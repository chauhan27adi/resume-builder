
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  longlong lVar4;
  longlong lVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong lStackX_8;
  undefined4 auStackX_20 [2];
  undefined8 uStack_30;
  
  uStack_30 = 0x10001d;
  lVar4 = func_0x();
  lVar4 = -lVar4;
  *(ulonglong *)(&stack0x00001ff8 + lVar4) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffd8 + lVar4);
  *(undefined8 *)(&stack0x00000050 + lVar4) = param_1;
  uVar7 = 1;
  bVar1 = true;
  *(undefined4 *)(&stack0x0000003c + lVar4) = 1;
  lVar5 = 0;
  *(undefined8 *)(&stack0x00000040 + lVar4) = 0;
  *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x100059;
  iVar2 = (*_DAT_)();
  if (iVar2 == 2) {
    *(undefined4 *)(&stack0x00000010 + lVar4) = 0x1fa0;
    *(undefined **)((longlong)&lStackX_8 + lVar4) = &stack0x00000030 + lVar4;
    *(undefined **)((longlong)auStackX_20 + lVar4 + -0x20) = &stack0x00000058 + lVar4;
    *(undefined **)(&stack0xfffffffffffffff8 + lVar4) = &stack0x00000034 + lVar4;
    *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x1000dd;
    iVar2 = func_0x(param_1,1,&stack0x00000028 + lVar4,&stack0x00000038 + lVar4);
    if (iVar2 == 1) {
      if ((*(int *)(&stack0x00000030 + lVar4) == 0) &&
         (iVar2 = *(int *)(&stack0x00000034 + lVar4), iVar2 != 0)) {
        if (((&stack0x00000028)[lVar4] - 0x25 & 0x77) == 0) {
          *(undefined4 *)(&stack0x0000002c + lVar4) = 0;
          *(undefined4 *)(&stack0x00000048 + lVar4) = 0;
          *(undefined **)((longlong)&lStackX_8 + lVar4) = &stack0x00000030 + lVar4;
          *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
          *(undefined **)(&stack0xfffffffffffffff8 + lVar4) = &stack0x00000034 + lVar4;
          *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x1001c3;
          iVar3 = (*_DAT_)(param_1,2,&stack0x00000028 + lVar4,&stack0x00000038 + lVar4);
          if (iVar3 == 1) {
            if ((&stack0x00000028)[lVar4] == -0x19) {
              if (*(int *)(&stack0x00000038 + lVar4) == 8000) {
                *(undefined **)((longlong)auStackX_20 + lVar4 + -0x20) = &stack0x0000002c + lVar4;
                *(undefined **)(&stack0xfffffffffffffff8 + lVar4) = &stack0x00000048 + lVar4;
                *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x1002d9;
                iVar2 = func_0x(5,&stack0x00000058 + lVar4,iVar2,&stack0x00000040 + lVar4);
                if (iVar2 < 0) {
                  *(undefined4 *)((longlong)auStackX_20 + lVar4) = 0xffffffff;
                  *(undefined8 *)(&stack0x00000018 + lVar4) = 0x108328;
                  *(undefined2 *)(&stack0x00000010 + lVar4) = 0;
                  *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 0;
                  *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
                  (&stack0xfffffffffffffff8)[lVar4] = 0;
                  *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x10031d;
                  (*_DAT_)(param_1,2,0xc357,0x10);
                  lVar5 = *(longlong *)(&stack0x00000040 + lVar4);
                }
                else {
                  uVar6 = *(uint *)(&stack0x0000002c + lVar4);
                  lVar5 = *(longlong *)(&stack0x00000040 + lVar4);
                  if ((uVar6 != 0) && (lVar5 != 0)) {
                    if (8000 < uVar6) {
                      uVar6 = 8000;
                    }
                    *(uint *)(&stack0x0000002c + lVar4) = uVar6;
                    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar4) = 0;
                    *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x10035d;
                    iVar2 = (*_DAT_)(param_1,2,lVar5);
                    if (iVar2 != 1) {
                      *(undefined4 *)((longlong)auStackX_20 + lVar4) = 0xffffffff;
                      *(undefined8 *)(&stack0x00000018 + lVar4) = 0x108358;
                      *(undefined2 *)(&stack0x00000010 + lVar4) = 0;
                      *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 0;
                      *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
                      (&stack0xfffffffffffffff8)[lVar4] = 0;
                      *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x1003a2;
                      (*_DAT_)(param_1,2,0xc357,0x10);
                      goto LAB_;
                    }
                  }
                  *(undefined4 *)(&stack0x0000003c + lVar4) = 0;
                  bVar1 = false;
                }
              }
              else {
                *(undefined4 *)((longlong)auStackX_20 + lVar4) = 0xffffffff;
                *(undefined8 *)(&stack0x00000018 + lVar4) = 0x1082d0;
                *(undefined2 *)(&stack0x00000010 + lVar4) = 0;
                *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 0;
                *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
                (&stack0xfffffffffffffff8)[lVar4] = 0;
                *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x1002a6;
                (*_DAT_)(param_1,2,0xc357,0x10);
              }
            }
            else {
              *(undefined4 *)((longlong)auStackX_20 + lVar4) = 0xffffffff;
              *(undefined8 *)(&stack0x00000018 + lVar4) = 0x108280;
              *(undefined2 *)(&stack0x00000010 + lVar4) = 0;
              *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 0;
              *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
              (&stack0xfffffffffffffff8)[lVar4] = 0;
              *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x100254;
              (*_DAT_)(param_1,2,0xc357,0x10);
            }
          }
          else {
            *(undefined4 *)((longlong)auStackX_20 + lVar4) = 0xffffffff;
            *(undefined8 *)(&stack0x00000018 + lVar4) = 0x1081c0;
            *(undefined2 *)(&stack0x00000010 + lVar4) = 0;
            *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 0;
            *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
            (&stack0xfffffffffffffff8)[lVar4] = 0;
            *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x100208;
            (*_DAT_)(param_1,2,0xc357,0x10);
          }
        }
        else {
          *(undefined4 *)((longlong)auStackX_20 + lVar4) = 0xffffffff;
          *(undefined8 *)(&stack0x00000018 + lVar4) = 0x108230;
          *(undefined2 *)(&stack0x00000010 + lVar4) = 0;
          *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 0;
          *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
          (&stack0xfffffffffffffff8)[lVar4] = 0;
          *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x10018b;
          (*_DAT_)(param_1,2,0xc357,0x10);
        }
      }
      else {
        *(undefined4 *)((longlong)auStackX_20 + lVar4) = 0xffffffff;
        *(undefined8 *)(&stack0x00000018 + lVar4) = 0x1081f0;
        *(undefined2 *)(&stack0x00000010 + lVar4) = 0;
        *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 0;
        *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
        (&stack0xfffffffffffffff8)[lVar4] = 0;
        *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x1003f4;
        (*_DAT_)(param_1,2,0xc357,0x10);
      }
    }
    else {
      *(undefined4 *)((longlong)auStackX_20 + lVar4) = 0xffffffff;
      *(undefined8 *)(&stack0x00000018 + lVar4) = 0x1081c0;
      *(undefined2 *)(&stack0x00000010 + lVar4) = 0;
      *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 0;
      *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
      (&stack0xfffffffffffffff8)[lVar4] = 0;
      *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x100122;
      (*_DAT_)(param_1,2,0xc357,0x10);
    }
  }
  else {
    *(undefined4 *)((longlong)auStackX_20 + lVar4) = 0xffffffff;
    *(undefined8 *)(&stack0x00000018 + lVar4) = 0x108190;
    *(undefined2 *)(&stack0x00000010 + lVar4) = 0;
    *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 0;
    *(undefined8 *)((longlong)auStackX_20 + lVar4 + -0x20) = 0;
    (&stack0xfffffffffffffff8)[lVar4] = 0;
    *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x10009d;
    (*_DAT_)(param_1,2,0xc357,0x10);
    lVar5 = 0;
  }
LAB_:
  if (bVar1) {
    uVar7 = 3;
  }
  *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x100464;
  (*_DAT_)(param_1,uVar7,0,0);
  if (lVar5 != 0) {
    *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x100476;
    func_0x(lVar5,2);
  }
  *(undefined8 *)((longlong)&uStack_30 + lVar4) = 0x100488;
  func_0x(*(ulonglong *)(&stack0x00001ff8 + lVar4) ^
                  (ulonglong)(&stack0xffffffffffffffd8 + lVar4));
  return;
}

