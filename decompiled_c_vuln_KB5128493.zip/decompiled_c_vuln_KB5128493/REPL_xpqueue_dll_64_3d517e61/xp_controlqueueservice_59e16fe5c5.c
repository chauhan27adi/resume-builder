
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  undefined4 uVar7;
  longlong lVar8;
  undefined auStack_1e8 [32];
  undefined8 uStack_1c8;
  int *piStack_1c0;
  undefined8 uStack_1b8;
  undefined4 uStack_1b0;
  undefined4 *puStack_1a8;
  undefined4 uStack_1a0;
  char acStack_198 [4];
  int iStack_194;
  int iStack_190;
  int iStack_18c;
  int iStack_188;
  undefined4 uStack_184;
  undefined auStack_180 [4];
  undefined4 uStack_17c;
  undefined4 uStack_178;
  int iStack_174;
  longlong lStack_170;
  longlong lStack_168;
  undefined8 uStack_160;
  undefined auStack_158 [4];
  int iStack_154;
  uint uStack_144;
  undefined8 uStack_138;
  undefined2 uStack_130;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined2 uStack_f4;
  undefined uStack_f2;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined2 uStack_9c;
  undefined uStack_9a;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined2 uStack_40;
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)auStack_1e8;
  iVar5 = 1;
  uStack_184 = 1;
  lVar6 = 0;
  lStack_170 = 0;
  lVar8 = 0;
  lStack_168 = 0;
  iVar4 = 0;
  iStack_194 = 0;
  uStack_138 = _DAT_;
  uStack_130 = _DAT_;
  uStack_98 = _DAT_;
  uStack_94 = uRam0000000000107214;
  uStack_90 = uRam0000000000107218;
  uStack_8c = uRam000000000010721c;
  uStack_88 = _DAT_;
  uStack_84 = uRam0000000000107224;
  uStack_80 = uRam0000000000107228;
  uStack_7c = uRam000000000010722c;
  uStack_78 = _DAT_;
  uStack_74 = uRam0000000000107234;
  uStack_70 = uRam0000000000107238;
  uStack_6c = uRam000000000010723c;
  uStack_68 = _DAT_;
  uStack_64 = uRam0000000000107244;
  uStack_60 = uRam0000000000107248;
  uStack_5c = uRam000000000010724c;
  uStack_58 = _DAT_;
  uStack_54 = uRam0000000000107254;
  uStack_50 = uRam0000000000107258;
  uStack_4c = uRam000000000010725c;
  uStack_48 = _DAT_;
  uStack_40 = _DAT_;
  uStack_128 = _DAT_;
  uStack_124 = uRam0000000000107274;
  uStack_120 = uRam0000000000107278;
  uStack_11c = uRam000000000010727c;
  uStack_118 = _DAT_;
  uStack_114 = uRam0000000000107284;
  uStack_110 = uRam0000000000107288;
  uStack_10c = uRam000000000010728c;
  uStack_108 = _DAT_;
  uStack_104 = uRam0000000000107294;
  uStack_100 = uRam0000000000107298;
  uStack_fc = uRam000000000010729c;
  uStack_f8 = _DAT_;
  uStack_f4 = _DAT_;
  uStack_f2 = DAT_;
  uStack_e8 = _DAT_;
  uStack_e4 = uRam00000000001072b4;
  uStack_e0 = uRam00000000001072b8;
  uStack_dc = uRam00000000001072bc;
  uStack_d8 = _DAT_;
  uStack_d4 = uRam00000000001072c4;
  uStack_d0 = uRam00000000001072c8;
  uStack_cc = uRam00000000001072cc;
  uStack_c8 = _DAT_;
  uStack_c4 = uRam00000000001072d4;
  uStack_c0 = uRam00000000001072d8;
  uStack_bc = uRam00000000001072dc;
  uStack_b8 = _DAT_;
  uStack_b4 = uRam00000000001072e4;
  uStack_b0 = uRam00000000001072e8;
  uStack_ac = uRam00000000001072ec;
  uStack_a8 = _DAT_;
  uStack_a0 = _DAT_;
  uStack_9c = _DAT_;
  uStack_9a = DAT_;
  uStack_160 = param_1;
  iVar2 = (*_DAT_)();
  if (iVar2 == 2) {
    uStack_1b0 = 4;
    uStack_1b8 = &iStack_190;
    piStack_1c0 = &iStack_188;
    uStack_1c8 = &iStack_18c;
    iVar2 = func_0x(param_1,1,acStack_198,auStack_180);
    if (iVar2 == 1) {
      if ((iStack_190 == 0) && (iStack_18c != 0)) {
        if ((acStack_198[0] == '&') || (acStack_198[0] == '8')) {
          uStack_1b0 = 4;
          uStack_1b8 = &iStack_190;
          piStack_1c0 = &iStack_194;
          uStack_1c8 = &iStack_18c;
          iVar2 = func_0x(param_1,2,acStack_198,auStack_180);
          if (iVar2 == 1) {
            if ((acStack_198[0] == '&') || (acStack_198[0] == '8')) {
              if ((iStack_190 != 0) || (iStack_18c == 0)) {
                iStack_194 = 0;
              }
              if ((_DAT_ == 0) && (iVar2 = func_0x(), iVar2 < 0)) {
                uStack_1a0 = 0xffffffff;
                puStack_1a8 = &uStack_128;
                uStack_1b0 = uStack_1b0 & 0xffff0000;
                uStack_1b8 = (int *)((ulonglong)uStack_1b8 & 0xffffffff00000000);
                piStack_1c0 = (int *)0x0;
                uStack_1c8 = (int *)((ulonglong)uStack_1c8 & 0xffffffffffffff00);
                (*_DAT_)(param_1,2,0xc357,0x10);
              }
              else {
                uStack_17c = 4;
                if (iStack_188 == 2) {
                  uStack_17c = 0x20000004;
                }
                lVar6 = (*_DAT_)(0,0);
                lStack_170 = lVar6;
                if (lVar6 == 0) {
                  uStack_1a0 = 0xffffffff;
                  puStack_1a8 = (undefined4 *)0x107430;
                  uStack_1b0 = uStack_1b0 & 0xffff0000;
                  uStack_1b8 = (int *)((ulonglong)uStack_1b8 & 0xffffffff00000000);
                  piStack_1c0 = (int *)0x0;
                  uStack_1c8 = (int *)((ulonglong)uStack_1c8 & 0xffffffffffffff00);
                  (*_DAT_)(param_1,2,0xc357,0x10);
                }
                else {
                  uStack_178 = 0x80000000;
                  if (iStack_188 == 2) {
                    uStack_178 = 0x80000010;
                  }
                  lVar8 = (*_DAT_)(lVar6,&uStack_138);
                  lStack_168 = lVar8;
                  if (lVar8 == 0) {
                    iVar2 = (*_DAT_)();
                    uStack_1a0 = 0xffffffff;
                    puStack_1a8 = &uStack_e8;
                    if (iVar2 != 0x424) {
                      puStack_1a8 = (undefined4 *)0x107470;
                    }
                    uStack_1b0 = uStack_1b0 & 0xffff0000;
                    uStack_1b8 = (int *)((ulonglong)uStack_1b8 & 0xffffffff00000000);
                    piStack_1c0 = (int *)0x0;
                    uStack_1c8 = (int *)((ulonglong)uStack_1c8 & 0xffffffffffffff00);
                    (*_DAT_)(param_1,2,0xc357,0x10);
                  }
                  else {
                    iVar2 = (*_DAT_)(lVar8,auStack_158);
                    if (iVar2 == 0) {
                      uStack_1a0 = 0xffffffff;
                      puStack_1a8 = (undefined4 *)0x1074d0;
                      uStack_1b0 = uStack_1b0 & 0xffff0000;
                      uStack_1b8 = (int *)((ulonglong)uStack_1b8 & 0xffffffff00000000);
                      piStack_1c0 = (int *)0x0;
                      uStack_1c8 = (int *)((ulonglong)uStack_1c8 & 0xffffffffffffff00);
                      (*_DAT_)(param_1,2,0xc357,0x10);
                    }
                    else {
                      if (iStack_188 == 1) {
                        iStack_174 = iStack_154;
                        iVar2 = iStack_154;
                      }
                      else {
                        iVar2 = iVar4;
                        if (iStack_188 == 2) {
                          iVar2 = 4;
                          iStack_174 = 4;
                          if ((iStack_154 - 1U & 0xfffffffd) == 0) {
                            iVar3 = (*_DAT_)(lVar8,0,0);
                            if (iVar3 == 0) {
                              uStack_1a0 = 0xffffffff;
                              puStack_1a8 = (undefined4 *)0x107530;
                              uStack_1b0 = uStack_1b0 & 0xffff0000;
                              uStack_1b8 = (int *)((ulonglong)uStack_1b8 & 0xffffffff00000000);
                              piStack_1c0 = (int *)0x0;
                              uStack_1c8 = (int *)((ulonglong)uStack_1c8 & 0xffffffffffffff00);
                              (*_DAT_)(param_1,2,0xc357,0x10);
                              goto LAB_;
                            }
                            iVar3 = (*_DAT_)(lVar8,auStack_158);
                            if (iVar3 == 0) {
                              uStack_1a0 = 0xffffffff;
                              puStack_1a8 = (undefined4 *)0x107568;
                              uStack_1b0 = uStack_1b0 & 0xffff0000;
                              uStack_1b8 = (int *)((ulonglong)uStack_1b8 & 0xffffffff00000000);
                              piStack_1c0 = (int *)0x0;
                              uStack_1c8 = (int *)((ulonglong)uStack_1c8 & 0xffffffffffffff00);
                              (*_DAT_)(param_1,2,0xc357,0x10);
                              goto LAB_;
                            }
                          }
                        }
                      }
                      do {
                        uVar1 = uStack_144;
                        if (iStack_154 == iVar2) goto LAB_;
                        (*_DAT_)(10000);
                        iVar3 = (*_DAT_)(lVar8,auStack_158);
                      } while ((iVar3 != 0) && (uVar1 < uStack_144));
                      if (iStack_154 == iVar2) {
LAB_:
                        switch(iVar2) {
                        case 1:
                          iStack_194 = 2;
                          break;
                        case 2:
                          iStack_194 = 4;
                          break;
                        case 3:
                          iStack_194 = 5;
                          break;
                        case 4:
                          iStack_194 = 1;
                          break;
                        case 5:
                          iStack_194 = 7;
                          break;
                        case 6:
                          iStack_194 = 6;
                          break;
                        case 7:
                          iStack_194 = 3;
                        }
                        uStack_184 = 0;
                        iVar5 = iVar4;
                      }
                    }
                  }
                }
              }
            }
            else {
              uStack_1a0 = 0xffffffff;
              puStack_1a8 = (undefined4 *)0x1073e0;
              uStack_1b0 = (uint)uStack_1b0._2_2_ << 0x10;
              uStack_1b8 = (int *)((ulonglong)uStack_1b8._4_4_ << 0x20);
              piStack_1c0 = (int *)0x0;
              uStack_1c8 = (int *)((ulonglong)uStack_1c8._1_7_ << 8);
              (*_DAT_)(param_1,2,0xc357,0x10);
            }
          }
          else {
            uStack_1a0 = 0xffffffff;
            puStack_1a8 = (undefined4 *)0x107300;
            uStack_1b0 = (uint)uStack_1b0._2_2_ << 0x10;
            uStack_1b8 = (int *)((ulonglong)uStack_1b8._4_4_ << 0x20);
            piStack_1c0 = (int *)0x0;
            uStack_1c8 = (int *)((ulonglong)uStack_1c8._1_7_ << 8);
            (*_DAT_)(param_1,2,0xc357,0x10);
          }
        }
        else {
          uStack_1a0 = 0xffffffff;
          puStack_1a8 = (undefined4 *)0x107390;
          uStack_1b0 = (uint)uStack_1b0._2_2_ << 0x10;
          uStack_1b8 = (int *)((ulonglong)uStack_1b8._4_4_ << 0x20);
          piStack_1c0 = (int *)0x0;
          uStack_1c8 = (int *)((ulonglong)uStack_1c8._1_7_ << 8);
          (*_DAT_)(param_1,2,0xc357,0x10);
        }
      }
      else {
        uStack_1a0 = 0xffffffff;
        puStack_1a8 = (undefined4 *)0x107340;
        uStack_1b0 = (uint)uStack_1b0._2_2_ << 0x10;
        uStack_1b8 = (int *)((ulonglong)uStack_1b8._4_4_ << 0x20);
        piStack_1c0 = (int *)0x0;
        uStack_1c8 = (int *)((ulonglong)uStack_1c8._1_7_ << 8);
        (*_DAT_)(param_1,2,0xc357,0x10);
      }
    }
    else {
      uStack_1a0 = 0xffffffff;
      puStack_1a8 = (undefined4 *)0x107300;
      uStack_1b0 = uStack_1b0 & 0xffff0000;
      uStack_1b8 = (int *)((ulonglong)uStack_1b8 & 0xffffffff00000000);
      piStack_1c0 = (int *)0x0;
      uStack_1c8 = (int *)((ulonglong)uStack_1c8 & 0xffffffffffffff00);
      (*_DAT_)(param_1,2,0xc357,0x10);
    }
  }
  else {
    uStack_1a0 = 0xffffffff;
    puStack_1a8 = &uStack_98;
    uStack_1b0 = (uint)uStack_1b0._2_2_ << 0x10;
    uStack_1b8 = (int *)((ulonglong)uStack_1b8._4_4_ << 0x20);
    piStack_1c0 = (int *)0x0;
    uStack_1c8 = (int *)((ulonglong)uStack_1c8 & 0xffffffffffffff00);
    (*_DAT_)(param_1,2,0xc357,0x10);
    lVar6 = 0;
    lVar8 = 0;
    iVar5 = 1;
  }
LAB_:
  if (lVar8 != 0) {
    (*_DAT_)(lVar8);
  }
  if (lVar6 != 0) {
    (*_DAT_)(lVar6);
  }
  if (iVar5 == 1) {
    iStack_194 = iVar4;
  }
  uStack_1c8 = (int *)((ulonglong)uStack_1c8 & 0xffffffff00000000);
  (*_DAT_)(param_1,2,&iStack_194);
  uVar7 = 1;
  if (iVar5 != 0) {
    uVar7 = 3;
  }
  (*_DAT_)(param_1,uVar7,0,0);
  func_0x(uStack_38 ^ (ulonglong)auStack_1e8);
  return;
}

