
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(double *param_1,ulonglong param_2,undefined4 param_3,undefined4 param_4,
                 longlong *param_5,uint *param_6,int *param_7)

{
  undefined uVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  byte bVar6;
  byte bVar7;
  byte bVar8;
  ushort uVar9;
  ushort uVar10;
  ushort uVar11;
  ushort uVar12;
  ushort uVar13;
  short sVar14;
  float fVar15;
  uint uVar16;
  undefined auVar17 [16];
  double dVar18;
  longlong *plVar19;
  uint *puVar20;
  int *piVar21;
  int iVar22;
  longlong lVar23;
  undefined8 uVar24;
  undefined2 *puVar25;
  short *psVar26;
  int iVar27;
  ulonglong uVar28;
  int iVar29;
  longlong lVar30;
  undefined8 *puVar31;
  uint uVar32;
  uint auStackX_8 [2];
  float afStackX_10 [2];
  uint auStackX_18 [2];
  uint uStack_2168;
  double *pdStack_2160;
  undefined4 uStack_2158;
  undefined2 uStack_2154;
  undefined4 uStack_2150;
  undefined2 uStack_214c;
  undefined4 uStack_2148;
  undefined2 uStack_2144;
  undefined8 uStack_2140;
  undefined2 uStack_2138;
  undefined8 uStack_2130;
  undefined2 uStack_2128;
  undefined8 uStack_2120;
  undefined4 uStack_2118;
  undefined4 uStack_2108;
  undefined4 uStack_2104;
  undefined4 uStack_2100;
  undefined4 uStack_20fc;
  undefined4 uStack_20f8;
  undefined4 uStack_20f4;
  undefined4 uStack_20f0;
  undefined4 uStack_20ec;
  undefined4 uStack_20e8;
  undefined4 uStack_20e4;
  undefined4 uStack_20e0;
  undefined4 uStack_20dc;
  undefined4 uStack_20d8;
  undefined4 uStack_20d4;
  undefined4 uStack_20d0;
  undefined4 uStack_20cc;
  undefined8 uStack_20c8;
  undefined2 uStack_20c0;
  undefined4 uStack_20b8;
  undefined4 uStack_20b4;
  undefined4 uStack_20b0;
  undefined4 uStack_20ac;
  undefined4 uStack_20a8;
  undefined4 uStack_20a4;
  undefined4 uStack_20a0;
  undefined4 uStack_209c;
  undefined4 uStack_2098;
  undefined4 uStack_2094;
  undefined4 uStack_2090;
  undefined4 uStack_208c;
  undefined4 uStack_2088;
  undefined4 uStack_2084;
  undefined4 uStack_2080;
  undefined4 uStack_207c;
  undefined4 uStack_2078;
  undefined4 uStack_2074;
  undefined4 uStack_2070;
  undefined4 uStack_206c;
  undefined4 uStack_2068;
  undefined4 uStack_2064;
  undefined4 uStack_2060;
  undefined4 uStack_205c;
  undefined4 uStack_2058;
  undefined2 uStack_2054;
  short asStack_2048 [4096];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x100022;
  lVar23 = func_0x();
  piVar21 = param_7;
  puVar20 = param_6;
  plVar19 = param_5;
  lVar23 = -lVar23;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar23);
  param_2 = param_2 & 0xffffffff;
  uStack_2168 = 0;
  uVar28 = (ulonglong)*param_6;
  *(undefined4 *)((longlong)&param_7 + lVar23) = 0;
  uStack_2158 = _DAT_;
  uStack_2154 = _DAT_;
  uStack_2118 = _DAT_;
  uStack_2120 = _DAT_;
  uStack_2128 = _DAT_;
  uStack_2130 = _DAT_;
  uStack_20c0 = _DAT_;
  uStack_2108 = _DAT_;
  uStack_2104 = uRam0000000000106ab4;
  uStack_2100 = uRam0000000000106ab8;
  uStack_20fc = uRam0000000000106abc;
  uStack_2058 = _DAT_;
  uStack_20e8 = _DAT_;
  uStack_20e4 = uRam0000000000106ad4;
  uStack_20e0 = uRam0000000000106ad8;
  uStack_20dc = uRam0000000000106adc;
  uStack_2054 = _DAT_;
  uStack_20f8 = _DAT_;
  uStack_20f4 = uRam0000000000106ac4;
  uStack_20f0 = uRam0000000000106ac8;
  uStack_20ec = uRam0000000000106acc;
  uStack_20c8 = _DAT_;
  uStack_2148 = _DAT_;
  uStack_20d8 = _DAT_;
  uStack_20d4 = uRam0000000000106ae4;
  uStack_20d0 = uRam0000000000106ae8;
  uStack_20cc = uRam0000000000106aec;
  uStack_20b8 = _DAT_;
  uStack_20b4 = uRam0000000000106b04;
  uStack_20b0 = uRam0000000000106b08;
  uStack_20ac = uRam0000000000106b0c;
  uStack_2144 = _DAT_;
  uStack_2150 = _DAT_;
  uStack_20a8 = _DAT_;
  uStack_20a4 = uRam0000000000106b14;
  uStack_20a0 = uRam0000000000106b18;
  uStack_209c = uRam0000000000106b1c;
  uStack_2098 = _DAT_;
  uStack_2094 = uRam0000000000106b24;
  uStack_2090 = uRam0000000000106b28;
  uStack_208c = uRam0000000000106b2c;
  uStack_214c = _DAT_;
  uStack_2088 = _DAT_;
  uStack_2084 = uRam0000000000106b34;
  uStack_2080 = uRam0000000000106b38;
  uStack_207c = uRam0000000000106b3c;
  uStack_2078 = _DAT_;
  uStack_2074 = uRam0000000000106b44;
  uStack_2070 = uRam0000000000106b48;
  uStack_206c = uRam0000000000106b4c;
  *(undefined4 *)(&stack0x00000044 + lVar23) = param_3;
  iVar22 = *piVar21;
  uStack_2138 = _DAT_;
  *(undefined4 *)((longlong)&param_7 + lVar23 + 4) = param_4;
  uStack_2068 = _DAT_;
  uStack_2064 = uRam0000000000106b54;
  uStack_2060 = uRam0000000000106b58;
  uStack_205c = uRam0000000000106b5c;
  *(undefined4 *)(&stack0x00000040 + lVar23) = 0x27;
  uStack_2140 = _DAT_;
  pdStack_2160 = param_1;
LAB_:
  iVar29 = (int)param_2;
  if ((uint)uVar28 < (uint)(iVar22 + 6 + iVar29)) {
    do {
      auVar17 = ZEXT816(2) * ZEXT416((int)(uVar28 >> 1) + 0x1001);
      uVar24 = auVar17._0_8_;
      if (auVar17._8_8_ != 0) {
        uVar24 = 0xffffffffffffffff;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1001dc;
      puVar25 = (undefined2 *)func_0x(uVar24);
      *puVar20 = *puVar20 + 0x2000;
      *puVar25 = 0;
      if (*plVar19 != 0) {
        uVar32 = *puVar20;
        *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100204;
        (*_DAT_)(puVar25,(uVar32 >> 1) + 1);
        lVar30 = *plVar19;
        *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100212;
        func_0x(lVar30,2);
      }
      *plVar19 = (longlong)puVar25;
      iVar22 = *piVar21;
      uVar28 = (ulonglong)*puVar20;
      param_1 = pdStack_2160;
    } while (*puVar20 < (uint)(iVar22 + 6 + iVar29));
  }
  else {
    puVar25 = (undefined2 *)*plVar19;
  }
  uVar32 = (uint)uVar28;
  if (param_1 == (double *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10070b;
    (*_DAT_)(puVar25,(uVar32 >> 1) + 1,&uStack_2140);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (*(short *)((longlong)&uStack_2140 + lVar30 * 2) != 0);
    *piVar21 = *piVar21 + (int)lVar30 * 2;
    goto LAB_;
  }
  switch(*(undefined4 *)(&stack0x00000044 + lVar23)) {
  case 2:
  case 3:
  case 8:
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1006f2;
    (*pcRam0000000000104e70)(puVar25,(uVar32 >> 1) + 1,param_1,param_2 >> 1);
    *piVar21 = *piVar21 + iVar29;
    goto LAB_;
  case 4:
    fVar15 = *(float *)param_1;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100434;
    func_0x(asStack_2048,0x1000,&uStack_2158,fVar15);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 5:
    sVar14 = *(short *)param_1;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100406;
    func_0x(asStack_2048,0x1000,&uStack_2158,(int)sVar14);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 6:
  case 7:
    if (iVar29 == 4) {
      puVar31 = &uStack_2130;
      dVar18 = (double)*(float *)param_1;
    }
    else {
      dVar18 = *param_1;
      puVar31 = &uStack_2120;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10047f;
    func_0x(asStack_2048,0x1000,puVar31,dVar18);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 9:
    uVar9 = *(ushort *)((longlong)param_1 + 10);
    uVar10 = *(ushort *)(param_1 + 1);
    uVar11 = *(ushort *)((longlong)param_1 + 6);
    uVar12 = *(ushort *)((longlong)param_1 + 4);
    uVar13 = *(ushort *)((longlong)param_1 + 2);
    sVar14 = *(short *)param_1;
    *(float *)((longlong)afStackX_10 + lVar23) = *(float *)((longlong)param_1 + 0xc);
    *(uint *)((longlong)auStackX_8 + lVar23) = (uint)uVar9;
    *(uint *)(&stack0x00000000 + lVar23) = (uint)uVar10;
    *(uint *)(&stack0xfffffffffffffff8 + lVar23) = (uint)uVar11;
    *(uint *)(&stack0xfffffffffffffff0 + lVar23) = (uint)uVar12;
    *(uint *)(&stack0xffffffffffffffe8 + lVar23) = (uint)uVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1004ed;
    func_0x(asStack_2048,0x1000,&uStack_2108,(int)sVar14);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 0xfffffff5:
    bVar2 = *(byte *)((longlong)param_1 + 0xe);
    bVar3 = *(byte *)((longlong)param_1 + 0xd);
    bVar4 = *(byte *)((longlong)param_1 + 0xc);
    bVar5 = *(byte *)((longlong)param_1 + 0xb);
    bVar6 = *(byte *)((longlong)param_1 + 10);
    bVar7 = *(byte *)((longlong)param_1 + 9);
    bVar8 = *(byte *)(param_1 + 1);
    uVar9 = *(ushort *)((longlong)param_1 + 6);
    uVar10 = *(ushort *)((longlong)param_1 + 4);
    *(uint *)((longlong)&param_6 + lVar23) = (uint)*(byte *)((longlong)param_1 + 0xf);
    *(uint *)((longlong)&param_5 + lVar23) = (uint)bVar2;
    *(uint *)(&stack0x00000020 + lVar23) = (uint)bVar3;
    *(uint *)((longlong)auStackX_18 + lVar23) = (uint)bVar4;
    *(uint *)((longlong)afStackX_10 + lVar23) = (uint)bVar5;
    *(uint *)((longlong)auStackX_8 + lVar23) = (uint)bVar6;
    *(uint *)(&stack0x00000000 + lVar23) = (uint)bVar7;
    *(uint *)(&stack0xfffffffffffffff8 + lVar23) = (uint)bVar8;
    *(uint *)(&stack0xfffffffffffffff0 + lVar23) = (uint)uVar9;
    *(uint *)(&stack0xffffffffffffffe8 + lVar23) = (uint)uVar10;
    fVar15 = *(float *)pdStack_2160;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100583;
    func_0x(asStack_2048,0x1000,&uStack_20b8,fVar15);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
      param_1 = pdStack_2160;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 0xfffffff6:
  case 0xfffffff7:
  case 0xfffffff8:
    iVar22 = *(int *)((longlong)&param_7 + lVar23 + 4);
    if (iVar22 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100690;
      (*_DAT_)(puVar25,(uVar32 >> 1) + 1,&uStack_2148);
      *piVar21 = *piVar21 + 2;
      uVar32 = *puVar20;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1006b1;
    (*pcRam0000000000104e70)(puVar25,(uVar32 >> 1) + 1,param_1,param_2 >> 1);
    *piVar21 = *piVar21 + iVar29;
    if (iVar22 == 0) goto LAB_;
    uVar32 = *puVar20;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1006d3;
    (*_DAT_)(puVar25,(uVar32 >> 1) + 1,&stack0x00000040 + lVar23);
    *piVar21 = *piVar21 + 2;
    goto code_r0x00100728;
  case 0xfffffff9:
  case 0xfffffffa:
    uVar1 = *(undefined *)param_1;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10039e;
    func_0x(asStack_2048,0x1000,&uStack_2158,uVar1);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  default:
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1005c0;
    func_0x(asStack_2048,0x1000,0x106ba0,*(undefined4 *)(&stack0x00000044 + lVar23));
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 0xfffffffc:
  case 0xfffffffd:
  case 0xfffffffe:
    iVar27 = *(int *)((longlong)&param_7 + lVar23);
    if (*(int *)((longlong)&param_7 + lVar23) == 0) {
      iVar27 = iVar29;
    }
    *(int *)((longlong)&param_7 + lVar23) = iVar27;
    param_2 = (ulonglong)(iVar27 * 4 + 4);
    if ((uint)(iVar27 * 4 + 10 + iVar22) <= uVar32) {
      *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10031c;
      (*_DAT_)(puVar25,(uVar32 >> 1) + 1,0x106b84);
      *piVar21 = *piVar21 + 4;
      uVar32 = *(uint *)((longlong)&param_7 + lVar23);
      if (uVar32 != 0) goto code_r0x00100330;
      goto LAB_;
    }
    goto LAB_;
  case 0xffffffff:
  case 1:
  case 0xc:
    goto code_r0x0010026c;
  }
  iVar22 = *piVar21;
  uVar16 = (int)lVar30 * 2;
  param_2 = (ulonglong)uVar16;
  uVar32 = *puVar20;
  uVar28 = (ulonglong)uVar32;
  if (iVar22 + 6 + uVar16 <= uVar32) {
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1003e5;
    (*_DAT_)(puVar25,(uVar32 >> 1) + 1,asStack_2048);
    *piVar21 = *piVar21 + uVar16;
    goto LAB_;
  }
  goto LAB_;
code_r0x0010026c:
  iVar27 = *(int *)((longlong)&param_7 + lVar23);
  if (*(int *)((longlong)&param_7 + lVar23) == 0) {
    iVar27 = iVar29;
  }
  *(int *)((longlong)&param_7 + lVar23) = iVar27;
  param_2 = (ulonglong)(uint)(iVar27 * 2);
  if (iVar27 * 2 + 6U + iVar22 <= uVar32) goto code_r0x0010028a;
  goto LAB_;
code_r0x0010028a:
  if (*(int *)((longlong)&param_7 + lVar23 + 4) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1002a6;
    (*_DAT_)(puVar25,(uVar32 >> 1) + 1,&stack0x00000040 + lVar23);
    *piVar21 = *piVar21 + 2;
    iVar27 = *(int *)((longlong)&param_7 + lVar23);
  }
  uVar32 = iVar27 + 1;
  if (uVar32 < 0x1001) {
    psVar26 = asStack_2048;
    uVar32 = 0x1000;
  }
  else {
    uVar24 = SUB168(ZEXT816(2) * ZEXT416(uVar32),0);
    if (SUB168(ZEXT816(2) * ZEXT416(uVar32),8) != 0) {
      uVar24 = 0xffffffffffffffff;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1002d9;
    psVar26 = (short *)func_0x(uVar24);
    iVar27 = *(int *)((longlong)&param_7 + lVar23);
  }
  *(uint *)(&stack0xfffffffffffffff0 + lVar23) = uVar32;
  *(short **)(&stack0xffffffffffffffe8 + lVar23) = psVar26;
  *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10060d;
  iVar22 = (*pcRam0000000000104cd8)(0,0,param_1,iVar27);
  psVar26[iVar22] = 0;
  uVar16 = *puVar20;
  *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10062e;
  (*_DAT_)(puVar25,(uVar16 >> 1) + 1,psVar26);
  *piVar21 = *piVar21 + iVar22 * 2;
  if (*(int *)((longlong)&param_7 + lVar23 + 4) != 0) {
    uVar16 = *puVar20;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100651;
    (*_DAT_)(puVar25,(uVar16 >> 1) + 1,&stack0x00000040 + lVar23);
    *piVar21 = *piVar21 + 2;
  }
  if (0x1000 < uVar32) {
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10066d;
    func_0x(psVar26);
  }
  goto LAB_;
  while( true ) {
    uVar1 = *(undefined *)param_1;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100355;
    func_0x(asStack_2048,0x1000,0x106b90,uVar1);
    uVar16 = *puVar20;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10036d;
    (*_DAT_)(puVar25,(uVar16 >> 1) + 1,asStack_2048);
    param_1 = (double *)((longlong)param_1 + 1);
    *piVar21 = *piVar21 + 4;
    uStack_2168 = uStack_2168 + 1;
    if (uVar32 <= uStack_2168) break;
code_r0x00100330:
    if (param_1 == (double *)0x0) break;
  }
LAB_:
  if (*(int *)((longlong)&param_7 + lVar23 + 4) != 0) {
code_r0x00100728:
    lVar30 = -1;
    uVar32 = *puVar20;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10073d;
    (*_DAT_)(puVar25,(uVar32 >> 1) + 1,&uStack_2150);
    do {
      lVar30 = lVar30 + 1;
    } while (*(short *)((longlong)&uStack_2150 + lVar30 * 2) != 0);
    *piVar21 = *piVar21 + (int)lVar30 * 2;
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100761;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar23));
  return;
}

