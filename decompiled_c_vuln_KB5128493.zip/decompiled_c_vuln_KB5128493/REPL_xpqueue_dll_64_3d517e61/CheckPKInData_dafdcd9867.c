
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,uint param_2,uint *param_3,uint param_4,uint param_5,
                 longlong param_6,undefined8 param_7,longlong param_8)

{
  longlong lVar1;
  byte bVar2;
  undefined (*pauVar3) [16];
  code *pcVar4;
  byte bVar5;
  int iVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 uVar9;
  uint uVar10;
  uint *puVar11;
  uint uVar12;
  longlong lVar13;
  uint *puVar14;
  ulonglong uVar15;
  int iVar16;
  short *psVar17;
  undefined auStack_1e8 [32];
  uint uStack_1c8;
  undefined8 uStack_1c0;
  uint uStack_1b8;
  uint uStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_198;
  uint uStack_190;
  uint uStack_18c;
  uint *puStack_188;
  undefined8 uStack_180;
  undefined2 uStack_178;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined2 uStack_15c;
  undefined2 auStack_158 [136];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1e8;
  uVar12 = 0;
  uStack_180 = 0;
  uStack_178 = 0;
  uStack_160 = _DAT_;
  uStack_15c = _DAT_;
  uStack_170 = _DAT_;
  uStack_16c = uRam000000000010a73c;
  uStack_168 = uRam000000000010a740;
  uStack_164 = uRam000000000010a744;
  uStack_198 = param_1;
  if (param_4 == *param_3) {
    puVar14 = (uint *)((ulonglong)param_4 + (longlong)param_3);
    if ((param_3 + 1 < puVar14) && (puVar11 = param_3 + 2, param_2 <= param_3[1])) {
      uVar10 = uVar12;
      if (param_2 != 0xffffffff) {
        do {
          if (puVar14 <= puVar11) goto LAB_;
          uVar10 = uVar10 + 1;
          puVar11 = (uint *)((longlong)puVar11 + (ulonglong)*puVar11);
        } while (uVar10 < param_2 + 1);
      }
      if ((((puVar11 < puVar14) && ((uint *)((ulonglong)*puVar11 + (longlong)puVar11) <= puVar14))
          && (puVar11 + 1 < puVar14)) && ((uint *)((longlong)puVar11 + 9U) < puVar14)) {
        uVar10 = *(uint *)((longlong)puVar11 + 9U);
        if (((uint *)((longlong)puVar11 + 0x11U) < puVar14) && (uVar10 < 0x102)) {
          func_0x(auStack_158,(uint *)((longlong)puVar11 + 0x11U),uVar10);
          if (0x101 < ((ulonglong)uVar10 & 0xfffffffffffffffe)) {
            func_0x();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
          }
          *(undefined2 *)((longlong)auStack_158 + ((ulonglong)uVar10 & 0xfffffffffffffffe)) = 0;
          lVar7 = (*_DAT_)(auStack_158,param_7);
          if ((lVar7 != 0) && (lVar7 = (*_DAT_)(auStack_158,&uStack_170), lVar7 != 0)) {
            lVar13 = -1;
            lVar8 = -1;
            do {
              lVar1 = lVar8 * 2;
              lVar8 = lVar8 + 1;
            } while (*(short *)((longlong)&uStack_170 + lVar1 + 2) != 0);
            iVar16 = 3;
            (*_DAT_)(&uStack_180,5,lVar7 + lVar8 * 2,3);
            uVar9 = uStack_198;
            uStack_180 = uStack_180 & 0xffffffffffff;
            if (*(int *)(param_6 + 0x34) == 0) {
              uStack_1a8 = 0;
              uStack_1b0 = 6;
              uStack_1b8 = 0xe7;
              uStack_1c0 = CONCAT44(uStack_1c0._4_4_,6);
              uStack_1c8 = 0xe7;
              *(undefined *)(param_6 + 2) = 0xe7;
              *(undefined4 *)(param_6 + 4) = 6;
              *(undefined *)(param_6 + 8) = 0xe7;
              *(undefined4 *)(param_6 + 0xc) = 6;
              iVar6 = (*_DAT_)(uStack_198,1,param_6 + 0x10,*(undefined4 *)(param_6 + 0x30));
              if (iVar6 != 1) goto LAB_;
              *(undefined4 *)(param_6 + 0x34) = 1;
            }
            lVar7 = -1;
            do {
              lVar8 = lVar7 * 2;
              lVar7 = lVar7 + 1;
            } while (*(short *)((longlong)&uStack_180 + lVar8 + 2) != 0);
            (*_DAT_)(uVar9,1,(int)lVar7 * 2);
            (*_DAT_)(uVar9,1,&uStack_180);
            if (*(int *)(param_6 + 0x7c) == 0) {
              uStack_1a8 = 0;
              uStack_1b0 = 0x8c;
              uStack_1b8 = 0xe7;
              uStack_1c0 = CONCAT44(uStack_1c0._4_4_,0x8c);
              uStack_1c8 = 0xe7;
              *(undefined *)(param_6 + 0x4a) = 0xe7;
              *(undefined4 *)(param_6 + 0x4c) = 0x8c;
              *(undefined *)(param_6 + 0x50) = 0xe7;
              *(undefined4 *)(param_6 + 0x54) = 0x8c;
              iVar6 = (*_DAT_)(uVar9,2,param_6 + 0x58,*(undefined4 *)(param_6 + 0x78));
              if (iVar6 != 2) goto LAB_;
              *(undefined4 *)(param_6 + 0x7c) = 1;
            }
            do {
              lVar7 = lVar13 * 2;
              lVar13 = lVar13 + 1;
            } while (*(short *)(param_8 + 2 + lVar7) != 0);
            (*_DAT_)(uVar9,2,(int)lVar13 * 2);
            (*_DAT_)(uVar9,2,param_8);
            uVar10 = uVar12;
            do {
              if (puVar14 <= puVar11) goto LAB_;
              uVar10 = uVar10 + 1;
              puVar11 = (uint *)((longlong)puVar11 + (ulonglong)*puVar11);
            } while (uVar10 < 3);
            uStack_190 = 0;
            if (param_5 != 0) {
              psVar17 = (short *)(param_6 + 0x90);
              do {
                for (; uVar12 != (int)*psVar17 - 1U; uVar12 = uVar12 + 1) {
                  if (puVar14 <= puVar11) goto LAB_;
                  puVar11 = (uint *)((longlong)puVar11 + (ulonglong)*puVar11);
                }
                if (((puVar14 <= puVar11) ||
                    (puStack_188 = (uint *)((ulonglong)*puVar11 + (longlong)puVar11),
                    puVar14 < puStack_188)) || (puVar14 <= puVar11 + 1)) goto LAB_;
                bVar2 = *(byte *)(puVar11 + 1);
                if (puVar14 <= (uint *)((longlong)puVar11 + 5U)) goto LAB_;
                uVar10 = *(uint *)((longlong)puVar11 + 5U);
                if (puVar14 <= (uint *)((longlong)puVar11 + 9U)) goto LAB_;
                uVar15 = (ulonglong)*(uint *)((longlong)puVar11 + 9U);
                if (puVar14 <= (uint *)((longlong)puVar11 + 0xdU)) goto LAB_;
                uStack_18c = *(uint *)((longlong)puVar11 + 0xdU);
                puVar11 = (uint *)((longlong)puVar11 + 0x11);
                if ((puVar14 <= puVar11) || (puStack_188 < (uint *)((longlong)puVar11 + uVar15)))
                goto LAB_;
                if (*(int *)(psVar17 + 0x1a) == 0) {
                  *(byte *)(psVar17 + 1) = bVar2;
                  *(uint *)(psVar17 + 2) = uVar10;
                  *(byte *)(psVar17 + 4) = bVar2;
                  *(uint *)(psVar17 + 6) = uVar10;
                  if ((((byte)(bVar2 - 0x37) < 0x34) &&
                      ((0x8000000000101U >> ((ulonglong)(bVar2 - 0x37 & 0xff) & 0x3f) & 1) != 0)) ||
                     (bVar5 = bVar2, bVar2 == 0x6c)) {
                    uVar10 = 0x13;
                    *(undefined4 *)(psVar17 + 2) = 0x13;
                    *(undefined *)(psVar17 + 4) = 0x37;
                    *(undefined4 *)(psVar17 + 6) = 0x13;
                    bVar5 = 0x37;
                  }
                  uStack_1a8 = 0;
                  uStack_1b8 = (uint)bVar5;
                  uStack_1c0 = CONCAT44(uStack_1c0._4_4_,uVar10);
                  uStack_1c8 = (uint)bVar2;
                  uStack_1b0 = uVar10;
                  iVar6 = (*_DAT_)(uStack_198,iVar16,psVar17 + 8,
                                           *(undefined4 *)(psVar17 + 0x18));
                  if (iVar6 != iVar16) goto LAB_;
                  *(undefined4 *)(psVar17 + 0x1a) = 1;
                }
                uVar9 = uStack_198;
                if (uStack_18c == 0) {
                  if (((byte)(bVar2 - 0x37) < 0x36) &&
                     ((0x28000000000101U >> ((ulonglong)(byte)(bVar2 - 0x37) & 0x3f) & 1) != 0)) {
                    if (*(longlong *)(psVar17 + 0x1c) != 0) {
                      func_0x(*(longlong *)(psVar17 + 0x1c),1);
                    }
                    uVar9 = func_0x();
                    *(undefined8 *)(psVar17 + 0x1c) = uVar9;
                    pauVar3 = *(undefined (**) [16])(psVar17 + 0x1c);
                    uStack_1b8 = 0x13;
                    *pauVar3 = ZEXT816(0);
                    *(undefined2 *)pauVar3[1] = 0;
                    pauVar3[1][2] = 0;
                    **(undefined **)(psVar17 + 0x1c) = *(undefined *)(psVar17 + 0x20);
                    *(undefined *)(*(longlong *)(psVar17 + 0x1c) + 1) =
                         *(undefined *)((longlong)psVar17 + 0x41);
                    uStack_1c0 = *(undefined8 *)(psVar17 + 0x1c);
                    uStack_1c8 = 0x37;
                    iVar6 = (*_DAT_)(uStack_198,0xe7,puVar11,uVar15);
                    if (iVar6 == -1) goto LAB_;
                    puVar11 = *(uint **)(psVar17 + 0x1c);
                    uVar15 = 0x13;
                  }
                  uVar9 = uStack_198;
                  iVar6 = (*_DAT_)(uStack_198,iVar16,uVar15);
                  if ((iVar6 != 1) || (iVar6 = (*_DAT_)(uVar9,iVar16,puVar11), iVar6 != 1))
                  goto LAB_;
                }
                else {
                  (*_DAT_)(uStack_198,iVar16,0);
                }
                uVar12 = uVar12 + 1;
                uStack_190 = uStack_190 + 1;
                iVar16 = iVar16 + 1;
                psVar17 = psVar17 + 0x24;
                puVar11 = puStack_188;
              } while (uStack_190 < param_5);
            }
            (*_DAT_)(uVar9);
          }
        }
      }
    }
  }
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_1e8);
  return;
}

