
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 *param_1)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  longlong lVar4;
  uint uVar5;
  ulonglong uVar6;
  
  *param_1 = 0x1451a8;
  lVar4 = param_1[3];
  if ((*(byte *)(param_1 + 1) & 8) == 0) {
    func_0x();
  }
  else if (lVar4 != 0) {
    plVar1 = (longlong *)(lVar4 + -8);
    func_0x(lVar4,0x30,*plVar1,0x10eba0,0xfffffffffffffffe);
    func_0x(plVar1,*plVar1 * 0x30 + 8);
  }
  func_0x(param_1[4]);
  lVar4 = param_1[0xe];
  if (lVar4 != 0) {
    uVar6 = 0;
    lVar3 = lVar4;
    if (*(int *)(param_1 + 0xf) != 0) {
      do {
        puVar2 = *(undefined8 **)(lVar3 + uVar6 * 8);
        if (puVar2 != (undefined8 *)0x0) {
          (**(code **)*puVar2)(puVar2,1);
          lVar3 = param_1[0xe];
          lVar4 = lVar3;
        }
        uVar5 = (int)uVar6 + 1;
        uVar6 = (ulonglong)uVar5;
      } while (uVar5 < *(uint *)(param_1 + 0xf));
    }
    func_0x(lVar4);
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

