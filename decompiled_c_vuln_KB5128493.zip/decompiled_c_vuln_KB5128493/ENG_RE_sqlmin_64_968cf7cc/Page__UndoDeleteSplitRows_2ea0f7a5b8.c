
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,uint param_3,uint param_4)

{
  ushort uVar1;
  undefined auVar2 [16];
  undefined8 uVar3;
  longlong lVar4;
  code *UNRECOVERED_JUMPTABLE;
  undefined *puVar5;
  uint uVar6;
  ulonglong uVar7;
  undefined8 uStack_110;
  undefined auStack_108 [32];
  undefined4 *puStack_e8;
  undefined8 uStack_e0;
  uint uStack_d8;
  uint uStack_d0;
  undefined2 auStack_c8 [2];
  undefined4 uStack_c4;
  byte *pbStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_aa;
  undefined2 uStack_a2;
  undefined2 uStack_a0;
  undefined6 uStack_9e;
  undefined4 uStack_88;
  undefined2 uStack_84;
  uint uStack_78;
  int iStack_74;
  uint uStack_70;
  longlong lStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  longlong lStack_40;
  ulonglong uStack_38;
  
  puVar5 = auStack_108;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_c8;
  uVar7 = (ulonglong)(int)param_3;
  uStack_78 = 0;
  iStack_74 = param_2;
  uStack_70 = param_4;
  if (*(ushort *)(param_1 + 0x1c) < param_4) {
    uStack_88 = *(undefined4 *)(param_1 + 0x20);
    uStack_84 = *(undefined2 *)(param_1 + 0x24);
    uStack_e0 = 0x134e570;
    puStack_e8 = &uStack_88;
    uStack_110 = 0x1000a6;
    uStack_d8 = (uint)*(ushort *)(param_1 + 0x1c);
    uStack_d0 = param_4;
    (*_DAT_)(0xb,0x1b,0x16,0x6d);
  }
  uVar6 = 0;
  if (param_2 == 0) {
    auVar2._8_8_ = 0;
    auVar2._0_8_ = uVar7;
    uVar3 = SUB168(auVar2 * ZEXT816(2),0);
    if (SUB168(auVar2 * ZEXT816(2),8) != 0) {
      uVar3 = 0xffffffffffffffff;
      uStack_110 = 0x1000e4;
      func_0x(0x80070216,2,uVar7);
    }
    uStack_110 = 0x100100;
    lVar4 = func_0x();
    lVar4 = -lVar4;
    puVar5 = auStack_108 + lVar4;
    uVar1 = *(ushort *)(param_1 + 0x16);
    *(undefined8 *)(auStack_108 + lVar4 + -8) = 0x100135;
    func_0x
              ((longlong)auStack_c8 + lVar4,uVar3,
               param_1 + ((longlong)(int)((1 - (uint)uVar1) - param_3) + 0xfff) * 2,uVar7 * 2);
    uVar1 = *(ushort *)(param_1 + 0x16);
    *(undefined8 *)(auStack_108 + lVar4 + -8) = 0x10016d;
    func_0x
              (param_1 + ((longlong)(int)((1 - (uint)uVar1) - param_3) + 0xfff) * 2,
               param_1 + (0x1000 - (longlong)(int)(uint)uVar1) * 2,(uint)uVar1 * 2);
    *(undefined8 *)(auStack_108 + lVar4 + -8) = 0x100191;
    func_0x
              (param_1 + ((longlong)(int)(1 - param_3) + 0xfff) * 2,
               (longlong)(int)(1 - param_3) * 2 + 0x3ffe,(longlong)auStack_c8 + lVar4,uVar7 * 2);
    uVar6 = uStack_78;
    param_2 = iStack_74;
  }
  auStack_c8[0] = 0xffff;
  pbStack_c0 = (byte *)0x0;
  uStack_88 = 0;
  uStack_c4 = 0;
  uStack_aa = 0;
  uStack_a0 = 0;
  uStack_9e = 0;
  uStack_b8 = 0;
  if (0 < (int)param_3) {
    lStack_40 = (longlong)param_2;
    lStack_58 = param_1 + 0x2000;
    if (param_1 == 0) {
      lStack_58 = 0;
    }
    uStack_50 = 0;
    uStack_48 = (ulonglong)*(ushort *)(param_1 + (0xfff - lStack_40) * 2);
    pbStack_c0 = (byte *)(uStack_48 + param_1);
    if ((*(byte *)(uStack_48 + param_1) & 1) != 0) {
      auStack_c8[0] = 1;
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_c0 & 0x1c) + 0x100ca4) *
                              4 + 0x100c94) - 0x1426ab0);
                    /* WARNING: Could not emulate address calculation at 0x00100240 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
    auStack_c8[0] = 0;
    uStack_c4 = 0;
    uStack_a2 = 0;
    uStack_a0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001003be */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_c0 & 0xe) * 4 + 0x100cc4) - 0x1426ab0))
              ();
    return;
  }
  if (uVar6 != param_4) {
    *(undefined8 *)(puVar5 + 0x20) = 0;
    *(undefined8 *)(puVar5 + -8) = 0x100c1e;
    (*_DAT_)(1,0x14d0640,0x149b7e8,0x162d);
  }
  *(short *)(param_1 + 0x16) = *(short *)(param_1 + 0x16) + (short)param_3;
  *(short *)(param_1 + 0x1c) = *(short *)(param_1 + 0x1c) - (short)param_4;
  *(undefined2 *)(param_1 + 0x3a) = *(undefined2 *)(param_1 + 0x3a);
  if (*(char *)(param_1 + 2) < '\0') {
    if ((int)(uint)*(ushort *)(param_1 + 0x61) < (int)(0xffff - (param_3 & 0xffff))) {
      *(ushort *)(param_1 + 0x61) = *(ushort *)(param_1 + 0x61) + (short)param_3;
    }
    else {
      *(undefined2 *)(param_1 + 0x61) = 0xffff;
    }
  }
  uVar7 = uStack_38 ^ (ulonglong)auStack_c8;
  *(undefined8 *)(puVar5 + -8) = 0x100c6b;
  func_0x(uVar7);
  return;
}

