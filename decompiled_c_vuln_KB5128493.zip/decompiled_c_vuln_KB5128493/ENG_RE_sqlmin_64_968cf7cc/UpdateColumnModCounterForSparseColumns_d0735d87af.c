
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong param_3)

{
  longlong *plVar1;
  ushort uVar2;
  short sVar3;
  undefined8 uVar4;
  code *pcVar5;
  undefined *puVar6;
  byte bVar7;
  ushort uVar8;
  uint uVar9;
  int iVar10;
  int iVar11;
  longlong lVar12;
  ulonglong *puVar13;
  longlong lVar14;
  longlong lVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  longlong lVar18;
  ushort uVar19;
  uint uVar20;
  ulonglong uVar21;
  longlong lVar22;
  undefined *puVar23;
  ushort *puVar24;
  ushort *puVar25;
  ulonglong uVar26;
  ulonglong uVar27;
  ushort uVar28;
  uint uVar29;
  byte *pbVar30;
  uint *puVar31;
  longlong lVar32;
  ushort *puVar33;
  ulonglong uVar34;
  longlong lVar35;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_120;
  undefined auStack_118 [32];
  undefined8 auStack_f8 [2];
  uint uStack_e8;
  uint uStack_e4;
  longlong lStack_e0;
  uint auStack_d8 [2];
  longlong lStack_d0;
  uint uStack_c8;
  int iStack_c4;
  ushort *puStack_c0;
  uint uStack_b8;
  longlong lStack_b0;
  longlong *plStack_a8;
  uint uStack_a0;
  undefined4 uStack_9c;
  uint uStack_98;
  uint uStack_94;
  longlong *plStack_90;
  longlong lStack_88;
  longlong *plStack_80;
  longlong lStack_78;
  longlong *plStack_70;
  longlong lStack_68;
  longlong lStack_60;
  longlong lStack_58;
  ushort *puStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_e8;
  lStack_d0 = 0;
  uStack_120 = 0x100051;
  lStack_e0 = param_2;
  lStack_b0 = param_3;
  plStack_a8 = param_1;
  lVar12 = (**(code **)*param_1)();
  uStack_120 = 0x10005c;
  uVar9 = func_0x(lVar12);
  uStack_120 = 0x10006b;
  uStack_b8 = uVar9;
  iVar10 = func_0x(param_2);
  lVar15 = 0;
  puVar6 = auStack_118;
  iStack_c4 = iVar10;
  if ((int)uVar9 < 1) {
LAB_:
    puVar23 = puVar6;
    pcVar5 = *(code **)(*param_1 + 8);
    *(undefined8 *)(puVar23 + -8) = 0x1008eb;
    (*pcVar5)(param_1);
    if (0 < (int)uVar9) goto LAB_;
  }
  else {
    uVar16 = (longlong)(int)uVar9 * 0x20 + 0xf;
    if (uVar16 <= (ulonglong)((longlong)(int)uVar9 * 0x20)) {
      uVar16 = 0xffffffffffffff0;
    }
    uVar16 = uVar16 & 0xfffffffffffffff0;
    uStack_120 = 0x1000a8;
    func_0x();
    lVar22 = -uVar16;
    puVar23 = auStack_118 + lVar22;
    puVar24 = (ushort *)(lVar12 + 2);
    lStack_d0 = (longlong)&uStack_e8 + lVar22;
    puStack_50 = puVar24;
    if (*(int *)(lVar12 + 4) == 0) {
      pbVar30 = *(byte **)(lVar12 + 8);
      uVar20 = *(uint *)(lVar12 + 0x10);
      uVar16 = (ulonglong)uVar20;
      *puVar24 = 0;
      *(uint *)(lVar12 + 0x14) = uVar20;
      bVar7 = *pbVar30;
      if ((bVar7 & 0x10) != 0) {
        uVar20 = uVar20 + 2 + (*(ushort *)(pbVar30 + uVar16) + 7 >> 3);
        uVar16 = (ulonglong)uVar20;
        *(uint *)(lVar12 + 0x14) = uVar20;
        bVar7 = *pbVar30;
      }
      if ((bVar7 & 0x20) == 0) {
        *(int *)(lVar12 + 4) = (int)uVar16;
        *(undefined2 *)(lVar12 + 0x1c) = 0;
        *(int *)(lVar12 + 0x18) = (int)uVar16;
      }
      else {
        puVar33 = (ushort *)(pbVar30 + uVar16);
        uVar8 = *puVar33;
        *(ushort *)(lVar12 + 0x1c) = uVar8;
        if (uVar8 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar15 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar15 != 0)) &&
             ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
              (*(char *)(lVar15 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x10018e;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)((longlong)auStack_f8 + lVar22) = 0;
              *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1001cc;
              (*_DAT_)(1,0xab09f8,0xbd06c8,0x80f);
            }
          }
          uVar4 = *(undefined8 *)(lVar12 + 8);
          *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x10019e;
          func_0x(uVar4,3);
          uVar8 = *(ushort *)(lVar12 + 0x1c);
          uVar16 = (ulonglong)*(uint *)(lVar12 + 0x14);
        }
        uVar20 = (int)uVar16 + (uVar8 + 1) * 2;
        *(uint *)(lVar12 + 0x18) = uVar20;
        if (0x1f9e < uVar20) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar15 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar15 != 0 &&
              ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
               (*(char *)(lVar15 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x100267;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)auStack_f8 + lVar22) = 0;
              *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x10028d;
              (*_DAT_)(1,0xab09f8,0xbd06c8,0x816);
            }
          }
          uVar4 = *(undefined8 *)(lVar12 + 8);
          *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x10029b;
          func_0x(uVar4,4);
          uVar8 = *(ushort *)(lVar12 + 0x1c);
          uVar20 = *(uint *)(lVar12 + 0x18);
        }
        uVar16 = (ulonglong)uVar8;
        uVar8 = puVar33[uVar16];
        *(uint *)(lVar12 + 4) = uVar8 & 0x7fff;
        if ((uVar8 & 0x7fff) < uVar20) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar15 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar15 != 0)) &&
             ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
              (*(char *)(lVar15 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x10033a;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)auStack_f8 + lVar22) = 0;
              *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x100360;
              (*_DAT_)(1,0xab09f8,0xbd06c8,0x81d);
            }
          }
          uVar4 = *(undefined8 *)(lVar12 + 8);
          *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x10036e;
          func_0x(uVar4,4);
          uVar16 = (ulonglong)*(ushort *)(lVar12 + 0x1c);
        }
        if ((short)puVar33[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
          pbVar30 = *(byte **)(lVar12 + 8);
          do {
            if ((int)uVar16 == 1) {
              uVar20 = *(uint *)(lVar12 + 0x18);
              uVar29 = uVar20;
LAB_:
              if ((*(ushort *)(pbVar30 + uVar16 * 2 + (ulonglong)*(uint *)(lVar12 + 0x14)) & 0x7fff)
                  < uVar20) goto LAB_;
            }
            else {
              uVar29 = *(uint *)(lVar12 + 0x18);
              uVar20 = *(ushort *)(pbVar30 + uVar16 * 2 + ((ulonglong)*(uint *)(lVar12 + 0x14) - 2))
                       & 0x7fff;
              if (uVar29 <= uVar20) goto LAB_;
LAB_:
              *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1003d2;
              func_0x(pbVar30,7);
              uVar29 = *(uint *)(lVar12 + 0x18);
            }
            if ((uVar20 < uVar29) || (*(uint *)(lVar12 + 4) < uVar20)) goto LAB_;
            pbVar30 = *(byte **)(lVar12 + 8);
            if (*(ushort *)(pbVar30 + uVar20) == 5) {
              *puVar24 = *puVar24 | 2;
              *(short *)(lVar12 + 0x1c) = *(short *)(lVar12 + 0x1c) + -1;
              uVar8 = *(ushort *)(lVar12 + 0x2c) & 0xc7ff;
              uVar29 = uVar20 & 0xffff;
              *(short *)(lVar12 + 0x2a) = (short)uVar20;
              if ((*(ushort *)(pbVar30 + (ulonglong)uVar29 + 2) >> 0xe & 1) != 0) {
                uVar8 = *(ushort *)(pbVar30 + (ulonglong)uVar29 + 2) & 0x3800 | uVar8;
              }
              *(ushort *)(lVar12 + 0x2c) = uVar8;
              *(ushort *)(lVar12 + 0x2c) =
                   (uVar8 ^ *(ushort *)(pbVar30 + (ulonglong)uVar29 + 2)) & 0x7ff ^ uVar8;
              goto LAB_;
            }
            if (*(ushort *)(pbVar30 + uVar20) < 0x400) goto LAB_;
            *puVar24 = *puVar24 | 1;
            uVar8 = *(short *)(lVar12 + 0x1c) - 1;
            *(ushort *)(lVar12 + 0x1c) = uVar8;
            if (uVar8 == 0) goto LAB_;
            uVar16 = (ulonglong)uVar8;
          } while ((short)puVar33[(ulonglong)(uVar8 - 1) + 1] < 0);
          uVar16 = (ulonglong)*(uint *)(lVar12 + 4);
        }
        else {
LAB_:
          uVar16 = (ulonglong)*(uint *)(lVar12 + 4);
          pbVar30 = *(byte **)(lVar12 + 8);
        }
      }
      iVar11 = 0;
      if ((*pbVar30 & 0x40) == 0) {
        *(undefined4 *)(lVar12 + 0x26) = 0;
      }
      else {
        *(int *)(lVar12 + 0x26) = *(int *)(lVar12 + 4);
        *(int *)(lVar12 + 4) = *(int *)(lVar12 + 4) + 0xe;
        *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1004d4;
        puVar13 = (ulonglong *)func_0x(puVar24);
        uVar19 = (ushort)(*puVar13 >> 0x30);
        uVar8 = uVar19;
        if ((((uint)(int)(short)uVar19 >> 1 ^ (int)(short)uVar19) & 0x2000) != 0) {
          uVar8 = uVar19 & 0xdfff;
          if ((uVar19 >> 0xe & 1) != 0) {
            uVar8 = uVar19 | 0x2000;
          }
        }
        if (uVar8 == 0xfffc) {
          iVar11 = (int)((*puVar13 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(lVar12 + 4) = *(int *)(lVar12 + 4) + iVar11;
        uVar16 = (ulonglong)*(uint *)(lVar12 + 4);
      }
      iVar11 = (int)uVar16;
      if ((*(ulonglong *)(lVar12 + 0x1e) != 0) &&
         (*(ulonglong *)(lVar12 + 0x1e) < uVar16 + *(longlong *)(lVar12 + 8))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar15 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar15 != 0 &&
             (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
            (*(char *)(lVar15 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1005c9;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)((longlong)auStack_f8 + lVar22) = 0;
            *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1005ef;
            (*_DAT_)(1,0xab09f8,0xbd06c8,0x877);
          }
        }
        uVar4 = *(undefined8 *)(lVar12 + 8);
        *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1005fd;
        func_0x(uVar4,0x12);
        iVar11 = *(int *)(lVar12 + 4);
      }
      if (0x3f3b < iVar11 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0 &&
            ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
             (*(char *)(lVar15 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x100689;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            uVar4 = *(undefined8 *)(lVar12 + 8);
            *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x100697;
            func_0x(uVar4,5);
            goto LAB_;
          }
          *(undefined8 *)((longlong)auStack_f8 + lVar22) = 0;
          *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1006bd;
          (*_DAT_)(1,0xab09f8,0xbd06c8,0x87c);
        }
        uVar4 = *(undefined8 *)(lVar12 + 8);
        *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1006cb;
        func_0x(uVar4,5);
      }
    }
LAB_:
    uVar16 = 0;
    *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1006d8;
    iVar11 = func_0x(puVar24);
    lVar15 = lStack_d0;
    puVar6 = auStack_118 + lVar22;
    if (iVar11 == 0) goto LAB_;
    uStack_e8 = *(ushort *)(lVar12 + 0x2c) & 0x7ff;
    uVar20 = uVar9;
    if ((uVar9 <= uStack_e8) || (uVar20 = uStack_e8, (*(ushort *)(lVar12 + 0x2c) & 0x7ff) != 0)) {
      lVar32 = *(longlong *)(lVar12 + 8);
      uVar26 = (ulonglong)*(ushort *)(lVar12 + 0x2a);
      lVar18 = uVar26 + lVar32;
      uVar29 = *(ushort *)(lVar12 + 0x2c) >> 0xb & 7;
      puVar33 = (ushort *)(lVar18 + 4);
      uVar9 = (*(ushort *)(lVar12 + 0x2c) & 0x7ff) * 2;
      uVar17 = (ulonglong)(uVar29 * 2);
      lVar14 = lVar32 + 4 + uVar26 + uVar17;
      lVar35 = uVar17 + 4 + uVar9 + uVar26 + lVar32;
      uVar29 = (((uint)*(ushort *)(lVar12 + 0x2a) + (uVar29 + 2 + uVar9) * 2) - (int)lVar18) +
               (int)lVar32;
      lVar12 = 0;
      do {
        if ((puVar24[0x15] & 0x3800) == 0) {
          uVar8 = *(ushort *)((ulonglong)puVar24[0x14] + 2 + *(longlong *)(puVar24 + 3));
          uVar19 = puVar24[0x15];
        }
        else {
          uVar8 = *puVar33;
          uVar19 = uVar8;
        }
        lVar32 = ((ulonglong)uVar19 & 0x7ff) - 1;
        if (lVar12 <= lVar32) {
          puVar25 = (ushort *)(lVar35 + lVar12 * 2);
          puVar31 = (uint *)(lStack_d0 + 0xc + lVar12 * 0x20);
          uVar17 = uVar16;
          uVar19 = uStack_9c._2_2_;
          do {
            puVar24 = puStack_50;
            uVar16 = uVar17;
            if ((longlong)(ulonglong)uVar20 <= lVar12) break;
            lVar12 = lVar12 + 1;
            uVar9 = (uint)*(ushort *)((lVar14 - lVar35) + (longlong)puVar25) +
                    (uint)(uVar8 >> 0xb & 7) * 0x10000 | 0x80000000;
            uVar28 = *puVar25;
            uVar16 = (ulonglong)((int)uVar17 + 1);
            uStack_9c = (uVar19 & 0xfff0) << 0x10;
            uVar2 = *(ushort *)(lVar35 + uVar17 * 2);
            *(ulonglong *)(puVar31 + -3) = (ulonglong)uVar29 + lVar18;
            puVar31[-1] = (uVar28 & 0x7fff) - uVar29;
            *puVar31 = (uint)(uVar2 >> 0xf) | *puVar31 & 0xfffffff0;
            puVar31[1] = uVar9;
            puVar31[2] = uStack_9c;
            puVar31[3] = uStack_98;
            puVar31[4] = uStack_94;
            puVar31 = puVar31 + 8;
            uVar29 = *puVar25 & 0x7fff;
            puVar25 = puVar25 + 1;
            uVar17 = uVar16;
            uVar19 = uVar19 & 0xfff0;
            uStack_a0 = uVar9;
          } while (lVar12 <= lVar32);
        }
        puVar33 = puVar33 + 1;
        param_1 = plStack_a8;
        iVar10 = iStack_c4;
        uVar9 = uStack_b8;
        uStack_e8 = uVar20;
        puStack_c0 = puVar33;
        lStack_60 = lVar14;
        lStack_58 = lVar18;
      } while (lVar12 < (longlong)(ulonglong)uVar20);
    }
    puVar6 = auStack_118 + lVar22;
    if ((int)uVar9 <= (int)uStack_e8) goto LAB_;
    uVar20 = uVar9 - uStack_e8;
    lVar12 = (longlong)(int)uStack_e8 * 0x20 + lStack_d0;
    *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1008d3;
    func_0x(lVar12,0,(ulonglong)uVar20 << 5);
    pcVar5 = *(code **)(*param_1 + 8);
    *(undefined8 *)(auStack_118 + lVar22 + -8) = 0x1008dc;
    (*pcVar5)(param_1);
LAB_:
    uStack_e4 = *(uint *)(lVar15 + 0x10) & 0x1fffffff;
  }
  lVar15 = lStack_e0;
  uStack_e8 = 0;
  uVar16 = 0;
  if (0 < iVar10) {
    if (*(int *)(lStack_e0 + 4) == 0) {
      pbVar30 = *(byte **)(lStack_e0 + 8);
      uVar20 = *(uint *)(lStack_e0 + 0x10);
      uVar17 = (ulonglong)uVar20;
      *(undefined2 *)(lStack_e0 + 2) = 0;
      *(uint *)(lStack_e0 + 0x14) = uVar20;
      bVar7 = *pbVar30;
      if ((bVar7 & 0x10) != 0) {
        uVar20 = uVar20 + 2 + (*(ushort *)(pbVar30 + uVar17) + 7 >> 3);
        uVar17 = (ulonglong)uVar20;
        *(uint *)(lStack_e0 + 0x14) = uVar20;
        bVar7 = *pbVar30;
      }
      if ((bVar7 & 0x20) == 0) {
        *(int *)(lStack_e0 + 4) = (int)uVar17;
        *(undefined2 *)(lStack_e0 + 0x1c) = 0;
        *(int *)(lStack_e0 + 0x18) = (int)uVar17;
      }
      else {
        puVar24 = (ushort *)(pbVar30 + uVar17);
        uVar8 = *puVar24;
        *(ushort *)(lStack_e0 + 0x1c) = uVar8;
        if (uVar8 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar23 + -8) = 0x1009e9;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar23 + 0x20) = 0;
              *(undefined8 *)(puVar23 + -8) = 0x100a0f;
              (*_DAT_)(1,0xab09f8,0xbd06c8,0x80f);
            }
          }
          uVar4 = *(undefined8 *)(lVar15 + 8);
          *(undefined8 *)(puVar23 + -8) = 0x100a1d;
          func_0x(uVar4,3);
          uVar8 = *(ushort *)(lVar15 + 0x1c);
          uVar17 = (ulonglong)*(uint *)(lVar15 + 0x14);
        }
        uVar20 = (int)uVar17 + (uVar8 + 1) * 2;
        *(uint *)(lVar15 + 0x18) = uVar20;
        if (0x1f9e < uVar20) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar12 != 0 &&
              ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
               (*(char *)(lVar12 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar23 + -8) = 0x100abd;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar23 + 0x20) = 0;
              *(undefined8 *)(puVar23 + -8) = 0x100ae3;
              (*_DAT_)(1,0xab09f8,0xbd06c8,0x816);
            }
          }
          uVar4 = *(undefined8 *)(lVar15 + 8);
          *(undefined8 *)(puVar23 + -8) = 0x100af1;
          func_0x(uVar4,4);
          uVar8 = *(ushort *)(lVar15 + 0x1c);
          uVar20 = *(uint *)(lVar15 + 0x18);
        }
        uVar17 = (ulonglong)uVar8;
        uVar8 = puVar24[uVar17];
        *(uint *)(lVar15 + 4) = uVar8 & 0x7fff;
        if ((uVar8 & 0x7fff) < uVar20) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar23 + -8) = 0x100b90;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar23 + 0x20) = 0;
              *(undefined8 *)(puVar23 + -8) = 0x100bb6;
              (*_DAT_)(1,0xab09f8,0xbd06c8,0x81d);
            }
          }
          uVar4 = *(undefined8 *)(lVar15 + 8);
          *(undefined8 *)(puVar23 + -8) = 0x100bc4;
          func_0x(uVar4,4);
          uVar17 = (ulonglong)*(ushort *)(lVar15 + 0x1c);
        }
        if ((short)puVar24[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
          pbVar30 = *(byte **)(lVar15 + 8);
          do {
            if ((int)uVar17 == 1) {
              uVar20 = *(uint *)(lVar15 + 0x18);
              uVar29 = uVar20;
LAB_:
              if ((*(ushort *)(pbVar30 + uVar17 * 2 + (ulonglong)*(uint *)(lVar15 + 0x14)) & 0x7fff)
                  < uVar20) goto LAB_;
            }
            else {
              uVar29 = *(uint *)(lVar15 + 0x18);
              uVar20 = *(ushort *)(pbVar30 + uVar17 * 2 + ((ulonglong)*(uint *)(lVar15 + 0x14) - 2))
                       & 0x7fff;
              if (uVar29 <= uVar20) goto LAB_;
LAB_:
              *(undefined8 *)(puVar23 + -8) = 0x100c25;
              func_0x(pbVar30,7);
              uVar29 = *(uint *)(lVar15 + 0x18);
            }
            if ((uVar20 < uVar29) || (*(uint *)(lVar15 + 4) < uVar20)) goto LAB_;
            pbVar30 = *(byte **)(lVar15 + 8);
            if (*(ushort *)(pbVar30 + uVar20) == 5) {
              *(ushort *)(lVar15 + 2) = *(ushort *)(lVar15 + 2) | 2;
              *(short *)(lVar15 + 0x1c) = *(short *)(lVar15 + 0x1c) + -1;
              uVar8 = *(ushort *)(lVar15 + 0x2c) & 0xc7ff;
              uVar29 = uVar20 & 0xffff;
              *(short *)(lVar15 + 0x2a) = (short)uVar20;
              if ((*(ushort *)(pbVar30 + (ulonglong)uVar29 + 2) >> 0xe & 1) != 0) {
                uVar8 = *(ushort *)(pbVar30 + (ulonglong)uVar29 + 2) & 0x3800 | uVar8;
              }
              *(ushort *)(lVar15 + 0x2c) = uVar8;
              *(ushort *)(lVar15 + 0x2c) =
                   (uVar8 ^ *(ushort *)(pbVar30 + (ulonglong)uVar29 + 2)) & 0x7ff ^ uVar8;
              goto LAB_;
            }
            if (*(ushort *)(pbVar30 + uVar20) < 0x400) goto LAB_;
            *(ushort *)(lVar15 + 2) = *(ushort *)(lVar15 + 2) | 1;
            uVar8 = *(short *)(lVar15 + 0x1c) - 1;
            *(ushort *)(lVar15 + 0x1c) = uVar8;
            if (uVar8 == 0) goto LAB_;
            uVar17 = (ulonglong)uVar8;
          } while ((short)puVar24[(ulonglong)(uVar8 - 1) + 1] < 0);
          uVar17 = (ulonglong)*(uint *)(lVar15 + 4);
        }
        else {
LAB_:
          uVar17 = (ulonglong)*(uint *)(lVar15 + 4);
          pbVar30 = *(byte **)(lVar15 + 8);
        }
      }
      iVar11 = 0;
      if ((*pbVar30 & 0x40) == 0) {
        *(undefined4 *)(lVar15 + 0x26) = 0;
      }
      else {
        *(int *)(lVar15 + 0x26) = *(int *)(lVar15 + 4);
        *(int *)(lVar15 + 4) = *(int *)(lVar15 + 4) + 0xe;
        *(undefined8 *)(puVar23 + -8) = 0x100d2e;
        puVar13 = (ulonglong *)func_0x(lVar15 + 2);
        uVar19 = (ushort)(*puVar13 >> 0x30);
        uVar8 = uVar19;
        if ((((uint)(int)(short)uVar19 >> 1 ^ (int)(short)uVar19) & 0x2000) != 0) {
          uVar8 = uVar19 & 0xdfff;
          if ((uVar19 >> 0xe & 1) != 0) {
            uVar8 = uVar19 | 0x2000;
          }
        }
        if (uVar8 == 0xfffc) {
          iVar11 = (int)((*puVar13 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(lVar15 + 4) = *(int *)(lVar15 + 4) + iVar11;
        uVar17 = (ulonglong)*(uint *)(lVar15 + 4);
      }
      iVar11 = (int)uVar17;
      if ((*(ulonglong *)(lVar15 + 0x1e) != 0) &&
         (*(ulonglong *)(lVar15 + 0x1e) < uVar17 + *(longlong *)(lVar15 + 8))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar12 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar12 != 0 &&
             (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar23 + -8) = 0x100e2c;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar23 + 0x20) = 0;
            *(undefined8 *)(puVar23 + -8) = 0x100e52;
            (*_DAT_)(1,0xab09f8,0xbd06c8,0x877);
          }
        }
        uVar4 = *(undefined8 *)(lVar15 + 8);
        *(undefined8 *)(puVar23 + -8) = 0x100e60;
        func_0x(uVar4,0x12);
        iVar11 = *(int *)(lVar15 + 4);
      }
      if (0x3f3b < iVar11 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar12 != 0 &&
            ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
             (*(char *)(lVar12 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar23 + -8) = 0x100eed;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            uVar4 = *(undefined8 *)(lVar15 + 8);
            *(undefined8 *)(puVar23 + -8) = 0x100efb;
            func_0x(uVar4,5);
            goto LAB_;
          }
          *(undefined8 *)(puVar23 + 0x20) = 0;
          *(undefined8 *)(puVar23 + -8) = 0x100f21;
          (*_DAT_)(1,0xab09f8,0xbd06c8,0x87c);
        }
        uVar4 = *(undefined8 *)(lVar15 + 8);
        *(undefined8 *)(puVar23 + -8) = 0x100f2f;
        func_0x(uVar4,5);
      }
    }
LAB_:
    *(undefined8 *)(puVar23 + -8) = 0x100f3c;
    iVar11 = func_0x(lVar15 + 2);
    if (iVar11 == 0) {
      *(undefined8 *)(puVar23 + -8) = 0x101024;
      iVar11 = func_0x(lVar15 + 2);
      if (iVar11 == 0) {
        *(undefined8 *)(puVar23 + 0x20) = 0;
        *(undefined8 *)(puVar23 + -8) = 0x10104a;
        (*_DAT_)(1,0xc6c078,0xc5d168,0xd67);
      }
    }
    else {
      uVar8 = 0;
      if ((*(ushort *)(lVar15 + 0x2c) & 0x7ff) == 0) {
        *(undefined8 *)(puVar23 + 0x20) = 0;
        *(undefined8 *)(puVar23 + -8) = 0x101016;
        (*_DAT_)(1,0xc6c048,0xc6c090,0x3c6);
      }
      else {
        uVar17 = (ulonglong)*(ushort *)(lVar15 + 0x2a);
        lVar12 = *(longlong *)(lVar15 + 8);
        if ((*(ushort *)(lVar15 + 0x2c) & 0x3800) == 0) {
          uVar28 = *(ushort *)(lVar12 + 2 + uVar17);
LAB_:
          uVar8 = uVar28 >> 0xb & 7;
        }
        else {
          uVar19 = *(ushort *)(lVar15 + 0x2c) >> 0xb;
          if ((uVar19 & 7) != 0) {
            lVar22 = 0;
            do {
              if (((lVar22 == 0) || ((*(ushort *)(lVar12 + uVar17 + 2 + lVar22 * 2) & 0x7ff) == 0))
                 && (uVar28 = *(ushort *)(lVar12 + uVar17 + 4 + lVar22 * 2),
                    -1 < (int)((uVar28 & 0x7ff) - 1))) goto LAB_;
              lVar22 = lVar22 + 1;
            } while (lVar22 < (longlong)(ulonglong)(uVar19 & 7));
          }
        }
        auStack_d8[0] =
             (uint)*(ushort *)
                    ((ulonglong)((*(ushort *)(lVar15 + 0x2c) >> 0xb & 7) * 2) + lVar12 + 4 + uVar17)
             + (uint)uVar8 * 0x10000;
      }
    }
  }
  lVar15 = (longlong)(int)uVar9;
  uVar26 = 0;
  puStack_c0 = (ushort *)(longlong)iVar10;
  iVar10 = 0;
  uVar17 = uVar26;
  if (0 < lVar15) {
    do {
      lVar12 = lStack_e0;
      iVar10 = (int)uVar26;
      if ((longlong)puStack_c0 <= (longlong)uVar17) break;
      if (uStack_e4 < auStack_d8[0]) {
        uVar26 = (ulonglong)(iVar10 + 1);
        uStack_c8 = uStack_e4;
        uVar16 = uVar16 + 1;
        uVar34 = uVar17;
        if ((longlong)uVar16 < lVar15) {
          uStack_e4 = *(uint *)(uVar16 * 0x20 + 0x10 + lStack_d0) & 0x1fffffff;
        }
      }
      else {
        uStack_c8 = auStack_d8[0];
        if (auStack_d8[0] < uStack_e4) {
          uStack_e8 = uStack_e8 + 1;
          uVar34 = uVar17 + 1;
          if ((longlong)uVar34 < (longlong)puStack_c0) {
            puVar24 = (ushort *)(lStack_e0 + 2);
            if (*(int *)(lStack_e0 + 4) == 0) {
              pbVar30 = *(byte **)(lStack_e0 + 8);
              uVar9 = *(uint *)(lStack_e0 + 0x10);
              uVar21 = (ulonglong)uVar9;
              *puVar24 = 0;
              *(uint *)(lStack_e0 + 0x14) = uVar9;
              bVar7 = *pbVar30;
              if ((bVar7 & 0x10) != 0) {
                uVar9 = uVar9 + 2 + (*(ushort *)(pbVar30 + uVar21) + 7 >> 3);
                uVar21 = (ulonglong)uVar9;
                *(uint *)(lStack_e0 + 0x14) = uVar9;
                bVar7 = *pbVar30;
              }
              if ((bVar7 & 0x20) == 0) {
                *(int *)(lStack_e0 + 4) = (int)uVar21;
                *(undefined2 *)(lStack_e0 + 0x1c) = 0;
                *(int *)(lStack_e0 + 0x18) = (int)uVar21;
              }
              else {
                puVar33 = (ushort *)(pbVar30 + uVar21);
                uVar8 = *puVar33;
                *(ushort *)(lStack_e0 + 0x1c) = uVar8;
                if (uVar8 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0)) &&
                     ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                      (*(char *)(lVar22 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar23 + -8) = 0x10126a;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x101290;
                      (*_DAT_)(1,0xab09f8,0xbd06c8,0x80f);
                    }
                  }
                  uVar4 = *(undefined8 *)(lVar12 + 8);
                  *(undefined8 *)(puVar23 + -8) = 0x10129e;
                  func_0x(uVar4,3);
                  uVar21 = (ulonglong)*(uint *)(lVar12 + 0x14);
                  uVar8 = *(ushort *)(lVar12 + 0x1c);
                }
                uVar9 = (int)uVar21 + (uVar8 + 1) * 2;
                *(uint *)(lVar12 + 0x18) = uVar9;
                if (0x1f9e < uVar9) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0 &&
                      ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                       (*(char *)(lVar22 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar23 + -8) = 0x101341;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x101367;
                      (*_DAT_)(1,0xab09f8,0xbd06c8,0x816);
                    }
                  }
                  uVar4 = *(undefined8 *)(lVar12 + 8);
                  *(undefined8 *)(puVar23 + -8) = 0x101375;
                  func_0x(uVar4,4);
                  uVar9 = *(uint *)(lVar12 + 0x18);
                  uVar8 = *(ushort *)(lStack_e0 + 0x1c);
                }
                uVar21 = (ulonglong)uVar8;
                uVar8 = puVar33[uVar21];
                *(uint *)(lVar12 + 4) = uVar8 & 0x7fff;
                if ((uVar8 & 0x7fff) < uVar9) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0)) &&
                     ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                      (*(char *)(lVar22 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar23 + -8) = 0x101417;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x10143d;
                      (*_DAT_)(1,0xab09f8,0xbd06c8,0x81d);
                    }
                  }
                  uVar4 = *(undefined8 *)(lVar12 + 8);
                  *(undefined8 *)(puVar23 + -8) = 0x10144b;
                  func_0x(uVar4,4);
                  uVar21 = (ulonglong)*(ushort *)(lStack_e0 + 0x1c);
                }
                lVar22 = lStack_e0;
                if ((short)puVar33[(ulonglong)((int)uVar21 - 1) + 1] < 0) {
                  pbVar30 = *(byte **)(lVar12 + 8);
                  do {
                    if ((int)uVar21 == 1) {
                      uVar9 = *(uint *)(lVar12 + 0x18);
                      uVar27 = (ulonglong)uVar9;
LAB_:
                      if ((*(ushort *)(pbVar30 + uVar21 * 2 + (ulonglong)*(uint *)(lVar12 + 0x14)) &
                          0x7fff) < (uint)uVar27) goto LAB_;
                    }
                    else {
                      uVar9 = *(uint *)(lVar22 + 0x18);
                      uVar27 = (ulonglong)
                               (*(ushort *)
                                 (pbVar30 + uVar21 * 2 + ((ulonglong)*(uint *)(lVar12 + 0x14) - 2))
                               & 0x7fff);
                      if (uVar9 <= (*(ushort *)
                                     (pbVar30 +
                                     uVar21 * 2 + ((ulonglong)*(uint *)(lVar12 + 0x14) - 2)) &
                                   0x7fff)) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar23 + -8) = 0x1014b3;
                      func_0x(pbVar30,7);
                      uVar9 = *(uint *)(lStack_e0 + 0x18);
                      lVar22 = lStack_e0;
                    }
                    if (((uint)uVar27 < uVar9) || (*(uint *)(lVar12 + 4) < (uint)uVar27))
                    goto LAB_;
                    pbVar30 = *(byte **)(lVar12 + 8);
                    if (*(ushort *)(pbVar30 + uVar27) == 5) {
                      *puVar24 = *puVar24 | 2;
                      *(short *)(lVar12 + 0x1c) = *(short *)(lVar12 + 0x1c) + -1;
                      uVar8 = *(ushort *)(lVar12 + 0x2c) & 0xc7ff;
                      uVar21 = uVar27 & 0xffff;
                      *(short *)(lVar12 + 0x2a) = (short)uVar27;
                      if ((*(ushort *)(pbVar30 + uVar21 + 2) >> 0xe & 1) != 0) {
                        uVar8 = *(ushort *)(pbVar30 + uVar21 + 2) & 0x3800 | uVar8;
                      }
                      *(ushort *)(lVar12 + 0x2c) = uVar8;
                      *(ushort *)(lVar12 + 0x2c) =
                           (uVar8 ^ *(ushort *)(pbVar30 + uVar21 + 2)) & 0x7ff ^ uVar8;
                      goto LAB_;
                    }
                    if (*(ushort *)(pbVar30 + uVar27) < 0x400) goto LAB_;
                    sVar3 = *(short *)(lVar12 + 0x1c);
                    *puVar24 = *puVar24 | 1;
                    uVar8 = sVar3 - 1;
                    *(ushort *)(lVar12 + 0x1c) = uVar8;
                    if (uVar8 == 0) goto LAB_;
                    uVar21 = (ulonglong)uVar8;
                  } while ((short)puVar33[(ulonglong)(uVar8 - 1) + 1] < 0);
                  uVar21 = (ulonglong)*(uint *)(lVar22 + 4);
                }
                else {
LAB_:
                  uVar21 = (ulonglong)*(uint *)(lVar22 + 4);
                  pbVar30 = *(byte **)(lVar12 + 8);
                }
              }
              iVar10 = 0;
              if ((*pbVar30 & 0x40) == 0) {
                *(undefined4 *)(lVar12 + 0x26) = 0;
              }
              else {
                *(int *)(lVar12 + 0x26) = *(int *)(lVar12 + 4);
                *(int *)(lVar12 + 4) = *(int *)(lVar12 + 4) + 0xe;
                *(undefined8 *)(puVar23 + -8) = 0x1015aa;
                puVar13 = (ulonglong *)func_0x(puVar24);
                uVar19 = (ushort)(*puVar13 >> 0x30);
                uVar8 = uVar19;
                if ((((uint)(int)(short)uVar19 >> 1 ^ (int)(short)uVar19) & 0x2000) != 0) {
                  uVar8 = uVar19 & 0xdfff;
                  if ((uVar19 >> 0xe & 1) != 0) {
                    uVar8 = uVar19 | 0x2000;
                  }
                }
                if (uVar8 == 0xfffc) {
                  iVar10 = (int)((*puVar13 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(lVar12 + 4) = *(int *)(lVar12 + 4) + iVar10;
                uVar21 = (ulonglong)*(uint *)(lVar12 + 4);
              }
              iVar10 = (int)uVar21;
              if ((*(ulonglong *)(lVar12 + 0x1e) != 0) &&
                 (*(ulonglong *)(lVar12 + 0x1e) < uVar21 + *(longlong *)(lVar12 + 8))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar22 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                     lVar22 != 0 && (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
                    (*(char *)(lVar22 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar23 + -8) = 0x1016a6;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar23 + 0x20) = 0;
                    *(undefined8 *)(puVar23 + -8) = 0x1016cc;
                    (*_DAT_)(1,0xab09f8,0xbd06c8,0x877);
                  }
                }
                uVar4 = *(undefined8 *)(lVar12 + 8);
                *(undefined8 *)(puVar23 + -8) = 0x1016da;
                func_0x(uVar4,0x12);
                iVar10 = *(int *)(lStack_e0 + 4);
              }
              if (0x3f3b < iVar10 - 1U) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar22 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar22 != 0 &&
                    ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                     (*(char *)(lVar22 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar23 + -8) = 0x10176c;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar23 + 0x20) = 0;
                    *(undefined8 *)(puVar23 + -8) = 0x101792;
                    (*_DAT_)(1,0xab09f8,0xbd06c8,0x87c);
                  }
                }
                uVar4 = *(undefined8 *)(lVar12 + 8);
                *(undefined8 *)(puVar23 + -8) = 0x1017a0;
                func_0x(uVar4,5);
              }
            }
LAB_:
            *(undefined8 *)(puVar23 + -8) = 0x1017a8;
            iVar10 = func_0x(puVar24);
            if (iVar10 == 0) {
              *(undefined8 *)(puVar23 + -8) = 0x1018b2;
              iVar10 = func_0x(puVar24);
              if (iVar10 == 0) {
                *(undefined8 *)(puVar23 + 0x20) = 0;
                *(undefined8 *)(puVar23 + -8) = 0x1018de;
                (*_DAT_)(1,0xc6c078,0xc5d168,0xd67);
              }
            }
            else if (((longlong)uVar34 < 0) ||
                    ((int)(*(ushort *)(lVar12 + 0x2c) & 0x7ff) <= (int)uStack_e8)) {
              *(undefined8 *)(puVar23 + 0x20) = 0;
              *(undefined8 *)(puVar23 + -8) = 0x1018a2;
              (*_DAT_)(1,0xc6c048,0xc6c090,0x3c6);
            }
            else {
              lVar18 = 0;
              uVar8 = 0;
              uVar21 = (ulonglong)*(ushort *)(lVar12 + 0x2a);
              lVar22 = *(longlong *)(lVar12 + 8);
              if ((*(ushort *)(lVar12 + 0x2c) & 0x3800) == 0) {
                uVar19 = *(ushort *)(lVar22 + 2 + uVar21);
LAB_:
                uVar8 = uVar19 >> 0xb & 7;
              }
              else {
                uVar28 = *(ushort *)(lVar12 + 0x2c) >> 0xb;
                if ((uVar28 & 7) != 0) {
                  do {
                    uVar9 = 0;
                    if (lVar18 != 0) {
                      uVar9 = *(ushort *)(lVar22 + uVar21 + 2 + lVar18 * 2) & 0x7ff;
                    }
                    if (((int)uVar9 <= (int)uStack_e8) &&
                       (uVar19 = *(ushort *)(lVar22 + uVar21 + 4 + lVar18 * 2),
                       (int)uStack_e8 <= (int)((uVar19 & 0x7ff) - 1))) goto LAB_;
                    lVar18 = lVar18 + 1;
                  } while (lVar18 < (longlong)(ulonglong)(uVar28 & 7));
                }
              }
LAB_:
              uVar34 = uVar17 + 1;
              auStack_d8[0] =
                   (uint)*(ushort *)
                          ((ulonglong)((*(ushort *)(lVar12 + 0x2c) >> 0xb & 7) * 2) + lVar22 +
                           uVar34 * 2 + 4 + uVar21) + (uint)uVar8 * 0x10000;
            }
          }
        }
        else {
          uVar26 = (ulonglong)(iVar10 + 1);
          uVar16 = uVar16 + 1;
          uStack_c8 = uStack_e4;
          if ((longlong)uVar16 < lVar15) {
            uStack_e4 = *(uint *)(uVar16 * 0x20 + 0x10 + lStack_d0) & 0x1fffffff;
          }
          uStack_e8 = uStack_e8 + 1;
          uVar34 = uVar17 + 1;
          if ((longlong)uVar34 < (longlong)puStack_c0) {
            puVar24 = (ushort *)(lStack_e0 + 2);
            if (*(int *)(lStack_e0 + 4) == 0) {
              pbVar30 = *(byte **)(lStack_e0 + 8);
              uVar9 = *(uint *)(lStack_e0 + 0x10);
              uVar21 = (ulonglong)uVar9;
              *puVar24 = 0;
              *(uint *)(lStack_e0 + 0x14) = uVar9;
              bVar7 = *pbVar30;
              if ((bVar7 & 0x10) != 0) {
                uVar9 = uVar9 + 2 + (*(ushort *)(pbVar30 + uVar21) + 7 >> 3);
                uVar21 = (ulonglong)uVar9;
                *(uint *)(lStack_e0 + 0x14) = uVar9;
                bVar7 = *pbVar30;
              }
              if ((bVar7 & 0x20) == 0) {
                *(int *)(lStack_e0 + 4) = (int)uVar21;
                *(undefined2 *)(lStack_e0 + 0x1c) = 0;
                *(int *)(lStack_e0 + 0x18) = (int)uVar21;
              }
              else {
                puVar33 = (ushort *)(pbVar30 + uVar21);
                uVar8 = *puVar33;
                *(ushort *)(lStack_e0 + 0x1c) = uVar8;
                if (uVar8 == 0) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0 &&
                      ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                       (*(char *)(lVar22 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar23 + -8) = 0x1019f4;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x101a1a;
                      (*_DAT_)(1,0xab09f8,0xbd06c8,0x80f);
                    }
                  }
                  uVar4 = *(undefined8 *)(lVar12 + 8);
                  *(undefined8 *)(puVar23 + -8) = 0x101a28;
                  func_0x(uVar4,3);
                  uVar21 = (ulonglong)*(uint *)(lVar12 + 0x14);
                  uVar8 = *(ushort *)(lVar12 + 0x1c);
                }
                uVar9 = (int)uVar21 + (uVar8 + 1) * 2;
                *(uint *)(lVar12 + 0x18) = uVar9;
                if (0x1f9e < uVar9) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0)) &&
                     ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                      (*(char *)(lVar22 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar23 + -8) = 0x101acb;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x101af1;
                      (*_DAT_)(1,0xab09f8,0xbd06c8,0x816);
                    }
                  }
                  uVar4 = *(undefined8 *)(lVar12 + 8);
                  *(undefined8 *)(puVar23 + -8) = 0x101aff;
                  func_0x(uVar4,4);
                  uVar9 = *(uint *)(lVar12 + 0x18);
                  uVar8 = *(ushort *)(lStack_e0 + 0x1c);
                }
                uVar21 = (ulonglong)uVar8;
                uVar8 = puVar33[uVar21];
                *(uint *)(lVar12 + 4) = uVar8 & 0x7fff;
                if ((uVar8 & 0x7fff) < uVar9) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0 &&
                      ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                       (*(char *)(lVar22 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar23 + -8) = 0x101ba1;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x101bc7;
                      (*_DAT_)(1,0xab09f8,0xbd06c8,0x81d);
                    }
                  }
                  uVar4 = *(undefined8 *)(lVar12 + 8);
                  *(undefined8 *)(puVar23 + -8) = 0x101bd5;
                  func_0x(uVar4,4);
                  uVar21 = (ulonglong)*(ushort *)(lStack_e0 + 0x1c);
                }
                lVar22 = lStack_e0;
                if ((short)puVar33[(ulonglong)((int)uVar21 - 1) + 1] < 0) {
                  pbVar30 = *(byte **)(lVar12 + 8);
                  do {
                    if ((int)uVar21 == 1) {
                      uVar9 = *(uint *)(lVar12 + 0x18);
                      uVar27 = (ulonglong)uVar9;
LAB_:
                      if ((*(ushort *)(pbVar30 + uVar21 * 2 + (ulonglong)*(uint *)(lVar12 + 0x14)) &
                          0x7fff) < (uint)uVar27) goto LAB_;
                    }
                    else {
                      uVar9 = *(uint *)(lVar22 + 0x18);
                      uVar27 = (ulonglong)
                               (*(ushort *)
                                 (pbVar30 + uVar21 * 2 + ((ulonglong)*(uint *)(lVar12 + 0x14) - 2))
                               & 0x7fff);
                      if (uVar9 <= (*(ushort *)
                                     (pbVar30 +
                                     uVar21 * 2 + ((ulonglong)*(uint *)(lVar12 + 0x14) - 2)) &
                                   0x7fff)) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar23 + -8) = 0x101c43;
                      func_0x(pbVar30,7);
                      uVar9 = *(uint *)(lStack_e0 + 0x18);
                      lVar22 = lStack_e0;
                    }
                    if (((uint)uVar27 < uVar9) || (*(uint *)(lVar12 + 4) < (uint)uVar27))
                    goto LAB_;
                    pbVar30 = *(byte **)(lVar12 + 8);
                    if (*(ushort *)(pbVar30 + uVar27) == 5) {
                      *puVar24 = *puVar24 | 2;
                      *(short *)(lVar12 + 0x1c) = *(short *)(lVar12 + 0x1c) + -1;
                      uVar8 = *(ushort *)(lVar12 + 0x2c) & 0xc7ff;
                      uVar21 = uVar27 & 0xffff;
                      *(short *)(lVar12 + 0x2a) = (short)uVar27;
                      if ((*(ushort *)(pbVar30 + uVar21 + 2) >> 0xe & 1) != 0) {
                        uVar8 = *(ushort *)(pbVar30 + uVar21 + 2) & 0x3800 | uVar8;
                      }
                      *(ushort *)(lVar12 + 0x2c) = uVar8;
                      *(ushort *)(lVar12 + 0x2c) =
                           (uVar8 ^ *(ushort *)(pbVar30 + uVar21 + 2)) & 0x7ff ^ uVar8;
                      goto LAB_;
                    }
                    if (*(ushort *)(pbVar30 + uVar27) < 0x400) goto LAB_;
                    sVar3 = *(short *)(lVar12 + 0x1c);
                    *puVar24 = *puVar24 | 1;
                    uVar8 = sVar3 - 1;
                    *(ushort *)(lVar12 + 0x1c) = uVar8;
                    if (uVar8 == 0) goto LAB_;
                    uVar21 = (ulonglong)uVar8;
                  } while ((short)puVar33[(ulonglong)(uVar8 - 1) + 1] < 0);
                  uVar21 = (ulonglong)*(uint *)(lVar22 + 4);
                }
                else {
LAB_:
                  uVar21 = (ulonglong)*(uint *)(lVar22 + 4);
                  pbVar30 = *(byte **)(lVar12 + 8);
                }
              }
              iVar10 = 0;
              if ((*pbVar30 & 0x40) == 0) {
                *(undefined4 *)(lVar12 + 0x26) = 0;
              }
              else {
                *(int *)(lVar12 + 0x26) = *(int *)(lVar12 + 4);
                *(int *)(lVar12 + 4) = *(int *)(lVar12 + 4) + 0xe;
                *(undefined8 *)(puVar23 + -8) = 0x101d3a;
                puVar13 = (ulonglong *)func_0x(puVar24);
                uVar19 = (ushort)(*puVar13 >> 0x30);
                uVar8 = uVar19;
                if ((((uint)(int)(short)uVar19 >> 1 ^ (int)(short)uVar19) & 0x2000) != 0) {
                  uVar8 = uVar19 & 0xdfff;
                  if ((uVar19 >> 0xe & 1) != 0) {
                    uVar8 = uVar19 | 0x2000;
                  }
                }
                if (uVar8 == 0xfffc) {
                  iVar10 = (int)((*puVar13 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(lVar12 + 4) = *(int *)(lVar12 + 4) + iVar10;
                uVar21 = (ulonglong)*(uint *)(lVar12 + 4);
              }
              iVar10 = (int)uVar21;
              if ((*(ulonglong *)(lVar12 + 0x1e) != 0) &&
                 (*(ulonglong *)(lVar12 + 0x1e) < uVar21 + *(longlong *)(lVar12 + 8))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar22 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                     lVar22 != 0 && (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
                    (*(char *)(lVar22 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar23 + -8) = 0x101e36;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar23 + 0x20) = 0;
                    *(undefined8 *)(puVar23 + -8) = 0x101e5c;
                    (*_DAT_)(1,0xab09f8,0xbd06c8,0x877);
                  }
                }
                uVar4 = *(undefined8 *)(lVar12 + 8);
                *(undefined8 *)(puVar23 + -8) = 0x101e6a;
                func_0x(uVar4,0x12);
                iVar10 = *(int *)(lStack_e0 + 4);
              }
              if (0x3f3b < iVar10 - 1U) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar22 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar22 != 0 &&
                    ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                     (*(char *)(lVar22 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar23 + -8) = 0x101efc;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar23 + 0x20) = 0;
                    *(undefined8 *)(puVar23 + -8) = 0x101f22;
                    (*_DAT_)(1,0xab09f8,0xbd06c8,0x87c);
                  }
                }
                uVar4 = *(undefined8 *)(lVar12 + 8);
                *(undefined8 *)(puVar23 + -8) = 0x101f30;
                func_0x(uVar4,5);
              }
            }
LAB_:
            *(undefined8 *)(puVar23 + -8) = 0x101f38;
            iVar10 = func_0x(puVar24);
            if (iVar10 == 0) {
              *(undefined8 *)(puVar23 + -8) = 0x102015;
              iVar10 = func_0x(puVar24);
              if (iVar10 == 0) {
                *(undefined8 *)(puVar23 + 0x20) = 0;
                *(undefined8 *)(puVar23 + -8) = 0x102041;
                (*_DAT_)(1,0xc6c078,0xc5d168,0xd67);
              }
            }
            else {
              if ((-1 < (longlong)uVar34) &&
                 ((int)uStack_e8 < (int)(*(ushort *)(lVar12 + 0x2c) & 0x7ff))) {
                lVar18 = 0;
                uVar8 = 0;
                uVar21 = (ulonglong)*(ushort *)(lVar12 + 0x2a);
                lVar22 = *(longlong *)(lVar12 + 8);
                if ((*(ushort *)(lVar12 + 0x2c) & 0x3800) == 0) {
                  uVar19 = *(ushort *)(lVar22 + 2 + uVar21);
                  goto LAB_;
                }
                uVar28 = *(ushort *)(lVar12 + 0x2c) >> 0xb;
                if ((uVar28 & 7) != 0) {
                  do {
                    uVar9 = 0;
                    if (lVar18 != 0) {
                      uVar9 = *(ushort *)(lVar22 + uVar21 + 2 + lVar18 * 2) & 0x7ff;
                    }
                    if (((int)uVar9 <= (int)uStack_e8) &&
                       (uVar19 = *(ushort *)(lVar22 + uVar21 + 4 + lVar18 * 2),
                       (int)uStack_e8 <= (int)((uVar19 & 0x7ff) - 1))) goto LAB_;
                    lVar18 = lVar18 + 1;
                  } while (lVar18 < (longlong)(ulonglong)(uVar28 & 7));
                }
                goto LAB_;
              }
              *(undefined8 *)(puVar23 + 0x20) = 0;
              *(undefined8 *)(puVar23 + -8) = 0x102005;
              (*_DAT_)(1,0xc6c048,0xc6c090,0x3c6);
            }
          }
        }
      }
      lVar12 = lStack_b0;
      uVar17 = 0;
      iVar10 = (int)uVar26;
      uVar4 = *(undefined8 *)(*(longlong *)(lStack_b0 + 8) + 0x160);
      *(undefined8 *)(puVar23 + -8) = 0x1010c6;
      func_0x(uVar4,&plStack_90,&uStack_c8);
      lVar12 = *(longlong *)(lVar12 + 8);
      if ((((*(longlong *)(lVar12 + 0x90) == 0) || (DAT_ == '\0')) ||
          (*(longlong *)(*(longlong *)(*(longlong *)(lVar12 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
         (*(uint *)(lVar12 + 0xf4) < 2)) {
        if (*(int *)(lVar12 + 0x480) == 0) {
          *(undefined8 *)(puVar23 + -8) = 0x10110f;
          func_0x();
        }
        plVar1 = plStack_90;
        if (plStack_90[1] != 0) {
          lVar22 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar12 = *(longlong *)(lVar22 + 0x100);
          if (lVar12 == 0) {
            *(undefined8 *)(puVar23 + -8) = 0x101151;
            (*_DAT_)(0);
            lVar12 = *(longlong *)(lVar22 + 0x100);
          }
          if (*(longlong *)(lVar12 + 0x260) != 0) {
            uVar17 = (ulonglong)*(uint *)(*(longlong *)(lVar12 + 0x260) + 0xe68);
          }
          if ((uint)uVar17 < *(uint *)(_DAT_ + 8)) {
            lVar12 = *(longlong *)(plVar1[1] + uVar17 * 8);
            *(longlong *)(lVar12 + lStack_88 * 8) = *(longlong *)(lVar12 + lStack_88 * 8) + 1;
            goto LAB_;
          }
        }
        LOCK();
        plVar1 = (longlong *)(*plStack_90 + lStack_88 * 8);
        *plVar1 = *plVar1 + 1;
        UNLOCK();
      }
LAB_:
      uVar17 = uVar34;
    } while ((longlong)uVar16 < lVar15);
    uVar16 = (ulonglong)uStack_e8;
  }
  lVar12 = lStack_b0;
  lVar22 = (longlong)iVar10;
  if (lVar22 < lVar15) {
    puVar31 = (uint *)(lStack_d0 + 0x10 + lVar22 * 0x20);
    do {
      uVar4 = *(undefined8 *)(*(longlong *)(lVar12 + 8) + 0x160);
      *(undefined8 *)(puVar23 + -8) = 0x1020d8;
      func_0x(uVar4,&plStack_80,&uStack_e4);
      lVar18 = *(longlong *)(lVar12 + 8);
      if ((((*(longlong *)(lVar18 + 0x90) == 0) || (DAT_ == '\0')) ||
          (*(longlong *)(*(longlong *)(*(longlong *)(lVar18 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
         (*(uint *)(lVar18 + 0xf4) < 2)) {
        if (*(int *)(lVar18 + 0x480) == 0) {
          *(undefined8 *)(puVar23 + -8) = 0x102121;
          func_0x();
        }
        plVar1 = plStack_80;
        if (plStack_80[1] != 0) {
          lVar32 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar18 = *(longlong *)(lVar32 + 0x100);
          if (lVar18 == 0) {
            *(undefined8 *)(puVar23 + -8) = 0x10215f;
            (*_DAT_)(0);
            lVar18 = *(longlong *)(lVar32 + 0x100);
          }
          if (*(longlong *)(lVar18 + 0x260) == 0) {
            uVar16 = 0;
          }
          else {
            uVar16 = (ulonglong)*(uint *)(*(longlong *)(lVar18 + 0x260) + 0xe68);
          }
          if ((uint)uVar16 < *(uint *)(_DAT_ + 8)) {
            lVar18 = *(longlong *)(plVar1[1] + uVar16 * 8);
            *(longlong *)(lVar18 + lStack_78 * 8) = *(longlong *)(lVar18 + lStack_78 * 8) + 1;
            goto LAB_;
          }
        }
        LOCK();
        plVar1 = (longlong *)(*plStack_80 + lStack_78 * 8);
        *plVar1 = *plVar1 + 1;
        UNLOCK();
      }
LAB_:
      lVar22 = lVar22 + 1;
      puVar31 = puVar31 + 8;
      if (lVar15 <= lVar22) goto LAB_;
      uStack_e4 = *puVar31 & 0x1fffffff;
    } while( true );
  }
LAB_:
  lVar12 = (longlong)puStack_c0;
  lVar15 = lStack_e0;
  lVar22 = (longlong)(int)uVar16;
  if (lVar22 < (longlong)puStack_c0) {
LAB_:
    lVar18 = lStack_b0;
    uVar17 = 0;
    uVar4 = *(undefined8 *)(*(longlong *)(lStack_b0 + 8) + 0x160);
    *(undefined8 *)(puVar23 + -8) = 0x10221c;
    func_0x(uVar4,&plStack_70,auStack_d8);
    lVar18 = *(longlong *)(lVar18 + 8);
    if ((((*(longlong *)(lVar18 + 0x90) == 0) || (DAT_ == '\0')) ||
        (*(longlong *)(*(longlong *)(*(longlong *)(lVar18 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
       (*(uint *)(lVar18 + 0xf4) < 2)) {
      if (*(int *)(lVar18 + 0x480) == 0) {
        *(undefined8 *)(puVar23 + -8) = 0x102265;
        func_0x();
      }
      plVar1 = plStack_70;
      if (plStack_70[1] != 0) {
        lVar32 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar18 = *(longlong *)(lVar32 + 0x100);
        if (lVar18 == 0) {
          *(undefined8 *)(puVar23 + -8) = 0x1022a3;
          (*_DAT_)(0);
          lVar18 = *(longlong *)(lVar32 + 0x100);
        }
        if (*(longlong *)(lVar18 + 0x260) != 0) {
          uVar17 = (ulonglong)*(uint *)(*(longlong *)(lVar18 + 0x260) + 0xe68);
        }
        if ((uint)uVar17 < *(uint *)(_DAT_ + 8)) {
          lVar18 = *(longlong *)(plVar1[1] + uVar17 * 8);
          *(longlong *)(lVar18 + lStack_68 * 8) = *(longlong *)(lVar18 + lStack_68 * 8) + 1;
          goto LAB_;
        }
      }
      LOCK();
      plVar1 = (longlong *)(*plStack_70 + lStack_68 * 8);
      *plVar1 = *plVar1 + 1;
      UNLOCK();
    }
LAB_:
    uVar9 = (int)uVar16 + 1;
    uVar16 = (ulonglong)uVar9;
    lVar22 = lVar22 + 1;
    if (lVar22 < lVar12) {
      if (*(int *)(lVar15 + 4) == 0) {
        pbVar30 = *(byte **)(lVar15 + 8);
        uVar20 = *(uint *)(lVar15 + 0x10);
        uVar17 = (ulonglong)uVar20;
        *(undefined2 *)(lVar15 + 2) = 0;
        *(uint *)(lVar15 + 0x14) = uVar20;
        bVar7 = *pbVar30;
        if ((bVar7 & 0x10) != 0) {
          uVar20 = uVar20 + 2 + (*(ushort *)(pbVar30 + uVar17) + 7 >> 3);
          uVar17 = (ulonglong)uVar20;
          *(uint *)(lVar15 + 0x14) = uVar20;
          bVar7 = *pbVar30;
        }
        if ((bVar7 & 0x20) == 0) {
          *(int *)(lVar15 + 4) = (int)uVar17;
          *(undefined2 *)(lVar15 + 0x1c) = 0;
          *(int *)(lVar15 + 0x18) = (int)uVar17;
        }
        else {
          puVar24 = (ushort *)(pbVar30 + uVar17);
          uVar8 = *puVar24;
          *(ushort *)(lVar15 + 0x1c) = uVar8;
          if (uVar8 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar18 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar18 != 0)) &&
               ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                (*(char *)(lVar18 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar23 + -8) = 0x1023ea;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar23 + 0x20) = 0;
                *(undefined8 *)(puVar23 + -8) = 0x102410;
                (*_DAT_)(1,0xab09f8,0xbd06c8,0x80f);
              }
            }
            uVar4 = *(undefined8 *)(lVar15 + 8);
            *(undefined8 *)(puVar23 + -8) = 0x10241e;
            func_0x(uVar4,3);
            uVar17 = (ulonglong)*(uint *)(lVar15 + 0x14);
            uVar8 = *(ushort *)(lVar15 + 0x1c);
          }
          uVar20 = (int)uVar17 + (uVar8 + 1) * 2;
          *(uint *)(lVar15 + 0x18) = uVar20;
          if (0x1f9e < uVar20) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar18 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar18 != 0 &&
                ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                 (*(char *)(lVar18 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar23 + -8) = 0x1024bf;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar23 + 0x20) = 0;
                *(undefined8 *)(puVar23 + -8) = 0x1024e5;
                (*_DAT_)(1,0xab09f8,0xbd06c8,0x816);
              }
            }
            uVar4 = *(undefined8 *)(lVar15 + 8);
            *(undefined8 *)(puVar23 + -8) = 0x1024f3;
            func_0x(uVar4,4);
            uVar8 = *(ushort *)(lVar15 + 0x1c);
            uVar20 = *(uint *)(lVar15 + 0x18);
          }
          uVar17 = (ulonglong)uVar8;
          uVar8 = puVar24[uVar17];
          *(uint *)(lVar15 + 4) = uVar8 & 0x7fff;
          if ((uVar8 & 0x7fff) < uVar20) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar18 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar18 != 0)) &&
               ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                (*(char *)(lVar18 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar23 + -8) = 0x102592;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar23 + 0x20) = 0;
                *(undefined8 *)(puVar23 + -8) = 0x1025b8;
                (*_DAT_)(1,0xab09f8,0xbd06c8,0x81d);
              }
            }
            uVar4 = *(undefined8 *)(lVar15 + 8);
            *(undefined8 *)(puVar23 + -8) = 0x1025c6;
            func_0x(uVar4,4);
            uVar17 = (ulonglong)*(ushort *)(lVar15 + 0x1c);
          }
          if ((short)puVar24[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
            pbVar30 = *(byte **)(lVar15 + 8);
            do {
              if ((int)uVar17 == 1) {
                uVar20 = *(uint *)(lVar15 + 0x18);
                uVar29 = uVar20;
LAB_:
                if ((*(ushort *)(pbVar30 + uVar17 * 2 + (ulonglong)*(uint *)(lVar15 + 0x14)) &
                    0x7fff) < uVar20) goto LAB_;
              }
              else {
                uVar29 = *(uint *)(lVar15 + 0x18);
                uVar20 = *(ushort *)
                          (pbVar30 + uVar17 * 2 + ((ulonglong)*(uint *)(lVar15 + 0x14) - 2)) &
                         0x7fff;
                if (uVar29 <= uVar20) goto LAB_;
LAB_:
                *(undefined8 *)(puVar23 + -8) = 0x102635;
                func_0x(pbVar30,7);
                uVar29 = *(uint *)(lVar15 + 0x18);
              }
              if ((uVar20 < uVar29) || (*(uint *)(lVar15 + 4) < uVar20)) goto LAB_;
              pbVar30 = *(byte **)(lVar15 + 8);
              if (*(ushort *)(pbVar30 + uVar20) == 5) {
                *(ushort *)(lVar15 + 2) = *(ushort *)(lVar15 + 2) | 2;
                *(short *)(lVar15 + 0x1c) = *(short *)(lVar15 + 0x1c) + -1;
                uVar8 = *(ushort *)(lVar15 + 0x2c) & 0xc7ff;
                uVar29 = uVar20 & 0xffff;
                *(short *)(lVar15 + 0x2a) = (short)uVar20;
                if ((*(ushort *)(pbVar30 + (ulonglong)uVar29 + 2) >> 0xe & 1) != 0) {
                  uVar8 = *(ushort *)(pbVar30 + (ulonglong)uVar29 + 2) & 0x3800 | uVar8;
                }
                *(ushort *)(lVar15 + 0x2c) = uVar8;
                *(ushort *)(lVar15 + 0x2c) =
                     (uVar8 ^ *(ushort *)(pbVar30 + (ulonglong)uVar29 + 2)) & 0x7ff ^ uVar8;
                goto LAB_;
              }
              if (*(ushort *)(pbVar30 + uVar20) < 0x400) goto LAB_;
              *(ushort *)(lVar15 + 2) = *(ushort *)(lVar15 + 2) | 1;
              uVar8 = *(short *)(lVar15 + 0x1c) - 1;
              *(ushort *)(lVar15 + 0x1c) = uVar8;
              if (uVar8 == 0) goto LAB_;
              uVar17 = (ulonglong)uVar8;
            } while ((short)puVar24[(ulonglong)(uVar8 - 1) + 1] < 0);
            uVar17 = (ulonglong)*(uint *)(lVar15 + 4);
          }
          else {
LAB_:
            uVar17 = (ulonglong)*(uint *)(lVar15 + 4);
            pbVar30 = *(byte **)(lVar15 + 8);
          }
        }
        iVar10 = 0;
        if ((*pbVar30 & 0x40) == 0) {
          *(undefined4 *)(lVar15 + 0x26) = 0;
        }
        else {
          *(int *)(lVar15 + 0x26) = *(int *)(lVar15 + 4);
          *(int *)(lVar15 + 4) = *(int *)(lVar15 + 4) + 0xe;
          *(undefined8 *)(puVar23 + -8) = 0x10273e;
          puVar13 = (ulonglong *)func_0x(lVar15 + 2);
          uVar19 = (ushort)(*puVar13 >> 0x30);
          uVar8 = uVar19;
          if ((((uint)(int)(short)uVar19 >> 1 ^ (int)(short)uVar19) & 0x2000) != 0) {
            uVar8 = uVar19 & 0xdfff;
            if ((uVar19 >> 0xe & 1) != 0) {
              uVar8 = uVar19 | 0x2000;
            }
          }
          if (uVar8 == 0xfffc) {
            iVar10 = (int)((*puVar13 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(lVar15 + 4) = *(int *)(lVar15 + 4) + iVar10;
          uVar17 = (ulonglong)*(uint *)(lVar15 + 4);
        }
        iVar10 = (int)uVar17;
        if ((*(ulonglong *)(lVar15 + 0x1e) != 0) &&
           (*(ulonglong *)(lVar15 + 0x1e) < uVar17 + *(longlong *)(lVar15 + 8))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar18 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar18 != 0 &&
               (lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0)) &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar23 + -8) = 0x10283c;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar23 + 0x20) = 0;
              *(undefined8 *)(puVar23 + -8) = 0x102862;
              (*_DAT_)(1,0xab09f8,0xbd06c8,0x877);
            }
          }
          uVar4 = *(undefined8 *)(lVar15 + 8);
          *(undefined8 *)(puVar23 + -8) = 0x102870;
          func_0x(uVar4,0x12);
          iVar10 = *(int *)(lVar15 + 4);
        }
        if (0x3f3b < iVar10 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar18 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar18 != 0 &&
              ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
               (*(char *)(lVar18 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar23 + -8) = 0x1028fd;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              uVar4 = *(undefined8 *)(lVar15 + 8);
              *(undefined8 *)(puVar23 + -8) = 0x10290b;
              func_0x(uVar4,5);
              goto LAB_;
            }
            *(undefined8 *)(puVar23 + 0x20) = 0;
            *(undefined8 *)(puVar23 + -8) = 0x102931;
            (*_DAT_)(1,0xab09f8,0xbd06c8,0x87c);
          }
          uVar4 = *(undefined8 *)(lVar15 + 8);
          *(undefined8 *)(puVar23 + -8) = 0x10293f;
          func_0x(uVar4,5);
        }
      }
LAB_:
      lVar18 = 0;
      *(undefined8 *)(puVar23 + -8) = 0x10294c;
      iVar10 = func_0x(lVar15 + 2);
      if (iVar10 == 0) {
        *(undefined8 *)(puVar23 + -8) = 0x102a58;
        iVar10 = func_0x(lVar15 + 2);
        if (iVar10 == 0) {
          *(undefined8 *)(puVar23 + 0x20) = 0;
          *(undefined8 *)(puVar23 + -8) = 0x102a82;
          (*_DAT_)(1,0xc6c078,0xc5d168,0xd67);
        }
      }
      else if ((lVar22 < 0) || ((int)(*(ushort *)(lVar15 + 0x2c) & 0x7ff) <= (int)uVar9)) {
        *(undefined8 *)(puVar23 + 0x20) = 0;
        *(undefined8 *)(puVar23 + -8) = 0x102a47;
        (*_DAT_)(1,0xc6c048,0xc6c090,0x3c6);
      }
      else {
        uVar17 = (ulonglong)*(ushort *)(lVar15 + 0x2a);
        lVar32 = *(longlong *)(lVar15 + 8);
        if ((*(ushort *)(lVar15 + 0x2c) & 0x3800) == 0) {
          uVar19 = *(ushort *)(lVar32 + 2 + uVar17);
LAB_:
          uVar19 = uVar19 >> 0xb & 7;
        }
        else {
          uVar8 = *(ushort *)(lVar15 + 0x2c) >> 0xb;
          uVar19 = 0;
          if ((uVar8 & 7) != 0) {
            do {
              if (lVar18 == 0) {
                uVar20 = 0;
              }
              else {
                uVar20 = *(ushort *)(lVar32 + uVar17 + 2 + lVar18 * 2) & 0x7ff;
              }
              if (((int)uVar20 <= (int)uVar9) &&
                 (uVar19 = *(ushort *)(lVar32 + uVar17 + 4 + lVar18 * 2),
                 (int)uVar9 <= (int)((uVar19 & 0x7ff) - 1))) goto LAB_;
              lVar18 = lVar18 + 1;
              uVar19 = 0;
            } while (lVar18 < (longlong)(ulonglong)(uVar8 & 7));
          }
        }
        auStack_d8[0] =
             (uint)*(ushort *)
                    ((ulonglong)((*(ushort *)(lVar15 + 0x2c) >> 0xb & 7) * 2) + lVar32 + lVar22 * 2
                     + 4 + uVar17) + (uint)uVar19 * 0x10000;
      }
      goto LAB_;
    }
  }
  uVar16 = uStack_48 ^ (ulonglong)&uStack_e8;
  *(undefined8 *)(puVar23 + -8) = 0x102a96;
  func_0x(uVar16);
  return;
LAB_:
  uVar16 = (ulonglong)uStack_e8;
  goto LAB_;
}

