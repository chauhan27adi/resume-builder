
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 *param_2,longlong *param_3,undefined8 param_4)

{
  int *piVar1;
  short *psVar2;
  undefined4 uVar3;
  code *pcVar4;
  longlong lVar5;
  char *pcVar6;
  longlong *plVar7;
  longlong *plVar8;
  bool bVar9;
  char cVar10;
  byte bVar11;
  undefined uVar12;
  ushort uVar13;
  undefined2 uVar14;
  short sVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  undefined4 uVar19;
  longlong lVar20;
  short *psVar21;
  undefined2 *puVar22;
  undefined8 uVar23;
  longlong lVar24;
  longlong lVar25;
  undefined4 *puVar26;
  longlong lVar27;
  undefined *puVar28;
  byte *pbVar29;
  undefined8 *puVar30;
  undefined8 *puVar31;
  undefined *puVar32;
  longlong **pplVar33;
  undefined8 uVar34;
  undefined8 uVar35;
  undefined8 uVar36;
  undefined8 uVar37;
  ushort uVar38;
  uint uVar39;
  uint uVar40;
  ulonglong uVar41;
  uint uVar42;
  uint uVar43;
  uint uVar44;
  int *piVar45;
  uint *puVar46;
  undefined *puVar47;
  undefined *puVar48;
  ushort *puVar49;
  int iVar50;
  int iVar51;
  ushort *puVar52;
  byte bVar53;
  byte *pbVar54;
  short *psVar55;
  ulonglong uVar56;
  longlong lVar57;
  short sStackX_10;
  ushort uStackX_12;
  uint uStackX_14;
  byte *pbStackX_18;
  undefined8 uStackX_20;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar20 = func_0x();
  lVar20 = -lVar20;
  puVar47 = &stack0xffffffffffffffc0 + lVar20;
  puVar48 = &stack0xffffffffffffffc0 + lVar20;
  puVar32 = &stack0xffffffffffffffc0 + lVar20;
  puVar28 = &stack0xffffffffffffffc0 + lVar20;
  psVar2 = (short *)((longlong)&sStackX_10 + lVar20);
  *(undefined8 *)(&stack0x000002e0 + lVar20) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000067e0 + lVar20) = _DAT_ ^ (ulonglong)psVar2;
  *(undefined8 *)(&stack0x00000170 + lVar20) = param_4;
  *(longlong **)(&stack0x00000050 + lVar20) = param_3;
  *(undefined8 **)(&stack0x000000b0 + lVar20) = param_2;
  *(longlong *)(&stack0x00000138 + lVar20) = param_1;
  lVar27 = *param_3;
  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100075;
  func_0x(&stack0x000002a0 + lVar20,param_1);
  lVar24 = **(longlong **)(param_1 + 0x2e0);
  *(longlong *)(&stack0x00000080 + lVar20) = lVar24;
  puVar30 = (undefined8 *)0x0;
  uVar39 = 0;
  if (((*(byte *)(*(longlong *)(**(longlong **)(*(uint **)(param_1 + 0x108) + 8) + 8) + 0x107) &
       0x40) == 0) || (uVar44 = 1, (**(uint **)(param_1 + 0x108) & 0x1000000) != 0)) {
    uVar44 = uVar39;
  }
  *(uint *)(&stack0x000000a8 + lVar20) = uVar44;
  *psVar2 = -1;
  *(undefined8 *)((longlong)&pbStackX_18 + lVar20) = 0;
  *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = 0;
  *(undefined8 *)(&stack0x0000002e + lVar20) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar20) = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar20) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1000e5;
  iVar16 = func_0x(param_2,uVar44);
  if (iVar16 == 0x40f02) {
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1000f5;
    func_0x(param_2 + 6);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100101;
    func_0x(param_2 + 0x56);
    *(undefined4 *)((longlong)param_2 + 0x634) = 1;
    puVar48 = &stack0xffffffffffffffc0 + lVar20;
    if (*(undefined8 **)(&stack0x00000170 + lVar20) != (undefined8 *)0x0) {
      **(undefined8 **)(&stack0x00000170 + lVar20) = 0;
      puVar48 = &stack0xffffffffffffffc0 + lVar20;
    }
    goto LAB_;
  }
  if ((*(byte *)(lVar27 + 0x38) & 2) == 0) {
    *(undefined8 *)(&stack0x00000288 + lVar20) = *(undefined8 *)(*(longlong *)(param_1 + 0x2e0) + 8)
    ;
    lVar27 = *(longlong *)(&stack0x00000138 + lVar20);
    uVar44 = *(uint *)(lVar27 + 0x25c);
    if (((param_2 != (undefined8 *)0x0) && (*(int *)(param_2 + 1) == 1)) &&
       (*(char *)(param_2[5] + 0xb5) != '\0')) {
      *(uint *)((longlong)param_2 + 0x634) = *(uint *)((longlong)param_2 + 0x634) & 0xfffffffe;
    }
    if ((*(byte *)(*param_3 + 0x38) & 0x20) == 0) {
      puVar31 = puVar30;
      if ((param_2 != (undefined8 *)0x0) && (*(int *)(param_2 + 1) == 1)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100193;
        func_0x(param_2);
        puVar31 = param_2;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1001a2;
      func_0x(&stack0x00000280 + lVar20,puVar31);
      pcVar4 = *(code **)*param_2;
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1001ab;
      psVar21 = (short *)(*pcVar4)(param_2);
      pcVar4 = *(code **)*param_2;
      if (*psVar21 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1001c2;
        puVar22 = (undefined2 *)(*pcVar4)();
        *puVar22 = 0;
        puVar52 = puVar22 + 1;
        *(ushort **)(&stack0x00000070 + lVar20) = puVar52;
        *psVar2 = 0;
        lVar27 = *param_3;
        if ((*(byte *)(lVar27 + 0x38) & 0x20) == 0) {
          if (((**(byte **)(puVar22 + 4) & 0xe) == 2) && ((**(byte **)(puVar22 + 4) & 0x40) != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100209;
            uVar23 = func_0x(puVar52,&stack0x000002e8 + lVar20);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100211;
            iVar16 = func_0x(uVar23);
            if (iVar16 == 0) goto LAB_;
            bVar9 = true;
          }
          else {
LAB_:
            bVar9 = false;
          }
          if (((*(byte *)(lVar27 + 0x5c) & 2) == 0) &&
             (*(uint *)(puVar22 + 8) == *(uint *)(lVar27 + 0x14))) {
            uVar44 = uVar39;
            if ((**(byte **)(puVar22 + 4) & 0x10) != 0) {
              uVar44 = (uint)*(ushort *)(*(byte **)(puVar22 + 4) + *(uint *)(puVar22 + 8));
            }
            if ((uVar44 != *(ushort *)(*(longlong *)(lVar24 + 8) + 0xcc)) || (bVar9))
            goto LAB_;
            if (*(int *)(puVar22 + 2) == 0) {
              *puVar52 = 0;
              uVar39 = *(uint *)(puVar22 + 8);
              uVar56 = (ulonglong)uVar39;
              *(uint *)(puVar22 + 10) = uVar39;
              pbVar29 = *(byte **)(puVar22 + 4);
              bVar53 = *pbVar29;
              pbVar54 = pbVar29;
              if ((bVar53 & 0x10) != 0) {
                uVar39 = (*(ushort *)(pbVar29 + uVar56) + 7 >> 3) + uVar39 + 2;
                *(uint *)(puVar22 + 10) = uVar39;
                uVar56 = (ulonglong)uVar39;
                bVar53 = *pbVar29;
                pbVar54 = *(byte **)(puVar22 + 4);
              }
              if ((bVar53 & 0x20) == 0) {
                *(int *)(puVar22 + 2) = (int)uVar56;
                puVar22[0xe] = 0;
                *(uint *)(puVar22 + 0xc) = uVar39;
              }
              else {
                puVar49 = (ushort *)(pbVar29 + uVar56);
                uVar13 = *puVar49;
                puVar22[0xe] = uVar13;
                if (uVar13 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1002da;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1002e3;
                    lVar24 = func_0x();
                    if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1002fd;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100319;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10033f;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10034d;
                  func_0x(uVar23,3);
                  uVar13 = puVar22[0xe];
                  uVar39 = *(uint *)(puVar22 + 10);
                }
                uVar39 = uVar39 + (uVar13 + 1) * 2;
                *(uint *)(puVar22 + 0xc) = uVar39;
                if (0x1f9e < uVar39) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100382;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10038b;
                    lVar24 = func_0x();
                    if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1003a5;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1003c1;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1003e7;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1003f5;
                  func_0x(uVar23,4);
                  uVar13 = puVar22[0xe];
                  uVar39 = *(uint *)(puVar22 + 0xc);
                }
                uVar56 = (ulonglong)uVar13;
                uVar13 = puVar49[uVar56];
                *(uint *)(puVar22 + 2) = uVar13 & 0x7fff;
                if ((uVar13 & 0x7fff) < uVar39) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100425;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10042e;
                    lVar24 = func_0x();
                    if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100448;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100464;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10048a;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100498;
                  func_0x(uVar23,4);
                  uVar56 = (ulonglong)(ushort)puVar22[0xe];
                }
                if ((short)puVar49[(ulonglong)((int)uVar56 - 1) + 1] < 0) {
                  do {
                    lVar24 = *(longlong *)(puVar22 + 4);
                    lVar25 = (ulonglong)*(uint *)(puVar22 + 10) + lVar24;
                    if ((int)uVar56 == 1) {
                      uVar39 = *(uint *)(puVar22 + 0xc);
                      uVar13 = *(ushort *)(lVar25 + uVar56 * 2);
                      uVar44 = uVar39;
LAB_:
                      if ((uVar13 & 0x7fff) < uVar39) goto LAB_;
                    }
                    else {
                      uVar39 = *(ushort *)(lVar25 + -2 + uVar56 * 2) & 0x7fff;
                      uVar44 = *(uint *)(puVar22 + 0xc);
                      uVar13 = *(ushort *)(lVar25 + uVar56 * 2);
                      if (uVar44 <= uVar39) goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100507;
                      func_0x(lVar24,7);
                      uVar44 = *(uint *)(puVar22 + 0xc);
                      lVar24 = *(longlong *)(puVar22 + 4);
                    }
                    if ((uVar39 < uVar44) || (*(uint *)(puVar22 + 2) < uVar39)) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar39 + lVar24) == 5) {
                      *puVar52 = *puVar52 | 2;
                      puVar22[0xe] = puVar22[0xe] + -1;
                      puVar22[0x15] = (short)uVar39;
                      lVar24 = (ulonglong)(uVar39 & 0xffff) + *(longlong *)(puVar22 + 4);
                      uVar13 = puVar22[0x16] & 0xc7ff;
                      if ((*(ushort *)(lVar24 + 2) >> 0xe & 1) != 0) {
                        uVar13 = *(ushort *)(lVar24 + 2) & 0x3800 | puVar22[0x16] & 0xc7ff;
                      }
                      puVar22[0x16] = uVar13;
                      puVar22[0x16] = (uVar13 ^ *(ushort *)(lVar24 + 2)) & 0x7ff ^ uVar13;
                      pbVar54 = *(byte **)(puVar22 + 4);
                      uVar56 = (ulonglong)*(uint *)(puVar22 + 2);
                      goto LAB_;
                    }
                    if (*(ushort *)((ulonglong)uVar39 + lVar24) < 0x400) break;
                    *puVar52 = *puVar52 | 1;
                    uVar13 = puVar22[0xe] - 1;
                    puVar22[0xe] = uVar13;
                    if ((uVar13 == 0) ||
                       (uVar56 = (ulonglong)uVar13, -1 < (short)puVar49[(ulonglong)(uVar13 - 1) + 1]
                       )) break;
                  } while( true );
                }
                pbVar54 = *(byte **)(puVar22 + 4);
                uVar56 = (ulonglong)*(uint *)(puVar22 + 2);
              }
LAB_:
              if ((*pbVar54 & 0x40) == 0) {
                *(undefined4 *)(puVar22 + 0x13) = 0;
              }
              else {
                *(int *)(puVar22 + 0x13) = (int)uVar56;
                *(int *)(puVar22 + 2) = (int)uVar56 + 0xe;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1005fe;
                uVar23 = func_0x(puVar52);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10060d;
                func_0x(uVar23,&stack0x000001c0 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100619;
                iVar16 = func_0x(&stack0x000001c0 + lVar20);
                *(int *)(puVar22 + 2) = *(int *)(puVar22 + 2) + iVar16;
                pbVar54 = *(byte **)(puVar22 + 4);
              }
              uVar39 = *(uint *)(puVar22 + 2);
              if ((*(byte **)(puVar22 + 0xf) != (byte *)0x0) &&
                 (*(byte **)(puVar22 + 0xf) < pbVar54 + uVar39)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100650;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100659;
                  lVar24 = func_0x();
                  if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100673;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10068f;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1006b5;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                    }
                  }
                }
                uVar23 = *(undefined8 *)(puVar22 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1006c3;
                func_0x(uVar23,0x12);
                uVar39 = *(uint *)(puVar22 + 2);
              }
              if (0x3f3b < uVar39 - 1) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1006dc;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1006e5;
                  lVar24 = func_0x();
                  if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1006ff;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10071b;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100741;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                    }
                  }
                }
                uVar23 = *(undefined8 *)(puVar22 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10074f;
                func_0x(uVar23,5);
              }
            }
LAB_:
            uVar39 = *(uint *)(puVar22 + 2);
            if ((uVar39 < 9) &&
               (((**(byte **)(puVar22 + 4) & 0xe) == 0 || ((**(byte **)(puVar22 + 4) & 0xe) == 0xc))
               )) {
              uVar39 = 9;
            }
            *(undefined4 *)((longlong)&uStackX_20 + lVar20) = *(undefined4 *)(puVar22 + 8);
            *(ushort *)((longlong)&sStackX_10 + lVar20 + 2) = *puVar52;
            *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = *(undefined4 *)(puVar22 + 2);
            *(undefined2 *)(&stack0x0000002c + lVar20) = puVar22[0xe];
            *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) = *(undefined4 *)(puVar22 + 10);
            *(undefined4 *)(&stack0x00000028 + lVar20) = *(undefined4 *)(puVar22 + 0xc);
            *(undefined4 *)(&stack0x00000036 + lVar20) = *(undefined4 *)(puVar22 + 0x13);
            uVar23 = *(undefined8 *)(puVar22 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1007b7;
            func_0x(&stack0x000028a0 + lVar20,0x3f3c,uVar23,uVar39);
            *(undefined **)((longlong)&pbStackX_18 + lVar20) = &stack0x000028a0 + lVar20;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1007cb;
            iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if (iVar16 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1007df;
              uVar13 = func_0x
                                 ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000178 + lVar20);
              *(ushort *)(&stack0x0000003a + lVar20) = uVar13;
              lVar24 = (ulonglong)uVar13 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
              uVar13 = *(ushort *)(lVar24 + 2);
              uVar38 = *(ushort *)(&stack0x0000003c + lVar20);
              if ((uVar13 & 0x4000) == 0) {
                uVar38 = uVar38 & 0xc7ff;
              }
              else {
                uVar38 = uVar38 ^ (uVar13 ^ uVar38) & 0x3800;
              }
              *(ushort *)(&stack0x0000003c + lVar20) = uVar38;
              *(ushort *)(&stack0x0000003c + lVar20) =
                   (uVar38 ^ *(ushort *)(lVar24 + 2)) & 0x7ff ^ uVar38;
            }
            if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0xe) == 2) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10085c;
              func_0x((longlong)&sStackX_10 + lVar20 + 2);
            }
            lVar24 = *param_3;
            if ((*(byte *)(lVar27 + 0x5c) & 4) == 0) {
              uVar13 = *(ushort *)(lVar24 + 0x62);
              *(uint *)(&stack0x0000005c + lVar20) = (uint)uVar13;
              uVar39 = 0;
              *(undefined4 *)(&stack0x00000048 + lVar20) = 0;
              puVar46 = (uint *)param_3[1];
              *(uint **)(&stack0x00000068 + lVar20) = puVar46;
              if (uVar13 != 0) {
                do {
                  uVar44 = 0;
                  (&stack0x00000058)[lVar20] = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100a23;
                  func_0x(param_3,puVar46,&stack0x00000058 + lVar20);
                  if ((&stack0x00000058)[lVar20] == '\x03') {
                    if ((puVar46[0x10] & 0x4000) == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103717;
                      (*_DAT_)(6,0x51,0x10,1);
                    }
                    uVar14 = *(undefined2 *)(puVar46 + 0xf);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10372f;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,puVar46,uVar14,1);
                  }
                  else {
                    if (*(short *)(puVar46 + 1) != 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100a42;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2,puVar46);
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100a54;
                    func_0x(param_3,puVar46,&stack0x000000d8 + lVar20);
                    cVar10 = *(char *)(puVar46 + 0x10);
                    if ((cVar10 == '\x01') || (cVar10 == '\x02')) {
                      lVar27 = *(longlong *)(&stack0x000000d8 + lVar20);
                      if ((puVar46[0x10] >> 8 & 1) == 0) {
                        uVar44 = *puVar46;
                        uVar14 = *(undefined2 *)(puVar46 + 0xf);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103642;
                        func_0x
                                  ((longlong)(int)uVar44 +
                                   *(longlong *)((longlong)&pbStackX_18 + lVar20),lVar27,uVar14);
                        goto LAB_;
                      }
                      if (((puVar46[0x10] >> 0xf & 1) == 0) ||
                         ((*(byte *)((longlong)param_3 + 0x14) & 8) == 0)) {
                        if ((*(byte *)(*(longlong *)(puVar46 + 0x12) + 0x2a) & 0x10) == 0) {
                          lVar24 = param_3[3];
                        }
                        else {
                          lVar24 = param_3[4];
                        }
                        uVar39 = *(uint *)(*(longlong *)(*(longlong *)(puVar46 + 0x12) + 0x18) +
                                          lVar24);
                      }
                      else {
                        uVar39 = *(uint *)(param_3[7] + (ulonglong)puVar46[0xe] * 8);
                      }
                      uVar18 = (uint)*(ushort *)(puVar46 + 0xf);
                      if (uVar39 < uVar18) {
                        uVar44 = uVar18 - uVar39;
                      }
                      else if (uVar18 < uVar39) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1036af;
                        (*_DAT_)(6,0x5c,0x16,1);
                      }
                      uVar12 = *(undefined *)(*(longlong *)(puVar46 + 0x12) + 0x24);
                      lVar24 = (longlong)(int)*puVar46 +
                               *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      if ((lVar27 != 0) && (uVar39 != 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1036d8;
                        func_0x(lVar24,lVar27,uVar39);
                      }
                      if (uVar44 != 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1036ec;
                        func_0x((ulonglong)uVar39 + lVar24,uVar12,uVar44);
                      }
                    }
                    else {
                      if ((cVar10 == '\x03') || (cVar10 == '\x04')) {
                        uVar18 = puVar46[0x10];
                        piVar45 = *(int **)(&stack0x000000d8 + lVar20);
                        *(int **)(&stack0x00000070 + lVar20) = piVar45;
                        if (((uVar18 >> 0xd & 1) == 0) || (*piVar45 != 0)) {
                          if (((uVar18 >> 0xf & 1) == 0) ||
                             ((*(byte *)((longlong)param_3 + 0x14) & 8) == 0)) {
                            lVar27 = *(longlong *)(puVar46 + 0x12);
                            if ((uVar18 >> 8 & 1) == 0) {
                              uVar44 = (uint)*(ushort *)(lVar27 + 2);
                            }
                            else if ((*(byte *)(lVar27 + 0x2a) & 0x10) == 0) {
                              uVar44 = *(uint *)(*(longlong *)(lVar27 + 0x18) + param_3[3]);
                            }
                            else {
                              uVar44 = *(uint *)(*(longlong *)(lVar27 + 0x18) + param_3[4]);
                            }
                          }
                          else {
                            uVar44 = *(uint *)(param_3[7] + (ulonglong)puVar46[0xe] * 8);
                          }
                        }
                        if (*(ushort *)(puVar46 + 0xf) < uVar44) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102102;
                          (*_DAT_)(6,0x52,0x16,0x93);
                          piVar45 = *(int **)(&stack0x000000d8 + lVar20);
                          *(int **)(&stack0x00000070 + lVar20) = piVar45;
                        }
                        uVar18 = *puVar46;
                        if ((int)uVar18 < 0) {
                          if ((uVar18 & 0xc0000000) == 0x80000000) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102e4c;
                            func_0x(&stack0x00000660 + lVar20);
                            *(undefined4 *)(&stack0x00000094 + lVar20) = 0;
                            if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                              uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20);
                              uVar56 = (ulonglong)uVar39;
                              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              if ((*pbVar29 & 0x10) != 0) {
                                uVar39 = uVar39 + 2 + (*(ushort *)(pbVar29 + uVar56) + 7 >> 3);
                                uVar56 = (ulonglong)uVar39;
                                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              }
                              uVar39 = (uint)uVar56;
                              if ((*pbVar29 & 0x20) == 0) {
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                              }
                              else {
                                puVar52 = (ushort *)(pbVar29 + uVar56);
                                uVar13 = *puVar52;
                                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                if (uVar13 == 0) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102eb3;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ebc;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ed6;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ef2;
                                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f18;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f26;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                }
                                uVar18 = (int)uVar56 + (uVar13 + 1) * 2;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar18;
                                if (0x1f9e < uVar18) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f5a;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f63;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f7d;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f99;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102fbf;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102fcd;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                }
                                uVar41 = (ulonglong)uVar13;
                                uVar39 = puVar52[uVar41] & 0x7fff;
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                                if (uVar39 < uVar18) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103007;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103010;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10302a;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103046;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10306c;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10307a;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                  uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                  uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                                }
                                do {
                                  if (-1 < (short)puVar52[(ulonglong)((int)uVar41 - 1) + 1]) break;
                                  uVar40 = uVar18;
                                  if ((int)uVar41 != 1) {
                                    uVar40 = *(ushort *)(pbVar29 + uVar41 * 2 + (uVar56 - 2)) &
                                             0x7fff;
                                  }
                                  if ((uVar40 < uVar18) ||
                                     ((*(ushort *)(pbVar29 + uVar41 * 2 + uVar56) & 0x7fff) < uVar40
                                     )) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1030e1;
                                    func_0x(pbVar29,7);
                                    uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                    uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                                    uVar56 = (ulonglong)
                                             *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                    pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                    uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                                  }
                                  if ((uVar40 < uVar18) || (uVar39 < uVar40)) goto LAB_;
                                  if (*(ushort *)(pbVar29 + uVar40) == 5) {
                                    puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                    *puVar52 = *puVar52 | 2;
                                    *(short *)(&stack0x0000002c + lVar20) = (short)uVar41 + -1;
                                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar40;
                                    uVar13 = *(ushort *)(&stack0x0000003c + lVar20);
                                    if ((*(ushort *)(pbVar29 + (ulonglong)(uVar40 & 0xffff) + 2) >>
                                         0xe & 1) == 0) {
                                      uVar13 = uVar13 & 0xc7ff;
                                    }
                                    else {
                                      uVar13 = uVar13 ^ (*(ushort *)
                                                          (pbVar29 +
                                                          (ulonglong)(uVar40 & 0xffff) + 2) ^ uVar13
                                                        ) & 0x3800;
                                    }
                                    *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                                    *(ushort *)(&stack0x0000003c + lVar20) =
                                         uVar13 ^ (uVar13 ^ *(ushort *)
                                                             (pbVar29 +
                                                             (ulonglong)(uVar40 & 0xffff) + 2)) &
                                                  0x7ff;
                                    break;
                                  }
                                  if (*(ushort *)(pbVar29 + uVar40) < 0x400) break;
                                  puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                  *puVar49 = *puVar49 | 1;
                                  uVar13 = (short)uVar41 - 1;
                                  uVar41 = (ulonglong)uVar13;
                                  *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                } while (uVar13 != 0);
                              }
                              if ((*pbVar29 & 0x40) == 0) {
                                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                              }
                              else {
                                *(uint *)(&stack0x00000036 + lVar20) = uVar39;
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39 + 0xe;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1031c8;
                                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2)
                                ;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1031d7;
                                func_0x(uVar23,&stack0x000001f8 + lVar20);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1031e3;
                                iVar16 = func_0x(&stack0x000001f8 + lVar20);
                                uVar39 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar16;
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                                pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              if ((*(byte **)(&stack0x0000002e + lVar20) != (byte *)0x0) &&
                                 (*(byte **)(&stack0x0000002e + lVar20) < pbVar29 + uVar39)) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103220;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103229;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103243;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10325f;
                                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103285;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103293;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),
                                                0x12);
                                uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                              }
                              if (0x3f3b < uVar39 - 1) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1032ae;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1032b7;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1032d1;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1032ed;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103313;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103321;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                              }
LAB_:
                              uVar39 = *(uint *)(&stack0x00000048 + lVar20);
                            }
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10332d;
                            iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            if ((iVar16 == 0) && (uVar44 == 0)) {
                              param_3 = *(longlong **)(&stack0x00000050 + lVar20);
                              goto LAB_;
                            }
                            bVar53 = **(byte **)((longlong)&pbStackX_18 + lVar20) >> 6;
                            if ((bVar53 & 1) != 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10335c;
                              func_0x
                                        ((longlong)&sStackX_10 + lVar20 + 2,
                                         &stack0x00000660 + lVar20);
                            }
                            if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103377;
                              puVar26 = (undefined4 *)
                                        func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                                        &stack0x00000094 + lVar20);
                              *(undefined4 *)(&stack0x00000128 + lVar20) = *puVar26;
                              *(undefined2 *)(&stack0x0000012c + lVar20) =
                                   *(undefined2 *)(puVar26 + 1);
                              *(undefined2 *)(&stack0x0000012e + lVar20) =
                                   *(undefined2 *)((longlong)puVar26 + 6);
                            }
                            if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) == 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1033a7;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            }
                            lVar24 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4) +
                                     *(longlong *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1033b7;
                            iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                            if (iVar16 == 0) {
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                              uVar40 = (uint)uVar13;
                              uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                              puVar52 = (ushort *)(lVar27 + (ulonglong)uVar39);
                              uVar39 = uVar39 + 2 + uVar40 * 2;
                              uVar18 = 0;
                              if (*puVar52 != 0) {
                                do {
                                  uVar38 = puVar52[(ulonglong)uVar18 + 1];
                                  puVar52[(ulonglong)(uVar18 & 0xffff) + 1] =
                                       puVar52[(ulonglong)(uVar18 & 0xffff) + 1] & 0x8000;
                                  puVar52[(ulonglong)(uVar18 & 0xffff) + 1] =
                                       puVar52[(ulonglong)(uVar18 & 0xffff) + 1] |
                                       (uVar38 & 0x7fff) + 2 & 0x7fff;
                                  uVar18 = uVar18 + 1;
                                } while (uVar18 < *puVar52);
                                lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                              }
                              iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10349a;
                              func_0x
                                        ((ulonglong)uVar39 + 2 + lVar27,(ulonglong)uVar39 + lVar27,
                                         iVar16 - uVar39);
                              piVar1 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                              *piVar1 = *piVar1 + 2;
                              uVar39 = *(int *)(&stack0x00000028 + lVar20) + 2;
                              *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                              if (uVar13 != 0) {
                                uVar39 = puVar52[(ulonglong)(uVar40 - 1) + 1] & 0x7fff;
                              }
                              uVar18 = uVar40 + 1;
                              if (uVar40 < uVar18) {
                                do {
                                  puVar52[(ulonglong)(uVar40 & 0xffff) + 1] =
                                       (ushort)uVar39 & 0x7fff;
                                  uVar40 = uVar40 + 1;
                                } while (uVar40 < uVar18);
                              }
                              *puVar52 = *puVar52 + 1;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1034ea;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2);
                              iVar50 = 0;
                              uVar13 = *(ushort *)
                                        (lVar24 + 2 +
                                        (ulonglong)*(ushort *)(&stack0x0000002c + lVar20) * 2);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103501;
                              func_0x(&stack0x00000340 + lVar20);
                              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0;
                              *(uint **)(&stack0xffffffffffffffe0 + lVar20) = puVar46;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10351f;
                              func_0x(&stack0x00000330 + lVar20,piVar45,uVar44,0);
                              *(undefined **)(&stack0xffffffffffffffe8 + lVar20) =
                                   &stack0x00000154 + lVar20;
                              *(undefined **)(&stack0xffffffffffffffe0 + lVar20) =
                                   &stack0x00000330 + lVar20;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103553;
                              func_0x(&stack0x0000003a + lVar20,uVar13 & 0x7fff,0x1f9e,1);
                              iVar16 = *(int *)(&stack0x00000154 + lVar20);
                            }
                            else {
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                              lVar25 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4) +
                                       lVar27;
                              uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                              if (uVar13 != 0) {
                                uVar39 = *(ushort *)(lVar25 + (ulonglong)uVar13 * 2) & 0x7fff;
                              }
                              uVar18 = *(ushort *)(lVar25 + 2 + (ulonglong)(uint)uVar13 * 2) &
                                       0x7fff;
                              if ((uVar39 < *(uint *)(&stack0x00000028 + lVar20)) ||
                                 (uVar18 < uVar39)) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103405;
                                func_0x(lVar27,7);
                              }
                              iVar50 = uVar18 - uVar39;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103419;
                              iVar16 = func_0x(&stack0x0000003a + lVar20,puVar46,piVar45,
                                                       uVar44);
                            }
                            iVar50 = (*(int *)((longlong)&sStackX_10 + lVar20 + 4) - iVar50) +
                                     iVar16;
                            *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar50;
                            if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                              *(ushort *)
                               (lVar24 + 2 +
                               (ulonglong)(*(ushort *)(&stack0x0000002c + lVar20) + 1) * 2) =
                                   (ushort)iVar50 | 0x8000;
                              iVar50 = (*(int *)((longlong)&sStackX_10 + lVar20 + 4) -
                                       *(int *)(&stack0x00000094 + lVar20)) + -2;
                            }
                            *(ushort *)
                             (lVar24 + 2 + (ulonglong)*(ushort *)(&stack0x0000002c + lVar20) * 2) =
                                 (ushort)iVar50 | 0x8000;
                            lVar27 = (longlong)&sStackX_10 + lVar20 + 2;
                            if (iVar16 == 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1035ad;
                              func_0x
                                        (lVar27,*(ushort *)(&stack0x0000002c + lVar20) + 1);
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) != 0) {
                                *(short *)(&stack0x0000002c + lVar20) =
                                     *(short *)(&stack0x0000002c + lVar20) + 1;
                                puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                *puVar52 = *puVar52 & 0xfffd;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1035cc;
                                func_0x(&stack0x0000003a + lVar20);
                              }
                            }
                            else {
                              puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                              *puVar52 = *puVar52 | 2;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1035df;
                              uVar14 = func_0x(lVar27,&stack0x00000190 + lVar20);
                              *(undefined2 *)(&stack0x0000003a + lVar20) = uVar14;
                            }
                            if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103605;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                              *(undefined4 *)(&stack0x00000094 + lVar20),
                                              &stack0x00000128 + lVar20);
                            }
                            if ((bVar53 & 1) != 0) {
                              puVar32 = &stack0x00000660;
                              goto LAB_;
                            }
                          }
                          else {
                            if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                              uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20);
                              uVar56 = (ulonglong)uVar39;
                              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x10) != 0) {
                                uVar39 = uVar39 + 2 +
                                         (*(ushort *)
                                           (*(byte **)((longlong)&pbStackX_18 + lVar20) + uVar56) +
                                          7 >> 3);
                                uVar56 = (ulonglong)uVar39;
                                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              }
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) == 0) {
                                *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar56;
                                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                                *(int *)(&stack0x00000028 + lVar20) = (int)uVar56;
                              }
                              else {
                                psVar21 = (short *)(*(byte **)((longlong)&pbStackX_18 + lVar20) +
                                                   uVar56);
                                sVar15 = *psVar21;
                                *(short *)(&stack0x0000002c + lVar20) = sVar15;
                                if (sVar15 == 0) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102750;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102759;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102773;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10278f;
                                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1027b5;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1027c3;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3
                                                 );
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                }
                                uVar39 = (int)uVar56 +
                                         (*(ushort *)(&stack0x0000002c + lVar20) + 1) * 2;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                                if (0x1f9e < uVar39) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1027f0;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1027f9;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102813;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10282f;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102855;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102863;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                }
                                uVar13 = psVar21[*(ushort *)(&stack0x0000002c + lVar20)];
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar13 & 0x7fff;
                                if ((uVar13 & 0x7fff) < uVar39) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102894;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10289d;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1028b7;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1028d3;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1028f9;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102907;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                }
                                do {
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  if (-1 < psVar21[(ulonglong)(uVar13 - 1) + 1]) break;
                                  lVar27 = uVar56 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                                  uVar18 = uVar39;
                                  if (uVar13 != 1) {
                                    uVar18 = *(ushort *)(lVar27 + -2 + (ulonglong)uVar13 * 2) &
                                             0x7fff;
                                  }
                                  if ((uVar18 < uVar39) ||
                                     ((*(ushort *)(lVar27 + (ulonglong)uVar13 * 2) & 0x7fff) <
                                      uVar18)) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10296a;
                                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20)
                                                    ,7);
                                    uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                                    uVar56 = (ulonglong)
                                             *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  }
                                  if ((uVar18 < uVar39) ||
                                     (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar18))
                                  goto LAB_;
                                  uVar13 = *(ushort *)
                                            ((ulonglong)uVar18 +
                                            *(longlong *)((longlong)&pbStackX_18 + lVar20));
                                  if (uVar13 == 5) {
                                    puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                    *puVar52 = *puVar52 | 2;
                                    *(short *)(&stack0x0000002c + lVar20) =
                                         *(short *)(&stack0x0000002c + lVar20) + -1;
                                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar18;
                                    lVar27 = (ulonglong)(uVar18 & 0xffff) +
                                             *(longlong *)((longlong)&pbStackX_18 + lVar20);
                                    uVar13 = *(ushort *)(lVar27 + 2);
                                    uVar38 = *(ushort *)(&stack0x0000003c + lVar20);
                                    if ((uVar13 >> 0xe & 1) == 0) {
                                      uVar38 = uVar38 & 0xc7ff;
                                    }
                                    else {
                                      uVar38 = uVar38 ^ (uVar13 ^ uVar38) & 0x3800;
                                    }
                                    *(ushort *)(&stack0x0000003c + lVar20) = uVar38;
                                    *(ushort *)(&stack0x0000003c + lVar20) =
                                         uVar38 ^ (uVar38 ^ *(ushort *)(lVar27 + 2)) & 0x7ff;
                                    break;
                                  }
                                  if (uVar13 < 0x400) break;
                                  puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                  *puVar52 = *puVar52 | 1;
                                  psVar55 = (short *)(&stack0x0000002c + lVar20);
                                  *psVar55 = *psVar55 + -1;
                                } while (*psVar55 != 0);
                              }
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x40) == 0) {
                                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                              }
                              else {
                                *(undefined4 *)(&stack0x00000036 + lVar20) =
                                     *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                                piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                                *piVar45 = *piVar45 + 0xe;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102a38;
                                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2)
                                ;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102a47;
                                func_0x(uVar23,&stack0x000001f0 + lVar20);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102a53;
                                iVar16 = func_0x(&stack0x000001f0 + lVar20);
                                piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                                *piVar45 = *piVar45 + iVar16;
                              }
                              if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                                 (*(ulonglong *)(&stack0x0000002e + lVar20) <
                                  (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                                  *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102a81;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102a8a;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102aa4;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ac0;
                                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ae6;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102af4;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),
                                                0x12);
                              }
                              if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b0c;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b15;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b2f;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b4b;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b71;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b7f;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                              }
                            }
LAB_:
                            uVar39 = -*puVar46;
                            if ((uVar44 != 0) || (uVar39 <= *(ushort *)(&stack0x0000002c + lVar20)))
                            {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ba4;
                              func_0x(&stack0x00000580 + lVar20);
                              pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              bVar53 = *pbVar29;
                              if ((bVar53 >> 6 & 1) != 0) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102bc6;
                                func_0x
                                          ((longlong)&sStackX_10 + lVar20 + 2,
                                           &stack0x00000580 + lVar20);
                                pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              if (uVar44 == 0) {
                                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
LAB_:
                                uVar18 = (uint)uVar13;
                              }
                              else {
                                if ((*pbVar29 & 0x20) == 0) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102be2;
                                  func_0x((longlong)&sStackX_10 + lVar20 + 2);
                                  pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                }
                                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                uVar18 = (uint)uVar13;
                                if (uVar39 <= uVar18) goto LAB_;
                                uVar40 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                puVar52 = (ushort *)(pbVar29 + uVar40);
                                uVar40 = uVar40 + 2 + uVar18 * 2;
                                uVar42 = (uVar39 - uVar13) * 2;
                                uVar43 = 0;
                                if (*puVar52 != 0) {
                                  do {
                                    uVar38 = puVar52[(ulonglong)uVar43 + 1];
                                    puVar52[(ulonglong)(uVar43 & 0xffff) + 1] =
                                         puVar52[(ulonglong)(uVar43 & 0xffff) + 1] & 0x8000;
                                    puVar52[(ulonglong)(uVar43 & 0xffff) + 1] =
                                         puVar52[(ulonglong)(uVar43 & 0xffff) + 1] |
                                         (uVar38 & 0x7fff) + (short)uVar42 & 0x7fff;
                                    uVar43 = uVar43 + 1;
                                  } while (uVar43 < *puVar52);
                                  pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                }
                                iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102c7a;
                                func_0x
                                          (pbVar29 + (ulonglong)uVar40 + (ulonglong)uVar42,
                                           pbVar29 + uVar40,iVar16 - uVar40);
                                piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                                *piVar45 = *piVar45 + uVar42;
                                uVar42 = *(int *)(&stack0x00000028 + lVar20) + uVar42;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar42;
                                if (uVar13 != 0) {
                                  uVar42 = puVar52[(ulonglong)(uVar18 - 1) + 1] & 0x7fff;
                                }
                                do {
                                  puVar52[(ulonglong)(uVar18 & 0xffff) + 1] =
                                       (ushort)uVar42 & 0x7fff;
                                  uVar18 = uVar18 + 1;
                                } while (uVar18 < uVar39);
                                *puVar52 = *puVar52 + (short)(uVar39 - uVar13);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102cbc;
                                iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2)
                                ;
                                if (iVar16 != 0) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102cd0;
                                  uVar14 = func_0x
                                                     ((longlong)&sStackX_10 + lVar20 + 2,
                                                      &stack0x00000188 + lVar20);
                                  *(undefined2 *)(&stack0x0000003a + lVar20) = uVar14;
                                }
                                uVar18 = uVar39 & 0xffff;
                                *(short *)(&stack0x0000002c + lVar20) = (short)uVar39;
                                pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                              if (uVar18 < uVar39) {
                                uVar18 = *(ushort *)(pbVar29 + (ulonglong)uVar18 * 2 + uVar56) &
                                         0x7fff;
                                uVar40 = 0;
                              }
                              else {
                                uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                                if (uVar39 != 1) {
                                  uVar18 = *(ushort *)
                                            (pbVar29 + (longlong)(int)uVar39 * 2 + (uVar56 - 2)) &
                                           0x7fff;
                                }
                                uVar13 = *(ushort *)(pbVar29 + (longlong)(int)uVar39 * 2 + uVar56);
                                if ((uVar18 < *(uint *)(&stack0x00000028 + lVar20)) ||
                                   ((uVar13 & 0x7fff) < uVar18)) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102d32;
                                  func_0x(pbVar29,7);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                }
                                uVar40 = (uVar13 & 0x7fff) - uVar18;
                              }
                              if (uVar44 != uVar40) {
                                puVar52 = (ushort *)(pbVar29 + uVar56);
                                uVar19 = *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102d6b;
                                uVar19 = func_0x(uVar19,uVar40 + uVar18);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102d87;
                                func_0x
                                          ((longlong)(int)uVar44 +
                                           *(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                           (ulonglong)uVar18,
                                           (longlong)(int)uVar40 +
                                           *(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                           (ulonglong)uVar18,uVar19);
                                uVar42 = uVar39 - 1;
                                if ((int)uVar42 < (int)(uint)*puVar52) {
                                  do {
                                    uVar13 = puVar52[(longlong)(int)uVar42 + 1];
                                    puVar52[((ulonglong)uVar42 & 0xffff) + 1] =
                                         puVar52[((ulonglong)uVar42 & 0xffff) + 1] & 0x8000;
                                    puVar52[((ulonglong)uVar42 & 0xffff) + 1] =
                                         puVar52[((ulonglong)uVar42 & 0xffff) + 1] |
                                         ((uVar13 & 0x7fff) - (short)uVar40) + (short)uVar44 &
                                         0x7fff;
                                    uVar42 = uVar42 + 1;
                                  } while ((int)uVar42 < (int)(uint)*puVar52);
                                }
                                piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                                *piVar45 = *piVar45 + (uVar44 - uVar40);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ddf;
                                iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2)
                                ;
                                if (iVar16 != 0) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102df3;
                                  uVar14 = func_0x
                                                     ((longlong)&sStackX_10 + lVar20 + 2,
                                                      &stack0x0000018c + lVar20);
                                  *(undefined2 *)(&stack0x0000003a + lVar20) = uVar14;
                                }
                                pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102e0d;
                              func_0x
                                        (pbVar29 + uVar18,*(undefined8 *)(&stack0x00000070 + lVar20)
                                         ,uVar44);
                              if ((uVar44 == 0) &&
                                 (uVar39 == *(ushort *)(&stack0x0000002c + lVar20))) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102e2b;
                                func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar39,1)
                                ;
                              }
                              if ((bVar53 >> 6 & 1) != 0) {
                                puVar32 = &stack0x00000580;
                                goto LAB_;
                              }
                              goto LAB_;
                            }
                          }
                        }
                        else {
                          bVar53 = (byte)*(ushort *)((longlong)puVar46 + 6);
                          if ((*(ushort *)((longlong)puVar46 + 6) & 8) == 0) {
                            if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                              uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20);
                              uVar56 = (ulonglong)uVar39;
                              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x10) != 0) {
                                uVar39 = uVar39 + 2 +
                                         (*(ushort *)
                                           (*(byte **)((longlong)&pbStackX_18 + lVar20) + uVar56) +
                                          7 >> 3);
                                uVar56 = (ulonglong)uVar39;
                                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              }
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) == 0) {
                                *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar56;
                                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                                *(int *)(&stack0x00000028 + lVar20) = (int)uVar56;
                              }
                              else {
                                puVar52 = (ushort *)
                                          (*(byte **)((longlong)&pbStackX_18 + lVar20) + uVar56);
                                uVar13 = *puVar52;
                                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                if (uVar13 == 0) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102212;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10221b;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102235;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102251;
                                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102277;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102285;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                }
                                uVar39 = (int)uVar56 + (uVar13 + 1) * 2;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                                if (0x1f9e < uVar39) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1022b6;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1022bf;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1022d9;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1022f5;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10231b;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102329;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                }
                                uVar41 = (ulonglong)uVar13;
                                uVar13 = puVar52[uVar41];
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar13 & 0x7fff;
                                if ((uVar13 & 0x7fff) < uVar39) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10235f;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102368;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102382;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10239e;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1023c4;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1023d2;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                }
                                do {
                                  if (-1 < (short)puVar52[(ulonglong)((int)uVar41 - 1) + 1]) break;
                                  lVar27 = uVar56 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                                  uVar18 = uVar39;
                                  if ((int)uVar41 != 1) {
                                    uVar18 = *(ushort *)(lVar27 + -2 + uVar41 * 2) & 0x7fff;
                                  }
                                  if ((uVar18 < uVar39) ||
                                     ((*(ushort *)(lVar27 + uVar41 * 2) & 0x7fff) < uVar18)) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10243a;
                                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20)
                                                    ,7);
                                    uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                    uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                                    uVar56 = (ulonglong)
                                             *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  }
                                  if ((uVar18 < uVar39) ||
                                     (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar18))
                                  goto LAB_;
                                  uVar13 = *(ushort *)
                                            ((ulonglong)uVar18 +
                                            *(longlong *)((longlong)&pbStackX_18 + lVar20));
                                  if (uVar13 == 5) {
                                    puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                    *puVar52 = *puVar52 | 2;
                                    *(short *)(&stack0x0000002c + lVar20) = (short)uVar41 + -1;
                                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar18;
                                    lVar27 = (ulonglong)(uVar18 & 0xffff) +
                                             *(longlong *)((longlong)&pbStackX_18 + lVar20);
                                    uVar13 = *(ushort *)(lVar27 + 2);
                                    uVar38 = *(ushort *)(&stack0x0000003c + lVar20);
                                    if ((uVar13 >> 0xe & 1) == 0) {
                                      uVar38 = uVar38 & 0xc7ff;
                                    }
                                    else {
                                      uVar38 = uVar38 ^ (uVar13 ^ uVar38) & 0x3800;
                                    }
                                    *(ushort *)(&stack0x0000003c + lVar20) = uVar38;
                                    *(ushort *)(&stack0x0000003c + lVar20) =
                                         uVar38 ^ (uVar38 ^ *(ushort *)(lVar27 + 2)) & 0x7ff;
                                    break;
                                  }
                                  if (uVar13 < 0x400) break;
                                  puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                  *puVar49 = *puVar49 | 1;
                                  uVar13 = (short)uVar41 - 1;
                                  uVar41 = (ulonglong)uVar13;
                                  *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                } while (uVar13 != 0);
                              }
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x40) == 0) {
                                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                              }
                              else {
                                *(undefined4 *)(&stack0x00000036 + lVar20) =
                                     *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                                piVar1 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                                *piVar1 = *piVar1 + 0xe;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10251b;
                                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2)
                                ;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10252a;
                                func_0x(uVar23,&stack0x000001e8 + lVar20);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102536;
                                iVar16 = func_0x(&stack0x000001e8 + lVar20);
                                piVar1 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                                *piVar1 = *piVar1 + iVar16;
                              }
                              if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                                 (*(ulonglong *)(&stack0x0000002e + lVar20) <
                                  (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                                  *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102564;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10256d;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102587;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1025a3;
                                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1025c9;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1025d7;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),
                                                0x12);
                              }
                              if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1025ef;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1025f8;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102612;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10262e;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102654;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102662;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                              }
                            }
LAB_:
                            uVar39 = *puVar46;
                            uVar18 = uVar39 + uVar44;
                            if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar18) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102687;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2,0,
                                              uVar18 - *(uint *)((longlong)&uStackX_20 + lVar20),0);
                              if ((1 << (**(byte **)((longlong)&pbStackX_18 + lVar20) & 0xe) &
                                  0x1105U) != 0) {
                                *(short *)(*(byte **)((longlong)&pbStackX_18 + lVar20) + 2) =
                                     (short)uVar18;
                              }
                              *(uint *)((longlong)&uStackX_20 + lVar20) = uVar18;
                              uVar39 = *puVar46;
                            }
                            if ((piVar45 != (int *)0x0) && (uVar44 != 0)) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1026ce;
                              func_0x
                                        ((longlong)(int)uVar39 +
                                         *(longlong *)((longlong)&pbStackX_18 + lVar20),piVar45,
                                         uVar44);
                            }
                          }
                          else {
                            cVar10 = *(char *)piVar45;
                            uVar39 = uVar18 + 1;
                            if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar39) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10214a;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2,0,
                                              uVar39 - *(uint *)((longlong)&uStackX_20 + lVar20),0);
                              pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              if ((1 << (*pbVar29 & 0xe) & 0x1105U) != 0) {
                                *(short *)(pbVar29 + 2) = (short)uVar39;
                                pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              *(uint *)((longlong)&uStackX_20 + lVar20) = uVar39;
                              bVar53 = *(byte *)((longlong)puVar46 + 6);
                            }
                            else {
                              pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            }
                            if (cVar10 == '\0') {
                              pbVar29[(int)uVar18] =
                                   pbVar29[(int)uVar18] & ~(byte)(1 << (bVar53 & 7));
                            }
                            else {
                              pbVar29[(int)uVar18] =
                                   pbVar29[(int)uVar18] | (byte)(1 << (bVar53 & 7));
                            }
                          }
                        }
                      }
                      else {
                        if (cVar10 != '\b') {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0x14edeb8;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100aa7;
                          (*_DAT_)(1,0x18f2d10,0x191f650);
                          goto LAB_;
                        }
                        pbVar29 = *(byte **)(&stack0x000000d8 + lVar20);
                        uVar39 = *puVar46;
                        if ((int)uVar39 < 0) {
                          if ((uVar39 & 0xc0000000) == 0x80000000) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1017d8;
                            func_0x(&stack0x000004a0 + lVar20);
                            *(undefined4 *)(&stack0x00000090 + lVar20) = 0;
                            if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                              uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20);
                              uVar56 = (ulonglong)uVar39;
                              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              if ((*pbVar54 & 0x10) != 0) {
                                uVar39 = uVar39 + 2 + (*(ushort *)(pbVar54 + uVar56) + 7 >> 3);
                                uVar56 = (ulonglong)uVar39;
                                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              }
                              uVar39 = (uint)uVar56;
                              if ((*pbVar54 & 0x20) == 0) {
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                              }
                              else {
                                puVar52 = (ushort *)(pbVar54 + uVar56);
                                uVar13 = *puVar52;
                                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                if (uVar13 == 0) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10183f;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101848;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101862;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10187e;
                                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1018a4;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1018b2;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                }
                                uVar44 = (int)uVar56 + (uVar13 + 1) * 2;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar44;
                                if (0x1f9e < uVar44) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1018e6;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1018ef;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101909;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101925;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10194b;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101959;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                }
                                uVar41 = (ulonglong)uVar13;
                                uVar39 = puVar52[uVar41] & 0x7fff;
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                                if (uVar39 < uVar44) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101993;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10199c;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1019b6;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1019d2;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1019f8;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101a06;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                  uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                  uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                                }
                                do {
                                  if (-1 < (short)puVar52[(ulonglong)((int)uVar41 - 1) + 1]) break;
                                  uVar18 = uVar44;
                                  if ((int)uVar41 != 1) {
                                    uVar18 = *(ushort *)(pbVar54 + uVar41 * 2 + (uVar56 - 2)) &
                                             0x7fff;
                                  }
                                  if ((uVar18 < uVar44) ||
                                     ((*(ushort *)(pbVar54 + uVar41 * 2 + uVar56) & 0x7fff) < uVar18
                                     )) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101a71;
                                    func_0x(pbVar54,7);
                                    uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                    uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                                    uVar56 = (ulonglong)
                                             *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                    pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                    uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                                  }
                                  if ((uVar18 < uVar44) || (uVar39 < uVar18)) goto LAB_;
                                  if (*(ushort *)(pbVar54 + uVar18) == 5) {
                                    puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                    *puVar52 = *puVar52 | 2;
                                    *(short *)(&stack0x0000002c + lVar20) = (short)uVar41 + -1;
                                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar18;
                                    uVar13 = *(ushort *)(&stack0x0000003c + lVar20);
                                    if ((*(ushort *)(pbVar54 + (ulonglong)(uVar18 & 0xffff) + 2) >>
                                         0xe & 1) == 0) {
                                      uVar13 = uVar13 & 0xc7ff;
                                    }
                                    else {
                                      uVar13 = uVar13 ^ (*(ushort *)
                                                          (pbVar54 +
                                                          (ulonglong)(uVar18 & 0xffff) + 2) ^ uVar13
                                                        ) & 0x3800;
                                    }
                                    *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                                    *(ushort *)(&stack0x0000003c + lVar20) =
                                         uVar13 ^ (uVar13 ^ *(ushort *)
                                                             (pbVar54 +
                                                             (ulonglong)(uVar18 & 0xffff) + 2)) &
                                                  0x7ff;
                                    break;
                                  }
                                  if (*(ushort *)(pbVar54 + uVar18) < 0x400) break;
                                  puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                  *puVar49 = *puVar49 | 1;
                                  uVar13 = (short)uVar41 - 1;
                                  uVar41 = (ulonglong)uVar13;
                                  *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                } while (uVar13 != 0);
                              }
                              if ((*pbVar54 & 0x40) == 0) {
                                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                              }
                              else {
                                *(uint *)(&stack0x00000036 + lVar20) = uVar39;
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39 + 0xe;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101b58;
                                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2)
                                ;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101b67;
                                func_0x(uVar23,&stack0x000001e0 + lVar20);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101b73;
                                iVar16 = func_0x(&stack0x000001e0 + lVar20);
                                uVar39 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar16;
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                                pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              if ((*(byte **)(&stack0x0000002e + lVar20) != (byte *)0x0) &&
                                 (*(byte **)(&stack0x0000002e + lVar20) < pbVar54 + uVar39)) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101bb0;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101bb9;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101bd3;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101bef;
                                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c15;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c23;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),
                                                0x12);
                                uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                              }
                              if (0x3f3b < uVar39 - 1) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c3e;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c47;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c61;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c7d;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101ca3;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101cb1;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                              }
                            }
LAB_:
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101cba;
                            func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            bVar53 = **(byte **)((longlong)&pbStackX_18 + lVar20) >> 6;
                            if ((bVar53 & 1) != 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101cdc;
                              func_0x
                                        ((longlong)&sStackX_10 + lVar20 + 2,
                                         &stack0x000004a0 + lVar20);
                            }
                            if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101cf7;
                              puVar26 = (undefined4 *)
                                        func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                                        &stack0x00000090 + lVar20);
                              *(undefined4 *)(&stack0x00000120 + lVar20) = *puVar26;
                              *(undefined2 *)(&stack0x00000124 + lVar20) =
                                   *(undefined2 *)(puVar26 + 1);
                              *(undefined2 *)(&stack0x00000126 + lVar20) =
                                   *(undefined2 *)((longlong)puVar26 + 6);
                            }
                            if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) == 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101d27;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            }
                            lVar24 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4) +
                                     *(longlong *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101d37;
                            iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                            if (iVar16 == 0) {
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                              uVar18 = (uint)uVar13;
                              uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                              puVar52 = (ushort *)(lVar27 + (ulonglong)uVar39);
                              uVar39 = uVar39 + 2 + uVar18 * 2;
                              uVar44 = 0;
                              if (*puVar52 != 0) {
                                do {
                                  uVar38 = puVar52[(ulonglong)uVar44 + 1];
                                  puVar52[(ulonglong)(uVar44 & 0xffff) + 1] =
                                       puVar52[(ulonglong)(uVar44 & 0xffff) + 1] & 0x8000;
                                  puVar52[(ulonglong)(uVar44 & 0xffff) + 1] =
                                       puVar52[(ulonglong)(uVar44 & 0xffff) + 1] |
                                       (uVar38 & 0x7fff) + 2 & 0x7fff;
                                  uVar44 = uVar44 + 1;
                                } while (uVar44 < *puVar52);
                                lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                              }
                              iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101e1a;
                              func_0x
                                        ((ulonglong)uVar39 + 2 + lVar27,(ulonglong)uVar39 + lVar27,
                                         iVar16 - uVar39);
                              piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                              *piVar45 = *piVar45 + 2;
                              uVar39 = *(int *)(&stack0x00000028 + lVar20) + 2;
                              *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                              if (uVar13 != 0) {
                                uVar39 = puVar52[(ulonglong)(uVar18 - 1) + 1] & 0x7fff;
                              }
                              uVar44 = uVar18 + 1;
                              if (uVar18 < uVar44) {
                                do {
                                  puVar52[(ulonglong)(uVar18 & 0xffff) + 1] =
                                       (ushort)uVar39 & 0x7fff;
                                  uVar18 = uVar18 + 1;
                                } while (uVar18 < uVar44);
                              }
                              *puVar52 = *puVar52 + 1;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101e6a;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2);
                              iVar50 = 0;
                              uVar13 = *(ushort *)
                                        (lVar24 + 2 +
                                        (ulonglong)*(ushort *)(&stack0x0000002c + lVar20) * 2);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101e81;
                              func_0x(&stack0x00000320 + lVar20);
                              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0;
                              *(uint **)(&stack0xffffffffffffffe0 + lVar20) = puVar46;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101ea0;
                              func_0x(&stack0x00000310 + lVar20,pbVar29,1,0);
                              *(undefined **)(&stack0xffffffffffffffe8 + lVar20) =
                                   &stack0x00000158 + lVar20;
                              *(undefined **)(&stack0xffffffffffffffe0 + lVar20) =
                                   &stack0x00000310 + lVar20;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101ed4;
                              func_0x(&stack0x0000003a + lVar20,uVar13 & 0x7fff,0x1f9e);
                              iVar16 = *(int *)(&stack0x00000158 + lVar20);
                            }
                            else {
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                              lVar25 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4) +
                                       lVar27;
                              uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                              if (uVar13 != 0) {
                                uVar39 = *(ushort *)(lVar25 + (ulonglong)uVar13 * 2) & 0x7fff;
                              }
                              uVar44 = *(ushort *)(lVar25 + 2 + (ulonglong)(uint)uVar13 * 2) &
                                       0x7fff;
                              if ((uVar39 < *(uint *)(&stack0x00000028 + lVar20)) ||
                                 (uVar44 < uVar39)) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101d85;
                                func_0x(lVar27,7);
                              }
                              iVar50 = uVar44 - uVar39;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101d9c;
                              iVar16 = func_0x(&stack0x0000003a + lVar20,puVar46,pbVar29);
                            }
                            iVar50 = (*(int *)((longlong)&sStackX_10 + lVar20 + 4) - iVar50) +
                                     iVar16;
                            *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar50;
                            if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                              *(ushort *)
                               (lVar24 + 2 +
                               (ulonglong)(*(ushort *)(&stack0x0000002c + lVar20) + 1) * 2) =
                                   (ushort)iVar50 | 0x8000;
                              iVar50 = (*(int *)((longlong)&sStackX_10 + lVar20 + 4) -
                                       *(int *)(&stack0x00000090 + lVar20)) + -2;
                            }
                            *(ushort *)
                             (lVar24 + 2 + (ulonglong)*(ushort *)(&stack0x0000002c + lVar20) * 2) =
                                 (ushort)iVar50 | 0x8000;
                            lVar27 = (longlong)&sStackX_10 + lVar20 + 2;
                            if (iVar16 == 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101f28;
                              func_0x
                                        (lVar27,*(ushort *)(&stack0x0000002c + lVar20) + 1);
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) != 0) {
                                *(short *)(&stack0x0000002c + lVar20) =
                                     *(short *)(&stack0x0000002c + lVar20) + 1;
                                puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                *puVar52 = *puVar52 & 0xfffd;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101f47;
                                func_0x(&stack0x0000003a + lVar20);
                              }
                            }
                            else {
                              puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                              *puVar52 = *puVar52 | 2;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101f5a;
                              uVar14 = func_0x(lVar27,&stack0x00000184 + lVar20);
                              *(undefined2 *)(&stack0x0000003a + lVar20) = uVar14;
                            }
                            if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101f80;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                              *(undefined4 *)(&stack0x00000090 + lVar20));
                            }
                            if ((bVar53 & 1) != 0) {
                              puVar32 = &stack0x000004a0;
LAB_:
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101f95;
                              func_0x
                                        ((longlong)&sStackX_10 + lVar20 + 2,
                                         (longlong)puVar32 + lVar20);
                            }
                          }
                          else {
                            if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                              uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20);
                              uVar56 = (ulonglong)uVar39;
                              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              if ((*pbVar54 & 0x10) != 0) {
                                uVar39 = uVar39 + 2 + (*(ushort *)(pbVar54 + uVar56) + 7 >> 3);
                                uVar56 = (ulonglong)uVar39;
                                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              }
                              uVar39 = (uint)uVar56;
                              if ((*pbVar54 & 0x20) == 0) {
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                              }
                              else {
                                puVar52 = (ushort *)(pbVar54 + uVar56);
                                uVar13 = *puVar52;
                                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                if (uVar13 == 0) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1010d7;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1010e0;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1010fa;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101116;
                                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10113c;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10114a;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                }
                                uVar44 = (int)uVar56 + (uVar13 + 1) * 2;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar44;
                                if (0x1f9e < uVar44) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10117e;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101187;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1011a1;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1011bd;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1011e3;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1011f1;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                }
                                uVar41 = (ulonglong)uVar13;
                                uVar39 = puVar52[uVar41] & 0x7fff;
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                                if (uVar39 < uVar44) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10122b;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101234;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10124e;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10126a;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101290;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10129e;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                  uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                  uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                                }
                                do {
                                  if (-1 < (short)puVar52[(ulonglong)((int)uVar41 - 1) + 1]) break;
                                  uVar18 = uVar44;
                                  if ((int)uVar41 != 1) {
                                    uVar18 = *(ushort *)(pbVar54 + uVar41 * 2 + (uVar56 - 2)) &
                                             0x7fff;
                                  }
                                  if ((uVar18 < uVar44) ||
                                     ((*(ushort *)(pbVar54 + uVar41 * 2 + uVar56) & 0x7fff) < uVar18
                                     )) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101311;
                                    func_0x(pbVar54,7);
                                    uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                    uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                                    uVar56 = (ulonglong)
                                             *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                    pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                                    uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                                  }
                                  if ((uVar18 < uVar44) || (uVar39 < uVar18)) goto LAB_;
                                  if (*(ushort *)(pbVar54 + uVar18) == 5) {
                                    puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                    *puVar52 = *puVar52 | 2;
                                    *(short *)(&stack0x0000002c + lVar20) = (short)uVar41 + -1;
                                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar18;
                                    uVar13 = *(ushort *)(&stack0x0000003c + lVar20);
                                    if ((*(ushort *)(pbVar54 + (ulonglong)(uVar18 & 0xffff) + 2) >>
                                         0xe & 1) == 0) {
                                      uVar13 = uVar13 & 0xc7ff;
                                    }
                                    else {
                                      uVar13 = uVar13 ^ (*(ushort *)
                                                          (pbVar54 +
                                                          (ulonglong)(uVar18 & 0xffff) + 2) ^ uVar13
                                                        ) & 0x3800;
                                    }
                                    *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                                    *(ushort *)(&stack0x0000003c + lVar20) =
                                         uVar13 ^ (uVar13 ^ *(ushort *)
                                                             (pbVar54 +
                                                             (ulonglong)(uVar18 & 0xffff) + 2)) &
                                                  0x7ff;
                                    break;
                                  }
                                  if (*(ushort *)(pbVar54 + uVar18) < 0x400) break;
                                  puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                  *puVar49 = *puVar49 | 1;
                                  uVar13 = (short)uVar41 - 1;
                                  uVar41 = (ulonglong)uVar13;
                                  *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                } while (uVar13 != 0);
                              }
                              if ((*pbVar54 & 0x40) == 0) {
                                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                              }
                              else {
                                *(uint *)(&stack0x00000036 + lVar20) = uVar39;
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39 + 0xe;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1013ee;
                                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2)
                                ;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1013fd;
                                func_0x(uVar23,&stack0x000001d8 + lVar20);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101409;
                                iVar16 = func_0x(&stack0x000001d8 + lVar20);
                                uVar39 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar16;
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                                pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              if ((*(byte **)(&stack0x0000002e + lVar20) != (byte *)0x0) &&
                                 (*(byte **)(&stack0x0000002e + lVar20) < pbVar54 + uVar39)) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101446;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10144f;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101469;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101485;
                                      (*_DAT_)(0x22,0x44,0x15);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1014ab;
                                      (*_DAT_)(1,0x17719d8,0x18916a8);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1014b9;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),
                                                0x12);
                                uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                              }
                              if (0x3f3b < uVar39 - 1) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1014d4;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1014dd;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1014f7;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101513;
                                      (*_DAT_)(0x22,0x44,0x15);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101539;
                                      (*_DAT_)(1,0x17719d8,0x18916a8);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101547;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                              }
                            }
LAB_:
                            uVar39 = -*puVar46;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10155a;
                            func_0x(&stack0x000003c0 + lVar20);
                            pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            bVar53 = *pbVar54;
                            if ((bVar53 >> 6 & 1) != 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10157c;
                              func_0x
                                        ((longlong)&sStackX_10 + lVar20 + 2,
                                         &stack0x000003c0 + lVar20);
                              pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            }
                            if ((*pbVar54 & 0x20) == 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10158f;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2);
                              pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            }
                            uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            uVar18 = (uint)uVar13;
                            uVar44 = (uint)uVar13;
                            if (uVar44 < uVar39) {
                              uVar18 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                              puVar52 = (ushort *)(pbVar54 + uVar18);
                              uVar18 = uVar18 + 2 + uVar44 * 2;
                              uVar40 = (uVar39 - uVar13) * 2;
                              uVar42 = 0;
                              if (*puVar52 != 0) {
                                do {
                                  uVar38 = puVar52[(ulonglong)uVar42 + 1];
                                  puVar52[(ulonglong)(uVar42 & 0xffff) + 1] =
                                       puVar52[(ulonglong)(uVar42 & 0xffff) + 1] & 0x8000;
                                  puVar52[(ulonglong)(uVar42 & 0xffff) + 1] =
                                       puVar52[(ulonglong)(uVar42 & 0xffff) + 1] |
                                       (uVar38 & 0x7fff) + (short)uVar40 & 0x7fff;
                                  uVar42 = uVar42 + 1;
                                } while (uVar42 < *puVar52);
                                pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10161a;
                              func_0x
                                        (pbVar54 + (ulonglong)uVar18 + (ulonglong)uVar40,
                                         pbVar54 + uVar18,iVar16 - uVar18);
                              piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                              *piVar45 = *piVar45 + uVar40;
                              uVar40 = *(int *)(&stack0x00000028 + lVar20) + uVar40;
                              *(uint *)(&stack0x00000028 + lVar20) = uVar40;
                              if (uVar13 != 0) {
                                uVar40 = puVar52[(ulonglong)(uVar44 - 1) + 1] & 0x7fff;
                              }
                              do {
                                puVar52[(ulonglong)(uVar44 & 0xffff) + 1] = (ushort)uVar40 & 0x7fff;
                                uVar44 = uVar44 + 1;
                              } while (uVar44 < uVar39);
                              *puVar52 = *puVar52 + (short)(uVar39 - uVar13);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10165c;
                              iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                              if (iVar16 != 0) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101670;
                                uVar14 = func_0x
                                                   ((longlong)&sStackX_10 + lVar20 + 2,
                                                    &stack0x0000017c + lVar20);
                                *(undefined2 *)(&stack0x0000003a + lVar20) = uVar14;
                              }
                              uVar18 = uVar39 & 0xffff;
                              *(short *)(&stack0x0000002c + lVar20) = (short)uVar39;
                              pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            }
                            uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                            if (uVar18 < uVar39) {
                              uVar44 = *(ushort *)(pbVar54 + uVar56 + (ulonglong)uVar18 * 2) &
                                       0x7fff;
                              iVar16 = 0;
LAB_:
                              puVar52 = (ushort *)(pbVar54 + uVar56);
                              uVar19 = *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101707;
                              uVar19 = func_0x(uVar19,iVar16 + uVar44);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101723;
                              func_0x
                                        (*(longlong *)((longlong)&pbStackX_18 + lVar20) + 1 +
                                         (ulonglong)uVar44,
                                         (longlong)iVar16 +
                                         *(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                         (ulonglong)uVar44,uVar19);
                              uVar39 = uVar39 - 1;
                              if ((int)uVar39 < (int)(uint)*puVar52) {
                                do {
                                  uVar13 = puVar52[(longlong)(int)uVar39 + 1];
                                  puVar52[((ulonglong)uVar39 & 0xffff) + 1] =
                                       puVar52[((ulonglong)uVar39 & 0xffff) + 1] & 0x8000;
                                  puVar52[((ulonglong)uVar39 & 0xffff) + 1] =
                                       puVar52[((ulonglong)uVar39 & 0xffff) + 1] |
                                       ((uVar13 & 0x7fff) - (short)iVar16) + 1 & 0x7fff;
                                  uVar39 = uVar39 + 1;
                                } while ((int)uVar39 < (int)(uint)*puVar52);
                              }
                              piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                              *piVar45 = *piVar45 + (1 - iVar16);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101780;
                              iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                              if (iVar16 != 0) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101794;
                                uVar14 = func_0x
                                                   ((longlong)&sStackX_10 + lVar20 + 2,
                                                    &stack0x00000180 + lVar20);
                                *(undefined2 *)(&stack0x0000003a + lVar20) = uVar14;
                              }
                              pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            }
                            else {
                              uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                              if (uVar39 != 1) {
                                uVar44 = *(ushort *)
                                          (pbVar54 + uVar56 + (longlong)(int)uVar39 * 2 + -2) &
                                         0x7fff;
                              }
                              uVar18 = *(ushort *)(pbVar54 + uVar56 + (longlong)(int)uVar39 * 2) &
                                       0x7fff;
                              if ((uVar44 < *(uint *)(&stack0x00000028 + lVar20)) ||
                                 (uVar18 < uVar44)) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1016ce;
                                func_0x(pbVar54,7);
                                uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                pbVar54 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              iVar16 = uVar18 - uVar44;
                              if (iVar16 != 1) goto LAB_;
                            }
                            pbVar54[uVar44] = *pbVar29;
                            if ((bVar53 >> 6 & 1) != 0) {
                              puVar32 = &stack0x000003c0;
LAB_:
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1017bd;
                              func_0x
                                        ((longlong)&sStackX_10 + lVar20 + 2,
                                         (longlong)puVar32 + lVar20);
                            }
LAB_:
                            puVar46 = *(uint **)(&stack0x00000068 + lVar20);
                          }
                        }
                        else {
                          bVar53 = (byte)*(ushort *)((longlong)puVar46 + 6);
                          if ((*(ushort *)((longlong)puVar46 + 6) & 8) == 0) {
                            if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                              uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20);
                              uVar56 = (ulonglong)uVar39;
                              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x10) != 0) {
                                uVar39 = uVar39 + 2 +
                                         (*(ushort *)
                                           (*(byte **)((longlong)&pbStackX_18 + lVar20) + uVar56) +
                                          7 >> 3);
                                uVar56 = (ulonglong)uVar39;
                                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
                              }
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) == 0) {
                                *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar56;
                                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                                *(int *)(&stack0x00000028 + lVar20) = (int)uVar56;
                              }
                              else {
                                puVar52 = (ushort *)
                                          (*(byte **)((longlong)&pbStackX_18 + lVar20) + uVar56);
                                uVar13 = *puVar52;
                                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                if (uVar13 == 0) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ba9;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100bb2;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100bcc;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100be8;
                                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100c0e;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100c1c;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                }
                                uVar39 = (int)uVar56 + (uVar13 + 1) * 2;
                                *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                                if (0x1f9e < uVar39) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100c4d;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100c56;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100c70;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100c8c;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100cb2;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100cc0;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                }
                                uVar41 = (ulonglong)uVar13;
                                uVar13 = puVar52[uVar41];
                                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar13 & 0x7fff;
                                if ((uVar13 & 0x7fff) < uVar39) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100cf6;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100cff;
                                    lVar27 = func_0x();
                                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100d19;
                                      cVar10 = func_0x(0x1e80c50);
                                      if (cVar10 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100d35;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100d5b;
                                        (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                                      }
                                    }
                                  }
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100d69;
                                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4
                                                 );
                                  uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                                  uVar56 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                }
                                do {
                                  if (-1 < (short)puVar52[(ulonglong)((int)uVar41 - 1) + 1]) break;
                                  lVar27 = uVar56 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                                  uVar44 = uVar39;
                                  if ((int)uVar41 != 1) {
                                    uVar44 = *(ushort *)(lVar27 + -2 + uVar41 * 2) & 0x7fff;
                                  }
                                  if ((uVar44 < uVar39) ||
                                     ((*(ushort *)(lVar27 + uVar41 * 2) & 0x7fff) < uVar44)) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100dda;
                                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20)
                                                    ,7);
                                    uVar41 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                                    uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                                    uVar56 = (ulonglong)
                                             *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                                  }
                                  if ((uVar44 < uVar39) ||
                                     (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar44))
                                  goto LAB_;
                                  uVar13 = *(ushort *)
                                            ((ulonglong)uVar44 +
                                            *(longlong *)((longlong)&pbStackX_18 + lVar20));
                                  if (uVar13 == 5) {
                                    puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                    *puVar52 = *puVar52 | 2;
                                    *(short *)(&stack0x0000002c + lVar20) = (short)uVar41 + -1;
                                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar44;
                                    lVar27 = (ulonglong)(uVar44 & 0xffff) +
                                             *(longlong *)((longlong)&pbStackX_18 + lVar20);
                                    uVar13 = *(ushort *)(lVar27 + 2);
                                    uVar38 = *(ushort *)(&stack0x0000003c + lVar20);
                                    if ((uVar13 >> 0xe & 1) == 0) {
                                      uVar38 = uVar38 & 0xc7ff;
                                    }
                                    else {
                                      uVar38 = uVar38 ^ (uVar13 ^ uVar38) & 0x3800;
                                    }
                                    *(ushort *)(&stack0x0000003c + lVar20) = uVar38;
                                    *(ushort *)(&stack0x0000003c + lVar20) =
                                         uVar38 ^ (uVar38 ^ *(ushort *)(lVar27 + 2)) & 0x7ff;
                                    break;
                                  }
                                  if (uVar13 < 0x400) break;
                                  puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                  *puVar49 = *puVar49 | 1;
                                  uVar13 = (short)uVar41 - 1;
                                  uVar41 = (ulonglong)uVar13;
                                  *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                                } while (uVar13 != 0);
                              }
                              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x40) == 0) {
                                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                              }
                              else {
                                *(undefined4 *)(&stack0x00000036 + lVar20) =
                                     *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                                piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                                *piVar45 = *piVar45 + 0xe;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ebb;
                                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2)
                                ;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100eca;
                                func_0x(uVar23,&stack0x000001d0 + lVar20);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ed6;
                                iVar16 = func_0x(&stack0x000001d0 + lVar20);
                                piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                                *piVar45 = *piVar45 + iVar16;
                              }
                              if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                                 (*(ulonglong *)(&stack0x0000002e + lVar20) <
                                  (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                                  *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f04;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f0d;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f27;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f43;
                                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f69;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f77;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),
                                                0x12);
                              }
                              if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f8f;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 != '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f98;
                                  lVar27 = func_0x();
                                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100fb2;
                                    cVar10 = func_0x(0x1e80c50);
                                    if (cVar10 == '\0') {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100fce;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                    }
                                    else {
                                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ff4;
                                      (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                                    }
                                  }
                                }
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101002;
                                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                              }
                            }
LAB_:
                            uVar44 = *puVar46;
                            uVar39 = uVar44 + 1;
                            if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar39) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101026;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2,0,
                                              uVar39 - *(uint *)((longlong)&uStackX_20 + lVar20),0);
                              if ((1 << (**(byte **)((longlong)&pbStackX_18 + lVar20) & 0xe) &
                                  0x1105U) != 0) {
                                *(short *)(*(byte **)((longlong)&pbStackX_18 + lVar20) + 2) =
                                     (short)uVar39;
                              }
                              *(uint *)((longlong)&uStackX_20 + lVar20) = uVar39;
                              uVar44 = *puVar46;
                            }
                            if (pbVar29 != (byte *)0x0) {
                              *(byte *)((longlong)(int)uVar44 +
                                       *(longlong *)((longlong)&pbStackX_18 + lVar20)) = *pbVar29;
                            }
                          }
                          else {
                            bVar11 = *pbVar29;
                            uVar44 = uVar39 + 1;
                            if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar44) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100aed;
                              func_0x((longlong)&sStackX_10 + lVar20 + 2,0,
                                              uVar44 - *(uint *)((longlong)&uStackX_20 + lVar20),0);
                              pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              if ((1 << (*pbVar29 & 0xe) & 0x1105U) != 0) {
                                *(short *)(pbVar29 + 2) = (short)uVar44;
                                pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                              }
                              *(uint *)((longlong)&uStackX_20 + lVar20) = uVar44;
                              bVar53 = *(byte *)((longlong)puVar46 + 6);
                            }
                            else {
                              pbVar29 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            }
                            if (bVar11 == 0) {
                              pbVar29[(int)uVar39] =
                                   pbVar29[(int)uVar39] & ~(byte)(1 << (bVar53 & 7));
                            }
                            else {
                              pbVar29[(int)uVar39] =
                                   pbVar29[(int)uVar39] | (byte)(1 << (bVar53 & 7));
                            }
                          }
                        }
                      }
                      param_3 = *(longlong **)(&stack0x00000050 + lVar20);
                    }
                    uVar39 = *(uint *)(&stack0x00000048 + lVar20);
                  }
LAB_:
                  puVar46 = puVar46 + 0x14;
                  *(uint **)(&stack0x00000068 + lVar20) = puVar46;
                  uVar39 = uVar39 + 1;
                  *(uint *)(&stack0x00000048 + lVar20) = uVar39;
                } while (uVar39 < *(uint *)(&stack0x0000005c + lVar20));
              }
            }
            else {
              piVar45 = *(int **)(lVar24 + 0x70);
              if (*(ushort *)(lVar24 + 0x62) != 0) {
                uVar56 = (ulonglong)*(ushort *)(lVar24 + 0x62);
                lVar27 = *(longlong *)(&stack0x00000050 + lVar20);
                do {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10089b;
                  cVar10 = func_0x(lVar27,piVar45);
                  if (cVar10 == '\x03') {
                    if ((piVar45[0x10] & 0x4000U) == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1009c1;
                      (*_DAT_)(6,0x51,0x10,4);
                    }
                    uVar14 = *(undefined2 *)(piVar45 + 0xf);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1009d8;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,piVar45,uVar14,1);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1008af;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,piVar45);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1008c1;
                    func_0x(lVar27,piVar45,&stack0x000001c8 + lVar20);
                    lVar24 = *(longlong *)(&stack0x000001c8 + lVar20);
                    if (((uint)piVar45[0x10] >> 8 & 1) == 0) {
                      iVar16 = *piVar45;
                      uVar14 = *(undefined2 *)(piVar45 + 0xf);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1008e5;
                      func_0x
                                ((longlong)iVar16 + *(longlong *)((longlong)&pbStackX_18 + lVar20),
                                 lVar24,uVar14);
                    }
                    else {
                      iVar16 = 0;
                      if (((piVar45[0x10] & 0x8000U) == 0) || ((*(byte *)(lVar27 + 0x14) & 8) == 0))
                      {
                        if ((*(byte *)(*(longlong *)(piVar45 + 0x12) + 0x2a) & 0x10) == 0) {
                          lVar27 = *(longlong *)(lVar27 + 0x18);
                        }
                        else {
                          lVar27 = *(longlong *)(lVar27 + 0x20);
                        }
                        uVar39 = *(uint *)(*(longlong *)(*(longlong *)(piVar45 + 0x12) + 0x18) +
                                          lVar27);
                      }
                      else {
                        uVar39 = *(uint *)(*(longlong *)(lVar27 + 0x38) +
                                          (ulonglong)(uint)piVar45[0xe] * 8);
                      }
                      uVar44 = (uint)*(ushort *)(piVar45 + 0xf);
                      if (uVar39 < uVar44) {
                        iVar16 = uVar44 - uVar39;
                      }
                      else if (uVar44 < uVar39) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100946;
                        (*_DAT_)(6,0x5c,0x16,1);
                      }
                      uVar12 = *(undefined *)(*(longlong *)(piVar45 + 0x12) + 0x24);
                      lVar27 = (longlong)*piVar45 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      if ((lVar24 != 0) && (uVar39 != 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10096d;
                        func_0x(lVar27,lVar24,uVar39);
                      }
                      if (iVar16 != 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100982;
                        func_0x((ulonglong)uVar39 + lVar27,uVar12,iVar16);
                      }
                      lVar27 = *(longlong *)(&stack0x00000050 + lVar20);
                    }
                  }
                  piVar45 = piVar45 + 0x14;
                  uVar56 = uVar56 - 1;
                } while (uVar56 != 0);
              }
            }
            if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
              uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20);
              uVar56 = (ulonglong)uVar39;
              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x10) != 0) {
                uVar39 = uVar39 + 2 +
                         (*(ushort *)(*(byte **)((longlong)&pbStackX_18 + lVar20) + uVar56) + 7 >> 3
                         );
                uVar56 = (ulonglong)uVar39;
                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar39;
              }
              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) == 0) {
                *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar56;
                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                *(int *)(&stack0x00000028 + lVar20) = (int)uVar56;
              }
              else {
                puVar52 = (ushort *)(*(byte **)((longlong)&pbStackX_18 + lVar20) + uVar56);
                uVar13 = *puVar52;
                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                if (uVar13 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102022;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10202f;
                    lVar27 = func_0x();
                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102051;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102071;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103767;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103775;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                }
                uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar13 * 2;
                *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                if (0x1f9e < uVar39) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1037a4;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1037ad;
                    lVar27 = func_0x();
                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1037c7;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1037e3;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103809;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103817;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                }
                uVar56 = (ulonglong)uVar13;
                uVar13 = puVar52[uVar56];
                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar13 & 0x7fff;
                if ((uVar13 & 0x7fff) < uVar39) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103847;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103850;
                    lVar27 = func_0x();
                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10386a;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103886;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1038ac;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1038ba;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                  uVar56 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                }
                do {
                  if (-1 < (short)puVar52[(ulonglong)((int)uVar56 - 1) + 1]) break;
                  lVar27 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4) +
                           *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  uVar44 = uVar39;
                  if ((int)uVar56 != 1) {
                    uVar44 = *(ushort *)(lVar27 + -2 + uVar56 * 2) & 0x7fff;
                  }
                  if ((uVar44 < uVar39) || ((*(ushort *)(lVar27 + uVar56 * 2) & 0x7fff) < uVar44)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10391e;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),7);
                    uVar56 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                    uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                  }
                  if ((uVar44 < uVar39) || (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar44))
                  goto LAB_;
                  uVar13 = *(ushort *)
                            ((ulonglong)uVar44 + *(longlong *)((longlong)&pbStackX_18 + lVar20));
                  if (uVar13 == 5) {
                    puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar52 = *puVar52 | 2;
                    *(short *)(&stack0x0000002c + lVar20) = (short)uVar56 + -1;
                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar44;
                    lVar27 = (ulonglong)(uVar44 & 0xffff) +
                             *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    uVar13 = *(ushort *)(lVar27 + 2);
                    uVar38 = *(ushort *)(&stack0x0000003c + lVar20);
                    if ((uVar13 >> 0xe & 1) == 0) {
                      uVar38 = uVar38 & 0xc7ff;
                    }
                    else {
                      uVar38 = uVar38 ^ (uVar13 ^ uVar38) & 0x3800;
                    }
                    *(ushort *)(&stack0x0000003c + lVar20) = uVar38;
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         (uVar38 ^ *(ushort *)(lVar27 + 2)) & 0x7ff ^ uVar38;
                    break;
                  }
                  if (uVar13 < 0x400) break;
                  puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar49 = *puVar49 | 1;
                  uVar13 = (short)uVar56 - 1;
                  uVar56 = (ulonglong)uVar13;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                } while (uVar13 != 0);
              }
              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x40) == 0) {
                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
              }
              else {
                *(undefined4 *)(&stack0x00000036 + lVar20) =
                     *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                *piVar45 = *piVar45 + 0xe;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1039f6;
                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a05;
                func_0x(uVar23,&stack0x00000200 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a11;
                iVar16 = func_0x(&stack0x00000200 + lVar20);
                piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                *piVar45 = *piVar45 + iVar16;
              }
              if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                 (*(ulonglong *)(&stack0x0000002e + lVar20) <
                  (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                  *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a3e;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a47;
                  lVar27 = func_0x();
                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a61;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a7d;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103aa3;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103ab1;
                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
              }
              if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103ac9;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103ad2;
                  lVar27 = func_0x();
                  if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103aec;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103b08;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103b2e;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103b3c;
                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
              }
            }
LAB_:
            if (((8 < *(uint *)((longlong)&sStackX_10 + lVar20 + 4)) ||
                ((bVar53 = **(byte **)((longlong)&pbStackX_18 + lVar20) & 0xe,
                 puVar32 = &stack0xffffffffffffffc0 + lVar20, bVar53 != 0 &&
                 (puVar32 = &stack0xffffffffffffffc0 + lVar20, bVar53 != 0xc)))) &&
               (puVar32 = &stack0xffffffffffffffc0 + lVar20,
               0x3f3c < *(uint *)((longlong)&sStackX_10 + lVar20 + 4))) {
              uVar23 = 0xb8;
              puVar32 = &stack0xffffffffffffffc0 + lVar20;
LAB_:
              *(undefined8 *)(puVar32 + -8) = 0x105df1;
              (*_DAT_)(6,0x52,0x16,uVar23);
            }
          }
          else {
LAB_:
            *(undefined8 *)(&stack0x00000068 + lVar20) = 0;
            if ((*(byte *)((longlong)param_3 + 0x14) & 0x10) != 0) {
              puVar30 = (undefined8 *)*param_3;
            }
            *(undefined8 *)(&stack0x000000e0 + lVar20) = 0;
            *(undefined4 *)(&stack0x00000078 + lVar20) = 0;
            puVar30 = puVar30 + 2;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103ba1;
            iVar16 = func_0x(puVar30);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103bad;
            uVar44 = func_0x(puVar52);
            if ((uint)-iVar16 < uVar44) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103bbc;
              uVar44 = func_0x(puVar52);
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103bc9;
              iVar16 = func_0x(puVar30);
              uVar44 = -iVar16;
            }
            uVar56 = (ulonglong)uVar44;
            *(uint *)(&stack0x00000048 + lVar20) = uVar44;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103bdb;
            iVar16 = func_0x(puVar52);
            if (iVar16 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103bf3;
              cVar10 = func_0x
                                 (*(undefined8 *)(&stack0x00000050 + lVar20),
                                  &stack0x000000e0 + lVar20,&stack0x00000078 + lVar20);
              if (cVar10 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c09;
                uVar18 = func_0x(*(undefined8 *)(&stack0x000000e0 + lVar20),
                                         *(undefined4 *)(&stack0x00000078 + lVar20),puVar52);
                if (uVar44 <= uVar18) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c23;
                  uVar44 = func_0x(*(undefined8 *)(&stack0x000000e0 + lVar20),
                                           *(undefined4 *)(&stack0x00000078 + lVar20),puVar52);
                  uVar56 = (ulonglong)uVar44;
                  *(uint *)(&stack0x00000048 + lVar20) = uVar44;
                }
              }
            }
            uVar44 = (uint)uVar56;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c31;
            uVar18 = func_0x(puVar30);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c3b;
            uVar19 = func_0x(puVar30);
            *(undefined **)((longlong)&pbStackX_18 + lVar20) = &stack0x000028a0 + lVar20;
            *(undefined4 *)((longlong)&uStackX_20 + lVar20) = uVar19;
            *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
            *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
            *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c5f;
            cVar10 = func_0x(puVar52);
            lVar27 = (longlong)&sStackX_10 + lVar20 + 2;
            if (cVar10 == '\x06') {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c6c;
              puVar28 = (undefined *)func_0x(lVar27);
              *puVar28 = 6;
              uVar40 = 1;
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c7b;
              puVar28 = (undefined *)func_0x(lVar27);
              *puVar28 = 0;
              *(undefined *)(*(longlong *)((longlong)&pbStackX_18 + lVar20) + 1) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c92;
              func_0x
                        ((longlong)&sStackX_10 + lVar20 + 2,
                         *(undefined4 *)((longlong)&uStackX_20 + lVar20));
              uVar40 = 4;
            }
            uVar42 = *(uint *)(puVar22 + 8);
            if (*(uint *)((longlong)&uStackX_20 + lVar20) <= uVar42) {
              uVar42 = *(uint *)((longlong)&uStackX_20 + lVar20);
            }
            lVar27 = *(longlong *)(puVar22 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103cbc;
            func_0x
                      (*(longlong *)((longlong)&pbStackX_18 + lVar20) + (ulonglong)uVar40,
                       lVar27 + (ulonglong)uVar40,uVar42 - uVar40);
            if (uVar18 == 0) {
              *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                   *(undefined4 *)((longlong)&uStackX_20 + lVar20);
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103ccd;
              pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *pbVar29 = *pbVar29 | 0x10;
              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                   (uVar18 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20) + 2;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103ce9;
              pbVar29 = (byte *)func_0x(puVar52);
              if ((*pbVar29 & 0x10) == 0) {
                uVar40 = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103d85;
                func_0x(&stack0x000001a0 + lVar20);
                *(short *)((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                          *(longlong *)((longlong)&pbStackX_18 + lVar20)) = (short)uVar18;
              }
              else {
                lVar27 = *(longlong *)(puVar22 + 4);
                uVar13 = *(ushort *)((ulonglong)*(uint *)(puVar22 + 8) + lVar27);
                uVar40 = (uint)uVar13;
                if (uVar13 == uVar18) {
                  iVar16 = *(int *)((longlong)&uStackX_20 + lVar20 + 4);
                  uVar18 = *(uint *)(puVar22 + 8);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103d1a;
                  func_0x
                            ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                             *(longlong *)((longlong)&pbStackX_18 + lVar20),
                             (ulonglong)uVar18 + lVar27,
                             iVar16 - *(uint *)((longlong)&uStackX_20 + lVar20));
                  goto LAB_;
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103d2b;
                func_0x(&stack0x000001a0 + lVar20);
                *(short *)((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                          *(longlong *)((longlong)&pbStackX_18 + lVar20)) = (short)uVar18;
                if (uVar13 != 0) {
                  uVar43 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) -
                           *(uint *)((longlong)&uStackX_20 + lVar20);
                  uVar42 = *(uint *)(puVar22 + 8);
                  uVar17 = *(int *)(puVar22 + 10) - uVar42;
                  if (uVar17 <= uVar43) {
                    uVar43 = uVar17;
                  }
                  lVar27 = *(longlong *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103d74;
                  func_0x
                            (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                             (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) + 2,
                             lVar27 + (ulonglong)uVar42 + 2,uVar43 - 2);
                }
              }
              if (uVar18 < uVar40) {
                uVar40 = uVar18 & 0xffff;
              }
              uVar13 = (ushort)uVar40;
              while (uVar13 = uVar13 + 1, uVar13 <= uVar18) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103dbf;
                func_0x(&stack0x000001a0 + lVar20,uVar13);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103dcf;
                func_0x((longlong)&sStackX_10 + lVar20 + 2,&stack0x000001a0 + lVar20);
              }
            }
LAB_:
            uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
            *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
            *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
            if (uVar44 == 0) {
              lVar27 = *(longlong *)(&stack0x00000068 + lVar20);
            }
            else {
              uVar41 = uVar56 * 0x20 + 0xf;
              if (uVar41 <= uVar56 * 0x20) {
                uVar41 = 0xffffffffffffff0;
              }
              uVar41 = uVar41 & 0xfffffffffffffff0;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103e1c;
              func_0x();
              lVar24 = -uVar41;
              puVar32 = &stack0xffffffffffffffc0 + lVar24 + lVar20;
              *(longlong *)(&stack0x00000068 + lVar20) = (longlong)&sStackX_10 + lVar24 + lVar20;
              if (*(int *)(puVar22 + 2) == 0) {
                *puVar52 = 0;
                *(undefined4 *)(puVar22 + 10) = *(undefined4 *)(puVar22 + 8);
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103e44;
                pbVar29 = (byte *)func_0x(puVar52);
                if ((*pbVar29 & 0x10) != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103e51;
                  pbVar29 = (byte *)func_0x(puVar52);
                  if ((*pbVar29 & 0x10) != 0) {
                    uVar39 = (uint)*(ushort *)
                                    ((ulonglong)*(uint *)(puVar22 + 8) + *(longlong *)(puVar22 + 4))
                    ;
                  }
                  *(uint *)(puVar22 + 10) = *(int *)(puVar22 + 10) + (uVar39 + 7 >> 3) + 2;
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103e7a;
                pbVar29 = (byte *)func_0x(puVar52);
                if ((*pbVar29 & 0x20) == 0) {
                  *(undefined4 *)(puVar22 + 2) = *(undefined4 *)(puVar22 + 10);
                  puVar22[0xe] = 0;
                  *(undefined4 *)(puVar22 + 0xc) = *(undefined4 *)(puVar22 + 10);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103e8b;
                  puVar49 = (ushort *)func_0x(puVar52);
                  uVar13 = *puVar49;
                  puVar22[0xe] = uVar13;
                  if (uVar13 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103ea6;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103eaf;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103ebf;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103edb;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103f01;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(puVar22 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103f0f;
                    func_0x(uVar23,3);
                    uVar13 = puVar22[0xe];
                  }
                  uVar39 = *(int *)(puVar22 + 10) + 2 + (uint)uVar13 * 2;
                  *(uint *)(puVar22 + 0xc) = uVar39;
                  if (0x1f9e < uVar39) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103f36;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103f3f;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103f4f;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103f6b;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103f91;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(puVar22 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103f9f;
                    func_0x(uVar23,4);
                    uVar13 = puVar22[0xe];
                  }
                  puVar49 = puVar49 + 1;
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103fb5;
                  uVar13 = func_0x(puVar49,(ulonglong)uVar13 - 1);
                  *(uint *)(puVar22 + 2) = (uint)uVar13;
                  if ((uint)uVar13 <= *(uint *)(puVar22 + 0xc) &&
                      *(uint *)(puVar22 + 0xc) != (uint)uVar13) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103fcc;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103fd5;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x103fe5;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104001;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10402b;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(puVar22 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104039;
                    func_0x(uVar23,4);
                  }
                  uVar13 = puVar22[0xe];
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104047;
                  iVar16 = func_0x(puVar49,uVar13 - 1);
                  while (iVar16 != 0) {
                    uVar13 = puVar22[0xe];
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10405c;
                    lVar27 = func_0x(puVar52);
                    if (uVar13 == 1) {
                      uVar41 = (ulonglong)*(uint *)(puVar22 + 0xc);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104079;
                      uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                      uVar41 = (ulonglong)uVar38;
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104089;
                    uVar13 = func_0x(lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                    uVar39 = (uint)uVar41;
                    if ((uVar39 < *(uint *)(puVar22 + 0xc)) || (uVar13 < uVar39)) {
                      uVar23 = *(undefined8 *)(puVar22 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1040a3;
                      func_0x(uVar23,7);
                      if (uVar39 < *(uint *)(puVar22 + 0xc)) goto LAB_;
                    }
                    if (*(uint *)(puVar22 + 2) < uVar39) goto LAB_;
                    if (*(ushort *)(uVar41 + *(longlong *)(puVar22 + 4)) == 5) {
                      *puVar52 = *puVar52 | 2;
                      puVar22[0xe] = puVar22[0xe] + -1;
                      puVar22[0x15] = (short)uVar41;
                      lVar27 = (uVar41 & 0xffff) + *(longlong *)(puVar22 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10416f;
                      iVar16 = func_0x(lVar27);
                      if (iVar16 == 0) {
                        puVar22[0x16] = puVar22[0x16] & 0xc7ff;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10417b;
                        uVar13 = func_0x(lVar27);
                        puVar22[0x16] = puVar22[0x16] & 0xc7ff;
                        puVar22[0x16] = puVar22[0x16] | (uVar13 & 7) << 0xb;
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1041a3;
                      uVar13 = func_0x(lVar27);
                      puVar22[0x16] = puVar22[0x16] & 0xf800;
                      puVar22[0x16] = puVar22[0x16] | uVar13 & 0x7ff;
                      break;
                    }
                    if (*(ushort *)(uVar41 + *(longlong *)(puVar22 + 4)) < 0x400) break;
                    *puVar52 = *puVar52 | 1;
                    uVar13 = puVar22[0xe] - 1;
                    puVar22[0xe] = uVar13;
                    if (uVar13 == 0) break;
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1040f3;
                    iVar16 = func_0x(puVar49,uVar13 - 1);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104109;
                iVar16 = func_0x(puVar52);
                if (iVar16 == 0) {
                  *(undefined4 *)(puVar22 + 0x13) = 0;
                }
                else {
                  *(int *)(puVar22 + 0x13) = *(int *)(puVar22 + 2);
                  *(int *)(puVar22 + 2) = *(int *)(puVar22 + 2) + 0xe;
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104128;
                  uVar23 = func_0x(puVar52);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104137;
                  func_0x(uVar23,&stack0x00000208 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104143;
                  iVar16 = func_0x(&stack0x00000208 + lVar20);
                  *(int *)(puVar22 + 2) = *(int *)(puVar22 + 2) + iVar16;
                }
                uVar39 = *(uint *)(puVar22 + 2);
                if ((*(ulonglong *)(puVar22 + 0xf) != 0) &&
                   (*(ulonglong *)(puVar22 + 0xf) < (ulonglong)uVar39 + *(longlong *)(puVar22 + 4)))
                {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1041fe;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104207;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104217;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104233;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104259;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104267;
                  func_0x(uVar23,0x12);
                  uVar39 = *(uint *)(puVar22 + 2);
                }
                if (0x3f3b < uVar39 - 1) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104283;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10428c;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10429c;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1042b8;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1042de;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1042ec;
                  func_0x(uVar23,5);
                }
              }
LAB_:
              uVar13 = puVar22[0xe];
              uVar39 = (uint)uVar13;
              if ((uVar44 <= uVar13) || (uVar44 = (uint)uVar13, uVar13 != 0)) {
                uVar39 = uVar44;
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10430f;
                lVar25 = func_0x(puVar52);
                *(undefined4 *)(&stack0x0000005c + lVar20) = *(undefined4 *)(puVar22 + 0xc);
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104324;
                func_0x(&stack0x000002f0 + lVar20);
                uVar44 = 0;
                lVar25 = lVar25 + 2;
                lVar57 = 0;
                lVar27 = *(longlong *)(&stack0x00000068 + lVar20);
                do {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104340;
                  iVar16 = func_0x(lVar25,uVar44);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104352;
                  uVar13 = func_0x(lVar25,lVar57);
                  uVar18 = *(uint *)(&stack0x0000005c + lVar20);
                  lVar5 = *(longlong *)(puVar22 + 4);
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar24 + lVar20) = 0;
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar24 + lVar20) =
                       &stack0x000002f0 + lVar20;
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x104381;
                  func_0x
                            (lVar27,(ulonglong)uVar18 + lVar5,uVar13 - uVar18,iVar16 != 0);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10438c;
                  uVar13 = func_0x(lVar25,lVar57);
                  *(uint *)(&stack0x0000005c + lVar20) = (uint)uVar13;
                  uVar44 = uVar44 + 1;
                  lVar57 = lVar57 + 1;
                  lVar27 = lVar27 + 0x20;
                } while (uVar44 < uVar39);
                puVar52 = *(ushort **)(&stack0x00000070 + lVar20);
                uVar56 = (ulonglong)*(uint *)(&stack0x00000048 + lVar20);
              }
              lVar27 = *(longlong *)(&stack0x00000068 + lVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1043c7;
              func_0x
                        ((ulonglong)uVar39 * 0x20 + lVar27,0,((int)uVar56 - uVar39) * 0x20);
            }
            lVar24 = *(longlong *)(&stack0x000000e0 + lVar20);
            if (lVar24 != 0) {
              *(int *)(puVar32 + 0x28) = (int)uVar56;
              *(longlong *)(puVar32 + 0x20) = lVar27;
              uVar19 = *(undefined4 *)(&stack0x00000078 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x1043f2;
              func_0x(lVar24,uVar19,puVar52,(longlong)&sStackX_10 + lVar20 + 2);
            }
            uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
            *(undefined8 *)(puVar32 + -8) = 0x1043fb;
            uVar23 = func_0x(uVar23);
            *(undefined8 *)(puVar32 + -8) = 0x104403;
            uVar13 = func_0x(uVar23);
            *(uint *)(&stack0x00000088 + lVar20) = (uint)uVar13;
            *(undefined8 *)(&stack0x000000b8 + lVar20) = 0;
            *(undefined4 *)(&stack0x0000005c + lVar20) = 0;
            uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
            *(undefined8 *)(puVar32 + -8) = 0x104420;
            lVar24 = func_0x(uVar23);
            *(longlong *)(&stack0x000000c0 + lVar20) = lVar24;
            if (uVar13 != 0) {
              lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
              do {
                *(undefined8 *)(puVar32 + -8) = 0x104448;
                uVar23 = func_0x(lVar24);
                *(undefined8 *)(&stack0x00000148 + lVar20) = uVar23;
                *(undefined8 *)(puVar32 + -8) = 0x10445a;
                iVar16 = func_0x(lVar24);
                *(undefined8 *)(puVar32 + -8) = 0x10446b;
                func_0x(lVar25,lVar24,&stack0x00000060 + lVar20);
                if ((&stack0x00000060)[lVar20] == '\x03') {
                  *(undefined8 *)(puVar32 + -8) = 0x105cdc;
                  iVar50 = func_0x(lVar24);
                  if (iVar50 == 0) {
                    *(undefined8 *)(puVar32 + -8) = 0x105ce8;
                    iVar50 = func_0x(lVar24);
                    if (iVar50 == 0) {
                      *(undefined8 *)(puVar32 + -8) = 0x105d00;
                      (*_DAT_)(6,0x51,0x10,3);
                    }
                  }
                  *(undefined8 *)(puVar32 + -8) = 0x105d12;
                  func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23,0,0);
                  if (iVar16 < 0) {
                    puVar46 = (uint *)((longlong)(-1 - iVar16) * 0x20 + 0xc + lVar27);
                    *puVar46 = *puVar46 | 2;
                  }
                }
                else {
                  *(undefined8 *)(puVar32 + -8) = 0x10447d;
                  sVar15 = func_0x(uVar23);
                  if (sVar15 != 0) {
                    *(undefined8 *)(puVar32 + -8) = 0x10448e;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
                  }
                  *(undefined8 *)(puVar32 + -8) = 0x1044a0;
                  func_0x(lVar25,lVar24,&stack0x000000b8 + lVar20);
                  *(undefined8 *)(puVar32 + -8) = 0x1044a8;
                  iVar50 = func_0x(lVar24);
                  uVar39 = 0;
                  if ((iVar50 == 1) || (iVar50 == 2)) {
                    lVar27 = *(longlong *)(&stack0x000000b8 + lVar20);
                    *(undefined8 *)(puVar32 + -8) = 0x105ba1;
                    iVar16 = func_0x(lVar24);
                    if (iVar16 == 0) {
                      *(undefined8 *)(puVar32 + -8) = 0x105bad;
                      uVar14 = func_0x();
                      *(undefined8 *)(puVar32 + -8) = 0x105bb8;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)(puVar32 + -8) = 0x105bc0;
                      iVar16 = func_0x(uVar23);
                      lVar57 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar32 + -8) = 0x105bd2;
                      func_0x(iVar16 + lVar57,lVar27,uVar14);
                    }
                    else {
                      *(undefined8 *)(puVar32 + -8) = 0x105bdf;
                      iVar16 = func_0x(lVar24);
                      if ((iVar16 == 0) || ((*(byte *)(lVar25 + 0x14) & 8) == 0)) {
                        *(undefined8 *)(puVar32 + -8) = 0x105c0d;
                        iVar16 = func_0x(lVar24);
                        if (iVar16 == 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x105c3b;
                          uVar13 = func_0x(lVar24);
                          uVar44 = (uint)uVar13;
                        }
                        else {
                          *(undefined8 *)(puVar32 + -8) = 0x105c19;
                          uVar23 = func_0x();
                          *(undefined8 *)(puVar32 + -8) = 0x105c27;
                          uVar34 = func_0x(lVar25,lVar24);
                          *(undefined8 *)(puVar32 + -8) = 0x105c32;
                          uVar44 = func_0x(uVar34,uVar23);
                        }
                      }
                      else {
                        *(undefined8 *)(puVar32 + -8) = 0x105bf2;
                        uVar44 = func_0x(lVar24);
                        uVar44 = *(uint *)((ulonglong)uVar44 * 8 + *(longlong *)(lVar25 + 0x38));
                      }
                      *(undefined8 *)(puVar32 + -8) = 0x105c46;
                      uVar13 = func_0x(lVar24);
                      if (uVar44 < uVar13) {
                        *(undefined8 *)(puVar32 + -8) = 0x105c55;
                        uVar13 = func_0x(lVar24);
                        uVar39 = uVar13 - uVar44;
                      }
                      else {
                        *(undefined8 *)(puVar32 + -8) = 0x105c61;
                        uVar13 = func_0x(lVar24);
                        if (uVar13 < uVar44) {
                          *(undefined8 *)(puVar32 + -8) = 0x105c7e;
                          (*_DAT_)(6,0x5c,0x16);
                        }
                      }
                      *(undefined8 *)(puVar32 + -8) = 0x105c86;
                      uVar12 = func_0x(lVar24);
                      *(undefined8 *)(puVar32 + -8) = 0x105c92;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)(puVar32 + -8) = 0x105c9a;
                      iVar16 = func_0x(uVar23);
                      lVar57 = (longlong)iVar16 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      if ((lVar27 != 0) && (uVar44 != 0)) {
                        *(undefined8 *)(puVar32 + -8) = 0x105cb8;
                        func_0x(lVar57,lVar27,uVar44);
                      }
                      if (uVar39 != 0) {
                        *(undefined8 *)(puVar32 + -8) = 0x105ccc;
                        func_0x((ulonglong)uVar44 + lVar57,uVar12,uVar39);
                      }
                    }
                  }
                  else if ((iVar50 == 3) || (iVar50 == 4)) {
                    *(undefined8 *)(puVar32 + -8) = 0x105abf;
                    iVar50 = func_0x(lVar24);
                    if ((iVar50 == 0) || (**(int **)(&stack0x000000b8 + lVar20) != 0)) {
                      *(undefined8 *)(puVar32 + -8) = 0x105adc;
                      iVar50 = func_0x(lVar24);
                      if ((iVar50 == 0) || ((*(byte *)(lVar25 + 0x14) & 8) == 0)) {
                        *(undefined8 *)(puVar32 + -8) = 0x105b0a;
                        iVar50 = func_0x(lVar24);
                        if (iVar50 == 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x105b38;
                          uVar13 = func_0x(lVar24);
                          uVar39 = (uint)uVar13;
                        }
                        else {
                          *(undefined8 *)(puVar32 + -8) = 0x105b16;
                          uVar34 = func_0x();
                          *(undefined8 *)(puVar32 + -8) = 0x105b24;
                          uVar35 = func_0x(lVar25,lVar24);
                          *(undefined8 *)(puVar32 + -8) = 0x105b2f;
                          uVar39 = func_0x(uVar35,uVar34);
                        }
                      }
                      else {
                        *(undefined8 *)(puVar32 + -8) = 0x105aef;
                        uVar39 = func_0x(lVar24);
                        uVar39 = *(uint *)((ulonglong)uVar39 * 8 + *(longlong *)(lVar25 + 0x38));
                      }
                    }
                    *(undefined8 *)(puVar32 + -8) = 0x105b43;
                    uVar13 = func_0x(lVar24);
                    if (uVar13 < uVar39) {
                      *(undefined8 *)(puVar32 + -8) = 0x105b60;
                      (*_DAT_)(6,0x52,0x16);
                    }
                    *(undefined4 *)(puVar32 + 0x28) = 0;
                    *(undefined8 *)(puVar32 + 0x20) = uVar23;
                    uVar23 = *(undefined8 *)(&stack0x000000b8 + lVar20);
                    *(undefined8 *)(puVar32 + -8) = 0x105b8d;
                    func_0x((longlong)(-1 - iVar16) * 0x20 + lVar27,uVar23,uVar39);
                  }
                  else if (iVar50 == 8) {
                    pcVar6 = *(char **)(&stack0x000000b8 + lVar20);
                    *(char **)(&stack0x00000070 + lVar20) = pcVar6;
                    *(undefined8 *)(puVar32 + -8) = 0x10450f;
                    iVar16 = func_0x(uVar23);
                    if (iVar16 < 0) {
                      *(undefined8 *)(puVar32 + -8) = 0x104b43;
                      iVar16 = func_0x(uVar23);
                      if (iVar16 == 0) {
                        if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                          *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                          *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                               *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x104b6b;
                          pbVar29 = (byte *)func_0x
                                                      ((longlong)&sStackX_10 + lVar20 + 2);
                          if ((*pbVar29 & 0x10) != 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x104b79;
                            pbVar29 = (byte *)func_0x
                                                        ((longlong)&sStackX_10 + lVar20 + 2);
                            if ((*pbVar29 & 0x10) != 0) {
                              uVar39 = (uint)*(ushort *)
                                              ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20)
                                              + *(longlong *)((longlong)&pbStackX_18 + lVar20));
                            }
                            *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                                 (uVar39 + 7 >> 3) +
                                 *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                          }
                          *(undefined8 *)(puVar32 + -8) = 0x104ba8;
                          pbVar29 = (byte *)func_0x
                                                      ((longlong)&sStackX_10 + lVar20 + 2);
                          if ((*pbVar29 & 0x20) == 0) {
                            uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                            *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                            *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                            *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                          }
                          else {
                            *(undefined8 *)(puVar32 + -8) = 0x104bba;
                            puVar52 = (ushort *)
                                      func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            uVar13 = *puVar52;
                            *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                            if (uVar13 == 0) {
                              *(undefined8 *)(puVar32 + -8) = 0x104bd8;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x104be1;
                                cVar10 = func_0x();
                                if (cVar10 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x104bf1;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 == '\0') {
                                    *(undefined8 *)(puVar32 + -8) = 0x104c0d;
                                    (*_DAT_)(0x22,0x44,0x15);
                                  }
                                  else {
                                    *(undefined8 *)(puVar32 + 0x20) = 0;
                                    *(undefined8 *)(puVar32 + -8) = 0x104c33;
                                    (*_DAT_)(1,0x17719d8,0x18916a8);
                                  }
                                }
                              }
                              uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x104c41;
                              func_0x(uVar34,3);
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            }
                            uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 +
                                     (uint)uVar13 * 2;
                            *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                            if (0x1f9e < uVar39) {
                              *(undefined8 *)(puVar32 + -8) = 0x104c6a;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x104c73;
                                cVar10 = func_0x();
                                if (cVar10 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x104c83;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 == '\0') {
                                    *(undefined8 *)(puVar32 + -8) = 0x104c9f;
                                    (*_DAT_)(0x22,0x44,0x15);
                                  }
                                  else {
                                    *(undefined8 *)(puVar32 + 0x20) = 0;
                                    *(undefined8 *)(puVar32 + -8) = 0x104cc5;
                                    (*_DAT_)(1,0x17719d8,0x18916a8);
                                  }
                                }
                              }
                              uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x104cd3;
                              func_0x(uVar34,4);
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            }
                            *(undefined8 *)(puVar32 + -8) = 0x104ceb;
                            uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
                            *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
                            if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                                *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                              *(undefined8 *)(puVar32 + -8) = 0x104d02;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x104d0b;
                                cVar10 = func_0x();
                                if (cVar10 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x104d1b;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 == '\0') {
                                    *(undefined8 *)(puVar32 + -8) = 0x104d37;
                                    (*_DAT_)(0x22,0x44,0x15);
                                  }
                                  else {
                                    *(undefined8 *)(puVar32 + 0x20) = 0;
                                    *(undefined8 *)(puVar32 + -8) = 0x104d61;
                                    (*_DAT_)(1,0x17719d8,0x18916a8);
                                  }
                                }
                              }
                              uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x104d6f;
                              func_0x(uVar34,4);
                            }
                            uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            do {
                              *(undefined8 *)(puVar32 + -8) = 0x104d8d;
                              iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                              if (iVar16 == 0) break;
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x104da2;
                              lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                              if (uVar13 == 1) {
                                uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                              }
                              else {
                                *(undefined8 *)(puVar32 + -8) = 0x104dbe;
                                uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                                uVar39 = (uint)uVar38;
                              }
                              *(undefined8 *)(puVar32 + -8) = 0x104dce;
                              uVar13 = func_0x
                                                 (lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                              uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                              if ((uVar39 < uVar44) || (uVar13 < uVar39)) {
                                uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                                *(undefined8 *)(puVar32 + -8) = 0x104dea;
                                func_0x(uVar34,7);
                                uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                              }
                              if ((uVar39 < uVar44) ||
                                 (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar39))
                              goto LAB_;
                              lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                              uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar39);
                              if (uVar13 == 5) {
                                puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                *puVar52 = *puVar52 | 2;
                                *(short *)(&stack0x0000002c + lVar20) =
                                     *(short *)(&stack0x0000002c + lVar20) + -1;
                                *(short *)(&stack0x0000003a + lVar20) = (short)uVar39;
                                lVar27 = (ulonglong)(uVar39 & 0xffff) + lVar27;
                                *(undefined8 *)(puVar32 + -8) = 0x104e9c;
                                iVar16 = func_0x(lVar27);
                                if (iVar16 == 0) {
                                  *(ushort *)(&stack0x0000003c + lVar20) =
                                       *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                                }
                                else {
                                  *(undefined8 *)(puVar32 + -8) = 0x104ea8;
                                  sVar15 = func_0x(lVar27);
                                  *(ushort *)(&stack0x0000003c + lVar20) =
                                       *(ushort *)(&stack0x0000003c + lVar20) ^
                                       (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) &
                                       0x3800;
                                }
                                *(undefined8 *)(puVar32 + -8) = 0x104ed5;
                                uVar13 = func_0x(lVar27);
                                *(ushort *)(&stack0x0000003c + lVar20) =
                                     *(ushort *)(&stack0x0000003c + lVar20) ^
                                     (*(ushort *)(&stack0x0000003c + lVar20) ^ uVar13) & 0x7ff;
                                break;
                              }
                              if (uVar13 < 0x400) break;
                              puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                              *puVar49 = *puVar49 | 1;
                              uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                              *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                            } while (uVar13 != 0);
                          }
                          *(undefined8 *)(puVar32 + -8) = 0x104e3b;
                          iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          if (iVar16 == 0) {
                            *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                            uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                          }
                          else {
                            iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                            *(int *)(&stack0x00000036 + lVar20) = iVar16;
                            *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
                            *(undefined8 *)(puVar32 + -8) = 0x104e58;
                            uVar34 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            *(undefined8 *)(puVar32 + -8) = 0x104e67;
                            func_0x(uVar34,&stack0x00000218 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x104e73;
                            iVar16 = func_0x(&stack0x00000218 + lVar20);
                            uVar39 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar16;
                            *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                          }
                          if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                             (*(ulonglong *)(&stack0x0000002e + lVar20) <
                              (ulonglong)uVar39 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                            *(undefined8 *)(puVar32 + -8) = 0x104f31;
                            cVar10 = func_0x(0x1e80c50);
                            if (cVar10 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x104f3a;
                              cVar10 = func_0x();
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x104f4a;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x104f66;
                                  (*_DAT_)(0x22,0x44,0x15);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x104f8c;
                                  (*_DAT_)(1,0x17719d8,0x18916a8);
                                }
                              }
                            }
                            uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x104f9a;
                            func_0x(uVar34,0x12);
                            uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                          }
                          if (0x3f3b < uVar39 - 1) {
                            *(undefined8 *)(puVar32 + -8) = 0x104fb3;
                            cVar10 = func_0x(0x1e80c50);
                            if (cVar10 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x104fbc;
                              cVar10 = func_0x();
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x104fcc;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x104fe8;
                                  (*_DAT_)(0x22,0x44,0x15);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x10500e;
                                  (*_DAT_)(1,0x17719d8,0x18916a8);
                                }
                              }
                            }
                            uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x10501c;
                            func_0x(uVar34,5);
                          }
                        }
LAB_:
                        *(undefined8 *)(puVar32 + -8) = 0x105024;
                        iVar16 = func_0x(uVar23);
                        uVar39 = -iVar16;
                        *(undefined8 *)(puVar32 + -8) = 0x105034;
                        func_0x(&stack0x00000740 + lVar20);
                        *(undefined8 *)(puVar32 + -8) = 0x10503d;
                        iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        *(int *)(&stack0x00000148 + lVar20) = iVar16;
                        if (iVar16 != 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x10505a;
                          func_0x
                                    ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000740 + lVar20);
                        }
                        *(undefined8 *)(puVar32 + -8) = 0x105063;
                        pbVar29 = (byte *)func_0x
                                                    ((longlong)&sStackX_10 + lVar20 + 2);
                        if ((*pbVar29 & 0x20) == 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x105071;
                          func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        }
                        uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                        uVar18 = (uint)uVar13;
                        uVar44 = (uint)uVar13;
                        if (uVar44 < uVar39) {
                          *(uint *)(&stack0x00000150 + lVar20) = uVar39 - uVar13;
                          uVar18 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                          lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          puVar52 = (ushort *)(lVar27 + (ulonglong)uVar18);
                          uVar18 = uVar18 + 2 + uVar44 * 2;
                          uVar40 = (uVar39 - uVar13) * 2;
                          uVar42 = 0;
                          if (*puVar52 != 0) {
                            do {
                              *(undefined8 *)(puVar32 + -8) = 0x1050bb;
                              uVar38 = func_0x(puVar52 + 1,uVar42);
                              *(undefined8 *)(puVar32 + -8) = 0x1050ce;
                              func_0x(puVar52 + 1,uVar42 & 0xffff,uVar38 + uVar40);
                              uVar42 = uVar42 + 1;
                            } while (uVar42 < *puVar52);
                            lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          }
                          iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                          *(undefined8 *)(puVar32 + -8) = 0x1050f9;
                          func_0x
                                    ((ulonglong)uVar40 + lVar27 + (ulonglong)uVar18,
                                     (ulonglong)uVar18 + lVar27,iVar16 - uVar18);
                          piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                          *piVar45 = *piVar45 + uVar40;
                          uVar40 = *(int *)(&stack0x00000028 + lVar20) + uVar40;
                          *(uint *)(&stack0x00000028 + lVar20) = uVar40;
                          if (uVar13 != 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x105116;
                            uVar13 = func_0x(puVar52 + 1,uVar44 - 1);
                            uVar40 = (uint)uVar13;
                          }
                          do {
                            *(undefined8 *)(puVar32 + -8) = 0x105132;
                            func_0x(puVar52 + 1,uVar44 & 0xffff,uVar40 & 0xffff);
                            uVar44 = uVar44 + 1;
                          } while (uVar44 < uVar39);
                          *puVar52 = *puVar52 + (short)*(undefined4 *)(&stack0x00000150 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x10514c;
                          iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          if (iVar16 != 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x105159;
                            func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          }
                          uVar18 = uVar39 & 0xffff;
                          *(short *)(&stack0x0000002c + lVar20) = (short)uVar39;
                          iVar16 = *(int *)(&stack0x00000148 + lVar20);
                        }
                        lVar27 = (longlong)&sStackX_10 + lVar20 + 2;
                        if (uVar18 < uVar39) {
                          *(undefined8 *)(puVar32 + -8) = 0x1051d8;
                          lVar27 = func_0x(lVar27);
                          uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x1051e8;
                          uVar13 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 1);
                          uVar44 = (uint)uVar13;
                          iVar50 = 0;
LAB_:
                          uVar39 = uVar39 - 1;
                          *(undefined8 *)(puVar32 + -8) = 0x1051fb;
                          puVar52 = (ushort *)
                                    func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          uVar19 = *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                          *(undefined8 *)(puVar32 + -8) = 0x10520d;
                          uVar19 = func_0x(uVar19,uVar44 + iVar50);
                          lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x105228;
                          func_0x
                                    (lVar27 + 1 + (ulonglong)uVar44,
                                     iVar50 + lVar27 + (ulonglong)uVar44,uVar19);
                          if ((int)uVar39 < (int)(uint)*puVar52) {
                            do {
                              *(undefined8 *)(puVar32 + -8) = 0x10524c;
                              uVar13 = func_0x(puVar52 + 1,(longlong)(int)uVar39);
                              *(undefined8 *)(puVar32 + -8) = 0x10525f;
                              func_0x
                                        (puVar52 + 1,uVar39 & 0xffff,(uint)uVar13 + (1 - iVar50));
                              uVar39 = uVar39 + 1;
                            } while ((int)uVar39 < (int)(uint)*puVar52);
                          }
                          piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                          *piVar45 = *piVar45 + (1 - iVar50);
                          *(undefined8 *)(puVar32 + -8) = 0x10527e;
                          iVar50 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          if (iVar50 != 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x10528b;
                            func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          }
                        }
                        else {
                          *(undefined8 *)(puVar32 + -8) = 0x105177;
                          lVar27 = func_0x(lVar27);
                          if (uVar39 == 1) {
                            uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                          }
                          else {
                            *(undefined8 *)(puVar32 + -8) = 0x105194;
                            uVar13 = func_0x(lVar27 + 2,(longlong)(int)(uVar39 - 2))
                            ;
                            uVar44 = (uint)uVar13;
                          }
                          *(undefined8 *)(puVar32 + -8) = 0x1051a7;
                          uVar13 = func_0x(lVar27 + 2,(longlong)(int)(uVar39 - 1));
                          if ((uVar44 < *(uint *)(&stack0x00000028 + lVar20)) || (uVar13 < uVar44))
                          {
                            uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x1051c4;
                            func_0x(uVar23,7);
                          }
                          iVar50 = uVar13 - uVar44;
                          if (iVar50 != 1) goto LAB_;
                        }
                        *(undefined *)
                         ((ulonglong)uVar44 + *(longlong *)((longlong)&pbStackX_18 + lVar20)) =
                             **(undefined **)(&stack0x00000070 + lVar20);
                        if (iVar16 != 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x1052b1;
                          func_0x
                                    ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000740 + lVar20);
                        }
                        lVar24 = *(longlong *)(&stack0x000000c0 + lVar20);
                      }
                      else {
                        *(undefined8 *)(puVar32 + -8) = 0x1052cc;
                        func_0x(&stack0x00000820 + lVar20);
                        *(undefined4 *)(&stack0x00000098 + lVar20) = 0;
                        *(undefined8 *)(puVar32 + -8) = 0x1052df;
                        func_0x(&stack0x00000160 + lVar20);
                        if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                          *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                          *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                               *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x1052fd;
                          pbVar29 = (byte *)func_0x
                                                      ((longlong)&sStackX_10 + lVar20 + 2);
                          if ((*pbVar29 & 0x10) != 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x10530b;
                            pbVar29 = (byte *)func_0x
                                                        ((longlong)&sStackX_10 + lVar20 + 2);
                            if ((*pbVar29 & 0x10) != 0) {
                              uVar39 = (uint)*(ushort *)
                                              ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20)
                                              + *(longlong *)((longlong)&pbStackX_18 + lVar20));
                            }
                            *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                                 (uVar39 + 7 >> 3) +
                                 *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                          }
                          *(undefined8 *)(puVar32 + -8) = 0x10533a;
                          pbVar29 = (byte *)func_0x
                                                      ((longlong)&sStackX_10 + lVar20 + 2);
                          if ((*pbVar29 & 0x20) == 0) {
                            uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                            *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                            *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                            *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                          }
                          else {
                            *(undefined8 *)(puVar32 + -8) = 0x10534c;
                            puVar52 = (ushort *)
                                      func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            uVar13 = *puVar52;
                            *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                            if (uVar13 == 0) {
                              *(undefined8 *)(puVar32 + -8) = 0x10536a;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x105373;
                                cVar10 = func_0x();
                                if (cVar10 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x105383;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 == '\0') {
                                    *(undefined8 *)(puVar32 + -8) = 0x10539f;
                                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                  }
                                  else {
                                    *(undefined8 *)(puVar32 + 0x20) = 0;
                                    *(undefined8 *)(puVar32 + -8) = 0x1053c5;
                                    (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                                  }
                                }
                              }
                              uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x1053d3;
                              func_0x(uVar34,3);
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            }
                            uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 +
                                     (uint)uVar13 * 2;
                            *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                            if (0x1f9e < uVar39) {
                              *(undefined8 *)(puVar32 + -8) = 0x1053fc;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x105405;
                                cVar10 = func_0x();
                                if (cVar10 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x105415;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 == '\0') {
                                    *(undefined8 *)(puVar32 + -8) = 0x105431;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(puVar32 + 0x20) = 0;
                                    *(undefined8 *)(puVar32 + -8) = 0x105457;
                                    (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                                  }
                                }
                              }
                              uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x105465;
                              func_0x(uVar34,4);
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            }
                            *(undefined8 *)(puVar32 + -8) = 0x10547d;
                            uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
                            *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
                            if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                                *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                              *(undefined8 *)(puVar32 + -8) = 0x105494;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x10549d;
                                cVar10 = func_0x();
                                if (cVar10 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x1054ad;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 == '\0') {
                                    *(undefined8 *)(puVar32 + -8) = 0x1054c9;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(puVar32 + 0x20) = 0;
                                    *(undefined8 *)(puVar32 + -8) = 0x1054f3;
                                    (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                                  }
                                }
                              }
                              uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x105501;
                              func_0x(uVar34,4);
                            }
                            uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            do {
                              *(undefined8 *)(puVar32 + -8) = 0x10551d;
                              iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                              if (iVar16 == 0) break;
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x105532;
                              lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                              if (uVar13 == 1) {
                                uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                              }
                              else {
                                *(undefined8 *)(puVar32 + -8) = 0x10554e;
                                uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                                uVar39 = (uint)uVar38;
                              }
                              *(undefined8 *)(puVar32 + -8) = 0x10555e;
                              uVar13 = func_0x
                                                 (lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                              uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                              if ((uVar39 < uVar44) || (uVar13 < uVar39)) {
                                uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                                *(undefined8 *)(puVar32 + -8) = 0x10557a;
                                func_0x(uVar34,7);
                                uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                              }
                              if ((uVar39 < uVar44) ||
                                 (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar39))
                              goto LAB_;
                              lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                              uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar39);
                              if (uVar13 == 5) {
                                puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                *puVar52 = *puVar52 | 2;
                                *(short *)(&stack0x0000002c + lVar20) =
                                     *(short *)(&stack0x0000002c + lVar20) + -1;
                                *(short *)(&stack0x0000003a + lVar20) = (short)uVar39;
                                lVar27 = (ulonglong)(uVar39 & 0xffff) + lVar27;
                                *(undefined8 *)(puVar32 + -8) = 0x10562c;
                                iVar16 = func_0x(lVar27);
                                if (iVar16 == 0) {
                                  *(ushort *)(&stack0x0000003c + lVar20) =
                                       *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                                }
                                else {
                                  *(undefined8 *)(puVar32 + -8) = 0x105638;
                                  sVar15 = func_0x(lVar27);
                                  *(ushort *)(&stack0x0000003c + lVar20) =
                                       *(ushort *)(&stack0x0000003c + lVar20) ^
                                       (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) &
                                       0x3800;
                                }
                                *(undefined8 *)(puVar32 + -8) = 0x105665;
                                uVar13 = func_0x(lVar27);
                                *(ushort *)(&stack0x0000003c + lVar20) =
                                     *(ushort *)(&stack0x0000003c + lVar20) ^
                                     (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
                                break;
                              }
                              if (uVar13 < 0x400) break;
                              puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                              *puVar49 = *puVar49 | 1;
                              uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                              *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                            } while (uVar13 != 0);
                          }
                          *(undefined8 *)(puVar32 + -8) = 0x1055cb;
                          iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          if (iVar16 == 0) {
                            *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                            uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                          }
                          else {
                            iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                            *(int *)(&stack0x00000036 + lVar20) = iVar16;
                            *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
                            *(undefined8 *)(puVar32 + -8) = 0x1055e8;
                            uVar34 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            *(undefined8 *)(puVar32 + -8) = 0x1055f7;
                            func_0x(uVar34,&stack0x00000220 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x105603;
                            iVar16 = func_0x(&stack0x00000220 + lVar20);
                            uVar39 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar16;
                            *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                          }
                          if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                             (*(ulonglong *)(&stack0x0000002e + lVar20) <
                              (ulonglong)uVar39 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                            *(undefined8 *)(puVar32 + -8) = 0x1056be;
                            cVar10 = func_0x(0x1e80c50);
                            if (cVar10 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x1056c7;
                              cVar10 = func_0x();
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x1056d7;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x1056f3;
                                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x105719;
                                  (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                                }
                              }
                            }
                            uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x105727;
                            func_0x(uVar34,0x12);
                            uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                          }
                          if (0x3f3b < uVar39 - 1) {
                            *(undefined8 *)(puVar32 + -8) = 0x105740;
                            cVar10 = func_0x(0x1e80c50);
                            if (cVar10 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x105749;
                              cVar10 = func_0x();
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x105759;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x105775;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x10579b;
                                  (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                                }
                              }
                            }
                            uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x1057a9;
                            func_0x(uVar34,5);
                          }
                        }
LAB_:
                        *(undefined8 *)(puVar32 + -8) = 0x1057b2;
                        func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        *(undefined8 *)(puVar32 + -8) = 0x1057bb;
                        iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        if (iVar16 != 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x1057d2;
                          func_0x
                                    ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000820 + lVar20);
                        }
                        if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x1057ed;
                          uVar34 = func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                                   &stack0x00000098 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x1057fc;
                          func_0x(&stack0x00000160 + lVar20,uVar34);
                        }
                        *(undefined8 *)(puVar32 + -8) = 0x105805;
                        pbVar29 = (byte *)func_0x
                                                    ((longlong)&sStackX_10 + lVar20 + 2);
                        if ((*pbVar29 & 0x20) == 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x105813;
                          func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        }
                        *(undefined8 *)(puVar32 + -8) = 0x10581c;
                        lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        *(undefined8 *)(puVar32 + -8) = 0x105828;
                        iVar50 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        if (iVar50 == 0) {
                          uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                          uVar44 = (uint)uVar13;
                          uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                          lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          puVar52 = (ushort *)(lVar24 + (ulonglong)uVar39);
                          uVar39 = uVar39 + 2 + uVar44 * 2;
                          uVar18 = 0;
                          if (*puVar52 != 0) {
                            do {
                              *(undefined8 *)(puVar32 + -8) = 0x1058db;
                              uVar38 = func_0x(puVar52 + 1,uVar18);
                              *(undefined8 *)(puVar32 + -8) = 0x1058ef;
                              func_0x(puVar52 + 1,uVar18 & 0xffff,uVar38 + 2);
                              uVar18 = uVar18 + 1;
                            } while (uVar18 < *puVar52);
                            lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          }
                          iVar50 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                          *(undefined8 *)(puVar32 + -8) = 0x105917;
                          func_0x
                                    ((ulonglong)uVar39 + 2 + lVar24,(ulonglong)uVar39 + lVar24,
                                     iVar50 - uVar39);
                          piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                          *piVar45 = *piVar45 + 2;
                          uVar39 = *(int *)(&stack0x00000028 + lVar20) + 2;
                          *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                          if (uVar13 != 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x105934;
                            uVar13 = func_0x(puVar52 + 1,uVar44 - 1);
                            uVar39 = (uint)uVar13;
                          }
                          uVar18 = uVar44 + 1;
                          if (uVar44 < uVar18) {
                            do {
                              *(undefined8 *)(puVar32 + -8) = 0x105954;
                              func_0x(puVar52 + 1,uVar44 & 0xffff,uVar39 & 0xffff,0)
                              ;
                              uVar44 = uVar44 + 1;
                            } while (uVar44 < uVar18);
                          }
                          *puVar52 = *puVar52 + 1;
                          *(undefined8 *)(puVar32 + -8) = 0x105967;
                          func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          iVar51 = 0;
                          uVar14 = *(undefined2 *)(&stack0x0000002c + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x10597d;
                          uVar14 = func_0x(lVar27 + 2,uVar14);
                          *(undefined8 *)(puVar32 + -8) = 0x10598c;
                          func_0x(&stack0x00000350 + lVar20);
                          *(undefined4 *)(puVar32 + 0x28) = 0;
                          *(undefined8 *)(puVar32 + 0x20) =
                               *(undefined8 *)(&stack0x00000148 + lVar20);
                          uVar23 = *(undefined8 *)(&stack0x00000070 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x1059b9;
                          func_0x(&stack0x00000350 + lVar20,uVar23,1,0);
                          *(undefined **)(puVar32 + 0x28) = &stack0x00000140 + lVar20;
                          *(undefined **)(puVar32 + 0x20) = &stack0x00000350 + lVar20;
                          *(undefined8 *)(puVar32 + -8) = 0x1059e5;
                          func_0x(&stack0x0000003a + lVar20,uVar14,0x1f9e,1);
                          iVar50 = *(int *)(&stack0x00000140 + lVar20);
                        }
                        else {
                          uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                          uVar39 = uVar13 + 1;
                          *(undefined8 *)(puVar32 + -8) = 0x10583f;
                          lVar24 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          if (uVar39 == 1) {
                            uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                          }
                          else {
                            *(undefined8 *)(puVar32 + -8) = 0x10585b;
                            uVar38 = func_0x(lVar24 + 2,(ulonglong)uVar39 - 2);
                            uVar39 = (uint)uVar38;
                          }
                          *(undefined8 *)(puVar32 + -8) = 0x10586a;
                          uVar13 = func_0x(lVar24 + 2,uVar13);
                          if ((uVar39 < *(uint *)(&stack0x00000028 + lVar20)) || (uVar13 < uVar39))
                          {
                            uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x105884;
                            func_0x(uVar34,7);
                          }
                          iVar51 = uVar13 - uVar39;
                          uVar34 = *(undefined8 *)(&stack0x00000070 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x10589c;
                          iVar50 = func_0x(&stack0x0000003a + lVar20,uVar23,uVar34,1);
                        }
                        iVar51 = (*(int *)((longlong)&sStackX_10 + lVar20 + 4) - iVar51) + iVar50;
                        *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar51;
                        if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                          uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x105a10;
                          func_0x(lVar27 + 2,uVar13 + 1,iVar51,1);
                          iVar51 = (*(int *)((longlong)&sStackX_10 + lVar20 + 4) -
                                   *(int *)(&stack0x00000098 + lVar20)) + -2;
                        }
                        uVar14 = *(undefined2 *)(&stack0x0000002c + lVar20);
                        *(undefined8 *)(puVar32 + -8) = 0x105a2e;
                        func_0x(lVar27 + 2,uVar14,iVar51);
                        lVar27 = (longlong)&sStackX_10 + lVar20 + 2;
                        if (iVar50 == 0) {
                          uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x105a44;
                          func_0x(lVar27,uVar13 + 1,0);
                          *(undefined8 *)(puVar32 + -8) = 0x105a4d;
                          pbVar29 = (byte *)func_0x
                                                      ((longlong)&sStackX_10 + lVar20 + 2);
                          if ((*pbVar29 & 0x20) != 0) {
                            *(short *)(&stack0x0000002c + lVar20) =
                                 *(short *)(&stack0x0000002c + lVar20) + 1;
                            puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                            *puVar52 = *puVar52 & 0xfffd;
                            *(undefined8 *)(puVar32 + -8) = 0x105a68;
                            func_0x(&stack0x0000003a + lVar20);
                          }
                        }
                        else {
                          puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                          *puVar52 = *puVar52 | 2;
                          *(undefined8 *)(puVar32 + -8) = 0x105a74;
                          func_0x(lVar27);
                        }
                        if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                          uVar19 = *(undefined4 *)(&stack0x00000098 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x105a96;
                          func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,uVar19);
                        }
                        if (iVar16 != 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x105aab;
                          func_0x
                                    ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000820 + lVar20);
                        }
                        lVar24 = *(longlong *)(&stack0x000000c0 + lVar20);
                      }
                    }
                    else {
                      *(undefined8 *)(puVar32 + -8) = 0x104522;
                      iVar16 = func_0x();
                      if (iVar16 == 0) {
                        if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                          *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                          *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                               *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x104620;
                          pbVar29 = (byte *)func_0x
                                                      ((longlong)&sStackX_10 + lVar20 + 2);
                          if ((*pbVar29 & 0x10) != 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x10462e;
                            pbVar29 = (byte *)func_0x
                                                        ((longlong)&sStackX_10 + lVar20 + 2);
                            if ((*pbVar29 & 0x10) != 0) {
                              uVar39 = (uint)*(ushort *)
                                              ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20)
                                              + *(longlong *)((longlong)&pbStackX_18 + lVar20));
                            }
                            *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                                 (uVar39 + 7 >> 3) +
                                 *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                          }
                          *(undefined8 *)(puVar32 + -8) = 0x10465d;
                          pbVar29 = (byte *)func_0x
                                                      ((longlong)&sStackX_10 + lVar20 + 2);
                          if ((*pbVar29 & 0x20) == 0) {
                            uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                            *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                            *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                            *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                          }
                          else {
                            *(undefined8 *)(puVar32 + -8) = 0x10466f;
                            puVar52 = (ushort *)
                                      func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            uVar13 = *puVar52;
                            *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                            if (uVar13 == 0) {
                              *(undefined8 *)(puVar32 + -8) = 0x10468d;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x104696;
                                cVar10 = func_0x();
                                if (cVar10 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x1046a6;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 == '\0') {
                                    *(undefined8 *)(puVar32 + -8) = 0x1046c2;
                                    (*_DAT_)(0x22,0x44,0x15);
                                  }
                                  else {
                                    *(undefined8 *)(puVar32 + 0x20) = 0;
                                    *(undefined8 *)(puVar32 + -8) = 0x1046e8;
                                    (*_DAT_)(1,0x17719d8,0x18916a8);
                                  }
                                }
                              }
                              uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x1046f6;
                              func_0x(uVar34,3);
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            }
                            uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 +
                                     (uint)uVar13 * 2;
                            *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                            if (0x1f9e < uVar39) {
                              *(undefined8 *)(puVar32 + -8) = 0x10471f;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x104728;
                                cVar10 = func_0x();
                                if (cVar10 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x104738;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 == '\0') {
                                    *(undefined8 *)(puVar32 + -8) = 0x104754;
                                    (*_DAT_)(0x22,0x44,0x15);
                                  }
                                  else {
                                    *(undefined8 *)(puVar32 + 0x20) = 0;
                                    *(undefined8 *)(puVar32 + -8) = 0x10477a;
                                    (*_DAT_)(1,0x17719d8,0x18916a8);
                                  }
                                }
                              }
                              uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x104788;
                              func_0x(uVar34,4);
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            }
                            *(undefined8 *)(puVar32 + -8) = 0x1047a0;
                            uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
                            *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
                            if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                                *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                              *(undefined8 *)(puVar32 + -8) = 0x1047b7;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x1047c0;
                                cVar10 = func_0x();
                                if (cVar10 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x1047d0;
                                  cVar10 = func_0x(0x1e80c50);
                                  if (cVar10 == '\0') {
                                    *(undefined8 *)(puVar32 + -8) = 0x1047ec;
                                    (*_DAT_)(0x22,0x44,0x15);
                                  }
                                  else {
                                    *(undefined8 *)(puVar32 + 0x20) = 0;
                                    *(undefined8 *)(puVar32 + -8) = 0x104816;
                                    (*_DAT_)(1,0x17719d8,0x18916a8);
                                  }
                                }
                              }
                              uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x104824;
                              func_0x(uVar34,4);
                            }
                            uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                            do {
                              *(undefined8 *)(puVar32 + -8) = 0x10483d;
                              iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                              if (iVar16 == 0) break;
                              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                              *(undefined8 *)(puVar32 + -8) = 0x104852;
                              lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                              if (uVar13 == 1) {
                                uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                              }
                              else {
                                *(undefined8 *)(puVar32 + -8) = 0x10486e;
                                uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                                uVar39 = (uint)uVar38;
                              }
                              *(undefined8 *)(puVar32 + -8) = 0x10487e;
                              uVar13 = func_0x
                                                 (lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                              uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                              if ((uVar39 < uVar44) || (uVar13 < uVar39)) {
                                uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                                *(undefined8 *)(puVar32 + -8) = 0x10489a;
                                func_0x(uVar34,7);
                                uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                              }
                              if ((uVar39 < uVar44) ||
                                 (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar39))
                              goto LAB_;
                              lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                              uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar39);
                              if (uVar13 == 5) {
                                puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                                *puVar52 = *puVar52 | 2;
                                *(short *)(&stack0x0000002c + lVar20) =
                                     *(short *)(&stack0x0000002c + lVar20) + -1;
                                *(short *)(&stack0x0000003a + lVar20) = (short)uVar39;
                                lVar27 = (ulonglong)(uVar39 & 0xffff) + lVar27;
                                *(undefined8 *)(puVar32 + -8) = 0x104954;
                                iVar16 = func_0x(lVar27);
                                if (iVar16 == 0) {
                                  *(ushort *)(&stack0x0000003c + lVar20) =
                                       *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                                }
                                else {
                                  *(undefined8 *)(puVar32 + -8) = 0x104960;
                                  sVar15 = func_0x(lVar27);
                                  *(ushort *)(&stack0x0000003c + lVar20) =
                                       *(ushort *)(&stack0x0000003c + lVar20) ^
                                       (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) &
                                       0x3800;
                                }
                                *(undefined8 *)(puVar32 + -8) = 0x10498d;
                                uVar13 = func_0x(lVar27);
                                *(ushort *)(&stack0x0000003c + lVar20) =
                                     *(ushort *)(&stack0x0000003c + lVar20) ^
                                     (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
                                break;
                              }
                              if (uVar13 < 0x400) break;
                              puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                              *puVar49 = *puVar49 | 1;
                              uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                              *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                            } while (uVar13 != 0);
                          }
                          *(undefined8 *)(puVar32 + -8) = 0x1048ef;
                          iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          if (iVar16 == 0) {
                            *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                            uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                          }
                          else {
                            iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                            *(int *)(&stack0x00000036 + lVar20) = iVar16;
                            *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
                            *(undefined8 *)(puVar32 + -8) = 0x10490c;
                            uVar34 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                            *(undefined8 *)(puVar32 + -8) = 0x10491b;
                            func_0x(uVar34,&stack0x00000210 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x104927;
                            iVar16 = func_0x(&stack0x00000210 + lVar20);
                            uVar39 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar16;
                            *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar39;
                          }
                          if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                             (*(ulonglong *)(&stack0x0000002e + lVar20) <
                              (ulonglong)uVar39 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                            *(undefined8 *)(puVar32 + -8) = 0x1049e6;
                            cVar10 = func_0x(0x1e80c50);
                            if (cVar10 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x1049ef;
                              cVar10 = func_0x();
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x1049ff;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x104a1b;
                                  (*_DAT_)(0x22,0x44,0x15);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x104a41;
                                  (*_DAT_)(1,0x17719d8,0x18916a8);
                                }
                              }
                            }
                            uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x104a4f;
                            func_0x(uVar34,0x12);
                            uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                          }
                          if (0x3f3b < uVar39 - 1) {
                            *(undefined8 *)(puVar32 + -8) = 0x104a68;
                            cVar10 = func_0x(0x1e80c50);
                            if (cVar10 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x104a71;
                              cVar10 = func_0x();
                              if (cVar10 != '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x104a81;
                                cVar10 = func_0x(0x1e80c50);
                                if (cVar10 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x104a9d;
                                  (*_DAT_)(0x22,0x44,0x15);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x104ac3;
                                  (*_DAT_)(1,0x17719d8,0x18916a8);
                                }
                              }
                            }
                            uVar34 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar32 + -8) = 0x104ad1;
                            func_0x(uVar34,5);
                          }
                        }
LAB_:
                        *(undefined8 *)(puVar32 + -8) = 0x104ad9;
                        iVar16 = func_0x(uVar23);
                        uVar39 = iVar16 + 1;
                        if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar39) {
                          iVar16 = *(int *)((longlong)&uStackX_20 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x104af9;
                          func_0x((longlong)&sStackX_10 + lVar20 + 2,0,uVar39 - iVar16);
                          *(undefined8 *)(puVar32 + -8) = 0x104b02;
                          iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          if (iVar16 != 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x104b14;
                            func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar39);
                          }
                          *(uint *)((longlong)&uStackX_20 + lVar20) = uVar39;
                        }
                        *(undefined8 *)(puVar32 + -8) = 0x104b1f;
                        iVar16 = func_0x(uVar23);
                        if (pcVar6 != (char *)0x0) {
                          *(char *)((longlong)iVar16 +
                                   *(longlong *)((longlong)&pbStackX_18 + lVar20)) = *pcVar6;
                        }
                      }
                      else {
                        cVar10 = *pcVar6;
                        *(undefined8 *)(puVar32 + -8) = 0x10453a;
                        iVar16 = func_0x(uVar23);
                        uVar39 = iVar16 + 1;
                        if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar39) {
                          iVar50 = *(int *)((longlong)&uStackX_20 + lVar20);
                          *(undefined8 *)(puVar32 + -8) = 0x10455d;
                          func_0x((longlong)&sStackX_10 + lVar20 + 2,0,uVar39 - iVar50);
                          *(undefined8 *)(puVar32 + -8) = 0x104566;
                          iVar50 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          if (iVar50 != 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x104578;
                            func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar39);
                          }
                          *(uint *)((longlong)&uStackX_20 + lVar20) = uVar39;
                        }
                        pbVar29 = (byte *)((longlong)iVar16 +
                                          *(longlong *)((longlong)&pbStackX_18 + lVar20));
                        bVar53 = *pbVar29;
                        *(undefined8 *)(puVar32 + -8) = 0x10458d;
                        bVar11 = func_0x(uVar23);
                        if (cVar10 == '\0') {
                          bVar53 = bVar53 & ~(byte)(1 << (bVar11 & 0x1f));
                        }
                        else {
                          bVar53 = bVar53 | (byte)(1 << (bVar11 & 0x1f));
                        }
                        *pbVar29 = bVar53;
                      }
                    }
                    lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
                  }
                  else {
                    *(undefined8 *)(puVar32 + 0x20) = 0x14edeb8;
                    *(undefined8 *)(puVar32 + -8) = 0x1044f7;
                    (*_DAT_)(1,0x18f2d10,0x191f650);
                  }
                }
                lVar24 = lVar24 + 0x50;
                *(longlong *)(&stack0x000000c0 + lVar20) = lVar24;
                iVar16 = *(int *)(&stack0x0000005c + lVar20);
                *(uint *)(&stack0x0000005c + lVar20) = iVar16 + 1U;
                lVar27 = *(longlong *)(&stack0x00000068 + lVar20);
              } while (iVar16 + 1U < *(uint *)(&stack0x00000088 + lVar20));
              uVar56 = (ulonglong)*(uint *)(&stack0x00000048 + lVar20);
            }
            puVar22 = (undefined2 *)0x0;
            if ((int)uVar56 != 0) {
              lVar27 = *(longlong *)(&stack0x00000068 + lVar20);
LAB_:
              uVar39 = (uint)uVar56;
              uVar44 = uVar39 - 1;
              if (*(int *)((ulonglong)uVar44 * 0x20 + 8 + lVar27) == 0) goto code_r0x001045f8;
              *(short *)(&stack0x0000002c + lVar20) = (short)uVar56;
              iVar16 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + uVar39 * 2;
              *(int *)(&stack0x00000028 + lVar20) = iVar16;
              *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16;
              *(undefined8 *)(puVar32 + -8) = 0x105d50;
              pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *pbVar29 = *pbVar29 | 0x20;
              if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 0x3f3d) {
                *(undefined8 *)(puVar32 + -8) = 0x105d65;
                puVar22 = (undefined2 *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                *puVar22 = (short)uVar56;
              }
              uVar44 = 0;
              if (uVar39 != 0) {
                puVar46 = (uint *)(lVar27 + 0xc);
                do {
                  uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                  lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  uVar40 = puVar46[-1];
                  uVar42 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + uVar40;
                  *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar42;
                  if (uVar42 < 0x3f3d) {
                    uVar43 = *puVar46;
                    *(undefined8 *)(puVar32 + -8) = 0x105db2;
                    func_0x(puVar22 + 1,uVar44,uVar42,uVar43 & 1);
                    uVar23 = *(undefined8 *)(puVar46 + -3);
                    *(undefined8 *)(puVar32 + -8) = 0x105dc4;
                    func_0x((ulonglong)uVar18 + lVar27,uVar40,uVar23,uVar40);
                  }
                  uVar44 = uVar44 + 1;
                  puVar46 = puVar46 + 8;
                } while (uVar44 < uVar39);
              }
              if (0x3f3c < *(uint *)((longlong)&sStackX_10 + lVar20 + 4)) {
                uVar23 = 0xb9;
                goto LAB_;
              }
            }
          }
LAB_:
          uVar39 = 0;
          if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
            *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
            *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                 *(undefined4 *)((longlong)&uStackX_20 + lVar20);
            *(undefined8 *)(puVar32 + -8) = 0x105e12;
            pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((*pbVar29 & 0x10) != 0) {
              *(undefined8 *)(puVar32 + -8) = 0x105e20;
              pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((*pbVar29 & 0x10) != 0) {
                uVar39 = (uint)*(ushort *)
                                ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                                *(longlong *)((longlong)&pbStackX_18 + lVar20));
              }
              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                   (uVar39 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
            }
            *(undefined8 *)(puVar32 + -8) = 0x105e4f;
            pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((*pbVar29 & 0x20) == 0) {
              uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
              *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
              *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
              *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
            }
            else {
              *(undefined8 *)(puVar32 + -8) = 0x105e61;
              puVar52 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              uVar13 = *puVar52;
              *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
              if (uVar13 == 0) {
                *(undefined8 *)(puVar32 + -8) = 0x105e7f;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x105e88;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x105e98;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar32 + -8) = 0x105eb4;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar32 + 0x20) = 0;
                      *(undefined8 *)(puVar32 + -8) = 0x105eda;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x105ee8;
                func_0x(uVar23,3);
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
              }
              uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar13 * 2;
              *(uint *)(&stack0x00000028 + lVar20) = uVar39;
              if (0x1f9e < uVar39) {
                *(undefined8 *)(puVar32 + -8) = 0x105f11;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x105f1a;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x105f2a;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar32 + -8) = 0x105f46;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar32 + 0x20) = 0;
                      *(undefined8 *)(puVar32 + -8) = 0x105f6c;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x105f7a;
                func_0x(uVar23,4);
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
              }
              *(undefined8 *)(puVar32 + -8) = 0x105f92;
              uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
              *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
              if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                  *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                *(undefined8 *)(puVar32 + -8) = 0x105fa9;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x105fb2;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x105fc2;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar32 + -8) = 0x105fde;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar32 + 0x20) = 0;
                      *(undefined8 *)(puVar32 + -8) = 0x106004;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x106012;
                func_0x(uVar23,4);
              }
              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
              do {
                *(undefined8 *)(puVar32 + -8) = 0x10602d;
                iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                if (iVar16 == 0) break;
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x106042;
                lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if (uVar13 == 1) {
                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                }
                else {
                  *(undefined8 *)(puVar32 + -8) = 0x10605e;
                  uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                  uVar39 = (uint)uVar38;
                }
                *(undefined8 *)(puVar32 + -8) = 0x10606e;
                uVar13 = func_0x(lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                if ((uVar39 < uVar44) || (uVar13 < uVar39)) {
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar32 + -8) = 0x10608a;
                  func_0x(uVar23,7);
                  uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                }
                if ((uVar39 < uVar44) || (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar39))
                goto LAB_;
                lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar39);
                if (uVar13 == 5) {
                  puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar52 = *puVar52 | 2;
                  *(short *)(&stack0x0000002c + lVar20) = *(short *)(&stack0x0000002c + lVar20) + -1
                  ;
                  *(short *)(&stack0x0000003a + lVar20) = (short)uVar39;
                  lVar27 = (ulonglong)(uVar39 & 0xffff) + lVar27;
                  *(undefined8 *)(puVar32 + -8) = 0x1060f4;
                  iVar16 = func_0x(lVar27);
                  if (iVar16 == 0) {
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                  }
                  else {
                    *(undefined8 *)(puVar32 + -8) = 0x106100;
                    sVar15 = func_0x(lVar27);
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         *(ushort *)(&stack0x0000003c + lVar20) ^
                         (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                  }
                  *(undefined8 *)(puVar32 + -8) = 0x10612d;
                  uVar13 = func_0x(lVar27);
                  *(ushort *)(&stack0x0000003c + lVar20) =
                       *(ushort *)(&stack0x0000003c + lVar20) ^
                       (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
                  break;
                }
                if (uVar13 < 0x400) break;
                puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                *puVar49 = *puVar49 | 1;
                uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
              } while (uVar13 != 0);
            }
            *(undefined8 *)(puVar32 + -8) = 0x10615c;
            iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if (iVar16 == 0) {
              *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
            }
            else {
              iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
              *(int *)(&stack0x00000036 + lVar20) = iVar16;
              *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
              *(undefined8 *)(puVar32 + -8) = 0x106175;
              uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *(undefined8 *)(puVar32 + -8) = 0x106184;
              func_0x(uVar23,&stack0x00000228 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x106190;
              iVar16 = func_0x(&stack0x00000228 + lVar20);
              piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
              *piVar45 = *piVar45 + iVar16;
            }
            if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
               (*(ulonglong *)(&stack0x0000002e + lVar20) <
                (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
              *(undefined8 *)(puVar32 + -8) = 0x1061be;
              cVar10 = func_0x(0x1e80c50);
              if (cVar10 != '\0') {
                *(undefined8 *)(puVar32 + -8) = 0x1061c7;
                cVar10 = func_0x();
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x1061d7;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 == '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x1061f3;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar32 + 0x20) = 0;
                    *(undefined8 *)(puVar32 + -8) = 0x106219;
                    (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                  }
                }
              }
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x106227;
              func_0x(uVar23,0x12);
            }
            if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
              *(undefined8 *)(puVar32 + -8) = 0x10623f;
              cVar10 = func_0x(0x1e80c50);
              if (cVar10 != '\0') {
                *(undefined8 *)(puVar32 + -8) = 0x106248;
                cVar10 = func_0x();
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x106258;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 == '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x106274;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar32 + 0x20) = 0;
                    *(undefined8 *)(puVar32 + -8) = 0x10629a;
                    (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                  }
                }
              }
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x1062a8;
              func_0x(uVar23,5);
            }
          }
LAB_:
          if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 9) {
            *(undefined8 *)(puVar32 + -8) = 0x1062b7;
            cVar10 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((cVar10 != '\0') && (cVar10 != '\f')) goto LAB_;
            uVar39 = 9;
          }
          else {
LAB_:
            uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
          }
          uVar19 = 9;
          *(undefined8 *)(puVar32 + -8) = 0x1062dc;
          iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
          uVar44 = *(uint *)(&stack0x00000036 + lVar20);
          if (iVar16 == 0) {
            uVar44 = uVar39;
          }
          puVar47 = puVar32;
          if (uVar44 < 0x1f7d) goto LAB_;
          uVar23 = *(undefined8 *)(&stack0x00000080 + lVar20);
          *(undefined8 *)(puVar32 + -8) = 0x1062fd;
          func_0x(uVar23,(longlong)&sStackX_10 + lVar20 + 2);
          uVar39 = 0;
          if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
            *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
            *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                 *(undefined4 *)((longlong)&uStackX_20 + lVar20);
            *(undefined8 *)(puVar32 + -8) = 0x10631b;
            pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((*pbVar29 & 0x10) != 0) {
              *(undefined8 *)(puVar32 + -8) = 0x106329;
              pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              uVar44 = uVar39;
              if ((*pbVar29 & 0x10) != 0) {
                uVar44 = (uint)*(ushort *)
                                ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                                *(longlong *)((longlong)&pbStackX_18 + lVar20));
              }
              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                   (uVar44 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
            }
            *(undefined8 *)(puVar32 + -8) = 0x106358;
            pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((*pbVar29 & 0x20) == 0) {
              uVar3 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
              *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar3;
              *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
              *(undefined4 *)(&stack0x00000028 + lVar20) = uVar3;
            }
            else {
              *(undefined8 *)(puVar32 + -8) = 0x10636a;
              puVar52 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              uVar13 = *puVar52;
              *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
              if (uVar13 == 0) {
                *(undefined8 *)(puVar32 + -8) = 0x106388;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x106391;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x1063a1;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar32 + -8) = 0x1063bd;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar32 + 0x20) = 0;
                      *(undefined8 *)(puVar32 + -8) = 0x1063e3;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x1063f1;
                func_0x(uVar23,3);
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
              }
              uVar44 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar13 * 2;
              *(uint *)(&stack0x00000028 + lVar20) = uVar44;
              if (0x1f9e < uVar44) {
                *(undefined8 *)(puVar32 + -8) = 0x10641a;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x106423;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x106433;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar32 + -8) = 0x10644f;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar32 + 0x20) = 0;
                      *(undefined8 *)(puVar32 + -8) = 0x106475;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x106483;
                func_0x(uVar23,4);
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
              }
              *(undefined8 *)(puVar32 + -8) = 0x10649b;
              uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
              *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
              if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                  *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                *(undefined8 *)(puVar32 + -8) = 0x1064b2;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x1064bb;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x1064cb;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar32 + -8) = 0x1064e7;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar32 + 0x20) = 0;
                      *(undefined8 *)(puVar32 + -8) = 0x10650d;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x10651b;
                func_0x(uVar23,4);
              }
              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
              do {
                *(undefined8 *)(puVar32 + -8) = 0x10653d;
                iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                if (iVar16 == 0) break;
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x106552;
                lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if (uVar13 == 1) {
                  uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                }
                else {
                  *(undefined8 *)(puVar32 + -8) = 0x10656e;
                  uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                  uVar44 = (uint)uVar38;
                }
                *(undefined8 *)(puVar32 + -8) = 0x10657e;
                uVar13 = func_0x(lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                if ((uVar44 < uVar18) || (uVar13 < uVar44)) {
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar32 + -8) = 0x10659a;
                  func_0x(uVar23,7);
                  uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                }
                if ((uVar44 < uVar18) || (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar44))
                goto LAB_;
                lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar44);
                if (uVar13 == 5) {
                  puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar52 = *puVar52 | 2;
                  *(short *)(&stack0x0000002c + lVar20) = *(short *)(&stack0x0000002c + lVar20) + -1
                  ;
                  *(short *)(&stack0x0000003a + lVar20) = (short)uVar44;
                  lVar27 = (ulonglong)(uVar44 & 0xffff) + lVar27;
                  *(undefined8 *)(puVar32 + -8) = 0x106604;
                  iVar16 = func_0x(lVar27);
                  if (iVar16 == 0) {
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                  }
                  else {
                    *(undefined8 *)(puVar32 + -8) = 0x106610;
                    sVar15 = func_0x(lVar27);
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         *(ushort *)(&stack0x0000003c + lVar20) ^
                         (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                  }
                  *(undefined8 *)(puVar32 + -8) = 0x10663d;
                  uVar13 = func_0x(lVar27);
                  *(ushort *)(&stack0x0000003c + lVar20) =
                       *(ushort *)(&stack0x0000003c + lVar20) ^
                       (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
                  break;
                }
                if (uVar13 < 0x400) break;
                puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                *puVar49 = *puVar49 | 1;
                uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
              } while (uVar13 != 0);
            }
            *(undefined8 *)(puVar32 + -8) = 0x10666c;
            iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if (iVar16 == 0) {
              *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
            }
            else {
              iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
              *(int *)(&stack0x00000036 + lVar20) = iVar16;
              *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
              *(undefined8 *)(puVar32 + -8) = 0x106685;
              uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *(undefined8 *)(puVar32 + -8) = 0x106694;
              func_0x(uVar23,&stack0x00000230 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x1066a0;
              iVar16 = func_0x(&stack0x00000230 + lVar20);
              piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
              *piVar45 = *piVar45 + iVar16;
            }
            if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
               (*(ulonglong *)(&stack0x0000002e + lVar20) <
                (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
              *(undefined8 *)(puVar32 + -8) = 0x1066ce;
              cVar10 = func_0x(0x1e80c50);
              if (cVar10 != '\0') {
                *(undefined8 *)(puVar32 + -8) = 0x1066d7;
                cVar10 = func_0x();
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x1066e7;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 == '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x106703;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar32 + 0x20) = 0;
                    *(undefined8 *)(puVar32 + -8) = 0x106729;
                    (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                  }
                }
              }
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x106737;
              func_0x(uVar23,0x12);
            }
            if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
              *(undefined8 *)(puVar32 + -8) = 0x10674f;
              cVar10 = func_0x(0x1e80c50);
              if (cVar10 != '\0') {
                *(undefined8 *)(puVar32 + -8) = 0x106758;
                cVar10 = func_0x();
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x106768;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 == '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x106784;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar32 + 0x20) = 0;
                    *(undefined8 *)(puVar32 + -8) = 0x1067aa;
                    (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                  }
                }
              }
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x1067b8;
              func_0x(uVar23,5);
            }
          }
LAB_:
          if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 9) {
            *(undefined8 *)(puVar32 + -8) = 0x1067c7;
            cVar10 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((cVar10 != '\0') && (cVar10 != '\f')) goto LAB_;
            uVar44 = 9;
          }
          else {
LAB_:
            uVar44 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
          }
          *(undefined8 *)(puVar32 + -8) = 0x1067e0;
          iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
          uVar18 = *(uint *)(&stack0x00000036 + lVar20);
          if (iVar16 == 0) {
            uVar18 = uVar44;
          }
          if (uVar18 < 0x1f7d) goto LAB_;
          if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
            *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
            *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                 *(undefined4 *)((longlong)&uStackX_20 + lVar20);
            *(undefined8 *)(puVar32 + -8) = 0x106812;
            pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((*pbVar29 & 0x10) != 0) {
              *(undefined8 *)(puVar32 + -8) = 0x106820;
              pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((*pbVar29 & 0x10) != 0) {
                uVar39 = (uint)*(ushort *)
                                ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                                *(longlong *)((longlong)&pbStackX_18 + lVar20));
              }
              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                   (uVar39 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
            }
            *(undefined8 *)(puVar32 + -8) = 0x10684f;
            pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((*pbVar29 & 0x20) == 0) {
              uVar3 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
              *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar3;
              *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
              *(undefined4 *)(&stack0x00000028 + lVar20) = uVar3;
            }
            else {
              *(undefined8 *)(puVar32 + -8) = 0x106861;
              puVar52 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              uVar13 = *puVar52;
              *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
              if (uVar13 == 0) {
                *(undefined8 *)(puVar32 + -8) = 0x10687f;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x106888;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x106898;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar32 + -8) = 0x1068b4;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar32 + 0x20) = 0;
                      *(undefined8 *)(puVar32 + -8) = 0x1068da;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x1068e8;
                func_0x(uVar23,3);
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
              }
              uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar13 * 2;
              *(uint *)(&stack0x00000028 + lVar20) = uVar39;
              if (0x1f9e < uVar39) {
                *(undefined8 *)(puVar32 + -8) = 0x106911;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x10691a;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x10692a;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar32 + -8) = 0x106946;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar32 + 0x20) = 0;
                      *(undefined8 *)(puVar32 + -8) = 0x10696c;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x10697a;
                func_0x(uVar23,4);
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
              }
              *(undefined8 *)(puVar32 + -8) = 0x106992;
              uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
              *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
              if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                  *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                *(undefined8 *)(puVar32 + -8) = 0x1069a9;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x1069b2;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x1069c2;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar32 + -8) = 0x1069de;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar32 + 0x20) = 0;
                      *(undefined8 *)(puVar32 + -8) = 0x106a04;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x106a12;
                func_0x(uVar23,4);
              }
              uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
              do {
                *(undefined8 *)(puVar32 + -8) = 0x106a2d;
                iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                if (iVar16 == 0) break;
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                *(undefined8 *)(puVar32 + -8) = 0x106a42;
                lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if (uVar13 == 1) {
                  uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                }
                else {
                  *(undefined8 *)(puVar32 + -8) = 0x106a5e;
                  uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                  uVar39 = (uint)uVar38;
                }
                *(undefined8 *)(puVar32 + -8) = 0x106a6e;
                uVar13 = func_0x(lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                if ((uVar39 < uVar44) || (uVar13 < uVar39)) {
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar32 + -8) = 0x106a8a;
                  func_0x(uVar23,7);
                  uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                }
                if ((uVar39 < uVar44) || (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar39))
                goto LAB_;
                lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar39);
                if (uVar13 == 5) {
                  puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar52 = *puVar52 | 2;
                  *(short *)(&stack0x0000002c + lVar20) = *(short *)(&stack0x0000002c + lVar20) + -1
                  ;
                  *(short *)(&stack0x0000003a + lVar20) = (short)uVar39;
                  lVar27 = (ulonglong)(uVar39 & 0xffff) + lVar27;
                  *(undefined8 *)(puVar32 + -8) = 0x106af4;
                  iVar16 = func_0x(lVar27);
                  if (iVar16 == 0) {
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                  }
                  else {
                    *(undefined8 *)(puVar32 + -8) = 0x106b00;
                    sVar15 = func_0x(lVar27);
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         *(ushort *)(&stack0x0000003c + lVar20) ^
                         (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                  }
                  *(undefined8 *)(puVar32 + -8) = 0x106b2d;
                  uVar13 = func_0x(lVar27);
                  *(ushort *)(&stack0x0000003c + lVar20) =
                       *(ushort *)(&stack0x0000003c + lVar20) ^
                       (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
                  break;
                }
                if (uVar13 < 0x400) break;
                puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                *puVar49 = *puVar49 | 1;
                uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
              } while (uVar13 != 0);
            }
            *(undefined8 *)(puVar32 + -8) = 0x106b5c;
            iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if (iVar16 == 0) {
              *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
            }
            else {
              iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
              *(int *)(&stack0x00000036 + lVar20) = iVar16;
              *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
              *(undefined8 *)(puVar32 + -8) = 0x106b75;
              uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *(undefined8 *)(puVar32 + -8) = 0x106b84;
              func_0x(uVar23,&stack0x00000238 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x106b90;
              iVar16 = func_0x(&stack0x00000238 + lVar20);
              piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
              *piVar45 = *piVar45 + iVar16;
            }
            if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
               (*(ulonglong *)(&stack0x0000002e + lVar20) <
                (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
              *(undefined8 *)(puVar32 + -8) = 0x106bbe;
              cVar10 = func_0x(0x1e80c50);
              if (cVar10 != '\0') {
                *(undefined8 *)(puVar32 + -8) = 0x106bc7;
                cVar10 = func_0x();
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x106bd7;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 == '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x106bf3;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar32 + 0x20) = 0;
                    *(undefined8 *)(puVar32 + -8) = 0x106c19;
                    (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                  }
                }
              }
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x106c27;
              func_0x(uVar23,0x12);
            }
            if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
              *(undefined8 *)(puVar32 + -8) = 0x106c3f;
              cVar10 = func_0x(0x1e80c50);
              if (cVar10 != '\0') {
                *(undefined8 *)(puVar32 + -8) = 0x106c48;
                cVar10 = func_0x();
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar32 + -8) = 0x106c58;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 == '\0') {
                    *(undefined8 *)(puVar32 + -8) = 0x106c74;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar32 + 0x20) = 0;
                    *(undefined8 *)(puVar32 + -8) = 0x106c9a;
                    (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                  }
                }
              }
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar32 + -8) = 0x106ca8;
              func_0x(uVar23,5);
            }
          }
LAB_:
          if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 9) {
            *(undefined8 *)(puVar32 + -8) = 0x106cb7;
            cVar10 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((cVar10 != '\0') && (cVar10 != '\f')) goto LAB_;
          }
          else {
LAB_:
            uVar19 = *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
          }
          *(undefined8 *)(puVar32 + -8) = 0x106cd6;
          func_0x(7,uVar19,0x1f7c);
          goto LAB_;
        }
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106cdd;
        psVar21 = (short *)(*pcVar4)(param_2);
        *(short **)(&stack0x00000070 + lVar20) = psVar21;
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106cec;
        lVar27 = func_0x(param_3);
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106cf7;
        iVar16 = func_0x(lVar27);
        puVar47 = &stack0xffffffffffffffc0 + lVar20;
        if (iVar16 == 0) {
          if (*psVar21 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106d0d;
            iVar16 = func_0x();
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106d14;
            iVar16 = func_0x(psVar21 + 1);
          }
          if (iVar16 == 0) {
LAB_:
            bVar9 = false;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106d20;
            iVar16 = func_0x(psVar21);
            if (iVar16 == 0) goto LAB_;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106d33;
            uVar23 = func_0x(psVar21,&stack0x000002c0 + lVar20);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106d3b;
            iVar16 = func_0x(uVar23);
            if (iVar16 == 0) goto LAB_;
            bVar9 = true;
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106d4f;
          iVar16 = func_0x(lVar27);
          uVar44 = 0;
          if (iVar16 == 0) {
            if (*psVar21 == 0) {
              iVar16 = *(int *)(psVar21 + 8);
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106d6a;
              iVar16 = func_0x(psVar21 + 1);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106d75;
            iVar50 = func_0x(lVar27 + 0x10);
            if (iVar16 != iVar50) goto LAB_;
            if (*psVar21 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106d8c;
              pbVar29 = (byte *)func_0x(psVar21 + 1);
              if ((*pbVar29 & 0x10) != 0) {
                uVar39 = (uint)*(ushort *)
                                ((ulonglong)*(uint *)(psVar21 + 8) + *(longlong *)(psVar21 + 4));
              }
            }
            else {
              uVar39 = (uint)(ushort)psVar21[1];
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106db0;
            lVar24 = func_0x(*(undefined8 *)(&stack0x00000080 + lVar20));
            if ((uVar39 != *(ushort *)(lVar24 + 0x2c)) || (bVar9)) goto LAB_;
            sVar15 = *psVar21;
            *psVar2 = sVar15;
            if (sVar15 == 0) {
              if (*(int *)(psVar21 + 2) == 0) {
                psVar21[1] = 0;
                *(undefined4 *)(psVar21 + 10) = *(undefined4 *)(psVar21 + 8);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106df3;
                pbVar29 = (byte *)func_0x(psVar21 + 1);
                if ((*pbVar29 & 0x10) != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106e01;
                  pbVar29 = (byte *)func_0x(psVar21 + 1);
                  if ((*pbVar29 & 0x10) != 0) {
                    uVar44 = (uint)*(ushort *)
                                    ((ulonglong)*(uint *)(psVar21 + 8) + *(longlong *)(psVar21 + 4))
                    ;
                  }
                  *(uint *)(psVar21 + 10) = *(int *)(psVar21 + 10) + (uVar44 + 7 >> 3) + 2;
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106e2b;
                pbVar29 = (byte *)func_0x(psVar21 + 1);
                if ((*pbVar29 & 0x20) == 0) {
                  *(undefined4 *)(psVar21 + 2) = *(undefined4 *)(psVar21 + 10);
                  psVar21[0xe] = 0;
                  *(undefined4 *)(psVar21 + 0xc) = *(undefined4 *)(psVar21 + 10);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106e3d;
                  puVar52 = (ushort *)func_0x(psVar21 + 1);
                  uVar13 = *puVar52;
                  psVar21[0xe] = uVar13;
                  if (uVar13 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106e58;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106e61;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106e71;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106e8d;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106eb1;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(psVar21 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106ebf;
                    func_0x(uVar23,3);
                    uVar13 = psVar21[0xe];
                  }
                  uVar39 = *(int *)(psVar21 + 10) + 2 + (uint)uVar13 * 2;
                  *(uint *)(psVar21 + 0xc) = uVar39;
                  if (0x1f9e < uVar39) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106ee6;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106eef;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106eff;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106f1b;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106f3f;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(psVar21 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106f4d;
                    func_0x(uVar23,4);
                    uVar13 = psVar21[0xe];
                  }
                  puVar52 = puVar52 + 1;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106f63;
                  uVar13 = func_0x(puVar52,(ulonglong)uVar13 - 1);
                  *(uint *)(psVar21 + 2) = (uint)uVar13;
                  if ((uint)uVar13 <= *(uint *)(psVar21 + 0xc) &&
                      *(uint *)(psVar21 + 0xc) != (uint)uVar13) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106f7a;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106f83;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106f93;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106faf;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106fd7;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(psVar21 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106fe5;
                    func_0x(uVar23,4);
                  }
                  uVar13 = psVar21[0xe];
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x106ff3;
                  iVar16 = func_0x(puVar52,uVar13 - 1);
                  while (iVar16 != 0) {
                    uVar13 = psVar21[0xe];
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10700d;
                    lVar24 = func_0x(psVar21 + 1);
                    if (uVar13 == 1) {
                      uVar39 = *(uint *)(psVar21 + 0xc);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10702a;
                      uVar38 = func_0x(lVar24 + 2,(ulonglong)uVar13 - 2);
                      uVar39 = (uint)uVar38;
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10703a;
                    uVar13 = func_0x(lVar24 + 2,(ulonglong)(uint)uVar13 - 1);
                    if ((uVar39 < *(uint *)(psVar21 + 0xc)) || (uVar13 < uVar39)) {
                      uVar23 = *(undefined8 *)(psVar21 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107054;
                      func_0x(uVar23,7);
                      if (uVar39 < *(uint *)(psVar21 + 0xc)) goto LAB_;
                    }
                    if (*(uint *)(psVar21 + 2) < uVar39) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(psVar21 + 4)) == 5) {
                      psVar21[1] = psVar21[1] | 2;
                      psVar21[0xe] = psVar21[0xe] + -1;
                      psVar21[0x15] = (short)uVar39;
                      lVar24 = (ulonglong)(uVar39 & 0xffff) + *(longlong *)(psVar21 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10711f;
                      iVar16 = func_0x(lVar24);
                      if (iVar16 == 0) {
                        psVar21[0x16] = psVar21[0x16] & 0xc7ff;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10712b;
                        uVar13 = func_0x(lVar24);
                        psVar21[0x16] = psVar21[0x16] & 0xc7ff;
                        psVar21[0x16] = psVar21[0x16] | (uVar13 & 7) << 0xb;
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107153;
                      uVar13 = func_0x(lVar24);
                      psVar21[0x16] = psVar21[0x16] & 0xf800;
                      psVar21[0x16] = psVar21[0x16] | uVar13 & 0x7ff;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(psVar21 + 4)) < 0x400) break;
                    psVar21[1] = psVar21[1] | 1;
                    uVar13 = psVar21[0xe] - 1;
                    psVar21[0xe] = uVar13;
                    if (uVar13 == 0) break;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1070a4;
                    iVar16 = func_0x(puVar52,uVar13 - 1);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1070be;
                iVar16 = func_0x(psVar21 + 1);
                if (iVar16 == 0) {
                  *(undefined4 *)(psVar21 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar21 + 0x13) = *(int *)(psVar21 + 2);
                  *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + 0xe;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1070db;
                  uVar23 = func_0x(psVar21 + 1);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1070ea;
                  func_0x(uVar23,&stack0x00000240 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1070f6;
                  iVar16 = func_0x(&stack0x00000240 + lVar20);
                  *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + iVar16;
                }
                uVar39 = *(uint *)(psVar21 + 2);
                if ((*(ulonglong *)(psVar21 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar21 + 0xf) < (ulonglong)uVar39 + *(longlong *)(psVar21 + 4)))
                {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1071a7;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1071b0;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1071c0;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1071dc;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107200;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(psVar21 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10720e;
                  func_0x(uVar23,0x12);
                  uVar39 = *(uint *)(psVar21 + 2);
                }
                if (0x3f3b < uVar39 - 1) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107227;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107230;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107240;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10725c;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107280;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(psVar21 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10728e;
                  func_0x(uVar23,5);
                }
              }
LAB_:
              uVar39 = *(uint *)(psVar21 + 2);
              if (uVar39 < 9) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10729f;
                cVar10 = func_0x(psVar21 + 1);
                if ((cVar10 == '\0') || (cVar10 == '\f')) {
                  uVar39 = 9;
                }
                else {
                  uVar39 = *(uint *)(psVar21 + 2);
                }
              }
              *(undefined4 *)((longlong)&uStackX_20 + lVar20) = *(undefined4 *)(psVar21 + 8);
              *(short *)((longlong)&sStackX_10 + lVar20 + 2) = psVar21[1];
              *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = *(undefined4 *)(psVar21 + 2);
              *(short *)(&stack0x0000002c + lVar20) = psVar21[0xe];
              *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) = *(undefined4 *)(psVar21 + 10);
              *(undefined4 *)(&stack0x00000028 + lVar20) = *(undefined4 *)(psVar21 + 0xc);
              *(undefined4 *)(&stack0x00000036 + lVar20) = *(undefined4 *)(psVar21 + 0x13);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1072ea;
              uVar23 = func_0x(psVar21 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107301;
              func_0x(&stack0x000028a0 + lVar20,0x3f3c,uVar23,uVar39);
              *(undefined **)((longlong)&pbStackX_18 + lVar20) = &stack0x000028a0 + lVar20;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107315;
              iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if (iVar16 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107329;
                uVar13 = func_0x
                                   ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000194 + lVar20);
                *(ushort *)(&stack0x0000003a + lVar20) = uVar13;
                lVar24 = (ulonglong)uVar13 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10733c;
                iVar16 = func_0x(lVar24);
                if (iVar16 == 0) {
                  *(ushort *)(&stack0x0000003c + lVar20) =
                       *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107348;
                  sVar15 = func_0x(lVar24);
                  *(ushort *)(&stack0x0000003c + lVar20) =
                       *(ushort *)(&stack0x0000003c + lVar20) ^
                       (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107375;
                uVar13 = func_0x(lVar24);
                *(ushort *)(&stack0x0000003c + lVar20) =
                     *(ushort *)(&stack0x0000003c + lVar20) ^
                     (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
              }
            }
            else {
              if (*psVar21 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1073bc;
                lVar24 = func_0x(psVar21 + 1);
                if (lVar24 != 0) {
                  if (*psVar21 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1073d5;
                    puVar30 = (undefined8 *)func_0x(psVar21 + 1);
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1073dd;
                  iVar16 = func_0x(puVar30);
                  if (iVar16 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1073fa;
                    func_0x(psVar2,&stack0x000028a0 + lVar20,0x3f3c,psVar21);
                    goto LAB_;
                  }
                }
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107416;
              func_0x((longlong)&sStackX_10 + lVar20 + 2,&stack0x000028a0 + lVar20,0x3f3c,
                              psVar21 + 1);
              if (*psVar21 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10742b;
                func_0x((longlong)&sStackX_10 + lVar20 + 2,0);
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107439;
                uVar23 = func_0x(psVar21 + 1);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107445;
                func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
              }
            }
LAB_:
            if (*psVar2 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1073a8;
              iVar16 = func_0x();
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10744f;
              iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            }
            if (iVar16 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10745c;
              func_0x(psVar2);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107464;
            iVar16 = func_0x(lVar27);
            if (iVar16 == 0) {
              lVar27 = *(longlong *)(&stack0x00000050 + lVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107694;
              uVar23 = func_0x(lVar27);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10769c;
              uVar13 = func_0x(uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1076a7;
              lVar24 = func_0x(lVar27);
              if (uVar13 != 0) {
                uVar56 = (ulonglong)uVar13;
                do {
                  (&stack0x00000059)[lVar20] = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1076da;
                  func_0x(lVar27,lVar24,&stack0x00000059 + lVar20);
                  if ((&stack0x00000059)[lVar20] == '\x03') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107a17;
                    iVar16 = func_0x(lVar24);
                    if (iVar16 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107a2e;
                      (*_DAT_)(6,0x51,0x10,1);
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107a36;
                    uVar14 = func_0x(lVar24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107a41;
                    uVar23 = func_0x(lVar24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107a53;
                    func_0x(psVar2,uVar23,uVar14,1);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1076ec;
                    uVar23 = func_0x();
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1076f4;
                    sVar15 = func_0x(uVar23);
                    if (sVar15 != 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107701;
                      uVar23 = func_0x(lVar24);
                      if (*psVar2 == 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107714;
                        func_0x();
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10771b;
                        func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10772d;
                    func_0x(lVar27,lVar24,&stack0x000000c8 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107735;
                    iVar16 = func_0x(lVar24);
                    uVar39 = 0;
                    if ((iVar16 == 1) || (iVar16 == 2)) {
                      lVar25 = *(longlong *)(&stack0x000000c8 + lVar20);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10787c;
                      iVar16 = func_0x(lVar24);
                      if (iVar16 == 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107888;
                        uVar14 = func_0x();
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107893;
                        uVar23 = func_0x(lVar24);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10789b;
                        iVar16 = func_0x(uVar23);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1078ad;
                        func_0x
                                  ((longlong)iVar16 + *(longlong *)((longlong)&pbStackX_18 + lVar20)
                                   ,lVar25,uVar14);
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1078ba;
                        iVar16 = func_0x(lVar24);
                        if ((iVar16 == 0) || ((*(byte *)(lVar27 + 0x14) & 8) == 0)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1078e7;
                          iVar16 = func_0x(lVar24);
                          if (iVar16 == 0) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107915;
                            uVar13 = func_0x(lVar24);
                            uVar44 = (uint)uVar13;
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1078f3;
                            uVar23 = func_0x();
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107901;
                            uVar34 = func_0x(lVar27,lVar24);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10790c;
                            uVar44 = func_0x(uVar34,uVar23);
                          }
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1078cc;
                          uVar44 = func_0x(lVar24);
                          uVar44 = *(uint *)((ulonglong)uVar44 * 8 + *(longlong *)(lVar27 + 0x38));
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107920;
                        uVar13 = func_0x(lVar24);
                        if (uVar44 < uVar13) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10792f;
                          uVar13 = func_0x(lVar24);
                          uVar39 = uVar13 - uVar44;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10793d;
                          uVar13 = func_0x(lVar24);
                          if (uVar13 < uVar44) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10795a;
                            (*_DAT_)(6,0x5c,0x16,1);
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107962;
                        uVar12 = func_0x(lVar24);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10796e;
                        uVar23 = func_0x(lVar24);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107976;
                        iVar16 = func_0x(uVar23);
                        lVar27 = (longlong)iVar16 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                        if ((lVar25 != 0) && (uVar44 != 0)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107994;
                          func_0x(lVar27,lVar25,uVar44);
                        }
                        if (uVar39 != 0) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1079a9;
                          func_0x((ulonglong)uVar44 + lVar27,uVar12,uVar39);
                        }
                        lVar27 = *(longlong *)(&stack0x00000050 + lVar20);
                      }
                    }
                    else if ((iVar16 == 3) || (iVar16 == 4)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1077aa;
                      iVar16 = func_0x(lVar24);
                      if ((iVar16 == 0) || (**(int **)(&stack0x000000c8 + lVar20) != 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1077c7;
                        iVar16 = func_0x(lVar24);
                        if ((iVar16 == 0) || ((*(byte *)(lVar27 + 0x14) & 8) == 0)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1077f4;
                          iVar16 = func_0x(lVar24);
                          if (iVar16 == 0) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107822;
                            uVar13 = func_0x(lVar24);
                            uVar39 = (uint)uVar13;
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107800;
                            uVar23 = func_0x();
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10780e;
                            uVar34 = func_0x(lVar27,lVar24);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107819;
                            uVar39 = func_0x(uVar34,uVar23);
                          }
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1077d9;
                          uVar39 = func_0x(lVar24);
                          uVar39 = *(uint *)((ulonglong)uVar39 * 8 + *(longlong *)(lVar27 + 0x38));
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10782d;
                      uVar13 = func_0x(lVar24);
                      if (uVar13 < uVar39) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10784a;
                        (*_DAT_)(6,0x52,0x16,0x93);
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107852;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107868;
                      func_0x
                                (psVar2,uVar23,*(undefined8 *)(&stack0x000000c8 + lVar20),uVar39);
                    }
                    else if (iVar16 == 8) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107787;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10779d;
                      func_0x
                                (psVar2,uVar23,*(undefined8 *)(&stack0x000000c8 + lVar20),1);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0x14edeb8;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10777a;
                      (*_DAT_)(1,0x18f2d10,0x191f650,0x380);
                    }
                  }
                  lVar24 = lVar24 + 0x50;
                  uVar56 = uVar56 - 1;
                } while (uVar56 != 0);
              }
            }
            else {
              lVar27 = *(longlong *)(&stack0x00000050 + lVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107478;
              uVar23 = func_0x(lVar27);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107483;
              uVar13 = func_0x(uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10748e;
              lVar24 = func_0x(uVar23);
              if (uVar13 != 0) {
                uVar56 = (ulonglong)uVar13;
                do {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1074ab;
                  cVar10 = func_0x(lVar27,lVar24);
                  if (cVar10 == '\x03') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107649;
                    iVar16 = func_0x(lVar24);
                    if (iVar16 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107661;
                      (*_DAT_)(6,0x51,0x10,4);
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107669;
                    uVar14 = func_0x(lVar24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107674;
                    uVar23 = func_0x(lVar24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107686;
                    func_0x(psVar2,uVar23,uVar14,1);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1074bb;
                    uVar23 = func_0x();
                    if (*psVar2 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1074ce;
                      func_0x();
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1074d5;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1074e7;
                    func_0x(lVar27,lVar24,&stack0x00000248 + lVar20);
                    lVar25 = *(longlong *)(&stack0x00000248 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1074f6;
                    iVar16 = func_0x(lVar24);
                    if (iVar16 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107502;
                      uVar14 = func_0x();
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10750d;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107515;
                      iVar16 = func_0x(uVar23);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107527;
                      func_0x
                                ((longlong)iVar16 + *(longlong *)((longlong)&pbStackX_18 + lVar20),
                                 lVar25,uVar14);
                    }
                    else {
                      iVar50 = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107534;
                      iVar16 = func_0x(lVar24);
                      if ((iVar16 == 0) || ((*(byte *)(lVar27 + 0x14) & 8) == 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107562;
                        iVar16 = func_0x(lVar24);
                        if (iVar16 == 0) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107590;
                          uVar13 = func_0x(lVar24);
                          uVar39 = (uint)uVar13;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10756e;
                          uVar23 = func_0x();
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10757c;
                          uVar34 = func_0x(lVar27,lVar24);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107587;
                          uVar39 = func_0x(uVar34,uVar23);
                        }
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107547;
                        uVar39 = func_0x(lVar24);
                        uVar39 = *(uint *)((ulonglong)uVar39 * 8 + *(longlong *)(lVar27 + 0x38));
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10759b;
                      uVar13 = func_0x(lVar24);
                      if (uVar39 < uVar13) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1075aa;
                        uVar13 = func_0x(lVar24);
                        iVar50 = uVar13 - uVar39;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1075b6;
                        uVar13 = func_0x(lVar24);
                        if (uVar13 < uVar39) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1075d3;
                          (*_DAT_)(6,0x5c,0x16,1);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1075db;
                      uVar12 = func_0x(lVar24);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1075e7;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1075ef;
                      iVar16 = func_0x(uVar23);
                      lVar27 = (longlong)iVar16 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      if ((lVar25 != 0) && (uVar39 != 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10760d;
                        func_0x(lVar27,lVar25,uVar39);
                      }
                      if (iVar50 != 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107621;
                        func_0x((ulonglong)uVar39 + lVar27,uVar12,iVar50);
                      }
                      lVar27 = *(longlong *)(&stack0x00000050 + lVar20);
                    }
                  }
                  lVar24 = lVar24 + 0x50;
                  uVar56 = uVar56 - 1;
                } while (uVar56 != 0);
              }
            }
            if (*psVar2 == 0) {
              if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                     *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1079f2;
                pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((*pbVar29 & 0x10) != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107a00;
                  pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if ((*pbVar29 & 0x10) == 0) {
                    uVar39 = 0;
                  }
                  else {
                    uVar39 = (uint)*(ushort *)
                                    ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                                    *(longlong *)((longlong)&pbStackX_18 + lVar20));
                  }
                  *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                       (uVar39 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107a74;
                pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((*pbVar29 & 0x20) == 0) {
                  uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                  *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                  *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                  *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107a86;
                  puVar52 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  uVar13 = *puVar52;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                  if (uVar13 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107aa4;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107aad;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107abd;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107ad9;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107aff;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107b0d;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
                    uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                  }
                  uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar13 * 2;
                  *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                  if (0x1f9e < uVar39) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107b36;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107b3f;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107b4f;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107b6b;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107b91;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107b9f;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                    uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107bb7;
                  uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
                  *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
                  if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                      *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107bce;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107bd7;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107be7;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107c03;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107c29;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107c37;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                  }
                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                  do {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107c4e;
                    iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                    if (iVar16 == 0) break;
                    uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107c63;
                    lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (uVar13 == 1) {
                      uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107c7f;
                      uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                      uVar39 = (uint)uVar38;
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107c8f;
                    uVar13 = func_0x(lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                    uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                    if ((uVar39 < uVar44) || (uVar13 < uVar39)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107cab;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),7);
                      uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                    }
                    if ((uVar39 < uVar44) ||
                       (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar39)) goto LAB_;
                    lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar39);
                    if (uVar13 == 5) {
                      puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar52 = *puVar52 | 2;
                      *(short *)(&stack0x0000002c + lVar20) =
                           *(short *)(&stack0x0000002c + lVar20) + -1;
                      *(short *)(&stack0x0000003a + lVar20) = (short)uVar39;
                      lVar27 = (ulonglong)(uVar39 & 0xffff) + lVar27;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107d57;
                      iVar16 = func_0x(lVar27);
                      if (iVar16 == 0) {
                        *(ushort *)(&stack0x0000003c + lVar20) =
                             *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107d63;
                        sVar15 = func_0x(lVar27);
                        *(ushort *)(&stack0x0000003c + lVar20) =
                             *(ushort *)(&stack0x0000003c + lVar20) ^
                             (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107d90;
                      uVar13 = func_0x(lVar27);
                      *(ushort *)(&stack0x0000003c + lVar20) =
                           *(ushort *)(&stack0x0000003c + lVar20) ^
                           (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
                      break;
                    }
                    if (uVar13 < 0x400) break;
                    puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar49 = *puVar49 | 1;
                    uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                  } while (uVar13 != 0);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107cfb;
                iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if (iVar16 == 0) {
                  *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                }
                else {
                  iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *(int *)(&stack0x00000036 + lVar20) = iVar16;
                  *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107d18;
                  uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107d27;
                  func_0x(uVar23,&stack0x00000250 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107d33;
                  iVar16 = func_0x(&stack0x00000250 + lVar20);
                  piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *piVar45 = *piVar45 + iVar16;
                }
                if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                   (*(ulonglong *)(&stack0x0000002e + lVar20) <
                    (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                    *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107de5;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107dee;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107dfe;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107e1a;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107e40;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107e4e;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
                }
                if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107e66;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107e6f;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107e7f;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107e9b;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107ec1;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107ecf;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                }
              }
LAB_:
              if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 9) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107ede;
                cVar10 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((cVar10 == '\0') || (cVar10 == '\f')) {
                  uVar39 = 9;
                  goto LAB_;
                }
              }
              uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107efb;
              uVar39 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            }
LAB_:
            if (0x3f3c < uVar39) {
              uVar23 = 0xb8;
              puVar28 = &stack0xffffffffffffffc0 + lVar20;
              goto LAB_;
            }
          }
          else {
LAB_:
            *(undefined8 *)(&stack0x00000088 + lVar20) = 0;
            uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107f21;
            lVar27 = func_0x(uVar23);
            *(undefined2 *)(&stack0x000000e8 + lVar20) = 0xffff;
            *(undefined8 *)(&stack0x000000f0 + lVar20) = 0;
            *(undefined4 *)(&stack0x000000ec + lVar20) = 0;
            *(undefined8 *)(&stack0x00000106 + lVar20) = 0;
            *(undefined8 *)(&stack0x00000110 + lVar20) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107f5a;
            func_0x(&stack0x000000ea + lVar20,0);
            *(undefined8 *)(&stack0x000000d0 + lVar20) = 0;
            *(undefined4 *)(&stack0x0000007c + lVar20) = 0;
            psVar55 = psVar21;
            if (*psVar21 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107f78;
              lVar24 = func_0x(psVar21 + 1);
              if (lVar24 != 0) {
                puVar31 = puVar30;
                if (*psVar21 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107f95;
                  puVar31 = (undefined8 *)func_0x(psVar21 + 1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107f9d;
                iVar16 = func_0x(puVar31);
                if (iVar16 != 0) {
                  sVar15 = *psVar21;
                  *(short *)(&stack0x000000e8 + lVar20) = sVar15;
                  if (sVar15 == 0) {
                    if (*(int *)(psVar21 + 2) == 0) {
                      psVar21[1] = 0;
                      *(undefined4 *)(psVar21 + 10) = *(undefined4 *)(psVar21 + 8);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107fd6;
                      pbVar29 = (byte *)func_0x(psVar21 + 1);
                      if ((*pbVar29 & 0x10) != 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x107fe4;
                        pbVar29 = (byte *)func_0x(psVar21 + 1);
                        if ((*pbVar29 & 0x10) != 0) {
                          uVar44 = (uint)*(ushort *)
                                          ((ulonglong)*(uint *)(psVar21 + 8) +
                                          *(longlong *)(psVar21 + 4));
                        }
                        *(uint *)(psVar21 + 10) = *(int *)(psVar21 + 10) + (uVar44 + 7 >> 3) + 2;
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10800e;
                      pbVar29 = (byte *)func_0x(psVar21 + 1);
                      if ((*pbVar29 & 0x20) == 0) {
                        *(undefined4 *)(psVar21 + 2) = *(undefined4 *)(psVar21 + 10);
                        psVar21[0xe] = 0;
                        *(undefined4 *)(psVar21 + 0xc) = *(undefined4 *)(psVar21 + 10);
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108020;
                        puVar52 = (ushort *)func_0x(psVar21 + 1);
                        uVar13 = *puVar52;
                        psVar21[0xe] = uVar13;
                        if (uVar13 == 0) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10803b;
                          cVar10 = func_0x(0x1e80c50);
                          if (cVar10 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108044;
                            cVar10 = func_0x();
                            if (cVar10 != '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108054;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108070;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108094;
                                (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                              }
                            }
                          }
                          uVar23 = *(undefined8 *)(psVar21 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1080a2;
                          func_0x(uVar23,3);
                          uVar13 = psVar21[0xe];
                        }
                        uVar39 = *(int *)(psVar21 + 10) + 2 + (uint)uVar13 * 2;
                        *(uint *)(psVar21 + 0xc) = uVar39;
                        if (0x1f9e < uVar39) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1080c9;
                          cVar10 = func_0x(0x1e80c50);
                          if (cVar10 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1080d2;
                            cVar10 = func_0x();
                            if (cVar10 != '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1080e2;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1080fe;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108122;
                                (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                              }
                            }
                          }
                          uVar23 = *(undefined8 *)(psVar21 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108130;
                          func_0x(uVar23,4);
                          uVar13 = psVar21[0xe];
                        }
                        puVar52 = puVar52 + 1;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108146;
                        uVar13 = func_0x(puVar52,(ulonglong)uVar13 - 1);
                        *(uint *)(psVar21 + 2) = (uint)uVar13;
                        if ((uint)uVar13 <= *(uint *)(psVar21 + 0xc) &&
                            *(uint *)(psVar21 + 0xc) != (uint)uVar13) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10815d;
                          cVar10 = func_0x(0x1e80c50);
                          if (cVar10 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108166;
                            cVar10 = func_0x();
                            if (cVar10 != '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108176;
                              cVar10 = func_0x(0x1e80c50);
                              if (cVar10 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108192;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1081ba;
                                (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                              }
                            }
                          }
                          uVar23 = *(undefined8 *)(psVar21 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1081c8;
                          func_0x(uVar23,4);
                        }
                        uVar13 = psVar21[0xe];
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1081d6;
                        iVar16 = func_0x(puVar52,uVar13 - 1);
                        while (iVar16 != 0) {
                          uVar13 = psVar21[0xe];
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1081ed;
                          lVar24 = func_0x(psVar21 + 1);
                          if (uVar13 == 1) {
                            uVar39 = *(uint *)(psVar21 + 0xc);
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10820a;
                            uVar38 = func_0x(lVar24 + 2,(ulonglong)uVar13 - 2);
                            uVar39 = (uint)uVar38;
                          }
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10821a;
                          uVar13 = func_0x(lVar24 + 2,(ulonglong)(uint)uVar13 - 1);
                          if ((uVar39 < *(uint *)(psVar21 + 0xc)) || (uVar13 < uVar39)) {
                            uVar23 = *(undefined8 *)(psVar21 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108234;
                            func_0x(uVar23,7);
                            if (uVar39 < *(uint *)(psVar21 + 0xc)) goto LAB_;
                          }
                          if (*(uint *)(psVar21 + 2) < uVar39) goto LAB_;
                          if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(psVar21 + 4)) == 5) {
                            psVar21[1] = psVar21[1] | 2;
                            psVar21[0xe] = psVar21[0xe] + -1;
                            psVar21[0x15] = (short)uVar39;
                            lVar24 = (ulonglong)(uVar39 & 0xffff) + *(longlong *)(psVar21 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1082ff;
                            iVar16 = func_0x(lVar24);
                            if (iVar16 == 0) {
                              psVar21[0x16] = psVar21[0x16] & 0xc7ff;
                            }
                            else {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10830b;
                              uVar13 = func_0x(lVar24);
                              psVar21[0x16] = psVar21[0x16] & 0xc7ff;
                              psVar21[0x16] = psVar21[0x16] | (uVar13 & 7) << 0xb;
                            }
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108333;
                            uVar13 = func_0x(lVar24);
                            psVar21[0x16] = psVar21[0x16] & 0xf800;
                            psVar21[0x16] = psVar21[0x16] | uVar13 & 0x7ff;
                            break;
                          }
                          if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(psVar21 + 4)) < 0x400)
                          break;
                          psVar21[1] = psVar21[1] | 1;
                          uVar13 = psVar21[0xe] - 1;
                          psVar21[0xe] = uVar13;
                          if (uVar13 == 0) break;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108284;
                          iVar16 = func_0x(puVar52,uVar13 - 1);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10829e;
                      iVar16 = func_0x(psVar21 + 1);
                      if (iVar16 == 0) {
                        *(undefined4 *)(psVar21 + 0x13) = 0;
                      }
                      else {
                        *(int *)(psVar21 + 0x13) = *(int *)(psVar21 + 2);
                        *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + 0xe;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1082bb;
                        uVar23 = func_0x(psVar21 + 1);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1082ca;
                        func_0x(uVar23,&stack0x00000258 + lVar20);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1082d6;
                        iVar16 = func_0x(&stack0x00000258 + lVar20);
                        *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + iVar16;
                      }
                      uVar39 = *(uint *)(psVar21 + 2);
                      if ((*(ulonglong *)(psVar21 + 0xf) != 0) &&
                         (*(ulonglong *)(psVar21 + 0xf) <
                          (ulonglong)uVar39 + *(longlong *)(psVar21 + 4))) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108387;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108390;
                          cVar10 = func_0x();
                          if (cVar10 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1083a0;
                            cVar10 = func_0x(0x1e80c50);
                            if (cVar10 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1083bc;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1083e0;
                              (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                            }
                          }
                        }
                        uVar23 = *(undefined8 *)(psVar21 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1083ee;
                        func_0x(uVar23,0x12);
                        uVar39 = *(uint *)(psVar21 + 2);
                      }
                      if (0x3f3b < uVar39 - 1) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108407;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108410;
                          cVar10 = func_0x();
                          if (cVar10 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108420;
                            cVar10 = func_0x(0x1e80c50);
                            if (cVar10 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10843c;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108460;
                              (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                            }
                          }
                        }
                        uVar23 = *(undefined8 *)(psVar21 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10846e;
                        func_0x(uVar23,5);
                      }
                    }
LAB_:
                    uVar39 = *(uint *)(psVar21 + 2);
                    if (uVar39 < 9) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10847f;
                      cVar10 = func_0x(psVar21 + 1);
                      if ((cVar10 == '\0') || (cVar10 == '\f')) {
                        uVar39 = 9;
                      }
                      else {
                        uVar39 = *(uint *)(psVar21 + 2);
                      }
                    }
                    *(undefined4 *)(&stack0x000000f8 + lVar20) = *(undefined4 *)(psVar21 + 8);
                    *(short *)(&stack0x000000ea + lVar20) = psVar21[1];
                    *(undefined4 *)(&stack0x000000ec + lVar20) = *(undefined4 *)(psVar21 + 2);
                    *(short *)(&stack0x00000104 + lVar20) = psVar21[0xe];
                    *(undefined4 *)(&stack0x000000fc + lVar20) = *(undefined4 *)(psVar21 + 10);
                    *(undefined4 *)(&stack0x00000100 + lVar20) = *(undefined4 *)(psVar21 + 0xc);
                    *(undefined4 *)(&stack0x0000010e + lVar20) = *(undefined4 *)(psVar21 + 0x13);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1084df;
                    uVar23 = func_0x(psVar21 + 1);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1084f6;
                    func_0x(&stack0x00000900 + lVar20,0x1f9e,uVar23,uVar39);
                    *(undefined **)(&stack0x000000f0 + lVar20) = &stack0x00000900 + lVar20;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108510;
                    iVar16 = func_0x(&stack0x000000ea + lVar20);
                    if (iVar16 != 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10852b;
                      uVar13 = func_0x
                                         (&stack0x000000ea + lVar20,&stack0x00000198 + lVar20);
                      *(ushort *)(&stack0x00000112 + lVar20) = uVar13;
                      lVar24 = (ulonglong)uVar13 + *(longlong *)(&stack0x000000f0 + lVar20);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108544;
                      iVar16 = func_0x(lVar24);
                      if (iVar16 == 0) {
                        *(ushort *)(&stack0x00000114 + lVar20) =
                             *(ushort *)(&stack0x00000114 + lVar20) & 0xc7ff;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108550;
                        sVar15 = func_0x(lVar24);
                        *(ushort *)(&stack0x00000114 + lVar20) =
                             *(ushort *)(&stack0x00000114 + lVar20) ^
                             (sVar15 << 0xb ^ *(ushort *)(&stack0x00000114 + lVar20)) & 0x3800;
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108586;
                      uVar13 = func_0x(lVar24);
                      *(ushort *)(&stack0x00000114 + lVar20) =
                           *(ushort *)(&stack0x00000114 + lVar20) ^
                           (uVar13 ^ *(ushort *)(&stack0x00000114 + lVar20)) & 0x7ff;
                    }
                    uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
                    psVar55 = (short *)(&stack0x000000e8 + lVar20);
                  }
                  else {
                    if (*psVar21 != 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1085c7;
                      lVar24 = func_0x(psVar21 + 1);
                      if (lVar24 != 0) {
                        if (*psVar21 != 0) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1085e0;
                          puVar30 = (undefined8 *)func_0x(psVar21 + 1);
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1085e8;
                        iVar16 = func_0x(puVar30);
                        if (iVar16 != 0) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108608;
                          func_0x(&stack0x000000e8 + lVar20,&stack0x00000900 + lVar20,0x1f9e
                                          ,psVar21);
                          psVar55 = (short *)(&stack0x000000e8 + lVar20);
                          goto LAB_;
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10862e;
                    func_0x(&stack0x000000ea + lVar20,&stack0x00000900 + lVar20,0x1f9e,
                                    psVar21 + 1);
                    if (*psVar21 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108646;
                      func_0x(&stack0x000000ea + lVar20,0);
                      psVar55 = (short *)(&stack0x000000e8 + lVar20);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108658;
                      uVar34 = func_0x(psVar21 + 1);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108667;
                      func_0x(&stack0x000000ea + lVar20,uVar34);
                      psVar55 = (short *)(&stack0x000000e8 + lVar20);
                    }
                  }
                }
              }
            }
LAB_:
            uVar44 = 1;
            lVar27 = lVar27 + 0x10;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10867f;
            iVar16 = func_0x(lVar27);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10868b;
            uVar39 = func_0x(psVar55);
            if ((uint)-iVar16 < uVar39) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10869a;
              uVar39 = func_0x(psVar55);
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1086a7;
              iVar16 = func_0x(lVar27);
              uVar39 = -iVar16;
            }
            uVar56 = (ulonglong)uVar39;
            *(uint *)(&stack0x00000048 + lVar20) = uVar39;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1086b9;
            iVar16 = func_0x(psVar21);
            if (iVar16 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1086d0;
              cVar10 = func_0x
                                 (uVar23,&stack0x000000d0 + lVar20,&stack0x0000007c + lVar20);
              if (cVar10 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1086e6;
                uVar18 = func_0x(*(undefined8 *)(&stack0x000000d0 + lVar20),
                                         *(undefined4 *)(&stack0x0000007c + lVar20),psVar21);
                if (uVar39 <= uVar18) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108700;
                  uVar39 = func_0x(*(undefined8 *)(&stack0x000000d0 + lVar20),
                                           *(undefined4 *)(&stack0x0000007c + lVar20),psVar21);
                  uVar56 = (ulonglong)uVar39;
                  *(uint *)(&stack0x00000048 + lVar20) = uVar39;
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10870e;
            uVar39 = func_0x(lVar27);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108719;
            uVar19 = func_0x(lVar27);
            sVar15 = *psVar55;
            *psVar2 = sVar15;
            puVar52 = (ushort *)(psVar55 + 1);
            if (sVar15 == 0) {
              *(undefined **)((longlong)&pbStackX_18 + lVar20) = &stack0x000028a0 + lVar20;
              *(undefined4 *)((longlong)&uStackX_20 + lVar20) = uVar19;
              uVar18 = 0;
              *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
              *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108753;
              cVar10 = func_0x(puVar52);
              lVar27 = (longlong)&sStackX_10 + lVar20 + 2;
              if (cVar10 == '\x06') {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108760;
                puVar32 = (undefined *)func_0x(lVar27);
                *puVar32 = 6;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10876d;
                puVar32 = (undefined *)func_0x(lVar27);
                *puVar32 = 0;
                *(undefined *)(*(longlong *)((longlong)&pbStackX_18 + lVar20) + 1) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108782;
                func_0x
                          ((longlong)&sStackX_10 + lVar20 + 2,
                           *(undefined4 *)((longlong)&uStackX_20 + lVar20));
                uVar44 = 4;
              }
              uVar40 = *(uint *)(psVar55 + 8);
              if (*(uint *)((longlong)&uStackX_20 + lVar20) <= uVar40) {
                uVar40 = *(uint *)((longlong)&uStackX_20 + lVar20);
              }
              lVar27 = *(longlong *)(psVar55 + 4);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1087ac;
              func_0x
                        (*(longlong *)((longlong)&pbStackX_18 + lVar20) + (ulonglong)uVar44,
                         lVar27 + (ulonglong)uVar44,uVar40 - uVar44);
              if (uVar39 == 0) {
                *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                     *(undefined4 *)((longlong)&uStackX_20 + lVar20);
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1087be;
                pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                *pbVar29 = *pbVar29 | 0x10;
                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                     (uVar39 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20) + 2;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1087db;
                pbVar29 = (byte *)func_0x(puVar52);
                if ((*pbVar29 & 0x10) == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10887f;
                  func_0x(&stack0x000001b0 + lVar20);
                  *(short *)((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                            *(longlong *)((longlong)&pbStackX_18 + lVar20)) = (short)uVar39;
                }
                else {
                  lVar27 = *(longlong *)(psVar55 + 4);
                  uVar13 = *(ushort *)((ulonglong)*(uint *)(psVar55 + 8) + lVar27);
                  uVar18 = (uint)uVar13;
                  if (uVar13 == uVar39) {
                    iVar16 = *(int *)((longlong)&uStackX_20 + lVar20 + 4);
                    uVar39 = *(uint *)(psVar55 + 8);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10880d;
                    func_0x
                              ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                               *(longlong *)((longlong)&pbStackX_18 + lVar20),
                               (ulonglong)uVar39 + lVar27,
                               iVar16 - *(uint *)((longlong)&uStackX_20 + lVar20));
                    uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                    *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                    *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                    goto LAB_;
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108827;
                  func_0x(&stack0x000001b0 + lVar20);
                  *(short *)((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                            *(longlong *)((longlong)&pbStackX_18 + lVar20)) = (short)uVar39;
                  if (uVar13 != 0) {
                    uVar44 = *(uint *)(psVar55 + 8);
                    uVar42 = *(int *)(psVar55 + 10) - uVar44;
                    uVar40 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) -
                             *(uint *)((longlong)&uStackX_20 + lVar20);
                    if (uVar42 <= uVar40) {
                      uVar40 = uVar42;
                    }
                    lVar27 = *(longlong *)(psVar55 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108871;
                    func_0x
                              (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                               (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) + 2,
                               (ulonglong)uVar44 + lVar27 + 2,uVar40 - 2);
                  }
                }
                if (uVar39 < uVar18) {
                  uVar18 = uVar39 & 0xffff;
                }
                uVar13 = (short)uVar18 + 1;
                if (uVar13 <= uVar39) {
                  do {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1088bf;
                    func_0x(&stack0x000001b0 + lVar20,uVar13);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1088cf;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,&stack0x000001b0 + lVar20);
                    uVar13 = uVar13 + 1;
                  } while (uVar13 <= uVar39);
                  uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                  *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                  *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                  goto LAB_;
                }
              }
              uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
              *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
              *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
            }
            else {
              *(uint *)(&stack0xffffffffffffffe0 + lVar20) = uVar39;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108914;
              func_0x((longlong)&sStackX_10 + lVar20 + 2,&stack0x000028a0 + lVar20,0x3f3c,
                              puVar52);
            }
LAB_:
            if ((uint)uVar56 == 0) {
              lVar27 = *(longlong *)(&stack0x00000088 + lVar20);
              puVar28 = &stack0xffffffffffffffc0 + lVar20;
            }
            else {
              uVar41 = uVar56 * 0x20 + 0xf;
              if (uVar41 <= uVar56 * 0x20) {
                uVar41 = 0xffffffffffffff0;
              }
              uVar41 = uVar41 & 0xfffffffffffffff0;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108946;
              func_0x();
              lVar24 = -uVar41;
              lVar27 = (longlong)&sStackX_10 + lVar24 + lVar20;
              *(longlong *)(&stack0x00000088 + lVar20) = lVar27;
              if (*psVar55 == 0) {
                if (*(int *)(psVar55 + 2) == 0) {
                  *puVar52 = 0;
                  *(undefined4 *)(psVar55 + 10) = *(undefined4 *)(psVar55 + 8);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10897d;
                  pbVar29 = (byte *)func_0x(puVar52);
                  if ((*pbVar29 & 0x10) != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10898a;
                    pbVar29 = (byte *)func_0x(puVar52);
                    if ((*pbVar29 & 0x10) == 0) {
                      uVar39 = 0;
                    }
                    else {
                      uVar39 = (uint)*(ushort *)
                                      ((ulonglong)*(uint *)(psVar55 + 8) +
                                      *(longlong *)(psVar55 + 4));
                    }
                    *(uint *)(psVar55 + 10) = *(int *)(psVar55 + 10) + (uVar39 + 7 >> 3) + 2;
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1089b3;
                  pbVar29 = (byte *)func_0x(puVar52);
                  if ((*pbVar29 & 0x20) == 0) {
                    *(undefined4 *)(psVar55 + 2) = *(undefined4 *)(psVar55 + 10);
                    psVar55[0xe] = 0;
                    *(undefined4 *)(psVar55 + 0xc) = *(undefined4 *)(psVar55 + 10);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1089c4;
                    puVar49 = (ushort *)func_0x(puVar52);
                    uVar13 = *puVar49;
                    psVar55[0xe] = uVar13;
                    if (uVar13 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1089df;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1089e8;
                        cVar10 = func_0x();
                        if (cVar10 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x1089f8;
                          cVar10 = func_0x(0x1e80c50);
                          if (cVar10 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108a14;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108a3a;
                            (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)(psVar55 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108a48;
                      func_0x(uVar23,3);
                      uVar13 = psVar55[0xe];
                    }
                    uVar39 = *(int *)(psVar55 + 10) + (uVar13 + 1) * 2;
                    *(uint *)(psVar55 + 0xc) = uVar39;
                    if (0x1f9e < uVar39) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108a6f;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108a78;
                        cVar10 = func_0x();
                        if (cVar10 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108a88;
                          cVar10 = func_0x(0x1e80c50);
                          if (cVar10 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108aa4;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108aca;
                            (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)(psVar55 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108ad8;
                      func_0x(uVar23,4);
                      uVar13 = psVar55[0xe];
                    }
                    puVar49 = puVar49 + 1;
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108aee;
                    uVar13 = func_0x(puVar49,(ulonglong)uVar13 - 1);
                    *(uint *)(psVar55 + 2) = (uint)uVar13;
                    if ((uint)uVar13 <= *(uint *)(psVar55 + 0xc) &&
                        *(uint *)(psVar55 + 0xc) != (uint)uVar13) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108b05;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108b0e;
                        cVar10 = func_0x();
                        if (cVar10 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108b1e;
                          cVar10 = func_0x(0x1e80c50);
                          if (cVar10 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108b3a;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108b60;
                            (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)(psVar55 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108b6e;
                      func_0x(uVar23,4);
                    }
                    uVar13 = psVar55[0xe];
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108b7c;
                    iVar16 = func_0x(puVar49,uVar13 - 1);
                    while (iVar16 != 0) {
                      uVar13 = psVar55[0xe];
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108b90;
                      lVar27 = func_0x(puVar52);
                      if (uVar13 == 1) {
                        uVar41 = (ulonglong)*(uint *)(psVar55 + 0xc);
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108bad;
                        uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                        uVar41 = (ulonglong)uVar38;
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108bbd;
                      uVar13 = func_0x(lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                      uVar39 = (uint)uVar41;
                      if ((uVar39 < *(uint *)(psVar55 + 0xc)) || (uVar13 < uVar39)) {
                        uVar23 = *(undefined8 *)(psVar55 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108bd7;
                        func_0x(uVar23,7);
                        if (uVar39 < *(uint *)(psVar55 + 0xc)) goto LAB_;
                      }
                      if (*(uint *)(psVar55 + 2) < uVar39) goto LAB_;
                      if (*(ushort *)(uVar41 + *(longlong *)(psVar55 + 4)) == 5) {
                        *puVar52 = *puVar52 | 2;
                        psVar55[0xe] = psVar55[0xe] + -1;
                        psVar55[0x15] = (short)uVar41;
                        lVar27 = (uVar41 & 0xffff) + *(longlong *)(psVar55 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108ca1;
                        iVar16 = func_0x(lVar27);
                        if (iVar16 == 0) {
                          psVar55[0x16] = psVar55[0x16] & 0xc7ff;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108cad;
                          uVar13 = func_0x(lVar27);
                          psVar55[0x16] = psVar55[0x16] & 0xc7ff;
                          psVar55[0x16] = psVar55[0x16] | (uVar13 & 7) << 0xb;
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108cd5;
                        uVar13 = func_0x(lVar27);
                        psVar55[0x16] = psVar55[0x16] & 0xf800;
                        psVar55[0x16] = psVar55[0x16] | uVar13 & 0x7ff;
                        break;
                      }
                      if (*(ushort *)(uVar41 + *(longlong *)(psVar55 + 4)) < 0x400) break;
                      *puVar52 = *puVar52 | 1;
                      uVar13 = psVar55[0xe] - 1;
                      psVar55[0xe] = uVar13;
                      if (uVar13 == 0) break;
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108c26;
                      iVar16 = func_0x(puVar49,uVar13 - 1);
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108c3c;
                  iVar16 = func_0x(puVar52);
                  if (iVar16 == 0) {
                    *(undefined4 *)(psVar55 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar55 + 0x13) = *(int *)(psVar55 + 2);
                    *(int *)(psVar55 + 2) = *(int *)(psVar55 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108c5b;
                    uVar23 = func_0x(puVar52);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108c6a;
                    func_0x(uVar23,&stack0x00000260 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108c76;
                    iVar16 = func_0x(&stack0x00000260 + lVar20);
                    *(int *)(psVar55 + 2) = *(int *)(psVar55 + 2) + iVar16;
                  }
                  uVar39 = *(uint *)(psVar55 + 2);
                  if ((*(ulonglong *)(psVar55 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar55 + 0xf) < (ulonglong)uVar39 + *(longlong *)(psVar55 + 4)
                     )) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108d30;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108d39;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108d49;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108d65;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108d8b;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(psVar55 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108d99;
                    func_0x(uVar23,0x12);
                    uVar39 = *(uint *)(psVar55 + 2);
                  }
                  if (0x3f3b < uVar39 - 1) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108db5;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108dbe;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108dce;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108dea;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108e10;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(psVar55 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108e1e;
                    func_0x(uVar23,5);
                  }
                }
LAB_:
                uVar13 = psVar55[0xe];
                uVar41 = uVar56;
                if (((uint)uVar56 <= (uint)uVar13) || (uVar41 = (ulonglong)uVar13, uVar13 != 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108e41;
                  lVar25 = func_0x(puVar52);
                  *(undefined4 *)(&stack0x0000005c + lVar20) = *(undefined4 *)(psVar55 + 0xc);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108e56;
                  func_0x(&stack0x00000300 + lVar20);
                  uVar39 = 0;
                  lVar25 = lVar25 + 2;
                  lVar57 = 0;
                  lVar27 = *(longlong *)(&stack0x00000088 + lVar20);
                  do {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108e7b;
                    iVar16 = func_0x(lVar25,uVar39);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108e8d;
                    uVar13 = func_0x(lVar25,lVar57);
                    uVar44 = *(uint *)(&stack0x0000005c + lVar20);
                    lVar5 = *(longlong *)(psVar55 + 4);
                    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar24 + lVar20) = 0;
                    *(undefined **)(&stack0xffffffffffffffe0 + lVar24 + lVar20) =
                         &stack0x00000300 + lVar20;
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108ebc;
                    func_0x
                              (lVar27,(ulonglong)uVar44 + lVar5,uVar13 - uVar44,iVar16 != 0);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108ec7;
                    uVar13 = func_0x(lVar25,lVar57);
                    *(uint *)(&stack0x0000005c + lVar20) = (uint)uVar13;
                    uVar39 = uVar39 + 1;
                    lVar57 = lVar57 + 1;
                    lVar27 = lVar27 + 0x20;
                  } while (uVar39 < (uint)uVar41);
                  psVar21 = *(short **)(&stack0x00000070 + lVar20);
                  uVar56 = (ulonglong)*(uint *)(&stack0x00000048 + lVar20);
                }
                lVar27 = *(longlong *)(&stack0x00000088 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108f03;
                func_0x(uVar41 * 0x20 + lVar27,0,((int)uVar56 - (int)uVar41) * 0x20)
                ;
                puVar28 = &stack0xffffffffffffffc0 + lVar24 + lVar20;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x108f16;
                func_0x(puVar52,lVar27,uVar56);
                puVar28 = &stack0xffffffffffffffc0 + lVar24 + lVar20;
              }
            }
            lVar24 = *(longlong *)(&stack0x000000d0 + lVar20);
            if (lVar24 != 0) {
              *(int *)(puVar28 + 0x28) = (int)uVar56;
              *(longlong *)(puVar28 + 0x20) = lVar27;
              uVar19 = *(undefined4 *)(&stack0x0000007c + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x108f41;
              func_0x(lVar24,uVar19,psVar21,psVar2);
            }
            uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x108f4a;
            uVar23 = func_0x(uVar23);
            *(undefined8 *)(puVar28 + -8) = 0x108f52;
            uVar13 = func_0x(uVar23);
            *(undefined8 *)(&stack0x000000a0 + lVar20) = 0;
            uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x108f68;
            lVar24 = func_0x(uVar23);
            if (uVar13 != 0) {
              uVar56 = (ulonglong)uVar13;
              lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
              do {
                *(undefined8 *)(puVar28 + -8) = 0x108f88;
                uVar23 = func_0x(lVar24);
                *(undefined8 *)(puVar28 + -8) = 0x108f93;
                iVar16 = func_0x(lVar24);
                *(undefined8 *)(puVar28 + -8) = 0x108fa5;
                func_0x(lVar25,lVar24,&stack0x00000061 + lVar20);
                if ((&stack0x00000061)[lVar20] == '\x03') {
                  *(undefined8 *)(puVar28 + -8) = 0x10932f;
                  iVar50 = func_0x(lVar24);
                  if (iVar50 == 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x10933b;
                    iVar50 = func_0x(lVar24);
                    if (iVar50 == 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x109353;
                      (*_DAT_)(6,0x51,0x10,3);
                    }
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x109365;
                  func_0x(psVar2,uVar23,0,0);
                  if (iVar16 < 0) {
                    puVar46 = (uint *)((longlong)-iVar16 * 0x20 + -0x14 + lVar27);
                    *puVar46 = *puVar46 | 2;
                  }
                }
                else {
                  *(undefined8 *)(puVar28 + -8) = 0x108fb7;
                  sVar15 = func_0x(uVar23);
                  if (sVar15 != 0) {
                    if (*psVar2 == 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x108fcf;
                      func_0x();
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x108fd6;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
                    }
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x108fe8;
                  func_0x(lVar25,lVar24,&stack0x000000a0 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x108ff0;
                  iVar50 = func_0x(lVar24);
                  if ((iVar50 == 1) || (iVar50 == 2)) {
                    lVar27 = *(longlong *)(&stack0x000000a0 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x109193;
                    iVar16 = func_0x(lVar24);
                    if (iVar16 == 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x1091a3;
                      uVar14 = func_0x();
                      *(undefined8 *)(puVar28 + -8) = 0x1091ae;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)(puVar28 + -8) = 0x1091b6;
                      iVar16 = func_0x(uVar23);
                      lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x1091c8;
                      func_0x(iVar16 + lVar25,lVar27,uVar14);
                    }
                    else {
                      iVar50 = 0;
                      *(undefined8 *)(puVar28 + -8) = 0x10922e;
                      iVar16 = func_0x(lVar24);
                      if ((iVar16 == 0) || ((*(byte *)(lVar25 + 0x14) & 8) == 0)) {
                        *(undefined8 *)(puVar28 + -8) = 0x10925b;
                        iVar16 = func_0x(lVar24);
                        if (iVar16 == 0) {
                          *(undefined8 *)(puVar28 + -8) = 0x10928a;
                          uVar13 = func_0x(lVar24);
                          uVar39 = (uint)uVar13;
                        }
                        else {
                          *(undefined8 *)(puVar28 + -8) = 0x109267;
                          uVar34 = func_0x();
                          uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x109276;
                          uVar23 = func_0x(uVar23,lVar24);
                          *(undefined8 *)(puVar28 + -8) = 0x109281;
                          uVar39 = func_0x(uVar23,uVar34);
                        }
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x109240;
                        uVar39 = func_0x(lVar24);
                        uVar39 = *(uint *)((ulonglong)uVar39 * 8 + *(longlong *)(lVar25 + 0x38));
                      }
                      *(undefined8 *)(puVar28 + -8) = 0x109295;
                      uVar13 = func_0x(lVar24);
                      if (uVar39 < uVar13) {
                        *(undefined8 *)(puVar28 + -8) = 0x1092a4;
                        uVar13 = func_0x(lVar24);
                        iVar50 = uVar13 - uVar39;
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x1092b2;
                        uVar13 = func_0x(lVar24);
                        if (uVar13 < uVar39) {
                          *(undefined8 *)(puVar28 + -8) = 0x1092cf;
                          (*_DAT_)(6,0x5c,0x16);
                        }
                      }
                      *(undefined8 *)(puVar28 + -8) = 0x1092d7;
                      uVar12 = func_0x(lVar24);
                      *(undefined8 *)(puVar28 + -8) = 0x1092e3;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)(puVar28 + -8) = 0x1092eb;
                      iVar16 = func_0x(uVar23);
                      lVar25 = (longlong)iVar16 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      if ((lVar27 != 0) && (uVar39 != 0)) {
                        *(undefined8 *)(puVar28 + -8) = 0x109309;
                        func_0x(lVar25,lVar27,uVar39);
                      }
                      if (iVar50 != 0) {
                        *(undefined8 *)(puVar28 + -8) = 0x109322;
                        func_0x((ulonglong)uVar39 + lVar25,uVar12,iVar50);
                      }
                    }
                  }
                  else {
                    uVar39 = 0;
                    if ((iVar50 != 3) && (iVar50 != 4)) {
                      if (iVar50 == 8) {
                        *(undefined8 *)(puVar28 + -8) = 0x109054;
                        sVar15 = func_0x(psVar2);
                        if (sVar15 == 0) {
                          uVar34 = *(undefined8 *)(&stack0x000000a0 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x109072;
                          func_0x(psVar2,uVar23,uVar34);
                        }
                        else {
                          *(undefined4 *)(puVar28 + 0x28) = 0;
                          *(undefined8 *)(puVar28 + 0x20) = uVar23;
                          uVar23 = *(undefined8 *)(&stack0x000000a0 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x1090a6;
                          func_0x((longlong)(-1 - iVar16) * 0x20 + lVar27,uVar23,1);
                        }
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0x14edeb8;
                        *(undefined8 *)(puVar28 + -8) = 0x109046;
                        (*_DAT_)(1,0x18f2d10,0x191f650);
                      }
                      goto LAB_;
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x1090b3;
                    iVar50 = func_0x(lVar24);
                    if ((iVar50 == 0) || (**(int **)(&stack0x000000a0 + lVar20) != 0)) {
                      *(undefined8 *)(puVar28 + -8) = 0x1090d0;
                      iVar50 = func_0x(lVar24);
                      if ((iVar50 == 0) || ((*(byte *)(lVar25 + 0x14) & 8) == 0)) {
                        *(undefined8 *)(puVar28 + -8) = 0x1090fd;
                        iVar50 = func_0x(lVar24);
                        if (iVar50 == 0) {
                          *(undefined8 *)(puVar28 + -8) = 0x10912c;
                          uVar13 = func_0x(lVar24);
                          uVar39 = (uint)uVar13;
                        }
                        else {
                          *(undefined8 *)(puVar28 + -8) = 0x109109;
                          uVar35 = func_0x();
                          uVar34 = *(undefined8 *)(&stack0x00000050 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x109118;
                          uVar34 = func_0x(uVar34,lVar24);
                          *(undefined8 *)(puVar28 + -8) = 0x109123;
                          uVar39 = func_0x(uVar34,uVar35);
                        }
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x1090e2;
                        uVar39 = func_0x(lVar24);
                        uVar39 = *(uint *)((ulonglong)uVar39 * 8 + *(longlong *)(lVar25 + 0x38));
                      }
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x109137;
                    uVar13 = func_0x(lVar24);
                    if (uVar13 < uVar39) {
                      *(undefined8 *)(puVar28 + -8) = 0x109154;
                      (*_DAT_)(6,0x52,0x16);
                    }
                    *(undefined4 *)(puVar28 + 0x28) = 0;
                    *(undefined8 *)(puVar28 + 0x20) = uVar23;
                    uVar23 = *(undefined8 *)(&stack0x000000a0 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x109182;
                    func_0x((longlong)(-1 - iVar16) * 0x20 + lVar27,uVar23,uVar39);
                  }
                  lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
                }
LAB_:
                lVar24 = lVar24 + 0x50;
                uVar56 = uVar56 - 1;
                lVar27 = *(longlong *)(&stack0x00000088 + lVar20);
              } while (uVar56 != 0);
              uVar56 = (ulonglong)*(uint *)(&stack0x00000048 + lVar20);
            }
            puVar22 = (undefined2 *)0x0;
            if ((int)uVar56 != 0) {
              lVar27 = *(longlong *)(&stack0x00000088 + lVar20);
              if (*psVar2 == 0) {
LAB_:
                uVar39 = (uint)uVar56;
                uVar44 = uVar39 - 1;
                if (*(int *)((ulonglong)uVar44 * 0x20 + 8 + lVar27) == 0) goto code_r0x00109218;
                *(short *)(&stack0x0000002c + lVar20) = (short)uVar56;
                iVar16 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + uVar39 * 2;
                *(int *)(&stack0x00000028 + lVar20) = iVar16;
                *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16;
                *(undefined8 *)(puVar28 + -8) = 0x1093a1;
                pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                *pbVar29 = *pbVar29 | 0x20;
                if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 0x3f3d) {
                  *(undefined8 *)(puVar28 + -8) = 0x1093b6;
                  puVar22 = (undefined2 *)
                            func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar22 = (short)uVar56;
                }
                uVar44 = 0;
                if (uVar39 != 0) {
                  puVar46 = (uint *)(lVar27 + 0xc);
                  do {
                    uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                    lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    uVar40 = puVar46[-1];
                    uVar42 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + uVar40;
                    *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar42;
                    if (uVar42 < 0x3f3d) {
                      uVar43 = *puVar46;
                      *(undefined8 *)(puVar28 + -8) = 0x109402;
                      func_0x(puVar22 + 1,uVar44,uVar42,uVar43 & 1);
                      uVar23 = *(undefined8 *)(puVar46 + -3);
                      *(undefined8 *)(puVar28 + -8) = 0x109414;
                      func_0x((ulonglong)uVar18 + lVar27,uVar40,uVar23,uVar40);
                    }
                    uVar44 = uVar44 + 1;
                    puVar46 = puVar46 + 8;
                  } while (uVar44 < uVar39);
                }
                uVar39 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                *(uint *)(&stack0x00000130 + lVar20) = uVar39;
                uVar39 = (uint)(uVar39 < 0x3f3d);
                goto LAB_;
              }
              *(undefined **)(puVar28 + 0x28) = &stack0x00000130 + lVar20;
              *(longlong *)(puVar28 + 0x20) = lVar27;
              *(undefined8 *)(puVar28 + -8) = 0x10945b;
              uVar39 = func_0x((longlong)&sStackX_10 + lVar20 + 2,0x3f3c,0x3f3c,uVar56);
LAB_:
              if (uVar39 == 0) {
                uVar23 = 0xb9;
LAB_:
                *(undefined8 *)(puVar28 + -8) = 0x109478;
                (*_DAT_)(6,0x52,0x16,uVar23);
              }
            }
          }
          if (*psVar2 == 0) {
            if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
              *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                   *(undefined4 *)((longlong)&uStackX_20 + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x1094a2;
              pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((*pbVar29 & 0x10) != 0) {
                *(undefined8 *)(puVar28 + -8) = 0x1094b0;
                pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((*pbVar29 & 0x10) == 0) {
                  uVar39 = 0;
                }
                else {
                  uVar39 = (uint)*(ushort *)
                                  ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                                  *(longlong *)((longlong)&pbStackX_18 + lVar20));
                }
                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                     (uVar39 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
              }
              *(undefined8 *)(puVar28 + -8) = 0x1094de;
              pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((*pbVar29 & 0x20) == 0) {
                uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
              }
              else {
                *(undefined8 *)(puVar28 + -8) = 0x1094f0;
                puVar52 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                uVar13 = *puVar52;
                *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                if (uVar13 == 0) {
                  *(undefined8 *)(puVar28 + -8) = 0x10950e;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x109517;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x109527;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x109543;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x109569;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x109577;
                  func_0x(uVar23,3);
                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                }
                uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar13 * 2;
                *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                if (0x1f9e < uVar39) {
                  *(undefined8 *)(puVar28 + -8) = 0x1095a0;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x1095a9;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x1095b9;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x1095d5;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x1095fb;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x109609;
                  func_0x(uVar23,4);
                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                }
                *(undefined8 *)(puVar28 + -8) = 0x109621;
                uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
                if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                    *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                  *(undefined8 *)(puVar28 + -8) = 0x109638;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x109641;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x109651;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10966d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x109693;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x1096a1;
                  func_0x(uVar23,4);
                }
                uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                do {
                  *(undefined8 *)(puVar28 + -8) = 0x1096bd;
                  iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                  if (iVar16 == 0) break;
                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x1096d2;
                  lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if (uVar13 == 1) {
                    uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                  }
                  else {
                    *(undefined8 *)(puVar28 + -8) = 0x1096ee;
                    uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                    uVar39 = (uint)uVar38;
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x1096fe;
                  uVar13 = func_0x(lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                  uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                  if ((uVar39 < uVar44) || (uVar13 < uVar39)) {
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10971a;
                    func_0x(uVar23,7);
                    uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                  }
                  if ((uVar39 < uVar44) || (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar39))
                  goto LAB_;
                  lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar39);
                  if (uVar13 == 5) {
                    puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar52 = *puVar52 | 2;
                    *(short *)(&stack0x0000002c + lVar20) =
                         *(short *)(&stack0x0000002c + lVar20) + -1;
                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar39;
                    lVar27 = (ulonglong)(uVar39 & 0xffff) + lVar27;
                    *(undefined8 *)(puVar28 + -8) = 0x1097c6;
                    iVar16 = func_0x(lVar27);
                    if (iVar16 == 0) {
                      *(ushort *)(&stack0x0000003c + lVar20) =
                           *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x1097d2;
                      sVar15 = func_0x(lVar27);
                      *(ushort *)(&stack0x0000003c + lVar20) =
                           *(ushort *)(&stack0x0000003c + lVar20) ^
                           (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x1097ff;
                    uVar13 = func_0x(lVar27);
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         *(ushort *)(&stack0x0000003c + lVar20) ^
                         (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
                    break;
                  }
                  if (uVar13 < 0x400) break;
                  puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar49 = *puVar49 | 1;
                  uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                } while (uVar13 != 0);
              }
              *(undefined8 *)(puVar28 + -8) = 0x10976a;
              iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if (iVar16 == 0) {
                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
              }
              else {
                iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                *(int *)(&stack0x00000036 + lVar20) = iVar16;
                *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
                *(undefined8 *)(puVar28 + -8) = 0x109787;
                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                *(undefined8 *)(puVar28 + -8) = 0x109796;
                func_0x(uVar23,&stack0x00000268 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x1097a2;
                iVar16 = func_0x(&stack0x00000268 + lVar20);
                piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                *piVar45 = *piVar45 + iVar16;
              }
              if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                 (*(ulonglong *)(&stack0x0000002e + lVar20) <
                  (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                  *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                *(undefined8 *)(puVar28 + -8) = 0x109854;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x10985d;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10986d;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x109889;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar28 + 0x20) = 0;
                      *(undefined8 *)(puVar28 + -8) = 0x1098af;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x1098bd;
                func_0x(uVar23,0x12);
              }
              if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                *(undefined8 *)(puVar28 + -8) = 0x1098d5;
                cVar10 = func_0x(0x1e80c50);
                if (cVar10 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x1098de;
                  cVar10 = func_0x();
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x1098ee;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 == '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10990a;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar28 + 0x20) = 0;
                      *(undefined8 *)(puVar28 + -8) = 0x109930;
                      (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10993e;
                func_0x(uVar23,5);
              }
            }
LAB_:
            if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 9) {
              *(undefined8 *)(puVar28 + -8) = 0x10994d;
              cVar10 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((cVar10 == '\0') || (cVar10 == '\f')) {
                uVar44 = 9;
                *(undefined8 *)(puVar28 + -8) = 0x109963;
                iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                uVar39 = *(uint *)(&stack0x00000036 + lVar20);
                goto LAB_;
              }
            }
            uVar44 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
            *(undefined8 *)(puVar28 + -8) = 0x109974;
            iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            uVar39 = *(uint *)(&stack0x00000036 + lVar20);
          }
          else {
            *(undefined8 *)(puVar28 + -8) = 0x109982;
            func_0x((longlong)&sStackX_10 + lVar20 + 2);
            *(undefined8 *)(puVar28 + -8) = 0x10998b;
            uVar44 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            *(undefined8 *)(puVar28 + -8) = 0x109996;
            iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            uVar39 = *(uint *)(&stack0x00000040 + lVar20);
          }
LAB_:
          if (iVar16 == 0) {
            uVar39 = uVar44;
          }
          puVar47 = puVar28;
          if (0x1f7c < uVar39) {
            uVar23 = *(undefined8 *)(&stack0x00000080 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x1099b7;
            func_0x(uVar23,psVar2);
            if (*psVar2 == 0) {
              if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                     *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x1099e1;
                pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((*pbVar29 & 0x10) != 0) {
                  *(undefined8 *)(puVar28 + -8) = 0x1099ef;
                  pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if ((*pbVar29 & 0x10) == 0) {
                    uVar39 = 0;
                  }
                  else {
                    uVar39 = (uint)*(ushort *)
                                    ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                                    *(longlong *)((longlong)&pbStackX_18 + lVar20));
                  }
                  *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                       (uVar39 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                }
                *(undefined8 *)(puVar28 + -8) = 0x109a1d;
                pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((*pbVar29 & 0x20) == 0) {
                  uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                  *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                  *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                  *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                }
                else {
                  *(undefined8 *)(puVar28 + -8) = 0x109a2f;
                  puVar52 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  uVar13 = *puVar52;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                  if (uVar13 == 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x109a4d;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x109a56;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x109a66;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x109a82;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x109aa8;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x109ab6;
                    func_0x(uVar23,3);
                    uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                  }
                  uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar13 * 2;
                  *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                  if (0x1f9e < uVar39) {
                    *(undefined8 *)(puVar28 + -8) = 0x109adf;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x109ae8;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x109af8;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x109b14;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x109b3a;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x109b48;
                    func_0x(uVar23,4);
                    uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x109b60;
                  uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
                  *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
                  if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                      *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                    *(undefined8 *)(puVar28 + -8) = 0x109b77;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x109b80;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x109b90;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x109bac;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x109bd2;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x109be0;
                    func_0x(uVar23,4);
                  }
                  uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                  do {
                    *(undefined8 *)(puVar28 + -8) = 0x109bfd;
                    iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                    if (iVar16 == 0) break;
                    uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x109c12;
                    lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (uVar13 == 1) {
                      uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x109c2e;
                      uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                      uVar39 = (uint)uVar38;
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x109c3e;
                    uVar13 = func_0x(lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                    uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                    if ((uVar39 < uVar44) || (uVar13 < uVar39)) {
                      uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x109c5a;
                      func_0x(uVar23,7);
                      uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                    }
                    if ((uVar39 < uVar44) ||
                       (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar39)) goto LAB_;
                    lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar39);
                    if (uVar13 == 5) {
                      puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar52 = *puVar52 | 2;
                      *(short *)(&stack0x0000002c + lVar20) =
                           *(short *)(&stack0x0000002c + lVar20) + -1;
                      *(short *)(&stack0x0000003a + lVar20) = (short)uVar39;
                      lVar27 = (ulonglong)(uVar39 & 0xffff) + lVar27;
                      *(undefined8 *)(puVar28 + -8) = 0x109d06;
                      iVar16 = func_0x(lVar27);
                      if (iVar16 == 0) {
                        *(ushort *)(&stack0x0000003c + lVar20) =
                             *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x109d12;
                        sVar15 = func_0x(lVar27);
                        *(ushort *)(&stack0x0000003c + lVar20) =
                             *(ushort *)(&stack0x0000003c + lVar20) ^
                             (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                      }
                      *(undefined8 *)(puVar28 + -8) = 0x109d3f;
                      uVar13 = func_0x(lVar27);
                      *(ushort *)(&stack0x0000003c + lVar20) =
                           *(ushort *)(&stack0x0000003c + lVar20) ^
                           (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
                      break;
                    }
                    if (uVar13 < 0x400) break;
                    puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar49 = *puVar49 | 1;
                    uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                  } while (uVar13 != 0);
                }
                *(undefined8 *)(puVar28 + -8) = 0x109caa;
                iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if (iVar16 == 0) {
                  *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                }
                else {
                  iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *(int *)(&stack0x00000036 + lVar20) = iVar16;
                  *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
                  *(undefined8 *)(puVar28 + -8) = 0x109cc7;
                  uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  *(undefined8 *)(puVar28 + -8) = 0x109cd6;
                  func_0x(uVar23,&stack0x00000270 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x109ce2;
                  iVar16 = func_0x(&stack0x00000270 + lVar20);
                  piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *piVar45 = *piVar45 + iVar16;
                }
                if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                   (*(ulonglong *)(&stack0x0000002e + lVar20) <
                    (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                    *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                  *(undefined8 *)(puVar28 + -8) = 0x109d94;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x109d9d;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x109dad;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x109dc9;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x109def;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x109dfd;
                  func_0x(uVar23,0x12);
                }
                if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                  *(undefined8 *)(puVar28 + -8) = 0x109e15;
                  cVar10 = func_0x(0x1e80c50);
                  if (cVar10 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x109e1e;
                    cVar10 = func_0x();
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x109e2e;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x109e4a;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x109e70;
                        (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x109e7e;
                  func_0x(uVar23,5);
                }
              }
LAB_:
              if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 9) {
                *(undefined8 *)(puVar28 + -8) = 0x109e8d;
                cVar10 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((cVar10 == '\0') || (cVar10 == '\f')) {
                  uVar44 = 9;
                  *(undefined8 *)(puVar28 + -8) = 0x109ea3;
                  iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  uVar39 = *(uint *)(&stack0x00000036 + lVar20);
                  goto LAB_;
                }
              }
              uVar44 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              *(undefined8 *)(puVar28 + -8) = 0x109eb4;
              iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              uVar39 = *(uint *)(&stack0x00000036 + lVar20);
            }
            else {
              *(undefined8 *)(puVar28 + -8) = 0x109ec2;
              func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *(undefined8 *)(puVar28 + -8) = 0x109ecb;
              uVar44 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *(undefined8 *)(puVar28 + -8) = 0x109ed6;
              iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              uVar39 = *(uint *)(&stack0x00000040 + lVar20);
            }
LAB_:
            if (iVar16 == 0) {
              uVar39 = uVar44;
            }
            if (0x1f7c < uVar39) {
              if (*psVar2 == 0) {
                if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                  *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                  *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                       *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x109f14;
                  pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if ((*pbVar29 & 0x10) != 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x109f22;
                    pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if ((*pbVar29 & 0x10) == 0) {
                      uVar39 = 0;
                    }
                    else {
                      uVar39 = (uint)*(ushort *)
                                      ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                                      *(longlong *)((longlong)&pbStackX_18 + lVar20));
                    }
                    *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                         (uVar39 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x109f50;
                  pbVar29 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if ((*pbVar29 & 0x20) == 0) {
                    uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                    *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                    *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                    *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                  }
                  else {
                    *(undefined8 *)(puVar28 + -8) = 0x109f62;
                    puVar52 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    uVar13 = *puVar52;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                    if (uVar13 == 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x109f80;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x109f89;
                        cVar10 = func_0x();
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x109f99;
                          cVar10 = func_0x(0x1e80c50);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x109fb5;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar28 + 0x20) = 0;
                            *(undefined8 *)(puVar28 + -8) = 0x109fdb;
                            (*_DAT_)(1,0x17719d8,0x18916a8,0x80f);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x109fe9;
                      func_0x(uVar23,3);
                      uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                    }
                    uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar13 * 2;
                    *(uint *)(&stack0x00000028 + lVar20) = uVar39;
                    if (0x1f9e < uVar39) {
                      *(undefined8 *)(puVar28 + -8) = 0x10a012;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10a01b;
                        cVar10 = func_0x();
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10a02b;
                          cVar10 = func_0x(0x1e80c50);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x10a047;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar28 + 0x20) = 0;
                            *(undefined8 *)(puVar28 + -8) = 0x10a06d;
                            (*_DAT_)(1,0x17719d8,0x18916a8,0x816);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10a07b;
                      func_0x(uVar23,4);
                      uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x10a093;
                    uVar13 = func_0x(puVar52 + 1,(ulonglong)uVar13 - 1);
                    *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar13;
                    if ((uint)uVar13 <= *(uint *)(&stack0x00000028 + lVar20) &&
                        *(uint *)(&stack0x00000028 + lVar20) != (uint)uVar13) {
                      *(undefined8 *)(puVar28 + -8) = 0x10a0aa;
                      cVar10 = func_0x(0x1e80c50);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10a0b3;
                        cVar10 = func_0x();
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10a0c3;
                          cVar10 = func_0x(0x1e80c50);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x10a0df;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar28 + 0x20) = 0;
                            *(undefined8 *)(puVar28 + -8) = 0x10a105;
                            (*_DAT_)(1,0x17719d8,0x18916a8,0x81d);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10a113;
                      func_0x(uVar23,4);
                    }
                    uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                    do {
                      *(undefined8 *)(puVar28 + -8) = 0x10a12d;
                      iVar16 = func_0x(puVar52 + 1,uVar13 - 1);
                      if (iVar16 == 0) break;
                      uVar13 = *(ushort *)(&stack0x0000002c + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10a142;
                      lVar27 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      if (uVar13 == 1) {
                        uVar39 = *(uint *)(&stack0x00000028 + lVar20);
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x10a15e;
                        uVar38 = func_0x(lVar27 + 2,(ulonglong)uVar13 - 2);
                        uVar39 = (uint)uVar38;
                      }
                      *(undefined8 *)(puVar28 + -8) = 0x10a16e;
                      uVar13 = func_0x(lVar27 + 2,(ulonglong)(uint)uVar13 - 1);
                      uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                      if ((uVar39 < uVar44) || (uVar13 < uVar39)) {
                        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10a18a;
                        func_0x(uVar23,7);
                        uVar44 = *(uint *)(&stack0x00000028 + lVar20);
                      }
                      if ((uVar39 < uVar44) ||
                         (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar39))
                      goto LAB_;
                      lVar27 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      uVar13 = *(ushort *)(lVar27 + (ulonglong)uVar39);
                      if (uVar13 == 5) {
                        puVar52 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                        *puVar52 = *puVar52 | 2;
                        *(short *)(&stack0x0000002c + lVar20) =
                             *(short *)(&stack0x0000002c + lVar20) + -1;
                        *(short *)(&stack0x0000003a + lVar20) = (short)uVar39;
                        lVar27 = (ulonglong)(uVar39 & 0xffff) + lVar27;
                        *(undefined8 *)(puVar28 + -8) = 0x10a236;
                        iVar16 = func_0x(lVar27);
                        if (iVar16 == 0) {
                          *(ushort *)(&stack0x0000003c + lVar20) =
                               *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                        }
                        else {
                          *(undefined8 *)(puVar28 + -8) = 0x10a242;
                          sVar15 = func_0x(lVar27);
                          *(ushort *)(&stack0x0000003c + lVar20) =
                               *(ushort *)(&stack0x0000003c + lVar20) ^
                               (sVar15 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                        }
                        *(undefined8 *)(puVar28 + -8) = 0x10a26f;
                        uVar13 = func_0x(lVar27);
                        *(ushort *)(&stack0x0000003c + lVar20) =
                             *(ushort *)(&stack0x0000003c + lVar20) ^
                             (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff;
                        break;
                      }
                      if (uVar13 < 0x400) break;
                      puVar49 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar49 = *puVar49 | 1;
                      uVar13 = *(short *)(&stack0x0000002c + lVar20) - 1;
                      *(ushort *)(&stack0x0000002c + lVar20) = uVar13;
                    } while (uVar13 != 0);
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x10a1da;
                  iVar16 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if (iVar16 == 0) {
                    *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                  }
                  else {
                    iVar16 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *(int *)(&stack0x00000036 + lVar20) = iVar16;
                    *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar16 + 0xe;
                    *(undefined8 *)(puVar28 + -8) = 0x10a1f7;
                    uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    *(undefined8 *)(puVar28 + -8) = 0x10a206;
                    func_0x(uVar23,&stack0x00000278 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10a212;
                    iVar16 = func_0x(&stack0x00000278 + lVar20);
                    piVar45 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *piVar45 = *piVar45 + iVar16;
                  }
                  if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                     (*(ulonglong *)(&stack0x0000002e + lVar20) <
                      (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
                      *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                    *(undefined8 *)(puVar28 + -8) = 0x10a2c4;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10a2cd;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10a2dd;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10a2f9;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x10a31f;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x877);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10a32d;
                    func_0x(uVar23,0x12);
                  }
                  if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                    *(undefined8 *)(puVar28 + -8) = 0x10a345;
                    cVar10 = func_0x(0x1e80c50);
                    if (cVar10 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10a34e;
                      cVar10 = func_0x();
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10a35e;
                        cVar10 = func_0x(0x1e80c50);
                        if (cVar10 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10a37a;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x10a3a0;
                          (*_DAT_)(1,0x17719d8,0x18916a8,0x87c);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10a3ae;
                    func_0x(uVar23,5);
                  }
                }
LAB_:
                if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 9) {
                  *(undefined8 *)(puVar28 + -8) = 0x10a3bd;
                  cVar10 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if ((cVar10 == '\0') || (cVar10 == '\f')) {
                    uVar19 = 9;
                    goto LAB_;
                  }
                }
                uVar19 = *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
              }
              else {
                *(undefined8 *)(puVar28 + -8) = 0x10a3da;
                uVar19 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              }
LAB_:
              *(undefined8 *)(puVar28 + -8) = 0x10a3ec;
              func_0x(7,uVar19,0x1f7c);
            }
          }
        }
LAB_:
        param_3 = *(longlong **)(&stack0x00000050 + lVar20);
      }
      *(undefined8 *)(puVar47 + -8) = 0x10a3ff;
      func_0x(&stack0x00000280 + lVar20);
      lVar24 = *(longlong *)(&stack0x00000080 + lVar20);
      puVar48 = puVar47;
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a417;
      func_0x(lVar27 + 0xa60,param_2);
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a41f;
      uVar23 = func_0x(param_3);
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a427;
      iVar16 = func_0x(uVar23);
      uVar39 = uVar44 & 1;
      if (iVar16 != 0) {
        uVar39 = 0;
      }
      *(longlong *)((longlong)&uStackX_20 + lVar20 + -0x20) =
           *(longlong *)(&stack0x00000138 + lVar20) + 0x290;
      *(undefined **)(&stack0xfffffffffffffff8 + lVar20) = &stack0x0000019c + lVar20;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar20) = 0x1f7c;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0x3f3c;
      *(undefined **)(&stack0xffffffffffffffe0 + lVar20) = &stack0x000028a0 + lVar20;
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a483;
      func_0x(param_1 + 0xa80,param_3,(uVar39 ^ 1) + 1,psVar2);
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a48e;
      lVar27 = func_0x(lVar24);
      if ((*(byte *)(lVar27 + 0x67) & 0x40) != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a49c;
        lVar27 = func_0x(param_3);
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4b3;
        func_0x(param_1 + 0xa80,lVar27 + 0x78,psVar2,uVar39);
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4bb;
      uVar23 = func_0x(param_3);
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4c3;
      lVar27 = func_0x(uVar23);
      puVar48 = &stack0xffffffffffffffc0 + lVar20;
      if (lVar27 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4d0;
        iVar16 = func_0x(lVar24);
        puVar48 = &stack0xffffffffffffffc0 + lVar20;
        if (iVar16 != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4dc;
          iVar16 = func_0x(lVar24);
          puVar48 = &stack0xffffffffffffffc0 + lVar20;
          if (iVar16 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4ef;
            func_0x(param_2,psVar2,lVar24);
            puVar48 = &stack0xffffffffffffffc0 + lVar20;
          }
        }
      }
    }
    uVar39 = 0;
    *(undefined8 *)(puVar48 + -8) = 0x10a4f7;
    iVar16 = func_0x(lVar24);
    if (iVar16 == 0) {
      *(undefined8 *)(puVar48 + -8) = 0x10a507;
      uVar23 = func_0x(param_3);
      if (lVar24 != 0) {
        *(undefined8 *)(puVar48 + -8) = 0x10a51b;
        lVar27 = func_0x(uVar23);
        *(undefined8 *)(puVar48 + -8) = 0x10a529;
        sVar15 = func_0x(uVar23);
        if (sVar15 != 0) {
          do {
            *(undefined8 *)(puVar48 + -8) = 0x10a53e;
            iVar16 = func_0x(lVar27);
            if (iVar16 == 0) {
              *(undefined8 *)(puVar48 + -8) = 0x10a555;
              pplVar33 = (longlong **)func_0x(lVar27,&stack0x00000370 + lVar20);
              uVar34 = *(undefined8 *)(lVar24 + 8);
              *(undefined8 *)(puVar48 + -8) = 0x10a561;
              cVar10 = func_0x(uVar34);
              if (cVar10 != '\0') {
                if (*(int *)(*(longlong *)(lVar24 + 8) + 0x480) == 0) {
                  *(undefined8 *)(puVar48 + -8) = 0x10a57e;
                  func_0x(lVar24);
                }
                plVar7 = pplVar33[1];
                plVar8 = *pplVar33;
                if (plVar8[1] == 0) {
LAB_:
                  plVar7 = (longlong *)(*plVar8 + (longlong)plVar7 * 8);
                  LOCK();
                  *plVar7 = *plVar7 + 1;
                  UNLOCK();
                }
                else {
                  *(undefined8 *)(puVar48 + -8) = 0x10a591;
                  uVar44 = func_0x();
                  *(undefined8 *)(puVar48 + -8) = 0x10a5a0;
                  uVar18 = func_0x(_DAT_);
                  if (uVar18 <= uVar44) goto LAB_;
                  lVar24 = *(longlong *)(plVar8[1] + (ulonglong)uVar44 * 8);
                  *(longlong *)(lVar24 + (longlong)plVar7 * 8) =
                       *(longlong *)(lVar24 + (longlong)plVar7 * 8) + 1;
                }
                plVar7 = *(longlong **)(&stack0x00000288 + lVar20);
                if (plVar7 == (longlong *)0x0) {
                  lVar24 = *(longlong *)(&stack0x00000080 + lVar20);
                }
                else {
                  *(undefined8 *)(puVar48 + -8) = 0x10a5e6;
                  uVar34 = func_0x(plVar7);
                  *(undefined8 *)(puVar48 + -8) = 0x10a5ee;
                  cVar10 = func_0x(uVar34);
                  lVar24 = *(longlong *)(&stack0x00000080 + lVar20);
                  if (cVar10 != '\0') {
                    *(undefined **)(puVar48 + 0x20) = &stack0x000002c8 + lVar20;
                    uVar19 = *(undefined4 *)(pplVar33 + 1);
                    uVar34 = *(undefined8 *)(lVar24 + 8);
                    *(undefined8 *)(puVar48 + -8) = 0x10a620;
                    cVar10 = func_0x
                                       (uVar34,uVar19,&stack0x00000298 + lVar20,
                                        &stack0x00000290 + lVar20);
                    if (cVar10 != '\0') {
                      lVar25 = *plVar7;
                      *(undefined8 *)(puVar48 + -8) = 0x10a634;
                      uVar34 = func_0x(lVar24);
                      pcVar4 = *(code **)(lVar25 + 0x2b8);
                      *(undefined8 *)(puVar48 + -8) = 0x10a640;
                      (*pcVar4)(plVar7,uVar34);
                      *(undefined8 *)(puVar48 + -8) = 0x10a64c;
                      func_0x(&stack0x00000380 + lVar20);
                      uVar19 = *(undefined4 *)(pplVar33 + 1);
                      uVar34 = *(undefined8 *)(*(longlong *)(lVar24 + 8) + 0x160);
                      *(undefined8 *)(puVar48 + -8) = 0x10a65f;
                      uVar34 = func_0x(uVar34,uVar19);
                      *(undefined8 *)(puVar48 + -8) = 0x10a667;
                      uVar19 = func_0x(uVar34);
                      *(undefined8 *)(puVar48 + -8) = 0x10a671;
                      uVar35 = func_0x(lVar24);
                      *(undefined8 *)(puVar48 + 0x20) = *(undefined8 *)(&stack0x00000290 + lVar20);
                      uVar34 = *(undefined8 *)(&stack0x00000298 + lVar20);
                      *(undefined8 *)(puVar48 + -8) = 0x10a696;
                      func_0x(&stack0x00000380 + lVar20,uVar35,uVar19,uVar34);
                      *(undefined8 *)(puVar48 + -8) = 0x10a6a5;
                      func_0x(&stack0x00000380 + lVar20,plVar7);
                    }
                  }
                }
              }
            }
            uVar39 = uVar39 + 1;
            lVar27 = lVar27 + 0x50;
            *(undefined8 *)(puVar48 + -8) = 0x10a6ba;
            uVar13 = func_0x(uVar23);
          } while (uVar39 < uVar13);
        }
      }
    }
    *(undefined8 *)(puVar48 + -8) = 0x10a6cf;
    iVar16 = func_0x(psVar2);
    if (iVar16 != 0) {
      *(undefined8 *)(puVar48 + -8) = 0x10a6df;
      func_0x(&stack0x00000168 + lVar20);
      *(undefined8 *)(puVar48 + -8) = 0x10a6eb;
      func_0x(&stack0x00000168 + lVar20);
      *(undefined8 *)(puVar48 + -8) = 0x10a6fb;
      func_0x(psVar2,&stack0x00000168 + lVar20);
      *(undefined8 *)(puVar48 + -8) = 0x10a703;
      cVar10 = func_0x(lVar24);
      if (cVar10 != '\0') {
        *(undefined8 *)(puVar48 + -8) = 0x10a718;
        uVar23 = func_0x(&stack0x000002a8 + lVar20,0,0);
        *(undefined8 *)(puVar48 + -8) = 0x10a724;
        func_0x(psVar2,uVar23);
      }
    }
    param_2 = *(undefined8 **)(&stack0x000000b0 + lVar20);
  }
  else {
    uVar23 = *(undefined8 *)(param_1 + 0x2e0);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a8c9;
    uVar23 = func_0x(uVar23);
    *(short **)(&stack0xfffffffffffffff8 + lVar20) = psVar2;
    *(undefined **)(&stack0xfffffffffffffff0 + lVar20) = &stack0x000028a0 + lVar20;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0x3f3c;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = *(undefined8 *)(param_1 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a903;
    func_0x(param_2,lVar27,lVar24,uVar23);
  }
  uVar19 = 0;
  *(undefined8 *)(puVar48 + -8) = 0x10a73f;
  cVar10 = func_0x(param_2,1);
  if (cVar10 != '\0') {
    *(undefined8 *)(puVar48 + -8) = 0x10a755;
    uVar34 = func_0x(param_2,1,1);
    *(undefined8 *)(puVar48 + -8) = 0x10a766;
    uVar35 = func_0x(param_2,1,0);
    *(undefined8 *)(puVar48 + -8) = 0x10a778;
    uVar36 = func_0x(uVar34,&stack0x000002d0 + lVar20);
    *(undefined8 *)(puVar48 + -8) = 0x10a78a;
    uVar23 = func_0x(uVar34,&stack0x000002ae + lVar20);
    *(undefined8 *)(puVar48 + -8) = 0x10a799;
    uVar37 = func_0x(uVar23,&stack0x000002ba + lVar20);
    uVar23 = *(undefined8 *)(*(longlong *)(&stack0x00000138 + lVar20) + 0x2e0);
    *(undefined8 *)(puVar48 + -8) = 0x10a7af;
    uVar23 = func_0x(uVar23);
    *(undefined8 *)(puVar48 + -8) = 0x10a7b7;
    uVar23 = func_0x(uVar23);
    *(undefined8 *)(puVar48 + -8) = 0x10a7bf;
    uVar23 = func_0x(uVar23);
    *(undefined8 *)(puVar48 + -8) = 0x10a7d0;
    iVar16 = func_0x(uVar23,uVar37,uVar36,0);
    if (iVar16 != 0) {
      *(undefined8 *)(puVar48 + -8) = 0x10a7e3;
      uVar23 = func_0x(uVar34,&stack0x000002d8 + lVar20);
      *(undefined8 *)(puVar48 + -8) = 0x10a7eb;
      uVar12 = func_0x(uVar23);
      *(undefined8 *)(puVar48 + -8) = 0x10a7fd;
      uVar23 = func_0x(uVar34,&stack0x000002b4 + lVar20);
      *(undefined8 *)(puVar48 + -8) = 0x10a808;
      iVar16 = func_0x(uVar34);
      *(undefined8 *)(puVar48 + -8) = 0x10a81c;
      uVar19 = func_0x(uVar35,iVar16 != 0,uVar23,uVar12);
    }
    param_2 = *(undefined8 **)(&stack0x000000b0 + lVar20);
  }
  uVar3 = *(undefined4 *)(&stack0x000000a8 + lVar20);
  *(undefined8 *)(puVar48 + -8) = 0x10a83c;
  func_0x(param_2,psVar2,uVar3,uVar19);
  lVar27 = *(longlong *)(&stack0x00000080 + lVar20);
  if ((*(longlong *)(*(longlong *)(lVar27 + 8) + 0x488) != 0) && (*_DAT_ != '\0')) {
    *(undefined8 *)(puVar48 + -8) = 0x10a867;
    uVar23 = func_0x();
    *(undefined8 *)(puVar48 + -8) = 0x10a874;
    iVar16 = func_0x(uVar23,0x281);
    if (iVar16 == 0) {
      lVar27 = *(longlong *)(*(longlong *)(lVar27 + 8) + 0x488);
      if (*(longlong *)(lVar27 + 0x20) != 0) {
        *(undefined8 *)(puVar48 + -8) = 0x10a893;
        uVar39 = func_0x();
        *(undefined8 *)(puVar48 + -8) = 0x10a8a1;
        uVar44 = func_0x(_DAT_);
        if (uVar39 < uVar44) {
          lVar27 = *(longlong *)(*(longlong *)(lVar27 + 0x20) + (ulonglong)uVar39 * 8);
          *(longlong *)(lVar27 + 0x10) = *(longlong *)(lVar27 + 0x10) + 1;
          goto LAB_;
        }
      }
      LOCK();
      plVar7 = (longlong *)(*(longlong *)(lVar27 + 0x18) + 0x10);
      *plVar7 = *plVar7 + 1;
      UNLOCK();
    }
  }
LAB_:
  **(undefined8 **)(&stack0x00000170 + lVar20) = param_2;
LAB_:
  *(undefined8 *)(puVar48 + -8) = 0x10a928;
  func_0x(&stack0x000002a0 + lVar20);
  uVar56 = *(ulonglong *)(&stack0x000067e0 + lVar20);
  *(undefined8 *)(puVar48 + -8) = 0x10a937;
  func_0x(uVar56 ^ (ulonglong)psVar2);
  return;
code_r0x00109218:
  uVar56 = (ulonglong)uVar44;
  if (uVar44 == 0) goto LAB_;
  goto LAB_;
code_r0x001045f8:
  uVar56 = (ulonglong)uVar44;
  if (uVar44 == 0) goto LAB_;
  goto LAB_;
}

