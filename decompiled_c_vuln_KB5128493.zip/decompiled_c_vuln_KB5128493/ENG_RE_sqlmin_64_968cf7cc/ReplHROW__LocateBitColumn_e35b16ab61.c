
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_(short *param_1,uint *param_2,undefined8 param_3,int *param_4)

{
  ushort *puVar1;
  longlong *plVar2;
  byte bVar3;
  ushort uVar4;
  int iVar5;
  ulonglong *puVar6;
  longlong lVar7;
  longlong lVar8;
  ushort uVar9;
  short sVar10;
  uint uVar11;
  uint uVar12;
  ulonglong uVar13;
  uint uVar14;
  uint uVar15;
  int *piVar16;
  byte *pbVar17;
  longlong lVar18;
  ushort *puVar19;
  longlong unaff_GS_OFFSET;
  undefined auStackX_8 [8];
  uint auStackX_18 [4];
  
  auStackX_18[0] = (uint)param_3;
  puVar1 = (ushort *)(param_1 + 1);
  uVar4 = *(ushort *)(param_2 + 1);
  if (*param_1 != 0) {
    auStackX_18[0] = 0;
    piVar16 = (int *)func_0x(puVar1,param_2,param_3,param_4,auStackX_18);
    if (*param_1 == 0) {
      return piVar16;
    }
    plVar2 = *(longlong **)(param_1 + 8);
    if (plVar2 == (longlong *)0x0) {
      return piVar16;
    }
    if (*plVar2 == 0) {
      return piVar16;
    }
    if ((*(byte *)((longlong)param_2 + 6) & 8) != 0) {
      return piVar16;
    }
    if ((auStackX_18[0] & 1) != 0) {
      return piVar16;
    }
    if ((piVar16 != (int *)0x0) && (piVar16 != (int *)0x17b4434)) {
      piVar16 = (int *)func_0x(plVar2,param_2,piVar16,*param_4,0,0,param_4,auStackX_18[0]);
      return piVar16;
    }
LAB_:
    *param_4 = 0;
    return (int *)0x0;
  }
  uVar12 = *param_2;
  if ((uVar12 & 0xc0000000) == 0x80000000) {
    iVar5 = func_0x(puVar1);
    if (iVar5 != 0) {
      piVar16 = (int *)func_0x(param_1 + 0x15,param_2,param_4,auStackX_8);
      return piVar16;
    }
    goto LAB_;
  }
  uVar14 = 1;
  uVar15 = 0;
  if ((uVar4 != 0) || ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
    pbVar17 = *(byte **)(param_1 + 4);
    if ((*pbVar17 & 0x10) == 0) {
      uVar14 = 1;
      uVar11 = uVar15;
      if ((1 << (*pbVar17 & 0xe) & 0x1105U) != 0) {
LAB_:
        uVar14 = uVar15;
        uVar11 = ~(uint)(*(ushort *)((longlong)param_2 + 6) >> 4) & 1;
      }
      if (uVar4 != 0) goto LAB_;
    }
    else {
      uVar11 = *(uint *)(param_1 + 8);
      if (((int)uVar11 <= (int)uVar12) || (*(ushort *)(pbVar17 + uVar11) < uVar4))
      goto LAB_;
      if (uVar4 == 0) goto LAB_;
      uVar11 = pbVar17[(ulonglong)uVar11 + (ulonglong)(uVar4 - 1 >> 3) + 2] >>
               ((byte)(uVar4 - 1) & 7) & 1;
LAB_:
      if (uVar11 != 0) {
        *param_4 = 0;
        return (int *)0x0;
      }
    }
    if ((uVar14 == 0) && ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) goto LAB_;
  }
LAB_:
  if (-1 < (int)uVar12) {
    uVar9 = *(ushort *)((longlong)param_2 + 6);
    if ((uVar9 & 8) != 0) {
      piVar16 = (int *)0x17b4434;
      bVar3 = *(byte *)((longlong)(int)uVar12 + *(longlong *)(param_1 + 4));
      *param_4 = 1;
      if ((bVar3 & (byte)(1 << ((byte)uVar9 & 7))) == 0) {
        piVar16 = (int *)0x17b4a58;
      }
      return piVar16;
    }
    if ((uVar9 & 0x10) != 0) {
      bVar3 = **(byte **)(param_1 + 4);
      if ((bVar3 & 0x10) == 0) {
        if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
          piVar16 = *(int **)(param_2 + 2);
          iVar5 = *piVar16;
          if (iVar5 != 1) {
            (*_DAT_)(1,0x1bdd768,0x1bdc168,0x381,0);
          }
          *param_4 = iVar5;
          return piVar16 + 1;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uVar12) ||
              (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < uVar4))
      goto LAB_;
    }
    *param_4 = 1;
    return (int *)((longlong)(int)*param_2 + *(longlong *)(param_1 + 4));
  }
  if (*(int *)(param_1 + 2) == 0) {
    pbVar17 = *(byte **)(param_1 + 4);
    uVar12 = *(uint *)(param_1 + 8);
    uVar13 = (ulonglong)uVar12;
    *puVar1 = 0;
    *(uint *)(param_1 + 10) = uVar12;
    bVar3 = *pbVar17;
    if ((bVar3 & 0x10) != 0) {
      uVar12 = uVar12 + 2 + (*(ushort *)(pbVar17 + uVar13) + 7 >> 3);
      uVar13 = (ulonglong)uVar12;
      *(uint *)(param_1 + 10) = uVar12;
      bVar3 = *pbVar17;
    }
    if ((bVar3 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar13;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar13;
    }
    else {
      puVar19 = (ushort *)(pbVar17 + uVar13);
      uVar4 = *puVar19;
      param_1[0xe] = uVar4;
      if (uVar4 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar8 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar8 != 0)) &&
           ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x1a2f9f8,0x1b4f6c8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar13 = (ulonglong)*(uint *)(param_1 + 10);
        uVar4 = param_1[0xe];
      }
      uVar12 = (int)uVar13 + (uVar4 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar12;
      if (0x1f9e < uVar12) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar8 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar8 != 0 &&
            ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1a2f9f8,0x1b4f6c8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar4 = param_1[0xe];
        uVar12 = *(uint *)(param_1 + 0xc);
      }
      uVar13 = (ulonglong)uVar4;
      uVar4 = puVar19[uVar13];
      *(uint *)(param_1 + 2) = uVar4 & 0x7fff;
      if ((uVar4 & 0x7fff) < uVar12) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar8 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar8 != 0)) &&
           ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1a2f9f8,0x1b4f6c8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar13 = (ulonglong)(ushort)param_1[0xe];
      }
      if ((short)puVar19[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
        lVar8 = *(longlong *)(param_1 + 4);
        do {
          if ((int)uVar13 == 1) {
            uVar12 = *(uint *)(param_1 + 0xc);
            uVar14 = uVar12;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar8 + uVar13 * 2) & 0x7fff) <
                uVar12) goto LAB_;
          }
          else {
            uVar14 = *(uint *)(param_1 + 0xc);
            uVar12 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar8 + -2 + uVar13 * 2) &
                     0x7fff;
            if (uVar14 <= uVar12) goto LAB_;
LAB_:
            func_0x(lVar8,7);
            uVar14 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar12 < uVar14) || (*(uint *)(param_1 + 2) < uVar12)) goto LAB_;
          lVar8 = *(longlong *)(param_1 + 4);
          if (*(ushort *)(lVar8 + (ulonglong)uVar12) == 5) {
            *puVar1 = *puVar1 | 2;
            param_1[0xe] = param_1[0xe] + -1;
            param_1[0x15] = (short)uVar12;
            lVar8 = (ulonglong)(uVar12 & 0xffff) + *(longlong *)(param_1 + 4);
            uVar4 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar8 + 2) & 0x4000) != 0) {
              uVar4 = *(ushort *)(lVar8 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar4;
            param_1[0x16] = (uVar4 ^ *(ushort *)(lVar8 + 2)) & 0x7ff ^ uVar4;
            uVar13 = (ulonglong)*(uint *)(param_1 + 2);
            pbVar17 = *(byte **)(param_1 + 4);
            goto LAB_;
          }
          if (*(ushort *)(lVar8 + (ulonglong)uVar12) < 0x400) break;
          *puVar1 = *puVar1 | 1;
          uVar4 = param_1[0xe] - 1;
          param_1[0xe] = uVar4;
          if ((uVar4 == 0) ||
             (uVar13 = (ulonglong)uVar4, -1 < (short)puVar19[(ulonglong)(uVar4 - 1) + 1])) break;
        } while( true );
      }
      uVar13 = (ulonglong)*(uint *)(param_1 + 2);
      pbVar17 = *(byte **)(param_1 + 4);
    }
LAB_:
    if ((*pbVar17 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = (int)uVar13;
      *(int *)(param_1 + 2) = (int)uVar13 + 0xe;
      puVar6 = (ulonglong *)func_0x(puVar1);
      uVar13 = *puVar6;
      uVar9 = (ushort)(uVar13 >> 0x30);
      uVar4 = uVar9;
      if ((((uint)(int)(short)uVar9 >> 1 ^ (int)(short)uVar9) & 0x2000) != 0) {
        uVar4 = uVar9 & 0xdfff;
        if ((uVar13 & 0x4000000000000000) != 0) {
          uVar4 = uVar9 | 0x2000;
        }
      }
      if (uVar4 == 0xfffc) {
        uVar15 = (uint)((uVar13 >> 0x20 & 0xffff) >> 5);
      }
      *(uint *)(param_1 + 2) = *(int *)(param_1 + 2) + uVar15;
      uVar13 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar5 = (int)uVar13;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar13 + *(longlong *)(param_1 + 4))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar8 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar8 != 0 &&
           (lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0)) && (*(char *)(lVar8 + 0x499) != '\0'))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x1a2f9f8,0x1b4f6c8,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar5 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar5 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar8 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar8 != 0 &&
          ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x1a2f9f8,0x1b4f6c8,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar10 = -*(short *)param_2;
  if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
    bVar3 = **(byte **)(param_1 + 4);
    if ((bVar3 & 0x10) == 0) {
      if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
        piVar16 = *(int **)(param_2 + 2);
        *param_4 = *piVar16;
        return piVar16 + 1;
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)*param_2) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
             *(ushort *)(param_2 + 1))) goto LAB_;
  }
  lVar8 = (longlong)sVar10;
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar10) {
    *param_4 = 0;
    return *(int **)(param_1 + 4);
  }
  lVar18 = *(longlong *)(param_1 + 4);
  lVar7 = (ulonglong)*(uint *)(param_1 + 10) + lVar18;
  if (sVar10 == 1) {
    uVar12 = *(uint *)(param_1 + 0xc);
    uVar15 = *(ushort *)(lVar7 + lVar8 * 2) & 0x7fff;
LAB_:
    if (uVar12 <= uVar15) goto LAB_;
  }
  else {
    uVar12 = *(ushort *)(lVar7 + -2 + lVar8 * 2) & 0x7fff;
    lVar18 = *(longlong *)(param_1 + 4);
    uVar15 = *(ushort *)(lVar7 + lVar8 * 2) & 0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar12) goto LAB_;
  }
  func_0x(lVar18,7);
LAB_:
  *param_4 = uVar15 - uVar12;
  return (int *)((ulonglong)uVar12 + *(longlong *)(param_1 + 4));
}

