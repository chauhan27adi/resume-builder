
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint *param_2,short *param_3)

{
  uint *puVar1;
  longlong *plVar2;
  undefined8 uVar3;
  bool bVar4;
  byte bVar5;
  ushort uVar6;
  int iVar7;
  uint uVar8;
  longlong lVar9;
  longlong lVar10;
  ulonglong *puVar11;
  uint uVar12;
  ulonglong uVar13;
  longlong lVar14;
  ushort uVar15;
  short sVar16;
  undefined8 unaff_RBX;
  undefined *puVar17;
  uint *puVar18;
  ushort *puVar19;
  byte *pbVar20;
  uint uVar21;
  uint *puVar22;
  ulonglong uVar23;
  longlong unaff_GS_OFFSET;
  uint uStackX_18;
  uint auStackX_1c [2];
  undefined auStackX_24 [4];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  puVar17 = &stack0xffffffffffffffc8 + lVar9;
  puVar1 = (uint *)((longlong)&uStackX_18 + lVar9);
  *(undefined8 *)(&stack0x00000030 + lVar9) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000040e0 + lVar9) = unaff_RBX;
  *(ulonglong *)(&stack0x00004078 + lVar9) = _DAT_ ^ (ulonglong)puVar1;
  *(longlong *)(&stack0x00000028 + lVar9) = param_1;
  lVar14 = *(longlong *)(param_1 + 0x58);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10005c;
  func_0x(&stack0x00000038 + lVar9,&stack0x00000140 + lVar9);
  *(undefined8 *)(&stack0x00000038 + lVar9) = 0x834988;
  *(undefined4 *)((longlong)auStackX_1c + lVar9 + 4) = 0x80000;
  bVar4 = false;
  puVar18 = (uint *)0x0;
  uVar21 = 0;
  lVar14 = *(longlong *)(lVar14 + 8);
  puVar22 = (uint *)0x0;
  uVar8 = uVar21;
  if (*(int *)(lVar14 + 0x100) == 2) {
    if ((*(byte *)(lVar14 + 0x42) & 4) == 0) {
      uVar23 = (ulonglong)*(uint *)(lVar14 + 0xb0);
      if (0x1f9e < *(uint *)(lVar14 + 0xb0)) {
        uVar23 = 0x1f9e;
      }
    }
    else {
      uVar23 = 0x1f9e;
    }
    uVar8 = (uint)uVar23;
    uVar13 = uVar23 + 0xf;
    if (uVar13 <= uVar23) {
      uVar13 = 0xffffffffffffff0;
    }
    uVar13 = uVar13 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000be;
    func_0x();
    puVar17 = &stack0xffffffffffffffc8 + -uVar13 + lVar9;
    puVar22 = (uint *)((longlong)&uStackX_18 + -uVar13 + lVar9);
  }
  bVar5 = *(byte *)(param_2 + 8);
  if (*param_3 == 0) {
    uVar8 = *param_2;
    if ((uVar8 & 0xc0000000) == 0x80000000) {
      *(undefined8 *)(puVar17 + -8) = 0x10098d;
      iVar7 = func_0x(param_3 + 1);
      if (iVar7 != 0) {
        *(undefined8 *)(puVar17 + -8) = 0x1009a5;
        puVar18 = (uint *)func_0x(param_3 + 0x15,param_2,puVar1,auStackX_24 + lVar9);
        goto LAB_;
      }
      uVar8 = 0;
      *puVar1 = 0;
    }
    else if (((bVar5 & 2) == 0) && ((*(byte *)((longlong)param_2 + 6) & 0x10) == 0)) {
LAB_:
      if ((int)uVar8 < 0) {
        if (*(int *)(param_3 + 2) == 0) {
          param_3[1] = 0;
          uVar8 = *(uint *)(param_3 + 8);
          uVar23 = (ulonglong)uVar8;
          *(uint *)(param_3 + 10) = uVar8;
          pbVar20 = *(byte **)(param_3 + 4);
          bVar5 = *pbVar20;
          if ((bVar5 & 0x10) != 0) {
            uVar8 = uVar8 + 2 + (*(ushort *)(pbVar20 + uVar23) + 7 >> 3);
            uVar23 = (ulonglong)uVar8;
            *(uint *)(param_3 + 10) = uVar8;
            bVar5 = *pbVar20;
          }
          if ((bVar5 & 0x20) == 0) {
            *(int *)(param_3 + 2) = (int)uVar23;
            param_3[0xe] = 0;
            *(int *)(param_3 + 0xc) = (int)uVar23;
          }
          else {
            puVar19 = (ushort *)(pbVar20 + uVar23);
            uVar6 = *puVar19;
            param_3[0xe] = uVar6;
            if (uVar6 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar14 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0)) &&
                 ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                  (*(char *)(lVar14 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar17 + -8) = 0x10035f;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar17 + 0x20) = 0;
                  *(undefined8 *)(puVar17 + -8) = 0x1003a1;
                  (*_DAT_)(1,0xa9a4c8,0xbba198,0x80f);
                }
              }
              uVar3 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar17 + -8) = 0x100370;
              func_0x(uVar3,3);
              uVar6 = param_3[0xe];
              uVar23 = (ulonglong)*(uint *)(param_3 + 10);
            }
            uVar8 = (int)uVar23 + (uVar6 + 1) * 2;
            *(uint *)(param_3 + 0xc) = uVar8;
            if (0x1f9e < uVar8) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar14 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0 &&
                  ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                   (*(char *)(lVar14 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar17 + -8) = 0x10043c;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar17 + 0x20) = 0;
                  *(undefined8 *)(puVar17 + -8) = 0x100462;
                  (*_DAT_)(1,0xa9a4c8,0xbba198,0x816);
                }
              }
              uVar3 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar17 + -8) = 0x100470;
              func_0x(uVar3,4);
              uVar6 = param_3[0xe];
              uVar8 = *(uint *)(param_3 + 0xc);
            }
            uVar23 = (ulonglong)uVar6;
            uVar6 = puVar19[uVar23];
            *(uint *)(param_3 + 2) = uVar6 & 0x7fff;
            if ((uVar6 & 0x7fff) < uVar8) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar14 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0)) &&
                 ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                  (*(char *)(lVar14 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar17 + -8) = 0x10050e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar17 + 0x20) = 0;
                  *(undefined8 *)(puVar17 + -8) = 0x100534;
                  (*_DAT_)(1,0xa9a4c8,0xbba198,0x81d);
                }
              }
              uVar3 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar17 + -8) = 0x100542;
              func_0x(uVar3,4);
              uVar23 = (ulonglong)(ushort)param_3[0xe];
            }
            if ((short)puVar19[(ulonglong)((int)uVar23 - 1) + 1] < 0) {
              lVar14 = *(longlong *)(param_3 + 4);
              do {
                lVar10 = (ulonglong)*(uint *)(param_3 + 10) + lVar14;
                if ((int)uVar23 == 1) {
                  uVar8 = *(uint *)(param_3 + 0xc);
                  uVar6 = *(ushort *)(lVar10 + uVar23 * 2);
                  uVar21 = uVar8;
LAB_:
                  if ((uVar6 & 0x7fff) < uVar8) goto LAB_;
                }
                else {
                  uVar8 = *(ushort *)(lVar10 + -2 + uVar23 * 2) & 0x7fff;
                  uVar21 = *(uint *)(param_3 + 0xc);
                  uVar6 = *(ushort *)(lVar10 + uVar23 * 2);
                  if (uVar21 <= uVar8) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar17 + -8) = 0x1005be;
                  func_0x(lVar14,7);
                  uVar21 = *(uint *)(param_3 + 0xc);
                }
                if ((uVar8 < uVar21) || (*(uint *)(param_3 + 2) < uVar8)) goto LAB_;
                lVar14 = *(longlong *)(param_3 + 4);
                if (*(ushort *)(lVar14 + (ulonglong)uVar8) == 5) {
                  param_3[1] = param_3[1] | 2;
                  param_3[0xe] = param_3[0xe] + -1;
                  param_3[0x15] = (short)uVar8;
                  lVar14 = (ulonglong)(uVar8 & 0xffff) + *(longlong *)(param_3 + 4);
                  uVar6 = param_3[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar14 + 2) & 0x4000) != 0) {
                    uVar6 = *(ushort *)(lVar14 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
                  }
                  param_3[0x16] = uVar6;
                  param_3[0x16] = (uVar6 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar6;
                  uVar23 = (ulonglong)*(uint *)(param_3 + 2);
                  pbVar20 = *(byte **)(param_3 + 4);
                  goto LAB_;
                }
                if (*(ushort *)(lVar14 + (ulonglong)uVar8) < 0x400) break;
                param_3[1] = param_3[1] | 1;
                uVar6 = param_3[0xe] - 1;
                param_3[0xe] = uVar6;
                if ((uVar6 == 0) ||
                   (uVar23 = (ulonglong)uVar6, -1 < (short)puVar19[(ulonglong)(uVar6 - 1) + 1]))
                break;
              } while( true );
            }
            uVar23 = (ulonglong)*(uint *)(param_3 + 2);
            pbVar20 = *(byte **)(param_3 + 4);
          }
LAB_:
          iVar7 = 0;
          if ((*pbVar20 & 0x40) == 0) {
            *(undefined4 *)(param_3 + 0x13) = 0;
          }
          else {
            *(int *)(param_3 + 0x13) = (int)uVar23;
            *(int *)(param_3 + 2) = (int)uVar23 + 0xe;
            *(undefined8 *)(puVar17 + -8) = 0x1006cc;
            puVar11 = (ulonglong *)func_0x(param_3 + 1);
            uVar23 = *puVar11;
            uVar15 = (ushort)(uVar23 >> 0x30);
            uVar6 = uVar15;
            if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
              uVar6 = uVar15 & 0xdfff;
              if ((uVar23 & 0x4000000000000000) != 0) {
                uVar6 = uVar15 | 0x2000;
              }
            }
            if (uVar6 == 0xfffc) {
              iVar7 = (int)((uVar23 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar7;
            uVar23 = (ulonglong)*(uint *)(param_3 + 2);
          }
          iVar7 = (int)uVar23;
          if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
             (*(ulonglong *)(param_3 + 0xf) < uVar23 + *(longlong *)(param_3 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar14 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar14 != 0 &&
                 (lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0)) &&
                (*(char *)(lVar14 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar17 + -8) = 0x1007c4;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar17 + 0x20) = 0;
                *(undefined8 *)(puVar17 + -8) = 0x1007ea;
                (*_DAT_)(1,0xa9a4c8,0xbba198,0x877);
              }
            }
            uVar3 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar17 + -8) = 0x1007f8;
            func_0x(uVar3,0x12);
            iVar7 = *(int *)(param_3 + 2);
          }
          if (0x3f3b < iVar7 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar14 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar14 != 0 &&
                ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                 (*(char *)(lVar14 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar17 + -8) = 0x100884;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar17 + 0x20) = 0;
                *(undefined8 *)(puVar17 + -8) = 0x1008aa;
                (*_DAT_)(1,0xa9a4c8,0xbba198,0x87c);
              }
            }
            uVar3 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar17 + -8) = 0x1008b6;
            func_0x(uVar3,5);
          }
        }
LAB_:
        sVar16 = -*(short *)param_2;
        if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
          bVar5 = **(byte **)(param_3 + 4);
          if ((bVar5 & 0x10) == 0) {
            if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar18 = *(uint **)(param_2 + 2) + 1;
              uVar8 = **(uint **)(param_2 + 2);
              *puVar1 = uVar8;
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_3 + 8) <= (int)*param_2) ||
                  (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                   *(ushort *)(param_2 + 1))) goto LAB_;
        }
        lVar14 = (longlong)sVar16;
        puVar18 = *(uint **)(param_3 + 4);
        if ((uint)(ushort)param_3[0xe] < (uint)(int)sVar16) goto LAB_;
        uVar8 = *(uint *)(param_3 + 10);
        if (sVar16 == 1) {
          uVar21 = *(uint *)(param_3 + 0xc);
          uVar8 = *(ushort *)((longlong)puVar18 + lVar14 * 2 + (ulonglong)uVar8) & 0x7fff;
LAB_:
          if (uVar8 < uVar21) goto LAB_;
        }
        else {
          uVar21 = *(ushort *)((longlong)puVar18 + lVar14 * 2 + ((ulonglong)uVar8 - 2)) & 0x7fff;
          uVar8 = *(ushort *)((longlong)puVar18 + lVar14 * 2 + (ulonglong)uVar8) & 0x7fff;
          puVar18 = *(uint **)(param_3 + 4);
          if (*(uint *)(param_3 + 0xc) <= uVar21) goto LAB_;
LAB_:
          *(undefined8 *)(puVar17 + -8) = 0x100972;
          func_0x(puVar18,7);
          puVar18 = *(uint **)(param_3 + 4);
        }
        puVar18 = (uint *)((longlong)puVar18 + (ulonglong)uVar21);
        uVar8 = uVar8 - uVar21;
        *puVar1 = uVar8;
      }
      else {
        uVar6 = *(ushort *)((longlong)param_2 + 6);
        if ((uVar6 & 8) != 0) {
          puVar18 = (uint *)0x81ef04;
          if ((*(byte *)((longlong)(int)uVar8 + *(longlong *)(param_3 + 4)) &
              (byte)(1 << ((byte)uVar6 & 7))) == 0) {
            puVar18 = (uint *)0x81f528;
          }
          uVar8 = 1;
          *puVar1 = 1;
          goto LAB_;
        }
        uVar21 = (uint)*(ushort *)(param_2 + 0xe);
        if ((uVar6 & 0x10) != 0) {
          bVar5 = **(byte **)(param_3 + 4);
          if ((bVar5 & 0x10) == 0) {
            if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar18 = *(uint **)(param_2 + 2) + 1;
              uVar8 = **(uint **)(param_2 + 2);
              if ((uVar21 != 0) && (uVar8 != uVar21)) {
                *(undefined8 *)(puVar17 + 0x20) = 0;
                *(undefined8 *)(puVar17 + -8) = 0x10024b;
                (*_DAT_)(1,0xc48238,0xc46c38,0x381);
                *puVar1 = uVar8;
                goto LAB_;
              }
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_3 + 8) <= (int)uVar8) ||
                  (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                   *(ushort *)(param_2 + 1))) goto LAB_;
        }
        puVar18 = (uint *)((longlong)(int)uVar8 + *(longlong *)(param_3 + 4));
        *puVar1 = uVar21;
        uVar8 = uVar21;
      }
    }
    else {
      pbVar20 = *(byte **)(param_3 + 4);
      if ((*pbVar20 & 0x10) == 0) {
        if ((1 << (*pbVar20 & 0xe) & 0x1105U) != 0) goto LAB_;
        bVar4 = true;
LAB_:
        if ((bVar5 & 2) != 0) goto LAB_;
LAB_:
        if ((!bVar4) && ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
          puVar18 = *(uint **)(param_2 + 2) + 1;
          uVar8 = **(uint **)(param_2 + 2);
          *puVar1 = uVar8;
          goto LAB_;
        }
        goto LAB_;
      }
      uVar21 = *(uint *)(param_3 + 8);
      if ((int)uVar21 <= (int)uVar8) {
LAB_:
        uVar21 = ~(uint)(*(ushort *)((longlong)param_2 + 6) >> 4) & 1;
        goto LAB_;
      }
      if ((uint)*(ushort *)(pbVar20 + uVar21) < (uint)*(ushort *)(param_2 + 1)) goto LAB_;
      if ((bVar5 & 2) == 0) goto LAB_;
      uVar12 = *(ushort *)(param_2 + 1) - 1;
      uVar21 = pbVar20[(ulonglong)(uVar12 >> 3) + (ulonglong)uVar21 + 2] >> ((byte)uVar12 & 7) & 1;
      bVar4 = true;
LAB_:
      puVar18 = (uint *)0x0;
      if (uVar21 == 0) goto LAB_;
LAB_:
      uVar8 = 0;
LAB_:
      *puVar1 = uVar8;
    }
  }
  else {
    *(undefined4 *)((longlong)auStackX_1c + lVar9) = 0;
    *(longlong *)(puVar17 + 0x20) = (longlong)auStackX_1c + lVar9;
    *(undefined8 *)(puVar17 + -8) = 0x1009ec;
    puVar18 = (uint *)func_0x(param_3 + 1,param_2);
    if ((((*param_3 != 0) && (plVar2 = *(longlong **)(param_3 + 8), plVar2 != (longlong *)0x0)) &&
        (*plVar2 != 0)) &&
       (((*(byte *)((longlong)param_2 + 6) & 8) == 0 &&
        ((*(uint *)((longlong)auStackX_1c + lVar9) & 1) == 0)))) {
      if ((puVar18 == (uint *)0x0) || (puVar18 == (uint *)0x81ef04)) {
        puVar18 = (uint *)0x0;
        uVar8 = 0;
        *puVar1 = 0;
        goto LAB_;
      }
      *(uint *)(puVar17 + 0x38) = *(uint *)((longlong)auStackX_1c + lVar9);
      *(uint **)(puVar17 + 0x30) = puVar1;
      *(uint *)(puVar17 + 0x28) = uVar8;
      *(uint **)(puVar17 + 0x20) = puVar22;
      uVar8 = *puVar1;
      *(undefined8 *)(puVar17 + -8) = 0x100a46;
      puVar18 = (uint *)func_0x(plVar2,param_2,puVar18,uVar8);
    }
LAB_:
    uVar8 = *puVar1;
  }
LAB_:
  uVar6 = *(ushort *)(param_2 + 0x14);
  if (uVar6 < 0x11) {
    if ((puVar18 == (uint *)0x0) || ((uVar8 == 0x10 && (*(short *)puVar18 == 0))))
    goto LAB_;
  }
  else if (uVar8 <= uVar6) goto LAB_;
  uVar21 = (uint)uVar6;
  if (uVar6 < uVar8) {
    uVar21 = uVar8;
  }
  uVar23 = (ulonglong)uVar21;
  *(undefined8 *)(puVar17 + -8) = 0x100a87;
  iVar7 = func_0x(param_3,param_2);
  if (iVar7 == 0) {
    *(undefined4 *)((longlong)auStackX_1c + lVar9 + 4) = 0x80200;
    uVar23 = (ulonglong)uVar21;
    if (uVar21 < 0x18) {
      uVar23 = 0x18;
    }
  }
  uVar8 = *param_2;
  *(undefined4 *)(&stack0x000000c0 + lVar9) = 0;
  *(undefined2 *)(&stack0x000000c4 + lVar9) = 0;
  uVar21 = *puVar1;
  *(undefined4 *)(puVar17 + 0x40) = 0;
  *(ulonglong *)(puVar17 + 0x38) = uVar23;
  *(undefined4 *)(puVar17 + 0x30) = 2;
  *(undefined4 *)(puVar17 + 0x28) = *(undefined4 *)((longlong)auStackX_1c + lVar9 + 4);
  *(uint *)(puVar17 + 0x20) = uVar8;
  uVar3 = *(undefined8 *)(&stack0x00000028 + lVar9);
  *(undefined8 *)(puVar17 + -8) = 0x100ae3;
  func_0x(&stack0x00000038 + lVar9,uVar3,puVar18,uVar21);
  uVar6 = *(ushort *)((longlong)param_2 + 0x3a);
  uVar23 = (ulonglong)uVar6;
  if (uVar6 == 0x10) {
    *(uint *)(&stack0x00000074 + lVar9) = *(uint *)(&stack0x00000074 + lVar9) & 0xfffff7ff;
    *(undefined8 *)(&stack0x00000130 + lVar9) = 0;
    *(undefined4 *)(&stack0x00000100 + lVar9) = 1;
    *(undefined4 *)(&stack0x00000104 + lVar9) = 0x1f68;
    *(undefined4 *)(&stack0x00000108 + lVar9) = 0x1f5;
LAB_:
    *(undefined4 *)(&stack0x00000110 + lVar9) = 0x40;
    *(undefined4 *)(&stack0x0000010c + lVar9) = 5;
  }
  else {
    *(ulonglong *)(&stack0x00000130 + lVar9) = uVar23;
    bVar5 = *(byte *)(*(longlong *)(&stack0x00000048 + lVar9) + 0x79);
    *(undefined4 *)(&stack0x00000100 + lVar9) = 1;
    *(undefined4 *)(&stack0x00000104 + lVar9) = 0x1f68;
    *(undefined4 *)(&stack0x00000108 + lVar9) = 0x1f5;
    if (uVar6 == 0) goto LAB_;
    if ((bVar5 & 8) == 0) {
      uVar21 = (uint)((uVar23 - 0xc) / 0xc);
      uVar8 = 5;
      if (uVar21 < 5) {
        uVar8 = uVar21;
      }
      *(uint *)(&stack0x0000010c + lVar9) = uVar8;
      *(uint *)(&stack0x00000110 + lVar9) = (uint)uVar6;
    }
    else {
      uVar21 = (uint)((uVar23 - 0xc) / 0xc);
      uVar8 = 0x1f5;
      if (uVar21 < 0x1f5) {
        uVar8 = uVar21;
      }
      *(uint *)(&stack0x0000010c + lVar9) = uVar8;
      *(undefined4 *)(&stack0x00000110 + lVar9) = *(undefined4 *)(&stack0x00000130 + lVar9);
    }
  }
  *(undefined8 *)(puVar17 + -8) = 0x100b36;
  func_0x(&stack0x00000038 + lVar9);
  if ((((*(uint *)(&stack0x00000074 + lVar9) & 0x800) == 0) ||
      (*(int *)(&stack0x00000058 + lVar9) != 0)) || (*(short *)(&stack0x0000005c + lVar9) != 0)) {
    uVar8 = 0x10;
  }
  else {
    lVar14 = *(longlong *)(&stack0x00000088 + lVar9);
    if ((*(byte *)(lVar14 + 0xc) & 0xf) == 0) {
      uVar8 = (uint)*(ushort *)(lVar14 + 0xe);
    }
    else {
      uVar8 = (*(ushort *)(lVar14 + 0x10) + 1) * 0xc;
    }
  }
  if (&stack0x00004076 + lVar9 <= &stack0x000020d8 + (ulonglong)uVar8 + lVar9) {
    *(undefined8 *)(puVar17 + 0x20) = 0;
    *(undefined8 *)(puVar17 + -8) = 0x100c58;
    (*_DAT_)(1,0xc76a60,0xc21b00,0x1f72);
  }
  *(undefined8 *)(puVar17 + -8) = 0x100c6a;
  func_0x(&stack0x00000038 + lVar9,uVar8,&stack0x000020d8 + lVar9);
  *(undefined8 *)(puVar17 + -8) = 0x100c73;
  func_0x(&stack0x00000038 + lVar9);
  *(undefined8 *)(puVar17 + -8) = 0x100c88;
  func_0x(param_3,param_2,&stack0x000020d8 + lVar9,uVar8);
  if (*param_3 == 0) {
    *(undefined8 *)(puVar17 + -8) = 0x100ca2;
    func_0x(param_3 + 1,param_2,1);
  }
  else {
    if (*(int *)(param_3 + 2) == 0) {
      *(undefined8 *)(puVar17 + -8) = 0x100cb4;
      func_0x(param_3 + 1);
    }
    if (*(ushort *)(param_2 + 1) <= (ushort)param_3[1]) {
      uVar6 = param_3[0xf];
      lVar14 = *(longlong *)(param_3 + 4);
      *(undefined8 *)(puVar17 + -8) = 0x100cd5;
      uVar8 = func_0x(param_3 + 1);
      puVar19 = (ushort *)(lVar14 + (ulonglong)uVar6 + 3 + (ulonglong)uVar8 * 2);
      *puVar19 = *puVar19 | 0x8000;
    }
  }
LAB_:
  *(undefined8 *)(puVar17 + -8) = 0x100cee;
  func_0x(&stack0x00000038 + lVar9);
  uVar23 = *(ulonglong *)(&stack0x00004078 + lVar9);
  *(undefined8 *)(puVar17 + -8) = 0x100cfd;
  func_0x(uVar23 ^ (ulonglong)puVar1);
  return;
}

