
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong *param_3,longlong param_4)

{
  undefined8 *puVar1;
  longlong **pplVar2;
  code *pcVar3;
  byte bVar4;
  short sVar5;
  ushort uVar6;
  int iVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong lVar10;
  ulonglong *puVar11;
  ushort uVar12;
  uint uVar13;
  ulonglong uVar14;
  byte *pbVar15;
  longlong lVar16;
  longlong lVar17;
  uint uVar18;
  ulonglong uVar19;
  longlong lVar20;
  undefined8 unaff_RBX;
  undefined *puVar21;
  undefined *puVar22;
  int iVar23;
  longlong **pplVar24;
  longlong **pplVar25;
  undefined *puVar26;
  longlong **pplVar27;
  ushort *puVar28;
  longlong unaff_GS_OFFSET;
  longlong lStackX_8;
  undefined8 uStackX_10;
  uint uStackX_18;
  undefined2 uStackX_1c;
  undefined8 uStackX_1e;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  puVar21 = &stack0xffffffffffffffc8 + lVar8;
  pplVar2 = (longlong **)(&stack0xfffffffffffffff8 + lVar8);
  *(undefined8 *)(&stack0x000000a0 + lVar8) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000020d0 + lVar8) = unaff_RBX;
  *(ulonglong *)(&stack0x00002068 + lVar8) = _DAT_ ^ (ulonglong)pplVar2;
  *pplVar2 = param_2;
  puVar26 = (undefined *)0x0;
  *(undefined8 *)(&stack0x000000c0 + lVar8) = 0;
  *(undefined (*) [16])(&stack0x000000b0 + lVar8) = ZEXT816(0);
  *(undefined8 *)((longlong)&lStackX_8 + lVar8) = 0;
  *(undefined4 *)((longlong)&uStackX_1c + lVar8 + -0x18) = 0;
  *(undefined8 *)((longlong)&uStackX_1c + lVar8 + 2) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar8) = 0;
  *(undefined8 *)((longlong)&uStackX_10 + lVar8) = 0;
  *(undefined4 *)(&stack0x0000004c + lVar8) = 0;
  *(undefined8 *)(&stack0x00000060 + lVar8) = 0;
  *(undefined4 *)(&stack0x00000068 + lVar8) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100099;
  func_0x(&stack0x00000098 + lVar8,param_1,2);
  if (*(int *)(param_1 + 0x150) != 0) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0x19928a8;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1000cd;
    (*_DAT_)(1,0x1992880,0x19669f0,0x25c6);
  }
  if ((*(byte *)(*(longlong *)(param_1 + 0x18) + 0x218) & 2) != 0) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1000fe;
    (*_DAT_)(1,0x1992b70,0x19669f0,0x25c9);
  }
  if (*(int *)(*(longlong *)(param_1 + 0x118) + 0x100) == 2) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100132;
    (*_DAT_)(1,0x1992b48,0x19669f0,0x25ce);
  }
  puVar22 = &stack0xffffffffffffffc8 + lVar8;
  if (param_3 != (longlong *)0x0) {
    puVar1 = (undefined8 *)(param_1 + 0x110);
    if ((*(int *)(param_1 + 0x138) == *(int *)(param_3 + 1)) &&
       (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x124) * 0x10000)) {
      pcVar3 = *(code **)*puVar1;
      *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10016f;
      sVar5 = (*pcVar3)(puVar1);
      if (*(short *)((longlong)param_3 + 0xc) != sVar5) goto LAB_;
      if (param_3[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar8) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar8);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100191;
      func_0x(param_3,puVar1);
    }
    uVar6 = *(ushort *)(param_3 + 7);
    uVar12 = *(ushort *)((longlong)param_3 + 0x62);
    uVar18 = (uint)uVar12;
    if ((uVar6 & 0x400) == 0) {
      *(longlong **)(&stack0x00000038 + lVar8) = param_3;
      *(longlong *)(&stack0x00000050 + lVar8) = param_4;
      *(undefined8 *)(&stack0x00000058 + lVar8) = 0;
      *(undefined4 *)(&stack0x0000004c + lVar8) = 0x10;
      puVar22 = &stack0xffffffffffffffc8 + lVar8;
    }
    else {
      if (uVar12 == 0) {
        iVar7 = 0;
        uVar18 = 0;
        puVar22 = puVar26;
      }
      else {
        iVar7 = (uint)uVar12 * 8;
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1001ea;
        lVar20 = func_0x();
        lVar20 = -lVar20;
        puVar22 = &stack0xfffffffffffffff8 + lVar20 + lVar8;
        *(undefined8 *)((longlong)&uStack_40 + lVar20 + lVar8) = 0x100207;
        lVar10 = func_0x();
        lVar10 = -lVar10;
        puVar21 = &stack0xffffffffffffffc8 + lVar10 + lVar20 + lVar8;
        puVar26 = &stack0xfffffffffffffff8 + lVar10 + lVar20 + lVar8;
        uVar12 = *(ushort *)(param_3 + 0xb);
        uVar19 = (ulonglong)*(uint *)((longlong)param_3 + 0x54);
        if ((*(uint *)((longlong)param_3 + 0x54) < 0x1f9f) ||
           (uVar19 = (ulonglong)uVar12, 0x1f9d < uVar12)) {
          if ((int)uVar19 == 0) goto LAB_;
        }
        else {
          uVar19 = 0x1f9e;
        }
        *(undefined2 **)(&stack0x00000088 + lVar8) = (undefined2 *)(param_1 + 0x268);
        *(longlong *)(param_1 + 0x280) = *(longlong *)(param_1 + 0x278);
        *(ushort *)(param_1 + 0x26a) = -(ushort)(*(longlong *)(param_1 + 0x278) != 0) & 8000;
        *(undefined2 *)(param_1 + 0x268) = 0;
        *(undefined8 *)(param_1 + 0x270) = 0;
        *(undefined4 *)(param_1 + 0x26c) = 0;
        uVar14 = uVar19 + 0xf;
        if (uVar14 <= uVar19) {
          uVar14 = 0xffffffffffffff0;
        }
        uVar14 = uVar14 & 0xfffffffffffffff0;
        *(undefined8 *)((longlong)&uStack_40 + lVar10 + lVar20 + lVar8) = 0x100282;
        func_0x();
        puVar21 = &stack0xffffffffffffffc8 + -uVar14 + lVar10 + lVar20 + lVar8;
        *(undefined **)(param_1 + 0x270) =
             &stack0xfffffffffffffff8 + -uVar14 + lVar10 + lVar20 + lVar8;
        *(ushort *)(param_1 + 0x26c) = (short)uVar19 - uVar12;
        *(ushort *)(param_1 + 0x26e) = uVar12;
        uVar18 = (uint)*(ushort *)((longlong)param_3 + 0x62);
        uVar6 = *(ushort *)(param_3 + 7);
      }
LAB_:
      *(longlong **)(&stack0x00000038 + lVar8) = param_3;
      *(uint *)(&stack0x00000048 + lVar8) = uVar18 & 0xffff;
      *(longlong *)(&stack0x00000050 + lVar8) = param_4;
      *(undefined8 *)(&stack0x00000058 + lVar8) = 0;
      *(undefined8 *)(&stack0x00000090 + lVar8) = 0;
      *(longlong *)(&stack0x00000040 + lVar8) = param_3[0xe];
      if (puVar1 != (undefined8 *)0x0) {
        lVar20 = **(longlong **)(*(longlong *)(param_1 + 0x118) + 0x160);
        *(undefined8 *)(&stack0x00000060 + lVar8) = *(undefined8 *)(lVar20 + 0xa8);
        *(undefined4 *)(&stack0x00000068 + lVar8) = *(undefined4 *)(lVar20 + 0xb0);
      }
      *(undefined4 *)(&stack0x0000004c + lVar8) = 0x10;
      if (((uVar6 & 0x400) != 0) && (param_4 != 0)) {
        *(undefined4 *)(&stack0x0000004c + lVar8) = 0x14;
        *(undefined **)(&stack0x00000070 + lVar8) = puVar22;
        *(int *)(&stack0x00000080 + lVar8) = iVar7;
        *(undefined **)(&stack0x00000078 + lVar8) = puVar26;
        *(int *)(&stack0x00000084 + lVar8) = iVar7;
        if (puVar22 != (undefined *)0x0) {
          *(undefined4 *)(&stack0x0000004c + lVar8) = 0x16;
          *(undefined8 *)(puVar21 + -8) = 0x100354;
          func_0x(&stack0x00000038 + lVar8);
          *(undefined4 *)(&stack0x0000004c + lVar8) = 0x1e;
        }
      }
      param_2 = *pplVar2;
      puVar22 = puVar21;
    }
  }
  pplVar27 = (longlong **)0x0;
  if ((*(byte *)(*(longlong *)(&stack0x00000038 + lVar8) + 0x38) & 0x10) != 0) {
    *(undefined8 *)(puVar22 + 0x20) = 0x1992b28;
    *(undefined8 *)(puVar22 + -8) = 0x100397;
    (*_DAT_)(1,0x1992ae8,0x19669f0,0x25db);
  }
  *(undefined8 *)(puVar22 + -8) = 0x1003a6;
  func_0x(param_2,&stack0x000000a8 + lVar8);
  *(uint *)(param_2 + 2) = *(uint *)(param_2 + 2) & 0xfffffeff;
  if (((*(byte *)(param_2 + 2) & 0x80) == 0) && ((*(byte *)((longlong)param_2 + 0x34) & 1) != 0)) {
    plVar9 = param_2 + 9;
  }
  else {
    *(undefined8 *)(puVar22 + -8) = 0x1003cc;
    plVar9 = (longlong *)func_0x(param_2,1);
  }
  iVar7 = 0;
  if (*(short *)plVar9 == 0) {
    if (*(int *)((longlong)plVar9 + 4) == 0) {
      *(undefined2 *)((longlong)plVar9 + 2) = 0;
      uVar18 = *(uint *)(plVar9 + 2);
      uVar19 = (ulonglong)uVar18;
      *(uint *)((longlong)plVar9 + 0x14) = uVar18;
      pbVar15 = (byte *)plVar9[1];
      bVar4 = *pbVar15;
      if ((bVar4 & 0x10) != 0) {
        uVar18 = uVar18 + 2 + (*(ushort *)(pbVar15 + uVar19) + 7 >> 3);
        uVar19 = (ulonglong)uVar18;
        *(uint *)((longlong)plVar9 + 0x14) = uVar18;
        bVar4 = *pbVar15;
      }
      if ((bVar4 & 0x20) == 0) {
        *(int *)((longlong)plVar9 + 4) = (int)uVar19;
        *(undefined2 *)((longlong)plVar9 + 0x1c) = 0;
        *(int *)(plVar9 + 3) = (int)uVar19;
      }
      else {
        puVar28 = (ushort *)(pbVar15 + uVar19);
        uVar6 = *puVar28;
        *(ushort *)((longlong)plVar9 + 0x1c) = uVar6;
        if (uVar6 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar20 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar20 != 0)) &&
             ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
              (*(char *)(lVar20 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar22 + -8) = 0x1004b4;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x1004da;
              (*_DAT_)(1,0x17e2638,0x1902308,0x80f);
            }
          }
          lVar20 = plVar9[1];
          *(undefined8 *)(puVar22 + -8) = 0x1004e8;
          func_0x(lVar20,3);
          uVar19 = (ulonglong)*(uint *)((longlong)plVar9 + 0x14);
          uVar6 = *(ushort *)((longlong)plVar9 + 0x1c);
        }
        uVar18 = (int)uVar19 + (uVar6 + 1) * 2;
        *(uint *)(plVar9 + 3) = uVar18;
        if (0x1f9e < uVar18) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar20 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar20 != 0 &&
              ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
               (*(char *)(lVar20 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar22 + -8) = 0x100586;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x1005ac;
              (*_DAT_)(1,0x17e2638,0x1902308,0x816);
            }
          }
          lVar20 = plVar9[1];
          *(undefined8 *)(puVar22 + -8) = 0x1005ba;
          func_0x(lVar20,4);
          uVar6 = *(ushort *)((longlong)plVar9 + 0x1c);
          uVar18 = *(uint *)(plVar9 + 3);
        }
        uVar19 = (ulonglong)uVar6;
        uVar6 = puVar28[uVar19];
        *(uint *)((longlong)plVar9 + 4) = uVar6 & 0x7fff;
        if ((uVar6 & 0x7fff) < uVar18) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar20 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar20 != 0)) &&
             ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
              (*(char *)(lVar20 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar22 + -8) = 0x100658;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x10067e;
              (*_DAT_)(1,0x17e2638,0x1902308,0x81d);
            }
          }
          lVar20 = plVar9[1];
          *(undefined8 *)(puVar22 + -8) = 0x10068c;
          func_0x(lVar20,4);
          uVar19 = (ulonglong)*(ushort *)((longlong)plVar9 + 0x1c);
        }
        if ((short)puVar28[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
          lVar20 = plVar9[1];
          do {
            lVar10 = (ulonglong)*(uint *)((longlong)plVar9 + 0x14) + lVar20;
            if ((int)uVar19 == 1) {
              uVar18 = *(uint *)(plVar9 + 3);
              uVar6 = *(ushort *)(lVar10 + uVar19 * 2);
              uVar13 = uVar18;
LAB_:
              if ((uVar6 & 0x7fff) < uVar18) goto LAB_;
            }
            else {
              uVar18 = *(ushort *)(lVar10 + -2 + uVar19 * 2) & 0x7fff;
              uVar13 = *(uint *)(plVar9 + 3);
              uVar6 = *(ushort *)(lVar10 + uVar19 * 2);
              if (uVar13 <= uVar18) goto LAB_;
LAB_:
              *(undefined8 *)(puVar22 + -8) = 0x1006fb;
              func_0x(lVar20,7);
              uVar13 = *(uint *)(plVar9 + 3);
            }
            if ((uVar18 < uVar13) || (*(uint *)((longlong)plVar9 + 4) < uVar18)) goto LAB_;
            lVar20 = plVar9[1];
            if (*(ushort *)(lVar20 + (ulonglong)uVar18) == 5) {
              *(ushort *)((longlong)plVar9 + 2) = *(ushort *)((longlong)plVar9 + 2) | 2;
              *(short *)((longlong)plVar9 + 0x1c) = *(short *)((longlong)plVar9 + 0x1c) + -1;
              *(short *)((longlong)plVar9 + 0x2a) = (short)uVar18;
              lVar20 = (ulonglong)(uVar18 & 0xffff) + plVar9[1];
              uVar6 = *(ushort *)((longlong)plVar9 + 0x2c) & 0xc7ff;
              if ((*(ushort *)(lVar20 + 2) >> 0xe & 1) != 0) {
                uVar6 = *(ushort *)(lVar20 + 2) & 0x3800 | uVar6;
              }
              *(ushort *)((longlong)plVar9 + 0x2c) = uVar6;
              *(ushort *)((longlong)plVar9 + 0x2c) =
                   (uVar6 ^ *(ushort *)(lVar20 + 2)) & 0x7ff ^ uVar6;
              break;
            }
            if (*(ushort *)(lVar20 + (ulonglong)uVar18) < 0x400) break;
            *(ushort *)((longlong)plVar9 + 2) = *(ushort *)((longlong)plVar9 + 2) | 1;
            uVar6 = *(short *)((longlong)plVar9 + 0x1c) - 1;
            *(ushort *)((longlong)plVar9 + 0x1c) = uVar6;
            if ((uVar6 == 0) ||
               (uVar19 = (ulonglong)uVar6, -1 < (short)puVar28[(ulonglong)(uVar6 - 1) + 1])) break;
          } while( true );
        }
        uVar19 = (ulonglong)*(uint *)((longlong)plVar9 + 4);
        pbVar15 = (byte *)plVar9[1];
      }
      if ((*pbVar15 & 0x40) == 0) {
        *(undefined4 *)((longlong)plVar9 + 0x26) = 0;
      }
      else {
        *(int *)((longlong)plVar9 + 0x26) = (int)uVar19;
        *(int *)((longlong)plVar9 + 4) = (int)uVar19 + 0xe;
        *(undefined8 *)(puVar22 + -8) = 0x1007f3;
        puVar11 = (ulonglong *)func_0x((longlong)plVar9 + 2);
        uVar12 = (ushort)(*puVar11 >> 0x30);
        uVar6 = uVar12;
        if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
          uVar6 = uVar12 & 0xdfff;
          if ((uVar12 >> 0xe & 1) != 0) {
            uVar6 = uVar12 | 0x2000;
          }
        }
        iVar23 = iVar7;
        if (uVar6 == 0xfffc) {
          iVar23 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)((longlong)plVar9 + 4) = *(int *)((longlong)plVar9 + 4) + iVar23;
        uVar19 = (ulonglong)*(uint *)((longlong)plVar9 + 4);
      }
      iVar23 = (int)uVar19;
      if ((*(ulonglong *)((longlong)plVar9 + 0x1e) != 0) &&
         (*(ulonglong *)((longlong)plVar9 + 0x1e) < uVar19 + plVar9[1])) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar20 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), lVar20 != 0 && (lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0)) &&
            (*(char *)(lVar20 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar22 + -8) = 0x1008e3;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar22 + 0x20) = 0;
            *(undefined8 *)(puVar22 + -8) = 0x100909;
            (*_DAT_)(1,0x17e2638,0x1902308,0x877);
          }
        }
        lVar20 = plVar9[1];
        *(undefined8 *)(puVar22 + -8) = 0x100917;
        func_0x(lVar20,0x12);
        iVar23 = *(int *)((longlong)plVar9 + 4);
      }
      if (0x3f3b < iVar23 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar20 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar20 != 0 &&
            ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
             (*(char *)(lVar20 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar22 + -8) = 0x1009a2;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            lVar20 = plVar9[1];
            *(undefined8 *)(puVar22 + -8) = 0x1009b0;
            func_0x(lVar20,5);
            goto LAB_;
          }
          *(undefined8 *)(puVar22 + 0x20) = 0;
          *(undefined8 *)(puVar22 + -8) = 0x1009d6;
          (*_DAT_)(1,0x17e2638,0x1902308,0x87c);
        }
        lVar20 = plVar9[1];
        *(undefined8 *)(puVar22 + -8) = 0x1009e4;
        func_0x(lVar20,5);
      }
    }
  }
  else if (*(int *)((longlong)plVar9 + 4) == 0) {
    *(undefined8 *)(puVar22 + -8) = 0x1009f5;
    func_0x((longlong)plVar9 + 2);
  }
LAB_:
  sVar5 = *(short *)plVar9;
  *(short *)((longlong)&uStackX_1c + lVar8 + -0x1c) = sVar5;
  if (sVar5 == 0) {
    if (*(int *)((longlong)plVar9 + 4) == 0) {
      *(undefined2 *)((longlong)plVar9 + 2) = 0;
      uVar18 = *(uint *)(plVar9 + 2);
      uVar19 = (ulonglong)uVar18;
      *(uint *)((longlong)plVar9 + 0x14) = uVar18;
      pbVar15 = (byte *)plVar9[1];
      bVar4 = *pbVar15;
      if ((bVar4 & 0x10) != 0) {
        uVar18 = uVar18 + (*(ushort *)(pbVar15 + uVar19) + 7 >> 3) + 2;
        uVar19 = (ulonglong)uVar18;
        *(uint *)((longlong)plVar9 + 0x14) = uVar18;
        bVar4 = *pbVar15;
      }
      if ((bVar4 & 0x20) == 0) {
        *(int *)((longlong)plVar9 + 4) = (int)uVar19;
        *(undefined2 *)((longlong)plVar9 + 0x1c) = 0;
        *(int *)(plVar9 + 3) = (int)uVar19;
      }
      else {
        puVar28 = (ushort *)(pbVar15 + uVar19);
        uVar6 = *puVar28;
        *(ushort *)((longlong)plVar9 + 0x1c) = uVar6;
        if (uVar6 == 0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar20 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar20 != 0 &&
              ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
               (*(char *)(lVar20 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar22 + -8) = 0x100ae3;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x100b09;
              (*_DAT_)(1,0x17e2638,0x1902308,0x80f);
            }
          }
          lVar20 = plVar9[1];
          *(undefined8 *)(puVar22 + -8) = 0x100b17;
          func_0x(lVar20,3);
          uVar19 = (ulonglong)*(uint *)((longlong)plVar9 + 0x14);
          uVar6 = *(ushort *)((longlong)plVar9 + 0x1c);
        }
        uVar18 = (int)uVar19 + (uVar6 + 1) * 2;
        *(uint *)(plVar9 + 3) = uVar18;
        if (0x1f9e < uVar18) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar20 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar20 != 0)) &&
             ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
              (*(char *)(lVar20 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar22 + -8) = 0x100bb1;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x100bd7;
              (*_DAT_)(1,0x17e2638,0x1902308,0x816);
            }
          }
          lVar20 = plVar9[1];
          *(undefined8 *)(puVar22 + -8) = 0x100be5;
          func_0x(lVar20,4);
          uVar6 = *(ushort *)((longlong)plVar9 + 0x1c);
        }
        uVar19 = (ulonglong)uVar6;
        uVar6 = puVar28[uVar19];
        *(uint *)((longlong)plVar9 + 4) = uVar6 & 0x7fff;
        if ((uVar6 & 0x7fff) < *(uint *)(plVar9 + 3)) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar20 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar20 != 0 &&
              ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
               (*(char *)(lVar20 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar22 + -8) = 0x100c7d;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x100ca3;
              (*_DAT_)(1,0x17e2638,0x1902308,0x81d);
            }
          }
          lVar20 = plVar9[1];
          *(undefined8 *)(puVar22 + -8) = 0x100cb1;
          func_0x(lVar20,4);
          uVar19 = (ulonglong)*(ushort *)((longlong)plVar9 + 0x1c);
        }
        if ((short)puVar28[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
          do {
            lVar20 = plVar9[1];
            lVar10 = (ulonglong)*(uint *)((longlong)plVar9 + 0x14) + lVar20;
            if ((int)uVar19 == 1) {
              uVar18 = *(uint *)(plVar9 + 3);
              uVar6 = *(ushort *)(lVar10 + uVar19 * 2);
              uVar13 = uVar18;
LAB_:
              if ((uVar6 & 0x7fff) < uVar18) goto LAB_;
            }
            else {
              uVar18 = *(ushort *)(lVar10 + -2 + uVar19 * 2) & 0x7fff;
              uVar13 = *(uint *)(plVar9 + 3);
              uVar6 = *(ushort *)(lVar10 + uVar19 * 2);
              if (uVar13 <= uVar18) goto LAB_;
LAB_:
              *(undefined8 *)(puVar22 + -8) = 0x100d21;
              func_0x(lVar20,7);
              uVar13 = *(uint *)(plVar9 + 3);
              lVar20 = plVar9[1];
              uVar19 = (ulonglong)*(ushort *)((longlong)plVar9 + 0x1c);
            }
            if ((uVar18 < uVar13) || (*(uint *)((longlong)plVar9 + 4) < uVar18)) goto LAB_;
            if (*(ushort *)(lVar20 + (ulonglong)uVar18) == 5) {
              *(ushort *)((longlong)plVar9 + 2) = *(ushort *)((longlong)plVar9 + 2) | 2;
              *(short *)((longlong)plVar9 + 0x1c) = (short)uVar19 + -1;
              *(short *)((longlong)plVar9 + 0x2a) = (short)uVar18;
              lVar20 = (ulonglong)(uVar18 & 0xffff) + plVar9[1];
              uVar6 = *(ushort *)((longlong)plVar9 + 0x2c) & 0xc7ff;
              if ((*(ushort *)(lVar20 + 2) >> 0xe & 1) != 0) {
                uVar6 = *(ushort *)(lVar20 + 2) & 0x3800 | uVar6;
              }
              *(ushort *)((longlong)plVar9 + 0x2c) = uVar6;
              *(ushort *)((longlong)plVar9 + 0x2c) =
                   (uVar6 ^ *(ushort *)(lVar20 + 2)) & 0x7ff ^ uVar6;
              goto LAB_;
            }
            if (*(ushort *)(lVar20 + (ulonglong)uVar18) < 0x400) goto LAB_;
            *(ushort *)((longlong)plVar9 + 2) = *(ushort *)((longlong)plVar9 + 2) | 1;
            uVar6 = (short)uVar19 - 1;
            *(ushort *)((longlong)plVar9 + 0x1c) = uVar6;
            if (uVar6 == 0) goto LAB_;
            uVar19 = (ulonglong)uVar6;
          } while ((short)puVar28[(ulonglong)(uVar6 - 1) + 1] < 0);
          uVar19 = (ulonglong)*(uint *)((longlong)plVar9 + 4);
          pbVar15 = (byte *)plVar9[1];
        }
        else {
LAB_:
          uVar19 = (ulonglong)*(uint *)((longlong)plVar9 + 4);
          pbVar15 = (byte *)plVar9[1];
        }
      }
      if ((*pbVar15 & 0x40) == 0) {
        *(undefined4 *)((longlong)plVar9 + 0x26) = 0;
      }
      else {
        *(int *)((longlong)plVar9 + 0x26) = *(int *)((longlong)plVar9 + 4);
        *(int *)((longlong)plVar9 + 4) = *(int *)((longlong)plVar9 + 4) + 0xe;
        *(undefined8 *)(puVar22 + -8) = 0x100e12;
        puVar11 = (ulonglong *)func_0x((longlong)plVar9 + 2);
        uVar12 = (ushort)(*puVar11 >> 0x30);
        uVar6 = uVar12;
        if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
          uVar6 = uVar12 & 0xdfff;
          if ((uVar12 >> 0xe & 1) != 0) {
            uVar6 = uVar12 | 0x2000;
          }
        }
        if (uVar6 == 0xfffc) {
          iVar7 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)((longlong)plVar9 + 4) = *(int *)((longlong)plVar9 + 4) + iVar7;
        uVar19 = (ulonglong)*(uint *)((longlong)plVar9 + 4);
        pbVar15 = (byte *)plVar9[1];
      }
      iVar7 = (int)uVar19;
      if ((*(byte **)((longlong)plVar9 + 0x1e) != (byte *)0x0) &&
         (*(byte **)((longlong)plVar9 + 0x1e) < pbVar15 + uVar19)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar20 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), lVar20 != 0 && (lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0)) &&
            (*(char *)(lVar20 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar22 + -8) = 0x100f11;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar22 + 0x20) = 0;
            *(undefined8 *)(puVar22 + -8) = 0x100f37;
            (*_DAT_)(1,0x17e2638,0x1902308,0x877);
          }
        }
        lVar20 = plVar9[1];
        *(undefined8 *)(puVar22 + -8) = 0x100f45;
        func_0x(lVar20,0x12);
        iVar7 = *(int *)((longlong)plVar9 + 4);
      }
      if (0x3f3b < iVar7 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar20 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar20 != 0 &&
            ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
             (*(char *)(lVar20 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar22 + -8) = 0x100fd0;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(puVar22 + 0x20) = 0;
            *(undefined8 *)(puVar22 + -8) = 0x100ff6;
            (*_DAT_)(1,0x17e2638,0x1902308,0x87c);
          }
        }
        lVar20 = plVar9[1];
        *(undefined8 *)(puVar22 + -8) = 0x101004;
        func_0x(lVar20,5);
      }
    }
LAB_:
    uVar18 = *(uint *)((longlong)plVar9 + 4);
    if ((uVar18 < 9) && (((*(byte *)plVar9[1] & 0xe) == 0 || ((*(byte *)plVar9[1] & 0xe) == 0xc))))
    {
      uVar18 = 9;
    }
    *(undefined4 *)((longlong)&uStackX_10 + lVar8) = *(undefined4 *)(plVar9 + 2);
    *(undefined2 *)((longlong)&uStackX_1c + lVar8 + -0x1a) = *(undefined2 *)((longlong)plVar9 + 2);
    *(undefined4 *)((longlong)&uStackX_1c + lVar8 + -0x18) = *(undefined4 *)((longlong)plVar9 + 4);
    *(undefined2 *)((longlong)&uStackX_1c + lVar8) = *(undefined2 *)((longlong)plVar9 + 0x1c);
    *(undefined4 *)((longlong)&uStackX_10 + lVar8 + 4) = *(undefined4 *)((longlong)plVar9 + 0x14);
    *(undefined4 *)((longlong)&uStackX_18 + lVar8) = *(undefined4 *)(plVar9 + 3);
    *(undefined4 *)(&stack0x00000026 + lVar8) = *(undefined4 *)((longlong)plVar9 + 0x26);
    lVar20 = plVar9[1];
    *(undefined8 *)(puVar22 + -8) = 0x101068;
    func_0x(&stack0x000000c8 + lVar8,0x1f9e,lVar20,uVar18);
    *(undefined **)((longlong)&lStackX_8 + lVar8) = &stack0x000000c8 + lVar8;
    *(undefined8 *)(puVar22 + -8) = 0x10107c;
    iVar7 = func_0x((longlong)&uStackX_1c + lVar8 + -0x1a);
    if (iVar7 != 0) {
      lVar20 = *(longlong *)((longlong)&lStackX_8 + lVar8);
      puVar28 = (ushort *)((ulonglong)*(uint *)((longlong)&uStackX_10 + lVar8 + 4) + lVar20);
      uVar18 = *puVar28 - 1;
      if ((*(byte *)((longlong)&uStackX_1c + lVar8 + -0x1a) & 1) == 0) {
        uVar18 = (uint)*puVar28;
      }
      uVar13 = *(uint *)((longlong)&uStackX_18 + lVar8);
      if (uVar18 != 1) {
        uVar13 = puVar28[(longlong)(int)uVar18 + -1] & 0x7fff;
      }
      if ((uVar13 < *(uint *)((longlong)&uStackX_18 + lVar8)) ||
         ((puVar28[(int)uVar18] & 0x7fff) < uVar13)) {
        *(undefined8 *)(puVar22 + -8) = 0x1010d7;
        func_0x(lVar20,7);
        lVar20 = *(longlong *)((longlong)&lStackX_8 + lVar8);
      }
      *(short *)(&stack0x0000002a + lVar8) = (short)uVar13;
      lVar20 = (ulonglong)(uVar13 & 0xffff) + lVar20;
      uVar6 = *(ushort *)(lVar20 + 2);
      uVar12 = *(ushort *)(&stack0x0000002c + lVar8);
      if ((uVar6 >> 0xe & 1) == 0) {
        uVar12 = uVar12 & 0xc7ff;
      }
      else {
        uVar12 = uVar12 ^ (uVar6 ^ uVar12) & 0x3800;
      }
      *(ushort *)(&stack0x0000002c + lVar8) = uVar12;
      *(ushort *)(&stack0x0000002c + lVar8) = (uVar12 ^ *(ushort *)(lVar20 + 2)) & 0x7ff ^ uVar12;
    }
  }
  else if (((*(short *)plVar9 == 0) || ((longlong *)plVar9[2] == (longlong *)0x0)) ||
          (*(longlong *)plVar9[2] == 0)) {
    *(undefined8 *)(puVar22 + -8) = 0x101174;
    func_0x((longlong)&uStackX_1c + lVar8 + -0x1a,&stack0x000000c8 + lVar8,0x1f9e,
                    (longlong)plVar9 + 2);
    pplVar24 = pplVar27;
    if (*(short *)plVar9 != 0) {
      pplVar24 = (longlong **)plVar9[2];
    }
    *(longlong ***)((longlong)&uStackX_10 + lVar8) = pplVar24;
  }
  else {
    *(undefined8 *)(puVar22 + -8) = 0x101158;
    func_0x((longlong)&uStackX_1c + lVar8 + -0x1c,&stack0x000000c8 + lVar8,0x1f9e,plVar9);
  }
  pcVar3 = *(code **)(*param_2 + 8);
  *(undefined8 *)(puVar22 + -8) = 0x10118e;
  (*pcVar3)(param_2);
  plVar9[1] = 0;
  *plVar9 = 0xffff;
  plVar9[3] = 0;
  plVar9[4] = 0;
  plVar9[2] = 0;
  *(undefined4 *)(plVar9 + 6) = 0;
  plVar9[5] = 0;
  uVar19 = 0;
  lVar20 = *(longlong *)(&stack0x00000038 + lVar8);
  if (*(short *)(lVar20 + 0x62) != 0) {
    do {
      lVar10 = uVar19 * 0x50 + *(longlong *)(lVar20 + 0x70);
      uVar18 = *(uint *)(lVar10 + 0x40);
      if ((uVar18 & 0x400) == 0) {
LAB_:
        if (((uVar18 >> 0xf & 1) == 0) || (((&stack0x0000004c)[lVar8] & 8) == 0)) {
          lVar16 = *(longlong *)(lVar10 + 0x48);
          if ((uVar18 >> 8 & 1) == 0) {
            pplVar25 = (longlong **)(ulonglong)*(ushort *)(lVar16 + 2);
          }
          else {
            lVar17 = *(longlong *)(&stack0x00000050 + lVar8);
            if ((*(byte *)(lVar16 + 0x2a) & 0x10) != 0) {
              lVar17 = *(longlong *)(&stack0x00000058 + lVar8);
            }
            pplVar25 = (longlong **)(ulonglong)*(uint *)(lVar17 + *(longlong *)(lVar16 + 0x18));
          }
        }
        else {
          pplVar25 = (longlong **)
                     (ulonglong)
                     *(uint *)(*(longlong *)(&stack0x00000070 + lVar8) +
                              (ulonglong)*(uint *)(lVar10 + 0x38) * 8);
        }
        if (((uVar18 & 0x48000) == 0x48000) && (((&stack0x0000004c)[lVar8] & 8) != 0)) {
          pplVar24 = (longlong **)
                     *(longlong **)
                      (*(longlong *)(&stack0x00000078 + lVar8) +
                      (ulonglong)*(uint *)(lVar10 + 0x38) * 8);
        }
        else {
          lVar16 = *(longlong *)(&stack0x00000050 + lVar8);
          if ((*(byte *)(*(longlong *)(lVar10 + 0x48) + 0x2a) & 0x10) != 0) {
            lVar16 = *(longlong *)(&stack0x00000058 + lVar8);
          }
          pplVar24 = (longlong **)(lVar16 + *(longlong *)(lVar10 + 0x28));
          if ((uVar18 >> 0xb & 1) != 0) {
            pplVar24 = (longlong **)*pplVar24;
          }
        }
      }
      else {
        lVar16 = *(longlong *)(&stack0x00000050 + lVar8);
        if ((*(byte *)(*(longlong *)(lVar10 + 0x48) + 0x2a) & 0x10) != 0) {
          lVar16 = *(longlong *)(&stack0x00000058 + lVar8);
        }
        pplVar24 = pplVar27;
        pplVar25 = pplVar27;
        if (*(char *)(lVar16 + *(longlong *)(lVar10 + 0x30)) != '\x03') goto LAB_;
      }
      *(undefined8 *)(puVar22 + -8) = 0x10129f;
      func_0x((longlong)&uStackX_1c + lVar8 + -0x1c,lVar10,pplVar24,pplVar25);
      uVar6 = (short)uVar19 + 1;
      uVar19 = (ulonglong)uVar6;
    } while (uVar6 < *(ushort *)(lVar20 + 0x62));
  }
  *(undefined8 *)(puVar22 + -8) = 0x1012bf;
  func_0x(param_2,(longlong)&uStackX_1c + lVar8 + -0x1c,&stack0x000000a8 + lVar8);
  plVar9 = *(longlong **)(&stack0x00000098 + lVar8);
  if (plVar9 != (longlong *)0x0) {
    pcVar3 = *(code **)(*plVar9 + 0xd0);
    *(undefined8 *)(puVar22 + -8) = 0x1012d7;
    (*pcVar3)(plVar9,0);
  }
  uVar19 = *(ulonglong *)(&stack0x00002068 + lVar8);
  *(undefined8 *)(puVar22 + -8) = 0x1012e6;
  func_0x(uVar19 ^ (ulonglong)pplVar2);
  return;
}

