
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,undefined param_3)

{
  short *psVar1;
  ushort *puVar2;
  undefined8 uVar3;
  longlong *plVar4;
  bool bVar5;
  undefined uVar6;
  undefined2 uVar7;
  undefined *puVar8;
  longlong lVar9;
  int iVar10;
  uint *puVar11;
  ulonglong *puVar12;
  byte bVar13;
  uint uVar14;
  ulonglong uVar15;
  byte bVar16;
  uint uVar17;
  longlong lVar18;
  undefined *puVar19;
  ushort uVar20;
  ushort *puVar21;
  uint uVar22;
  ulonglong uVar23;
  int *piVar24;
  ushort uVar25;
  short sVar26;
  byte *pbVar27;
  longlong lVar28;
  longlong lVar29;
  undefined4 uVar30;
  ulonglong uVar31;
  int iVar32;
  longlong unaff_GS_OFFSET;
  undefined auStack_128 [96];
  undefined auStack_c8 [4];
  int iStack_c4;
  uint uStack_c0;
  undefined4 uStack_bc;
  int *piStack_b8;
  undefined2 uStack_b0;
  undefined2 uStack_ae;
  ushort uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined4 uStack_9c;
  undefined *puStack_98;
  byte bStack_90;
  undefined2 uStack_8f;
  undefined uStack_8d;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  undefined4 uStack_80;
  undefined8 uStack_7c;
  undefined4 uStack_74;
  uint uStack_70;
  undefined4 uStack_6c;
  undefined2 uStack_68;
  undefined2 uStack_66;
  longlong lStack_60;
  undefined4 uStack_58;
  undefined2 uStack_54;
  undefined2 uStack_52;
  longlong lStack_50;
  longlong lStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  
  puVar19 = auStack_128;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_c8;
  uVar23 = 0;
  uStack_c0 = 0;
  lStack_50 = *(longlong *)(param_2 + 0x98);
  uStack_bc = (uint)(uStack_bc._2_2_ & 0xffe0) << 0x10;
  piStack_b8 = (int *)0x0;
  lVar29 = *(longlong *)(lStack_50 + 0x80);
  uStack_a8 = 0;
  lVar18 = *(longlong *)(lVar29 + 8);
  puStack_98 = (undefined *)0x0;
  uVar31 = uVar23;
  auStack_c8[0] = param_3;
  lStack_60 = lVar29;
  lStack_48 = param_2;
  uStack_40 = param_1;
  if (*(int *)(lVar18 + 0x100) == 2) {
    if ((*(byte *)(lVar18 + 0x42) & 4) == 0) {
      uVar31 = (ulonglong)*(uint *)(lVar18 + 0xb0);
      if (0x1f9e < *(uint *)(lVar18 + 0xb0)) {
        uVar31 = 0x1f9e;
      }
    }
    else {
      uVar31 = 0x1f9e;
    }
    uStack_a8 = (uint)uVar31;
    uVar15 = uVar31 + 0xf;
    if (uVar15 <= uVar31) {
      uVar15 = 0xffffffffffffff0;
    }
    uVar15 = uVar15 & 0xfffffffffffffff0;
    func_0x();
    puVar19 = auStack_128 + -uVar15;
    puStack_98 = auStack_c8 + -uVar15;
  }
  psVar1 = (short *)(param_2 + 0xa0);
  uVar15 = *(ulonglong *)(param_2 + 0xa8) & 0xffffffffffffe000;
  uStack_9c = *(undefined4 *)(uVar15 + 0x20);
  uStack_b0 = *(undefined2 *)(uVar15 + 0x24);
  uStack_ae = *(undefined2 *)(param_2 + 0xd4);
  pbVar27 = *(byte **)(param_2 + 0xa8);
  if (*psVar1 == 0) {
    bVar16 = *pbVar27 & 0xe;
    lVar18 = lStack_48;
    if (bVar16 == 2) {
      bVar5 = false;
      if ((pbVar27[1] & 1) != 0) {
        bVar5 = true;
      }
    }
    else {
      bVar5 = false;
      if (((bVar16 - 10 & 0xf9) == 0) && (bVar5 = false, bVar16 != 0x10)) {
        bVar5 = true;
      }
    }
  }
  else {
    lVar18 = param_2;
    bVar5 = ((*pbVar27 & 0x1c) - 4 & 0xffffffe7) == 0;
  }
  if (!bVar5) {
    puVar2 = (ushort *)(lVar18 + 0xa2);
    if (*psVar1 == 0) {
      *(undefined8 *)(puVar19 + -8) = 0x100186;
      uStack_a4 = func_0x(puVar2);
      lVar29 = lStack_60;
    }
    else {
      uStack_a4 = (uint)*puVar2;
    }
    if (0 < (int)uStack_a4) {
      do {
        puVar11 = (uint *)0x0;
        uVar20 = ~(ushort)uVar23;
        uVar22 = (uint)(short)uVar20;
        uStack_ac = uVar20;
        if (-1 < (short)(ushort)uVar23) {
          if ((uVar22 & 0xc0000000) == 0x80000000) {
            uVar3 = **(undefined8 **)(*(longlong *)(lVar29 + 8) + 0x160);
            *(undefined8 *)(puVar19 + -8) = 0x1001f2;
            puVar11 = (uint *)func_0x(uVar3,uVar22 & 0x1fffffff);
          }
          else {
            uVar3 = *(undefined8 *)(*(longlong *)(lVar29 + 8) + 0x160);
            *(undefined8 *)(puVar19 + -8) = 0x1001d7;
            puVar11 = (uint *)func_0x(uVar3);
          }
        }
        lVar29 = lStack_60;
        uVar30 = 0;
        if (puVar11 == (uint *)0x0) {
          *(undefined8 *)(puVar19 + -8) = 0x10020d;
          func_0x(lVar29,uVar22,&uStack_c0);
        }
        else {
          uStack_c0 = *puVar11;
          uStack_bc = puVar11[1];
          piStack_b8 = *(int **)(puVar11 + 2);
          if ((((*(int *)(lStack_50 + 0x328) == 3) && (uVar25 = 0, DAT_ != '\0')) &&
              ((DAT_ & 0x10) == 0)) && ((DAT_ != '\0' && ((DAT_ & 1) == 0)))
             ) {
            uStack_8f = 0;
            uStack_8d = 0;
            uStack_7c = 0;
            bStack_90 = 0;
            uStack_8c = 0;
            uStack_88 = 0xffffffffffffffff;
            uStack_80 = 0;
            uStack_74 = 0;
            *(undefined8 *)(puVar19 + -8) = 0x100317;
            func_0x(puVar11,&bStack_90);
            if (((short)uStack_80 == -1) ||
               (*(char *)((ulonglong)*(byte *)((ulonglong)bStack_90 + 0xade3e0) + 0x1493a58) != '\0'
               )) {
              if (*psVar1 == 0) {
                pbVar27 = *(byte **)(param_2 + 0xa8);
                if ((*pbVar27 & 0x10) == 0) {
                  if ((1 << (*pbVar27 & 0xe) & 0x1105U) != 0) {
LAB_:
                    uVar25 = ~(uStack_bc._2_2_ >> 4) & 1;
                  }
                }
                else {
                  uVar22 = *(uint *)(param_2 + 0xb0);
                  if ((int)uStack_c0 < (int)uVar22) {
                    if ((uint)*(ushort *)(pbVar27 + uVar22) < (uStack_bc & 0xffff))
                    goto LAB_;
                    uVar17 = (uStack_bc & 0xffff) - 1;
                    uVar25 = pbVar27[(ulonglong)(uVar17 >> 3) + (ulonglong)uVar22 + 2] >>
                             ((byte)uVar17 & 7) & 1;
                  }
                  else {
                    uVar25 = ~(uStack_bc._2_2_ >> 4) & 1;
                  }
                }
              }
              else if (*(ushort *)(param_2 + 0xa2) < (ushort)uStack_bc) {
                uVar25 = ~(uStack_bc._2_2_ >> 4) & 1;
              }
              else {
                bVar16 = *(byte *)((longlong)((int)((uStack_bc & 0xffff) - 1) / 2) +
                                   (ulonglong)*(ushort *)(param_2 + 0xb8) +
                                  *(longlong *)(param_2 + 0xa8));
                bVar13 = bVar16 >> 4;
                if ((uStack_bc & 1) != 0) {
                  bVar13 = bVar16 & 0xf;
                }
                uVar25 = (ushort)(bVar13 == 0);
              }
              if (uVar25 == 0) {
                uVar30 = 1;
              }
            }
          }
        }
        piVar24 = (int *)0x0;
        *(undefined8 *)(puVar19 + -8) = 0x10021b;
        iVar10 = func_0x(psVar1,&uStack_c0);
        if ((iVar10 != 0) || ((char)uVar30 != '\0')) {
          if (*psVar1 == 0) {
            if ((uStack_c0 & 0xc0000000) == 0x80000000) {
              *(undefined8 *)(puVar19 + -8) = 0x100c01;
              iVar10 = func_0x(puVar2);
              if (iVar10 == 0) {
                iStack_c4 = 0;
                iVar10 = iStack_c4;
              }
              else {
                *(undefined8 *)(puVar19 + -8) = 0x100c1a;
                piVar24 = (int *)func_0x(lVar18 + 0xca,&uStack_c0,&iStack_c4,&uStack_70);
                iVar10 = iStack_c4;
              }
            }
            else {
              uVar25 = uStack_bc._2_2_ >> 4 & 1;
              uVar20 = uStack_ac;
              if (uVar25 != 0) {
                bVar16 = **(byte **)(lVar18 + 0xa8);
                if ((bVar16 & 0x10) == 0) {
                  if ((1 << (bVar16 & 0xe) & 0x1105U) != 0) {
                    piVar24 = piStack_b8 + 1;
                    iVar10 = *piStack_b8;
                    goto LAB_;
                  }
                  goto LAB_;
                }
                if (((int)uStack_c0 < (int)*(uint *)(lVar18 + 0xb0)) &&
                   ((ushort)uStack_bc <=
                    *(ushort *)(*(byte **)(lVar18 + 0xa8) + *(uint *)(lVar18 + 0xb0))))
                goto LAB_;
                goto LAB_;
              }
LAB_:
              if ((int)uStack_c0 < 0) {
                if (*(int *)(lVar18 + 0xa4) == 0) {
                  pbVar27 = *(byte **)(lVar18 + 0xa8);
                  uVar22 = *(uint *)(lVar18 + 0xb0);
                  uVar31 = (ulonglong)uVar22;
                  *puVar2 = 0;
                  *(uint *)(lVar18 + 0xb4) = uVar22;
                  bVar16 = *pbVar27;
                  if ((bVar16 & 0x10) != 0) {
                    uVar22 = uVar22 + 2 + (*(ushort *)(pbVar27 + uVar31) + 7 >> 3);
                    uVar31 = (ulonglong)uVar22;
                    *(uint *)(lVar18 + 0xb4) = uVar22;
                    bVar16 = *pbVar27;
                  }
                  if ((bVar16 & 0x20) == 0) {
                    *(int *)(lVar18 + 0xa4) = (int)uVar31;
                    *(undefined2 *)(lVar18 + 0xbc) = 0;
                    *(int *)(lVar18 + 0xb8) = (int)uVar31;
                  }
                  else {
                    puVar21 = (ushort *)(pbVar27 + uVar31);
                    uVar20 = *puVar21;
                    *(ushort *)(lVar18 + 0xbc) = uVar20;
                    if (uVar20 == 0) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar29 = *(longlong *)
                                     (*(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8 +
                                     (ulonglong)*_DAT_), lVar29 != 0)) &&
                         ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
                          (*(char *)(lVar29 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar19 + -8) = 0x100609;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar19 + 0x20) = 0;
                          *(undefined8 *)(puVar19 + -8) = 0x10062d;
                          (*_DAT_)(1,0xd59508,0xe791d8,0x80f);
                        }
                      }
                      uVar3 = *(undefined8 *)(lVar18 + 0xa8);
                      *(undefined8 *)(puVar19 + -8) = 0x10063b;
                      func_0x(uVar3,3);
                      uVar31 = (ulonglong)*(uint *)(lVar18 + 0xb4);
                      uVar20 = *(ushort *)(lVar18 + 0xbc);
                    }
                    uVar22 = (int)uVar31 + (uVar20 + 1) * 2;
                    *(uint *)(lVar18 + 0xb8) = uVar22;
                    if (0x1f9e < uVar22) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar29 = *(longlong *)
                                     (*(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8 +
                                     (ulonglong)*_DAT_), lVar29 != 0 &&
                          ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
                           (*(char *)(lVar29 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar19 + -8) = 0x1006da;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar19 + 0x20) = 0;
                          *(undefined8 *)(puVar19 + -8) = 0x1006fe;
                          (*_DAT_)(1,0xd59508,0xe791d8,0x816);
                        }
                      }
                      uVar3 = *(undefined8 *)(lVar18 + 0xa8);
                      *(undefined8 *)(puVar19 + -8) = 0x10070c;
                      func_0x(uVar3,4);
                      uVar20 = *(ushort *)(lVar18 + 0xbc);
                      uVar22 = *(uint *)(lVar18 + 0xb8);
                    }
                    uVar31 = (ulonglong)uVar20;
                    uVar20 = puVar21[uVar31];
                    *(uint *)(lVar18 + 0xa4) = uVar20 & 0x7fff;
                    if ((uVar20 & 0x7fff) < uVar22) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar29 = *(longlong *)
                                     (*(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8 +
                                     (ulonglong)*_DAT_), lVar29 != 0)) &&
                         ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
                          (*(char *)(lVar29 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar19 + -8) = 0x1007aa;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar19 + 0x20) = 0;
                          *(undefined8 *)(puVar19 + -8) = 0x1007ce;
                          (*_DAT_)(1,0xd59508,0xe791d8,0x81d);
                        }
                      }
                      uVar3 = *(undefined8 *)(lVar18 + 0xa8);
                      *(undefined8 *)(puVar19 + -8) = 0x1007dc;
                      func_0x(uVar3,4);
                      uVar31 = (ulonglong)*(ushort *)(lVar18 + 0xbc);
                    }
                    if ((short)puVar21[(ulonglong)((int)uVar31 - 1) + 1] < 0) {
                      pbVar27 = *(byte **)(lVar18 + 0xa8);
                      do {
                        if ((int)uVar31 == 1) {
                          uVar22 = *(uint *)(lVar18 + 0xb8);
                          uVar17 = uVar22;
LAB_:
                          if ((*(ushort *)
                                (pbVar27 + uVar31 * 2 + (ulonglong)*(uint *)(lVar18 + 0xb4)) &
                              0x7fff) < uVar22) goto LAB_;
                        }
                        else {
                          uVar17 = *(uint *)(lVar18 + 0xb8);
                          uVar22 = *(ushort *)
                                    (pbVar27 +
                                    uVar31 * 2 + ((ulonglong)*(uint *)(lVar18 + 0xb4) - 2)) & 0x7fff
                          ;
                          if (uVar17 <= uVar22) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar19 + -8) = 0x100842;
                          func_0x(pbVar27,7);
                          uVar17 = *(uint *)(lVar18 + 0xb8);
                        }
                        if ((uVar22 < uVar17) || (*(uint *)(lVar18 + 0xa4) < uVar22))
                        goto LAB_;
                        pbVar27 = *(byte **)(lVar18 + 0xa8);
                        if (*(ushort *)(pbVar27 + uVar22) == 5) {
                          *puVar2 = *puVar2 | 2;
                          *(short *)(lVar18 + 0xbc) = *(short *)(lVar18 + 0xbc) + -1;
                          uVar20 = *(ushort *)(lVar18 + 0xcc) & 0xc7ff;
                          *(short *)(lVar18 + 0xca) = (short)uVar22;
                          lVar29 = (ulonglong)(uVar22 & 0xffff) + *(longlong *)(lVar18 + 0xa8);
                          if ((*(ushort *)(lVar29 + 2) >> 0xe & 1) != 0) {
                            uVar20 = *(ushort *)(lVar29 + 2) & 0x3800 | uVar20;
                          }
                          *(ushort *)(lVar18 + 0xcc) = uVar20;
                          *(ushort *)(lVar18 + 0xcc) =
                               (uVar20 ^ *(ushort *)(lVar29 + 2)) & 0x7ff ^ uVar20;
                          goto LAB_;
                        }
                        if (*(ushort *)(pbVar27 + uVar22) < 0x400) goto LAB_;
                        *puVar2 = *puVar2 | 1;
                        uVar20 = *(short *)(lVar18 + 0xbc) - 1;
                        *(ushort *)(lVar18 + 0xbc) = uVar20;
                        if (uVar20 == 0) goto LAB_;
                        uVar31 = (ulonglong)uVar20;
                      } while ((short)puVar21[(ulonglong)(uVar20 - 1) + 1] < 0);
                      uVar31 = (ulonglong)*(uint *)(lVar18 + 0xa4);
                    }
                    else {
LAB_:
                      uVar31 = (ulonglong)*(uint *)(lVar18 + 0xa4);
                      pbVar27 = *(byte **)(lVar18 + 0xa8);
                    }
                  }
                  iVar10 = 0;
                  if ((*pbVar27 & 0x40) == 0) {
                    *(undefined4 *)(lVar18 + 0xc6) = 0;
                  }
                  else {
                    *(int *)(lVar18 + 0xc6) = (int)uVar31;
                    *(int *)(lVar18 + 0xa4) = (int)uVar31 + 0xe;
                    *(undefined8 *)(puVar19 + -8) = 0x100932;
                    puVar12 = (ulonglong *)func_0x(puVar2);
                    uVar25 = (ushort)(*puVar12 >> 0x30);
                    uVar20 = uVar25;
                    if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
                      uVar20 = uVar25 & 0xdfff;
                      if ((uVar25 >> 0xe & 1) != 0) {
                        uVar20 = uVar25 | 0x2000;
                      }
                    }
                    if (uVar20 == 0xfffc) {
                      iVar10 = (int)((*puVar12 >> 0x20 & 0xffff) >> 5);
                    }
                    *(int *)(lVar18 + 0xa4) = *(int *)(lVar18 + 0xa4) + iVar10;
                    uVar31 = (ulonglong)*(uint *)(lVar18 + 0xa4);
                  }
                  iVar10 = (int)uVar31;
                  if ((*(ulonglong *)(lVar18 + 0xbe) != 0) &&
                     (*(ulonglong *)(lVar18 + 0xbe) < uVar31 + *(longlong *)(lVar18 + 0xa8))) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       (((lVar29 = *(longlong *)
                                    (*(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_
                                    ), lVar29 != 0 &&
                         (lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0)) &&
                        (*(char *)(lVar29 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar19 + -8) = 0x100a2e;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar19 + 0x20) = 0;
                        *(undefined8 *)(puVar19 + -8) = 0x100a52;
                        (*_DAT_)(1,0xd59508,0xe791d8,0x877);
                      }
                    }
                    uVar3 = *(undefined8 *)(lVar18 + 0xa8);
                    *(undefined8 *)(puVar19 + -8) = 0x100a60;
                    func_0x(uVar3,0x12);
                    iVar10 = *(int *)(lVar18 + 0xa4);
                  }
                  if (0x3f3b < iVar10 - 1U) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar29 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar29 != 0 &&
                        ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
                         (*(char *)(lVar29 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar19 + -8) = 0x100aec;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar19 + 0x20) = 0;
                        *(undefined8 *)(puVar19 + -8) = 0x100b10;
                        (*_DAT_)(1,0xd59508,0xe791d8,0x87c);
                      }
                    }
                    uVar3 = *(undefined8 *)(lVar18 + 0xa8);
                    *(undefined8 *)(puVar19 + -8) = 0x100b1e;
                    func_0x(uVar3,5);
                  }
                }
LAB_:
                sVar26 = -(short)uStack_c0;
                uVar20 = uStack_ac;
                if ((uStack_bc & 0x100000) != 0) {
                  bVar16 = **(byte **)(lVar18 + 0xa8);
                  if ((bVar16 & 0x10) == 0) {
                    if ((1 << (bVar16 & 0xe) & 0x1105U) != 0) {
LAB_:
                      piVar24 = piStack_b8 + 1;
                      uVar20 = uStack_ac;
                      iVar10 = *piStack_b8;
                      goto LAB_;
                    }
                  }
                  else {
                    if ((int)*(uint *)(lVar18 + 0xb0) <= (int)uStack_c0) goto LAB_;
                    if (*(ushort *)(*(byte **)(lVar18 + 0xa8) + *(uint *)(lVar18 + 0xb0)) <
                        (ushort)uStack_bc) {
                      piVar24 = piStack_b8 + 1;
                      iVar10 = *piStack_b8;
                      goto LAB_;
                    }
                  }
                }
                piVar24 = *(int **)(lVar18 + 0xa8);
                if ((uint)*(ushort *)(lVar18 + 0xbc) < (uint)(int)sVar26) {
                  iVar10 = 0;
                }
                else {
                  uVar22 = *(ushort *)
                            ((longlong)piVar24 +
                            (longlong)sVar26 * 2 + (ulonglong)*(uint *)(lVar18 + 0xb4)) & 0x7fff;
                  if (sVar26 == 1) {
                    uVar17 = *(uint *)(lVar18 + 0xb8);
LAB_:
                    if (uVar22 < uVar17) goto LAB_;
                  }
                  else {
                    uVar17 = *(ushort *)
                              ((longlong)piVar24 +
                              (longlong)sVar26 * 2 + ((ulonglong)*(uint *)(lVar18 + 0xb4) - 2)) &
                             0x7fff;
                    if (*(uint *)(lVar18 + 0xb8) <= uVar17) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar19 + -8) = 0x100bd0;
                    func_0x(piVar24,7);
                    piVar24 = *(int **)(lVar18 + 0xa8);
                  }
                  piVar24 = (int *)((longlong)piVar24 + (ulonglong)uVar17);
                  uVar20 = uStack_ac;
                  iVar10 = uVar22 - uVar17;
                }
              }
              else {
                if ((uStack_bc & 0x80000) != 0) {
                  piVar24 = (int *)0xaddf44;
                  iStack_c4 = 1;
                  iVar10 = iStack_c4;
                  if ((*(byte *)((longlong)(int)uStack_c0 + *(longlong *)(lVar18 + 0xa8)) &
                      (byte)(1 << (uStack_bc._2_1_ & 7))) == 0) {
                    piVar24 = (int *)0xade568;
                  }
                  goto LAB_;
                }
                if (uVar25 != 0) {
                  bVar16 = **(byte **)(lVar18 + 0xa8);
                  if ((bVar16 & 0x10) == 0) {
                    if ((1 << (bVar16 & 0xe) & 0x1105U) != 0) {
LAB_:
                      iVar10 = *piStack_b8;
                      piVar24 = piStack_b8 + 1;
                      if (iVar10 != 0x1f9e) {
                        *(undefined8 *)(puVar19 + 0x20) = 0;
                        *(undefined8 *)(puVar19 + -8) = 0x1004f7;
                        (*_DAT_)(1,0xf07278,0xf05c78,0x381);
                        uVar20 = uStack_ac;
                      }
                      goto LAB_;
                    }
                  }
                  else if (((int)*(uint *)(lVar18 + 0xb0) <= (int)uStack_c0) ||
                          (*(ushort *)(*(byte **)(lVar18 + 0xa8) + *(uint *)(lVar18 + 0xb0)) <
                           (ushort)uStack_bc)) goto LAB_;
                }
                piVar24 = (int *)((longlong)(int)uStack_c0 + *(longlong *)(lVar18 + 0xa8));
                iStack_c4 = 0x1f9e;
                iVar10 = iStack_c4;
              }
            }
          }
          else {
            uStack_a0 = 0;
            *(uint **)(puVar19 + 0x20) = &uStack_a0;
            *(undefined8 *)(puVar19 + -8) = 0x100c43;
            piVar24 = (int *)func_0x(puVar2,&uStack_c0);
            iVar10 = iStack_c4;
            if ((((*psVar1 != 0) &&
                 (plVar4 = *(longlong **)(param_2 + 0xb0), plVar4 != (longlong *)0x0)) &&
                (*plVar4 != 0)) && (((uStack_bc & 0x80000) == 0 && ((uStack_a0 & 1) == 0)))) {
              if ((piVar24 == (int *)0x0) || (piVar24 == (int *)0xaddf44)) {
                piVar24 = (int *)0x0;
                iStack_c4 = 0;
                iVar10 = iStack_c4;
              }
              else {
                *(uint *)(puVar19 + 0x38) = uStack_a0;
                *(int **)(puVar19 + 0x30) = &iStack_c4;
                puVar8 = puStack_98;
                *(int *)(puVar19 + 0x28) = (int)uVar31;
                *(undefined **)(puVar19 + 0x20) = puVar8;
                *(undefined8 *)(puVar19 + -8) = 0x100ca5;
                piVar24 = (int *)func_0x(plVar4,&uStack_c0,piVar24,iVar10);
                iVar10 = iStack_c4;
              }
            }
          }
LAB_:
          iStack_c4 = iVar10;
          uVar3 = uStack_40;
          lVar28 = lStack_48;
          lVar29 = lStack_50;
          uVar6 = auStack_c8[0];
          uStack_6c = uStack_9c;
          uStack_68 = uStack_b0;
          uStack_66 = uStack_ae;
          *(undefined4 *)(puVar19 + 0x50) = uVar30;
          *(ushort *)(puVar19 + 0x48) = uVar20;
          *(undefined4 *)(puVar19 + 0x40) = 0;
          iVar10 = iStack_c4;
          *(int *)(puVar19 + 0x38) = (int)uVar23;
          *(int **)(puVar19 + 0x30) = piVar24;
          *(int *)(puVar19 + 0x28) = iVar10;
          *(undefined4 **)(puVar19 + 0x20) = &uStack_6c;
          *(undefined8 *)(puVar19 + -8) = 0x100d0e;
          iVar10 = func_0x(uVar3,lVar28,uVar6,lVar29);
          if (iVar10 == 0) goto LAB_;
        }
        uVar31 = (ulonglong)uStack_a8;
        uVar22 = (int)uVar23 + 1;
        uVar23 = (ulonglong)uVar22;
        lVar29 = lStack_60;
      } while ((int)uVar22 < (int)uStack_a4);
    }
    uVar31 = 0;
    *(undefined8 *)(puVar19 + -8) = 0x100d35;
    iVar10 = func_0x(psVar1);
    if (0 < iVar10) {
      *(undefined8 *)(puVar19 + -8) = 0x100d48;
      iVar10 = func_0x(psVar1);
      if (0 < iVar10) {
        puStack_98 = (undefined *)(longlong)iVar10;
        uVar23 = uVar31;
        uVar22 = uStack_70;
        do {
          lVar29 = 0;
          if (*(int *)(lVar18 + 0xa4) == 0) {
            pbVar27 = *(byte **)(lVar18 + 0xa8);
            uVar17 = *(uint *)(lVar18 + 0xb0);
            uVar15 = (ulonglong)uVar17;
            *puVar2 = 0;
            *(uint *)(lVar18 + 0xb4) = uVar17;
            bVar16 = *pbVar27;
            if ((bVar16 & 0x10) != 0) {
              uVar17 = uVar17 + 2 + (*(ushort *)(pbVar27 + uVar15) + 7 >> 3);
              uVar15 = (ulonglong)uVar17;
              *(uint *)(lVar18 + 0xb4) = uVar17;
              bVar16 = *pbVar27;
            }
            if ((bVar16 & 0x20) == 0) {
              *(int *)(lVar18 + 0xa4) = (int)uVar15;
              *(undefined2 *)(lVar18 + 0xbc) = 0;
              *(int *)(lVar18 + 0xb8) = (int)uVar15;
            }
            else {
              puVar21 = (ushort *)(pbVar27 + uVar15);
              uVar20 = *puVar21;
              *(ushort *)(lVar18 + 0xbc) = uVar20;
              if (uVar20 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar28 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar28 != 0)) &&
                   ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                    (*(char *)(lVar28 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar19 + -8) = 0x100e40;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar19 + 0x20) = 0;
                    *(undefined8 *)(puVar19 + -8) = 0x100e66;
                    (*_DAT_)(1,0xd59508,0xe791d8,0x80f);
                  }
                }
                uVar3 = *(undefined8 *)(lVar18 + 0xa8);
                *(undefined8 *)(puVar19 + -8) = 0x100e74;
                func_0x(uVar3,3);
                uVar15 = (ulonglong)*(uint *)(lVar18 + 0xb4);
                uVar20 = *(ushort *)(lVar18 + 0xbc);
              }
              uVar17 = (int)uVar15 + (uVar20 + 1) * 2;
              *(uint *)(lVar18 + 0xb8) = uVar17;
              if (0x1f9e < uVar17) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar28 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar28 != 0 &&
                    ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                     (*(char *)(lVar28 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar19 + -8) = 0x100f13;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar19 + 0x20) = 0;
                    *(undefined8 *)(puVar19 + -8) = 0x100f39;
                    (*_DAT_)(1,0xd59508,0xe791d8,0x816);
                  }
                }
                uVar3 = *(undefined8 *)(lVar18 + 0xa8);
                *(undefined8 *)(puVar19 + -8) = 0x100f47;
                func_0x(uVar3,4);
                uVar20 = *(ushort *)(lVar18 + 0xbc);
                uVar17 = *(uint *)(lVar18 + 0xb8);
              }
              uVar15 = (ulonglong)uVar20;
              uVar20 = puVar21[uVar15];
              *(uint *)(lVar18 + 0xa4) = uVar20 & 0x7fff;
              if ((uVar20 & 0x7fff) < uVar17) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar28 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar28 != 0)) &&
                   ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                    (*(char *)(lVar28 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar19 + -8) = 0x100fe5;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar19 + 0x20) = 0;
                    *(undefined8 *)(puVar19 + -8) = 0x10100b;
                    (*_DAT_)(1,0xd59508,0xe791d8,0x81d);
                  }
                }
                uVar3 = *(undefined8 *)(lVar18 + 0xa8);
                *(undefined8 *)(puVar19 + -8) = 0x101019;
                func_0x(uVar3,4);
                uVar15 = (ulonglong)*(ushort *)(lVar18 + 0xbc);
              }
              if ((short)puVar21[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                pbVar27 = *(byte **)(lVar18 + 0xa8);
                do {
                  if ((int)uVar15 == 1) {
                    uVar17 = *(uint *)(lVar18 + 0xb8);
                    uVar14 = uVar17;
LAB_:
                    if ((*(ushort *)(pbVar27 + uVar15 * 2 + (ulonglong)*(uint *)(lVar18 + 0xb4)) &
                        0x7fff) < uVar17) goto LAB_;
                  }
                  else {
                    uVar14 = *(uint *)(lVar18 + 0xb8);
                    uVar17 = *(ushort *)
                              (pbVar27 + uVar15 * 2 + ((ulonglong)*(uint *)(lVar18 + 0xb4) - 2)) &
                             0x7fff;
                    if (uVar14 <= uVar17) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar19 + -8) = 0x101082;
                    func_0x(pbVar27,7);
                    uVar14 = *(uint *)(lVar18 + 0xb8);
                  }
                  if ((uVar17 < uVar14) || (*(uint *)(lVar18 + 0xa4) < uVar17)) goto LAB_;
                  pbVar27 = *(byte **)(lVar18 + 0xa8);
                  if (*(ushort *)(pbVar27 + uVar17) == 5) {
                    *puVar2 = *puVar2 | 2;
                    *(short *)(lVar18 + 0xbc) = *(short *)(lVar18 + 0xbc) + -1;
                    uVar20 = *(ushort *)(lVar18 + 0xcc) & 0xc7ff;
                    *(short *)(lVar18 + 0xca) = (short)uVar17;
                    lVar28 = (ulonglong)(uVar17 & 0xffff) + *(longlong *)(lVar18 + 0xa8);
                    if ((*(ushort *)(lVar28 + 2) >> 0xe & 1) != 0) {
                      uVar20 = *(ushort *)(lVar28 + 2) & 0x3800 | uVar20;
                    }
                    *(ushort *)(lVar18 + 0xcc) = uVar20;
                    *(ushort *)(lVar18 + 0xcc) = (uVar20 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar20
                    ;
                    goto LAB_;
                  }
                  if (*(ushort *)(pbVar27 + uVar17) < 0x400) goto LAB_;
                  *puVar2 = *puVar2 | 1;
                  uVar20 = *(short *)(lVar18 + 0xbc) - 1;
                  *(ushort *)(lVar18 + 0xbc) = uVar20;
                  if (uVar20 == 0) goto LAB_;
                  uVar15 = (ulonglong)uVar20;
                } while ((short)puVar21[(ulonglong)(uVar20 - 1) + 1] < 0);
                uVar15 = (ulonglong)*(uint *)(lVar18 + 0xa4);
              }
              else {
LAB_:
                uVar15 = (ulonglong)*(uint *)(lVar18 + 0xa4);
                pbVar27 = *(byte **)(lVar18 + 0xa8);
              }
            }
            iVar10 = 0;
            if ((*pbVar27 & 0x40) == 0) {
              *(undefined4 *)(lVar18 + 0xc6) = 0;
            }
            else {
              *(int *)(lVar18 + 0xc6) = (int)uVar15;
              *(int *)(lVar18 + 0xa4) = (int)uVar15 + 0xe;
              *(undefined8 *)(puVar19 + -8) = 0x101172;
              puVar12 = (ulonglong *)func_0x(puVar2);
              uVar25 = (ushort)(*puVar12 >> 0x30);
              uVar20 = uVar25;
              if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
                uVar20 = uVar25 & 0xdfff;
                if ((uVar25 >> 0xe & 1) != 0) {
                  uVar20 = uVar25 | 0x2000;
                }
              }
              if (uVar20 == 0xfffc) {
                iVar10 = (int)((*puVar12 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(lVar18 + 0xa4) = *(int *)(lVar18 + 0xa4) + iVar10;
              uVar15 = (ulonglong)*(uint *)(lVar18 + 0xa4);
            }
            iVar10 = (int)uVar15;
            if ((*(ulonglong *)(lVar18 + 0xbe) != 0) &&
               (*(ulonglong *)(lVar18 + 0xbe) < uVar15 + *(longlong *)(lVar18 + 0xa8))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar28 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                   lVar28 != 0 && (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                  (*(char *)(lVar28 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar19 + -8) = 0x10126e;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar19 + 0x20) = 0;
                  *(undefined8 *)(puVar19 + -8) = 0x101294;
                  (*_DAT_)(1,0xd59508,0xe791d8,0x877);
                }
              }
              uVar3 = *(undefined8 *)(lVar18 + 0xa8);
              *(undefined8 *)(puVar19 + -8) = 0x1012a2;
              func_0x(uVar3,0x12);
              iVar10 = *(int *)(lVar18 + 0xa4);
            }
            if (0x3f3b < iVar10 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar28 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar28 != 0 &&
                  ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                   (*(char *)(lVar28 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar19 + -8) = 0x10132e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  uVar3 = *(undefined8 *)(lVar18 + 0xa8);
                  *(undefined8 *)(puVar19 + -8) = 0x10133c;
                  func_0x(uVar3,5);
                  goto LAB_;
                }
                *(undefined8 *)(puVar19 + 0x20) = 0;
                *(undefined8 *)(puVar19 + -8) = 0x101362;
                (*_DAT_)(1,0xd59508,0xe791d8,0x87c);
              }
              uVar3 = *(undefined8 *)(lVar18 + 0xa8);
              *(undefined8 *)(puVar19 + -8) = 0x101370;
              func_0x(uVar3,5);
            }
          }
LAB_:
          *(undefined8 *)(puVar19 + -8) = 0x10137c;
          iVar10 = func_0x(puVar2);
          iVar32 = (int)uVar23;
          if (iVar10 == 0) {
            *(undefined8 *)(puVar19 + -8) = 0x101440;
            iVar10 = func_0x(puVar2);
            if (iVar10 == 0) {
              *(undefined8 *)(puVar19 + 0x20) = 0;
              *(undefined8 *)(puVar19 + -8) = 0x101466;
              (*_DAT_)(1,0xf14b88,0xf05c78,0xd67);
            }
          }
          else {
            if (-1 < iVar32) {
              uVar17 = *(ushort *)(lVar18 + 0xcc) & 0x7ff;
              if (iVar32 < (int)uVar17) {
                uVar17 = uVar17 * 2;
                uVar22 = *(ushort *)(lVar18 + 0xcc) >> 0xb & 7;
                lVar29 = *(longlong *)(lVar18 + 0xa8) + (ulonglong)(uVar22 * 2) + (ulonglong)uVar17
                         + (ulonglong)*(ushort *)(lVar18 + 0xca);
                if (iVar32 == 0) {
                  uVar17 = (uVar22 + uVar17) * 2 + 4;
                }
                else {
                  uVar17 = *(ushort *)(lVar29 + 2 + uVar31 * 2) & 0x7fff;
                }
                iStack_c4 = (*(ushort *)(lVar29 + 4 + uVar31 * 2) & 0x7fff) - uVar17;
                uVar22 = (uint)(*(ushort *)(lVar29 + 4 + uVar23 * 2) >> 0xf);
                lVar29 = (ulonglong)uVar17 +
                         *(longlong *)(lVar18 + 0xa8) + (ulonglong)*(ushort *)(lVar18 + 0xca);
                goto LAB_;
              }
            }
            *(undefined8 *)(puVar19 + 0x20) = 0;
            *(undefined8 *)(puVar19 + -8) = 0x101436;
            (*_DAT_)(1,0xf14b58,0xf14ba0,0x3c6);
            lVar29 = 0;
          }
LAB_:
          uVar3 = uStack_40;
          lVar9 = lStack_48;
          lVar28 = lStack_50;
          uVar7 = uStack_ae;
          uVar6 = auStack_c8[0];
          if (uVar22 != 0) {
            uStack_58 = uStack_9c;
            uStack_54 = uStack_b0;
            *(undefined4 *)(puVar19 + 0x50) = 0;
            uVar17 = uStack_a4;
            uStack_52 = uVar7;
            *(undefined2 *)(puVar19 + 0x48) = 0;
            *(undefined4 *)(puVar19 + 0x40) = 1;
            *(uint *)(puVar19 + 0x38) = uVar17 + iVar32;
            iVar10 = iStack_c4;
            *(longlong *)(puVar19 + 0x30) = lVar29;
            *(int *)(puVar19 + 0x28) = iVar10;
            *(undefined4 **)(puVar19 + 0x20) = &uStack_58;
            *(undefined8 *)(puVar19 + -8) = 0x1014cd;
            iVar10 = func_0x(uVar3,lVar9,uVar6,lVar28);
            if (iVar10 == 0) break;
          }
          uVar23 = (ulonglong)(iVar32 + 1);
          uVar31 = uVar31 + 1;
        } while ((longlong)uVar31 < (longlong)puStack_98);
      }
    }
  }
LAB_:
  uVar31 = uStack_38 ^ (ulonglong)auStack_c8;
  *(undefined8 *)(puVar19 + -8) = 0x1014f0;
  func_0x(uVar31);
  return;
}

