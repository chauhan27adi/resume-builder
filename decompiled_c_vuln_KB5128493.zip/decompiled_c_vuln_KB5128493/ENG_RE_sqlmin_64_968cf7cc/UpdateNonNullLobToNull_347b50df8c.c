
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined8 *puVar1;
  byte *pbVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  longlong lVar11;
  undefined8 uVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  longlong lVar15;
  undefined8 unaff_RBX;
  undefined8 unaff_RSI;
  longlong lVar16;
  undefined8 unaff_RDI;
  longlong lVar17;
  undefined4 uVar18;
  int iVar19;
  longlong unaff_GS_OFFSET;
  undefined8 auStackX_8 [2];
  undefined8 auStackX_18 [2];
  undefined8 uStack_30;
  
  uStack_30 = 0x100014;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  puVar1 = (undefined8 *)((longlong)auStackX_8 + lVar11);
  *puVar1 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002100 + lVar11) = unaff_RBX;
  *(undefined8 *)(&stack0x00002108 + lVar11) = unaff_RSI;
  *(undefined8 *)(&stack0x00002110 + lVar11) = unaff_RDI;
  *(ulonglong *)(&stack0x000020b8 + lVar11) = _DAT_ ^ (ulonglong)puVar1;
  uVar12 = *(undefined8 *)(&stack0x00002120 + lVar11);
  lVar6 = *(longlong *)(&stack0x00002128 + lVar11);
  *(undefined8 *)((longlong)&uStack_30 + lVar11) = 0x100071;
  func_0x((longlong)auStackX_18 + lVar11,&stack0x00000120 + lVar11);
  *(undefined8 *)((longlong)auStackX_18 + lVar11) = 0x83ead8;
  uVar18 = 0;
  if ((((*(byte *)(*(longlong *)(*(longlong *)(param_1 + 0x58) + 8) + 0x107) & 0x40) != 0) &&
      (uVar18 = 0, (*(byte *)(*(longlong *)(param_3 + 0x12) + 0xc) & 4) != 0)) &&
     (uVar18 = 0, *(int *)(&stack0x00002118 + lVar11) != 0)) {
    uVar18 = 0x20;
  }
  *(undefined4 *)((longlong)auStackX_18 + lVar11 + -0x18) = uVar18;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = *param_3;
  *(undefined8 *)((longlong)&uStack_30 + lVar11) = 0x1000c9;
  func_0x((longlong)auStackX_18 + lVar11,param_1,uVar12);
  *(undefined8 *)((longlong)&uStack_30 + lVar11) = 0x1000d2;
  func_0x((longlong)auStackX_18 + lVar11);
  if ((((*(uint *)(&stack0x00000054 + lVar11) & 0x800) == 0) ||
      (*(int *)(&stack0x00000038 + lVar11) != 0)) || (*(short *)(&stack0x0000003c + lVar11) != 0)) {
    uVar13 = 0x10;
  }
  else {
    lVar7 = *(longlong *)(&stack0x00000068 + lVar11);
    if ((*(byte *)(lVar7 + 0xc) & 0xf) == 0) {
      uVar13 = (ulonglong)*(ushort *)(lVar7 + 0xe);
    }
    else {
      uVar13 = (ulonglong)(ushort)((*(short *)(lVar7 + 0x10) + 1) * 0xc);
    }
  }
  uVar14 = uVar13 + 0xf;
  if (uVar14 <= uVar13) {
    uVar14 = 0xffffffffffffff0;
  }
  uVar14 = uVar14 & 0xfffffffffffffff0;
  *(undefined8 *)((longlong)&uStack_30 + lVar11) = 0x100135;
  func_0x();
  lVar8 = -uVar14;
  lVar7 = (longlong)auStackX_8 + lVar8 + lVar11;
  uVar13 = uVar13 & 0xffff;
  iVar19 = (int)uVar13;
  *(undefined8 *)((longlong)&uStack_30 + lVar8 + lVar11) = 0x100150;
  func_0x((longlong)auStackX_18 + lVar11,uVar13,lVar7);
  *(undefined8 *)((longlong)&uStack_30 + lVar8 + lVar11) = 0x100159;
  func_0x((longlong)auStackX_18 + lVar11);
  lVar16 = (ulonglong)*(uint *)(lVar6 + 4) * 0x40;
  pbVar2 = (byte *)(lVar16 + 0x18 + *(longlong *)(lVar6 + 8));
  *pbVar2 = *pbVar2 & 0xfb;
  if (*(uint *)(lVar6 + 0x20) < (uint)(*(int *)(lVar6 + 0x10) + iVar19)) {
    lVar17 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar15 = *(longlong *)(lVar17 + 0x100);
    if (lVar15 == 0) {
      *(undefined8 *)((longlong)&uStack_30 + lVar8 + lVar11) = 0x1001a7;
      (*_DAT_)(0);
      lVar15 = *(longlong *)(lVar17 + 0x100);
    }
    (&stack0xfffffffffffffff8)[lVar8 + lVar11] = 5;
    uVar12 = *(undefined8 *)(lVar15 + 1000);
    *(undefined8 *)((longlong)&uStack_30 + lVar8 + lVar11) = 0x1001d2;
    uVar12 = (*_DAT_)(0x1f9e,uVar12,0xbc2758,0xcd);
    *(undefined8 *)(lVar6 + 0x18) = uVar12;
    *(undefined4 *)(lVar6 + 0x10) = 0;
    pbVar2 = (byte *)(lVar16 + 0x18 + *(longlong *)(lVar6 + 8));
    *pbVar2 = *pbVar2 | 4;
    *(undefined4 *)(lVar6 + 0x20) = 0x1f9e;
  }
  uVar18 = param_3[1];
  uVar9 = param_3[2];
  uVar10 = param_3[3];
  puVar3 = (undefined4 *)(lVar16 + 8 + *(longlong *)(lVar6 + 8));
  *puVar3 = *param_3;
  puVar3[1] = uVar18;
  puVar3[2] = uVar9;
  puVar3[3] = uVar10;
  *(undefined4 *)(lVar16 + *(longlong *)(lVar6 + 8)) = param_2;
  pbVar2 = (byte *)(lVar16 + 0x18 + *(longlong *)(lVar6 + 8));
  *pbVar2 = *pbVar2 & 0xfe;
  pbVar2 = (byte *)(lVar16 + 0x18 + *(longlong *)(lVar6 + 8));
  *pbVar2 = *pbVar2 & 0xfd;
  lVar16 = *(longlong *)(lVar6 + 8) + lVar16;
  *(ulonglong *)(lVar16 + 0x20) = (ulonglong)*(uint *)(lVar6 + 0x10) + *(longlong *)(lVar6 + 0x18);
  *(int *)(lVar16 + 0x28) = iVar19;
  uVar4 = *(uint *)(lVar16 + 0x2c);
  *(uint *)(lVar16 + 0x2c) = uVar4 & 0xfffffffb | 1;
  uVar18 = param_3[1];
  uVar9 = param_3[2];
  uVar10 = param_3[3];
  *(undefined4 *)(lVar16 + 0x30) = *param_3;
  *(undefined4 *)(lVar16 + 0x34) = uVar18;
  *(undefined4 *)(lVar16 + 0x38) = uVar9;
  *(undefined4 *)(lVar16 + 0x3c) = uVar10;
  *(uint *)(lVar16 + 0x2c) = uVar4 & 0xfffffff1 | 1;
  uVar4 = *(uint *)(lVar6 + 0x10);
  iVar5 = *(int *)(lVar6 + 0x20);
  lVar16 = *(longlong *)(lVar6 + 0x18);
  *(undefined8 *)((longlong)&uStack_30 + lVar8 + lVar11) = 0x10025b;
  func_0x((ulonglong)uVar4 + lVar16,iVar5 - uVar4,lVar7,uVar13);
  *(int *)(lVar6 + 4) = *(int *)(lVar6 + 4) + 1;
  *(int *)(lVar6 + 0x10) = *(int *)(lVar6 + 0x10) + iVar19;
  *(undefined8 *)((longlong)&uStack_30 + lVar8 + lVar11) = 0x10026b;
  func_0x((longlong)auStackX_18 + lVar11);
  uVar13 = *(ulonglong *)(&stack0x000020b8 + lVar11);
  *(undefined8 *)((longlong)&uStack_30 + lVar8 + lVar11) = 0x10027a;
  func_0x(uVar13 ^ (ulonglong)puVar1);
  return;
}

