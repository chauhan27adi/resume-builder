
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,byte **param_3,longlong param_4,
                 undefined8 param_5,longlong *param_6)

{
  undefined *puVar1;
  undefined uVar2;
  undefined2 uVar3;
  undefined8 *puVar4;
  code *pcVar5;
  bool bVar6;
  longlong *plVar7;
  char cVar8;
  short sVar9;
  uint uVar10;
  uint uVar11;
  undefined4 uVar12;
  int iVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  longlong lVar17;
  undefined4 *puVar18;
  byte **ppbVar19;
  undefined8 uVar20;
  ulonglong *puVar21;
  byte bVar22;
  uint uVar23;
  longlong lVar24;
  byte *pbVar25;
  ushort uVar26;
  ushort uVar27;
  uint uVar28;
  ulonglong uVar29;
  uint uVar30;
  uint uVar31;
  uint *puVar32;
  undefined *puVar33;
  undefined *puVar34;
  undefined *puVar35;
  byte **ppbVar36;
  uint *puVar37;
  int iVar38;
  ushort *puVar39;
  uint *puVar40;
  uint uVar41;
  uint *puVar42;
  int iVar43;
  ulonglong uVar44;
  longlong lVar45;
  undefined8 uVar46;
  byte *pbVar47;
  int **ppiVar48;
  undefined2 *puVar49;
  byte **ppbVar50;
  uint **ppuVar51;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_450;
  undefined auStack_448 [80];
  short sStack_3f8;
  ushort uStack_3f6;
  uint uStack_3f4;
  uint *puStack_3f0;
  undefined8 uStack_3e8;
  uint uStack_3e0;
  ushort uStack_3dc;
  byte *pbStack_3da;
  undefined2 uStack_3d2;
  undefined2 uStack_3d0;
  undefined2 uStack_3ce;
  ushort uStack_3cc;
  undefined2 uStack_3ca;
  undefined4 uStack_3c8;
  uint uStack_3c0;
  char cStack_3bc;
  char acStack_3bb [3];
  uint uStack_3b8;
  uint uStack_3b4;
  uint auStack_3b0 [2];
  byte **ppbStack_3a8;
  longlong lStack_3a0;
  int aiStack_398 [2];
  undefined8 uStack_390;
  byte **ppbStack_388;
  uint uStack_380;
  byte **ppbStack_378;
  uint *puStack_370;
  uint uStack_368;
  uint uStack_364;
  longlong lStack_360;
  longlong lStack_358;
  undefined8 uStack_350;
  undefined4 uStack_348;
  longlong lStack_340;
  longlong lStack_338;
  uint uStack_330;
  uint uStack_32c;
  undefined2 *puStack_328;
  undefined8 uStack_320;
  int iStack_318;
  uint uStack_314;
  undefined4 uStack_310;
  undefined2 uStack_30c;
  undefined2 uStack_30a;
  longlong lStack_308;
  longlong lStack_2f8;
  undefined8 *puStack_2f0;
  undefined4 uStack_2e8;
  undefined4 uStack_2e4;
  longlong lStack_2e0;
  undefined4 uStack_2d8;
  longlong lStack_2d0;
  undefined2 uStack_2c8;
  uint uStack_2c4;
  undefined8 uStack_2c0;
  undefined auStack_2b8 [4];
  undefined auStack_2b4 [4];
  undefined auStack_2b0 [4];
  undefined auStack_2ac [4];
  longlong *plStack_2a8;
  undefined8 uStack_2a0;
  undefined8 uStack_298;
  undefined8 uStack_290;
  undefined8 uStack_288;
  undefined auStack_248 [16];
  undefined auStack_238 [16];
  undefined auStack_228 [8];
  uint *puStack_220;
  uint *puStack_218;
  undefined2 uStack_210;
  undefined2 auStack_20e [3];
  undefined auStack_208 [224];
  undefined auStack_128 [224];
  ulonglong uStack_48;
  
  puVar33 = auStack_448;
  puVar35 = auStack_448;
  uStack_48 = _DAT_ ^ (ulonglong)&sStack_3f8;
  uVar30 = 0x1f7c;
  plStack_2a8 = param_6;
  sStack_3f8 = -1;
  uStack_3b8 = 0x1f7c;
  puStack_3f0 = (uint *)0x0;
  uStack_3f4 = 0;
  uVar44 = 0;
  pbStack_3da = (byte *)0x0;
  uStack_3d0 = 0;
  uStack_3ce = 0;
  uStack_3cc = 0;
  uStack_3ca = 0;
  uStack_3e8 = (longlong *)0x0;
  puVar4 = *(undefined8 **)(param_1 + 0x30);
  lVar17 = puVar4[1];
  uStack_364 = 0;
  uStack_350 = 0;
  uStack_348 = 0;
  lStack_3a0 = param_1;
  if (param_3 != (byte **)0x0) {
    if ((*(int *)(puVar4 + 5) == *(int *)(param_3 + 1)) &&
       (*param_3 == (byte *)((ulonglong)*(uint6 *)((longlong)puVar4 + 0x14) * 0x10000))) {
      uStack_450 = 0x1000ce;
      sVar9 = (**(code **)*puVar4)(puVar4);
      if (*(short *)((longlong)param_3 + 0xc) != sVar9) goto LAB_;
      if (param_3[0x15] != (byte *)0x0) {
        LOCK();
        UNLOCK();
      }
    }
    else {
LAB_:
      uStack_450 = 0x1000f0;
      func_0x(param_3,puVar4);
    }
    uVar26 = *(ushort *)(param_3 + 7);
    uVar27 = *(ushort *)((longlong)param_3 + 0x62);
    uVar28 = (uint)uVar27;
    ppbStack_378 = param_3;
    lStack_360 = param_4;
    if ((uVar26 & 0x400) == 0) {
      uVar44 = (ulonglong)uStack_3f4;
      uStack_368 = (uint)uVar27;
      lStack_358 = 0;
      uStack_320 = 0;
      puStack_370 = (uint *)param_3[0xe];
      if (*(longlong *)(param_1 + 0x30) != 0) {
        lVar24 = **(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x30) + 8) + 0x160);
        uStack_350 = *(undefined8 *)(lVar24 + 0xa8);
        uStack_348 = *(undefined4 *)(lVar24 + 0xb0);
      }
      uStack_364 = uStack_364 | 0x10;
      puVar35 = auStack_448;
    }
    else {
      if (uVar27 == 0) {
        lVar24 = 0;
        uVar31 = 0;
        lVar16 = lVar24;
        uVar28 = uVar31;
      }
      else {
        uVar31 = (uint)uVar27 * 8;
        uStack_450 = 0x1001a7;
        lVar14 = func_0x();
        lVar14 = -lVar14;
        lVar24 = (longlong)&sStack_3f8 + lVar14;
        *(undefined8 *)(auStack_448 + lVar14 + -8) = 0x1001c4;
        lVar15 = func_0x();
        lVar45 = lStack_3a0;
        lVar15 = -lVar15;
        puVar33 = auStack_448 + lVar15 + lVar14;
        uVar27 = *(ushort *)(param_3 + 0xb);
        lVar16 = (longlong)&sStack_3f8 + lVar15 + lVar14;
        uVar44 = (ulonglong)*(uint *)((longlong)param_3 + 0x54);
        if ((*(uint *)((longlong)param_3 + 0x54) < 0x1f9f) ||
           (uVar44 = (ulonglong)uVar27, 0x1f9d < uVar27)) {
          if ((int)uVar44 == 0) goto LAB_;
        }
        else {
          uVar44 = 0x1f9e;
        }
        puStack_328 = (undefined2 *)(lStack_3a0 + 0x260);
        *(longlong *)(lStack_3a0 + 0x278) = *(longlong *)(lStack_3a0 + 0x270);
        *(ushort *)(lStack_3a0 + 0x262) = -(ushort)(*(longlong *)(lStack_3a0 + 0x270) != 0) & 8000;
        *puStack_328 = 0;
        *(undefined8 *)(lStack_3a0 + 0x268) = 0;
        *(undefined4 *)(lStack_3a0 + 0x264) = 0;
        uVar29 = uVar44 + 0xf;
        if (uVar29 <= uVar44) {
          uVar29 = 0xffffffffffffff0;
        }
        uVar29 = uVar29 & 0xfffffffffffffff0;
        *(undefined8 *)(auStack_448 + lVar15 + lVar14 + -8) = 0x100244;
        func_0x();
        puVar33 = auStack_448 + -uVar29 + lVar15 + lVar14;
        *(ulonglong *)(lVar45 + 0x268) = (longlong)&sStack_3f8 + -uVar29 + lVar15 + lVar14;
        *(ushort *)(lVar45 + 0x264) = (short)uVar44 - uVar27;
        *(ushort *)(lVar45 + 0x266) = uVar27;
        uVar28 = (uint)*(ushort *)((longlong)param_3 + 0x62);
        uVar26 = *(ushort *)(param_3 + 7);
      }
LAB_:
      uStack_368 = uVar28 & 0xffff;
      lStack_358 = 0;
      uStack_320 = 0;
      puStack_370 = (uint *)param_3[0xe];
      if (*(longlong *)(lStack_3a0 + 0x30) != 0) {
        lVar14 = **(longlong **)(*(longlong *)(*(longlong *)(lStack_3a0 + 0x30) + 8) + 0x160);
        uStack_350 = *(undefined8 *)(lVar14 + 0xa8);
        uStack_348 = *(undefined4 *)(lVar14 + 0xb0);
      }
      uVar28 = uStack_364 | 0x10;
      if ((((uVar26 & 0x400) != 0) && (param_4 != 0)) &&
         (uVar28 = uStack_364 | 0x14, lStack_340 = lVar24, lStack_338 = lVar16, uStack_330 = uVar31,
         uStack_32c = uVar31, lVar24 != 0)) {
        uStack_364 = uStack_364 | 0x16;
        *(undefined8 *)(puVar33 + -8) = 0x100343;
        func_0x(&ppbStack_378);
        uVar28 = uStack_364 | 8;
      }
      uStack_364 = uVar28;
      uVar44 = (ulonglong)uStack_3f4;
      puVar35 = puVar33;
      param_1 = lStack_3a0;
    }
  }
  uVar29 = 0;
  if ((*(uint **)(param_1 + 0x230) != (uint *)0x0) &&
     ((**(uint **)(param_1 + 0x230) & 0x20000000) != 0)) {
    pbVar47 = param_3[0x18];
    uStack_3b8 = 0x1f7c;
    if (pbVar47 != (byte *)0x0) {
      if (((*(uint *)(pbVar47 + 0x40) & 0x48000) == 0x48000) && ((uStack_364 & 8) != 0)) {
        ppiVar48 = *(int ***)(lStack_338 + (ulonglong)*(uint *)(pbVar47 + 0x38) * 8);
      }
      else {
        lVar24 = lStack_360;
        if ((*(byte *)(*(longlong *)(pbVar47 + 0x48) + 0x2a) & 0x10) != 0) {
          lVar24 = lStack_358;
        }
        ppiVar48 = (int **)(*(longlong *)(pbVar47 + 0x28) + lVar24);
        if ((*(uint *)(pbVar47 + 0x40) >> 0xb & 1) != 0) {
          ppiVar48 = (int **)*ppiVar48;
        }
      }
      if (*(int *)ppiVar48 != 0) {
        uVar28 = *(uint *)(**(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x30) + 8) + 0x160)
                          + 0x14);
        if (uVar28 == 1) {
          uVar30 = 0x1f84;
          uStack_3b8 = uVar30;
        }
        else {
          uVar30 = 0x1f7c;
          uStack_3b8 = uVar30;
          if (1 < uVar28) {
            uVar30 = 0x1f82;
            uStack_3b8 = uVar30;
          }
        }
      }
    }
  }
  if ((*(byte *)((longlong)param_3 + 0xe) & 8) == 0) {
    uVar28 = uStack_2c4 & 0xfffffff8;
    uStack_2a0 = 0x818a90;
    uVar46 = 0x11de0e8;
    uStack_288 = 0;
    uStack_2c0 = 0;
    lStack_2e0 = *(longlong *)(param_1 + 0x30);
    iVar43 = *(int *)(*(longlong *)(lStack_2e0 + 8) + 0x100);
    if ((iVar43 == 0) || (iVar43 - 3U < 2)) {
      uStack_298 = 0x11de0e8;
      if ((*(byte *)(lVar17 + 0x106) & 1) == 0) {
        uStack_298 = 0x11ddc60;
      }
    }
    else {
      uStack_298 = 0x11eb730;
      if ((*(byte *)(lVar17 + 0x106) & 1) == 0) {
        uStack_298 = 0x11ddc98;
      }
    }
    lStack_2f8 = param_1 + 0x2b0;
    puStack_2f0 = &uStack_2a0;
    uStack_290 = 0;
    uStack_2e8 = 1;
    uStack_2e4 = 1;
    lVar24 = *(longlong *)(lStack_2e0 + 8);
    lVar16 = lVar24;
    if (*(longlong *)(lVar24 + 0x478) != 0) {
      lVar16 = *(longlong *)(lVar24 + 0x478);
    }
    if ((*(short *)(lVar16 + 0x440) != 0) || (*(short *)(lVar24 + 0xce) != 0)) {
      uVar28 = uVar28 | 1;
    }
    if ((0x1f7c < *(uint *)(*(longlong *)(lStack_2e0 + 8) + 0xb0)) &&
       ((*(byte *)(*(longlong *)(lStack_2e0 + 8) + 0x106) & 4) == 0)) {
      uVar28 = uVar28 | 2;
    }
    uStack_2c4 = uVar28 | 4;
    uStack_2d8 = *(undefined4 *)(*(longlong *)(lStack_2e0 + 0x20) + 0x664);
    lStack_2d0 = (ulonglong)*(uint6 *)(lStack_2e0 + 0x14) << 0x10;
    uStack_2c8 = *(undefined2 *)(*(longlong *)(lStack_2e0 + 0x20) + 0x660);
    *(undefined8 *)(puVar35 + -8) = 0x101413;
    lVar16 = func_0x();
    ppbVar50 = ppbStack_378;
    lVar24 = *(longlong *)(param_1 + 0x30);
    lVar16 = -lVar16;
    puVar34 = puVar35 + lVar16;
    bVar22 = *(byte *)(lVar17 + 0x106);
    puVar1 = puVar35 + lVar16 + 0x50;
    iVar43 = *(int *)(*(longlong *)(lVar24 + 8) + 0x100);
    if ((iVar43 == 0) || (iVar43 == 3 || iVar43 == 4)) {
      bVar6 = false;
    }
    else {
      bVar6 = true;
    }
    ppbVar36 = (byte **)0x0;
    lStack_308 = lVar24;
    if ((*(byte *)(ppbStack_378 + 7) & 0x20) == 0) {
      if (bVar6) {
        uVar30 = uStack_364 & 0x10;
        *(undefined2 *)(puVar35 + lVar16 + 0x28) = 1;
        ppbVar19 = ppbVar36;
        if (uVar30 != 0) {
          ppbVar19 = ppbVar50;
        }
        ppbStack_3a8 = (byte **)0x0;
        uVar12 = *(undefined4 *)((longlong)ppbVar19 + 0x14);
        uVar30 = -*(int *)(ppbVar19 + 2);
        *(undefined4 *)(puVar35 + lVar16 + 0x20) = *(undefined4 *)(ppbVar19 + 3);
        auStack_3b0[0] = uVar30;
        if ((bVar22 & 1) == 0) {
          *(undefined8 *)(puVar35 + lVar16 + -8) = 0x10317a;
          func_0x(&sStack_3f8,puVar1,0x1f9e,uVar12);
        }
        else {
          *(undefined8 *)(puVar35 + lVar16 + -8) = 0x103173;
          func_0x();
        }
        puVar34 = puVar35 + lVar16;
        if (uVar30 != 0) {
          *(undefined8 *)(puVar35 + lVar16 + -8) = 0x1031a2;
          lVar17 = func_0x();
          lVar17 = -lVar17;
          puVar34 = puVar35 + lVar17 + lVar16;
          ppbVar36 = (byte **)(puVar35 + lVar17 + lVar16 + 0x50);
          ppbStack_3a8 = ppbVar36;
          *(undefined8 *)(puVar35 + lVar17 + lVar16 + -8) = 0x1031b8;
          func_0x(ppbVar36,0);
        }
        if (*(ushort *)((longlong)ppbStack_378 + 0x62) != 0) {
          puVar32 = puStack_370 + 0xe;
          ppbStack_388 = (byte **)(ulonglong)*(ushort *)((longlong)ppbStack_378 + 0x62);
          do {
            uVar30 = puVar32[-0xe];
            puVar37 = puVar32 + -0xe;
            *(undefined8 *)(puVar34 + -8) = 0x10320a;
            func_0x(&ppbStack_378,puVar37,acStack_3bb);
            if (acStack_3bb[0] == '\x03') {
              if (((*(ushort *)(*(longlong *)(puVar32 + 4) + 0xc) & 0x400) == 0) &&
                 ((puVar32[2] & 0x4000) == 0)) {
                *(undefined8 *)(puVar34 + -8) = 0x10351b;
                (*_DAT_)(6,0x51,0x10,3);
              }
              *(undefined8 *)(puVar34 + -8) = 0x10352d;
              func_0x(&sStack_3f8,puVar37,0,0);
              if ((int)uVar30 < 0) {
                puVar37 = (uint *)((longlong)(int)~uVar30 * 0x20 + 0xc + (longlong)ppbVar36);
                *puVar37 = *puVar37 | 2;
              }
            }
            else {
              if (*(short *)(puVar32 + -0xd) != 0) {
                if (sStack_3f8 == 0) {
                  *(undefined8 *)(puVar34 + -8) = 0x10322e;
                  func_0x();
                }
                else {
                  *(undefined8 *)(puVar34 + -8) = 0x103235;
                  func_0x(&uStack_3f6,puVar37);
                }
              }
              uVar28 = puVar32[2];
              if (((uVar28 & 0x48000) == 0x48000) && ((uStack_364 & 8) != 0)) {
                ppiVar48 = *(int ***)(lStack_338 + (ulonglong)*puVar32 * 8);
              }
              else {
                lVar17 = lStack_360;
                if ((*(byte *)(*(longlong *)(puVar32 + 4) + 0x2a) & 0x10) != 0) {
                  lVar17 = lStack_358;
                }
                ppiVar48 = (int **)(lVar17 + *(longlong *)(puVar32 + -4));
                if ((uVar28 >> 0xb & 1) != 0) {
                  ppiVar48 = (int **)*ppiVar48;
                }
              }
              cVar8 = (char)uVar28;
              if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
                if ((uVar28 >> 8 & 1) == 0) {
                  pbVar47 = (byte *)((longlong)(int)*puVar37 + (longlong)puStack_3f0);
                  uVar3 = *(undefined2 *)(puVar32 + 1);
                  *(undefined8 *)(puVar34 + -8) = 0x10344a;
                  func_0x(pbVar47,ppiVar48,uVar3);
                }
                else {
                  if (((uVar28 >> 0xf & 1) == 0) || ((uStack_364 & 8) == 0)) {
                    lVar17 = lStack_360;
                    if ((*(byte *)(*(longlong *)(puVar32 + 4) + 0x2a) & 0x10) != 0) {
                      lVar17 = lStack_358;
                    }
                    uVar30 = *(uint *)(*(longlong *)(*(longlong *)(puVar32 + 4) + 0x18) + lVar17);
                  }
                  else {
                    uVar30 = *(uint *)(lStack_340 + (ulonglong)*puVar32 * 8);
                  }
                  uVar28 = (uint)*(ushort *)(puVar32 + 1);
                  if (uVar30 < uVar28) {
                    iVar43 = uVar28 - uVar30;
                  }
                  else {
                    iVar43 = 0;
                    if (uVar28 < uVar30) {
                      *(undefined8 *)(puVar34 + -8) = 0x1034aa;
                      (*_DAT_)(6,0x5c,0x16);
                      iVar43 = 0;
                    }
                  }
                  pbVar47 = (byte *)((longlong)(int)*puVar37 + (longlong)puStack_3f0);
                  uVar2 = *(undefined *)(*(longlong *)(puVar32 + 4) + 0x24);
                  if ((ppiVar48 != (int **)0x0) && (uVar30 != 0)) {
                    *(undefined8 *)(puVar34 + -8) = 0x1034d2;
                    func_0x(pbVar47,ppiVar48,uVar30);
                  }
                  if (iVar43 != 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x1034eb;
                    func_0x(pbVar47 + uVar30,uVar2,iVar43);
                  }
                }
              }
              else if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
                if (((uVar28 >> 0xd & 1) == 0) || (*(int *)ppiVar48 != 0)) {
                  if (((uVar28 >> 0xf & 1) == 0) || ((uStack_364 & 8) == 0)) {
                    lVar17 = *(longlong *)(puVar32 + 4);
                    if ((uVar28 >> 8 & 1) == 0) {
                      uVar28 = (uint)*(ushort *)(lVar17 + 2);
                    }
                    else {
                      lVar24 = lStack_360;
                      if ((*(byte *)(lVar17 + 0x2a) & 0x10) != 0) {
                        lVar24 = lStack_358;
                      }
                      uVar28 = *(uint *)(*(longlong *)(lVar17 + 0x18) + lVar24);
                    }
                  }
                  else {
                    uVar28 = *(uint *)(lStack_340 + (ulonglong)*puVar32 * 8);
                  }
                }
                else {
                  uVar28 = 0;
                }
                if (*(ushort *)(puVar32 + 1) < uVar28) {
                  *(undefined8 *)(puVar34 + -8) = 0x1033a0;
                  (*_DAT_)(6,0x52,0x16);
                }
                *(undefined4 *)(puVar34 + 0x28) = 0;
                *(uint **)(puVar34 + 0x20) = puVar37;
                *(undefined8 *)(puVar34 + -8) = 0x1033c4;
                func_0x(ppbVar36 + (longlong)(int)~uVar30 * 4,ppiVar48,uVar28);
              }
              else if (cVar8 == '\b') {
                if (sStack_3f8 == 0) {
                  *(undefined8 *)(puVar34 + -8) = 0x1032fe;
                  func_0x(&sStack_3f8,puVar37,ppiVar48);
                }
                else {
                  *(undefined4 *)(puVar34 + 0x28) = 0;
                  *(uint **)(puVar34 + 0x20) = puVar37;
                  *(undefined8 *)(puVar34 + -8) = 0x10332b;
                  func_0x(ppbVar36 + (longlong)(int)~uVar30 * 4,ppiVar48,1);
                }
              }
              else {
                *(undefined8 *)(puVar34 + 0x20) = 0x7f0108;
                *(undefined8 *)(puVar34 + -8) = 0x1032dd;
                (*_DAT_)(1,0xbf4f60,0xc218a0);
              }
            }
            puVar32 = puVar32 + 0x14;
            ppbStack_388 = (byte **)((longlong)ppbStack_388 - 1);
            ppbVar36 = ppbStack_3a8;
          } while (ppbStack_388 != (byte **)0x0);
          ppbStack_388 = (byte **)0x0;
          lVar24 = lStack_308;
          uVar30 = auStack_3b0[0];
        }
        ppbVar50 = ppbStack_3a8;
        uVar28 = uStack_3b8;
        puVar39 = (ushort *)0x0;
        if (uVar30 != 0) {
          if (sStack_3f8 == 0) {
            do {
              uVar44 = (ulonglong)uVar30;
              uVar31 = uVar30 - 1;
              if (*(int *)(ppbStack_3a8 + (ulonglong)uVar31 * 4 + 1) != 0) {
                uStack_3dc = (ushort)uVar30;
                uStack_3f4 = uStack_3e8._4_4_ + 2 + uVar30 * 2;
                *(byte *)puStack_3f0 = *(byte *)puStack_3f0 | 0x20;
                if (uStack_3f4 <= uStack_3b8) {
                  puVar39 = (ushort *)((ulonglong)uStack_3e8._4_4_ + (longlong)puStack_3f0);
                  *puVar39 = uStack_3dc;
                }
                uStack_3e0 = uStack_3f4;
                uStack_314 = uStack_3f4;
                if (uVar30 != 0) {
                  puVar32 = (uint *)((longlong)ppbStack_3a8 + 0xc);
                  do {
                    puVar39 = puVar39 + 1;
                    uVar30 = puVar32[-1];
                    uVar29 = (ulonglong)uStack_3f4;
                    uStack_3f4 = uStack_3f4 + uVar30;
                    pbVar47 = (byte *)(uVar29 + (longlong)puStack_3f0);
                    if ((uStack_3f4 <= uVar28) && (uStack_3f4 < 0x1f9f)) {
                      *puVar39 = (ushort)((*puVar32 & 1) << 0xf) | (ushort)uStack_3f4 & 0x7fff;
                      uVar46 = *(undefined8 *)(puVar32 + -3);
                      *(undefined8 *)(puVar34 + -8) = 0x1035ce;
                      func_0x(pbVar47,uVar30,uVar46,uVar30);
                    }
                    puVar32 = puVar32 + 8;
                    uVar44 = uVar44 - 1;
                    uStack_314 = uStack_3f4;
                  } while (uVar44 != 0);
                }
                break;
              }
              uVar30 = uVar31;
            } while (uVar31 != 0);
          }
          else {
            *(uint **)(puVar34 + 0x28) = &uStack_314;
            *(byte ***)(puVar34 + 0x20) = ppbVar50;
            uVar28 = uStack_3b8;
            *(undefined8 *)(puVar34 + -8) = 0x103610;
            func_0x(&uStack_3f6,0x1f9e,uVar28,uVar30);
          }
        }
      }
      else {
        sStack_3f8 = 0;
        ppbVar50 = ppbVar36;
        if ((uStack_364 & 0x10) != 0) {
          ppbVar50 = ppbStack_378;
        }
        ppbStack_388 = (byte **)0x0;
        uVar12 = *(undefined4 *)(ppbVar50 + 3);
        uVar30 = -*(int *)(ppbVar50 + 2);
        auStack_3b0[0] = uVar30;
        if ((bVar22 & 1) == 0) {
          iVar43 = *(int *)((longlong)ppbVar50 + 0x14) + -1;
          puVar35[lVar16 + 0x28] = 6;
        }
        else {
          iVar43 = *(int *)((longlong)ppbVar50 + 0x14) + -4;
          puVar35[lVar16 + 0x28] = 0;
        }
        *(undefined4 *)(puVar35 + lVar16 + 0x20) = uVar12;
        *(undefined8 *)(puVar35 + lVar16 + -8) = 0x1014cf;
        func_0x(&uStack_3f6,puVar1,0x1f9e,iVar43);
        puVar34 = puVar35 + lVar16;
        if (uVar30 != 0) {
          *(undefined8 *)(puVar35 + lVar16 + -8) = 0x1014f7;
          lVar17 = func_0x();
          lVar17 = -lVar17;
          puVar34 = puVar35 + lVar17 + lVar16;
          ppbVar36 = (byte **)(puVar35 + lVar17 + lVar16 + 0x50);
          ppbStack_388 = ppbVar36;
          *(undefined8 *)(puVar35 + lVar17 + lVar16 + -8) = 0x10150d;
          func_0x(ppbVar36,0);
        }
        uStack_3b4 = 0;
        uStack_390 = CONCAT44(uStack_390._4_4_,(uint)*(ushort *)((longlong)ppbStack_378 + 0x62));
        puVar32 = puStack_370;
        if (*(ushort *)((longlong)ppbStack_378 + 0x62) != 0) {
          do {
            uVar30 = *puVar32;
            *(undefined8 *)(puVar34 + -8) = 0x101557;
            func_0x(&ppbStack_378,puVar32,&cStack_3bc);
            if (cStack_3bc == '\x03') {
              if (((*(ushort *)(*(longlong *)(puVar32 + 0x12) + 0xc) & 0x400) == 0) &&
                 ((puVar32[0x10] & 0x4000) == 0)) {
                *(undefined8 *)(puVar34 + -8) = 0x103061;
                (*_DAT_)(6,0x51,0x10,3);
              }
              *(undefined8 *)(puVar34 + -8) = 0x103073;
              func_0x(&uStack_3f6,puVar32,0,0);
              if ((int)uVar30 < 0) {
                puVar37 = (uint *)((longlong)(int)~uVar30 * 0x20 + 0xc + (longlong)ppbVar36);
                *puVar37 = *puVar37 | 2;
              }
            }
            else {
              if (*(short *)(puVar32 + 1) != 0) {
                *(undefined8 *)(puVar34 + -8) = 0x101575;
                func_0x(&uStack_3f6,puVar32);
              }
              uVar28 = puVar32[0x10];
              if (((uVar28 & 0x48000) == 0x48000) && ((uStack_364 & 8) != 0)) {
                ppbVar50 = *(byte ***)(lStack_338 + (ulonglong)puVar32[0xe] * 8);
              }
              else {
                lVar17 = lStack_360;
                if ((*(byte *)(*(longlong *)(puVar32 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar17 = lStack_358;
                }
                ppbVar50 = (byte **)(lVar17 + *(longlong *)(puVar32 + 10));
                if ((uVar28 >> 0xb & 1) != 0) {
                  ppbVar50 = (byte **)*ppbVar50;
                }
              }
              cVar8 = (char)uVar28;
              ppbStack_3a8 = ppbVar50;
              if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
                if ((uVar28 >> 8 & 1) == 0) {
                  pbVar47 = (byte *)((longlong)(int)*puVar32 + (longlong)puStack_3f0);
                  uVar3 = *(undefined2 *)(puVar32 + 0xf);
                  *(undefined8 *)(puVar34 + -8) = 0x102f8e;
                  func_0x(pbVar47,ppbVar50,uVar3);
                }
                else {
                  if (((uVar28 & 0x8000) == 0) || ((uStack_364 & 8) == 0)) {
                    lVar17 = lStack_360;
                    if ((*(byte *)(*(longlong *)(puVar32 + 0x12) + 0x2a) & 0x10) != 0) {
                      lVar17 = lStack_358;
                    }
                    uVar30 = *(uint *)(*(longlong *)(*(longlong *)(puVar32 + 0x12) + 0x18) + lVar17)
                    ;
                  }
                  else {
                    uVar30 = *(uint *)(lStack_340 + (ulonglong)puVar32[0xe] * 8);
                  }
                  uVar28 = (uint)*(ushort *)(puVar32 + 0xf);
                  if (uVar30 < uVar28) {
                    iVar43 = uVar28 - uVar30;
                  }
                  else {
                    iVar43 = 0;
                    if (uVar28 < uVar30) {
                      *(undefined8 *)(puVar34 + -8) = 0x102fed;
                      (*_DAT_)(6,0x5c,0x16);
                      iVar43 = 0;
                    }
                  }
                  pbVar47 = (byte *)((longlong)(int)*puVar32 + (longlong)puStack_3f0);
                  uVar2 = *(undefined *)(*(longlong *)(puVar32 + 0x12) + 0x24);
                  if ((ppbVar50 != (byte **)0x0) && (uVar30 != 0)) {
                    *(undefined8 *)(puVar34 + -8) = 0x103015;
                    func_0x(pbVar47,ppbVar50,uVar30);
                  }
                  if (iVar43 != 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x10302d;
                    func_0x(pbVar47 + uVar30,uVar2,iVar43);
                  }
                }
              }
              else if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
                if (((uVar28 >> 0xd & 1) == 0) || (*(int *)ppbVar50 != 0)) {
                  if (((uVar28 & 0x8000) == 0) || ((uStack_364 & 8) == 0)) {
                    lVar17 = *(longlong *)(puVar32 + 0x12);
                    if ((uVar28 >> 8 & 1) == 0) {
                      uVar28 = (uint)*(ushort *)(lVar17 + 2);
                    }
                    else {
                      lVar24 = lStack_360;
                      if ((*(byte *)(lVar17 + 0x2a) & 0x10) != 0) {
                        lVar24 = lStack_358;
                      }
                      uVar28 = *(uint *)(*(longlong *)(lVar17 + 0x18) + lVar24);
                    }
                  }
                  else {
                    uVar28 = *(uint *)(lStack_340 + (ulonglong)puVar32[0xe] * 8);
                  }
                }
                else {
                  uVar28 = 0;
                }
                if (*(ushort *)(puVar32 + 0xf) < uVar28) {
                  *(undefined8 *)(puVar34 + -8) = 0x102f49;
                  (*_DAT_)(6,0x52,0x16);
                }
                *(undefined4 *)(puVar34 + 0x28) = 0;
                *(uint **)(puVar34 + 0x20) = puVar32;
                *(undefined8 *)(puVar34 + -8) = 0x102f6e;
                func_0x(ppbVar36 + (longlong)(int)~uVar30 * 4,ppbVar50,uVar28);
              }
              else if (cVar8 == '\b') {
                uVar30 = *puVar32;
                lVar17 = (longlong)(int)uVar30;
                if ((int)uVar30 < 0) {
                  if ((uVar30 & 0xc0000000) == 0x80000000) {
                    *(undefined8 *)(puVar34 + -8) = 0x1025fb;
                    func_0x(auStack_128);
                    aiStack_398[0] = 0;
                    if (uStack_3f4 == 0) {
                      uVar44 = (ulonglong)uStack_3e8 & 0xffffffff;
                      uStack_3f6 = 0;
                      uVar30 = (uint)uStack_3e8;
                      if ((*(byte *)puStack_3f0 & 0x10) != 0) {
                        uVar30 = (uint)uStack_3e8 + 2 +
                                 (*(ushort *)(uVar44 + (longlong)puStack_3f0) + 7 >> 3);
                        uVar44 = (ulonglong)uVar30;
                      }
                      uStack_3e8 = (longlong *)CONCAT44(uVar30,(uint)uStack_3e8);
                      uVar30 = (uint)uVar44;
                      if ((*(byte *)puStack_3f0 & 0x20) == 0) {
                        uStack_3dc = 0;
                        uStack_3f4 = uVar30;
                        uStack_3e0 = uVar30;
                      }
                      else {
                        puVar39 = (ushort *)(uVar44 + (longlong)puStack_3f0);
                        uStack_3dc = *puVar39;
                        if (uStack_3dc == 0) {
                          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                              (lVar17 = *(longlong *)
                                         (*(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8 +
                                         (ulonglong)*_DAT_), lVar17 != 0)) &&
                             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                              (*(char *)(lVar17 + 0x499) != '\0')))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar34 + -8) = 0x1026d5;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x1026fb;
                              (*_DAT_)(1,0xa73c28,0xb938f8,0x80f);
                            }
                          }
                          puVar37 = puStack_3f0;
                          *(undefined8 *)(puVar34 + -8) = 0x102709;
                          func_0x(puVar37,3);
                          uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                        }
                        uStack_3e0 = (int)uVar44 + (uStack_3dc + 1) * 2;
                        if (0x1f9e < uStack_3e0) {
                          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                             ((lVar17 = *(longlong *)
                                         (*(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8 +
                                         (ulonglong)*_DAT_), lVar17 != 0 &&
                              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                               (*(char *)(lVar17 + 0x499) != '\0')))))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar34 + -8) = 0x1027a9;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x1027cf;
                              (*_DAT_)(1,0xa73c28,0xb938f8,0x816);
                            }
                          }
                          puVar37 = puStack_3f0;
                          *(undefined8 *)(puVar34 + -8) = 0x1027dd;
                          func_0x(puVar37,4);
                          uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                        }
                        uVar29 = (ulonglong)uStack_3dc;
                        uStack_3f4 = puVar39[uVar29] & 0x7fff;
                        uVar30 = uStack_3f4;
                        uVar28 = uStack_3e0;
                        if (uStack_3f4 < uStack_3e0) {
                          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                              (lVar17 = *(longlong *)
                                         (*(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8 +
                                         (ulonglong)*_DAT_), lVar17 != 0)) &&
                             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                              (*(char *)(lVar17 + 0x499) != '\0')))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar34 + -8) = 0x10287e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x1028a4;
                              (*_DAT_)(1,0xa73c28,0xb938f8,0x81d);
                            }
                          }
                          puVar37 = puStack_3f0;
                          *(undefined8 *)(puVar34 + -8) = 0x1028b2;
                          func_0x(puVar37,4);
                          uVar29 = (ulonglong)uStack_3dc;
                          uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                          uVar30 = uStack_3f4;
                          uVar28 = uStack_3e0;
                        }
                        do {
                          puVar37 = puStack_3f0;
                          if (-1 < (short)puVar39[(ulonglong)((int)uVar29 - 1) + 1]) break;
                          uVar31 = uVar28;
                          if ((((int)uVar29 != 1) &&
                              (uVar31 = *(ushort *)
                                         ((longlong)puStack_3f0 + uVar29 * 2 + (uVar44 - 2)) &
                                        0x7fff, uVar31 < uVar28)) ||
                             ((*(ushort *)((longlong)puStack_3f0 + uVar29 * 2 + uVar44) & 0x7fff) <
                              uVar31)) {
                            *(undefined8 *)(puVar34 + -8) = 0x10291a;
                            func_0x(puVar37,7);
                            uVar29 = (ulonglong)uStack_3dc;
                            uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                            uVar30 = uStack_3f4;
                            uVar28 = uStack_3e0;
                          }
                          if ((uVar31 < uVar28) || (uVar30 < uVar31)) goto LAB_;
                          if (*(ushort *)((ulonglong)uVar31 + (longlong)puStack_3f0) == 5) {
                            uStack_3f6 = uStack_3f6 | 2;
                            uStack_3dc = (short)uVar29 - 1;
                            uStack_3ce = (undefined2)uVar31;
                            uVar26 = *(ushort *)
                                      ((longlong)puStack_3f0 + (ulonglong)(uVar31 & 0xffff) + 2);
                            if ((uVar26 & 0x4000) == 0) {
                              uStack_3cc = uStack_3cc & 0xc7ff;
                            }
                            else {
                              uStack_3cc = uStack_3cc ^ (uStack_3cc ^ uVar26) & 0x3800;
                            }
                            uStack_3cc = uStack_3cc ^
                                         (uStack_3cc ^
                                         *(ushort *)
                                          ((longlong)puStack_3f0 + (ulonglong)(uVar31 & 0xffff) + 2)
                                         ) & 0x7ff;
                            break;
                          }
                          if (*(ushort *)((ulonglong)uVar31 + (longlong)puStack_3f0) < 0x400) break;
                          uStack_3f6 = uStack_3f6 | 1;
                          uStack_3dc = (short)uVar29 - 1;
                          uVar29 = (ulonglong)uStack_3dc;
                        } while (uStack_3dc != 0);
                      }
                      iVar43 = 0;
                      if ((*(byte *)puStack_3f0 & 0x40) == 0) {
                        uStack_3d2 = 0;
                        uStack_3d0 = 0;
                      }
                      else {
                        uStack_3d2 = (undefined2)uVar30;
                        uStack_3d0 = (undefined2)(uVar30 >> 0x10);
                        uStack_3f4 = uVar30 + 0xe;
                        *(undefined8 *)(puVar34 + -8) = 0x102a1d;
                        puVar21 = (ulonglong *)func_0x(&uStack_3f6);
                        uVar44 = *puVar21;
                        uVar26 = (ushort)(uVar44 >> 0x30);
                        if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
                          if ((uVar44 & 0x4000000000000000) == 0) {
                            uVar26 = uVar26 & 0xdfff;
                          }
                          else {
                            uVar26 = uVar26 | 0x2000;
                          }
                        }
                        if (uVar26 == 0xfffc) {
                          iVar43 = (int)((uVar44 >> 0x20 & 0xffff) >> 5);
                        }
                        uVar30 = uStack_3f4 + iVar43;
                        uStack_3f4 = uVar30;
                      }
                      if ((pbStack_3da != (byte *)0x0) &&
                         (pbStack_3da < (byte *)((ulonglong)uVar30 + (longlong)puStack_3f0))) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           (((lVar17 = *(longlong *)
                                        (*(longlong *)
                                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                          (ulonglong)*_DAT_ * 8) + 8 +
                                        (ulonglong)*_DAT_), lVar17 != 0 &&
                             (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                            (*(char *)(lVar17 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar34 + -8) = 0x102b0c;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x102b32;
                            (*_DAT_)(1,0xa73c28,0xb938f8,0x877);
                          }
                        }
                        puVar37 = puStack_3f0;
                        *(undefined8 *)(puVar34 + -8) = 0x102b40;
                        func_0x(puVar37,0x12);
                        uVar30 = uStack_3f4;
                      }
                      if (0x3f3b < uVar30 - 1) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           ((lVar17 = *(longlong *)
                                       (*(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8 +
                                       (ulonglong)*_DAT_), lVar17 != 0 &&
                            ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                             (*(char *)(lVar17 + 0x499) != '\0')))))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar34 + -8) = 0x102bce;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x102bf4;
                            (*_DAT_)(1,0xa73c28,0xb938f8,0x87c);
                          }
                        }
                        puVar37 = puStack_3f0;
                        *(undefined8 *)(puVar34 + -8) = 0x102c02;
                        func_0x(puVar37,5);
                      }
                    }
LAB_:
                    *(undefined8 *)(puVar34 + -8) = 0x102c0b;
                    func_0x(&uStack_3f6);
                    bVar22 = *(byte *)puStack_3f0;
                    if ((bVar22 >> 6 & 1) != 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x102c2d;
                      func_0x(&uStack_3f6,auStack_128);
                    }
                    if ((uStack_3f6 & 1) != 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x102c45;
                      puVar18 = (undefined4 *)func_0x(&uStack_3f6,0x400,aiStack_398);
                      uStack_310 = *puVar18;
                      uStack_30c = *(undefined2 *)(puVar18 + 1);
                      uStack_30a = *(undefined2 *)((longlong)puVar18 + 6);
                    }
                    if ((*(byte *)puStack_3f0 & 0x20) == 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x102c75;
                      func_0x(&uStack_3f6);
                    }
                    puVar37 = puStack_3f0;
                    uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                    *(undefined8 *)(puVar34 + -8) = 0x102c85;
                    iVar43 = func_0x(&uStack_3f6);
                    uVar26 = uStack_3dc;
                    puVar42 = puStack_3f0;
                    if (iVar43 == 0) {
                      uVar28 = (uint)uStack_3dc;
                      puVar39 = (ushort *)((longlong)puStack_3f0 + (ulonglong)uStack_3e8._4_4_);
                      uVar30 = uStack_3e8._4_4_ + 2 + uVar28 * 2;
                      uVar31 = 0;
                      if (*puVar39 != 0) {
                        do {
                          uVar23 = uVar31 & 0xffff;
                          uVar29 = (ulonglong)uVar31;
                          uVar31 = uVar31 + 1;
                          puVar39[(ulonglong)uVar23 + 1] =
                               puVar39[(ulonglong)uVar23 + 1] ^
                               (puVar39[uVar29 + 1] + 2 ^ puVar39[(ulonglong)uVar23 + 1]) & 0x7fff;
                          ppbVar50 = ppbStack_3a8;
                        } while (uVar31 < *puVar39);
                      }
                      pbVar47 = (byte *)((ulonglong)uVar30 + (longlong)puStack_3f0);
                      iVar43 = uStack_3f4 - uVar30;
                      pbVar25 = (byte *)((ulonglong)uVar30 + 2 + (longlong)puStack_3f0);
                      *(undefined8 *)(puVar34 + -8) = 0x102d5d;
                      func_0x(pbVar25,pbVar47,iVar43);
                      uStack_3f4 = uStack_3f4 + 2;
                      uStack_3e0 = uStack_3e0 + 2;
                      uVar30 = uStack_3e0;
                      if (uVar26 != 0) {
                        uVar30 = puVar39[(ulonglong)(uVar28 - 1) + 1] & 0x7fff;
                      }
                      uVar31 = uVar28 + 1;
                      if (uVar28 < uVar31) {
                        do {
                          uVar23 = uVar28 & 0xffff;
                          uVar28 = uVar28 + 1;
                          puVar39[(ulonglong)uVar23 + 1] = (ushort)uVar30 & 0x7fff;
                        } while (uVar28 < uVar31);
                      }
                      *puVar39 = *puVar39 + 1;
                      *(undefined8 *)(puVar34 + -8) = 0x102daa;
                      func_0x(&uStack_3f6);
                      iVar38 = 0;
                      uVar26 = *(ushort *)
                                ((longlong)puVar37 + (ulonglong)uStack_3dc * 2 + uVar44 + 2);
                      *(undefined8 *)(puVar34 + -8) = 0x102dc3;
                      func_0x(auStack_238);
                      *(undefined4 *)(puVar34 + 0x28) = 0;
                      *(uint **)(puVar34 + 0x20) = puVar32;
                      *(undefined8 *)(puVar34 + -8) = 0x102de4;
                      func_0x(auStack_248,ppbVar50,1,0);
                      *(int **)(puVar34 + 0x28) = &iStack_318;
                      *(undefined **)(puVar34 + 0x20) = auStack_248;
                      *(undefined8 *)(puVar34 + -8) = 0x102e19;
                      func_0x(&uStack_3ce,uVar26 & 0x7fff,0x1f9e);
                      iVar43 = iStack_318;
                    }
                    else {
                      uVar30 = uStack_3e0;
                      if (uStack_3dc != 0) {
                        uVar30 = *(ushort *)
                                  ((longlong)puStack_3f0 +
                                  (ulonglong)uStack_3dc * 2 + (ulonglong)uStack_3e8._4_4_) & 0x7fff;
                      }
                      uVar28 = *(ushort *)
                                ((longlong)puStack_3f0 +
                                (ulonglong)uStack_3dc * 2 + (ulonglong)uStack_3e8._4_4_ + 2) &
                               0x7fff;
                      if ((uVar30 < uStack_3e0) || (uVar28 < uVar30)) {
                        *(undefined8 *)(puVar34 + -8) = 0x102ccf;
                        func_0x(puVar42,7);
                      }
                      iVar38 = uVar28 - uVar30;
                      *(undefined8 *)(puVar34 + -8) = 0x102ce6;
                      iVar43 = func_0x(&uStack_3ce,puVar32,ppbVar50);
                    }
                    uStack_3f4 = (uStack_3f4 - iVar38) + iVar43;
                    uVar30 = uStack_3f4;
                    if ((uStack_3f6 & 1) != 0) {
                      *(ushort *)((longlong)puVar37 + (ulonglong)(uStack_3dc + 1) * 2 + uVar44 + 2)
                           = (ushort)uStack_3f4 | 0x8000;
                      uVar30 = (uStack_3f4 - aiStack_398[0]) - 2;
                    }
                    *(ushort *)((longlong)puVar37 + (ulonglong)uStack_3dc * 2 + uVar44 + 2) =
                         (ushort)uVar30 | 0x8000;
                    if (iVar43 == 0) {
                      uVar30 = (uint)uStack_3dc;
                      *(undefined8 *)(puVar34 + -8) = 0x102e6a;
                      func_0x(&uStack_3f6,uVar30 + 1,0);
                      if ((*(byte *)puStack_3f0 & 0x20) != 0) {
                        uStack_3dc = uStack_3dc + 1;
                        uStack_3f6 = uStack_3f6 & 0xfffd;
                        *(undefined8 *)(puVar34 + -8) = 0x102e89;
                        func_0x();
                      }
                    }
                    else {
                      uStack_3f6 = uStack_3f6 | 2;
                      *(undefined8 *)(puVar34 + -8) = 0x102e9c;
                      uStack_3ce = func_0x(&uStack_3f6,auStack_2b0);
                    }
                    iVar43 = aiStack_398[0];
                    if ((uStack_3f6 & 1) != 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x102ebf;
                      func_0x(&uStack_3f6,0x400,iVar43);
                    }
                    if ((bVar22 >> 6 & 1) != 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x102ed8;
                      func_0x(&uStack_3f6,auStack_128);
                    }
                  }
                  else {
                    if (uStack_3f4 == 0) {
                      uVar44 = (ulonglong)uStack_3e8 & 0xffffffff;
                      uStack_3f6 = 0;
                      uVar30 = (uint)uStack_3e8;
                      if ((*(byte *)puStack_3f0 & 0x10) != 0) {
                        uVar30 = (uint)uStack_3e8 + 2 +
                                 (*(ushort *)(uVar44 + (longlong)puStack_3f0) + 7 >> 3);
                        uVar44 = (ulonglong)uVar30;
                      }
                      uStack_3e8 = (longlong *)CONCAT44(uVar30,(uint)uStack_3e8);
                      uVar30 = (uint)uVar44;
                      if ((*(byte *)puStack_3f0 & 0x20) == 0) {
                        uStack_3dc = 0;
                        uStack_3f4 = uVar30;
                        uStack_3e0 = uVar30;
                      }
                      else {
                        puVar39 = (ushort *)(uVar44 + (longlong)puStack_3f0);
                        uStack_3dc = *puVar39;
                        if (uStack_3dc == 0) {
                          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                              (lVar17 = *(longlong *)
                                         (*(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8 +
                                         (ulonglong)*_DAT_), lVar17 != 0)) &&
                             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                              (*(char *)(lVar17 + 0x499) != '\0')))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar34 + -8) = 0x101de0;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x101e06;
                              (*_DAT_)(1,0xa73c28,0xb938f8,0x80f);
                            }
                          }
                          puVar37 = puStack_3f0;
                          *(undefined8 *)(puVar34 + -8) = 0x101e14;
                          func_0x(puVar37,3);
                          uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                        }
                        uStack_3e0 = (int)uVar44 + (uStack_3dc + 1) * 2;
                        if (0x1f9e < uStack_3e0) {
                          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                             ((lVar17 = *(longlong *)
                                         (*(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8 +
                                         (ulonglong)*_DAT_), lVar17 != 0 &&
                              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                               (*(char *)(lVar17 + 0x499) != '\0')))))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar34 + -8) = 0x101eb4;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x101eda;
                              (*_DAT_)(1,0xa73c28,0xb938f8,0x816);
                            }
                          }
                          puVar37 = puStack_3f0;
                          *(undefined8 *)(puVar34 + -8) = 0x101ee8;
                          func_0x(puVar37,4);
                          uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                        }
                        uVar29 = (ulonglong)uStack_3dc;
                        uStack_3f4 = puVar39[uVar29] & 0x7fff;
                        uVar30 = uStack_3f4;
                        uVar28 = uStack_3e0;
                        if (uStack_3f4 < uStack_3e0) {
                          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                              (lVar17 = *(longlong *)
                                         (*(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8 +
                                         (ulonglong)*_DAT_), lVar17 != 0)) &&
                             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                              (*(char *)(lVar17 + 0x499) != '\0')))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar34 + -8) = 0x101f89;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x101faf;
                              (*_DAT_)(1,0xa73c28,0xb938f8,0x81d);
                            }
                          }
                          puVar37 = puStack_3f0;
                          *(undefined8 *)(puVar34 + -8) = 0x101fbd;
                          func_0x(puVar37,4);
                          uVar29 = (ulonglong)uStack_3dc;
                          uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                          uVar30 = uStack_3f4;
                          uVar28 = uStack_3e0;
                        }
                        do {
                          puVar37 = puStack_3f0;
                          if (-1 < (short)puVar39[(ulonglong)((int)uVar29 - 1) + 1]) break;
                          uVar31 = uVar28;
                          if ((((int)uVar29 != 1) &&
                              (uVar31 = *(ushort *)
                                         ((longlong)puStack_3f0 + uVar29 * 2 + (uVar44 - 2)) &
                                        0x7fff, uVar31 < uVar28)) ||
                             ((*(ushort *)((longlong)puStack_3f0 + uVar29 * 2 + uVar44) & 0x7fff) <
                              uVar31)) {
                            *(undefined8 *)(puVar34 + -8) = 0x10201d;
                            func_0x(puVar37,7);
                            uVar29 = (ulonglong)uStack_3dc;
                            uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                            uVar30 = uStack_3f4;
                            uVar28 = uStack_3e0;
                          }
                          if ((uVar31 < uVar28) || (uVar30 < uVar31)) goto LAB_;
                          if (*(ushort *)((ulonglong)uVar31 + (longlong)puStack_3f0) == 5) {
                            uStack_3f6 = uStack_3f6 | 2;
                            uStack_3dc = (short)uVar29 - 1;
                            uStack_3ce = (undefined2)uVar31;
                            uVar26 = *(ushort *)
                                      ((longlong)puStack_3f0 + (ulonglong)(uVar31 & 0xffff) + 2);
                            if ((uVar26 & 0x4000) == 0) {
                              uStack_3cc = uStack_3cc & 0xc7ff;
                            }
                            else {
                              uStack_3cc = uStack_3cc ^ (uStack_3cc ^ uVar26) & 0x3800;
                            }
                            uStack_3cc = uStack_3cc ^
                                         (uStack_3cc ^
                                         *(ushort *)
                                          ((longlong)puStack_3f0 + (ulonglong)(uVar31 & 0xffff) + 2)
                                         ) & 0x7ff;
                            break;
                          }
                          if (*(ushort *)((ulonglong)uVar31 + (longlong)puStack_3f0) < 0x400) break;
                          uStack_3f6 = uStack_3f6 | 1;
                          uStack_3dc = (short)uVar29 - 1;
                          uVar29 = (ulonglong)uStack_3dc;
                        } while (uStack_3dc != 0);
                      }
                      iVar43 = 0;
                      if ((*(byte *)puStack_3f0 & 0x40) == 0) {
                        uStack_3d2 = 0;
                        uStack_3d0 = 0;
                      }
                      else {
                        uStack_3d2 = (undefined2)uVar30;
                        uStack_3d0 = (undefined2)(uVar30 >> 0x10);
                        uStack_3f4 = uVar30 + 0xe;
                        *(undefined8 *)(puVar34 + -8) = 0x102120;
                        puVar21 = (ulonglong *)func_0x(&uStack_3f6);
                        uVar44 = *puVar21;
                        uVar26 = (ushort)(uVar44 >> 0x30);
                        if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
                          if ((uVar44 & 0x4000000000000000) == 0) {
                            uVar26 = uVar26 & 0xdfff;
                          }
                          else {
                            uVar26 = uVar26 | 0x2000;
                          }
                        }
                        if (uVar26 == 0xfffc) {
                          iVar43 = (int)((uVar44 >> 0x20 & 0xffff) >> 5);
                        }
                        uVar30 = uStack_3f4 + iVar43;
                        uStack_3f4 = uVar30;
                      }
                      if ((pbStack_3da != (byte *)0x0) &&
                         (pbStack_3da < (byte *)((ulonglong)uVar30 + (longlong)puStack_3f0))) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           (((lVar17 = *(longlong *)
                                        (*(longlong *)
                                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                          (ulonglong)*_DAT_ * 8) + 8 +
                                        (ulonglong)*_DAT_), lVar17 != 0 &&
                             (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                            (*(char *)(lVar17 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar34 + -8) = 0x10220f;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x102235;
                            (*_DAT_)(1,0xa73c28,0xb938f8);
                          }
                        }
                        puVar37 = puStack_3f0;
                        *(undefined8 *)(puVar34 + -8) = 0x102243;
                        func_0x(puVar37,0x12);
                        uVar30 = uStack_3f4;
                      }
                      if (0x3f3b < uVar30 - 1) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           ((lVar17 = *(longlong *)
                                       (*(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8 +
                                       (ulonglong)*_DAT_), lVar17 != 0 &&
                            ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                             (*(char *)(lVar17 + 0x499) != '\0')))))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar34 + -8) = 0x1022d1;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x1022f7;
                            (*_DAT_)(1,0xa73c28,0xb938f8);
                          }
                        }
                        puVar37 = puStack_3f0;
                        *(undefined8 *)(puVar34 + -8) = 0x102305;
                        func_0x(puVar37,5);
                      }
                    }
LAB_:
                    uVar30 = -*puVar32;
                    *(undefined8 *)(puVar34 + -8) = 0x102318;
                    func_0x(auStack_208);
                    uVar28 = *(byte *)puStack_3f0 >> 6 & 1;
                    uStack_380 = uVar28;
                    if ((*(byte *)puStack_3f0 >> 6 & 1) != 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x10233e;
                      func_0x(&uStack_3f6,auStack_208);
                    }
                    if ((*(byte *)puStack_3f0 & 0x20) == 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x102351;
                      func_0x(&uStack_3f6);
                    }
                    uVar26 = uStack_3dc;
                    uVar23 = (uint)uStack_3dc;
                    uVar31 = (uint)uStack_3dc;
                    if (uVar31 < uVar30) {
                      uVar10 = (uint)uStack_3dc;
                      puVar39 = (ushort *)((longlong)puStack_3f0 + (ulonglong)uStack_3e8._4_4_);
                      uVar23 = uStack_3e8._4_4_ + 2 + uVar31 * 2;
                      uVar41 = 0;
                      uVar11 = (uVar30 - uVar10) * 2;
                      if (*puVar39 != 0) {
                        do {
                          uVar28 = uVar41 & 0xffff;
                          uVar44 = (ulonglong)uVar41;
                          uVar41 = uVar41 + 1;
                          puVar39[(ulonglong)uVar28 + 1] =
                               puVar39[(ulonglong)uVar28 + 1] ^
                               ((short)uVar11 + puVar39[uVar44 + 1] ^ puVar39[(ulonglong)uVar28 + 1]
                               ) & 0x7fff;
                          uVar28 = uStack_380;
                        } while (uVar41 < *puVar39);
                      }
                      pbVar47 = (byte *)((longlong)puStack_3f0 + (ulonglong)uVar23);
                      iVar43 = uStack_3f4 - uVar23;
                      pbVar25 = (byte *)((longlong)puStack_3f0 +
                                        (ulonglong)uVar23 + (ulonglong)uVar11);
                      *(undefined8 *)(puVar34 + -8) = 0x1023dd;
                      func_0x(pbVar25,pbVar47,iVar43);
                      uStack_3f4 = uStack_3f4 + uVar11;
                      uStack_3e0 = uStack_3e0 + uVar11;
                      uVar23 = uStack_3e0;
                      if (uVar26 != 0) {
                        uVar23 = puVar39[(ulonglong)(uVar31 - 1) + 1] & 0x7fff;
                      }
                      do {
                        uVar11 = uVar31 & 0xffff;
                        uVar31 = uVar31 + 1;
                        puVar39[(ulonglong)uVar11 + 1] = (ushort)uVar23 & 0x7fff;
                      } while (uVar31 < uVar30);
                      *puVar39 = *puVar39 + (short)(uVar30 - uVar10);
                      *(undefined8 *)(puVar34 + -8) = 0x10241c;
                      iVar43 = func_0x(&uStack_3f6);
                      if (iVar43 != 0) {
                        *(undefined8 *)(puVar34 + -8) = 0x102430;
                        uStack_3ce = func_0x(&uStack_3f6,auStack_2b8);
                      }
                      uVar23 = uVar30 & 0xffff;
                      uStack_3dc = (ushort)uVar30;
                    }
                    puVar37 = puStack_3f0;
                    uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                    if (uVar23 < uVar30) {
                      uVar29 = (ulonglong)
                               (*(ushort *)((longlong)puStack_3f0 + (ulonglong)uVar23 * 2 + uVar44)
                               & 0x7fff);
                      iVar43 = 0;
LAB_:
                      uVar31 = uStack_3f4;
                      puVar39 = (ushort *)(uVar44 + (longlong)puStack_3f0);
                      *(undefined8 *)(puVar34 + -8) = 0x1024cc;
                      uVar12 = func_0x(uVar31,iVar43 + (int)uVar29);
                      pbVar25 = (byte *)((longlong)puStack_3f0 + uVar29 + (longlong)iVar43);
                      pbVar47 = (byte *)((longlong)puStack_3f0 + uVar29 + 1);
                      *(undefined8 *)(puVar34 + -8) = 0x1024e8;
                      func_0x(pbVar47,pbVar25,uVar12);
                      uVar30 = uVar30 - 1;
                      if ((int)uVar30 < (int)(uint)*puVar39) {
                        do {
                          uVar44 = (ulonglong)uVar30;
                          lVar17 = (longlong)(int)uVar30;
                          uVar30 = uVar30 + 1;
                          puVar39[(uVar44 & 0xffff) + 1] =
                               puVar39[(uVar44 & 0xffff) + 1] ^
                               ((puVar39[lVar17 + 1] - (short)iVar43) + 1 ^
                               puVar39[(uVar44 & 0xffff) + 1]) & 0x7fff;
                          uVar28 = uStack_380;
                        } while ((int)uVar30 < (int)(uint)*puVar39);
                      }
                      uStack_3f4 = uStack_3f4 + (1 - iVar43);
                      *(undefined8 *)(puVar34 + -8) = 0x102544;
                      iVar43 = func_0x(&uStack_3f6);
                      if (iVar43 != 0) {
                        *(undefined8 *)(puVar34 + -8) = 0x102558;
                        uStack_3ce = func_0x(&uStack_3f6,auStack_2b4);
                      }
                    }
                    else {
                      uVar31 = uStack_3e0;
                      if (uVar30 != 1) {
                        uVar31 = *(ushort *)
                                  ((longlong)puStack_3f0 + (longlong)(int)uVar30 * 2 + (uVar44 - 2))
                                 & 0x7fff;
                      }
                      uVar29 = (ulonglong)uVar31;
                      uVar23 = *(ushort *)
                                ((longlong)puStack_3f0 + (longlong)(int)uVar30 * 2 + uVar44) &
                               0x7fff;
                      if ((uVar31 < uStack_3e0) || (uVar23 < uVar31)) {
                        *(undefined8 *)(puVar34 + -8) = 0x10248e;
                        func_0x(puVar37,7);
                        uVar44 = (ulonglong)uStack_3e8 >> 0x20;
                      }
                      iVar43 = uVar23 - uVar31;
                      if (iVar43 != 1) goto LAB_;
                    }
                    *(byte *)(uVar29 + (longlong)puStack_3f0) = *(byte *)ppbStack_3a8;
                    if (uVar28 != 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x102583;
                      func_0x(&uStack_3f6,auStack_208);
                    }
                  }
                }
                else {
                  uVar28 = (uint)*(ushort *)((longlong)puVar32 + 6);
                  if ((*(ushort *)((longlong)puVar32 + 6) & 8) == 0) {
                    if (uStack_3f4 == 0) {
                      uStack_3f6 = 0;
                      uVar30 = (uint)uStack_3e8;
                      if ((*(byte *)puStack_3f0 & 0x10) != 0) {
                        uVar30 = (uint)uStack_3e8 + 2 +
                                 (*(ushort *)
                                   (((ulonglong)uStack_3e8 & 0xffffffff) + (longlong)puStack_3f0) +
                                  7 >> 3);
                      }
                      uStack_3e8 = (longlong *)CONCAT44(uVar30,(uint)uStack_3e8);
                      if ((*(byte *)puStack_3f0 & 0x20) == 0) {
                        uStack_3dc = 0;
                        uStack_3f4 = uVar30;
                        uStack_3e0 = uVar30;
                      }
                      else {
                        puVar39 = (ushort *)((ulonglong)uVar30 + (longlong)puStack_3f0);
                        uStack_3dc = *puVar39;
                        if (uStack_3dc == 0) {
                          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                              (lVar17 = *(longlong *)
                                         (*(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8 +
                                         (ulonglong)*_DAT_), lVar17 != 0)) &&
                             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                              (*(char *)(lVar17 + 0x499) != '\0')))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar34 + -8) = 0x101796;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x1017bc;
                              (*_DAT_)(1,0xa73c28,0xb938f8,0x80f);
                            }
                          }
                          puVar37 = puStack_3f0;
                          *(undefined8 *)(puVar34 + -8) = 0x1017ca;
                          func_0x(puVar37,3);
                        }
                        uStack_3e0 = uStack_3e8._4_4_ + 2 + (uint)uStack_3dc * 2;
                        if (0x1f9e < uStack_3e0) {
                          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                             ((lVar17 = *(longlong *)
                                         (*(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8 +
                                         (ulonglong)*_DAT_), lVar17 != 0 &&
                              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                               (*(char *)(lVar17 + 0x499) != '\0')))))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar34 + -8) = 0x101869;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x10188f;
                              (*_DAT_)(1,0xa73c28,0xb938f8,0x816);
                            }
                          }
                          puVar37 = puStack_3f0;
                          *(undefined8 *)(puVar34 + -8) = 0x10189d;
                          func_0x(puVar37,4);
                        }
                        uVar44 = (ulonglong)uStack_3dc;
                        uStack_3f4 = puVar39[uVar44] & 0x7fff;
                        uVar30 = uStack_3f4;
                        uVar28 = uStack_3e0;
                        if (uStack_3f4 < uStack_3e0) {
                          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                              (lVar17 = *(longlong *)
                                         (*(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8 +
                                         (ulonglong)*_DAT_), lVar17 != 0)) &&
                             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                              (*(char *)(lVar17 + 0x499) != '\0')))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar34 + -8) = 0x10193a;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x101960;
                              (*_DAT_)(1,0xa73c28,0xb938f8,0x81d);
                            }
                          }
                          puVar37 = puStack_3f0;
                          *(undefined8 *)(puVar34 + -8) = 0x10196e;
                          func_0x(puVar37,4);
                          uVar44 = (ulonglong)uStack_3dc;
                          uVar30 = uStack_3f4;
                          uVar28 = uStack_3e0;
                        }
                        do {
                          puVar37 = puStack_3f0;
                          if (-1 < (short)puVar39[(ulonglong)((int)uVar44 - 1) + 1]) break;
                          uVar31 = uVar28;
                          if ((((int)uVar44 != 1) &&
                              (uVar31 = *(ushort *)
                                         ((longlong)puStack_3f0 +
                                         uVar44 * 2 + (((ulonglong)uStack_3e8 >> 0x20) - 2)) &
                                        0x7fff, uVar31 < uVar28)) ||
                             ((*(ushort *)
                                ((longlong)puStack_3f0 +
                                uVar44 * 2 + ((ulonglong)uStack_3e8 >> 0x20)) & 0x7fff) < uVar31)) {
                            *(undefined8 *)(puVar34 + -8) = 0x1019ca;
                            func_0x(puVar37,7);
                            uVar44 = (ulonglong)uStack_3dc;
                            uVar30 = uStack_3f4;
                            uVar28 = uStack_3e0;
                          }
                          if ((uVar31 < uVar28) || (uVar30 < uVar31)) goto LAB_;
                          if (*(ushort *)((ulonglong)uVar31 + (longlong)puStack_3f0) == 5) {
                            uStack_3f6 = uStack_3f6 | 2;
                            uStack_3dc = (short)uVar44 - 1;
                            uStack_3ce = (undefined2)uVar31;
                            uVar26 = *(ushort *)
                                      ((longlong)puStack_3f0 + (ulonglong)(uVar31 & 0xffff) + 2);
                            if ((uVar26 & 0x4000) == 0) {
                              uStack_3cc = uStack_3cc & 0xc7ff;
                            }
                            else {
                              uStack_3cc = uStack_3cc ^ (uVar26 ^ uStack_3cc) & 0x3800;
                            }
                            uStack_3cc = uStack_3cc ^
                                         (uStack_3cc ^
                                         *(ushort *)
                                          ((longlong)puStack_3f0 + (ulonglong)(uVar31 & 0xffff) + 2)
                                         ) & 0x7ff;
                            break;
                          }
                          if (*(ushort *)((ulonglong)uVar31 + (longlong)puStack_3f0) < 0x400) break;
                          uStack_3f6 = uStack_3f6 | 1;
                          uStack_3dc = (short)uVar44 - 1;
                          uVar44 = (ulonglong)uStack_3dc;
                        } while (uStack_3dc != 0);
                      }
                      if ((*(byte *)puStack_3f0 & 0x40) == 0) {
                        uStack_3d2 = 0;
                        uStack_3d0 = 0;
                      }
                      else {
                        uStack_3d2 = (undefined2)uVar30;
                        uStack_3d0 = (undefined2)(uVar30 >> 0x10);
                        uStack_3f4 = uVar30 + 0xe;
                        *(undefined8 *)(puVar34 + -8) = 0x101ab1;
                        puVar21 = (ulonglong *)func_0x(&uStack_3f6);
                        iVar43 = 0;
                        uVar44 = *puVar21;
                        uVar26 = (ushort)(uVar44 >> 0x30);
                        if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
                          if ((uVar44 & 0x4000000000000000) == 0) {
                            uVar26 = uVar26 & 0xdfff;
                          }
                          else {
                            uVar26 = uVar26 | 0x2000;
                          }
                        }
                        if (uVar26 == 0xfffc) {
                          iVar43 = (int)((uVar44 >> 0x20 & 0xffff) >> 5);
                        }
                        uVar30 = uStack_3f4 + iVar43;
                        uStack_3f4 = uVar30;
                      }
                      if ((pbStack_3da != (byte *)0x0) &&
                         (pbStack_3da < (byte *)((ulonglong)uVar30 + (longlong)puStack_3f0))) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           (((lVar17 = *(longlong *)
                                        (*(longlong *)
                                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                          (ulonglong)*_DAT_ * 8) + 8 +
                                        (ulonglong)*_DAT_), lVar17 != 0 &&
                             (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                            (*(char *)(lVar17 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar34 + -8) = 0x101ba0;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x101bc6;
                            (*_DAT_)(1,0xa73c28,0xb938f8);
                          }
                        }
                        puVar37 = puStack_3f0;
                        *(undefined8 *)(puVar34 + -8) = 0x101bd4;
                        func_0x(puVar37,0x12);
                        uVar30 = uStack_3f4;
                      }
                      if (0x3f3b < uVar30 - 1) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           ((lVar17 = *(longlong *)
                                       (*(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8 +
                                       (ulonglong)*_DAT_), lVar17 != 0 &&
                            ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                             (*(char *)(lVar17 + 0x499) != '\0')))))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar34 + -8) = 0x101c62;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x101c88;
                            (*_DAT_)(1,0xa73c28,0xb938f8);
                          }
                        }
                        puVar37 = puStack_3f0;
                        *(undefined8 *)(puVar34 + -8) = 0x101c96;
                        func_0x(puVar37,5);
                      }
                    }
LAB_:
                    uVar30 = *puVar32 + 1;
                    if ((uint)uStack_3e8 < uVar30) {
                      iVar43 = uVar30 - (uint)uStack_3e8;
                      *(undefined8 *)(puVar34 + -8) = 0x101cb7;
                      func_0x(&uStack_3f6,0,iVar43);
                      if ((1 << (*(byte *)puStack_3f0 & 0xe) & 0x1105U) != 0) {
                        *(short *)((longlong)puStack_3f0 + 2) = (short)uVar30;
                      }
                      uStack_3e8 = (longlong *)CONCAT44(uStack_3e8._4_4_,uVar30);
                    }
                    if (ppbVar50 != (byte **)0x0) {
                      *(byte *)((longlong)(int)*puVar32 + (longlong)puStack_3f0) = *(byte *)ppbVar50
                      ;
                    }
                  }
                  else {
                    uVar30 = uVar30 + 1;
                    bVar22 = *(byte *)ppbVar50;
                    if ((uint)uStack_3e8 < uVar30) {
                      iVar43 = uVar30 - (uint)uStack_3e8;
                      *(undefined8 *)(puVar34 + -8) = 0x101668;
                      func_0x(&uStack_3f6,0,iVar43);
                      if ((1 << (*(byte *)puStack_3f0 & 0xe) & 0x1105U) != 0) {
                        *(short *)((longlong)puStack_3f0 + 2) = (short)uVar30;
                      }
                      uStack_3e8 = (longlong *)CONCAT44(uStack_3e8._4_4_,uVar30);
                      uVar28 = (uint)*(byte *)((longlong)puVar32 + 6);
                    }
                    if (bVar22 == 0) {
                      *(byte *)(lVar17 + (longlong)puStack_3f0) =
                           *(byte *)((longlong)puStack_3f0 + lVar17) & ~(byte)(1 << (uVar28 & 7));
                    }
                    else {
                      *(byte *)(lVar17 + (longlong)puStack_3f0) =
                           *(byte *)((longlong)puStack_3f0 + lVar17) | (byte)(1 << (uVar28 & 7));
                    }
                  }
                }
              }
              else {
                *(undefined8 *)(puVar34 + 0x20) = 0x7f0108;
                *(undefined8 *)(puVar34 + -8) = 0x10162b;
                (*_DAT_)(1,0xbf4f60,0xc218a0);
              }
            }
            uStack_3b4 = uStack_3b4 + 1;
            ppbVar36 = ppbStack_388;
            puVar32 = puVar32 + 0x14;
            lVar24 = lStack_308;
            uVar30 = auStack_3b0[0];
          } while (uStack_3b4 < (uint)uStack_390);
        }
        uVar28 = uStack_3b8;
        puVar39 = (ushort *)0x0;
        do {
          uVar31 = uVar30;
          if (uVar31 == 0) goto LAB_;
          uVar44 = (ulonglong)uVar31;
          uVar30 = uVar31 - 1;
        } while (*(int *)(ppbStack_388 + (ulonglong)(uVar31 - 1) * 4 + 1) == 0);
        uStack_3dc = (ushort)uVar31;
        uStack_3f4 = uStack_3e8._4_4_ + 2 + uVar31 * 2;
        *(byte *)puStack_3f0 = *(byte *)puStack_3f0 | 0x20;
        if (uStack_3f4 <= uStack_3b8) {
          puVar39 = (ushort *)((ulonglong)uStack_3e8._4_4_ + (longlong)puStack_3f0);
          *puVar39 = uStack_3dc;
        }
        uStack_3e0 = uStack_3f4;
        if (uVar31 != 0) {
          puVar32 = (uint *)((longlong)ppbStack_388 + 0xc);
          do {
            puVar39 = puVar39 + 1;
            uVar30 = puVar32[-1];
            uVar29 = (ulonglong)uStack_3f4;
            uStack_3f4 = uStack_3f4 + uVar30;
            pbVar47 = (byte *)(uVar29 + (longlong)puStack_3f0);
            if ((uStack_3f4 <= uVar28) && (uStack_3f4 < 0x1f9f)) {
              *puVar39 = (ushort)((*puVar32 & 1) << 0xf) | (ushort)uStack_3f4 & 0x7fff;
              uVar46 = *(undefined8 *)(puVar32 + -3);
              *(undefined8 *)(puVar34 + -8) = 0x10311d;
              func_0x(pbVar47,uVar30,uVar46,uVar30);
            }
            puVar32 = puVar32 + 8;
            uVar44 = uVar44 - 1;
          } while (uVar44 != 0);
        }
      }
    }
    else {
      if (bVar6) {
        uVar46 = 0x11eb730;
        uVar20 = 0x11ddc98;
      }
      else {
        uVar20 = 0x11ddc60;
      }
      uStack_290 = 0;
      if ((bVar22 & 1) == 0) {
        uVar46 = uVar20;
      }
      *(longlong *)(puVar35 + lVar16 + 0x40) = param_1 + 0x238;
      *(undefined **)(puVar35 + lVar16 + 0x38) = auStack_2ac;
      *(uint *)(puVar35 + lVar16 + 0x30) = uVar30;
      uStack_298 = uVar46;
      *(undefined4 *)(puVar35 + lVar16 + 0x28) = 0x1f9e;
      *(undefined **)(puVar35 + lVar16 + 0x20) = puVar1;
      *(undefined8 *)(puVar35 + lVar16 + -8) = 0x103687;
      func_0x(&lStack_2f8,&ppbStack_378,2,&sStack_3f8);
    }
LAB_:
    *(undefined8 *)(puVar34 + -8) = 0x10368f;
    func_0x(lVar24);
    puVar35 = puVar34;
code_r0x00103695:
    uVar44 = (ulonglong)uStack_3f4;
  }
  else {
    puVar32 = *(uint **)(*(longlong *)(param_3[0xe] + 0x28) + param_4);
    puStack_3f0 = puVar32;
    if ((*(byte *)puVar32 & 1) == 0) {
      sStack_3f8 = 0;
      uStack_3d2 = 0;
      uStack_3d0 = 0;
      uVar29 = (ulonglong)*(ushort *)(lVar17 + 0xb8);
      switch(*(byte *)puVar32 & 0xe) {
      default:
        uVar29 = (ulonglong)*(ushort *)((longlong)puVar32 + 2);
        if (0x1f9d < *(ushort *)((longlong)puVar32 + 2) - 1) {
          *(undefined8 *)(puVar35 + -8) = 0x1005e2;
          func_0x(puVar32,6);
          uVar44 = (ulonglong)uStack_3f4;
        }
        break;
      case 4:
        uVar29 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar29 = 1;
      }
      uStack_3e8 = (longlong *)CONCAT44(uStack_3e8._4_4_,(int)uVar29);
    }
    else {
      sStack_3f8 = 1;
      bVar22 = *(byte *)puVar32;
      switch(bVar22 & 0x1c) {
      default:
        if ((char)*(byte *)((longlong)puVar32 + 1) < '\0') {
          sVar9 = 3;
          uStack_3e0 = 3;
          uStack_3f6 = (*(ushort *)((longlong)puVar32 + 1) & 0x7f) << 8 |
                       *(ushort *)((longlong)puVar32 + 1) >> 8;
        }
        else {
          sVar9 = 2;
          uStack_3f6 = (ushort)*(byte *)((longlong)puVar32 + 1);
          uStack_3e0 = 2;
        }
        uStack_3dc = ((ushort)(uStack_3f6 + 1) >> 1) + sVar9;
        if (uStack_3f6 < 0x1f) {
          uStack_3c8 = 0;
        }
        else {
          uStack_3c8 = 0;
          uVar29 = 0;
          uStack_3e0 = CONCAT22((short)((int)(uStack_3f6 - 1) / 0x1e),(undefined2)uStack_3e0);
        }
        break;
      case 4:
        if (((bVar22 & 0x1c) == 4) && ((bVar22 & 2) != 0)) {
          uVar44 = 0xf;
          uStack_3e0 = 0;
          uStack_3f4 = 0xf;
          uVar29 = 0;
          uStack_3f6 = 0;
          uStack_3dc = 0;
          uStack_3d2 = 0;
          uStack_3c8 = 1;
        }
        else {
          uStack_3e0 = 0;
          uVar44 = 1;
          uStack_3f6 = 0;
          uVar29 = 0;
          uStack_3dc = 0;
          uStack_3d2 = 0;
          uStack_3f4 = 1;
          uStack_3c8 = 0;
        }
        break;
      case 8:
        uStack_3e0 = 0;
        uVar44 = 9;
        uStack_3f6 = 0;
        uVar29 = 0;
        uStack_3dc = 0;
        uStack_3d2 = 0;
        uStack_3f4 = 9;
        uStack_3c8 = 0;
      }
    }
    if (sStack_3f8 == 0) {
      if ((int)uVar44 == 0) {
        uStack_3f6 = 0;
        uVar28 = (uint)uVar29;
        uVar44 = uVar29;
        if ((*(byte *)puStack_3f0 & 0x10) != 0) {
          uVar28 = uVar28 + 2 + (*(ushort *)((longlong)puStack_3f0 + uVar29) + 7 >> 3);
          uVar44 = (ulonglong)uVar28;
        }
        uStack_3e8 = (longlong *)CONCAT44(uVar28,(uint)uStack_3e8);
        if ((*(byte *)puStack_3f0 & 0x20) == 0) {
          uStack_3dc = 0;
          uStack_3f4 = (uint)uVar44;
          uStack_3e0 = (uint)uVar44;
        }
        else {
          puVar39 = (ushort *)(uVar44 + (longlong)puStack_3f0);
          uStack_3dc = *puVar39;
          if (uStack_3dc == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar17 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar17 != 0)) &&
               ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar35 + -8) = 0x10070d;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar35 + 0x20) = 0;
                *(undefined8 *)(puVar35 + -8) = 0x100730;
                (*_DAT_)(1,0xa73c28,0xb938f8,0x80f);
              }
            }
            puVar32 = puStack_3f0;
            *(undefined8 *)(puVar35 + -8) = 0x10073e;
            func_0x(puVar32,3);
          }
          uStack_3e0 = uStack_3e8._4_4_ + (uStack_3dc + 1) * 2;
          if (0x1f9e < uStack_3e0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar17 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar17 != 0 &&
                ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                 (*(char *)(lVar17 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar35 + -8) = 0x1007d7;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar35 + 0x20) = 0;
                *(undefined8 *)(puVar35 + -8) = 0x1007fa;
                (*_DAT_)(1,0xa73c28,0xb938f8,0x816);
              }
            }
            puVar32 = puStack_3f0;
            *(undefined8 *)(puVar35 + -8) = 0x100808;
            func_0x(puVar32,4);
          }
          uStack_3f4 = puVar39[uStack_3dc] & 0x7fff;
          uVar44 = (ulonglong)uStack_3f4;
          if (uStack_3f4 < uStack_3e0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar17 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar17 != 0)) &&
               ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar35 + -8) = 0x10089d;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar35 + 0x20) = 0;
                *(undefined8 *)(puVar35 + -8) = 0x1008c2;
                (*_DAT_)(1,0xa73c28,0xb938f8,0x81d);
              }
            }
            puVar32 = puStack_3f0;
            *(undefined8 *)(puVar35 + -8) = 0x1008d0;
            func_0x(puVar32,4);
            uVar44 = (ulonglong)uStack_3f4;
          }
          do {
            puVar32 = puStack_3f0;
            if (-1 < (short)puVar39[(ulonglong)(uStack_3dc - 1) + 1]) break;
            uVar28 = uStack_3e0;
            if (((uStack_3dc != 1) &&
                (uVar28 = *(ushort *)
                           ((longlong)puStack_3f0 +
                           (ulonglong)uStack_3dc * 2 + (((ulonglong)uStack_3e8 >> 0x20) - 2)) &
                          0x7fff, uVar28 < uStack_3e0)) ||
               ((*(ushort *)
                  ((longlong)puStack_3f0 +
                  (ulonglong)uStack_3dc * 2 + ((ulonglong)uStack_3e8 >> 0x20)) & 0x7fff) < uVar28))
            {
              *(undefined8 *)(puVar35 + -8) = 0x100926;
              func_0x(puVar32,7);
              uVar44 = (ulonglong)uStack_3f4;
            }
            if ((uVar28 < uStack_3e0) || ((uint)uVar44 < uVar28)) goto code_r0x00100bf7;
            if (*(ushort *)((ulonglong)uVar28 + (longlong)puStack_3f0) == 5) {
              uStack_3f6 = uStack_3f6 | 2;
              uStack_3dc = uStack_3dc - 1;
              uStack_3ce = (undefined2)uVar28;
              uVar26 = *(ushort *)((longlong)puStack_3f0 + (ulonglong)(uVar28 & 0xffff) + 2);
              uVar27 = uStack_3cc & 0xc7ff;
              if ((uVar26 & 0x4000) != 0) {
                uVar27 = (uStack_3cc ^ uVar26) & 0x3800 ^ uStack_3cc;
              }
              uStack_3cc = (uVar27 ^ uVar26) & 0x7ff ^ uVar27;
              break;
            }
            if (*(ushort *)((ulonglong)uVar28 + (longlong)puStack_3f0) < 0x400) break;
            uStack_3f6 = uStack_3f6 | 1;
            uStack_3dc = uStack_3dc - 1;
          } while (uStack_3dc != 0);
        }
        if ((*(byte *)puStack_3f0 & 0x40) == 0) {
          uStack_3d2 = 0;
          uStack_3d0 = 0;
        }
        else {
          uStack_3d2 = (undefined2)uVar44;
          uStack_3d0 = (undefined2)(uVar44 >> 0x10);
          uStack_3f4 = (int)uVar44 + 0xe;
          *(undefined8 *)(puVar35 + -8) = 0x1009fe;
          puVar21 = (ulonglong *)func_0x(&uStack_3f6);
          uVar44 = *puVar21;
          uVar28 = 0;
          uVar27 = (ushort)(uVar44 >> 0x30);
          uVar26 = uVar27;
          if ((((uint)(int)(short)uVar27 >> 1 ^ (int)(short)uVar27) & 0x2000) != 0) {
            uVar26 = uVar27 & 0xdfff;
            if ((uVar44 & 0x4000000000000000) != 0) {
              uVar26 = uVar27 | 0x2000;
            }
          }
          if (uVar26 == 0xfffc) {
            uVar28 = ((uint)(uVar44 >> 0x20) & 0xffff) >> 5;
          }
          uStack_3f4 = uStack_3f4 + uVar28;
          uVar44 = (ulonglong)uStack_3f4;
        }
        if ((pbStack_3da != (byte *)0x0) && (pbStack_3da < (byte *)(uVar44 + (longlong)puStack_3f0))
           ) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar17 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar17 != 0 &&
               (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar35 + -8) = 0x100b01;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar35 + 0x20) = 0;
              *(undefined8 *)(puVar35 + -8) = 0x100b24;
              (*_DAT_)(1,0xa73c28,0xb938f8,0x877);
            }
          }
          puVar32 = puStack_3f0;
          *(undefined8 *)(puVar35 + -8) = 0x100b32;
          func_0x(puVar32,0x12);
          uVar44 = (ulonglong)uStack_3f4;
        }
        if (0x3f3b < (int)uVar44 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar35 + -8) = 0x100bc0;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(puVar35 + 0x20) = 0;
              *(undefined8 *)(puVar35 + -8) = 0x100be5;
              (*_DAT_)(1,0xa73c28,0xb938f8,0x87c);
            }
          }
          puVar32 = puStack_3f0;
          *(undefined8 *)(puVar35 + -8) = 0x100bf3;
          func_0x(puVar32,5);
          uVar44 = (ulonglong)uStack_3f4;
        }
      }
code_r0x00100bf7:
      if (8 < (uint)uVar44) goto code_r0x00100c3a;
      bVar22 = *(byte *)puStack_3f0 & 0xe;
joined_r0x00100c2e:
      if ((bVar22 != 0) && (bVar22 != 0xc)) goto code_r0x00100c3a;
      uVar28 = 9;
    }
    else {
      if ((int)uVar44 == 0) {
        *(undefined8 *)(puVar35 + -8) = 0x100c1b;
        func_0x(&uStack_3f6);
        uVar44 = (ulonglong)uStack_3f4;
      }
      if ((uint)uVar44 < 9) {
        bVar22 = *(byte *)puStack_3f0 & 0x1c;
        goto joined_r0x00100c2e;
      }
code_r0x00100c3a:
      uVar28 = (uint)uVar44;
    }
    uVar31 = (uint)uVar44;
    if (uVar30 < uVar28) {
      if (sStack_3f8 == 0) {
        if (uVar31 == 0) {
          uVar28 = 0;
          uVar44 = (ulonglong)uStack_3e8 & 0xffffffff;
          uStack_3f6 = 0;
          uVar30 = (uint)uStack_3e8;
          if ((*(byte *)puStack_3f0 & 0x10) != 0) {
            uVar30 = (uint)uStack_3e8 + 2 + (*(ushort *)(uVar44 + (longlong)puStack_3f0) + 7 >> 3);
            uVar44 = (ulonglong)uVar30;
          }
          uStack_3e8 = (longlong *)CONCAT44(uVar30,(uint)uStack_3e8);
          if ((*(byte *)puStack_3f0 & 0x20) == 0) {
            uStack_3dc = 0;
            uStack_3f4 = (uint)uVar44;
            uStack_3e0 = (uint)uVar44;
          }
          else {
            puVar39 = (ushort *)(uVar44 + (longlong)puStack_3f0);
            uStack_3dc = *puVar39;
            if (uStack_3dc == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar17 != 0)) &&
                 ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar35 + -8) = 0x100d27;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar35 + 0x20) = 0;
                  *(undefined8 *)(puVar35 + -8) = 0x100d4a;
                  (*_DAT_)(1,0xa73c28,0xb938f8,0x80f);
                }
              }
              puVar32 = puStack_3f0;
              *(undefined8 *)(puVar35 + -8) = 0x100d58;
              func_0x(puVar32,3);
            }
            uStack_3e0 = uStack_3e8._4_4_ + 2 + (uint)uStack_3dc * 2;
            if (0x1f9e < uStack_3e0) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar17 != 0 &&
                  ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                   (*(char *)(lVar17 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar35 + -8) = 0x100df6;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar35 + 0x20) = 0;
                  *(undefined8 *)(puVar35 + -8) = 0x100e19;
                  (*_DAT_)(1,0xa73c28,0xb938f8,0x816);
                }
              }
              puVar32 = puStack_3f0;
              *(undefined8 *)(puVar35 + -8) = 0x100e27;
              func_0x(puVar32,4);
            }
            uStack_3f4 = puVar39[uStack_3dc] & 0x7fff;
            uVar44 = (ulonglong)uStack_3f4;
            uVar30 = uStack_3e0;
            if (uStack_3f4 < uStack_3e0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar17 != 0)) &&
                 ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar35 + -8) = 0x100ec2;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar35 + 0x20) = 0;
                  *(undefined8 *)(puVar35 + -8) = 0x100ee5;
                  (*_DAT_)(1,0xa73c28,0xb938f8,0x81d);
                }
              }
              puVar32 = puStack_3f0;
              *(undefined8 *)(puVar35 + -8) = 0x100ef3;
              func_0x(puVar32,4);
              uVar44 = (ulonglong)uStack_3f4;
              uVar30 = uStack_3e0;
            }
            do {
              puVar32 = puStack_3f0;
              if (-1 < (short)puVar39[(ulonglong)(uStack_3dc - 1) + 1]) break;
              uVar31 = uVar30;
              if (((uStack_3dc != 1) &&
                  (uVar31 = *(ushort *)
                             ((longlong)puStack_3f0 +
                             (ulonglong)uStack_3dc * 2 + (((ulonglong)uStack_3e8 >> 0x20) - 2)) &
                            0x7fff, uVar31 < uVar30)) ||
                 ((*(ushort *)
                    ((longlong)puStack_3f0 +
                    (ulonglong)uStack_3dc * 2 + ((ulonglong)uStack_3e8 >> 0x20)) & 0x7fff) < uVar31)
                 ) {
                *(undefined8 *)(puVar35 + -8) = 0x100f4e;
                func_0x(puVar32,7);
                uVar44 = (ulonglong)uStack_3f4;
                uVar30 = uStack_3e0;
              }
              if ((uVar31 < uVar30) || ((uint)uVar44 < uVar31)) goto code_r0x00101229;
              if (*(ushort *)((ulonglong)uVar31 + (longlong)puStack_3f0) == 5) {
                uStack_3f6 = uStack_3f6 | 2;
                uStack_3dc = uStack_3dc - 1;
                uStack_3ce = (undefined2)uVar31;
                uVar26 = *(ushort *)((longlong)puStack_3f0 + (ulonglong)(uVar31 & 0xffff) + 2);
                if ((uVar26 & 0x4000) == 0) {
                  uStack_3cc = uStack_3cc & 0xc7ff;
                }
                else {
                  uStack_3cc = uStack_3cc ^ (uStack_3cc ^ uVar26) & 0x3800;
                }
                uStack_3cc = (uStack_3cc ^
                             *(ushort *)((longlong)puStack_3f0 + (ulonglong)(uVar31 & 0xffff) + 2))
                             & 0x7ff ^ uStack_3cc;
                break;
              }
              if (*(ushort *)((ulonglong)uVar31 + (longlong)puStack_3f0) < 0x400) break;
              uStack_3f6 = uStack_3f6 | 1;
              uStack_3dc = uStack_3dc - 1;
            } while (uStack_3dc != 0);
          }
          if ((*(byte *)puStack_3f0 & 0x40) == 0) {
            uStack_3d2 = 0;
            uStack_3d0 = 0;
          }
          else {
            uStack_3d2 = (undefined2)uVar44;
            uStack_3d0 = (undefined2)(uVar44 >> 0x10);
            uStack_3f4 = (int)uVar44 + 0xe;
            *(undefined8 *)(puVar35 + -8) = 0x101037;
            puVar21 = (ulonglong *)func_0x(&uStack_3f6);
            uVar44 = *puVar21;
            uVar27 = (ushort)(uVar44 >> 0x30);
            uVar26 = uVar27;
            if ((((uint)(int)(short)uVar27 >> 1 ^ (int)(short)uVar27) & 0x2000) != 0) {
              uVar26 = uVar27 & 0xdfff;
              if ((uVar44 & 0x4000000000000000) != 0) {
                uVar26 = uVar27 | 0x2000;
              }
            }
            if (uVar26 == 0xfffc) {
              uVar28 = ((uint)(uVar44 >> 0x20) & 0xffff) >> 5;
            }
            uStack_3f4 = uStack_3f4 + uVar28;
            uVar44 = (ulonglong)uStack_3f4;
          }
          if ((pbStack_3da != (byte *)0x0) &&
             (pbStack_3da < (byte *)(uVar44 + (longlong)puStack_3f0))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar17 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar17 != 0 &&
                 (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar35 + -8) = 0x101135;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar35 + 0x20) = 0;
                *(undefined8 *)(puVar35 + -8) = 0x101158;
                (*_DAT_)(1,0xa73c28,0xb938f8,0x877);
              }
            }
            puVar32 = puStack_3f0;
            *(undefined8 *)(puVar35 + -8) = 0x101166;
            func_0x(puVar32,0x12);
            uVar44 = (ulonglong)uStack_3f4;
          }
          if (0x3f3b < (int)uVar44 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar17 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar17 != 0 &&
                ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                 (*(char *)(lVar17 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar35 + -8) = 0x1011f4;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar35 + 0x20) = 0;
                *(undefined8 *)(puVar35 + -8) = 0x101217;
                (*_DAT_)(1,0xa73c28,0xb938f8,0x87c);
              }
            }
            puVar32 = puStack_3f0;
            *(undefined8 *)(puVar35 + -8) = 0x101225;
            func_0x(puVar32,5);
            uVar44 = (ulonglong)uStack_3f4;
          }
        }
code_r0x00101229:
        uVar31 = (uint)uVar44;
        if (uVar31 < 9) {
          bVar22 = *(byte *)puStack_3f0 & 0xe;
joined_r0x00101260:
          if ((bVar22 == 0) || (bVar22 == 0xc)) {
            uVar31 = 9;
          }
        }
      }
      else {
        if (uVar31 == 0) {
          *(undefined8 *)(puVar35 + -8) = 0x10124d;
          func_0x(&uStack_3f6);
          uVar31 = uStack_3f4;
        }
        if (uVar31 < 9) {
          bVar22 = *(byte *)puStack_3f0 & 0x1c;
          goto joined_r0x00101260;
        }
      }
      *(undefined4 *)(puVar35 + 0x28) = 0x1f7c;
      *(uint *)(puVar35 + 0x20) = uVar31;
      *(undefined8 *)(puVar35 + -8) = 0x10128b;
      (*_DAT_)(5,0xb,0x10);
      goto code_r0x00103695;
    }
  }
  lVar17 = lStack_3a0;
  if (*(int *)(lStack_3a0 + 0x22c) != 0) {
    lVar24 = *(longlong *)(lStack_3a0 + 0x30);
    uVar30 = *(uint *)(lStack_3a0 + 0x47c);
    uVar12 = *(undefined4 *)(lStack_3a0 + 0x480);
    puVar4 = *(undefined8 **)(lStack_3a0 + -8);
    if ((uVar30 < *(uint *)(*(longlong *)(lVar24 + 8) + 0xb4)) &&
       ((((byte)*(undefined4 *)(puVar4 + 0x43) & 5) != 1 || ((*(byte *)(puVar4 + 0x5b) & 2) == 0))))
    {
      pcVar5 = *(code **)*puVar4;
      *(undefined8 *)(puVar35 + -8) = 0x1036e3;
      cVar8 = (*pcVar5)();
      if (cVar8 == '\0') {
        *(undefined4 *)(puVar35 + 0x28) = uVar12;
        *(uint *)(puVar35 + 0x20) = uVar30;
        *(undefined8 *)(puVar35 + -8) = 0x103707;
        func_0x(lVar24,0,&sStack_3f8,lVar17 + 200);
      }
      uVar44 = (ulonglong)uStack_3f4;
    }
  }
  auStack_20e[2] = 0;
  if (*(longlong *)(lVar17 + 0x180) != 0) {
    *(undefined8 *)(puVar35 + -8) = 0x103731;
    iVar43 = func_0x(lVar17 + -0x18,&sStack_3f8,auStack_228);
    if (iVar43 == 0) {
      auStack_20e[2] = 1;
    }
    goto LAB_;
  }
  uStack_390 = *(longlong *)(lVar17 + 0x30);
  puVar49 = auStack_20e;
  ppuVar51 = &puStack_218;
  iVar43 = *(int *)(**(longlong **)(*(longlong *)(uStack_390 + 8) + 0x160) + 0x1c);
  iVar38 = iVar43 + -1;
  if ((*(byte *)(*(longlong *)(uStack_390 + 8) + 0x106) & 0x40) == 0) {
    iVar38 = iVar43;
  }
  puStack_220 = puStack_3f0;
  if (sStack_3f8 == 0) {
    if ((int)uVar44 == 0) {
      uVar44 = (ulonglong)uStack_3e8 & 0xffffffff;
      uStack_3f6 = 0;
      uVar30 = (uint)uStack_3e8;
      if ((*(byte *)puStack_3f0 & 0x10) != 0) {
        uVar30 = (uint)uStack_3e8 + 2 + (*(ushort *)(uVar44 + (longlong)puStack_3f0) + 7 >> 3);
        uVar44 = (ulonglong)uVar30;
      }
      uStack_3e8 = (longlong *)CONCAT44(uVar30,(uint)uStack_3e8);
      if ((*(byte *)puStack_3f0 & 0x20) == 0) {
        uStack_3dc = 0;
        uStack_3f4 = (uint)uVar44;
        uStack_3e0 = (uint)uVar44;
      }
      else {
        puVar39 = (ushort *)(uVar44 + (longlong)puStack_3f0);
        uStack_3dc = *puVar39;
        if (uStack_3dc == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar17 != 0)) &&
             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar35 + -8) = 0x10386e;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar35 + 0x20) = 0;
              *(undefined8 *)(puVar35 + -8) = 0x103891;
              (*_DAT_)(1,0xa73c28,0xb938f8,0x80f);
            }
          }
          puVar32 = puStack_3f0;
          *(undefined8 *)(puVar35 + -8) = 0x10389f;
          func_0x(puVar32,3);
        }
        uStack_3e0 = uStack_3e8._4_4_ + (uStack_3dc + 1) * 2;
        if (0x1f9e < uStack_3e0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar35 + -8) = 0x103934;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar35 + 0x20) = 0;
              *(undefined8 *)(puVar35 + -8) = 0x103957;
              (*_DAT_)(1,0xa73c28,0xb938f8,0x816);
            }
          }
          puVar32 = puStack_3f0;
          *(undefined8 *)(puVar35 + -8) = 0x103965;
          func_0x(puVar32,4);
        }
        uStack_3f4 = puVar39[uStack_3dc] & 0x7fff;
        if (uStack_3f4 < uStack_3e0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar17 != 0)) &&
             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar35 + -8) = 0x1039f9;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar35 + 0x20) = 0;
              *(undefined8 *)(puVar35 + -8) = 0x103a1c;
              (*_DAT_)(1,0xa73c28,0xb938f8,0x81d);
            }
          }
          puVar32 = puStack_3f0;
          *(undefined8 *)(puVar35 + -8) = 0x103a2a;
          func_0x(puVar32,4);
        }
        uVar44 = (ulonglong)uStack_3f4;
        do {
          puVar32 = puStack_3f0;
          if (-1 < (short)puVar39[(ulonglong)(uStack_3dc - 1) + 1]) break;
          uVar30 = uStack_3e0;
          if (((uStack_3dc != 1) &&
              (uVar30 = *(ushort *)
                         ((longlong)puStack_3f0 +
                         (ulonglong)uStack_3dc * 2 + (((ulonglong)uStack_3e8 >> 0x20) - 2)) & 0x7fff
              , uVar30 < uStack_3e0)) ||
             ((*(ushort *)
                ((longlong)puStack_3f0 + (ulonglong)uStack_3dc * 2 + ((ulonglong)uStack_3e8 >> 0x20)
                ) & 0x7fff) < uVar30)) {
            *(undefined8 *)(puVar35 + -8) = 0x103a86;
            func_0x(puVar32,7);
            uVar44 = (ulonglong)uStack_3f4;
          }
          if ((uVar30 < uStack_3e0) || ((uint)uVar44 < uVar30)) goto LAB_;
          if (*(ushort *)((ulonglong)uVar30 + (longlong)puStack_3f0) == 5) {
            uStack_3f6 = uStack_3f6 | 2;
            uStack_3dc = uStack_3dc - 1;
            uStack_3ce = (undefined2)uVar30;
            uVar26 = *(ushort *)((longlong)puStack_3f0 + (ulonglong)(uVar30 & 0xffff) + 2);
            if ((uVar26 & 0x4000) == 0) {
              uStack_3cc = uStack_3cc & 0xc7ff;
            }
            else {
              uStack_3cc = uStack_3cc ^ (uStack_3cc ^ uVar26) & 0x3800;
            }
            uStack_3cc = (uStack_3cc ^
                         *(ushort *)((longlong)puStack_3f0 + (ulonglong)(uVar30 & 0xffff) + 2)) &
                         0x7ff ^ uStack_3cc;
            break;
          }
          if (*(ushort *)((ulonglong)uVar30 + (longlong)puStack_3f0) < 0x400) break;
          uStack_3f6 = uStack_3f6 | 1;
          uStack_3dc = uStack_3dc - 1;
        } while (uStack_3dc != 0);
      }
      if ((*(byte *)puStack_3f0 & 0x40) == 0) {
        uStack_3d2 = 0;
        uStack_3d0 = 0;
      }
      else {
        uStack_3d2 = (undefined2)uVar44;
        uStack_3d0 = (undefined2)(uVar44 >> 0x10);
        uStack_3f4 = (int)uVar44 + 0xe;
        *(undefined8 *)(puVar35 + -8) = 0x103b8c;
        puVar21 = (ulonglong *)func_0x(&uStack_3f6);
        iVar43 = 0;
        uVar44 = *puVar21;
        uVar27 = (ushort)(uVar44 >> 0x30);
        uVar26 = uVar27;
        if ((((uint)(int)(short)uVar27 >> 1 ^ (int)(short)uVar27) & 0x2000) != 0) {
          uVar26 = uVar27 & 0xdfff;
          if ((uVar44 & 0x4000000000000000) != 0) {
            uVar26 = uVar27 | 0x2000;
          }
        }
        if (uVar26 == 0xfffc) {
          iVar43 = (int)((uVar44 >> 0x20 & 0xffff) >> 5);
        }
        uStack_3f4 = uStack_3f4 + iVar43;
        uVar44 = (ulonglong)uStack_3f4;
      }
      if ((pbStack_3da != (byte *)0x0) && (pbStack_3da < (byte *)(uVar44 + (longlong)puStack_3f0)))
      {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar17 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar17 != 0 &&
             (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
            (*(char *)(lVar17 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar35 + -8) = 0x103c89;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar35 + 0x20) = 0;
            *(undefined8 *)(puVar35 + -8) = 0x103caf;
            (*_DAT_)(1,0xa73c28,0xb938f8,0x877);
          }
        }
        puVar32 = puStack_3f0;
        *(undefined8 *)(puVar35 + -8) = 0x103cbd;
        func_0x(puVar32,0x12);
        uVar44 = (ulonglong)uStack_3f4;
      }
      if (0x3f3b < (int)uVar44 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar17 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar17 != 0 &&
            ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
             (*(char *)(lVar17 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar35 + -8) = 0x103d47;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(puVar35 + 0x20) = 0;
            *(undefined8 *)(puVar35 + -8) = 0x103d89;
            (*_DAT_)(1,0xa73c28,0xb938f8,0x87c);
          }
        }
        puVar32 = puStack_3f0;
        *(undefined8 *)(puVar35 + -8) = 0x103d5a;
        func_0x(puVar32,5);
        uVar44 = (ulonglong)uStack_3f4;
      }
    }
LAB_:
    if (8 < (uint)uVar44) goto LAB_;
    bVar22 = *(byte *)puStack_3f0 & 0xe;
joined_r0x00103db1:
    if ((bVar22 != 0) && (bVar22 != 0xc)) goto LAB_;
    uStack_210 = 9;
  }
  else {
    if ((int)uVar44 == 0) {
      *(undefined8 *)(puVar35 + -8) = 0x103d99;
      func_0x(&uStack_3f6);
      uVar44 = (ulonglong)uStack_3f4;
    }
    if ((uint)uVar44 < 9) {
      bVar22 = *(byte *)puStack_3f0 & 0x1c;
      goto joined_r0x00103db1;
    }
LAB_:
    uStack_210 = (undefined2)uVar44;
  }
  uVar29 = 0;
  lVar17 = lStack_3a0;
  if ((iVar38 != 0) != 0) {
    do {
      puVar37 = (uint *)0x0;
      lVar17 = **(longlong **)(*(longlong *)(uStack_390 + 8) + 0x160);
      puVar32 = *(uint **)(lVar17 + 0x38);
      puVar42 = (uint *)(lVar17 + 0x30);
      if (puVar32 == puVar42) {
        puVar32 = puVar37;
      }
      puVar40 = puVar37;
      if (puVar32 != (uint *)0x0) {
        puVar40 = puVar32 + -0x58;
      }
      iVar43 = (int)uVar29;
      if (iVar43 != 0) {
        do {
          puVar32 = *(uint **)(puVar40 + 0x5a);
          if (*(uint **)(puVar40 + 0x5a) == puVar42) {
            puVar32 = puVar37;
          }
          puVar40 = puVar37;
          if (puVar32 != (uint *)0x0) {
            puVar40 = puVar32 + -0x58;
          }
          uVar29 = uVar29 - 1;
        } while (uVar29 != 0);
      }
      bVar22 = *(byte *)(puVar40 + 8);
      if (sStack_3f8 == 0) {
        uVar28 = *puVar40;
        if ((uVar28 & 0xc0000000) == 0x80000000) {
          *(undefined8 *)(puVar35 + -8) = 0x104690;
          iVar13 = func_0x(&uStack_3f6);
          if (iVar13 == 0) {
LAB_:
            puVar32 = (uint *)0x0;
            uStack_3c0 = 0;
            uVar30 = uStack_3c0;
          }
          else {
            *(undefined8 *)(puVar35 + -8) = 0x1046a8;
            puVar32 = (uint *)func_0x(&uStack_3ce,puVar40,&uStack_3c0,auStack_3b0);
            uVar30 = uStack_3c0;
          }
        }
        else {
          if (((bVar22 & 2) != 0) || ((*(byte *)((longlong)puVar40 + 6) & 0x10) != 0)) {
            if ((*(byte *)puStack_3f0 & 0x10) == 0) {
              if ((1 << (*(byte *)puStack_3f0 & 0xe) & 0x1105U) != 0) goto LAB_;
              uVar26 = 0;
              bVar6 = true;
LAB_:
              if ((bVar22 & 2) != 0) goto LAB_;
            }
            else {
              if ((int)(uint)uStack_3e8 <= (int)uVar28) {
LAB_:
                uVar26 = ~(*(ushort *)((longlong)puVar40 + 6) >> 4) & 1;
                bVar6 = false;
                goto LAB_;
              }
              if (*(ushort *)(((ulonglong)uStack_3e8 & 0xffffffff) + (longlong)puStack_3f0) <
                  *(ushort *)(puVar40 + 1)) goto LAB_;
              if ((bVar22 & 2) == 0) goto LAB_;
              uVar30 = *(ushort *)(puVar40 + 1) - 1;
              bVar6 = true;
              uVar26 = *(byte *)((longlong)puStack_3f0 +
                                ((ulonglong)uStack_3e8 & 0xffffffff) + (ulonglong)(uVar30 >> 3) + 2)
                       >> ((byte)uVar30 & 7) & 1;
LAB_:
              if (uVar26 != 0) {
                uStack_3c0 = 0;
                puVar32 = (uint *)0x0;
                uVar30 = uStack_3c0;
                goto LAB_;
              }
            }
            if ((!bVar6) && ((*(byte *)((longlong)puVar40 + 6) & 0x10) != 0)) {
              puVar32 = *(uint **)(puVar40 + 2) + 1;
              uVar30 = **(uint **)(puVar40 + 2);
              goto LAB_;
            }
          }
LAB_:
          if ((int)uVar28 < 0) {
            if ((int)uVar44 == 0) {
              uStack_3f6 = 0;
              uVar30 = (uint)uStack_3e8;
              if ((*(byte *)puStack_3f0 & 0x10) != 0) {
                uVar30 = (uint)uStack_3e8 + 2 +
                         (*(ushort *)(((ulonglong)uStack_3e8 & 0xffffffff) + (longlong)puStack_3f0)
                          + 7 >> 3);
              }
              uStack_3e8 = (longlong *)CONCAT44(uVar30,(uint)uStack_3e8);
              if ((*(byte *)puStack_3f0 & 0x20) == 0) {
                uStack_3dc = 0;
                uStack_3f4 = uVar30;
                uStack_3e0 = uVar30;
              }
              else {
                puVar39 = (ushort *)((ulonglong)uVar30 + (longlong)puStack_3f0);
                uStack_3dc = *puVar39;
                if (uStack_3dc == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar17 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar17 != 0)) &&
                     ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                      (*(char *)(lVar17 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar35 + -8) = 0x1040c9;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar35 + 0x20) = 0;
                      *(undefined8 *)(puVar35 + -8) = 0x1040ee;
                      (*_DAT_)(1,0xa73c28,0xb938f8,0x80f);
                    }
                  }
                  puVar32 = puStack_3f0;
                  *(undefined8 *)(puVar35 + -8) = 0x1040fc;
                  func_0x(puVar32,3);
                }
                uStack_3e0 = uStack_3e8._4_4_ + (uStack_3dc + 1) * 2;
                if (0x1f9e < uStack_3e0) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar17 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar17 != 0 &&
                      ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                       (*(char *)(lVar17 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar35 + -8) = 0x104192;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar35 + 0x20) = 0;
                      *(undefined8 *)(puVar35 + -8) = 0x1041b7;
                      (*_DAT_)(1,0xa73c28,0xb938f8,0x816);
                    }
                  }
                  puVar32 = puStack_3f0;
                  *(undefined8 *)(puVar35 + -8) = 0x1041c5;
                  func_0x(puVar32,4);
                }
                uStack_3f4 = puVar39[uStack_3dc] & 0x7fff;
                uVar30 = uStack_3f4;
                if (uStack_3f4 < uStack_3e0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar17 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar17 != 0)) &&
                     ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                      (*(char *)(lVar17 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar35 + -8) = 0x10425d;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar35 + 0x20) = 0;
                      *(undefined8 *)(puVar35 + -8) = 0x104282;
                      (*_DAT_)(1,0xa73c28,0xb938f8,0x81d);
                    }
                  }
                  puVar32 = puStack_3f0;
                  *(undefined8 *)(puVar35 + -8) = 0x104290;
                  func_0x(puVar32,4);
                  uVar30 = uStack_3f4;
                }
                do {
                  puVar32 = puStack_3f0;
                  if (-1 < (short)puVar39[(ulonglong)(uStack_3dc - 1) + 1]) break;
                  uVar28 = uStack_3e0;
                  if (((uStack_3dc != 1) &&
                      (uVar28 = *(ushort *)
                                 ((longlong)puStack_3f0 +
                                 (ulonglong)uStack_3dc * 2 + (((ulonglong)uStack_3e8 >> 0x20) - 2))
                                & 0x7fff, uVar28 < uStack_3e0)) ||
                     ((*(ushort *)
                        ((longlong)puStack_3f0 +
                        (ulonglong)uStack_3dc * 2 + ((ulonglong)uStack_3e8 >> 0x20)) & 0x7fff) <
                      uVar28)) {
                    *(undefined8 *)(puVar35 + -8) = 0x1042ef;
                    func_0x(puVar32,7);
                    uVar30 = uStack_3f4;
                  }
                  if ((uVar28 < uStack_3e0) || (uVar30 < uVar28)) goto LAB_;
                  if (*(ushort *)((ulonglong)uVar28 + (longlong)puStack_3f0) == 5) {
                    uStack_3f6 = uStack_3f6 | 2;
                    uStack_3dc = uStack_3dc - 1;
                    uStack_3ce = (undefined2)uVar28;
                    uVar26 = *(ushort *)((longlong)puStack_3f0 + (ulonglong)(uVar28 & 0xffff) + 2);
                    if ((uVar26 & 0x4000) == 0) {
                      uStack_3cc = uStack_3cc & 0xc7ff;
                    }
                    else {
                      uStack_3cc = uStack_3cc ^ (uStack_3cc ^ uVar26) & 0x3800;
                    }
                    uStack_3cc = uStack_3cc ^
                                 (uStack_3cc ^
                                 *(ushort *)
                                  ((longlong)puStack_3f0 + (ulonglong)(uVar28 & 0xffff) + 2)) &
                                 0x7ff;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar28 + (longlong)puStack_3f0) < 0x400) break;
                  uStack_3f6 = uStack_3f6 | 1;
                  uStack_3dc = uStack_3dc - 1;
                } while (uStack_3dc != 0);
              }
              if ((*(byte *)puStack_3f0 & 0x40) == 0) {
                uStack_3d2 = 0;
                uStack_3d0 = 0;
              }
              else {
                uStack_3d2 = (undefined2)uVar30;
                uStack_3d0 = (undefined2)(uVar30 >> 0x10);
                uStack_3f4 = uVar30 + 0xe;
                *(undefined8 *)(puVar35 + -8) = 0x1043e3;
                puVar21 = (ulonglong *)func_0x(&uStack_3f6);
                iVar13 = 0;
                uVar44 = *puVar21;
                uVar27 = (ushort)(uVar44 >> 0x30);
                uVar26 = uVar27;
                if ((((uint)(int)(short)uVar27 >> 1 ^ (int)(short)uVar27) & 0x2000) != 0) {
                  uVar26 = uVar27 & 0xdfff;
                  if ((uVar44 & 0x4000000000000000) != 0) {
                    uVar26 = uVar27 | 0x2000;
                  }
                }
                if (uVar26 == 0xfffc) {
                  iVar13 = (int)((uVar44 >> 0x20 & 0xffff) >> 5);
                }
                uVar30 = uStack_3f4 + iVar13;
                uStack_3f4 = uVar30;
              }
              if ((pbStack_3da != (byte *)0x0) &&
                 (pbStack_3da < (byte *)((ulonglong)uVar30 + (longlong)puStack_3f0))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar17 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                     lVar17 != 0 && (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar35 + -8) = 0x1044dd;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar35 + 0x20) = 0;
                    *(undefined8 *)(puVar35 + -8) = 0x104503;
                    (*_DAT_)(1,0xa73c28,0xb938f8,0x877);
                  }
                }
                puVar32 = puStack_3f0;
                *(undefined8 *)(puVar35 + -8) = 0x104511;
                func_0x(puVar32,0x12);
                uVar30 = uStack_3f4;
              }
              if (0x3f3b < uVar30 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar17 != 0 &&
                    ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                     (*(char *)(lVar17 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar35 + -8) = 0x10459d;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar35 + 0x20) = 0;
                    *(undefined8 *)(puVar35 + -8) = 0x1045c3;
                    (*_DAT_)(1,0xa73c28,0xb938f8,0x87c);
                  }
                }
                puVar32 = puStack_3f0;
                *(undefined8 *)(puVar35 + -8) = 0x1045d1;
                func_0x(puVar32,5);
              }
            }
LAB_:
            puVar32 = puStack_3f0;
            sVar9 = -*(short *)puVar40;
            if ((*(byte *)((longlong)puVar40 + 6) & 0x10) != 0) {
              if ((*(byte *)puStack_3f0 & 0x10) == 0) {
                if ((1 << (*(byte *)puStack_3f0 & 0xe) & 0x1105U) != 0) {
LAB_:
                  puVar32 = *(uint **)(puVar40 + 2) + 1;
                  uVar30 = **(uint **)(puVar40 + 2);
                  goto LAB_;
                }
              }
              else if (((int)(uint)uStack_3e8 <= (int)*puVar40) ||
                      (*(ushort *)(((ulonglong)uStack_3e8 & 0xffffffff) + (longlong)puStack_3f0) <
                       *(ushort *)(puVar40 + 1))) goto LAB_;
            }
            if ((uint)uStack_3dc < (uint)(int)sVar9) {
              uStack_3c0 = 0;
              uVar30 = uStack_3c0;
            }
            else {
              uVar30 = uStack_3e0;
              if (sVar9 != 1) {
                uVar30 = *(ushort *)
                          ((longlong)puStack_3f0 +
                          (longlong)sVar9 * 2 + (((ulonglong)uStack_3e8 >> 0x20) - 2)) & 0x7fff;
              }
              uVar28 = *(ushort *)
                        ((longlong)puStack_3f0 +
                        (longlong)sVar9 * 2 + ((ulonglong)uStack_3e8 >> 0x20)) & 0x7fff;
              if ((uVar30 < uStack_3e0) || (uVar28 < uVar30)) {
                *(undefined8 *)(puVar35 + -8) = 0x10466f;
                func_0x(puVar32,7);
              }
              puVar32 = (uint *)((ulonglong)uVar30 + (longlong)puStack_3f0);
              uVar30 = uVar28 - uVar30;
            }
          }
          else {
            uVar26 = *(ushort *)((longlong)puVar40 + 6);
            uVar31 = (uint)*(ushort *)(puVar40 + 0xe);
            if ((uVar26 & 8) == 0) {
              if ((uVar26 & 0x10) != 0) {
                if ((*(byte *)puStack_3f0 & 0x10) == 0) {
                  if ((1 << (*(byte *)puStack_3f0 & 0xe) & 0x1105U) != 0) {
LAB_:
                    uVar30 = **(uint **)(puVar40 + 2);
                    puVar32 = *(uint **)(puVar40 + 2) + 1;
                    if ((uVar31 != 0) && (uVar30 != uVar31)) {
                      *(undefined8 *)(puVar35 + 0x20) = 0;
                      *(undefined8 *)(puVar35 + -8) = 0x103fbc;
                      (*_DAT_)(1,0xc21998,0xc20398,0x381);
                    }
                    goto LAB_;
                  }
                }
                else if (((int)(uint)uStack_3e8 <= (int)uVar28) ||
                        (*(ushort *)(((ulonglong)uStack_3e8 & 0xffffffff) + (longlong)puStack_3f0) <
                         *(ushort *)(puVar40 + 1))) goto LAB_;
              }
              puVar32 = (uint *)((longlong)(int)*puVar40 + (longlong)puStack_3f0);
              uVar30 = uVar31;
            }
            else {
              uStack_3c0 = 1;
              puVar32 = (uint *)0x7f8664;
              uVar30 = uStack_3c0;
              if ((*(byte *)((longlong)(int)uVar28 + (longlong)puStack_3f0) &
                  (byte)(1 << ((byte)uVar26 & 7))) == 0) {
                puVar32 = (uint *)0x7f8c88;
              }
            }
          }
        }
      }
      else {
        uStack_3b4 = 0;
        *(uint **)(puVar35 + 0x20) = &uStack_3b4;
        *(undefined8 *)(puVar35 + -8) = 0x104707;
        puVar32 = (uint *)func_0x(&uStack_3f6,puVar40,puVar42,&uStack_3c0);
        uVar30 = uStack_3c0;
        plVar7 = uStack_3e8;
        if ((((sStack_3f8 != 0) && (uStack_3e8 != (longlong *)0x0)) && (*uStack_3e8 != 0)) &&
           (((*(byte *)((longlong)puVar40 + 6) & 8) == 0 && ((uStack_3b4 & 1) == 0)))) {
          if ((puVar32 == (uint *)0x0) || (puVar32 == (uint *)0x7f8664)) goto LAB_;
          *(uint *)(puVar35 + 0x38) = uStack_3b4;
          *(uint **)(puVar35 + 0x30) = &uStack_3c0;
          *(undefined4 *)(puVar35 + 0x28) = 0;
          *(undefined8 *)(puVar35 + 0x20) = 0;
          *(undefined8 *)(puVar35 + -8) = 0x104765;
          puVar32 = (uint *)func_0x(plVar7,puVar40,puVar32,uVar30);
          uVar30 = uStack_3c0;
        }
      }
LAB_:
      uStack_3c0 = uVar30;
      *ppuVar51 = puVar32;
      uVar30 = iVar43 + 1;
      uVar29 = (ulonglong)uVar30;
      ppuVar51 = ppuVar51 + 1;
      *puVar49 = (undefined2)uStack_3c0;
      puVar49 = puVar49 + 1;
      lVar17 = lStack_3a0;
      if ((iVar38 != 0) <= uVar30) break;
      uVar44 = (ulonglong)uStack_3f4;
    } while( true );
  }
LAB_:
  uVar12 = *(undefined4 *)(lVar17 + 0xb8);
  uVar46 = *(undefined8 *)(lVar17 + 0x150);
  *(undefined4 *)(puVar35 + 0x28) = *(undefined4 *)(lVar17 + 0x170);
  *(undefined8 *)(puVar35 + 0x20) = *(undefined8 *)(lVar17 + 0x168);
  *(undefined8 *)(puVar35 + -8) = 0x1047a9;
  func_0x(uVar46,auStack_228,lVar17 + 0x178,uVar12);
  *plStack_2a8 = lVar17 + -0x18;
  uVar44 = uStack_48 ^ (ulonglong)&sStack_3f8;
  *(undefined8 *)(puVar35 + -8) = 0x1047c8;
  func_0x(uVar44);
  return;
}

