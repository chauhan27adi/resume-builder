
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,undefined4 *param_3)

{
  byte *pbVar1;
  byte bVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  short sVar5;
  int iVar6;
  byte **ppbVar7;
  undefined8 uVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar9;
  ulonglong uVar10;
  undefined4 uVar11;
  uint *puVar12;
  longlong lVar13;
  longlong unaff_GS_OFFSET;
  undefined auStack_5d8 [32];
  undefined8 uStack_5b8;
  short sStack_594;
  int iStack_588;
  longlong lStack_578;
  byte bStack_570;
  byte bStack_56f;
  ushort uStack_568;
  undefined2 uStack_560;
  undefined4 uStack_558;
  uint uStack_550;
  longlong lStack_548;
  longlong *plStack_540;
  undefined4 uStack_538;
  undefined2 uStack_534;
  ushort uStack_4f8;
  ushort uStack_4f4;
  ushort uStack_4f0;
  uint uStack_4d0;
  uint uStack_4c8;
  uint uStack_4c0;
  undefined4 uStack_4b8;
  short sStack_4b4;
  ushort uStack_4b0;
  ushort uStack_498;
  ushort uStack_496;
  undefined4 *puStack_490;
  byte **ppbStack_478;
  undefined4 *puStack_470;
  longlong **pplStack_468;
  longlong lStack_460;
  int *piStack_458;
  undefined4 uStack_450;
  undefined2 uStack_44c;
  int iStack_448;
  uint uStack_444;
  undefined4 uStack_3f8;
  undefined auStack_3f4 [36];
  longlong **pplStack_3d0;
  longlong lStack_3a8;
  byte *pbStack_390;
  undefined8 uStack_388;
  longlong lStack_380;
  longlong lStack_378;
  byte *pbStack_370;
  undefined8 uStack_368;
  undefined *puStack_360;
  longlong lStack_358;
  undefined8 uStack_350;
  longlong lStack_348;
  byte **ppbStack_340;
  longlong lStack_338;
  byte **ppbStack_330;
  byte **ppbStack_328;
  byte *pbStack_320;
  byte **ppbStack_318;
  longlong lStack_310;
  byte *pbStack_308;
  byte *pbStack_300;
  longlong lStack_2d8;
  byte *pbStack_2d0;
  undefined *puStack_2c8;
  byte *pbStack_2c0;
  undefined *puStack_2b8;
  byte *pbStack_2b0;
  ushort *puStack_1d0;
  undefined2 *puStack_1c8;
  uint *puStack_1c0;
  longlong lStack_1b8;
  uint *puStack_1b0;
  uint *puStack_1a8;
  undefined8 uStack_168;
  undefined8 *puStack_160;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  ushort uStack_110;
  undefined auStack_10e [2];
  undefined4 uStack_10c;
  byte *pbStack_108;
  undefined8 uStack_100;
  undefined8 uStack_f2;
  undefined2 uStack_ea;
  undefined2 uStack_e8;
  undefined6 uStack_e6;
  undefined4 uStack_dc;
  undefined auStack_d8 [16];
  undefined auStack_c8 [16];
  undefined auStack_b8 [16];
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined8 uStack_68;
  undefined auStack_60 [24];
  ulonglong uStack_48;
  
  uStack_388 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_5d8;
  puVar3 = (undefined8 *)**(longlong **)(param_1 + 8);
  uVar11 = 2;
  if (*(int *)(param_1 + 0xfc) == 3) {
    uVar11 = 0;
  }
  uStack_130 = 0;
  uStack_168 = 0;
  puStack_490 = param_3;
  pplStack_468 = param_2;
  lStack_460 = param_1;
  pplStack_3d0 = param_2;
  lStack_3a8 = param_1;
  puStack_160 = puVar3;
  sVar5 = (**(code **)*puVar3)(puVar3);
  if (sVar5 == 2) {
    uVar11 = 2;
  }
  uStack_12c = uVar11;
  if (*(short *)((longlong)param_2 + 0xc) < 4) {
    uStack_5b8 = 0;
    (*_DAT_)(1,0x1add7f0,0x1ab4238,0x11ab);
  }
  if ((*(int *)(param_1 + 0xfc) - 2U < 2) &&
     ((plVar4 = *(longlong **)(*(longlong *)(param_1 + 8) + 8),
      ((byte)*(undefined4 *)(plVar4 + 0x43) & 5) != 1 || ((*(byte *)(plVar4 + 0x5b) & 2) == 0)))) {
    (**(code **)(*plVar4 + 0x170))(plVar4,0x2000,0);
  }
  func_0x(param_1,0x1938758);
  uStack_168 = *(undefined8 *)(param_1 + 0x110);
  func_0x(&uStack_168,param_2);
  lStack_380 = puVar3[1] + 0x200;
  lVar9 = **param_2;
  piStack_458 = (int *)(puVar3[1] + 0x210);
  uStack_4f4 = *(ushort *)(lVar9 + 0x1ffe);
  pbStack_370 = (byte *)(lVar9 + (ulonglong)uStack_4f4);
  uStack_4f8 = (ushort)(*pbStack_370 & 1);
  lStack_578 = lVar9;
  lStack_378 = lVar9;
  if ((*pbStack_370 & 1) != 0) {
    uStack_110 = 0xffff;
    pbStack_108 = (byte *)0x0;
    uStack_10c = 0;
    uStack_f2 = 0;
    uStack_e8 = 0;
    uStack_e6 = 0;
    uStack_100 = 0;
    uStack_dc = 0;
    if (*(char *)(lVar9 + 2) < '\0') {
      pbVar1 = (byte *)(lVar9 + 0x60);
      uStack_368 = 0;
      ppbStack_478 = (byte **)0x0;
      puStack_360 = auStack_d8;
      auStack_d8 = ZEXT816(0);
      auStack_c8 = ZEXT816(0);
      auStack_b8 = ZEXT816(0);
      auStack_a8 = ZEXT816(0);
      auStack_98 = ZEXT816(0);
      auStack_88 = ZEXT816(0);
      auStack_78 = ZEXT816(0);
      uStack_68 = 0;
      ppbVar7 = (byte **)func_0x(auStack_d8);
      ppbStack_478 = ppbVar7;
      lStack_358 = lVar9 + 0x20;
      uVar8 = func_0x(lVar9,auStack_60,0,0);
      pbStack_390 = pbVar1;
      uStack_350 = uVar8;
      ppbStack_340 = ppbVar7;
      if (pbVar1 == *ppbVar7) {
        iVar6 = func_0x(uVar8,ppbVar7 + 0xc);
        if (iVar6 != 0) {
          lStack_338 = (longlong)ppbVar7 + 0x6c;
        }
      }
      *ppbVar7 = pbVar1;
      func_0x(ppbVar7 + 0xc,uVar8);
      func_0x((longlong)ppbVar7 + 0x6c,lVar9 + 0x20);
      uVar10 = (ulonglong)*pbVar1;
      uStack_4f0 = (ushort)*pbVar1;
      uStack_450 = *(undefined4 *)(uVar10 * 6 + 0x172ca30);
      uStack_44c = *(undefined2 *)(uVar10 * 6 + 0x172ca34);
      uStack_4b8 = *(undefined4 *)(uVar10 * 6 + 0x172ca30);
      sStack_594 = *(short *)(uVar10 * 6 + 0x172ca34);
      lStack_548 = lVar9 + 99;
      ppbStack_330 = ppbVar7 + 2;
      *(undefined2 *)ppbStack_330 = 0xffff;
      ppbVar7[3] = (byte *)0x0;
      *(undefined4 *)((longlong)ppbVar7 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar7 + 0x2e) = 0;
      ppbVar7[7] = (byte *)0x0;
      ppbVar7[4] = (byte *)0x0;
      ppbStack_328 = ppbVar7 + 9;
      *ppbStack_328 = (byte *)0x0;
      ppbVar7[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar7 + 0xb) = 0;
      sStack_4b4 = sStack_594;
      if ((**ppbVar7 & 2) != 0) {
        pbStack_320 = pbVar1 + sStack_594;
        bVar2 = *pbStack_320;
        uStack_4b0 = (ushort)(bVar2 & 1);
        *(ushort *)ppbStack_330 = uStack_4b0;
        lStack_348 = (longlong)ppbVar7 + 0x12;
        ppbStack_318 = ppbStack_330;
        if ((bVar2 & 1) == 0) {
          uStack_558 = 0;
          ppbVar7[3] = pbStack_320;
          *(undefined4 *)((longlong)ppbVar7 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar7 + 0x36) = 0;
          pbStack_308 = ppbVar7[3];
          lStack_310 = lStack_348;
                    /* WARNING: Could not emulate address calculation at 0x00100446 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_308 & 0xe) * 4 + 0x10188c) -
                    0xe0d400))();
          return;
        }
        ppbVar7[3] = pbStack_320;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_320 & 0x1c) + 0x1018d8) * 4 +
                               0x1018c8) - 0xe0d400);
        pbStack_300 = pbStack_320;
                    /* WARNING: Could not emulate address calculation at 0x00100525 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      if ((**ppbVar7 & 4) != 0) {
        uStack_4b8._2_2_ = (short)((uint)uStack_4b8 >> 0x10);
        uVar10 = (ulonglong)sStack_594;
        if (uStack_4b8._2_2_ != 0) {
          uVar10 = (ulonglong)*(ushort *)(lVar9 + 0x61 + (longlong)uStack_4b8._2_2_ * 2);
        }
        lStack_2d8 = uVar10 + lVar9 + 0x60;
        func_0x(ppbStack_328);
      }
      if (ppbVar7[1] != (byte *)0x0) {
        func_0x(ppbVar7[1],ppbVar7);
      }
    }
    else {
      ppbStack_478 = (byte **)0x0;
    }
    uStack_550 = (uint)*(ushort *)(lVar9 + 0xe);
    uStack_498 = *(ushort *)(lVar9 + 0x1ffe);
    pbStack_2d0 = (byte *)(lVar9 + (ulonglong)uStack_498);
    uStack_496 = (ushort)(*pbStack_2d0 & 1);
    puStack_2c8 = auStack_10e;
    uStack_444 = uStack_550;
    uStack_110 = uStack_496;
    pbStack_108 = pbStack_2d0;
    if ((*pbStack_2d0 & 1) == 0) {
      uStack_10c = 0;
      uStack_ea = 0;
      uStack_e8 = 0;
      pbStack_2c0 = pbStack_2d0;
                    /* WARNING: Could not emulate address calculation at 0x001007bd */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_2d0 & 0xe) * 4 + 0x1018f8) - 0xe0d400
                ))();
      return;
    }
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_2d0 & 0x1c) + 0x101944) *
                            4 + 0x101934) - 0xe0d400);
    puStack_2b8 = puStack_2c8;
    pbStack_2b0 = pbStack_2d0;
                    /* WARNING: Could not emulate address calculation at 0x0010087b */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_2d0,pbStack_2d0);
    return;
  }
  iStack_448 = *piStack_458;
  puStack_470 = (undefined4 *)(pbStack_370 + iStack_448);
  uStack_538 = *puStack_470;
  uStack_534 = *(undefined2 *)(puStack_470 + 1);
  func_0x(param_1,param_2,&uStack_538,&uStack_168);
  func_0x(&uStack_168);
  func_0x(param_1);
  if (*param_2 == (longlong *)0x0) goto LAB_;
  puStack_1d0 = (ushort *)((longlong)*param_2 + 0x62);
  uStack_568 = *puStack_1d0;
  if (((uStack_568 & 0x400) != 0) && (2 < *(short *)((longlong)param_2 + 0xc))) {
    func_0x(param_2);
    goto LAB_;
  }
  iStack_588 = (int)*(short *)((longlong)param_2 + 0xc);
  plStack_540 = *param_2;
  puStack_1c8 = (undefined2 *)((longlong)plStack_540 + 0x62);
  uStack_560 = *puStack_1c8;
  if (((byte)uStack_560 >> 3 & 1) != 0) {
    if (iStack_588 == 3) {
      iStack_588 = 4;
    }
    else if (iStack_588 < 2) goto LAB_;
    puStack_1c0 = (uint *)((longlong)plStack_540 + 100);
    uStack_4d0 = *puStack_1c0;
    if ((((uStack_4d0 & 8) != 0) && (lVar9 = plStack_540[0x12], lVar9 != 0)) &&
       (lStack_1b8 = lVar9, *(longlong *)(lVar9 + 0x758) != 0)) {
      func_0x(*(undefined8 *)(lVar9 + 0x758),plStack_540,iStack_588);
    }
  }
LAB_:
  bStack_570 = DAT_ >> 7;
  if ((char)DAT_ < '\0') {
    puVar12 = (uint *)((longlong)plStack_540 + 100);
    uStack_4c8 = *puVar12;
    puStack_1b0 = puVar12;
    if (((uStack_4c8 & 8) != 0) && (2 < iStack_588)) {
      uStack_4c0 = *puVar12;
      puStack_1a8 = puVar12;
      if (((uStack_4c0 & 0xc0000000) != 0x40000000) && (*plStack_540 != 0)) {
        uStack_3f8 = 2;
        iVar6 = (*_DAT_)(*plStack_540,0x2000,2,auStack_3f4);
        if (iVar6 != 0) {
          LOCK();
          *puVar12 = *puVar12 & 0x3fffffff;
          UNLOCK();
          LOCK();
          *puVar12 = *puVar12 | 0x40000000;
          UNLOCK();
        }
      }
    }
  }
  plVar4 = plStack_540;
  iVar6 = iStack_588;
  func_0x(plStack_540 + 0x13,iStack_588);
  if ((_DAT_ != 0) && (bStack_56f = DAT_ >> 1, (bStack_56f & 1) != 0)) {
    func_0x(plVar4,0,iVar6);
  }
  *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
  *param_2 = (longlong *)0x0;
LAB_:
  *param_3 = uStack_538;
  *(undefined2 *)(param_3 + 1) = uStack_534;
  lVar13 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar9 = *(longlong *)(lVar13 + 0x100);
  if (lVar9 == 0) {
    (*_DAT_)();
    lVar9 = *(longlong *)(lVar13 + 0x100);
  }
  if (*(int *)(lVar9 + 0x22c) != 0) {
    (*_DAT_)();
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_5d8);
  return;
}

