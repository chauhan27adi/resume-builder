
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,undefined8 param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong lVar5;
  undefined auVar6 [16];
  undefined8 uVar7;
  char cVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar9;
  undefined8 uStack_1a8;
  undefined2 uStack_1a0;
  undefined2 uStack_198;
  undefined4 uStack_194;
  undefined8 uStack_190;
  undefined8 uStack_188;
  undefined8 uStack_17a;
  undefined8 uStack_170;
  undefined8 uStack_160;
  longlong **pplStack_158;
  undefined2 uStack_f8;
  undefined4 uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  undefined4 uStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  undefined8 uStack_80;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [10];
  undefined auStack_56 [6];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_1a8;
  lVar4 = **param_1;
  uStack_f8 = 0xffff;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_e8 = 0;
  uStack_198 = 0xffff;
  uStack_190 = 0;
  uStack_194 = 0;
  uStack_17a = 0;
  uStack_170 = 0;
  uStack_188 = 0;
  uStack_c4 = 1;
  uStack_160 = param_3;
  pplStack_158 = param_1;
  if (-1 < *(char *)(lVar4 + 2)) goto LAB_;
  pbVar1 = (byte *)(lVar4 + 0x60);
  stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
  auStack_b0._0_2_ = 0xffff;
  uStack_98 = 0;
  uStack_8a = 0;
  uStack_a8 = 0;
  uStack_80 = 0;
  uStack_92 = 0;
  uStack_90 = 0;
  uStack_88 = 0;
  uStack_86 = 0;
  uStack_a0 = 0;
  psStack_78 = (short *)0x0;
  _auStack_60 = ZEXT812(0);
  auStack_56._2_4_ = 0;
  uStack_50 = 0;
  psStack_70 = (short *)0x0;
  sStack_68 = 0;
  uStack_66 = 0;
  auStack_c0 = ZEXT816(0);
  lVar5 = 0;
  if (*(short *)(lVar4 + 0x24) == 0) {
LAB_:
    auStack_c0._8_8_ = lVar5;
    uStack_1a8 = *(undefined8 *)(lVar4 + 0x28);
    uStack_1a0 = *(undefined2 *)(lVar4 + 0x30);
  }
  else {
    cVar8 = *(char *)(lVar4 + 1);
    if (cVar8 == '\v') {
      if (*(int *)(lVar4 + 0x18) != 99) {
LAB_:
        if (cVar8 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar8 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar4 + 0x18) != 99) goto LAB_;
    }
    uStack_1a8 = CONCAT26(uStack_1a8._6_2_,*(undefined6 *)(lVar4 + 0x20));
    cVar8 = func_0x(&uStack_1a8,0x1043c58,2);
    lVar5 = auStack_c0._8_8_;
    if (cVar8 == '\0') goto LAB_;
    func_0x(lVar4,&uStack_1a8);
  }
  auStack_60._8_2_ = uStack_1a0;
  auStack_60._0_8_ = uStack_1a8;
  auStack_c0._0_8_ = pbVar1;
  auStack_56._2_4_ = *(undefined4 *)(lVar4 + 0x20);
  auStack_b0._0_2_ = 0xffff;
  auStack_b0 = (undefined  [8])((ulonglong)auStack_b0 & 0xffffffff);
  uStack_a8 = 0;
  uStack_92 = 0;
  uStack_90 = 0;
  uVar3 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x10c4260);
  uVar9 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x10c4264);
  uStack_88 = 0;
  uStack_86 = 0;
  uStack_a0 = 0;
  psStack_78 = (short *)0x0;
  psStack_70 = (short *)0x0;
  sStack_68 = 0;
  uStack_1a8 = CONCAT44((int)((ulonglong)uStack_1a8 >> 0x20),uVar3);
  uVar7 = uStack_1a8;
  if ((*pbVar1 & 2) != 0) {
    pbVar2 = pbVar1 + uVar9;
    uStack_a8 = pbVar2;
    if ((pbVar1[uVar9] & 1) == 0) {
      auVar6._14_2_ = 0;
      auVar6._0_14_ = stack0xffffffffffffff52;
      _auStack_b0 = auVar6 << 0x10;
      uStack_8a = 0;
      uStack_88 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010045d */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x101a74) - 0x1475bd0))()
      ;
      return;
    }
    auStack_b0._0_2_ = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x101a54) * 4 +
                           0x101a44) - 0x1475bd0);
                    /* WARNING: Could not emulate address calculation at 0x0010029b */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar1 & 4) != 0) {
    uStack_1a8._2_2_ = (short)((uint)uVar3 >> 0x10);
    if (uStack_1a8._2_2_ != 0) {
      uVar9 = (ulonglong)*(ushort *)(lVar4 + 0x61 + (longlong)uStack_1a8._2_2_ * 2);
    }
    psStack_78 = (short *)(pbVar1 + uVar9);
    psStack_70 = psStack_78 + 1;
    sStack_68 = (*psStack_78 + 1) * 2;
  }
  uStack_1a8 = uVar7;
  if (auStack_c0._8_8_ != 0) {
    func_0x(auStack_c0._8_8_,auStack_c0);
  }
LAB_:
  pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar4 + 0x1ffc) + lVar4);
  if ((*pbStack_f0 & 1) == 0) {
    uStack_f8 = 0;
    uStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007d2 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_f0 & 0xe) * 4 + 0x101ae0) - 0x1475bd0))
              ((longlong)(int)(*pbStack_f0 & 0xe),0x1043c58,0);
    return;
  }
  uStack_f8 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_f0 & 0x1c) + 0x101ac0) * 4 +
                         0x101ab0) - 0x1475bd0);
                    /* WARNING: Could not emulate address calculation at 0x00100582 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

