
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2,longlong *param_3)

{
  undefined auVar1 [16];
  undefined2 uVar2;
  uint uVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  undefined8 uVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong lVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  longlong lVar15;
  longlong unaff_GS_OFFSET;
  undefined auStack_208 [32];
  undefined8 uStack_1e8;
  undefined8 uStack_1e0;
  ulonglong uStack_1d8;
  undefined8 uStack_1d0;
  undefined4 uStack_1c8;
  undefined2 uStack_1b8;
  uint auStack_1b0 [2];
  undefined4 auStack_1a8 [2];
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined8 uStack_190;
  undefined4 uStack_188;
  undefined auStack_180 [16];
  longlong lStack_170;
  undefined auStack_168 [16];
  undefined auStack_158 [16];
  undefined auStack_148 [16];
  undefined auStack_138 [16];
  undefined auStack_128 [16];
  undefined8 uStack_118;
  undefined8 uStack_108;
  undefined auStack_100 [16];
  undefined auStack_f0 [16];
  undefined auStack_e0 [24];
  longlong lStack_c8;
  undefined2 uStack_c0;
  undefined8 uStack_b8;
  int iStack_b0;
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  longlong lStack_68;
  uint uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_108 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_208;
  lVar15 = *(longlong *)
            ((ulonglong)*_DAT_ + 8 +
            *(longlong *)((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)));
  lVar10 = *(longlong *)((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)) +
           (ulonglong)*_DAT_;
  lVar8 = *(longlong *)(lVar10 + 0x100);
  auStack_1a8[0] = param_2;
  if (lVar8 == 0) {
    (*_DAT_)(0);
    lVar8 = *(longlong *)(lVar10 + 0x100);
  }
  lStack_170 = *(longlong *)(lVar8 + 600);
  uStack_190 = 0;
  uStack_188 = 1;
  auStack_180 = ZEXT816(0);
  if ((lVar15 == 0) || (lStack_170 == 0)) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1bffa50,0x1bda010,0x415);
  }
  if (*(longlong *)(param_1 + 0x28) != 0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1bffa38,0x1bda010,0x416);
  }
  uStack_1b8 = *(undefined2 *)
                (*(longlong *)
                  (*(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) + 0x50
                  ) + 8);
  if (param_1 + 0x280 == 0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1bffdcc,0x1bda090,0xccd);
  }
  if (param_3 == (longlong *)0x0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1bffd98,0x1bda090,0xccf);
  }
  uStack_1a0 = 0;
  if (*param_3 == 0) {
LAB_:
    uVar11 = 0;
  }
  else {
    uVar5 = func_0x(param_3,0x1a4b708,&uStack_1a0);
    uVar11 = (ulonglong)uVar5;
    if ((ulonglong)uVar5 != *(ulonglong *)((ulonglong)(uVar5 - 1) * 0x58 + param_3[0xc])) {
      uVar5 = 1;
      uVar3 = 1;
      if (*(uint *)(param_3 + 0xd) != 0) {
        do {
          uVar5 = uVar3;
          if (uVar11 == *(ulonglong *)((ulonglong)(uVar5 - 1) * 0x58 + param_3[0xc])) break;
          uVar5 = uVar5 + 1;
          uVar3 = uVar5;
        } while (uVar5 <= *(uint *)(param_3 + 0xd));
      }
    }
    if (*(uint *)(param_3 + 0xd) < uVar5) goto LAB_;
    lVar8 = (ulonglong)(uVar5 - 1) * 0x58 + param_3[0xc];
    lVar15 = *param_3;
    uVar11 = *(ulonglong *)(lVar15 + *(longlong *)(lVar8 + 0x10));
    iVar6 = *(int *)(lVar15 + *(longlong *)(lVar8 + 0x18));
    lVar15 = *(longlong *)(lVar8 + 8) + lVar15;
    if (0x202 < uVar11) {
      uStack_1e8 = 0;
      (*_DAT_)(1,0x1bffdd8,0x1bda090,0xcd6);
    }
    if (((lVar15 == 0) || (uVar11 == 0)) || (iVar6 == 3)) goto LAB_;
    if (uVar11 < 0x203) {
      func_0x(param_1 + 0x280,lVar15,uVar11);
    }
  }
  *(undefined2 *)(param_1 + 0x280 + (uVar11 & 0xfffffffffffffffe)) = 0;
  if (param_1 + 0x500 == 0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1bffdcc,0x1bda090,0xccd);
  }
  uStack_19c = 0;
  if (*param_3 == 0) {
LAB_:
    uVar11 = 0;
  }
  else {
    uVar5 = func_0x(param_3,0x1a4b6d0,&uStack_19c);
    uVar11 = (ulonglong)uVar5;
    if ((ulonglong)uVar5 != *(ulonglong *)((ulonglong)(uVar5 - 1) * 0x58 + param_3[0xc])) {
      uVar5 = 1;
      uVar3 = 1;
      if (*(uint *)(param_3 + 0xd) != 0) {
        do {
          uVar5 = uVar3;
          if (uVar11 == *(ulonglong *)((ulonglong)(uVar5 - 1) * 0x58 + param_3[0xc])) break;
          uVar5 = uVar5 + 1;
          uVar3 = uVar5;
        } while (uVar5 <= *(uint *)(param_3 + 0xd));
      }
    }
    if (*(uint *)(param_3 + 0xd) < uVar5) goto LAB_;
    lVar8 = (ulonglong)(uVar5 - 1) * 0x58 + param_3[0xc];
    lVar15 = *param_3;
    uVar11 = *(ulonglong *)(lVar15 + *(longlong *)(lVar8 + 0x10));
    iVar6 = *(int *)(lVar15 + *(longlong *)(lVar8 + 0x18));
    lVar15 = *(longlong *)(lVar8 + 8) + lVar15;
    if (0x202 < uVar11) {
      uStack_1e8 = 0;
      (*_DAT_)(1,0x1bffdd8,0x1bda090,0xcd6);
    }
    if (((lVar15 == 0) || (uVar11 == 0)) || (iVar6 == 3)) goto LAB_;
    if (uVar11 < 0x203) {
      func_0x(param_1 + 0x500,lVar15,uVar11);
    }
  }
  uVar13 = 0;
  *(undefined2 *)(param_1 + 0x500 + (uVar11 & 0xfffffffffffffffe)) = 0;
  if (param_1 + 0x710 == 0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1bffdcc,0x1bda090,0xccd);
  }
  uStack_198 = 0;
  if (*param_3 != 0) {
    uVar5 = func_0x(param_3,0x1a4b6e0,&uStack_198);
    uVar11 = (ulonglong)uVar5;
    if ((ulonglong)uVar5 != *(ulonglong *)((ulonglong)(uVar5 - 1) * 0x58 + param_3[0xc])) {
      uVar5 = 1;
      uVar3 = 1;
      if (*(uint *)(param_3 + 0xd) != 0) {
        do {
          uVar5 = uVar3;
          if (uVar11 == *(ulonglong *)((ulonglong)(uVar5 - 1) * 0x58 + param_3[0xc])) break;
          uVar5 = uVar5 + 1;
          uVar3 = uVar5;
        } while (uVar5 <= *(uint *)(param_3 + 0xd));
      }
    }
    if (uVar5 <= *(uint *)(param_3 + 0xd)) {
      lVar8 = (ulonglong)(uVar5 - 1) * 0x58 + param_3[0xc];
      lVar15 = *param_3;
      uVar11 = *(ulonglong *)(lVar15 + *(longlong *)(lVar8 + 0x10));
      iVar6 = *(int *)(lVar15 + *(longlong *)(lVar8 + 0x18));
      lVar15 = *(longlong *)(lVar8 + 8) + lVar15;
      if (0x202 < uVar11) {
        uStack_1e8 = 0;
        (*_DAT_)(1,0x1bffdd8,0x1bda090,0xcd6);
      }
      if (((lVar15 != 0) && (uVar11 != 0)) && (iVar6 != 3)) {
        if (uVar11 < 0x203) {
          func_0x(param_1 + 0x710,lVar15,uVar11);
        }
        goto LAB_;
      }
    }
  }
  uVar11 = 0;
LAB_:
  *(undefined2 *)(param_1 + 0x710 + (uVar11 & 0xfffffffffffffffe)) = 0;
  uStack_188 = 1;
  auStack_180._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  cVar4 = (**(code **)(*(longlong *)auStack_180._0_8_ + 0x1d0))();
  if (cVar4 == '\0') {
    uStack_1c8 = 0;
    uStack_1d0 = 0;
    uStack_1d8 = uStack_1d8 & 0xffffffffffffff00;
    uStack_1e0 = (undefined8 *)CONCAT44(uStack_1e0._4_4_,2);
    uStack_1e8 = CONCAT44(uStack_1e8._4_4_,1);
    (**(code **)(*(longlong *)auStack_180._0_8_ + 8))(auStack_180._0_8_,0x1a4b680,0xf,1);
    uStack_190 = CONCAT44(uStack_190._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_180._0_8_ + 0xe8))
              (auStack_180._0_8_,1,1,(longlong)&uStack_190 + 4);
    uStack_188 = 1;
    uStack_190 = CONCAT44(uStack_190._4_4_,4);
  }
  uVar2 = uStack_1b8;
  iVar6 = func_0x(uStack_1b8,0x1a4b6a8);
  if (iVar6 == 0) {
    func_0x(0x4977,0x10,1,0x1a4b6a8);
  }
  else {
    uStack_b8 = (**(code **)(*(longlong *)auStack_180._0_8_ + 0x1b0))();
    lStack_c8 = 0;
    uStack_c0 = uVar2;
    auStack_a8 = ZEXT816(0);
    auStack_98 = ZEXT816(0);
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    lStack_68 = 0;
    uStack_60 = 0;
    uStack_58 = 0;
    uStack_50 = 0;
    iStack_b0 = iVar6;
    iVar6 = func_0x(&lStack_c8,3,1);
    if (iVar6 == 0) {
      func_0x(0x49aa,0x10,3,0x1a4b6a8);
    }
    else {
      auStack_1b0[0] = 4;
      auStack_e0._0_4_ = func_0x(&lStack_c8,0x184e130,auStack_1b0);
      auStack_100 = ZEXT816(0);
      auStack_f0 = ZEXT816(0);
      auStack_e0._4_12_ = SUB1612(ZEXT816(0),4);
      uStack_118 = 0;
      auStack_128 = ZEXT416(auStack_1b0[0]) << 0x40;
      auStack_158 = ZEXT816(0);
      auStack_168 = ZEXT416((uint)auStack_e0._0_4_);
      auStack_138._0_12_ = ZEXT412(1) << 0x40;
      auStack_138._12_4_ = 0;
      auStack_148._8_8_ = 0;
      auStack_148._0_8_ = auStack_100;
      uStack_1d8 = 0;
      uStack_1e0 = &uStack_50;
      uStack_1e8 = 0;
      (**(code **)(*(longlong *)auStack_98._8_8_ + 0x20))(auStack_98._8_8_,2,1,auStack_168);
      uStack_1d8 = uStack_1d8 & 0xffffffff00000000;
      uStack_1e0 = (undefined8 *)auStack_1a8;
      uStack_1e8 = 1;
      (**(code **)(*(longlong *)auStack_88._8_8_ + 0x28))(auStack_88._8_8_,uStack_50,1,auStack_1a8);
      uStack_1e0 = (undefined8 *)lStack_c8;
      uStack_1e8 = uStack_58;
      iVar6 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1,0);
      lVar15 = lStack_170;
      while (iVar6 == 0) {
        if (((*(uint *)(lVar15 + 0xbc) & 4) != 0) &&
           ((iVar6 = func_0x(), iVar6 != 0 ||
            (((lVar8 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
              lVar8 != 0 && (*(char *)(*(longlong *)(lVar8 + 0x38) + 8) != '\0')) &&
             (iVar6 = func_0x(), iVar6 == 0)))))) goto LAB_;
        *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
        uStack_1e0 = (undefined8 *)lStack_c8;
        uStack_1e8 = uStack_58;
        iVar6 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1,0);
      }
      auVar1 = ZEXT816(4) * ZEXT416(*(uint *)(param_1 + 0x24));
      uVar7 = auVar1._0_8_;
      if (auVar1._8_8_ != 0) {
        uVar7 = 0xffffffffffffffff;
      }
      uStack_1e0 = (undefined8 *)CONCAT71(uStack_1e0._1_7_,6);
      uStack_1e8 = CONCAT44(uStack_1e8._4_4_,0x442);
      uVar7 = (*_DAT_)(uVar7,_DAT_,1,0x1a4b838);
      *(undefined8 *)(param_1 + 0x28) = uVar7;
      uVar14 = (ulonglong)*(uint *)(param_1 + 0x24) * 4;
      if (0xffffffff < uVar14) {
        uVar14 = 0xffffffff;
        func_0x(0x80070216,4);
      }
      uStack_1e8 = 0;
      func_0x(uVar2,0x1f,uVar14 & 0xffffffff,1);
      if (*(longlong *)(param_1 + 0x28) == 0) {
        uStack_1e8 = 0;
        (*_DAT_)(1,0x1bffa88,0x1bda010,0x443);
      }
      iVar6 = (**(code **)(*(longlong *)auStack_88._0_8_ + 0x38))(auStack_88._0_8_,0);
      uVar14 = uVar13;
      if (iVar6 == 0) {
        while( true ) {
          uStack_1e0 = (undefined8 *)lStack_c8;
          uStack_1e8 = uStack_58;
          iVar6 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1,0);
          if ((iVar6 != 0) ||
             (((*(uint *)(lVar15 + 0xbc) & 4) != 0 &&
              ((iVar6 = func_0x(), iVar6 != 0 ||
               (((lVar8 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
                 , lVar8 != 0 && (*(char *)(*(longlong *)(lVar8 + 0x38) + 8) != '\0')) &&
                (iVar6 = func_0x(), iVar6 == 0)))))))) break;
          uStack_194 = 0;
          uVar9 = uVar13;
          if (lStack_c8 != 0) {
            uVar5 = func_0x(&lStack_c8,0x17e6cf0,&uStack_194);
            uVar12 = (ulonglong)uVar5;
            if (uVar12 == *(ulonglong *)((ulonglong)(uVar5 - 1) * 0x58 + lStack_68)) {
LAB_:
              uVar11 = 0;
              if (uVar5 <= uStack_60) {
                lVar8 = (ulonglong)(uVar5 - 1) * 0x58 + lStack_68;
                uVar9 = *(longlong *)(lVar8 + 8) + lStack_c8;
                uVar11 = *(ulonglong *)(lStack_c8 + *(longlong *)(lVar8 + 0x10));
              }
            }
            else {
              uVar5 = 1;
              uVar11 = uVar13;
              if (uStack_60 != 0) {
                do {
                  if (uVar12 == *(ulonglong *)((ulonglong)(uVar5 - 1) * 0x58 + lStack_68))
                  goto LAB_;
                  uVar5 = uVar5 + 1;
                } while (uVar5 <= uStack_60);
              }
            }
          }
          *(undefined4 *)(uVar14 * 4 + *(longlong *)(param_1 + 0x28)) = 0;
          func_0x
                    (uVar14 * 4 + *(longlong *)(param_1 + 0x28),uVar9,uVar11 & 0xffffffff);
          uVar14 = (ulonglong)((int)uVar14 + 1);
        }
      }
      else {
        uStack_1e8 = CONCAT44(uStack_1e8._4_4_,iVar6);
        func_0x(0x497a,0x10,1,0x1a4b6a8);
      }
    }
LAB_:
    func_0x(&lStack_c8);
  }
  func_0x(&uStack_190,0);
  if ((int)uStack_190 != 0) {
    func_0x(&uStack_190,0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_208);
  return;
}

