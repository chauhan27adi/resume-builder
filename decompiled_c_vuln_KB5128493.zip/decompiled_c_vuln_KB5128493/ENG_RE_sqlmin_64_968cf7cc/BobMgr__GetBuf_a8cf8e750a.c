
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  uint uVar1;
  code *pcVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uStack_20;
  
  uStack_20 = 0x100019;
  lVar3 = func_0x();
  lVar3 = -lVar3;
  *(ulonglong *)(&stack0x00001058 + lVar3) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffe8 + lVar3);
  uVar1 = *(uint *)(param_1 + 0x4c);
  *(undefined4 *)(&stack0x00000028 + lVar3) = 0x4000b9;
  *(undefined8 *)(&stack0x00000030 + lVar3) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar3) = 0;
  lVar4 = *(longlong *)(param_1 + 0x50);
  *(undefined8 *)(&stack0x00000038 + lVar3) = 0;
  *(undefined8 *)(&stack0x00000048 + lVar3) = 0;
  *(undefined8 *)((longlong)&uStack_20 + lVar3) = 0x100071;
  lVar4 = func_0x(lVar4 + (ulonglong)uVar1 * 0x28);
  if (lVar4 != 0) {
    *(undefined8 *)((longlong)&uStack_20 + lVar3) = 0x100086;
    func_0x
              (*(ulonglong *)(&stack0x00001058 + lVar3) ^
               (ulonglong)(&stack0xffffffffffffffe8 + lVar3));
    return;
  }
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}

