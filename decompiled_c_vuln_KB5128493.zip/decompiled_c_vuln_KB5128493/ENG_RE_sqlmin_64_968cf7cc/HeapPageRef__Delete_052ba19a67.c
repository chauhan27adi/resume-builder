
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,longlong *param_3,undefined8 param_4)

{
  short *psVar1;
  char *pcVar2;
  undefined4 uVar3;
  code **ppcVar4;
  code *pcVar5;
  uint *puVar6;
  undefined8 uVar7;
  undefined *puVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  char cVar11;
  char cVar12;
  int iVar13;
  undefined4 uVar14;
  longlong lVar15;
  short *psVar16;
  longlong lVar17;
  longlong lVar18;
  longlong lVar19;
  undefined4 *puVar20;
  undefined8 uVar21;
  longlong *plVar22;
  undefined8 *puVar23;
  undefined4 *puVar24;
  ulonglong *puVar25;
  byte **ppbVar26;
  longlong lVar27;
  byte bVar28;
  byte bVar29;
  uint uVar30;
  undefined4 *puVar31;
  byte *pbVar32;
  short sVar33;
  ushort uVar34;
  ushort uVar35;
  uint uVar36;
  longlong *plVar37;
  uint uVar39;
  uint uVar40;
  uint uVar41;
  longlong **pplVar42;
  undefined *puVar43;
  uint uVar44;
  byte **ppbVar45;
  undefined *puVar46;
  short *psVar47;
  ushort *puVar48;
  byte *pbVar49;
  byte **ppbVar50;
  undefined2 *puVar51;
  undefined2 uVar52;
  ulonglong uVar53;
  short sVar54;
  longlong lVar55;
  ushort *puVar56;
  longlong unaff_GS_OFFSET;
  bool bVar57;
  undefined2 auStackX_10 [2];
  undefined4 uStackX_14;
  undefined8 auStackX_18 [2];
  undefined8 uStack_108;
  undefined auStack_100 [120];
  undefined8 auStack_88 [3];
  undefined auStack_70 [16];
  undefined2 auStack_60 [2];
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined8 auStack_50 [2];
  ulonglong uVar38;
  
  auStack_50[1] = 0x100017;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  pcVar2 = &stack0x00000050 + lVar15;
  *(ulonglong *)(&stack0x000023e0 + lVar15) = _DAT_ ^ (ulonglong)pcVar2;
  lVar27 = *(longlong *)(&stack0x00002468 + lVar15);
  ppbVar45 = (byte **)0x0;
  uVar41 = 0;
  *(longlong ***)(&stack0x000000d0 + lVar15) = param_1;
  *(undefined8 *)(&stack0x00000098 + lVar15) = 0;
  *(undefined4 *)(&stack0x00000094 + lVar15) = 0;
  *(undefined8 *)(&stack0x000000ae + lVar15) = 0;
  *(undefined8 *)(&stack0x000000b8 + lVar15) = 0;
  *(undefined8 *)(&stack0x000000a0 + lVar15) = 0;
  *(undefined8 *)(&stack0x00000338 + lVar15) = 0;
  *(undefined4 *)(&stack0x00000334 + lVar15) = 0;
  *(undefined8 *)(&stack0x0000034e + lVar15) = 0;
  *(undefined8 *)(&stack0x00000358 + lVar15) = 0;
  *(undefined8 *)(&stack0x00000340 + lVar15) = 0;
  *(undefined8 *)(&stack0x000003e8 + lVar15) = 0;
  *(undefined4 *)(&stack0x000003e4 + lVar15) = 0;
  *(undefined8 *)(&stack0x000003fe + lVar15) = 0;
  *(undefined8 *)(&stack0x00000408 + lVar15) = 0;
  *(undefined8 *)(&stack0x000003f0 + lVar15) = 0;
  *(undefined8 *)(&stack0x00000418 + lVar15) = 0;
  *(undefined4 *)(&stack0x00000420 + lVar15) = 0;
  *(undefined8 *)(&stack0x000000e0 + lVar15) = *(undefined8 *)(&stack0x00002470 + lVar15);
  *(undefined2 *)(&stack0x00000090 + lVar15) = 0xffff;
  *(undefined2 *)(&stack0x00000330 + lVar15) = 0xffff;
  *(undefined2 *)(&stack0x000003e0 + lVar15) = 0xffff;
  plVar22 = *param_1;
  *(undefined8 *)(&stack0x00000198 + lVar15) = param_4;
  *(longlong **)(&stack0x00000118 + lVar15) = param_3;
  *(undefined8 *)(&stack0x00000100 + lVar15) = param_2;
  lVar17 = *plVar22;
  *(undefined8 *)(&stack0x00000428 + lVar15) = 0;
  *(undefined (*) [16])(&stack0x000001a0 + lVar15) = ZEXT816(0);
  *(undefined4 *)(&stack0x00000430 + lVar15) = 0;
  *(undefined2 *)(&stack0x00000434 + lVar15) = 0;
  ppcVar4 = (code **)*param_3;
  *(longlong *)(&stack0x000000f0 + lVar15) = lVar27;
  *(longlong *)(&stack0x00000110 + lVar15) = lVar17;
  *(undefined4 *)(&stack0x00000054 + lVar15) = 0;
  *(undefined8 *)(&stack0x00000190 + lVar15) = 0;
  (&stack0x000000c8)[lVar15] = 0;
  pcVar5 = *ppcVar4;
  *(undefined8 *)((longlong)auStack_50 + lVar15 + 8) = 0x100132;
  cVar11 = (*pcVar5)(param_3);
  *(undefined4 *)(&stack0x00000364 + lVar15) = *(undefined4 *)(&stack0x00002460 + lVar15);
  lVar55 = 2;
  *(undefined4 *)(&stack0x00000120 + lVar15) = *(undefined4 *)(&stack0x00002460 + lVar15);
  *(undefined4 *)(&stack0x0000010c + lVar15) = 9;
  *pcVar2 = '\0';
  uVar44 = 0;
  sVar54 = 2;
  ppbVar26 = ppbVar45;
  if (*(char *)(lVar17 + 2) < '\0') {
    pbVar49 = (byte *)(lVar17 + 0x60);
    if ((*(short *)(&stack0x00000330 + lVar15) == 0) ||
       (ppbVar26 = *(byte ***)(&stack0x00000340 + lVar15), ppbVar26 == (byte **)0x0)) {
      ppbVar26 = (byte **)(&stack0x00000368 + lVar15);
      *(undefined (*) [16])(&stack0x00000378 + lVar15) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000380 + lVar15) = 0;
      *(undefined8 *)(&stack0x000003d8 + lVar15) = 0;
      *(undefined (*) [16])(&stack0x00000388 + lVar15) = ZEXT816(0);
      *(undefined2 *)(&stack0x00000378 + lVar15) = 0xffff;
      *(undefined (*) [16])(&stack0x00000398 + lVar15) = ZEXT816(0);
      *(undefined4 *)(&stack0x0000037c + lVar15) = 0;
      *(undefined (*) [16])(&stack0x000003c8 + lVar15) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000396 + lVar15) = 0;
      *(undefined (*) [16])(&stack0x000003a8 + lVar15) = ZEXT816(0);
      *(undefined8 *)(&stack0x000003a0 + lVar15) = 0;
      *(undefined (*) [16])(&stack0x000003b8 + lVar15) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000388 + lVar15) = 0;
      *(undefined (*) [16])(&stack0x00000368 + lVar15) = ZEXT816(0);
      *(undefined8 *)(&stack0x000003b0 + lVar15) = 0;
      *(undefined8 *)(&stack0x000003c8 + lVar15) = 0;
      *(undefined4 *)(&stack0x000003d0 + lVar15) = 0;
      *(undefined2 *)(&stack0x000003da + lVar15) = 0;
    }
    if (*(short *)(lVar17 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000130 + lVar15) = *(undefined8 *)(lVar17 + 0x28);
      *(undefined2 *)(&stack0x00000138 + lVar15) = *(undefined2 *)(lVar17 + 0x30);
    }
    else {
      cVar12 = *(char *)(lVar17 + 1);
      if (cVar12 == '\v') {
        if (*(int *)(lVar17 + 0x18) != 99) {
LAB_:
          if (cVar12 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar12 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar17 + 0x18) != 99) goto LAB_;
      }
      *(undefined4 *)(&stack0x00000178 + lVar15) = *(undefined4 *)(lVar17 + 0x20);
      *(undefined2 *)(&stack0x0000017c + lVar15) = *(undefined2 *)(lVar17 + 0x24);
      *(undefined8 *)((longlong)auStack_50 + lVar15 + 8) = 0x10026f;
      cVar12 = func_0x(&stack0x00000178 + lVar15);
      if (cVar12 == '\0') goto LAB_;
      *(undefined8 *)((longlong)auStack_50 + lVar15 + 8) = 0x100282;
      func_0x(lVar17,&stack0x00000130 + lVar15);
    }
    *ppbVar26 = pbVar49;
    uVar21 = *(undefined8 *)(&stack0x00000130 + lVar15);
    uVar52 = *(undefined2 *)(&stack0x00000138 + lVar15);
    *(undefined4 *)(ppbVar26 + 0xc) = *(undefined4 *)(&stack0x00000130 + lVar15);
    *(int *)((longlong)ppbVar26 + 100) = (int)((ulonglong)uVar21 >> 0x20);
    *(undefined2 *)(ppbVar26 + 0xd) = uVar52;
    *(undefined4 *)((longlong)ppbVar26 + 0x6c) = *(undefined4 *)(lVar17 + 0x20);
    *(undefined2 *)(ppbVar26 + 0xe) = *(undefined2 *)(lVar17 + 0x24);
    *(undefined2 *)((longlong)ppbVar26 + 0x72) = 0;
    uVar53 = (ulonglong)*(short *)((ulonglong)*pbVar49 * 6 + 0x16d7084);
    *(undefined4 *)(&stack0x00000170 + lVar15) =
         *(undefined4 *)((ulonglong)*pbVar49 * 6 + 0x16d7080);
    *(undefined2 *)(ppbVar26 + 2) = 0xffff;
    ppbVar26[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
    ppbVar26[7] = (byte *)0x0;
    ppbVar26[4] = (byte *)0x0;
    ppbVar26[9] = (byte *)0x0;
    ppbVar26[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar26 + 0xb) = 0;
    lVar18 = lVar17;
    if ((**ppbVar26 & 2) != 0) {
      pbVar32 = pbVar49 + uVar53;
      if ((pbVar49[uVar53] & 1) == 0) {
        *(undefined2 *)(ppbVar26 + 2) = 0;
        ppbVar26[3] = pbVar32;
        *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar26 + 0x36) = 0;
        uVar30 = uVar44;
        switch(*pbVar32 & 0xe) {
        default:
          uVar30 = (uint)*(ushort *)(pbVar32 + 2);
          if (0x1f9d < *(ushort *)(pbVar32 + 2) - 1) {
            *(undefined8 *)((longlong)auStack_50 + lVar15 + 8) = 0x100524;
            func_0x(pbVar32,6);
          }
          break;
        case 4:
          uVar30 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar30 = 1;
        }
        *(uint *)(ppbVar26 + 4) = uVar30;
        lVar18 = *(longlong *)(&stack0x00000110 + lVar15);
        *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar26 + 2) = 1;
        ppbVar26[3] = pbVar32;
        bVar29 = *pbVar32;
        switch(bVar29 & 0x1c) {
        default:
          if ((char)pbVar32[1] < '\0') {
            uVar34 = *(ushort *)(pbVar32 + 1);
            sVar33 = 3;
            *(ushort *)((longlong)ppbVar26 + 0x12) = uVar34;
            uVar34 = (uVar34 & 0x7f) << 8 | uVar34 >> 8;
          }
          else {
            uVar34 = (ushort)pbVar32[1];
            sVar33 = sVar54;
          }
          *(ushort *)((longlong)ppbVar26 + 0x12) = uVar34;
          *(short *)(ppbVar26 + 5) = sVar33;
          *(short *)((longlong)ppbVar26 + 0x2c) =
               (short)(*(ushort *)((longlong)ppbVar26 + 0x12) + 1 >> 1) + sVar33;
          if (*(ushort *)((longlong)ppbVar26 + 0x12) < 0x1f) {
            *(undefined2 *)((longlong)ppbVar26 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
            *(undefined4 *)(ppbVar26 + 8) = 0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
          }
          else {
            iVar13 = *(ushort *)((longlong)ppbVar26 + 0x12) - 1;
            *(short *)((longlong)ppbVar26 + 0x2a) =
                 ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                 (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
            *(undefined4 *)(ppbVar26 + 8) = 0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar29 & 0x1c) != 4) || (uVar30 = 1, (bVar29 & 2) == 0)) {
            uVar30 = uVar44;
          }
          *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
          ppbVar26[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar26 + 0x12) = 0;
          ppbVar26[6] = (byte *)0x0;
          ppbVar26[4] = (byte *)0x0;
          *(undefined4 *)(ppbVar26 + 8) = 0;
          ppbVar26[7] = (byte *)0x0;
          ppbVar26[3] = pbVar32;
          if (uVar30 == 0) {
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = 1;
            *(undefined4 *)(ppbVar26 + 8) = 0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
          }
          else {
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0xf;
            *(undefined4 *)(ppbVar26 + 8) = 0;
            *(undefined4 *)(ppbVar26 + 8) = 1;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
          }
          break;
        case 8:
          ppbVar26[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar26 + 0x12) = 0;
          ppbVar26[6] = (byte *)0x0;
          ppbVar26[4] = (byte *)0x0;
          ppbVar26[7] = (byte *)0x0;
          ppbVar26[3] = pbVar32;
          *(undefined4 *)((longlong)ppbVar26 + 0x14) = 9;
          *(undefined4 *)(ppbVar26 + 8) = 0;
          ppbVar26[7] = (byte *)0x0;
          ppbVar26[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar26 & 4) != 0) {
      if (*(short *)(&stack0x00000172 + lVar15) != 0) {
        uVar53 = (ulonglong)
                 *(ushort *)(lVar17 + 0x61 + (longlong)*(short *)(&stack0x00000172 + lVar15) * 2);
      }
      psVar16 = (short *)(pbVar49 + uVar53);
      ppbVar26[9] = (byte *)psVar16;
      sVar33 = *psVar16;
      ppbVar26[10] = (byte *)(psVar16 + 1);
      *(short *)(ppbVar26 + 0xb) = (sVar33 + 1) * 2;
    }
    pbVar49 = ppbVar26[1];
    if (pbVar49 != (byte *)0x0) {
      *(undefined8 *)((longlong)auStack_50 + lVar15 + 8) = 0x1005b9;
      func_0x(pbVar49,ppbVar26);
    }
    lVar27 = *(longlong *)(&stack0x000000f0 + lVar15);
    param_3 = *(longlong **)(&stack0x00000118 + lVar15);
    lVar17 = lVar18;
  }
  uVar30 = (uint)*(ushort *)(lVar17 + 0xe);
  pbVar49 = (byte *)((ulonglong)
                     *(ushort *)
                      (*(longlong *)(&stack0x00000110 + lVar15) +
                      (0xfff - (longlong)*(int *)(&stack0x00000120 + lVar15)) * 2) +
                    *(longlong *)(&stack0x00000110 + lVar15));
  bVar29 = *pbVar49;
  *(byte **)(&stack0x00000338 + lVar15) = pbVar49;
  if ((bVar29 & 1) == 0) {
    *(undefined2 *)(&stack0x00000330 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000334 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000356 + lVar15) = 0;
    switch(*pbVar49 & 0xe) {
    default:
      uVar30 = (uint)*(ushort *)(pbVar49 + 2);
      if (0x1f9d < *(ushort *)(pbVar49 + 2) - 1) {
        *(undefined8 *)((longlong)auStack_50 + lVar15 + 8) = 0x1007f2;
        func_0x(pbVar49,6);
      }
      break;
    case 4:
      uVar30 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar30 = 1;
    }
    *(uint *)(&stack0x00000340 + lVar15) = uVar30;
    *(longlong *)(&stack0x0000034e + lVar15) = *(longlong *)(&stack0x00000110 + lVar15) + 0x2000;
  }
  else {
    *(undefined2 *)(&stack0x00000330 + lVar15) = 1;
    bVar29 = *pbVar49;
    switch(bVar29 & 0x1c) {
    default:
      if ((char)pbVar49[1] < '\0') {
        uVar34 = (*(ushort *)(pbVar49 + 1) & 0x7f) << 8 | *(ushort *)(pbVar49 + 1) >> 8;
        *(undefined2 *)(&stack0x00000348 + lVar15) = 3;
        sVar54 = 3;
        *(ushort *)(&stack0x00000332 + lVar15) = uVar34;
      }
      else {
        uVar34 = (ushort)pbVar49[1];
        *(ushort *)(&stack0x00000332 + lVar15) = uVar34;
        *(undefined2 *)(&stack0x00000348 + lVar15) = 2;
      }
      *(ushort *)(&stack0x0000034c + lVar15) = ((ushort)(uVar34 + 1) >> 1) + sVar54;
      if (uVar34 < 0x1f) {
        *(undefined2 *)(&stack0x0000034a + lVar15) = 0;
        *(undefined4 *)(&stack0x00000334 + lVar15) = 0;
        *(undefined4 *)(&stack0x00000360 + lVar15) = 0;
      }
      else {
        iVar13 = uVar34 - 1;
        *(undefined4 *)(&stack0x00000334 + lVar15) = 0;
        *(undefined4 *)(&stack0x00000360 + lVar15) = 0;
        *(short *)(&stack0x0000034a + lVar15) =
             ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
             (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar29 & 0x1c) == 4) && ((bVar29 & 2) != 0)) {
        *(undefined8 *)(&stack0x00000348 + lVar15) = 0;
        *(undefined2 *)(&stack0x00000332 + lVar15) = 0;
        *(undefined8 *)(&stack0x00000350 + lVar15) = 0;
        *(undefined4 *)(&stack0x00000334 + lVar15) = 0xf;
        *(undefined4 *)(&stack0x00000360 + lVar15) = 1;
      }
      else {
        *(undefined8 *)(&stack0x00000348 + lVar15) = 0;
        *(undefined2 *)(&stack0x00000332 + lVar15) = 0;
        *(undefined8 *)(&stack0x00000350 + lVar15) = 0;
        *(undefined4 *)(&stack0x00000334 + lVar15) = 1;
        *(undefined4 *)(&stack0x00000360 + lVar15) = 0;
      }
      break;
    case 8:
      *(undefined8 *)(&stack0x00000348 + lVar15) = 0;
      *(undefined2 *)(&stack0x00000332 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000350 + lVar15) = 0;
      *(undefined4 *)(&stack0x00000334 + lVar15) = 9;
      *(undefined4 *)(&stack0x00000360 + lVar15) = 0;
    }
    *(byte ***)(&stack0x00000340 + lVar15) = ppbVar26;
    *(longlong *)(&stack0x00000358 + lVar15) = *(longlong *)(&stack0x00000110 + lVar15) + 0x2000;
  }
  *(undefined8 *)(&stack0x00000168 + lVar15) = 0;
  *(undefined8 *)((longlong)auStack_50 + lVar15 + 8) = 0x100856;
  lVar17 = func_0x();
  lVar17 = -lVar17;
  puVar43 = &stack0xffffffffffffffc0 + lVar17 + lVar15;
  puVar46 = &stack0x00000050 + lVar17 + lVar15;
  *(undefined **)(&stack0x000000f8 + lVar15) = puVar46;
  if (lVar27 != 0) {
    pcVar5 = *(code **)(*param_3 + 0x88);
    *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10087a;
    cVar12 = (*pcVar5)(param_3);
    if (cVar12 != '\0') {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17 + lVar15) = 0;
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1008a2;
      (*pcRam0000000001558390)(1,0x1a88eb0,0x1a5e8d0,0x1cd);
    }
  }
  pplVar42 = *(longlong ***)(&stack0x000000d0 + lVar15);
  plVar22 = *pplVar42;
  *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1008bf;
  lVar18 = func_0x(uRam0000000001ffaa88,plVar22,1);
  *(ushort *)(lVar18 + 4) = *(ushort *)(lVar18 + 4) & 0xedff;
  *(undefined4 *)(lVar18 + 0x40) = 1;
  plVar22 = *pplVar42;
  if (*(short *)((longlong)plVar22 + 0x2c) != 2) {
    lVar18 = plVar22[0x12];
    if (lVar18 == 0) {
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1008f2;
      func_0x(plVar22);
      lVar18 = plVar22[0x12];
      plVar22 = *pplVar42;
    }
    if (((*(byte *)(*(longlong *)(lVar18 + 0x6b0) + 0x3c) & 1) != 0) &&
       (*(longlong *)(*(longlong *)(lVar18 + 0x6b0) + 0x280) == 0)) {
      lVar18 = plVar22[0x12];
      if (lVar18 == 0) {
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100926;
        func_0x(plVar22);
        lVar18 = plVar22[0x12];
      }
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100932;
      cVar12 = func_0x(lVar18);
      if (cVar12 == '\0') goto code_r0x00100b9f;
    }
    plVar22 = *pplVar42;
    lVar18 = plVar22[0x12];
    if (lVar18 == 0) {
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100951;
      func_0x(plVar22);
      lVar18 = plVar22[0x12];
    }
    if ((*(byte *)(lVar18 + 0x1cd0) & 0x20) == 0) {
      lVar18 = **pplVar42;
      if (*(short *)(lVar18 + 0x24) == 0) {
code_r0x001009ca:
        *(undefined8 *)(&stack0x00000140 + lVar15) = *(undefined8 *)(lVar18 + 0x28);
        *(undefined2 *)(&stack0x00000148 + lVar15) = *(undefined2 *)(lVar18 + 0x30);
      }
      else {
        cVar12 = *(char *)(lVar18 + 1);
        if (cVar12 == '\v') {
          if (*(int *)(lVar18 + 0x18) != 99) {
code_r0x00100988:
            if (cVar12 != '\t') goto code_r0x001009ca;
            goto code_r0x0010098c;
          }
        }
        else {
          if (cVar12 != '\b') goto code_r0x00100988;
code_r0x0010098c:
          if (*(int *)(lVar18 + 0x18) != 99) goto code_r0x001009ca;
        }
        *(undefined4 *)(&stack0x00000180 + lVar15) = *(undefined4 *)(lVar18 + 0x20);
        *(undefined2 *)(&stack0x00000184 + lVar15) = *(undefined2 *)(lVar18 + 0x24);
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1009b5;
        cVar12 = func_0x(&stack0x00000180 + lVar15);
        if (cVar12 == '\0') goto code_r0x001009ca;
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1009c8;
        func_0x(lVar18,&stack0x00000140 + lVar15);
      }
      plVar22 = *pplVar42;
      lVar18 = plVar22[0x12];
      if (lVar18 == 0) {
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1009fb;
        func_0x(plVar22);
        lVar18 = plVar22[0x12];
      }
      uVar52 = *(undefined2 *)((longlong)plVar22 + 0x74);
      uVar21 = *(undefined8 *)(lVar18 + 0x6a0);
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100a16;
      lVar19 = func_0x(uVar21,uVar52,0);
      plVar22 = *pplVar42;
      lVar18 = plVar22[0x12];
      if (lVar18 == 0) {
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100a33;
        func_0x(plVar22);
        lVar18 = plVar22[0x12];
        plVar22 = **(longlong ***)(&stack0x000000d0 + lVar15);
      }
      if (((*(int *)(*(longlong *)(lVar18 + 0x7a8) + 0x58) == 0) &&
          (*(uint *)(lVar19 + 0x130) <= *(uint *)(&stack0x00000140 + lVar15))) &&
         ((*(uint *)(lVar19 + 0x130) != *(uint *)(&stack0x00000140 + lVar15) ||
          ((*(uint *)(lVar19 + 0x134) <= *(uint *)(&stack0x00000144 + lVar15) &&
           ((*(uint *)(lVar19 + 0x134) != *(uint *)(&stack0x00000144 + lVar15) ||
            (*(ushort *)(lVar19 + 0x138) <= *(ushort *)(&stack0x00000148 + lVar15))))))))) {
code_r0x00100ad2:
        lVar18 = plVar22[0x12];
        if (lVar18 == 0) {
          *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100ae6;
          func_0x(plVar22);
          pplVar42 = *(longlong ***)(&stack0x000000d0 + lVar15);
          lVar18 = plVar22[0x12];
          plVar22 = *pplVar42;
        }
        else {
          pplVar42 = *(longlong ***)(&stack0x000000d0 + lVar15);
        }
        if ((*(int *)(*(longlong *)(lVar18 + 0x7a8) + 0x110) != 0) &&
           (lVar18 = *plVar22, uVar30 = *(uint *)(lVar18 + 0x20) & 0xfffffff8,
           uVar30 != (uVar30 / 0x7cd00) * 0x7cd00)) {
          lVar19 = plVar22[0x12];
          if (lVar19 == 0) {
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100b45;
            func_0x(plVar22);
            lVar19 = plVar22[0x12];
            lVar18 = **pplVar42;
          }
          uVar21 = *(undefined8 *)(lVar19 + 0x7a8);
          *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100b62;
          func_0x(uVar21,lVar18 + 0x20);
        }
      }
      else {
        lVar18 = plVar22[0x12];
        if (lVar18 == 0) {
          *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100a97;
          func_0x(plVar22);
          pplVar42 = *(longlong ***)(&stack0x000000d0 + lVar15);
          lVar18 = plVar22[0x12];
          plVar22 = *pplVar42;
        }
        else {
          pplVar42 = *(longlong ***)(&stack0x000000d0 + lVar15);
        }
        if (((*(byte *)(*(longlong *)(lVar18 + 0x6b0) + 0x3c) & 1) != 0) &&
           (*(longlong *)(*(longlong *)(lVar18 + 0x6b0) + 0x280) == 0)) goto code_r0x00100ad2;
        lVar18 = plVar22[0x12];
        plVar37 = plVar22;
        if (lVar18 == 0) {
          *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100b7b;
          func_0x(plVar22);
          plVar37 = *pplVar42;
          lVar18 = plVar22[0x12];
        }
        lVar19 = *plVar37;
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100b91;
        func_0x(lVar18,lVar19 + 0x20);
        pplVar42 = *(longlong ***)(&stack0x000000d0 + lVar15);
      }
      puVar46 = *(undefined **)(&stack0x000000f8 + lVar15);
    }
  }
code_r0x00100b9f:
  lVar18 = **pplVar42;
  if ((*(ushort *)(lVar18 + 4) & 0x2000) != 0) {
    if (*(short *)(lVar18 + 0x24) == 0) {
code_r0x00100c14:
      *(undefined8 *)(&stack0x00000150 + lVar15) = *(undefined8 *)(lVar18 + 0x28);
      *(undefined2 *)(&stack0x00000158 + lVar15) = *(undefined2 *)(lVar18 + 0x30);
    }
    else {
      cVar12 = *(char *)(lVar18 + 1);
      if (cVar12 == '\v') {
        if (*(int *)(lVar18 + 0x18) != 99) {
code_r0x00100bd2:
          if (cVar12 != '\t') goto code_r0x00100c14;
          goto code_r0x00100bd6;
        }
      }
      else {
        if (cVar12 != '\b') goto code_r0x00100bd2;
code_r0x00100bd6:
        if (*(int *)(lVar18 + 0x18) != 99) goto code_r0x00100c14;
      }
      *(undefined4 *)(&stack0x00000188 + lVar15) = *(undefined4 *)(lVar18 + 0x20);
      *(undefined2 *)(&stack0x0000018c + lVar15) = *(undefined2 *)(lVar18 + 0x24);
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100bff;
      cVar12 = func_0x(&stack0x00000188 + lVar15);
      if (cVar12 == '\0') goto code_r0x00100c14;
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100c12;
      func_0x(lVar18,&stack0x00000150 + lVar15);
    }
    plVar22 = *pplVar42;
    lVar18 = plVar22[0x12];
    if (lVar18 == 0) {
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100c45;
      func_0x(plVar22);
      lVar18 = plVar22[0x12];
    }
    puVar6 = *(uint **)(*(longlong *)(lVar18 + 0x6b0) + 0x2c0);
    uVar30 = *(uint *)(&stack0x00000150 + lVar15);
    if ((((*(short *)((longlong)puVar6 + 10) != 2) || (uVar30 != 0)) && (uVar30 <= *puVar6)) &&
       ((uVar30 != *puVar6 ||
        ((*(uint *)(&stack0x00000154 + lVar15) <= puVar6[1] &&
         ((*(uint *)(&stack0x00000154 + lVar15) != puVar6[1] ||
          (*(ushort *)(&stack0x00000158 + lVar15) <= *(ushort *)(puVar6 + 2))))))))) {
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100c97;
      func_0x(pplVar42);
    }
  }
  *(uint *)(&stack0x00000128 + lVar15) = ((byte)~**(byte **)(&stack0x000000e0 + lVar15) & 8) << 0x13
  ;
  pcVar5 = *(code **)(*param_3 + 0x88);
  *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100cbc;
  cVar12 = (*pcVar5)(param_3);
  if ((cVar12 == '\0') && (lVar27 != 0)) {
    pcVar5 = *(code **)(*param_3 + 0x2c0);
    *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100cd2;
    (*pcVar5)(param_3);
  }
  puVar24 = *(undefined4 **)(&stack0x000000e0 + lVar15);
  puVar20 = puVar24;
  puVar31 = (undefined4 *)(&stack0x00000230 + lVar15);
  do {
    uVar14 = puVar20[1];
    uVar3 = puVar20[2];
    uVar9 = puVar20[3];
    *puVar31 = *puVar20;
    puVar31[1] = uVar14;
    puVar31[2] = uVar3;
    puVar31[3] = uVar9;
    uVar14 = puVar20[5];
    uVar3 = puVar20[6];
    uVar9 = puVar20[7];
    puVar31[4] = puVar20[4];
    puVar31[5] = uVar14;
    puVar31[6] = uVar3;
    puVar31[7] = uVar9;
    uVar14 = puVar20[9];
    uVar3 = puVar20[10];
    uVar9 = puVar20[0xb];
    puVar31[8] = puVar20[8];
    puVar31[9] = uVar14;
    puVar31[10] = uVar3;
    puVar31[0xb] = uVar9;
    uVar14 = puVar20[0xd];
    uVar3 = puVar20[0xe];
    uVar9 = puVar20[0xf];
    puVar31[0xc] = puVar20[0xc];
    puVar31[0xd] = uVar14;
    puVar31[0xe] = uVar3;
    puVar31[0xf] = uVar9;
    uVar14 = puVar20[0x11];
    uVar3 = puVar20[0x12];
    uVar9 = puVar20[0x13];
    puVar31[0x10] = puVar20[0x10];
    puVar31[0x11] = uVar14;
    puVar31[0x12] = uVar3;
    puVar31[0x13] = uVar9;
    uVar14 = puVar20[0x15];
    uVar3 = puVar20[0x16];
    uVar9 = puVar20[0x17];
    puVar31[0x14] = puVar20[0x14];
    puVar31[0x15] = uVar14;
    puVar31[0x16] = uVar3;
    puVar31[0x17] = uVar9;
    uVar14 = puVar20[0x19];
    uVar3 = puVar20[0x1a];
    uVar9 = puVar20[0x1b];
    puVar31[0x18] = puVar20[0x18];
    puVar31[0x19] = uVar14;
    puVar31[0x1a] = uVar3;
    puVar31[0x1b] = uVar9;
    uVar14 = puVar20[0x1d];
    uVar3 = puVar20[0x1e];
    uVar9 = puVar20[0x1f];
    puVar31[0x1c] = puVar20[0x1c];
    puVar31[0x1d] = uVar14;
    puVar31[0x1e] = uVar3;
    puVar31[0x1f] = uVar9;
    lVar55 = lVar55 + -1;
    puVar20 = puVar20 + 0x20;
    puVar31 = puVar31 + 0x20;
  } while (lVar55 != 0);
  pcVar5 = *(code **)*param_3;
  *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100d3f;
  cVar12 = (*pcVar5)(param_3);
  ppbVar26 = ppbVar45;
  if (((cVar12 == '\0') && (((&stack0x00000230)[lVar15] & 1) == 0)) &&
     (-1 < (char)(&stack0x00000230)[lVar15])) {
    lVar27 = param_3[0x1a];
    if (((&stack0x00000238)[lVar15] & 1) != 0) {
code_r0x00101017:
      pplVar42 = *(longlong ***)(&stack0x000000d0 + lVar15);
      goto code_r0x0010101e;
    }
    pcVar5 = *(code **)*param_3;
    *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100d7c;
    cVar12 = (*pcVar5)(param_3);
    if (cVar12 != '\0') goto code_r0x00101017;
    pcVar5 = *(code **)(*param_3 + 0x88);
    *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100d91;
    cVar12 = (*pcVar5)(param_3);
    if (cVar12 != '\0') {
      if ((&stack0x00000239)[lVar15] != '\0') goto code_r0x00101017;
      if (lVar27 == 0) {
        pcVar5 = *(code **)(*param_3 + 0x18);
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100db5;
        cVar12 = (*pcVar5)(param_3);
        if (cVar12 == '\0') goto code_r0x00101017;
      }
      if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
        if ((*(byte *)(param_3 + 0x4a) & 0x5a) == 0) {
          if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
            if (param_3[0x1a] == 0) {
              pcVar5 = *(code **)(*param_3 + 0x88);
              *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100dfc;
              cVar12 = (*pcVar5)(param_3);
              if (cVar12 != '\0') {
                pcVar5 = *(code **)(*param_3 + 0x18);
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100e0a;
                cVar12 = (*pcVar5)(param_3);
                if (cVar12 == '\0') {
                  *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                  goto code_r0x00100ee3;
                }
              }
            }
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100e24;
            iVar13 = func_0x(param_3);
            if (iVar13 == 0) {
              pcVar5 = *(code **)(*param_3 + 0x270);
              *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100e35;
              (*pcVar5)(param_3);
            }
            if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
              if ((*(byte *)(param_3 + 0x4a) & 0x52) == 2) {
                lVar55 = param_3[0x1a];
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100e73;
                cVar12 = func_0x(lVar55);
                if (((cVar12 != '\0') && (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                   (*(undefined *)(param_3[0x1a] + 0x130) = 1, *pcRam0000000001557b70 != '\0')) {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17 + lVar15) = 0;
                  *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100eb9;
                  func_0x(0x1fedfd0,0x1c,0x10,1);
                }
              }
              uVar30 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
            }
            else {
              pcVar5 = *(code **)(*param_3 + 0x1e8);
              *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100e4d;
              uVar21 = (*pcVar5)(param_3);
              *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100e55;
              uVar30 = func_0x(uVar21);
            }
            if (uVar30 != 0) goto code_r0x00100ecb;
          }
        }
        else {
code_r0x00100ecb:
          if (((*(byte *)(param_3 + 0x4a) & 0x40) != 0) && ((&stack0x0000023a)[lVar15] != '\0'))
          goto code_r0x00101017;
        }
      }
    }
code_r0x00100ee3:
    if (((&stack0x00000238)[lVar15] & 0x1c) != 0) goto code_r0x0010111d;
    if (*(longlong *)(&stack0x00000240 + lVar15) != 0) {
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100f05;
      iVar13 = func_0x();
      if (((iVar13 != 0) &&
          (iVar13 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000240 + lVar15) + 8) + 0x100),
          iVar13 != 0)) && (1 < iVar13 - 3U)) {
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17 + lVar15) = 0;
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100f4e;
        (*pcRam0000000001558390)(1,0x1a88f40,0x1a88f90,0x116);
      }
      uVar21 = *(undefined8 *)(&stack0x00000240 + lVar15);
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100f62;
      iVar13 = func_0x(uVar21);
      if (((iVar13 != 0) &&
          ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000240 + lVar15) + 8) + 0x109) & 1) == 0
          )) && ((iVar13 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000240 + lVar15) + 8) +
                                   0x100), iVar13 != 0 && (1 < iVar13 - 3U)))) {
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17 + lVar15) = 0;
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100fae;
        (*pcRam0000000001558390)(1,0x1a88fc0,0x1a88f90,0x119);
      }
    }
    if ((lVar27 == 0) || ((*(int *)(lVar27 + 0x78) < 1 && (*(int *)(lVar27 + 0x74) < 1)))) {
      if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
        if ((*(byte *)(param_3 + 0x4a) & 0x5a) != 0) {
code_r0x0010111d:
          if (lVar27 != 0) goto code_r0x00101126;
          goto code_r0x0010143f;
        }
        if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
          if (param_3[0x1a] == 0) {
            pcVar5 = *(code **)(*param_3 + 0x88);
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x100ffc;
            cVar12 = (*pcVar5)(param_3);
            if (cVar12 != '\0') {
              pcVar5 = *(code **)(*param_3 + 0x18);
              *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10100a;
              cVar12 = (*pcVar5)(param_3);
              if (cVar12 == '\0') {
                *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                goto code_r0x00101017;
              }
            }
          }
          *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101072;
          iVar13 = func_0x(param_3);
          if (iVar13 == 0) {
            pcVar5 = *(code **)(*param_3 + 0x270);
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101083;
            (*pcVar5)(param_3);
          }
          if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
            if ((*(byte *)(param_3 + 0x4a) & 0x52) == 2) {
              lVar55 = param_3[0x1a];
              *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1010c1;
              cVar12 = func_0x(lVar55);
              if (((cVar12 != '\0') && (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                 (*(undefined *)(param_3[0x1a] + 0x130) = 1, *pcRam0000000001557b70 != '\0')) {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17 + lVar15) = 0;
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101107;
                func_0x(0x1fedfd0,0x1c,0x10,1);
              }
            }
            uVar30 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
          }
          else {
            pcVar5 = *(code **)(*param_3 + 0x1e8);
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10109b;
            uVar21 = (*pcVar5)(param_3);
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1010a3;
            uVar30 = func_0x(uVar21);
          }
          if (uVar30 != 0) goto code_r0x0010111d;
        }
      }
      goto code_r0x00101017;
    }
code_r0x00101126:
    if (((&stack0x00000238)[lVar15] & 0x1c) == 0) {
      if (*(longlong *)(&stack0x00000240 + lVar15) != 0) {
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101148;
        iVar13 = func_0x();
        if (((iVar13 != 0) &&
            (iVar13 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000240 + lVar15) + 8) + 0x100),
            iVar13 != 0)) && (1 < iVar13 - 3U)) {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17 + lVar15) = 0;
          *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10118f;
          (*pcRam0000000001558390)(1,0x1a88f40,0x1a88f90,0x116);
        }
        uVar21 = *(undefined8 *)(&stack0x00000240 + lVar15);
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1011a2;
        iVar13 = func_0x(uVar21);
        if ((((iVar13 != 0) &&
             ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000240 + lVar15) + 8) + 0x109) & 1)
              == 0)) &&
            (iVar13 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000240 + lVar15) + 8) + 0x100),
            iVar13 != 0)) && (1 < iVar13 - 3U)) {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17 + lVar15) = 0;
          *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1011ed;
          (*pcRam0000000001558390)(1,0x1a88fc0,0x1a88f90,0x119);
        }
      }
      if ((*(int *)(lVar27 + 0x78) < 1) && (*(int *)(lVar27 + 0x74) < 1)) {
        if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
          if ((*(byte *)(param_3 + 0x4a) & 0x5a) == 0) {
            if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
              if (param_3[0x1a] == 0) {
                pcVar5 = *(code **)(*param_3 + 0x88);
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10123e;
                cVar11 = (*pcVar5)(param_3);
                if (cVar11 != '\0') {
                  pcVar5 = *(code **)(*param_3 + 0x18);
                  *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10124c;
                  cVar11 = (*pcVar5)(param_3);
                  if (cVar11 == '\0') {
                    *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                    goto code_r0x0010131c;
                  }
                }
              }
              *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101266;
              iVar13 = func_0x(param_3);
              if (iVar13 == 0) {
                pcVar5 = *(code **)(*param_3 + 0x270);
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101277;
                (*pcVar5)(param_3);
              }
              if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                if ((*(byte *)(param_3 + 0x4a) & 0x52) == 2) {
                  lVar55 = param_3[0x1a];
                  *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1012b5;
                  cVar11 = func_0x(lVar55);
                  if (((cVar11 != '\0') && (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(param_3[0x1a] + 0x130) = 1, *pcRam0000000001557b70 != '\0')) {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17 + lVar15) = 0;
                    *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1012fb;
                    func_0x(0x1fedfd0,0x1c,0x10,1);
                  }
                }
                uVar30 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
              }
              else {
                pcVar5 = *(code **)(*param_3 + 0x1e8);
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10128f;
                uVar21 = (*pcVar5)(param_3);
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101297;
                uVar30 = func_0x(uVar21);
              }
              if (uVar30 != 0) goto code_r0x0010130d;
            }
          }
          else {
code_r0x0010130d:
            if ((*(byte *)(param_3 + 0x4a) & 0x10) != 0) goto code_r0x0010143f;
          }
        }
code_r0x0010131c:
        if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
          if ((*(byte *)(param_3 + 0x4a) & 0x5a) == 0) {
            if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
              if (param_3[0x1a] == 0) {
                pcVar5 = *(code **)(*param_3 + 0x88);
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10135b;
                cVar11 = (*pcVar5)(param_3);
                if (cVar11 != '\0') {
                  pcVar5 = *(code **)(*param_3 + 0x18);
                  *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101369;
                  cVar11 = (*pcVar5)(param_3);
                  if (cVar11 == '\0') {
                    *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                    goto code_r0x00101435;
                  }
                }
              }
              *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101383;
              iVar13 = func_0x(param_3);
              if (iVar13 == 0) {
                pcVar5 = *(code **)(*param_3 + 0x270);
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101394;
                (*pcVar5)(param_3);
              }
              if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                if ((*(byte *)(param_3 + 0x4a) & 0x52) == 2) {
                  lVar55 = param_3[0x1a];
                  *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1013d2;
                  cVar11 = func_0x(lVar55);
                  if (((cVar11 != '\0') && (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(param_3[0x1a] + 0x130) = 1, *pcRam0000000001557b70 != '\0')) {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17 + lVar15) = 0;
                    *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101418;
                    func_0x(0x1fedfd0,0x1c,0x10,1);
                  }
                }
                uVar30 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
              }
              else {
                pcVar5 = *(code **)(*param_3 + 0x1e8);
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1013ac;
                uVar21 = (*pcVar5)(param_3);
                *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1013b4;
                uVar30 = func_0x(uVar21);
              }
              if (uVar30 != 0) goto code_r0x0010142a;
            }
          }
          else {
code_r0x0010142a:
            if ((*(byte *)(param_3 + 0x4a) & 0x40) != 0) goto code_r0x0010143f;
          }
        }
      }
    }
code_r0x00101435:
    *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10143f;
    func_0x(lVar27,0);
code_r0x0010143f:
    *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101447;
    iVar13 = func_0x(param_3);
    if (iVar13 == 0) {
      pcVar5 = *(code **)(*param_3 + 0x270);
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101458;
      (*pcVar5)(param_3);
    }
    pplVar42 = *(longlong ***)(&stack0x000000d0 + lVar15);
    plVar22 = *pplVar42;
    lVar27 = plVar22[0x12];
    if (lVar27 == 0) {
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101476;
      func_0x(plVar22);
      lVar27 = plVar22[0x12];
      pplVar42 = *(longlong ***)(&stack0x000000d0 + lVar15);
    }
    if (*(ushort *)(lVar27 + 0x67e) < 0x387) {
      uVar34 = (ushort)(byte)~(*(byte *)(*plVar22 + 2) >> 6);
    }
    else {
      uVar34 = (ushort)~*(ushort *)((longlong)plVar22 + 0x62) >> 8;
    }
    if ((uVar34 & 1) != 0) {
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1014be;
      func_0x(pplVar42,1,param_3);
    }
    lVar27 = param_3[0x1a];
    uVar30 = (uint)puVar24[6] >> 1 & 1;
    if ((*(byte *)(puVar24 + 2) & 0x24) == 0) {
      if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
        if ((*(byte *)(param_3 + 0x4a) & 0x5a) != 0) goto code_r0x0010161c;
        if ((*(byte *)(param_3 + 0x43) & 1) == 0) goto code_r0x00101605;
        if (lVar27 != 0) {
code_r0x00101541:
          *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101549;
          iVar13 = func_0x(param_3);
          if (iVar13 == 0) {
            pcVar5 = *(code **)(*param_3 + 0x270);
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10155a;
            (*pcVar5)(param_3);
          }
          if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
            if ((*(byte *)(param_3 + 0x4a) & 0x52) == 2) {
              lVar55 = param_3[0x1a];
              *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10159b;
              cVar11 = func_0x(lVar55);
              if (((cVar11 != '\0') && (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                 (*(undefined *)(param_3[0x1a] + 0x130) = 1, *pcRam0000000001557b70 != '\0')) {
                ppbVar50 = ppbVar45;
                if (lRam0000000002005f50 != 0) {
                  ppbVar50 = (byte **)(lRam0000000002005f50 + 0xe000);
                }
                if ((ppbVar50 != (byte **)0x0) && (*ppbVar50 != (byte *)0x0)) {
                  LOCK();
                  plVar22 = (longlong *)(*ppbVar50 + 0x10);
                  *plVar22 = *plVar22 + 1;
                  UNLOCK();
                }
              }
            }
            uVar40 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
          }
          else {
            pcVar5 = *(code **)(*param_3 + 0x1e8);
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101572;
            uVar21 = (*pcVar5)(param_3);
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10157a;
            uVar40 = func_0x(uVar21);
          }
          if (uVar40 != 0) goto code_r0x0010161c;
          goto code_r0x00101605;
        }
        pcVar5 = *(code **)(*param_3 + 0x88);
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101516;
        cVar11 = (*pcVar5)(param_3);
        if (cVar11 == '\0') goto code_r0x00101541;
        pcVar5 = *(code **)(*param_3 + 0x18);
        *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101524;
        cVar11 = (*pcVar5)(param_3);
        if (cVar11 != '\0') goto code_r0x00101541;
        *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
        *(undefined4 *)(&stack0x00000054 + lVar15) = 0;
        ppbVar50 = ppbVar45;
      }
      else {
code_r0x00101605:
        if ((lVar27 != 0) && (0 < *(int *)(lVar27 + 0x74))) goto code_r0x0010161c;
        ppbVar50 = (byte **)0x0;
        *(undefined4 *)(&stack0x00000054 + lVar15) = 0;
      }
    }
    else {
code_r0x0010161c:
      ppbVar50 = (byte **)0x1;
      *(undefined4 *)(&stack0x00000054 + lVar15) = 1;
    }
    iVar13 = (int)ppbVar50;
    if ((uVar30 == 0) && (iVar13 == 0)) goto code_r0x00105a35;
    puVar46 = *(undefined **)(&stack0x00000418 + lVar15);
    uVar53 = *(ulonglong *)(&stack0x00000338 + lVar15) & 0xffffffffffffe000;
    *(undefined4 *)(&stack0x00000124 + lVar15) = 0;
    if ((*(char *)(uVar53 + 2) < '\0') && (puVar46 == (undefined *)0x0)) {
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101665;
      lVar27 = func_0x();
      uVar14 = 0x1f9e;
      *(undefined4 *)(&stack0x00000420 + lVar15) = 0x1f9e;
      puVar46 = &stack0x00000050 + -lVar27 + lVar17 + lVar15;
      *(undefined **)(&stack0x00000418 + lVar15) = puVar46;
      puVar43 = &stack0xffffffffffffffc0 + -lVar27 + lVar17 + lVar15;
    }
    else {
      uVar14 = *(undefined4 *)(&stack0x00000420 + lVar15);
      puVar43 = &stack0xffffffffffffffc0 + lVar17 + lVar15;
    }
    if (*(short *)(&stack0x00000330 + lVar15) == 0) {
      bVar29 = **(byte **)(&stack0x00000338 + lVar15) & 0xe;
      *(undefined4 *)(&stack0x00000108 + lVar15) = 0;
      if (bVar29 == 2) {
        *(uint *)(&stack0x00000108 + lVar15) =
             (uint)((*(byte *)(*(longlong *)(&stack0x00000338 + lVar15) + 1) & 1) != 0);
      }
      else if (((bVar29 - 10 & 0xf9) == 0) && (bVar29 != 0x10)) {
        *(undefined4 *)(&stack0x00000108 + lVar15) = 1;
      }
    }
    else {
      *(uint *)(&stack0x00000108 + lVar15) =
           (uint)(((**(byte **)(&stack0x00000338 + lVar15) & 0x1c) - 4 & 0xffffffe7) == 0);
    }
    psVar16 = *(short **)(&stack0x000000f0 + lVar15);
    if (psVar16 == (short *)0x0) {
      if (*(char *)(uVar53 + 2) < '\0') {
        *(short *)(&stack0x000003e0 + lVar15) = *(short *)(&stack0x00000330 + lVar15);
        if (*(short *)(&stack0x00000330 + lVar15) == 0) {
          uVar40 = *(uint *)(&stack0x00000334 + lVar15);
          if (uVar40 == 0) {
            uVar40 = *(uint *)(&stack0x00000340 + lVar15);
            uVar53 = (ulonglong)uVar40;
            *(undefined2 *)(&stack0x00000332 + lVar15) = 0;
            *(uint *)(&stack0x00000344 + lVar15) = uVar40;
            if ((**(byte **)(&stack0x00000338 + lVar15) & 0x10) != 0) {
              uVar40 = uVar40 + 2 +
                       (*(ushort *)(*(byte **)(&stack0x00000338 + lVar15) + uVar53) + 7 >> 3);
              uVar53 = (ulonglong)uVar40;
              *(uint *)(&stack0x00000344 + lVar15) = uVar40;
            }
            if ((**(byte **)(&stack0x00000338 + lVar15) & 0x20) == 0) {
              *(int *)(&stack0x00000334 + lVar15) = (int)uVar53;
              *(undefined2 *)(&stack0x0000034c + lVar15) = 0;
              *(int *)(&stack0x00000348 + lVar15) = (int)uVar53;
              uVar38 = uVar53;
            }
            else {
              psVar16 = (short *)(*(byte **)(&stack0x00000338 + lVar15) + uVar53);
              sVar54 = *psVar16;
              *(short *)(&stack0x0000034c + lVar15) = sVar54;
              if (sVar54 == 0) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                   ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x101819;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10183c;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x10184d;
                func_0x(uVar21,3);
              }
              uVar40 = *(int *)(&stack0x00000344 + lVar15) +
                       (*(ushort *)(&stack0x0000034c + lVar15) + 1) * 2;
              *(uint *)(&stack0x00000348 + lVar15) = uVar40;
              if (0x1f9e < uVar40) {
                if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                   ((lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                    ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                     (*(char *)(lVar17 + 0x499) != '\0')))))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1018f1;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x101914;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x101925;
                func_0x(uVar21,4);
                uVar40 = *(uint *)(&stack0x00000348 + lVar15);
              }
              uVar36 = (ushort)psVar16[*(ushort *)(&stack0x0000034c + lVar15)] & 0x7fff;
              *(uint *)(&stack0x00000334 + lVar15) = uVar36;
              if (uVar36 < uVar40) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                   ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1019c7;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1019ea;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x1019fb;
                func_0x(uVar21,4);
                uVar40 = *(uint *)(&stack0x00000348 + lVar15);
                uVar36 = *(uint *)(&stack0x00000334 + lVar15);
              }
              uVar38 = (ulonglong)uVar40;
              uVar53 = (ulonglong)uVar36;
              do {
                uVar34 = *(ushort *)(&stack0x0000034c + lVar15);
                if (-1 < psVar16[(ulonglong)(uVar34 - 1) + 1]) break;
                uVar39 = (uint)uVar38;
                if (((uVar34 != 1) &&
                    (uVar39 = *(ushort *)
                               ((ulonglong)*(uint *)(&stack0x00000344 + lVar15) +
                                *(longlong *)(&stack0x00000338 + lVar15) + -2 +
                               (ulonglong)uVar34 * 2) & 0x7fff, uVar39 < (uint)uVar38)) ||
                   ((*(ushort *)
                      ((ulonglong)*(uint *)(&stack0x00000344 + lVar15) +
                       *(longlong *)(&stack0x00000338 + lVar15) + (ulonglong)uVar34 * 2) & 0x7fff) <
                    uVar39)) {
                  uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                  *(undefined8 *)(puVar43 + -8) = 0x101a6f;
                  func_0x(uVar21,7);
                  uVar38 = (ulonglong)*(uint *)(&stack0x00000348 + lVar15);
                  uVar53 = (ulonglong)*(uint *)(&stack0x00000334 + lVar15);
                }
                uVar40 = (uint)uVar53;
                uVar36 = (uint)uVar38;
                if ((uVar39 < uVar36) || (uVar40 < uVar39)) goto code_r0x00101dbe;
                if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(&stack0x00000338 + lVar15)) == 5)
                {
                  *(ushort *)(&stack0x00000332 + lVar15) =
                       *(ushort *)(&stack0x00000332 + lVar15) | 2;
                  *(short *)(&stack0x0000034c + lVar15) = *(short *)(&stack0x0000034c + lVar15) + -1
                  ;
                  uVar34 = *(ushort *)(&stack0x0000035c + lVar15);
                  *(short *)(&stack0x0000035a + lVar15) = (short)uVar39;
                  lVar17 = (ulonglong)(uVar39 & 0xffff) + *(longlong *)(&stack0x00000338 + lVar15);
                  uVar35 = *(ushort *)(lVar17 + 2);
                  if ((uVar35 & 0x4000) == 0) {
                    uVar34 = uVar34 & 0xc7ff;
                  }
                  else {
                    uVar34 = uVar34 ^ (uVar35 ^ uVar34) & 0x3800;
                  }
                  *(ushort *)(&stack0x0000035c + lVar15) = uVar34;
                  *(ushort *)(&stack0x0000035c + lVar15) =
                       (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
                  goto code_r0x00101b64;
                }
                if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(&stack0x00000338 + lVar15)) <
                    0x400) break;
                *(ushort *)(&stack0x00000332 + lVar15) = *(ushort *)(&stack0x00000332 + lVar15) | 1;
                psVar47 = (short *)(&stack0x0000034c + lVar15);
                *psVar47 = *psVar47 + -1;
              } while (*psVar47 != 0);
            }
            uVar36 = (uint)uVar38;
code_r0x00101b64:
            if ((**(byte **)(&stack0x00000338 + lVar15) & 0x40) == 0) {
              *(undefined4 *)(&stack0x00000356 + lVar15) = 0;
            }
            else {
              *(int *)(&stack0x00000356 + lVar15) = (int)uVar53;
              *(int *)(&stack0x00000334 + lVar15) = (int)uVar53 + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x101b8f;
              puVar25 = (ulonglong *)func_0x(&stack0x00000332 + lVar15);
              uVar53 = *puVar25;
              uVar35 = (ushort)(uVar53 >> 0x30);
              uVar34 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar34 = uVar35 & 0xdfff;
                if ((uVar53 & 0x4000000000000000) != 0) {
                  uVar34 = uVar35 | 0x2000;
                }
              }
              uVar40 = uVar44;
              if (uVar34 == 0xfffc) {
                uVar40 = (uint)((uVar53 >> 0x20 & 0xffff) >> 5);
              }
              uVar36 = *(uint *)(&stack0x00000348 + lVar15);
              uVar53 = (ulonglong)(*(int *)(&stack0x00000334 + lVar15) + uVar40);
              *(uint *)(&stack0x00000334 + lVar15) = *(int *)(&stack0x00000334 + lVar15) + uVar40;
            }
            uVar40 = (uint)uVar53;
            if ((*(ulonglong *)(&stack0x0000034e + lVar15) != 0) &&
               (*(ulonglong *)(&stack0x0000034e + lVar15) <
                uVar53 + *(longlong *)(&stack0x00000338 + lVar15))) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 (((lVar17 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                              (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                   (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x101c9f;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101cc5;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
                }
              }
              uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
              *(undefined8 *)(puVar43 + -8) = 0x101cd6;
              func_0x(uVar21,0x12);
              uVar36 = *(uint *)(&stack0x00000348 + lVar15);
              uVar40 = *(uint *)(&stack0x00000334 + lVar15);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 ((lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                             (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                  ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                   (*(char *)(lVar17 + 0x499) != '\0')))))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x101d6c;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101d92;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
                }
              }
              uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
              *(undefined8 *)(puVar43 + -8) = 0x101da3;
              func_0x(uVar21,5);
              uVar36 = *(uint *)(&stack0x00000348 + lVar15);
              uVar40 = *(uint *)(&stack0x00000334 + lVar15);
            }
          }
          else {
            uVar36 = *(uint *)(&stack0x00000348 + lVar15);
          }
code_r0x00101dbe:
          uVar39 = uVar40;
          if ((uVar40 < 9) &&
             (((**(byte **)(&stack0x00000338 + lVar15) & 0xe) == 0 ||
              ((**(byte **)(&stack0x00000338 + lVar15) & 0xe) == 0xc)))) {
            uVar39 = 9;
          }
          uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
          *(undefined4 *)(&stack0x000003f0 + lVar15) = *(undefined4 *)(&stack0x00000340 + lVar15);
          *(undefined2 *)(&stack0x000003e2 + lVar15) = *(undefined2 *)(&stack0x00000332 + lVar15);
          *(undefined2 *)(&stack0x000003fc + lVar15) = *(undefined2 *)(&stack0x0000034c + lVar15);
          *(uint *)(&stack0x000003f8 + lVar15) = uVar36;
          *(undefined4 *)(&stack0x000003f4 + lVar15) = *(undefined4 *)(&stack0x00000344 + lVar15);
          *(uint *)(&stack0x000003e4 + lVar15) = uVar40;
          *(undefined4 *)(&stack0x00000406 + lVar15) = *(undefined4 *)(&stack0x00000356 + lVar15);
          *(undefined8 *)(puVar43 + -8) = 0x101e42;
          func_0x(puVar46,uVar14,uVar21,uVar39);
          *(undefined **)(&stack0x000003e8 + lVar15) = puVar46;
          *(undefined8 *)(puVar43 + -8) = 0x101e55;
          iVar13 = func_0x(&stack0x000003e2 + lVar15);
          if (iVar13 != 0) {
            lVar17 = *(longlong *)(&stack0x000003e8 + lVar15);
            puVar48 = (ushort *)((ulonglong)*(uint *)(&stack0x000003f4 + lVar15) + lVar17);
            uVar40 = *puVar48 - 1;
            if (((&stack0x000003e2)[lVar15] & 1) == 0) {
              uVar40 = (uint)*puVar48;
            }
            if (uVar40 == 1) {
              uVar36 = *(uint *)(&stack0x000003f8 + lVar15);
code_r0x00101ea0:
              if ((puVar48[(int)uVar40] & 0x7fff) < uVar36) goto code_r0x00101ead;
            }
            else {
              uVar36 = puVar48[(longlong)(int)uVar40 + -1] & 0x7fff;
              if (*(uint *)(&stack0x000003f8 + lVar15) <= uVar36) goto code_r0x00101ea0;
code_r0x00101ead:
              *(undefined8 *)(puVar43 + -8) = 0x101eba;
              func_0x(lVar17,7);
              lVar17 = *(longlong *)(&stack0x000003e8 + lVar15);
            }
            uVar34 = *(ushort *)(&stack0x0000040c + lVar15);
            *(short *)(&stack0x0000040a + lVar15) = (short)uVar36;
            lVar17 = (ulonglong)(uVar36 & 0xffff) + lVar17;
            uVar35 = *(ushort *)(lVar17 + 2);
            if ((uVar35 >> 0xe & 1) == 0) {
              uVar34 = uVar34 & 0xc7ff;
            }
            else {
              uVar34 = uVar34 ^ (uVar35 ^ uVar34) & 0x3800;
            }
            *(ushort *)(&stack0x0000040c + lVar15) = uVar34;
            *(ushort *)(&stack0x0000040c + lVar15) =
                 (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
          }
        }
        else if ((*(longlong **)(&stack0x00000340 + lVar15) == (longlong *)0x0) ||
                (**(longlong **)(&stack0x00000340 + lVar15) == 0)) {
          *(undefined8 *)(puVar43 + -8) = 0x101f5c;
          func_0x(&stack0x000003e2 + lVar15,puVar46,uVar14,&stack0x00000332 + lVar15);
          ppbVar50 = *(byte ***)(&stack0x00000340 + lVar15);
          if (*(short *)(&stack0x00000330 + lVar15) == 0) {
            ppbVar50 = ppbVar45;
          }
          *(byte ***)(&stack0x000003f0 + lVar15) = ppbVar50;
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x101f41;
          func_0x(&stack0x000003e0 + lVar15,puVar46,uVar14,&stack0x00000330 + lVar15);
        }
        uVar14 = *(undefined4 *)(&stack0x00000420 + lVar15);
        psVar16 = (short *)(&stack0x000003e0 + lVar15);
        puVar46 = *(undefined **)(&stack0x00000418 + lVar15);
      }
      else {
        psVar16 = (short *)(&stack0x00000330 + lVar15);
      }
    }
    if (*psVar16 == 0) {
      bVar57 = (**(byte **)(psVar16 + 4) & 0xe) == 2;
    }
    else {
      bVar57 = ((**(byte **)(psVar16 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
    }
    if (bVar57) {
code_r0x00102a82:
      if (*(char *)((*(ulonglong *)(&stack0x00000338 + lVar15) & 0xffffffffffffe000) + 2) < '\0') {
        *(short *)(&stack0x000003e0 + lVar15) = *(short *)(&stack0x00000330 + lVar15);
        if (*(short *)(&stack0x00000330 + lVar15) == 0) {
          uVar40 = *(uint *)(&stack0x00000334 + lVar15);
          if (uVar40 == 0) {
            uVar40 = *(uint *)(&stack0x00000340 + lVar15);
            uVar53 = (ulonglong)uVar40;
            *(undefined2 *)(&stack0x00000332 + lVar15) = 0;
            *(uint *)(&stack0x00000344 + lVar15) = uVar40;
            if ((**(byte **)(&stack0x00000338 + lVar15) & 0x10) != 0) {
              uVar40 = uVar40 + 2 +
                       (*(ushort *)(*(byte **)(&stack0x00000338 + lVar15) + uVar53) + 7 >> 3);
              uVar53 = (ulonglong)uVar40;
              *(uint *)(&stack0x00000344 + lVar15) = uVar40;
            }
            if ((**(byte **)(&stack0x00000338 + lVar15) & 0x20) == 0) {
              *(int *)(&stack0x00000334 + lVar15) = (int)uVar53;
              *(undefined2 *)(&stack0x0000034c + lVar15) = 0;
              *(int *)(&stack0x00000348 + lVar15) = (int)uVar53;
              uVar38 = uVar53;
            }
            else {
              psVar47 = (short *)(*(byte **)(&stack0x00000338 + lVar15) + uVar53);
              sVar54 = *psVar47;
              *(short *)(&stack0x0000034c + lVar15) = sVar54;
              if (sVar54 == 0) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                   ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x102b9d;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x102bc3;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x102bd4;
                func_0x(uVar21,3);
              }
              uVar40 = *(int *)(&stack0x00000344 + lVar15) +
                       (*(ushort *)(&stack0x0000034c + lVar15) + 1) * 2;
              *(uint *)(&stack0x00000348 + lVar15) = uVar40;
              if (0x1f9e < uVar40) {
                if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                   ((lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                    ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                     (*(char *)(lVar17 + 0x499) != '\0')))))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x102c78;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x102c9e;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x102caf;
                func_0x(uVar21,4);
                uVar40 = *(uint *)(&stack0x00000348 + lVar15);
              }
              uVar38 = (ulonglong)uVar40;
              uVar36 = (ushort)psVar47[*(ushort *)(&stack0x0000034c + lVar15)] & 0x7fff;
              uVar53 = (ulonglong)uVar36;
              *(uint *)(&stack0x00000334 + lVar15) = uVar36;
              if (uVar36 < uVar40) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                   ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x102d51;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x102d77;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x102d88;
                func_0x(uVar21,4);
                uVar38 = (ulonglong)*(uint *)(&stack0x00000348 + lVar15);
                uVar53 = (ulonglong)*(uint *)(&stack0x00000334 + lVar15);
              }
              do {
                uVar34 = *(ushort *)(&stack0x0000034c + lVar15);
                if (-1 < psVar47[(ulonglong)(uVar34 - 1) + 1]) break;
                uVar36 = (uint)uVar38;
                if (((uVar34 != 1) &&
                    (uVar36 = *(ushort *)
                               ((ulonglong)*(uint *)(&stack0x00000344 + lVar15) +
                                *(longlong *)(&stack0x00000338 + lVar15) + -2 +
                               (ulonglong)uVar34 * 2) & 0x7fff, uVar36 < (uint)uVar38)) ||
                   ((*(ushort *)
                      ((ulonglong)*(uint *)(&stack0x00000344 + lVar15) +
                       *(longlong *)(&stack0x00000338 + lVar15) + (ulonglong)uVar34 * 2) & 0x7fff) <
                    uVar36)) {
                  uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                  *(undefined8 *)(puVar43 + -8) = 0x102dff;
                  func_0x(uVar21,7);
                  uVar38 = (ulonglong)*(uint *)(&stack0x00000348 + lVar15);
                  uVar53 = (ulonglong)*(uint *)(&stack0x00000334 + lVar15);
                }
                uVar40 = (uint)uVar53;
                uVar39 = (uint)uVar38;
                if ((uVar36 < uVar39) || (uVar40 < uVar36)) goto code_r0x00103148;
                if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000338 + lVar15)) == 5)
                {
                  *(ushort *)(&stack0x00000332 + lVar15) =
                       *(ushort *)(&stack0x00000332 + lVar15) | 2;
                  *(short *)(&stack0x0000034c + lVar15) = *(short *)(&stack0x0000034c + lVar15) + -1
                  ;
                  uVar34 = *(ushort *)(&stack0x0000035c + lVar15);
                  *(short *)(&stack0x0000035a + lVar15) = (short)uVar36;
                  lVar17 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(&stack0x00000338 + lVar15);
                  uVar35 = *(ushort *)(lVar17 + 2);
                  if ((uVar35 & 0x4000) == 0) {
                    uVar34 = uVar34 & 0xc7ff;
                  }
                  else {
                    uVar34 = uVar34 ^ (uVar34 ^ uVar35) & 0x3800;
                  }
                  *(ushort *)(&stack0x0000035c + lVar15) = uVar34;
                  *(ushort *)(&stack0x0000035c + lVar15) =
                       (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
                  goto code_r0x00102efc;
                }
                if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000338 + lVar15)) <
                    0x400) break;
                *(ushort *)(&stack0x00000332 + lVar15) = *(ushort *)(&stack0x00000332 + lVar15) | 1;
                psVar1 = (short *)(&stack0x0000034c + lVar15);
                *psVar1 = *psVar1 + -1;
              } while (*psVar1 != 0);
            }
            uVar39 = (uint)uVar38;
code_r0x00102efc:
            if ((**(byte **)(&stack0x00000338 + lVar15) & 0x40) == 0) {
              *(undefined4 *)(&stack0x00000356 + lVar15) = 0;
            }
            else {
              *(int *)(&stack0x00000356 + lVar15) = (int)uVar53;
              *(int *)(&stack0x00000334 + lVar15) = (int)uVar53 + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x102f27;
              puVar25 = (ulonglong *)func_0x(&stack0x00000332 + lVar15);
              uVar53 = *puVar25;
              uVar35 = (ushort)(uVar53 >> 0x30);
              uVar34 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar34 = uVar35 & 0xdfff;
                if ((uVar53 & 0x4000000000000000) != 0) {
                  uVar34 = uVar35 | 0x2000;
                }
              }
              uVar40 = uVar44;
              if (uVar34 == 0xfffc) {
                uVar40 = (uint)((uVar53 >> 0x20 & 0xffff) >> 5);
              }
              uVar39 = *(uint *)(&stack0x00000348 + lVar15);
              uVar53 = (ulonglong)(*(int *)(&stack0x00000334 + lVar15) + uVar40);
              *(uint *)(&stack0x00000334 + lVar15) = *(int *)(&stack0x00000334 + lVar15) + uVar40;
            }
            uVar40 = (uint)uVar53;
            if ((*(ulonglong *)(&stack0x0000034e + lVar15) != 0) &&
               (*(ulonglong *)(&stack0x0000034e + lVar15) <
                uVar53 + *(longlong *)(&stack0x00000338 + lVar15))) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 (((lVar17 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                              (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                   (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x103037;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10305d;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
                }
              }
              uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
              *(undefined8 *)(puVar43 + -8) = 0x10306e;
              func_0x(uVar21,0x12);
              uVar39 = *(uint *)(&stack0x00000348 + lVar15);
              uVar40 = *(uint *)(&stack0x00000334 + lVar15);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 ((lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                             (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                  ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                   (*(char *)(lVar17 + 0x499) != '\0')))))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x103104;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10312a;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
                }
              }
              uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
              *(undefined8 *)(puVar43 + -8) = 0x10313b;
              func_0x(uVar21,5);
              uVar40 = *(uint *)(&stack0x00000334 + lVar15);
              goto code_r0x00103141;
            }
          }
          else {
code_r0x00103141:
            uVar39 = *(uint *)(&stack0x00000348 + lVar15);
          }
code_r0x00103148:
          uVar36 = uVar40;
          if ((uVar40 < 9) &&
             (((**(byte **)(&stack0x00000338 + lVar15) & 0xe) == 0 ||
              ((**(byte **)(&stack0x00000338 + lVar15) & 0xe) == 0xc)))) {
            uVar36 = 9;
          }
          uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
          *(undefined4 *)(&stack0x000003f0 + lVar15) = *(undefined4 *)(&stack0x00000340 + lVar15);
          *(undefined2 *)(&stack0x000003e2 + lVar15) = *(undefined2 *)(&stack0x00000332 + lVar15);
          *(undefined2 *)(&stack0x000003fc + lVar15) = *(undefined2 *)(&stack0x0000034c + lVar15);
          *(uint *)(&stack0x000003f8 + lVar15) = uVar39;
          *(undefined4 *)(&stack0x000003f4 + lVar15) = *(undefined4 *)(&stack0x00000344 + lVar15);
          *(uint *)(&stack0x000003e4 + lVar15) = uVar40;
          *(undefined4 *)(&stack0x00000406 + lVar15) = *(undefined4 *)(&stack0x00000356 + lVar15);
          *(undefined8 *)(puVar43 + -8) = 0x1031cc;
          func_0x(puVar46,uVar14,uVar21,uVar36);
          *(undefined **)(&stack0x000003e8 + lVar15) = puVar46;
          *(undefined8 *)(puVar43 + -8) = 0x1031df;
          iVar13 = func_0x(&stack0x000003e2 + lVar15);
          if (iVar13 != 0) {
            lVar17 = *(longlong *)(&stack0x000003e8 + lVar15);
            puVar48 = (ushort *)((ulonglong)*(uint *)(&stack0x000003f4 + lVar15) + lVar17);
            uVar40 = *puVar48 - 1;
            if (((&stack0x000003e2)[lVar15] & 1) == 0) {
              uVar40 = (uint)*puVar48;
            }
            if (uVar40 == 1) {
              uVar36 = *(uint *)(&stack0x000003f8 + lVar15);
code_r0x0010322a:
              if ((puVar48[(int)uVar40] & 0x7fff) < uVar36) goto code_r0x00103237;
            }
            else {
              uVar36 = puVar48[(longlong)(int)uVar40 + -1] & 0x7fff;
              if (*(uint *)(&stack0x000003f8 + lVar15) <= uVar36) goto code_r0x0010322a;
code_r0x00103237:
              *(undefined8 *)(puVar43 + -8) = 0x103244;
              func_0x(lVar17,7);
              lVar17 = *(longlong *)(&stack0x000003e8 + lVar15);
            }
            uVar34 = *(ushort *)(&stack0x0000040c + lVar15);
            *(short *)(&stack0x0000040a + lVar15) = (short)uVar36;
            lVar17 = (ulonglong)(uVar36 & 0xffff) + lVar17;
            uVar35 = *(ushort *)(lVar17 + 2);
            if ((uVar35 >> 0xe & 1) == 0) {
              uVar34 = uVar34 & 0xc7ff;
            }
            else {
              uVar34 = uVar34 ^ (uVar34 ^ uVar35) & 0x3800;
            }
            *(ushort *)(&stack0x0000040c + lVar15) = uVar34;
            *(ushort *)(&stack0x0000040c + lVar15) =
                 (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
          }
        }
        else if ((*(longlong **)(&stack0x00000340 + lVar15) == (longlong *)0x0) ||
                (**(longlong **)(&stack0x00000340 + lVar15) == 0)) {
          *(undefined8 *)(puVar43 + -8) = 0x1032f1;
          func_0x(&stack0x000003e2 + lVar15,puVar46,uVar14,&stack0x00000332 + lVar15);
          ppbVar50 = *(byte ***)(&stack0x00000340 + lVar15);
          if (*(short *)(&stack0x00000330 + lVar15) == 0) {
            ppbVar50 = ppbVar45;
          }
          *(byte ***)(&stack0x000003f0 + lVar15) = ppbVar50;
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x1032d6;
          func_0x(&stack0x000003e0 + lVar15,puVar46,uVar14,&stack0x00000330 + lVar15);
        }
        puVar46 = &stack0x000003e0;
      }
      else {
        puVar46 = &stack0x00000330;
      }
      bVar29 = **(byte **)((longlong)(puVar46 + lVar15) + 8);
      if (*(short *)(puVar46 + lVar15) == 0) {
        if ((bVar29 & 0xe) == 2) goto code_r0x0010332d;
code_r0x00103493:
        puVar24 = *(undefined4 **)(&stack0x000000e0 + lVar15);
        if ((*(byte *)((longlong)puVar24 + 1) & 1) != 0) {
          plVar22 = (longlong *)
                    (*(longlong *)(*(longlong *)(&stack0x00000118 + lVar15) + 0x30) + 0xf8);
          *plVar22 = *plVar22 + 1;
        }
      }
      else {
        if (((bVar29 & 0x1c) - 0x10 & 0xfffffffb) != 0) goto code_r0x00103493;
code_r0x0010332d:
        puVar24 = *(undefined4 **)(&stack0x000000e0 + lVar15);
        plVar22 = (longlong *)
                  (*(longlong *)(*(longlong *)(&stack0x00000118 + lVar15) + 0x30) + 0xf0);
        *plVar22 = *plVar22 + 1;
      }
      psVar47 = *(short **)(&stack0x000000f0 + lVar15);
      *(undefined2 *)(&stack0x00000058 + lVar15) = 0xffff;
      *(undefined8 *)(&stack0x00000060 + lVar15) = 0;
      *(undefined4 *)(&stack0x0000005c + lVar15) = 0;
      *(undefined8 *)(&stack0x00000076 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000080 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000068 + lVar15) = 0;
      if (((*(byte *)puVar24 & 2) != 0) && (psVar47 == (short *)0x0)) {
        sVar54 = *psVar16;
        *(short *)(&stack0x00000058 + lVar15) = sVar54;
        if (sVar54 == 0) {
          if (*(int *)(psVar16 + 2) == 0) {
            psVar16[1] = 0;
            uVar40 = *(uint *)(psVar16 + 8);
            uVar53 = (ulonglong)uVar40;
            *(uint *)(psVar16 + 10) = uVar40;
            pbVar49 = *(byte **)(psVar16 + 4);
            bVar29 = *pbVar49;
            if ((bVar29 & 0x10) != 0) {
              uVar40 = uVar40 + (*(ushort *)(pbVar49 + uVar53) + 7 >> 3) + 2;
              uVar53 = (ulonglong)uVar40;
              *(uint *)(psVar16 + 10) = uVar40;
              bVar29 = *pbVar49;
            }
            if ((bVar29 & 0x20) == 0) {
              *(int *)(psVar16 + 2) = (int)uVar53;
              psVar16[0xe] = 0;
              *(uint *)(psVar16 + 0xc) = uVar40;
            }
            else {
              puVar48 = (ushort *)(pbVar49 + uVar53);
              uVar34 = *puVar48;
              psVar16[0xe] = uVar34;
              if (uVar34 == 0) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                   ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10347e;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1034e0;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
                  }
                }
                uVar21 = *(undefined8 *)(psVar16 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x1034ef;
                func_0x(uVar21,3);
                uVar34 = psVar16[0xe];
                uVar40 = *(uint *)(psVar16 + 10);
              }
              uVar40 = uVar40 + (uVar34 + 1) * 2;
              *(uint *)(psVar16 + 0xc) = uVar40;
              if (0x1f9e < uVar40) {
                if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                   ((lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                    ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                     (*(char *)(lVar17 + 0x499) != '\0')))))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10358e;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1035b4;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
                  }
                }
                uVar21 = *(undefined8 *)(psVar16 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x1035c3;
                func_0x(uVar21,4);
                uVar40 = *(uint *)(psVar16 + 0xc);
              }
              uVar34 = puVar48[(ushort)psVar16[0xe]];
              *(uint *)(psVar16 + 2) = uVar34 & 0x7fff;
              if ((uVar34 & 0x7fff) < uVar40) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                   ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x103661;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x103687;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
                  }
                }
                uVar21 = *(undefined8 *)(psVar16 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x103696;
                func_0x(uVar21,4);
              }
              do {
                uVar34 = psVar16[0xe];
                if (-1 < (short)puVar48[(ulonglong)(uVar34 - 1) + 1]) break;
                lVar17 = *(longlong *)(psVar16 + 4);
                if (uVar34 == 1) {
                  uVar40 = *(uint *)(psVar16 + 0xc);
code_r0x001036e0:
                  if ((*(ushort *)
                        ((ulonglong)*(uint *)(psVar16 + 10) + lVar17 + (ulonglong)uVar34 * 2) &
                      0x7fff) < uVar40) goto code_r0x001036ed;
                }
                else {
                  uVar40 = *(ushort *)
                            ((ulonglong)*(uint *)(psVar16 + 10) + lVar17 + -2 +
                            (ulonglong)uVar34 * 2) & 0x7fff;
                  if (*(uint *)(psVar16 + 0xc) <= uVar40) goto code_r0x001036e0;
code_r0x001036ed:
                  *(undefined8 *)(puVar43 + -8) = 0x1036fa;
                  func_0x(lVar17,7);
                  lVar17 = *(longlong *)(psVar16 + 4);
                  if (uVar40 < *(uint *)(psVar16 + 0xc)) goto code_r0x001039e9;
                }
                if (*(uint *)(psVar16 + 2) < uVar40) goto code_r0x001039e9;
                if (*(ushort *)((ulonglong)uVar40 + lVar17) == 5) {
                  psVar16[1] = psVar16[1] | 2;
                  psVar16[0xe] = psVar16[0xe] + -1;
                  psVar16[0x15] = (short)uVar40;
                  lVar17 = (ulonglong)(uVar40 & 0xffff) + *(longlong *)(psVar16 + 4);
                  uVar34 = psVar16[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar17 + 2) >> 0xe & 1) != 0) {
                    uVar34 = *(ushort *)(lVar17 + 2) & 0x3800 | psVar16[0x16] & 0xc7ffU;
                  }
                  psVar16[0x16] = uVar34;
                  psVar16[0x16] = (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar40 + lVar17) < 0x400) break;
                psVar16[1] = psVar16[1] | 1;
                psVar1 = psVar16 + 0xe;
                *psVar1 = *psVar1 + -1;
              } while (*psVar1 != 0);
              pbVar49 = *(byte **)(psVar16 + 4);
            }
            if ((*pbVar49 & 0x40) == 0) {
              *(undefined4 *)(psVar16 + 0x13) = 0;
            }
            else {
              *(int *)(psVar16 + 0x13) = *(int *)(psVar16 + 2);
              *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x1037ed;
              puVar25 = (ulonglong *)func_0x(psVar16 + 1);
              uVar35 = (ushort)(*puVar25 >> 0x30);
              uVar34 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar34 = uVar35 & 0xdfff;
                if ((uVar35 >> 0xe & 1) != 0) {
                  uVar34 = uVar35 | 0x2000;
                }
              }
              uVar40 = uVar44;
              if (uVar34 == 0xfffc) {
                uVar40 = (uint)((*puVar25 >> 0x20 & 0xffff) >> 5);
              }
              *(uint *)(psVar16 + 2) = *(int *)(psVar16 + 2) + uVar40;
              pbVar49 = *(byte **)(psVar16 + 4);
            }
            uVar40 = *(uint *)(psVar16 + 2);
            if ((*(byte **)(psVar16 + 0xf) != (byte *)0x0) &&
               (*(byte **)(psVar16 + 0xf) < pbVar49 + uVar40)) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 (((lVar17 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                              (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                   (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x1038f1;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x103917;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
                }
              }
              uVar21 = *(undefined8 *)(psVar16 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x103926;
              func_0x(uVar21,0x12);
              uVar40 = *(uint *)(psVar16 + 2);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 ((lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                             (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                  ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                   (*(char *)(lVar17 + 0x499) != '\0')))))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x1039b4;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1039da;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
                }
              }
              uVar21 = *(undefined8 *)(psVar16 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x1039e9;
              func_0x(uVar21,5);
            }
          }
code_r0x001039e9:
          uVar40 = *(uint *)(psVar16 + 2);
          if (uVar40 < 9) {
            pbVar49 = *(byte **)(psVar16 + 4);
            if (((*pbVar49 & 0xe) != 0) && ((*pbVar49 & 0xe) != 0xc)) goto code_r0x00103a0b;
            uVar36 = 9;
          }
          else {
code_r0x00103a0b:
            pbVar49 = *(byte **)(psVar16 + 4);
            uVar36 = uVar40;
          }
          *(undefined4 *)(&stack0x00000068 + lVar15) = *(undefined4 *)(psVar16 + 8);
          sVar54 = psVar16[1];
          *(uint *)(&stack0x0000005c + lVar15) = uVar40;
          *(short *)(&stack0x0000005a + lVar15) = sVar54;
          *(short *)(&stack0x00000074 + lVar15) = psVar16[0xe];
          *(undefined4 *)(&stack0x0000006c + lVar15) = *(undefined4 *)(psVar16 + 10);
          *(undefined4 *)(&stack0x00000070 + lVar15) = *(undefined4 *)(psVar16 + 0xc);
          *(undefined4 *)(&stack0x0000007e + lVar15) = *(undefined4 *)(psVar16 + 0x13);
          *(undefined8 *)(puVar43 + -8) = 0x103a5d;
          func_0x(&stack0x00000440 + lVar15,0x1f9e,pbVar49,uVar36);
          *(undefined **)(&stack0x00000060 + lVar15) = &stack0x00000440 + lVar15;
          *(undefined8 *)(puVar43 + -8) = 0x103a71;
          iVar13 = func_0x(&stack0x0000005a + lVar15);
          if (iVar13 != 0) {
            puVar48 = (ushort *)
                      ((ulonglong)*(uint *)(&stack0x0000006c + lVar15) +
                      *(longlong *)(&stack0x00000060 + lVar15));
            uVar40 = *puVar48 - 1;
            if (((&stack0x0000005a)[lVar15] & 1) == 0) {
              uVar40 = (uint)*puVar48;
            }
            if (uVar40 == 1) {
              uVar36 = *(uint *)(&stack0x00000070 + lVar15);
code_r0x00103aaa:
              if ((puVar48[(int)uVar40] & 0x7fff) < uVar36) goto code_r0x00103ab7;
            }
            else {
              uVar36 = puVar48[(longlong)(int)uVar40 + -1] & 0x7fff;
              if (*(uint *)(&stack0x00000070 + lVar15) <= uVar36) goto code_r0x00103aaa;
code_r0x00103ab7:
              uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
              *(undefined8 *)(puVar43 + -8) = 0x103ac5;
              func_0x(uVar21,7);
            }
            uVar34 = *(ushort *)(&stack0x00000084 + lVar15);
            *(short *)(&stack0x00000082 + lVar15) = (short)uVar36;
            lVar17 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(&stack0x00000060 + lVar15);
            uVar35 = *(ushort *)(lVar17 + 2);
            if ((uVar35 >> 0xe & 1) == 0) {
              uVar34 = uVar34 & 0xc7ff;
            }
            else {
              uVar34 = uVar34 ^ (uVar35 ^ uVar34) & 0x3800;
            }
            *(ushort *)(&stack0x00000084 + lVar15) = uVar34;
            *(ushort *)(&stack0x00000084 + lVar15) =
                 (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
          }
          puVar24 = *(undefined4 **)(&stack0x000000e0 + lVar15);
        }
        else if ((*(longlong **)(psVar16 + 8) == (longlong *)0x0) ||
                (**(longlong **)(psVar16 + 8) == 0)) {
          *(undefined8 *)(puVar43 + -8) = 0x103b61;
          func_0x(&stack0x0000005a + lVar15,&stack0x00000440 + lVar15,0x1f9e,psVar16 + 1);
          ppbVar50 = ppbVar45;
          if (*psVar16 != 0) {
            ppbVar50 = *(byte ***)(psVar16 + 8);
          }
          *(byte ***)(&stack0x00000068 + lVar15) = ppbVar50;
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x103b44;
          func_0x(&stack0x00000058 + lVar15,&stack0x00000440 + lVar15,0x1f9e,psVar16);
        }
        if (((*(byte *)((longlong)puVar24 + 1) & 2) == 0) ||
           ((*(short *)(puVar24 + 0xc) == 0 && (puVar24[0xb] == 0)))) {
          uVar40 = *(uint *)(&stack0x0000005c + lVar15);
          uVar53 = (ulonglong)uVar40;
          if (*(short *)(&stack0x00000058 + lVar15) == 0) {
            pbVar49 = *(byte **)(&stack0x00000060 + lVar15);
            if ((*pbVar49 & 0xe) == 2) goto code_r0x001042b7;
            if (uVar40 == 0) {
              uVar40 = *(uint *)(&stack0x00000068 + lVar15);
              uVar53 = (ulonglong)uVar40;
              *(uint *)(&stack0x0000006c + lVar15) = uVar40;
              *(undefined2 *)(&stack0x0000005a + lVar15) = 0;
              if ((*pbVar49 & 0x10) != 0) {
                uVar40 = uVar40 + 2 + (*(ushort *)(pbVar49 + uVar53) + 7 >> 3);
                uVar53 = (ulonglong)uVar40;
                *(uint *)(&stack0x0000006c + lVar15) = uVar40;
              }
              if ((**(byte **)(&stack0x00000060 + lVar15) & 0x20) == 0) {
                *(int *)(&stack0x0000005c + lVar15) = (int)uVar53;
                *(undefined2 *)(&stack0x00000074 + lVar15) = 0;
                *(int *)(&stack0x00000070 + lVar15) = (int)uVar53;
              }
              else {
                puVar48 = (ushort *)(*(byte **)(&stack0x00000060 + lVar15) + uVar53);
                uVar34 = *puVar48;
                *(ushort *)(&stack0x00000074 + lVar15) = uVar34;
                if (uVar34 == 0) {
                  if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                      (lVar17 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                                 (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                     ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                      (*(char *)(lVar17 + 0x499) != '\0')))) {
                    if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x103cc9;
                      (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x103cef;
                      (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
                    }
                  }
                  uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                  *(undefined8 *)(puVar43 + -8) = 0x103cfd;
                  func_0x(uVar21,3);
                  uVar34 = *(ushort *)(&stack0x00000074 + lVar15);
                }
                uVar40 = *(int *)(&stack0x0000006c + lVar15) + 2 + (uint)uVar34 * 2;
                *(uint *)(&stack0x00000070 + lVar15) = uVar40;
                if (0x1f9e < uVar40) {
                  if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                     ((lVar17 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                                 (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                      ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                       (*(char *)(lVar17 + 0x499) != '\0')))))) {
                    if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x103d9c;
                      (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x103dc2;
                      (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
                    }
                  }
                  uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                  *(undefined8 *)(puVar43 + -8) = 0x103dd0;
                  func_0x(uVar21,4);
                  uVar34 = *(ushort *)(&stack0x00000074 + lVar15);
                  uVar40 = *(uint *)(&stack0x00000070 + lVar15);
                }
                uVar38 = (ulonglong)uVar34;
                uVar36 = puVar48[uVar38] & 0x7fff;
                uVar53 = (ulonglong)uVar36;
                *(uint *)(&stack0x0000005c + lVar15) = uVar36;
                if (uVar36 < uVar40) {
                  if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                      (lVar17 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                                 (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                     ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                      (*(char *)(lVar17 + 0x499) != '\0')))) {
                    if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x103e6e;
                      (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x103e94;
                      (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
                    }
                  }
                  uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                  *(undefined8 *)(puVar43 + -8) = 0x103ea2;
                  func_0x(uVar21,4);
                  uVar38 = (ulonglong)*(ushort *)(&stack0x00000074 + lVar15);
                  uVar40 = *(uint *)(&stack0x00000070 + lVar15);
                  uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
                }
                do {
                  if (-1 < (short)puVar48[(ulonglong)((int)uVar38 - 1) + 1]) break;
                  uVar36 = uVar40;
                  if ((((int)uVar38 != 1) &&
                      (uVar36 = *(ushort *)
                                 ((ulonglong)*(uint *)(&stack0x0000006c + lVar15) +
                                  *(longlong *)(&stack0x00000060 + lVar15) + -2 + uVar38 * 2) &
                                0x7fff, uVar36 < uVar40)) ||
                     ((*(ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000006c + lVar15) +
                         *(longlong *)(&stack0x00000060 + lVar15) + uVar38 * 2) & 0x7fff) < uVar36))
                  {
                    uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                    *(undefined8 *)(puVar43 + -8) = 0x103f02;
                    func_0x(uVar21,7);
                    uVar38 = (ulonglong)*(ushort *)(&stack0x00000074 + lVar15);
                    uVar40 = *(uint *)(&stack0x00000070 + lVar15);
                    uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
                  }
                  if ((uVar36 < uVar40) || ((uint)uVar53 < uVar36)) goto code_r0x001041ea;
                  if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000060 + lVar15)) == 5
                     ) {
                    *(ushort *)(&stack0x0000005a + lVar15) =
                         *(ushort *)(&stack0x0000005a + lVar15) | 2;
                    uVar34 = *(ushort *)(&stack0x00000084 + lVar15);
                    *(short *)(&stack0x00000074 + lVar15) = (short)uVar38 + -1;
                    *(short *)(&stack0x00000082 + lVar15) = (short)uVar36;
                    lVar17 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(&stack0x00000060 + lVar15)
                    ;
                    uVar35 = *(ushort *)(lVar17 + 2);
                    if ((uVar35 & 0x4000) == 0) {
                      uVar34 = uVar34 & 0xc7ff;
                    }
                    else {
                      uVar34 = uVar34 ^ (uVar34 ^ uVar35) & 0x3800;
                    }
                    *(ushort *)(&stack0x00000084 + lVar15) = uVar34;
                    *(ushort *)(&stack0x00000084 + lVar15) =
                         (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000060 + lVar15)) <
                      0x400) break;
                  *(ushort *)(&stack0x0000005a + lVar15) =
                       *(ushort *)(&stack0x0000005a + lVar15) | 1;
                  uVar34 = (short)uVar38 - 1;
                  uVar38 = (ulonglong)uVar34;
                  *(ushort *)(&stack0x00000074 + lVar15) = uVar34;
                } while (uVar34 != 0);
              }
              if ((**(byte **)(&stack0x00000060 + lVar15) & 0x40) == 0) {
                *(undefined4 *)(&stack0x0000007e + lVar15) = 0;
              }
              else {
                *(int *)(&stack0x0000007e + lVar15) = (int)uVar53;
                *(int *)(&stack0x0000005c + lVar15) = (int)uVar53 + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x103ff9;
                puVar25 = (ulonglong *)func_0x(&stack0x0000005a + lVar15);
                uVar53 = *puVar25;
                uVar35 = (ushort)(uVar53 >> 0x30);
                uVar34 = uVar35;
                if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                  uVar34 = uVar35 & 0xdfff;
                  if ((uVar53 & 0x4000000000000000) != 0) {
                    uVar34 = uVar35 | 0x2000;
                  }
                }
                uVar40 = uVar44;
                if (uVar34 == 0xfffc) {
                  uVar40 = (uint)((uVar53 >> 0x20 & 0xffff) >> 5);
                }
                uVar53 = (ulonglong)(*(int *)(&stack0x0000005c + lVar15) + uVar40);
                *(uint *)(&stack0x0000005c + lVar15) = *(int *)(&stack0x0000005c + lVar15) + uVar40;
              }
              if ((*(ulonglong *)(&stack0x00000076 + lVar15) != 0) &&
                 (*(ulonglong *)(&stack0x00000076 + lVar15) <
                  uVar53 + *(longlong *)(&stack0x00000060 + lVar15))) {
                if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                   (((lVar17 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                                (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                     (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1040f3;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x104119;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x104127;
                func_0x(uVar21,0x12);
                uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
              }
              if (0x3f3b < (int)uVar53 - 1U) {
                if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                   ((lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                    ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                     (*(char *)(lVar17 + 0x499) != '\0')))))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1041b3;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1041d9;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x1041e7;
                func_0x(uVar21,5);
                uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
              }
            }
code_r0x001041ea:
            uVar40 = (uint)uVar53;
            if ((uVar40 < 9) &&
               (((**(byte **)(&stack0x00000060 + lVar15) & 0xe) == 0 ||
                ((**(byte **)(&stack0x00000060 + lVar15) & 0xe) == 0xc)))) {
              uVar40 = 9;
              uVar36 = *(uint *)(&stack0x0000007e + lVar15);
              bVar29 = **(byte **)(&stack0x00000060 + lVar15);
              bVar57 = (bVar29 & 0x40) == 0;
            }
            else {
              uVar36 = *(uint *)(&stack0x0000007e + lVar15);
              bVar29 = **(byte **)(&stack0x00000060 + lVar15);
              bVar57 = (bVar29 & 0x40) == 0;
            }
code_r0x0010428d:
            uVar39 = (uint)uVar53;
            if (bVar57) {
              uVar36 = uVar40;
            }
            uVar40 = 0x10;
            if (*(short *)(&stack0x00000058 + lVar15) == 0) {
              uVar40 = 0x16;
            }
            if (uVar36 < uVar40) goto code_r0x001042ad;
          }
          else {
            if (((**(byte **)(&stack0x00000060 + lVar15) & 0x1c) - 0x10 & 0xfffffffb) != 0) {
              if (uVar40 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x10424b;
                func_0x(&stack0x0000005a + lVar15);
                uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
                if (*(uint *)(&stack0x0000005c + lVar15) == 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x10425b;
                  func_0x(&stack0x0000005a + lVar15);
                  uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
                }
              }
              uVar40 = (uint)uVar53;
              if ((uVar40 < 9) &&
                 (((**(byte **)(&stack0x00000060 + lVar15) & 0x1c) == 0 ||
                  ((**(byte **)(&stack0x00000060 + lVar15) & 0x1c) == 0xc)))) {
                uVar40 = 9;
              }
              uVar36 = *(uint *)(&stack0x00000088 + lVar15);
              bVar29 = **(byte **)(&stack0x00000060 + lVar15);
              bVar57 = (bVar29 & 2) == 0;
              goto code_r0x0010428d;
            }
code_r0x001042ad:
            uVar39 = (uint)uVar53;
            if (*(short *)(&stack0x00000058 + lVar15) == 0) {
code_r0x001042b7:
              if ((int)uVar53 == 0) {
                uVar40 = *(uint *)(&stack0x00000068 + lVar15);
                uVar53 = (ulonglong)uVar40;
                *(undefined2 *)(&stack0x0000005a + lVar15) = 0;
                *(uint *)(&stack0x0000006c + lVar15) = uVar40;
                if ((**(byte **)(&stack0x00000060 + lVar15) & 0x10) != 0) {
                  uVar40 = uVar40 + 2 +
                           (*(ushort *)(*(byte **)(&stack0x00000060 + lVar15) + uVar53) + 7 >> 3);
                  uVar53 = (ulonglong)uVar40;
                  *(uint *)(&stack0x0000006c + lVar15) = uVar40;
                }
                if ((**(byte **)(&stack0x00000060 + lVar15) & 0x20) == 0) {
                  *(int *)(&stack0x0000005c + lVar15) = (int)uVar53;
                  *(undefined2 *)(&stack0x00000074 + lVar15) = 0;
                  *(int *)(&stack0x00000070 + lVar15) = (int)uVar53;
                }
                else {
                  puVar48 = (ushort *)(*(byte **)(&stack0x00000060 + lVar15) + uVar53);
                  uVar34 = *puVar48;
                  *(ushort *)(&stack0x00000074 + lVar15) = uVar34;
                  if (uVar34 == 0) {
                    if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                        (lVar17 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                                   (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                       ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                        (*(char *)(lVar17 + 0x499) != '\0')))) {
                      if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x104384;
                        (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x1043aa;
                        (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
                      }
                    }
                    uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                    *(undefined8 *)(puVar43 + -8) = 0x1043b8;
                    func_0x(uVar21,3);
                    uVar34 = *(ushort *)(&stack0x00000074 + lVar15);
                  }
                  uVar40 = *(int *)(&stack0x0000006c + lVar15) + 2 + (uint)uVar34 * 2;
                  *(uint *)(&stack0x00000070 + lVar15) = uVar40;
                  if (0x1f9e < uVar40) {
                    if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                       ((lVar17 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                                   (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                        ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                         (*(char *)(lVar17 + 0x499) != '\0')))))) {
                      if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x104457;
                        (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10447d;
                        (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
                      }
                    }
                    uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                    *(undefined8 *)(puVar43 + -8) = 0x10448b;
                    func_0x(uVar21,4);
                    uVar34 = *(ushort *)(&stack0x00000074 + lVar15);
                    uVar40 = *(uint *)(&stack0x00000070 + lVar15);
                  }
                  uVar38 = (ulonglong)uVar34;
                  uVar36 = puVar48[uVar38] & 0x7fff;
                  uVar53 = (ulonglong)uVar36;
                  *(uint *)(&stack0x0000005c + lVar15) = uVar36;
                  if (uVar36 < uVar40) {
                    if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                        (lVar17 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                                   (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                       ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                        (*(char *)(lVar17 + 0x499) != '\0')))) {
                      if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x104529;
                        (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10454f;
                        (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
                      }
                    }
                    uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                    *(undefined8 *)(puVar43 + -8) = 0x10455d;
                    func_0x(uVar21,4);
                    uVar38 = (ulonglong)*(ushort *)(&stack0x00000074 + lVar15);
                    uVar40 = *(uint *)(&stack0x00000070 + lVar15);
                    uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
                  }
                  do {
                    if (-1 < (short)puVar48[(ulonglong)((int)uVar38 - 1) + 1]) break;
                    uVar36 = uVar40;
                    if ((((int)uVar38 != 1) &&
                        (uVar36 = *(ushort *)
                                   ((ulonglong)*(uint *)(&stack0x0000006c + lVar15) +
                                    *(longlong *)(&stack0x00000060 + lVar15) + -2 + uVar38 * 2) &
                                  0x7fff, uVar36 < uVar40)) ||
                       ((*(ushort *)
                          ((ulonglong)*(uint *)(&stack0x0000006c + lVar15) +
                           *(longlong *)(&stack0x00000060 + lVar15) + uVar38 * 2) & 0x7fff) < uVar36
                       )) {
                      uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                      *(undefined8 *)(puVar43 + -8) = 0x1045c2;
                      func_0x(uVar21,7);
                      uVar38 = (ulonglong)*(ushort *)(&stack0x00000074 + lVar15);
                      uVar40 = *(uint *)(&stack0x00000070 + lVar15);
                      uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
                    }
                    if ((uVar36 < uVar40) || ((uint)uVar53 < uVar36)) goto code_r0x0010489c;
                    if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000060 + lVar15)) ==
                        5) {
                      *(ushort *)(&stack0x0000005a + lVar15) =
                           *(ushort *)(&stack0x0000005a + lVar15) | 2;
                      uVar34 = *(ushort *)(&stack0x00000084 + lVar15);
                      *(short *)(&stack0x00000074 + lVar15) = (short)uVar38 + -1;
                      *(short *)(&stack0x00000082 + lVar15) = (short)uVar36;
                      lVar17 = (ulonglong)(uVar36 & 0xffff) +
                               *(longlong *)(&stack0x00000060 + lVar15);
                      uVar35 = *(ushort *)(lVar17 + 2);
                      if ((uVar35 & 0x4000) == 0) {
                        uVar34 = uVar34 & 0xc7ff;
                      }
                      else {
                        uVar34 = uVar34 ^ (uVar34 ^ uVar35) & 0x3800;
                      }
                      *(ushort *)(&stack0x00000084 + lVar15) = uVar34;
                      *(ushort *)(&stack0x00000084 + lVar15) =
                           (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000060 + lVar15)) <
                        0x400) break;
                    *(ushort *)(&stack0x0000005a + lVar15) =
                         *(ushort *)(&stack0x0000005a + lVar15) | 1;
                    uVar34 = (short)uVar38 - 1;
                    uVar38 = (ulonglong)uVar34;
                    *(ushort *)(&stack0x00000074 + lVar15) = uVar34;
                  } while (uVar34 != 0);
                }
                if ((**(byte **)(&stack0x00000060 + lVar15) & 0x40) == 0) {
                  *(undefined4 *)(&stack0x0000007e + lVar15) = 0;
                }
                else {
                  *(int *)(&stack0x0000007e + lVar15) = (int)uVar53;
                  *(int *)(&stack0x0000005c + lVar15) = (int)uVar53 + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x1046b9;
                  puVar25 = (ulonglong *)func_0x(&stack0x0000005a + lVar15);
                  uVar53 = *puVar25;
                  uVar34 = (ushort)(uVar53 >> 0x30);
                  if ((((uint)(int)(short)uVar34 >> 1 ^ (int)(short)uVar34) & 0x2000) != 0) {
                    if ((uVar53 & 0x4000000000000000) == 0) {
                      uVar34 = uVar34 & 0xdfff;
                    }
                    else {
                      uVar34 = uVar34 | 0x2000;
                    }
                  }
                  uVar40 = uVar44;
                  if (uVar34 == 0xfffc) {
                    uVar40 = (uint)((uVar53 >> 0x20 & 0xffff) >> 5);
                  }
                  uVar53 = (ulonglong)(*(int *)(&stack0x0000005c + lVar15) + uVar40);
                  *(uint *)(&stack0x0000005c + lVar15) =
                       *(int *)(&stack0x0000005c + lVar15) + uVar40;
                }
                if ((*(ulonglong *)(&stack0x00000076 + lVar15) != 0) &&
                   (*(ulonglong *)(&stack0x00000076 + lVar15) <
                    uVar53 + *(longlong *)(&stack0x00000060 + lVar15))) {
                  if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                     (((lVar17 = *(longlong *)
                                  (*(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                                  (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                       (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                      (*(char *)(lVar17 + 0x499) != '\0')))) {
                    if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1047a5;
                      (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1047cb;
                      (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
                    }
                  }
                  uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                  *(undefined8 *)(puVar43 + -8) = 0x1047d9;
                  func_0x(uVar21,0x12);
                  uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
                }
                if (0x3f3b < (int)uVar53 - 1U) {
                  if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                     ((lVar17 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                                 (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                      ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                       (*(char *)(lVar17 + 0x499) != '\0')))))) {
                    if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x104865;
                      (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10488b;
                      (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
                    }
                  }
                  uVar21 = *(undefined8 *)(&stack0x00000060 + lVar15);
                  *(undefined8 *)(puVar43 + -8) = 0x104899;
                  func_0x(uVar21,5);
                  uVar53 = (ulonglong)*(uint *)(&stack0x0000005c + lVar15);
                }
              }
code_r0x0010489c:
              uVar39 = (uint)uVar53;
              if ((uVar39 < 9) &&
                 (((**(byte **)(&stack0x00000060 + lVar15) & 0xe) == 0 ||
                  ((**(byte **)(&stack0x00000060 + lVar15) & 0xe) == 0xc)))) {
                uVar36 = *(uint *)(&stack0x0000007e + lVar15);
                bVar29 = **(byte **)(&stack0x00000060 + lVar15);
                bVar57 = (bVar29 & 0x40) == 0;
                uVar40 = 9;
              }
              else {
                uVar36 = *(uint *)(&stack0x0000007e + lVar15);
                bVar29 = **(byte **)(&stack0x00000060 + lVar15);
                bVar57 = (bVar29 & 0x40) == 0;
                uVar40 = uVar39;
              }
            }
            else {
              if (uVar39 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x1048e8;
                func_0x(&stack0x0000005a + lVar15);
                uVar39 = *(uint *)(&stack0x0000005c + lVar15);
                if (uVar39 == 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x1048f8;
                  func_0x(&stack0x0000005a + lVar15);
                  uVar39 = *(uint *)(&stack0x0000005c + lVar15);
                }
              }
              uVar40 = uVar39;
              if ((uVar39 < 9) &&
                 (((**(byte **)(&stack0x00000060 + lVar15) & 0x1c) == 0 ||
                  ((**(byte **)(&stack0x00000060 + lVar15) & 0x1c) == 0xc)))) {
                uVar40 = 9;
              }
              uVar36 = *(uint *)(&stack0x00000088 + lVar15);
              bVar29 = **(byte **)(&stack0x00000060 + lVar15);
              bVar57 = (bVar29 & 2) == 0;
            }
            if (bVar57) {
              uVar36 = uVar40;
            }
            uVar40 = 0x18;
            if (*(short *)(&stack0x00000058 + lVar15) == 0) {
              uVar40 = 0x20;
            }
            if (uVar36 < uVar40) {
              *(undefined8 *)(puVar43 + -8) = 0x104984;
              func_0x(&stack0x00000058 + lVar15);
              goto code_r0x00104984;
            }
          }
          if (*(short *)(&stack0x00000058 + lVar15) == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x104955;
            func_0x(&stack0x0000005a + lVar15);
          }
          else if ((bVar29 & 2) != 0) {
            if (uVar39 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x104969;
              func_0x(&stack0x0000005a + lVar15);
            }
            **(byte **)(&stack0x00000060 + lVar15) = **(byte **)(&stack0x00000060 + lVar15) & 0xfd;
            *(undefined4 *)(&stack0x0000005c + lVar15) = *(undefined4 *)(&stack0x00000088 + lVar15);
            *(undefined4 *)(&stack0x00000088 + lVar15) = 0;
          }
        }
        else {
          if (*(short *)(&stack0x00000058 + lVar15) == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x103b97;
            func_0x(&stack0x0000005a + lVar15);
          }
          else if ((**(byte **)(&stack0x00000060 + lVar15) & 2) != 0) {
            if (*(int *)(&stack0x0000005c + lVar15) == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x103bb0;
              func_0x(&stack0x0000005a + lVar15);
            }
            **(byte **)(&stack0x00000060 + lVar15) = **(byte **)(&stack0x00000060 + lVar15) & 0xfd;
            *(undefined4 *)(&stack0x0000005c + lVar15) = *(undefined4 *)(&stack0x00000088 + lVar15);
            *(undefined4 *)(&stack0x00000088 + lVar15) = 0;
          }
          if (*(short *)(&stack0x00000058 + lVar15) == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x103bd3;
            func_0x();
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x103bdd;
            func_0x(&stack0x0000005a + lVar15,puVar24 + 9);
          }
        }
      }
code_r0x00104984:
      uVar40 = uVar44;
      if (((*(short *)(&stack0x00000330 + lVar15) != 0) &&
          (*(longlong **)(&stack0x00000340 + lVar15) != (longlong *)0x0)) &&
         (**(longlong **)(&stack0x00000340 + lVar15) != 0)) {
        uVar40 = 1;
      }
      if (((*(byte *)puVar24 & 2) != 0) && (psVar47 == (short *)0x0)) {
        psVar16 = (short *)(&stack0x00000058 + lVar15);
      }
      uVar14 = puVar24[2];
      uVar3 = puVar24[3];
      uVar9 = puVar24[4];
      uVar10 = puVar24[5];
      uVar21 = *(undefined8 *)(&stack0x00000110 + lVar15);
      *(undefined4 *)(puVar43 + 0x70) = 0;
      *(undefined8 *)(puVar43 + 0x68) = 0;
      *(undefined **)(puVar43 + 0x60) = &stack0x000000e8 + lVar15;
      *(undefined **)(puVar43 + 0x58) = &stack0x00000124 + lVar15;
      *(undefined4 *)(puVar43 + 0x50) = puVar24[7];
      lVar17 = *(longlong *)(&stack0x000000d0 + lVar15);
      *(uint *)(puVar43 + 0x48) = uVar30;
      *(undefined8 *)(puVar43 + 0x40) = 0;
      *(uint *)(puVar43 + 0x38) = uVar40;
      *(uint *)(puVar43 + 0x30) = (uint)(psVar47 == (short *)0x0);
      uVar7 = *(undefined8 *)(lVar17 + 0x18);
      *(undefined4 *)(puVar43 + 0x28) = 1;
      *(short **)(puVar43 + 0x20) = psVar16;
      param_3 = *(longlong **)(&stack0x00000118 + lVar15);
      *(undefined4 *)(&stack0x00000210 + lVar15) = uVar14;
      *(undefined4 *)(&stack0x00000214 + lVar15) = uVar3;
      *(undefined4 *)(&stack0x00000218 + lVar15) = uVar9;
      *(undefined4 *)(&stack0x0000021c + lVar15) = uVar10;
      *(undefined8 *)(puVar43 + -8) = 0x104a3d;
      func_0x(&stack0x00000210 + lVar15,uVar7,param_3,uVar21);
      lVar17 = *(longlong *)(&stack0x00000100 + lVar15);
      if (*(int *)(&stack0x00000124 + lVar15) == 2) {
        lVar27 = *(longlong *)(*(longlong *)(lVar17 + 8) + 0x488);
        if (((lVar27 != 0) && (*pcRam0000000001557b68 != '\0')) && ((bRam0000000001ff9f20 & 2) == 0)
           ) {
          if (*(longlong *)(lVar27 + 0x20) != 0) {
            lVar18 = (ulonglong)*puRam0000000001558400 +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam00000000015583f8 * 8
                      );
            lVar55 = *(longlong *)(lVar18 + 0x100);
            if (lVar55 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x104abb;
              (*pcRam0000000001558410)(0);
              lVar55 = *(longlong *)(lVar18 + 0x100);
            }
            ppbVar50 = ppbVar45;
            if (*(longlong *)(lVar55 + 0x260) != 0) {
              ppbVar50 = (byte **)(ulonglong)*(uint *)(*(longlong *)(lVar55 + 0x260) + 0xe68);
            }
            if ((uint)ppbVar50 < *(uint *)(lRam0000000001ffab40 + 8)) {
              lVar27 = *(longlong *)(*(longlong *)(lVar27 + 0x20) + (longlong)ppbVar50 * 8);
              *(longlong *)(lVar27 + 0x140) = *(longlong *)(lVar27 + 0x140) + 1;
              goto code_r0x00104b14;
            }
          }
          LOCK();
          plVar22 = (longlong *)(*(longlong *)(lVar27 + 0x18) + 0x140);
          *plVar22 = *plVar22 + 1;
          UNLOCK();
        }
code_r0x00104b14:
        lVar27 = *(longlong *)(*(longlong *)(lVar17 + 8) + 0x488);
        if (((lVar27 != 0) && (*pcRam0000000001557b68 != '\0')) && ((bRam0000000001ff9f20 & 2) == 0)
           ) {
          if (*(longlong *)(lVar27 + 0x20) != 0) {
            lVar18 = (ulonglong)*puRam0000000001558400 +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam00000000015583f8 * 8
                      );
            lVar55 = *(longlong *)(lVar18 + 0x100);
            if (lVar55 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x104b82;
              (*pcRam0000000001558410)(0);
              lVar55 = *(longlong *)(lVar18 + 0x100);
            }
            ppbVar50 = ppbVar45;
            if (*(longlong *)(lVar55 + 0x260) != 0) {
              ppbVar50 = (byte **)(ulonglong)*(uint *)(*(longlong *)(lVar55 + 0x260) + 0xe68);
            }
            if ((uint)ppbVar50 < *(uint *)(lRam0000000001ffab40 + 8)) {
              lVar27 = *(longlong *)(*(longlong *)(lVar27 + 0x20) + (longlong)ppbVar50 * 8);
              *(longlong *)(lVar27 + 0x150) = *(longlong *)(lVar27 + 0x150) + 1;
              uVar53 = (ulonglong)*(ushort *)(&stack0x000000ee + lVar15);
              goto code_r0x001029c8;
            }
          }
          LOCK();
          plVar22 = (longlong *)(*(longlong *)(lVar27 + 0x18) + 0x150);
          *plVar22 = *plVar22 + 1;
          UNLOCK();
          uVar53 = (ulonglong)*(ushort *)(&stack0x000000ee + lVar15);
          goto code_r0x001029c8;
        }
      }
      uVar53 = (ulonglong)*(ushort *)(&stack0x000000ee + lVar15);
    }
    else {
      if (*(char *)((*(ulonglong *)(&stack0x00000338 + lVar15) & 0xffffffffffffe000) + 2) < '\0') {
        *(short *)(&stack0x000003e0 + lVar15) = *(short *)(&stack0x00000330 + lVar15);
        if (*(short *)(&stack0x00000330 + lVar15) == 0) {
          uVar40 = *(uint *)(&stack0x00000334 + lVar15);
          if (uVar40 == 0) {
            uVar40 = *(uint *)(&stack0x00000340 + lVar15);
            uVar53 = (ulonglong)uVar40;
            *(undefined2 *)(&stack0x00000332 + lVar15) = 0;
            *(uint *)(&stack0x00000344 + lVar15) = uVar40;
            if ((**(byte **)(&stack0x00000338 + lVar15) & 0x10) != 0) {
              uVar40 = uVar40 + 2 +
                       (*(ushort *)(*(byte **)(&stack0x00000338 + lVar15) + uVar53) + 7 >> 3);
              uVar53 = (ulonglong)uVar40;
              *(uint *)(&stack0x00000344 + lVar15) = uVar40;
            }
            if ((**(byte **)(&stack0x00000338 + lVar15) & 0x20) == 0) {
              *(int *)(&stack0x00000334 + lVar15) = (int)uVar53;
              *(undefined2 *)(&stack0x0000034c + lVar15) = 0;
              *(int *)(&stack0x00000348 + lVar15) = (int)uVar53;
              uVar38 = uVar53;
            }
            else {
              psVar47 = (short *)(*(byte **)(&stack0x00000338 + lVar15) + uVar53);
              sVar54 = *psVar47;
              *(short *)(&stack0x0000034c + lVar15) = sVar54;
              if (sVar54 == 0) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                   ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1020cf;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1020f5;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x102106;
                func_0x(uVar21,3);
              }
              uVar40 = *(int *)(&stack0x00000344 + lVar15) +
                       (*(ushort *)(&stack0x0000034c + lVar15) + 1) * 2;
              *(uint *)(&stack0x00000348 + lVar15) = uVar40;
              if (0x1f9e < uVar40) {
                if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                   ((lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                    ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                     (*(char *)(lVar17 + 0x499) != '\0')))))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1021aa;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1021d0;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x1021e1;
                func_0x(uVar21,4);
                uVar40 = *(uint *)(&stack0x00000348 + lVar15);
              }
              uVar38 = (ulonglong)uVar40;
              uVar36 = (ushort)psVar47[*(ushort *)(&stack0x0000034c + lVar15)] & 0x7fff;
              uVar53 = (ulonglong)uVar36;
              *(uint *)(&stack0x00000334 + lVar15) = uVar36;
              if (uVar36 < uVar40) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar17 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
                   ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                    (*(char *)(lVar17 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x102283;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1022a9;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
                  }
                }
                uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                *(undefined8 *)(puVar43 + -8) = 0x1022ba;
                func_0x(uVar21,4);
                uVar38 = (ulonglong)*(uint *)(&stack0x00000348 + lVar15);
                uVar53 = (ulonglong)*(uint *)(&stack0x00000334 + lVar15);
              }
              do {
                uVar34 = *(ushort *)(&stack0x0000034c + lVar15);
                if (-1 < psVar47[(ulonglong)(uVar34 - 1) + 1]) break;
                uVar36 = (uint)uVar38;
                if (((uVar34 != 1) &&
                    (uVar36 = *(ushort *)
                               ((ulonglong)*(uint *)(&stack0x00000344 + lVar15) +
                                *(longlong *)(&stack0x00000338 + lVar15) + -2 +
                               (ulonglong)uVar34 * 2) & 0x7fff, uVar36 < (uint)uVar38)) ||
                   ((*(ushort *)
                      ((ulonglong)*(uint *)(&stack0x00000344 + lVar15) +
                       *(longlong *)(&stack0x00000338 + lVar15) + (ulonglong)uVar34 * 2) & 0x7fff) <
                    uVar36)) {
                  uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
                  *(undefined8 *)(puVar43 + -8) = 0x10232f;
                  func_0x(uVar21,7);
                  uVar38 = (ulonglong)*(uint *)(&stack0x00000348 + lVar15);
                  uVar53 = (ulonglong)*(uint *)(&stack0x00000334 + lVar15);
                }
                uVar40 = (uint)uVar53;
                uVar39 = (uint)uVar38;
                if ((uVar36 < uVar39) || (uVar40 < uVar36)) goto code_r0x00102673;
                if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000338 + lVar15)) == 5)
                {
                  *(ushort *)(&stack0x00000332 + lVar15) =
                       *(ushort *)(&stack0x00000332 + lVar15) | 2;
                  *(short *)(&stack0x0000034c + lVar15) = *(short *)(&stack0x0000034c + lVar15) + -1
                  ;
                  uVar34 = *(ushort *)(&stack0x0000035c + lVar15);
                  *(short *)(&stack0x0000035a + lVar15) = (short)uVar36;
                  lVar17 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(&stack0x00000338 + lVar15);
                  uVar35 = *(ushort *)(lVar17 + 2);
                  if ((uVar35 & 0x4000) == 0) {
                    uVar34 = uVar34 & 0xc7ff;
                  }
                  else {
                    uVar34 = uVar34 ^ (uVar35 ^ uVar34) & 0x3800;
                  }
                  *(ushort *)(&stack0x0000035c + lVar15) = uVar34;
                  *(ushort *)(&stack0x0000035c + lVar15) =
                       (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
                  goto code_r0x00102427;
                }
                if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000338 + lVar15)) <
                    0x400) break;
                *(ushort *)(&stack0x00000332 + lVar15) = *(ushort *)(&stack0x00000332 + lVar15) | 1;
                psVar1 = (short *)(&stack0x0000034c + lVar15);
                *psVar1 = *psVar1 + -1;
              } while (*psVar1 != 0);
            }
            uVar39 = (uint)uVar38;
code_r0x00102427:
            if ((**(byte **)(&stack0x00000338 + lVar15) & 0x40) == 0) {
              *(undefined4 *)(&stack0x00000356 + lVar15) = 0;
            }
            else {
              *(int *)(&stack0x00000356 + lVar15) = (int)uVar53;
              *(int *)(&stack0x00000334 + lVar15) = (int)uVar53 + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x102452;
              puVar25 = (ulonglong *)func_0x(&stack0x00000332 + lVar15);
              uVar53 = *puVar25;
              uVar35 = (ushort)(uVar53 >> 0x30);
              uVar34 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar34 = uVar35 & 0xdfff;
                if ((uVar53 & 0x4000000000000000) != 0) {
                  uVar34 = uVar35 | 0x2000;
                }
              }
              uVar40 = uVar44;
              if (uVar34 == 0xfffc) {
                uVar40 = (uint)((uVar53 >> 0x20 & 0xffff) >> 5);
              }
              uVar39 = *(uint *)(&stack0x00000348 + lVar15);
              uVar53 = (ulonglong)(*(int *)(&stack0x00000334 + lVar15) + uVar40);
              *(uint *)(&stack0x00000334 + lVar15) = *(int *)(&stack0x00000334 + lVar15) + uVar40;
            }
            uVar40 = (uint)uVar53;
            if ((*(ulonglong *)(&stack0x0000034e + lVar15) != 0) &&
               (*(ulonglong *)(&stack0x0000034e + lVar15) <
                uVar53 + *(longlong *)(&stack0x00000338 + lVar15))) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 (((lVar17 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                              (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                   (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x102562;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x102588;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
                }
              }
              uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
              *(undefined8 *)(puVar43 + -8) = 0x102599;
              func_0x(uVar21,0x12);
              uVar39 = *(uint *)(&stack0x00000348 + lVar15);
              uVar40 = *(uint *)(&stack0x00000334 + lVar15);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 ((lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                             (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                  ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                   (*(char *)(lVar17 + 0x499) != '\0')))))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10262f;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x102655;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
                }
              }
              uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
              *(undefined8 *)(puVar43 + -8) = 0x102666;
              func_0x(uVar21,5);
              uVar40 = *(uint *)(&stack0x00000334 + lVar15);
              goto code_r0x0010266c;
            }
          }
          else {
code_r0x0010266c:
            uVar39 = *(uint *)(&stack0x00000348 + lVar15);
          }
code_r0x00102673:
          uVar36 = uVar40;
          if ((uVar40 < 9) &&
             (((**(byte **)(&stack0x00000338 + lVar15) & 0xe) == 0 ||
              ((**(byte **)(&stack0x00000338 + lVar15) & 0xe) == 0xc)))) {
            uVar36 = 9;
          }
          uVar21 = *(undefined8 *)(&stack0x00000338 + lVar15);
          *(undefined4 *)(&stack0x000003f0 + lVar15) = *(undefined4 *)(&stack0x00000340 + lVar15);
          *(undefined2 *)(&stack0x000003e2 + lVar15) = *(undefined2 *)(&stack0x00000332 + lVar15);
          *(undefined2 *)(&stack0x000003fc + lVar15) = *(undefined2 *)(&stack0x0000034c + lVar15);
          *(uint *)(&stack0x000003f8 + lVar15) = uVar39;
          *(undefined4 *)(&stack0x000003f4 + lVar15) = *(undefined4 *)(&stack0x00000344 + lVar15);
          *(uint *)(&stack0x000003e4 + lVar15) = uVar40;
          *(undefined4 *)(&stack0x00000406 + lVar15) = *(undefined4 *)(&stack0x00000356 + lVar15);
          *(undefined8 *)(puVar43 + -8) = 0x1026f7;
          func_0x(puVar46,uVar14,uVar21,uVar36);
          *(undefined **)(&stack0x000003e8 + lVar15) = puVar46;
          *(undefined8 *)(puVar43 + -8) = 0x10270a;
          iVar13 = func_0x(&stack0x000003e2 + lVar15);
          if (iVar13 != 0) {
            lVar17 = *(longlong *)(&stack0x000003e8 + lVar15);
            puVar48 = (ushort *)((ulonglong)*(uint *)(&stack0x000003f4 + lVar15) + lVar17);
            uVar40 = *puVar48 - 1;
            if (((&stack0x000003e2)[lVar15] & 1) == 0) {
              uVar40 = (uint)*puVar48;
            }
            if (uVar40 == 1) {
              uVar36 = *(uint *)(&stack0x000003f8 + lVar15);
code_r0x00102755:
              if ((puVar48[(int)uVar40] & 0x7fff) < uVar36) goto code_r0x00102762;
            }
            else {
              uVar36 = puVar48[(longlong)(int)uVar40 + -1] & 0x7fff;
              if (*(uint *)(&stack0x000003f8 + lVar15) <= uVar36) goto code_r0x00102755;
code_r0x00102762:
              *(undefined8 *)(puVar43 + -8) = 0x10276f;
              func_0x(lVar17,7);
              lVar17 = *(longlong *)(&stack0x000003e8 + lVar15);
            }
            uVar34 = *(ushort *)(&stack0x0000040c + lVar15);
            *(short *)(&stack0x0000040a + lVar15) = (short)uVar36;
            lVar17 = (ulonglong)(uVar36 & 0xffff) + lVar17;
            uVar35 = *(ushort *)(lVar17 + 2);
            if ((uVar35 >> 0xe & 1) == 0) {
              uVar34 = uVar34 & 0xc7ff;
            }
            else {
              uVar34 = uVar34 ^ (uVar34 ^ uVar35) & 0x3800;
            }
            *(ushort *)(&stack0x0000040c + lVar15) = uVar34;
            *(ushort *)(&stack0x0000040c + lVar15) =
                 (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
          }
        }
        else if ((*(longlong **)(&stack0x00000340 + lVar15) == (longlong *)0x0) ||
                (**(longlong **)(&stack0x00000340 + lVar15) == 0)) {
          *(undefined8 *)(puVar43 + -8) = 0x10281c;
          func_0x(&stack0x000003e2 + lVar15,puVar46,uVar14,&stack0x00000332 + lVar15);
          ppbVar50 = *(byte ***)(&stack0x00000340 + lVar15);
          if (*(short *)(&stack0x00000330 + lVar15) == 0) {
            ppbVar50 = ppbVar45;
          }
          *(byte ***)(&stack0x000003f0 + lVar15) = ppbVar50;
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x102801;
          func_0x(&stack0x000003e0 + lVar15,puVar46,uVar14,&stack0x00000330 + lVar15);
        }
        uVar14 = *(undefined4 *)(&stack0x00000420 + lVar15);
        puVar8 = &stack0x000003e0;
        puVar46 = *(undefined **)(&stack0x00000418 + lVar15);
      }
      else {
        puVar8 = &stack0x00000330;
      }
      bVar29 = **(byte **)((longlong)(puVar8 + lVar15) + 8);
      if (*(short *)(puVar8 + lVar15) == 0) {
        bVar57 = (bVar29 & 0xe) == 2;
      }
      else {
        bVar57 = ((bVar29 & 0x1c) - 0x10 & 0xfffffffb) == 0;
      }
      if (((bVar57) ||
          (puVar24 = *(undefined4 **)(&stack0x000000e0 + lVar15),
          (*(byte *)((longlong)puVar24 + 1) & 1) != 0)) ||
         ((*(short *)(&stack0x00000330 + lVar15) != 0 &&
          ((*(longlong **)(&stack0x00000340 + lVar15) != (longlong *)0x0 &&
           (**(longlong **)(&stack0x00000340 + lVar15) != 0)))))) goto code_r0x00102a82;
      uVar14 = puVar24[6];
      uVar3 = *(undefined4 *)(&stack0x00000054 + lVar15);
      uVar21 = *(undefined8 *)(&stack0x000000d0 + lVar15);
      uVar7 = *(undefined8 *)(&stack0x00000118 + lVar15);
      puVar43[0x28] = 1;
      puVar43[0x20] = (char)uVar3;
      *(undefined8 *)(puVar43 + -8) = 0x1028c9;
      cVar11 = func_0x(uVar21,psVar16,uVar7,uVar14);
      if (cVar11 == '\0') {
        uVar14 = *(undefined4 *)(&stack0x00000420 + lVar15);
        puVar46 = *(undefined **)(&stack0x00000418 + lVar15);
        goto code_r0x00102a82;
      }
      param_3 = *(longlong **)(&stack0x00000118 + lVar15);
      pcVar5 = *(code **)(*param_3 + 0x50);
      *(undefined8 *)(puVar43 + -8) = 0x1028e2;
      uVar14 = (*pcVar5)(param_3);
      lVar17 = *(longlong *)(&stack0x00000100 + lVar15);
      uVar53 = 0xfffffffc;
      *(undefined4 *)(&stack0x000000e8 + lVar15) = uVar14;
      *(undefined4 *)(&stack0x000000ec + lVar15) = 0xfffc0001;
      lVar27 = *(longlong *)(*(longlong *)(lVar17 + 8) + 0x488);
      if (((lVar27 != 0) && (*pcRam0000000001557b68 != '\0')) && ((bRam0000000001ff9f20 & 2) == 0))
      {
        if (*(longlong *)(lVar27 + 0x20) != 0) {
          lVar18 = (ulonglong)*puRam0000000001558400 +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam00000000015583f8 * 8);
          lVar55 = *(longlong *)(lVar18 + 0x100);
          if (lVar55 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10296c;
            (*pcRam0000000001558410)(0);
            lVar55 = *(longlong *)(lVar18 + 0x100);
          }
          ppbVar50 = ppbVar45;
          if (*(longlong *)(lVar55 + 0x260) != 0) {
            ppbVar50 = (byte **)(ulonglong)*(uint *)(*(longlong *)(lVar55 + 0x260) + 0xe68);
          }
          if ((uint)ppbVar50 < *(uint *)(lRam0000000001ffab40 + 8)) {
            lVar27 = *(longlong *)(*(longlong *)(lVar27 + 0x20) + (longlong)ppbVar50 * 8);
            *(longlong *)(lVar27 + 0x148) = *(longlong *)(lVar27 + 0x148) + 1;
            uVar53 = (ulonglong)*(ushort *)(&stack0x000000ee + lVar15);
            goto code_r0x001029c1;
          }
        }
        LOCK();
        plVar22 = (longlong *)(*(longlong *)(lVar27 + 0x18) + 0x148);
        *plVar22 = *plVar22 + 1;
        UNLOCK();
        uVar53 = (ulonglong)*(ushort *)(&stack0x000000ee + lVar15);
      }
code_r0x001029c1:
      psVar47 = *(short **)(&stack0x000000f0 + lVar15);
    }
code_r0x001029c8:
    iVar13 = *(int *)(&stack0x00000054 + lVar15);
    if (iVar13 != 0) {
      uVar34 = (ushort)uVar53;
      if (psVar47 == (short *)0x0) {
code_r0x0010548b:
        if (*(short *)(&stack0x00000330 + lVar15) == 0) {
          if ((**(byte **)(&stack0x00000338 + lVar15) & 0xe) != 2) {
code_r0x001054d3:
            if ((((uint)(int)(short)uVar34 >> 1 ^ (int)(short)uVar34) & 0x2000) != 0) {
              if ((uVar34 >> 0xe & 1) == 0) {
                uVar53 = uVar53 & 0xffffffffffffdfff;
              }
              else {
                uVar53 = uVar53 | 0x2000;
              }
            }
            if ((short)uVar53 == -4) {
              *(undefined8 *)(&stack0x00000428 + lVar15) =
                   *(undefined8 *)(&stack0x000000e8 + lVar15);
              plVar22 = param_3;
              if ((*(byte *)(param_3 + 0x43) & 4) != 0) {
                pcVar5 = *(code **)(*param_3 + 0x1e8);
                *(undefined8 *)(puVar43 + -8) = 0x105529;
                plVar22 = (longlong *)(*pcVar5)(param_3);
                iVar13 = *(int *)(&stack0x00000054 + lVar15);
              }
              *(undefined4 *)(&stack0x00000430 + lVar15) = *(undefined4 *)(plVar22 + 5);
              *(undefined2 *)(&stack0x00000434 + lVar15) = *(undefined2 *)((longlong)plVar22 + 0x2c)
              ;
              uVar41 = 8;
              *(undefined **)(&stack0x00000168 + lVar15) = &stack0x00000428 + lVar15;
              ppbVar26 = (byte **)(&stack0x00000428 + lVar15);
              goto code_r0x00105a41;
            }
            puVar46 = *(undefined **)(&stack0x000000f8 + lVar15);
            *(short *)(&stack0x00000090 + lVar15) = *(short *)(&stack0x00000330 + lVar15);
            *(undefined2 *)(&stack0x00000092 + lVar15) = 0;
            *(undefined **)(&stack0x00000098 + lVar15) = puVar46;
            if (*(short *)(&stack0x00000330 + lVar15) == 0) {
              *(undefined4 *)(&stack0x000000b6 + lVar15) = 0;
              *puVar46 = 0xe;
              *(undefined4 *)(&stack0x000000a0 + lVar15) = 1;
              *(undefined4 *)(&stack0x000000a4 + lVar15) = 1;
              *(undefined4 *)(&stack0x00000094 + lVar15) = 1;
              *(undefined4 *)(&stack0x000000a8 + lVar15) = 1;
              *(undefined2 *)(&stack0x000000ac + lVar15) = 0;
            }
            else {
              *(undefined8 *)(&stack0x000000a8 + lVar15) = 0;
              *(undefined8 *)(&stack0x000000b0 + lVar15) = 0;
              *(undefined8 *)(&stack0x000000a0 + lVar15) = 0;
              *(undefined4 *)(&stack0x000000c0 + lVar15) = 0;
              *(undefined8 *)(&stack0x000000b8 + lVar15) = 0;
              *puVar46 = 1;
              **(byte **)(&stack0x00000098 + lVar15) = **(byte **)(&stack0x00000098 + lVar15) & 0xe7
              ;
              **(byte **)(&stack0x00000098 + lVar15) = **(byte **)(&stack0x00000098 + lVar15) | 4;
              *(undefined4 *)(&stack0x00000094 + lVar15) = 1;
            }
            goto code_r0x001056af;
          }
          *(undefined8 *)(puVar43 + -8) = 0x1054b9;
          puVar23 = (undefined8 *)
                    func_0x(&stack0x00000332 + lVar15,uVar53,&stack0x00000170 + lVar15);
        }
        else {
          if (((**(byte **)(&stack0x00000338 + lVar15) & 0x1c) - 0x10 & 0xfffffffb) != 0)
          goto code_r0x001054d3;
          *(undefined8 *)(puVar43 + -8) = 0x1055ce;
          puVar23 = (undefined8 *)func_0x(&stack0x00000332 + lVar15);
        }
        if (puVar23 == (undefined8 *)0x0) {
          *(undefined8 *)(puVar43 + -8) = 0x1055e7;
          (*pcRam0000000001558398)(6,0x55,0x10,3);
          *(undefined8 *)(&stack0x00000160 + lVar15) = 0;
          *(undefined8 *)(puVar43 + -8) = 0x1055f6;
          puVar24 = (undefined4 *)(*pcRam0000000001558730)();
          *puVar24 = 0x16;
          *(undefined8 *)(puVar43 + -8) = 0x105603;
          (*pcRam0000000001558748)();
        }
        else {
          *(undefined8 *)(&stack0x00000160 + lVar15) = *puVar23;
        }
        uVar21 = *(undefined8 *)(&stack0x000000f8 + lVar15);
        *(short *)(&stack0x00000090 + lVar15) = *(short *)(&stack0x00000330 + lVar15);
        if (*(short *)(&stack0x00000330 + lVar15) == 0) {
          puVar43[0x28] = 0;
          *(undefined4 *)(puVar43 + 0x20) = 0;
          *(undefined8 *)(puVar43 + -8) = 0x10563b;
          func_0x();
        }
        else {
          puVar43[0x20] = 0;
          *(undefined8 *)(puVar43 + -8) = 0x105647;
          func_0x(&stack0x00000092 + lVar15,uVar21);
        }
        if (*(short *)(&stack0x00000090 + lVar15) == 0) {
          pbVar49 = *(byte **)(&stack0x00000098 + lVar15);
          if ((*pbVar49 & 0xe) != 2) {
            *(undefined8 *)(puVar43 + -8) = 0x105675;
            func_0x(&stack0x00000092 + lVar15,0x400,8,&stack0x00000160 + lVar15);
            pbVar49 = *(byte **)(&stack0x00000098 + lVar15);
          }
          *pbVar49 = *pbVar49 & 0xf3;
          **(byte **)(&stack0x00000098 + lVar15) = **(byte **)(&stack0x00000098 + lVar15) | 2;
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x105695;
          func_0x(&stack0x00000092 + lVar15,&stack0x00000160 + lVar15);
        }
        pbVar49 = *(byte **)(&stack0x00000098 + lVar15);
        if (*(short *)(&stack0x00000090 + lVar15) == 0) {
          pbVar49[1] = pbVar49[1] | 1;
        }
        else {
          *pbVar49 = *pbVar49 & 0xf7;
          **(byte **)(&stack0x00000098 + lVar15) = **(byte **)(&stack0x00000098 + lVar15) | 0x14;
        }
      }
      else {
        uVar35 = uVar34;
        if ((((uint)(int)(short)uVar34 >> 1 ^ (int)(short)uVar34) & 0x2000) != 0) {
          uVar35 = uVar34 & 0xdfff;
          if ((uVar34 >> 0xe & 1) != 0) {
            uVar35 = uVar34 | 0x2000;
          }
        }
        if (uVar35 != 0xfffc) goto code_r0x0010548b;
        if ((&stack0x00000108)[lVar15] != '\0') {
          if (*(short *)(&stack0x00000330 + lVar15) == 0) {
            uVar40 = 1 << (**(byte **)(&stack0x00000338 + lVar15) & 0xe) & 0x1105;
          }
          else {
            uVar30 = **(byte **)(&stack0x00000338 + lVar15) & 0x1c;
            if ((0x10 < uVar30) || (uVar40 = 1, (0x11001U >> uVar30 & 1) == 0)) {
              uVar40 = uVar44;
            }
          }
          if (uVar40 != 0) {
            *(undefined8 *)(&stack0x00000428 + lVar15) = *(undefined8 *)(&stack0x000000e8 + lVar15);
            plVar22 = param_3;
            if ((*(byte *)(param_3 + 0x43) & 4) != 0) {
              pcVar5 = *(code **)(*param_3 + 0x1e8);
              *(undefined8 *)(puVar43 + -8) = 0x104c50;
              plVar22 = (longlong *)(*pcVar5)(param_3);
              iVar13 = *(int *)(&stack0x00000054 + lVar15);
            }
            *(undefined4 *)(&stack0x00000430 + lVar15) = *(undefined4 *)(plVar22 + 5);
            *(undefined2 *)(&stack0x00000434 + lVar15) = *(undefined2 *)((longlong)plVar22 + 0x2c);
            uVar41 = 0x100000;
            *(undefined **)(&stack0x00000168 + lVar15) = &stack0x00000428 + lVar15;
            ppbVar26 = (byte **)(&stack0x00000428 + lVar15);
            goto code_r0x00105a41;
          }
        }
        sVar54 = *psVar47;
        *(short *)(&stack0x00000090 + lVar15) = sVar54;
        if (sVar54 == 0) {
          if (*(int *)(psVar47 + 2) == 0) {
            psVar47[1] = 0;
            uVar30 = *(uint *)(psVar47 + 8);
            uVar53 = (ulonglong)uVar30;
            *(uint *)(psVar47 + 10) = uVar30;
            pbVar49 = *(byte **)(psVar47 + 4);
            bVar29 = *pbVar49;
            pbVar32 = pbVar49;
            if ((bVar29 & 0x10) != 0) {
              uVar30 = uVar30 + (*(ushort *)(pbVar49 + uVar53) + 7 >> 3) + 2;
              uVar53 = (ulonglong)uVar30;
              *(uint *)(psVar47 + 10) = uVar30;
              bVar29 = *pbVar49;
              pbVar32 = *(byte **)(psVar47 + 4);
            }
            if ((bVar29 & 0x20) == 0) {
              *(int *)(psVar47 + 2) = (int)uVar53;
              psVar47[0xe] = 0;
              *(uint *)(psVar47 + 0xc) = uVar30;
            }
            else {
              puVar48 = (ushort *)(pbVar49 + uVar53);
              uVar34 = *puVar48;
              psVar47[0xe] = uVar34;
              if (uVar34 == 0) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar27 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar27 != 0)) &&
                   ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                    (*(char *)(lVar27 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x104d77;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x104d9a;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
                  }
                }
                uVar21 = *(undefined8 *)(psVar47 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x104da8;
                func_0x(uVar21,3);
                uVar34 = psVar47[0xe];
                uVar30 = *(uint *)(psVar47 + 10);
              }
              uVar30 = uVar30 + (uVar34 + 1) * 2;
              *(uint *)(psVar47 + 0xc) = uVar30;
              if (0x1f9e < uVar30) {
                if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                   ((lVar27 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar27 != 0 &&
                    ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                     (*(char *)(lVar27 + 0x499) != '\0')))))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x104e45;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x104e68;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
                  }
                }
                uVar21 = *(undefined8 *)(psVar47 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x104e76;
                func_0x(uVar21,4);
                uVar30 = *(uint *)(psVar47 + 0xc);
              }
              uVar34 = puVar48[(ushort)psVar47[0xe]];
              *(uint *)(psVar47 + 2) = uVar34 & 0x7fff;
              if ((uVar34 & 0x7fff) < uVar30) {
                if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                    (lVar27 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                               (ulonglong)*puRam0000000001558400), lVar27 != 0)) &&
                   ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                    (*(char *)(lVar27 + 0x499) != '\0')))) {
                  if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x104f11;
                    (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x104f34;
                    (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
                  }
                }
                uVar21 = *(undefined8 *)(psVar47 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x104f42;
                func_0x(uVar21,4);
              }
              do {
                uVar34 = psVar47[0xe];
                if (-1 < (short)puVar48[(ulonglong)(uVar34 - 1) + 1]) break;
                lVar27 = *(longlong *)(psVar47 + 4);
                if (uVar34 == 1) {
                  uVar30 = *(uint *)(psVar47 + 0xc);
                  uVar53 = (ulonglong)uVar30;
code_r0x00104f92:
                  if ((*(ushort *)
                        ((ulonglong)*(uint *)(psVar47 + 10) + lVar27 + (ulonglong)uVar34 * 2) &
                      0x7fff) < (uint)uVar53) goto code_r0x00104fa0;
                }
                else {
                  uVar30 = *(uint *)(psVar47 + 0xc);
                  uVar40 = *(ushort *)
                            ((ulonglong)*(uint *)(psVar47 + 10) + lVar27 + -2 +
                            (ulonglong)uVar34 * 2) & 0x7fff;
                  uVar53 = (ulonglong)uVar40;
                  if (uVar30 <= uVar40) goto code_r0x00104f92;
code_r0x00104fa0:
                  *(undefined8 *)(puVar43 + -8) = 0x104fad;
                  func_0x(lVar27,7);
                  uVar30 = *(uint *)(psVar47 + 0xc);
                  lVar27 = *(longlong *)(psVar47 + 4);
                }
                if (((uint)uVar53 < uVar30) || (*(uint *)(psVar47 + 2) < (uint)uVar53))
                goto code_r0x00105285;
                if (*(ushort *)(lVar27 + uVar53) == 5) {
                  psVar47[1] = psVar47[1] | 2;
                  psVar47[0xe] = psVar47[0xe] + -1;
                  psVar47[0x15] = (short)uVar53;
                  lVar27 = (uVar53 & 0xffff) + *(longlong *)(psVar47 + 4);
                  uVar34 = psVar47[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar27 + 2) >> 0xe & 1) != 0) {
                    uVar34 = *(ushort *)(lVar27 + 2) & 0x3800 | psVar47[0x16] & 0xc7ffU;
                  }
                  psVar47[0x16] = uVar34;
                  psVar47[0x16] = (uVar34 ^ *(ushort *)(lVar27 + 2)) & 0x7ff ^ uVar34;
                  break;
                }
                if (*(ushort *)(lVar27 + uVar53) < 0x400) break;
                psVar47[1] = psVar47[1] | 1;
                psVar16 = psVar47 + 0xe;
                *psVar16 = *psVar16 + -1;
              } while (*psVar16 != 0);
              pbVar32 = *(byte **)(psVar47 + 4);
              uVar53 = (ulonglong)*(uint *)(psVar47 + 2);
            }
            if ((*pbVar32 & 0x40) == 0) {
              *(undefined4 *)(psVar47 + 0x13) = 0;
            }
            else {
              *(int *)(psVar47 + 0x13) = *(int *)(psVar47 + 2);
              *(int *)(psVar47 + 2) = *(int *)(psVar47 + 2) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x10508d;
              puVar25 = (ulonglong *)func_0x(psVar47 + 1);
              uVar35 = (ushort)(*puVar25 >> 0x30);
              uVar34 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar34 = uVar35 & 0xdfff;
                if ((uVar35 >> 0xe & 1) != 0) {
                  uVar34 = uVar35 | 0x2000;
                }
              }
              uVar30 = uVar44;
              if (uVar34 == 0xfffc) {
                uVar30 = (uint)((*puVar25 >> 0x20 & 0xffff) >> 5);
              }
              *(uint *)(psVar47 + 2) = *(int *)(psVar47 + 2) + uVar30;
              uVar53 = (ulonglong)*(uint *)(psVar47 + 2);
              pbVar32 = *(byte **)(psVar47 + 4);
            }
            iVar13 = (int)uVar53;
            if ((*(byte **)(psVar47 + 0xf) != (byte *)0x0) &&
               (*(byte **)(psVar47 + 0xf) < pbVar32 + uVar53)) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 (((lVar27 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                              (ulonglong)*puRam0000000001558400), lVar27 != 0 &&
                   (lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0)) &&
                  (*(char *)(lVar27 + 0x499) != '\0')))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10518f;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1051b5;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
                }
              }
              uVar21 = *(undefined8 *)(psVar47 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x1051c3;
              func_0x(uVar21,0x12);
              iVar13 = *(int *)(psVar47 + 2);
            }
            if (0x3f3b < iVar13 - 1U) {
              if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                 ((lVar27 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                             (ulonglong)*puRam0000000001558400), lVar27 != 0 &&
                  ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                   (*(char *)(lVar27 + 0x499) != '\0')))))) {
                if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x105251;
                  (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x105277;
                  (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
                }
              }
              uVar21 = *(undefined8 *)(psVar47 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x105285;
              func_0x(uVar21,5);
            }
          }
code_r0x00105285:
          uVar30 = *(uint *)(psVar47 + 2);
          if (uVar30 < 9) {
            pbVar49 = *(byte **)(psVar47 + 4);
            if (((*pbVar49 & 0xe) != 0) && ((*pbVar49 & 0xe) != 0xc)) goto code_r0x001052a5;
            uVar40 = 9;
          }
          else {
code_r0x001052a5:
            pbVar49 = *(byte **)(psVar47 + 4);
            uVar40 = uVar30;
          }
          uVar21 = *(undefined8 *)(&stack0x000000f8 + lVar15);
          *(undefined4 *)(&stack0x000000a0 + lVar15) = *(undefined4 *)(psVar47 + 8);
          sVar54 = psVar47[1];
          *(uint *)(&stack0x00000094 + lVar15) = uVar30;
          *(short *)(&stack0x00000092 + lVar15) = sVar54;
          *(short *)(&stack0x000000ac + lVar15) = psVar47[0xe];
          *(undefined4 *)(&stack0x000000a4 + lVar15) = *(undefined4 *)(psVar47 + 10);
          *(undefined4 *)(&stack0x000000a8 + lVar15) = *(undefined4 *)(psVar47 + 0xc);
          *(undefined4 *)(&stack0x000000b6 + lVar15) = *(undefined4 *)(psVar47 + 0x13);
          *(undefined8 *)(puVar43 + -8) = 0x1052f3;
          func_0x(uVar21,0x1f9e,pbVar49,uVar40);
          *(undefined8 *)(&stack0x00000098 + lVar15) = uVar21;
          *(undefined8 *)(puVar43 + -8) = 0x105300;
          iVar13 = func_0x(&stack0x00000092 + lVar15);
          pbVar49 = *(byte **)(&stack0x00000098 + lVar15);
          if (iVar13 != 0) {
            puVar48 = (ushort *)(pbVar49 + *(uint *)(&stack0x000000a4 + lVar15));
            uVar30 = *puVar48 - 1;
            if (((&stack0x00000092)[lVar15] & 1) == 0) {
              uVar30 = (uint)*puVar48;
            }
            if (uVar30 == 1) {
              uVar40 = *(uint *)(&stack0x000000a8 + lVar15);
code_r0x0010533c:
              if ((puVar48[(int)uVar30] & 0x7fff) < uVar40) goto code_r0x00105349;
            }
            else {
              uVar40 = puVar48[(longlong)(int)uVar30 + -1] & 0x7fff;
              if (*(uint *)(&stack0x000000a8 + lVar15) <= uVar40) goto code_r0x0010533c;
code_r0x00105349:
              *(undefined8 *)(puVar43 + -8) = 0x105356;
              func_0x(pbVar49,7);
              pbVar49 = *(byte **)(&stack0x00000098 + lVar15);
            }
            uVar34 = *(ushort *)(&stack0x000000bc + lVar15);
            *(short *)(&stack0x000000ba + lVar15) = (short)uVar40;
            if ((*(ushort *)(pbVar49 + (ulonglong)(uVar40 & 0xffff) + 2) >> 0xe & 1) == 0) {
              uVar34 = uVar34 & 0xc7ff;
            }
            else {
              uVar34 = uVar34 ^ (*(ushort *)(pbVar49 + (ulonglong)(uVar40 & 0xffff) + 2) ^ uVar34) &
                                0x3800;
            }
            *(ushort *)(&stack0x000000bc + lVar15) = uVar34;
            *(ushort *)(&stack0x000000bc + lVar15) =
                 (uVar34 ^ *(ushort *)(pbVar49 + (ulonglong)(uVar40 & 0xffff) + 2)) & 0x7ff ^ uVar34
            ;
          }
        }
        else {
          uVar21 = *(undefined8 *)(&stack0x000000f8 + lVar15);
          *(undefined8 *)(puVar43 + -8) = 0x1053c4;
          func_0x(&stack0x00000092 + lVar15,uVar21,0x1f9e,psVar47 + 1);
          ppbVar50 = ppbVar45;
          if (*psVar47 != 0) {
            ppbVar50 = *(byte ***)(psVar47 + 8);
          }
          pbVar49 = *(byte **)(&stack0x00000098 + lVar15);
          *(byte ***)(&stack0x000000a0 + lVar15) = ppbVar50;
        }
        if (*(short *)(&stack0x00000090 + lVar15) == 0) {
          bVar29 = *pbVar49;
          bVar28 = bVar29 & 0xe;
          if (bVar28 == 0) {
code_r0x0010542b:
            *pbVar49 = bVar29 & 0xfd | 0xc;
          }
          else if (bVar28 == 6) {
            *pbVar49 = bVar29 & 0xfb | 10;
          }
          else {
            if (bVar28 == 8) goto code_r0x0010542b;
            *(undefined8 *)(puVar43 + 0x20) = 0x1656a78;
            *(undefined8 *)(puVar43 + -8) = 0x105420;
            (*pcRam0000000001558390)(1,0x1a5b8d0,0x1a86d08,0xec3);
          }
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x10543d;
          func_0x(&stack0x00000092 + lVar15);
        }
        if (*(short *)(&stack0x00000090 + lVar15) == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x10544c;
          func_0x(&stack0x00000092 + lVar15);
          *pcVar2 = '\x01';
        }
        else {
          pbVar49 = *(byte **)(&stack0x00000098 + lVar15);
          if ((*pbVar49 & 2) != 0) {
            if (*(int *)(&stack0x00000094 + lVar15) == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x10546c;
              func_0x(&stack0x00000092 + lVar15);
              pbVar49 = *(byte **)(&stack0x00000098 + lVar15);
            }
            *pbVar49 = *pbVar49 & 0xfd;
            *(undefined4 *)(&stack0x00000094 + lVar15) = *(undefined4 *)(&stack0x000000c0 + lVar15);
            *(undefined4 *)(&stack0x000000c0 + lVar15) = 0;
          }
          *pcVar2 = '\x01';
        }
      }
code_r0x001056af:
      plVar22 = param_3;
      if ((*(byte *)(param_3 + 0x43) & 4) != 0) {
        pcVar5 = *(code **)(*param_3 + 0x1e8);
        *(undefined8 *)(puVar43 + -8) = 0x1056ce;
        plVar22 = (longlong *)(*pcVar5)(param_3);
      }
      if (*(short *)(&stack0x00000090 + lVar15) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x1056e4;
        func_0x();
      }
      else {
        *(undefined8 *)(puVar43 + -8) = 0x1056eb;
        func_0x(&stack0x00000092 + lVar15,plVar22 + 5);
      }
      if (*(short *)(&stack0x00000090 + lVar15) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x105701;
        func_0x(&stack0x00000092 + lVar15,&stack0x000000e8 + lVar15);
      }
      else {
        if (*(int *)(&stack0x00000094 + lVar15) == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x105711;
          func_0x(&stack0x00000092 + lVar15);
        }
        *(undefined8 *)(puVar43 + -8) = 0x10571a;
        func_0x(&stack0x00000092 + lVar15);
        ppbVar50 = ppbVar45;
        if ((**(byte **)(&stack0x00000098 + lVar15) & 2) != 0) {
          ppbVar50 = (byte **)(*(byte **)(&stack0x00000098 + lVar15) +
                              *(uint *)(&stack0x000000c0 + lVar15));
        }
        *ppbVar50 = *(byte **)(&stack0x000000e8 + lVar15);
        *(undefined4 *)(&stack0x00000094 + lVar15) = 0;
        *(undefined8 *)(puVar43 + -8) = 0x105744;
        func_0x(&stack0x00000092 + lVar15);
      }
      lVar27 = *(longlong *)(&stack0x00000110 + lVar15);
      *(undefined **)(&stack0x000001a0 + lVar15) = &stack0x00000090 + lVar15;
      if (*(char *)(lVar27 + 2) < '\0') {
        puVar24 = (undefined4 *)(puVar43 + 0x50);
        uVar14 = *puVar24;
        uVar52 = 0xffff;
        *(undefined2 *)puVar24 = 0xffff;
        *(undefined8 *)(puVar43 + 0x58) = 0;
        *(undefined4 *)(puVar43 + 0x54) = 0;
        *(undefined8 *)(puVar43 + 0x6e) = 0;
        *(undefined8 *)(puVar43 + 0x78) = 0;
        *(undefined8 *)(puVar43 + 0x60) = 0;
        *(undefined8 *)(puVar43 + -0x48) = 0x10579a;
        lVar55 = func_0x(uVar14);
        lVar55 = -lVar55;
        *(undefined (*) [16])(puVar43 + lVar55 + -0x30) = ZEXT816(0);
        *(undefined (*) [16])(puVar43 + lVar55 + -0x20) = ZEXT816(0);
        *(undefined (*) [16])(puVar43 + lVar55 + -0x10) = ZEXT816(0);
        *(undefined (*) [16])(puVar43 + lVar55) = ZEXT816(0);
        *(undefined (*) [16])(puVar43 + lVar55 + 0x10) = ZEXT816(0);
        *(undefined (*) [16])(puVar43 + lVar55 + 0x20) = ZEXT816(0);
        *(undefined (*) [16])(puVar43 + lVar55 + 0x30) = ZEXT816(0);
        *(undefined8 *)(puVar43 + lVar55 + 0x40) = 0;
        *(undefined2 *)(puVar43 + lVar55 + -0x20) = uVar52;
        *(undefined8 *)(puVar43 + lVar55 + -0x18) = 0;
        *(undefined4 *)(puVar43 + lVar55 + -0x1c) = 0;
        *(undefined8 *)(puVar43 + lVar55 + -2) = 0;
        *(undefined8 *)(puVar43 + lVar55 + 8) = 0;
        *(undefined8 *)(puVar43 + lVar55 + -0x10) = 0;
        *(undefined8 *)(puVar43 + lVar55 + 0x18) = 0;
        *(undefined8 *)(puVar43 + lVar55 + 0x30) = 0;
        *(undefined4 *)(puVar43 + lVar55 + 0x38) = 0;
        *(undefined2 *)(puVar43 + lVar55 + 0x42) = 0;
        *(undefined **)(&stack0x000001b0 + lVar15) = puVar43 + lVar55 + 0x50;
        *(undefined (**) [16])(&stack0x000001c0 + lVar15) =
             (undefined (*) [16])(puVar43 + lVar55 + -0x30);
        *(undefined4 **)(&stack0x000001a8 + lVar15) = puVar24;
        *(undefined4 *)(&stack0x000001b8 + lVar15) = 0x1f9e;
        *(undefined8 *)(puVar43 + lVar55 + -200) = 0x105832;
        func_0x(&stack0x000001a0 + lVar15,lVar27);
        puVar43 = puVar43 + lVar55 + -0xc0;
      }
      iVar13 = *(int *)(&stack0x00000054 + lVar15);
      puVar24 = *(undefined4 **)(&stack0x000000e0 + lVar15);
    }
  }
  else {
code_r0x0010101e:
    if (*(char *)(param_3[6] + 0x1cde) == '\0') {
      pcVar5 = *(code **)(*param_3 + 0x18);
      *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x101036;
      cVar12 = (*pcVar5)(param_3);
      if (cVar12 != '\0') goto code_r0x0010103e;
    }
    else {
code_r0x0010103e:
      if ((*(byte *)puVar24 & 1) != 0) {
        if (*(short *)(&stack0x00000330 + lVar15) == 0) {
          bVar57 = (**(byte **)(&stack0x00000338 + lVar15) & 0xe) == 2;
        }
        else {
          bVar57 = ((**(byte **)(&stack0x00000338 + lVar15) & 0x1c) - 0x10 & 0xfffffffb) == 0;
        }
        if ((bVar57) && (cVar11 == '\0')) {
          plVar22 = *pplVar42;
          lVar27 = plVar22[0x12];
          if (lVar27 == 0) {
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x105877;
            func_0x(plVar22);
            lVar27 = plVar22[0x12];
          }
          if (*(ushort *)(lVar27 + 0x67e) < 0x387) {
            uVar34 = (ushort)(byte)~(*(byte *)(*plVar22 + 2) >> 6);
          }
          else {
            uVar34 = (ushort)~*(ushort *)((longlong)plVar22 + 0x62) >> 8;
          }
          if ((uVar34 & 1) != 0) {
            *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x1058b8;
            func_0x(pplVar42,1,param_3);
          }
          *(short *)(&stack0x00000090 + lVar15) = *(short *)(&stack0x00000330 + lVar15);
          *(undefined **)(&stack0x00000098 + lVar15) = puVar46;
          *(undefined2 *)(&stack0x00000092 + lVar15) = 0;
          if (*(short *)(&stack0x00000330 + lVar15) == 0) {
            *(undefined4 *)(&stack0x000000b6 + lVar15) = 0;
            *puVar46 = 0xe;
            *(undefined4 *)(&stack0x000000a0 + lVar15) = 1;
            *(undefined4 *)(&stack0x000000a4 + lVar15) = 1;
            *(undefined4 *)(&stack0x000000a8 + lVar15) = 1;
            *(undefined2 *)(&stack0x000000ac + lVar15) = 0;
          }
          else {
            *(undefined8 *)(&stack0x000000a8 + lVar15) = 0;
            *(undefined8 *)(&stack0x000000b0 + lVar15) = 0;
            *(undefined8 *)(&stack0x000000a0 + lVar15) = 0;
            *(undefined4 *)(&stack0x000000c0 + lVar15) = 0;
            *(undefined8 *)(&stack0x000000b8 + lVar15) = 0;
            *puVar46 = 1;
            **(byte **)(&stack0x00000098 + lVar15) = **(byte **)(&stack0x00000098 + lVar15) & 0xe7;
            **(byte **)(&stack0x00000098 + lVar15) = **(byte **)(&stack0x00000098 + lVar15) | 4;
          }
          *(undefined4 *)(&stack0x00000094 + lVar15) = 1;
          (&stack0xffffffffffffffe0)[lVar17 + lVar15] = 0;
          *(undefined8 *)((longlong)auStack_50 + lVar17 + lVar15 + 8) = 0x10592d;
          func_0x(&stack0x00000090 + lVar15,param_3,0,1);
          lVar27 = *(longlong *)(&stack0x00000110 + lVar15);
          *(undefined **)(&stack0x000001a0 + lVar15) = &stack0x00000090 + lVar15;
          puVar43 = &stack0xffffffffffffffc0 + lVar17 + lVar15;
          if (*(char *)(lVar27 + 2) < '\0') {
            puVar51 = (undefined2 *)((longlong)auStackX_10 + lVar17 + lVar15);
            uVar52 = 0xffff;
            *puVar51 = 0xffff;
            *(undefined8 *)((longlong)auStackX_18 + lVar17 + lVar15) = 0;
            *(undefined4 *)((longlong)&uStackX_14 + lVar17 + lVar15) = 0;
            *(undefined8 *)(&stack0x0000002e + lVar17 + lVar15) = 0;
            *(undefined8 *)(&stack0x00000038 + lVar17 + lVar15) = 0;
            *(undefined8 *)((longlong)auStackX_18 + lVar17 + lVar15 + 8) = 0;
            *(undefined8 *)((longlong)auStack_88 + lVar17 + lVar15) = 0x105983;
            lVar55 = func_0x();
            lVar55 = -lVar55;
            puVar43 = auStack_100 + lVar55 + lVar17 + lVar15;
            *(undefined (*) [16])(auStack_70 + lVar55 + lVar17 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])((longlong)auStack_60 + lVar55 + lVar17 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])((longlong)auStack_50 + lVar55 + lVar17 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0xffffffffffffffc0 + lVar55 + lVar17 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0xffffffffffffffd0 + lVar55 + lVar17 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0xffffffffffffffe0 + lVar55 + lVar17 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0xfffffffffffffff0 + lVar55 + lVar17 + lVar15) = ZEXT816(0);
            *(undefined8 *)((longlong)auStackX_18 + lVar55 + lVar17 + lVar15 + -0x18) = 0;
            *(undefined2 *)((longlong)auStack_60 + lVar55 + lVar17 + lVar15) = uVar52;
            *(undefined8 *)((longlong)&uStack_58 + lVar55 + lVar17 + lVar15) = 0;
            *(undefined4 *)((longlong)&uStack_5c + lVar55 + lVar17 + lVar15) = 0;
            *(undefined8 *)((longlong)auStack_50 + lVar55 + lVar17 + lVar15 + 0xe) = 0;
            *(undefined8 *)(&stack0xffffffffffffffc8 + lVar55 + lVar17 + lVar15) = 0;
            *(undefined8 *)((longlong)auStack_50 + lVar55 + lVar17 + lVar15) = 0;
            *(undefined8 *)(&stack0xffffffffffffffd8 + lVar55 + lVar17 + lVar15) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff0 + lVar55 + lVar17 + lVar15) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff8 + lVar55 + lVar17 + lVar15) = 0;
            *(undefined2 *)((longlong)auStackX_18 + lVar55 + lVar17 + lVar15 + -0x16) = 0;
            *(longlong *)(&stack0x000001b0 + lVar15) =
                 (longlong)auStackX_10 + lVar55 + lVar17 + lVar15;
            *(undefined (**) [16])(&stack0x000001c0 + lVar15) =
                 (undefined (*) [16])(auStack_70 + lVar55 + lVar17 + lVar15);
            *(undefined2 **)(&stack0x000001a8 + lVar15) = puVar51;
            *(undefined4 *)(&stack0x000001b8 + lVar15) = 0x1f9e;
            *(undefined8 *)((longlong)&uStack_108 + lVar55 + lVar17 + lVar15) = 0x105a1b;
            func_0x(&stack0x000001a0 + lVar15,lVar27);
          }
          iVar13 = *(int *)(&stack0x00000054 + lVar15);
          uVar41 = 0x800000;
          lVar17 = *(longlong *)(&stack0x00000100 + lVar15);
          (&stack0x000000c8)[lVar15] = 1;
          goto code_r0x00105a41;
        }
      }
    }
    iVar13 = *(int *)(&stack0x00000054 + lVar15);
code_r0x00105a35:
    lVar17 = *(longlong *)(&stack0x00000100 + lVar15);
  }
code_r0x00105a41:
  cVar11 = *pcVar2;
  uVar30 = uVar41 | 0x100;
  if (puVar24[8] != 0) {
    uVar30 = uVar41;
  }
  uVar41 = uVar30 | 0x20;
  if ((*(byte *)puVar24 & 0x40) == 0) {
    uVar41 = uVar30;
  }
  uVar30 = uVar41 | 0x1000000;
  if ((*(byte *)(puVar24 + 2) & 2) != 0) {
    uVar30 = uVar41;
  }
  uVar41 = uVar30 | 0x80000;
  sVar54 = *(short *)(*(longlong *)(&stack0x00000110 + lVar15) + 0x3a);
  *(short *)(&stack0x00000054 + lVar15) = sVar54;
  if (((&stack0x000000c8)[lVar15] == '\0') &&
     (((iVar13 == 0 || ((uVar30 & 0x100008) != 0)) || (cVar11 != '\0')))) {
    bVar57 = false;
  }
  else {
    bVar57 = true;
    if (ppbVar26 != (byte **)0x0) {
      *(undefined8 *)(puVar43 + 0x20) = 0;
      *(undefined8 *)(puVar43 + -8) = 0x105acf;
      (*pcRam0000000001558390)(1,0x1a88f00,0x1a5e8d0,0x3fe);
      ppbVar26 = *(byte ***)(&stack0x00000168 + lVar15);
    }
    uVar41 = uVar30 | 0x88000;
  }
  uVar30 = uVar41 | 0x400000;
  if (*(longlong *)(&stack0x000000f0 + lVar15) == 0) {
    uVar30 = uVar41;
  }
  if (cVar11 == '\0') {
    plVar22 = *(longlong **)(&stack0x000000d0 + lVar15);
    pbVar49 = *(byte **)(&stack0x000000e0 + lVar15);
    uVar21 = *(undefined8 *)(&stack0x00000198 + lVar15);
    ppbVar50 = (byte **)(&stack0x000001a0 + lVar15);
    if (!bVar57) {
      ppbVar50 = ppbVar45;
    }
    *(byte ***)(puVar43 + 0x60) = ppbVar50;
    bVar29 = *pbVar49;
    uVar14 = *(undefined4 *)(&stack0x00000128 + lVar15);
    *(undefined4 *)(puVar43 + 0x58) = 1;
    *(byte ***)(puVar43 + 0x50) = ppbVar26;
    *(uint *)(puVar43 + 0x48) = uVar30;
    uVar3 = *(undefined4 *)(&stack0x00000120 + lVar15);
    *(undefined8 *)(puVar43 + 0x40) = uVar21;
    lVar17 = plVar22[3];
    *(longlong **)(puVar43 + 0x38) = param_3;
    *(uint *)(puVar43 + 0x30) = bVar29 >> 2 & 1;
    *(undefined4 *)(puVar43 + 0x28) = uVar14;
    *(undefined4 *)(puVar43 + 0x20) = 1;
    *(undefined8 *)(puVar43 + -8) = 0x1071c4;
    func_0x(plVar22,lVar17,plVar22 + 4,uVar3);
    goto code_r0x001070f5;
  }
  pbVar49 = *(byte **)(&stack0x000000e0 + lVar15);
  uVar41 = *(uint *)(&stack0x00000094 + lVar15);
  uVar40 = uVar30 | 0x20000;
  if (*(int *)(*(longlong *)(lVar17 + 8) + 0x100) != 2) {
    uVar40 = uVar30;
  }
  uVar30 = uVar40 | 0x40000;
  if ((*pbVar49 & 4) == 0) {
    uVar30 = uVar40;
  }
  uVar40 = uVar30 | 0x200000;
  if (*(int *)(pbVar49 + 0x20) == 0) {
    uVar40 = uVar30;
  }
  if (*(short *)(&stack0x00000090 + lVar15) == 0) {
    if (uVar41 == 0) {
      uVar41 = *(uint *)(&stack0x000000a0 + lVar15);
      uVar53 = (ulonglong)uVar41;
      *(undefined2 *)(&stack0x00000092 + lVar15) = 0;
      *(uint *)(&stack0x000000a4 + lVar15) = uVar41;
      if ((**(byte **)(&stack0x00000098 + lVar15) & 0x10) != 0) {
        uVar41 = uVar41 + 2 + (*(ushort *)(*(byte **)(&stack0x00000098 + lVar15) + uVar53) + 7 >> 3)
        ;
        uVar53 = (ulonglong)uVar41;
        *(uint *)(&stack0x000000a4 + lVar15) = uVar41;
      }
      if ((**(byte **)(&stack0x00000098 + lVar15) & 0x20) == 0) {
        *(int *)(&stack0x00000094 + lVar15) = (int)uVar53;
        *(undefined2 *)(&stack0x000000ac + lVar15) = 0;
        *(int *)(&stack0x000000a8 + lVar15) = (int)uVar53;
      }
      else {
        puVar48 = (ushort *)(*(byte **)(&stack0x00000098 + lVar15) + uVar53);
        uVar34 = *puVar48;
        *(ushort *)(&stack0x000000ac + lVar15) = uVar34;
        if (uVar34 == 0) {
          if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                         (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
              *(undefined8 *)(puVar43 + -8) = 0x105c14;
              (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x105c3a;
              (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
            }
          }
          uVar21 = *(undefined8 *)(&stack0x00000098 + lVar15);
          *(undefined8 *)(puVar43 + -8) = 0x105c48;
          func_0x(uVar21,3);
          uVar34 = *(ushort *)(&stack0x000000ac + lVar15);
        }
        uVar30 = *(int *)(&stack0x000000a4 + lVar15) + 2 + (uint)uVar34 * 2;
        *(uint *)(&stack0x000000a8 + lVar15) = uVar30;
        if (0x1f9e < uVar30) {
          if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
              (lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                         (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
              *(undefined8 *)(puVar43 + -8) = 0x105ce6;
              (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x105d0c;
              (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
            }
          }
          uVar21 = *(undefined8 *)(&stack0x00000098 + lVar15);
          *(undefined8 *)(puVar43 + -8) = 0x105d1a;
          func_0x(uVar21,4);
          uVar34 = *(ushort *)(&stack0x000000ac + lVar15);
          uVar30 = *(uint *)(&stack0x000000a8 + lVar15);
        }
        uVar38 = (ulonglong)uVar34;
        uVar41 = puVar48[uVar38] & 0x7fff;
        *(uint *)(&stack0x00000094 + lVar15) = uVar41;
        if (uVar41 < uVar30) {
          if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                         (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
              *(undefined8 *)(puVar43 + -8) = 0x105db9;
              (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x105ddf;
              (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
            }
          }
          uVar21 = *(undefined8 *)(&stack0x00000098 + lVar15);
          *(undefined8 *)(puVar43 + -8) = 0x105ded;
          func_0x(uVar21,4);
          uVar38 = (ulonglong)*(ushort *)(&stack0x000000ac + lVar15);
          uVar30 = *(uint *)(&stack0x000000a8 + lVar15);
          uVar41 = *(uint *)(&stack0x00000094 + lVar15);
        }
        uVar53 = (ulonglong)uVar41;
        do {
          if (-1 < (short)puVar48[(ulonglong)((int)uVar38 - 1) + 1]) break;
          uVar36 = uVar30;
          if ((((int)uVar38 != 1) &&
              (uVar36 = *(ushort *)
                         ((ulonglong)*(uint *)(&stack0x000000a4 + lVar15) +
                          *(longlong *)(&stack0x00000098 + lVar15) + -2 + uVar38 * 2) & 0x7fff,
              uVar36 < uVar30)) ||
             ((*(ushort *)
                ((ulonglong)*(uint *)(&stack0x000000a4 + lVar15) +
                 *(longlong *)(&stack0x00000098 + lVar15) + uVar38 * 2) & 0x7fff) < uVar36)) {
            uVar21 = *(undefined8 *)(&stack0x00000098 + lVar15);
            *(undefined8 *)(puVar43 + -8) = 0x105e52;
            func_0x(uVar21,7);
            uVar38 = (ulonglong)*(ushort *)(&stack0x000000ac + lVar15);
            uVar30 = *(uint *)(&stack0x000000a8 + lVar15);
            uVar53 = (ulonglong)*(uint *)(&stack0x00000094 + lVar15);
          }
          uVar41 = (uint)uVar53;
          if ((uVar36 < uVar30) || (uVar41 < uVar36)) goto code_r0x00106131;
          if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000098 + lVar15)) == 5) {
            *(ushort *)(&stack0x00000092 + lVar15) = *(ushort *)(&stack0x00000092 + lVar15) | 2;
            uVar34 = *(ushort *)(&stack0x000000bc + lVar15);
            *(short *)(&stack0x000000ac + lVar15) = (short)uVar38 + -1;
            *(short *)(&stack0x000000ba + lVar15) = (short)uVar36;
            lVar17 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(&stack0x00000098 + lVar15);
            uVar35 = *(ushort *)(lVar17 + 2);
            if ((uVar35 & 0x4000) == 0) {
              uVar34 = uVar34 & 0xc7ff;
            }
            else {
              uVar34 = uVar34 ^ (uVar34 ^ uVar35) & 0x3800;
            }
            *(ushort *)(&stack0x000000bc + lVar15) = uVar34;
            *(ushort *)(&stack0x000000bc + lVar15) =
                 (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
            break;
          }
          if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000098 + lVar15)) < 0x400)
          break;
          *(ushort *)(&stack0x00000092 + lVar15) = *(ushort *)(&stack0x00000092 + lVar15) | 1;
          uVar34 = (short)uVar38 - 1;
          uVar38 = (ulonglong)uVar34;
          *(ushort *)(&stack0x000000ac + lVar15) = uVar34;
        } while (uVar34 != 0);
      }
      if ((**(byte **)(&stack0x00000098 + lVar15) & 0x40) == 0) {
        *(undefined4 *)(&stack0x000000b6 + lVar15) = 0;
      }
      else {
        *(int *)(&stack0x000000b6 + lVar15) = (int)uVar53;
        *(int *)(&stack0x00000094 + lVar15) = (int)uVar53 + 0xe;
        *(undefined8 *)(puVar43 + -8) = 0x105f3a;
        puVar25 = (ulonglong *)func_0x(&stack0x00000092 + lVar15);
        uVar53 = *puVar25;
        uVar35 = (ushort)(uVar53 >> 0x30);
        uVar34 = uVar35;
        if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
          uVar34 = uVar35 & 0xdfff;
          if ((uVar53 & 0x4000000000000000) != 0) {
            uVar34 = uVar35 | 0x2000;
          }
        }
        uVar41 = uVar44;
        if (uVar34 == 0xfffc) {
          uVar41 = (uint)((uVar53 >> 0x20 & 0xffff) >> 5);
        }
        uVar53 = (ulonglong)(*(int *)(&stack0x00000094 + lVar15) + uVar41);
        *(uint *)(&stack0x00000094 + lVar15) = *(int *)(&stack0x00000094 + lVar15) + uVar41;
      }
      uVar41 = (uint)uVar53;
      if ((*(ulonglong *)(&stack0x000000ae + lVar15) != 0) &&
         (*(ulonglong *)(&stack0x000000ae + lVar15) <
          uVar53 + *(longlong *)(&stack0x00000098 + lVar15))) {
        if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
           (((lVar17 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                        (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
             (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
            (*(char *)(lVar17 + 0x499) != '\0')))) {
          if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
            *(undefined8 *)(puVar43 + -8) = 0x106037;
            (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar43 + 0x20) = 0;
            *(undefined8 *)(puVar43 + -8) = 0x10605d;
            (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
          }
        }
        uVar21 = *(undefined8 *)(&stack0x00000098 + lVar15);
        *(undefined8 *)(puVar43 + -8) = 0x10606b;
        func_0x(uVar21,0x12);
        uVar41 = *(uint *)(&stack0x00000094 + lVar15);
      }
      if (0x3f3b < uVar41 - 1) {
        if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
           ((lVar17 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                       (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
            ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
             (*(char *)(lVar17 + 0x499) != '\0')))))) {
          if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
            *(undefined8 *)(puVar43 + -8) = 0x1060f9;
            (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(puVar43 + 0x20) = 0;
            *(undefined8 *)(puVar43 + -8) = 0x10611f;
            (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
          }
        }
        uVar21 = *(undefined8 *)(&stack0x00000098 + lVar15);
        *(undefined8 *)(puVar43 + -8) = 0x10612d;
        func_0x(uVar21,5);
        uVar41 = *(uint *)(&stack0x00000094 + lVar15);
      }
    }
code_r0x00106131:
    if (uVar41 < 9) {
      bVar29 = **(byte **)(&stack0x00000098 + lVar15) & 0xe;
joined_r0x0010616a:
      if ((bVar29 == 0) || (bVar29 == 0xc)) {
        uVar41 = 9;
      }
    }
  }
  else {
    if (uVar41 == 0) {
      *(undefined8 *)(puVar43 + -8) = 0x106156;
      func_0x(&stack0x00000092 + lVar15);
      uVar41 = *(uint *)(&stack0x00000094 + lVar15);
    }
    if (uVar41 < 9) {
      bVar29 = **(byte **)(&stack0x00000098 + lVar15) & 0x1c;
      goto joined_r0x0010616a;
    }
  }
  if (*(char *)((*(ulonglong *)(&stack0x00000338 + lVar15) & 0xffffffffffffe000) + 2) < '\0') {
    uVar14 = *(undefined4 *)(&stack0x00000420 + lVar15);
    uVar21 = *(undefined8 *)(&stack0x00000418 + lVar15);
    *(short *)(&stack0x000003e0 + lVar15) = *(short *)(&stack0x00000330 + lVar15);
    if (*(short *)(&stack0x00000330 + lVar15) == 0) {
      uVar30 = *(uint *)(&stack0x00000334 + lVar15);
      if (uVar30 == 0) {
        uVar30 = *(uint *)(&stack0x00000340 + lVar15);
        uVar53 = (ulonglong)uVar30;
        *(undefined2 *)(&stack0x00000332 + lVar15) = 0;
        *(uint *)(&stack0x00000344 + lVar15) = uVar30;
        if ((**(byte **)(&stack0x00000338 + lVar15) & 0x10) != 0) {
          uVar30 = uVar30 + 2 +
                   (*(ushort *)(*(byte **)(&stack0x00000338 + lVar15) + uVar53) + 7 >> 3);
          uVar53 = (ulonglong)uVar30;
          *(uint *)(&stack0x00000344 + lVar15) = uVar30;
        }
        if ((**(byte **)(&stack0x00000338 + lVar15) & 0x20) == 0) {
          *(int *)(&stack0x00000334 + lVar15) = (int)uVar53;
          *(undefined2 *)(&stack0x0000034c + lVar15) = 0;
          *(int *)(&stack0x00000348 + lVar15) = (int)uVar53;
          uVar38 = uVar53;
        }
        else {
          psVar16 = (short *)(*(byte **)(&stack0x00000338 + lVar15) + uVar53);
          sVar54 = *psVar16;
          *(short *)(&stack0x0000034c + lVar15) = sVar54;
          if (sVar54 == 0) {
            if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                (lVar17 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                           (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
               ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x1062a0;
                (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x1062c6;
                (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
              }
            }
            uVar7 = *(undefined8 *)(&stack0x00000338 + lVar15);
            *(undefined8 *)(puVar43 + -8) = 0x1062d7;
            func_0x(uVar7,3);
          }
          uVar30 = *(int *)(&stack0x00000344 + lVar15) +
                   (*(ushort *)(&stack0x0000034c + lVar15) + 1) * 2;
          *(uint *)(&stack0x00000348 + lVar15) = uVar30;
          if (0x1f9e < uVar30) {
            if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
               ((lVar17 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                           (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
                ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                 (*(char *)(lVar17 + 0x499) != '\0')))))) {
              if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10637b;
                (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x1063a1;
                (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
              }
            }
            uVar7 = *(undefined8 *)(&stack0x00000338 + lVar15);
            *(undefined8 *)(puVar43 + -8) = 0x1063b2;
            func_0x(uVar7,4);
            uVar30 = *(uint *)(&stack0x00000348 + lVar15);
          }
          uVar38 = (ulonglong)uVar30;
          uVar36 = (ushort)psVar16[*(ushort *)(&stack0x0000034c + lVar15)] & 0x7fff;
          uVar53 = (ulonglong)uVar36;
          *(uint *)(&stack0x00000334 + lVar15) = uVar36;
          if (uVar36 < uVar30) {
            if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
                (lVar17 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                           (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
               ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x106454;
                (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10647a;
                (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
              }
            }
            uVar7 = *(undefined8 *)(&stack0x00000338 + lVar15);
            *(undefined8 *)(puVar43 + -8) = 0x10648b;
            func_0x(uVar7,4);
            uVar38 = (ulonglong)*(uint *)(&stack0x00000348 + lVar15);
            uVar53 = (ulonglong)*(uint *)(&stack0x00000334 + lVar15);
          }
          do {
            uVar34 = *(ushort *)(&stack0x0000034c + lVar15);
            if (-1 < psVar16[(ulonglong)(uVar34 - 1) + 1]) break;
            uVar36 = (uint)uVar38;
            if (((uVar34 != 1) &&
                (uVar36 = *(ushort *)
                           ((ulonglong)*(uint *)(&stack0x00000344 + lVar15) +
                            *(longlong *)(&stack0x00000338 + lVar15) + -2 + (ulonglong)uVar34 * 2) &
                          0x7fff, uVar36 < (uint)uVar38)) ||
               ((*(ushort *)
                  ((ulonglong)*(uint *)(&stack0x00000344 + lVar15) +
                   *(longlong *)(&stack0x00000338 + lVar15) + (ulonglong)uVar34 * 2) & 0x7fff) <
                uVar36)) {
              uVar7 = *(undefined8 *)(&stack0x00000338 + lVar15);
              *(undefined8 *)(puVar43 + -8) = 0x1064ff;
              func_0x(uVar7,7);
              uVar38 = (ulonglong)*(uint *)(&stack0x00000348 + lVar15);
              uVar53 = (ulonglong)*(uint *)(&stack0x00000334 + lVar15);
            }
            uVar30 = (uint)uVar53;
            uVar39 = (uint)uVar38;
            if ((uVar36 < uVar39) || (uVar30 < uVar36)) goto code_r0x00106843;
            if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000338 + lVar15)) == 5) {
              *(ushort *)(&stack0x00000332 + lVar15) = *(ushort *)(&stack0x00000332 + lVar15) | 2;
              *(short *)(&stack0x0000034c + lVar15) = *(short *)(&stack0x0000034c + lVar15) + -1;
              uVar34 = *(ushort *)(&stack0x0000035c + lVar15);
              *(short *)(&stack0x0000035a + lVar15) = (short)uVar36;
              lVar17 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(&stack0x00000338 + lVar15);
              uVar35 = *(ushort *)(lVar17 + 2);
              if ((uVar35 & 0x4000) == 0) {
                uVar34 = uVar34 & 0xc7ff;
              }
              else {
                uVar34 = uVar34 ^ (uVar35 ^ uVar34) & 0x3800;
              }
              *(ushort *)(&stack0x0000035c + lVar15) = uVar34;
              *(ushort *)(&stack0x0000035c + lVar15) =
                   (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
              goto code_r0x001065f7;
            }
            if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x00000338 + lVar15)) < 0x400)
            break;
            *(ushort *)(&stack0x00000332 + lVar15) = *(ushort *)(&stack0x00000332 + lVar15) | 1;
            psVar47 = (short *)(&stack0x0000034c + lVar15);
            *psVar47 = *psVar47 + -1;
          } while (*psVar47 != 0);
        }
        uVar39 = (uint)uVar38;
code_r0x001065f7:
        if ((**(byte **)(&stack0x00000338 + lVar15) & 0x40) == 0) {
          *(undefined4 *)(&stack0x00000356 + lVar15) = 0;
        }
        else {
          *(int *)(&stack0x00000356 + lVar15) = (int)uVar53;
          *(int *)(&stack0x00000334 + lVar15) = (int)uVar53 + 0xe;
          *(undefined8 *)(puVar43 + -8) = 0x106622;
          puVar25 = (ulonglong *)func_0x(&stack0x00000332 + lVar15);
          uVar53 = *puVar25;
          uVar35 = (ushort)(uVar53 >> 0x30);
          uVar34 = uVar35;
          if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
            uVar34 = uVar35 & 0xdfff;
            if ((uVar53 & 0x4000000000000000) != 0) {
              uVar34 = uVar35 | 0x2000;
            }
          }
          uVar30 = uVar44;
          if (uVar34 == 0xfffc) {
            uVar30 = (uint)((uVar53 >> 0x20 & 0xffff) >> 5);
          }
          uVar53 = (ulonglong)(*(int *)(&stack0x00000334 + lVar15) + uVar30);
          uVar39 = *(uint *)(&stack0x00000348 + lVar15);
          *(uint *)(&stack0x00000334 + lVar15) = *(int *)(&stack0x00000334 + lVar15) + uVar30;
        }
        uVar30 = (uint)uVar53;
        if ((*(ulonglong *)(&stack0x0000034e + lVar15) != 0) &&
           (*(ulonglong *)(&stack0x0000034e + lVar15) <
            uVar53 + *(longlong *)(&stack0x00000338 + lVar15))) {
          if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
             (((lVar17 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                          (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
               (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
              *(undefined8 *)(puVar43 + -8) = 0x106732;
              (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x106758;
              (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
            }
          }
          uVar7 = *(undefined8 *)(&stack0x00000338 + lVar15);
          *(undefined8 *)(puVar43 + -8) = 0x106769;
          func_0x(uVar7,0x12);
          uVar39 = *(uint *)(&stack0x00000348 + lVar15);
          uVar30 = *(uint *)(&stack0x00000334 + lVar15);
        }
        if (0x3f3b < uVar30 - 1) {
          if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                         (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
              *(undefined8 *)(puVar43 + -8) = 0x1067ff;
              (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x106825;
              (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
            }
          }
          uVar7 = *(undefined8 *)(&stack0x00000338 + lVar15);
          *(undefined8 *)(puVar43 + -8) = 0x106836;
          func_0x(uVar7,5);
          uVar30 = *(uint *)(&stack0x00000334 + lVar15);
          goto code_r0x0010683c;
        }
      }
      else {
code_r0x0010683c:
        uVar39 = *(uint *)(&stack0x00000348 + lVar15);
      }
code_r0x00106843:
      uVar36 = uVar30;
      if ((uVar30 < 9) &&
         (((**(byte **)(&stack0x00000338 + lVar15) & 0xe) == 0 ||
          ((**(byte **)(&stack0x00000338 + lVar15) & 0xe) == 0xc)))) {
        uVar36 = 9;
      }
      *(undefined4 *)(&stack0x000003f0 + lVar15) = *(undefined4 *)(&stack0x00000340 + lVar15);
      *(undefined2 *)(&stack0x000003e2 + lVar15) = *(undefined2 *)(&stack0x00000332 + lVar15);
      *(undefined2 *)(&stack0x000003fc + lVar15) = *(undefined2 *)(&stack0x0000034c + lVar15);
      *(undefined4 *)(&stack0x000003f4 + lVar15) = *(undefined4 *)(&stack0x00000344 + lVar15);
      *(uint *)(&stack0x000003e4 + lVar15) = uVar30;
      *(uint *)(&stack0x000003f8 + lVar15) = uVar39;
      uVar7 = *(undefined8 *)(&stack0x00000338 + lVar15);
      *(undefined4 *)(&stack0x00000406 + lVar15) = *(undefined4 *)(&stack0x00000356 + lVar15);
      *(undefined8 *)(puVar43 + -8) = 0x1068c7;
      func_0x(uVar21,uVar14,uVar7,uVar36);
      *(undefined8 *)(&stack0x000003e8 + lVar15) = uVar21;
      *(undefined8 *)(puVar43 + -8) = 0x1068da;
      iVar13 = func_0x(&stack0x000003e2 + lVar15);
      if (iVar13 != 0) {
        lVar17 = *(longlong *)(&stack0x000003e8 + lVar15);
        puVar48 = (ushort *)((ulonglong)*(uint *)(&stack0x000003f4 + lVar15) + lVar17);
        uVar30 = *puVar48 - 1;
        if (((&stack0x000003e2)[lVar15] & 1) == 0) {
          uVar30 = (uint)*puVar48;
        }
        if (uVar30 == 1) {
          uVar36 = *(uint *)(&stack0x000003f8 + lVar15);
code_r0x00106925:
          if ((puVar48[(int)uVar30] & 0x7fff) < uVar36) goto code_r0x00106932;
        }
        else {
          uVar36 = puVar48[(longlong)(int)uVar30 + -1] & 0x7fff;
          if (*(uint *)(&stack0x000003f8 + lVar15) <= uVar36) goto code_r0x00106925;
code_r0x00106932:
          *(undefined8 *)(puVar43 + -8) = 0x10693f;
          func_0x(lVar17,7);
          lVar17 = *(longlong *)(&stack0x000003e8 + lVar15);
        }
        uVar34 = *(ushort *)(&stack0x0000040c + lVar15);
        *(short *)(&stack0x0000040a + lVar15) = (short)uVar36;
        lVar17 = (ulonglong)(uVar36 & 0xffff) + lVar17;
        uVar35 = *(ushort *)(lVar17 + 2);
        if ((uVar35 >> 0xe & 1) == 0) {
          uVar34 = uVar34 & 0xc7ff;
        }
        else {
          uVar34 = uVar34 ^ (uVar35 ^ uVar34) & 0x3800;
        }
        *(ushort *)(&stack0x0000040c + lVar15) = uVar34;
        *(ushort *)(&stack0x0000040c + lVar15) = (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34
        ;
      }
    }
    else if ((*(longlong **)(&stack0x00000340 + lVar15) == (longlong *)0x0) ||
            (**(longlong **)(&stack0x00000340 + lVar15) == 0)) {
      *(undefined8 *)(puVar43 + -8) = 0x1069e6;
      func_0x(&stack0x000003e2 + lVar15,uVar21,uVar14,&stack0x00000332 + lVar15);
      ppbVar26 = *(byte ***)(&stack0x00000340 + lVar15);
      if (*(short *)(&stack0x00000330 + lVar15) == 0) {
        ppbVar26 = ppbVar45;
      }
      *(byte ***)(&stack0x000003f0 + lVar15) = ppbVar26;
    }
    else {
      *(undefined8 *)(puVar43 + -8) = 0x1069cb;
      func_0x(&stack0x000003e0 + lVar15,uVar21,uVar14,&stack0x00000330 + lVar15);
    }
    pbVar49 = *(byte **)(&stack0x000000e0 + lVar15);
    puVar46 = &stack0x000003e0;
  }
  else {
    puVar46 = &stack0x00000330;
  }
  psVar16 = (short *)(puVar46 + lVar15);
  puVar48 = (ushort *)(psVar16 + 1);
  if (*psVar16 == 0) {
    if (*(int *)(psVar16 + 2) == 0) {
      *puVar48 = 0;
      uVar30 = *(uint *)(psVar16 + 8);
      uVar53 = (ulonglong)uVar30;
      *(uint *)(psVar16 + 10) = uVar30;
      pbVar32 = *(byte **)(psVar16 + 4);
      bVar29 = *pbVar32;
      if ((bVar29 & 0x10) != 0) {
        uVar30 = uVar30 + (*(ushort *)(pbVar32 + uVar53) + 7 >> 3) + 2;
        uVar53 = (ulonglong)uVar30;
        *(uint *)(psVar16 + 10) = uVar30;
        bVar29 = *pbVar32;
      }
      if ((bVar29 & 0x20) == 0) {
        *(int *)(psVar16 + 2) = (int)uVar53;
        psVar16[0xe] = 0;
        *(uint *)(psVar16 + 0xc) = uVar30;
      }
      else {
        puVar56 = (ushort *)(pbVar32 + uVar53);
        uVar34 = *puVar56;
        psVar16[0xe] = uVar34;
        if (uVar34 == 0) {
          if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
              (lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                         (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
              *(undefined8 *)(puVar43 + -8) = 0x106aed;
              (*pcRam0000000001558398)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x106b13;
              (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x80f);
            }
          }
          uVar21 = *(undefined8 *)(psVar16 + 4);
          *(undefined8 *)(puVar43 + -8) = 0x106b21;
          func_0x(uVar21,3);
          uVar34 = psVar16[0xe];
          uVar30 = *(uint *)(psVar16 + 10);
        }
        uVar30 = uVar30 + (uVar34 + 1) * 2;
        *(uint *)(psVar16 + 0xc) = uVar30;
        if (0x1f9e < uVar30) {
          if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                         (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
              *(undefined8 *)(puVar43 + -8) = 0x106bba;
              (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x106be0;
              (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x816);
            }
          }
          uVar21 = *(undefined8 *)(psVar16 + 4);
          *(undefined8 *)(puVar43 + -8) = 0x106bee;
          func_0x(uVar21,4);
          uVar30 = *(uint *)(psVar16 + 0xc);
        }
        uVar53 = (ulonglong)(ushort)psVar16[0xe];
        uVar34 = puVar56[uVar53];
        *(uint *)(psVar16 + 2) = uVar34 & 0x7fff;
        if ((uVar34 & 0x7fff) < uVar30) {
          if ((((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
              (lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                         (ulonglong)*puRam0000000001558400), lVar17 != 0)) &&
             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
              *(undefined8 *)(puVar43 + -8) = 0x106c85;
              (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x106cab;
              (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x81d);
            }
          }
          uVar21 = *(undefined8 *)(psVar16 + 4);
          *(undefined8 *)(puVar43 + -8) = 0x106cb9;
          func_0x(uVar21,4);
          uVar53 = (ulonglong)(ushort)psVar16[0xe];
        }
        while ((short)puVar56[(ulonglong)((int)uVar53 - 1) + 1] < 0) {
          lVar17 = *(longlong *)(psVar16 + 4);
          lVar27 = (ulonglong)*(uint *)(psVar16 + 10) + lVar17;
          if ((int)uVar53 == 1) {
            uVar30 = *(uint *)(psVar16 + 0xc);
            uVar36 = uVar30;
code_r0x00106cfe:
            if ((*(ushort *)(lVar27 + uVar53 * 2) & 0x7fff) < uVar30) goto code_r0x00106d0c;
          }
          else {
            uVar36 = *(uint *)(psVar16 + 0xc);
            uVar30 = *(ushort *)(lVar27 + -2 + uVar53 * 2) & 0x7fff;
            if (uVar36 <= uVar30) goto code_r0x00106cfe;
code_r0x00106d0c:
            *(undefined8 *)(puVar43 + -8) = 0x106d19;
            func_0x(lVar17,7);
            uVar36 = *(uint *)(psVar16 + 0xc);
          }
          if ((uVar30 < uVar36) || (*(uint *)(psVar16 + 2) < uVar30)) goto code_r0x00106fd7;
          if (*(ushort *)((ulonglong)uVar30 + *(longlong *)(psVar16 + 4)) == 5) {
            *puVar48 = *puVar48 | 2;
            psVar16[0xe] = psVar16[0xe] + -1;
            psVar16[0x15] = (short)uVar30;
            lVar17 = (ulonglong)(uVar30 & 0xffff) + *(longlong *)(psVar16 + 4);
            uVar34 = psVar16[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar17 + 2) >> 0xe & 1) != 0) {
              uVar34 = *(ushort *)(lVar17 + 2) & 0x3800 | psVar16[0x16] & 0xc7ffU;
            }
            psVar16[0x16] = uVar34;
            psVar16[0x16] = (uVar34 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar34;
            break;
          }
          if (*(ushort *)((ulonglong)uVar30 + *(longlong *)(psVar16 + 4)) < 0x400) break;
          *puVar48 = *puVar48 | 1;
          uVar34 = psVar16[0xe] - 1;
          psVar16[0xe] = uVar34;
          if (uVar34 == 0) break;
          uVar53 = (ulonglong)uVar34;
        }
        pbVar32 = *(byte **)(psVar16 + 4);
      }
      if ((*pbVar32 & 0x40) == 0) {
        *(undefined4 *)(psVar16 + 0x13) = 0;
      }
      else {
        *(int *)(psVar16 + 0x13) = *(int *)(psVar16 + 2);
        *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + 0xe;
        *(undefined8 *)(puVar43 + -8) = 0x106de9;
        puVar25 = (ulonglong *)func_0x(puVar48);
        uVar35 = (ushort)(*puVar25 >> 0x30);
        uVar34 = uVar35;
        if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
          uVar34 = uVar35 & 0xdfff;
          if ((uVar35 >> 0xe & 1) != 0) {
            uVar34 = uVar35 | 0x2000;
          }
        }
        if (uVar34 == 0xfffc) {
          uVar44 = (uint)((*puVar25 >> 0x20 & 0xffff) >> 5);
        }
        *(uint *)(psVar16 + 2) = *(int *)(psVar16 + 2) + uVar44;
      }
      uVar44 = *(uint *)(psVar16 + 2);
      if ((*(ulonglong *)(psVar16 + 0xf) != 0) &&
         (*(ulonglong *)(psVar16 + 0xf) < (ulonglong)uVar44 + *(longlong *)(psVar16 + 4))) {
        if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
           (((lVar17 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                        (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
             (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
            (*(char *)(lVar17 + 0x499) != '\0')))) {
          if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
            *(undefined8 *)(puVar43 + -8) = 0x106ee3;
            (*pcRam0000000001558398)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar43 + 0x20) = 0;
            *(undefined8 *)(puVar43 + -8) = 0x106f09;
            (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x877);
          }
        }
        uVar21 = *(undefined8 *)(psVar16 + 4);
        *(undefined8 *)(puVar43 + -8) = 0x106f17;
        func_0x(uVar21,0x12);
        uVar44 = *(uint *)(psVar16 + 2);
      }
      if (0x3f3b < uVar44 - 1) {
        if (((cRam0000000001fe9b6b != '\0') || ((bRam0000000001ffa470 & 1) != 0)) &&
           ((lVar17 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000015583f8 * 8) + 8 +
                       (ulonglong)*puRam0000000001558400), lVar17 != 0 &&
            ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
             (*(char *)(lVar17 + 0x499) != '\0')))))) {
          if ((cRam0000000001fe9a5b == '\0') && ((bRam0000000001ffa470 & 2) == 0)) {
            *(undefined8 *)(puVar43 + -8) = 0x106fa3;
            (*pcRam0000000001558398)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(puVar43 + 0x20) = 0;
            *(undefined8 *)(puVar43 + -8) = 0x106fc9;
            (*pcRam0000000001558390)(1,0x18da598,0x19fa268,0x87c);
          }
        }
        uVar21 = *(undefined8 *)(psVar16 + 4);
        *(undefined8 *)(puVar43 + -8) = 0x106fd7;
        func_0x(uVar21,5);
      }
    }
code_r0x00106fd7:
    if ((8 < *(uint *)(psVar16 + 2)) ||
       (((**(byte **)(psVar16 + 4) & 0xe) != 0 && ((**(byte **)(psVar16 + 4) & 0xe) != 0xc)))) {
      *(uint *)(&stack0x0000010c + lVar15) = *(uint *)(psVar16 + 2);
    }
  }
  else {
    uVar44 = *(uint *)(psVar16 + 2);
    if (uVar44 == 0) {
      *(undefined8 *)(puVar43 + -8) = 0x107007;
      func_0x(puVar48);
      uVar44 = *(uint *)(psVar16 + 2);
    }
    if ((uVar44 < 9) &&
       (((**(byte **)(psVar16 + 4) & 0x1c) == 0 || ((**(byte **)(psVar16 + 4) & 0x1c) == 0xc)))) {
      *(undefined4 *)(&stack0x0000010c + lVar15) = 9;
    }
    else {
      *(uint *)(&stack0x0000010c + lVar15) = uVar44;
    }
  }
  bVar29 = *pbVar49;
  plVar22 = *(longlong **)(&stack0x000000d0 + lVar15);
  uVar21 = *(undefined8 *)(&stack0x00000198 + lVar15);
  param_3 = *(longlong **)(&stack0x00000118 + lVar15);
  uVar14 = *(undefined4 *)(&stack0x00000120 + lVar15);
  *(undefined8 *)(puVar43 + 0x88) = 0;
  *(undefined **)(puVar43 + 0x80) = &stack0x000001a0 + lVar15;
  *(undefined4 *)(puVar43 + 0x78) = 1;
  *(undefined4 *)(puVar43 + 0x70) = 0;
  *(undefined8 *)(puVar43 + 0x68) = 0;
  *(uint *)(puVar43 + 0x60) = uVar40;
  *(undefined8 *)(puVar43 + 0x58) = uVar21;
  lVar17 = plVar22[3];
  *(longlong **)(puVar43 + 0x50) = param_3;
  *(uint *)(puVar43 + 0x48) = bVar29 >> 2 & 1;
  *(undefined4 *)(puVar43 + 0x40) = *(undefined4 *)(&stack0x00000128 + lVar15);
  *(undefined8 *)(puVar43 + 0x38) = *(undefined8 *)(&stack0x00000098 + lVar15);
  uVar3 = *(undefined4 *)(&stack0x0000010c + lVar15);
  *(uint *)(puVar43 + 0x30) = uVar41;
  *(undefined4 *)(puVar43 + 0x28) = uVar3;
  *(undefined4 *)(puVar43 + 0x20) = 0;
  *(undefined8 *)(puVar43 + -8) = 0x1070cb;
  iVar13 = func_0x(plVar22,lVar17,plVar22 + 4,uVar14);
  if (iVar13 != 0) {
    *(undefined8 *)(puVar43 + 0x20) = 0;
    *(undefined8 *)(puVar43 + -8) = 0x1070f0;
    (*pcRam0000000001558390)(1,0x1a88ee0,0x1a5e8d0,0x437);
  }
  sVar54 = *(short *)(&stack0x00000054 + lVar15);
code_r0x001070f5:
  if (*(short *)(*(longlong *)(&stack0x00000110 + lVar15) + 0x3a) == 1) {
    if (((byte)*(undefined2 *)(*plVar22 + 0x62) >> 2 & 1) == 0) {
      lVar17 = *plVar22;
      sVar54 = *(short *)(lVar17 + 0x2c);
      *(undefined8 *)(puVar43 + -8) = 0x107134;
      func_0x(lVar17,(sVar54 != 2) + '\x02',1);
      LOCK();
      puVar6 = (uint *)(*(longlong *)(param_3[6] + 0x6b0) + 0x1540);
      *puVar6 = *puVar6 & 0xfffffff7;
      UNLOCK();
    }
  }
  else if (((sVar54 != 0) && (*(short *)(*(longlong *)(&stack0x00000110 + lVar15) + 0x3a) == 0)) &&
          (*(char *)(plVar22 + 5) == '\0')) {
    lVar17 = *plVar22;
    sVar54 = *(short *)(lVar17 + 0x2c);
    *(undefined8 *)(puVar43 + -8) = 0x1071f1;
    func_0x(lVar17,(sVar54 != 2) + '\x02',0);
  }
  uVar53 = *(ulonglong *)(&stack0x000023e0 + lVar15);
  *(undefined8 *)(puVar43 + -8) = 0x107200;
  func_0x(uVar53 ^ (ulonglong)pcVar2);
  return;
}

