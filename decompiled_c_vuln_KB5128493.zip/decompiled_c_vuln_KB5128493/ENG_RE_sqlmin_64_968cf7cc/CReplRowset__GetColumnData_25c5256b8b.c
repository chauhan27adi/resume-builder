
longlong FUN_(longlong *param_1,longlong param_2,undefined8 *param_3,undefined4 *param_4)

{
  uint uVar1;
  uint uVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined4 auStackX_8 [2];
  
  auStackX_8[0] = 0;
  if ((((*param_1 != 0) && (param_2 != 0)) && (param_3 != (undefined8 *)0x0)) &&
     (param_4 != (undefined4 *)0x0)) {
    *param_3 = 0;
    *param_4 = 0;
    uVar2 = func_0x(param_1,param_2,auStackX_8);
    uVar4 = (ulonglong)uVar2;
    if (uVar4 != *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + param_1[0xc])) {
      uVar2 = 1;
      uVar1 = 1;
      if (*(uint *)(param_1 + 0xd) != 0) {
        do {
          uVar2 = uVar1;
          if (uVar4 == *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + param_1[0xc])) break;
          uVar2 = uVar2 + 1;
          uVar1 = uVar2;
        } while (uVar2 <= *(uint *)(param_1 + 0xd));
      }
    }
    if (uVar2 <= *(uint *)(param_1 + 0xd)) {
      lVar3 = (ulonglong)(uVar2 - 1) * 0x58;
      *param_3 = *(undefined8 *)(*(longlong *)(param_1[0xc] + 0x10 + lVar3) + *param_1);
      *param_4 = *(undefined4 *)(*(longlong *)(param_1[0xc] + 0x18 + lVar3) + *param_1);
      return *(longlong *)(lVar3 + 8 + param_1[0xc]) + *param_1;
    }
  }
  return 0;
}

