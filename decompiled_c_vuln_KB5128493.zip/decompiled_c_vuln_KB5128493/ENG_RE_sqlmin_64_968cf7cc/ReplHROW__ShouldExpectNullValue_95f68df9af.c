
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_(short *param_1,uint *param_2,byte *param_3)

{
  ushort *puVar1;
  uint uVar2;
  byte *pbVar3;
  longlong *plVar4;
  bool bVar5;
  byte bVar6;
  ushort uVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  ulonglong *puVar11;
  uint *puVar12;
  uint *puVar13;
  uint uVar14;
  uint uVar15;
  ushort uVar16;
  uint uVar17;
  ulonglong uVar18;
  uint *puVar19;
  short sVar20;
  longlong lVar21;
  int iVar22;
  ushort *puVar23;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [2];
  uint auStackX_18 [4];
  
  puVar19 = (uint *)0x0;
  bVar5 = false;
  iVar9 = 0;
  auStackX_8[0] = 0;
  if ((*(short *)(param_3 + 0x10) == -1) ||
     (iVar22 = iVar9,
     *(char *)((ulonglong)*(byte *)((ulonglong)*param_3 + 0x17b5270) + 0x216a8e8) != '\0')) {
    iVar22 = 1;
  }
  iVar8 = func_0x(param_1);
  uVar17 = (uint)*(ushort *)(param_3 + 0x10);
  if ((*(ushort *)(param_3 + 0x10) == 0xffff) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*param_3 + 0x17b5270) + 0x216a8e8) != '\0')) {
    uVar17 = 0x1fa4;
  }
  puVar1 = (ushort *)(param_1 + 1);
  if (*param_1 != 0) {
    auStackX_18[0] = 0;
    puVar13 = (uint *)func_0x(puVar1,param_2);
    puVar12 = puVar13;
    if ((((*param_1 != 0) && (plVar4 = *(longlong **)(param_1 + 8), plVar4 != (longlong *)0x0)) &&
        (*plVar4 != 0)) &&
       ((((*(byte *)((longlong)param_2 + 6) & 8) == 0 && ((auStackX_18[0] & 1) == 0)) &&
        ((puVar12 = puVar19, puVar13 != (uint *)0x0 && (puVar13 != (uint *)0x17b4dd4)))))) {
      puVar12 = (uint *)func_0x(plVar4,param_2,puVar13,auStackX_8[0],0,0,auStackX_8,
                                        auStackX_18[0]);
    }
    goto LAB_;
  }
  uVar15 = *param_2;
  if ((uVar15 & 0xc0000000) == 0x80000000) {
    iVar9 = func_0x(puVar1);
    puVar12 = (uint *)0x0;
    if (iVar9 != 0) {
      puVar12 = (uint *)func_0x(param_1 + 0x15,param_2,auStackX_8,auStackX_18);
    }
    goto LAB_;
  }
  pbVar3 = *(byte **)(param_1 + 4);
  bVar6 = *pbVar3;
  if ((bVar6 & 0x10) == 0) {
    if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
      uVar7 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
      goto LAB_;
    }
  }
  else {
    uVar2 = *(uint *)(param_1 + 8);
    if ((int)uVar15 < (int)uVar2) {
      if ((uint)*(ushort *)(pbVar3 + uVar2) < (uint)*(ushort *)(param_2 + 1)) {
        bVar5 = false;
        uVar7 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
      }
      else {
        uVar14 = *(ushort *)(param_2 + 1) - 1;
        bVar5 = true;
        uVar7 = (ushort)(pbVar3[(ulonglong)uVar2 + (ulonglong)(uVar14 >> 3) + 2] >>
                        ((byte)uVar14 & 7));
      }
    }
    else {
      bVar5 = false;
      uVar7 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
    }
LAB_:
    puVar12 = puVar19;
    if ((uVar7 & 1) != 0) goto LAB_;
    if ((!bVar5) && ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
      puVar12 = (uint *)(*(longlong *)(param_2 + 2) + 4);
      goto LAB_;
    }
  }
  if (-1 < (int)uVar15) {
    uVar7 = *(ushort *)((longlong)param_2 + 6);
    if ((uVar7 & 8) != 0) {
      puVar12 = (uint *)0x17b4dd4;
      if ((pbVar3[(int)uVar15] & (byte)(1 << ((byte)uVar7 & 7))) == 0) {
        puVar12 = (uint *)0x17b53f8;
      }
      goto LAB_;
    }
    if ((uVar7 & 0x10) != 0) {
      if ((bVar6 & 0x10) == 0) {
        if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar12 = *(uint **)(param_2 + 2) + 1;
          if ((uVar17 != 0) && (**(uint **)(param_2 + 2) != uVar17)) {
            (*_DAT_)(1,0x1bde108,0x1bdcb08,0x381,0);
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uVar15) ||
              (*(ushort *)(pbVar3 + *(uint *)(param_1 + 8)) < *(ushort *)(param_2 + 1)))
      goto LAB_;
    }
    puVar12 = (uint *)(pbVar3 + (int)uVar15);
    goto LAB_;
  }
  if (*(int *)(param_1 + 2) == 0) {
    uVar17 = *(uint *)(param_1 + 8);
    uVar18 = (ulonglong)uVar17;
    *(uint *)(param_1 + 10) = uVar17;
    *puVar1 = 0;
    bVar6 = *pbVar3;
    if ((bVar6 & 0x10) != 0) {
      uVar17 = uVar17 + 2 + (*(ushort *)(pbVar3 + uVar18) + 7 >> 3);
      uVar18 = (ulonglong)uVar17;
      *(uint *)(param_1 + 10) = uVar17;
      bVar6 = *pbVar3;
    }
    if ((bVar6 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar18;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar18;
    }
    else {
      puVar23 = (ushort *)(pbVar3 + uVar18);
      uVar7 = *puVar23;
      param_1[0xe] = uVar7;
      if (uVar7 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar21 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar21 != 0)) &&
           ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
            (*(char *)(lVar21 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x1a30398,0x1b50068,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar18 = (ulonglong)*(uint *)(param_1 + 10);
        uVar7 = param_1[0xe];
      }
      uVar17 = (int)uVar18 + (uVar7 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar17;
      if (0x1f9e < uVar17) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar21 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar21 != 0 &&
            ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
             (*(char *)(lVar21 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1a30398,0x1b50068,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar7 = param_1[0xe];
        uVar17 = *(uint *)(param_1 + 0xc);
      }
      uVar18 = (ulonglong)uVar7;
      uVar7 = puVar23[uVar18];
      *(uint *)(param_1 + 2) = uVar7 & 0x7fff;
      if ((uVar7 & 0x7fff) < uVar17) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar21 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar21 != 0)) &&
           ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
            (*(char *)(lVar21 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1a30398,0x1b50068,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar18 = (ulonglong)(ushort)param_1[0xe];
      }
      if ((short)puVar23[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
        lVar21 = *(longlong *)(param_1 + 4);
        do {
          if ((int)uVar18 == 1) {
            uVar17 = *(uint *)(param_1 + 0xc);
            uVar15 = uVar17;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar21 + uVar18 * 2) & 0x7fff) <
                uVar17) goto LAB_;
          }
          else {
            uVar15 = *(uint *)(param_1 + 0xc);
            uVar17 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar21 + -2 + uVar18 * 2) &
                     0x7fff;
            if (uVar15 <= uVar17) goto LAB_;
LAB_:
            func_0x(lVar21,7);
            uVar15 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar17 < uVar15) || (*(uint *)(param_1 + 2) < uVar17)) goto LAB_;
          lVar21 = *(longlong *)(param_1 + 4);
          if (*(ushort *)(lVar21 + (ulonglong)uVar17) == 5) {
            *puVar1 = *puVar1 | 2;
            param_1[0xe] = param_1[0xe] + -1;
            param_1[0x15] = (short)uVar17;
            lVar21 = (ulonglong)(uVar17 & 0xffff) + *(longlong *)(param_1 + 4);
            uVar7 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar21 + 2) & 0x4000) != 0) {
              uVar7 = *(ushort *)(lVar21 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar7;
            param_1[0x16] = (uVar7 ^ *(ushort *)(lVar21 + 2)) & 0x7ff ^ uVar7;
            uVar18 = (ulonglong)*(uint *)(param_1 + 2);
            goto LAB_;
          }
          if (*(ushort *)(lVar21 + (ulonglong)uVar17) < 0x400) break;
          *puVar1 = *puVar1 | 1;
          uVar7 = param_1[0xe] - 1;
          param_1[0xe] = uVar7;
          if ((uVar7 == 0) ||
             (uVar18 = (ulonglong)uVar7, -1 < (short)puVar23[(ulonglong)(uVar7 - 1) + 1])) break;
        } while( true );
      }
      uVar18 = (ulonglong)*(uint *)(param_1 + 2);
    }
LAB_:
    if ((**(byte **)(param_1 + 4) & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = (int)uVar18;
      *(int *)(param_1 + 2) = (int)uVar18 + 0xe;
      puVar11 = (ulonglong *)func_0x(puVar1);
      uVar18 = *puVar11;
      uVar16 = (ushort)(uVar18 >> 0x30);
      uVar7 = uVar16;
      if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
        uVar7 = uVar16 & 0xdfff;
        if ((uVar18 & 0x4000000000000000) != 0) {
          uVar7 = uVar16 | 0x2000;
        }
      }
      if (uVar7 == 0xfffc) {
        iVar9 = (int)((uVar18 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar9;
      uVar18 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar9 = (int)uVar18;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar18 + *(longlong *)(param_1 + 4))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar21 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar21 != 0 &&
           (lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0)) &&
          (*(char *)(lVar21 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x1a30398,0x1b50068,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar9 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar9 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar21 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar21 != 0 &&
          ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
           (*(char *)(lVar21 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x1a30398,0x1b50068,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar20 = -*(short *)param_2;
  if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
    bVar6 = **(byte **)(param_1 + 4);
    if ((bVar6 & 0x10) == 0) {
      if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
        puVar12 = (uint *)(*(longlong *)(param_2 + 2) + 4);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)*param_2) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
             *(ushort *)(param_2 + 1))) goto LAB_;
  }
  puVar12 = *(uint **)(param_1 + 4);
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar20) goto LAB_;
  if (sVar20 == 1) {
    uVar17 = *(uint *)(param_1 + 0xc);
LAB_:
    if ((*(ushort *)((longlong)puVar12 + (longlong)sVar20 * 2 + (ulonglong)*(uint *)(param_1 + 10))
        & 0x7fff) < uVar17) goto LAB_;
  }
  else {
    uVar17 = *(ushort *)
              ((longlong)puVar12 + (longlong)sVar20 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2))
             & 0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar17) goto LAB_;
LAB_:
    func_0x(puVar12,7);
    puVar12 = *(uint **)(param_1 + 4);
  }
  puVar12 = (uint *)((longlong)puVar12 + (ulonglong)uVar17);
LAB_:
  if (((iVar22 == 0) && (iVar8 == 0)) && (puVar12 == (uint *)0x0)) {
    uVar10 = 1;
  }
  else {
    uVar10 = 0;
  }
  return uVar10;
}

