
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,undefined4 param_3,undefined8 *param_4)

{
  byte **ppbVar1;
  int *piVar2;
  char *pcVar3;
  byte bVar4;
  undefined2 uVar5;
  undefined2 uVar6;
  undefined2 uVar7;
  int iVar8;
  undefined8 *puVar9;
  code *pcVar10;
  undefined8 uVar11;
  byte *pbVar12;
  byte *pbVar13;
  undefined8 uVar14;
  longlong lVar15;
  int iVar16;
  char cVar17;
  short sVar18;
  ushort uVar19;
  int iVar20;
  uint uVar21;
  longlong lVar22;
  byte **ppbVar23;
  byte **ppbVar24;
  undefined8 *puVar25;
  longlong lVar26;
  ulonglong uVar27;
  short *psVar28;
  undefined8 uVar29;
  undefined8 uVar30;
  uint uVar31;
  longlong lVar32;
  int *piVar33;
  longlong *plVar34;
  ulonglong uVar35;
  undefined4 *puVar36;
  longlong lVar37;
  undefined *puVar38;
  byte **ppbVar39;
  byte **ppbVar40;
  byte *pbVar41;
  undefined2 uVar42;
  char cVar43;
  uint uVar44;
  byte **ppbVar45;
  byte **ppbVar46;
  longlong unaff_GS_OFFSET;
  longlong lStackX_10;
  undefined4 uStackX_18;
  char acStackX_20 [4];
  short asStackX_24 [2];
  undefined8 uStack_48;
  
  uStack_48 = 0x100020;
  lStackX_10 = param_2;
  uStackX_18 = param_3;
  lVar22 = func_0x();
  lVar22 = -lVar22;
  puVar38 = &stack0xffffffffffffffc0 + lVar22;
  pcVar3 = acStackX_20 + lVar22;
  *(undefined8 *)(&stack0x000002d8 + lVar22) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00001040 + lVar22) = _DAT_ ^ (ulonglong)pcVar3;
  *(longlong *)(&stack0x00000050 + lVar22) = param_1;
  *(longlong *)(&stack0x000000d8 + lVar22) = param_1;
  *(longlong *)(&stack0x000001f0 + lVar22) = param_1;
  *(undefined8 **)(&stack0x00000240 + lVar22) = param_4;
  puVar25 = *(undefined8 **)(&stack0x000010c0 + lVar22);
  *(undefined8 **)(&stack0x00000248 + lVar22) = puVar25;
  puVar9 = *(undefined8 **)(&stack0x000010c8 + lVar22);
  *(undefined8 **)(&stack0x00000108 + lVar22) = puVar9;
  plVar34 = *(longlong **)(&stack0x000010d0 + lVar22);
  *(longlong **)(&stack0x00000040 + lVar22) = plVar34;
  *(longlong *)(&stack0x000000f8 + lVar22) = *(longlong *)(param_1 + 0x108) + 0x90;
  ppbVar45 = (byte **)0x0;
  *(undefined4 *)(&stack0x0000011c + lVar22) = 0;
  *(undefined4 *)(&stack0x00000070 + lVar22) = 1;
  *(undefined4 *)(&stack0x00000074 + lVar22) = 0;
  *(undefined8 *)(&stack0x00000088 + lVar22) = 0;
  *(undefined8 *)(&stack0x00000090 + lVar22) = 0;
  *(undefined8 *)(&stack0x00000150 + lVar22) = 0;
  *(undefined8 *)(&stack0x000001c0 + lVar22) = 0;
  *(undefined4 *)(&stack0x00000034 + lVar22) = 0;
  *(undefined2 *)(&stack0x00000038 + lVar22) = 0;
  *(undefined4 *)(&stack0x00000064 + lVar22) = 0;
  *(undefined2 *)(&stack0x00000068 + lVar22) = 0;
  *(undefined2 *)(acStackX_20 + lVar22 + 4) = 0;
  acStackX_20[lVar22 + 1] = '\0';
  *(undefined8 *)(&stack0x00000080 + lVar22) = 0;
  *(undefined8 *)(&stack0x00000078 + lVar22) = 0;
  *(int *)(&stack0x00000218 + lVar22) = _DAT_;
  *(int *)(&stack0x0000021c + lVar22) = iRam0000000001ef940c;
  *(int *)(&stack0x00000220 + lVar22) = _DAT_;
  *(int *)(&stack0x00000224 + lVar22) = iRam0000000001ef9414;
  *(undefined8 *)(&stack0x000001b8 + lVar22) = 0;
  *(undefined8 *)(&stack0x00000148 + lVar22) = 0;
  *(undefined8 *)(&stack0x00000110 + lVar22) = 0;
  *(undefined4 *)(&stack0x00000290 + lVar22) = _DAT_;
  *(uint *)(&stack0x000002a0 + lVar22) = *(uint *)(&stack0x000002a0 + lVar22) & 0xfffffffc;
  lVar32 = *(longlong *)(param_1 + 0x10);
  *(longlong *)(&stack0x00000058 + lVar22) = lVar32;
  *(undefined8 *)(&stack0x00000048 + lVar22) = *(undefined8 *)(param_1 + 0x18);
  *(undefined8 *)(&stack0x00000028 + lVar22) =
       *(undefined8 *)(*(longlong *)(param_1 + 0x2e0) + 0x10);
  *param_4 = 0;
  *puVar25 = 0;
  *puVar9 = 0;
  *(undefined4 *)(&stack0x00000060 + lVar22) =
       *(undefined4 *)(**(longlong **)(*(longlong *)(lVar32 + 8) + 0x160) + 0x1c);
  *(undefined8 *)(&stack0x00000100 + lVar22) = *(undefined8 *)(lVar32 + 0x20);
  ppbVar39 = ppbVar45;
  if (*plVar34 == 0) {
    *(undefined4 *)(&stack0x000000e8 + lVar22) = 0x3134;
    (&stack0xffffffffffffffe0)[lVar22] = 5;
    uVar30 = *(undefined8 *)(param_1 + 0x1f0);
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100364;
    ppbVar24 = (byte **)(*_DAT_)(0xa80,uVar30,0x156f938,0x3134);
    *(byte ***)(&stack0x000001c8 + lVar22) = ppbVar24;
    ppbVar23 = ppbVar45;
    if (ppbVar24 != (byte **)0x0) {
      *(undefined2 *)((longlong)ppbVar24 + 10) = 0;
      *(undefined2 *)((longlong)ppbVar24 + 0x1e) = 0;
      ppbVar23 = ppbVar24;
    }
    *(byte ***)(param_1 + 0x418) = ppbVar23;
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100396;
    func_0x(ppbVar23,0,0xa80);
    lVar37 = *(longlong *)(param_1 + 0x418);
    uVar30 = *(undefined8 *)(param_1 + 0x1f0);
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1003b0;
    func_0x(uVar30,*(undefined4 *)(&stack0x00000060 + lVar22),lVar37 + 0x10);
    *(undefined4 *)(&stack0x000000e8 + lVar22) = 0;
    *(undefined2 *)(&stack0x000000ec + lVar22) = 0;
    lVar37 = *(longlong *)(param_1 + 0x418);
    *(undefined4 *)(lVar37 + 4) = 0;
    *(undefined2 *)(lVar37 + 8) = 0;
    *(undefined2 *)(lVar37 + 10) = 0;
    uVar30 = *(undefined8 *)(*(longlong *)(param_1 + 0x418) + 0x10);
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1003e7;
    func_0x(lVar32,uVar30);
    lVar32 = *(longlong *)(*(longlong *)(param_1 + 0x418) + 0x10);
    *(undefined4 *)(lVar32 + 0x10) = 1;
    *(undefined4 *)(lVar32 + 0x14) = 0;
    *(undefined8 *)(*(longlong *)(param_1 + 0x418) + 0xa78) = 0;
LAB_:
    lVar32 = *(longlong *)(&stack0x00000028 + lVar22);
  }
  else {
    *(undefined4 *)(&stack0x000000e8 + lVar22) = 0x30eb;
    (&stack0xffffffffffffffe0)[lVar22] = 5;
    uVar30 = *(undefined8 *)(param_1 + 0x1f0);
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1001ac;
    ppbVar23 = (byte **)(*_DAT_)(0x58,uVar30,0x156f938,0x30eb);
    *(byte ***)(&stack0x000001c8 + lVar22) = ppbVar23;
    if (ppbVar23 != (byte **)0x0) {
      *(undefined4 *)ppbVar23 = 0;
      *(undefined2 *)((longlong)ppbVar23 + 4) = 0;
      *(undefined4 *)(ppbVar23 + 1) = 0;
      *(undefined4 *)((longlong)ppbVar23 + 0xc) = 0;
      *(undefined2 *)(ppbVar23 + 2) = 0;
      *(undefined4 *)((longlong)ppbVar23 + 0x14) = 0;
      *(undefined4 *)(ppbVar23 + 3) = 0xffffffff;
      *(undefined4 *)((longlong)ppbVar23 + 0x1c) = 0;
      *(undefined2 *)(ppbVar23 + 4) = 0;
      ppbVar39 = ppbVar23;
    }
    *(byte ***)(&stack0x000001b8 + lVar22) = ppbVar39;
    lVar32 = *(longlong *)(param_1 + 0x418);
    *(undefined4 *)(ppbVar39 + 9) = *(undefined4 *)(lVar32 + 0x18);
    *(undefined2 *)((longlong)ppbVar39 + 0x4c) = *(undefined2 *)(lVar32 + 0x1c);
    *(undefined4 *)(ppbVar39 + 10) = 1;
    *(undefined4 *)(&stack0x00000194 + lVar22) = 0;
    *(undefined2 *)(&stack0x00000198 + lVar22) = 0;
    piVar33 = (int *)(*(longlong *)(param_1 + 0x418) + 4);
    if ((*piVar33 == 0) && (*(short *)(*(longlong *)(param_1 + 0x418) + 8) == 0)) goto LAB_;
    lVar32 = *(longlong *)(&stack0x00000028 + lVar22);
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10024c;
    iVar20 = func_0x(lVar32,piVar33,3,&stack0x00000228 + lVar22);
    if (iVar20 != 0) {
      *(undefined8 *)(&stack0x00000120 + lVar22) = 0;
      ppbVar23 = (byte **)(param_1 + 0x340);
      ppbVar24 = *(byte ***)(param_1 + 0x348);
      if (*(byte ***)(param_1 + 0x348) == ppbVar23) {
        ppbVar24 = ppbVar45;
      }
      while (ppbVar24 != (byte **)0x0) {
        pbVar41 = ppbVar24[2];
        if (*(int *)(pbVar41 + 8) == 0) {
          if ((*(byte *)(ppbVar24 + 3) & 1) != 0) {
            *(undefined8 *)(pbVar41 + 0x10) = *(undefined8 *)(param_1 + 0x370);
            *(undefined4 *)(pbVar41 + 4) = 2;
            *(uint *)(ppbVar24 + 3) = *(uint *)(ppbVar24 + 3) & 0xfffffffe;
            pbVar41 = ppbVar24[2];
          }
          *(int *)(pbVar41 + 8) = *(int *)(pbVar41 + 8) + 1;
          pbVar41 = ppbVar24[2];
          goto LAB_;
        }
        ppbVar1 = ppbVar24 + 1;
        ppbVar24 = (byte **)*ppbVar1;
        if ((byte **)*ppbVar1 == ppbVar23) {
          ppbVar24 = ppbVar45;
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1002df;
      pbVar41 = (byte *)func_0x(ppbVar23);
LAB_:
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1002ee;
      func_0x(&stack0x00000120 + lVar22,pbVar41);
      uVar30 = *(undefined8 *)(&stack0x00000120 + lVar22);
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100304;
      func_0x(uVar30,&stack0x00000228 + lVar22);
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10031c;
      func_0x(param_1,uVar30,*(undefined8 *)(&stack0x000000f8 + lVar22),2);
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100324;
      func_0x(uVar30);
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100331;
      func_0x(&stack0x00000120 + lVar22);
      goto LAB_;
    }
    *(undefined4 *)(&stack0x0000018c + lVar22) = 0;
    *(undefined2 *)(&stack0x00000190 + lVar22) = 0;
    lVar37 = *(longlong *)(param_1 + 0x418);
    *(undefined4 *)(lVar37 + 4) = 0;
    *(undefined2 *)(lVar37 + 8) = 0;
    *(undefined2 *)(lVar37 + 10) = 0;
  }
  *(undefined8 *)(&stack0x000001c8 + lVar22) =
       *(undefined8 *)(*(longlong *)(param_1 + 0x418) + 0x10);
  **(undefined8 **)(&stack0x00000040 + lVar22) = 0;
  lVar37 = *(longlong *)(param_1 + 0x388);
  if (lVar37 == 0) {
    uVar30 = *(undefined8 *)(*(longlong *)(param_1 + 0x2e0) + 8);
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10044b;
    func_0x(uVar30,*(undefined4 *)(&stack0x00000060 + lVar22));
    lVar37 = *(longlong *)(*(longlong *)(&stack0x000001f0 + lVar22) + 0x388);
  }
  *(undefined4 *)(&stack0x00000258 + lVar22) = 0;
  *(undefined8 *)(&stack0x000002e0 + lVar22) = 0;
  if (*(int *)(lVar37 + 0x20) == 0) {
    lVar26 = *(longlong *)(lVar37 + 0x10);
  }
  else {
    lVar26 = *(longlong *)(lVar37 + 0x18);
    *(undefined8 *)(lVar37 + 0x18) = *(undefined8 *)(lVar37 + 0x10);
    *(longlong *)(lVar37 + 0x10) = lVar26;
    *(undefined4 *)(lVar37 + 0x20) = 0;
  }
  *(undefined4 *)(lVar26 + 0x10) = 0;
  *(undefined4 *)(lVar26 + 8) = 0;
  *(undefined4 *)(lVar26 + 0x14) = 0;
  *(undefined4 *)(lVar37 + 0x20) = 0;
  lVar37 = *(longlong *)(lVar37 + 0x18);
  *(undefined4 *)(lVar37 + 0x10) = 0;
  *(undefined4 *)(lVar37 + 8) = 0;
  *(undefined4 *)(lVar37 + 0x14) = 0;
  if (*(int *)(lVar26 + 8) == 0) {
    *(undefined4 *)(lVar26 + 0x10) = 1;
    *(undefined4 *)(lVar26 + 8) = 0;
    *(undefined4 *)(lVar26 + 0x14) = 0;
    if (*(int *)(lVar37 + 8) != 0) goto LAB_;
  }
  *(undefined4 *)(lVar37 + 0x10) = 2;
  *(undefined4 *)(lVar37 + 8) = 0;
  *(undefined4 *)(lVar37 + 0x14) = 0;
LAB_:
  uVar31 = 0;
  if ((*(int *)(&stack0x000010b0 + lVar22) == 0) ||
     ((longlong)(ulonglong)_DAT_ <= *(longlong *)(*(longlong *)(param_1 + 0x418) + 0xa78)))
  {
    uVar44 = 1;
    uVar21 = uVar31;
  }
  else {
    uVar44 = uVar31;
    uVar21 = 1;
  }
  *(uint *)(&stack0x000000e8 + lVar22) = uVar44;
  *(uint *)(&stack0x00000120 + lVar22) = uVar21;
  *(undefined **)((longlong)&lStackX_10 + lVar22) = &stack0x00000078 + lVar22;
  *(undefined **)(acStackX_20 + lVar22 + -0x20) = &stack0x00000290 + lVar22;
  *(uint *)(&stack0xfffffffffffffff8 + lVar22) = uVar21 ^ 1;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar22) = 0;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar22) = 7;
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar22) = 2;
  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10054a;
  func_0x(lVar32,2,0,0);
  plVar34 = *(longlong **)(lVar32 + 0x48);
  pcVar10 = *(code **)(*plVar34 + 0x30);
  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100557;
  (*pcVar10)(plVar34,ppbVar39);
  if (ppbVar39 != (byte **)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10056a;
    (*_DAT_)(ppbVar39,0x58);
    *(undefined8 *)(&stack0x000001b8 + lVar22) = 0;
  }
  ppbVar39 = (byte **)(param_1 + 0x340);
  ppbVar23 = *(byte ***)(param_1 + 0x348);
  if (*(byte ***)(param_1 + 0x348) == ppbVar39) {
    ppbVar23 = ppbVar45;
  }
  while (ppbVar23 != (byte **)0x0) {
    pbVar41 = ppbVar23[2];
    if (*(int *)(pbVar41 + 8) == 0) {
      if ((*(byte *)(ppbVar23 + 3) & 1) != 0) {
        *(undefined8 *)(pbVar41 + 0x10) = *(undefined8 *)(param_1 + 0x370);
        *(undefined4 *)(pbVar41 + 4) = 2;
        *(uint *)(ppbVar23 + 3) = *(uint *)(ppbVar23 + 3) & 0xfffffffe;
        pbVar41 = ppbVar23[2];
      }
      *(int *)(pbVar41 + 8) = *(int *)(pbVar41 + 8) + 1;
      pbVar41 = ppbVar23[2];
      goto LAB_;
    }
    ppbVar24 = ppbVar23 + 1;
    ppbVar23 = (byte **)*ppbVar24;
    if ((byte **)*ppbVar24 == ppbVar39) {
      ppbVar23 = ppbVar45;
    }
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1005d0;
  pbVar41 = (byte *)func_0x(ppbVar39);
LAB_:
  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1005dc;
  func_0x(&stack0x00000088 + lVar22,pbVar41);
  ppbVar39 = (byte **)(param_1 + 0x340);
  ppbVar23 = *(byte ***)(param_1 + 0x348);
  if (*(byte ***)(param_1 + 0x348) == ppbVar39) {
    ppbVar23 = ppbVar45;
  }
  do {
    if (ppbVar23 == (byte **)0x0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10063d;
      pbVar41 = (byte *)func_0x(ppbVar39);
LAB_:
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100649;
      func_0x(&stack0x00000090 + lVar22,pbVar41);
      lVar32 = *(longlong *)(&stack0x00000088 + lVar22);
      lVar37 = *(longlong *)(&stack0x00000090 + lVar22);
      ppbVar39 = ppbVar45;
      ppbVar23 = ppbVar45;
LAB_:
      do {
        plVar34 = *(longlong **)(&stack0x00000040 + lVar22);
LAB_:
        uVar30 = *(undefined8 *)(&stack0x00000048 + lVar22);
        uVar29 = *(undefined8 *)(&stack0x00000028 + lVar22);
        if ((*(longlong *)(&stack0x000010a8 + lVar22) <= (longlong)ppbVar39) && (*plVar34 != 0))
        goto LAB_;
        *(undefined4 *)(&stack0x00000118 + lVar22) = 0;
        *(undefined **)(puVar38 + 0x30) = &stack0x00000118 + lVar22;
        *(undefined **)(puVar38 + 0x28) = &stack0x00000218 + lVar22;
        uVar11 = *(undefined8 *)(&stack0x000000f8 + lVar22);
        *(undefined8 *)(puVar38 + -8) = 0x1006a4;
        func_0x(param_1,uVar30,uVar29,uVar11);
        if (*(int *)(&stack0x00000118 + lVar22) != 0) goto code_r0x001006ad;
        if ((*(longlong *)(&stack0x00000218 + lVar22) ==
             CONCAT44(iRam0000000001ef940c,_DAT_)) &&
           (*(longlong *)(&stack0x00000220 + lVar22) == CONCAT44(iRam0000000001ef9414,_DAT_)
           )) {
          *(undefined4 *)(&stack0x0000011c + lVar22) = 1;
          **(undefined8 **)(&stack0x00000040 + lVar22) = 0;
          *(undefined4 *)(&stack0x00000064 + lVar22) = 0;
          *(undefined2 *)(&stack0x00000068 + lVar22) = 0;
          lVar32 = *(longlong *)(param_1 + 0x418);
          if ((*(int *)(lVar32 + 4) != 0) || (*(short *)(lVar32 + 8) != 0)) {
            uVar30 = *(undefined8 *)(&stack0x00000028 + lVar22);
            uVar29 = *(undefined8 *)(&stack0x00000058 + lVar22);
            uVar11 = *(undefined8 *)(&stack0x00000048 + lVar22);
            *(undefined8 *)(puVar38 + -8) = 0x100726;
            func_0x(uVar11,uVar29,uVar30);
            lVar32 = *(longlong *)(*(longlong *)(&stack0x000001f0 + lVar22) + 0x418);
          }
          lVar37 = *(longlong *)(lVar32 + 0x10);
          if (lVar37 != 0) {
            *(undefined8 *)(puVar38 + -8) = 0x10074b;
            (*_DAT_)(lVar37,0x18);
            *(undefined8 *)(*(longlong *)(param_1 + 0x418) + 0x10) = 0;
            lVar32 = *(longlong *)(*(longlong *)(&stack0x000001f0 + lVar22) + 0x418);
          }
          *(undefined8 *)(puVar38 + -8) = 0x10076f;
          (*_DAT_)(lVar32,0xa80);
          *(undefined8 *)(param_1 + 0x418) = 0;
          goto LAB_;
        }
        *(undefined8 *)(puVar38 + -8) = 0x10078a;
        func_0x(lVar32,&stack0x00000218 + lVar22);
        ppbVar39 = (byte **)((longlong)ppbVar39 + 1);
        *(byte ***)(&stack0x000000e0 + lVar22) = ppbVar39;
        *(byte ***)(&stack0x00000130 + lVar22) = ppbVar39;
        uVar30 = *(undefined8 *)(&stack0x000000f8 + lVar22);
        *(undefined8 *)(puVar38 + -8) = 0x1007b0;
        iVar20 = func_0x(param_1,lVar32,uVar30,1);
        if (iVar20 != 0) {
          *(undefined8 *)(puVar38 + -8) = 0x1007bc;
          func_0x(lVar32);
          goto LAB_;
        }
        if (*(undefined8 **)(lVar32 + 0x30) == (undefined8 *)0x0) {
          *(undefined8 *)(&stack0x00000128 + lVar22) = 0;
          ppbVar24 = ppbVar45;
        }
        else {
          ppbVar24 = (byte **)**(undefined8 **)(lVar32 + 0x30);
          *(byte ***)(&stack0x00000128 + lVar22) = ppbVar24;
        }
        ppbVar1 = ppbVar24 + 4;
        iVar20 = *(int *)ppbVar1;
        *(int *)(&stack0x00000034 + lVar22) = iVar20;
        sVar18 = *(short *)((longlong)ppbVar24 + 0x24);
        *(short *)(&stack0x00000038 + lVar22) = sVar18;
        lVar26 = *(longlong *)(*(longlong *)(&stack0x00000050 + lVar22) + 0x418);
        iVar8 = *(int *)(lVar26 + 4);
        if ((iVar8 != iVar20) || (*(short *)(lVar26 + 8) != sVar18)) {
          if (*(char *)((longlong)ppbVar24 + 1) == '\x13') {
            *(undefined4 *)(&stack0x00000200 + lVar22) = 0;
            *(undefined2 *)(&stack0x00000204 + lVar22) = 0;
            if ((iVar8 != 0) || (*(short *)(lVar26 + 8) != 0)) {
              uVar30 = *(undefined8 *)(&stack0x00000028 + lVar22);
              uVar29 = *(undefined8 *)(&stack0x00000058 + lVar22);
              uVar11 = *(undefined8 *)(&stack0x00000048 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x100849;
              func_0x(uVar11,uVar29,uVar30);
              *(undefined4 *)(&stack0x00000070 + lVar22) = 1;
              lVar26 = *(longlong *)(*(longlong *)(&stack0x000001f0 + lVar22) + 0x418);
              iVar20 = *(int *)(&stack0x00000034 + lVar22);
            }
            *(int *)(lVar26 + 4) = iVar20;
            *(undefined2 *)(lVar26 + 8) = *(undefined2 *)(&stack0x00000038 + lVar22);
            *(undefined2 *)(lVar26 + 10) = 0;
          }
          else if (*(short *)((longlong)ppbVar24 + 0x16) == 0) {
            param_1 = *(longlong *)(&stack0x00000050 + lVar22);
            *(undefined8 *)(puVar38 + -8) = 0x100a51;
            iVar20 = func_0x(param_1,lVar32,0);
            if (iVar20 == 0) {
              **(longlong **)(&stack0x00000108 + lVar22) =
                   **(longlong **)(&stack0x00000108 + lVar22) + 1;
            }
            *(undefined8 *)(puVar38 + -8) = 0x100a67;
            func_0x(lVar32);
            plVar34 = *(longlong **)(&stack0x00000040 + lVar22);
            if (*plVar34 != 0) goto LAB_;
            *(undefined4 *)(&stack0x00000070 + lVar22) = 1;
            goto LAB_;
          }
        }
        *(undefined8 *)(puVar38 + -8) = 0x100879;
        func_0x(lVar32);
        sVar18 = *(short *)(&stack0x00000038 + lVar22);
        if (*(short *)(acStackX_20 + lVar22 + 4) == sVar18) {
          ppbVar46 = ppbVar24;
          if ((acStackX_20[lVar22 + 1] != '\0') && (DAT_ != '\0')) goto LAB_;
        }
        else {
          lVar32 = *(longlong *)(&stack0x00000050 + lVar22);
          lVar37 = *(longlong *)(lVar32 + 0x418);
          if (*(short *)(lVar37 + 8) != sVar18) {
            *(undefined4 *)(&stack0x000000e0 + lVar22) = 0;
            *(undefined2 *)(&stack0x000000e4 + lVar22) = 0;
            if ((*(int *)(lVar37 + 4) != 0) || (*(short *)(lVar37 + 8) != 0)) {
              uVar30 = *(undefined8 *)(&stack0x00000028 + lVar22);
              uVar29 = *(undefined8 *)(&stack0x00000058 + lVar22);
              uVar11 = *(undefined8 *)(&stack0x00000048 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x1008cb;
              func_0x(uVar11,uVar29,uVar30);
              sVar18 = *(short *)(&stack0x00000038 + lVar22);
            }
          }
          *(short *)(acStackX_20 + lVar22 + 4) = sVar18;
          acStackX_20[lVar22 + 1] = '\0';
          if (*(longlong *)
               (*(longlong *)
                 (*(longlong *)
                   ((ulonglong)*_DAT_ + 8 +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) + 0x60)
               + 0x4d8) != 0) {
            puVar25 = *(undefined8 **)
                       (*(longlong *)
                         (*(longlong *)
                           ((ulonglong)*_DAT_ + 8 +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
                         + 0x60) + 0x4d8);
            *(undefined8 **)(&stack0x000002e8 + lVar22) = puVar25;
            if (puVar25 != (undefined8 *)0x0) {
              *puVar25 = 0x1544ed8;
              *(undefined8 *)(puVar38 + -8) = 0x100948;
              (*_DAT_)(puVar25,0x30);
            }
            *(undefined8 *)
             (*(longlong *)
               (*(longlong *)
                 ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8) +
               0x60) + 0x4d8) = 0;
          }
          *(undefined4 *)(&stack0x0000018c + lVar22) = 0x3240;
          puVar38[0x20] = 5;
          uVar30 = *(undefined8 *)(lVar32 + 0x1f0);
          *(undefined8 *)(puVar38 + -8) = 0x1009a4;
          puVar25 = (undefined8 *)(*_DAT_)(0x30,uVar30,0x156f938,0x3240);
          *(undefined8 **)(&stack0x000002f0 + lVar22) = puVar25;
          if (puVar25 == (undefined8 *)0x0) {
            *(undefined8 *)(&stack0x000000f0 + lVar22) = 0;
          }
          else {
            uVar42 = *(undefined2 *)(acStackX_20 + lVar22 + 4);
            lVar37 = *(longlong *)(&stack0x00000100 + lVar22);
            uVar30 = *(undefined8 *)(lVar37 + 0x6a0);
            *(undefined8 *)(puVar38 + -8) = 0x1009d3;
            lVar26 = func_0x(uVar30,uVar42,0);
            uVar5 = *(undefined2 *)(lVar37 + 0x6b8);
            uVar6 = *(undefined2 *)(lVar26 + 0x84);
            uVar7 = *(undefined2 *)(lVar37 + 0x660);
            *puVar25 = 0x1544ed8;
            *(undefined4 *)(puVar25 + 1) = 0;
            *(undefined2 *)((longlong)puVar25 + 0xc) = 0;
            *(undefined4 *)(puVar25 + 2) = 0;
            *(undefined2 *)((longlong)puVar25 + 0x14) = 0;
            *(undefined2 *)(puVar25 + 3) = uVar5;
            *(undefined2 *)((longlong)puVar25 + 0x1a) = uVar7;
            *(undefined2 *)((longlong)puVar25 + 0x1c) = uVar6;
            *(undefined2 *)((longlong)puVar25 + 0x1e) = uVar42;
            *(undefined4 *)(puVar25 + 4) = 0;
            *(undefined2 *)((longlong)puVar25 + 0x24) = 0;
            *(undefined4 *)(puVar25 + 5) = 0;
            *(undefined *)((longlong)puVar25 + 0x2c) = 0;
            *(undefined8 **)(&stack0x000000f0 + lVar22) = puVar25;
          }
          *(undefined8 *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8) + 0x60) + 0x4d8) = *(undefined8 *)(&stack0x000000f0 + lVar22);
          lVar37 = *(longlong *)(&stack0x00000080 + lVar22);
          if (lVar37 != 0) {
            *(undefined8 *)(puVar38 + -8) = 0x100b73;
            func_0x(lVar37);
            *(undefined8 *)(puVar38 + -8) = 0x100b80;
            func_0x(lVar37,1);
            *(undefined8 *)(&stack0x00000080 + lVar22) = 0;
          }
          *(undefined4 *)(&stack0x00000194 + lVar22) = 0x3252;
          lVar37 = *(longlong *)(lVar32 + 0x2e0);
          puVar38[0x20] = 5;
          uVar30 = *(undefined8 *)(lVar37 + 8);
          *(undefined8 *)(puVar38 + -8) = 0x100bb6;
          ppbVar39 = (byte **)(*_DAT_)(0xb0,uVar30,0x156f938,0x3252);
          *(byte ***)(&stack0x000002f8 + lVar22) = ppbVar39;
          ppbVar23 = ppbVar45;
          if (ppbVar39 != (byte **)0x0) {
            pbVar41 = *(byte **)(lVar32 + 0x2f8);
            pbVar12 = *(byte **)(lVar32 + 0x1e0);
            pbVar13 = *(byte **)(lVar32 + 0x2e8);
            plVar34 = (longlong *)(lVar32 + 0x10);
            *(byte ***)(&stack0x00000300 + lVar22) = ppbVar39;
            *ppbVar39 = (byte *)0x155dce0;
            *ppbVar39 = (byte *)0x15551c0;
            *(undefined4 *)((longlong)ppbVar39 + 0x14) = 0;
            *(undefined2 *)(ppbVar39 + 3) = 0;
            *(undefined2 *)((longlong)ppbVar39 + 0x1a) = 0;
            *(undefined4 *)(ppbVar39 + 5) = 0xffffffff;
            *(undefined4 *)(ppbVar39 + 2) = 0;
            *(undefined4 *)(ppbVar39 + 7) = 0x80000000;
            *(undefined *)(ppbVar39 + 6) = 0;
            *(undefined4 *)(ppbVar39 + 9) = 0;
            ppbVar39[0xb] = pbVar13;
            ppbVar39[0xc] = pbVar12;
            *(undefined2 *)(ppbVar39 + 0xd) = 0;
            ppbVar39[0xf] = (byte *)0x0;
            ppbVar39[0x10] = (byte *)0x0;
            ppbVar39[0x12] = (byte *)plVar34;
            ppbVar39[0x13] = (byte *)0x0;
            ppbVar39[0x14] = (byte *)0x0;
            *(undefined4 *)(ppbVar39 + 0x15) = 0;
            lVar37 = *plVar34;
            *(undefined8 *)(puVar38 + -8) = 0x100c7a;
            func_0x(ppbVar39,lVar37);
            ppbVar39[0x11] = *(byte **)(*plVar34 + 0x20);
            ppbVar39[0xe] = pbVar41;
            ppbVar23 = ppbVar39;
          }
          *(byte ***)(&stack0x00000080 + lVar22) = ppbVar23;
          sVar18 = *(short *)(acStackX_20 + lVar22 + 4);
          *(short *)(ppbVar23 + 0xd) = sVar18;
          *(undefined4 *)(puVar38 + 0x20) = *(undefined4 *)(&stack0x000000e8 + lVar22);
          uVar30 = *(undefined8 *)(lVar32 + 0x388);
          *(undefined8 *)(puVar38 + -8) = 0x100cbd;
          func_0x(ppbVar23,uVar30);
          if (sVar18 == *(short *)(*(longlong *)(lVar32 + 0x418) + 0x1c)) {
            uVar30 = *(undefined8 *)(&stack0x000001c8 + lVar22);
            *(undefined8 *)(puVar38 + -8) = 0x100cdd;
            func_0x(ppbVar23,uVar30);
          }
          else {
            *(undefined8 *)(puVar38 + -8) = 0x100d5a;
            func_0x(ppbVar23,0);
            lVar32 = *(longlong *)(&stack0x000001c8 + lVar22);
            *(undefined4 *)(lVar32 + 0x10) = 1;
            *(undefined4 *)(lVar32 + 0x14) = 0;
          }
          lVar32 = *(longlong *)(&stack0x00000088 + lVar22);
          lVar37 = *(longlong *)(&stack0x00000090 + lVar22);
          ppbVar39 = *(byte ***)(&stack0x00000130 + lVar22);
          *(byte ***)(&stack0x000000e0 + lVar22) = ppbVar39;
          ppbVar46 = *(byte ***)(&stack0x00000128 + lVar22);
        }
        *(undefined8 *)(puVar38 + 0x30) = *(undefined8 *)(&stack0x00000078 + lVar22);
        *(undefined **)(puVar38 + 0x28) = &stack0x00000064 + lVar22;
        *(byte ***)(puVar38 + 0x20) = ppbVar23;
        uVar30 = *(undefined8 *)(&stack0x00000028 + lVar22);
        uVar29 = *(undefined8 *)(&stack0x00000058 + lVar22);
        uVar11 = *(undefined8 *)(&stack0x00000048 + lVar22);
        uVar14 = *(undefined8 *)(&stack0x00000050 + lVar22);
        *(undefined8 *)(puVar38 + -8) = 0x100d26;
        func_0x(uVar14,uVar11,uVar29,uVar30);
        *(undefined4 *)(&stack0x000000f0 + lVar22) = 0;
        *(undefined2 *)(&stack0x000000f4 + lVar22) = 0;
        if ((*(int *)(&stack0x00000064 + lVar22) != 0) ||
           (*(short *)(&stack0x00000068 + lVar22) != 0)) {
          if ((*(int *)(&stack0x00000064 + lVar22) != *(int *)(&stack0x00000034 + lVar22)) ||
             (uVar44 = uVar31,
             *(short *)(&stack0x00000068 + lVar22) != *(short *)(&stack0x00000038 + lVar22))) {
            uVar44 = 1;
          }
          if (uVar44 == 0) {
            if ((*(longlong *)(&stack0x000010a8 + lVar22) != 0) &&
               ((*(int *)(&stack0x00000070 + lVar22) != 0 ||
                (*(longlong *)(&stack0x000010a8 + lVar22) <= (longlong)ppbVar39)))) {
              *(undefined2 *)(&stack0x00000530 + lVar22) = 0xffff;
              *(undefined8 *)(&stack0x00000538 + lVar22) = 0;
              *(undefined4 *)(&stack0x00000534 + lVar22) = 0;
              *(undefined8 *)(&stack0x0000054e + lVar22) = 0;
              *(undefined8 *)(&stack0x00000558 + lVar22) = 0;
              *(undefined8 *)(&stack0x00000540 + lVar22) = 0;
              *(undefined4 *)(&stack0x00000564 + lVar22) = 0xffffffff;
              *(undefined8 *)(puVar38 + -8) = 0x102766;
              func_0x(lVar32,3);
              *(undefined4 *)(&stack0x00000564 + lVar22) = 0;
              if (*(char *)((longlong)ppbVar46 + 2) < '\0') {
                ppbVar39 = ppbVar46 + 0xc;
                if (*(short *)(&stack0x00000530 + lVar22) == 0) {
                  *(undefined8 *)(&stack0x000001e8 + lVar22) = 0;
LAB_:
                  *(undefined (*) [16])(&stack0x00000568 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000578 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000588 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000598 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000005a8 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000005b8 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000005c8 + lVar22) = ZEXT816(0);
                  *(undefined8 *)(&stack0x000005d8 + lVar22) = 0;
                  *(undefined (*) [16])(&stack0x00000568 + lVar22) = ZEXT816(0);
                  *(undefined2 *)(&stack0x00000578 + lVar22) = 0xffff;
                  *(undefined8 *)(&stack0x00000580 + lVar22) = 0;
                  *(undefined4 *)(&stack0x0000057c + lVar22) = 0;
                  *(undefined8 *)(&stack0x00000596 + lVar22) = 0;
                  *(undefined8 *)(&stack0x000005a0 + lVar22) = 0;
                  *(undefined8 *)(&stack0x00000588 + lVar22) = 0;
                  *(undefined8 *)(&stack0x000005b0 + lVar22) = 0;
                  *(undefined4 *)(&stack0x000005c8 + lVar22) = 0;
                  *(undefined4 *)(&stack0x000005cc + lVar22) = 0;
                  *(undefined2 *)(&stack0x000005d0 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000005d2 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000005da + lVar22) = 0;
                  ppbVar40 = (byte **)(&stack0x00000568 + lVar22);
                  *(byte ***)(&stack0x000001e8 + lVar22) = ppbVar40;
                }
                else {
                  ppbVar40 = *(byte ***)(&stack0x00000540 + lVar22);
                  *(byte ***)(&stack0x000001e8 + lVar22) = ppbVar40;
                  if (ppbVar40 == (byte **)0x0) goto LAB_;
                }
                (&stack0x0000003e)[lVar22] = 0;
                if (*(short *)((longlong)ppbVar46 + 0x24) == 0) {
LAB_:
                  *(byte **)(&stack0x00000158 + lVar22) = ppbVar46[5];
                  *(undefined2 *)(&stack0x00000160 + lVar22) = *(undefined2 *)(ppbVar46 + 6);
                }
                else {
                  cVar17 = *(char *)((longlong)ppbVar46 + 1);
                  if (cVar17 != '\v') {
                    if (cVar17 == '\b') {
LAB_:
                      if (*(int *)(ppbVar46 + 3) == 99) goto LAB_;
                    }
                    else {
LAB_:
                      if (cVar17 == '\t') goto LAB_;
                    }
LAB_:
                    (&stack0x0000003e)[lVar22] = 0;
                    goto LAB_;
                  }
                  if (*(int *)(ppbVar46 + 3) != 99) goto LAB_;
LAB_:
                  *(undefined4 *)(&stack0x000001ac + lVar22) = *(undefined4 *)ppbVar1;
                  *(undefined2 *)(&stack0x000001b0 + lVar22) =
                       *(undefined2 *)((longlong)ppbVar24 + 0x24);
                  *(undefined8 *)(puVar38 + -8) = 0x1028b3;
                  cVar17 = func_0x(&stack0x000001ac + lVar22);
                  if (cVar17 == '\0') goto LAB_;
                  (&stack0x0000003e)[lVar22] = 1;
                  *(undefined8 *)(puVar38 + -8) = 0x1028ca;
                  func_0x(ppbVar46,&stack0x00000158 + lVar22);
                }
                *ppbVar40 = (byte *)ppbVar39;
                uVar42 = *(undefined2 *)(&stack0x00000160 + lVar22);
                uVar30 = *(undefined8 *)(&stack0x00000158 + lVar22);
                *(undefined4 *)(ppbVar40 + 0xc) = *(undefined4 *)(&stack0x00000158 + lVar22);
                *(int *)((longlong)ppbVar40 + 100) = (int)((ulonglong)uVar30 >> 0x20);
                *(undefined2 *)(ppbVar40 + 0xd) = uVar42;
                *(undefined4 *)((longlong)ppbVar40 + 0x6c) = *(undefined4 *)ppbVar1;
                *(undefined2 *)(ppbVar40 + 0xe) = *(undefined2 *)((longlong)ppbVar24 + 0x24);
                *(undefined2 *)((longlong)ppbVar40 + 0x72) = 0;
                bVar4 = *(byte *)ppbVar39;
                *(undefined4 *)(&stack0x00000140 + lVar22) =
                     *(undefined4 *)((ulonglong)bVar4 * 6 + 0x15d5960);
                sVar18 = *(short *)((ulonglong)bVar4 * 6 + 0x15d5964);
                *(short *)(&stack0x00000030 + lVar22) = sVar18;
                *(undefined2 *)(ppbVar40 + 2) = 0xffff;
                ppbVar40[3] = (byte *)0x0;
                *(undefined4 *)((longlong)ppbVar40 + 0x14) = 0;
                *(undefined8 *)((longlong)ppbVar40 + 0x2e) = 0;
                ppbVar40[7] = (byte *)0x0;
                ppbVar40[4] = (byte *)0x0;
                ppbVar40[9] = (byte *)0x0;
                ppbVar40[10] = (byte *)0x0;
                *(undefined2 *)(ppbVar40 + 0xb) = 0;
                if ((**ppbVar40 & 2) != 0) {
                  pbVar41 = (byte *)((longlong)ppbVar39 + (longlong)sVar18);
                  bVar4 = *pbVar41;
                  *(ushort *)(ppbVar40 + 2) = (ushort)(bVar4 & 1);
                  if ((bVar4 & 1) == 0) {
                    *(undefined4 *)(&stack0x000000c0 + lVar22) = 0;
                    ppbVar40[3] = pbVar41;
                    *(undefined4 *)((longlong)ppbVar40 + 0x14) = 0;
                    *(undefined4 *)((longlong)ppbVar40 + 0x36) = 0;
                    uVar44 = uVar31;
                    switch(*pbVar41 & 0xe) {
                    default:
                      uVar19 = *(ushort *)(pbVar41 + 2);
                      uVar44 = (uint)uVar19;
                      *(uint *)(&stack0x000000c0 + lVar22) = (uint)uVar19;
                      if (uVar19 - 1 < 0x1f9e) goto code_r0x00102a64;
                      *(undefined8 *)(puVar38 + -8) = 0x1029f0;
                      func_0x(pbVar41,6);
                      ppbVar39 = ppbVar46 + 0xc;
                      *(uint *)(ppbVar40 + 4) = (uint)uVar19;
                      *(undefined8 *)((longlong)ppbVar40 + 0x2e) = 0;
                      break;
                    case 4:
                      *(undefined4 *)(&stack0x000000c0 + lVar22) = 9;
                      *(undefined4 *)(ppbVar40 + 4) = 9;
                      *(undefined8 *)((longlong)ppbVar40 + 0x2e) = 0;
                      break;
                    case 6:
                    case 10:
code_r0x00102a64:
                      *(uint *)(ppbVar40 + 4) = uVar44;
                      *(undefined8 *)((longlong)ppbVar40 + 0x2e) = 0;
                      break;
                    case 0xe:
                      *(undefined4 *)(&stack0x000000c0 + lVar22) = 1;
                      *(undefined4 *)(ppbVar40 + 4) = 1;
                      *(undefined8 *)((longlong)ppbVar40 + 0x2e) = 0;
                    }
                  }
                  else {
                    ppbVar40[3] = pbVar41;
                    bVar4 = *pbVar41;
                    switch(bVar4 & 0x1c) {
                    default:
                      if ((char)pbVar41[1] < '\0') {
                        uVar19 = *(ushort *)(pbVar41 + 1);
                        *(ushort *)((longlong)ppbVar40 + 0x12) = uVar19;
                        *(ushort *)((longlong)ppbVar40 + 0x12) = uVar19 >> 8 | (uVar19 & 0x7f) << 8;
                        sVar18 = 3;
                      }
                      else {
                        *(ushort *)((longlong)ppbVar40 + 0x12) = (ushort)pbVar41[1];
                        sVar18 = 2;
                      }
                      *(short *)(ppbVar40 + 5) = sVar18;
                      *(short *)((longlong)ppbVar40 + 0x2c) =
                           (short)(*(ushort *)((longlong)ppbVar40 + 0x12) + 1 >> 1) + sVar18;
                      if (*(ushort *)((longlong)ppbVar40 + 0x12) < 0x1f) {
                        *(undefined2 *)((longlong)ppbVar40 + 0x2a) = 0;
                        *(undefined4 *)((longlong)ppbVar40 + 0x14) = 0;
                        *(undefined4 *)(ppbVar40 + 8) = 0;
                      }
                      else {
                        iVar20 = *(ushort *)((longlong)ppbVar40 + 0x12) - 1;
                        *(short *)((longlong)ppbVar40 + 0x2a) =
                             ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                             (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                        *(undefined4 *)((longlong)ppbVar40 + 0x14) = 0;
                        *(undefined4 *)(ppbVar40 + 8) = 0;
                      }
                      break;
                    case 4:
                      uVar44 = uVar31;
                      if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
                        uVar44 = 1;
                      }
                      ppbVar40[3] = (byte *)0x0;
                      *(undefined4 *)((longlong)ppbVar40 + 0x14) = 0;
                      *(undefined2 *)(ppbVar40 + 5) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x12) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x2a) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x2c) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x2e) = 0;
                      *(undefined2 *)(ppbVar40 + 6) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x32) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x34) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x36) = 0;
                      ppbVar40[4] = (byte *)0x0;
                      *(undefined4 *)(ppbVar40 + 8) = 0;
                      ppbVar40[7] = (byte *)0x0;
                      ppbVar40[3] = pbVar41;
                      if (uVar44 == 0) {
                        *(undefined4 *)((longlong)ppbVar40 + 0x14) = 1;
                      }
                      else {
                        *(undefined4 *)((longlong)ppbVar40 + 0x14) = 0xf;
                        *(undefined4 *)(ppbVar40 + 8) = 1;
                      }
                      break;
                    case 8:
                      ppbVar40[3] = (byte *)0x0;
                      *(undefined4 *)((longlong)ppbVar40 + 0x14) = 0;
                      *(undefined2 *)(ppbVar40 + 5) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x12) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x2a) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x2c) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x2e) = 0;
                      *(undefined2 *)(ppbVar40 + 6) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x32) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x34) = 0;
                      *(undefined2 *)((longlong)ppbVar40 + 0x36) = 0;
                      ppbVar40[4] = (byte *)0x0;
                      *(undefined4 *)(ppbVar40 + 8) = 0;
                      ppbVar40[7] = (byte *)0x0;
                      ppbVar40[3] = pbVar41;
                      *(undefined4 *)((longlong)ppbVar40 + 0x14) = 9;
                    }
                    ppbVar40[7] = (byte *)0x0;
                    ppbVar40[4] = (byte *)0x0;
                  }
                  sVar18 = *(short *)(&stack0x00000030 + lVar22);
                }
                if ((**ppbVar40 & 4) != 0) {
                  if (*(short *)(&stack0x00000142 + lVar22) == 0) {
                    uVar27 = (ulonglong)sVar18;
                  }
                  else {
                    uVar27 = (ulonglong)
                             *(ushort *)
                              ((longlong)ppbVar39 +
                              (longlong)*(short *)(&stack0x00000142 + lVar22) * 2 + 1);
                  }
                  psVar28 = (short *)(uVar27 + (longlong)ppbVar39);
                  ppbVar40[9] = (byte *)psVar28;
                  sVar18 = *psVar28;
                  ppbVar40[10] = (byte *)(psVar28 + 1);
                  *(short *)(ppbVar40 + 0xb) = (sVar18 + 1) * 2;
                }
                pbVar41 = ppbVar40[1];
                if (pbVar41 != (byte *)0x0) {
                  *(undefined8 *)(puVar38 + -8) = 0x102c77;
                  func_0x(pbVar41,ppbVar40);
                }
              }
              else {
                *(undefined8 *)(&stack0x000001e8 + lVar22) = 0;
                ppbVar40 = ppbVar45;
              }
              uVar19 = *(ushort *)((longlong)ppbVar46 + 0xe);
              uVar44 = (uint)uVar19;
              pbVar41 = (byte *)((ulonglong)*(ushort *)((longlong)ppbVar46 + 0x1ffe) +
                                (longlong)ppbVar46);
              if ((*pbVar41 & 1) == 0) {
                *(undefined2 *)(&stack0x00000530 + lVar22) = 0;
                *(uint *)(&stack0x000000c8 + lVar22) = (uint)uVar19;
                *(byte **)(&stack0x00000538 + lVar22) = pbVar41;
                *(undefined4 *)(&stack0x00000534 + lVar22) = 0;
                *(undefined4 *)(&stack0x00000556 + lVar22) = 0;
                switch(*pbVar41 & 0xe) {
                default:
                  uVar19 = *(ushort *)(pbVar41 + 2);
                  uVar44 = (uint)uVar19;
                  *(uint *)(&stack0x000000c8 + lVar22) = (uint)uVar19;
                  if (0x1f9d < uVar19 - 1) {
                    *(undefined8 *)(puVar38 + -8) = 0x10303a;
                    func_0x(pbVar41,6);
                  }
                  break;
                case 4:
                  uVar44 = 9;
                  *(undefined4 *)(&stack0x000000c8 + lVar22) = 9;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar44 = 1;
                  *(undefined4 *)(&stack0x000000c8 + lVar22) = 1;
                }
                *(uint *)(&stack0x00000540 + lVar22) = uVar44;
                *(byte ***)(&stack0x0000054e + lVar22) = ppbVar46 + 0x400;
              }
              else {
                *(undefined2 *)(&stack0x00000530 + lVar22) = 1;
                *(byte **)(&stack0x00000538 + lVar22) = pbVar41;
                bVar4 = *pbVar41;
                switch(bVar4 & 0x1c) {
                default:
                  uVar19 = (ushort)pbVar41[1];
                  if ((char)pbVar41[1] < '\0') {
                    uVar19 = *(ushort *)(pbVar41 + 1);
                    *(ushort *)(&stack0x00000532 + lVar22) = uVar19;
                    uVar19 = uVar19 >> 8 | (uVar19 & 0x7f) << 8;
                    sVar18 = 3;
                  }
                  else {
                    sVar18 = 2;
                  }
                  *(ushort *)(&stack0x00000532 + lVar22) = uVar19;
                  *(short *)(&stack0x00000548 + lVar22) = sVar18;
                  *(short *)(&stack0x0000054c + lVar22) = (short)(uVar19 + 1 >> 1) + sVar18;
                  if (uVar19 < 0x1f) {
                    *(undefined2 *)(&stack0x0000054a + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000534 + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000560 + lVar22) = 0;
                    *(byte ***)(&stack0x00000558 + lVar22) = ppbVar46 + 0x400;
                    *(byte ***)(&stack0x00000540 + lVar22) = ppbVar40;
                  }
                  else {
                    iVar20 = uVar19 - 1;
                    *(short *)(&stack0x0000054a + lVar22) =
                         ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                         (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                    *(undefined4 *)(&stack0x00000534 + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000560 + lVar22) = 0;
                    *(byte ***)(&stack0x00000558 + lVar22) = ppbVar46 + 0x400;
                    *(byte ***)(&stack0x00000540 + lVar22) = ppbVar40;
                  }
                  break;
                case 4:
                  if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
                    *(undefined8 *)(&stack0x00000538 + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000534 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000548 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000532 + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000054a + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000054c + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000054e + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000550 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000552 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000554 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000556 + lVar22) = 0;
                    *(undefined8 *)(&stack0x00000540 + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000560 + lVar22) = 0;
                    *(undefined8 *)(&stack0x00000558 + lVar22) = 0;
                    *(byte **)(&stack0x00000538 + lVar22) = pbVar41;
                    *(undefined4 *)(&stack0x00000534 + lVar22) = 0xf;
                    *(undefined4 *)(&stack0x00000560 + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000560 + lVar22) = 1;
                    *(byte ***)(&stack0x00000558 + lVar22) = ppbVar46 + 0x400;
                    *(byte ***)(&stack0x00000540 + lVar22) = ppbVar40;
                  }
                  else {
                    *(undefined8 *)(&stack0x00000538 + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000534 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000548 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000532 + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000054a + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000054c + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000054e + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000550 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000552 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000554 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000556 + lVar22) = 0;
                    *(undefined8 *)(&stack0x00000540 + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000560 + lVar22) = 0;
                    *(undefined8 *)(&stack0x00000558 + lVar22) = 0;
                    *(byte **)(&stack0x00000538 + lVar22) = pbVar41;
                    *(undefined4 *)(&stack0x00000534 + lVar22) = 1;
                    *(undefined4 *)(&stack0x00000560 + lVar22) = 0;
                    *(byte ***)(&stack0x00000558 + lVar22) = ppbVar46 + 0x400;
                    *(byte ***)(&stack0x00000540 + lVar22) = ppbVar40;
                  }
                  break;
                case 8:
                  *(undefined8 *)(&stack0x00000538 + lVar22) = 0;
                  *(undefined4 *)(&stack0x00000534 + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000548 + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000532 + lVar22) = 0;
                  *(undefined2 *)(&stack0x0000054a + lVar22) = 0;
                  *(undefined2 *)(&stack0x0000054c + lVar22) = 0;
                  *(undefined2 *)(&stack0x0000054e + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000550 + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000552 + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000554 + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000556 + lVar22) = 0;
                  *(undefined8 *)(&stack0x00000540 + lVar22) = 0;
                  *(undefined4 *)(&stack0x00000560 + lVar22) = 0;
                  *(undefined8 *)(&stack0x00000558 + lVar22) = 0;
                  *(byte **)(&stack0x00000538 + lVar22) = pbVar41;
                  *(undefined4 *)(&stack0x00000534 + lVar22) = 9;
                  *(undefined4 *)(&stack0x00000560 + lVar22) = 0;
                  *(byte ***)(&stack0x00000558 + lVar22) = ppbVar46 + 0x400;
                  *(byte ***)(&stack0x00000540 + lVar22) = ppbVar40;
                }
              }
              param_1 = *(longlong *)(&stack0x00000050 + lVar22);
              lVar26 = *(longlong *)(param_1 + 0x418);
              *(undefined4 *)(puVar38 + 0x30) = 0;
              *(longlong *)(puVar38 + 0x28) = lVar26 + 0x20;
              *(undefined4 *)(puVar38 + 0x20) = 0xa58;
              uVar30 = *(undefined8 *)(lVar26 + 0x10);
              uVar29 = *(undefined8 *)(&stack0x00000058 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x1030d2;
              func_0x(uVar29,&stack0x00000530 + lVar22,0,uVar30);
              *(undefined8 *)(puVar38 + -8) = 0x1030da;
              func_0x(lVar32);
              lVar26 = *(longlong *)(param_1 + 0x418);
              *(undefined4 *)(lVar26 + 0x18) = *(undefined4 *)(&stack0x00000034 + lVar22);
              *(undefined2 *)(lVar26 + 0x1c) = *(undefined2 *)(&stack0x00000038 + lVar22);
              *(undefined2 *)(lVar26 + 0x1e) = 0;
              plVar34 = *(longlong **)(&stack0x00000040 + lVar22);
              *plVar34 = *(longlong *)(param_1 + 0x418);
              ppbVar39 = *(byte ***)(&stack0x000000e0 + lVar22);
              *(byte ***)(&stack0x00000150 + lVar22) = ppbVar39;
              *(undefined4 *)(&stack0x00000074 + lVar22) = 0;
              *(undefined4 *)(&stack0x00000070 + lVar22) = 0;
              goto LAB_;
            }
          }
          else {
            *(int *)(&stack0x00000280 + lVar22) = _DAT_;
            *(int *)(&stack0x00000284 + lVar22) = iRam0000000001ef940c;
            *(int *)(&stack0x00000288 + lVar22) = _DAT_;
            *(int *)(&stack0x0000028c + lVar22) = iRam0000000001ef9414;
            *(undefined8 *)(&stack0x00000238 + lVar22) = 0;
            *(undefined2 *)(&stack0x000003d0 + lVar22) = 0xffff;
            *(undefined8 *)(&stack0x000003d8 + lVar22) = 0;
            *(undefined4 *)(&stack0x000003d4 + lVar22) = 0;
            *(undefined8 *)(&stack0x000003ee + lVar22) = 0;
            *(undefined8 *)(&stack0x000003f8 + lVar22) = 0;
            *(undefined8 *)(&stack0x000003e0 + lVar22) = 0;
            *(undefined4 *)(&stack0x00000404 + lVar22) = 0xffffffff;
            *(undefined2 *)(&stack0x00000480 + lVar22) = 0xffff;
            *(undefined8 *)(&stack0x00000488 + lVar22) = 0;
            *(undefined4 *)(&stack0x00000484 + lVar22) = 0;
            *(undefined8 *)(&stack0x0000049e + lVar22) = 0;
            *(undefined8 *)(&stack0x000004a8 + lVar22) = 0;
            *(undefined8 *)(&stack0x00000490 + lVar22) = 0;
            *(undefined4 *)(&stack0x000004b4 + lVar22) = 0xffffffff;
            *(undefined4 *)(&stack0x00000188 + lVar22) = 0;
            param_1 = *(longlong *)(&stack0x00000050 + lVar22);
            *(longlong *)(&stack0x000000f0 + lVar22) = *(longlong *)(param_1 + 0x418) + 0x20;
            while( true ) {
              *(undefined8 *)(puVar38 + 0x28) = 0;
              *(undefined **)(puVar38 + 0x20) = &stack0x00000280 + lVar22;
              uVar30 = *(undefined8 *)(&stack0x00000028 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x100e78;
              iVar20 = func_0x(uVar30,&stack0x00000064 + lVar22,3);
              lVar26 = lVar32;
              if (iVar20 == 0) goto LAB_;
              *(undefined8 *)(puVar38 + -8) = 0x100e8f;
              func_0x(lVar37,&stack0x00000280 + lVar22);
              uVar30 = *(undefined8 *)(&stack0x000000f8 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x100ea4;
              iVar20 = func_0x(param_1,lVar37,uVar30,0);
              if (iVar20 != 0) {
                *(undefined8 *)(puVar38 + -8) = 0x100eb0;
                func_0x(lVar32);
                lVar26 = lVar37;
                goto LAB_;
              }
              ppbVar39 = ppbVar45;
              if (*(undefined8 **)(lVar37 + 0x30) != (undefined8 *)0x0) {
                ppbVar39 = (byte **)**(undefined8 **)(lVar37 + 0x30);
              }
              *(byte ***)(&stack0x00000238 + lVar22) = ppbVar39;
              if (*(short *)((longlong)ppbVar39 + 0x16) != 0) break;
              *(undefined8 *)(puVar38 + -8) = 0x10262e;
              iVar20 = func_0x(param_1,lVar37,0);
              *(undefined8 *)(puVar38 + -8) = 0x102638;
              func_0x(lVar37);
              if (iVar20 != 0) goto LAB_;
              **(longlong **)(&stack0x00000108 + lVar22) =
                   **(longlong **)(&stack0x00000108 + lVar22) + 1;
              *(undefined8 *)(puVar38 + 0x30) = *(undefined8 *)(&stack0x00000078 + lVar22);
              *(undefined **)(puVar38 + 0x28) = &stack0x00000064 + lVar22;
              *(byte ***)(puVar38 + 0x20) = ppbVar23;
              uVar30 = *(undefined8 *)(&stack0x00000028 + lVar22);
              uVar29 = *(undefined8 *)(&stack0x00000058 + lVar22);
              uVar11 = *(undefined8 *)(&stack0x00000048 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x102675;
              func_0x(param_1,uVar11,uVar29,uVar30);
              *(undefined4 *)(&stack0x00000128 + lVar22) = 0;
              *(undefined2 *)(&stack0x0000012c + lVar22) = 0;
              iVar20 = *(int *)(&stack0x00000064 + lVar22);
              sVar18 = *(short *)(&stack0x00000068 + lVar22);
              if ((iVar20 == 0) && (sVar18 == 0)) {
                *(undefined4 *)(&stack0x00000138 + lVar22) = 0;
                *(undefined2 *)(&stack0x0000013c + lVar22) = 0;
                acStackX_20[lVar22 + 1] = '\x01';
                *(undefined8 *)(puVar38 + -8) = 0x1026af;
                func_0x(lVar32);
                lVar26 = lVar37;
                goto LAB_;
              }
              if ((iVar20 == *(int *)(&stack0x00000034 + lVar22)) &&
                 (sVar18 == *(short *)(&stack0x00000038 + lVar22))) {
                *(undefined4 *)(&stack0x00000138 + lVar22) = 0;
                *(undefined2 *)(&stack0x0000013c + lVar22) = 0;
                if ((iVar20 == 0) && (sVar18 == 0)) {
                  acStackX_20[lVar22 + 1] = '\x01';
                }
                *(undefined8 *)(puVar38 + -8) = 0x1026e3;
                func_0x(lVar32);
                lVar26 = lVar37;
LAB_:
                *(undefined8 *)(puVar38 + -8) = 0x1026f5;
                func_0x(lVar26);
                ppbVar39 = *(byte ***)(&stack0x000000e0 + lVar22);
                goto LAB_;
              }
            }
            *(undefined4 *)(&stack0x00000188 + lVar22) = 1;
            *(undefined4 *)(&stack0x00000404 + lVar22) = 0;
            if (*(char *)((longlong)ppbVar39 + 2) < '\0') {
              ppbVar23 = ppbVar39 + 0xc;
              if (*(short *)(&stack0x000003d0 + lVar22) == 0) {
                *(undefined8 *)(&stack0x000001d8 + lVar22) = 0;
LAB_:
                *(undefined (*) [16])(&stack0x00000408 + lVar22) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000418 + lVar22) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000428 + lVar22) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000438 + lVar22) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000448 + lVar22) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000458 + lVar22) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000468 + lVar22) = ZEXT816(0);
                *(undefined8 *)(&stack0x00000478 + lVar22) = 0;
                *(undefined (*) [16])(&stack0x00000408 + lVar22) = ZEXT816(0);
                *(undefined2 *)(&stack0x00000418 + lVar22) = 0xffff;
                *(undefined8 *)(&stack0x00000420 + lVar22) = 0;
                *(undefined4 *)(&stack0x0000041c + lVar22) = 0;
                *(undefined8 *)(&stack0x00000436 + lVar22) = 0;
                *(undefined8 *)(&stack0x00000440 + lVar22) = 0;
                *(undefined8 *)(&stack0x00000428 + lVar22) = 0;
                *(undefined8 *)(&stack0x00000450 + lVar22) = 0;
                *(undefined4 *)(&stack0x00000468 + lVar22) = 0;
                *(undefined4 *)(&stack0x0000046c + lVar22) = 0;
                *(undefined2 *)(&stack0x00000470 + lVar22) = 0;
                *(undefined2 *)(&stack0x00000472 + lVar22) = 0;
                *(undefined2 *)(&stack0x0000047a + lVar22) = 0;
                ppbVar24 = (byte **)(&stack0x00000408 + lVar22);
                *(byte ***)(&stack0x000001d8 + lVar22) = ppbVar24;
              }
              else {
                ppbVar24 = *(byte ***)(&stack0x000003e0 + lVar22);
                *(byte ***)(&stack0x000001d8 + lVar22) = ppbVar24;
                if (ppbVar24 == (byte **)0x0) goto LAB_;
              }
              uVar42 = 0xffff;
              (&stack0x0000003c)[lVar22] = 0;
              if (*(short *)((longlong)ppbVar39 + 0x24) == 0) {
LAB_:
                *(byte **)(&stack0x00000178 + lVar22) = ppbVar39[5];
                *(undefined2 *)(&stack0x00000180 + lVar22) = *(undefined2 *)(ppbVar39 + 6);
              }
              else {
                cVar17 = *(char *)((longlong)ppbVar39 + 1);
                uVar42 = 0xffff;
                if (cVar17 != '\v') {
                  if (cVar17 == '\b') {
LAB_:
                    if (*(int *)(ppbVar39 + 3) == 99) goto LAB_;
                  }
                  else {
LAB_:
                    if (cVar17 == '\t') goto LAB_;
                  }
LAB_:
                  (&stack0x0000003c)[lVar22] = 0;
                  goto LAB_;
                }
                if (*(int *)(ppbVar39 + 3) != 99) goto LAB_;
LAB_:
                *(undefined4 *)(&stack0x0000019c + lVar22) = *(undefined4 *)(ppbVar39 + 4);
                *(undefined2 *)(&stack0x000001a0 + lVar22) =
                     *(undefined2 *)((longlong)ppbVar39 + 0x24);
                *(undefined8 *)(puVar38 + -8) = 0x101041;
                uVar42 = 0xffff;
                cVar17 = func_0x(&stack0x0000019c + lVar22);
                if (cVar17 == '\0') goto LAB_;
                (&stack0x0000003c)[lVar22] = 1;
                *(undefined8 *)(puVar38 + -8) = 0x101058;
                func_0x(ppbVar39,&stack0x00000178 + lVar22);
              }
              *ppbVar24 = (byte *)ppbVar23;
              uVar5 = *(undefined2 *)(&stack0x00000180 + lVar22);
              uVar30 = *(undefined8 *)(&stack0x00000178 + lVar22);
              *(undefined4 *)(ppbVar24 + 0xc) = *(undefined4 *)(&stack0x00000178 + lVar22);
              *(int *)((longlong)ppbVar24 + 100) = (int)((ulonglong)uVar30 >> 0x20);
              *(undefined2 *)(ppbVar24 + 0xd) = uVar5;
              *(undefined4 *)((longlong)ppbVar24 + 0x6c) = *(undefined4 *)(ppbVar39 + 4);
              *(undefined2 *)(ppbVar24 + 0xe) = *(undefined2 *)((longlong)ppbVar39 + 0x24);
              *(undefined2 *)((longlong)ppbVar24 + 0x72) = 0;
              bVar4 = *(byte *)ppbVar23;
              *(undefined4 *)(&stack0x00000208 + lVar22) =
                   *(undefined4 *)((ulonglong)bVar4 * 6 + 0x15d5960);
              sVar18 = *(short *)((ulonglong)bVar4 * 6 + 0x15d5964);
              *(short *)(&stack0x00000030 + lVar22) = sVar18;
              *(undefined2 *)(ppbVar24 + 2) = uVar42;
              ppbVar24[3] = (byte *)0x0;
              *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
              *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
              ppbVar24[7] = (byte *)0x0;
              ppbVar24[4] = (byte *)0x0;
              ppbVar24[9] = (byte *)0x0;
              ppbVar24[10] = (byte *)0x0;
              *(undefined2 *)(ppbVar24 + 0xb) = 0;
              if ((**ppbVar24 & 2) != 0) {
                pbVar41 = (byte *)((longlong)sVar18 + (longlong)ppbVar23);
                bVar4 = *pbVar41;
                *(ushort *)(ppbVar24 + 2) = (ushort)(bVar4 & 1);
                if ((bVar4 & 1) == 0) {
                  *(undefined4 *)(&stack0x000000a0 + lVar22) = 0;
                  ppbVar24[3] = pbVar41;
                  *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                  *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
                  uVar44 = uVar31;
                  switch(*pbVar41 & 0xe) {
                  default:
                    uVar19 = *(ushort *)(pbVar41 + 2);
                    uVar44 = (uint)uVar19;
                    *(uint *)(&stack0x000000a0 + lVar22) = (uint)uVar19;
                    if (uVar19 - 1 < 0x1f9e) goto code_r0x001011e3;
                    *(undefined8 *)(puVar38 + -8) = 0x101177;
                    func_0x(pbVar41,6);
                    *(uint *)(ppbVar24 + 4) = (uint)uVar19;
                    *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                    break;
                  case 4:
                    *(undefined4 *)(&stack0x000000a0 + lVar22) = 9;
                    *(undefined4 *)(ppbVar24 + 4) = 9;
                    *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                    break;
                  case 6:
                  case 10:
code_r0x001011e3:
                    *(uint *)(ppbVar24 + 4) = uVar44;
                    *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                    break;
                  case 0xe:
                    *(undefined4 *)(&stack0x000000a0 + lVar22) = 1;
                    *(undefined4 *)(ppbVar24 + 4) = 1;
                    *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                  }
                }
                else {
                  ppbVar24[3] = pbVar41;
                  bVar4 = *pbVar41;
                  switch(bVar4 & 0x1c) {
                  default:
                    if ((char)pbVar41[1] < '\0') {
                      uVar19 = *(ushort *)(pbVar41 + 1);
                      *(ushort *)((longlong)ppbVar24 + 0x12) = uVar19;
                      *(ushort *)((longlong)ppbVar24 + 0x12) = uVar19 >> 8 | (uVar19 & 0x7f) << 8;
                      sVar18 = 3;
                    }
                    else {
                      *(ushort *)((longlong)ppbVar24 + 0x12) = (ushort)pbVar41[1];
                      sVar18 = 2;
                    }
                    *(short *)(ppbVar24 + 5) = sVar18;
                    *(short *)((longlong)ppbVar24 + 0x2c) =
                         (short)(*(ushort *)((longlong)ppbVar24 + 0x12) + 1 >> 1) + sVar18;
                    if (*(ushort *)((longlong)ppbVar24 + 0x12) < 0x1f) {
                      *(undefined2 *)((longlong)ppbVar24 + 0x2a) = 0;
                      *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                      *(undefined4 *)(ppbVar24 + 8) = 0;
                    }
                    else {
                      iVar20 = *(ushort *)((longlong)ppbVar24 + 0x12) - 1;
                      *(short *)((longlong)ppbVar24 + 0x2a) =
                           ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                           (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                      *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                      *(undefined4 *)(ppbVar24 + 8) = 0;
                    }
                    break;
                  case 4:
                    uVar44 = uVar31;
                    if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
                      uVar44 = 1;
                    }
                    ppbVar24[3] = (byte *)0x0;
                    *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                    *(undefined2 *)(ppbVar24 + 5) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x2a) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x2c) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x2e) = 0;
                    *(undefined2 *)(ppbVar24 + 6) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x32) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x34) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x36) = 0;
                    ppbVar24[4] = (byte *)0x0;
                    *(undefined4 *)(ppbVar24 + 8) = 0;
                    ppbVar24[7] = (byte *)0x0;
                    ppbVar24[3] = pbVar41;
                    if (uVar44 == 0) {
                      *(undefined4 *)((longlong)ppbVar24 + 0x14) = 1;
                    }
                    else {
                      *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0xf;
                      *(undefined4 *)(ppbVar24 + 8) = 1;
                    }
                    break;
                  case 8:
                    ppbVar24[3] = (byte *)0x0;
                    *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                    *(undefined2 *)(ppbVar24 + 5) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x2a) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x2c) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x2e) = 0;
                    *(undefined2 *)(ppbVar24 + 6) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x32) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x34) = 0;
                    *(undefined2 *)((longlong)ppbVar24 + 0x36) = 0;
                    ppbVar24[4] = (byte *)0x0;
                    *(undefined4 *)(ppbVar24 + 8) = 0;
                    ppbVar24[7] = (byte *)0x0;
                    ppbVar24[3] = pbVar41;
                    *(undefined4 *)((longlong)ppbVar24 + 0x14) = 9;
                  }
                  ppbVar24[7] = (byte *)0x0;
                  ppbVar24[4] = (byte *)0x0;
                }
                sVar18 = *(short *)(&stack0x00000030 + lVar22);
              }
              if ((**ppbVar24 & 4) != 0) {
                if (*(short *)(&stack0x0000020a + lVar22) == 0) {
                  uVar27 = (ulonglong)sVar18;
                }
                else {
                  uVar27 = (ulonglong)
                           *(ushort *)
                            ((longlong)ppbVar39 +
                            (longlong)*(short *)(&stack0x0000020a + lVar22) * 2 + 0x61);
                }
                psVar28 = (short *)(uVar27 + (longlong)ppbVar23);
                ppbVar24[9] = (byte *)psVar28;
                sVar18 = *psVar28;
                ppbVar24[10] = (byte *)(psVar28 + 1);
                *(short *)(ppbVar24 + 0xb) = (sVar18 + 1) * 2;
              }
              pbVar41 = ppbVar24[1];
              if (pbVar41 != (byte *)0x0) {
                *(undefined8 *)(puVar38 + -8) = 0x1013f2;
                func_0x(pbVar41,ppbVar24);
              }
            }
            else {
              *(undefined8 *)(&stack0x000001d8 + lVar22) = 0;
              ppbVar24 = ppbVar45;
            }
            uVar19 = *(ushort *)((longlong)ppbVar39 + 0xe);
            uVar44 = (uint)uVar19;
            pbVar41 = (byte *)((ulonglong)*(ushort *)((longlong)ppbVar39 + 0x1ffe) +
                              (longlong)ppbVar39);
            if ((*pbVar41 & 1) == 0) {
              *(undefined2 *)(&stack0x000003d0 + lVar22) = 0;
              *(uint *)(&stack0x000000a8 + lVar22) = (uint)uVar19;
              *(byte **)(&stack0x000003d8 + lVar22) = pbVar41;
              *(undefined4 *)(&stack0x000003d4 + lVar22) = 0;
              *(undefined4 *)(&stack0x000003f6 + lVar22) = 0;
              switch(*pbVar41 & 0xe) {
              default:
                uVar19 = *(ushort *)(pbVar41 + 2);
                uVar44 = (uint)uVar19;
                *(uint *)(&stack0x000000a8 + lVar22) = (uint)uVar19;
                if (0x1f9d < uVar19 - 1) {
                  *(undefined8 *)(puVar38 + -8) = 0x1017b5;
                  func_0x(pbVar41,6);
                }
                break;
              case 4:
                uVar44 = 9;
                *(undefined4 *)(&stack0x000000a8 + lVar22) = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar44 = 1;
                *(undefined4 *)(&stack0x000000a8 + lVar22) = 1;
              }
              *(uint *)(&stack0x000003e0 + lVar22) = uVar44;
              *(byte ***)(&stack0x000003ee + lVar22) = ppbVar39 + 0x400;
            }
            else {
              *(undefined2 *)(&stack0x000003d0 + lVar22) = 1;
              *(byte **)(&stack0x000003d8 + lVar22) = pbVar41;
              bVar4 = *pbVar41;
              switch(bVar4 & 0x1c) {
              default:
                uVar19 = (ushort)pbVar41[1];
                if ((char)pbVar41[1] < '\0') {
                  uVar19 = *(ushort *)(pbVar41 + 1);
                  *(ushort *)(&stack0x000003d2 + lVar22) = uVar19;
                  uVar19 = uVar19 >> 8 | (uVar19 & 0x7f) << 8;
                  sVar18 = 3;
                }
                else {
                  sVar18 = 2;
                }
                *(ushort *)(&stack0x000003d2 + lVar22) = uVar19;
                *(short *)(&stack0x000003e8 + lVar22) = sVar18;
                *(short *)(&stack0x000003ec + lVar22) = (short)(uVar19 + 1 >> 1) + sVar18;
                if (uVar19 < 0x1f) {
                  *(undefined2 *)(&stack0x000003ea + lVar22) = 0;
                  *(undefined4 *)(&stack0x000003d4 + lVar22) = 0;
                  *(undefined4 *)(&stack0x00000400 + lVar22) = 0;
                  *(byte ***)(&stack0x000003f8 + lVar22) = ppbVar39 + 0x400;
                  *(byte ***)(&stack0x000003e0 + lVar22) = ppbVar24;
                }
                else {
                  iVar20 = uVar19 - 1;
                  *(short *)(&stack0x000003ea + lVar22) =
                       ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                       (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                  *(undefined4 *)(&stack0x000003d4 + lVar22) = 0;
                  *(undefined4 *)(&stack0x00000400 + lVar22) = 0;
                  *(byte ***)(&stack0x000003f8 + lVar22) = ppbVar39 + 0x400;
                  *(byte ***)(&stack0x000003e0 + lVar22) = ppbVar24;
                }
                break;
              case 4:
                if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
                  *(undefined8 *)(&stack0x000003d8 + lVar22) = 0;
                  *(undefined4 *)(&stack0x000003d4 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003e8 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003d2 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003ea + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003ec + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003ee + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003f0 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003f2 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003f4 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003f6 + lVar22) = 0;
                  *(undefined8 *)(&stack0x000003e0 + lVar22) = 0;
                  *(undefined4 *)(&stack0x00000400 + lVar22) = 0;
                  *(undefined8 *)(&stack0x000003f8 + lVar22) = 0;
                  *(byte **)(&stack0x000003d8 + lVar22) = pbVar41;
                  *(undefined4 *)(&stack0x000003d4 + lVar22) = 0xf;
                  *(undefined4 *)(&stack0x00000400 + lVar22) = 0;
                  *(undefined4 *)(&stack0x00000400 + lVar22) = 1;
                  *(byte ***)(&stack0x000003f8 + lVar22) = ppbVar39 + 0x400;
                  *(byte ***)(&stack0x000003e0 + lVar22) = ppbVar24;
                }
                else {
                  *(undefined8 *)(&stack0x000003d8 + lVar22) = 0;
                  *(undefined4 *)(&stack0x000003d4 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003e8 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003d2 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003ea + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003ec + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003ee + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003f0 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003f2 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003f4 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000003f6 + lVar22) = 0;
                  *(undefined8 *)(&stack0x000003e0 + lVar22) = 0;
                  *(undefined4 *)(&stack0x00000400 + lVar22) = 0;
                  *(undefined8 *)(&stack0x000003f8 + lVar22) = 0;
                  *(byte **)(&stack0x000003d8 + lVar22) = pbVar41;
                  *(undefined4 *)(&stack0x000003d4 + lVar22) = 1;
                  *(undefined4 *)(&stack0x00000400 + lVar22) = 0;
                  *(byte ***)(&stack0x000003f8 + lVar22) = ppbVar39 + 0x400;
                  *(byte ***)(&stack0x000003e0 + lVar22) = ppbVar24;
                }
                break;
              case 8:
                *(undefined8 *)(&stack0x000003d8 + lVar22) = 0;
                *(undefined4 *)(&stack0x000003d4 + lVar22) = 0;
                *(undefined2 *)(&stack0x000003e8 + lVar22) = 0;
                *(undefined2 *)(&stack0x000003d2 + lVar22) = 0;
                *(undefined2 *)(&stack0x000003ea + lVar22) = 0;
                *(undefined2 *)(&stack0x000003ec + lVar22) = 0;
                *(undefined2 *)(&stack0x000003ee + lVar22) = 0;
                *(undefined2 *)(&stack0x000003f0 + lVar22) = 0;
                *(undefined2 *)(&stack0x000003f2 + lVar22) = 0;
                *(undefined2 *)(&stack0x000003f4 + lVar22) = 0;
                *(undefined2 *)(&stack0x000003f6 + lVar22) = 0;
                *(undefined8 *)(&stack0x000003e0 + lVar22) = 0;
                *(undefined4 *)(&stack0x00000400 + lVar22) = 0;
                *(undefined8 *)(&stack0x000003f8 + lVar22) = 0;
                *(byte **)(&stack0x000003d8 + lVar22) = pbVar41;
                *(undefined4 *)(&stack0x000003d4 + lVar22) = 9;
                *(undefined4 *)(&stack0x00000400 + lVar22) = 0;
                *(byte ***)(&stack0x000003f8 + lVar22) = ppbVar39 + 0x400;
                *(byte ***)(&stack0x000003e0 + lVar22) = ppbVar24;
              }
            }
            lVar26 = *(longlong *)(&stack0x00000110 + lVar22);
            if (lVar26 == 0) {
              uVar35 = (ulonglong)(*(int *)(&stack0x00000060 + lVar22) * 0x10 + 0x18);
              uVar27 = uVar35 + 0xf;
              if (uVar27 <= uVar35) {
                uVar27 = 0xffffffffffffff0;
              }
              uVar27 = uVar27 & 0xfffffffffffffff0;
              *(undefined8 *)(puVar38 + -8) = 0x10184a;
              func_0x();
              lVar15 = -uVar27;
              *(undefined8 *)(puVar38 + lVar15 + -8) = 0x101857;
              lVar26 = func_0x(puVar38 + lVar15 + 0x60);
              *(longlong *)(&stack0x00000110 + lVar22) = lVar26;
              uVar30 = *(undefined8 *)(&stack0x00000058 + lVar22);
              *(undefined8 *)(puVar38 + lVar15 + -8) = 0x10186d;
              func_0x(uVar30,lVar26);
              puVar38 = puVar38 + lVar15;
            }
            *(undefined4 *)(puVar38 + 0x30) = 0;
            uVar30 = *(undefined8 *)(&stack0x000000f0 + lVar22);
            *(undefined8 *)(puVar38 + 0x28) = uVar30;
            *(undefined4 *)(puVar38 + 0x20) = 0xa58;
            uVar29 = *(undefined8 *)(&stack0x00000058 + lVar22);
            *(undefined8 *)(puVar38 + -8) = 0x10189c;
            func_0x(uVar29,&stack0x000003d0 + lVar22,0,lVar26);
            *(undefined8 *)(puVar38 + -8) = 0x1018a4;
            func_0x(lVar37);
            if (*(longlong *)(&stack0x000010a8 + lVar22) == 0) {
              lVar37 = *(longlong *)(&stack0x00000050 + lVar22);
            }
            else {
              lVar15 = *(longlong *)(&stack0x000000e0 + lVar22);
              if ((lVar15 < *(longlong *)(&stack0x000010a8 + lVar22)) &&
                 (*(int *)(&stack0x00000070 + lVar22) == 0)) {
                *(undefined4 *)(&stack0x00000074 + lVar22) = 1;
                lVar37 = *(longlong *)(&stack0x00000050 + lVar22);
              }
              else {
                lVar37 = *(longlong *)(&stack0x00000050 + lVar22);
                uVar29 = *(undefined8 *)(*(longlong *)(lVar37 + 0x418) + 0x10);
                *(undefined8 *)(puVar38 + -8) = 0x1018ef;
                func_0x(uVar29,lVar26,uVar30,0xa58);
                **(undefined8 **)(&stack0x00000040 + lVar22) = *(undefined8 *)(lVar37 + 0x418);
                *(undefined4 *)(&stack0x00000074 + lVar22) = 0;
              }
              *(longlong *)(&stack0x00000150 + lVar22) = lVar15;
              lVar26 = *(longlong *)(lVar37 + 0x418);
              *(undefined4 *)(lVar26 + 0x18) = *(undefined4 *)(&stack0x00000034 + lVar22);
              *(undefined2 *)(lVar26 + 0x1c) = *(undefined2 *)(&stack0x00000038 + lVar22);
              *(undefined2 *)(lVar26 + 0x1e) = 0;
              *(undefined4 *)(&stack0x00000070 + lVar22) = 0;
            }
            if ((cRam0000000001ee86b8 == '\0') || ((bRam0000000001ef8b15 & 0x10) != 0)) {
              cVar17 = '\0';
            }
            else {
              cVar17 = '\x01';
            }
            *pcVar3 = cVar17;
            (&stack0x00000098)[lVar22] = cVar17;
            (&stack0x0000006c)[lVar22] = 1;
            if (((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000100 + lVar22) + 0x6b0) + 0x3c)
                 & 1) == 0) ||
               (*(longlong *)
                 (*(longlong *)(*(longlong *)(&stack0x00000100 + lVar22) + 0x6b0) + 0x280) != 0)) {
              cVar43 = '\0';
            }
            else {
              cVar43 = '\x01';
            }
            (&stack0x00000030)[lVar22] = cVar43;
            (&stack0x0000006c)[lVar22] = cVar43;
            if ((*(int *)(*(longlong *)(lVar37 + 0x418) + 4) == *(int *)(&stack0x00000034 + lVar22))
               && (*(short *)(*(longlong *)(lVar37 + 0x418) + 8) ==
                   *(short *)(&stack0x00000038 + lVar22))) {
              *(undefined8 *)(&stack0x00000308 + lVar22) = 0;
              if ((cVar17 == '\0') || (uVar30 = uRam00000000014569d8, cVar43 == '\0')) {
                uVar30 = uRam00000000014557f0;
              }
              *(undefined8 *)(puVar38 + 0x28) = 0;
              *(undefined8 *)(puVar38 + 0x20) = uVar30;
              *(undefined8 *)(puVar38 + -8) = 0x1019e1;
              func_0x(&stack0x00000358 + lVar22,0xb,0,0);
              lVar32 = *(longlong *)(lVar37 + 0x418);
              *(int *)(&stack0x00000318 + lVar22) = _DAT_;
              *(int *)(&stack0x0000031c + lVar22) = iRam0000000001ef940c;
              *(int *)(&stack0x00000320 + lVar22) = _DAT_;
              *(int *)(&stack0x00000324 + lVar22) = iRam0000000001ef9414;
              *(longlong *)(puVar38 + 0x48) = lVar32 + 4;
              *(undefined **)(puVar38 + 0x40) = &stack0x00000318 + lVar22;
              puVar38[0x38] = 0;
              *(longlong *)(puVar38 + 0x30) = lVar37 + 0x340;
              *(undefined **)(puVar38 + 0x28) = &stack0x00000034 + lVar22;
              *(undefined8 *)(puVar38 + 0x20) = *(undefined8 *)(&stack0x00000110 + lVar22);
              uVar30 = *(undefined8 *)(&stack0x000000f8 + lVar22);
              uVar29 = *(undefined8 *)(&stack0x00000028 + lVar22);
              uVar11 = *(undefined8 *)(&stack0x00000058 + lVar22);
              uVar14 = *(undefined8 *)(&stack0x00000048 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x101a4a;
              func_0x(uVar14,uVar11,uVar29,uVar30);
              *(undefined8 *)(puVar38 + -8) = 0x101a57;
              func_0x(&stack0x00000358 + lVar22);
            }
            else {
              if (*(longlong *)(&stack0x00000148 + lVar22) == 0) {
                uVar35 = (ulonglong)(*(int *)(&stack0x00000060 + lVar22) * 0x10 + 0x18);
                uVar27 = uVar35 + 0xf;
                if (uVar27 <= uVar35) {
                  uVar27 = 0xffffffffffffff0;
                }
                uVar27 = uVar27 & 0xfffffffffffffff0;
                *(undefined8 *)(puVar38 + -8) = 0x101b1b;
                func_0x();
                lVar37 = -uVar27;
                *(undefined8 *)(puVar38 + lVar37 + -8) = 0x101b28;
                uVar29 = func_0x(puVar38 + lVar37 + 0x60);
                *(undefined8 *)(&stack0x00000148 + lVar22) = uVar29;
                uVar30 = *(undefined8 *)(&stack0x00000058 + lVar22);
                *(undefined8 *)(puVar38 + lVar37 + -8) = 0x101b3b;
                func_0x(uVar30,uVar29);
                puVar38 = puVar38 + lVar37;
              }
              *(undefined8 *)(puVar38 + -8) = 0x101b4c;
              func_0x(lVar32,3);
              ppbVar39 = ppbVar45;
              if (*(undefined8 **)(lVar32 + 0x30) != (undefined8 *)0x0) {
                ppbVar39 = (byte **)**(undefined8 **)(lVar32 + 0x30);
              }
              *(undefined4 *)(&stack0x000004b4 + lVar22) = 0;
              if (*(char *)((longlong)ppbVar39 + 2) < '\0') {
                ppbVar23 = ppbVar39 + 0xc;
                if (*(short *)(&stack0x00000480 + lVar22) == 0) {
                  *(undefined8 *)(&stack0x000001e0 + lVar22) = 0;
code_r0x00101bac:
                  *(undefined (*) [16])(&stack0x000004b8 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000004c8 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000004d8 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000004e8 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000004f8 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000508 + lVar22) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000518 + lVar22) = ZEXT816(0);
                  *(undefined8 *)(&stack0x00000528 + lVar22) = 0;
                  *(undefined (*) [16])(&stack0x000004b8 + lVar22) = ZEXT816(0);
                  *(undefined2 *)(&stack0x000004c8 + lVar22) = 0xffff;
                  *(undefined8 *)(&stack0x000004d0 + lVar22) = 0;
                  *(undefined4 *)(&stack0x000004cc + lVar22) = 0;
                  *(undefined8 *)(&stack0x000004e6 + lVar22) = 0;
                  *(undefined8 *)(&stack0x000004f0 + lVar22) = 0;
                  *(undefined8 *)(&stack0x000004d8 + lVar22) = 0;
                  *(undefined8 *)(&stack0x00000500 + lVar22) = 0;
                  *(undefined4 *)(&stack0x00000518 + lVar22) = 0;
                  *(undefined4 *)(&stack0x0000051c + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000520 + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000522 + lVar22) = 0;
                  *(undefined2 *)(&stack0x0000052a + lVar22) = 0;
                  ppbVar24 = (byte **)(&stack0x000004b8 + lVar22);
                  *(byte ***)(&stack0x000001e0 + lVar22) = ppbVar24;
                }
                else {
                  ppbVar24 = *(byte ***)(&stack0x00000490 + lVar22);
                  *(byte ***)(&stack0x000001e0 + lVar22) = ppbVar24;
                  if (ppbVar24 == (byte **)0x0) goto code_r0x00101bac;
                }
                uVar42 = 0xffff;
                (&stack0x0000003d)[lVar22] = 0;
                if (*(short *)((longlong)ppbVar39 + 0x24) == 0) {
code_r0x00101ccb:
                  *(byte **)(&stack0x00000168 + lVar22) = ppbVar39[5];
                  *(undefined2 *)(&stack0x00000170 + lVar22) = *(undefined2 *)(ppbVar39 + 6);
                }
                else {
                  cVar17 = *(char *)((longlong)ppbVar39 + 1);
                  uVar42 = 0xffff;
                  if (cVar17 != '\v') {
                    if (cVar17 == '\b') {
code_r0x00101c88:
                      if (*(int *)(ppbVar39 + 3) == 99) goto code_r0x00101c8e;
                    }
                    else {
code_r0x00101c84:
                      if (cVar17 == '\t') goto code_r0x00101c88;
                    }
code_r0x00101cc7:
                    (&stack0x0000003d)[lVar22] = 0;
                    goto code_r0x00101ccb;
                  }
                  if (*(int *)(ppbVar39 + 3) != 99) goto code_r0x00101c84;
code_r0x00101c8e:
                  *(undefined4 *)(&stack0x000001a4 + lVar22) = *(undefined4 *)(ppbVar39 + 4);
                  *(undefined2 *)(&stack0x000001a8 + lVar22) =
                       *(undefined2 *)((longlong)ppbVar39 + 0x24);
                  *(undefined8 *)(puVar38 + -8) = 0x101cae;
                  uVar42 = 0xffff;
                  cVar17 = func_0x(&stack0x000001a4 + lVar22);
                  if (cVar17 == '\0') goto code_r0x00101cc7;
                  (&stack0x0000003d)[lVar22] = 1;
                  *(undefined8 *)(puVar38 + -8) = 0x101cc5;
                  func_0x(ppbVar39,&stack0x00000168 + lVar22);
                }
                *ppbVar24 = (byte *)ppbVar23;
                uVar5 = *(undefined2 *)(&stack0x00000170 + lVar22);
                uVar30 = *(undefined8 *)(&stack0x00000168 + lVar22);
                *(undefined4 *)(ppbVar24 + 0xc) = *(undefined4 *)(&stack0x00000168 + lVar22);
                *(int *)((longlong)ppbVar24 + 100) = (int)((ulonglong)uVar30 >> 0x20);
                *(undefined2 *)(ppbVar24 + 0xd) = uVar5;
                *(undefined4 *)((longlong)ppbVar24 + 0x6c) = *(undefined4 *)(ppbVar39 + 4);
                *(undefined2 *)(ppbVar24 + 0xe) = *(undefined2 *)((longlong)ppbVar39 + 0x24);
                *(undefined2 *)((longlong)ppbVar24 + 0x72) = 0;
                bVar4 = *(byte *)ppbVar23;
                *(undefined4 *)(&stack0x00000210 + lVar22) =
                     *(undefined4 *)((ulonglong)bVar4 * 6 + 0x15d5960);
                uVar27 = (ulonglong)*(short *)((ulonglong)bVar4 * 6 + 0x15d5964);
                *(undefined2 *)(ppbVar24 + 2) = uVar42;
                ppbVar24[3] = (byte *)0x0;
                *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                ppbVar24[7] = (byte *)0x0;
                ppbVar24[4] = (byte *)0x0;
                ppbVar24[9] = (byte *)0x0;
                ppbVar24[10] = (byte *)0x0;
                *(undefined2 *)(ppbVar24 + 0xb) = 0;
                if ((**ppbVar24 & 2) != 0) {
                  pbVar41 = (byte *)((longlong)ppbVar23 + uVar27);
                  bVar4 = *pbVar41;
                  *(ushort *)(ppbVar24 + 2) = (ushort)(bVar4 & 1);
                  if ((bVar4 & 1) == 0) {
                    *(undefined4 *)(&stack0x000000b0 + lVar22) = 0;
                    ppbVar24[3] = pbVar41;
                    *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                    *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
                    uVar44 = uVar31;
                    switch(*pbVar41 & 0xe) {
                    default:
                      uVar19 = *(ushort *)(pbVar41 + 2);
                      uVar44 = (uint)uVar19;
                      *(uint *)(&stack0x000000b0 + lVar22) = (uint)uVar19;
                      if (uVar19 - 1 < 0x1f9e) goto code_r0x00101e48;
                      *(undefined8 *)(puVar38 + -8) = 0x101ddc;
                      func_0x(pbVar41,6);
                      *(uint *)(ppbVar24 + 4) = (uint)uVar19;
                      *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                      break;
                    case 4:
                      *(undefined4 *)(&stack0x000000b0 + lVar22) = 9;
                      *(undefined4 *)(ppbVar24 + 4) = 9;
                      *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                      break;
                    case 6:
                    case 10:
code_r0x00101e48:
                      *(uint *)(ppbVar24 + 4) = uVar44;
                      *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                      break;
                    case 0xe:
                      *(undefined4 *)(&stack0x000000b0 + lVar22) = 1;
                      *(undefined4 *)(ppbVar24 + 4) = 1;
                      *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                    }
                  }
                  else {
                    ppbVar24[3] = pbVar41;
                    bVar4 = *pbVar41;
                    switch(bVar4 & 0x1c) {
                    default:
                      if ((char)pbVar41[1] < '\0') {
                        uVar19 = *(ushort *)(pbVar41 + 1);
                        *(ushort *)((longlong)ppbVar24 + 0x12) = uVar19;
                        *(ushort *)((longlong)ppbVar24 + 0x12) = uVar19 >> 8 | (uVar19 & 0x7f) << 8;
                        *(undefined2 *)(ppbVar24 + 5) = 3;
                        sVar18 = 3;
                      }
                      else {
                        *(ushort *)((longlong)ppbVar24 + 0x12) = (ushort)pbVar41[1];
                        *(undefined2 *)(ppbVar24 + 5) = 2;
                        sVar18 = 2;
                      }
                      *(short *)((longlong)ppbVar24 + 0x2c) =
                           (short)(*(ushort *)((longlong)ppbVar24 + 0x12) + 1 >> 1) + sVar18;
                      if (*(ushort *)((longlong)ppbVar24 + 0x12) < 0x1f) {
                        *(undefined2 *)((longlong)ppbVar24 + 0x2a) = 0;
                        *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                        *(undefined4 *)(ppbVar24 + 8) = 0;
                      }
                      else {
                        iVar20 = *(ushort *)((longlong)ppbVar24 + 0x12) - 1;
                        *(short *)((longlong)ppbVar24 + 0x2a) =
                             ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                             (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                        *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                        *(undefined4 *)(ppbVar24 + 8) = 0;
                      }
                      break;
                    case 4:
                      uVar44 = uVar31;
                      if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
                        uVar44 = 1;
                      }
                      ppbVar24[3] = (byte *)0x0;
                      *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                      *(undefined2 *)(ppbVar24 + 5) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x2a) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x2c) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x2e) = 0;
                      *(undefined2 *)(ppbVar24 + 6) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x32) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x34) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x36) = 0;
                      ppbVar24[4] = (byte *)0x0;
                      *(undefined4 *)(ppbVar24 + 8) = 0;
                      ppbVar24[7] = (byte *)0x0;
                      ppbVar24[3] = pbVar41;
                      if (uVar44 == 0) {
                        *(undefined4 *)((longlong)ppbVar24 + 0x14) = 1;
                      }
                      else {
                        *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0xf;
                        *(undefined4 *)(ppbVar24 + 8) = 1;
                      }
                      break;
                    case 8:
                      ppbVar24[3] = (byte *)0x0;
                      *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                      *(undefined2 *)(ppbVar24 + 5) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x2a) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x2c) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x2e) = 0;
                      *(undefined2 *)(ppbVar24 + 6) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x32) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x34) = 0;
                      *(undefined2 *)((longlong)ppbVar24 + 0x36) = 0;
                      ppbVar24[4] = (byte *)0x0;
                      *(undefined4 *)(ppbVar24 + 8) = 0;
                      ppbVar24[7] = (byte *)0x0;
                      ppbVar24[3] = pbVar41;
                      *(undefined4 *)((longlong)ppbVar24 + 0x14) = 9;
                    }
                    ppbVar24[7] = (byte *)0x0;
                    ppbVar24[4] = (byte *)0x0;
                  }
                }
                if ((**ppbVar24 & 4) != 0) {
                  if (*(short *)(&stack0x00000212 + lVar22) != 0) {
                    uVar27 = (ulonglong)
                             *(ushort *)
                              ((longlong)ppbVar39 +
                              (longlong)*(short *)(&stack0x00000212 + lVar22) * 2 + 0x61);
                  }
                  psVar28 = (short *)((longlong)ppbVar23 + uVar27);
                  ppbVar24[9] = (byte *)psVar28;
                  sVar18 = *psVar28;
                  ppbVar24[10] = (byte *)(psVar28 + 1);
                  *(short *)(ppbVar24 + 0xb) = (sVar18 + 1) * 2;
                }
                pbVar41 = ppbVar24[1];
                if (pbVar41 != (byte *)0x0) {
                  *(undefined8 *)(puVar38 + -8) = 0x102056;
                  func_0x(pbVar41,ppbVar24);
                }
                cVar17 = *pcVar3;
                cVar43 = (&stack0x00000030)[lVar22];
              }
              else {
                *(undefined8 *)(&stack0x000001e0 + lVar22) = 0;
                ppbVar24 = ppbVar45;
              }
              uVar19 = *(ushort *)((longlong)ppbVar39 + 0xe);
              uVar44 = (uint)uVar19;
              pbVar41 = (byte *)((ulonglong)*(ushort *)((longlong)ppbVar39 + 0x1ffe) +
                                (longlong)ppbVar39);
              if ((*pbVar41 & 1) == 0) {
                *(undefined2 *)(&stack0x00000480 + lVar22) = 0;
                *(uint *)(&stack0x000000b8 + lVar22) = (uint)uVar19;
                *(byte **)(&stack0x00000488 + lVar22) = pbVar41;
                *(undefined4 *)(&stack0x00000484 + lVar22) = 0;
                *(undefined4 *)(&stack0x000004a6 + lVar22) = 0;
                switch(*pbVar41 & 0xe) {
                default:
                  uVar19 = *(ushort *)(pbVar41 + 2);
                  uVar44 = (uint)uVar19;
                  *(uint *)(&stack0x000000b8 + lVar22) = (uint)uVar19;
                  if (0x1f9d < uVar19 - 1) {
                    *(undefined8 *)(puVar38 + -8) = 0x102423;
                    func_0x(pbVar41,6);
                  }
                  break;
                case 4:
                  uVar44 = 9;
                  *(undefined4 *)(&stack0x000000b8 + lVar22) = 9;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar44 = 1;
                  *(undefined4 *)(&stack0x000000b8 + lVar22) = 1;
                }
                *(uint *)(&stack0x00000490 + lVar22) = uVar44;
                *(byte ***)(&stack0x0000049e + lVar22) = ppbVar39 + 0x400;
              }
              else {
                *(undefined2 *)(&stack0x00000480 + lVar22) = 1;
                *(byte **)(&stack0x00000488 + lVar22) = pbVar41;
                bVar4 = *pbVar41;
                switch(bVar4 & 0x1c) {
                default:
                  uVar19 = (ushort)pbVar41[1];
                  if ((char)pbVar41[1] < '\0') {
                    uVar19 = *(ushort *)(pbVar41 + 1);
                    *(ushort *)(&stack0x00000482 + lVar22) = uVar19;
                    uVar19 = uVar19 >> 8 | (uVar19 & 0x7f) << 8;
                    sVar18 = 3;
                  }
                  else {
                    sVar18 = 2;
                  }
                  *(ushort *)(&stack0x00000482 + lVar22) = uVar19;
                  *(short *)(&stack0x00000498 + lVar22) = sVar18;
                  *(short *)(&stack0x0000049c + lVar22) = (short)(uVar19 + 1 >> 1) + sVar18;
                  if (uVar19 < 0x1f) {
                    *(undefined2 *)(&stack0x0000049a + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000484 + lVar22) = 0;
                    *(undefined4 *)(&stack0x000004b0 + lVar22) = 0;
                    *(byte ***)(&stack0x000004a8 + lVar22) = ppbVar39 + 0x400;
                    *(byte ***)(&stack0x00000490 + lVar22) = ppbVar24;
                  }
                  else {
                    iVar20 = uVar19 - 1;
                    *(short *)(&stack0x0000049a + lVar22) =
                         ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                         (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                    *(undefined4 *)(&stack0x00000484 + lVar22) = 0;
                    *(undefined4 *)(&stack0x000004b0 + lVar22) = 0;
                    *(byte ***)(&stack0x000004a8 + lVar22) = ppbVar39 + 0x400;
                    *(byte ***)(&stack0x00000490 + lVar22) = ppbVar24;
                  }
                  break;
                case 4:
                  if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
                    *(undefined8 *)(&stack0x00000488 + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000484 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000498 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000482 + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000049a + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000049c + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000049e + lVar22) = 0;
                    *(undefined2 *)(&stack0x000004a0 + lVar22) = 0;
                    *(undefined2 *)(&stack0x000004a2 + lVar22) = 0;
                    *(undefined2 *)(&stack0x000004a4 + lVar22) = 0;
                    *(undefined2 *)(&stack0x000004a6 + lVar22) = 0;
                    *(undefined8 *)(&stack0x00000490 + lVar22) = 0;
                    *(undefined4 *)(&stack0x000004b0 + lVar22) = 0;
                    *(undefined8 *)(&stack0x000004a8 + lVar22) = 0;
                    *(byte **)(&stack0x00000488 + lVar22) = pbVar41;
                    *(undefined4 *)(&stack0x00000484 + lVar22) = 0xf;
                    *(undefined4 *)(&stack0x000004b0 + lVar22) = 0;
                    *(undefined4 *)(&stack0x000004b0 + lVar22) = 1;
                    *(byte ***)(&stack0x000004a8 + lVar22) = ppbVar39 + 0x400;
                    *(byte ***)(&stack0x00000490 + lVar22) = ppbVar24;
                  }
                  else {
                    *(undefined8 *)(&stack0x00000488 + lVar22) = 0;
                    *(undefined4 *)(&stack0x00000484 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000498 + lVar22) = 0;
                    *(undefined2 *)(&stack0x00000482 + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000049a + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000049c + lVar22) = 0;
                    *(undefined2 *)(&stack0x0000049e + lVar22) = 0;
                    *(undefined2 *)(&stack0x000004a0 + lVar22) = 0;
                    *(undefined2 *)(&stack0x000004a2 + lVar22) = 0;
                    *(undefined2 *)(&stack0x000004a4 + lVar22) = 0;
                    *(undefined2 *)(&stack0x000004a6 + lVar22) = 0;
                    *(undefined8 *)(&stack0x00000490 + lVar22) = 0;
                    *(undefined4 *)(&stack0x000004b0 + lVar22) = 0;
                    *(undefined8 *)(&stack0x000004a8 + lVar22) = 0;
                    *(byte **)(&stack0x00000488 + lVar22) = pbVar41;
                    *(undefined4 *)(&stack0x00000484 + lVar22) = 1;
                    *(undefined4 *)(&stack0x000004b0 + lVar22) = 0;
                    *(byte ***)(&stack0x000004a8 + lVar22) = ppbVar39 + 0x400;
                    *(byte ***)(&stack0x00000490 + lVar22) = ppbVar24;
                  }
                  break;
                case 8:
                  *(undefined8 *)(&stack0x00000488 + lVar22) = 0;
                  *(undefined4 *)(&stack0x00000484 + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000498 + lVar22) = 0;
                  *(undefined2 *)(&stack0x00000482 + lVar22) = 0;
                  *(undefined2 *)(&stack0x0000049a + lVar22) = 0;
                  *(undefined2 *)(&stack0x0000049c + lVar22) = 0;
                  *(undefined2 *)(&stack0x0000049e + lVar22) = 0;
                  *(undefined2 *)(&stack0x000004a0 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000004a2 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000004a4 + lVar22) = 0;
                  *(undefined2 *)(&stack0x000004a6 + lVar22) = 0;
                  *(undefined8 *)(&stack0x00000490 + lVar22) = 0;
                  *(undefined4 *)(&stack0x000004b0 + lVar22) = 0;
                  *(undefined8 *)(&stack0x000004a8 + lVar22) = 0;
                  *(byte **)(&stack0x00000488 + lVar22) = pbVar41;
                  *(undefined4 *)(&stack0x00000484 + lVar22) = 9;
                  *(undefined4 *)(&stack0x000004b0 + lVar22) = 0;
                  *(byte ***)(&stack0x000004a8 + lVar22) = ppbVar39 + 0x400;
                  *(byte ***)(&stack0x00000490 + lVar22) = ppbVar24;
                }
              }
              *(undefined4 *)(puVar38 + 0x30) = 0;
              *(undefined **)(puVar38 + 0x28) = &stack0x000005e0 + lVar22;
              *(undefined4 *)(puVar38 + 0x20) = 0xa58;
              uVar30 = *(undefined8 *)(&stack0x00000148 + lVar22);
              uVar29 = *(undefined8 *)(&stack0x00000058 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x1024b9;
              func_0x(uVar29,&stack0x00000480 + lVar22,0,uVar30);
              *(undefined8 *)(puVar38 + -8) = 0x1024c1;
              func_0x(lVar32);
              *(undefined8 *)(&stack0x00000310 + lVar22) = 0;
              if ((cVar17 == '\0') || (uVar30 = uRam00000000014569d8, cVar43 == '\0')) {
                uVar30 = uRam00000000014557f0;
              }
              *(undefined8 *)(puVar38 + 0x28) = 0;
              *(undefined8 *)(puVar38 + 0x20) = uVar30;
              *(undefined8 *)(puVar38 + -8) = 0x102501;
              func_0x(&stack0x00000380 + lVar22,0xb,0,0);
              lVar37 = *(longlong *)(*(longlong *)(&stack0x00000050 + lVar22) + 0x418);
              puVar36 = (undefined4 *)(lVar37 + 4);
              *(int *)(&stack0x00000228 + lVar22) = _DAT_;
              *(int *)(&stack0x0000022c + lVar22) = iRam0000000001ef940c;
              *(int *)(&stack0x00000230 + lVar22) = _DAT_;
              *(int *)(&stack0x00000234 + lVar22) = iRam0000000001ef9414;
              *(undefined4 *)(&stack0x000000d0 + lVar22) = *puVar36;
              *(undefined2 *)(&stack0x000000d4 + lVar22) = *(undefined2 *)(lVar37 + 8);
              lVar32 = *(longlong *)(&stack0x00000050 + lVar22) + 0x340;
              *(undefined4 **)(puVar38 + 0x48) = puVar36;
              *(undefined **)(puVar38 + 0x40) = &stack0x00000228 + lVar22;
              puVar38[0x38] = 0;
              *(longlong *)(puVar38 + 0x30) = lVar32;
              *(undefined **)(puVar38 + 0x28) = &stack0x000000d0 + lVar22;
              *(undefined8 *)(puVar38 + 0x20) = *(undefined8 *)(&stack0x00000148 + lVar22);
              uVar30 = *(undefined8 *)(&stack0x000000f8 + lVar22);
              uVar11 = *(undefined8 *)(&stack0x00000028 + lVar22);
              uVar14 = *(undefined8 *)(&stack0x00000048 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x10258c;
              func_0x(uVar14,uVar29,uVar11,uVar30);
              *(undefined4 *)(&stack0x000000d0 + lVar22) = *puVar36;
              *(undefined2 *)(&stack0x000000d4 + lVar22) = *(undefined2 *)(lVar37 + 8);
              *(undefined4 **)(puVar38 + 0x48) = puVar36;
              *(undefined **)(puVar38 + 0x40) = &stack0x00000228 + lVar22;
              puVar38[0x38] = 0;
              *(longlong *)(puVar38 + 0x30) = lVar32;
              *(undefined **)(puVar38 + 0x28) = &stack0x000000d0 + lVar22;
              *(undefined8 *)(puVar38 + 0x20) = *(undefined8 *)(&stack0x00000110 + lVar22);
              *(undefined8 *)(puVar38 + -8) = 0x1025e3;
              func_0x(uVar14,uVar29,uVar11,uVar30);
              *(undefined8 *)(puVar38 + -8) = 0x1025f0;
              func_0x(&stack0x00000380 + lVar22);
            }
            lVar37 = (ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
            lVar32 = *(longlong *)(lVar37 + 0x100);
            if (lVar32 == 0) {
              *(undefined8 *)(puVar38 + -8) = 0x101aa0;
              (*_DAT_)();
              lVar32 = *(longlong *)(lVar37 + 0x100);
            }
            if (*(int *)(lVar32 + 0x22c) != 0) {
              *(undefined8 *)(puVar38 + -8) = 0x101ab6;
              (*_DAT_)();
            }
            *(longlong *)(&stack0x000001c0 + lVar22) = *(longlong *)(&stack0x000001c0 + lVar22) + 1;
            lVar32 = *(longlong *)(&stack0x00000088 + lVar22);
            lVar37 = *(longlong *)(&stack0x00000090 + lVar22);
            ppbVar39 = *(byte ***)(&stack0x00000130 + lVar22);
            ppbVar23 = *(byte ***)(&stack0x00000080 + lVar22);
          }
          param_1 = *(longlong *)(&stack0x00000050 + lVar22);
          plVar34 = *(longlong **)(&stack0x00000040 + lVar22);
          goto LAB_;
        }
        *(undefined8 *)(puVar38 + -8) = 0x100d4d;
        func_0x(lVar32);
        acStackX_20[lVar22 + 1] = '\x01';
LAB_:
        param_1 = *(longlong *)(&stack0x00000050 + lVar22);
      } while( true );
    }
    pbVar41 = ppbVar23[2];
    if (*(int *)(pbVar41 + 8) == 0) {
      if ((*(byte *)(ppbVar23 + 3) & 1) != 0) {
        *(undefined8 *)(pbVar41 + 0x10) = *(undefined8 *)(param_1 + 0x370);
        *(undefined4 *)(pbVar41 + 4) = 2;
        *(uint *)(ppbVar23 + 3) = *(uint *)(ppbVar23 + 3) & 0xfffffffe;
        pbVar41 = ppbVar23[2];
      }
      *(int *)(pbVar41 + 8) = *(int *)(pbVar41 + 8) + 1;
      pbVar41 = ppbVar23[2];
      goto LAB_;
    }
    ppbVar24 = ppbVar23 + 1;
    ppbVar23 = (byte **)*ppbVar24;
    if ((byte **)*ppbVar24 == ppbVar39) {
      ppbVar23 = ppbVar45;
    }
  } while( true );
code_r0x001006ad:
  plVar34 = *(longlong **)(&stack0x00000040 + lVar22);
  if (*plVar34 != 0) {
LAB_:
    if (*(int *)(&stack0x00000074 + lVar22) != 0) {
      lVar32 = *(longlong *)(param_1 + 0x418);
      uVar30 = *(undefined8 *)(&stack0x00000110 + lVar22);
      uVar29 = *(undefined8 *)(lVar32 + 0x10);
      *(undefined8 *)(puVar38 + -8) = 0x100aa7;
      func_0x(uVar29,uVar30,lVar32 + 0x20,0xa58);
      **(undefined8 **)(&stack0x00000040 + lVar22) = *(undefined8 *)(param_1 + 0x418);
    }
    if (*(int *)(&stack0x00000120 + lVar22) == 0) {
      if (*(int *)(&stack0x000010b0 + lVar22) != 0) {
        plVar34 = (longlong *)(*(longlong *)(param_1 + 0x418) + 0xa78);
        *plVar34 = *plVar34 - *(longlong *)(&stack0x00000150 + lVar22);
      }
    }
    else {
      *(longlong *)(*(longlong *)(param_1 + 0x418) + 0xa78) =
           (longlong)*(int *)(*(longlong *)(&stack0x00000078 + lVar22) + 0x48);
    }
LAB_:
    if (ppbVar23 != (byte **)0x0) {
      *(undefined8 *)(puVar38 + -8) = 0x100b01;
      func_0x(ppbVar23);
      *(undefined8 *)(puVar38 + -8) = 0x100b0c;
      func_0x(ppbVar23,1);
      *(undefined8 *)(&stack0x00000080 + lVar22) = 0;
    }
    uVar30 = *(undefined8 *)(&stack0x00000078 + lVar22);
    uVar29 = *(undefined8 *)(&stack0x00000028 + lVar22);
    *(undefined8 *)(puVar38 + -8) = 0x100b1d;
    func_0x(uVar29,uVar30);
    *(undefined8 *)(&stack0x00000078 + lVar22) = 0;
    uVar30 = *(undefined8 *)(&stack0x000001c0 + lVar22);
    uVar29 = *(undefined8 *)(&stack0x00000150 + lVar22);
    lVar37 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar32 = *(longlong *)(lVar37 + 0x100);
    if (lVar32 == 0) {
      *(undefined8 *)(puVar38 + -8) = 0x103163;
      (*_DAT_)();
      lVar32 = *(longlong *)(lVar37 + 0x100);
    }
    if (*(int *)(lVar32 + 0x22c) != 0) {
      *(undefined8 *)(puVar38 + -8) = 0x103179;
      (*_DAT_)();
    }
    **(undefined8 **)(&stack0x00000240 + lVar22) = uVar29;
    **(undefined8 **)(&stack0x00000248 + lVar22) = uVar30;
    piVar33 = *(int **)(&stack0x00000090 + lVar22);
    if (piVar33 != (int *)0x0) {
      piVar2 = piVar33 + 2;
      *piVar2 = *piVar2 + -1;
      if (*piVar2 == 0) {
        if (*piVar33 == 1) {
          *(undefined8 *)(puVar38 + -8) = 0x1031ac;
          func_0x(piVar33,1);
        }
        else if ((piVar33[1] & 4U) != 0) {
          if ((piVar33[1] & 0x10U) == 0) {
            lVar32 = *(longlong *)(piVar33 + 0x12);
            if ((lVar32 != CONCAT44(iRam0000000001ef940c,_DAT_)) ||
               (*(longlong *)(piVar33 + 0x14) != CONCAT44(iRam0000000001ef9414,_DAT_))) {
              *(undefined4 *)(lVar32 + 0x48) = 0;
              *(undefined8 *)(lVar32 + 0x50) = 0;
              *(undefined *)((longlong)piVar33 + 0x3e) = 0;
              *(undefined8 *)(piVar33 + 0xc) = 0;
              *(undefined2 *)(piVar33 + 0xf) = 0;
            }
            iVar16 = iRam0000000001ef9414;
            iVar8 = _DAT_;
            iVar20 = iRam0000000001ef940c;
            piVar33[0x12] = _DAT_;
            piVar33[0x13] = iVar20;
            piVar33[0x14] = iVar8;
            piVar33[0x15] = iVar16;
            *(undefined8 *)(piVar33 + 0x16) = 0;
          }
          uVar30 = *(undefined8 *)(*(longlong *)(piVar33 + 6) + 0x10);
          *(undefined8 *)(puVar38 + -8) = 0x103208;
          func_0x(uVar30,piVar33 + 8);
          piVar33[1] = piVar33[1] & 0xffffff6b;
        }
      }
    }
    piVar33 = *(int **)(&stack0x00000088 + lVar22);
    if (piVar33 != (int *)0x0) {
      piVar2 = piVar33 + 2;
      *piVar2 = *piVar2 + -1;
      if (*piVar2 == 0) {
        if (*piVar33 == 1) {
          *(undefined8 *)(puVar38 + -8) = 0x10322e;
          func_0x(piVar33,1);
        }
        else if ((piVar33[1] & 4U) != 0) {
          if ((piVar33[1] & 0x10U) == 0) {
            lVar32 = *(longlong *)(piVar33 + 0x12);
            if ((lVar32 != CONCAT44(iRam0000000001ef940c,_DAT_)) ||
               (*(longlong *)(piVar33 + 0x14) != CONCAT44(iRam0000000001ef9414,_DAT_))) {
              *(undefined4 *)(lVar32 + 0x48) = 0;
              *(undefined8 *)(lVar32 + 0x50) = 0;
              *(undefined *)((longlong)piVar33 + 0x3e) = 0;
              *(undefined8 *)(piVar33 + 0xc) = 0;
              *(undefined2 *)(piVar33 + 0xf) = 0;
            }
            iVar16 = iRam0000000001ef9414;
            iVar8 = _DAT_;
            iVar20 = iRam0000000001ef940c;
            piVar33[0x12] = _DAT_;
            piVar33[0x13] = iVar20;
            piVar33[0x14] = iVar8;
            piVar33[0x15] = iVar16;
            *(undefined8 *)(piVar33 + 0x16) = 0;
          }
          uVar30 = *(undefined8 *)(*(longlong *)(piVar33 + 6) + 0x10);
          *(undefined8 *)(puVar38 + -8) = 0x10328a;
          func_0x(uVar30,piVar33 + 8);
          piVar33[1] = piVar33[1] & 0xffffff6b;
        }
      }
    }
    uVar27 = *(ulonglong *)(&stack0x00001040 + lVar22);
    *(undefined8 *)(puVar38 + -8) = 0x1032a0;
    func_0x(uVar27 ^ (ulonglong)pcVar3);
    return;
  }
  goto LAB_;
}

