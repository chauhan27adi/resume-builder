
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_(short *param_1,longlong param_2,uint param_3,int *param_4,uint *param_5)

{
  ushort *puVar1;
  byte bVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint *puVar6;
  ulonglong *puVar7;
  int *piVar8;
  uint uVar9;
  longlong lVar10;
  ushort uVar11;
  short sVar12;
  ulonglong uVar13;
  uint uVar14;
  undefined8 uVar15;
  longlong lVar16;
  byte *pbVar17;
  ushort uVar18;
  ushort *puVar19;
  longlong unaff_GS_OFFSET;
  undefined auStackX_8 [8];
  uint uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  
  puVar1 = (ushort *)(param_1 + 1);
  uVar15 = 0;
  iVar5 = 0;
  uStack_48 = 0;
  *param_5 = 0;
  *param_4 = 0;
  uStack_44 = (uint)(uStack_44._2_2_ & 0xffe0) << 0x10;
  piStack_40 = (int *)0x0;
  if (*param_1 == 0) {
    uVar3 = func_0x(puVar1);
  }
  else {
    uVar3 = (uint)*puVar1;
  }
  uVar14 = 0;
  if ((int)uVar3 <= (int)param_3) {
    param_3 = param_3 - uVar3;
    iVar5 = func_0x(param_1);
    if (iVar5 <= (int)param_3) {
      (*_DAT_)(0x19,0,0x19,0);
      return (int *)0x0;
    }
    if (*(int *)(param_1 + 2) == 0) {
      pbVar17 = *(byte **)(param_1 + 4);
      uVar3 = *(uint *)(param_1 + 8);
      uVar13 = (ulonglong)uVar3;
      *puVar1 = 0;
      *(uint *)(param_1 + 10) = uVar3;
      bVar2 = *pbVar17;
      if ((bVar2 & 0x10) != 0) {
        uVar3 = uVar3 + 2 + (*(ushort *)(pbVar17 + uVar13) + 7 >> 3);
        uVar13 = (ulonglong)uVar3;
        *(uint *)(param_1 + 10) = uVar3;
        bVar2 = *pbVar17;
      }
      if ((bVar2 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar13;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar13;
      }
      else {
        puVar19 = (ushort *)(pbVar17 + uVar13);
        uVar18 = *puVar19;
        param_1[0xe] = uVar18;
        if (uVar18 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar16 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar16 != 0)) &&
             ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
              (*(char *)(lVar16 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xd38bf8,0xe588c8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar18 = param_1[0xe];
          uVar13 = (ulonglong)*(uint *)(param_1 + 10);
        }
        uVar3 = (int)uVar13 + (uVar18 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar3;
        if (0x1f9e < uVar3) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar16 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar16 != 0 &&
              ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
               (*(char *)(lVar16 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xd38bf8,0xe588c8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar18 = param_1[0xe];
          uVar3 = *(uint *)(param_1 + 0xc);
        }
        uVar13 = (ulonglong)uVar18;
        uVar18 = puVar19[uVar13];
        *(uint *)(param_1 + 2) = uVar18 & 0x7fff;
        if ((uVar18 & 0x7fff) < uVar3) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar16 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar16 != 0)) &&
             ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
              (*(char *)(lVar16 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xd38bf8,0xe588c8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar13 = (ulonglong)(ushort)param_1[0xe];
        }
        if ((short)puVar19[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
          lVar16 = *(longlong *)(param_1 + 4);
          do {
            if ((int)uVar13 == 1) {
              uVar3 = *(uint *)(param_1 + 0xc);
              uVar9 = uVar3;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar16 + uVar13 * 2) & 0x7fff) <
                  uVar3) goto LAB_;
            }
            else {
              uVar9 = *(uint *)(param_1 + 0xc);
              uVar3 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar16 + -2 + uVar13 * 2) &
                      0x7fff;
              if (uVar9 <= uVar3) goto LAB_;
LAB_:
              func_0x(lVar16,7);
              uVar9 = *(uint *)(param_1 + 0xc);
            }
            if ((uVar3 < uVar9) || (*(uint *)(param_1 + 2) < uVar3)) goto LAB_;
            lVar16 = *(longlong *)(param_1 + 4);
            if (*(ushort *)(lVar16 + (ulonglong)uVar3) == 5) {
              *puVar1 = *puVar1 | 2;
              param_1[0xe] = param_1[0xe] + -1;
              param_1[0x15] = (short)uVar3;
              lVar16 = (ulonglong)(uVar3 & 0xffff) + *(longlong *)(param_1 + 4);
              uVar18 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar16 + 2) & 0x4000) != 0) {
                uVar18 = *(ushort *)(lVar16 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar18;
              param_1[0x16] = (uVar18 ^ *(ushort *)(lVar16 + 2)) & 0x7ff ^ uVar18;
              uVar13 = (ulonglong)*(uint *)(param_1 + 2);
              pbVar17 = *(byte **)(param_1 + 4);
              goto LAB_;
            }
            if (*(ushort *)(lVar16 + (ulonglong)uVar3) < 0x400) break;
            *puVar1 = *puVar1 | 1;
            uVar18 = param_1[0xe] - 1;
            param_1[0xe] = uVar18;
            if ((uVar18 == 0) ||
               (uVar13 = (ulonglong)uVar18, -1 < (short)puVar19[(ulonglong)(uVar18 - 1) + 1]))
            break;
          } while( true );
        }
        uVar13 = (ulonglong)*(uint *)(param_1 + 2);
        pbVar17 = *(byte **)(param_1 + 4);
      }
LAB_:
      if ((*pbVar17 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar13;
        *(int *)(param_1 + 2) = (int)uVar13 + 0xe;
        puVar7 = (ulonglong *)func_0x(puVar1);
        uVar13 = *puVar7;
        uVar11 = (ushort)(uVar13 >> 0x30);
        uVar18 = uVar11;
        if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
          uVar18 = uVar11 & 0xdfff;
          if ((uVar13 & 0x4000000000000000) != 0) {
            uVar18 = uVar11 | 0x2000;
          }
        }
        if (uVar18 == 0xfffc) {
          uVar14 = (uint)((uVar13 >> 0x20 & 0xffff) >> 5);
        }
        *(uint *)(param_1 + 2) = *(int *)(param_1 + 2) + uVar14;
        uVar13 = (ulonglong)*(uint *)(param_1 + 2);
      }
      iVar5 = (int)uVar13;
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar13 + *(longlong *)(param_1 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar16 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar16 != 0 &&
             (lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0)) &&
            (*(char *)(lVar16 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xd38bf8,0xe588c8,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        iVar5 = *(int *)(param_1 + 2);
      }
      if (0x3f3b < iVar5 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar16 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar16 != 0 &&
            ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
             (*(char *)(lVar16 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            func_0x(*(undefined8 *)(param_1 + 4),5);
            goto LAB_;
          }
          (*_DAT_)(1,0xd38bf8,0xe588c8,0x87c,0);
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
      }
    }
LAB_:
    iVar5 = func_0x(puVar1);
    if (iVar5 == 0) {
      iVar5 = func_0x(puVar1);
      if (iVar5 != 0) {
        return (int *)0x0;
      }
      (*_DAT_)(1,0xef4278,0xee5368,0xd67,0);
      return (int *)0x0;
    }
    if ((-1 < (int)param_3) && ((int)param_3 < (int)((ushort)param_1[0x16] & 0x7ff))) {
      lVar16 = *(longlong *)(param_1 + 4);
      uVar18 = param_1[0x15];
      uVar14 = (ushort)param_1[0x16] >> 0xb & 7;
      uVar3 = ((ushort)param_1[0x16] & 0x7ff) * 2;
      lVar10 = (ulonglong)(uVar14 * 2) + lVar16 + (ulonglong)uVar3 + (ulonglong)uVar18;
      if (param_3 == 0) {
        uVar3 = (uVar14 + uVar3) * 2 + 4;
      }
      else {
        uVar3 = *(ushort *)(lVar10 + 2 + (longlong)(int)param_3 * 2) & 0x7fff;
      }
      *param_4 = (*(ushort *)(lVar10 + 4 + (longlong)(int)param_3 * 2) & 0x7fff) - uVar3;
      *param_5 = (uint)(*(ushort *)(lVar10 + 4 + (ulonglong)param_3 * 2) >> 0xf);
      return (int *)((ulonglong)uVar3 + lVar16 + (ulonglong)uVar18);
    }
    (*_DAT_)(1,0xef4248,0xef4290,0x3c6,0);
    return (int *)0x0;
  }
  uVar3 = ~param_3;
  if ((int)param_3 < 0) {
LAB_:
    func_0x(param_2,uVar3,&uStack_48);
  }
  else {
    if ((uVar3 & 0xc0000000) == 0x80000000) {
      puVar6 = (uint *)func_0x
                                 (**(undefined8 **)(*(longlong *)(param_2 + 8) + 0x160),
                                  uVar3 & 0x1fffffff);
    }
    else {
      puVar6 = (uint *)func_0x(*(undefined8 *)(*(longlong *)(param_2 + 8) + 0x160));
    }
    if (puVar6 == (uint *)0x0) goto LAB_;
    uStack_48 = *puVar6;
    uStack_44 = puVar6[1];
    piStack_40 = *(int **)(puVar6 + 2);
  }
  iVar4 = func_0x(param_1,&uStack_48);
  if (iVar4 == 0) {
    return (int *)0x0;
  }
  *param_5 = 1;
  if (*param_1 != 0) {
    piVar8 = (int *)func_0x(puVar1,&uStack_48);
    if (*param_1 == 0) {
      return piVar8;
    }
    if (*(longlong *)(param_1 + 8) == 0) {
      return piVar8;
    }
    if (**(longlong **)(param_1 + 8) == 0) {
      return piVar8;
    }
    if ((uStack_44 & 0x80000) != 0) {
      return piVar8;
    }
    if (*param_1 != 0) {
      uVar15 = *(undefined8 *)(param_1 + 8);
    }
    if ((piVar8 != (int *)0x0) && (piVar8 != (int *)0xabd634)) {
      piVar8 = (int *)func_0x(uVar15,&uStack_48,piVar8,*param_4,0,0,param_4,0);
      return piVar8;
    }
    *param_4 = 0;
    return (int *)0x0;
  }
  if ((uStack_48 & 0xc0000000) == 0x80000000) {
    iVar5 = func_0x(puVar1);
    if (iVar5 != 0) {
      piVar8 = (int *)func_0x(param_1 + 0x15,&uStack_48,param_4,auStackX_8);
      return piVar8;
    }
    *param_4 = 0;
    return (int *)0x0;
  }
  uVar18 = uStack_44._2_2_ >> 4 & 1;
  if (uVar18 != 0) {
    bVar2 = **(byte **)(param_1 + 4);
    if ((bVar2 & 0x10) == 0) {
      if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
        *param_4 = *piStack_40;
        return piStack_40 + 1;
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_48) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < (ushort)uStack_44))
    goto LAB_;
  }
  if (-1 < (int)uStack_48) {
    if ((uStack_44 & 0x80000) != 0) {
      bVar2 = *(byte *)((longlong)(int)uStack_48 + *(longlong *)(param_1 + 4));
      *param_4 = 1;
      if ((bVar2 & (byte)(1 << (uStack_44._2_1_ & 7))) != 0) {
        return (int *)0xabd634;
      }
      return (int *)0xabdc58;
    }
    if (uVar18 != 0) {
      bVar2 = **(byte **)(param_1 + 4);
      if ((bVar2 & 0x10) == 0) {
        if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
LAB_:
          iVar5 = *piStack_40;
          piVar8 = piStack_40 + 1;
          if (iVar5 != 0x1f9e) {
            (*_DAT_)(1,0xee6968,0xee5368,0x381,0);
          }
          *param_4 = iVar5;
          return piVar8;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_48) ||
              (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < (ushort)uStack_44))
      goto LAB_;
    }
    *param_4 = 0x1f9e;
    return (int *)((longlong)(int)uStack_48 + *(longlong *)(param_1 + 4));
  }
  if (*(int *)(param_1 + 2) == 0) {
    pbVar17 = *(byte **)(param_1 + 4);
    uVar3 = *(uint *)(param_1 + 8);
    uVar13 = (ulonglong)uVar3;
    *puVar1 = 0;
    *(uint *)(param_1 + 10) = uVar3;
    bVar2 = *pbVar17;
    if ((bVar2 & 0x10) != 0) {
      uVar3 = uVar3 + 2 + (*(ushort *)(pbVar17 + uVar13) + 7 >> 3);
      uVar13 = (ulonglong)uVar3;
      *(uint *)(param_1 + 10) = uVar3;
      bVar2 = *pbVar17;
    }
    iVar4 = (int)uVar13;
    if ((bVar2 & 0x20) == 0) {
      *(int *)(param_1 + 2) = iVar4;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = iVar4;
    }
    else {
      puVar19 = (ushort *)(pbVar17 + uVar13);
      uVar18 = *puVar19;
      param_1[0xe] = uVar18;
      if (uVar18 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar16 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar16 != 0)) &&
           ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
            (*(char *)(lVar16 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xd38bf8,0xe588c8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar18 = param_1[0xe];
        iVar4 = *(int *)(param_1 + 10);
      }
      uVar3 = iVar4 + (uVar18 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar3;
      if (0x1f9e < uVar3) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar16 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar16 != 0 &&
            ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
             (*(char *)(lVar16 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xd38bf8,0xe588c8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar18 = param_1[0xe];
        uVar3 = *(uint *)(param_1 + 0xc);
      }
      uVar11 = puVar19[uVar18];
      *(uint *)(param_1 + 2) = uVar11 & 0x7fff;
      if ((uVar11 & 0x7fff) < uVar3) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar16 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar16 != 0)) &&
           ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
            (*(char *)(lVar16 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xd38bf8,0xe588c8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar18 = param_1[0xe];
      }
      if ((short)puVar19[(ulonglong)(uVar18 - 1) + 1] < 0) {
        lVar16 = *(longlong *)(param_1 + 4);
        do {
          if (uVar18 == 1) {
            uVar3 = *(uint *)(param_1 + 0xc);
            uVar9 = uVar3;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar16 + (ulonglong)uVar18 * 2) &
                0x7fff) < uVar3) goto LAB_;
          }
          else {
            uVar9 = *(uint *)(param_1 + 0xc);
            uVar3 = *(ushort *)
                     ((ulonglong)*(uint *)(param_1 + 10) + lVar16 + -2 + (ulonglong)uVar18 * 2) &
                    0x7fff;
            if (uVar9 <= uVar3) goto LAB_;
LAB_:
            func_0x(lVar16,7);
            uVar9 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar3 < uVar9) || (*(uint *)(param_1 + 2) < uVar3)) goto LAB_;
          lVar16 = *(longlong *)(param_1 + 4);
          if (*(ushort *)((ulonglong)uVar3 + lVar16) == 5) {
            *puVar1 = *puVar1 | 2;
            param_1[0xe] = param_1[0xe] + -1;
            param_1[0x15] = (short)uVar3;
            lVar16 = (ulonglong)(uVar3 & 0xffff) + *(longlong *)(param_1 + 4);
            uVar18 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar16 + 2) & 0x4000) != 0) {
              uVar18 = *(ushort *)(lVar16 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar18;
            param_1[0x16] = (uVar18 ^ *(ushort *)(lVar16 + 2)) & 0x7ff ^ uVar18;
            break;
          }
          if (*(ushort *)((ulonglong)uVar3 + lVar16) < 0x400) break;
          *puVar1 = *puVar1 | 1;
          uVar18 = param_1[0xe] - 1;
          param_1[0xe] = uVar18;
          if ((uVar18 == 0) || (-1 < (short)puVar19[(ulonglong)(uVar18 - 1) + 1])) break;
        } while( true );
      }
    }
    if ((**(byte **)(param_1 + 4) & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = *(int *)(param_1 + 2);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + 0xe;
      puVar7 = (ulonglong *)func_0x(puVar1);
      uVar13 = *puVar7;
      uVar11 = (ushort)(uVar13 >> 0x30);
      uVar18 = uVar11;
      if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
        uVar18 = uVar11 & 0xdfff;
        if ((uVar13 & 0x4000000000000000) != 0) {
          uVar18 = uVar11 | 0x2000;
        }
      }
      if (uVar18 == 0xfffc) {
        iVar5 = (int)((uVar13 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar5;
    }
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) <
        (ulonglong)*(uint *)(param_1 + 2) + *(longlong *)(param_1 + 4))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar16 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar16 != 0 &&
           (lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0)) &&
          (*(char *)(lVar16 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0xd38bf8,0xe588c8,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
    }
    if (0x3f3b < *(int *)(param_1 + 2) - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar16 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar16 != 0 &&
          ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
           (*(char *)(lVar16 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0xd38bf8,0xe588c8,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar12 = -(short)uStack_48;
  if ((uStack_44 & 0x100000) != 0) {
    if ((**(byte **)(param_1 + 4) & 0x10) == 0) {
      if ((1 << (**(byte **)(param_1 + 4) & 0xe) & 0x1105U) != 0) goto LAB_;
    }
    else {
      if (*(int *)(param_1 + 8) <= (int)uStack_48) {
LAB_:
        *param_4 = *piStack_40;
        return piStack_40 + 1;
      }
      if ((**(byte **)(param_1 + 4) & 0x10) != 0) {
        uVar14 = (uint)*(ushort *)((ulonglong)*(uint *)(param_1 + 8) + *(longlong *)(param_1 + 4));
      }
      if (uVar14 < (uStack_44 & 0xffff)) goto LAB_;
    }
  }
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar12) {
    *param_4 = 0;
    return *(int **)(param_1 + 4);
  }
  uVar3 = *(ushort *)
           ((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4) + (longlong)sVar12 * 2)
          & 0x7fff;
  if (sVar12 == 1) {
    uVar14 = *(uint *)(param_1 + 0xc);
LAB_:
    if (uVar14 <= uVar3) goto LAB_;
  }
  else {
    uVar14 = *(ushort *)
              ((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4) + -2 +
              (longlong)sVar12 * 2) & 0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar14) goto LAB_;
  }
  func_0x(*(undefined8 *)(param_1 + 4),7);
LAB_:
  *param_4 = uVar3 - uVar14;
  return (int *)((ulonglong)uVar14 + *(longlong *)(param_1 + 4));
}

