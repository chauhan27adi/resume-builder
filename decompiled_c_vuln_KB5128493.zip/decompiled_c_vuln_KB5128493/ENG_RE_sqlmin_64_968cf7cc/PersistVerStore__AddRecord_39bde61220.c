
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,longlong *param_2,undefined8 param_3,short *param_4,
                 undefined8 *param_5,ulonglong param_6,undefined8 param_7,undefined8 param_8,
                 undefined4 *param_9)

{
  ushort *puVar1;
  short sVar2;
  bool bVar3;
  char cVar4;
  byte bVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  undefined4 uVar9;
  ulonglong *puVar10;
  undefined8 uVar11;
  longlong *plVar12;
  uint uVar13;
  longlong lVar14;
  undefined4 uVar15;
  longlong lVar16;
  uint uVar17;
  uint uVar18;
  byte *pbVar19;
  ushort *puVar20;
  undefined8 uVar21;
  longlong unaff_GS_OFFSET;
  undefined8 uVar22;
  ulonglong uVar23;
  undefined8 in_stack_fffffffffffffaf8;
  undefined8 in_stack_fffffffffffffb00;
  undefined8 in_stack_fffffffffffffb08;
  undefined4 uVar24;
  short sStack_4d8;
  undefined2 uStack_4d4;
  ulonglong uStack_4d0;
  int iStack_4c8;
  undefined8 uStack_4c0;
  uint uStack_4b8;
  ushort uStack_4b2;
  uint uStack_4b0;
  ulonglong *puStack_4a8;
  int iStack_4a0;
  short sStack_49c;
  undefined8 *puStack_498;
  int iStack_490;
  int iStack_488;
  int iStack_478;
  short sStack_474;
  longlong *plStack_468;
  undefined8 uStack_460;
  longlong lStack_458;
  longlong lStack_450;
  undefined8 uStack_448;
  int iStack_440;
  undefined4 uStack_43c;
  int iStack_438;
  undefined4 uStack_434;
  undefined4 uStack_430;
  undefined4 uStack_428;
  int iStack_424;
  undefined4 uStack_420;
  longlong lStack_418;
  longlong lStack_410;
  longlong lStack_408;
  undefined4 uStack_400;
  undefined4 uStack_3fc;
  longlong lStack_3f8;
  char cStack_3f0;
  undefined4 uStack_3c0;
  undefined8 uStack_3b8;
  undefined8 uStack_3b0;
  undefined8 uStack_3a8;
  undefined8 uStack_3a0;
  longlong lStack_398;
  undefined4 *puStack_390;
  longlong lStack_388;
  longlong lStack_380;
  undefined8 uStack_378;
  longlong lStack_370;
  longlong *plStack_368;
  longlong *plStack_360;
  longlong lStack_358;
  longlong lStack_350;
  longlong lStack_348;
  undefined8 uStack_340;
  longlong lStack_338;
  uint *puStack_330;
  undefined2 *puStack_328;
  uint **ppuStack_320;
  longlong lStack_310;
  undefined8 uStack_308;
  longlong lStack_300;
  longlong *plStack_2f8;
  longlong *plStack_2f0;
  longlong lStack_2e8;
  longlong lStack_2e0;
  undefined auStack_2d8 [48];
  undefined auStack_2a8 [8];
  undefined2 uStack_2a0;
  undefined2 uStack_29e;
  undefined4 uStack_298;
  uint **ppuStack_290;
  undefined *puStack_288;
  undefined8 uStack_280;
  uint *puStack_278;
  undefined4 uStack_270;
  undefined2 uStack_26c;
  undefined2 uStack_26a;
  undefined auStack_268 [528];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  uint auStack_48 [4];
  
  uStack_340 = 0xfffffffffffffffe;
  if ((*(byte *)(param_2 + 0x43) & 4) == 0) {
    plVar12 = param_2 + 5;
  }
  else {
    lVar16 = (**(code **)(*param_2 + 0x1e8))(param_2);
    plVar12 = (longlong *)(lVar16 + 0x28);
  }
  iStack_4c8 = *(int *)plVar12;
  sVar2 = *(short *)((longlong)plVar12 + 4);
  puVar1 = (ushort *)(param_4 + 1);
  if (*param_4 == 0) {
    func_0x();
  }
  else {
    func_0x(puVar1,&iStack_4a0);
  }
  uStack_3c0 = 0x400514;
  uStack_3b8 = 0;
  uStack_3a8 = 0;
  uStack_3b0 = 0;
  uStack_3a0 = 0;
  puStack_498 = param_1 + 0xd;
  uVar15 = 0;
  iStack_490 = 0;
  iVar8 = func_0x(puStack_498,1,0xffffffff);
  if (iVar8 == 0) {
    iStack_490 = 1;
  }
  else if (iVar8 == 2) {
    func_0x(0xfb);
  }
  else {
    (*_DAT_)(1,0x1103420,0x10bbf48,0x7f9,0);
  }
  if (((*param_4 != 0) && (*(longlong **)(param_4 + 8) != (longlong *)0x0)) &&
     (**(longlong **)(param_4 + 8) != 0)) {
    (*_DAT_)(1,0x11034c0,0x10bbf48,0x7ff,0);
  }
  lVar16 = *(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8);
  if (lVar16 == 0) {
    lStack_450 = 0;
LAB_:
    lStack_458 = 0;
  }
  else {
    lStack_450 = *(longlong *)(lVar16 + 0x60);
    if (lStack_450 == 0) goto LAB_;
    lStack_458 = *(longlong *)(lStack_450 + 0x4d8);
    if (lStack_458 != 0) {
      *(undefined8 *)(lStack_450 + 0x4d8) = 0;
    }
  }
  if ((*(char *)((longlong)param_1 + 0x134) == '\0') &&
     (cVar4 = func_0x(param_1), cVar4 == '\0')) {
    *(undefined *)((longlong)param_1 + 0x134) = 1;
  }
  uVar24 = (undefined4)((ulonglong)in_stack_fffffffffffffb08 >> 0x20);
  uVar17 = (uint)((ulonglong)in_stack_fffffffffffffaf8 >> 0x20);
  uVar9 = (undefined4)((ulonglong)in_stack_fffffffffffffb00 >> 0x20);
  if ((*(char *)((longlong)param_1 + 0x13c) == '\0') ||
     (bVar3 = true, *(char *)((longlong)param_1 + 0x134) == '\0')) {
    bVar3 = false;
  }
  lVar16 = param_2[0x1a];
  uStack_4d0 = param_6;
  if (param_6 == 0) {
    if (((lVar16 == 0) || (*(char *)(lVar16 + 0x34) == '\0')) || (*(longlong *)(lVar16 + 0x40) == 0)
       ) {
      uStack_4d0 = 0;
    }
    else {
      LOCK();
      plVar12 = (longlong *)(lVar16 + 0x128);
      lVar16 = *plVar12;
      *plVar12 = *plVar12 + 1;
      UNLOCK();
      uStack_4d0 = lVar16 + 1;
    }
    puStack_4a8 = *(ulonglong **)(param_4 + 4);
    if (*param_4 == 0) {
      if (*(int *)(param_4 + 2) == 0) {
        *puVar1 = 0;
        uVar13 = *(uint *)(param_4 + 8);
        uVar23 = (ulonglong)uVar13;
        *(uint *)(param_4 + 10) = uVar13;
        pbVar19 = *(byte **)(param_4 + 4);
        bVar5 = *pbVar19;
        if ((bVar5 & 0x10) != 0) {
          uVar13 = uVar13 + 2 + (*(ushort *)(pbVar19 + uVar23) + 7 >> 3);
          uVar23 = (ulonglong)uVar13;
          *(uint *)(param_4 + 10) = uVar13;
          bVar5 = *pbVar19;
        }
        if ((bVar5 & 0x20) == 0) {
          *(int *)(param_4 + 2) = (int)uVar23;
          param_4[0xe] = 0;
          *(int *)(param_4 + 0xc) = (int)uVar23;
        }
        else {
          puVar20 = (ushort *)(pbVar19 + uVar23);
          uVar6 = *puVar20;
          param_4[0xe] = uVar6;
          if (uVar6 == 0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar16 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar16 != 0 &&
                ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
                 (*(char *)(lVar16 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                (*_DAT_)(1,0xf35808,0x10554d8,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_4 + 4),3);
            uVar6 = param_4[0xe];
            uVar23 = (ulonglong)*(uint *)(param_4 + 10);
          }
          uVar17 = (int)uVar23 + (uVar6 + 1) * 2;
          *(uint *)(param_4 + 0xc) = uVar17;
          if (0x1f9e < uVar17) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar16 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar16 != 0)) &&
               ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
                (*(char *)(lVar16 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                (*_DAT_)(1,0xf35808,0x10554d8,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_4 + 4),4);
            uVar6 = param_4[0xe];
            uVar17 = *(uint *)(param_4 + 0xc);
          }
          uVar13 = puVar20[uVar6] & 0x7fff;
          *(uint *)(param_4 + 2) = uVar13;
          if (uVar13 < uVar17) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar16 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar16 != 0 &&
                ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
                 (*(char *)(lVar16 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                (*_DAT_)(1,0xf35808,0x10554d8,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_4 + 4),4);
            uVar6 = param_4[0xe];
            uVar13 = *(uint *)(param_4 + 2);
          }
          uVar24 = (undefined4)((ulonglong)in_stack_fffffffffffffb08 >> 0x20);
          uVar17 = (uint)((ulonglong)in_stack_fffffffffffffaf8 >> 0x20);
          uVar9 = (undefined4)((ulonglong)in_stack_fffffffffffffb00 >> 0x20);
          uVar23 = (ulonglong)uVar13;
          if ((short)puVar20[(ulonglong)(uVar6 - 1) + 1] < 0) {
            lVar16 = *(longlong *)(param_4 + 4);
            do {
              uVar23 = (ulonglong)uVar6;
              lVar14 = (ulonglong)*(uint *)(param_4 + 10) + lVar16;
              if (uVar6 == 1) {
                uVar13 = *(uint *)(param_4 + 0xc);
                uVar6 = *(ushort *)(lVar14 + uVar23 * 2);
                uVar18 = uVar13;
LAB_:
                if ((uVar6 & 0x7fff) < uVar13) goto LAB_;
              }
              else {
                uVar13 = *(ushort *)(lVar14 + -2 + uVar23 * 2) & 0x7fff;
                uVar18 = *(uint *)(param_4 + 0xc);
                uVar6 = *(ushort *)(lVar14 + uVar23 * 2);
                if (uVar18 <= uVar13) goto LAB_;
LAB_:
                func_0x(lVar16,7);
                uVar18 = *(uint *)(param_4 + 0xc);
              }
              uVar24 = (undefined4)((ulonglong)in_stack_fffffffffffffb08 >> 0x20);
              uVar17 = (uint)((ulonglong)in_stack_fffffffffffffaf8 >> 0x20);
              uVar9 = (undefined4)((ulonglong)in_stack_fffffffffffffb00 >> 0x20);
              if ((uVar13 < uVar18) ||
                 (uVar23 = (ulonglong)*(uint *)(param_4 + 2), *(uint *)(param_4 + 2) < uVar13))
              goto LAB_;
              lVar16 = *(longlong *)(param_4 + 4);
              if (*(ushort *)((ulonglong)uVar13 + lVar16) == 5) {
                *puVar1 = *puVar1 | 2;
                param_4[0xe] = param_4[0xe] + -1;
                param_4[0x15] = (short)uVar13;
                lVar16 = (ulonglong)(uVar13 & 0xffff) + *(longlong *)(param_4 + 4);
                uVar6 = *(ushort *)(lVar16 + 2);
                uVar7 = param_4[0x16] & 0xc7ff;
                if ((uVar6 & 0x4000) != 0) {
                  uVar7 = uVar6 & 0x3800 | uVar7;
                }
                param_4[0x16] = uVar7;
                param_4[0x16] = (uVar7 ^ *(ushort *)(lVar16 + 2)) & 0x7ff ^ uVar7;
                uVar23 = (ulonglong)*(uint *)(param_4 + 2);
                pbVar19 = *(byte **)(param_4 + 4);
                goto LAB_;
              }
              if (*(ushort *)((ulonglong)uVar13 + lVar16) < 0x400) break;
              *puVar1 = *puVar1 | 1;
              uVar6 = param_4[0xe] - 1;
              param_4[0xe] = uVar6;
              if ((uVar6 == 0) || (-1 < (short)puVar20[(ulonglong)(uVar6 - 1) + 1])) break;
            } while( true );
          }
          pbVar19 = *(byte **)(param_4 + 4);
        }
LAB_:
        if ((*pbVar19 & 0x40) == 0) {
          *(undefined4 *)(param_4 + 0x13) = 0;
        }
        else {
          *(int *)(param_4 + 0x13) = (int)uVar23;
          *(int *)(param_4 + 2) = (int)uVar23 + 0xe;
          puVar10 = (ulonglong *)func_0x(puVar1);
          uVar23 = *puVar10;
          iVar8 = 0;
          uVar6 = (ushort)(uVar23 >> 0x30);
          if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
            if ((uVar23 & 0x4000000000000000) == 0) {
              uVar6 = uVar6 & 0xdfff;
            }
            else {
              uVar6 = uVar6 | 0x2000;
            }
          }
          if (uVar6 == 0xfffc) {
            iVar8 = (int)((uVar23 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + iVar8;
          uVar23 = (ulonglong)*(uint *)(param_4 + 2);
        }
        iVar8 = (int)uVar23;
        if ((*(ulonglong *)(param_4 + 0xf) != 0) &&
           (*(ulonglong *)(param_4 + 0xf) < uVar23 + *(longlong *)(param_4 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar16 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar16 != 0 && (lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0))
              && (*(char *)(lVar16 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15);
            }
            else {
              (*_DAT_)(1,0xf35808,0x10554d8,0x877,0);
            }
          }
          func_0x(*(undefined8 *)(param_4 + 4),0x12);
          iVar8 = *(int *)(param_4 + 2);
        }
        if (0x3f3b < iVar8 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar16 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar16 != 0 &&
              ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
               (*(char *)(lVar16 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15);
              func_0x(*(undefined8 *)(param_4 + 4),5);
              goto LAB_;
            }
            (*_DAT_)(1,0xf35808,0x10554d8,0x87c,0);
          }
          func_0x(*(undefined8 *)(param_4 + 4),5);
        }
      }
LAB_:
      uVar13 = *(uint *)(param_4 + 2);
      if ((uVar13 < 9) &&
         (((**(byte **)(param_4 + 4) & 0xe) == 0 || ((**(byte **)(param_4 + 4) & 0xe) == 0xc)))) {
        uVar13 = 9;
      }
    }
    else {
      uVar13 = *(uint *)(param_4 + 2);
      if (uVar13 == 0) {
        func_0x(puVar1);
        uVar13 = *(uint *)(param_4 + 2);
      }
      if ((uVar13 < 9) &&
         (((**(byte **)(param_4 + 4) & 0x1c) == 0 || ((**(byte **)(param_4 + 4) & 0x1c) == 0xc)))) {
        uVar13 = 9;
      }
    }
    uStack_4d4 = (undefined2)uVar13;
    sStack_4d8 = 9;
    if (*param_4 == 0) {
      sStack_4d8 = (short)*(undefined4 *)(param_4 + 8);
      func_0x(puVar1,&uStack_4b8);
    }
    else {
      if ((**(byte **)(param_4 + 4) & 0x1c) == 4) {
        sStack_4d8 = 1;
      }
      else if ((**(byte **)(param_4 + 4) & 0x1c) != 0x10) {
        sStack_4d8 = param_4[0xe] + param_4[0xd];
      }
      func_0x(puVar1,&uStack_4b8);
    }
    if ((sVar2 == sStack_49c) && (iStack_4c8 == iStack_4a0)) {
      uVar18 = (uint)(int)(short)uStack_4b2 >> 0xe & 1;
      uVar13 = (uint)(int)(short)uStack_4b2 >> 0xd & 1;
      uVar6 = uStack_4b2;
      if (uVar13 != uVar18) {
        if ((uStack_4b2 & 0x4000) == 0) {
          uVar6 = uStack_4b2 & 0xdfff;
        }
        else {
          uVar6 = uStack_4b2 | 0x2000;
        }
      }
      if (uVar6 != 0xfffc) {
        if ((uStack_4b8 & 0x80000000) != 0) {
          uVar6 = uStack_4b2;
          if (uVar13 != uVar18) {
            if ((uStack_4b2 & 0x4000) == 0) {
              uVar6 = uStack_4b2 & 0xdfff;
            }
            else {
              uVar6 = uStack_4b2 | 0x2000;
            }
          }
          if (uVar6 == 0xfffc) {
            (*_DAT_)(1,0x10e0010,0x10b9750,0x4ec,0);
          }
          cVar4 = func_0x(&uStack_4b8);
          if (((cVar4 == '\0') && (cVar4 = func_0x(&uStack_4b8), cVar4 == '\0')) &&
             (((uint)(int)(short)uStack_4b2 >> 0xc & 1) != 0)) goto LAB_;
        }
        cVar4 = func_0x(param_8);
        if (cVar4 == '\0') {
          uStack_4d0 = uStack_4d0 | 0x2000000000000;
        }
        goto LAB_;
      }
    }
LAB_:
    uStack_4d0 = uStack_4d0 | 0x1000000000000;
  }
  else {
    puStack_4a8 = &uStack_4d0;
    uStack_4d4 = 8;
    sStack_4d8 = 8;
  }
LAB_:
  if (param_5 == (undefined8 *)0x0) {
    uStack_4c0 = 0;
  }
  else {
    uStack_4c0 = *param_5;
    uVar15 = *(undefined4 *)(param_5 + 1);
  }
  cVar4 = (**(code **)(*param_2 + 0x88))(param_2);
  uVar11 = _DAT_;
  if (cVar4 == '\0') {
    uVar11 = _DAT_;
  }
  uVar23 = 0;
  func_0x(auStack_2d8,0xb,0,0,uVar11,0);
  lStack_310 = param_1[2];
  if ((((*(byte *)(*(longlong *)(lStack_310 + 0x6b0) + 0x3c) & 1) != 0) &&
      (*(longlong *)(*(longlong *)(lStack_310 + 0x6b0) + 0x280) == 0)) &&
     (cVar4 = (**(code **)(*param_2 + 0x88))(param_2), cVar4 != '\0')) {
    if ((DAT_ >> 3 & 1) != 0) {
LAB_:
      puStack_390 = param_9;
      *param_9 = 0;
      *(undefined2 *)(param_9 + 1) = 0;
      *(undefined2 *)((longlong)param_9 + 6) = 0xffff;
      func_0x(auStack_2d8);
      if ((lStack_450 != 0) && (lStack_458 != 0)) {
        *(longlong *)(lStack_450 + 0x4d8) = lStack_458;
      }
      if (iStack_490 == 0) {
        return;
      }
      (*_DAT_)(puStack_498);
      return;
    }
    uStack_420 = 0x58;
    lStack_300 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    plStack_2f8 = (longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)(lStack_300 + (ulonglong)*_DAT_ * 8));
    lStack_2e8 = *plStack_2f8;
    plStack_2f0 = plStack_2f8;
    lStack_2e0 = lStack_2e8;
    if ((lStack_2e8 == 0) ||
       (lStack_418 = **(longlong **)(lStack_2e8 + 0x38), lStack_398 = lStack_418, lStack_418 == 0))
    {
      lStack_418 = 0;
    }
    else {
      iStack_438 = (*_DAT_)(lStack_418,0x1b23);
      if (iStack_438 != 0) goto LAB_;
    }
  }
  if (bVar3) {
    func_0x(param_1,param_2,param_8,param_3,puStack_4a8,uStack_4d4,sStack_4d8,uStack_4d0,
                    &uStack_4c0,CONCAT44(uVar9,uVar15),param_7,param_9);
    goto LAB_;
  }
  func_0x(&lStack_3f8);
  uStack_434 = 0x58;
  lStack_388 = *(longlong *)(unaff_GS_OFFSET + 0x58);
  lVar16 = (ulonglong)*_DAT_ + *(longlong *)(lStack_388 + (ulonglong)*_DAT_ * 8);
  lStack_410 = *(longlong *)(lVar16 + 0x100);
  lStack_380 = lVar16;
  if (lStack_410 == 0) {
    (*_DAT_)(0);
    lStack_410 = *(longlong *)(lVar16 + 0x100);
  }
  uVar13 = *(uint *)(*(longlong *)(lStack_410 + 0x260) + 0xe68);
  uVar11 = *(undefined8 *)(param_1[5] + ((ulonglong)uVar13 % (ulonglong)*(uint *)(param_1 + 9)) * 8)
  ;
  iStack_440 = 0;
  uStack_43c = 4;
  uStack_430 = 4;
  uVar9 = 0;
  uStack_4b0 = uVar13;
  uStack_460 = uVar11;
  uStack_448 = uVar11;
  uStack_378 = uVar11;
  iStack_488 = func_0x
                         (uVar11,4,0xffffffff,0,0,uVar23 & 0xffffffff00000000,0,0,
                          (ulonglong)uVar17 << 0x20);
  plVar12 = *(longlong **)(param_1[6] + ((ulonglong)uVar13 % (ulonglong)*(uint *)(param_1 + 9)) * 8)
  ;
  plStack_468 = plVar12;
  iStack_440 = iStack_488;
  if (*plVar12 == 0) {
    if ((DAT_ >> 2 & 1) == 0) {
      uStack_428 = 0x58;
      lStack_370 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      plStack_368 = (longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)(lStack_370 + (ulonglong)*_DAT_ * 8));
      lStack_358 = *plStack_368;
      plStack_360 = plStack_368;
      lStack_350 = lStack_358;
      if ((lStack_358 == 0) ||
         (lStack_408 = **(longlong **)(lStack_358 + 0x38), lStack_348 = lStack_408, lStack_408 == 0)
         ) {
        lStack_408 = 0;
        uVar11 = uStack_460;
      }
      else {
        iStack_424 = (*_DAT_)(lStack_408,0xf8a);
        plVar12 = plStack_468;
        uVar11 = uStack_460;
        if (iStack_424 != 0) goto LAB_;
      }
    }
    else {
LAB_:
      plVar12 = plStack_468;
      uVar21 = 0xf48cc8;
      if (*(char *)((longlong)param_1 + 0x4c) != '\0') {
        uVar21 = 0xead188;
      }
      uVar22 = param_1[1];
      func_0x(0xfc77a0,*(undefined2 *)(param_1[2] + 0x6b8),uVar21,uStack_4b0,uVar22);
      uVar9 = (undefined4)((ulonglong)uVar22 >> 0x20);
    }
    uVar21 = 0xf48cc8;
    uStack_400 = 0x1f;
    uStack_3fc = 0x4000000;
    if ((_DAT_ & 0x4000000) != 0) {
      if (*(char *)((longlong)param_1 + 0x4c) != '\0') {
        uVar21 = 0xead188;
      }
      func_0x(*(undefined2 *)(param_1[2] + 0x6b8),*(longlong *)(param_1[2] + 0x6b0) + 0x3a8,
                      0xfc7840,uVar21,CONCAT44(uVar9,uStack_4b0),param_1[1]);
    }
    func_0x(plVar12,*param_1,param_1[0xc],param_1[1],param_1);
  }
  iStack_478 = iStack_4c8;
  sStack_474 = sVar2;
  uVar9 = (**(code **)(*param_2 + 0x50))(param_2);
  func_0x(plVar12,&iStack_478,param_8,uVar9,param_3,puStack_4a8,uStack_4d4,sStack_4d8,
                  uStack_4d0,&uStack_4c0,CONCAT44(uVar24,uVar15),param_9);
  if (iStack_488 != 0) {
    iStack_4c8 = 4;
    uStack_308 = uVar11;
    func_0x(uVar11,4);
    iStack_440 = 0;
  }
  if (cStack_3f0 != '\0') {
    lStack_338 = lStack_3f8;
    puStack_330 = (uint *)(lStack_3f8 + 800);
    *puStack_330 = *puStack_330 | 0x1000000;
  }
LAB_:
  puStack_4a8 = (ulonglong *)0x80000000000001f;
  if ((_DAT_ & 0x8000000) != 0) {
    puStack_328 = &uStack_2a0;
    uStack_2a0 = 0;
    uStack_29e = 1;
    uStack_298 = 0;
    ppuStack_290 = &puStack_278;
    puStack_288 = auStack_268;
    uStack_58 = 0;
    uStack_54 = 0;
    uStack_280 = 0;
    uStack_50 = 0;
    ppuStack_320 = &puStack_278;
    puStack_278 = auStack_48;
    uStack_270 = 4;
    uStack_26c = 0;
    uStack_26a = 0;
    auStack_48[0] = (uint)*(ushort *)(param_1[2] + 0x6b8);
    func_0x(auStack_2a8);
  }
  if (*(char *)((longlong)param_1 + 0x134) == '\0') {
    *(undefined *)((longlong)param_1 + 0x134) = 1;
  }
  func_0x(auStack_2d8);
  lVar14 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar16 = *(longlong *)(lVar14 + 0x100);
  if (lVar16 == 0) {
    (*_DAT_)();
    lVar16 = *(longlong *)(lVar14 + 0x100);
  }
  if (*(int *)(lVar16 + 0x22c) != 0) {
    (*_DAT_)();
  }
  if (*_DAT_ != '\0') {
    if (((*(longlong *)(&DAT_ + (ulonglong)(*(ushort *)(param_1[2] + 0x6b8) >> 8) * 8) != 0)
        && (plVar12 = (longlong *)
                      (*(longlong *)
                        (&DAT_ + (ulonglong)(*(ushort *)(param_1[2] + 0x6b8) >> 8) * 8) +
                       (ulonglong)(*(ushort *)(param_1[2] + 0x6b8) & 0xff) * 8 + 0x2800),
           plVar12 != (longlong *)0x0)) && (*plVar12 != 0)) {
      LOCK();
      *(longlong *)(*plVar12 + 0x2a0) = *(longlong *)(*plVar12 + 0x2a0) + 1;
      UNLOCK();
      if ((DAT_ & 0x20) != 0) {
        plVar12 = (longlong *)0x0;
        if (_DAT_ != 0) {
          plVar12 = (longlong *)(_DAT_ + 0x2800);
        }
        if ((plVar12 != (longlong *)0x0) && (*plVar12 != 0)) {
          LOCK();
          plVar12 = (longlong *)(*plVar12 + 0x2a0);
          *plVar12 = *plVar12 + 1;
          UNLOCK();
        }
      }
    }
  }
  if ((lStack_450 != 0) && (lStack_458 != 0)) {
    *(longlong *)(lStack_450 + 0x4d8) = lStack_458;
  }
  if (iStack_490 != 0) {
    (*_DAT_)(puStack_498);
  }
  return;
}

