
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  byte *pbVar1;
  longlong *plVar2;
  byte *pbVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined auVar6 [16];
  char cVar7;
  longlong lVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  uint uVar9;
  longlong lVar10;
  ulonglong uVar11;
  longlong unaff_GS_OFFSET;
  undefined auStack_1e8 [148];
  int iStack_154;
  undefined8 uStack_150;
  undefined2 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_138;
  undefined2 uStack_134;
  undefined4 uStack_130;
  undefined2 uStack_12c;
  undefined2 uStack_12a;
  longlong lStack_128;
  longlong lStack_120;
  undefined8 uStack_118;
  undefined8 uStack_110;
  longlong lStack_108;
  longlong lStack_100;
  undefined2 uStack_f8;
  undefined4 uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  undefined8 uStack_80;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [10];
  undefined auStack_56 [6];
  undefined8 uStack_50;
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_1e8;
  lStack_100 = **(longlong **)(param_1 + 8);
  uVar9 = 0;
  lStack_128 = *(longlong *)(lStack_100 + 8);
  uStack_130 = *(undefined4 *)(lStack_128 + 0x3c0);
  uStack_12c = *(undefined2 *)(lStack_128 + 0x3c4);
  uStack_12a = *(undefined2 *)(lStack_128 + 0x3c6);
  lStack_120 = param_1;
  uStack_118 = param_2;
  uStack_110 = param_4;
  if (*(int *)(param_1 + 0x40) != 0) {
    (**(code **)(**(longlong **)(lStack_100 + 8) + 0xa0))
              (*(longlong **)(lStack_100 + 8),param_2,param_4);
    lVar5 = *(longlong *)(*(longlong *)(lStack_100 + 8) + 0x488);
    if (((lVar5 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar5 + 0x20) != 0) {
        lVar10 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar8 = *(longlong *)(lVar10 + 0x100);
        if (lVar8 == 0) {
          (*_DAT_)(0);
          lVar8 = *(longlong *)(lVar10 + 0x100);
        }
        if (*(longlong *)(lVar8 + 0x260) != 0) {
          uVar9 = *(uint *)(*(longlong *)(lVar8 + 0x260) + 0xe68);
        }
        if (uVar9 < *(uint *)(_DAT_ + 8)) {
          lVar5 = *(longlong *)(*(longlong *)(lVar5 + 0x20) + (ulonglong)uVar9 * 8);
          *(longlong *)(lVar5 + 0x30) = *(longlong *)(lVar5 + 0x30) + 1;
          goto LAB_;
        }
      }
      LOCK();
      plVar2 = (longlong *)(*(longlong *)(lVar5 + 0x18) + 0x30);
      *plVar2 = *plVar2 + 1;
      UNLOCK();
    }
LAB_:
    func_0x(uStack_40 ^ (ulonglong)auStack_1e8);
    return;
  }
  iStack_154 = *(int *)(param_1 + 0x30);
  uStack_f8 = 0xffff;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_e8 = 0;
  lVar5 = **(longlong **)(param_1 + 0x18);
  lStack_108 = (ulonglong)*(uint6 *)(lStack_100 + 0x14) << 0x10;
  iStack_c4 = iStack_154;
  if (-1 < *(char *)(lVar5 + 2)) goto LAB_;
  pbVar1 = (byte *)(lVar5 + 0x60);
  stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
  auStack_b0._0_2_ = 0xffff;
  uStack_98 = 0;
  uStack_8a = 0;
  uStack_a8 = 0;
  uStack_80 = 0;
  uStack_92 = 0;
  uStack_90 = 0;
  uStack_88 = 0;
  uStack_86 = 0;
  uStack_a0 = 0;
  psStack_78 = (short *)0x0;
  _auStack_60 = ZEXT812(0);
  auStack_56._2_4_ = 0;
  uStack_50 = 0;
  psStack_70 = (short *)0x0;
  sStack_68 = 0;
  uStack_66 = 0;
  auStack_c0 = ZEXT816(0);
  lVar8 = 0;
  if (*(short *)(lVar5 + 0x24) == 0) {
LAB_:
    auStack_c0._8_8_ = lVar8;
    uStack_150 = *(undefined8 *)(lVar5 + 0x28);
    uStack_148 = *(undefined2 *)(lVar5 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar5 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar5 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar5 + 0x18) != 99) goto LAB_;
    }
    uStack_138 = *(undefined4 *)(lVar5 + 0x20);
    uStack_134 = *(undefined2 *)(lVar5 + 0x24);
    cVar7 = func_0x(&uStack_138);
    lVar8 = auStack_c0._8_8_;
    if (cVar7 == '\0') goto LAB_;
    func_0x(lVar5,&uStack_150);
  }
  auStack_60._8_2_ = uStack_148;
  auStack_60._0_8_ = uStack_150;
  auStack_c0._0_8_ = pbVar1;
  auStack_56._2_4_ = *(undefined4 *)(lVar5 + 0x20);
  auStack_b0._0_2_ = 0xffff;
  auStack_b0 = (undefined  [8])((ulonglong)auStack_b0 & 0xffffffff);
  uStack_a8 = 0;
  uStack_92 = 0;
  uStack_90 = 0;
  uVar4 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x174f7e0);
  uVar11 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x174f7e4);
  uStack_88 = 0;
  uStack_86 = 0;
  uStack_a0 = 0;
  psStack_78 = (short *)0x0;
  psStack_70 = (short *)0x0;
  sStack_68 = 0;
  uStack_140 = uVar4;
  if ((*pbVar1 & 2) != 0) {
    pbVar3 = pbVar1 + uVar11;
    uStack_a8 = pbVar3;
    if ((pbVar1[uVar11] & 1) == 0) {
      auVar6._14_2_ = 0;
      auVar6._0_14_ = stack0xffffffffffffff52;
      _auStack_b0 = auVar6 << 0x10;
      uStack_8a = 0;
      uStack_88 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001003cd */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x1010d8) - 0xdea650))();
      return;
    }
    auStack_b0._0_2_ = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x1010b8) * 4 +
                           0x1010a8) - 0xdea650);
                    /* WARNING: Could not emulate address calculation at 0x00100272 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar1 & 4) != 0) {
    uStack_140._2_2_ = (short)((uint)uVar4 >> 0x10);
    if (uStack_140._2_2_ != 0) {
      uVar11 = (ulonglong)*(ushort *)(lVar5 + 0x61 + (longlong)uStack_140._2_2_ * 2);
    }
    psStack_78 = (short *)(pbVar1 + uVar11);
    psStack_70 = psStack_78 + 1;
    sStack_68 = (*psStack_78 + 1) * 2;
  }
  if (auStack_c0._8_8_ != 0) {
    func_0x(auStack_c0._8_8_,auStack_c0);
  }
LAB_:
  pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar5 + (0xfff - (longlong)iStack_154) * 2) + lVar5);
  if ((*pbStack_f0 & 1) == 0) {
    uStack_f8 = 0;
    uStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010061d */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_f0 & 0xe) * 4 + 0x101144) - 0xdea650))
              (0xfff - (longlong)iStack_154,(longlong)(int)(*pbStack_f0 & 0xe),pbStack_f0);
    return;
  }
  uStack_f8 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_f0 & 0x1c) + 0x101124) * 4 +
                         0x101114) - 0xdea650);
                    /* WARNING: Could not emulate address calculation at 0x001004d5 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

