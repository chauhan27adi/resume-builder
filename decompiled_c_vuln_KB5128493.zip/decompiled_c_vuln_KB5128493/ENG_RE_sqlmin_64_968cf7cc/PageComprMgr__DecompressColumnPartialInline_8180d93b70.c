
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * FUN_(byte **param_1,undefined (*param_2) [16],uint *param_3,uint param_4,
                   uint *param_5,uint param_6,uint *param_7,uint param_8)

{
  ushort *puVar1;
  longlong *plVar2;
  bool bVar3;
  byte bVar4;
  int iVar5;
  ulonglong *puVar6;
  longlong lVar7;
  ushort uVar8;
  ulonglong uVar9;
  ushort *puVar10;
  uint *puVar11;
  ushort uVar12;
  short sVar13;
  byte *pbVar14;
  uint *puVar15;
  uint uVar16;
  uint uVar17;
  uint *puVar18;
  longlong unaff_GS_OFFSET;
  uint auStackX_10 [2];
  undefined auStackX_18 [16];
  undefined auStack_48 [6];
  byte bStack_42;
  uint *puStack_40;
  
  puVar11 = (uint *)0x0;
  bVar3 = false;
  if ((param_8 & 4) == 0) {
    *param_7 = param_4;
    puVar18 = param_3;
  }
  else {
    bVar4 = *(byte *)param_3;
    puVar1 = (ushort *)param_1[10];
    if (bVar4 == 0) {
      *param_7 = (uint)*puVar1 - (uint)*(ushort *)(param_1 + 0xb);
      uVar12 = *(ushort *)(param_1 + 0xb);
    }
    else {
      *param_7 = (uint)puVar1[bVar4] - (uint)puVar1[(ulonglong)bVar4 - 1];
      uVar12 = *(ushort *)(param_1[10] + (ulonglong)bVar4 * 2 + -2);
    }
    puVar18 = (uint *)(param_1[9] + uVar12);
  }
  puVar15 = puVar11;
  if (((*param_2)[6] & 0x10) != 0) {
    puVar15 = (uint *)(*(longlong *)(*param_2 + 8) + 4);
  }
  if ((param_3 == puVar15) || ((**param_1 & 2) == 0)) {
    return puVar18;
  }
  _auStack_48 = *param_2;
  uVar12 = SUB162(_auStack_48,6);
  if ((SUB168(_auStack_48,0) >> 0x30 & 0x10) != 0) {
    uVar12 = uVar12 & 0xffef;
    _auStack_48 = SUB168(_auStack_48,0) & 0xffefffffffffffff;
    puStack_40 = (uint *)0x0;
  }
  if (param_1[1] != (byte *)0x0) {
    puVar15 = (uint *)func_0x(param_1[1] + 0x18,auStack_48,&param_8);
    goto LAB_;
  }
  puVar1 = (ushort *)((longlong)param_1 + 0x12);
  if (*(short *)(param_1 + 2) != 0) {
    auStackX_10[0] = 0;
    puVar15 = (uint *)func_0x(puVar1,auStack_48,uVar12,&param_8,auStackX_10);
    if ((((*(short *)(param_1 + 2) != 0) &&
         (plVar2 = (longlong *)param_1[4], plVar2 != (longlong *)0x0)) && (*plVar2 != 0)) &&
       (((_auStack_48 & (undefined  [16])0x8000000000000) == (undefined  [16])0x0 &&
        ((auStackX_10[0] & 1) == 0)))) {
      if ((puVar15 == (uint *)0x0) || (puVar15 == (uint *)0x1691974)) {
        param_8 = 0;
        puVar15 = puVar11;
      }
      else {
        puVar15 = (uint *)FUN_(plVar2,auStack_48,puVar15,param_8,0,0,&param_8,auStackX_10[0]
                                      );
      }
    }
    goto LAB_;
  }
  if ((auStack_48._0_4_ & 0xc0000000) == 0x80000000) {
    iVar5 = func_0x(puVar1);
    if (iVar5 == 0) {
      param_8 = 0;
      puVar15 = (uint *)0x0;
    }
    else {
      puVar15 = (uint *)func_0x((longlong)param_1 + 0x3a,auStack_48,&param_8,auStackX_18);
    }
    goto LAB_;
  }
  pbVar14 = param_1[3];
  bVar4 = *pbVar14;
  if ((bVar4 & 0x10) == 0) {
    if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
      uVar12 = ~(uVar12 >> 4);
      goto LAB_;
    }
LAB_:
    if ((int)auStack_48._0_4_ < 0) {
      if (*(int *)((longlong)param_1 + 0x14) == 0) {
        uVar17 = *(uint *)(param_1 + 4);
        uVar9 = (ulonglong)uVar17;
        *(uint *)((longlong)param_1 + 0x24) = uVar17;
        *puVar1 = 0;
        bVar4 = *pbVar14;
        if ((bVar4 & 0x10) != 0) {
          uVar17 = uVar17 + 2 + (*(ushort *)(pbVar14 + uVar9) + 7 >> 3);
          uVar9 = (ulonglong)uVar17;
          *(uint *)((longlong)param_1 + 0x24) = uVar17;
          bVar4 = *pbVar14;
        }
        if ((bVar4 & 0x20) == 0) {
          *(int *)((longlong)param_1 + 0x14) = (int)uVar9;
          *(undefined2 *)((longlong)param_1 + 0x2c) = 0;
          *(int *)(param_1 + 5) = (int)uVar9;
        }
        else {
          puVar10 = (ushort *)(pbVar14 + uVar9);
          uVar12 = *puVar10;
          *(ushort *)((longlong)param_1 + 0x2c) = uVar12;
          if (uVar12 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar7 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar7 != 0)) &&
               ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                (*(char *)(lVar7 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x190cf38,0x1a2cc08,0x80f,0);
              }
            }
            func_0x(param_1[3],3);
            uVar12 = *(ushort *)((longlong)param_1 + 0x2c);
            uVar9 = (ulonglong)*(uint *)((longlong)param_1 + 0x24);
          }
          uVar17 = (int)uVar9 + (uVar12 + 1) * 2;
          *(uint *)(param_1 + 5) = uVar17;
          if (0x1f9e < uVar17) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar7 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar7 != 0 &&
                ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                 (*(char *)(lVar7 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x190cf38,0x1a2cc08,0x816,0);
              }
            }
            func_0x(param_1[3],4);
            uVar12 = *(ushort *)((longlong)param_1 + 0x2c);
            uVar17 = *(uint *)(param_1 + 5);
          }
          uVar9 = (ulonglong)uVar12;
          uVar12 = puVar10[uVar9];
          *(uint *)((longlong)param_1 + 0x14) = uVar12 & 0x7fff;
          if ((uVar12 & 0x7fff) < uVar17) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar7 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar7 != 0)) &&
               ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                (*(char *)(lVar7 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x190cf38,0x1a2cc08,0x81d,0);
              }
            }
            func_0x(param_1[3],4);
            uVar9 = (ulonglong)*(ushort *)((longlong)param_1 + 0x2c);
          }
          if ((short)puVar10[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
            pbVar14 = param_1[3];
            do {
              if ((int)uVar9 == 1) {
                uVar17 = *(uint *)(param_1 + 5);
                uVar16 = uVar17;
LAB_:
                if ((*(ushort *)
                      (pbVar14 + uVar9 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x24)) &
                    0x7fff) < uVar17) goto LAB_;
              }
              else {
                uVar16 = *(uint *)(param_1 + 5);
                uVar17 = *(ushort *)
                          (pbVar14 +
                          uVar9 * 2 + ((ulonglong)*(uint *)((longlong)param_1 + 0x24) - 2)) & 0x7fff
                ;
                if (uVar16 <= uVar17) goto LAB_;
LAB_:
                func_0x(pbVar14,7);
                uVar16 = *(uint *)(param_1 + 5);
              }
              if ((uVar17 < uVar16) || (*(uint *)((longlong)param_1 + 0x14) < uVar17))
              goto LAB_;
              pbVar14 = param_1[3];
              if (*(ushort *)(pbVar14 + uVar17) == 5) {
                *puVar1 = *puVar1 | 2;
                *(short *)((longlong)param_1 + 0x2c) = *(short *)((longlong)param_1 + 0x2c) + -1;
                uVar12 = *(ushort *)((longlong)param_1 + 0x3c) & 0xc7ff;
                uVar16 = uVar17 & 0xffff;
                *(short *)((longlong)param_1 + 0x3a) = (short)uVar17;
                pbVar14 = param_1[3];
                if ((*(ushort *)(pbVar14 + (ulonglong)uVar16 + 2) & 0x4000) != 0) {
                  uVar12 = *(ushort *)(pbVar14 + (ulonglong)uVar16 + 2) & 0x3800 | uVar12;
                }
                *(ushort *)((longlong)param_1 + 0x3c) = uVar12;
                *(ushort *)((longlong)param_1 + 0x3c) =
                     (uVar12 ^ *(ushort *)(pbVar14 + (ulonglong)uVar16 + 2)) & 0x7ff ^ uVar12;
                break;
              }
              if (*(ushort *)(pbVar14 + uVar17) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar12 = *(short *)((longlong)param_1 + 0x2c) - 1;
              *(ushort *)((longlong)param_1 + 0x2c) = uVar12;
              if ((uVar12 == 0) ||
                 (uVar9 = (ulonglong)uVar12, -1 < (short)puVar10[(ulonglong)(uVar12 - 1) + 1]))
              goto LAB_;
            } while( true );
          }
          uVar9 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
        }
        goto LAB_;
      }
      goto LAB_;
    }
    if ((_auStack_48 & (undefined  [16])0x8000000000000) != (undefined  [16])0x0) {
      param_8 = 1;
      puVar15 = (uint *)0x1691974;
      if ((pbVar14[(int)auStack_48._0_4_] & (byte)(1 << (bStack_42 & 7))) == 0) {
        puVar15 = (uint *)0x1691f98;
      }
      goto LAB_;
    }
    if ((_auStack_48 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) goto LAB_;
      }
      else {
        if ((int)*(uint *)(param_1 + 4) <= (int)auStack_48._0_4_) goto LAB_;
        if (*(ushort *)(pbVar14 + *(uint *)(param_1 + 4)) < (ushort)auStack_48._4_2_) {
          param_8 = *puStack_40;
          puVar15 = puStack_40 + 1;
          goto LAB_;
        }
      }
    }
    param_8 = 0;
    puVar15 = (uint *)(pbVar14 + (int)auStack_48._0_4_);
    goto LAB_;
  }
  uVar17 = *(uint *)(param_1 + 4);
  if ((int)auStack_48._0_4_ < (int)uVar17) {
    if ((uint)*(ushort *)(pbVar14 + uVar17) < (uint)(ushort)auStack_48._4_2_) {
      uVar12 = ~(uVar12 >> 4);
    }
    else {
      uVar16 = (ushort)auStack_48._4_2_ - 1;
      bVar3 = true;
      uVar12 = (ushort)(pbVar14[(ulonglong)(uVar16 >> 3) + (ulonglong)uVar17 + 2] >>
                       ((byte)uVar16 & 7));
    }
  }
  else {
    uVar12 = ~(uVar12 >> 4);
  }
LAB_:
  if ((uVar12 & 1) == 0) {
    if ((!bVar3) && ((_auStack_48 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0)) {
      param_8 = *puStack_40;
      puVar15 = puStack_40 + 1;
      goto LAB_;
    }
    goto LAB_;
  }
LAB_:
  param_8 = 0;
  puVar15 = puVar11;
  goto LAB_;
LAB_:
  uVar9 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
LAB_:
  if ((*param_1[3] & 0x40) == 0) {
    *(undefined4 *)((longlong)param_1 + 0x36) = 0;
  }
  else {
    *(int *)((longlong)param_1 + 0x36) = (int)uVar9;
    *(int *)((longlong)param_1 + 0x14) = (int)uVar9 + 0xe;
    puVar6 = (ulonglong *)func_0x(puVar1);
    iVar5 = 0;
    uVar9 = *puVar6;
    uVar8 = (ushort)(uVar9 >> 0x30);
    uVar12 = uVar8;
    if ((((uint)(int)(short)uVar8 >> 1 ^ (int)(short)uVar8) & 0x2000) != 0) {
      uVar12 = uVar8 & 0xdfff;
      if ((uVar9 & 0x4000000000000000) != 0) {
        uVar12 = uVar8 | 0x2000;
      }
    }
    if (uVar12 == 0xfffc) {
      iVar5 = (int)((uVar9 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)((longlong)param_1 + 0x14) = *(int *)((longlong)param_1 + 0x14) + iVar5;
    uVar9 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
  }
  iVar5 = (int)uVar9;
  if ((*(byte **)((longlong)param_1 + 0x2e) != (byte *)0x0) &&
     (*(byte **)((longlong)param_1 + 0x2e) < param_1[3] + uVar9)) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar7 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar7 != 0 &&
         (lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0)) && (*(char *)(lVar7 + 0x499) != '\0'))))
    {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x190cf38,0x1a2cc08,0x877,0);
      }
    }
    func_0x(param_1[3],0x12);
    iVar5 = *(int *)((longlong)param_1 + 0x14);
  }
  if (0x3f3b < iVar5 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar7 = *(longlong *)
                  (*(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                  (ulonglong)*_DAT_), lVar7 != 0 &&
        ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0'))))))
    {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x190cf38,0x1a2cc08,0x87c,0);
      }
    }
    func_0x(param_1[3],5);
  }
LAB_:
  sVar13 = -auStack_48._0_2_;
  if ((_auStack_48 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
    bVar4 = *param_1[3];
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) == 0) goto LAB_;
    }
    else if (((int)auStack_48._0_4_ < (int)*(uint *)(param_1 + 4)) &&
            ((ushort)auStack_48._4_2_ <= *(ushort *)(param_1[3] + *(uint *)(param_1 + 4))))
    goto LAB_;
LAB_:
    param_8 = *puStack_40;
    puVar15 = puStack_40 + 1;
    goto LAB_;
  }
LAB_:
  puVar11 = (uint *)param_1[3];
  lVar7 = (longlong)sVar13;
  if ((uint)*(ushort *)((longlong)param_1 + 0x2c) < (uint)(int)sVar13) goto LAB_;
  uVar17 = *(uint *)((longlong)param_1 + 0x24);
  if (sVar13 == 1) {
    uVar16 = *(uint *)(param_1 + 5);
    uVar17 = *(ushort *)((longlong)puVar11 + lVar7 * 2 + (ulonglong)uVar17) & 0x7fff;
LAB_:
    if (uVar17 < uVar16) goto LAB_;
  }
  else {
    puVar1 = (ushort *)((longlong)puVar11 + lVar7 * 2 + (ulonglong)uVar17);
    uVar16 = *(ushort *)((longlong)puVar11 + lVar7 * 2 + ((ulonglong)uVar17 - 2)) & 0x7fff;
    puVar11 = (uint *)param_1[3];
    uVar17 = *puVar1 & 0x7fff;
    if (*(uint *)(param_1 + 5) <= uVar16) goto LAB_;
LAB_:
    func_0x(puVar11,7);
    puVar11 = (uint *)param_1[3];
  }
  param_8 = uVar17 - uVar16;
  puVar15 = (uint *)((longlong)puVar11 + (ulonglong)uVar16);
LAB_:
  if (puVar15 != (uint *)0x0) {
    uVar17 = *param_7;
    if (uVar17 == 0) {
      *param_7 = param_8;
      puVar18 = puVar15;
    }
    else {
      if ((char)*(byte *)puVar18 < '\0') {
        uVar17 = uVar17 - 2;
        uVar9 = (ulonglong)((*(ushort *)puVar18 & 0x7f) << 8 | (uint)(*(ushort *)puVar18 >> 8));
        puVar18 = (uint *)((longlong)puVar18 + 2);
      }
      else {
        uVar17 = uVar17 - 1;
        uVar9 = (ulonglong)*(byte *)puVar18;
        puVar18 = (uint *)((longlong)puVar18 + 1);
      }
      uVar16 = (uint)uVar9;
      if (uVar16 == 0) {
        *param_7 = uVar17;
      }
      else {
        *param_7 = uVar17 + uVar16;
        if (param_6 < uVar17 + uVar16) {
          (*_DAT_)(1,0x1abad50,0x1abad70,0x687,0);
        }
        func_0x(param_5,param_6,puVar15,uVar9);
        if (param_6 < uVar16) {
          (*_DAT_)(1,0x1abada8,0x1abad70,0x68b,0);
        }
        func_0x((byte *)((longlong)param_5 + uVar9),param_6 - uVar16,puVar18,uVar17)
        ;
        puVar18 = param_5;
      }
    }
  }
  return puVar18;
}

