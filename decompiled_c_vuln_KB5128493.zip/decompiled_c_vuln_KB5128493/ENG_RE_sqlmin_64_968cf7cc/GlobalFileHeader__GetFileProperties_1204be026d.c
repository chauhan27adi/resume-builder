
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,char param_2,uint param_3,undefined8 param_4)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  undefined2 uVar4;
  undefined8 uVar5;
  code *pcVar6;
  longlong lVar7;
  longlong *plVar8;
  uint **ppuVar9;
  char cVar10;
  byte bVar11;
  int iVar12;
  undefined4 uVar13;
  uint uVar14;
  int iVar15;
  uint uVar16;
  longlong lVar17;
  longlong *plVar18;
  byte **ppbVar19;
  byte **ppbVar20;
  longlong lVar21;
  uint *puVar22;
  short *psVar23;
  ulonglong *puVar24;
  ushort uVar25;
  uint uVar26;
  longlong lVar27;
  undefined8 *puVar28;
  ushort uVar29;
  short sVar30;
  ulonglong uVar31;
  ushort *puVar32;
  undefined *puVar33;
  uint uVar34;
  uint uVar35;
  undefined *puVar36;
  uint uVar37;
  byte **ppbVar38;
  ulonglong uVar39;
  longlong unaff_GS_OFFSET;
  undefined auStackX_8 [4];
  uint auStackX_c [3];
  uint auStackX_18 [2];
  undefined8 uStackX_20;
  ushort uStack_5288;
  uint uStack_5284;
  uint uStack_5280;
  uint uStack_527c;
  undefined8 uStack_5278;
  ushort uStack_5270;
  undefined8 uStack_5268;
  undefined8 uStack_5260;
  ushort uStack_5258;
  undefined8 uStack_5250;
  undefined2 uStack_5248;
  undefined8 uStack_5240;
  undefined2 uStack_5238;
  undefined auStack_5230 [4];
  undefined4 uStack_522c;
  undefined4 uStack_5228;
  undefined2 uStack_5224;
  undefined4 uStack_5220;
  undefined2 uStack_521c;
  undefined8 uStack_5218;
  undefined2 uStack_5210;
  undefined4 uStack_5208;
  undefined2 uStack_5204;
  undefined4 uStack_5200;
  undefined2 uStack_51fc;
  undefined4 uStack_51f8;
  undefined2 uStack_51f4;
  undefined8 uStack_51f0;
  undefined2 uStack_51e8;
  undefined8 uStack_51e0;
  ushort uStack_51d8;
  undefined auStack_51d0 [4];
  undefined auStack_51cc [4];
  undefined auStack_51c8 [4];
  undefined auStack_51c4 [4];
  undefined auStack_51c0 [4];
  undefined auStack_51bc [4];
  undefined auStack_51b8 [4];
  undefined auStack_51b4 [4];
  uint uStack_51b0;
  undefined8 uStack_51ac;
  undefined8 uStack_5198;
  undefined8 uStack_5190;
  undefined8 uStack_5188;
  undefined8 uStack_5180;
  undefined8 uStack_5178;
  undefined auStack_5168 [8];
  undefined4 uStack_5160;
  undefined4 uStack_5158;
  uint **ppuStack_5150;
  undefined *puStack_5148;
  undefined8 uStack_5140;
  uint *puStack_5138;
  undefined4 uStack_5130;
  undefined4 uStack_512c;
  longlong lStack_5128;
  undefined4 uStack_5120;
  undefined4 uStack_511c;
  longlong lStack_5118;
  undefined4 uStack_5110;
  undefined4 uStack_510c;
  short *psStack_5108;
  int iStack_5100;
  undefined4 uStack_50fc;
  short *psStack_50f8;
  int iStack_50f0;
  undefined4 uStack_50ec;
  undefined8 uStack_50e8;
  undefined4 uStack_50e0;
  undefined4 uStack_50dc;
  undefined auStack_50d8 [448];
  undefined8 uStack_4f18;
  undefined8 uStack_4f10;
  uint uStack_4f08;
  undefined2 uStack_4f04;
  undefined4 uStack_4f02;
  undefined uStack_4efe;
  undefined uStack_4efd;
  short sStack_4168;
  ushort uStack_4166;
  uint uStack_4164;
  byte **ppbStack_4160;
  undefined8 uStack_4158;
  undefined4 uStack_4150;
  ushort uStack_414c;
  undefined2 uStack_414a;
  undefined6 uStack_4148;
  undefined2 uStack_4142;
  undefined2 uStack_4140;
  undefined2 uStack_413e;
  ushort uStack_413c;
  undefined2 uStack_413a;
  undefined4 uStack_4138;
  undefined4 uStack_4134;
  undefined auStack_4130 [16];
  undefined auStack_4120 [8];
  undefined8 uStack_4118;
  undefined8 uStack_4110;
  undefined6 uStack_4108;
  undefined2 uStack_4102;
  undefined6 uStack_4100;
  undefined2 uStack_40fa;
  undefined8 uStack_40f8;
  undefined auStack_40f0 [16];
  undefined auStack_40e0 [16];
  undefined auStack_40d0 [16];
  undefined8 uStack_40c0;
  undefined auStack_40b8 [4096];
  short asStack_30b8 [24];
  short asStack_3088 [2071];
  undefined auStack_2059 [8193];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x100028;
  auStackX_18[0] = param_3;
  uStackX_20 = param_4;
  lVar17 = func_0x();
  lVar17 = -lVar17;
  uStack_5178 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar17);
  sStack_4168 = -1;
  ppbVar38 = (byte **)0x0;
  ppbStack_4160 = (byte **)0x0;
  uStack_4164 = 0;
  uStack_414a = 0;
  uStack_4148 = 0;
  uStack_4140 = 0;
  uStack_413e = 0;
  uStack_413c = 0;
  uStack_413a = 0;
  uStack_4158 = (byte **)0x0;
  uStack_4134 = 0xffffffff;
  *(undefined8 *)(&stack0x00000000 + lVar17) = 0;
  auStackX_8[lVar17] = 0;
  uVar34 = *(uint *)((longlong)auStackX_c + lVar17);
  *(uint *)((longlong)auStackX_c + lVar17) = uVar34 & 0xffff0000;
  *(uint *)((longlong)auStackX_c + lVar17) = uVar34 & 0xff000000;
  *(undefined4 *)((longlong)auStackX_c + lVar17) = 0;
  *(undefined4 *)((longlong)&uStackX_20 + lVar17) = 0;
  *(undefined2 *)((longlong)&uStackX_20 + lVar17 + 4) = 0;
  puVar32 = (ushort *)((longlong)&uStackX_20 + lVar17 + 6);
  *puVar32 = *puVar32 & 0xffe0;
  *(undefined8 *)(&stack0x00000028 + lVar17) = 0;
  lVar21 = *param_1;
  uVar4 = *(undefined2 *)(lVar21 + 0x20);
  *(undefined4 *)(&stack0x00000030 + lVar17) = 0;
  *(undefined2 *)(&stack0x00000034 + lVar17) = uVar4;
  if (param_2 == '\0') {
    lVar21 = param_1[1];
    uStack_51ac = 0;
    ppbVar20 = ppbVar38;
    if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
      lVar27 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar27 != 0) && (lVar27 = **(longlong **)(lVar27 + 0x38), lVar27 != 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100230;
        iVar12 = (*_DAT_)(lVar27,0x337);
        if (iVar12 != 0) goto LAB_;
      }
      lVar27 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
      if (lVar27 != 0) {
        ppbVar20 = *(byte ***)(lVar27 + 0x60);
      }
    }
LAB_:
    lVar27 = *(longlong *)(lVar21 + 0x728);
    do {
      uStack_5280 = 0;
      lVar7 = *(longlong *)(&stack0x00000000 + lVar17);
      if (lVar7 != 0) {
        iVar12 = (int)*(short *)((longlong)auStackX_c + lVar17);
        if (((*(ushort *)(lVar7 + 0x62) & 0x400) == 0) || (iVar12 < 3)) {
          plVar18 = *(longlong **)(&stack0x00000000 + lVar17);
          if (((byte)*(undefined2 *)(lVar7 + 0x62) >> 3 & 1) != 0) {
            if (iVar12 == 3) {
              iVar12 = 4;
            }
            else if (iVar12 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar17) + 100) & 8) != 0) &&
                (lVar7 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar17) + 0x90), lVar7 != 0)
                ) && (*(longlong *)(lVar7 + 0x758) != 0)) {
              uVar5 = *(undefined8 *)(lVar7 + 0x758);
              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100306;
              func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar17),iVar12);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar18 + 100) & 8) != 0)) &&
             ((2 < iVar12 &&
              (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar7 = *plVar18, lVar7 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10034b;
            iVar15 = (*_DAT_)(lVar7,0x2000,2,auStack_51d0);
            if (iVar15 != 0) {
              LOCK();
              *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10036d;
          func_0x(plVar18 + 0x13,iVar12);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10038c;
            func_0x(plVar18,0,iVar12);
          }
          *(uint *)((longlong)auStackX_c + lVar17) =
               *(uint *)((longlong)auStackX_c + lVar17) & 0xffff0000;
          *(undefined8 *)(&stack0x00000000 + lVar17) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1002a1;
          func_0x((longlong)&stack0x00000000 + lVar17);
        }
      }
      if (*(longlong *)(lVar21 + 0x728) != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1003be;
        func_0x((longlong)&stack0x00000000 + lVar17,&stack0x00000030 + lVar17,lVar21);
        lVar7 = *(longlong *)(&stack0x00000000 + lVar17);
        if (lVar7 != 0) {
          iVar12 = (int)*(short *)((longlong)auStackX_c + lVar17);
          if (((*(ushort *)(lVar7 + 0x62) & 0x400) == 0) || (iVar12 < 3)) {
            plVar18 = *(longlong **)(&stack0x00000000 + lVar17);
            if (((byte)*(undefined2 *)(lVar7 + 0x62) >> 3 & 1) != 0) {
              if (iVar12 == 3) {
                iVar12 = 4;
              }
              else if (iVar12 < 2) goto LAB_;
              if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar17) + 100) & 8) != 0) &&
                  (lVar7 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar17) + 0x90),
                  lVar7 != 0)) && (*(longlong *)(lVar7 + 0x758) != 0)) {
                uVar5 = *(undefined8 *)(lVar7 + 0x758);
                *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10044e;
                func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar17),iVar12);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar18 + 100) & 8) != 0)) &&
               ((2 < iVar12 &&
                (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) != 0x40000000 &&
                 (lVar7 = *plVar18, lVar7 != 0)))))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10048f;
              iVar15 = (*_DAT_)(lVar7,0x2000,2,auStack_51cc);
              if (iVar15 != 0) {
                LOCK();
                *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1004b1;
            func_0x(plVar18 + 0x13,iVar12);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1004d0;
              func_0x(plVar18,0,iVar12);
            }
            *(uint *)((longlong)auStackX_c + lVar17) =
                 *(uint *)((longlong)auStackX_c + lVar17) & 0xffff0000;
            *(undefined8 *)(&stack0x00000000 + lVar17) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1003e9;
            func_0x((longlong)&stack0x00000000 + lVar17);
          }
        }
      }
      *(uint **)(&stack0xffffffffffffffe8 + lVar17) = &uStack_51b0;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar17) = 2;
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100507;
      ppbVar19 = (byte **)func_0x
                                    (_DAT_,lVar21,&stack0x00000030 + lVar17,&uStack_5280);
      *(byte ***)(&stack0x00000000 + lVar17) = ppbVar19;
      uVar34 = *(uint *)((longlong)auStackX_c + lVar17) & 0xffff0002 | 2;
      *(uint *)((longlong)auStackX_c + lVar17) = uVar34;
      if (ppbVar20 != (byte **)0x0) {
        if (ppbVar20[(ulonglong)(*(uint *)(ppbVar20 + 0xa0) & 0xf) + 0xa1] != *ppbVar19) {
          ppbVar20[(ulonglong)(*(uint *)(ppbVar20 + 0xa0) & 0xf) + 0xa1] = *ppbVar19;
          ppbVar20[0xa0] = ppbVar20[0xa0] + 1;
          uVar34 = *(uint *)((longlong)auStackX_c + lVar17);
        }
      }
      uVar34 = (uStack_5280 >> 3 & 1) << 0x18 | uVar34 & 0xffffff;
      *(uint *)((longlong)auStackX_c + lVar17) = uVar34;
      *(uint *)((longlong)auStackX_c + lVar17 + 4) =
           uStack_5280 >> 4 & 1 | *(uint *)((longlong)auStackX_c + lVar17 + 4) & 0xffffff00;
      if (((lVar27 != 0) && (ppbVar20 != (byte **)0x0)) &&
         (ppbVar20 == *(byte ***)(lVar21 + 0x1c38))) {
        *(longlong *)(lVar27 + 0x5b28) = *(longlong *)(lVar27 + 0x5b28) + 1;
        if ((int)uStack_51ac != 0) {
          *(longlong *)(lVar27 + 0x5b30) = *(longlong *)(lVar27 + 0x5b30) + 1;
          *(longlong *)(lVar27 + 0x5b38) = *(longlong *)(lVar27 + 0x5b38) + (ulonglong)uStack_51b0;
          if (0xffffff < uVar34) {
            *(longlong *)(lVar27 + 0x5b40) = *(longlong *)(lVar27 + 0x5b40) + 1;
            *(longlong *)(lVar27 + 0x5b48) = *(longlong *)(lVar27 + 0x5b48) + (ulonglong)uStack_51b0
            ;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1005cd;
      cVar10 = func_0x(lVar21);
      if (((cVar10 == '\0') || (*(char *)(lVar21 + 0x2050) == '\0')) ||
         ((*(int *)(&stack0x00000030 + lVar17) == 0 ||
          ((*(int *)(&stack0x00000030 + lVar17) == 9 && (*(short *)(&stack0x00000034 + lVar17) == 1)
           ))))) goto LAB_;
      lVar7 = **(longlong **)(&stack0x00000000 + lVar17);
      if (*(short *)(lVar7 + 0x24) == 0) {
LAB_:
        uStack_5260 = *(undefined8 *)(lVar7 + 0x28);
        uStack_5258 = *(ushort *)(lVar7 + 0x30);
      }
      else {
        cVar10 = *(char *)(lVar7 + 1);
        if (cVar10 == '\v') {
          if (*(int *)(lVar7 + 0x18) != 99) {
LAB_:
            if (cVar10 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar10 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar7 + 0x18) != 99) goto LAB_;
        }
        uStack_5228 = *(undefined4 *)(lVar7 + 0x20);
        uStack_5224 = *(undefined2 *)(lVar7 + 0x24);
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100643;
        cVar10 = func_0x(&uStack_5228);
        if (cVar10 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100653;
        func_0x(lVar7,&uStack_5260);
      }
      uVar34 = *(uint *)(lVar21 + 0x2108);
      do {
        uVar14 = uVar34 & 0xfffffffe;
        *(undefined8 *)(&stack0x00000038 + lVar17) = *(undefined8 *)(lVar21 + 0x20fc);
        uVar13 = *(undefined4 *)(lVar21 + 0x2104);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc0 + lVar17) =
             *(undefined4 *)(&stack0xffffffffffffffc0 + lVar17);
        UNLOCK();
        uVar34 = *(uint *)(lVar21 + 0x2108);
      } while (uVar14 != uVar34);
      if ((uint)uStack_5260 <= *(uint *)(&stack0x00000038 + lVar17)) {
        if (*(uint *)(&stack0x00000038 + lVar17) != (uint)uStack_5260) goto LAB_;
        uVar34 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000038 + lVar17) >> 0x20);
        if ((uStack_5260._4_4_ <= uVar34) &&
           ((uVar34 != uStack_5260._4_4_ ||
            (uStack_5288 = (ushort)uVar13, uStack_5258 <= uStack_5288)))) goto LAB_;
      }
      if ((*(char *)(lVar21 + 0x6ac8) == '\0') &&
         (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) != *(longlong *)(lVar21 + 0x2120))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10070d;
        cVar10 = func_0x(lVar21);
        if (cVar10 != '\0') goto LAB_;
        uVar34 = *(uint *)(lVar21 + 0x2108);
        do {
          uVar14 = uVar34 & 0xfffffffe;
          uStack_51e0 = *(undefined8 *)(lVar21 + 0x20fc);
          *(undefined8 *)(&stack0x00000038 + lVar17) = uStack_51e0;
          uVar13 = *(undefined4 *)(lVar21 + 0x2104);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc0 + lVar17) =
               *(undefined4 *)(&stack0xffffffffffffffc0 + lVar17);
          UNLOCK();
          uVar34 = *(uint *)(lVar21 + 0x2108);
        } while (uVar14 != uVar34);
        uStack_5288 = (ushort)uVar13;
        uStack_51d8 = uStack_5288;
        lVar27 = **(longlong **)(&stack0x00000000 + lVar17);
        if (*(short *)(lVar27 + 0x24) == 0) {
LAB_:
          uStack_5278 = *(undefined8 *)(lVar27 + 0x28);
          uStack_5270 = *(ushort *)(lVar27 + 0x30);
        }
        else {
          cVar10 = *(char *)(lVar27 + 1);
          if (cVar10 == '\v') {
            if (*(int *)(lVar27 + 0x18) != 99) {
LAB_:
              if (cVar10 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar10 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar27 + 0x18) != 99) goto LAB_;
          }
          uStack_5200 = *(undefined4 *)(lVar27 + 0x20);
          uStack_51fc = *(undefined2 *)(lVar27 + 0x24);
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1009be;
          cVar10 = func_0x(&uStack_5200);
          if (cVar10 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1009ce;
          func_0x(lVar27,&uStack_5278);
        }
        if ((*(uint *)(&stack0x00000038 + lVar17) < (uint)uStack_5278) ||
           ((*(uint *)(&stack0x00000038 + lVar17) == (uint)uStack_5278 &&
            ((uVar34 = (uint)((ulonglong)uStack_5278 >> 0x20),
             *(uint *)(&stack0x0000003c + lVar17) < uVar34 ||
             ((*(uint *)(&stack0x0000003c + lVar17) == uVar34 && (uStack_5288 < uStack_5270))))))))
        {
          lVar27 = *(longlong *)(lVar21 + 0x6b0);
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100a2e;
          func_0x(&uStack_5278,asStack_30b8,auStack_5230);
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100a42;
          func_0x(&uStack_51e0,asStack_3088,auStack_5230);
          if ((_DAT_ & 0x10000) != 0) {
            uStack_5160 = 0x60000;
            uStack_5158 = 0;
            ppuStack_5150 = &puStack_5138;
            puStack_5148 = auStack_50d8;
            uStack_4f18 = 0;
            uStack_5140 = 0;
            uStack_4f10 = 0;
            puStack_5138 = &uStack_4f08;
            uStack_5130 = 0x34;
            uStack_512c = 5;
            lStack_5128 = 0x12b6c48;
            uStack_5120 = 0x10;
            uStack_511c = 5;
            lStack_5118 = 0x12b6c48;
            uStack_5110 = 0x10;
            uStack_510c = 6;
            psStack_5108 = (short *)0x0;
            iStack_5100 = 0;
            uStack_50fc = 7;
            psStack_50f8 = (short *)0x0;
            iStack_50f0 = 0;
            uStack_50ec = 8;
            uStack_50e8 = 0;
            uStack_50e0 = 0;
            uStack_50dc = 9;
            uStack_4f08 = (uint)*(ushort *)(lVar21 + 0x6b8);
            uStack_4f04 = *(undefined2 *)(&stack0x00000034 + lVar17);
            uStack_4f02 = *(undefined4 *)(&stack0x00000030 + lVar17);
            uStack_4efe = 0xff;
            uStack_4efd = *(undefined *)(**(longlong **)(&stack0x00000000 + lVar17) + 1);
            lStack_5128 = lVar27 + 0x254;
            lStack_5118 = lVar27 + 0x244;
            lVar21 = -1;
            do {
              lVar21 = lVar21 + 1;
            } while (asStack_30b8[lVar21] != 0);
            psStack_5108 = asStack_30b8;
            iStack_5100 = (int)lVar21 * 2;
            lVar21 = -1;
            do {
              lVar21 = lVar21 + 1;
            } while (asStack_3088[lVar21] != 0);
            iStack_50f0 = (int)lVar21 * 2;
            psStack_50f8 = asStack_3088;
            uStack_522c = 0;
            pcVar6 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100c05;
            puVar22 = (uint *)(*pcVar6)(lVar27,&uStack_522c);
            ppuVar9 = ppuStack_5150;
            uVar34 = 0;
            if (puVar22 != (uint *)0x0) {
              lVar21 = -1;
              do {
                lVar21 = lVar21 + 1;
              } while (*(short *)((longlong)puVar22 + lVar21 * 2) != 0);
              uVar34 = (int)lVar21 * 2;
            }
            ppuStack_5150[10] = puVar22;
            *(uint *)(ppuVar9 + 0xb) = uVar34;
            *(undefined4 *)((longlong)ppuVar9 + 0x5c) = 9;
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100c42;
            func_0x(auStack_5168);
          }
        }
LAB_:
        uVar31 = **(ulonglong **)(&stack0x00000000 + lVar17);
        goto LAB_;
      }
LAB_:
      if (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) == *(longlong *)(lVar21 + 0x2120)) goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100751;
      cVar10 = func_0x(lVar21);
      if (cVar10 != '\0') goto LAB_;
      if (ppbVar20 == (byte **)0x0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100763;
        ppbVar20 = (byte **)func_0x();
      }
      plVar18 = *(longlong **)(&stack0x00000000 + lVar17);
      lVar7 = *plVar18;
      if (*(short *)(lVar7 + 0x24) == 0) {
LAB_:
        uStack_5218 = *(undefined8 *)(lVar7 + 0x28);
        uStack_5210 = *(undefined2 *)(lVar7 + 0x30);
      }
      else {
        cVar10 = *(char *)(lVar7 + 1);
        if (cVar10 == '\v') {
          if (*(int *)(lVar7 + 0x18) != 99) {
LAB_:
            if (cVar10 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar10 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar7 + 0x18) != 99) goto LAB_;
        }
        uStack_51f8 = *(undefined4 *)(lVar7 + 0x20);
        uStack_51f4 = *(undefined2 *)(lVar7 + 0x24);
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1007aa;
        cVar10 = func_0x(&uStack_51f8);
        if (cVar10 == '\0') {
          plVar18 = *(longlong **)(&stack0x00000000 + lVar17);
          goto LAB_;
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1007ba;
        func_0x(lVar7,&uStack_5218);
        plVar18 = *(longlong **)(&stack0x00000000 + lVar17);
      }
      if (plVar18 != (longlong *)0x0) {
        iVar12 = (int)*(short *)((longlong)auStackX_c + lVar17);
        if (((*(ushort *)((longlong)plVar18 + 0x62) & 0x400) == 0) || (iVar12 < 3)) {
          plVar8 = *(longlong **)(&stack0x00000000 + lVar17);
          if (((byte)*(undefined2 *)((longlong)plVar18 + 0x62) >> 3 & 1) != 0) {
            if (iVar12 == 3) {
              iVar12 = 4;
            }
            else if (iVar12 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar17) + 100) & 8) != 0) &&
                (lVar7 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar17) + 0x90), lVar7 != 0)
                ) && (*(longlong *)(lVar7 + 0x758) != 0)) {
              uVar5 = *(undefined8 *)(lVar7 + 0x758);
              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100868;
              func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar17),iVar12);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar8 + 100) & 8) != 0)) &&
             ((2 < iVar12 &&
              (((*(uint *)((longlong)plVar8 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar7 = *plVar8, lVar7 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1008a9;
            iVar15 = (*_DAT_)(lVar7,0x2000,2,auStack_51c8);
            if (iVar15 != 0) {
              LOCK();
              *(uint *)((longlong)plVar8 + 100) = *(uint *)((longlong)plVar8 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar8 + 100) = *(uint *)((longlong)plVar8 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1008cb;
          func_0x(plVar8 + 0x13,iVar12);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1008ea;
            func_0x(plVar8,0,iVar12);
          }
          *(uint *)((longlong)auStackX_c + lVar17) =
               *(uint *)((longlong)auStackX_c + lVar17) & 0xffff0000;
          *(undefined8 *)(&stack0x00000000 + lVar17) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100803;
          func_0x((longlong)&stack0x00000000 + lVar17);
        }
      }
      uStack_51f0 = uStack_5218;
      uStack_51e8 = uStack_5210;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
      uVar5 = *(undefined8 *)(lVar21 + 0x728);
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10092c;
      func_0x(uVar5,&uStack_51f0,4);
    } while( true );
  }
  uVar31 = (ulonglong)auStack_2059 & 0xfffffffffffff000;
  uStack_5284 = 0;
  uStack_5198 = 0;
  uStack_5190 = 0;
  uStack_5180 = 0;
  uStack_5188 = 0;
  uVar5 = *(undefined8 *)(lVar21 + 0x18);
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100117;
  plVar18 = (longlong *)func_0x(uVar5);
  if (plVar18 == (longlong *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100162;
    (*_DAT_)(0x32);
LAB_:
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100168;
    uVar13 = (*_DAT_)();
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10017d;
    (*_DAT_)(uVar13,auStack_40b8,0,0);
    lVar21 = *param_1;
    puVar33 = auStack_40b8;
    puVar36 = auStack_5168;
    for (lVar27 = 0x1000; lVar27 != 0; lVar27 = lVar27 + -1) {
      *puVar36 = *puVar33;
      puVar33 = puVar33 + 1;
      puVar36 = puVar36 + 1;
    }
    *(longlong *)(&stack0xfffffffffffffff8 + lVar17) = lVar21 + 0x940;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = 0;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = 0x331c;
    *(undefined **)(&stack0xffffffffffffffe0 + lVar17) = auStack_5168;
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1001d0;
    (*_DAT_)(8,0x17,0x18,0x13);
  }
  else {
    lVar21 = *plVar18;
    *(undefined8 **)(&stack0xffffffffffffffe8 + lVar17) = &uStack_5198;
    *(uint **)(&stack0xffffffffffffffe0 + lVar17) = &uStack_5284;
    pcVar6 = *(code **)(lVar21 + 0xd8);
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100148;
    iVar12 = (*pcVar6)(plVar18,uVar5,uVar31,0x2000);
    if ((iVar12 == 0) || (uStack_5284 < 0x2000)) goto LAB_;
  }
LAB_:
  if (*(short *)(uVar31 + 0x24) == 0) {
LAB_:
    uStack_5250 = *(undefined8 *)(uVar31 + 0x28);
    uStack_5248 = *(undefined2 *)(uVar31 + 0x30);
  }
  else {
    cVar10 = *(char *)(uVar31 + 1);
    if (cVar10 == '\v') {
      if (*(int *)(uVar31 + 0x18) != 99) {
LAB_:
        if (cVar10 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar10 != '\b') goto LAB_;
LAB_:
      if (*(int *)(uVar31 + 0x18) != 99) goto LAB_;
    }
    uStack_5208 = *(undefined4 *)(uVar31 + 0x20);
    uStack_5204 = *(undefined2 *)(uVar31 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100c8f;
    cVar10 = func_0x(&uStack_5208);
    if (cVar10 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100c9f;
    func_0x(uVar31,&uStack_5250);
  }
  lVar21 = *param_1;
  *(undefined4 *)(lVar21 + 0x70) = (undefined4)uStack_5250;
  *(int *)(lVar21 + 0x74) = (int)((ulonglong)uStack_5250 >> 0x20);
  *(undefined2 *)(lVar21 + 0x78) = uStack_5248;
  uStack_4134 = 0;
  uVar34 = 1;
  uVar14 = 0;
  ppbVar20 = ppbVar38;
  if (*(char *)(uVar31 + 2) < '\0') {
    pbVar1 = (byte *)(uVar31 + 0x60);
    if ((sStack_4168 == 0) || (ppbVar20 = uStack_4158, uStack_4158 == (byte **)0x0)) {
      uStack_4108 = 0;
      uStack_40fa = 0;
      auStack_40e0 = ZEXT816(0);
      auStack_4130 = ZEXT816(0);
      stack0xffffffffffffbee2 = SUB1614(ZEXT816(0),2);
      auStack_4120._0_2_ = 0xffff;
      uStack_4118 = 0;
      uStack_4102 = 0;
      uStack_4100 = 0;
      uStack_40f8 = 0;
      uStack_4110 = 0;
      auStack_40f0 = ZEXT816(0);
      auStack_40d0._0_12_ = ZEXT812(0);
      auStack_40d0._12_4_ = 0;
      uStack_40c0 = 0;
      ppbVar20 = (byte **)auStack_4130;
    }
    if (*(short *)(uVar31 + 0x24) == 0) {
LAB_:
      uStack_5240 = *(undefined8 *)(uVar31 + 0x28);
      uStack_5238 = *(undefined2 *)(uVar31 + 0x30);
    }
    else {
      cVar10 = *(char *)(uVar31 + 1);
      if (cVar10 == '\v') {
        if (*(int *)(uVar31 + 0x18) != 99) {
LAB_:
          if (cVar10 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar10 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar31 + 0x18) != 99) goto LAB_;
      }
      uStack_5220 = *(undefined4 *)(uVar31 + 0x20);
      uStack_521c = *(undefined2 *)(uVar31 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100def;
      uVar34 = 1;
      cVar10 = func_0x(&uStack_5220);
      if (cVar10 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100dff;
      func_0x(uVar31,&uStack_5240);
    }
    *ppbVar20 = pbVar1;
    *(undefined4 *)(ppbVar20 + 0xc) = (undefined4)uStack_5240;
    *(int *)((longlong)ppbVar20 + 100) = (int)((ulonglong)uStack_5240 >> 0x20);
    *(undefined2 *)(ppbVar20 + 0xd) = uStack_5238;
    *(undefined4 *)((longlong)ppbVar20 + 0x6c) = *(undefined4 *)(uVar31 + 0x20);
    *(undefined2 *)(ppbVar20 + 0xe) = *(undefined2 *)(uVar31 + 0x24);
    *(undefined2 *)((longlong)ppbVar20 + 0x72) = 0;
    uStack_5268 = (undefined8 *)
                  CONCAT44(uStack_5268._4_4_,*(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1187350));
    uVar39 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1187354);
    *(undefined2 *)(ppbVar20 + 2) = 0xffff;
    ppbVar20[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
    ppbVar20[7] = (byte *)0x0;
    ppbVar20[4] = (byte *)0x0;
    ppbVar20[9] = (byte *)0x0;
    ppbVar20[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar20 + 0xb) = 0;
    if ((**ppbVar20 & 2) != 0) {
      pbVar2 = pbVar1 + uVar39;
      if ((*pbVar2 & (byte)uVar34) == 0) {
        *(undefined2 *)(ppbVar20 + 2) = 0;
        ppbVar20[3] = pbVar2;
        *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar20 + 0x36) = 0;
        uVar16 = uVar14;
        switch(*pbVar2 & 0xe) {
        default:
          uVar16 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10107b;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar16 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar16 = uVar34;
        }
        *(uint *)(ppbVar20 + 4) = uVar16;
        *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
      }
      else {
        *(short *)(ppbVar20 + 2) = (short)uVar34;
        ppbVar20[3] = pbVar2;
        bVar3 = *pbVar2;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar25 = *(ushort *)(pbVar2 + 1);
            *(ushort *)((longlong)ppbVar20 + 0x12) = uVar25;
            sVar30 = 3;
            uVar25 = (uVar25 & 0x7f) << 8 | uVar25 >> 8;
          }
          else {
            sVar30 = 2;
            uVar25 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar20 + 0x12) = uVar25;
          *(short *)(ppbVar20 + 5) = sVar30;
          uVar25 = *(ushort *)((longlong)ppbVar20 + 0x12);
          *(short *)((longlong)ppbVar20 + 0x2c) = (short)(uVar25 + 1 >> 1) + sVar30;
          if (uVar25 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar20 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
            *(undefined4 *)(ppbVar20 + 8) = 0;
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
          }
          else {
            iVar12 = uVar25 - 1;
            *(short *)((longlong)ppbVar20 + 0x2a) =
                 ((short)(iVar12 / 0x1e) + (short)(iVar12 >> 0x1f)) -
                 (short)((longlong)iVar12 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
            *(undefined4 *)(ppbVar20 + 8) = 0;
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) != 4) || (uVar16 = uVar34, (bVar3 & 2) == 0)) {
            uVar16 = 0;
          }
          uVar26 = uVar34;
          uVar35 = uVar14;
          if (uVar16 != 0) {
            *(undefined4 *)(ppbVar20 + 8) = 0;
            uVar26 = 0xf;
            uVar35 = uVar34;
          }
          ppbVar20[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
          ppbVar20[6] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[3] = pbVar2;
          *(uint *)((longlong)ppbVar20 + 0x14) = uVar26;
          *(uint *)(ppbVar20 + 8) = uVar35;
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar20[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
          ppbVar20[6] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar20 + 0x14) = 9;
          *(undefined4 *)(ppbVar20 + 8) = 0;
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar20 & 4) != 0) {
      if (uStack_5268._2_2_ != 0) {
        uVar39 = (ulonglong)*(ushort *)(uVar31 + 0x61 + (longlong)uStack_5268._2_2_ * 2);
      }
      psVar23 = (short *)(pbVar1 + uVar39);
      ppbVar20[9] = (byte *)psVar23;
      sVar30 = *psVar23;
      ppbVar20[10] = (byte *)(psVar23 + 1);
      *(short *)(ppbVar20 + 0xb) = (sVar30 + 1) * 2;
    }
    pbVar1 = ppbVar20[1];
    if (pbVar1 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10110d;
      func_0x(pbVar1,ppbVar20);
    }
  }
  uVar39 = (ulonglong)*(ushort *)(uVar31 + 0xe);
  ppbStack_4160 = (byte **)(*(ushort *)(uVar31 + 0x1ffe) + uVar31);
  if ((*(byte *)ppbStack_4160 & 1) == 0) {
    sStack_4168 = 0;
    uStack_4164 = 0;
    uStack_4142 = 0;
    uStack_4140 = 0;
    switch(*(byte *)ppbStack_4160 & 0xe) {
    default:
      uVar39 = (ulonglong)*(ushort *)((longlong)ppbStack_4160 + 2);
      if (0x1f9d < *(ushort *)((longlong)ppbStack_4160 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101346;
        func_0x(ppbStack_4160,6);
      }
      break;
    case 4:
      uVar39 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar39 = 1;
    }
    uStack_4158 = (byte **)CONCAT44(uStack_4158._4_4_,(int)uVar39);
    uStack_414a = (undefined2)(uVar31 + 0x2000);
    uStack_4148 = (undefined6)(uVar31 + 0x2000 >> 0x10);
  }
  else {
    sStack_4168 = 1;
    bVar3 = *(byte *)ppbStack_4160;
    switch(bVar3 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)ppbStack_4160 + 1) < '\0') {
        uStack_4166 = (*(ushort *)((longlong)ppbStack_4160 + 1) & 0x7f) << 8 |
                      *(ushort *)((longlong)ppbStack_4160 + 1) >> 8;
        sVar30 = 3;
        uStack_4150._0_2_ = 3;
      }
      else {
        uStack_4166 = (ushort)*(byte *)((longlong)ppbStack_4160 + 1);
        uStack_4150._0_2_ = 2;
        sVar30 = 2;
      }
      uStack_414c = (short)(uStack_4166 + 1 >> 1) + sVar30;
      if (uStack_4166 < 0x1f) {
        uStack_4150._2_2_ = 0;
        uStack_4164 = 0;
        uStack_4138 = 0;
      }
      else {
        iVar12 = uStack_4166 - 1;
        uStack_4150._2_2_ =
             ((short)(iVar12 / 0x1e) + (short)(iVar12 >> 0x1f)) -
             (short)((longlong)iVar12 * 0x88888889 >> 0x3f);
        uStack_4164 = 0;
        uStack_4138 = 0;
      }
      break;
    case 4:
      if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
        uStack_4150._0_2_ = 0;
        uStack_4150._2_2_ = 0;
        uStack_414c = 0;
        uStack_414a = 0;
        uStack_4166 = 0;
        uStack_4148 = 0;
        uStack_4142 = 0;
        uStack_4164 = 0xf;
        uStack_4138 = 1;
      }
      else {
        uStack_4150._0_2_ = 0;
        uStack_4150._2_2_ = 0;
        uStack_414c = 0;
        uStack_414a = 0;
        uStack_4166 = 0;
        uStack_4148 = 0;
        uStack_4142 = 0;
        uStack_4164 = 1;
        uStack_4138 = 0;
      }
      break;
    case 8:
      uStack_4150._0_2_ = 0;
      uStack_4150._2_2_ = 0;
      uStack_414c = 0;
      uStack_414a = 0;
      uStack_4166 = 0;
      uStack_4148 = 0;
      uStack_4142 = 0;
      uStack_4164 = 9;
      uStack_4138 = 0;
    }
    lVar21 = uVar31 + 0x2000;
    uStack_4140 = (undefined2)lVar21;
    uStack_413e = (undefined2)((ulonglong)lVar21 >> 0x10);
    uStack_413c = (ushort)((ulonglong)lVar21 >> 0x20);
    uStack_413a = (undefined2)((ulonglong)lVar21 >> 0x30);
    uStack_4158 = ppbVar20;
    uVar39 = (ulonglong)ppbVar20 & 0xffffffff;
  }
  puVar28 = &uStackX_20;
  uStack_5268 = puVar28;
  if (auStackX_18[0] != 0) {
    while( true ) {
      uVar26 = (uint)uVar39;
      auStackX_18[0] = auStackX_18[0] - 1;
      uVar34 = *(uint *)puVar28;
      uVar5 = puVar28[1];
      uStack_5268 = puVar28 + 3;
      uVar16 = *(uint *)(puVar28 + 2);
      if (0x3b < (int)uVar34) break;
      uVar37 = -uVar34;
      *(uint *)((longlong)&uStackX_20 + lVar17) = uVar37;
      *(short *)((longlong)&uStackX_20 + lVar17 + 4) = (short)uVar34;
      uVar35 = uVar34;
      if ((uVar37 & 0xc0000000) == 0x80000000) {
        *(undefined2 *)((longlong)&uStackX_20 + lVar17 + 4) = 0;
        uVar35 = 0;
      }
      *(ushort *)((longlong)&uStackX_20 + lVar17 + 6) =
           *(ushort *)((longlong)&uStackX_20 + lVar17 + 6) & 0xffe0;
      *(undefined8 *)(&stack0x00000028 + lVar17) = 0;
      if (sStack_4168 == 0) {
        if ((uVar37 & 0xc0000000) == 0x80000000) {
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101d6f;
          iVar12 = func_0x(&uStack_4166);
          if (iVar12 == 0) {
code_r0x00101e1f:
            ppbVar20 = (byte **)0x0;
            *(undefined4 *)((longlong)auStackX_18 + lVar17) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101d91;
            ppbVar20 = (byte **)func_0x(&uStack_413e,(longlong)&uStackX_20 + lVar17,
                                                (longlong)auStackX_18 + lVar17,auStack_51c4);
          }
        }
        else {
          bVar3 = *(byte *)ppbStack_4160;
          if ((bVar3 & 0x10) == 0) {
            if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
              bVar11 = 0xff;
              uVar35 = uVar14;
              goto code_r0x001014e1;
            }
code_r0x00101524:
            if ((int)uVar34 < 1) {
              bVar11 = *(byte *)((longlong)&uStackX_20 + lVar17 + 6);
              if ((bVar11 & 8) == 0) {
                if ((bVar11 & 0x10) == 0) {
code_r0x00101567:
                  ppbVar20 = (byte **)((longlong)(int)uVar37 + (longlong)ppbStack_4160);
                  *(undefined4 *)((longlong)auStackX_18 + lVar17) = 0;
                }
                else {
                  if ((bVar3 & 0x10) == 0) {
                    if ((1 << (bVar3 & 0xe) & 0x1105U) == 0) goto code_r0x00101567;
                  }
                  else if (((int)uVar37 < (int)uVar26) &&
                          (*(ushort *)((longlong)&uStackX_20 + lVar17 + 4) <=
                           *(ushort *)(uVar39 + (longlong)ppbStack_4160))) goto code_r0x00101567;
code_r0x00101507:
                  ppbVar20 = (byte **)0x4;
                  *(undefined4 *)((longlong)auStackX_18 + lVar17) =
                       **(undefined4 **)(&stack0x00000028 + lVar17);
                }
              }
              else {
                ppbVar20 = (byte **)0x110f2a4;
                if ((*(byte *)((longlong)(int)uVar37 + (longlong)ppbStack_4160) &
                    (byte)(1 << (*(byte *)((longlong)&uStackX_20 + lVar17 + 6) & 7))) == 0) {
                  ppbVar20 = (byte **)0x110f8c8;
                }
                *(undefined4 *)((longlong)auStackX_18 + lVar17) = 1;
              }
            }
            else {
              ppbVar20 = ppbStack_4160;
              uVar34 = uStack_4150;
              if (uStack_4164 == 0) {
                uStack_4166 = 0;
                uVar34 = uVar26;
                if ((*(byte *)ppbStack_4160 & 0x10) != 0) {
                  uVar34 = uVar26 + 2 + (*(ushort *)(uVar39 + (longlong)ppbStack_4160) + 7 >> 3);
                }
                uStack_4158 = (byte **)CONCAT44(uVar34,(uint)uStack_4158);
                if ((*(byte *)ppbStack_4160 & 0x20) == 0) {
                  uVar31 = (ulonglong)uVar34;
                  uStack_4164 = uVar34;
                  uStack_414c = 0;
                  uStack_4150._0_2_ = (undefined2)uVar34;
                  uStack_4150._2_2_ = (short)(uVar34 >> 0x10);
                  uVar35 = uVar34;
                }
                else {
                  puVar32 = (ushort *)((ulonglong)uVar34 + (longlong)ppbStack_4160);
                  uStack_414c = *puVar32;
                  if (*puVar32 == 0) {
                    if ((((cRam0000000001a99e3b != '\0') || ((bRam0000000001aaa740 & 1) != 0)) &&
                        (lVar21 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar21 != 0)) &&
                       ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                        (*(char *)(lVar21 + 0x499) != '\0')))) {
                      if ((cRam0000000001a99d2b == '\0') && ((bRam0000000001aaa740 & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10168e;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1016b2;
                        (*pcRam0000000001008660)(1,0x138a868,0x14aa538,0x80f);
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1016c6;
                    func_0x(ppbStack_4160,3);
                  }
                  uVar34 = uStack_4158._4_4_ + (uStack_414c + 1) * 2;
                  uStack_4150._0_2_ = (undefined2)uVar34;
                  uStack_4150._2_2_ = (short)(uVar34 >> 0x10);
                  uStack_4150 = uVar34;
                  if (0x1f9e < uVar34) {
                    if (((cRam0000000001a99e3b != '\0') || ((bRam0000000001aaa740 & 1) != 0)) &&
                       ((lVar21 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar21 != 0 &&
                        ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                         (*(char *)(lVar21 + 0x499) != '\0')))))) {
                      if ((cRam0000000001a99d2b == '\0') && ((bRam0000000001aaa740 & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101770;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101796;
                        (*pcRam0000000001008660)(1,0x138a868,0x14aa538,0x816);
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1017aa;
                    func_0x(ppbStack_4160,4);
                  }
                  uStack_4164 = puVar32[uStack_414c] & 0x7fff;
                  uVar34 = uStack_4150;
                  if ((puVar32[uStack_414c] & 0x7fff) < uStack_4150) {
                    if ((((cRam0000000001a99e3b != '\0') || ((bRam0000000001aaa740 & 1) != 0)) &&
                        (lVar21 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar21 != 0)) &&
                       ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                        (*(char *)(lVar21 + 0x499) != '\0')))) {
                      if ((cRam0000000001a99d2b == '\0') && ((bRam0000000001aaa740 & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101855;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10187b;
                        (*pcRam0000000001008660)(1,0x138a868,0x14aa538,0x81d);
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10188f;
                    func_0x(ppbStack_4160,4);
                    uVar34 = uStack_4150;
                  }
                  uVar31 = (ulonglong)uStack_4164;
                  ppbVar20 = ppbStack_4160;
                  uStack_4150 = uVar34;
                  do {
                    if (-1 < (short)puVar32[(ulonglong)(uStack_414c - 1) + 1]) break;
                    uVar35 = uVar34;
                    if (uStack_414c != 1) {
                      uVar35 = *(ushort *)
                                ((longlong)ppbVar20 +
                                (ulonglong)uStack_414c * 2 + (((ulonglong)uStack_4158 >> 0x20) - 2))
                               & 0x7fff;
                    }
                    if ((uVar35 < uVar34) ||
                       ((*(ushort *)
                          ((longlong)ppbVar20 +
                          (ulonglong)uStack_414c * 2 + ((ulonglong)uStack_4158 >> 0x20)) & 0x7fff) <
                        uVar35)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101904;
                      func_0x(ppbVar20,7);
                      uVar31 = (ulonglong)uStack_4164;
                      ppbVar20 = ppbStack_4160;
                      uVar34 = uStack_4150;
                    }
                    uVar26 = (uint)uStack_4158;
                    if ((uVar35 < uVar34) || ((uint)uVar31 < uVar35)) goto code_r0x00101c73;
                    if (*(ushort *)((ulonglong)uVar35 + (longlong)ppbVar20) == 5) {
                      uStack_4166 = uStack_4166 | 2;
                      uStack_414c = uStack_414c - 1;
                      uStack_413e = (short)uVar35;
                      uVar25 = *(ushort *)((ulonglong)(uVar35 & 0xffff) + 2 + (longlong)ppbVar20);
                      if ((uVar25 & 0x4000) == 0) {
                        uStack_413c = uStack_413c & 0xc7ff;
                      }
                      else {
                        uStack_413c = uStack_413c ^ (uVar25 ^ uStack_413c) & 0x3800;
                      }
                      uStack_413c = uStack_413c ^
                                    (uStack_413c ^
                                    *(ushort *)
                                     ((ulonglong)(uVar35 & 0xffff) + 2 + (longlong)ppbVar20)) &
                                    0x7ff;
                      uVar35 = uStack_4150;
                      goto code_r0x00101a06;
                    }
                    if (*(ushort *)((ulonglong)uVar35 + (longlong)ppbVar20) < 0x400) break;
                    uStack_4166 = uStack_4166 | 1;
                    uStack_414c = uStack_414c - 1;
                  } while (uStack_414c != 0);
                  uVar26 = (uint)uStack_4158;
                  uVar35 = uStack_4150;
                }
code_r0x00101a06:
                if ((*(byte *)ppbVar20 & 0x40) == 0) {
                  uStack_4142 = 0;
                  uStack_4140 = 0;
                }
                else {
                  uStack_4142 = (undefined2)uVar31;
                  uStack_4140 = (undefined2)(uVar31 >> 0x10);
                  uStack_4164 = (int)uVar31 + 0xe;
                  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101a2d;
                  uStack_4150 = uVar35;
                  puVar24 = (ulonglong *)func_0x(&uStack_4166);
                  uVar31 = *puVar24;
                  uVar29 = (ushort)(uVar31 >> 0x30);
                  uVar25 = uVar29;
                  if ((((uint)(int)(short)uVar29 >> 1 ^ (int)(short)uVar29) & 0x2000) != 0) {
                    uVar25 = uVar29 & 0xdfff;
                    if ((uVar31 & 0x4000000000000000) != 0) {
                      uVar25 = uVar29 | 0x2000;
                    }
                  }
                  uVar34 = uVar14;
                  if (uVar25 == 0xfffc) {
                    uVar34 = (uint)((uVar31 >> 0x20 & 0xffff) >> 5);
                  }
                  uVar31 = (ulonglong)(uStack_4164 + uVar34);
                  uStack_4164 = uStack_4164 + uVar34;
                  ppbVar20 = ppbStack_4160;
                  uVar26 = (uint)uStack_4158;
                  uVar34 = uStack_4150;
                  uVar35 = uStack_4150;
                }
                uVar37 = (uint)uVar31;
                uStack_4150 = uVar34;
                if ((CONCAT62(uStack_4148,uStack_414a) != 0) &&
                   (CONCAT62(uStack_4148,uStack_414a) < uVar31 + (longlong)ppbVar20)) {
                  uStack_4150 = uVar35;
                  if (((cRam0000000001a99e3b != '\0') || ((bRam0000000001aaa740 & 1) != 0)) &&
                     (((lVar21 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), ppbVar20 = ppbStack_4160,
                       lVar21 != 0 && (lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0)) &&
                      (*(char *)(lVar21 + 0x499) != '\0')))) {
                    if ((cRam0000000001a99d2b == '\0') && ((bRam0000000001aaa740 & 2) == 0)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101b45;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      ppbVar20 = ppbStack_4160;
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101b6b;
                      (*pcRam0000000001008660)(1,0x138a868,0x14aa538,0x877);
                      ppbVar20 = ppbStack_4160;
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101b7f;
                  func_0x(ppbVar20,0x12);
                  ppbVar20 = ppbStack_4160;
                  uVar37 = uStack_4164;
                  uVar26 = (uint)uStack_4158;
                  uVar35 = uStack_4150;
                }
                uVar34 = uStack_4150;
                uStack_4150 = uVar35;
                if (0x3f3b < uVar37 - 1) {
                  if (((cRam0000000001a99e3b != '\0') || ((bRam0000000001aaa740 & 1) != 0)) &&
                     ((lVar21 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), ppbVar20 = ppbStack_4160,
                      lVar21 != 0 &&
                      ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                       (*(char *)(lVar21 + 0x499) != '\0')))))) {
                    if ((cRam0000000001a99d2b == '\0') && ((bRam0000000001aaa740 & 2) == 0)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101c24;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      ppbVar20 = ppbStack_4160;
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101c4a;
                      (*pcRam0000000001008660)(1,0x138a868,0x14aa538,0x87c);
                      ppbVar20 = ppbStack_4160;
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101c5e;
                  func_0x(ppbVar20,5);
                  ppbVar20 = ppbStack_4160;
                  uVar26 = (uint)uStack_4158;
                  uVar34 = uStack_4150;
                }
              }
code_r0x00101c73:
              sVar30 = -*(short *)((longlong)&uStackX_20 + lVar17);
              if ((*(byte *)((longlong)&uStackX_20 + lVar17 + 6) & 0x10) != 0) {
                if ((*(byte *)ppbVar20 & 0x10) == 0) {
                  if ((1 << (*(byte *)ppbVar20 & 0xe) & 0x1105U) != 0) {
code_r0x00101cd6:
                    ppbVar20 = (byte **)(*(undefined4 **)(&stack0x00000028 + lVar17) + 1);
                    *(undefined4 *)((longlong)auStackX_18 + lVar17) =
                         **(undefined4 **)(&stack0x00000028 + lVar17);
                    goto code_r0x00101e27;
                  }
                }
                else if (((int)uVar26 <= *(int *)((longlong)&uStackX_20 + lVar17)) ||
                        (*(ushort *)((ulonglong)uVar26 + (longlong)ppbVar20) <
                         *(ushort *)((longlong)&uStackX_20 + lVar17 + 4))) goto code_r0x00101cd6;
              }
              if ((uint)uStack_414c < (uint)(int)sVar30) {
                *(undefined4 *)((longlong)auStackX_18 + lVar17) = 0;
              }
              else {
                ppbVar19 = ppbVar20;
                uVar26 = uVar34;
                if (sVar30 != 1) {
                  uVar34 = *(ushort *)
                            ((longlong)ppbVar20 +
                            (longlong)sVar30 * 2 + (((ulonglong)uStack_4158 >> 0x20) - 2)) & 0x7fff;
                  ppbVar19 = ppbStack_4160;
                  uVar26 = uStack_4150;
                }
                uVar35 = *(ushort *)
                          ((longlong)ppbVar20 +
                          (longlong)sVar30 * 2 + ((ulonglong)uStack_4158 >> 0x20)) & 0x7fff;
                if ((uVar34 < uVar26) || (uVar35 < uVar34)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101d2d;
                  func_0x(ppbVar19,7);
                  ppbVar19 = ppbStack_4160;
                }
                ppbVar20 = (byte **)((ulonglong)uVar34 + (longlong)ppbVar19);
                *(uint *)((longlong)auStackX_18 + lVar17) = uVar35 - uVar34;
              }
            }
          }
          else {
            if ((int)uVar37 < (int)uVar26) {
              if ((uint)*(ushort *)((longlong)ppbStack_4160 + uVar39) < (uVar35 & 0xffff)) {
                bVar11 = 0xff;
                uVar35 = 0;
              }
              else {
                uVar35 = (uVar35 & 0xffff) - 1;
                bVar11 = *(byte *)((longlong)ppbStack_4160 + uVar39 + 2 + (ulonglong)(uVar35 >> 3))
                         >> ((byte)uVar35 & 7);
                uVar35 = 1;
              }
            }
            else {
              bVar11 = 0xff;
              uVar35 = 0;
            }
code_r0x001014e1:
            if ((bVar11 & 1) == 0) {
              if ((uVar35 != 0) || ((*(byte *)((longlong)&uStackX_20 + lVar17 + 6) & 0x10) == 0))
              goto code_r0x00101524;
              goto code_r0x00101507;
            }
            *(undefined4 *)((longlong)auStackX_18 + lVar17) = 0;
            ppbVar20 = ppbVar38;
          }
        }
      }
      else {
        uStack_527c = 0;
        *(uint **)(&stack0xffffffffffffffe0 + lVar17) = &uStack_527c;
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101dbc;
        ppbVar20 = (byte **)func_0x(&uStack_4166,(longlong)&uStackX_20 + lVar17,uVar37,
                                            (longlong)auStackX_18 + lVar17);
        if ((((sStack_4168 != 0) && (uStack_4158 != (byte **)0x0)) && (*uStack_4158 != (byte *)0x0))
           && (((*(byte *)((longlong)&uStackX_20 + lVar17 + 6) & 8) == 0 && ((uStack_527c & 1) == 0)
               ))) {
          if ((ppbVar20 == (byte **)0x0) || (ppbVar20 == (byte **)0x110f2a4)) goto code_r0x00101e1f;
          *(uint *)(&stack0xfffffffffffffff8 + lVar17) = uStack_527c;
          *(longlong *)(&stack0xfffffffffffffff0 + lVar17) = (longlong)auStackX_18 + lVar17;
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101e1a;
          ppbVar20 = (byte **)func_0x
                                        (uStack_4158,(longlong)&uStackX_20 + lVar17,ppbVar20,
                                         *(undefined4 *)((longlong)auStackX_18 + lVar17));
        }
      }
code_r0x00101e27:
      if (ppbVar20 == (byte **)0x0) {
        lVar21 = *(longlong *)(&stack0x00000000 + lVar17);
        if (lVar21 == 0) goto code_r0x001022cc;
        iVar12 = (int)*(short *)((longlong)auStackX_c + lVar17);
        if (((*(ushort *)(lVar21 + 0x62) >> 10 & 1) != 0) && (2 < iVar12)) goto code_r0x00101fc4;
        plVar18 = *(longlong **)(&stack0x00000000 + lVar17);
        if (((byte)*(undefined2 *)(lVar21 + 0x62) >> 3 & 1) != 0) {
          if (iVar12 == 3) {
            iVar12 = 4;
          }
          else if (iVar12 < 2) goto code_r0x00102039;
          if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar17) + 100) & 8) != 0) &&
              (lVar21 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar17) + 0x90), lVar21 != 0)
              ) && (*(longlong *)(lVar21 + 0x758) != 0)) {
            uVar5 = *(undefined8 *)(lVar21 + 0x758);
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102039;
            func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar17),iVar12);
          }
        }
code_r0x00102039:
        if ((((DAT_ & 0x80) == 0) || ((*(uint *)((longlong)plVar18 + 100) & 8) == 0)) ||
           ((iVar12 < 3 ||
            (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) == 0x40000000 ||
             (lVar21 = *plVar18, lVar21 == 0)))))) goto code_r0x0010215e;
        puVar33 = auStack_51bc;
        goto code_r0x00102139;
      }
      if (uVar16 < *(uint *)((longlong)auStackX_18 + lVar17)) {
        lVar21 = *(longlong *)(&stack0x00000000 + lVar17);
        if (lVar21 != 0) {
          iVar12 = (int)*(short *)((longlong)auStackX_c + lVar17);
          if (((*(ushort *)(lVar21 + 0x62) >> 10 & 1) == 0) || (iVar12 < 3)) {
            plVar18 = *(longlong **)(&stack0x00000000 + lVar17);
            if (((byte)*(undefined2 *)(lVar21 + 0x62) >> 3 & 1) != 0) {
              if (iVar12 == 3) {
                iVar12 = 4;
              }
              else if (iVar12 < 2) goto code_r0x00101f07;
              if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar17) + 100) & 8) != 0) &&
                  (lVar21 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar17) + 0x90),
                  lVar21 != 0)) && (*(longlong *)(lVar21 + 0x758) != 0)) {
                uVar5 = *(undefined8 *)(lVar21 + 0x758);
                *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101f07;
                func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar17),iVar12);
              }
            }
code_r0x00101f07:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar18 + 100) & 8) != 0)) &&
               ((2 < iVar12 &&
                (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) != 0x40000000 &&
                 (lVar21 = *plVar18, lVar21 != 0)))))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101f48;
              iVar15 = (*_DAT_)(lVar21,0x2000,2,auStack_51c0);
              if (iVar15 != 0) {
                LOCK();
                *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101f6a;
            func_0x(plVar18 + 0x13,iVar12);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101f89;
              func_0x(plVar18,0,iVar12);
            }
            *(uint *)((longlong)auStackX_c + lVar17) =
                 *(uint *)((longlong)auStackX_c + lVar17) & 0xffff0000;
            *(undefined8 *)(&stack0x00000000 + lVar17) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101e9c;
            func_0x((longlong)&stack0x00000000 + lVar17);
          }
        }
        goto code_r0x001022cc;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101e4a;
      func_0x
                (uVar5,(longlong)(int)uVar16,ppbVar20,
                 *(undefined4 *)((longlong)auStackX_18 + lVar17));
      if (auStackX_18[0] == 0) goto code_r0x001021a3;
      uVar39 = (ulonglong)uStack_4158 & 0xffffffff;
      puVar28 = uStack_5268;
    }
    lVar21 = *(longlong *)(&stack0x00000000 + lVar17);
    if (lVar21 == 0) goto code_r0x001022cc;
    iVar12 = (int)*(short *)((longlong)auStackX_c + lVar17);
    if (((*(ushort *)(lVar21 + 0x62) >> 10 & 1) != 0) && (2 < iVar12)) {
code_r0x00101fc4:
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101fce;
      func_0x((longlong)&stack0x00000000 + lVar17);
      goto code_r0x001022cc;
    }
    plVar18 = *(longlong **)(&stack0x00000000 + lVar17);
    if (((byte)*(undefined2 *)(lVar21 + 0x62) >> 3 & 1) != 0) {
      if (iVar12 == 3) {
        iVar12 = 4;
      }
      else if (iVar12 < 2) goto code_r0x00102109;
      if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar17) + 100) & 8) != 0) &&
          (lVar21 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar17) + 0x90), lVar21 != 0)) &&
         (*(longlong *)(lVar21 + 0x758) != 0)) {
        uVar5 = *(undefined8 *)(lVar21 + 0x758);
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102109;
        func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar17),iVar12);
      }
    }
code_r0x00102109:
    if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar18 + 100) & 8) != 0)) &&
       ((2 < iVar12 &&
        (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) != 0x40000000 &&
         (lVar21 = *plVar18, lVar21 != 0)))))) {
      puVar33 = auStack_51b8;
code_r0x00102139:
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10214a;
      iVar15 = (*_DAT_)(lVar21,0x2000,2,puVar33);
      if (iVar15 != 0) {
        LOCK();
        *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) & 0x3fffffff;
        UNLOCK();
        LOCK();
        *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) | 0x40000000;
        UNLOCK();
      }
    }
code_r0x0010215e:
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10216c;
    func_0x(plVar18 + 0x13,iVar12);
    if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10218b;
      func_0x(plVar18,0,iVar12);
    }
    *(undefined8 *)(&stack0x00000000 + lVar17) = 0;
    *(uint *)((longlong)auStackX_c + lVar17) = *(uint *)((longlong)auStackX_c + lVar17) & 0xffff0000
    ;
    goto code_r0x001022cc;
  }
code_r0x001021a3:
  auStackX_18[0] = auStackX_18[0] - 1;
  lVar21 = *(longlong *)(&stack0x00000000 + lVar17);
  if (lVar21 == 0) goto code_r0x001022cc;
  iVar12 = (int)*(short *)((longlong)auStackX_c + lVar17);
  if (((*(ushort *)(lVar21 + 0x62) >> 10 & 1) != 0) && (2 < iVar12)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1021d8;
    func_0x((longlong)&stack0x00000000 + lVar17);
    goto code_r0x001022cc;
  }
  plVar18 = *(longlong **)(&stack0x00000000 + lVar17);
  if (((byte)*(undefined2 *)(lVar21 + 0x62) >> 3 & 1) != 0) {
    if (iVar12 == 3) {
      iVar12 = 4;
    }
    else if (iVar12 < 2) goto code_r0x0010223d;
    if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar17) + 100) & 8) != 0) &&
        (lVar21 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar17) + 0x90), lVar21 != 0)) &&
       (*(longlong *)(lVar21 + 0x758) != 0)) {
      uVar5 = *(undefined8 *)(lVar21 + 0x758);
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10223d;
      func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar17),iVar12);
    }
  }
code_r0x0010223d:
  if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar18 + 100) & 8) != 0)) &&
     ((2 < iVar12 &&
      (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) != 0x40000000 &&
       (lVar21 = *plVar18, lVar21 != 0)))))) {
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10227e;
    iVar15 = (*_DAT_)(lVar21,0x2000,2,auStack_51b4);
    if (iVar15 != 0) {
      LOCK();
      *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) & 0x3fffffff;
      UNLOCK();
      LOCK();
      *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) | 0x40000000;
      UNLOCK();
    }
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1022a0;
  func_0x(plVar18 + 0x13,iVar12);
  if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1022bf;
    func_0x(plVar18,0,iVar12);
  }
  *(uint *)((longlong)auStackX_c + lVar17) = *(uint *)((longlong)auStackX_c + lVar17) & 0xffff0000;
  *(undefined8 *)(&stack0x00000000 + lVar17) = 0;
code_r0x001022cc:
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1022d6;
  func_0x((longlong)&stack0x00000000 + lVar17);
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1022e8;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar17));
  return;
}

