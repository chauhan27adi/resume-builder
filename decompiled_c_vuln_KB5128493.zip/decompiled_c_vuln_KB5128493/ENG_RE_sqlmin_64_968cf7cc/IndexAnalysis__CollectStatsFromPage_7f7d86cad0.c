
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  char cVar3;
  uint uVar4;
  longlong lVar5;
  short *psVar6;
  ulonglong *puVar7;
  ushort uVar8;
  int iVar9;
  byte bVar10;
  ushort uVar11;
  uint uVar12;
  byte **ppbVar13;
  uint uVar14;
  ushort *puVar15;
  short sVar16;
  ulonglong uVar17;
  byte **ppbVar18;
  undefined4 uVar19;
  longlong unaff_GS_OFFSET;
  bool bVar20;
  undefined auStack_188 [32];
  undefined8 uStack_168;
  int iStack_158;
  uint uStack_150;
  ushort uStack_14c;
  ushort uStack_14a;
  longlong lStack_148;
  undefined8 uStack_140;
  short sStack_138;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined2 uStack_128;
  undefined4 uStack_124;
  undefined2 uStack_120;
  longlong lStack_118;
  undefined8 uStack_110;
  undefined2 uStack_108;
  undefined4 uStack_100;
  short sStack_f8;
  ushort uStack_f6;
  uint uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  ushort uStack_dc;
  undefined2 uStack_da;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined2 uStack_ce;
  ushort uStack_cc;
  undefined2 uStack_ca;
  undefined4 uStack_c8;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [16];
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined8 uStack_88;
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [16];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_188;
  *(longlong *)(param_2 + 0x68) = *(longlong *)(param_2 + 0x68) + 1;
  sStack_f8 = -1;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d8 = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_cc = 0;
  uStack_ca = 0;
  uStack_e8 = (byte **)0x0;
  iStack_c4 = -1;
  if (*(char *)(param_3 + 2) < '\0') {
    *(longlong *)(param_2 + 0x48) = *(longlong *)(param_2 + 0x48) + 1;
  }
  if ((*(int *)(param_1 + 0x14e4) != 0) ||
     (((*(int *)(param_1 + 0xb74) == 0 && (*(int *)(param_1 + 0xbd4) == 1)) &&
      (*(int *)(param_1 + 0x960) == 1)))) {
    uVar14 = *(uint *)(param_3 + 0x20);
    uVar12 = *(uint *)(param_2 + 0x98) & 0xfffffff8;
    sVar16 = *(short *)(param_3 + 0x24);
    if (((uVar14 & 0xfffffff8) != uVar12) || (sVar16 != *(short *)(param_2 + 0x9c))) {
      *(longlong *)(param_2 + 0x88) = *(longlong *)(param_2 + 0x88) + 1;
      sVar16 = *(short *)(param_3 + 0x24);
      uVar14 = *(uint *)(param_3 + 0x20);
    }
    if (((*(uint *)(param_2 + 0x98) != 0) || (*(short *)(param_2 + 0x9c) != 0)) &&
       ((*(short *)(param_2 + 0x9c) == sVar16 &&
        ((uVar12 != (uVar14 & 0xfffffff8) && (uVar12 + 8 != (uVar14 & 0xfffffff8))))))) {
      *(longlong *)(param_2 + 0x90) = *(longlong *)(param_2 + 0x90) + 1;
    }
  }
  iStack_158 = -1;
  if (((*(int *)(param_1 + 0xbd4) == 1) &&
      ((*(int *)(param_2 + 0x98) + 1 != *(int *)(param_3 + 0x20) ||
       (*(short *)(param_2 + 0x9c) != *(short *)(param_3 + 0x24))))) &&
     ((*(int *)(param_1 + 0xbc4) == 0 || (param_2 != param_1 + 0x7e8)))) {
    *(longlong *)(param_2 + 0x58) = *(longlong *)(param_2 + 0x58) + 1;
  }
  if (((*(int *)(param_1 + 3000) != 0) && (param_2 != param_1 + 0x7e8)) &&
     ((*(int *)(param_3 + 8) != *(int *)(param_2 + 0x98) ||
      (*(short *)(param_3 + 0xc) != *(short *)(param_2 + 0x9c))))) {
    *(longlong *)(param_2 + 0x78) = *(longlong *)(param_2 + 0x78) + 1;
  }
  *(undefined4 *)(param_2 + 0x98) = *(undefined4 *)(param_3 + 0x20);
  *(undefined2 *)(param_2 + 0x9c) = *(undefined2 *)(param_3 + 0x24);
  uVar8 = *(ushort *)(param_3 + 0x16);
  uVar14 = (uint)uVar8;
  if (((*(byte *)(param_3 + 4) & 8) != 0) && (uVar17 = (ulonglong)(uint)uVar8, uVar8 != 0)) {
    psVar6 = (short *)(param_3 + 0x1ffe);
    do {
      sVar16 = *psVar6;
      psVar6 = psVar6 + -1;
      uVar12 = uVar14 - 1;
      if (sVar16 != 0) {
        uVar12 = uVar14;
      }
      uVar14 = uVar12;
      uVar17 = uVar17 - 1;
    } while (uVar17 != 0);
  }
  lStack_148 = -1;
  *(longlong *)(param_2 + 8) =
       *(longlong *)(param_2 + 8) + (longlong)(int)(uVar14 - *(ushort *)(param_3 + 0x3a));
  lStack_118 = param_1;
  while( true ) {
    ppbVar13 = (byte **)0x0;
    uVar14 = 1;
    uVar8 = *(ushort *)(param_3 + 0x16);
    lStack_148 = lStack_148 + 1;
    iStack_158 = iStack_158 + 1;
    if ((longlong)(ulonglong)uVar8 <= lStack_148) break;
    psVar6 = (short *)(param_3 + (0xfff - lStack_148) * 2);
    while (*psVar6 == 0) {
      iStack_158 = iStack_158 + 1;
      lStack_148 = lStack_148 + 1;
      psVar6 = psVar6 + -1;
      if ((longlong)(ulonglong)uVar8 <= lStack_148) goto LAB_;
    }
    if (iStack_158 == -1) break;
    lVar5 = 0xfff - lStack_148;
    if (*(short *)(param_3 + lVar5 * 2) != 0) {
      iStack_c4 = iStack_158;
      if (*(char *)(param_3 + 2) < '\0') {
        pbVar2 = (byte *)(param_3 + 0x60);
        if ((sStack_f8 == 0) || (ppbVar13 = uStack_e8, uStack_e8 == (byte **)0x0)) {
          ppbVar13 = (byte **)auStack_c0;
          auStack_b0 = ZEXT816(0);
          uStack_98 = 0;
          auStack_b0._0_2_ = 0xffff;
          uStack_8a = 0;
          auStack_b0 = ZEXT416((uint)auStack_b0._0_4_);
          uStack_92 = 0;
          uStack_90 = 0;
          uStack_88 = 0;
          auStack_70 = ZEXT816(0);
          uStack_a0 = 0;
          auStack_c0 = ZEXT816(0);
          auStack_80 = ZEXT816(0);
          auStack_60._0_12_ = ZEXT812(0);
          auStack_60._12_4_ = 0;
          uStack_50 = 0;
        }
        if (*(short *)(param_3 + 0x24) == 0) {
LAB_:
          uStack_140 = *(undefined8 *)(param_3 + 0x28);
          sStack_138 = *(short *)(param_3 + 0x30);
        }
        else {
          cVar3 = *(char *)(param_3 + 1);
          if (cVar3 == '\v') {
            if (*(int *)(param_3 + 0x18) != 99) {
LAB_:
              if (cVar3 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar3 != '\b') goto LAB_;
LAB_:
            if (*(int *)(param_3 + 0x18) != 99) goto LAB_;
          }
          uStack_12c = *(undefined4 *)(param_3 + 0x20);
          uStack_128 = *(undefined2 *)(param_3 + 0x24);
          cVar3 = func_0x(&uStack_12c);
          if (cVar3 == '\0') goto LAB_;
          func_0x(param_3,&uStack_140);
        }
        iVar9 = (int)((ulonglong)uStack_140 >> 0x20);
        if (((((pbVar2 != *ppbVar13) || (sStack_138 != *(short *)(ppbVar13 + 0xd))) ||
             ((int)uStack_140 != *(int *)(ppbVar13 + 0xc))) ||
            ((iVar9 != *(int *)((longlong)ppbVar13 + 100) ||
             (*(int *)(param_3 + 0x20) != *(int *)((longlong)ppbVar13 + 0x6c))))) ||
           (param_1 = lStack_118, *(short *)(param_3 + 0x24) != *(short *)(ppbVar13 + 0xe))) {
          *ppbVar13 = pbVar2;
          *(short *)(ppbVar13 + 0xd) = sStack_138;
          *(int *)(ppbVar13 + 0xc) = (int)uStack_140;
          *(int *)((longlong)ppbVar13 + 100) = iVar9;
          *(undefined4 *)((longlong)ppbVar13 + 0x6c) = *(undefined4 *)(param_3 + 0x20);
          *(undefined2 *)(ppbVar13 + 0xe) = *(undefined2 *)(param_3 + 0x24);
          *(undefined2 *)((longlong)ppbVar13 + 0x72) = 0;
          uStack_100 = *(undefined4 *)((ulonglong)*pbVar2 * 6 + 0xb01400);
          uVar17 = (ulonglong)*(short *)((ulonglong)*pbVar2 * 6 + 0xb01404);
          *(undefined2 *)(ppbVar13 + 2) = 0xffff;
          ppbVar13[3] = (byte *)0x0;
          uVar12 = 0;
          *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
          ppbVar13[7] = (byte *)0x0;
          ppbVar13[4] = (byte *)0x0;
          ppbVar13[9] = (byte *)0x0;
          ppbVar13[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar13 + 0xb) = 0;
          if ((**ppbVar13 & 2) != 0) {
            pbVar1 = pbVar2 + uVar17;
            if ((pbVar2[uVar17] & 1) == 0) {
              *(undefined2 *)(ppbVar13 + 2) = 0;
              ppbVar13[3] = pbVar1;
              *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar13 + 0x36) = 0;
              switch(*pbVar1 & 0xe) {
              default:
                uVar12 = (uint)*(ushort *)(pbVar1 + 2);
                if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                  func_0x(pbVar1,6);
                }
                break;
              case 4:
                uVar12 = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar12 = 1;
              }
              *(uint *)(ppbVar13 + 4) = uVar12;
              *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
            }
            else {
              *(undefined2 *)(ppbVar13 + 2) = 1;
              ppbVar13[3] = pbVar1;
              bVar10 = *pbVar1;
              switch(bVar10 & 0x1c) {
              default:
                if ((char)pbVar1[1] < '\0') {
                  uVar8 = *(ushort *)(pbVar1 + 1);
                  sVar16 = 3;
                  *(ushort *)((longlong)ppbVar13 + 0x12) = uVar8;
                  uVar8 = (uVar8 & 0x7f) << 8 | uVar8 >> 8;
                }
                else {
                  sVar16 = 2;
                  uVar8 = (ushort)pbVar1[1];
                }
                *(ushort *)((longlong)ppbVar13 + 0x12) = uVar8;
                *(short *)(ppbVar13 + 5) = sVar16;
                uVar8 = *(ushort *)((longlong)ppbVar13 + 0x12);
                *(short *)((longlong)ppbVar13 + 0x2c) = (short)(uVar8 + 1 >> 1) + sVar16;
                if (uVar8 < 0x1f) {
                  *(undefined2 *)((longlong)ppbVar13 + 0x2a) = 0;
                  *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
                  *(undefined4 *)(ppbVar13 + 8) = 0;
                  ppbVar13[7] = (byte *)0x0;
                  ppbVar13[4] = (byte *)0x0;
                }
                else {
                  iVar9 = uVar8 - 1;
                  *(short *)((longlong)ppbVar13 + 0x2a) =
                       ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                       (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
                  *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
                  *(undefined4 *)(ppbVar13 + 8) = 0;
                  ppbVar13[7] = (byte *)0x0;
                  ppbVar13[4] = (byte *)0x0;
                }
                break;
              case 4:
                if (((bVar10 & 0x1c) != 4) || (uVar4 = uVar14, (bVar10 & 2) == 0)) {
                  uVar4 = uVar12;
                }
                if (uVar4 != 0) {
                  *(undefined4 *)(ppbVar13 + 8) = 0;
                  uVar14 = 0xf;
                }
                ppbVar13[5] = (byte *)0x0;
                *(undefined2 *)((longlong)ppbVar13 + 0x12) = 0;
                ppbVar13[6] = (byte *)0x0;
                ppbVar13[4] = (byte *)0x0;
                ppbVar13[7] = (byte *)0x0;
                ppbVar13[3] = pbVar1;
                *(uint *)((longlong)ppbVar13 + 0x14) = uVar14;
                *(uint *)(ppbVar13 + 8) = (uint)(uVar4 != 0);
                ppbVar13[7] = (byte *)0x0;
                ppbVar13[4] = (byte *)0x0;
                break;
              case 8:
                ppbVar13[7] = (byte *)0x0;
                ppbVar13[7] = (byte *)0x0;
                ppbVar13[5] = (byte *)0x0;
                *(undefined2 *)((longlong)ppbVar13 + 0x12) = 0;
                ppbVar13[6] = (byte *)0x0;
                ppbVar13[4] = (byte *)0x0;
                ppbVar13[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar13 + 0x14) = 9;
                *(undefined4 *)(ppbVar13 + 8) = 0;
                ppbVar13[4] = (byte *)0x0;
              }
            }
          }
          if ((**ppbVar13 & 4) != 0) {
            if (uStack_100._2_2_ != 0) {
              uVar17 = (ulonglong)*(ushort *)(param_3 + 0x61 + (longlong)uStack_100._2_2_ * 2);
            }
            psVar6 = (short *)(pbVar2 + uVar17);
            ppbVar13[9] = (byte *)psVar6;
            sVar16 = *psVar6;
            ppbVar13[10] = (byte *)(psVar6 + 1);
            *(short *)(ppbVar13 + 0xb) = (sVar16 + 1) * 2;
          }
          param_1 = lStack_118;
          if (ppbVar13[1] != (byte *)0x0) {
            func_0x(ppbVar13[1],ppbVar13);
            param_1 = lStack_118;
          }
        }
      }
      uVar14 = (uint)*(ushort *)(param_3 + 0xe);
      pbStack_f0 = (byte *)((ulonglong)*(ushort *)(param_3 + lVar5 * 2) + param_3);
      if ((*pbStack_f0 & 1) == 0) {
        sStack_f8 = 0;
        uStack_f4 = 0;
        uStack_d2 = 0;
        uStack_d0 = 0;
        switch(*pbStack_f0 & 0xe) {
        default:
          uVar14 = (uint)*(ushort *)(pbStack_f0 + 2);
          if (0x1f9d < *(ushort *)(pbStack_f0 + 2) - 1) {
            func_0x(pbStack_f0,6);
          }
          break;
        case 4:
          uVar14 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar14 = 1;
        }
        uStack_e8 = (byte **)CONCAT44(uStack_e8._4_4_,uVar14);
        lVar5 = param_3 + 0x2000;
        if (param_3 == 0) {
          lVar5 = 0;
        }
        uStack_da = (undefined2)lVar5;
        uStack_d8 = (undefined6)((ulonglong)lVar5 >> 0x10);
      }
      else {
        sStack_f8 = 1;
        bVar10 = *pbStack_f0;
        switch(bVar10 & 0x1c) {
        default:
          if ((char)pbStack_f0[1] < '\0') {
            uStack_e0._0_2_ = 3;
            uStack_f6 = (*(ushort *)(pbStack_f0 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_f0 + 1) >> 8
            ;
          }
          else {
            uStack_f6 = (ushort)pbStack_f0[1];
            uStack_e0._0_2_ = 2;
          }
          uStack_dc = (short)(uStack_f6 + 1 >> 1) + (short)uStack_e0;
          if (uStack_f6 < 0x1f) {
            uStack_e0._2_2_ = 0;
            uStack_f4 = 0;
            uStack_c8 = 0;
          }
          else {
            iVar9 = uStack_f6 - 1;
            uStack_f4 = 0;
            uStack_c8 = 0;
            uStack_e0._2_2_ =
                 ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                 (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
          }
          break;
        case 4:
          if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
            uStack_e0._0_2_ = 0;
            uStack_e0._2_2_ = 0;
            uStack_dc = 0;
            uStack_da = 0;
            uStack_f6 = 0;
            uStack_d8 = 0;
            uStack_d2 = 0;
            uStack_f4 = 0xf;
            uStack_c8 = 1;
          }
          else {
            uStack_e0._0_2_ = 0;
            uStack_e0._2_2_ = 0;
            uStack_dc = 0;
            uStack_da = 0;
            uStack_f6 = 0;
            uStack_d8 = 0;
            uStack_d2 = 0;
            uStack_f4 = 1;
            uStack_c8 = 0;
          }
          break;
        case 8:
          uStack_e0._0_2_ = 0;
          uStack_e0._2_2_ = 0;
          uStack_dc = 0;
          uStack_da = 0;
          uStack_f6 = 0;
          uStack_d8 = 0;
          uStack_d2 = 0;
          uStack_f4 = 9;
          uStack_c8 = 0;
        }
        lVar5 = param_3 + 0x2000;
        if (param_3 == 0) {
          lVar5 = 0;
        }
        uStack_d0 = (undefined2)lVar5;
        uStack_ce = (undefined2)((ulonglong)lVar5 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar5 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar5 >> 0x30);
        uStack_e8 = ppbVar13;
      }
      if ((bRam0000000001424438 & 2) == 0) {
        if (sStack_f8 == 0) {
          func_0x();
        }
        else {
          func_0x(&uStack_f6,&uStack_150);
        }
        cVar3 = func_0x(&uStack_150);
        uVar8 = uStack_14a;
        if (cVar3 == '\0') {
          uVar14 = (uint)(int)(short)uStack_14a >> 0xd & 1;
          uVar12 = (uint)(int)(short)uStack_14a >> 0xe & 1;
          uVar11 = uStack_14a;
          if (uVar14 != uVar12) {
            uVar11 = uStack_14a & 0xdfff;
            if ((uStack_14a & 0x4000) != 0) {
              uVar11 = uStack_14a | 0x2000;
            }
          }
          if (uVar11 != 0xffff) {
            uVar11 = uStack_14a;
            if (uVar14 != uVar12) {
              uVar11 = uStack_14a & 0xdfff;
              if ((uStack_14a & 0x4000) != 0) {
                uVar11 = uStack_14a | 0x2000;
              }
            }
            if (uVar11 != 0xfffd) {
              *(longlong *)(param_2 + 0xa0) = *(longlong *)(param_2 + 0xa0) + 1;
              uVar11 = uStack_14a;
              if (uVar14 != uVar12) {
                uVar11 = uStack_14a & 0xdfff;
                if ((uStack_14a & 0x4000) != 0) {
                  uVar11 = uStack_14a | 0x2000;
                }
              }
              if (uVar11 == 0xfffc) {
                *(longlong *)(param_2 + 0xa8) = *(longlong *)(param_2 + 0xa8) + 1;
                uVar11 = uStack_14a;
                if (uVar14 != uVar12) {
                  uVar11 = uStack_14a & 0xdfff;
                  if ((uStack_14a & 0x4000) != 0) {
                    uVar11 = uStack_14a | 0x2000;
                  }
                }
                if (uVar11 == 0xfffc) {
                  uVar11 = uStack_14c & 0x1f;
                }
                else {
                  uStack_168 = 0;
                  (*pcRam0000000000982710)(1,0xe8ecf8,0xe88860,0x4ba);
                  uVar11 = uStack_14c;
                }
                if (uVar11 == 2) {
                  *(longlong *)(param_2 + 0xb0) = *(longlong *)(param_2 + 0xb0) + 1;
                }
                uVar17 = 0;
                uVar11 = uVar8;
                if (uVar14 != uVar12) {
                  uVar11 = uVar8 & 0xdfff;
                  if ((uVar8 >> 0xe & 1) != 0) {
                    uVar11 = uVar8 | 0x2000;
                  }
                }
                if (uVar11 == 0xfffc) {
                  uVar17 = (ulonglong)(uStack_14c >> 5);
                }
                *(longlong *)(param_2 + 0xb8) = *(longlong *)(param_2 + 0xb8) + uVar17;
              }
              else if ((uStack_150 & 0x80000000) != 0) {
                if (uVar14 != uVar12) {
                  uVar8 = uStack_14a & 0xdfff;
                  if ((uStack_14a & 0x4000) != 0) {
                    uVar8 = uStack_14a | 0x2000;
                  }
                }
                if (uVar8 == 0xfffc) {
                  uStack_168 = 0;
                  (*pcRam0000000000982710)(1,0xeaf120,0xe88860,0x4ec);
                }
                cVar3 = func_0x(&uStack_150);
                if (cVar3 == '\0') {
                  cVar3 = func_0x(&uStack_150);
                  if ((cVar3 == '\0') && ((uStack_14a & 0x8000) != 0)) {
                    *(longlong *)(param_2 + 200) = *(longlong *)(param_2 + 200) + 1;
                    goto code_r0x00100b3e;
                  }
                }
                *(longlong *)(param_2 + 0xc0) = *(longlong *)(param_2 + 0xc0) + 1;
              }
            }
          }
        }
      }
code_r0x00100b3e:
      uVar19 = 0;
      bVar20 = false;
      if (sStack_f8 == 0) {
        bVar10 = *pbStack_f0 & 0xe;
        if (bVar10 == 2) {
          bVar20 = (pbStack_f0[1] & 1) != 0;
        }
        else if (((bVar10 - 10 & 0xf9) == 0) && (bVar10 != 0x10)) {
          bVar20 = true;
        }
      }
      else {
        bVar20 = ((*pbStack_f0 & 0x1c) - 4 & 0xffffffe7) == 0;
      }
      if (bVar20) {
        if (*(short *)(param_3 + 0x24) == 0) {
code_r0x00100c06:
          uStack_110 = *(undefined8 *)(param_3 + 0x28);
          uStack_108 = *(undefined2 *)(param_3 + 0x30);
        }
        else {
          cVar3 = *(char *)(param_3 + 1);
          if (cVar3 == '\v') {
            if (*(int *)(param_3 + 0x18) != 99) {
code_r0x00100bc9:
              if (cVar3 != '\t') goto code_r0x00100c06;
              goto code_r0x00100bcd;
            }
          }
          else {
            if (cVar3 != '\b') goto code_r0x00100bc9;
code_r0x00100bcd:
            if (*(int *)(param_3 + 0x18) != 99) goto code_r0x00100c06;
          }
          uStack_124 = *(undefined4 *)(param_3 + 0x20);
          uStack_120 = *(undefined2 *)(param_3 + 0x24);
          uVar19 = 0;
          cVar3 = func_0x(&uStack_124);
          if (cVar3 == '\0') goto code_r0x00100c06;
          func_0x(param_3,&uStack_110);
        }
        uStack_130 = uVar19;
        cVar3 = func_0x
                          (&sStack_f8,&uStack_110,*(undefined8 *)(param_1 + 0xb38),&uStack_130);
        if (cVar3 == '\0') {
          *(longlong *)(param_2 + 0x18) = *(longlong *)(param_2 + 0x18) + 1;
        }
        else {
          *(longlong *)(param_2 + 0x10) = *(longlong *)(param_2 + 0x10) + 1;
        }
      }
      else {
        uVar14 = uStack_e0;
        if (sStack_f8 == 0) {
          if (uStack_f4 == 0) {
            uVar17 = (ulonglong)uStack_e8 & 0xffffffff;
            uStack_f6 = 0;
            uVar14 = (uint)uStack_e8;
            if ((*pbStack_f0 & 0x10) != 0) {
              uVar14 = (uint)uStack_e8 + 2 + (*(ushort *)(pbStack_f0 + uVar17) + 7 >> 3);
              uVar17 = (ulonglong)uVar14;
            }
            uStack_e8 = (byte **)CONCAT44(uVar14,(uint)uStack_e8);
            uVar14 = (uint)uVar17;
            if ((*pbStack_f0 & 0x20) == 0) {
              uStack_dc = 0;
              uStack_f4 = uVar14;
            }
            else {
              puVar15 = (ushort *)(pbStack_f0 + uVar17);
              uStack_dc = *puVar15;
              if (uStack_dc == 0) {
                if ((((cRam0000000001413eeb != '\0') || ((bRam00000000014247f0 & 1) != 0)) &&
                    (lVar5 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam0000000000982778 * 8) + 8 +
                              (ulonglong)*puRam0000000000982780), lVar5 != 0)) &&
                   ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                    (*(char *)(lVar5 + 0x499) != '\0')))) {
                  if ((cRam0000000001413ddb == '\0') && ((bRam00000000014247f0 & 2) == 0)) {
                    (*pcRam0000000000982718)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_168 = 0;
                    (*pcRam0000000000982710)(1,0xd04918,0xe245e8,0x80f);
                  }
                }
                func_0x(pbStack_f0,3);
                uVar17 = (ulonglong)uStack_e8 >> 0x20;
              }
              uStack_e0 = (int)uVar17 + (uStack_dc + 1) * 2;
              if (0x1f9e < uStack_e0) {
                if (((cRam0000000001413eeb != '\0') || ((bRam00000000014247f0 & 1) != 0)) &&
                   ((lVar5 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam0000000000982778 * 8) + 8 +
                              (ulonglong)*puRam0000000000982780), lVar5 != 0 &&
                    ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                     (*(char *)(lVar5 + 0x499) != '\0')))))) {
                  if ((cRam0000000001413ddb == '\0') && ((bRam00000000014247f0 & 2) == 0)) {
                    (*pcRam0000000000982718)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_168 = 0;
                    (*pcRam0000000000982710)(1,0xd04918,0xe245e8,0x816);
                  }
                }
                func_0x(pbStack_f0,4);
                uVar17 = (ulonglong)uStack_e8 >> 0x20;
              }
              uStack_f4 = puVar15[uStack_dc] & 0x7fff;
              uVar14 = uStack_e0;
              if (uStack_f4 < uStack_e0) {
                if ((((cRam0000000001413eeb != '\0') || ((bRam00000000014247f0 & 1) != 0)) &&
                    (lVar5 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam0000000000982778 * 8) + 8 +
                              (ulonglong)*puRam0000000000982780), lVar5 != 0)) &&
                   ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                    (*(char *)(lVar5 + 0x499) != '\0')))) {
                  if ((cRam0000000001413ddb == '\0') && ((bRam00000000014247f0 & 2) == 0)) {
                    (*pcRam0000000000982718)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_168 = 0;
                    (*pcRam0000000000982710)(1,0xd04918,0xe245e8,0x81d);
                  }
                }
                func_0x(pbStack_f0,4);
                uVar17 = (ulonglong)uStack_e8 >> 0x20;
                uVar14 = uStack_e0;
              }
              do {
                if (-1 < (short)puVar15[(ulonglong)(uStack_dc - 1) + 1]) break;
                uVar12 = uStack_e0;
                if (((uStack_dc != 1) &&
                    (uVar12 = *(ushort *)(pbStack_f0 + (ulonglong)uStack_dc * 2 + (uVar17 - 2)) &
                              0x7fff, uVar12 < uStack_e0)) ||
                   ((*(ushort *)(pbStack_f0 + (ulonglong)uStack_dc * 2 + uVar17) & 0x7fff) < uVar12)
                   ) {
                  uStack_e0 = uVar14;
                  func_0x(pbStack_f0,7);
                  uVar17 = (ulonglong)uStack_e8 >> 0x20;
                  uVar14 = uStack_e0;
                }
                if ((uVar12 < uStack_e0) || (uStack_f4 < uVar12)) goto code_r0x00101263;
                if (*(ushort *)(pbStack_f0 + uVar12) == 5) {
                  uStack_f6 = uStack_f6 | 2;
                  uStack_dc = uStack_dc - 1;
                  uStack_ce = (undefined2)uVar12;
                  if ((*(ushort *)(pbStack_f0 + (ulonglong)(uVar12 & 0xffff) + 2) & 0x4000) == 0) {
                    uStack_cc = uStack_cc & 0xc7ff;
                  }
                  else {
                    uStack_cc = uStack_cc ^
                                (uStack_cc ^
                                *(ushort *)(pbStack_f0 + (ulonglong)(uVar12 & 0xffff) + 2)) & 0x3800
                    ;
                  }
                  uStack_cc = uStack_cc ^
                              (uStack_cc ^
                              *(ushort *)(pbStack_f0 + (ulonglong)(uVar12 & 0xffff) + 2)) & 0x7ff;
                  break;
                }
                if (*(ushort *)(pbStack_f0 + uVar12) < 0x400) break;
                uStack_f6 = uStack_f6 | 1;
                uStack_dc = uStack_dc - 1;
              } while (uStack_dc != 0);
            }
            if ((*pbStack_f0 & 0x40) == 0) {
              uStack_d2 = 0;
              uStack_d0 = 0;
            }
            else {
              uStack_d2 = (undefined2)uStack_f4;
              uStack_d0 = (undefined2)(uStack_f4 >> 0x10);
              uStack_f4 = uStack_f4 + 0xe;
              uStack_e0 = uVar14;
              puVar7 = (ulonglong *)func_0x(&uStack_f6);
              iVar9 = 0;
              uVar17 = *puVar7;
              uVar11 = (ushort)(uVar17 >> 0x30);
              uVar8 = uVar11;
              if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
                uVar8 = uVar11 & 0xdfff;
                if ((uVar17 & 0x4000000000000000) != 0) {
                  uVar8 = uVar11 | 0x2000;
                }
              }
              if (uVar8 == 0xfffc) {
                iVar9 = (int)((uVar17 >> 0x20 & 0xffff) >> 5);
              }
              uStack_f4 = uStack_f4 + iVar9;
              uVar14 = uStack_e0;
            }
            uStack_e0 = uVar14;
            if (((byte *)CONCAT62(uStack_d8,uStack_da) != (byte *)0x0) &&
               ((byte *)CONCAT62(uStack_d8,uStack_da) < pbStack_f0 + uStack_f4)) {
              if (((cRam0000000001413eeb != '\0') || ((bRam00000000014247f0 & 1) != 0)) &&
                 (((lVar5 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam0000000000982778 * 8) + 8 +
                             (ulonglong)*puRam0000000000982780), lVar5 != 0 &&
                   (lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0)) &&
                  (*(char *)(lVar5 + 0x499) != '\0')))) {
                if ((cRam0000000001413ddb == '\0') && ((bRam00000000014247f0 & 2) == 0)) {
                  (*pcRam0000000000982718)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  uStack_168 = 0;
                  (*pcRam0000000000982710)(1,0xd04918,0xe245e8,0x877);
                }
              }
              func_0x(pbStack_f0,0x12);
            }
            uVar14 = uStack_e0;
            if (0x3f3b < uStack_f4 - 1) {
              if (((cRam0000000001413eeb != '\0') || ((bRam00000000014247f0 & 1) != 0)) &&
                 ((lVar5 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam0000000000982778 * 8) + 8 +
                            (ulonglong)*puRam0000000000982780), lVar5 != 0 &&
                  ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                   (*(char *)(lVar5 + 0x499) != '\0')))))) {
                if ((cRam0000000001413ddb == '\0') && ((bRam00000000014247f0 & 2) == 0)) {
                  (*pcRam0000000000982718)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  uStack_168 = 0;
                  (*pcRam0000000000982710)(1,0xd04918,0xe245e8,0x87c);
                }
              }
              func_0x(pbStack_f0,5);
              uVar14 = uStack_e0;
            }
          }
code_r0x00101263:
          uVar12 = uStack_f4;
          if (uStack_f4 < 9) {
            bVar10 = *pbStack_f0 & 0xe;
joined_r0x0010129c:
            if ((bVar10 == 0) || (uVar12 = uStack_f4, bVar10 == 0xc)) {
              uVar12 = 9;
            }
          }
        }
        else {
          if (uStack_f4 == 0) {
            func_0x(&uStack_f6);
            uVar14 = uStack_e0;
          }
          uVar12 = uStack_f4;
          if (uStack_f4 < 9) {
            bVar10 = *pbStack_f0 & 0x1c;
            goto joined_r0x0010129c;
          }
        }
        *(longlong *)(param_2 + 0x28) = *(longlong *)(param_2 + 0x28) + (ulonglong)uVar12;
        if (uVar12 < *(uint *)(param_2 + 0x20)) {
          *(uint *)(param_2 + 0x20) = uVar12;
        }
        if (*(uint *)(param_2 + 0x24) < uVar12) {
          *(uint *)(param_2 + 0x24) = uVar12;
        }
        uStack_e0 = uVar14;
        if (*(int *)(param_1 + 0xb74) == 0) {
          if (sStack_f8 == 0) {
            bVar20 = (*pbStack_f0 & 0xe) == 4;
          }
          else {
            bVar20 = (*pbStack_f0 & 0x1c) == 8;
          }
          if (bVar20) {
            *(longlong *)(param_2 + 0x40) = *(longlong *)(param_2 + 0x40) + 1;
          }
        }
      }
    }
  }
LAB_:
  ppbVar18 = (byte **)0x2;
  if (uVar8 != 0) {
    ppbVar18 = ppbVar13;
  }
  *(longlong *)(param_2 + 0x70) =
       *(longlong *)(param_2 + 0x70) + ((ulonglong)*(ushort *)(param_3 + 0x1c) - (longlong)ppbVar18)
  ;
  func_0x(uStack_48 ^ (ulonglong)auStack_188);
  return;
}

