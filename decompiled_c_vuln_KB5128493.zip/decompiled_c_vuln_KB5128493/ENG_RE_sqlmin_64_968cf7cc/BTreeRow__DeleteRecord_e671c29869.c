
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x01125895) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,ulonglong param_3,longlong param_4,longlong param_5,
                 undefined4 param_6)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  uint uVar6;
  uint uVar7;
  longlong **pplVar8;
  byte bVar9;
  char cVar10;
  byte bVar11;
  int iVar12;
  undefined8 uVar13;
  uint uVar14;
  byte bVar15;
  longlong unaff_GS_OFFSET;
  undefined auStack_378 [32];
  undefined8 uStack_358;
  uint uStack_350;
  uint uStack_348;
  longlong *plStack_340;
  undefined4 *puStack_338;
  uint uStack_330;
  undefined8 uStack_328;
  ulonglong uStack_320;
  int *piStack_318;
  undefined4 *puStack_310;
  char cStack_2b8;
  longlong lStack_2b0;
  undefined uStack_2a4;
  char cStack_2a3;
  char cStack_2a2;
  undefined uStack_2a1;
  longlong **pplStack_2a0;
  int iStack_298;
  int iStack_294;
  undefined4 auStack_290 [2];
  longlong lStack_288;
  int iStack_280;
  byte bStack_278;
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined8 uStack_268;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  uint uStack_258;
  undefined4 uStack_254;
  int iStack_250;
  undefined2 uStack_24c;
  undefined2 uStack_24a;
  longlong lStack_230;
  undefined4 *puStack_228;
  longlong lStack_1e8;
  undefined8 uStack_1b0;
  undefined8 uStack_188;
  longlong lStack_180;
  undefined8 uStack_178;
  uint uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined uStack_10a;
  undefined4 uStack_e8;
  undefined2 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined2 uStack_d8;
  undefined2 uStack_d6;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  undefined4 *puStack_b8;
  undefined4 *puStack_b0;
  undefined *puStack_a8;
  undefined2 uStack_a0;
  undefined uStack_9e;
  undefined4 uStack_98;
  undefined auStack_94 [60];
  ulonglong uStack_58;
  
  uStack_178 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_378;
  param_3 = param_3 & 0xffffffff;
  lStack_230 = param_5;
  uStack_270 = uStack_270 & 0xffffffc0;
  uStack_270._0_3_ = (uint3)(byte)uStack_270;
  uStack_268 = 0;
  lStack_288 = 0;
  iStack_280 = 0;
  uStack_10a = 1;
  uStack_1b0 = 0;
  plVar2 = (longlong *)(*(longlong **)(param_1 + 0x28))[1];
  lVar3 = **(longlong **)(param_1 + 0x28);
  uStack_258 = (uint)(*(int *)(*(longlong *)(lVar3 + 8) + 0x100) == 2);
  uStack_254 = 0;
  auStack_290[0] = 0;
  cStack_2b8 = '\0';
  lVar4 = *(longlong *)(param_4 + 0x10);
  uVar13 = *(undefined8 *)(lVar3 + 0x14);
  lStack_2b0 = lVar3;
  iStack_250 = param_2;
  lStack_1e8 = lVar4;
  lStack_180 = param_4;
  uStack_d0 = func_0x(lVar3);
  uStack_e8 = 0;
  uStack_e4 = 0;
  uStack_e0 = 0;
  uStack_d6 = 0;
  uStack_c8 = _DAT_;
  uStack_c0 = uRam0000000002573778;
  puStack_b8 = &uStack_98;
  puStack_a8 = auStack_94;
  uStack_a0 = 0;
  uStack_9e = 0;
  puStack_b0 = &uStack_98;
  uStack_98 = 0x4000000;
  uStack_dc = (undefined4)uVar13;
  uStack_d8 = (undefined2)((ulonglong)uVar13 >> 0x20);
  puStack_228 = (undefined4 *)0x0;
  bStack_278 = ((((byte)(param_3 >> 2) & 1 | -(param_5 != 0) & 2U) * '\x02' | (byte)param_3 & 1) *
                '\x02' | (byte)(param_3 >> 1) & 1) * '\x02' | param_2 == 3 | bStack_278 & 0xe0;
  uStack_260 = *(undefined4 *)(*(longlong *)(param_1 + 0xf8) + 0x24);
  uStack_25c = *(undefined4 *)(*(longlong *)(param_1 + 0x28) + 0x20);
  if ((param_3 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(&uStack_270,lVar3,param_6);
  *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) & 0xfffffeff;
  if (((*(uint *)(param_1 + 0x10) & 0x10080) != 0) ||
     (*(int *)(*(longlong *)(param_1 + 0x18) + 0x60) != 4)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(param_1 + 0x34) & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(param_1);
  uStack_188 = *(undefined8 *)(param_1 + 0x38);
  lVar5 = *(longlong *)(param_1 + 0x18);
  pplStack_2a0 = (longlong **)(lVar5 + 0x30);
  cStack_2a3 = *(char *)(lVar4 + 1);
  if ((((byte)*(undefined4 *)(lVar5 + 4) & 0x24) != 0x24) || (*(int *)(lVar5 + 0x88) == 4)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  cStack_2a2 = *(char *)(lVar5 + 0x78);
  if ((cStack_2a3 != '\x05') && (cStack_2a2 != '\x05')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_2a1 = 0;
  if (*(char *)(*(longlong *)(param_1 + 0x28) + 0x29) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar4 = *(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           0x100);
  if (lVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(lVar4 + 800) & 0x180) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puStack_228 = &uStack_e8;
  uStack_348 = 0;
  uStack_350 = 0;
  uStack_358 = 0;
  func_0x(plVar2,&uStack_e8,&uStack_2a4,lVar3);
  lVar3 = uStack_268;
  if ((*(byte *)(param_1 + 0x10) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  plVar1 = (longlong *)(uStack_268 + 8);
  if ((*(byte *)(*plVar1 + 0x108) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar4 = plVar2[0x1a];
  if (((uStack_270 & 1) == 0) && (cVar10 = (**(code **)*plVar2)(plVar2), cVar10 == '\0')) {
    cVar10 = (**(code **)(*plVar2 + 0x88))(plVar2);
    if (cVar10 != '\0') {
      if (uStack_270._1_1_ != '\0') goto LAB_;
      if (lVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)(plVar2 + 0x4a) & 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if ((uStack_270 & 0x1c) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar5 = *plVar1;
    if (*(int *)(lVar5 + 0x68) < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (0 < *(int *)(lVar5 + 0x68)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar12 = func_0x(lVar3);
    if (iVar12 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((lVar4 != 0) && ((0 < *(int *)(lVar4 + 0x78) || (0 < *(int *)(lVar4 + 0x74))))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)(plVar2 + 0x4a) & 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
LAB_:
  cVar10 = (**(code **)*plVar2)(plVar2);
  if (cVar10 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((((byte)*(undefined4 *)(plVar2 + 0x43) & 5) == 1) && ((*(byte *)(plVar2 + 0x5b) & 2) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(short *)(**pplStack_2a0 + 0x16) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x158) == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_158 = uStack_270;
  uStack_154 = uStack_26c;
  uStack_150 = (undefined4)uStack_268;
  uStack_14c = uStack_268._4_4_;
  puStack_310 = auStack_290;
  piStack_318 = &iStack_294;
  uStack_320 = 0;
  uStack_328 = CONCAT44(uStack_328._4_4_,0x2000);
  uStack_330 = uStack_258;
  puStack_338 = (undefined4 *)0x0;
  plStack_340 = (longlong *)0x0;
  uStack_348 = *(undefined4 *)(param_1 + 0x30);
  uStack_350 = 1;
  uStack_358 = CONCAT44(uStack_358._4_4_,4);
  iVar12 = func_0x(pplStack_2a0,lStack_2b0,plVar2);
  if (iStack_294 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iStack_298 = iVar12;
  cVar10 = (**(code **)(*plVar2 + 0x88))(plVar2);
  bVar9 = bStack_278;
  lVar3 = lStack_2b0;
  if (cVar10 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar12 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((DAT_ & 0x40) == 0) {
    if (lStack_230 == 0) {
      func_0x(&lStack_288,lStack_2b0);
    }
    pplVar8 = pplStack_2a0;
    uVar14 = (uint)(*(char *)(**pplStack_2a0 + 1) == '\x01');
    bVar11 = bVar9 >> 2 & 1;
    bVar15 = bVar9 >> 3 & 1;
    uVar6 = bVar11 | 0x4000;
    if (bVar15 == 0) {
      uVar6 = (uint)bVar11;
    }
    uVar7 = uVar6 | 0x100;
    if ((bVar9 & 0x10) == 0) {
      uVar7 = uVar6;
    }
    iStack_250 = *(int *)(*(longlong *)(*(longlong *)pplStack_2a0[5][1] + 8) + 0x3c0);
    uStack_24c = *(undefined2 *)(*(longlong *)(*(longlong *)pplStack_2a0[5][1] + 8) + 0x3c4);
    uStack_24a = 0;
    uStack_348 = bVar9 >> 1 & 1;
    uStack_330 = uVar7 | 0x1000000;
    if ((uStack_270 & 2) != 0) {
      uStack_330 = uVar7;
    }
    uStack_350 = uVar14 | 0x400000;
    if ((bVar9 & 1) != 0) {
      uStack_350 = uVar14;
    }
    piStack_318 = (int *)0x0;
    uStack_320 = uStack_320 & 0xffffffff00000000;
    uStack_328 = 0;
    puStack_338 = puStack_228;
    uStack_358 = CONCAT44(uStack_358._4_4_,1);
    plStack_340 = plVar2;
    func_0x(pplStack_2a0,(ulonglong)*(uint6 *)(lVar3 + 0x14) << 0x10,&iStack_250,
                    *(undefined4 *)(param_1 + 0x30));
    lVar4 = lStack_288;
    if ((*(uint *)(**pplVar8 + 0x18) & 0xe0000000) == 0x80000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar3 = *(longlong *)(*(longlong *)(lVar3 + 8) + 0x488);
    if (((lVar3 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar3 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      plVar2 = (longlong *)(*(longlong *)(lVar3 + 0x18) + 8);
      *plVar2 = *plVar2 + 1;
      UNLOCK();
    }
    if (bVar15 == 0) {
      if (lStack_230 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (cStack_2b8 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(*(undefined8 *)(lStack_288 + 8));
      func_0x(*(undefined8 *)(lVar4 + 8),0xffffffffffffffff);
      if (iStack_280 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(*(longlong *)(lVar4 + 8) + 0x630,2);
      iStack_280 = 0;
      lStack_288 = 0;
      if (bVar11 == 0) {
        lVar3 = *(longlong *)(lStack_2b0 + 8);
        if ((*(longlong *)(lVar3 + 0x90) != 0) && (DAT_ != '\0')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(uint *)(lVar3 + 0xf4) < 2) {
          if (*(int *)(lVar3 + 0x480) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(longlong *)(lVar3 + 0x150) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          LOCK();
          plVar2 = (longlong *)(*(longlong *)(lVar3 + 0x148) + 8);
          *plVar2 = *plVar2 + 1;
          UNLOCK();
        }
      }
      *(byte *)(param_1 + 0x34) = *(byte *)(param_1 + 0x34) & 0xfe;
      if (*(short *)(**pplStack_2a0 + 0x16) != *(short *)(**pplStack_2a0 + 0x3a)) {
        if ((puStack_228 != (undefined4 *)0x0) && (*(char *)((longlong)puStack_228 + 0x4a) != '\0'))
        {
          *(undefined *)(*(longlong *)(param_1 + 0x28) + 0xb6) = 0;
        }
        *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x100;
        func_0x(uStack_58 ^ (ulonglong)auStack_378);
        return;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

