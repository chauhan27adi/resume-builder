
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,ulonglong param_3,uint param_4,uint param_5,
                 undefined8 param_6,undefined4 param_7,undefined2 param_8,undefined8 param_9,
                 undefined8 *param_10)

{
  byte *pbVar1;
  byte *pbVar2;
  ushort *puVar3;
  undefined8 uVar4;
  undefined auVar5 [16];
  char cVar6;
  int iVar7;
  longlong lVar8;
  ulonglong *puVar9;
  undefined4 *puVar10;
  undefined8 *puVar11;
  longlong lVar12;
  byte bVar13;
  ushort uVar14;
  short sVar15;
  ushort uVar16;
  uint uVar17;
  ulonglong uVar18;
  uint uVar19;
  undefined4 uVar20;
  uint uVar21;
  uint uVar22;
  ulonglong uVar23;
  undefined8 *puVar24;
  undefined *puVar25;
  short sVar26;
  ushort *puVar27;
  uint uVar28;
  ulonglong uVar29;
  longlong unaff_GS_OFFSET;
  short sStackX_10;
  ushort uStackX_12;
  uint uStackX_14;
  byte *pbStackX_18;
  undefined8 uStackX_20;
  uint uStack_20f8;
  uint uStack_20e0;
  undefined2 uStack_20dc;
  undefined8 uStack_20d8;
  undefined2 uStack_20d0;
  int iStack_20c8;
  undefined8 uStack_20c0;
  undefined8 uStack_20b8;
  short sStack_20b0;
  ushort uStack_20ae;
  uint uStack_20ac;
  byte *pbStack_20a8;
  undefined8 uStack_20a0;
  undefined4 uStack_2098;
  ushort uStack_2094;
  undefined2 uStack_2092;
  undefined6 uStack_2090;
  undefined2 uStack_208a;
  undefined2 uStack_2088;
  undefined2 uStack_2086;
  ushort uStack_2084;
  undefined2 uStack_2082;
  undefined4 uStack_2080;
  int iStack_207c;
  undefined auStack_2078 [16];
  undefined auStack_2068 [2];
  undefined auStack_2066 [2];
  undefined auStack_2064 [12];
  uint uStack_2058;
  undefined4 uStack_2054;
  short sStack_2050;
  short sStack_204e;
  short sStack_204c;
  undefined2 uStack_204a;
  undefined6 uStack_2048;
  undefined2 uStack_2042;
  undefined2 uStack_2040;
  undefined6 uStack_203e;
  uint uStack_2038;
  undefined4 uStack_2034;
  short *psStack_2030;
  short *psStack_2028;
  short sStack_2020;
  undefined6 uStack_201e;
  undefined auStack_2018 [10];
  undefined auStack_200e [6];
  ulonglong uStack_2008;
  byte bStack_1ff8;
  undefined auStack_1ff7 [8095];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  iStack_20c8 = param_2;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar8);
  puVar25 = (undefined *)0x0;
  uStack_20e0 = param_5;
  uStack_20c0 = param_6;
  uVar20 = 0xf;
  uVar21 = 0xf;
  uStack_20b8 = param_9;
  sVar26 = 2;
  uVar18 = param_3 & 0xffffffff;
  sStack_20b0 = 0xffff;
  pbStack_20a8 = (byte *)0x0;
  uStack_20ac = 0;
  uStack_2092 = 0;
  uStack_2090 = 0;
  uStack_2088 = 0;
  uStack_2086 = 0;
  uStack_2084 = 0;
  uStack_2082 = 0;
  uStack_20a0 = (undefined *)0x0;
  *(undefined2 *)((longlong)&sStackX_10 + lVar8) = 0xffff;
  *(undefined8 *)((longlong)&pbStackX_18 + lVar8) = 0;
  *(undefined4 *)((longlong)&sStackX_10 + lVar8 + 4) = 0;
  *(undefined8 *)(&stack0x0000002e + lVar8) = 0;
  *(undefined8 *)((longlong)&param_7 + lVar8) = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar8) = 0;
  sVar15 = 2;
  iStack_207c = iStack_20c8;
  if (*(char *)(param_1 + 2) < '\0') {
    pbVar1 = (byte *)(param_1 + 0x60);
    _auStack_2066 = SUB1614(ZEXT816(0),2);
    auStack_2068 = (undefined  [2])0xffff;
    sStack_2050 = 0;
    sStack_204e = 0;
    sStack_204c = 0;
    uStack_2042 = 0;
    auStack_2064._4_8_ = 0;
    uStack_2038 = 0;
    uStack_2034 = 0;
    uStack_204a = 0;
    uStack_2048 = 0;
    uStack_2040 = 0;
    uStack_203e = 0;
    uStack_2058 = 0;
    uStack_2054 = 0;
    psStack_2030 = (short *)0x0;
    _auStack_2018 = ZEXT812(0);
    auStack_200e._2_4_ = 0;
    uStack_2008 = 0;
    psStack_2028 = (short *)0x0;
    sStack_2020 = 0;
    uStack_201e = 0;
    auStack_2078 = ZEXT816(0);
    uVar4 = 0;
    lVar12 = param_1;
    if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
      auStack_2078._8_8_ = uVar4;
      uStack_20d8 = *(undefined8 *)(lVar12 + 0x28);
      uStack_20d0 = *(undefined2 *)(lVar12 + 0x30);
    }
    else {
      cVar6 = *(char *)(param_1 + 1);
      if (cVar6 == '\v') {
        if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
          if (cVar6 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar6 != '\b') goto LAB_;
LAB_:
        if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
      }
      uStack_20d8 = CONCAT26(uStack_20d8._6_2_,*(undefined6 *)(param_1 + 0x20));
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10015d;
      cVar6 = func_0x(&uStack_20d8);
      uVar4 = auStack_2078._8_8_;
      if (cVar6 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10016d;
      func_0x(lVar12,&uStack_20d8);
    }
    auStack_2018._8_2_ = uStack_20d0;
    auStack_2018._0_8_ = uStack_20d8;
    auStack_2078._0_8_ = pbVar1;
    auStack_2068 = (undefined  [2])0xffff;
    auStack_200e._2_4_ = *(undefined4 *)(param_1 + 0x20);
    uStack_2008 = CONCAT62((int6)(uStack_2008 >> 0x10),*(undefined2 *)(param_1 + 0x24)) &
                  0xffffffff0000ffff;
    lVar12 = (ulonglong)*pbVar1 * 6;
    uVar29 = (ulonglong)*(short *)(lVar12 + 0x1118004);
    uStack_20d8 = CONCAT44((int)((ulonglong)uStack_20d8 >> 0x20),*(undefined4 *)(lVar12 + 0x1118000)
                          );
    uVar17 = 0;
    _auStack_2068 = _auStack_2068 & 0xffffffff;
    auStack_2064._4_8_ = 0;
    uStack_204a = 0;
    uStack_2048 = 0;
    uStack_2040 = 0;
    uStack_203e = 0;
    uStack_2058 = 0;
    uStack_2054 = 0;
    sStack_2020 = 0;
    psStack_2030 = (short *)0x0;
    psStack_2028 = (short *)0x0;
    uVar22 = uStack_2058;
    if ((*pbVar1 & 2) != 0) {
      pbVar2 = pbVar1 + uVar29;
      auStack_2064._4_8_ = pbVar2;
      if ((pbVar1[uVar29] & 1) == 0) {
        auVar5._14_2_ = 0;
        auVar5._0_14_ = _auStack_2066;
        _auStack_2068 = auVar5 << 0x10;
        uStack_2042 = 0;
        uStack_2040 = 0;
        uVar22 = uVar17;
        switch(*pbVar2 & 0xe) {
        default:
          uVar16 = *(ushort *)(pbVar2 + 2);
          uVar22 = (uint)uVar16;
          if (0x1f9d < uVar16 - 1) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1003c9;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar22 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar22 = 1;
        }
      }
      else {
        bVar13 = *pbVar2;
        switch(bVar13 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            sStack_2050 = 3;
            auStack_2066 = (undefined  [2])
                           ((*(ushort *)(pbVar2 + 1) & 0x7f) << 8 | *(ushort *)(pbVar2 + 1) >> 8);
          }
          else {
            auStack_2066 = (undefined  [2])(ushort)pbVar2[1];
            sStack_2050 = sVar15;
          }
          auStack_2068 = (undefined  [2])0x1;
          sStack_204c = (short)((ushort)auStack_2066 + 1 >> 1) + sStack_2050;
          if ((ushort)auStack_2066 < 0x1f) {
            uStack_2038 = 0;
            sStack_204e = 0;
            uStack_2040 = 0;
            uStack_203e = 0;
            uStack_2058 = 0;
            uStack_2054 = 0;
            uVar22 = uStack_2058;
          }
          else {
            iVar7 = (ushort)auStack_2066 - 1;
            uStack_2038 = 0;
            uStack_2040 = 0;
            uStack_203e = 0;
            uStack_2058 = 0;
            uStack_2054 = 0;
            sStack_204e = ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                          (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
            uVar22 = uStack_2058;
          }
          break;
        case 4:
          if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
            uVar17 = 1;
          }
          else {
            uVar20 = 1;
          }
          sStack_2050 = 0;
          sStack_204e = 0;
          sStack_204c = 0;
          uStack_2042 = 0;
          auStack_2064._0_4_ = uVar20;
          _auStack_2068 = 1;
          uStack_2040 = 0;
          uStack_203e = 0;
          uStack_2058 = 0;
          uStack_2054 = 0;
          uVar22 = uStack_2058;
          uStack_2038 = uVar17;
          break;
        case 8:
          sStack_2050 = 0;
          sStack_204e = 0;
          sStack_204c = 0;
          uStack_2042 = 0;
          _auStack_2068 = 0x900000001;
          uStack_2038 = 0;
          uStack_2040 = 0;
          uStack_203e = 0;
          uStack_2058 = 0;
          uStack_2054 = 0;
          uVar22 = uStack_2058;
        }
      }
    }
    uStack_2058 = uVar22;
    uStack_2048 = 0;
    uStack_204a = 0;
    if ((*(byte *)auStack_2078._0_8_ & 4) != 0) {
      if (uStack_20d8._2_2_ != 0) {
        uVar29 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)uStack_20d8._2_2_ * 2);
      }
      psStack_2030 = (short *)(pbVar1 + uVar29);
      psStack_2028 = psStack_2030 + 1;
      sStack_2020 = (*psStack_2030 + 1) * 2;
    }
    puVar25 = auStack_2078;
    if (auStack_2078._8_8_ != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10045c;
      func_0x(auStack_2078._8_8_,auStack_2078);
    }
  }
  uVar23 = 9;
  uVar29 = 0;
  pbStack_20a8 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)iStack_20c8) * 2) +
                         param_1);
  if ((*pbStack_20a8 & 1) == 0) {
    sStack_20b0 = 0;
    uStack_20ac = 0;
    uStack_208a = 0;
    uStack_2088 = 0;
    uVar22 = (uint)*(ushort *)(param_1 + 0xe);
    switch(*pbStack_20a8 & 0xe) {
    default:
      uVar16 = *(ushort *)(pbStack_20a8 + 2);
      uVar29 = 0;
      uVar22 = (uint)uVar16;
      if (0x1f9d < uVar16 - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10065e;
        func_0x(pbStack_20a8,6);
        uVar29 = (ulonglong)uStack_20ac;
      }
      break;
    case 4:
      uVar29 = 0;
      uVar22 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar22 = 1;
    }
    uVar17 = (uint)uVar29;
    uStack_20a0 = (undefined *)CONCAT44(uStack_20a0._4_4_,uVar22);
    puVar25 = (undefined *)(ulonglong)uVar22;
    lVar12 = param_1 + 0x2000;
    if (param_1 == 0) {
      lVar12 = 0;
    }
    uStack_2092 = (undefined2)lVar12;
    uStack_2090 = (undefined6)((ulonglong)lVar12 >> 0x10);
  }
  else {
    sStack_20b0 = 1;
    bVar13 = *pbStack_20a8;
    switch(bVar13 & 0x1c) {
    default:
      if ((char)pbStack_20a8[1] < '\0') {
        uStack_20ae = (*(ushort *)(pbStack_20a8 + 1) & 0x7f) << 8 |
                      *(ushort *)(pbStack_20a8 + 1) >> 8;
        uStack_2098._0_2_ = 3;
        sVar15 = 3;
      }
      else {
        uStack_20ae = (ushort)pbStack_20a8[1];
        uStack_2098._0_2_ = 2;
      }
      uStack_2094 = ((ushort)(uStack_20ae + 1) >> 1) + sVar15;
      uVar23 = uVar29;
      if (uStack_20ae < 0x1f) {
        uStack_2098._2_2_ = 0;
        uStack_20ac = 0;
        uStack_2080 = 0;
      }
      else {
        iVar7 = uStack_20ae - 1;
        uStack_20ac = 0;
        uStack_2080 = 0;
        uStack_2098._2_2_ =
             ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
             (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
        uStack_2098._0_2_ = 0;
        uStack_2098._2_2_ = 0;
        uStack_2094 = 0;
        uStack_2092 = 0;
        uVar23 = 0xf;
        uStack_20ae = 0;
        uStack_2090 = 0;
        uStack_208a = 0;
        uStack_20ac = 0xf;
        uStack_2080 = 1;
      }
      else {
        uStack_2098._0_2_ = 0;
        uStack_2098._2_2_ = 0;
        uStack_2094 = 0;
        uStack_2092 = 0;
        uVar23 = 1;
        uStack_20ae = 0;
        uStack_2090 = 0;
        uStack_208a = 0;
        uStack_20ac = 1;
        uStack_2080 = 0;
      }
      break;
    case 8:
      uStack_2098._0_2_ = 0;
      uStack_2098._2_2_ = 0;
      uStack_2094 = 0;
      uStack_2092 = 0;
      uStack_20ae = 0;
      uStack_2090 = 0;
      uStack_208a = 0;
      uStack_20ac = 9;
      uStack_2080 = 0;
    }
    uVar17 = (uint)uVar23;
    uVar23 = param_1 + 0x2000;
    if (param_1 == 0) {
      uVar23 = uVar29;
    }
    uStack_2088 = (undefined2)uVar23;
    uStack_2086 = (undefined2)(uVar23 >> 0x10);
    uStack_2084 = (ushort)(uVar23 >> 0x20);
    uStack_2082 = (undefined2)(uVar23 >> 0x30);
    uStack_20a0 = puVar25;
  }
  if (sStack_20b0 == 0) {
    uVar22 = CONCAT22(uStack_2098._2_2_,(undefined2)uStack_2098);
    if (uVar17 == 0) {
      uVar22 = (uint)puVar25;
      uVar29 = (ulonglong)puVar25 & 0xffffffff;
      uStack_20ae = 0;
      if ((*pbStack_20a8 & 0x10) != 0) {
        uVar22 = uVar22 + 2 +
                 (*(ushort *)(pbStack_20a8 + ((ulonglong)puVar25 & 0xffffffff)) + 7 >> 3);
        uVar29 = (ulonglong)uVar22;
      }
      uStack_20a0 = (undefined *)CONCAT44(uVar22,(uint)uStack_20a0);
      uVar22 = (uint)uVar29;
      if ((*pbStack_20a8 & 0x20) == 0) {
        uStack_2094 = 0;
        uStack_20ac = uVar22;
      }
      else {
        puVar27 = (ushort *)(pbStack_20a8 + uVar29);
        uStack_2094 = *puVar27;
        if (uStack_2094 == 0) {
          if ((((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                         (ulonglong)*puRam0000000000f99380), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10079a;
              (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007bd;
              (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007cb;
          func_0x(pbStack_20a8,3);
        }
        uStack_2098 = uStack_20a0._4_4_ + 2 + (uint)uStack_2094 * 2;
        if (0x1f9e < uStack_2098) {
          if (((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
             ((lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                         (ulonglong)*puRam0000000000f99380), lVar12 != 0 &&
              ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
               (*(char *)(lVar12 + 0x499) != '\0')))))) {
            if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10086c;
              (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10088f;
              (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10089d;
          func_0x(pbStack_20a8,4);
        }
        uVar23 = (ulonglong)uStack_2094;
        uStack_20ac = puVar27[uVar23] & 0x7fff;
        uVar29 = (ulonglong)uStack_20ac;
        uVar22 = uStack_2098;
        if (uStack_20ac < uStack_2098) {
          if ((((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                         (ulonglong)*puRam0000000000f99380), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10093a;
              (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10095f;
              (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10096d;
          func_0x(pbStack_20a8,4);
          uVar23 = (ulonglong)uStack_2094;
          uVar29 = (ulonglong)uStack_20ac;
          uVar22 = uStack_2098;
        }
        do {
          if (-1 < (short)puVar27[(ulonglong)((int)uVar23 - 1) + 1]) break;
          uVar28 = uStack_2098;
          if ((((int)uVar23 != 1) &&
              (uVar28 = *(ushort *)
                         (pbStack_20a8 + uVar23 * 2 + (((ulonglong)uStack_20a0 >> 0x20) - 2)) &
                        0x7fff, uVar28 < uStack_2098)) ||
             ((*(ushort *)(pbStack_20a8 + uVar23 * 2 + ((ulonglong)uStack_20a0 >> 0x20)) & 0x7fff) <
              uVar28)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1009d4;
            uStack_2098 = uVar22;
            func_0x(pbStack_20a8,7);
            uVar23 = (ulonglong)uStack_2094;
            uVar29 = (ulonglong)uStack_20ac;
            uVar22 = uStack_2098;
          }
          uVar17 = (uint)uVar29;
          if ((uVar28 < uStack_2098) || (uVar17 < uVar28)) goto code_r0x00100cb3;
          if (*(ushort *)(pbStack_20a8 + uVar28) == 5) {
            uStack_20ae = uStack_20ae | 2;
            uStack_2094 = (short)uVar23 - 1;
            uStack_2086 = (undefined2)uVar28;
            if ((*(ushort *)(pbStack_20a8 + (ulonglong)(uVar28 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_2084 = uStack_2084 & 0xc7ff;
            }
            else {
              uStack_2084 = uStack_2084 ^
                            (*(ushort *)(pbStack_20a8 + (ulonglong)(uVar28 & 0xffff) + 2) ^
                            uStack_2084) & 0x3800;
            }
            uStack_2084 = (uStack_2084 ^
                          *(ushort *)(pbStack_20a8 + (ulonglong)(uVar28 & 0xffff) + 2)) & 0x7ff ^
                          uStack_2084;
            break;
          }
          if (*(ushort *)(pbStack_20a8 + uVar28) < 0x400) break;
          uStack_20ae = uStack_20ae | 1;
          uStack_2094 = (short)uVar23 - 1;
          uVar23 = (ulonglong)uStack_2094;
        } while (uStack_2094 != 0);
      }
      if ((*pbStack_20a8 & 0x40) == 0) {
        uStack_208a = 0;
        uStack_2088 = 0;
      }
      else {
        uStack_208a = (undefined2)uVar29;
        uStack_2088 = (undefined2)(uVar29 >> 0x10);
        uStack_20ac = (int)uVar29 + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100abb;
        uStack_2098 = uVar22;
        puVar9 = (ulonglong *)func_0x(&uStack_20ae);
        iVar7 = 0;
        uVar29 = *puVar9;
        uVar14 = (ushort)(uVar29 >> 0x30);
        uVar16 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar16 = uVar14 & 0xdfff;
          if ((uVar29 & 0x4000000000000000) != 0) {
            uVar16 = uVar14 | 0x2000;
          }
        }
        if (uVar16 == 0xfffc) {
          iVar7 = (int)((uVar29 >> 0x20 & 0xffff) >> 5);
        }
        uStack_20ac = uStack_20ac + iVar7;
        uVar29 = (ulonglong)uStack_20ac;
        uVar22 = uStack_2098;
      }
      uVar17 = (uint)uVar29;
      uStack_2098 = uVar22;
      if (((byte *)CONCAT62(uStack_2090,uStack_2092) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_2090,uStack_2092) < pbStack_20a8 + uVar29)) {
        if (((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
           (((lVar12 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                        (ulonglong)*puRam0000000000f99380), lVar12 != 0 &&
             (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100bb9;
            (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100bdf;
            (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100bed;
        func_0x(pbStack_20a8,0x12);
        uVar17 = uStack_20ac;
      }
      uVar22 = uStack_2098;
      if (0x3f3b < uVar17 - 1) {
        if (((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
           ((lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                       (ulonglong)*puRam0000000000f99380), lVar12 != 0 &&
            ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
             (*(char *)(lVar12 + 0x499) != '\0')))))) {
          if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100c79;
            (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100c9f;
            (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100cad;
        func_0x(pbStack_20a8,5);
        uVar17 = uStack_20ac;
        uVar22 = uStack_2098;
      }
    }
code_r0x00100cb3:
    if (uVar17 < 9) {
      bVar13 = *pbStack_20a8 & 0xe;
joined_r0x00100ceb:
      if ((bVar13 == 0) || (bVar13 == 0xc)) {
        uVar17 = 9;
      }
    }
  }
  else {
    if (uVar17 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100cd6;
      func_0x(&uStack_20ae);
      uVar17 = uStack_20ac;
    }
    uVar22 = CONCAT22(uStack_2098._2_2_,(undefined2)uStack_2098);
    if (uVar17 < 9) {
      bVar13 = *pbStack_20a8 & 0x1c;
      goto joined_r0x00100ceb;
    }
  }
  uVar29 = (ulonglong)uStack_20e0;
  uVar28 = (uStack_20e0 - param_4) + uVar17;
  uVar19 = (uint)param_3;
  uStack_2098 = uVar22;
  if (uVar17 < param_4 + uVar19) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d31;
    (*pcRam0000000000f99310)(1,0x14d5320,0x14a0468,0x1285);
  }
  if (0x1f9e < uVar28) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d60;
    (*pcRam0000000000f99310)(1,0x14d5340,0x14a0468,0x1286);
  }
  if (0x1f9e < uVar19) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d92;
    (*pcRam0000000000f99310)(1,0x14d4ea8,0x14a0468,0x1287);
  }
  if (uVar19 != 0) {
    if ((pbStack_20a8 == (byte *)0x0) || (0x1f9e < uVar18)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100dce;
      func_0x(&bStack_1ff8,0,0x1f9e);
      if (pbStack_20a8 == (byte *)0x0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100ddb;
        puVar10 = (undefined4 *)(*pcRam0000000000f996b0)();
        *puVar10 = 0x16;
      }
      else {
        if (uVar18 < 0x1f9f) goto code_r0x00100dfe;
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100df2;
        puVar10 = (undefined4 *)(*pcRam0000000000f996b0)();
        *puVar10 = 0x22;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100dfe;
      (*pcRam0000000000f996c8)();
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100db8;
      func_0x(&bStack_1ff8,pbStack_20a8,uVar18);
    }
  }
code_r0x00100dfe:
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100e1c;
  func_0x(auStack_1ff7 + (uVar18 - 1),0x1f9e - uVar19,uStack_20c0,uVar29);
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100e4d;
  iVar7 = func_0x
                    (auStack_1ff7 + uVar29 + uVar18 + -1,(0x1f9e - uStack_20e0) - uVar19,
                     pbStack_20a8 + param_4 + uVar18,(uVar17 - param_4) - uVar19);
  if (iVar7 != 0) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100e7a;
    (*pcRam0000000000f99310)(1,0x14b1598,0x14a0468,0x1298);
  }
  puVar24 = (undefined8 *)0x0;
  if (((byte)(*(char *)(param_1 + 1) - 3U) < 2) || (*(char *)(param_1 + 1) == '\r')) {
    if ((bStack_1ff8 & 1) == 0) {
      if ((bStack_1ff8 & 0xe) != 0xe) {
        bVar13 = bStack_1ff8 >> 6;
        goto code_r0x00100ec3;
      }
      goto code_r0x00100edb;
    }
    if (((bStack_1ff8 & 0x1c) == 4) && ((bStack_1ff8 & 2) != 0)) goto code_r0x00100edb;
    bVar13 = bStack_1ff8 >> 1;
code_r0x00100ec3:
    if ((bVar13 & 1) != 0) {
      uVar28 = uVar28 - 0xe;
    }
    auStack_1ff7._0_3_ = CONCAT21((short)uVar28,auStack_1ff7[0]);
  }
  else {
code_r0x00100edb:
    uVar28 = (uint)(ushort)auStack_1ff7._1_2_;
  }
  uVar22 = (uint)*(ushort *)(param_1 + 0xe);
  *(byte **)((longlong)&pbStackX_18 + lVar8) = &bStack_1ff8;
  if ((bStack_1ff8 & 1) == 0) {
    *(undefined2 *)((longlong)&sStackX_10 + lVar8) = 0;
    *(undefined4 *)((longlong)&param_6 + lVar8 + 6) = 0;
    switch(bStack_1ff8 & 0xe) {
    default:
      uVar22 = uVar28 & 0xffff;
      if (0x1f9d < uVar22 - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1010df;
        func_0x(&bStack_1ff8,6);
      }
      break;
    case 4:
      uVar22 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar22 = 1;
    }
    *(uint *)((longlong)&uStackX_20 + lVar8) = uVar22;
code_r0x001010ef:
    uVar21 = *(uint *)((longlong)&sStackX_10 + lVar8 + 4);
  }
  else {
    *(undefined2 *)((longlong)&sStackX_10 + lVar8) = 1;
    switch(bStack_1ff8 & 0x1c) {
    default:
      if ((char)auStack_1ff7[0] < '\0') {
        uVar16 = (auStack_1ff7._0_2_ & 0x7f) << 8 | (ushort)auStack_1ff7._0_2_ >> 8;
        *(undefined2 *)((longlong)&param_5 + lVar8) = 3;
        sVar26 = 3;
        *(ushort *)((longlong)&sStackX_10 + lVar8 + 2) = uVar16;
      }
      else {
        uVar16 = (ushort)auStack_1ff7[0];
        *(ushort *)((longlong)&sStackX_10 + lVar8 + 2) = uVar16;
        *(undefined2 *)((longlong)&param_5 + lVar8) = 2;
      }
      *(ushort *)(&stack0x0000002c + lVar8) = ((ushort)(uVar16 + 1) >> 1) + sVar26;
      if (uVar16 < 0x1f) {
        *(undefined2 *)((longlong)&param_5 + lVar8 + 2) = 0;
      }
      else {
        iVar7 = uVar16 - 1;
        *(short *)((longlong)&param_5 + lVar8 + 2) =
             ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
             (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
      }
      uStack_20f8 = 0;
      goto code_r0x001010ef;
    case 4:
      if (((bStack_1ff8 & 0x1c) == 4) && ((bStack_1ff8 & 2) != 0)) {
        *(undefined4 *)((longlong)&param_5 + lVar8) = 0;
        *(undefined2 *)((longlong)&sStackX_10 + lVar8 + 2) = 0;
        *(undefined2 *)(&stack0x0000002c + lVar8) = 0;
        *(undefined2 *)((longlong)&param_6 + lVar8 + 6) = 0;
        *(undefined4 *)((longlong)&sStackX_10 + lVar8 + 4) = 0xf;
        uStack_20f8 = 1;
      }
      else {
        *(undefined4 *)((longlong)&param_5 + lVar8) = 0;
        *(undefined2 *)((longlong)&sStackX_10 + lVar8 + 2) = 0;
        uVar21 = 1;
        *(undefined2 *)(&stack0x0000002c + lVar8) = 0;
        *(undefined2 *)((longlong)&param_6 + lVar8 + 6) = 0;
        *(undefined4 *)((longlong)&sStackX_10 + lVar8 + 4) = 1;
        uStack_20f8 = 0;
      }
      break;
    case 8:
      *(undefined4 *)((longlong)&param_5 + lVar8) = 0;
      *(undefined2 *)((longlong)&sStackX_10 + lVar8 + 2) = 0;
      uVar21 = 9;
      *(undefined2 *)(&stack0x0000002c + lVar8) = 0;
      *(undefined2 *)((longlong)&param_6 + lVar8 + 6) = 0;
      *(undefined4 *)((longlong)&sStackX_10 + lVar8 + 4) = 9;
      uStack_20f8 = 0;
    }
  }
  puVar11 = param_10;
  uVar22 = 9;
  if (param_10 == (undefined8 *)0x0) {
    if (*(short *)((longlong)&sStackX_10 + lVar8) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101202;
      func_0x((longlong)&sStackX_10 + lVar8 + 2);
      uVar21 = *(uint *)((longlong)&sStackX_10 + lVar8 + 4);
    }
    else if ((**(byte **)((longlong)&pbStackX_18 + lVar8) & 2) != 0) {
      if (uVar21 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101220;
        func_0x((longlong)&sStackX_10 + lVar8 + 2);
      }
      **(byte **)((longlong)&pbStackX_18 + lVar8) =
           **(byte **)((longlong)&pbStackX_18 + lVar8) & 0xfd;
      *(uint *)((longlong)&sStackX_10 + lVar8 + 4) = uStack_20f8;
      uVar21 = uStack_20f8;
    }
  }
  else {
    uStack_20e0 = *(uint *)(param_10 + 1);
    uStack_20dc = *(undefined2 *)((longlong)param_10 + 0xc);
    if (*(short *)((longlong)&sStackX_10 + lVar8) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101127;
      func_0x();
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101182;
      func_0x((longlong)&sStackX_10 + lVar8 + 2,&uStack_20e0);
    }
    uVar4 = *puVar11;
    uStack_20c0 = uVar4;
    if (*(short *)((longlong)&sStackX_10 + lVar8) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10119f;
      func_0x((longlong)&sStackX_10 + lVar8 + 2,&uStack_20c0);
      uVar21 = *(uint *)((longlong)&sStackX_10 + lVar8 + 4);
    }
    else {
      if (*(int *)((longlong)&sStackX_10 + lVar8 + 4) == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1011b9;
        func_0x((longlong)&sStackX_10 + lVar8 + 2);
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1011c3;
      func_0x((longlong)&sStackX_10 + lVar8 + 2);
      puVar11 = puVar24;
      if ((**(byte **)((longlong)&pbStackX_18 + lVar8) & 2) != 0) {
        puVar11 = (undefined8 *)(*(byte **)((longlong)&pbStackX_18 + lVar8) + uStack_20f8);
      }
      *puVar11 = uVar4;
      *(undefined4 *)((longlong)&sStackX_10 + lVar8 + 4) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1011ea;
      func_0x((longlong)&sStackX_10 + lVar8 + 2);
      uVar21 = *(uint *)((longlong)&sStackX_10 + lVar8 + 4);
    }
  }
  if (*(short *)((longlong)&sStackX_10 + lVar8) == 0) {
    if (uVar21 == 0) {
      pbVar1 = *(byte **)((longlong)&pbStackX_18 + lVar8);
      uVar21 = *(uint *)((longlong)&uStackX_20 + lVar8);
      uVar18 = (ulonglong)uVar21;
      *(undefined2 *)((longlong)&sStackX_10 + lVar8 + 2) = 0;
      *(uint *)((longlong)&uStackX_20 + lVar8 + 4) = uVar21;
      if ((*pbVar1 & 0x10) != 0) {
        uVar21 = uVar21 + 2 + (*(ushort *)(pbVar1 + uVar18) + 7 >> 3);
        uVar18 = (ulonglong)uVar21;
        *(uint *)((longlong)&uStackX_20 + lVar8 + 4) = uVar21;
      }
      if ((**(byte **)((longlong)&pbStackX_18 + lVar8) & 0x20) == 0) {
        *(int *)((longlong)&sStackX_10 + lVar8 + 4) = (int)uVar18;
        *(undefined2 *)(&stack0x0000002c + lVar8) = 0;
        *(int *)((longlong)&param_5 + lVar8) = (int)uVar18;
      }
      else {
        puVar27 = (ushort *)(*(byte **)((longlong)&pbStackX_18 + lVar8) + uVar18);
        uVar16 = *puVar27;
        *(ushort *)(&stack0x0000002c + lVar8) = uVar16;
        if (uVar16 == 0) {
          if ((((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                         (ulonglong)*puRam0000000000f99380), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101310;
              (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101334;
              (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101343;
          func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar8),3);
          uVar16 = *(ushort *)(&stack0x0000002c + lVar8);
        }
        uVar17 = *(int *)((longlong)&uStackX_20 + lVar8 + 4) + 2 + (uint)uVar16 * 2;
        *(uint *)((longlong)&param_5 + lVar8) = uVar17;
        if (0x1f9e < uVar17) {
          if (((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
             ((lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                         (ulonglong)*puRam0000000000f99380), lVar12 != 0 &&
              ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
               (*(char *)(lVar12 + 0x499) != '\0')))))) {
            if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1013e4;
              (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101408;
              (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101417;
          func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar8),4);
          uVar16 = *(ushort *)(&stack0x0000002c + lVar8);
          uVar17 = *(uint *)((longlong)&param_5 + lVar8);
        }
        uVar21 = puVar27[uVar16] & 0x7fff;
        uVar18 = (ulonglong)uVar21;
        *(uint *)((longlong)&sStackX_10 + lVar8 + 4) = uVar21;
        if (uVar21 < uVar17) {
          if ((((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                         (ulonglong)*puRam0000000000f99380), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1014b6;
              (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1014da;
              (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1014e9;
          func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar8),4);
          uVar16 = *(ushort *)(&stack0x0000002c + lVar8);
          uVar17 = *(uint *)((longlong)&param_5 + lVar8);
          uVar18 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar8 + 4);
        }
        do {
          if (-1 < (short)puVar27[(ulonglong)(uVar16 - 1) + 1]) break;
          lVar12 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar8 + 4) +
                   *(longlong *)((longlong)&pbStackX_18 + lVar8);
          uVar28 = uVar17;
          if (((uVar16 != 1) &&
              (uVar28 = *(ushort *)(lVar12 + -2 + (ulonglong)uVar16 * 2) & 0x7fff, uVar28 < uVar17))
             || ((*(ushort *)(lVar12 + (ulonglong)uVar16 * 2) & 0x7fff) < uVar28)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101556;
            func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar8),7);
            uVar16 = *(ushort *)(&stack0x0000002c + lVar8);
            uVar17 = *(uint *)((longlong)&param_5 + lVar8);
            uVar18 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar8 + 4);
          }
          uVar21 = (uint)uVar18;
          if ((uVar28 < uVar17) || (uVar21 < uVar28)) goto code_r0x0010184c;
          uVar14 = *(ushort *)((ulonglong)uVar28 + *(longlong *)((longlong)&pbStackX_18 + lVar8));
          if (uVar14 == 5) {
            puVar27 = (ushort *)((longlong)&sStackX_10 + lVar8 + 2);
            *puVar27 = *puVar27 | 2;
            uVar14 = *(ushort *)(&stack0x0000003c + lVar8);
            *(ushort *)(&stack0x0000002c + lVar8) = uVar16 - 1;
            *(short *)((longlong)&param_7 + lVar8 + 2) = (short)uVar28;
            lVar12 = (ulonglong)(uVar28 & 0xffff) + *(longlong *)((longlong)&pbStackX_18 + lVar8);
            uVar16 = *(ushort *)(lVar12 + 2);
            if ((uVar16 & 0x4000) == 0) {
              uVar14 = uVar14 & 0xc7ff;
            }
            else {
              uVar14 = uVar14 ^ (uVar14 ^ uVar16) & 0x3800;
            }
            *(ushort *)(&stack0x0000003c + lVar8) = uVar14;
            *(ushort *)(&stack0x0000003c + lVar8) =
                 (uVar14 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar14;
            break;
          }
          if (uVar14 < 0x400) break;
          puVar3 = (ushort *)((longlong)&sStackX_10 + lVar8 + 2);
          *puVar3 = *puVar3 | 1;
          uVar16 = uVar16 - 1;
          *(ushort *)(&stack0x0000002c + lVar8) = uVar16;
        } while (uVar16 != 0);
      }
      if ((**(byte **)((longlong)&pbStackX_18 + lVar8) & 0x40) == 0) {
        *(undefined4 *)((longlong)&param_6 + lVar8 + 6) = 0;
      }
      else {
        *(int *)((longlong)&param_6 + lVar8 + 6) = (int)uVar18;
        *(int *)((longlong)&sStackX_10 + lVar8 + 4) = (int)uVar18 + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101655;
        puVar9 = (ulonglong *)func_0x((longlong)&sStackX_10 + lVar8 + 2);
        uVar18 = *puVar9;
        uVar14 = (ushort)(uVar18 >> 0x30);
        uVar16 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar16 = uVar14 & 0xdfff;
          if ((uVar18 & 0x4000000000000000) != 0) {
            uVar16 = uVar14 | 0x2000;
          }
        }
        puVar11 = puVar24;
        if (uVar16 == 0xfffc) {
          puVar11 = (undefined8 *)((uVar18 >> 0x20 & 0xffff) >> 5);
        }
        uVar21 = *(int *)((longlong)&sStackX_10 + lVar8 + 4) + (int)puVar11;
        uVar18 = (ulonglong)uVar21;
        *(uint *)((longlong)&sStackX_10 + lVar8 + 4) = uVar21;
      }
      uVar21 = (uint)uVar18;
      if ((*(ulonglong *)(&stack0x0000002e + lVar8) != 0) &&
         (*(ulonglong *)(&stack0x0000002e + lVar8) <
          uVar18 + *(longlong *)((longlong)&pbStackX_18 + lVar8))) {
        if (((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
           (((lVar12 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                        (ulonglong)*puRam0000000000f99380), lVar12 != 0 &&
             (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101755;
            (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101779;
            (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101788;
        func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar8),0x12);
        uVar21 = *(uint *)((longlong)&sStackX_10 + lVar8 + 4);
      }
      if (0x3f3b < uVar21 - 1) {
        if (((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
           ((lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                       (ulonglong)*puRam0000000000f99380), lVar12 != 0 &&
            ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
             (*(char *)(lVar12 + 0x499) != '\0')))))) {
          if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101815;
            (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101839;
            (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101848;
        func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar8),5);
        uVar21 = *(uint *)((longlong)&sStackX_10 + lVar8 + 4);
      }
    }
code_r0x0010184c:
    if (8 < uVar21) goto code_r0x0010188f;
    bVar13 = **(byte **)((longlong)&pbStackX_18 + lVar8) & 0xe;
  }
  else {
    if (uVar21 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101871;
      func_0x((longlong)&sStackX_10 + lVar8 + 2);
      uVar21 = *(uint *)((longlong)&sStackX_10 + lVar8 + 4);
    }
    if (8 < uVar21) goto code_r0x0010188f;
    bVar13 = **(byte **)((longlong)&pbStackX_18 + lVar8) & 0x1c;
  }
  if ((bVar13 == 0) || (bVar13 == 0xc)) {
    uVar21 = 9;
  }
code_r0x0010188f:
  if (sStack_20b0 == 0) {
    uVar28 = uStack_20ac;
    uVar17 = uStack_2098;
    if (uStack_20ac == 0) {
      uVar18 = (ulonglong)uStack_20a0 & 0xffffffff;
      uStack_20ae = 0;
      uVar17 = (uint)uStack_20a0;
      if ((*pbStack_20a8 & 0x10) != 0) {
        uVar17 = (uint)uStack_20a0 + 2 + (*(ushort *)(pbStack_20a8 + uVar18) + 7 >> 3);
        uVar18 = (ulonglong)uVar17;
      }
      uStack_20a0 = (undefined *)CONCAT44(uVar17,(uint)uStack_20a0);
      uVar17 = (uint)uVar18;
      if ((*pbStack_20a8 & 0x20) == 0) {
        uStack_2094 = 0;
        uStack_20ac = uVar17;
      }
      else {
        puVar27 = (ushort *)(pbStack_20a8 + uVar18);
        uStack_2094 = *puVar27;
        if (uStack_2094 == 0) {
          if ((((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                         (ulonglong)*puRam0000000000f99380), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10196b;
              (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10198f;
              (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10199d;
          func_0x(pbStack_20a8,3);
        }
        uStack_2098 = uStack_20a0._4_4_ + 2 + (uint)uStack_2094 * 2;
        if (0x1f9e < uStack_2098) {
          if (((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
             ((lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                         (ulonglong)*puRam0000000000f99380), lVar12 != 0 &&
              ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
               (*(char *)(lVar12 + 0x499) != '\0')))))) {
            if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101a3c;
              (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101a60;
              (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101a6e;
          func_0x(pbStack_20a8,4);
        }
        uVar29 = (ulonglong)uStack_2094;
        uStack_20ac = puVar27[uVar29] & 0x7fff;
        uVar18 = (ulonglong)uStack_20ac;
        uVar17 = uStack_2098;
        if (uStack_20ac < uStack_2098) {
          if ((((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                         (ulonglong)*puRam0000000000f99380), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101b0c;
              (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101b30;
              (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101b3e;
          func_0x(pbStack_20a8,4);
          uVar29 = (ulonglong)uStack_2094;
          uVar18 = (ulonglong)uStack_20ac;
          uVar17 = uStack_2098;
        }
        do {
          if (-1 < (short)puVar27[(ulonglong)((int)uVar29 - 1) + 1]) break;
          uVar19 = uStack_2098;
          if ((((int)uVar29 != 1) &&
              (uVar19 = *(ushort *)
                         (pbStack_20a8 + uVar29 * 2 + (((ulonglong)uStack_20a0 >> 0x20) - 2)) &
                        0x7fff, uVar19 < uStack_2098)) ||
             ((*(ushort *)(pbStack_20a8 + uVar29 * 2 + ((ulonglong)uStack_20a0 >> 0x20)) & 0x7fff) <
              uVar19)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101ba3;
            uStack_2098 = uVar17;
            func_0x(pbStack_20a8,7);
            uVar29 = (ulonglong)uStack_2094;
            uVar18 = (ulonglong)uStack_20ac;
            uVar17 = uStack_2098;
          }
          uVar28 = (uint)uVar18;
          if ((uVar19 < uStack_2098) || (uVar28 < uVar19)) goto code_r0x00101e86;
          if (*(ushort *)(pbStack_20a8 + uVar19) == 5) {
            uStack_20ae = uStack_20ae | 2;
            uStack_2094 = (short)uVar29 - 1;
            uStack_2086 = (undefined2)uVar19;
            if ((*(ushort *)(pbStack_20a8 + (ulonglong)(uVar19 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_2084 = uStack_2084 & 0xc7ff;
            }
            else {
              uStack_2084 = uStack_2084 ^
                            (uStack_2084 ^
                            *(ushort *)(pbStack_20a8 + (ulonglong)(uVar19 & 0xffff) + 2)) & 0x3800;
            }
            uStack_2084 = (uStack_2084 ^
                          *(ushort *)(pbStack_20a8 + (ulonglong)(uVar19 & 0xffff) + 2)) & 0x7ff ^
                          uStack_2084;
            break;
          }
          if (*(ushort *)(pbStack_20a8 + uVar19) < 0x400) break;
          uStack_20ae = uStack_20ae | 1;
          uStack_2094 = (short)uVar29 - 1;
          uVar29 = (ulonglong)uStack_2094;
        } while (uStack_2094 != 0);
      }
      if ((*pbStack_20a8 & 0x40) == 0) {
        uStack_208a = 0;
        uStack_2088 = 0;
      }
      else {
        uStack_208a = (undefined2)uVar18;
        uStack_2088 = (undefined2)(uVar18 >> 0x10);
        uStack_20ac = (int)uVar18 + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101c98;
        uStack_2098 = uVar17;
        puVar9 = (ulonglong *)func_0x(&uStack_20ae);
        uVar18 = *puVar9;
        uVar14 = (ushort)(uVar18 >> 0x30);
        uVar16 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar16 = uVar14 & 0xdfff;
          if ((uVar18 & 0x4000000000000000) != 0) {
            uVar16 = uVar14 | 0x2000;
          }
        }
        if (uVar16 == 0xfffc) {
          puVar24 = (undefined8 *)((uVar18 >> 0x20 & 0xffff) >> 5);
        }
        uStack_20ac = uStack_20ac + (int)puVar24;
        uVar18 = (ulonglong)uStack_20ac;
        uVar17 = uStack_2098;
      }
      uVar28 = (uint)uVar18;
      uStack_2098 = uVar17;
      if (((byte *)CONCAT62(uStack_2090,uStack_2092) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_2090,uStack_2092) < pbStack_20a8 + uVar18)) {
        if (((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
           (((lVar12 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                        (ulonglong)*puRam0000000000f99380), lVar12 != 0 &&
             (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101d93;
            (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101db7;
            (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101dc5;
        func_0x(pbStack_20a8,0x12);
        uVar28 = uStack_20ac;
      }
      uVar17 = uStack_2098;
      if (0x3f3b < uVar28 - 1) {
        if (((cRam0000000001a2aaeb != '\0') || ((bRam0000000001a3b3f0 & 1) != 0)) &&
           ((lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000f99378 * 8) + 8 +
                       (ulonglong)*puRam0000000000f99380), lVar12 != 0 &&
            ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
             (*(char *)(lVar12 + 0x499) != '\0')))))) {
          if ((cRam0000000001a2a9db == '\0') && ((bRam0000000001a3b3f0 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101e51;
            (*pcRam0000000000f99318)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101e75;
            (*pcRam0000000000f99310)(1,0x131b518,0x143b1e8,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101e83;
        func_0x(pbStack_20a8,5);
        uVar28 = uStack_20ac;
        uVar17 = uStack_2098;
      }
    }
code_r0x00101e86:
    uStack_2098 = uVar17;
    if ((8 < uVar28) || (((*pbStack_20a8 & 0xe) != 0 && ((*pbStack_20a8 & 0xe) != 0xc)))) {
      uVar22 = uVar28;
    }
  }
  else {
    if (uStack_20ac == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101eb1;
      func_0x(&uStack_20ae);
    }
    if ((8 < uStack_20ac) || (((*pbStack_20a8 & 0x1c) != 0 && ((*pbStack_20a8 & 0x1c) != 0xc)))) {
      uVar22 = uStack_20ac;
    }
  }
  iVar7 = iStack_20c8;
  *(undefined8 *)((longlong)&uStackX_20 + lVar8 + -0x20) = uStack_20b8;
  *(undefined2 *)(&stack0xfffffffffffffff8 + lVar8) = param_8;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar8) = param_7;
  *(byte **)(&stack0xffffffffffffffe8 + lVar8) = &bStack_1ff8;
  *(uint *)(&stack0xffffffffffffffe0 + lVar8) = uVar21;
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101f0d;
  func_0x(param_1,iVar7,0,uVar22);
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101f1c;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar8));
  return;
}

