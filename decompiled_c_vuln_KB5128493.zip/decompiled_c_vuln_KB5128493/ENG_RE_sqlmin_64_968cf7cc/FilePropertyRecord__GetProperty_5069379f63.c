
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(short *param_1,int param_2,undefined8 param_3,uint *param_4)

{
  ushort *puVar1;
  byte *pbVar2;
  longlong *plVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  ulonglong *puVar7;
  uint *puVar8;
  ushort uVar9;
  short sVar10;
  uint uVar11;
  ulonglong uVar12;
  uint uVar13;
  int iVar14;
  longlong lVar15;
  ushort *puVar16;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  uint auStackX_10 [2];
  ulonglong in_stack_ffffffffffffff88;
  uint *puVar17;
  undefined auStack_58 [8];
  uint uStack_50;
  ushort uStack_4c;
  ushort uStack_4a;
  uint *puStack_48;
  
  puVar17 = (uint *)(in_stack_ffffffffffffff88 & 0xffffffff00000000);
  func_0x(&uStack_50,-param_2,param_2,0,puVar17);
  puVar1 = (ushort *)(param_1 + 1);
  if (*param_1 != 0) {
    puVar17 = auStackX_8;
    auStackX_8[0] = 0;
    puVar8 = (uint *)func_0x(puVar1,&uStack_50);
    if ((((*param_1 != 0) && (plVar3 = *(longlong **)(param_1 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) && (((uStack_4a & 8) == 0 && ((auStackX_8[0] & 1) == 0)))) {
      if ((puVar8 == (uint *)0x0) || (puVar8 == (uint *)0x10fd3d4)) {
        auStackX_10[0] = 0;
        puVar8 = (uint *)0x0;
      }
      else {
        puVar17 = (uint *)0x0;
        puVar8 = (uint *)func_0x
                                   (plVar3,&uStack_50,puVar8,auStackX_10[0],0,0,auStackX_10,
                                    auStackX_8[0]);
      }
    }
    goto LAB_;
  }
  if ((uStack_50 & 0xc0000000) == 0x80000000) {
    iVar6 = func_0x(puVar1);
    if (iVar6 == 0) {
      auStackX_10[0] = 0;
      puVar8 = (uint *)0x0;
    }
    else {
      puVar8 = (uint *)func_0x(param_1 + 0x15,&uStack_50,auStackX_10,auStack_58);
    }
    goto LAB_;
  }
  pbVar2 = *(byte **)(param_1 + 4);
  iVar14 = 1;
  bVar4 = *pbVar2;
  iVar6 = 0;
  if ((bVar4 & 0x10) == 0) {
    if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
      uVar5 = ~(uStack_4a >> 4);
      iVar14 = iVar6;
      goto LAB_;
    }
  }
  else {
    uVar11 = *(uint *)(param_1 + 8);
    if ((int)uStack_50 < (int)uVar11) {
      if ((uint)*(ushort *)(pbVar2 + uVar11) < (uint)uStack_4c) {
        uVar5 = ~(uStack_4a >> 4);
        iVar14 = iVar6;
      }
      else {
        uVar13 = uStack_4c - 1;
        uVar5 = (ushort)(pbVar2[(ulonglong)uVar11 + (ulonglong)(uVar13 >> 3) + 2] >>
                        ((byte)uVar13 & 7));
      }
    }
    else {
      uVar5 = ~(uStack_4a >> 4);
      iVar14 = iVar6;
    }
LAB_:
    if ((uVar5 & 1) != 0) {
      auStackX_10[0] = 0;
      puVar8 = (uint *)0x0;
      goto LAB_;
    }
    if ((iVar14 == 0) && ((uStack_4a & 0x10) != 0)) {
      auStackX_10[0] = *puStack_48;
      puVar8 = puStack_48 + 1;
      goto LAB_;
    }
  }
  if ((int)uStack_50 < 0) {
    if (*(int *)(param_1 + 2) == 0) {
      uVar11 = *(uint *)(param_1 + 8);
      uVar12 = (ulonglong)uVar11;
      *(uint *)(param_1 + 10) = uVar11;
      *puVar1 = 0;
      bVar4 = *pbVar2;
      if ((bVar4 & 0x10) != 0) {
        uVar11 = uVar11 + 2 + (*(ushort *)(pbVar2 + uVar12) + 7 >> 3);
        uVar12 = (ulonglong)uVar11;
        *(uint *)(param_1 + 10) = uVar11;
        bVar4 = *pbVar2;
      }
      if ((bVar4 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar12;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar12;
      }
      else {
        puVar16 = (ushort *)(pbVar2 + uVar12);
        uVar5 = *puVar16;
        param_1[0xe] = uVar5;
        if (uVar5 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar15 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar15 != 0)) &&
             ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
              (*(char *)(lVar15 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puVar17 = (uint *)0x0;
              (*_DAT_)(1,0x1378998,0x1498668,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar12 = (ulonglong)*(uint *)(param_1 + 10);
          uVar5 = param_1[0xe];
        }
        uVar11 = (int)uVar12 + (uVar5 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar11;
        if (0x1f9e < uVar11) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar15 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar15 != 0 &&
              ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
               (*(char *)(lVar15 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puVar17 = (uint *)0x0;
              (*_DAT_)(1,0x1378998,0x1498668,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar5 = param_1[0xe];
          uVar11 = *(uint *)(param_1 + 0xc);
        }
        uVar12 = (ulonglong)uVar5;
        uVar5 = puVar16[uVar12];
        *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar11) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar15 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar15 != 0)) &&
             ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
              (*(char *)(lVar15 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puVar17 = (uint *)0x0;
              (*_DAT_)(1,0x1378998,0x1498668,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar12 = (ulonglong)(ushort)param_1[0xe];
        }
        if ((short)puVar16[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
          lVar15 = *(longlong *)(param_1 + 4);
          do {
            if ((int)uVar12 == 1) {
              uVar11 = *(uint *)(param_1 + 0xc);
              uVar13 = uVar11;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar15 + uVar12 * 2) & 0x7fff) <
                  uVar11) goto LAB_;
            }
            else {
              uVar13 = *(uint *)(param_1 + 0xc);
              uVar11 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar15 + -2 + uVar12 * 2) &
                       0x7fff;
              if (uVar13 <= uVar11) goto LAB_;
LAB_:
              func_0x(lVar15,7);
              uVar13 = *(uint *)(param_1 + 0xc);
            }
            if ((uVar11 < uVar13) || (*(uint *)(param_1 + 2) < uVar11)) goto LAB_;
            lVar15 = *(longlong *)(param_1 + 4);
            if (*(ushort *)((ulonglong)uVar11 + lVar15) == 5) {
              *puVar1 = *puVar1 | 2;
              param_1[0xe] = param_1[0xe] + -1;
              param_1[0x15] = (short)uVar11;
              lVar15 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(param_1 + 4);
              uVar5 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar15 + 2) & 0x4000) != 0) {
                uVar5 = *(ushort *)(lVar15 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar5;
              param_1[0x16] = (uVar5 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar5;
              break;
            }
            if (*(ushort *)((ulonglong)uVar11 + lVar15) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar5 = param_1[0xe] - 1;
            param_1[0xe] = uVar5;
            if ((uVar5 == 0) ||
               (uVar12 = (ulonglong)uVar5, -1 < (short)puVar16[(ulonglong)(uVar5 - 1) + 1]))
            goto LAB_;
          } while( true );
        }
        uVar12 = (ulonglong)*(uint *)(param_1 + 2);
      }
      goto LAB_;
    }
    goto LAB_;
  }
  if ((uStack_4a & 8) != 0) {
    auStackX_10[0] = 1;
    puVar8 = (uint *)0x10fd3d4;
    if ((pbVar2[(int)uStack_50] & (byte)(1 << ((byte)uStack_4a & 7))) == 0) {
      puVar8 = (uint *)0x10fd9f8;
    }
    goto LAB_;
  }
  if ((uStack_4a & 0x10) != 0) {
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) goto LAB_;
    }
    else {
      if ((int)*(uint *)(param_1 + 8) <= (int)uStack_50) goto LAB_;
      if (*(ushort *)(pbVar2 + *(uint *)(param_1 + 8)) < uStack_4c) {
        auStackX_10[0] = *puStack_48;
        puVar8 = puStack_48 + 1;
        goto LAB_;
      }
    }
  }
  puVar8 = (uint *)(pbVar2 + (int)uStack_50);
LAB_:
  auStackX_10[0] = 0;
  goto LAB_;
LAB_:
  uVar12 = (ulonglong)*(uint *)(param_1 + 2);
LAB_:
  if ((**(byte **)(param_1 + 4) & 0x40) == 0) {
    *(undefined4 *)(param_1 + 0x13) = 0;
  }
  else {
    *(int *)(param_1 + 0x13) = (int)uVar12;
    *(int *)(param_1 + 2) = (int)uVar12 + 0xe;
    puVar7 = (ulonglong *)func_0x(puVar1);
    uVar12 = *puVar7;
    uVar9 = (ushort)(uVar12 >> 0x30);
    uVar5 = uVar9;
    if ((((uint)(int)(short)uVar9 >> 1 ^ (int)(short)uVar9) & 0x2000) != 0) {
      uVar5 = uVar9 & 0xdfff;
      if ((uVar12 & 0x4000000000000000) != 0) {
        uVar5 = uVar9 | 0x2000;
      }
    }
    if (uVar5 == 0xfffc) {
      iVar6 = (int)((uVar12 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar6;
    uVar12 = (ulonglong)*(uint *)(param_1 + 2);
  }
  iVar6 = (int)uVar12;
  if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
     (*(ulonglong *)(param_1 + 0xf) < uVar12 + *(longlong *)(param_1 + 4))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar15 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar15 != 0 &&
         (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
        (*(char *)(lVar15 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        puVar17 = (uint *)0x0;
        (*_DAT_)(1,0x1378998,0x1498668,0x877,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 4),0x12);
    iVar6 = *(int *)(param_1 + 2);
  }
  if (0x3f3b < iVar6 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar15 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar15 != 0 &&
        ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 && (*(char *)(lVar15 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        puVar17 = (uint *)0x0;
        (*_DAT_)(1,0x1378998,0x1498668,0x87c,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 4),5);
  }
LAB_:
  sVar10 = -(short)uStack_50;
  if ((uStack_4a & 0x10) != 0) {
    bVar4 = **(byte **)(param_1 + 4);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) == 0) goto LAB_;
    }
    else if (((int)uStack_50 < (int)*(uint *)(param_1 + 8)) &&
            (uStack_4c <= *(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8))))
    goto LAB_;
LAB_:
    auStackX_10[0] = *puStack_48;
    puVar8 = puStack_48 + 1;
    goto LAB_;
  }
LAB_:
  puVar8 = *(uint **)(param_1 + 4);
  lVar15 = (longlong)sVar10;
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar10) goto LAB_;
  uVar11 = *(uint *)(param_1 + 10);
  if (sVar10 == 1) {
    uVar13 = *(uint *)(param_1 + 0xc);
    uVar11 = *(ushort *)((longlong)puVar8 + lVar15 * 2 + (ulonglong)uVar11) & 0x7fff;
LAB_:
    if (uVar11 < uVar13) goto LAB_;
  }
  else {
    puVar1 = (ushort *)((longlong)puVar8 + lVar15 * 2 + (ulonglong)uVar11);
    uVar13 = *(ushort *)((longlong)puVar8 + lVar15 * 2 + ((ulonglong)uVar11 - 2)) & 0x7fff;
    puVar8 = *(uint **)(param_1 + 4);
    uVar11 = *puVar1 & 0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar13) goto LAB_;
LAB_:
    func_0x(puVar8,7);
    puVar8 = *(uint **)(param_1 + 4);
  }
  auStackX_10[0] = uVar11 - uVar13;
  puVar8 = (uint *)((longlong)puVar8 + (ulonglong)uVar13);
LAB_:
  if (puVar8 == (uint *)0x0) {
    return 0x58d;
  }
  if (auStackX_10[0] <= *param_4) {
    func_0x(param_3,(longlong)(int)*param_4,puVar8,auStackX_10[0],puVar17);
    *param_4 = auStackX_10[0];
    return 0;
  }
  *param_4 = auStackX_10[0];
  return 0xea;
}

