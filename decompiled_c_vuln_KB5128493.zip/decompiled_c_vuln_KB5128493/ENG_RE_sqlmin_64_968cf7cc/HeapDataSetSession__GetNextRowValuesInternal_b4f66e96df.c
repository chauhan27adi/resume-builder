
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,longlong **param_3,uint param_4,undefined8 *param_5)

{
  undefined4 uVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong **pplVar4;
  longlong *plVar5;
  char cVar6;
  byte bVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  longlong lVar14;
  byte **ppbVar15;
  undefined8 uVar16;
  short *psVar17;
  longlong lVar18;
  longlong *plVar19;
  undefined uVar20;
  byte *pbVar21;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar22;
  ulonglong uVar23;
  longlong *plVar24;
  longlong **pplVar25;
  longlong lVar26;
  undefined *puVar27;
  short sVar28;
  uint uVar29;
  uint *puVar30;
  byte *pbVar31;
  uint uVar32;
  uint uVar33;
  uint *puVar34;
  ushort *puVar35;
  longlong unaff_GS_OFFSET;
  bool bVar36;
  undefined8 uStack_5d0;
  undefined auStack_5c8 [32];
  undefined8 uStack_5a8;
  int iStack_5a0;
  undefined8 uStack_598;
  undefined8 uStack_590;
  uint uStack_588;
  uint uStack_584;
  undefined4 uStack_568;
  longlong **pplStack_560;
  char cStack_558;
  undefined4 uStack_554;
  uint uStack_550;
  int iStack_54c;
  int iStack_548;
  longlong *plStack_540;
  undefined4 uStack_538;
  char cStack_530;
  undefined4 uStack_51c;
  undefined2 uStack_518;
  int iStack_514;
  int iStack_510;
  uint uStack_50c;
  undefined4 uStack_508;
  undefined2 uStack_504;
  uint uStack_500;
  longlong lStack_4f8;
  uint uStack_4f0;
  uint uStack_4ec;
  longlong **pplStack_4e8;
  uint uStack_4e0;
  undefined4 uStack_4dc;
  undefined8 uStack_4d8;
  longlong lStack_4d0;
  undefined8 uStack_4c8;
  longlong lStack_4c0;
  int iStack_4a0;
  int iStack_49c;
  int iStack_498;
  int iStack_494;
  longlong lStack_488;
  uint uStack_480;
  int iStack_47c;
  undefined4 uStack_42c;
  undefined2 uStack_428;
  undefined4 uStack_426;
  undefined2 uStack_422;
  int iStack_3e8;
  int iStack_3e4;
  uint auStack_3e0 [2];
  undefined4 uStack_3d8;
  undefined2 uStack_3d4;
  undefined2 uStack_3d2;
  undefined4 uStack_3d0;
  undefined2 uStack_3cc;
  undefined2 uStack_3ca;
  longlong *plStack_3c8;
  longlong lStack_3c0;
  int iStack_3b8;
  undefined8 *puStack_3b0;
  undefined4 uStack_3a8;
  undefined auStack_358 [4];
  undefined8 uStack_354;
  undefined8 uStack_34c;
  undefined auStack_344 [28];
  undefined auStack_328 [16];
  longlong alStack_318 [2];
  undefined auStack_308 [8];
  undefined auStack_300 [64];
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined4 uStack_2b4;
  short sStack_2b0;
  undefined4 uStack_2ac;
  byte *pbStack_2a8;
  byte **ppbStack_2a0;
  undefined8 uStack_292;
  undefined2 uStack_28a;
  undefined2 uStack_288;
  undefined6 uStack_286;
  int iStack_27c;
  undefined auStack_278 [16];
  undefined auStack_268 [16];
  undefined auStack_258 [16];
  undefined auStack_248 [16];
  undefined auStack_238 [16];
  undefined auStack_228 [16];
  undefined auStack_218 [16];
  undefined8 uStack_208;
  undefined auStack_200 [14];
  undefined uStack_1f2;
  undefined auStack_1f0 [14];
  undefined uStack_1e2;
  undefined auStack_1e0 [14];
  undefined uStack_1d2;
  undefined auStack_1d0 [16];
  undefined auStack_1c0 [16];
  undefined auStack_1b0 [352];
  ulonglong uStack_50;
  
  uStack_50 = _DAT_ ^ (ulonglong)&uStack_588;
  puStack_3b0 = param_5;
  uStack_5d0 = 0x100064;
  pplStack_560 = param_3;
  iStack_510 = param_2;
  lStack_4f8 = param_1;
  uStack_4ec = param_4;
  cVar6 = func_0x(0x1ea8470);
  if ((cVar6 == '\0') ||
     (cStack_530 = '\x01', (*(uint *)(*(longlong *)(param_1 + 0x108) + 8) >> 1 & 1) == 0)) {
    cStack_530 = '\0';
  }
  puVar27 = auStack_5c8;
  if ((*(byte *)(param_1 + 0x2e8) & 4) != 0) {
    plVar24 = (longlong *)0x0;
    iVar10 = 0;
    if (*(int *)(param_1 + 0x1c8) == 0) {
      if ((*(longlong *)(param_1 + 0x158) != 0) || (*(longlong *)(param_1 + 0x160) != 0)) {
        iVar10 = 1;
      }
      if ((*(byte *)((longlong)param_3 + 0x14) & 0x10) != 0) {
        plVar24 = *param_3;
      }
      if (*(int *)(param_1 + 0x1b8) == 0) {
        if (plVar24 == (longlong *)0x0) {
          bVar36 = *(longlong *)(param_1 + 0x1c0) == -1;
        }
        else {
          bVar36 = plVar24[0x1c] == *(longlong *)(param_1 + 0x1c0);
        }
        if (bVar36) goto LAB_;
      }
      uStack_5d0 = 0x10013b;
      uStack_5a8 = plVar24;
      iStack_5a0 = iVar10;
      uStack_598 = *(undefined8 *)(param_1 + 0x170);
      uStack_590 = *(undefined8 *)(param_1 + 0x178);
      func_0x(param_1 + 0x1d4,**(undefined8 **)(param_1 + 0x2e0));
      *(undefined4 *)(param_1 + 0x1b8) = 0;
    }
    else {
      *(undefined4 *)(param_1 + 0x1d4) = 1;
    }
LAB_:
    pplVar25 = (longlong **)(param_1 + 0xa28);
    uStack_538 = iStack_498;
    iVar10 = iStack_498;
    pplStack_4e8 = pplVar25;
LAB_:
    plStack_540 = *(longlong **)(param_1 + 0xa18);
    iStack_4a0 = *(int *)(param_1 + 0x1d4);
    if (*(int *)(plStack_540 + 1) == 1) {
      iStack_548 = -1;
      iStack_514 = 1;
      iStack_54c = 0;
      lStack_3c0 = *(longlong *)(plStack_540[3] + 0x18);
      uStack_584 = 0;
      uStack_588 = 0;
      uStack_4f0 = 1;
      uVar33 = 0;
      uVar29 = 0;
LAB_:
      do {
        iVar12 = iStack_548;
        iVar13 = iStack_54c;
        lVar14 = plStack_540[0x58];
        if (lVar14 == 0) {
          *(uint *)((longlong)plStack_540 + 0x66c) =
               *(uint *)((longlong)plStack_540 + 0x66c) & 0xfffffffe;
          if (*(int *)(plStack_540 + 0x75) == 4) {
            uStack_5d0 = 0x1001fe;
            func_0x(plStack_540 + 0x5d);
          }
          uStack_5d0 = 0x10020b;
          lVar14 = func_0x(plStack_540 + 0xd);
          if (*(char *)(plStack_540[0xc] + 0xb5) == '\0') {
            *(uint *)((longlong)plStack_540 + 0x66c) = *(uint *)((longlong)plStack_540 + 0x66c) | 1;
          }
          if (lVar14 != 0) goto LAB_;
LAB_:
          if (iVar12 != -1) {
            iVar12 = *(int *)(plStack_540 + 0x5a);
            if (*(int *)((longlong)plStack_540 + 0x2d4) == 0) {
              if ((*(char *)(lStack_3c0 + 3) == '\0') &&
                 (*(longlong *)(*(longlong *)(*(longlong *)(plStack_540[2] + 8) + 0x30) + 0x1b28) ==
                  0)) {
                iVar12 = 0;
              }
              else if (((*(byte *)(lStack_3c0 + 4) & 8) == 0) ||
                      ((*(longlong *)(lStack_3c0 + 0x10) != 0 || ((DAT_ & 4) != 0)))) {
LAB_:
                iVar12 = 2;
              }
              else {
                lVar26 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
                if ((lVar26 != 0) && (lVar26 = **(longlong **)(lVar26 + 0x38), lVar26 != 0)) {
                  uStack_5d0 = 0x100885;
                  iVar12 = (*_DAT_)(lVar26,0x4c2);
                  if (iVar12 != 0) goto LAB_;
                }
                plVar24 = plStack_540 + 0xd1;
                uStack_5d0 = 0x1008a9;
                uVar16 = func_0x(lVar14,auStack_1d0);
                uStack_5d0 = 0x1008b4;
                iVar11 = func_0x(uVar16,plVar24);
                iVar12 = 3;
                uVar33 = uStack_588;
                if (iVar11 != 0) {
                  iVar12 = 1;
                }
              }
              *(int *)(plStack_540 + 0x5a) = iVar12;
              *(undefined4 *)((longlong)plStack_540 + 0x2d4) = 1;
            }
            if (iVar12 == 0) goto LAB_;
            if (iVar12 == 1) {
              if (iStack_4a0 == 1) goto LAB_;
            }
            else if (iVar12 != 2) {
              if (iVar12 != 3) {
                uStack_5a8 = (longlong *)0x15156d8;
                uStack_5d0 = 0x10091b;
                (*_DAT_)(1,0x191a530);
                goto LAB_;
              }
              if (iStack_4a0 == 1) {
                iVar13 = 1;
                iStack_54c = 1;
                iStack_514 = 0;
                uStack_4f0 = ~(*(uint *)(*(longlong *)(plStack_540[3] + 0x18) + 4) >> 2) & 1;
                goto LAB_;
              }
            }
            iVar13 = 1;
            iStack_54c = 1;
            iStack_514 = 1;
            uStack_4f0 = ~(*(uint *)(*(longlong *)(plStack_540[3] + 0x18) + 4) >> 2) & 1;
LAB_:
            plVar24 = plStack_540 + 7;
            plStack_3c8 = plVar24;
LAB_:
            uVar32 = 0;
            *(uint *)((longlong)plVar24 + 0x634) = *(uint *)((longlong)plVar24 + 0x634) & 0xfffffffe
            ;
            uStack_4e0 = 0;
            uStack_588 = uVar33;
LAB_:
            plVar19 = plVar24;
            uStack_584 = uVar29;
            if ((*(int *)(plVar24 + 0x6e) == 4) &&
               ((plVar2 = plVar24 + 0x56, plVar24[0x58] != _DAT_ ||
                (plVar19 = plStack_3c8, plVar24[0x59] != _DAT_)))) {
              if ((*(byte *)(plVar24 + 100) & 2) != 0) {
                uStack_5d0 = 0x1009f9;
                iVar12 = func_0x(plVar24 + 0x65);
                if (iVar12 != 0) {
                  *(longlong *)(*plVar2 + 0x30) = *(longlong *)(*plVar2 + 0x30) + -1;
                }
              }
              *(undefined *)(plVar24 + 100) = 0;
              *(undefined4 *)((longlong)plVar24 + 0x31c) = 0;
              *(undefined4 *)(plVar24 + 0x67) = 0;
              if ((*(byte *)(plVar24 + 0x6a) & 2) != 0) {
                uStack_5d0 = 0x100a2b;
                iVar12 = func_0x(plVar24 + 0x6b);
                if (iVar12 != 0) {
                  *(longlong *)(*plVar2 + 0x30) = *(longlong *)(*plVar2 + 0x30) + -1;
                }
              }
              *(undefined *)(plVar24 + 0x6a) = 0;
              *(undefined4 *)((longlong)plVar24 + 0x34c) = 0;
              *(undefined4 *)(plVar24 + 0x6d) = 0;
              if (plVar24[0x5b] != 0) {
                *(undefined *)((longlong)plVar24 + 0x2e6) = 0;
                plVar24[0x5b] = 0;
                *(undefined2 *)((longlong)plVar24 + 0x2e4) = 0;
                *(undefined4 *)(plVar24[0x58] + 0x48) = 0;
              }
              uStack_5d0 = 0x100a79;
              func_0x(*(undefined8 *)*plVar2,plVar24 + 0x58);
              uStack_5d0 = 0x100a81;
              func_0x(plVar2);
              *(undefined4 *)(plVar24 + 0x6e) = 2;
              plVar19 = plStack_3c8;
            }
            plVar24 = plVar19;
            if ((int)uVar32 < 1) {
              if (uVar32 != 0) goto LAB_;
LAB_:
              plVar19 = plVar24 + 6;
              bVar36 = iVar13 == 0;
              lVar14 = *(longlong *)(plVar24[7] + 8);
              pbStack_2a8 = (byte *)0x0;
              sStack_2b0 = -1;
              iStack_27c = 0xffffffff;
              uStack_2ac = 0;
              uStack_292 = 0;
              uStack_288 = 0;
              uStack_286 = 0;
              ppbStack_2a0 = (byte **)0x0;
              uStack_508 = 0;
              uStack_504 = 0;
              lStack_4d0 = *(longlong *)(*plVar19 + 0x18);
              cStack_558 = bVar36;
              lStack_4c0 = lVar14;
              if ((*(byte *)(plVar24 + 0x14) & 2) != 0) {
                uStack_5d0 = 0x100b75;
                iVar10 = func_0x(plVar24 + 0x15);
                if (iVar10 != 0) {
                  *(longlong *)(*plVar19 + 0x30) = *(longlong *)(*plVar19 + 0x30) + -1;
                }
              }
              *(undefined *)(plVar24 + 0x14) = 0;
              *(undefined4 *)((longlong)plVar24 + 0x9c) = 0;
              *(undefined4 *)(plVar24 + 0x17) = 0;
              *(int *)(plVar24 + 10) = iStack_548;
              if (((((*(uint *)(plVar24[0x20] + 0x10) & 1) != 0) &&
                   ((*(uint *)(plVar24[0x20] + 0x10) & 0x40) == 0)) &&
                  (*(char *)(*(longlong *)(lVar14 + 0x30) + 0x1cd2) != '\0')) &&
                 (*(char *)(*(longlong *)(lVar14 + 0x30) + 0x2050) == '\0')) {
                uStack_1e2 = 1;
                uStack_3d8 = *(undefined4 *)(*(longlong *)plVar24[0xb] + 0x20);
                uStack_3d4 = *(undefined2 *)(*(longlong *)plVar24[0xb] + 0x24);
                uStack_3d2 = (undefined2)*(undefined4 *)(plVar24 + 10);
                uStack_5d0 = 0x100c1c;
                func_0x
                          (auStack_1f0,*(undefined2 *)(*(longlong *)(lVar14 + 0x30) + 0x6b8),
                           &uStack_3d8);
                uStack_5d0 = 0x100c30;
                cVar6 = func_0x(lVar14,3,auStack_1f0);
                if (cVar6 == '\0') {
                  uStack_5d0 = 0x100c3c;
                  func_0x(plVar19);
                  uStack_5a8 = (longlong *)CONCAT71(uStack_5a8._1_7_,1);
                  uStack_5d0 = 0x100c5d;
                  func_0x(lVar14,3,*(undefined4 *)(*(longlong *)(*plVar19 + 0x18) + 0x18));
                  if (plVar24[0xb] == 0) {
                    uStack_5d0 = 0x100c6e;
                    func_0x(plVar19,0);
                  }
                }
              }
              uStack_518 = _DAT_;
              uStack_4dc = _DAT_;
              while( true ) {
                uStack_500 = uStack_588;
                uStack_50c = uVar29;
                if (((*(char *)(plVar24[7] + 0x29) != '\0') &&
                    ((*(uint *)(lStack_4d0 + 4) & 0x140) == 0)) &&
                   (lVar26 = plVar24[0x51], lVar14 = lStack_4c0,
                   *(ushort *)(plVar24 + 10) < *(ushort *)(lVar26 + 0x16))) {
                  iVar10 = *(int *)(plVar24 + 10);
                  lStack_488 = 0xfff - (longlong)iVar10;
                  if (*(short *)(lVar26 + lStack_488 * 2) != 0) {
                    iStack_27c = iVar10;
                    if (*(char *)(lVar26 + 2) < '\0') {
                      pbVar31 = (byte *)(lVar26 + 0x60);
                      if ((sStack_2b0 == 0) ||
                         (ppbVar15 = ppbStack_2a0, ppbStack_2a0 == (byte **)0x0)) {
                        auStack_278 = ZEXT816(0);
                        uStack_208 = 0;
                        auStack_268 = ZEXT816(0);
                        auStack_258 = ZEXT816(0);
                        auStack_248 = ZEXT816(0);
                        auStack_238 = ZEXT816(0);
                        auStack_228 = ZEXT816(0);
                        auStack_218 = ZEXT816(0);
                        uStack_5d0 = 0x100d72;
                        ppbVar15 = (byte **)func_0x(auStack_278);
                      }
                      uStack_5d0 = 0x100d8a;
                      uVar16 = func_0x(lVar26,auStack_1c0,0,0);
                      if (pbVar31 == *ppbVar15) {
                        uStack_5d0 = 0x100d9e;
                        func_0x(uVar16,ppbVar15 + 0xc);
                      }
                      *ppbVar15 = pbVar31;
                      uStack_5d0 = 0x100dad;
                      func_0x(ppbVar15 + 0xc,uVar16);
                      uStack_5d0 = 0x100dba;
                      func_0x((longlong)ppbVar15 + 0x6c,lVar26 + 0x20);
                      uStack_3a8 = *(undefined4 *)((ulonglong)*pbVar31 * 6 + 0x1595ce0);
                      sVar28 = *(short *)((ulonglong)*pbVar31 * 6 + 0x1595ce4);
                      *(undefined2 *)(ppbVar15 + 2) = 0xffff;
                      ppbVar15[3] = (byte *)0x0;
                      *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
                      *(undefined8 *)((longlong)ppbVar15 + 0x2e) = 0;
                      ppbVar15[7] = (byte *)0x0;
                      ppbVar15[4] = (byte *)0x0;
                      ppbVar15[9] = (byte *)0x0;
                      ppbVar15[10] = (byte *)0x0;
                      *(undefined2 *)(ppbVar15 + 0xb) = 0;
                      uStack_538 = CONCAT22(uStack_538._2_2_,sVar28);
                      if ((**ppbVar15 & 2) != 0) {
                        pbVar21 = pbVar31 + sVar28;
                        if ((pbVar31[sVar28] & 1) != 0) {
                          *(undefined2 *)(ppbVar15 + 2) = 1;
                          ppbVar15[3] = pbVar21;
                          uStack_588 = uStack_500;
                          uStack_584 = uStack_50c;
                          UNRECOVERED_JUMPTABLE =
                               (code *)((ulonglong)
                                        *(uint *)((ulonglong)
                                                  *(byte *)((longlong)(int)(*pbVar21 & 0x1c) +
                                                           0x1083f0) * 4 + 0x1083e0) - 0xfa4150);
                    /* WARNING: Could not emulate address calculation at 0x00100e65 */
                    /* WARNING: Treating indirect jump as call */
                          (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                          return;
                        }
                        *(undefined2 *)(ppbVar15 + 2) = 0;
                        ppbVar15[3] = pbVar21;
                        *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
                        *(undefined4 *)((longlong)ppbVar15 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010101f */
                    /* WARNING: Treating indirect jump as call */
                        (*(code *)((ulonglong)
                                   *(uint *)((longlong)(int)(*pbVar21 & 0xe) * 4 + 0x108410) -
                                  0xfa4150))();
                        return;
                      }
                      if ((**ppbVar15 & 4) != 0) {
                        uStack_3a8._2_2_ = (short)((uint)uStack_3a8 >> 0x10);
                        if (uStack_3a8._2_2_ == 0) {
                          uVar23 = (ulonglong)sVar28;
                        }
                        else {
                          uVar23 = (ulonglong)
                                   *(ushort *)(lVar26 + 0x61 + (longlong)uStack_3a8._2_2_ * 2);
                        }
                        uStack_5d0 = 0x1010d2;
                        func_0x(ppbVar15 + 9,pbVar31 + uVar23);
                      }
                      if (ppbVar15[1] != (byte *)0x0) {
                        uStack_5d0 = 0x1010e6;
                        func_0x(ppbVar15[1],ppbVar15);
                      }
                    }
                    pbStack_2a8 = (byte *)((ulonglong)*(ushort *)(lVar26 + lStack_488 * 2) + lVar26)
                    ;
                    if ((*pbStack_2a8 & 1) != 0) {
                      sStack_2b0 = 1;
                      UNRECOVERED_JUMPTABLE =
                           (code *)((ulonglong)
                                    *(uint *)((ulonglong)
                                              *(byte *)((longlong)(int)(*pbStack_2a8 & 0x1c) +
                                                       0x10845c) * 4 + 0x10844c) - 0xfa4150);
                    /* WARNING: Could not emulate address calculation at 0x00101138 */
                    /* WARNING: Treating indirect jump as call */
                      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                      return;
                    }
                    sStack_2b0 = 0;
                    uStack_2ac = 0;
                    uStack_28a = 0;
                    uStack_288 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101357 */
                    /* WARNING: Treating indirect jump as call */
                    (*(code *)((ulonglong)
                               *(uint *)((longlong)(int)(*pbStack_2a8 & 0xe) * 4 + 0x10847c) -
                              0xfa4150))();
                    return;
                  }
                }
                lVar26 = lStack_4d0;
                if (bVar36 != false) break;
                uStack_1d2 = 1;
                uStack_3d0 = *(undefined4 *)(*(longlong *)plVar24[0xb] + 0x20);
                uStack_3cc = *(undefined2 *)(*(longlong *)plVar24[0xb] + 0x24);
                uStack_3ca = (undefined2)*(undefined4 *)(plVar24 + 10);
                uStack_5d0 = 0x1015b5;
                func_0x
                          (auStack_1e0,*(undefined2 *)(*(longlong *)(lVar14 + 0x30) + 0x6b8),
                           &uStack_3d0);
                lVar26 = lStack_4d0;
                uStack_590 = CONCAT44(uStack_590._4_4_,iStack_514);
                uStack_598 = CONCAT44(uStack_598._4_4_,uStack_4f0);
                iStack_5a0 = iStack_54c;
                uStack_5d0 = 0x1015f1;
                uStack_5a8 = plVar24 + 0x12;
                iVar10 = func_0x(plVar19);
                if (iVar10 < 0) {
                  *(undefined4 *)(plVar24 + 0x1e) = 3;
                  iVar10 = 1;
                  *(undefined4 *)(plVar24 + 10) = 0xffffffff;
                  *(uint *)((longlong)plStack_540 + 0x66c) =
                       *(uint *)((longlong)plStack_540 + 0x66c) | 1;
                  uStack_538 = 1;
                  uVar33 = uStack_588;
                  goto LAB_;
                }
                if (iVar10 != 1) break;
                bVar36 = true;
                cStack_558 = bVar36;
              }
              *(undefined4 *)(plVar24 + 0x1e) = 4;
              lVar14 = *(longlong *)(lVar14 + 0x30);
              if (*(longlong *)(lVar14 + 0x1b28) != 0) {
                if (((((*(uint *)(plVar24[0x20] + 0x10) & 1) == 0) ||
                     ((*(uint *)(plVar24[0x20] + 0x10) & 0x40) != 0)) ||
                    (*(char *)(lVar14 + 0x1cd2) == '\0')) || (*(char *)(lVar14 + 0x2050) != '\0')) {
                  if (iStack_54c == 1) {
                    uStack_5d0 = 0x101667;
                    cVar6 = func_0x(lVar26);
                    if (cVar6 == '\0') goto LAB_;
                  }
                }
                else {
LAB_:
                  lVar14 = plVar24[0x51];
                  if (*(ushort *)(plVar24 + 10) < *(ushort *)(lVar14 + 0x16)) {
                    iVar10 = *(int *)(plVar24 + 10);
                    lStack_488 = 0xfff - (longlong)iVar10;
                    if (*(short *)(lVar14 + lStack_488 * 2) != 0) {
                      iStack_27c = iVar10;
                      if (*(char *)(lVar14 + 2) < '\0') {
                        pbVar31 = (byte *)(lVar14 + 0x60);
                        if ((sStack_2b0 == 0) ||
                           (ppbVar15 = ppbStack_2a0, ppbStack_2a0 == (byte **)0x0)) {
                          auStack_278 = ZEXT816(0);
                          uStack_208 = 0;
                          auStack_268 = ZEXT816(0);
                          auStack_258 = ZEXT816(0);
                          auStack_248 = ZEXT816(0);
                          auStack_238 = ZEXT816(0);
                          auStack_228 = ZEXT816(0);
                          auStack_218 = ZEXT816(0);
                          uStack_5d0 = 0x101724;
                          ppbVar15 = (byte **)func_0x(auStack_278);
                        }
                        uStack_5d0 = 0x10173c;
                        uVar16 = func_0x(lVar14,auStack_1b0,0,0);
                        if (pbVar31 == *ppbVar15) {
                          uStack_5d0 = 0x101750;
                          func_0x(uVar16,ppbVar15 + 0xc);
                        }
                        *ppbVar15 = pbVar31;
                        uStack_5d0 = 0x10175f;
                        func_0x(ppbVar15 + 0xc,uVar16);
                        uStack_5d0 = 0x10176c;
                        func_0x((longlong)ppbVar15 + 0x6c,lVar14 + 0x20);
                        uVar1 = *(undefined4 *)((ulonglong)*pbVar31 * 6 + 0x1595ce0);
                        sVar28 = *(short *)((ulonglong)*pbVar31 * 6 + 0x1595ce4);
                        uStack_4d8 = CONCAT44(uStack_4d8._4_4_,uVar1);
                        lVar26 = uStack_4d8;
                        *(undefined2 *)(ppbVar15 + 2) = 0xffff;
                        ppbVar15[3] = (byte *)0x0;
                        *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
                        *(undefined8 *)((longlong)ppbVar15 + 0x2e) = 0;
                        ppbVar15[7] = (byte *)0x0;
                        ppbVar15[4] = (byte *)0x0;
                        ppbVar15[9] = (byte *)0x0;
                        ppbVar15[10] = (byte *)0x0;
                        *(undefined2 *)(ppbVar15 + 0xb) = 0;
                        uStack_538 = CONCAT22(uStack_538._2_2_,sVar28);
                        if ((**ppbVar15 & 2) != 0) {
                          pbVar21 = pbVar31 + sVar28;
                          if ((pbVar31[sVar28] & 1) != 0) {
                            *(undefined2 *)(ppbVar15 + 2) = 1;
                            ppbVar15[3] = pbVar21;
                            uStack_588 = uStack_500;
                            uStack_584 = uStack_50c;
                            UNRECOVERED_JUMPTABLE =
                                 (code *)((ulonglong)
                                          *(uint *)((ulonglong)
                                                    *(byte *)((longlong)(int)(*pbVar21 & 0x1c) +
                                                             0x1084c8) * 4 + 0x1084b8) - 0xfa4150);
                    /* WARNING: Could not emulate address calculation at 0x00101817 */
                    /* WARNING: Treating indirect jump as call */
                            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                            return;
                          }
                          *(undefined2 *)(ppbVar15 + 2) = 0;
                          ppbVar15[3] = pbVar21;
                          *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
                          *(undefined4 *)((longlong)ppbVar15 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001019c8 */
                    /* WARNING: Treating indirect jump as call */
                          (*(code *)((ulonglong)
                                     *(uint *)((longlong)(int)(*pbVar21 & 0xe) * 4 + 0x1084e8) -
                                    0xfa4150))();
                          return;
                        }
                        if ((**ppbVar15 & 4) != 0) {
                          uStack_4d8._2_2_ = (short)((uint)uVar1 >> 0x10);
                          if (uStack_4d8._2_2_ == 0) {
                            uVar23 = (ulonglong)sVar28;
                          }
                          else {
                            uVar23 = (ulonglong)
                                     *(ushort *)(lVar14 + 0x61 + (longlong)uStack_4d8._2_2_ * 2);
                          }
                          uStack_5d0 = 0x101a7b;
                          uStack_4d8 = lVar26;
                          func_0x(ppbVar15 + 9,pbVar31 + uVar23);
                        }
                        if (ppbVar15[1] != (byte *)0x0) {
                          uStack_5d0 = 0x101a8f;
                          func_0x(ppbVar15[1],ppbVar15);
                        }
                      }
                      pbStack_2a8 = (byte *)((ulonglong)*(ushort *)(lVar14 + lStack_488 * 2) +
                                            lVar14);
                      if ((*pbStack_2a8 & 1) != 0) {
                        sStack_2b0 = 1;
                        UNRECOVERED_JUMPTABLE =
                             (code *)((ulonglong)
                                      *(uint *)((ulonglong)
                                                *(byte *)((longlong)(int)(*pbStack_2a8 & 0x1c) +
                                                         0x108534) * 4 + 0x108524) - 0xfa4150);
                    /* WARNING: Could not emulate address calculation at 0x00101add */
                    /* WARNING: Treating indirect jump as call */
                        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                        return;
                      }
                      sStack_2b0 = 0;
                      uStack_2ac = 0;
                      uStack_28a = 0;
                      uStack_288 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101cfc */
                    /* WARNING: Treating indirect jump as call */
                      (*(code *)((ulonglong)
                                 *(uint *)((longlong)(int)(*pbStack_2a8 & 0xe) * 4 + 0x108554) -
                                0xfa4150))();
                      return;
                    }
                  }
                }
              }
              uStack_5d0 = 0x101e5b;
              func_0x(plVar19,1);
              uStack_584 = *(uint *)(plVar24 + 0x4d);
              uStack_588 = *(uint *)((longlong)plVar24 + 0x26c);
              iVar10 = 0;
              uStack_538 = 0;
              plVar24 = plStack_3c8;
              uVar32 = uStack_4e0;
              uVar29 = uStack_584;
            }
            else {
              if (plVar24[0xb] == 0) {
                uStack_5d0 = 0x100aad;
                func_0x(plVar24 + 6,0);
              }
              if (*(int *)(plVar24 + 0x4e) == 0) {
                uStack_5d0 = 0x100ac2;
                func_0x(plVar24 + 6,1);
              }
              uStack_584 = *(uint *)(plVar24 + 0x4d);
              uStack_588 = *(uint *)((longlong)plVar24 + 0x26c);
              uVar29 = uStack_584;
LAB_:
              if (*(char *)(plVar24[5] + 0x29) != '\0') goto LAB_;
              if (iVar10 != 0) goto LAB_;
            }
            iVar13 = iStack_54c;
            if ((uVar29 != 3) ||
               ((*(char *)(*(longlong *)(plVar24[4] + 0x18) + 3) != '\0' &&
                ((iStack_54c == 0 || (iStack_514 == 0)))))) goto LAB_;
            bVar36 = false;
            if (*(char *)(plVar24[5] + 0x29) == '\0') {
              uStack_5d0 = 0x101f32;
              cVar6 = func_0x();
              if ((cVar6 == '\0') || (2 < (int)uVar32)) goto LAB_;
              uStack_4c8 = 0;
              uStack_5d0 = 0x101f5a;
              iVar12 = func_0x(plVar24,1,1);
            }
            else {
              bVar36 = (int)uVar32 < 0x32;
LAB_:
              uStack_4c8 = 0;
              uStack_5d0 = 0x101ee7;
              iVar12 = func_0x(plVar24,1,bVar36);
              if (bVar36 == false) goto LAB_;
            }
            if (1 < iVar12 - 1U) goto LAB_;
            uVar32 = uVar32 + 1;
            uStack_5d0 = 0x101f05;
            uStack_4e0 = uVar32;
            func_0x(plVar24 + 6);
            uVar33 = uStack_588;
            uStack_588 = uVar33;
            if (*(char *)(plVar24[5] + 0x29) == '\0') {
              uStack_5d0 = 0x101f25;
              func_0x(10);
              uStack_588 = uVar33;
            }
            goto LAB_;
          }
        }
        else {
LAB_:
          if (*(int *)((longlong)plStack_540 + 0x34) == 0) {
            iStack_548 = iStack_510 + *(int *)(plStack_540 + 6);
          }
          else {
            *(undefined4 *)((longlong)plStack_540 + 0x34) = 0;
            iStack_548 = *(int *)((longlong)plStack_540 + 0x684);
            if (iStack_548 == -1) {
              iStack_548 = (int)*(short *)((longlong)plStack_540 + 0x682);
              if (*(short *)((longlong)plStack_540 + 0x682) == -1) {
                if (iStack_510 == 1) {
                  iStack_548 = 0;
                }
                else {
                  iStack_548 = *(ushort *)(lVar14 + 0x16) - 1;
                }
              }
            }
            else {
              *(undefined4 *)((longlong)plStack_540 + 0x684) = 0xffffffff;
            }
          }
          if ((ushort)iStack_548 < *(ushort *)(lVar14 + 0x16)) {
            if ((*(short *)((longlong)plStack_540 + 0x682) == -1) ||
               (iStack_548 == *(short *)((longlong)plStack_540 + 0x682))) {
              *(int *)(plStack_540 + 6) = iStack_548;
              iVar12 = iStack_548;
              goto LAB_;
            }
            iStack_548 = -1;
          }
          else {
            iStack_548 = -1;
          }
        }
        plVar19 = plStack_540;
        plVar24 = plStack_540 + 0xd;
        if ((plStack_540[0xf] != _DAT_) || (plStack_540[0x10] != _DAT_)) {
          if ((*(byte *)(plStack_540 + 0x1b) & 2) != 0) {
            uStack_5d0 = 0x1002fc;
            iVar10 = func_0x(plStack_540 + 0x1c);
            if (iVar10 != 0) {
              *(longlong *)(*plVar24 + 0x30) = *(longlong *)(*plVar24 + 0x30) + -1;
            }
          }
          *(undefined *)(plVar19 + 0x1b) = 0;
          *(undefined4 *)((longlong)plVar19 + 0xd4) = 0;
          *(undefined4 *)(plVar19 + 0x1e) = 0;
          if ((*(byte *)(plVar19 + 0x21) & 2) != 0) {
            uStack_5d0 = 0x10032e;
            iVar10 = func_0x(plVar19 + 0x22);
            if (iVar10 != 0) {
              *(longlong *)(*plVar24 + 0x30) = *(longlong *)(*plVar24 + 0x30) + -1;
            }
          }
          *(undefined *)(plVar19 + 0x21) = 0;
          *(undefined4 *)((longlong)plVar19 + 0x104) = 0;
          *(undefined4 *)(plVar19 + 0x24) = 0;
          if (plVar19[0x12] != 0) {
            *(undefined *)((longlong)plVar19 + 0x9e) = 0;
            plVar19[0x12] = 0;
            *(undefined2 *)((longlong)plVar19 + 0x9c) = 0;
            *(undefined4 *)(plVar19[0xf] + 0x48) = 0;
          }
          uStack_5d0 = 0x100378;
          func_0x(*(undefined8 *)*plVar24,plVar19 + 0xf);
          uStack_5d0 = 0x100380;
          func_0x(plVar24);
          *(undefined4 *)(plVar19 + 0x25) = 2;
        }
        plVar5 = plStack_540;
        plVar2 = plStack_540 + 0x5d;
        if ((plStack_540[0x5f] != _DAT_) || (plStack_540[0x60] != _DAT_)) {
          if ((*(byte *)(plStack_540 + 0x6b) & 2) != 0) {
            uStack_5d0 = 0x1003ce;
            iVar10 = func_0x(plStack_540 + 0x6c);
            if (iVar10 != 0) {
              *(longlong *)(*plVar2 + 0x30) = *(longlong *)(*plVar2 + 0x30) + -1;
            }
          }
          *(undefined *)(plVar5 + 0x6b) = 0;
          *(undefined4 *)((longlong)plVar5 + 0x354) = 0;
          *(undefined4 *)(plVar5 + 0x6e) = 0;
          if ((*(byte *)(plVar5 + 0x71) & 2) != 0) {
            uStack_5d0 = 0x1003fd;
            iVar10 = func_0x(plVar5 + 0x72);
            if (iVar10 != 0) {
              *(longlong *)(*plVar2 + 0x30) = *(longlong *)(*plVar2 + 0x30) + -1;
            }
          }
          *(undefined *)(plVar5 + 0x71) = 0;
          *(undefined4 *)((longlong)plVar5 + 900) = 0;
          *(undefined4 *)(plVar5 + 0x74) = 0;
          if (plVar5[0x62] != 0) {
            *(undefined *)((longlong)plVar5 + 0x31e) = 0;
            plVar5[0x62] = 0;
            *(undefined2 *)((longlong)plVar5 + 0x31c) = 0;
            *(undefined4 *)(plVar5[0x5f] + 0x48) = 0;
          }
          uStack_5d0 = 0x100448;
          func_0x(*(undefined8 *)*plVar2,plVar5 + 0x5f);
          uStack_5d0 = 0x100450;
          func_0x(plVar2);
          *(undefined4 *)(plVar5 + 0x75) = 2;
        }
        *(undefined4 *)((longlong)plStack_540 + 0x66c) = 0;
        while( true ) {
          uStack_5a8 = (longlong *)&uStack_2c0;
          uStack_5d0 = 0x1004a5;
          iVar10 = func_0x(*(undefined8 *)plStack_540[3]);
          if (iVar10 != 0) {
            plVar24 = (longlong *)0x0;
            iVar13 = 1;
            *pplStack_4e8 = (longlong *)0x0;
            pplVar25 = pplStack_4e8;
            param_1 = lStack_4f8;
            iVar10 = uStack_538;
            goto LAB_;
          }
          uVar1 = *(undefined4 *)(plStack_540 + 0xcf);
          *(uint *)((longlong)plStack_540 + 0x66c) =
               *(uint *)((longlong)plStack_540 + 0x66c) & 0xfffffffe;
          uStack_1f2 = 1;
          uVar16 = *(undefined8 *)*plVar24;
          plVar2 = *(longlong **)(plVar19[0xe] + 8);
          *(undefined4 *)(plVar19 + 0xf) = uStack_2c0;
          *(undefined4 *)((longlong)plVar19 + 0x7c) = uStack_2bc;
          *(undefined4 *)(plVar19 + 0x10) = uStack_2b8;
          *(undefined4 *)((longlong)plVar19 + 0x84) = uStack_2b4;
          uStack_5d0 = 0x1004eb;
          func_0x(uVar16);
          plVar19[0x58] = *(longlong *)plVar19[0x12];
          *(undefined4 *)(plVar19 + 0x18) = uVar1;
          *(undefined4 *)((longlong)plVar19 + 0x2d4) = 0;
          lVar14 = *(longlong *)(*plVar24 + 0x18);
          if (((((*(uint *)(plVar19[0x27] + 0x10) & 1) != 0) &&
               ((*(uint *)(plVar19[0x27] + 0x10) & 0x40) == 0)) &&
              (*(char *)(plVar2[6] + 0x1cd2) != '\0')) && (*(char *)(plVar2[6] + 0x2050) == '\0')) {
            uStack_42c = *(undefined4 *)(plVar19[0xf] + 0x90);
            uStack_428 = *(undefined2 *)(plVar19[0xf] + 0x94);
            uStack_5d0 = 0x100584;
            func_0x(auStack_200,*(undefined2 *)(plVar2[6] + 0x6b8),&uStack_42c,0);
            uStack_5d0 = 0x10059d;
            cVar6 = func_0x(*(undefined8 *)(plVar19[0xe] + 8));
            if (cVar6 == '\0') {
              uStack_5d0 = 0x1005a9;
              func_0x(plVar24);
              uStack_5a8 = (longlong *)CONCAT71(uStack_5a8._1_7_,1);
              uStack_5d0 = 0x1005cf;
              func_0x(*(undefined8 *)(plVar19[0xe] + 8));
            }
          }
          if (*(char *)(lVar14 + 2) == '\0') {
            uStack_5d0 = 0x1005e1;
            func_0x(*(undefined8 *)plVar19[0xe]);
          }
          else {
            uStack_5d0 = 0x10062c;
            cVar6 = (**(code **)(*plVar2 + 0x28))(plVar2);
            if (cVar6 == '\0') {
              uStack_426 = *(undefined4 *)(plVar19[0xf] + 0x90);
              uStack_422 = *(undefined2 *)(plVar19[0xf] + 0x94);
              uStack_5d0 = 0x100677;
              func_0x
                        (auStack_200,
                         *(undefined2 *)
                          (*(longlong *)(*(longlong *)(plVar19[0xe] + 8) + 0x30) + 0x6b8),
                         &uStack_426,0);
              uStack_5a8 = plVar19 + 0x1f;
              uStack_590 = CONCAT44(uStack_590._4_4_,1);
              uStack_598 = CONCAT44(uStack_598._4_4_,1);
              iStack_5a0 = 1;
              uStack_5d0 = 0x1006aa;
              iVar10 = func_0x(plVar24);
              if (iVar10 < 0) {
                if ((plVar19[0xf] != _DAT_) || (plVar19[0x10] != _DAT_)) {
                  if ((*(byte *)(plVar19 + 0x1b) & 2) != 0) {
                    uStack_5d0 = 0x1006e5;
                    iVar10 = func_0x(plVar19 + 0x1c);
                    if (iVar10 != 0) {
                      *(longlong *)(*plVar24 + 0x30) = *(longlong *)(*plVar24 + 0x30) + -1;
                    }
                  }
                  *(undefined *)(plVar19 + 0x1b) = 0;
                  *(undefined4 *)((longlong)plVar19 + 0xd4) = 0;
                  *(undefined4 *)(plVar19 + 0x1e) = 0;
                  if ((*(byte *)(plVar19 + 0x21) & 2) != 0) {
                    uStack_5d0 = 0x10071a;
                    iVar10 = func_0x(plVar19 + 0x22);
                    if (iVar10 != 0) {
                      *(longlong *)(*plVar24 + 0x30) = *(longlong *)(*plVar24 + 0x30) + -1;
                    }
                  }
                  *(undefined *)(plVar19 + 0x21) = 0;
                  *(undefined4 *)((longlong)plVar19 + 0x104) = 0;
                  *(undefined4 *)(plVar19 + 0x24) = 0;
                  if (plVar19[0x12] != 0) {
                    if (plVar19[0x12] != 0) {
                      *(undefined *)((longlong)plVar19 + 0x9e) = 0;
                      plVar19[0x12] = 0;
                      *(undefined2 *)((longlong)plVar19 + 0x9c) = 0;
                    }
                    *(undefined4 *)(plVar19[0xf] + 0x48) = 0;
                  }
                  uStack_5d0 = 0x10076a;
                  func_0x(*(undefined8 *)*plVar24);
                  uStack_5d0 = 0x100772;
                  func_0x(plVar24);
                  *(undefined4 *)(plVar19 + 0x25) = 2;
                }
                *(uint *)((longlong)plStack_540 + 0x66c) =
                     *(uint *)((longlong)plStack_540 + 0x66c) | 1;
                goto LAB_;
              }
            }
          }
          *(undefined4 *)(plVar19 + 0x25) = 3;
          if (plVar19[0x12] != 0) break;
          uStack_5d0 = 0x100605;
          func_0x(plVar24,1);
          if (*(int *)(plVar19 + 0x25) == 3) break;
          *(uint *)((longlong)plStack_540 + 0x66c) = *(uint *)((longlong)plStack_540 + 0x66c) | 1;
        }
        *(uint *)((longlong)plStack_540 + 0x66c) = *(uint *)((longlong)plStack_540 + 0x66c) | 1;
LAB_:
        *(undefined4 *)((longlong)plStack_540 + 0x34) = 1;
        iVar10 = uStack_538;
        uVar33 = uStack_588;
        uVar29 = uStack_584;
      } while( true );
    }
    uStack_5d0 = 0x102199;
    iVar13 = (**(code **)(*plStack_540 + 0x38))(plStack_540);
    plVar24 = *pplVar25;
    goto LAB_;
  }
  goto LAB_;
LAB_:
  if (plVar24[0x5b] == 0) {
    uStack_5d0 = 0x101f74;
    func_0x(plVar24 + 0x56,0);
  }
  if (*(int *)(plVar24 + 0x9e) == 0) {
    uStack_5d0 = 0x101f8c;
    func_0x(plVar24 + 0x56,1);
  }
  uStack_588 = *(uint *)((longlong)plVar24 + 0x4ec);
LAB_:
  plVar19 = plStack_540;
  uVar33 = uStack_588;
  uVar32 = *(uint *)((longlong)plVar24 + 0x634);
  *(uint *)((longlong)plVar24 + 0x634) = uVar32 | 1;
  if (iVar10 != 0) goto LAB_;
  if (uVar29 == 2) goto LAB_;
  if (uVar29 == 3) {
    if ((*(char *)(*(longlong *)(plStack_540[3] + 0x18) + 3) == '\0') ||
       ((iStack_54c != 0 && (iStack_514 != 0)))) goto LAB_;
    iVar13 = 1;
    iStack_54c = 1;
    iStack_514 = 1;
    if (plStack_540[0x58] == 0) {
      *(uint *)((longlong)plStack_540 + 0x66c) = uVar32 & 0xfffffffe;
      if (*(int *)(plStack_540 + 0x75) == 4) {
        uStack_5d0 = 0x10202e;
        func_0x(plStack_540 + 0x5d);
      }
      uStack_5d0 = 0x102037;
      func_0x(plVar19 + 0xd);
      if (*(char *)(plVar19[0xc] + 0xb5) == '\0') {
        *(uint *)((longlong)plVar19 + 0x66c) = *(uint *)((longlong)plVar19 + 0x66c) | 1;
      }
    }
    goto LAB_;
  }
  if ((uVar29 == 1) || (uVar29 == 4)) goto LAB_;
LAB_:
  if (uStack_588 == 0) {
LAB_:
    if ((*(int *)(*(longlong *)(plStack_540[3] + 0x18) + 8) == 0x10000) ||
       (*(longlong *)(*(longlong *)(plStack_540[3] + 0x18) + 0x10) != 0)) {
      uStack_5d0 = 0x102131;
      func_0x(plVar24);
    }
    goto LAB_;
  }
  iVar13 = 0;
  plVar24 = plStack_540 + 7;
  *pplStack_4e8 = plVar24;
  pplVar25 = pplStack_4e8;
  param_1 = lStack_4f8;
LAB_:
  if (iVar13 != 0) {
    if (plVar24 != (longlong *)0x0) {
      uStack_5a8 = (longlong *)0x0;
      uStack_5d0 = 0x102393;
      (*_DAT_)(1,0x194a078);
    }
    uStack_5d0 = 0x10239e;
    iVar13 = func_0x(param_1);
    puVar27 = auStack_5c8;
    if (iVar13 != 0) goto LAB_;
    goto LAB_;
  }
  lVar14 = *(longlong *)(*(longlong *)(param_1 + 0x1e0) + 0x58);
  if (lVar14 != 0) {
    plVar24 = (longlong *)(lVar14 + 0x58);
    *plVar24 = *plVar24 + 1;
    plVar24 = *pplVar25;
  }
  if ((((*(uint *)(param_1 + 0x2e8) & 0x800) == 0) ||
      (plVar24 = *pplVar25, plVar24 == (longlong *)0x0)) || (*(char *)(plVar24 + 199) == '\0')) {
    lStack_3c0 = *(longlong *)(param_1 + 0x178);
    puVar3 = *(undefined8 **)(param_1 + 0x168);
    lVar14 = param_1 + 400;
    plVar19 = *(longlong **)(param_1 + 0x160);
    lVar26 = *(longlong *)(param_1 + 0x158);
    lStack_488 = *(longlong *)(param_1 + 0x170);
    uStack_5d0 = 0x10222b;
    uVar16 = func_0x(plVar24);
    if ((lVar26 == 0) && (puVar3 == (undefined8 *)0x0)) {
LAB_:
      if (plVar19 != (longlong *)0x0) {
        plVar2 = *(longlong **)plVar19[1];
        *(undefined8 *)(param_1 + 0x1b0) = uVar16;
        *(longlong **)(param_1 + 0x1a8) = plVar24;
        uStack_5d0 = 0x1022a7;
        (**(code **)(*plVar2 + 0x20))(plVar2,lVar14);
        uStack_5d0 = 0x1022b7;
        iVar10 = (**(code **)(*plVar19 + 8))(plVar19);
        if (iVar10 == 0) goto LAB_;
      }
      pplVar25 = pplStack_4e8;
      lVar26 = lStack_4f8;
      if (lStack_488 != 0) {
        *(undefined8 *)(param_1 + 0x1b0) = uVar16;
        *(longlong **)(param_1 + 0x1a8) = plVar24;
        uStack_5d0 = 0x1022e5;
        iVar10 = func_0x(lVar14);
        pplVar25 = pplStack_4e8;
        lVar26 = lStack_4f8;
        if (iVar10 == 0) goto LAB_;
      }
    }
    else {
      *(undefined8 *)(param_1 + 0x1b0) = uVar16;
      *(longlong **)(param_1 + 0x1a8) = plVar24;
      alStack_318[0] = lVar14;
      if (lVar26 == 0) {
LAB_:
        if (puVar3 != (undefined8 *)0x0) {
          uStack_5d0 = 0x10227f;
          cVar6 = (**(code **)*puVar3)(puVar3);
          if (cVar6 == '\0') goto LAB_;
        }
        goto LAB_;
      }
      uStack_5d0 = 0x10225c;
      (**(code **)(lVar26 + 8))(alStack_318);
      if ((*(char *)(param_1 + 0xac0) != '\x03') && (*(char *)(param_1 + 0xac8) != '\0'))
      goto LAB_;
LAB_:
      pplVar25 = pplStack_4e8;
      param_1 = lStack_4f8;
      if ((cStack_530 == '\0') ||
         (lVar14 = *(longlong *)(lStack_4f8 + 0x1e0), plVar24 = (longlong *)(lVar14 + 0x60),
         *plVar24 = *plVar24 + 1, *(longlong *)(lVar14 + 0x60) < 10000)) {
        lVar14 = *(longlong *)(*(longlong *)(lStack_4f8 + 0x2d8) + 0x18);
        if ((*(int *)(lVar14 + 8) == 0x10000) || (*(longlong *)(lVar14 + 0x10) != 0)) {
          uStack_5d0 = 0x10233d;
          func_0x(*pplStack_4e8);
        }
        uStack_5d0 = 0x10234f;
        (**(code **)(**pplVar25 + 8))();
        iVar10 = uStack_538;
        goto LAB_;
      }
      *(undefined *)puStack_3b0[1] = 1;
      *(undefined8 *)(*(longlong *)(lStack_4f8 + 0x1e0) + 0x60) = 0;
      lVar26 = lStack_4f8;
    }
  }
  else {
    lVar14 = *(longlong *)(*(longlong *)(param_1 + 0x1e0) + 0x58);
    lVar26 = param_1;
    if (lVar14 != 0) {
      plVar24 = (longlong *)(lVar14 + 0x70);
      *plVar24 = *plVar24 + 1;
      lVar26 = param_1;
    }
  }
  puVar27 = auStack_5c8;
  if ((*(byte *)((longlong)pplStack_560 + 0x14) & 0x10) == 0) goto LAB_;
  pplVar25 = (longlong **)*pplVar25;
  plVar24 = *pplStack_560;
  pplStack_4e8 = pplVar25;
  if ((((*(uint *)(lVar26 + 0x2e8) & 0x800) != 0) && (pplVar25 != (longlong **)0x0)) &&
     (*(char *)(pplVar25 + 199) != '\0')) {
    plVar19 = pplVar25[200];
    plVar2 = pplStack_560[3];
    lVar14 = plVar24[0x20];
    if (plVar19 == (longlong *)0x0) {
      uStack_5a8 = (longlong *)0x0;
      uStack_5d0 = 0x102469;
      (*_DAT_)(1,0x1948cd8,0x191d5c8,0x3b);
    }
    uStack_5d0 = 0x102477;
    func_0x(plVar19,lVar14,plVar2);
    puVar27 = auStack_5c8;
    goto LAB_;
  }
  if ((*(short *)((longlong)plVar24 + 0x3a) != 0) || (*(int *)(plVar24 + 10) != 0)) {
    uStack_5d0 = 0x108355;
    func_0x(lVar26,pplVar25,pplStack_560,&iStack_498);
    puVar27 = auStack_5c8;
    if (iStack_498 != 1) {
      lVar14 = *(longlong *)(*(longlong *)(lVar26 + 0x108) + 0x70);
      puVar27 = auStack_5c8;
      if ((lVar14 != 0) &&
         (puVar27 = auStack_5c8, (*(uint *)(*(longlong *)(lVar26 + 0x108) + 0x120) & 0x100) != 0)) {
        uStack_5d0 = 0x108386;
        func_0x(pplVar25 + 6,lVar14);
        puVar27 = auStack_5c8;
        if (*(int *)(pplVar25 + 0x6e) == 4) {
          uStack_5d0 = 0x10839f;
          func_0x(pplVar25 + 0x56,lVar14);
          puVar27 = auStack_5c8;
        }
      }
    }
    goto LAB_;
  }
  uStack_5d0 = 0x1024a3;
  psVar17 = (short *)func_0x(pplVar25,1);
  lVar14 = lVar26 + 0x110;
  plStack_540 = (longlong *)(lVar26 + 0xa60);
  plVar24 = *pplStack_560;
  uStack_4d8 = lVar14;
  if ((*(byte *)(plVar24 + 6) & 1) != 0) {
    puVar30 = (uint *)0x0;
    uVar33 = 0;
    if (*psVar17 == 0) {
      if ((**(byte **)(psVar17 + 4) & 0x10) != 0) {
        uVar33 = (uint)*(ushort *)(*(byte **)(psVar17 + 4) + *(uint *)(psVar17 + 8));
      }
    }
    else {
      uVar33 = (uint)(ushort)psVar17[1];
    }
    if (*(uint *)(plVar24 + 3) <= uVar33) {
      *psVar17 = 0;
      plVar24 = pplStack_560[1];
      uStack_500 = (uint)*(ushort *)((longlong)*pplStack_560 + 0x62);
      puVar27 = auStack_5c8;
      puVar34 = puVar30;
      pplVar25 = pplStack_560;
      if (uStack_500 != 0) goto LAB_;
      goto LAB_;
    }
  }
  if (pplStack_4e8 == (longlong **)0x0) {
    *(short **)(lVar26 + 0xa68) = psVar17;
    *(undefined8 *)(lVar26 + 0xa70) = 0;
  }
  else {
    *(undefined8 *)(lVar26 + 0xa68) = 0;
    *(longlong ***)(lVar26 + 0xa70) = pplStack_4e8;
    uStack_5d0 = 0x103575;
    lVar18 = (*(code *)**pplStack_4e8)();
    plStack_540[1] = lVar18;
  }
  uVar23 = 0;
  if (*psVar17 == 0) {
    *psVar17 = 0;
    puVar27 = auStack_5c8;
    if ((*(byte *)((longlong)pplStack_560 + 0x14) & 0x10) != 0) {
      uVar33 = *(uint *)(pplStack_560 + 2);
      plVar24 = pplStack_560[1];
      uStack_584 = 0;
      puVar27 = auStack_5c8;
      lVar26 = lStack_4f8;
      uStack_588 = uVar33;
      if (uVar33 != 0) {
        do {
          if (*(byte *)(plVar24 + 8) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(plVar24 + 8) * 4 + 0x108590) -
                         0xfa4150);
                    /* WARNING: Could not emulate address calculation at 0x001035e5 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,pplStack_560,0,plStack_540);
            return;
          }
          uVar29 = *(uint *)(plVar24 + 8);
          if ((uVar29 >> 10 & 1) != 0) {
            if ((*(byte *)(plVar24[9] + 0x2a) & 0x10) == 0) {
              plVar19 = pplStack_560[3];
            }
            else {
              plVar19 = pplStack_560[4];
            }
            *(undefined *)((longlong)plVar19 + plVar24[6]) = 3;
            uVar29 = *(uint *)(plVar24 + 8);
          }
          if ((uVar29 >> 9 & 1) != 0) {
            uStack_5a8 = (longlong *)CONCAT44(uStack_5a8._4_4_,uStack_554);
            uStack_5d0 = 0x105580;
            func_0x(pplStack_560,lVar14,plVar24,0);
          }
          uStack_584 = (int)uVar23 + 1;
          uVar23 = (ulonglong)uStack_584;
          plVar24 = plVar24 + 10;
          puVar27 = auStack_5c8;
          lVar26 = lStack_4f8;
        } while (uStack_584 < uVar33);
      }
    }
  }
  else if (*(int *)(*(longlong *)(lVar26 + 0x118) + 0x100) == 2) {
    uStack_4e0 = *(uint *)((longlong)plVar24 + 0x34);
    uVar22 = (ulonglong)uStack_4e0 + 0xf;
    if (uVar22 <= uStack_4e0) {
      uVar22 = 0xffffffffffffff0;
    }
    uVar22 = uVar22 & 0xfffffffffffffff0;
    uStack_5d0 = 0x105f46;
    pplVar25 = pplStack_560;
    func_0x();
    lVar18 = -uVar22;
    lStack_4d0 = (longlong)&uStack_588 + lVar18;
    puVar27 = auStack_5c8 + lVar18;
    lVar26 = lStack_4f8;
    if ((*(byte *)((longlong)pplVar25 + 0x14) & 0x10) != 0) {
      uStack_500 = *(uint *)(pplVar25 + 2);
      plVar24 = pplVar25[1];
      uStack_4ec = (uint)uVar23;
      puVar27 = auStack_5c8 + lVar18;
      uVar22 = uVar23;
      if (uStack_500 != 0) {
        do {
          pplVar4 = pplStack_560;
          if (*(byte *)(plVar24 + 8) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(plVar24 + 8) * 4 + 0x1088e0) -
                         0xfa4150);
                    /* WARNING: Could not emulate address calculation at 0x00105fa6 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          uVar33 = *(uint *)(plVar24 + 8);
          if ((uVar33 >> 10 & 1) != 0) {
            if ((*(byte *)(plVar24[9] + 0x2a) & 0x10) == 0) {
              plVar19 = pplVar25[3];
            }
            else {
              plVar19 = pplVar25[4];
            }
            uVar20 = (undefined)uVar22;
            if (uVar23 == 0) {
              uVar20 = 3;
            }
            *(undefined *)((longlong)plVar19 + plVar24[6]) = uVar20;
            uVar33 = *(uint *)(plVar24 + 8);
          }
          if ((uVar33 >> 9 & 1) != 0) {
            *(undefined4 *)((longlong)&uStack_5a8 + lVar18) = uStack_568;
            *(undefined8 *)(auStack_5c8 + lVar18 + -8) = 0x1082d5;
            func_0x(pplVar4,lVar14,plVar24,uVar23);
          }
          uStack_4ec = uStack_4ec + 1;
          plVar24 = plVar24 + 10;
          pplVar25 = pplStack_560;
          puVar27 = auStack_5c8 + lVar18;
          uVar22 = 0;
          lVar26 = lStack_4f8;
        } while (uStack_4ec < uStack_500);
      }
    }
  }
  else {
    if (*psVar17 == -1) {
      *psVar17 = 1;
    }
    puVar27 = auStack_5c8;
    if ((*(byte *)((longlong)pplStack_560 + 0x14) & 0x10) != 0) {
      uVar33 = *(uint *)(pplStack_560 + 2);
      plVar24 = pplStack_560[1];
      puVar27 = auStack_5c8;
      if (uVar33 != 0) {
        do {
          if (*(byte *)(plVar24 + 8) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(plVar24 + 8) * 4 + 0x108738) -
                         0xfa4150);
                    /* WARNING: Could not emulate address calculation at 0x001055f7 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,pplStack_560,0,plStack_540);
            return;
          }
          uVar29 = *(uint *)(plVar24 + 8);
          if ((uVar29 & 0x400) != 0) {
            if ((*(byte *)(plVar24[9] + 0x2a) & 0x10) == 0) {
              plVar19 = pplStack_560[3];
            }
            else {
              plVar19 = pplStack_560[4];
            }
            *(undefined *)((longlong)plVar19 + plVar24[6]) = 3;
            uVar29 = *(uint *)(plVar24 + 8);
          }
          if ((uVar29 >> 9 & 1) != 0) {
            uStack_5a8 = (longlong *)CONCAT44(uStack_5a8._4_4_,uStack_51c);
            uStack_5d0 = 0x105efb;
            func_0x(pplStack_560,uStack_4d8,plVar24,0);
          }
          uVar29 = (int)uVar23 + 1;
          uVar23 = (ulonglong)uVar29;
          plVar24 = plVar24 + 10;
          puVar27 = auStack_5c8;
          lVar26 = lStack_4f8;
        } while (uVar29 < uVar33);
      }
    }
  }
  pplVar25 = pplStack_4e8;
  if (pplStack_4e8 != (longlong **)0x0) {
    UNRECOVERED_JUMPTABLE = *(code **)(**(longlong **)(lVar26 + 0xa70) + 8);
    *(undefined8 *)(puVar27 + -8) = 0x108335;
    (*UNRECOVERED_JUMPTABLE)();
    UNRECOVERED_JUMPTABLE = (code *)(*pplVar25)[1];
    *(undefined8 *)(puVar27 + -8) = 0x10833e;
    (*UNRECOVERED_JUMPTABLE)(pplVar25);
    goto LAB_;
  }
  goto LAB_;
LAB_:
  do {
    cVar6 = *(char *)(plVar24 + 8);
    if (cVar6 == '\x01') {
      if ((*(byte *)((longlong)plVar24 + 6) & 0x10) == 0) {
        uVar33 = *(ushort *)((longlong)plVar24 + 4) - 1;
        uVar33 = *(byte *)((ulonglong)(uVar33 >> 3) + (ulonglong)*(uint *)(psVar17 + 8) + 2 +
                          *(longlong *)(psVar17 + 4)) >> ((byte)uVar33 & 7) & 1;
      }
      else {
        uStack_5a8 = &uStack_354;
        uStack_5d0 = 0x103369;
        func_0x(psVar17 + 1,plVar24,1,&uStack_480);
        uVar33 = uStack_480;
      }
      if (uVar33 == 0) goto LAB_;
LAB_:
      if ((*(byte *)(plVar24[9] + 0x2a) & 0x10) == 0) {
        *(undefined *)((longlong)pplVar25[3] + plVar24[6]) = 3;
      }
      else {
        *(undefined *)((longlong)pplVar25[4] + plVar24[6]) = 3;
      }
    }
    else {
      if (cVar6 == '\x02') {
LAB_:
        uVar9 = *(ushort *)((longlong)plVar24 + 0x3c);
        if ((*(byte *)((longlong)plVar24 + 6) & 0x10) == 0) {
LAB_:
          puVar30 = (uint *)((longlong)(int)*(uint *)plVar24 + *(longlong *)(psVar17 + 4));
          uVar33 = (uint)uVar9;
        }
        else {
          uStack_5a8 = (longlong *)&iStack_47c;
          uStack_5d0 = 0x1033fa;
          func_0x(psVar17 + 1,plVar24,0,auStack_358);
          if (iStack_47c != 0) goto LAB_;
          uVar33 = *(uint *)plVar24[1];
          puVar30 = (uint *)plVar24[1] + 1;
          if ((uVar9 != 0) && (uVar33 != uVar9)) {
            uStack_5a8 = (longlong *)0x0;
            uStack_5d0 = 0x10343b;
            (*_DAT_)(1,0x1946f68,0x1945968,0x381);
          }
        }
        uStack_550 = uVar33;
        pplVar25 = pplStack_560;
        if ((*(byte *)(plVar24[9] + 0x2a) & 0x10) == 0) {
LAB_:
          plVar19 = pplVar25[3];
        }
        else {
          plVar19 = pplStack_560[4];
        }
LAB_:
        *(undefined *)((longlong)plVar19 + plVar24[6]) = 0;
      }
      else {
        if (cVar6 == '\x03') {
          if ((*(byte *)((longlong)plVar24 + 6) & 0x10) == 0) {
            uVar33 = *(ushort *)((longlong)plVar24 + 4) - 1;
            uVar33 = *(byte *)((ulonglong)(uVar33 >> 3) + (ulonglong)*(uint *)(psVar17 + 8) + 2 +
                              *(longlong *)(psVar17 + 4)) >> ((byte)uVar33 & 7) & 1;
          }
          else {
            uStack_5a8 = &uStack_34c;
            uStack_5d0 = 0x102d02;
            func_0x(psVar17 + 1,plVar24,1,auStack_3e0);
            uVar33 = auStack_3e0[0];
          }
          if (uVar33 != 0) goto LAB_;
        }
        else if (cVar6 != '\x04') {
          if (cVar6 == '\b') {
            uVar9 = *(ushort *)((longlong)plVar24 + 0x3c);
            iVar10 = *(uint *)(plVar24 + 8) << 0xc;
            if ((*(uint *)plVar24 & 0xc0000000) == 0x80000000) {
              uStack_5d0 = 0x102c68;
              iVar10 = func_0x(psVar17 + 1);
              if (iVar10 != 0) {
                uStack_5d0 = 0x102c83;
                puVar30 = (uint *)func_0x(psVar17 + 0x15,plVar24,&uStack_550,
                                                  (longlong)&uStack_34c + 4);
                uVar33 = uStack_550;
                goto LAB_;
              }
              uStack_550 = 0;
              puVar30 = (uint *)0x0;
              uVar9 = *(ushort *)(plVar24[9] + 0x2a);
LAB_:
              if ((uVar9 & 0x10) == 0) {
                *(undefined *)((longlong)pplVar25[3] + plVar24[6]) = 3;
              }
              else {
                *(undefined *)((longlong)pplVar25[4] + plVar24[6]) = 3;
              }
              goto LAB_;
            }
            if ((iVar10 < 0) || ((*(byte *)((longlong)plVar24 + 6) & 0x10) != 0)) {
              uStack_5a8 = (longlong *)&iStack_494;
              uStack_5d0 = 0x1025e6;
              func_0x(psVar17 + 1,plVar24,iVar10 < 0,&iStack_49c);
              if ((iVar10 < 0) && (iStack_49c != 0)) {
                uStack_550 = 0;
                puVar30 = (uint *)0x0;
                pplVar25 = pplStack_560;
                uVar33 = uStack_550;
                goto LAB_;
              }
            }
            else {
              iStack_49c = 0;
              iStack_494 = 1;
            }
            if ((iStack_494 == 0) && ((*(byte *)((longlong)plVar24 + 6) & 0x10) != 0)) {
              puVar30 = (uint *)plVar24[1] + 1;
              pplVar25 = pplStack_560;
              uVar33 = *(uint *)plVar24[1];
            }
            else if ((int)*(uint *)plVar24 < 0) {
              if (*(int *)(psVar17 + 2) == 0) {
                psVar17[1] = 0;
                uVar33 = *(uint *)(psVar17 + 8);
                uVar23 = (ulonglong)uVar33;
                *(uint *)(psVar17 + 10) = uVar33;
                pbVar31 = *(byte **)(psVar17 + 4);
                bVar7 = *pbVar31;
                if ((bVar7 & 0x10) != 0) {
                  uVar33 = uVar33 + (*(ushort *)(pbVar31 + uVar23) + 7 >> 3) + 2;
                  uVar23 = (ulonglong)uVar33;
                  *(uint *)(psVar17 + 10) = uVar33;
                  bVar7 = *pbVar31;
                }
                if ((bVar7 & 0x20) == 0) {
                  *(int *)(psVar17 + 2) = (int)uVar23;
                  psVar17[0xe] = 0;
                  *(uint *)(psVar17 + 0xc) = uVar33;
                }
                else {
                  puVar35 = (ushort *)(pbVar31 + uVar23);
                  uVar9 = *puVar35;
                  psVar17[0xe] = uVar9;
                  if (uVar9 == 0) {
                    uStack_5d0 = 0x102754;
                    cVar6 = func_0x(0x1ea8470);
                    if (cVar6 != '\0') {
                      uStack_5d0 = 0x10275d;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        uStack_5d0 = 0x102777;
                        cVar6 = func_0x(0x1ea8470);
                        if (cVar6 == '\0') {
                          uStack_5d0 = 0x102793;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          uStack_5a8 = (longlong *)0x0;
                          uStack_5d0 = 0x1027b6;
                          (*_DAT_)(1,0x17991f8,0x18b8ec8,0x80f);
                        }
                      }
                    }
                    uStack_5d0 = 0x1027c4;
                    func_0x(*(undefined8 *)(psVar17 + 4),3);
                    uVar9 = psVar17[0xe];
                    uVar33 = *(uint *)(psVar17 + 10);
                  }
                  uVar33 = uVar33 + (uVar9 + 1) * 2;
                  *(uint *)(psVar17 + 0xc) = uVar33;
                  if (0x1f9e < uVar33) {
                    uStack_5d0 = 0x1027f3;
                    cVar6 = func_0x(0x1ea8470);
                    if (cVar6 != '\0') {
                      uStack_5d0 = 0x1027fc;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        uStack_5d0 = 0x102816;
                        cVar6 = func_0x(0x1ea8470);
                        if (cVar6 == '\0') {
                          uStack_5d0 = 0x102832;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_5a8 = (longlong *)0x0;
                          uStack_5d0 = 0x102855;
                          (*_DAT_)(1,0x17991f8,0x18b8ec8,0x816);
                        }
                      }
                    }
                    uStack_5d0 = 0x102863;
                    func_0x(*(undefined8 *)(psVar17 + 4),4);
                    uVar9 = psVar17[0xe];
                    uVar33 = *(uint *)(psVar17 + 0xc);
                  }
                  uVar23 = (ulonglong)uVar9;
                  uVar9 = puVar35[uVar23];
                  *(uint *)(psVar17 + 2) = uVar9 & 0x7fff;
                  if ((uVar9 & 0x7fff) < uVar33) {
                    uStack_5d0 = 0x102891;
                    cVar6 = func_0x(0x1ea8470);
                    if (cVar6 != '\0') {
                      uStack_5d0 = 0x10289a;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        uStack_5d0 = 0x1028b4;
                        cVar6 = func_0x(0x1ea8470);
                        if (cVar6 == '\0') {
                          uStack_5d0 = 0x1028d0;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_5a8 = (longlong *)0x0;
                          uStack_5d0 = 0x1028f3;
                          (*_DAT_)(1,0x17991f8,0x18b8ec8,0x81d);
                        }
                      }
                    }
                    uStack_5d0 = 0x102901;
                    func_0x(*(undefined8 *)(psVar17 + 4),4);
                    uVar23 = (ulonglong)(ushort)psVar17[0xe];
                  }
                  if ((short)puVar35[(ulonglong)((int)uVar23 - 1) + 1] < 0) {
                    do {
                      lVar14 = (ulonglong)*(uint *)(psVar17 + 10) + *(longlong *)(psVar17 + 4);
                      if ((int)uVar23 == 1) {
                        uVar33 = *(uint *)(psVar17 + 0xc);
                        uVar29 = uVar33;
LAB_:
                        if ((*(ushort *)(lVar14 + uVar23 * 2) & 0x7fff) < uVar33) goto LAB_;
                      }
                      else {
                        uVar29 = *(uint *)(psVar17 + 0xc);
                        uVar33 = *(ushort *)(lVar14 + -2 + uVar23 * 2) & 0x7fff;
                        if (uVar29 <= uVar33) goto LAB_;
LAB_:
                        uStack_5d0 = 0x102964;
                        func_0x(*(longlong *)(psVar17 + 4),7);
                        uVar29 = *(uint *)(psVar17 + 0xc);
                      }
                      if ((uVar33 < uVar29) || (*(uint *)(psVar17 + 2) < uVar33)) goto LAB_;
                      if (*(ushort *)((ulonglong)uVar33 + *(longlong *)(psVar17 + 4)) == 5) {
                        psVar17[1] = psVar17[1] | 2;
                        psVar17[0xe] = psVar17[0xe] + -1;
                        psVar17[0x15] = (short)uVar33;
                        lVar14 = (ulonglong)(uVar33 & 0xffff) + *(longlong *)(psVar17 + 4);
                        uVar8 = psVar17[0x16] & 0xc7ff;
                        uVar9 = *(ushort *)(lVar14 + 2);
                        if ((uVar9 >> 0xe & 1) != 0) {
                          uVar8 = uVar9 & 0x3800 | uVar8;
                        }
                        psVar17[0x16] = uVar8;
                        psVar17[0x16] = (uVar8 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar8;
                        goto LAB_;
                      }
                      if (*(ushort *)((ulonglong)uVar33 + *(longlong *)(psVar17 + 4)) < 0x400)
                      goto LAB_;
                      psVar17[1] = psVar17[1] | 1;
                      uVar9 = psVar17[0xe] - 1;
                      psVar17[0xe] = uVar9;
                      if (uVar9 == 0) goto LAB_;
                      uVar23 = (ulonglong)uVar9;
                    } while ((short)puVar35[(ulonglong)(uVar9 - 1) + 1] < 0);
                    pbVar31 = *(byte **)(psVar17 + 4);
                  }
                  else {
LAB_:
                    pbVar31 = *(byte **)(psVar17 + 4);
                  }
                }
                if ((*pbVar31 & 0x40) == 0) {
                  *(undefined4 *)(psVar17 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar17 + 0x13) = *(int *)(psVar17 + 2);
                  *(int *)(psVar17 + 2) = *(int *)(psVar17 + 2) + 0xe;
                  uStack_5d0 = 0x102a4b;
                  uVar16 = func_0x(psVar17 + 1);
                  uStack_5d0 = 0x102a5a;
                  func_0x(uVar16,auStack_308);
                  uStack_5d0 = 0x102a66;
                  iVar10 = func_0x(auStack_308);
                  *(int *)(psVar17 + 2) = *(int *)(psVar17 + 2) + iVar10;
                }
                uVar33 = *(uint *)(psVar17 + 2);
                if ((*(ulonglong *)(psVar17 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar17 + 0xf) < (ulonglong)uVar33 + *(longlong *)(psVar17 + 4)))
                {
                  uStack_5d0 = 0x102a96;
                  cVar6 = func_0x(0x1ea8470);
                  if (cVar6 != '\0') {
                    uStack_5d0 = 0x102a9f;
                    lVar14 = func_0x();
                    if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                      uStack_5d0 = 0x102ab9;
                      cVar6 = func_0x(0x1ea8470);
                      if (cVar6 == '\0') {
                        uStack_5d0 = 0x102ad5;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        uStack_5a8 = (longlong *)0x0;
                        uStack_5d0 = 0x102af8;
                        (*_DAT_)(1,0x17991f8,0x18b8ec8,0x877);
                      }
                    }
                  }
                  uStack_5d0 = 0x102b06;
                  func_0x(*(undefined8 *)(psVar17 + 4),0x12);
                  uVar33 = *(uint *)(psVar17 + 2);
                }
                if (0x3f3b < uVar33 - 1) {
                  uStack_5d0 = 0x102b1f;
                  cVar6 = func_0x(0x1ea8470);
                  if (cVar6 != '\0') {
                    uStack_5d0 = 0x102b28;
                    lVar14 = func_0x();
                    if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                      uStack_5d0 = 0x102b42;
                      cVar6 = func_0x(0x1ea8470);
                      if (cVar6 == '\0') {
                        uStack_5d0 = 0x102b5e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        uStack_5a8 = (longlong *)0x0;
                        uStack_5d0 = 0x102b81;
                        (*_DAT_)(1,0x17991f8,0x18b8ec8,0x87c);
                      }
                    }
                  }
                  uStack_5d0 = 0x102b8f;
                  func_0x(*(undefined8 *)(psVar17 + 4),5);
                }
              }
LAB_:
              sVar28 = -*(short *)plVar24;
              if ((*(byte *)((longlong)plVar24 + 6) & 0x10) != 0) {
                uStack_5a8 = (longlong *)&iStack_3e4;
                uStack_5d0 = 0x102bbf;
                func_0x(psVar17 + 1,plVar24,0,auStack_344);
                if (iStack_3e4 == 0) {
                  puVar30 = (uint *)plVar24[1] + 1;
                  pplVar25 = pplStack_560;
                  uVar33 = *(uint *)plVar24[1];
                  goto LAB_;
                }
              }
              lVar14 = (longlong)sVar28;
              if ((uint)(ushort)psVar17[0xe] < (uint)(int)sVar28) {
                uStack_550 = 0;
                puVar30 = *(uint **)(psVar17 + 4);
                pplVar25 = pplStack_560;
                uVar33 = uStack_550;
              }
              else {
                lVar26 = *(longlong *)(psVar17 + 4);
                lVar18 = (ulonglong)*(uint *)(psVar17 + 10) + lVar26;
                if (sVar28 == 1) {
                  uVar33 = *(uint *)(psVar17 + 0xc);
                  uVar29 = *(ushort *)(lVar18 + lVar14 * 2) & 0x7fff;
LAB_:
                  if (uVar29 < uVar33) goto LAB_;
                }
                else {
                  uVar33 = *(ushort *)(lVar18 + -2 + lVar14 * 2) & 0x7fff;
                  lVar26 = *(longlong *)(psVar17 + 4);
                  uVar29 = *(ushort *)(lVar18 + lVar14 * 2) & 0x7fff;
                  if (*(uint *)(psVar17 + 0xc) <= uVar33) goto LAB_;
LAB_:
                  uStack_5d0 = 0x102c3e;
                  func_0x(lVar26,7);
                }
                puVar30 = (uint *)((ulonglong)uVar33 + *(longlong *)(psVar17 + 4));
                pplVar25 = pplStack_560;
                uVar33 = uVar29 - uVar33;
              }
            }
            else if ((*(ushort *)((longlong)plVar24 + 6) & 8) == 0) {
              if ((*(ushort *)((longlong)plVar24 + 6) & 0x10) != 0) {
                uStack_5a8 = (longlong *)&iStack_3e8;
                uStack_5d0 = 0x10266c;
                func_0x(psVar17 + 1,plVar24,0,auStack_328);
                if (iStack_3e8 == 0) {
                  uVar33 = *(uint *)plVar24[1];
                  puVar30 = (uint *)plVar24[1] + 1;
                  pplVar25 = pplStack_560;
                  if ((uVar9 != 0) && (uVar33 != uVar9)) {
                    uStack_5a8 = (longlong *)0x0;
                    uStack_5d0 = 0x1026ad;
                    (*_DAT_)(1,0x1946f68,0x1945968,0x381);
                    pplVar25 = pplStack_560;
                  }
                  goto LAB_;
                }
              }
              puVar30 = (uint *)((longlong)(int)*(uint *)plVar24 + *(longlong *)(psVar17 + 4));
              pplVar25 = pplStack_560;
              uVar33 = (uint)uVar9;
            }
            else {
              uStack_5d0 = 0x1026de;
              puVar30 = (uint *)func_0x(psVar17 + 1,plVar24);
              pplVar25 = pplStack_560;
              uVar33 = uStack_550;
            }
LAB_:
            uStack_550 = uVar33;
            uVar9 = *(ushort *)(plVar24[9] + 0x2a);
            if (puVar30 == (uint *)0x0) goto LAB_;
            if ((uVar9 & 0x10) == 0) goto LAB_;
            plVar19 = pplVar25[4];
            goto LAB_;
          }
          uStack_5a8 = (longlong *)0x15156d8;
          uStack_5d0 = 0x10257b;
          (*_DAT_)(1,0x191a530,0x1946e70,0x27d);
          goto LAB_;
        }
        if (*(int *)(psVar17 + 2) == 0) {
          psVar17[1] = 0;
          uVar33 = *(uint *)(psVar17 + 8);
          uVar23 = (ulonglong)uVar33;
          *(uint *)(psVar17 + 10) = uVar33;
          pbVar31 = *(byte **)(psVar17 + 4);
          bVar7 = *pbVar31;
          pbVar21 = pbVar31;
          if ((bVar7 & 0x10) != 0) {
            uVar33 = uVar33 + (*(ushort *)(pbVar31 + uVar23) + 7 >> 3) + 2;
            uVar23 = (ulonglong)uVar33;
            *(uint *)(psVar17 + 10) = uVar33;
            bVar7 = *pbVar31;
            pbVar21 = *(byte **)(psVar17 + 4);
          }
          if ((bVar7 & 0x20) == 0) {
            *(int *)(psVar17 + 2) = (int)uVar23;
            psVar17[0xe] = 0;
            *(uint *)(psVar17 + 0xc) = uVar33;
          }
          else {
            puVar35 = (ushort *)(pbVar31 + uVar23);
            uVar9 = *puVar35;
            psVar17[0xe] = uVar9;
            if (uVar9 == 0) {
              uStack_5d0 = 0x102dae;
              cVar6 = func_0x(0x1ea8470);
              if (cVar6 != '\0') {
                uStack_5d0 = 0x102db7;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  uStack_5d0 = 0x102dd1;
                  cVar6 = func_0x(0x1ea8470);
                  if (cVar6 == '\0') {
                    uStack_5d0 = 0x102ded;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_5a8 = (longlong *)0x0;
                    uStack_5d0 = 0x102e10;
                    (*_DAT_)(1,0x17991f8,0x18b8ec8,0x80f);
                  }
                }
              }
              uStack_5d0 = 0x102e1e;
              func_0x(*(undefined8 *)(psVar17 + 4),3);
              uVar9 = psVar17[0xe];
              uVar33 = *(uint *)(psVar17 + 10);
            }
            uVar33 = uVar33 + (uVar9 + 1) * 2;
            *(uint *)(psVar17 + 0xc) = uVar33;
            if (0x1f9e < uVar33) {
              uStack_5d0 = 0x102e4e;
              cVar6 = func_0x(0x1ea8470);
              if (cVar6 != '\0') {
                uStack_5d0 = 0x102e57;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  uStack_5d0 = 0x102e71;
                  cVar6 = func_0x(0x1ea8470);
                  if (cVar6 == '\0') {
                    uStack_5d0 = 0x102e8d;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_5a8 = (longlong *)0x0;
                    uStack_5d0 = 0x102eb0;
                    (*_DAT_)(1,0x17991f8,0x18b8ec8,0x816);
                  }
                }
              }
              uStack_5d0 = 0x102ebe;
              func_0x(*(undefined8 *)(psVar17 + 4),4);
              uVar9 = psVar17[0xe];
              uVar33 = *(uint *)(psVar17 + 0xc);
            }
            uVar23 = (ulonglong)uVar9;
            uVar9 = puVar35[uVar23];
            *(uint *)(psVar17 + 2) = uVar9 & 0x7fff;
            if ((uVar9 & 0x7fff) < uVar33) {
              uStack_5d0 = 0x102eec;
              cVar6 = func_0x(0x1ea8470);
              if (cVar6 != '\0') {
                uStack_5d0 = 0x102ef5;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  uStack_5d0 = 0x102f0f;
                  cVar6 = func_0x(0x1ea8470);
                  if (cVar6 == '\0') {
                    uStack_5d0 = 0x102f2b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_5a8 = (longlong *)0x0;
                    uStack_5d0 = 0x102f4e;
                    (*_DAT_)(1,0x17991f8,0x18b8ec8,0x81d);
                  }
                }
              }
              uStack_5d0 = 0x102f5c;
              func_0x(*(undefined8 *)(psVar17 + 4),4);
              uVar23 = (ulonglong)(ushort)psVar17[0xe];
            }
            if ((short)puVar35[(ulonglong)((int)uVar23 - 1) + 1] < 0) {
              do {
                lVar14 = *(longlong *)(psVar17 + 4);
                if ((int)uVar23 == 1) {
                  uVar33 = *(uint *)(psVar17 + 0xc);
                  uVar29 = uVar33;
LAB_:
                  if ((*(ushort *)((ulonglong)*(uint *)(psVar17 + 10) + lVar14 + uVar23 * 2) &
                      0x7fff) < uVar33) goto LAB_;
                }
                else {
                  uVar29 = *(uint *)(psVar17 + 0xc);
                  uVar33 = *(ushort *)
                            ((ulonglong)*(uint *)(psVar17 + 10) + lVar14 + -2 + uVar23 * 2) & 0x7fff
                  ;
                  if (uVar29 <= uVar33) goto LAB_;
LAB_:
                  uStack_5d0 = 0x102fc4;
                  func_0x(lVar14,7);
                  uVar29 = *(uint *)(psVar17 + 0xc);
                  lVar14 = *(longlong *)(psVar17 + 4);
                }
                if ((uVar33 < uVar29) || (*(uint *)(psVar17 + 2) < uVar33)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar33 + lVar14) == 5) {
                  psVar17[1] = psVar17[1] | 2;
                  psVar17[0xe] = psVar17[0xe] + -1;
                  psVar17[0x15] = (short)uVar33;
                  lVar14 = (ulonglong)(uVar33 & 0xffff) + *(longlong *)(psVar17 + 4);
                  uVar8 = psVar17[0x16] & 0xc7ff;
                  uVar9 = *(ushort *)(lVar14 + 2);
                  if ((uVar9 >> 0xe & 1) != 0) {
                    uVar8 = uVar9 & 0x3800 | uVar8;
                  }
                  psVar17[0x16] = uVar8;
                  psVar17[0x16] = (uVar8 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar8;
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar33 + lVar14) < 0x400) goto LAB_;
                psVar17[1] = psVar17[1] | 1;
                uVar9 = psVar17[0xe] - 1;
                psVar17[0xe] = uVar9;
                if (uVar9 == 0) goto LAB_;
                uVar23 = (ulonglong)uVar9;
              } while ((short)puVar35[(ulonglong)(uVar9 - 1) + 1] < 0);
              pbVar21 = *(byte **)(psVar17 + 4);
            }
            else {
LAB_:
              pbVar21 = *(byte **)(psVar17 + 4);
            }
          }
          if ((*pbVar21 & 0x40) == 0) {
            *(undefined4 *)(psVar17 + 0x13) = 0;
          }
          else {
            *(int *)(psVar17 + 0x13) = *(int *)(psVar17 + 2);
            *(int *)(psVar17 + 2) = *(int *)(psVar17 + 2) + 0xe;
            uStack_5d0 = 0x1030ac;
            uVar16 = func_0x(psVar17 + 1);
            uStack_5d0 = 0x1030bb;
            func_0x(uVar16,auStack_300);
            uStack_5d0 = 0x1030c7;
            iVar10 = func_0x(auStack_300);
            *(int *)(psVar17 + 2) = *(int *)(psVar17 + 2) + iVar10;
            pbVar21 = *(byte **)(psVar17 + 4);
          }
          uVar33 = *(uint *)(psVar17 + 2);
          if ((*(byte **)(psVar17 + 0xf) != (byte *)0x0) &&
             (*(byte **)(psVar17 + 0xf) < pbVar21 + uVar33)) {
            uStack_5d0 = 0x1030f9;
            cVar6 = func_0x(0x1ea8470);
            if (cVar6 != '\0') {
              uStack_5d0 = 0x103102;
              lVar14 = func_0x();
              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                uStack_5d0 = 0x10311c;
                cVar6 = func_0x(0x1ea8470);
                if (cVar6 == '\0') {
                  uStack_5d0 = 0x103138;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  uStack_5a8 = (longlong *)0x0;
                  uStack_5d0 = 0x10315b;
                  (*_DAT_)(1,0x17991f8,0x18b8ec8,0x877);
                }
              }
            }
            uStack_5d0 = 0x103169;
            func_0x(*(undefined8 *)(psVar17 + 4),0x12);
            uVar33 = *(uint *)(psVar17 + 2);
          }
          if (0x3f3b < uVar33 - 1) {
            uStack_5d0 = 0x103182;
            cVar6 = func_0x(0x1ea8470);
            if (cVar6 != '\0') {
              uStack_5d0 = 0x10318b;
              lVar14 = func_0x();
              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                uStack_5d0 = 0x1031a5;
                cVar6 = func_0x(0x1ea8470);
                if (cVar6 == '\0') {
                  uStack_5d0 = 0x1031c1;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  uStack_5a8 = (longlong *)0x0;
                  uStack_5d0 = 0x1031e4;
                  (*_DAT_)(1,0x17991f8,0x18b8ec8,0x87c);
                }
              }
            }
            uStack_5d0 = 0x1031f2;
            func_0x(*(undefined8 *)(psVar17 + 4),5);
          }
        }
LAB_:
        sVar28 = -*(short *)plVar24;
        if ((*(byte *)((longlong)plVar24 + 6) & 0x10) == 0) {
LAB_:
          lVar14 = (longlong)sVar28;
          if ((uint)(ushort)psVar17[0xe] < (uint)(int)sVar28) {
            uStack_550 = 0;
            puVar30 = *(uint **)(psVar17 + 4);
          }
          else {
            lVar26 = *(longlong *)(psVar17 + 4);
            lVar18 = (ulonglong)*(uint *)(psVar17 + 10) + lVar26;
            if (sVar28 == 1) {
              uVar23 = (ulonglong)*(uint *)(psVar17 + 0xc);
              uVar29 = *(ushort *)(lVar18 + lVar14 * 2) & 0x7fff;
LAB_:
              if (uVar29 < (uint)uVar23) goto LAB_;
            }
            else {
              uVar33 = *(ushort *)(lVar18 + -2 + lVar14 * 2) & 0x7fff;
              uVar23 = (ulonglong)uVar33;
              lVar26 = *(longlong *)(psVar17 + 4);
              uVar29 = *(ushort *)(lVar18 + lVar14 * 2) & 0x7fff;
              if (*(uint *)(psVar17 + 0xc) <= uVar33) goto LAB_;
LAB_:
              uStack_5d0 = 0x10329c;
              func_0x(lVar26,7);
            }
            uStack_550 = uVar29 - (int)uVar23;
            puVar30 = (uint *)(uVar23 + *(longlong *)(psVar17 + 4));
          }
        }
        else {
          uStack_5a8 = (longlong *)&iStack_3b8;
          uStack_5d0 = 0x103222;
          func_0x(psVar17 + 1,plVar24,0,(longlong)&uStack_354 + 4);
          if (iStack_3b8 != 0) goto LAB_;
          uStack_550 = *(uint *)plVar24[1];
          puVar30 = (uint *)plVar24[1] + 1;
        }
        pplVar25 = pplStack_560;
        if (((*(uint *)(plVar24 + 8) & 0x2000) != 0) && (uStack_550 == 0)) {
          uStack_550 = 4;
          puVar30 = (uint *)0x153f59c;
        }
        if ((*(byte *)(plVar24[9] + 0x2a) & 0x10) == 0) {
          plVar19 = pplStack_560[3];
        }
        else {
          plVar19 = pplStack_560[4];
        }
        *(undefined *)((longlong)plVar19 + plVar24[6]) = 0;
        if ((1 << (**(byte **)(psVar17 + 4) & 0xe) & 0x440U) != 0) {
          uStack_5d0 = 0x10330f;
          iVar10 = func_0x(plVar24);
          if (iVar10 != 0) goto LAB_;
        }
        if (*(ushort *)((longlong)plVar24 + 0x3c) < uStack_550) {
          uStack_5d0 = 0x10333b;
          (*_DAT_)(6,0x52,0x16,0x91);
        }
      }
LAB_:
      uVar23 = (ulonglong)uStack_550;
      lVar14 = plVar24[9];
      if ((*(uint *)(plVar24 + 8) & 0x800) == 0) {
        if ((*(byte *)(lVar14 + 0x2a) & 0x10) == 0) {
          plVar19 = pplVar25[3];
        }
        else {
          plVar19 = pplVar25[4];
        }
        uStack_5d0 = 0x10349f;
        func_0x((longlong)plVar19 + plVar24[5],puVar30);
      }
      else {
        uVar9 = *(ushort *)(lVar14 + 0x2a) & 0x10;
        if (*(int *)(lVar14 + 0x10) == 10) {
          if (uVar9 == 0) {
            plVar19 = pplVar25[3];
          }
          else {
            plVar19 = pplVar25[4];
          }
          *(uint **)((longlong)plVar19 + plVar24[5]) = puVar30;
        }
        else {
          if (uVar9 == 0) {
            plVar19 = pplVar25[3];
          }
          else {
            plVar19 = pplVar25[4];
          }
          uStack_5d0 = 0x1034d4;
          func_0x(*(undefined8 *)(plVar24[5] + (longlong)plVar19),puVar30);
        }
      }
      pplVar25 = pplStack_560;
      if ((*(uint *)(plVar24 + 8) & 0x100) != 0) {
        if ((*(byte *)(plVar24[9] + 0x2a) & 0x10) == 0) {
          plVar19 = pplStack_560[3];
        }
        else {
          plVar19 = pplStack_560[4];
        }
        *(ulonglong *)((longlong)plVar19 + *(longlong *)(plVar24[9] + 0x18)) = uVar23;
      }
    }
LAB_:
    uVar33 = (int)puVar34 + 1;
    plVar24 = plVar24 + 10;
    puVar27 = auStack_5c8;
    puVar34 = (uint *)(ulonglong)uVar33;
  } while (uVar33 < uStack_500);
LAB_:
  pplVar25 = pplStack_4e8;
  UNRECOVERED_JUMPTABLE = (code *)(*pplStack_4e8)[1];
  *(undefined8 *)(puVar27 + -8) = 0x103555;
  (*UNRECOVERED_JUMPTABLE)(pplVar25);
LAB_:
  *puStack_3b0 = *(undefined8 *)(lStack_4f8 + 0xa28);
  uVar23 = uStack_50 ^ (ulonglong)&uStack_588;
  *(undefined8 *)(puVar27 + -8) = 0x1083c6;
  func_0x(uVar23);
  return;
}

