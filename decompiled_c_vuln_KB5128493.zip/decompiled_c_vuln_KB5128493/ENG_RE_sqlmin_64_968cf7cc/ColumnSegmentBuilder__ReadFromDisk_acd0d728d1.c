
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,longlong *param_3,char *param_4,
                 undefined2 *param_5,longlong *param_6,int *param_7,longlong *param_8,int *param_9,
                 longlong *param_10,int *param_11)

{
  ushort uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uStackX_8;
  
  uStackX_8 = param_1;
  (**(code **)(*param_3 + 8))(param_3,param_4,0x22,&uStackX_8);
  if ((int)uStackX_8 != 0x22) {
    (*_DAT_)(1,0x13b8430,0x1380a88,0x163,0);
  }
  if (*param_4 != '\x01') {
    (*_DAT_)(1,0x13b8130,0x1380a88,0x166,0);
  }
  if (param_4[4] != '\x01') {
    (*_DAT_)(1,0x13b8460,0x1380a88,0x167,0);
  }
  if (*(int *)(param_4 + 0x10) != 3) {
    if (*(int *)(param_4 + 0x10) == 7) goto LAB_;
    (*_DAT_)(1,0x13b8490,0x1380a88,0x16d,0);
    if (*(int *)(param_4 + 0x10) != 3) goto LAB_;
  }
  (**(code **)(*param_3 + 8))(param_3,param_5,0xe,&uStackX_8);
  if ((int)uStackX_8 != 0xe) {
    (*_DAT_)(1,0x13b83a8,0x1380a88,0x178,0);
  }
LAB_:
  iVar2 = *(int *)(param_4 + 0x14);
  *param_7 = iVar2 << 3;
  lVar3 = (*_DAT_)(iVar2 << 3,param_2,0x123c968,0x17f,5);
  if (*param_6 != lVar3) {
    (*_DAT_)(*param_6,0);
  }
  *param_6 = lVar3;
  (**(code **)(*param_3 + 8))(param_3,lVar3,*param_7,&uStackX_8);
  if ((int)uStackX_8 != *param_7) {
    (*_DAT_)(1,0x13b83d0,0x1380a88,0x187,0);
  }
  uVar1 = *(ushort *)(param_4 + 0x20);
  iVar2 = *(int *)(param_4 + 0x1c);
  *param_9 = (uint)uVar1 * iVar2;
  lVar3 = (*_DAT_)((uint)uVar1 * iVar2,param_2,0x123c968,0x18d,5);
  if (*param_8 != lVar3) {
    (*_DAT_)(*param_8,0);
  }
  *param_8 = lVar3;
  (**(code **)(*param_3 + 8))(param_3,lVar3,*param_9,&uStackX_8);
  if ((int)uStackX_8 != *param_9) {
    (*_DAT_)(1,0x13b83f0,0x1380a88,0x194,0);
  }
  if (*(int *)(param_4 + 0x10) == 7) {
    if (*param_10 != 0) {
      (*_DAT_)(*param_10,0);
    }
    *param_10 = 0;
    *param_11 = 0;
    *param_5 = 0;
    *(undefined8 *)(param_5 + 3) = 0;
    *(undefined4 *)(param_5 + 1) = 0;
  }
  else {
    iVar2 = *(int *)(param_5 + 1);
    *param_11 = iVar2 << 3;
    lVar3 = (*_DAT_)(iVar2 << 3,param_2,0x123c968,0x1a4,5);
    if (*param_10 != lVar3) {
      (*_DAT_)(*param_10,0);
    }
    *param_10 = lVar3;
    (**(code **)(*param_3 + 8))(param_3,lVar3,*param_11,&uStackX_8);
    if ((int)uStackX_8 != *param_11) {
      (*_DAT_)(1,0x13b8410,0x1380a88,0x1ab,0);
    }
  }
  return;
}

