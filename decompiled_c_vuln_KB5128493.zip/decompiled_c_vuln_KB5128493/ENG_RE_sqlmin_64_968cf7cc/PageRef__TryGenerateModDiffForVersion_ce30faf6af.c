
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(uint *param_1,undefined8 param_2,longlong param_3,longlong param_4,short *param_5,
                 short *param_6)

{
  uint *puVar1;
  byte **ppbVar2;
  uint *puVar3;
  longlong lVar4;
  byte bVar5;
  undefined6 uVar6;
  undefined8 uVar7;
  char cVar8;
  byte bVar9;
  ushort uVar10;
  ulonglong *puVar11;
  undefined8 *puVar12;
  uint uVar13;
  int iVar14;
  ulonglong uVar15;
  ushort uVar16;
  uint uVar17;
  longlong lVar18;
  byte *pbVar19;
  ulonglong uVar20;
  ushort *puVar21;
  ushort *puVar22;
  longlong lVar23;
  uint uVar24;
  ushort *puVar25;
  longlong lVar26;
  ushort *puVar27;
  short *psVar28;
  short *psVar29;
  uint *puVar30;
  longlong unaff_GS_OFFSET;
  undefined8 auStack_360 [5];
  undefined8 uStack_338;
  undefined8 uStack_330;
  ushort *puStack_328;
  int iStack_320;
  int iStack_31c;
  int iStack_318;
  int iStack_314;
  uint uStack_310;
  char cStack_30c;
  undefined8 uStack_308;
  undefined8 uStack_2f8;
  undefined auStack_2f0 [8];
  undefined8 uStack_2e8;
  short *psStack_2e0;
  uint uStack_2d8;
  uint uStack_2d4;
  short *psStack_2d0;
  undefined auStack_2c8 [8];
  uint auStack_2c0 [2];
  longlong lStack_2b8;
  uint uStack_2b0;
  uint uStack_2ac;
  longlong lStack_2a8;
  uint *puStack_2a0;
  undefined8 uStack_298;
  longlong lStack_290;
  uint *puStack_288;
  undefined8 uStack_280;
  ulonglong uStack_278;
  ulonglong uStack_270;
  undefined8 uStack_268;
  undefined8 uStack_260;
  undefined auStack_240 [40];
  undefined8 uStack_218;
  undefined4 uStack_210;
  undefined2 uStack_20c;
  undefined8 uStack_138;
  undefined4 uStack_130;
  undefined2 uStack_12c;
  ulonglong uStack_58;
  
  uStack_280 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)&puStack_328;
  psStack_2e0 = param_5;
  psStack_2d0 = param_6;
  uStack_218 = 0;
  uStack_210 = 0;
  uStack_20c = 0;
  puStack_328 = (ushort *)0x0;
  uStack_138 = 0;
  uStack_130 = 0;
  uStack_12c = 0;
  if (*param_6 == 0) {
    bVar9 = **(byte **)(param_6 + 4) >> 6;
  }
  else {
    bVar9 = **(byte **)(param_6 + 4) >> 1;
  }
  cStack_30c = '\0';
  uStack_330 = 0;
  uStack_338 = _DAT_;
  auStack_360[0] = 0x1000ee;
  uStack_2d4 = bVar9 & 1;
  lStack_2a8 = param_4;
  puStack_2a0 = param_1;
  uStack_298 = param_2;
  lStack_290 = param_3;
  puStack_288 = param_1;
  func_0x(auStack_240,0,0);
  auStack_360[0] = 0x1000fd;
  func_0x(auStack_2c0,1);
  if (*param_5 == 0) {
    bVar5 = **(byte **)(param_5 + 4) >> 6;
  }
  else {
    bVar5 = **(byte **)(param_5 + 4) >> 1;
  }
  if ((bVar5 & 1) != 0) {
    if (*param_5 == 0) {
      auStack_360[0] = 0x100132;
      func_0x();
    }
    else {
      auStack_360[0] = 0x100139;
      func_0x(param_5 + 1,&uStack_308);
    }
    uVar17 = (uint)uStack_308;
    uVar16 = uStack_308._4_2_;
    uStack_2e8._0_6_ = SUB86(uStack_308,0);
    uVar6 = (undefined6)uStack_2e8;
    uStack_308 = (ushort *)((ulonglong)uStack_308 & 0xffff000000000000);
    auStack_360[0] = 0x100161;
    func_0x(param_3 + 0x19c8,&uStack_308);
    puStack_328 = (ushort *)((ulonglong)puStack_328 & 0xffff000000000000);
    if ((uVar16 == 0) && (uVar17 == 0)) {
LAB_:
      cStack_30c = '\x01';
      if (*param_5 == 0) {
        auStack_360[0] = 0x1001d2;
        func_0x();
      }
      else {
        auStack_360[0] = 0x1001d9;
        func_0x(param_5 + 1,&puStack_328);
      }
      if (*param_5 == 0) {
        auStack_360[0] = 0x1001f0;
        func_0x();
      }
      else {
        auStack_360[0] = 0x1001f7;
        func_0x(param_5 + 1,&uStack_138);
      }
    }
    else {
      uStack_2f8 = (ushort *)CONCAT26(uStack_2f8._6_2_,uVar6);
      if (*param_5 == 0) {
        auStack_360[0] = 0x10018d;
        func_0x();
      }
      else {
        auStack_360[0] = 0x100194;
        func_0x(param_5 + 1,auStack_2c8);
      }
      auStack_360[0] = 0x1001a9;
      cVar8 = func_0x(*(undefined8 *)(param_3 + 0x6b0),&uStack_2f8,auStack_2c8);
      if (cVar8 == '\0') {
        if ((uVar16 < uStack_308._4_2_) ||
           ((uStack_308._4_2_ == uVar16 && (uVar17 < (uint)uStack_308)))) goto LAB_;
      }
    }
  }
  if ((char)(bVar9 & 1) != '\0') {
    if (*param_6 == 0) {
      auStack_360[0] = 0x100216;
      func_0x();
    }
    else {
      auStack_360[0] = 0x10021d;
      func_0x(param_6 + 1,&uStack_218);
    }
  }
  puVar22 = (ushort *)(param_5 + 1);
  uStack_2e8 = puVar22;
  if (*param_5 == 0) {
    puVar1 = (uint *)(param_5 + 2);
    puStack_328 = puVar22;
    if (*puVar1 == 0) {
      iStack_320 = 0;
      *puVar22 = 0;
      uVar17 = *(uint *)(param_5 + 8);
      uVar15 = (ulonglong)uVar17;
      puVar30 = (uint *)(param_5 + 10);
      *puVar30 = uVar17;
      ppbVar2 = (byte **)(param_5 + 4);
      pbVar19 = *ppbVar2;
      bVar9 = *pbVar19;
      if ((bVar9 & 0x10) != 0) {
        uVar17 = uVar17 + 2 + (*(ushort *)(pbVar19 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar17;
        *puVar30 = uVar17;
        bVar9 = *pbVar19;
      }
      puVar21 = (ushort *)(param_5 + 0xe);
      if ((bVar9 & 0x20) == 0) {
        *puVar1 = (uint)uVar15;
        *puVar21 = 0;
        *(uint *)(param_5 + 0xc) = uVar17;
      }
      else {
        uStack_2f8 = (ushort *)(pbVar19 + uVar15);
        uVar16 = *uStack_2f8;
        *puVar21 = uVar16;
        if (uVar16 == 0) {
          iStack_320 = 1;
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x100327;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x100351;
              (*_DAT_)(1,0x1301658,0x1421328,0x80f);
            }
          }
          puVar22 = puStack_328;
          auStack_360[0] = 0x100362;
          func_0x(*ppbVar2,3);
          uVar17 = *puVar30;
        }
        uVar16 = *puVar21;
        uVar17 = uVar17 + (uVar16 + 1) * 2;
        puVar3 = (uint *)(puVar22 + 0xb);
        *puVar3 = uVar17;
        if (0x1f9e < uVar17) {
          iStack_320 = iStack_320 + 1;
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), puVar22 = puStack_328, lVar18 != 0 &&
              ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
               (*(char *)(lVar18 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x100402;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
              puVar22 = puStack_328;
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x10042c;
              (*_DAT_)(1,0x1301658,0x1421328,0x816);
              puVar22 = puStack_328;
            }
          }
          auStack_360[0] = 0x10043d;
          func_0x(*ppbVar2,4);
          uVar16 = *puVar21;
          uVar17 = *puVar3;
        }
        uVar15 = (ulonglong)uVar16;
        uVar16 = uStack_2f8[uVar15];
        *puVar1 = uVar16 & 0x7fff;
        puVar25 = uStack_2e8;
        if ((uVar16 & 0x7fff) < uVar17) {
          iStack_320 = iStack_320 + 1;
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), puVar22 = puStack_328, lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x1004e0;
              (*_DAT_)(0x22,0x44,0x15);
              puVar22 = puStack_328;
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x10050a;
              (*_DAT_)(1,0x1301658,0x1421328);
              puVar22 = puStack_328;
            }
          }
          auStack_360[0] = 0x10051b;
          func_0x(*ppbVar2,4);
          uVar15 = (ulonglong)*puVar21;
          puVar25 = uStack_2e8;
        }
        while ((short)uStack_2f8[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          pbVar19 = *ppbVar2;
          uVar17 = *puVar30;
          if ((int)uVar15 == 1) {
            uVar24 = *(uint *)(puVar25 + 0xb);
            uVar16 = *(ushort *)(pbVar19 + uVar15 * 2 + (ulonglong)uVar17);
            uVar13 = uVar24;
LAB_:
            if ((uVar16 & 0x7fff) < uVar24) goto LAB_;
          }
          else {
            uVar24 = *(ushort *)(pbVar19 + uVar15 * 2 + ((ulonglong)uVar17 - 2)) & 0x7fff;
            uVar13 = *(uint *)(puVar25 + 0xb);
            uVar16 = *(ushort *)(pbVar19 + uVar15 * 2 + (ulonglong)uVar17);
            if (uVar13 <= uVar24) goto LAB_;
LAB_:
            auStack_360[0] = 0x100593;
            func_0x(pbVar19,7);
            uVar13 = *(uint *)(uStack_2e8 + 0xb);
            puVar25 = uStack_2e8;
          }
          if ((uVar24 < uVar13) || (*puVar1 < uVar24)) {
            iStack_320 = iStack_320 + 1;
            goto LAB_;
          }
          uStack_2d8 = uVar24;
          if (*(ushort *)(*ppbVar2 + uVar24) == 5) {
            *puVar22 = *puVar22 | 2;
            *puVar21 = *puVar21 - 1;
            puVar22[0x14] = (ushort)uVar24;
            lVar18 = (ulonglong)(uVar24 & 0xffff) + *(longlong *)(puVar22 + 3);
            uVar16 = *(ushort *)(lVar18 + 2);
            uVar10 = puVar22[0x15] & 0xc7ff;
            if ((uVar16 & 0x4000) == 0) {
              puVar22[0x15] = uVar10;
            }
            else {
              uVar10 = uVar16 & 0x3800 | uVar10;
              puVar22[0x15] = uVar10;
            }
            puVar22[0x15] = (uVar10 ^ *(ushort *)(lVar18 + 2)) & 0x7ff ^ uVar10;
            pbVar19 = *ppbVar2;
            uVar15 = (ulonglong)*puVar1;
            goto LAB_;
          }
          if (*(ushort *)(*ppbVar2 + uVar24) < 0x400) break;
          *puVar22 = *puVar22 | 1;
          uVar16 = *puVar21 - 1;
          *puVar21 = uVar16;
          if (uVar16 == 0) break;
          uVar15 = (ulonglong)uVar16;
        }
        pbVar19 = *ppbVar2;
        uVar15 = (ulonglong)*puVar1;
      }
LAB_:
      puVar21 = uStack_2e8;
      if ((*pbVar19 & 0x40) == 0) {
        *(undefined4 *)(param_5 + 0x13) = 0;
      }
      else {
        *(uint *)(param_5 + 0x13) = *puVar1;
        *puVar1 = *puVar1 + 0xe;
        auStack_360[0] = 0x1006aa;
        puVar11 = (ulonglong *)func_0x(puVar22);
        uStack_278 = *puVar11;
        uVar17 = 0;
        uVar16 = (ushort)(uStack_278 >> 0x30);
        if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
          if ((uStack_278 & 0x4000000000000000) == 0) {
            uVar16 = uVar16 & 0xdfff;
          }
          else {
            uVar16 = uVar16 | 0x2000;
          }
        }
        if (uVar16 == 0xfffc) {
          uVar17 = ((uint)(uStack_278 >> 0x20) & 0xffff) >> 5;
        }
        *puVar1 = *puVar1 + uVar17;
        uVar15 = (ulonglong)*puVar1;
      }
      iVar14 = (int)uVar15;
      if ((*(byte **)(puVar22 + 0xe) != (byte *)0x0) &&
         (*(byte **)(puVar22 + 0xe) < *ppbVar2 + uVar15)) {
        iStack_320 = iStack_320 + 1;
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar18 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), puVar22 = puStack_328, lVar18 != 0 &&
             (lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0)) &&
            (*(char *)(lVar18 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_360[0] = 0x1007a6;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
            puVar22 = puStack_328;
          }
          else {
            uStack_338 = 0;
            auStack_360[0] = 0x1007cc;
            (*_DAT_)(1,0x1301658,0x1421328,0x877);
            puVar22 = puStack_328;
          }
        }
        auStack_360[0] = 0x1007dd;
        func_0x(*ppbVar2,0x12);
        iVar14 = *(int *)(puVar21 + 1);
      }
      if (0x3f3b < iVar14 - 1U) {
        iStack_320 = iStack_320 + 1;
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar18 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), puVar22 = puStack_328, lVar18 != 0 &&
            ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
             (*(char *)(lVar18 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_360[0] = 0x10086b;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            puVar22 = puStack_328;
          }
          else {
            uStack_338 = 0;
            auStack_360[0] = 0x100891;
            (*_DAT_)(1,0x1301658,0x1421328,0x87c);
            puVar22 = puStack_328;
          }
        }
        auStack_360[0] = 0x1008a2;
        func_0x(*ppbVar2,5);
      }
    }
LAB_:
    uStack_2d8 = *puVar1;
    psVar28 = psStack_2d0;
    if ((uStack_2d8 < 9) &&
       (((**(byte **)(puVar22 + 3) & 0xe) == 0 || ((**(byte **)(puVar22 + 3) & 0xe) == 0xc)))) {
      uStack_2d8 = 9;
    }
  }
  else {
    uStack_2d8 = *(uint *)(param_5 + 2);
    if (uStack_2d8 == 0) {
      auStack_360[0] = 0x1008f4;
      func_0x(puVar22);
      uStack_2d8 = *(uint *)(param_5 + 2);
    }
    psVar28 = param_6;
    if ((uStack_2d8 < 9) &&
       (((**(byte **)(param_5 + 4) & 0x1c) == 0 ||
        (psVar28 = param_6, (**(byte **)(param_5 + 4) & 0x1c) == 0xc)))) {
      uStack_2d8 = 9;
      psVar28 = param_6;
    }
  }
  uStack_310 = 9;
  puVar22 = (ushort *)(psVar28 + 1);
  uStack_2f8 = puVar22;
  if (*psVar28 == 0) {
    puVar1 = (uint *)(psVar28 + 2);
    puStack_328 = puVar22;
    if (*puVar1 == 0) {
      iStack_31c = 0;
      *puVar22 = 0;
      uVar17 = *(uint *)(psVar28 + 8);
      uVar15 = (ulonglong)uVar17;
      puVar30 = (uint *)(psVar28 + 10);
      *puVar30 = uVar17;
      ppbVar2 = (byte **)(psVar28 + 4);
      pbVar19 = *ppbVar2;
      bVar9 = *pbVar19;
      if ((bVar9 & 0x10) != 0) {
        uVar17 = uVar17 + (*(ushort *)(pbVar19 + uVar15) + 7 >> 3) + 2;
        uVar15 = (ulonglong)uVar17;
        *puVar30 = uVar17;
        bVar9 = *pbVar19;
      }
      puVar21 = (ushort *)(psVar28 + 0xe);
      if ((bVar9 & 0x20) == 0) {
        *puVar1 = (uint)uVar15;
        *puVar21 = 0;
        *(uint *)(psVar28 + 0xc) = uVar17;
      }
      else {
        uStack_308 = (ushort *)(pbVar19 + uVar15);
        uVar16 = *uStack_308;
        *puVar21 = uVar16;
        if (uVar16 == 0) {
          iStack_31c = 1;
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x100a2b;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x100a51;
              (*_DAT_)(1,0x1301658,0x1421328,0x80f);
            }
          }
          puVar22 = puStack_328;
          auStack_360[0] = 0x100a62;
          func_0x(*ppbVar2,3);
          uVar17 = *puVar30;
        }
        uVar16 = *puVar21;
        uVar17 = uVar17 + (uVar16 + 1) * 2;
        puVar3 = (uint *)(puVar22 + 0xb);
        *puVar3 = uVar17;
        if (0x1f9e < uVar17) {
          iStack_31c = iStack_31c + 1;
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), puVar22 = puStack_328, lVar18 != 0 &&
              ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
               (*(char *)(lVar18 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x100b02;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
              puVar22 = puStack_328;
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x100b28;
              (*_DAT_)(1,0x1301658,0x1421328,0x816);
              puVar22 = puStack_328;
            }
          }
          auStack_360[0] = 0x100b39;
          func_0x(*ppbVar2,4);
          uVar16 = *puVar21;
          uVar17 = *puVar3;
        }
        uVar15 = (ulonglong)uVar16;
        uVar16 = uStack_308[uVar15];
        *puVar1 = uVar16 & 0x7fff;
        puVar25 = uStack_2f8;
        if ((uVar16 & 0x7fff) < uVar17) {
          iStack_31c = iStack_31c + 1;
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), puVar22 = puStack_328, lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x100bdc;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
              puVar22 = puStack_328;
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x100c02;
              (*_DAT_)(1,0x1301658,0x1421328,0x81d);
              puVar22 = puStack_328;
            }
          }
          auStack_360[0] = 0x100c13;
          func_0x(*ppbVar2,4);
          uVar15 = (ulonglong)*puVar21;
          puVar25 = uStack_2f8;
        }
        while ((short)uStack_308[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          pbVar19 = *ppbVar2;
          uVar17 = *puVar30;
          if ((int)uVar15 == 1) {
            uVar24 = *(uint *)(puVar25 + 0xb);
            uVar20 = (ulonglong)uVar24;
            uVar16 = *(ushort *)(pbVar19 + uVar15 * 2 + (ulonglong)uVar17);
LAB_:
            if ((uVar16 & 0x7fff) < (uint)uVar20) goto LAB_;
          }
          else {
            uVar20 = (ulonglong)
                     (*(ushort *)(pbVar19 + uVar15 * 2 + ((ulonglong)uVar17 - 2)) & 0x7fff);
            uVar24 = *(uint *)(puVar25 + 0xb);
            uVar16 = *(ushort *)(pbVar19 + uVar15 * 2 + (ulonglong)uVar17);
            if (uVar24 <= (*(ushort *)(pbVar19 + uVar15 * 2 + ((ulonglong)uVar17 - 2)) & 0x7fff))
            goto LAB_;
LAB_:
            auStack_360[0] = 0x100c83;
            func_0x(pbVar19,7);
            uVar24 = *(uint *)(uStack_2f8 + 0xb);
            puVar25 = uStack_2f8;
          }
          uStack_2b0 = (uint)uVar20;
          if ((uStack_2b0 < uVar24) || (*puVar1 < uStack_2b0)) {
            iStack_31c = iStack_31c + 1;
            goto LAB_;
          }
          if (*(ushort *)(*ppbVar2 + uVar20) == 5) {
            *puVar22 = *puVar22 | 2;
            *puVar21 = *puVar21 - 1;
            puVar22[0x14] = (ushort)uVar20;
            lVar18 = (uVar20 & 0xffff) + *(longlong *)(puVar22 + 3);
            uVar16 = *(ushort *)(lVar18 + 2);
            uVar10 = puVar22[0x15] & 0xc7ff;
            if ((uVar16 >> 0xe & 1) == 0) {
              puVar22[0x15] = uVar10;
            }
            else {
              uVar10 = uVar16 & 0x3800 | uVar10;
              puVar22[0x15] = uVar10;
            }
            puVar22[0x15] = (uVar10 ^ *(ushort *)(lVar18 + 2)) & 0x7ff ^ uVar10;
            break;
          }
          if (*(ushort *)(*ppbVar2 + uVar20) < 0x400) break;
          *puVar22 = *puVar22 | 1;
          uVar16 = *puVar21 - 1;
          *puVar21 = uVar16;
          if (uVar16 == 0) break;
          uVar15 = (ulonglong)uVar16;
        }
        pbVar19 = *ppbVar2;
        uVar15 = (ulonglong)*puVar1;
      }
      iVar14 = 0;
      if ((*pbVar19 & 0x40) == 0) {
        *(undefined4 *)(psVar28 + 0x13) = 0;
      }
      else {
        *(uint *)(psVar28 + 0x13) = *puVar1;
        *puVar1 = *puVar1 + 0xe;
        auStack_360[0] = 0x100d6e;
        puVar11 = (ulonglong *)func_0x(puVar22);
        uStack_270 = *puVar11;
        uVar16 = (ushort)(uStack_270 >> 0x30);
        if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
          if ((uVar16 >> 0xe & 1) == 0) {
            uVar16 = uVar16 & 0xdfff;
          }
          else {
            uVar16 = uVar16 | 0x2000;
          }
        }
        if (uVar16 == 0xfffc) {
          iVar14 = (int)((uStack_270 >> 0x20 & 0xffff) >> 5);
        }
        *puVar1 = *puVar1 + iVar14;
        uVar15 = (ulonglong)*puVar1;
      }
      iVar14 = (int)uVar15;
      if ((*(byte **)(puVar22 + 0xe) != (byte *)0x0) &&
         (*(byte **)(puVar22 + 0xe) < *ppbVar2 + uVar15)) {
        iStack_31c = iStack_31c + 1;
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar18 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), puVar22 = puStack_328, lVar18 != 0 &&
             (lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0)) &&
            (*(char *)(lVar18 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_360[0] = 0x100e66;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
            puVar22 = puStack_328;
          }
          else {
            uStack_338 = 0;
            auStack_360[0] = 0x100e8c;
            (*_DAT_)(1,0x1301658,0x1421328,0x877);
            puVar22 = puStack_328;
          }
        }
        auStack_360[0] = 0x100e9d;
        func_0x(*ppbVar2,0x12);
        iVar14 = *(int *)(uStack_2f8 + 1);
      }
      if (0x3f3b < iVar14 - 1U) {
        iStack_31c = iStack_31c + 1;
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar18 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), puVar22 = puStack_328, lVar18 != 0 &&
            ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
             (*(char *)(lVar18 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_360[0] = 0x100f2f;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            puVar22 = puStack_328;
          }
          else {
            uStack_338 = 0;
            auStack_360[0] = 0x100f55;
            (*_DAT_)(1,0x1301658,0x1421328,0x87c);
            puVar22 = puStack_328;
          }
        }
        auStack_360[0] = 0x100f66;
        func_0x(*ppbVar2,5);
      }
    }
LAB_:
    uVar17 = *puVar1;
    puVar21 = uStack_2f8;
    psVar28 = psStack_2d0;
    uVar24 = uVar17;
    if ((uVar17 < 9) &&
       (((**(byte **)(puVar22 + 3) & 0xe) == 0 || ((**(byte **)(puVar22 + 3) & 0xe) == 0xc)))) {
      uVar24 = 9;
    }
  }
  else {
    uVar17 = *(uint *)(psVar28 + 2);
    if (uVar17 == 0) {
      auStack_360[0] = 0x100fb0;
      func_0x(puVar22);
      uVar17 = *(uint *)(psVar28 + 2);
    }
    puVar21 = puVar22;
    uVar24 = uVar17;
    if ((uVar17 < 9) &&
       (((**(byte **)(psVar28 + 4) & 0x1c) == 0 || ((**(byte **)(psVar28 + 4) & 0x1c) == 0xc)))) {
      uVar24 = 9;
    }
  }
  psVar29 = psStack_2e0;
  puVar22 = uStack_2e8;
  if (uVar24 < uStack_2d8) {
    if (*psStack_2e0 != 0) {
      uVar17 = *(uint *)(uStack_2e8 + 1);
      if (uVar17 == 0) {
        auStack_360[0] = 0x10166c;
        func_0x(uStack_2e8);
        uVar17 = *(uint *)(puVar22 + 1);
      }
      uStack_310 = uVar17;
      if ((uVar17 < 9) &&
         (((**(byte **)(puVar22 + 3) & 0x1c) == 0 || ((**(byte **)(puVar22 + 3) & 0x1c) == 0xc)))) {
        uStack_310 = 9;
      }
      goto LAB_;
    }
    puStack_328 = uStack_2e8;
    puVar1 = (uint *)(uStack_2e8 + 1);
    puVar21 = uStack_2e8;
    if (*puVar1 == 0) {
      iStack_318 = 0;
      *uStack_2e8 = 0;
      uVar17 = *(uint *)(uStack_2e8 + 7);
      uVar15 = (ulonglong)uVar17;
      puVar30 = (uint *)(uStack_2e8 + 9);
      *puVar30 = uVar17;
      ppbVar2 = (byte **)(uStack_2e8 + 3);
      pbVar19 = *ppbVar2;
      bVar9 = *pbVar19;
      if ((bVar9 & 0x10) != 0) {
        uVar17 = uVar17 + 2 + (*(ushort *)(pbVar19 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar17;
        *puVar30 = uVar17;
        bVar9 = *pbVar19;
      }
      puVar25 = uStack_2e8 + 0xd;
      if ((bVar9 & 0x20) == 0) {
        *puVar1 = (uint)uVar15;
        *puVar25 = 0;
        *(uint *)(uStack_2e8 + 0xb) = uVar17;
      }
      else {
        uStack_308 = (ushort *)(pbVar19 + uVar15);
        uVar16 = *uStack_308;
        *puVar25 = uVar16;
        if (uVar16 == 0) {
          iStack_318 = 1;
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x1010ed;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x101113;
              (*_DAT_)(1,0x1301658,0x1421328,0x80f);
            }
          }
          puVar21 = puStack_328;
          auStack_360[0] = 0x101124;
          func_0x(*ppbVar2,3);
          uVar17 = *puVar30;
        }
        uVar16 = *puVar25;
        uVar17 = uVar17 + (uVar16 + 1) * 2;
        puVar3 = (uint *)(puVar21 + 0xb);
        *puVar3 = uVar17;
        if (0x1f9e < uVar17) {
          iStack_318 = iStack_318 + 1;
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), puVar21 = puStack_328, lVar18 != 0 &&
              ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
               (*(char *)(lVar18 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x1011c8;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
              puVar21 = puStack_328;
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x1011ee;
              (*_DAT_)(1,0x1301658,0x1421328,0x816);
              puVar21 = puStack_328;
            }
          }
          auStack_360[0] = 0x1011ff;
          func_0x(*ppbVar2,4);
          uVar16 = *puVar25;
          uVar17 = *puVar3;
        }
        uVar15 = (ulonglong)uVar16;
        uVar16 = uStack_308[uVar15];
        *puVar1 = uVar16 & 0x7fff;
        puVar27 = uStack_2e8;
        if ((uVar16 & 0x7fff) < uVar17) {
          iStack_318 = iStack_318 + 1;
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), puVar21 = puStack_328, lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x1012a1;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
              puVar21 = puStack_328;
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x1012c7;
              (*_DAT_)(1,0x1301658,0x1421328,0x81d);
              puVar21 = puStack_328;
            }
          }
          auStack_360[0] = 0x1012d8;
          func_0x(*ppbVar2,4);
          uVar15 = (ulonglong)*puVar25;
          puVar27 = uStack_2e8;
        }
        while ((short)uStack_308[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          pbVar19 = *ppbVar2;
          uVar17 = *puVar30;
          if ((int)uVar15 == 1) {
            uVar24 = *(uint *)(puVar27 + 0xb);
            uVar16 = *(ushort *)(pbVar19 + uVar15 * 2 + (ulonglong)uVar17);
            uVar13 = uVar24;
LAB_:
            if ((uVar16 & 0x7fff) < uVar24) goto LAB_;
          }
          else {
            uVar24 = *(ushort *)(pbVar19 + uVar15 * 2 + ((ulonglong)uVar17 - 2)) & 0x7fff;
            uVar13 = *(uint *)(puVar27 + 0xb);
            uVar16 = *(ushort *)(pbVar19 + uVar15 * 2 + (ulonglong)uVar17);
            if (uVar13 <= uVar24) goto LAB_;
LAB_:
            auStack_360[0] = 0x101344;
            func_0x(pbVar19,7);
            uVar13 = *(uint *)(uStack_2e8 + 0xb);
            puVar27 = uStack_2e8;
          }
          uStack_2ac = uVar24;
          if ((uVar24 < uVar13) || (*puVar1 < uVar24)) {
            iStack_318 = iStack_318 + 1;
            goto LAB_;
          }
          if (*(ushort *)(*ppbVar2 + uVar24) == 5) {
            *puVar21 = *puVar21 | 2;
            *puVar25 = *puVar25 - 1;
            puVar21[0x14] = (ushort)uVar24;
            lVar18 = (ulonglong)(uVar24 & 0xffff) + *(longlong *)(puVar21 + 3);
            uVar16 = *(ushort *)(lVar18 + 2);
            uVar10 = puVar21[0x15] & 0xc7ff;
            if ((uVar16 >> 0xe & 1) == 0) {
              puVar21[0x15] = uVar10;
            }
            else {
              uVar10 = uVar16 & 0x3800 | uVar10;
              puVar21[0x15] = uVar10;
            }
            puVar21[0x15] = (uVar10 ^ *(ushort *)(lVar18 + 2)) & 0x7ff ^ uVar10;
            break;
          }
          if (*(ushort *)(*ppbVar2 + uVar24) < 0x400) break;
          *puVar21 = *puVar21 | 1;
          uVar16 = *puVar25 - 1;
          *puVar25 = uVar16;
          if (uVar16 == 0) break;
          uVar15 = (ulonglong)uVar16;
        }
        pbVar19 = *ppbVar2;
        uVar15 = (ulonglong)*puVar1;
      }
      puVar25 = uStack_2e8;
      if ((*pbVar19 & 0x40) == 0) {
        *(undefined4 *)(puVar22 + 0x12) = 0;
      }
      else {
        uVar17 = *puVar1;
        *(uint *)(puVar22 + 0x12) = uVar17;
        *puVar1 = uVar17 + 0xe;
        auStack_360[0] = 0x101430;
        puVar12 = (undefined8 *)func_0x(puVar21);
        uStack_268 = *puVar12;
        uVar17 = 0;
        uVar16 = (ushort)((ulonglong)uStack_268 >> 0x30);
        if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
          if ((uVar16 >> 0xe & 1) == 0) {
            uVar16 = uVar16 & 0xdfff;
          }
          else {
            uVar16 = uVar16 | 0x2000;
          }
        }
        if (uVar16 == 0xfffc) {
          uVar17 = ((uint)((ulonglong)uStack_268 >> 0x20) & 0xffff) >> 5;
        }
        *puVar1 = *puVar1 + uVar17;
        uVar15 = (ulonglong)*puVar1;
      }
      iVar14 = (int)uVar15;
      if ((*(byte **)(puVar21 + 0xe) != (byte *)0x0) &&
         (*(byte **)(puVar21 + 0xe) < *ppbVar2 + uVar15)) {
        iStack_318 = iStack_318 + 1;
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar18 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), puVar21 = puStack_328, lVar18 != 0 &&
             (lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0)) &&
            (*(char *)(lVar18 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_360[0] = 0x10152e;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
            puVar21 = puStack_328;
          }
          else {
            uStack_338 = 0;
            auStack_360[0] = 0x101554;
            (*_DAT_)(1,0x1301658,0x1421328,0x877);
            puVar21 = puStack_328;
          }
        }
        auStack_360[0] = 0x101565;
        func_0x(*ppbVar2,0x12);
        iVar14 = *(int *)(puVar25 + 1);
      }
      if (0x3f3b < iVar14 - 1U) {
        iStack_318 = iStack_318 + 1;
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar18 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), puVar21 = puStack_328, lVar18 != 0 &&
            ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
             (*(char *)(lVar18 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_360[0] = 0x1015f3;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            puVar21 = puStack_328;
          }
          else {
            uStack_338 = 0;
            auStack_360[0] = 0x101619;
            (*_DAT_)(1,0x1301658,0x1421328,0x87c);
            puVar21 = puStack_328;
          }
        }
        auStack_360[0] = 0x10162a;
        func_0x(*ppbVar2,5);
      }
    }
LAB_:
    uVar17 = *puVar1;
    if ((uVar17 < 9) &&
       ((puVar22 = uStack_2e8, psVar29 = psStack_2e0, (**(byte **)(puVar21 + 3) & 0xe) == 0 ||
        ((**(byte **)(puVar21 + 3) & 0xe) == 0xc)))) goto LAB_;
  }
  else {
    if (*psVar28 != 0) {
      if (uVar17 == 0) {
        auStack_360[0] = 0x101d26;
        func_0x(puVar21);
        uVar17 = *(uint *)(puVar21 + 1);
      }
      puVar22 = uStack_2e8;
      psVar29 = psStack_2e0;
      uStack_310 = uVar17;
      if ((8 < uVar17) ||
         (((**(byte **)(puVar21 + 3) & 0x1c) != 0 && ((**(byte **)(puVar21 + 3) & 0x1c) != 0xc))))
      goto LAB_;
LAB_:
      uStack_310 = 9;
      puVar22 = uStack_2e8;
      psVar29 = psStack_2e0;
      goto LAB_;
    }
    puVar22 = puVar21;
    puStack_328 = puVar21;
    if (uVar17 == 0) {
      iStack_314 = 0;
      *puVar21 = 0;
      uVar17 = *(uint *)(puVar21 + 7);
      uVar15 = (ulonglong)uVar17;
      puVar1 = (uint *)(puVar21 + 9);
      *puVar1 = uVar17;
      ppbVar2 = (byte **)(puVar21 + 3);
      pbVar19 = *ppbVar2;
      bVar9 = *pbVar19;
      if ((bVar9 & 0x10) != 0) {
        uVar17 = uVar17 + (*(ushort *)(pbVar19 + uVar15) + 7 >> 3) + 2;
        uVar15 = (ulonglong)uVar17;
        *puVar1 = uVar17;
        bVar9 = *pbVar19;
      }
      puVar25 = puVar21 + 0xd;
      if ((bVar9 & 0x20) == 0) {
        puVar30 = (uint *)(puVar21 + 1);
        *puVar30 = (uint)uVar15;
        *puVar25 = 0;
        *(uint *)(puVar21 + 0xb) = uVar17;
        puVar25 = puVar21;
      }
      else {
        uStack_308 = (ushort *)(pbVar19 + uVar15);
        uVar16 = *uStack_308;
        *puVar25 = uVar16;
        if (uVar16 == 0) {
          iStack_314 = 1;
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x1017a1;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x1017c7;
              (*_DAT_)(1,0x1301658,0x1421328,0x80f);
            }
          }
          puVar22 = puStack_328;
          auStack_360[0] = 0x1017d8;
          func_0x(*ppbVar2,3);
          uVar17 = *puVar1;
        }
        uVar16 = *puVar25;
        uVar17 = uVar17 + (uVar16 + 1) * 2;
        puVar30 = (uint *)(puVar22 + 0xb);
        *puVar30 = uVar17;
        if (0x1f9e < uVar17) {
          iStack_314 = iStack_314 + 1;
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), puVar22 = puStack_328, lVar18 != 0 &&
              ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
               (*(char *)(lVar18 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x10187c;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
              puVar22 = puStack_328;
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x1018a2;
              (*_DAT_)(1,0x1301658,0x1421328,0x816);
              puVar22 = puStack_328;
            }
          }
          auStack_360[0] = 0x1018b3;
          func_0x(*ppbVar2,4);
          uVar16 = *puVar25;
          uVar17 = *puVar30;
        }
        uVar15 = (ulonglong)uVar16;
        uVar16 = uStack_308[uVar15];
        puVar30 = (uint *)(puVar22 + 1);
        *puVar30 = uVar16 & 0x7fff;
        puVar27 = uStack_2f8;
        if ((uVar16 & 0x7fff) < uVar17) {
          iStack_314 = iStack_314 + 1;
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), puVar22 = puStack_328, lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              auStack_360[0] = 0x101959;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
              puVar22 = puStack_328;
            }
            else {
              uStack_338 = 0;
              auStack_360[0] = 0x10197f;
              (*_DAT_)(1,0x1301658,0x1421328,0x81d);
              puVar22 = puStack_328;
            }
          }
          auStack_360[0] = 0x101990;
          func_0x(*ppbVar2,4);
          uVar15 = (ulonglong)*puVar25;
          puVar27 = uStack_2f8;
        }
        while ((short)uStack_308[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          pbVar19 = *ppbVar2;
          uVar17 = *puVar1;
          if ((int)uVar15 == 1) {
            uVar24 = *(uint *)(puVar27 + 0xb);
            uVar16 = *(ushort *)(pbVar19 + uVar15 * 2 + (ulonglong)uVar17);
            uVar13 = uVar24;
LAB_:
            if ((uVar16 & 0x7fff) < uVar24) goto LAB_;
          }
          else {
            uVar24 = *(ushort *)(pbVar19 + uVar15 * 2 + ((ulonglong)uVar17 - 2)) & 0x7fff;
            uVar13 = *(uint *)(puVar27 + 0xb);
            uVar16 = *(ushort *)(pbVar19 + uVar15 * 2 + (ulonglong)uVar17);
            if (uVar13 <= uVar24) goto LAB_;
LAB_:
            auStack_360[0] = 0x101a04;
            func_0x(pbVar19,7);
            uVar13 = *(uint *)(uStack_2f8 + 0xb);
            puVar27 = uStack_2f8;
          }
          if ((uVar24 < uVar13) || (*puVar30 < uVar24)) {
            iStack_314 = iStack_314 + 1;
            goto LAB_;
          }
          uStack_310 = uVar24;
          if (*(ushort *)(*ppbVar2 + uVar24) == 5) {
            *puVar22 = *puVar22 | 2;
            *puVar25 = *puVar25 - 1;
            puVar22[0x14] = (ushort)uVar24;
            lVar18 = (ulonglong)(uVar24 & 0xffff) + *(longlong *)(puVar22 + 3);
            uVar16 = *(ushort *)(lVar18 + 2);
            uVar10 = puVar22[0x15] & 0xc7ff;
            if ((uVar16 >> 0xe & 1) == 0) {
              puVar22[0x15] = uVar10;
            }
            else {
              uVar10 = uVar16 & 0x3800 | uVar10;
              puVar22[0x15] = uVar10;
            }
            puVar22[0x15] = (uVar10 ^ *(ushort *)(lVar18 + 2)) & 0x7ff ^ uVar10;
            break;
          }
          if (*(ushort *)(*ppbVar2 + uVar24) < 0x400) break;
          *puVar22 = *puVar22 | 1;
          uVar16 = *puVar25 - 1;
          *puVar25 = uVar16;
          if (uVar16 == 0) break;
          uVar15 = (ulonglong)uVar16;
        }
        pbVar19 = *ppbVar2;
        puVar25 = uStack_2f8;
      }
      if ((*pbVar19 & 0x40) == 0) {
        *(undefined4 *)(puVar21 + 0x12) = 0;
        uVar17 = *(uint *)(puVar25 + 1);
      }
      else {
        *(uint *)(puVar21 + 0x12) = *puVar30;
        *puVar30 = *puVar30 + 0xe;
        auStack_360[0] = 0x101aee;
        puVar12 = (undefined8 *)func_0x(puVar22);
        uStack_260 = *puVar12;
        uVar17 = 0;
        uVar16 = (ushort)((ulonglong)uStack_260 >> 0x30);
        if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
          if ((uVar16 >> 0xe & 1) == 0) {
            uVar16 = uVar16 & 0xdfff;
          }
          else {
            uVar16 = uVar16 | 0x2000;
          }
        }
        if (uVar16 == 0xfffc) {
          uVar17 = ((uint)((ulonglong)uStack_260 >> 0x20) & 0xffff) >> 5;
        }
        *puVar30 = *puVar30 + uVar17;
        uVar17 = *puVar30;
      }
      if ((*(byte **)(puVar22 + 0xe) != (byte *)0x0) &&
         (*(byte **)(puVar22 + 0xe) < *ppbVar2 + uVar17)) {
        iStack_314 = iStack_314 + 1;
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar18 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), puVar22 = puStack_328, lVar18 != 0 &&
             (lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0)) &&
            (*(char *)(lVar18 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_360[0] = 0x101bed;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
            puVar22 = puStack_328;
          }
          else {
            uStack_338 = 0;
            auStack_360[0] = 0x101c13;
            (*_DAT_)(1,0x1301658,0x1421328,0x877);
            puVar22 = puStack_328;
          }
        }
        auStack_360[0] = 0x101c24;
        func_0x(*ppbVar2,0x12);
        uVar17 = *(uint *)(puVar25 + 1);
      }
      if (0x3f3b < uVar17 - 1) {
        iStack_314 = iStack_314 + 1;
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar18 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), puVar22 = puStack_328, lVar18 != 0 &&
            ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
             (*(char *)(lVar18 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_360[0] = 0x101cb2;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            puVar22 = puStack_328;
          }
          else {
            uStack_338 = 0;
            auStack_360[0] = 0x101cd8;
            (*_DAT_)(1,0x1301658,0x1421328,0x87c);
            puVar22 = puStack_328;
          }
        }
        auStack_360[0] = 0x101ce9;
        func_0x(*ppbVar2,5);
      }
    }
LAB_:
    uVar17 = *(uint *)(puVar22 + 1);
    if (uVar17 < 9) {
      if ((**(byte **)(puVar22 + 3) & 0xe) == 0) goto LAB_;
      if ((**(byte **)(puVar22 + 3) & 0xe) == 0xc) {
        uStack_310 = 9;
        puVar22 = uStack_2e8;
        psVar29 = psStack_2e0;
        goto LAB_;
      }
    }
  }
  puVar22 = uStack_2e8;
  psVar29 = psStack_2e0;
  uStack_310 = uVar17;
LAB_:
  lVar23 = lStack_2a8;
  uVar17 = (uStack_310 >> 4) + 4;
  uVar20 = (ulonglong)uVar17;
  *(uint *)(lStack_2a8 + 0x14) = uVar17;
  lVar18 = uVar20 * 4;
  lVar26 = (ulonglong)uVar17 * 0x10;
  psStack_2e0 = (short *)(lVar26 + uVar20 * 0xe + 0x54 + (ulonglong)(uVar17 * 2 + 4) * 2);
  *(undefined4 *)(lStack_2a8 + 0x10) = 1;
  *(int *)(lStack_2a8 + 0x18) = (int)psStack_2e0;
  uVar15 = (longlong)psStack_2e0 + 0xf;
  if (uVar15 <= psStack_2e0) {
    uVar15 = 0xffffffffffffff0;
  }
  uVar15 = uVar15 & 0xfffffffffffffff0;
  auStack_360[0] = 0x101dea;
  func_0x();
  psVar28 = psStack_2d0;
  puVar21 = uStack_2f8;
  lVar4 = -uVar15;
  *(longlong *)(lVar23 + 0x48) = (longlong)&puStack_328 + lVar4;
  lVar26 = lVar26 + 0x38 + (longlong)&puStack_328 + lVar4;
  *(longlong *)(lVar23 + 0x40) = lVar26;
  lVar26 = uVar20 * 8 + 0x1c + lVar26;
  *(longlong *)(lVar23 + 0x30) = lVar26;
  lVar26 = lVar26 + lVar18;
  *(longlong *)(lVar23 + 0x38) = lVar26;
  *(ulonglong *)(lVar23 + 0x20) = lVar26 + uVar20 * 2;
  *(undefined4 *)(lVar23 + 0x28) = 0;
  *(undefined4 *)(lVar23 + 0x10) = 2;
  *(undefined4 *)(lVar23 + 0xc) = 0;
  if (*psStack_2d0 == 0) {
    *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101e46;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101e4d;
    func_0x(puVar21,puVar22,lVar23);
  }
  uVar7 = uStack_298;
  uVar17 = *(int *)(lVar23 + 0x28) * 0x10 + *(int *)(lVar23 + 4) + 4;
  *puStack_2a0 = uVar17;
  if (uVar17 < 0xc9) {
    *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101e81;
    func_0x(lVar23,uVar7);
  }
  else {
    *(longlong *)(lStack_290 + 0xb8) = *(longlong *)(lStack_290 + 0xb8) + 1;
    *puStack_2a0 = 0;
  }
  if ((char)uStack_2d4 != '\0') {
    if (*psVar28 == 0) {
      *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101eaf;
      func_0x();
    }
    else {
      *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101eb6;
      func_0x(puVar21,&uStack_218);
    }
  }
  if (cStack_30c != '\0') {
    if (*psVar29 == 0) {
      *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101ed2;
      func_0x();
    }
    else {
      *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101ed9;
      func_0x(puVar22,&uStack_138);
    }
  }
  *(uint *)(lStack_2b8 + 0x268) = *(uint *)(lStack_2b8 + 0x268) & ~auStack_2c0[0];
  *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101ef5;
  func_0x(auStack_240);
  lVar23 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar18 = *(longlong *)(lVar23 + 0x100);
  if (lVar18 == 0) {
    *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101f30;
    (*_DAT_)();
    lVar18 = *(longlong *)(lVar23 + 0x100);
  }
  if (*(int *)(lVar18 + 0x22c) != 0) {
    *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101f46;
    (*_DAT_)();
  }
  uVar15 = uStack_58 ^ (ulonglong)&puStack_328;
  *(undefined8 *)((longlong)auStack_360 + lVar4) = 0x101f5c;
  func_0x(uVar15);
  return;
}

