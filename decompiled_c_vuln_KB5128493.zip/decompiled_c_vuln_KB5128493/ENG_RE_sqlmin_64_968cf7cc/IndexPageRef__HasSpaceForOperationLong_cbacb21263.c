
/* WARNING: Removing unreachable block (ram,0x00103b1a) */
/* WARNING: Removing unreachable block (ram,0x00103b27) */
/* WARNING: Removing unreachable block (ram,0x00103b30) */
/* WARNING: Removing unreachable block (ram,0x00103b3b) */
/* WARNING: Removing unreachable block (ram,0x00103b3f) */
/* WARNING: Removing unreachable block (ram,0x00102afa) */
/* WARNING: Removing unreachable block (ram,0x00102b0b) */
/* WARNING: Removing unreachable block (ram,0x00102b1e) */
/* WARNING: Removing unreachable block (ram,0x00102b32) */
/* WARNING: Removing unreachable block (ram,0x00102e5a) */
/* WARNING: Removing unreachable block (ram,0x00102b3c) */
/* WARNING: Removing unreachable block (ram,0x00102b55) */
/* WARNING: Removing unreachable block (ram,0x00102b65) */
/* WARNING: Removing unreachable block (ram,0x00102b6f) */
/* WARNING: Removing unreachable block (ram,0x00102b78) */
/* WARNING: Removing unreachable block (ram,0x00102ba2) */
/* WARNING: Removing unreachable block (ram,0x00102b88) */
/* WARNING: Removing unreachable block (ram,0x00102bc6) */
/* WARNING: Removing unreachable block (ram,0x00102be0) */
/* WARNING: Removing unreachable block (ram,0x00102c01) */
/* WARNING: Removing unreachable block (ram,0x00102c11) */
/* WARNING: Removing unreachable block (ram,0x00102c1b) */
/* WARNING: Removing unreachable block (ram,0x00102c24) */
/* WARNING: Removing unreachable block (ram,0x00102c4e) */
/* WARNING: Removing unreachable block (ram,0x00102c34) */
/* WARNING: Removing unreachable block (ram,0x00102c72) */
/* WARNING: Removing unreachable block (ram,0x00102c91) */
/* WARNING: Removing unreachable block (ram,0x00102cac) */
/* WARNING: Removing unreachable block (ram,0x00102cbc) */
/* WARNING: Removing unreachable block (ram,0x00102cc6) */
/* WARNING: Removing unreachable block (ram,0x00102ccf) */
/* WARNING: Removing unreachable block (ram,0x00102cf9) */
/* WARNING: Removing unreachable block (ram,0x00102cdf) */
/* WARNING: Removing unreachable block (ram,0x00102d1d) */
/* WARNING: Removing unreachable block (ram,0x00102d40) */
/* WARNING: Removing unreachable block (ram,0x00102d46) */
/* WARNING: Removing unreachable block (ram,0x00102d5a) */
/* WARNING: Removing unreachable block (ram,0x00102d6c) */
/* WARNING: Removing unreachable block (ram,0x00102d67) */
/* WARNING: Removing unreachable block (ram,0x00102d78) */
/* WARNING: Removing unreachable block (ram,0x00102d89) */
/* WARNING: Removing unreachable block (ram,0x00102d8e) */
/* WARNING: Removing unreachable block (ram,0x00102daf) */
/* WARNING: Removing unreachable block (ram,0x00102db8) */
/* WARNING: Removing unreachable block (ram,0x00102dc0) */
/* WARNING: Removing unreachable block (ram,0x00102df2) */
/* WARNING: Removing unreachable block (ram,0x00102e30) */
/* WARNING: Removing unreachable block (ram,0x00102e1e) */
/* WARNING: Removing unreachable block (ram,0x00102e38) */
/* WARNING: Removing unreachable block (ram,0x00102dcd) */
/* WARNING: Removing unreachable block (ram,0x00102ddb) */
/* WARNING: Removing unreachable block (ram,0x00102ded) */
/* WARNING: Removing unreachable block (ram,0x00102e67) */
/* WARNING: Removing unreachable block (ram,0x00102ea8) */
/* WARNING: Removing unreachable block (ram,0x00102e6d) */
/* WARNING: Removing unreachable block (ram,0x00102eac) */
/* WARNING: Removing unreachable block (ram,0x00102eba) */
/* WARNING: Removing unreachable block (ram,0x00102ec8) */
/* WARNING: Removing unreachable block (ram,0x00102ed8) */
/* WARNING: Removing unreachable block (ram,0x00102ee2) */
/* WARNING: Removing unreachable block (ram,0x00102eeb) */
/* WARNING: Removing unreachable block (ram,0x00102f15) */
/* WARNING: Removing unreachable block (ram,0x00102efb) */
/* WARNING: Removing unreachable block (ram,0x00102f39) */
/* WARNING: Removing unreachable block (ram,0x00102f51) */
/* WARNING: Removing unreachable block (ram,0x00102f5f) */
/* WARNING: Removing unreachable block (ram,0x00102f6f) */
/* WARNING: Removing unreachable block (ram,0x00102f79) */
/* WARNING: Removing unreachable block (ram,0x00102f82) */
/* WARNING: Removing unreachable block (ram,0x00102fac) */
/* WARNING: Removing unreachable block (ram,0x00102f92) */
/* WARNING: Removing unreachable block (ram,0x00102fd0) */
/* WARNING: Removing unreachable block (ram,0x00102fe8) */
/* WARNING: Removing unreachable block (ram,0x00102fed) */
/* WARNING: Removing unreachable block (ram,0x00102ff5) */
/* WARNING: Removing unreachable block (ram,0x00102ff9) */
/* WARNING: Removing unreachable block (ram,0x00102ffc) */
/* WARNING: Removing unreachable block (ram,0x00103004) */
/* WARNING: Removing unreachable block (ram,0x00103008) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong *
FUN_(longlong **param_1,longlong param_2,longlong *param_3,longlong param_4,uint *param_5,
            uint param_6,int param_7,undefined8 param_8,short **param_9,uint *param_10,int param_11,
            longlong param_12,undefined4 *param_13,int *param_14)

{
  ushort *puVar1;
  undefined2 uVar2;
  short sVar3;
  undefined8 *puVar4;
  bool bVar5;
  short *psVar6;
  char cVar7;
  byte bVar8;
  ushort uVar9;
  int iVar10;
  uint uVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined8 uVar14;
  longlong lVar15;
  uint uVar16;
  longlong lVar17;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar18;
  undefined8 *puVar19;
  uint uVar20;
  longlong lVar21;
  ushort uVar22;
  int iVar23;
  byte *pbVar24;
  ushort *puVar25;
  short *psVar26;
  longlong unaff_GS_OFFSET;
  int iStack_a18;
  undefined auStack_a0e [2];
  int iStack_a0c;
  byte *pbStack_a08;
  undefined8 uStack_a00;
  undefined8 uStack_9f2;
  undefined2 uStack_9e8;
  undefined2 uStack_9e6;
  undefined2 uStack_9e4;
  undefined2 uStack_9e2;
  int iStack_9e0;
  int iStack_9d8;
  longlong lStack_9d0;
  undefined4 uStack_9c8;
  short *psStack_9c0;
  int iStack_9b8;
  undefined4 uStack_9b4;
  undefined4 uStack_9b0;
  int iStack_9ac;
  undefined8 uStack_998;
  longlong *plStack_990;
  int iStack_988;
  uint *puStack_980;
  longlong lStack_978;
  undefined4 uStack_970;
  undefined2 uStack_96c;
  undefined2 uStack_96a;
  undefined2 uStack_968;
  undefined4 uStack_958;
  uint uStack_954;
  uint uStack_950;
  uint uStack_94c;
  undefined auStack_938 [16];
  undefined auStack_928 [8];
  undefined auStack_920 [8];
  undefined auStack_918 [24];
  undefined8 uStack_900;
  undefined8 *puStack_8f8;
  undefined8 uStack_8e0;
  ushort auStack_8d8 [4];
  undefined8 auStack_8d0 [31];
  undefined4 uStack_7d8;
  longlong lStack_7d0;
  undefined2 uStack_7c8;
  undefined8 uStack_7c0;
  undefined auStack_7b8 [8];
  undefined4 uStack_7b0;
  undefined4 uStack_7a8;
  undefined4 **ppuStack_7a0;
  undefined *puStack_798;
  undefined8 uStack_790;
  undefined4 *puStack_788;
  undefined8 uStack_780;
  undefined auStack_778 [528];
  undefined8 uStack_568;
  undefined8 uStack_560;
  undefined4 uStack_558;
  uint uStack_554;
  undefined2 uStack_550;
  undefined4 uStack_54e;
  longlong lStack_54a;
  undefined8 uStack_542;
  undefined auStack_538 [8];
  undefined4 uStack_530;
  undefined4 uStack_528;
  undefined4 **ppuStack_520;
  undefined *puStack_518;
  undefined8 uStack_510;
  undefined4 *puStack_508;
  undefined8 uStack_500;
  undefined auStack_4f8 [528];
  undefined8 uStack_2e8;
  undefined8 uStack_2e0;
  undefined4 uStack_2d8;
  uint uStack_2d4;
  undefined2 uStack_2d0;
  undefined4 uStack_2ce;
  longlong lStack_2ca;
  undefined8 uStack_2c2;
  undefined auStack_2b8 [8];
  undefined4 uStack_2b0;
  undefined4 uStack_2a8;
  uint **ppuStack_2a0;
  undefined *puStack_298;
  undefined8 uStack_290;
  uint *puStack_288;
  undefined8 uStack_280;
  undefined auStack_278 [528];
  undefined8 uStack_68;
  undefined8 uStack_60;
  uint uStack_58;
  undefined2 uStack_54;
  undefined4 uStack_52;
  longlong lStack_4e;
  char cStack_46;
  
  uStack_8e0 = 0xfffffffffffffffe;
  plVar13 = (longlong *)0x0;
  auStack_8d8[0] = 0;
  uStack_7d8 = 0;
  uStack_7c8 = 0;
  lStack_7d0 = 0;
  uStack_7c0 = 0;
  uVar20 = (uint)(*(char *)(param_4 + 1) == '\x01');
  if (param_7 == 0) {
    uVar20 = uVar20 | 0x400000;
  }
  else if ((*(uint *)((longlong)*param_1 + 100) >> 0x13 & 1) != 0) {
    func_0x(0x18cb6d0,0x18cb680,*(undefined2 *)(param_4 + 0x24),
                    *(undefined4 *)(param_4 + 0x20));
    plVar12 = (longlong *)0x0;
    goto LAB_;
  }
  lVar17 = (ulonglong)*(uint6 *)(param_2 + 0x14) << 0x10;
  uVar2 = *(undefined2 *)(*(longlong *)(param_2 + 0x20) + 0x6b8);
  lStack_978 = -1;
  uStack_96a = 0;
  if ((_DAT_ & 0x1000) == 0) {
    plStack_990 = &lStack_978;
    puStack_8f8 = &uStack_998;
  }
  else {
    uStack_970 = *(undefined4 *)(*param_1 + 0xe);
    uStack_96c = *(undefined2 *)((longlong)*param_1 + 0x74);
    plStack_990 = &lStack_978;
    puStack_8f8 = &uStack_998;
    uStack_998 = _DAT_;
    lStack_978 = lVar17;
    uStack_968 = uVar2;
    if (*_DAT_ != 0) {
      (*_DAT_)(&uStack_900);
      uStack_998 = uStack_900;
    }
    uStack_7b0 = 0x10000;
    uStack_7a8 = 0;
    ppuStack_7a0 = &puStack_788;
    puStack_798 = auStack_778;
    uStack_568 = 0;
    uStack_790 = 0;
    uStack_560 = 0;
    puStack_788 = &uStack_558;
    uStack_780 = 0x1e;
    uStack_558 = 0;
    uStack_542 = 0;
    lStack_54a = *plStack_990;
    uStack_550 = *(undefined2 *)((longlong)plStack_990 + 0xc);
    uStack_54e = *(undefined4 *)(plStack_990 + 1);
    uStack_554 = (uint)*(ushort *)(plStack_990 + 2);
    func_0x(auStack_7b8);
  }
  iVar10 = func_0x(0,param_1,param_2,param_3,auStack_8d8,uVar20);
  if ((_DAT_ >> 0xc & 1) != 0) {
    uStack_530 = 0x10000;
    uStack_528 = 0;
    ppuStack_520 = &puStack_508;
    puStack_518 = auStack_4f8;
    uStack_2e8 = 0;
    uStack_510 = 0;
    uStack_2e0 = 0;
    puStack_508 = &uStack_2d8;
    uStack_500 = 0x1e;
    uStack_2d8 = 1;
    uStack_2c2 = func_0x(&uStack_998);
    lStack_2ca = *plStack_990;
    uStack_2d0 = *(undefined2 *)((longlong)plStack_990 + 0xc);
    uStack_2ce = *(undefined4 *)(plStack_990 + 1);
    uStack_2d4 = (uint)*(ushort *)(plStack_990 + 2);
    func_0x(auStack_538);
  }
  if (iVar10 != 0) {
    plVar12 = plVar13;
    if ((_DAT_ >> 0xb & 1) != 0) {
      uStack_2b0 = 0x10000;
      uStack_2a8 = 0;
      ppuStack_2a0 = &puStack_288;
      puStack_298 = auStack_278;
      uStack_68 = 0;
      uStack_290 = 0;
      uStack_60 = 0;
      puStack_288 = &uStack_58;
      uStack_280 = 0x13;
      uStack_54 = *(undefined2 *)((longlong)*param_1 + 0x74);
      uStack_52 = *(undefined4 *)(*param_1 + 0xe);
      uStack_58 = (uint)*(ushort *)(*(longlong *)(param_2 + 0x20) + 0x6b8);
      lStack_4e = (ulonglong)*(uint6 *)(param_2 + 0x14) << 0x10;
      cStack_46 = (char)iVar10;
      func_0x(auStack_2b8);
      plVar12 = (longlong *)0x0;
    }
    goto LAB_;
  }
  if (*_DAT_ != (char)iVar10) {
    plVar12 = plVar13;
    if (_DAT_ != 0) {
      plVar12 = (longlong *)(_DAT_ + 0x6800);
    }
    if ((plVar12 != (longlong *)0x0) && (*plVar12 != 0)) {
      LOCK();
      plVar12 = (longlong *)(*plVar12 + 0x150);
      *plVar12 = *plVar12 + 1;
      UNLOCK();
    }
  }
  lVar17 = *(longlong *)(*(longlong *)(param_2 + 8) + 0x488);
  if (((lVar17 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
    if (*(longlong *)(lVar17 + 0x20) != 0) {
      lVar21 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar15 = *(longlong *)(lVar21 + 0x100);
      if (lVar15 == 0) {
        (*_DAT_)(0);
        lVar15 = *(longlong *)(lVar21 + 0x100);
      }
      plVar12 = plVar13;
      if (*(longlong *)(lVar15 + 0x260) != 0) {
        plVar12 = (longlong *)(ulonglong)*(uint *)(*(longlong *)(lVar15 + 0x260) + 0xe68);
      }
      if ((uint)plVar12 < *(uint *)(_DAT_ + 8)) {
        lVar17 = *(longlong *)(*(longlong *)(lVar17 + 0x20) + (longlong)plVar12 * 8);
        *(longlong *)(lVar17 + 0x128) = *(longlong *)(lVar17 + 0x128) + 1;
        goto LAB_;
      }
    }
    LOCK();
    plVar12 = (longlong *)(*(longlong *)(lVar17 + 0x18) + 0x128);
    *plVar12 = *plVar12 + 1;
    UNLOCK();
  }
LAB_:
  *param_13 = 1;
  if (param_9 == (short **)0x0) {
    psStack_9c0 = (short *)0x0;
  }
  else {
    if (param_10 == (uint *)0x0) {
      puVar19 = (undefined8 *)param_9[1];
      puVar19[1] = 0;
      *puVar19 = 0xffff;
      puVar19[3] = 0;
      puVar19[4] = 0;
      puVar19[2] = 0;
      *(undefined4 *)(puVar19 + 6) = 0;
      puVar19[5] = 0;
      puVar19 = (undefined8 *)param_9[4];
      *puVar19 = 0;
      puVar19[0xc] = 0;
      *(undefined2 *)(puVar19 + 0xd) = 0;
      *(undefined8 *)((longlong)puVar19 + 0x6c) = 1;
      puVar19 = (undefined8 *)puVar19[1];
      if (puVar19 != (undefined8 *)0x0) {
        puVar4 = (undefined8 *)puVar19[1];
        if (puVar4 != (undefined8 *)0x0) {
          *puVar4 = 0;
          *(undefined4 *)(puVar4 + 0x481) = 0;
        }
        puVar19[3] = 0;
        *(undefined2 *)(puVar19 + 4) = 0;
        *puVar19 = 0;
        *(undefined4 *)(puVar19 + 0x14b) = 0;
      }
      if (*(char *)(param_4 + 2) < '\0') {
        func_0x(param_9,param_4);
        goto LAB_;
      }
    }
    else {
LAB_:
      if (*(char *)(param_4 + 2) < '\0') {
        psStack_9c0 = param_9[1];
        goto LAB_;
      }
    }
    psStack_9c0 = *param_9;
  }
LAB_:
  uStack_958 = *param_5;
  uStack_954 = param_5[1];
  uStack_950 = param_5[2];
  uStack_94c = param_5[3];
  iStack_a18 = 0;
  uStack_9c8 = 0;
  uStack_9b4 = 0;
  puStack_980 = (uint *)0x0;
  iStack_9d8 = 0;
  iStack_9ac = 0;
  pbStack_a08 = (byte *)0x0;
  iStack_a0c = 0;
  uStack_9f2 = 0;
  uStack_9e8 = 0;
  uStack_9e6 = 0;
  uStack_9e4 = 0;
  uStack_9e2 = 0;
  uStack_a00 = 0;
  lStack_9d0 = **param_1;
  plVar12 = param_3;
  if ((*(byte *)(param_3 + 0x43) & 4) != 0) {
    plVar12 = (longlong *)(**(code **)(*param_3 + 0x1e8))(param_3);
  }
  iStack_988 = *(int *)(plVar12 + 5);
  sVar3 = *(short *)((longlong)plVar12 + 0x2c);
  iStack_9b8 = 0;
  uStack_9b0 = 9;
  if (param_6 < 6) {
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)*(uint *)((longlong)(int)param_6 * 4 + 0x104c48) - 0xe7a7b0);
                    /* WARNING: Could not emulate address calculation at 0x00100560 */
                    /* WARNING: Treating indirect jump as call */
    plVar13 = (longlong *)(*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return plVar13;
  }
  (*_DAT_)(1,0x1a43ed0,0x1a71748,0x49f,0x163f078);
  if (((((byte)*(undefined4 *)(param_3 + 0x43) & 5) == 1) && ((*(byte *)(param_3 + 0x5b) & 2) != 0))
     || (cVar7 = (**(code **)*param_3)(param_3), uVar20 = uStack_958, cVar7 != '\0')) {
    if (param_6 < 6) {
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)*(uint *)((longlong)(int)param_6 * 4 + 0x104ccc) - 0xe7a7b0);
                    /* WARNING: Could not emulate address calculation at 0x00104061 */
                    /* WARNING: Treating indirect jump as call */
      plVar13 = (longlong *)(*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return plVar13;
    }
    (*_DAT_)(1,0x1a43ed0,0x1a71748,0x4be,0x163f078);
    lVar17 = lStack_9d0;
    iVar10 = iStack_9d8;
  }
  else {
    lVar17 = param_3[0x1a];
    if (((uStack_958 & 1) != 0) || (cVar7 = (**(code **)*param_3)(param_3), cVar7 != '\0'))
    goto LAB_;
    cVar7 = (**(code **)(*param_3 + 0x88))(param_3);
    if (cVar7 != '\0') {
      if ((uStack_958._1_1_ != '\0') ||
         ((lVar17 == 0 && (cVar7 = (**(code **)(*param_3 + 0x18))(param_3), cVar7 == '\0'))))
      goto LAB_;
      if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
        if ((*(byte *)(param_3 + 0x4a) & 0x5a) == 0) {
          if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
            if (((param_3[0x1a] == 0) &&
                (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0')) &&
               (cVar7 = (**(code **)(*param_3 + 0x18))(param_3), cVar7 == '\0')) {
              *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
            }
            else {
              iVar10 = func_0x(param_3);
              if (iVar10 == 0) {
                (**(code **)(*param_3 + 0x270))(param_3);
              }
              if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                if ((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
                    (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
                   ((*(char *)(param_3[0x1a] + 0x130) == '\0' &&
                    (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')))) {
                  plVar12 = plVar13;
                  if (_DAT_ != 0) {
                    plVar12 = (longlong *)(_DAT_ + 0xe000);
                  }
                  if ((plVar12 != (longlong *)0x0) && (*plVar12 != 0)) {
                    LOCK();
                    plVar12 = (longlong *)(*plVar12 + 0x10);
                    *plVar12 = *plVar12 + 1;
                    UNLOCK();
                  }
                }
                uVar11 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
              }
              else {
                uVar14 = (**(code **)(*param_3 + 0x1e8))(param_3);
                uVar11 = func_0x(uVar14);
              }
              if (uVar11 != 0) goto LAB_;
            }
          }
        }
        else {
LAB_:
          if (((*(byte *)(param_3 + 0x4a) & 0x40) != 0) && (uStack_958._2_1_ != '\0'))
          goto LAB_;
        }
      }
    }
    lVar15 = CONCAT44(uStack_94c,uStack_950);
    if ((uVar20 & 0x1c) == 0) {
      if (lVar15 != 0) {
        iVar10 = func_0x(lVar15);
        if (((iVar10 != 0) && (iVar10 = *(int *)(*(longlong *)(lVar15 + 8) + 0x100), iVar10 != 0))
           && (1 < iVar10 - 3U)) {
          (*_DAT_)(1,0x1a71540,0x1a71590,0x116,0);
        }
        iVar10 = func_0x(lVar15);
        if (((iVar10 != 0) && ((*(byte *)(*(longlong *)(lVar15 + 8) + 0x109) & 1) == 0)) &&
           ((iVar10 = *(int *)(*(longlong *)(lVar15 + 8) + 0x100), iVar10 != 0 && (1 < iVar10 - 3U))
           )) {
          (*_DAT_)(1,0x1a715c0,0x1a71590,0x119,0);
        }
      }
      if ((lVar17 != 0) && ((0 < *(int *)(lVar17 + 0x78) || (0 < *(int *)(lVar17 + 0x74))))) {
LAB_:
        if (lVar15 != 0) {
          iVar10 = func_0x(lVar15);
          if (((iVar10 != 0) && (iVar10 = *(int *)(*(longlong *)(lVar15 + 8) + 0x100), iVar10 != 0))
             && (1 < iVar10 - 3U)) {
            (*_DAT_)(1,0x1a71540,0x1a71590,0x116,0);
          }
          iVar10 = func_0x(lVar15);
          if (((iVar10 != 0) && ((*(byte *)(*(longlong *)(lVar15 + 8) + 0x109) & 1) == 0)) &&
             ((iVar10 = *(int *)(*(longlong *)(lVar15 + 8) + 0x100), iVar10 != 0 &&
              (1 < iVar10 - 3U)))) {
            (*_DAT_)(1,0x1a715c0,0x1a71590,0x119,0);
          }
        }
        if ((*(int *)(lVar17 + 0x78) < 1) && (*(int *)(lVar17 + 0x74) < 1)) {
          if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
            if ((*(byte *)(param_3 + 0x4a) & 0x5a) == 0) {
              if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
                if (((param_3[0x1a] == 0) &&
                    (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0')) &&
                   (cVar7 = (**(code **)(*param_3 + 0x18))(param_3), cVar7 == '\0')) {
                  *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                }
                else {
                  iVar10 = func_0x(param_3);
                  if (iVar10 == 0) {
                    (**(code **)(*param_3 + 0x270))(param_3);
                  }
                  if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                    if ((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
                        (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
                       ((*(char *)(param_3[0x1a] + 0x130) == '\0' &&
                        (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')))) {
                      plVar12 = plVar13;
                      if (_DAT_ != 0) {
                        plVar12 = (longlong *)(_DAT_ + 0xe000);
                      }
                      if ((plVar12 != (longlong *)0x0) && (*plVar12 != 0)) {
                        LOCK();
                        plVar12 = (longlong *)(*plVar12 + 0x10);
                        *plVar12 = *plVar12 + 1;
                        UNLOCK();
                      }
                    }
                    uVar11 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    uVar14 = (**(code **)(*param_3 + 0x1e8))(param_3);
                    uVar11 = func_0x(uVar14);
                  }
                  if (uVar11 != 0) goto LAB_;
                }
              }
            }
            else {
LAB_:
              if ((*(byte *)(param_3 + 0x4a) & 0x10) != 0) goto LAB_;
            }
          }
          if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
            if ((*(byte *)(param_3 + 0x4a) & 0x5a) == 0) {
              if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
                if (((param_3[0x1a] == 0) &&
                    (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0')) &&
                   (cVar7 = (**(code **)(*param_3 + 0x18))(param_3), cVar7 == '\0')) {
                  *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                }
                else {
                  iVar10 = func_0x(param_3);
                  if (iVar10 == 0) {
                    (**(code **)(*param_3 + 0x270))(param_3);
                  }
                  if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                    if ((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
                        (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
                       ((*(char *)(param_3[0x1a] + 0x130) == '\0' &&
                        (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')))) {
                      plVar12 = plVar13;
                      if (_DAT_ != 0) {
                        plVar12 = (longlong *)(_DAT_ + 0xe000);
                      }
                      if ((plVar12 != (longlong *)0x0) && (*plVar12 != 0)) {
                        LOCK();
                        plVar12 = (longlong *)(*plVar12 + 0x10);
                        *plVar12 = *plVar12 + 1;
                        UNLOCK();
                      }
                    }
                    uVar11 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    uVar14 = (**(code **)(*param_3 + 0x1e8))(param_3);
                    uVar11 = func_0x(uVar14);
                  }
                  if (uVar11 != 0) goto LAB_;
                }
              }
            }
            else {
LAB_:
              if ((*(byte *)(param_3 + 0x4a) & 0x40) != 0) goto LAB_;
            }
          }
        }
        goto LAB_;
      }
      if ((*(byte *)(param_3 + 0x4a) & 4) != 0) goto LAB_;
      if ((*(byte *)(param_3 + 0x4a) & 0x5a) != 0) goto LAB_;
      if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
        if (((param_3[0x1a] == 0) &&
            (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0')) &&
           (cVar7 = (**(code **)(*param_3 + 0x18))(param_3), cVar7 == '\0')) goto LAB_;
        iVar10 = func_0x(param_3);
        if (iVar10 == 0) {
          (**(code **)(*param_3 + 0x270))(param_3);
        }
        if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
          if ((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
              (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
             ((*(char *)(param_3[0x1a] + 0x130) == '\0' &&
              (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')))) {
            plVar12 = plVar13;
            if (_DAT_ != 0) {
              plVar12 = (longlong *)(_DAT_ + 0xe000);
            }
            if ((plVar12 != (longlong *)0x0) && (*plVar12 != 0)) {
              LOCK();
              plVar12 = (longlong *)(*plVar12 + 0x10);
              *plVar12 = *plVar12 + 1;
              UNLOCK();
            }
          }
          uVar11 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
        }
        else {
          uVar14 = (**(code **)(*param_3 + 0x1e8))(param_3);
          uVar11 = func_0x(uVar14);
        }
        if (uVar11 != 0) goto LAB_;
      }
LAB_:
      bVar5 = false;
    }
    else {
LAB_:
      if (lVar17 != 0) {
        if ((uVar20 & 0x1c) == 0) goto LAB_;
LAB_:
        func_0x(lVar17,0);
      }
LAB_:
      iVar10 = func_0x(param_3);
      if (iVar10 == 0) {
        (**(code **)(*param_3 + 0x270))(param_3);
      }
      lVar17 = param_3[0x1a];
      if ((uVar20 & 0x24) == 0) {
        if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
          if ((*(byte *)(param_3 + 0x4a) & 0x5a) != 0) goto LAB_;
          if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
            if (((lVar17 == 0) && (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0'))
               && (cVar7 = (**(code **)(*param_3 + 0x18))(param_3), cVar7 == '\0')) {
LAB_:
              *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
              goto LAB_;
            }
            iVar10 = func_0x(param_3);
            if (iVar10 == 0) {
              (**(code **)(*param_3 + 0x270))(param_3);
            }
            if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
              if ((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
                  (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
                 ((*(char *)(param_3[0x1a] + 0x130) == '\0' &&
                  (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')))) {
                plVar12 = plVar13;
                if (_DAT_ != 0) {
                  plVar12 = (longlong *)(_DAT_ + 0xe000);
                }
                if ((plVar12 != (longlong *)0x0) && (*plVar12 != 0)) {
                  LOCK();
                  plVar12 = (longlong *)(*plVar12 + 0x10);
                  *plVar12 = *plVar12 + 1;
                  UNLOCK();
                }
              }
              uVar20 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
            }
            else {
              uVar14 = (**(code **)(*param_3 + 0x1e8))(param_3);
              uVar20 = func_0x(uVar14);
            }
            if (uVar20 != 0) goto LAB_;
          }
        }
        if ((lVar17 == 0) || (*(int *)(lVar17 + 0x74) < 1)) goto LAB_;
      }
LAB_:
      iStack_a18 = 0xe;
      lVar17 = param_3[0x1a];
      if ((((param_6 == 0) &&
           (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), psVar6 = psStack_9c0, cVar7 == '\0'))
          && (lVar17 != 0)) && ((0 < *(int *)(lVar17 + 0x78) || (0 < *(int *)(lVar17 + 0x74))))) {
        puVar1 = (ushort *)(psStack_9c0 + 1);
        if (*psStack_9c0 == 0) {
          if (*(int *)(psStack_9c0 + 2) == 0) {
            *puVar1 = 0;
            uVar20 = *(uint *)(psStack_9c0 + 8);
            uVar18 = (ulonglong)uVar20;
            *(uint *)(psStack_9c0 + 10) = uVar20;
            pbVar24 = *(byte **)(psStack_9c0 + 4);
            bVar8 = *pbVar24;
            if ((bVar8 & 0x10) != 0) {
              uVar20 = uVar20 + 2 + (*(ushort *)(pbVar24 + uVar18) + 7 >> 3);
              uVar18 = (ulonglong)uVar20;
              *(uint *)(psStack_9c0 + 10) = uVar20;
              bVar8 = *pbVar24;
            }
            if ((bVar8 & 0x20) == 0) {
              *(int *)(psStack_9c0 + 2) = (int)uVar18;
              psStack_9c0[0xe] = 0;
              *(int *)(psStack_9c0 + 0xc) = (int)uVar18;
            }
            else {
              puVar25 = (ushort *)(pbVar24 + uVar18);
              uVar9 = *puVar25;
              psStack_9c0[0xe] = uVar9;
              if (uVar9 == 0) {
                cVar7 = func_0x(0x1fd1e10);
                if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                   (*(char *)(lVar17 + 0x499) != '\0')) {
                  cVar7 = func_0x(0x1fd1e10);
                  if (cVar7 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    (*_DAT_)(1,0x18c2b98,0x19e2868,0x80f,0);
                  }
                }
                func_0x(*(undefined8 *)(psVar6 + 4),3);
                uVar9 = psVar6[0xe];
                uVar18 = (ulonglong)*(uint *)(psVar6 + 10);
              }
              uVar20 = (int)uVar18 + (uVar9 + 1) * 2;
              *(uint *)(psVar6 + 0xc) = uVar20;
              if (0x1f9e < uVar20) {
                cVar7 = func_0x(0x1fd1e10);
                if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                   (*(char *)(lVar17 + 0x499) != '\0')) {
                  cVar7 = func_0x(0x1fd1e10);
                  if (cVar7 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x18c2b98,0x19e2868,0x816,0);
                  }
                }
                func_0x(*(undefined8 *)(psVar6 + 4),4);
                uVar9 = psVar6[0xe];
                uVar20 = *(uint *)(psVar6 + 0xc);
              }
              uVar11 = puVar25[uVar9] & 0x7fff;
              *(uint *)(psVar6 + 2) = uVar11;
              if (uVar11 < uVar20) {
                cVar7 = func_0x(0x1fd1e10);
                if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                   (*(char *)(lVar17 + 0x499) != '\0')) {
                  cVar7 = func_0x(0x1fd1e10);
                  if (cVar7 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x18c2b98,0x19e2868,0x81d,0);
                  }
                }
                func_0x(*(undefined8 *)(psVar6 + 4),4);
                uVar9 = psVar6[0xe];
                uVar11 = *(uint *)(psVar6 + 2);
              }
              uVar18 = (ulonglong)uVar11;
              if ((short)puVar25[(ulonglong)(uVar9 - 1) + 1] < 0) {
                pbVar24 = *(byte **)(psVar6 + 4);
                do {
                  uVar18 = (ulonglong)uVar9;
                  uVar20 = *(uint *)(psVar6 + 10);
                  if (uVar9 == 1) {
                    uVar11 = *(uint *)(psVar6 + 0xc);
                    uVar9 = *(ushort *)(pbVar24 + uVar18 * 2 + (ulonglong)uVar20);
                    uVar16 = uVar11;
LAB_:
                    if ((uVar9 & 0x7fff) < uVar11) goto LAB_;
                  }
                  else {
                    uVar11 = *(ushort *)(pbVar24 + uVar18 * 2 + ((ulonglong)uVar20 - 2)) & 0x7fff;
                    uVar16 = *(uint *)(psVar6 + 0xc);
                    uVar9 = *(ushort *)(pbVar24 + uVar18 * 2 + (ulonglong)uVar20);
                    if (uVar16 <= uVar11) goto LAB_;
LAB_:
                    func_0x(pbVar24,7);
                    uVar16 = *(uint *)(psVar6 + 0xc);
                  }
                  if ((uVar11 < uVar16) ||
                     (uVar18 = (ulonglong)*(uint *)(psVar6 + 2), *(uint *)(psVar6 + 2) < uVar11))
                  goto LAB_;
                  pbVar24 = *(byte **)(psVar6 + 4);
                  if (*(ushort *)(pbVar24 + uVar11) == 5) {
                    *puVar1 = *puVar1 | 2;
                    psVar6[0xe] = psVar6[0xe] + -1;
                    uVar20 = uVar11 & 0xffff;
                    psVar6[0x15] = (short)uVar11;
                    uVar9 = psVar6[0x16] & 0xc7ffU;
                    if ((*(ushort *)(pbVar24 + (ulonglong)uVar20 + 2) >> 0xe & 1) != 0) {
                      uVar9 = *(ushort *)(pbVar24 + (ulonglong)uVar20 + 2) & 0x3800 |
                              psVar6[0x16] & 0xc7ffU;
                    }
                    psVar6[0x16] = uVar9;
                    psVar6[0x16] = (uVar9 ^ *(ushort *)(pbVar24 + (ulonglong)uVar20 + 2)) & 0x7ff ^
                                   uVar9;
                    uVar18 = (ulonglong)*(uint *)(psVar6 + 2);
                    goto LAB_;
                  }
                  if (*(ushort *)(pbVar24 + uVar11) < 0x400) goto LAB_;
                  *puVar1 = *puVar1 | 1;
                  uVar9 = psVar6[0xe] - 1;
                  psVar6[0xe] = uVar9;
                  if (uVar9 == 0) goto LAB_;
                } while ((short)puVar25[(ulonglong)(uVar9 - 1) + 1] < 0);
              }
              else {
LAB_:
                pbVar24 = *(byte **)(psVar6 + 4);
              }
            }
            if ((*pbVar24 & 0x40) == 0) {
              *(undefined4 *)(psVar6 + 0x13) = 0;
            }
            else {
              *(int *)(psVar6 + 0x13) = (int)uVar18;
              *(int *)(psVar6 + 2) = (int)uVar18 + 0xe;
              uVar14 = func_0x(puVar1);
              func_0x(uVar14,auStack_938);
              iVar10 = func_0x(auStack_938);
              *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar10;
              uVar18 = (ulonglong)*(uint *)(psVar6 + 2);
            }
            iVar10 = (int)uVar18;
            if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
               (*(ulonglong *)(psVar6 + 0xf) < uVar18 + *(longlong *)(psVar6 + 4))) {
              cVar7 = func_0x(0x1fd1e10);
              if ((cVar7 != '\0') &&
                 ((lVar17 = func_0x(), lVar17 != 0 &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x877,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),0x12);
              iVar10 = *(int *)(psVar6 + 2);
            }
            if (0x3f3b < iVar10 - 1U) {
              cVar7 = func_0x(0x1fd1e10);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x87c,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),5);
            }
          }
LAB_:
          uVar20 = *(uint *)(psVar6 + 2);
          if ((uVar20 < 9) &&
             (((**(byte **)(psVar6 + 4) & 0xe) == 0 || ((**(byte **)(psVar6 + 4) & 0xe) == 0xc)))) {
            uVar20 = 9;
          }
        }
        else {
          uVar20 = func_0x(puVar1);
        }
        iStack_a18 = 0xe;
        if (uVar20 < 0x1f74) {
          iStack_a18 = 0x16;
        }
      }
      bVar5 = true;
    }
    psVar6 = psStack_9c0;
    if ((param_6 == 0) || (param_6 == 1)) {
      puVar1 = (ushort *)(psStack_9c0 + 1);
      psVar26 = psVar6;
      if (*psStack_9c0 == 0) {
        if (*(int *)(psStack_9c0 + 2) == 0) {
          *puVar1 = 0;
          uVar20 = *(uint *)(psStack_9c0 + 8);
          uVar18 = (ulonglong)uVar20;
          *(uint *)(psStack_9c0 + 10) = uVar20;
          pbVar24 = *(byte **)(psStack_9c0 + 4);
          bVar8 = *pbVar24;
          if ((bVar8 & 0x10) != 0) {
            uVar20 = uVar20 + 2 + (*(ushort *)(pbVar24 + uVar18) + 7 >> 3);
            uVar18 = (ulonglong)uVar20;
            *(uint *)(psStack_9c0 + 10) = uVar20;
            bVar8 = *pbVar24;
          }
          if ((bVar8 & 0x20) == 0) {
            *(int *)(psStack_9c0 + 2) = (int)uVar18;
            psStack_9c0[0xe] = 0;
            *(int *)(psStack_9c0 + 0xc) = (int)uVar18;
          }
          else {
            puVar25 = (ushort *)(pbVar24 + uVar18);
            uVar9 = *puVar25;
            psStack_9c0[0xe] = uVar9;
            if (uVar9 == 0) {
              cVar7 = func_0x(0x1fd1e10);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),3);
              uVar9 = psVar6[0xe];
              uVar18 = (ulonglong)*(uint *)(psVar6 + 10);
            }
            uVar20 = (int)uVar18 + (uVar9 + 1) * 2;
            *(uint *)(psVar6 + 0xc) = uVar20;
            if (0x1f9e < uVar20) {
              cVar7 = func_0x(0x1fd1e10);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar9 = psVar6[0xe];
              uVar20 = *(uint *)(psVar6 + 0xc);
            }
            uVar11 = puVar25[uVar9] & 0x7fff;
            *(uint *)(psVar6 + 2) = uVar11;
            if (uVar11 < uVar20) {
              cVar7 = func_0x(0x1fd1e10);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar9 = psVar6[0xe];
              uVar11 = *(uint *)(psVar6 + 2);
            }
            uVar18 = (ulonglong)uVar11;
            if ((short)puVar25[(ulonglong)(uVar9 - 1) + 1] < 0) {
              pbVar24 = *(byte **)(psVar6 + 4);
              do {
                uVar18 = (ulonglong)uVar9;
                uVar20 = *(uint *)(psVar6 + 10);
                if (uVar9 == 1) {
                  uVar11 = *(uint *)(psVar6 + 0xc);
                  uVar9 = *(ushort *)(pbVar24 + uVar18 * 2 + (ulonglong)uVar20);
                  uVar16 = uVar11;
LAB_:
                  if ((uVar9 & 0x7fff) < uVar11) goto LAB_;
                }
                else {
                  uVar11 = *(ushort *)(pbVar24 + uVar18 * 2 + ((ulonglong)uVar20 - 2)) & 0x7fff;
                  uVar16 = *(uint *)(psVar6 + 0xc);
                  uVar9 = *(ushort *)(pbVar24 + uVar18 * 2 + (ulonglong)uVar20);
                  if (uVar16 <= uVar11) goto LAB_;
LAB_:
                  func_0x(pbVar24,7);
                  uVar16 = *(uint *)(psVar6 + 0xc);
                }
                psVar26 = psStack_9c0;
                if ((uVar11 < uVar16) ||
                   (uVar18 = (ulonglong)*(uint *)(psVar6 + 2), *(uint *)(psVar6 + 2) < uVar11))
                goto LAB_;
                pbVar24 = *(byte **)(psVar6 + 4);
                if (*(ushort *)(pbVar24 + uVar11) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar6[0xe] = psVar6[0xe] + -1;
                  uVar20 = uVar11 & 0xffff;
                  psVar6[0x15] = (short)uVar11;
                  uVar9 = psVar6[0x16] & 0xc7ffU;
                  if ((*(ushort *)(pbVar24 + (ulonglong)uVar20 + 2) >> 0xe & 1) != 0) {
                    uVar9 = *(ushort *)(pbVar24 + (ulonglong)uVar20 + 2) & 0x3800 |
                            psVar6[0x16] & 0xc7ffU;
                  }
                  psVar6[0x16] = uVar9;
                  psVar6[0x16] = (uVar9 ^ *(ushort *)(pbVar24 + (ulonglong)uVar20 + 2)) & 0x7ff ^
                                 uVar9;
                  uVar18 = (ulonglong)*(uint *)(psVar6 + 2);
                  goto LAB_;
                }
                if (*(ushort *)(pbVar24 + uVar11) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar9 = psVar6[0xe] - 1;
                psVar6[0xe] = uVar9;
                if (uVar9 == 0) goto LAB_;
              } while ((short)puVar25[(ulonglong)(uVar9 - 1) + 1] < 0);
            }
            else {
LAB_:
              pbVar24 = *(byte **)(psVar6 + 4);
            }
          }
          if ((*pbVar24 & 0x40) == 0) {
            *(undefined4 *)(psVar6 + 0x13) = 0;
          }
          else {
            *(int *)(psVar6 + 0x13) = (int)uVar18;
            *(int *)(psVar6 + 2) = (int)uVar18 + 0xe;
            uVar14 = func_0x(puVar1);
            func_0x(uVar14,auStack_920);
            iVar10 = func_0x(auStack_920);
            *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar10;
            uVar18 = (ulonglong)*(uint *)(psVar6 + 2);
          }
          iVar10 = (int)uVar18;
          if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
             (*(ulonglong *)(psVar6 + 0xf) < uVar18 + *(longlong *)(psVar6 + 4))) {
            cVar7 = func_0x(0x1fd1e10);
            if ((cVar7 != '\0') &&
               ((lVar17 = func_0x(), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x1fd1e10);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x18c2b98,0x19e2868,0x877,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),0x12);
            iVar10 = *(int *)(psVar6 + 2);
          }
          psVar26 = psStack_9c0;
          if (0x3f3b < iVar10 - 1U) {
            cVar7 = func_0x(0x1fd1e10);
            if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
               (*(char *)(lVar17 + 0x499) != '\0')) {
              cVar7 = func_0x(0x1fd1e10);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x18c2b98,0x19e2868,0x87c,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),5);
            psVar26 = psStack_9c0;
          }
        }
      }
      else {
        func_0x(puVar1);
      }
LAB_:
      if ((((param_6 == 1) && (sVar3 == 0)) &&
          ((iStack_9b8 == iStack_988 && ((bVar5 && (param_12 == 0)))))) &&
         (cVar7 = (**(code **)(*param_3 + 0x20))(param_3), cVar7 != '\0')) {
        iStack_a18 = 0x22;
      }
      lVar17 = lStack_9d0;
      if (*psVar26 == 0) {
        if (*(int *)(psVar6 + 2) == 0) {
          *puVar1 = 0;
          uVar20 = *(uint *)(psVar6 + 8);
          uVar18 = (ulonglong)uVar20;
          *(uint *)(psVar6 + 10) = uVar20;
          pbVar24 = *(byte **)(psVar6 + 4);
          bVar8 = *pbVar24;
          if ((bVar8 & 0x10) != 0) {
            uVar20 = uVar20 + 2 + (*(ushort *)(pbVar24 + uVar18) + 7 >> 3);
            uVar18 = (ulonglong)uVar20;
            *(uint *)(psVar6 + 10) = uVar20;
            bVar8 = *pbVar24;
          }
          if ((bVar8 & 0x20) == 0) {
            *(int *)(psVar6 + 2) = (int)uVar18;
            psVar6[0xe] = 0;
            *(int *)(psVar6 + 0xc) = (int)uVar18;
          }
          else {
            puVar25 = (ushort *)(pbVar24 + uVar18);
            uVar9 = *puVar25;
            psVar6[0xe] = uVar9;
            if (uVar9 == 0) {
              cVar7 = func_0x(0x1fd1e10);
              if (((cVar7 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                 (*(char *)(lVar15 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),3);
              uVar9 = psVar6[0xe];
              uVar18 = (ulonglong)*(uint *)(psVar6 + 10);
            }
            uVar20 = (int)uVar18 + (uVar9 + 1) * 2;
            *(uint *)(psVar6 + 0xc) = uVar20;
            if (0x1f9e < uVar20) {
              cVar7 = func_0x(0x1fd1e10);
              if (((cVar7 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                 (*(char *)(lVar15 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar9 = psVar6[0xe];
              uVar20 = *(uint *)(psVar6 + 0xc);
            }
            uVar11 = puVar25[uVar9] & 0x7fff;
            *(uint *)(psVar6 + 2) = uVar11;
            if (uVar11 < uVar20) {
              cVar7 = func_0x(0x1fd1e10);
              if (((cVar7 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                 (*(char *)(lVar15 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar9 = psVar6[0xe];
              uVar11 = *(uint *)(psVar6 + 2);
            }
            uVar18 = (ulonglong)uVar11;
            if ((short)puVar25[(ulonglong)(uVar9 - 1) + 1] < 0) {
              pbVar24 = *(byte **)(psVar6 + 4);
              do {
                uVar18 = (ulonglong)uVar9;
                uVar20 = *(uint *)(psVar6 + 10);
                if (uVar9 == 1) {
                  uVar11 = *(uint *)(psVar6 + 0xc);
                  uVar9 = *(ushort *)(pbVar24 + uVar18 * 2 + (ulonglong)uVar20);
                  uVar16 = uVar11;
LAB_:
                  if ((uVar9 & 0x7fff) < uVar11) goto LAB_;
                }
                else {
                  uVar11 = *(ushort *)(pbVar24 + uVar18 * 2 + ((ulonglong)uVar20 - 2)) & 0x7fff;
                  uVar16 = *(uint *)(psVar6 + 0xc);
                  uVar9 = *(ushort *)(pbVar24 + uVar18 * 2 + (ulonglong)uVar20);
                  if (uVar16 <= uVar11) goto LAB_;
LAB_:
                  func_0x(pbVar24,7);
                  uVar16 = *(uint *)(psVar6 + 0xc);
                }
                if ((uVar11 < uVar16) ||
                   (uVar18 = (ulonglong)*(uint *)(psVar6 + 2), *(uint *)(psVar6 + 2) < uVar11))
                goto LAB_;
                pbVar24 = *(byte **)(psVar6 + 4);
                if (*(ushort *)(pbVar24 + uVar11) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar6[0xe] = psVar6[0xe] + -1;
                  uVar20 = uVar11 & 0xffff;
                  psVar6[0x15] = (short)uVar11;
                  uVar9 = psVar6[0x16] & 0xc7ffU;
                  if ((*(ushort *)(pbVar24 + (ulonglong)uVar20 + 2) >> 0xe & 1) != 0) {
                    uVar9 = *(ushort *)(pbVar24 + (ulonglong)uVar20 + 2) & 0x3800 |
                            psVar6[0x16] & 0xc7ffU;
                  }
                  psVar6[0x16] = uVar9;
                  psVar6[0x16] = (uVar9 ^ *(ushort *)(pbVar24 + (ulonglong)uVar20 + 2)) & 0x7ff ^
                                 uVar9;
                  uVar18 = (ulonglong)*(uint *)(psVar6 + 2);
                  goto LAB_;
                }
                if (*(ushort *)(pbVar24 + uVar11) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar9 = psVar6[0xe] - 1;
                psVar6[0xe] = uVar9;
                if (uVar9 == 0) goto LAB_;
              } while ((short)puVar25[(ulonglong)(uVar9 - 1) + 1] < 0);
            }
            else {
LAB_:
              pbVar24 = *(byte **)(psVar6 + 4);
            }
          }
          if ((*pbVar24 & 0x40) == 0) {
            *(undefined4 *)(psVar6 + 0x13) = 0;
          }
          else {
            *(int *)(psVar6 + 0x13) = (int)uVar18;
            *(int *)(psVar6 + 2) = (int)uVar18 + 0xe;
            uVar14 = func_0x(puVar1);
            func_0x(uVar14,auStack_918);
            iVar10 = func_0x(auStack_918);
            *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar10;
            uVar18 = (ulonglong)*(uint *)(psVar6 + 2);
          }
          iVar10 = (int)uVar18;
          if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
             (*(ulonglong *)(psVar6 + 0xf) < uVar18 + *(longlong *)(psVar6 + 4))) {
            cVar7 = func_0x(0x1fd1e10);
            if ((cVar7 != '\0') &&
               ((lVar15 = func_0x(), lVar15 != 0 &&
                (*(char *)(lVar15 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x1fd1e10);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x18c2b98,0x19e2868,0x877,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),0x12);
            iVar10 = *(int *)(psVar6 + 2);
          }
          if (0x3f3b < iVar10 - 1U) {
            cVar7 = func_0x(0x1fd1e10);
            if (((cVar7 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
               (*(char *)(lVar15 + 0x499) != '\0')) {
              cVar7 = func_0x(0x1fd1e10);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x18c2b98,0x19e2868,0x87c,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),5);
          }
        }
LAB_:
        if ((*(uint *)(psVar6 + 2) < 9) &&
           (((**(byte **)(psVar6 + 4) & 0xe) == 0 || ((**(byte **)(psVar6 + 4) & 0xe) == 0xc)))) {
          iVar10 = iStack_a18 + 9;
        }
        else {
          iVar10 = iStack_a18 + *(uint *)(psVar6 + 2);
        }
      }
      else {
        iVar10 = func_0x(puVar1);
        iVar10 = iVar10 + iStack_a18;
      }
    }
    else if (param_6 == 2) {
      if (param_10 == (uint *)0x0) {
        puVar1 = (ushort *)(psStack_9c0 + 1);
        if (*psStack_9c0 == 0) {
          if (*(int *)(psStack_9c0 + 2) == 0) {
            *puVar1 = 0;
            uVar20 = *(uint *)(psStack_9c0 + 8);
            uVar18 = (ulonglong)uVar20;
            *(uint *)(psStack_9c0 + 10) = uVar20;
            pbVar24 = *(byte **)(psStack_9c0 + 4);
            bVar8 = *pbVar24;
            if ((bVar8 & 0x10) != 0) {
              uVar20 = uVar20 + 2 + (*(ushort *)(pbVar24 + uVar18) + 7 >> 3);
              uVar18 = (ulonglong)uVar20;
              *(uint *)(psStack_9c0 + 10) = uVar20;
              bVar8 = *pbVar24;
            }
            if ((bVar8 & 0x20) == 0) {
              *(int *)(psStack_9c0 + 2) = (int)uVar18;
              psStack_9c0[0xe] = 0;
              *(int *)(psStack_9c0 + 0xc) = (int)uVar18;
            }
            else {
              puVar25 = (ushort *)(pbVar24 + uVar18);
              uVar9 = *puVar25;
              psStack_9c0[0xe] = uVar9;
              if (uVar9 == 0) {
                cVar7 = func_0x(0x1fd1e10);
                if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                   (*(char *)(lVar17 + 0x499) != '\0')) {
                  cVar7 = func_0x(0x1fd1e10);
                  if (cVar7 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    (*_DAT_)(1,0x18c2b98,0x19e2868,0x80f,0);
                  }
                }
                func_0x(*(undefined8 *)(psVar6 + 4),3);
                uVar9 = psVar6[0xe];
                uVar18 = (ulonglong)*(uint *)(psVar6 + 10);
                pbVar24 = *(byte **)(psVar6 + 4);
              }
              uVar20 = (int)uVar18 + (uVar9 + 1) * 2;
              *(uint *)(psVar6 + 0xc) = uVar20;
              if (0x1f9e < uVar20) {
                cVar7 = func_0x(0x1fd1e10);
                if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                   (*(char *)(lVar17 + 0x499) != '\0')) {
                  cVar7 = func_0x(0x1fd1e10);
                  if (cVar7 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x18c2b98,0x19e2868,0x816,0);
                  }
                }
                func_0x(*(undefined8 *)(psVar6 + 4),4);
                uVar9 = psVar6[0xe];
                uVar20 = *(uint *)(psVar6 + 0xc);
                pbVar24 = *(byte **)(psVar6 + 4);
              }
              uVar11 = puVar25[uVar9] & 0x7fff;
              *(uint *)(psVar6 + 2) = uVar11;
              if (uVar11 < uVar20) {
                cVar7 = func_0x(0x1fd1e10);
                if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                   (*(char *)(lVar17 + 0x499) != '\0')) {
                  cVar7 = func_0x(0x1fd1e10);
                  if (cVar7 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x18c2b98,0x19e2868,0x81d,0);
                  }
                }
                func_0x(*(undefined8 *)(psVar6 + 4),4);
                uVar9 = psVar6[0xe];
                pbVar24 = *(byte **)(psVar6 + 4);
                uVar11 = *(uint *)(psVar6 + 2);
              }
              uVar18 = (ulonglong)uVar11;
              if ((short)puVar25[(ulonglong)(uVar9 - 1) + 1] < 0) {
                do {
                  uVar18 = (ulonglong)uVar9;
                  uVar20 = *(uint *)(psVar6 + 10);
                  if (uVar9 == 1) {
                    uVar11 = *(uint *)(psVar6 + 0xc);
                    uVar9 = *(ushort *)(pbVar24 + uVar18 * 2 + (ulonglong)uVar20);
                    uVar16 = uVar11;
LAB_:
                    if ((uVar9 & 0x7fff) < uVar11) goto LAB_;
                  }
                  else {
                    uVar11 = *(ushort *)(pbVar24 + uVar18 * 2 + ((ulonglong)uVar20 - 2)) & 0x7fff;
                    uVar16 = *(uint *)(psVar6 + 0xc);
                    uVar9 = *(ushort *)(pbVar24 + uVar18 * 2 + (ulonglong)uVar20);
                    if (uVar16 <= uVar11) goto LAB_;
LAB_:
                    func_0x(pbVar24,7);
                    uVar16 = *(uint *)(psVar6 + 0xc);
                    pbVar24 = *(byte **)(psVar6 + 4);
                  }
                  if ((uVar11 < uVar16) ||
                     (uVar18 = (ulonglong)*(uint *)(psVar6 + 2), *(uint *)(psVar6 + 2) < uVar11))
                  goto LAB_;
                  if (*(ushort *)(pbVar24 + uVar11) == 5) {
                    *puVar1 = *puVar1 | 2;
                    psVar6[0xe] = psVar6[0xe] + -1;
                    psVar6[0x15] = (short)uVar11;
                    lVar17 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(psVar6 + 4);
                    uVar9 = psVar6[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar17 + 2) >> 0xe & 1) != 0) {
                      uVar9 = *(ushort *)(lVar17 + 2) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                    }
                    psVar6[0x16] = uVar9;
                    psVar6[0x16] = (uVar9 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar9;
                    uVar18 = (ulonglong)*(uint *)(psVar6 + 2);
                    goto LAB_;
                  }
                  if (*(ushort *)(pbVar24 + uVar11) < 0x400) goto LAB_;
                  *puVar1 = *puVar1 | 1;
                  uVar9 = psVar6[0xe] - 1;
                  psVar6[0xe] = uVar9;
                  if (uVar9 == 0) goto LAB_;
                } while ((short)puVar25[(ulonglong)(uVar9 - 1) + 1] < 0);
                pbVar24 = *(byte **)(psVar6 + 4);
              }
              else {
LAB_:
                pbVar24 = *(byte **)(psVar6 + 4);
              }
            }
            if ((*pbVar24 & 0x40) == 0) {
              *(undefined4 *)(psVar6 + 0x13) = 0;
            }
            else {
              *(int *)(psVar6 + 0x13) = (int)uVar18;
              *(int *)(psVar6 + 2) = (int)uVar18 + 0xe;
              uVar14 = func_0x(puVar1);
              func_0x(uVar14,auStack_928);
              iVar10 = func_0x(auStack_928);
              *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar10;
              uVar18 = (ulonglong)*(uint *)(psVar6 + 2);
              pbVar24 = *(byte **)(psVar6 + 4);
            }
            iVar10 = (int)uVar18;
            if ((*(byte **)(psVar6 + 0xf) != (byte *)0x0) &&
               (*(byte **)(psVar6 + 0xf) < pbVar24 + uVar18)) {
              cVar7 = func_0x(0x1fd1e10);
              if ((cVar7 != '\0') &&
                 ((lVar17 = func_0x(), lVar17 != 0 &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x877,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),0x12);
              iVar10 = *(int *)(psVar6 + 2);
            }
            if (0x3f3b < iVar10 - 1U) {
              cVar7 = func_0x(0x1fd1e10);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1fd1e10);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  (*_DAT_)(1,0x18c2b98,0x19e2868,0x87c,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),5);
            }
          }
LAB_:
          uVar20 = *(uint *)(psVar6 + 2);
          if (uVar20 < 9) {
            bVar8 = **(byte **)(psVar6 + 4);
            if (((bVar8 & 0xe) != 0) && ((bVar8 & 0xe) != 0xc)) goto LAB_;
            uVar20 = 9;
          }
          else {
LAB_:
            bVar8 = **(byte **)(psVar6 + 4);
          }
          if ((bVar8 & 0x40) != 0) {
            uVar20 = *(uint *)(psVar6 + 0x13);
          }
        }
        else {
          if (*(int *)(psStack_9c0 + 2) == 0) {
            func_0x(puVar1);
          }
          uVar20 = func_0x(puVar1);
          if ((**(byte **)(psVar6 + 4) & 2) != 0) {
            uVar20 = *(uint *)(psVar6 + 0x18);
          }
        }
      }
      else {
        uVar20 = *param_10;
      }
      if ((bVar5) && (cVar7 = (**(code **)(*param_3 + 0x20))(param_3), cVar7 != '\0')) {
        lVar17 = lStack_9d0;
        if (*puStack_980 < 0x15) {
          iVar10 = uVar20 + iStack_a18 + 0x14;
        }
        else {
          if (2000 < uVar20) goto LAB_;
          iVar10 = uVar20 + iStack_a18 + 200;
        }
      }
      else {
LAB_:
        lVar17 = lStack_9d0;
        iVar10 = uVar20 + iStack_a18;
      }
    }
    else if (param_6 == 3) {
      if (iStack_a0c == 0) {
        func_0x(auStack_a0e);
      }
      iVar10 = func_0x(auStack_a0e);
      if ((*pbStack_a08 & 2) == 0) {
        iStack_9e0 = iVar10;
      }
      lVar17 = lStack_9d0;
      iVar10 = iStack_a18 + iStack_9e0;
    }
    else {
      lVar17 = lStack_9d0;
      iVar10 = iStack_9d8;
      if (param_6 != 4) {
        (*_DAT_)(1,0x1a43ed0,0x1a71748,0x52c,0x163f078);
        lVar17 = lStack_9d0;
        iVar10 = iStack_9d8;
      }
    }
  }
  iVar23 = (1 << ((byte)*(undefined2 *)(lVar17 + 4) & 2)) + -1;
  uVar22 = (ushort)iVar23;
  uVar9 = ~uVar22;
  uVar20 = (iVar23 + iVar10 & 0xffffU & (uint)uVar9) + iStack_9ac;
  uVar11 = (uint)((short)uStack_9c8 + uVar22 & uVar9);
  iVar10 = uVar20 - uVar11;
  if (iVar10 == 0) {
    iVar10 = 0;
  }
  *param_14 = iVar10;
  if (uVar20 <= 0x2000U - param_11) {
    uVar20 = 0x2000U - param_11;
  }
  plVar12 = (longlong *)(ulonglong)(uVar20 <= *(ushort *)(lVar17 + 0x1c) + uVar11);
LAB_:
  if (auStack_8d8[0] != 0) {
    puVar19 = auStack_8d0;
    do {
      (*_DAT_)(*puVar19);
      uVar20 = (int)plVar13 + 1;
      plVar13 = (longlong *)(ulonglong)uVar20;
      puVar19 = puVar19 + 1;
    } while ((int)uVar20 < (int)(uint)auStack_8d8[0]);
  }
  if (lStack_7d0 != 0) {
    (*_DAT_)();
  }
  return plVar12;
}

