
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong *param_2,undefined4 param_3,undefined8 param_4)

{
  byte *pbVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  uint uVar11;
  undefined8 unaff_RBX;
  undefined8 uVar12;
  undefined *puVar13;
  undefined *puVar14;
  undefined *puVar15;
  longlong *plVar16;
  longlong *plVar17;
  longlong *plVar18;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_50;
  undefined auStack_48 [8];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  puVar15 = &stack0xffffffffffffffc8 + lVar9;
  puVar13 = &stack0xffffffffffffffc8 + lVar9;
  puVar2 = &stack0x000000b8 + lVar9;
  *(undefined8 *)(&stack0x00000170 + lVar9) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004198 + lVar9) = unaff_RBX;
  *(ulonglong *)(&stack0x00004138 + lVar9) = _DAT_ ^ (ulonglong)puVar2;
  *(undefined8 *)(&stack0x00000128 + lVar9) = param_4;
  *(undefined4 *)(&stack0x00000140 + lVar9) = param_3;
  *(longlong **)(&stack0x00000120 + lVar9) = param_2;
  *(longlong **)(&stack0x00000168 + lVar9) = param_1;
  *(undefined8 *)(&stack0x00000148 + lVar9) = *(undefined8 *)(&stack0x000041a8 + lVar9);
  uVar12 = *(undefined8 *)(&stack0x000041c8 + lVar9);
  *(undefined8 *)(&stack0x000000c8 + lVar9) = uVar12;
  plVar17 = (longlong *)0x0;
  *(undefined8 *)(&stack0x000000c0 + lVar9) = 0;
  *(undefined4 *)(&stack0x000000d8 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000130 + lVar9) = 0;
  *(undefined4 *)(&stack0x000000dc + lVar9) = 0;
  *(undefined8 *)(&stack0x00000158 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000198 + lVar9) = 0;
  *(undefined8 *)(&stack0x000001a0 + lVar9) = 0;
  *(undefined4 *)(&stack0x000001a8 + lVar9) = 0;
  *(undefined8 *)(&stack0x000001b0 + lVar9) = 0;
  *(undefined4 *)(&stack0x000001b8 + lVar9) = 0;
  *(undefined4 *)(&stack0x000000e8 + lVar9) = 1;
  *(undefined4 *)(&stack0x000000f0 + lVar9) = 0;
  *(undefined4 *)(&stack0x000000e0 + lVar9) = 0;
  lVar5 = *param_2;
  *(longlong *)(&stack0x00000160 + lVar9) = lVar5 + 0x78;
  *(undefined8 *)(&stack0x00000150 + lVar9) = 0;
  *(undefined4 *)(&stack0x000000e4 + lVar9) = 0;
  *(undefined4 *)(&stack0x000000f4 + lVar9) = 0;
  lVar10 = *(longlong *)(param_1[3] + 8);
  *(uint *)(&stack0x000000f8 + lVar9) = (uint)*(ushort *)(lVar10 + 0xb8);
  *(uint *)(&stack0x000000fc + lVar9) = (uint)*(ushort *)(lVar10 + 0xcc);
  *(undefined4 *)(&stack0x000000d4 + lVar9) = **(undefined4 **)(lVar5 + 0x80);
  lVar10 = *(longlong *)(lVar5 + 0x80);
  iVar8 = *(int *)(lVar10 + 0x14);
  plVar16 = plVar17;
  if (iVar8 != 0) {
    if ((*(byte *)((longlong)param_1 + 0x34) & 3) != 0) {
      plVar16 = (longlong *)(&stack0x000000a8 + lVar9);
      *(longlong **)(&stack0x00000130 + lVar9) = plVar16;
      uVar11 = iVar8 + 7U >> 3;
      if (uVar11 + 0xf <= uVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined8 *)((longlong)&uStack_50 + lVar9) = 0x10015b;
      lVar10 = func_0x();
      lVar10 = -lVar10;
      puVar13 = auStack_48 + lVar10 + lVar9;
      *plVar16 = (longlong)(&stack0x000000a8 + lVar10 + lVar9);
      *(int *)(&stack0x000000b4 + lVar9) = iVar8;
      *(uint *)(&stack0x000000b0 + lVar9) = uVar11;
      *(undefined8 *)((longlong)&uStack_50 + lVar10 + lVar9) = 0x100177;
      func_0x(&stack0x000000a8 + lVar10 + lVar9,0);
      lVar10 = *(longlong *)(lVar5 + 0x80);
    }
    puVar14 = puVar13;
    plVar18 = plVar17;
    if ((*(byte *)(lVar5 + 0x90) & 1) != 0) {
      plVar18 = (longlong *)(puVar13 + 0xe0);
      *(longlong **)(&stack0x000000c0 + lVar9) = plVar18;
      iVar8 = *(int *)(lVar10 + 0x14);
      uVar11 = iVar8 + 7U >> 3;
      if (uVar11 + 0xf <= uVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined8 *)(puVar13 + -0x18) = 0x1001be;
      lVar10 = func_0x();
      lVar10 = -lVar10;
      puVar14 = puVar13 + lVar10 + -0x10;
      *plVar18 = (longlong)(puVar13 + lVar10 + 0xe0);
      *(int *)(puVar13 + 0xec) = iVar8;
      *(uint *)(puVar13 + 0xe8) = uVar11;
      *(undefined8 *)(puVar13 + lVar10 + -0x18) = 0x1001db;
      func_0x(puVar13 + lVar10 + 0xe0,0);
      lVar10 = *(longlong *)(lVar5 + 0x80);
    }
    iVar8 = *(int *)(lVar10 + 0x14);
    *(int *)(&stack0x00000198 + lVar9) = iVar8;
    *(undefined4 *)(&stack0x000001b8 + lVar9) = 0x1f9e;
    *(undefined **)(&stack0x000001b0 + lVar9) = &stack0x000001bc + lVar9;
    uVar11 = iVar8 << 6;
    if ((ulonglong)uVar11 + 0xf <= (ulonglong)uVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)(puVar14 + -8) = 0x10021d;
    lVar10 = func_0x();
    lVar10 = -lVar10;
    puVar15 = puVar14 + lVar10;
    *(undefined **)(&stack0x000001a0 + lVar9) = puVar14 + lVar10 + 0xf0;
    *(undefined8 *)(puVar14 + lVar10 + -8) = 0x100236;
    func_0x(puVar14 + lVar10 + 0xf0,0);
    *(undefined4 *)(puVar14 + lVar10 + 0x30) = *(undefined4 *)(&stack0x000041c0 + lVar9);
    *(undefined **)(puVar14 + lVar10 + 0x28) = &stack0x000000e8 + lVar9;
    *(longlong **)(puVar14 + lVar10 + 0x20) = plVar18;
    uVar3 = *(undefined4 *)(param_1 + 2);
    uVar12 = *(undefined8 *)(&stack0x00000120 + lVar9);
    *(undefined8 *)(puVar14 + lVar10 + -8) = 0x100267;
    func_0x(param_1,uVar12,uVar3,&stack0x00000198 + lVar9);
    if (*(int *)(&stack0x000000e8 + lVar9) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar12 = *(undefined8 *)(&stack0x000000c8 + lVar9);
  }
  pbVar1 = (byte *)((longlong)param_1 + 0x34);
  if (((*pbVar1 & 3) != 0) &&
     ((lVar10 = *(longlong *)(*(longlong *)(*param_1 + 0x58) + 8), *(char *)(lVar10 + 0x41) < '\0'
      || ((*(byte *)(lVar10 + 0x109) & 1) != 0)))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar5 = *(longlong *)(lVar5 + 0x80);
  uVar6 = *(undefined8 *)(lVar5 + 0x18);
  uVar3 = *(undefined4 *)(lVar5 + 0x14);
  lVar10 = param_1[1];
  *(undefined4 *)(puVar15 + 0xe8) = 0;
  *(undefined8 *)(puVar15 + 0xe0) = 0;
  *(undefined8 *)(puVar15 + 0xd8) = 0;
  *(undefined **)(puVar15 + 0xd0) = &stack0x000000e0 + lVar9;
  *(undefined4 *)(puVar15 + 200) = *(undefined4 *)(&stack0x000041c0 + lVar9);
  *(undefined **)(puVar15 + 0xc0) = &stack0x00000178 + lVar9;
  *(undefined **)(puVar15 + 0xb8) = &stack0x000000dc + lVar9;
  *(undefined8 *)(puVar15 + 0xb0) = 0;
  *(undefined4 *)(puVar15 + 0xa8) = 0;
  *(undefined **)(puVar15 + 0xa0) = puVar2;
  *(undefined8 *)(puVar15 + 0x98) = uVar12;
  *(undefined4 *)(puVar15 + 0x90) = *(undefined4 *)(&stack0x000041b8 + lVar9);
  *(undefined4 *)(puVar15 + 0x88) = *(undefined4 *)(&stack0x000041b0 + lVar9);
  *(undefined8 *)(puVar15 + 0x80) = *(undefined8 *)(&stack0x00000148 + lVar9);
  *(undefined8 *)(puVar15 + 0x78) = *(undefined8 *)(&stack0x00000128 + lVar9);
  *(undefined **)(puVar15 + 0x70) = &stack0x000000d8 + lVar9;
  *(longlong **)(puVar15 + 0x68) = plVar16;
  *(undefined **)(puVar15 + 0x60) = &stack0x00000198 + lVar9;
  *(undefined8 *)(puVar15 + 0x58) = 0;
  *(undefined8 *)(puVar15 + 0x50) = 0;
  *(undefined8 *)(puVar15 + 0x48) = *(undefined8 *)(&stack0x00000120 + lVar9);
  *(undefined8 *)(puVar15 + 0x40) = *(undefined8 *)(lVar10 + 0x10);
  *(undefined8 *)(puVar15 + 0x38) = *(undefined8 *)(lVar10 + 8);
  *(undefined4 *)(puVar15 + 0x30) = *(undefined4 *)(&stack0x000000f8 + lVar9);
  *(undefined4 *)(puVar15 + 0x28) = *(undefined4 *)(&stack0x000000fc + lVar9);
  *(undefined4 *)(puVar15 + 0x20) = *(undefined4 *)(&stack0x000000d4 + lVar9);
  uVar4 = *(undefined4 *)(lVar5 + 0xc);
  *(undefined8 *)(puVar15 + -8) = 0x1003b7;
  iVar8 = func_0x(param_1,uVar3,uVar6,uVar4);
  if (iVar8 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((DAT_ & 1) == 0) {
    lVar5 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar5 != 0) && (**(longlong **)(lVar5 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(param_1[3] + 0x14) & 0xe0000000) == 0x80000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*pbVar1 & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if ((*pbVar1 & 3) != 0) {
    if (*(int *)(&stack0x000000d8 + lVar9) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(&stack0x000000dc + lVar9) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(&stack0x000041c0 + lVar9) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(&stack0x000000e4 + lVar9) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if ((*(longlong *)(&stack0x000001a0 + lVar9) != 0) && (*(uint *)(&stack0x00000198 + lVar9) != 0))
  {
    do {
      if ((*(byte *)(*(longlong *)(&stack0x000001a0 + lVar9) + 0x18 + (longlong)plVar17 * 0x40) & 4)
          != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar11 = (int)plVar17 + 1;
      plVar17 = (longlong *)(ulonglong)uVar11;
    } while (uVar11 < *(uint *)(&stack0x00000198 + lVar9));
  }
  uVar7 = *(ulonglong *)(&stack0x00004138 + lVar9);
  *(undefined8 *)(puVar15 + -8) = 0x1004b6;
  func_0x(uVar7 ^ (ulonglong)puVar2);
  return;
}

