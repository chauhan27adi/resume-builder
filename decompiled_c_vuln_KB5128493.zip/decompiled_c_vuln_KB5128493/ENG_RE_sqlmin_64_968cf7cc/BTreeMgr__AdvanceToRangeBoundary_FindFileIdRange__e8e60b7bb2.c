
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,short *param_3,int *param_4)

{
  byte **ppbVar1;
  byte **ppbVar2;
  byte *pbVar3;
  short sVar4;
  ushort uVar5;
  ushort uVar6;
  undefined2 uVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  longlong lVar11;
  char cVar12;
  byte bVar13;
  undefined uVar14;
  undefined2 uVar15;
  int iVar16;
  int iVar17;
  uint uVar18;
  undefined4 uVar19;
  longlong lVar20;
  undefined2 *puVar21;
  ushort *puVar22;
  undefined2 *puVar23;
  byte **ppbVar24;
  ulonglong uVar25;
  undefined8 uVar26;
  uint uVar27;
  uint *puVar28;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar29;
  undefined4 *puVar30;
  longlong *plVar31;
  longlong *plVar32;
  undefined8 *puVar33;
  int *piVar34;
  longlong lVar35;
  longlong lVar36;
  longlong **pplVar37;
  int *piVar38;
  int iVar39;
  undefined8 uVar40;
  ulonglong uVar41;
  longlong unaff_GS_OFFSET;
  char acStackX_8 [8];
  longlong *plStackX_10;
  char acStackX_18 [4];
  uint uStackX_1c;
  uint auStackX_20 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar20 = func_0x();
  lVar20 = -lVar20;
  *(undefined8 *)(&stack0x00001588 + lVar20) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002630 + lVar20) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar20);
  *(int **)(&stack0x00000538 + lVar20) = param_4;
  *(short **)(&stack0x00000290 + lVar20) = param_3;
  *(longlong *)(&stack0x00000100 + lVar20) = param_1;
  *(longlong *)(&stack0x00000a38 + lVar20) = param_1;
  puVar23 = *(undefined2 **)(&stack0x00002698 + lVar20);
  *(undefined2 **)(&stack0x00000540 + lVar20) = puVar23;
  puVar30 = *(undefined4 **)(&stack0x000026a0 + lVar20);
  *(undefined4 **)(&stack0x00000728 + lVar20) = puVar30;
  puVar10 = *(undefined4 **)(&stack0x000026a8 + lVar20);
  *(undefined4 **)(&stack0x00000a30 + lVar20) = puVar10;
  *(undefined4 *)(&stack0x00000060 + lVar20) = 0;
  *(undefined2 *)(&stack0x00000064 + lVar20) = 0;
  *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
  acStackX_18[lVar20] = '\0';
  uVar27 = *(uint *)((longlong)&uStackX_1c + lVar20);
  *(uint *)((longlong)&uStackX_1c + lVar20) = uVar27 & 0xffff0000;
  *(uint *)((longlong)&uStackX_1c + lVar20) = uVar27 & 0xff000000;
  *(undefined4 *)((longlong)&uStackX_1c + lVar20) = 0;
  *(undefined4 *)(&stack0x00000210 + lVar20) = 0;
  acStackX_8[lVar20] = '\x01';
  *puVar23 = 0xffff;
  *puVar30 = 0;
  *puVar10 = 0;
  if (*(int *)(param_1 + 0xd0) != 2) {
    *(int *)(&stack0x0000020c + lVar20) = *(int *)(param_1 + 0x80) + param_2;
    while (acStackX_8[lVar20] != '\0') {
      *(undefined4 **)(&stack0x00001590 + lVar20) = (undefined4 *)(param_1 + 0x170);
      *(undefined4 **)(&stack0x00001598 + lVar20) = (undefined4 *)(param_1 + 0x16c);
      *(undefined4 *)(param_1 + 0x16c) = 0;
      *(undefined4 *)(param_1 + 0x170) = 0;
      pplVar37 = (longlong **)(param_1 + 0x68);
      *(longlong ***)(&stack0x000015a0 + lVar20) = pplVar37;
      if (((*pplVar37 != (longlong *)0x0) && (*(short *)(param_1 + 0x74) != 1)) ||
         (*(int *)(param_1 + 0x90) != 0)) goto LAB_;
      lVar35 = **(longlong **)(param_1 + 8);
      *(longlong *)(&stack0x00000780 + lVar20) = lVar35;
      *(longlong ***)(&stack0x000015a8 + lVar20) = pplVar37;
      if ((*(int *)(param_1 + 0x80) == -1) && (*(int *)(param_1 + 0x90) == 0)) {
LAB_:
        (&stack0x00001b6c)[lVar20] = 0;
        uVar27 = (uint)(*(short *)(*(longlong *)(lVar35 + 8) + 0x3c4) != 1);
        *(uint *)(&stack0x00000a68 + lVar20) = uVar27;
        iVar16 = *(int *)(param_1 + 0xf4);
        *(undefined8 *)((longlong)auStackX_20 + lVar20 + -0x20) = 0;
        *(undefined **)(&stack0xfffffffffffffff8 + lVar20) = &stack0x00001b58 + lVar20;
        *(longlong ***)(&stack0xfffffffffffffff0 + lVar20) = pplVar37;
        *(uint *)(&stack0xffffffffffffffe8 + lVar20) = uVar27 + iVar16;
        uVar40 = *(undefined8 *)(param_1 + 0xa8);
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10070e;
        func_0x(param_1,uVar40,0,0);
      }
      else {
        *(undefined4 *)(&stack0x00000a9c + lVar20) = 0;
        *(undefined4 *)(&stack0x00000aa0 + lVar20) = 0;
        (&stack0xfffffffffffffff8)[lVar20] = 1;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar20) = 0;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1001cb;
        func_0x(pplVar37,2,0xffffffff,&stack0x00000a98 + lVar20);
        if (*(int *)(&stack0x00000a9c + lVar20) != 0) {
          lVar36 = **pplVar37;
          *(longlong *)(&stack0x000015b0 + lVar20) = lVar36;
          uVar14 = *(undefined *)(lVar36 + 1);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1001fd;
          func_0x(lVar35,uVar14,&stack0x00000a98 + lVar20,0xffffffff);
        }
        lVar36 = **pplVar37;
        *(longlong *)(&stack0x000015b8 + lVar20) = lVar36;
        *(int **)(&stack0x000015c0 + lVar20) = (int *)(param_1 + 0xbc);
        lVar29 = **(longlong **)(param_1 + 8);
        puVar28 = (uint *)(lVar29 + 0x14);
        *(uint **)(&stack0x000015c8 + lVar20) = puVar28;
        if (((*puVar28 & 0xe0000000) == 0x80000000) && (*(ushort *)(lVar29 + 0x18) < 0x100)) {
LAB_:
          *(undefined4 *)(&stack0x000005c4 + lVar20) = 1;
          *(longlong ***)(&stack0x00000608 + lVar20) = pplVar37;
          if (*pplVar37 != (longlong *)0x0) {
            puVar21 = (undefined2 *)((longlong)*pplVar37 + 0x62);
            *(undefined2 **)(&stack0x00001600 + lVar20) = puVar21;
            *(undefined2 *)(&stack0x000001b8 + lVar20) = *puVar21;
            plVar31 = *(longlong **)(&stack0x00000608 + lVar20);
            if (((*(ushort *)(&stack0x000001b8 + lVar20) & 0x400) == 0) ||
               (*(short *)((longlong)plVar31 + 0xc) < 3)) {
              *(int *)(&stack0x000000e0 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
              lVar35 = *plVar31;
              *(longlong *)(&stack0x00000260 + lVar20) = lVar35;
              puVar21 = (undefined2 *)(lVar35 + 0x62);
              *(undefined2 **)(&stack0x000015f8 + lVar20) = puVar21;
              uVar15 = *puVar21;
              *(undefined2 *)(&stack0x000001b0 + lVar20) = uVar15;
              if (((byte)uVar15 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000e0 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x000000e0 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x000000e0 + lVar20) < 2) goto LAB_;
                *(uint **)(&stack0x00001608 + lVar20) =
                     (uint *)(*(longlong *)(&stack0x00000260 + lVar20) + 100);
                uVar27 = *(uint *)(*(longlong *)(&stack0x00000260 + lVar20) + 100);
                *(uint *)(&stack0x000005c8 + lVar20) = uVar27;
                if ((((uVar27 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000260 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x00001610 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar40 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100584;
                  func_0x
                            (uVar40,*(undefined8 *)(&stack0x00000260 + lVar20),
                             *(undefined4 *)(&stack0x000000e0 + lVar20));
                }
              }
LAB_:
              (&stack0x00000108)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000260 + lVar20) + 100);
                *(uint **)(&stack0x00001618 + lVar20) = puVar28;
                uVar27 = *puVar28;
                *(uint *)(&stack0x000005d0 + lVar20) = uVar27;
                if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x000000e0 + lVar20))) {
                  *(uint **)(&stack0x00000b00 + lVar20) = puVar28;
                  uVar27 = *puVar28;
                  *(uint *)(&stack0x000005e0 + lVar20) = uVar27;
                  if (((uVar27 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000260 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x00000a50 + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100617;
                    iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000a54 + lVar20);
                    if (iVar16 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000260 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x000000e0 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100648;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x00000109)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100672;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x00000608 + lVar20) = 0;
              lVar35 = *(longlong *)(&stack0x00000780 + lVar20);
              param_1 = *(longlong *)(&stack0x00000100 + lVar20);
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10043a;
              func_0x(plVar31);
              lVar35 = *(longlong *)(&stack0x00000780 + lVar20);
            }
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          iVar16 = *(int *)(param_1 + 0xcc);
          if (iVar16 != 0) {
            *(int *)(&stack0x00000a58 + lVar20) = iVar16;
            lVar29 = (longlong)*(int *)(param_1 + 200);
            *(int *)(&stack0x00000a60 + lVar20) = *(int *)(param_1 + 200);
            lVar36 = *(longlong *)(lVar35 + 0x20);
            *(longlong *)(&stack0x00000b08 + lVar20) = lVar36;
            lVar36 = *(longlong *)(lVar36 + 0x6c10);
            *(longlong *)(&stack0x00000b10 + lVar20) = lVar36;
            if (lVar36 != 0) {
              if (iVar16 == 1) {
                plVar31 = (longlong *)(lVar36 + lVar29 * 0x28);
                *plVar31 = *plVar31 + 1;
              }
              else if (iVar16 == 2) {
                plVar31 = (longlong *)(lVar36 + 8 + lVar29 * 0x28);
                *plVar31 = *plVar31 + 1;
              }
              else if (iVar16 == 3) {
                plVar31 = (longlong *)(lVar36 + 0x18 + lVar29 * 0x28);
                *plVar31 = *plVar31 + 1;
              }
            }
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
          goto LAB_;
        }
        (&stack0x0000005c)[lVar20] = 0;
        if (*(short *)(lVar36 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x000002d0 + lVar20) = *(undefined8 *)(lVar36 + 0x28);
          sVar4 = *(short *)(lVar36 + 0x30);
          *(short *)(&stack0x000002d8 + lVar20) = sVar4;
        }
        else {
          cVar12 = *(char *)(lVar36 + 1);
          if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
             (*(int *)(lVar36 + 0x18) == 99)) {
            *(undefined **)(&stack0x000015d0 + lVar20) = &stack0x00000330 + lVar20;
            *(undefined4 **)(&stack0x000015d8 + lVar20) = (undefined4 *)(lVar36 + 0x20);
            *(undefined4 *)(&stack0x00000330 + lVar20) = *(undefined4 *)(lVar36 + 0x20);
            *(undefined2 *)(&stack0x00000334 + lVar20) = *(undefined2 *)(lVar36 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1002b4;
            cVar12 = func_0x(&stack0x00000330 + lVar20);
            if (cVar12 == '\0') goto LAB_;
            cVar12 = '\x01';
          }
          else {
LAB_:
            cVar12 = '\0';
          }
          (&stack0x0000005c)[lVar20] = cVar12;
          if (cVar12 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1002d9;
          func_0x(lVar36,&stack0x000002d0 + lVar20);
          sVar4 = *(short *)(&stack0x000002d8 + lVar20);
        }
        *(undefined **)(&stack0x000015e0 + lVar20) = &stack0x000002d0 + lVar20;
        if (((sVar4 != *(short *)(param_1 + 0xc4)) ||
            (*(int *)(&stack0x000002d0 + lVar20) != *(int *)(param_1 + 0xbc))) ||
           (*(int *)(&stack0x000002d4 + lVar20) != *(int *)(param_1 + 0xc0))) goto LAB_;
        *(undefined4 *)(&stack0x000005c4 + lVar20) = 0;
        iVar16 = *(int *)(param_1 + 0xcc);
        if (iVar16 == 0) goto LAB_;
        *(int *)(&stack0x00000a40 + lVar20) = iVar16;
        lVar36 = (longlong)*(int *)(param_1 + 200);
        *(int *)(&stack0x00000a48 + lVar20) = *(int *)(param_1 + 200);
        lVar35 = *(longlong *)(lVar35 + 0x20);
        *(longlong *)(&stack0x000015e8 + lVar20) = lVar35;
        lVar35 = *(longlong *)(lVar35 + 0x6c10);
        *(longlong *)(&stack0x000015f0 + lVar20) = lVar35;
        if (lVar35 == 0) {
LAB_:
          *(undefined4 *)(param_1 + 0xcc) = 0;
        }
        else {
          if (iVar16 == 1) {
            plVar31 = (longlong *)(lVar35 + 0x10 + lVar36 * 0x28);
            *plVar31 = *plVar31 + 1;
            goto LAB_;
          }
          if (iVar16 == 2) {
            plVar31 = (longlong *)(lVar35 + 8 + lVar36 * 0x28);
            *plVar31 = *plVar31 + 1;
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
          else {
            if (iVar16 != 3) goto LAB_;
            plVar31 = (longlong *)(lVar35 + 0x20 + lVar36 * 0x28);
            *plVar31 = *plVar31 + 1;
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
        }
      }
LAB_:
      if (*(int *)(param_1 + 0x90) != 0) {
        if (*(int *)(param_1 + 0xd0) != 2) {
          *(longlong ***)(&stack0x00000610 + lVar20) = pplVar37;
          if (*pplVar37 != (longlong *)0x0) {
            puVar22 = (ushort *)((longlong)*pplVar37 + 0x62);
            *(ushort **)(&stack0x00000b18 + lVar20) = puVar22;
            uVar5 = *puVar22;
            *(ushort *)(&stack0x000001a8 + lVar20) = uVar5;
            plVar31 = *(longlong **)(&stack0x00000610 + lVar20);
            if (((uVar5 & 0x400) == 0) || (*(short *)((longlong)plVar31 + 0xc) < 3)) {
              *(int *)(&stack0x000000d8 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
              lVar35 = *plVar31;
              *(longlong *)(&stack0x00000230 + lVar20) = lVar35;
              puVar23 = (undefined2 *)(lVar35 + 0x62);
              *(undefined2 **)(&stack0x00000b20 + lVar20) = puVar23;
              uVar15 = *puVar23;
              *(undefined2 *)(&stack0x000001a0 + lVar20) = uVar15;
              if (((byte)uVar15 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000d8 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x000000d8 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x000000d8 + lVar20) < 2) goto LAB_;
                *(uint **)(&stack0x00000b28 + lVar20) =
                     (uint *)(*(longlong *)(&stack0x00000230 + lVar20) + 100);
                uVar27 = *(uint *)(*(longlong *)(&stack0x00000230 + lVar20) + 100);
                *(uint *)(&stack0x000005e8 + lVar20) = uVar27;
                if ((((uVar27 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000230 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x00000b30 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar40 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10096d;
                  func_0x
                            (uVar40,*(undefined8 *)(&stack0x00000230 + lVar20),
                             *(undefined4 *)(&stack0x000000d8 + lVar20));
                }
              }
LAB_:
              (&stack0x0000010a)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000230 + lVar20) + 100);
                *(uint **)(&stack0x00000b38 + lVar20) = puVar28;
                uVar27 = *puVar28;
                *(uint *)(&stack0x000003c8 + lVar20) = uVar27;
                if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x000000d8 + lVar20))) {
                  *(uint **)(&stack0x00000b40 + lVar20) = puVar28;
                  uVar27 = *puVar28;
                  *(uint *)(&stack0x000003d0 + lVar20) = uVar27;
                  if (((uVar27 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000230 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x00000a6c + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1009fb;
                    iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000a70 + lVar20);
                    if (iVar16 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000230 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x000000d8 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100a2a;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x0000010b)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100a54;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x00000610 + lVar20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100789;
              func_0x(plVar31);
            }
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          *(undefined8 **)(&stack0x00000b48 + lVar20) = (undefined8 *)(param_1 + 0x88);
          if (*(int *)(param_1 + 0x90) != 0) {
            *(undefined4 *)(&stack0x00000a78 + lVar20) = *(undefined4 *)(param_1 + 0x94);
            *(undefined8 *)(&stack0x00000b50 + lVar20) = *(undefined8 *)(param_1 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1007c8;
            func_0x();
            *(undefined4 *)(param_1 + 0x90) = 0;
          }
          *(undefined4 *)(&stack0x00000074 + lVar20) = 0;
          *(undefined2 *)(&stack0x00000078 + lVar20) = 0;
          *(undefined4 **)(&stack0x00000b58 + lVar20) = (undefined4 *)(param_1 + 0x9c);
          *(undefined4 *)(param_1 + 0x9c) = 0;
          *(undefined2 *)(param_1 + 0xa0) = 0;
          *(undefined4 *)(&stack0x000006c0 + lVar20) = 0;
          *(undefined4 *)(&stack0x000006c4 + lVar20) = 0;
          *(undefined2 *)(&stack0x000006c8 + lVar20) = 0;
          *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x000006c0 + lVar20);
          *(undefined2 *)(param_1 + 0xc4) = 0;
          *(undefined4 *)(param_1 + 0xd0) = 2;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100835;
        func_0x((longlong)&plStackX_10 + lVar20);
        goto LAB_;
      }
      acStackX_8[lVar20] = '\0';
      lVar35 = **pplVar37;
      *(longlong *)(&stack0x00000b60 + lVar20) = lVar35;
      iVar16 = *(int *)(param_1 + 0x80);
      *(int *)(&stack0x00000a80 + lVar20) = iVar16;
      *(longlong *)(&stack0x000000f8 + lVar20) = (longlong)iVar16;
      uVar5 = *(ushort *)(lVar35 + (0xfff - (longlong)iVar16) * 2);
      *(ushort *)(&stack0x00000558 + lVar20) = uVar5;
      pbVar3 = (byte *)((ulonglong)uVar5 + lVar35);
      *(byte **)(&stack0x00000b68 + lVar20) = pbVar3;
      bVar13 = *pbVar3;
      *(ushort *)(&stack0x0000055c + lVar20) = (ushort)(bVar13 & 1);
      if ((bVar13 & 1) != 0) {
        *(undefined2 *)(&stack0x00001928 + lVar20) = 0xffff;
        *(undefined8 *)(&stack0x00001930 + lVar20) = 0;
        *(undefined4 *)(&stack0x0000192c + lVar20) = 0;
        *(undefined8 *)(&stack0x00001946 + lVar20) = 0;
        *(undefined8 *)(&stack0x00001950 + lVar20) = 0;
        *(undefined8 *)(&stack0x00001938 + lVar20) = 0;
        *(undefined4 *)(&stack0x0000195c + lVar20) = 0xffffffff;
        *(int *)(&stack0x0000195c + lVar20) = iVar16;
        if (-1 < *(char *)(lVar35 + 2)) {
          *(undefined8 *)(&stack0x00000730 + lVar20) = 0;
          goto LAB_;
        }
        *(undefined8 *)(&stack0x00000b70 + lVar20) = 0;
        *(undefined8 *)(&stack0x00000730 + lVar20) = 0;
        *(undefined **)(&stack0x00000b78 + lVar20) = &stack0x00001960 + lVar20;
        *(undefined (*) [16])(&stack0x00001960 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00001970 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00001980 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00001990 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x000019a0 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x000019b0 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x000019c0 + lVar20) = ZEXT816(0);
        *(undefined8 *)(&stack0x000019d0 + lVar20) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100b3a;
        ppbVar24 = (byte **)func_0x(&stack0x00001960 + lVar20);
        *(byte ***)(&stack0x00000730 + lVar20) = ppbVar24;
        (&stack0x00000048)[lVar20] = 0;
        if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x00001918 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
          sVar4 = *(short *)(lVar35 + 0x30);
          *(short *)(&stack0x00001920 + lVar20) = sVar4;
        }
        else {
          cVar12 = *(char *)(lVar35 + 1);
          if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
             (*(int *)(lVar35 + 0x18) == 99)) {
            *(undefined **)(&stack0x00000b80 + lVar20) = &stack0x00000328 + lVar20;
            *(undefined4 **)(&stack0x00000b88 + lVar20) = (undefined4 *)(lVar35 + 0x20);
            *(undefined4 *)(&stack0x00000328 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
            *(undefined2 *)(&stack0x0000032c + lVar20) = *(undefined2 *)(lVar35 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100bac;
            cVar12 = func_0x(&stack0x00000328 + lVar20);
            if (cVar12 == '\0') goto LAB_;
            cVar12 = '\x01';
          }
          else {
LAB_:
            cVar12 = '\0';
          }
          (&stack0x00000048)[lVar20] = cVar12;
          if (cVar12 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100bd1;
          func_0x(lVar35,&stack0x00001918 + lVar20);
          sVar4 = *(short *)(&stack0x00001920 + lVar20);
        }
        *(undefined **)(&stack0x00000b90 + lVar20) = &stack0x00001918 + lVar20;
        *(longlong *)(&stack0x00000b98 + lVar20) = lVar35 + 0x20;
        pbVar3 = (byte *)(lVar35 + 0x60);
        *(byte **)(&stack0x00000ba0 + lVar20) = pbVar3;
        *(byte ***)(&stack0x00000ba8 + lVar20) = ppbVar24;
        if (pbVar3 == *ppbVar24) {
          *(byte ***)(&stack0x00000bb0 + lVar20) = ppbVar24 + 0xc;
          if (((sVar4 == *(short *)(ppbVar24 + 0xd)) &&
              (*(int *)(&stack0x00001918 + lVar20) == *(int *)(ppbVar24 + 0xc))) &&
             (*(int *)(&stack0x0000191c + lVar20) == *(int *)((longlong)ppbVar24 + 100))) {
            *(longlong *)(&stack0x00000bb8 + lVar20) = (longlong)ppbVar24 + 0x6c;
          }
        }
        *ppbVar24 = pbVar3;
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100c77;
        func_0x(ppbVar24 + 0xc,&stack0x00001918 + lVar20);
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100c83;
        func_0x((longlong)ppbVar24 + 0x6c,lVar35 + 0x20);
        uVar41 = (ulonglong)*pbVar3;
        *(ushort *)(&stack0x00000560 + lVar20) = (ushort)*pbVar3;
        *(undefined4 *)(&stack0x00000788 + lVar20) = *(undefined4 *)(uVar41 * 6 + 0x17131f0);
        *(undefined2 *)(&stack0x0000078c + lVar20) = *(undefined2 *)(uVar41 * 6 + 0x17131f4);
        *(undefined4 *)(&stack0x00000580 + lVar20) = *(undefined4 *)(uVar41 * 6 + 0x17131f0);
        sVar4 = *(short *)(uVar41 * 6 + 0x17131f4);
        uVar41 = (ulonglong)sVar4;
        *(short *)(&stack0x00000584 + lVar20) = sVar4;
        *(longlong *)(&stack0x00000bc0 + lVar20) = lVar35 + 99;
        ppbVar1 = ppbVar24 + 2;
        *(byte ***)(&stack0x00000bc8 + lVar20) = ppbVar1;
        *(undefined2 *)ppbVar1 = 0xffff;
        ppbVar24[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
        ppbVar24[7] = (byte *)0x0;
        ppbVar24[4] = (byte *)0x0;
        *(byte ***)(&stack0x00000bd0 + lVar20) = ppbVar24 + 9;
        ppbVar24[9] = (byte *)0x0;
        ppbVar24[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar24 + 0xb) = 0;
        if ((**ppbVar24 & 2) != 0) {
          pbVar3 = pbVar3 + uVar41;
          *(byte **)(&stack0x00000bd8 + lVar20) = pbVar3;
          *(byte ***)(&stack0x00000be0 + lVar20) = ppbVar1;
          bVar13 = *pbVar3 & 1;
          *(ushort *)(&stack0x00000568 + lVar20) = (ushort)bVar13;
          *(ushort *)ppbVar1 = (ushort)bVar13;
          if (bVar13 != 0) {
            *(longlong *)(&stack0x00000bf8 + lVar20) = (longlong)ppbVar24 + 0x12;
            ppbVar24[3] = pbVar3;
            *(byte **)(&stack0x00000c00 + lVar20) = pbVar3;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107698)
                                    * 4 + 0x107688) - 0xe26c40);
                    /* WARNING: Could not emulate address calculation at 0x00100e6f */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          *(undefined4 *)(&stack0x000001d0 + lVar20) = 0;
          *(longlong *)(&stack0x00000be8 + lVar20) = (longlong)ppbVar24 + 0x12;
          ppbVar24[3] = pbVar3;
          *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
          pbVar3 = ppbVar24[3];
          *(byte **)(&stack0x00000bf0 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x00100da0 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x10764c) - 0xe26c40)
          )();
          return;
        }
        if ((**ppbVar24 & 4) != 0) {
          if (*(short *)(&stack0x00000582 + lVar20) != 0) {
            uVar41 = (ulonglong)
                     *(ushort *)
                      (lVar35 + 0x61 + (longlong)*(short *)(&stack0x00000582 + lVar20) * 2);
          }
          *(byte **)(&stack0x00000c28 + lVar20) = pbVar3 + uVar41;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10100f;
          func_0x();
        }
        pbVar3 = ppbVar24[1];
        if (pbVar3 != (byte *)0x0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x101023;
          func_0x(pbVar3,ppbVar24);
        }
LAB_:
        uVar5 = *(ushort *)(lVar35 + 0xe);
        *(uint *)(&stack0x00000a8c + lVar20) = (uint)uVar5;
        uVar6 = *(ushort *)(lVar35 + (0xfff - *(longlong *)(&stack0x000000f8 + lVar20)) * 2);
        *(ushort *)(&stack0x0000056a + lVar20) = uVar6;
        pbVar3 = (byte *)((ulonglong)uVar6 + lVar35);
        *(byte **)(&stack0x00000c30 + lVar20) = pbVar3;
        bVar13 = *pbVar3 & 1;
        *(ushort *)(&stack0x0000056c + lVar20) = (ushort)bVar13;
        *(ushort *)(&stack0x00001928 + lVar20) = (ushort)bVar13;
        if (bVar13 != 0) {
          *(undefined **)(&stack0x00000c48 + lVar20) = &stack0x0000192a + lVar20;
          *(byte **)(&stack0x00001930 + lVar20) = pbVar3;
          *(byte **)(&stack0x00000c50 + lVar20) = pbVar3;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107704) *
                                  4 + 0x1076f4) - 0xe26c40);
                    /* WARNING: Could not emulate address calculation at 0x001011a1 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbVar3,pbVar3);
          return;
        }
        *(uint *)(&stack0x00000228 + lVar20) = (uint)uVar5;
        *(undefined **)(&stack0x00000c38 + lVar20) = &stack0x0000192a + lVar20;
        *(byte **)(&stack0x00001930 + lVar20) = pbVar3;
        *(undefined4 *)(&stack0x0000192c + lVar20) = 0;
        *(undefined4 *)(&stack0x0000194e + lVar20) = 0;
        *(byte **)(&stack0x00000c40 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x001010d6 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x1076b8) - 0xe26c40))
                  ();
        return;
      }
      iVar16 = *param_4;
      *(int *)(&stack0x00000a88 + lVar20) = iVar16;
      puVar30 = (undefined4 *)(pbVar3 + iVar16);
      *(undefined4 **)(&stack0x00000748 + lVar20) = puVar30;
      *(undefined4 *)(&stack0x00000790 + lVar20) = *puVar30;
      uVar15 = *(undefined2 *)(puVar30 + 1);
      *(undefined2 *)(&stack0x00000794 + lVar20) = uVar15;
      *puVar23 = uVar15;
      iVar16 = *(int *)(param_1 + 0x80);
      *(int *)(&stack0x00000074 + lVar20) = iVar16;
LAB_:
      pplVar37 = (longlong **)(param_1 + 0x68);
      *(longlong ***)(&stack0x000000f8 + lVar20) = pplVar37;
      lVar35 = **pplVar37;
      *(longlong *)(&stack0x00000040 + lVar20) = lVar35;
      *(longlong *)(&stack0x00000038 + lVar20) = lVar35;
      uVar5 = *(ushort *)(lVar35 + 0x16);
      *(uint *)(&stack0x00000430 + lVar20) = (uint)uVar5;
      *(int *)(&stack0x0000042c + lVar20) = iVar16;
      iVar39 = uVar5 - 1;
      *(int *)(&stack0x0000006c + lVar20) = iVar39;
      *(int *)(&stack0x000003f4 + lVar20) = iVar39;
      if (*(int *)(&stack0x0000020c + lVar20) != 0) {
        iVar17 = *(int *)(&stack0x0000020c + lVar20) + -1;
        if (iVar17 < iVar39) {
          *(int *)(&stack0x0000006c + lVar20) = iVar17;
          *(int *)(&stack0x000003f4 + lVar20) = iVar17;
          iVar39 = iVar17;
        }
        *(int *)(&stack0x00000208 + lVar20) = iVar16;
        *(int *)(&stack0x00000204 + lVar20) = iVar39;
        piVar38 = *(int **)(param_3 + 8);
        *(int **)(&stack0x000000f0 + lVar20) = piVar38;
        *(int **)(&stack0x00000d38 + lVar20) = piVar38;
        uVar5 = *(ushort *)(lVar35 + (0xfff - (longlong)iVar39) * 2);
        *(ushort *)(&stack0x000005ac + lVar20) = uVar5;
        pbVar3 = (byte *)((ulonglong)uVar5 + lVar35);
        *(byte **)(&stack0x00000d40 + lVar20) = pbVar3;
        bVar13 = *pbVar3;
        *(ushort *)(&stack0x000005b0 + lVar20) = (ushort)(bVar13 & 1);
        if ((bVar13 & 1) != 0) {
          *(undefined2 *)(&stack0x000019d8 + lVar20) = 0xffff;
          *(undefined8 *)(&stack0x000019e0 + lVar20) = 0;
          *(undefined4 *)(&stack0x000019dc + lVar20) = 0;
          *(undefined8 *)(&stack0x000019f6 + lVar20) = 0;
          *(undefined8 *)(&stack0x00001a00 + lVar20) = 0;
          *(undefined8 *)(&stack0x000019e8 + lVar20) = 0;
          *(undefined4 *)(&stack0x00001a0c + lVar20) = 0xffffffff;
          *(int *)(&stack0x00001a0c + lVar20) = iVar39;
          if (-1 < *(char *)(lVar35 + 2)) {
            *(undefined8 *)(&stack0x00000750 + lVar20) = 0;
            goto LAB_;
          }
          *(undefined8 *)(&stack0x00000d48 + lVar20) = 0;
          *(undefined8 *)(&stack0x00000750 + lVar20) = 0;
          *(undefined **)(&stack0x00000d50 + lVar20) = &stack0x00001a10 + lVar20;
          *(undefined (*) [16])(&stack0x00001a10 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001a20 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001a30 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001a40 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001a50 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001a60 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001a70 + lVar20) = ZEXT816(0);
          *(undefined8 *)(&stack0x00001a80 + lVar20) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x102120;
          ppbVar24 = (byte **)func_0x(&stack0x00001a10 + lVar20);
          *(byte ***)(&stack0x00000750 + lVar20) = ppbVar24;
          (&stack0x00000049)[lVar20] = 0;
          if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
            *(undefined8 *)(&stack0x000018f8 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
            sVar4 = *(short *)(lVar35 + 0x30);
            *(short *)(&stack0x00001900 + lVar20) = sVar4;
          }
          else {
            cVar12 = *(char *)(lVar35 + 1);
            if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
               (*(int *)(lVar35 + 0x18) == 99)) {
              *(undefined **)(&stack0x00000d58 + lVar20) = &stack0x00000320 + lVar20;
              *(undefined4 **)(&stack0x00000d60 + lVar20) = (undefined4 *)(lVar35 + 0x20);
              *(undefined4 *)(&stack0x00000320 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
              *(undefined2 *)(&stack0x00000324 + lVar20) = *(undefined2 *)(lVar35 + 0x24);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x102195;
              cVar12 = func_0x(&stack0x00000320 + lVar20);
              if (cVar12 == '\0') goto LAB_;
              cVar12 = '\x01';
            }
            else {
LAB_:
              cVar12 = '\0';
            }
            (&stack0x00000049)[lVar20] = cVar12;
            if (cVar12 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1021ba;
            func_0x(lVar35,&stack0x000018f8 + lVar20);
            sVar4 = *(short *)(&stack0x00001900 + lVar20);
          }
          *(undefined **)(&stack0x00000d68 + lVar20) = &stack0x000018f8 + lVar20;
          *(longlong *)(&stack0x00000d70 + lVar20) = lVar35 + 0x20;
          pbVar3 = (byte *)(lVar35 + 0x60);
          *(byte **)(&stack0x00000d78 + lVar20) = pbVar3;
          *(byte ***)(&stack0x00000d80 + lVar20) = ppbVar24;
          if (pbVar3 == *ppbVar24) {
            *(byte ***)(&stack0x00000d88 + lVar20) = ppbVar24 + 0xc;
            if (((sVar4 == *(short *)(ppbVar24 + 0xd)) &&
                (*(int *)(&stack0x000018f8 + lVar20) == *(int *)(ppbVar24 + 0xc))) &&
               (*(int *)(&stack0x000018fc + lVar20) == *(int *)((longlong)ppbVar24 + 100))) {
              *(longlong *)(&stack0x00000d90 + lVar20) = (longlong)ppbVar24 + 0x6c;
            }
          }
          *ppbVar24 = pbVar3;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x102260;
          func_0x(ppbVar24 + 0xc,&stack0x000018f8 + lVar20);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10226c;
          func_0x((longlong)ppbVar24 + 0x6c,lVar35 + 0x20);
          uVar41 = (ulonglong)*pbVar3;
          *(ushort *)(&stack0x000005b8 + lVar20) = (ushort)*pbVar3;
          *(undefined4 *)(&stack0x000007aa + lVar20) = *(undefined4 *)(uVar41 * 6 + 0x17131f0);
          *(undefined2 *)(&stack0x000007ae + lVar20) = *(undefined2 *)(uVar41 * 6 + 0x17131f4);
          *(undefined4 *)(&stack0x00000588 + lVar20) = *(undefined4 *)(uVar41 * 6 + 0x17131f0);
          sVar4 = *(short *)(uVar41 * 6 + 0x17131f4);
          uVar41 = (ulonglong)sVar4;
          *(short *)(&stack0x0000058c + lVar20) = sVar4;
          *(longlong *)(&stack0x00000d98 + lVar20) = lVar35 + 99;
          ppbVar1 = ppbVar24 + 2;
          *(byte ***)(&stack0x00000da0 + lVar20) = ppbVar1;
          *(undefined2 *)ppbVar1 = 0xffff;
          ppbVar24[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
          ppbVar24[7] = (byte *)0x0;
          ppbVar24[4] = (byte *)0x0;
          ppbVar2 = ppbVar24 + 9;
          *(byte ***)(&stack0x00000da8 + lVar20) = ppbVar2;
          *ppbVar2 = (byte *)0x0;
          ppbVar24[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar24 + 0xb) = 0;
          if ((**ppbVar24 & 2) != 0) {
            pbVar3 = pbVar3 + uVar41;
            *(byte **)(&stack0x00000db0 + lVar20) = pbVar3;
            *(byte ***)(&stack0x00000db8 + lVar20) = ppbVar1;
            bVar13 = *pbVar3 & 1;
            *(ushort *)(&stack0x000005c0 + lVar20) = (ushort)bVar13;
            *(ushort *)ppbVar1 = (ushort)bVar13;
            if (bVar13 != 0) {
              *(longlong *)(&stack0x00000dd0 + lVar20) = (longlong)ppbVar24 + 0x12;
              ppbVar24[3] = pbVar3;
              *(byte **)(&stack0x00000dd8 + lVar20) = pbVar3;
              UNRECOVERED_JUMPTABLE_00 =
                   (code *)((ulonglong)
                            *(uint *)((ulonglong)
                                      *(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107770) * 4 +
                                     0x107760) - 0xe26c40);
                    /* WARNING: Could not emulate address calculation at 0x00102448 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
              return;
            }
            *(undefined4 *)(&stack0x000001e0 + lVar20) = 0;
            *(longlong *)(&stack0x00000dc0 + lVar20) = (longlong)ppbVar24 + 0x12;
            ppbVar24[3] = pbVar3;
            *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
            pbVar3 = ppbVar24[3];
            *(byte **)(&stack0x00000dc8 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x00102380 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107724) -
                      0xe26c40))();
            return;
          }
          if ((**ppbVar24 & 4) != 0) {
            if (*(short *)(&stack0x0000058a + lVar20) != 0) {
              uVar41 = (ulonglong)
                       *(ushort *)
                        (lVar35 + 0x61 + (longlong)*(short *)(&stack0x0000058a + lVar20) * 2);
            }
            *(byte **)(&stack0x00000e00 + lVar20) = pbVar3 + uVar41;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1025e7;
            func_0x(ppbVar2);
          }
          pbVar3 = ppbVar24[1];
          if (pbVar3 != (byte *)0x0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1025fb;
            func_0x(pbVar3,ppbVar24);
          }
          iVar39 = *(int *)(&stack0x0000006c + lVar20);
          lVar35 = *(longlong *)(&stack0x00000040 + lVar20);
LAB_:
          uVar5 = *(ushort *)(lVar35 + 0xe);
          *(uint *)(&stack0x00000830 + lVar20) = (uint)uVar5;
          uVar6 = *(ushort *)(lVar35 + (0xfff - (longlong)iVar39) * 2);
          *(ushort *)(&stack0x000005c2 + lVar20) = uVar6;
          pbVar3 = (byte *)(lVar35 + (ulonglong)uVar6);
          *(byte **)(&stack0x00000e08 + lVar20) = pbVar3;
          bVar13 = *pbVar3 & 1;
          *(ushort *)(&stack0x000005d8 + lVar20) = (ushort)bVar13;
          *(ushort *)(&stack0x000019d8 + lVar20) = (ushort)bVar13;
          if (bVar13 != 0) {
            *(undefined **)(&stack0x00000e20 + lVar20) = &stack0x000019da + lVar20;
            *(byte **)(&stack0x000019e0 + lVar20) = pbVar3;
            *(byte **)(&stack0x00000e28 + lVar20) = pbVar3;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x1077dc)
                                    * 4 + 0x1077cc) - 0xe26c40);
                    /* WARNING: Could not emulate address calculation at 0x0010277c */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbVar3,pbVar3);
            return;
          }
          *(uint *)(&stack0x000001e8 + lVar20) = (uint)uVar5;
          *(undefined **)(&stack0x00000e10 + lVar20) = &stack0x000019da + lVar20;
          *(byte **)(&stack0x000019e0 + lVar20) = pbVar3;
          *(undefined4 *)(&stack0x000019dc + lVar20) = 0;
          *(undefined4 *)(&stack0x000019fe + lVar20) = 0;
          *(byte **)(&stack0x00000e18 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x001026b1 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107790) - 0xe26c40)
          )();
          return;
        }
        iVar17 = *piVar38;
        *(int *)(&stack0x0000082c + lVar20) = iVar17;
        puVar30 = (undefined4 *)(pbVar3 + iVar17);
        *(undefined4 **)(&stack0x00000768 + lVar20) = puVar30;
        *(undefined4 *)(&stack0x00000310 + lVar20) = *puVar30;
        sVar4 = *(short *)(puVar30 + 1);
        *(short *)(&stack0x00000314 + lVar20) = sVar4;
        param_3 = *(short **)(&stack0x00000290 + lVar20);
        if (sVar4 != *param_3) {
          while (iVar16 < iVar39) {
            iVar17 = (iVar39 + 1 + iVar16) / 2;
            *(int *)(&stack0x00000200 + lVar20) = iVar17;
            piVar38 = *(int **)(param_3 + 8);
            *(int **)(&stack0x000000f0 + lVar20) = piVar38;
            *(int **)(&stack0x00000f10 + lVar20) = piVar38;
            uVar5 = *(ushort *)(lVar35 + (0xfff - (longlong)iVar17) * 2);
            *(ushort *)(&stack0x00000684 + lVar20) = uVar5;
            pbVar3 = (byte *)((ulonglong)uVar5 + lVar35);
            *(byte **)(&stack0x00000f18 + lVar20) = pbVar3;
            bVar13 = *pbVar3;
            *(ushort *)(&stack0x00000688 + lVar20) = (ushort)(bVar13 & 1);
            if ((bVar13 & 1) != 0) {
              *(undefined2 *)(&stack0x00001a88 + lVar20) = 0xffff;
              *(undefined8 *)(&stack0x00001a90 + lVar20) = 0;
              *(undefined4 *)(&stack0x00001a8c + lVar20) = 0;
              *(undefined8 *)(&stack0x00001aa6 + lVar20) = 0;
              *(undefined8 *)(&stack0x00001ab0 + lVar20) = 0;
              *(undefined8 *)(&stack0x00001a98 + lVar20) = 0;
              *(undefined4 *)(&stack0x00001abc + lVar20) = 0xffffffff;
              *(int *)(&stack0x00001abc + lVar20) = iVar17;
              if (-1 < *(char *)(lVar35 + 2)) {
                *(undefined8 *)(&stack0x00000770 + lVar20) = 0;
                goto LAB_;
              }
              pbVar3 = (byte *)(lVar35 + 0x60);
              *(undefined8 *)(&stack0x00000f20 + lVar20) = 0;
              *(undefined8 *)(&stack0x00000770 + lVar20) = 0;
              *(undefined **)(&stack0x00000f28 + lVar20) = &stack0x00001ac0 + lVar20;
              *(undefined (*) [16])(&stack0x00001ac0 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001ad0 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001ae0 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001af0 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001b00 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001b10 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001b20 + lVar20) = ZEXT816(0);
              *(undefined8 *)(&stack0x00001b30 + lVar20) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1036d2;
              ppbVar24 = (byte **)func_0x(&stack0x00001ac0 + lVar20);
              *(byte ***)(&stack0x00000770 + lVar20) = ppbVar24;
              (&stack0x0000004a)[lVar20] = 0;
              if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x00001908 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
                sVar4 = *(short *)(lVar35 + 0x30);
                *(short *)(&stack0x00001910 + lVar20) = sVar4;
              }
              else {
                cVar12 = *(char *)(lVar35 + 1);
                if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                   (*(int *)(lVar35 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00000f30 + lVar20) = &stack0x00000318 + lVar20;
                  *(undefined4 **)(&stack0x00000f38 + lVar20) = (undefined4 *)(lVar35 + 0x20);
                  *(undefined4 *)(&stack0x00000318 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
                  *(undefined2 *)(&stack0x0000031c + lVar20) = *(undefined2 *)(lVar35 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x103747;
                  cVar12 = func_0x(&stack0x00000318 + lVar20);
                  if (cVar12 == '\0') goto LAB_;
                  cVar12 = '\x01';
                }
                else {
LAB_:
                  cVar12 = '\0';
                }
                (&stack0x0000004a)[lVar20] = cVar12;
                if (cVar12 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10376c;
                func_0x(lVar35,&stack0x00001908 + lVar20);
                sVar4 = *(short *)(&stack0x00001910 + lVar20);
              }
              *(undefined **)(&stack0x00000f40 + lVar20) = &stack0x00001908 + lVar20;
              *(longlong *)(&stack0x00000f48 + lVar20) = lVar35 + 0x20;
              *(byte **)(&stack0x00000f50 + lVar20) = pbVar3;
              *(byte ***)(&stack0x00000f58 + lVar20) = ppbVar24;
              if (pbVar3 == *ppbVar24) {
                *(byte ***)(&stack0x00000f60 + lVar20) = ppbVar24 + 0xc;
                if (((sVar4 == *(short *)(ppbVar24 + 0xd)) &&
                    (*(int *)(&stack0x00001908 + lVar20) == *(int *)(ppbVar24 + 0xc))) &&
                   (*(int *)(&stack0x0000190c + lVar20) == *(int *)((longlong)ppbVar24 + 100))) {
                  *(longlong *)(&stack0x00000f68 + lVar20) = (longlong)ppbVar24 + 0x6c;
                }
              }
              *ppbVar24 = pbVar3;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10380e;
              func_0x(ppbVar24 + 0xc,&stack0x00001908 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10381a;
              func_0x((longlong)ppbVar24 + 0x6c,lVar35 + 0x20);
              uVar41 = (ulonglong)*pbVar3;
              *(ushort *)(&stack0x00000690 + lVar20) = (ushort)*pbVar3;
              *(undefined4 *)(&stack0x000007a4 + lVar20) = *(undefined4 *)(uVar41 * 6 + 0x17131f0);
              *(undefined2 *)(&stack0x000007a8 + lVar20) = *(undefined2 *)(uVar41 * 6 + 0x17131f4);
              *(undefined4 *)(&stack0x00000590 + lVar20) = *(undefined4 *)(uVar41 * 6 + 0x17131f0);
              sVar4 = *(short *)(uVar41 * 6 + 0x17131f4);
              uVar41 = (ulonglong)sVar4;
              *(short *)(&stack0x00000594 + lVar20) = sVar4;
              *(longlong *)(&stack0x00000f70 + lVar20) = lVar35 + 99;
              ppbVar1 = ppbVar24 + 2;
              *(byte ***)(&stack0x00000f78 + lVar20) = ppbVar1;
              *(undefined2 *)ppbVar1 = 0xffff;
              ppbVar24[3] = (byte *)0x0;
              *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
              *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
              ppbVar24[7] = (byte *)0x0;
              ppbVar24[4] = (byte *)0x0;
              ppbVar2 = ppbVar24 + 9;
              *(byte ***)(&stack0x00000f80 + lVar20) = ppbVar2;
              *ppbVar2 = (byte *)0x0;
              ppbVar24[10] = (byte *)0x0;
              *(undefined2 *)(ppbVar24 + 0xb) = 0;
              if ((**ppbVar24 & 2) != 0) {
                pbVar3 = pbVar3 + uVar41;
                *(byte **)(&stack0x00000f88 + lVar20) = pbVar3;
                *(byte ***)(&stack0x00000f90 + lVar20) = ppbVar1;
                bVar13 = *pbVar3 & 1;
                *(ushort *)(&stack0x00000698 + lVar20) = (ushort)bVar13;
                *(ushort *)ppbVar1 = (ushort)bVar13;
                if (bVar13 != 0) {
                  *(longlong *)(&stack0x00000fa8 + lVar20) = (longlong)ppbVar24 + 0x12;
                  ppbVar24[3] = pbVar3;
                  *(byte **)(&stack0x00000fb0 + lVar20) = pbVar3;
                  UNRECOVERED_JUMPTABLE_00 =
                       (code *)((ulonglong)
                                *(uint *)((ulonglong)
                                          *(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107848) * 4
                                         + 0x107838) - 0xe26c40);
                    /* WARNING: Could not emulate address calculation at 0x00103a00 */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                  return;
                }
                *(undefined4 *)(&stack0x000001f0 + lVar20) = 0;
                *(longlong *)(&stack0x00000f98 + lVar20) = (longlong)ppbVar24 + 0x12;
                ppbVar24[3] = pbVar3;
                *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
                pbVar3 = ppbVar24[3];
                *(byte **)(&stack0x00000fa0 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x00103938 */
                    /* WARNING: Treating indirect jump as call */
                (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x1077fc) -
                          0xe26c40))();
                return;
              }
              if ((**ppbVar24 & 4) != 0) {
                if (*(short *)(&stack0x00000592 + lVar20) != 0) {
                  uVar41 = (ulonglong)
                           *(ushort *)
                            (lVar35 + 0x61 + (longlong)*(short *)(&stack0x00000592 + lVar20) * 2);
                }
                *(byte **)(&stack0x00000fd8 + lVar20) = pbVar3 + uVar41;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x103b9f;
                func_0x(ppbVar2);
              }
              pbVar3 = ppbVar24[1];
              if (pbVar3 != (byte *)0x0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x103bb3;
                func_0x(pbVar3,ppbVar24);
              }
              lVar35 = *(longlong *)(&stack0x00000040 + lVar20);
LAB_:
              uVar5 = *(ushort *)(lVar35 + 0xe);
              *(uint *)(&stack0x00000878 + lVar20) = (uint)uVar5;
              uVar6 = *(ushort *)
                       (lVar35 + (0xfff - (longlong)*(int *)(&stack0x00000200 + lVar20)) * 2);
              *(ushort *)(&stack0x0000037c + lVar20) = uVar6;
              pbVar3 = (byte *)((ulonglong)uVar6 + lVar35);
              *(byte **)(&stack0x00000fe0 + lVar20) = pbVar3;
              bVar13 = *pbVar3 & 1;
              *(ushort *)(&stack0x0000037e + lVar20) = (ushort)bVar13;
              *(ushort *)(&stack0x00001a88 + lVar20) = (ushort)bVar13;
              if (bVar13 != 0) {
                *(undefined **)(&stack0x00000ff8 + lVar20) = &stack0x00001a8a + lVar20;
                *(byte **)(&stack0x00001a90 + lVar20) = pbVar3;
                *(byte **)(&stack0x00001000 + lVar20) = pbVar3;
                UNRECOVERED_JUMPTABLE_00 =
                     (code *)((ulonglong)
                              *(uint *)((ulonglong)
                                        *(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x1078b4) * 4 +
                                       0x1078a4) - 0xe26c40);
                    /* WARNING: Could not emulate address calculation at 0x00103d39 */
                    /* WARNING: Treating indirect jump as call */
                (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbVar3,pbVar3);
                return;
              }
              *(uint *)(&stack0x000001f8 + lVar20) = (uint)uVar5;
              *(undefined **)(&stack0x00000fe8 + lVar20) = &stack0x00001a8a + lVar20;
              *(byte **)(&stack0x00001a90 + lVar20) = pbVar3;
              *(undefined4 *)(&stack0x00001a8c + lVar20) = 0;
              *(undefined4 *)(&stack0x00001aae + lVar20) = 0;
              *(byte **)(&stack0x00000ff0 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x00103c6e */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107868) -
                        0xe26c40))();
              return;
            }
            iVar8 = *piVar38;
            *(int *)(&stack0x00000874 + lVar20) = iVar8;
            puVar30 = (undefined4 *)(pbVar3 + iVar8);
            *(undefined4 **)(&stack0x000006f0 + lVar20) = puVar30;
            *(undefined4 *)(&stack0x00000310 + lVar20) = *puVar30;
            sVar4 = *(short *)(puVar30 + 1);
            *(short *)(&stack0x00000314 + lVar20) = sVar4;
            param_3 = *(short **)(&stack0x00000290 + lVar20);
            if (sVar4 == *param_3) {
              *(int *)(&stack0x00000074 + lVar20) = iVar17;
              *(int *)(&stack0x00000208 + lVar20) = iVar17;
              iVar16 = iVar17;
            }
            else {
              iVar39 = iVar17 + -1;
              *(int *)(&stack0x0000006c + lVar20) = iVar39;
              *(int *)(&stack0x00000204 + lVar20) = iVar39;
            }
          }
          param_1 = *(longlong *)(&stack0x00000100 + lVar20);
          pplVar37 = *(longlong ***)(&stack0x000000f8 + lVar20);
        }
        *(int *)(&stack0x000008bc + lVar20) = iVar39;
        *(int *)(param_1 + 0x80) = iVar39 + 1;
        piVar38 = *(int **)(&stack0x00000728 + lVar20);
        *piVar38 = *piVar38 + (iVar39 - *(int *)(&stack0x0000042c + lVar20)) + 1;
        if (*(int *)(param_1 + 0x80) < *(int *)(&stack0x00000430 + lVar20)) goto LAB_;
        *(int *)(&stack0x0000020c + lVar20) =
             *(int *)(&stack0x0000020c + lVar20) - *(int *)(&stack0x00000430 + lVar20);
        *(int **)(&stack0x000010e8 + lVar20) = (int *)(lVar35 + 0x10);
        iVar16 = *(int *)(lVar35 + 0x10);
        *(int *)(&stack0x0000006c + lVar20) = iVar16;
        sVar4 = *(short *)(lVar35 + 0x14);
        *(short *)(&stack0x00000070 + lVar20) = sVar4;
        *(int *)(&stack0x00000060 + lVar20) = iVar16;
        *(short *)(&stack0x00000064 + lVar20) = sVar4;
        uVar40 = 0;
        *(undefined4 *)(&stack0x0000079e + lVar20) = 0;
        *(undefined2 *)(&stack0x000007a2 + lVar20) = 0;
        if ((iVar16 != 0) || (sVar4 != 0)) {
          *(undefined **)(&stack0x00001138 + lVar20) = &stack0x00000598 + lVar20;
          *(int *)(&stack0x00000598 + lVar20) = iVar16;
          *(short *)(&stack0x0000059c + lVar20) = sVar4;
          *(longlong ***)(&stack0x00000710 + lVar20) = pplVar37;
          plVar31 = *(longlong **)(param_1 + 8);
          *(longlong **)(&stack0x00000720 + lVar20) = plVar31;
          *(undefined8 *)(&stack0x00000658 + lVar20) = *(undefined8 *)(param_1 + 0x10);
          *(undefined4 *)(&stack0x00000360 + lVar20) = 0;
          *(undefined4 *)(&stack0x00000364 + lVar20) = 0;
          *(undefined2 *)(&stack0x00000368 + lVar20) = 0;
          lVar35 = *plVar31;
          *(longlong *)(&stack0x00000718 + lVar20) = lVar35;
          *(undefined4 *)(&stack0x00000ab4 + lVar20) = 0;
          *(undefined4 *)(&stack0x00000ab8 + lVar20) = 0;
          lVar36 = *(longlong *)(lVar35 + 0x20);
          *(longlong *)(&stack0x000000a0 + lVar20) = lVar36;
          *(uint6 **)(&stack0x00001140 + lVar20) = (uint6 *)(lVar35 + 0x14);
          lVar29 = (ulonglong)*(uint6 *)(lVar35 + 0x14) * 0x10000;
          *(longlong *)(&stack0x00001148 + lVar20) = lVar29;
          lVar35 = *(longlong *)(lVar36 + 2000);
          if ((lVar35 == lVar29) && (lVar35 - 1U < 0xfffffffffffffffe)) {
            (&stack0x0000004b)[lVar20] = 1;
            lVar35 = *(longlong *)(&stack0x00000040 + lVar20);
          }
          else {
            (&stack0x0000004b)[lVar20] = 0;
            if ((*(longlong *)(*(longlong *)(&stack0x000000a0 + lVar20) + 0x7d8) == lVar29) &&
               (*(longlong *)(*(longlong *)(&stack0x000000a0 + lVar20) + 0x7d8) - 1U <
                0xfffffffffffffffe)) {
              (&stack0x0000004c)[lVar20] = 1;
              lVar35 = *(longlong *)(&stack0x00000040 + lVar20);
            }
            else {
              (&stack0x0000004c)[lVar20] = 0;
              lVar35 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x00001150 + lVar20) = lVar35;
              lVar36 = (ulonglong)*_DAT_ +
                       *(longlong *)(lVar35 + (ulonglong)*_DAT_ * 8);
              *(longlong *)(&stack0x00001158 + lVar20) = lVar36;
              lVar35 = *(longlong *)(lVar36 + 0x100);
              *(longlong *)(&stack0x000009e8 + lVar20) = lVar35;
              puVar28 = _DAT_;
              if (lVar35 == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10502d;
                puVar28 = (uint *)(*_DAT_)(0);
                lVar35 = *(longlong *)(lVar36 + 0x100);
                *(longlong *)(&stack0x000009e8 + lVar20) = lVar35;
              }
              *(longlong *)(&stack0x00001160 + lVar20) = lVar35;
              uVar41 = rdtsc();
              uVar25 = CONCAT44((int)((ulonglong)puVar28 >> 0x20),(int)uVar41) |
                       uVar41 & 0xffffffff00000000;
              *(ulonglong *)(&stack0x00001168 + lVar20) = uVar25;
              uVar41 = *(ulonglong *)(lVar35 + 0x340);
              if ((uVar41 < uVar25) ||
                 ((uVar41 != 0x7fffffffffffffff &&
                  (*(ulonglong *)(*(longlong *)(lVar35 + 0x260) + 0xdf0) < uVar41 - uVar25)))) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1050fc;
                iVar16 = func_0x(0,0x2036cf0);
                *(int *)(&stack0x00000284 + lVar20) = iVar16;
                if (iVar16 == 2) {
LAB_:
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10510f;
                  func_0x(0x7c);
                }
              }
              else {
                lVar35 = *(longlong *)(lVar35 + 600);
                *(longlong *)(&stack0x000009f0 + lVar20) = lVar35;
                puVar28 = (uint *)(lVar35 + 0xbc);
                *(uint **)(&stack0x00001170 + lVar20) = puVar28;
                if ((*puVar28 & 4) != 0) {
                  lVar35 = *(longlong *)(*(longlong *)(&stack0x000009f0 + lVar20) + 0x98);
                  *(longlong *)(&stack0x00001178 + lVar20) = lVar35;
                  if (((*(byte *)(lVar35 + 0x268) & 1) == 0) &&
                     ((*(uint *)(lVar35 + 800) & 0x180) == 0)) {
                    *(undefined4 *)(&stack0x00000284 + lVar20) = 2;
                    goto LAB_;
                  }
                }
                *(undefined4 *)(&stack0x00000284 + lVar20) = 0;
              }
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
            }
          }
          *(undefined4 *)(&stack0x000007b0 + lVar20) = 0;
          *(undefined4 *)(&stack0x000007b4 + lVar20) = 0;
          *(undefined2 *)(&stack0x000007b8 + lVar20) = 0;
          if (*(longlong *)(&stack0x00000710 + lVar20) == 0) {
            (&stack0x00000028)[lVar20] = 0;
          }
          else {
            (&stack0x00000028)[lVar20] = 1;
            uVar14 = 0xff;
            if (*(char *)(*(longlong *)(&stack0x000000a0 + lVar20) + 0x2050) != '\0')
            goto LAB_;
          }
          uVar14 = 2;
LAB_:
          (&stack0x00000029)[lVar20] = uVar14;
          do {
            *(undefined **)(&stack0x000006f8 + lVar20) = &stack0x00000ab0 + lVar20;
            *(undefined4 *)(&stack0x000018cc + lVar20) = 0;
            *(undefined4 *)(&stack0x000018d0 + lVar20) = 0;
            cVar12 = *_DAT_;
            (&stack0x0000010e)[lVar20] = cVar12;
            uVar26 = uVar40;
            if ((cVar12 != '\0') &&
               ((&stack0x0000010f)[lVar20] = DAT_ >> 7, -1 < (char)DAT_)) {
              *(undefined4 *)(&stack0x00000450 + lVar20) = 0;
              lVar35 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x00001180 + lVar20) = lVar35;
              plVar31 = (longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)(lVar35 + (ulonglong)*_DAT_ * 8));
              *(longlong **)(&stack0x00001188 + lVar20) = plVar31;
              lVar35 = *plVar31;
              *(longlong *)(&stack0x00001190 + lVar20) = lVar35;
              if (lVar35 == 0) {
LAB_:
                *(undefined8 *)(&stack0x000009f8 + lVar20) = 0;
              }
              else {
                lVar35 = **(longlong **)(lVar35 + 0x38);
                *(longlong *)(&stack0x00001198 + lVar20) = lVar35;
                if (lVar35 == 0) goto LAB_;
                *(longlong *)(&stack0x000009f8 + lVar20) = lVar35;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105228;
                iVar16 = (*_DAT_)(lVar35,0x337);
                *(int *)(&stack0x00000450 + lVar20) = iVar16;
                if (iVar16 != 0) {
                  lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
                  goto LAB_;
                }
              }
              lVar35 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x000011a0 + lVar20) = lVar35;
              lVar35 = (ulonglong)*_DAT_ +
                       *(longlong *)(lVar35 + (ulonglong)*_DAT_ * 8);
              *(longlong *)(&stack0x000011a8 + lVar20) = lVar35;
              lVar36 = *(longlong *)(lVar35 + 8);
              *(longlong *)(&stack0x000011b0 + lVar20) = lVar36;
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
              if (lVar36 != 0) {
                uVar26 = *(undefined8 *)(lVar36 + 0x60);
              }
            }
LAB_:
            *(undefined8 *)(&stack0x000002a0 + lVar20) = uVar26;
            lVar36 = *(longlong *)(&stack0x000000a0 + lVar20);
            *(undefined8 *)(&stack0x00000a00 + lVar20) = *(undefined8 *)(lVar36 + 0x728);
LAB_:
            *(undefined4 *)(&stack0x00000280 + lVar20) = 0;
            if (*(longlong *)((longlong)&plStackX_10 + lVar20) != 0) {
              puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x62);
              *(undefined2 **)(&stack0x000011b8 + lVar20) = puVar23;
              *(undefined2 *)(&stack0x00000188 + lVar20) = *puVar23;
              if (((*(ushort *)(&stack0x00000188 + lVar20) & 0x400) == 0) ||
                 (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
                *(int *)(&stack0x000000e8 + lVar20) =
                     (int)*(short *)((longlong)&uStackX_1c + lVar20);
                *(undefined8 *)(&stack0x00000638 + lVar20) =
                     *(undefined8 *)((longlong)&plStackX_10 + lVar20);
                *(undefined2 **)(&stack0x000011c0 + lVar20) = puVar23;
                uVar15 = *puVar23;
                *(undefined2 *)(&stack0x00000180 + lVar20) = uVar15;
                if (((byte)uVar15 >> 3 & 1) != 0) {
                  if (*(int *)(&stack0x000000e8 + lVar20) == 3) {
                    *(undefined4 *)(&stack0x000000e8 + lVar20) = 4;
                  }
                  else if (*(int *)(&stack0x000000e8 + lVar20) < 2) goto LAB_;
                  puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
                  *(uint **)(&stack0x000011c8 + lVar20) = puVar28;
                  uVar27 = *puVar28;
                  *(uint *)(&stack0x00000458 + lVar20) = uVar27;
                  if ((((uVar27 & 8) != 0) &&
                      (lVar35 = *(longlong *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90)
                      , lVar35 != 0)) &&
                     (*(longlong *)(&stack0x000011d0 + lVar20) = lVar35,
                     *(longlong *)(lVar35 + 0x758) != 0)) {
                    uVar26 = *(undefined8 *)(lVar35 + 0x758);
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1053bc;
                    func_0x
                              (uVar26,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                               *(undefined4 *)(&stack0x000000e8 + lVar20));
                  }
                }
LAB_:
                (&stack0x00000110)[lVar20] = DAT_ >> 7;
                if ((char)DAT_ < '\0') {
                  puVar28 = (uint *)(*(longlong *)(&stack0x00000638 + lVar20) + 100);
                  *(uint **)(&stack0x000011d8 + lVar20) = puVar28;
                  uVar27 = *puVar28;
                  *(uint *)(&stack0x00000460 + lVar20) = uVar27;
                  if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x000000e8 + lVar20))) {
                    *(uint **)(&stack0x000011e0 + lVar20) = puVar28;
                    uVar27 = *puVar28;
                    *(uint *)(&stack0x00000468 + lVar20) = uVar27;
                    if (((uVar27 & 0xc0000000) != 0x40000000) &&
                       (lVar35 = **(longlong **)(&stack0x00000638 + lVar20), lVar35 != 0)) {
                      *(undefined4 *)(&stack0x000008d0 + lVar20) = 2;
                      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10544f;
                      iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x000008d4 + lVar20);
                      if (iVar16 != 0) {
                        LOCK();
                        *puVar28 = *puVar28 & 0x3fffffff;
                        UNLOCK();
                        LOCK();
                        *puVar28 = *puVar28 | 0x40000000;
                        UNLOCK();
                      }
                    }
                  }
                }
                lVar35 = *(longlong *)(&stack0x00000638 + lVar20);
                uVar19 = *(undefined4 *)(&stack0x000000e8 + lVar20);
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10547e;
                func_0x(lVar35 + 0x98,uVar19);
                if ((_DAT_ != 0) &&
                   ((&stack0x00000111)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1054a8;
                  func_0x(lVar35,0,uVar19);
                }
                *(uint *)((longlong)&uStackX_1c + lVar20) =
                     *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
                *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1052b1;
                func_0x((longlong)&plStackX_10 + lVar20);
              }
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
            }
            if (*(longlong *)(lVar36 + 0x728) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1054e6;
              func_0x((longlong)&plStackX_10 + lVar20,&stack0x00000060 + lVar20,
                              *(undefined8 *)(&stack0x000000a0 + lVar20));
              if (*(longlong *)((longlong)&plStackX_10 + lVar20) != 0) {
                puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x62);
                *(undefined2 **)(&stack0x000011e8 + lVar20) = puVar23;
                *(undefined2 *)(&stack0x00000178 + lVar20) = *puVar23;
                if (((*(ushort *)(&stack0x00000178 + lVar20) & 0x400) == 0) ||
                   (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
                  *(int *)(&stack0x000000c0 + lVar20) =
                       (int)*(short *)((longlong)&uStackX_1c + lVar20);
                  *(undefined8 *)(&stack0x00000640 + lVar20) =
                       *(undefined8 *)((longlong)&plStackX_10 + lVar20);
                  *(undefined2 **)(&stack0x000011f0 + lVar20) = puVar23;
                  uVar15 = *puVar23;
                  *(undefined2 *)(&stack0x00000170 + lVar20) = uVar15;
                  if (((byte)uVar15 >> 3 & 1) != 0) {
                    if (*(int *)(&stack0x000000c0 + lVar20) == 3) {
                      *(undefined4 *)(&stack0x000000c0 + lVar20) = 4;
                    }
                    else if (*(int *)(&stack0x000000c0 + lVar20) < 2) goto LAB_;
                    puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
                    *(uint **)(&stack0x000011f8 + lVar20) = puVar28;
                    uVar27 = *puVar28;
                    *(uint *)(&stack0x00000470 + lVar20) = uVar27;
                    if ((((uVar27 & 8) != 0) &&
                        (lVar35 = *(longlong *)
                                   (*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90),
                        lVar35 != 0)) &&
                       (*(longlong *)(&stack0x00001200 + lVar20) = lVar35,
                       *(longlong *)(lVar35 + 0x758) != 0)) {
                      uVar26 = *(undefined8 *)(lVar35 + 0x758);
                      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1055db;
                      func_0x
                                (uVar26,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                                 *(undefined4 *)(&stack0x000000c0 + lVar20));
                    }
                  }
LAB_:
                  (&stack0x00000221)[lVar20] = DAT_ >> 7;
                  if ((char)DAT_ < '\0') {
                    puVar28 = (uint *)(*(longlong *)(&stack0x00000640 + lVar20) + 100);
                    *(uint **)(&stack0x00001208 + lVar20) = puVar28;
                    uVar27 = *puVar28;
                    *(uint *)(&stack0x00000478 + lVar20) = uVar27;
                    if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x000000c0 + lVar20))) {
                      *(uint **)(&stack0x00001210 + lVar20) = puVar28;
                      uVar27 = *puVar28;
                      *(uint *)(&stack0x00000480 + lVar20) = uVar27;
                      if (((uVar27 & 0xc0000000) != 0x40000000) &&
                         (lVar35 = **(longlong **)(&stack0x00000640 + lVar20), lVar35 != 0)) {
                        *(undefined4 *)(&stack0x000008d8 + lVar20) = 2;
                        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10566e;
                        iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x000008dc + lVar20);
                        if (iVar16 != 0) {
                          LOCK();
                          *puVar28 = *puVar28 & 0x3fffffff;
                          UNLOCK();
                          LOCK();
                          *puVar28 = *puVar28 | 0x40000000;
                          UNLOCK();
                        }
                      }
                    }
                  }
                  lVar35 = *(longlong *)(&stack0x00000640 + lVar20);
                  uVar19 = *(undefined4 *)(&stack0x000000c0 + lVar20);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10569d;
                  func_0x(lVar35 + 0x98,uVar19);
                  if ((_DAT_ != 0) &&
                     ((&stack0x00000220)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0))
                  {
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1056c7;
                    func_0x(lVar35,0,uVar19);
                  }
                  *(uint *)((longlong)&uStackX_1c + lVar20) =
                       *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
                  *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10552a;
                  func_0x((longlong)&plStackX_10 + lVar20);
                }
                lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
              }
            }
            *(undefined8 *)(&stack0xfffffffffffffff0 + lVar20) =
                 *(undefined8 *)(&stack0x000006f8 + lVar20);
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105713;
            plVar31 = (longlong *)
                      func_0x
                                (_DAT_,*(undefined8 *)(&stack0x000000a0 + lVar20),
                                 &stack0x00000060 + lVar20);
            *(longlong **)((longlong)&plStackX_10 + lVar20) = plVar31;
            uVar27 = *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0002 | 2;
            *(uint *)((longlong)&uStackX_1c + lVar20) = uVar27;
            if (*(longlong *)(&stack0x000002a0 + lVar20) != 0) {
              lVar29 = *plVar31;
              *(longlong *)(&stack0x00001218 + lVar20) = lVar29;
              plVar32 = (longlong *)(*(longlong *)(&stack0x000002a0 + lVar20) + 0x500);
              *(longlong **)(&stack0x00001220 + lVar20) = plVar32;
              plVar31 = plVar32 + (ulonglong)(*(uint *)plVar32 & 0xf) + 1;
              *(longlong **)(&stack0x00001228 + lVar20) = plVar31;
              if (*plVar31 != lVar29) {
                *plVar31 = lVar29;
                *plVar32 = *plVar32 + 1;
                uVar27 = *(uint *)((longlong)&uStackX_1c + lVar20);
              }
            }
            uVar18 = *(uint *)(&stack0x00000280 + lVar20) >> 3 & 1;
            *(uint *)((longlong)&uStackX_1c + lVar20) = uVar18 << 0x18 | uVar27 & 0xffffff;
            *(uint *)((longlong)auStackX_20 + lVar20) =
                 *(uint *)(&stack0x00000280 + lVar20) >> 4 & 1 |
                 *(uint *)((longlong)auStackX_20 + lVar20) & 0xffffff00;
            lVar29 = *(longlong *)(&stack0x00000a00 + lVar20);
            if (((lVar29 != 0) && (*(longlong *)(&stack0x000002a0 + lVar20) != 0)) &&
               (*(longlong *)(&stack0x000002a0 + lVar20) ==
                *(longlong *)(*(longlong *)(&stack0x000000a0 + lVar20) + 0x1c38))) {
              *(uint *)(&stack0x000008e0 + lVar20) = uVar18;
              *(longlong *)(&stack0x00001230 + lVar20) = lVar29 + 0x59b8;
              *(longlong *)(lVar29 + 0x5b28) = *(longlong *)(lVar29 + 0x5b28) + 1;
              puVar28 = *(uint **)(&stack0x000006f8 + lVar20);
              if (puVar28[1] != 0) {
                *(longlong *)(lVar29 + 0x5b30) = *(longlong *)(lVar29 + 0x5b30) + 1;
                *(longlong *)(lVar29 + 0x5b38) =
                     *(longlong *)(lVar29 + 0x5b38) + (ulonglong)*puVar28;
                if (uVar18 != 0) {
                  *(longlong *)(lVar29 + 0x5b40) = *(longlong *)(lVar29 + 0x5b40) + 1;
                  *(longlong *)(lVar29 + 0x5b48) =
                       *(longlong *)(lVar29 + 0x5b48) + (ulonglong)*puVar28;
                }
              }
            }
            lVar29 = *(longlong *)(&stack0x000000a0 + lVar20);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105838;
            cVar12 = func_0x(lVar29);
            if ((cVar12 == '\0') || (*(char *)(lVar29 + 0x2050) == '\0')) goto LAB_;
            if (*(int *)(&stack0x00000060 + lVar20) == 0) {
LAB_:
              (&stack0x00000050)[lVar20] = 1;
              goto LAB_;
            }
            *(undefined4 *)(&stack0x00000798 + lVar20) = 9;
            *(undefined2 *)(&stack0x0000079c + lVar20) = 1;
            if ((*(int *)(&stack0x00000060 + lVar20) == 9) &&
               (*(short *)(&stack0x00000064 + lVar20) == 1)) goto LAB_;
            (&stack0x00000050)[lVar20] = 0;
            lVar35 = **(longlong **)((longlong)&plStackX_10 + lVar20);
            *(longlong *)(&stack0x00001238 + lVar20) = lVar35;
            (&stack0x0000004d)[lVar20] = 0;
            if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
              *(undefined8 *)(&stack0x00000300 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
              *(undefined2 *)(&stack0x00000308 + lVar20) = *(undefined2 *)(lVar35 + 0x30);
            }
            else {
              cVar12 = *(char *)(lVar35 + 1);
              if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                 (*(int *)(lVar35 + 0x18) == 99)) {
                *(undefined **)(&stack0x00001240 + lVar20) = &stack0x00000348 + lVar20;
                *(undefined4 **)(&stack0x00001248 + lVar20) = (undefined4 *)(lVar35 + 0x20);
                *(undefined4 *)(&stack0x00000348 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
                *(undefined2 *)(&stack0x0000034c + lVar20) = *(undefined2 *)(lVar35 + 0x24);
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105905;
                cVar12 = func_0x(&stack0x00000348 + lVar20);
                if (cVar12 == '\0') goto LAB_;
                cVar12 = '\x01';
              }
              else {
LAB_:
                cVar12 = '\0';
              }
              (&stack0x0000004d)[lVar20] = cVar12;
              if (cVar12 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10592a;
              func_0x(lVar35,&stack0x00000300 + lVar20);
            }
            *(undefined **)(&stack0x00001250 + lVar20) = &stack0x00000300 + lVar20;
            lVar35 = *(longlong *)(&stack0x000000a0 + lVar20) + 0x20fc;
            *(longlong *)(&stack0x00000a08 + lVar20) = lVar35;
            *(undefined4 *)(&stack0x000002c0 + lVar20) = 0;
            *(undefined4 *)(&stack0x000002c4 + lVar20) = 0;
            *(undefined2 *)(&stack0x000002c8 + lVar20) = 0;
            *(undefined2 *)(&stack0x000002ca + lVar20) = 0;
            puVar28 = (uint *)(*(longlong *)(&stack0x000000a0 + lVar20) + 0x2108);
            *(uint **)(&stack0x00001258 + lVar20) = puVar28;
            uVar27 = *puVar28;
            *(uint *)(&stack0x000002a8 + lVar20) = uVar27;
            *(uint **)(&stack0x00000a10 + lVar20) = puVar28;
            do {
              *(uint *)(&stack0x00000488 + lVar20) = uVar27 & 0xfffffffe;
              *(undefined8 *)(&stack0x000002c0 + lVar20) =
                   **(undefined8 **)(&stack0x00000a08 + lVar20);
              *(undefined4 *)(&stack0x000002c8 + lVar20) =
                   *(undefined4 *)(*(undefined8 **)(&stack0x00000a08 + lVar20) + 1);
              LOCK();
              *(undefined4 *)(&stack0xffffffffffffffc8 + lVar20) =
                   *(undefined4 *)(&stack0xffffffffffffffc8 + lVar20);
              UNLOCK();
              uVar27 = **(uint **)(&stack0x00000a10 + lVar20);
              *(uint *)(&stack0x000002a8 + lVar20) = uVar27;
            } while (*(uint *)(&stack0x00000488 + lVar20) != uVar27);
            if (*(uint *)(&stack0x00000300 + lVar20) <= *(uint *)(&stack0x000002c0 + lVar20)) {
              if (*(uint *)(&stack0x000002c0 + lVar20) != *(uint *)(&stack0x00000300 + lVar20))
              goto LAB_;
              uVar27 = (uint)((ulonglong)*(undefined8 *)(&stack0x000002c0 + lVar20) >> 0x20);
              if (*(uint *)(&stack0x00000304 + lVar20) <= uVar27) {
                if (uVar27 != *(uint *)(&stack0x00000304 + lVar20)) goto LAB_;
                if (*(ushort *)(&stack0x00000308 + lVar20) <= *(ushort *)(&stack0x000002c8 + lVar20)
                   ) {
                  lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
                  goto LAB_;
                }
              }
            }
            if (*(char *)(*(longlong *)(&stack0x000000a0 + lVar20) + 0x6ac8) != '\0') {
LAB_:
              if ((&stack0x00000028)[lVar20] != '\0') {
                lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
                goto LAB_;
              }
              lVar35 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x00001328 + lVar20) = lVar35;
              lVar35 = (ulonglong)*_DAT_ +
                       *(longlong *)(lVar35 + (ulonglong)*_DAT_ * 8);
              *(longlong *)(&stack0x00001330 + lVar20) = lVar35;
              lVar35 = *(longlong *)(lVar35 + 8);
              *(longlong *)(&stack0x00001338 + lVar20) = lVar35;
              lVar35 = *(longlong *)(lVar35 + 0x60);
              *(longlong *)(&stack0x00001340 + lVar20) = lVar35;
              if (lVar35 == *(longlong *)(*(longlong *)(&stack0x000000a0 + lVar20) + 0x2120))
              goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10616f;
              cVar12 = func_0x(*(longlong *)(&stack0x000000a0 + lVar20));
              if (cVar12 != '\0') goto LAB_;
              if (*(longlong *)(&stack0x000002a0 + lVar20) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106182;
                uVar26 = func_0x();
                *(undefined8 *)(&stack0x000002a0 + lVar20) = uVar26;
              }
              *(undefined **)(&stack0x00001348 + lVar20) = &stack0x000002e0 + lVar20;
              lVar35 = **(longlong **)((longlong)&plStackX_10 + lVar20);
              *(longlong *)(&stack0x00001350 + lVar20) = lVar35;
              (&stack0x0000004f)[lVar20] = 0;
              if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
                uVar26 = *(undefined8 *)(lVar35 + 0x28);
                *(undefined8 *)(&stack0x000002e0 + lVar20) = uVar26;
                uVar15 = *(undefined2 *)(lVar35 + 0x30);
                *(undefined2 *)(&stack0x000002e8 + lVar20) = uVar15;
              }
              else {
                cVar12 = *(char *)(lVar35 + 1);
                if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                   (*(int *)(lVar35 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00001358 + lVar20) = &stack0x00000338 + lVar20;
                  *(undefined4 **)(&stack0x00001360 + lVar20) = (undefined4 *)(lVar35 + 0x20);
                  *(undefined4 *)(&stack0x00000338 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
                  *(undefined2 *)(&stack0x0000033c + lVar20) = *(undefined2 *)(lVar35 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106213;
                  cVar12 = func_0x(&stack0x00000338 + lVar20);
                  if (cVar12 == '\0') goto LAB_;
                  cVar12 = '\x01';
                }
                else {
LAB_:
                  cVar12 = '\0';
                }
                (&stack0x0000004f)[lVar20] = cVar12;
                if (cVar12 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106238;
                func_0x(lVar35,&stack0x000002e0 + lVar20);
                uVar15 = *(undefined2 *)(&stack0x000002e8 + lVar20);
                uVar26 = *(undefined8 *)(&stack0x000002e0 + lVar20);
              }
              *(undefined **)(&stack0x00001368 + lVar20) = &stack0x000002e0 + lVar20;
              *(undefined8 *)(&stack0x00000370 + lVar20) = uVar26;
              *(undefined2 *)(&stack0x00000378 + lVar20) = uVar15;
              *(undefined2 *)(&stack0x0000037a + lVar20) = 0;
              if (*(longlong *)((longlong)&plStackX_10 + lVar20) != 0) {
                puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x62);
                *(undefined2 **)(&stack0x00001370 + lVar20) = puVar23;
                *(undefined2 *)(&stack0x00000218 + lVar20) = *puVar23;
                if (((*(ushort *)(&stack0x00000218 + lVar20) & 0x400) == 0) ||
                   (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
                  *(int *)(&stack0x000000b8 + lVar20) =
                       (int)*(short *)((longlong)&uStackX_1c + lVar20);
                  *(undefined8 *)(&stack0x00000648 + lVar20) =
                       *(undefined8 *)((longlong)&plStackX_10 + lVar20);
                  *(undefined2 **)(&stack0x00001378 + lVar20) = puVar23;
                  uVar15 = *puVar23;
                  *(undefined2 *)(&stack0x00000118 + lVar20) = uVar15;
                  if (((byte)uVar15 >> 3 & 1) != 0) {
                    if (*(int *)(&stack0x000000b8 + lVar20) == 3) {
                      *(undefined4 *)(&stack0x000000b8 + lVar20) = 4;
                    }
                    else if (*(int *)(&stack0x000000b8 + lVar20) < 2) goto LAB_;
                    puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
                    *(uint **)(&stack0x00001380 + lVar20) = puVar28;
                    uVar27 = *puVar28;
                    *(uint *)(&stack0x00000498 + lVar20) = uVar27;
                    if ((((uVar27 & 8) != 0) &&
                        (lVar35 = *(longlong *)
                                   (*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90),
                        lVar35 != 0)) &&
                       (*(longlong *)(&stack0x00001388 + lVar20) = lVar35,
                       *(longlong *)(lVar35 + 0x758) != 0)) {
                      uVar26 = *(undefined8 *)(lVar35 + 0x758);
                      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10638e;
                      func_0x
                                (uVar26,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                                 *(undefined4 *)(&stack0x000000b8 + lVar20));
                    }
                  }
LAB_:
                  (&stack0x000001ce)[lVar20] = DAT_ >> 7;
                  if ((char)DAT_ < '\0') {
                    puVar28 = (uint *)(*(longlong *)(&stack0x00000648 + lVar20) + 100);
                    *(uint **)(&stack0x00001390 + lVar20) = puVar28;
                    uVar27 = *puVar28;
                    *(uint *)(&stack0x000004a0 + lVar20) = uVar27;
                    if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x000000b8 + lVar20))) {
                      *(uint **)(&stack0x00001398 + lVar20) = puVar28;
                      uVar27 = *puVar28;
                      *(uint *)(&stack0x000004a8 + lVar20) = uVar27;
                      if (((uVar27 & 0xc0000000) != 0x40000000) &&
                         (lVar35 = **(longlong **)(&stack0x00000648 + lVar20), lVar35 != 0)) {
                        *(undefined4 *)(&stack0x000008f4 + lVar20) = 2;
                        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106421;
                        iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x000008f8 + lVar20);
                        if (iVar16 != 0) {
                          LOCK();
                          *puVar28 = *puVar28 & 0x3fffffff;
                          UNLOCK();
                          LOCK();
                          *puVar28 = *puVar28 | 0x40000000;
                          UNLOCK();
                        }
                      }
                    }
                  }
                  lVar35 = *(longlong *)(&stack0x00000648 + lVar20);
                  uVar19 = *(undefined4 *)(&stack0x000000b8 + lVar20);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106450;
                  func_0x(lVar35 + 0x98,uVar19);
                  if ((_DAT_ != 0) &&
                     ((&stack0x000001cd)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0))
                  {
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10647a;
                    func_0x(lVar35,0,uVar19);
                  }
                  *(uint *)((longlong)&uStackX_1c + lVar20) =
                       *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
                  *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1062dd;
                  func_0x((longlong)&plStackX_10 + lVar20);
                }
                uVar26 = *(undefined8 *)(&stack0x00000370 + lVar20);
                uVar15 = *(undefined2 *)(&stack0x00000378 + lVar20);
              }
              *(undefined **)(&stack0x000013a0 + lVar20) = &stack0x000007d0 + lVar20;
              *(undefined8 *)(&stack0x000007d0 + lVar20) = uVar26;
              *(undefined2 *)(&stack0x000007d8 + lVar20) = uVar15;
              *(undefined **)(&stack0x000013a8 + lVar20) = &stack0x000006a0 + lVar20;
              *(undefined8 *)(&stack0x000006a0 + lVar20) = uVar26;
              *(undefined2 *)(&stack0x000006a8 + lVar20) = uVar15;
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar20) = 0;
              uVar26 = *(undefined8 *)(lVar36 + 0x728);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1064ff;
              func_0x(uVar26,&stack0x000006a0 + lVar20,4);
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
              goto LAB_;
            }
            lVar29 = *(longlong *)(unaff_GS_OFFSET + 0x58);
            *(longlong *)(&stack0x00001260 + lVar20) = lVar29;
            lVar29 = (ulonglong)*_DAT_ +
                     *(longlong *)(lVar29 + (ulonglong)*_DAT_ * 8);
            *(longlong *)(&stack0x00001268 + lVar20) = lVar29;
            lVar29 = *(longlong *)(lVar29 + 8);
            *(longlong *)(&stack0x00001270 + lVar20) = lVar29;
            lVar29 = *(longlong *)(lVar29 + 0x60);
            *(longlong *)(&stack0x00001278 + lVar20) = lVar29;
            if (lVar29 == *(longlong *)(*(longlong *)(&stack0x000000a0 + lVar20) + 0x2120))
            goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105ac0;
            cVar12 = func_0x(*(longlong *)(&stack0x000000a0 + lVar20));
            if (cVar12 != '\0') goto LAB_;
            *(longlong *)(&stack0x00000708 + lVar20) = lVar35;
            *(undefined4 *)(&stack0x00000268 + lVar20) = 0;
            *(undefined4 *)(&stack0x0000026c + lVar20) = 0;
            *(undefined2 *)(&stack0x00000270 + lVar20) = 0;
            *(undefined2 *)(&stack0x00000272 + lVar20) = 0;
            *(uint **)(&stack0x00001280 + lVar20) = puVar28;
            uVar27 = *puVar28;
            *(uint *)(&stack0x000002ac + lVar20) = uVar27;
            puVar33 = *(undefined8 **)(&stack0x00000708 + lVar20);
            *(longlong *)(&stack0x00000a18 + lVar20) = (longlong)puVar33 + 0xc;
            while( true ) {
              *(uint *)(&stack0x0000048c + lVar20) = uVar27 & 0xfffffffe;
              *(undefined8 *)(&stack0x00000268 + lVar20) = *puVar33;
              *(undefined4 *)(&stack0x00000270 + lVar20) = *(undefined4 *)(puVar33 + 1);
              LOCK();
              *(undefined4 *)(&stack0xffffffffffffffc8 + lVar20) =
                   *(undefined4 *)(&stack0xffffffffffffffc8 + lVar20);
              UNLOCK();
              uVar27 = **(uint **)(&stack0x00000a18 + lVar20);
              *(uint *)(&stack0x000002ac + lVar20) = uVar27;
              if (*(uint *)(&stack0x0000048c + lVar20) == uVar27) break;
              puVar33 = *(undefined8 **)(&stack0x00000708 + lVar20);
            }
            *(undefined8 *)(&stack0x000007c0 + lVar20) = *(undefined8 *)(&stack0x00000268 + lVar20);
            uVar5 = *(ushort *)(&stack0x00000270 + lVar20);
            *(ushort *)(&stack0x000007c8 + lVar20) = uVar5;
            lVar35 = **(longlong **)((longlong)&plStackX_10 + lVar20);
            *(longlong *)(&stack0x00001288 + lVar20) = lVar35;
            (&stack0x0000004e)[lVar20] = 0;
            if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
              *(undefined8 *)(&stack0x000002f0 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
              uVar6 = *(ushort *)(lVar35 + 0x30);
              *(ushort *)(&stack0x000002f8 + lVar20) = uVar6;
            }
            else {
              cVar12 = *(char *)(lVar35 + 1);
              if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                 (*(int *)(lVar35 + 0x18) == 99)) {
                *(undefined **)(&stack0x00001290 + lVar20) = &stack0x00000340 + lVar20;
                *(undefined4 **)(&stack0x00001298 + lVar20) = (undefined4 *)(lVar35 + 0x20);
                *(undefined4 *)(&stack0x00000340 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
                *(undefined2 *)(&stack0x00000344 + lVar20) = *(undefined2 *)(lVar35 + 0x24);
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105c05;
                cVar12 = func_0x(&stack0x00000340 + lVar20);
                if (cVar12 == '\0') goto LAB_;
                cVar12 = '\x01';
              }
              else {
LAB_:
                cVar12 = '\0';
              }
              (&stack0x0000004e)[lVar20] = cVar12;
              if (cVar12 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105c2a;
              func_0x(lVar35,&stack0x000002f0 + lVar20);
              uVar6 = *(ushort *)(&stack0x000002f8 + lVar20);
            }
            if (*(uint *)(&stack0x00000268 + lVar20) < *(uint *)(&stack0x000002f0 + lVar20)) {
LAB_:
              lVar35 = *(longlong *)(&stack0x000000a0 + lVar20);
              lVar36 = *(longlong *)(lVar35 + 0x6b0);
              *(longlong *)(&stack0x000012a0 + lVar20) = lVar36;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105cc7;
              func_0x(&stack0x000002f0 + lVar20,&stack0x000025d0 + lVar20,
                              &stack0x00000490 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105ce4;
              func_0x(&stack0x000007c0 + lVar20,&stack0x00002600 + lVar20,
                              &stack0x00000490 + lVar20);
              *(undefined4 *)(&stack0x00000a20 + lVar20) = 0x1d;
              *(undefined4 *)(&stack0x00000a24 + lVar20) = 0x10000;
              if ((_DAT_ & 0x10000) != 0) {
                *(undefined2 *)(&stack0x000003a0 + lVar20) = 6;
                *(undefined **)(&stack0x000012a8 + lVar20) = &stack0x00001630 + lVar20;
                *(undefined2 *)(&stack0x00001630 + lVar20) = 0;
                *(undefined2 *)(&stack0x00001632 + lVar20) = 6;
                *(undefined4 *)(&stack0x00001638 + lVar20) = 0;
                *(undefined **)(&stack0x00001640 + lVar20) = &stack0x00001658 + lVar20;
                *(undefined **)(&stack0x00001648 + lVar20) = &stack0x000016b8 + lVar20;
                *(undefined4 *)(&stack0x00001878 + lVar20) = 0;
                *(undefined4 *)(&stack0x0000187c + lVar20) = 0;
                *(undefined8 *)(&stack0x00001650 + lVar20) = 0;
                *(undefined8 *)(&stack0x00001880 + lVar20) = 0;
                *(undefined **)(&stack0x000012b0 + lVar20) = &stack0x00001658 + lVar20;
                *(undefined **)(&stack0x00001658 + lVar20) = &stack0x00001888 + lVar20;
                *(undefined4 *)(&stack0x00001660 + lVar20) = 0x34;
                *(undefined2 *)(&stack0x00001664 + lVar20) = 5;
                *(undefined2 *)(&stack0x00001666 + lVar20) = 0;
                *(undefined **)(&stack0x000012b8 + lVar20) = &stack0x00001668 + lVar20;
                *(undefined8 *)(&stack0x00001668 + lVar20) = 0x1842ae8;
                *(undefined4 *)(&stack0x00001670 + lVar20) = 0x10;
                *(undefined2 *)(&stack0x00001674 + lVar20) = 5;
                *(undefined2 *)(&stack0x00001676 + lVar20) = 0;
                *(undefined **)(&stack0x000012c0 + lVar20) = &stack0x00001678 + lVar20;
                *(undefined8 *)(&stack0x00001678 + lVar20) = 0x1842ae8;
                *(undefined4 *)(&stack0x00001680 + lVar20) = 0x10;
                *(undefined2 *)(&stack0x00001684 + lVar20) = 6;
                *(undefined2 *)(&stack0x00001686 + lVar20) = 0;
                *(undefined **)(&stack0x000012c8 + lVar20) = &stack0x00001688 + lVar20;
                *(undefined8 *)(&stack0x00001688 + lVar20) = 0;
                *(undefined4 *)(&stack0x00001690 + lVar20) = 0;
                *(undefined2 *)(&stack0x00001694 + lVar20) = 7;
                *(undefined2 *)(&stack0x00001696 + lVar20) = 0;
                *(undefined **)(&stack0x000012d0 + lVar20) = &stack0x00001698 + lVar20;
                *(undefined8 *)(&stack0x00001698 + lVar20) = 0;
                *(undefined4 *)(&stack0x000016a0 + lVar20) = 0;
                *(undefined2 *)(&stack0x000016a4 + lVar20) = 8;
                *(undefined2 *)(&stack0x000016a6 + lVar20) = 0;
                *(undefined **)(&stack0x000012d8 + lVar20) = &stack0x000016a8 + lVar20;
                *(undefined8 *)(&stack0x000016a8 + lVar20) = 0;
                *(undefined4 *)(&stack0x000016b0 + lVar20) = 0;
                *(undefined2 *)(&stack0x000016b4 + lVar20) = 9;
                *(undefined2 *)(&stack0x000016b6 + lVar20) = 0;
                *(uint *)(&stack0x00001888 + lVar20) = (uint)*(ushort *)(lVar35 + 0x6b8);
                *(undefined2 *)(&stack0x0000188c + lVar20) =
                     *(undefined2 *)(&stack0x00000064 + lVar20);
                *(undefined4 *)(&stack0x0000188e + lVar20) =
                     *(undefined4 *)(&stack0x00000060 + lVar20);
                (&stack0x00001892)[lVar20] = (&stack0x00000029)[lVar20];
                lVar35 = **(longlong **)((longlong)&plStackX_10 + lVar20);
                *(longlong *)(&stack0x000012e0 + lVar20) = lVar35;
                (&stack0x00001893)[lVar20] = *(undefined *)(lVar35 + 1);
                *(undefined **)(&stack0x000012e8 + lVar20) = &stack0x00001668 + lVar20;
                *(longlong *)(&stack0x00001668 + lVar20) = lVar36 + 0x254;
                *(undefined4 *)(&stack0x00001670 + lVar20) = 0x10;
                *(undefined2 *)(&stack0x00001674 + lVar20) = 5;
                *(undefined2 *)(&stack0x00001676 + lVar20) = 0;
                *(undefined **)(&stack0x000012f0 + lVar20) = &stack0x00001678 + lVar20;
                *(longlong *)(&stack0x00001678 + lVar20) = lVar36 + 0x244;
                *(undefined4 *)(&stack0x00001680 + lVar20) = 0x10;
                *(undefined2 *)(&stack0x00001684 + lVar20) = 6;
                *(undefined2 *)(&stack0x00001686 + lVar20) = 0;
                *(undefined **)(&stack0x000012f8 + lVar20) = &stack0x000025d0 + lVar20;
                lVar35 = -1;
                do {
                  lVar35 = lVar35 + 1;
                } while (*(short *)(&stack0x000025d0 + lVar35 * 2 + lVar20) != 0);
                iVar16 = (int)lVar35 * 2;
                *(int *)(&stack0x000008e8 + lVar20) = iVar16;
                *(undefined **)(&stack0x00001300 + lVar20) = &stack0x00001688 + lVar20;
                *(undefined **)(&stack0x00001688 + lVar20) = &stack0x000025d0 + lVar20;
                *(int *)(&stack0x00001690 + lVar20) = iVar16;
                *(undefined2 *)(&stack0x00001694 + lVar20) = 7;
                *(undefined2 *)(&stack0x00001696 + lVar20) = 0;
                *(undefined **)(&stack0x00001308 + lVar20) = &stack0x00002600 + lVar20;
                lVar35 = -1;
                do {
                  lVar35 = lVar35 + 1;
                } while (*(short *)(&stack0x00002600 + lVar35 * 2 + lVar20) != 0);
                iVar16 = (int)lVar35 * 2;
                *(int *)(&stack0x000008ec + lVar20) = iVar16;
                *(undefined **)(&stack0x00001310 + lVar20) = &stack0x00001698 + lVar20;
                *(undefined **)(&stack0x00001698 + lVar20) = &stack0x00002600 + lVar20;
                *(int *)(&stack0x000016a0 + lVar20) = iVar16;
                *(undefined2 *)(&stack0x000016a4 + lVar20) = 8;
                *(undefined2 *)(&stack0x000016a6 + lVar20) = 0;
                *(undefined4 *)(&stack0x00000494 + lVar20) = 0;
                UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10609f;
                lVar35 = (*UNRECOVERED_JUMPTABLE_00)(lVar36,&stack0x00000494 + lVar20);
                *(longlong *)(&stack0x00001318 + lVar20) = lVar35;
                iVar16 = 0;
                if (lVar35 != 0) {
                  lVar36 = -1;
                  do {
                    lVar36 = lVar36 + 1;
                  } while (*(short *)(lVar35 + lVar36 * 2) != 0);
                  iVar16 = (int)lVar36 * 2;
                }
                *(int *)(&stack0x000008f0 + lVar20) = iVar16;
                lVar36 = *(longlong *)(&stack0x00001640 + lVar20);
                *(longlong **)(&stack0x00001320 + lVar20) = (longlong *)(lVar36 + 0x50);
                *(longlong *)(lVar36 + 0x50) = lVar35;
                *(int *)(lVar36 + 0x58) = iVar16;
                *(undefined2 *)(lVar36 + 0x5c) = 9;
                *(undefined2 *)(lVar36 + 0x5e) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1060fa;
                func_0x(&stack0x00001628 + lVar20);
              }
LAB_:
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
            }
            else {
              if (*(uint *)(&stack0x00000268 + lVar20) != *(uint *)(&stack0x000002f0 + lVar20))
              goto LAB_;
              uVar27 = (uint)((ulonglong)*(undefined8 *)(&stack0x000002f0 + lVar20) >> 0x20);
              if (*(uint *)(&stack0x0000026c + lVar20) < uVar27) goto LAB_;
              if (*(uint *)(&stack0x0000026c + lVar20) != uVar27) goto LAB_;
              if (uVar5 < uVar6) goto LAB_;
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
            }
LAB_:
            if ((1 < *(short *)((longlong)&uStackX_1c + lVar20)) &&
               ((&stack0x00000029)[lVar20] != -1)) {
              lVar36 = **(longlong **)((longlong)&plStackX_10 + lVar20);
              *(longlong *)(&stack0x000013b0 + lVar20) = lVar36;
              if (*(char *)(lVar36 + 1) != (&stack0x00000029)[lVar20]) {
                if (*(longlong *)(&stack0x000002a0 + lVar20) != 0) {
                  *(longlong *)(&stack0x000013b8 + lVar20) = lVar36;
                  *(longlong *)(*(longlong *)(&stack0x000002a0 + lVar20) + 0x588) = lVar36;
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10656b;
                lVar36 = func_0x();
                if (lVar36 == 0) {
LAB_:
                  *(undefined4 *)(&stack0x000004b0 + lVar20) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106575;
                  lVar36 = func_0x();
                  if (*(longlong *)(lVar36 + 0x30) == 0) goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106580;
                  lVar36 = func_0x();
                  uVar27 = *(uint *)(*(longlong *)(lVar36 + 0x30) + 0xc);
                  *(uint *)(&stack0x000008fc + lVar20) = uVar27;
                  if ((0xd < uVar27) || (iVar16 = 1, (0x2640U >> (uVar27 & 0x1f) & 1) == 0)) {
                    iVar16 = 0;
                  }
                  *(int *)(&stack0x000004b0 + lVar20) = iVar16;
                  if (iVar16 != 0) goto LAB_;
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1065c6;
                func_0x(0,8);
              }
            }
LAB_:
            *(undefined4 *)(&stack0x000007e0 + lVar20) = 0;
            *(undefined4 *)(&stack0x000007e4 + lVar20) = 0;
            *(undefined2 *)(&stack0x000007e8 + lVar20) = 0;
            if (((*(short *)(&stack0x00000368 + lVar20) == 0) &&
                (*(int *)(&stack0x00000360 + lVar20) == 0)) &&
               (*(int *)(&stack0x00000364 + lVar20) == 0)) goto LAB_;
            lVar36 = **(longlong **)((longlong)&plStackX_10 + lVar20);
            *(longlong *)(&stack0x000013c0 + lVar20) = lVar36;
            if ((*(byte *)(lVar36 + 4) & 1) == 0) goto LAB_;
            puVar23 = (undefined2 *)
                      ((longlong)*(longlong **)((longlong)&plStackX_10 + lVar20) + 0x62);
            *(undefined2 **)(&stack0x000013c8 + lVar20) = puVar23;
            *(undefined2 *)(&stack0x00000120 + lVar20) = *puVar23;
            if (((*(ushort *)(&stack0x00000120 + lVar20) & 0x400) == 0) ||
               (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
              *(int *)(&stack0x000000b0 + lVar20) = (int)*(short *)((longlong)&uStackX_1c + lVar20);
              *(undefined8 *)(&stack0x00000650 + lVar20) =
                   *(undefined8 *)((longlong)&plStackX_10 + lVar20);
              *(undefined2 **)(&stack0x000013d0 + lVar20) = puVar23;
              uVar15 = *puVar23;
              *(undefined2 *)(&stack0x00000128 + lVar20) = uVar15;
              if (((byte)uVar15 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000b0 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x000000b0 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x000000b0 + lVar20) < 2) goto LAB_;
                puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
                *(uint **)(&stack0x000013d8 + lVar20) = puVar28;
                uVar27 = *puVar28;
                *(uint *)(&stack0x000004b8 + lVar20) = uVar27;
                if ((((uVar27 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x000013e0 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar26 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10670a;
                  func_0x
                            (uVar26,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                             *(undefined4 *)(&stack0x000000b0 + lVar20));
                }
              }
LAB_:
              (&stack0x000001cc)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000650 + lVar20) + 100);
                *(uint **)(&stack0x000013e8 + lVar20) = puVar28;
                uVar27 = *puVar28;
                *(uint *)(&stack0x000004c0 + lVar20) = uVar27;
                if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x000000b0 + lVar20))) {
                  *(uint **)(&stack0x000013f0 + lVar20) = puVar28;
                  uVar27 = *puVar28;
                  *(uint *)(&stack0x000004c8 + lVar20) = uVar27;
                  if (((uVar27 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000650 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x00000900 + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10679d;
                    iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000904 + lVar20);
                    if (iVar16 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000650 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x000000b0 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1067cc;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x000001cb)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1067f6;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)&uStackX_1c + lVar20) =
                   *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
              *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106658;
              func_0x((longlong)&plStackX_10 + lVar20);
            }
            *(undefined4 *)(&stack0x00000ad8 + lVar20) = 0x400060;
            *(undefined8 *)(&stack0x00000ae0 + lVar20) = 0;
            *(undefined8 *)(&stack0x00000af0 + lVar20) = 0;
            *(undefined8 *)(&stack0x00000ae8 + lVar20) = 0;
            *(undefined8 *)(&stack0x00000af8 + lVar20) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106840;
            func_0x(10,&stack0x00000ad8 + lVar20);
            lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
          } while( true );
        }
        if (*(int *)(param_1 + 0xd0) != 2) {
          *(longlong **)(&stack0x00000630 + lVar20) = (longlong *)(param_1 + 0x68);
          lVar35 = *(longlong *)(param_1 + 0x68);
          if (lVar35 != 0) {
            puVar23 = (undefined2 *)(lVar35 + 0x62);
            *(undefined2 **)(&stack0x000010f0 + lVar20) = puVar23;
            *(undefined2 *)(&stack0x00000198 + lVar20) = *puVar23;
            plVar31 = *(longlong **)(&stack0x00000630 + lVar20);
            if (((*(ushort *)(&stack0x00000198 + lVar20) & 0x400) == 0) ||
               (*(short *)((longlong)plVar31 + 0xc) < 3)) {
              *(int *)(&stack0x000000d0 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
              lVar35 = *plVar31;
              *(longlong *)(&stack0x00000238 + lVar20) = lVar35;
              puVar23 = (undefined2 *)(lVar35 + 0x62);
              *(undefined2 **)(&stack0x000010f8 + lVar20) = puVar23;
              uVar15 = *puVar23;
              *(undefined2 *)(&stack0x00000190 + lVar20) = uVar15;
              if (((byte)uVar15 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000d0 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x000000d0 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x000000d0 + lVar20) < 2) goto LAB_;
                *(uint **)(&stack0x00001100 + lVar20) =
                     (uint *)(*(longlong *)(&stack0x00000238 + lVar20) + 100);
                uVar27 = *(uint *)(*(longlong *)(&stack0x00000238 + lVar20) + 100);
                *(uint *)(&stack0x00000438 + lVar20) = uVar27;
                if ((((uVar27 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000238 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x00001108 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar40 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x104d23;
                  func_0x
                            (uVar40,*(undefined8 *)(&stack0x00000238 + lVar20),
                             *(undefined4 *)(&stack0x000000d0 + lVar20));
                }
              }
LAB_:
              (&stack0x0000010c)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000238 + lVar20) + 100);
                *(uint **)(&stack0x00001110 + lVar20) = puVar28;
                uVar27 = *puVar28;
                *(uint *)(&stack0x00000440 + lVar20) = uVar27;
                if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x000000d0 + lVar20))) {
                  *(uint **)(&stack0x00001118 + lVar20) = puVar28;
                  uVar27 = *puVar28;
                  *(uint *)(&stack0x00000448 + lVar20) = uVar27;
                  if (((uVar27 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000238 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x000008c0 + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x104db6;
                    iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x000008c4 + lVar20);
                    if (iVar16 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000238 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x000000d0 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x104de5;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x0000010d)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x104e0f;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x00000630 + lVar20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x104c60;
              func_0x(plVar31);
            }
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          *(undefined8 **)(&stack0x00001120 + lVar20) = (undefined8 *)(param_1 + 0x88);
          if (*(int *)(param_1 + 0x90) != 0) {
            *(undefined4 *)(&stack0x000008c8 + lVar20) = *(undefined4 *)(param_1 + 0x94);
            *(undefined8 *)(&stack0x00001128 + lVar20) = *(undefined8 *)(param_1 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x104e5e;
            func_0x();
            *(undefined4 *)(param_1 + 0x90) = 0;
          }
          *(undefined4 *)(&stack0x00000100 + lVar20) = 0;
          *(undefined2 *)(&stack0x00000104 + lVar20) = 0;
          *(undefined4 **)(&stack0x00001130 + lVar20) = (undefined4 *)(param_1 + 0x9c);
          *(undefined4 *)(param_1 + 0x9c) = 0;
          *(undefined2 *)(param_1 + 0xa0) = 0;
          *(undefined4 *)(&stack0x000006b0 + lVar20) = 0;
          *(undefined4 *)(&stack0x000006b4 + lVar20) = 0;
          *(undefined2 *)(&stack0x000006b8 + lVar20) = 0;
          *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x000006b0 + lVar20);
          *(undefined2 *)(param_1 + 0xc4) = 0;
          *(undefined4 *)(param_1 + 0xd0) = 2;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x104ed3;
        func_0x((longlong)&plStackX_10 + lVar20);
        goto LAB_;
      }
      piVar38 = *(int **)(&stack0x00000728 + lVar20);
LAB_:
      if (*piVar38 == 0) {
        if (*(int *)(param_1 + 0xd0) != 2) {
          *(longlong **)(&stack0x00000678 + lVar20) = (longlong *)(param_1 + 0x68);
          lVar35 = *(longlong *)(param_1 + 0x68);
          if (lVar35 != 0) {
            puVar23 = (undefined2 *)(lVar35 + 0x62);
            *(undefined2 **)(&stack0x000014e0 + lVar20) = puVar23;
            *(undefined2 *)(&stack0x00000160 + lVar20) = *puVar23;
            plVar31 = *(longlong **)(&stack0x00000678 + lVar20);
            if (((*(ushort *)(&stack0x00000160 + lVar20) & 0x400) == 0) ||
               (*(short *)((longlong)plVar31 + 0xc) < 3)) {
              *(int *)(&stack0x00000090 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
              lVar35 = *plVar31;
              *(longlong *)(&stack0x00000248 + lVar20) = lVar35;
              puVar23 = (undefined2 *)(lVar35 + 0x62);
              *(undefined2 **)(&stack0x000014e8 + lVar20) = puVar23;
              uVar15 = *puVar23;
              *(undefined2 *)(&stack0x00000168 + lVar20) = uVar15;
              if (((byte)uVar15 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x00000090 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x00000090 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x00000090 + lVar20) < 2) goto LAB_;
                *(uint **)(&stack0x000014f0 + lVar20) =
                     (uint *)(*(longlong *)(&stack0x00000248 + lVar20) + 100);
                uVar27 = *(uint *)(*(longlong *)(&stack0x00000248 + lVar20) + 100);
                *(uint *)(&stack0x00000520 + lVar20) = uVar27;
                if ((((uVar27 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000248 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x000014f8 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar40 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1074d6;
                  func_0x
                            (uVar40,*(undefined8 *)(&stack0x00000248 + lVar20),
                             *(undefined4 *)(&stack0x00000090 + lVar20));
                }
              }
LAB_:
              (&stack0x000001c3)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000248 + lVar20) + 100);
                *(uint **)(&stack0x00001500 + lVar20) = puVar28;
                uVar27 = *puVar28;
                *(uint *)(&stack0x00000528 + lVar20) = uVar27;
                if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x00000090 + lVar20))) {
                  *(uint **)(&stack0x00001508 + lVar20) = puVar28;
                  uVar27 = *puVar28;
                  *(uint *)(&stack0x00000530 + lVar20) = uVar27;
                  if (((uVar27 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000248 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x00000924 + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107564;
                    iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000928 + lVar20);
                    if (iVar16 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000248 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x00000090 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107593;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x000001d8)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1075bd;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x00000678 + lVar20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107343;
              func_0x(plVar31);
            }
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          *(undefined8 **)(&stack0x00001510 + lVar20) = (undefined8 *)(param_1 + 0x88);
          if (*(int *)(param_1 + 0x90) != 0) {
            *(undefined4 *)(&stack0x00000930 + lVar20) = *(undefined4 *)(param_1 + 0x94);
            *(undefined8 *)(&stack0x00001518 + lVar20) = *(undefined8 *)(param_1 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107382;
            func_0x();
            *(undefined4 *)(param_1 + 0x90) = 0;
          }
          *(undefined4 *)(&stack0x00000040 + lVar20) = 0;
          *(undefined2 *)(&stack0x00000044 + lVar20) = 0;
          *(undefined4 **)(&stack0x00001520 + lVar20) = (undefined4 *)(param_1 + 0x9c);
          *(undefined4 *)(param_1 + 0x9c) = 0;
          *(undefined2 *)(param_1 + 0xa0) = 0;
          *(undefined4 *)(&stack0x000006e0 + lVar20) = 0;
          *(undefined4 *)(&stack0x000006e4 + lVar20) = 0;
          *(undefined2 *)(&stack0x000006e8 + lVar20) = 0;
          *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x000006e0 + lVar20);
          *(undefined2 *)(param_1 + 0xc4) = 0;
          *(undefined4 *)(param_1 + 0xd0) = 2;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1073e9;
        func_0x((longlong)&plStackX_10 + lVar20);
        goto LAB_;
      }
      **(undefined4 **)(&stack0x00000a30 + lVar20) = *(undefined4 *)(&stack0x00000210 + lVar20);
      param_4 = *(int **)(&stack0x00000538 + lVar20);
      puVar23 = *(undefined2 **)(&stack0x00000540 + lVar20);
    }
    lVar36 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar35 = *(longlong *)(lVar36 + 0x100);
    if (lVar35 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107607;
      (*_DAT_)();
      lVar35 = *(longlong *)(lVar36 + 0x100);
    }
    if (*(int *)(lVar35 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10761d;
      (*_DAT_)();
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107628;
  func_0x((longlong)&plStackX_10 + lVar20);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107638;
  func_0x
            (*(ulonglong *)(&stack0x00002630 + lVar20) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar20));
  return;
LAB_:
  lVar36 = *(longlong *)(&stack0x00000658 + lVar20);
  *(int *)(lVar36 + 4) = *(int *)(lVar36 + 4) + 1;
  if (*(longlong *)(lVar36 + 0x58) != 0) {
    piVar34 = (int *)(*(longlong *)(lVar36 + 0x58) + 4);
    *piVar34 = *piVar34 + 1;
  }
  if ((*(uint *)((longlong)&uStackX_1c + lVar20) & 0xff000000) != 0) {
    *(int *)(*(longlong *)(&stack0x00000658 + lVar20) + 8) =
         *(int *)(*(longlong *)(&stack0x00000658 + lVar20) + 8) + 1;
    if (*(longlong *)(lVar36 + 0x58) != 0) {
      piVar34 = (int *)(*(longlong *)(lVar36 + 0x58) + 8);
      *piVar34 = *piVar34 + 1;
    }
    if (*(char *)((longlong)auStackX_20 + lVar20) != '\0') {
      *(int *)(*(longlong *)(&stack0x00000658 + lVar20) + 0xc) =
           *(int *)(*(longlong *)(&stack0x00000658 + lVar20) + 0xc) + 1;
      if (*(longlong *)(lVar36 + 0x58) != 0) {
        piVar34 = (int *)(*(longlong *)(lVar36 + 0x58) + 0xc);
        *piVar34 = *piVar34 + 1;
      }
    }
  }
  if (*(int *)(&stack0x00000ab4 + lVar20) != 0) {
    lVar36 = **(longlong **)((longlong)&plStackX_10 + lVar20);
    *(longlong *)(&stack0x000013f8 + lVar20) = lVar36;
    uVar14 = *(undefined *)(lVar36 + 1);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1068d9;
    func_0x
              (*(undefined8 *)(&stack0x00000718 + lVar20),uVar14,&stack0x00000ab0 + lVar20);
  }
  if ((*(longlong *)(&stack0x00000710 + lVar20) == 0) ||
     (*(char *)(*(longlong *)(&stack0x000000a0 + lVar20) + 0x2050) == '\0')) {
    (&stack0x00000051)[lVar20] = 0;
    cVar12 = '\x01';
    (&stack0x00000052)[lVar20] = 1;
LAB_:
    *(undefined4 *)(&stack0x000000f0 + lVar20) = 0;
    *(undefined2 *)(&stack0x000000f4 + lVar20) = 0;
    *(undefined2 *)(&stack0x000000f6 + lVar20) = 0;
    lVar36 = **(longlong **)(&stack0x00000720 + lVar20);
    *(longlong *)(&stack0x00000a28 + lVar20) = lVar36;
    lVar29 = **(longlong **)((longlong)&plStackX_10 + lVar20);
    *(longlong *)(&stack0x00001400 + lVar20) = lVar29;
    lVar11 = *(longlong *)(lVar36 + 8);
    piVar34 = (int *)(lVar11 + 0x3c0);
    *(int **)(&stack0x00001408 + lVar20) = piVar34;
    *(undefined4 *)(&stack0x000004d0 + lVar20) = 0;
    if (*(int *)(lVar29 + 0x18) == *piVar34) {
      uVar5 = *(ushort *)(lVar11 + 0x3c4);
      if ((*(ushort *)(lVar29 + 6) == uVar5) || ((uVar5 | *(ushort *)(lVar29 + 6)) < 2)) {
        *(undefined4 *)(&stack0x000004d0 + lVar20) = 1;
        goto LAB_;
      }
    }
    *(longlong *)(&stack0x00001410 + lVar20) = lVar29;
    *(undefined4 *)(&stack0x000000f8 + lVar20) = 0;
    *(undefined2 *)(&stack0x000000fc + lVar20) = 0;
    *(undefined2 *)(&stack0x000000fe + lVar20) = 0;
    uVar19 = *(undefined4 *)(lVar29 + 0x18);
    *(undefined4 *)(&stack0x000000f8 + lVar20) = uVar19;
    uVar15 = *(undefined2 *)(lVar29 + 6);
    *(undefined2 *)(&stack0x000000fc + lVar20) = uVar15;
    *(undefined4 *)(&stack0x000000f0 + lVar20) = uVar19;
    *(undefined2 *)(&stack0x000000f4 + lVar20) = uVar15;
    *(undefined2 *)(&stack0x000000f6 + lVar20) = 0;
    puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x62);
    *(undefined2 **)(&stack0x00001418 + lVar20) = puVar23;
    *(undefined2 *)(&stack0x00000130 + lVar20) = *puVar23;
    if (((*(ushort *)(&stack0x00000130 + lVar20) & 0x400) == 0) ||
       (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
      *(int *)(&stack0x000000a8 + lVar20) = (int)*(short *)((longlong)&uStackX_1c + lVar20);
      *(undefined8 *)(&stack0x00000660 + lVar20) = *(undefined8 *)((longlong)&plStackX_10 + lVar20);
      *(undefined2 **)(&stack0x00001420 + lVar20) = puVar23;
      uVar7 = *puVar23;
      *(undefined2 *)(&stack0x00000138 + lVar20) = uVar7;
      if (((byte)uVar7 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x000000a8 + lVar20) == 3) {
          *(undefined4 *)(&stack0x000000a8 + lVar20) = 4;
        }
        else if (*(int *)(&stack0x000000a8 + lVar20) < 2) goto LAB_;
        puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
        *(uint **)(&stack0x00001428 + lVar20) = puVar28;
        uVar27 = *puVar28;
        *(uint *)(&stack0x000004d8 + lVar20) = uVar27;
        if ((((uVar27 & 8) != 0) &&
            (lVar35 = *(longlong *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90),
            lVar35 != 0)) &&
           (*(longlong *)(&stack0x00001430 + lVar20) = lVar35, *(longlong *)(lVar35 + 0x758) != 0))
        {
          uVar40 = *(undefined8 *)(lVar35 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106b2d;
          func_0x
                    (uVar40,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                     *(undefined4 *)(&stack0x000000a8 + lVar20));
        }
      }
LAB_:
      (&stack0x000001ca)[lVar20] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar28 = (uint *)(*(longlong *)(&stack0x00000660 + lVar20) + 100);
        *(uint **)(&stack0x00001438 + lVar20) = puVar28;
        uVar27 = *puVar28;
        *(uint *)(&stack0x000004e0 + lVar20) = uVar27;
        if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x000000a8 + lVar20))) {
          *(uint **)(&stack0x00001440 + lVar20) = puVar28;
          uVar27 = *puVar28;
          *(uint *)(&stack0x000004e8 + lVar20) = uVar27;
          if (((uVar27 & 0xc0000000) != 0x40000000) &&
             (lVar35 = **(longlong **)(&stack0x00000660 + lVar20), lVar35 != 0)) {
            *(undefined4 *)(&stack0x00000908 + lVar20) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106bbb;
            iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x0000090c + lVar20);
            if (iVar16 != 0) {
              LOCK();
              *puVar28 = *puVar28 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar28 = *puVar28 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar35 = *(longlong *)(&stack0x00000660 + lVar20);
      uVar9 = *(undefined4 *)(&stack0x000000a8 + lVar20);
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106bea;
      func_0x(lVar35 + 0x98,uVar9);
      if ((_DAT_ != 0) &&
         ((&stack0x000001c9)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106c14;
        func_0x(lVar35,0,uVar9);
      }
      *(uint *)((longlong)&uStackX_1c + lVar20) =
           *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
      *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106a7c;
      func_0x((longlong)&plStackX_10 + lVar20);
    }
    *(undefined **)(&stack0x00001448 + lVar20) = &stack0x00000350 + lVar20;
    *(undefined **)(&stack0x00001450 + lVar20) = &stack0x00000358 + lVar20;
    lVar35 = *(longlong *)(lVar36 + 8);
    puVar30 = (undefined4 *)(lVar35 + 0x3c0);
    *(undefined4 **)(&stack0x00001458 + lVar20) = puVar30;
    *(undefined4 *)(&stack0x00000350 + lVar20) = *puVar30;
    *(undefined2 *)(&stack0x00000354 + lVar20) = *(undefined2 *)(lVar35 + 0x3c4);
    *(undefined2 *)(&stack0x00000356 + lVar20) = 0;
    *(undefined4 *)(&stack0x00000358 + lVar20) = uVar19;
    *(undefined2 *)(&stack0x0000035c + lVar20) = uVar15;
    *(undefined2 *)(&stack0x0000035e + lVar20) = 0;
    UNRECOVERED_JUMPTABLE_00 = *(code **)**(undefined8 **)(&stack0x00000a28 + lVar20);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106c9e;
    uVar15 = (*UNRECOVERED_JUMPTABLE_00)();
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) =
         *(undefined4 *)(*(longlong *)(&stack0x00000720 + lVar20) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106cce;
    func_0x(&stack0x00000060 + lVar20,&stack0x00000358 + lVar20,uVar15,
                    &stack0x00000350 + lVar20);
    lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
    param_1 = *(longlong *)(&stack0x00000100 + lVar20);
    param_3 = *(short **)(&stack0x00000290 + lVar20);
  }
  else {
    (&stack0x00000051)[lVar20] = 1;
    (&stack0xfffffffffffffff8)[lVar20] = 0;
    *(longlong *)(&stack0xfffffffffffffff0 + lVar20) = *(longlong *)(&stack0x00000710 + lVar20);
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar20) = *(undefined8 *)(&stack0x00000718 + lVar20);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10692c;
    cVar12 = func_0x((longlong)&plStackX_10 + lVar20);
    (&stack0x00000052)[lVar20] = cVar12;
    if (cVar12 != '\0') goto LAB_;
  }
LAB_:
  (&stack0x000001c8)[lVar20] = cVar12;
  if (cVar12 == '\0') {
    *(uint *)(param_1 + 0x80) = *(ushort *)(lVar35 + 0x16) - 1;
    *piVar38 = *piVar38 + -1;
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106d11;
    func_0x(param_1,param_1 + 0x68);
    acStackX_8[lVar20] = '\x01';
    lVar35 = **(longlong **)(param_1 + 8);
    *(longlong *)(&stack0x00001460 + lVar20) = lVar35;
    *(undefined8 *)(&stack0x00001468 + lVar20) = *(undefined8 *)(lVar35 + 0x14);
    lVar35 = *(longlong *)(lVar35 + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106d5e;
    func_0x((longlong)&plStackX_10 + lVar20,lVar35 + 0xa0);
    *(undefined4 *)(param_1 + 200) = 2;
    *(uint *)(param_1 + 0xcc) = 2 - (uint)(acStackX_18[lVar20] != '\0');
    goto LAB_;
  }
  lVar36 = **(longlong **)((longlong)&plStackX_10 + lVar20);
  *(longlong *)(&stack0x00001470 + lVar20) = lVar36;
  if (((*(byte *)(lVar36 + 4) & 1) != 0) || (*(int *)(param_1 + 0x16c) != 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107223;
    func_0x((longlong)&plStackX_10 + lVar20);
    *(uint *)(param_1 + 0x80) = *(ushort *)(lVar35 + 0x16) - 1;
    *piVar38 = *piVar38 + -1;
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107240;
    func_0x(param_1,param_1 + 0x68);
    *(undefined8 *)(&stack0x00001b38 + lVar20) = 0;
    *(undefined **)(&stack0x000014d8 + lVar20) = &stack0x00001b40 + lVar20;
    (&stack0x00001b4e)[lVar20] = 1;
    (&stack0x00001b4f)[lVar20] = 0;
    uVar40 = **(undefined8 **)(param_1 + 8);
    uVar26 = (*(undefined8 **)(param_1 + 8))[1];
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107288;
    uVar19 = func_0x(&stack0x00001b38 + lVar20,&stack0x00000060 + lVar20,uVar26,uVar40);
    *(undefined4 *)(&stack0x00000920 + lVar20) = uVar19;
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107298;
    func_0x(uVar19,0x15);
    *(undefined4 *)(param_1 + 200) = 2;
    *(undefined4 *)(param_1 + 0xcc) = 3;
    acStackX_8[lVar20] = '\x01';
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1072c2;
    func_0x(&stack0x00001b38 + lVar20);
    goto LAB_;
  }
  plVar31 = (longlong *)(param_1 + 0x68);
  *(longlong **)(&stack0x00000668 + lVar20) = plVar31;
  if (*plVar31 != 0) {
    puVar22 = (ushort *)(*plVar31 + 0x62);
    *(ushort **)(&stack0x00001478 + lVar20) = puVar22;
    uVar5 = *puVar22;
    *(ushort *)(&stack0x00000140 + lVar20) = uVar5;
    plVar32 = *(longlong **)(&stack0x00000668 + lVar20);
    if (((uVar5 & 0x400) == 0) || (*(short *)((longlong)plVar32 + 0xc) < 3)) {
      *(int *)(&stack0x000000c8 + lVar20) = (int)*(short *)((longlong)plVar32 + 0xc);
      lVar35 = *plVar32;
      *(longlong *)(&stack0x00000240 + lVar20) = lVar35;
      puVar23 = (undefined2 *)(lVar35 + 0x62);
      *(undefined2 **)(&stack0x00001480 + lVar20) = puVar23;
      uVar15 = *puVar23;
      *(undefined2 *)(&stack0x00000148 + lVar20) = uVar15;
      if (((byte)uVar15 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x000000c8 + lVar20) == 3) {
          *(undefined4 *)(&stack0x000000c8 + lVar20) = 4;
        }
        else if (*(int *)(&stack0x000000c8 + lVar20) < 2) goto LAB_;
        *(uint **)(&stack0x00001488 + lVar20) =
             (uint *)(*(longlong *)(&stack0x00000240 + lVar20) + 100);
        uVar27 = *(uint *)(*(longlong *)(&stack0x00000240 + lVar20) + 100);
        *(uint *)(&stack0x000004f0 + lVar20) = uVar27;
        if ((((uVar27 & 8) != 0) &&
            (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000240 + lVar20) + 0x90), lVar35 != 0))
           && (*(longlong *)(&stack0x00001490 + lVar20) = lVar35, *(longlong *)(lVar35 + 0x758) != 0
              )) {
          uVar40 = *(undefined8 *)(lVar35 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106ebd;
          func_0x
                    (uVar40,*(undefined8 *)(&stack0x00000240 + lVar20),
                     *(undefined4 *)(&stack0x000000c8 + lVar20));
        }
      }
LAB_:
      (&stack0x000001c7)[lVar20] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar28 = (uint *)(*(longlong *)(&stack0x00000240 + lVar20) + 100);
        *(uint **)(&stack0x00001498 + lVar20) = puVar28;
        uVar27 = *puVar28;
        *(uint *)(&stack0x000004f8 + lVar20) = uVar27;
        if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x000000c8 + lVar20))) {
          *(uint **)(&stack0x000014a0 + lVar20) = puVar28;
          uVar27 = *puVar28;
          *(uint *)(&stack0x00000500 + lVar20) = uVar27;
          if (((uVar27 & 0xc0000000) != 0x40000000) &&
             (lVar35 = **(longlong **)(&stack0x00000240 + lVar20), lVar35 != 0)) {
            *(undefined4 *)(&stack0x00000910 + lVar20) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106f50;
            iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000914 + lVar20);
            if (iVar16 != 0) {
              LOCK();
              *puVar28 = *puVar28 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar28 = *puVar28 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar35 = *(longlong *)(&stack0x00000240 + lVar20);
      uVar19 = *(undefined4 *)(&stack0x000000c8 + lVar20);
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106f81;
      func_0x(lVar35 + 0x98,uVar19);
      if ((_DAT_ != 0) &&
         ((&stack0x000001c6)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106fab;
        func_0x(lVar35,0,uVar19);
      }
      *(uint *)((longlong)plVar32 + 0xc) = *(uint *)((longlong)plVar32 + 0xc) & 0xffff0000;
      **(undefined8 **)(&stack0x00000668 + lVar20) = 0;
      param_1 = *(longlong *)(&stack0x00000100 + lVar20);
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106df9;
      func_0x(plVar32);
    }
  }
  *(longlong **)(&stack0x00000670 + lVar20) = plVar31;
  if (*plVar31 != 0) {
    puVar22 = (ushort *)(*plVar31 + 0x62);
    *(ushort **)(&stack0x000014a8 + lVar20) = puVar22;
    uVar5 = *puVar22;
    *(ushort *)(&stack0x00000150 + lVar20) = uVar5;
    plVar31 = *(longlong **)(&stack0x00000670 + lVar20);
    if (((uVar5 & 0x400) == 0) || (*(short *)((longlong)plVar31 + 0xc) < 3)) {
      *(int *)(&stack0x00000098 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
      lVar35 = *plVar31;
      *(longlong *)(&stack0x00000258 + lVar20) = lVar35;
      puVar23 = (undefined2 *)(lVar35 + 0x62);
      *(undefined2 **)(&stack0x000014b0 + lVar20) = puVar23;
      uVar15 = *puVar23;
      *(undefined2 *)(&stack0x00000158 + lVar20) = uVar15;
      if (((byte)uVar15 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000098 + lVar20) == 3) {
          *(undefined4 *)(&stack0x00000098 + lVar20) = 4;
        }
        else if (*(int *)(&stack0x00000098 + lVar20) < 2) goto LAB_;
        *(uint **)(&stack0x000014b8 + lVar20) =
             (uint *)(*(longlong *)(&stack0x00000258 + lVar20) + 100);
        uVar27 = *(uint *)(*(longlong *)(&stack0x00000258 + lVar20) + 100);
        *(uint *)(&stack0x00000508 + lVar20) = uVar27;
        if ((((uVar27 & 8) != 0) &&
            (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000258 + lVar20) + 0x90), lVar35 != 0))
           && (*(longlong *)(&stack0x000014c0 + lVar20) = lVar35, *(longlong *)(lVar35 + 0x758) != 0
              )) {
          uVar40 = *(undefined8 *)(lVar35 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1070d5;
          func_0x
                    (uVar40,*(undefined8 *)(&stack0x00000258 + lVar20),
                     *(undefined4 *)(&stack0x00000098 + lVar20));
        }
      }
LAB_:
      (&stack0x000001c5)[lVar20] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar28 = (uint *)(*(longlong *)(&stack0x00000258 + lVar20) + 100);
        *(uint **)(&stack0x000014c8 + lVar20) = puVar28;
        uVar27 = *puVar28;
        *(uint *)(&stack0x00000510 + lVar20) = uVar27;
        if (((uVar27 & 8) != 0) && (2 < *(int *)(&stack0x00000098 + lVar20))) {
          *(uint **)(&stack0x000014d0 + lVar20) = puVar28;
          uVar27 = *puVar28;
          *(uint *)(&stack0x00000518 + lVar20) = uVar27;
          if (((uVar27 & 0xc0000000) != 0x40000000) &&
             (lVar35 = **(longlong **)(&stack0x00000258 + lVar20), lVar35 != 0)) {
            *(undefined4 *)(&stack0x00000918 + lVar20) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107168;
            iVar16 = (*_DAT_)(lVar35,0x2000,2,&stack0x0000091c + lVar20);
            if (iVar16 != 0) {
              LOCK();
              *puVar28 = *puVar28 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar28 = *puVar28 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar35 = *(longlong *)(&stack0x00000258 + lVar20);
      uVar19 = *(undefined4 *)(&stack0x00000098 + lVar20);
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107197;
      func_0x(lVar35 + 0x98,uVar19);
      if ((_DAT_ != 0) &&
         ((&stack0x000001c4)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1071c1;
        func_0x(lVar35,0,uVar19);
      }
      *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
      plVar31 = *(longlong **)(&stack0x00000670 + lVar20);
      *plVar31 = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107011;
      func_0x(plVar31);
    }
  }
  *plVar31 = *(longlong *)((longlong)&plStackX_10 + lVar20);
  *(uint *)((longlong)plVar31 + 0xc) =
       *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000 |
       (uint)*(ushort *)((longlong)&uStackX_1c + lVar20);
  *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
  *(uint *)((longlong)&uStackX_1c + lVar20) = *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000
  ;
  iVar16 = 0;
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(int *)(&stack0x00000210 + lVar20) = *(int *)(&stack0x00000210 + lVar20) + 1;
  *(undefined4 *)(&stack0x00000074 + lVar20) = 0;
  goto LAB_;
}

