
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,longlong param_4)

{
  ushort *puVar1;
  short *psVar2;
  ushort uVar3;
  undefined8 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  byte bVar7;
  char cVar8;
  short sVar9;
  ushort uVar10;
  int iVar11;
  uint uVar12;
  longlong lVar13;
  longlong lVar14;
  undefined8 uVar15;
  longlong lVar16;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar17;
  ushort uVar18;
  ulonglong uVar19;
  longlong lVar20;
  undefined8 unaff_RBX;
  uint *puVar21;
  undefined *puVar22;
  undefined *puVar23;
  ushort *puVar24;
  int iVar25;
  uint uVar26;
  uint *puVar27;
  longlong *plVar28;
  byte *pbVar29;
  byte *pbVar30;
  uint uVar31;
  uint *puVar32;
  bool bVar33;
  undefined4 uVar34;
  undefined auStackX_8 [24];
  uint auStackX_20 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  puVar22 = &stack0xffffffffffffffc8 + lVar13;
  *(undefined8 *)(&stack0x00000288 + lVar13) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002410 + lVar13) = unaff_RBX;
  *(ulonglong *)(&stack0x000023b8 + lVar13) = _DAT_ ^ (ulonglong)(auStackX_8 + lVar13);
  puVar27 = (uint *)0x0;
  uVar19 = 0;
  *(undefined4 *)(&stack0x0000007c + lVar13) = 0;
  *(undefined8 *)(&stack0x00000090 + lVar13) = 0;
  *(undefined4 *)(&stack0x00000098 + lVar13) = 0;
  if (param_3 == (longlong *)0x0) {
    uVar31 = *(uint *)(&stack0x00000078 + lVar13);
    *(uint *)((longlong)auStackX_20 + lVar13 + 4) = uVar31;
    lVar14 = *(longlong *)(&stack0x00000070 + lVar13);
    plVar28 = *(longlong **)(&stack0x00000068 + lVar13);
  }
  else {
    puVar4 = *(undefined8 **)(param_1 + 0x20);
    if ((*(int *)(puVar4 + 5) == *(int *)(param_3 + 1)) &&
       (*param_3 == (ulonglong)*(uint6 *)((longlong)puVar4 + 0x14) * 0x10000)) {
      UNRECOVERED_JUMPTABLE = *(code **)*puVar4;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10009c;
      sVar9 = (*UNRECOVERED_JUMPTABLE)(puVar4);
      if (*(short *)((longlong)param_3 + 0xc) != sVar9) goto LAB_;
      if (param_3[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1000bd;
      func_0x(param_3,puVar4);
    }
    lVar20 = *(longlong *)(param_1 + 0x20);
    uVar18 = *(ushort *)((longlong)param_3 + 0x62);
    uVar31 = (uint)uVar18;
    *(uint *)((longlong)auStackX_20 + lVar13 + 4) = (uint)uVar18;
    uVar3 = *(ushort *)(param_3 + 7);
    *(longlong **)(&stack0x00000068 + lVar13) = param_3;
    *(uint *)(&stack0x00000078 + lVar13) = (uint)uVar18;
    *(longlong *)(&stack0x00000080 + lVar13) = param_4;
    *(undefined8 *)(&stack0x00000088 + lVar13) = 0;
    *(undefined8 *)(&stack0x000000c0 + lVar13) = 0;
    lVar14 = param_3[0xe];
    *(longlong *)(&stack0x00000070 + lVar13) = lVar14;
    plVar28 = param_3;
    if ((uVar3 & 0x400) == 0) {
      if (lVar20 != 0) {
        lVar20 = **(longlong **)(*(longlong *)(lVar20 + 8) + 0x160);
        *(undefined8 *)(&stack0x00000090 + lVar13) = *(undefined8 *)(lVar20 + 0xa8);
        *(undefined4 *)(&stack0x00000098 + lVar13) = *(undefined4 *)(lVar20 + 0xb0);
      }
      uVar19 = (ulonglong)(*(uint *)(&stack0x0000007c + lVar13) | 0x10);
      *(uint *)(&stack0x0000007c + lVar13) = *(uint *)(&stack0x0000007c + lVar13) | 0x10;
    }
    else {
      *(uint *)((longlong)auStackX_20 + lVar13 + 4) = (uint)uVar18;
      if (lVar20 != 0) {
        lVar20 = **(longlong **)(*(longlong *)(lVar20 + 8) + 0x160);
        *(undefined8 *)(&stack0x00000090 + lVar13) = *(undefined8 *)(lVar20 + 0xa8);
        *(undefined4 *)(&stack0x00000098 + lVar13) = *(undefined4 *)(lVar20 + 0xb0);
      }
      uVar26 = *(uint *)(&stack0x0000007c + lVar13);
      uVar19 = (ulonglong)(uVar26 | 0x10);
      *(uint *)(&stack0x0000007c + lVar13) = uVar26 | 0x10;
      if (param_4 != 0) {
        *(undefined8 *)(&stack0x000000a0 + lVar13) = 0;
        *(undefined8 *)(&stack0x000000b0 + lVar13) = 0;
        *(undefined8 *)(&stack0x000000a8 + lVar13) = 0;
        if ((uVar26 & 4) == 0) {
          uVar19 = (ulonglong)(uVar26 | 0x12);
          *(uint *)(&stack0x0000007c + lVar13) = uVar26 | 0x12;
        }
      }
    }
  }
  *(undefined8 *)(&stack0x000001a8 + lVar13) = 0x81f100;
  psVar2 = (short *)(param_1 + 0x168);
  *(short **)(&stack0x00000038 + lVar13) = psVar2;
  *(short **)(&stack0x000001b0 + lVar13) = psVar2;
  *(undefined (*) [16])(&stack0x000001b8 + lVar13) = ZEXT816(0);
  if ((*(short *)((longlong)param_3 + 0x3a) == 0) && (*(int *)(param_3 + 10) == 0)) {
    lVar20 = *(longlong *)(param_1 + 0x20);
    *(longlong *)(&stack0x00000058 + lVar13) = lVar20;
    if ((*(byte *)(plVar28 + 6) & 1) != 0) {
      puVar1 = (ushort *)(param_1 + 0x16a);
      if (*psVar2 == 0) {
        if ((**(byte **)(param_1 + 0x170) & 0x10) == 0) {
          uVar26 = 0;
        }
        else {
          uVar26 = (uint)*(ushort *)(*(byte **)(param_1 + 0x170) + *(uint *)(param_1 + 0x178));
        }
      }
      else {
        uVar26 = (uint)*puVar1;
      }
      if (*(uint *)(plVar28 + 3) <= uVar26) {
        *psVar2 = 0;
        uVar3 = *(ushort *)(*(longlong *)(&stack0x00000068 + lVar13) + 0x62);
        puVar21 = *(uint **)(&stack0x00000070 + lVar13);
        puVar23 = &stack0xffffffffffffffc8 + lVar13;
        puVar32 = puVar27;
        if (uVar3 != 0) {
          do {
            cVar8 = *(char *)(puVar21 + 0x10);
            if (cVar8 == '\x01') {
              if ((*(byte *)((longlong)puVar21 + 6) & 0x10) == 0) {
                uVar31 = *(byte *)((ulonglong)(*(ushort *)(puVar21 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(param_1 + 0x178) + 2 +
                                  *(longlong *)(param_1 + 0x170)) >>
                         ((byte)(*(ushort *)(puVar21 + 1) - 1) & 7) & 1;
              }
              else {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000278 + lVar13;
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10108d;
                func_0x(puVar1,puVar21,1,&stack0x00000148 + lVar13);
                uVar31 = *(uint *)(&stack0x00000148 + lVar13);
              }
              if (uVar31 == 0) goto LAB_;
LAB_:
              bVar33 = (*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) == 0;
LAB_:
              lVar14 = *(longlong *)(&stack0x00000080 + lVar13);
              if (!bVar33) {
                lVar14 = *(longlong *)(&stack0x00000088 + lVar13);
              }
              *(undefined *)(lVar14 + *(longlong *)(puVar21 + 0xc)) = 3;
            }
            else {
              if (cVar8 == '\x02') {
LAB_:
                uVar18 = *(ushort *)(puVar21 + 0xf);
                if ((*(byte *)((longlong)puVar21 + 6) & 0x10) == 0) {
LAB_:
                  *(uint *)(&stack0x0000002c + lVar13) = (uint)uVar18;
                  puVar27 = (uint *)((longlong)(int)*puVar21 + *(longlong *)(param_1 + 0x170));
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000140 + lVar13;
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101113;
                  func_0x(puVar1,puVar21,0,&stack0x0000027c + lVar13);
                  if (*(int *)(&stack0x00000140 + lVar13) != 0) goto LAB_;
                  puVar27 = *(uint **)(puVar21 + 2) + 1;
                  uVar31 = **(uint **)(puVar21 + 2);
                  if ((uVar18 != 0) && (uVar31 != uVar18)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101158;
                    (*_DAT_)(1,0xc28008,0xc26a08,0x381);
                  }
                  *(uint *)(&stack0x0000002c + lVar13) = uVar31;
                }
                lVar14 = *(longlong *)(&stack0x00000080 + lVar13);
                if ((*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar14 = *(longlong *)(&stack0x00000088 + lVar13);
                }
                *(undefined *)(lVar14 + *(longlong *)(puVar21 + 0xc)) = 0;
              }
              else {
                iVar25 = 0;
                if (cVar8 == '\x03') {
                  if ((*(byte *)((longlong)puVar21 + 6) & 0x10) == 0) {
                    uVar31 = *(byte *)((ulonglong)(*(ushort *)(puVar21 + 1) - 1 >> 3) +
                                       (ulonglong)*(uint *)(param_1 + 0x178) + 2 +
                                      *(longlong *)(param_1 + 0x170)) >>
                             ((byte)(*(ushort *)(puVar21 + 1) - 1) & 7) & 1;
                  }
                  else {
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x0000021c + lVar13;
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a15;
                    func_0x(puVar1,puVar21,1,&stack0x00000154 + lVar13);
                    uVar31 = *(uint *)(&stack0x00000154 + lVar13);
                  }
                  if (uVar31 != 0) goto LAB_;
                }
                else if (cVar8 != '\x04') {
                  if (cVar8 == '\b') {
                    iVar25 = puVar21[0x10] << 0xc;
                    uVar18 = *(ushort *)(puVar21 + 0xf);
                    if ((*puVar21 & 0xc0000000) == 0x80000000) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100984;
                      iVar25 = func_0x(puVar1);
                      if (iVar25 == 0) {
                        puVar27 = (uint *)0x0;
                        *(undefined4 *)(&stack0x0000002c + lVar13) = 0;
                        bVar33 = (*(ushort *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) == 0;
                        goto LAB_;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10099f;
                      puVar27 = (uint *)func_0x(param_1 + 0x192,puVar21,
                                                        &stack0x0000002c + lVar13,
                                                        &stack0x00000218 + lVar13);
                    }
                    else {
                      if ((iVar25 < 0) || ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0)) {
                        *(undefined **)(&stack0xffffffffffffffe8 + lVar13) =
                             &stack0x000000cc + lVar13;
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10030a;
                        func_0x(puVar1,puVar21,iVar25 < 0,&stack0x000000c8 + lVar13)
                        ;
                        if ((iVar25 < 0) && (*(int *)(&stack0x000000c8 + lVar13) != 0)) {
                          puVar27 = (uint *)0x0;
                          *(undefined4 *)(&stack0x0000002c + lVar13) = 0;
                          goto LAB_;
                        }
                        iVar25 = *(int *)(&stack0x000000cc + lVar13);
                      }
                      else {
                        *(undefined4 *)(&stack0x000000c8 + lVar13) = 0;
                        iVar25 = 1;
                        *(undefined4 *)(&stack0x000000cc + lVar13) = 1;
                      }
                      if ((iVar25 == 0) && ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0)) {
                        puVar5 = *(undefined4 **)(puVar21 + 2);
                        *(undefined4 *)(&stack0x0000002c + lVar13) = *puVar5;
                        puVar27 = puVar5 + 1;
                      }
                      else if ((int)*puVar21 < 0) {
                        if (*(int *)(param_1 + 0x16c) == 0) {
                          *puVar1 = 0;
                          uVar31 = *(uint *)(param_1 + 0x178);
                          uVar19 = (ulonglong)uVar31;
                          *(uint *)(param_1 + 0x17c) = uVar31;
                          pbVar29 = *(byte **)(param_1 + 0x170);
                          bVar7 = *pbVar29;
                          if ((bVar7 & 0x10) != 0) {
                            uVar31 = uVar31 + 2 + (*(ushort *)(pbVar29 + uVar19) + 7 >> 3);
                            uVar19 = (ulonglong)uVar31;
                            *(uint *)(param_1 + 0x17c) = uVar31;
                            bVar7 = *pbVar29;
                          }
                          if ((bVar7 & 0x20) == 0) {
                            *(int *)(param_1 + 0x16c) = (int)uVar19;
                            *(undefined2 *)(param_1 + 0x184) = 0;
                            *(uint *)(param_1 + 0x180) = uVar31;
                          }
                          else {
                            puVar24 = (ushort *)(pbVar29 + uVar19);
                            uVar18 = *puVar24;
                            *(ushort *)(param_1 + 0x184) = uVar18;
                            if (uVar18 == 0) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100456;
                              cVar8 = func_0x(0x1189510);
                              if (cVar8 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10045f;
                                lVar14 = func_0x();
                                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100479;
                                  cVar8 = func_0x(0x1189510);
                                  if (cVar8 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100495;
                                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1004bb;
                                    (*_DAT_)(1,0xa7a298,0xb99f68,0x80f);
                                  }
                                }
                              }
                              uVar15 = *(undefined8 *)(param_1 + 0x170);
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1004c9;
                              func_0x(uVar15,3);
                              uVar18 = *(ushort *)(param_1 + 0x184);
                              uVar31 = *(uint *)(param_1 + 0x17c);
                            }
                            uVar31 = uVar31 + (uVar18 + 1) * 2;
                            *(uint *)(param_1 + 0x180) = uVar31;
                            if (0x1f9e < uVar31) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1004f8;
                              cVar8 = func_0x(0x1189510);
                              if (cVar8 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100501;
                                lVar14 = func_0x();
                                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10051b;
                                  cVar8 = func_0x(0x1189510);
                                  if (cVar8 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100537;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10055d;
                                    (*_DAT_)(1,0xa7a298,0xb99f68,0x816);
                                  }
                                }
                              }
                              uVar15 = *(undefined8 *)(param_1 + 0x170);
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10056b;
                              func_0x(uVar15,4);
                              uVar18 = *(ushort *)(param_1 + 0x184);
                              uVar31 = *(uint *)(param_1 + 0x180);
                            }
                            uVar19 = (ulonglong)uVar18;
                            uVar18 = puVar24[uVar19];
                            *(uint *)(param_1 + 0x16c) = uVar18 & 0x7fff;
                            if ((uVar18 & 0x7fff) < uVar31) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100598;
                              cVar8 = func_0x(0x1189510);
                              if (cVar8 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1005a1;
                                lVar14 = func_0x();
                                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1005bb;
                                  cVar8 = func_0x(0x1189510);
                                  if (cVar8 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1005d7;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1005fd;
                                    (*_DAT_)(1,0xa7a298,0xb99f68,0x81d);
                                  }
                                }
                              }
                              uVar15 = *(undefined8 *)(param_1 + 0x170);
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10060b;
                              func_0x(uVar15,4);
                              uVar19 = (ulonglong)
                                       *(ushort *)(*(longlong *)(&stack0x00000038 + lVar13) + 0x1c);
                            }
                            if ((short)puVar24[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
                              do {
                                lVar14 = *(longlong *)(param_1 + 0x170);
                                lVar20 = (ulonglong)*(uint *)(param_1 + 0x17c) + lVar14;
                                if ((int)uVar19 == 1) {
                                  uVar31 = *(uint *)(param_1 + 0x180);
                                  uVar26 = uVar31;
LAB_:
                                  if ((*(ushort *)(lVar20 + uVar19 * 2) & 0x7fff) < uVar31)
                                  goto LAB_;
                                }
                                else {
                                  uVar31 = *(ushort *)(lVar20 + -2 + uVar19 * 2) & 0x7fff;
                                  uVar26 = *(uint *)(param_1 + 0x180);
                                  if (uVar26 <= uVar31) goto LAB_;
LAB_:
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100675;
                                  func_0x(lVar14,7);
                                  uVar26 = *(uint *)(param_1 + 0x180);
                                }
                                if ((uVar31 < uVar26) || (*(uint *)(param_1 + 0x16c) < uVar31))
                                goto LAB_;
                                uVar18 = *(ushort *)
                                          ((ulonglong)uVar31 + *(longlong *)(param_1 + 0x170));
                                if (uVar18 == 5) {
                                  *puVar1 = *puVar1 | 2;
                                  *(short *)(param_1 + 0x184) = *(short *)(param_1 + 0x184) + -1;
                                  *(short *)(param_1 + 0x192) = (short)uVar31;
                                  lVar14 = (ulonglong)(uVar31 & 0xffff) +
                                           *(longlong *)(param_1 + 0x170);
                                  uVar18 = *(ushort *)(lVar14 + 2);
                                  uVar10 = *(ushort *)(param_1 + 0x194) & 0xc7ff;
                                  if ((uVar18 >> 0xe & 1) != 0) {
                                    uVar10 = uVar18 & 0x3800 | uVar10;
                                  }
                                  *(ushort *)(param_1 + 0x194) = uVar10;
                                  *(ushort *)(param_1 + 0x194) =
                                       (uVar10 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar10;
                                  goto LAB_;
                                }
                                if (uVar18 < 0x400) goto LAB_;
                                *puVar1 = *puVar1 | 1;
                                uVar18 = *(short *)(param_1 + 0x184) - 1;
                                *(ushort *)(param_1 + 0x184) = uVar18;
                                if (uVar18 == 0) goto LAB_;
                                uVar19 = (ulonglong)uVar18;
                              } while ((short)puVar24[(ulonglong)(uVar18 - 1) + 1] < 0);
                              pbVar29 = *(byte **)(param_1 + 0x170);
                            }
                            else {
LAB_:
                              pbVar29 = *(byte **)(param_1 + 0x170);
                            }
                          }
                          if ((*pbVar29 & 0x40) == 0) {
                            *(undefined4 *)(param_1 + 0x18e) = 0;
                          }
                          else {
                            *(int *)(param_1 + 0x18e) = *(int *)(param_1 + 0x16c);
                            *(int *)(param_1 + 0x16c) = *(int *)(param_1 + 0x16c) + 0xe;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100766;
                            uVar15 = func_0x(puVar1);
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100775;
                            func_0x(uVar15,&stack0x00000228 + lVar13);
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100781;
                            iVar25 = func_0x(&stack0x00000228 + lVar13);
                            *(int *)(param_1 + 0x16c) = *(int *)(param_1 + 0x16c) + iVar25;
                          }
                          uVar31 = *(uint *)(param_1 + 0x16c);
                          if ((*(ulonglong *)(param_1 + 0x186) != 0) &&
                             (*(ulonglong *)(param_1 + 0x186) <
                              (ulonglong)uVar31 + *(longlong *)(param_1 + 0x170))) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1007b0;
                            cVar8 = func_0x(0x1189510);
                            if (cVar8 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1007b9;
                              lVar14 = func_0x();
                              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1007d3;
                                cVar8 = func_0x(0x1189510);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1007ef;
                                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100812;
                                  (*_DAT_)(1,0xa7a298,0xb99f68,0x877);
                                }
                              }
                            }
                            uVar15 = *(undefined8 *)(param_1 + 0x170);
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100820;
                            func_0x(uVar15,0x12);
                            uVar31 = *(uint *)(param_1 + 0x16c);
                          }
                          if (0x3f3b < uVar31 - 1) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100839;
                            cVar8 = func_0x(0x1189510);
                            if (cVar8 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100842;
                              lVar14 = func_0x();
                              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10085c;
                                cVar8 = func_0x(0x1189510);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100878;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10089b;
                                  (*_DAT_)(1,0xa7a298,0xb99f68,0x87c);
                                }
                              }
                            }
                            uVar15 = *(undefined8 *)(param_1 + 0x170);
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1008a9;
                            func_0x(uVar15,5);
                          }
                        }
LAB_:
                        sVar9 = -*(short *)puVar21;
                        if ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe8 + lVar13) =
                               &stack0x000000f8 + lVar13;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1008d8;
                          func_0x(puVar1,puVar21,0,&stack0x00000214 + lVar13);
                          if (*(int *)(&stack0x000000f8 + lVar13) == 0) {
                            puVar5 = *(undefined4 **)(puVar21 + 2);
                            *(undefined4 *)(&stack0x0000002c + lVar13) = *puVar5;
                            puVar27 = puVar5 + 1;
                            goto LAB_;
                          }
                        }
                        lVar14 = (longlong)sVar9;
                        if ((uint)*(ushort *)(param_1 + 0x184) < (uint)(int)sVar9) {
                          *(undefined4 *)(&stack0x0000002c + lVar13) = 0;
                          puVar27 = *(uint **)(param_1 + 0x170);
                        }
                        else {
                          lVar20 = *(longlong *)(param_1 + 0x170);
                          lVar16 = (ulonglong)*(uint *)(param_1 + 0x17c) + lVar20;
                          if (sVar9 == 1) {
                            uVar31 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar13) + 0x18);
                            uVar26 = *(ushort *)(lVar16 + lVar14 * 2) & 0x7fff;
LAB_:
                            if (uVar26 < uVar31) goto LAB_;
                          }
                          else {
                            uVar31 = *(ushort *)(lVar16 + -2 + lVar14 * 2) & 0x7fff;
                            lVar20 = *(longlong *)(param_1 + 0x170);
                            uVar26 = *(ushort *)(lVar16 + lVar14 * 2) & 0x7fff;
                            if (*(uint *)(*(longlong *)(&stack0x00000038 + lVar13) + 0x18) <= uVar31
                               ) goto LAB_;
LAB_:
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10095f;
                            func_0x(lVar20,7);
                            lVar20 = *(longlong *)(param_1 + 0x170);
                          }
                          *(uint *)(&stack0x0000002c + lVar13) = uVar26 - uVar31;
                          puVar27 = (uint *)((ulonglong)uVar31 + lVar20);
                        }
                      }
                      else if ((*(ushort *)((longlong)puVar21 + 6) & 8) == 0) {
                        if ((*(ushort *)((longlong)puVar21 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe8 + lVar13) =
                               &stack0x00000158 + lVar13;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100382;
                          func_0x(puVar1,puVar21,0,&stack0x00000210 + lVar13);
                          if (*(int *)(&stack0x00000158 + lVar13) == 0) {
                            puVar27 = *(uint **)(puVar21 + 2) + 1;
                            uVar31 = **(uint **)(puVar21 + 2);
                            if ((uVar18 != 0) && (uVar31 != uVar18)) {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1003c7;
                              (*_DAT_)(1,0xc28008,0xc26a08,0x381);
                            }
                            *(uint *)(&stack0x0000002c + lVar13) = uVar31;
                            goto LAB_;
                          }
                        }
                        *(uint *)(&stack0x0000002c + lVar13) = (uint)uVar18;
                        puVar27 = (uint *)((longlong)(int)*puVar21 + *(longlong *)(param_1 + 0x170))
                        ;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1003ee;
                        puVar27 = (uint *)func_0x(puVar1,puVar21);
                      }
                    }
LAB_:
                    if (puVar27 == (uint *)0x0) {
                      bVar33 = (*(ushort *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) == 0;
                      goto LAB_;
                    }
                    lVar14 = *(longlong *)(&stack0x00000080 + lVar13);
                    if ((*(ushort *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
                      lVar14 = *(longlong *)(&stack0x00000088 + lVar13);
                    }
                    *(undefined *)(lVar14 + *(longlong *)(puVar21 + 0xc)) = 0;
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0x7f6778;
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10029f;
                    (*_DAT_)(1,0xbfb5d0,0xc27f10,0x27d);
                  }
                  goto LAB_;
                }
                if (*(int *)(param_1 + 0x16c) == 0) {
                  *puVar1 = 0;
                  uVar31 = *(uint *)(param_1 + 0x178);
                  uVar19 = (ulonglong)uVar31;
                  *(uint *)(param_1 + 0x17c) = uVar31;
                  pbVar29 = *(byte **)(param_1 + 0x170);
                  bVar7 = *pbVar29;
                  pbVar30 = pbVar29;
                  if ((bVar7 & 0x10) != 0) {
                    uVar31 = uVar31 + 2 + (*(ushort *)(pbVar29 + uVar19) + 7 >> 3);
                    uVar19 = (ulonglong)uVar31;
                    *(uint *)(param_1 + 0x17c) = uVar31;
                    bVar7 = *pbVar29;
                    pbVar30 = *(byte **)(param_1 + 0x170);
                  }
                  if ((bVar7 & 0x20) == 0) {
                    *(int *)(param_1 + 0x16c) = (int)uVar19;
                    *(undefined2 *)(param_1 + 0x184) = 0;
                    *(uint *)(param_1 + 0x180) = uVar31;
                  }
                  else {
                    puVar24 = (ushort *)(pbVar29 + uVar19);
                    uVar18 = *puVar24;
                    *(ushort *)(param_1 + 0x184) = uVar18;
                    if (uVar18 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100abc;
                      cVar8 = func_0x(0x1189510);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ac5;
                        lVar14 = func_0x();
                        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100adf;
                          cVar8 = func_0x(0x1189510);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100afb;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b21;
                            (*_DAT_)(1,0xa7a298,0xb99f68,0x80f);
                          }
                        }
                      }
                      uVar15 = *(undefined8 *)(param_1 + 0x170);
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b2f;
                      func_0x(uVar15,3);
                      uVar18 = *(ushort *)(param_1 + 0x184);
                      uVar31 = *(uint *)(param_1 + 0x17c);
                    }
                    uVar31 = uVar31 + (uVar18 + 1) * 2;
                    *(uint *)(param_1 + 0x180) = uVar31;
                    if (0x1f9e < uVar31) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b5e;
                      cVar8 = func_0x(0x1189510);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b67;
                        lVar14 = func_0x();
                        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b81;
                          cVar8 = func_0x(0x1189510);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b9d;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100bc3;
                            (*_DAT_)(1,0xa7a298,0xb99f68,0x816);
                          }
                        }
                      }
                      uVar15 = *(undefined8 *)(param_1 + 0x170);
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100bd1;
                      func_0x(uVar15,4);
                      uVar18 = *(ushort *)(param_1 + 0x184);
                      uVar31 = *(uint *)(param_1 + 0x180);
                    }
                    uVar19 = (ulonglong)uVar18;
                    uVar18 = puVar24[uVar19];
                    *(uint *)(param_1 + 0x16c) = uVar18 & 0x7fff;
                    if ((uVar18 & 0x7fff) < uVar31) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100bfe;
                      cVar8 = func_0x(0x1189510);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c07;
                        lVar14 = func_0x();
                        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c21;
                          cVar8 = func_0x(0x1189510);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c3d;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c63;
                            (*_DAT_)(1,0xa7a298,0xb99f68,0x81d);
                          }
                        }
                      }
                      uVar15 = *(undefined8 *)(param_1 + 0x170);
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c71;
                      func_0x(uVar15,4);
                      uVar19 = (ulonglong)
                               *(ushort *)(*(longlong *)(&stack0x00000038 + lVar13) + 0x1c);
                    }
                    if ((short)puVar24[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
                      do {
                        lVar14 = *(longlong *)(param_1 + 0x170);
                        lVar20 = (ulonglong)*(uint *)(param_1 + 0x17c) + lVar14;
                        if ((int)uVar19 == 1) {
                          uVar31 = *(uint *)(param_1 + 0x180);
                          uVar26 = uVar31;
LAB_:
                          if ((*(ushort *)(lVar20 + uVar19 * 2) & 0x7fff) < uVar31)
                          goto LAB_;
                        }
                        else {
                          uVar31 = *(ushort *)(lVar20 + -2 + uVar19 * 2) & 0x7fff;
                          uVar26 = *(uint *)(param_1 + 0x180);
                          if (uVar26 <= uVar31) goto LAB_;
LAB_:
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100cd5;
                          func_0x(lVar14,7);
                          uVar26 = *(uint *)(param_1 + 0x180);
                          lVar14 = *(longlong *)(param_1 + 0x170);
                        }
                        if ((uVar31 < uVar26) || (*(uint *)(param_1 + 0x16c) < uVar31))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar31 + lVar14) == 5) {
                          *puVar1 = *puVar1 | 2;
                          *(short *)(param_1 + 0x184) = *(short *)(param_1 + 0x184) + -1;
                          *(short *)(param_1 + 0x192) = (short)uVar31;
                          lVar14 = (ulonglong)(uVar31 & 0xffff) + *(longlong *)(param_1 + 0x170);
                          uVar18 = *(ushort *)(lVar14 + 2);
                          uVar10 = *(ushort *)(param_1 + 0x194) & 0xc7ff;
                          if ((uVar18 >> 0xe & 1) != 0) {
                            uVar10 = uVar18 & 0x3800 | uVar10;
                          }
                          *(ushort *)(param_1 + 0x194) = uVar10;
                          *(ushort *)(param_1 + 0x194) =
                               (uVar10 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar10;
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar31 + lVar14) < 0x400) goto LAB_;
                        *puVar1 = *puVar1 | 1;
                        uVar18 = *(short *)(param_1 + 0x184) - 1;
                        *(ushort *)(param_1 + 0x184) = uVar18;
                        if (uVar18 == 0) goto LAB_;
                        uVar19 = (ulonglong)uVar18;
                      } while ((short)puVar24[(ulonglong)(uVar18 - 1) + 1] < 0);
                      pbVar30 = *(byte **)(param_1 + 0x170);
                    }
                    else {
LAB_:
                      pbVar30 = *(byte **)(param_1 + 0x170);
                    }
                  }
                  if ((*pbVar30 & 0x40) == 0) {
                    *(undefined4 *)(param_1 + 0x18e) = 0;
                  }
                  else {
                    *(int *)(param_1 + 0x18e) = *(int *)(param_1 + 0x16c);
                    *(int *)(param_1 + 0x16c) = *(int *)(param_1 + 0x16c) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100dc6;
                    uVar15 = func_0x(puVar1);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100dd5;
                    func_0x(uVar15,&stack0x00000230 + lVar13);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100de1;
                    iVar11 = func_0x(&stack0x00000230 + lVar13);
                    *(int *)(param_1 + 0x16c) = *(int *)(param_1 + 0x16c) + iVar11;
                    pbVar30 = *(byte **)(param_1 + 0x170);
                  }
                  uVar31 = *(uint *)(param_1 + 0x16c);
                  if ((*(byte **)(param_1 + 0x186) != (byte *)0x0) &&
                     (*(byte **)(param_1 + 0x186) < pbVar30 + uVar31)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e14;
                    cVar8 = func_0x(0x1189510);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e1d;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e37;
                        cVar8 = func_0x(0x1189510);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e53;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e76;
                          (*_DAT_)(1,0xa7a298,0xb99f68,0x877);
                        }
                      }
                    }
                    uVar15 = *(undefined8 *)(param_1 + 0x170);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e84;
                    func_0x(uVar15,0x12);
                    uVar31 = *(uint *)(param_1 + 0x16c);
                  }
                  if (0x3f3b < uVar31 - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e9d;
                    cVar8 = func_0x(0x1189510);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ea6;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ec0;
                        cVar8 = func_0x(0x1189510);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100edc;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100eff;
                          (*_DAT_)(1,0xa7a298,0xb99f68,0x87c);
                        }
                      }
                    }
                    uVar15 = *(undefined8 *)(param_1 + 0x170);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100f0d;
                    func_0x(uVar15,5);
                  }
                }
LAB_:
                sVar9 = -*(short *)puVar21;
                if ((*(byte *)((longlong)puVar21 + 6) & 0x10) == 0) {
LAB_:
                  lVar14 = (longlong)sVar9;
                  if ((uint)*(ushort *)(param_1 + 0x184) < (uint)(int)sVar9) {
                    *(undefined4 *)(&stack0x0000002c + lVar13) = 0;
                    puVar27 = *(uint **)(param_1 + 0x170);
                  }
                  else {
                    lVar20 = *(longlong *)(param_1 + 0x170);
                    lVar16 = (ulonglong)*(uint *)(param_1 + 0x17c) + lVar20;
                    if (sVar9 == 1) {
                      uVar19 = (ulonglong)*(uint *)(*(longlong *)(&stack0x00000038 + lVar13) + 0x18)
                      ;
                      uVar31 = *(ushort *)(lVar16 + lVar14 * 2) & 0x7fff;
LAB_:
                      if (uVar31 < (uint)uVar19) goto LAB_;
                    }
                    else {
                      uVar26 = *(ushort *)(lVar16 + -2 + lVar14 * 2) & 0x7fff;
                      uVar19 = (ulonglong)uVar26;
                      lVar20 = *(longlong *)(param_1 + 0x170);
                      uVar31 = *(ushort *)(lVar16 + lVar14 * 2) & 0x7fff;
                      if (*(uint *)(*(longlong *)(&stack0x00000038 + lVar13) + 0x18) <= uVar26)
                      goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100fc3;
                      func_0x(lVar20,7);
                      lVar20 = *(longlong *)(param_1 + 0x170);
                    }
                    iVar25 = uVar31 - (int)uVar19;
                    *(int *)(&stack0x0000002c + lVar13) = iVar25;
                    puVar27 = (uint *)(uVar19 + lVar20);
                  }
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000150 + lVar13;
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100f3c;
                  func_0x(puVar1,puVar21,0,&stack0x00000220 + lVar13);
                  if (*(int *)(&stack0x00000150 + lVar13) != 0) goto LAB_;
                  piVar6 = *(int **)(puVar21 + 2);
                  iVar25 = *piVar6;
                  *(int *)(&stack0x0000002c + lVar13) = iVar25;
                  puVar27 = (uint *)(piVar6 + 1);
                }
                if (((puVar21[0x10] & 0x2000) != 0) && (iVar25 == 0)) {
                  *(undefined4 *)(&stack0x0000002c + lVar13) = 4;
                  puVar27 = (uint *)0x82063c;
                }
                lVar14 = *(longlong *)(&stack0x00000080 + lVar13);
                if ((*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar14 = *(longlong *)(&stack0x00000088 + lVar13);
                }
                *(undefined *)(lVar14 + *(longlong *)(puVar21 + 0xc)) = 0;
                if ((1 << (**(byte **)(param_1 + 0x170) & 0xe) & 0x440U) != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101034;
                  iVar25 = func_0x(puVar21);
                  if (iVar25 != 0) goto LAB_;
                }
                if ((uint)*(ushort *)(puVar21 + 0xf) < *(uint *)(&stack0x0000002c + lVar13)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101060;
                  (*_DAT_)(6,0x52,0x16,0x91);
                }
              }
LAB_:
              uVar31 = *(uint *)(&stack0x0000002c + lVar13);
              lVar14 = *(longlong *)(puVar21 + 0x12);
              if ((puVar21[0x10] & 0x800) == 0) {
                lVar20 = *(longlong *)(&stack0x00000080 + lVar13);
                if ((*(byte *)(lVar14 + 0x2a) & 0x10) != 0) {
                  lVar20 = *(longlong *)(&stack0x00000088 + lVar13);
                }
                lVar14 = *(longlong *)(puVar21 + 10);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1011b5;
                func_0x(lVar20 + lVar14,puVar27);
              }
              else {
                uVar18 = *(ushort *)(lVar14 + 0x2a) & 0x10;
                if (*(int *)(lVar14 + 0x10) == 10) {
                  lVar14 = *(longlong *)(&stack0x00000080 + lVar13);
                  if (uVar18 != 0) {
                    lVar14 = *(longlong *)(&stack0x00000088 + lVar13);
                  }
                  *(uint **)(lVar14 + *(longlong *)(puVar21 + 10)) = puVar27;
                }
                else {
                  lVar14 = *(longlong *)(&stack0x00000080 + lVar13);
                  if (uVar18 != 0) {
                    lVar14 = *(longlong *)(&stack0x00000088 + lVar13);
                  }
                  uVar15 = *(undefined8 *)(*(longlong *)(puVar21 + 10) + lVar14);
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1011e4;
                  func_0x(uVar15,puVar27);
                }
              }
              if ((puVar21[0x10] & 0x100) != 0) {
                lVar14 = *(longlong *)(&stack0x00000080 + lVar13);
                if ((*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar14 = *(longlong *)(&stack0x00000088 + lVar13);
                }
                *(ulonglong *)(lVar14 + *(longlong *)(*(longlong *)(puVar21 + 0x12) + 0x18)) =
                     (ulonglong)uVar31;
              }
            }
            uVar31 = (int)puVar32 + 1;
            puVar21 = puVar21 + 0x14;
            puVar23 = &stack0xffffffffffffffc8 + lVar13;
            puVar32 = (uint *)(ulonglong)uVar31;
          } while (uVar31 < uVar3);
        }
        goto LAB_;
      }
    }
    if (*psVar2 == 0) {
      *psVar2 = 0;
      puVar23 = &stack0xffffffffffffffc8 + lVar13;
      if (((&stack0x0000007c)[lVar13] & 0x10) != 0) {
        uVar31 = *(uint *)(&stack0x00000078 + lVar13);
        *(uint *)((longlong)auStackX_20 + lVar13 + 4) = uVar31;
        lVar14 = *(longlong *)(&stack0x00000070 + lVar13);
        uVar26 = 0;
        puVar23 = &stack0xffffffffffffffc8 + lVar13;
        if (uVar31 != 0) {
          do {
            lVar20 = -0x1cc30b0;
            if (*(byte *)(lVar14 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar14 + 0x40) * 4 + 0x106168) -
                           0x1cc30b0);
                    /* WARNING: Could not emulate address calculation at 0x0010129f */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar12 = *(uint *)(lVar14 + 0x40);
            if ((uVar12 >> 10 & 1) != 0) {
              lVar20 = *(longlong *)(&stack0x00000080 + lVar13);
              if ((*(byte *)(*(longlong *)(lVar14 + 0x48) + 0x2a) & 0x10) != 0) {
                lVar20 = *(longlong *)(&stack0x00000088 + lVar13);
              }
              *(undefined *)(lVar20 + *(longlong *)(lVar14 + 0x30)) = 3;
              uVar12 = *(uint *)(lVar14 + 0x40);
            }
            if ((uVar12 >> 9 & 1) != 0) {
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) =
                   *(undefined4 *)(&stack0x00000028 + lVar13);
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101b40;
              func_0x(&stack0x00000068 + lVar13,lVar20,lVar14,0);
            }
            uVar26 = uVar26 + 1;
            lVar14 = lVar14 + 0x50;
            puVar23 = &stack0xffffffffffffffc8 + lVar13;
          } while (uVar26 < uVar31);
        }
      }
    }
    else if (*(int *)(*(longlong *)(lVar20 + 8) + 0x100) == 2) {
      uVar31 = *(uint *)((longlong)plVar28 + 0x34);
      *(uint *)(&stack0x00000038 + lVar13) = uVar31;
      uVar17 = (ulonglong)uVar31 + 0xf;
      if (uVar17 <= uVar31) {
        uVar17 = 0xffffffffffffff0;
      }
      uVar17 = uVar17 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103b81;
      func_0x();
      lVar20 = -uVar17;
      *(undefined **)(&stack0x000000f0 + lVar13) = auStackX_8 + lVar20 + lVar13;
      puVar23 = &stack0xffffffffffffffc8 + lVar20 + lVar13;
      if (((uVar19 & 0x10) != 0) &&
         (*(undefined4 *)(&stack0x000000ec + lVar13) = 0,
         puVar23 = &stack0xffffffffffffffc8 + lVar20 + lVar13,
         *(int *)((longlong)auStackX_20 + lVar13 + 4) != 0)) {
        do {
          lVar16 = -0x1cc30b0;
          if (*(byte *)(lVar14 + 0x40) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(lVar14 + 0x40) * 4 + 0x1064b8) -
                         0x1cc30b0);
                    /* WARNING: Could not emulate address calculation at 0x00103bcf */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          uVar31 = *(uint *)(lVar14 + 0x40);
          if ((uVar31 >> 10 & 1) != 0) {
            lVar16 = *(longlong *)(&stack0x00000080 + lVar13);
            if ((*(byte *)(*(longlong *)(lVar14 + 0x48) + 0x2a) & 0x10) != 0) {
              lVar16 = *(longlong *)(&stack0x00000088 + lVar13);
            }
            *(undefined *)(lVar16 + *(longlong *)(lVar14 + 0x30)) = 3;
            uVar31 = *(uint *)(lVar14 + 0x40);
          }
          if ((uVar31 >> 9 & 1) != 0) {
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20 + lVar13) =
                 *(undefined4 *)((longlong)auStackX_20 + lVar13);
            *(undefined8 *)((longlong)&uStack_40 + lVar20 + lVar13) = 0x103d5d;
            func_0x(&stack0x00000068 + lVar13,lVar16,lVar14,0);
          }
          iVar25 = *(int *)(&stack0x000000ec + lVar13);
          *(uint *)(&stack0x000000ec + lVar13) = iVar25 + 1U;
          lVar14 = lVar14 + 0x50;
          puVar23 = &stack0xffffffffffffffc8 + lVar20 + lVar13;
        } while (iVar25 + 1U < *(uint *)((longlong)auStackX_20 + lVar13 + 4));
      }
    }
    else {
      if (*psVar2 == -1) {
        *psVar2 = 1;
        uVar19 = (ulonglong)*(uint *)(&stack0x0000007c + lVar13);
        uVar31 = *(uint *)(&stack0x00000078 + lVar13);
        lVar14 = *(longlong *)(&stack0x00000070 + lVar13);
      }
      puVar23 = &stack0xffffffffffffffc8 + lVar13;
      if (((uVar19 & 0x10) != 0) &&
         (uVar26 = 0, puVar23 = &stack0xffffffffffffffc8 + lVar13, uVar31 != 0)) {
        do {
          lVar20 = -0x1cc30b0;
          if (*(byte *)(lVar14 + 0x40) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(lVar14 + 0x40) * 4 + 0x106310) -
                         0x1cc30b0);
                    /* WARNING: Could not emulate address calculation at 0x001032af */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          uVar12 = *(uint *)(lVar14 + 0x40);
          if ((uVar12 >> 10 & 1) != 0) {
            lVar20 = *(longlong *)(&stack0x00000080 + lVar13);
            if ((*(byte *)(*(longlong *)(lVar14 + 0x48) + 0x2a) & 0x10) != 0) {
              lVar20 = *(longlong *)(&stack0x00000088 + lVar13);
            }
            *(undefined *)(lVar20 + *(longlong *)(lVar14 + 0x30)) = 3;
            uVar12 = *(uint *)(lVar14 + 0x40);
          }
          if ((uVar12 >> 9 & 1) != 0) {
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) =
                 *(undefined4 *)(&stack0x00000050 + lVar13);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103476;
            func_0x(&stack0x00000068 + lVar13,lVar20,lVar14,0);
          }
          uVar26 = uVar26 + 1;
          lVar14 = lVar14 + 0x50;
          puVar23 = &stack0xffffffffffffffc8 + lVar13;
        } while (uVar26 < uVar31);
      }
    }
  }
  else {
    *(uint *)(&stack0x0000019c + lVar13) = *(uint *)(&stack0x0000019c + lVar13) & 0xfffffff8;
    *(undefined8 *)(&stack0x000001a0 + lVar13) = 0;
    lVar14 = *(longlong *)(param_1 + 0x20);
    *(longlong *)(&stack0x00000168 + lVar13) = param_1 + 0x2a0;
    *(undefined **)(&stack0x00000170 + lVar13) = &stack0x000001a8 + lVar13;
    *(undefined4 *)(&stack0x00000178 + lVar13) = 1;
    *(undefined4 *)(&stack0x0000017c + lVar13) = 1;
    *(longlong *)(&stack0x00000180 + lVar13) = lVar14;
    lVar14 = *(longlong *)(lVar14 + 8);
    lVar20 = lVar14;
    if (*(longlong *)(lVar14 + 0x478) != 0) {
      lVar20 = *(longlong *)(lVar14 + 0x478);
    }
    if ((*(short *)(lVar20 + 0x440) == 0) && (*(short *)(lVar14 + 0xce) == 0)) {
      uVar31 = *(uint *)(&stack0x0000019c + lVar13);
    }
    else {
      uVar31 = *(uint *)(&stack0x0000019c + lVar13) | 1;
      *(uint *)(&stack0x0000019c + lVar13) = uVar31;
    }
    lVar14 = *(longlong *)(&stack0x00000180 + lVar13);
    if ((0x1f7c < *(uint *)(*(longlong *)(lVar14 + 8) + 0xb0)) &&
       ((*(byte *)(*(longlong *)(lVar14 + 8) + 0x106) & 4) == 0)) {
      uVar31 = uVar31 | 2;
      *(uint *)(&stack0x0000019c + lVar13) = uVar31;
    }
    *(undefined4 *)(&stack0x00000188 + lVar13) =
         *(undefined4 *)(*(longlong *)(lVar14 + 0x20) + 0x664);
    *(ulonglong *)(&stack0x00000190 + lVar13) = (ulonglong)*(uint6 *)(lVar14 + 0x14) << 0x10;
    *(undefined2 *)(&stack0x00000198 + lVar13) =
         *(undefined2 *)(*(longlong *)(lVar14 + 0x20) + 0x660);
    *(uint *)(&stack0x0000019c + lVar13) = uVar31 | 4;
    *(undefined8 *)(&stack0x000003e8 + lVar13) = 0;
    *(undefined8 *)(&stack0x000003f0 + lVar13) = 0;
    *(undefined4 *)(&stack0x000003f8 + lVar13) = 0;
    *(undefined8 *)(&stack0x00000400 + lVar13) = 0;
    *(undefined4 *)(&stack0x00000408 + lVar13) = 0;
    *(longlong *)(&stack0x000001b0 + lVar13) = param_1 + 0x168;
    *(undefined8 *)(&stack0x000001b8 + lVar13) = 0;
    lVar14 = *(longlong *)(&stack0x00000068 + lVar13);
    puVar21 = puVar27;
    if ((*(byte *)(lVar14 + 0x38) & 8) != 0) {
      puVar21 = (uint *)(&stack0x000003e8 + lVar13);
      uVar3 = *(ushort *)(lVar14 + 0x62);
      *(uint *)(&stack0x000003e8 + lVar13) = (uint)uVar3;
      *(undefined4 *)(&stack0x00000408 + lVar13) = 0x1f9e;
      *(undefined **)(&stack0x00000400 + lVar13) = &stack0x0000040c + lVar13;
      uVar17 = (ulonglong)(uint)uVar3 * 0x40;
      uVar19 = uVar17 + 0xf;
      if (uVar19 <= uVar17) {
        uVar19 = 0xffffffffffffff0;
      }
      uVar19 = uVar19 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x106070;
      func_0x();
      lVar20 = -uVar19;
      puVar22 = &stack0xffffffffffffffc8 + lVar20 + lVar13;
      *(undefined **)(&stack0x000003f0 + lVar13) = auStackX_8 + lVar20 + lVar13;
      *(undefined8 *)((longlong)&uStack_40 + lVar20 + lVar13) = 0x106086;
      func_0x(auStackX_8 + lVar20 + lVar13,0);
    }
    *(undefined8 *)(puVar22 + 0x28) = 0;
    *(undefined **)(puVar22 + 0x20) = &stack0x00000144 + lVar13;
    *(undefined8 *)(puVar22 + -8) = 0x1060b1;
    uVar34 = func_0x
                       (&stack0x00000168 + lVar13,&stack0x00000068 + lVar13,puVar21,
                        &stack0x0000020c + lVar13);
    if (*(int *)(&stack0x00000144 + lVar13) == 2) {
      UNRECOVERED_JUMPTABLE = *(code **)(_DAT_ + 0x10);
      *(undefined8 *)(puVar22 + -8) = 0x1060c7;
      uVar34 = (*UNRECOVERED_JUMPTABLE)(0);
    }
    if ((*(byte *)(lVar14 + 0x38) & 8) != 0) {
      *(undefined **)(puVar22 + 0x28) = &stack0x00000068 + lVar13;
      *(longlong *)(puVar22 + 0x20) = param_1 + 0x2a0;
      *(undefined8 *)(puVar22 + -8) = 0x1060e8;
      func_0x(uVar34,0,0,puVar21);
    }
    lVar14 = *(longlong *)(&stack0x000003f0 + lVar13);
    puVar23 = puVar22;
    if ((lVar14 != 0) && (uVar31 = *(uint *)(&stack0x000003e8 + lVar13), uVar31 != 0)) {
      do {
        lVar20 = (longlong)puVar27 * 0x40;
        if ((*(byte *)(lVar14 + 0x18 + lVar20) & 4) != 0) {
          uVar15 = *(undefined8 *)(lVar14 + 0x20 + lVar20);
          *(undefined8 *)(puVar22 + -8) = 0x106119;
          (*_DAT_)(uVar15);
          pbVar29 = (byte *)(*(longlong *)(&stack0x000003f0 + lVar13) + 0x18 + lVar20);
          *pbVar29 = *pbVar29 & 0xfb;
          lVar14 = *(longlong *)(&stack0x000003f0 + lVar13);
          uVar31 = *(uint *)(&stack0x000003e8 + lVar13);
        }
        uVar26 = (int)puVar27 + 1;
        puVar27 = (uint *)(ulonglong)uVar26;
      } while (uVar26 < uVar31);
    }
  }
LAB_:
  uVar19 = *(ulonglong *)(&stack0x000023b8 + lVar13);
  *(undefined8 *)(puVar23 + -8) = 0x10614b;
  func_0x(uVar19 ^ (ulonglong)(auStackX_8 + lVar13));
  return;
}

