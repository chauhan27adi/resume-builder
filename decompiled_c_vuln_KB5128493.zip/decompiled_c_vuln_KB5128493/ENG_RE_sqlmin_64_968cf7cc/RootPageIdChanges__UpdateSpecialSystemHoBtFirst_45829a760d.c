
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,longlong param_3,undefined8 *param_4)

{
  byte *pbVar1;
  short sVar2;
  undefined4 uVar3;
  short **ppsVar4;
  undefined8 uVar5;
  uint6 uVar6;
  char cVar7;
  longlong lVar8;
  short *psVar9;
  code *UNRECOVERED_JUMPTABLE_00;
  short *psVar10;
  ulonglong uVar11;
  int iVar12;
  byte *pbVar13;
  undefined2 uVar14;
  short *psVar15;
  ulonglong uVar16;
  undefined8 uStackX_10;
  undefined2 auStackX_18 [4];
  undefined4 uStackX_20;
  undefined2 auStackX_24 [2];
  short sStack_20b8;
  byte **ppbStack_20a8;
  undefined auStack_2080 [16];
  undefined auStack_2070 [8];
  undefined8 uStack_2068;
  undefined8 uStack_2060;
  undefined6 uStack_2058;
  undefined2 uStack_2052;
  undefined6 uStack_2050;
  undefined2 uStack_204a;
  undefined8 uStack_2048;
  undefined auStack_2040 [16];
  undefined auStack_2030 [16];
  undefined auStack_2020 [16];
  undefined8 uStack_2010;
  longlong lStack_2008;
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar8);
  uVar3 = *(undefined4 *)(uint6 *)(param_3 + 0x3c0);
  uVar6 = *(uint6 *)(param_3 + 0x3c0);
  *(undefined2 *)(&stack0x0000002c + lVar8) = *(undefined2 *)(param_3 + 0x3c4);
  *(undefined4 *)(&stack0x00000028 + lVar8) = uVar3;
  ppsVar4 = (short **)*param_4;
  sStack_20b8 = -1;
  ppbStack_20a8 = (byte **)0x0;
  *(undefined4 *)((longlong)&uStackX_20 + lVar8 + -0x20) = 0;
  *(undefined2 *)(&stack0x0000002e + lVar8) = 0;
  lStack_2008 = (ulonglong)uVar6 << 0x10;
  psVar9 = *ppsVar4;
  *(longlong *)(&stack0x00000030 + lVar8) = param_3;
  psVar10 = (short *)0x0;
  if (psVar9 != (short *)0x0) {
    psVar10 = psVar9;
  }
  *(undefined4 *)((longlong)auStackX_24 + lVar8 + -0x20) = 0;
  psVar15 = (short *)0x0;
  if (psVar9 != (short *)0x0) {
    psVar15 = psVar9 + 0x1000;
  }
  if (psVar15 == (short *)0x0) {
LAB_:
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0x1251880;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101164;
    (*_DAT_)(1,0x1215394,0x12113c8,0x73d);
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101173;
    func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar8));
    return;
  }
  do {
    psVar15 = psVar15 + -1;
    uVar11 = (ulonglong)psVar15 & 0xffffffffffffe000;
    iVar12 = (int)((longlong)((uVar11 - (longlong)psVar15) + 0x1ffe) >> 1);
    if ((int)(uint)(ushort)psVar10[0xb] <= iVar12) goto LAB_;
  } while (*psVar15 == 0);
  if (psVar15 == (short *)0x0) goto LAB_;
  if (-1 < *(char *)(uVar11 + 2)) goto LAB_;
  pbVar13 = (byte *)(uVar11 + 0x60);
  if ((sStack_20b8 == 0) || (ppbStack_20a8 == (byte **)0x0)) {
    ppbStack_20a8 = (byte **)auStack_2080;
    uStack_2058 = 0;
    stack0xffffffffffffdf92 = SUB1614(ZEXT816(0),2);
    auStack_2070._0_2_ = 0xffff;
    uStack_204a = 0;
    uStack_2068 = 0;
    uStack_2052 = 0;
    uStack_2050 = 0;
    uStack_2048 = 0;
    uStack_2060 = 0;
    auStack_2040 = ZEXT816(0);
    auStack_2020._0_12_ = ZEXT812(0);
    auStack_2020._12_4_ = 0;
    uStack_2010 = 0;
    auStack_2030 = ZEXT816(0);
    auStack_2080 = ZEXT816(0);
  }
  if (*(short *)(uVar11 + 0x24) == 0) {
LAB_:
    uVar14 = *(undefined2 *)(uVar11 + 0x30);
    *(undefined8 *)((longlong)&uStackX_10 + lVar8) = *(undefined8 *)(uVar11 + 0x28);
    *(undefined2 *)((longlong)auStackX_18 + lVar8) = uVar14;
  }
  else {
    cVar7 = *(char *)(uVar11 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(uVar11 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(uVar11 + 0x18) != 99) goto LAB_;
    }
    *(undefined4 *)((longlong)&uStackX_20 + lVar8) = *(undefined4 *)(uVar11 + 0x20);
    *(undefined2 *)((longlong)auStackX_24 + lVar8) = *(undefined2 *)(uVar11 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1001e7;
    cVar7 = func_0x((longlong)&uStackX_20 + lVar8);
    if (cVar7 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1001f8;
    func_0x(uVar11,(longlong)&uStackX_10 + lVar8);
    uVar14 = *(undefined2 *)((longlong)auStackX_18 + lVar8);
  }
  uVar3 = *(undefined4 *)((longlong)&uStackX_10 + lVar8);
  *ppbStack_20a8 = pbVar13;
  *(undefined4 *)(ppbStack_20a8 + 0xc) = uVar3;
  uVar5 = *(undefined8 *)((longlong)&uStackX_10 + lVar8);
  *(undefined2 *)(ppbStack_20a8 + 0xd) = uVar14;
  *(int *)((longlong)ppbStack_20a8 + 100) = (int)((ulonglong)uVar5 >> 0x20);
  *(undefined4 *)((longlong)ppbStack_20a8 + 0x6c) = *(undefined4 *)(uVar11 + 0x20);
  *(undefined2 *)(ppbStack_20a8 + 0xe) = *(undefined2 *)(uVar11 + 0x24);
  *(undefined2 *)((longlong)ppbStack_20a8 + 0x72) = 0;
  uVar16 = (ulonglong)*(short *)((ulonglong)*pbVar13 * 6 + 0xe88294);
  *(undefined4 *)(&stack0x00000038 + lVar8) = *(undefined4 *)((ulonglong)*pbVar13 * 6 + 0xe88290);
  *(undefined2 *)(ppbStack_20a8 + 2) = 0xffff;
  ppbStack_20a8[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbStack_20a8 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbStack_20a8 + 0x2e) = 0;
  ppbStack_20a8[7] = (byte *)0x0;
  ppbStack_20a8[4] = (byte *)0x0;
  ppbStack_20a8[9] = (byte *)0x0;
  ppbStack_20a8[10] = (byte *)0x0;
  *(undefined2 *)(ppbStack_20a8 + 0xb) = 0;
  if ((**ppbStack_20a8 & 2) != 0) {
    pbVar1 = pbVar13 + uVar16;
    if ((pbVar13[uVar16] & 1) == 0) {
      *(undefined2 *)(ppbStack_20a8 + 2) = 0;
      *(undefined4 *)((longlong)ppbStack_20a8 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbStack_20a8 + 0x36) = 0;
      ppbStack_20a8[3] = pbVar1;
                    /* WARNING: Could not emulate address calculation at 0x00100472 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x1011b8) - 0x16b1ba0))()
      ;
      return;
    }
    *(undefined2 *)(ppbStack_20a8 + 2) = 1;
    ppbStack_20a8[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x101198) * 4 +
                           0x101188) - 0x16b1ba0);
                    /* WARNING: Could not emulate address calculation at 0x001002d0 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbStack_20a8 & 4) != 0) {
    if (*(short *)(&stack0x0000003a + lVar8) != 0) {
      uVar16 = (ulonglong)
               *(ushort *)(uVar11 + 0x61 + (longlong)*(short *)(&stack0x0000003a + lVar8) * 2);
    }
    psVar9 = (short *)(pbVar13 + uVar16);
    ppbStack_20a8[9] = (byte *)psVar9;
    sVar2 = *psVar9;
    ppbStack_20a8[10] = (byte *)(psVar9 + 1);
    *(short *)(ppbStack_20a8 + 0xb) = (sVar2 + 1) * 2;
  }
  pbVar13 = ppbStack_20a8[1];
  if (pbVar13 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100537;
    func_0x(pbVar13,ppbStack_20a8);
  }
LAB_:
  pbVar13 = (byte *)(*(ushort *)(uVar11 + (0xfff - (longlong)iVar12) * 2) + uVar11);
  if ((*pbVar13 & 1) == 0) {
                    /* WARNING: Could not emulate address calculation at 0x001006d3 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar13 & 0xe) * 4 + 0x101224) - 0x16b1ba0))();
    return;
  }
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar13 & 0x1c) + 0x101204) * 4 +
                         0x1011f4) - 0x16b1ba0);
                    /* WARNING: Could not emulate address calculation at 0x00100589 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

