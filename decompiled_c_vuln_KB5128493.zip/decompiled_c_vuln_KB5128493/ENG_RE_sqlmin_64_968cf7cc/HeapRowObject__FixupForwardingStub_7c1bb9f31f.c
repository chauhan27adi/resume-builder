
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,undefined8 param_3)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  code *pcVar5;
  byte *pbVar6;
  undefined8 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  char cVar16;
  char cVar17;
  byte bVar18;
  ushort uVar19;
  short sVar20;
  int iVar21;
  longlong *plVar22;
  ulonglong *puVar23;
  undefined4 *puVar24;
  uint uVar25;
  undefined8 *puVar26;
  undefined4 *puVar27;
  longlong lVar28;
  ushort uVar29;
  short sVar30;
  uint uVar31;
  ulonglong uVar32;
  longlong lVar33;
  int iVar34;
  ushort *puVar35;
  undefined4 *puVar36;
  undefined2 *puVar37;
  longlong lVar38;
  short *psVar39;
  byte **ppbVar40;
  ushort *puVar41;
  undefined8 uVar42;
  longlong unaff_GS_OFFSET;
  undefined auStack_718 [64];
  undefined auStack_6d8 [16];
  undefined auStack_6c8 [8];
  undefined8 uStack_6c0;
  undefined8 uStack_6b8;
  undefined6 uStack_6b0;
  undefined2 uStack_6aa;
  undefined6 uStack_6a8;
  undefined2 uStack_6a2;
  undefined8 uStack_6a0;
  undefined auStack_698 [16];
  undefined auStack_688 [16];
  undefined auStack_678 [16];
  undefined8 uStack_668;
  undefined auStack_658 [8];
  undefined8 uStack_650;
  undefined2 auStack_648 [2];
  undefined4 uStack_644;
  undefined8 uStack_640;
  undefined8 uStack_638;
  undefined8 uStack_62a;
  undefined8 uStack_620;
  char cStack_608;
  char cStack_607;
  longlong lStack_600;
  int iStack_5f8;
  uint uStack_5f4;
  undefined8 *puStack_5f0;
  undefined4 uStack_5e8;
  undefined2 uStack_5e4;
  undefined2 uStack_5e2;
  undefined8 uStack_5e0;
  uint uStack_5d8;
  longlong lStack_5d0;
  undefined4 uStack_5c8;
  undefined4 uStack_5c4;
  undefined *puStack_5c0;
  undefined8 uStack_5b8;
  undefined4 uStack_5b0;
  undefined2 uStack_5ac;
  undefined8 uStack_5aa;
  undefined2 uStack_5a2;
  undefined2 uStack_5a0;
  undefined6 uStack_59e;
  undefined4 uStack_598;
  undefined4 *puStack_590;
  longlong *plStack_588;
  undefined4 *puStack_580;
  undefined2 *puStack_578;
  undefined *puStack_570;
  undefined4 uStack_568;
  undefined *puStack_560;
  undefined4 auStack_558 [64];
  undefined4 auStack_458 [64];
  undefined4 auStack_358 [64];
  undefined4 auStack_258 [64];
  undefined4 auStack_158 [64];
  undefined uStack_58;
  undefined8 uStack_57;
  ulonglong uStack_48;
  
  puVar37 = auStack_648;
  uStack_48 = _DAT_ ^ (ulonglong)&cStack_608;
  uStack_5aa = 0;
  uStack_5a0 = 0;
  uStack_59e = 0;
  uStack_5b8 = 0;
  iVar34 = *(int *)(*(longlong *)(**(longlong **)(param_1 + 0x28) + 8) + 0x100);
  puStack_578 = (undefined2 *)0x0;
  plVar4 = (longlong *)(*(longlong **)(param_1 + 0x28))[1];
  uStack_650 = 0x100075;
  uStack_5e0 = param_3;
  lStack_5d0 = param_1;
  cVar16 = (**(code **)(*plVar4 + 0x88))(plVar4);
  cStack_608 = cVar16 == '\0';
  uStack_650 = 0x100083;
  cVar16 = (**(code **)*plVar4)(plVar4);
  uStack_5f4 = (uint)(cVar16 == '\0');
  uStack_650 = 0x100096;
  cStack_607 = (**(code **)(*plVar4 + 8))(plVar4);
  lVar28 = param_1 + 0x30;
  uStack_650 = 0x1000a9;
  lStack_600 = lVar28;
  func_0x(lVar28);
  plVar4 = (longlong *)(param_1 + 0x2b0);
  uStack_650 = 0x1000b8;
  func_0x(plVar4);
  *(byte *)(param_1 + 0x531) = *(byte *)(param_1 + 0x531) & 0xfd;
  puVar36 = (undefined4 *)(param_1 + 0x530);
  *(byte *)puVar36 = *(byte *)puVar36 & 0xf9 | 1;
  puStack_590 = puVar36;
  if (*(longlong **)(param_2 + 0x28) == (longlong *)0x0) {
    if (*(int *)(param_2 + 0xc0) != 2) {
      uStack_650 = 0x100102;
      func_0x(param_2);
      if (*(int *)(param_2 + 0xc0) != 2) {
        lVar38 = **(longlong **)(param_2 + 0x28);
        goto LAB_;
      }
    }
    lVar38 = 0;
  }
  else {
    lVar38 = **(longlong **)(param_2 + 0x28);
  }
LAB_:
  uStack_5e8 = *(undefined4 *)(lVar38 + 0x20);
  uStack_5e4 = *(undefined2 *)(lVar38 + 0x24);
  uStack_5e2 = *(undefined2 *)(param_2 + 0x20);
  uStack_650 = 0x10013a;
  func_0x(param_2);
  if ((iVar34 == 0) || (iVar34 - 3U < 2)) {
    uStack_5a2 = 0;
    uStack_5a0 = 0;
    puStack_5c0 = &uStack_58;
    uStack_5c8 = 0;
    uStack_5b8 = 0x900000009;
    uStack_5c4 = 9;
    uStack_5b0 = 9;
    uStack_58 = 4;
    uStack_5ac = 0;
    uStack_650 = 0x1001da;
    func_0x(&uStack_57,8,&uStack_5e8);
  }
  else {
    puStack_5c0 = &uStack_58;
    uStack_5ac = 0;
    uStack_57 = CONCAT26(uStack_5e2,CONCAT24(uStack_5e4,uStack_5e8));
    uStack_5a2 = 0;
    uStack_5c8 = 1;
    uStack_5b0 = 0;
    uStack_58 = 9;
    uStack_5c4 = 9;
    uStack_598 = 0;
  }
  puStack_580 = &uStack_5c8;
  if (*(longlong *)(param_1 + 0x58) == 0) {
    uStack_650 = 0x1001f6;
    func_0x(lVar28);
  }
  uVar31 = uStack_5f4;
  if (*(int *)(param_1 + 0x270) == 0) {
    uStack_650 = 0x10020f;
    func_0x(lVar28);
  }
  iVar34 = *(int *)(param_1 + 0x268);
  iStack_5f8 = iVar34;
  if (*(longlong **)(param_1 + 0x58) == (longlong *)0x0) {
    if (*(int *)(param_1 + 0xf0) != 2) {
      uStack_650 = 0x100243;
      func_0x(lVar28);
      if (*(int *)(param_1 + 0xf0) != 2) {
        lVar38 = **(longlong **)(param_1 + 0x58);
        goto LAB_;
      }
    }
    lVar38 = 0;
  }
  else {
    lVar38 = **(longlong **)(param_1 + 0x58);
  }
LAB_:
  if (*(char *)(lVar38 + 2) < '\0') {
    auStack_648[0] = 0xffff;
    uStack_640 = 0;
    uStack_644 = 0;
    uStack_62a = 0;
    uStack_620 = 0;
    uStack_638 = 0;
    puStack_570 = auStack_658;
    puVar37 = (undefined2 *)auStack_718;
    puStack_560 = auStack_6d8;
    auStack_6d8 = ZEXT816(0);
    uStack_6b0 = 0;
    uStack_6a2 = 0;
    auStack_688 = ZEXT816(0);
    stack0xfffffffffffff93a = SUB1614(ZEXT816(0),2);
    auStack_6c8._0_2_ = 0xffff;
    uStack_6c0 = 0;
    uStack_6aa = 0;
    uStack_6a8 = 0;
    uStack_6a0 = 0;
    uStack_6b8 = 0;
    auStack_698 = ZEXT816(0);
    auStack_678._0_12_ = ZEXT812(0);
    auStack_678._12_4_ = 0;
    uStack_668 = 0;
    uStack_568 = 9;
    puStack_578 = auStack_648;
    func_0x(&puStack_580);
  }
  lVar38 = param_1;
  uVar42 = uStack_5e0;
  if ((cStack_608 == '\0') || (lVar38 = param_1, iVar34 != 3)) goto LAB_;
  *(undefined8 *)((longlong)puVar37 + -8) = 0x10034a;
  func_0x(lVar28);
  plVar22 = *(longlong **)(*(longlong *)(param_1 + 0x28) + 8);
  plStack_588 = plVar22 + 5;
  pcVar5 = *(code **)(*plVar22 + 0x58);
  *(undefined8 *)((longlong)puVar37 + -8) = 0x100363;
  cVar16 = (*pcVar5)();
  uStack_5d8 = -(uint)(cVar16 != '\0') & 0x80;
  if (*(undefined8 **)(param_1 + 0x2d8) == (undefined8 *)0x0) {
    puVar26 = (undefined8 *)0x0;
    puStack_5f0 = puVar26;
    if (*(int *)(param_1 + 0x370) != 2) {
      *(undefined8 *)((longlong)puVar37 + -8) = 0x1003a6;
      func_0x(plVar4);
      puStack_5f0 = (undefined8 *)0x0;
      puVar26 = *(undefined8 **)(param_1 + 0x2d8);
      if (*(int *)(param_1 + 0x370) != 2) {
        puStack_5f0 = (undefined8 *)*puVar26;
      }
    }
    cVar16 = *(char *)(param_1 + 0x4f8);
    if (puVar26 == (undefined8 *)0x0) {
      *(undefined8 *)((longlong)puVar37 + -8) = 0x1003d8;
      func_0x(plVar4,0);
    }
  }
  else {
    puStack_5f0 = (undefined8 *)**(undefined8 **)(param_1 + 0x2d8);
    cVar16 = *(char *)(param_1 + 0x4f8);
  }
  if (*(int *)(param_1 + 0x4f0) == 0) {
    *(undefined8 *)((longlong)puVar37 + -8) = 0x1003ec;
    func_0x(plVar4,uVar31);
  }
  if (_DAT_ != 0) {
    plVar22 = *(longlong **)(param_1 + 0x380);
    puVar26 = *(undefined8 **)(*(longlong *)(param_1 + 0x2b8) + 8);
    iVar34 = *(int *)(plVar22 + 2);
    cVar1 = *(char *)(puVar26[6] + 0x1cde);
    pcVar5 = *(code **)*puVar26;
    *(undefined8 *)((longlong)puVar37 + -8) = 0x100426;
    cVar17 = (*pcVar5)(puVar26);
    lVar28 = lStack_600;
    if (cVar17 == '\0') {
      if (cVar1 == '\0') {
        if (iVar34 << 0x1f < 0) {
          if ((*(byte *)(plVar22 + 2) & 0x40) == 0) goto LAB_;
          lVar38 = puVar26[0x1a];
          if (((lVar38 != 0) && (*(char *)(lVar38 + 0x34) != '\0')) &&
             (*(longlong *)(lVar38 + 0x40) != 0)) {
            LOCK();
            lVar33 = *(longlong *)(lVar38 + 0x128);
            if (lVar33 == 0) {
              *(longlong *)(lVar38 + 0x128) = 0;
              lVar33 = 0;
            }
            UNLOCK();
            if (*(longlong *)(*plVar22 + 0x28) != lVar33) goto LAB_;
          }
        }
      }
      else {
LAB_:
        lVar38 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x2b8) + 8) + 0x30);
        if (*(int *)(param_1 + 0x4f4) == 0) {
          if (*(int *)(*(longlong *)(lVar38 + 0x6b0) + 0x5ec) == 1) {
            *(undefined8 *)((longlong)puVar37 + -8) = 0x1004bf;
            plVar22 = (longlong *)func_0x(lVar38 + 0x18);
            *plVar22 = *plVar22 + 1;
            lVar28 = lStack_600;
          }
        }
        else if (*(int *)(*(longlong *)(lVar38 + 0x6b0) + 0x5ec) == 1) {
          *(undefined8 *)((longlong)puVar37 + -8) = 0x1004a4;
          plVar22 = (longlong *)func_0x(lVar38 + 0x28);
          *plVar22 = *plVar22 + 1;
          lVar28 = lStack_600;
        }
      }
    }
  }
  if (cVar16 == '\0') {
    psVar39 = (short *)(param_1 + 0x388);
    ppbVar40 = (byte **)(param_1 + 0x390);
    puVar35 = (ushort *)(param_1 + 0x38a);
  }
  else {
    psVar39 = (short *)(param_1 + 0x438);
    ppbVar40 = (byte **)(param_1 + 0x440);
    puVar35 = (ushort *)(param_1 + 0x43a);
  }
  uVar31 = *(uint *)(puVar35 + 1);
  if (*psVar39 == 0) {
    if (uVar31 == 0) {
      pbVar6 = *(byte **)(puVar35 + 3);
      uVar31 = *(uint *)(puVar35 + 7);
      uVar32 = (ulonglong)uVar31;
      *puVar35 = 0;
      *(uint *)(puVar35 + 9) = uVar31;
      bVar18 = *pbVar6;
      if ((bVar18 & 0x10) != 0) {
        uVar31 = uVar31 + 2 + (*(ushort *)(pbVar6 + uVar32) + 7 >> 3);
        uVar32 = (ulonglong)uVar31;
        *(uint *)(puVar35 + 9) = uVar31;
        bVar18 = *pbVar6;
      }
      if ((bVar18 & 0x20) == 0) {
        *(int *)(puVar35 + 1) = (int)uVar32;
        puVar35[0xd] = 0;
        *(int *)(puVar35 + 0xb) = (int)uVar32;
      }
      else {
        puVar41 = (ushort *)(pbVar6 + uVar32);
        uVar19 = *puVar41;
        puVar35[0xd] = uVar19;
        if (uVar19 == 0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar38 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar38 != 0 &&
              ((lVar38 = *(longlong *)(lVar38 + 0x60), lVar38 != 0 &&
               (*(char *)(lVar38 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)puVar37 + -8) = 0x1005e7;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)((longlong)puVar37 + 0x20) = 0;
              *(undefined8 *)((longlong)puVar37 + -8) = 0x10060d;
              (*_DAT_)(1,0x1861b48,0x1981818,0x80f);
            }
          }
          uVar42 = *(undefined8 *)(puVar35 + 3);
          *(undefined8 *)((longlong)puVar37 + -8) = 0x10061b;
          func_0x(uVar42,3);
          uVar19 = puVar35[0xd];
          uVar32 = (ulonglong)*(uint *)(puVar35 + 9);
        }
        uVar31 = (int)uVar32 + (uVar19 + 1) * 2;
        *(uint *)(puVar35 + 0xb) = uVar31;
        if (0x1f9e < uVar31) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar38 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar38 != 0)) &&
             ((lVar38 = *(longlong *)(lVar38 + 0x60), lVar38 != 0 &&
              (*(char *)(lVar38 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)puVar37 + -8) = 0x1006ba;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)puVar37 + 0x20) = 0;
              *(undefined8 *)((longlong)puVar37 + -8) = 0x1006e0;
              (*_DAT_)(1,0x1861b48,0x1981818,0x816);
            }
          }
          uVar42 = *(undefined8 *)(puVar35 + 3);
          *(undefined8 *)((longlong)puVar37 + -8) = 0x1006ee;
          func_0x(uVar42,4);
          uVar19 = puVar35[0xd];
          uVar31 = *(uint *)(puVar35 + 0xb);
        }
        uVar29 = puVar41[uVar19];
        *(uint *)(puVar35 + 1) = uVar29 & 0x7fff;
        if ((uVar29 & 0x7fff) < uVar31) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar38 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar38 != 0 &&
              ((lVar38 = *(longlong *)(lVar38 + 0x60), lVar38 != 0 &&
               (*(char *)(lVar38 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)puVar37 + -8) = 0x10078d;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)puVar37 + 0x20) = 0;
              *(undefined8 *)((longlong)puVar37 + -8) = 0x1007b3;
              (*_DAT_)(1,0x1861b48,0x1981818,0x81d);
            }
          }
          uVar42 = *(undefined8 *)(puVar35 + 3);
          *(undefined8 *)((longlong)puVar37 + -8) = 0x1007c1;
          func_0x(uVar42,4);
          uVar19 = puVar35[0xd];
        }
        if ((short)puVar41[(ulonglong)(uVar19 - 1) + 1] < 0) {
          do {
            lVar38 = *(longlong *)(puVar35 + 3);
            lVar33 = (ulonglong)*(uint *)(puVar35 + 9) + lVar38;
            if (uVar19 == 1) {
              uVar31 = *(uint *)(puVar35 + 0xb);
              uVar25 = uVar31;
LAB_:
              if ((*(ushort *)(lVar33 + (ulonglong)uVar19 * 2) & 0x7fff) < uVar31)
              goto LAB_;
            }
            else {
              uVar25 = *(uint *)(puVar35 + 0xb);
              uVar31 = *(ushort *)(lVar33 + -2 + (ulonglong)uVar19 * 2) & 0x7fff;
              if (uVar25 <= uVar31) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)puVar37 + -8) = 0x100826;
              func_0x(lVar38,7);
              uVar25 = *(uint *)(puVar35 + 0xb);
            }
            if ((uVar31 < uVar25) || (*(uint *)(puVar35 + 1) < uVar31)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar31 + *(longlong *)(puVar35 + 3)) == 5) {
              *puVar35 = *puVar35 | 2;
              puVar35[0xd] = puVar35[0xd] - 1;
              puVar35[0x14] = (ushort)uVar31;
              lVar38 = (ulonglong)(uVar31 & 0xffff) + *(longlong *)(puVar35 + 3);
              uVar19 = puVar35[0x15] & 0xc7ff;
              if ((*(ushort *)(lVar38 + 2) & 0x4000) != 0) {
                uVar19 = *(ushort *)(lVar38 + 2) & 0x3800 | puVar35[0x15] & 0xc7ff;
              }
              puVar35[0x15] = uVar19;
              puVar35[0x15] = (uVar19 ^ *(ushort *)(lVar38 + 2)) & 0x7ff ^ uVar19;
              uVar32 = (ulonglong)*(uint *)(puVar35 + 1);
              goto LAB_;
            }
            if (*(ushort *)((ulonglong)uVar31 + *(longlong *)(puVar35 + 3)) < 0x400) break;
            *puVar35 = *puVar35 | 1;
            uVar19 = puVar35[0xd] - 1;
            puVar35[0xd] = uVar19;
            if ((uVar19 == 0) || (-1 < (short)puVar41[(ulonglong)(uVar19 - 1) + 1])) break;
          } while( true );
        }
        uVar32 = (ulonglong)*(uint *)(puVar35 + 1);
      }
LAB_:
      iVar34 = 0;
      if ((**(byte **)(puVar35 + 3) & 0x40) == 0) {
        *(undefined4 *)(puVar35 + 0x12) = 0;
      }
      else {
        *(int *)(puVar35 + 0x12) = (int)uVar32;
        *(int *)(puVar35 + 1) = (int)uVar32 + 0xe;
        *(undefined8 *)((longlong)puVar37 + -8) = 0x10091a;
        puVar23 = (ulonglong *)func_0x(puVar35);
        uVar32 = *puVar23;
        uVar29 = (ushort)(uVar32 >> 0x30);
        uVar19 = uVar29;
        if ((((uint)(int)(short)uVar29 >> 1 ^ (int)(short)uVar29) & 0x2000) != 0) {
          uVar19 = uVar29 & 0xdfff;
          if ((uVar32 & 0x4000000000000000) != 0) {
            uVar19 = uVar29 | 0x2000;
          }
        }
        if (uVar19 == 0xfffc) {
          iVar34 = (int)((uVar32 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(puVar35 + 1) = *(int *)(puVar35 + 1) + iVar34;
        uVar32 = (ulonglong)*(uint *)(puVar35 + 1);
      }
      iVar34 = (int)uVar32;
      if ((*(ulonglong *)(puVar35 + 0xe) != 0) &&
         (*(ulonglong *)(puVar35 + 0xe) < uVar32 + *(longlong *)(puVar35 + 3))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar38 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar38 != 0 &&
             (lVar38 = *(longlong *)(lVar38 + 0x60), lVar38 != 0)) &&
            (*(char *)(lVar38 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)puVar37 + -8) = 0x100a15;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)((longlong)puVar37 + 0x20) = 0;
            *(undefined8 *)((longlong)puVar37 + -8) = 0x100a3b;
            (*_DAT_)(1,0x1861b48,0x1981818,0x877);
          }
        }
        uVar42 = *(undefined8 *)(puVar35 + 3);
        *(undefined8 *)((longlong)puVar37 + -8) = 0x100a49;
        func_0x(uVar42,0x12);
        iVar34 = *(int *)(puVar35 + 1);
      }
      if (0x3f3b < iVar34 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar38 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar38 != 0 &&
            ((lVar38 = *(longlong *)(lVar38 + 0x60), lVar38 != 0 &&
             (*(char *)(lVar38 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)puVar37 + -8) = 0x100ad5;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)((longlong)puVar37 + 0x20) = 0;
            *(undefined8 *)((longlong)puVar37 + -8) = 0x100afb;
            (*_DAT_)(1,0x1861b48,0x1981818,0x87c);
          }
        }
        uVar42 = *(undefined8 *)(puVar35 + 3);
        *(undefined8 *)((longlong)puVar37 + -8) = 0x100b09;
        func_0x(uVar42,5);
      }
    }
LAB_:
    uVar25 = *(uint *)(puVar35 + 1);
    if ((uVar25 < 9) &&
       (((**(byte **)(puVar35 + 3) & 0xe) == 0 || ((**(byte **)(puVar35 + 3) & 0xe) == 0xc)))) {
LAB_:
      uVar25 = 9;
    }
  }
  else {
    if (uVar31 == 0) {
      *(undefined8 *)((longlong)puVar37 + -8) = 0x100b3c;
      func_0x(puVar35);
      uVar31 = *(uint *)(puVar35 + 1);
    }
    if (uVar31 < 9) {
      if ((**(byte **)(puVar35 + 3) & 0x1c) == 0) goto LAB_;
      uVar25 = 9;
      if ((**(byte **)(puVar35 + 3) & 0x1c) == 0xc) goto LAB_;
    }
    uVar25 = uVar31;
  }
LAB_:
  puVar36 = puStack_590;
  uVar42 = uStack_5e0;
  sVar30 = 1 << ((byte)*(undefined2 *)((longlong)puStack_5f0 + 4) & 2);
  sVar20 = 0x20;
  if (*psVar39 != 0) {
    sVar20 = 0x18;
  }
  iVar34 = (uint)(ushort)(sVar20 + -1 + sVar30 & -sVar30) -
           (uint)(ushort)(sVar30 + -1 + (short)uVar25 & -sVar30);
  if (0 < iVar34) {
    if (plStack_588 == (longlong *)0x0) {
      uVar31 = (uint)*(ushort *)((longlong)puStack_5f0 + 0x1c);
    }
    else {
      uVar31 = (uint)*(ushort *)((longlong)puStack_5f0 + 0x26);
      if (((*(short *)((longlong)plStack_588 + 4) == *(short *)(puStack_5f0 + 7)) &&
          (*(int *)plStack_588 == *(int *)((longlong)puStack_5f0 + 0x34))) && (uStack_5d8 == 0)) {
        uVar31 = (uint)*(ushort *)((longlong)puStack_5f0 + 0x26) -
                 (uint)*(ushort *)((longlong)puStack_5f0 + 0x32);
      }
      if (uVar31 < *(ushort *)((longlong)puStack_5f0 + 0x1c)) {
        uVar31 = *(ushort *)((longlong)puStack_5f0 + 0x1c) - uVar31;
      }
      else {
        uVar31 = 0;
      }
    }
    if ((int)uVar31 < iVar34) {
      if (*(longlong **)(param_1 + 0x2d8) == (longlong *)0x0) {
        if (*(int *)(param_1 + 0x370) != 2) {
          *(undefined8 *)((longlong)puVar37 + -8) = 0x100c2a;
          func_0x(plVar4,1);
          if (*(int *)(param_1 + 0x370) != 2) {
            lVar38 = **(longlong **)(param_1 + 0x2d8);
            goto LAB_;
          }
        }
        lVar38 = 0;
      }
      else {
        lVar38 = **(longlong **)(param_1 + 0x2d8);
      }
LAB_:
      uVar2 = *(undefined2 *)(lVar38 + 0x24);
      sVar20 = *(short *)(param_1 + 0x2d0);
      uVar3 = *(undefined4 *)(lVar38 + 0x20);
      bVar18 = **ppbVar40 >> 1;
      if (*psVar39 == 0) {
        bVar18 = **ppbVar40 >> 6;
      }
      *(uint *)((longlong)puVar37 + 0x30) = bVar18 & 1;
      *(uint *)((longlong)puVar37 + 0x28) = uVar25;
      *(int *)((longlong)puVar37 + 0x20) = iVar34;
      *(undefined8 *)((longlong)puVar37 + -8) = 0x100c84;
      func_0x(0x186a890,uVar2,uVar3,(int)sVar20);
      *(undefined8 *)((longlong)puVar37 + -8) = 0x100c8c;
      func_0x(plVar4);
      puVar36 = puStack_590;
      lVar38 = lStack_5d0;
      uVar42 = uStack_5e0;
      iVar34 = iStack_5f8;
      goto LAB_;
    }
  }
  lVar38 = 2;
  *(byte *)puStack_590 = *(byte *)puStack_590 & 0xfe;
  puVar24 = puStack_590;
  puVar27 = auStack_558;
  do {
    uVar3 = puVar24[1];
    uVar8 = puVar24[2];
    uVar9 = puVar24[3];
    uVar10 = puVar24[4];
    uVar11 = puVar24[5];
    uVar12 = puVar24[6];
    uVar13 = puVar24[7];
    *puVar27 = *puVar24;
    puVar27[1] = uVar3;
    puVar27[2] = uVar8;
    puVar27[3] = uVar9;
    uVar3 = puVar24[8];
    uVar8 = puVar24[9];
    uVar9 = puVar24[10];
    uVar14 = puVar24[0xb];
    puVar27[4] = uVar10;
    puVar27[5] = uVar11;
    puVar27[6] = uVar12;
    puVar27[7] = uVar13;
    uVar10 = puVar24[0xc];
    uVar11 = puVar24[0xd];
    uVar12 = puVar24[0xe];
    uVar13 = puVar24[0xf];
    puVar27[8] = uVar3;
    puVar27[9] = uVar8;
    puVar27[10] = uVar9;
    puVar27[0xb] = uVar14;
    uVar3 = puVar24[0x10];
    uVar8 = puVar24[0x11];
    uVar9 = puVar24[0x12];
    uVar14 = puVar24[0x13];
    puVar27[0xc] = uVar10;
    puVar27[0xd] = uVar11;
    puVar27[0xe] = uVar12;
    puVar27[0xf] = uVar13;
    uVar11 = puVar24[0x14];
    uVar12 = puVar24[0x15];
    uVar13 = puVar24[0x16];
    uVar15 = puVar24[0x17];
    puVar27[0x10] = uVar3;
    puVar27[0x11] = uVar8;
    puVar27[0x12] = uVar9;
    puVar27[0x13] = uVar14;
    uVar3 = puVar24[0x18];
    uVar8 = puVar24[0x19];
    uVar9 = puVar24[0x1a];
    uVar10 = puVar24[0x1b];
    puVar27[0x14] = uVar11;
    puVar27[0x15] = uVar12;
    puVar27[0x16] = uVar13;
    puVar27[0x17] = uVar15;
    uVar11 = puVar24[0x1c];
    uVar12 = puVar24[0x1d];
    uVar13 = puVar24[0x1e];
    uVar14 = puVar24[0x1f];
    puVar27[0x18] = uVar3;
    puVar27[0x19] = uVar8;
    puVar27[0x1a] = uVar9;
    puVar27[0x1b] = uVar10;
    puVar27[0x1c] = uVar11;
    puVar27[0x1d] = uVar12;
    puVar27[0x1e] = uVar13;
    puVar27[0x1f] = uVar14;
    lVar38 = lVar38 + -1;
    puVar24 = puVar24 + 0x20;
    puVar27 = puVar27 + 0x20;
  } while (lVar38 != 0);
  *(undefined8 *)((longlong)puVar37 + 0x20) = uStack_5e0;
  *(undefined8 *)((longlong)puVar37 + -8) = 0x100dfd;
  func_0x(plVar4,0,auStack_558,0);
  if ((*(longlong *)(param_1 + 0x2c0) != CONCAT44(uRam0000000001f820dc,_DAT_)) ||
     (lVar38 = lStack_5d0, iVar34 = iStack_5f8,
     *(longlong *)(param_1 + 0x2c8) != CONCAT44(uRam0000000001f820e4,_DAT_))) {
    if ((*(byte *)(param_1 + 800) & 2) != 0) {
      *(undefined8 *)((longlong)puVar37 + -8) = 0x100e2a;
      iVar34 = func_0x(param_1 + 0x328);
      if (iVar34 != 0) {
        *(longlong *)(*plVar4 + 0x30) = *(longlong *)(*plVar4 + 0x30) + -1;
      }
    }
    *(undefined *)(param_1 + 800) = 0;
    *(undefined4 *)(param_1 + 0x31c) = 0;
    *(undefined4 *)(param_1 + 0x338) = 0;
    if ((*(byte *)(param_1 + 0x350) & 2) != 0) {
      *(undefined8 *)((longlong)puVar37 + -8) = 0x100e59;
      iVar34 = func_0x(param_1 + 0x358);
      if (iVar34 != 0) {
        *(longlong *)(*plVar4 + 0x30) = *(longlong *)(*plVar4 + 0x30) + -1;
      }
    }
    *(undefined *)(param_1 + 0x350) = 0;
    *(undefined4 *)(param_1 + 0x34c) = 0;
    *(undefined4 *)(param_1 + 0x368) = 0;
    if (*(longlong *)(param_1 + 0x2d8) != 0) {
      *(undefined *)(param_1 + 0x2e6) = 0;
      *(undefined8 *)(param_1 + 0x2d8) = 0;
      *(undefined2 *)(param_1 + 0x2e4) = 0;
      *(undefined4 *)(*(longlong *)(param_1 + 0x2c0) + 0x48) = 0;
    }
    uVar7 = *(undefined8 *)*plVar4;
    *(undefined8 *)((longlong)puVar37 + -8) = 0x100e9f;
    func_0x(uVar7,param_1 + 0x2c0);
    uVar10 = uRam0000000001f820e4;
    uVar9 = _DAT_;
    uVar8 = uRam0000000001f820dc;
    uVar3 = _DAT_;
    *(undefined4 *)(param_1 + 0x520) = 0xffffffff;
    *(undefined4 *)(param_1 + 0x2d0) = 0xffffffff;
    *(undefined4 *)(param_1 + 0x2c0) = uVar3;
    *(undefined4 *)(param_1 + 0x2c4) = uVar8;
    *(undefined4 *)(param_1 + 0x2c8) = uVar9;
    *(undefined4 *)(param_1 + 0x2cc) = uVar10;
    *(undefined4 *)(param_1 + 0x4f0) = 0;
    *(undefined8 *)(param_1 + 0x508) = 0;
    *(undefined8 *)(param_1 + 0x500) = 0;
    *(undefined8 *)(param_1 + 0x510) = 0;
    *(undefined2 *)(param_1 + 0x524) = 0xffff;
    *(undefined8 *)(param_1 + 0x526) = 0;
    *(undefined4 *)(param_1 + 0x370) = 2;
    lVar38 = lStack_5d0;
    iVar34 = iStack_5f8;
  }
LAB_:
  cVar16 = cStack_607;
  *(byte *)puVar36 = *(byte *)puVar36 | 1;
  puVar36 = (undefined4 *)(lVar38 + 0x530);
  lVar33 = 2;
  if (cStack_607 == '\0') {
    puVar24 = puVar36;
    puVar27 = auStack_358;
    do {
      uVar3 = puVar24[1];
      uVar8 = puVar24[2];
      uVar9 = puVar24[3];
      uVar10 = puVar24[4];
      uVar11 = puVar24[5];
      uVar12 = puVar24[6];
      uVar13 = puVar24[7];
      *puVar27 = *puVar24;
      puVar27[1] = uVar3;
      puVar27[2] = uVar8;
      puVar27[3] = uVar9;
      uVar3 = puVar24[8];
      uVar8 = puVar24[9];
      uVar9 = puVar24[10];
      uVar14 = puVar24[0xb];
      puVar27[4] = uVar10;
      puVar27[5] = uVar11;
      puVar27[6] = uVar12;
      puVar27[7] = uVar13;
      uVar10 = puVar24[0xc];
      uVar11 = puVar24[0xd];
      uVar12 = puVar24[0xe];
      uVar13 = puVar24[0xf];
      puVar27[8] = uVar3;
      puVar27[9] = uVar8;
      puVar27[10] = uVar9;
      puVar27[0xb] = uVar14;
      uVar3 = puVar24[0x10];
      uVar8 = puVar24[0x11];
      uVar9 = puVar24[0x12];
      uVar14 = puVar24[0x13];
      puVar27[0xc] = uVar10;
      puVar27[0xd] = uVar11;
      puVar27[0xe] = uVar12;
      puVar27[0xf] = uVar13;
      uVar11 = puVar24[0x14];
      uVar12 = puVar24[0x15];
      uVar13 = puVar24[0x16];
      uVar15 = puVar24[0x17];
      puVar27[0x10] = uVar3;
      puVar27[0x11] = uVar8;
      puVar27[0x12] = uVar9;
      puVar27[0x13] = uVar14;
      uVar3 = puVar24[0x18];
      uVar8 = puVar24[0x19];
      uVar9 = puVar24[0x1a];
      uVar10 = puVar24[0x1b];
      puVar27[0x14] = uVar11;
      puVar27[0x15] = uVar12;
      puVar27[0x16] = uVar13;
      puVar27[0x17] = uVar15;
      uVar11 = puVar24[0x1c];
      uVar12 = puVar24[0x1d];
      uVar13 = puVar24[0x1e];
      uVar14 = puVar24[0x1f];
      puVar27[0x18] = uVar3;
      puVar27[0x19] = uVar8;
      puVar27[0x1a] = uVar9;
      puVar27[0x1b] = uVar10;
      puVar27[0x1c] = uVar11;
      puVar27[0x1d] = uVar12;
      puVar27[0x1e] = uVar13;
      puVar27[0x1f] = uVar14;
      lVar33 = lVar33 + -1;
      puVar24 = puVar24 + 0x20;
      puVar27 = puVar27 + 0x20;
    } while (lVar33 != 0);
    *(undefined8 *)((longlong)puVar37 + 0x20) = uVar42;
    *(undefined8 *)((longlong)puVar37 + -8) = 0x100f81;
    func_0x(lVar28,&puStack_580,auStack_358,0);
  }
  else {
    puVar24 = puVar36;
    puVar27 = auStack_458;
    do {
      uVar3 = puVar24[1];
      uVar8 = puVar24[2];
      uVar9 = puVar24[3];
      uVar10 = puVar24[4];
      uVar11 = puVar24[5];
      uVar12 = puVar24[6];
      uVar13 = puVar24[7];
      *puVar27 = *puVar24;
      puVar27[1] = uVar3;
      puVar27[2] = uVar8;
      puVar27[3] = uVar9;
      uVar3 = puVar24[8];
      uVar8 = puVar24[9];
      uVar9 = puVar24[10];
      uVar14 = puVar24[0xb];
      puVar27[4] = uVar10;
      puVar27[5] = uVar11;
      puVar27[6] = uVar12;
      puVar27[7] = uVar13;
      uVar10 = puVar24[0xc];
      uVar11 = puVar24[0xd];
      uVar12 = puVar24[0xe];
      uVar13 = puVar24[0xf];
      puVar27[8] = uVar3;
      puVar27[9] = uVar8;
      puVar27[10] = uVar9;
      puVar27[0xb] = uVar14;
      uVar3 = puVar24[0x10];
      uVar8 = puVar24[0x11];
      uVar9 = puVar24[0x12];
      uVar14 = puVar24[0x13];
      puVar27[0xc] = uVar10;
      puVar27[0xd] = uVar11;
      puVar27[0xe] = uVar12;
      puVar27[0xf] = uVar13;
      uVar11 = puVar24[0x14];
      uVar12 = puVar24[0x15];
      uVar13 = puVar24[0x16];
      uVar15 = puVar24[0x17];
      puVar27[0x10] = uVar3;
      puVar27[0x11] = uVar8;
      puVar27[0x12] = uVar9;
      puVar27[0x13] = uVar14;
      uVar3 = puVar24[0x18];
      uVar8 = puVar24[0x19];
      uVar9 = puVar24[0x1a];
      uVar10 = puVar24[0x1b];
      puVar27[0x14] = uVar11;
      puVar27[0x15] = uVar12;
      puVar27[0x16] = uVar13;
      puVar27[0x17] = uVar15;
      uVar11 = puVar24[0x1c];
      uVar12 = puVar24[0x1d];
      uVar13 = puVar24[0x1e];
      uVar14 = puVar24[0x1f];
      puVar27[0x18] = uVar3;
      puVar27[0x19] = uVar8;
      puVar27[0x1a] = uVar9;
      puVar27[0x1b] = uVar10;
      puVar27[0x1c] = uVar11;
      puVar27[0x1d] = uVar12;
      puVar27[0x1e] = uVar13;
      puVar27[0x1f] = uVar14;
      lVar33 = lVar33 + -1;
      puVar24 = puVar24 + 0x20;
      puVar27 = puVar27 + 0x20;
    } while (lVar33 != 0);
    *(undefined8 *)((longlong)puVar37 + -8) = 0x100d3c;
    iVar21 = func_0x(lVar28,&puStack_580,auStack_458,0);
    if (iVar21 != 0) {
      *(undefined8 *)((longlong)puVar37 + 0x20) = 0;
      *(undefined8 *)((longlong)puVar37 + -8) = 0x100d6a;
      (*_DAT_)(1,0x1a10448,0x19e5ea8,0xf02);
    }
  }
  *(undefined8 *)((longlong)puVar37 + -8) = 0x100f8c;
  func_0x(lVar28);
  if ((iVar34 == 3) && (cStack_608 == '\0')) {
    lVar28 = 2;
    if (cVar16 == '\0') {
      puVar24 = auStack_158;
      do {
        uVar3 = puVar36[1];
        uVar8 = puVar36[2];
        uVar9 = puVar36[3];
        uVar10 = puVar36[4];
        uVar11 = puVar36[5];
        uVar12 = puVar36[6];
        uVar13 = puVar36[7];
        *puVar24 = *puVar36;
        puVar24[1] = uVar3;
        puVar24[2] = uVar8;
        puVar24[3] = uVar9;
        uVar3 = puVar36[8];
        uVar8 = puVar36[9];
        uVar9 = puVar36[10];
        uVar14 = puVar36[0xb];
        puVar24[4] = uVar10;
        puVar24[5] = uVar11;
        puVar24[6] = uVar12;
        puVar24[7] = uVar13;
        uVar10 = puVar36[0xc];
        uVar11 = puVar36[0xd];
        uVar12 = puVar36[0xe];
        uVar13 = puVar36[0xf];
        puVar24[8] = uVar3;
        puVar24[9] = uVar8;
        puVar24[10] = uVar9;
        puVar24[0xb] = uVar14;
        uVar3 = puVar36[0x10];
        uVar8 = puVar36[0x11];
        uVar9 = puVar36[0x12];
        uVar14 = puVar36[0x13];
        puVar24[0xc] = uVar10;
        puVar24[0xd] = uVar11;
        puVar24[0xe] = uVar12;
        puVar24[0xf] = uVar13;
        uVar11 = puVar36[0x14];
        uVar12 = puVar36[0x15];
        uVar13 = puVar36[0x16];
        uVar15 = puVar36[0x17];
        puVar24[0x10] = uVar3;
        puVar24[0x11] = uVar8;
        puVar24[0x12] = uVar9;
        puVar24[0x13] = uVar14;
        uVar3 = puVar36[0x18];
        uVar8 = puVar36[0x19];
        uVar9 = puVar36[0x1a];
        uVar10 = puVar36[0x1b];
        puVar24[0x14] = uVar11;
        puVar24[0x15] = uVar12;
        puVar24[0x16] = uVar13;
        puVar24[0x17] = uVar15;
        uVar11 = puVar36[0x1c];
        uVar12 = puVar36[0x1d];
        uVar13 = puVar36[0x1e];
        uVar14 = puVar36[0x1f];
        puVar24[0x18] = uVar3;
        puVar24[0x19] = uVar8;
        puVar24[0x1a] = uVar9;
        puVar24[0x1b] = uVar10;
        puVar24[0x1c] = uVar11;
        puVar24[0x1d] = uVar12;
        puVar24[0x1e] = uVar13;
        puVar24[0x1f] = uVar14;
        lVar28 = lVar28 + -1;
        puVar24 = puVar24 + 0x20;
        puVar36 = puVar36 + 0x20;
      } while (lVar28 != 0);
      *(undefined8 *)((longlong)puVar37 + 0x20) = 0;
      *(undefined8 *)((longlong)puVar37 + -8) = 0x1010c2;
      func_0x(lVar38 + 0x2b0,0,auStack_158,0);
    }
    else {
      puVar24 = auStack_258;
      do {
        uVar3 = puVar36[1];
        uVar8 = puVar36[2];
        uVar9 = puVar36[3];
        uVar10 = puVar36[4];
        uVar11 = puVar36[5];
        uVar12 = puVar36[6];
        uVar13 = puVar36[7];
        *puVar24 = *puVar36;
        puVar24[1] = uVar3;
        puVar24[2] = uVar8;
        puVar24[3] = uVar9;
        uVar3 = puVar36[8];
        uVar8 = puVar36[9];
        uVar9 = puVar36[10];
        uVar14 = puVar36[0xb];
        puVar24[4] = uVar10;
        puVar24[5] = uVar11;
        puVar24[6] = uVar12;
        puVar24[7] = uVar13;
        uVar10 = puVar36[0xc];
        uVar11 = puVar36[0xd];
        uVar12 = puVar36[0xe];
        uVar13 = puVar36[0xf];
        puVar24[8] = uVar3;
        puVar24[9] = uVar8;
        puVar24[10] = uVar9;
        puVar24[0xb] = uVar14;
        uVar3 = puVar36[0x10];
        uVar8 = puVar36[0x11];
        uVar9 = puVar36[0x12];
        uVar14 = puVar36[0x13];
        puVar24[0xc] = uVar10;
        puVar24[0xd] = uVar11;
        puVar24[0xe] = uVar12;
        puVar24[0xf] = uVar13;
        uVar11 = puVar36[0x14];
        uVar12 = puVar36[0x15];
        uVar13 = puVar36[0x16];
        uVar15 = puVar36[0x17];
        puVar24[0x10] = uVar3;
        puVar24[0x11] = uVar8;
        puVar24[0x12] = uVar9;
        puVar24[0x13] = uVar14;
        uVar3 = puVar36[0x18];
        uVar8 = puVar36[0x19];
        uVar9 = puVar36[0x1a];
        uVar10 = puVar36[0x1b];
        puVar24[0x14] = uVar11;
        puVar24[0x15] = uVar12;
        puVar24[0x16] = uVar13;
        puVar24[0x17] = uVar15;
        uVar11 = puVar36[0x1c];
        uVar12 = puVar36[0x1d];
        uVar13 = puVar36[0x1e];
        uVar14 = puVar36[0x1f];
        puVar24[0x18] = uVar3;
        puVar24[0x19] = uVar8;
        puVar24[0x1a] = uVar9;
        puVar24[0x1b] = uVar10;
        puVar24[0x1c] = uVar11;
        puVar24[0x1d] = uVar12;
        puVar24[0x1e] = uVar13;
        puVar24[0x1f] = uVar14;
        lVar28 = lVar28 + -1;
        puVar24 = puVar24 + 0x20;
        puVar36 = puVar36 + 0x20;
      } while (lVar28 != 0);
      *(undefined8 *)((longlong)puVar37 + -8) = 0x10101d;
      iVar34 = func_0x(lVar38 + 0x2b0,0,auStack_258,0);
      if (iVar34 != 0) {
        *(undefined8 *)((longlong)puVar37 + 0x20) = 0;
        *(undefined8 *)((longlong)puVar37 + -8) = 0x101049;
        (*_DAT_)(1,0x1a10448,0x19e5ea8,0xf17);
      }
    }
    *(undefined8 *)((longlong)puVar37 + -8) = 0x1010d3;
    func_0x(lVar38 + 0x2b0,0,0);
    if ((*(longlong *)(param_1 + 0x2c0) != CONCAT44(uRam0000000001f820dc,_DAT_)) ||
       (*(longlong *)(param_1 + 0x2c8) != CONCAT44(uRam0000000001f820e4,_DAT_))) {
      if ((*(byte *)(param_1 + 800) & 2) != 0) {
        *(undefined8 *)((longlong)puVar37 + -8) = 0x101100;
        iVar34 = func_0x(param_1 + 0x328);
        if (iVar34 != 0) {
          *(longlong *)(*plVar4 + 0x30) = *(longlong *)(*plVar4 + 0x30) + -1;
        }
      }
      *(undefined *)(param_1 + 800) = 0;
      *(undefined4 *)(param_1 + 0x31c) = 0;
      *(undefined4 *)(param_1 + 0x338) = 0;
      if ((*(byte *)(param_1 + 0x350) & 2) != 0) {
        *(undefined8 *)((longlong)puVar37 + -8) = 0x10112f;
        iVar34 = func_0x(param_1 + 0x358);
        if (iVar34 != 0) {
          *(longlong *)(*plVar4 + 0x30) = *(longlong *)(*plVar4 + 0x30) + -1;
        }
      }
      *(undefined *)(param_1 + 0x350) = 0;
      *(undefined4 *)(param_1 + 0x34c) = 0;
      *(undefined4 *)(param_1 + 0x368) = 0;
      if (*(longlong *)(param_1 + 0x2d8) != 0) {
        *(undefined *)(param_1 + 0x2e6) = 0;
        *(undefined8 *)(param_1 + 0x2d8) = 0;
        *(undefined2 *)(param_1 + 0x2e4) = 0;
        *(undefined4 *)(*(longlong *)(param_1 + 0x2c0) + 0x48) = 0;
      }
      uVar42 = *(undefined8 *)*plVar4;
      *(undefined8 *)((longlong)puVar37 + -8) = 0x10117a;
      func_0x(uVar42,param_1 + 0x2c0);
      uVar10 = uRam0000000001f820e4;
      uVar9 = _DAT_;
      uVar8 = uRam0000000001f820dc;
      uVar3 = _DAT_;
      *(undefined4 *)(param_1 + 0x520) = 0xffffffff;
      *(undefined4 *)(param_1 + 0x2d0) = 0xffffffff;
      *(undefined4 *)(param_1 + 0x2c0) = uVar3;
      *(undefined4 *)(param_1 + 0x2c4) = uVar8;
      *(undefined4 *)(param_1 + 0x2c8) = uVar9;
      *(undefined4 *)(param_1 + 0x2cc) = uVar10;
      *(undefined4 *)(param_1 + 0x4f0) = 0;
      *(undefined8 *)(param_1 + 0x508) = 0;
      *(undefined8 *)(param_1 + 0x500) = 0;
      *(undefined8 *)(param_1 + 0x510) = 0;
      *(undefined2 *)(param_1 + 0x524) = 0xffff;
      *(undefined8 *)(param_1 + 0x526) = 0;
      *(undefined4 *)(param_1 + 0x370) = 2;
    }
  }
  puStack_5f0 = (undefined8 *)0x0;
  *(undefined8 *)((longlong)puVar37 + -8) = 0x1011ed;
  iVar34 = func_0x(lVar38,uStack_5f4,0,&puStack_5f0);
  if (iVar34 != 4) {
    *(undefined8 *)((longlong)puVar37 + 0x20) = 0;
    *(undefined8 *)((longlong)puVar37 + -8) = 0x101216;
    (*_DAT_)(1,0x1a107b8,0x19e5ea8,0xf30);
  }
  *(undefined8 *)((longlong)puVar37 + -8) = 0x101225;
  func_0x(uStack_48 ^ (ulonglong)&cStack_608);
  return;
}

