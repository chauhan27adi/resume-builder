
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x010f8888) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong *param_3,longlong **param_4)

{
  longlong *plVar1;
  undefined2 *puVar2;
  undefined2 uVar3;
  byte *pbVar4;
  code *pcVar5;
  byte bVar6;
  char cVar7;
  short sVar8;
  ushort uVar9;
  int iVar10;
  uint uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  longlong lVar14;
  longlong lVar15;
  short *psVar16;
  undefined2 *puVar17;
  undefined8 uVar18;
  longlong **pplVar19;
  undefined8 uVar20;
  longlong lVar21;
  uint uVar22;
  int *piVar23;
  ulonglong uVar24;
  longlong lVar25;
  undefined2 uStackX_10;
  undefined2 uStackX_12;
  uint uStackX_14;
  byte *pbStackX_18;
  undefined8 uStackX_20;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  puVar2 = (undefined2 *)((longlong)&uStackX_10 + lVar14);
  *(undefined8 *)(&stack0x00000300 + lVar14) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00006950 + lVar14) = _DAT_ ^ (ulonglong)puVar2;
  *(longlong ***)(&stack0x00000298 + lVar14) = param_4;
  *(longlong **)(&stack0x00000050 + lVar14) = param_3;
  *(longlong **)(&stack0x00000288 + lVar14) = param_2;
  *(longlong *)(&stack0x00000088 + lVar14) = param_1;
  *(undefined8 *)(&stack0x000002f0 + lVar14) = 0;
  *(undefined (*) [16])(&stack0x000002e0 + lVar14) = ZEXT816(0);
  *(undefined8 **)(&stack0x00000290 + lVar14) = (undefined8 *)(param_1 + 0x10);
  uVar18 = *(undefined8 *)(param_1 + 0x10);
  *(undefined8 *)(&stack0x00000068 + lVar14) = uVar18;
  *(undefined8 *)(&stack0x00000168 + lVar14) = 0;
  *(undefined4 *)(&stack0x000000bc + lVar14) = 0;
  *(longlong *)(&stack0x000000d8 + lVar14) = *param_3;
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1000a6;
  func_0x(&stack0x00000400 + lVar14);
  *(undefined4 *)(&stack0x000000b8 + lVar14) = 0;
  lVar25 = *(longlong *)(param_1 + 0x18);
  *(longlong *)(&stack0x00000090 + lVar14) = lVar25;
  lVar25 = *(longlong *)(lVar25 + 0x30);
  uVar24 = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1000d0;
  func_0x(&stack0x000002a0 + lVar14,param_1);
  *puVar2 = 0xffff;
  *(undefined8 *)((longlong)&pbStackX_18 + lVar14) = 0;
  *(undefined4 *)((longlong)&uStackX_10 + lVar14 + 4) = 0;
  *(undefined8 *)(&stack0x0000002e + lVar14) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar14) = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar14) = 0;
  if (param_4 != (longlong **)0x0) {
    *param_4 = param_2;
  }
  lVar15 = *(longlong *)(param_1 + 0x108);
  if ((*(byte *)(*(longlong *)(**(longlong **)(lVar15 + 0x20) + 8) + 0x107) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10012f;
  iVar10 = func_0x(param_2,lVar15 + 0x90,uVar24 & 0xffffffffffffff00,
                           &stack0x000002d8 + lVar14);
  if (iVar10 == 0x40f02) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100142;
  lVar15 = func_0x(uVar18);
  if ((*(byte *)(lVar15 + 0x3c) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar15 = *(longlong *)(&stack0x000000d8 + lVar14);
  if ((*(byte *)(lVar15 + 0x5c) & 8) != 0) {
    if ((*(byte *)(*(longlong *)(**(longlong **)(*(longlong *)(param_1 + 0x108) + 0x20) + 8) + 0x107
                  ) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar22 = *(uint *)(param_2 + 2);
    uVar11 = uVar22 & 0xfffffeff;
    *(uint *)(param_2 + 2) = uVar11;
    if (((char)uVar11 < '\0') || ((*(byte *)((longlong)param_2 + 0x34) & 1) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((uVar22 >> 0xd & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar1 = param_2 + 9;
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1001be;
    iVar10 = func_0x(plVar1);
    if (iVar10 != 0) {
      if (*(short *)plVar1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(int *)(param_2 + 0xb) == *(int *)(*(longlong *)(&stack0x000000d8 + lVar14) + 0x14)) {
        if (*(short *)plVar1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((*(byte *)param_2[10] & 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (((*(short *)((byte *)param_2[10] + *(uint *)(param_2 + 0xb)) ==
              *(short *)(*(longlong *)(*(longlong *)(&stack0x00000068 + lVar14) + 8) + 0xcc)) &&
            (*(int *)(param_2 + 0x2b) != 3)) && (*(char *)(lVar25 + 0x6b4e) == '\0')) {
          if (*(int *)((longlong)param_2 + 0x4c) == 0) {
            *(undefined2 *)((longlong)param_2 + 0x4a) = 0;
            uVar22 = *(uint *)(param_2 + 0xb);
            *(uint *)((longlong)param_2 + 0x5c) = uVar22;
            pbVar4 = (byte *)param_2[10];
            bVar6 = *pbVar4;
            if ((bVar6 & 0x10) != 0) {
              uVar22 = uVar22 + (*(ushort *)(pbVar4 + uVar22) + 7 >> 3) + 2;
              *(uint *)((longlong)param_2 + 0x5c) = uVar22;
              bVar6 = *pbVar4;
            }
            if ((bVar6 & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(uint *)((longlong)param_2 + 0x4c) = uVar22;
            *(undefined2 *)((longlong)param_2 + 100) = 0;
            *(uint *)(param_2 + 0xc) = uVar22;
            if ((*pbVar4 & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(undefined4 *)((longlong)param_2 + 0x6e) = 0;
            if ((*(ulonglong *)((longlong)param_2 + 0x66) != 0) &&
               (*(ulonglong *)((longlong)param_2 + 0x66) < (ulonglong)uVar22 + param_2[10])) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            if (0x3f3b < uVar22 - 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
          }
          if (*(uint *)((longlong)param_2 + 0x4c) < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (0x80 < *(uint *)((longlong)param_2 + 0x4c)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
      }
    }
    pcVar5 = *(code **)(*param_2 + 8);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10030d;
    (*pcVar5)(param_2);
    lVar15 = *(longlong *)(&stack0x000000d8 + lVar14);
  }
  if ((*(byte *)(lVar15 + 0x38) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_2 != (longlong *)0x0) && (*(int *)(param_2 + 1) == 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(*param_3 + 0x38) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_2 != (longlong *)0x0) && (*(int *)(param_2 + 1) == 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10036d;
  func_0x(&stack0x00000270 + lVar14,0);
  pcVar5 = *(code **)*param_2;
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100377;
  psVar16 = (short *)(*pcVar5)(param_2);
  pcVar5 = *(code **)*param_2;
  if (*psVar16 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10038f;
  puVar17 = (undefined2 *)(*pcVar5)(param_2);
  *puVar17 = 0;
  *puVar2 = 0;
  lVar25 = *param_3;
  if ((*(byte *)(lVar25 + 0x38) & 0x20) != 0) {
LAB_:
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005a9;
    func_0x(&stack0x00000270 + lVar14);
    lVar25 = *(longlong *)(&stack0x00000068 + lVar14);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005b8;
    iVar10 = func_0x(lVar25);
    if (iVar10 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005c8;
      uVar18 = func_0x(param_3);
      if (lVar25 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005dc;
        lVar15 = func_0x(uVar18);
        uVar22 = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005ec;
        sVar8 = func_0x(uVar18);
        if (sVar8 != 0) {
          do {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100600;
            iVar10 = func_0x(lVar15);
            if (iVar10 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100613;
              pplVar19 = (longlong **)func_0x(lVar15,&stack0x00000398 + lVar14);
              uVar20 = *(undefined8 *)(lVar25 + 8);
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10061f;
              cVar7 = func_0x(uVar20);
              if (cVar7 != '\0') {
                if (*(int *)(*(longlong *)(lVar25 + 8) + 0x480) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                  halt_baddata();
                }
                if ((*pplVar19)[1] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                  halt_baddata();
                }
                plVar1 = (longlong *)(**pplVar19 + (longlong)pplVar19[1] * 8);
                LOCK();
                *plVar1 = *plVar1 + 1;
                UNLOCK();
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100666;
                uVar20 = func_0x(*(undefined8 *)(&stack0x00000090 + lVar14));
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10066e;
                cVar7 = func_0x(uVar20);
                lVar25 = *(longlong *)(&stack0x00000068 + lVar14);
                if (cVar7 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
                  halt_baddata();
                }
              }
            }
            uVar22 = uVar22 + 1;
            lVar15 = lVar15 + 0x50;
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100689;
            uVar9 = func_0x(uVar18);
          } while (uVar22 < uVar9);
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10069e;
    iVar10 = func_0x(puVar2);
    if (iVar10 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar18 = *(undefined8 *)(&stack0x00000288 + lVar14);
    lVar25 = *(longlong *)(&stack0x00000088 + lVar14);
    lVar15 = *(longlong *)(&stack0x00000068 + lVar14);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006d0;
    iVar10 = func_0x(*(undefined8 *)(&stack0x000000d8 + lVar14));
    if (iVar10 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006e4;
    func_0x(&stack0x000004a8 + lVar14);
    uVar20 = *(undefined8 *)(*(longlong *)(lVar25 + 0x108) + 0x20);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006f4;
    uVar20 = func_0x(uVar20);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006fc;
    lVar21 = func_0x(uVar20);
    if ((*(byte *)(lVar21 + 0x67) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(longlong *)(lVar25 + 0x380) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar20 = *(undefined8 *)(lVar25 + 0x108);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100722;
    uVar12 = func_0x(uVar20);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10072c;
    uVar13 = func_0x(lVar25);
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar14) = uVar12;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) = 0;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
    *(undefined **)(&stack0xffffffffffffffe0 + lVar14) = &stack0x000002d8 + lVar14;
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10075a;
    func_0x(uVar18,puVar2,uVar13,0);
    if (*(longlong *)(lVar25 + 0x380) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(longlong *)(*(longlong *)(lVar15 + 8) + 0x488) != 0) && (*_DAT_ != '\0')) {
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10078b;
      uVar18 = func_0x();
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100798;
      iVar10 = func_0x(uVar18,0x281);
      if (iVar10 == 0) {
        lVar25 = *(longlong *)(*(longlong *)(lVar15 + 8) + 0x488);
        if (*(longlong *)(lVar25 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        LOCK();
        plVar1 = (longlong *)(*(longlong *)(lVar25 + 0x18) + 0x10);
        *plVar1 = *plVar1 + 1;
        UNLOCK();
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1007c8;
    func_0x(&stack0x000002a0 + lVar14);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1007d7;
    func_0x(*(ulonglong *)(&stack0x00006950 + lVar14) ^ (ulonglong)puVar2);
    return;
  }
  if ((**(byte **)(puVar17 + 4) & 0xe) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((*(byte *)(lVar25 + 0x5c) & 2) == 0) && (*(uint *)(puVar17 + 8) == *(uint *)(lVar25 + 0x14)))
  {
    if ((**(byte **)(puVar17 + 4) & 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(short *)(*(byte **)(puVar17 + 4) + *(uint *)(puVar17 + 8)) ==
        *(short *)(*(longlong *)(*(longlong *)(&stack0x00000068 + lVar14) + 8) + 0xcc)) {
      if (*(int *)(puVar17 + 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar22 = *(uint *)(puVar17 + 2);
      if (uVar22 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined4 *)((longlong)&uStackX_20 + lVar14) = *(undefined4 *)(puVar17 + 8);
      *(undefined2 *)((longlong)&uStackX_10 + lVar14 + 2) = puVar17[1];
      *(undefined4 *)((longlong)&uStackX_10 + lVar14 + 4) = *(undefined4 *)(puVar17 + 2);
      *(undefined2 *)(&stack0x0000002c + lVar14) = puVar17[0xe];
      *(undefined4 *)((longlong)&uStackX_20 + lVar14 + 4) = *(undefined4 *)(puVar17 + 10);
      *(undefined4 *)(&stack0x00000028 + lVar14) = *(undefined4 *)(puVar17 + 0xc);
      *(undefined4 *)(&stack0x00000036 + lVar14) = *(undefined4 *)(puVar17 + 0x13);
      uVar18 = *(undefined8 *)(puVar17 + 4);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10046b;
      func_0x(&stack0x00002a10 + lVar14,0x3f3c,uVar18,uVar22);
      *(undefined **)((longlong)&pbStackX_18 + lVar14) = &stack0x00002a10 + lVar14;
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10047f;
      iVar10 = func_0x((longlong)&uStackX_10 + lVar14 + 2);
      if (iVar10 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((**(byte **)((longlong)&pbStackX_18 + lVar14) & 0xe) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)(lVar25 + 0x5c) & 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar9 = *(ushort *)(*param_3 + 0x62);
      piVar23 = *(int **)(*param_3 + 0x70);
      if (uVar9 != 0) {
        uVar24 = (ulonglong)uVar9;
        uVar18 = *(undefined8 *)(&stack0x00000050 + lVar14);
        do {
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1004db;
          cVar7 = func_0x(uVar18,piVar23);
          if (cVar7 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1004ef;
          func_0x((longlong)&uStackX_10 + lVar14 + 2,piVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100501;
          func_0x(uVar18,piVar23,&stack0x000001b8 + lVar14);
          if (((uint)piVar23[0x10] >> 8 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          iVar10 = *piVar23;
          uVar3 = *(undefined2 *)(piVar23 + 0xf);
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100529;
          func_0x((longlong)iVar10 + *(longlong *)((longlong)&pbStackX_18 + lVar14),
                          *(undefined8 *)(&stack0x000001b8 + lVar14),uVar3);
          piVar23 = piVar23 + 0x14;
          uVar24 = uVar24 - 1;
        } while (uVar24 != 0);
      }
      if (*(int *)((longlong)&uStackX_10 + lVar14 + 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(uint *)((longlong)&uStackX_10 + lVar14 + 4) < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (0x3f3c < *(uint *)((longlong)&uStackX_10 + lVar14 + 4)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(int *)((longlong)&uStackX_10 + lVar14 + 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(uint *)((longlong)&uStackX_10 + lVar14 + 4) < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar22 = *(uint *)((longlong)&uStackX_10 + lVar14 + 4);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100585;
      iVar10 = func_0x((longlong)&uStackX_10 + lVar14 + 2);
      uVar11 = *(uint *)(&stack0x00000036 + lVar14);
      if (iVar10 == 0) {
        uVar11 = uVar22;
      }
      if (0x1f7c < uVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      param_3 = *(longlong **)(&stack0x00000050 + lVar14);
      goto LAB_;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

