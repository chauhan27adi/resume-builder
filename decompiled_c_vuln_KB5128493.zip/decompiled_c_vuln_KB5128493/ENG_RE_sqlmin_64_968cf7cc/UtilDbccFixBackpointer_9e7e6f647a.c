
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,int param_3,longlong param_4,undefined2 param_5)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  undefined2 uVar4;
  undefined8 uVar5;
  code *pcVar6;
  longlong *plVar7;
  uint **ppuVar8;
  char cVar9;
  undefined4 uVar10;
  int iVar11;
  int iVar12;
  uint uVar13;
  uint uVar14;
  longlong lVar15;
  longlong *plVar16;
  longlong lVar17;
  uint *puVar18;
  longlong lVar19;
  short *psVar20;
  ulonglong *puVar21;
  ushort uVar22;
  ushort uVar23;
  undefined8 unaff_RBX;
  byte **ppbVar24;
  ulonglong uVar25;
  ushort *puVar26;
  uint uVar27;
  ulonglong uVar28;
  uint uVar29;
  longlong lVar30;
  longlong lVar31;
  ulonglong uVar32;
  uint uVar33;
  short sVar34;
  longlong unaff_GS_OFFSET;
  longlong *plStackX_8;
  undefined8 uStackX_10;
  undefined8 uStackX_18;
  undefined4 auStackX_20 [2];
  uint uStack_49a4;
  int iStack_4998;
  short sStack_4994;
  undefined8 uStack_4990;
  undefined4 uStack_4988;
  undefined4 uStack_4984;
  undefined2 uStack_4980;
  short sStack_4978;
  ushort uStack_4976;
  uint uStack_4974;
  byte *pbStack_4970;
  byte **ppbStack_4968;
  uint uStack_4960;
  ushort uStack_495c;
  undefined8 uStack_495a;
  undefined2 uStack_4952;
  undefined2 uStack_4950;
  undefined2 uStack_494e;
  ushort uStack_494c;
  undefined2 uStack_494a;
  uint uStack_4940;
  int iStack_493c;
  undefined8 uStack_4938;
  ushort uStack_4930;
  undefined4 uStack_4928;
  undefined2 uStack_4924;
  undefined2 uStack_4922;
  undefined8 uStack_4920;
  ushort uStack_4918;
  undefined auStack_4910 [4];
  undefined4 uStack_490c;
  undefined4 uStack_4908;
  undefined2 uStack_4904;
  undefined4 uStack_4900;
  undefined2 uStack_48fc;
  undefined4 uStack_48f8;
  undefined2 uStack_48f4;
  undefined8 uStack_48f0;
  undefined2 uStack_48e8;
  undefined8 uStack_48e0;
  undefined2 uStack_48d8;
  undefined8 uStack_48d0;
  undefined2 uStack_48c8;
  undefined8 uStack_48c0;
  ushort uStack_48b8;
  undefined auStack_48b0 [4];
  undefined auStack_48ac [4];
  undefined auStack_48a8 [8];
  undefined8 uStack_48a0;
  longlong *plStack_4898;
  uint uStack_4890;
  undefined8 uStack_488c;
  longlong lStack_4878;
  undefined8 uStack_4868;
  longlong lStack_4860;
  ulonglong uStack_4858;
  undefined4 uStack_4850;
  undefined4 uStack_4840;
  undefined uStack_4838;
  undefined4 uStack_4830;
  undefined auStack_4828 [16];
  undefined *puStack_4818;
  undefined4 uStack_4810;
  undefined *puStack_4808;
  undefined2 auStack_4800 [2];
  undefined4 uStack_47fc;
  undefined8 uStack_47f8;
  undefined8 uStack_47f0;
  undefined8 uStack_47e2;
  undefined8 uStack_47d8;
  undefined8 uStack_47c8;
  undefined auStack_47b8 [8];
  undefined4 uStack_47b0;
  undefined4 uStack_47a8;
  uint **ppuStack_47a0;
  undefined *puStack_4798;
  undefined8 uStack_4790;
  uint *puStack_4788;
  undefined4 uStack_4780;
  undefined4 uStack_477c;
  longlong lStack_4778;
  undefined4 uStack_4770;
  undefined4 uStack_476c;
  longlong lStack_4768;
  undefined4 uStack_4760;
  undefined4 uStack_475c;
  short *psStack_4758;
  int iStack_4750;
  undefined4 uStack_474c;
  short *psStack_4748;
  int iStack_4740;
  undefined4 uStack_473c;
  undefined8 uStack_4738;
  undefined4 uStack_4730;
  undefined4 uStack_472c;
  undefined auStack_4728 [448];
  undefined8 uStack_4568;
  undefined8 uStack_4560;
  uint uStack_4558;
  short sStack_4554;
  int iStack_4552;
  undefined uStack_454e;
  undefined uStack_454d;
  short sStack_4518;
  ushort uStack_4516;
  uint uStack_4514;
  byte *pbStack_4510;
  undefined8 uStack_4508;
  undefined4 uStack_4500;
  ushort uStack_44fc;
  undefined2 uStack_44fa;
  undefined6 uStack_44f8;
  undefined2 uStack_44f2;
  undefined2 uStack_44f0;
  undefined2 uStack_44ee;
  ushort uStack_44ec;
  undefined2 uStack_44ea;
  undefined4 uStack_44e8;
  int iStack_44e4;
  undefined auStack_44e0 [16];
  undefined auStack_44d0 [8];
  undefined8 uStack_44c8;
  undefined8 uStack_44c0;
  undefined6 uStack_44b8;
  undefined2 uStack_44b2;
  undefined6 uStack_44b0;
  undefined2 uStack_44aa;
  undefined8 uStack_44a8;
  undefined auStack_44a0 [16];
  undefined auStack_4490 [16];
  undefined auStack_4480 [16];
  undefined8 uStack_4470;
  undefined auStack_4468 [16];
  undefined2 uStack_4458;
  undefined4 uStack_4454;
  undefined8 uStack_4450;
  undefined8 uStack_4448;
  undefined8 uStack_443a;
  undefined8 uStack_4430;
  undefined8 uStack_4420;
  undefined8 uStack_4408;
  undefined4 uStack_4400;
  undefined2 uStack_43f6;
  short asStack_43e8 [24];
  short asStack_43b8 [24];
  byte abStack_4388 [8096];
  undefined auStack_23e8 [9120];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  uStack_47c8 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004a10 + lVar15) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15);
  sStack_4518 = -1;
  lVar17 = 0;
  pbStack_4510 = (byte *)0x0;
  uStack_4514 = 0;
  uStack_44fa = 0;
  uStack_44f8 = 0;
  uStack_44f0 = 0;
  uStack_44ee = 0;
  uStack_44ec = 0;
  uStack_44ea = 0;
  uStack_4508 = (byte **)0x0;
  iStack_44e4 = 0xffffffff;
  sStack_4978 = -1;
  pbStack_4970 = (byte *)0x0;
  uStack_4974 = 0;
  uStack_495a = 0;
  uStack_4950 = 0;
  uStack_494e = 0;
  uStack_494c = 0;
  uStack_494a = 0;
  ppbStack_4968 = (byte **)0x0;
  auStack_4800[0] = 0xffff;
  uStack_47f8 = 0;
  uStack_47fc = 0;
  uStack_47e2 = 0;
  uStack_47d8 = 0;
  uStack_47f0 = 0;
  auStack_4828 = ZEXT816(0);
  auStack_4468 = ZEXT816(0);
  uStack_4458 = 0xffff;
  uStack_4450 = 0;
  uStack_4454 = 0;
  uStack_443a = 0;
  uStack_4430 = 0;
  uStack_4448 = 0;
  uStack_4420 = 0;
  uStack_4408 = 0;
  uStack_4400 = 0;
  uStack_43f6 = 0;
  uStack_4928 = *(undefined4 *)(param_4 + 4);
  uStack_4924 = *(undefined2 *)(param_4 + 8);
  uStack_4922 = param_5;
  *(undefined8 *)(&stack0x00000040 + lVar15) = 0;
  uStack_49a4 = 0;
  (&stack0x00000038)[lVar15] = 5;
  uStack_4868 = 0xaacdb0;
  uStack_4858 = 0;
  uStack_4850 = 0;
  uStack_4840 = 0xffffffff;
  uStack_4830 = 0x80000000;
  uStack_4838 = 0;
  uVar4 = *(undefined2 *)(param_2 + 2);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001b9;
  iStack_493c = param_3;
  lStack_4878 = param_1;
  plVar16 = (longlong *)func_0x(uVar4);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001cb;
  plStack_4898 = plVar16;
  func_0x(param_1);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001d0;
  uVar10 = func_0x();
  *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar15) = 0;
  *(undefined4 *)((longlong)&uStackX_10 + lVar15) = 1;
  *(undefined4 *)((longlong)&plStackX_8 + lVar15) = uVar10;
  *(undefined4 *)((longlong)auStackX_20 + lVar15 + -0x20) = 1;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
  *(undefined8 **)(&stack0xffffffffffffffe8 + lVar15) = &uStack_48a0;
  uVar5 = *(undefined8 *)(param_1 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100219;
  func_0x(plVar16,uVar5,&uStack_4868,&stack0x00000038 + lVar15);
  (&stack0xffffffffffffffe8)[lVar15] = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100236;
  func_0x(plVar16,uStack_48a0,(&stack0x00000038)[lVar15],0);
  pcVar6 = *(code **)(*plVar16 + 0x270);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100242;
  (*pcVar6)(plVar16);
  iStack_4998 = *(int *)(param_2 + 4);
  sStack_4994 = *(short *)(param_2 + 8);
  lVar19 = plVar16[6];
  uStack_488c = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar30 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar30 != 0) && (lVar30 = **(longlong **)(lVar30 + 0x38), lVar30 != 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1002ae;
      iVar11 = (*_DAT_)(lVar30,0x337);
      if (iVar11 != 0) goto LAB_;
    }
    lVar30 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar30 != 0) {
      lVar17 = *(longlong *)(lVar30 + 0x60);
    }
  }
LAB_:
  lVar30 = *(longlong *)(lVar19 + 0x728);
LAB_:
  uStack_4940 = 0;
  lVar31 = *(longlong *)(&stack0x00000040 + lVar15);
  if (lVar31 != 0) {
    iVar11 = (int)(short)(ushort)uStack_49a4;
    if (((*(ushort *)(lVar31 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
      plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
      if (((byte)*(undefined2 *)(lVar31 + 0x62) >> 3 & 1) != 0) {
        if (iVar11 == 3) {
          iVar11 = 4;
        }
        else if (iVar11 < 2) goto LAB_;
        if ((((*(uint *)(*(longlong *)(&stack0x00000040 + lVar15) + 100) & 8) != 0) &&
            (lVar31 = *(longlong *)(*(longlong *)(&stack0x00000040 + lVar15) + 0x90), lVar31 != 0))
           && (*(longlong *)(lVar31 + 0x758) != 0)) {
          uVar5 = *(undefined8 *)(lVar31 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10038e;
          func_0x(uVar5,*(undefined8 *)(&stack0x00000040 + lVar15),iVar11);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar16 + 100) & 8) != 0)) &&
         ((2 < iVar11 &&
          (((*(uint *)((longlong)plVar16 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar31 = *plVar16, lVar31 != 0)))))) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003d3;
        iVar12 = (*_DAT_)(lVar31,0x2000,2,auStack_48b0);
        if (iVar12 != 0) {
          LOCK();
          *(uint *)((longlong)plVar16 + 100) = *(uint *)((longlong)plVar16 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar16 + 100) = *(uint *)((longlong)plVar16 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003f5;
      func_0x(plVar16 + 0x13,iVar11);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100414;
        func_0x(plVar16,0,iVar11);
      }
      uStack_49a4 = uStack_49a4 & 0xffff0000;
      *(undefined8 *)(&stack0x00000040 + lVar15) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100329;
      func_0x(&stack0x00000040 + lVar15);
    }
  }
  if (*(longlong *)(lVar19 + 0x728) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100444;
    func_0x(&stack0x00000040 + lVar15,&iStack_4998,lVar19);
    lVar31 = *(longlong *)(&stack0x00000040 + lVar15);
    if (lVar31 != 0) {
      iVar11 = (int)(short)(ushort)uStack_49a4;
      if (((*(ushort *)(lVar31 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
        if (((byte)*(undefined2 *)(lVar31 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)(&stack0x00000040 + lVar15) + 100) & 8) != 0) &&
              (lVar31 = *(longlong *)(*(longlong *)(&stack0x00000040 + lVar15) + 0x90), lVar31 != 0)
              ) && (*(longlong *)(lVar31 + 0x758) != 0)) {
            uVar5 = *(undefined8 *)(lVar31 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1004d3;
            func_0x(uVar5,*(undefined8 *)(&stack0x00000040 + lVar15),iVar11);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar16 + 100) & 8) != 0)) &&
           ((2 < iVar11 &&
            (((*(uint *)((longlong)plVar16 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar31 = *plVar16, lVar31 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100514;
          iVar12 = (*_DAT_)(lVar31,0x2000,2,auStack_48ac);
          if (iVar12 != 0) {
            LOCK();
            *(uint *)((longlong)plVar16 + 100) = *(uint *)((longlong)plVar16 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar16 + 100) = *(uint *)((longlong)plVar16 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100536;
        func_0x(plVar16 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100555;
          func_0x(plVar16,0,iVar11);
        }
        uStack_49a4 = uStack_49a4 & 0xffff0000;
        *(undefined8 *)(&stack0x00000040 + lVar15) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10046e;
        func_0x(&stack0x00000040 + lVar15);
      }
    }
  }
  uVar27 = uStack_49a4;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10056d;
  func_0x(lVar19,&iStack_4998);
  *(uint **)(&stack0xfffffffffffffff0 + lVar15) = &uStack_4890;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 4;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100598;
  plVar16 = (longlong *)func_0x(_DAT_,lVar19,&iStack_4998,&uStack_4940);
  *(longlong **)(&stack0x00000040 + lVar15) = plVar16;
  if (lVar17 != 0) {
    uVar28 = (ulonglong)(*(uint *)(lVar17 + 0x500) & 0xf);
    if (*(longlong *)(lVar17 + 0x508 + uVar28 * 8) != *plVar16) {
      *(longlong *)(lVar17 + 0x508 + uVar28 * 8) = *plVar16;
      *(longlong *)(lVar17 + 0x500) = *(longlong *)(lVar17 + 0x500) + 1;
    }
  }
  uVar29 = uStack_49a4 & 0xff0004 | 4;
  uStack_49a4 = (uStack_4940 >> 3 & 1) << 0x18 | uVar29;
  if (((lVar30 != 0) && (lVar17 != 0)) && (lVar17 == *(longlong *)(lVar19 + 0x1c38))) {
    *(longlong *)(lVar30 + 0x5b28) = *(longlong *)(lVar30 + 0x5b28) + 1;
    if ((int)uStack_488c != 0) {
      *(longlong *)(lVar30 + 0x5b30) = *(longlong *)(lVar30 + 0x5b30) + 1;
      *(longlong *)(lVar30 + 0x5b38) = *(longlong *)(lVar30 + 0x5b38) + (ulonglong)uStack_4890;
      if (0xffffff < uStack_49a4) {
        *(longlong *)(lVar30 + 0x5b40) = *(longlong *)(lVar30 + 0x5b40) + 1;
        *(longlong *)(lVar30 + 0x5b48) = *(longlong *)(lVar30 + 0x5b48) + (ulonglong)uStack_4890;
      }
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100668;
  cVar9 = func_0x(lVar19);
  uVar33 = 9;
  if (((cVar9 == '\0') || (*(char *)(lVar19 + 0x2050) == '\0')) ||
     ((iStack_4998 == 0 || ((iStack_4998 == 9 && (sStack_4994 == 1)))))) goto LAB_;
  lVar31 = **(longlong **)(&stack0x00000040 + lVar15);
  if (*(short *)(lVar31 + 0x24) == 0) {
LAB_:
    uStack_4920 = *(undefined8 *)(lVar31 + 0x28);
    uStack_4918 = *(ushort *)(lVar31 + 0x30);
  }
  else {
    cVar9 = *(char *)(lVar31 + 1);
    if (cVar9 == '\v') {
      if (*(int *)(lVar31 + 0x18) != 99) {
LAB_:
        if (cVar9 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar9 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar31 + 0x18) != 99) goto LAB_;
    }
    uStack_4908 = *(undefined4 *)(lVar31 + 0x20);
    uStack_4904 = *(undefined2 *)(lVar31 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1006ee;
    cVar9 = func_0x(&uStack_4908);
    if (cVar9 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1006fe;
    func_0x(lVar31,&uStack_4920);
  }
  uVar14 = *(uint *)(lVar19 + 0x2108);
  do {
    uVar13 = uVar14 & 0xfffffffe;
    uStack_4990 = *(undefined8 *)(lVar19 + 0x20fc);
    uStack_4988 = *(undefined4 *)(lVar19 + 0x2104);
    LOCK();
    *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
         *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
    UNLOCK();
    uVar14 = *(uint *)(lVar19 + 0x2108);
  } while (uVar13 != uVar14);
  if ((uint)uStack_4920 <= (uint)uStack_4990) {
    if ((uint)uStack_4990 != (uint)uStack_4920) goto LAB_;
    uVar14 = (uint)((ulonglong)uStack_4990 >> 0x20);
    if ((uStack_4920._4_4_ <= uVar14) &&
       ((uVar14 != uStack_4920._4_4_ || (uStack_4918 <= (ushort)uStack_4988)))) goto LAB_;
  }
  if ((*(char *)(lVar19 + 0x6ac8) == '\0') &&
     (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) != *(longlong *)(lVar19 + 0x2120))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007ba;
    cVar9 = func_0x(lVar19);
    if (cVar9 == '\0') {
      uVar27 = *(uint *)(lVar19 + 0x2108);
      do {
        uVar29 = uVar27 & 0xfffffffe;
        uStack_4990 = *(undefined8 *)(lVar19 + 0x20fc);
        uStack_4988 = *(undefined4 *)(lVar19 + 0x2104);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
        UNLOCK();
        uVar27 = *(uint *)(lVar19 + 0x2108);
      } while (uVar29 != uVar27);
      uVar22 = (ushort)uStack_4988;
      uStack_48b8 = (ushort)uStack_4988;
      lVar30 = **(longlong **)(&stack0x00000040 + lVar15);
      uStack_48c0 = uStack_4990;
      if (*(short *)(lVar30 + 0x24) == 0) {
LAB_:
        uStack_4938 = *(undefined8 *)(lVar30 + 0x28);
        uStack_4930 = *(ushort *)(lVar30 + 0x30);
      }
      else {
        cVar9 = *(char *)(lVar30 + 1);
        if (cVar9 == '\v') {
          if (*(int *)(lVar30 + 0x18) != 99) {
LAB_:
            if (cVar9 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar9 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar30 + 0x18) != 99) goto LAB_;
        }
        uStack_48f8 = *(undefined4 *)(lVar30 + 0x20);
        uStack_48f4 = *(undefined2 *)(lVar30 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a74;
        cVar9 = func_0x(&uStack_48f8);
        if (cVar9 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a84;
        func_0x(lVar30,&uStack_4938);
      }
      if ((uint)uStack_4990 < (uint)uStack_4938) {
LAB_:
        lVar30 = *(longlong *)(lVar19 + 0x6b0);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100ae6;
        func_0x(&uStack_4938,asStack_43e8,auStack_4910);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100afa;
        func_0x(&uStack_48c0,asStack_43b8,auStack_4910);
        if ((_DAT_ & 0x10000) != 0) {
          uStack_47b0 = 0x60000;
          iVar11 = 0;
          uStack_47a8 = 0;
          ppuStack_47a0 = &puStack_4788;
          puStack_4798 = auStack_4728;
          uStack_4568 = 0;
          uStack_4790 = 0;
          uStack_4560 = 0;
          puStack_4788 = &uStack_4558;
          uStack_4780 = 0x34;
          uStack_477c = 5;
          uStack_4770 = 0x10;
          uStack_476c = 5;
          uStack_4760 = 0x10;
          uStack_475c = 6;
          uStack_474c = 7;
          uStack_473c = 8;
          uStack_4738 = 0;
          uStack_4730 = 0;
          uStack_472c = 9;
          uStack_4558 = (uint)*(ushort *)(lVar19 + 0x6b8);
          sStack_4554 = sStack_4994;
          iStack_4552 = iStack_4998;
          uStack_454e = 1;
          uStack_454d = *(undefined *)(**(longlong **)(&stack0x00000040 + lVar15) + 1);
          lStack_4778 = lVar30 + 0x254;
          lStack_4768 = lVar30 + 0x244;
          lVar19 = -1;
          do {
            lVar19 = lVar19 + 1;
          } while (asStack_43e8[lVar19] != 0);
          iStack_4750 = (int)lVar19 * 2;
          psStack_4758 = asStack_43e8;
          lVar19 = -1;
          do {
            lVar19 = lVar19 + 1;
          } while (asStack_43b8[lVar19] != 0);
          iStack_4740 = (int)lVar19 * 2;
          psStack_4748 = asStack_43b8;
          uStack_490c = 0;
          pcVar6 = *(code **)(_DAT_ + 0x10);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100cb3;
          puVar18 = (uint *)(*pcVar6)(lVar30,&uStack_490c);
          ppuVar8 = ppuStack_47a0;
          if (puVar18 != (uint *)0x0) {
            lVar19 = -1;
            do {
              lVar19 = lVar19 + 1;
            } while (*(short *)((longlong)puVar18 + lVar19 * 2) != 0);
            iVar11 = (int)lVar19 * 2;
          }
          ppuStack_47a0[10] = puVar18;
          *(int *)(ppuVar8 + 0xb) = iVar11;
          *(undefined4 *)((longlong)ppuVar8 + 0x5c) = 9;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100ced;
          func_0x(auStack_47b8);
        }
      }
      else if ((uint)uStack_4990 == (uint)uStack_4938) {
        uVar27 = (uint)((ulonglong)uStack_4938 >> 0x20);
        if ((uStack_4990._4_4_ < uVar27) ||
           ((uStack_4990._4_4_ == uVar27 && (uVar22 < uStack_4930)))) goto LAB_;
      }
LAB_:
      uVar28 = 8;
      if ((1 < (short)(ushort)uStack_49a4) &&
         (*(char *)(**(longlong **)(&stack0x00000040 + lVar15) + 1) != '\x01')) {
        if (lVar17 != 0) {
          *(longlong *)(lVar17 + 0x588) = **(longlong **)(&stack0x00000040 + lVar15);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d27;
        lVar19 = func_0x();
        if (lVar19 != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d31;
          lVar19 = func_0x();
          if (*(longlong *)(lVar19 + 0x30) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d3d;
            lVar19 = func_0x();
            uVar27 = *(uint *)(*(longlong *)(lVar19 + 0x30) + 0xc);
            if ((uVar27 < 0xe) && ((0x2640U >> (uVar27 & 0x1f) & 1) != 0)) goto LAB_;
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d5d;
        func_0x(0,uVar28 & 0xffffffff);
      }
LAB_:
      lVar19 = **(longlong **)(&stack0x00000040 + lVar15);
      uVar28 = 0xf;
      iStack_44e4 = param_3;
      if (*(char *)(lVar19 + 2) < '\0') {
        pbVar1 = (byte *)(lVar19 + 0x60);
        if ((sStack_4518 == 0) || (ppbVar24 = uStack_4508, uStack_4508 == (byte **)0x0)) {
          uStack_44b8 = 0;
          uStack_44aa = 0;
          auStack_4490 = ZEXT816(0);
          auStack_44e0 = ZEXT816(0);
          stack0xffffffffffffbb32 = SUB1614(ZEXT816(0),2);
          auStack_44d0._0_2_ = 0xffff;
          uStack_44c8 = 0;
          uStack_44b2 = 0;
          uStack_44b0 = 0;
          uStack_44a8 = 0;
          uStack_44c0 = 0;
          auStack_44a0 = ZEXT816(0);
          auStack_4480._0_12_ = ZEXT812(0);
          auStack_4480._12_4_ = 0;
          uStack_4470 = 0;
          ppbVar24 = (byte **)auStack_44e0;
        }
        if (*(short *)(lVar19 + 0x24) == 0) {
LAB_:
          uStack_48e0 = *(undefined8 *)(lVar19 + 0x28);
          uStack_48d8 = *(undefined2 *)(lVar19 + 0x30);
        }
        else {
          cVar9 = *(char *)(lVar19 + 1);
          if (cVar9 == '\v') {
            if (*(int *)(lVar19 + 0x18) != 99) {
LAB_:
              if (cVar9 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar9 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar19 + 0x18) != 99) goto LAB_;
          }
          uStack_4984 = *(undefined4 *)(lVar19 + 0x20);
          uStack_4980 = *(undefined2 *)(lVar19 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100e99;
          cVar9 = func_0x(&uStack_4984,0xaacf48,0xaacf48);
          if (cVar9 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100ea9;
          func_0x(lVar19,&uStack_48e0);
        }
        *ppbVar24 = pbVar1;
        *(undefined4 *)(ppbVar24 + 0xc) = (undefined4)uStack_48e0;
        *(int *)((longlong)ppbVar24 + 100) = (int)((ulonglong)uStack_48e0 >> 0x20);
        *(undefined2 *)(ppbVar24 + 0xd) = uStack_48d8;
        *(undefined4 *)((longlong)ppbVar24 + 0x6c) = *(undefined4 *)(lVar19 + 0x20);
        *(undefined2 *)(ppbVar24 + 0xe) = *(undefined2 *)(lVar19 + 0x24);
        *(undefined2 *)((longlong)ppbVar24 + 0x72) = 0;
        uStack_4984 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0xb2d550);
        uVar32 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0xb2d554);
        *(undefined2 *)(ppbVar24 + 2) = 0xffff;
        ppbVar24[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
        ppbVar24[7] = (byte *)0x0;
        ppbVar24[4] = (byte *)0x0;
        ppbVar24[9] = (byte *)0x0;
        ppbVar24[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar24 + 0xb) = 0;
        if ((**ppbVar24 & 2) != 0) {
          pbVar2 = pbVar1 + uVar32;
          if ((*pbVar2 & 1) == 0) {
            *(undefined2 *)(ppbVar24 + 2) = 0;
            ppbVar24[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
            uVar27 = 0;
            switch(*pbVar2 & 0xe) {
            default:
              uVar22 = *(ushort *)(pbVar2 + 2);
              uVar27 = (uint)uVar22;
              if (0x1f9d < uVar22 - 1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10112a;
                func_0x(pbVar2,6);
              }
              break;
            case 4:
              uVar27 = uVar33;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar27 = 1;
            }
            *(uint *)(ppbVar24 + 4) = uVar27;
            *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
          }
          else {
            *(undefined2 *)(ppbVar24 + 2) = 1;
            ppbVar24[3] = pbVar2;
            bVar3 = *pbVar2;
            switch(bVar3 & 0x1c) {
            default:
              if ((char)pbVar2[1] < '\0') {
                uVar22 = *(ushort *)(pbVar2 + 1);
                *(ushort *)((longlong)ppbVar24 + 0x12) = uVar22;
                sVar34 = 3;
                uVar22 = (uVar22 & 0x7f) << 8 | uVar22 >> 8;
              }
              else {
                sVar34 = 2;
                uVar22 = (ushort)pbVar2[1];
              }
              *(ushort *)((longlong)ppbVar24 + 0x12) = uVar22;
              *(short *)(ppbVar24 + 5) = sVar34;
              uVar22 = *(ushort *)((longlong)ppbVar24 + 0x12);
              *(short *)((longlong)ppbVar24 + 0x2c) = (short)(uVar22 + 1 >> 1) + sVar34;
              if (uVar22 < 0x1f) {
                *(undefined2 *)((longlong)ppbVar24 + 0x2a) = 0;
                *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                *(undefined4 *)(ppbVar24 + 8) = 0;
                ppbVar24[7] = (byte *)0x0;
                ppbVar24[4] = (byte *)0x0;
              }
              else {
                iVar11 = uVar22 - 1;
                *(short *)((longlong)ppbVar24 + 0x2a) =
                     ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                     (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
                *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                *(undefined4 *)(ppbVar24 + 8) = 0;
                ppbVar24[7] = (byte *)0x0;
                ppbVar24[4] = (byte *)0x0;
              }
              break;
            case 4:
              if (((bVar3 & 0x1c) != 4) || (uVar27 = 1, (bVar3 & 2) == 0)) {
                uVar27 = 0;
              }
              if (uVar27 == 0) {
                uVar10 = 1;
              }
              else {
                *(undefined4 *)(ppbVar24 + 8) = 0;
                uVar10 = 0xf;
              }
              ppbVar24[5] = (byte *)0x0;
              *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
              ppbVar24[6] = (byte *)0x0;
              ppbVar24[4] = (byte *)0x0;
              ppbVar24[7] = (byte *)0x0;
              ppbVar24[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar24 + 0x14) = uVar10;
              *(uint *)(ppbVar24 + 8) = (uint)(uVar27 != 0);
              ppbVar24[7] = (byte *)0x0;
              ppbVar24[4] = (byte *)0x0;
              break;
            case 8:
              ppbVar24[5] = (byte *)0x0;
              *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
              ppbVar24[6] = (byte *)0x0;
              ppbVar24[4] = (byte *)0x0;
              ppbVar24[7] = (byte *)0x0;
              ppbVar24[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar24 + 0x14) = 9;
              *(undefined4 *)(ppbVar24 + 8) = 0;
              ppbVar24[7] = (byte *)0x0;
              ppbVar24[4] = (byte *)0x0;
            }
          }
        }
        if ((**ppbVar24 & 4) != 0) {
          if (uStack_4984._2_2_ != 0) {
            uVar32 = (ulonglong)*(ushort *)(lVar19 + 0x61 + (longlong)uStack_4984._2_2_ * 2);
          }
          psVar20 = (short *)(pbVar1 + uVar32);
          ppbVar24[9] = (byte *)psVar20;
          sVar34 = *psVar20;
          ppbVar24[10] = (byte *)(psVar20 + 1);
          *(short *)(ppbVar24 + 0xb) = (sVar34 + 1) * 2;
        }
        pbVar1 = ppbVar24[1];
        param_3 = iStack_493c;
        if (pbVar1 != (byte *)0x0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1011bf;
          func_0x(pbVar1,ppbVar24);
          param_3 = iStack_493c;
        }
      }
      else {
        ppbVar24 = (byte **)0x0;
      }
      uVar32 = 0;
      uVar25 = (ulonglong)*(ushort *)(lVar19 + 0xe);
      pbStack_4510 = (byte *)((ulonglong)*(ushort *)(lVar19 + (0xfff - (longlong)param_3) * 2) +
                             lVar19);
      if ((*pbStack_4510 & 1) == 0) {
        sStack_4518 = 0;
        uStack_4514 = 0;
        uStack_44f2 = 0;
        uStack_44f0 = 0;
        switch(*pbStack_4510 & 0xe) {
        default:
          uVar25 = (ulonglong)*(ushort *)(pbStack_4510 + 2);
          uVar32 = 0;
          if (0x1f9d < *(ushort *)(pbStack_4510 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101427;
            func_0x(pbStack_4510,6);
            uVar32 = (ulonglong)uStack_4514;
          }
          break;
        case 4:
          uVar25 = 9;
          uVar32 = 0;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar25 = 1;
        }
        uVar27 = (uint)uVar32;
        uStack_4508 = (byte **)CONCAT44(uStack_4508._4_4_,(int)uVar25);
        lVar17 = lVar19 + 0x2000;
        if (lVar19 == 0) {
          lVar17 = 0;
        }
        uStack_44fa = (undefined2)lVar17;
        uStack_44f8 = (undefined6)((ulonglong)lVar17 >> 0x10);
      }
      else {
        sStack_4518 = 1;
        bVar3 = *pbStack_4510;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbStack_4510[1] < '\0') {
            uStack_4516 = (*(ushort *)(pbStack_4510 + 1) & 0x7f) << 8 |
                          *(ushort *)(pbStack_4510 + 1) >> 8;
            sVar34 = 3;
            uStack_4500._0_2_ = 3;
          }
          else {
            uStack_4516 = (ushort)pbStack_4510[1];
            uStack_4500._0_2_ = 2;
            sVar34 = 2;
          }
          uStack_44fc = (short)(uStack_4516 + 1 >> 1) + sVar34;
          uVar28 = uVar32;
          if (uStack_4516 < 0x1f) {
            uStack_4500._2_2_ = 0;
            uStack_4514 = 0;
            uStack_44e8 = 0;
          }
          else {
            iVar11 = uStack_4516 - 1;
            uStack_4500._2_2_ =
                 ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                 (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
            uStack_4514 = 0;
            uStack_44e8 = 0;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
            uStack_4500._0_2_ = 0;
            uStack_4500._2_2_ = 0;
            uStack_44fc = 0;
            uStack_44fa = 0;
            uStack_4516 = 0;
            uStack_44f8 = 0;
            uStack_44f2 = 0;
            uStack_4514 = 0xf;
            uStack_44e8 = 1;
          }
          else {
            uStack_4500._0_2_ = 0;
            uStack_4500._2_2_ = 0;
            uStack_44fc = 0;
            uStack_44fa = 0;
            uStack_4516 = 0;
            uStack_44f8 = 0;
            uStack_44f2 = 0;
            uVar28 = 1;
            uStack_4514 = 1;
            uStack_44e8 = 0;
          }
          break;
        case 8:
          uStack_4500._0_2_ = 0;
          uStack_4500._2_2_ = 0;
          uStack_44fc = 0;
          uStack_44fa = 0;
          uStack_4516 = 0;
          uStack_44f8 = 0;
          uStack_44f2 = 0;
          uVar28 = 9;
          uStack_4514 = 9;
          uStack_44e8 = 0;
        }
        uVar27 = (uint)uVar28;
        uVar28 = lVar19 + 0x2000;
        if (lVar19 == 0) {
          uVar28 = uVar32;
        }
        uStack_44f0 = (undefined2)uVar28;
        uStack_44ee = (undefined2)(uVar28 >> 0x10);
        uStack_44ec = (ushort)(uVar28 >> 0x20);
        uStack_44ea = (undefined2)(uVar28 >> 0x30);
        uVar25 = (ulonglong)ppbVar24 & 0xffffffff;
        uStack_4508 = ppbVar24;
      }
      sStack_4978 = sStack_4518;
      if (sStack_4518 != 0) {
        if ((uStack_4508 == (byte **)0x0) || (*uStack_4508 == (byte *)0x0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101cbc;
          func_0x(&uStack_4976,abStack_4388,0x1f9e,&uStack_4516);
          ppbStack_4968 = uStack_4508;
          if (sStack_4518 == 0) {
            ppbStack_4968 = (byte **)0x0;
          }
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101c9a;
          func_0x(&sStack_4978,abStack_4388,0x1f9e,&sStack_4518);
        }
        goto code_r0x00101cd9;
      }
      if (uVar27 == 0) {
        uStack_4516 = 0;
        uVar27 = (uint)uVar25;
        if ((*pbStack_4510 & 0x10) != 0) {
          uVar27 = uVar27 + 2 + (*(ushort *)(pbStack_4510 + uVar25) + 7 >> 3);
          uVar25 = (ulonglong)uVar27;
        }
        uStack_4508 = (byte **)CONCAT44(uVar27,(undefined4)uStack_4508);
        if ((*pbStack_4510 & 0x20) == 0) {
          uStack_44fc = 0;
          uVar28 = uVar25;
          uStack_4514 = (uint)uVar25;
          uStack_4500 = (uint)uVar25;
        }
        else {
          puVar26 = (ushort *)(pbStack_4510 + uVar25);
          uStack_44fc = *puVar26;
          if (uStack_44fc == 0) {
            if ((((cRam000000000144003b != '\0') || ((bRam0000000001450940 & 1) != 0)) &&
                (lVar17 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar17 != 0)) &&
               ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((cRam000000000143ff2b == '\0') && ((bRam0000000001450940 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10157a;
                (*pcRam00000000009ae868)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1015a0;
                (*pcRam00000000009ae860)(1,0xd30a68,0xe50738,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1015af;
            func_0x(pbStack_4510,3);
          }
          uStack_4500 = uStack_4508._4_4_ + (uStack_44fc + 1) * 2;
          if (0x1f9e < uStack_4500) {
            if (((cRam000000000144003b != '\0') || ((bRam0000000001450940 & 1) != 0)) &&
               ((lVar17 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar17 != 0 &&
                ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                 (*(char *)(lVar17 + 0x499) != '\0')))))) {
              if ((cRam000000000143ff2b == '\0') && ((bRam0000000001450940 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101650;
                (*pcRam00000000009ae868)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101676;
                (*pcRam00000000009ae860)(1,0xd30a68,0xe50738,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101687;
            func_0x(pbStack_4510,4);
          }
          uStack_4514 = puVar26[uStack_44fc] & 0x7fff;
          if (uStack_4514 < uStack_4500) {
            if ((((cRam000000000144003b != '\0') || ((bRam0000000001450940 & 1) != 0)) &&
                (lVar17 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar17 != 0)) &&
               ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((cRam000000000143ff2b == '\0') && ((bRam0000000001450940 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101722;
                (*pcRam00000000009ae868)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10176a;
                (*pcRam00000000009ae860)(1,0xd30a68,0xe50738,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101736;
            func_0x(pbStack_4510,4);
          }
          uVar28 = (ulonglong)uStack_4514;
          uVar25 = (ulonglong)uStack_4500;
          while( true ) {
            if (-1 < (short)puVar26[(ulonglong)(uStack_44fc - 1) + 1]) break;
            uVar29 = (uint)uVar25;
            if (uStack_44fc != 1) {
              uVar29 = *(ushort *)
                        (pbStack_4510 +
                        (ulonglong)uStack_44fc * 2 + (((ulonglong)uStack_4508 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar29 < (uint)uVar25) ||
               ((*(ushort *)
                  (pbStack_4510 + (ulonglong)uStack_44fc * 2 + ((ulonglong)uStack_4508 >> 0x20)) &
                0x7fff) < uVar29)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1017e1;
              func_0x(pbStack_4510,7);
              uVar25 = (ulonglong)uStack_4500;
              uVar28 = (ulonglong)uStack_4514;
            }
            uVar27 = (uint)uVar28;
            uStack_4960 = (uint)uVar25;
            if ((uVar29 < uStack_4960) || (uVar27 < uVar29)) goto code_r0x00101b47;
            if (*(ushort *)(pbStack_4510 + uVar29) == 5) {
              uStack_4516 = uStack_4516 | 2;
              uStack_44fc = uStack_44fc - 1;
              uStack_44ee = (undefined2)uVar29;
              if ((*(ushort *)(pbStack_4510 + (ulonglong)(uVar29 & 0xffff) + 2) & 0x4000) == 0) {
                uStack_44ec = uStack_44ec & 0xc7ff;
              }
              else {
                uStack_44ec = uStack_44ec ^
                              (uStack_44ec ^
                              *(ushort *)(pbStack_4510 + (ulonglong)(uVar29 & 0xffff) + 2)) & 0x3800
                ;
              }
              uStack_44ec = (uStack_44ec ^
                            *(ushort *)(pbStack_4510 + (ulonglong)(uVar29 & 0xffff) + 2)) & 0x7ff ^
                            uStack_44ec;
              goto code_r0x001018eb;
            }
            if (*(ushort *)(pbStack_4510 + uVar29) < 0x400) break;
            uStack_4516 = uStack_4516 | 1;
            uStack_44fc = uStack_44fc - 1;
            if (uStack_44fc == 0) break;
          }
        }
        uStack_4960 = (uint)uVar25;
code_r0x001018eb:
        if ((*pbStack_4510 & 0x40) == 0) {
          uStack_44f2 = 0;
          uStack_44f0 = 0;
        }
        else {
          uStack_44f2 = (undefined2)uVar28;
          uStack_44f0 = (undefined2)(uVar28 >> 0x10);
          uStack_4514 = (int)uVar28 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101916;
          puVar21 = (ulonglong *)func_0x(&uStack_4516);
          uVar28 = *puVar21;
          iVar11 = 0;
          uVar23 = (ushort)(uVar28 >> 0x30);
          uVar22 = uVar23;
          if ((((uint)(int)(short)uVar23 >> 1 ^ (int)(short)uVar23) & 0x2000) != 0) {
            uVar22 = uVar23 & 0xdfff;
            if ((uVar28 & 0x4000000000000000) != 0) {
              uVar22 = uVar23 | 0x2000;
            }
          }
          if (uVar22 == 0xfffc) {
            iVar11 = (int)((uVar28 >> 0x20 & 0xffff) >> 5);
          }
          uStack_4514 = uStack_4514 + iVar11;
          uVar28 = (ulonglong)uStack_4514;
          uStack_4960 = uStack_4500;
        }
        uVar27 = (uint)uVar28;
        if (((byte *)CONCAT62(uStack_44f8,uStack_44fa) != (byte *)0x0) &&
           ((byte *)CONCAT62(uStack_44f8,uStack_44fa) < pbStack_4510 + uVar28)) {
          if (((cRam000000000144003b != '\0') || ((bRam0000000001450940 & 1) != 0)) &&
             (((lVar17 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar17 != 0 && (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0))
              && (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((cRam000000000143ff2b == '\0') && ((bRam0000000001450940 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101a28;
              (*pcRam00000000009ae868)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101a4e;
              (*pcRam00000000009ae860)(1,0xd30a68,0xe50738,0x877);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101a5f;
          func_0x(pbStack_4510,0x12);
          uVar27 = uStack_4514;
          uStack_4960 = uStack_4500;
        }
        if (0x3f3b < uVar27 - 1) {
          if (((cRam000000000144003b != '\0') || ((bRam0000000001450940 & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((cRam000000000143ff2b == '\0') && ((bRam0000000001450940 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101aef;
              (*pcRam00000000009ae868)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101b37;
              (*pcRam00000000009ae860)(1,0xd30a68,0xe50738,0x87c);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101b03;
          func_0x(pbStack_4510,5);
          uVar27 = uStack_4514;
          uStack_4960 = uStack_4500;
        }
      }
      else {
        uStack_4960 = CONCAT22(uStack_4500._2_2_,(undefined2)uStack_4500);
      }
code_r0x00101b47:
      if ((8 < uVar27) || (((*pbStack_4510 & 0xe) != 0 && ((*pbStack_4510 & 0xe) != 0xc)))) {
        uVar33 = uVar27;
      }
      uStack_4976 = uStack_4516;
      uStack_495c = uStack_44fc;
      ppbStack_4968 = uStack_4508;
      uStack_4952 = uStack_44f2;
      uStack_4950 = uStack_44f0;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101bb5;
      uStack_4974 = uVar27;
      func_0x(abStack_4388,0x1f9e,pbStack_4510,uVar33);
      pbStack_4970 = abStack_4388;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101bc9;
      iVar11 = func_0x(&uStack_4976);
      if (iVar11 != 0) {
        puVar26 = (ushort *)(pbStack_4970 + ((ulonglong)ppbStack_4968 >> 0x20));
        uVar27 = *puVar26 - 1;
        if ((uStack_4976 & 1) == 0) {
          uVar27 = (uint)*puVar26;
        }
        uVar29 = uStack_4960;
        if (uVar27 != 1) {
          uVar29 = puVar26[(longlong)(int)uVar27 + -1] & 0x7fff;
        }
        if ((uVar29 < uStack_4960) || ((puVar26[(int)uVar27] & 0x7fff) < uVar29)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101c24;
          func_0x(pbStack_4970,7);
        }
        uStack_494e = (undefined2)uVar29;
        if ((*(ushort *)(pbStack_4970 + (ulonglong)(uVar29 & 0xffff) + 2) >> 0xe & 1) == 0) {
          uStack_494c = uStack_494c & 0xc7ff;
        }
        else {
          uStack_494c = uStack_494c ^
                        (*(ushort *)(pbStack_4970 + (ulonglong)(uVar29 & 0xffff) + 2) ^ uStack_494c)
                        & 0x3800;
        }
        uStack_494c = (uStack_494c ^ *(ushort *)(pbStack_4970 + (ulonglong)(uVar29 & 0xffff) + 2)) &
                      0x7ff ^ uStack_494c;
      }
code_r0x00101cd9:
      if (sStack_4978 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ce9;
        func_0x();
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101cf0;
        func_0x(&uStack_4976);
      }
      if (sStack_4978 == 0) {
        if ((*pbStack_4970 & 0xe) != 2) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101d1c;
          func_0x(&uStack_4976,0x400,8,&uStack_4928);
        }
        *pbStack_4970 = *pbStack_4970 & 0xf3;
        *pbStack_4970 = *pbStack_4970 | 2;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101d39;
        func_0x(&uStack_4976,&uStack_4928);
      }
      auStack_4828._0_8_ = &sStack_4978;
      if (*(char *)(lVar19 + 2) < '\0') {
        auStack_4828._8_8_ = auStack_4800;
        puStack_4818 = auStack_23e8;
        uStack_4810 = 0x239e;
        puStack_4808 = auStack_4468;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101d8e;
        func_0x(auStack_4828,lVar19);
      }
      lVar19 = lStack_4878;
      plVar16 = plStack_4898;
      *(undefined8 *)((longlong)&param_5 + lVar15) = 0;
      *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
      *(undefined8 *)((longlong)&uStackX_18 + lVar15) = 0;
      *(undefined4 *)((longlong)&uStackX_10 + lVar15) = 2;
      *(undefined8 *)((longlong)&plStackX_8 + lVar15) = 0;
      *(longlong **)((longlong)auStackX_20 + lVar15 + -0x20) = plStack_4898;
      *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
      uVar5 = *(undefined8 *)(lVar19 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101de8;
      func_0x(&stack0x00000040 + lVar15,uVar5,lVar19 + 0x10,param_3);
      *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
      *(undefined4 *)((longlong)&uStackX_18 + lVar15) = 0;
      *(undefined8 *)((longlong)&uStackX_10 + lVar15) = 0;
      *(longlong **)((longlong)&plStackX_8 + lVar15) = plVar16;
      *(undefined4 *)((longlong)auStackX_20 + lVar15 + -0x20) = 1;
      *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
      *(undefined **)(&stack0xfffffffffffffff0 + lVar15) = auStack_4828;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
      uVar5 = *(undefined8 *)(lVar19 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e2c;
      func_0x(&stack0x00000040 + lVar15,uVar5,lVar19 + 0x10,param_3);
      uStack_4868 = 0xaacdb0;
      if ((int)uStack_4858 == 3) {
        uStack_4858 = uStack_4858 & 0xffffffff00000000;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e61;
        func_0x(lStack_4860 + 0x530,1);
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e6c;
      func_0x(&stack0x00000040 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e7b;
      func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15));
      return;
    }
  }
  if (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) == *(longlong *)(lVar19 + 0x2120)) goto LAB_;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007fe;
  cVar9 = func_0x(lVar19);
  if (cVar9 != '\0') goto LAB_;
  if (lVar17 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100810;
    lVar17 = func_0x();
  }
  plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
  lVar31 = *plVar16;
  if (*(short *)(lVar31 + 0x24) == 0) {
LAB_:
    uStack_48f0 = *(undefined8 *)(lVar31 + 0x28);
    uStack_48e8 = *(undefined2 *)(lVar31 + 0x30);
  }
  else {
    cVar9 = *(char *)(lVar31 + 1);
    if (cVar9 == '\v') {
      if (*(int *)(lVar31 + 0x18) != 99) {
LAB_:
        if (cVar9 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar9 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar31 + 0x18) != 99) goto LAB_;
    }
    uStack_4900 = *(undefined4 *)(lVar31 + 0x20);
    uStack_48fc = *(undefined2 *)(lVar31 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100860;
    cVar9 = func_0x(&uStack_4900);
    if (cVar9 == '\0') {
      plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
      goto LAB_;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100870;
    func_0x(lVar31,&uStack_48f0);
    plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
  }
  if (plVar16 != (longlong *)0x0) {
    uStack_49a4._0_2_ = (ushort)uVar29;
    if (((*(ushort *)((longlong)plVar16 + 0x62) & 0x400) == 0) || ((ushort)uStack_49a4 < 3)) {
      plVar7 = *(longlong **)(&stack0x00000040 + lVar15);
      if (((byte)*(undefined2 *)((longlong)plVar16 + 0x62) >> 3 & 1) != 0) {
        if ((ushort)uStack_49a4 == 3) {
          uStack_49a4._0_2_ = 4;
        }
        else if ((ushort)uStack_49a4 < 2) goto LAB_;
        if ((((*(uint *)(*(longlong *)(&stack0x00000040 + lVar15) + 100) & 8) != 0) &&
            (lVar31 = *(longlong *)(*(longlong *)(&stack0x00000040 + lVar15) + 0x90), lVar31 != 0))
           && (*(longlong *)(lVar31 + 0x758) != 0)) {
          uVar5 = *(undefined8 *)(lVar31 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10094e;
          func_0x
                    (uVar5,*(undefined8 *)(&stack0x00000040 + lVar15),(ushort)uStack_49a4);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar7 + 100) & 8) != 0)) &&
         ((2 < (ushort)uStack_49a4 &&
          (((*(uint *)((longlong)plVar7 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar31 = *plVar7, lVar31 != 0)))))) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100992;
        iVar11 = (*_DAT_)(lVar31,0x2000,2,auStack_48a8);
        if (iVar11 != 0) {
          LOCK();
          *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1009b4;
      func_0x(plVar7 + 0x13,(ushort)uStack_49a4);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1009d3;
        func_0x(plVar7,0,(ushort)uStack_49a4);
      }
      *(undefined8 *)(&stack0x00000040 + lVar15) = 0;
      uStack_49a4 = uVar27 & 0xff0000;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1008b6;
      func_0x(&stack0x00000040 + lVar15);
    }
  }
  uStack_48d0 = uStack_48f0;
  uStack_48c8 = uStack_48e8;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
  uVar5 = *(undefined8 *)(lVar19 + 0x728);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1008e9;
  func_0x(uVar5,&uStack_48d0,4);
  goto LAB_;
}

