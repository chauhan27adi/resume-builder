
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,undefined param_3)

{
  short sVar1;
  undefined2 uVar2;
  uint *puVar3;
  code *pcVar4;
  char *pcVar5;
  byte bVar6;
  int iVar7;
  longlong lVar8;
  longlong *plVar9;
  ulonglong *puVar10;
  longlong lVar11;
  byte *pbVar12;
  ushort uVar13;
  ushort uVar14;
  uint uVar15;
  ulonglong uVar16;
  longlong lVar17;
  uint uVar18;
  undefined8 unaff_RBX;
  undefined8 unaff_RSI;
  undefined4 uVar19;
  undefined8 uVar20;
  undefined8 unaff_R12;
  longlong lVar21;
  undefined8 unaff_R15;
  ushort *puVar22;
  longlong unaff_GS_OFFSET;
  undefined8 auStackX_8 [2];
  uint auStackX_18 [2];
  undefined auStackX_20 [8];
  undefined auStack_2008 [8];
  undefined auStack_2000 [16];
  undefined8 uStack_1ff0;
  undefined auStack_1fe8 [8096];
  ulonglong uStack_48;
  undefined8 uStack_28;
  
  uStack_28 = 0x100019;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffe0 + lVar8);
  lVar21 = *(longlong *)(param_1 + 0x10);
  lVar17 = 0;
  auStackX_20[lVar8] = param_3;
  uStack_1ff0 = 0;
  auStack_2000 = ZEXT816(0);
  *(undefined8 *)(&stack0x00000030 + lVar8) = 0;
  *(undefined4 *)(&stack0x0000002c + lVar8) = 0;
  *(undefined8 *)(&stack0x00000046 + lVar8) = 0;
  *(undefined8 *)(&stack0x00000050 + lVar8) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar8) = 0;
  lVar21 = *(longlong *)(lVar21 + 8);
  if ((((*(byte *)(lVar21 + 0x41) & 8) == 0) && ((*(byte *)(lVar21 + 0x108) & 0x40) == 0)) ||
     (*(longlong **)(lVar21 + 0x160) == (longlong *)0x0)) goto LAB_;
  lVar21 = **(longlong **)(lVar21 + 0x160);
  uVar15 = *(uint *)(lVar21 + 100);
  if (uVar15 == 0xffffffff) goto LAB_;
  puVar3 = *(uint **)(lVar21 + 8);
  *(undefined8 *)(&stack0x00002038 + lVar8) = unaff_R12;
  if (uVar15 < *puVar3) {
    uVar16 = (ulonglong)uVar15 / (ulonglong)puVar3[9];
    uVar15 = uVar15 % puVar3[9];
    lVar21 = *(longlong *)(puVar3 + 4);
  }
  else {
    uVar16 = (ulonglong)(uVar15 - *puVar3) / (ulonglong)puVar3[0x11];
    uVar15 = (uVar15 - *puVar3) % puVar3[0x11];
    lVar21 = *(longlong *)(puVar3 + 0xc);
  }
  lVar21 = (ulonglong)uVar15 * 0x1c0 + *(longlong *)(lVar21 + uVar16 * 8);
  if (lVar21 == 0) goto LAB_;
  *(uint *)(param_2 + 2) = *(uint *)(param_2 + 2) & 0xfffffeff;
  uVar15 = *(uint *)(param_2 + 2);
  *(undefined8 *)(&stack0x00002040 + lVar8) = unaff_RSI;
  *(undefined8 *)(&stack0x00002030 + lVar8) = unaff_R15;
  if (((char)uVar15 < '\0') || ((*(byte *)((longlong)param_2 + 0x34) & 1) == 0)) {
    *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x10012a;
    plVar9 = (longlong *)func_0x(param_2,0);
  }
  else if ((uVar15 & 0x2000) == 0) {
    plVar9 = param_2 + 9;
  }
  else {
    plVar9 = (longlong *)param_2[0x29];
  }
  sVar1 = *(short *)plVar9;
  *(undefined8 *)(&stack0x00002088 + lVar8) = unaff_RBX;
  *(short *)(&stack0x00000028 + lVar8) = sVar1;
  if (sVar1 == 0) {
    if (*(int *)((longlong)plVar9 + 4) == 0) {
      pbVar12 = (byte *)plVar9[1];
      uVar15 = *(uint *)(plVar9 + 2);
      uVar16 = (ulonglong)uVar15;
      *(short *)((longlong)plVar9 + 2) = 0;
      *(uint *)((longlong)plVar9 + 0x14) = uVar15;
      bVar6 = *pbVar12;
      if ((bVar6 & 0x10) != 0) {
        uVar15 = uVar15 + (*(ushort *)(pbVar12 + uVar16) + 7 >> 3) + 2;
        uVar16 = (ulonglong)uVar15;
        *(uint *)((longlong)plVar9 + 0x14) = uVar15;
        bVar6 = *pbVar12;
      }
      if ((bVar6 & 0x20) == 0) {
        *(int *)((longlong)plVar9 + 4) = (int)uVar16;
        *(short *)((longlong)plVar9 + 0x1c) = 0;
        *(int *)(plVar9 + 3) = (int)uVar16;
      }
      else {
        puVar22 = (ushort *)(pbVar12 + uVar16);
        uVar13 = *puVar22;
        *(ushort *)((longlong)plVar9 + 0x1c) = uVar13;
        if (uVar13 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar17 != 0)) &&
             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x10021e;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(auStackX_20 + lVar8 + -0x20) = 0;
              *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100244;
              (*_DAT_)(1,0x17eff38,0x190fc08,0x80f);
            }
          }
          lVar17 = plVar9[1];
          *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100252;
          func_0x(lVar17,3);
          uVar16 = (ulonglong)*(uint *)((longlong)plVar9 + 0x14);
          uVar13 = *(ushort *)((longlong)plVar9 + 0x1c);
        }
        uVar15 = (int)uVar16 + (uVar13 + 1) * 2;
        *(uint *)(plVar9 + 3) = uVar15;
        if (0x1f9e < uVar15) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1002ed;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(auStackX_20 + lVar8 + -0x20) = 0;
              *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100313;
              (*_DAT_)(1,0x17eff38,0x190fc08,0x816);
            }
          }
          lVar17 = plVar9[1];
          *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100321;
          func_0x(lVar17,4);
          uVar13 = *(ushort *)((longlong)plVar9 + 0x1c);
        }
        uVar16 = (ulonglong)uVar13;
        uVar13 = puVar22[uVar16];
        *(uint *)((longlong)plVar9 + 4) = uVar13 & 0x7fff;
        if ((uVar13 & 0x7fff) < *(uint *)(plVar9 + 3)) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar17 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar17 != 0)) &&
             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1003ba;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(auStackX_20 + lVar8 + -0x20) = 0;
              *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1003e0;
              (*_DAT_)(1,0x17eff38,0x190fc08,0x81d);
            }
          }
          lVar17 = plVar9[1];
          *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1003ee;
          func_0x(lVar17,4);
          uVar16 = (ulonglong)*(ushort *)((longlong)plVar9 + 0x1c);
        }
        if ((short)puVar22[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
          do {
            lVar17 = plVar9[1];
            lVar11 = (ulonglong)*(uint *)((longlong)plVar9 + 0x14) + lVar17;
            if ((int)uVar16 == 1) {
              uVar15 = *(uint *)(plVar9 + 3);
              uVar18 = uVar15;
LAB_:
              if ((*(ushort *)(lVar11 + uVar16 * 2) & 0x7fff) < uVar15) goto LAB_;
            }
            else {
              uVar18 = *(uint *)(plVar9 + 3);
              uVar15 = *(ushort *)(lVar11 + -2 + uVar16 * 2) & 0x7fff;
              if (uVar18 <= uVar15) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100458;
              func_0x(lVar17,7);
              uVar18 = *(uint *)(plVar9 + 3);
              lVar17 = plVar9[1];
              uVar16 = (ulonglong)*(ushort *)((longlong)plVar9 + 0x1c);
            }
            if ((uVar15 < uVar18) || (*(uint *)((longlong)plVar9 + 4) < uVar15)) goto LAB_;
            if (*(ushort *)(lVar17 + (ulonglong)uVar15) == 5) {
              *(ushort *)((longlong)plVar9 + 2) = *(ushort *)((longlong)plVar9 + 2) | 2;
              *(short *)((longlong)plVar9 + 0x1c) = (short)uVar16 + -1;
              uVar13 = *(ushort *)((longlong)plVar9 + 0x2c) & 0xc7ff;
              *(short *)((longlong)plVar9 + 0x2a) = (short)uVar15;
              lVar17 = (ulonglong)(uVar15 & 0xffff) + plVar9[1];
              if ((*(ushort *)(lVar17 + 2) >> 0xe & 1) != 0) {
                uVar13 = *(ushort *)(lVar17 + 2) & 0x3800 | uVar13;
              }
              *(ushort *)((longlong)plVar9 + 0x2c) = uVar13;
              *(ushort *)((longlong)plVar9 + 0x2c) =
                   (uVar13 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar13;
              break;
            }
            if (*(ushort *)(lVar17 + (ulonglong)uVar15) < 0x400) break;
            *(ushort *)((longlong)plVar9 + 2) = *(ushort *)((longlong)plVar9 + 2) | 1;
            uVar13 = (short)uVar16 - 1;
            *(ushort *)((longlong)plVar9 + 0x1c) = uVar13;
            if ((uVar13 == 0) ||
               (uVar16 = (ulonglong)uVar13, -1 < (short)puVar22[(ulonglong)(uVar13 - 1) + 1]))
            break;
          } while( true );
        }
        uVar16 = (ulonglong)*(uint *)((longlong)plVar9 + 4);
        pbVar12 = (byte *)plVar9[1];
      }
      iVar7 = 0;
      if ((*pbVar12 & 0x40) == 0) {
        *(undefined4 *)((longlong)plVar9 + 0x26) = 0;
      }
      else {
        *(int *)((longlong)plVar9 + 0x26) = *(int *)((longlong)plVar9 + 4);
        *(int *)((longlong)plVar9 + 4) = *(int *)((longlong)plVar9 + 4) + 0xe;
        *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x10054e;
        puVar10 = (ulonglong *)func_0x((short *)((longlong)plVar9 + 2));
        uVar14 = (ushort)(*puVar10 >> 0x30);
        uVar13 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar13 = uVar14 & 0xdfff;
          if ((uVar14 >> 0xe & 1) != 0) {
            uVar13 = uVar14 | 0x2000;
          }
        }
        if (uVar13 == 0xfffc) {
          iVar7 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)((longlong)plVar9 + 4) = *(int *)((longlong)plVar9 + 4) + iVar7;
        uVar16 = (ulonglong)*(uint *)((longlong)plVar9 + 4);
        pbVar12 = (byte *)plVar9[1];
      }
      iVar7 = (int)uVar16;
      if ((*(byte **)((longlong)plVar9 + 0x1e) != (byte *)0x0) &&
         (*(byte **)((longlong)plVar9 + 0x1e) < pbVar12 + uVar16)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar17 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar17 != 0 &&
             (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
            (*(char *)(lVar17 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x10064a;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(auStackX_20 + lVar8 + -0x20) = 0;
            *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100670;
            (*_DAT_)(1,0x17eff38,0x190fc08,0x877);
          }
        }
        lVar17 = plVar9[1];
        *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x10067e;
        func_0x(lVar17,0x12);
        iVar7 = *(int *)((longlong)plVar9 + 4);
      }
      if (0x3f3b < iVar7 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar17 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar17 != 0 &&
            ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
             (*(char *)(lVar17 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x10070a;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            lVar17 = plVar9[1];
            *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100718;
            func_0x(lVar17,5);
            goto LAB_;
          }
          *(undefined8 *)(auStackX_20 + lVar8 + -0x20) = 0;
          *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x10073e;
          (*_DAT_)(1,0x17eff38,0x190fc08,0x87c);
        }
        lVar17 = plVar9[1];
        *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x10074c;
        func_0x(lVar17,5);
      }
    }
LAB_:
    uVar15 = *(uint *)((longlong)plVar9 + 4);
    if ((uVar15 < 9) && (((*(byte *)plVar9[1] & 0xe) == 0 || ((*(byte *)plVar9[1] & 0xe) == 0xc))))
    {
      uVar15 = 9;
    }
    *(undefined4 *)(&stack0x00000038 + lVar8) = *(undefined4 *)(plVar9 + 2);
    *(short *)(&stack0x0000002a + lVar8) = *(short *)((longlong)plVar9 + 2);
    *(undefined4 *)(&stack0x0000002c + lVar8) = *(undefined4 *)((longlong)plVar9 + 4);
    *(short *)(&stack0x00000044 + lVar8) = *(short *)((longlong)plVar9 + 0x1c);
    *(undefined4 *)(&stack0x0000003c + lVar8) = *(undefined4 *)((longlong)plVar9 + 0x14);
    *(undefined4 *)(&stack0x00000040 + lVar8) = *(undefined4 *)(plVar9 + 3);
    *(undefined4 *)(&stack0x0000004e + lVar8) = *(undefined4 *)((longlong)plVar9 + 0x26);
    lVar17 = plVar9[1];
    *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1007b8;
    func_0x(auStack_1fe8,0x1f9e,lVar17,uVar15);
    *(undefined **)(&stack0x00000030 + lVar8) = auStack_1fe8;
    *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1007cb;
    iVar7 = func_0x(&stack0x0000002a + lVar8);
    if (iVar7 != 0) {
      lVar17 = *(longlong *)(&stack0x00000030 + lVar8);
      puVar22 = (ushort *)((ulonglong)*(uint *)(&stack0x0000003c + lVar8) + lVar17);
      uVar15 = *puVar22 - 1;
      if (((&stack0x0000002a)[lVar8] & 1) == 0) {
        uVar15 = (uint)*puVar22;
      }
      if (uVar15 == 1) {
        uVar18 = *(uint *)(&stack0x00000040 + lVar8);
LAB_:
        if ((puVar22[(int)uVar15] & 0x7fff) < uVar18) goto LAB_;
      }
      else {
        uVar18 = puVar22[(longlong)(int)uVar15 + -1] & 0x7fff;
        if (*(uint *)(&stack0x00000040 + lVar8) <= uVar18) goto LAB_;
LAB_:
        *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100826;
        func_0x(lVar17,7);
        lVar17 = *(longlong *)(&stack0x00000030 + lVar8);
      }
      uVar13 = *(ushort *)(&stack0x00000054 + lVar8);
      *(short *)(&stack0x00000052 + lVar8) = (short)uVar18;
      lVar17 = (ulonglong)(uVar18 & 0xffff) + lVar17;
      uVar14 = *(ushort *)(lVar17 + 2);
      if ((uVar14 >> 0xe & 1) == 0) {
        uVar13 = uVar13 & 0xc7ff;
      }
      else {
        uVar13 = uVar13 ^ (uVar13 ^ uVar14) & 0x3800;
      }
      *(ushort *)(&stack0x00000054 + lVar8) = uVar13;
      *(ushort *)(&stack0x00000054 + lVar8) = (uVar13 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar13;
    }
  }
  else if (((*(short *)plVar9 == 0) || ((longlong *)plVar9[2] == (longlong *)0x0)) ||
          (*(longlong *)plVar9[2] == 0)) {
    *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1008c8;
    func_0x(&stack0x0000002a + lVar8,auStack_1fe8,0x1f9e,(short *)((longlong)plVar9 + 2));
    if (*(short *)plVar9 != 0) {
      lVar17 = plVar9[2];
    }
    *(longlong *)(&stack0x00000038 + lVar8) = lVar17;
  }
  else {
    *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1008ae;
    func_0x(&stack0x00000028 + lVar8,auStack_1fe8,0x1f9e,plVar9);
  }
  puVar3 = *(uint **)(param_1 + 0x108);
  if (((*(byte *)(*(longlong *)(**(longlong **)(puVar3 + 8) + 8) + 0x107) & 0x40) == 0) ||
     ((*puVar3 & 0x1000000) != 0)) {
    uVar20 = 0;
  }
  else {
    uVar20 = 1;
  }
  *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x10092f;
  func_0x(param_2,puVar3 + 0x24,uVar20,auStack_2008);
  pcVar4 = *(code **)(*param_2 + 8);
  *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100938;
  (*pcVar4)(param_2);
  uVar2 = *(undefined2 *)(lVar21 + 0x38);
  *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x100950;
  func_0x(&stack0x00000028 + lVar8,lVar21,auStackX_20 + lVar8,uVar2);
  pcVar5 = *(char **)(param_1 + 0x380);
  if ((((pcVar5 == (char *)0x0) || (pcVar5[3] == '\0')) || (*pcVar5 == '\0')) ||
     (uVar19 = 2, pcVar5[1] == '\0')) {
    uVar19 = *(undefined4 *)(param_1 + 0x2f0);
  }
  *(uint *)((longlong)auStackX_18 + lVar8) = **(uint **)(param_1 + 0x108) >> 0x1b & 1;
  *(undefined8 *)((longlong)auStackX_8 + lVar8 + 8) = 0;
  *(undefined8 *)((longlong)auStackX_8 + lVar8) = 0;
  *(undefined **)(auStackX_20 + lVar8 + -0x20) = auStack_2008;
  *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1009b0;
  func_0x(param_2,&stack0x00000028 + lVar8,uVar19,0);
LAB_:
  *(undefined8 *)((longlong)&uStack_28 + lVar8) = 0x1009c7;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffe0 + lVar8));
  return;
}

