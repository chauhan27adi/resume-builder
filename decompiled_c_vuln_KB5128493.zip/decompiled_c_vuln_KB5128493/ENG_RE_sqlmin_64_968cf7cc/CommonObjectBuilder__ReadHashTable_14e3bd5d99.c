
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,int *param_2,longlong *param_3,longlong *param_4,int *param_5,
                 longlong *param_6,int *param_7,int *param_8)

{
  int iVar1;
  int iVar2;
  longlong lVar3;
  int aiStackX_10 [2];
  
  aiStackX_10[0] = 0;
  if (*param_2 != 2) {
    (*_DAT_)(1,0x13b87f0,0x1380f08,0x73,0);
  }
  *param_8 = 0;
  if (param_2[5] != 0) {
    iVar1 = param_2[2];
    iVar2 = param_2[1];
    *param_5 = iVar1 * iVar2;
    lVar3 = (*_DAT_)(iVar1 * iVar2,param_1,0x123cde8,0x7e,5);
    if (*param_4 != lVar3) {
      (*_DAT_)(*param_4,0);
    }
    *param_4 = lVar3;
    (**(code **)(*param_3 + 8))(param_3,lVar3,*param_5,aiStackX_10);
    if (aiStackX_10[0] != *param_5) {
      (*_DAT_)(1,0x13b8758,0x1380f08,0x85,0);
    }
    *param_8 = *param_8 + aiStackX_10[0];
    iVar1 = param_2[6];
    iVar2 = param_2[4];
    *param_7 = iVar1 * iVar2;
    lVar3 = (*_DAT_)(iVar1 * iVar2,param_1,0x123cde8,0x8c,5);
    if (*param_6 != lVar3) {
      (*_DAT_)(*param_6,0);
    }
    *param_6 = lVar3;
    (**(code **)(*param_3 + 8))(param_3,lVar3,*param_7,aiStackX_10);
    if (aiStackX_10[0] != *param_7) {
      (*_DAT_)(1,0x13b8778,0x1380f08,0x92,0);
    }
    *param_8 = *param_8 + aiStackX_10[0];
    return;
  }
  *param_7 = 0;
  *param_5 = 0;
  if (*param_4 != 0) {
    (*_DAT_)(*param_4,0);
  }
  *param_4 = 0;
  if (*param_6 != 0) {
    (*_DAT_)(*param_6,0);
  }
  *param_6 = 0;
  return;
}

