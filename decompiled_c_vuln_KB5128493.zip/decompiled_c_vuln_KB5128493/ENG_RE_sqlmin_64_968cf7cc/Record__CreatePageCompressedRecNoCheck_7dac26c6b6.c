
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,undefined8 param_2,ulonglong param_3,short *param_4)

{
  ushort *puVar1;
  int *piVar2;
  uint *puVar3;
  short sVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  byte bVar11;
  int iVar12;
  longlong lVar13;
  ulonglong *puVar14;
  undefined8 *puVar15;
  undefined4 *puVar16;
  byte bVar17;
  ulonglong uVar18;
  byte *pbVar19;
  ushort uVar20;
  ushort uVar21;
  ushort *puVar22;
  byte **ppbVar23;
  uint uVar24;
  undefined *puVar25;
  ushort uVar26;
  undefined8 *puVar27;
  undefined8 *puVar28;
  ushort uVar29;
  uint uVar30;
  longlong lVar31;
  longlong lVar32;
  longlong lVar33;
  short *psVar34;
  undefined8 *puVar35;
  ushort uVar36;
  ushort uVar37;
  ushort *puVar38;
  longlong unaff_GS_OFFSET;
  undefined8 uStackX_8;
  ushort auStackX_10 [2];
  uint uStackX_14;
  uint auStackX_18 [2];
  undefined4 uStackX_20;
  undefined2 auStackX_24 [2];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  puVar25 = &stack0xffffffffffffffc0 + lVar13;
  puVar3 = (uint *)((longlong)&uStackX_20 + lVar13 + -0x20);
  *(ulonglong *)(&stack0x00002430 + lVar13) = _DAT_ ^ (ulonglong)puVar3;
  pbVar19 = *(byte **)(param_4 + 4);
  puVar22 = (ushort *)(param_4 + 1);
  uVar8 = *(undefined8 *)(&stack0x000024b0 + lVar13);
  *(short **)(&stack0x00000058 + lVar13) = param_1;
  *(short **)(&stack0x00000070 + lVar13) = param_4;
  bVar11 = *pbVar19;
  *(int *)((longlong)&uStackX_14 + lVar13) = (int)param_3;
  *(undefined8 *)((longlong)&uStackX_8 + lVar13) = param_2;
  *(undefined8 *)(&stack0x00000030 + lVar13) = uVar8;
  if ((((bVar11 & 0x1c) - 4 & 0xffffffeb) == 0) && ((bVar11 & 0x1c) != 0x18)) {
    sVar4 = *param_4;
    *param_1 = sVar4;
    if (sVar4 != 0) {
      if (((*param_4 == 0) || (*(longlong **)(param_4 + 8) == (longlong *)0x0)) ||
         (**(longlong **)(param_4 + 8) == 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100830;
        func_0x(param_1 + 1);
        *(undefined8 *)(param_1 + 8) = uVar8;
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10081b;
        func_0x(param_1);
        *(undefined8 *)(param_1 + 8) = uVar8;
        puVar25 = &stack0xffffffffffffffc0 + lVar13;
      }
      goto LAB_;
    }
    puVar1 = (ushort *)(param_1 + 1);
    if (*(int *)(param_4 + 2) == 0) {
      pbVar19 = *(byte **)(param_4 + 4);
      uVar30 = *(uint *)(param_4 + 8);
      uVar18 = (ulonglong)uVar30;
      *puVar22 = 0;
      *(uint *)(param_4 + 10) = uVar30;
      bVar11 = *pbVar19;
      if ((bVar11 & 0x10) != 0) {
        uVar30 = uVar30 + 2 + (*(ushort *)(pbVar19 + uVar18) + 7 >> 3);
        uVar18 = (ulonglong)uVar30;
        *(uint *)(param_4 + 10) = uVar30;
        bVar11 = *pbVar19;
      }
      if ((bVar11 & 0x20) == 0) {
        *(int *)(param_4 + 2) = (int)uVar18;
        param_4[0xe] = 0;
        *(int *)(param_4 + 0xc) = (int)uVar18;
      }
      else {
        puVar38 = (ushort *)(pbVar19 + uVar18);
        uVar20 = *puVar38;
        param_4[0xe] = uVar20;
        if (uVar20 == 0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar31 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar31 != 0 &&
              ((lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0 &&
               (*(char *)(lVar31 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100178;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10019b;
              (*_DAT_)(1,0x9f57b8,0xb15488,0x80f);
            }
          }
          uVar8 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1001a9;
          func_0x(uVar8,3);
          uVar20 = param_4[0xe];
          uVar18 = (ulonglong)*(uint *)(param_4 + 10);
        }
        uVar30 = (int)uVar18 + (uVar20 + 1) * 2;
        *(uint *)(param_4 + 0xc) = uVar30;
        if (0x1f9e < uVar30) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar31 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar31 != 0)) &&
             ((lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0 &&
              (*(char *)(lVar31 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10024f;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100272;
              (*_DAT_)(1,0x9f57b8,0xb15488,0x816);
            }
          }
          uVar8 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100280;
          func_0x(uVar8,4);
          uVar20 = param_4[0xe];
          uVar30 = *(uint *)(param_4 + 0xc);
        }
        uVar18 = (ulonglong)uVar20;
        uVar20 = puVar38[uVar18];
        *(uint *)(param_4 + 2) = uVar20 & 0x7fff;
        if ((uVar20 & 0x7fff) < uVar30) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar31 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar31 != 0 &&
              ((lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0 &&
               (*(char *)(lVar31 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100323;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100346;
              (*_DAT_)(1,0x9f57b8,0xb15488,0x81d);
            }
          }
          uVar8 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100354;
          func_0x(uVar8,4);
          uVar18 = (ulonglong)(ushort)param_4[0xe];
        }
        if ((short)puVar38[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
          do {
            lVar31 = *(longlong *)(param_4 + 4);
            if ((int)uVar18 == 1) {
              uVar30 = *(uint *)(param_4 + 0xc);
              uVar24 = uVar30;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(param_4 + 10) + lVar31 + uVar18 * 2) & 0x7fff) <
                  uVar30) goto LAB_;
            }
            else {
              uVar24 = *(uint *)(param_4 + 0xc);
              uVar30 = *(ushort *)((ulonglong)*(uint *)(param_4 + 10) + lVar31 + -2 + uVar18 * 2) &
                       0x7fff;
              if (uVar24 <= uVar30) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1003c4;
              func_0x(lVar31,7);
              uVar24 = *(uint *)(param_4 + 0xc);
              lVar31 = *(longlong *)(param_4 + 4);
              uVar18 = (ulonglong)(ushort)param_4[0xe];
            }
            if ((uVar30 < uVar24) || (*(uint *)(param_4 + 2) < uVar30)) {
              param_3 = (ulonglong)*(uint *)((longlong)&uStackX_14 + lVar13);
              param_2 = *(undefined8 *)((longlong)&uStackX_8 + lVar13);
              goto LAB_;
            }
            if (*(ushort *)(lVar31 + (ulonglong)uVar30) == 5) {
              *puVar22 = *puVar22 | 2;
              param_4[0xe] = (short)uVar18 + -1;
              param_4[0x15] = (short)uVar30;
              lVar31 = (ulonglong)(uVar30 & 0xffff) + *(longlong *)(param_4 + 4);
              uVar20 = param_4[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar31 + 2) >> 0xe & 1) != 0) {
                uVar20 = *(ushort *)(lVar31 + 2) & 0x3800 | param_4[0x16] & 0xc7ffU;
              }
              param_4[0x16] = uVar20;
              param_4[0x16] = (uVar20 ^ *(ushort *)(lVar31 + 2)) & 0x7ff ^ uVar20;
              uVar18 = (ulonglong)*(uint *)(param_4 + 2);
              pbVar19 = *(byte **)(param_4 + 4);
              goto LAB_;
            }
            if (*(ushort *)(lVar31 + (ulonglong)uVar30) < 0x400) break;
            *puVar22 = *puVar22 | 1;
            uVar20 = (short)uVar18 - 1;
            uVar18 = (ulonglong)uVar20;
            param_4[0xe] = uVar20;
            if ((uVar20 == 0) || (-1 < (short)puVar38[(ulonglong)(uVar20 - 1) + 1])) break;
          } while( true );
        }
        uVar18 = (ulonglong)*(uint *)(param_4 + 2);
        pbVar19 = *(byte **)(param_4 + 4);
      }
LAB_:
      iVar12 = 0;
      if ((*pbVar19 & 0x40) == 0) {
        *(undefined4 *)(param_4 + 0x13) = 0;
      }
      else {
        *(int *)(param_4 + 0x13) = *(int *)(param_4 + 2);
        *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1004d1;
        puVar14 = (ulonglong *)func_0x(puVar22);
        uVar26 = (ushort)(*puVar14 >> 0x30);
        uVar20 = uVar26;
        if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
          uVar20 = uVar26 & 0xdfff;
          if ((uVar26 >> 0xe & 1) != 0) {
            uVar20 = uVar26 | 0x2000;
          }
        }
        if (uVar20 == 0xfffc) {
          iVar12 = (int)((*puVar14 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + iVar12;
        uVar18 = (ulonglong)*(uint *)(param_4 + 2);
        pbVar19 = *(byte **)(param_4 + 4);
      }
      iVar12 = (int)uVar18;
      if ((*(byte **)(param_4 + 0xf) != (byte *)0x0) &&
         (*(byte **)(param_4 + 0xf) < pbVar19 + uVar18)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar31 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar31 != 0 &&
             (lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0)) &&
            (*(char *)(lVar31 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1005d5;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1005f8;
            (*_DAT_)(1,0x9f57b8,0xb15488,0x877);
          }
        }
        uVar8 = *(undefined8 *)(param_4 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100606;
        func_0x(uVar8,0x12);
        iVar12 = *(int *)(param_4 + 2);
      }
      if (0x3f3b < iVar12 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar31 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar31 != 0 &&
            ((lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0 &&
             (*(char *)(lVar31 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100694;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1006b7;
            (*_DAT_)(1,0x9f57b8,0xb15488,0x87c);
          }
        }
        uVar8 = *(undefined8 *)(param_4 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1006c5;
        func_0x(uVar8,5);
      }
      param_2 = *(undefined8 *)((longlong)&uStackX_8 + lVar13);
      param_3 = (ulonglong)*(uint *)((longlong)&uStackX_14 + lVar13);
    }
LAB_:
    uVar30 = *(uint *)(param_4 + 2);
    if ((uVar30 < 9) &&
       (((**(byte **)(param_4 + 4) & 0xe) == 0 || ((**(byte **)(param_4 + 4) & 0xe) == 0xc)))) {
      uVar30 = 9;
    }
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_4 + 8);
    *puVar1 = *puVar22;
    *(undefined4 *)(param_1 + 2) = *(undefined4 *)(param_4 + 2);
    param_1[0xe] = param_4[0xe];
    *(undefined4 *)(param_1 + 10) = *(undefined4 *)(param_4 + 10);
    *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_4 + 0xc);
    *(undefined4 *)(param_1 + 0x13) = *(undefined4 *)(param_4 + 0x13);
    uVar8 = *(undefined8 *)(param_4 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10074a;
    func_0x(param_2,param_3 & 0xffffffff,uVar8,uVar30);
    *(undefined8 *)(param_1 + 4) = param_2;
    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100756;
    iVar12 = func_0x(puVar1);
    puVar25 = &stack0xffffffffffffffc0 + lVar13;
    if (iVar12 == 0) goto LAB_;
    lVar31 = *(longlong *)(param_1 + 4);
    puVar22 = (ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar31);
    uVar30 = *puVar22 - 1;
    if ((*(byte *)puVar1 & 1) == 0) {
      uVar30 = (uint)*puVar22;
    }
    if (uVar30 == 1) {
      uVar24 = *(uint *)(param_1 + 0xc);
LAB_:
      if ((puVar22[(int)uVar30] & 0x7fff) < uVar24) goto LAB_;
    }
    else {
      uVar24 = puVar22[(longlong)(int)uVar30 + -1] & 0x7fff;
      if (*(uint *)(param_1 + 0xc) <= uVar24) goto LAB_;
LAB_:
      *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1007af;
      func_0x(lVar31,7);
    }
    param_1[0x15] = (short)uVar24;
    lVar31 = (ulonglong)(uVar24 & 0xffff) + *(longlong *)(param_1 + 4);
    uVar20 = param_1[0x16] & 0xc7ffU;
    if ((*(ushort *)(lVar31 + 2) >> 0xe & 1) != 0) {
      uVar20 = *(ushort *)(lVar31 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
    }
    param_1[0x16] = uVar20;
    param_1[0x16] = (uVar20 ^ *(ushort *)(lVar31 + 2)) & 0x7ff ^ uVar20;
    puVar25 = &stack0xffffffffffffffc0 + lVar13;
  }
  else {
    puVar28 = (undefined8 *)0x0;
    *param_1 = 1;
    uVar20 = *puVar22;
    uVar30 = (uint)uVar20;
    *(undefined4 *)((longlong)auStackX_18 + lVar13 + 4) = 0;
    *(uint *)(&stack0x00000060 + lVar13) = (uint)uVar20;
    uVar18 = (ulonglong)uVar20 * 0x20 + 0xf;
    if (uVar18 <= (ulonglong)uVar20 * 0x20) {
      uVar18 = 0xffffffffffffff0;
    }
    uVar18 = uVar18 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100871;
    func_0x();
    lVar31 = -uVar18;
    puVar25 = (undefined *)((longlong)&uStackX_20 + lVar31 + lVar13 + -0x20);
    *(longlong *)(&stack0x00000068 + lVar13) = (longlong)&uStackX_20 + lVar31 + lVar13 + -0x20;
    *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x10088e;
    func_0x((longlong)&uStackX_20 + lVar31 + lVar13 + -0x20,0,uVar30 << 5);
    uVar8 = *(undefined8 *)((longlong)&uStackX_8 + lVar13);
    uVar20 = *puVar22;
    *(ulonglong *)(&stack0x00000050 + lVar13) =
         (ulonglong)(ushort)param_4[0xe] + (ulonglong)(ushort)param_4[0xd] +
         *(longlong *)(param_4 + 4);
    uVar26 = 0;
    *(undefined2 *)((longlong)auStackX_10 + lVar13) = 0;
    *(short **)(&stack0x00000080 + lVar13) = param_1 + 1;
    *(uint *)(&stack0xffffffffffffffe0 + lVar31 + lVar13) = (uint)uVar20;
    *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x1008c6;
    func_0x(param_1 + 1,uVar8);
    uVar20 = *(ushort *)(&stack0x00000046 + lVar13);
    if (*(int *)(param_4 + 2) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x1008df;
      func_0x(puVar22);
    }
    puVar35 = (undefined8 *)(&stack0x00000090 + lVar13);
    *(ushort *)(&stack0x00000038 + lVar13) = *puVar22;
    uVar37 = 0;
    *(undefined4 *)(&stack0x00000040 + lVar13) = 0;
    *(undefined8 *)(&stack0x00000048 + lVar13) = 0;
    *(ushort *)(&stack0x00000046 + lVar13) = uVar20 & 0xffe0;
    psVar34 = param_4;
    while (uVar37 != *(ushort *)(&stack0x00000038 + lVar13)) {
      uVar37 = uVar37 + 1;
      *(ushort *)(&stack0x0000003a + lVar13) = uVar37;
      *(int *)(&stack0x00000040 + lVar13) = (int)(short)(*(short *)(&stack0x00000040 + lVar13) + -1)
      ;
      *(ushort *)(&stack0x00000044 + lVar13) = uVar37;
      *puVar3 = 0;
      puVar27 = puVar28;
      puVar15 = puVar28;
      if (uVar37 <= *puVar22) {
        uVar37 = *(ushort *)(&stack0x0000003a + lVar13);
        lVar32 = *(longlong *)(param_4 + 4);
        uVar30 = uVar37 - 1;
        if ((int)uVar30 < 0) {
          uVar30 = (uint)uVar37;
        }
        bVar11 = *(byte *)((ulonglong)(ushort)param_4[0xc] + ((int)uVar30 >> 1) + lVar32);
        bVar17 = bVar11 >> 4;
        if (((&stack0x0000003a)[lVar13] & 1) != 0) {
          bVar17 = bVar11 & 0xf;
        }
        switch(bVar17) {
        case 0:
          break;
        case 1:
          puVar27 = (undefined8 *)0x0;
          puVar15 = (undefined8 *)0x1344c86;
          break;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
          puVar15 = *(undefined8 **)(&stack0x00000050 + lVar13);
          puVar27 = (undefined8 *)(ulonglong)*(ushort *)((ulonglong)bVar17 * 4 + 0x81ecf0);
          uVar37 = *(ushort *)(&stack0x0000003a + lVar13);
          *(byte **)(&stack0x00000050 + lVar13) = (byte *)((longlong)puVar15 + (longlong)puVar27);
          break;
        case 10:
          if (*(int *)(param_4 + 2) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x1009bc;
            func_0x(puVar22);
            lVar32 = *(longlong *)(param_4 + 4);
          }
          uVar20 = *(ushort *)((longlong)auStackX_10 + lVar13);
          uVar21 = param_4[0xf];
          *(ushort *)((longlong)auStackX_10 + lVar13) = uVar20 + 1;
          uVar18 = 0;
          lVar33 = (ulonglong)uVar21 + 1 + lVar32;
          uVar29 = *(ushort *)(lVar33 + 2 + (ulonglong)uVar20 * 2);
          uVar36 = uVar29 & 0x7fff;
          if (uVar20 != 0) {
            uVar21 = psVar34[0xf];
            lVar32 = *(longlong *)(psVar34 + 4);
            uVar18 = (ulonglong)(*(ushort *)(lVar33 + 2 + (ulonglong)(uVar20 - 1) * 2) & 0x7fff);
            uVar29 = *(ushort *)(lVar33 + (ulonglong)uVar20 * 2 + 2);
            uVar37 = *(ushort *)(&stack0x0000003a + lVar13);
          }
          puVar27 = (undefined8 *)(ulonglong)((uint)uVar36 - (int)uVar18);
          puVar15 = (undefined8 *)
                    ((ulonglong)uVar21 + uVar18 + lVar32 + (ulonglong)(ushort)param_4[0x12]);
          if ((short)uVar29 < 0) {
            *puVar3 = 1;
          }
          break;
        case 0xb:
          *puVar3 = 2;
          puVar27 = (undefined8 *)0x0;
          puVar15 = (undefined8 *)0x77a1f4;
          break;
        case 0xc:
          puVar15 = *(undefined8 **)(&stack0x00000050 + lVar13);
          *puVar3 = 4;
          *(byte **)(&stack0x00000050 + lVar13) = (byte *)((longlong)puVar15 + 1);
          puVar27 = (undefined8 *)0x1;
          break;
        default:
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar31 + lVar13) = 0x771c98;
          *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100ad9;
          (*_DAT_)(1,0xb76af0,0xb7cf10,0x11e5);
          puVar27 = (undefined8 *)0x0;
        }
      }
      uVar30 = *puVar3 & 1;
      *(uint *)(&stack0x00000028 + lVar13) = uVar30;
      uVar24 = (uint)puVar27;
      if (uVar30 == 0) {
        *puVar3 = *puVar3 & 0xfffffffb;
        if ((puVar15 == (undefined8 *)0x0) || (puVar15 == (undefined8 *)0x77a1f4)) {
          *(undefined4 *)((longlong)auStackX_18 + lVar13) = 0;
        }
        else {
          iVar12 = *(int *)((longlong)auStackX_18 + lVar13 + 4);
          *(uint **)(&stack0xfffffffffffffff8 + lVar31 + lVar13) = puVar3;
          *(longlong *)(&stack0xfffffffffffffff0 + lVar31 + lVar13) = (longlong)auStackX_18 + lVar13
          ;
          uVar8 = *(undefined8 *)(&stack0x00000030 + lVar13);
          *(int *)(&stack0xffffffffffffffe8 + lVar31 + lVar13) = 0x239e - iVar12;
          *(undefined8 **)(&stack0xffffffffffffffe0 + lVar31 + lVar13) = puVar35;
          *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100b3a;
          puVar15 = (undefined8 *)
                    func_0x(uVar8,&stack0x00000040 + lVar13,puVar15,puVar27);
          if (puVar15 != (undefined8 *)0x0) {
            uVar30 = *(uint *)(&stack0x00000028 + lVar13);
            if (puVar15 == puVar35) {
              uVar24 = *(uint *)((longlong)auStackX_18 + lVar13);
              piVar2 = (int *)((longlong)auStackX_18 + lVar13 + 4);
              *piVar2 = *piVar2 + uVar24;
              puVar35 = (undefined8 *)((longlong)puVar35 + (ulonglong)uVar24);
            }
            else {
              uVar24 = *(uint *)((longlong)auStackX_18 + lVar13);
            }
            goto LAB_;
          }
        }
        puVar25 = *(undefined **)(&stack0x00000068 + lVar13);
        psVar34 = *(short **)(&stack0x00000070 + lVar13);
        *(uint *)(puVar25 + (ulonglong)(ushort)(uVar37 - 1) * 0x20 + 0xc) =
             *(uint *)(puVar25 + (ulonglong)(ushort)(uVar37 - 1) * 0x20 + 0xc) | 2;
      }
      else {
        *(uint *)((longlong)auStackX_18 + lVar13) = uVar24;
LAB_:
        uVar5 = *puVar3;
        uVar6 = *(undefined4 *)(&stack0x00000040 + lVar13);
        uVar7 = *(undefined4 *)(&stack0x00000044 + lVar13);
        uVar9 = *(undefined4 *)(&stack0x00000048 + lVar13);
        uVar10 = *(undefined4 *)(&stack0x0000004c + lVar13);
        psVar34 = *(short **)(&stack0x00000070 + lVar13);
        ppbVar23 = (byte **)((ulonglong)(ushort)(uVar37 - 1) * 0x20 +
                            *(longlong *)(&stack0x00000068 + lVar13));
        *ppbVar23 = (byte *)puVar15;
        puVar25 = *(undefined **)(&stack0x00000068 + lVar13);
        *(uint *)(ppbVar23 + 1) = uVar24;
        *(uint *)((longlong)ppbVar23 + 0xc) =
             (uVar5 >> 2 & 1) << 2 | *(uint *)((longlong)ppbVar23 + 0xc) & 0xfffffff0 |
             uVar30 & 0xfffffff1;
        *(undefined4 *)(ppbVar23 + 2) = uVar6;
        *(undefined4 *)((longlong)ppbVar23 + 0x14) = uVar7;
        *(undefined4 *)(ppbVar23 + 3) = uVar9;
        *(undefined4 *)((longlong)ppbVar23 + 0x1c) = uVar10;
      }
    }
    uVar6 = *(undefined4 *)((longlong)&uStackX_14 + lVar13);
    lVar32 = *(longlong *)(&stack0x00000080 + lVar13);
    uVar7 = *(undefined4 *)(&stack0x00000060 + lVar13);
    *(undefined **)(&stack0xffffffffffffffe8 + lVar31 + lVar13) = &stack0x00000078 + lVar13;
    *(undefined **)(&stack0xffffffffffffffe0 + lVar31 + lVar13) = puVar25;
    *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100be8;
    func_0x(lVar32,uVar6,uVar6,uVar7);
    pbVar19 = *(byte **)(param_4 + 4);
    if (((*pbVar19 & 0x1c) - 0x10 & 0xfffffffb) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100c04;
      puVar35 = (undefined8 *)func_0x(puVar22);
      if (puVar35 == (undefined8 *)0x0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100c1d;
        (*_DAT_)(6,0x55,0x10,3);
        *(undefined8 *)(&stack0x00000028 + lVar13) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100c29;
        puVar16 = (undefined4 *)(*_DAT_)();
        *puVar16 = 0x16;
        *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100c35;
        (*_DAT_)();
      }
      else {
        *(undefined8 *)(&stack0x00000028 + lVar13) = *puVar35;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100c4a;
      func_0x(lVar32,&stack0x00000028 + lVar13);
      pbVar19 = *(byte **)(param_4 + 4);
    }
    if ((*pbVar19 & 2) != 0) {
      if (*(int *)(param_4 + 2) == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100c64;
        func_0x(puVar22);
      }
      *(undefined8 *)((longlong)&uStackX_8 + lVar13) = 0;
      uVar20 = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100c77;
      func_0x(puVar22);
      if (((**(byte **)(param_4 + 4) & 2) != 0) &&
         (puVar35 = (undefined8 *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 0x18)),
         puVar35 != (undefined8 *)0x0)) {
        uVar8 = *puVar35;
        *(int *)((longlong)&uStackX_8 + lVar13) = (int)uVar8;
        uVar20 = (ushort)((ulonglong)uVar8 >> 0x30);
        *(ushort *)((longlong)auStackX_10 + lVar13 + -2) = uVar20;
        uVar26 = (ushort)((ulonglong)uVar8 >> 0x20);
        *(ushort *)((longlong)auStackX_10 + lVar13 + -4) = uVar26;
      }
      if (*(int *)(param_4 + 2) == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100caf;
        func_0x(puVar22);
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100cb7;
      func_0x(puVar22);
      if (((**(byte **)(param_4 + 4) & 2) == 0) ||
         (pbVar19 = *(byte **)(param_4 + 4) + *(uint *)(param_4 + 0x18), pbVar19 == (byte *)0x0)) {
        *(undefined4 *)((longlong)&uStackX_20 + lVar13) = 0;
        *(undefined2 *)((longlong)auStackX_24 + lVar13) = 0;
      }
      else {
        *(undefined4 *)((longlong)&uStackX_20 + lVar13) = *(undefined4 *)(pbVar19 + 8);
        *(undefined2 *)((longlong)auStackX_24 + lVar13) = *(undefined2 *)(pbVar19 + 0xc);
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100ceb;
      func_0x(lVar32,(longlong)&uStackX_20 + lVar13);
      uVar37 = uVar20;
      if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
        uVar37 = uVar20 & 0xdfff;
        if ((uVar20 >> 0xe & 1) != 0) {
          uVar37 = uVar20 | 0x2000;
        }
      }
      if ((uVar37 == 0xfffc) && (0x1f < uVar26)) {
        pbVar19 = *(byte **)(param_4 + 4);
        if ((*pbVar19 & 2) != 0) {
          if (*(int *)(param_4 + 2) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100d41;
            func_0x(puVar22);
            pbVar19 = *(byte **)(psVar34 + 4);
          }
          puVar28 = (undefined8 *)(pbVar19 + (ulonglong)*(uint *)(param_4 + 0x18) + 0xe);
        }
        if (*(int *)(lVar32 + 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100d63;
          func_0x(lVar32);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100d6b;
        func_0x(lVar32);
        pbVar19 = *(byte **)(lVar32 + 6);
        if ((*pbVar19 & 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100d98;
          func_0x(0,(longlong)&uStackX_8 + lVar13,puVar28);
        }
        else {
          uVar30 = *(uint *)(lVar32 + 0x2e);
          *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100d87;
          func_0x(pbVar19 + uVar30,(longlong)&uStackX_8 + lVar13,puVar28);
        }
      }
      else {
        if (*(int *)(lVar32 + 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100da8;
          func_0x(lVar32);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100db0;
        func_0x(lVar32);
        if ((**(byte **)(lVar32 + 6) & 2) != 0) {
          puVar28 = (undefined8 *)(*(byte **)(lVar32 + 6) + *(uint *)(lVar32 + 0x2e));
        }
        *puVar28 = *(undefined8 *)((longlong)&uStackX_8 + lVar13);
      }
      *(undefined4 *)(lVar32 + 2) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100dd8;
      func_0x(lVar32);
    }
    puVar25 = &stack0xffffffffffffffc0 + lVar31 + lVar13;
    if (((**(byte **)(param_4 + 4) & 0x1c) - 4 & 0xffffffe7) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar31 + lVar13) = 0x100df5;
      func_0x(lVar32);
      puVar25 = &stack0xffffffffffffffc0 + lVar31 + lVar13;
    }
  }
LAB_:
  *(undefined8 *)(*(longlong *)(&stack0x00000058 + lVar13) + 0x10) =
       *(undefined8 *)(&stack0x00000030 + lVar13);
LAB_:
  uVar18 = *(ulonglong *)(&stack0x00002430 + lVar13);
  *(undefined8 *)(puVar25 + -8) = 0x100e10;
  func_0x(uVar18 ^ (ulonglong)puVar3);
  return;
}

