
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,longlong **param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  longlong lVar4;
  longlong *plVar5;
  byte **ppbVar6;
  longlong lVar7;
  longlong **pplVar8;
  longlong **pplVar9;
  char cVar10;
  ushort uVar11;
  int iVar12;
  longlong lVar13;
  ulonglong *puVar14;
  short *psVar15;
  ushort uVar16;
  undefined4 uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  int iVar22;
  ushort *puVar23;
  byte **ppbVar24;
  uint *puVar25;
  byte **ppbVar26;
  uint *puVar27;
  short sVar28;
  byte **ppbVar29;
  ulonglong uVar30;
  longlong unaff_GS_OFFSET;
  undefined auStack_1d8 [32];
  undefined8 uStack_1b8;
  undefined4 uStack_1b0;
  uint *puStack_1a8;
  uint uStack_1a0;
  uint auStack_198 [2];
  byte **ppbStack_190;
  uint uStack_188;
  uint uStack_184;
  longlong lStack_180;
  undefined8 uStack_178;
  undefined2 uStack_170;
  undefined4 uStack_168;
  undefined2 uStack_164;
  undefined4 uStack_160;
  undefined2 uStack_15c;
  longlong lStack_158;
  longlong lStack_150;
  undefined4 uStack_148;
  undefined8 uStack_140;
  undefined uStack_138;
  undefined4 uStack_134;
  undefined auStack_128 [4];
  undefined auStack_124 [4];
  undefined auStack_120 [4];
  undefined auStack_11c [4];
  undefined auStack_118 [4];
  undefined auStack_114 [4];
  longlong **pplStack_110;
  longlong **pplStack_108;
  undefined8 uStack_100;
  short sStack_f8;
  ushort uStack_f6;
  uint uStack_f4;
  byte **ppbStack_f0;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  ushort uStack_dc;
  undefined2 uStack_da;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined2 uStack_ce;
  ushort uStack_cc;
  undefined2 uStack_ca;
  undefined4 uStack_c8;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined8 uStack_88;
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [16];
  undefined8 uStack_50;
  uint auStack_48 [2];
  ulonglong uStack_40;
  
  uStack_100 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_1d8;
  lStack_180 = **param_2;
  lStack_158 = **param_3;
  ppbStack_190 = *(byte ***)(param_1 + 0x28);
  lStack_150 = param_1;
  pplStack_110 = param_2;
  pplStack_108 = param_3;
  if (((*(char *)(lStack_180 + 2) < '\0') || (*(char *)(lStack_158 + 2) < '\0')) ||
     (uVar11 = (short)(1 << ((byte)*(undefined2 *)(lStack_180 + 4) & 2)) - 1,
     *(ushort *)(lStack_180 + 0x1c) <
     (ushort)((uVar11 - *(short *)(lStack_158 + 0x1c)) + 0x1fa0 & ~uVar11))) {
    uStack_140 = 0;
    uStack_138 = 0;
    uStack_134 = 0;
    *(undefined4 *)(param_1 + 0xf54) = *(undefined4 *)(lStack_158 + 0x20);
    *(undefined2 *)(param_1 + 0xf58) = *(undefined2 *)(lStack_158 + 0x24);
    *(undefined4 *)(param_1 + 0xf5c) = *(undefined4 *)(lStack_180 + 0x20);
    *(undefined2 *)(param_1 + 0xf60) = *(undefined2 *)(lStack_180 + 0x24);
    func_0x(param_1,param_2,param_3,&uStack_140);
    if (*param_3 != (longlong *)0x0) {
      if (((*(ushort *)((longlong)*param_3 + 0x62) & 0x400) == 0) ||
         (*(short *)((longlong)param_3 + 0xc) < 3)) {
        iVar22 = (int)*(short *)((longlong)param_3 + 0xc);
        plVar5 = *param_3;
        if (((byte)*(undefined2 *)((longlong)plVar5 + 0x62) >> 3 & 1) != 0) {
          if (iVar22 == 3) {
            iVar22 = 4;
          }
          else if (iVar22 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plVar5 + 100) & 8) != 0) &&
              (lVar13 = plVar5[0x12], lVar13 != 0)) && (*(longlong *)(lVar13 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar13 + 0x758),plVar5,iVar22);
          }
        }
LAB_:
        if ((((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
             (2 < iVar22)) &&
            (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0)))) &&
           (iVar12 = (*_DAT_)(*plVar5,0x2000,2,auStack_118), iVar12 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar5 + 0x13,iVar22);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar5,0,iVar22);
        }
        *(undefined2 *)((longlong)param_3 + 0xc) = 0;
        *param_3 = (longlong *)0x0;
      }
      else {
        func_0x(param_3);
      }
    }
    if (*param_2 != (longlong *)0x0) {
      if (((*(ushort *)((longlong)*param_2 + 0x62) & 0x400) == 0) ||
         (*(short *)((longlong)param_2 + 0xc) < 3)) {
        iVar22 = (int)*(short *)((longlong)param_2 + 0xc);
        plVar5 = *param_2;
        if (((byte)*(undefined2 *)((longlong)plVar5 + 0x62) >> 3 & 1) != 0) {
          if (iVar22 == 3) {
            iVar22 = 4;
          }
          else if (iVar22 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plVar5 + 100) & 8) != 0) &&
              (lVar13 = plVar5[0x12], lVar13 != 0)) && (*(longlong *)(lVar13 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar13 + 0x758),plVar5,iVar22);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
            ((2 < iVar22 &&
             (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0))))))
           && (iVar12 = (*_DAT_)(*plVar5,0x2000,2,auStack_114), iVar12 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar5 + 0x13,iVar22);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar5,0,iVar22);
        }
        *(undefined2 *)((longlong)param_2 + 0xc) = 0;
        *param_2 = (longlong *)0x0;
      }
      else {
        func_0x(param_2);
      }
    }
    func_0x(&uStack_140);
    goto LAB_;
  }
  uVar20 = 0;
  uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
  if ((*(char *)(lStack_158 + 1) != '\x01') &&
     (((*(char *)(lStack_158 + 1) != '\x02' || (*(char *)(lStack_158 + 3) != '\0')) ||
      (uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0), *(ushort *)(lStack_158 + 6) < 2)
      ))) {
    uStack_da = 0;
    uStack_d8 = 0;
    uStack_ce = 0;
    uStack_cc = 0;
    uStack_ca = 0;
    uStack_e8 = (byte **)0x0;
    iStack_c4 = 0;
    uVar18 = (uint)*(ushort *)(lStack_158 + 0xe);
    ppbStack_f0 = (byte **)((ulonglong)*(ushort *)(lStack_158 + 0x1ffe) + lStack_158);
    sVar28 = 3;
    if ((*(byte *)ppbStack_f0 & 1) == 0) {
      sStack_f8 = 0;
      uStack_f4 = 0;
      uStack_d2 = 0;
      uStack_d0 = 0;
      switch(*(byte *)ppbStack_f0 & 0xe) {
      default:
        uVar18 = (uint)*(ushort *)((longlong)ppbStack_f0 + 2);
        if (0x1f9d < *(ushort *)((longlong)ppbStack_f0 + 2) - 1) {
          func_0x(ppbStack_f0,6);
        }
        break;
      case 4:
        uVar18 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar18 = 1;
      }
      uStack_e8 = (byte **)CONCAT44(uStack_e8._4_4_,uVar18);
      uStack_da = (undefined2)(lStack_158 + 0x2000);
      uStack_d8 = (undefined6)((ulonglong)(lStack_158 + 0x2000) >> 0x10);
    }
    else {
      sStack_f8 = 1;
      bVar3 = *(byte *)ppbStack_f0;
      switch(bVar3 & 0x1c) {
      default:
        if ((char)*(byte *)((longlong)ppbStack_f0 + 1) < '\0') {
          uStack_f6 = (*(ushort *)((longlong)ppbStack_f0 + 1) & 0x7f) << 8 |
                      *(ushort *)((longlong)ppbStack_f0 + 1) >> 8;
          uStack_e0._0_2_ = 3;
        }
        else {
          uStack_f6 = (ushort)*(byte *)((longlong)ppbStack_f0 + 1);
          uStack_e0._0_2_ = 2;
          sVar28 = 2;
        }
        uStack_dc = (short)(uStack_f6 + 1 >> 1) + sVar28;
        if (uStack_f6 < 0x1f) {
          uStack_e0._2_2_ = 0;
          uStack_f4 = 0;
          uStack_c8 = 0;
        }
        else {
          iVar22 = uStack_f6 - 1;
          uStack_e0._2_2_ =
               ((short)(iVar22 / 0x1e) + (short)(iVar22 >> 0x1f)) -
               (short)((longlong)iVar22 * 0x88888889 >> 0x3f);
          uStack_f4 = 0;
          uStack_c8 = 0;
        }
        break;
      case 4:
        if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
          uStack_e0._0_2_ = 0;
          uStack_e0._2_2_ = 0;
          uStack_dc = 0;
          uStack_f6 = 0;
          uStack_d2 = 0;
          uStack_f4 = 0xf;
          uStack_c8 = 1;
        }
        else {
          uStack_e0._0_2_ = 0;
          uStack_e0._2_2_ = 0;
          uStack_dc = 0;
          uStack_f6 = 0;
          uStack_d2 = 0;
          uStack_f4 = 1;
          uStack_c8 = 0;
        }
        break;
      case 8:
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_f6 = 0;
        uStack_d2 = 0;
        uStack_f4 = 9;
        uStack_c8 = 0;
      }
      uStack_d8 = 0;
      uStack_da = 0;
      lVar13 = lStack_158 + 0x2000;
      uStack_d0 = (undefined2)lVar13;
      uStack_ce = (undefined2)((ulonglong)lVar13 >> 0x10);
      uStack_cc = (ushort)((ulonglong)lVar13 >> 0x20);
      uStack_ca = (undefined2)((ulonglong)lVar13 >> 0x30);
      uStack_e8 = (byte **)0x0;
      uVar18 = uVar20;
    }
    ppbVar29 = ppbStack_190;
    ppbVar26 = ppbStack_190 + 0x42;
    uVar19 = 0;
    if (sStack_f8 == 0) {
      uVar21 = *(uint *)ppbVar26;
      if ((uVar21 & 0xc0000000) == 0x80000000) {
        iVar22 = func_0x(&uStack_f6);
        if (iVar22 == 0) {
code_r0x00100b8e:
          puVar25 = (uint *)0x0;
          auStack_198[0] = 0;
          uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
        }
        else {
          puVar25 = (uint *)func_0x(&uStack_ce,ppbVar26,auStack_198,auStack_128);
          uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
        }
      }
      else {
        uVar11 = *(ushort *)((longlong)ppbStack_190 + 0x216);
        if ((uVar11 & 0x10) != 0) {
          if ((*(byte *)ppbStack_f0 & 0x10) == 0) {
            if ((1 << (*(byte *)ppbStack_f0 & 0xe) & 0x1105U) == 0) goto code_r0x00100365;
          }
          else if (((int)uVar21 < (int)uVar18) &&
                  (*(ushort *)((longlong)ppbStack_190 + 0x214) <=
                   *(ushort *)((ulonglong)uVar18 + (longlong)ppbStack_f0))) goto code_r0x00100365;
          goto code_r0x001003b8;
        }
code_r0x00100365:
        if ((int)uVar21 < 0) {
          puVar25 = (uint *)ppbStack_f0;
          if (uStack_f4 == 0) {
            uStack_f6 = 0;
            uVar30 = (ulonglong)uStack_e8 & 0xffffffff;
            uVar18 = (uint)uStack_e8;
            if ((*(byte *)ppbStack_f0 & 0x10) != 0) {
              uVar18 = (uint)uStack_e8 + 2 + (*(ushort *)(uVar30 + (longlong)ppbStack_f0) + 7 >> 3);
              uVar30 = (ulonglong)uVar18;
            }
            uStack_e8 = (byte **)CONCAT44(uVar18,(uint)uStack_e8);
            uVar18 = (uint)uVar30;
            if ((*(byte *)ppbStack_f0 & 0x20) == 0) {
              uStack_dc = 0;
              uStack_f4 = uVar18;
            }
            else {
              puVar23 = (ushort *)(uVar30 + (longlong)ppbStack_f0);
              uStack_dc = *puVar23;
              if (uStack_dc == 0) {
                if ((((cRam00000000019a204b != '\0') || ((bRam00000000019b2950 & 1) != 0)) &&
                    (lVar13 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                               (ulonglong)*puRam0000000000f108e0), lVar13 != 0)) &&
                   ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                    (*(char *)(lVar13 + 0x499) != '\0')))) {
                  if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                    (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_1b8 = (uint *)0x0;
                    (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x80f);
                  }
                }
                func_0x(ppbStack_f0,3);
              }
              uStack_e0 = uStack_e8._4_4_ + (uStack_dc + 1) * 2;
              if (0x1f9e < uStack_e0) {
                if (((cRam00000000019a204b != '\0') || ((bRam00000000019b2950 & 1) != 0)) &&
                   ((lVar13 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                               (ulonglong)*puRam0000000000f108e0), lVar13 != 0 &&
                    ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                     (*(char *)(lVar13 + 0x499) != '\0')))))) {
                  if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                    (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_1b8 = (uint *)0x0;
                    (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x816);
                  }
                }
                func_0x(ppbStack_f0,4);
              }
              uStack_f4 = puVar23[uStack_dc] & 0x7fff;
              if (uStack_f4 < uStack_e0) {
                if ((((cRam00000000019a204b != '\0') || ((bRam00000000019b2950 & 1) != 0)) &&
                    (lVar13 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                               (ulonglong)*puRam0000000000f108e0), lVar13 != 0)) &&
                   ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                    (*(char *)(lVar13 + 0x499) != '\0')))) {
                  if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                    (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_1b8 = (uint *)0x0;
                    (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x81d);
                  }
                }
                func_0x(ppbStack_f0,4);
              }
              uVar30 = (ulonglong)uStack_f4;
              puVar25 = (uint *)ppbStack_f0;
              do {
                uVar18 = uStack_e0;
                if (-1 < (short)puVar23[(ulonglong)(uStack_dc - 1) + 1]) break;
                uVar21 = uStack_e0;
                if (((uStack_dc != 1) &&
                    (uVar21 = *(ushort *)
                               ((longlong)puVar25 +
                               (ulonglong)uStack_dc * 2 + (((ulonglong)uStack_e8 >> 0x20) - 2)) &
                              0x7fff, uVar21 < uStack_e0)) ||
                   ((*(ushort *)
                      ((longlong)puVar25 + (ulonglong)uStack_dc * 2 + ((ulonglong)uStack_e8 >> 0x20)
                      ) & 0x7fff) < uVar21)) {
                  func_0x(puVar25,7);
                  uVar30 = (ulonglong)uStack_f4;
                  puVar25 = (uint *)ppbStack_f0;
                }
                if ((uVar21 < uStack_e0) || ((uint)uVar30 < uVar21)) goto code_r0x001009fc;
                uVar18 = uStack_e0;
                if (*(ushort *)((ulonglong)uVar21 + (longlong)puVar25) == 5) {
                  uStack_f6 = uStack_f6 | 2;
                  uStack_dc = uStack_dc - 1;
                  uStack_ce = (undefined2)uVar21;
                  uVar11 = *(ushort *)((ulonglong)(uVar21 & 0xffff) + 2 + (longlong)puVar25);
                  if ((uVar11 & 0x4000) == 0) {
                    uStack_cc = uStack_cc & 0xc7ff;
                  }
                  else {
                    uStack_cc = uStack_cc ^ (uStack_cc ^ uVar11) & 0x3800;
                  }
                  uStack_cc = (uStack_cc ^
                              *(ushort *)((ulonglong)(uVar21 & 0xffff) + 2 + (longlong)puVar25)) &
                              0x7ff ^ uStack_cc;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar21 + (longlong)puVar25) < 0x400) break;
                uStack_f6 = uStack_f6 | 1;
                uStack_dc = uStack_dc - 1;
              } while (uStack_dc != 0);
            }
            if ((*(byte *)puVar25 & 0x40) == 0) {
              uStack_d2 = 0;
              uStack_d0 = 0;
            }
            else {
              uStack_d2 = (undefined2)uVar30;
              uStack_d0 = (undefined2)(uVar30 >> 0x10);
              uStack_f4 = (int)uVar30 + 0xe;
              uStack_e0 = uVar18;
              puVar14 = (ulonglong *)func_0x(&uStack_f6);
              uVar30 = *puVar14;
              uVar16 = (ushort)(uVar30 >> 0x30);
              uVar11 = uVar16;
              if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
                uVar11 = uVar16 & 0xdfff;
                if ((uVar30 & 0x4000000000000000) != 0) {
                  uVar11 = uVar16 | 0x2000;
                }
              }
              uVar18 = uVar19;
              if (uVar11 == 0xfffc) {
                uVar18 = (uint)((uVar30 >> 0x20 & 0xffff) >> 5);
              }
              uStack_f4 = uStack_f4 + uVar18;
              uVar30 = (ulonglong)uStack_f4;
              puVar25 = (uint *)ppbStack_f0;
              uVar18 = uStack_e0;
            }
            uVar21 = (uint)uVar30;
            uStack_e0 = uVar18;
            if (((byte *)CONCAT62(uStack_d8,uStack_da) != (byte *)0x0) &&
               ((byte *)CONCAT62(uStack_d8,uStack_da) < (byte *)(uVar30 + (longlong)puVar25))) {
              if (((cRam00000000019a204b != '\0') || ((bRam00000000019b2950 & 1) != 0)) &&
                 (((lVar13 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                              (ulonglong)*puRam0000000000f108e0), puVar25 = (uint *)ppbStack_f0,
                   lVar13 != 0 && (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
                  (*(char *)(lVar13 + 0x499) != '\0')))) {
                if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                  (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3fa);
                  puVar25 = (uint *)ppbStack_f0;
                }
                else {
                  uStack_1b8 = (uint *)0x0;
                  (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x877);
                  puVar25 = (uint *)ppbStack_f0;
                }
              }
              func_0x(puVar25,0x12);
              puVar25 = (uint *)ppbStack_f0;
              uVar21 = uStack_f4;
            }
            if (0x3f3b < uVar21 - 1) {
              if (((cRam00000000019a204b != '\0') || ((bRam00000000019b2950 & 1) != 0)) &&
                 ((lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                             (ulonglong)*puRam0000000000f108e0), puVar25 = (uint *)ppbStack_f0,
                  lVar13 != 0 &&
                  ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                   (*(char *)(lVar13 + 0x499) != '\0')))))) {
                if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                  (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3ed);
                  puVar25 = (uint *)ppbStack_f0;
                }
                else {
                  uStack_1b8 = (uint *)0x0;
                  (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x87c);
                  puVar25 = (uint *)ppbStack_f0;
                }
              }
              func_0x(puVar25,5);
              puVar25 = (uint *)ppbStack_f0;
            }
          }
code_r0x001009fc:
          sVar28 = -*(short *)ppbVar26;
          if ((*(byte *)((longlong)ppbVar29 + 0x216) & 0x10) != 0) {
            if ((*(byte *)puVar25 & 0x10) == 0) {
              if ((1 << (*(byte *)puVar25 & 0xe) & 0x1105U) != 0) {
code_r0x001003b8:
                puVar25 = (uint *)((longlong)ppbVar29[0x43] + 4);
                auStack_198[0] = *(uint *)ppbVar29[0x43];
                goto code_r0x00100b95;
              }
            }
            else {
              if ((int)(uint)uStack_e8 <= *(int *)ppbVar26) goto code_r0x001003b8;
              if (*(ushort *)(((ulonglong)uStack_e8 & 0xffffffff) + (longlong)puVar25) <
                  *(ushort *)((longlong)ppbVar29 + 0x214)) {
                puVar25 = (uint *)((longlong)ppbVar29[0x43] + 4);
                auStack_198[0] = *(uint *)ppbVar29[0x43];
                goto code_r0x00100b95;
              }
            }
          }
          auStack_198[0] = uVar20;
          if ((uint)(int)sVar28 <= (uint)uStack_dc) {
            puVar27 = puVar25;
            uVar18 = uStack_e0;
            if (sVar28 != 1) {
              puVar27 = (uint *)ppbStack_f0;
              uVar18 = *(ushort *)
                        ((longlong)puVar25 +
                        (longlong)sVar28 * 2 + (((ulonglong)uStack_e8 >> 0x20) - 2)) & 0x7fff;
            }
            uVar21 = *(ushort *)
                      ((longlong)puVar25 + (longlong)sVar28 * 2 + ((ulonglong)uStack_e8 >> 0x20)) &
                     0x7fff;
            if ((uVar18 < uStack_e0) || (uVar21 < uVar18)) {
              func_0x(puVar27,7);
              puVar27 = (uint *)ppbStack_f0;
            }
            puVar25 = (uint *)((ulonglong)uVar18 + (longlong)puVar27);
            auStack_198[0] = uVar21 - uVar18;
          }
        }
        else {
          if ((uVar11 & 8) != 0) {
            puVar25 = (uint *)0x10174b4;
            if ((*(byte *)((longlong)(int)uVar21 + (longlong)ppbStack_f0) &
                (byte)(1 << ((byte)uVar11 & 7))) == 0) {
              puVar25 = (uint *)0x1017ad8;
            }
            auStack_198[0] = 1;
            goto code_r0x00100b95;
          }
          if ((uVar11 & 0x10) != 0) {
            if ((*(byte *)ppbStack_f0 & 0x10) == 0) {
              if ((1 << (*(byte *)ppbStack_f0 & 0xe) & 0x1105U) != 0) {
code_r0x001003df:
                puVar25 = (uint *)((longlong)ppbStack_190[0x43] + 4);
                auStack_198[0] = *(uint *)ppbStack_190[0x43];
                if (auStack_198[0] != 6) {
                  uStack_1b8 = (uint *)0x0;
                  (*pcRam0000000000f10870)(1,0x14407e8,0x143f1e8,0x381);
                  uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
                }
                goto code_r0x00100b95;
              }
            }
            else if (((int)(uint)uStack_e8 <= (int)uVar21) ||
                    (*(ushort *)(((ulonglong)uStack_e8 & 0xffffffff) + (longlong)ppbStack_f0) <
                     *(ushort *)((longlong)ppbStack_190 + 0x214))) goto code_r0x001003df;
          }
          puVar25 = (uint *)((longlong)ppbStack_f0 + (longlong)(int)uVar21);
          auStack_198[0] = 6;
        }
      }
    }
    else {
      uStack_188 = 0;
      uStack_1b8 = &uStack_188;
      puVar25 = (uint *)func_0x(&uStack_f6,ppbVar26,ppbStack_f0,auStack_198);
      uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
      if (((sStack_f8 != 0) &&
          (uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0), uStack_e8 != (byte **)0x0))
         && ((uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0), *uStack_e8 != (byte *)0x0
             && ((uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0),
                 (*(byte *)((longlong)ppbVar29 + 0x216) & 8) == 0 &&
                 (uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0), (uStack_188 & 1) == 0
                 )))))) {
        if ((puVar25 == (uint *)0x0) || (puVar25 == (uint *)0x10174b4)) goto code_r0x00100b8e;
        uStack_1a0 = uStack_188;
        puStack_1a8 = auStack_198;
        uStack_1b0 = 6;
        uStack_1b8 = auStack_48;
        puVar25 = (uint *)func_0x(uStack_e8,ppbVar26,puVar25,auStack_198[0]);
      }
    }
code_r0x00100b95:
    lVar13 = lStack_180;
    *(uint *)(lStack_150 + 0xf54) = *puVar25;
    *(undefined2 *)(lStack_150 + 0xf58) = *(undefined2 *)(puVar25 + 1);
    uVar11 = *(ushort *)(lStack_180 + 0x16);
    iStack_c4 = uVar11 - 1;
    ppbVar26 = (byte **)0x0;
    if (*(char *)(lStack_180 + 2) < '\0') {
      pbVar1 = (byte *)(lStack_180 + 0x60);
      if ((sStack_f8 == 0) || (ppbVar26 = uStack_e8, uStack_e8 == (byte **)0x0)) {
        uStack_98 = 0;
        uStack_8a = 0;
        auStack_70 = ZEXT816(0);
        auStack_c0 = ZEXT816(0);
        stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
        auStack_b0._0_2_ = 0xffff;
        uStack_a8 = 0;
        uStack_92 = 0;
        uStack_90 = 0;
        uStack_88 = 0;
        uStack_a0 = 0;
        auStack_80 = ZEXT816(0);
        auStack_60._0_12_ = ZEXT812(0);
        auStack_60._12_4_ = 0;
        uStack_50 = 0;
        ppbVar26 = (byte **)auStack_c0;
      }
      if (*(short *)(lStack_180 + 0x24) == 0) {
code_r0x00100ca6:
        uStack_178 = *(undefined8 *)(lVar13 + 0x28);
        uStack_170 = *(undefined2 *)(lVar13 + 0x30);
      }
      else {
        cVar10 = *(char *)(lStack_180 + 1);
        if (cVar10 == '\v') {
          if (*(int *)(lStack_180 + 0x18) != 99) {
code_r0x00100c66:
            if (cVar10 != '\t') goto code_r0x00100ca6;
            goto code_r0x00100c6a;
          }
        }
        else {
          if (cVar10 != '\b') goto code_r0x00100c66;
code_r0x00100c6a:
          if (*(int *)(lStack_180 + 0x18) != 99) goto code_r0x00100ca6;
        }
        uStack_168 = *(undefined4 *)(lStack_180 + 0x20);
        uStack_164 = *(undefined2 *)(lStack_180 + 0x24);
        cVar10 = func_0x(&uStack_168);
        if (cVar10 == '\0') goto code_r0x00100ca6;
        func_0x(lVar13,&uStack_178);
      }
      *ppbVar26 = pbVar1;
      *(undefined4 *)(ppbVar26 + 0xc) = (undefined4)uStack_178;
      *(int *)((longlong)ppbVar26 + 100) = (int)((ulonglong)uStack_178 >> 0x20);
      *(undefined2 *)(ppbVar26 + 0xd) = uStack_170;
      *(undefined4 *)((longlong)ppbVar26 + 0x6c) = *(undefined4 *)(lVar13 + 0x20);
      *(undefined2 *)(ppbVar26 + 0xe) = *(undefined2 *)(lVar13 + 0x24);
      *(undefined2 *)((longlong)ppbVar26 + 0x72) = 0;
      uStack_148 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x108f560);
      uVar30 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x108f564);
      *(undefined2 *)(ppbVar26 + 2) = 0xffff;
      ppbVar26[3] = (byte *)0x0;
      *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
      ppbVar26[7] = (byte *)0x0;
      ppbVar26[4] = (byte *)0x0;
      ppbVar26[9] = (byte *)0x0;
      ppbVar26[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar26 + 0xb) = 0;
      if ((**ppbVar26 & 2) != 0) {
        pbVar2 = pbVar1 + uVar30;
        if ((*pbVar2 & 1) == 0) {
          *(undefined2 *)(ppbVar26 + 2) = 0;
          ppbVar26[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar26 + 0x36) = 0;
          switch(*pbVar2 & 0xe) {
          default:
            uVar19 = (uint)*(ushort *)(pbVar2 + 2);
            if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
              func_0x(pbVar2,6);
            }
            break;
          case 4:
            uVar19 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar19 = 1;
          }
          *(uint *)(ppbVar26 + 4) = uVar19;
          *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
        }
        else {
          *(undefined2 *)(ppbVar26 + 2) = 1;
          ppbVar26[3] = pbVar2;
          bVar3 = *pbVar2;
          switch(bVar3 & 0x1c) {
          default:
            if ((char)pbVar2[1] < '\0') {
              uVar16 = *(ushort *)(pbVar2 + 1);
              *(ushort *)((longlong)ppbVar26 + 0x12) = uVar16;
              sVar28 = 3;
              uVar16 = (uVar16 & 0x7f) << 8 | uVar16 >> 8;
            }
            else {
              sVar28 = 2;
              uVar16 = (ushort)pbVar2[1];
            }
            *(ushort *)((longlong)ppbVar26 + 0x12) = uVar16;
            *(short *)(ppbVar26 + 5) = sVar28;
            uVar16 = *(ushort *)((longlong)ppbVar26 + 0x12);
            *(short *)((longlong)ppbVar26 + 0x2c) = (short)(uVar16 + 1 >> 1) + sVar28;
            if (uVar16 < 0x1f) {
              *(undefined2 *)((longlong)ppbVar26 + 0x2a) = 0;
              *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
              *(undefined4 *)(ppbVar26 + 8) = 0;
              ppbVar26[7] = (byte *)0x0;
              ppbVar26[4] = (byte *)0x0;
            }
            else {
              iVar22 = uVar16 - 1;
              *(short *)((longlong)ppbVar26 + 0x2a) =
                   ((short)(iVar22 / 0x1e) + (short)(iVar22 >> 0x1f)) -
                   (short)((longlong)iVar22 * 0x88888889 >> 0x3f);
              *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
              *(undefined4 *)(ppbVar26 + 8) = 0;
              ppbVar26[7] = (byte *)0x0;
              ppbVar26[4] = (byte *)0x0;
            }
            break;
          case 4:
            if (((bVar3 & 0x1c) != 4) || (uVar18 = 1, (bVar3 & 2) == 0)) {
              uVar18 = uVar19;
            }
            if (uVar18 == 0) {
              uVar17 = 1;
            }
            else {
              *(undefined4 *)(ppbVar26 + 8) = 0;
              uVar17 = 0xf;
            }
            ppbVar26[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar26 + 0x12) = 0;
            ppbVar26[6] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = uVar17;
            *(uint *)(ppbVar26 + 8) = (uint)(uVar18 != 0);
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
            break;
          case 8:
            ppbVar26[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar26 + 0x12) = 0;
            ppbVar26[6] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = 9;
            *(undefined4 *)(ppbVar26 + 8) = 0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
          }
        }
      }
      if ((**ppbVar26 & 4) != 0) {
        if (uStack_148._2_2_ != 0) {
          uVar30 = (ulonglong)*(ushort *)(lVar13 + 0x61 + (longlong)uStack_148._2_2_ * 2);
        }
        psVar15 = (short *)(pbVar1 + uVar30);
        ppbVar26[9] = (byte *)psVar15;
        sVar28 = *psVar15;
        ppbVar26[10] = (byte *)(psVar15 + 1);
        *(short *)(ppbVar26 + 0xb) = (sVar28 + 1) * 2;
      }
      if (ppbVar26[1] != (byte *)0x0) {
        func_0x(ppbVar26[1],ppbVar26);
      }
    }
    lVar13 = lStack_180;
    ppbVar29 = (byte **)0x10174b4;
    uVar18 = (uint)*(ushort *)(lStack_180 + 0xe);
    ppbStack_f0 = (byte **)((ulonglong)*(ushort *)(lStack_180 + (0x1000 - (ulonglong)uVar11) * 2) +
                           lStack_180);
    if ((*(byte *)ppbStack_f0 & 1) == 0) {
      sStack_f8 = 0;
      uStack_f4 = 0;
      uStack_d2 = 0;
      uStack_d0 = 0;
      switch(*(byte *)ppbStack_f0 & 0xe) {
      default:
        uVar18 = (uint)*(ushort *)((longlong)ppbStack_f0 + 2);
        if (0x1f9d < *(ushort *)((longlong)ppbStack_f0 + 2) - 1) {
          func_0x(ppbStack_f0,6);
        }
        break;
      case 4:
        uVar18 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar18 = 1;
      }
      uStack_e8 = (byte **)CONCAT44(uStack_e8._4_4_,uVar18);
      uStack_da = (undefined2)(lVar13 + 0x2000);
      uStack_d8 = (undefined6)((ulonglong)(lVar13 + 0x2000) >> 0x10);
      ppbVar26 = (byte **)(ulonglong)uVar18;
      uVar18 = uStack_e0;
    }
    else {
      sStack_f8 = 1;
      bVar3 = *(byte *)ppbStack_f0;
      switch(bVar3 & 0x1c) {
      default:
        if ((char)*(byte *)((longlong)ppbStack_f0 + 1) < '\0') {
          uStack_f6 = (*(ushort *)((longlong)ppbStack_f0 + 1) & 0x7f) << 8 |
                      *(ushort *)((longlong)ppbStack_f0 + 1) >> 8;
          uStack_e0._0_2_ = 3;
          sVar28 = 3;
        }
        else {
          uStack_f6 = (ushort)*(byte *)((longlong)ppbStack_f0 + 1);
          uStack_e0._0_2_ = 2;
          sVar28 = 2;
        }
        uStack_dc = (short)(uStack_f6 + 1 >> 1) + sVar28;
        if (uStack_f6 < 0x1f) {
          uStack_e0._2_2_ = 0;
          uStack_f4 = 0;
          uStack_c8 = 0;
        }
        else {
          iVar22 = uStack_f6 - 1;
          uStack_e0._2_2_ =
               ((short)(iVar22 / 0x1e) + (short)(iVar22 >> 0x1f)) -
               (short)((longlong)iVar22 * 0x88888889 >> 0x3f);
          uStack_f4 = 0;
          uStack_c8 = 0;
        }
        break;
      case 4:
        if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
          uStack_e0._0_2_ = 0;
          uStack_e0._2_2_ = 0;
          uStack_dc = 0;
          uStack_da = 0;
          uStack_f6 = 0;
          uStack_d8 = 0;
          uStack_d2 = 0;
          uStack_f4 = 0xf;
          uStack_c8 = 1;
        }
        else {
          uStack_e0._0_2_ = 0;
          uStack_e0._2_2_ = 0;
          uStack_dc = 0;
          uStack_da = 0;
          uStack_f6 = 0;
          uStack_d8 = 0;
          uStack_d2 = 0;
          uStack_f4 = 1;
          uStack_c8 = 0;
        }
        break;
      case 8:
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_da = 0;
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_f4 = 9;
        uStack_c8 = 0;
      }
      lVar13 = lStack_180 + 0x2000;
      uStack_d0 = (undefined2)lVar13;
      uStack_ce = (undefined2)((ulonglong)lVar13 >> 0x10);
      uStack_cc = (ushort)((ulonglong)lVar13 >> 0x20);
      uStack_ca = (undefined2)((ulonglong)lVar13 >> 0x30);
      uStack_e8 = ppbVar26;
      uVar18 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
    }
    ppbVar6 = ppbStack_190;
    ppbVar24 = ppbStack_190 + 0x42;
    uStack_e0 = uVar18;
    if (sStack_f8 == 0) {
      uVar19 = *(uint *)ppbVar24;
      if ((uVar19 & 0xc0000000) == 0x80000000) {
        iVar22 = func_0x(&uStack_f6);
        if (iVar22 == 0) {
          auStack_198[0] = 0;
          ppbVar29 = (byte **)0x0;
          uVar20 = auStack_198[0];
        }
        else {
          ppbVar29 = (byte **)func_0x(&uStack_ce,ppbVar24,auStack_198,auStack_124);
          uVar20 = auStack_198[0];
        }
      }
      else {
        uVar11 = *(ushort *)((longlong)ppbStack_190 + 0x216);
        if ((uVar11 & 0x10) != 0) {
          if ((*(byte *)ppbStack_f0 & 0x10) == 0) {
            if ((1 << (*(byte *)ppbStack_f0 & 0xe) & 0x1105U) == 0) goto code_r0x001011ef;
          }
          else if (((int)uVar19 < (int)ppbVar26) &&
                  (*(ushort *)((longlong)ppbStack_190 + 0x214) <=
                   *(ushort *)(((ulonglong)ppbVar26 & 0xffffffff) + (longlong)ppbStack_f0)))
          goto code_r0x001011ef;
          goto code_r0x00101248;
        }
code_r0x001011ef:
        if ((int)uVar19 < 0) {
          ppbVar29 = ppbStack_f0;
          if (uStack_f4 == 0) {
            uStack_f6 = 0;
            uVar30 = (ulonglong)uStack_e8 & 0xffffffff;
            uVar19 = (uint)uStack_e8;
            if ((*(byte *)ppbStack_f0 & 0x10) != 0) {
              uVar19 = (uint)uStack_e8 + 2 + (*(ushort *)(uVar30 + (longlong)ppbStack_f0) + 7 >> 3);
              uVar30 = (ulonglong)uVar19;
            }
            uStack_e8 = (byte **)CONCAT44(uVar19,(uint)uStack_e8);
            uStack_e0 = (uint)uVar30;
            if ((*(byte *)ppbStack_f0 & 0x20) == 0) {
              uStack_dc = 0;
              uStack_f4 = uStack_e0;
            }
            else {
              puVar23 = (ushort *)(uVar30 + (longlong)ppbStack_f0);
              uStack_dc = *puVar23;
              if (uStack_dc == 0) {
                if ((((cRam00000000019a204b != '\0') ||
                     (uStack_e0 = uVar18, (bRam00000000019b2950 & 1) != 0)) &&
                    (lVar13 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                               (ulonglong)*puRam0000000000f108e0), uStack_e0 = uVar18, lVar13 != 0))
                   && ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                       (*(char *)(lVar13 + 0x499) != '\0')))) {
                  if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                    (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_1b8 = (uint *)0x0;
                    (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x80f);
                  }
                }
                func_0x(ppbStack_f0,3);
              }
              uStack_e0 = uStack_e8._4_4_ + (uStack_dc + 1) * 2;
              if (0x1f9e < uStack_e0) {
                if (((cRam00000000019a204b != '\0') || ((bRam00000000019b2950 & 1) != 0)) &&
                   ((lVar13 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                               (ulonglong)*puRam0000000000f108e0), lVar13 != 0 &&
                    ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                     (*(char *)(lVar13 + 0x499) != '\0')))))) {
                  if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                    (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_1b8 = (uint *)0x0;
                    (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x816);
                  }
                }
                func_0x(ppbStack_f0,4);
              }
              uStack_f4 = puVar23[uStack_dc] & 0x7fff;
              if (uStack_f4 < uStack_e0) {
                if ((((cRam00000000019a204b != '\0') || ((bRam00000000019b2950 & 1) != 0)) &&
                    (lVar13 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                               (ulonglong)*puRam0000000000f108e0), lVar13 != 0)) &&
                   ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                    (*(char *)(lVar13 + 0x499) != '\0')))) {
                  if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                    (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_1b8 = (uint *)0x0;
                    (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x81d);
                  }
                }
                func_0x(ppbStack_f0,4);
              }
              uVar30 = (ulonglong)uStack_f4;
              ppbVar29 = ppbStack_f0;
              do {
                if (-1 < (short)puVar23[(ulonglong)(uStack_dc - 1) + 1]) break;
                uVar18 = uStack_e0;
                if (((uStack_dc != 1) &&
                    (uVar18 = *(ushort *)
                               ((longlong)ppbVar29 +
                               (ulonglong)uStack_dc * 2 + (((ulonglong)uStack_e8 >> 0x20) - 2)) &
                              0x7fff, uVar18 < uStack_e0)) ||
                   ((*(ushort *)
                      ((longlong)ppbVar29 +
                      (ulonglong)uStack_dc * 2 + ((ulonglong)uStack_e8 >> 0x20)) & 0x7fff) < uVar18)
                   ) {
                  func_0x(ppbVar29,7);
                  uVar30 = (ulonglong)uStack_f4;
                  ppbVar29 = ppbStack_f0;
                }
                if ((uVar18 < uStack_e0) || ((uint)uVar30 < uVar18)) goto code_r0x0010189e;
                if (*(ushort *)((ulonglong)uVar18 + (longlong)ppbVar29) == 5) {
                  uStack_f6 = uStack_f6 | 2;
                  uStack_dc = uStack_dc - 1;
                  uStack_ce = (undefined2)uVar18;
                  uVar11 = *(ushort *)((ulonglong)(uVar18 & 0xffff) + 2 + (longlong)ppbVar29);
                  if ((uVar11 & 0x4000) == 0) {
                    uStack_cc = uStack_cc & 0xc7ff;
                  }
                  else {
                    uStack_cc = uStack_cc ^ (uVar11 ^ uStack_cc) & 0x3800;
                  }
                  uStack_cc = (uStack_cc ^
                              *(ushort *)((ulonglong)(uVar18 & 0xffff) + 2 + (longlong)ppbVar29)) &
                              0x7ff ^ uStack_cc;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar18 + (longlong)ppbVar29) < 0x400) break;
                uStack_f6 = uStack_f6 | 1;
                uStack_dc = uStack_dc - 1;
              } while (uStack_dc != 0);
            }
            if ((*(byte *)ppbVar29 & 0x40) == 0) {
              uStack_d2 = 0;
              uStack_d0 = 0;
            }
            else {
              uStack_d2 = (undefined2)uVar30;
              uStack_d0 = (undefined2)(uVar30 >> 0x10);
              uStack_f4 = (int)uVar30 + 0xe;
              puVar14 = (ulonglong *)func_0x(&uStack_f6);
              uVar30 = *puVar14;
              uVar16 = (ushort)(uVar30 >> 0x30);
              uVar11 = uVar16;
              if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
                uVar11 = uVar16 & 0xdfff;
                if ((uVar30 & 0x4000000000000000) != 0) {
                  uVar11 = uVar16 | 0x2000;
                }
              }
              uVar18 = uVar20;
              if (uVar11 == 0xfffc) {
                uVar18 = (uint)((uVar30 >> 0x20 & 0xffff) >> 5);
              }
              uStack_f4 = uStack_f4 + uVar18;
              uVar30 = (ulonglong)uStack_f4;
              ppbVar29 = ppbStack_f0;
            }
            uVar18 = (uint)uVar30;
            if ((CONCAT62(uStack_d8,uStack_da) != 0) &&
               (CONCAT62(uStack_d8,uStack_da) < uVar30 + (longlong)ppbVar29)) {
              if (((cRam00000000019a204b != '\0') || ((bRam00000000019b2950 & 1) != 0)) &&
                 (((lVar13 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                              (ulonglong)*puRam0000000000f108e0), ppbVar29 = ppbStack_f0,
                   lVar13 != 0 && (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
                  (*(char *)(lVar13 + 0x499) != '\0')))) {
                if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                  (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3fa);
                  ppbVar29 = ppbStack_f0;
                }
                else {
                  uStack_1b8 = (uint *)0x0;
                  (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x877);
                  ppbVar29 = ppbStack_f0;
                }
              }
              func_0x(ppbVar29,0x12);
              ppbVar29 = ppbStack_f0;
              uVar18 = uStack_f4;
            }
            if (0x3f3b < uVar18 - 1) {
              if (((cRam00000000019a204b != '\0') || ((bRam00000000019b2950 & 1) != 0)) &&
                 ((lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam0000000000f108d8 * 8) + 8 +
                             (ulonglong)*puRam0000000000f108e0), ppbVar29 = ppbStack_f0, lVar13 != 0
                  && ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                      (*(char *)(lVar13 + 0x499) != '\0')))))) {
                if ((cRam00000000019a1f3b == '\0') && ((bRam00000000019b2950 & 2) == 0)) {
                  (*pcRam0000000000f10878)(0x22,0x44,0x15,0x3ed);
                  ppbVar29 = ppbStack_f0;
                }
                else {
                  uStack_1b8 = (uint *)0x0;
                  (*pcRam0000000000f10870)(1,0x1292a78,0x13b2748,0x87c);
                  ppbVar29 = ppbStack_f0;
                }
              }
              func_0x(ppbVar29,5);
              ppbVar29 = ppbStack_f0;
            }
          }
code_r0x0010189e:
          sVar28 = -*(short *)ppbVar24;
          if ((*(byte *)((longlong)ppbVar6 + 0x216) & 0x10) != 0) {
            uVar18 = uStack_e0;
            if ((*(byte *)ppbVar29 & 0x10) == 0) {
              if ((1 << (*(byte *)ppbVar29 & 0xe) & 0x1105U) != 0) {
code_r0x00101248:
                ppbVar29 = (byte **)((longlong)ppbVar6[0x43] + 4);
                uVar20 = *(uint *)ppbVar6[0x43];
                uStack_e0 = uVar18;
                goto code_r0x00101a2c;
              }
            }
            else {
              if ((int)(uint)uStack_e8 <= *(int *)ppbVar24) goto code_r0x00101248;
              if (*(ushort *)(((ulonglong)uStack_e8 & 0xffffffff) + (longlong)ppbVar29) <
                  *(ushort *)((longlong)ppbVar6 + 0x214)) {
                ppbVar29 = (byte **)((longlong)ppbVar6[0x43] + 4);
                uVar20 = *(uint *)ppbVar6[0x43];
                goto code_r0x00101a2c;
              }
            }
          }
          if ((uint)(int)sVar28 <= (uint)uStack_dc) {
            ppbVar26 = ppbVar29;
            uVar20 = uStack_e0;
            if (sVar28 != 1) {
              ppbVar26 = ppbStack_f0;
              uVar20 = *(ushort *)
                        ((longlong)ppbVar29 +
                        (longlong)sVar28 * 2 + (((ulonglong)uStack_e8 >> 0x20) - 2)) & 0x7fff;
            }
            uVar18 = *(ushort *)
                      ((longlong)ppbVar29 + (longlong)sVar28 * 2 + ((ulonglong)uStack_e8 >> 0x20)) &
                     0x7fff;
            if ((uVar20 < uStack_e0) || (uVar18 < uVar20)) {
              func_0x(ppbVar26,7);
              ppbVar26 = ppbStack_f0;
            }
            ppbVar29 = (byte **)((ulonglong)uVar20 + (longlong)ppbVar26);
            uVar20 = uVar18 - uVar20;
          }
        }
        else {
          if ((uVar11 & 8) != 0) {
            if ((*(byte *)((longlong)(int)uVar19 + (longlong)ppbStack_f0) &
                (byte)(1 << ((byte)uVar11 & 7))) == 0) {
              ppbVar29 = (byte **)0x1017ad8;
            }
            auStack_198[0] = 1;
            uVar20 = auStack_198[0];
            ppbStack_190 = ppbVar29;
            goto code_r0x00101a2c;
          }
          if ((uVar11 & 0x10) != 0) {
            if ((*(byte *)ppbStack_f0 & 0x10) == 0) {
              if ((1 << (*(byte *)ppbStack_f0 & 0xe) & 0x1105U) != 0) {
code_r0x00101270:
                ppbVar29 = (byte **)((longlong)ppbStack_190[0x43] + 4);
                uVar20 = *(uint *)ppbStack_190[0x43];
                if (uVar20 != 6) {
                  uStack_1b8 = (uint *)0x0;
                  (*pcRam0000000000f10870)(1,0x14407e8,0x143f1e8,0x381);
                }
                goto code_r0x00101a2c;
              }
            }
            else if (((int)(uint)uStack_e8 <= (int)uVar19) ||
                    (*(ushort *)(((ulonglong)uStack_e8 & 0xffffffff) + (longlong)ppbStack_f0) <
                     *(ushort *)((longlong)ppbStack_190 + 0x214))) goto code_r0x00101270;
          }
          auStack_198[0] = 6;
          ppbVar29 = (byte **)((longlong)ppbStack_f0 + (longlong)(int)uVar19);
          uVar20 = auStack_198[0];
        }
      }
    }
    else {
      uStack_184 = 0;
      uStack_1b8 = &uStack_184;
      ppbVar29 = (byte **)func_0x(&uStack_f6,ppbVar24,ppbStack_f0,auStack_198);
      uVar20 = auStack_198[0];
      if ((((sStack_f8 != 0) && (uStack_e8 != (byte **)0x0)) && (*uStack_e8 != (byte *)0x0)) &&
         (((*(byte *)((longlong)ppbVar6 + 0x216) & 8) == 0 && ((uStack_184 & 1) == 0)))) {
        if ((ppbVar29 == (byte **)0x0) || (ppbVar29 == (byte **)0x10174b4)) {
          auStack_198[0] = 0;
          ppbVar29 = (byte **)0x0;
          uVar20 = auStack_198[0];
        }
        else {
          uStack_1a0 = uStack_184;
          puStack_1a8 = auStack_198;
          uStack_1b0 = 6;
          uStack_1b8 = auStack_48;
          ppbVar29 = (byte **)func_0x(uStack_e8,ppbVar24,ppbVar29,auStack_198[0]);
          uVar20 = auStack_198[0];
        }
      }
    }
code_r0x00101a2c:
    auStack_198[0] = uVar20;
    *(undefined4 *)(lStack_150 + 0xf5c) = *(undefined4 *)ppbVar29;
    *(undefined2 *)(lStack_150 + 0xf60) = *(undefined2 *)((longlong)ppbVar29 + 4);
  }
  pplVar9 = pplStack_108;
  pplVar8 = pplStack_110;
  lVar4 = lStack_158;
  lVar13 = lStack_180;
  uStack_1b8 = (uint *)CONCAT44(uStack_1b8._4_4_,(uint)*(ushort *)(lStack_158 + 0x16));
  func_0x(lStack_150,pplStack_108,pplStack_110,0);
  uStack_160 = *(undefined4 *)(lVar4 + 0x20);
  uStack_15c = *(undefined2 *)(lVar4 + 0x24);
  if (*pplVar9 != (longlong *)0x0) {
    if (((*(ushort *)((longlong)*pplVar9 + 0x62) & 0x400) == 0) ||
       (*(short *)((longlong)pplVar9 + 0xc) < 3)) {
      iVar22 = (int)*(short *)((longlong)pplVar9 + 0xc);
      plVar5 = *pplVar9;
      if (((byte)*(undefined2 *)((longlong)plVar5 + 0x62) >> 3 & 1) != 0) {
        if (iVar22 == 3) {
          iVar22 = 4;
        }
        else if (iVar22 < 2) goto LAB_;
        if ((((*(uint *)((longlong)plVar5 + 100) & 8) != 0) && (lVar4 = plVar5[0x12], lVar4 != 0))
           && (*(longlong *)(lVar4 + 0x758) != 0)) {
          func_0x(*(undefined8 *)(lVar4 + 0x758),plVar5,iVar22);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
         ((2 < iVar22 &&
          (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0)))))) {
        iVar12 = (*_DAT_)(*plVar5,0x2000,2,auStack_120);
        if (iVar12 != 0) {
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      func_0x(plVar5 + 0x13,iVar22);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        func_0x(plVar5,0,iVar22);
      }
      *(undefined2 *)((longlong)pplVar9 + 0xc) = 0;
      *pplVar9 = (longlong *)0x0;
    }
    else {
      func_0x(pplVar9);
    }
  }
  lVar7 = lStack_150;
  lVar4 = *(longlong *)(lStack_150 + 0x60);
  *(undefined4 *)(lVar4 + 0x14) = *(undefined4 *)(lVar13 + 0x20);
  *(undefined2 *)(lVar4 + 0x18) = *(undefined2 *)(lVar13 + 0x24);
  *(undefined2 *)(lVar4 + 0x1a) = 0;
  if (*pplVar8 != (longlong *)0x0) {
    if (((*(ushort *)((longlong)*pplVar8 + 0x62) >> 10 & 1) != 0) &&
       (2 < *(short *)((longlong)pplVar8 + 0xc))) {
      func_0x(pplVar8);
      func_0x(lVar7,&uStack_160);
      goto LAB_;
    }
    iVar22 = (int)*(short *)((longlong)pplVar8 + 0xc);
    plVar5 = *pplVar8;
    if (((byte)*(undefined2 *)((longlong)plVar5 + 0x62) >> 3 & 1) != 0) {
      if (iVar22 == 3) {
        iVar22 = 4;
      }
      else if (iVar22 < 2) goto LAB_;
      if ((((*(uint *)((longlong)plVar5 + 100) & 8) != 0) && (lVar13 = plVar5[0x12], lVar13 != 0))
         && (*(longlong *)(lVar13 + 0x758) != 0)) {
        func_0x(*(undefined8 *)(lVar13 + 0x758),plVar5,iVar22);
      }
    }
LAB_:
    if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
       ((2 < iVar22 &&
        (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0)))))) {
      iVar12 = (*_DAT_)(*plVar5,0x2000,2,auStack_11c);
      if (iVar12 != 0) {
        LOCK();
        *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
        UNLOCK();
        LOCK();
        *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
        UNLOCK();
      }
    }
    func_0x(plVar5 + 0x13,iVar22);
    if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
      func_0x(plVar5,0,iVar22);
    }
    *(undefined2 *)((longlong)pplVar8 + 0xc) = 0;
    *pplVar8 = (longlong *)0x0;
  }
  func_0x(lVar7,&uStack_160);
LAB_:
  func_0x(uStack_40 ^ (ulonglong)auStack_1d8);
  return;
}

