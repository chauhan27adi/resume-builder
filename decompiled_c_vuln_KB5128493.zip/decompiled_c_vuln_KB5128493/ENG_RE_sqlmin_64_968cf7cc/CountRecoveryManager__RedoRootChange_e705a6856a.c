
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3,longlong *param_4,char param_5,
                 char param_6)

{
  uint *puVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  longlong lVar4;
  undefined8 uVar5;
  int iVar6;
  longlong lVar7;
  ushort uVar8;
  longlong lVar9;
  undefined8 *puVar10;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar11;
  undefined auStack_118 [32];
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  uint uStack_d8;
  undefined2 uStack_c8;
  undefined4 uStack_c4;
  byte *pbStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_aa;
  undefined2 uStack_a2;
  undefined2 uStack_a0;
  undefined6 uStack_9e;
  undefined4 uStack_90;
  undefined2 uStack_8c;
  undefined8 *puStack_88;
  uint uStack_80;
  longlong alStack_78 [2];
  ulonglong uStack_68;
  longlong lStack_60;
  int iStack_58;
  longlong lStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  
  uStack_40 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_118;
  lStack_60 = param_1 + 0x40;
  iStack_58 = 0;
  lStack_50 = 0;
  uStack_48 = 0;
  alStack_78[0] = param_2;
  func_0x(&lStack_60,0x40033d);
  lVar7 = lStack_60;
  if (param_6 != '\0') {
    lVar4 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x728);
    if ((lVar4 == 0) || (iVar6 = iStack_58, (*(uint *)(lVar4 + 0x24) >> 7 & 1) == 0)) {
      puVar10 = (undefined8 *)0x0;
      if ((*(char *)(param_1 + 0x79) != '\0') && (param_5 != '\0')) {
        puVar1 = (uint *)(param_2 + 0x30);
        uVar8 = 0;
        uStack_68 = *(ulonglong *)(param_2 + 0x38) >> 0x10;
        lVar9 = func_0x(param_1,&uStack_68);
        lVar4 = *(longlong *)(lVar9 + 0x60);
        if ((((param_4 == (longlong *)0x0) || ((*(byte *)(param_4 + 0x3c) & 1) == 0)) ||
            (8 < *puVar1)) || ((0x124U >> (*puVar1 & 0x1f) & 1) == 0)) {
          puStack_88._0_4_ = 0;
          if (lVar4 == 0) {
            uStack_90 = *(undefined4 *)(param_2 + 0x48);
            uStack_8c = *(undefined2 *)(param_2 + 0x4c);
            func_0x(lVar9,*puVar1,&uStack_90,*(undefined8 *)(param_1 + 0x30));
            if (((DAT_ & 0x10) != 0) &&
               (*(char *)(*(longlong *)(param_1 + 0x38) + 0x2050) != '\0')) {
              puStack_88 = (undefined8 *)0x0;
              uVar11 = 0;
              lVar4 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x728);
              if (lVar4 != 0) {
                puVar10 = (undefined8 *)func_0x(lVar4,alStack_78,1);
                puStack_88 = (undefined8 *)*puVar10;
                uStack_80 = *(uint *)(puVar10 + 1);
                uVar11 = uStack_80 & 0xffff;
              }
              uStack_e0 = CONCAT44(uStack_e0._4_4_,uVar11);
              uStack_e8 = CONCAT44(uStack_e8._4_4_,(int)((ulonglong)puStack_88 >> 0x20));
              uStack_f8 = CONCAT44(uStack_f8._4_4_,*(undefined4 *)(param_2 + 0x48));
              uStack_f0 = puStack_88._0_4_;
              func_0x(0x10f3af0,*(undefined8 *)(param_2 + 0x38),*puVar1,
                              *(undefined2 *)(param_2 + 0x4c));
            }
          }
          else {
            lVar9 = lVar4 + 0x5b0;
            uStack_48._4_4_ = 4;
            uStack_d8 = 0;
            uStack_e0 = 0;
            uStack_e8 = 0;
            uStack_f0 = 0;
            uStack_f8 = 0;
            lStack_50 = lVar9;
            uStack_48._0_4_ = func_0x(lVar9,4,0xffffffff);
            func_0x(lVar4,puVar1);
            func_0x(lVar9,4);
            uStack_48 = (ulonglong)uStack_48._4_4_ << 0x20;
            if (((DAT_ & 0x10) != 0) &&
               (*(char *)(*(longlong *)(param_1 + 0x38) + 0x2050) != '\0')) {
              puStack_88 = (undefined8 *)0x0;
              lVar9 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x728);
              if (lVar9 != 0) {
                puVar10 = (undefined8 *)func_0x(lVar9,alStack_78,1);
                puStack_88 = (undefined8 *)*puVar10;
                uStack_80 = *(uint *)(puVar10 + 1);
                uVar8 = (ushort)uStack_80;
              }
              uStack_f0 = *(undefined4 *)(param_2 + 0x48);
              uStack_d8 = (uint)uVar8;
              uStack_e0 = CONCAT44(uStack_e0._4_4_,(int)((ulonglong)puStack_88 >> 0x20));
              uStack_e8 = CONCAT44(uStack_e8._4_4_,puStack_88._0_4_);
              uStack_f8 = CONCAT44(uStack_f8._4_4_,(uint)*(ushort *)(param_2 + 0x4c));
              func_0x(0x10f3bf0,*(undefined8 *)(param_2 + 0x38),lVar4,*puVar1);
            }
          }
        }
        else {
          uStack_90 = 0x793;
          uStack_68 = _DAT_;
          uStack_f8 = CONCAT71(uStack_f8._1_7_,5);
          puStack_88 = (undefined8 *)(*_DAT_)(0x58,_DAT_,0x10f3d08,0x793);
          if (puStack_88 != (undefined8 *)0x0) {
            uVar3 = *(undefined4 *)(param_2 + 0x48);
            uVar2 = *(undefined2 *)(param_2 + 0x4c);
            uVar5 = *(undefined8 *)(param_2 + 0x38);
            alStack_78[0] = CONCAT26((short)uVar5,(int6)((ulonglong)uVar5 >> 0x10));
            uVar11 = *puVar1;
            puStack_88[1] = 0;
            puStack_88[2] = 0;
            puStack_88[3] = 0;
            puStack_88[4] = 0;
            *puStack_88 = 0xdc9d10;
            *(undefined2 *)((longlong)puStack_88 + 0x3e) = 0;
            *(uint *)(puStack_88 + 8) = uVar11;
            *(int *)(puStack_88 + 7) = (int)((ulonglong)uVar5 >> 0x10);
            *(short *)((longlong)puStack_88 + 0x3c) = (short)((ulonglong)uVar5 >> 0x30);
            puStack_88[9] = param_4;
            *(undefined4 *)(puStack_88 + 10) = uVar3;
            *(undefined2 *)((longlong)puStack_88 + 0x54) = uVar2;
            *(undefined2 *)((longlong)puStack_88 + 0x56) = 0;
            puVar10 = puStack_88;
          }
          (**(code **)(*param_4 + 0x158))(param_4,puVar10);
        }
      }
      *(undefined8 *)(lVar7 + 0x30) = 0;
      func_0x(lVar7,0);
      iVar6 = iStack_58 + -1;
    }
    for (; iStack_58 = iVar6, iVar6 != 0; iVar6 = iVar6 + -1) {
      *(undefined8 *)(lVar7 + 0x30) = 0;
      func_0x(lVar7,0);
    }
    func_0x(uStack_38 ^ (ulonglong)auStack_118);
    return;
  }
  uStack_c4 = 0;
  uStack_aa = 0;
  uStack_a0 = 0;
  uStack_9e = 0;
  uStack_b8 = 0;
  pbStack_c0 = (byte *)((ulonglong)
                        *(ushort *)(param_3 + (0xfff - (longlong)*(short *)(param_2 + 0x1e)) * 2) +
                       param_3);
  if ((*pbStack_c0 & 1) != 0) {
    uStack_c8 = 1;
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_c0 & 0x1c) + 0x100ce8) * 4
                           + 0x100cd8) - 0x16b5fd0);
                    /* WARNING: Could not emulate address calculation at 0x001000d5 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
  uStack_c8 = 0;
  uStack_a2 = 0;
  uStack_a0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100289 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_c0 & 0xe) * 4 + 0x100d08) - 0x16b5fd0))
            ((longlong)*(short *)(param_2 + 0x1e),(longlong)(int)(*pbStack_c0 & 0xe),pbStack_c0,0);
  return;
}

