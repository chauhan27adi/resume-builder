
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,longlong param_4,
                 longlong **param_5)

{
  ushort *puVar1;
  short *psVar2;
  uint *puVar3;
  ushort uVar4;
  undefined2 uVar5;
  longlong lVar6;
  bool bVar7;
  uint *puVar8;
  longlong *plVar9;
  longlong **pplVar10;
  char cVar11;
  short sVar12;
  ushort uVar13;
  ushort uVar14;
  uint uVar15;
  undefined4 uVar16;
  longlong lVar17;
  longlong lVar18;
  undefined8 uVar19;
  longlong *plVar20;
  byte *pbVar21;
  longlong *plVar22;
  undefined uVar23;
  int iVar24;
  int iVar25;
  undefined8 *puVar26;
  ulonglong uVar27;
  uint uVar28;
  undefined *puVar29;
  undefined *puVar30;
  uint uVar31;
  uint *puVar32;
  uint uVar33;
  ulonglong uVar34;
  byte bVar35;
  uint uVar36;
  uint uVar37;
  ushort *puVar38;
  longlong *plVar39;
  undefined8 uStack_330;
  undefined auStack_328 [32];
  longlong *plStack_308;
  undefined8 uStack_300;
  longlong lStack_2d8;
  longlong *plStack_2d0;
  uint *puStack_2c8;
  undefined uStack_2c0;
  uint uStack_2bc;
  longlong *plStack_2b8;
  undefined8 *puStack_2b0;
  int iStack_2a8;
  uint uStack_2a4;
  uint uStack_2a0;
  longlong lStack_298;
  int iStack_290;
  uint uStack_288;
  undefined auStack_284 [4];
  longlong *plStack_280;
  longlong *plStack_278;
  longlong *plStack_268;
  uint *puStack_260;
  uint uStack_258;
  uint uStack_254;
  longlong lStack_250;
  longlong lStack_248;
  undefined8 uStack_240;
  undefined4 uStack_238;
  longlong lStack_230;
  undefined *puStack_218;
  undefined8 uStack_210;
  longlong **pplStack_208;
  int iStack_200;
  uint uStack_1f8;
  int iStack_1f4;
  uint uStack_1f0;
  longlong lStack_1e8;
  undefined auStack_1e0 [4];
  undefined auStack_1dc [4];
  undefined8 uStack_1d8;
  undefined auStack_1d0 [8];
  undefined auStack_1c8 [8];
  undefined auStack_1c0 [8];
  undefined auStack_1b8 [4];
  short sStack_1b4;
  ushort uStack_1b2;
  longlong lStack_1b0;
  longlong lStack_1a8;
  undefined8 uStack_190;
  undefined auStack_188 [16];
  undefined auStack_178 [16];
  undefined auStack_168 [64];
  undefined auStack_128 [224];
  ulonglong uStack_48;
  
  puVar29 = auStack_328;
  uStack_190 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&lStack_2d8;
  pplStack_208 = param_5;
  lVar17 = *(longlong *)(param_1 + 0x3f0);
  plVar39 = (longlong *)0x0;
  uVar36 = 0;
  lStack_1e8 = param_1;
  if (*(longlong *)(lVar17 + 0x10) == 0) {
    uStack_330 = 0x1001f9;
    lVar17 = func_0x(*(longlong *)(param_1 + 0x3b8) + 0xa0);
    if ((lVar17 == 0) &&
       (*(int *)(**(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160) + 0x18) == 0)) {
      puVar26 = (undefined8 *)(param_1 + 0x3b0);
      plVar22 = *(longlong **)(param_1 + 0x3f0);
      uStack_330 = 0x10023e;
      plStack_2b8 = plVar22;
      puStack_2b0 = puVar26;
      func_0x(auStack_168);
      lStack_298 = 0;
      iStack_290 = 0;
      uStack_254 = 0;
      uStack_240 = 0;
      uStack_238 = 0;
      uStack_330 = 0x100264;
      func_0x(auStack_1b8);
      bVar35 = *(byte *)(*(longlong *)(param_1 + 0x3b8) + 0x106) & 1;
      uVar13 = 0;
      puVar30 = auStack_328;
      uVar37 = uStack_254;
      if (param_3 != (longlong *)0x0) {
        if ((*(int *)(param_1 + 0x3d8) == *(int *)(param_3 + 1)) &&
           (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x3c4) * 0x10000)) {
          uStack_330 = 0x1002b4;
          sVar12 = (**(code **)*puVar26)(puVar26);
          if (*(short *)((longlong)param_3 + 0xc) != sVar12) goto LAB_;
          if (param_3[0x15] != 0) {
            LOCK();
            UNLOCK();
          }
        }
        else {
LAB_:
          uStack_330 = 0x1002d6;
          func_0x(param_3,puVar26);
        }
        uVar14 = *(ushort *)(param_3 + 7);
        uVar4 = *(ushort *)((longlong)param_3 + 0x62);
        plStack_268 = param_3;
        lStack_250 = param_4;
        if ((uVar14 >> 10 & 1) == 0) {
          lStack_248 = 0;
          uStack_210 = 0;
          puStack_260 = (uint *)param_3[0xe];
          if (puVar26 != (undefined8 *)0x0) {
            lVar17 = **(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160);
            uStack_240 = *(undefined8 *)(lVar17 + 0xa8);
            uStack_238 = *(undefined4 *)(lVar17 + 0xb0);
          }
          puVar30 = auStack_328;
          uStack_258 = (uint)uVar4;
          uVar37 = uStack_254 | 0x10;
        }
        else {
          if (uVar4 == 0) {
            plStack_2d0 = (longlong *)0x0;
            plVar20 = plVar39;
            uVar31 = uVar36;
          }
          else {
            uVar31 = (uint)uVar4 * 8;
            uStack_330 = 0x10037f;
            uVar13 = uVar4;
            lVar17 = func_0x(uVar4,uVar31,0xffffffffffffff0);
            lVar17 = -lVar17;
            plStack_278 = (longlong *)((longlong)&lStack_2d8 + lVar17);
            *(undefined8 *)(auStack_328 + lVar17 + -8) = 0x1003a0;
            lVar18 = func_0x();
            lVar18 = -lVar18;
            puVar29 = auStack_328 + lVar18 + lVar17;
            plStack_2d0 = (longlong *)((longlong)&lStack_2d8 + lVar18 + lVar17);
            uVar4 = *(ushort *)(param_3 + 0xb);
            uVar37 = *(uint *)((longlong)param_3 + 0x54);
            uVar15 = 0x1f9e;
            if (uVar37 < 0x1f9f) {
LAB_:
              plVar22 = plStack_2b8;
              plVar20 = plStack_278;
              param_1 = lStack_1e8;
              uVar15 = uVar37;
              if (uVar37 == 0) goto LAB_;
            }
            else if (0x1f9d < uVar4) {
              uVar37 = (uint)uVar4;
              goto LAB_;
            }
            puStack_218 = auStack_1b8;
            *(undefined8 *)(auStack_328 + lVar18 + lVar17 + -8) = 0x1003e8;
            func_0x(auStack_1b8);
            uVar27 = (ulonglong)uVar15 + 0xf;
            if (uVar27 <= uVar15) {
              uVar27 = 0xffffffffffffff0;
            }
            uVar27 = uVar27 & 0xfffffffffffffff0;
            *(undefined8 *)(auStack_328 + lVar18 + lVar17 + -8) = 0x100409;
            func_0x();
            puVar29 = auStack_328 + -uVar27 + lVar18 + lVar17;
            lStack_1b0 = (longlong)&lStack_2d8 + -uVar27 + lVar18 + lVar17;
            sStack_1b4 = (short)uVar15 - uVar4;
            uVar13 = *(ushort *)((longlong)param_3 + 0x62);
            uVar14 = *(ushort *)(param_3 + 7);
            plVar22 = plStack_2b8;
            plVar20 = plStack_278;
            param_1 = lStack_1e8;
            uStack_1b2 = uVar4;
          }
LAB_:
          lVar17 = (longlong)plStack_2d0;
          uVar15 = (uint)uVar13;
          lStack_248 = 0;
          uStack_210 = 0;
          puStack_260 = (uint *)param_3[0xe];
          puVar26 = (undefined8 *)(param_1 + 0x3b0);
          if ((undefined8 *)(param_1 + 0x3b0) != (undefined8 *)0x0) {
            lVar18 = **(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160);
            uStack_240 = *(undefined8 *)(lVar18 + 0xa8);
            uStack_238 = *(undefined4 *)(lVar18 + 0xb0);
            puVar26 = puStack_2b0;
          }
          puVar30 = puVar29;
          uStack_258 = uVar15;
          uVar37 = uStack_254 | 0x10;
          if (((uVar14 >> 10 & 1) != 0) && (param_4 != 0)) {
            uStack_254 = uStack_254 | 0x14;
            *(uint *)(puVar29 + 0x30) = uVar31;
            *(longlong *)(puVar29 + 0x28) = lVar17;
            *(uint *)(puVar29 + 0x20) = uVar31;
            *(undefined8 *)(puVar29 + -8) = 0x10050c;
            func_0x(&plStack_268,puVar26,uVar15,plVar20);
            uVar37 = uStack_254;
          }
        }
      }
      uStack_254 = uVar37;
      plVar20 = plVar22 + 1;
      uVar37 = *(uint *)(plVar22 + 9);
      lVar17 = plVar22[8];
      uVar31 = *(uint *)(*(longlong *)(lStack_1e8 + 0x3b8) + 0xb0);
      iVar25 = *(int *)(*(longlong *)(lStack_1e8 + 0x3b8) + 0x100);
      if ((iVar25 == 0) || (iVar25 - 3U < 2)) {
        bVar7 = false;
      }
      else {
        bVar7 = true;
      }
      plStack_2d0 = plVar20;
      uStack_2bc = uVar31;
      uStack_2a4 = uVar37;
      if ((*(byte *)(plStack_268 + 7) & 0x20) == 0) {
        plStack_2b8 = (longlong *)0x0;
        uVar15 = 0;
        if (bVar7) {
          plVar22 = plVar39;
          if ((uStack_254 & 0x10) != 0) {
            plVar22 = plStack_268;
          }
          uVar36 = -*(int *)(plVar22 + 2);
          iVar25 = *(int *)(plVar22 + 3);
          iVar24 = *(int *)((longlong)plVar22 + 0x14);
          uStack_2a0 = uVar36;
          *(undefined2 *)(puVar30 + 0x28) = 1;
          *(int *)(puVar30 + 0x20) = iVar25;
          if (bVar35 == 0) {
            *(undefined8 *)(puVar30 + -8) = 0x101eee;
            func_0x(plVar20,lVar17,uVar37,iVar24);
          }
          else {
            *(undefined8 *)(puVar30 + -8) = 0x101ee7;
            func_0x();
          }
          plVar22 = plVar39;
          if (uVar36 != 0) {
            *(undefined8 *)(puVar30 + -8) = 0x101f18;
            lVar17 = func_0x();
            lVar17 = -lVar17;
            plVar22 = (longlong *)(puVar30 + lVar17 + 0x50);
            plStack_2b8 = plVar22;
            *(undefined8 *)(puVar30 + lVar17 + -8) = 0x101f2e;
            func_0x(plVar22,0);
            puVar30 = puVar30 + lVar17;
          }
          plVar9 = plStack_2b8;
          puStack_2c8 = (uint *)0x0;
          if (*(ushort *)((longlong)plStack_268 + 0x62) != 0) {
            puVar32 = puStack_260 + 0xe;
            puStack_2b0 = (undefined8 *)(ulonglong)*(ushort *)((longlong)plStack_268 + 0x62);
            do {
              puVar3 = puVar32 + -0xe;
              uVar36 = *puVar3;
              *(undefined8 *)(puVar30 + -8) = 0x101f77;
              func_0x(&plStack_268,puVar3,&lStack_2d8);
              plVar22 = plStack_2d0;
              if ((char)lStack_2d8 == '\x03') {
                if (((*(ushort *)(*(longlong *)(puVar32 + 4) + 0xc) & 0x400) == 0) &&
                   ((puVar32[2] & 0x4000) == 0)) {
                  *(undefined8 *)(puVar30 + -8) = 0x10228a;
                  (*_DAT_)(6,0x51,0x10,3);
                }
                plVar22 = plStack_2d0;
                *(undefined8 *)(puVar30 + -8) = 0x10229c;
                func_0x(plVar22,puVar3,0,0);
                plVar20 = plStack_2d0;
                if ((int)uVar36 < 0) {
                  puVar3 = (uint *)((longlong)(int)~uVar36 * 0x20 + 0xc + (longlong)plVar9);
                  *puVar3 = *puVar3 | 2;
                }
              }
              else {
                if (*(short *)(puVar32 + -0xd) != 0) {
                  psVar2 = (short *)((longlong)plStack_2d0 + 2);
                  if (*(short *)plStack_2d0 == 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x101f9e;
                    func_0x();
                  }
                  else {
                    *(undefined8 *)(puVar30 + -8) = 0x101fa5;
                    func_0x(psVar2,puVar3);
                  }
                }
                *(undefined8 *)(puVar30 + -8) = 0x101fb5;
                func_0x(&plStack_268,puVar3,&puStack_2c8);
                puVar8 = puStack_2c8;
                plVar20 = plStack_2d0;
                cVar11 = *(char *)(puVar32 + 2);
                if ((cVar11 == '\x01') || (cVar11 == '\x02')) {
                  if ((puVar32[2] >> 8 & 1) == 0) {
                    uVar36 = *puVar3;
                    lVar17 = plStack_2d0[1];
                    uVar5 = *(undefined2 *)(puVar32 + 1);
                    *(undefined8 *)(puVar30 + -8) = 0x102133;
                    func_0x((int)uVar36 + lVar17,puVar8,uVar5);
                  }
                  else {
                    if (((puVar32[2] >> 0xf & 1) == 0) || ((uStack_254 & 8) == 0)) {
                      lVar17 = lStack_250;
                      if ((*(byte *)(*(longlong *)(puVar32 + 4) + 0x2a) & 0x10) != 0) {
                        lVar17 = lStack_248;
                      }
                      uVar36 = *(uint *)(*(longlong *)(*(longlong *)(puVar32 + 4) + 0x18) + lVar17);
                    }
                    else {
                      uVar36 = *(uint *)(lStack_230 + (ulonglong)*puVar32 * 8);
                    }
                    uVar37 = (uint)*(ushort *)(puVar32 + 1);
                    if (uVar36 < uVar37) {
                      uVar31 = uVar37 - uVar36;
                    }
                    else {
                      uVar31 = uVar15;
                      if (uVar37 < uVar36) {
                        *(undefined8 *)(puVar30 + -8) = 0x1021a9;
                        (*_DAT_)(6,0x5c,0x16);
                      }
                    }
                    uStack_2c0 = *(undefined *)(*(longlong *)(puVar32 + 4) + 0x24);
                    uVar37 = *puVar3;
                    lVar17 = plStack_2d0[1];
                    if ((puVar8 != (uint *)0x0) && (uVar36 != 0)) {
                      *(undefined8 *)(puVar30 + -8) = 0x1021d6;
                      func_0x((int)uVar37 + lVar17,puVar8,uVar36);
                    }
                    uVar23 = uStack_2c0;
                    plVar20 = plStack_2d0;
                    if (uVar31 != 0) {
                      *(undefined8 *)(puVar30 + -8) = 0x1021ef;
                      func_0x
                                ((ulonglong)uVar36 + (int)uVar37 + lVar17,uVar23,uVar31);
                      plVar20 = plStack_2d0;
                    }
                  }
                }
                else if ((cVar11 == '\x03') || (cVar11 == '\x04')) {
                  uVar37 = puVar32[2];
                  if (((uVar37 >> 0xd & 1) == 0) || (uVar31 = uVar15, *puStack_2c8 != 0)) {
                    if (((uVar37 & 0x8000) == 0) || ((uStack_254 & 8) == 0)) {
                      lVar17 = *(longlong *)(puVar32 + 4);
                      if ((uVar37 >> 8 & 1) == 0) {
                        uVar31 = (uint)*(ushort *)(lVar17 + 2);
                      }
                      else {
                        lVar18 = lStack_250;
                        if ((*(byte *)(lVar17 + 0x2a) & 0x10) != 0) {
                          lVar18 = lStack_248;
                        }
                        uVar31 = *(uint *)(*(longlong *)(lVar17 + 0x18) + lVar18);
                      }
                    }
                    else {
                      uVar31 = *(uint *)(lStack_230 + (ulonglong)*puVar32 * 8);
                    }
                  }
                  if (*(ushort *)(puVar32 + 1) < uVar31) {
                    *(undefined8 *)(puVar30 + -8) = 0x1020e1;
                    (*_DAT_)(6,0x52,0x16);
                  }
                  puVar8 = puStack_2c8;
                  *(undefined4 *)(puVar30 + 0x28) = 0;
                  *(uint **)(puVar30 + 0x20) = puVar3;
                  *(undefined8 *)(puVar30 + -8) = 0x102109;
                  func_0x(plVar9 + (longlong)(int)~uVar36 * 4,puVar8,uVar31);
                  plVar20 = plStack_2d0;
                }
                else if (cVar11 == '\b') {
                  if (*(short *)plVar22 == 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x102031;
                    func_0x(plVar20,puVar3,puVar8);
                  }
                  else {
                    *(undefined4 *)(puVar30 + 0x28) = 0;
                    *(uint **)(puVar30 + 0x20) = puVar3;
                    puVar3 = puStack_2c8;
                    *(undefined8 *)(puVar30 + -8) = 0x102061;
                    func_0x(plVar9 + (longlong)(int)~uVar36 * 4,puVar3,1);
                    plVar20 = plStack_2d0;
                  }
                }
                else {
                  *(undefined8 *)(puVar30 + 0x20) = 0x795b68;
                  *(undefined8 *)(puVar30 + -8) = 0x10200d;
                  (*_DAT_)(1,0xb9a9c0,0xbc7300);
                  plVar20 = plStack_2d0;
                }
              }
              puVar32 = puVar32 + 0x14;
              puStack_2b0 = (undefined8 *)((longlong)puStack_2b0 + -1);
              plVar22 = plStack_2b8;
              uVar37 = uStack_2a4;
              uVar31 = uStack_2bc;
              uVar36 = uStack_2a0;
            } while (puStack_2b0 != (undefined8 *)0x0);
          }
          uVar15 = uStack_2a4;
          if (uVar36 != 0) {
            if (*(short *)plVar20 == 0) {
              do {
                uVar27 = (ulonglong)uVar36;
                uVar37 = uVar36 - 1;
                if (*(int *)(plVar22 + (ulonglong)uVar37 * 4 + 1) != 0) {
                  *(short *)((longlong)plVar20 + 0x1c) = (short)uVar36;
                  iVar25 = *(int *)((longlong)plVar20 + 0x14) + 2 + uVar36 * 2;
                  *(int *)(plVar20 + 3) = iVar25;
                  *(int *)((longlong)plVar20 + 4) = iVar25;
                  *(byte *)plVar20[1] = *(byte *)plVar20[1] | 0x20;
                  if (*(uint *)((longlong)plVar20 + 4) <= uStack_2bc) {
                    plVar39 = (longlong *)
                              ((ulonglong)*(uint *)((longlong)plVar20 + 0x14) + plVar20[1]);
                    *(short *)plVar39 = (short)uVar36;
                  }
                  if (uVar36 != 0) {
                    puVar32 = (uint *)((longlong)plVar22 + 0xc);
                    uVar36 = uStack_2bc;
                    do {
                      plVar39 = (longlong *)((longlong)plVar39 + 2);
                      uVar31 = *(uint *)((longlong)plVar20 + 4);
                      lVar17 = plVar20[1];
                      uVar33 = puVar32[-1];
                      uVar37 = uVar31 + uVar33;
                      *(uint *)((longlong)plVar20 + 4) = uVar37;
                      if ((uVar37 <= uVar36) && (uVar37 <= uVar15)) {
                        *(ushort *)plVar39 =
                             (ushort)((*puVar32 & 1) << 0xf) | (ushort)uVar37 & 0x7fff;
                        uVar19 = *(undefined8 *)(puVar32 + -3);
                        *(undefined8 *)(puVar30 + -8) = 0x102350;
                        func_0x((ulonglong)uVar31 + lVar17,uVar33,uVar19,uVar33);
                        uVar36 = uStack_2bc;
                      }
                      puVar32 = puVar32 + 8;
                      uVar27 = uVar27 - 1;
                    } while (uVar27 != 0);
                  }
                  break;
                }
                uVar36 = uVar37;
              } while (uVar37 != 0);
            }
            else {
              *(undefined **)(puVar30 + 0x28) = auStack_284;
              *(longlong **)(puVar30 + 0x20) = plVar22;
              *(undefined8 *)(puVar30 + -8) = 0x102382;
              func_0x((short *)((longlong)plVar20 + 2),uVar37,uVar31,uVar36);
            }
          }
        }
        else {
          *(short *)plVar20 = 0;
          puVar1 = (ushort *)((longlong)plVar22 + 10);
          plVar20 = plVar39;
          if ((uStack_254 & 0x10) != 0) {
            plVar20 = plStack_268;
          }
          uVar31 = -*(int *)(plVar20 + 2);
          uVar23 = 0;
          if (bVar35 == 0) {
            uVar23 = 6;
          }
          iVar25 = 4;
          if (bVar35 == 0) {
            iVar25 = 1;
          }
          iVar24 = *(int *)((longlong)plVar20 + 0x14);
          uStack_2a0 = uVar31;
          puVar30[0x28] = uVar23;
          *(int *)(puVar30 + 0x20) = *(int *)(plVar20 + 3);
          *(undefined8 *)(puVar30 + -8) = 0x1005c7;
          func_0x(puVar1,lVar17,uVar37,iVar24 - iVar25);
          plVar20 = plVar39;
          if (uVar31 != 0) {
            *(undefined8 *)(puVar30 + -8) = 0x1005ef;
            lVar17 = func_0x();
            lVar17 = -lVar17;
            plVar20 = (longlong *)(puVar30 + lVar17 + 0x50);
            plStack_2b8 = plVar20;
            *(undefined8 *)(puVar30 + lVar17 + -8) = 0x100605;
            func_0x(plVar20,0);
            puVar30 = puVar30 + lVar17;
          }
          uStack_1f0 = (uint)*(ushort *)((longlong)plStack_268 + 0x62);
          plStack_280 = (longlong *)0x0;
          uStack_288 = 0;
          puStack_2c8 = puStack_260;
          puVar32 = puStack_260;
          if (uStack_1f0 != 0) {
            do {
              uVar37 = *puVar32;
              puStack_2c8 = puVar32;
              *(undefined8 *)(puVar30 + -8) = 0x100651;
              func_0x(&plStack_268,puVar32,&lStack_2d8);
              if ((char)lStack_2d8 == '\x03') {
                if (((*(ushort *)(*(longlong *)(puVar32 + 0x12) + 0xc) & 0x400) == 0) &&
                   ((puVar32[0x10] & 0x4000) == 0)) {
                  *(undefined8 *)(puVar30 + -8) = 0x101dc8;
                  (*_DAT_)(6,0x51,0x10,3);
                }
                *(undefined8 *)(puVar30 + -8) = 0x101dd9;
                func_0x(puVar1,puVar32,0,0);
                puStack_2c8 = puVar32;
                if ((int)uVar37 < 0) {
                  puVar3 = (uint *)((longlong)(int)~uVar37 * 0x20 + 0xc + (longlong)plVar20);
                  *puVar3 = *puVar3 | 2;
                }
              }
              else {
                if (*(short *)(puVar32 + 1) != 0) {
                  *(undefined8 *)(puVar30 + -8) = 0x10066f;
                  func_0x(puVar1,puVar32);
                }
                *(undefined8 *)(puVar30 + -8) = 0x10067f;
                func_0x(&plStack_268,puVar32,&plStack_280);
                plVar9 = plStack_280;
                cVar11 = *(char *)(puVar32 + 0x10);
                if ((cVar11 == '\x01') || (cVar11 == '\x02')) {
                  if ((puVar32[0x10] >> 8 & 1) == 0) {
                    uVar37 = *puVar32;
                    lVar17 = plVar22[2];
                    uVar5 = *(undefined2 *)(puVar32 + 0xf);
                    *(undefined8 *)(puVar30 + -8) = 0x101cde;
                    func_0x((int)uVar37 + lVar17,plVar9,uVar5);
                    puStack_2c8 = puVar32;
                  }
                  else {
                    if (((puVar32[0x10] & 0x8000) == 0) || ((uStack_254 & 8) == 0)) {
                      lVar17 = lStack_250;
                      if ((*(byte *)(*(longlong *)(puVar32 + 0x12) + 0x2a) & 0x10) != 0) {
                        lVar17 = lStack_248;
                      }
                      uVar37 = *(uint *)(*(longlong *)(*(longlong *)(puVar32 + 0x12) + 0x18) +
                                        lVar17);
                    }
                    else {
                      uVar37 = *(uint *)(lStack_230 + (ulonglong)puVar32[0xe] * 8);
                    }
                    uVar31 = (uint)*(ushort *)(puVar32 + 0xf);
                    if (uVar37 < uVar31) {
                      uVar33 = uVar31 - uVar37;
                    }
                    else {
                      uVar33 = uVar15;
                      if (uVar31 < uVar37) {
                        *(undefined8 *)(puVar30 + -8) = 0x101d4d;
                        (*_DAT_)(6,0x5c,0x16);
                      }
                    }
                    uVar23 = *(undefined *)(*(longlong *)(puVar32 + 0x12) + 0x24);
                    uVar31 = *puStack_2c8;
                    lVar17 = plVar22[2];
                    if ((plVar9 != (longlong *)0x0) && (uVar37 != 0)) {
                      *(undefined8 *)(puVar30 + -8) = 0x101d79;
                      func_0x((int)uVar31 + lVar17,plVar9,uVar37);
                    }
                    if (uVar33 != 0) {
                      *(undefined8 *)(puVar30 + -8) = 0x101d92;
                      func_0x
                                ((ulonglong)uVar37 + (int)uVar31 + lVar17,uVar23,uVar33);
                    }
                  }
                }
                else if ((cVar11 == '\x03') || (cVar11 == '\x04')) {
                  uVar31 = puVar32[0x10];
                  if (((uVar31 >> 0xd & 1) == 0) || (uVar33 = uVar36, *(int *)plStack_280 != 0)) {
                    if (((uVar31 & 0x8000) == 0) || ((uStack_254 & 8) == 0)) {
                      lVar17 = *(longlong *)(puVar32 + 0x12);
                      if ((uVar31 >> 8 & 1) == 0) {
                        uVar33 = (uint)*(ushort *)(lVar17 + 2);
                      }
                      else {
                        lVar18 = lStack_250;
                        if ((*(byte *)(lVar17 + 0x2a) & 0x10) != 0) {
                          lVar18 = lStack_248;
                        }
                        uVar33 = *(uint *)(*(longlong *)(lVar17 + 0x18) + lVar18);
                      }
                    }
                    else {
                      uVar33 = *(uint *)(lStack_230 + (ulonglong)puVar32[0xe] * 8);
                    }
                  }
                  if (*(ushort *)(puVar32 + 0xf) < uVar33) {
                    *(undefined8 *)(puVar30 + -8) = 0x101c8c;
                    (*_DAT_)(6,0x52,0x16);
                  }
                  plVar9 = plStack_280;
                  *(undefined4 *)(puVar30 + 0x28) = 0;
                  *(uint **)(puVar30 + 0x20) = puVar32;
                  *(undefined8 *)(puVar30 + -8) = 0x101cb4;
                  func_0x(plVar20 + (longlong)(int)~uVar37 * 4,plVar9,uVar33);
                  puStack_2c8 = puVar32;
                }
                else if (cVar11 == '\b') {
                  plStack_278 = plStack_280;
                  uVar37 = *puVar32;
                  lVar17 = (longlong)(int)uVar37;
                  if ((int)uVar37 < 0) {
                    if ((uVar37 & 0xc0000000) == 0x80000000) {
                      *(undefined8 *)(puVar30 + -8) = 0x10146a;
                      func_0x(auStack_128);
                      iStack_2a8 = 0;
                      if (*(int *)((longlong)plVar22 + 0xc) == 0) {
                        *puVar1 = 0;
                        uVar37 = *(uint *)(plVar22 + 3);
                        uVar27 = (ulonglong)uVar37;
                        *(uint *)((longlong)plVar22 + 0x1c) = uVar37;
                        pbVar21 = (byte *)plVar22[2];
                        bVar35 = *pbVar21;
                        if ((bVar35 & 0x10) != 0) {
                          uVar37 = uVar37 + 2 + (*(ushort *)(pbVar21 + uVar27) + 7 >> 3);
                          uVar27 = (ulonglong)uVar37;
                          *(uint *)((longlong)plVar22 + 0x1c) = uVar37;
                          bVar35 = *pbVar21;
                        }
                        if ((bVar35 & 0x20) == 0) {
                          *(int *)((longlong)plVar22 + 0xc) = (int)uVar27;
                          *(short *)((longlong)plVar22 + 0x24) = 0;
                          *(int *)(plVar22 + 4) = (int)uVar27;
                        }
                        else {
                          puVar38 = (ushort *)(pbVar21 + uVar27);
                          uVar13 = *puVar38;
                          *(ushort *)((longlong)plVar22 + 0x24) = uVar13;
                          if (uVar13 == 0) {
                            *(undefined8 *)(puVar30 + -8) = 0x1014d1;
                            cVar11 = func_0x(0x1128900);
                            if (cVar11 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x1014da;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x1014f4;
                                cVar11 = func_0x(0x1128900);
                                if (cVar11 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x101510;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x101536;
                                  (*_DAT_)(1,0xa19688,0xb39358,0x80f);
                                }
                              }
                            }
                            lVar17 = plVar22[2];
                            *(undefined8 *)(puVar30 + -8) = 0x101544;
                            func_0x(lVar17,3);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0x1c);
                            pbVar21 = (byte *)plVar22[2];
                            uVar13 = *(ushort *)((longlong)plVar22 + 0x24);
                          }
                          uVar37 = (int)uVar27 + (uVar13 + 1) * 2;
                          *(uint *)(plVar22 + 4) = uVar37;
                          if (0x1f9e < uVar37) {
                            *(undefined8 *)(puVar30 + -8) = 0x101578;
                            cVar11 = func_0x(0x1128900);
                            if (cVar11 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x101581;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x10159b;
                                cVar11 = func_0x(0x1128900);
                                if (cVar11 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x1015b7;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x1015dd;
                                  (*_DAT_)(1,0xa19688,0xb39358,0x816);
                                }
                              }
                            }
                            lVar17 = plVar22[2];
                            *(undefined8 *)(puVar30 + -8) = 0x1015eb;
                            func_0x(lVar17,4);
                            uVar13 = *(ushort *)((longlong)plVar22 + 0x24);
                            pbVar21 = (byte *)plVar22[2];
                            uVar37 = *(uint *)(plVar22 + 4);
                          }
                          uVar27 = (ulonglong)uVar13;
                          uVar13 = puVar38[uVar27];
                          *(uint *)((longlong)plVar22 + 0xc) = uVar13 & 0x7fff;
                          if ((uVar13 & 0x7fff) < uVar37) {
                            *(undefined8 *)(puVar30 + -8) = 0x10161c;
                            cVar11 = func_0x(0x1128900);
                            if (cVar11 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x101625;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x10163f;
                                cVar11 = func_0x(0x1128900);
                                if (cVar11 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x10165b;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x101681;
                                  (*_DAT_)(1,0xa19688,0xb39358,0x81d);
                                }
                              }
                            }
                            lVar17 = plVar22[2];
                            *(undefined8 *)(puVar30 + -8) = 0x10168f;
                            func_0x(lVar17,4);
                            uVar27 = (ulonglong)*(ushort *)((longlong)plVar22 + 0x24);
                            pbVar21 = (byte *)plVar22[2];
                          }
                          uVar34 = uVar27;
                          if ((short)puVar38[(ulonglong)((int)uVar27 - 1) + 1] < 0) {
                            do {
                              sVar12 = (short)uVar34;
                              uVar37 = *(uint *)((longlong)plVar22 + 0x1c);
                              if ((int)uVar27 == 1) {
                                uVar31 = *(uint *)(plVar22 + 4);
                                uVar13 = *(ushort *)(pbVar21 + uVar27 * 2 + (ulonglong)uVar37);
                                uVar33 = uVar31;
LAB_:
                                if ((uVar13 & 0x7fff) < uVar31) goto LAB_;
                              }
                              else {
                                uVar31 = *(ushort *)(pbVar21 + uVar27 * 2 + ((ulonglong)uVar37 - 2))
                                         & 0x7fff;
                                uVar33 = *(uint *)(plVar22 + 4);
                                uVar13 = *(ushort *)(pbVar21 + uVar27 * 2 + (ulonglong)uVar37);
                                if (uVar33 <= uVar31) goto LAB_;
LAB_:
                                *(undefined8 *)(puVar30 + -8) = 0x1016f6;
                                func_0x(pbVar21,7);
                                uVar33 = *(uint *)(plVar22 + 4);
                                pbVar21 = (byte *)plVar22[2];
                                sVar12 = *(short *)((longlong)plVar22 + 0x24);
                              }
                              if ((uVar31 < uVar33) || (*(uint *)((longlong)plVar22 + 0xc) < uVar31)
                                 ) goto LAB_;
                              if (*(ushort *)(pbVar21 + uVar31) == 5) {
                                *puVar1 = *puVar1 | 2;
                                *(short *)((longlong)plVar22 + 0x24) = sVar12 + -1;
                                *(short *)((longlong)plVar22 + 0x32) = (short)uVar31;
                                lVar17 = (ulonglong)(uVar31 & 0xffff) + plVar22[2];
                                uVar13 = *(ushort *)(lVar17 + 2);
                                uVar14 = *(ushort *)((longlong)plVar22 + 0x34) & 0xc7ff;
                                if ((uVar13 >> 0xe & 1) != 0) {
                                  uVar14 = uVar13 & 0x3800 | uVar14;
                                }
                                *(ushort *)((longlong)plVar22 + 0x34) = uVar14;
                                *(ushort *)((longlong)plVar22 + 0x34) =
                                     (uVar14 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar14;
                                goto LAB_;
                              }
                              if (*(ushort *)(pbVar21 + uVar31) < 0x400) goto LAB_;
                              *puVar1 = *puVar1 | 1;
                              uVar13 = sVar12 - 1;
                              *(ushort *)((longlong)plVar22 + 0x24) = uVar13;
                              if (uVar13 == 0) goto LAB_;
                              uVar34 = (ulonglong)uVar13;
                              uVar27 = (ulonglong)(uint)uVar13;
                            } while ((short)puVar38[(ulonglong)(uVar13 - 1) + 1] < 0);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0xc);
                            pbVar21 = (byte *)plVar22[2];
                          }
                          else {
LAB_:
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0xc);
                            pbVar21 = (byte *)plVar22[2];
                          }
                        }
                        if ((*pbVar21 & 0x40) == 0) {
                          *(undefined4 *)((longlong)plVar22 + 0x2e) = 0;
                        }
                        else {
                          *(int *)((longlong)plVar22 + 0x2e) = (int)uVar27;
                          *(int *)((longlong)plVar22 + 0xc) = (int)uVar27 + 0xe;
                          *(undefined8 *)(puVar30 + -8) = 0x1017e6;
                          uVar19 = func_0x(puVar1);
                          *(undefined8 *)(puVar30 + -8) = 0x1017f5;
                          func_0x(uVar19,auStack_1c0);
                          *(undefined8 *)(puVar30 + -8) = 0x101801;
                          iVar25 = func_0x(auStack_1c0);
                          *(int *)((longlong)plVar22 + 0xc) =
                               *(int *)((longlong)plVar22 + 0xc) + iVar25;
                          uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0xc);
                          pbVar21 = (byte *)plVar22[2];
                        }
                        iVar25 = (int)uVar27;
                        if ((*(byte **)((longlong)plVar22 + 0x26) != (byte *)0x0) &&
                           (*(byte **)((longlong)plVar22 + 0x26) < pbVar21 + uVar27)) {
                          *(undefined8 *)(puVar30 + -8) = 0x101839;
                          cVar11 = func_0x(0x1128900);
                          if (cVar11 != '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x101842;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar30 + -8) = 0x10185c;
                              cVar11 = func_0x(0x1128900);
                              if (cVar11 == '\0') {
                                *(undefined8 *)(puVar30 + -8) = 0x101878;
                                (*_DAT_)(0x22,0x44,0x15,0x3fa);
                              }
                              else {
                                *(undefined8 *)(puVar30 + 0x20) = 0;
                                *(undefined8 *)(puVar30 + -8) = 0x10189e;
                                (*_DAT_)(1,0xa19688,0xb39358,0x877);
                              }
                            }
                          }
                          lVar17 = plVar22[2];
                          *(undefined8 *)(puVar30 + -8) = 0x1018ac;
                          func_0x(lVar17,0x12);
                          iVar25 = *(int *)((longlong)plVar22 + 0xc);
                        }
                        if (0x3f3b < iVar25 - 1U) {
                          *(undefined8 *)(puVar30 + -8) = 0x1018c5;
                          cVar11 = func_0x(0x1128900);
                          if (cVar11 != '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x1018ce;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar30 + -8) = 0x1018e8;
                              cVar11 = func_0x(0x1128900);
                              if (cVar11 == '\0') {
                                *(undefined8 *)(puVar30 + -8) = 0x101904;
                                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                              }
                              else {
                                *(undefined8 *)(puVar30 + 0x20) = 0;
                                *(undefined8 *)(puVar30 + -8) = 0x10192a;
                                (*_DAT_)(1,0xa19688,0xb39358,0x87c);
                              }
                            }
                          }
                          lVar17 = plVar22[2];
                          *(undefined8 *)(puVar30 + -8) = 0x101938;
                          func_0x(lVar17,5);
                        }
                      }
LAB_:
                      *(undefined8 *)(puVar30 + -8) = 0x101940;
                      func_0x(puVar1);
                      bVar35 = *(byte *)plVar22[2];
                      if ((bVar35 >> 6 & 1) != 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x101961;
                        func_0x(puVar1,auStack_128);
                      }
                      if ((*(byte *)puVar1 & 1) != 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x101977;
                        plVar20 = (longlong *)func_0x(puVar1,0x400,&iStack_2a8);
                        puStack_2b0 = (undefined8 *)*plVar20;
                      }
                      pbVar21 = (byte *)plVar22[2];
                      if ((*pbVar21 & 0x20) == 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x10199d;
                        func_0x(puVar1);
                        pbVar21 = (byte *)plVar22[2];
                      }
                      uVar37 = *(uint *)((longlong)plVar22 + 0x1c);
                      *(undefined8 *)(puVar30 + -8) = 0x1019b0;
                      iVar25 = func_0x(puVar1);
                      lVar17 = plVar22[2];
                      uVar13 = *(ushort *)((longlong)plVar22 + 0x24);
                      uVar27 = (ulonglong)uVar13;
                      puVar38 = (ushort *)(lVar17 + (ulonglong)*(uint *)((longlong)plVar22 + 0x1c));
                      uVar31 = (uint)uVar13;
                      if (iVar25 == 0) {
                        uVar33 = *(uint *)((longlong)plVar22 + 0x1c) + (uVar13 + 1) * 2;
                        plVar20 = plVar39;
                        if (*puVar38 != 0) {
                          do {
                            uVar14 = puVar38[(longlong)((longlong)plVar20 + 1)];
                            puVar38[((ulonglong)plVar20 & 0xffff) + 1] =
                                 puVar38[((ulonglong)plVar20 & 0xffff) + 1] & 0x8000;
                            puVar38[((ulonglong)plVar20 & 0xffff) + 1] =
                                 puVar38[((ulonglong)plVar20 & 0xffff) + 1] |
                                 (uVar14 & 0x7fff) + 2 & 0x7fff;
                            uVar28 = (int)plVar20 + 1;
                            plVar20 = (longlong *)(ulonglong)uVar28;
                          } while (uVar28 < *puVar38);
                          lVar17 = plVar22[2];
                        }
                        lVar17 = (ulonglong)uVar33 + lVar17;
                        iVar25 = *(int *)((longlong)plVar22 + 0xc);
                        *(undefined8 *)(puVar30 + -8) = 0x101a97;
                        func_0x(lVar17 + 2,lVar17,iVar25 - uVar33);
                        *(int *)((longlong)plVar22 + 0xc) = *(int *)((longlong)plVar22 + 0xc) + 2;
                        *(int *)(plVar22 + 4) = *(int *)(plVar22 + 4) + 2;
                        uVar14 = (ushort)*(int *)(plVar22 + 4);
                        if (uVar31 != 0) {
                          uVar14 = puVar38[(ulonglong)(uVar13 - 1) + 1] & 0x7fff;
                        }
                        if (uVar31 < uVar13 + 1) {
                          do {
                            puVar38[(uVar27 & 0xffff) + 1] = uVar14 & 0x7fff;
                            uVar31 = (int)uVar27 + 1;
                            uVar27 = (ulonglong)uVar31;
                          } while (uVar31 < uVar13 + 1);
                        }
                        *puVar38 = *puVar38 + 1;
                        *(undefined8 *)(puVar30 + -8) = 0x101adb;
                        func_0x(puVar1);
                        uVar13 = *(ushort *)
                                  (pbVar21 +
                                  (ulonglong)*(ushort *)((longlong)plVar22 + 0x24) * 2 +
                                  (ulonglong)uVar37 + 2);
                        *(undefined8 *)(puVar30 + -8) = 0x101af4;
                        func_0x(auStack_178);
                        *(undefined4 *)(puVar30 + 0x28) = 0;
                        *(uint **)(puVar30 + 0x20) = puStack_2c8;
                        plVar20 = plStack_278;
                        *(undefined8 *)(puVar30 + -8) = 0x101b18;
                        func_0x(auStack_188,plVar20,1);
                        *(int **)(puVar30 + 0x28) = &iStack_1f4;
                        *(undefined **)(puVar30 + 0x20) = auStack_188;
                        *(undefined8 *)(puVar30 + -8) = 0x101b50;
                        func_0x((short *)((longlong)plVar22 + 0x32),uVar13 & 0x7fff,0x1f9e);
                        uVar31 = uVar36;
                        iVar25 = iStack_1f4;
                      }
                      else {
                        if (uVar31 == 0) {
                          uVar31 = *(uint *)(plStack_2d0 + 3);
                          uVar33 = puVar38[uVar27 + 1] & 0x7fff;
LAB_:
                          if (uVar33 < uVar31) goto LAB_;
                        }
                        else {
                          uVar31 = puVar38[uVar27] & 0x7fff;
                          uVar33 = puVar38[uVar27 + 1] & 0x7fff;
                          if (*(uint *)(plStack_2d0 + 3) <= uVar31) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar30 + -8) = 0x101a07;
                          func_0x(lVar17,7);
                        }
                        plVar20 = plStack_278;
                        puVar32 = puStack_2c8;
                        *(undefined8 *)(puVar30 + -8) = 0x101a24;
                        iVar25 = func_0x((short *)((longlong)plVar22 + 0x32),puVar32,plVar20
                                                );
                        uVar31 = uVar33 - uVar31;
                      }
                      iVar24 = (*(int *)((longlong)plVar22 + 0xc) - uVar31) + iVar25;
                      *(int *)((longlong)plVar22 + 0xc) = iVar24;
                      if ((*(byte *)puVar1 & 1) != 0) {
                        *(ushort *)
                         (pbVar21 +
                         (ulonglong)*(ushort *)((longlong)plVar22 + 0x24) * 2 +
                         (ulonglong)uVar37 + 4) = (ushort)iVar24 | 0x8000;
                        iVar24 = (*(int *)((longlong)plVar22 + 0xc) - iStack_2a8) + -2;
                      }
                      *(ushort *)
                       (pbVar21 +
                       (ulonglong)*(ushort *)((longlong)plVar22 + 0x24) * 2 + (ulonglong)uVar37 + 2)
                           = (ushort)iVar24 | 0x8000;
                      if (iVar25 == 0) {
                        uVar13 = *(ushort *)((longlong)plVar22 + 0x24);
                        *(undefined8 *)(puVar30 + -8) = 0x101ba3;
                        func_0x(puVar1,uVar13 + 1,0);
                        if ((*(byte *)plVar22[2] & 0x20) != 0) {
                          *(short *)(int *)((longlong)plVar22 + 0x24) =
                               *(short *)(int *)((longlong)plVar22 + 0x24) + 1;
                          *puVar1 = *puVar1 & 0xfffd;
                          *(undefined8 *)(puVar30 + -8) = 0x101bc0;
                          func_0x((short *)((longlong)plVar22 + 0x32));
                        }
                      }
                      else {
                        *puVar1 = *puVar1 | 2;
                        *(undefined8 *)(puVar30 + -8) = 0x101bcf;
                        sVar12 = func_0x(puVar1,auStack_284);
                        *(short *)((longlong)plVar22 + 0x32) = sVar12;
                      }
                      iVar25 = iStack_2a8;
                      if ((*(byte *)puVar1 & 1) != 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x101bed;
                        func_0x(puVar1,0x400,iVar25);
                      }
                      if ((bVar35 >> 6 & 1) != 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x101c01;
                        func_0x(puVar1,auStack_128);
                      }
                    }
                    else {
                      if (*(int *)((longlong)plVar22 + 0xc) == 0) {
                        *puVar1 = 0;
                        uVar37 = *(uint *)(plVar22 + 3);
                        uVar27 = (ulonglong)uVar37;
                        *(uint *)((longlong)plVar22 + 0x1c) = uVar37;
                        pbVar21 = (byte *)plVar22[2];
                        bVar35 = *pbVar21;
                        if ((bVar35 & 0x10) != 0) {
                          uVar37 = uVar37 + (*(ushort *)(pbVar21 + uVar27) + 7 >> 3) + 2;
                          uVar27 = (ulonglong)uVar37;
                          *(uint *)((longlong)plVar22 + 0x1c) = uVar37;
                          bVar35 = *pbVar21;
                        }
                        if ((bVar35 & 0x20) == 0) {
                          *(int *)((longlong)plVar22 + 0xc) = (int)uVar27;
                          *(short *)((longlong)plVar22 + 0x24) = 0;
                          *(int *)(plVar22 + 4) = (int)uVar27;
                        }
                        else {
                          puVar38 = (ushort *)(pbVar21 + uVar27);
                          uVar13 = *puVar38;
                          *(ushort *)((longlong)plVar22 + 0x24) = uVar13;
                          if (uVar13 == 0) {
                            *(undefined8 *)(puVar30 + -8) = 0x100d1b;
                            cVar11 = func_0x(0x1128900);
                            if (cVar11 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100d24;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x100d3e;
                                cVar11 = func_0x(0x1128900);
                                if (cVar11 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x100d5a;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x100d80;
                                  (*_DAT_)(1,0xa19688,0xb39358,0x80f);
                                }
                              }
                            }
                            lVar17 = plVar22[2];
                            *(undefined8 *)(puVar30 + -8) = 0x100d8e;
                            func_0x(lVar17,3);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0x1c);
                            uVar13 = *(ushort *)((longlong)plVar22 + 0x24);
                          }
                          uVar37 = (int)uVar27 + (uVar13 + 1) * 2;
                          *(uint *)(plVar22 + 4) = uVar37;
                          if (0x1f9e < uVar37) {
                            *(undefined8 *)(puVar30 + -8) = 0x100dbe;
                            cVar11 = func_0x(0x1128900);
                            if (cVar11 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100dc7;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x100de1;
                                cVar11 = func_0x(0x1128900);
                                if (cVar11 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x100dfd;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x100e23;
                                  (*_DAT_)(1,0xa19688,0xb39358,0x816);
                                }
                              }
                            }
                            lVar17 = plVar22[2];
                            *(undefined8 *)(puVar30 + -8) = 0x100e31;
                            func_0x(lVar17,4);
                            uVar13 = *(ushort *)((longlong)plVar22 + 0x24);
                            uVar37 = *(uint *)(plVar22 + 4);
                          }
                          uVar27 = (ulonglong)uVar13;
                          uVar13 = puVar38[uVar27];
                          *(uint *)((longlong)plVar22 + 0xc) = uVar13 & 0x7fff;
                          if ((uVar13 & 0x7fff) < uVar37) {
                            *(undefined8 *)(puVar30 + -8) = 0x100e5e;
                            cVar11 = func_0x(0x1128900);
                            if (cVar11 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100e67;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x100e81;
                                cVar11 = func_0x(0x1128900);
                                if (cVar11 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x100e9d;
                                  (*_DAT_)(0x22,0x44,0x15);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x100ec3;
                                  (*_DAT_)(1,0xa19688,0xb39358);
                                }
                              }
                            }
                            lVar17 = plVar22[2];
                            *(undefined8 *)(puVar30 + -8) = 0x100ed1;
                            func_0x(lVar17,4);
                            uVar27 = (ulonglong)*(ushort *)((longlong)plVar22 + 0x24);
                          }
                          if ((short)puVar38[(ulonglong)((int)uVar27 - 1) + 1] < 0) {
                            pbVar21 = (byte *)plVar22[2];
                            do {
                              uVar37 = *(uint *)((longlong)plVar22 + 0x1c);
                              if ((int)uVar27 == 1) {
                                uVar31 = *(uint *)(plVar22 + 4);
                                uVar13 = *(ushort *)(pbVar21 + uVar27 * 2 + (ulonglong)uVar37);
                                uVar33 = uVar31;
LAB_:
                                if ((uVar13 & 0x7fff) < uVar31) goto LAB_;
                              }
                              else {
                                uVar31 = *(ushort *)(pbVar21 + uVar27 * 2 + ((ulonglong)uVar37 - 2))
                                         & 0x7fff;
                                uVar33 = *(uint *)(plVar22 + 4);
                                uVar13 = *(ushort *)(pbVar21 + uVar27 * 2 + (ulonglong)uVar37);
                                if (uVar33 <= uVar31) goto LAB_;
LAB_:
                                *(undefined8 *)(puVar30 + -8) = 0x100f34;
                                func_0x(pbVar21,7);
                                uVar33 = *(uint *)(plVar22 + 4);
                              }
                              if ((uVar31 < uVar33) || (*(uint *)((longlong)plVar22 + 0xc) < uVar31)
                                 ) goto LAB_;
                              pbVar21 = (byte *)plVar22[2];
                              if (*(ushort *)(pbVar21 + uVar31) == 5) {
                                *puVar1 = *puVar1 | 2;
                                *(short *)(int *)((longlong)plVar22 + 0x24) =
                                     *(short *)(int *)((longlong)plVar22 + 0x24) + -1;
                                *(short *)((longlong)plVar22 + 0x32) = (short)uVar31;
                                uVar13 = *(ushort *)((longlong)plVar22 + 0x34) & 0xc7ff;
                                if ((*(ushort *)(pbVar21 + (ulonglong)(uVar31 & 0xffff) + 2) >> 0xe
                                    & 1) != 0) {
                                  uVar13 = *(ushort *)(pbVar21 + (ulonglong)(uVar31 & 0xffff) + 2) &
                                           0x3800 | uVar13;
                                }
                                *(ushort *)((longlong)plVar22 + 0x34) = uVar13;
                                *(ushort *)((longlong)plVar22 + 0x34) =
                                     (uVar13 ^ *(ushort *)
                                                (pbVar21 + (ulonglong)(uVar31 & 0xffff) + 2)) &
                                     0x7ff ^ uVar13;
                                goto LAB_;
                              }
                              if (*(ushort *)(pbVar21 + uVar31) < 0x400) goto LAB_;
                              *puVar1 = *puVar1 | 1;
                              uVar13 = *(short *)((longlong)plVar22 + 0x24) - 1;
                              *(ushort *)((longlong)plVar22 + 0x24) = uVar13;
                              if (uVar13 == 0) goto LAB_;
                              uVar27 = (ulonglong)uVar13;
                            } while ((short)puVar38[(ulonglong)(uVar13 - 1) + 1] < 0);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0xc);
                          }
                          else {
LAB_:
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0xc);
                            pbVar21 = (byte *)plVar22[2];
                          }
                        }
                        if ((*pbVar21 & 0x40) == 0) {
                          *(undefined4 *)((longlong)plVar22 + 0x2e) = 0;
                        }
                        else {
                          *(int *)((longlong)plVar22 + 0x2e) = (int)uVar27;
                          *(int *)((longlong)plVar22 + 0xc) = (int)uVar27 + 0xe;
                          *(undefined8 *)(puVar30 + -8) = 0x10101d;
                          uVar19 = func_0x(puVar1);
                          *(undefined8 *)(puVar30 + -8) = 0x10102c;
                          func_0x(uVar19,auStack_1c8);
                          *(undefined8 *)(puVar30 + -8) = 0x101038;
                          iVar25 = func_0x(auStack_1c8);
                          *(int *)((longlong)plVar22 + 0xc) =
                               *(int *)((longlong)plVar22 + 0xc) + iVar25;
                          uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0xc);
                        }
                        iVar25 = (int)uVar27;
                        if ((*(ulonglong *)((longlong)plVar22 + 0x26) != 0) &&
                           (*(ulonglong *)((longlong)plVar22 + 0x26) < uVar27 + plVar22[2])) {
                          *(undefined8 *)(puVar30 + -8) = 0x10106d;
                          cVar11 = func_0x(0x1128900);
                          if (cVar11 != '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x101076;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar30 + -8) = 0x101090;
                              cVar11 = func_0x(0x1128900);
                              if (cVar11 == '\0') {
                                *(undefined8 *)(puVar30 + -8) = 0x1010ac;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar30 + 0x20) = 0;
                                *(undefined8 *)(puVar30 + -8) = 0x1010d2;
                                (*_DAT_)(1,0xa19688,0xb39358);
                              }
                            }
                          }
                          lVar17 = plVar22[2];
                          *(undefined8 *)(puVar30 + -8) = 0x1010e0;
                          func_0x(lVar17,0x12);
                          iVar25 = *(int *)((longlong)plVar22 + 0xc);
                        }
                        if (0x3f3b < iVar25 - 1U) {
                          *(undefined8 *)(puVar30 + -8) = 0x1010f9;
                          cVar11 = func_0x(0x1128900);
                          if (cVar11 != '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x101102;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar30 + -8) = 0x10111c;
                              cVar11 = func_0x(0x1128900);
                              if (cVar11 == '\0') {
                                *(undefined8 *)(puVar30 + -8) = 0x101138;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar30 + 0x20) = 0;
                                *(undefined8 *)(puVar30 + -8) = 0x10115e;
                                (*_DAT_)(1,0xa19688,0xb39358);
                              }
                            }
                          }
                          lVar17 = plVar22[2];
                          *(undefined8 *)(puVar30 + -8) = 0x10116c;
                          func_0x(lVar17,5);
                        }
                      }
LAB_:
                      uVar37 = -*puVar32;
                      *(undefined8 *)(puVar30 + -8) = 0x10117f;
                      func_0x(auStack_128);
                      pbVar21 = (byte *)plVar22[2];
                      bVar35 = *pbVar21;
                      uStack_1f8 = bVar35 >> 6 & 1;
                      if ((bVar35 >> 6 & 1) != 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x1011a6;
                        func_0x(puVar1,auStack_128);
                        pbVar21 = (byte *)plVar22[2];
                        bVar35 = *pbVar21;
                      }
                      if ((bVar35 & 0x20) == 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x1011ba;
                        func_0x(puVar1);
                        pbVar21 = (byte *)plVar22[2];
                      }
                      uVar13 = *(ushort *)((longlong)plVar22 + 0x24);
                      uVar27 = (ulonglong)uVar13;
                      if (uVar13 < uVar37) {
                        iVar25 = uVar37 - uVar13;
                        puVar38 = (ushort *)(pbVar21 + *(uint *)((longlong)plVar22 + 0x1c));
                        uVar33 = *(uint *)((longlong)plVar22 + 0x1c) + (uVar13 + 1) * 2;
                        uVar31 = iVar25 * 2;
                        plVar20 = plVar39;
                        if (*puVar38 != 0) {
                          do {
                            uVar14 = puVar38[(longlong)((longlong)plVar20 + 1)];
                            puVar38[((ulonglong)plVar20 & 0xffff) + 1] =
                                 puVar38[((ulonglong)plVar20 & 0xffff) + 1] & 0x8000;
                            puVar38[((ulonglong)plVar20 & 0xffff) + 1] =
                                 puVar38[((ulonglong)plVar20 & 0xffff) + 1] |
                                 (uVar14 & 0x7fff) + (short)uVar31 & 0x7fff;
                            uVar28 = (int)plVar20 + 1;
                            plVar20 = (longlong *)(ulonglong)uVar28;
                          } while (uVar28 < *puVar38);
                          pbVar21 = (byte *)plVar22[2];
                        }
                        iVar24 = *(int *)((longlong)plVar22 + 0xc);
                        *(undefined8 *)(puVar30 + -8) = 0x10124f;
                        func_0x
                                  (pbVar21 + (ulonglong)uVar33 + (ulonglong)uVar31,pbVar21 + uVar33,
                                   iVar24 - uVar33);
                        *(int *)((longlong)plVar22 + 0xc) =
                             *(int *)((longlong)plVar22 + 0xc) + uVar31;
                        *(uint *)(plVar22 + 4) = *(int *)(plVar22 + 4) + uVar31;
                        uVar14 = (ushort)*(int *)(plVar22 + 4);
                        if (uVar13 != 0) {
                          uVar14 = puVar38[(ulonglong)(uVar13 - 1) + 1] & 0x7fff;
                        }
                        do {
                          puVar38[(uVar27 & 0xffff) + 1] = uVar14 & 0x7fff;
                          uVar31 = (int)uVar27 + 1;
                          uVar27 = (ulonglong)uVar31;
                        } while (uVar31 < uVar37);
                        *puVar38 = *puVar38 + (short)iVar25;
                        *(undefined8 *)(puVar30 + -8) = 0x10129c;
                        iVar25 = func_0x(puVar1);
                        if (iVar25 != 0) {
                          *(undefined8 *)(puVar30 + -8) = 0x1012af;
                          sVar12 = func_0x(puVar1,auStack_1e0);
                          *(short *)((longlong)plVar22 + 0x32) = sVar12;
                        }
                        *(short *)((longlong)plVar22 + 0x24) = (short)uVar37;
                        uVar27 = (ulonglong)(uVar37 & 0xffff);
                        pbVar21 = (byte *)plVar22[2];
                      }
                      uVar31 = *(uint *)((longlong)plVar22 + 0x1c);
                      if ((uint)uVar27 < uVar37) {
                        uVar33 = *(ushort *)(pbVar21 + uVar27 * 2 + (ulonglong)uVar31) & 0x7fff;
                        uVar31 = uVar36;
LAB_:
                        puVar38 = (ushort *)(pbVar21 + *(uint *)((longlong)plVar22 + 0x1c));
                        lVar17 = plVar22[2];
                        iVar25 = *(int *)((longlong)plVar22 + 0xc);
                        *(undefined8 *)(puVar30 + -8) = 0x101351;
                        uVar16 = func_0x(iVar25,uVar33 + uVar31);
                        *(undefined8 *)(puVar30 + -8) = 0x101363;
                        func_0x
                                  ((ulonglong)uVar33 + lVar17 + 1,
                                   (longlong)(int)uVar31 + (ulonglong)uVar33 + lVar17,uVar16);
                        uVar37 = uVar37 - 1;
                        if ((int)uVar37 < (int)(uint)*puVar38) {
                          do {
                            uVar13 = puVar38[(longlong)(int)uVar37 + 1];
                            puVar38[((ulonglong)uVar37 & 0xffff) + 1] =
                                 puVar38[((ulonglong)uVar37 & 0xffff) + 1] & 0x8000;
                            puVar38[((ulonglong)uVar37 & 0xffff) + 1] =
                                 puVar38[((ulonglong)uVar37 & 0xffff) + 1] |
                                 ((uVar13 & 0x7fff) - (short)uVar31) + 1 & 0x7fff;
                            uVar37 = uVar37 + 1;
                          } while ((int)uVar37 < (int)(uint)*puVar38);
                        }
                        *(int *)((longlong)plVar22 + 0xc) =
                             *(int *)((longlong)plVar22 + 0xc) + (1 - uVar31);
                        *(undefined8 *)(puVar30 + -8) = 0x1013c4;
                        iVar25 = func_0x(puVar1);
                        if (iVar25 != 0) {
                          *(undefined8 *)(puVar30 + -8) = 0x1013d7;
                          sVar12 = func_0x(puVar1,auStack_1dc);
                          *(short *)((longlong)plVar22 + 0x32) = sVar12;
                        }
                      }
                      else {
                        if (uVar37 == 1) {
                          uVar33 = *(uint *)(plStack_2d0 + 3);
                          uVar31 = *(ushort *)(pbVar21 + (ulonglong)uVar31 + 2) & 0x7fff;
LAB_:
                          if (uVar31 < uVar33) goto LAB_;
                        }
                        else {
                          uVar33 = *(ushort *)
                                    (pbVar21 + (longlong)(int)uVar37 * 2 + ((ulonglong)uVar31 - 2))
                                   & 0x7fff;
                          uVar31 = *(ushort *)
                                    (pbVar21 + (longlong)(int)uVar37 * 2 + (ulonglong)uVar31) &
                                   0x7fff;
                          if (*(uint *)(plStack_2d0 + 3) <= uVar33) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar30 + -8) = 0x101319;
                          func_0x(pbVar21,7);
                          pbVar21 = (byte *)plVar22[2];
                        }
                        uVar31 = uVar31 - uVar33;
                        if (uVar31 != 1) goto LAB_;
                      }
                      *(char *)(plVar22[2] + (ulonglong)uVar33) = *(char *)plStack_278;
                      if (uStack_1f8 != 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x101404;
                        func_0x(puVar1,auStack_128);
                      }
                    }
                  }
                  else {
                    uVar31 = (uint)*(ushort *)((longlong)puVar32 + 6);
                    if ((*(ushort *)((longlong)puVar32 + 6) & 8) == 0) {
                      if (*(int *)((longlong)plVar22 + 0xc) == 0) {
                        *puVar1 = 0;
                        uVar37 = *(uint *)(plVar22 + 3);
                        uVar27 = (ulonglong)uVar37;
                        *(uint *)((longlong)plVar22 + 0x1c) = uVar37;
                        pbVar21 = (byte *)plVar22[2];
                        bVar35 = *pbVar21;
                        if ((bVar35 & 0x10) != 0) {
                          uVar37 = uVar37 + 2 + (*(ushort *)(pbVar21 + uVar27) + 7 >> 3);
                          uVar27 = (ulonglong)uVar37;
                          *(uint *)((longlong)plVar22 + 0x1c) = uVar37;
                          bVar35 = *pbVar21;
                        }
                        if ((bVar35 & 0x20) == 0) {
                          *(int *)((longlong)plVar22 + 0xc) = (int)uVar27;
                          *(short *)((longlong)plVar22 + 0x24) = 0;
                          *(int *)(plVar22 + 4) = (int)uVar27;
                        }
                        else {
                          puVar38 = (ushort *)(pbVar21 + uVar27);
                          uVar13 = *puVar38;
                          *(ushort *)((longlong)plVar22 + 0x24) = uVar13;
                          if (uVar13 == 0) {
                            *(undefined8 *)(puVar30 + -8) = 0x1007d8;
                            cVar11 = func_0x(0x1128900);
                            if (cVar11 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x1007e1;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x1007fb;
                                cVar11 = func_0x(0x1128900);
                                if (cVar11 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x100817;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x10083d;
                                  (*_DAT_)(1,0xa19688,0xb39358,0x80f);
                                }
                              }
                            }
                            lVar17 = plVar22[2];
                            *(undefined8 *)(puVar30 + -8) = 0x10084b;
                            func_0x(lVar17,3);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0x1c);
                            pbVar21 = (byte *)plVar22[2];
                            uVar13 = *(ushort *)((longlong)plVar22 + 0x24);
                          }
                          uVar37 = (int)uVar27 + (uVar13 + 1) * 2;
                          *(uint *)(plVar22 + 4) = uVar37;
                          if (0x1f9e < uVar37) {
                            *(undefined8 *)(puVar30 + -8) = 0x10087f;
                            cVar11 = func_0x(0x1128900);
                            if (cVar11 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100888;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x1008a2;
                                cVar11 = func_0x(0x1128900);
                                if (cVar11 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x1008be;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x1008e4;
                                  (*_DAT_)(1,0xa19688,0xb39358,0x816);
                                }
                              }
                            }
                            lVar17 = plVar22[2];
                            *(undefined8 *)(puVar30 + -8) = 0x1008f2;
                            func_0x(lVar17,4);
                            uVar13 = *(ushort *)((longlong)plVar22 + 0x24);
                            pbVar21 = (byte *)plVar22[2];
                            uVar37 = *(uint *)(plVar22 + 4);
                          }
                          uVar27 = (ulonglong)uVar13;
                          uVar13 = puVar38[uVar27];
                          *(uint *)((longlong)plVar22 + 0xc) = uVar13 & 0x7fff;
                          if ((uVar13 & 0x7fff) < uVar37) {
                            *(undefined8 *)(puVar30 + -8) = 0x100923;
                            cVar11 = func_0x(0x1128900);
                            if (cVar11 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x10092c;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x100946;
                                cVar11 = func_0x(0x1128900);
                                if (cVar11 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x100962;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x100988;
                                  (*_DAT_)(1,0xa19688,0xb39358,0x81d);
                                }
                              }
                            }
                            lVar17 = plVar22[2];
                            *(undefined8 *)(puVar30 + -8) = 0x100996;
                            func_0x(lVar17,4);
                            uVar27 = (ulonglong)*(ushort *)((longlong)plVar22 + 0x24);
                            pbVar21 = (byte *)plVar22[2];
                          }
                          if ((short)puVar38[(ulonglong)((int)uVar27 - 1) + 1] < 0) {
                            do {
                              uVar37 = *(uint *)((longlong)plVar22 + 0x1c);
                              if ((int)uVar27 == 1) {
                                uVar31 = *(uint *)(plVar22 + 4);
                                uVar13 = *(ushort *)(pbVar21 + uVar27 * 2 + (ulonglong)uVar37);
                                uVar33 = uVar31;
LAB_:
                                if ((uVar13 & 0x7fff) < uVar31) goto LAB_;
                              }
                              else {
                                uVar31 = *(ushort *)(pbVar21 + uVar27 * 2 + ((ulonglong)uVar37 - 2))
                                         & 0x7fff;
                                uVar33 = *(uint *)(plVar22 + 4);
                                uVar13 = *(ushort *)(pbVar21 + uVar27 * 2 + (ulonglong)uVar37);
                                if (uVar33 <= uVar31) goto LAB_;
LAB_:
                                *(undefined8 *)(puVar30 + -8) = 0x100a04;
                                func_0x(pbVar21,7);
                                uVar33 = *(uint *)(plVar22 + 4);
                                pbVar21 = (byte *)plVar22[2];
                              }
                              if ((uVar31 < uVar33) || (*(uint *)((longlong)plVar22 + 0xc) < uVar31)
                                 ) goto LAB_;
                              if (*(ushort *)(pbVar21 + uVar31) == 5) {
                                *puVar1 = *puVar1 | 2;
                                *(short *)(int *)((longlong)plVar22 + 0x24) =
                                     *(short *)(int *)((longlong)plVar22 + 0x24) + -1;
                                *(short *)((longlong)plVar22 + 0x32) = (short)uVar31;
                                lVar17 = (ulonglong)(uVar31 & 0xffff) + plVar22[2];
                                uVar13 = *(ushort *)(lVar17 + 2);
                                uVar14 = *(ushort *)((longlong)plVar22 + 0x34) & 0xc7ff;
                                if ((uVar13 >> 0xe & 1) != 0) {
                                  uVar14 = uVar13 & 0x3800 | uVar14;
                                }
                                *(ushort *)((longlong)plVar22 + 0x34) = uVar14;
                                *(ushort *)((longlong)plVar22 + 0x34) =
                                     (uVar14 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar14;
                                goto LAB_;
                              }
                              if (*(ushort *)(pbVar21 + uVar31) < 0x400) goto LAB_;
                              *puVar1 = *puVar1 | 1;
                              uVar13 = *(short *)((longlong)plVar22 + 0x24) - 1;
                              *(ushort *)((longlong)plVar22 + 0x24) = uVar13;
                              if (uVar13 == 0) goto LAB_;
                              uVar27 = (ulonglong)uVar13;
                            } while ((short)puVar38[(ulonglong)(uVar13 - 1) + 1] < 0);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0xc);
                            pbVar21 = (byte *)plVar22[2];
                          }
                          else {
LAB_:
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0xc);
                            pbVar21 = (byte *)plVar22[2];
                          }
                        }
                        if ((*pbVar21 & 0x40) == 0) {
                          *(undefined4 *)((longlong)plVar22 + 0x2e) = 0;
                        }
                        else {
                          *(int *)((longlong)plVar22 + 0x2e) = (int)uVar27;
                          *(int *)((longlong)plVar22 + 0xc) = (int)uVar27 + 0xe;
                          *(undefined8 *)(puVar30 + -8) = 0x100aef;
                          uVar19 = func_0x(puVar1);
                          *(undefined8 *)(puVar30 + -8) = 0x100afe;
                          func_0x(uVar19,auStack_1d0);
                          *(undefined8 *)(puVar30 + -8) = 0x100b0a;
                          iVar25 = func_0x(auStack_1d0);
                          *(int *)((longlong)plVar22 + 0xc) =
                               *(int *)((longlong)plVar22 + 0xc) + iVar25;
                          uVar27 = (ulonglong)*(uint *)((longlong)plVar22 + 0xc);
                          pbVar21 = (byte *)plVar22[2];
                        }
                        iVar25 = (int)uVar27;
                        if ((*(byte **)((longlong)plVar22 + 0x26) != (byte *)0x0) &&
                           (*(byte **)((longlong)plVar22 + 0x26) < pbVar21 + uVar27)) {
                          *(undefined8 *)(puVar30 + -8) = 0x100b42;
                          cVar11 = func_0x(0x1128900);
                          if (cVar11 != '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x100b4b;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar30 + -8) = 0x100b65;
                              cVar11 = func_0x(0x1128900);
                              if (cVar11 == '\0') {
                                *(undefined8 *)(puVar30 + -8) = 0x100b81;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar30 + 0x20) = 0;
                                *(undefined8 *)(puVar30 + -8) = 0x100ba7;
                                (*_DAT_)(1,0xa19688,0xb39358);
                              }
                            }
                          }
                          lVar17 = plVar22[2];
                          *(undefined8 *)(puVar30 + -8) = 0x100bb5;
                          func_0x(lVar17,0x12);
                          iVar25 = *(int *)((longlong)plVar22 + 0xc);
                        }
                        if (0x3f3b < iVar25 - 1U) {
                          *(undefined8 *)(puVar30 + -8) = 0x100bce;
                          cVar11 = func_0x(0x1128900);
                          if (cVar11 != '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x100bd7;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar30 + -8) = 0x100bf1;
                              cVar11 = func_0x(0x1128900);
                              if (cVar11 == '\0') {
                                *(undefined8 *)(puVar30 + -8) = 0x100c0d;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar30 + 0x20) = 0;
                                *(undefined8 *)(puVar30 + -8) = 0x100c33;
                                (*_DAT_)(1,0xa19688,0xb39358);
                              }
                            }
                          }
                          lVar17 = plVar22[2];
                          *(undefined8 *)(puVar30 + -8) = 0x100c41;
                          func_0x(lVar17,5);
                        }
                      }
LAB_:
                      uVar31 = *puVar32;
                      uVar37 = uVar31 + 1;
                      uVar33 = *(uint *)(plVar22 + 3);
                      if (uVar33 < uVar37) {
                        *(undefined8 *)(puVar30 + -8) = 0x100c62;
                        func_0x(puVar1,0,uVar37 - uVar33);
                        if ((1 << (*(byte *)plVar22[2] & 0xe) & 0x1105U) != 0) {
                          *(short *)((byte *)plVar22[2] + 2) = (short)uVar37;
                        }
                        *(uint *)(plVar22 + 3) = uVar37;
                        uVar31 = *puVar32;
                      }
                      puStack_2c8 = puVar32;
                      if (plVar9 != (longlong *)0x0) {
                        *(char *)((longlong)(int)uVar31 + plVar22[2]) = *(char *)plVar9;
                      }
                    }
                    else {
                      cVar11 = *(char *)plStack_280;
                      uVar37 = uVar37 + 1;
                      uVar33 = *(uint *)(plVar22 + 3);
                      if (uVar33 < uVar37) {
                        *(undefined8 *)(puVar30 + -8) = 0x100721;
                        func_0x(puVar1,0,uVar37 - uVar33);
                        if ((1 << (*(byte *)plVar22[2] & 0xe) & 0x1105U) != 0) {
                          *(short *)((byte *)plVar22[2] + 2) = (short)uVar37;
                        }
                        *(uint *)(plVar22 + 3) = uVar37;
                        uVar31 = (uint)*(byte *)((longlong)puVar32 + 6);
                      }
                      lVar18 = plVar22[2];
                      if (cVar11 == '\0') {
                        *(byte *)(lVar17 + lVar18) =
                             *(byte *)(lVar18 + lVar17) & ~(byte)(1 << (uVar31 & 7));
                        puStack_2c8 = puVar32;
                      }
                      else {
                        *(byte *)(lVar17 + lVar18) =
                             *(byte *)(lVar18 + lVar17) | (byte)(1 << (uVar31 & 7));
                        puStack_2c8 = puVar32;
                      }
                    }
                  }
                }
                else {
                  *(undefined8 *)(puVar30 + 0x20) = 0x795b68;
                  *(undefined8 *)(puVar30 + -8) = 0x1006d9;
                  (*_DAT_)(1,0xb9a9c0,0xbc7300);
                  puStack_2c8 = puVar32;
                }
              }
              puVar32 = puStack_2c8 + 0x14;
              uStack_288 = uStack_288 + 1;
              plVar20 = plStack_2b8;
              uVar31 = uStack_2a0;
              puStack_2c8 = puVar32;
            } while (uStack_288 < uStack_1f0);
          }
          do {
            uVar36 = uVar31;
            uVar37 = uStack_2a4;
            if (uVar36 == 0) goto LAB_;
            uVar27 = (ulonglong)uVar36;
            uVar31 = uVar36 - 1;
          } while (*(int *)(plStack_2b8 + (ulonglong)(uVar36 - 1) * 4 + 1) == 0);
          *(short *)((longlong)plVar22 + 0x24) = (short)uVar36;
          iVar25 = *(int *)((longlong)plVar22 + 0x1c) + 2 + uVar36 * 2;
          *(int *)(plVar22 + 4) = iVar25;
          *(int *)((longlong)plVar22 + 0xc) = iVar25;
          *(byte *)plVar22[2] = *(byte *)plVar22[2] | 0x20;
          if (*(uint *)((longlong)plVar22 + 0xc) <= uStack_2bc) {
            plVar39 = (longlong *)((ulonglong)*(uint *)((longlong)plVar22 + 0x1c) + plVar22[2]);
            *(short *)plVar39 = (short)uVar36;
          }
          if (uVar36 != 0) {
            puVar32 = (uint *)((longlong)plStack_2b8 + 0xc);
            uVar36 = uStack_2bc;
            do {
              plVar39 = (longlong *)((longlong)plVar39 + 2);
              uVar15 = *(uint *)((longlong)plVar22 + 0xc);
              lVar17 = plVar22[2];
              uVar33 = puVar32[-1];
              uVar31 = uVar15 + uVar33;
              *(uint *)((longlong)plVar22 + 0xc) = uVar31;
              if ((uVar31 <= uVar36) && (uVar31 <= uVar37)) {
                *(ushort *)plVar39 = (ushort)((*puVar32 & 1) << 0xf) | (ushort)uVar31 & 0x7fff;
                uVar19 = *(undefined8 *)(puVar32 + -3);
                *(undefined8 *)(puVar30 + -8) = 0x101e90;
                func_0x((ulonglong)uVar15 + lVar17,uVar33,uVar19,uVar33);
                uVar36 = uStack_2bc;
              }
              puVar32 = puVar32 + 8;
              uVar27 = uVar27 - 1;
            } while (uVar27 != 0);
          }
        }
      }
      else {
        *(undefined8 *)(puVar30 + 0x40) = 0;
        *(undefined **)(puVar30 + 0x38) = auStack_284;
        *(uint *)(puVar30 + 0x30) = uVar31;
        *(uint *)(puVar30 + 0x28) = uVar37;
        *(longlong *)(puVar30 + 0x20) = lVar17;
        *(undefined8 *)(puVar30 + -8) = 0x1023b9;
        func_0x(auStack_168,&plStack_268,2,plVar20);
      }
LAB_:
      lVar17 = lStack_1e8;
      if (((*(uint *)(lStack_1e8 + 0x3c4) & 0xe0000000) != 0x80000000) ||
         (0xff < *(ushort *)(lStack_1e8 + 0x3c8))) {
        lVar18 = lStack_1e8 + 0x3b0;
        *(undefined8 *)(puVar30 + -8) = 0x1023f4;
        func_0x(lVar18,1);
      }
      *(undefined8 *)(puVar30 + -8) = 0x102409;
      func_0x(&lStack_298,lVar17 + 0x3b0);
      lVar18 = lStack_298;
      uVar19 = *(undefined8 *)(lStack_298 + 8);
      *(undefined8 *)(puVar30 + -8) = 0x102416;
      func_0x(uVar19);
      uVar19 = *(undefined8 *)(lVar18 + 8);
      *(undefined8 *)(puVar30 + -8) = 0x102424;
      func_0x(uVar19,1);
      if (iStack_290 != 0) {
        lVar18 = *(longlong *)(lVar18 + 8);
        *(undefined8 *)(puVar30 + -8) = 0x10243f;
        func_0x(lVar18 + 0x630,2);
        iStack_290 = 0;
      }
      lStack_298 = 0;
      lVar18 = lStack_1a8;
      while (lVar18 != 0) {
        lVar6 = *(longlong *)(lVar18 + 8000);
        *(undefined8 *)(puVar30 + -8) = 0x102464;
        (*_DAT_)(lVar18,0x1f48);
        lVar18 = lVar6;
      }
      *pplStack_208 = (longlong *)(*(longlong *)(lVar17 + 0x3f0) + 8);
      goto LAB_;
    }
  }
  else {
    if ((*(byte *)(param_1 + 0x438) & 4) == 0) {
      lStack_298 = *(longlong *)(param_1 + 0x430);
      iStack_290 = 0;
      uStack_300 = 0;
      plStack_308 = &lStack_298;
      uStack_330 = 0x1000a7;
      func_0x(param_1 + 8,*(undefined8 *)(param_1 + 0x428),0,0);
      *(uint *)(param_1 + 0x438) = *(uint *)(param_1 + 0x438) | 4;
      lVar17 = *(longlong *)(param_1 + 0x3f0);
    }
    uStack_330 = 0x1000c7;
    (**(code **)(**(longlong **)(param_1 + 0x38) + 0x28))
              (*(longlong **)(param_1 + 0x38),lVar17,&uStack_1d8);
    uStack_330 = 0x1000d8;
    (**(code **)(**(longlong **)(param_1 + 0x38) + 0x20))(*(longlong **)(param_1 + 0x38),uStack_1d8)
    ;
    lVar17 = *(longlong *)(param_1 + 0x3f0);
    pplStack_208 = (longlong **)0x0;
    iStack_200 = 0;
    *(undefined8 *)(lVar17 + 0x10) = 0;
    *(undefined8 *)(lVar17 + 8) = 0xffff;
    *(undefined8 *)(lVar17 + 0x20) = 0;
    *(undefined8 *)(lVar17 + 0x28) = 0;
    *(undefined8 *)(lVar17 + 0x18) = 0;
    *(undefined4 *)(lVar17 + 0x38) = 0;
    *(undefined8 *)(lVar17 + 0x30) = 0;
    uStack_330 = 0x100125;
    func_0x(&pplStack_208,param_1 + 0x3b0);
    pplVar10 = pplStack_208;
    uStack_330 = 0x100135;
    func_0x(pplStack_208[1]);
    uStack_330 = 0x100141;
    func_0x(pplVar10[1],0xffffffffffffffff);
    if (iStack_200 != 0) {
      uStack_330 = 0x10015f;
      func_0x(pplVar10[1] + 0xc6,2);
      iStack_200 = 0;
    }
    pplStack_208 = (longlong **)0x0;
  }
  if ((*(byte *)(param_1 + 0x438) & 4) == 0) {
    lStack_298 = *(longlong *)(param_1 + 0x430);
    iStack_290 = 0;
    uStack_300 = 0;
    plStack_308 = &lStack_298;
    uStack_330 = 0x1001a8;
    func_0x(param_1 + 8,*(undefined8 *)(param_1 + 0x428),0,0);
    *(uint *)(param_1 + 0x438) = *(uint *)(param_1 + 0x438) | 4;
  }
  plVar22 = (longlong *)(param_1 + 0x40);
  plStack_308 = (longlong *)0x0;
  uStack_330 = 0x1001cb;
  func_0x(*(undefined8 *)(param_1 + 0x38),param_3,param_4,plVar22);
  if (param_5 == (longlong **)0x0) {
    puVar30 = auStack_328;
    if (*plVar22 != 0) {
      uStack_330 = 0x102492;
      (**(code **)(**(longlong **)(param_1 + 0x38) + 0x20))();
      puVar30 = auStack_328;
    }
  }
  else {
    if (*plVar22 == 0) {
      plVar22 = plVar39;
    }
    *param_5 = plVar22;
    puVar30 = auStack_328;
  }
LAB_:
  uVar27 = uStack_48 ^ (ulonglong)&lStack_2d8;
  *(undefined8 *)(puVar30 + -8) = 0x1024a3;
  func_0x(uVar27);
  return;
}

