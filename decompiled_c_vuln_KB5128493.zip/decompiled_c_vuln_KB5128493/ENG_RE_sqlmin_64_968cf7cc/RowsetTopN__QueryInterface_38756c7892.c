
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,longlong *param_2,longlong **param_3)

{
  if (*param_2 == _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_2 == _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_2 == _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*param_2 == _DAT_) && (param_2[1] == _DAT_)) {
    *param_3 = (longlong *)(param_1 + 0x78);
    (**(code **)(*(longlong *)(param_1 + 0x78) + 8))();
    return 0;
  }
  if ((*param_2 == _DAT_) && (param_2[1] == _DAT_)) {
    *param_3 = (longlong *)(param_1 + 0x88);
    (**(code **)(*(longlong *)(param_1 + 0x88) + 8))();
    return 0;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

