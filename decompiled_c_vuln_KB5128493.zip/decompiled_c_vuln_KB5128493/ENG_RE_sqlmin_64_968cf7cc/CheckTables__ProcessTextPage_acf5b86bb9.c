
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2,longlong param_3,longlong param_4,
                 undefined8 param_5)

{
  byte *pbVar1;
  int *piVar2;
  byte *pbVar3;
  ushort uVar4;
  short sVar5;
  longlong lVar6;
  undefined auVar7 [16];
  char cVar8;
  int iVar9;
  longlong lVar10;
  uint uVar11;
  ulonglong uVar12;
  code *UNRECOVERED_JUMPTABLE_00;
  short *psVar13;
  uint uVar14;
  uint uVar15;
  ulonglong uVar16;
  ushort uVar17;
  longlong unaff_GS_OFFSET;
  undefined auStack_298 [32];
  longlong lStack_278;
  undefined8 *puStack_270;
  undefined4 uStack_268;
  undefined4 uStack_260;
  undefined4 uStack_258;
  undefined4 uStack_250;
  int iStack_248;
  undefined4 uStack_240;
  uint *puStack_238;
  undefined4 uStack_230;
  undefined8 uStack_228;
  undefined4 uStack_220;
  undefined8 uStack_218;
  undefined2 uStack_210;
  undefined4 uStack_208;
  undefined8 uStack_200;
  undefined4 uStack_1f8;
  undefined2 uStack_1f0;
  uint uStack_1b0;
  undefined4 uStack_1ac;
  undefined8 uStack_1a8;
  undefined4 uStack_1a0;
  int iStack_198;
  uint uStack_194;
  undefined4 uStack_190;
  longlong lStack_188;
  undefined8 uStack_180;
  undefined2 uStack_178;
  undefined4 uStack_170;
  undefined2 uStack_16c;
  longlong lStack_168;
  longlong lStack_160;
  undefined8 uStack_158;
  ulonglong uStack_150;
  undefined4 uStack_148;
  undefined8 uStack_140;
  undefined2 uStack_138;
  undefined4 uStack_134;
  byte *pbStack_130;
  undefined8 uStack_128;
  undefined8 uStack_11a;
  undefined2 uStack_112;
  undefined2 uStack_110;
  undefined6 uStack_10e;
  int iStack_104;
  undefined auStack_100 [16];
  undefined auStack_f0 [8];
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined6 uStack_d0;
  undefined2 uStack_ca;
  undefined2 uStack_c8;
  undefined6 uStack_c6;
  undefined8 uStack_c0;
  short *psStack_b8;
  short *psStack_b0;
  short sStack_a8;
  undefined6 uStack_a6;
  undefined auStack_a0 [8];
  undefined8 uStack_98;
  undefined8 uStack_90;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_68;
  undefined4 uStack_64;
  uint uStack_60;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_298;
  uVar12 = 0;
  uStack_1a8 = param_5;
  uStack_158 = 0;
  uStack_150 = 0;
  uStack_190 = 1;
  uStack_194 = 0;
  iStack_198 = 0;
  uStack_1ac = param_2;
  lStack_168 = param_4;
  lStack_160 = param_1;
  if (1 < (ushort)(*(short *)(param_4 + 0x7a) - 4U)) {
    func_0x(param_2,param_3,4,*(undefined *)(param_3 + 1));
    func_0x(param_1,2,param_4 + 0x60);
    goto LAB_;
  }
  if ((*(byte *)(param_1 + 0xbc) & 0x20) != 0) goto LAB_;
  uStack_1b0 = 0;
  uVar15 = 0;
  if ((ulonglong)*(ushort *)(param_3 + 0x16) != 0) {
    psVar13 = (short *)(param_3 + 0x1ffe);
    uVar16 = uVar12;
    do {
      iVar9 = (int)uVar16;
      if (*psVar13 != 0) {
        uVar15 = 0;
        if (iVar9 != -1) {
          lStack_188 = (longlong)iVar9;
          goto LAB_;
        }
        break;
      }
      uStack_1b0 = iVar9 + 1;
      uVar16 = (ulonglong)uStack_1b0;
      uVar12 = uVar12 + 1;
      psVar13 = psVar13 + -1;
      uVar15 = 0;
    } while ((longlong)uVar12 < (longlong)(ulonglong)*(ushort *)(param_3 + 0x16));
  }
  goto LAB_;
LAB_:
  lVar10 = lStack_160;
  lVar6 = lStack_188;
  iVar9 = (int)uVar16;
  func_0x(param_4,param_3,uVar16);
  uStack_194 = func_0x(lVar10,param_4,*(undefined *)(param_3 + 1));
  if ((uStack_194 & 4) == 0) {
    uStack_140 = *(undefined8 *)(param_4 + 0xa8);
    pbStack_130 = (byte *)0x0;
    uStack_138 = 0xffff;
    uStack_134 = 0;
    uStack_11a = 0;
    uStack_110 = 0;
    uStack_10e = 0;
    uStack_128 = 0;
    iStack_104 = iVar9;
    if (-1 < *(char *)(param_3 + 2)) goto LAB_;
    pbVar1 = (byte *)(param_3 + 0x60);
    stack0xffffffffffffff12 = SUB1614(ZEXT816(0),2);
    auStack_f0._0_2_ = 0xffff;
    uStack_d8 = 0;
    uStack_ca = 0;
    uStack_e8 = 0;
    uStack_c0 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
    uStack_c8 = 0;
    uStack_c6 = 0;
    uStack_e0 = 0;
    psStack_b8 = (short *)0x0;
    _auStack_a0 = ZEXT812(0);
    uStack_98._4_4_ = 0;
    auVar7 = _auStack_a0;
    uStack_98 = 0;
    uStack_90 = 0;
    psStack_b0 = (short *)0x0;
    sStack_a8 = 0;
    uStack_a6 = 0;
    auStack_100 = ZEXT816(0);
    lVar10 = 0;
    if (*(short *)(param_3 + 0x24) == 0) {
LAB_:
      auStack_100._8_8_ = lVar10;
      uStack_180 = *(undefined8 *)(param_3 + 0x28);
      uStack_178 = *(undefined2 *)(param_3 + 0x30);
    }
    else {
      cVar8 = *(char *)(param_3 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(param_3 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(param_3 + 0x18) != 99) goto LAB_;
      }
      uStack_170 = *(undefined4 *)(param_3 + 0x20);
      uStack_16c = *(undefined2 *)(param_3 + 0x24);
      _auStack_a0 = auVar7;
      cVar8 = func_0x(&uStack_170);
      lVar10 = auStack_100._8_8_;
      if (cVar8 == '\0') goto LAB_;
      func_0x(param_3,&uStack_180);
    }
    auStack_a0 = (undefined  [8])uStack_180;
    uStack_98._4_4_ = *(undefined4 *)(param_3 + 0x20);
    lVar10 = (ulonglong)*pbVar1 * 6;
    uStack_98._0_2_ = uStack_178;
    uStack_148 = *(undefined4 *)(lVar10 + 0xb73b80);
    uVar12 = (ulonglong)*(short *)(lVar10 + 0xb73b84);
    auStack_100._0_8_ = pbVar1;
    auStack_f0._0_2_ = 0xffff;
    auStack_f0 = (undefined  [8])((ulonglong)auStack_f0 & 0xffffffff);
    uStack_e8 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
    uStack_c8 = 0;
    uStack_c6 = 0;
    uStack_e0 = 0;
    sStack_a8 = 0;
    psStack_b8 = (short *)0x0;
    psStack_b0 = (short *)0x0;
    if ((*pbVar1 & 2) != 0) {
      pbVar3 = pbVar1 + uVar12;
      uStack_e8 = pbVar3;
      if ((pbVar1[uVar12] & 1) == 0) {
        auVar7._14_2_ = 0;
        auVar7._0_14_ = stack0xffffffffffffff12;
        _auStack_f0 = auVar7 << 0x10;
        uStack_ca = 0;
        uStack_c8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100527 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x101598) - 0x19c62b0))
                  ();
        return;
      }
      auStack_f0._0_2_ = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x101578) * 4 +
                             0x101568) - 0x19c62b0);
                    /* WARNING: Could not emulate address calculation at 0x00100375 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    if ((*pbVar1 & 4) != 0) {
      uStack_148._2_2_ = (short)((uint)uStack_148 >> 0x10);
      if (uStack_148._2_2_ != 0) {
        uVar12 = (ulonglong)*(ushort *)(param_3 + 0x61 + (longlong)uStack_148._2_2_ * 2);
      }
      psStack_b8 = (short *)(pbVar1 + uVar12);
      psStack_b0 = psStack_b8 + 1;
      sStack_a8 = (*psStack_b8 + 1) * 2;
    }
    if (auStack_100._8_8_ != 0) {
      func_0x(auStack_100._8_8_,auStack_100);
    }
LAB_:
    pbStack_130 = (byte *)((ulonglong)*(ushort *)((0xfff - lVar6) * 2 + param_3) + param_3);
    if ((*pbStack_130 & 1) == 0) {
      uStack_138 = 0;
      uStack_134 = 0;
      uStack_112 = 0;
      uStack_110 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007b3 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_130 & 0xe) * 4 + 0x101604) -
                0x19c62b0))();
      return;
    }
    uStack_138 = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_130 & 0x1c) + 0x1015e4) *
                            4 + 0x1015d4) - 0x19c62b0);
                    /* WARNING: Could not emulate address calculation at 0x00100630 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((uStack_194 & 0x10) == 0) {
    func_0x(&uStack_158,param_4 + 0xa0);
  }
  else {
    iStack_198 = 1;
  }
  lStack_188 = lVar6 + 1;
  uStack_1b0 = iVar9 + 1;
  if ((longlong)(ulonglong)*(ushort *)(param_3 + 0x16) <= lStack_188) goto LAB_;
  psVar13 = (short *)((0xfff - lStack_188) * 2 + param_3);
  while (uVar16 = (ulonglong)uStack_1b0, *psVar13 == 0) {
    uStack_1b0 = uStack_1b0 + 1;
    lStack_188 = lStack_188 + 1;
    psVar13 = psVar13 + -1;
    if ((longlong)(ulonglong)*(ushort *)(param_3 + 0x16) <= lStack_188) goto LAB_;
  }
  if (uStack_1b0 == 0xffffffff) goto LAB_;
  goto LAB_;
LAB_:
  uVar15 = (uint)uStack_158;
LAB_:
  lVar6 = lStack_160;
  if (*(char *)(param_3 + 1) == '\x03') {
    func_0x(lStack_160,uStack_1ac,param_3);
  }
  if (((uint)uStack_150 == *(ushort *)(param_3 + 0x3a)) || (iStack_198 != 0)) {
    uVar4 = *(ushort *)(param_3 + 0x16);
    uVar12 = (ulonglong)uVar4;
    uVar11 = (uint)uVar4;
    uVar17 = *(ushort *)(param_3 + 4) & 8;
    if ((uVar17 != 0) && (lVar10 = (longlong)(int)uVar11, uVar4 != 0)) {
      psVar13 = (short *)(param_3 + 0x1ffe);
      uVar14 = uVar11;
      do {
        sVar5 = *psVar13;
        psVar13 = psVar13 + -1;
        uVar11 = uVar14 - 1;
        if (sVar5 != 0) {
          uVar11 = uVar14;
        }
        lVar10 = lVar10 + -1;
        uVar14 = uVar11;
      } while (lVar10 != 0);
    }
    if ((uVar15 != uVar11) && (iStack_198 == 0)) {
      if ((uVar17 != 0) && (uVar4 != 0)) {
        psVar13 = (short *)(param_3 + 0x1ffe);
        uVar16 = uVar12;
        do {
          sVar5 = *psVar13;
          psVar13 = psVar13 + -1;
          uVar11 = (uint)uVar12 - 1;
          if (sVar5 != 0) {
            uVar11 = (uint)uVar12;
          }
          uVar12 = (ulonglong)uVar11;
          uVar16 = uVar16 - 1;
        } while (uVar16 != 0);
      }
      uStack_60 = (uint)*(byte *)(param_3 + 1);
      uStack_64 = (undefined4)uVar12;
      uStack_68 = uVar15;
      lVar10 = func_0x();
      uStack_1ac = *(undefined4 *)(lVar10 + 0x68);
      lVar10 = *(longlong *)(*(longlong *)(lVar6 + 0x168) + 8);
      LOCK();
      piVar2 = (int *)(lVar10 + 8);
      iStack_248 = *piVar2;
      *piVar2 = *piVar2 + 1;
      UNLOCK();
      puStack_238 = &uStack_68;
      uStack_250 = 2;
      uStack_260 = 0x22d7;
      goto LAB_;
    }
  }
  else {
    uStack_80 = (uint)*(byte *)(param_3 + 1);
    uStack_88 = (uint)uStack_150;
    uStack_84 = (uint)*(ushort *)(param_3 + 0x3a);
    lVar10 = func_0x();
    uStack_1ac = *(undefined4 *)(lVar10 + 0x68);
    lVar10 = *(longlong *)(*(longlong *)(lVar6 + 0x168) + 8);
    LOCK();
    piVar2 = (int *)(lVar10 + 8);
    iStack_248 = *piVar2;
    *piVar2 = *piVar2 + 1;
    UNLOCK();
    puStack_238 = &uStack_88;
    uStack_250 = 3;
    uStack_260 = 0x22df;
LAB_:
    iStack_248 = iStack_248 + 1;
    uStack_1a0 = 0;
    uStack_1a8 = 0;
    uStack_1f0 = 0;
    uStack_1f8 = 0;
    uStack_200 = 0;
    uStack_208 = 0;
    uStack_210 = 1;
    uStack_218 = 0;
    uStack_220 = 0;
    uStack_228 = 0;
    uStack_230 = 0;
    uStack_240 = 3;
    uStack_258 = 0x10;
    uStack_268 = 0;
    puStack_270 = &uStack_1a8;
    lStack_278 = param_4 + 0x60;
    func_0x(lVar10,&uStack_1ac,param_4 + 0x154);
    func_0x(lVar6,2,param_4 + 0x60);
  }
  if (((DAT_ & 4) != 0) ||
     (((lVar6 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar6 != 0 && (lVar6 = **(longlong **)(lVar6 + 0x38), lVar6 != 0)) &&
      (iVar9 = (*_DAT_)(lVar6,0x9d2), iVar9 != 0)))) {
    func_0x(*(undefined8 *)(param_4 + 0x88),uStack_150 & 0xffffffff);
  }
  if ((*(int *)(*(longlong *)(param_4 + 0x90) + 0x14) == 1) &&
     (*(int *)(*(longlong *)(param_4 + 0x98) + 800) != 0)) {
    func_0x(*(undefined8 *)(param_4 + 0x88),0);
  }
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_298);
  return;
}

