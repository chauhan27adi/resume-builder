
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(byte *param_1,longlong param_2,int *param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  ushort uVar4;
  int iVar5;
  longlong unaff_GS_OFFSET;
  
  lVar1 = **(longlong **)(param_1 + 0x20);
  lVar2 = (*(longlong **)(param_1 + 0x20))[1];
  if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)(lVar1 + 8);
  if (*(char *)(param_2 + 0x2050) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_1[0x124] & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *param_3 = -1;
  if ((*param_1 & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(param_1 + 0x120) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((((*(byte *)(lVar1 + 0x106) & 4) == 0) && ((*(byte *)(lVar1 + 0x107) & 1) == 0)) &&
     (*(char *)(*(longlong *)(lVar2 + 0x30) + 0x2050) != '\0')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *param_3 = *(int *)(*(longlong *)
                       (*(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_) + 0x68) + 0x1c);
  if ((*(byte *)(lVar1 + 0x106) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(uint *)(param_1 + 0x120) = *(uint *)(param_1 + 0x120) | 1;
  if ((*param_1 & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_3 == 0x100) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_3 == 0x1000000) {
LAB_:
    if (*param_3 == 0x1000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((DAT_ & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar1 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar1 != 0) && (**(longlong **)(lVar1 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar3 = *(longlong **)(lVar2 + 0x290);
    if (plVar3 != (longlong *)0x0) {
      iVar5 = (**(code **)(*plVar3 + 400))(plVar3);
      if (iVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      iVar5 = *param_3;
      if (iVar5 == 0x1000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (iVar5 == 0x1000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (iVar5 != 0x10000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(longlong *)(param_2 + 0x1b8) = *(longlong *)(param_2 + 0x1b8) + 1;
    }
    return;
  }
  if (((*(byte *)(param_2 + 0x1cd0) & 1) == 0) && (*(int *)(param_2 + 0x674) != 5)) {
    uVar4 = _DAT_;
    if (*(char *)(*(longlong *)(param_2 + 0x6b0) + 0x939) != '\0') {
      uVar4 = 0x388;
    }
    if (uVar4 <= *(ushort *)(param_2 + 0x67e)) {
      uVar4 = 1;
      if ((DAT_ & 2) == 0) {
        uVar4 = 0x3bd;
      }
      if (*(ushort *)(param_2 + 0x67e) <= uVar4) goto LAB_;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

