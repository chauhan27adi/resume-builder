
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint *param_2,short *param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  longlong *plVar3;
  undefined8 uVar4;
  undefined auVar5 [16];
  short *psVar6;
  char cVar7;
  ushort uVar8;
  int iVar9;
  longlong lVar10;
  ulonglong *puVar11;
  byte bVar12;
  int iVar13;
  longlong lVar14;
  ushort uVar15;
  uint uVar16;
  undefined4 uVar17;
  uint uVar18;
  uint uVar19;
  undefined *puVar20;
  ushort *puVar21;
  ushort *puVar22;
  uint *puVar23;
  short *psVar24;
  short sVar25;
  int *piVar26;
  ulonglong uVar27;
  short sVar28;
  longlong unaff_GS_OFFSET;
  undefined auStack_9d8 [32];
  uint *puStack_9b8;
  undefined4 uStack_9b0;
  int *piStack_9a8;
  uint uStack_9a0;
  int aiStack_998 [2];
  uint uStack_990;
  ushort uStack_98c;
  ushort uStack_98a;
  int *piStack_988;
  undefined4 uStack_980;
  undefined2 uStack_97c;
  uint auStack_978 [2];
  uint *puStack_970;
  longlong lStack_968;
  undefined8 uStack_960;
  undefined2 uStack_958;
  short *psStack_950;
  undefined auStack_948 [8];
  short sStack_940;
  ushort uStack_93e;
  uint uStack_93c;
  byte *pbStack_938;
  undefined8 uStack_930;
  undefined4 uStack_928;
  ushort uStack_924;
  undefined2 uStack_922;
  undefined6 uStack_920;
  undefined2 uStack_91a;
  undefined2 uStack_918;
  undefined2 uStack_916;
  ushort uStack_914;
  undefined2 uStack_912;
  undefined4 uStack_910;
  undefined4 uStack_90c;
  undefined auStack_908 [16];
  undefined auStack_8f8 [2];
  undefined auStack_8f6 [2];
  undefined auStack_8f4 [12];
  uint uStack_8e8;
  undefined4 uStack_8e4;
  short sStack_8e0;
  short sStack_8de;
  short sStack_8dc;
  undefined2 uStack_8da;
  undefined6 uStack_8d8;
  undefined2 uStack_8d2;
  undefined2 uStack_8d0;
  undefined6 uStack_8ce;
  uint uStack_8c8;
  undefined4 uStack_8c4;
  short *psStack_8c0;
  short *psStack_8b8;
  short sStack_8b0;
  undefined6 uStack_8ae;
  undefined auStack_8a8 [8];
  undefined8 uStack_8a0;
  undefined8 uStack_898;
  undefined2 auStack_888 [2];
  undefined4 uStack_884;
  undefined8 uStack_880;
  undefined8 uStack_878;
  undefined8 uStack_86a;
  undefined8 uStack_860;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_9d8;
  puVar20 = (undefined *)0x0;
  auStack_888[0] = 0xffff;
  uStack_880 = 0;
  uVar16 = 0;
  uStack_884 = 0;
  uVar17 = 0xf;
  uVar18 = 0xf;
  uStack_86a = 0;
  uStack_860 = 0;
  sVar28 = 2;
  uStack_878 = 0;
  sStack_940 = -1;
  pbStack_938 = (byte *)0x0;
  uStack_93c = 0;
  uStack_922 = 0;
  uStack_920 = 0;
  uStack_918 = 0;
  uStack_916 = 0;
  uStack_914 = 0;
  uStack_912 = 0;
  uStack_930 = (undefined *)0x0;
  uStack_90c = 0;
  sVar25 = 2;
  puStack_970 = param_2;
  lStack_968 = param_1;
  psStack_950 = param_3;
  if (*(char *)(param_1 + 2) < '\0') {
    pbVar2 = (byte *)(param_1 + 0x60);
    puVar20 = auStack_908;
    _auStack_8f6 = SUB1614(ZEXT816(0),2);
    auStack_8f8 = (undefined  [2])0xffff;
    sStack_8e0 = 0;
    sStack_8de = 0;
    sStack_8dc = 0;
    uStack_8d2 = 0;
    auStack_8f4._4_8_ = 0;
    uStack_8c8 = 0;
    uStack_8c4 = 0;
    uStack_8da = 0;
    uStack_8d8 = 0;
    uStack_8d0 = 0;
    uStack_8ce = 0;
    uStack_8e8 = 0;
    uStack_8e4 = 0;
    psStack_8c0 = (short *)0x0;
    _auStack_8a8 = ZEXT812(0);
    uStack_8a0._4_4_ = 0;
    auVar5 = _auStack_8a8;
    uStack_8a0 = 0;
    uStack_898 = 0;
    psStack_8b8 = (short *)0x0;
    sStack_8b0 = 0;
    uStack_8ae = 0;
    auStack_908 = ZEXT816(0);
    uVar4 = 0;
    if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
      auStack_908._8_8_ = uVar4;
      uStack_960 = *(undefined8 *)(param_1 + 0x28);
      uStack_958 = *(undefined2 *)(param_1 + 0x30);
    }
    else {
      cVar7 = *(char *)(param_1 + 1);
      if (cVar7 == '\v') {
        if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
          if (cVar7 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar7 != '\b') goto LAB_;
LAB_:
        if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
      }
      uStack_980 = *(undefined4 *)(param_1 + 0x20);
      uStack_97c = *(undefined2 *)(param_1 + 0x24);
      _auStack_8a8 = auVar5;
      cVar7 = func_0x(&uStack_980,0x108acd8);
      uVar4 = auStack_908._8_8_;
      if (cVar7 == '\0') goto LAB_;
      func_0x(param_1,&uStack_960);
    }
    auStack_8a8 = (undefined  [8])uStack_960;
    uStack_8a0._4_4_ = *(undefined4 *)(param_1 + 0x20);
    auStack_908._0_8_ = pbVar2;
    lVar14 = (ulonglong)*pbVar2 * 6;
    uStack_980 = *(undefined4 *)(lVar14 + 0x110b2e0);
    uVar27 = (ulonglong)*(short *)(lVar14 + 0x110b2e4);
    auStack_8f8 = (undefined  [2])0xffff;
    uStack_8a0._0_2_ = uStack_958;
    _auStack_8f8 = _auStack_8f8 & 0xffffffff;
    auStack_8f4._4_8_ = 0;
    uStack_8da = 0;
    uStack_8d8 = 0;
    uStack_8d0 = 0;
    uStack_8ce = 0;
    uStack_8e8 = 0;
    uStack_8e4 = 0;
    sStack_8b0 = 0;
    psStack_8c0 = (short *)0x0;
    psStack_8b8 = (short *)0x0;
    uVar19 = uStack_8e8;
    if ((*pbVar2 & 2) != 0) {
      pbVar1 = pbVar2 + uVar27;
      auStack_8f4._4_8_ = pbVar1;
      if ((pbVar2[uVar27] & 1) == 0) {
        auVar5._14_2_ = 0;
        auVar5._0_14_ = _auStack_8f6;
        _auStack_8f8 = auVar5 << 0x10;
        uStack_8d2 = 0;
        uStack_8d0 = 0;
        uVar19 = uVar16;
        switch(*pbVar1 & 0xe) {
        default:
          uVar8 = *(ushort *)(pbVar1 + 2);
          uVar19 = (uint)uVar8;
          if (0x1f9d < uVar8 - 1) {
            func_0x(pbVar1,6);
          }
          break;
        case 4:
          uVar19 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar19 = 1;
        }
      }
      else {
        bVar12 = *pbVar1;
        switch(bVar12 & 0x1c) {
        default:
          if ((char)pbVar1[1] < '\0') {
            sVar25 = 3;
            auStack_8f6 = (undefined  [2])
                          ((*(ushort *)(pbVar1 + 1) & 0x7f) << 8 | *(ushort *)(pbVar1 + 1) >> 8);
          }
          else {
            auStack_8f6 = (undefined  [2])(ushort)pbVar1[1];
          }
          auStack_8f8 = (undefined  [2])0x1;
          sStack_8dc = (short)((ushort)auStack_8f6 + 1 >> 1) + sVar25;
          sStack_8e0 = sVar25;
          if ((ushort)auStack_8f6 < 0x1f) {
            uStack_8c8 = 0;
            sStack_8de = 0;
            uStack_8d0 = 0;
            uStack_8ce = 0;
            uStack_8e8 = 0;
            uStack_8e4 = 0;
            uVar19 = uStack_8e8;
          }
          else {
            iVar13 = (ushort)auStack_8f6 - 1;
            uStack_8c8 = 0;
            uStack_8d0 = 0;
            uStack_8ce = 0;
            uStack_8e8 = 0;
            uStack_8e4 = 0;
            sStack_8de = ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                         (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
            uVar19 = uStack_8e8;
          }
          break;
        case 4:
          if (((bVar12 & 0x1c) == 4) && ((bVar12 & 2) != 0)) {
            uVar16 = 1;
          }
          else {
            uVar17 = 1;
          }
          sStack_8e0 = 0;
          sStack_8de = 0;
          sStack_8dc = 0;
          uStack_8d2 = 0;
          auStack_8f4._0_4_ = uVar17;
          _auStack_8f8 = 1;
          uStack_8d0 = 0;
          uStack_8ce = 0;
          uStack_8e8 = 0;
          uStack_8e4 = 0;
          uVar19 = uStack_8e8;
          uStack_8c8 = uVar16;
          break;
        case 8:
          sStack_8e0 = 0;
          sStack_8de = 0;
          sStack_8dc = 0;
          uStack_8d2 = 0;
          _auStack_8f8 = 0x900000001;
          uStack_8c8 = 0;
          uStack_8d0 = 0;
          uStack_8ce = 0;
          uStack_8e8 = 0;
          uStack_8e4 = 0;
          uVar19 = uStack_8e8;
        }
      }
    }
    uStack_8e8 = uVar19;
    uStack_8d8 = 0;
    uStack_8da = 0;
    if ((*(byte *)auStack_908._0_8_ & 4) != 0) {
      if (uStack_980._2_2_ != 0) {
        uVar27 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)uStack_980._2_2_ * 2);
      }
      psStack_8c0 = (short *)(pbVar2 + uVar27);
      psStack_8b8 = psStack_8c0 + 1;
      sStack_8b0 = (*psStack_8c0 + 1) * 2;
    }
    if (auStack_908._8_8_ != 0) {
      func_0x(auStack_908._8_8_,auStack_908);
    }
  }
  lVar14 = lStack_968;
  pbStack_938 = (byte *)((ulonglong)*(ushort *)(lStack_968 + 0x1ffe) + lStack_968);
  if ((*pbStack_938 & 1) == 0) {
    sStack_940 = 0;
    uStack_93c = 0;
    uStack_91a = 0;
    uStack_918 = 0;
    uVar18 = (uint)*(ushort *)(lStack_968 + 0xe);
    switch(*pbStack_938 & 0xe) {
    default:
      uVar18 = (uint)*(ushort *)(pbStack_938 + 2);
      if (0x1f9d < *(ushort *)(pbStack_938 + 2) - 1) {
        func_0x(pbStack_938,6);
      }
      break;
    case 4:
      uVar18 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar18 = 1;
    }
    uStack_930 = (undefined *)CONCAT44(uStack_930._4_4_,uVar18);
    puVar20 = (undefined *)(ulonglong)uVar18;
    lVar10 = lVar14 + 0x2000;
    if (lVar14 == 0) {
      lVar10 = 0;
    }
    uStack_922 = (undefined2)lVar10;
    uStack_920 = (undefined6)((ulonglong)lVar10 >> 0x10);
    uVar18 = uStack_93c;
  }
  else {
    sStack_940 = 1;
    bVar12 = *pbStack_938;
    switch(bVar12 & 0x1c) {
    default:
      if ((char)pbStack_938[1] < '\0') {
        sVar28 = 3;
        uStack_928._0_2_ = 3;
        uStack_93e = (*(ushort *)(pbStack_938 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_938 + 1) >> 8;
      }
      else {
        uStack_93e = (ushort)pbStack_938[1];
        uStack_928._0_2_ = 2;
      }
      uStack_924 = ((ushort)(uStack_93e + 1) >> 1) + sVar28;
      if (uStack_93e < 0x1f) {
        uStack_928._2_2_ = 0;
        uStack_93c = 0;
        uStack_910 = 0;
        uVar18 = 0;
      }
      else {
        iVar13 = uStack_93e - 1;
        uStack_928._2_2_ =
             ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
             (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
        uStack_910 = 0;
        uStack_93c = 0;
        uVar18 = 0;
      }
      break;
    case 4:
      if (((bVar12 & 0x1c) == 4) && ((bVar12 & 2) != 0)) {
        uStack_93c = 0xf;
        uStack_928._0_2_ = 0;
        uStack_928._2_2_ = 0;
        uStack_924 = 0;
        uStack_922 = 0;
        uStack_93e = 0;
        uStack_920 = 0;
        uStack_91a = 0;
        uStack_910 = 1;
      }
      else {
        uVar18 = 1;
        uStack_928._0_2_ = 0;
        uStack_928._2_2_ = 0;
        uStack_924 = 0;
        uStack_922 = 0;
        uStack_93e = 0;
        uStack_920 = 0;
        uStack_91a = 0;
        uStack_93c = 1;
        uStack_910 = 0;
      }
      break;
    case 8:
      uStack_928._0_2_ = 0;
      uStack_928._2_2_ = 0;
      uStack_924 = 0;
      uStack_922 = 0;
      uStack_93e = 0;
      uStack_920 = 0;
      uStack_91a = 0;
      uStack_93c = 9;
      uStack_910 = 0;
      uVar18 = 9;
    }
    lVar10 = lStack_968 + 0x2000;
    if (lStack_968 == 0) {
      lVar10 = 0;
    }
    uStack_918 = (undefined2)lVar10;
    uStack_916 = (undefined2)((ulonglong)lVar10 >> 0x10);
    uStack_914 = (ushort)((ulonglong)lVar10 >> 0x20);
    uStack_912 = (undefined2)((ulonglong)lVar10 >> 0x30);
    uStack_930 = puVar20;
  }
  iVar13 = 0;
  if (sStack_940 == 0) {
    uVar16 = CONCAT22(uStack_928._2_2_,(undefined2)uStack_928);
    if (uVar18 == 0) {
      uVar18 = (uint)puVar20;
      uStack_93e = 0;
      if ((*pbStack_938 & 0x10) != 0) {
        uVar18 = uVar18 + 2 +
                 (*(ushort *)(pbStack_938 + ((ulonglong)puVar20 & 0xffffffff)) + 7 >> 3);
      }
      uStack_930 = (undefined *)CONCAT44(uVar18,(undefined4)uStack_930);
      if ((*pbStack_938 & 0x20) == 0) {
        uStack_924 = 0;
        uStack_93c = uVar18;
        uVar16 = uVar18;
      }
      else {
        puVar21 = (ushort *)(pbStack_938 + uVar18);
        uStack_924 = *puVar21;
        if (uStack_924 == 0) {
          if ((((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
              (lVar10 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                         (ulonglong)*puRam0000000000f8c660), lVar10 != 0)) &&
             ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
              (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_9b8 = (uint *)0x0;
              (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x80f);
            }
          }
          func_0x(pbStack_938,3);
        }
        uStack_928 = uStack_930._4_4_ + 2 + (uint)uStack_924 * 2;
        if (0x1f9e < uStack_928) {
          if (((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
             ((lVar10 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                         (ulonglong)*puRam0000000000f8c660), lVar10 != 0 &&
              ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
               (*(char *)(lVar10 + 0x499) != '\0')))))) {
            if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
              (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_9b8 = (uint *)0x0;
              (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x816);
            }
          }
          func_0x(pbStack_938,4);
        }
        uStack_93c = puVar21[uStack_924] & 0x7fff;
        uVar18 = uStack_93c;
        uVar16 = uStack_928;
        if (uStack_93c < uStack_928) {
          if ((((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
              (lVar10 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                         (ulonglong)*puRam0000000000f8c660), lVar10 != 0)) &&
             ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
              (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_9b8 = (uint *)0x0;
              (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x81d);
            }
          }
          func_0x(pbStack_938,4);
          uVar18 = uStack_93c;
          uVar16 = uStack_928;
        }
        do {
          if (-1 < (short)puVar21[(ulonglong)(uStack_924 - 1) + 1]) break;
          uVar19 = uStack_928;
          if (((uStack_924 != 1) &&
              (uVar19 = *(ushort *)
                         (pbStack_938 +
                         (ulonglong)uStack_924 * 2 + (((ulonglong)uStack_930 >> 0x20) - 2)) & 0x7fff
              , uVar19 < uStack_928)) ||
             ((*(ushort *)
                (pbStack_938 + (ulonglong)uStack_924 * 2 + ((ulonglong)uStack_930 >> 0x20)) & 0x7fff
              ) < uVar19)) {
            uStack_928 = uVar16;
            func_0x(pbStack_938,7);
            uVar18 = uStack_93c;
            uVar16 = uStack_928;
          }
          if ((uVar19 < uStack_928) || (uVar18 < uVar19)) goto code_r0x00100c52;
          if (*(ushort *)(pbStack_938 + uVar19) == 5) {
            uStack_93e = uStack_93e | 2;
            uStack_924 = uStack_924 - 1;
            uStack_916 = (undefined2)uVar19;
            if ((*(ushort *)(pbStack_938 + (ulonglong)(uVar19 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_914 = uStack_914 & 0xc7ff;
            }
            else {
              uStack_914 = uStack_914 ^
                           (*(ushort *)(pbStack_938 + (ulonglong)(uVar19 & 0xffff) + 2) ^ uStack_914
                           ) & 0x3800;
            }
            uStack_914 = (uStack_914 ^ *(ushort *)(pbStack_938 + (ulonglong)(uVar19 & 0xffff) + 2))
                         & 0x7ff ^ uStack_914;
            break;
          }
          if (*(ushort *)(pbStack_938 + uVar19) < 0x400) break;
          uStack_93e = uStack_93e | 1;
          uStack_924 = uStack_924 - 1;
        } while (uStack_924 != 0);
      }
      if ((*pbStack_938 & 0x40) == 0) {
        uStack_91a = 0;
        uStack_918 = 0;
      }
      else {
        uStack_91a = (undefined2)uVar18;
        uStack_918 = (undefined2)(uVar18 >> 0x10);
        uStack_93c = uVar18 + 0xe;
        uStack_928 = uVar16;
        puVar11 = (ulonglong *)func_0x(&uStack_93e);
        uVar27 = *puVar11;
        uVar15 = (ushort)(uVar27 >> 0x30);
        uVar8 = uVar15;
        if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
          uVar8 = uVar15 & 0xdfff;
          if ((uVar27 & 0x4000000000000000) != 0) {
            uVar8 = uVar15 | 0x2000;
          }
        }
        iVar9 = iVar13;
        if (uVar8 == 0xfffc) {
          iVar9 = (int)((uVar27 >> 0x20 & 0xffff) >> 5);
        }
        uVar18 = uStack_93c + iVar9;
        uStack_93c = uVar18;
        uVar16 = uStack_928;
      }
      uStack_928 = uVar16;
      if (((byte *)CONCAT62(uStack_920,uStack_922) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_920,uStack_922) < pbStack_938 + uVar18)) {
        if (((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
           (((lVar10 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                        (ulonglong)*puRam0000000000f8c660), lVar10 != 0 &&
             (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
            (*(char *)(lVar10 + 0x499) != '\0')))) {
          if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
            (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_9b8 = (uint *)0x0;
            (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x877);
          }
        }
        func_0x(pbStack_938,0x12);
        uVar18 = uStack_93c;
      }
      uVar16 = uStack_928;
      if (0x3f3b < uVar18 - 1) {
        if (((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
           ((lVar10 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                       (ulonglong)*puRam0000000000f8c660), lVar10 != 0 &&
            ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
             (*(char *)(lVar10 + 0x499) != '\0')))))) {
          if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
            (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_9b8 = (uint *)0x0;
            (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x87c);
          }
        }
        func_0x(pbStack_938,5);
        uVar18 = uStack_93c;
        uVar16 = uStack_928;
      }
    }
code_r0x00100c52:
    if (uVar18 < 9) {
      bVar12 = *pbStack_938 & 0xe;
joined_r0x00100c87:
      uVar19 = 9;
      if ((bVar12 == 0) || (uVar19 = 9, bVar12 == 0xc)) goto code_r0x00100c91;
    }
  }
  else {
    if (uVar18 == 0) {
      func_0x(&uStack_93e);
      uVar18 = uStack_93c;
    }
    uVar16 = CONCAT22(uStack_928._2_2_,(undefined2)uStack_928);
    if (uVar18 < 9) {
      bVar12 = *pbStack_938 & 0x1c;
      goto joined_r0x00100c87;
    }
  }
  uVar19 = uVar18;
code_r0x00100c91:
  if (0x1f9d < uVar19) {
    puStack_9b8 = (uint *)0x0;
    uStack_928 = uVar16;
    (*pcRam0000000000f8c5f0)(1,0x14c80a0,0x1493748,0x1e87);
    uVar16 = uStack_928;
  }
  uStack_928 = uVar16;
  func_0x(auStack_888,&sStack_940);
  psVar6 = psStack_950;
  uVar18 = *puStack_970;
  if (uVar18 != 0x3c) {
    puVar21 = (ushort *)(psStack_950 + 1);
    psVar24 = psStack_950;
    do {
      puVar23 = puStack_970;
      puStack_9b8 = (uint *)((ulonglong)puStack_9b8 & 0xffffffff00000000);
      func_0x(&uStack_990,-uVar18,uVar18 & 0xffff,0);
      if (*psVar24 == 0) {
        if ((uStack_990 & 0xc0000000) == 0x80000000) {
          iVar9 = func_0x(puVar21);
          if (iVar9 == 0) {
code_r0x00101629:
            piVar26 = (int *)0x0;
            aiStack_998[0] = 0;
          }
          else {
            piVar26 = (int *)func_0x(psVar6 + 0x15,&uStack_990,aiStack_998,auStack_948);
          }
        }
        else {
          pbVar2 = *(byte **)(psVar6 + 4);
          bVar12 = *pbVar2;
          psVar24 = psStack_950;
          iVar9 = iVar13;
          if ((bVar12 & 0x10) == 0) {
            if ((1 << (bVar12 & 0xe) & 0x1105U) != 0) {
              uVar8 = ~(uStack_98a >> 4);
              goto code_r0x00100dc5;
            }
code_r0x00100e03:
            if ((int)uStack_990 < 0) {
              if (*(int *)(psVar6 + 2) == 0) {
                uVar16 = *(uint *)(psVar6 + 8);
                uVar27 = (ulonglong)uVar16;
                *(uint *)(psVar6 + 10) = uVar16;
                *puVar21 = 0;
                bVar12 = *pbVar2;
                if ((bVar12 & 0x10) != 0) {
                  uVar16 = uVar16 + 2 + (*(ushort *)(pbVar2 + uVar27) + 7 >> 3);
                  uVar27 = (ulonglong)uVar16;
                  *(uint *)(psVar6 + 10) = uVar16;
                  bVar12 = *pbVar2;
                }
                if ((bVar12 & 0x20) == 0) {
                  *(int *)(psVar6 + 2) = (int)uVar27;
                  psVar6[0xe] = 0;
                  *(int *)(psVar6 + 0xc) = (int)uVar27;
                }
                else {
                  puVar22 = (ushort *)(pbVar2 + uVar27);
                  uVar8 = *puVar22;
                  psVar6[0xe] = uVar8;
                  if (uVar8 == 0) {
                    if ((((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
                        (lVar14 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                                   (ulonglong)*puRam0000000000f8c660), lVar14 != 0)) &&
                       ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                        (*(char *)(lVar14 + 0x499) != '\0')))) {
                      if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
                        (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        puStack_9b8 = (uint *)0x0;
                        (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x80f);
                      }
                    }
                    func_0x(*(undefined8 *)(psVar6 + 4),3);
                    uVar27 = (ulonglong)*(uint *)(psVar6 + 10);
                    uVar8 = psVar6[0xe];
                  }
                  uVar16 = (int)uVar27 + (uVar8 + 1) * 2;
                  *(uint *)(psVar6 + 0xc) = uVar16;
                  if (0x1f9e < uVar16) {
                    if (((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
                       ((lVar14 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                                   (ulonglong)*puRam0000000000f8c660), lVar14 != 0 &&
                        ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                         (*(char *)(lVar14 + 0x499) != '\0')))))) {
                      if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
                        (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        puStack_9b8 = (uint *)0x0;
                        (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x816);
                      }
                    }
                    func_0x(*(undefined8 *)(psVar6 + 4),4);
                    uVar8 = psVar6[0xe];
                    uVar16 = *(uint *)(psVar6 + 0xc);
                  }
                  uVar27 = (ulonglong)uVar8;
                  uVar8 = puVar22[uVar27];
                  *(uint *)(psVar6 + 2) = uVar8 & 0x7fff;
                  if ((uVar8 & 0x7fff) < uVar16) {
                    if ((((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
                        (lVar14 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                                   (ulonglong)*puRam0000000000f8c660), lVar14 != 0)) &&
                       ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                        (*(char *)(lVar14 + 0x499) != '\0')))) {
                      if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
                        (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        puStack_9b8 = (uint *)0x0;
                        (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x81d);
                      }
                    }
                    func_0x(*(undefined8 *)(psVar6 + 4),4);
                    uVar27 = (ulonglong)(ushort)psVar6[0xe];
                  }
                  if ((short)puVar22[(ulonglong)((int)uVar27 - 1) + 1] < 0) {
                    lVar14 = *(longlong *)(psVar6 + 4);
                    do {
                      if ((int)uVar27 == 1) {
                        uVar16 = *(uint *)(psVar6 + 0xc);
                        uVar19 = uVar16;
code_r0x00101198:
                        if ((*(ushort *)((ulonglong)*(uint *)(psVar6 + 10) + lVar14 + uVar27 * 2) &
                            0x7fff) < uVar16) goto code_r0x001011a5;
                      }
                      else {
                        uVar19 = *(uint *)(psVar6 + 0xc);
                        uVar16 = *(ushort *)
                                  ((ulonglong)*(uint *)(psVar6 + 10) + lVar14 + -2 + uVar27 * 2) &
                                 0x7fff;
                        if (uVar19 <= uVar16) goto code_r0x00101198;
code_r0x001011a5:
                        func_0x(lVar14,7);
                        uVar19 = *(uint *)(psVar6 + 0xc);
                      }
                      if ((uVar16 < uVar19) || (*(uint *)(psVar6 + 2) < uVar16))
                      goto code_r0x00101488;
                      lVar14 = *(longlong *)(psVar6 + 4);
                      if (*(ushort *)(lVar14 + (ulonglong)uVar16) == 5) {
                        *puVar21 = *puVar21 | 2;
                        psVar6[0xe] = psVar6[0xe] + -1;
                        psVar6[0x15] = (short)uVar16;
                        lVar14 = (ulonglong)(uVar16 & 0xffff) + *(longlong *)(psVar6 + 4);
                        uVar8 = psVar6[0x16] & 0xc7ffU;
                        if ((*(ushort *)(lVar14 + 2) >> 0xe & 1) != 0) {
                          uVar8 = *(ushort *)(lVar14 + 2) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                        }
                        psVar6[0x16] = uVar8;
                        psVar6[0x16] = (uVar8 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar8;
                        goto code_r0x0010126f;
                      }
                      if (*(ushort *)(lVar14 + (ulonglong)uVar16) < 0x400) goto code_r0x0010126f;
                      sVar25 = psVar6[0xe];
                      *puVar21 = *puVar21 | 1;
                      uVar8 = sVar25 - 1;
                      psVar6[0xe] = uVar8;
                      if (uVar8 == 0) goto code_r0x0010126f;
                      uVar27 = (ulonglong)uVar8;
                    } while ((short)puVar22[(ulonglong)(uVar8 - 1) + 1] < 0);
                    uVar27 = (ulonglong)*(uint *)(psVar6 + 2);
                  }
                  else {
code_r0x0010126f:
                    uVar27 = (ulonglong)*(uint *)(psVar6 + 2);
                  }
                }
                if ((**(byte **)(psVar6 + 4) & 0x40) == 0) {
                  *(undefined4 *)(psVar6 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar6 + 0x13) = (int)uVar27;
                  *(int *)(psVar6 + 2) = (int)uVar27 + 0xe;
                  puVar11 = (ulonglong *)func_0x(puVar21);
                  uVar15 = (ushort)(*puVar11 >> 0x30);
                  uVar8 = uVar15;
                  if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
                    uVar8 = uVar15 & 0xdfff;
                    if ((uVar15 >> 0xe & 1) != 0) {
                      uVar8 = uVar15 | 0x2000;
                    }
                  }
                  iVar9 = iVar13;
                  if (uVar8 == 0xfffc) {
                    iVar9 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar9;
                  uVar27 = (ulonglong)*(uint *)(psVar6 + 2);
                }
                iVar9 = (int)uVar27;
                if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar6 + 0xf) < uVar27 + *(longlong *)(psVar6 + 4))) {
                  if (((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
                     (((lVar14 = *(longlong *)
                                  (*(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                                  (ulonglong)*puRam0000000000f8c660), lVar14 != 0 &&
                       (lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0)) &&
                      (*(char *)(lVar14 + 0x499) != '\0')))) {
                    if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
                      (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      puStack_9b8 = (uint *)0x0;
                      (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x877);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar6 + 4),0x12);
                  iVar9 = *(int *)(psVar6 + 2);
                }
                if (0x3f3b < iVar9 - 1U) {
                  if (((cRam0000000001a1ddcb != '\0') || ((bRam0000000001a2e6d0 & 1) != 0)) &&
                     ((lVar14 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam0000000000f8c658 * 8) + 8 +
                                 (ulonglong)*puRam0000000000f8c660), lVar14 != 0 &&
                      ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                       (*(char *)(lVar14 + 0x499) != '\0')))))) {
                    if ((cRam0000000001a1dcbb == '\0') && ((bRam0000000001a2e6d0 & 2) == 0)) {
                      (*pcRam0000000000f8c5f8)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      puStack_9b8 = (uint *)0x0;
                      (*pcRam0000000000f8c5f0)(1,0x130e7f8,0x142e4c8,0x87c);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar6 + 4),5);
                }
              }
code_r0x00101488:
              sVar25 = -(short)uStack_990;
              puVar23 = puStack_970;
              psVar24 = psStack_950;
              if ((uStack_98a & 0x10) != 0) {
                bVar12 = **(byte **)(psVar6 + 4);
                if ((bVar12 & 0x10) == 0) {
                  if ((1 << (bVar12 & 0xe) & 0x1105U) != 0) {
code_r0x001014fa:
                    aiStack_998[0] = *piStack_988;
                    piVar26 = piStack_988 + 1;
                    goto code_r0x00101631;
                  }
                }
                else if (((int)*(uint *)(psVar6 + 8) <= (int)uStack_990) ||
                        (*(ushort *)(*(byte **)(psVar6 + 4) + *(uint *)(psVar6 + 8)) < uStack_98c))
                goto code_r0x001014fa;
              }
              lVar14 = (longlong)sVar25;
              piVar26 = *(int **)(psVar6 + 4);
              if ((uint)(ushort)psVar6[0xe] < (uint)(int)sVar25) {
                aiStack_998[0] = 0;
              }
              else {
                uVar16 = *(uint *)(psVar6 + 10);
                if (sVar25 == 1) {
                  uVar19 = *(uint *)(psVar6 + 0xc);
                  uVar16 = *(ushort *)((longlong)piVar26 + lVar14 * 2 + (ulonglong)uVar16) & 0x7fff;
code_r0x00101538:
                  if (uVar16 < uVar19) goto code_r0x0010153c;
                }
                else {
                  puVar22 = (ushort *)((longlong)piVar26 + lVar14 * 2 + (ulonglong)uVar16);
                  uVar19 = *(ushort *)((longlong)piVar26 + lVar14 * 2 + ((ulonglong)uVar16 - 2)) &
                           0x7fff;
                  piVar26 = *(int **)(psVar6 + 4);
                  uVar16 = *puVar22 & 0x7fff;
                  if (*(uint *)(psVar6 + 0xc) <= uVar19) goto code_r0x00101538;
code_r0x0010153c:
                  func_0x(piVar26,7);
                  piVar26 = *(int **)(psVar6 + 4);
                }
                piVar26 = (int *)((longlong)piVar26 + (ulonglong)uVar19);
                aiStack_998[0] = uVar16 - uVar19;
                puVar23 = puStack_970;
                psVar24 = psStack_950;
              }
            }
            else if ((uStack_98a & 8) == 0) {
              if ((uStack_98a & 0x10) != 0) {
                if ((bVar12 & 0x10) == 0) {
                  if ((1 << (bVar12 & 0xe) & 0x1105U) != 0) {
code_r0x00100e63:
                    aiStack_998[0] = *piStack_988;
                    piVar26 = piStack_988 + 1;
                    goto code_r0x00101631;
                  }
                }
                else if (((int)*(uint *)(psVar6 + 8) <= (int)uStack_990) ||
                        (*(ushort *)(pbVar2 + *(uint *)(psVar6 + 8)) < uStack_98c))
                goto code_r0x00100e63;
              }
              piVar26 = (int *)(pbVar2 + (int)uStack_990);
              aiStack_998[0] = 0;
            }
            else {
              piVar26 = (int *)0x1093234;
              aiStack_998[0] = 1;
              if ((pbVar2[(int)uStack_990] & (byte)(1 << ((byte)uStack_98a & 7))) == 0) {
                piVar26 = (int *)0x1093858;
              }
            }
          }
          else {
            uVar16 = *(uint *)(psVar6 + 8);
            if ((int)uStack_990 < (int)uVar16) {
              if ((uint)*(ushort *)(pbVar2 + uVar16) < (uint)uStack_98c) {
                uVar8 = ~(uStack_98a >> 4);
              }
              else {
                uVar19 = uStack_98c - 1;
                iVar9 = 1;
                uVar8 = (ushort)(pbVar2[(ulonglong)(uVar19 >> 3) + (ulonglong)uVar16 + 2] >>
                                ((byte)uVar19 & 7));
              }
            }
            else {
              uVar8 = ~(uStack_98a >> 4);
            }
code_r0x00100dc5:
            if ((uVar8 & 1) == 0) {
              if ((iVar9 != 0) || ((uStack_98a & 0x10) == 0)) goto code_r0x00100e03;
              aiStack_998[0] = *piStack_988;
              piVar26 = piStack_988 + 1;
            }
            else {
              aiStack_998[0] = 0;
              piVar26 = (int *)0x0;
            }
          }
        }
      }
      else {
        puStack_9b8 = auStack_978;
        auStack_978[0] = 0;
        piVar26 = (int *)func_0x(puVar21,&uStack_990);
        if ((((*psVar24 != 0) && (plVar3 = *(longlong **)(psVar24 + 8), plVar3 != (longlong *)0x0))
            && (*plVar3 != 0)) && (((uStack_98a & 8) == 0 && ((auStack_978[0] & 1) == 0)))) {
          if ((piVar26 == (int *)0x0) || (piVar26 == (int *)0x1093234)) goto code_r0x00101629;
          uStack_9a0 = auStack_978[0];
          piStack_9a8 = aiStack_998;
          uStack_9b0 = 0;
          puStack_9b8 = (uint *)0x0;
          piVar26 = (int *)func_0x(plVar3,&uStack_990,piVar26,aiStack_998[0]);
        }
      }
code_r0x00101631:
      func_0x(auStack_888,uVar18,piVar26);
      uVar18 = puVar23[1];
      puStack_970 = puVar23 + 1;
      lVar14 = lStack_968;
    } while (uVar18 != 0x3c);
  }
  func_0x(lVar14,auStack_888);
  func_0x(uStack_48 ^ (ulonglong)auStack_9d8);
  return;
}

