
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  ulonglong *puVar1;
  ulonglong uVar2;
  code *pcVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  longlong unaff_GS_OFFSET;
  
  puVar1 = (ulonglong *)(param_1 + 0x10);
  if (*(int *)puVar1 == 0) {
    LOCK();
    uVar2 = *puVar1;
    if (uVar2 == 0) {
      *puVar1 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (uVar2 == 0) {
      lVar5 = *(longlong *)(param_1 + 8);
      if (*(longlong *)(param_1 + 8) == param_1) {
        lVar5 = 0;
      }
      lVar6 = 0;
      if (lVar5 != 0) {
        lVar6 = lVar5 + -0x10;
      }
      func_0x(param_1,lVar6);
      if ((*_DAT_ != '\0') && (iVar4 = (*_DAT_)(), iVar4 == (iVar4 / 5) * 5)) {
        func_0x();
      }
      pcVar3 = (code *)swi(3);
      (*pcVar3)();
      return;
    }
  }
  pcVar3 = (code *)swi(3);
  (*pcVar3)();
  return;
}

