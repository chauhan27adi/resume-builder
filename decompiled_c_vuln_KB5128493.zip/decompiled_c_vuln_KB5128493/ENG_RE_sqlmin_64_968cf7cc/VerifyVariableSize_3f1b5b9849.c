
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  ushort *puVar1;
  uint uVar2;
  longlong *plVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  uint *puVar7;
  ulonglong *puVar8;
  longlong lVar9;
  uint uVar10;
  ushort uVar11;
  uint uVar12;
  ulonglong uVar13;
  uint uVar14;
  short sVar15;
  byte *pbVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  uint *puVar20;
  int iVar21;
  uint *puVar22;
  ushort *puVar23;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  short *psStackX_10;
  uint auStackX_18 [2];
  uint uStackX_20;
  
  lVar9 = *(longlong *)(param_1 + 8);
  puVar20 = (uint *)0x0;
  iVar19 = 0;
  uStackX_20 = 0;
  iVar21 = 0;
  puVar22 = puVar20;
  puVar7 = puVar20;
  psStackX_10 = param_2;
  if (*(int *)(**(longlong **)(lVar9 + 0x160) + 0x14) != 0) {
    do {
      iVar21 = (int)puVar22;
      iVar19 = (int)puVar20;
      uVar5 = 0;
      iVar6 = *(int *)(**(longlong **)(lVar9 + 0x160) + 0x14);
      if (iVar6 == 0) break;
      if (puVar7 == (uint *)0x0) {
        uVar12 = 0;
      }
      else {
        uVar12 = *puVar7;
      }
      iVar17 = uVar12 - 1;
      iVar18 = -iVar17;
      if (iVar6 < iVar18) break;
      while ((puVar7 = (uint *)func_0x(*(undefined8 *)(lVar9 + 0x160),iVar17),
             puVar7 == (uint *)0x0 || ((*(byte *)(puVar7 + 8) & 0x10) != 0))) {
        lVar9 = *(longlong *)(param_1 + 8);
        iVar17 = iVar17 + -1;
        iVar18 = iVar18 + 1;
        if (*(int *)(**(longlong **)(lVar9 + 0x160) + 0x14) < iVar18) goto LAB_;
      }
      lVar9 = *(longlong *)(param_1 + 8);
      if (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar7 + 0xd) + 0x14ac710) + 0x14ad9e0
                   ) == '\x01') {
        puVar1 = (ushort *)(param_2 + 1);
        bVar4 = *(byte *)(puVar7 + 8);
        uVar12 = (uint)*(ushort *)(puVar7 + 0xe);
        if (*param_2 != 0) {
          auStackX_18[0] = 0;
          lVar9 = func_0x(puVar1,puVar7);
          uVar14 = auStackX_8[0];
          if ((((*param_2 != 0) && (plVar3 = *(longlong **)(param_2 + 8), plVar3 != (longlong *)0x0)
               ) && (*plVar3 != 0)) &&
             (((*(byte *)((longlong)puVar7 + 6) & 8) == 0 && ((auStackX_18[0] & 1) == 0)))) {
            if ((lVar9 == 0) || (lVar9 == 0x14ac274)) goto LAB_;
            func_0x(plVar3,puVar7,lVar9,auStackX_8[0],0,0,auStackX_8,auStackX_18[0])
            ;
            uVar14 = auStackX_8[0];
          }
          goto LAB_;
        }
        uVar2 = *puVar7;
        if ((uVar2 & 0xc0000000) == 0x80000000) {
          iVar6 = func_0x(puVar1);
          if (iVar6 != 0) {
            func_0x(param_2 + 0x15,puVar7,auStackX_8,auStackX_18);
            uVar14 = auStackX_8[0];
            goto LAB_;
          }
LAB_:
          auStackX_8[0] = 0;
        }
        else {
          if (((bVar4 & 2) != 0) || ((*(byte *)((longlong)puVar7 + 6) & 0x10) != 0)) {
            pbVar16 = *(byte **)(param_2 + 4);
            if ((*pbVar16 & 0x10) == 0) {
              if ((1 << (*pbVar16 & 0xe) & 0x1105U) != 0) goto LAB_;
              uVar11 = uVar5;
              uVar5 = 1;
LAB_:
              if ((bVar4 & 2) != 0) goto LAB_;
            }
            else {
              uVar14 = *(uint *)(param_2 + 8);
              if ((int)uVar14 <= (int)uVar2) {
LAB_:
                uVar11 = ~(*(ushort *)((longlong)puVar7 + 6) >> 4) & 1;
                goto LAB_;
              }
              if ((uint)*(ushort *)(pbVar16 + uVar14) < (uint)*(ushort *)(puVar7 + 1))
              goto LAB_;
              if ((bVar4 & 2) == 0) goto LAB_;
              uVar10 = *(ushort *)(puVar7 + 1) - 1;
              uVar5 = 1;
              uVar11 = pbVar16[(ulonglong)(uVar10 >> 3) + (ulonglong)uVar14 + 2] >>
                       ((byte)uVar10 & 7) & 1;
LAB_:
              if (uVar11 != 0) goto LAB_;
            }
            if ((uVar5 == 0) && ((*(byte *)((longlong)puVar7 + 6) & 0x10) != 0)) {
              uVar14 = **(uint **)(puVar7 + 2);
              goto LAB_;
            }
          }
LAB_:
          if ((int)uVar2 < 0) {
            if (*(int *)(param_2 + 2) == 0) {
              pbVar16 = *(byte **)(param_2 + 4);
              uVar12 = *(uint *)(param_2 + 8);
              uVar13 = (ulonglong)uVar12;
              *puVar1 = 0;
              *(uint *)(param_2 + 10) = uVar12;
              bVar4 = *pbVar16;
              if ((bVar4 & 0x10) != 0) {
                uVar12 = uVar12 + 2 + (*(ushort *)(pbVar16 + uVar13) + 7 >> 3);
                uVar13 = (ulonglong)uVar12;
                *(uint *)(param_2 + 10) = uVar12;
                bVar4 = *pbVar16;
              }
              if ((bVar4 & 0x20) == 0) {
                *(int *)(param_2 + 2) = (int)uVar13;
                param_2[0xe] = 0;
                *(int *)(param_2 + 0xc) = (int)uVar13;
              }
              else {
                puVar23 = (ushort *)(pbVar16 + uVar13);
                uVar5 = *puVar23;
                param_2[0xe] = uVar5;
                if (uVar5 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar9 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar9 != 0)) &&
                     ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                      (*(char *)(lVar9 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      (*_DAT_)(1,0x1727838,0x1847508,0x80f,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 4),3);
                  uVar13 = (ulonglong)*(uint *)(param_2 + 10);
                  uVar5 = param_2[0xe];
                }
                uVar12 = (int)uVar13 + (uVar5 + 1) * 2;
                *(uint *)(param_2 + 0xc) = uVar12;
                if (0x1f9e < uVar12) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar9 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar9 != 0 &&
                      ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                       (*(char *)(lVar9 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x1727838,0x1847508,0x816,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 4),4);
                  uVar5 = param_2[0xe];
                  uVar12 = *(uint *)(param_2 + 0xc);
                }
                uVar13 = (ulonglong)uVar5;
                uVar5 = puVar23[uVar13];
                *(uint *)(param_2 + 2) = uVar5 & 0x7fff;
                if ((uVar5 & 0x7fff) < uVar12) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar9 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar9 != 0)) &&
                     ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                      (*(char *)(lVar9 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x1727838,0x1847508,0x81d,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 4),4);
                  uVar13 = (ulonglong)(ushort)param_2[0xe];
                }
                if ((short)puVar23[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
                  pbVar16 = *(byte **)(param_2 + 4);
                  do {
                    if ((int)uVar13 == 1) {
                      uVar12 = *(uint *)(param_2 + 0xc);
                      uVar14 = uVar12;
LAB_:
                      if ((*(ushort *)(pbVar16 + uVar13 * 2 + (ulonglong)*(uint *)(param_2 + 10)) &
                          0x7fff) < uVar12) goto LAB_;
                    }
                    else {
                      uVar14 = *(uint *)(param_2 + 0xc);
                      uVar12 = *(ushort *)
                                (pbVar16 + uVar13 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                               0x7fff;
                      if (uVar14 <= uVar12) goto LAB_;
LAB_:
                      func_0x(pbVar16,7);
                      uVar14 = *(uint *)(param_2 + 0xc);
                    }
                    if ((uVar12 < uVar14) || (*(uint *)(param_2 + 2) < uVar12)) goto LAB_;
                    pbVar16 = *(byte **)(param_2 + 4);
                    if (*(ushort *)(pbVar16 + uVar12) == 5) {
                      *puVar1 = *puVar1 | 2;
                      param_2[0xe] = param_2[0xe] + -1;
                      param_2[0x15] = (short)uVar12;
                      lVar9 = (ulonglong)(uVar12 & 0xffff) + *(longlong *)(param_2 + 4);
                      uVar5 = param_2[0x16] & 0xc7ffU;
                      if ((*(ushort *)(lVar9 + 2) >> 0xe & 1) != 0) {
                        uVar5 = *(ushort *)(lVar9 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                      }
                      param_2[0x16] = uVar5;
                      param_2[0x16] = (uVar5 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar5;
                      goto LAB_;
                    }
                    if (*(ushort *)(pbVar16 + uVar12) < 0x400) goto LAB_;
                    *puVar1 = *puVar1 | 1;
                    uVar5 = param_2[0xe] - 1;
                    param_2[0xe] = uVar5;
                    if (uVar5 == 0) goto LAB_;
                    uVar13 = (ulonglong)uVar5;
                  } while ((short)puVar23[(ulonglong)(uVar5 - 1) + 1] < 0);
                  uVar13 = (ulonglong)*(uint *)(param_2 + 2);
                }
                else {
LAB_:
                  uVar13 = (ulonglong)*(uint *)(param_2 + 2);
                  pbVar16 = *(byte **)(param_2 + 4);
                }
              }
              iVar6 = 0;
              if ((*pbVar16 & 0x40) == 0) {
                *(undefined4 *)(param_2 + 0x13) = 0;
              }
              else {
                *(int *)(param_2 + 0x13) = (int)uVar13;
                *(int *)(param_2 + 2) = (int)uVar13 + 0xe;
                puVar8 = (ulonglong *)func_0x(puVar1);
                uVar11 = (ushort)(*puVar8 >> 0x30);
                uVar5 = uVar11;
                if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
                  uVar5 = uVar11 & 0xdfff;
                  if ((uVar11 >> 0xe & 1) != 0) {
                    uVar5 = uVar11 | 0x2000;
                  }
                }
                if (uVar5 == 0xfffc) {
                  iVar6 = (int)((*puVar8 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar6;
                uVar13 = (ulonglong)*(uint *)(param_2 + 2);
              }
              iVar6 = (int)uVar13;
              if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
                 (*(ulonglong *)(param_2 + 0xf) < uVar13 + *(longlong *)(param_2 + 4))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar9 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                     lVar9 != 0 && (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    (*_DAT_)(1,0x1727838,0x1847508,0x877,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),0x12);
                iVar6 = *(int *)(param_2 + 2);
              }
              if (0x3f3b < iVar6 - 1U) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar9 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar9 != 0 &&
                    ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                     (*(char *)(lVar9 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    func_0x(*(undefined8 *)(param_2 + 4),5);
                    goto LAB_;
                  }
                  (*_DAT_)(1,0x1727838,0x1847508,0x87c,0);
                }
                func_0x(*(undefined8 *)(param_2 + 4),5);
              }
            }
LAB_:
            sVar15 = -*(short *)puVar7;
            if ((*(byte *)((longlong)puVar7 + 6) & 0x10) != 0) {
              bVar4 = **(byte **)(param_2 + 4);
              if ((bVar4 & 0x10) == 0) {
                if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                  uVar14 = **(uint **)(puVar7 + 2);
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(param_2 + 8) <= (int)*puVar7) ||
                      (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
                       *(ushort *)(puVar7 + 1))) goto LAB_;
            }
            if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar15) goto LAB_;
            lVar9 = (ulonglong)*(uint *)(param_2 + 10) + *(longlong *)(param_2 + 4);
            uVar12 = *(ushort *)(lVar9 + (longlong)sVar15 * 2) & 0x7fff;
            if (sVar15 == 1) {
              uVar14 = *(uint *)(param_2 + 0xc);
LAB_:
              if (uVar12 < uVar14) goto LAB_;
            }
            else {
              uVar14 = *(ushort *)(lVar9 + -2 + (longlong)sVar15 * 2) & 0x7fff;
              if (*(uint *)(param_2 + 0xc) <= uVar14) goto LAB_;
LAB_:
              func_0x(*(longlong *)(param_2 + 4),7);
            }
            uVar14 = uVar12 - uVar14;
          }
          else {
            if ((*(ushort *)((longlong)puVar7 + 6) & 8) != 0) {
              auStackX_8[0] = 1;
              goto LAB_;
            }
            uVar14 = uVar12;
            if ((*(ushort *)((longlong)puVar7 + 6) & 0x10) != 0) {
              bVar4 = **(byte **)(param_2 + 4);
              if ((bVar4 & 0x10) == 0) {
                if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) goto LAB_;
              }
              else if (((int)*(uint *)(param_2 + 8) <= (int)uVar2) ||
                      (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
                       *(ushort *)(puVar7 + 1))) {
LAB_:
                uVar14 = **(uint **)(puVar7 + 2);
                if ((uVar12 != 0) && (uVar14 != uVar12)) {
                  (*_DAT_)(1,0x18d55a8,0x18d3fa8,0x381,0);
                }
              }
            }
          }
LAB_:
          auStackX_8[0] = uVar14;
          if ((0x18 < auStackX_8[0]) && ((*(byte *)((longlong)puVar7 + 0x21) & 0x10) != 0)) {
            auStackX_8[0] = 0x18;
          }
        }
LAB_:
        lVar9 = *(longlong *)(param_1 + 8);
        puVar20 = (uint *)(ulonglong)(iVar19 + 2 + auStackX_8[0]);
        iVar19 = 0;
        if (8 < auStackX_8[0]) {
          iVar19 = 2;
        }
        puVar22 = (uint *)(ulonglong)(iVar21 + iVar19 + auStackX_8[0]);
        param_2 = psStackX_10;
      }
      iVar21 = (int)puVar22;
      iVar19 = (int)puVar20;
      uStackX_20 = uStackX_20 + 1;
    } while (uStackX_20 < *(uint *)(**(longlong **)(lVar9 + 0x160) + 0x14));
  }
LAB_:
  if ((*(int *)(lVar9 + 0xbc) < iVar19) || (*(int *)(lVar9 + 0xc4) < iVar21)) {
    iVar21 = iVar21 - *(int *)(lVar9 + 0xc4);
    iVar19 = iVar19 - *(int *)(lVar9 + 0xbc);
    if (iVar19 <= iVar21) {
      iVar19 = iVar21;
    }
    (*_DAT_)(6,0xb,0x10,1,iVar19);
  }
  return;
}

