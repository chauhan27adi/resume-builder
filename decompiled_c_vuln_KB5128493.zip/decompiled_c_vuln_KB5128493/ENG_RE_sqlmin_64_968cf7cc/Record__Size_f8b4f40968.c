
/* WARNING: Control flow encountered bad instruction data */

ulonglong FUN_(short *param_1)

{
  code *pcVar1;
  ulonglong uVar2;
  
  if (*param_1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 2) != 0) {
    if (8 < *(uint *)(param_1 + 2)) {
      return (ulonglong)*(uint *)(param_1 + 2);
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pcVar1 = (code *)swi(3);
  uVar2 = (*pcVar1)();
  return uVar2;
}

