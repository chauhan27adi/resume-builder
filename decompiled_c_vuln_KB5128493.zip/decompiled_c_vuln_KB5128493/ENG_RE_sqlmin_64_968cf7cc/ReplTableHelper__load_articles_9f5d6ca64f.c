
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  int *piVar1;
  byte bVar2;
  undefined2 uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  longlong lVar8;
  undefined8 *puVar9;
  byte *pbVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  longlong unaff_GS_OFFSET;
  undefined auStack_138 [32];
  undefined8 uStack_118;
  longlong lStack_110;
  int iStack_108;
  undefined4 uStack_104;
  undefined4 auStack_100 [2];
  int iStack_f8;
  int iStack_f4;
  longlong lStack_f0;
  int iStack_e8;
  undefined8 uStack_e0;
  undefined2 uStack_d8;
  undefined2 uStack_d6;
  undefined8 uStack_d0;
  undefined2 uStack_c8;
  undefined2 uStack_c6;
  undefined8 uStack_c0;
  longlong lStack_b8;
  undefined2 uStack_b0;
  undefined8 uStack_a8;
  int iStack_a0;
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  longlong lStack_58;
  uint uStack_50;
  undefined8 *puStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  
  uStack_c0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_138;
  uVar3 = *(undefined2 *)(param_1 + 1);
  uVar15 = 0;
  if ((DAT_ & 8) == 0) {
    iStack_e8 = 0;
  }
  else {
    iStack_e8 = 1;
    iStack_f8 = (*_DAT_)();
    iStack_f4 = 0x22;
    lStack_f0 = func_0x(uVar3);
  }
  lVar11 = *(longlong *)
            (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8 + (ulonglong)*_DAT_);
  lVar12 = *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           (ulonglong)*_DAT_;
  lVar8 = *(longlong *)(lVar12 + 0x100);
  if (lVar8 == 0) {
    (*_DAT_)(0);
    lVar8 = *(longlong *)(lVar12 + 0x100);
  }
  lVar8 = *(longlong *)(lVar8 + 600);
  iStack_108 = 0;
  lVar12 = *(longlong *)(param_1[0xe] + 8);
  if ((lVar11 == 0) || (lVar8 == 0)) {
    uStack_118 = (undefined8 *)0x0;
    (*_DAT_)(1,0x1bdf770,0x1bb9db0,0xaec);
  }
  iVar5 = func_0x(*(undefined2 *)(param_1 + 1),0x1a27960);
  if ((((iVar5 == 0) && ((*(uint *)(*param_1 + 0x18) & 2) == 0)) &&
      (*(int *)(*(longlong *)(param_1[0xe] + 8) + 0x348) < 1)) &&
     ((*(uint *)(*param_1 + 0x18) & 4) == 0)) {
    func_0x(0x4977,0x10,2,0x1a27960);
  }
  iVar6 = func_0x(*(undefined2 *)(param_1 + 1),0x1a2b540);
  if (iVar6 == 0) {
    if ((((*(uint *)(*param_1 + 0x18) & 2) == 0) &&
        (*(int *)(*(longlong *)(param_1[0xe] + 8) + 0x348) < 1)) &&
       ((*(uint *)(*param_1 + 0x18) & 4) == 0)) {
      func_0x(0x4977,0x10,2,0x1a2b540);
    }
  }
  else {
    uStack_a8 = (**(code **)(**(longlong **)
                               (*(longlong *)
                                 ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8)) + 0x90) + 0x1b0))();
    uStack_b0 = *(undefined2 *)(param_1 + 1);
    lStack_b8 = 0;
    auStack_98 = ZEXT816(0);
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    auStack_68 = ZEXT816(0);
    lStack_58 = 0;
    uStack_50 = 0;
    puStack_48 = (undefined8 *)0x0;
    uStack_40 = 0;
    iStack_a0 = iVar6;
    iVar6 = func_0x(&lStack_b8,3,1);
    if (iVar6 == 0) {
      if (((*(byte *)(*param_1 + 0x18) & 2) == 0) &&
         (*(int *)(*(longlong *)(param_1[0xe] + 8) + 0x348) < 1)) {
        func_0x(0x49aa,0x10,10,0x1a2b540);
      }
    }
    else {
      lStack_110 = lStack_b8;
      uStack_118 = puStack_48;
      iVar6 = (**(code **)(*(longlong *)auStack_98._8_8_ + 0x18))(auStack_98._8_8_,0,1);
      uVar16 = uVar15;
      if (iVar6 == 0) {
        do {
          uStack_104 = 0;
          if (lStack_b8 == 0) {
            lVar11 = 0;
LAB_:
            lVar13 = lStack_b8;
            if (uVar16 < 5) goto LAB_;
          }
          else {
            uVar16 = 0;
            uVar7 = func_0x(&lStack_b8,0x17c7268,&uStack_104);
            uVar14 = (ulonglong)uVar7;
            if ((ulonglong)uVar7 == *(ulonglong *)((ulonglong)(uVar7 - 1) * 0x58 + lStack_58)) {
LAB_:
              if (uVar7 <= uStack_50) {
                lVar11 = (ulonglong)(uVar7 - 1) * 0x58 + lStack_58;
                uVar16 = *(ulonglong *)(lStack_b8 + *(longlong *)(lVar11 + 0x10));
                lVar11 = *(longlong *)(lVar11 + 8) + lStack_b8;
                goto LAB_;
              }
            }
            else {
              uVar7 = 1;
              if (uStack_50 != 0) {
                do {
                  if (uVar14 == *(ulonglong *)((ulonglong)(uVar7 - 1) * 0x58 + lStack_58))
                  goto LAB_;
                  uVar7 = uVar7 + 1;
                } while (uVar7 <= uStack_50);
                lVar11 = 0;
                goto LAB_;
              }
            }
            lVar11 = 0;
LAB_:
            lVar13 = lStack_b8;
            func_0x(&iStack_108,lVar11,uVar16);
          }
          if (iStack_108 == *(int *)param_1[0xe]) {
            auStack_100[0] = 0;
            if (lVar13 == 0) {
LAB_:
              pbVar10 = (byte *)0x0;
            }
            else {
              uVar16 = 0;
              uVar7 = func_0x(&lStack_b8,0x17c6300,auStack_100);
              uVar14 = (ulonglong)uVar7;
              if (uVar14 != *(ulonglong *)((ulonglong)(uVar7 - 1) * 0x58 + lStack_58)) {
                uVar7 = 1;
                if (uStack_50 != 0) {
                  do {
                    if (uVar14 == *(ulonglong *)((ulonglong)(uVar7 - 1) * 0x58 + lStack_58))
                    goto LAB_;
                    uVar7 = uVar7 + 1;
                  } while (uVar7 <= uStack_50);
                }
                goto LAB_;
              }
LAB_:
              if (uStack_50 < uVar7) goto LAB_;
              lVar11 = (ulonglong)(uVar7 - 1) * 0x58 + lStack_58;
              uVar16 = *(ulonglong *)(lStack_b8 + *(longlong *)(lVar11 + 0x10));
              pbVar10 = (byte *)(*(longlong *)(lVar11 + 8) + lStack_b8);
            }
            bVar2 = *pbVar10;
            if (((*(uint *)(lVar8 + 0xbc) & 4) != 0) &&
               ((iVar6 = func_0x(), iVar6 != 0 ||
                (((lVar11 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              )), lVar11 != 0 &&
                  (*(char *)(*(longlong *)(lVar11 + 0x38) + 8) != '\0')) &&
                 (iVar6 = func_0x(), iVar6 == 0)))))) {
              func_0x(&lStack_b8);
              goto LAB_;
            }
            lVar13 = lStack_b8;
            if ((bVar2 & 1) != 0) {
              puVar9 = (undefined8 *)func_0x(param_1);
              param_1[0x10] = (longlong)puVar9;
              if (puVar9 == (undefined8 *)0x0) {
                uStack_118 = puVar9;
                (*_DAT_)(1,0x1bdf938,0x1bb9db0,0xb16);
              }
              func_0x(param_1,&lStack_b8,iVar5);
              *(undefined8 *)(param_1[0x10] + 0x708) = *(undefined8 *)(param_1[0xe] + 8);
              func_0x(param_1);
              uVar15 = 1;
              lVar13 = lStack_b8;
            }
          }
          uStack_118 = puStack_48;
          lStack_110 = lVar13;
          iVar6 = (**(code **)(*(longlong *)auStack_98._8_8_ + 0x18))(auStack_98._8_8_,0,1);
        } while (iVar6 == 0);
        if ((((int)uVar15 != 0) && (lVar12 != 0)) && (*(int *)(lVar12 + 0x338) == 0)) {
          uStack_118 = (undefined8 *)CONCAT44(uStack_118._4_4_,*(undefined4 *)(lVar12 + 8));
          (*_DAT_)(0xbb,0x38,0x10,3);
        }
      }
    }
    func_0x(&lStack_b8);
  }
  if (((*(byte *)(*param_1 + 0x18) & 2) != 0) && (0 < *(int *)(lVar12 + 0x348))) {
    uStack_118 = (undefined8 *)func_0x(param_1);
    param_1[0x10] = (longlong)uStack_118;
    if (uStack_118 == (undefined8 *)0x0) {
      (*_DAT_)(1,0x1bdf938,0x1bb9db0,0xb3c);
      uStack_118 = (undefined8 *)param_1[0x10];
    }
    *(longlong *)((longlong)uStack_118 + 0x708) = lVar12;
    uStack_e0 = *(undefined8 *)(lVar12 + 0x554);
    uStack_d8 = *(undefined2 *)(lVar12 + 0x55c);
    uStack_d6 = *(undefined2 *)(lVar12 + 0x55e);
    uStack_118 = &uStack_e0;
    func_0x(param_1,*(undefined4 *)(lVar12 + 0x348),0,lVar12 + 0x350);
    func_0x(param_1);
    if (0 < *(int *)(lVar12 + 0x34c)) {
      uStack_118 = (undefined8 *)func_0x(param_1);
      param_1[0x10] = (longlong)uStack_118;
      if (uStack_118 == (undefined8 *)0x0) {
        (*_DAT_)(1,0x1bdf938,0x1bb9db0,0xb4a);
        uStack_118 = (undefined8 *)param_1[0x10];
      }
      *(longlong *)((longlong)uStack_118 + 0x708) = lVar12;
      uStack_d0 = *(undefined8 *)(lVar12 + 0x560);
      uStack_c8 = *(undefined2 *)(lVar12 + 0x568);
      uStack_c6 = *(undefined2 *)(lVar12 + 0x56a);
      uStack_118 = &uStack_d0;
      func_0x(param_1,*(undefined4 *)(lVar12 + 0x34c),2,lVar12 + 0x452);
      func_0x(param_1);
    }
  }
  if ((*(byte *)(*param_1 + 0x18) & 4) != 0) {
    lVar11 = func_0x(param_1);
    param_1[0x10] = lVar11;
    if (lVar11 == 0) {
      (*_DAT_)(0xe3,0x1a,0x11,0xc);
      lVar11 = param_1[0x10];
    }
    *(longlong *)(lVar11 + 0x708) = lVar12;
    cVar4 = func_0x(param_1);
    if (cVar4 != '\0') {
      func_0x(param_1);
    }
  }
LAB_:
  lVar11 = lStack_f0;
  if ((iStack_e8 != 0) && (lStack_f0 != 0)) {
    iVar5 = (*_DAT_)();
    piVar1 = (int *)(lVar11 + 8 + (longlong)iStack_f4 * 4);
    *piVar1 = *piVar1 + (iVar5 - iStack_f8);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_138);
  return;
}

