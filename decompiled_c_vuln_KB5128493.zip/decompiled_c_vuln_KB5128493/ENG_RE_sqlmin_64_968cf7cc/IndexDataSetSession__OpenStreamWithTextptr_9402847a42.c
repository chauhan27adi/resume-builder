
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,int param_3,longlong param_4,
                 ulonglong param_5,uint param_6,longlong *param_7)

{
  ushort *puVar1;
  code *pcVar2;
  bool bVar3;
  undefined8 uVar4;
  byte bVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  longlong *plVar9;
  longlong lVar10;
  uint *puVar11;
  longlong lVar12;
  longlong lVar13;
  ulonglong *puVar14;
  longlong lVar15;
  uint uVar16;
  ulonglong uVar17;
  short sVar18;
  longlong *plVar19;
  undefined *puVar20;
  undefined *puVar21;
  ushort *puVar22;
  uint uVar23;
  int *piVar24;
  byte *pbVar25;
  uint uVar26;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_180;
  undefined auStack_178 [32];
  longlong *plStack_158;
  undefined4 auStack_150 [2];
  ulonglong uStack_148;
  uint auStack_140 [10];
  int iStack_118;
  uint uStack_114;
  uint uStack_110;
  int iStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined2 uStack_100;
  undefined4 uStack_f8;
  undefined2 uStack_f4;
  longlong *plStack_e8;
  longlong *plStack_e0;
  longlong lStack_d8;
  longlong *plStack_d0;
  longlong *plStack_c8;
  ulonglong uStack_c0;
  longlong lStack_b8;
  longlong *plStack_b0;
  undefined8 uStack_a8;
  longlong lStack_a0;
  longlong *plStack_98;
  undefined8 uStack_80;
  undefined auStack_78 [32];
  longlong alStack_58 [2];
  ulonglong uStack_48;
  
  puVar20 = auStack_178;
  uStack_80 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&iStack_118;
  plStack_b0 = param_7;
  plStack_98 = param_7;
  uStack_110 = param_6;
  uStack_108 = 0x80004005;
  plVar9 = (longlong *)0x0;
  iStack_10c = 0;
  lVar12 = param_1[2];
  plVar19 = (longlong *)param_1[3];
  *param_7 = 0;
  puVar21 = auStack_178;
  plStack_d0 = plVar19;
  plStack_c8 = param_1;
  lStack_b8 = lVar12;
  uStack_a8 = param_2;
  if ((param_4 == 0) || (puVar21 = auStack_178, param_3 != 0x10)) goto LAB_;
  lVar10 = *(longlong *)(lVar12 + 8);
  if (*(longlong *)(lVar10 + 0x478) != 0) {
    lVar10 = *(longlong *)(lVar10 + 0x478);
  }
  if ((*(byte *)(lVar10 + 0x474) & 1) == 0) {
    plStack_158 = alStack_58;
    uStack_180 = 0x100bce;
    iVar8 = func_0x(lVar12,param_5 & 0xffffffff,0x10);
    puVar21 = auStack_178;
    if (iVar8 == 0) goto LAB_;
    iStack_118 = 0x10;
    plVar19 = alStack_58;
    uVar26 = uStack_110;
  }
  else {
    uStack_180 = 0x1000d1;
    iVar8 = func_0x(lVar12,plVar19);
    puVar21 = auStack_178;
    if (iVar8 == 0) goto LAB_;
    iStack_10c = (int)*(short *)(param_4 + 2);
    uStack_180 = 0x1000f5;
    lVar10 = (**(code **)(*plVar19 + 0xe0))(plVar19,iStack_10c,auStack_78);
    puVar21 = auStack_178;
    lStack_d8 = lVar10;
    if (((*(byte *)(lVar10 + 4) & 2) != 0) ||
       (uStack_c0 = param_5, puVar21 = auStack_178,
       param_5 != *(uint *)(*(longlong *)(lVar10 + 8) + 4))) goto LAB_;
    uStack_180 = 0x100133;
    puVar11 = (uint *)func_0x
                                (*(undefined8 *)(*(longlong *)(lVar12 + 8) + 0x160),
                                 param_5 & 0xffffffff);
    uStack_180 = 0x10014f;
    (**(code **)(*param_1 + 0x80))(param_1,*(longlong *)(lVar10 + 8) + 0xc,&plStack_e0);
    if (plStack_e0 == (longlong *)0x0) {
      plStack_158 = plStack_e0;
      uStack_180 = 0x10017b;
      (*_DAT_)(1,0x19b53e8,0x1988d70,0xebc);
    }
    *(uint *)(plStack_e0 + 2) = *(uint *)(plStack_e0 + 2) & 0xfffffeff;
    if (((char)*(uint *)(plStack_e0 + 2) < '\0') ||
       ((*(byte *)((longlong)plStack_e0 + 0x34) & 1) == 0)) {
      uStack_180 = 0x1001be;
      plStack_e8 = (longlong *)func_0x(plStack_e0,0);
    }
    else if ((*(uint *)(plStack_e0 + 2) & 0x2000) == 0) {
      plStack_e8 = plStack_e0 + 9;
    }
    else {
      plStack_e8 = (longlong *)plStack_e0[0x29];
    }
    plVar19 = plStack_e8;
    uStack_180 = 0x1001d5;
    lVar12 = func_0x();
    lVar12 = -lVar12;
    bVar5 = *(byte *)(puVar11 + 8);
    puVar1 = (ushort *)((longlong)plVar19 + 2);
    if (*(short *)plVar19 == 0) {
      uVar26 = *puVar11;
      if ((uVar26 & 0xc0000000) == 0x80000000) {
        *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100a6b;
        iVar8 = func_0x(puVar1);
        if (iVar8 != 0) {
          *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100a87;
          piVar24 = (int *)func_0x((short *)((longlong)plVar19 + 0x2a),puVar11,&iStack_118,
                                           &uStack_104);
          goto LAB_;
        }
LAB_:
        iStack_118 = 0;
        piVar24 = (int *)0x0;
      }
      else {
        if (((bVar5 & 2) != 0) || ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0)) {
          pbVar25 = (byte *)plVar19[1];
          if ((*pbVar25 & 0x10) == 0) {
            if ((1 << (*pbVar25 & 0xe) & 0x1105U) != 0) goto LAB_;
            uVar6 = 0;
            bVar3 = true;
LAB_:
            if ((bVar5 & 2) != 0) goto LAB_;
          }
          else {
            uVar23 = *(uint *)(plVar19 + 2);
            if ((int)uVar23 <= (int)uVar26) {
LAB_:
              uVar6 = ~(*(ushort *)((longlong)puVar11 + 6) >> 4) & 1;
              bVar3 = false;
              goto LAB_;
            }
            if ((uint)*(ushort *)(pbVar25 + uVar23) < (uint)*(ushort *)(puVar11 + 1))
            goto LAB_;
            if ((bVar5 & 2) == 0) goto LAB_;
            uVar16 = *(ushort *)(puVar11 + 1) - 1;
            uVar6 = pbVar25[(ulonglong)(uVar16 >> 3) + (ulonglong)uVar23 + 2] >> ((byte)uVar16 & 7)
                    & 1;
            bVar3 = true;
LAB_:
            if (uVar6 != 0) goto LAB_;
          }
          if ((!bVar3) && ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0)) {
            piVar24 = *(int **)(puVar11 + 2) + 1;
            iStack_118 = **(int **)(puVar11 + 2);
            goto LAB_;
          }
        }
LAB_:
        if ((int)uVar26 < 0) {
          if (*(int *)((longlong)plVar19 + 4) == 0) {
            *puVar1 = 0;
            uVar26 = *(uint *)(plVar19 + 2);
            uVar17 = (ulonglong)uVar26;
            *(uint *)((longlong)plVar19 + 0x14) = uVar26;
            pbVar25 = (byte *)plVar19[1];
            bVar5 = *pbVar25;
            if ((bVar5 & 0x10) != 0) {
              uVar26 = uVar26 + 2 + (*(ushort *)(pbVar25 + uVar17) + 7 >> 3);
              uVar17 = (ulonglong)uVar26;
              *(uint *)((longlong)plVar19 + 0x14) = uVar26;
              bVar5 = *pbVar25;
            }
            if ((bVar5 & 0x20) == 0) {
              *(int *)((longlong)plVar19 + 4) = (int)uVar17;
              *(short *)((longlong)plVar19 + 0x1c) = 0;
              *(int *)(plVar19 + 3) = (int)uVar17;
            }
            else {
              puVar22 = (ushort *)(pbVar25 + uVar17);
              uVar6 = *puVar22;
              *(ushort *)((longlong)plVar19 + 0x1c) = uVar6;
              if (uVar6 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar10 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0)) &&
                   ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                    (*(char *)(lVar10 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100467;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_150 + lVar12 + -8) = 0;
                    *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10048d;
                    (*_DAT_)(1,0x18049b8,0x1924688,0x80f);
                  }
                }
                lVar10 = plVar19[1];
                *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10049b;
                func_0x(lVar10,3);
                uVar6 = *(ushort *)((longlong)plVar19 + 0x1c);
                uVar17 = (ulonglong)*(uint *)((longlong)plVar19 + 0x14);
              }
              uVar26 = (int)uVar17 + (uVar6 + 1) * 2;
              *(uint *)(plVar19 + 3) = uVar26;
              if (0x1f9e < uVar26) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar10 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0 &&
                    ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                     (*(char *)(lVar10 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100539;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_150 + lVar12 + -8) = 0;
                    *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10055f;
                    (*_DAT_)(1,0x18049b8,0x1924688,0x816);
                  }
                }
                lVar10 = plVar19[1];
                *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10056d;
                func_0x(lVar10,4);
                uVar6 = *(ushort *)((longlong)plVar19 + 0x1c);
                uVar26 = *(uint *)(plVar19 + 3);
              }
              uVar17 = (ulonglong)uVar6;
              uVar6 = puVar22[uVar17];
              *(uint *)((longlong)plVar19 + 4) = uVar6 & 0x7fff;
              if ((uVar6 & 0x7fff) < uVar26) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar10 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0)) &&
                   ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                    (*(char *)(lVar10 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10060a;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_150 + lVar12 + -8) = 0;
                    *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100630;
                    (*_DAT_)(1,0x18049b8,0x1924688,0x81d);
                  }
                }
                lVar10 = plVar19[1];
                *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10063e;
                func_0x(lVar10,4);
                uVar17 = (ulonglong)*(ushort *)((longlong)plVar19 + 0x1c);
              }
              if ((short)puVar22[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
                lVar10 = plVar19[1];
                do {
                  lVar13 = (ulonglong)*(uint *)((longlong)plVar19 + 0x14) + lVar10;
                  if ((int)uVar17 == 1) {
                    uVar26 = *(uint *)(plVar19 + 3);
                    uVar6 = *(ushort *)(lVar13 + uVar17 * 2);
                    uVar23 = uVar26;
LAB_:
                    if ((uVar6 & 0x7fff) < uVar26) goto LAB_;
                  }
                  else {
                    uVar26 = *(ushort *)(lVar13 + -2 + uVar17 * 2) & 0x7fff;
                    uVar23 = *(uint *)(plVar19 + 3);
                    uVar6 = *(ushort *)(lVar13 + uVar17 * 2);
                    if (uVar23 <= uVar26) goto LAB_;
LAB_:
                    *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x1006ab;
                    func_0x(lVar10,7);
                    uVar23 = *(uint *)(plVar19 + 3);
                  }
                  if ((uVar26 < uVar23) || (*(uint *)((longlong)plVar19 + 4) < uVar26))
                  goto LAB_;
                  lVar10 = plVar19[1];
                  if (*(ushort *)(lVar10 + (ulonglong)uVar26) == 5) {
                    *puVar1 = *puVar1 | 2;
                    *(short *)((longlong)plVar19 + 0x1c) = *(short *)((longlong)plVar19 + 0x1c) + -1
                    ;
                    *(short *)((longlong)plVar19 + 0x2a) = (short)uVar26;
                    lVar10 = (ulonglong)(uVar26 & 0xffff) + plVar19[1];
                    uVar6 = *(ushort *)(lVar10 + 2);
                    uVar7 = *(ushort *)((longlong)plVar19 + 0x2c) & 0xc7ff;
                    if ((uVar6 & 0x4000) != 0) {
                      uVar7 = uVar6 & 0x3800 | uVar7;
                    }
                    *(ushort *)((longlong)plVar19 + 0x2c) = uVar7;
                    *(ushort *)((longlong)plVar19 + 0x2c) =
                         (uVar7 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar7;
                    uVar17 = (ulonglong)*(uint *)((longlong)plVar19 + 4);
                    pbVar25 = (byte *)plVar19[1];
                    goto LAB_;
                  }
                  if (*(ushort *)(lVar10 + (ulonglong)uVar26) < 0x400) break;
                  *puVar1 = *puVar1 | 1;
                  uVar6 = *(short *)((longlong)plVar19 + 0x1c) - 1;
                  *(ushort *)((longlong)plVar19 + 0x1c) = uVar6;
                  if ((uVar6 == 0) ||
                     (uVar17 = (ulonglong)uVar6, -1 < (short)puVar22[(ulonglong)(uVar6 - 1) + 1]))
                  break;
                } while( true );
              }
              uVar17 = (ulonglong)*(uint *)((longlong)plVar19 + 4);
              pbVar25 = (byte *)plVar19[1];
            }
LAB_:
            iVar8 = 0;
            if ((*pbVar25 & 0x40) == 0) {
              *(undefined4 *)((longlong)plVar19 + 0x26) = 0;
            }
            else {
              *(int *)((longlong)plVar19 + 0x26) = (int)uVar17;
              *(int *)((longlong)plVar19 + 4) = (int)uVar17 + 0xe;
              *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x1007a6;
              puVar14 = (ulonglong *)func_0x(puVar1);
              uVar17 = *puVar14;
              uVar6 = (ushort)(uVar17 >> 0x30);
              if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
                if ((uVar17 & 0x4000000000000000) == 0) {
                  uVar6 = uVar6 & 0xdfff;
                }
                else {
                  uVar6 = uVar6 | 0x2000;
                }
              }
              if (uVar6 == 0xfffc) {
                iVar8 = (int)((uVar17 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)((longlong)plVar19 + 4) = *(int *)((longlong)plVar19 + 4) + iVar8;
              uVar17 = (ulonglong)*(uint *)((longlong)plVar19 + 4);
            }
            iVar8 = (int)uVar17;
            if ((*(ulonglong *)((longlong)plVar19 + 0x1e) != 0) &&
               (*(ulonglong *)((longlong)plVar19 + 0x1e) < uVar17 + plVar19[1])) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar10 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0 &&
                   (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
                  (*(char *)(lVar10 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10088e;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)((longlong)auStack_150 + lVar12 + -8) = 0;
                  *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x1008b4;
                  (*_DAT_)(1,0x18049b8,0x1924688,0x877);
                }
              }
              lVar10 = plVar19[1];
              *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x1008c2;
              func_0x(lVar10,0x12);
              iVar8 = *(int *)((longlong)plVar19 + 4);
            }
            if (0x3f3b < iVar8 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar10 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0 &&
                  ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                   (*(char *)(lVar10 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10094d;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  lVar10 = plVar19[1];
                  *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10095b;
                  func_0x(lVar10,5);
                  goto LAB_;
                }
                *(undefined8 *)((longlong)auStack_150 + lVar12 + -8) = 0;
                *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100981;
                (*_DAT_)(1,0x18049b8,0x1924688,0x87c);
              }
              lVar10 = plVar19[1];
              *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x10098f;
              func_0x(lVar10,5);
            }
          }
LAB_:
          sVar18 = -*(short *)puVar11;
          if ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0) {
            bVar5 = *(byte *)plVar19[1];
            if ((bVar5 & 0x10) == 0) {
              if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                piVar24 = *(int **)(puVar11 + 2) + 1;
                iStack_118 = **(int **)(puVar11 + 2);
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(plVar19 + 2) <= (int)*puVar11) ||
                    (*(ushort *)((byte *)plVar19[1] + *(uint *)(plVar19 + 2)) <
                     *(ushort *)(puVar11 + 1))) goto LAB_;
          }
          lVar10 = (longlong)sVar18;
          if ((uint)*(ushort *)((longlong)plVar19 + 0x1c) < (uint)(int)sVar18) {
            iStack_118 = 0;
            piVar24 = (int *)plVar19[1];
          }
          else {
            lVar13 = plVar19[1];
            lVar15 = (ulonglong)*(uint *)((longlong)plVar19 + 0x14) + lVar13;
            if (sVar18 == 1) {
              uVar26 = *(uint *)(plVar19 + 3);
              uVar23 = *(ushort *)(lVar15 + lVar10 * 2) & 0x7fff;
LAB_:
              if (uVar23 < uVar26) goto LAB_;
            }
            else {
              uVar26 = *(ushort *)(lVar15 + -2 + lVar10 * 2) & 0x7fff;
              uVar23 = *(ushort *)(lVar15 + lVar10 * 2) & 0x7fff;
              lVar13 = plVar19[1];
              if (*(uint *)(plVar19 + 3) <= uVar26) goto LAB_;
LAB_:
              *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100a47;
              func_0x(lVar13,7);
            }
            piVar24 = (int *)((ulonglong)uVar26 + plVar19[1]);
            iStack_118 = uVar23 - uVar26;
          }
        }
        else {
          uVar6 = *(ushort *)((longlong)puVar11 + 6);
          if ((uVar6 & 8) == 0) {
            if ((uVar6 & 0x10) != 0) {
              bVar5 = *(byte *)plVar19[1];
              if ((bVar5 & 0x10) == 0) {
                if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                  piVar24 = *(int **)(puVar11 + 2) + 1;
                  iStack_118 = **(int **)(puVar11 + 2);
                  if (iStack_118 != 0x1f9e) {
                    *(undefined8 *)((longlong)auStack_150 + lVar12 + -8) = 0;
                    *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100355;
                    (*_DAT_)(1,0x19b2728,0x19b1128,0x381);
                  }
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(plVar19 + 2) <= (int)uVar26) ||
                      (*(ushort *)((byte *)plVar19[1] + *(uint *)(plVar19 + 2)) <
                       *(ushort *)(puVar11 + 1))) goto LAB_;
            }
            iStack_118 = 0x1f9e;
            piVar24 = (int *)((longlong)(int)*puVar11 + plVar19[1]);
          }
          else {
            iStack_118 = 1;
            piVar24 = (int *)0x15893f4;
            if ((*(byte *)((longlong)(int)uVar26 + plVar19[1]) & (byte)(1 << ((byte)uVar6 & 7))) ==
                0) {
              piVar24 = (int *)0x1589a18;
            }
          }
        }
      }
    }
    else {
      uStack_114 = 0;
      *(longlong *)((longlong)auStack_150 + lVar12 + -8) = (longlong)&iStack_118 + 4;
      *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100aab;
      piVar24 = (int *)func_0x(puVar1,puVar11);
      if ((((*(short *)plVar19 != 0) &&
           (plVar19 = (longlong *)plVar19[2], plVar19 != (longlong *)0x0)) && (*plVar19 != 0)) &&
         (((*(byte *)((longlong)puVar11 + 6) & 8) == 0 && ((uStack_114 & 1) == 0)))) {
        if ((piVar24 == (int *)0x0) || (piVar24 == (int *)0x15893f4)) {
          iStack_118 = 0;
          piVar24 = (int *)0x0;
        }
        else {
          *(uint *)((longlong)auStack_140 + lVar12) = uStack_114;
          *(int **)((longlong)&uStack_148 + lVar12) = &iStack_118;
          *(undefined4 *)((longlong)auStack_150 + lVar12) = 0x1f9e;
          *(longlong *)((longlong)auStack_150 + lVar12 + -8) = (longlong)&iStack_118 + lVar12;
          iVar8 = iStack_118;
          *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100b08;
          piVar24 = (int *)func_0x(plVar19,puVar11,piVar24,iVar8);
        }
      }
    }
LAB_:
    plVar19 = plStack_e8;
    if (piVar24 == (int *)0x0) {
      uVar26 = param_6 | 8;
    }
    else {
      *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100b2b;
      iVar8 = func_0x(plVar19,puVar11);
      uVar26 = uStack_110;
      if (iVar8 == 0) {
        uVar26 = param_6 | 0x200;
      }
    }
    *(undefined8 *)(auStack_178 + lVar12 + -8) = 0x100b59;
    lVar10 = func_0x();
    lVar10 = -lVar10;
    puVar20 = auStack_178 + lVar10 + lVar12;
    plVar19 = (longlong *)((longlong)&iStack_118 + lVar10 + lVar12);
    *(undefined8 *)(auStack_178 + lVar10 + lVar12 + -8) = 0x100b6f;
    func_0x(plVar19);
    if (((*(byte *)(lStack_d8 + 4) & 1) == 0) &&
       ((*(uint *)(*(longlong *)(plStack_d0[6] + 0x6b0) + 0x278) & 0x1000) == 0)) {
      uVar26 = uVar26 | 0x10000;
    }
    pcVar2 = *(code **)(*plStack_e0 + 8);
    *(undefined8 *)(auStack_178 + lVar10 + lVar12 + -8) = 0x100ba2;
    (*pcVar2)(plStack_e0);
    param_5 = uStack_c0;
    param_1 = plStack_c8;
    param_7 = plStack_b0;
    lVar12 = lStack_b8;
    plVar9 = plStack_e0;
  }
  uStack_104 = 0;
  uStack_100 = 0;
  uStack_f8 = 0;
  uStack_f4 = 0;
  *(undefined4 **)(puVar20 + 0x50) = &uStack_f8;
  *(int *)(puVar20 + 0x48) = iStack_10c;
  *(longlong **)(puVar20 + 0x40) = param_7;
  *(uint *)(puVar20 + 0x38) = uVar26 | 0x80;
  *(ulonglong *)(puVar20 + 0x30) = param_5;
  *(int *)(puVar20 + 0x28) = iStack_118;
  *(longlong **)(puVar20 + 0x20) = plVar19;
  uVar4 = uStack_a8;
  lVar10 = param_1[0x3d];
  *(undefined8 *)(puVar20 + -8) = 0x100c41;
  iVar8 = func_0x(param_1,uVar4,lVar10,1);
  if (iVar8 != 0) {
    uStack_108 = 0;
    lStack_a0 = *(longlong *)(lVar12 + 8);
    lVar12 = lStack_a0;
    if (*(longlong *)(lStack_a0 + 0x478) != 0) {
      lVar12 = *(longlong *)(lStack_a0 + 0x478);
    }
    if ((*(byte *)(lVar12 + 0x474) & 1) != 0) {
      lVar12 = *param_7;
      *(int *)((longlong)plVar9 + 0xc) = *(int *)((longlong)plVar9 + 0xc) + 1;
      *(longlong **)(lVar12 + 0x150) = plVar9;
      *(undefined4 *)(lVar12 + 0x158) = 1;
    }
  }
  lVar10 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar12 = *(longlong *)(lVar10 + 0x100);
  if (lVar12 == 0) {
    *(undefined8 *)(puVar20 + -8) = 0x100cc1;
    (*_DAT_)();
    lVar12 = *(longlong *)(lVar10 + 0x100);
  }
  puVar21 = puVar20;
  if (*(int *)(lVar12 + 0x22c) != 0) {
    *(undefined8 *)(puVar20 + -8) = 0x100cd7;
    (*_DAT_)();
  }
LAB_:
  uVar17 = uStack_48 ^ (ulonglong)&iStack_118;
  *(undefined8 *)(puVar21 + -8) = 0x100cf0;
  func_0x(uVar17);
  return;
}

