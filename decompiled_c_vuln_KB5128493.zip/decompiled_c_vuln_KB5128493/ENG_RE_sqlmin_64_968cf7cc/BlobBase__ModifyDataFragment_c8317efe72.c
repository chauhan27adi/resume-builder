
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong **param_2,int *param_3,uint param_4,uint param_5,
                 int param_6,undefined8 param_7,uint param_8,int param_9,longlong param_10)

{
  byte *pbVar1;
  undefined uVar2;
  undefined8 uVar3;
  longlong lVar4;
  code *pcVar5;
  int *piVar6;
  byte bVar7;
  char cVar8;
  short sVar9;
  undefined2 uVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  short *psVar14;
  ulonglong *puVar15;
  longlong lVar16;
  byte bVar17;
  ushort uVar18;
  undefined4 uVar19;
  undefined4 *puVar20;
  ulonglong uVar21;
  ushort uVar22;
  longlong *plVar23;
  uint uVar24;
  uint uVar25;
  undefined *puVar26;
  uint uVar27;
  byte **ppbVar28;
  uint uVar29;
  byte bVar30;
  longlong lVar31;
  byte *pbVar32;
  ushort *puVar33;
  longlong **pplVar34;
  longlong unaff_GS_OFFSET;
  bool bVar35;
  undefined8 uStack_420;
  undefined auStack_418 [32];
  undefined4 *puStack_3f8;
  int iStack_3f0;
  uint uStack_3e8;
  uint uStack_3e0;
  int iStack_3d8;
  undefined8 uStack_3d0;
  undefined4 *puStack_3c8;
  byte abStack_3b8 [4];
  uint uStack_3b4;
  uint uStack_3b0;
  uint uStack_3ac;
  longlong lStack_3a8;
  undefined4 uStack_3a0;
  undefined2 uStack_39c;
  undefined2 uStack_39a;
  int *piStack_398;
  undefined4 uStack_390;
  undefined2 uStack_38c;
  undefined2 uStack_38a;
  undefined4 uStack_388;
  undefined2 uStack_384;
  undefined2 uStack_382;
  undefined4 uStack_380;
  undefined2 uStack_37c;
  undefined2 uStack_37a;
  undefined4 uStack_378;
  undefined2 uStack_374;
  undefined2 uStack_372;
  uint uStack_370;
  undefined4 uStack_368;
  undefined4 uStack_364;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  byte bStack_358;
  undefined7 uStack_357;
  undefined8 uStack_350;
  undefined2 uStack_348;
  undefined4 uStack_340;
  undefined2 uStack_33c;
  undefined2 uStack_33a;
  undefined4 uStack_338;
  undefined2 uStack_334;
  undefined4 uStack_330;
  undefined2 uStack_32c;
  undefined4 uStack_328;
  undefined2 uStack_324;
  undefined2 uStack_322;
  undefined4 uStack_320;
  undefined2 uStack_31c;
  undefined2 uStack_31a;
  undefined4 uStack_318;
  undefined2 uStack_314;
  undefined2 uStack_312;
  undefined4 uStack_310;
  undefined2 uStack_30c;
  undefined2 uStack_30a;
  undefined4 uStack_308;
  undefined2 uStack_304;
  undefined2 uStack_302;
  longlong **pplStack_300;
  undefined4 uStack_2f8;
  undefined2 uStack_2f4;
  undefined2 uStack_2f2;
  undefined4 uStack_2f0;
  undefined2 uStack_2ec;
  undefined2 uStack_2ea;
  undefined4 uStack_2e8;
  undefined2 uStack_2e4;
  undefined2 uStack_2e2;
  undefined4 uStack_2e0;
  undefined2 uStack_2dc;
  undefined2 uStack_2da;
  undefined4 uStack_2d8;
  undefined2 uStack_2d4;
  undefined2 uStack_2d2;
  undefined4 uStack_2c8;
  undefined2 uStack_2c4;
  undefined8 uStack_2c0;
  undefined4 uStack_2b8;
  undefined8 uStack_2b0;
  undefined8 uStack_2a8;
  undefined8 uStack_2a0;
  undefined4 *puStack_298;
  undefined4 *puStack_290;
  undefined4 *puStack_288;
  undefined2 uStack_280;
  char cStack_27e;
  longlong lStack_278;
  longlong lStack_270;
  undefined8 uStack_268;
  undefined4 uStack_260;
  undefined auStack_258 [8];
  longlong lStack_250;
  undefined auStack_248 [8];
  undefined auStack_240 [4];
  undefined8 uStack_23c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined8 uStack_218;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined8 uStack_1f8;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined8 uStack_1d8;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined8 uStack_1b8;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  ulonglong uStack_198;
  undefined4 uStack_188;
  uint uStack_184;
  byte *pbStack_180;
  undefined8 uStack_178;
  undefined4 uStack_170;
  ushort uStack_16c;
  undefined2 uStack_16a;
  undefined6 uStack_168;
  undefined2 uStack_162;
  undefined2 uStack_160;
  undefined2 uStack_15e;
  ushort uStack_15c;
  undefined2 uStack_15a;
  uint uStack_158;
  int iStack_154;
  undefined auStack_150 [16];
  undefined auStack_140 [8];
  undefined8 uStack_138;
  undefined8 uStack_130;
  undefined6 uStack_128;
  undefined2 uStack_122;
  undefined6 uStack_120;
  undefined2 uStack_11a;
  undefined8 uStack_118;
  undefined auStack_110 [16];
  undefined auStack_100 [16];
  undefined auStack_f0 [16];
  undefined8 uStack_e0;
  undefined4 auStack_d8 [32];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)abStack_3b8;
  uStack_3b4 = param_5;
  uStack_268 = param_7;
  puStack_298 = auStack_d8;
  lStack_3a8 = param_10;
  uStack_2c8 = 0;
  uStack_2c4 = 0;
  uStack_2c0 = 0;
  uStack_2b8 = 0;
  uStack_2b0 = 0;
  uStack_2a8 = 0x78;
  uStack_280 = 0;
  cStack_27e = '\0';
  auStack_d8[0] = 0x4000000;
  if ((((*(uint *)((longlong)param_1 + 0x34) & 0x8200) == 0) ||
      ((*(uint *)((longlong)param_1 + 0x34) >> 0xd & 1) != 0)) || (param_9 != 1)) {
    bVar30 = 0;
  }
  else {
    bVar30 = 1;
  }
  uStack_23c = 0;
  if (param_10 == 0) {
    lStack_3a8 = *param_1;
  }
  lVar16 = param_1[0x14];
  uStack_420 = 0x10010f;
  abStack_3b8[0] = bVar30;
  uStack_3ac = param_4;
  piStack_398 = param_3;
  pplStack_300 = param_2;
  lStack_270 = lVar16;
  bVar7 = func_0x(param_1);
  uStack_368 = *(undefined4 *)(param_1 + 10);
  uStack_364 = *(undefined4 *)((longlong)param_1 + 0x54);
  uStack_360 = *(undefined4 *)(param_1 + 0xb);
  uStack_35c = *(undefined4 *)((longlong)param_1 + 0x5c);
  bVar17 = 0;
  if (*(int *)(param_1[1] + 0x38) == 3) {
    bVar17 = 4;
  }
  bStack_358 = bVar17 | (bVar7 & 1) * '\x02' | bStack_358 & 0xe0 | bVar30;
  if ((bVar30 != 0) && ((*(uint *)((longlong)param_1 + 0x34) & 0x1000) == 0)) {
    puStack_3f8 = (undefined4 *)0x0;
    uStack_420 = 0x100177;
    (*_DAT_)(1,0x16e6590,0x16b61d8,0x3d3);
  }
  puStack_290 = puStack_298;
  *puStack_298 = 0x4000000;
  puStack_288 = puStack_298 + 1;
  uStack_2a0 = 0;
  if ((*(byte *)(param_1 + 0xc) & 2) == 0) {
    if ((*(byte *)((longlong)param_1 + 0x8c) & 1) != 0) {
      plVar23 = param_1 + 0x12;
      goto LAB_;
    }
  }
  else {
    plVar23 = (longlong *)((longlong)param_1 + 0x3c);
LAB_:
    uStack_420 = 0x1001cf;
    func_0x(param_1,plVar23,&uStack_2c8);
  }
  uStack_420 = 0x1001e1;
  func_0x(param_1,**param_2,*param_3);
  uStack_218 = CONCAT71(uStack_357,bStack_358);
  uStack_228 = uStack_368;
  uStack_224 = uStack_364;
  uStack_220 = uStack_360;
  uStack_21c = uStack_35c;
  if ((*(longlong *)(lVar16 + 8) == 0) ||
     (lVar31 = *(longlong *)(*(longlong *)(lVar16 + 8) + 8), *(char *)(lVar31 + 0x3f) != '\0')) {
    if (*(int *)(lVar16 + 0x40) == 2) {
      uStack_322 = 0;
      uStack_328 = **(undefined4 **)(lVar16 + 0x30);
      puVar20 = &uStack_328;
      uStack_324 = *(undefined2 *)(*(undefined4 **)(lVar16 + 0x30) + 1);
    }
    else {
      uStack_31a = 0;
      uStack_320 = **(undefined4 **)(lVar16 + 0x28);
      puVar20 = &uStack_320;
      uStack_31c = *(undefined2 *)(*(undefined4 **)(lVar16 + 0x28) + 1);
    }
    uStack_388 = *puVar20;
    uStack_384 = *(undefined2 *)(puVar20 + 1);
  }
  else {
    uStack_388 = *(undefined4 *)(lVar31 + 8);
    uStack_384 = *(undefined2 *)(lVar31 + 0xc);
  }
  puStack_3c8 = &uStack_228;
  uStack_3d0 = uStack_268;
  iStack_3d8 = param_6;
  uStack_3e0 = uStack_3b4;
  iStack_3f0 = *param_3;
  puStack_3f8 = &uStack_2c8;
  uStack_382 = 0;
  uStack_420 = 0x1002d4;
  uStack_3e8 = param_4;
  iVar11 = func_0x
                     (param_2,*(undefined8 *)(param_1[1] + 0x58),&uStack_388,lStack_3a8);
  if (iVar11 == 0) {
    *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & 0xfffffffd;
    *(uint *)((longlong)param_1 + 0x8c) = *(uint *)((longlong)param_1 + 0x8c) & 0xfffffffe;
    puVar26 = auStack_418;
    if (cStack_27e != '\0') {
      *(undefined *)(param_1[1] + 0x188) = 0;
      puVar26 = auStack_418;
    }
    goto LAB_;
  }
  uStack_370 = param_4 + 0xe;
  pbStack_180 = (byte *)0x0;
  uStack_188 = CONCAT22(uStack_188._2_2_,0xffff);
  uStack_184 = 0;
  uStack_16a = 0;
  uStack_168 = 0;
  uStack_160 = 0;
  uStack_15e = 0;
  uStack_15c = 0;
  uStack_15a = 0;
  uStack_178 = (byte **)0x0;
  sVar9 = -1;
  if (uStack_370 < param_4) {
    uStack_370 = 0xffffffff;
    uStack_420 = 0x10035d;
    func_0x(0x80070216,param_4,0xe);
    sVar9 = (short)uStack_188;
  }
  ppbVar28 = (byte **)0x0;
  iStack_154 = *param_3;
  lVar31 = (longlong)iStack_154;
  uVar24 = 0xf;
  lVar16 = **param_2;
  lStack_278 = lVar16;
  if (*(char *)(lVar16 + 2) < '\0') {
    pbVar32 = (byte *)(lVar16 + 0x60);
    if ((sVar9 == 0) || (ppbVar28 = uStack_178, uStack_178 == (byte **)0x0)) {
      ppbVar28 = (byte **)auStack_150;
      uStack_128 = 0;
      stack0xfffffffffffffec2 = SUB1614(ZEXT816(0),2);
      auStack_140._0_2_ = 0xffff;
      uStack_11a = 0;
      uStack_138 = 0;
      uStack_122 = 0;
      uStack_120 = 0;
      uStack_118 = 0;
      uStack_130 = 0;
      auStack_110 = ZEXT816(0);
      auStack_f0._0_12_ = ZEXT812(0);
      auStack_f0._12_4_ = 0;
      uStack_e0 = 0;
      auStack_100 = ZEXT816(0);
      auStack_150 = ZEXT816(0);
    }
    if (*(short *)(lVar16 + 0x24) == 0) {
LAB_:
      uStack_350 = *(undefined8 *)(lVar16 + 0x28);
      uStack_348 = *(undefined2 *)(lVar16 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar16 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar16 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar16 + 0x18) != 99) goto LAB_;
      }
      uStack_338 = *(undefined4 *)(lVar16 + 0x20);
      uStack_334 = *(undefined2 *)(lVar16 + 0x24);
      uStack_420 = 0x1004a5;
      cVar8 = func_0x(&uStack_338);
      if (cVar8 == '\0') goto LAB_;
      uStack_420 = 0x1004b5;
      func_0x(lVar16,&uStack_350);
    }
    *ppbVar28 = pbVar32;
    *(undefined4 *)(ppbVar28 + 0xc) = (undefined4)uStack_350;
    *(undefined2 *)(ppbVar28 + 0xd) = uStack_348;
    *(int *)((longlong)ppbVar28 + 100) = (int)((ulonglong)uStack_350 >> 0x20);
    *(undefined4 *)((longlong)ppbVar28 + 0x6c) = *(undefined4 *)(lVar16 + 0x20);
    *(undefined2 *)(ppbVar28 + 0xe) = *(undefined2 *)(lVar16 + 0x24);
    *(undefined2 *)((longlong)ppbVar28 + 0x72) = 0;
    uStack_260 = *(undefined4 *)((ulonglong)*pbVar32 * 6 + 0x132e020);
    uVar21 = (ulonglong)*(short *)((ulonglong)*pbVar32 * 6 + 0x132e024);
    *(undefined2 *)(ppbVar28 + 2) = 0xffff;
    ppbVar28[3] = (byte *)0x0;
    uVar29 = 0;
    *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
    ppbVar28[7] = (byte *)0x0;
    ppbVar28[4] = (byte *)0x0;
    ppbVar28[9] = (byte *)0x0;
    ppbVar28[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar28 + 0xb) = 0;
    if ((**ppbVar28 & 2) != 0) {
      pbVar1 = pbVar32 + uVar21;
      if ((pbVar32[uVar21] & 1) == 0) {
        *(undefined2 *)(ppbVar28 + 2) = 0;
        ppbVar28[3] = pbVar1;
        *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar28 + 0x36) = 0;
        switch(*pbVar1 & 0xe) {
        default:
          uVar29 = (uint)*(ushort *)(pbVar1 + 2);
          if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
            uStack_420 = 0x100747;
            func_0x(pbVar1,6);
          }
          break;
        case 4:
          uVar29 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar29 = 1;
        }
        *(uint *)(ppbVar28 + 4) = uVar29;
        *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar28 + 2) = 1;
        ppbVar28[3] = pbVar1;
        bVar30 = *pbVar1;
        switch(bVar30 & 0x1c) {
        default:
          if ((char)pbVar1[1] < '\0') {
            uVar18 = *(ushort *)(pbVar1 + 1);
            sVar9 = 3;
            *(ushort *)((longlong)ppbVar28 + 0x12) = uVar18;
            uVar18 = (uVar18 & 0x7f) << 8 | uVar18 >> 8;
          }
          else {
            sVar9 = 2;
            uVar18 = (ushort)pbVar1[1];
          }
          *(ushort *)((longlong)ppbVar28 + 0x12) = uVar18;
          *(short *)(ppbVar28 + 5) = sVar9;
          uVar18 = *(ushort *)((longlong)ppbVar28 + 0x12);
          *(short *)((longlong)ppbVar28 + 0x2c) = (short)(uVar18 + 1 >> 1) + sVar9;
          if (uVar18 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar28 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
            *(undefined4 *)(ppbVar28 + 8) = 0;
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
          }
          else {
            iVar11 = uVar18 - 1;
            *(short *)((longlong)ppbVar28 + 0x2a) =
                 ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                 (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
            *(undefined4 *)(ppbVar28 + 8) = 0;
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar30 & 0x1c) != 4) || (uVar27 = 1, (bVar30 & 2) == 0)) {
            uVar27 = uVar29;
          }
          if (uVar27 == 0) {
            uVar19 = 1;
          }
          else {
            *(undefined4 *)(ppbVar28 + 8) = 0;
            uVar19 = 0xf;
          }
          ppbVar28[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar28 + 0x12) = 0;
          ppbVar28[6] = (byte *)0x0;
          ppbVar28[4] = (byte *)0x0;
          ppbVar28[7] = (byte *)0x0;
          ppbVar28[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar28 + 0x14) = uVar19;
          *(uint *)(ppbVar28 + 8) = (uint)(uVar27 != 0);
          ppbVar28[7] = (byte *)0x0;
          ppbVar28[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar28[7] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar28 + 0x14) = 9;
          ppbVar28[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar28 + 0x12) = 0;
          ppbVar28[6] = (byte *)0x0;
          ppbVar28[4] = (byte *)0x0;
          ppbVar28[3] = pbVar1;
          *(undefined4 *)(ppbVar28 + 8) = 0;
          ppbVar28[7] = (byte *)0x0;
          ppbVar28[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar28 & 4) != 0) {
      if (uStack_260._2_2_ != 0) {
        uVar21 = (ulonglong)*(ushort *)(lVar16 + 0x61 + (longlong)uStack_260._2_2_ * 2);
      }
      psVar14 = (short *)(pbVar32 + uVar21);
      ppbVar28[9] = (byte *)psVar14;
      sVar9 = *psVar14;
      ppbVar28[10] = (byte *)(psVar14 + 1);
      *(short *)(ppbVar28 + 0xb) = (sVar9 + 1) * 2;
    }
    if (ppbVar28[1] != (byte *)0x0) {
      uStack_420 = 0x1007e3;
      func_0x(ppbVar28[1],ppbVar28);
    }
  }
  lVar16 = lStack_278;
  pbStack_180 = (byte *)((ulonglong)*(ushort *)(lStack_278 + (0xfff - lVar31) * 2) + lStack_278);
  if ((*pbStack_180 & 1) == 0) {
    uStack_188 = uStack_188 & 0xffff0000;
    uStack_184 = 0;
    uStack_162 = 0;
    uStack_160 = 0;
    uVar24 = (uint)*(ushort *)(lStack_278 + 0xe);
    switch(*pbStack_180 & 0xe) {
    default:
      uVar18 = *(ushort *)(pbStack_180 + 2);
      uVar24 = (uint)uVar18;
      if (0x1f9d < uVar18 - 1) {
        uStack_420 = 0x100a39;
        func_0x(pbStack_180,6);
      }
      break;
    case 4:
      uVar24 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar24 = 1;
    }
    uStack_178 = (byte **)CONCAT44(uStack_178._4_4_,uVar24);
    uStack_16a = (undefined2)(lVar16 + 0x2000);
    uStack_168 = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
    ppbVar28 = (byte **)(ulonglong)uVar24;
    uVar24 = uStack_184;
  }
  else {
    bVar30 = *pbStack_180;
    switch(bVar30 & 0x1c) {
    default:
      bVar30 = pbStack_180[1];
      if ((char)bVar30 < '\0') {
        uVar18 = (*(ushort *)(pbStack_180 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_180 + 1) >> 8;
        uStack_170._0_2_ = 3;
        sVar9 = 3;
        uStack_188 = CONCAT22(uVar18,1);
      }
      else {
        uVar18 = (ushort)bVar30;
        uStack_188 = (uint)CONCAT12(bVar30,1);
        uStack_170._0_2_ = 2;
        sVar9 = 2;
      }
      uStack_16c = ((ushort)(uVar18 + 1) >> 1) + sVar9;
      uVar24 = 0;
      if (uVar18 < 0x1f) {
        uStack_170._2_2_ = 0;
        uStack_184 = 0;
        uStack_158 = 0;
      }
      else {
        iVar11 = uVar18 - 1;
        uStack_158 = 0;
        uStack_184 = 0;
        uStack_170._2_2_ =
             ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
             (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar30 & 0x1c) == 4) && ((bVar30 & 2) != 0)) {
        uStack_170._0_2_ = 0;
        uStack_170._2_2_ = 0;
        uStack_16c = 0;
        uStack_16a = 0;
        uStack_188 = 1;
        uStack_168 = 0;
        uStack_162 = 0;
        uStack_184 = 0xf;
        uStack_158 = 1;
      }
      else {
        uVar24 = 1;
        uStack_170._0_2_ = 0;
        uStack_170._2_2_ = 0;
        uStack_16c = 0;
        uStack_16a = 0;
        uStack_184 = 1;
        uStack_188 = 1;
        uStack_168 = 0;
        uStack_162 = 0;
        uStack_158 = 0;
      }
      break;
    case 8:
      uStack_170._0_2_ = 0;
      uStack_170._2_2_ = 0;
      uStack_16c = 0;
      uStack_16a = 0;
      uStack_184 = 9;
      uStack_188 = 1;
      uStack_168 = 0;
      uStack_162 = 0;
      uStack_158 = 0;
      uVar24 = 9;
    }
    lVar31 = lStack_278 + 0x2000;
    uStack_160 = (undefined2)lVar31;
    uStack_15e = (undefined2)((ulonglong)lVar31 >> 0x10);
    uStack_15c = (ushort)((ulonglong)lVar31 >> 0x20);
    uStack_15a = (undefined2)((ulonglong)lVar31 >> 0x30);
    uStack_178 = ppbVar28;
  }
  if ((short)uStack_188 == 0) {
    uVar29 = CONCAT22(uStack_170._2_2_,(undefined2)uStack_170);
    if (uVar24 == 0) {
      uVar24 = (uint)ppbVar28;
      uVar21 = (ulonglong)ppbVar28 & 0xffffffff;
      uStack_188 = uStack_188 & 0xffff;
      if ((*pbStack_180 & 0x10) != 0) {
        uVar24 = uVar24 + 2 +
                 (*(ushort *)(pbStack_180 + ((ulonglong)ppbVar28 & 0xffffffff)) + 7 >> 3);
        uVar21 = (ulonglong)uVar24;
      }
      uStack_178 = (byte **)CONCAT44(uVar24,(undefined4)uStack_178);
      uVar29 = (uint)uVar21;
      if ((*pbStack_180 & 0x20) == 0) {
        uStack_16c = 0;
        uStack_184 = uVar29;
      }
      else {
        puVar33 = (ushort *)(pbStack_180 + uVar21);
        uStack_16c = *puVar33;
        if (uStack_16c == 0) {
          if ((((cRam0000000001c40b0b != '\0') || ((bRam0000000001c51410 & 1) != 0)) &&
              (lVar31 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000011af398 * 8) + 8 +
                         (ulonglong)*puRam00000000011af3a0), lVar31 != 0)) &&
             ((lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0 &&
              (*(char *)(lVar31 + 0x499) != '\0')))) {
            if ((cRam0000000001c409fb == '\0') && ((bRam0000000001c51410 & 2) == 0)) {
              uStack_420 = 0x100b5f;
              (*pcRam00000000011af338)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_3f8 = (undefined4 *)0x0;
              uStack_420 = 0x100bd6;
              (*_DAT_)(1,0x1531538,0x1651208,0x80f);
            }
          }
          uStack_420 = 0x100be7;
          func_0x(pbStack_180,3);
        }
        uStack_170 = uStack_178._4_4_ + 2 + (uint)uStack_16c * 2;
        if (0x1f9e < uStack_170) {
          if (((cRam0000000001c40b0b != '\0') || ((bRam0000000001c51410 & 1) != 0)) &&
             ((lVar31 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000011af398 * 8) + 8 +
                         (ulonglong)*puRam00000000011af3a0), lVar31 != 0 &&
              ((lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0 &&
               (*(char *)(lVar31 + 0x499) != '\0')))))) {
            if ((cRam0000000001c409fb == '\0') && ((bRam0000000001c51410 & 2) == 0)) {
              uStack_420 = 0x100c91;
              (*pcRam00000000011af338)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_3f8 = (undefined4 *)0x0;
              uStack_420 = 0x100cb5;
              (*_DAT_)(1,0x1531538,0x1651208,0x816);
            }
          }
          uStack_420 = 0x100cc8;
          func_0x(pbStack_180,4);
        }
        uStack_184 = puVar33[uStack_16c] & 0x7fff;
        if (uStack_184 < uStack_170) {
          if ((((cRam0000000001c40b0b != '\0') || ((bRam0000000001c51410 & 1) != 0)) &&
              (lVar31 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000011af398 * 8) + 8 +
                         (ulonglong)*puRam00000000011af3a0), lVar31 != 0)) &&
             ((lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0 &&
              (*(char *)(lVar31 + 0x499) != '\0')))) {
            if ((cRam0000000001c409fb == '\0') && ((bRam0000000001c51410 & 2) == 0)) {
              uStack_420 = 0x100d75;
              (*pcRam00000000011af338)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_3f8 = (undefined4 *)0x0;
              uStack_420 = 0x100d9b;
              (*_DAT_)(1,0x1531538,0x1651208,0x81d);
            }
          }
          uStack_420 = 0x100da9;
          func_0x(pbStack_180,4);
        }
        uVar21 = (ulonglong)uStack_184;
        uVar29 = uStack_170;
        do {
          if (-1 < (short)puVar33[(ulonglong)(uStack_16c - 1) + 1]) break;
          uVar27 = uStack_170;
          if (((uStack_16c != 1) &&
              (uVar27 = *(ushort *)
                         (pbStack_180 +
                         (ulonglong)uStack_16c * 2 + (((ulonglong)uStack_178 >> 0x20) - 2)) & 0x7fff
              , uVar27 < uStack_170)) ||
             ((*(ushort *)
                (pbStack_180 + (ulonglong)uStack_16c * 2 + ((ulonglong)uStack_178 >> 0x20)) & 0x7fff
              ) < uVar27)) {
            uStack_420 = 0x100e2d;
            uStack_170 = uVar29;
            func_0x(pbStack_180,7);
            uVar21 = (ulonglong)uStack_184;
            uVar29 = uStack_170;
          }
          uVar24 = (uint)uVar21;
          if ((uVar27 < uStack_170) || (uVar24 < uVar27)) goto code_r0x0010116a;
          if (*(ushort *)(pbStack_180 + uVar27) == 5) {
            uStack_188 = uStack_188 | 0x20000;
            uStack_16c = uStack_16c - 1;
            uStack_15e = (undefined2)uVar27;
            if ((*(ushort *)(pbStack_180 + (ulonglong)(uVar27 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_15c = uStack_15c & 0xc7ff;
            }
            else {
              uStack_15c = uStack_15c ^
                           (uStack_15c ^ *(ushort *)(pbStack_180 + (ulonglong)(uVar27 & 0xffff) + 2)
                           ) & 0x3800;
            }
            uStack_15c = (uStack_15c ^ *(ushort *)(pbStack_180 + (ulonglong)(uVar27 & 0xffff) + 2))
                         & 0x7ff ^ uStack_15c;
            break;
          }
          if (*(ushort *)(pbStack_180 + uVar27) < 0x400) break;
          uStack_188 = uStack_188 | 0x10000;
          uStack_16c = uStack_16c - 1;
        } while (uStack_16c != 0);
      }
      if ((*pbStack_180 & 0x40) == 0) {
        uStack_162 = 0;
        uStack_160 = 0;
      }
      else {
        uStack_162 = (undefined2)uVar21;
        uStack_160 = (undefined2)(uVar21 >> 0x10);
        uStack_184 = (int)uVar21 + 0xe;
        uStack_420 = 0x100f55;
        uStack_170 = uVar29;
        puVar15 = (ulonglong *)func_0x((longlong)&uStack_188 + 2);
        iVar11 = 0;
        uVar21 = *puVar15;
        uVar22 = (ushort)(uVar21 >> 0x30);
        uVar18 = uVar22;
        if ((((uint)(int)(short)uVar22 >> 1 ^ (int)(short)uVar22) & 0x2000) != 0) {
          uVar18 = uVar22 & 0xdfff;
          if ((uVar21 & 0x4000000000000000) != 0) {
            uVar18 = uVar22 | 0x2000;
          }
        }
        if (uVar18 == 0xfffc) {
          iVar11 = (int)((uVar21 >> 0x20 & 0xffff) >> 5);
        }
        uStack_184 = uStack_184 + iVar11;
        uVar21 = (ulonglong)uStack_184;
        uVar29 = uStack_170;
      }
      uVar24 = (uint)uVar21;
      uStack_170 = uVar29;
      if (((byte *)CONCAT62(uStack_168,uStack_16a) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_168,uStack_16a) < pbStack_180 + uVar21)) {
        if (((cRam0000000001c40b0b != '\0') || ((bRam0000000001c51410 & 1) != 0)) &&
           (((lVar31 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000011af398 * 8) + 8 +
                        (ulonglong)*puRam00000000011af3a0), lVar31 != 0 &&
             (lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0)) &&
            (*(char *)(lVar31 + 0x499) != '\0')))) {
          if ((cRam0000000001c409fb == '\0') && ((bRam0000000001c51410 & 2) == 0)) {
            uStack_420 = 0x101065;
            (*pcRam00000000011af338)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_3f8 = (undefined4 *)0x0;
            uStack_420 = 0x10108b;
            (*_DAT_)(1,0x1531538,0x1651208,0x877);
          }
        }
        uStack_420 = 0x10109c;
        func_0x(pbStack_180,0x12);
        uVar24 = uStack_184;
      }
      uVar29 = uStack_170;
      if (0x3f3b < uVar24 - 1) {
        if (((cRam0000000001c40b0b != '\0') || ((bRam0000000001c51410 & 1) != 0)) &&
           ((lVar31 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000011af398 * 8) + 8 +
                       (ulonglong)*puRam00000000011af3a0), lVar31 != 0 &&
            ((lVar31 = *(longlong *)(lVar31 + 0x60), lVar31 != 0 &&
             (*(char *)(lVar31 + 0x499) != '\0')))))) {
          if ((cRam0000000001c409fb == '\0') && ((bRam0000000001c51410 & 2) == 0)) {
            uStack_420 = 0x10112b;
            (*pcRam00000000011af338)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_3f8 = (undefined4 *)0x0;
            uStack_420 = 0x101153;
            (*_DAT_)(1,0x1531538,0x1651208,0x87c);
          }
        }
        uStack_420 = 0x101164;
        func_0x(pbStack_180,5);
        uVar24 = uStack_184;
        uVar29 = uStack_170;
      }
    }
code_r0x0010116a:
    if ((uVar24 < 9) && (((*pbStack_180 & 0xe) == 0 || ((*pbStack_180 & 0xe) == 0xc)))) {
      uVar24 = 9;
      bVar35 = (*pbStack_180 & 0x40) == 0;
      uVar27 = CONCAT22(uStack_160,uStack_162);
    }
    else {
      bVar35 = (*pbStack_180 & 0x40) == 0;
      uVar27 = CONCAT22(uStack_160,uStack_162);
    }
  }
  else {
    if (uVar24 == 0) {
      uStack_420 = 0x1011be;
      func_0x((longlong)&uStack_188 + 2);
      uVar24 = uStack_184;
      if (uStack_184 == 0) {
        uStack_420 = 0x1011d4;
        func_0x((longlong)&uStack_188 + 2);
        uVar24 = uStack_184;
      }
    }
    uVar29 = CONCAT22(uStack_170._2_2_,(undefined2)uStack_170);
    if ((uVar24 < 9) && (((*pbStack_180 & 0x1c) == 0 || ((*pbStack_180 & 0x1c) == 0xc)))) {
      uVar24 = 9;
    }
    bVar35 = (*pbStack_180 & 2) == 0;
    uVar27 = uStack_158;
  }
  uVar25 = uStack_370;
  if (bVar35) {
    uVar27 = uVar24;
  }
  uVar21 = (ulonglong)uStack_370 + 0xf;
  if (uVar21 <= uStack_370) {
    uVar21 = 0xffffffffffffff0;
  }
  uVar21 = uVar21 & 0xfffffffffffffff0;
  uStack_420 = 0x101234;
  uStack_170 = uVar29;
  func_0x();
  uVar29 = uStack_3ac;
  uStack_188 = 0;
  lVar31 = -uVar21;
  puVar26 = auStack_418 + lVar31;
  uStack_162 = 0;
  uStack_160 = 0;
  iVar11 = uStack_3ac - 4;
  pbStack_180 = abStack_3b8 + lVar31;
  *pbStack_180 = 8;
  pbStack_180[1] = 0;
  *(short *)(pbStack_180 + 2) = (short)iVar11 + 4;
  uStack_16c = 0;
  uStack_178 = (byte **)CONCAT44(uVar29,uVar29);
  uStack_184 = uVar29;
  uStack_170._0_2_ = (undefined2)uVar29;
  uStack_170._2_2_ = (short)(uVar29 >> 0x10);
  uVar18 = *(ushort *)(lVar16 + (0xfff - (longlong)*piStack_398) * 2);
  *(undefined8 *)(auStack_418 + lVar31 + -8) = 0x1012c2;
  func_0x
            ((longlong)&uStack_3b4 + lVar31,uVar25 - 4,(ulonglong)uVar18 + lVar16 + 4,iVar11);
  uVar24 = uStack_3b4;
  uVar25 = uStack_3b4 + uVar29;
  if (uVar25 < uStack_3b4) {
    uVar25 = 0xffffffff;
    *(undefined8 *)(auStack_418 + lVar31 + -8) = 0x1012e7;
    func_0x(0x80070216,uVar24,uVar29);
  }
  if (uVar27 < uVar25) {
    iVar11 = -1;
    *(undefined8 *)(auStack_418 + lVar31 + -8) = 0x101315;
    func_0x(0x80070216,uVar27,uVar25);
code_r0x00101317:
    *(undefined8 *)(auStack_418 + lVar31 + -8) = 0x101336;
    lVar16 = func_0x();
    lVar16 = -lVar16;
    puVar26 = auStack_418 + lVar16 + lVar31;
    pbVar32 = abStack_3b8 + lVar16 + lVar31;
    *(undefined8 *)(auStack_418 + lVar16 + lVar31 + -8) = 0x101354;
    func_0x(pbVar32);
  }
  else {
    iVar11 = uVar27 - uVar25;
    pbVar32 = (byte *)0x0;
    if (iVar11 != 0) goto code_r0x00101317;
  }
  pplVar34 = pplStack_300;
  uStack_318 = *(undefined4 *)(**pplStack_300 + 0x20);
  uStack_314 = *(undefined2 *)(**pplStack_300 + 0x24);
  uStack_312 = *(undefined2 *)piStack_398;
  *(undefined8 *)(puVar26 + -8) = 0x10138b;
  func_0x(pplVar34);
  if (*(char *)(*(longlong *)(*(longlong *)(param_1[1] + 0x58) + 8) + 0x751) == '\0') {
    puVar26[0x28] = 0;
    *(undefined4 *)(puVar26 + 0x20) = 4;
    *(undefined8 *)(puVar26 + -8) = 0x1013c6;
    func_0x(param_1,auStack_248,&uStack_318,5);
  }
  puVar26[0x30] = 1;
  *(undefined8 *)(puVar26 + 0x28) = 0;
  *(undefined4 *)(puVar26 + 0x20) = 0;
  *(undefined8 *)(puVar26 + -8) = 0x1013ee;
  func_0x(pplVar34,4,0xffffffff,auStack_240);
  if ((int)uStack_23c != 0) {
    uVar3 = *(undefined8 *)(param_1[1] + 0x58);
    uVar2 = *(undefined *)(**pplVar34 + 1);
    *(undefined8 *)(puVar26 + -8) = 0x10141b;
    func_0x(uVar3,uVar2,auStack_240,0xffffffff);
  }
  bVar30 = 0;
  if (*(int *)(param_1[1] + 0x38) == 3) {
    bVar30 = 4;
  }
  bVar30 = bVar30 | bStack_358 & 0xea;
  puStack_290 = puStack_298;
  *puStack_298 = 0x4000000;
  puStack_288 = puStack_298 + 1;
  uStack_2a0 = 0;
  bStack_358 = bVar30;
  *(undefined8 *)(puVar26 + -8) = 0x10147a;
  func_0x(param_1,0,&uStack_2c8);
  if ((*(byte *)(param_1 + 0xc) & 2) == 0) {
    if ((*(byte *)((longlong)param_1 + 0x8c) & 1) != 0) {
      *(undefined8 *)(puVar26 + -8) = 0x1014b8;
      func_0x(param_1,param_1 + 0x12,&uStack_2c8);
      *(uint *)((longlong)param_1 + 0x8c) = *(uint *)((longlong)param_1 + 0x8c) & 0xfffffffe;
    }
  }
  else {
    *(undefined8 *)(puVar26 + -8) = 0x101493;
    func_0x(param_1,(longlong)param_1 + 0x3c,&uStack_2c8);
    *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & 0xfffffffd;
  }
  lVar31 = lStack_270;
  lVar16 = lStack_3a8;
  uStack_1f8 = CONCAT71(uStack_357,bStack_358);
  uStack_208 = uStack_368;
  uStack_204 = uStack_364;
  uStack_200 = uStack_360;
  uStack_1fc = uStack_35c;
  if ((*(longlong *)(lStack_270 + 8) == 0) ||
     (lVar4 = *(longlong *)(*(longlong *)(lStack_270 + 8) + 8), *(char *)(lVar4 + 0x3f) != '\0')) {
    if (*(int *)(lStack_270 + 0x40) == 2) {
      uStack_30a = 0;
      uStack_310 = **(undefined4 **)(lStack_270 + 0x30);
      puVar20 = &uStack_310;
      uStack_30c = *(undefined2 *)(*(undefined4 **)(lStack_270 + 0x30) + 1);
    }
    else {
      uStack_302 = 0;
      uStack_308 = **(undefined4 **)(lStack_270 + 0x28);
      puVar20 = &uStack_308;
      uStack_304 = *(undefined2 *)(*(undefined4 **)(lStack_270 + 0x28) + 1);
    }
    uStack_380 = *puVar20;
    uStack_37c = *(undefined2 *)(puVar20 + 1);
  }
  else {
    uStack_380 = *(undefined4 *)(lVar4 + 8);
    uStack_37c = *(undefined2 *)(lVar4 + 0xc);
  }
  uStack_37a = 0;
  lVar4 = param_1[1];
  *(undefined4 **)(puVar26 + 0x30) = &uStack_208;
  uVar3 = *(undefined8 *)(lVar4 + 0x58);
  *(int *)(puVar26 + 0x28) = *piStack_398;
  *(undefined4 **)(puVar26 + 0x20) = &uStack_2c8;
  *(undefined8 *)(puVar26 + -8) = 0x10159e;
  func_0x(pplVar34,uVar3,&uStack_380,lVar16);
  if (*pplVar34 != (longlong *)0x0) {
    if (((*(ushort *)((longlong)*pplVar34 + 0x62) >> 10 & 1) == 0) ||
       (*(short *)((longlong)pplVar34 + 0xc) < 3)) {
      iVar13 = (int)*(short *)((longlong)pplVar34 + 0xc);
      plVar23 = *pplStack_300;
      if (((byte)*(undefined2 *)((longlong)plVar23 + 0x62) >> 3 & 1) != 0) {
        if (iVar13 == 3) {
          iVar13 = 4;
        }
        else if (iVar13 < 2) goto code_r0x00101711;
        if ((((*(uint *)((longlong)plVar23 + 100) & 8) != 0) &&
            (lVar16 = plVar23[0x12], lVar16 != 0)) && (*(longlong *)(lVar16 + 0x758) != 0)) {
          uVar3 = *(undefined8 *)(lVar16 + 0x758);
          *(undefined8 *)(puVar26 + -8) = 0x101711;
          func_0x(uVar3,plVar23,iVar13);
        }
      }
code_r0x00101711:
      if ((((bRam0000000001c50ed5 & 0x80) != 0) && ((*(uint *)((longlong)plVar23 + 100) & 8) != 0))
         && ((2 < iVar13 &&
             (((*(uint *)((longlong)plVar23 + 100) & 0xc0000000) != 0x40000000 &&
              (lVar16 = *plVar23, lVar16 != 0)))))) {
        *(undefined8 *)(puVar26 + -8) = 0x101756;
        iVar12 = (*pcRam00000000011ac418)(lVar16,0x2000,2,auStack_258);
        if (iVar12 != 0) {
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)(puVar26 + -8) = 0x101779;
      func_0x(plVar23 + 0x13);
      if ((iRam0000000001c53090 != 0) && ((bRam0000000001c5103f & 2) != 0)) {
        *(undefined8 *)(puVar26 + -8) = 0x101798;
        func_0x(plVar23,0,iVar13);
      }
      *(undefined2 *)((longlong)pplStack_300 + 0xc) = 0;
      *pplStack_300 = (longlong *)0x0;
      lVar31 = lStack_270;
      pplVar34 = pplStack_300;
    }
    else {
      *(undefined8 *)(puVar26 + -8) = 0x1015c9;
      func_0x(pplVar34);
    }
  }
  uStack_3b0 = uStack_3b0 & 0xfffffff8;
  uVar24 = (uVar27 - uStack_3b4) + param_6;
  plVar23 = *(longlong **)(lVar31 + 0x50);
  if (uVar24 < param_8) {
    uVar24 = param_8;
  }
  uVar29 = *(uint *)((longlong)param_1 + 0x34);
  *(undefined4 *)(puVar26 + 0x40) = 0;
  piVar6 = piStack_398;
  lVar16 = *plVar23;
  uStack_330 = 0;
  uStack_32c = 0;
  uVar27 = uVar24 + 0xe;
  if ((uVar29 & 0x10000) == 0) {
    uVar27 = uVar24;
  }
  *(uint **)(puVar26 + 0x38) = &uStack_3b0;
  *(undefined4 **)(puVar26 + 0x30) = &uStack_330;
  *(uint *)(puVar26 + 0x28) = uVar27;
  puVar26[0x20] = 3;
  pcVar5 = *(code **)(lVar16 + 0x10);
  *(undefined8 *)(puVar26 + -8) = 0x10163d;
  (*pcVar5)(plVar23,param_1 + 0x14,pplVar34,piVar6);
  *(undefined8 *)(puVar26 + -8) = 0x101650;
  func_0x(param_1,&uStack_3b0,&uStack_2c8);
  lVar16 = lStack_3a8;
  uStack_1d8 = CONCAT71(uStack_357,bStack_358);
  uStack_1e8 = uStack_368;
  uStack_1e4 = uStack_364;
  uStack_1e0 = uStack_360;
  uStack_1dc = uStack_35c;
  lStack_250 = (ulonglong)*(uint6 *)(*(longlong *)(lVar31 + 0x10) + 0x14) << 0x10;
  if ((*(longlong *)(lVar31 + 8) == 0) ||
     (lVar4 = *(longlong *)(*(longlong *)(lVar31 + 8) + 8), *(char *)(lVar4 + 0x3f) != '\0')) {
    if (*(int *)(lVar31 + 0x40) == 2) {
      uStack_2f2 = 0;
      uStack_2f8 = **(undefined4 **)(lVar31 + 0x30);
      puVar20 = &uStack_2f8;
      uStack_2f4 = *(undefined2 *)(*(undefined4 **)(lVar31 + 0x30) + 1);
    }
    else {
      uStack_2ea = 0;
      uStack_2f0 = **(undefined4 **)(lVar31 + 0x28);
      puVar20 = &uStack_2f0;
      uStack_2ec = *(undefined2 *)(*(undefined4 **)(lVar31 + 0x28) + 1);
    }
    uStack_378 = *puVar20;
    uStack_374 = *(undefined2 *)(puVar20 + 1);
  }
  else {
    uStack_378 = *(undefined4 *)(lVar4 + 8);
    uStack_374 = *(undefined2 *)(lVar4 + 0xc);
  }
  uStack_372 = 0;
  *(undefined4 **)(puVar26 + 0x38) = &uStack_188;
  *(undefined4 **)(puVar26 + 0x30) = &uStack_1e8;
  *(int *)(puVar26 + 0x28) = *piVar6;
  *(undefined4 **)(puVar26 + 0x20) = &uStack_2c8;
  *(undefined8 *)(puVar26 + -8) = 0x10185b;
  func_0x(pplVar34,&lStack_250,&uStack_378,lVar16);
  lVar16 = lStack_3a8;
  uVar24 = uStack_3ac;
  bVar17 = abStack_3b8[0];
  bVar7 = abStack_3b8[0] | bVar30;
  uStack_1b8 = CONCAT71(uStack_357,bVar7);
  uStack_1c8 = uStack_368;
  uStack_1c4 = uStack_364;
  uStack_1c0 = uStack_360;
  uStack_1bc = uStack_35c;
  if ((*(longlong *)(lVar31 + 8) == 0) ||
     (lVar4 = *(longlong *)(*(longlong *)(lVar31 + 8) + 8), *(char *)(lVar4 + 0x3f) != '\0')) {
    if (*(int *)(lVar31 + 0x40) == 2) {
      uStack_2e8 = **(undefined4 **)(lVar31 + 0x30);
      puVar20 = &uStack_2e8;
      uStack_2e4 = *(undefined2 *)(*(undefined4 **)(lVar31 + 0x30) + 1);
      uStack_2e2 = 0;
    }
    else {
      uStack_2e0 = **(undefined4 **)(lVar31 + 0x28);
      puVar20 = &uStack_2e0;
      uStack_2dc = *(undefined2 *)(*(undefined4 **)(lVar31 + 0x28) + 1);
      uStack_2da = 0;
    }
    uStack_3a0 = *puVar20;
    uStack_39c = *(undefined2 *)(puVar20 + 1);
  }
  else {
    uStack_3a0 = *(undefined4 *)(lVar4 + 8);
    uStack_39c = *(undefined2 *)(lVar4 + 0xc);
  }
  lVar4 = param_1[1];
  abStack_3b8[0] = bVar7;
  bStack_358 = bVar7;
  *(undefined4 **)(puVar26 + 0x50) = &uStack_1c8;
  *(undefined8 *)(puVar26 + 0x48) = uStack_268;
  *(int *)(puVar26 + 0x40) = param_6;
  piVar6 = piStack_398;
  *(undefined4 *)(puVar26 + 0x38) = 0;
  uStack_39a = 0;
  uVar3 = *(undefined8 *)(lVar4 + 0x58);
  iVar13 = *piVar6;
  *(uint *)(puVar26 + 0x30) = uVar24;
  *(int *)(puVar26 + 0x28) = iVar13;
  *(undefined8 *)(puVar26 + 0x20) = 0;
  *(undefined8 *)(puVar26 + -8) = 0x10195c;
  iVar13 = func_0x(pplVar34,uVar3,&uStack_3a0,lVar16);
  if (iVar13 != 0) {
    *(undefined8 *)(puVar26 + 0x20) = 0;
    *(undefined8 *)(puVar26 + -8) = 0x101984;
    (*_DAT_)(1,0x16e61d8,0x16b61d8,0x499);
  }
  lVar16 = lStack_3a8;
  if (iVar11 != 0) {
    bStack_358 = bVar17 & 0xfe | bVar30;
    uStack_198 = CONCAT71(uStack_357,bVar7) & 0xfffffffffffffffe;
    uStack_1a8 = uStack_368;
    uStack_1a4 = uStack_364;
    uStack_1a0 = uStack_360;
    uStack_19c = uStack_35c;
    if ((*(longlong *)(lVar31 + 8) == 0) ||
       (lVar4 = *(longlong *)(*(longlong *)(lVar31 + 8) + 8), *(char *)(lVar4 + 0x3f) != '\0')) {
      if (*(int *)(lVar31 + 0x40) == 2) {
        uStack_2d8 = **(undefined4 **)(lVar31 + 0x30);
        puVar20 = &uStack_2d8;
        uStack_2d4 = *(undefined2 *)(*(undefined4 **)(lVar31 + 0x30) + 1);
        uStack_2d2 = 0;
      }
      else {
        uStack_340 = **(undefined4 **)(lVar31 + 0x28);
        puVar20 = &uStack_340;
        uStack_33c = *(undefined2 *)(*(undefined4 **)(lVar31 + 0x28) + 1);
        uStack_33a = 0;
      }
      uStack_390 = *puVar20;
      uVar10 = *(undefined2 *)(puVar20 + 1);
    }
    else {
      uStack_390 = *(undefined4 *)(lVar4 + 8);
      uVar10 = *(undefined2 *)(lVar4 + 0xc);
    }
    lVar31 = param_1[1];
    *(undefined4 **)(puVar26 + 0x50) = &uStack_1a8;
    uStack_38c = uVar10;
    *(byte **)(puVar26 + 0x48) = pbVar32;
    uStack_38a = 0;
    uVar3 = *(undefined8 *)(lVar31 + 0x58);
    *(int *)(puVar26 + 0x40) = iVar11;
    *(undefined4 *)(puVar26 + 0x38) = 0;
    *(uint *)(puVar26 + 0x30) = param_6 + uVar24;
    *(int *)(puVar26 + 0x28) = *piStack_398;
    *(undefined8 *)(puVar26 + 0x20) = 0;
    *(undefined8 *)(puVar26 + -8) = 0x101a7b;
    iVar11 = func_0x(pplVar34,uVar3,&uStack_390,lVar16);
    if (iVar11 != 0) {
      *(undefined8 *)(puVar26 + 0x20) = 0;
      *(undefined8 *)(puVar26 + -8) = 0x101aa1;
      (*_DAT_)(1,0x16e61d8,0x16b61d8,0x4ab);
    }
  }
  if (*(char *)(param_1[1] + 0x17c) != '\0') {
    plVar23 = *pplVar34;
    *(undefined8 *)(puVar26 + -8) = 0x101ac3;
    func_0x(plVar23 + 0xe,lVar16);
  }
  if (cStack_27e != '\0') {
    *(undefined *)(param_1[1] + 0x188) = 0;
  }
LAB_:
  uVar21 = uStack_58 ^ (ulonglong)abStack_3b8;
  *(undefined8 *)(puVar26 + -8) = 0x101ae6;
  func_0x(uVar21);
  return;
}

