
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x012611d5) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong param_3)

{
  longlong *plVar1;
  uint uVar2;
  undefined8 uVar3;
  longlong lVar4;
  uint uVar5;
  longlong unaff_GS_OFFSET;
  longlong lStack_40;
  ulonglong uVar6;
  
  uVar6 = 0;
  lVar4 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  if ((lVar4 == 0) || (*(longlong *)(lVar4 + 0x110) != lVar4)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(lVar4 + 0x100) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar4 = *(longlong *)(*(longlong *)(lVar4 + 0x100) + 0x3e0);
  lStack_40 = 0;
  if (((*_DAT_ & 1) != 0) && (lVar4 != 0)) {
    uVar3 = (*_DAT_)();
    lStack_40 = (*_DAT_)(uVar3,*(undefined2 *)(lVar4 + 0xa0));
    if (lStack_40 != 0) {
      plVar1 = (longlong *)(*(longlong *)(lStack_40 + 0x18) + 0x3028);
      *plVar1 = *plVar1 + 1;
    }
  }
  if (param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = *_DAT_;
  if (*_DAT_ == 0) {
    uVar2 = 1;
  }
  if (uVar2 != 0) {
    do {
      if (((int)uVar6 != 0) && (*(int *)param_1 == 0)) break;
      uVar5 = (int)uVar6 + 1;
      uVar6 = (ulonglong)uVar5;
    } while (uVar5 < uVar2);
  }
  if (lStack_40 != 0) {
    plVar1 = (longlong *)(*(longlong *)(lStack_40 + 0x18) + 0x3020);
    *plVar1 = *plVar1 + uVar6;
  }
  if (uVar2 <= (uint)uVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  LOCK();
  lVar4 = *param_1;
  if (lVar4 == 0) {
    *param_1 = param_3;
  }
  UNLOCK();
  if (lVar4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}

