
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined4 *param_2,longlong param_3,undefined8 param_4)

{
  undefined uVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  char cVar7;
  uint uVar8;
  undefined *puVar9;
  longlong lVar10;
  undefined8 *puVar11;
  undefined4 *puVar12;
  char *pcVar13;
  ulonglong uVar14;
  undefined8 *puVar15;
  int iVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  longlong lVar19;
  undefined auStack_3a8 [32];
  undefined8 uStack_388;
  undefined8 uStack_380;
  undefined8 uStack_378;
  undefined8 uStack_370;
  undefined8 uStack_368;
  undefined8 uStack_360;
  int aiStack_358 [2];
  undefined8 uStack_350;
  undefined4 auStack_348 [2];
  undefined8 uStack_340;
  undefined8 *puStack_330;
  undefined8 uStack_328;
  undefined4 uStack_318;
  undefined4 uStack_314;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  undefined4 uStack_308;
  undefined8 uStack_2f8;
  longlong lStack_2f0;
  undefined8 *puStack_2e8;
  undefined4 uStack_2d8;
  undefined4 uStack_2d4;
  undefined4 uStack_2d0;
  undefined4 uStack_2cc;
  undefined4 uStack_2c8;
  undefined4 uStack_2c4;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined auStack_2b8 [16];
  undefined auStack_2a8 [16];
  undefined auStack_298 [16];
  undefined auStack_288 [16];
  undefined auStack_278 [16];
  undefined auStack_268 [16];
  undefined4 uStack_258;
  undefined2 uStack_254;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined8 uStack_208;
  undefined4 uStack_200;
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined2 uStack_178;
  short asStack_168 [144];
  ulonglong uStack_48;
  
  uStack_2f8 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_3a8;
  puVar15 = (undefined8 *)0x0;
  uStack_350 = 0;
  aiStack_358[0] = 0;
  if ((DAT_ != '\0') && (auStack_348[0] = 0, *param_1 != 0)) {
    uVar8 = func_0x(param_1,0x1a90f98,auStack_348);
    uVar17 = (ulonglong)uVar8;
    if ((ulonglong)uVar8 != *(ulonglong *)((ulonglong)(uVar8 - 1) * 0x58 + param_1[0xc])) {
      uVar8 = 1;
      uVar6 = 1;
      if (*(uint *)(param_1 + 0xd) != 0) {
        do {
          uVar8 = uVar6;
          if (uVar17 == *(ulonglong *)((ulonglong)(uVar8 - 1) * 0x58 + param_1[0xc])) break;
          uVar8 = uVar8 + 1;
          uVar6 = uVar8;
        } while (uVar8 <= *(uint *)(param_1 + 0xd));
      }
    }
    if (uVar8 <= *(uint *)(param_1 + 0xd)) {
      lVar19 = (ulonglong)(uVar8 - 1) * 0x58 + param_1[0xc];
      lVar10 = *param_1;
      uStack_350 = *(undefined8 *)(*(longlong *)(lVar19 + 0x10) + lVar10);
      aiStack_358[0] = *(int *)(lVar10 + *(longlong *)(lVar19 + 0x18));
      pcVar13 = (char *)(*(longlong *)(lVar19 + 8) + lVar10);
      if (pcVar13 != (char *)0x0) {
        cVar7 = *pcVar13;
        if (cVar7 == '\x01') {
          puVar9 = (undefined *)func_0x(param_1,0x1a90fc0,&uStack_350,aiStack_358);
          if (puVar9 == (undefined *)0x0) {
            uStack_388 = 0;
            (*_DAT_)(1,0x1c4c5c0,0x1c26780,0x24e);
          }
          if (aiStack_358[0] == 3) {
            uStack_388 = 0;
            (*_DAT_)(1,0x1c4c5d0,0x1c26780,0x253);
          }
          uVar1 = *puVar9;
          lVar10 = func_0x(param_1,0x1a90f38,&uStack_350,aiStack_358);
          if (lVar10 == 0) {
            uStack_388 = 0;
            (*_DAT_)(1,0x1c4c5c0,0x1c26780,0x24e);
          }
          if (aiStack_358[0] == 3) {
            uStack_388 = 0;
            (*_DAT_)(1,0x1c4c5d0,0x1c26780,0x253);
          }
          iVar16 = 0x800;
          if ((int)uStack_350 < 0x801) {
            iVar16 = (int)uStack_350;
          }
          lVar19 = func_0x(param_1,0x1a90f68,&uStack_350,aiStack_358);
          if (lVar19 == 0) {
            uStack_388 = lVar19;
            (*_DAT_)(1,0x1c4c5c0,0x1c26780,0x24e);
          }
          if (aiStack_358[0] == 3) {
            uStack_388 = 0;
            (*_DAT_)(1,0x1c4c5d0,0x1c26780,0x253);
          }
          auStack_348[0] = 0x3a;
          puStack_330 = (undefined8 *)_DAT_;
          uStack_388._0_1_ = 6;
          uStack_328 = (*_DAT_)(0x20f8,_DAT_,0x1a90ee8,0x3a);
          if (uStack_328 != 0) {
            uStack_2d8 = *param_2;
            uStack_2d4 = param_2[1];
            uStack_2d0 = param_2[2];
            uStack_2cc = param_2[3];
            uStack_360 = 0;
            uStack_368 = (undefined4 *)CONCAT44(uStack_368._4_4_,(int)uStack_350);
            uStack_378 = CONCAT44(uStack_378._4_4_,iVar16);
            uStack_380 = (undefined8 *)lVar10;
            uStack_370 = (undefined4 *)lVar19;
            uStack_388._0_1_ = uVar1;
            func_0x(uStack_328,param_3,param_4,&uStack_2d8);
          }
          uStack_340 = 0;
          goto LAB_;
        }
        if (cVar7 != '\0') {
          uStack_380 = (undefined8 *)CONCAT71(uStack_380._1_7_,cVar7);
          uStack_388._0_1_ = 0x50;
          uStack_388._1_7_ = 0x1a90e;
          func_0x(param_4,lVar10,0x1827790,0);
          goto LAB_;
        }
      }
    }
  }
  uStack_328 = CONCAT44(uStack_328._4_4_,0x46);
  lStack_2f0 = _DAT_;
  uStack_388._0_1_ = 6;
  puVar11 = (undefined8 *)(*_DAT_)(0x12b8,_DAT_,0x1a90ee8,0x46);
  puStack_2e8 = puVar11;
  if (puVar11 != (undefined8 *)0x0) {
    *puVar11 = 0x1a8f4f0;
    puVar11[1] = 0;
    puVar11[2] = 0;
    *(undefined2 *)(puVar11 + 3) = *(undefined2 *)(param_3 + 0x106);
    puVar11[4] = param_3;
    *(undefined4 *)(puVar11 + 5) = 0;
    puVar11[6] = _DAT_;
    uVar3 = param_2[1];
    uVar4 = param_2[2];
    uVar5 = param_2[3];
    *(undefined4 *)(puVar11 + 7) = *param_2;
    *(undefined4 *)((longlong)puVar11 + 0x3c) = uVar3;
    *(undefined4 *)(puVar11 + 8) = uVar4;
    *(undefined4 *)((longlong)puVar11 + 0x44) = uVar5;
    *(undefined2 *)(puVar11 + 9) = 1;
    *(undefined *)((longlong)puVar11 + 0x4a) = 0;
    puVar11[0xb] = 0;
    *(undefined4 *)(puVar11 + 0xc) = 0;
    *(undefined4 *)(puVar11 + 0xd) = 0;
    puVar11[0xe] = 0;
    *(undefined4 *)(puVar11 + 0xf) = 0;
    puVar11[0x10] = 0;
    puVar11[0x13] = 0;
    puVar15 = puVar11 + 0x11;
    puVar11[0x12] = puVar15;
    *puVar15 = puVar15;
    *(undefined4 *)(puVar11 + 0x14) = 0;
    puVar11[0x15] = 0;
    puVar11[0x18] = 0;
    puVar15 = puVar11 + 0x16;
    puVar11[0x17] = puVar15;
    *puVar15 = puVar15;
    puVar11[0x19] = 0;
    *puVar11 = 0x1a93cf8;
    puVar11[0x1b] = 0;
    puVar15 = puVar11 + 0x21f;
    puVar11[0x220] = puVar15;
    *puVar15 = puVar15;
    puVar11[0x221] = 0;
    *(undefined4 *)(puVar11 + 0x222) = 1;
    *(undefined4 *)((longlong)puVar11 + 0x1114) = 1;
    puVar11[0x223] = 1;
    puVar11[0x21e] = 0x180cbd8;
    puVar11[0x224] = 0;
    *(undefined *)((longlong)puVar11 + 0x12b3) = 0;
    *(undefined2 *)(puVar11 + 0x256) = *(undefined2 *)(puVar11[4] + 0x106);
    puVar11[0x1c] = 0;
    *(undefined *)((longlong)puVar11 + 0x56) = 0;
    uStack_340 = 0;
    *(undefined8 *)((longlong)puVar11 + 0x4c) = 0;
    *(undefined2 *)((longlong)puVar11 + 0x54) = 0;
    *(undefined *)((longlong)puVar11 + 0x12b2) = 0;
    puVar11[0x255] = 0;
    *(undefined2 *)(puVar11 + 0x1d) = 0;
    lVar10 = _DAT_;
    if (_DAT_ == 0) {
      lVar10 = *_DAT_;
    }
    func_0x(puVar11 + 0xb,0x200,lVar10);
    func_0x(puVar11);
    puVar15 = puVar11;
  }
  puStack_330 = puVar15;
  if (DAT_ == '\0') {
    lVar10 = func_0x(param_1,0x1a90eb8,&uStack_350,aiStack_358);
    if (lVar10 == 0) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      (*_DAT_)(1,0x1c4c5c0,0x1c26780,0x24e);
    }
    if (aiStack_358[0] == 3) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      (*_DAT_)(1,0x1c4c5d0,0x1c26780,0x253);
    }
    uVar17 = (ulonglong)(int)uStack_350;
    if (uVar17 < 0x65) {
      if (uVar17 != 0) goto LAB_;
    }
    else {
      uStack_388._0_1_ = 0xb8;
      uStack_388._1_7_ = 0x1a90e;
      (*_DAT_)(0xe3,0x28,0x10,3);
LAB_:
      if ((lVar10 == 0) || (0x66 < uVar17)) {
        auStack_2b8 = ZEXT816(0);
        uStack_258 = 0;
        uStack_254 = 0;
        auStack_2a8 = auStack_2b8;
        auStack_298 = auStack_2b8;
        auStack_288 = auStack_2b8;
        auStack_278 = auStack_2b8;
        auStack_268 = auStack_2b8;
        if (lVar10 == 0) {
          puVar12 = (undefined4 *)(*_DAT_)();
          *puVar12 = 0x16;
        }
        else {
          if (uVar17 < 0x67) goto LAB_;
          puVar12 = (undefined4 *)(*_DAT_)();
          *puVar12 = 0x22;
        }
        (*_DAT_)();
      }
      else {
        func_0x(auStack_2b8,lVar10);
      }
    }
LAB_:
    if (0x65 < (uVar17 & 0xfffffffffffffffe)) {
      func_0x();
      pcVar2 = (code *)swi(3);
      (*pcVar2)();
      return;
    }
    *(undefined2 *)(auStack_2b8 + (uVar17 & 0xfffffffffffffffe)) = 0;
    uStack_248 = _DAT_;
    uStack_244 = uRam0000000001a93094;
    uStack_240 = uRam0000000001a93098;
    uStack_23c = uRam0000000001a9309c;
    uStack_238 = _DAT_;
    uStack_234 = uRam0000000001a930a4;
    uStack_230 = uRam0000000001a930a8;
    uStack_22c = uRam0000000001a930ac;
    uStack_228 = _DAT_;
    uStack_224 = uRam0000000001a930b4;
    uStack_220 = uRam0000000001a930b8;
    uStack_21c = uRam0000000001a930bc;
    uStack_218 = _DAT_;
    uStack_214 = uRam0000000001a930c4;
    uStack_210 = uRam0000000001a930c8;
    uStack_20c = uRam0000000001a930cc;
    uStack_208 = _DAT_;
    uStack_200 = _DAT_;
    uVar17 = (*_DAT_)(auStack_2b8,&uStack_248);
    uVar18 = 0xffffffffffffffff;
    uVar14 = 0xffffffffffffffff;
    do {
      uVar14 = uVar14 + 1;
    } while (*(short *)(auStack_2b8 + uVar14 * 2) != 0);
    if (uVar17 < uVar14) {
      uStack_388._0_1_ = 0xb8;
      uStack_388._1_7_ = 0x1a90e;
      (*_DAT_)(0xe3,0x28,0x10,4);
    }
    (*_DAT_)(puVar15 + 0x225,0x33,auStack_2b8);
    lVar10 = func_0x(param_1,0x190e300,&uStack_350,aiStack_358);
    if (lVar10 == 0) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      (*_DAT_)(1,0x1c4c5c0,0x1c26780,0x24e);
    }
    if (aiStack_358[0] == 3) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      (*_DAT_)(1,0x1c4c5d0,0x1c26780,0x253);
    }
    uVar17 = (ulonglong)(int)uStack_350;
    if (uVar17 < 0x119) {
      if (uVar17 != 0) goto LAB_;
    }
    else {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0x190e3;
      (*_DAT_)(0xe3,0x28,0x10,5);
LAB_:
      if ((lVar10 == 0) || (0x11a < uVar17)) {
        func_0x(asStack_168,0,0x11a);
        if (lVar10 == 0) {
          puVar12 = (undefined4 *)(*_DAT_)();
          *puVar12 = 0x16;
        }
        else {
          if (uVar17 < 0x11b) goto LAB_;
          puVar12 = (undefined4 *)(*_DAT_)();
          *puVar12 = 0x22;
        }
        (*_DAT_)();
      }
      else {
        func_0x(asStack_168,lVar10);
      }
    }
LAB_:
    if (0x119 < (uVar17 & 0xfffffffffffffffe)) {
      func_0x();
      pcVar2 = (code *)swi(3);
      (*pcVar2)();
      return;
    }
    *(undefined2 *)((longlong)asStack_168 + (uVar17 & 0xfffffffffffffffe)) = 0;
    uStack_1f8 = _DAT_;
    uStack_1f4 = uRam0000000001a930e4;
    uStack_1f0 = uRam0000000001a930e8;
    uStack_1ec = uRam0000000001a930ec;
    uStack_1e8 = _DAT_;
    uStack_1e4 = uRam0000000001a930f4;
    uStack_1e0 = uRam0000000001a930f8;
    uStack_1dc = uRam0000000001a930fc;
    uStack_1d8 = _DAT_;
    uStack_1d4 = uRam0000000001a93104;
    uStack_1d0 = uRam0000000001a93108;
    uStack_1cc = uRam0000000001a9310c;
    uStack_1c8 = _DAT_;
    uStack_1c4 = uRam0000000001a93114;
    uStack_1c0 = uRam0000000001a93118;
    uStack_1bc = uRam0000000001a9311c;
    uStack_1b8 = _DAT_;
    uStack_1b4 = uRam0000000001a93124;
    uStack_1b0 = uRam0000000001a93128;
    uStack_1ac = uRam0000000001a9312c;
    uStack_1a8 = _DAT_;
    uStack_1a4 = uRam0000000001a93134;
    uStack_1a0 = uRam0000000001a93138;
    uStack_19c = uRam0000000001a9313c;
    uStack_198 = _DAT_;
    uStack_194 = uRam0000000001a93144;
    uStack_190 = uRam0000000001a93148;
    uStack_18c = uRam0000000001a9314c;
    uStack_188 = _DAT_;
    uStack_184 = uRam0000000001a93154;
    uStack_180 = uRam0000000001a93158;
    uStack_17c = uRam0000000001a9315c;
    uStack_178 = _DAT_;
    uVar17 = (*_DAT_)(asStack_168,&uStack_1f8);
    do {
      uVar18 = uVar18 + 1;
    } while (asStack_168[uVar18] != 0);
    if (uVar17 < uVar18) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0x190e3;
      (*_DAT_)(0xe3,0x28,0x10,6);
    }
    (*_DAT_)((longlong)puVar15 + 0x118e,0x8d,asStack_168);
  }
  else {
    lVar10 = func_0x(param_1,0x1a90f38,&uStack_350,aiStack_358);
    if (lVar10 == 0) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      (*_DAT_)(1,0x1c4c5c0,0x1c26780,0x24e);
    }
    if (aiStack_358[0] == 3) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      (*_DAT_)(1,0x1c4c5d0,0x1c26780,0x253);
    }
    iVar16 = 0x800;
    if ((int)uStack_350 < 0x801) {
      iVar16 = (int)uStack_350;
    }
    puVar11 = puVar15 + 0x1d;
    func_0x(puVar11,lVar10,(longlong)iVar16);
    *(undefined2 *)((longlong)puVar15 + (longlong)(iVar16 / 2) * 2 + 0xe8) = 0;
    uStack_360 = 0;
    uStack_368 = (undefined4 *)0x0;
    uStack_370 = (undefined4 *)0x0;
    uStack_378 = 0;
    uStack_380 = (undefined8 *)0x0;
    uStack_388._0_1_ = 0;
    uStack_388._1_7_ = 0;
    cVar7 = func_0x(puVar11,0,0,0);
    if (cVar7 == '\0') {
      uStack_318 = _DAT_;
      uStack_314 = uRam0000000001c1e584;
      uStack_310 = uRam0000000001c1e588;
      uStack_30c = uRam0000000001c1e58c;
      uStack_308 = 0;
      uStack_2c8 = *(undefined4 *)(puVar15 + 7);
      uStack_2c4 = *(undefined4 *)((longlong)puVar15 + 0x3c);
      uStack_2c0 = *(undefined4 *)(puVar15 + 8);
      uStack_2bc = *(undefined4 *)((longlong)puVar15 + 0x44);
      uStack_368 = &uStack_318;
      uStack_370 = &uStack_2c8;
      uStack_378 = 0x1a90f20;
      uStack_388 = 0x1a90e90;
      uStack_380 = puVar11;
      func_0x(param_4);
      uStack_368 = (undefined4 *)0x1a909a0;
      uStack_370 = (undefined4 *)CONCAT44(uStack_370._4_4_,0xc);
      uStack_378 = CONCAT44(uStack_378._4_4_,0x10);
      uStack_380 = (undefined8 *)CONCAT44(uStack_380._4_4_,0x49aa);
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      func_0x(1,param_3,0,0);
    }
    lVar10 = func_0x(param_1,0x1a90f68,&uStack_350,aiStack_358);
    if (lVar10 == 0) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      (*_DAT_)(1,0x1c4c5c0,0x1c26780,0x24e);
    }
    if (aiStack_358[0] == 3) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      (*_DAT_)(1,0x1c4c5d0,0x1c26780,0x253);
    }
    iVar16 = (int)uStack_350;
    if (0x802 < iVar16 + 1U) {
      uStack_388._0_1_ = 0;
      uStack_388._1_7_ = 0;
      (*_DAT_)(1,0x1c4bb00,0x1c26658,0xef);
    }
    *(int *)((longlong)puVar15 + 0x10ec) = iVar16;
    func_0x((longlong)puVar15 + 0x8ea,0x802,lVar10,(longlong)iVar16);
    *(undefined2 *)
     ((longlong)puVar15 +
     ((longlong)*(int *)((longlong)puVar15 + 0x10ec) & 0xfffffffffffffffeU) + 0x8ea) = 0;
  }
  puStack_330 = (undefined8 *)0x0;
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_3a8);
  return;
}

