
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ushort *param_1,undefined8 param_2,undefined8 param_3)

{
  byte bVar1;
  ushort uVar2;
  ulonglong *puVar3;
  undefined8 uVar4;
  uint uVar5;
  byte *pbVar6;
  ushort uVar7;
  uint uVar8;
  ulonglong uVar9;
  ushort *puVar10;
  int iVar11;
  longlong lVar12;
  byte *pbVar13;
  int iVar14;
  longlong unaff_GS_OFFSET;
  
  iVar14 = 0;
  if (*(int *)(param_1 + 1) == 0) {
    pbVar13 = *(byte **)(param_1 + 3);
    uVar8 = *(uint *)(param_1 + 7);
    uVar9 = (ulonglong)uVar8;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar8;
    bVar1 = *pbVar13;
    pbVar6 = pbVar13;
    if ((bVar1 & 0x10) != 0) {
      uVar8 = uVar8 + 2 + (*(ushort *)(pbVar13 + uVar9) + 7 >> 3);
      uVar9 = (ulonglong)uVar8;
      pbVar6 = *(byte **)(param_1 + 3);
      *(uint *)(param_1 + 9) = uVar8;
      bVar1 = *pbVar13;
    }
    if ((bVar1 & 0x20) == 0) {
      *(int *)(param_1 + 1) = (int)uVar9;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = (int)uVar9;
    }
    else {
      puVar10 = (ushort *)(pbVar13 + uVar9);
      uVar2 = *puVar10;
      param_1[0xd] = uVar2;
      if (uVar2 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar12 != 0)) &&
           ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9e8548,0xb08218,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar9 = (ulonglong)*(uint *)(param_1 + 9);
        uVar2 = param_1[0xd];
      }
      uVar8 = (int)uVar9 + (uVar2 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar8;
      if (0x1f9e < uVar8) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar12 != 0 &&
            ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
             (*(char *)(lVar12 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9e8548,0xb08218,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar2 = param_1[0xd];
        uVar8 = *(uint *)(param_1 + 0xb);
      }
      uVar9 = (ulonglong)uVar2;
      uVar2 = puVar10[uVar9];
      *(uint *)(param_1 + 1) = uVar2 & 0x7fff;
      if ((uVar2 & 0x7fff) < uVar8) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar12 != 0)) &&
           ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9e8548,0xb08218,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar9 = (ulonglong)param_1[0xd];
      }
      if ((short)puVar10[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
        lVar12 = *(longlong *)(param_1 + 3);
        do {
          if ((int)uVar9 == 1) {
            uVar8 = *(uint *)(param_1 + 0xb);
            uVar5 = uVar8;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar12 + uVar9 * 2) & 0x7fff) <
                uVar8) goto LAB_;
          }
          else {
            uVar5 = *(uint *)(param_1 + 0xb);
            uVar8 = *(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar12 + -2 + uVar9 * 2) &
                    0x7fff;
            if (uVar5 <= uVar8) goto LAB_;
LAB_:
            func_0x(lVar12,7);
            uVar5 = *(uint *)(param_1 + 0xb);
          }
          if ((uVar8 < uVar5) || (*(uint *)(param_1 + 1) < uVar8)) goto LAB_;
          lVar12 = *(longlong *)(param_1 + 3);
          if (*(ushort *)(lVar12 + (ulonglong)uVar8) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = param_1[0xd] - 1;
            param_1[0x14] = (ushort)uVar8;
            lVar12 = (ulonglong)(uVar8 & 0xffff) + *(longlong *)(param_1 + 3);
            uVar2 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(lVar12 + 2) & 0x4000) != 0) {
              uVar2 = *(ushort *)(lVar12 + 2) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar2;
            param_1[0x15] = (uVar2 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar2;
            uVar9 = (ulonglong)*(uint *)(param_1 + 1);
            pbVar6 = *(byte **)(param_1 + 3);
            goto LAB_;
          }
          if (*(ushort *)(lVar12 + (ulonglong)uVar8) < 0x400) break;
          *param_1 = *param_1 | 1;
          uVar2 = param_1[0xd] - 1;
          param_1[0xd] = uVar2;
          if ((uVar2 == 0) ||
             (uVar9 = (ulonglong)uVar2, -1 < (short)puVar10[(ulonglong)(uVar2 - 1) + 1])) break;
        } while( true );
      }
      uVar9 = (ulonglong)*(uint *)(param_1 + 1);
      pbVar6 = *(byte **)(param_1 + 3);
    }
LAB_:
    if ((*pbVar6 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar9;
      *(int *)(param_1 + 1) = (int)uVar9 + 0xe;
      puVar3 = (ulonglong *)func_0x(param_1);
      uVar9 = *puVar3;
      uVar7 = (ushort)(uVar9 >> 0x30);
      uVar2 = uVar7;
      if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
        uVar2 = uVar7 & 0xdfff;
        if ((uVar9 & 0x4000000000000000) != 0) {
          uVar2 = uVar7 | 0x2000;
        }
      }
      iVar11 = iVar14;
      if (uVar2 == 0xfffc) {
        iVar11 = (int)((uVar9 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar11;
      uVar9 = (ulonglong)*(uint *)(param_1 + 1);
    }
    iVar11 = (int)uVar9;
    if ((*(ulonglong *)(param_1 + 0xe) != 0) &&
       (*(ulonglong *)(param_1 + 0xe) < uVar9 + *(longlong *)(param_1 + 3))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar12 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar12 != 0 &&
           (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
          (*(char *)(lVar12 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9e8548,0xb08218,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      iVar11 = *(int *)(param_1 + 1);
    }
    if (0x3f3b < iVar11 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar12 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar12 != 0 &&
          ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
           (*(char *)(lVar12 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9e8548,0xb08218,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
    }
  }
LAB_:
  uVar4 = func_0x(param_1);
  func_0x(uVar4,param_2,param_3);
  pbVar13 = *(byte **)(param_1 + 3);
  uVar8 = *(uint *)(param_1 + 7);
  uVar9 = (ulonglong)uVar8;
  *(undefined4 *)(param_1 + 1) = 0;
  *param_1 = 0;
  *(uint *)(param_1 + 9) = uVar8;
  bVar1 = *pbVar13;
  if ((bVar1 & 0x10) != 0) {
    uVar8 = uVar8 + 2 + (*(ushort *)(pbVar13 + uVar9) + 7 >> 3);
    uVar9 = (ulonglong)uVar8;
    *(uint *)(param_1 + 9) = uVar8;
    bVar1 = *pbVar13;
  }
  if ((bVar1 & 0x20) == 0) {
    *(int *)(param_1 + 1) = (int)uVar9;
    param_1[0xd] = 0;
    *(int *)(param_1 + 0xb) = (int)uVar9;
  }
  else {
    puVar10 = (ushort *)(pbVar13 + uVar9);
    uVar2 = *puVar10;
    param_1[0xd] = uVar2;
    if (uVar2 == 0) {
      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
          (lVar12 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar12 != 0)) &&
         ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 && (*(char *)(lVar12 + 0x499) != '\0')
          ))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3eb);
        }
        else {
          (*_DAT_)(1,0x9e8548,0xb08218,0x80f,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),3);
      uVar9 = (ulonglong)*(uint *)(param_1 + 9);
      uVar2 = param_1[0xd];
    }
    uVar8 = (int)uVar9 + (uVar2 + 1) * 2;
    *(uint *)(param_1 + 0xb) = uVar8;
    if (0x1f9e < uVar8) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar12 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar12 != 0 &&
          ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
           (*(char *)(lVar12 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ec);
        }
        else {
          (*_DAT_)(1,0x9e8548,0xb08218,0x816,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),4);
      uVar2 = param_1[0xd];
      uVar8 = *(uint *)(param_1 + 0xb);
    }
    uVar9 = (ulonglong)uVar2;
    uVar2 = puVar10[uVar9];
    *(uint *)(param_1 + 1) = uVar2 & 0x7fff;
    if ((uVar2 & 0x7fff) < uVar8) {
      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
          (lVar12 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar12 != 0)) &&
         ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 && (*(char *)(lVar12 + 0x499) != '\0')
          ))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ec);
        }
        else {
          (*_DAT_)(1,0x9e8548,0xb08218,0x81d,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),4);
      uVar9 = (ulonglong)param_1[0xd];
    }
    if ((short)puVar10[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
      lVar12 = *(longlong *)(param_1 + 3);
      do {
        if ((int)uVar9 == 1) {
          uVar8 = *(uint *)(param_1 + 0xb);
          uVar5 = uVar8;
LAB_:
          if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar12 + uVar9 * 2) & 0x7fff) < uVar8
             ) goto LAB_;
        }
        else {
          uVar5 = *(uint *)(param_1 + 0xb);
          uVar8 = *(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar12 + -2 + uVar9 * 2) & 0x7fff;
          if (uVar5 <= uVar8) goto LAB_;
LAB_:
          func_0x(lVar12,7);
          uVar5 = *(uint *)(param_1 + 0xb);
        }
        if (uVar8 < uVar5) {
          return;
        }
        if (*(uint *)(param_1 + 1) < uVar8) {
          return;
        }
        lVar12 = *(longlong *)(param_1 + 3);
        if (*(ushort *)((ulonglong)uVar8 + lVar12) == 5) {
          *param_1 = *param_1 | 2;
          param_1[0xd] = param_1[0xd] - 1;
          param_1[0x14] = (ushort)uVar8;
          lVar12 = (ulonglong)(uVar8 & 0xffff) + *(longlong *)(param_1 + 3);
          uVar2 = param_1[0x15] & 0xc7ff;
          if ((*(ushort *)(lVar12 + 2) & 0x4000) != 0) {
            uVar2 = *(ushort *)(lVar12 + 2) & 0x3800 | param_1[0x15] & 0xc7ff;
          }
          param_1[0x15] = uVar2;
          param_1[0x15] = (uVar2 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar2;
          uVar9 = (ulonglong)*(uint *)(param_1 + 1);
          pbVar13 = *(byte **)(param_1 + 3);
          goto LAB_;
        }
        if (*(ushort *)((ulonglong)uVar8 + lVar12) < 0x400) break;
        *param_1 = *param_1 | 1;
        uVar2 = param_1[0xd] - 1;
        param_1[0xd] = uVar2;
        if ((uVar2 == 0) ||
           (uVar9 = (ulonglong)uVar2, -1 < (short)puVar10[(ulonglong)(uVar2 - 1) + 1])) break;
      } while( true );
    }
    uVar9 = (ulonglong)*(uint *)(param_1 + 1);
    pbVar13 = *(byte **)(param_1 + 3);
  }
LAB_:
  if ((*pbVar13 & 0x40) == 0) {
    *(undefined4 *)(param_1 + 0x12) = 0;
  }
  else {
    *(int *)(param_1 + 0x12) = (int)uVar9;
    *(int *)(param_1 + 1) = (int)uVar9 + 0xe;
    puVar3 = (ulonglong *)func_0x(param_1);
    uVar9 = *puVar3;
    uVar7 = (ushort)(uVar9 >> 0x30);
    uVar2 = uVar7;
    if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
      uVar2 = uVar7 & 0xdfff;
      if ((uVar9 & 0x4000000000000000) != 0) {
        uVar2 = uVar7 | 0x2000;
      }
    }
    if (uVar2 == 0xfffc) {
      iVar14 = (int)((uVar9 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar14;
    uVar9 = (ulonglong)*(uint *)(param_1 + 1);
  }
  iVar14 = (int)uVar9;
  if ((*(ulonglong *)(param_1 + 0xe) != 0) &&
     (*(ulonglong *)(param_1 + 0xe) < uVar9 + *(longlong *)(param_1 + 3))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar12 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar12 != 0 &&
         (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
        (*(char *)(lVar12 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x9e8548,0xb08218,0x877,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 3),0x12);
    iVar14 = *(int *)(param_1 + 1);
  }
  if (0x3f3b < iVar14 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar12 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar12 != 0 &&
        ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 && (*(char *)(lVar12 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x9e8548,0xb08218,0x87c,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 3),5);
  }
  return;
}

