
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_(undefined8 *param_1)

{
  short sVar1;
  undefined2 uVar2;
  longlong *plVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  short *psVar7;
  undefined8 uVar8;
  longlong lVar9;
  ulonglong *puVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  byte bVar13;
  byte *pbVar14;
  ushort uVar15;
  ushort uVar16;
  undefined8 *puVar18;
  uint uVar19;
  longlong lVar20;
  ushort *puVar21;
  longlong unaff_GS_OFFSET;
  bool bVar22;
  undefined8 uStackX_8;
  undefined8 uStackX_10;
  undefined8 *puStackX_18;
  ulonglong in_stack_ffffffffffffff18;
  ulonglong in_stack_ffffffffffffff20;
  ulonglong in_stack_ffffffffffffff38;
  undefined8 uStack_b0;
  undefined2 uStack_a8;
  undefined auStack_98 [96];
  ulonglong uVar17;
  
  uStackX_8 = param_1;
  if ((*(char *)((longlong)(longlong *)param_1[0x26] + 0xe) == '\0') &&
     (*(longlong *)(*(longlong *)param_1[0x26] + 0x18) == 0)) {
    psVar7 = (short *)(**(code **)*param_1)();
    pbVar14 = *(byte **)(psVar7 + 4);
    if (*psVar7 != 0) {
      return ((*pbVar14 & 0x1c) - 4 & 0xffffffe7) == 0;
    }
    bVar13 = *pbVar14 & 0xe;
    if (bVar13 == 2) {
      return (pbVar14[1] & 1) != 0;
    }
    if ((bVar13 - 10 & 0xf9) != 0) {
      return false;
    }
    if (bVar13 == 0x10) {
      return false;
    }
    return true;
  }
  if (param_1[0x28] == 0) {
    uVar8 = (*_DAT_)(0x1f9e,*(undefined8 *)param_1[3],0x9f2a00,0x36f,5);
    param_1[0x28] = uVar8;
  }
  puVar12 = (undefined8 *)0x0;
  bVar22 = false;
  iVar5 = 0;
  if (param_1[0x27] == 0) {
    uStackX_10 = CONCAT44(uStackX_10._4_4_,0x375);
    puStackX_18 = (undefined8 *)(*_DAT_)(0xb0,*(undefined8 *)param_1[3],0x9f2a00,0x375,5);
    puVar18 = puVar12;
    if (puStackX_18 != (undefined8 *)0x0) {
      *(short *)puStackX_18 = -1;
      puStackX_18[1] = 0;
      *(undefined4 *)((longlong)puStackX_18 + 4) = 0;
      *(undefined8 *)((longlong)puStackX_18 + 0x1e) = 0;
      puStackX_18[5] = 0;
      puStackX_18[2] = 0;
      *(undefined4 *)((longlong)puStackX_18 + 0x34) = 0xffffffff;
      puVar18 = puStackX_18;
    }
    param_1[0x27] = puVar18;
    uStackX_8 = (undefined8 *)param_1[0x28];
    sVar1 = *(short *)(param_1 + 0xb);
    *(short *)puVar18 = sVar1;
    if (sVar1 == 0) {
      psVar7 = (short *)((longlong)puVar18 + 2);
      if (*(int *)((longlong)param_1 + 0x5c) == 0) {
        *(undefined2 *)((longlong)param_1 + 0x5a) = 0;
        uVar19 = *(uint *)(param_1 + 0xd);
        uVar17 = (ulonglong)uVar19;
        *(uint *)((longlong)param_1 + 0x6c) = uVar19;
        pbVar14 = (byte *)param_1[0xc];
        bVar13 = *pbVar14;
        if ((bVar13 & 0x10) != 0) {
          uVar19 = uVar19 + 2 + (*(ushort *)(pbVar14 + uVar17) + 7 >> 3);
          uVar17 = (ulonglong)uVar19;
          *(uint *)((longlong)param_1 + 0x6c) = uVar19;
          bVar13 = *pbVar14;
        }
        if ((bVar13 & 0x20) == 0) {
          *(int *)((longlong)param_1 + 0x5c) = (int)uVar17;
          *(undefined2 *)((longlong)param_1 + 0x74) = 0;
          *(int *)(param_1 + 0xe) = (int)uVar17;
        }
        else {
          puVar21 = (ushort *)(pbVar14 + uVar17);
          uVar15 = *puVar21;
          *(ushort *)((longlong)param_1 + 0x74) = uVar15;
          if (uVar15 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar20 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar20 != 0)) &&
               ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                (*(char *)(lVar20 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x8c2808,0x9e24d8,0x80f,0);
              }
            }
            func_0x(param_1[0xc],3);
            uVar15 = *(ushort *)((longlong)param_1 + 0x74);
            uVar17 = (ulonglong)*(uint *)((longlong)param_1 + 0x6c);
          }
          uVar19 = (int)uVar17 + (uVar15 + 1) * 2;
          *(uint *)(param_1 + 0xe) = uVar19;
          if (0x1f9e < uVar19) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar20 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar20 != 0 &&
                ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                 (*(char *)(lVar20 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x8c2808,0x9e24d8,0x816,0);
              }
            }
            func_0x(param_1[0xc],4);
            uVar15 = *(ushort *)((longlong)param_1 + 0x74);
            uVar19 = *(uint *)(param_1 + 0xe);
          }
          uVar17 = (ulonglong)uVar15;
          uVar15 = puVar21[uVar17];
          *(uint *)((longlong)param_1 + 0x5c) = uVar15 & 0x7fff;
          if ((uVar15 & 0x7fff) < uVar19) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar20 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar20 != 0)) &&
               ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                (*(char *)(lVar20 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x8c2808,0x9e24d8,0x81d,0);
              }
            }
            func_0x(param_1[0xc],4);
            uVar17 = (ulonglong)*(ushort *)((longlong)param_1 + 0x74);
          }
          if ((short)puVar21[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
            do {
              lVar20 = param_1[0xc];
              lVar9 = (ulonglong)*(uint *)((longlong)param_1 + 0x6c) + lVar20;
              if ((int)uVar17 == 1) {
                uVar19 = *(uint *)(param_1 + 0xe);
                uVar15 = *(ushort *)(lVar9 + uVar17 * 2);
                uVar6 = uVar19;
LAB_:
                if ((uVar15 & 0x7fff) < uVar19) goto LAB_;
              }
              else {
                uVar19 = *(ushort *)(lVar9 + -2 + uVar17 * 2) & 0x7fff;
                uVar6 = *(uint *)(param_1 + 0xe);
                uVar15 = *(ushort *)(lVar9 + uVar17 * 2);
                if (uVar6 <= uVar19) goto LAB_;
LAB_:
                func_0x(lVar20,7);
                uVar6 = *(uint *)(param_1 + 0xe);
                lVar20 = param_1[0xc];
                uVar17 = (ulonglong)*(ushort *)((longlong)param_1 + 0x74);
              }
              if ((uVar19 < uVar6) || (*(uint *)((longlong)param_1 + 0x5c) < uVar19))
              goto LAB_;
              if (*(ushort *)(lVar20 + (ulonglong)uVar19) == 5) {
                *(ushort *)((longlong)param_1 + 0x5a) = *(ushort *)((longlong)param_1 + 0x5a) | 2;
                *(short *)((longlong)param_1 + 0x74) = (short)uVar17 + -1;
                *(short *)((longlong)param_1 + 0x82) = (short)uVar19;
                lVar20 = (ulonglong)(uVar19 & 0xffff) + param_1[0xc];
                uVar15 = *(ushort *)((longlong)param_1 + 0x84) & 0xc7ff;
                if ((*(ushort *)(lVar20 + 2) & 0x4000) != 0) {
                  uVar15 = *(ushort *)(lVar20 + 2) & 0x3800 | uVar15;
                }
                *(ushort *)((longlong)param_1 + 0x84) = uVar15;
                *(ushort *)((longlong)param_1 + 0x84) =
                     (uVar15 ^ *(ushort *)(lVar20 + 2)) & 0x7ff ^ uVar15;
                uVar17 = (ulonglong)*(uint *)((longlong)param_1 + 0x5c);
                pbVar14 = (byte *)param_1[0xc];
                goto LAB_;
              }
              if (*(ushort *)(lVar20 + (ulonglong)uVar19) < 0x400) break;
              *(ushort *)((longlong)param_1 + 0x5a) = *(ushort *)((longlong)param_1 + 0x5a) | 1;
              uVar15 = (short)uVar17 - 1;
              uVar17 = (ulonglong)uVar15;
              *(ushort *)((longlong)param_1 + 0x74) = uVar15;
              if ((uVar15 == 0) || (-1 < (short)puVar21[(ulonglong)(uVar15 - 1) + 1])) break;
            } while( true );
          }
          uVar17 = (ulonglong)*(uint *)((longlong)param_1 + 0x5c);
          pbVar14 = (byte *)param_1[0xc];
        }
LAB_:
        if ((*pbVar14 & 0x40) == 0) {
          *(undefined4 *)((longlong)param_1 + 0x7e) = 0;
        }
        else {
          *(int *)((longlong)param_1 + 0x7e) = *(int *)((longlong)param_1 + 0x5c);
          *(int *)((longlong)param_1 + 0x5c) = *(int *)((longlong)param_1 + 0x5c) + 0xe;
          puVar10 = (ulonglong *)func_0x((longlong)param_1 + 0x5a);
          uVar17 = *puVar10;
          uVar16 = (ushort)(uVar17 >> 0x30);
          uVar15 = uVar16;
          if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
            uVar15 = uVar16 & 0xdfff;
            if ((uVar17 & 0x4000000000000000) != 0) {
              uVar15 = uVar16 | 0x2000;
            }
          }
          if (uVar15 == 0xfffc) {
            iVar5 = (int)((uVar17 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)((longlong)param_1 + 0x5c) = *(int *)((longlong)param_1 + 0x5c) + iVar5;
          uVar17 = (ulonglong)*(uint *)((longlong)param_1 + 0x5c);
          pbVar14 = (byte *)param_1[0xc];
        }
        iVar5 = (int)uVar17;
        if ((*(byte **)((longlong)param_1 + 0x76) != (byte *)0x0) &&
           (*(byte **)((longlong)param_1 + 0x76) < pbVar14 + uVar17)) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar20 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar20 != 0 && (lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0))
              && (*(char *)(lVar20 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x8c2808,0x9e24d8,0x877,0);
            }
          }
          func_0x(param_1[0xc],0x12);
          iVar5 = *(int *)((longlong)param_1 + 0x5c);
        }
        if (0x3f3b < iVar5 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar20 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar20 != 0 &&
              ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
               (*(char *)(lVar20 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x8c2808,0x9e24d8,0x87c,0);
            }
          }
          func_0x(param_1[0xc],5);
        }
      }
LAB_:
      uVar19 = *(uint *)((longlong)param_1 + 0x5c);
      if ((uVar19 < 9) &&
         (((*(byte *)param_1[0xc] & 0xe) == 0 || ((*(byte *)param_1[0xc] & 0xe) == 0xc)))) {
        uVar19 = 9;
      }
      *(undefined4 *)(puVar18 + 2) = *(undefined4 *)(param_1 + 0xd);
      *psVar7 = *(short *)((longlong)param_1 + 0x5a);
      *(undefined4 *)((longlong)puVar18 + 4) = *(undefined4 *)((longlong)param_1 + 0x5c);
      *(short *)((longlong)puVar18 + 0x1c) = *(short *)((longlong)param_1 + 0x74);
      *(undefined4 *)((longlong)puVar18 + 0x14) = *(undefined4 *)((longlong)param_1 + 0x6c);
      *(undefined4 *)(puVar18 + 3) = *(undefined4 *)(param_1 + 0xe);
      *(undefined4 *)((longlong)puVar18 + 0x26) = *(undefined4 *)((longlong)param_1 + 0x7e);
      func_0x(uStackX_8,0x1f9e,param_1[0xc],uVar19);
      puVar18[1] = uStackX_8;
      iVar5 = func_0x(psVar7);
      if (iVar5 != 0) {
        puVar21 = (ushort *)((ulonglong)*(uint *)((longlong)puVar18 + 0x14) + puVar18[1]);
        uVar19 = *puVar21 - 1;
        if ((*(byte *)psVar7 & 1) == 0) {
          uVar19 = (uint)*puVar21;
        }
        if (uVar19 == 1) {
          uVar6 = *(uint *)(puVar18 + 3);
          uVar15 = puVar21[(int)uVar19];
LAB_:
          if ((uVar15 & 0x7fff) < uVar6) goto LAB_;
        }
        else {
          uVar6 = puVar21[(longlong)(int)uVar19 + -1] & 0x7fff;
          uVar15 = puVar21[(int)uVar19];
          if (*(uint *)(puVar18 + 3) <= uVar6) goto LAB_;
LAB_:
          func_0x(puVar18[1],7);
        }
        *(short *)((longlong)puVar18 + 0x2a) = (short)uVar6;
        lVar20 = (ulonglong)(uVar6 & 0xffff) + puVar18[1];
        uVar15 = *(ushort *)((longlong)puVar18 + 0x2c) & 0xc7ff;
        if ((*(ushort *)(lVar20 + 2) >> 0xe & 1) != 0) {
          uVar15 = *(ushort *)(lVar20 + 2) & 0x3800 | uVar15;
        }
        *(ushort *)((longlong)puVar18 + 0x2c) = uVar15;
        *(ushort *)((longlong)puVar18 + 0x2c) = (uVar15 ^ *(ushort *)(lVar20 + 2)) & 0x7ff ^ uVar15;
      }
    }
    else if (((*(short *)(param_1 + 0xb) == 0) || ((longlong *)param_1[0xd] == (longlong *)0x0)) ||
            (*(longlong *)param_1[0xd] == 0)) {
      func_0x
                ((short *)((longlong)puVar18 + 2),uStackX_8,0x1f9e,(longlong)param_1 + 0x5a);
      puVar11 = puVar12;
      if (*(short *)(param_1 + 0xb) != 0) {
        puVar11 = (undefined8 *)param_1[0xd];
      }
      puVar18[2] = puVar11;
    }
    else {
      func_0x(puVar18,uStackX_8,0x1f9e,param_1 + 0xb);
    }
  }
  lVar20 = param_1[0x22];
  if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
    uStack_b0 = *(undefined8 *)(lVar20 + 0x28);
    uStack_a8 = *(undefined2 *)(lVar20 + 0x30);
  }
  else {
    cVar4 = *(char *)(lVar20 + 1);
    if (cVar4 == '\v') {
      if (*(int *)(lVar20 + 0x18) != 99) {
LAB_:
        if (cVar4 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar4 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar20 + 0x18) != 99) goto LAB_;
    }
    uStackX_10 = CONCAT26(uStackX_10._6_2_,*(undefined6 *)(lVar20 + 0x20));
    cVar4 = func_0x(&uStackX_10);
    if (cVar4 == '\0') goto LAB_;
    func_0x(lVar20,&uStack_b0);
  }
  puVar18 = (undefined8 *)((longlong)param_1 + 0xbd6);
  *puVar18 = uStack_b0;
  *(undefined2 *)((longlong)param_1 + 0xbde) = uStack_a8;
  uStackX_10 = param_1[0x26];
  puVar11 = param_1 + 0x2b;
  psVar7 = (short *)param_1[0x27];
  lVar20 = param_1[4];
  plVar3 = *(longlong **)(param_1[0x25] + 8);
  puStackX_18 = (undefined8 *)param_1[0x28];
  if ((*(char *)(plVar3[6] + 0x2050) != '\0') && ((*(byte *)(lVar20 + 0x10) & 1) != 0)) {
    iVar5 = (**(code **)(*plVar3 + 0xf0))(plVar3);
    if (iVar5 == 0) {
      lVar9 = plVar3[0x49];
    }
    else {
      lVar9 = (**(code **)(*plVar3 + 0x1e8))(plVar3);
      lVar9 = *(longlong *)(lVar9 + 0x248);
    }
    if (*(char *)(lVar9 + 0x16) == '\0') {
      (*_DAT_)(0x27,0x30,0x10,2);
    }
  }
  func_0x(psVar7,param_1 + 0xb);
  *(int *)puVar11 = 1;
  if (uStackX_10 == 0) {
    if (((DAT_ & 8) != 0) ||
       (((lVar9 = *(longlong *)
                   ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
         lVar9 != 0 && (lVar9 = **(longlong **)(lVar9 + 0x38), lVar9 != 0)) &&
        (iVar5 = (*_DAT_)(lVar9,0xf73), iVar5 != 0)))) {
      puVar18 = puVar12;
      if (plVar3[0x1a] != 0) {
        puVar18 = *(undefined8 **)(plVar3[0x1a] + 0x40);
      }
      uVar2 = *(undefined2 *)(plVar3[6] + 0x6b8);
      uVar8 = (**(code **)(*(longlong *)plVar3[0x52] + 0x138))();
      func_0x(0x8cb8a0,uVar2,*(undefined8 *)(lVar20 + 0x28),uVar8,puVar18);
    }
  }
  else {
    bVar13 = **(byte **)(psVar7 + 4) >> 1;
    if (*psVar7 == 0) {
      bVar13 = **(byte **)(psVar7 + 4) >> 6;
    }
    if ((bVar13 & 1) != 0) {
      if (*psVar7 == 0) {
        func_0x();
      }
      else {
        func_0x(psVar7 + 1,&uStackX_8);
      }
      if ((uStackX_8._4_2_ != 0) || ((int)uStackX_8 != 0)) {
        if (*(short *)(param_1 + 0xb) == 1) {
          func_0x
                    (param_1 + 0xb,puStackX_18,0x1f9e,plVar3,lVar20,psVar7,puVar11,
                     in_stack_ffffffffffffff20 & 0xffffffffffffff00,0,uStackX_10,puVar18);
        }
        else {
          func_0x
                    (puStackX_18,0x1f9e,plVar3,lVar20,psVar7,puVar11,
                     in_stack_ffffffffffffff18 & 0xffffffffffffff00,0,uStackX_10,puVar18,
                     in_stack_ffffffffffffff38 & 0xffffffffffffff00,param_1 + 0x178);
        }
        goto LAB_;
      }
    }
  }
  if (((DAT_ & 8) != 0) ||
     (((lVar20 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar20 != 0 && (lVar20 = **(longlong **)(lVar20 + 0x38), lVar20 != 0)) &&
      (iVar5 = (*_DAT_)(lVar20,0xf73), iVar5 != 0)))) {
    (*_DAT_)(auStack_98);
    uVar8 = (*_DAT_)();
    uStackX_8 = (undefined8 *)(*_DAT_)(uVar8,0,0x6c0);
    if (uStackX_8 != (undefined8 *)0x0) {
      puVar12 = (undefined8 *)func_0x(uStackX_8,0);
    }
    if ((puVar12 != (undefined8 *)0x0) && (iVar5 = (*_DAT_)(auStack_98,puVar12), iVar5 == 0)
       ) {
      (**(code **)*puVar12)(puVar12,1);
    }
    func_0x(psVar7,auStack_98);
    (*_DAT_)(auStack_98);
  }
LAB_:
  if (*(int *)puVar11 != 0) {
    uVar19 = *(uint *)(param_1 + 2);
    uVar6 = uVar19 | 0x800;
    *(uint *)(param_1 + 2) = uVar6;
    if ((*(char *)(param_1 + 0x178) == '\0') || (*(char *)((longlong)param_1 + 0xbc1) == '\0')) {
      if ((uVar19 & 0x8000) == 0) {
        func_0x(param_1);
        uVar6 = *(uint *)(param_1 + 2);
      }
      if ((uVar6 >> 0xc & 1) == 0) {
        func_0x(param_1);
      }
      return (bool)2;
    }
    psVar7 = (short *)(**(code **)*param_1)(param_1);
    pbVar14 = *(byte **)(psVar7 + 4);
    if (*psVar7 == 0) {
      bVar13 = *pbVar14 & 0xe;
      if (bVar13 == 2) {
        bVar22 = (pbVar14[1] & 1) != 0;
      }
      else if (((bVar13 - 10 & 0xf9) == 0) && (bVar13 != 0x10)) {
        bVar22 = true;
      }
    }
    else {
      bVar22 = ((*pbVar14 & 0x1c) - 4 & 0xffffffe7) == 0;
    }
    if (!bVar22) {
      return false;
    }
  }
  return true;
}

