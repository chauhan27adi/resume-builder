
/* WARNING: Instruction at (ram,0x00102257) overlaps instruction at (ram,0x00102253)
    */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,longlong *param_3)

{
  char *pcVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined8 *puVar4;
  char cVar5;
  char cVar6;
  byte bVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  longlong lVar13;
  byte **ppbVar14;
  short *psVar15;
  undefined8 uVar16;
  longlong lVar17;
  longlong *plVar18;
  longlong *plVar19;
  byte *pbVar20;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar21;
  longlong **pplVar22;
  longlong *plVar23;
  short sVar24;
  uint *puVar25;
  byte *pbVar26;
  ulonglong uVar27;
  ulonglong uVar28;
  uint *puVar29;
  uint uVar30;
  longlong lVar31;
  uint uVar32;
  ushort *puVar33;
  longlong unaff_GS_OFFSET;
  bool bVar34;
  undefined auStack_5e8 [32];
  undefined8 uStack_5c8;
  int iStack_5c0;
  undefined8 uStack_5b8;
  undefined8 uStack_5b0;
  uint uStack_5a8;
  uint uStack_5a4;
  undefined4 uStack_588;
  char cStack_584;
  undefined4 uStack_580;
  longlong *plStack_578;
  uint uStack_570;
  char acStack_56c [4];
  int iStack_568;
  undefined4 uStack_560;
  longlong *plStack_558;
  undefined4 uStack_548;
  int iStack_540;
  int iStack_53c;
  undefined4 uStack_538;
  uint uStack_534;
  undefined4 uStack_530;
  undefined2 uStack_52c;
  uint uStack_528;
  longlong lStack_520;
  longlong lStack_518;
  uint uStack_510;
  uint uStack_50c;
  int iStack_508;
  uint uStack_504;
  undefined8 uStack_500;
  uint uStack_4f8;
  undefined8 uStack_4f0;
  longlong *plStack_4e8;
  longlong lStack_4e0;
  int iStack_4d0;
  int iStack_4cc;
  int iStack_4c4;
  longlong lStack_4b0;
  longlong *plStack_4a8;
  uint uStack_4a0;
  int iStack_49c;
  uint uStack_498;
  int iStack_494;
  undefined4 uStack_428;
  undefined2 uStack_424;
  undefined4 uStack_422;
  undefined2 uStack_41e;
  undefined4 uStack_3f8;
  undefined2 uStack_3f4;
  undefined2 uStack_3f2;
  undefined4 uStack_3f0;
  undefined2 uStack_3ec;
  undefined2 uStack_3ea;
  int iStack_3e8;
  longlong lStack_3c8;
  int iStack_3c0;
  undefined4 uStack_3b0;
  undefined4 uStack_3a8;
  ulonglong uStack_370;
  ulonglong auStack_368 [2];
  undefined auStack_354 [4];
  undefined8 uStack_350;
  longlong alStack_348 [6];
  longlong lStack_318;
  undefined8 uStack_310;
  undefined auStack_308 [8];
  undefined auStack_300 [80];
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined4 uStack_2a8;
  undefined4 uStack_2a4;
  short sStack_2a0;
  undefined4 uStack_29c;
  byte *pbStack_298;
  byte **ppbStack_290;
  undefined8 uStack_282;
  undefined2 uStack_27a;
  undefined2 uStack_278;
  undefined6 uStack_276;
  int iStack_26c;
  undefined auStack_268 [16];
  undefined auStack_258 [16];
  undefined auStack_248 [16];
  undefined auStack_238 [16];
  undefined auStack_228 [16];
  undefined auStack_218 [16];
  undefined auStack_208 [16];
  undefined8 uStack_1f8;
  undefined auStack_1f0 [14];
  undefined uStack_1e2;
  undefined auStack_1e0 [14];
  undefined uStack_1d2;
  undefined auStack_1d0 [14];
  undefined uStack_1c2;
  undefined auStack_1c0 [16];
  undefined auStack_1b0 [16];
  undefined auStack_1a0 [352];
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_5e8;
  plStack_578 = param_3;
  lStack_518 = param_1;
  iStack_508 = param_2;
  if ((*(byte *)(param_1 + 0x2e8) & 4) == 0) goto LAB_;
  iVar10 = 0;
  if (*(int *)(param_1 + 0x1c8) == 0) {
    if ((*(longlong *)(param_1 + 0x158) != 0) || (*(longlong *)(param_1 + 0x160) != 0)) {
      iVar10 = 1;
    }
    plVar18 = (longlong *)param_3[1];
    if (*(int *)(param_1 + 0x1b8) == 0) {
      if (plVar18 == (longlong *)0x0) {
        bVar34 = *(longlong *)(param_1 + 0x1c0) == -1;
      }
      else {
        bVar34 = plVar18[0x1c] == *(longlong *)(param_1 + 0x1c0);
      }
      if (bVar34) goto LAB_;
    }
    uStack_5c8 = plVar18;
    iStack_5c0 = iVar10;
    uStack_5b8 = *(undefined8 *)(param_1 + 0x170);
    uStack_5b0 = *(undefined8 *)(param_1 + 0x178);
    func_0x
              (param_1 + 0x1d4,**(undefined8 **)(param_1 + 0x2e0),*(undefined8 *)(param_1 + 0x108));
    *(undefined4 *)(param_1 + 0x1b8) = 0;
  }
  else {
    *(undefined4 *)(param_1 + 0x1d4) = 1;
  }
LAB_:
  uVar27 = 0;
  acStack_56c[0] = '\0';
  uStack_504 = 0;
  uStack_4f8 = 0;
  uVar28 = uVar27;
  if ((*(longlong *)(param_1 + 0x158) != 0) && (*(longlong *)(param_1 + 0x168) != 0)) {
    func_0x(*param_3,acStack_56c,&uStack_504);
    if (uStack_504 != 0) {
      (*_DAT_)(auStack_368);
    }
    uVar28 = (ulonglong)uStack_504;
  }
  uVar30 = (uint)uVar28;
  if (*(int *)(*param_3 + 0x40) + 1 < *(int *)(*param_3 + 0x2c)) {
    uStack_560 = iStack_4c4;
LAB_:
    uVar21 = (uint)uVar27;
    uVar30 = (uint)uVar28;
    if ((uVar30 == 0) || (param_1 = lStack_518, uVar21 != uVar30)) {
      plStack_558 = *(longlong **)(lStack_518 + 0xa18);
      pplVar22 = (longlong **)(lStack_518 + 0xa28);
      uStack_500 = CONCAT44(uStack_500._4_4_,*(undefined4 *)(lStack_518 + 0x1d4));
      if (*(int *)(plStack_558 + 1) == 1) {
        iStack_568 = -1;
        iStack_53c = 1;
        iStack_540 = 0;
        lStack_3c8 = *(longlong *)(plStack_558[3] + 0x18);
        uStack_5a4 = 0;
        uStack_5a8 = 0;
        uStack_50c = 1;
        plVar18 = plStack_558;
        iVar10 = uStack_560;
        uVar21 = 0;
        uVar30 = 0;
LAB_:
        do {
          iVar12 = iStack_568;
          lVar13 = plVar18[0x58];
          if (lVar13 == 0) {
            *(uint *)((longlong)plVar18 + 0x66c) = *(uint *)((longlong)plVar18 + 0x66c) & 0xfffffffe
            ;
            if (*(int *)(plVar18 + 0x75) == 4) {
              func_0x(plVar18 + 0x5d);
            }
            lVar13 = func_0x(plVar18 + 0xd);
            if (*(char *)(plVar18[0xc] + 0xb5) == '\0') {
              *(uint *)((longlong)plVar18 + 0x66c) = *(uint *)((longlong)plVar18 + 0x66c) | 1;
            }
            if (lVar13 != 0) goto LAB_;
LAB_:
            if (iVar12 != -1) {
              iVar12 = *(int *)(plVar18 + 0x5a);
              if (*(int *)((longlong)plVar18 + 0x2d4) == 0) {
                if ((*(char *)(lStack_3c8 + 3) == '\0') &&
                   (*(longlong *)(*(longlong *)(*(longlong *)(plVar18[2] + 8) + 0x30) + 0x1b28) == 0
                   )) {
                  iVar12 = 0;
                }
                else if ((((*(byte *)(lStack_3c8 + 4) & 8) == 0) ||
                         ((*(longlong *)(lStack_3c8 + 0x10) != 0 || ((DAT_ & 4) != 0)))) ||
                        ((lVar31 = *(longlong *)
                                    ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8)), lVar31 != 0 &&
                         ((lVar31 = **(longlong **)(lVar31 + 0x38), lVar31 != 0 &&
                          (iVar12 = (*_DAT_)(lVar31,0x4c2), iVar12 != 0)))))) {
                  iVar12 = 2;
                }
                else {
                  uVar16 = func_0x(lVar13,auStack_1c0,0);
                  iVar11 = func_0x(uVar16,plVar18 + 0xd1);
                  iVar12 = 3;
                  uVar30 = uStack_5a8;
                  if (iVar11 != 0) {
                    iVar12 = 1;
                  }
                }
                *(int *)(plVar18 + 0x5a) = iVar12;
                *(undefined4 *)((longlong)plVar18 + 0x2d4) = 1;
              }
              if (iVar12 == 0) goto LAB_;
              if (iVar12 == 1) {
                if ((int)uStack_500 == 1) goto LAB_;
LAB_:
                iStack_53c = 1;
              }
              else {
                if (iVar12 == 2) goto LAB_;
                if (iVar12 != 3) {
                  uStack_5c8 = (longlong *)0x150cc48;
                  (*_DAT_)(1,0x1911aa0,0x1941600);
                  goto LAB_;
                }
                if ((int)uStack_500 != 1) goto LAB_;
                iStack_53c = 0;
              }
              iStack_540 = 1;
              uStack_50c = ~(*(uint *)(*(longlong *)(plVar18[3] + 0x18) + 4) >> 2) & 1;
LAB_:
              plVar23 = plVar18 + 7;
              plStack_4e8 = plVar23;
LAB_:
              uVar32 = 0;
              *(uint *)((longlong)plVar23 + 0x634) =
                   *(uint *)((longlong)plVar23 + 0x634) & 0xfffffffe;
              uStack_510 = 0;
              uStack_5a8 = uVar30;
LAB_:
              plVar18 = plVar23;
              uStack_5a4 = uVar21;
              if ((*(int *)(plVar23 + 0x6e) == 4) &&
                 ((plVar19 = plVar23 + 0x56, plVar23[0x58] != _DAT_ ||
                  (plVar18 = plStack_4e8, plVar23[0x59] != _DAT_)))) {
                if (((*(byte *)(plVar23 + 100) & 2) != 0) &&
                   (iVar12 = func_0x(plVar23 + 0x65), iVar12 != 0)) {
                  *(longlong *)(*plVar19 + 0x30) = *(longlong *)(*plVar19 + 0x30) + -1;
                }
                *(undefined *)(plVar23 + 100) = 0;
                *(undefined4 *)((longlong)plVar23 + 0x31c) = 0;
                *(undefined4 *)(plVar23 + 0x67) = 0;
                if (((*(byte *)(plVar23 + 0x6a) & 2) != 0) &&
                   (iVar12 = func_0x(plVar23 + 0x6b), iVar12 != 0)) {
                  *(longlong *)(*plVar19 + 0x30) = *(longlong *)(*plVar19 + 0x30) + -1;
                }
                *(undefined *)(plVar23 + 0x6a) = 0;
                *(undefined4 *)((longlong)plVar23 + 0x34c) = 0;
                *(undefined4 *)(plVar23 + 0x6d) = 0;
                if (plVar23[0x5b] != 0) {
                  *(undefined *)((longlong)plVar23 + 0x2e6) = 0;
                  plVar23[0x5b] = 0;
                  *(undefined2 *)((longlong)plVar23 + 0x2e4) = 0;
                  *(undefined4 *)(plVar23[0x58] + 0x48) = 0;
                }
                func_0x(*(undefined8 *)*plVar19,plVar23 + 0x58);
                func_0x(plVar19);
                *(undefined4 *)(plVar23 + 0x6e) = 2;
                plVar18 = plStack_4e8;
              }
              plVar23 = plVar18;
              if ((int)uVar32 < 1) {
                if (uVar32 != 0) goto LAB_;
LAB_:
                plVar18 = plVar23 + 6;
                bVar34 = iStack_540 == 0;
                lVar13 = *(longlong *)(plVar23[7] + 8);
                pbStack_298 = (byte *)0x0;
                sStack_2a0 = -1;
                iStack_26c = 0xffffffff;
                uStack_29c = 0;
                uStack_282 = 0;
                uStack_278 = 0;
                uStack_276 = 0;
                ppbStack_290 = (byte **)0x0;
                uStack_530 = 0;
                uStack_52c = 0;
                lVar31 = *(longlong *)(*plVar18 + 0x18);
                cStack_584 = bVar34;
                lStack_520 = lVar13;
                lStack_4e0 = lVar31;
                plStack_4a8 = plVar18;
                if (((*(byte *)(plVar23 + 0x14) & 2) != 0) &&
                   (iVar10 = func_0x(plVar23 + 0x15), iVar10 != 0)) {
                  *(longlong *)(*plVar18 + 0x30) = *(longlong *)(*plVar18 + 0x30) + -1;
                }
                *(undefined *)(plVar23 + 0x14) = 0;
                *(undefined4 *)((longlong)plVar23 + 0x9c) = 0;
                *(undefined4 *)(plVar23 + 0x17) = 0;
                *(int *)(plVar23 + 10) = iStack_568;
                if (((((*(uint *)(plVar23[0x20] + 0x10) & 1) != 0) &&
                     ((*(uint *)(plVar23[0x20] + 0x10) & 0x40) == 0)) &&
                    (*(char *)(*(longlong *)(lVar13 + 0x30) + 0x1cd2) != '\0')) &&
                   (*(char *)(*(longlong *)(lVar13 + 0x30) + 0x2050) == '\0')) {
                  uStack_1d2 = 1;
                  uStack_3f8 = *(undefined4 *)(*(longlong *)plVar23[0xb] + 0x20);
                  uStack_3f4 = *(undefined2 *)(*(longlong *)plVar23[0xb] + 0x24);
                  uStack_3f2 = (undefined2)*(undefined4 *)(plVar23 + 10);
                  func_0x
                            (auStack_1e0,*(undefined2 *)(*(longlong *)(lVar13 + 0x30) + 0x6b8),
                             &uStack_3f8);
                  cVar5 = func_0x(lVar13,3,auStack_1e0);
                  if (cVar5 == '\0') {
                    func_0x(plVar18);
                    uStack_5c8 = (longlong *)CONCAT71(uStack_5c8._1_7_,1);
                    func_0x(lVar13,3,*(undefined4 *)(*(longlong *)(*plVar18 + 0x18) + 0x18))
                    ;
                    if (plVar23[0xb] == 0) {
                      func_0x(plVar18,0);
                    }
                  }
                }
                uStack_560 = CONCAT22(uStack_560._2_2_,_DAT_);
                uStack_538 = _DAT_;
                while( true ) {
                  uStack_528 = uStack_5a8;
                  uStack_534 = uStack_5a4;
                  if (((*(char *)(plVar23[7] + 0x29) != '\0') &&
                      ((*(uint *)(lVar31 + 4) & 0x140) == 0)) &&
                     (lVar17 = plVar23[0x51], lVar31 = lStack_4e0,
                     *(ushort *)(plVar23 + 10) < *(ushort *)(lVar17 + 0x16))) {
                    iVar10 = *(int *)(plVar23 + 10);
                    lStack_4b0 = 0xfff - (longlong)iVar10;
                    lVar13 = lStack_520;
                    if (*(short *)(lVar17 + lStack_4b0 * 2) != 0) {
                      iStack_26c = iVar10;
                      if (*(char *)(lVar17 + 2) < '\0') {
                        pbVar26 = (byte *)(lVar17 + 0x60);
                        if ((sStack_2a0 == 0) ||
                           (ppbVar14 = ppbStack_290, ppbStack_290 == (byte **)0x0)) {
                          auStack_268 = ZEXT816(0);
                          uStack_1f8 = 0;
                          auStack_258 = ZEXT816(0);
                          auStack_248 = ZEXT816(0);
                          auStack_238 = ZEXT816(0);
                          auStack_228 = ZEXT816(0);
                          auStack_218 = ZEXT816(0);
                          auStack_208 = ZEXT816(0);
                          ppbVar14 = (byte **)func_0x(auStack_268);
                        }
                        uVar16 = func_0x(lVar17,auStack_1b0,0);
                        if (pbVar26 == *ppbVar14) {
                          func_0x(uVar16,ppbVar14 + 0xc);
                        }
                        *ppbVar14 = pbVar26;
                        func_0x(ppbVar14 + 0xc,uVar16);
                        func_0x((longlong)ppbVar14 + 0x6c,lVar17 + 0x20);
                        uStack_3b0 = *(undefined4 *)((ulonglong)*pbVar26 * 6 + 0x158d250);
                        uVar28 = (ulonglong)*(short *)((ulonglong)*pbVar26 * 6 + 0x158d254);
                        *(undefined2 *)(ppbVar14 + 2) = 0xffff;
                        ppbVar14[3] = (byte *)0x0;
                        *(undefined4 *)((longlong)ppbVar14 + 0x14) = 0;
                        *(undefined8 *)((longlong)ppbVar14 + 0x2e) = 0;
                        ppbVar14[7] = (byte *)0x0;
                        ppbVar14[4] = (byte *)0x0;
                        ppbVar14[9] = (byte *)0x0;
                        ppbVar14[10] = (byte *)0x0;
                        *(undefined2 *)(ppbVar14 + 0xb) = 0;
                        if ((**ppbVar14 & 2) != 0) {
                          pbVar20 = pbVar26 + uVar28;
                          if ((pbVar26[uVar28] & 1) == 0) {
                            *(undefined2 *)(ppbVar14 + 2) = 0;
                            ppbVar14[3] = pbVar20;
                            *(undefined4 *)((longlong)ppbVar14 + 0x14) = 0;
                            *(undefined4 *)((longlong)ppbVar14 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010100e */
                    /* WARNING: Treating indirect jump as call */
                            (*(code *)((ulonglong)
                                       *(uint *)((longlong)(int)(*pbVar20 & 0xe) * 4 + 0x107fa8) -
                                      0xfacbe0))();
                            return;
                          }
                          *(undefined2 *)(ppbVar14 + 2) = 1;
                          ppbVar14[3] = pbVar20;
                          uStack_5a8 = uStack_528;
                          uStack_5a4 = uStack_534;
                          UNRECOVERED_JUMPTABLE =
                               (code *)((ulonglong)
                                        *(uint *)((ulonglong)
                                                  *(byte *)((longlong)(int)(*pbVar20 & 0x1c) +
                                                           0x107f88) * 4 + 0x107f78) - 0xfacbe0);
                    /* WARNING: Could not emulate address calculation at 0x00100e5e */
                    /* WARNING: Treating indirect jump as call */
                          (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                          return;
                        }
                        if ((**ppbVar14 & 4) != 0) {
                          uStack_3b0._2_2_ = (short)((uint)uStack_3b0 >> 0x10);
                          if (uStack_3b0._2_2_ != 0) {
                            uVar28 = (ulonglong)
                                     *(ushort *)(lVar17 + 0x61 + (longlong)uStack_3b0._2_2_ * 2);
                          }
                          func_0x(ppbVar14 + 9,pbVar26 + uVar28);
                        }
                        if (ppbVar14[1] != (byte *)0x0) {
                          func_0x(ppbVar14[1],ppbVar14);
                        }
                      }
                      pbStack_298 = (byte *)((ulonglong)*(ushort *)(lVar17 + lStack_4b0 * 2) +
                                            lVar17);
                      if ((*pbStack_298 & 1) == 0) {
                        sStack_2a0 = 0;
                        uStack_29c = 0;
                        uStack_27a = 0;
                        uStack_278 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001012ce */
                    /* WARNING: Treating indirect jump as call */
                        (*(code *)((ulonglong)
                                   *(uint *)((longlong)(int)(*pbStack_298 & 0xe) * 4 + 0x108014) -
                                  0xfacbe0))();
                        return;
                      }
                      sStack_2a0 = 1;
                      UNRECOVERED_JUMPTABLE =
                           (code *)((ulonglong)
                                    *(uint *)((ulonglong)
                                              *(byte *)((longlong)(int)(*pbStack_298 & 0x1c) +
                                                       0x107ff4) * 4 + 0x107fe4) - 0xfacbe0);
                    /* WARNING: Could not emulate address calculation at 0x00101121 */
                    /* WARNING: Treating indirect jump as call */
                      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                      return;
                    }
                  }
                  iVar10 = iStack_540;
                  if (bVar34 != false) break;
                  uStack_1c2 = 1;
                  uStack_3f0 = *(undefined4 *)(*(longlong *)plVar23[0xb] + 0x20);
                  uStack_3ec = *(undefined2 *)(*(longlong *)plVar23[0xb] + 0x24);
                  uStack_3ea = (undefined2)*(undefined4 *)(plVar23 + 10);
                  func_0x
                            (auStack_1d0,*(undefined2 *)(*(longlong *)(lVar13 + 0x30) + 0x6b8),
                             &uStack_3f0);
                  iVar10 = iStack_540;
                  uStack_5b0 = CONCAT44(uStack_5b0._4_4_,iStack_53c);
                  uStack_5b8 = CONCAT44(uStack_5b8._4_4_,uStack_50c);
                  iStack_5c0 = iStack_540;
                  uStack_5c8 = plVar23 + 0x12;
                  iVar12 = func_0x(plVar18,auStack_1d0,3);
                  if (iVar12 < 0) {
                    *(undefined4 *)(plVar23 + 0x1e) = 3;
                    *(undefined4 *)(plVar23 + 10) = 0xffffffff;
                    iVar10 = 1;
                    uStack_560 = 1;
                    *(uint *)((longlong)plStack_558 + 0x66c) =
                         *(uint *)((longlong)plStack_558 + 0x66c) | 1;
                    plVar18 = plStack_558;
                    uVar21 = uStack_5a4;
                    uVar30 = uStack_5a8;
                    goto LAB_;
                  }
                  if (iVar12 != 1) break;
                  bVar34 = true;
                  cStack_584 = bVar34;
                }
                *(undefined4 *)(plVar23 + 0x1e) = 4;
                lVar13 = *(longlong *)(lVar13 + 0x30);
                if ((*(longlong *)(lVar13 + 0x1b28) != 0) &&
                   (((((((*(uint *)(plVar23[0x20] + 0x10) & 1) != 0 &&
                        ((*(uint *)(plVar23[0x20] + 0x10) & 0x40) == 0)) &&
                       (*(char *)(lVar13 + 0x1cd2) != '\0')) && (*(char *)(lVar13 + 0x2050) == '\0')
                      ) || ((iVar10 == 1 && (cVar5 = func_0x(lVar31), cVar5 == '\0')))) &&
                    (lVar13 = plVar23[0x51], *(ushort *)(plVar23 + 10) < *(ushort *)(lVar13 + 0x16))
                    ))) {
                  iVar10 = *(int *)(plVar23 + 10);
                  lStack_4b0 = 0xfff - (longlong)iVar10;
                  if (*(short *)(lVar13 + lStack_4b0 * 2) != 0) {
                    iStack_26c = iVar10;
                    if (*(char *)(lVar13 + 2) < '\0') {
                      pbVar26 = (byte *)(lVar13 + 0x60);
                      if ((sStack_2a0 == 0) ||
                         (ppbVar14 = ppbStack_290, ppbStack_290 == (byte **)0x0)) {
                        auStack_268 = ZEXT816(0);
                        uStack_1f8 = 0;
                        auStack_258 = ZEXT816(0);
                        auStack_248 = ZEXT816(0);
                        auStack_238 = ZEXT816(0);
                        auStack_228 = ZEXT816(0);
                        auStack_218 = ZEXT816(0);
                        auStack_208 = ZEXT816(0);
                        ppbVar14 = (byte **)func_0x(auStack_268);
                      }
                      uVar16 = func_0x(lVar13,auStack_1a0,0,0);
                      if (pbVar26 == *ppbVar14) {
                        func_0x(uVar16,ppbVar14 + 0xc);
                      }
                      *ppbVar14 = pbVar26;
                      func_0x(ppbVar14 + 0xc,uVar16);
                      func_0x((longlong)ppbVar14 + 0x6c,lVar13 + 0x20);
                      uStack_3a8 = *(undefined4 *)((ulonglong)*pbVar26 * 6 + 0x158d250);
                      uVar28 = (ulonglong)*(short *)((ulonglong)*pbVar26 * 6 + 0x158d254);
                      *(undefined2 *)(ppbVar14 + 2) = 0xffff;
                      ppbVar14[3] = (byte *)0x0;
                      *(undefined4 *)((longlong)ppbVar14 + 0x14) = 0;
                      *(undefined8 *)((longlong)ppbVar14 + 0x2e) = 0;
                      ppbVar14[7] = (byte *)0x0;
                      ppbVar14[4] = (byte *)0x0;
                      ppbVar14[9] = (byte *)0x0;
                      ppbVar14[10] = (byte *)0x0;
                      *(undefined2 *)(ppbVar14 + 0xb) = 0;
                      if ((**ppbVar14 & 2) != 0) {
                        pbVar20 = pbVar26 + uVar28;
                        if ((pbVar26[uVar28] & 1) == 0) {
                          *(undefined2 *)(ppbVar14 + 2) = 0;
                          ppbVar14[3] = pbVar20;
                          *(undefined4 *)((longlong)ppbVar14 + 0x14) = 0;
                          *(undefined4 *)((longlong)ppbVar14 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010190e */
                    /* WARNING: Treating indirect jump as call */
                          (*(code *)((ulonglong)
                                     *(uint *)((longlong)(int)(*pbVar20 & 0xe) * 4 + 0x108080) -
                                    0xfacbe0))();
                          return;
                        }
                        *(undefined2 *)(ppbVar14 + 2) = 1;
                        ppbVar14[3] = pbVar20;
                        uStack_5a8 = uStack_528;
                        uStack_5a4 = uStack_534;
                        UNRECOVERED_JUMPTABLE =
                             (code *)((ulonglong)
                                      *(uint *)((ulonglong)
                                                *(byte *)((longlong)(int)(*pbVar20 & 0x1c) +
                                                         0x108060) * 4 + 0x108050) - 0xfacbe0);
                    /* WARNING: Could not emulate address calculation at 0x0010175a */
                    /* WARNING: Treating indirect jump as call */
                        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                        return;
                      }
                      if ((**ppbVar14 & 4) != 0) {
                        uStack_3a8._2_2_ = (short)((uint)uStack_3a8 >> 0x10);
                        if (uStack_3a8._2_2_ != 0) {
                          uVar28 = (ulonglong)
                                   *(ushort *)(lVar13 + 0x61 + (longlong)uStack_3a8._2_2_ * 2);
                        }
                        func_0x(ppbVar14 + 9,pbVar26 + uVar28);
                      }
                      if (ppbVar14[1] != (byte *)0x0) {
                        func_0x(ppbVar14[1],ppbVar14);
                      }
                    }
                    pbStack_298 = (byte *)((ulonglong)*(ushort *)(lVar13 + lStack_4b0 * 2) + lVar13)
                    ;
                    if ((*pbStack_298 & 1) == 0) {
                      sStack_2a0 = 0;
                      uStack_29c = 0;
                      uStack_27a = 0;
                      uStack_278 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101bcd */
                    /* WARNING: Treating indirect jump as call */
                      (*(code *)((ulonglong)
                                 *(uint *)((longlong)(int)(*pbStack_298 & 0xe) * 4 + 0x1080ec) -
                                0xfacbe0))();
                      return;
                    }
                    sStack_2a0 = 1;
                    UNRECOVERED_JUMPTABLE =
                         (code *)((ulonglong)
                                  *(uint *)((ulonglong)
                                            *(byte *)((longlong)(int)(*pbStack_298 & 0x1c) +
                                                     0x1080cc) * 4 + 0x1080bc) - 0xfacbe0);
                    /* WARNING: Could not emulate address calculation at 0x00101a1d */
                    /* WARNING: Treating indirect jump as call */
                    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                    return;
                  }
                }
                func_0x(plVar18,1);
                uStack_5a4 = *(uint *)(plVar23 + 0x4d);
                uStack_5a8 = *(uint *)((longlong)plVar23 + 0x26c);
                iVar10 = 0;
                uStack_560 = 0;
                plVar23 = plStack_4e8;
                uVar32 = uStack_510;
                uVar21 = uStack_5a4;
              }
              else {
                if (plVar23[0xb] == 0) {
                  func_0x(plVar23 + 6,0);
                }
                if (*(int *)(plVar23 + 0x4e) == 0) {
                  func_0x(plVar23 + 6,1);
                }
                uStack_5a4 = *(uint *)(plVar23 + 0x4d);
                uStack_5a8 = *(uint *)((longlong)plVar23 + 0x26c);
                uVar21 = uStack_5a4;
LAB_:
                if (*(char *)(plVar23[5] + 0x29) != '\0') goto LAB_;
                if (iVar10 != 0) goto LAB_;
              }
              if ((uVar21 != 3) ||
                 ((*(char *)(*(longlong *)(plVar23[4] + 0x18) + 3) != '\0' &&
                  ((iStack_540 == 0 || (iStack_53c == 0)))))) goto LAB_;
              bVar34 = false;
              if (*(char *)(plVar23[5] + 0x29) == '\0') {
                cVar5 = func_0x();
                if ((cVar5 == '\0') || (2 < (int)uVar32)) goto LAB_;
                uStack_4f0 = 0;
                iVar12 = func_0x(plVar23);
              }
              else {
                bVar34 = (int)uVar32 < 0x32;
LAB_:
                uStack_4f0 = 0;
                iVar12 = func_0x(plVar23);
                if (!bVar34) goto LAB_;
              }
              if (1 < iVar12 - 1U) goto LAB_;
              uVar32 = uVar32 + 1;
              uStack_510 = uVar32;
              func_0x(plVar23 + 6);
              uVar30 = uStack_5a8;
              uStack_5a8 = uVar30;
              if (*(char *)(plVar23[5] + 0x29) == '\0') {
                func_0x(10);
                uStack_5a8 = uVar30;
              }
              goto LAB_;
            }
          }
          else {
LAB_:
            if (*(int *)((longlong)plVar18 + 0x34) == 0) {
              iStack_568 = iStack_508 + *(int *)(plVar18 + 6);
            }
            else {
              *(undefined4 *)((longlong)plVar18 + 0x34) = 0;
              iStack_568 = *(int *)((longlong)plVar18 + 0x684);
              if (iStack_568 == -1) {
                iStack_568 = (int)*(short *)((longlong)plVar18 + 0x682);
                if (*(short *)((longlong)plVar18 + 0x682) == -1) {
                  if (iStack_508 == 1) {
                    iStack_568 = 0;
                  }
                  else {
                    iStack_568 = *(ushort *)(lVar13 + 0x16) - 1;
                  }
                }
              }
              else {
                *(undefined4 *)((longlong)plVar18 + 0x684) = 0xffffffff;
              }
            }
            if ((ushort)iStack_568 < *(ushort *)(lVar13 + 0x16)) {
              if ((*(short *)((longlong)plVar18 + 0x682) == -1) ||
                 (iStack_568 == *(short *)((longlong)plVar18 + 0x682))) {
                *(int *)(plVar18 + 6) = iStack_568;
                iVar12 = iStack_568;
                goto LAB_;
              }
              iStack_568 = -1;
            }
            else {
              iStack_568 = -1;
            }
          }
          if ((plVar18[0xf] != _DAT_) || (plVar18[0x10] != _DAT_)) {
            if (((*(byte *)(plVar18 + 0x1b) & 2) != 0) &&
               (iVar10 = func_0x(plVar18 + 0x1c), iVar10 != 0)) {
              *(longlong *)(plVar18[0xd] + 0x30) = *(longlong *)(plVar18[0xd] + 0x30) + -1;
            }
            *(undefined *)(plVar18 + 0x1b) = 0;
            *(undefined4 *)((longlong)plVar18 + 0xd4) = 0;
            *(undefined4 *)(plVar18 + 0x1e) = 0;
            if (((*(byte *)(plVar18 + 0x21) & 2) != 0) &&
               (iVar10 = func_0x(plVar18 + 0x22), iVar10 != 0)) {
              *(longlong *)(plVar18[0xd] + 0x30) = *(longlong *)(plVar18[0xd] + 0x30) + -1;
            }
            *(undefined *)(plVar18 + 0x21) = 0;
            *(undefined4 *)((longlong)plVar18 + 0x104) = 0;
            *(undefined4 *)(plVar18 + 0x24) = 0;
            if (plVar18[0x12] != 0) {
              *(undefined *)((longlong)plVar18 + 0x9e) = 0;
              plVar18[0x12] = 0;
              *(undefined2 *)((longlong)plVar18 + 0x9c) = 0;
              *(undefined4 *)(plVar18[0xf] + 0x48) = 0;
            }
            func_0x(*(undefined8 *)plVar18[0xd],plVar18 + 0xf);
            func_0x(plVar18 + 0xd);
            *(undefined4 *)(plVar18 + 0x25) = 2;
          }
          plVar23 = plVar18 + 0x5d;
          if ((plVar18[0x5f] != _DAT_) || (plVar18[0x60] != _DAT_)) {
            if (((*(byte *)(plVar18 + 0x6b) & 2) != 0) &&
               (iVar10 = func_0x(plVar18 + 0x6c), iVar10 != 0)) {
              *(longlong *)(*plVar23 + 0x30) = *(longlong *)(*plVar23 + 0x30) + -1;
            }
            *(undefined *)(plVar18 + 0x6b) = 0;
            *(undefined4 *)((longlong)plVar18 + 0x354) = 0;
            *(undefined4 *)(plVar18 + 0x6e) = 0;
            if (((*(byte *)(plVar18 + 0x71) & 2) != 0) &&
               (iVar10 = func_0x(plVar18 + 0x72), iVar10 != 0)) {
              *(longlong *)(*plVar23 + 0x30) = *(longlong *)(*plVar23 + 0x30) + -1;
            }
            *(undefined *)(plVar18 + 0x71) = 0;
            *(undefined4 *)((longlong)plVar18 + 900) = 0;
            *(undefined4 *)(plVar18 + 0x74) = 0;
            if (plVar18[0x62] != 0) {
              *(undefined *)((longlong)plVar18 + 0x31e) = 0;
              plVar18[0x62] = 0;
              *(undefined2 *)((longlong)plVar18 + 0x31c) = 0;
              *(undefined4 *)(plVar18[0x5f] + 0x48) = 0;
            }
            func_0x(*(undefined8 *)*plVar23,plVar18 + 0x5f);
            func_0x(plVar23);
            *(undefined4 *)(plVar18 + 0x75) = 2;
          }
          *(undefined4 *)((longlong)plVar18 + 0x66c) = 0;
          while( true ) {
            plVar23 = plStack_558;
            uStack_5c8 = (longlong *)&uStack_2b0;
            iVar10 = func_0x(*(undefined8 *)plStack_558[3],plVar18 + 5);
            if (iVar10 != 0) {
              plVar18 = (longlong *)0x0;
              iVar10 = 1;
              goto LAB_;
            }
            uVar3 = *(undefined4 *)(plVar23 + 0xcf);
            puVar29 = (uint *)((longlong)plVar23 + 0x66c);
            *puVar29 = *puVar29 & 0xfffffffe;
            uStack_1e2 = 1;
            uVar16 = *(undefined8 *)plVar18[0xd];
            plVar23 = *(longlong **)(plVar18[0xe] + 8);
            *(undefined4 *)(plVar18 + 0xf) = uStack_2b0;
            *(undefined4 *)((longlong)plVar18 + 0x7c) = uStack_2ac;
            *(undefined4 *)(plVar18 + 0x10) = uStack_2a8;
            *(undefined4 *)((longlong)plVar18 + 0x84) = uStack_2a4;
            func_0x(uVar16);
            plVar18[0x58] = *(longlong *)plVar18[0x12];
            *(undefined4 *)(plVar18 + 0x18) = uVar3;
            *(undefined4 *)((longlong)plVar18 + 0x2d4) = 0;
            lVar13 = *(longlong *)(plVar18[0xd] + 0x18);
            if (((((*(uint *)(plVar18[0x27] + 0x10) & 1) != 0) &&
                 ((*(uint *)(plVar18[0x27] + 0x10) & 0x40) == 0)) &&
                (*(char *)(plVar23[6] + 0x1cd2) != '\0')) &&
               (*(char *)(plVar23[6] + 0x2050) == '\0')) {
              uStack_428 = *(undefined4 *)(plVar18[0xf] + 0x90);
              uStack_424 = *(undefined2 *)(plVar18[0xf] + 0x94);
              func_0x(auStack_1f0,*(undefined2 *)(plVar23[6] + 0x6b8),&uStack_428,0)
              ;
              cVar5 = func_0x(*(undefined8 *)(plVar18[0xe] + 8));
              if (cVar5 == '\0') {
                func_0x(plVar18 + 0xd);
                uStack_5c8 = (longlong *)CONCAT71(uStack_5c8._1_7_,1);
                func_0x(*(undefined8 *)(plVar18[0xe] + 8));
              }
            }
            if (*(char *)(lVar13 + 2) == '\0') {
              func_0x(*(undefined8 *)plVar18[0xe]);
            }
            else {
              cVar5 = (**(code **)(*plVar23 + 0x28))(plVar23);
              if (cVar5 == '\0') {
                uStack_422 = *(undefined4 *)(plVar18[0xf] + 0x90);
                uStack_41e = *(undefined2 *)(plVar18[0xf] + 0x94);
                func_0x
                          (auStack_1f0,
                           *(undefined2 *)
                            (*(longlong *)(*(longlong *)(plVar18[0xe] + 8) + 0x30) + 0x6b8),
                           &uStack_422,0);
                uStack_5c8 = plVar18 + 0x1f;
                uStack_5b0 = CONCAT44(uStack_5b0._4_4_,1);
                uStack_5b8 = CONCAT44(uStack_5b8._4_4_,1);
                iStack_5c0 = 1;
                iVar10 = func_0x(plVar18 + 0xd);
                if (iVar10 < 0) {
                  if ((plVar18[0xf] != _DAT_) || (plVar18[0x10] != _DAT_)) {
                    if (((*(byte *)(plVar18 + 0x1b) & 2) != 0) &&
                       (iVar10 = func_0x(plVar18 + 0x1c), iVar10 != 0)) {
                      *(longlong *)(plVar18[0xd] + 0x30) = *(longlong *)(plVar18[0xd] + 0x30) + -1;
                    }
                    *(undefined *)(plVar18 + 0x1b) = 0;
                    *(undefined4 *)((longlong)plVar18 + 0xd4) = 0;
                    *(undefined4 *)(plVar18 + 0x1e) = 0;
                    if (((*(byte *)(plVar18 + 0x21) & 2) != 0) &&
                       (iVar10 = func_0x(plVar18 + 0x22), iVar10 != 0)) {
                      *(longlong *)(plVar18[0xd] + 0x30) = *(longlong *)(plVar18[0xd] + 0x30) + -1;
                    }
                    *(undefined *)(plVar18 + 0x21) = 0;
                    *(undefined4 *)((longlong)plVar18 + 0x104) = 0;
                    *(undefined4 *)(plVar18 + 0x24) = 0;
                    if (plVar18[0x12] != 0) {
                      if (plVar18[0x12] != 0) {
                        *(undefined *)((longlong)plVar18 + 0x9e) = 0;
                        plVar18[0x12] = 0;
                        *(undefined2 *)((longlong)plVar18 + 0x9c) = 0;
                      }
                      *(undefined4 *)(plVar18[0xf] + 0x48) = 0;
                    }
                    func_0x(*(undefined8 *)plVar18[0xd]);
                    func_0x(plVar18 + 0xd);
                    *(undefined4 *)(plVar18 + 0x25) = 2;
                  }
                  *(uint *)((longlong)plStack_558 + 0x66c) =
                       *(uint *)((longlong)plStack_558 + 0x66c) | 1;
                  goto LAB_;
                }
              }
            }
            *(undefined4 *)(plVar18 + 0x25) = 3;
            if ((plVar18[0x12] != 0) ||
               (func_0x(plVar18 + 0xd,1), *(int *)(plVar18 + 0x25) == 3)) break;
            *(uint *)((longlong)plStack_558 + 0x66c) = *(uint *)((longlong)plStack_558 + 0x66c) | 1;
          }
          *(uint *)((longlong)plStack_558 + 0x66c) = *(uint *)((longlong)plStack_558 + 0x66c) | 1;
LAB_:
          *(undefined4 *)((longlong)plStack_558 + 0x34) = 1;
          plVar18 = plStack_558;
          iVar10 = uStack_560;
          uVar21 = uStack_5a4;
          uVar30 = uStack_5a8;
        } while( true );
      }
      iVar10 = (**(code **)(*plStack_558 + 0x38))
                         (plStack_558,param_2,*(undefined4 *)(lStack_518 + 0x1d4));
      goto LAB_;
    }
  }
  goto LAB_;
LAB_:
  if (plVar23[0x5b] == 0) {
    func_0x(plVar23 + 0x56,0);
  }
  if (*(int *)(plVar23 + 0x9e) == 0) {
    func_0x(plVar23 + 0x56,1);
  }
  uStack_5a8 = *(uint *)((longlong)plVar23 + 0x4ec);
LAB_:
  plVar18 = plStack_558;
  uVar30 = uStack_5a8;
  uVar32 = *(uint *)((longlong)plVar23 + 0x634);
  *(uint *)((longlong)plVar23 + 0x634) = uVar32 | 1;
  if (iVar10 != 0) goto LAB_;
  if (uVar21 == 2) goto LAB_;
  if (uVar21 == 3) {
    if ((*(char *)(*(longlong *)(plStack_558[3] + 0x18) + 3) == '\0') ||
       ((iStack_540 != 0 && (iStack_53c != 0)))) goto LAB_;
    iStack_540 = 1;
    iStack_53c = 1;
    if (plStack_558[0x58] == 0) {
      *(uint *)((longlong)plStack_558 + 0x66c) = uVar32 & 0xfffffffe;
      if (*(int *)(plStack_558 + 0x75) == 4) {
        func_0x(plStack_558 + 0x5d);
      }
      func_0x(plVar18 + 0xd);
      if (*(char *)(plVar18[0xc] + 0xb5) == '\0') {
        *(uint *)((longlong)plVar18 + 0x66c) = *(uint *)((longlong)plVar18 + 0x66c) | 1;
      }
    }
    goto LAB_;
  }
  if ((uVar21 == 1) || (uVar21 == 4)) goto LAB_;
LAB_:
  if (uStack_5a8 == 0) {
LAB_:
    if ((*(int *)(*(longlong *)(plStack_558[3] + 0x18) + 8) == 0x10000) ||
       (*(longlong *)(*(longlong *)(plStack_558[3] + 0x18) + 0x10) != 0)) {
      func_0x(plVar23);
    }
    goto LAB_;
  }
  iVar10 = 0;
  plVar18 = plStack_558 + 7;
LAB_:
  pplVar22 = (longlong **)(lStack_518 + 0xa28);
  *pplVar22 = plVar18;
  param_3 = plStack_578;
  uVar21 = uStack_4f8;
LAB_:
  param_1 = lStack_518;
  cVar5 = acStack_56c[0];
  if (iVar10 != 0) {
    if (*pplVar22 != (longlong *)0x0) {
      uStack_5c8 = (longlong *)0x0;
      (*_DAT_)(1,0x1941530);
    }
    iVar10 = func_0x(param_1,1);
    if (iVar10 != 0) goto LAB_;
    goto LAB_;
  }
  lStack_3c8 = *(longlong *)(lStack_518 + 0x178);
  pcVar1 = (char *)(lStack_518 + 0xac0);
  puVar4 = *(undefined8 **)(lStack_518 + 0x168);
  uStack_4f8 = uVar21 + 1;
  lStack_4b0 = *(longlong *)(lStack_518 + 0x170);
  plVar18 = *(longlong **)(lStack_518 + 0x160);
  lVar31 = *(longlong *)(lStack_518 + 0x158);
  uVar16 = *(undefined8 *)(lStack_518 + 0xa28);
  lVar13 = lStack_518 + 400;
  lStack_520 = func_0x(uVar16,1);
  if ((lVar31 == 0) && (puVar4 == (undefined8 *)0x0)) {
LAB_:
    if (plVar18 != (longlong *)0x0) {
      plVar23 = *(longlong **)plVar18[1];
      *(longlong *)(param_1 + 0x1b0) = lStack_520;
      *(undefined8 *)(param_1 + 0x1a8) = uVar16;
      (**(code **)(*plVar23 + 0x20))(plVar23,lVar13);
      iVar10 = (**(code **)(*plVar18 + 8))(plVar18,uStack_310);
      if (iVar10 == 0) goto LAB_;
    }
    if (lStack_4b0 != 0) {
      *(longlong *)(param_1 + 0x1b0) = lStack_520;
      *(undefined8 *)(param_1 + 0x1a8) = uVar16;
      iVar10 = func_0x(lVar13);
      if (iVar10 == 0) goto LAB_;
    }
    param_3 = plStack_578;
    *(int *)(*plStack_578 + 0x40) = *(int *)(*plStack_578 + 0x40) + 1;
    param_1 = lStack_518;
    if (*(int *)(plStack_578 + 3) == 0) goto LAB_;
    plVar18 = *(longlong **)(lStack_518 + 0xa28);
    uVar30 = 0;
    lVar13 = plStack_578[1];
    plVar23 = plVar18;
    if ((*(uint *)(lStack_518 + 0x2e8) & 0x800) == 0) {
      plVar23 = (longlong *)0x0;
    }
    plStack_4e8 = plVar18;
    if ((plVar23 == (longlong *)0x0) || (*(char *)(plVar23 + 199) == '\0')) {
LAB_:
      if ((*(short *)(lVar13 + 0x3a) != 0) || (*(int *)(lVar13 + 0x50) != 0)) {
        func_0x(param_1,plVar18);
        if (iStack_4c4 != 1) {
          lVar13 = *(longlong *)(*(longlong *)(param_1 + 0x108) + 0x70);
          if (((lVar13 != 0) && ((*(uint *)(*(longlong *)(param_1 + 0x108) + 0x120) & 0x100) != 0))
             && (func_0x(plVar18 + 6,lVar13), *(int *)(plVar18 + 0x6e) == 4)) {
            func_0x(plVar18 + 0x56,lVar13);
          }
        }
        goto LAB_;
      }
    }
    else {
      plVar19 = plStack_578;
      param_1 = func_0x();
      lVar13 = *(longlong *)(lVar13 + 0x100);
      if (plVar23[200] == 0) goto LAB_;
      piVar2 = (int *)(plVar23[200] + 0x54 + (longlong)plVar19 * 4);
      *piVar2 = *piVar2 + -1;
    }
    psVar15 = (short *)func_0x(plVar18,1);
    lVar13 = param_1 + 0x110;
    plStack_558 = (longlong *)(param_1 + 0xa60);
    lVar31 = plStack_578[1];
    uStack_500 = lVar13;
    if ((*(byte *)(lVar31 + 0x30) & 1) == 0) {
LAB_:
      if (plVar18 == (longlong *)0x0) {
        *(short **)(param_1 + 0xa68) = psVar15;
        *(undefined8 *)(param_1 + 0xa70) = 0;
      }
      else {
        *(undefined8 *)(param_1 + 0xa68) = 0;
        *(longlong **)(param_1 + 0xa70) = plVar18;
        lVar17 = (**(code **)*plVar18)(plVar18);
        plStack_558[1] = lVar17;
      }
      uVar30 = 0;
      if (*psVar15 == 0) {
        *psVar15 = 0;
        uVar30 = *(uint *)(plStack_578 + 3);
        lVar31 = plStack_578[2];
        uStack_5a4 = 0;
        uStack_5a8 = uVar30;
        if (uVar30 != 0) {
          do {
            uVar21 = uStack_5a4;
            if (*(byte *)(lVar31 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar31 + 0x40) * 4 + 0x108128) -
                           0xfacbe0);
                    /* WARNING: Could not emulate address calculation at 0x001032a5 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar32 = *(uint *)(lVar31 + 0x40);
            if ((uVar32 >> 10 & 1) != 0) {
              func_0x(plStack_578,lVar31);
              uVar32 = *(uint *)(lVar31 + 0x40);
            }
            if ((uVar32 >> 9 & 1) != 0) {
              uStack_5c8 = (longlong *)CONCAT44(uStack_5c8._4_4_,uStack_580);
              func_0x(plStack_578,lVar13,lVar31,0);
            }
            uStack_5a4 = uVar21 + 1;
            lVar31 = lVar31 + 0x50;
          } while (uStack_5a4 < uVar30);
        }
      }
      else if (*(int *)(*(longlong *)(param_1 + 0x118) + 0x100) == 2) {
        uStack_538 = *(undefined4 *)(lVar31 + 0x34);
        lVar31 = plStack_578[2];
        lStack_520 = *(longlong *)(*plStack_578 + 0x30);
        uStack_528 = *(uint *)(plStack_578 + 3);
        uStack_510 = 0;
        if (uStack_528 != 0) {
          do {
            plVar18 = plStack_578;
            if (*(byte *)(lVar31 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar31 + 0x40) * 4 + 0x108478) -
                           0xfacbe0);
                    /* WARNING: Could not emulate address calculation at 0x00105b26 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar30 = *(uint *)(lVar31 + 0x40);
            if ((uVar30 >> 10 & 1) != 0) {
              func_0x(plStack_578,lVar31);
              uVar30 = *(uint *)(lVar31 + 0x40);
            }
            if ((uVar30 >> 9 & 1) != 0) {
              uStack_5c8 = (longlong *)CONCAT44(uStack_5c8._4_4_,uStack_588);
              func_0x(plVar18,lVar13,lVar31,0);
            }
            lVar31 = lVar31 + 0x50;
            uStack_510 = uStack_510 + 1;
          } while (uStack_510 < uStack_528);
        }
      }
      else {
        if (*psVar15 == -1) {
          *psVar15 = 1;
        }
        uVar21 = *(uint *)(plStack_578 + 3);
        lVar13 = plStack_578[2];
        if (uVar21 != 0) {
          do {
            if (*(byte *)(lVar13 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar13 + 0x40) * 4 + 0x1082d0) -
                           0xfacbe0);
                    /* WARNING: Could not emulate address calculation at 0x00105238 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar32 = *(uint *)(lVar13 + 0x40);
            if ((uVar32 >> 10 & 1) != 0) {
              func_0x(plStack_578,lVar13);
              uVar32 = *(uint *)(lVar13 + 0x40);
            }
            if ((uVar32 >> 9 & 1) != 0) {
              uStack_5c8 = (longlong *)CONCAT44(uStack_5c8._4_4_,uStack_548);
              func_0x(plStack_578,uStack_500,lVar13,0);
            }
            uVar30 = uVar30 + 1;
            lVar13 = lVar13 + 0x50;
          } while (uVar30 < uVar21);
        }
      }
      plVar18 = plStack_4e8;
      param_1 = lStack_518;
      if (plStack_4e8 != (longlong *)0x0) {
        (**(code **)(**(longlong **)(lStack_518 + 0xa70) + 8))();
        lVar13 = *plVar18;
        goto LAB_;
      }
    }
    else {
      if (*psVar15 == 0) {
        if ((**(byte **)(psVar15 + 4) & 0x10) == 0) {
          uVar21 = 0;
        }
        else {
          uVar21 = (uint)*(ushort *)(*(byte **)(psVar15 + 4) + *(uint *)(psVar15 + 8));
        }
      }
      else {
        uVar21 = (uint)(ushort)psVar15[1];
      }
      if (uVar21 < *(uint *)(lVar31 + 0x18)) goto LAB_;
      *psVar15 = 0;
      puVar29 = (uint *)plStack_578[2];
      uStack_528 = (uint)*(ushort *)(plStack_578[1] + 0x62);
      if (uStack_528 != 0) {
        do {
          cVar5 = *(char *)(puVar29 + 0x10);
          if (cVar5 == '\x01') {
            if ((*(byte *)((longlong)puVar29 + 6) & 0x10) == 0) {
              uVar21 = *(byte *)((ulonglong)(*(ushort *)(puVar29 + 1) - 1 >> 3) +
                                 (ulonglong)*(uint *)(psVar15 + 8) + 2 + *(longlong *)(psVar15 + 4))
                       >> ((byte)(*(ushort *)(puVar29 + 1) - 1) & 7) & 1;
            }
            else {
              uStack_5c8 = &uStack_350;
              func_0x(psVar15 + 1,puVar29,1);
              uVar21 = uStack_498;
            }
            if (uVar21 == 0) goto LAB_;
            func_0x(plStack_578,puVar29);
          }
          else {
            if (cVar5 == '\x02') {
LAB_:
              uVar8 = *(ushort *)(puVar29 + 0xf);
              uVar32 = (uint)uVar8;
              uVar21 = uVar32;
              if ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0) {
                uStack_5c8 = (longlong *)&iStack_494;
                func_0x(psVar15 + 1,puVar29,0,auStack_354);
                if (((iStack_494 == 0) && (uVar21 = **(uint **)(puVar29 + 2), uVar8 != 0)) &&
                   (uVar21 != uVar32)) {
                  uStack_5c8 = (longlong *)0x0;
                  (*_DAT_)(1,0x193e4d8,0x193ced8,0x381);
                }
              }
            }
            else {
              if (cVar5 == '\x03') {
                if ((*(byte *)((longlong)puVar29 + 6) & 0x10) == 0) {
                  uVar21 = *(byte *)((ulonglong)(*(ushort *)(puVar29 + 1) - 1 >> 3) +
                                     (ulonglong)*(uint *)(psVar15 + 8) + 2 +
                                    *(longlong *)(psVar15 + 4)) >>
                           ((byte)(*(ushort *)(puVar29 + 1) - 1) & 7) & 1;
                }
                else {
                  uStack_5c8 = alStack_348;
                  func_0x(psVar15 + 1,puVar29,1);
                  uVar21 = uStack_4a0;
                }
                if (uVar21 != 0) {
                  func_0x(plStack_578,puVar29);
                  goto LAB_;
                }
              }
              else if (cVar5 != '\x04') {
                if (cVar5 != '\b') {
                  uStack_5c8 = (longlong *)0x150cc48;
                  (*_DAT_)(1,0x1911aa0,0x193e3e0,0x27d);
                  uVar21 = uStack_570;
                  goto LAB_;
                }
                uVar21 = puVar29[0x10];
                uVar8 = *(ushort *)(puVar29 + 0xf);
                if ((*puVar29 & 0xc0000000) == 0x80000000) {
                  iVar10 = func_0x(psVar15 + 1);
                  if (iVar10 == 0) {
                    uStack_570 = 0;
                    func_0x(plStack_578,puVar29);
                    goto LAB_;
                  }
                  puVar25 = (uint *)func_0x(psVar15 + 0x15,puVar29);
                  uVar21 = uStack_570;
                }
                else {
                  if (((int)(uVar21 << 0xc) < 0) || ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0)
                     ) {
                    uStack_5c8 = (longlong *)&iStack_4cc;
                    func_0x(psVar15 + 1,puVar29);
                    if (((int)(uVar21 << 0xc) < 0) && (iStack_4d0 != 0)) {
                      uStack_570 = 0;
                      puVar25 = (uint *)0x0;
                      uVar21 = uStack_570;
                      goto LAB_;
                    }
                  }
                  else {
                    iStack_4d0 = 0;
                    iStack_4cc = 1;
                  }
                  if ((iStack_4cc == 0) && ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0)) {
                    puVar25 = *(uint **)(puVar29 + 2) + 1;
                    uVar21 = **(uint **)(puVar29 + 2);
                  }
                  else if ((int)*puVar29 < 0) {
                    if (*(int *)(psVar15 + 2) == 0) {
                      psVar15[1] = 0;
                      uVar21 = *(uint *)(psVar15 + 8);
                      uVar28 = (ulonglong)uVar21;
                      *(uint *)(psVar15 + 10) = uVar21;
                      pbVar26 = *(byte **)(psVar15 + 4);
                      bVar7 = *pbVar26;
                      if ((bVar7 & 0x10) != 0) {
                        uVar21 = uVar21 + (*(ushort *)(pbVar26 + uVar28) + 7 >> 3) + 2;
                        uVar28 = (ulonglong)uVar21;
                        *(uint *)(psVar15 + 10) = uVar21;
                        bVar7 = *pbVar26;
                      }
                      if ((bVar7 & 0x20) == 0) {
                        *(int *)(psVar15 + 2) = (int)uVar28;
                        psVar15[0xe] = 0;
                        *(uint *)(psVar15 + 0xc) = uVar21;
                      }
                      else {
                        puVar33 = (ushort *)(pbVar26 + uVar28);
                        uVar8 = *puVar33;
                        psVar15[0xe] = uVar8;
                        if (uVar8 == 0) {
                          cVar5 = func_0x(0x1e9f9e0);
                          if (((cVar5 != '\0') && (lVar13 = func_0x(), lVar13 != 0))
                             && (*(char *)(lVar13 + 0x499) != '\0')) {
                            cVar5 = func_0x(0x1e9f9e0);
                            if (cVar5 == '\0') {
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              uStack_5c8 = (longlong *)0x0;
                              (*_DAT_)(1,0x1790768,0x18b0438);
                            }
                          }
                          func_0x(*(undefined8 *)(psVar15 + 4),3);
                          uVar8 = psVar15[0xe];
                          uVar21 = *(uint *)(psVar15 + 10);
                        }
                        uVar21 = uVar21 + (uVar8 + 1) * 2;
                        *(uint *)(psVar15 + 0xc) = uVar21;
                        if (0x1f9e < uVar21) {
                          cVar5 = func_0x(0x1e9f9e0);
                          if (((cVar5 != '\0') && (lVar13 = func_0x(), lVar13 != 0))
                             && (*(char *)(lVar13 + 0x499) != '\0')) {
                            cVar5 = func_0x(0x1e9f9e0);
                            if (cVar5 == '\0') {
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              uStack_5c8 = (longlong *)0x0;
                              (*_DAT_)(1,0x1790768,0x18b0438);
                            }
                          }
                          func_0x(*(undefined8 *)(psVar15 + 4),4);
                          uVar8 = psVar15[0xe];
                          uVar21 = *(uint *)(psVar15 + 0xc);
                        }
                        uVar28 = (ulonglong)uVar8;
                        uVar8 = puVar33[uVar28];
                        *(uint *)(psVar15 + 2) = uVar8 & 0x7fff;
                        if ((uVar8 & 0x7fff) < uVar21) {
                          cVar5 = func_0x(0x1e9f9e0);
                          if (((cVar5 != '\0') && (lVar13 = func_0x(), lVar13 != 0))
                             && (*(char *)(lVar13 + 0x499) != '\0')) {
                            cVar5 = func_0x(0x1e9f9e0);
                            if (cVar5 == '\0') {
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              uStack_5c8 = (longlong *)0x0;
                              (*_DAT_)(1,0x1790768,0x18b0438);
                            }
                          }
                          func_0x(*(undefined8 *)(psVar15 + 4),4);
                          uVar28 = (ulonglong)(ushort)psVar15[0xe];
                        }
                        if ((short)puVar33[(ulonglong)((int)uVar28 - 1) + 1] < 0) {
                          do {
                            lVar13 = (ulonglong)*(uint *)(psVar15 + 10) + *(longlong *)(psVar15 + 4)
                            ;
                            if ((int)uVar28 == 1) {
                              uVar21 = *(uint *)(psVar15 + 0xc);
                              uVar32 = uVar21;
LAB_:
                              if ((*(ushort *)(lVar13 + uVar28 * 2) & 0x7fff) < uVar21)
                              goto LAB_;
                            }
                            else {
                              uVar32 = *(uint *)(psVar15 + 0xc);
                              uVar21 = *(ushort *)(lVar13 + -2 + uVar28 * 2) & 0x7fff;
                              if (uVar32 <= uVar21) goto LAB_;
LAB_:
                              func_0x(*(longlong *)(psVar15 + 4),7);
                              uVar32 = *(uint *)(psVar15 + 0xc);
                            }
                            if ((uVar21 < uVar32) || (*(uint *)(psVar15 + 2) < uVar21))
                            goto LAB_;
                            if (*(ushort *)((ulonglong)uVar21 + *(longlong *)(psVar15 + 4)) == 5) {
                              psVar15[1] = psVar15[1] | 2;
                              psVar15[0xe] = psVar15[0xe] + -1;
                              psVar15[0x15] = (short)uVar21;
                              lVar13 = (ulonglong)(uVar21 & 0xffff) + *(longlong *)(psVar15 + 4);
                              uVar9 = psVar15[0x16] & 0xc7ff;
                              uVar8 = *(ushort *)(lVar13 + 2);
                              if ((uVar8 >> 0xe & 1) != 0) {
                                uVar9 = uVar8 & 0x3800 | uVar9;
                              }
                              psVar15[0x16] = uVar9;
                              psVar15[0x16] = (uVar9 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar9;
                              goto LAB_;
                            }
                            if (*(ushort *)((ulonglong)uVar21 + *(longlong *)(psVar15 + 4)) < 0x400)
                            goto LAB_;
                            psVar15[1] = psVar15[1] | 1;
                            uVar8 = psVar15[0xe] - 1;
                            psVar15[0xe] = uVar8;
                            if (uVar8 == 0) goto LAB_;
                            uVar28 = (ulonglong)uVar8;
                          } while ((short)puVar33[(ulonglong)(uVar8 - 1) + 1] < 0);
                          pbVar26 = *(byte **)(psVar15 + 4);
                        }
                        else {
LAB_:
                          pbVar26 = *(byte **)(psVar15 + 4);
                        }
                      }
                      if ((*pbVar26 & 0x40) == 0) {
                        *(undefined4 *)(psVar15 + 0x13) = 0;
                      }
                      else {
                        *(int *)(psVar15 + 0x13) = *(int *)(psVar15 + 2);
                        *(int *)(psVar15 + 2) = *(int *)(psVar15 + 2) + 0xe;
                        uVar16 = func_0x(psVar15 + 1);
                        func_0x(uVar16,auStack_308);
                        iVar10 = func_0x(auStack_308);
                        *(int *)(psVar15 + 2) = *(int *)(psVar15 + 2) + iVar10;
                      }
                      uVar21 = *(uint *)(psVar15 + 2);
                      if ((*(ulonglong *)(psVar15 + 0xf) != 0) &&
                         (*(ulonglong *)(psVar15 + 0xf) <
                          (ulonglong)uVar21 + *(longlong *)(psVar15 + 4))) {
                        cVar5 = func_0x(0x1e9f9e0);
                        if ((cVar5 != '\0') &&
                           ((lVar13 = func_0x(), lVar13 != 0 &&
                            (*(char *)(lVar13 + 0x499) != '\0')))) {
                          cVar5 = func_0x(0x1e9f9e0);
                          if (cVar5 == '\0') {
                            (*_DAT_)(0x22);
                          }
                          else {
                            uStack_5c8 = (longlong *)0x0;
                            (*_DAT_)(1,0x1790768);
                          }
                        }
                        func_0x(*(undefined8 *)(psVar15 + 4),0x12);
                        uVar21 = *(uint *)(psVar15 + 2);
                      }
                      if (0x3f3b < uVar21 - 1) {
                        cVar5 = func_0x(0x1e9f9e0);
                        if (((cVar5 != '\0') && (lVar13 = func_0x(), lVar13 != 0))
                           && (*(char *)(lVar13 + 0x499) != '\0')) {
                          cVar5 = func_0x(0x1e9f9e0);
                          if (cVar5 == '\0') {
                            (*_DAT_)(0x22);
                          }
                          else {
                            uStack_5c8 = (longlong *)0x0;
                            (*_DAT_)(1,0x1790768);
                          }
                        }
                        func_0x(*(undefined8 *)(psVar15 + 4),5);
                      }
                    }
LAB_:
                    sVar24 = -*(short *)puVar29;
                    if ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0) {
                      uStack_5c8 = (longlong *)&iStack_3c0;
                      func_0x(psVar15 + 1,puVar29);
                      if (iStack_3c0 == 0) {
                        puVar25 = *(uint **)(puVar29 + 2) + 1;
                        uVar21 = **(uint **)(puVar29 + 2);
                        goto LAB_;
                      }
                    }
                    lVar13 = (longlong)sVar24;
                    if ((uint)(ushort)psVar15[0xe] < (uint)(int)sVar24) {
                      uStack_570 = 0;
                      puVar25 = *(uint **)(psVar15 + 4);
                      uVar21 = uStack_570;
                    }
                    else {
                      lVar31 = *(longlong *)(psVar15 + 4);
                      lVar17 = (ulonglong)*(uint *)(psVar15 + 10) + lVar31;
                      if (sVar24 == 1) {
                        uVar28 = (ulonglong)*(uint *)(psVar15 + 0xc);
                        uVar21 = *(ushort *)(lVar17 + lVar13 * 2) & 0x7fff;
LAB_:
                        if (uVar21 < (uint)uVar28) goto LAB_;
                      }
                      else {
                        uVar32 = *(ushort *)(lVar17 + -2 + lVar13 * 2) & 0x7fff;
                        uVar28 = (ulonglong)uVar32;
                        lVar31 = *(longlong *)(psVar15 + 4);
                        uVar21 = *(ushort *)(lVar17 + lVar13 * 2) & 0x7fff;
                        if (*(uint *)(psVar15 + 0xc) <= uVar32) goto LAB_;
LAB_:
                        func_0x(lVar31,7);
                      }
                      puVar25 = (uint *)(uVar28 + *(longlong *)(psVar15 + 4));
                      uVar21 = uVar21 - (int)uVar28;
                    }
                  }
                  else if ((*(ushort *)((longlong)puVar29 + 6) & 8) == 0) {
                    if ((*(ushort *)((longlong)puVar29 + 6) & 0x10) != 0) {
                      uStack_5c8 = (longlong *)&iStack_3e8;
                      func_0x(psVar15 + 1,puVar29);
                      if (iStack_3e8 == 0) {
                        uVar21 = **(uint **)(puVar29 + 2);
                        puVar25 = *(uint **)(puVar29 + 2) + 1;
                        if ((uVar8 != 0) && (uVar21 != uVar8)) {
                          uStack_5c8 = (longlong *)0x0;
                          (*_DAT_)(1,0x193e4d8);
                        }
                        goto LAB_;
                      }
                    }
                    puVar25 = (uint *)((longlong)(int)*puVar29 + *(longlong *)(psVar15 + 4));
                    uVar21 = (uint)uVar8;
                  }
                  else {
                    puVar25 = (uint *)func_0x(psVar15 + 1,puVar29);
                    uVar21 = uStack_570;
                  }
                }
LAB_:
                uStack_570 = uVar21;
                uVar21 = uStack_570;
                if (puVar25 == (uint *)0x0) {
                  func_0x(plStack_578,puVar29);
                  goto LAB_;
                }
                goto LAB_;
              }
              if (*(int *)(psVar15 + 2) == 0) {
                psVar15[1] = 0;
                uVar21 = *(uint *)(psVar15 + 8);
                uVar28 = (ulonglong)uVar21;
                *(uint *)(psVar15 + 10) = uVar21;
                pbVar26 = *(byte **)(psVar15 + 4);
                bVar7 = *pbVar26;
                pbVar20 = pbVar26;
                if ((bVar7 & 0x10) != 0) {
                  uVar21 = uVar21 + (*(ushort *)(pbVar26 + uVar28) + 7 >> 3) + 2;
                  uVar28 = (ulonglong)uVar21;
                  *(uint *)(psVar15 + 10) = uVar21;
                  bVar7 = *pbVar26;
                  pbVar20 = *(byte **)(psVar15 + 4);
                }
                if ((bVar7 & 0x20) == 0) {
                  *(int *)(psVar15 + 2) = (int)uVar28;
                  psVar15[0xe] = 0;
                  *(uint *)(psVar15 + 0xc) = uVar21;
                }
                else {
                  puVar33 = (ushort *)(pbVar26 + uVar28);
                  uVar8 = *puVar33;
                  psVar15[0xe] = uVar8;
                  if (uVar8 == 0) {
                    cVar5 = func_0x(0x1e9f9e0);
                    if (((cVar5 != '\0') && (lVar13 = func_0x(), lVar13 != 0)) &&
                       (*(char *)(lVar13 + 0x499) != '\0')) {
                      cVar5 = func_0x(0x1e9f9e0);
                      if (cVar5 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        uStack_5c8 = (longlong *)0x0;
                        (*_DAT_)(1,0x1790768,0x18b0438,0x80f);
                      }
                    }
                    func_0x(*(undefined8 *)(psVar15 + 4),3);
                    uVar8 = psVar15[0xe];
                    uVar21 = *(uint *)(psVar15 + 10);
                  }
                  uVar21 = uVar21 + (uVar8 + 1) * 2;
                  *(uint *)(psVar15 + 0xc) = uVar21;
                  if (0x1f9e < uVar21) {
                    cVar5 = func_0x(0x1e9f9e0);
                    if (((cVar5 != '\0') && (lVar13 = func_0x(), lVar13 != 0)) &&
                       (*(char *)(lVar13 + 0x499) != '\0')) {
                      cVar5 = func_0x(0x1e9f9e0);
                      if (cVar5 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_5c8 = (longlong *)0x0;
                        (*_DAT_)(1,0x1790768,0x18b0438,0x816);
                      }
                    }
                    func_0x(*(undefined8 *)(psVar15 + 4),4);
                    uVar8 = psVar15[0xe];
                    uVar21 = *(uint *)(psVar15 + 0xc);
                  }
                  uVar28 = (ulonglong)uVar8;
                  uVar8 = puVar33[uVar28];
                  *(uint *)(psVar15 + 2) = uVar8 & 0x7fff;
                  if ((uVar8 & 0x7fff) < uVar21) {
                    cVar5 = func_0x(0x1e9f9e0);
                    if (((cVar5 != '\0') && (lVar13 = func_0x(), lVar13 != 0)) &&
                       (*(char *)(lVar13 + 0x499) != '\0')) {
                      cVar5 = func_0x(0x1e9f9e0);
                      if (cVar5 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_5c8 = (longlong *)0x0;
                        (*_DAT_)(1,0x1790768,0x18b0438,0x81d);
                      }
                    }
                    func_0x(*(undefined8 *)(psVar15 + 4),4);
                    uVar28 = (ulonglong)(ushort)psVar15[0xe];
                  }
                  if ((short)puVar33[(ulonglong)((int)uVar28 - 1) + 1] < 0) {
                    do {
                      lVar13 = *(longlong *)(psVar15 + 4);
                      if ((int)uVar28 == 1) {
                        uVar21 = *(uint *)(psVar15 + 0xc);
                        uVar32 = uVar21;
LAB_:
                        if ((*(ushort *)((ulonglong)*(uint *)(psVar15 + 10) + lVar13 + uVar28 * 2) &
                            0x7fff) < uVar21) goto LAB_;
                      }
                      else {
                        uVar32 = *(uint *)(psVar15 + 0xc);
                        uVar21 = *(ushort *)
                                  ((ulonglong)*(uint *)(psVar15 + 10) + lVar13 + -2 + uVar28 * 2) &
                                 0x7fff;
                        if (uVar32 <= uVar21) goto LAB_;
LAB_:
                        func_0x(lVar13,7);
                        uVar32 = *(uint *)(psVar15 + 0xc);
                        lVar13 = *(longlong *)(psVar15 + 4);
                      }
                      if ((uVar21 < uVar32) || (*(uint *)(psVar15 + 2) < uVar21)) goto LAB_;
                      if (*(ushort *)((ulonglong)uVar21 + lVar13) == 5) {
                        psVar15[1] = psVar15[1] | 2;
                        psVar15[0xe] = psVar15[0xe] + -1;
                        psVar15[0x15] = (short)uVar21;
                        lVar13 = (ulonglong)(uVar21 & 0xffff) + *(longlong *)(psVar15 + 4);
                        uVar9 = psVar15[0x16] & 0xc7ff;
                        uVar8 = *(ushort *)(lVar13 + 2);
                        if ((uVar8 >> 0xe & 1) != 0) {
                          uVar9 = uVar8 & 0x3800 | uVar9;
                        }
                        psVar15[0x16] = uVar9;
                        psVar15[0x16] = (uVar9 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar9;
                        goto LAB_;
                      }
                      if (*(ushort *)((ulonglong)uVar21 + lVar13) < 0x400) goto LAB_;
                      psVar15[1] = psVar15[1] | 1;
                      uVar8 = psVar15[0xe] - 1;
                      psVar15[0xe] = uVar8;
                      if (uVar8 == 0) goto LAB_;
                      uVar28 = (ulonglong)uVar8;
                    } while ((short)puVar33[(ulonglong)(uVar8 - 1) + 1] < 0);
                    pbVar20 = *(byte **)(psVar15 + 4);
                  }
                  else {
LAB_:
                    pbVar20 = *(byte **)(psVar15 + 4);
                  }
                }
                if ((*pbVar20 & 0x40) == 0) {
                  *(undefined4 *)(psVar15 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar15 + 0x13) = *(int *)(psVar15 + 2);
                  *(int *)(psVar15 + 2) = *(int *)(psVar15 + 2) + 0xe;
                  uVar16 = func_0x(psVar15 + 1);
                  func_0x(uVar16,auStack_300);
                  iVar10 = func_0x(auStack_300);
                  *(int *)(psVar15 + 2) = *(int *)(psVar15 + 2) + iVar10;
                  pbVar20 = *(byte **)(psVar15 + 4);
                }
                uVar21 = *(uint *)(psVar15 + 2);
                if ((*(byte **)(psVar15 + 0xf) != (byte *)0x0) &&
                   (*(byte **)(psVar15 + 0xf) < pbVar20 + uVar21)) {
                  cVar5 = func_0x(0x1e9f9e0);
                  if ((cVar5 != '\0') &&
                     ((lVar13 = func_0x(), lVar13 != 0 &&
                      (*(char *)(lVar13 + 0x499) != '\0')))) {
                    cVar5 = func_0x(0x1e9f9e0);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      uStack_5c8 = (longlong *)0x0;
                      (*_DAT_)(1,0x1790768,0x18b0438,0x877);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar15 + 4),0x12);
                  uVar21 = *(uint *)(psVar15 + 2);
                }
                if (0x3f3b < uVar21 - 1) {
                  cVar5 = func_0x(0x1e9f9e0);
                  if (((cVar5 != '\0') && (lVar13 = func_0x(), lVar13 != 0)) &&
                     (*(char *)(lVar13 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x1e9f9e0);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      uStack_5c8 = (longlong *)0x0;
                      (*_DAT_)(1,0x1790768,0x18b0438,0x87c);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar15 + 4),5);
                }
              }
LAB_:
              sVar24 = -*(short *)puVar29;
              if ((*(byte *)((longlong)puVar29 + 6) & 0x10) == 0) {
LAB_:
                lVar13 = (longlong)sVar24;
                if ((uint)(ushort)psVar15[0xe] < (uint)(int)sVar24) {
                  uStack_570 = 0;
                }
                else {
                  lVar31 = *(longlong *)(psVar15 + 4);
                  lVar17 = (ulonglong)*(uint *)(psVar15 + 10) + lVar31;
                  if (sVar24 == 1) {
                    uVar21 = *(uint *)(psVar15 + 0xc);
                    uVar32 = *(ushort *)(lVar17 + lVar13 * 2) & 0x7fff;
LAB_:
                    if (uVar32 < uVar21) goto LAB_;
                  }
                  else {
                    uVar21 = *(ushort *)(lVar17 + -2 + lVar13 * 2) & 0x7fff;
                    lVar31 = *(longlong *)(psVar15 + 4);
                    uVar32 = *(ushort *)(lVar17 + lVar13 * 2) & 0x7fff;
                    if (*(uint *)(psVar15 + 0xc) <= uVar21) goto LAB_;
LAB_:
                    func_0x(lVar31,7);
                  }
                  uStack_570 = uVar32 - uVar21;
                }
              }
              else {
                uStack_5c8 = (longlong *)&iStack_49c;
                func_0x(psVar15 + 1,puVar29,0,(longlong)&uStack_350 + 4);
                if (iStack_49c != 0) goto LAB_;
                uStack_570 = **(uint **)(puVar29 + 2);
              }
              if (((puVar29[0x10] & 0x2000) != 0) && (uStack_570 == 0)) {
                uStack_570 = 4;
              }
              if ((((1 << (**(byte **)(psVar15 + 4) & 0xe) & 0x440U) == 0) ||
                  (iVar10 = func_0x(puVar29), uVar21 = uStack_570, iVar10 == 0)) &&
                 (uVar21 = uStack_570, *(ushort *)(puVar29 + 0xf) < uStack_570)) {
                (*_DAT_)(6,0x52,0x16,0x91);
                uVar21 = uStack_570;
              }
            }
LAB_:
            uStack_570 = uVar21;
            uStack_5c8 = (longlong *)CONCAT44(uStack_5c8._4_4_,uStack_570);
            func_0x(*plStack_578,puVar29[10]);
          }
LAB_:
          uVar30 = uVar30 + 1;
          puVar29 = puVar29 + 0x14;
        } while (uVar30 < uStack_528);
        lVar13 = *plStack_4e8;
        plVar18 = plStack_4e8;
        param_1 = lStack_518;
        goto LAB_;
      }
    }
    lVar13 = *plStack_4e8;
    plVar18 = plStack_4e8;
    param_1 = lStack_518;
  }
  else {
    *(longlong *)(param_1 + 0x1b0) = lStack_520;
    *(undefined8 *)(param_1 + 0x1a8) = uVar16;
    lStack_318 = lVar13;
    if ((((cVar5 == '\0') ||
         ((puVar4 == (undefined8 *)0x0 ||
          (cVar6 = (**(code **)*puVar4)(puVar4,lVar13), cVar6 != '\0')))) &&
        ((lVar31 == 0 ||
         (((**(code **)(lVar31 + 8))(&lStack_318,lVar31), *pcVar1 != '\x03' &&
          (*(char *)(param_1 + 0xac8) != '\0')))))) &&
       ((cVar5 != '\0' ||
        ((puVar4 == (undefined8 *)0x0 ||
         (cVar5 = (**(code **)*puVar4)(puVar4,lVar13), cVar5 != '\0')))))) goto LAB_;
LAB_:
    param_1 = lStack_518;
    lVar13 = *(longlong *)(*(longlong *)(lStack_518 + 0x2d8) + 0x18);
    if ((*(int *)(lVar13 + 8) == 0x10000) || (*(longlong *)(lVar13 + 0x10) != 0)) {
      func_0x(*(undefined8 *)(lStack_518 + 0xa28));
    }
    plVar18 = *(longlong **)(param_1 + 0xa28);
    lVar13 = *plVar18;
  }
LAB_:
  (**(code **)(lVar13 + 8))(plVar18);
  param_3 = plStack_578;
LAB_:
  if (*(int *)(*param_3 + 0x2c) <= *(int *)(*param_3 + 0x40) + 1) goto LAB_;
  uVar28 = (ulonglong)uStack_504;
  uVar27 = (ulonglong)uStack_4f8;
  param_2 = iStack_508;
  goto LAB_;
LAB_:
  uVar27 = (ulonglong)uStack_4f8;
  uVar30 = uStack_504;
LAB_:
  if (uVar30 != 0) {
    (*_DAT_)(&uStack_370);
    lVar13 = uStack_370 - auStack_368[0];
    if (uStack_370 < auStack_368[0]) {
      lVar13 = 0;
    }
    func_0x(*param_3,acStack_56c[0],uVar27,lVar13);
  }
  lVar13 = *(longlong *)(*(longlong *)(param_1 + 0x1e0) + 0x58);
  if (lVar13 != 0) {
    plVar18 = (longlong *)(lVar13 + 0x58);
    *plVar18 = *plVar18 + uVar27;
  }
LAB_:
  func_0x(uStack_40 ^ (ulonglong)auStack_5e8);
  return;
}

