
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,undefined8 param_3,longlong **param_4,
                 longlong *param_5)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  byte bVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  undefined4 *puVar10;
  longlong *plVar11;
  short *psVar12;
  undefined8 uVar13;
  longlong lVar14;
  longlong lVar15;
  undefined uVar16;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar17;
  ulonglong uVar18;
  uint uVar19;
  undefined *puVar20;
  longlong *plVar21;
  uint *puVar22;
  uint *puVar23;
  ushort *puVar24;
  short sVar25;
  uint uVar26;
  undefined4 uVar27;
  byte *pbVar28;
  byte *pbVar29;
  uint uVar30;
  longlong *plVar31;
  uint *puVar32;
  bool bVar33;
  undefined8 uStack_3b0;
  undefined auStack_3a8 [32];
  undefined8 uStack_388;
  undefined4 uStack_380;
  longlong lStack_378;
  longlong lStack_370;
  undefined auStack_368 [24];
  undefined4 uStack_350;
  uint uStack_34c;
  uint uStack_348;
  undefined4 uStack_344;
  uint auStack_340 [6];
  undefined4 uStack_328;
  longlong *plStack_320;
  longlong *plStack_318;
  longlong *plStack_310;
  undefined8 uStack_308;
  longlong *plStack_300;
  undefined *puStack_2f8;
  int iStack_2f0;
  int iStack_2ec;
  int iStack_298;
  uint uStack_28c;
  int iStack_288;
  int iStack_284;
  uint auStack_280 [2];
  int iStack_278;
  uint uStack_274;
  int iStack_270;
  undefined4 uStack_260;
  undefined2 uStack_25c;
  undefined2 uStack_25a;
  undefined auStack_21c [4];
  undefined auStack_218 [4];
  undefined auStack_214 [4];
  undefined8 uStack_210;
  undefined8 uStack_208;
  longlong *plStack_1f0;
  undefined8 uStack_1e8;
  undefined auStack_1e0 [8];
  undefined auStack_1d8 [408];
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_368;
  plStack_320 = param_5;
  uVar13 = *(undefined8 *)param_1[0x5c];
  if (*_DAT_ != '\0') {
    uStack_3b0 = 0x100066;
    lVar9 = func_0x(0x1e9bb80);
    *(longlong *)(lVar9 + 0x48) = *(longlong *)(lVar9 + 0x48) + 1;
  }
  lVar9 = *(longlong *)(param_2 + 8);
  if (((*(uint *)(lVar9 + 0x40) & 0x48000) == 0x48000) && ((*(byte *)(param_2 + 0x14) & 8) != 0)) {
    uStack_308 = *(undefined8 **)
                  (*(longlong *)(param_2 + 0x40) + (ulonglong)*(uint *)(lVar9 + 0x38) * 8);
  }
  else {
    if ((*(byte *)(*(longlong *)(lVar9 + 0x48) + 0x2a) & 0x10) == 0) {
      lVar15 = *(longlong *)(param_2 + 0x18);
    }
    else {
      lVar15 = *(longlong *)(param_2 + 0x20);
    }
    uStack_308 = (undefined8 *)(*(longlong *)(lVar9 + 0x28) + lVar15);
    if ((*(uint *)(lVar9 + 0x40) >> 0xb & 1) != 0) {
      uStack_308 = (undefined8 *)*uStack_308;
    }
  }
  if (uStack_308 == (undefined8 *)0x0) {
    uStack_3b0 = 0x1000d1;
    puVar10 = (undefined4 *)(*_DAT_)();
    *puVar10 = 0x16;
    uStack_3b0 = 0x1000dd;
    (*_DAT_)();
  }
  else {
    uStack_308 = (undefined8 *)*uStack_308;
  }
  uStack_388 = (longlong **)0x0;
  if (*(int *)(param_1 + 0x39) == 0) {
    if ((param_1[0x2b] != 0) || (uVar27 = 0, param_1[0x2c] != 0)) {
      uVar27 = 1;
    }
    if ((*(byte *)((longlong)param_5 + 0x14) & 0x10) != 0) {
      uStack_388 = (longlong **)*param_5;
    }
    if (*(int *)(param_1 + 0x37) == 0) {
      if (uStack_388 == (longlong **)0x0) {
        bVar33 = param_1[0x38] == -1;
      }
      else {
        bVar33 = *(longlong *)((longlong)uStack_388 + 0xe0) == param_1[0x38];
      }
      if (bVar33) goto LAB_;
    }
    lStack_370 = param_1[0x2f];
    lStack_378 = param_1[0x2e];
    uStack_3b0 = 0x10017f;
    uStack_380 = uVar27;
    func_0x((longlong)param_1 + 0x1d4,uVar13,param_1[0x21]);
    *(undefined4 *)(param_1 + 0x37) = 0;
  }
  else {
    *(undefined4 *)((longlong)param_1 + 0x1d4) = 1;
  }
LAB_:
  uStack_260 = (undefined4)uStack_308;
  uStack_25c = uStack_308._4_2_;
  uStack_25a = uStack_308._6_2_;
  uStack_3b0 = 0x1001c3;
  uStack_388 = param_4;
  func_0x(param_1,&uStack_260,0,*(undefined4 *)((longlong)param_1 + 0x1d4));
  plVar21 = *param_4;
  if (plVar21 == (longlong *)0x0) {
    puVar20 = auStack_3a8;
    if (*(char *)(param_1[0x21] + 99) == '\x04') {
      uStack_3b0 = 0x1065f6;
      func_0x(0x1792570,uStack_308._4_2_,(ulonglong)uStack_308 & 0xffffffff,
                      (int)uStack_308._6_2_);
      puVar20 = auStack_3a8;
    }
    goto LAB_;
  }
  if (*(longlong *)(param_1[0x3c] + 0x58) != 0) {
    plVar21 = (longlong *)(*(longlong *)(param_1[0x3c] + 0x58) + 0x58);
    *plVar21 = *plVar21 + 1;
    plVar21 = *param_4;
  }
  uStack_3b0 = 0x1001f3;
  plStack_300 = (longlong *)func_0x(plVar21,1,0);
  plStack_310 = (longlong *)param_1[0x2f];
  plVar31 = param_1 + 0x32;
  lVar9 = param_1[0x2b];
  puVar1 = (undefined8 *)param_1[0x2d];
  plVar11 = (longlong *)param_1[0x2c];
  puStack_2f8 = (undefined *)param_1[0x2e];
  if ((lVar9 != 0) || (puVar1 != (undefined8 *)0x0)) {
    param_1[0x36] = (longlong)plStack_300;
    param_1[0x35] = (longlong)plVar21;
    plStack_1f0 = plVar31;
    if (lVar9 == 0) {
LAB_:
      if (puVar1 != (undefined8 *)0x0) {
        uStack_3b0 = 0x10027e;
        cVar4 = (**(code **)*puVar1)(puVar1,plVar31);
        if (cVar4 == '\0') goto LAB_;
      }
      goto LAB_;
    }
    uStack_3b0 = 0x10025c;
    (**(code **)(lVar9 + 8))(&plStack_1f0,lVar9,param_1 + 0x158);
    if ((*(char *)(param_1 + 0x158) != '\x03') && (*(char *)(param_1 + 0x159) != '\0'))
    goto LAB_;
LAB_:
    uStack_3b0 = 0x1002ec;
    func_0x(*param_4);
    uStack_3b0 = 0x1002f8;
    (**(code **)(*param_1 + 0x20))(param_1,*param_4);
    *param_4 = (longlong *)0x0;
    puVar20 = auStack_3a8;
    goto LAB_;
  }
LAB_:
  plVar3 = plStack_300;
  if (plVar11 != (longlong *)0x0) {
    plVar2 = *(longlong **)plVar11[1];
    param_1[0x36] = (longlong)plStack_300;
    param_1[0x35] = (longlong)plVar21;
    uStack_3b0 = 0x1002ab;
    (**(code **)(*plVar2 + 0x20))(plVar2,plVar31,&uStack_1e8);
    uStack_3b0 = 0x1002bc;
    iVar8 = (**(code **)(*plVar11 + 8))(plVar11,uStack_1e8);
    if (iVar8 == 0) goto LAB_;
  }
  if (puStack_2f8 != (undefined *)0x0) {
    param_1[0x36] = (longlong)plVar3;
    param_1[0x35] = (longlong)plVar21;
    uStack_3b0 = 0x1002e0;
    iVar8 = func_0x(plVar31,puStack_2f8,plStack_310);
    if (iVar8 == 0) goto LAB_;
  }
  plVar31 = plStack_320;
  if ((*(byte *)((longlong)plStack_320 + 0x14) & 0x10) == 0) {
    uStack_3b0 = 0x1065ce;
    (**(code **)(*plVar21 + 8))(plVar21);
    puVar20 = auStack_3a8;
    goto LAB_;
  }
  plVar21 = *param_4;
  uVar30 = 0;
  lVar9 = *plStack_320;
  plVar11 = plVar21;
  if ((*(uint *)(param_1 + 0x5d) & 0x800) == 0) {
    plVar11 = (longlong *)0x0;
  }
  plStack_300 = plVar21;
  if ((plVar11 != (longlong *)0x0) && (*(char *)(plVar11 + 199) != '\0')) {
    lVar15 = plVar11[200];
    lVar14 = plStack_320[3];
    uVar13 = *(undefined8 *)(lVar9 + 0x100);
    if (lVar15 == 0) {
      uStack_388 = (longlong **)0x0;
      uStack_3b0 = 0x100379;
      (*_DAT_)(1,0x1937c18,0x190c508,0x3b);
    }
    uStack_3b0 = 0x100387;
    func_0x(lVar15,uVar13,lVar14);
    puVar20 = auStack_3a8;
    goto LAB_;
  }
  if ((*(short *)(lVar9 + 0x3a) != 0) || (*(int *)(lVar9 + 0x50) != 0)) {
    uStack_3b0 = 0x10657a;
    func_0x(param_1,plVar21,plStack_320,&iStack_288);
    puVar20 = auStack_3a8;
    if (iStack_288 != 1) {
      lVar9 = *(longlong *)(param_1[0x21] + 0x70);
      puVar20 = auStack_3a8;
      if ((lVar9 != 0) && (puVar20 = auStack_3a8, (*(uint *)(param_1[0x21] + 0x120) & 0x100) != 0))
      {
        uStack_3b0 = 0x1065ab;
        func_0x(plVar21 + 6,lVar9);
        puVar20 = auStack_3a8;
        if (*(int *)(plVar21 + 0x6e) == 4) {
          uStack_3b0 = 0x1065c3;
          func_0x(plVar21 + 0x56,lVar9);
          puVar20 = auStack_3a8;
        }
      }
    }
    goto LAB_;
  }
  uStack_3b0 = 0x1003b3;
  psVar12 = (short *)func_0x(plVar21,1,0);
  lVar9 = *plVar31;
  plStack_318 = param_1 + 0x22;
  plStack_310 = param_1 + 0x14c;
  if ((*(byte *)(lVar9 + 0x30) & 1) == 0) {
LAB_:
    if (plStack_300 == (longlong *)0x0) {
      param_1[0x14d] = (longlong)psVar12;
      param_1[0x14e] = 0;
    }
    else {
      param_1[0x14d] = 0;
      param_1[0x14e] = (longlong)plStack_300;
      uStack_3b0 = 0x10152c;
      lVar15 = (**(code **)*plStack_300)();
      plStack_310[1] = lVar15;
    }
    plVar21 = plStack_320;
    uVar18 = 0;
    if (*psVar12 == 0) {
      *psVar12 = 0;
      puVar20 = auStack_3a8;
      if ((*(byte *)((longlong)plVar31 + 0x14) & 0x10) != 0) {
        uVar30 = *(uint *)(plVar31 + 2);
        uStack_348 = 0;
        lVar9 = plStack_320[1];
        puVar20 = auStack_3a8;
        uStack_34c = uVar30;
        if (uVar30 != 0) {
          do {
            if (*(byte *)(lVar9 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar9 + 0x40) * 4 + 0x106620) -
                           0xfb5210);
                    /* WARNING: Could not emulate address calculation at 0x0010159e */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,0);
              return;
            }
            uVar19 = *(uint *)(lVar9 + 0x40);
            if ((uVar19 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(lVar9 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar15 = plVar21[3];
              }
              else {
                lVar15 = plVar21[4];
              }
              *(undefined *)(lVar15 + *(longlong *)(lVar9 + 0x30)) = 3;
              uVar19 = *(uint *)(lVar9 + 0x40);
            }
            if ((uVar19 >> 9 & 1) != 0) {
              uStack_388 = (longlong **)CONCAT44(uStack_388._4_4_,uStack_344);
              uStack_3b0 = 0x103777;
              func_0x(plVar21,plStack_318,lVar9,0);
            }
            uStack_348 = (int)uVar18 + 1;
            uVar18 = (ulonglong)uStack_348;
            lVar9 = lVar9 + 0x50;
            puVar20 = auStack_3a8;
          } while (uStack_348 < uVar30);
        }
      }
    }
    else if (*(int *)(plStack_318[1] + 0x100) == 2) {
      uStack_34c = *(uint *)(lVar9 + 0x34);
      uVar17 = (ulonglong)uStack_34c + 0xf;
      if (uVar17 <= uStack_34c) {
        uVar17 = 0xffffffffffffff0;
      }
      uVar17 = uVar17 & 0xfffffffffffffff0;
      uStack_3b0 = 0x104136;
      func_0x();
      lVar9 = -uVar17;
      puStack_2f8 = auStack_368 + lVar9;
      puVar20 = auStack_3a8 + lVar9;
      if ((*(byte *)((longlong)plVar31 + 0x14) & 0x10) != 0) {
        uStack_28c = *(uint *)(plVar31 + 2);
        lVar15 = plVar31[1];
        uStack_348 = (uint)uVar18;
        puVar20 = auStack_3a8 + lVar9;
        if (uStack_28c != 0) {
          do {
            plVar21 = plStack_318;
            if (*(byte *)(lVar15 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar15 + 0x40) * 4 + 0x106974) -
                           0xfb5210);
                    /* WARNING: Could not emulate address calculation at 0x0010418f */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar30 = *(uint *)(lVar15 + 0x40);
            if ((uVar30 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(lVar15 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar14 = plVar31[3];
              }
              else {
                lVar14 = plVar31[4];
              }
              uVar16 = 0;
              if (uVar18 == 0) {
                uVar16 = 3;
              }
              *(undefined *)(lVar14 + *(longlong *)(lVar15 + 0x30)) = uVar16;
              uVar30 = *(uint *)(lVar15 + 0x40);
            }
            if ((uVar30 >> 9 & 1) != 0) {
              *(undefined4 *)((longlong)&uStack_388 + lVar9) = uStack_350;
              *(undefined8 *)(auStack_3a8 + lVar9 + -8) = 0x10650a;
              func_0x(plVar31,plVar21,lVar15,uVar18);
            }
            lVar15 = lVar15 + 0x50;
            uStack_348 = uStack_348 + 1;
            puVar20 = auStack_3a8 + lVar9;
          } while (uStack_348 < uStack_28c);
        }
      }
    }
    else {
      if (*psVar12 == -1) {
        *psVar12 = 1;
      }
      puVar20 = auStack_3a8;
      if ((*(byte *)((longlong)plVar31 + 0x14) & 0x10) != 0) {
        uVar30 = *(uint *)(plVar31 + 2);
        lVar9 = plVar31[1];
        puVar20 = auStack_3a8;
        if (uVar30 != 0) {
          do {
            if (*(byte *)(lVar9 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar9 + 0x40) * 4 + 0x1067cc) -
                           0xfb5210);
                    /* WARNING: Could not emulate address calculation at 0x001037fe */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,0);
              return;
            }
            uVar19 = *(uint *)(lVar9 + 0x40);
            if ((uVar19 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(lVar9 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar15 = plVar31[3];
              }
              else {
                lVar15 = plVar31[4];
              }
              *(undefined *)(lVar15 + *(longlong *)(lVar9 + 0x30)) = 3;
              uVar19 = *(uint *)(lVar9 + 0x40);
            }
            if ((uVar19 >> 9 & 1) != 0) {
              uStack_388 = (longlong **)CONCAT44(uStack_388._4_4_,uStack_328);
              uStack_3b0 = 0x1040f0;
              func_0x(plVar31,plStack_318,lVar9,0);
            }
            uVar19 = (int)uVar18 + 1;
            uVar18 = (ulonglong)uVar19;
            lVar9 = lVar9 + 0x50;
            puVar20 = auStack_3a8;
          } while (uVar19 < uVar30);
        }
      }
    }
    plVar21 = plStack_300;
    if (plStack_300 != (longlong *)0x0) {
      UNRECOVERED_JUMPTABLE = *(code **)(*(longlong *)plStack_310[2] + 8);
      *(undefined8 *)(puVar20 + -8) = 0x106557;
      (*UNRECOVERED_JUMPTABLE)();
      UNRECOVERED_JUMPTABLE = *(code **)(*plVar21 + 8);
      *(undefined8 *)(puVar20 + -8) = 0x106560;
      (*UNRECOVERED_JUMPTABLE)(plVar21);
      goto LAB_;
    }
  }
  else {
    if (*psVar12 == 0) {
      if ((**(byte **)(psVar12 + 4) & 0x10) == 0) {
        uVar19 = 0;
      }
      else {
        uVar19 = (uint)*(ushort *)(*(byte **)(psVar12 + 4) + *(uint *)(psVar12 + 8));
      }
    }
    else {
      uVar19 = (uint)(ushort)psVar12[1];
    }
    if (uVar19 < *(uint *)(lVar9 + 0x18)) goto LAB_;
    *psVar12 = 0;
    puVar22 = (uint *)0x0;
    puVar32 = (uint *)plVar31[1];
    uStack_34c = (uint)*(ushort *)(*plVar31 + 0x62);
    puVar20 = auStack_3a8;
    if (uStack_34c != 0) {
      do {
        cVar4 = *(char *)(puVar32 + 0x10);
        if (cVar4 == '\x01') {
          if ((*(byte *)((longlong)puVar32 + 6) & 0x10) == 0) {
            uVar19 = *(byte *)((ulonglong)(*(ushort *)(puVar32 + 1) - 1 >> 3) +
                               (ulonglong)*(uint *)(psVar12 + 8) + 2 + *(longlong *)(psVar12 + 4))
                     >> ((byte)(*(ushort *)(puVar32 + 1) - 1) & 7) & 1;
          }
          else {
            uStack_388 = (longlong **)&uStack_208;
            uStack_3b0 = 0x101335;
            func_0x(psVar12 + 1,puVar32,1,&uStack_274);
            uVar19 = uStack_274;
          }
          if (uVar19 == 0) goto LAB_;
LAB_:
          puVar23 = puVar22;
          if ((*(byte *)(*(longlong *)(puVar32 + 0x12) + 0x2a) & 0x10) == 0) {
            *(undefined *)(plVar31[3] + *(longlong *)(puVar32 + 0xc)) = 3;
          }
          else {
            *(undefined *)(plVar31[4] + *(longlong *)(puVar32 + 0xc)) = 3;
          }
        }
        else {
          if (cVar4 == '\x02') {
LAB_:
            uVar7 = *(ushort *)(puVar32 + 0xf);
            if ((*(byte *)((longlong)puVar32 + 6) & 0x10) == 0) {
LAB_:
              puVar22 = (uint *)((longlong)(int)*puVar32 + *(longlong *)(psVar12 + 4));
              uVar19 = (uint)uVar7;
            }
            else {
              uStack_388 = (longlong **)&iStack_270;
              uStack_3b0 = 0x1013cb;
              func_0x(psVar12 + 1,puVar32,0,(longlong)&uStack_208 + 4);
              if (iStack_270 != 0) goto LAB_;
              uVar19 = **(uint **)(puVar32 + 2);
              puVar22 = *(uint **)(puVar32 + 2) + 1;
              plVar31 = plStack_320;
              if ((uVar7 != 0) && (uVar19 != uVar7)) {
                uStack_388 = (longlong **)0x0;
                uStack_3b0 = 0x10140c;
                (*_DAT_)(1,0x1935ea8,0x19348a8,0x381);
                plVar31 = plStack_320;
              }
            }
            auStack_340[0] = uVar19;
            if ((*(byte *)(*(longlong *)(puVar32 + 0x12) + 0x2a) & 0x10) == 0) {
LAB_:
              lVar9 = plVar31[3];
            }
            else {
              lVar9 = plVar31[4];
            }
LAB_:
            *(undefined *)(lVar9 + *(longlong *)(puVar32 + 0xc)) = 0;
          }
          else {
            if (cVar4 == '\x03') {
              if ((*(byte *)((longlong)puVar32 + 6) & 0x10) == 0) {
                uVar19 = *(byte *)((ulonglong)(*(ushort *)(puVar32 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(psVar12 + 8) + 2 +
                                  *(longlong *)(psVar12 + 4)) >>
                         ((byte)(*(ushort *)(puVar32 + 1) - 1) & 7) & 1;
              }
              else {
                uStack_388 = (longlong **)&uStack_210;
                uStack_3b0 = 0x100c5a;
                func_0x(psVar12 + 1,puVar32,1,auStack_280);
                uVar19 = auStack_280[0];
              }
              if (uVar19 != 0) goto LAB_;
            }
            else if (cVar4 != '\x04') {
              if (cVar4 == '\b') {
                puVar23 = (uint *)0x0;
                puVar22 = (uint *)0x0;
                uVar7 = *(ushort *)(puVar32 + 0xf);
                iVar8 = puVar32[0x10] << 0xc;
                if ((*puVar32 & 0xc0000000) == 0x80000000) {
                  uStack_3b0 = 0x100bb7;
                  iVar8 = func_0x(psVar12 + 1);
                  if (iVar8 != 0) {
                    uStack_3b0 = 0x100bd3;
                    puVar22 = (uint *)func_0x(psVar12 + 0x15,puVar32,auStack_340,auStack_214
                                                     );
                    uVar19 = auStack_340[0];
                    goto LAB_;
                  }
                  auStack_340[0] = 0;
                  uVar7 = *(ushort *)(*(longlong *)(puVar32 + 0x12) + 0x2a);
LAB_:
                  plVar31 = plStack_320;
                  if ((uVar7 & 0x10) == 0) {
                    *(undefined *)(plStack_320[3] + *(longlong *)(puVar32 + 0xc)) = 3;
                  }
                  else {
                    *(undefined *)(plStack_320[4] + *(longlong *)(puVar32 + 0xc)) = 3;
                  }
                  goto LAB_;
                }
                if ((iVar8 < 0) || ((*(byte *)((longlong)puVar32 + 6) & 0x10) != 0)) {
                  uStack_388 = (longlong **)&iStack_2ec;
                  uStack_3b0 = 0x1004e8;
                  func_0x(psVar12 + 1,puVar32,iVar8 < 0,&iStack_2f0);
                  if ((iVar8 < 0) && (iStack_2f0 != 0)) {
                    auStack_340[0] = 0;
                    uVar19 = auStack_340[0];
                    goto LAB_;
                  }
                }
                else {
                  iStack_2f0 = 0;
                  iStack_2ec = 1;
                }
                if ((iStack_2ec == 0) && ((*(byte *)((longlong)puVar32 + 6) & 0x10) != 0)) {
                  puVar22 = *(uint **)(puVar32 + 2) + 1;
                  uVar19 = **(uint **)(puVar32 + 2);
                }
                else if ((int)*puVar32 < 0) {
                  if (*(int *)(psVar12 + 2) == 0) {
                    psVar12[1] = 0;
                    uVar19 = *(uint *)(psVar12 + 8);
                    uVar18 = (ulonglong)uVar19;
                    *(uint *)(psVar12 + 10) = uVar19;
                    pbVar28 = *(byte **)(psVar12 + 4);
                    bVar5 = *pbVar28;
                    if ((bVar5 & 0x10) != 0) {
                      uVar19 = uVar19 + (*(ushort *)(pbVar28 + uVar18) + 7 >> 3) + 2;
                      uVar18 = (ulonglong)uVar19;
                      *(uint *)(psVar12 + 10) = uVar19;
                      bVar5 = *pbVar28;
                    }
                    if ((bVar5 & 0x20) == 0) {
                      *(int *)(psVar12 + 2) = (int)uVar18;
                      psVar12[0xe] = 0;
                      *(uint *)(psVar12 + 0xc) = uVar19;
                    }
                    else {
                      puVar24 = (ushort *)(pbVar28 + uVar18);
                      uVar7 = *puVar24;
                      psVar12[0xe] = uVar7;
                      if (uVar7 == 0) {
                        uStack_3b0 = 0x10063a;
                        cVar4 = func_0x(0x1e973b0);
                        if (cVar4 != '\0') {
                          uStack_3b0 = 0x100643;
                          lVar9 = func_0x();
                          if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                            uStack_3b0 = 0x10065d;
                            cVar4 = func_0x(0x1e973b0);
                            if (cVar4 == '\0') {
                              uStack_3b0 = 0x100679;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              uStack_388 = (longlong **)0x0;
                              uStack_3b0 = 0x10069e;
                              (*_DAT_)(1,0x1788138,0x18a7e08,0x80f);
                            }
                          }
                        }
                        uStack_3b0 = 0x1006ad;
                        func_0x(*(undefined8 *)(psVar12 + 4),3);
                        uVar7 = psVar12[0xe];
                        uVar19 = *(uint *)(psVar12 + 10);
                      }
                      uVar19 = uVar19 + (uVar7 + 1) * 2;
                      *(uint *)(psVar12 + 0xc) = uVar19;
                      if (0x1f9e < uVar19) {
                        uStack_3b0 = 0x1006e1;
                        cVar4 = func_0x(0x1e973b0);
                        if (cVar4 != '\0') {
                          uStack_3b0 = 0x1006ea;
                          lVar9 = func_0x();
                          if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                            uStack_3b0 = 0x100704;
                            cVar4 = func_0x(0x1e973b0);
                            if (cVar4 == '\0') {
                              uStack_3b0 = 0x100720;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_388 = (longlong **)0x0;
                              uStack_3b0 = 0x100745;
                              (*_DAT_)(1,0x1788138,0x18a7e08,0x816);
                            }
                          }
                        }
                        uStack_3b0 = 0x100754;
                        func_0x(*(undefined8 *)(psVar12 + 4),4);
                        uVar7 = psVar12[0xe];
                        uVar19 = *(uint *)(psVar12 + 0xc);
                      }
                      uVar18 = (ulonglong)uVar7;
                      uVar7 = puVar24[uVar18];
                      *(uint *)(psVar12 + 2) = uVar7 & 0x7fff;
                      if ((uVar7 & 0x7fff) < uVar19) {
                        uStack_3b0 = 0x100786;
                        cVar4 = func_0x(0x1e973b0);
                        if (cVar4 != '\0') {
                          uStack_3b0 = 0x10078f;
                          lVar9 = func_0x();
                          if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                            uStack_3b0 = 0x1007a9;
                            cVar4 = func_0x(0x1e973b0);
                            if (cVar4 == '\0') {
                              uStack_3b0 = 0x1007c5;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_388 = (longlong **)0x0;
                              uStack_3b0 = 0x1007ea;
                              (*_DAT_)(1,0x1788138,0x18a7e08,0x81d);
                            }
                          }
                        }
                        uStack_3b0 = 0x1007f9;
                        func_0x(*(undefined8 *)(psVar12 + 4),4);
                        uVar18 = (ulonglong)(ushort)psVar12[0xe];
                      }
                      if ((short)puVar24[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
                        do {
                          lVar9 = (ulonglong)*(uint *)(psVar12 + 10) + *(longlong *)(psVar12 + 4);
                          if ((int)uVar18 == 1) {
                            uVar19 = *(uint *)(psVar12 + 0xc);
                            uVar26 = uVar19;
LAB_:
                            if ((*(ushort *)(lVar9 + uVar18 * 2) & 0x7fff) < uVar19)
                            goto LAB_;
                          }
                          else {
                            uVar26 = *(uint *)(psVar12 + 0xc);
                            uVar19 = *(ushort *)(lVar9 + -2 + uVar18 * 2) & 0x7fff;
                            if (uVar26 <= uVar19) goto LAB_;
LAB_:
                            uStack_3b0 = 0x10086c;
                            func_0x(*(longlong *)(psVar12 + 4),7);
                            uVar26 = *(uint *)(psVar12 + 0xc);
                          }
                          if ((uVar19 < uVar26) || (*(uint *)(psVar12 + 2) < uVar19))
                          goto LAB_;
                          if (*(ushort *)((ulonglong)uVar19 + *(longlong *)(psVar12 + 4)) == 5) {
                            psVar12[1] = psVar12[1] | 2;
                            psVar12[0xe] = psVar12[0xe] + -1;
                            psVar12[0x15] = (short)uVar19;
                            lVar9 = (ulonglong)(uVar19 & 0xffff) + *(longlong *)(psVar12 + 4);
                            uVar6 = psVar12[0x16] & 0xc7ff;
                            uVar7 = *(ushort *)(lVar9 + 2);
                            if ((uVar7 >> 0xe & 1) != 0) {
                              uVar6 = uVar7 & 0x3800 | uVar6;
                            }
                            psVar12[0x16] = uVar6;
                            psVar12[0x16] = (uVar6 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar6;
                            goto LAB_;
                          }
                          if (*(ushort *)((ulonglong)uVar19 + *(longlong *)(psVar12 + 4)) < 0x400)
                          goto LAB_;
                          psVar12[1] = psVar12[1] | 1;
                          uVar7 = psVar12[0xe] - 1;
                          psVar12[0xe] = uVar7;
                          if (uVar7 == 0) goto LAB_;
                          uVar18 = (ulonglong)uVar7;
                        } while ((short)puVar24[(ulonglong)(uVar7 - 1) + 1] < 0);
                        pbVar28 = *(byte **)(psVar12 + 4);
                      }
                      else {
LAB_:
                        pbVar28 = *(byte **)(psVar12 + 4);
                      }
                    }
                    if ((*pbVar28 & 0x40) == 0) {
                      *(undefined4 *)(psVar12 + 0x13) = 0;
                    }
                    else {
                      *(int *)(psVar12 + 0x13) = *(int *)(psVar12 + 2);
                      *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + 0xe;
                      uStack_3b0 = 0x100986;
                      uVar13 = func_0x(psVar12 + 1);
                      uStack_3b0 = 0x100995;
                      func_0x(uVar13,auStack_1e0);
                      uStack_3b0 = 0x1009a1;
                      iVar8 = func_0x(auStack_1e0);
                      *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + iVar8;
                    }
                    uVar19 = *(uint *)(psVar12 + 2);
                    if ((*(ulonglong *)(psVar12 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar12 + 0xf) <
                        (ulonglong)uVar19 + *(longlong *)(psVar12 + 4))) {
                      uStack_3b0 = 0x1009dc;
                      cVar4 = func_0x(0x1e973b0);
                      if (cVar4 != '\0') {
                        uStack_3b0 = 0x1009e5;
                        lVar9 = func_0x();
                        if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                          uStack_3b0 = 0x1009ff;
                          cVar4 = func_0x(0x1e973b0);
                          if (cVar4 == '\0') {
                            uStack_3b0 = 0x100a1b;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            uStack_388 = (longlong **)0x0;
                            uStack_3b0 = 0x100a41;
                            (*_DAT_)(1,0x1788138,0x18a7e08,0x877);
                          }
                        }
                      }
                      uStack_3b0 = 0x100a50;
                      func_0x(*(undefined8 *)(psVar12 + 4),0x12);
                      uVar19 = *(uint *)(psVar12 + 2);
                    }
                    if (0x3f3b < uVar19 - 1) {
                      uStack_3b0 = 0x100a6f;
                      cVar4 = func_0x(0x1e973b0);
                      if (cVar4 != '\0') {
                        uStack_3b0 = 0x100a78;
                        lVar9 = func_0x();
                        if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                          uStack_3b0 = 0x100a92;
                          cVar4 = func_0x(0x1e973b0);
                          if (cVar4 == '\0') {
                            uStack_3b0 = 0x100aae;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            uStack_388 = (longlong **)0x0;
                            uStack_3b0 = 0x100ad4;
                            (*_DAT_)(1,0x1788138,0x18a7e08,0x87c);
                          }
                        }
                      }
                      uStack_3b0 = 0x100ae3;
                      func_0x(*(undefined8 *)(psVar12 + 4),5);
                    }
                  }
LAB_:
                  sVar25 = -*(short *)puVar32;
                  if ((*(byte *)((longlong)puVar32 + 6) & 0x10) != 0) {
                    uStack_388 = (longlong **)&iStack_284;
                    uStack_3b0 = 0x100b14;
                    func_0x(psVar12 + 1,puVar32,0,auStack_218);
                    if (iStack_284 == 0) {
                      puVar22 = *(uint **)(puVar32 + 2) + 1;
                      uVar19 = **(uint **)(puVar32 + 2);
                      goto LAB_;
                    }
                  }
                  lVar9 = (longlong)sVar25;
                  if ((uint)(ushort)psVar12[0xe] < (uint)(int)sVar25) {
                    auStack_340[0] = 0;
                    puVar22 = *(uint **)(psVar12 + 4);
                    uVar19 = auStack_340[0];
                  }
                  else {
                    lVar15 = *(longlong *)(psVar12 + 4);
                    lVar14 = (ulonglong)*(uint *)(psVar12 + 10) + lVar15;
                    if (sVar25 == 1) {
                      uVar18 = (ulonglong)*(uint *)(psVar12 + 0xc);
                      uVar26 = *(ushort *)(lVar14 + lVar9 * 2) & 0x7fff;
LAB_:
                      if (uVar26 < (uint)uVar18) goto LAB_;
                    }
                    else {
                      uVar19 = *(ushort *)(lVar14 + -2 + lVar9 * 2) & 0x7fff;
                      uVar18 = (ulonglong)uVar19;
                      lVar15 = *(longlong *)(psVar12 + 4);
                      uVar26 = *(ushort *)(lVar14 + lVar9 * 2) & 0x7fff;
                      if (*(uint *)(psVar12 + 0xc) <= uVar19) goto LAB_;
LAB_:
                      uStack_3b0 = 0x100b95;
                      func_0x(lVar15,7);
                    }
                    puVar22 = (uint *)(uVar18 + *(longlong *)(psVar12 + 4));
                    uVar19 = uVar26 - (int)uVar18;
                  }
                }
                else if ((*(ushort *)((longlong)puVar32 + 6) & 8) == 0) {
                  if ((*(ushort *)((longlong)puVar32 + 6) & 0x10) != 0) {
                    uStack_388 = (longlong **)&iStack_298;
                    uStack_3b0 = 0x10055b;
                    func_0x(psVar12 + 1,puVar32,0,auStack_21c);
                    if (iStack_298 == 0) {
                      uVar19 = **(uint **)(puVar32 + 2);
                      puVar22 = *(uint **)(puVar32 + 2) + 1;
                      if ((uVar7 != 0) && (uVar19 != uVar7)) {
                        uStack_388 = (longlong **)0x0;
                        uStack_3b0 = 0x10059b;
                        (*_DAT_)(1,0x1935ea8,0x19348a8,0x381);
                      }
                      goto LAB_;
                    }
                  }
                  puVar22 = (uint *)((longlong)(int)*puVar32 + *(longlong *)(psVar12 + 4));
                  uVar19 = (uint)uVar7;
                }
                else {
                  uStack_3b0 = 0x1005c5;
                  puVar22 = (uint *)func_0x(psVar12 + 1,puVar32);
                  uVar19 = auStack_340[0];
                }
LAB_:
                auStack_340[0] = uVar19;
                uVar7 = *(ushort *)(*(longlong *)(puVar32 + 0x12) + 0x2a);
                puVar23 = puVar22;
                if (puVar22 == (uint *)0x0) goto LAB_;
                plVar31 = plStack_320;
                if ((uVar7 & 0x10) == 0) goto LAB_;
                lVar9 = plStack_320[4];
                goto LAB_;
              }
              uStack_388 = (longlong **)0x1504618;
              uStack_3b0 = 0x100482;
              (*_DAT_)(1,0x1909470,0x1935db0,0x27d);
              goto LAB_;
            }
            if (*(int *)(psVar12 + 2) == 0) {
              psVar12[1] = 0;
              uVar19 = *(uint *)(psVar12 + 8);
              uVar18 = (ulonglong)uVar19;
              *(uint *)(psVar12 + 10) = uVar19;
              pbVar28 = *(byte **)(psVar12 + 4);
              bVar5 = *pbVar28;
              pbVar29 = pbVar28;
              if ((bVar5 & 0x10) != 0) {
                uVar19 = uVar19 + (*(ushort *)(pbVar28 + uVar18) + 7 >> 3) + 2;
                uVar18 = (ulonglong)uVar19;
                *(uint *)(psVar12 + 10) = uVar19;
                bVar5 = *pbVar28;
                pbVar29 = *(byte **)(psVar12 + 4);
              }
              if ((bVar5 & 0x20) == 0) {
                *(int *)(psVar12 + 2) = (int)uVar18;
                psVar12[0xe] = 0;
                *(uint *)(psVar12 + 0xc) = uVar19;
              }
              else {
                puVar24 = (ushort *)(pbVar28 + uVar18);
                uVar7 = *puVar24;
                psVar12[0xe] = uVar7;
                if (uVar7 == 0) {
                  uStack_3b0 = 0x100d14;
                  cVar4 = func_0x(0x1e973b0);
                  if (cVar4 != '\0') {
                    uStack_3b0 = 0x100d1d;
                    lVar9 = func_0x();
                    if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                      uStack_3b0 = 0x100d37;
                      cVar4 = func_0x(0x1e973b0);
                      if (cVar4 == '\0') {
                        uStack_3b0 = 0x100d53;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        uStack_388 = (longlong **)0x0;
                        uStack_3b0 = 0x100d79;
                        (*_DAT_)(1,0x1788138,0x18a7e08,0x80f);
                      }
                    }
                  }
                  uStack_3b0 = 0x100d85;
                  func_0x(*(undefined8 *)(psVar12 + 4),3);
                  uVar7 = psVar12[0xe];
                  uVar19 = *(uint *)(psVar12 + 10);
                }
                uVar19 = uVar19 + (uVar7 + 1) * 2;
                *(uint *)(psVar12 + 0xc) = uVar19;
                if (0x1f9e < uVar19) {
                  uStack_3b0 = 0x100db9;
                  cVar4 = func_0x(0x1e973b0);
                  if (cVar4 != '\0') {
                    uStack_3b0 = 0x100dc2;
                    lVar9 = func_0x();
                    if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                      uStack_3b0 = 0x100ddc;
                      cVar4 = func_0x(0x1e973b0);
                      if (cVar4 == '\0') {
                        uStack_3b0 = 0x100df8;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_388 = (longlong **)0x0;
                        uStack_3b0 = 0x100e1e;
                        (*_DAT_)(1,0x1788138,0x18a7e08,0x816);
                      }
                    }
                  }
                  uStack_3b0 = 0x100e2d;
                  func_0x(*(undefined8 *)(psVar12 + 4),4);
                  uVar7 = psVar12[0xe];
                  uVar19 = *(uint *)(psVar12 + 0xc);
                }
                uVar18 = (ulonglong)uVar7;
                uVar7 = puVar24[uVar18];
                *(uint *)(psVar12 + 2) = uVar7 & 0x7fff;
                if ((uVar7 & 0x7fff) < uVar19) {
                  uStack_3b0 = 0x100e5f;
                  cVar4 = func_0x(0x1e973b0);
                  if (cVar4 != '\0') {
                    uStack_3b0 = 0x100e68;
                    lVar9 = func_0x();
                    if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                      uStack_3b0 = 0x100e82;
                      cVar4 = func_0x(0x1e973b0);
                      if (cVar4 == '\0') {
                        uStack_3b0 = 0x100e9e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_388 = (longlong **)0x0;
                        uStack_3b0 = 0x100ec4;
                        (*_DAT_)(1,0x1788138,0x18a7e08,0x81d);
                      }
                    }
                  }
                  uStack_3b0 = 0x100ed3;
                  func_0x(*(undefined8 *)(psVar12 + 4),4);
                  uVar18 = (ulonglong)(ushort)psVar12[0xe];
                }
                if ((short)puVar24[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
                  do {
                    lVar9 = *(longlong *)(psVar12 + 4);
                    if ((int)uVar18 == 1) {
                      uVar19 = *(uint *)(psVar12 + 0xc);
                      uVar26 = uVar19;
LAB_:
                      if ((*(ushort *)((ulonglong)*(uint *)(psVar12 + 10) + lVar9 + uVar18 * 2) &
                          0x7fff) < uVar19) goto LAB_;
                    }
                    else {
                      uVar26 = *(uint *)(psVar12 + 0xc);
                      uVar19 = *(ushort *)
                                ((ulonglong)*(uint *)(psVar12 + 10) + lVar9 + -2 + uVar18 * 2) &
                               0x7fff;
                      if (uVar26 <= uVar19) goto LAB_;
LAB_:
                      uStack_3b0 = 0x100f3c;
                      func_0x(lVar9,7);
                      uVar26 = *(uint *)(psVar12 + 0xc);
                      lVar9 = *(longlong *)(psVar12 + 4);
                    }
                    if ((uVar19 < uVar26) || (*(uint *)(psVar12 + 2) < uVar19)) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar19 + lVar9) == 5) {
                      psVar12[1] = psVar12[1] | 2;
                      psVar12[0xe] = psVar12[0xe] + -1;
                      psVar12[0x15] = (short)uVar19;
                      lVar9 = (ulonglong)(uVar19 & 0xffff) + *(longlong *)(psVar12 + 4);
                      uVar6 = psVar12[0x16] & 0xc7ff;
                      uVar7 = *(ushort *)(lVar9 + 2);
                      if ((uVar7 >> 0xe & 1) != 0) {
                        uVar6 = uVar7 & 0x3800 | uVar6;
                      }
                      psVar12[0x16] = uVar6;
                      psVar12[0x16] = (uVar6 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar6;
                      goto LAB_;
                    }
                    if (*(ushort *)((ulonglong)uVar19 + lVar9) < 0x400) goto LAB_;
                    psVar12[1] = psVar12[1] | 1;
                    uVar7 = psVar12[0xe] - 1;
                    psVar12[0xe] = uVar7;
                    if (uVar7 == 0) goto LAB_;
                    uVar18 = (ulonglong)uVar7;
                  } while ((short)puVar24[(ulonglong)(uVar7 - 1) + 1] < 0);
                  pbVar29 = *(byte **)(psVar12 + 4);
                }
                else {
LAB_:
                  pbVar29 = *(byte **)(psVar12 + 4);
                }
              }
              if ((*pbVar29 & 0x40) == 0) {
                *(undefined4 *)(psVar12 + 0x13) = 0;
              }
              else {
                *(int *)(psVar12 + 0x13) = *(int *)(psVar12 + 2);
                *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + 0xe;
                uStack_3b0 = 0x101057;
                uVar13 = func_0x(psVar12 + 1);
                uStack_3b0 = 0x101066;
                func_0x(uVar13,auStack_1d8);
                uStack_3b0 = 0x101072;
                iVar8 = func_0x(auStack_1d8);
                *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + iVar8;
                pbVar29 = *(byte **)(psVar12 + 4);
              }
              uVar19 = *(uint *)(psVar12 + 2);
              if ((*(byte **)(psVar12 + 0xf) != (byte *)0x0) &&
                 (*(byte **)(psVar12 + 0xf) < pbVar29 + uVar19)) {
                uStack_3b0 = 0x1010b0;
                cVar4 = func_0x(0x1e973b0);
                if (cVar4 != '\0') {
                  uStack_3b0 = 0x1010b9;
                  lVar9 = func_0x();
                  if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                    uStack_3b0 = 0x1010d3;
                    cVar4 = func_0x(0x1e973b0);
                    if (cVar4 == '\0') {
                      uStack_3b0 = 0x1010ef;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      uStack_388 = (longlong **)0x0;
                      uStack_3b0 = 0x101115;
                      (*_DAT_)(1,0x1788138,0x18a7e08,0x877);
                    }
                  }
                }
                uStack_3b0 = 0x101124;
                func_0x(*(undefined8 *)(psVar12 + 4),0x12);
                uVar19 = *(uint *)(psVar12 + 2);
              }
              if (0x3f3b < uVar19 - 1) {
                uStack_3b0 = 0x101143;
                cVar4 = func_0x(0x1e973b0);
                if (cVar4 != '\0') {
                  uStack_3b0 = 0x10114c;
                  lVar9 = func_0x();
                  if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                    uStack_3b0 = 0x101166;
                    cVar4 = func_0x(0x1e973b0);
                    if (cVar4 == '\0') {
                      uStack_3b0 = 0x101182;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      uStack_388 = (longlong **)0x0;
                      uStack_3b0 = 0x1011a8;
                      (*_DAT_)(1,0x1788138,0x18a7e08,0x87c);
                    }
                  }
                }
                uStack_3b0 = 0x1011b7;
                func_0x(*(undefined8 *)(psVar12 + 4),5);
              }
            }
LAB_:
            sVar25 = -*(short *)puVar32;
            if ((*(byte *)((longlong)puVar32 + 6) & 0x10) == 0) {
LAB_:
              lVar9 = (longlong)sVar25;
              if ((uint)(ushort)psVar12[0xe] < (uint)(int)sVar25) {
                auStack_340[0] = 0;
                puVar22 = *(uint **)(psVar12 + 4);
              }
              else {
                lVar15 = *(longlong *)(psVar12 + 4);
                lVar14 = (ulonglong)*(uint *)(psVar12 + 10) + lVar15;
                if (sVar25 == 1) {
                  uVar18 = (ulonglong)*(uint *)(psVar12 + 0xc);
                  uVar26 = *(ushort *)(lVar14 + lVar9 * 2) & 0x7fff;
LAB_:
                  if (uVar26 < (uint)uVar18) goto LAB_;
                }
                else {
                  uVar19 = *(ushort *)(lVar14 + -2 + lVar9 * 2) & 0x7fff;
                  uVar18 = (ulonglong)uVar19;
                  lVar15 = *(longlong *)(psVar12 + 4);
                  uVar26 = *(ushort *)(lVar14 + lVar9 * 2) & 0x7fff;
                  if (*(uint *)(psVar12 + 0xc) <= uVar19) goto LAB_;
LAB_:
                  uStack_3b0 = 0x101266;
                  func_0x(lVar15,7);
                }
                auStack_340[0] = uVar26 - (int)uVar18;
                puVar22 = (uint *)(uVar18 + *(longlong *)(psVar12 + 4));
              }
            }
            else {
              uStack_388 = (longlong **)&iStack_278;
              uStack_3b0 = 0x1011e8;
              func_0x(psVar12 + 1,puVar32,0,(longlong)&uStack_210 + 4);
              if (iStack_278 != 0) goto LAB_;
              auStack_340[0] = **(uint **)(puVar32 + 2);
              puVar22 = *(uint **)(puVar32 + 2) + 1;
            }
            if (((puVar32[0x10] & 0x2000) != 0) && (auStack_340[0] == 0)) {
              auStack_340[0] = 4;
              puVar22 = (uint *)0x152e4dc;
            }
            if ((*(byte *)(*(longlong *)(puVar32 + 0x12) + 0x2a) & 0x10) == 0) {
              lVar9 = plVar31[3];
            }
            else {
              lVar9 = plVar31[4];
            }
            *(undefined *)(lVar9 + *(longlong *)(puVar32 + 0xc)) = 0;
            if ((1 << (**(byte **)(psVar12 + 4) & 0xe) & 0x440U) != 0) {
              uStack_3b0 = 0x1012d7;
              iVar8 = func_0x(puVar32);
              if (iVar8 != 0) goto LAB_;
            }
            if (*(ushort *)(puVar32 + 0xf) < auStack_340[0]) {
              uStack_3b0 = 0x101303;
              (*_DAT_)(6,0x52,0x16,0x91);
            }
          }
LAB_:
          uVar18 = (ulonglong)auStack_340[0];
          lVar9 = *(longlong *)(puVar32 + 0x12);
          if ((puVar32[0x10] & 0x800) == 0) {
            if ((*(byte *)(lVar9 + 0x2a) & 0x10) == 0) {
              lVar9 = plVar31[3];
            }
            else {
              lVar9 = plVar31[4];
            }
            uStack_3b0 = 0x101470;
            func_0x(lVar9 + *(longlong *)(puVar32 + 10),puVar22);
          }
          else {
            uVar7 = *(ushort *)(lVar9 + 0x2a) & 0x10;
            if (*(int *)(lVar9 + 0x10) == 10) {
              if (uVar7 == 0) {
                lVar9 = plVar31[3];
              }
              else {
                lVar9 = plVar31[4];
              }
              *(uint **)(lVar9 + *(longlong *)(puVar32 + 10)) = puVar22;
            }
            else {
              if (uVar7 == 0) {
                lVar9 = plVar31[3];
              }
              else {
                lVar9 = plVar31[4];
              }
              uStack_3b0 = 0x1014a5;
              func_0x(*(undefined8 *)(*(longlong *)(puVar32 + 10) + lVar9),puVar22);
            }
          }
          puVar23 = puVar22;
          if ((puVar32[0x10] & 0x100) != 0) {
            if ((*(byte *)(*(longlong *)(puVar32 + 0x12) + 0x2a) & 0x10) == 0) {
              lVar9 = plVar31[3];
            }
            else {
              lVar9 = plVar31[4];
            }
            *(ulonglong *)(lVar9 + *(longlong *)(*(longlong *)(puVar32 + 0x12) + 0x18)) = uVar18;
          }
        }
LAB_:
        uVar30 = uVar30 + 1;
        puVar32 = puVar32 + 0x14;
        puVar20 = auStack_3a8;
        puVar22 = puVar23;
      } while (uVar30 < uStack_34c);
    }
  }
  plVar21 = plStack_300;
  UNRECOVERED_JUMPTABLE = *(code **)(*plStack_300 + 8);
  *(undefined8 *)(puVar20 + -8) = 0x101511;
  (*UNRECOVERED_JUMPTABLE)(plVar21);
LAB_:
  uVar18 = uStack_40 ^ (ulonglong)auStack_368;
  *(undefined8 *)(puVar20 + -8) = 0x106605;
  func_0x(uVar18);
  return;
}

