
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,int param_2,int param_3,undefined8 *param_4,undefined2 *param_5,
                 undefined4 *param_6)

{
  ulonglong uVar1;
  byte bVar2;
  longlong lVar3;
  ulonglong *puVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  int iVar8;
  longlong unaff_GS_OFFSET;
  
  lVar7 = *(longlong *)(param_1 + 0x40);
  *param_4 = 0;
  *param_5 = 0;
  *param_6 = 0;
  if (param_2 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar3 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x18);
  puVar4 = *(ulonglong **)(lVar3 + 8);
  if (param_3 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)puVar4 == 0) {
    LOCK();
    uVar1 = *puVar4;
    if (uVar1 == 0) {
      *puVar4 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (uVar1 == 0) {
      lVar5 = *(longlong *)(param_1 + 0x38);
      bVar2 = *(byte *)(lVar5 + 0x37);
      if (((bVar2 & 1) != 0) || ((bVar2 & 2) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)(lVar5 + 0x38) & 1) == 0) {
        if ((bVar2 & 4) == 0) {
          if ((*(byte *)(lVar5 + 0x38) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          lVar6 = *(longlong *)(lVar3 + 0x40);
          if (lVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(byte *)(lVar6 + 0x37) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(char *)(lVar6 + 0x36) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(byte *)(lVar5 + 0x38) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (lVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (lVar6 != lVar5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(longlong *)(lVar3 + 0x38) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
        if (*(longlong *)(lVar3 + 0x30) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
      if (lVar7 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      iVar8 = 0;
      do {
        if (3 < iVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        lVar7 = *(longlong *)(lVar3 + 0x10 + (longlong)iVar8 * 8);
        if (lVar7 == 0) {
          lVar7 = 0;
        }
        else {
          if ((*(byte *)(lVar7 + 0x37) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(char *)(lVar7 + 0x36) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
        if (lVar7 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        iVar8 = iVar8 + 1;
      } while( true );
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

