
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  char cVar1;
  ushort uVar2;
  longlong lVar3;
  longlong lVar4;
  int iVar5;
  longlong unaff_GS_OFFSET;
  undefined auStack_438 [96];
  undefined uStack_3d8;
  undefined8 uStack_3d0;
  undefined8 uStack_3c8;
  longlong lStack_3b8;
  longlong lStack_3b0;
  longlong lStack_3a0;
  undefined8 uStack_398;
  undefined2 uStack_390;
  longlong lStack_348;
  longlong lStack_2b0;
  undefined8 uStack_1c0;
  undefined8 uStack_48;
  undefined2 uStack_40;
  ulonglong uStack_38;
  
  uStack_1c0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_438;
  if ((*(uint *)(param_1 + 0x10) & 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(param_1 + 0x10) >> 0xd & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x158) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lStack_3b0 = param_1;
  lStack_2b0 = param_1;
  if (2 < *(int *)(param_1 + 0x158) - 2U) {
    lVar3 = *(longlong *)(*(longlong *)(param_1 + 0x28) + 8);
    lVar4 = *(longlong *)(lVar3 + 0x30);
    *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) & 0xfffffeff;
    if ((*(uint *)(param_1 + 0x10) & 0x10080) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lStack_3a0 = lVar4;
    lStack_348 = lVar3;
    iVar5 = func_0x(param_1,2);
    if (iVar5 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((~*(byte *)(param_1 + 0x34) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(char *)(lVar4 + 0x2050) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_48 = 0;
    uStack_40 = 0;
    if ((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar4 = *(longlong *)(param_1 + 0x20);
    uVar2 = *(ushort *)(lVar4 + 4);
    if ((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(short *)(lVar4 + 0x24) != 0) {
      cVar1 = *(char *)(lVar4 + 1);
      if (cVar1 == '\v') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((cVar1 == '\b') || (cVar1 == '\t')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    uStack_398 = *(undefined8 *)(lVar4 + 0x28);
    uStack_390 = *(undefined2 *)(lVar4 + 0x30);
    uStack_3d0 = *(undefined8 *)(*(longlong *)(param_1 + 0xf8) + 0x18);
    uStack_3c8 = *(undefined8 *)(param_1 + 0x150);
    lStack_3b8 = *(longlong *)(lVar3 + 0x30);
    uStack_3d8 = *(undefined *)(lStack_3b8 + 0x1cde);
    if (*(char *)(lStack_3b8 + 0x2050) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(*(undefined8 *)(param_1 + 0x148),param_1 + 0x48);
    *(undefined4 *)(param_1 + 0x158) = 1;
    if ((uVar2 & 0x2000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((DAT_ & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar3 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar3 != 0) && (**(longlong **)(lVar3 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((DAT_ & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar3 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar3 != 0) && (**(longlong **)(lVar3 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(param_1 + 0x158) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_438);
  return;
}

