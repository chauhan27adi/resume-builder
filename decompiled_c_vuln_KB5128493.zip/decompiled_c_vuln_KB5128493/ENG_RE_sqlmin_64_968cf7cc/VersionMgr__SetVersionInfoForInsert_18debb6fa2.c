
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,longlong *param_2,char param_3,char param_4,char param_5)

{
  longlong *plVar1;
  longlong lVar2;
  char cVar3;
  byte bVar4;
  ushort uVar5;
  undefined4 uVar6;
  ulonglong *puVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong *puVar10;
  ushort uVar11;
  uint uVar12;
  uint uVar13;
  ulonglong uVar14;
  byte *pbVar15;
  int iVar16;
  ushort *puVar17;
  longlong unaff_GS_OFFSET;
  undefined4 uStackX_8;
  undefined2 uStackX_c;
  undefined8 uStackX_10;
  longlong lStack_48;
  undefined8 uStack_40;
  
  lVar8 = param_2[0x1a];
  puVar10 = (ulonglong *)0x0;
  iVar16 = 0;
  if (((param_4 != '\0') || (lVar8 == 0)) ||
     ((*(int *)(lVar8 + 0x78) < 1 && (*(int *)(lVar8 + 0x74) < 1)))) {
    cVar3 = (**(code **)(*param_2 + 0x88))(param_2);
    if (cVar3 == '\0') {
      uVar6 = (**(code **)(*param_2 + 0x50))(param_2);
      uVar5 = 0xfffc;
      uStackX_10 = CONCAT44(0xfffc0003,uVar6);
    }
    else {
      uStackX_10 = 0;
      uVar5 = 0;
    }
    goto LAB_;
  }
  LOCK();
  plVar1 = (longlong *)(lVar8 + 0x128);
  lStack_48 = *plVar1;
  *plVar1 = *plVar1 + 1;
  UNLOCK();
  lStack_48 = lStack_48 + 1;
  cVar3 = (**(code **)(*param_2 + 0x88))(param_2);
  if (cVar3 != '\0') {
    uVar5 = 0xfffe;
    uStackX_10 = CONCAT26(0xfffe,(int6)lStack_48);
    goto LAB_;
  }
  if (*param_1 == 0) {
    if (*(int *)(param_1 + 2) == 0) {
      pbVar15 = *(byte **)(param_1 + 4);
      uVar12 = *(uint *)(param_1 + 8);
      uVar14 = (ulonglong)uVar12;
      param_1[1] = 0;
      *(uint *)(param_1 + 10) = uVar12;
      bVar4 = *pbVar15;
      if ((bVar4 & 0x10) != 0) {
        uVar12 = uVar12 + 2 + (*(ushort *)(pbVar15 + uVar14) + 7 >> 3);
        uVar14 = (ulonglong)uVar12;
        *(uint *)(param_1 + 10) = uVar12;
        bVar4 = *pbVar15;
      }
      if ((bVar4 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar14;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar14;
      }
      else {
        puVar17 = (ushort *)(pbVar15 + uVar14);
        uVar5 = *puVar17;
        param_1[0xe] = uVar5;
        if (uVar5 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xeb5918,0xfd55e8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar14 = (ulonglong)*(uint *)(param_1 + 10);
          uVar5 = param_1[0xe];
        }
        uVar12 = (int)uVar14 + (uVar5 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar12;
        if (0x1f9e < uVar12) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0 &&
              ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
               (*(char *)(lVar8 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xeb5918,0xfd55e8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar5 = param_1[0xe];
          uVar12 = *(uint *)(param_1 + 0xc);
        }
        uVar9 = (ulonglong)uVar5;
        uVar13 = puVar17[uVar9] & 0x7fff;
        *(uint *)(param_1 + 2) = uVar13;
        if (uVar13 < uVar12) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xeb5918,0xfd55e8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar9 = (ulonglong)(ushort)param_1[0xe];
          uVar13 = *(uint *)(param_1 + 2);
        }
        uVar14 = (ulonglong)uVar13;
        if ((short)puVar17[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
          pbVar15 = *(byte **)(param_1 + 4);
          do {
            if ((int)uVar9 == 1) {
              uVar12 = *(uint *)(param_1 + 0xc);
              uVar13 = uVar12;
LAB_:
              if ((*(ushort *)(pbVar15 + uVar9 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff) <
                  uVar12) goto LAB_;
            }
            else {
              uVar13 = *(uint *)(param_1 + 0xc);
              uVar12 = *(ushort *)(pbVar15 + uVar9 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
                       0x7fff;
              if (uVar13 <= uVar12) goto LAB_;
LAB_:
              func_0x(pbVar15,7);
              uVar13 = *(uint *)(param_1 + 0xc);
            }
            if ((uVar12 < uVar13) ||
               (uVar14 = (ulonglong)*(uint *)(param_1 + 2), *(uint *)(param_1 + 2) < uVar12))
            goto LAB_;
            pbVar15 = *(byte **)(param_1 + 4);
            if (*(ushort *)(pbVar15 + uVar12) == 5) {
              param_1[1] = param_1[1] | 2;
              param_1[0xe] = param_1[0xe] + -1;
              param_1[0x15] = (short)uVar12;
              lVar8 = (ulonglong)(uVar12 & 0xffff) + *(longlong *)(param_1 + 4);
              uVar5 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar8 + 2) >> 0xe & 1) != 0) {
                uVar5 = *(ushort *)(lVar8 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar5;
              param_1[0x16] = (uVar5 ^ *(ushort *)(lVar8 + 2)) & 0x7ff ^ uVar5;
              uVar14 = (ulonglong)*(uint *)(param_1 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar15 + uVar12) < 0x400) goto LAB_;
            param_1[1] = param_1[1] | 1;
            uVar5 = param_1[0xe] - 1;
            param_1[0xe] = uVar5;
            if (uVar5 == 0) goto LAB_;
            uVar9 = (ulonglong)uVar5;
          } while ((short)puVar17[(ulonglong)(uVar5 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar15 = *(byte **)(param_1 + 4);
        }
      }
      if ((*pbVar15 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar14;
        *(int *)(param_1 + 2) = (int)uVar14 + 0xe;
        puVar7 = (ulonglong *)func_0x(param_1 + 1);
        uVar11 = (ushort)(*puVar7 >> 0x30);
        uVar5 = uVar11;
        if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
          uVar5 = uVar11 & 0xdfff;
          if ((uVar11 >> 0xe & 1) != 0) {
            uVar5 = uVar11 | 0x2000;
          }
        }
        if (uVar5 == 0xfffc) {
          iVar16 = (int)((*puVar7 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar16;
        uVar14 = (ulonglong)*(uint *)(param_1 + 2);
      }
      iVar16 = (int)uVar14;
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar14 + *(longlong *)(param_1 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar8 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar8 != 0 &&
             (lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0)) &&
            (*(char *)(lVar8 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xeb5918,0xfd55e8,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        iVar16 = *(int *)(param_1 + 2);
      }
      if (0x3f3b < iVar16 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar8 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar8 != 0 &&
            ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0xeb5918,0xfd55e8,0x87c,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
      }
    }
LAB_:
    uVar12 = *(uint *)(param_1 + 2);
    if ((uVar12 < 9) &&
       (((**(byte **)(param_1 + 4) & 0xe) == 0 || ((**(byte **)(param_1 + 4) & 0xe) == 0xc)))) {
      uVar12 = 9;
    }
  }
  else {
    uVar12 = *(uint *)(param_1 + 2);
    if (uVar12 == 0) {
      func_0x(param_1 + 1);
      uVar12 = *(uint *)(param_1 + 2);
    }
    if ((uVar12 < 9) &&
       (((**(byte **)(param_1 + 4) & 0x1c) == 0 || ((**(byte **)(param_1 + 4) & 0x1c) == 0xc)))) {
      uVar12 = 9;
    }
  }
  if (uVar12 < 0x1f74) {
    if (param_5 == '\0') {
      uVar6 = (**(code **)(*param_2 + 0x50))(param_2);
      uVar5 = 0xfffc;
      uStackX_10 = CONCAT44(0xfffc0103,uVar6);
      goto LAB_;
    }
LAB_:
    *(longlong *)(param_2[6] + 0x1a8) = *(longlong *)(param_2[6] + 0x1a8) + 1;
  }
  else if (param_5 != '\0') goto LAB_;
  uStack_40 = 0;
  uStackX_8 = 0;
  uStackX_c = 0;
  cVar3 = (**(code **)(*param_2 + 0x10))(param_2);
  if (cVar3 == '\0') {
    (*_DAT_)(1,0x1085b00,0x103c128,0x3f6,0);
  }
  lVar8 = param_2[6];
  lVar2 = *(longlong *)(lVar8 + 0x7c0);
  if (*(char *)(*(longlong *)(lVar2 + 8) + 0x2050) != '\0') {
    (*_DAT_)(1,0x10836b8,0x103c058,0x13e,0);
  }
  func_0x(*(undefined8 *)(lVar2 + 0x10),param_2,0,param_1,0,lStack_48,&uStackX_8,&uStack_40,
                  &uStackX_10);
  uVar5 = uStackX_10._6_2_;
  if ((((uint)(int)(short)uStackX_10._6_2_ >> 1 ^ (int)(short)uStackX_10._6_2_) & 0x2000) != 0) {
    uVar5 = uStackX_10._6_2_ & 0xdfff;
    if ((uStackX_10._6_2_ >> 0xe & 1) != 0) {
      uVar5 = uStackX_10._6_2_ | 0x2000;
    }
  }
  if (uVar5 == 0xfffc) {
    (*_DAT_)(1,0x1060120,0x1039860,0x502,0);
  }
  plVar1 = (longlong *)(lVar8 + 0x68);
  *plVar1 = *plVar1 + 1;
  uVar5 = uStackX_10._6_2_ | 0x1000;
  uStackX_10 = uStackX_10 | 0x1000000080000000;
LAB_:
  if (param_3 != '\0') {
    if ((uVar5 & 0x4000) == 0) {
      uVar5 = uVar5 | 0x2000;
    }
    else {
      uVar5 = uVar5 & 0xdfff;
    }
    uStackX_10 = CONCAT26(uVar5,(undefined6)uStackX_10);
  }
  if ((*(byte *)(param_2 + 0x43) & 4) == 0) {
    param_2 = param_2 + 5;
  }
  else {
    lVar8 = (**(code **)(*param_2 + 0x1e8))(param_2);
    param_2 = (longlong *)(lVar8 + 0x28);
  }
  if (*param_1 == 0) {
    func_0x();
  }
  else {
    func_0x(param_1 + 1,param_2);
  }
  uVar12 = (uint)(short)uStackX_10._6_2_;
  uVar14 = (ulonglong)uVar12;
  uVar13 = uVar12 >> 0xe & 1;
  uVar12 = uVar12 >> 0xd & 1;
  uVar5 = uStackX_10._6_2_;
  if (uVar12 != uVar13) {
    uVar5 = uStackX_10._6_2_ & 0xdfff;
    if ((uStackX_10 & 0x4000000000000000) != 0) {
      uVar5 = uStackX_10._6_2_ | 0x2000;
    }
  }
  if (uVar5 == 0xfffc) {
    uVar5 = uStackX_10._6_2_;
    if (uVar12 != uVar13) {
      uVar5 = uStackX_10._6_2_ & 0xdfff;
      if ((uStackX_10 & 0x4000000000000000) != 0) {
        uVar5 = uStackX_10._6_2_ | 0x2000;
      }
    }
    if (uVar5 == 0xfffc) {
      uVar5 = uStackX_10._4_2_ & 0x1f;
    }
    else {
      (*_DAT_)(1,0x103fcf8,0x1039860,0x4ba,0);
      uVar14 = uStackX_10 >> 0x30;
      uVar5 = uStackX_10._4_2_;
    }
    uVar11 = (ushort)uVar14;
    if (uVar5 == 3) {
      uVar5 = uVar11;
      if (((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) &&
         (uVar5 = uVar11 & 0xdfff, (uVar14 & 0x4000) != 0)) {
        uVar5 = uVar11 | 0x2000;
      }
      if ((uVar5 == 0xfffc) && (uStackX_10._4_2_ >> 5 == 8)) {
        if (*param_1 == 0) {
          func_0x();
          return;
        }
        func_0x(param_1 + 1,&uStackX_10,&lStack_48);
        return;
      }
    }
  }
  if (*param_1 == 0) {
    func_0x(param_1 + 1,&uStackX_10);
  }
  else {
    if (*(int *)(param_1 + 2) == 0) {
      func_0x(param_1 + 1);
    }
    func_0x(param_1 + 1);
    if ((**(byte **)(param_1 + 4) & 2) != 0) {
      puVar10 = (ulonglong *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 0x18));
    }
    *puVar10 = uStackX_10;
    *(undefined4 *)(param_1 + 2) = 0;
    func_0x(param_1 + 1);
  }
  return;
}

