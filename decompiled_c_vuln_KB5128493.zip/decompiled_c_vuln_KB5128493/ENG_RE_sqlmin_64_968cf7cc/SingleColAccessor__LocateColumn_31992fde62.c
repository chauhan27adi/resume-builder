
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x010a2717) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 *param_2,ulonglong *param_3,longlong *param_4)

{
  ushort uVar1;
  uint uVar2;
  uint uVar3;
  short *psVar4;
  uint *puVar5;
  byte *pbVar6;
  longlong *plVar7;
  code *pcVar8;
  char cVar9;
  longlong lVar10;
  uint uVar11;
  undefined auStack_118 [32];
  uint *puStack_f8;
  uint uStack_f0;
  ulonglong *puStack_e8;
  uint uStack_e0;
  longlong *plStack_d8;
  uint auStack_d0 [30];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_118;
  plStack_d8 = param_4;
  cVar9 = (**(code **)*param_2)(param_2);
  if (cVar9 != '\0') {
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  if ((*(uint *)(param_1 + 0x24) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *param_3 = 0;
  psVar4 = (short *)param_2[4];
  puVar5 = *(uint **)(param_1 + 0x50);
  uVar1 = *(ushort *)(param_1 + 0x58);
  if (*psVar4 != 0) {
    puStack_f8 = auStack_d0;
    auStack_d0[0] = 0;
    lVar10 = func_0x(psVar4 + 1,param_1 + 0x60);
    if ((((*psVar4 != 0) && (plVar7 = *(longlong **)(psVar4 + 8), plVar7 != (longlong *)0x0)) &&
        (*plVar7 != 0)) && (((*(byte *)(param_1 + 0x66) & 8) == 0 && ((auStack_d0[0] & 1) == 0)))) {
      if ((lVar10 == 0) || (lVar10 == 0x245cc84)) {
        *(undefined4 *)param_3 = 0;
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
      }
      uStack_e0 = auStack_d0[0];
      uStack_f0 = (uint)uVar1;
      puStack_f8 = puVar5;
      puStack_e8 = param_3;
      func_0x(plVar7,param_1 + 0x60,lVar10,*(undefined4 *)param_3);
    }
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  uVar2 = *(uint *)(param_1 + 0x60);
  if ((uVar2 & 0xc0000000) == 0x80000000) {
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  if (*(int *)(param_1 + 0x74) == 0) {
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  pbVar6 = *(byte **)(psVar4 + 4);
  if ((*pbVar6 & 0x10) == 0) {
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  uVar3 = *(uint *)(psVar4 + 8);
  if ((int)uVar3 <= (int)uVar2) {
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  if ((uint)*(ushort *)(pbVar6 + uVar3) < (uint)*(ushort *)(param_1 + 100)) {
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  if ((*(int *)(param_1 + 0x74) != 0) &&
     (uVar11 = *(ushort *)(param_1 + 100) - 1,
     (pbVar6[(ulonglong)(uVar11 >> 3) + (ulonglong)uVar3 + 2] >> ((byte)uVar11 & 7) & 1) != 0)) {
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  if ((int)uVar2 < 0) {
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  if ((*(ushort *)(param_1 + 0x66) & 8) == 0) {
    if ((*(ushort *)(param_1 + 0x66) & 0x10) == 0) {
      *(uint *)param_3 = (uint)*(ushort *)(param_1 + 0x70);
      *plStack_d8 = (longlong)*(int *)(param_1 + 0x60) + *(longlong *)(psVar4 + 4);
      if ((ulonglong)*(ushort *)(param_1 + 0x70) < *param_3) {
        (*_DAT_)(6,0x52,0x16,0x9b);
      }
      pcVar8 = (code *)swi(3);
      (*pcVar8)();
      return;
    }
    pcVar8 = (code *)swi(3);
    (*pcVar8)();
    return;
  }
  pcVar8 = (code *)swi(3);
  (*pcVar8)();
  return;
}

