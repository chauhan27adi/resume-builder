
void FUN_(longlong param_1)

{
  undefined4 uVar1;
  byte *pbVar2;
  code *pcVar3;
  
  pbVar2 = *(byte **)(param_1 + 6);
  if ((*pbVar2 & 0x40) != 0) {
    if (*(int *)(param_1 + 2) == 0) {
      pcVar3 = (code *)swi(3);
      (*pcVar3)();
      return;
    }
    *pbVar2 = *pbVar2 & 0xbf;
    uVar1 = *(undefined4 *)(param_1 + 0x24);
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 2) = uVar1;
  }
  return;
}

