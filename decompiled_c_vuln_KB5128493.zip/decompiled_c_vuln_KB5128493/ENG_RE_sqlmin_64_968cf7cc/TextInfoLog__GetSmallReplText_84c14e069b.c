
longlong FUN_(longlong param_1,longlong param_2,longlong param_3,undefined4 *param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  code *UNRECOVERED_JUMPTABLE;
  undefined8 uVar4;
  undefined auStackX_10 [24];
  undefined auStack_88 [8];
  uint uStack_80;
  short sStack_7c;
  ushort uStack_7a;
  undefined8 uStack_78;
  undefined2 uStack_70;
  undefined4 uStack_6c;
  byte *pbStack_68;
  undefined8 uStack_60;
  undefined8 uStack_52;
  undefined2 uStack_4a;
  undefined2 uStack_48;
  undefined6 uStack_46;
  
  lVar3 = 0;
  uStack_80 = *(uint *)(param_1 + 0x30);
  uStack_7a = uStack_7a & 0xffe0;
  uStack_6c = 0;
  uStack_52 = 0;
  uStack_48 = 0;
  uStack_46 = 0;
  uStack_60 = 0;
  uStack_78 = 0;
  if (param_2 == 0) {
    if ((int)uStack_80 < 0) {
      if ((uStack_80 & 0xc0000000) == 0x80000000) {
        sStack_7c = 0;
      }
      else {
        sStack_7c = -(short)uStack_80;
      }
    }
    else {
      uStack_80 = uStack_80 | 0xa0000000;
      sStack_7c = 0;
    }
    pbStack_68 = (byte *)func_0x(param_3 + 0x3e,0,auStack_88);
    if ((*pbStack_68 & 1) != 0) {
      uStack_70 = 1;
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_68 & 0x1c) + 0x100be8) *
                              4 + 0x100bd8) - 0x1229b10);
                    /* WARNING: Could not emulate address calculation at 0x001000e6 */
                    /* WARNING: Treating indirect jump as call */
      lVar3 = (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return lVar3;
    }
    uStack_70 = 0;
    uStack_4a = 0;
    uStack_48 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010023c */
                    /* WARNING: Treating indirect jump as call */
    lVar3 = (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_68 & 0xe) * 4 + 0x100c08) -
                      0x1229b10))
                      ((longlong)(int)(*pbStack_68 & 0xe),0xfffffffffedd64f0,pbStack_68,pbStack_68);
    return lVar3;
  }
  cVar1 = *(char *)(param_2 + 0x16);
  if (cVar1 == '\x04') {
    uVar4 = 1;
LAB_:
    lVar3 = func_0x(param_2 + 0x3e,uVar4,auStackX_10);
  }
  else if ((cVar1 == '\x02') || (cVar1 == '\x03')) {
    uVar4 = 0;
    goto LAB_;
  }
  if ((*(char *)(param_2 + 0x16) - 2U & 0xfd) == 0) {
    uVar2 = *(undefined4 *)(param_1 + 0x50);
  }
  else {
    if (*(char *)(param_2 + 0x16) != '\x03') goto LAB_;
    uVar2 = *(undefined4 *)(param_1 + 0x48);
  }
  *param_4 = uVar2;
LAB_:
  if ((*(byte *)(lVar3 + 0xc) & 0xf) == 8) {
    lVar3 = 0;
  }
  else {
    lVar3 = *(longlong *)(param_1 + 0x40) + 0x14 + lVar3;
  }
  return lVar3;
}

