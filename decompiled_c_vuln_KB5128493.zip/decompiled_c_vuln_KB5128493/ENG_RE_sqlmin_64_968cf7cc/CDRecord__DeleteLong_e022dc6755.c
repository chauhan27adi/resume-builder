
undefined8 FUN_(longlong param_1,ushort param_2,int *param_3)

{
  code *pcVar1;
  uint uVar2;
  undefined8 uVar3;
  ushort uVar4;
  int iVar5;
  longlong lVar6;
  char *pcVar7;
  ushort uVar8;
  longlong lVar9;
  byte *pbVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  int iVar14;
  byte *pbVar15;
  longlong lVar16;
  ulonglong uVar17;
  uint uVar18;
  short *psVar19;
  
  uVar4 = *(ushort *)(param_1 + 0x1c);
  pbVar15 = *(byte **)(param_1 + 6);
  pbVar10 = pbVar15 + uVar4;
  if (*(short *)(param_1 + 0x24) == 1) {
    uVar2 = *(uint *)(param_1 + 2);
    uVar8 = (*(ushort *)(pbVar10 + 3) & 0x7fff) + uVar4 + *(short *)(param_1 + 0x22);
    iVar12 = (uint)uVar8 - (uint)uVar4;
    if (uVar8 != uVar2) {
      func_0x(pbVar10,pbVar15 + uVar8,uVar2 - uVar8);
      uVar2 = *(uint *)(param_1 + 2);
      uVar4 = *(ushort *)(param_1 + 0x1c);
      pbVar15 = *(byte **)(param_1 + 6);
    }
    *(uint *)(param_1 + 2) = uVar2 - iVar12;
    *(undefined4 *)(param_1 + 0x1e) = 0;
    *(undefined2 *)(param_1 + 0x22) = 0;
    if (*(int *)(param_1 + 0x2e) != 0) {
      *(int *)(param_1 + 0x2e) = *(int *)(param_1 + 0x2e) - iVar12;
    }
    *param_3 = *param_3 + ((uint)uVar4 - (uint)uVar8);
    *pbVar15 = *pbVar15 & 0xdf;
  }
  else {
    uVar2 = func_0x(param_1,param_2);
    uVar17 = (ulonglong)*(ushort *)(param_1 + 0x1c);
    lVar16 = *(longlong *)(param_1 + 6);
    uVar4 = 0;
    if (uVar2 != 0) {
      uVar4 = *(ushort *)(uVar17 + lVar16 + 3 + (ulonglong)(uVar2 - 1) * 2) & 0x7fff;
    }
    uVar13 = *(uint *)(param_1 + 2);
    uVar11 = (uint)(*(ushort *)(uVar17 + lVar16 + 3 + (ulonglong)uVar2 * 2) & 0x7fff) - (uint)uVar4;
    lVar6 = (ulonglong)uVar4 + *(ushort *)(param_1 + 0x22) + uVar17 + lVar16;
    lVar9 = (ulonglong)uVar11 + lVar6;
    uVar18 = (int)lVar9 - (int)lVar16 & 0xffff;
    if (uVar18 != uVar13) {
      func_0x(lVar6,lVar9,uVar13 - uVar18);
      uVar13 = *(uint *)(param_1 + 2);
      uVar17 = (ulonglong)*(ushort *)(param_1 + 0x1c);
      lVar16 = *(longlong *)(param_1 + 6);
    }
    iVar12 = *param_3;
    iVar14 = uVar13 - uVar11;
    iVar5 = *(int *)(param_1 + 0x2e);
    *(int *)(param_1 + 2) = iVar14;
    if (iVar5 != 0) {
      iVar5 = iVar5 - uVar11;
      *(int *)(param_1 + 0x2e) = iVar5;
    }
    psVar19 = (short *)(lVar16 + 1 + uVar17);
    uVar4 = (short)uVar2 * 2 + *(short *)(param_1 + 0x1e) + (short)uVar17;
    if (iVar14 != uVar4 + 2) {
      func_0x
                ((ulonglong)uVar4 + lVar16,(ulonglong)uVar4 + lVar16 + 2,(iVar14 - (uint)uVar4) + -2
                );
      iVar14 = *(int *)(param_1 + 2);
      iVar5 = *(int *)(param_1 + 0x2e);
    }
    *(int *)(param_1 + 2) = iVar14 + -2;
    *(short *)(param_1 + 0x20) = *(short *)(param_1 + 0x20) + -2;
    *(short *)(param_1 + 0x22) = *(short *)(param_1 + 0x22) + -2;
    if (iVar5 != 0) {
      *(int *)(param_1 + 0x2e) = iVar5 + -2;
    }
    *psVar19 = *psVar19 + -1;
    *param_3 = (iVar12 - uVar11) + -2;
    if (uVar2 < *(ushort *)(pbVar10 + 1)) {
      pcVar1 = (code *)swi(3);
      uVar3 = (*pcVar1)();
      return uVar3;
    }
    if (*(ushort *)(param_1 + 0x18) != 0) {
      uVar2 = (int)(param_2 - 1) / 0x1e;
      if ((ushort)uVar2 < *(ushort *)(param_1 + 0x18)) {
        pcVar7 = (char *)((ulonglong)*(ushort *)(param_1 + 0x20) + (ulonglong)(uVar2 & 0xffff) +
                          (ulonglong)*(ushort *)(param_1 + 0x1c) + *(longlong *)(param_1 + 6));
        *pcVar7 = *pcVar7 + -1;
      }
    }
  }
  *(short *)(param_1 + 0x24) = *(short *)(param_1 + 0x24) + -1;
  pbVar10 = (byte *)((longlong)((int)(param_2 - 1) / 2) + (ulonglong)*(ushort *)(param_1 + 0x16) +
                    *(longlong *)(param_1 + 6));
  if ((param_2 & 1) == 0) {
    *pbVar10 = *pbVar10 & 0xf | 0x10;
    return 1;
  }
  *pbVar10 = *pbVar10 & 0xf1 | 1;
  return 1;
}

