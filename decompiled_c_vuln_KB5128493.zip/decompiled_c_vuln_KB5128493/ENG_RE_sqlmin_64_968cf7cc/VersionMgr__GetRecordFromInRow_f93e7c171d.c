
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,byte *param_2,ulonglong param_3,longlong param_4)

{
  undefined2 *puVar1;
  undefined8 uVar2;
  ushort uVar3;
  longlong lVar4;
  ulonglong *puVar5;
  undefined4 *puVar6;
  byte *pbVar7;
  code *UNRECOVERED_JUMPTABLE;
  byte *pbVar8;
  byte bVar9;
  ushort uVar10;
  uint uVar11;
  ulonglong uVar12;
  uint uVar13;
  int iVar14;
  longlong lVar15;
  ushort *puVar16;
  longlong unaff_GS_OFFSET;
  undefined8 uStackX_e;
  undefined auStackX_16 [18];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar4 = func_0x();
  lVar4 = -lVar4;
  puVar1 = (undefined2 *)(&stack0xfffffffffffffff0 + lVar4);
  *(ulonglong *)(&stack0x00002180 + lVar4) = _DAT_ ^ (ulonglong)puVar1;
  pbVar7 = (byte *)0x0;
  *(undefined8 *)(&stack0x00000040 + lVar4) = *(undefined8 *)(&stack0x00002208 + lVar4);
  uVar3 = *(ushort *)(param_4 + 4);
  uVar10 = uVar3 >> 5;
  uVar13 = (uint)uVar10;
  *(byte **)(&stack0x00000028 + lVar4) = param_2;
  *(uint *)(&stack0x00000030 + lVar4) = uVar13;
  if (((byte)uVar3 & 0x1f) == 3) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100086;
    (*_DAT_)(1,0x1081890,0x1037e08,0x915);
  }
  iVar14 = 0;
  if (uVar10 != 0) {
    uVar3 = *(ushort *)(param_4 + 4) & 0x1f;
    if (uVar3 != 2) {
      if (uVar3 != 1) {
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10212c;
        (*_DAT_)(1,0x103b9d8,0x1037e08,0x989);
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10213b;
        func_0x(*(ulonglong *)(&stack0x00002180 + lVar4) ^ (ulonglong)puVar1);
        return;
      }
      if ((uint)param_3 < uVar13) {
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x101e55;
        (*_DAT_)(1,0x1081868,0x1037e08,0x97c);
      }
      if (*param_1 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x101e64;
        pbVar7 = (byte *)func_0x(param_1 + 1);
      }
      else {
        pbVar8 = *(byte **)(param_1 + 4);
        if ((*pbVar8 & 2) != 0) {
          if (*(int *)(param_1 + 2) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x101e7e;
            func_0x(param_1 + 1);
            pbVar8 = *(byte **)(param_1 + 4);
          }
          pbVar7 = pbVar8 + (ulonglong)*(uint *)(param_1 + 0x18) + 0xe;
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x101ea3;
      func_0x(param_2,param_3 & 0xffffffff,pbVar7,uVar13);
      if ((*param_2 & 1) == 0) {
        *param_1 = 0;
        *(byte **)(param_1 + 4) = param_2;
        *(undefined4 *)(param_1 + 2) = 0;
        *(undefined4 *)(param_1 + 0x13) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00102084 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*param_2 & 0xe) * 4 + 0x1022c4) - 0x188bd50)
        )();
        return;
      }
      *param_1 = 1;
      *(byte **)(param_1 + 4) = param_2;
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*param_2 & 0x1c) + 0x1022a4) * 4
                             + 0x102294) - 0x188bd50);
                    /* WARNING: Could not emulate address calculation at 0x00101f01 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
    *(undefined8 *)(&stack0x000000a0 + lVar4) = 0;
    *(undefined8 *)(&stack0x00000038 + lVar4) = 0;
    *(undefined4 *)(&stack0x000000a8 + lVar4) = 0;
    *(undefined2 *)(&stack0x000000ac + lVar4) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff4 + lVar4) = 0;
    *(undefined8 *)((longlong)&uStackX_e + lVar4) = 0;
    *(undefined8 *)(auStackX_16 + lVar4 + 2) = 0;
    *(undefined8 *)(auStackX_16 + lVar4 + -0x16) = 0;
    if (*param_1 == 0) {
      if (*(int *)(param_1 + 2) == 0) {
        pbVar7 = *(byte **)(param_1 + 4);
        uVar13 = *(uint *)(param_1 + 8);
        uVar12 = (ulonglong)uVar13;
        param_1[1] = 0;
        *(uint *)(param_1 + 10) = uVar13;
        bVar9 = *pbVar7;
        if ((bVar9 & 0x10) != 0) {
          uVar13 = uVar13 + 2 + (*(ushort *)(pbVar7 + uVar12) + 7 >> 3);
          uVar12 = (ulonglong)uVar13;
          *(uint *)(param_1 + 10) = uVar13;
          bVar9 = *pbVar7;
        }
        if ((bVar9 & 0x20) == 0) {
          *(int *)(param_1 + 2) = (int)uVar12;
          param_1[0xe] = 0;
          *(int *)(param_1 + 0xc) = (int)uVar12;
        }
        else {
          puVar16 = (ushort *)(pbVar7 + uVar12);
          uVar3 = *puVar16;
          param_1[0xe] = uVar3;
          if (uVar3 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar15 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar15 != 0)) &&
               ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                (*(char *)(lVar15 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100c02;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100c26;
                (*_DAT_)(1,0xeb15f8,0xfd12c8,0x80f);
              }
            }
            uVar2 = *(undefined8 *)(param_1 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100c34;
            func_0x(uVar2,3);
            uVar3 = param_1[0xe];
            uVar12 = (ulonglong)*(uint *)(param_1 + 10);
          }
          uVar13 = (int)uVar12 + (uVar3 + 1) * 2;
          *(uint *)(param_1 + 0xc) = uVar13;
          if (0x1f9e < uVar13) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar15 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar15 != 0 &&
                ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                 (*(char *)(lVar15 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100cd4;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100cf8;
                (*_DAT_)(1,0xeb15f8,0xfd12c8,0x816);
              }
            }
            uVar2 = *(undefined8 *)(param_1 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100d06;
            func_0x(uVar2,4);
            uVar3 = param_1[0xe];
            uVar13 = *(uint *)(param_1 + 0xc);
          }
          uVar11 = puVar16[uVar3] & 0x7fff;
          *(uint *)(param_1 + 2) = uVar11;
          if (uVar11 < uVar13) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar15 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar15 != 0)) &&
               ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                (*(char *)(lVar15 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100da5;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100dc9;
                (*_DAT_)(1,0xeb15f8,0xfd12c8,0x81d);
              }
            }
            uVar2 = *(undefined8 *)(param_1 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100dd7;
            func_0x(uVar2,4);
            uVar3 = param_1[0xe];
            uVar11 = *(uint *)(param_1 + 2);
          }
          if ((short)puVar16[(ulonglong)(uVar3 - 1) + 1] < 0) {
            lVar15 = *(longlong *)(param_1 + 4);
            do {
              if (uVar3 == 1) {
                uVar13 = *(uint *)(param_1 + 0xc);
                uVar11 = uVar13;
LAB_:
                if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar15 + (ulonglong)uVar3 * 2)
                    & 0x7fff) < uVar13) goto LAB_;
              }
              else {
                uVar11 = *(uint *)(param_1 + 0xc);
                uVar13 = *(ushort *)
                          ((ulonglong)*(uint *)(param_1 + 10) + lVar15 + -2 + (ulonglong)uVar3 * 2)
                         & 0x7fff;
                if (uVar11 <= uVar13) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100e44;
                func_0x(lVar15,7);
                uVar11 = *(uint *)(param_1 + 0xc);
              }
              if ((uVar13 < uVar11) || (uVar11 = *(uint *)(param_1 + 2), uVar11 < uVar13))
              goto LAB_;
              lVar15 = *(longlong *)(param_1 + 4);
              if (*(ushort *)((ulonglong)uVar13 + lVar15) == 5) {
                param_1[1] = param_1[1] | 2;
                param_1[0xe] = param_1[0xe] + -1;
                param_1[0x15] = (short)uVar13;
                lVar15 = (ulonglong)(uVar13 & 0xffff) + *(longlong *)(param_1 + 4);
                uVar3 = param_1[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar15 + 2) & 0x4000) != 0) {
                  uVar3 = *(ushort *)(lVar15 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
                }
                param_1[0x16] = uVar3;
                param_1[0x16] = (uVar3 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar3;
                uVar11 = *(uint *)(param_1 + 2);
                break;
              }
              if (*(ushort *)((ulonglong)uVar13 + lVar15) < 0x400) break;
              param_1[1] = param_1[1] | 1;
              uVar3 = param_1[0xe] - 1;
              param_1[0xe] = uVar3;
              if ((uVar3 == 0) || (-1 < (short)puVar16[(ulonglong)(uVar3 - 1) + 1])) break;
            } while( true );
          }
          uVar12 = (ulonglong)uVar11;
          pbVar7 = *(byte **)(param_1 + 4);
        }
        if ((*pbVar7 & 0x40) == 0) {
          *(undefined4 *)(param_1 + 0x13) = 0;
        }
        else {
          *(int *)(param_1 + 0x13) = (int)uVar12;
          *(int *)(param_1 + 2) = (int)uVar12 + 0xe;
          *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100f61;
          puVar5 = (ulonglong *)func_0x(param_1 + 1);
          uVar12 = *puVar5;
          uVar10 = (ushort)(uVar12 >> 0x30);
          uVar3 = uVar10;
          if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
            uVar3 = uVar10 & 0xdfff;
            if ((uVar12 & 0x4000000000000000) != 0) {
              uVar3 = uVar10 | 0x2000;
            }
          }
          if (uVar3 == 0xfffc) {
            iVar14 = (int)((uVar12 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar14;
          uVar12 = (ulonglong)*(uint *)(param_1 + 2);
        }
        iVar14 = (int)uVar12;
        if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
           (*(ulonglong *)(param_1 + 0xf) < uVar12 + *(longlong *)(param_1 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar15 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar15 != 0 &&
               (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
              (*(char *)(lVar15 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x101053;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x101077;
              (*_DAT_)(1,0xeb15f8,0xfd12c8,0x877);
            }
          }
          uVar2 = *(undefined8 *)(param_1 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x101085;
          func_0x(uVar2,0x12);
          iVar14 = *(int *)(param_1 + 2);
        }
        if (0x3f3b < iVar14 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar15 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar15 != 0 &&
              ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
               (*(char *)(lVar15 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x101118;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10113c;
              (*_DAT_)(1,0xeb15f8,0xfd12c8,0x87c);
            }
          }
          uVar2 = *(undefined8 *)(param_1 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10114a;
          func_0x(uVar2,5);
        }
      }
LAB_:
      uVar13 = *(uint *)(param_1 + 2);
      if (uVar13 < 9) {
        bVar9 = **(byte **)(param_1 + 4) & 0xe;
        goto joined_r0x00101163;
      }
    }
    else {
      uVar13 = *(uint *)(param_1 + 2);
      if (uVar13 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10117b;
        func_0x(param_1 + 1);
        uVar13 = *(uint *)(param_1 + 2);
      }
      if (uVar13 < 9) {
        bVar9 = **(byte **)(param_1 + 4) & 0x1c;
joined_r0x00101163:
        if ((bVar9 == 0) || (bVar9 == 0xc)) {
          uVar13 = 9;
        }
      }
    }
    lVar15 = *(longlong *)(param_1 + 4);
    if (uVar13 != 0) {
      if ((lVar15 == 0) || (0x2000 < uVar13)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1011d9;
        func_0x(&stack0x00000180 + lVar4,0,0x2000);
        if (lVar15 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1011e4;
          puVar6 = (undefined4 *)(*_DAT_)();
          *puVar6 = 0x16;
        }
        else {
          if (uVar13 < 0x2001) goto LAB_;
          *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1011fb;
          puVar6 = (undefined4 *)(*_DAT_)();
          *puVar6 = 0x22;
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x101207;
        (*_DAT_)();
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1011c6;
        func_0x(&stack0x00000180 + lVar4,lVar15,uVar13);
      }
    }
LAB_:
    bVar9 = (&stack0x00000180)[lVar4];
    *(undefined **)(&stack0xfffffffffffffff8 + lVar4) = &stack0x00000180 + lVar4;
    if ((bVar9 & 1) == 0) {
      *puVar1 = 0;
      lVar15 = (longlong)(int)(bVar9 & 0xe);
      *(undefined4 *)(auStackX_16 + lVar4) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001013a6 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)(lVar15 * 4 + 0x1021ec) - 0x188bd50))
                (lVar15,bVar9,0xc2dad8,0xc2dad8);
      return;
    }
    *puVar1 = 1;
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(bVar9 & 0x1c) + 0x1021cc) * 4 +
                           0x1021bc) - 0x188bd50);
                    /* WARNING: Could not emulate address calculation at 0x0010127c */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
  if (*param_1 != 0) {
    uVar13 = *(uint *)(param_1 + 2);
    if (uVar13 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1006da;
      func_0x(param_1 + 1);
      uVar13 = *(uint *)(param_1 + 2);
    }
    if ((uVar13 < 9) &&
       (((**(byte **)(param_1 + 4) & 0x1c) == 0 || ((**(byte **)(param_1 + 4) & 0x1c) == 0xc)))) {
      uVar13 = 9;
    }
    goto LAB_;
  }
  if (*(int *)(param_1 + 2) == 0) {
    pbVar7 = *(byte **)(param_1 + 4);
    uVar13 = *(uint *)(param_1 + 8);
    uVar12 = (ulonglong)uVar13;
    param_1[1] = 0;
    *(uint *)(param_1 + 10) = uVar13;
    bVar9 = *pbVar7;
    if ((bVar9 & 0x10) != 0) {
      uVar13 = uVar13 + 2 + (*(ushort *)(pbVar7 + uVar12) + 7 >> 3);
      uVar12 = (ulonglong)uVar13;
      *(uint *)(param_1 + 10) = uVar13;
      bVar9 = *pbVar7;
    }
    if ((bVar9 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar12;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar12;
    }
    else {
      puVar16 = (ushort *)(pbVar7 + uVar12);
      uVar3 = *puVar16;
      param_1[0xe] = uVar3;
      if (uVar3 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0)) &&
           ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
            (*(char *)(lVar15 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100174;
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100198;
            (*_DAT_)(1,0xeb15f8,0xfd12c8,0x80f);
          }
        }
        uVar2 = *(undefined8 *)(param_1 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1001a6;
        func_0x(uVar2,3);
        uVar3 = param_1[0xe];
        uVar12 = (ulonglong)*(uint *)(param_1 + 10);
      }
      uVar13 = (int)uVar12 + (uVar3 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar13;
      if (0x1f9e < uVar13) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0 &&
            ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
             (*(char *)(lVar15 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100246;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10026a;
            (*_DAT_)(1,0xeb15f8,0xfd12c8,0x816);
          }
        }
        uVar2 = *(undefined8 *)(param_1 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100278;
        func_0x(uVar2,4);
        uVar3 = param_1[0xe];
        uVar13 = *(uint *)(param_1 + 0xc);
      }
      uVar11 = puVar16[uVar3] & 0x7fff;
      *(uint *)(param_1 + 2) = uVar11;
      if (uVar11 < uVar13) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0)) &&
           ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
            (*(char *)(lVar15 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100317;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10033b;
            (*_DAT_)(1,0xeb15f8,0xfd12c8,0x81d);
          }
        }
        uVar2 = *(undefined8 *)(param_1 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100349;
        func_0x(uVar2,4);
        uVar3 = param_1[0xe];
        uVar11 = *(uint *)(param_1 + 2);
      }
      if ((short)puVar16[(ulonglong)(uVar3 - 1) + 1] < 0) {
        lVar15 = *(longlong *)(param_1 + 4);
        do {
          if (uVar3 == 1) {
            uVar13 = *(uint *)(param_1 + 0xc);
            uVar11 = uVar13;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar15 + (ulonglong)uVar3 * 2) &
                0x7fff) < uVar13) goto LAB_;
          }
          else {
            uVar11 = *(uint *)(param_1 + 0xc);
            uVar13 = *(ushort *)
                      ((ulonglong)*(uint *)(param_1 + 10) + lVar15 + -2 + (ulonglong)uVar3 * 2) &
                     0x7fff;
            if (uVar11 <= uVar13) goto LAB_;
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1003b4;
            func_0x(lVar15,7);
            uVar11 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar13 < uVar11) ||
             (uVar12 = (ulonglong)*(uint *)(param_1 + 2), *(uint *)(param_1 + 2) < uVar13))
          goto LAB_;
          lVar15 = *(longlong *)(param_1 + 4);
          if (*(ushort *)((ulonglong)uVar13 + lVar15) == 5) {
            param_1[1] = param_1[1] | 2;
            param_1[0xe] = param_1[0xe] + -1;
            param_1[0x15] = (short)uVar13;
            lVar15 = (ulonglong)(uVar13 & 0xffff) + *(longlong *)(param_1 + 4);
            uVar3 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar15 + 2) & 0x4000) != 0) {
              uVar3 = *(ushort *)(lVar15 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar3;
            param_1[0x16] = (uVar3 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar3;
            uVar11 = *(uint *)(param_1 + 2);
            break;
          }
          if (*(ushort *)((ulonglong)uVar13 + lVar15) < 0x400) goto LAB_;
          param_1[1] = param_1[1] | 1;
          uVar3 = param_1[0xe] - 1;
          param_1[0xe] = uVar3;
          if ((uVar3 == 0) || (-1 < (short)puVar16[(ulonglong)(uVar3 - 1) + 1])) goto LAB_;
        } while( true );
      }
      uVar12 = (ulonglong)uVar11;
      pbVar7 = *(byte **)(param_1 + 4);
    }
    goto LAB_;
  }
LAB_:
  uVar13 = *(uint *)(param_1 + 2);
  if ((uVar13 < 9) &&
     (((**(byte **)(param_1 + 4) & 0xe) == 0 || ((**(byte **)(param_1 + 4) & 0xe) == 0xc)))) {
    uVar13 = 9;
  }
  param_2 = *(byte **)(&stack0x00000028 + lVar4);
LAB_:
  uVar2 = *(undefined8 *)(param_1 + 4);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10070b;
  func_0x(param_2,param_3 & 0xffffffff,uVar2,uVar13);
  if ((*param_2 & 1) == 0) {
    *param_1 = 0;
    *(byte **)(param_1 + 4) = param_2;
    *(undefined4 *)(param_1 + 2) = 0;
    *(undefined4 *)(param_1 + 0x13) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001008ec */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*param_2 & 0xe) * 4 + 0x102180) - 0x188bd50))();
    return;
  }
  *param_1 = 1;
  *(byte **)(param_1 + 4) = param_2;
  UNRECOVERED_JUMPTABLE =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*param_2 & 0x1c) + 0x102160) * 4 +
                         0x102150) - 0x188bd50);
                    /* WARNING: Could not emulate address calculation at 0x00100769 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
  return;
LAB_:
  pbVar7 = *(byte **)(param_1 + 4);
LAB_:
  if ((*pbVar7 & 0x40) == 0) {
    *(undefined4 *)(param_1 + 0x13) = 0;
  }
  else {
    *(int *)(param_1 + 0x13) = (int)uVar12;
    *(int *)(param_1 + 2) = (int)uVar12 + 0xe;
    *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1004b7;
    puVar5 = (ulonglong *)func_0x(param_1 + 1);
    uVar12 = *puVar5;
    uVar10 = (ushort)(uVar12 >> 0x30);
    uVar3 = uVar10;
    if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
      uVar3 = uVar10 & 0xdfff;
      if ((uVar12 & 0x4000000000000000) != 0) {
        uVar3 = uVar10 | 0x2000;
      }
    }
    if (uVar3 == 0xfffc) {
      iVar14 = (int)((uVar12 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar14;
    uVar12 = (ulonglong)*(uint *)(param_1 + 2);
  }
  iVar14 = (int)uVar12;
  if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
     (*(ulonglong *)(param_1 + 0xf) < uVar12 + *(longlong *)(param_1 + 4))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar15 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar15 != 0 &&
         (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
        (*(char *)(lVar15 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1005b3;
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1005d7;
        (*_DAT_)(1,0xeb15f8,0xfd12c8,0x877);
      }
    }
    uVar2 = *(undefined8 *)(param_1 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1005e5;
    func_0x(uVar2,0x12);
    iVar14 = *(int *)(param_1 + 2);
  }
  if (0x3f3b < iVar14 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar15 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar15 != 0 &&
        ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 && (*(char *)(lVar15 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100672;
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100696;
        (*_DAT_)(1,0xeb15f8,0xfd12c8,0x87c);
      }
    }
    uVar2 = *(undefined8 *)(param_1 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1006a4;
    func_0x(uVar2,5);
  }
  goto LAB_;
}

