
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined4 param_1,undefined8 *param_2)

{
  undefined auVar1 [16];
  char cVar2;
  uint uVar3;
  undefined8 uVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong lVar8;
  undefined8 *puVar9;
  undefined4 uVar10;
  char cVar11;
  undefined uVar12;
  undefined8 *puVar13;
  char cVar14;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_80;
  int iStack_78;
  undefined auStack_70 [8];
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined auStack_40 [40];
  
  uStack_60 = 0xfffffffffffffffe;
  puVar9 = (undefined8 *)0x0;
  uStack_80 = 0x16ce7c8;
  iStack_78 = 0;
  cVar2 = func_0x(&uStack_80,1,0xffffffff,0);
  if (cVar2 == '\0') {
    (*_DAT_)(0xe0,0xd,0x10,2);
  }
  switch(param_1) {
  case 1:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    lVar6 = param_2[0xc];
    cVar11 = '\0';
    uVar12 = 0;
    cVar14 = '\x01';
    cVar2 = cVar11;
    if (((((*(char *)((longlong)param_2 + 0x7d) == '\0') && (lVar6 != 0)) &&
         (*(char *)(lVar6 + 0x42) != '\0')) &&
        ((*(longlong *)(lVar6 + 0x30) != 0 &&
         ((*(char *)((longlong)param_2 + 0x44) != '\x02' ||
          (cVar2 = cVar14, *(int *)(param_2 + 0xf) != 3)))))) &&
       (cVar2 = cVar11, *(int *)(param_2 + 0xf) == 0)) {
      if (*(char *)(lVar6 + 0x42) == '\x02') {
        if (*(char *)((longlong)param_2 + 0x44) == '\x01') {
          uVar12 = 1;
          goto code_r0x0010013b;
        }
        uVar7 = 0xf;
        uVar4 = 0xdf;
        uVar10 = 0x7a;
      }
      else {
        uVar7 = 0x1c;
        uVar4 = 0xe0;
        uVar10 = 1;
      }
      (*_DAT_)(uVar4,uVar7,0x10,uVar10);
    }
code_r0x0010013b:
    if ((iRam00000000015081b8 != 0) && (cVar14 = '\x01', iRam0000000001508200 == 0)) {
      cVar14 = '\0';
    }
    puVar13 = param_2 + 10;
    if (cVar14 == '\0') {
      puVar13 = puVar9;
    }
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    func_0x(lRam0000000001752328,*(undefined *)((longlong)param_2 + 0x44),
                    *(undefined *)((longlong)param_2 + 0x45),*(undefined4 *)(param_2 + 9),lVar6,
                    puVar13,param_2 + 0xb,param_2,param_2 + 1,param_2[0xd],param_2[0xe],
                    *(undefined4 *)(param_2 + 0xf),*(undefined *)((longlong)param_2 + 0x7d),cVar2,
                    uVar12);
    if (((lVar6 != 0) && (*(char *)(lVar6 + 0x42) != '\0')) && (*(longlong *)(lVar6 + 0x30) != 0)) {
      func_0x(lVar6);
      func_0x(lVar6);
      func_0x();
      if (*(char *)((longlong)param_2 + 0xb9) != '\0') {
        func_0x(lVar6);
      }
    }
    goto code_r0x0010021d;
  case 2:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    func_0x(lRam0000000001752328,*param_2,param_2[0xc]);
    puVar9 = (undefined8 *)0x0;
    break;
  case 3:
    func_0x(auStack_40,0,0,0,0xffffffffffb265f0,0);
    uVar4 = func_0x();
    func_0x(uVar4,*param_2,param_2[2],0,param_2[0xc]);
    func_0x(auStack_40);
    lVar8 = (ulonglong)*puRam0000000000a6ed40 +
            *(longlong *)
             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam0000000000a6ed38 * 8);
    lVar6 = *(longlong *)(lVar8 + 0x100);
    if (lVar6 == 0) {
      (*pcRam0000000000a6ed50)();
      lVar6 = *(longlong *)(lVar8 + 0x100);
    }
    if (*(int *)(lVar6 + 0x22c) != 0) {
      (*pcRam0000000000a6ec30)();
      puVar9 = (undefined8 *)0x0;
      break;
    }
    goto code_r0x0010021d;
  case 4:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    lVar8 = lRam0000000001752328;
    lVar6 = param_2[4];
    if (lVar6 == 0) {
      (*_DAT_)(1,0xfc5a50,0xf77900,0xb4a,0);
    }
    lVar5 = func_0x(0,1);
    if ((lVar5 == 0) || (cVar2 = func_0x(lVar5), cVar2 == '\0')) {
      (*_DAT_)(1,0xfa70d0,0xf77900,0xb4e,0);
    }
    cVar2 = *(char *)(lVar5 + 0x42);
    if (cVar2 == '\0') {
      (*_DAT_)(1,0xfc5cb8,0xf77910,0x57c,0);
      cVar2 = *(char *)(lVar5 + 0x42);
    }
    if (cVar2 == '\x02') {
      (*_DAT_)(1,0xfafe78,0xf77900,0xb4f,0);
    }
    auVar1 = *(undefined (*) [16])(lVar5 + 0x20);
    _auStack_70 = auVar1;
    if ((auVar1 & (undefined  [16])0xffffff0000000000) == (undefined  [16])0x0) {
      (*_DAT_)(1,0xfc5a10,0xf77900,0xb53,0);
    }
    if ((auVar1 & (undefined  [16])0xffffff0000) == (undefined  [16])0x0) {
      (*_DAT_)(1,0xfc59d0,0xf77900,0xb54,0);
    }
    uStack_68._0_2_ = (short)lVar6;
    func_0x(lVar8,auStack_70,uStack_68,0,0);
    puVar9 = (undefined8 *)0x0;
    break;
  case 5:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    uVar3 = func_0x(lRam0000000001752328,*param_2,*(undefined4 *)(param_2 + 9),param_2 + 10,
                            param_2 + 0xb);
    puVar9 = (undefined8 *)(ulonglong)uVar3;
    break;
  case 6:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    uVar3 = func_0x(lRam0000000001752328,*param_2,(longlong)param_2 + 0x4c);
    puVar9 = (undefined8 *)(ulonglong)uVar3;
    break;
  case 7:
    lVar6 = param_2[0xc];
    if (((lVar6 != 0) && (*(char *)(lVar6 + 0x42) != '\0')) && (*(longlong *)(lVar6 + 0x30) != 0)) {
      func_0x(lVar6,0);
    }
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    func_0x(lRam0000000001752328,param_2);
    lVar6 = param_2[0xc];
    if (((lVar6 != 0) && (*(char *)(lVar6 + 0x42) != '\0')) && (*(longlong *)(lVar6 + 0x30) != 0)) {
      func_0x();
      func_0x(param_2[0xc]);
      func_0x();
      if (*(char *)((longlong)param_2 + 0xb9) != '\0') {
        func_0x(param_2[0xc]);
        puVar9 = (undefined8 *)0x0;
        break;
      }
    }
code_r0x0010021d:
    puVar9 = (undefined8 *)0x0;
    break;
  case 8:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    uVar3 = func_0x(lRam0000000001752328,param_2);
    puVar9 = (undefined8 *)(ulonglong)uVar3;
    break;
  case 9:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    uVar3 = func_0x(lRam0000000001752328,param_2[7]);
    puVar9 = (undefined8 *)(ulonglong)uVar3;
    break;
  case 10:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    uVar3 = func_0x(lRam0000000001752328,*param_2,*(undefined *)((longlong)param_2 + 0x45));
    puVar9 = (undefined8 *)(ulonglong)uVar3;
    break;
  default:
    (*_DAT_)(1,0xf72210,0xf77900,0x43b,0xb6d3b8);
    break;
  case 0xc:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    uVar3 = func_0x(lRam0000000001752328,1);
    puVar9 = (undefined8 *)(ulonglong)uVar3;
    break;
  case 0xd:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    uVar3 = func_0x(lRam0000000001752328,0);
    puVar9 = (undefined8 *)(ulonglong)uVar3;
    break;
  case 0xe:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    func_0x(lRam0000000001752328,*param_2,param_2[2],1,0);
    puVar9 = (undefined8 *)0x0;
    break;
  case 0xf:
    if (lRam0000000001752328 == 0) {
      (*_DAT_)(0xe0,0xe,0x10,1);
    }
    func_0x(lRam0000000001752328,*param_2,*(undefined4 *)(param_2 + 9),0,param_2 + 10,
                    param_2 + 0xb);
    puVar9 = (undefined8 *)0x0;
  }
  if (iStack_78 != 0) {
    (*_DAT_)(uStack_80);
  }
  return puVar9;
}

