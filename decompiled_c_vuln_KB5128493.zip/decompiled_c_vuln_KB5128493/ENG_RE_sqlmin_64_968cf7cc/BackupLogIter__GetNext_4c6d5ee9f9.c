
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(longlong param_1)

{
  ushort uVar1;
  longlong lVar2;
  ushort *puVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  
  if (*(char *)(param_1 + 0x228) != '\x03') {
    puVar3 = *(ushort **)(param_1 + 0x230);
    uVar5 = 0;
    uVar4 = (ulonglong)*(ushort *)(param_1 + 0x218);
    do {
      uVar1 = (short)uVar4 + 1;
      *(ushort *)(param_1 + 0x218) = uVar1;
      if ((uint)uVar1 < puVar3[1] + 1) {
        uVar4 = (ulonglong)
                *(ushort *)((ulonglong)puVar3[2] + (ulonglong)uVar1 * -2 + (longlong)puVar3) +
                (longlong)puVar3;
        *(ulonglong *)(param_1 + 0x208) = uVar4;
        if (uVar4 != 0) {
          if (4 < *puVar3) {
            return uVar4;
          }
          lVar2 = *(longlong *)(param_1 + 600);
          if (lVar2 == 0) {
            lVar2 = (*_DAT_)(0x6000,*(undefined8 *)(param_1 + 0x250),0x1030720,0x54a,5);
            puVar3 = *(ushort **)(param_1 + 0x230);
            *(longlong *)(param_1 + 600) = lVar2;
          }
          uVar1 = *puVar3;
          if (uVar1 != 3) {
            if (uVar1 != 4) {
              (*_DAT_)(0x5a,0xe,0x15,4,*(undefined8 *)(param_1 + 0x248),uVar1,3,6);
              return *(ulonglong *)(param_1 + 600);
            }
            func_0x(param_1 + 0x210,uVar4,lVar2);
            return *(ulonglong *)(param_1 + 600);
          }
          func_0x(param_1 + 0x210,uVar4,lVar2);
          uVar5 = *(ulonglong *)(param_1 + 600);
        }
        return uVar5;
      }
      *(undefined8 *)(param_1 + 0x208) = 0;
      func_0x(param_1);
      puVar3 = *(ushort **)(param_1 + 0x230);
      if (puVar3 == (ushort *)0x0) {
        *(undefined *)(param_1 + 0x228) = 3;
        return 0;
      }
      *(undefined2 *)(param_1 + 0x218) = 0;
      uVar4 = uVar5;
    } while (*(char *)(param_1 + 0x228) != '\x03');
  }
  return 0;
}

