
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,char param_2,short *param_3,longlong param_4,undefined8 *param_5,
                 longlong param_6)

{
  short sVar1;
  longlong *plVar2;
  undefined *puVar3;
  ushort uVar4;
  int iVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong lVar8;
  short *psVar9;
  short *psVar10;
  ulonglong *puVar11;
  short *psVar12;
  byte bVar13;
  ushort uVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  longlong lVar18;
  ushort *puVar19;
  int iVar20;
  byte *pbVar21;
  longlong unaff_GS_OFFSET;
  undefined auStack_608 [32];
  undefined8 uStack_5e8;
  longlong lStack_5e0;
  longlong lStack_5d8;
  short *psStack_5d0;
  undefined8 uStack_5c8;
  int iStack_5c0;
  undefined8 uStack_5b8;
  int *piStack_5b0;
  undefined **ppuStack_5a8;
  undefined8 uStack_5a0;
  undefined8 uStack_598;
  undefined *puStack_590;
  undefined8 uStack_588;
  undefined4 uStack_580;
  undefined8 uStack_57c;
  undefined8 uStack_574;
  undefined8 uStack_568;
  undefined2 uStack_560;
  undefined auStack_558 [2];
  undefined2 uStack_556;
  undefined8 uStack_554;
  undefined2 uStack_54c;
  undefined2 uStack_54a;
  undefined4 uStack_548;
  undefined2 uStack_544;
  char cStack_542;
  undefined uStack_541;
  ushort uStack_53c;
  undefined2 auStack_53a [65];
  undefined auStack_4b8 [16];
  uint uStack_4a8;
  undefined4 uStack_4a4;
  uint uStack_4a0;
  undefined4 uStack_49c;
  short asStack_498 [261];
  short asStack_28e [129];
  short asStack_18c [129];
  undefined2 uStack_8a;
  undefined uStack_88;
  undefined2 uStack_86;
  undefined uStack_84;
  int iStack_78;
  int iStack_74;
  uint uStack_70;
  undefined *puStack_68;
  uint *puStack_60;
  undefined8 uStack_58;
  ulonglong uStack_50;
  
  uStack_50 = _DAT_ ^ (ulonglong)auStack_608;
  uStack_8a = 0;
  uStack_4a8 = *(uint *)(param_4 + 0x650) & 0xffbfffff;
  uStack_86 = 0;
  uStack_4a4 = *(undefined4 *)(param_4 + 0xc);
  uStack_4a0 = (uint)*(ushort *)(param_4 + 0x10);
  uStack_49c = 0;
  uStack_84 = 0;
  uStack_88 = 0;
  uStack_548 = 0;
  uStack_544 = 0;
  uStack_53c = 0;
  lStack_5d8 = param_1;
  psStack_5d0 = param_3;
  if ((param_2 == -0x72) && (*(char *)(param_6 + 0x5ce) != '\0')) {
    if (((byte)*(uint *)(param_4 + 0x650) & 0x28) != 0x28) {
      uStack_5e8 = 0;
      (*_DAT_)(1,0x1574540,0x1541078,0xedd);
    }
    lVar6 = (*_DAT_)(param_4 + 0x812,0x1d1f530);
    if ((lVar6 == 0) || (lVar6 != param_4 + 0x812)) {
      uStack_5e8 = 0;
      (*_DAT_)(1,0x1574560,0x1541078,0xee8);
    }
    param_1 = lStack_5d8;
    uVar7 = 0xffffffffffffffff;
    do {
      uVar7 = uVar7 + 1;
    } while (*(short *)(uVar7 * 2 + 0x1d1f530) != 0);
    lVar6 = lVar6 + (uVar7 & 0xffffffff) * 2;
    if ((*(ushort *)(*(longlong *)(lStack_5d8 + 0x20) + 0x67e) < 0x356) &&
       ((DAT_ & 0x80) == 0)) {
      lVar8 = -1;
      do {
        lVar8 = lVar8 + 1;
      } while (*(short *)(lVar6 + lVar8 * 2) != 0);
      uStack_5e8 = CONCAT44(uStack_5e8._4_4_,(int)lVar8 * 2);
      lStack_5e0 = lVar6;
      (*_DAT_)(0x33,0x15,0x10,0x65);
    }
  }
  else {
    lVar6 = param_4 + 0x812;
  }
  func_0x(asStack_498,0,0x20a);
  lVar8 = 0x105;
  psVar12 = asStack_498;
  do {
    if ((lVar8 == -0x7ffffef9) ||
       (sVar1 = *(short *)((lVar6 - (longlong)asStack_498) + (longlong)psVar12), sVar1 == 0)) break;
    *psVar12 = sVar1;
    psVar12 = psVar12 + 1;
    lVar8 = lVar8 + -1;
  } while (lVar8 != 0);
  psVar9 = psVar12 + -1;
  if (lVar8 != 0) {
    psVar9 = psVar12;
  }
  *psVar9 = 0;
  func_0x(asStack_28e,0,0x102);
  lVar8 = 0x81;
  psVar12 = asStack_28e;
  lVar6 = 0x81;
  do {
    if ((lVar6 == -0x7fffff7d) ||
       (sVar1 = *(short *)((param_4 - (longlong)asStack_28e) + 0x710 + (longlong)psVar12),
       sVar1 == 0)) break;
    *psVar12 = sVar1;
    psVar12 = psVar12 + 1;
    lVar6 = lVar6 + -1;
  } while (lVar6 != 0);
  psVar9 = psVar12 + -1;
  if (lVar6 != 0) {
    psVar9 = psVar12;
  }
  uVar4 = *(ushort *)(param_4 + 0x10);
  lVar18 = 0;
  *psVar9 = 0;
  lVar6 = *(longlong *)(*(longlong *)(param_1 + 0x20) + 0x698);
  if (((*(uint *)(lVar6 + 0x4c) < (uint)uVar4) || (uVar4 == 0)) ||
     (lVar18 = *(longlong *)(*(longlong *)(lVar6 + 0x28) + -8 + (ulonglong)uVar4 * 8), lVar18 == 0))
  {
    uStack_5e8 = 0;
    (*_DAT_)(1,0x1573bf8,0x1541078,0xf14);
  }
  func_0x(asStack_18c,0,0x102);
  psVar9 = psStack_5d0;
  psVar12 = asStack_18c;
  do {
    if ((lVar8 == -0x7fffff7d) ||
       (sVar1 = *(short *)((lVar18 - (longlong)asStack_18c) + 100 + (longlong)psVar12), sVar1 == 0))
    break;
    *psVar12 = sVar1;
    psVar12 = psVar12 + 1;
    lVar8 = lVar8 + -1;
  } while (lVar8 != 0);
  psVar10 = psVar12 + -1;
  if (lVar8 != 0) {
    psVar10 = psVar12;
  }
  *psVar10 = 0;
  if (param_2 == -0x72) {
    uStack_88 = *(undefined *)(param_6 + 0x5ce);
  }
  uStack_541 = 0;
  uStack_54a = 0;
  auStack_53a[uStack_53c] = 0x428;
  uStack_53c = uStack_53c + 1;
  iVar5 = 0;
  cStack_542 = param_2;
  if (*psStack_5d0 == 0) {
    if (*(int *)(psStack_5d0 + 2) == 0) {
      pbVar21 = *(byte **)(psStack_5d0 + 4);
      uVar15 = *(uint *)(psStack_5d0 + 8);
      uVar7 = (ulonglong)uVar15;
      psStack_5d0[1] = 0;
      *(uint *)(psStack_5d0 + 10) = uVar15;
      bVar13 = *pbVar21;
      if ((bVar13 & 0x10) != 0) {
        uVar15 = uVar15 + 2 + (*(ushort *)(pbVar21 + uVar7) + 7 >> 3);
        uVar7 = (ulonglong)uVar15;
        *(uint *)(psStack_5d0 + 10) = uVar15;
        bVar13 = *pbVar21;
      }
      if ((bVar13 & 0x20) == 0) {
        *(int *)(psStack_5d0 + 2) = (int)uVar7;
        psStack_5d0[0xe] = 0;
        *(int *)(psStack_5d0 + 0xc) = (int)uVar7;
      }
      else {
        puVar19 = (ushort *)(pbVar21 + uVar7);
        uVar4 = *puVar19;
        psStack_5d0[0xe] = uVar4;
        if (uVar4 == 0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar6 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar6 != 0 &&
              ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 &&
               (*(char *)(lVar6 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_5e8 = 0;
              (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),3);
          uVar4 = psVar9[0xe];
          uVar7 = (ulonglong)*(uint *)(psVar9 + 10);
        }
        uVar15 = (int)uVar7 + (uVar4 + 1) * 2;
        *(uint *)(psVar9 + 0xc) = uVar15;
        if (0x1f9e < uVar15) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar6 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar6 != 0)) &&
             ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_5e8 = 0;
              (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),4);
          uVar4 = psVar9[0xe];
          uVar15 = *(uint *)(psVar9 + 0xc);
        }
        uVar16 = puVar19[uVar4] & 0x7fff;
        *(uint *)(psVar9 + 2) = uVar16;
        if (uVar16 < uVar15) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar6 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar6 != 0 &&
              ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 &&
               (*(char *)(lVar6 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_5e8 = 0;
              (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),4);
          uVar4 = psVar9[0xe];
          uVar16 = *(uint *)(psVar9 + 2);
        }
        if ((short)puVar19[(ulonglong)(uVar4 - 1) + 1] < 0) {
          lVar6 = *(longlong *)(psVar9 + 4);
          do {
            if (uVar4 == 1) {
              uVar15 = *(uint *)(psVar9 + 0xc);
              uVar16 = uVar15;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(psVar9 + 10) + lVar6 + (ulonglong)uVar4 * 2) &
                  0x7fff) < uVar15) goto LAB_;
            }
            else {
              uVar16 = *(uint *)(psVar9 + 0xc);
              uVar15 = *(ushort *)
                        ((ulonglong)*(uint *)(psVar9 + 10) + lVar6 + -2 + (ulonglong)uVar4 * 2) &
                       0x7fff;
              if (uVar16 <= uVar15) goto LAB_;
LAB_:
              func_0x(lVar6,7);
              uVar16 = *(uint *)(psVar9 + 0xc);
            }
            if ((uVar15 < uVar16) || (uVar16 = *(uint *)(psVar9 + 2), uVar16 < uVar15))
            goto LAB_;
            lVar6 = *(longlong *)(psVar9 + 4);
            if (*(ushort *)((ulonglong)uVar15 + lVar6) == 5) {
              psVar9[1] = psVar9[1] | 2;
              psVar9[0xe] = psVar9[0xe] + -1;
              psVar9[0x15] = (short)uVar15;
              lVar6 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(psVar9 + 4);
              uVar4 = psVar9[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar6 + 2) & 0x4000) != 0) {
                uVar4 = *(ushort *)(lVar6 + 2) & 0x3800 | psVar9[0x16] & 0xc7ffU;
              }
              psVar9[0x16] = uVar4;
              psVar9[0x16] = (uVar4 ^ *(ushort *)(lVar6 + 2)) & 0x7ff ^ uVar4;
              uVar7 = (ulonglong)*(uint *)(psVar9 + 2);
              pbVar21 = *(byte **)(psVar9 + 4);
              goto LAB_;
            }
            if (*(ushort *)((ulonglong)uVar15 + lVar6) < 0x400) break;
            psVar9[1] = psVar9[1] | 1;
            uVar4 = psVar9[0xe] - 1;
            psVar9[0xe] = uVar4;
            if ((uVar4 == 0) || (-1 < (short)puVar19[(ulonglong)(uVar4 - 1) + 1])) break;
          } while( true );
        }
        uVar7 = (ulonglong)uVar16;
        pbVar21 = *(byte **)(psVar9 + 4);
      }
LAB_:
      if ((*pbVar21 & 0x40) == 0) {
        *(undefined4 *)(psVar9 + 0x13) = 0;
      }
      else {
        *(int *)(psVar9 + 0x13) = (int)uVar7;
        *(int *)(psVar9 + 2) = (int)uVar7 + 0xe;
        puVar11 = (ulonglong *)func_0x(psVar9 + 1);
        uVar7 = *puVar11;
        uVar14 = (ushort)(uVar7 >> 0x30);
        uVar4 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar4 = uVar14 & 0xdfff;
          if ((uVar7 & 0x4000000000000000) != 0) {
            uVar4 = uVar14 | 0x2000;
          }
        }
        iVar20 = iVar5;
        if (uVar4 == 0xfffc) {
          iVar20 = (int)((uVar7 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar9 + 2) = *(int *)(psVar9 + 2) + iVar20;
        uVar7 = (ulonglong)*(uint *)(psVar9 + 2);
      }
      iVar20 = (int)uVar7;
      if ((*(ulonglong *)(psVar9 + 0xf) != 0) &&
         (*(ulonglong *)(psVar9 + 0xf) < uVar7 + *(longlong *)(psVar9 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar6 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar6 != 0 &&
             (lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0)) &&
            (*(char *)(lVar6 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_5e8 = 0;
            (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x877);
          }
        }
        func_0x(*(undefined8 *)(psVar9 + 4),0x12);
        iVar20 = *(int *)(psVar9 + 2);
      }
      if (0x3f3b < iVar20 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar6 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar6 != 0 &&
            ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_5e8 = 0;
            (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x87c);
          }
        }
        func_0x(*(undefined8 *)(psVar9 + 4),5);
      }
    }
LAB_:
    uVar15 = *(uint *)(psVar9 + 2);
    if (8 < uVar15) goto LAB_;
    bVar13 = **(byte **)(psVar9 + 4) & 0xe;
  }
  else {
    uVar15 = *(uint *)(psStack_5d0 + 2);
    if (uVar15 == 0) {
      func_0x(psStack_5d0 + 1);
      uVar15 = *(uint *)(psVar9 + 2);
    }
    if (8 < uVar15) goto LAB_;
    bVar13 = **(byte **)(psVar9 + 4) & 0x1c;
  }
  if ((bVar13 == 0) || (bVar13 == 0xc)) {
    uVar15 = 9;
  }
LAB_:
  uVar16 = 9;
  auStack_53a[uStack_53c] = (short)uVar15;
  uStack_554 = *param_5;
  uStack_53c = uStack_53c + 1;
  uStack_54c = *(undefined2 *)(param_5 + 1);
  uStack_556 = 0x1c;
  iStack_78 = (uint)uStack_53c * 2 + 0x1e;
  puStack_68 = auStack_558;
  puStack_60 = &uStack_4a8;
  iStack_74 = 0x428;
  if (*psVar9 == 0) {
    if (*(int *)(psVar9 + 2) == 0) {
      pbVar21 = *(byte **)(psVar9 + 4);
      uVar15 = *(uint *)(psVar9 + 8);
      uVar7 = (ulonglong)uVar15;
      psVar9[1] = 0;
      *(uint *)(psVar9 + 10) = uVar15;
      bVar13 = *pbVar21;
      if ((bVar13 & 0x10) != 0) {
        uVar15 = uVar15 + 2 + (*(ushort *)(pbVar21 + uVar7) + 7 >> 3);
        uVar7 = (ulonglong)uVar15;
        *(uint *)(psVar9 + 10) = uVar15;
        bVar13 = *pbVar21;
      }
      if ((bVar13 & 0x20) == 0) {
        *(int *)(psVar9 + 2) = (int)uVar7;
        psVar9[0xe] = 0;
        *(int *)(psVar9 + 0xc) = (int)uVar7;
      }
      else {
        puVar19 = (ushort *)(pbVar21 + uVar7);
        uVar4 = *puVar19;
        psVar9[0xe] = uVar4;
        if (uVar4 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar6 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar6 != 0)) &&
             ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_5e8 = 0;
              (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),3);
          uVar4 = psVar9[0xe];
          uVar7 = (ulonglong)*(uint *)(psVar9 + 10);
        }
        uVar15 = (int)uVar7 + (uVar4 + 1) * 2;
        *(uint *)(psVar9 + 0xc) = uVar15;
        if (0x1f9e < uVar15) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar6 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar6 != 0 &&
              ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 &&
               (*(char *)(lVar6 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_5e8 = 0;
              (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),4);
          uVar4 = psVar9[0xe];
          uVar15 = *(uint *)(psVar9 + 0xc);
        }
        uVar17 = puVar19[uVar4] & 0x7fff;
        *(uint *)(psVar9 + 2) = uVar17;
        if (uVar17 < uVar15) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar6 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar6 != 0)) &&
             ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_5e8 = 0;
              (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),4);
          uVar4 = psVar9[0xe];
          uVar17 = *(uint *)(psVar9 + 2);
        }
        uVar7 = (ulonglong)uVar17;
        if ((short)puVar19[(ulonglong)(uVar4 - 1) + 1] < 0) {
          lVar6 = *(longlong *)(psVar9 + 4);
          do {
            if (uVar4 == 1) {
              uVar15 = *(uint *)(psVar9 + 0xc);
              uVar17 = uVar15;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(psVar9 + 10) + lVar6 + (ulonglong)uVar4 * 2) &
                  0x7fff) < uVar15) goto LAB_;
            }
            else {
              uVar17 = *(uint *)(psVar9 + 0xc);
              uVar15 = *(ushort *)
                        ((ulonglong)*(uint *)(psVar9 + 10) + lVar6 + -2 + (ulonglong)uVar4 * 2) &
                       0x7fff;
              if (uVar17 <= uVar15) goto LAB_;
LAB_:
              func_0x(lVar6,7);
              uVar17 = *(uint *)(psVar9 + 0xc);
            }
            if ((uVar15 < uVar17) ||
               (uVar7 = (ulonglong)*(uint *)(psVar9 + 2), *(uint *)(psVar9 + 2) < uVar15))
            goto LAB_;
            lVar6 = *(longlong *)(psVar9 + 4);
            if (*(ushort *)((ulonglong)uVar15 + lVar6) == 5) {
              psVar9[1] = psVar9[1] | 2;
              psVar9[0xe] = psVar9[0xe] + -1;
              psVar9[0x15] = (short)uVar15;
              lVar6 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(psVar9 + 4);
              uVar4 = psVar9[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar6 + 2) & 0x4000) != 0) {
                uVar4 = *(ushort *)(lVar6 + 2) & 0x3800 | psVar9[0x16] & 0xc7ffU;
              }
              psVar9[0x16] = uVar4;
              psVar9[0x16] = (uVar4 ^ *(ushort *)(lVar6 + 2)) & 0x7ff ^ uVar4;
              uVar7 = (ulonglong)*(uint *)(psVar9 + 2);
              pbVar21 = *(byte **)(psVar9 + 4);
              goto LAB_;
            }
            if (*(ushort *)((ulonglong)uVar15 + lVar6) < 0x400) break;
            psVar9[1] = psVar9[1] | 1;
            uVar4 = psVar9[0xe] - 1;
            psVar9[0xe] = uVar4;
            if ((uVar4 == 0) || (-1 < (short)puVar19[(ulonglong)(uVar4 - 1) + 1])) break;
          } while( true );
        }
        pbVar21 = *(byte **)(psVar9 + 4);
      }
LAB_:
      if ((*pbVar21 & 0x40) == 0) {
        *(undefined4 *)(psVar9 + 0x13) = 0;
      }
      else {
        *(int *)(psVar9 + 0x13) = (int)uVar7;
        *(int *)(psVar9 + 2) = (int)uVar7 + 0xe;
        puVar11 = (ulonglong *)func_0x(psVar9 + 1);
        uVar7 = *puVar11;
        uVar14 = (ushort)(uVar7 >> 0x30);
        uVar4 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar4 = uVar14 & 0xdfff;
          if ((uVar7 & 0x4000000000000000) != 0) {
            uVar4 = uVar14 | 0x2000;
          }
        }
        if (uVar4 == 0xfffc) {
          iVar5 = (int)((uVar7 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar9 + 2) = *(int *)(psVar9 + 2) + iVar5;
        uVar7 = (ulonglong)*(uint *)(psVar9 + 2);
      }
      iVar5 = (int)uVar7;
      if ((*(ulonglong *)(psVar9 + 0xf) != 0) &&
         (*(ulonglong *)(psVar9 + 0xf) < uVar7 + *(longlong *)(psVar9 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar6 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar6 != 0 &&
             (lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0)) &&
            (*(char *)(lVar6 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_5e8 = 0;
            (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x877);
          }
        }
        func_0x(*(undefined8 *)(psVar9 + 4),0x12);
        iVar5 = *(int *)(psVar9 + 2);
      }
      if (0x3f3b < iVar5 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar6 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar6 != 0 &&
            ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_5e8 = 0;
            (*_DAT_)(1,0x13bc2e8,0x14dbfb8,0x87c);
          }
        }
        func_0x(*(undefined8 *)(psVar9 + 4),5);
      }
    }
LAB_:
    if ((8 < *(uint *)(psVar9 + 2)) ||
       (((**(byte **)(psVar9 + 4) & 0xe) != 0 && ((**(byte **)(psVar9 + 4) & 0xe) != 0xc)))) {
      uVar16 = *(uint *)(psVar9 + 2);
    }
  }
  else {
    uVar15 = *(uint *)(psVar9 + 2);
    if (uVar15 == 0) {
      func_0x(psVar9 + 1);
      uVar15 = *(uint *)(psVar9 + 2);
    }
    if ((8 < uVar15) ||
       (((**(byte **)(psVar9 + 4) & 0x1c) != 0 && ((**(byte **)(psVar9 + 4) & 0x1c) != 0xc)))) {
      uVar16 = uVar15;
    }
  }
  lVar8 = lStack_5d8;
  uStack_58 = *(undefined8 *)(psVar9 + 4);
  lVar6 = *(longlong *)(lStack_5d8 + 0x20);
  uStack_70 = uVar16;
  iVar5 = func_0x(lVar6);
  if (((iVar5 == 0) && (iVar5 = func_0x(lVar6), iVar5 == 0)) ||
     (*(char *)(lVar6 + 0x2050) != '\0')) {
    func_0x(*(undefined8 *)(lVar6 + 0x6b0));
    uVar16 = uStack_70;
  }
  puVar3 = puStack_68;
  uStack_580 = 0;
  uStack_57c = 0xffffffffffffffff;
  uStack_574 = 0;
  uStack_5c8 = 0;
  uStack_5b8 = 3;
  iStack_5c0 = (uVar16 + 3 & 0xfffffffc) + (iStack_74 + 3U & 0xfffffffc) +
               (iStack_78 + 3U & 0xfffffffc);
  uStack_5a0 = 0;
  piStack_5b0 = &iStack_78;
  ppuStack_5a8 = &puStack_68;
  uStack_598 = 0;
  puStack_590 = auStack_4b8;
  uStack_588 = 0;
  (**(code **)(**(longlong **)(lVar6 + 0x6c8) + 0x2c8))(*(longlong **)(lVar6 + 0x6c8),&uStack_5c8);
  func_0x(lVar6,puVar3);
  plVar2 = *(longlong **)(*(longlong *)(lVar8 + 0x20) + 0x6c8);
  uStack_568 = 0;
  uStack_560 = 0;
  (**(code **)(*plVar2 + 0x90))(plVar2,&uStack_568,0);
  func_0x(uStack_50 ^ (ulonglong)auStack_608);
  return;
}

