
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2)

{
  undefined uVar1;
  ushort uVar2;
  undefined2 uVar3;
  ushort uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  code *pcVar7;
  undefined8 uVar8;
  int *piVar9;
  char cVar10;
  char cVar11;
  uint uVar12;
  int iVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  undefined8 *puVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  ulonglong uVar20;
  ulonglong uVar21;
  longlong lVar22;
  ushort uVar23;
  longlong unaff_GS_OFFSET;
  bool bVar24;
  char acStackX_8 [4];
  undefined4 uStackX_c;
  undefined4 auStackX_10 [2];
  longlong lStackX_20;
  ulonglong uStack_1098;
  ulonglong uStack_1090;
  undefined8 uStack_1088;
  ushort *puStack_1080;
  longlong lStack_1078;
  undefined4 uStack_1070;
  undefined auStack_1068 [16];
  undefined8 uStack_1058;
  undefined2 uStack_1050;
  undefined2 uStack_104e;
  undefined auStack_1048 [4096];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x100022;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar14);
  *(undefined8 *)(&stack0x00000018 + lVar14) = _DAT_;
  param_1[0x18] = 0;
  *(undefined2 *)(param_1 + 0x19) = 0;
  uVar1 = *(undefined *)(param_1[3] + 0x2050);
  *(undefined *)(param_1 + 0x16) = uVar1;
  *(undefined *)((longlong)param_1 + 0xb1) = uVar1;
  *(undefined *)((longlong)param_1 + 0xb2) = 1;
  *(undefined8 *)((longlong)param_1 + 0xcc) = *(undefined8 *)(param_1[0x17] + 0x140);
  *(undefined4 *)((longlong)param_1 + 0xd4) = *(undefined4 *)(param_1[0x17] + 0x148);
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1000a7;
  uStack_1088 = param_2;
  func_0x(param_1);
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1000ad;
  (*_DAT_)();
  if (param_1[1] != 0) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1000d8;
    (*_DAT_)(1,0xa723e8,0xa19c80,0xd9);
  }
  *param_1 = (longlong)param_1;
  plVar6 = *(longlong **)(param_1[3] + 0x6c8);
  pcVar7 = *(code **)(*plVar6 + 0x290);
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1000f2;
  lVar15 = (*pcVar7)(plVar6);
  pcVar7 = *(code **)(*plVar6 + 0x240);
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100101;
  lVar16 = (*pcVar7)(plVar6);
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar14) = 2;
  param_1[1] = lVar16;
  *(undefined *)(lVar15 + 0xd1) = 1;
  plVar6 = (longlong *)param_1[1];
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar14) = 1;
  (&stack0xffffffffffffffe8)[lVar14] = 1;
  pcVar7 = *(code **)(*plVar6 + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100139;
  (*pcVar7)(plVar6,0x6c8020,0x1c,0);
  uVar8 = *(undefined8 *)(*param_1 + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100149;
  puVar17 = (undefined8 *)func_0x(auStack_1068,uVar8);
  plVar6 = (longlong *)param_1[1];
  *(undefined8 *)((longlong)&lStackX_20 + lVar14 + -0x20) = 0;
  (&stack0xfffffffffffffff8)[lVar14] = 0;
  uVar8 = *puVar17;
  lVar15 = *plVar6;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) = 0;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 3;
  pcVar7 = *(code **)(lVar15 + 0x28);
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100175;
  (*pcVar7)(plVar6,uVar8,5,1);
  uVar20 = _DAT_;
  if (*_DAT_ != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10018c;
    (*_DAT_)(&stack0x00000030 + lVar14);
    uVar20 = *(ulonglong *)(&stack0x00000030 + lVar14);
  }
  param_1[0x13] = uVar20;
  while( true ) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1001b9;
    cVar10 = func_0x(param_1,acStackX_8 + lVar14,&stack0x00000018 + lVar14,
                             (longlong)&lStackX_20 + lVar14);
    cVar11 = acStackX_8[lVar14];
    while (cVar11 != '\0') {
      if (((*(byte *)(*(longlong *)(*param_1 + 0x18) + 0x1cd0) & 4) != 0) ||
         (*(char *)(*(longlong *)(*param_1 + 0xb8) + 0x88) != '\0')) goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10020f;
      cVar10 = func_0x(param_1,acStackX_8 + lVar14,&stack0x00000018 + lVar14,
                               (longlong)&lStackX_20 + lVar14);
      cVar11 = acStackX_8[lVar14];
    }
    if ((((*(byte *)(*(longlong *)(*param_1 + 0x18) + 0x1cd0) & 4) != 0) ||
        (*(char *)(*(longlong *)(*param_1 + 0xb8) + 0x88) != '\0')) || (cVar10 == '\0')) break;
    lVar15 = *(longlong *)((longlong)&lStackX_20 + lVar14);
    uVar2 = *(ushort *)(lVar15 + 2);
    if (uVar2 != 0) {
      uVar3 = *(undefined2 *)(lVar15 + 0x14);
      uVar5 = *(undefined4 *)(lVar15 + 0x10);
      *(undefined4 *)(param_1 + 5) = *(undefined4 *)(lVar15 + 0xc);
      piVar9 = _DAT_;
      *(undefined4 *)((longlong)param_1 + 0x2c) = uVar5;
      *(undefined2 *)(param_1 + 6) = uVar3;
      if (*piVar9 == 0) {
        lVar15 = *(longlong *)((longlong)&lStackX_20 + lVar14);
        uVar20 = _DAT_;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100288;
        (*_DAT_)(&stack0x00000038 + lVar14);
        uVar20 = *(ulonglong *)(&stack0x00000038 + lVar14);
      }
      uVar23 = 1;
      puStack_1080 = (ushort *)(lVar15 + 4);
      lVar16 = uVar20 - param_1[0x13];
      if (uVar20 < (ulonglong)param_1[0x13]) {
        lVar16 = 0;
      }
      param_1[9] = param_1[9] + 1;
      param_1[0x10] = param_1[0x10] + lVar16;
      uVar4 = *(ushort *)(lVar15 + 6);
      if (uVar4 <= *puStack_1080) {
        uVar4 = *puStack_1080;
      }
      param_1[0xd] = param_1[0xd] + (ulonglong)uVar4;
      if (uVar2 != 0) {
        do {
          param_1[10] = param_1[10] + 1;
          *(ushort *)(param_1 + 6) = uVar23;
          lVar16 = (ulonglong)
                   *(ushort *)((ulonglong)*puStack_1080 + (ulonglong)uVar23 * -2 + lVar15) + lVar15;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100320;
          uVar12 = func_0x(param_1,lVar16,acStackX_8 + lVar14 + 1,param_2);
          uVar20 = (ulonglong)uVar12;
          if (uVar12 == 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100658;
            cVar11 = func_0x(param_1);
            if (cVar11 == '\0') {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100680;
              (*_DAT_)(1,0xa61560,0xa19c80,0xa51);
            }
            goto LAB_;
          }
          if (*(char *)(lVar16 + 0x16) == -0x1a) {
            param_1[0xb] = param_1[0xb] + 1;
          }
          if (uVar12 == 0x8200001b) goto LAB_;
          if (uVar12 == 0x84000002) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100354;
            cVar11 = func_0x(param_1);
            if (cVar11 != '\0') goto LAB_;
          }
          if ((int)uVar20 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100374;
            uVar18 = func_0x(uVar20 & 0xffffffff,auStack_1048);
            uStack_1070 = *(undefined4 *)(param_1 + 6);
            lStack_1078 = param_1[5];
            lVar15 = param_1[3];
            *(undefined4 *)((longlong)auStackX_10 + lVar14) = 0;
            uVar8 = *(undefined8 *)(lVar15 + 0x6b0);
            pcVar7 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1003a7;
            uVar19 = (*pcVar7)(uVar8,(longlong)auStackX_10 + lVar14);
            lVar15 = param_1[3];
            *(undefined4 *)(acStackX_8 + lVar14 + 4) = 0;
            uVar8 = *(undefined8 *)(lVar15 + 0x6b0);
            pcVar7 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1003ca;
            (*pcVar7)(uVar8,acStackX_8 + lVar14 + 4);
            uVar5 = *(undefined4 *)(acStackX_8 + lVar14 + 4);
            *(undefined8 *)((longlong)&lStackX_20 + lVar14 + -0x20) = uVar19;
            *(undefined4 *)(&stack0xfffffffffffffff8 + lVar14) = uVar5;
            *(longlong **)(&stack0xfffffffffffffff0 + lVar14) = &lStack_1078;
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = uVar18;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1003fd;
            (*_DAT_)(0x19d,0x37,0x15,1);
            lVar15 = *(longlong *)((longlong)&lStackX_20 + lVar14);
          }
          if (acStackX_8[lVar14 + 1] != '\0') {
            uVar20 = _DAT_;
            if (*_DAT_ != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100424;
              (*_DAT_)(&stack0x00000040 + lVar14);
              uVar20 = *(ulonglong *)(&stack0x00000040 + lVar14);
            }
            param_1[0x15] = uVar20;
            lVar15 = *(longlong *)(param_1[3] + 0x6b0);
            uVar20 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
            if (*(int *)(lVar15 + 0x1500) == 0) {
              LOCK();
              bVar24 = *(ulonglong *)(lVar15 + 0x1500) == 0;
              if (bVar24) {
                *(ulonglong *)(lVar15 + 0x1500) = uVar20;
              }
              UNLOCK();
              if (!bVar24) goto LAB_;
            }
            else {
LAB_:
              lVar16 = 0;
              uVar21 = 0;
              if (((byte)*_DAT_ & 0x84) == 0x84) {
                lVar22 = (ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
                if ((lVar22 != 0) && (*(longlong *)(lVar22 + 0x110) == lVar22)) {
                  lVar16 = *(longlong *)(lVar22 + 0x100);
                }
                if ((lVar16 != 0) && (uVar21 = _DAT_, *_DAT_ != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1004dc;
                  (*_DAT_)(&uStack_1098);
                  uVar21 = uStack_1098;
                }
              }
              if (*(char *)(_DAT_ + 199) < '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10050c;
                func_0x(lVar15 + 0x1500,lVar16,uVar20);
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100516;
                func_0x(lVar15 + 0x1500,uVar20);
              }
              if (lVar16 != 0) {
                uVar20 = _DAT_;
                if (*_DAT_ != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100531;
                  (*_DAT_)(&uStack_1090);
                  uVar20 = uStack_1090;
                }
                lVar15 = 0;
                if (uVar21 <= uVar20) {
                  lVar15 = uVar20 - uVar21;
                }
                *(longlong *)(lVar16 + 0xc78) = *(longlong *)(lVar16 + 0xc78) + lVar15;
              }
            }
            lVar15 = param_1[3];
            uStack_1058 = *(undefined8 *)(lVar15 + 0x908);
            uStack_1050 = *(undefined2 *)(lVar15 + 0x910);
            uStack_104e = *(undefined2 *)(lVar15 + 0x912);
            plVar6 = (longlong *)param_1[0x17];
            pcVar7 = *(code **)(*plVar6 + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100596;
            (*pcVar7)(plVar6,&uStack_1058);
            lVar15 = *(longlong *)(param_1[3] + 0x6b0);
            if (*_DAT_ != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1005b3;
              iVar13 = (*_DAT_)();
              if (iVar13 == (iVar13 / 5) * 5) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1005d4;
                func_0x();
              }
            }
            *(undefined8 *)(lVar15 + 0x1500) = 0;
            if (*(char *)((longlong)param_1 + 0xb1) == '\0') {
              lVar15 = param_1[0x17];
              *(undefined4 *)(lVar15 + 0xc0) = 1;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100603;
              func_0x(lVar15 + 0x90,0);
            }
            lVar15 = *(longlong *)((longlong)&lStackX_20 + lVar14);
            *(undefined *)((longlong)param_1 + 0xb2) = 1;
            param_2 = uStack_1088;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10061b;
          cVar11 = func_0x(param_1);
          if (cVar11 != '\0') goto LAB_;
          uVar23 = uVar23 + 1;
        } while (uVar23 <= uVar2);
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10063d;
      func_0x(0x5f);
    }
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100698;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar14));
  return;
}

