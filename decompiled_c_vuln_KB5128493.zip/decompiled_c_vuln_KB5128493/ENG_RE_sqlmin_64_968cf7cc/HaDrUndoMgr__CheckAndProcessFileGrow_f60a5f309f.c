
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,short *param_2,short *param_3,longlong param_4)

{
  ushort *puVar1;
  byte *pbVar2;
  longlong *plVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  int iVar7;
  ulonglong *puVar8;
  longlong lVar9;
  uint *puVar10;
  ushort uVar11;
  short sVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  uint *puVar16;
  uint uVar17;
  int iVar18;
  ushort *puVar19;
  longlong unaff_GS_OFFSET;
  int aiStackX_10 [2];
  uint auStackX_18 [2];
  longlong lStackX_20;
  ulonglong in_stack_ffffffffffffff68;
  uint *puVar20;
  uint uStack_78;
  undefined auStack_74 [4];
  undefined auStack_70 [4];
  uint uStack_6c;
  undefined2 uStack_68;
  uint uStack_60;
  ushort uStack_5c;
  ushort uStack_5a;
  int *piStack_58;
  
  puVar16 = (uint *)0x0;
  puVar20 = (uint *)(in_stack_ffffffffffffff68 & 0xffffffff00000000);
  lStackX_20 = param_4;
  func_0x(&uStack_60,0xfffffffb,5,0,puVar20);
  puVar1 = (ushort *)(param_2 + 1);
  iVar18 = 1;
  iVar7 = 0;
  if (*param_2 == 0) {
    if ((uStack_60 & 0xc0000000) == 0x80000000) {
      iVar6 = func_0x(puVar1);
      if (iVar6 == 0) {
LAB_:
        puVar10 = (uint *)0x0;
        aiStackX_10[0] = 0;
      }
      else {
        puVar10 = (uint *)func_0x(param_2 + 0x15,&uStack_60,aiStackX_10,auStack_74);
      }
    }
    else {
      pbVar2 = *(byte **)(param_2 + 4);
      bVar4 = *pbVar2;
      iVar6 = iVar7;
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
          uVar5 = ~(uStack_5a >> 4);
          goto LAB_;
        }
LAB_:
        if ((int)uStack_60 < 0) {
          if (*(int *)(param_2 + 2) == 0) {
            uVar13 = *(uint *)(param_2 + 8);
            uVar15 = (ulonglong)uVar13;
            *(uint *)(param_2 + 10) = uVar13;
            *puVar1 = 0;
            bVar4 = *pbVar2;
            if ((bVar4 & 0x10) != 0) {
              uVar13 = uVar13 + 2 + (*(ushort *)(pbVar2 + uVar15) + 7 >> 3);
              uVar15 = (ulonglong)uVar13;
              *(uint *)(param_2 + 10) = uVar13;
              bVar4 = *pbVar2;
            }
            if ((bVar4 & 0x20) == 0) {
              *(int *)(param_2 + 2) = (int)uVar15;
              param_2[0xe] = 0;
              *(int *)(param_2 + 0xc) = (int)uVar15;
            }
            else {
              puVar19 = (ushort *)(pbVar2 + uVar15);
              uVar5 = *puVar19;
              param_2[0xe] = uVar5;
              if (uVar5 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar9 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar9 != 0)) &&
                   ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    puVar20 = (uint *)0x0;
                    (*_DAT_)(1,0x20f1718,0x22113e8,0x80f,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),3);
                uVar15 = (ulonglong)*(uint *)(param_2 + 10);
                uVar5 = param_2[0xe];
              }
              uVar13 = (int)uVar15 + (uVar5 + 1) * 2;
              *(uint *)(param_2 + 0xc) = uVar13;
              if (0x1f9e < uVar13) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar9 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar9 != 0 &&
                    ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                     (*(char *)(lVar9 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puVar20 = (uint *)0x0;
                    (*_DAT_)(1,0x20f1718,0x22113e8,0x816,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),4);
                uVar5 = param_2[0xe];
                uVar13 = *(uint *)(param_2 + 0xc);
              }
              uVar15 = (ulonglong)uVar5;
              uVar5 = puVar19[uVar15];
              *(uint *)(param_2 + 2) = uVar5 & 0x7fff;
              if ((uVar5 & 0x7fff) < uVar13) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar9 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar9 != 0)) &&
                   ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puVar20 = (uint *)0x0;
                    (*_DAT_)(1,0x20f1718,0x22113e8,0x81d,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),4);
                uVar15 = (ulonglong)(ushort)param_2[0xe];
              }
              if ((short)puVar19[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                lVar9 = *(longlong *)(param_2 + 4);
                do {
                  if ((int)uVar15 == 1) {
                    uVar13 = *(uint *)(param_2 + 0xc);
                    uVar14 = uVar13;
LAB_:
                    if ((*(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar9 + uVar15 * 2) &
                        0x7fff) < uVar13) goto LAB_;
                  }
                  else {
                    uVar14 = *(uint *)(param_2 + 0xc);
                    uVar13 = *(ushort *)
                              ((ulonglong)*(uint *)(param_2 + 10) + lVar9 + -2 + uVar15 * 2) &
                             0x7fff;
                    if (uVar14 <= uVar13) goto LAB_;
LAB_:
                    func_0x(lVar9,7);
                    uVar14 = *(uint *)(param_2 + 0xc);
                  }
                  if ((uVar13 < uVar14) || (*(uint *)(param_2 + 2) < uVar13)) goto LAB_;
                  lVar9 = *(longlong *)(param_2 + 4);
                  if (*(ushort *)(lVar9 + (ulonglong)uVar13) == 5) {
                    *puVar1 = *puVar1 | 2;
                    param_2[0xe] = param_2[0xe] + -1;
                    param_2[0x15] = (short)uVar13;
                    lVar9 = (ulonglong)(uVar13 & 0xffff) + *(longlong *)(param_2 + 4);
                    uVar5 = param_2[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar9 + 2) >> 0xe & 1) != 0) {
                      uVar5 = *(ushort *)(lVar9 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                    }
                    param_2[0x16] = uVar5;
                    param_2[0x16] = (uVar5 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar5;
                    goto LAB_;
                  }
                  if (*(ushort *)(lVar9 + (ulonglong)uVar13) < 0x400) goto LAB_;
                  *puVar1 = *puVar1 | 1;
                  uVar5 = param_2[0xe] - 1;
                  param_2[0xe] = uVar5;
                  if (uVar5 == 0) goto LAB_;
                  uVar15 = (ulonglong)uVar5;
                } while ((short)puVar19[(ulonglong)(uVar5 - 1) + 1] < 0);
                uVar15 = (ulonglong)*(uint *)(param_2 + 2);
              }
              else {
LAB_:
                uVar15 = (ulonglong)*(uint *)(param_2 + 2);
              }
            }
            if ((**(byte **)(param_2 + 4) & 0x40) == 0) {
              *(undefined4 *)(param_2 + 0x13) = 0;
            }
            else {
              *(int *)(param_2 + 0x13) = (int)uVar15;
              *(int *)(param_2 + 2) = (int)uVar15 + 0xe;
              puVar8 = (ulonglong *)func_0x(puVar1);
              uVar11 = (ushort)(*puVar8 >> 0x30);
              uVar5 = uVar11;
              if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
                uVar5 = uVar11 & 0xdfff;
                if ((uVar11 >> 0xe & 1) != 0) {
                  uVar5 = uVar11 | 0x2000;
                }
              }
              iVar6 = iVar7;
              if (uVar5 == 0xfffc) {
                iVar6 = (int)((*puVar8 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar6;
              uVar15 = (ulonglong)*(uint *)(param_2 + 2);
            }
            iVar6 = (int)uVar15;
            if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
               (*(ulonglong *)(param_2 + 0xf) < uVar15 + *(longlong *)(param_2 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar9 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                   lVar9 != 0 && (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) &&
                  (*(char *)(lVar9 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  puVar20 = (uint *)0x0;
                  (*_DAT_)(1,0x20f1718,0x22113e8,0x877,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),0x12);
              iVar6 = *(int *)(param_2 + 2);
            }
            if (0x3f3b < iVar6 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar9 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar9 != 0 &&
                  ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                   (*(char *)(lVar9 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  puVar20 = (uint *)0x0;
                  (*_DAT_)(1,0x20f1718,0x22113e8,0x87c,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),5);
            }
          }
LAB_:
          sVar12 = -(short)uStack_60;
          if ((uStack_5a & 0x10) != 0) {
            bVar4 = **(byte **)(param_2 + 4);
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                aiStackX_10[0] = *piStack_58;
                puVar10 = (uint *)(piStack_58 + 1);
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_2 + 8) <= (int)uStack_60) ||
                    (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) < uStack_5c))
            goto LAB_;
          }
          puVar10 = *(uint **)(param_2 + 4);
          lVar9 = (longlong)sVar12;
          if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar12) {
            aiStackX_10[0] = 0;
          }
          else {
            uVar13 = *(uint *)(param_2 + 10);
            if (sVar12 == 1) {
              uVar14 = *(uint *)(param_2 + 0xc);
              uVar13 = *(ushort *)((longlong)puVar10 + lVar9 * 2 + (ulonglong)uVar13) & 0x7fff;
LAB_:
              if (uVar13 < uVar14) goto LAB_;
            }
            else {
              puVar1 = (ushort *)((longlong)puVar10 + lVar9 * 2 + (ulonglong)uVar13);
              uVar14 = *(ushort *)((longlong)puVar10 + lVar9 * 2 + ((ulonglong)uVar13 - 2)) & 0x7fff
              ;
              puVar10 = *(uint **)(param_2 + 4);
              uVar13 = *puVar1 & 0x7fff;
              if (*(uint *)(param_2 + 0xc) <= uVar14) goto LAB_;
LAB_:
              func_0x(puVar10,7);
              puVar10 = *(uint **)(param_2 + 4);
            }
            puVar10 = (uint *)((longlong)puVar10 + (ulonglong)uVar14);
            aiStackX_10[0] = uVar13 - uVar14;
          }
        }
        else if ((uStack_5a & 8) == 0) {
          if ((uStack_5a & 0x10) != 0) {
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                aiStackX_10[0] = *piStack_58;
                puVar10 = (uint *)(piStack_58 + 1);
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_2 + 8) <= (int)uStack_60) ||
                    (*(ushort *)(pbVar2 + *(uint *)(param_2 + 8)) < uStack_5c)) goto LAB_;
          }
          puVar10 = (uint *)(pbVar2 + (int)uStack_60);
          aiStackX_10[0] = 0;
        }
        else {
          puVar10 = (uint *)0x1e76154;
          aiStackX_10[0] = 1;
          if ((pbVar2[(int)uStack_60] & (byte)(1 << ((byte)uStack_5a & 7))) == 0) {
            puVar10 = (uint *)0x1e76778;
          }
        }
      }
      else {
        uVar13 = *(uint *)(param_2 + 8);
        if ((int)uStack_60 < (int)uVar13) {
          if ((uint)*(ushort *)(pbVar2 + uVar13) < (uint)uStack_5c) {
            uVar5 = ~(uStack_5a >> 4);
          }
          else {
            uVar14 = uStack_5c - 1;
            uVar5 = (ushort)(pbVar2[(ulonglong)uVar13 + (ulonglong)(uVar14 >> 3) + 2] >>
                            ((byte)uVar14 & 7));
            iVar6 = iVar18;
          }
        }
        else {
          uVar5 = ~(uStack_5a >> 4);
        }
LAB_:
        if ((uVar5 & 1) == 0) {
          if ((iVar6 != 0) || ((uStack_5a & 0x10) == 0)) goto LAB_;
          aiStackX_10[0] = *piStack_58;
          puVar10 = (uint *)(piStack_58 + 1);
        }
        else {
          aiStackX_10[0] = 0;
          puVar10 = puVar16;
        }
      }
    }
  }
  else {
    puVar20 = auStackX_18;
    auStackX_18[0] = 0;
    puVar10 = (uint *)func_0x(puVar1,&uStack_60);
    if ((((*param_2 != 0) && (plVar3 = *(longlong **)(param_2 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) && (((uStack_5a & 8) == 0 && ((auStackX_18[0] & 1) == 0)))) {
      if ((puVar10 == (uint *)0x0) || (puVar10 == (uint *)0x1e76154)) goto LAB_;
      puVar20 = (uint *)0x0;
      puVar10 = (uint *)func_0x(plVar3,&uStack_60,puVar10,aiStackX_10[0],0,0,aiStackX_10,
                                        auStackX_18[0]);
    }
  }
LAB_:
  puVar1 = (ushort *)(param_3 + 1);
  uVar13 = *puVar10;
  if (*param_3 != 0) {
    puVar20 = &uStack_78;
    uStack_78 = 0;
    puVar10 = (uint *)func_0x(puVar1,&uStack_60);
    if ((((*param_3 != 0) && (plVar3 = *(longlong **)(param_3 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) && (((uStack_5a & 8) == 0 && ((uStack_78 & 1) == 0)))) {
      if ((puVar10 == (uint *)0x0) || (puVar10 == (uint *)0x1e76154)) {
        aiStackX_10[0] = 0;
        puVar10 = puVar16;
      }
      else {
        puVar20 = (uint *)0x0;
        puVar10 = (uint *)func_0x(plVar3,&uStack_60,puVar10,aiStackX_10[0],0,0,aiStackX_10,
                                          uStack_78);
      }
    }
    goto LAB_;
  }
  if ((uStack_60 & 0xc0000000) == 0x80000000) {
    iVar7 = func_0x(puVar1);
    if (iVar7 == 0) {
      aiStackX_10[0] = 0;
      puVar10 = (uint *)0x0;
    }
    else {
      puVar10 = (uint *)func_0x(param_3 + 0x15,&uStack_60,aiStackX_10,auStack_70,puVar20);
    }
    goto LAB_;
  }
  pbVar2 = *(byte **)(param_3 + 4);
  bVar4 = *pbVar2;
  if ((bVar4 & 0x10) == 0) {
    if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
      uVar5 = ~(uStack_5a >> 4);
      iVar18 = iVar7;
      goto LAB_;
    }
  }
  else {
    uVar14 = *(uint *)(param_3 + 8);
    if ((int)uStack_60 < (int)uVar14) {
      if ((uint)*(ushort *)(pbVar2 + uVar14) < (uint)uStack_5c) {
        uVar5 = ~(uStack_5a >> 4);
        iVar18 = iVar7;
      }
      else {
        uVar17 = uStack_5c - 1;
        uVar5 = (ushort)(pbVar2[(ulonglong)uVar14 + (ulonglong)(uVar17 >> 3) + 2] >>
                        ((byte)uVar17 & 7));
      }
    }
    else {
      uVar5 = ~(uStack_5a >> 4);
      iVar18 = iVar7;
    }
LAB_:
    if ((uVar5 & 1) != 0) {
      aiStackX_10[0] = 0;
      puVar10 = puVar16;
      goto LAB_;
    }
    if ((iVar18 == 0) && ((uStack_5a & 0x10) != 0)) {
      aiStackX_10[0] = *piStack_58;
      puVar10 = (uint *)(piStack_58 + 1);
      goto LAB_;
    }
  }
  if ((int)uStack_60 < 0) {
    if (*(int *)(param_3 + 2) == 0) {
      uVar14 = *(uint *)(param_3 + 8);
      uVar15 = (ulonglong)uVar14;
      *(uint *)(param_3 + 10) = uVar14;
      *puVar1 = 0;
      bVar4 = *pbVar2;
      if ((bVar4 & 0x10) != 0) {
        uVar14 = uVar14 + 2 + (*(ushort *)(pbVar2 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar14;
        *(uint *)(param_3 + 10) = uVar14;
        bVar4 = *pbVar2;
      }
      if ((bVar4 & 0x20) == 0) {
        *(int *)(param_3 + 2) = (int)uVar15;
        param_3[0xe] = 0;
        *(int *)(param_3 + 0xc) = (int)uVar15;
      }
      else {
        puVar19 = (ushort *)(pbVar2 + uVar15);
        uVar5 = *puVar19;
        param_3[0xe] = uVar5;
        if (uVar5 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar9 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar9 != 0)) &&
             ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puVar20 = (uint *)0x0;
              (*_DAT_)(1,0x20f1718,0x22113e8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),3);
          uVar15 = (ulonglong)*(uint *)(param_3 + 10);
          uVar5 = param_3[0xe];
        }
        uVar14 = (int)uVar15 + (uVar5 + 1) * 2;
        *(uint *)(param_3 + 0xc) = uVar14;
        if (0x1f9e < uVar14) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar9 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar9 != 0 &&
              ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
               (*(char *)(lVar9 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puVar20 = (uint *)0x0;
              (*_DAT_)(1,0x20f1718,0x22113e8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),4);
          uVar5 = param_3[0xe];
          uVar14 = *(uint *)(param_3 + 0xc);
        }
        uVar15 = (ulonglong)uVar5;
        uVar5 = puVar19[uVar15];
        *(uint *)(param_3 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar14) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar9 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar9 != 0)) &&
             ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puVar20 = (uint *)0x0;
              (*_DAT_)(1,0x20f1718,0x22113e8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),4);
          uVar15 = (ulonglong)(ushort)param_3[0xe];
        }
        if ((short)puVar19[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          lVar9 = *(longlong *)(param_3 + 4);
          do {
            if ((int)uVar15 == 1) {
              uVar14 = *(uint *)(param_3 + 0xc);
              uVar17 = uVar14;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(param_3 + 10) + lVar9 + uVar15 * 2) & 0x7fff) <
                  uVar14) goto LAB_;
            }
            else {
              uVar17 = *(uint *)(param_3 + 0xc);
              uVar14 = *(ushort *)((ulonglong)*(uint *)(param_3 + 10) + lVar9 + -2 + uVar15 * 2) &
                       0x7fff;
              if (uVar17 <= uVar14) goto LAB_;
LAB_:
              func_0x(lVar9,7);
              uVar17 = *(uint *)(param_3 + 0xc);
            }
            if ((uVar14 < uVar17) || (*(uint *)(param_3 + 2) < uVar14)) goto LAB_;
            lVar9 = *(longlong *)(param_3 + 4);
            if (*(ushort *)((ulonglong)uVar14 + lVar9) == 5) {
              *puVar1 = *puVar1 | 2;
              param_3[0xe] = param_3[0xe] + -1;
              param_3[0x15] = (short)uVar14;
              lVar9 = (ulonglong)(uVar14 & 0xffff) + *(longlong *)(param_3 + 4);
              uVar5 = param_3[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar9 + 2) >> 0xe & 1) != 0) {
                uVar5 = *(ushort *)(lVar9 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
              }
              param_3[0x16] = uVar5;
              param_3[0x16] = (uVar5 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar5;
              goto LAB_;
            }
            if (*(ushort *)((ulonglong)uVar14 + lVar9) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar5 = param_3[0xe] - 1;
            param_3[0xe] = uVar5;
            if (uVar5 == 0) goto LAB_;
            uVar15 = (ulonglong)uVar5;
          } while ((short)puVar19[(ulonglong)(uVar5 - 1) + 1] < 0);
          uVar15 = (ulonglong)*(uint *)(param_3 + 2);
        }
        else {
LAB_:
          uVar15 = (ulonglong)*(uint *)(param_3 + 2);
        }
      }
      if ((**(byte **)(param_3 + 4) & 0x40) == 0) {
        *(undefined4 *)(param_3 + 0x13) = 0;
      }
      else {
        *(int *)(param_3 + 0x13) = (int)uVar15;
        *(int *)(param_3 + 2) = (int)uVar15 + 0xe;
        puVar8 = (ulonglong *)func_0x(puVar1);
        uVar11 = (ushort)(*puVar8 >> 0x30);
        uVar5 = uVar11;
        if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
          uVar5 = uVar11 & 0xdfff;
          if ((uVar11 >> 0xe & 1) != 0) {
            uVar5 = uVar11 | 0x2000;
          }
        }
        if (uVar5 == 0xfffc) {
          iVar7 = (int)((*puVar8 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar7;
        uVar15 = (ulonglong)*(uint *)(param_3 + 2);
      }
      iVar7 = (int)uVar15;
      if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
         (*(ulonglong *)(param_3 + 0xf) < uVar15 + *(longlong *)(param_3 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar9 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar9 != 0 &&
             (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) &&
            (*(char *)(lVar9 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puVar20 = (uint *)0x0;
            (*_DAT_)(1,0x20f1718,0x22113e8,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(param_3 + 4),0x12);
        iVar7 = *(int *)(param_3 + 2);
      }
      if (0x3f3b < iVar7 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar9 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar9 != 0 &&
            ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puVar20 = (uint *)0x0;
            (*_DAT_)(1,0x20f1718,0x22113e8,0x87c,0);
          }
        }
        func_0x(*(undefined8 *)(param_3 + 4),5);
      }
    }
LAB_:
    sVar12 = -(short)uStack_60;
    if ((uStack_5a & 0x10) != 0) {
      bVar4 = **(byte **)(param_3 + 4);
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
          aiStackX_10[0] = *piStack_58;
          puVar10 = (uint *)(piStack_58 + 1);
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_3 + 8) <= (int)uStack_60) ||
              (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) < uStack_5c))
      goto LAB_;
    }
    puVar10 = *(uint **)(param_3 + 4);
    lVar9 = (longlong)sVar12;
    if ((uint)(int)sVar12 <= (uint)(ushort)param_3[0xe]) {
      uVar14 = *(uint *)(param_3 + 10);
      if (sVar12 == 1) {
        uVar17 = *(uint *)(param_3 + 0xc);
        uVar14 = *(ushort *)((longlong)puVar10 + lVar9 * 2 + (ulonglong)uVar14) & 0x7fff;
LAB_:
        if (uVar14 < uVar17) goto LAB_;
      }
      else {
        puVar1 = (ushort *)((longlong)puVar10 + lVar9 * 2 + (ulonglong)uVar14);
        uVar17 = *(ushort *)((longlong)puVar10 + lVar9 * 2 + ((ulonglong)uVar14 - 2)) & 0x7fff;
        puVar10 = *(uint **)(param_3 + 4);
        uVar14 = *puVar1 & 0x7fff;
        if (*(uint *)(param_3 + 0xc) <= uVar17) goto LAB_;
LAB_:
        func_0x(puVar10,7);
        puVar10 = *(uint **)(param_3 + 4);
      }
      aiStackX_10[0] = uVar14 - uVar17;
      puVar10 = (uint *)((longlong)puVar10 + (ulonglong)uVar17);
      goto LAB_;
    }
  }
  else {
    if ((uStack_5a & 8) != 0) {
      aiStackX_10[0] = 1;
      puVar10 = (uint *)0x1e76154;
      if ((pbVar2[(int)uStack_60] & (byte)(1 << ((byte)uStack_5a & 7))) == 0) {
        puVar10 = (uint *)0x1e76778;
      }
      goto LAB_;
    }
    if ((uStack_5a & 0x10) != 0) {
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) == 0) goto LAB_;
      }
      else if ((int)uStack_60 < (int)*(uint *)(param_3 + 8)) {
        if (*(ushort *)(pbVar2 + *(uint *)(param_3 + 8)) < uStack_5c) {
          aiStackX_10[0] = *piStack_58;
          puVar10 = (uint *)(piStack_58 + 1);
          goto LAB_;
        }
        goto LAB_;
      }
      goto LAB_;
    }
LAB_:
    puVar10 = (uint *)(pbVar2 + (int)uStack_60);
  }
  aiStackX_10[0] = 0;
LAB_:
  uVar14 = *puVar10;
  if (uVar14 < uVar13) {
    lVar9 = (***(code ***)*param_1)();
    uVar5 = *(ushort *)(lStackX_20 + 0x1c);
    if (((((uVar5 != 0) && (uVar5 <= *(ushort *)(*(longlong *)(lVar9 + 0x6a0) + 0x74))) &&
         (lVar9 = *(longlong *)
                   (*(longlong *)(*(longlong *)(lVar9 + 0x6a0) + 0x50) + -8 + (ulonglong)uVar5 * 8),
         lVar9 != 0)) && (((*(uint *)(lVar9 + 100) & 4) == 0 && (uVar14 < *(uint *)(lVar9 + 0x80))))
        ) && ((*(uint *)(lVar9 + 100) & 0x40) == 0)) {
      uStack_68 = *(undefined2 *)(lStackX_20 + 0x1c);
      if (*(uint *)(lVar9 + 0x80) < uVar13) {
        uVar13 = *(uint *)(lVar9 + 0x80);
      }
      uStack_6c = uVar14;
      func_0x(param_1,uStack_68,&uStack_6c,uVar13,puVar20);
    }
  }
  return;
}

