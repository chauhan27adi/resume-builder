
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x010f23c3) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,undefined8 param_3)

{
  undefined2 *puVar1;
  byte bVar2;
  ushort uVar3;
  undefined2 uVar4;
  uint uVar5;
  int iVar6;
  longlong lVar7;
  uint *puVar8;
  undefined8 uVar9;
  int iVar10;
  int iVar11;
  longlong lVar12;
  undefined8 uVar13;
  longlong lVar14;
  undefined8 unaff_RBX;
  int *piVar15;
  undefined uVar16;
  longlong unaff_GS_OFFSET;
  undefined2 uStackX_18;
  undefined auStackX_1a [2];
  undefined4 uStackX_1c;
  longlong lStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar1 = (undefined2 *)((longlong)&uStackX_18 + lVar12);
  *(undefined8 *)(&stack0x00000158 + lVar12) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000023d0 + lVar12) = unaff_RBX;
  *(ulonglong *)(&stack0x00002368 + lVar12) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined8 *)(&stack0x00000108 + lVar12) = param_3;
  *(longlong **)(&stack0x000000c8 + lVar12) = param_2;
  *(longlong *)(&stack0x000000e0 + lVar12) = param_1;
  *(longlong *)(&stack0x00000110 + lVar12) = param_1;
  lVar7 = *param_2;
  *(longlong *)(&stack0x000000e8 + lVar12) = lVar7;
  *puVar1 = 0xffff;
  *(undefined8 *)((longlong)&lStackX_20 + lVar12) = 0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar12 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar12) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar12) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar12) = 0;
  lVar14 = *(longlong *)(param_1 + 0x10);
  *(longlong *)(&stack0x000000d8 + lVar12) = lVar14;
  *(undefined4 *)(&stack0x000000c4 + lVar12) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000b7;
  func_0x(&stack0x00000118 + lVar12,param_1,1);
  *(undefined4 *)(&stack0x00000094 + lVar12) = 0x1f7c;
  uVar16 = 0;
  (&stack0x00000050)[lVar12] = 0;
  puVar8 = *(uint **)(param_1 + 0x108);
  if ((puVar8 != (uint *)0x0) && ((*puVar8 & 0x10000000) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(lVar7 + 0xe) & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar7 = *(longlong *)(lVar14 + 8);
  bVar2 = *(byte *)(lVar7 + 0x106);
  *(uint *)(&stack0x000000a0 + lVar12) = bVar2 & 1;
  if ((puVar8 != (uint *)0x0) &&
     (*(uint *)(&stack0x000000a0 + lVar12) = bVar2 & 1, (*puVar8 & 0x20000000) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(lVar7 + 0x100) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar7 = *param_2;
  if ((*(byte *)(lVar7 + 0x38) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar5 = *(uint *)((longlong)param_2 + 0x14);
  *puVar1 = 0;
  *(undefined8 *)(&stack0x000000f0 + lVar12) = 0;
  lVar14 = 0;
  if ((uVar5 & 0x10) != 0) {
    lVar14 = lVar7;
  }
  iVar11 = *(int *)(lVar14 + 0x10);
  *(int *)(&stack0x000000a4 + lVar12) = -iVar11;
  if ((bVar2 & 1) == 0) {
    uVar16 = 6;
  }
  iVar10 = 4;
  if ((bVar2 & 1) == 0) {
    iVar10 = 1;
  }
  iVar6 = *(int *)(lVar14 + 0x14);
  (&stack0xfffffffffffffff0)[lVar12] = uVar16;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) = *(undefined4 *)(lVar14 + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001b0;
  func_0x((longlong)&uStackX_18 + lVar12 + 2,&stack0x000003c8 + lVar12,0x1f9e,iVar6 - iVar10
                 );
  if (-iVar11 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar3 = *(ushort *)(*param_2 + 0x62);
  *(uint *)(&stack0x000000d0 + lVar12) = (uint)uVar3;
  *(undefined4 *)(&stack0x000000c0 + lVar12) = 0;
  piVar15 = (int *)param_2[1];
  *(int **)(&stack0x00000098 + lVar12) = piVar15;
  iVar11 = 0;
  if (uVar3 != 0) {
    do {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100202;
      func_0x(param_2,piVar15,&stack0x00000090 + lVar12);
      if ((&stack0x00000090)[lVar12] == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(short *)(piVar15 + 1) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100220;
        func_0x((longlong)&uStackX_18 + lVar12 + 2,piVar15);
      }
      uVar5 = piVar15[0x10];
      if ((uVar5 & 0x48000) == 0x48000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)(*(longlong *)(piVar15 + 0x12) + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar7 = param_2[3];
      lVar14 = *(longlong *)(piVar15 + 10);
      *(longlong *)(&stack0x000000b8 + lVar12) = lVar14 + lVar7;
      if ((uVar5 >> 0xb & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((char)uVar5 != '\x01') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((uVar5 >> 8 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      iVar11 = *piVar15;
      uVar4 = *(undefined2 *)(piVar15 + 0xf);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10028d;
      func_0x((longlong)iVar11 + *(longlong *)((longlong)&lStackX_20 + lVar12),
                      lVar14 + lVar7,uVar4);
      piVar15 = piVar15 + 0x14;
      *(int **)(&stack0x00000098 + lVar12) = piVar15;
      iVar11 = *(int *)(&stack0x000000c0 + lVar12);
      *(uint *)(&stack0x000000c0 + lVar12) = iVar11 + 1U;
    } while (iVar11 + 1U < *(uint *)(&stack0x000000d0 + lVar12));
    iVar11 = *(int *)(&stack0x000000a4 + lVar12);
  }
  if (iVar11 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar9 = *(undefined8 *)(&stack0x000000d8 + lVar12);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002dd;
  iVar11 = func_0x(uVar9);
  if ((iVar11 == 0) && (((&stack0x000000a0)[lVar12] & 2) == 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002fd;
    func_0x(uVar9,1);
  }
  lVar7 = *(longlong *)(&stack0x000000e0 + lVar12);
  if ((*(uint **)(lVar7 + 0x108) == (uint *)0x0) ||
     (uVar13 = _DAT_, (**(uint **)(lVar7 + 0x108) & 0x8000000) == 0)) {
    uVar13 = _DAT_;
  }
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar12) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = uVar13;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006a2;
  func_0x(&stack0x00000180 + lVar12,0xc,5,0);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006b0;
  lVar14 = func_0x(uVar9,1);
  if (lVar14 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(lVar7 + 0x460) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar12) = *(undefined8 *)(&stack0x00000108 + lVar12);
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = *(undefined8 *)(&stack0x000000e8 + lVar12);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006f1;
  iVar11 = func_0x(lVar7,puVar1,0,1);
  if (iVar11 == 0) {
    if ((DAT_ & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar7 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar7 != 0) && (**(longlong **)(lVar7 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10074b;
    func_0x(&stack0x00000180 + lVar12);
    lVar7 = *(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             0x100);
    if (lVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(lVar7 + 0x22c) == 0) {
      if (*(longlong *)(&stack0x00000118 + lVar12) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1007a7;
        func_0x(*(ulonglong *)(&stack0x00002368 + lVar12) ^ (ulonglong)puVar1);
        return;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

