
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint param_2,longlong param_3,ushort *param_4,longlong param_5)

{
  int *piVar1;
  uint *puVar2;
  int iVar3;
  uint *puVar4;
  longlong lVar5;
  uint uVar6;
  uint uVar7;
  byte bVar8;
  char cVar9;
  ushort uVar10;
  int iVar11;
  undefined8 uVar12;
  int **ppiVar13;
  byte *pbVar14;
  uint uVar15;
  ulonglong uVar16;
  uint uVar17;
  ushort *puVar18;
  longlong lVar19;
  uint uVar20;
  longlong lVar21;
  undefined auStack_58 [8];
  longlong lStack_50;
  longlong lStack_48;
  
  uVar20 = 0;
  lStack_50 = param_5;
  if (param_2 != 0) {
    lVar21 = 0;
    lStack_48 = param_1;
    do {
      puVar4 = *(uint **)(lStack_48 + lVar21 * 8);
      bVar8 = **(byte **)(param_3 + 6);
      if ((bVar8 & 0x10) == 0) {
        if ((1 << (bVar8 & 0xe) & 0x1105U) != 0) {
LAB_:
          uVar17 = *puVar4;
          lVar19 = (longlong)(int)uVar17;
          iVar3 = **(int **)(puVar4 + 2);
          piVar1 = *(int **)(puVar4 + 2) + 1;
          if ((int)uVar17 < 0) {
            ppiVar13 = (int **)((longlong)(int)~uVar17 * 0x20 + param_5);
            *(uint *)((longlong)ppiVar13 + 0xc) = *(uint *)((longlong)ppiVar13 + 0xc) & 0xfffffffa;
            *ppiVar13 = piVar1;
            *(int *)(ppiVar13 + 1) = iVar3;
            uVar17 = *puVar4;
            uVar15 = puVar4[1];
            uVar6 = puVar4[2];
            uVar7 = puVar4[3];
            *(uint *)((longlong)ppiVar13 + 0xc) = *(uint *)((longlong)ppiVar13 + 0xc) & 0xfffffff5;
            *(uint *)(ppiVar13 + 2) = uVar17;
            *(uint *)((longlong)ppiVar13 + 0x14) = uVar15;
            *(uint *)(ppiVar13 + 3) = uVar6;
            *(uint *)((longlong)ppiVar13 + 0x1c) = uVar7;
            puVar2 = (uint *)((longlong)(int)~*puVar4 * 0x20 + 0xc + param_5);
            *puVar2 = *puVar2 | 8;
          }
          else {
            uVar15 = (uint)*(ushort *)((longlong)puVar4 + 6);
            if ((*(ushort *)((longlong)puVar4 + 6) & 8) == 0) {
              if (*(int *)(param_4 + 1) == 0) {
                pbVar14 = *(byte **)(param_4 + 3);
                uVar17 = *(uint *)(param_4 + 7);
                uVar16 = (ulonglong)uVar17;
                *param_4 = 0;
                *(uint *)(param_4 + 9) = uVar17;
                bVar8 = *pbVar14;
                if ((bVar8 & 0x10) != 0) {
                  uVar17 = uVar17 + 2 + (*(ushort *)(pbVar14 + uVar16) + 7 >> 3);
                  uVar16 = (ulonglong)uVar17;
                  *(uint *)(param_4 + 9) = uVar17;
                  bVar8 = *pbVar14;
                }
                if ((bVar8 & 0x20) == 0) {
                  *(int *)(param_4 + 1) = (int)uVar16;
                  param_4[0xd] = 0;
                  *(int *)(param_4 + 0xb) = (int)uVar16;
                }
                else {
                  puVar18 = (ushort *)(pbVar14 + uVar16);
                  uVar10 = *puVar18;
                  param_4[0xd] = uVar10;
                  if (uVar10 == 0) {
                    cVar9 = func_0x(0x1eb1120);
                    if (((cVar9 != '\0') && (lVar19 = func_0x(), lVar19 != 0)) &&
                       (*(char *)(lVar19 + 0x499) != '\0')) {
                      cVar9 = func_0x(0x1eb1120);
                      if (cVar9 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        (*_DAT_)(1,0x17a1ea8,0x18c1b78,0x80f,0);
                      }
                    }
                    func_0x(*(undefined8 *)(param_4 + 3),3);
                    uVar16 = (ulonglong)*(uint *)(param_4 + 9);
                    pbVar14 = *(byte **)(param_4 + 3);
                    uVar10 = param_4[0xd];
                  }
                  uVar17 = (int)uVar16 + (uVar10 + 1) * 2;
                  *(uint *)(param_4 + 0xb) = uVar17;
                  if (0x1f9e < uVar17) {
                    cVar9 = func_0x(0x1eb1120);
                    if (((cVar9 != '\0') && (lVar19 = func_0x(), lVar19 != 0)) &&
                       (*(char *)(lVar19 + 0x499) != '\0')) {
                      cVar9 = func_0x(0x1eb1120);
                      if (cVar9 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        (*_DAT_)(1,0x17a1ea8,0x18c1b78,0x816,0);
                      }
                    }
                    func_0x(*(undefined8 *)(param_4 + 3),4);
                    uVar10 = param_4[0xd];
                    pbVar14 = *(byte **)(param_4 + 3);
                    uVar17 = *(uint *)(param_4 + 0xb);
                  }
                  uVar16 = (ulonglong)uVar10;
                  uVar10 = puVar18[uVar16];
                  *(uint *)(param_4 + 1) = uVar10 & 0x7fff;
                  if ((uVar10 & 0x7fff) < uVar17) {
                    cVar9 = func_0x(0x1eb1120);
                    if (((cVar9 != '\0') && (lVar19 = func_0x(), lVar19 != 0)) &&
                       (*(char *)(lVar19 + 0x499) != '\0')) {
                      cVar9 = func_0x(0x1eb1120);
                      if (cVar9 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        (*_DAT_)(1,0x17a1ea8,0x18c1b78,0x81d,0);
                      }
                    }
                    func_0x(*(undefined8 *)(param_4 + 3),4);
                    uVar16 = (ulonglong)param_4[0xd];
                    pbVar14 = *(byte **)(param_4 + 3);
                  }
                  if ((short)puVar18[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
                    do {
                      if ((int)uVar16 == 1) {
                        uVar17 = *(uint *)(param_4 + 0xb);
                        uVar15 = uVar17;
LAB_:
                        if ((*(ushort *)(pbVar14 + uVar16 * 2 + (ulonglong)*(uint *)(param_4 + 9)) &
                            0x7fff) < uVar17) goto LAB_;
                      }
                      else {
                        uVar15 = *(uint *)(param_4 + 0xb);
                        uVar17 = *(ushort *)
                                  (pbVar14 + uVar16 * 2 + ((ulonglong)*(uint *)(param_4 + 9) - 2)) &
                                 0x7fff;
                        if (uVar15 <= uVar17) goto LAB_;
LAB_:
                        func_0x(pbVar14,7);
                        uVar15 = *(uint *)(param_4 + 0xb);
                        pbVar14 = *(byte **)(param_4 + 3);
                      }
                      if ((uVar17 < uVar15) || (*(uint *)(param_4 + 1) < uVar17)) goto LAB_;
                      if (*(ushort *)(pbVar14 + uVar17) == 5) {
                        *param_4 = *param_4 | 2;
                        param_4[0xd] = param_4[0xd] - 1;
                        param_4[0x14] = (ushort)uVar17;
                        lVar19 = (ulonglong)(uVar17 & 0xffff) + *(longlong *)(param_4 + 3);
                        uVar10 = param_4[0x15] & 0xc7ff;
                        if ((*(ushort *)(lVar19 + 2) >> 0xe & 1) != 0) {
                          uVar10 = *(ushort *)(lVar19 + 2) & 0x3800 | param_4[0x15] & 0xc7ff;
                        }
                        param_4[0x15] = uVar10;
                        param_4[0x15] = (uVar10 ^ *(ushort *)(lVar19 + 2)) & 0x7ff ^ uVar10;
                        pbVar14 = *(byte **)(param_4 + 3);
                        goto LAB_;
                      }
                      if (*(ushort *)(pbVar14 + uVar17) < 0x400) goto LAB_;
                      *param_4 = *param_4 | 1;
                      uVar10 = param_4[0xd] - 1;
                      param_4[0xd] = uVar10;
                      if (uVar10 == 0) goto LAB_;
                      uVar16 = (ulonglong)uVar10;
                    } while ((short)puVar18[(ulonglong)(uVar10 - 1) + 1] < 0);
                    uVar16 = (ulonglong)*(uint *)(param_4 + 1);
                  }
                  else {
LAB_:
                    uVar16 = (ulonglong)*(uint *)(param_4 + 1);
                  }
                }
                if ((*pbVar14 & 0x40) == 0) {
                  *(undefined4 *)(param_4 + 0x12) = 0;
                }
                else {
                  *(int *)(param_4 + 0x12) = (int)uVar16;
                  *(int *)(param_4 + 1) = (int)uVar16 + 0xe;
                  uVar12 = func_0x(param_4);
                  func_0x(uVar12,auStack_58);
                  iVar11 = func_0x(auStack_58);
                  *(int *)(param_4 + 1) = *(int *)(param_4 + 1) + iVar11;
                  uVar16 = (ulonglong)*(uint *)(param_4 + 1);
                  pbVar14 = *(byte **)(param_4 + 3);
                }
                if ((*(byte **)(param_4 + 0xe) != (byte *)0x0) &&
                   (*(byte **)(param_4 + 0xe) < pbVar14 + uVar16)) {
                  cVar9 = func_0x(0x1eb1120);
                  if ((cVar9 != '\0') &&
                     ((lVar19 = func_0x(), lVar19 != 0 &&
                      (*(char *)(lVar19 + 0x499) != '\0')))) {
                    cVar9 = func_0x(0x1eb1120);
                    if (cVar9 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      (*_DAT_)(1,0x17a1ea8,0x18c1b78,0x877,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_4 + 3),0x12);
                  uVar16 = (ulonglong)*(uint *)(param_4 + 1);
                }
                if (0x3f3b < (int)uVar16 - 1U) {
                  cVar9 = func_0x(0x1eb1120);
                  if (((cVar9 != '\0') && (lVar19 = func_0x(), lVar19 != 0)) &&
                     (*(char *)(lVar19 + 0x499) != '\0')) {
                    cVar9 = func_0x(0x1eb1120);
                    if (cVar9 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      (*_DAT_)(1,0x17a1ea8,0x18c1b78,0x87c,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_4 + 3),5);
                }
              }
LAB_:
              uVar17 = *puVar4 + iVar3;
              if (*(uint *)(param_4 + 7) < uVar17) {
                func_0x(param_4,0,uVar17 - *(uint *)(param_4 + 7),0);
                if ((1 << (**(byte **)(param_4 + 3) & 0xe) & 0x1105U) != 0) {
                  *(short *)(*(byte **)(param_4 + 3) + 2) = (short)uVar17;
                }
                *(uint *)(param_4 + 7) = uVar17;
              }
              if ((piVar1 != (int *)0x0) && (iVar3 != 0)) {
                func_0x
                          ((longlong)(int)*puVar4 + *(longlong *)(param_4 + 3),piVar1,iVar3);
              }
            }
            else {
              uVar17 = uVar17 + 1;
              cVar9 = *(char *)piVar1;
              if (*(uint *)(param_4 + 7) < uVar17) {
                func_0x(param_4,0,uVar17 - *(uint *)(param_4 + 7),0);
                if ((1 << (**(byte **)(param_4 + 3) & 0xe) & 0x1105U) != 0) {
                  *(short *)(*(byte **)(param_4 + 3) + 2) = (short)uVar17;
                }
                *(uint *)(param_4 + 7) = uVar17;
                uVar15 = (uint)*(byte *)((longlong)puVar4 + 6);
              }
              lVar5 = *(longlong *)(param_4 + 3);
              if (cVar9 == '\0') {
                *(byte *)(lVar5 + lVar19) = *(byte *)(lVar5 + lVar19) & ~(byte)(1 << (uVar15 & 7));
              }
              else {
                *(byte *)(lVar5 + lVar19) = *(byte *)(lVar5 + lVar19) | (byte)(1 << (uVar15 & 7));
              }
            }
          }
          lVar19 = (ulonglong)(*(ushort *)(puVar4 + 1) - 1 >> 3) + (longlong)*(int *)(param_4 + 7) +
                   *(longlong *)(param_4 + 3);
          *(byte *)(lVar19 + 2) =
               *(byte *)(lVar19 + 2) & ~(byte)(1 << (*(ushort *)(puVar4 + 1) - 1 & 7));
          param_5 = lStack_50;
        }
      }
      else if (((int)*(uint *)(param_3 + 0xe) <= (int)*puVar4) ||
              (*(ushort *)(*(byte **)(param_3 + 6) + *(uint *)(param_3 + 0xe)) <
               *(ushort *)(puVar4 + 1))) goto LAB_;
      uVar20 = uVar20 + 1;
      lVar21 = lVar21 + 1;
    } while (uVar20 < param_2);
  }
  return;
}

