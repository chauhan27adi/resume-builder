
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2,longlong *param_3,undefined8 param_4)

{
  short sVar1;
  code *pcVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  char *pcVar5;
  byte bVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong lVar11;
  ulonglong *puVar12;
  longlong lVar13;
  byte *pbVar14;
  ushort uVar15;
  ulonglong uVar16;
  longlong lVar17;
  uint uVar18;
  undefined4 uVar19;
  uint uVar20;
  ushort *puVar21;
  longlong unaff_GS_OFFSET;
  undefined auStackX_8 [4];
  int iStackX_c;
  int aiStackX_10 [2];
  short sStackX_18;
  short sStackX_1a;
  int iStackX_1c;
  byte *pbStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  *(undefined8 *)(&stack0x000000b0 + lVar9) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002078 + lVar9) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9);
  *(undefined8 *)(&stack0x00000060 + lVar9) = param_4;
  uVar18 = (uint)param_2;
  uVar16 = param_2 & 0xffffffff;
  *(uint *)(&stack0x00000050 + lVar9) = uVar18;
  *(longlong *)(&stack0x00000068 + lVar9) = param_1;
  lVar13 = *(longlong *)(&stack0x000020e8 + lVar9);
  *(longlong *)(&stack0x00000078 + lVar9) = lVar13;
  *(undefined8 *)(&stack0x00000070 + lVar9) = *(undefined8 *)(&stack0x000020f0 + lVar9);
  *(undefined8 *)(&stack0x000000a8 + lVar9) = 0;
  *(undefined (*) [16])(&stack0x00000098 + lVar9) = ZEXT816(0);
  *(undefined2 *)((longlong)&sStackX_18 + lVar9) = 0xffff;
  *(undefined8 *)((longlong)&pbStackX_20 + lVar9) = 0;
  *(undefined4 *)((longlong)&sStackX_18 + lVar9 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar9) = 0;
  *(undefined4 *)(&stack0x00000058 + lVar9) = 0;
  *(undefined4 *)(&stack0x0000005c + lVar9) = 0;
  *(undefined4 *)((longlong)aiStackX_10 + lVar9) = 0;
  lVar11 = *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x30);
  if (((*(byte *)(*(longlong *)(**(longlong **)(*(uint **)(param_1 + 0x108) + 8) + 8) + 0x107) &
       0x40) == 0) ||
     (uVar20 = **(uint **)(param_1 + 0x108), auStackX_8[lVar9] = 1, (uVar20 & 0x1000000) != 0)) {
    auStackX_8[lVar9] = 0;
  }
  uVar20 = uVar18 & 0xc2;
  *(uint *)(&stack0x00000054 + lVar9) = uVar20;
  if ((lVar13 == 0) || (*(undefined4 *)((longlong)&iStackX_c + lVar9) = 1, (param_2 & 8) == 0)) {
    *(undefined4 *)((longlong)&iStackX_c + lVar9) = 0;
  }
  *(uint *)(param_3 + 2) = *(uint *)(param_3 + 2) & 0xfffffeff;
  if (((char)*(uint *)(param_3 + 2) < '\0') || ((*(byte *)((longlong)param_3 + 0x34) & 1) == 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10015e;
    plVar10 = (longlong *)func_0x(param_3,0);
  }
  else if ((*(uint *)(param_3 + 2) & 0x2000) == 0) {
    plVar10 = param_3 + 9;
  }
  else {
    plVar10 = (longlong *)param_3[0x29];
  }
  if (*(char *)(lVar11 + 0x1cde) != '\0') {
    lVar13 = *(longlong *)(param_1 + 0x108);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100193;
    func_0x(param_3,lVar13 + 0x90,auStackX_8[lVar9],&stack0x00000090 + lVar9);
    *(uint *)(param_3 + 2) = *(uint *)(param_3 + 2) & 0xfffffeff;
    if (((char)*(uint *)(param_3 + 2) < '\0') || ((*(byte *)((longlong)param_3 + 0x34) & 1) == 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001c7;
      plVar10 = (longlong *)func_0x(param_3,0);
    }
    else if ((*(uint *)(param_3 + 2) & 0x2000) == 0) {
      plVar10 = param_3 + 9;
    }
    else {
      plVar10 = (longlong *)param_3[0x29];
    }
    if (plVar10 == (longlong *)0x0) {
      *(uint *)(param_3 + 2) = *(uint *)(param_3 + 2) | 0x100;
      goto LAB_;
    }
  }
  if (((((param_2 & 0x10) != 0) || (*(int *)((longlong)&iStackX_c + lVar9) != 0)) ||
      ((param_2 & 0xc2) != 0)) || (iVar8 = 0, (uVar18 >> 8 & 1) != 0)) {
    sVar1 = *(short *)plVar10;
    *(short *)((longlong)&sStackX_18 + lVar9) = sVar1;
    if (sVar1 == 0) {
      if (*(int *)((longlong)plVar10 + 4) == 0) {
        *(short *)((longlong)plVar10 + 2) = 0;
        uVar18 = *(uint *)(plVar10 + 2);
        uVar16 = (ulonglong)uVar18;
        *(uint *)((longlong)plVar10 + 0x14) = uVar18;
        pbVar14 = (byte *)plVar10[1];
        bVar6 = *pbVar14;
        if ((bVar6 & 0x10) != 0) {
          uVar18 = uVar18 + (*(ushort *)(pbVar14 + uVar16) + 7 >> 3) + 2;
          uVar16 = (ulonglong)uVar18;
          *(uint *)((longlong)plVar10 + 0x14) = uVar18;
          bVar6 = *pbVar14;
        }
        if ((bVar6 & 0x20) == 0) {
          *(int *)((longlong)plVar10 + 4) = (int)uVar16;
          *(short *)((longlong)plVar10 + 0x1c) = 0;
          *(int *)(plVar10 + 3) = (int)uVar16;
        }
        else {
          puVar21 = (ushort *)(pbVar14 + uVar16);
          uVar15 = *puVar21;
          *(ushort *)((longlong)plVar10 + 0x1c) = uVar15;
          if (uVar15 == 0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar13 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar13 != 0 &&
                ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                 (*(char *)(lVar13 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002e7;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10030d;
                (*_DAT_)(1,0x17cdf88,0x18edc58,0x80f);
              }
            }
            lVar13 = plVar10[1];
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10031b;
            func_0x(lVar13,3);
            uVar16 = (ulonglong)*(uint *)((longlong)plVar10 + 0x14);
            uVar15 = *(ushort *)((longlong)plVar10 + 0x1c);
          }
          uVar18 = (int)uVar16 + (uVar15 + 1) * 2;
          *(uint *)(plVar10 + 3) = uVar18;
          if (0x1f9e < uVar18) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar13 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar13 != 0)) &&
               ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                (*(char *)(lVar13 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003b8;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003de;
                (*_DAT_)(1,0x17cdf88,0x18edc58,0x816);
              }
            }
            lVar13 = plVar10[1];
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003ec;
            func_0x(lVar13,4);
            uVar15 = *(ushort *)((longlong)plVar10 + 0x1c);
          }
          uVar16 = (ulonglong)uVar15;
          uVar15 = puVar21[uVar16];
          *(uint *)((longlong)plVar10 + 4) = uVar15 & 0x7fff;
          if ((uVar15 & 0x7fff) < *(uint *)(plVar10 + 3)) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar13 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar13 != 0 &&
                ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                 (*(char *)(lVar13 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100484;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004aa;
                (*_DAT_)(1,0x17cdf88,0x18edc58,0x81d);
              }
            }
            lVar13 = plVar10[1];
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004b8;
            func_0x(lVar13,4);
            uVar16 = (ulonglong)*(ushort *)((longlong)plVar10 + 0x1c);
          }
          if ((short)puVar21[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
            do {
              lVar13 = plVar10[1];
              lVar11 = (ulonglong)*(uint *)((longlong)plVar10 + 0x14) + lVar13;
              if ((int)uVar16 == 1) {
                uVar18 = *(uint *)(plVar10 + 3);
                uVar15 = *(ushort *)(lVar11 + uVar16 * 2);
                uVar20 = uVar18;
LAB_:
                if ((uVar15 & 0x7fff) < uVar18) goto LAB_;
              }
              else {
                uVar18 = *(ushort *)(lVar11 + -2 + uVar16 * 2) & 0x7fff;
                uVar20 = *(uint *)(plVar10 + 3);
                uVar15 = *(ushort *)(lVar11 + uVar16 * 2);
                if (uVar20 <= uVar18) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100531;
                func_0x(lVar13,7);
                uVar20 = *(uint *)(plVar10 + 3);
                lVar13 = plVar10[1];
                uVar16 = (ulonglong)*(ushort *)((longlong)plVar10 + 0x1c);
              }
              if ((uVar18 < uVar20) || (*(uint *)((longlong)plVar10 + 4) < uVar18))
              goto LAB_;
              if (*(ushort *)(lVar13 + (ulonglong)uVar18) == 5) {
                *(ushort *)((longlong)plVar10 + 2) = *(ushort *)((longlong)plVar10 + 2) | 2;
                *(short *)((longlong)plVar10 + 0x1c) = (short)uVar16 + -1;
                *(short *)((longlong)plVar10 + 0x2a) = (short)uVar18;
                lVar13 = (ulonglong)(uVar18 & 0xffff) + plVar10[1];
                uVar15 = *(ushort *)(lVar13 + 2);
                uVar7 = *(ushort *)((longlong)plVar10 + 0x2c) & 0xc7ff;
                if ((uVar15 & 0x4000) != 0) {
                  uVar7 = uVar15 & 0x3800 | uVar7;
                }
                *(ushort *)((longlong)plVar10 + 0x2c) = uVar7;
                *(ushort *)((longlong)plVar10 + 0x2c) =
                     (uVar7 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar7;
                uVar16 = (ulonglong)*(uint *)((longlong)plVar10 + 4);
                pbVar14 = (byte *)plVar10[1];
                goto LAB_;
              }
              if (*(ushort *)(lVar13 + (ulonglong)uVar18) < 0x400) break;
              *(ushort *)((longlong)plVar10 + 2) = *(ushort *)((longlong)plVar10 + 2) | 1;
              uVar15 = (short)uVar16 - 1;
              *(ushort *)((longlong)plVar10 + 0x1c) = uVar15;
              if ((uVar15 == 0) ||
                 (uVar16 = (ulonglong)uVar15, -1 < (short)puVar21[(ulonglong)(uVar15 - 1) + 1]))
              break;
            } while( true );
          }
          uVar16 = (ulonglong)*(uint *)((longlong)plVar10 + 4);
          pbVar14 = (byte *)plVar10[1];
        }
LAB_:
        if ((*pbVar14 & 0x40) == 0) {
          *(undefined4 *)((longlong)plVar10 + 0x26) = 0;
        }
        else {
          *(int *)((longlong)plVar10 + 0x26) = *(int *)((longlong)plVar10 + 4);
          *(int *)((longlong)plVar10 + 4) = *(int *)((longlong)plVar10 + 4) + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100659;
          puVar12 = (ulonglong *)func_0x((short *)((longlong)plVar10 + 2));
          uVar16 = *puVar12;
          iVar8 = 0;
          uVar15 = (ushort)(uVar16 >> 0x30);
          if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
            if ((uVar16 & 0x4000000000000000) == 0) {
              uVar15 = uVar15 & 0xdfff;
            }
            else {
              uVar15 = uVar15 | 0x2000;
            }
          }
          if (uVar15 == 0xfffc) {
            iVar8 = (int)((uVar16 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)((longlong)plVar10 + 4) = *(int *)((longlong)plVar10 + 4) + iVar8;
          uVar16 = (ulonglong)*(uint *)((longlong)plVar10 + 4);
          pbVar14 = (byte *)plVar10[1];
        }
        iVar8 = (int)uVar16;
        if ((*(byte **)((longlong)plVar10 + 0x1e) != (byte *)0x0) &&
           (*(byte **)((longlong)plVar10 + 0x1e) < pbVar14 + uVar16)) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar13 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar13 != 0 && (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0))
              && (*(char *)(lVar13 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10074f;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100775;
              (*_DAT_)(1,0x17cdf88,0x18edc58,0x877);
            }
          }
          lVar13 = plVar10[1];
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100783;
          func_0x(lVar13,0x12);
          iVar8 = *(int *)((longlong)plVar10 + 4);
        }
        if (0x3f3b < iVar8 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar13 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar13 != 0 &&
              ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
               (*(char *)(lVar13 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10080e;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              lVar13 = plVar10[1];
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10081c;
              func_0x(lVar13,5);
              goto LAB_;
            }
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100842;
            (*_DAT_)(1,0x17cdf88,0x18edc58,0x87c);
          }
          lVar13 = plVar10[1];
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100850;
          func_0x(lVar13,5);
        }
      }
LAB_:
      uVar18 = *(uint *)((longlong)plVar10 + 4);
      if ((uVar18 < 9) &&
         (((*(byte *)plVar10[1] & 0xe) == 0 || ((*(byte *)plVar10[1] & 0xe) == 0xc)))) {
        uVar18 = 9;
      }
      *(undefined4 *)(&stack0x00000028 + lVar9) = *(undefined4 *)(plVar10 + 2);
      *(short *)((longlong)&sStackX_18 + lVar9 + 2) = *(short *)((longlong)plVar10 + 2);
      *(undefined4 *)((longlong)&sStackX_18 + lVar9 + 4) = *(undefined4 *)((longlong)plVar10 + 4);
      *(short *)(&stack0x00000034 + lVar9) = *(short *)((longlong)plVar10 + 0x1c);
      *(undefined4 *)(&stack0x0000002c + lVar9) = *(undefined4 *)((longlong)plVar10 + 0x14);
      *(undefined4 *)(&stack0x00000030 + lVar9) = *(undefined4 *)(plVar10 + 3);
      *(undefined4 *)(&stack0x0000003e + lVar9) = *(undefined4 *)((longlong)plVar10 + 0x26);
      lVar13 = plVar10[1];
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008d5;
      func_0x(&stack0x000000d8 + lVar9,0x1f9e,lVar13,uVar18);
      *(undefined **)((longlong)&pbStackX_20 + lVar9) = &stack0x000000d8 + lVar9;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008ec;
      iVar8 = func_0x((longlong)&sStackX_18 + lVar9 + 2);
      pbVar14 = *(byte **)((longlong)&pbStackX_20 + lVar9);
      if (iVar8 != 0) {
        puVar21 = (ushort *)(pbVar14 + *(uint *)(&stack0x0000002c + lVar9));
        uVar18 = *puVar21 - 1;
        if ((*(byte *)((longlong)&sStackX_18 + lVar9 + 2) & 1) == 0) {
          uVar18 = (uint)*puVar21;
        }
        uVar20 = *(uint *)(&stack0x00000030 + lVar9);
        if (uVar18 != 1) {
          uVar20 = puVar21[(longlong)(int)uVar18 + -1] & 0x7fff;
        }
        if ((uVar20 < *(uint *)(&stack0x00000030 + lVar9)) ||
           ((puVar21[(int)uVar18] & 0x7fff) < uVar20)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10094c;
          func_0x(pbVar14,7);
          pbVar14 = *(byte **)((longlong)&pbStackX_20 + lVar9);
        }
        *(short *)(&stack0x00000042 + lVar9) = (short)uVar20;
        uVar15 = *(ushort *)(&stack0x00000044 + lVar9);
        if ((*(ushort *)(pbVar14 + (ulonglong)(uVar20 & 0xffff) + 2) & 0x4000) == 0) {
          uVar15 = uVar15 & 0xc7ff;
        }
        else {
          uVar15 = uVar15 ^ (uVar15 ^ *(ushort *)(pbVar14 + (ulonglong)(uVar20 & 0xffff) + 2)) &
                            0x3800;
        }
        *(ushort *)(&stack0x00000044 + lVar9) = uVar15;
        *(ushort *)(&stack0x00000044 + lVar9) =
             (uVar15 ^ *(ushort *)(pbVar14 + (ulonglong)(uVar20 & 0xffff) + 2)) & 0x7ff ^ uVar15;
      }
      param_1 = *(longlong *)(&stack0x00000068 + lVar9);
      uVar16 = (ulonglong)*(uint *)(&stack0x00000050 + lVar9);
      uVar20 = *(uint *)(&stack0x00000054 + lVar9);
    }
    else {
      if (((*(short *)plVar10 == 0) || ((longlong *)plVar10[2] == (longlong *)0x0)) ||
         (*(longlong *)plVar10[2] == 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1009ff;
        func_0x((longlong)&sStackX_18 + lVar9 + 2,&stack0x000000d8 + lVar9,0x1f9e,
                        (short *)((longlong)plVar10 + 2));
        if (*(short *)plVar10 == 0) {
          lVar13 = 0;
        }
        else {
          lVar13 = plVar10[2];
        }
        *(longlong *)(&stack0x00000028 + lVar9) = lVar13;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1009e1;
        func_0x((longlong)&sStackX_18 + lVar9,&stack0x000000d8 + lVar9,0x1f9e,plVar10);
      }
      pbVar14 = *(byte **)((longlong)&pbStackX_20 + lVar9);
    }
    if (*(short *)((longlong)&sStackX_18 + lVar9) == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a29;
      func_0x((longlong)&sStackX_18 + lVar9 + 2);
    }
    else if ((*pbVar14 & 2) != 0) {
      if (*(int *)((longlong)&sStackX_18 + lVar9 + 4) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a42;
        func_0x((longlong)&sStackX_18 + lVar9 + 2);
        pbVar14 = *(byte **)((longlong)&pbStackX_20 + lVar9);
      }
      *pbVar14 = *pbVar14 & 0xfd;
      *(undefined4 *)((longlong)&sStackX_18 + lVar9 + 4) = *(undefined4 *)(&stack0x00000048 + lVar9)
      ;
      *(undefined4 *)(&stack0x00000048 + lVar9) = 0;
    }
    lVar13 = *(longlong *)(param_1 + 0x108);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a83;
    func_0x(param_3,lVar13 + 0x90,auStackX_8[lVar9],&stack0x00000090 + lVar9);
    iVar8 = *(int *)((longlong)&iStackX_c + lVar9);
  }
  pcVar2 = *(code **)(*param_3 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a90;
  (*pcVar2)(param_3);
  if ((uVar20 != 0) || ((uVar16 & 0x10) != 0)) {
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x0000005c + lVar9;
    uVar3 = *(undefined8 *)(param_1 + 0x1e8);
    uVar4 = *(undefined8 *)(param_1 + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100ac0;
    func_0x(uVar4,uVar3,(longlong)&sStackX_18 + lVar9,uVar16);
  }
  uVar3 = *(undefined8 *)(&stack0x00000060 + lVar9);
  if (iVar8 != 0) {
    *(undefined **)(&stack0xfffffffffffffff0 + lVar9) = &stack0x00000058 + lVar9;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = uVar3;
    uVar4 = *(undefined8 *)(param_1 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100aff;
    func_0x(uVar4,(longlong)&sStackX_18 + lVar9,*(undefined8 *)(&stack0x00000078 + lVar9),
                    *(undefined8 *)(&stack0x00000070 + lVar9));
  }
  if (((uint)uVar16 >> 8 & 1) != 0) {
    uVar4 = *(undefined8 *)(param_1 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b1f;
    func_0x(uVar4,(longlong)&sStackX_18 + lVar9,uVar3,(longlong)aiStackX_10 + lVar9);
  }
  if ((((*(int *)(&stack0x00000058 + lVar9) != 0) || (*(int *)(&stack0x0000005c + lVar9) != 0)) ||
      (*(int *)((longlong)aiStackX_10 + lVar9) != 0)) && ((uVar16 & 0x20) == 0)) {
    pcVar5 = *(char **)(param_1 + 0x380);
    if (((pcVar5 == (char *)0x0) || (pcVar5[3] == '\0')) ||
       ((*pcVar5 == '\0' || (pcVar5[1] == '\0')))) {
      uVar19 = *(undefined4 *)(param_1 + 0x2f0);
    }
    else {
      uVar19 = 2;
    }
    *(uint *)((longlong)&pbStackX_20 + lVar9 + -0x20) = **(uint **)(param_1 + 0x108) >> 0x1b & 1;
    *(undefined8 *)(&stack0xfffffffffffffff8 + lVar9) = 0;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x00000090 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100bb0;
    func_0x(param_3,(longlong)&sStackX_18 + lVar9,uVar19,0);
  }
  lVar13 = 0;
  if ((uVar16 & 4) != 0) {
    *(undefined4 *)((longlong)aiStackX_10 + lVar9) = 0x3d51;
    lVar17 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar11 = *(longlong *)(lVar17 + 0x100);
    if (lVar11 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100bff;
      (*_DAT_)(0);
      lVar11 = *(longlong *)(lVar17 + 0x100);
    }
    uVar3 = *(undefined8 *)(lVar11 + 1000);
    *(undefined8 *)(&stack0x00000078 + lVar9) = uVar3;
    (&stack0xffffffffffffffe8)[lVar9] = 5;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c32;
    lVar11 = (*_DAT_)(0x110,uVar3,0x1564a48,0x3d51);
    *(longlong *)(&stack0x00000070 + lVar9) = lVar11;
    if (lVar11 != 0) {
      lVar17 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar13 = *(longlong *)(lVar17 + 0x100);
      if (lVar13 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c75;
        (*_DAT_)(0);
        lVar13 = *(longlong *)(lVar17 + 0x100);
      }
      uVar3 = *(undefined8 *)(lVar13 + 1000);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c8b;
      lVar13 = func_0x(lVar11,uVar3);
    }
    *(longlong *)(&stack0x00000060 + lVar9) = lVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100cab;
    func_0x(lVar13,0,0x110);
    *(undefined2 *)(lVar13 + 0xe) = 2;
    *(ushort *)(lVar13 + 0x38) = *(ushort *)(lVar13 + 0x38) | 2;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x00000068 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100cd7;
    func_0x(param_1,param_3,lVar13,0);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100cdf;
    func_0x(lVar13);
    lVar11 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar13 = *(longlong *)(lVar11 + 0x100);
    if (lVar13 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d11;
      (*_DAT_)();
      lVar13 = *(longlong *)(lVar11 + 0x100);
    }
    if (*(int *)(lVar13 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d27;
      (*_DAT_)();
    }
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d37;
  func_0x
            (*(ulonglong *)(&stack0x00002078 + lVar9) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar9));
  return;
}

