
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2)

{
  ushort uVar1;
  undefined2 uVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  char cVar7;
  byte bVar8;
  int iVar9;
  ushort *puVar10;
  undefined2 *puVar11;
  uint *puVar12;
  undefined8 uVar13;
  
  (*_DAT_)(param_2 + 0x490,param_2 + 0x818);
  func_0x(*(undefined8 *)(param_2 + 0xf8));
  plVar5 = *(longlong **)(param_2 + 0x268);
  if (*plVar5 != 0) {
    puVar10 = (ushort *)(*plVar5 + 0x62);
    *(ushort **)(param_2 + 0x708) = puVar10;
    uVar1 = *puVar10;
    *(ushort *)(param_2 + 0x1c8) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)((longlong)plVar5 + 0xc) < 3)) {
      *(int *)(param_2 + 0xa8) = (int)*(short *)((longlong)plVar5 + 0xc);
      lVar6 = *plVar5;
      *(longlong *)(param_2 + 0xf8) = lVar6;
      puVar11 = (undefined2 *)(lVar6 + 0x62);
      *(undefined2 **)(param_2 + 0x710) = puVar11;
      uVar2 = *puVar11;
      *(undefined2 *)(param_2 + 0x1d0) = uVar2;
      if (((byte)uVar2 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xa8) == 3) {
          *(undefined4 *)(param_2 + 0xa8) = 4;
        }
        else if (*(int *)(param_2 + 0xa8) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xf8) + 100);
        *(uint **)(param_2 + 0x718) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x300) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0xf8) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x720) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0xf8),
                     *(undefined4 *)(param_2 + 0xa8));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x308) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0x10b) = -cVar7;
      if (-cVar7 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xf8) + 100);
        *(uint **)(param_2 + 0x728) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x310) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xa8))) {
          *(uint **)(param_2 + 0x730) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x318) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0xf8), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 800) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 0x324);
            if (iVar9 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0xf8);
      uVar4 = *(undefined4 *)(param_2 + 0xa8);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x328) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0x10c) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
      *plVar5 = 0;
    }
    else {
      func_0x(plVar5);
    }
  }
  if (*(longlong *)(param_2 + 0x150) != 0) {
    puVar10 = (ushort *)(*(longlong *)(param_2 + 0x150) + 0x62);
    *(ushort **)(param_2 + 0x738) = puVar10;
    uVar1 = *puVar10;
    *(ushort *)(param_2 + 0x1d8) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)(param_2 + 0x15c) < 3)) {
      *(int *)(param_2 + 0xb0) = (int)*(short *)(param_2 + 0x15c);
      *(undefined8 *)(param_2 + 0x170) = *(undefined8 *)(param_2 + 0x150);
      *(ushort **)(param_2 + 0x740) = puVar10;
      uVar1 = *puVar10;
      *(ushort *)(param_2 + 0x1f8) = uVar1;
      if (((byte)uVar1 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xb0) == 3) {
          *(undefined4 *)(param_2 + 0xb0) = 4;
        }
        else if (*(int *)(param_2 + 0xb0) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x150) + 100);
        *(uint **)(param_2 + 0x748) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x330) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0x150) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x750) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0x150),
                     *(undefined4 *)(param_2 + 0xb0));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x338) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0x10d) = -cVar7;
      if (-cVar7 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x170) + 100);
        *(uint **)(param_2 + 0x758) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x340) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xb0))) {
          *(uint **)(param_2 + 0x760) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x348) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0x170), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 0x350) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 0x354);
            if (iVar9 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0x170);
      uVar4 = *(undefined4 *)(param_2 + 0xb0);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x358) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0x10e) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)(param_2 + 0x15c) = *(uint *)(param_2 + 0x15c) & 0xffff0000;
      *(undefined8 *)(param_2 + 0x150) = 0;
    }
    else {
      func_0x(param_2 + 0x150);
    }
  }
  plVar5 = *(longlong **)(param_2 + 0x428);
  if (*plVar5 != 0) {
    puVar10 = (ushort *)(*plVar5 + 0x62);
    *(ushort **)(param_2 + 0x768) = puVar10;
    uVar1 = *puVar10;
    *(ushort *)(param_2 + 0x200) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)((longlong)plVar5 + 0xc) < 3)) {
      *(int *)(param_2 + 0xb8) = (int)*(short *)((longlong)plVar5 + 0xc);
      lVar6 = *plVar5;
      *(longlong *)(param_2 + 0x100) = lVar6;
      puVar11 = (undefined2 *)(lVar6 + 0x62);
      *(undefined2 **)(param_2 + 0x770) = puVar11;
      uVar2 = *puVar11;
      *(undefined2 *)(param_2 + 0x208) = uVar2;
      if (((byte)uVar2 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xb8) == 3) {
          *(undefined4 *)(param_2 + 0xb8) = 4;
        }
        else if (*(int *)(param_2 + 0xb8) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x100) + 100);
        *(uint **)(param_2 + 0x778) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x360) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0x100) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x780) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0x100),
                     *(undefined4 *)(param_2 + 0xb8));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x368) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0x10f) = -cVar7;
      if (-cVar7 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x100) + 100);
        *(uint **)(param_2 + 0x788) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x370) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xb8))) {
          *(uint **)(param_2 + 0x790) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x378) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0x100), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 0x380) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 900);
            if (iVar9 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0x100);
      uVar4 = *(undefined4 *)(param_2 + 0xb8);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x388) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0x110) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
      *plVar5 = 0;
    }
    else {
      func_0x(plVar5);
    }
  }
  plVar5 = *(longlong **)(param_2 + 0x430);
  if (*plVar5 != 0) {
    puVar10 = (ushort *)(*plVar5 + 0x62);
    *(ushort **)(param_2 + 0x798) = puVar10;
    uVar1 = *puVar10;
    *(ushort *)(param_2 + 0x210) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)((longlong)plVar5 + 0xc) < 3)) {
      *(int *)(param_2 + 0xc0) = (int)*(short *)((longlong)plVar5 + 0xc);
      lVar6 = *plVar5;
      *(longlong *)(param_2 + 0xf0) = lVar6;
      puVar11 = (undefined2 *)(lVar6 + 0x62);
      *(undefined2 **)(param_2 + 0x7a0) = puVar11;
      uVar2 = *puVar11;
      *(undefined2 *)(param_2 + 0x218) = uVar2;
      if (((byte)uVar2 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xc0) == 3) {
          *(undefined4 *)(param_2 + 0xc0) = 4;
        }
        else if (*(int *)(param_2 + 0xc0) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xf0) + 100);
        *(uint **)(param_2 + 0x7a8) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x390) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0xf0) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x7b0) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0xf0),
                     *(undefined4 *)(param_2 + 0xc0));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x3c8) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0x113) = -cVar7;
      if (-cVar7 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xf0) + 100);
        *(uint **)(param_2 + 0x7b8) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x398) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xc0))) {
          *(uint **)(param_2 + 0x7c0) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x3a0) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0xf0), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 0x3a8) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 0x3ac);
            if (iVar9 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0xf0);
      uVar4 = *(undefined4 *)(param_2 + 0xc0);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x3b0) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0x111) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
      *plVar5 = 0;
    }
    else {
      func_0x(plVar5);
    }
  }
  plVar5 = *(longlong **)(param_2 + 0x438);
  if (*plVar5 == 0) goto LAB_;
  puVar10 = (ushort *)(*plVar5 + 0x62);
  *(ushort **)(param_2 + 0x7c8) = puVar10;
  uVar1 = *puVar10;
  *(ushort *)(param_2 + 0x220) = uVar1;
  if (((uVar1 >> 10 & 1) != 0) && (2 < *(short *)((longlong)plVar5 + 0xc))) {
    func_0x(plVar5);
    goto LAB_;
  }
  *(int *)(param_2 + 200) = (int)*(short *)((longlong)plVar5 + 0xc);
  lVar6 = *plVar5;
  *(longlong *)(param_2 + 0xe0) = lVar6;
  puVar11 = (undefined2 *)(lVar6 + 0x62);
  *(undefined2 **)(param_2 + 2000) = puVar11;
  uVar2 = *puVar11;
  *(undefined2 *)(param_2 + 0x1b8) = uVar2;
  if (((byte)uVar2 >> 3 & 1) != 0) {
    if (*(int *)(param_2 + 200) == 3) {
      *(undefined4 *)(param_2 + 200) = 4;
    }
    else if (*(int *)(param_2 + 200) < 2) goto LAB_;
    puVar12 = (uint *)(*(longlong *)(param_2 + 0xe0) + 100);
    *(uint **)(param_2 + 0x7d8) = puVar12;
    uVar3 = *puVar12;
    *(uint *)(param_2 + 0x3b8) = uVar3;
    if ((((uVar3 & 8) != 0) &&
        (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0xe0) + 0x90), lVar6 != 0)) &&
       (*(longlong *)(param_2 + 0x7e0) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
      func_0x
                (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0xe0),
                 *(undefined4 *)(param_2 + 200));
    }
  }
LAB_:
  cVar7 = DAT_ >> 7;
  *(char *)(param_2 + 0x112) = -cVar7;
  if (-cVar7 != '\0') {
    puVar12 = (uint *)(*(longlong *)(param_2 + 0xe0) + 100);
    *(uint **)(param_2 + 0x7e8) = puVar12;
    uVar3 = *puVar12;
    *(uint *)(param_2 + 0x3c0) = uVar3;
    if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 200))) {
      *(uint **)(param_2 + 0x7f0) = puVar12;
      uVar3 = *puVar12;
      *(uint *)(param_2 + 0x268) = uVar3;
      if (((uVar3 & 0xc0000000) != 0x40000000) && (**(longlong **)(param_2 + 0xe0) != 0)) {
        iVar9 = (*_DAT_)(**(longlong **)(param_2 + 0xe0),0x2000,2,param_2 + 0x130);
        if (iVar9 != 0) {
          LOCK();
          *puVar12 = *puVar12 & 0x3fffffff;
          UNLOCK();
          LOCK();
          *puVar12 = *puVar12 | 0x40000000;
          UNLOCK();
        }
      }
    }
  }
  lVar6 = *(longlong *)(param_2 + 0xe0);
  uVar4 = *(undefined4 *)(param_2 + 200);
  func_0x(lVar6 + 0x98,uVar4);
  if ((_DAT_ != 0) && ((DAT_ >> 1 & 1) != 0)) {
    func_0x(lVar6,0,uVar4);
  }
  *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
  *plVar5 = 0;
LAB_:
  uVar13 = (*_DAT_)(param_2 + 0x490);
  (*_DAT_)(uVar13);
  (*_DAT_)(param_2 + 0x490);
  return 0xfffffffffeddc408;
}

