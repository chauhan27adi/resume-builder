
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined2 *param_1,undefined4 *param_2,undefined8 param_3,undefined4 param_4,
                 int param_5)

{
  longlong lVar1;
  longlong lVar2;
  ushort uVar3;
  undefined2 uVar4;
  undefined8 uVar5;
  longlong lVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined2 *puVar11;
  byte bVar12;
  int iVar13;
  ulonglong *puVar14;
  longlong lVar15;
  ulonglong uVar16;
  longlong lVar17;
  ushort uVar18;
  uint uVar19;
  byte *pbVar20;
  byte *pbVar21;
  ulonglong uVar22;
  longlong lVar23;
  undefined8 *puVar24;
  ulonglong uVar25;
  ushort uVar26;
  uint uVar27;
  uint uVar28;
  ushort *puVar29;
  ushort uVar30;
  ushort *puVar31;
  uint uVar32;
  longlong lVar33;
  uint *puVar34;
  longlong lVar35;
  longlong lVar36;
  longlong unaff_GS_OFFSET;
  undefined8 auStack_100 [5];
  longlong alStack_d8 [2];
  undefined8 uStack_c8;
  undefined auStack_c0 [4];
  undefined auStack_bc [2];
  undefined auStack_ba [8];
  undefined4 uStack_b2;
  undefined auStack_ae [4];
  uint uStack_aa;
  undefined2 uStack_a6;
  undefined4 uStack_9c;
  ushort uStack_98;
  ushort uStack_96;
  ulonglong uStack_90;
  longlong lStack_88;
  ushort *puStack_80;
  longlong lStack_78;
  undefined8 uStack_70;
  undefined2 *puStack_68;
  uint uStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  uint uStack_54;
  longlong lStack_50;
  longlong lStack_48;
  undefined4 *puStack_40;
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)&uStack_c8;
  puVar29 = param_1 + -0x14;
  uStack_c8._0_4_ = param_4;
  uStack_70 = param_3;
  puStack_68 = param_1;
  puStack_40 = param_2;
  if (*(int *)(param_1 + -0x13) == 0) {
    pbVar20 = *(byte **)(param_1 + -0x11);
    uVar27 = *(uint *)(param_1 + -0xd);
    uVar25 = (ulonglong)uVar27;
    *puVar29 = 0;
    *(uint *)(param_1 + -0xb) = uVar27;
    bVar12 = *pbVar20;
    if ((bVar12 & 0x10) != 0) {
      uVar27 = uVar27 + 2 + (*(ushort *)(pbVar20 + uVar25) + 7 >> 3);
      uVar25 = (ulonglong)uVar27;
      *(uint *)(param_1 + -0xb) = uVar27;
      bVar12 = *pbVar20;
    }
    if ((bVar12 & 0x20) == 0) {
      *(int *)(param_1 + -0x13) = (int)uVar25;
      param_1[-7] = 0;
      *(int *)(param_1 + -9) = (int)uVar25;
    }
    else {
      puVar31 = (ushort *)(pbVar20 + uVar25);
      uVar18 = *puVar31;
      param_1[-7] = uVar18;
      if (uVar18 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0)) &&
           ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
            (*(char *)(lVar15 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_100[0] = 0x10013a;
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            alStack_d8[0] = 0;
            auStack_100[0] = 0x100160;
            (*_DAT_)(1,0x9db8d8,0xafb5a8,0x80f);
          }
        }
        auStack_100[0] = 0x10016e;
        func_0x(*(undefined8 *)(param_1 + -0x11),3);
        uVar18 = param_1[-7];
        uVar25 = (ulonglong)*(uint *)(param_1 + -0xb);
      }
      uVar27 = (int)uVar25 + (uVar18 + 1) * 2;
      *(uint *)(param_1 + -9) = uVar27;
      if (0x1f9e < uVar27) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0 &&
            ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
             (*(char *)(lVar15 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_100[0] = 0x10020c;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            alStack_d8[0] = 0;
            auStack_100[0] = 0x100232;
            (*_DAT_)(1,0x9db8d8,0xafb5a8,0x816);
          }
        }
        auStack_100[0] = 0x100240;
        func_0x(*(undefined8 *)(param_1 + -0x11),4);
        uVar18 = param_1[-7];
        uVar27 = *(uint *)(param_1 + -9);
      }
      uVar28 = puVar31[uVar18] & 0x7fff;
      *(uint *)(param_1 + -0x13) = uVar28;
      if (uVar28 < uVar27) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0)) &&
           ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
            (*(char *)(lVar15 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            auStack_100[0] = 0x1002dc;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            alStack_d8[0] = 0;
            auStack_100[0] = 0x100302;
            (*_DAT_)(1,0x9db8d8,0xafb5a8,0x81d);
          }
        }
        auStack_100[0] = 0x100310;
        func_0x(*(undefined8 *)(param_1 + -0x11),4);
        uVar18 = param_1[-7];
        uVar28 = *(uint *)(param_1 + -0x13);
      }
      uVar25 = (ulonglong)uVar28;
      if ((short)puVar31[(ulonglong)(uVar18 - 1) + 1] < 0) {
        do {
          lVar15 = *(longlong *)(param_1 + -0x11);
          if (uVar18 == 1) {
            uVar27 = *(uint *)(param_1 + -9);
            uVar28 = uVar27;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + -0xb) + lVar15 + (ulonglong)uVar18 * 2)
                & 0x7fff) < uVar27) goto LAB_;
          }
          else {
            uVar28 = *(uint *)(param_1 + -9);
            uVar27 = *(ushort *)
                      ((ulonglong)*(uint *)(param_1 + -0xb) + lVar15 + -2 + (ulonglong)uVar18 * 2) &
                     0x7fff;
            if (uVar28 <= uVar27) goto LAB_;
LAB_:
            auStack_100[0] = 0x100378;
            func_0x(lVar15,7);
            uVar28 = *(uint *)(param_1 + -9);
            lVar15 = *(longlong *)(param_1 + -0x11);
            uVar18 = param_1[-7];
          }
          if ((uVar27 < uVar28) ||
             (uVar25 = (ulonglong)*(uint *)(param_1 + -0x13), *(uint *)(param_1 + -0x13) < uVar27))
          goto LAB_;
          if (*(ushort *)(lVar15 + (ulonglong)uVar27) == 5) {
            *puVar29 = *puVar29 | 2;
            param_1[-7] = uVar18 - 1;
            *param_1 = (short)uVar27;
            lVar15 = (ulonglong)(uVar27 & 0xffff) + *(longlong *)(param_1 + -0x11);
            uVar18 = param_1[1] & 0xc7ff;
            if ((*(ushort *)(lVar15 + 2) >> 0xe & 1) != 0) {
              uVar18 = *(ushort *)(lVar15 + 2) & 0x3800 | param_1[1] & 0xc7ff;
            }
            param_1[1] = uVar18;
            param_1[1] = (uVar18 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar18;
            uVar25 = (ulonglong)*(uint *)(param_1 + -0x13);
            goto LAB_;
          }
          if (*(ushort *)(lVar15 + (ulonglong)uVar27) < 0x400) goto LAB_;
          *puVar29 = *puVar29 | 1;
          uVar18 = uVar18 - 1;
          param_1[-7] = uVar18;
          if (uVar18 == 0) goto LAB_;
        } while ((short)puVar31[(ulonglong)(uVar18 - 1) + 1] < 0);
        pbVar20 = *(byte **)(param_1 + -0x11);
      }
      else {
LAB_:
        pbVar20 = *(byte **)(param_1 + -0x11);
      }
    }
    iVar13 = 0;
    if ((*pbVar20 & 0x40) == 0) {
      *(undefined4 *)(param_1 + -2) = 0;
    }
    else {
      *(int *)(param_1 + -2) = (int)uVar25;
      *(int *)(param_1 + -0x13) = (int)uVar25 + 0xe;
      auStack_100[0] = 0x10046a;
      puVar14 = (ulonglong *)func_0x(puVar29);
      uVar26 = (ushort)(*puVar14 >> 0x30);
      uVar18 = uVar26;
      if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
        uVar18 = uVar26 & 0xdfff;
        if ((uVar26 >> 0xe & 1) != 0) {
          uVar18 = uVar26 | 0x2000;
        }
      }
      if (uVar18 == 0xfffc) {
        iVar13 = (int)((*puVar14 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + -0x13) = *(int *)(param_1 + -0x13) + iVar13;
      uVar25 = (ulonglong)*(uint *)(param_1 + -0x13);
      pbVar20 = *(byte **)(param_1 + -0x11);
    }
    iVar13 = (int)uVar25;
    if ((*(byte **)(param_1 + -6) != (byte *)0x0) && (*(byte **)(param_1 + -6) < pbVar20 + uVar25))
    {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar15 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar15 != 0 &&
           (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
          (*(char *)(lVar15 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          auStack_100[0] = 0x10055d;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          alStack_d8[0] = 0;
          auStack_100[0] = 0x100583;
          (*_DAT_)(1,0x9db8d8,0xafb5a8,0x877);
        }
      }
      auStack_100[0] = 0x100591;
      func_0x(*(undefined8 *)(param_1 + -0x11),0x12);
      iVar13 = *(int *)(param_1 + -0x13);
    }
    if (0x3f3b < iVar13 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar15 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar15 != 0 &&
          ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
           (*(char *)(lVar15 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          auStack_100[0] = 0x10061d;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
          auStack_100[0] = 0x10062b;
          func_0x(*(undefined8 *)(param_1 + -0x11),5);
          goto LAB_;
        }
        alStack_d8[0] = 0;
        auStack_100[0] = 0x100651;
        (*_DAT_)(1,0x9db8d8,0xafb5a8,0x87c);
      }
      auStack_100[0] = 0x10065f;
      func_0x(*(undefined8 *)(param_1 + -0x11),5);
    }
  }
LAB_:
  uVar27 = *(uint *)(param_1 + -0x13);
  uVar28 = 9;
  if (uVar27 < 9) {
    pbVar20 = *(byte **)(param_1 + -0x11);
    if (((*pbVar20 & 0xe) == 0) || ((*pbVar20 & 0xe) == 0xc)) goto LAB_;
  }
  pbVar20 = *(byte **)(param_1 + -0x11);
  uVar28 = uVar27;
LAB_:
  auStack_100[0] = 0x1006b0;
  pbVar21 = pbVar20;
  lVar15 = func_0x(pbVar20,uVar27,0xffffffffffffff0);
  lVar15 = -lVar15;
  if (uVar27 == 0) {
    uVar27 = *(uint *)(param_1 + -0xd);
    uVar25 = (ulonglong)uVar27;
    *(uint *)(param_1 + -0xb) = uVar27;
    *puVar29 = 0;
    if ((*pbVar20 & 0x10) != 0) {
      uVar27 = uVar27 + 2 + (*(ushort *)(pbVar20 + uVar25) + 7 >> 3);
      uVar25 = (ulonglong)uVar27;
      *(uint *)(param_1 + -0xb) = uVar27;
    }
    if ((*pbVar20 & 0x20) == 0) {
      *(int *)(param_1 + -0x13) = (int)uVar25;
      param_1[-7] = 0;
      *(int *)(param_1 + -9) = (int)uVar25;
    }
    else {
      puVar31 = (ushort *)(pbVar20 + uVar25);
      uVar18 = *puVar31;
      param_1[-7] = uVar18;
      if (uVar18 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar33 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar33 != 0)) &&
           ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
            (*(char *)(lVar33 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100780;
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            *(undefined8 *)((longlong)alStack_d8 + lVar15) = 0;
            *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x1007a6;
            (*_DAT_)(1,0x9db8d8,0xafb5a8,0x80f);
          }
        }
        uVar5 = *(undefined8 *)(param_1 + -0x11);
        *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x1007b4;
        func_0x(uVar5,3);
        uVar18 = param_1[-7];
        uVar25 = (ulonglong)*(uint *)(param_1 + -0xb);
      }
      uVar27 = (int)uVar25 + (uVar18 + 1) * 2;
      *(uint *)(param_1 + -9) = uVar27;
      if (0x1f9e < uVar27) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar33 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar33 != 0 &&
            ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
             (*(char *)(lVar33 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x10084f;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)((longlong)alStack_d8 + lVar15) = 0;
            *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100875;
            (*_DAT_)(1,0x9db8d8,0xafb5a8,0x816);
          }
        }
        uVar5 = *(undefined8 *)(param_1 + -0x11);
        *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100883;
        func_0x(uVar5,4);
        uVar18 = param_1[-7];
        uVar27 = *(uint *)(param_1 + -9);
      }
      uVar32 = puVar31[uVar18] & 0x7fff;
      *(uint *)(param_1 + -0x13) = uVar32;
      if (uVar32 < uVar27) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar33 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar33 != 0)) &&
           ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
            (*(char *)(lVar33 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100921;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)((longlong)alStack_d8 + lVar15) = 0;
            *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100947;
            (*_DAT_)(1,0x9db8d8,0xafb5a8,0x81d);
          }
        }
        uVar5 = *(undefined8 *)(param_1 + -0x11);
        *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100955;
        func_0x(uVar5,4);
        uVar18 = param_1[-7];
        uVar32 = *(uint *)(param_1 + -0x13);
      }
      uVar25 = (ulonglong)uVar32;
      if ((short)puVar31[(ulonglong)(uVar18 - 1) + 1] < 0) {
        do {
          pbVar21 = *(byte **)(param_1 + -0x11);
          if (uVar18 == 1) {
            uVar27 = *(uint *)(param_1 + -9);
            uVar32 = uVar27;
LAB_:
            if ((*(ushort *)(pbVar21 + (ulonglong)uVar18 * 2 + (ulonglong)*(uint *)(param_1 + -0xb))
                & 0x7fff) < uVar27) goto LAB_;
          }
          else {
            uVar32 = *(uint *)(param_1 + -9);
            uVar27 = *(ushort *)
                      (pbVar21 + (ulonglong)uVar18 * 2 + ((ulonglong)*(uint *)(param_1 + -0xb) - 2))
                     & 0x7fff;
            if (uVar32 <= uVar27) goto LAB_;
LAB_:
            *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x1009bb;
            func_0x(pbVar21,7);
            pbVar21 = *(byte **)(param_1 + -0x11);
            uVar32 = *(uint *)(param_1 + -9);
            uVar18 = param_1[-7];
          }
          pbVar20 = pbVar21;
          if ((uVar27 < uVar32) ||
             (uVar25 = (ulonglong)*(uint *)(param_1 + -0x13), *(uint *)(param_1 + -0x13) < uVar27))
          goto LAB_;
          if (*(ushort *)(pbVar21 + uVar27) == 5) {
            *puVar29 = *puVar29 | 2;
            param_1[-7] = uVar18 - 1;
            *puStack_68 = (short)uVar27;
            lVar33 = (ulonglong)(uVar27 & 0xffff) + *(longlong *)(puStack_68 + -0x11);
            uVar18 = puStack_68[1] & 0xc7ff;
            if ((*(ushort *)(lVar33 + 2) >> 0xe & 1) != 0) {
              uVar18 = *(ushort *)(lVar33 + 2) & 0x3800 | puStack_68[1] & 0xc7ff;
            }
            puStack_68[1] = uVar18;
            puStack_68[1] = (uVar18 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar18;
            uVar25 = (ulonglong)*(uint *)(puStack_68 + -0x13);
            goto LAB_;
          }
          if (*(ushort *)(pbVar21 + uVar27) < 0x400) goto LAB_;
          *puVar29 = *puVar29 | 1;
          uVar18 = uVar18 - 1;
          param_1[-7] = uVar18;
          if (uVar18 == 0) goto LAB_;
        } while ((short)puVar31[(ulonglong)(uVar18 - 1) + 1] < 0);
        pbVar20 = *(byte **)(param_1 + -0x11);
      }
      else {
LAB_:
        pbVar20 = *(byte **)(param_1 + -0x11);
      }
    }
    iVar13 = 0;
    if ((*pbVar20 & 0x40) == 0) {
      *(undefined4 *)(param_1 + -2) = 0;
      pbVar21 = pbVar20;
    }
    else {
      *(int *)(param_1 + -2) = (int)uVar25;
      *(int *)(param_1 + -0x13) = (int)uVar25 + 0xe;
      *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100abc;
      puVar14 = (ulonglong *)func_0x(puVar29);
      uVar26 = (ushort)(*puVar14 >> 0x30);
      uVar18 = uVar26;
      if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
        uVar18 = uVar26 & 0xdfff;
        if ((uVar26 >> 0xe & 1) != 0) {
          uVar18 = uVar26 | 0x2000;
        }
      }
      if (uVar18 == 0xfffc) {
        iVar13 = (int)((*puVar14 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + -0x13) = *(int *)(param_1 + -0x13) + iVar13;
      uVar25 = (ulonglong)*(uint *)(param_1 + -0x13);
      pbVar21 = *(byte **)(param_1 + -0x11);
    }
    uVar27 = (uint)uVar25;
    if ((*(byte **)(param_1 + -6) != (byte *)0x0) && (*(byte **)(param_1 + -6) < pbVar21 + uVar25))
    {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar33 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar33 != 0 &&
           (lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0)) &&
          (*(char *)(lVar33 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100bc4;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)((longlong)alStack_d8 + lVar15) = 0;
          *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100bea;
          (*_DAT_)(1,0x9db8d8,0xafb5a8,0x877);
        }
      }
      uVar5 = *(undefined8 *)(param_1 + -0x11);
      *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100bf8;
      func_0x(uVar5,0x12);
      pbVar21 = *(byte **)(param_1 + -0x11);
      uVar27 = *(uint *)(param_1 + -0x13);
    }
    if ((uVar27 == 0) || (pbVar20 = pbVar21, 0x3f3c < uVar27)) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar33 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar33 != 0 &&
           (lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0)) &&
          (*(char *)(lVar33 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100c8d;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)((longlong)alStack_d8 + lVar15) = 0;
          *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100cb3;
          (*_DAT_)(1,0x9db8d8,0xafb5a8,0x87c);
        }
      }
      uVar5 = *(undefined8 *)(param_1 + -0x11);
      *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100cc1;
      func_0x(uVar5,5);
      pbVar21 = *(byte **)(param_1 + -0x11);
      pbVar20 = pbVar21;
    }
  }
LAB_:
  unique0x0000c200 = *(uint *)(param_1 + -0x13);
  if ((8 < unique0x0000c200) ||
     ((pbVar21 = pbVar20, uVar27 = 9, (*pbVar20 & 0xe) != 0 && ((*pbVar20 & 0xe) != 0xc)))) {
    uVar27 = unique0x0000c200;
  }
  uStack_b2 = *(undefined4 *)(param_1 + -0xd);
  auStack_c0._0_2_ = *puVar29;
  uStack_a6 = param_1[-7];
  auStack_ae = *(undefined (*) [4])(param_1 + -0xb);
  uStack_aa = *(uint *)(param_1 + -9);
  uStack_9c = *(undefined4 *)(param_1 + -2);
  *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100d1f;
  func_0x((longlong)&uStack_c8 + lVar15,uVar28,pbVar21,uVar27);
  auStack_ba = (undefined  [8])((longlong)&uStack_c8 + lVar15);
  *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100d2c;
  iVar13 = func_0x(auStack_c0);
  lVar33 = (longlong)auStack_ba;
  if (iVar13 == 0) {
    uVar25 = (ulonglong)uStack_98;
  }
  else {
    puVar29 = (ushort *)((ulonglong)(uint)auStack_ae + (longlong)auStack_ba);
    uVar27 = *puVar29 - 1;
    if ((auStack_c0._0_2_ & 1) == 0) {
      uVar27 = (uint)*puVar29;
    }
    uVar28 = uStack_aa;
    if (((uVar27 != 1) &&
        (uVar28 = puVar29[(longlong)(int)uVar27 + -1] & 0x7fff, uVar28 < uStack_aa)) ||
       ((puVar29[(int)uVar27] & 0x7fff) < uVar28)) {
      *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100d82;
      func_0x(lVar33,7);
    }
    uVar25 = (ulonglong)(uVar28 & 0xffff);
    uStack_98 = (ushort)uVar28;
    uVar18 = *(ushort *)(uVar25 + 2 + (longlong)auStack_ba);
    if ((uVar18 >> 0xe & 1) == 0) {
      uStack_96 = uStack_96 & 0xc7ff;
    }
    else {
      uStack_96 = uStack_96 ^ (uVar18 ^ uStack_96) & 0x3800;
    }
    uStack_96 = (uStack_96 ^ *(ushort *)(uVar25 + 2 + (longlong)auStack_ba)) & 0x7ff ^ uStack_96;
  }
  uVar26 = uStack_96;
  lVar33 = (longlong)auStack_ba;
  uVar18 = uStack_96 & 0x7ff;
  uVar27 = uStack_96 & 0x7ff;
  uVar16 = ((ulonglong)uVar27 + 1) * 0x20;
  uVar22 = uVar16 + 0xf;
  if (uVar22 <= uVar16) {
    uVar22 = 0xffffffffffffff0;
  }
  uVar22 = uVar22 & 0xfffffffffffffff0;
  uStack_90 = uVar25;
  *(undefined8 *)((longlong)auStack_100 + lVar15) = 0x100e23;
  func_0x();
  uVar5 = uStack_70;
  lVar6 = -uVar22;
  lVar2 = (longlong)&uStack_c8 + lVar6 + lVar15;
  lStack_78 = lVar2;
  if (uVar18 != 0) {
    uVar28 = uVar26 >> 0xb & 7;
    lVar1 = uVar25 + lVar33;
    uVar22 = (ulonglong)(uVar28 * 2);
    lStack_48 = lVar1;
    lVar17 = uVar25 + 4 + uVar22 + lVar33;
    lStack_50 = lVar17;
    puVar29 = (ushort *)(lVar1 + 4);
    lVar23 = uVar22 + uVar27 * 2 + uVar25 + 4 + lVar33;
    lStack_88 = lVar23;
    uVar32 = (int)uVar25 + (((uVar27 * 2 + uVar28) * 2 + 4) - (int)lVar1) + auStack_ba._0_4_;
    uVar28 = 0;
    lVar35 = 0;
    uVar18 = uStack_5c._2_2_;
    do {
      if ((uVar26 & 0x3800) == 0) {
        uVar30 = *(ushort *)((uVar25 & 0xffff) + 2 + lVar33);
        uVar3 = uVar26;
      }
      else {
        uVar30 = *puVar29;
        uVar3 = uVar30;
      }
      lVar36 = (ulonglong)(uVar3 & 0x7ff) - 1;
      if (lVar35 <= lVar36) {
        puVar31 = (ushort *)(lVar23 + lVar35 * 2);
        puVar34 = (uint *)((longlong)auStack_bc + lVar35 * 0x20 + lVar6 + lVar15);
        uVar26 = uVar18;
        do {
          uVar18 = uVar26;
          if ((longlong)(ulonglong)uVar27 <= lVar35) break;
          lVar35 = lVar35 + 1;
          uVar19 = (uint)*(ushort *)((lVar17 - lVar23) + (longlong)puVar31) +
                   (uint)(uVar30 >> 0xb & 7) * 0x10000 | 0x80000000;
          uStack_60 = uVar19;
          uVar3 = *puVar31;
          uVar18 = uVar26 & 0xfff0;
          uVar25 = (ulonglong)uVar28;
          uVar28 = uVar28 + 1;
          uStack_5c = (uVar26 & 0xfff0) << 0x10;
          uVar26 = *(ushort *)(lVar23 + uVar25 * 2);
          *(ulonglong *)(puVar34 + -3) = (ulonglong)uVar32 + lVar1;
          puVar34[1] = uVar19;
          puVar34[2] = uStack_5c;
          puVar34[3] = uStack_58;
          puVar34[4] = uStack_54;
          puVar34[-1] = (uVar3 & 0x7fff) - uVar32;
          *puVar34 = *puVar34 & 0xfffffff0 | (uint)(uVar26 >> 0xf);
          puVar34 = puVar34 + 8;
          uVar26 = *puVar31;
          puVar31 = puVar31 + 1;
          uVar32 = uVar26 & 0x7fff;
          uVar26 = uVar18;
        } while (lVar35 <= lVar36);
        uStack_90 = (ulonglong)uStack_98;
        lVar33 = (longlong)auStack_ba;
        uVar26 = uStack_96;
      }
      puVar29 = puVar29 + 1;
      puStack_80 = puVar29;
      uVar25 = uStack_90;
    } while (lVar35 < (longlong)(ulonglong)uVar27);
  }
  if ((param_5 < 0) || ((int)(uVar26 & 0x7ff) <= param_5)) {
    puVar24 = (undefined8 *)(((ulonglong)uVar26 & 0x7ff) * 0x20 + lVar2);
    *(uint *)((longlong)puVar24 + 0xc) = *(uint *)((longlong)puVar24 + 0xc) & 0xfffffffa;
    *puVar24 = uVar5;
    *(undefined4 *)(puVar24 + 1) = (undefined4)uStack_c8;
    uVar7 = *puStack_40;
    uVar8 = puStack_40[1];
    uVar9 = puStack_40[2];
    uVar10 = puStack_40[3];
    *(uint *)((longlong)puVar24 + 0xc) = *(uint *)((longlong)puVar24 + 0xc) & 0xfffffff5;
    *(undefined4 *)(puVar24 + 2) = uVar7;
    *(undefined4 *)((longlong)puVar24 + 0x14) = uVar8;
    *(undefined4 *)(puVar24 + 3) = uVar9;
    *(undefined4 *)((longlong)puVar24 + 0x1c) = uVar10;
    uVar18 = (uStack_96 & 0x7ff) + 1;
  }
  else {
    *(undefined8 *)(lVar2 + (longlong)param_5 * 0x20) = uStack_70;
    *(undefined4 *)((longlong)auStack_c0 + (longlong)param_5 * 0x20 + lVar6 + lVar15) =
         (undefined4)uStack_c8;
    uVar18 = uStack_96 & 0x7ff;
  }
  puVar11 = puStack_68;
  *(undefined8 **)((longlong)alStack_d8 + lVar6 + lVar15 + 8) = &uStack_c8;
  *(longlong *)((longlong)alStack_d8 + lVar6 + lVar15) = lVar2;
  uVar4 = *puVar11;
  *(undefined8 *)((longlong)auStack_100 + lVar6 + lVar15) = 0x10105e;
  func_0x(puVar11,uVar4,0x1f9e,uVar18);
  uVar25 = uStack_38 ^ (ulonglong)&uStack_c8;
  *(undefined8 *)((longlong)auStack_100 + lVar6 + lVar15) = 0x101070;
  func_0x(uVar25);
  return;
}

