
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                 undefined8 param_5,longlong param_6)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong unaff_GS_OFFSET;
  undefined auStack_2c8 [68];
  undefined4 uStack_284;
  undefined8 uStack_280;
  undefined8 uStack_278;
  undefined8 uStack_270;
  undefined2 uStack_268;
  undefined2 uStack_210;
  undefined4 uStack_20c;
  byte *pbStack_208;
  undefined8 uStack_200;
  undefined8 uStack_1f2;
  undefined2 uStack_1ea;
  undefined2 uStack_1e8;
  undefined6 uStack_1e6;
  undefined4 uStack_1dc;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_2c8;
  uStack_210 = 0xffff;
  pbStack_208 = (byte *)0x0;
  uStack_20c = 0;
  uStack_1f2 = 0;
  uStack_1e8 = 0;
  uStack_1e6 = 0;
  uStack_200 = 0;
  uStack_284 = param_3;
  uStack_280 = param_2;
  uStack_278 = param_4;
  lVar3 = func_0x(_DAT_,*param_1,1);
  *(ushort *)(lVar3 + 4) = *(ushort *)(lVar3 + 4) & 0xedff;
  *(undefined4 *)(lVar3 + 0x40) = 1;
  if (*(short *)((longlong)*param_1 + 0x2c) != 2) {
    lVar4 = (*param_1)[0x12];
    if (lVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)(*(longlong *)(lVar4 + 0x6b0) + 0x3c) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*param_1)[0x12] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)((*param_1)[0x12] + 0x1cd0) & 0x20) == 0) {
      lVar4 = **param_1;
      if (*(short *)(lVar4 + 0x24) != 0) {
        cVar1 = *(char *)(lVar4 + 1);
        if (cVar1 == '\v') {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((cVar1 == '\b') || (cVar1 == '\t')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
      uStack_270 = *(undefined8 *)(lVar4 + 0x28);
      uStack_268 = *(undefined2 *)(lVar4 + 0x30);
      lVar4 = (*param_1)[0x12];
      if (lVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar4 = func_0x
                        (*(undefined8 *)(lVar4 + 0x6a0),*(undefined2 *)((longlong)*param_1 + 0x74),0
                        );
      plVar2 = *param_1;
      if (plVar2[0x12] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(int *)(*(longlong *)(plVar2[0x12] + 0x7a8) + 0x58) == 0) &&
         (*(uint *)(lVar4 + 0x130) <= (uint)uStack_270)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (plVar2[0x12] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)(*(longlong *)(plVar2[0x12] + 0x6b0) + 0x3c) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (plVar2[0x12] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(plVar2[0x12],*plVar2 + 0x20);
    }
  }
  if ((*(ushort *)(**param_1 + 4) & 0x2000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_6 != 0) {
    if ((DAT_ & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar4 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar4 != 0) && (**(longlong **)(lVar4 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  uStack_1dc = 0;
  if (*(char *)(lVar3 + 2) < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pbStack_208 = (byte *)((ulonglong)*(ushort *)(lVar3 + 0x1ffe) + lVar3);
  if ((*pbStack_208 & 1) == 0) {
    uStack_210 = 0;
    uStack_20c = 0;
    uStack_1ea = 0;
    uStack_1e8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100295 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_208 & 0xe) * 4 + 0xfffb4) - 0xe7070))
              (0x23d27b8);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

