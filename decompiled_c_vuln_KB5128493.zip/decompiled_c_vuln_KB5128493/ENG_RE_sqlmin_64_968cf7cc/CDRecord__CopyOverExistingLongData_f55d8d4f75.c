
undefined8
FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,uint param_4,uint *param_5,
            uint param_6)

{
  ushort uVar1;
  ushort uVar2;
  uint uVar3;
  undefined8 uVar4;
  uint uVar5;
  ushort uVar6;
  uint uVar7;
  longlong lVar8;
  short sVar9;
  ushort *puVar10;
  int iVar11;
  ulonglong uVar12;
  
  puVar10 = (ushort *)(*(longlong *)(param_1 + 6) + (ulonglong)*(ushort *)(param_1 + 0x1c) + 1);
  uVar12 = (ulonglong)param_4;
  uVar3 = func_0x();
  uVar1 = *(ushort *)(param_1 + 0x1c);
  uVar6 = 0;
  lVar8 = *(longlong *)(param_1 + 6) + (ulonglong)uVar1;
  if (uVar3 != 0) {
    uVar6 = *(ushort *)(lVar8 + 3 + (ulonglong)(uVar3 - 1) * 2) & 0x7fff;
  }
  uVar2 = *(ushort *)(param_1 + 0x22);
  uVar5 = (uint)(*(ushort *)((ulonglong)uVar3 * 2 + 3 + lVar8) & 0x7fff) - (uint)uVar6;
  lVar8 = (ulonglong)uVar6 + *(longlong *)(param_1 + 6) + (ulonglong)uVar2 + (ulonglong)uVar1;
  if (param_4 == uVar5) {
    func_0x(lVar8,uVar12,param_3,uVar5);
    uVar4 = 1;
  }
  else {
    sVar9 = (short)param_4 - (short)uVar5;
    iVar11 = (int)sVar9;
    *param_5 = *param_5 + iVar11;
    if (param_6 < *param_5) {
      uVar4 = 0;
    }
    else {
      uVar7 = (uint)(ushort)((puVar10[(ulonglong)uVar3 + 1] & 0x7fff) + uVar2 + uVar1);
      if (uVar7 != *(uint *)(param_1 + 2)) {
        func_0x
                  (uVar12 + lVar8,(ulonglong)uVar5 + lVar8,*(uint *)(param_1 + 2) - uVar7);
      }
      func_0x(lVar8,uVar12,param_3,uVar12);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar11;
      if (*(int *)(param_1 + 0x2e) != 0) {
        *(int *)(param_1 + 0x2e) = *(int *)(param_1 + 0x2e) + iVar11;
      }
      if (uVar3 < *puVar10) {
        do {
          uVar1 = puVar10[(ulonglong)uVar3 + 1];
          uVar5 = uVar3 + 1;
          puVar10[(ulonglong)uVar3 + 1] = (uVar1 + sVar9 ^ uVar1) & 0x7fff ^ uVar1;
          uVar3 = uVar5;
        } while (uVar5 < *puVar10);
      }
      uVar4 = 1;
    }
  }
  return uVar4;
}

