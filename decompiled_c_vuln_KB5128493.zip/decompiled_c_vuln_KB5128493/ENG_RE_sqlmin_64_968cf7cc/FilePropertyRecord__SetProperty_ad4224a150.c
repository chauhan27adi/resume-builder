
/* WARNING: Control flow encountered bad instruction data */

void FUN_(short *param_1,uint param_2,longlong param_3,undefined4 param_4)

{
  ushort uVar1;
  ushort uVar2;
  byte *pbVar3;
  byte bVar4;
  longlong lVar5;
  uint uVar6;
  ulonglong uVar7;
  ushort *puVar8;
  undefined auStack_48 [4];
  ushort uStack_44;
  
  func_0x(auStack_48,-param_2,param_2 & 0xffff,0,0);
  if (*param_1 == 0) {
    if (*(int *)(param_1 + 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((**(byte **)(param_1 + 4) & 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < param_2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (param_3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(param_1,auStack_48,param_3,param_4);
  if (*param_1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar5 = (ulonglong)(uStack_44 - 1 >> 3) + (longlong)*(int *)(param_1 + 8) +
          *(longlong *)(param_1 + 4);
  *(byte *)(lVar5 + 2) = *(byte *)(lVar5 + 2) & ~(byte)(1 << (uStack_44 - 1 & 7));
  if (*param_1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pbVar3 = *(byte **)(param_1 + 4);
  uVar6 = *(uint *)(param_1 + 8);
  uVar7 = (ulonglong)uVar6;
  param_1[1] = 0;
  *(uint *)(param_1 + 10) = uVar6;
  bVar4 = *pbVar3;
  if ((bVar4 & 0x10) != 0) {
    uVar6 = uVar6 + 2 + (*(ushort *)(pbVar3 + uVar7) + 7 >> 3);
    uVar7 = (ulonglong)uVar6;
    *(uint *)(param_1 + 10) = uVar6;
    bVar4 = *pbVar3;
  }
  if ((bVar4 & 0x20) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar8 = (ushort *)(pbVar3 + uVar7);
  uVar1 = *puVar8;
  param_1[0xe] = uVar1;
  if (uVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar6 = (int)uVar7 + (uVar1 + 1) * 2;
  *(uint *)(param_1 + 0xc) = uVar6;
  if (0x1f9e < uVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = puVar8[uVar1];
  *(uint *)(param_1 + 2) = uVar2 & 0x7fff;
  if ((uVar2 & 0x7fff) < uVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((short)puVar8[(ulonglong)(uVar1 - 1) + 1] < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((**(byte **)(param_1 + 4) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined4 *)(param_1 + 0x13) = 0;
  if (*(longlong *)(param_1 + 0xf) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (0x3f3b < *(int *)(param_1 + 2) - 1U) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}

