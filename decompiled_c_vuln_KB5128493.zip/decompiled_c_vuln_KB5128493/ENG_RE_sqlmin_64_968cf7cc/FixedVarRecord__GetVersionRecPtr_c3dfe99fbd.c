
undefined8 * FUN_(longlong param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  code *pcVar2;
  undefined8 *puVar3;
  
  if (*(int *)(param_1 + 2) != 0) {
    *param_2 = 0;
    puVar3 = (undefined8 *)func_0x(param_1);
    if (puVar3 != (undefined8 *)0x0) {
      uVar1 = *puVar3;
      *(int *)param_2 = (int)uVar1;
      *(short *)((longlong)param_2 + 6) = (short)((ulonglong)uVar1 >> 0x30);
      *(short *)((longlong)param_2 + 4) = (short)((ulonglong)uVar1 >> 0x20);
    }
    return param_2;
  }
  pcVar2 = (code *)swi(3);
  puVar3 = (undefined8 *)(*pcVar2)();
  return puVar3;
}

