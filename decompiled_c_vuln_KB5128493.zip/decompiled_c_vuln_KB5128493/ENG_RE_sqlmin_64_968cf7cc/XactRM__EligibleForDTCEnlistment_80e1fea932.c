
/* WARNING: Control flow encountered bad instruction data */

ulonglong FUN_(longlong param_1,longlong param_2)

{
  int iVar1;
  ulonglong uVar2;
  
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x290) + 0x3b0))();
  if (((char)uVar2 == '\0') &&
     (uVar2 = *(ulonglong *)(param_2 + 0x2a8), *(int *)(uVar2 + 0x15c) != 2)) {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x290) + 400))();
    if ((iVar1 != 0) ||
       (uVar2 = *(ulonglong *)(param_1 + 0x290), (*(byte *)(uVar2 + 0x20) & 2) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  return uVar2 & 0xffffffffffffff00;
}

