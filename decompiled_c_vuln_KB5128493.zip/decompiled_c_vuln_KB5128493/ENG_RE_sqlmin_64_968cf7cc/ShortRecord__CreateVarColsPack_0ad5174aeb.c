
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,ulonglong param_3,uint param_4,ushort *param_5)

{
  ushort *puVar1;
  code *pcVar2;
  byte bVar3;
  uint uVar4;
  int iVar5;
  short *psVar6;
  uint *puVar7;
  ulonglong *puVar8;
  longlong lVar9;
  ulonglong uVar10;
  longlong lVar11;
  undefined8 uVar12;
  longlong lVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  ushort uVar16;
  undefined *puVar17;
  uint *puVar18;
  ushort *puVar19;
  undefined4 uVar20;
  uint uVar21;
  uint uVar22;
  short sVar23;
  ushort uVar24;
  byte *pbVar25;
  ushort uVar26;
  longlong unaff_GS_OFFSET;
  undefined auStack_c8 [64];
  ushort auStack_88 [2];
  uint uStack_84;
  uint uStack_80;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint uStack_70;
  uint uStack_6c;
  uint uStack_68;
  int iStack_64;
  longlong lStack_60;
  longlong lStack_58;
  longlong lStack_50;
  uint auStack_48 [2];
  longlong lStack_40;
  ulonglong uStack_38;
  
  puVar17 = auStack_c8;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_88;
  uVar22 = 0;
  uVar20 = 0;
  uStack_80 = 0;
  uStack_7c = (uStack_7c >> 0x10 & 0xffe0) << 0x10;
  lVar11 = *(longlong *)(param_2 + 8);
  puStack_78 = (uint *)0x0;
  lStack_50 = 0;
  iStack_64 = -1;
  uStack_70 = param_4;
  lStack_60 = param_2;
  lStack_40 = param_1;
  if (*(int *)(lVar11 + 0x100) == 2) {
    if ((*(byte *)(lVar11 + 0x42) & 4) == 0) {
      uVar15 = (ulonglong)*(uint *)(lVar11 + 0xb0);
      if (0x1f9e < *(uint *)(lVar11 + 0xb0)) {
        uVar15 = 0x1f9e;
      }
    }
    else {
      uVar15 = 0x1f9e;
    }
    uVar20 = (undefined4)uVar15;
    uVar10 = uVar15 + 0xf;
    if (uVar10 <= uVar15) {
      uVar10 = 0xffffffffffffff0;
    }
    uVar10 = uVar10 & 0xfffffffffffffff0;
    func_0x();
    puVar17 = auStack_c8 + -uVar10;
    lStack_50 = (longlong)auStack_88 + -uVar10;
  }
  lVar11 = lStack_50;
  psVar6 = *(short **)(param_1 + 8);
  if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
    pcVar2 = *(code **)**(undefined8 **)(param_1 + 0x10);
    *(undefined8 *)(puVar17 + -8) = 0x1000e3;
    psVar6 = (short *)(*pcVar2)();
  }
  if ((uint)param_3 != 0) {
    if (param_4 == 0) {
      *(undefined8 *)(puVar17 + 0x20) = 0;
      *(undefined8 *)(puVar17 + -8) = 0x100114;
      (*_DAT_)(1,0xbd7d20,0xb820c8,0x596);
    }
    auStack_88[0] = 0;
    *param_5 = (ushort)param_3;
    puVar1 = (ushort *)(psVar6 + 1);
    lStack_58 = (longlong)param_5 +
                (param_3 & 0xffff) * 2 + (ulonglong)((~((uint)param_3 & 0xffff) & 1) * 2) + 2;
    while( true ) {
      uStack_68 = uVar22;
      if (*psVar6 == 0) {
        *(undefined8 *)(puVar17 + -8) = 0x100157;
        uVar4 = func_0x(puVar1);
      }
      else {
        uVar4 = (uint)*puVar1;
      }
      if ((int)uVar4 <= (int)uVar22) break;
      uVar4 = ~uVar22;
      if ((int)uVar22 < 0) {
LAB_:
        lVar9 = lStack_60;
        *(undefined8 *)(puVar17 + -8) = 0x1001d4;
        func_0x(lVar9,uVar4,&uStack_80);
      }
      else {
        if ((uVar4 & 0xc0000000) == 0x80000000) {
          uVar12 = **(undefined8 **)(*(longlong *)(lStack_60 + 8) + 0x160);
          *(undefined8 *)(puVar17 + -8) = 0x1001b6;
          puVar7 = (uint *)func_0x(uVar12,uVar4 & 0x1fffffff);
        }
        else {
          uVar12 = *(undefined8 *)(*(longlong *)(lStack_60 + 8) + 0x160);
          *(undefined8 *)(puVar17 + -8) = 0x10019b;
          puVar7 = (uint *)func_0x(uVar12);
        }
        if (puVar7 == (uint *)0x0) goto LAB_;
        uStack_80 = *puVar7;
        uStack_7c = puVar7[1];
        puStack_78 = *(uint **)(puVar7 + 2);
      }
      *(undefined8 *)(puVar17 + -8) = 0x1001e0;
      iVar5 = func_0x(psVar6,&uStack_80);
      uVar26 = auStack_88[0];
      if (iVar5 == 0) {
        uVar15 = (ulonglong)auStack_88[0];
        if (auStack_88[0] == 0) {
          uVar16 = ((~*param_5 & 1) + *param_5 * 3 + 1) * 2;
        }
        else {
          uVar16 = param_5[uVar15] & 0x7fff;
        }
        param_5[uVar15 + 1] = uVar16 & 0x7fff;
        *(uint *)(lStack_58 + uVar15 * 4) = uVar4;
        if ((ushort)param_4 < uVar16) {
          *(undefined8 *)(puVar17 + 0x20) = 0;
          *(undefined8 *)(puVar17 + -8) = 0x100c8b;
          (*_DAT_)(1,0xbd7d60,0xb820c8,0x5c5);
        }
        uVar22 = uVar22 + 1;
        auStack_88[0] = uVar26 + 1;
        lVar11 = lStack_50;
      }
      else {
        if (*psVar6 == 0) {
          if ((uStack_80 & 0xc0000000) == 0x80000000) {
            *(undefined8 *)(puVar17 + -8) = 0x100a41;
            iVar5 = func_0x(puVar1);
            if (iVar5 == 0) goto LAB_;
            *(undefined8 *)(puVar17 + -8) = 0x100a5d;
            puVar7 = (uint *)func_0x(psVar6 + 0x15,&uStack_80,&uStack_84,auStack_48);
          }
          else {
            uVar26 = uStack_7c._2_2_ >> 4 & 1;
            if (uVar26 != 0) {
              bVar3 = **(byte **)(psVar6 + 4);
              if ((bVar3 & 0x10) == 0) {
                if ((1 << (bVar3 & 0xe) & 0x1105U) == 0) goto LAB_;
              }
              else if (((int)uStack_80 < (int)*(uint *)(psVar6 + 8)) &&
                      ((ushort)uStack_7c <=
                       *(ushort *)(*(byte **)(psVar6 + 4) + *(uint *)(psVar6 + 8))))
              goto LAB_;
              goto LAB_;
            }
LAB_:
            if ((int)uStack_80 < 0) {
              if (*(int *)(psVar6 + 2) == 0) {
                pbVar25 = *(byte **)(psVar6 + 4);
                uVar22 = *(uint *)(psVar6 + 8);
                uVar15 = (ulonglong)uVar22;
                *puVar1 = 0;
                *(uint *)(psVar6 + 10) = uVar22;
                bVar3 = *pbVar25;
                if ((bVar3 & 0x10) != 0) {
                  uVar22 = uVar22 + 2 + (*(ushort *)(pbVar25 + uVar15) + 7 >> 3);
                  uVar15 = (ulonglong)uVar22;
                  *(uint *)(psVar6 + 10) = uVar22;
                  bVar3 = *pbVar25;
                }
                iVar5 = (int)uVar15;
                if ((bVar3 & 0x20) == 0) {
                  *(int *)(psVar6 + 2) = iVar5;
                  psVar6[0xe] = 0;
                  *(int *)(psVar6 + 0xc) = iVar5;
                }
                else {
                  puVar19 = (ushort *)(pbVar25 + uVar15);
                  uVar26 = *puVar19;
                  psVar6[0xe] = uVar26;
                  if (uVar26 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar11 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar11 != 0)) &&
                       ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                        (*(char *)(lVar11 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar17 + -8) = 0x100409;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar17 + 0x20) = 0;
                        *(undefined8 *)(puVar17 + -8) = 0x10042f;
                        (*_DAT_)(1,0x9fa998,0xb1a668,0x80f);
                      }
                    }
                    uVar12 = *(undefined8 *)(psVar6 + 4);
                    *(undefined8 *)(puVar17 + -8) = 0x10043d;
                    func_0x(uVar12,3);
                    iVar5 = *(int *)(psVar6 + 10);
                    uVar26 = psVar6[0xe];
                  }
                  uVar22 = iVar5 + (uVar26 + 1) * 2;
                  *(uint *)(psVar6 + 0xc) = uVar22;
                  if (0x1f9e < uVar22) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar11 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar11 != 0 &&
                        ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                         (*(char *)(lVar11 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar17 + -8) = 0x1004dc;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar17 + 0x20) = 0;
                        *(undefined8 *)(puVar17 + -8) = 0x100502;
                        (*_DAT_)(1,0x9fa998,0xb1a668,0x816);
                      }
                    }
                    uVar12 = *(undefined8 *)(psVar6 + 4);
                    *(undefined8 *)(puVar17 + -8) = 0x100510;
                    func_0x(uVar12,4);
                    uVar26 = psVar6[0xe];
                    uVar22 = *(uint *)(psVar6 + 0xc);
                  }
                  uVar15 = (ulonglong)uVar26;
                  uVar26 = puVar19[uVar15];
                  *(uint *)(psVar6 + 2) = uVar26 & 0x7fff;
                  if ((uVar26 & 0x7fff) < uVar22) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar11 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar11 != 0)) &&
                       ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                        (*(char *)(lVar11 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar17 + -8) = 0x1005af;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar17 + 0x20) = 0;
                        *(undefined8 *)(puVar17 + -8) = 0x1005d5;
                        (*_DAT_)(1,0x9fa998,0xb1a668,0x81d);
                      }
                    }
                    uVar12 = *(undefined8 *)(psVar6 + 4);
                    *(undefined8 *)(puVar17 + -8) = 0x1005e3;
                    func_0x(uVar12,4);
                    uVar15 = (ulonglong)(ushort)psVar6[0xe];
                  }
                  if ((short)puVar19[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                    lVar11 = *(longlong *)(psVar6 + 4);
                    do {
                      if ((int)uVar15 == 1) {
                        uVar22 = *(uint *)(psVar6 + 0xc);
                        uVar21 = uVar22;
LAB_:
                        if ((*(ushort *)((ulonglong)*(uint *)(psVar6 + 10) + lVar11 + uVar15 * 2) &
                            0x7fff) < uVar22) goto LAB_;
                      }
                      else {
                        uVar21 = *(uint *)(psVar6 + 0xc);
                        uVar22 = *(ushort *)
                                  ((ulonglong)*(uint *)(psVar6 + 10) + lVar11 + -2 + uVar15 * 2) &
                                 0x7fff;
                        if (uVar21 <= uVar22) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar17 + -8) = 0x10063d;
                        func_0x(lVar11,7);
                        uVar21 = *(uint *)(psVar6 + 0xc);
                      }
                      if ((uVar22 < uVar21) || (*(uint *)(psVar6 + 2) < uVar22)) goto LAB_;
                      lVar11 = *(longlong *)(psVar6 + 4);
                      if (*(ushort *)((ulonglong)uVar22 + lVar11) == 5) {
                        *puVar1 = *puVar1 | 2;
                        psVar6[0xe] = psVar6[0xe] + -1;
                        psVar6[0x15] = (short)uVar22;
                        lVar11 = (ulonglong)(uVar22 & 0xffff) + *(longlong *)(psVar6 + 4);
                        uVar26 = psVar6[0x16] & 0xc7ffU;
                        if ((*(ushort *)(lVar11 + 2) & 0x4000) != 0) {
                          uVar26 = *(ushort *)(lVar11 + 2) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                        }
                        psVar6[0x16] = uVar26;
                        psVar6[0x16] = (uVar26 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar26;
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar22 + lVar11) < 0x400) break;
                      *puVar1 = *puVar1 | 1;
                      uVar26 = psVar6[0xe] - 1;
                      psVar6[0xe] = uVar26;
                      if ((uVar26 == 0) ||
                         (uVar15 = (ulonglong)uVar26,
                         -1 < (short)puVar19[(ulonglong)(uVar26 - 1) + 1])) break;
                    } while( true );
                  }
                }
                iVar5 = 0;
                if ((**(byte **)(psVar6 + 4) & 0x40) == 0) {
                  *(undefined4 *)(psVar6 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
                  *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
                  *(undefined8 *)(puVar17 + -8) = 0x1006ca;
                  puVar8 = (ulonglong *)func_0x(puVar1);
                  uVar15 = *puVar8;
                  uVar16 = (ushort)(uVar15 >> 0x30);
                  uVar26 = uVar16;
                  if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
                    uVar26 = uVar16 & 0xdfff;
                    if ((uVar15 & 0x4000000000000000) != 0) {
                      uVar26 = uVar16 | 0x2000;
                    }
                  }
                  if (uVar26 == 0xfffc) {
                    iVar5 = (int)((uVar15 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar5;
                }
                if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar6 + 0xf) <
                    (ulonglong)*(uint *)(psVar6 + 2) + *(longlong *)(psVar6 + 4))) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar11 = *(longlong *)
                                  (*(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                       lVar11 != 0 && (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
                      (*(char *)(lVar11 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar17 + -8) = 0x10083f;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar17 + 0x20) = 0;
                      *(undefined8 *)(puVar17 + -8) = 0x100865;
                      (*_DAT_)(1,0x9fa998,0xb1a668,0x877);
                    }
                  }
                  uVar12 = *(undefined8 *)(psVar6 + 4);
                  *(undefined8 *)(puVar17 + -8) = 0x100873;
                  func_0x(uVar12,0x12);
                }
                if (0x3f3b < *(int *)(psVar6 + 2) - 1U) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar11 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar11 != 0 &&
                      ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                       (*(char *)(lVar11 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar17 + -8) = 0x100901;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      uVar12 = *(undefined8 *)(psVar6 + 4);
                      *(undefined8 *)(puVar17 + -8) = 0x10090f;
                      func_0x(uVar12,5);
                      goto LAB_;
                    }
                    *(undefined8 *)(puVar17 + 0x20) = 0;
                    *(undefined8 *)(puVar17 + -8) = 0x100935;
                    (*_DAT_)(1,0x9fa998,0xb1a668,0x87c);
                  }
                  uVar12 = *(undefined8 *)(psVar6 + 4);
                  *(undefined8 *)(puVar17 + -8) = 0x100943;
                  func_0x(uVar12,5);
                }
              }
LAB_:
              sVar23 = -(short)uStack_80;
              uVar22 = 0;
              if ((uStack_7c & 0x100000) == 0) {
LAB_:
                lVar11 = (longlong)sVar23;
                if ((uint)(ushort)psVar6[0xe] < (uint)(int)sVar23) {
                  uStack_84 = 0;
                  puVar7 = *(uint **)(psVar6 + 4);
                }
                else {
                  lVar9 = (ulonglong)*(uint *)(psVar6 + 10) + *(longlong *)(psVar6 + 4);
                  if (sVar23 == 1) {
                    uVar22 = *(uint *)(psVar6 + 0xc);
                    uVar21 = *(ushort *)(lVar9 + lVar11 * 2) & 0x7fff;
LAB_:
                    if (uVar21 < uVar22) goto code_r0x00100a12;
                  }
                  else {
                    uVar22 = *(ushort *)(lVar9 + -2 + lVar11 * 2) & 0x7fff;
                    uVar21 = *(ushort *)(lVar9 + lVar11 * 2) & 0x7fff;
                    if (*(uint *)(psVar6 + 0xc) <= uVar22) goto LAB_;
code_r0x00100a12:
                    uVar12 = *(undefined8 *)(psVar6 + 4);
                    *(undefined8 *)(puVar17 + -8) = 0x100a20;
                    func_0x(uVar12,7);
                  }
                  uStack_84 = uVar21 - uVar22;
                  puVar7 = (uint *)((ulonglong)uVar22 + *(longlong *)(psVar6 + 4));
                }
              }
              else {
                if ((**(byte **)(psVar6 + 4) & 0x10) == 0) {
                  if ((1 << (**(byte **)(psVar6 + 4) & 0xe) & 0x1105U) == 0) goto LAB_;
                }
                else if ((int)uStack_80 < *(int *)(psVar6 + 8)) {
                  if ((**(byte **)(psVar6 + 4) & 0x10) != 0) {
                    uVar22 = (uint)*(ushort *)
                                    ((ulonglong)*(uint *)(psVar6 + 8) + *(longlong *)(psVar6 + 4));
                  }
                  if (uVar22 < (uStack_7c & 0xffff)) {
                    uStack_84 = *puStack_78;
                    puVar7 = puStack_78 + 1;
                    goto LAB_;
                  }
                  goto LAB_;
                }
LAB_:
                uStack_84 = *puStack_78;
                puVar7 = puStack_78 + 1;
              }
            }
            else {
              if ((uStack_7c & 0x80000) != 0) {
                puVar7 = (uint *)0x77f3d4;
                uStack_84 = 1;
                if ((*(byte *)(*(longlong *)(psVar6 + 4) + (longlong)(int)uStack_80) &
                    (byte)(1 << (uStack_7c._2_1_ & 7))) == 0) {
                  puVar7 = (uint *)0x77f9f8;
                }
                goto LAB_;
              }
              if (uVar26 != 0) {
                bVar3 = **(byte **)(psVar6 + 4);
                if ((bVar3 & 0x10) == 0) {
                  if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
                    puVar18 = (uint *)(ulonglong)*puStack_78;
                    puVar7 = puStack_78 + 1;
                    if (*puStack_78 != 0x1f9e) {
                      *(undefined8 *)(puVar17 + 0x20) = 0;
                      *(undefined8 *)(puVar17 + -8) = 0x1002fb;
                      (*_DAT_)(1,0xba8708,0xba7108,0x381);
                    }
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(psVar6 + 8) <= (int)uStack_80) ||
                        (*(ushort *)(*(byte **)(psVar6 + 4) + *(uint *)(psVar6 + 8)) <
                         (ushort)uStack_7c)) goto LAB_;
              }
              uStack_84 = 0x1f9e;
              puVar7 = (uint *)((longlong)(int)uStack_80 + *(longlong *)(psVar6 + 4));
            }
          }
        }
        else {
          uVar12 = 0;
          uStack_6c = 0;
          *(uint **)(puVar17 + 0x20) = &uStack_6c;
          *(undefined8 *)(puVar17 + -8) = 0x100ab7;
          puVar7 = (uint *)func_0x(puVar1,&uStack_80);
          uVar22 = uStack_84;
          if ((((*psVar6 != 0) && (*(longlong *)(psVar6 + 8) != 0)) &&
              (**(longlong **)(psVar6 + 8) != 0)) &&
             (((uStack_7c & 0x80000) == 0 && ((uStack_6c & 1) == 0)))) {
            if (*psVar6 != 0) {
              uVar12 = *(undefined8 *)(psVar6 + 8);
            }
            if ((puVar7 == (uint *)0x0) || (puVar7 == (uint *)0x77f3d4)) {
LAB_:
              puVar18 = (uint *)0x0;
              puVar7 = puVar18;
LAB_:
              uStack_84 = (uint)puVar18;
            }
            else {
              *(uint *)(puVar17 + 0x38) = uStack_6c;
              *(uint **)(puVar17 + 0x30) = &uStack_84;
              *(undefined4 *)(puVar17 + 0x28) = uVar20;
              *(longlong *)(puVar17 + 0x20) = lVar11;
              *(undefined8 *)(puVar17 + -8) = 0x100b37;
              puVar7 = (uint *)func_0x(uVar12,&uStack_80,puVar7,uVar22);
            }
          }
        }
LAB_:
        uVar15 = (ulonglong)auStack_88[0];
        if (auStack_88[0] == 0) {
          uVar26 = ((~*param_5 & 1) + *param_5 * 3 + 1) * 2;
        }
        else {
          uVar26 = param_5[uVar15] & 0x7fff;
        }
        param_5[uVar15 + 1] = (short)uStack_84 + uVar26 & 0x7fff;
        *(uint *)(lStack_58 + uVar15 * 4) = uVar4;
        if ((uStack_70 & 0xffff) < (uint)uVar26 + (uStack_84 & 0xffff)) {
          *(undefined8 *)(puVar17 + 0x20) = 0;
          *(undefined8 *)(puVar17 + -8) = 0x100bbb;
          (*_DAT_)(1,0xbd7d60,0xb820c8,0x5c5);
        }
        uVar22 = uStack_84;
        param_5[uVar15 + 1] = param_5[uVar15 + 1] | 0x8000;
        *(undefined8 *)(puVar17 + -8) = 0x100bdd;
        func_0x((ulonglong)uVar26 + (longlong)param_5,uVar22,puVar7,uVar22);
        uVar22 = uStack_68 + 1;
        auStack_88[0] = auStack_88[0] + 1;
        lVar11 = lStack_50;
        param_4 = uStack_70;
      }
    }
    uVar10 = 0;
    *(undefined8 *)(puVar17 + -8) = 0x100cac;
    iVar5 = func_0x(psVar6);
    lStack_50 = (longlong)iVar5;
    uVar15 = uVar10;
    uVar22 = auStack_48[0];
    if (0 < lStack_50) {
      do {
        if (*(int *)(psVar6 + 2) == 0) {
          pbVar25 = *(byte **)(psVar6 + 4);
          uVar4 = *(uint *)(psVar6 + 8);
          uVar14 = (ulonglong)uVar4;
          *puVar1 = 0;
          *(uint *)(psVar6 + 10) = uVar4;
          bVar3 = *pbVar25;
          if ((bVar3 & 0x10) != 0) {
            uVar4 = uVar4 + 2 + (*(ushort *)(pbVar25 + uVar14) + 7 >> 3);
            uVar14 = (ulonglong)uVar4;
            *(uint *)(psVar6 + 10) = uVar4;
            bVar3 = *pbVar25;
          }
          if ((bVar3 & 0x20) == 0) {
            *(int *)(psVar6 + 2) = (int)uVar14;
            psVar6[0xe] = 0;
            *(int *)(psVar6 + 0xc) = (int)uVar14;
          }
          else {
            puVar19 = (ushort *)(pbVar25 + uVar14);
            uVar26 = *puVar19;
            psVar6[0xe] = uVar26;
            if (uVar26 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar11 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar11 != 0)) &&
                 ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                  (*(char *)(lVar11 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar17 + -8) = 0x100da0;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar17 + 0x20) = 0;
                  *(undefined8 *)(puVar17 + -8) = 0x100dc6;
                  (*_DAT_)(1,0x9fa998,0xb1a668,0x80f);
                }
              }
              uVar12 = *(undefined8 *)(psVar6 + 4);
              *(undefined8 *)(puVar17 + -8) = 0x100dd4;
              func_0x(uVar12,3);
              uVar14 = (ulonglong)*(uint *)(psVar6 + 10);
              uVar26 = psVar6[0xe];
            }
            uVar4 = (int)uVar14 + (uVar26 + 1) * 2;
            *(uint *)(psVar6 + 0xc) = uVar4;
            if (0x1f9e < uVar4) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar11 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar11 != 0 &&
                  ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                   (*(char *)(lVar11 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar17 + -8) = 0x100e73;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar17 + 0x20) = 0;
                  *(undefined8 *)(puVar17 + -8) = 0x100e99;
                  (*_DAT_)(1,0x9fa998,0xb1a668,0x816);
                }
              }
              uVar12 = *(undefined8 *)(psVar6 + 4);
              *(undefined8 *)(puVar17 + -8) = 0x100ea7;
              func_0x(uVar12,4);
              uVar26 = psVar6[0xe];
              uVar4 = *(uint *)(psVar6 + 0xc);
            }
            uVar14 = (ulonglong)uVar26;
            uVar26 = puVar19[uVar14];
            *(uint *)(psVar6 + 2) = uVar26 & 0x7fff;
            if ((uVar26 & 0x7fff) < uVar4) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar11 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar11 != 0)) &&
                 ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                  (*(char *)(lVar11 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar17 + -8) = 0x100f48;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar17 + 0x20) = 0;
                  *(undefined8 *)(puVar17 + -8) = 0x100f6e;
                  (*_DAT_)(1,0x9fa998,0xb1a668,0x81d);
                }
              }
              uVar12 = *(undefined8 *)(psVar6 + 4);
              *(undefined8 *)(puVar17 + -8) = 0x100f7c;
              func_0x(uVar12,4);
              uVar14 = (ulonglong)(ushort)psVar6[0xe];
            }
            if ((short)puVar19[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
              pbVar25 = *(byte **)(psVar6 + 4);
              do {
                if ((int)uVar14 == 1) {
                  uVar4 = *(uint *)(psVar6 + 0xc);
                  uVar21 = uVar4;
LAB_:
                  if ((*(ushort *)(pbVar25 + uVar14 * 2 + (ulonglong)*(uint *)(psVar6 + 10)) &
                      0x7fff) < uVar4) goto LAB_;
                }
                else {
                  uVar21 = *(uint *)(psVar6 + 0xc);
                  uVar4 = *(ushort *)
                           (pbVar25 + uVar14 * 2 + ((ulonglong)*(uint *)(psVar6 + 10) - 2)) & 0x7fff
                  ;
                  if (uVar21 <= uVar4) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar17 + -8) = 0x100fdd;
                  func_0x(pbVar25,7);
                  uVar21 = *(uint *)(psVar6 + 0xc);
                }
                if ((uVar4 < uVar21) || (*(uint *)(psVar6 + 2) < uVar4)) goto LAB_;
                pbVar25 = *(byte **)(psVar6 + 4);
                if (*(ushort *)(pbVar25 + uVar4) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar6[0xe] = psVar6[0xe] + -1;
                  psVar6[0x15] = (short)uVar4;
                  lVar11 = (ulonglong)(uVar4 & 0xffff) + *(longlong *)(psVar6 + 4);
                  uVar26 = psVar6[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar11 + 2) >> 0xe & 1) != 0) {
                    uVar26 = *(ushort *)(lVar11 + 2) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                  }
                  psVar6[0x16] = uVar26;
                  psVar6[0x16] = (uVar26 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar26;
                  goto LAB_;
                }
                if (*(ushort *)(pbVar25 + uVar4) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar26 = psVar6[0xe] - 1;
                psVar6[0xe] = uVar26;
                if (uVar26 == 0) goto LAB_;
                uVar14 = (ulonglong)uVar26;
              } while ((short)puVar19[(ulonglong)(uVar26 - 1) + 1] < 0);
              uVar14 = (ulonglong)*(uint *)(psVar6 + 2);
            }
            else {
LAB_:
              uVar14 = (ulonglong)*(uint *)(psVar6 + 2);
              pbVar25 = *(byte **)(psVar6 + 4);
            }
          }
          iVar5 = 0;
          if ((*pbVar25 & 0x40) == 0) {
            *(undefined4 *)(psVar6 + 0x13) = 0;
          }
          else {
            *(int *)(psVar6 + 0x13) = (int)uVar14;
            *(int *)(psVar6 + 2) = (int)uVar14 + 0xe;
            *(undefined8 *)(puVar17 + -8) = 0x1010d3;
            puVar8 = (ulonglong *)func_0x(puVar1);
            uVar16 = (ushort)(*puVar8 >> 0x30);
            uVar26 = uVar16;
            if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
              uVar26 = uVar16 & 0xdfff;
              if ((uVar16 >> 0xe & 1) != 0) {
                uVar26 = uVar16 | 0x2000;
              }
            }
            if (uVar26 == 0xfffc) {
              iVar5 = (int)((*puVar8 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar5;
            uVar14 = (ulonglong)*(uint *)(psVar6 + 2);
          }
          iVar5 = (int)uVar14;
          if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
             (*(ulonglong *)(psVar6 + 0xf) < uVar14 + *(longlong *)(psVar6 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar11 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar11 != 0 &&
                 (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar17 + -8) = 0x1011cf;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar17 + 0x20) = 0;
                *(undefined8 *)(puVar17 + -8) = 0x1011f5;
                (*_DAT_)(1,0x9fa998,0xb1a668,0x877);
              }
            }
            uVar12 = *(undefined8 *)(psVar6 + 4);
            *(undefined8 *)(puVar17 + -8) = 0x101203;
            func_0x(uVar12,0x12);
            iVar5 = *(int *)(psVar6 + 2);
          }
          if (0x3f3b < iVar5 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar11 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar11 != 0 &&
                ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                 (*(char *)(lVar11 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar17 + -8) = 0x10128f;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                uVar12 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar17 + -8) = 0x10129d;
                func_0x(uVar12,5);
                goto LAB_;
              }
              *(undefined8 *)(puVar17 + 0x20) = 0;
              *(undefined8 *)(puVar17 + -8) = 0x1012c3;
              (*_DAT_)(1,0x9fa998,0xb1a668,0x87c);
            }
            uVar12 = *(undefined8 *)(psVar6 + 4);
            *(undefined8 *)(puVar17 + -8) = 0x1012d1;
            func_0x(uVar12,5);
          }
        }
LAB_:
        *(undefined8 *)(puVar17 + -8) = 0x1012dd;
        iVar5 = func_0x(puVar1);
        uVar4 = (uint)uVar15;
        if (iVar5 == 0) {
          *(undefined8 *)(puVar17 + -8) = 0x101420;
          iVar5 = func_0x(puVar1);
          lVar11 = 0;
          if (iVar5 == 0) {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x101446;
            (*_DAT_)(1,0xbb6018,0xba7108,0xd67);
            lVar11 = 0;
          }
        }
        else {
          uVar26 = psVar6[0x16];
          if (uVar4 < (uVar26 & 0x7ff)) {
            uVar15 = (ulonglong)(ushort)psVar6[0x15];
            lVar9 = *(longlong *)(psVar6 + 4);
            uVar16 = 0;
            lVar11 = lVar9 + uVar15;
            if ((uVar26 & 0x3800) == 0) {
              uVar24 = *(ushort *)(lVar11 + 2);
LAB_:
              uVar16 = uVar24 >> 0xb & 7;
            }
            else {
              lVar13 = 0;
              if ((uVar26 >> 0xb & 7) != 0) {
                do {
                  if (((lVar13 == 0) || ((*(ushort *)(lVar11 + 2 + lVar13 * 2) & 0x7ff) <= uVar4))
                     && (uVar24 = *(ushort *)(lVar11 + 4 + lVar13 * 2),
                        (int)uVar4 <= (int)((uVar24 & 0x7ff) - 1))) goto LAB_;
                  lVar13 = lVar13 + 1;
                } while (lVar13 < (longlong)(ulonglong)(uVar26 >> 0xb & 7));
              }
            }
            uVar21 = uVar26 >> 0xb & 7;
            uVar14 = (ulonglong)(uVar21 * 2);
            uVar22 = (uVar26 & 0x7ff) * 2;
            iStack_64 = (uint)*(ushort *)(uVar14 + (uVar10 + 2) * 2 + lVar9 + uVar15) +
                        (uint)uVar16 * 0x10000;
            lVar9 = uVar22 + uVar14 + lVar9 + uVar15;
            if (uVar10 == 0) {
              uVar21 = (uVar22 + uVar21) * 2 + 4;
            }
            else {
              uVar21 = *(ushort *)(lVar9 + 2 + uVar10 * 2) & 0x7fff;
            }
            uStack_84 = (*(ushort *)(lVar9 + 4 + uVar10 * 2) & 0x7fff) - uVar21;
            uVar22 = (uint)(*(ushort *)(lVar9 + 4 + uVar10 * 2) >> 0xf);
            lVar11 = (ulonglong)uVar21 + lVar11;
          }
          else {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x101416;
            (*_DAT_)(1,0xbb5fe8,0xbb6030,0x3c6);
            lVar11 = 0;
          }
        }
        iVar5 = iStack_64;
        uVar12 = **(undefined8 **)(*(longlong *)(lStack_60 + 8) + 0x160);
        *(undefined8 *)(puVar17 + -8) = 0x101460;
        puVar7 = (uint *)func_0x(uVar12,iVar5);
        uVar26 = auStack_88[0];
        uStack_80 = *puVar7;
        uStack_7c = puVar7[1];
        puStack_78 = *(uint **)(puVar7 + 2);
        if (uVar22 == 0) {
          uVar15 = (ulonglong)auStack_88[0];
          if (auStack_88[0] == 0) {
            uVar16 = ((~*param_5 & 1) + *param_5 * 3 + 1) * 2;
          }
          else {
            uVar16 = param_5[uVar15] & 0x7fff;
          }
          param_5[uVar15 + 1] = uVar16 & 0x7fff;
          *(uint *)(lStack_58 + uVar15 * 4) = uStack_80;
          if ((uStack_70 & 0xffff) < (uint)uVar16) {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x1015d4;
            (*_DAT_)(1,0xbd7d60,0xb820c8,0x5c5);
          }
        }
        else {
          uVar15 = (ulonglong)auStack_88[0];
          if (auStack_88[0] == 0) {
            uVar26 = ((~*param_5 & 1) + *param_5 * 3 + 1) * 2;
          }
          else {
            uVar26 = param_5[uVar15] & 0x7fff;
          }
          param_5[uVar15 + 1] = (short)uStack_84 + uVar26 & 0x7fff;
          *(uint *)(lStack_58 + uVar15 * 4) = uStack_80;
          if ((uStack_70 & 0xffff) < (uint)uVar26 + (uStack_84 & 0xffff)) {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x101516;
            (*_DAT_)(1,0xbd7d60,0xb820c8,0x5c5);
          }
          uVar21 = uStack_84;
          param_5[uVar15 + 1] = param_5[uVar15 + 1] | 0x8000;
          *(undefined8 *)(puVar17 + -8) = 0x101537;
          func_0x((ulonglong)uVar26 + (longlong)param_5,uVar21,lVar11,uVar21);
          uVar26 = auStack_88[0];
        }
        auStack_88[0] = uVar26 + 1;
        uVar10 = uVar10 + 1;
        uVar15 = (ulonglong)(uVar4 + 1);
      } while ((longlong)uVar10 < lStack_50);
    }
  }
  if (*(longlong **)(lStack_40 + 0x10) != (longlong *)0x0) {
    pcVar2 = *(code **)(**(longlong **)(lStack_40 + 0x10) + 8);
    *(undefined8 *)(puVar17 + -8) = 0x101603;
    (*pcVar2)();
  }
  uVar15 = uStack_38 ^ (ulonglong)auStack_88;
  *(undefined8 *)(puVar17 + -8) = 0x10160f;
  func_0x(uVar15);
  return;
}

