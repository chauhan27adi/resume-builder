
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 *param_2,int param_3,short *param_4,int param_5)

{
  ushort *puVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  code *pcVar4;
  longlong lVar5;
  ushort uVar6;
  int iVar7;
  longlong lVar8;
  undefined4 *puVar9;
  longlong lVar10;
  ulonglong *puVar11;
  byte bVar12;
  short sVar13;
  ushort uVar14;
  uint uVar15;
  uint uVar16;
  ulonglong uVar17;
  longlong lVar18;
  uint *puVar19;
  byte *pbVar20;
  ulonglong uVar21;
  ushort *puVar22;
  longlong unaff_GS_OFFSET;
  undefined auStack_388 [32];
  undefined8 uStack_368;
  undefined2 auStack_358 [4];
  undefined4 auStack_350 [2];
  undefined8 uStack_348;
  undefined8 uStack_340;
  undefined4 uStack_338;
  uint uStack_330;
  undefined4 uStack_32c;
  uint uStack_328;
  uint uStack_324;
  int aiStack_320 [2];
  uint auStack_318 [2];
  longlong lStack_310;
  longlong lStack_308;
  short *psStack_300;
  undefined8 uStack_2f8;
  longlong lStack_2f0;
  undefined4 uStack_2e8;
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined8 uStack_2d8;
  undefined8 uStack_2d0;
  undefined4 uStack_2c8;
  undefined4 auStack_2b8 [2];
  undefined8 uStack_2b0;
  undefined8 uStack_2a8;
  longlong lStack_2a0;
  undefined8 uStack_298;
  undefined8 uStack_290;
  undefined auStack_288 [16];
  undefined auStack_268 [14];
  undefined uStack_25a;
  undefined2 auStack_258 [256];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_388;
  puVar19 = (uint *)0x4;
  uVar3 = *(undefined8 *)(*(longlong *)(param_1 + 0x90) + 0x80);
  uStack_25a = 1;
  uStack_330 = 0x200;
  aiStack_320[0] = param_3;
  psStack_300 = param_4;
  uStack_2f8 = uVar3;
  if ((*(byte *)(param_1 + 0xd8) & 4) == 0) {
    lVar8 = func_0x();
    if (lVar8 != 0) {
      lVar8 = func_0x();
      puVar19 = (uint *)(lVar8 + 0x10);
    }
    *puVar19 = *puVar19 | 2;
    (*_DAT_)(0x59,0x43,0x10,6);
  }
  func_0x(*(undefined8 *)(param_1 + 0xe0),0,*(undefined4 *)(param_1 + 0xf0));
  lVar8 = 0;
  if ((((*(short *)(param_1 + 0x22) == 1) || (param_5 == 0)) || (aiStack_320[0] != 0)) ||
     ((*(short *)(param_1 + 0x22) != 2 && (*(short *)(param_1 + 0xb4) == 0)))) {
    func_0x(param_1 + 200,param_4);
  }
  else {
    lVar8 = 1;
  }
  auStack_358[0] = *(undefined2 *)(param_2 + 1);
  pbVar20 = *(byte **)(*(longlong *)(param_1 + 0xb8) + 8);
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar13 = *(short *)(pbVar20 + 0x10);
  if ((sVar13 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar20 + 0xa37650) + 0x13eccc8) != '\0')) {
    sVar13 = 0x1fa4;
  }
  uStack_368._0_4_ = 0;
  lStack_308 = lVar8;
  (*_DAT_)(auStack_350,auStack_358,sVar13);
  (*_DAT_)(*(undefined8 *)(*(longlong *)(param_1 + 0xc0) + 8),auStack_350,0xffffffff,0);
  uStack_32c = *param_2;
  lVar18 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar13 = *(short *)(lVar18 + 0x50);
  if ((sVar13 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar18 + 0x40) + 0xa37650) + 0x13eccc8) !=
      '\0')) {
    sVar13 = 0x1fa4;
  }
  uStack_368._0_4_ = 0;
  (*_DAT_)(auStack_350,&uStack_32c,sVar13);
  (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0x20,auStack_350,0xffffffff,0)
  ;
  lVar18 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar13 = *(short *)(lVar18 + 0x90);
  if ((sVar13 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar18 + 0x80) + 0xa37650) + 0x13eccc8) !=
      '\0')) {
    sVar13 = 0x1fa4;
  }
  uStack_368._0_4_ = 0;
  (*_DAT_)(auStack_350,aiStack_320,sVar13);
  (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0x40,auStack_350,0xffffffff,0)
  ;
  auStack_358[0] = *(undefined2 *)(param_1 + 0xb4);
  lVar18 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar13 = *(short *)(lVar18 + 0xd0);
  if ((sVar13 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar18 + 0xc0) + 0xa37650) + 0x13eccc8) !=
      '\0')) {
    sVar13 = 0x1fa4;
  }
  uStack_368 = (uint *)((ulonglong)uStack_368._4_4_ << 0x20);
  (*_DAT_)(auStack_350,auStack_358,sVar13);
  (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0x60,auStack_350,0xffffffff,0)
  ;
  sVar13 = *(short *)(param_1 + 0xb4);
  uVar21 = 4;
  if (sVar13 != 0) {
    puVar9 = (undefined4 *)
             func_0x(*(undefined8 *)(*(longlong *)(param_1 + 0x90) + 0x80),param_4);
    uVar2 = *puVar9;
    auStack_358[0] = *(undefined2 *)(puVar9 + 1);
    lVar18 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
    auStack_350[0] = 3;
    uStack_348 = 0;
    uStack_340 = 0;
    uStack_338 = 0;
    sVar13 = *(short *)(lVar18 + 0x110);
    if ((sVar13 == -1) ||
       (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar18 + 0x100) + 0xa37650) + 0x13eccc8)
        != '\0')) {
      sVar13 = 0x1fa4;
    }
    uStack_368 = (uint *)((ulonglong)uStack_368 & 0xffffffff00000000);
    (*_DAT_)(auStack_350,auStack_358,sVar13);
    (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0x80,auStack_350,0xffffffff,
                     0);
    lVar18 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
    auStack_350[0] = 3;
    uStack_348 = 0;
    uStack_340 = 0;
    uStack_338 = 0;
    sVar13 = *(short *)(lVar18 + 0x150);
    if ((sVar13 == -1) ||
       (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar18 + 0x140) + 0xa37650) + 0x13eccc8)
        != '\0')) {
      sVar13 = 0x1fa4;
    }
    uStack_368 = (uint *)((ulonglong)uStack_368 & 0xffffffff00000000);
    uStack_32c = uVar2;
    (*_DAT_)(auStack_350,&uStack_32c,sVar13);
    (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0xa0,auStack_350,0xffffffff,
                     0);
    sVar13 = *(short *)(param_1 + 0xb4);
    uVar21 = 6;
  }
  lStack_310 = 0;
  uStack_2d8 = 0;
  uStack_2e0 = 0;
  lStack_2f0 = *(longlong *)(*(longlong *)(param_1 + 0x90) + 0x80);
  uStack_2e8 = 7;
  if (sVar13 == 0) {
    uStack_2e8 = 3;
  }
  uStack_2d0 = 0;
  uStack_2c8 = 0;
  lVar18 = **(longlong **)(*(longlong *)(lStack_2f0 + 8) + 0x160);
  if (sVar13 == 0) {
    uStack_2e4 = *(undefined4 *)(lVar18 + 0x10);
  }
  else {
    uStack_2e4 = *(undefined4 *)(lVar18 + 0x1c);
  }
  iVar7 = func_0x(&lStack_2f0,&lStack_310);
  lVar18 = lStack_310;
  lVar5 = lStack_2a0;
  while (lStack_310 = lVar18, iVar7 != 0) {
    lStack_2a0 = param_1 + 200;
    auStack_2b8[0] = 0;
    auStack_288 = ZEXT816(0);
    uStack_290 = 0;
    if (lVar8 == 0) {
      if ((*(byte *)(lVar18 + 0x21) & 8) == 0) {
        uStack_2b0 = *(undefined8 *)(param_1 + 0x90);
        uStack_2a8 = *(undefined8 *)(param_1 + 0x100);
        uStack_368 = &uStack_328;
        uStack_298 = 0;
        uStack_324 = 0;
        uStack_328 = 0;
        if ((char)*(byte *)(lVar18 + 0x21) < '\0') {
          lVar10 = func_0x(auStack_2b8,*(undefined4 *)(lVar18 + 0x3c),lVar18,&uStack_324);
        }
        else {
          lVar10 = func_0x(auStack_2b8,0,*(undefined4 *)(lVar18 + 0x24));
        }
        uVar15 = uStack_328;
        if ((uStack_328 & 4) != 0) {
          (*_DAT_)(6,0x54,0x16,3);
        }
        lVar5 = lStack_2a0;
        if ((lVar10 == 0) ||
           (((bVar12 = *(byte *)(lVar18 + 0x34), uStack_324 == 0 &&
             (((10 < (byte)(bVar12 + 0x5b) || ((0x505U >> (bVar12 + 0x5b & 0x1f) & 1) == 0)) &&
              (bVar12 != 0xef)))) && (bVar12 != 0xe7)))) goto LAB_;
        pbVar20 = (byte *)(uVar21 * 0x40 + *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8));
        if ((uVar15 & 2) == 0) {
          auStack_350[0] = 3;
          uStack_348 = 0;
          uStack_340 = 0;
          uStack_338 = 0;
          uVar6 = *(ushort *)(pbVar20 + 0x10);
          if ((uVar6 == 0xffff) ||
             (uVar14 = uVar6,
             *(char *)((ulonglong)*(byte *)((ulonglong)*pbVar20 + 0xa37650) + 0x13eccc8) != '\0')) {
            uVar14 = 0x1fa4;
          }
          uVar15 = uStack_324;
          if (uVar14 < uStack_324) {
            if ((uVar6 == 0xffff) ||
               (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar20 + 0xa37650) + 0x13eccc8) != '\0')
               ) {
              uVar6 = 0x1fa4;
            }
            uVar15 = (uint)uVar6;
          }
          uStack_368 = (uint *)CONCAT44(uStack_368._4_4_,1);
          (*_DAT_)(auStack_350,lVar10,uVar15,pbVar20);
        }
        else {
          auStack_350[0] = 0xe700;
          uStack_338 = 0;
          uStack_348 = 0xda0570;
          uStack_340 = 0x18;
        }
        if (0 < *(int *)(param_1 + 0xb0)) {
          puVar9 = (undefined4 *)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + uVar21 * 0x20);
          if ((*(byte *)((longlong)puVar9 + 2) & 1) != 0) {
            (*_DAT_)(puVar9,pbVar20);
          }
          *puVar9 = 3;
          *(undefined8 *)(puVar9 + 2) = 0;
          *(undefined8 *)(puVar9 + 4) = 0;
          puVar9[6] = 0;
        }
        uStack_368 = (uint *)0x0;
        (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + uVar21 * 0x20,
                         *(undefined8 *)(param_1 + 0x30),pbVar20,auStack_350);
        lVar8 = lStack_308;
        goto LAB_;
      }
    }
    else {
LAB_:
      lStack_2a0 = lVar5;
      *(undefined *)(uVar21 * 0x20 + *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8)) = 3;
LAB_:
      uVar21 = (ulonglong)(ushort)((short)uVar21 + 1);
      lVar5 = lStack_2a0;
    }
    lStack_2a0 = lVar5;
    iVar7 = func_0x(&lStack_2f0);
    uVar3 = uStack_2f8;
    param_4 = psStack_300;
    lVar18 = lStack_310;
    lVar5 = lStack_2a0;
  }
  lStack_2a0 = lVar5;
  if (*(short *)(param_1 + 0xb4) == 0) {
    uStack_368 = (uint *)0x0;
    func_0x(auStack_268,uVar3,param_4,0);
    uStack_368 = (uint *)CONCAT44(uStack_368._4_4_,1);
    func_0x(auStack_268,auStack_258,&uStack_330,0);
    if (0x1ff < uStack_330) {
      uStack_330 = 0x1fe;
    }
    if (0x1ff < ((longlong)(int)uStack_330 & 0xfffffffffffffffeU)) {
      func_0x();
      pcVar4 = (code *)swi(3);
      (*pcVar4)();
      return;
    }
    *(undefined2 *)((longlong)auStack_258 + ((longlong)(int)uStack_330 & 0xfffffffffffffffeU)) = 0;
    lVar18 = uVar21 * 0x20;
    lVar8 = *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8);
    *(undefined4 *)(lVar18 + lVar8) = 0xe703;
    *(undefined8 *)(lVar18 + 8 + lVar8) = 0;
    *(undefined8 *)(lVar18 + 0x10 + lVar8) = 0;
    *(undefined4 *)(lVar18 + 0x18 + lVar8) = 0;
    lVar8 = *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8);
    *(undefined2 **)(lVar18 + 8 + lVar8) = auStack_258;
    *(ulonglong *)(lVar18 + 0x10 + lVar8) = (ulonglong)uStack_330;
    *(undefined *)(lVar18 + *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8)) = 0;
  }
  else {
    *(undefined *)(uVar21 * 0x20 + *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8)) = 3;
  }
  uVar21 = (ulonglong)(ushort)((short)uVar21 + 1);
  puVar1 = (ushort *)(param_4 + 1);
  if (*param_4 == 0) {
    if (*(int *)(param_4 + 2) == 0) {
      pbVar20 = *(byte **)(param_4 + 4);
      uVar15 = *(uint *)(param_4 + 8);
      uVar17 = (ulonglong)uVar15;
      *puVar1 = 0;
      *(uint *)(param_4 + 10) = uVar15;
      bVar12 = *pbVar20;
      if ((bVar12 & 0x10) != 0) {
        uVar15 = uVar15 + 2 + (*(ushort *)(pbVar20 + uVar17) + 7 >> 3);
        uVar17 = (ulonglong)uVar15;
        *(uint *)(param_4 + 10) = uVar15;
        bVar12 = *pbVar20;
      }
      if ((bVar12 & 0x20) == 0) {
        *(int *)(param_4 + 2) = (int)uVar17;
        param_4[0xe] = 0;
        *(int *)(param_4 + 0xc) = (int)uVar17;
      }
      else {
        puVar22 = (ushort *)(pbVar20 + uVar17);
        uVar6 = *puVar22;
        param_4[0xe] = uVar6;
        if (uVar6 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_368 = (uint *)0x0;
              (*_DAT_)(1,0xcb2778,0xdd2448,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_4 + 4),3);
          uVar6 = param_4[0xe];
          uVar17 = (ulonglong)*(uint *)(param_4 + 10);
        }
        uVar15 = (int)uVar17 + (uVar6 + 1) * 2;
        *(uint *)(param_4 + 0xc) = uVar15;
        if (0x1f9e < uVar15) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0 &&
              ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
               (*(char *)(lVar8 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_368 = (uint *)0x0;
              (*_DAT_)(1,0xcb2778,0xdd2448,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_4 + 4),4);
          uVar6 = param_4[0xe];
          uVar15 = *(uint *)(param_4 + 0xc);
        }
        uVar16 = puVar22[uVar6] & 0x7fff;
        *(uint *)(param_4 + 2) = uVar16;
        if (uVar16 < uVar15) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_368 = (uint *)0x0;
              (*_DAT_)(1,0xcb2778,0xdd2448,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_4 + 4),4);
          uVar6 = param_4[0xe];
          uVar16 = *(uint *)(param_4 + 2);
        }
        uVar17 = (ulonglong)uVar16;
        if ((short)puVar22[(ulonglong)(uVar6 - 1) + 1] < 0) {
          pbVar20 = *(byte **)(param_4 + 4);
          do {
            if (uVar6 == 1) {
              uVar15 = *(uint *)(param_4 + 0xc);
              uVar16 = uVar15;
LAB_:
              if ((*(ushort *)(pbVar20 + (ulonglong)uVar6 * 2 + (ulonglong)*(uint *)(param_4 + 10))
                  & 0x7fff) < uVar15) goto LAB_;
            }
            else {
              uVar16 = *(uint *)(param_4 + 0xc);
              uVar15 = *(ushort *)
                        (pbVar20 + (ulonglong)uVar6 * 2 + ((ulonglong)*(uint *)(param_4 + 10) - 2))
                       & 0x7fff;
              if (uVar16 <= uVar15) goto LAB_;
LAB_:
              func_0x(pbVar20,7);
              uVar16 = *(uint *)(param_4 + 0xc);
            }
            if ((uVar15 < uVar16) ||
               (uVar17 = (ulonglong)*(uint *)(param_4 + 2), *(uint *)(param_4 + 2) < uVar15))
            goto LAB_;
            pbVar20 = *(byte **)(param_4 + 4);
            if (*(ushort *)(pbVar20 + uVar15) == 5) {
              *puVar1 = *puVar1 | 2;
              param_4[0xe] = param_4[0xe] + -1;
              param_4[0x15] = (short)uVar15;
              lVar8 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(param_4 + 4);
              uVar6 = param_4[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar8 + 2) >> 0xe & 1) != 0) {
                uVar6 = *(ushort *)(lVar8 + 2) & 0x3800 | param_4[0x16] & 0xc7ffU;
              }
              param_4[0x16] = uVar6;
              param_4[0x16] = (uVar6 ^ *(ushort *)(lVar8 + 2)) & 0x7ff ^ uVar6;
              uVar17 = (ulonglong)*(uint *)(param_4 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar20 + uVar15) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar6 = param_4[0xe] - 1;
            param_4[0xe] = uVar6;
            if (uVar6 == 0) goto LAB_;
          } while ((short)puVar22[(ulonglong)(uVar6 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar20 = *(byte **)(param_4 + 4);
        }
      }
      iVar7 = 0;
      if ((*pbVar20 & 0x40) == 0) {
        *(undefined4 *)(param_4 + 0x13) = 0;
      }
      else {
        *(int *)(param_4 + 0x13) = (int)uVar17;
        *(int *)(param_4 + 2) = (int)uVar17 + 0xe;
        puVar11 = (ulonglong *)func_0x(puVar1);
        uVar14 = (ushort)(*puVar11 >> 0x30);
        uVar6 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar6 = uVar14 & 0xdfff;
          if ((uVar14 >> 0xe & 1) != 0) {
            uVar6 = uVar14 | 0x2000;
          }
        }
        if (uVar6 == 0xfffc) {
          iVar7 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + iVar7;
        uVar17 = (ulonglong)*(uint *)(param_4 + 2);
      }
      iVar7 = (int)uVar17;
      if ((*(ulonglong *)(param_4 + 0xf) != 0) &&
         (*(ulonglong *)(param_4 + 0xf) < uVar17 + *(longlong *)(param_4 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar8 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar8 != 0 &&
             (lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0)) &&
            (*(char *)(lVar8 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_368 = (uint *)0x0;
            (*_DAT_)(1,0xcb2778,0xdd2448,0x877);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 4),0x12);
        iVar7 = *(int *)(param_4 + 2);
      }
      if (0x3f3b < iVar7 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar8 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar8 != 0 &&
            ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_368 = (uint *)0x0;
            (*_DAT_)(1,0xcb2778,0xdd2448,0x87c);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 4),5);
      }
    }
LAB_:
    auStack_318[0] = *(uint *)(param_4 + 2);
    if (8 < auStack_318[0]) goto LAB_;
    bVar12 = **(byte **)(param_4 + 4) & 0xe;
  }
  else {
    auStack_318[0] = *(uint *)(param_4 + 2);
    if (auStack_318[0] == 0) {
      func_0x(puVar1);
      auStack_318[0] = *(uint *)(param_4 + 2);
    }
    if (8 < auStack_318[0]) goto LAB_;
    bVar12 = **(byte **)(param_4 + 4) & 0x1c;
  }
  if ((bVar12 == 0) || (bVar12 == 0xc)) {
    auStack_318[0] = 9;
  }
LAB_:
  pbVar20 = (byte *)(uVar21 * 0x40 + *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8));
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar13 = *(short *)(pbVar20 + 0x10);
  if ((sVar13 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar20 + 0xa37650) + 0x13eccc8) != '\0')) {
    sVar13 = 0x1fa4;
  }
  uStack_368 = (uint *)((ulonglong)uStack_368._4_4_ << 0x20);
  (*_DAT_)(auStack_350,auStack_318,sVar13);
  (*_DAT_)(uVar21 * 0x20 + *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8),auStack_350,
                   0xffffffff,0);
  (*_DAT_)(*(undefined8 *)(param_1 + 0xa8),
                   *(undefined8 *)(*(longlong *)(param_1 + 0xc0) + 8));
  *(int *)(param_1 + 0xb0) = *(int *)(param_1 + 0xb0) + 1;
  func_0x(uStack_58 ^ (ulonglong)auStack_388);
  return;
}

