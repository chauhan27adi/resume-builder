
/* WARNING: Type propagation algorithm not settling */

uint FUN_(longlong param_1)

{
  ushort uVar1;
  longlong lVar2;
  bool bVar3;
  short sVar4;
  int iVar5;
  ulonglong *puVar6;
  byte bVar7;
  ulonglong uVar8;
  uint uVar9;
  uint uVar10;
  byte *pbVar11;
  ushort *puVar12;
  uint uVar13;
  byte *pbVar14;
  ushort uVar15;
  ushort uVar16;
  byte *pbVar17;
  byte *pbVar18;
  ulonglong uVar19;
  uint uVar20;
  uint uVar21;
  longlong unaff_GS_OFFSET;
  longlong lStackX_8;
  ushort uStack_66;
  uint uStack_64;
  byte *pbStack_60;
  undefined8 uStack_58;
  uint uStack_50;
  ushort uStack_4c;
  byte *pbStack_4a;
  undefined2 uStack_42;
  undefined2 uStack_40;
  undefined2 uStack_3e;
  ushort uStack_3c;
  undefined2 uStack_3a;
  undefined4 uStack_38;
  
  if (*(char *)(param_1 + 2) < '\0') {
    iVar5 = func_0x(param_1 + 0x60);
    uVar9 = iVar5 + 0x60;
  }
  else {
    uVar9 = 0x60;
  }
  uVar1 = *(ushort *)(param_1 + 0x1c);
  uVar20 = 0;
  uVar21 = uVar20;
  if (*(short *)(param_1 + 0x16) != 0) {
    lStackX_8 = 0;
    do {
      pbVar11 = (byte *)0x0;
      pbVar14 = (byte *)(ulonglong)*(ushort *)(param_1 + 0xe);
      uVar10 = 0;
      pbVar17 = (byte *)0x0;
      uStack_64 = 0;
      pbStack_4a = (byte *)0x0;
      pbStack_60 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - lStackX_8) * 2) + param_1);
      uStack_3e = 0;
      uStack_3c = 0;
      uStack_3a = 0;
      uStack_58 = 0;
      if ((*pbStack_60 & 1) == 0) {
        bVar3 = false;
        uStack_42 = 0;
        uStack_40 = 0;
        pbVar18 = pbVar11;
        switch(*pbStack_60 & 0xe) {
        default:
          pbVar14 = (byte *)(ulonglong)*(ushort *)(pbStack_60 + 2);
          pbVar18 = pbVar17;
          if (0x1f9d < *(ushort *)(pbStack_60 + 2) - 1) {
            func_0x(pbStack_60,6);
            pbVar18 = (byte *)(ulonglong)uStack_64;
          }
          break;
        case 4:
          pbVar14 = (byte *)0x9;
          pbVar18 = pbVar17;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          pbVar14 = (byte *)0x1;
          pbVar18 = pbVar17;
        }
        uVar13 = (uint)pbVar18;
        pbStack_4a = (byte *)(param_1 + 0x2000);
        if (param_1 == 0) {
          pbStack_4a = pbVar11;
        }
        uStack_58 = CONCAT44(uStack_58._4_4_,(int)pbVar14);
      }
      else {
        bVar3 = true;
        bVar7 = *pbStack_60;
        switch(bVar7 & 0x1c) {
        default:
          if ((char)pbStack_60[1] < '\0') {
            sVar4 = 3;
            uStack_50 = 3;
            uStack_66 = (*(ushort *)(pbStack_60 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_60 + 1) >> 8
            ;
          }
          else {
            uStack_66 = (ushort)pbStack_60[1];
            sVar4 = 2;
            uStack_50 = 2;
          }
          uStack_4c = (short)(uStack_66 + 1 >> 1) + sVar4;
          if (uStack_66 < 0x1f) {
            uStack_38 = 0;
            pbVar17 = pbVar11;
          }
          else {
            iVar5 = uStack_66 - 1;
            uStack_38 = 0;
            uStack_50 = CONCAT22(((short)(iVar5 / 0x1e) + (short)(iVar5 >> 0x1f)) -
                                 (short)((longlong)iVar5 * 0x88888889 >> 0x3f),(undefined2)uStack_50
                                );
          }
          break;
        case 4:
          if (((bVar7 & 0x1c) == 4) && ((bVar7 & 2) != 0)) {
            pbVar17 = (byte *)0xf;
            uStack_50 = 0;
            uStack_64 = 0xf;
            uStack_66 = 0;
            uStack_4c = 0;
            uStack_42 = 0;
            uStack_38 = 1;
          }
          else {
            uStack_50 = 0;
            pbVar17 = (byte *)0x1;
            uStack_66 = 0;
            uStack_4c = 0;
            uStack_42 = 0;
            uStack_64 = 1;
            uStack_38 = 0;
          }
          break;
        case 8:
          pbVar17 = (byte *)0x9;
          uStack_50 = 0;
          uStack_64 = 9;
          uStack_66 = 0;
          uStack_4c = 0;
          uStack_42 = 0;
          uStack_38 = 0;
        }
        uVar13 = (uint)pbVar17;
        uStack_58 = 0;
        pbVar14 = (byte *)(param_1 + 0x2000);
        if (param_1 == 0) {
          pbVar14 = pbVar11;
        }
        uStack_40 = SUB82(pbVar14,0);
        uStack_3e = (undefined2)((ulonglong)pbVar14 >> 0x10);
        uStack_3c = (ushort)((ulonglong)pbVar14 >> 0x20);
        uStack_3a = (undefined2)((ulonglong)pbVar14 >> 0x30);
        pbVar14 = pbVar11;
      }
      if (bVar3) {
        if (uVar13 == 0) {
          func_0x(&uStack_66);
          uVar13 = uStack_64;
        }
        if (uVar13 < 9) {
          bVar7 = *pbStack_60 & 0x1c;
          goto joined_r0x00100931;
        }
      }
      else {
        if (uVar13 == 0) {
          uVar13 = (uint)pbVar14;
          uStack_66 = 0;
          if ((*pbStack_60 & 0x10) != 0) {
            if ((*pbStack_60 & 0x10) != 0) {
              uVar10 = (uint)*(ushort *)(pbStack_60 + (longlong)pbVar14);
            }
            uVar13 = uVar13 + 2 + (uVar10 + 7 >> 3);
            pbVar14 = (byte *)(ulonglong)uVar13;
          }
          uStack_58 = CONCAT44(uVar13,(int)uStack_58);
          if ((*pbStack_60 & 0x20) == 0) {
            uStack_4c = 0;
            pbVar17 = pbVar14;
            uStack_64 = (uint)pbVar14;
            uStack_50 = (uint)pbVar14;
          }
          else {
            puVar12 = (ushort *)(pbStack_60 + (longlong)pbVar14);
            uStack_4c = *puVar12;
            if (uStack_4c == 0) {
              if ((((cRam0000000001a3508b != '\0') || ((bRam0000000001a45990 & 1) != 0)) &&
                  (lVar2 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam0000000000fa3918 * 8) + 8 +
                            (ulonglong)*puRam0000000000fa3920), lVar2 != 0)) &&
                 ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 &&
                  (*(char *)(lVar2 + 0x499) != '\0')))) {
                if ((cRam0000000001a34f7b == '\0') && ((bRam0000000001a45990 & 2) == 0)) {
                  (*pcRam0000000000fa38b8)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*pcRam0000000000fa38b0)(1,0x1325ab8,0x1445788,0x80f,0);
                }
              }
              func_0x(pbStack_60,3);
              pbVar14 = (byte *)(uStack_58 >> 0x20);
            }
            uStack_50 = (int)pbVar14 + (uStack_4c + 1) * 2;
            if (0x1f9e < uStack_50) {
              if (((cRam0000000001a3508b != '\0') || ((bRam0000000001a45990 & 1) != 0)) &&
                 ((lVar2 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam0000000000fa3918 * 8) + 8 +
                            (ulonglong)*puRam0000000000fa3920), lVar2 != 0 &&
                  ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 &&
                   (*(char *)(lVar2 + 0x499) != '\0')))))) {
                if ((cRam0000000001a34f7b == '\0') && ((bRam0000000001a45990 & 2) == 0)) {
                  (*pcRam0000000000fa38b8)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*pcRam0000000000fa38b0)(1,0x1325ab8,0x1445788,0x816,0);
                }
              }
              func_0x(pbStack_60,4);
              pbVar14 = (byte *)(uStack_58 >> 0x20);
            }
            uVar19 = (ulonglong)uStack_4c;
            uStack_64 = puVar12[uVar19] & 0x7fff;
            pbVar17 = (byte *)(ulonglong)uStack_64;
            uVar10 = uStack_50;
            if (uStack_64 < uStack_50) {
              if ((((cRam0000000001a3508b != '\0') || ((bRam0000000001a45990 & 1) != 0)) &&
                  (lVar2 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam0000000000fa3918 * 8) + 8 +
                            (ulonglong)*puRam0000000000fa3920), lVar2 != 0)) &&
                 ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 &&
                  (*(char *)(lVar2 + 0x499) != '\0')))) {
                if ((cRam0000000001a34f7b == '\0') && ((bRam0000000001a45990 & 2) == 0)) {
                  (*pcRam0000000000fa38b8)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*pcRam0000000000fa38b0)(1,0x1325ab8,0x1445788,0x81d,0);
                }
              }
              func_0x(pbStack_60,4);
              uVar19 = (ulonglong)uStack_4c;
              pbVar17 = (byte *)(ulonglong)uStack_64;
              pbVar14 = (byte *)(uStack_58 >> 0x20);
              uVar10 = uStack_50;
            }
            do {
              if (-1 < (short)puVar12[(ulonglong)((int)uVar19 - 1) + 1]) break;
              if ((int)uVar19 == 1) {
                uVar8 = 1;
                uVar13 = uVar10;
code_r0x001005e9:
                if ((*(ushort *)(pbStack_60 + (longlong)(pbVar14 + uVar8 * 2)) & 0x7fff) < uVar13)
                goto code_r0x001005f6;
              }
              else {
                uVar13 = *(ushort *)(pbStack_60 + (longlong)(pbVar14 + uVar19 * 2 + -2)) & 0x7fff;
                uVar8 = uVar19;
                if (uVar10 <= uVar13) goto code_r0x001005e9;
code_r0x001005f6:
                func_0x(pbStack_60,7);
                uVar19 = (ulonglong)uStack_4c;
                pbVar17 = (byte *)(ulonglong)uStack_64;
                pbVar14 = (byte *)(uStack_58 >> 0x20);
                uVar10 = uStack_50;
              }
              if ((uVar13 < uVar10) || ((uint)pbVar17 < uVar13)) goto code_r0x001008f4;
              if (*(ushort *)(pbStack_60 + uVar13) == 5) {
                uStack_66 = uStack_66 | 2;
                uStack_4c = (short)uVar19 - 1;
                uStack_3e = (undefined2)uVar13;
                if ((*(ushort *)(pbStack_60 + (ulonglong)(uVar13 & 0xffff) + 2) & 0x4000) == 0) {
                  uStack_3c = uStack_3c & 0xc7ff;
                }
                else {
                  uStack_3c = uStack_3c ^
                              (*(ushort *)(pbStack_60 + (ulonglong)(uVar13 & 0xffff) + 2) ^
                              uStack_3c) & 0x3800;
                }
                uStack_3c = uStack_3c ^
                            (uStack_3c ^ *(ushort *)(pbStack_60 + (ulonglong)(uVar13 & 0xffff) + 2))
                            & 0x7ff;
                break;
              }
              if (*(ushort *)(pbStack_60 + uVar13) < 0x400) break;
              uStack_66 = uStack_66 | 1;
              uStack_4c = (short)uVar19 - 1;
              uVar19 = (ulonglong)uStack_4c;
            } while (uStack_4c != 0);
          }
          iVar5 = 0;
          if ((*pbStack_60 & 0x40) == 0) {
            uStack_42 = 0;
            uStack_40 = 0;
          }
          else {
            uStack_42 = SUB82(pbVar17,0);
            uStack_40 = (undefined2)((ulonglong)pbVar17 >> 0x10);
            uStack_64 = (int)pbVar17 + 0xe;
            puVar6 = (ulonglong *)func_0x(&uStack_66);
            uVar19 = *puVar6;
            uVar15 = (ushort)(uVar19 >> 0x30);
            uVar16 = uVar15;
            if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
              uVar16 = uVar15 & 0xdfff;
              if ((uVar19 & 0x4000000000000000) != 0) {
                uVar16 = uVar15 | 0x2000;
              }
            }
            if (uVar16 == 0xfffc) {
              iVar5 = (int)((uVar19 >> 0x20 & 0xffff) >> 5);
            }
            uStack_64 = uStack_64 + iVar5;
            pbVar17 = (byte *)(ulonglong)uStack_64;
          }
          if ((pbStack_4a != (byte *)0x0) && (pbStack_4a < pbVar17 + (longlong)pbStack_60)) {
            if (((cRam0000000001a3508b != '\0') || ((bRam0000000001a45990 & 1) != 0)) &&
               (((lVar2 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam0000000000fa3918 * 8) + 8 +
                           (ulonglong)*puRam0000000000fa3920), lVar2 != 0 &&
                 (lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0)) &&
                (*(char *)(lVar2 + 0x499) != '\0')))) {
              if ((cRam0000000001a34f7b == '\0') && ((bRam0000000001a45990 & 2) == 0)) {
                (*pcRam0000000000fa38b8)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*pcRam0000000000fa38b0)(1,0x1325ab8,0x1445788,0x877,0);
              }
            }
            func_0x(pbStack_60,0x12);
            pbVar17 = (byte *)(ulonglong)uStack_64;
          }
          if (0x3f3b < (int)pbVar17 - 1U) {
            if (((cRam0000000001a3508b != '\0') || ((bRam0000000001a45990 & 1) != 0)) &&
               ((lVar2 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam0000000000fa3918 * 8) + 8 +
                          (ulonglong)*puRam0000000000fa3920), lVar2 != 0 &&
                ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 &&
                 (*(char *)(lVar2 + 0x499) != '\0')))))) {
              if ((cRam0000000001a34f7b == '\0') && ((bRam0000000001a45990 & 2) == 0)) {
                (*pcRam0000000000fa38b8)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*pcRam0000000000fa38b0)(1,0x1325ab8,0x1445788,0x87c,0);
              }
            }
            func_0x(pbStack_60,5);
            pbVar17 = (byte *)(ulonglong)uStack_64;
          }
code_r0x001008f4:
          uVar13 = (uint)pbVar17;
        }
        if (uVar13 < 9) {
          bVar7 = *pbStack_60 & 0xe;
joined_r0x00100931:
          if ((bVar7 == 0) || (bVar7 == 0xc)) {
            uVar13 = 9;
          }
        }
      }
      uVar20 = uVar20 + 2 + uVar13;
      if ((0x2000 - (uint)uVar1) - (uVar9 & 0xffff) >> 1 < uVar20) {
        return uVar21;
      }
      lStackX_8 = lStackX_8 + 1;
      uVar21 = uVar21 + 1;
    } while ((int)uVar21 < (int)(uint)*(ushort *)(param_1 + 0x16));
  }
  return uVar21;
}

