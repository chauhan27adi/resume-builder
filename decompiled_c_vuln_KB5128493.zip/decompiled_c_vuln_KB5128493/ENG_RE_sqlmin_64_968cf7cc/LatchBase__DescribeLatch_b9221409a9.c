
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(int param_1,undefined8 *param_2,longlong param_3,uint *param_4,char param_5,
                 ushort *param_6,undefined4 *param_7)

{
  ushort uVar1;
  ushort uVar2;
  int iVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  uint uVar7;
  undefined auStack_2a8 [32];
  undefined8 uStack_288;
  undefined8 uStack_280;
  undefined4 uStack_278;
  ulonglong uStack_268;
  undefined auStack_258 [528];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_2a8;
  uVar7 = *param_4 >> 1;
  func_0x(auStack_258,0,0x208);
  if ((param_1 + 0xfbffffd0U < 6) || (param_1 + 0xfbffffc0U < 6)) {
    uVar1 = *(ushort *)(param_2 + 1);
    if (param_5 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_268 = (ulonglong)uVar7;
    uVar2 = *(ushort *)(undefined4 *)((longlong)param_2 + 4);
    uVar4 = (*_DAT_)();
    uStack_278 = *(undefined4 *)param_2;
    uStack_280 = CONCAT44(uStack_280._4_4_,(uint)uVar2);
    uStack_288 = CONCAT44(uStack_288._4_4_,(uint)uVar1);
    func_0x(param_3,uStack_268,0x24fb398,uVar4);
    if ((param_6 != (ushort *)0x0) && (param_7 != (undefined4 *)0x0)) {
      *param_6 = uVar1;
      *param_7 = *(undefined4 *)param_2;
      *(ushort *)(param_7 + 1) = *(ushort *)(undefined4 *)((longlong)param_2 + 4);
    }
    lVar5 = -1;
    do {
      lVar5 = lVar5 + 1;
    } while (*(short *)(param_3 + lVar5 * 2) != 0);
LAB_:
    uVar7 = (int)lVar5 * 2;
  }
  else {
    if (5 < param_1 + 0xfbffffb0U) {
      if (param_5 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (0xb4 < *(int *)(param_2 + 1) - 1U) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar4 = *(undefined8 *)((longlong)*(int *)(param_2 + 1) * 8 + 0x2504700);
      uVar6 = (*_DAT_)();
      uStack_280 = *param_2;
      uStack_288 = uVar4;
      func_0x(param_3,uVar7,0x25072a8,uVar6);
      lVar5 = -1;
      do {
        lVar5 = lVar5 + 1;
      } while (*(short *)(param_3 + lVar5 * 2) != 0);
      goto LAB_;
    }
    if (uVar7 < 0x40) {
      uStack_288 = 0;
      (*_DAT_)(1,0x290f818,0x28dbb80,0x1322);
    }
    if ((_DAT_ != 0) ||
       (((_DAT_ != 0 && (lVar5 = (*_DAT_)(), *(char *)(lVar5 + 0x29e) != '\0')) ||
        (DAT_ != '\0')))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar3 = (*_DAT_)(0x2ecf4d0,param_3,uVar7);
    if (iVar3 == 0) goto LAB_;
    uVar7 = iVar3 * 2 - 2;
  }
  *param_4 = uVar7;
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_2a8);
  return;
}

