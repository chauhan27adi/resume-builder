
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,byte *param_2,undefined8 param_3,undefined4 param_4)

{
  byte *pbVar1;
  longlong lVar2;
  ushort *puVar3;
  byte bVar4;
  ushort uVar5;
  undefined4 uVar6;
  char cVar7;
  int iVar8;
  longlong lVar9;
  short *psVar10;
  ulonglong uVar11;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar12;
  undefined2 uVar13;
  undefined8 unaff_RBX;
  byte **ppbVar14;
  undefined *puVar15;
  undefined8 unaff_RSI;
  ulonglong uVar16;
  undefined8 unaff_RDI;
  byte *pbVar17;
  short sVar18;
  uint uVar20;
  ulonglong uVar21;
  ushort auStackX_8 [2];
  undefined4 uStackX_c;
  undefined2 auStackX_10 [2];
  undefined4 uStackX_14;
  undefined8 uStackX_18;
  short asStackX_20 [4];
  undefined8 uStack_30;
  int iVar19;
  
  uStack_30 = 0x100014;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  puVar15 = &stack0xffffffffffffffd8 + lVar9;
  puVar3 = (ushort *)((longlong)auStackX_8 + lVar9);
  *(undefined8 *)(&stack0x00002250 + lVar9) = unaff_RBX;
  *(undefined8 *)(&stack0x00002258 + lVar9) = unaff_RSI;
  *(undefined8 *)(&stack0x00002260 + lVar9) = unaff_RDI;
  *(ulonglong *)(&stack0x00002208 + lVar9) = _DAT_ ^ (ulonglong)puVar3;
  uVar5 = *(ushort *)(param_1 + 0x16);
  uVar13 = 0xffff;
  *(undefined4 *)(&stack0x00000028 + lVar9) = param_4;
  uVar16 = 0;
  *(undefined2 *)(&stack0x00000040 + lVar9) = 0xffff;
  *(undefined8 *)(&stack0x00000048 + lVar9) = 0;
  *(undefined4 *)(&stack0x00000044 + lVar9) = 0;
  *(undefined8 *)(&stack0x0000005e + lVar9) = 0;
  *(undefined8 *)(&stack0x00000068 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000050 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar9) = 0;
  *puVar3 = uVar5;
  *(undefined4 *)((longlong)&uStackX_14 + lVar9) = 0;
  *(undefined (*) [16])(&stack0x000001e8 + lVar9) = ZEXT816(0);
  *(undefined2 *)(&stack0x000001f8 + lVar9) = 0xffff;
  *(undefined8 *)(&stack0x00000200 + lVar9) = 0;
  *(undefined4 *)(&stack0x000001fc + lVar9) = 0;
  *(undefined8 *)(&stack0x00000216 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000220 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000208 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000230 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000248 + lVar9) = 0;
  *(undefined4 *)(&stack0x00000250 + lVar9) = 0;
  *(undefined2 *)(&stack0x0000025a + lVar9) = 0;
  *(undefined2 *)(&stack0x000000e8 + lVar9) = 0xffff;
  *(undefined8 *)(&stack0x000000f0 + lVar9) = 0;
  *(undefined4 *)(&stack0x000000ec + lVar9) = 0;
  *(undefined8 *)(&stack0x00000106 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000110 + lVar9) = 0;
  *(undefined8 *)(&stack0x000000f8 + lVar9) = 0;
  *(undefined4 *)(&stack0x0000011c + lVar9) = 0xffffffff;
  *(undefined2 *)(&stack0x00000198 + lVar9) = 0xffff;
  *(undefined8 *)(&stack0x000001a0 + lVar9) = 0;
  *(undefined4 *)(&stack0x0000019c + lVar9) = 0;
  *(undefined8 *)(&stack0x000001b6 + lVar9) = 0;
  *(undefined8 *)(&stack0x000001c0 + lVar9) = 0;
  *(undefined8 *)(&stack0x000001a8 + lVar9) = 0;
  *(undefined8 *)(&stack0x000001d0 + lVar9) = 0;
  *(undefined4 *)(&stack0x000001d8 + lVar9) = 0;
  uVar11 = uVar16;
  if (uVar5 != 0) {
    uVar11 = (ulonglong)uVar5 * 2 + 0xf;
    if (uVar11 <= (ulonglong)uVar5 * 2) {
      uVar11 = 0xffffffffffffff0;
    }
    uVar11 = uVar11 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_30 + lVar9) = 0x100162;
    uVar13 = 0xffff;
    func_0x();
    puVar15 = &stack0xffffffffffffffd8 + -uVar11 + lVar9;
    uVar11 = (longlong)auStackX_8 + -uVar11 + lVar9;
    *(ulonglong *)(&stack0x00000038 + lVar9) = uVar11;
  }
  sVar18 = (short)uVar16;
  iVar19 = (int)uVar16;
  if (((param_2 != (byte *)0x0) || (*(int *)(&stack0x00000254 + lVar9) != iVar19)) ||
     (sVar18 != *(short *)(&stack0x00000258 + lVar9))) {
    bVar4 = *param_2;
    *(byte **)(&stack0x000001e8 + lVar9) = param_2;
    *(int *)(&stack0x00000254 + lVar9) = iVar19;
    *(short *)(&stack0x00000258 + lVar9) = sVar18;
    *(ulonglong *)(&stack0x00000238 + lVar9) = uVar16;
    *(short *)(&stack0x00000240 + lVar9) = sVar18;
    lVar2 = (ulonglong)bVar4 * 6;
    uVar16 = (ulonglong)*(short *)(lVar2 + 0x1526de4);
    *(undefined4 *)((longlong)&uStackX_c + lVar9) = *(undefined4 *)(lVar2 + 0x1526de0);
    if ((bVar4 & 2) != 0) {
      bVar4 = param_2[uVar16];
      param_2 = param_2 + uVar16;
      *(byte **)(&stack0x00000200 + lVar9) = param_2;
      if ((bVar4 & 1) == 0) {
        *(short *)(&stack0x000001f8 + lVar9) = sVar18;
        *(int *)(&stack0x0000021e + lVar9) = iVar19;
                    /* WARNING: Could not emulate address calculation at 0x001003bb */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*param_2 & 0xe) * 4 + 0x101684) - 0x1013050)
        )();
        return;
      }
      *(undefined2 *)(&stack0x000001f8 + lVar9) = 1;
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*param_2 & 0x1c) + 0x101664) * 4
                             + 0x101654) - 0x1013050);
                    /* WARNING: Could not emulate address calculation at 0x00100212 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
    if ((**(byte **)(&stack0x000001e8 + lVar9) & 4) != 0) {
      sVar18 = *(short *)((longlong)&uStackX_c + lVar9 + 2);
      if (sVar18 != 0) {
        uVar16 = (ulonglong)*(ushort *)(param_2 + (longlong)sVar18 * 2 + 1);
      }
      psVar10 = (short *)(param_2 + uVar16);
      *(short **)(&stack0x00000230 + lVar9) = psVar10;
      sVar18 = *psVar10;
      *(short **)(&stack0x00000238 + lVar9) = psVar10 + 1;
      *(short *)(&stack0x00000240 + lVar9) = (sVar18 + 1) * 2;
    }
    lVar2 = *(longlong *)(&stack0x000001f0 + lVar9);
    if (lVar2 != 0) {
      *(undefined8 *)(puVar15 + -8) = 0x100481;
      func_0x(lVar2,&stack0x000001e8 + lVar9);
    }
    uVar13 = 0xffff;
    uVar16 = 0;
  }
  uVar21 = uVar16 & 0xffffffff;
  if (uVar5 != 0) {
    *(ulonglong *)(&stack0x00000030 + lVar9) = uVar16;
    uVar12 = uVar16;
    do {
      uVar20 = (uint)uVar21;
      if ((uVar20 < *(ushort *)(param_1 + 0x16)) &&
         (*(short *)(param_1 + (0xfff - uVar12) * 2) != 0)) {
        cVar7 = *(char *)(param_1 + 2);
        *(uint *)(&stack0x0000011c + lVar9) = uVar20;
        if (-1 < cVar7) goto LAB_;
        pbVar17 = (byte *)(param_1 + 0x60);
        if ((*(short *)(&stack0x000000e8 + lVar9) == 0) ||
           (ppbVar14 = *(byte ***)(&stack0x000000f8 + lVar9), ppbVar14 == (byte **)0x0)) {
          ppbVar14 = (byte **)(&stack0x00000120 + lVar9);
          *(undefined (*) [16])(&stack0x00000130 + lVar9) = ZEXT816(0);
          *(undefined8 *)(&stack0x00000190 + lVar9) = 0;
          *(undefined (*) [16])(&stack0x00000140 + lVar9) = ZEXT816(0);
          *(undefined2 *)(&stack0x00000130 + lVar9) = uVar13;
          *(undefined (*) [16])(&stack0x00000150 + lVar9) = ZEXT816(0);
          *(ulonglong *)(&stack0x00000138 + lVar9) = uVar16;
          *(undefined (*) [16])(&stack0x00000180 + lVar9) = ZEXT816(0);
          *(int *)(&stack0x00000134 + lVar9) = (int)uVar16;
          *(undefined (*) [16])(&stack0x00000160 + lVar9) = ZEXT816(0);
          *(ulonglong *)(&stack0x0000014e + lVar9) = uVar16;
          *(ulonglong *)(&stack0x00000158 + lVar9) = uVar16;
          *(ulonglong *)(&stack0x00000140 + lVar9) = uVar16;
          *(ulonglong *)(&stack0x00000168 + lVar9) = uVar16;
          *(undefined8 *)(&stack0x00000180 + lVar9) = 0;
          *(undefined4 *)(&stack0x00000188 + lVar9) = 0;
          *(short *)(&stack0x00000192 + lVar9) = (short)uVar16;
          *(undefined (*) [16])(&stack0x00000170 + lVar9) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00000120 + lVar9) = ZEXT816(0);
        }
        if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
          sVar18 = *(short *)(param_1 + 0x30);
          *(undefined8 *)((longlong)&uStackX_18 + lVar9) = *(undefined8 *)(param_1 + 0x28);
          *(short *)((longlong)asStackX_20 + lVar9) = sVar18;
        }
        else {
          cVar7 = *(char *)(param_1 + 1);
          if (cVar7 == '\v') {
            if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
              if (cVar7 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar7 != '\b') goto LAB_;
LAB_:
            if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
          }
          *(undefined4 *)((longlong)&uStackX_c + lVar9) = *(undefined4 *)(param_1 + 0x20);
          *(undefined2 *)((longlong)&uStackX_c + lVar9 + 4) = *(undefined2 *)(param_1 + 0x24);
          *(undefined8 *)(puVar15 + -8) = 0x1005d4;
          cVar7 = func_0x((longlong)&uStackX_c + lVar9);
          if (cVar7 == '\0') goto LAB_;
          *(undefined8 *)(puVar15 + -8) = 0x1005e4;
          func_0x(param_1,(longlong)&uStackX_18 + lVar9);
          sVar18 = *(short *)((longlong)asStackX_20 + lVar9);
        }
        iVar19 = *(int *)((longlong)&uStackX_18 + lVar9);
        iVar8 = (int)((ulonglong)*(undefined8 *)((longlong)&uStackX_18 + lVar9) >> 0x20);
        if (((((pbVar17 != *ppbVar14) || (sVar18 != *(short *)(ppbVar14 + 0xd))) ||
             (iVar19 != *(int *)(ppbVar14 + 0xc))) ||
            ((iVar8 != *(int *)((longlong)ppbVar14 + 100) ||
             (*(int *)(param_1 + 0x20) != *(int *)((longlong)ppbVar14 + 0x6c))))) ||
           (*(short *)(param_1 + 0x24) != *(short *)(ppbVar14 + 0xe))) {
          *ppbVar14 = pbVar17;
          uVar16 = 0;
          *(short *)(ppbVar14 + 0xd) = sVar18;
          *(int *)(ppbVar14 + 0xc) = iVar19;
          *(int *)((longlong)ppbVar14 + 100) = iVar8;
          *(undefined4 *)((longlong)ppbVar14 + 0x6c) = *(undefined4 *)(param_1 + 0x20);
          *(undefined2 *)(ppbVar14 + 0xe) = *(undefined2 *)(param_1 + 0x24);
          *(undefined2 *)((longlong)ppbVar14 + 0x72) = 0;
          uVar11 = (ulonglong)*(short *)((ulonglong)*pbVar17 * 6 + 0x1526de4);
          *(undefined4 *)(&stack0x00000078 + lVar9) =
               *(undefined4 *)((ulonglong)*pbVar17 * 6 + 0x1526de0);
          *(undefined2 *)(ppbVar14 + 2) = 0xffff;
          ppbVar14[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar14 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar14 + 0x2e) = 0;
          ppbVar14[7] = (byte *)0x0;
          ppbVar14[4] = (byte *)0x0;
          ppbVar14[9] = (byte *)0x0;
          ppbVar14[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar14 + 0xb) = 0;
          if ((**ppbVar14 & 2) != 0) {
            pbVar1 = pbVar17 + uVar11;
            if ((pbVar17[uVar11] & 1) == 0) {
              *(undefined2 *)(ppbVar14 + 2) = 0;
              ppbVar14[3] = pbVar1;
              *(undefined4 *)((longlong)ppbVar14 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar14 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100880 */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x1016f0) -
                        0x1013050))();
              return;
            }
            *(undefined2 *)(ppbVar14 + 2) = 1;
            ppbVar14[3] = pbVar1;
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x1016d0)
                                    * 4 + 0x1016c0) - 0x1013050);
                    /* WARNING: Could not emulate address calculation at 0x001006ef */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          if ((**ppbVar14 & 4) != 0) {
            if (*(short *)(&stack0x0000007a + lVar9) != 0) {
              uVar11 = (ulonglong)
                       *(ushort *)
                        (param_1 + 0x61 + (longlong)*(short *)(&stack0x0000007a + lVar9) * 2);
            }
            psVar10 = (short *)(pbVar17 + uVar11);
            ppbVar14[9] = (byte *)psVar10;
            sVar18 = *psVar10;
            ppbVar14[10] = (byte *)(psVar10 + 1);
            *(short *)(ppbVar14 + 0xb) = (sVar18 + 1) * 2;
          }
          pbVar17 = ppbVar14[1];
          if (pbVar17 == (byte *)0x0) goto LAB_;
          *(undefined8 *)(puVar15 + -8) = 0x100938;
          func_0x(pbVar17,ppbVar14);
        }
        uVar16 = 0;
LAB_:
        pbVar17 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - uVar12) * 2) + param_1);
        bVar4 = *pbVar17;
        *(byte **)(&stack0x000000f0 + lVar9) = pbVar17;
        if ((bVar4 & 1) == 0) {
          *(short *)(&stack0x000000e8 + lVar9) = (short)uVar16;
          *(int *)(&stack0x0000010e + lVar9) = (int)uVar16;
          *(int *)(&stack0x000000ec + lVar9) = (int)uVar16;
                    /* WARNING: Could not emulate address calculation at 0x00100b64 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar17 & 0xe) * 4 + 0x10175c) -
                    0x1013050))();
          return;
        }
        *(undefined2 *)(&stack0x000000e8 + lVar9) = 1;
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar17 & 0x1c) + 0x10173c) *
                                4 + 0x10172c) - 0x1013050);
                    /* WARNING: Could not emulate address calculation at 0x0010097a */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return;
      }
      *(undefined2 *)(uVar11 + uVar12 * 2) = uVar13;
      uVar12 = uVar12 + 1;
      uVar21 = (ulonglong)(uVar20 + 1);
      *(ulonglong *)(&stack0x00000030 + lVar9) = uVar12;
    } while ((int)(uVar20 + 1) < (int)(uint)uVar5);
  }
  uVar6 = *(undefined4 *)(&stack0x00000028 + lVar9);
  *(undefined **)(&stack0x00000088 + lVar9) = &stack0x00000268 + lVar9;
  *(undefined2 *)(&stack0x000000b0 + lVar9) = uVar13;
  *(undefined **)(&stack0x000000a8 + lVar9) = &stack0x000001e8 + lVar9;
  *(ulonglong *)(&stack0x000000b8 + lVar9) = uVar16;
  *(int *)(&stack0x000000b4 + lVar9) = (int)uVar16;
  *(ulonglong *)(&stack0x000000ce + lVar9) = uVar16;
  *(ulonglong *)(&stack0x000000d8 + lVar9) = uVar16;
  *(ulonglong *)(&stack0x000000c0 + lVar9) = uVar16;
  *(undefined4 *)(&stack0x00000090 + lVar9) = 0x1f9e;
  *(ulonglong *)(&stack0x00000098 + lVar9) = uVar11;
  *(ushort *)(&stack0x000000a0 + lVar9) = uVar5;
  *(undefined8 *)(puVar15 + -8) = 0x10161e;
  func_0x(param_1,&stack0x00000088 + lVar9,uVar6);
  uVar11 = *(ulonglong *)(&stack0x00002208 + lVar9);
  *(undefined8 *)(puVar15 + -8) = 0x10162d;
  func_0x(uVar11 ^ (ulonglong)puVar3);
  return;
}

