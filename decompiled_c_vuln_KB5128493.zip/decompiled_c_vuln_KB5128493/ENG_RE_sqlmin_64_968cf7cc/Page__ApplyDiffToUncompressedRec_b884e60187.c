
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,undefined8 param_3,undefined4 param_4,
                 undefined4 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  byte *pbVar1;
  longlong lVar2;
  byte bVar3;
  undefined2 uVar4;
  ushort uVar5;
  undefined auVar6 [16];
  undefined8 uVar7;
  char cVar8;
  longlong lVar9;
  code *UNRECOVERED_JUMPTABLE_00;
  byte *pbVar10;
  ulonglong uVar11;
  undefined4 auStackX_8 [2];
  undefined8 auStackX_18 [2];
  undefined auStack_20b0 [16];
  undefined auStack_20a0 [8];
  undefined8 uStack_2098;
  undefined8 uStack_2090;
  undefined6 uStack_2088;
  undefined2 uStack_2082;
  undefined6 uStack_2080;
  undefined2 uStack_207a;
  undefined2 uStack_2078;
  undefined6 uStack_2076;
  undefined8 uStack_2070;
  short *psStack_2068;
  short *psStack_2060;
  short sStack_2058;
  undefined6 uStack_2056;
  undefined auStack_2050 [8];
  undefined8 uStack_2048;
  undefined8 uStack_2040;
  undefined2 uStack_2038;
  undefined4 uStack_2034;
  undefined8 uStack_2030;
  undefined8 uStack_2028;
  undefined8 uStack_201a;
  undefined8 uStack_2010;
  undefined *puStack_2000;
  undefined4 uStack_1ff8;
  undefined auStack_1fe8 [8096];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x100022;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9);
  *(undefined8 *)((longlong)auStackX_18 + lVar9) = param_8;
  *(undefined4 *)((longlong)auStackX_8 + lVar9) = param_5;
  *(undefined8 *)((longlong)&param_5 + lVar9) = param_6;
  *(undefined8 *)((longlong)auStackX_18 + lVar9 + 8) = param_7;
  *(undefined4 *)((longlong)auStackX_8 + lVar9 + 4) = param_4;
  puStack_2000 = auStack_1fe8;
  *(longlong *)((longlong)&param_6 + lVar9) = param_1;
  *(undefined2 *)((longlong)&param_7 + lVar9) = 0xffff;
  *(undefined8 *)((longlong)&param_8 + lVar9) = 0;
  *(undefined4 *)((longlong)&param_7 + lVar9 + 4) = 0;
  uStack_2038 = 0xffff;
  uStack_2030 = 0;
  uStack_2034 = 0;
  uStack_201a = 0;
  uStack_2010 = 0;
  uStack_2028 = 0;
  uStack_1ff8 = 0x1f9e;
  if (-1 < *(char *)(param_1 + 2)) goto LAB_;
  pbVar10 = (byte *)(param_1 + 0x60);
  stack0xffffffffffffdf62 = SUB1614(ZEXT816(0),2);
  auStack_20a0._0_2_ = 0xffff;
  uStack_2088 = 0;
  uStack_207a = 0;
  uStack_2098 = 0;
  uStack_2070 = 0;
  uStack_2082 = 0;
  uStack_2080 = 0;
  uStack_2078 = 0;
  uStack_2076 = 0;
  uStack_2090 = 0;
  psStack_2068 = (short *)0x0;
  _auStack_2050 = ZEXT812(0);
  uStack_2048._4_4_ = 0;
  uStack_2040 = 0;
  psStack_2060 = (short *)0x0;
  sStack_2058 = 0;
  uStack_2056 = 0;
  auStack_20b0 = ZEXT816(0);
  auVar6 = auStack_20b0;
  auStack_20b0._8_8_ = 0;
  if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
    uVar4 = *(undefined2 *)(param_1 + 0x30);
    *(undefined8 *)(&stack0xfffffffffffffff8 + lVar9) = *(undefined8 *)(param_1 + 0x28);
  }
  else {
    cVar8 = *(char *)(param_1 + 1);
    if (cVar8 == '\v') {
      if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
        if (cVar8 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar8 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
    }
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar9) = *(undefined4 *)(param_1 + 0x20);
    *(undefined2 *)(&stack0xfffffffffffffffc + lVar9) = *(undefined2 *)(param_1 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10017d;
    auStack_20b0 = auVar6;
    cVar8 = func_0x(&stack0xfffffffffffffff8 + lVar9);
    if (cVar8 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10018e;
    func_0x(param_1,&stack0xfffffffffffffff8 + lVar9);
    uVar4 = *(undefined2 *)((longlong)auStackX_18 + lVar9 + -0x18);
  }
  auVar6 = _auStack_2050;
  bVar3 = *pbVar10;
  auStack_2050._0_4_ = *(undefined4 *)(&stack0xfffffffffffffff8 + lVar9);
  uStack_2048 = auVar6._8_8_;
  auStack_2050 = (undefined  [8])
                 CONCAT44((int)((ulonglong)*(undefined8 *)(&stack0xfffffffffffffff8 + lVar9) >> 0x20
                               ),*(undefined4 *)(&stack0xfffffffffffffff8 + lVar9));
  uVar7 = auStack_2050;
  uStack_2048._4_4_ = *(undefined4 *)(param_1 + 0x20);
  uVar5 = *(ushort *)(param_1 + 0x24);
  lVar2 = (ulonglong)bVar3 * 6;
  uStack_2048._0_2_ = uVar4;
  _auStack_2050 = CONCAT28((undefined2)uStack_2048,uVar7);
  uVar11 = (ulonglong)*(short *)(lVar2 + 0x110f474);
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar9) = *(undefined4 *)(lVar2 + 0x110f470);
  auStack_20b0._0_8_ = pbVar10;
  auStack_20a0._0_2_ = 0xffff;
  auStack_20a0 = (undefined  [8])((ulonglong)auStack_20a0 & 0xffffffff);
  uStack_2098 = 0;
  uStack_2082 = 0;
  uStack_2080 = 0;
  uStack_2078 = 0;
  uStack_2076 = 0;
  uStack_2090 = 0;
  sStack_2058 = 0;
  psStack_2068 = (short *)0x0;
  psStack_2060 = (short *)0x0;
  if ((bVar3 & 2) != 0) {
    pbVar1 = pbVar10 + uVar11;
    uStack_2098 = pbVar1;
    if ((pbVar10[uVar11] & 1) == 0) {
      auVar6._14_2_ = 0;
      auVar6._0_14_ = stack0xffffffffffffdf62;
      _auStack_20a0 = auVar6 << 0x10;
      uStack_207a = 0;
      uStack_2078 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001003be */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x1038f0) - 0x142a9c0))()
      ;
      return;
    }
    auStack_20a0._0_2_ = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x1038d0) * 4 +
                           0x1038c0) - 0x142a9c0);
                    /* WARNING: Could not emulate address calculation at 0x00100257 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar10 & 4) != 0) {
    if (*(short *)(&stack0xfffffffffffffffa + lVar9) != 0) {
      uVar11 = (ulonglong)
               *(ushort *)
                (param_1 + 0x61 + (longlong)*(short *)(&stack0xfffffffffffffffa + lVar9) * 2);
    }
    psStack_2068 = (short *)(pbVar10 + uVar11);
    psStack_2060 = psStack_2068 + 1;
    sStack_2058 = (*psStack_2068 + 1) * 2;
  }
  if (auStack_20b0._8_8_ != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100478;
    func_0x(auStack_20b0._8_8_,auStack_20b0);
  }
LAB_:
  pbVar10 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)param_2) * 2) + param_1);
  bVar3 = *pbVar10;
  *(byte **)((longlong)&param_8 + lVar9) = pbVar10;
  if ((bVar3 & 1) == 0) {
    *(undefined2 *)((longlong)&param_7 + lVar9) = 0;
    *(undefined4 *)((longlong)&param_7 + lVar9 + 4) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100654 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar10 & 0xe) * 4 + 0x10395c) - 0x142a9c0))();
    return;
  }
  *(undefined2 *)((longlong)&param_7 + lVar9) = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar10 & 0x1c) + 0x10393c) * 4 +
                         0x10392c) - 0x142a9c0);
                    /* WARNING: Could not emulate address calculation at 0x001004c6 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

