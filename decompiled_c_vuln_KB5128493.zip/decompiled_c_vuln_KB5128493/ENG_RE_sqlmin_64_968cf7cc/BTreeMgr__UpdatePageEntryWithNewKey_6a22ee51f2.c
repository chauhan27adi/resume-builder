
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong **param_3,undefined8 param_4)

{
  longlong *plVar1;
  byte *pbVar2;
  byte bVar3;
  char cVar4;
  int iVar5;
  byte **ppbVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  longlong lVar9;
  longlong lVar10;
  ushort uVar11;
  short sVar12;
  short sVar13;
  uint uVar14;
  uint uVar15;
  int *piVar16;
  longlong lVar17;
  uint uVar18;
  int *piVar19;
  uint *puVar20;
  ushort *puVar21;
  longlong unaff_GS_OFFSET;
  undefined auStack_1b8 [32];
  uint *puStack_198;
  undefined4 uStack_190;
  int *piStack_188;
  uint uStack_180;
  int iStack_178;
  undefined4 uStack_174;
  int iStack_170;
  undefined2 uStack_16c;
  uint uStack_168;
  undefined4 uStack_164;
  uint uStack_160;
  uint uStack_15c;
  undefined4 uStack_158;
  ushort *puStack_150;
  longlong **pplStack_148;
  longlong lStack_140;
  undefined8 uStack_138;
  undefined auStack_130 [8];
  undefined auStack_128 [8];
  undefined8 uStack_120;
  short sStack_118;
  ushort uStack_116;
  uint uStack_114;
  int *piStack_110;
  undefined8 uStack_108;
  uint uStack_100;
  ushort uStack_fc;
  byte *pbStack_fa;
  undefined2 uStack_f2;
  undefined2 uStack_f0;
  undefined2 uStack_ee;
  ushort uStack_ec;
  undefined2 uStack_ea;
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [16];
  undefined auStack_d0 [16];
  undefined auStack_c0 [16];
  undefined auStack_b0 [16];
  undefined auStack_a0 [16];
  undefined auStack_90 [16];
  undefined auStack_80 [16];
  undefined8 uStack_70;
  undefined auStack_68 [16];
  uint auStack_58 [2];
  ulonglong uStack_50;
  
  uStack_50 = _DAT_ ^ (ulonglong)auStack_1b8;
  pplStack_148 = param_3;
  lStack_140 = param_1;
  uStack_138 = param_2;
  uStack_120 = param_4;
  iVar5 = func_0x();
  ppbVar6 = (byte **)0x0;
  uVar18 = 0;
  if (iVar5 == 0) {
    puStack_198 = (uint *)0x0;
    (*_DAT_)(1,0x1aff718,0x1ad5e58,900);
  }
  uVar14 = 0;
  if (*(int *)(param_3 + 5) == 0) {
    iVar5 = *(int *)(param_3 + 3);
    lVar9 = **param_3;
    lVar10 = *(longlong *)(**(longlong **)(param_1 + 8) + 8);
    puVar20 = (uint *)(lVar10 + 0x210);
    puStack_150 = (ushort *)(lVar9 + (0xfff - (longlong)iVar5) * 2);
    if ((*(byte *)((ulonglong)*puStack_150 + lVar9) & 1) == 0) {
      piVar16 = (int *)((byte *)((ulonglong)*puStack_150 + lVar9) + (int)*puVar20);
    }
    else {
      sStack_118 = 0xffff;
      piStack_110 = (int *)0x0;
      uStack_114 = 0;
      pbStack_fa = (byte *)0x0;
      uStack_f0 = 0;
      uStack_ee = 0;
      uStack_ec = 0;
      uStack_ea = 0;
      uStack_108 = (byte **)0x0;
      iStack_e4 = iVar5;
      if (*(char *)(lVar9 + 2) < '\0') {
        auStack_e0 = ZEXT816(0);
        uStack_70 = 0;
        auStack_d0 = ZEXT816(0);
        auStack_c0 = ZEXT816(0);
        auStack_b0 = ZEXT816(0);
        auStack_a0 = ZEXT816(0);
        auStack_90 = ZEXT816(0);
        auStack_80 = ZEXT816(0);
        ppbVar6 = (byte **)func_0x(auStack_e0,(longlong)iVar5,2);
        uVar7 = func_0x(lVar9,auStack_68,0,0);
        if ((byte *)(lVar9 + 0x60) == *ppbVar6) {
          func_0x(uVar7,ppbVar6 + 0xc);
        }
        *ppbVar6 = (byte *)(lVar9 + 0x60);
        func_0x(ppbVar6 + 0xc,uVar7);
        func_0x((longlong)ppbVar6 + 0x6c,lVar9 + 0x20);
        uStack_158 = *(undefined4 *)((ulonglong)*(byte *)(lVar9 + 0x60) * 6 + 0x174e650);
        sVar13 = *(short *)((ulonglong)*(byte *)(lVar9 + 0x60) * 6 + 0x174e654);
        *(undefined2 *)(ppbVar6 + 2) = 0xffff;
        ppbVar6[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar6 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar6 + 0x2e) = 0;
        ppbVar6[7] = (byte *)0x0;
        ppbVar6[4] = (byte *)0x0;
        ppbVar6[9] = (byte *)0x0;
        ppbVar6[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar6 + 0xb) = 0;
        uStack_174 = CONCAT22(uStack_174._2_2_,sVar13);
        if ((**ppbVar6 & 2) != 0) {
          pbVar2 = (byte *)(lVar9 + 0x60 + (longlong)sVar13);
          if ((*(byte *)(lVar9 + 0x60 + (longlong)sVar13) & 1) == 0) {
            *(undefined2 *)(ppbVar6 + 2) = 0;
            ppbVar6[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar6 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar6 + 0x36) = 0;
            switch(*pbVar2 & 0xe) {
            default:
              uVar14 = (uint)*(ushort *)(pbVar2 + 2);
              if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
                func_0x(pbVar2,6);
                sVar13 = (short)uStack_174;
              }
              break;
            case 4:
              uVar14 = 9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar14 = 1;
            }
            *(uint *)(ppbVar6 + 4) = uVar14;
            *(undefined8 *)((longlong)ppbVar6 + 0x2e) = 0;
          }
          else {
            *(undefined2 *)(ppbVar6 + 2) = 1;
            ppbVar6[3] = pbVar2;
            bVar3 = *pbVar2;
            switch(bVar3 & 0x1c) {
            default:
              if ((char)pbVar2[1] < '\0') {
                uVar11 = *(ushort *)(pbVar2 + 1);
                sVar12 = 3;
                *(ushort *)((longlong)ppbVar6 + 0x12) = uVar11;
                uVar11 = (uVar11 & 0x7f) << 8 | uVar11 >> 8;
              }
              else {
                sVar12 = 2;
                uVar11 = (ushort)pbVar2[1];
              }
              *(ushort *)((longlong)ppbVar6 + 0x12) = uVar11;
              *(short *)(ppbVar6 + 5) = sVar12;
              uVar11 = *(ushort *)((longlong)ppbVar6 + 0x12);
              *(short *)((longlong)ppbVar6 + 0x2c) = (short)(uVar11 + 1 >> 1) + sVar12;
              if (uVar11 < 0x1f) {
                *(undefined2 *)((longlong)ppbVar6 + 0x2a) = 0;
                *(undefined4 *)((longlong)ppbVar6 + 0x14) = 0;
                *(undefined4 *)(ppbVar6 + 8) = 0;
                ppbVar6[7] = (byte *)0x0;
                ppbVar6[4] = (byte *)0x0;
              }
              else {
                iVar5 = uVar11 - 1;
                *(short *)((longlong)ppbVar6 + 0x2a) =
                     ((short)(iVar5 / 0x1e) + (short)(iVar5 >> 0x1f)) -
                     (short)((longlong)iVar5 * 0x88888889 >> 0x3f);
                *(undefined4 *)((longlong)ppbVar6 + 0x14) = 0;
                *(undefined4 *)(ppbVar6 + 8) = 0;
                ppbVar6[7] = (byte *)0x0;
                ppbVar6[4] = (byte *)0x0;
              }
              goto LAB_;
            case 4:
              if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
                func_0x((longlong)ppbVar6 + 0x12);
                *(undefined4 *)(ppbVar6 + 8) = 0;
                ppbVar6[3] = pbVar2;
                *(undefined4 *)((longlong)ppbVar6 + 0x14) = 0xf;
                *(undefined4 *)(ppbVar6 + 8) = 1;
              }
              else {
                func_0x((longlong)ppbVar6 + 0x12);
                ppbVar6[3] = pbVar2;
                *(undefined4 *)((longlong)ppbVar6 + 0x14) = 1;
                *(undefined4 *)(ppbVar6 + 8) = 0;
              }
              break;
            case 8:
              func_0x((longlong)ppbVar6 + 0x12);
              ppbVar6[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar6 + 0x14) = 9;
              *(undefined4 *)(ppbVar6 + 8) = 0;
            }
            ppbVar6[7] = (byte *)0x0;
            ppbVar6[4] = (byte *)0x0;
            sVar13 = (short)uStack_174;
          }
        }
LAB_:
        if ((**ppbVar6 & 4) != 0) {
          if (uStack_158._2_2_ == 0) {
            uVar8 = (ulonglong)sVar13;
          }
          else {
            uVar8 = (ulonglong)*(ushort *)(lVar9 + 0x61 + (longlong)uStack_158._2_2_ * 2);
          }
          func_0x(ppbVar6 + 9,lVar9 + 0x60 + uVar8);
        }
        if (ppbVar6[1] != (byte *)0x0) {
          func_0x(ppbVar6[1],ppbVar6);
        }
      }
      uVar8 = (ulonglong)*(ushort *)(lVar9 + 0xe);
      piVar16 = (int *)((ulonglong)*puStack_150 + lVar9);
      piStack_110 = piVar16;
      if ((*(byte *)piVar16 & 1) == 0) {
        sStack_118 = 0;
        uStack_114 = 0;
        uStack_f2 = 0;
        uStack_f0 = 0;
        switch(*(byte *)piVar16 & 0xe) {
        default:
          uVar8 = (ulonglong)*(ushort *)((longlong)piVar16 + 2);
          if (0x1f9d < *(ushort *)((longlong)piVar16 + 2) - 1) {
            func_0x(piVar16,6);
          }
          break;
        case 4:
          uVar8 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar8 = 1;
        }
        pbStack_fa = (byte *)(lVar9 + 0x2000);
        uStack_108 = (byte **)CONCAT44(uStack_108._4_4_,(int)uVar8);
      }
      else {
        sStack_118 = 1;
        bVar3 = *(byte *)piVar16;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)*(byte *)((longlong)piVar16 + 1) < '\0') {
            sVar13 = 3;
            uStack_100 = 3;
            uStack_116 = (*(ushort *)((longlong)piVar16 + 1) & 0x7f) << 8 |
                         *(ushort *)((longlong)piVar16 + 1) >> 8;
          }
          else {
            uStack_116 = (ushort)*(byte *)((longlong)piVar16 + 1);
            uStack_100 = 2;
            sVar13 = 2;
          }
          uStack_fc = ((ushort)(uStack_116 + 1) >> 1) + sVar13;
          if (uStack_116 < 0x1f) {
            uStack_114 = 0;
            uStack_e8 = 0;
          }
          else {
            iVar5 = uStack_116 - 1;
            uStack_114 = 0;
            uStack_e8 = 0;
            uStack_100 = CONCAT22(((short)(iVar5 / 0x1e) + (short)(iVar5 >> 0x1f)) -
                                  (short)((longlong)iVar5 * 0x88888889 >> 0x3f),
                                  (undefined2)uStack_100);
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
            func_0x(&uStack_116);
            uStack_114 = 0xf;
            uStack_e8 = 1;
          }
          else {
            func_0x(&uStack_116);
            uStack_114 = 1;
            uStack_e8 = 0;
          }
          break;
        case 8:
          func_0x(&uStack_116);
          uStack_114 = 9;
          uStack_e8 = 0;
        }
        lVar9 = lVar9 + 0x2000;
        uStack_f0 = (undefined2)lVar9;
        uStack_ee = (undefined2)((ulonglong)lVar9 >> 0x10);
        uStack_ec = (ushort)((ulonglong)lVar9 >> 0x20);
        uStack_ea = (undefined2)((ulonglong)lVar9 >> 0x30);
        uVar8 = (ulonglong)ppbVar6 & 0xffffffff;
        piStack_110 = piVar16;
        uStack_108 = ppbVar6;
      }
      if (sStack_118 == 0) {
        if ((*puVar20 & 0xc0000000) == 0x80000000) {
          iVar5 = func_0x(&uStack_116);
          if (iVar5 == 0) {
code_r0x00100d07:
            iStack_178 = 0;
            piVar16 = (int *)0x0;
            param_3 = pplStack_148;
            param_2 = uStack_138;
            param_1 = lStack_140;
          }
          else {
            piVar16 = (int *)func_0x(&uStack_ee,puVar20,&iStack_178,&uStack_158);
            param_3 = pplStack_148;
            param_2 = uStack_138;
            param_1 = lStack_140;
          }
        }
        else {
          if ((*(byte *)(lVar10 + 0x216) & 0x10) == 0) {
            uStack_164 = 0;
            uStack_174 = 1;
          }
          else {
            puStack_198 = &uStack_174;
            func_0x(&uStack_116,puVar20,0,&uStack_164);
            if ((uStack_174 == 0) && ((*(byte *)(lVar10 + 0x216) & 0x10) != 0)) {
              piVar16 = *(int **)(lVar10 + 0x218) + 1;
              param_3 = pplStack_148;
              param_2 = uStack_138;
              param_1 = lStack_140;
              iStack_178 = **(int **)(lVar10 + 0x218);
              goto code_r0x00100dba;
            }
            uVar8 = (ulonglong)uStack_108 & 0xffffffff;
          }
          if ((int)*puVar20 < 0) {
            piVar16 = piStack_110;
            if (uStack_114 == 0) {
              uStack_116 = 0;
              uVar14 = (uint)uVar8;
              if ((*(byte *)piStack_110 & 0x10) != 0) {
                uVar14 = uVar14 + 2 + (*(ushort *)(uVar8 + (longlong)piStack_110) + 7 >> 3);
                uVar8 = (ulonglong)uVar14;
              }
              uStack_108 = (byte **)CONCAT44(uVar14,(undefined4)uStack_108);
              if ((*(byte *)piStack_110 & 0x20) == 0) {
                uStack_fc = 0;
                uStack_114 = (uint)uVar8;
                uStack_100 = (uint)uVar8;
              }
              else {
                puVar21 = (ushort *)(uVar8 + (longlong)piStack_110);
                uStack_fc = *puVar21;
                if (uStack_fc == 0) {
                  cVar4 = func_0x(0x2060de0);
                  if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                     (*(char *)(lVar9 + 0x499) != '\0')) {
                    cVar4 = func_0x(0x2060de0);
                    if (cVar4 == '\0') {
                      (*pcRam00000000015cf968)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      puStack_198 = (uint *)0x0;
                      (*_DAT_)(1,0x1951b68,0x1a71838,0x80f);
                    }
                  }
                  func_0x(piStack_110,3);
                }
                uStack_100 = uStack_108._4_4_ + (uStack_fc + 1) * 2;
                if (0x1f9e < uStack_100) {
                  cVar4 = func_0x(0x2060de0);
                  if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                     (*(char *)(lVar9 + 0x499) != '\0')) {
                    cVar4 = func_0x(0x2060de0);
                    if (cVar4 == '\0') {
                      (*pcRam00000000015cf968)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      puStack_198 = (uint *)0x0;
                      (*_DAT_)(1,0x1951b68,0x1a71838,0x816);
                    }
                  }
                  func_0x(piStack_110,4);
                }
                uStack_114 = puVar21[uStack_fc] & 0x7fff;
                if (uStack_114 < uStack_100) {
                  cVar4 = func_0x(0x2060de0);
                  if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                     (*(char *)(lVar9 + 0x499) != '\0')) {
                    cVar4 = func_0x(0x2060de0);
                    if (cVar4 == '\0') {
                      (*pcRam00000000015cf968)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      puStack_198 = (uint *)0x0;
                      (*_DAT_)(1,0x1951b68,0x1a71838,0x81d);
                    }
                  }
                  func_0x(piStack_110,4);
                }
                uVar8 = (ulonglong)uStack_114;
                piVar16 = piStack_110;
                do {
                  if (-1 < (short)puVar21[(ulonglong)(uStack_fc - 1) + 1]) break;
                  uVar14 = uStack_100;
                  if (((uStack_fc != 1) &&
                      (uVar14 = *(ushort *)
                                 ((longlong)piVar16 +
                                 (ulonglong)uStack_fc * 2 + (((ulonglong)uStack_108 >> 0x20) - 2)) &
                                0x7fff, uVar14 < uStack_100)) ||
                     ((*(ushort *)
                        ((longlong)piVar16 +
                        (ulonglong)uStack_fc * 2 + ((ulonglong)uStack_108 >> 0x20)) & 0x7fff) <
                      uVar14)) {
                    func_0x(piVar16,7);
                    uVar8 = (ulonglong)uStack_114;
                    piVar16 = piStack_110;
                  }
                  if ((uVar14 < uStack_100) || ((uint)uVar8 < uVar14)) goto code_r0x00100c25;
                  if (*(ushort *)((ulonglong)uVar14 + (longlong)piVar16) == 5) {
                    uStack_116 = uStack_116 | 2;
                    uStack_fc = uStack_fc - 1;
                    uStack_ee = (undefined2)uVar14;
                    uVar11 = *(ushort *)((ulonglong)(uVar14 & 0xffff) + 2 + (longlong)piVar16);
                    if ((uVar11 >> 0xe & 1) == 0) {
                      uStack_ec = uStack_ec & 0xc7ff;
                    }
                    else {
                      uStack_ec = uStack_ec ^ (uStack_ec ^ uVar11) & 0x3800;
                    }
                    uStack_ec = (uStack_ec ^
                                *(ushort *)((ulonglong)(uVar14 & 0xffff) + 2 + (longlong)piVar16)) &
                                0x7ff ^ uStack_ec;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar14 + (longlong)piVar16) < 0x400) break;
                  uStack_116 = uStack_116 | 1;
                  uStack_fc = uStack_fc - 1;
                } while (uStack_fc != 0);
              }
              if ((*(byte *)piVar16 & 0x40) == 0) {
                uStack_f2 = 0;
                uStack_f0 = 0;
              }
              else {
                uStack_f2 = (undefined2)uVar8;
                uStack_f0 = (undefined2)(uVar8 >> 0x10);
                uStack_114 = (int)uVar8 + 0xe;
                uVar7 = func_0x(&uStack_116);
                func_0x(uVar7,auStack_128);
                iVar5 = func_0x(auStack_128);
                uStack_114 = uStack_114 + iVar5;
                uVar8 = (ulonglong)uStack_114;
                piVar16 = piStack_110;
              }
              uVar14 = (uint)uVar8;
              if ((pbStack_fa != (byte *)0x0) && (pbStack_fa < (byte *)(uVar8 + (longlong)piVar16)))
              {
                cVar4 = func_0x(0x2060de0);
                if ((cVar4 != '\0') &&
                   ((lVar9 = func_0x(), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  cVar4 = func_0x(0x2060de0);
                  if (cVar4 == '\0') {
                    (*pcRam00000000015cf968)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    puStack_198 = (uint *)0x0;
                    (*_DAT_)(1,0x1951b68,0x1a71838,0x877);
                  }
                }
                func_0x(piStack_110,0x12);
                piVar16 = piStack_110;
                uVar14 = uStack_114;
              }
              if (0x3f3b < uVar14 - 1) {
                cVar4 = func_0x(0x2060de0);
                if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                   (*(char *)(lVar9 + 0x499) != '\0')) {
                  cVar4 = func_0x(0x2060de0);
                  if (cVar4 == '\0') {
                    (*pcRam00000000015cf968)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    puStack_198 = (uint *)0x0;
                    (*_DAT_)(1,0x1951b68,0x1a71838,0x87c);
                  }
                }
                func_0x(piStack_110,5);
                piVar16 = piStack_110;
              }
            }
code_r0x00100c25:
            sVar13 = -*(short *)puVar20;
            if ((*(byte *)(lVar10 + 0x216) & 0x10) != 0) {
              puStack_198 = &uStack_15c;
              func_0x(&uStack_116,puVar20,0,&puStack_150);
              piVar16 = piStack_110;
              if (uStack_15c == 0) {
                piVar16 = *(int **)(lVar10 + 0x218) + 1;
                param_3 = pplStack_148;
                param_2 = uStack_138;
                param_1 = lStack_140;
                iStack_178 = **(int **)(lVar10 + 0x218);
                goto code_r0x00100dba;
              }
            }
            if ((uint)uStack_fc < (uint)(int)sVar13) {
              iStack_178 = 0;
              param_3 = pplStack_148;
              param_2 = uStack_138;
              param_1 = lStack_140;
            }
            else {
              piVar19 = piVar16;
              uVar14 = uStack_100;
              if (sVar13 != 1) {
                piVar19 = piStack_110;
                uVar14 = *(ushort *)
                          ((longlong)piVar16 +
                          (longlong)sVar13 * 2 + (((ulonglong)uStack_108 >> 0x20) - 2)) & 0x7fff;
              }
              uVar15 = *(ushort *)
                        ((longlong)piVar16 + (longlong)sVar13 * 2 + ((ulonglong)uStack_108 >> 0x20))
                       & 0x7fff;
              if ((uVar14 < uStack_100) || (uVar15 < uVar14)) {
                func_0x(piVar19,7);
                piVar19 = piStack_110;
              }
              piVar16 = (int *)((ulonglong)uVar14 + (longlong)piVar19);
              param_3 = pplStack_148;
              param_2 = uStack_138;
              param_1 = lStack_140;
              iStack_178 = uVar15 - uVar14;
            }
          }
          else if ((*(ushort *)(lVar10 + 0x216) & 8) == 0) {
            if ((*(ushort *)(lVar10 + 0x216) & 0x10) != 0) {
              puStack_198 = &uStack_160;
              func_0x(&uStack_116,puVar20,0,auStack_130);
              if (uStack_160 == 0) {
                iStack_178 = **(int **)(lVar10 + 0x218);
                piVar16 = *(int **)(lVar10 + 0x218) + 1;
                param_3 = pplStack_148;
                param_2 = uStack_138;
                param_1 = lStack_140;
                if (iStack_178 != 6) {
                  puStack_198 = (uint *)0x0;
                  (*_DAT_)(1,0x1aff8d8,0x1afe2d8,0x381);
                  param_3 = pplStack_148;
                  param_2 = uStack_138;
                  param_1 = lStack_140;
                }
                goto code_r0x00100dba;
              }
            }
            piVar16 = (int *)((longlong)(int)*puVar20 + (longlong)piStack_110);
            param_3 = pplStack_148;
            param_2 = uStack_138;
            param_1 = lStack_140;
            iStack_178 = 6;
          }
          else {
            piVar16 = (int *)func_0x(&uStack_116,puVar20,&iStack_178);
            param_3 = pplStack_148;
            param_2 = uStack_138;
            param_1 = lStack_140;
          }
        }
      }
      else {
        puStack_198 = &uStack_168;
        uStack_168 = 0;
        piVar16 = (int *)func_0x(&uStack_116,puVar20,0,&iStack_178);
        param_3 = pplStack_148;
        param_2 = uStack_138;
        param_1 = lStack_140;
        if ((((sStack_118 != 0) && (uStack_108 != (byte **)0x0)) && (*uStack_108 != (byte *)0x0)) &&
           (((*(byte *)(lVar10 + 0x216) & 8) == 0 && ((uStack_168 & 1) == 0)))) {
          if ((piVar16 == (int *)0x0) || (piVar16 == (int *)0x16d65a4)) goto code_r0x00100d07;
          uStack_180 = uStack_168;
          piStack_188 = &iStack_178;
          puStack_198 = auStack_58;
          uStack_190 = 6;
          piVar16 = (int *)func_0x(uStack_108,puVar20,piVar16,iStack_178);
          param_3 = pplStack_148;
          param_2 = uStack_138;
          param_1 = lStack_140;
        }
      }
    }
code_r0x00100dba:
    iStack_170 = *piVar16;
    uStack_16c = *(undefined2 *)(piVar16 + 1);
  }
  else {
    iStack_170 = *(int *)((longlong)param_3 + 0x34);
    uStack_16c = *(undefined2 *)(param_3 + 7);
  }
  func_0x(param_1,param_2,2);
  puStack_198 = (uint *)&iStack_170;
  uStack_190 = 2;
  iVar5 = func_0x(param_1,param_2,param_3,uStack_120);
  if (((iVar5 != 0) &&
      (lVar9 = *(longlong *)(*(longlong *)(**(longlong **)(param_1 + 8) + 8) + 0x488), lVar9 != 0))
     && ((*_DAT_ != '\0' && ((DAT_ & 2) == 0)))) {
    if (*(longlong *)(lVar9 + 0x20) != 0) {
      lVar17 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar10 = *(longlong *)(lVar17 + 0x100);
      if (lVar10 == 0) {
        (*_DAT_)(0);
        lVar10 = *(longlong *)(lVar17 + 0x100);
      }
      if (*(longlong *)(lVar10 + 0x260) != 0) {
        uVar18 = *(uint *)(*(longlong *)(lVar10 + 0x260) + 0xe68);
      }
      if (uVar18 < *(uint *)(_DAT_ + 8)) {
        lVar9 = *(longlong *)(*(longlong *)(lVar9 + 0x20) + (ulonglong)uVar18 * 8);
        *(longlong *)(lVar9 + 0x30) = *(longlong *)(lVar9 + 0x30) + 1;
        goto LAB_;
      }
    }
    LOCK();
    plVar1 = (longlong *)(*(longlong *)(lVar9 + 0x18) + 0x30);
    *plVar1 = *plVar1 + 1;
    UNLOCK();
  }
LAB_:
  func_0x(uStack_50 ^ (ulonglong)auStack_1b8);
  return;
}

