// NOTE: 4 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(void)

{
  int in_stack_00000030;
  int in_stack_00000038;
  
  if ((in_stack_00000030 == 0) && (in_stack_00000038 == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

