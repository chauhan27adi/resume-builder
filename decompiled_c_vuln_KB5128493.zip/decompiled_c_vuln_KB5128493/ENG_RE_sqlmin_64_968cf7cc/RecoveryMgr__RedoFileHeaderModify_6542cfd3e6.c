
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong *param_3,undefined8 *param_4)

{
  byte bVar1;
  undefined2 uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  char cVar7;
  short sVar8;
  int iVar9;
  undefined4 uVar10;
  int iVar11;
  ulonglong *puVar12;
  uint *puVar13;
  undefined4 *puVar14;
  undefined8 *puVar15;
  longlong lVar16;
  ushort uVar17;
  ushort uVar18;
  short sVar19;
  uint uVar20;
  ulonglong uVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  ulonglong uVar25;
  longlong lVar26;
  longlong lVar27;
  uint uVar28;
  ulonglong uVar29;
  ushort *puVar30;
  longlong unaff_GS_OFFSET;
  bool bVar31;
  undefined auStack_1b8 [32];
  undefined8 uStack_198;
  undefined8 uStack_190;
  longlong *plStack_188;
  undefined8 uStack_180;
  uint uStack_178;
  short sStack_170;
  ushort uStack_16e;
  uint uStack_16c;
  byte *pbStack_168;
  undefined4 uStack_160;
  uint uStack_15c;
  uint uStack_158;
  ushort uStack_154;
  byte *pbStack_152;
  undefined2 uStack_14a;
  undefined2 uStack_148;
  undefined2 uStack_146;
  ushort uStack_144;
  undefined2 uStack_142;
  undefined4 uStack_140;
  short sStack_138;
  ushort uStack_136;
  uint uStack_134;
  byte *pbStack_130;
  undefined4 uStack_128;
  uint uStack_124;
  uint uStack_120;
  ushort uStack_11c;
  byte *pbStack_11a;
  undefined2 uStack_112;
  undefined2 uStack_110;
  undefined2 uStack_10e;
  ushort uStack_10c;
  undefined2 uStack_10a;
  undefined4 uStack_108;
  uint auStack_100 [2];
  longlong lStack_f8;
  longlong lStack_f0;
  uint uStack_e8;
  int iStack_e4;
  int aiStack_e0 [2];
  undefined8 *puStack_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  longlong lStack_c0;
  longlong *plStack_b8;
  uint uStack_a8;
  short asStack_a0 [8];
  undefined8 uStack_90;
  undefined8 uStack_88;
  undefined2 uStack_80;
  undefined8 uStack_78;
  undefined8 uStack_68;
  ulonglong uStack_58;
  
  uStack_90 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_1b8;
  sStack_170 = -1;
  uVar21 = 0;
  pbStack_168 = (byte *)0x0;
  uVar20 = 0;
  uStack_16c = 0;
  pbStack_152 = (byte *)0x0;
  uStack_148 = 0;
  uStack_146 = 0;
  uStack_144 = 0;
  uStack_142 = 0;
  uStack_160 = 0;
  uStack_15c = 0;
  sStack_138 = -1;
  pbStack_130 = (byte *)0x0;
  uStack_134 = 0;
  pbStack_11a = (byte *)0x0;
  uStack_110 = 0;
  uStack_10e = 0;
  uStack_10c = 0;
  uStack_10a = 0;
  uStack_128 = 0;
  uStack_124 = 0;
  uStack_88 = 0;
  uStack_80 = 1;
  uVar18 = *(ushort *)(param_2 + 0x1c);
  lVar27 = *(longlong *)(*param_1 + 0x6a0);
  if ((((uVar18 == 0) || (*(ushort *)(lVar27 + 0x74) < uVar18)) ||
      (lStack_f0 = *(longlong *)(*(longlong *)(lVar27 + 0x50) + -8 + (ulonglong)uVar18 * 8),
      lStack_f0 == 0)) || ((*(byte *)(lStack_f0 + 100) & 4) != 0)) {
    lStack_f0 = 0;
  }
  lVar27 = lStack_f0;
  lStack_f8 = param_2;
  puStack_d8 = param_4;
  plStack_b8 = param_3;
  if (((*(byte *)(*param_1 + 0x1cd0) & 0x40) == 0) ||
     (iVar9 = func_0x(param_1,lStack_f0,param_2), iVar9 == 0)) {
    uVar2 = *(undefined2 *)(param_3 + 1);
    uVar10 = *(undefined4 *)((longlong)param_3 + 4);
    *(undefined4 *)((longlong)param_1 + 0x5674) = *(undefined4 *)param_3;
    *(undefined4 *)(param_1 + 0xacf) = uVar10;
    *(undefined2 *)((longlong)param_1 + 0x567c) = uVar2;
    lVar16 = *param_3;
    sVar19 = 0;
    uStack_a8 = (uint)*(ushort *)(param_3 + 1);
    do {
      uVar28 = *(uint *)((longlong)param_1 + 0x568c);
      while ((uVar28 & 1) == 0) {
        LOCK();
        uVar22 = *(uint *)((longlong)param_1 + 0x568c);
        bVar31 = uVar28 == uVar22;
        if (bVar31) {
          *(uint *)((longlong)param_1 + 0x568c) = uVar28 | 1;
          uVar22 = uVar28;
        }
        UNLOCK();
        uVar28 = uVar22;
        if (bVar31) {
          param_1[0xad0] = lVar16;
          *(uint *)(param_1 + 0xad1) = uStack_a8;
          *(uint *)((longlong)param_1 + 0x568c) = uVar22 + 2;
          cVar7 = func_0x();
          if (cVar7 != '\0') {
            uStack_190 = (undefined8 *)CONCAT44(uStack_190._4_4_,(uint)*(ushort *)(lVar27 + 0x20));
            uStack_198 = (short *)CONCAT44(uStack_198._4_4_,(uint)*(ushort *)(param_3 + 1));
            func_0x(*param_1,0xfab8d0,*(undefined4 *)param_3,
                            *(undefined4 *)((longlong)param_3 + 4));
          }
          lStack_c0 = param_2 + 0x3e;
          pbStack_130 = (byte *)func_0x(lStack_c0,0,auStack_100);
          sVar8 = 3;
          uStack_178 = 9;
          uVar25 = uVar21;
          if ((*pbStack_130 & 1) == 0) {
            sStack_138 = 0;
            uStack_112 = 0;
            uStack_110 = 0;
            switch(*pbStack_130 & 0xe) {
            default:
              uVar25 = (ulonglong)*(ushort *)(pbStack_130 + 2);
              if (0x1f9d < *(ushort *)(pbStack_130 + 2) - 1) {
                func_0x(pbStack_130,6,pbStack_130,0xc8f948);
              }
              break;
            case 4:
              uVar25 = 9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar25 = 1;
            }
            uStack_128 = (undefined4)uVar25;
            uVar29 = (ulonglong)uStack_134;
          }
          else {
            sStack_138 = 1;
            bVar1 = *pbStack_130;
            switch(bVar1 & 0x1c) {
            default:
              if ((char)pbStack_130[1] < '\0') {
                uStack_136 = (*(ushort *)(pbStack_130 + 1) & 0x7f) << 8 |
                             *(ushort *)(pbStack_130 + 1) >> 8;
                uStack_120 = 3;
              }
              else {
                uStack_136 = (ushort)pbStack_130[1];
                uStack_120 = 2;
                sVar8 = 2;
              }
              uStack_11c = (short)(uStack_136 + 1 >> 1) + sVar8;
              if (uStack_136 < 0x1f) {
                uStack_108 = 0;
                uVar29 = (ulonglong)uStack_134;
              }
              else {
                iVar9 = uStack_136 - 1;
                uStack_120 = CONCAT22(((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                                      (short)((longlong)iVar9 * 0x88888889 >> 0x3f),
                                      (undefined2)uStack_120);
                uStack_108 = 0;
                uVar29 = (ulonglong)uStack_134;
                uVar25 = 0;
              }
              break;
            case 4:
              if (((bVar1 & 0x1c) == 4) && ((bVar1 & 2) != 0)) {
                uStack_120 = 0;
                uStack_136 = 0;
                uStack_11c = 0;
                uStack_112 = 0;
                uVar29 = 0xf;
                uStack_134 = 0xf;
                uStack_108 = 1;
                uVar25 = 0;
              }
              else {
                uStack_120 = 0;
                uStack_136 = 0;
                uStack_11c = 0;
                uStack_112 = 0;
                uVar29 = 1;
                uStack_134 = 1;
                uStack_108 = 0;
                uVar25 = 0;
              }
              break;
            case 8:
              uStack_120 = 0;
              uStack_136 = 0;
              uStack_11c = 0;
              uStack_112 = 0;
              uVar29 = 9;
              uStack_134 = 9;
              uStack_108 = 0;
              uVar25 = 0;
            }
          }
          uVar28 = (uint)uVar29;
          if (sStack_138 != 0) {
            if (uVar28 == 0) {
              func_0x(&uStack_136);
              uVar28 = uStack_134;
            }
            if ((uVar28 < 9) && (((*pbStack_130 & 0x1c) == 0 || ((*pbStack_130 & 0x1c) == 0xc)))) {
              uVar28 = 9;
            }
            goto code_r0x001009ed;
          }
          if (uVar28 != 0) goto code_r0x001009a2;
          uStack_136 = 0;
          uStack_124 = (uint)uVar25;
          uVar29 = uVar25;
          if ((*pbStack_130 & 0x10) != 0) {
            uStack_124 = uStack_124 + 2 + (*(ushort *)(pbStack_130 + uVar25) + 7 >> 3);
            uVar29 = (ulonglong)uStack_124;
          }
          if ((*pbStack_130 & 0x20) == 0) {
            uStack_11c = 0;
            uStack_134 = (uint)uVar29;
            uStack_120 = (uint)uVar29;
            goto code_r0x00100795;
          }
          puVar30 = (ushort *)(pbStack_130 + uVar29);
          uStack_11c = *puVar30;
          if (uStack_11c == 0) {
            if ((((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
                (lVar27 = *(longlong *)
                           ((ulonglong)*puRam0000000000b912d0 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam0000000000b912c8 * 8) + 8), lVar27 != 0)) &&
               ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                (*(char *)(lVar27 + 0x499) != '\0')))) {
              if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
                (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_198 = (short *)0x0;
                (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x80f);
              }
            }
            func_0x(pbStack_130,3);
          }
          uStack_120 = uStack_124 + 2 + (uint)uStack_11c * 2;
          if (0x1f9e < uStack_120) {
            if (((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
               ((lVar27 = *(longlong *)
                           ((ulonglong)*puRam0000000000b912d0 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam0000000000b912c8 * 8) + 8), lVar27 != 0 &&
                ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                 (*(char *)(lVar27 + 0x499) != '\0')))))) {
              if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
                (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_198 = (short *)0x0;
                (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x816);
              }
            }
            func_0x(pbStack_130,4);
          }
          uStack_134 = puVar30[uStack_11c] & 0x7fff;
          uVar29 = (ulonglong)uStack_134;
          uVar28 = uStack_120;
          if (uStack_134 < uStack_120) {
            if ((((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
                (lVar27 = *(longlong *)
                           ((ulonglong)*puRam0000000000b912d0 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam0000000000b912c8 * 8) + 8), lVar27 != 0)) &&
               ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                (*(char *)(lVar27 + 0x499) != '\0')))) {
              if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
                (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_198 = (short *)0x0;
                (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x81d);
              }
            }
            func_0x(pbStack_130,4);
            uVar29 = (ulonglong)uStack_134;
            uVar28 = uStack_120;
          }
          goto code_r0x00100670;
        }
      }
    } while( true );
  }
  goto LAB_;
  while( true ) {
    uVar22 = uVar28;
    if (uStack_11c != 1) {
      uVar22 = *(ushort *)(pbStack_130 + (ulonglong)uStack_11c * 2 + ((ulonglong)uStack_124 - 2)) &
               0x7fff;
    }
    if ((uVar22 < uVar28) ||
       ((*(ushort *)(pbStack_130 + (ulonglong)uStack_11c * 2 + (ulonglong)uStack_124) & 0x7fff) <
        uVar22)) {
      func_0x(pbStack_130,7);
      uVar29 = (ulonglong)uStack_134;
      uVar28 = uStack_120;
    }
    if ((uVar22 < uVar28) || ((uint)uVar29 < uVar22)) goto code_r0x001009a2;
    if (*(ushort *)(pbStack_130 + uVar22) == 5) {
      uStack_136 = uStack_136 | 2;
      uStack_11c = uStack_11c - 1;
      uStack_10e = (undefined2)uVar22;
      uVar18 = *(ushort *)(pbStack_130 + (ulonglong)(uVar22 & 0xffff) + 2);
      uVar17 = uStack_10c & 0xc7ff;
      if ((uVar18 & 0x4000) != 0) {
        uVar17 = (uVar18 ^ uStack_10c) & 0x3800 ^ uStack_10c;
      }
      uStack_10c = (uVar17 ^ uVar18) & 0x7ff ^ uVar17;
      break;
    }
    if (*(ushort *)(pbStack_130 + uVar22) < 0x400) break;
    uStack_136 = uStack_136 | 1;
    uStack_11c = uStack_11c - 1;
    if (uStack_11c == 0) break;
code_r0x00100670:
    if (-1 < (short)puVar30[(ulonglong)(uStack_11c - 1) + 1]) break;
  }
code_r0x00100795:
  if ((*pbStack_130 & 0x40) == 0) {
    uStack_112 = 0;
    uStack_110 = 0;
  }
  else {
    uStack_112 = (undefined2)uVar29;
    uStack_110 = (undefined2)(uVar29 >> 0x10);
    uStack_134 = (int)uVar29 + 0xe;
    puVar12 = (ulonglong *)func_0x(&uStack_136);
    uVar25 = *puVar12;
    uVar17 = (ushort)(uVar25 >> 0x30);
    uVar18 = uVar17;
    if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
      uVar18 = uVar17 & 0xdfff;
      if ((uVar25 & 0x4000000000000000) != 0) {
        uVar18 = uVar17 | 0x2000;
      }
    }
    uVar28 = uVar20;
    if (uVar18 == 0xfffc) {
      uVar28 = (uint)((uVar25 >> 0x20 & 0xffff) >> 5);
    }
    uStack_134 = uStack_134 + uVar28;
    uVar29 = (ulonglong)uStack_134;
  }
  if ((pbStack_11a != (byte *)0x0) && (pbStack_11a < pbStack_130 + uVar29)) {
    if (((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
       (((lVar27 = *(longlong *)
                    ((ulonglong)*puRam0000000000b912d0 +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam0000000000b912c8 * 8
                      ) + 8), lVar27 != 0 && (lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0))
        && (*(char *)(lVar27 + 0x499) != '\0')))) {
      if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
        (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3fa);
      }
      else {
        uStack_198 = (short *)0x0;
        (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x877);
      }
    }
    func_0x(pbStack_130,0x12);
    uVar29 = (ulonglong)uStack_134;
  }
  if (0x3f3b < (int)uVar29 - 1U) {
    if (((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
       ((lVar27 = *(longlong *)
                   ((ulonglong)*puRam0000000000b912d0 +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam0000000000b912c8 * 8)
                   + 8), lVar27 != 0 &&
        ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 && (*(char *)(lVar27 + 0x499) != '\0'))
        )))) {
      if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
        (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3ed);
      }
      else {
        uStack_198 = (short *)0x0;
        (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x87c);
      }
    }
    func_0x(pbStack_130,5);
    uVar29 = (ulonglong)uStack_134;
  }
code_r0x001009a2:
  uVar28 = (uint)uVar29;
  if ((uVar28 < 9) && (((*pbStack_130 & 0xe) == 0 || ((*pbStack_130 & 0xe) == 0xc)))) {
    uVar28 = 9;
  }
code_r0x001009ed:
  if (auStack_100[0] != uVar28) {
    uStack_198 = (short *)0x0;
    (*pcRam0000000000b91260)(1,0x10aa960,0x1099c50,0x1857);
  }
  pbStack_168 = (byte *)func_0x(lStack_c0,1,auStack_100);
  uVar25 = uVar21;
  if ((*pbStack_168 & 1) == 0) {
    sStack_170 = 0;
    uStack_14a = 0;
    uStack_148 = 0;
    switch(*pbStack_168 & 0xe) {
    default:
      uVar25 = (ulonglong)*(ushort *)(pbStack_168 + 2);
      if (0x1f9d < *(ushort *)(pbStack_168 + 2) - 1) {
        func_0x(pbStack_168,6);
      }
      break;
    case 4:
      uVar25 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar25 = 1;
    }
    uStack_160 = (undefined4)uVar25;
  }
  else {
    sStack_170 = 1;
    bVar1 = *pbStack_168;
    switch(bVar1 & 0x1c) {
    default:
      if ((char)pbStack_168[1] < '\0') {
        uStack_16e = (*(ushort *)(pbStack_168 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_168 + 1) >> 8;
        uVar18 = 3;
        sVar8 = 3;
      }
      else {
        uStack_16e = (ushort)pbStack_168[1];
        uVar18 = 2;
        sVar8 = 2;
      }
      uStack_154 = (short)(uStack_16e + 1 >> 1) + sVar8;
      if (uStack_16e < 0x1f) {
        uStack_158 = (uint)uVar18;
        uStack_140 = 0;
      }
      else {
        iVar9 = uStack_16e - 1;
        uStack_158 = CONCAT22(((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                              (short)((longlong)iVar9 * 0x88888889 >> 0x3f),uVar18);
        uStack_140 = 0;
        uVar25 = 0;
      }
      break;
    case 4:
      if (((bVar1 & 0x1c) == 4) && ((bVar1 & 2) != 0)) {
        uStack_158 = 0;
        uStack_16e = 0;
        uStack_154 = 0;
        uStack_14a = 0;
        uStack_16c = 0xf;
        uStack_140 = 1;
        uVar25 = 0;
      }
      else {
        uStack_158 = 0;
        uStack_16e = 0;
        uStack_154 = 0;
        uStack_14a = 0;
        uStack_16c = 1;
        uStack_140 = 0;
        uVar25 = 0;
      }
      break;
    case 8:
      uStack_158 = 0;
      uStack_16e = 0;
      uStack_154 = 0;
      uStack_14a = 0;
      uStack_16c = 9;
      uStack_140 = 0;
      uVar25 = 0;
    }
  }
  uVar28 = 0;
  if (sStack_170 == 0) {
    uVar22 = uStack_16c;
    if (uStack_16c == 0) {
      uStack_16e = 0;
      uVar22 = (uint)uVar25;
      if ((*pbStack_168 & 0x10) != 0) {
        uVar22 = uVar22 + 2 + (*(ushort *)(pbStack_168 + uVar25) + 7 >> 3);
      }
      uStack_15c = uVar22;
      if ((*pbStack_168 & 0x20) == 0) {
        uStack_154 = 0;
        uStack_16c = uVar22;
        uStack_158 = uVar22;
      }
      else {
        puVar30 = (ushort *)(pbStack_168 + uVar22);
        uStack_154 = *puVar30;
        if (uStack_154 == 0) {
          if ((((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
              (lVar27 = *(longlong *)
                         ((ulonglong)*puRam0000000000b912d0 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000b912c8 * 8) + 8), lVar27 != 0)) &&
             ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
              (*(char *)(lVar27 + 0x499) != '\0')))) {
            if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
              (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_198 = (short *)0x0;
              (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x80f);
            }
          }
          func_0x(pbStack_168,3);
        }
        uStack_158 = uStack_15c + 2 + (uint)uStack_154 * 2;
        if (0x1f9e < uStack_158) {
          if (((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
             ((lVar27 = *(longlong *)
                         ((ulonglong)*puRam0000000000b912d0 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000b912c8 * 8) + 8), lVar27 != 0 &&
              ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
               (*(char *)(lVar27 + 0x499) != '\0')))))) {
            if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
              (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_198 = (short *)0x0;
              (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x816);
            }
          }
          func_0x(pbStack_168,4);
        }
        uStack_16c = puVar30[uStack_154] & 0x7fff;
        uVar22 = uStack_16c;
        uVar24 = uStack_158;
        if (uStack_16c < uStack_158) {
          if ((((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
              (lVar27 = *(longlong *)
                         ((ulonglong)*puRam0000000000b912d0 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000b912c8 * 8) + 8), lVar27 != 0)) &&
             ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
              (*(char *)(lVar27 + 0x499) != '\0')))) {
            if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
              (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_198 = (short *)0x0;
              (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x81d);
            }
          }
          func_0x(pbStack_168,4);
          uVar22 = uStack_16c;
          uVar24 = uStack_158;
        }
        do {
          if (-1 < (short)puVar30[(ulonglong)(uStack_154 - 1) + 1]) break;
          uVar23 = uVar24;
          if (uStack_154 != 1) {
            uVar23 = *(ushort *)
                      (pbStack_168 + (ulonglong)uStack_154 * 2 + ((ulonglong)uStack_15c - 2)) &
                     0x7fff;
          }
          if ((uVar23 < uVar24) ||
             ((*(ushort *)(pbStack_168 + (ulonglong)uStack_154 * 2 + (ulonglong)uStack_15c) & 0x7fff
              ) < uVar23)) {
            func_0x(pbStack_168,7);
            uVar22 = uStack_16c;
            uVar24 = uStack_158;
          }
          if ((uVar23 < uVar24) || (uVar22 < uVar23)) goto code_r0x00101251;
          if (*(ushort *)(pbStack_168 + uVar23) == 5) {
            uStack_16e = uStack_16e | 2;
            uStack_154 = uStack_154 - 1;
            uStack_146 = (undefined2)uVar23;
            uVar18 = *(ushort *)(pbStack_168 + (ulonglong)(uVar23 & 0xffff) + 2);
            uVar17 = uStack_144 & 0xc7ff;
            if ((uVar18 & 0x4000) != 0) {
              uVar17 = (uVar18 ^ uStack_144) & 0x3800 ^ uStack_144;
            }
            uStack_144 = (uVar17 ^ uVar18) & 0x7ff ^ uVar17;
            break;
          }
          if (*(ushort *)(pbStack_168 + uVar23) < 0x400) break;
          uStack_16e = uStack_16e | 1;
          uStack_154 = uStack_154 - 1;
        } while (uStack_154 != 0);
      }
      if ((*pbStack_168 & 0x40) == 0) {
        uStack_14a = 0;
        uStack_148 = 0;
      }
      else {
        uStack_14a = (undefined2)uVar22;
        uStack_148 = (undefined2)(uVar22 >> 0x10);
        uStack_16c = uVar22 + 0xe;
        puVar12 = (ulonglong *)func_0x(&uStack_16e);
        uVar25 = *puVar12;
        uVar17 = (ushort)(uVar25 >> 0x30);
        uVar18 = uVar17;
        if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
          uVar18 = uVar17 & 0xdfff;
          if ((uVar25 & 0x4000000000000000) != 0) {
            uVar18 = uVar17 | 0x2000;
          }
        }
        uVar22 = uVar28;
        if (uVar18 == 0xfffc) {
          uVar22 = (uint)((uVar25 >> 0x20 & 0xffff) >> 5);
        }
        uVar22 = uStack_16c + uVar22;
        uStack_16c = uVar22;
      }
      if ((pbStack_152 != (byte *)0x0) && (pbStack_152 < pbStack_168 + uVar22)) {
        if (((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
           (((lVar27 = *(longlong *)
                        ((ulonglong)*puRam0000000000b912d0 +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000b912c8 * 8) + 8), lVar27 != 0 &&
             (lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0)) &&
            (*(char *)(lVar27 + 0x499) != '\0')))) {
          if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
            (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_198 = (short *)0x0;
            (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x877);
          }
        }
        func_0x(pbStack_168,0x12);
        uVar22 = uStack_16c;
      }
      if (0x3f3b < uVar22 - 1) {
        if (((cRam0000000001622a3b != '\0') || ((bRam0000000001633340 & 1) != 0)) &&
           ((lVar27 = *(longlong *)
                       ((ulonglong)*puRam0000000000b912d0 +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000b912c8 * 8) + 8), lVar27 != 0 &&
            ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
             (*(char *)(lVar27 + 0x499) != '\0')))))) {
          if ((cRam000000000162292b == '\0') && ((bRam0000000001633340 & 2) == 0)) {
            (*pcRam0000000000b91268)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_198 = (short *)0x0;
            (*pcRam0000000000b91260)(1,0xf13468,0x1033138,0x87c);
          }
        }
        func_0x(pbStack_168,5);
        uVar22 = uStack_16c;
      }
    }
code_r0x00101251:
    if ((8 < uVar22) || (((*pbStack_168 & 0xe) != 0 && ((*pbStack_168 & 0xe) != 0xc)))) {
      uStack_178 = uVar22;
    }
  }
  else {
    if (uStack_16c == 0) {
      func_0x(&uStack_16e);
    }
    uStack_178 = uStack_16c;
    if ((uStack_16c < 9) &&
       (((*pbStack_168 & 0x1c) == 0 || (uStack_178 = uStack_16c, (*pbStack_168 & 0x1c) == 0xc)))) {
      uStack_178 = 9;
    }
  }
  if (auStack_100[0] != uStack_178) {
    uStack_198 = (short *)0x0;
    (*pcRam0000000000b91260)(1,0x10aa990,0x1099c50,0x185b);
  }
  iVar9 = func_0x(&sStack_138);
  if (iVar9 == 2) {
    uStack_190 = puStack_d8;
    uStack_198 = &sStack_138;
    func_0x(param_1,lStack_f8,param_3,&sStack_170);
    goto LAB_;
  }
  if ((((param_1[0x108a] != 0) && (lStack_f0 != 0)) &&
      (iVar9 = func_0x(lStack_f0,&sStack_170), iVar9 != 0)) &&
     (param_1[0x108a] != 0)) {
    func_0x(param_1[0x108a],0xfab958,param_3);
  }
  lVar27 = lStack_f8;
  if ((*(byte *)((longlong)param_1 + 0x24) & 0x10) == 0) {
    lVar16 = *(longlong *)(*param_1 + 0x6b0);
    if (((*(int *)(lVar16 + 0x310) != 0) &&
        ((*(longlong *)(lVar16 + 0x314) != lRam0000000001678a58 ||
         (*(longlong *)(lVar16 + 0x31c) != lRam0000000001678a60)))) ||
       (*(char *)(*param_1 + 0x206c) != '\0')) goto code_r0x0010138b;
  }
  else {
code_r0x0010138b:
    uVar2 = *(undefined2 *)(lStack_f8 + 0x1c);
    uVar3 = *(undefined8 *)(*param_1 + 0x6a0);
    uVar10 = func_0x(param_1,param_3,lStack_f8);
    uStack_198 = (short *)CONCAT44(uStack_198._4_4_,uVar10);
    func_0x(uVar3,uVar2,&sStack_138,&sStack_170);
  }
  puVar13 = (uint *)func_0x(&sStack_138,5);
  if (puVar13 == (uint *)0x0) {
    uStack_178 = 0;
    puVar14 = (undefined4 *)(*pcRam0000000000b91600)();
    *puVar14 = 0x16;
    (*pcRam0000000000b91618)();
    uVar22 = uVar20;
  }
  else {
    uStack_178 = *puVar13;
    uVar22 = uStack_178;
  }
  puVar13 = (uint *)func_0x(&sStack_170,5);
  if (puVar13 == (uint *)0x0) {
    uStack_e8 = 0;
    puVar14 = (undefined4 *)(*pcRam0000000000b91600)();
    *puVar14 = 0x16;
    (*pcRam0000000000b91618)();
    uVar24 = uVar20;
  }
  else {
    uStack_e8 = *puVar13;
    uVar24 = uStack_e8;
  }
  if (uVar22 < uVar24) {
    if (*(ushort *)(lVar27 + 0x3e) < 3) {
      uStack_198 = (short *)0x0;
      (*pcRam0000000000b91260)(1,0x10e28a0,0x1099c50,0x188e);
    }
    puVar15 = (undefined8 *)func_0x(lVar27 + 0x3e,2,&lStack_c0);
    iVar9 = func_0x(param_1,param_3,lVar27);
  }
  else {
    if (param_1[0x108a] != 0) {
      func_0x(param_1[0x108a],0xf412d8,param_3);
    }
    uStack_180 = 0;
    plStack_188 = (longlong *)0x0;
    uStack_190 = (undefined8 *)((ulonglong)uStack_190 & 0xffffffffffffff00);
    uStack_198 = (short *)CONCAT71(uStack_198._1_7_,1);
    iStack_e4 = func_0x(param_1,lVar27,param_3,puStack_d8);
    plVar6 = plStack_b8;
    uVar23 = uStack_178;
    if (((uVar24 < uVar22) && (uVar22 = uVar23, *(char *)(*param_1 + 0x206c) != '\0')) &&
       ((plVar4 = (longlong *)param_1[0xbf0], plVar4 != (longlong *)0x0 &&
        (uVar2 = *(undefined2 *)(lStack_f8 + 0x1c), *(int *)(plVar4 + 1) != 0)))) {
      do {
        func_0x(*(undefined8 *)(*plVar4 + uVar21 * 8),uVar2,uVar23,plVar6);
        uVar24 = (int)uVar21 + 1;
        uVar21 = (ulonglong)uVar24;
      } while (uVar24 < *(uint *)(plVar4 + 1));
    }
    puVar15 = &uStack_88;
    iVar9 = iStack_e4;
  }
  plVar6 = plStack_b8;
  lVar27 = lStack_f8;
  uStack_180 = CONCAT44(uStack_180._4_4_,iVar9);
  plStack_188 = plStack_b8;
  uStack_198 = (short *)CONCAT44(uStack_198._4_4_,1);
  uStack_190 = puVar15;
  func_0x
            (*(undefined8 *)(*param_1 + 0x6a0),*(undefined2 *)(lStack_f8 + 0x1c),&sStack_138,
             &sStack_170);
  if (uVar22 < uStack_e8) {
    uStack_180 = 0;
    plStack_188 = (longlong *)0x0;
    uStack_190 = (undefined8 *)((ulonglong)uStack_190 & 0xffffffffffffff00);
    uStack_198 = (short *)CONCAT71(uStack_198._1_7_,1);
    func_0x(param_1,lVar27,plVar6,puStack_d8);
    if (iVar9 != 0) {
      lVar16 = *param_1;
      lVar5 = *(longlong *)(lVar16 + 0x6a0);
      uVar18 = *(ushort *)(lVar27 + 0x1c);
      lStack_f0 = 0;
      if ((((uVar18 == 0) || ((uint)*(ushort *)(lVar5 + 0x74) < (uint)uVar18)) ||
          (lVar26 = *(longlong *)(*(longlong *)(lVar5 + 0x50) + -8 + (ulonglong)uVar18 * 8),
          lStack_f0 = lVar26, lVar26 == 0)) || ((*(byte *)(lVar26 + 100) & 4) != 0)) {
        lVar26 = lStack_f0;
        lVar27 = *(longlong *)(*(longlong *)(lVar5 + 0x20) + 0x6b0);
        plStack_188 = (longlong *)(lVar27 + 0x3a8);
        uStack_190 = (undefined8 *)CONCAT44(uStack_190._4_4_,*(undefined4 *)(lVar27 + 0x3a0));
        uStack_198 = (short *)CONCAT44(uStack_198._4_4_,(uint)uVar18);
        (*pcRam0000000000b91268)(0x33,0x50,0x16,1);
        lVar16 = *param_1;
      }
      lVar27 = lStack_f8;
      if (*(char *)(lVar16 + 0x206c) == '\0') {
        func_0x(lVar26,1);
        lVar27 = lStack_f8;
      }
    }
  }
  if ((*(byte *)((longlong)param_1 + 0x24) & 0x10) == 0) {
    lVar16 = *(longlong *)(*param_1 + 0x6b0);
    if (((*(int *)(lVar16 + 0x310) != 0) &&
        ((*(longlong *)(lVar16 + 0x314) != lRam0000000001678a58 ||
         (*(longlong *)(lVar16 + 0x31c) != lRam0000000001678a60)))) ||
       (*(char *)(*param_1 + 0x206c) != '\0')) goto code_r0x00101697;
code_r0x001017ab:
    func_0x(param_1,plVar6);
    if (iVar9 != 0) goto code_r0x001017bb;
    lVar27 = lStack_f0;
    if (lStack_f0 == 0) goto LAB_;
  }
  else {
code_r0x00101697:
    uVar2 = *(undefined2 *)(lVar27 + 0x1c);
    lVar27 = *(longlong *)(*param_1 + 0x6a0);
    if (((iVar9 == 0) ||
        (iVar11 = func_0x(&sStack_138,&sStack_170,aiStack_e0,asStack_a0),
        iVar11 == 0)) || (aiStack_e0[0] == 0)) goto code_r0x001017ab;
    uStack_d0 = 0;
    uStack_c8 = 0;
    lVar16 = func_0x(lVar27,uVar2,&uStack_d0,4);
    if (lVar16 == 0) {
      uStack_198 = (short *)0x0;
      (*pcRam0000000000b91260)(1,0x10c6560,0x10981e8,0x416c);
    }
    if ((*(byte *)(lVar16 + 100) & 0x40) != 0) {
      uStack_198 = (short *)0x0;
      (*pcRam0000000000b91260)(1,0x10caf28,0x10981e8,0x416d);
    }
    func_0x(uRam0000000001633958,0,*(undefined8 *)(lVar27 + 0x20),100);
    func_0x(lVar16,1);
    uStack_190 = (undefined8 *)CONCAT44(uStack_190._4_4_,1);
    uStack_198 = asStack_a0;
    func_0x(lVar27,0,*(undefined2 *)(lVar16 + 0x20),1);
    if ((int)uStack_c8 == 0) goto code_r0x001017ab;
    func_0x(uStack_d0,uStack_c8._4_4_);
    uStack_c8 = uStack_c8 & 0xffffffff00000000;
    func_0x(param_1,plVar6);
code_r0x001017bb:
    lVar27 = lStack_f0;
    if (lStack_f0 == 0) goto LAB_;
    if (((*(byte *)((longlong)param_1 + 0x24) & 0x10) != 0) ||
       (*(char *)(*param_1 + 0x206c) != '\0')) {
      func_0x(lStack_f0,1);
      lVar16 = *(longlong *)(*param_1 + 0x6b0);
      if (((*(longlong *)(lVar16 + 0x280) == 0) &&
          (((*(byte *)(lVar16 + 0x38) & 8) == 0 || ((*(byte *)(lVar16 + 0x38) & 0x20) != 0)))) ||
         (*(char *)(param_1 + 0xbfb) != '\0')) {
        func_0x
                  (*(undefined2 *)(lVar16 + 0x28),*(undefined2 *)(*param_1 + 0x660),lVar27 + 0x124,
                   lVar27);
      }
    }
  }
  if (*(char *)(*param_1 + 0x2050) != '\0') {
    puVar15 = (undefined8 *)func_0x(&sStack_170,0x15);
    sVar8 = sVar19;
    uVar22 = uVar28;
    uVar24 = uVar28;
    if (puVar15 != (undefined8 *)0x0) {
      uVar3 = *puVar15;
      sVar8 = *(short *)(puVar15 + 1);
      uStack_78._4_4_ = (uint)((ulonglong)uVar3 >> 0x20);
      uStack_78._0_4_ = (uint)uVar3;
      uVar22 = (uint)uStack_78;
      uVar24 = uStack_78._4_4_;
      uStack_78 = uVar3;
    }
    puVar15 = (undefined8 *)func_0x(&sStack_138,0x15);
    if (puVar15 != (undefined8 *)0x0) {
      uVar3 = *puVar15;
      sVar19 = *(short *)(puVar15 + 1);
      uStack_68._4_4_ = (uint)((ulonglong)uVar3 >> 0x20);
      uStack_68._0_4_ = (uint)uVar3;
      uVar20 = (uint)uStack_68;
      uVar28 = uStack_68._4_4_;
      uStack_68 = uVar3;
    }
    if (((sVar8 != sVar19) || (uVar22 != uVar20)) || (uVar24 != uVar28)) {
      *(undefined4 *)(lVar27 + 0x198) = 2;
    }
  }
LAB_:
  func_0x(uStack_58 ^ (ulonglong)auStack_1b8);
  return;
}

