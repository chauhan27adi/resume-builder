
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined param_2,longlong param_3,undefined8 *param_4,
                 int param_5,undefined8 param_6)

{
  longlong lVar1;
  longlong *plVar2;
  undefined *puVar3;
  int iVar4;
  ulonglong uVar5;
  ulonglong *puVar6;
  char cVar7;
  byte bVar8;
  ulonglong uVar9;
  ushort uVar10;
  ushort uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  ushort *puVar15;
  ulonglong uVar16;
  uint uVar17;
  int iVar18;
  longlong unaff_GS_OFFSET;
  undefined auStack_d48 [32];
  undefined8 uStack_d28;
  short sStack_d18;
  ushort uStack_d16;
  uint uStack_d14;
  byte *pbStack_d10;
  undefined8 uStack_d08;
  uint uStack_d00;
  ushort uStack_cfc;
  byte *pbStack_cfa;
  undefined2 uStack_cf2;
  undefined2 uStack_cf0;
  undefined2 uStack_cee;
  ushort uStack_cec;
  undefined2 uStack_cea;
  undefined8 uStack_cd8;
  int iStack_cd0;
  undefined8 uStack_cc8;
  int *piStack_cc0;
  undefined **ppuStack_cb8;
  undefined8 uStack_cb0;
  undefined8 uStack_ca8;
  undefined *puStack_ca0;
  undefined8 uStack_c98;
  undefined4 uStack_c90;
  undefined8 uStack_c8c;
  undefined8 uStack_c84;
  undefined8 uStack_c78;
  undefined2 uStack_c70;
  undefined auStack_c68 [2];
  undefined2 uStack_c66;
  undefined8 uStack_c64;
  undefined2 uStack_c5c;
  undefined2 uStack_c5a;
  undefined4 uStack_c58;
  undefined2 uStack_c54;
  undefined uStack_c52;
  undefined uStack_c51;
  ushort uStack_c4c;
  short asStack_c4a [65];
  undefined auStack_bc8 [16];
  undefined auStack_bb8 [800];
  int iStack_898;
  int iStack_894;
  uint uStack_890;
  int iStack_88c;
  int iStack_888;
  undefined *puStack_880;
  undefined *puStack_878;
  byte *pbStack_870;
  undefined8 *puStack_868;
  undefined8 uStack_860;
  undefined auStack_858 [2048];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_d48;
  pbStack_d10 = (byte *)0x0;
  iVar4 = 0;
  uStack_d14 = 0;
  pbStack_cfa = (byte *)0x0;
  sStack_d18 = -1;
  uStack_cf0 = 0;
  uStack_cee = 0;
  uStack_cec = 0;
  uStack_cea = 0;
  uStack_d08 = 0;
  uStack_c58 = 0;
  uStack_c54 = 0;
  uStack_c4c = 0;
  func_0x(param_3,&sStack_d18,auStack_858);
  uStack_d28 = param_3 + 0xb60;
  func_0x(auStack_bb8,*(undefined2 *)(param_3 + 0x20),*(undefined4 *)(param_3 + 100));
  uVar5 = 0xffffffffffffffff;
  do {
    uVar5 = uVar5 + 1;
  } while (*(short *)(uVar5 * 2 + 0x1d51800) != 0);
  if ((((_DAT_ == 0) || (DAT_ == '\0')) ||
      (*(char *)(*(longlong *)(param_1 + 0x20) + 0x6c18) == '\0')) ||
     ((lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x20) + 0x2400), lVar1 == 0 ||
      (*(int *)(lVar1 + 0x5b8) != 1)))) {
    cVar7 = '\0';
  }
  else {
    cVar7 = '\x01';
  }
  if ((((_DAT_ == 0) && ((DAT_ & 8) == 0)) && ((int)uVar5 != 0)) || (cVar7 != '\0'))
  {
    uStack_d28 = CONCAT71(uStack_d28._1_7_,cVar7);
    func_0x(auStack_bb8,0x1d51800,uVar5 & 0xffffffff);
  }
  uStack_c51 = 0;
  uStack_c5a = 0;
  asStack_c4a[uStack_c4c] = 0x314;
  uStack_c4c = uStack_c4c + 1;
  uVar5 = (ulonglong)uStack_d14;
  uStack_c52 = param_2;
  if (sStack_d18 == 0) {
    if (uStack_d14 == 0) {
      uVar5 = uStack_d08 & 0xffffffff;
      uStack_d16 = 0;
      uVar12 = (uint)uStack_d08;
      if ((*pbStack_d10 & 0x10) != 0) {
        uVar12 = (uint)uStack_d08 + 2 + (*(ushort *)(pbStack_d10 + uVar5) + 7 >> 3);
        uVar5 = (ulonglong)uVar12;
      }
      uStack_d08 = CONCAT44(uVar12,(uint)uStack_d08);
      uStack_d00 = (uint)uVar5;
      if ((*pbStack_d10 & 0x20) == 0) {
        uStack_cfc = 0;
        uStack_d14 = uStack_d00;
      }
      else {
        puVar15 = (ushort *)(pbStack_d10 + uVar5);
        uStack_cfc = *puVar15;
        if (uStack_cfc == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_d28 = 0;
              (*_DAT_)(1,0x13ee5b8,0x150e288,0x80f);
            }
          }
          func_0x(pbStack_d10,3);
        }
        uStack_d00 = uStack_d08._4_4_ + 2 + (uint)uStack_cfc * 2;
        if (0x1f9e < uStack_d00) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar1 != 0 &&
              ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
               (*(char *)(lVar1 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d28 = 0;
              (*_DAT_)(1,0x13ee5b8,0x150e288,0x816);
            }
          }
          func_0x(pbStack_d10,4);
        }
        uVar16 = (ulonglong)uStack_cfc;
        uStack_d14 = puVar15[uVar16] & 0x7fff;
        uVar5 = (ulonglong)uStack_d14;
        uVar12 = uStack_d00;
        if (uStack_d14 < uStack_d00) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d28 = 0;
              (*_DAT_)(1,0x13ee5b8,0x150e288,0x81d);
            }
          }
          func_0x(pbStack_d10,4);
          uVar16 = (ulonglong)uStack_cfc;
          uVar5 = (ulonglong)uStack_d14;
          uVar12 = uStack_d00;
        }
        do {
          if (-1 < (short)puVar15[(ulonglong)((int)uVar16 - 1) + 1]) break;
          if ((int)uVar16 == 1) {
            uVar9 = 1;
            uVar13 = uVar12;
LAB_:
            if ((*(ushort *)(pbStack_d10 + uVar9 * 2 + (uStack_d08 >> 0x20)) & 0x7fff) < uVar13)
            goto LAB_;
          }
          else {
            uVar13 = *(ushort *)(pbStack_d10 + uVar16 * 2 + ((uStack_d08 >> 0x20) - 2)) & 0x7fff;
            uVar9 = uVar16;
            if (uVar12 <= uVar13) goto LAB_;
LAB_:
            func_0x(pbStack_d10,7);
            uVar16 = (ulonglong)uStack_cfc;
            uVar5 = (ulonglong)uStack_d14;
            uVar12 = uStack_d00;
          }
          if ((uVar13 < uVar12) || ((uint)uVar5 < uVar13)) goto LAB_;
          if (*(ushort *)(pbStack_d10 + uVar13) == 5) {
            uStack_d16 = uStack_d16 | 2;
            uStack_cfc = (short)uVar16 - 1;
            uStack_cee = (undefined2)uVar13;
            if ((*(ushort *)(pbStack_d10 + (ulonglong)(uVar13 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_cec = uStack_cec & 0xc7ff;
            }
            else {
              uStack_cec = uStack_cec ^
                           (*(ushort *)(pbStack_d10 + (ulonglong)(uVar13 & 0xffff) + 2) ^ uStack_cec
                           ) & 0x3800;
            }
            uStack_cec = (uStack_cec ^ *(ushort *)(pbStack_d10 + (ulonglong)(uVar13 & 0xffff) + 2))
                         & 0x7ff ^ uStack_cec;
            break;
          }
          if (*(ushort *)(pbStack_d10 + uVar13) < 0x400) break;
          uStack_d16 = uStack_d16 | 1;
          uStack_cfc = (short)uVar16 - 1;
          uVar16 = (ulonglong)uStack_cfc;
        } while (uStack_cfc != 0);
      }
      if ((*pbStack_d10 & 0x40) == 0) {
        uStack_cf2 = 0;
        uStack_cf0 = 0;
      }
      else {
        uStack_cf2 = (undefined2)uVar5;
        uStack_cf0 = (undefined2)(uVar5 >> 0x10);
        uStack_d14 = (int)uVar5 + 0xe;
        puVar6 = (ulonglong *)func_0x(&uStack_d16);
        uVar5 = *puVar6;
        uVar10 = (ushort)(uVar5 >> 0x30);
        uVar11 = uVar10;
        if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
          uVar11 = uVar10 & 0xdfff;
          if ((uVar5 & 0x4000000000000000) != 0) {
            uVar11 = uVar10 | 0x2000;
          }
        }
        if (uVar11 == 0xfffc) {
          iVar4 = (int)((uVar5 >> 0x20 & 0xffff) >> 5);
        }
        uStack_d14 = uStack_d14 + iVar4;
        uVar5 = (ulonglong)uStack_d14;
      }
      if ((pbStack_cfa != (byte *)0x0) && (pbStack_cfa < pbStack_d10 + uVar5)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar1 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar1 != 0 &&
             (lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0)) &&
            (*(char *)(lVar1 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15);
          }
          else {
            uStack_d28 = 0;
            (*_DAT_)(1,0x13ee5b8,0x150e288);
          }
        }
        func_0x(pbStack_d10,0x12);
        uVar5 = (ulonglong)uStack_d14;
      }
      if (0x3f3b < (int)uVar5 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar1 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar1 != 0 &&
            ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15);
          }
          else {
            uStack_d28 = 0;
            (*_DAT_)(1,0x13ee5b8,0x150e288);
          }
        }
        func_0x(pbStack_d10,5);
        uVar5 = (ulonglong)uStack_d14;
      }
    }
LAB_:
    if (8 < (uint)uVar5) goto LAB_;
    bVar8 = *pbStack_d10 & 0xe;
  }
  else {
    if (uStack_d14 == 0) {
      func_0x(&uStack_d16);
      uVar5 = (ulonglong)uStack_d14;
    }
    if (8 < (uint)uVar5) goto LAB_;
    bVar8 = *pbStack_d10 & 0x1c;
  }
  if ((bVar8 == 0) || (bVar8 == 0xc)) {
    uVar5 = 9;
  }
LAB_:
  uVar12 = 9;
  asStack_c4a[uStack_c4c] = (short)uVar5;
  asStack_c4a[(ushort)(uStack_c4c + 1)] = 10;
  asStack_c4a[(ushort)(uStack_c4c + 2)] = (short)param_5 << 5;
  uStack_c64 = *param_4;
  uStack_c4c = uStack_c4c + 3;
  uStack_c5c = *(undefined2 *)(param_4 + 1);
  uStack_c66 = 0x1c;
  iStack_898 = (uint)uStack_c4c * 2 + 0x1e;
  puStack_880 = auStack_c68;
  puStack_878 = auStack_bb8;
  iStack_894 = 0x314;
  if (sStack_d18 == 0) {
    uVar13 = uStack_d14;
    if (uStack_d14 == 0) {
      uVar5 = uStack_d08 & 0xffffffff;
      uStack_d16 = 0;
      uVar13 = (uint)uStack_d08;
      if ((*pbStack_d10 & 0x10) != 0) {
        uVar13 = (uint)uStack_d08 + 2 + (*(ushort *)(pbStack_d10 + uVar5) + 7 >> 3);
        uVar5 = (ulonglong)uVar13;
      }
      uStack_d08 = CONCAT44(uVar13,(uint)uStack_d08);
      if ((*pbStack_d10 & 0x20) == 0) {
        uStack_cfc = 0;
        uStack_d14 = (uint)uVar5;
        uStack_d00 = (uint)uVar5;
      }
      else {
        puVar15 = (ushort *)(pbStack_d10 + uVar5);
        uStack_cfc = *puVar15;
        if (uStack_cfc == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15);
            }
            else {
              uStack_d28 = 0;
              (*_DAT_)(1,0x13ee5b8,0x150e288);
            }
          }
          func_0x(pbStack_d10,3);
        }
        uStack_d00 = uStack_d08._4_4_ + 2 + (uint)uStack_cfc * 2;
        if (0x1f9e < uStack_d00) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar1 != 0 &&
              ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
               (*(char *)(lVar1 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d28 = 0;
              (*_DAT_)(1,0x13ee5b8,0x150e288,0x816);
            }
          }
          func_0x(pbStack_d10,4);
        }
        uVar16 = (ulonglong)uStack_cfc;
        uStack_d14 = puVar15[uVar16] & 0x7fff;
        uVar5 = (ulonglong)uStack_d14;
        uVar17 = uStack_d00;
        if (uStack_d14 < uStack_d00) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d28 = 0;
              (*_DAT_)(1,0x13ee5b8,0x150e288,0x81d);
            }
          }
          func_0x(pbStack_d10,4);
          uVar16 = (ulonglong)uStack_cfc;
          uVar5 = (ulonglong)uStack_d14;
          uVar17 = uStack_d00;
        }
        do {
          if (-1 < (short)puVar15[(ulonglong)((int)uVar16 - 1) + 1]) break;
          if ((int)uVar16 == 1) {
            uVar9 = 1;
            uVar14 = uVar17;
LAB_:
            if ((*(ushort *)(pbStack_d10 + uVar9 * 2 + (uStack_d08 >> 0x20)) & 0x7fff) < uVar14)
            goto LAB_;
          }
          else {
            uVar14 = *(ushort *)(pbStack_d10 + uVar16 * 2 + ((uStack_d08 >> 0x20) - 2)) & 0x7fff;
            uVar9 = uVar16;
            if (uVar17 <= uVar14) goto LAB_;
LAB_:
            func_0x(pbStack_d10,7);
            uVar16 = (ulonglong)uStack_cfc;
            uVar5 = (ulonglong)uStack_d14;
            uVar17 = uStack_d00;
          }
          uVar13 = (uint)uVar5;
          if ((uVar14 < uVar17) || (uVar13 < uVar14)) goto LAB_;
          if (*(ushort *)(pbStack_d10 + uVar14) == 5) {
            uStack_d16 = uStack_d16 | 2;
            uStack_cfc = (short)uVar16 - 1;
            uStack_cee = (undefined2)uVar14;
            if ((*(ushort *)(pbStack_d10 + (ulonglong)(uVar14 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_cec = uStack_cec & 0xc7ff;
            }
            else {
              uStack_cec = uStack_cec ^
                           (*(ushort *)(pbStack_d10 + (ulonglong)(uVar14 & 0xffff) + 2) ^ uStack_cec
                           ) & 0x3800;
            }
            uStack_cec = (uStack_cec ^ *(ushort *)(pbStack_d10 + (ulonglong)(uVar14 & 0xffff) + 2))
                         & 0x7ff ^ uStack_cec;
            break;
          }
          if (*(ushort *)(pbStack_d10 + uVar14) < 0x400) break;
          uStack_d16 = uStack_d16 | 1;
          uStack_cfc = (short)uVar16 - 1;
          uVar16 = (ulonglong)uStack_cfc;
        } while (uStack_cfc != 0);
      }
      if ((*pbStack_d10 & 0x40) == 0) {
        uStack_cf2 = 0;
        uStack_cf0 = 0;
      }
      else {
        uStack_cf2 = (undefined2)uVar5;
        uStack_cf0 = (undefined2)(uVar5 >> 0x10);
        uStack_d14 = (int)uVar5 + 0xe;
        puVar6 = (ulonglong *)func_0x(&uStack_d16);
        uVar5 = *puVar6;
        iVar4 = 0;
        uVar10 = (ushort)(uVar5 >> 0x30);
        uVar11 = uVar10;
        if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
          uVar11 = uVar10 & 0xdfff;
          if ((uVar5 & 0x4000000000000000) != 0) {
            uVar11 = uVar10 | 0x2000;
          }
        }
        if (uVar11 == 0xfffc) {
          iVar4 = (int)((uVar5 >> 0x20 & 0xffff) >> 5);
        }
        uStack_d14 = uStack_d14 + iVar4;
        uVar5 = (ulonglong)uStack_d14;
      }
      uVar13 = (uint)uVar5;
      if ((pbStack_cfa != (byte *)0x0) && (pbStack_cfa < pbStack_d10 + uVar5)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar1 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar1 != 0 &&
             (lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0)) &&
            (*(char *)(lVar1 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_d28 = 0;
            (*_DAT_)(1,0x13ee5b8,0x150e288,0x877);
          }
        }
        func_0x(pbStack_d10,0x12);
        uVar13 = uStack_d14;
      }
      if (0x3f3b < uVar13 - 1) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar1 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar1 != 0 &&
            ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_d28 = 0;
            (*_DAT_)(1,0x13ee5b8,0x150e288,0x87c);
          }
        }
        func_0x(pbStack_d10,5);
        uVar13 = uStack_d14;
      }
    }
LAB_:
    if ((8 < uVar13) || (((*pbStack_d10 & 0xe) != 0 && ((*pbStack_d10 & 0xe) != 0xc)))) {
      uVar12 = uVar13;
    }
  }
  else {
    if (uStack_d14 == 0) {
      func_0x(&uStack_d16);
    }
    if ((8 < uStack_d14) || (((*pbStack_d10 & 0x1c) != 0 && ((*pbStack_d10 & 0x1c) != 0xc)))) {
      uVar12 = uStack_d14;
    }
  }
  lVar1 = *(longlong *)(param_1 + 0x20);
  pbStack_870 = pbStack_d10;
  uStack_860 = param_6;
  iStack_88c = 10;
  uStack_890 = uVar12;
  iStack_888 = param_5 << 5;
  puStack_868 = param_4;
  iVar4 = func_0x(lVar1);
  if (((iVar4 == 0) && (iVar4 = func_0x(lVar1), iVar4 == 0)) ||
     (iVar4 = param_5 << 5, iVar18 = 10, *(char *)(lVar1 + 0x2050) != '\0')) {
    func_0x(*(undefined8 *)(lVar1 + 0x6b0));
    iVar4 = iStack_888;
    iVar18 = iStack_88c;
    uVar12 = uStack_890;
  }
  puVar3 = puStack_880;
  uStack_c8c = 0xffffffffffffffff;
  uStack_cc8 = 5;
  uStack_cb0 = 2;
  uStack_c90 = 0;
  uStack_c84 = 0;
  uStack_cd8 = 0;
  uStack_ca8 = 0;
  uStack_c98 = 0;
  iStack_cd0 = (iVar4 + 3U & 0xfffffffc) + (iVar18 + 3U & 0xfffffffc) + (uVar12 + 3 & 0xfffffffc) +
               (iStack_894 + 3U & 0xfffffffc) + (iStack_898 + 3U & 0xfffffffc);
  piStack_cc0 = &iStack_898;
  ppuStack_cb8 = &puStack_880;
  puStack_ca0 = auStack_bc8;
  (**(code **)(**(longlong **)(lVar1 + 0x6c8) + 0x2c8))(*(longlong **)(lVar1 + 0x6c8),&uStack_cd8);
  func_0x(lVar1,puVar3);
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x20) + 0x6c8);
  uStack_c78 = 0;
  uStack_c70 = 0;
  (**(code **)(*plVar2 + 0x90))(plVar2,&uStack_c78,0);
  func_0x(uStack_58 ^ (ulonglong)auStack_d48);
  return;
}

