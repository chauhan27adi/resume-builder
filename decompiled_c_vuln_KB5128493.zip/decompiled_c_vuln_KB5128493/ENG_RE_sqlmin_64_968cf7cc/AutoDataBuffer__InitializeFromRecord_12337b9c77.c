
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2)

{
  ulonglong *puVar1;
  code *pcVar2;
  undefined4 *puVar3;
  undefined8 uVar4;
  byte bVar5;
  char cVar6;
  short sVar7;
  ushort uVar8;
  ushort uVar9;
  longlong lVar10;
  longlong **pplVar11;
  longlong lVar12;
  undefined8 uVar13;
  longlong lVar14;
  int *piVar15;
  longlong lVar16;
  undefined uVar17;
  byte bVar18;
  ushort uVar19;
  longlong **pplVar20;
  longlong lVar21;
  ulonglong uVar22;
  longlong lVar23;
  ulonglong uVar24;
  int iVar25;
  undefined8 unaff_RBX;
  undefined8 *puVar26;
  short *psVar27;
  undefined *puVar28;
  undefined *puVar29;
  ushort *puVar30;
  short *psVar31;
  ushort *puVar32;
  int iVar33;
  uint uVar34;
  longlong *plVar35;
  uint *puVar36;
  uint *puVar37;
  ulonglong uVar38;
  byte *pbVar39;
  byte *pbVar40;
  uint *puVar41;
  ulonglong *puVar42;
  uint uVar43;
  uint *puVar44;
  undefined4 uVar45;
  undefined8 uStackX_8;
  undefined8 uStackX_10;
  undefined8 uStackX_18;
  uint auStackX_20 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  puVar28 = &stack0xffffffffffffffc8 + lVar10;
  puVar1 = (ulonglong *)((longlong)&uStackX_8 + lVar10);
  *(undefined8 *)(&stack0x00000288 + lVar10) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002418 + lVar10) = unaff_RBX;
  *(ulonglong *)(&stack0x000023b8 + lVar10) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined8 *)(&stack0x00000028 + lVar10) = param_2;
  uVar24 = 0;
  *(undefined4 *)(&stack0x0000007c + lVar10) = 0;
  *(undefined8 *)(&stack0x00000090 + lVar10) = 0;
  *(undefined4 *)(&stack0x00000098 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000160 + lVar10) = 0xb74ea0;
  *(undefined (*) [16])(&stack0x00000168 + lVar10) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000178 + lVar10) = 0;
  *(uint *)(&stack0x000001bc + lVar10) = *(uint *)(&stack0x000001bc + lVar10) & 0xfffffff8;
  *(undefined8 *)(&stack0x000001c0 + lVar10) = 0;
  pplVar11 = *(longlong ***)(param_1 + 0x38);
  plVar35 = *pplVar11;
  if (plVar35 == (longlong *)0x0) {
    uVar43 = *(uint *)(&stack0x00000078 + lVar10);
    *(uint *)(&stack0x00000050 + lVar10) = uVar43;
    puVar44 = *(uint **)(&stack0x00000070 + lVar10);
    plVar35 = *(longlong **)(&stack0x00000068 + lVar10);
  }
  else {
    puVar26 = *(undefined8 **)(*(longlong *)(param_1 + 0x30) + 0x80);
    if ((*(int *)(puVar26 + 5) == *(int *)(plVar35 + 1)) &&
       (*plVar35 == (ulonglong)*(uint6 *)((longlong)puVar26 + 0x14) * 0x10000)) {
      pcVar2 = *(code **)*puVar26;
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1000d8;
      sVar7 = (*pcVar2)(puVar26);
      if (*(short *)((longlong)plVar35 + 0xc) != sVar7) goto LAB_;
      if (plVar35[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar10) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar10);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1000fa;
      func_0x(plVar35,puVar26);
    }
    lVar12 = *(longlong *)(param_1 + 0x18);
    pplVar11 = *(longlong ***)(param_1 + 0x38);
    uVar19 = *(ushort *)((longlong)*pplVar11 + 0x62);
    uVar43 = (uint)uVar19;
    *(uint *)(&stack0x00000050 + lVar10) = (uint)uVar19;
    lVar21 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x80);
    uVar9 = *(ushort *)(plVar35 + 7);
    *(longlong **)(&stack0x00000068 + lVar10) = plVar35;
    *(uint *)(&stack0x00000078 + lVar10) = (uint)uVar19;
    *(longlong *)(&stack0x00000080 + lVar10) = lVar12;
    *(undefined8 *)(&stack0x00000088 + lVar10) = 0;
    puVar44 = (uint *)plVar35[0xe];
    *(uint **)(&stack0x00000070 + lVar10) = puVar44;
    if ((uVar9 & 0x400) == 0) {
      if (lVar21 != 0) {
        lVar21 = **(longlong **)(*(longlong *)(lVar21 + 8) + 0x160);
        *(undefined8 *)(&stack0x00000090 + lVar10) = *(undefined8 *)(lVar21 + 0xa8);
        *(undefined4 *)(&stack0x00000098 + lVar10) = *(undefined4 *)(lVar21 + 0xb0);
      }
      uVar34 = *(uint *)(&stack0x0000007c + lVar10);
      uVar24 = (ulonglong)(uVar34 | 0x10);
      *(uint *)(&stack0x0000007c + lVar10) = uVar34 | 0x10;
      if (((*(ushort *)(plVar35 + 7) & 0x400) != 0) && (lVar12 != 0)) {
        *(undefined8 *)(&stack0x000000a0 + lVar10) = 0;
        *(undefined8 *)(&stack0x000000b0 + lVar10) = 0;
        *(undefined8 *)(&stack0x000000a8 + lVar10) = 0;
        if ((uVar34 & 4) == 0) {
          uVar24 = (ulonglong)(uVar34 | 0x12);
          *(uint *)(&stack0x0000007c + lVar10) = uVar34 | 0x12;
        }
      }
    }
    else {
      pplVar20 = pplVar11;
      if (lVar21 != 0) {
        lVar21 = **(longlong **)(*(longlong *)(lVar21 + 8) + 0x160);
        *(undefined8 *)(&stack0x00000090 + lVar10) = *(undefined8 *)(lVar21 + 0xa8);
        *(undefined4 *)(&stack0x00000098 + lVar10) = *(undefined4 *)(lVar21 + 0xb0);
        pplVar20 = *(longlong ***)(param_1 + 0x38);
      }
      uVar34 = *(uint *)(&stack0x0000007c + lVar10);
      uVar24 = (ulonglong)(uVar34 | 0x10);
      *(uint *)(&stack0x0000007c + lVar10) = uVar34 | 0x10;
      if (((*(ushort *)(plVar35 + 7) & 0x400) != 0) && (lVar12 != 0)) {
        *(undefined8 *)(&stack0x000000a0 + lVar10) = 0;
        *(undefined8 *)(&stack0x000000b0 + lVar10) = 0;
        *(undefined8 *)(&stack0x000000a8 + lVar10) = 0;
        if ((uVar34 & 4) == 0) {
          uVar24 = (ulonglong)(uVar34 | 0x12);
          *(uint *)(&stack0x0000007c + lVar10) = uVar34 | 0x12;
          pplVar11 = pplVar20;
        }
      }
    }
    param_2 = *(undefined8 *)(&stack0x00000028 + lVar10);
  }
  puVar36 = (uint *)0x0;
  *(undefined8 *)(&stack0x000000c0 + lVar10) = 0x1fd1f0;
  uVar34 = 0;
  if ((*(short *)((longlong)*pplVar11 + 0x3a) == 0) && (*(int *)(*pplVar11 + 10) == 0)) {
    lVar12 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x80);
    *(longlong *)(&stack0x00000058 + lVar10) = lVar12;
    psVar31 = *(short **)(&stack0x00000028 + lVar10);
    if ((*(byte *)(plVar35 + 6) & 1) != 0) {
      puVar32 = (ushort *)(psVar31 + 1);
      if (*psVar31 == 0) {
        if ((**(byte **)(psVar31 + 4) & 0x10) != 0) {
          uVar34 = (uint)*(ushort *)(*(byte **)(psVar31 + 4) + *(uint *)(psVar31 + 8));
        }
      }
      else {
        uVar34 = (uint)*puVar32;
      }
      if (*(uint *)(plVar35 + 3) <= uVar34) {
        *psVar31 = 0;
        uVar9 = *(ushort *)(*(longlong *)(&stack0x00000068 + lVar10) + 0x62);
        puVar44 = *(uint **)(&stack0x00000070 + lVar10);
        puVar29 = &stack0xffffffffffffffc8 + lVar10;
        puVar37 = puVar36;
        if (uVar9 != 0) {
          do {
            cVar6 = *(char *)(puVar44 + 0x10);
            if (cVar6 == '\x01') {
              if ((*(byte *)((longlong)puVar44 + 6) & 0x10) == 0) {
                uVar43 = *(byte *)((ulonglong)(*(ushort *)(puVar44 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(psVar31 + 8) + 2 +
                                  *(longlong *)(psVar31 + 4)) >>
                         ((byte)(*(ushort *)(puVar44 + 1) - 1) & 7) & 1;
              }
              else {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000220 + lVar10;
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101169;
                func_0x(puVar32,puVar44,1,&stack0x00000148 + lVar10);
                uVar43 = *(uint *)(&stack0x00000148 + lVar10);
              }
              if (uVar43 == 0) goto LAB_;
LAB_:
              lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
              if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
              }
              *(undefined *)(lVar12 + *(longlong *)(puVar44 + 0xc)) = 3;
            }
            else {
              if (cVar6 == '\x02') {
LAB_:
                uVar19 = *(ushort *)(puVar44 + 0xf);
                if ((*(byte *)((longlong)puVar44 + 6) & 0x10) == 0) {
LAB_:
                  *(uint *)(&stack0x00000034 + lVar10) = (uint)uVar19;
                  puVar36 = (uint *)((longlong)(int)*puVar44 + *(longlong *)(psVar31 + 4));
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000144 + lVar10;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1011ef;
                  func_0x(puVar32,puVar44,0,&stack0x00000278 + lVar10);
                  if (*(int *)(&stack0x00000144 + lVar10) != 0) goto LAB_;
                  puVar36 = *(uint **)(puVar44 + 2) + 1;
                  uVar43 = **(uint **)(puVar44 + 2);
                  if ((uVar19 != 0) && (uVar43 != uVar19)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101234;
                    (*_DAT_)(1,0xf7dda8,0xf7c7a8,0x381);
                  }
                  *(uint *)(&stack0x00000034 + lVar10) = uVar43;
                }
                lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
                if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
                }
                *(undefined *)(lVar12 + *(longlong *)(puVar44 + 0xc)) = 0;
              }
              else {
                if (cVar6 == '\x03') {
                  if ((*(byte *)((longlong)puVar44 + 6) & 0x10) == 0) {
                    uVar43 = *(byte *)((ulonglong)(*(ushort *)(puVar44 + 1) - 1 >> 3) +
                                       (ulonglong)*(uint *)(psVar31 + 8) + 2 +
                                      *(longlong *)(psVar31 + 4)) >>
                             ((byte)(*(ushort *)(puVar44 + 1) - 1) & 7) & 1;
                  }
                  else {
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000218 + lVar10;
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100ade;
                    func_0x(puVar32,puVar44,1,&stack0x00000154 + lVar10);
                    uVar43 = *(uint *)(&stack0x00000154 + lVar10);
                  }
                  if (uVar43 != 0) goto LAB_;
                }
                else if (cVar6 != '\x04') {
                  if (cVar6 == '\b') {
                    iVar33 = puVar44[0x10] << 0xc;
                    uVar19 = *(ushort *)(puVar44 + 0xf);
                    if ((*puVar44 & 0xc0000000) == 0x80000000) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100a46;
                      iVar33 = func_0x(puVar32);
                      if (iVar33 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100a61;
                        puVar36 = (uint *)func_0x(psVar31 + 0x15,puVar44,
                                                          &stack0x00000034 + lVar10,
                                                          &stack0x00000214 + lVar10);
                        goto LAB_;
                      }
                      *(undefined4 *)(&stack0x00000034 + lVar10) = 0;
                      puVar36 = (uint *)0x0;
                      uVar19 = *(ushort *)(*(longlong *)(puVar44 + 0x12) + 0x2a);
                    }
                    else {
                      if ((iVar33 < 0) || ((*(byte *)((longlong)puVar44 + 6) & 0x10) != 0)) {
                        *(undefined **)(&stack0xffffffffffffffe8 + lVar10) =
                             &stack0x000000cc + lVar10;
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1003af;
                        func_0x
                                  (puVar32,puVar44,iVar33 < 0,&stack0x000000c8 + lVar10);
                        if ((iVar33 < 0) && (*(int *)(&stack0x000000c8 + lVar10) != 0)) {
                          puVar36 = (uint *)0x0;
                          *(undefined4 *)(&stack0x00000034 + lVar10) = 0;
                          goto LAB_;
                        }
                        iVar33 = *(int *)(&stack0x000000cc + lVar10);
                      }
                      else {
                        *(undefined4 *)(&stack0x000000c8 + lVar10) = 0;
                        iVar33 = 1;
                        *(undefined4 *)(&stack0x000000cc + lVar10) = 1;
                      }
                      if ((iVar33 == 0) && ((*(byte *)((longlong)puVar44 + 6) & 0x10) != 0)) {
                        puVar3 = *(undefined4 **)(puVar44 + 2);
                        *(undefined4 *)(&stack0x00000034 + lVar10) = *puVar3;
                        puVar36 = puVar3 + 1;
                      }
                      else if ((int)*puVar44 < 0) {
                        if (*(int *)(psVar31 + 2) == 0) {
                          *puVar32 = 0;
                          uVar43 = *(uint *)(psVar31 + 8);
                          uVar24 = (ulonglong)uVar43;
                          *(uint *)(psVar31 + 10) = uVar43;
                          pbVar40 = *(byte **)(psVar31 + 4);
                          bVar5 = *pbVar40;
                          if ((bVar5 & 0x10) != 0) {
                            uVar43 = uVar43 + 2 + (*(ushort *)(pbVar40 + uVar24) + 7 >> 3);
                            uVar24 = (ulonglong)uVar43;
                            *(uint *)(psVar31 + 10) = uVar43;
                            bVar5 = *pbVar40;
                          }
                          if ((bVar5 & 0x20) == 0) {
                            *(int *)(psVar31 + 2) = (int)uVar24;
                            psVar31[0xe] = 0;
                            *(uint *)(psVar31 + 0xc) = uVar43;
                          }
                          else {
                            puVar30 = (ushort *)(pbVar40 + uVar24);
                            uVar19 = *puVar30;
                            psVar31[0xe] = uVar19;
                            if (uVar19 == 0) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100501;
                              cVar6 = func_0x(0x14df2b0);
                              if (cVar6 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10050a;
                                lVar12 = func_0x();
                                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100524;
                                  cVar6 = func_0x(0x14df2b0);
                                  if (cVar6 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100540;
                                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100567;
                                    (*_DAT_)(1,0xdd0038,0xeefd08,0x80f);
                                  }
                                }
                              }
                              uVar13 = *(undefined8 *)(psVar31 + 4);
                              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100575;
                              func_0x(uVar13,3);
                              uVar19 = psVar31[0xe];
                              uVar43 = *(uint *)(psVar31 + 10);
                            }
                            uVar43 = uVar43 + (uVar19 + 1) * 2;
                            *(uint *)(psVar31 + 0xc) = uVar43;
                            if (0x1f9e < uVar43) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1005a4;
                              cVar6 = func_0x(0x14df2b0);
                              if (cVar6 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1005ad;
                                lVar12 = func_0x();
                                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1005c7;
                                  cVar6 = func_0x(0x14df2b0);
                                  if (cVar6 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1005e3;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10060a;
                                    (*_DAT_)(1,0xdd0038,0xeefd08,0x816);
                                  }
                                }
                              }
                              uVar13 = *(undefined8 *)(psVar31 + 4);
                              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100618;
                              func_0x(uVar13,4);
                              uVar19 = psVar31[0xe];
                              uVar43 = *(uint *)(psVar31 + 0xc);
                            }
                            uVar24 = (ulonglong)uVar19;
                            uVar19 = puVar30[uVar24];
                            *(uint *)(psVar31 + 2) = uVar19 & 0x7fff;
                            if ((uVar19 & 0x7fff) < uVar43) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100645;
                              cVar6 = func_0x(0x14df2b0);
                              if (cVar6 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10064e;
                                lVar12 = func_0x();
                                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100668;
                                  cVar6 = func_0x(0x14df2b0);
                                  if (cVar6 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100684;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1006ab;
                                    (*_DAT_)(1,0xdd0038,0xeefd08,0x81d);
                                  }
                                }
                              }
                              uVar13 = *(undefined8 *)(psVar31 + 4);
                              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1006b9;
                              func_0x(uVar13,4);
                              uVar24 = (ulonglong)
                                       *(ushort *)(*(longlong *)(&stack0x00000028 + lVar10) + 0x1c);
                            }
                            if ((short)puVar30[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                              do {
                                lVar12 = *(longlong *)(psVar31 + 4);
                                lVar21 = (ulonglong)*(uint *)(psVar31 + 10) + lVar12;
                                if ((int)uVar24 == 1) {
                                  uVar43 = *(uint *)(psVar31 + 0xc);
                                  uVar34 = uVar43;
LAB_:
                                  if ((*(ushort *)(lVar21 + uVar24 * 2) & 0x7fff) < uVar43)
                                  goto LAB_;
                                }
                                else {
                                  uVar43 = *(ushort *)(lVar21 + -2 + uVar24 * 2) & 0x7fff;
                                  uVar34 = *(uint *)(psVar31 + 0xc);
                                  if (uVar34 <= uVar43) goto LAB_;
LAB_:
                                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100725;
                                  func_0x(lVar12,7);
                                  uVar34 = *(uint *)(psVar31 + 0xc);
                                }
                                if ((uVar43 < uVar34) || (*(uint *)(psVar31 + 2) < uVar43))
                                goto LAB_;
                                if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) == 5
                                   ) {
                                  *puVar32 = *puVar32 | 2;
                                  psVar31[0xe] = psVar31[0xe] + -1;
                                  psVar31[0x15] = (short)uVar43;
                                  lVar12 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar31 + 4)
                                  ;
                                  uVar19 = *(ushort *)(lVar12 + 2);
                                  uVar8 = psVar31[0x16] & 0xc7ff;
                                  if ((uVar19 >> 0xe & 1) != 0) {
                                    uVar8 = uVar19 & 0x3800 | uVar8;
                                  }
                                  psVar31[0x16] = uVar8;
                                  psVar31[0x16] = (uVar8 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar8;
                                  goto LAB_;
                                }
                                if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) <
                                    0x400) goto LAB_;
                                *puVar32 = *puVar32 | 1;
                                uVar19 = psVar31[0xe] - 1;
                                psVar31[0xe] = uVar19;
                                if (uVar19 == 0) goto LAB_;
                                uVar24 = (ulonglong)uVar19;
                              } while ((short)puVar30[(ulonglong)(uVar19 - 1) + 1] < 0);
                              pbVar40 = *(byte **)(psVar31 + 4);
                            }
                            else {
LAB_:
                              pbVar40 = *(byte **)(psVar31 + 4);
                            }
                          }
                          if ((*pbVar40 & 0x40) == 0) {
                            *(undefined4 *)(psVar31 + 0x13) = 0;
                          }
                          else {
                            *(int *)(psVar31 + 0x13) = *(int *)(psVar31 + 2);
                            *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + 0xe;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100811;
                            uVar13 = func_0x(puVar32);
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100820;
                            func_0x(uVar13,&stack0x00000228 + lVar10);
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10082c;
                            iVar33 = func_0x(&stack0x00000228 + lVar10);
                            *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar33;
                          }
                          uVar43 = *(uint *)(psVar31 + 2);
                          if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
                             (*(ulonglong *)(psVar31 + 0xf) <
                              (ulonglong)uVar43 + *(longlong *)(psVar31 + 4))) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100860;
                            cVar6 = func_0x(0x14df2b0);
                            if (cVar6 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100869;
                              lVar12 = func_0x();
                              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100883;
                                cVar6 = func_0x(0x14df2b0);
                                if (cVar6 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10089f;
                                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1008c9;
                                  (*_DAT_)(1,0xdd0038,0xeefd08,0x877);
                                }
                              }
                            }
                            uVar13 = *(undefined8 *)(psVar31 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1008d7;
                            func_0x(uVar13,0x12);
                            uVar43 = *(uint *)(psVar31 + 2);
                          }
                          if (0x3f3b < uVar43 - 1) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1008f4;
                            cVar6 = func_0x(0x14df2b0);
                            if (cVar6 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1008fd;
                              lVar12 = func_0x();
                              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100917;
                                cVar6 = func_0x(0x14df2b0);
                                if (cVar6 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100933;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10095d;
                                  (*_DAT_)(1,0xdd0038,0xeefd08,0x87c);
                                }
                              }
                            }
                            uVar13 = *(undefined8 *)(psVar31 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10096b;
                            func_0x(uVar13,5);
                          }
                        }
LAB_:
                        sVar7 = -*(short *)puVar44;
                        if ((*(byte *)((longlong)puVar44 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe8 + lVar10) =
                               &stack0x000000f8 + lVar10;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10099a;
                          func_0x(puVar32,puVar44,0,&stack0x00000210 + lVar10);
                          if (*(int *)(&stack0x000000f8 + lVar10) == 0) {
                            puVar3 = *(undefined4 **)(puVar44 + 2);
                            *(undefined4 *)(&stack0x00000034 + lVar10) = *puVar3;
                            puVar36 = puVar3 + 1;
                            goto LAB_;
                          }
                        }
                        lVar12 = (longlong)sVar7;
                        if ((uint)(ushort)psVar31[0xe] < (uint)(int)sVar7) {
                          *(undefined4 *)(&stack0x00000034 + lVar10) = 0;
                          puVar36 = *(uint **)(psVar31 + 4);
                        }
                        else {
                          lVar21 = *(longlong *)(psVar31 + 4);
                          lVar14 = (ulonglong)*(uint *)(psVar31 + 10) + lVar21;
                          if (sVar7 == 1) {
                            uVar43 = *(uint *)(*(longlong *)(&stack0x00000028 + lVar10) + 0x18);
                            uVar34 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
LAB_:
                            if (uVar34 < uVar43) goto LAB_;
                          }
                          else {
                            uVar43 = *(ushort *)(lVar14 + -2 + lVar12 * 2) & 0x7fff;
                            lVar21 = *(longlong *)(psVar31 + 4);
                            uVar34 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
                            if (*(uint *)(*(longlong *)(&stack0x00000028 + lVar10) + 0x18) <= uVar43
                               ) goto LAB_;
LAB_:
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100a21;
                            func_0x(lVar21,7);
                            lVar21 = *(longlong *)(psVar31 + 4);
                          }
                          *(uint *)(&stack0x00000034 + lVar10) = uVar34 - uVar43;
                          puVar36 = (uint *)((ulonglong)uVar43 + lVar21);
                        }
                      }
                      else if ((*(ushort *)((longlong)puVar44 + 6) & 8) == 0) {
                        if ((*(ushort *)((longlong)puVar44 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe8 + lVar10) =
                               &stack0x00000158 + lVar10;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10042c;
                          func_0x(puVar32,puVar44,0,&stack0x0000020c + lVar10);
                          if (*(int *)(&stack0x00000158 + lVar10) == 0) {
                            puVar36 = *(uint **)(puVar44 + 2) + 1;
                            uVar43 = **(uint **)(puVar44 + 2);
                            if ((uVar19 != 0) && (uVar43 != uVar19)) {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100471;
                              (*_DAT_)(1,0xf7dda8,0xf7c7a8,0x381);
                            }
                            *(uint *)(&stack0x00000034 + lVar10) = uVar43;
                            goto LAB_;
                          }
                        }
                        *(uint *)(&stack0x00000034 + lVar10) = (uint)uVar19;
                        puVar36 = (uint *)((longlong)(int)*puVar44 + *(longlong *)(psVar31 + 4));
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100498;
                        puVar36 = (uint *)func_0x(puVar32,puVar44);
                      }
LAB_:
                      uVar19 = *(ushort *)(*(longlong *)(puVar44 + 0x12) + 0x2a);
                      if (puVar36 != (uint *)0x0) {
                        lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
                        if ((uVar19 & 0x10) != 0) {
                          lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
                        }
                        *(undefined *)(lVar12 + *(longlong *)(puVar44 + 0xc)) = 0;
                        goto LAB_;
                      }
                    }
                    lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
                    if ((uVar19 & 0x10) != 0) {
                      lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
                    }
                    *(undefined *)(lVar12 + *(longlong *)(puVar44 + 0xc)) = 3;
                    goto LAB_;
                  }
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0xb4c518;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100340;
                  (*_DAT_)(1,0xf51370,0xf7dcb0,0x27d);
                  goto LAB_;
                }
                if (*(int *)(psVar31 + 2) == 0) {
                  *puVar32 = 0;
                  uVar43 = *(uint *)(psVar31 + 8);
                  uVar24 = (ulonglong)uVar43;
                  *(uint *)(psVar31 + 10) = uVar43;
                  pbVar40 = *(byte **)(psVar31 + 4);
                  bVar5 = *pbVar40;
                  pbVar39 = pbVar40;
                  if ((bVar5 & 0x10) != 0) {
                    uVar43 = uVar43 + 2 + (*(ushort *)(pbVar40 + uVar24) + 7 >> 3);
                    uVar24 = (ulonglong)uVar43;
                    *(uint *)(psVar31 + 10) = uVar43;
                    bVar5 = *pbVar40;
                    pbVar39 = *(byte **)(psVar31 + 4);
                  }
                  if ((bVar5 & 0x20) == 0) {
                    *(int *)(psVar31 + 2) = (int)uVar24;
                    psVar31[0xe] = 0;
                    *(uint *)(psVar31 + 0xc) = uVar43;
                  }
                  else {
                    puVar30 = (ushort *)(pbVar40 + uVar24);
                    uVar19 = *puVar30;
                    psVar31[0xe] = uVar19;
                    if (uVar19 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100b88;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100b91;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100bab;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100bc7;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100bef;
                            (*_DAT_)(1,0xdd0038,0xeefd08,0x80f);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100bfd;
                      func_0x(uVar13,3);
                      uVar19 = psVar31[0xe];
                      uVar43 = *(uint *)(psVar31 + 10);
                    }
                    uVar43 = uVar43 + (uVar19 + 1) * 2;
                    *(uint *)(psVar31 + 0xc) = uVar43;
                    if (0x1f9e < uVar43) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100c2c;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100c35;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100c4f;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100c6b;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100c93;
                            (*_DAT_)(1,0xdd0038,0xeefd08,0x816);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100ca1;
                      func_0x(uVar13,4);
                      uVar19 = psVar31[0xe];
                      uVar43 = *(uint *)(psVar31 + 0xc);
                    }
                    uVar24 = (ulonglong)uVar19;
                    uVar19 = puVar30[uVar24];
                    *(uint *)(psVar31 + 2) = uVar19 & 0x7fff;
                    if ((uVar19 & 0x7fff) < uVar43) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100cce;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100cd7;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100cf1;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100d0d;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100d35;
                            (*_DAT_)(1,0xdd0038,0xeefd08,0x81d);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100d43;
                      func_0x(uVar13,4);
                      uVar24 = (ulonglong)
                               *(ushort *)(*(longlong *)(&stack0x00000028 + lVar10) + 0x1c);
                    }
                    if ((short)puVar30[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                      do {
                        lVar12 = *(longlong *)(psVar31 + 4);
                        if ((int)uVar24 == 1) {
                          uVar43 = *(uint *)(psVar31 + 0xc);
                          uVar34 = uVar43;
LAB_:
                          if ((*(ushort *)((ulonglong)*(uint *)(psVar31 + 10) + lVar12 + uVar24 * 2)
                              & 0x7fff) < uVar43) goto LAB_;
                        }
                        else {
                          uVar43 = *(ushort *)
                                    ((ulonglong)*(uint *)(psVar31 + 10) + lVar12 + -2 + uVar24 * 2)
                                   & 0x7fff;
                          uVar34 = *(uint *)(psVar31 + 0xc);
                          if (uVar34 <= uVar43) goto LAB_;
LAB_:
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100da5;
                          func_0x(lVar12,7);
                          uVar34 = *(uint *)(psVar31 + 0xc);
                          lVar12 = *(longlong *)(psVar31 + 4);
                        }
                        if ((uVar43 < uVar34) || (*(uint *)(psVar31 + 2) < uVar43))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar43 + lVar12) == 5) {
                          *puVar32 = *puVar32 | 2;
                          psVar31[0xe] = psVar31[0xe] + -1;
                          psVar31[0x15] = (short)uVar43;
                          lVar12 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar31 + 4);
                          uVar19 = *(ushort *)(lVar12 + 2);
                          uVar8 = psVar31[0x16] & 0xc7ff;
                          if ((uVar19 >> 0xe & 1) != 0) {
                            uVar8 = uVar19 & 0x3800 | uVar8;
                          }
                          psVar31[0x16] = uVar8;
                          psVar31[0x16] = (uVar8 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar8;
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar43 + lVar12) < 0x400) goto LAB_;
                        *puVar32 = *puVar32 | 1;
                        uVar19 = psVar31[0xe] - 1;
                        psVar31[0xe] = uVar19;
                        if (uVar19 == 0) goto LAB_;
                        uVar24 = (ulonglong)uVar19;
                      } while ((short)puVar30[(ulonglong)(uVar19 - 1) + 1] < 0);
                      pbVar39 = *(byte **)(psVar31 + 4);
                    }
                    else {
LAB_:
                      pbVar39 = *(byte **)(psVar31 + 4);
                    }
                  }
                  if ((*pbVar39 & 0x40) == 0) {
                    *(undefined4 *)(psVar31 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar31 + 0x13) = *(int *)(psVar31 + 2);
                    *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100e92;
                    uVar13 = func_0x(puVar32);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100ea1;
                    func_0x(uVar13,&stack0x00000230 + lVar10);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100ead;
                    iVar33 = func_0x(&stack0x00000230 + lVar10);
                    *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar33;
                    pbVar39 = *(byte **)(psVar31 + 4);
                  }
                  uVar43 = *(uint *)(psVar31 + 2);
                  if ((*(byte **)(psVar31 + 0xf) != (byte *)0x0) &&
                     (*(byte **)(psVar31 + 0xf) < pbVar39 + uVar43)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100ee4;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100eed;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f07;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f23;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f4b;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x877);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f59;
                    func_0x(uVar13,0x12);
                    uVar43 = *(uint *)(psVar31 + 2);
                  }
                  if (0x3f3b < uVar43 - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f76;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f7f;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f99;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100fb5;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100fdd;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x87c);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100feb;
                    func_0x(uVar13,5);
                  }
                }
LAB_:
                sVar7 = -*(short *)puVar44;
                if ((*(byte *)((longlong)puVar44 + 6) & 0x10) == 0) {
LAB_:
                  lVar12 = (longlong)sVar7;
                  if ((uint)(ushort)psVar31[0xe] < (uint)(int)sVar7) {
                    *(undefined4 *)(&stack0x00000034 + lVar10) = 0;
                    puVar36 = *(uint **)(psVar31 + 4);
                    iVar33 = 0;
                  }
                  else {
                    lVar21 = *(longlong *)(psVar31 + 4);
                    lVar14 = (ulonglong)*(uint *)(psVar31 + 10) + lVar21;
                    if (sVar7 == 1) {
                      uVar24 = (ulonglong)*(uint *)(*(longlong *)(&stack0x00000028 + lVar10) + 0x18)
                      ;
                      uVar43 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
LAB_:
                      if (uVar43 < (uint)uVar24) goto LAB_;
                    }
                    else {
                      uVar34 = *(ushort *)(lVar14 + -2 + lVar12 * 2) & 0x7fff;
                      uVar24 = (ulonglong)uVar34;
                      lVar21 = *(longlong *)(psVar31 + 4);
                      uVar43 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
                      if (*(uint *)(*(longlong *)(&stack0x00000028 + lVar10) + 0x18) <= uVar34)
                      goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1010a1;
                      func_0x(lVar21,7);
                      lVar21 = *(longlong *)(psVar31 + 4);
                    }
                    iVar33 = uVar43 - (int)uVar24;
                    *(int *)(&stack0x00000034 + lVar10) = iVar33;
                    puVar36 = (uint *)(uVar24 + lVar21);
                  }
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000150 + lVar10;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10101a;
                  func_0x(puVar32,puVar44,0,&stack0x0000021c + lVar10);
                  if (*(int *)(&stack0x00000150 + lVar10) != 0) goto LAB_;
                  piVar15 = *(int **)(puVar44 + 2);
                  iVar33 = *piVar15;
                  *(int *)(&stack0x00000034 + lVar10) = iVar33;
                  puVar36 = (uint *)(piVar15 + 1);
                }
                if (((puVar44[0x10] & 0x2000) != 0) && (iVar33 == 0)) {
                  *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
                  puVar36 = (uint *)0xb763dc;
                }
                lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
                if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
                }
                *(undefined *)(lVar12 + *(longlong *)(puVar44 + 0xc)) = 0;
                if ((1 << (**(byte **)(psVar31 + 4) & 0xe) & 0x440U) != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101110;
                  iVar33 = func_0x(puVar44);
                  if (iVar33 != 0) goto LAB_;
                }
                if ((uint)*(ushort *)(puVar44 + 0xf) < *(uint *)(&stack0x00000034 + lVar10)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10113c;
                  (*_DAT_)(6,0x52,0x16,0x91);
                }
              }
LAB_:
              uVar43 = *(uint *)(&stack0x00000034 + lVar10);
              lVar12 = *(longlong *)(puVar44 + 0x12);
              if ((puVar44[0x10] & 0x800) == 0) {
                lVar21 = *(longlong *)(&stack0x00000080 + lVar10);
                if ((*(byte *)(lVar12 + 0x2a) & 0x10) != 0) {
                  lVar21 = *(longlong *)(&stack0x00000088 + lVar10);
                }
                lVar12 = *(longlong *)(puVar44 + 10);
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101291;
                func_0x(lVar21 + lVar12,puVar36);
              }
              else {
                uVar19 = *(ushort *)(lVar12 + 0x2a) & 0x10;
                if (*(int *)(lVar12 + 0x10) == 10) {
                  lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
                  if (uVar19 != 0) {
                    lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
                  }
                  *(uint **)(lVar12 + *(longlong *)(puVar44 + 10)) = puVar36;
                }
                else {
                  lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
                  if (uVar19 != 0) {
                    lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
                  }
                  uVar13 = *(undefined8 *)(*(longlong *)(puVar44 + 10) + lVar12);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1012c0;
                  func_0x(uVar13,puVar36);
                }
              }
              if ((puVar44[0x10] & 0x100) != 0) {
                lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
                if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
                }
                *(ulonglong *)(lVar12 + *(longlong *)(*(longlong *)(puVar44 + 0x12) + 0x18)) =
                     (ulonglong)uVar43;
              }
            }
LAB_:
            uVar43 = (int)puVar37 + 1;
            puVar44 = puVar44 + 0x14;
            puVar29 = &stack0xffffffffffffffc8 + lVar10;
            puVar37 = (uint *)(ulonglong)uVar43;
          } while (uVar43 < uVar9);
        }
        goto LAB_;
      }
      lVar12 = *(longlong *)(&stack0x00000058 + lVar10);
    }
    *(short **)(&stack0x00000168 + lVar10) = psVar31;
    if (*psVar31 == 0) {
      *psVar31 = 0;
      puVar32 = (ushort *)(psVar31 + 1);
      puVar29 = &stack0xffffffffffffffc8 + lVar10;
      if (((&stack0x0000007c)[lVar10] & 0x10) != 0) {
        uVar43 = *(uint *)(&stack0x00000078 + lVar10);
        *(uint *)((longlong)auStackX_20 + lVar10 + 4) = uVar43;
        puVar37 = *(uint **)(&stack0x00000070 + lVar10);
        puVar29 = &stack0xffffffffffffffc8 + lVar10;
        puVar44 = puVar36;
        if (uVar43 != 0) {
          do {
            switch(*(undefined *)(puVar37 + 0x10)) {
            case 0:
              goto code_r0x001014bc;
            case 1:
              *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x0000027c + lVar10;
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1013b9;
              func_0x(puVar32,puVar37,1,&stack0x00000134 + lVar10);
              if (*(int *)(&stack0x00000134 + lVar10) == 0) goto code_r0x001013d1;
            case 0xd:
            case 0x1b:
              puVar44 = (uint *)0x0;
              *(undefined4 *)(&stack0x00000030 + lVar10) = 0;
              break;
            case 2:
code_r0x001013d1:
              uVar9 = *(ushort *)(puVar37 + 0xf);
              if ((*(byte *)((longlong)puVar37 + 6) & 0x10) != 0) {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x0000014c + lVar10;
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101404;
                func_0x(puVar32,puVar37,0,&stack0x00000280 + lVar10);
                if (*(int *)(&stack0x0000014c + lVar10) == 0) {
                  puVar44 = *(uint **)(puVar37 + 2) + 1;
                  uVar43 = **(uint **)(puVar37 + 2);
                  if ((uVar9 != 0) && (uVar43 != uVar9)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10144c;
                    (*_DAT_)(1,0xf7dda8,0xf7c7a8,0x381);
                  }
                  *(uint *)(&stack0x00000030 + lVar10) = uVar43;
                  goto code_r0x0010144f;
                }
              }
              *(uint *)(&stack0x00000030 + lVar10) = (uint)uVar9;
              puVar44 = (uint *)((longlong)(int)*puVar37 + *(longlong *)(psVar31 + 4));
              break;
            case 3:
              *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x000001c8 + lVar10;
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10150c;
              func_0x(puVar32,puVar37,1,&stack0x000000fc + lVar10);
              if (*(int *)(&stack0x000000fc + lVar10) == 0) goto code_r0x0010152a;
              puVar44 = (uint *)0x0;
              *(undefined4 *)(&stack0x00000030 + lVar10) = 0;
              break;
            case 4:
code_r0x0010152a:
              if (*(int *)(psVar31 + 2) == 0) {
                *puVar32 = 0;
                uVar43 = *(uint *)(psVar31 + 8);
                uVar24 = (ulonglong)uVar43;
                *(uint *)(psVar31 + 10) = uVar43;
                pbVar40 = *(byte **)(psVar31 + 4);
                bVar5 = *pbVar40;
                pbVar39 = pbVar40;
                if ((bVar5 & 0x10) != 0) {
                  uVar43 = uVar43 + (*(ushort *)(pbVar40 + uVar24) + 7 >> 3) + 2;
                  uVar24 = (ulonglong)uVar43;
                  *(uint *)(psVar31 + 10) = uVar43;
                  bVar5 = *pbVar40;
                  pbVar39 = *(byte **)(psVar31 + 4);
                }
                if ((bVar5 & 0x20) == 0) {
                  *(int *)(psVar31 + 2) = (int)uVar24;
                  psVar31[0xe] = 0;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                }
                else {
                  puVar30 = (ushort *)(pbVar40 + uVar24);
                  uVar9 = *puVar30;
                  psVar31[0xe] = uVar9;
                  if (uVar9 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101595;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10159e;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1015b8;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1015d4;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1015fc;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x80f);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10160a;
                    func_0x(uVar13,3);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 10);
                  }
                  uVar43 = uVar43 + (uVar9 + 1) * 2;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                  if (0x1f9e < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101639;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101642;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10165c;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101678;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1016a0;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x816);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1016ae;
                    func_0x(uVar13,4);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 0xc);
                  }
                  uVar24 = (ulonglong)uVar9;
                  uVar9 = puVar30[uVar24];
                  *(uint *)(psVar31 + 2) = uVar9 & 0x7fff;
                  if ((uVar9 & 0x7fff) < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1016db;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1016e4;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1016fe;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10171a;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101742;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x81d);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101750;
                    func_0x(uVar13,4);
                    uVar24 = (ulonglong)(ushort)psVar31[0xe];
                  }
                  if ((short)puVar30[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                    do {
                      lVar12 = *(longlong *)(psVar31 + 4);
                      if ((int)uVar24 == 1) {
                        uVar43 = *(uint *)(psVar31 + 0xc);
                        uVar34 = uVar43;
code_r0x0010179b:
                        if ((*(ushort *)((ulonglong)*(uint *)(psVar31 + 10) + lVar12 + uVar24 * 2) &
                            0x7fff) < uVar43) goto code_r0x001017a8;
                      }
                      else {
                        uVar43 = *(ushort *)
                                  ((ulonglong)*(uint *)(psVar31 + 10) + lVar12 + -2 + uVar24 * 2) &
                                 0x7fff;
                        uVar34 = *(uint *)(psVar31 + 0xc);
                        if (uVar34 <= uVar43) goto code_r0x0010179b;
code_r0x001017a8:
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1017b5;
                        func_0x(lVar12,7);
                        uVar34 = *(uint *)(psVar31 + 0xc);
                        lVar12 = *(longlong *)(psVar31 + 4);
                      }
                      if ((uVar43 < uVar34) || (*(uint *)(psVar31 + 2) < uVar43))
                      goto code_r0x001019fd;
                      if (*(ushort *)((ulonglong)uVar43 + lVar12) == 5) {
                        *puVar32 = *puVar32 | 2;
                        psVar31[0xe] = psVar31[0xe] + -1;
                        psVar31[0x15] = (short)uVar43;
                        lVar12 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar31 + 4);
                        uVar9 = *(ushort *)(lVar12 + 2);
                        uVar19 = psVar31[0x16] & 0xc7ff;
                        if ((uVar9 >> 0xe & 1) != 0) {
                          uVar19 = uVar9 & 0x3800 | uVar19;
                        }
                        psVar31[0x16] = uVar19;
                        psVar31[0x16] = (uVar19 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar19;
                        goto code_r0x00101876;
                      }
                      if (*(ushort *)((ulonglong)uVar43 + lVar12) < 0x400) goto code_r0x00101876;
                      *puVar32 = *puVar32 | 1;
                      uVar9 = psVar31[0xe] - 1;
                      psVar31[0xe] = uVar9;
                      if (uVar9 == 0) goto code_r0x00101876;
                      uVar24 = (ulonglong)uVar9;
                    } while ((short)puVar30[(ulonglong)(uVar9 - 1) + 1] < 0);
                    pbVar39 = *(byte **)(psVar31 + 4);
                  }
                  else {
code_r0x00101876:
                    pbVar39 = *(byte **)(psVar31 + 4);
                  }
                }
                if ((*pbVar39 & 0x40) == 0) {
                  *(undefined4 *)(psVar31 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar31 + 0x13) = *(int *)(psVar31 + 2);
                  *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + 0xe;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1018a4;
                  uVar13 = func_0x(puVar32);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1018b3;
                  func_0x(uVar13,&stack0x00000238 + lVar10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1018bf;
                  iVar33 = func_0x(&stack0x00000238 + lVar10);
                  *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar33;
                  pbVar39 = *(byte **)(psVar31 + 4);
                }
                uVar43 = *(uint *)(psVar31 + 2);
                if ((*(byte **)(psVar31 + 0xf) != (byte *)0x0) &&
                   (*(byte **)(psVar31 + 0xf) < pbVar39 + uVar43)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1018f6;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1018ff;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101919;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101935;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10195d;
                        (*_DAT_)(1,0xdd0038,0xeefd08,0x877);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10196b;
                  func_0x(uVar13,0x12);
                  uVar43 = *(uint *)(psVar31 + 2);
                }
                if (0x3f3b < uVar43 - 1) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101988;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101991;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1019ab;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1019c7;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1019ef;
                        (*_DAT_)(1,0xdd0038,0xeefd08,0x87c);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1019fd;
                  func_0x(uVar13,5);
                }
              }
code_r0x001019fd:
              sVar7 = -*(short *)puVar37;
              if ((*(byte *)((longlong)puVar37 + 6) & 0x10) == 0) {
code_r0x00101a47:
                lVar12 = (longlong)sVar7;
                if ((uint)(int)sVar7 <= (uint)(ushort)psVar31[0xe]) {
                  lVar21 = *(longlong *)(psVar31 + 4);
                  lVar14 = (ulonglong)*(uint *)(psVar31 + 10) + lVar21;
                  if (sVar7 == 1) {
                    uVar43 = *(uint *)(psVar31 + 0xc);
                    uVar34 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
code_r0x00101a92:
                    if (uVar34 < uVar43) goto code_r0x00101a96;
                  }
                  else {
                    uVar43 = *(ushort *)(lVar14 + -2 + lVar12 * 2) & 0x7fff;
                    uVar34 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
                    lVar21 = *(longlong *)(psVar31 + 4);
                    if (*(uint *)(psVar31 + 0xc) <= uVar43) goto code_r0x00101a92;
code_r0x00101a96:
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101aa3;
                    func_0x(lVar21,7);
                  }
                  iVar33 = uVar34 - uVar43;
                  *(int *)(&stack0x00000030 + lVar10) = iVar33;
                  puVar44 = (uint *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4));
                  goto code_r0x00101aaf;
                }
                *(undefined4 *)(&stack0x00000030 + lVar10) = 0;
                puVar44 = *(uint **)(psVar31 + 4);
code_r0x00101ac0:
                if ((puVar37[0x10] & 0x2000) != 0) {
                  *(undefined4 *)(&stack0x00000030 + lVar10) = 4;
                  puVar44 = (uint *)0xb763dc;
                }
              }
              else {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000100 + lVar10;
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101a2e;
                func_0x(puVar32,puVar37,0,&stack0x000001cc + lVar10);
                if (*(int *)(&stack0x00000100 + lVar10) != 0) goto code_r0x00101a47;
                piVar15 = *(int **)(puVar37 + 2);
                iVar33 = *piVar15;
                *(int *)(&stack0x00000030 + lVar10) = iVar33;
                puVar44 = (uint *)(piVar15 + 1);
code_r0x00101aaf:
                if (iVar33 == 0) goto code_r0x00101ac0;
              }
              if ((1 << (**(byte **)(psVar31 + 4) & 0xe) & 0x440U) != 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101af9;
                iVar33 = func_0x(puVar37);
                if (iVar33 != 0) goto code_r0x0010144f;
              }
              if ((uint)*(ushort *)(puVar37 + 0xf) < *(uint *)(&stack0x00000030 + lVar10)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101b26;
                (*_DAT_)(6,0x52,0x16,0x91);
              }
code_r0x0010144f:
              uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
              break;
            case 5:
              puVar44 = *(uint **)(psVar31 + 4);
              if (*(int *)(psVar31 + 2) == 0) {
                *puVar32 = 0;
                uVar43 = *(uint *)(psVar31 + 8);
                uVar24 = (ulonglong)uVar43;
                *(uint *)(psVar31 + 10) = uVar43;
                pbVar40 = *(byte **)(psVar31 + 4);
                bVar5 = *pbVar40;
                if ((bVar5 & 0x10) != 0) {
                  uVar43 = uVar43 + 2 + (*(ushort *)(pbVar40 + uVar24) + 7 >> 3);
                  uVar24 = (ulonglong)uVar43;
                  *(uint *)(psVar31 + 10) = uVar43;
                  bVar5 = *pbVar40;
                }
                if ((bVar5 & 0x20) == 0) {
                  *(int *)(psVar31 + 2) = (int)uVar24;
                  psVar31[0xe] = 0;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                }
                else {
                  puVar30 = (ushort *)(pbVar40 + uVar24);
                  uVar9 = *puVar30;
                  psVar31[0xe] = uVar9;
                  if (uVar9 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1022ea;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1022f3;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10230d;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102329;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102353;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x80f);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102361;
                    func_0x(uVar13,3);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 10);
                  }
                  uVar43 = uVar43 + (uVar9 + 1) * 2;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                  if (0x1f9e < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10238d;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102396;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1023b0;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1023cc;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1023f6;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x816);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102404;
                    func_0x(uVar13,4);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 0xc);
                  }
                  uVar9 = puVar30[uVar9];
                  *(uint *)(psVar31 + 2) = uVar9 & 0x7fff;
                  if ((uVar9 & 0x7fff) < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10242f;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102438;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102452;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10246e;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102498;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x81d);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1024a6;
                    func_0x(uVar13,4);
                  }
                  uVar9 = psVar31[0xe];
                  if ((short)puVar30[(ulonglong)(uVar9 - 1) + 1] < 0) {
                    do {
                      lVar12 = *(longlong *)(psVar31 + 4);
                      lVar21 = (ulonglong)*(uint *)(psVar31 + 10) + lVar12;
                      if (uVar9 == 1) {
                        uVar43 = *(uint *)(psVar31 + 0xc);
                        uVar34 = uVar43;
code_r0x001024eb:
                        if ((*(ushort *)(lVar21 + (ulonglong)uVar9 * 2) & 0x7fff) < uVar43)
                        goto code_r0x001024f8;
                      }
                      else {
                        uVar43 = *(ushort *)(lVar21 + -2 + (ulonglong)uVar9 * 2) & 0x7fff;
                        uVar34 = *(uint *)(psVar31 + 0xc);
                        if (uVar34 <= uVar43) goto code_r0x001024eb;
code_r0x001024f8:
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102505;
                        func_0x(lVar12,7);
                        uVar34 = *(uint *)(psVar31 + 0xc);
                      }
                      if ((uVar43 < uVar34) || (*(uint *)(psVar31 + 2) < uVar43))
                      goto code_r0x00102754;
                      if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) == 5) {
                        *puVar32 = *puVar32 | 2;
                        psVar31[0xe] = psVar31[0xe] + -1;
                        psVar31[0x15] = (short)uVar43;
                        lVar12 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar31 + 4);
                        uVar9 = *(ushort *)(lVar12 + 2);
                        uVar19 = psVar31[0x16] & 0xc7ff;
                        if ((uVar9 >> 0xe & 1) != 0) {
                          uVar19 = uVar9 & 0x3800 | uVar19;
                        }
                        psVar31[0x16] = uVar19;
                        psVar31[0x16] = (uVar19 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar19;
                        goto code_r0x001025c8;
                      }
                      if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) < 0x400)
                      goto code_r0x001025c8;
                      *puVar32 = *puVar32 | 1;
                      uVar9 = psVar31[0xe] - 1;
                      psVar31[0xe] = uVar9;
                      if (uVar9 == 0) goto code_r0x001025c8;
                    } while ((short)puVar30[(ulonglong)(uVar9 - 1) + 1] < 0);
                    pbVar40 = *(byte **)(psVar31 + 4);
                    uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
                  }
                  else {
code_r0x001025c8:
                    pbVar40 = *(byte **)(psVar31 + 4);
                    uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
                  }
                }
                if ((*pbVar40 & 0x40) == 0) {
                  *(undefined4 *)(psVar31 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar31 + 0x13) = (int)uVar24;
                  *(int *)(psVar31 + 2) = (int)uVar24 + 0xe;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1025f7;
                  uVar13 = func_0x(puVar32);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102606;
                  func_0x(uVar13,&stack0x00000248 + lVar10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102612;
                  iVar33 = func_0x(&stack0x00000248 + lVar10);
                  *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar33;
                }
                uVar43 = *(uint *)(psVar31 + 2);
                if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar31 + 0xf) < (ulonglong)uVar43 + *(longlong *)(psVar31 + 4)))
                {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102646;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10264f;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102669;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102685;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1026af;
                        (*_DAT_)(1,0xdd0038,0xeefd08,0x877);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1026bd;
                  func_0x(uVar13,0x12);
                  uVar43 = *(uint *)(psVar31 + 2);
                }
                if (0x3f3b < uVar43 - 1) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1026da;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1026e3;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1026fd;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102719;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102743;
                        (*_DAT_)(1,0xdd0038,0xeefd08,0x87c);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102751;
                  func_0x(uVar13,5);
                }
              }
code_r0x00102754:
              uVar43 = *(uint *)(psVar31 + 2);
              if ((uVar43 < 9) &&
                 (((**(byte **)(psVar31 + 4) & 0xe) == 0 ||
                  ((**(byte **)(psVar31 + 4) & 0xe) == 0xc)))) {
                uVar43 = 9;
              }
              *(uint *)(&stack0x00000030 + lVar10) = uVar43;
              uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
              break;
            case 6:
            case 7:
            case 9:
            case 10:
            case 0xb:
            case 0xe:
            case 0xf:
            case 0x19:
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102790;
              func_0x(&stack0x00000160 + lVar10,puVar37,&stack0x00000068 + lVar10);
              goto code_r0x001014bc;
            case 8:
              iVar33 = puVar37[0x10] << 0xc;
              uVar9 = *(ushort *)(puVar37 + 0xf);
              if ((*puVar37 & 0xc0000000) == 0x80000000) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10224b;
                iVar33 = func_0x(puVar32);
                if (iVar33 == 0) {
                  *(undefined4 *)(&stack0x00000030 + lVar10) = 0;
                  puVar44 = (uint *)0x0;
                  uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
                  break;
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102266;
                puVar44 = (uint *)func_0x(psVar31 + 0x15,puVar37,&stack0x00000030 + lVar10,
                                                  &stack0x000001d8 + lVar10);
                goto code_r0x0010144f;
              }
              if ((iVar33 < 0) || ((*(byte *)((longlong)puVar37 + 6) & 0x10) != 0)) {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x000000d4 + lVar10;
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101b9b;
                func_0x(puVar32,puVar37,iVar33 < 0,&stack0x000000d0 + lVar10);
                if ((iVar33 < 0) && (*(int *)(&stack0x000000d0 + lVar10) != 0)) {
                  *(undefined4 *)(&stack0x00000030 + lVar10) = 0;
                  puVar44 = (uint *)0x0;
                  uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
                  break;
                }
                iVar33 = *(int *)(&stack0x000000d4 + lVar10);
              }
              else {
                *(undefined4 *)(&stack0x000000d0 + lVar10) = 0;
                iVar33 = 1;
                *(undefined4 *)(&stack0x000000d4 + lVar10) = 1;
              }
              if ((iVar33 == 0) && ((*(byte *)((longlong)puVar37 + 6) & 0x10) != 0)) {
                puVar3 = *(undefined4 **)(puVar37 + 2);
                *(undefined4 *)(&stack0x00000030 + lVar10) = *puVar3;
                puVar44 = puVar3 + 1;
                uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
              }
              else if ((int)*puVar37 < 0) {
                if (*(int *)(psVar31 + 2) == 0) {
                  *puVar32 = 0;
                  uVar43 = *(uint *)(psVar31 + 8);
                  uVar24 = (ulonglong)uVar43;
                  *(uint *)(psVar31 + 10) = uVar43;
                  pbVar40 = *(byte **)(psVar31 + 4);
                  bVar5 = *pbVar40;
                  if ((bVar5 & 0x10) != 0) {
                    uVar43 = uVar43 + 2 + (*(ushort *)(pbVar40 + uVar24) + 7 >> 3);
                    uVar24 = (ulonglong)uVar43;
                    *(uint *)(psVar31 + 10) = uVar43;
                    bVar5 = *pbVar40;
                  }
                  if ((bVar5 & 0x20) == 0) {
                    *(int *)(psVar31 + 2) = (int)uVar24;
                    psVar31[0xe] = 0;
                    *(uint *)(psVar31 + 0xc) = uVar43;
                  }
                  else {
                    puVar30 = (ushort *)(pbVar40 + uVar24);
                    uVar9 = *puVar30;
                    psVar31[0xe] = uVar9;
                    if (uVar9 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101d12;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101d1b;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101d35;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101d51;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101d79;
                            (*_DAT_)(1,0xdd0038,0xeefd08,0x80f);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101d87;
                      func_0x(uVar13,3);
                      uVar9 = psVar31[0xe];
                      uVar43 = *(uint *)(psVar31 + 10);
                    }
                    uVar43 = uVar43 + (uVar9 + 1) * 2;
                    *(uint *)(psVar31 + 0xc) = uVar43;
                    if (0x1f9e < uVar43) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101db3;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101dbc;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101dd6;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101df2;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101e1a;
                            (*_DAT_)(1,0xdd0038,0xeefd08,0x816);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101e28;
                      func_0x(uVar13,4);
                      uVar9 = psVar31[0xe];
                      uVar43 = *(uint *)(psVar31 + 0xc);
                    }
                    uVar9 = puVar30[uVar9];
                    *(uint *)(psVar31 + 2) = uVar9 & 0x7fff;
                    if ((uVar9 & 0x7fff) < uVar43) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101e53;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101e5c;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101e76;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101e92;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101eba;
                            (*_DAT_)(1,0xdd0038,0xeefd08,0x81d);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101ec8;
                      func_0x(uVar13,4);
                    }
                    uVar9 = psVar31[0xe];
                    if ((short)puVar30[(ulonglong)(uVar9 - 1) + 1] < 0) {
                      do {
                        lVar12 = *(longlong *)(psVar31 + 4);
                        lVar21 = (ulonglong)*(uint *)(psVar31 + 10) + lVar12;
                        if (uVar9 == 1) {
                          uVar43 = *(uint *)(psVar31 + 0xc);
                          uVar34 = uVar43;
code_r0x00101f0b:
                          if ((*(ushort *)(lVar21 + (ulonglong)uVar9 * 2) & 0x7fff) < uVar43)
                          goto code_r0x00101f18;
                        }
                        else {
                          uVar43 = *(ushort *)(lVar21 + -2 + (ulonglong)uVar9 * 2) & 0x7fff;
                          uVar34 = *(uint *)(psVar31 + 0xc);
                          if (uVar34 <= uVar43) goto code_r0x00101f0b;
code_r0x00101f18:
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101f25;
                          func_0x(lVar12,7);
                          uVar34 = *(uint *)(psVar31 + 0xc);
                        }
                        if ((uVar43 < uVar34) || (*(uint *)(psVar31 + 2) < uVar43))
                        goto code_r0x0010216a;
                        if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) == 5) {
                          *puVar32 = *puVar32 | 2;
                          psVar31[0xe] = psVar31[0xe] + -1;
                          psVar31[0x15] = (short)uVar43;
                          lVar12 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar31 + 4);
                          uVar9 = *(ushort *)(lVar12 + 2);
                          uVar19 = psVar31[0x16] & 0xc7ff;
                          if ((uVar9 >> 0xe & 1) != 0) {
                            uVar19 = uVar9 & 0x3800 | uVar19;
                          }
                          psVar31[0x16] = uVar19;
                          psVar31[0x16] = (uVar19 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar19;
                          goto code_r0x00101fe5;
                        }
                        if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) < 0x400)
                        goto code_r0x00101fe5;
                        *puVar32 = *puVar32 | 1;
                        uVar9 = psVar31[0xe] - 1;
                        psVar31[0xe] = uVar9;
                        if (uVar9 == 0) goto code_r0x00101fe5;
                      } while ((short)puVar30[(ulonglong)(uVar9 - 1) + 1] < 0);
                      pbVar40 = *(byte **)(psVar31 + 4);
                    }
                    else {
code_r0x00101fe5:
                      pbVar40 = *(byte **)(psVar31 + 4);
                    }
                  }
                  if ((*pbVar40 & 0x40) == 0) {
                    *(undefined4 *)(psVar31 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar31 + 0x13) = *(int *)(psVar31 + 2);
                    *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102014;
                    uVar13 = func_0x(puVar32);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102023;
                    func_0x(uVar13,&stack0x00000240 + lVar10);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10202f;
                    iVar33 = func_0x(&stack0x00000240 + lVar10);
                    *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar33;
                  }
                  uVar43 = *(uint *)(psVar31 + 2);
                  if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar31 + 0xf) < (ulonglong)uVar43 + *(longlong *)(psVar31 + 4)
                     )) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102063;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10206c;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102086;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1020a2;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1020ca;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x877);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1020d8;
                    func_0x(uVar13,0x12);
                    uVar43 = *(uint *)(psVar31 + 2);
                  }
                  if (0x3f3b < uVar43 - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1020f5;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1020fe;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102118;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102134;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10215c;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x87c);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10216a;
                    func_0x(uVar13,5);
                  }
                }
code_r0x0010216a:
                sVar7 = -*(short *)puVar37;
                if ((*(byte *)((longlong)puVar37 + 6) & 0x10) != 0) {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000108 + lVar10;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10219b;
                  func_0x(puVar32,puVar37,0,&stack0x000001d4 + lVar10);
                  if (*(int *)(&stack0x00000108 + lVar10) == 0) {
                    puVar3 = *(undefined4 **)(puVar37 + 2);
                    *(undefined4 *)(&stack0x00000030 + lVar10) = *puVar3;
                    puVar44 = puVar3 + 1;
                    uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
                    break;
                  }
                }
                lVar12 = (longlong)sVar7;
                if ((uint)(ushort)psVar31[0xe] < (uint)(int)sVar7) {
                  *(undefined4 *)(&stack0x00000030 + lVar10) = 0;
                  puVar44 = *(uint **)(psVar31 + 4);
                  uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
                }
                else {
                  lVar21 = *(longlong *)(psVar31 + 4);
                  lVar14 = (ulonglong)*(uint *)(psVar31 + 10) + lVar21;
                  if (sVar7 == 1) {
                    uVar43 = *(uint *)(psVar31 + 0xc);
                    uVar34 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
code_r0x00102208:
                    if (uVar34 < uVar43) goto code_r0x0010220c;
                  }
                  else {
                    uVar43 = *(ushort *)(lVar14 + -2 + lVar12 * 2) & 0x7fff;
                    uVar34 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
                    lVar21 = *(longlong *)(psVar31 + 4);
                    if (*(uint *)(psVar31 + 0xc) <= uVar43) goto code_r0x00102208;
code_r0x0010220c:
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102219;
                    func_0x(lVar21,7);
                  }
                  *(uint *)(&stack0x00000030 + lVar10) = uVar34 - uVar43;
                  puVar44 = (uint *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4));
                  uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
                }
              }
              else if ((*(ushort *)((longlong)puVar37 + 6) & 8) == 0) {
                if ((*(ushort *)((longlong)puVar37 + 6) & 0x10) != 0) {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000104 + lVar10;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101c27;
                  func_0x(puVar32,puVar37,0,&stack0x000001d0 + lVar10);
                  if (*(int *)(&stack0x00000104 + lVar10) == 0) {
                    puVar44 = *(uint **)(puVar37 + 2) + 1;
                    uVar43 = **(uint **)(puVar37 + 2);
                    if ((uVar9 != 0) && (uVar43 != uVar9)) {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101c6b;
                      (*_DAT_)(1,0xf7dda8,0xf7c7a8,0x381);
                    }
                    *(uint *)(&stack0x00000030 + lVar10) = uVar43;
                    uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
                    break;
                  }
                }
                *(uint *)(&stack0x00000030 + lVar10) = (uint)uVar9;
                puVar44 = (uint *)((longlong)(int)*puVar37 + *(longlong *)(psVar31 + 4));
                uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x101c9e;
                puVar44 = (uint *)func_0x(puVar32,puVar37,&stack0x00000030 + lVar10)
                ;
                uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
              }
              break;
            case 0x10:
              uVar13 = *(undefined8 *)(*(longlong *)(lVar12 + 8) + 0x160);
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1027a7;
              piVar15 = (int *)func_0x(uVar13,0);
              *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
              iVar33 = *(int *)(*(longlong *)(lVar12 + 8) + 0x100);
              if (iVar33 == 2) {
                lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
                if (*(int *)(lVar12 + 4) == 0) {
                  *puVar32 = 0;
                  uVar43 = *(uint *)(lVar12 + 0x10);
                  uVar24 = (ulonglong)uVar43;
                  *(uint *)(lVar12 + 0x14) = uVar43;
                  pbVar40 = *(byte **)(lVar12 + 8);
                  bVar5 = *pbVar40;
                  if ((bVar5 & 0x10) != 0) {
                    uVar43 = uVar43 + 2 + (*(ushort *)(pbVar40 + uVar24) + 7 >> 3);
                    uVar24 = (ulonglong)uVar43;
                    *(uint *)(lVar12 + 0x14) = uVar43;
                    bVar5 = *pbVar40;
                  }
                  if ((bVar5 & 0x20) == 0) {
                    *(int *)(lVar12 + 4) = (int)uVar24;
                    *(undefined2 *)(lVar12 + 0x1c) = 0;
                    *(uint *)(lVar12 + 0x18) = uVar43;
                  }
                  else {
                    puVar30 = (ushort *)(pbVar40 + uVar24);
                    uVar9 = *puVar30;
                    *(ushort *)(lVar12 + 0x1c) = uVar9;
                    if (uVar9 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102835;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10283e;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102857;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102873;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102899;
                            (*_DAT_)(1,0xdd0038,0xeefd08,0x80f);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(*(longlong *)(&stack0x00000028 + lVar10) + 8);
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1028ab;
                      func_0x(uVar13,3);
                      lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
                      uVar9 = *(ushort *)(lVar12 + 0x1c);
                      uVar43 = *(uint *)(lVar12 + 0x14);
                    }
                    uVar43 = uVar43 + (uVar9 + 1) * 2;
                    *(uint *)(lVar12 + 0x18) = uVar43;
                    if (0x1f9e < uVar43) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1028dd;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1028e6;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1028ff;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10291b;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102941;
                            (*_DAT_)(1,0xdd0038,0xeefd08,0x816);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(*(longlong *)(&stack0x00000028 + lVar10) + 8);
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102953;
                      func_0x(uVar13,4);
                      lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
                      uVar9 = *(ushort *)(lVar12 + 0x1c);
                      uVar43 = *(uint *)(lVar12 + 0x18);
                    }
                    uVar9 = puVar30[uVar9];
                    *(uint *)(lVar12 + 4) = uVar9 & 0x7fff;
                    if ((uVar9 & 0x7fff) < uVar43) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102985;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10298e;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1029a7;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1029c3;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1029e9;
                            (*_DAT_)(1,0xdd0038,0xeefd08,0x81d);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(*(longlong *)(&stack0x00000028 + lVar10) + 8);
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1029fb;
                      func_0x(uVar13,4);
                      lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
                    }
                    uVar9 = *(ushort *)(lVar12 + 0x1c);
                    if ((short)puVar30[(ulonglong)(uVar9 - 1) + 1] < 0) {
                      do {
                        lVar21 = *(longlong *)(lVar12 + 8);
                        lVar14 = (ulonglong)*(uint *)(lVar12 + 0x14) + lVar21;
                        if (uVar9 == 1) {
                          uVar43 = *(uint *)(lVar12 + 0x18);
                          uVar34 = uVar43;
code_r0x00102a40:
                          if ((*(ushort *)(lVar14 + (ulonglong)uVar9 * 2) & 0x7fff) < uVar43)
                          goto code_r0x00102a4d;
                        }
                        else {
                          uVar43 = *(ushort *)(lVar14 + -2 + (ulonglong)uVar9 * 2) & 0x7fff;
                          uVar34 = *(uint *)(lVar12 + 0x18);
                          if (uVar34 <= uVar43) goto code_r0x00102a40;
code_r0x00102a4d:
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102a5a;
                          func_0x(lVar21,7);
                          lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
                          uVar34 = *(uint *)(lVar12 + 0x18);
                        }
                        if ((uVar43 < uVar34) || (*(uint *)(lVar12 + 4) < uVar43))
                        goto code_r0x00102cbe;
                        uVar9 = *(ushort *)((ulonglong)uVar43 + *(longlong *)(lVar12 + 8));
                        if (uVar9 == 5) {
                          *puVar32 = *puVar32 | 2;
                          *(short *)(lVar12 + 0x1c) = *(short *)(lVar12 + 0x1c) + -1;
                          *(short *)(lVar12 + 0x2a) = (short)uVar43;
                          lVar21 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(lVar12 + 8);
                          uVar9 = *(ushort *)(lVar21 + 2);
                          uVar19 = *(ushort *)(lVar12 + 0x2c) & 0xc7ff;
                          if ((uVar9 >> 0xe & 1) != 0) {
                            uVar19 = uVar9 & 0x3800 | uVar19;
                          }
                          *(ushort *)(lVar12 + 0x2c) = uVar19;
                          *(ushort *)(lVar12 + 0x2c) =
                               (uVar19 ^ *(ushort *)(lVar21 + 2)) & 0x7ff ^ uVar19;
                          goto code_r0x00102b28;
                        }
                        if (uVar9 < 0x400) goto code_r0x00102b28;
                        *puVar32 = *puVar32 | 1;
                        uVar9 = *(short *)(lVar12 + 0x1c) - 1;
                        *(ushort *)(lVar12 + 0x1c) = uVar9;
                        if (uVar9 == 0) goto code_r0x00102b28;
                      } while ((short)puVar30[(ulonglong)(uVar9 - 1) + 1] < 0);
                      pbVar40 = *(byte **)(lVar12 + 8);
                    }
                    else {
code_r0x00102b28:
                      pbVar40 = *(byte **)(lVar12 + 8);
                    }
                  }
                  if ((*pbVar40 & 0x40) == 0) {
                    *(undefined4 *)(lVar12 + 0x26) = 0;
                  }
                  else {
                    *(int *)(lVar12 + 0x26) = *(int *)(lVar12 + 4);
                    *(int *)(lVar12 + 4) = *(int *)(lVar12 + 4) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102b58;
                    uVar13 = func_0x(puVar32);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102b67;
                    func_0x(uVar13,&stack0x00000250 + lVar10);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102b73;
                    iVar33 = func_0x(&stack0x00000250 + lVar10);
                    lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
                    *(int *)(lVar12 + 4) = *(int *)(lVar12 + 4) + iVar33;
                  }
                  uVar43 = *(uint *)(lVar12 + 4);
                  if ((*(ulonglong *)(lVar12 + 0x1e) == 0) ||
                     ((ulonglong)uVar43 + *(longlong *)(lVar12 + 8) <= *(ulonglong *)(lVar12 + 0x1e)
                     )) {
                    lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102bad;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102bb6;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102bd0;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102bec;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102c12;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x877);
                        }
                      }
                    }
                    lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
                    uVar13 = *(undefined8 *)(lVar12 + 8);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102c24;
                    func_0x(uVar13,0x12);
                    uVar43 = *(uint *)(lVar12 + 4);
                  }
                  if (0x3f3b < uVar43 - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102c47;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102c50;
                      lVar21 = func_0x();
                      if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102c6a;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102c86;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102cb0;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x87c);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(lVar12 + 8);
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102cbe;
                    func_0x(uVar13,5);
                  }
                }
code_r0x00102cbe:
                sVar7 = -*(short *)piVar15;
                if ((*(byte *)((longlong)piVar15 + 6) & 0x10) == 0) {
code_r0x00102d02:
                  lVar21 = (longlong)sVar7;
                  lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
                  if ((uint)*(ushort *)(lVar12 + 0x1c) < (uint)(int)sVar7) {
                    iVar33 = 0;
                    puVar42 = *(ulonglong **)(lVar12 + 8);
                  }
                  else {
                    lVar14 = *(longlong *)(lVar12 + 8);
                    lVar16 = (ulonglong)*(uint *)(lVar12 + 0x14) + lVar14;
                    if (sVar7 == 1) {
                      uVar43 = *(uint *)(lVar12 + 0x18);
                      uVar34 = *(ushort *)(lVar16 + lVar21 * 2) & 0x7fff;
code_r0x00102d54:
                      if (uVar34 < uVar43) goto code_r0x00102d58;
                    }
                    else {
                      uVar43 = *(ushort *)(lVar16 + -2 + lVar21 * 2) & 0x7fff;
                      uVar34 = *(ushort *)(lVar16 + lVar21 * 2) & 0x7fff;
                      lVar14 = *(longlong *)(lVar12 + 8);
                      if (*(uint *)(lVar12 + 0x18) <= uVar43) goto code_r0x00102d54;
code_r0x00102d58:
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102d62;
                      func_0x(lVar14,7);
                      lVar14 = *(longlong *)(lVar12 + 8);
                    }
                    iVar33 = uVar34 - uVar43;
                    puVar42 = (ulonglong *)((ulonglong)uVar43 + lVar14);
                  }
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x0000010c + lVar10;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x102ceb;
                  func_0x(puVar32,piVar15,0,&stack0x000001dc + lVar10);
                  if (*(int *)(&stack0x0000010c + lVar10) != 0) goto code_r0x00102d02;
                  iVar33 = **(int **)(piVar15 + 2);
                  puVar42 = (ulonglong *)(*(int **)(piVar15 + 2) + 1);
                }
                bVar5 = *(byte *)((longlong)puVar37 + 0x45);
                bVar18 = *(byte *)(puVar37 + 0x11);
                switch(*(undefined *)((longlong)puVar37 + 0x3e)) {
                case 0x30:
                  if (iVar33 == 0) {
                    *(undefined *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 1;
                  }
                  else {
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x10) = *(byte *)puVar42;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 1;
                  }
                  break;
                case 0x34:
                  if (iVar33 == 0) {
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
code_r0x00102ee0:
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 2;
                  }
                  else if (iVar33 == 1) {
                    *(ushort *)((longlong)&uStackX_8 + lVar10 + 0x10) = (*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x10) = *(byte *)puVar42 ^ 0x80;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 2;
                  }
                  else {
                    if (iVar33 != 2) goto code_r0x00102ee0;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x11) = *(byte *)puVar42 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         *(byte *)((longlong)puVar42 + 1);
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 2;
                  }
                  break;
                case 0x38:
                case 0x7a:
                  if (iVar33 == 0) {
                    *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                  }
                  else if (iVar33 == 1) {
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = (*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x10) = *(byte *)puVar42 ^ 0x80;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                  }
                  else if (iVar33 == 2) {
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = (*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x11) = *(byte *)puVar42 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         *(byte *)((longlong)puVar42 + 1);
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                  }
                  else if (iVar33 == 3) {
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = (*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x12) = *(byte *)puVar42 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x11) =
                         *(byte *)((longlong)puVar42 + 1);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         *(byte *)((longlong)puVar42 + 2);
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                  }
                  else {
                    if (iVar33 != 4) goto code_r0x00103183;
                    uVar43 = *(uint *)puVar42;
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                         uVar43 << 0x18;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x13) = (byte)uVar43 ^ 0x80;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                  }
                  break;
                case 0x3a:
                  if (iVar33 == 4) {
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = *(uint *)puVar42;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                  }
                  else {
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
code_r0x0010309b:
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0x12) = *(undefined2 *)puVar42;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                  }
                  break;
                case 0x3b:
                  *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
                  if (iVar33 == 1) {
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x13) = *(byte *)puVar42;
code_r0x00103183:
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                  }
                  else {
                    if (iVar33 == 2) goto code_r0x0010309b;
                    if (iVar33 == 3) {
                      *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0x11) = *(undefined2 *)puVar42
                      ;
                      *(byte *)((longlong)&uStackX_8 + lVar10 + 0x13) =
                           *(byte *)((longlong)puVar42 + 2);
                      *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                    }
                    else {
                      if (iVar33 != 4) goto code_r0x00103183;
                      *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = *(uint *)puVar42;
                      *(undefined4 *)(&stack0x0000003c + lVar10) = 4;
                    }
                  }
                  break;
                case 0x3c:
                case 0x3d:
                case 0x7f:
                  switch(iVar33) {
                  case 0:
                    *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 1:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x10) = *(byte *)puVar42 ^ 0x80;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 2:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x11) = *(byte *)puVar42 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         *(byte *)((longlong)puVar42 + 1);
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 3:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x12) = *(byte *)puVar42 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x11) =
                         *(byte *)((longlong)puVar42 + 1);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         *(byte *)((longlong)puVar42 + 2);
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 4:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                    uVar43 = *(uint *)puVar42;
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                         uVar43 << 0x18;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x13) = *(byte *)puVar42 ^ 0x80;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 5:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x14) = *(byte *)puVar42 ^ 0x80;
                    uVar43 = *(uint *)((longlong)puVar42 + 1);
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                         uVar43 << 0x18;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 6:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x15) = *(byte *)puVar42 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x14) =
                         *(byte *)((longlong)puVar42 + 1);
                    uVar43 = *(uint *)((longlong)puVar42 + 2);
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                         uVar43 << 0x18;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 7:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x16) = *(byte *)puVar42 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x15) =
                         *(byte *)((longlong)puVar42 + 1);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x14) =
                         *(byte *)((longlong)puVar42 + 2);
                    uVar43 = *(uint *)((longlong)puVar42 + 3);
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                         uVar43 << 0x18;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 8:
                    uVar24 = *puVar42;
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 0x10) =
                         uVar24 >> 0x38 | (uVar24 & 0xff000000000000) >> 0x28 |
                         (uVar24 & 0xff0000000000) >> 0x18 | (uVar24 & 0xff00000000) >> 8 |
                         (uVar24 & 0xff000000) << 8 | (uVar24 & 0xff0000) << 0x18 |
                         (uVar24 & 0xff00) << 0x28 | uVar24 << 0x38;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x17) = (byte)uVar24 ^ 0x80;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  default:
                    goto code_r0x0010325f;
                  }
                  break;
                case 0x3e:
                  *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
                  switch(iVar33) {
                  case 1:
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x17) = *(byte *)puVar42;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 2:
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0x16) = *(undefined2 *)puVar42;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 3:
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0x15) = *(undefined2 *)puVar42;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x17) =
                         *(byte *)((longlong)puVar42 + 2);
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 4:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x14) = *(uint *)puVar42;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 5:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x13) = *(uint *)puVar42;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x17) =
                         *(byte *)((longlong)puVar42 + 4);
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 6:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x12) = *(uint *)puVar42;
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0x16) =
                         *(undefined2 *)((longlong)puVar42 + 4);
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 7:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x11) = *(uint *)puVar42;
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0x15) =
                         *(undefined2 *)((longlong)puVar42 + 4);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0x17) =
                         *(byte *)((longlong)puVar42 + 6);
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                    break;
                  case 8:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 0x10) = *puVar42;
                  default:
code_r0x0010325f:
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                  }
                  break;
                case 0x6a:
                case 0x6c:
                  *(undefined **)(&stack0xfffffffffffffff0 + lVar10) = &stack0x0000003c + lVar10;
                  *(longlong *)(&stack0xffffffffffffffe8 + lVar10) =
                       (longlong)&uStackX_8 + lVar10 + 0x10;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103288;
                  cVar6 = (*pcRam0000000000a4ba40)(puVar42,iVar33,bVar18 & 0x3f);
                  if (cVar6 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1032a6;
                    (*_DAT_)(6,0x54,0x16,1);
                  }
                  break;
                case 0xad:
                case 0xaf:
                  (&stack0xffffffffffffffe8)[lVar10] = *(undefined *)((longlong)puVar37 + 0x3e);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1030c8;
                  func_0x
                            (puVar42,iVar33,(longlong)&uStackX_8 + lVar10 + 0x10,
                             *(undefined4 *)(&stack0x0000003c + lVar10));
                  break;
                case 0xbd:
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1030fe;
                  func_0x
                            (puVar42,iVar33,(longlong)&uStackX_8 + lVar10 + 0x10,bVar5 & 0x3f);
                  *(undefined4 *)(&stack0x0000003c + lVar10) = 8;
                  break;
                case 0xe7:
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar10) =
                       *(undefined4 *)(&stack0x0000003c + lVar10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1032c9;
                  uVar45 = (*pcRam0000000000a4ba38)
                                     (&stack0x00000290 + lVar10,puVar42,iVar33,
                                      (longlong)&uStackX_8 + lVar10 + 0x10);
                  *(undefined4 *)(&stack0x0000003c + lVar10) = uVar45;
                  break;
                case 0xef:
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar10) =
                       *(undefined4 *)(&stack0x0000003c + lVar10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1030eb;
                  (*pcRam0000000000a4ba48)
                            (&stack0x000003a8 + lVar10,puVar42,iVar33,
                             (longlong)&uStackX_8 + lVar10 + 0x10);
                }
code_r0x0010335b:
                uVar43 = *(uint *)((longlong)auStackX_20 + lVar10 + 4);
              }
              else if (iVar33 == 0) {
                uVar9 = *(ushort *)(puVar37 + 0xf);
                if ((*(byte *)((longlong)piVar15 + 6) & 0x10) == 0) {
code_r0x00103349:
                  puVar26 = (undefined8 *)
                            ((longlong)*piVar15 +
                            *(longlong *)(*(longlong *)(&stack0x00000028 + lVar10) + 8));
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000110 + lVar10;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103306;
                  func_0x(puVar32,piVar15,0,&stack0x000001e0 + lVar10);
                  if (*(int *)(&stack0x00000110 + lVar10) != 0) goto code_r0x00103349;
                  puVar26 = (undefined8 *)(*(uint **)(piVar15 + 2) + 1);
                  if ((uVar9 != 0) && (**(uint **)(piVar15 + 2) != (uint)uVar9)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103347;
                    (*_DAT_)(1,0xf7dda8,0xf7c7a8,0x381);
                  }
                }
                *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 0x10) = *puVar26;
                goto code_r0x0010335b;
              }
              lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
              if ((*(byte *)(*(longlong *)(puVar37 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
              }
              lVar21 = *(longlong *)(puVar37 + 10);
              *(undefined8 *)(lVar21 + lVar12) =
                   *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 0x10);
              uVar34 = puVar37[0x10];
              if ((uVar34 >> 8 & 1) != 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10339d;
                func_0x
                          (&stack0x00000068 + lVar10,puVar37,
                           *(undefined4 *)(&stack0x0000003c + lVar10));
                uVar34 = puVar37[0x10];
              }
              psVar31 = *(short **)(&stack0x00000028 + lVar10);
              if ((uVar34 >> 10 & 1) != 0) {
                lVar14 = *(longlong *)(&stack0x00000080 + lVar10);
                if ((*(byte *)(*(longlong *)(puVar37 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar14 = *(longlong *)(&stack0x00000088 + lVar10);
                }
                uVar17 = 0;
                if ((undefined8 *)(lVar21 + lVar12) == (undefined8 *)0x0) {
                  uVar17 = 3;
                }
                *(undefined *)(lVar14 + *(longlong *)(puVar37 + 0xc)) = uVar17;
              }
              goto code_r0x001014bc;
            }
            uVar34 = puVar37[0x10];
            if ((uVar34 >> 10 & 1) != 0) {
              lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
              if ((*(byte *)(*(longlong *)(puVar37 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
              }
              uVar17 = 0;
              if (puVar44 == (uint *)0x0) {
                uVar17 = 3;
              }
              *(undefined *)(lVar12 + *(longlong *)(puVar37 + 0xc)) = uVar17;
              uVar34 = puVar37[0x10];
            }
            if ((uVar34 >> 9 & 1) != 0) {
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar10) =
                   *(undefined4 *)(&stack0x00000030 + lVar10);
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1014ac;
              func_0x(&stack0x00000068 + lVar10);
            }
code_r0x001014bc:
            uVar34 = (int)puVar36 + 1;
            puVar36 = (uint *)(ulonglong)uVar34;
            puVar37 = puVar37 + 0x14;
            lVar12 = *(longlong *)(&stack0x00000058 + lVar10);
            puVar29 = &stack0xffffffffffffffc8 + lVar10;
          } while (uVar34 < uVar43);
        }
      }
    }
    else if (*(int *)(*(longlong *)(lVar12 + 8) + 0x100) == 2) {
      uVar38 = (ulonglong)*(uint *)((longlong)plVar35 + 0x34);
      *(uint *)((longlong)auStackX_20 + lVar10 + 4) = *(uint *)((longlong)plVar35 + 0x34);
      uVar22 = uVar38 + 0xf;
      if (uVar22 <= uVar38) {
        uVar22 = 0xffffffffffffff0;
      }
      uVar22 = uVar22 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103d46;
      func_0x();
      lVar14 = -uVar22;
      lVar21 = (longlong)&uStackX_8 + lVar14 + lVar10;
      *(longlong *)(&stack0x000000f0 + lVar10) = lVar21;
      puVar29 = &stack0xffffffffffffffc8 + lVar14 + lVar10;
      if (((uVar24 & 0x10) != 0) &&
         (puVar37 = (uint *)0x0, puVar29 = &stack0xffffffffffffffc8 + lVar14 + lVar10,
         puVar36 = puVar37, *(int *)(&stack0x00000050 + lVar10) != 0)) {
        do {
          iVar33 = 1;
          switch(*(undefined *)(puVar44 + 0x10)) {
          case 0:
            goto code_r0x00103f3f;
          case 1:
            psVar31 = *(short **)(&stack0x00000028 + lVar10);
            if (*psVar31 == 0) {
              *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                   &stack0x000001e4 + lVar10;
              *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x103dc8;
              func_0x(psVar31 + 1,puVar44,1);
              uVar43 = *(uint *)(&stack0x00000120 + lVar10);
            }
            else {
              uVar9 = *(ushort *)(puVar44 + 1);
              if ((ushort)psVar31[1] < uVar9) {
                uVar43 = ~(uint)(*(ushort *)((longlong)puVar44 + 6) >> 4) & 1;
              }
              else {
                bVar5 = *(byte *)((longlong)((int)(uVar9 - 1) / 2) + (ulonglong)(ushort)psVar31[0xc]
                                 + *(longlong *)(psVar31 + 4));
                bVar18 = bVar5 >> 4;
                if ((uVar9 & 1) != 0) {
                  bVar18 = bVar5 & 0xf;
                }
                uVar43 = (uint)(bVar18 == 0);
              }
            }
            if (uVar43 == 0) goto code_r0x00103e3d;
            puVar36 = (uint *)0x0;
            *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = 0;
            break;
          case 2:
            psVar31 = *(short **)(&stack0x00000028 + lVar10);
code_r0x00103e3d:
            uVar9 = *(ushort *)(puVar44 + 0xf);
            if ((*(byte *)((longlong)puVar44 + 6) & 0x10) != 0) {
              *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                   &stack0x00000124 + lVar10;
              *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x103e6d;
              func_0x(psVar31 + 1,puVar44,0);
              if (*(int *)(&stack0x00000124 + lVar10) == 0) {
                puVar36 = *(uint **)(puVar44 + 2) + 1;
                uVar43 = **(uint **)(puVar44 + 2);
                if ((uVar9 != 0) && (uVar43 != uVar9)) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x103eb1;
                  (*_DAT_)(1,0xf7dda8,0xf7c7a8);
                }
                *(uint *)((longlong)&uStackX_8 + lVar10 + 0x18) = uVar43;
                break;
              }
            }
            *(uint *)((longlong)&uStackX_8 + lVar10 + 0x18) = (uint)uVar9;
code_r0x00103eb9:
            uVar24 = (ulonglong)(int)*puVar44;
code_r0x00103ebd:
            puVar36 = (uint *)(uVar24 + *(longlong *)(psVar31 + 4));
            break;
          case 3:
            psVar31 = *(short **)(&stack0x00000028 + lVar10);
            if (*psVar31 == 0) {
              *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                   &stack0x000001ec + lVar10;
              *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x103f82;
              func_0x(psVar31 + 1,puVar44,1);
              uVar43 = *(uint *)(&stack0x00000128 + lVar10);
            }
            else {
              uVar9 = *(ushort *)(puVar44 + 1);
              if ((ushort)psVar31[1] < uVar9) {
                uVar43 = ~(uint)(*(ushort *)((longlong)puVar44 + 6) >> 4) & 1;
              }
              else {
                bVar5 = *(byte *)((longlong)((int)(uVar9 - 1) / 2) + (ulonglong)(ushort)psVar31[0xc]
                                 + *(longlong *)(psVar31 + 4));
                bVar18 = bVar5 >> 4;
                if ((uVar9 & 1) != 0) {
                  bVar18 = bVar5 & 0xf;
                }
                uVar43 = (uint)(bVar18 == 0);
              }
            }
            puVar36 = (uint *)0x0;
            if (uVar43 == 0) goto code_r0x00103ffb;
            *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = 0;
            break;
          case 4:
            psVar31 = *(short **)(&stack0x00000028 + lVar10);
code_r0x00103ffb:
            if (*psVar31 == 0) {
              if (*(int *)(psVar31 + 2) == 0) {
                psVar31[1] = 0;
                uVar43 = *(uint *)(psVar31 + 8);
                uVar24 = (ulonglong)uVar43;
                *(uint *)(psVar31 + 10) = uVar43;
                pbVar40 = *(byte **)(psVar31 + 4);
                bVar5 = *pbVar40;
                if ((bVar5 & 0x10) != 0) {
                  uVar43 = uVar43 + (*(ushort *)(pbVar40 + uVar24) + 7 >> 3) + 2;
                  uVar24 = (ulonglong)uVar43;
                  *(uint *)(psVar31 + 10) = uVar43;
                  bVar5 = *pbVar40;
                }
                if ((bVar5 & 0x20) == 0) {
                  *(int *)(psVar31 + 2) = (int)uVar24;
                  psVar31[0xe] = 0;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                }
                else {
                  puVar32 = (ushort *)(pbVar40 + uVar24);
                  uVar9 = *puVar32;
                  psVar31[0xe] = uVar9;
                  if (uVar9 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104070;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104079;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104093;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1040af;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1040d9;
                          (*_DAT_)(1,0xdd0038,0xeefd08);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1040e7;
                    func_0x(uVar13,3);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 10);
                  }
                  uVar43 = uVar43 + (uVar9 + 1) * 2;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                  if (0x1f9e < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104118;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104121;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10413b;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104157;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104181;
                          (*_DAT_)(1,0xdd0038,0xeefd08);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10418f;
                    func_0x(uVar13,4);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 0xc);
                  }
                  uVar24 = (ulonglong)uVar9;
                  uVar9 = puVar32[uVar24];
                  *(uint *)(psVar31 + 2) = uVar9 & 0x7fff;
                  if ((uVar9 & 0x7fff) < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1041be;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1041c7;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1041e1;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1041fd;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104227;
                          (*_DAT_)(1,0xdd0038,0xeefd08);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104235;
                    func_0x(uVar13,4);
                    uVar24 = (ulonglong)(ushort)psVar31[0xe];
                  }
                  if ((short)puVar32[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                    do {
                      lVar12 = *(longlong *)(psVar31 + 4);
                      lVar21 = (ulonglong)*(uint *)(psVar31 + 10) + lVar12;
                      if ((int)uVar24 == 1) {
                        uVar43 = *(uint *)(psVar31 + 0xc);
                        uVar34 = uVar43;
code_r0x0010427e:
                        if ((*(ushort *)(lVar21 + uVar24 * 2) & 0x7fff) < uVar43)
                        goto code_r0x0010428b;
                      }
                      else {
                        uVar43 = *(ushort *)(lVar21 + -2 + uVar24 * 2) & 0x7fff;
                        uVar34 = *(uint *)(psVar31 + 0xc);
                        if (uVar34 <= uVar43) goto code_r0x0010427e;
code_r0x0010428b:
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104298;
                        func_0x(lVar12,7);
                        uVar34 = *(uint *)(psVar31 + 0xc);
                      }
                      if ((uVar43 < uVar34) || (*(uint *)(psVar31 + 2) < uVar43))
                      goto code_r0x001044f8;
                      if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) == 5) {
                        psVar31[1] = psVar31[1] | 2;
                        psVar31[0xe] = psVar31[0xe] + -1;
                        psVar31[0x15] = (short)uVar43;
                        lVar12 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar31 + 4);
                        uVar9 = *(ushort *)(lVar12 + 2);
                        uVar19 = psVar31[0x16] & 0xc7ff;
                        if ((uVar9 >> 0xe & 1) != 0) {
                          uVar19 = uVar9 & 0x3800 | uVar19;
                        }
                        psVar31[0x16] = uVar19;
                        psVar31[0x16] = (uVar19 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar19;
                        goto code_r0x00104367;
                      }
                      if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) < 0x400)
                      goto code_r0x00104367;
                      psVar31[1] = psVar31[1] | 1;
                      uVar9 = psVar31[0xe] - 1;
                      psVar31[0xe] = uVar9;
                      if (uVar9 == 0) goto code_r0x00104367;
                      uVar24 = (ulonglong)uVar9;
                    } while ((short)puVar32[(ulonglong)(uVar9 - 1) + 1] < 0);
                    pbVar40 = *(byte **)(psVar31 + 4);
                  }
                  else {
code_r0x00104367:
                    pbVar40 = *(byte **)(psVar31 + 4);
                  }
                }
                if ((*pbVar40 & 0x40) == 0) {
                  *(undefined4 *)(psVar31 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar31 + 0x13) = *(int *)(psVar31 + 2);
                  *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + 0xe;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10439b;
                  uVar13 = func_0x(psVar31 + 1);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1043aa;
                  func_0x(uVar13,&stack0x00000258 + lVar10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1043b6;
                  iVar33 = func_0x(&stack0x00000258 + lVar10);
                  *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar33;
                }
                uVar43 = *(uint *)(psVar31 + 2);
                if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar31 + 0xf) < (ulonglong)uVar43 + *(longlong *)(psVar31 + 4)))
                {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1043ec;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1043f5;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10440f;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10442b;
                        (*_DAT_)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104455;
                        (*_DAT_)(1,0xdd0038,0xeefd08);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104463;
                  func_0x(uVar13,0x12);
                  uVar43 = *(uint *)(psVar31 + 2);
                }
                if (0x3f3b < uVar43 - 1) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104481;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10448a;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1044a4;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1044c0;
                        (*_DAT_)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1044ea;
                        (*_DAT_)(1,0xdd0038,0xeefd08);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1044f8;
                  func_0x(uVar13,5);
                }
              }
code_r0x001044f8:
              sVar7 = -*(short *)puVar44;
              if ((*(byte *)((longlong)puVar44 + 6) & 0x10) != 0) {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                     &stack0x0000012c + lVar10;
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10452a;
                func_0x(psVar31 + 1,puVar44,0);
                if (*(int *)(&stack0x0000012c + lVar10) == 0) {
                  puVar3 = *(undefined4 **)(puVar44 + 2);
                  *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = *puVar3;
                  puVar36 = puVar3 + 1;
                  goto code_r0x0010464d;
                }
              }
              lVar12 = (longlong)sVar7;
              if ((uint)(ushort)psVar31[0xe] < (uint)(int)sVar7) {
                *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = 0;
code_r0x00104649:
                puVar36 = *(uint **)(psVar31 + 4);
              }
              else {
                lVar21 = *(longlong *)(psVar31 + 4);
                lVar16 = (ulonglong)*(uint *)(psVar31 + 10) + lVar21;
                if (sVar7 == 1) {
                  uVar43 = *(uint *)(psVar31 + 0xc);
                  uVar34 = *(ushort *)(lVar16 + lVar12 * 2) & 0x7fff;
code_r0x001045a0:
                  if (uVar34 < uVar43) goto code_r0x001045a4;
                }
                else {
                  uVar43 = *(ushort *)(lVar16 + -2 + lVar12 * 2) & 0x7fff;
                  lVar21 = *(longlong *)(psVar31 + 4);
                  uVar34 = *(ushort *)(lVar16 + lVar12 * 2) & 0x7fff;
                  if (*(uint *)(psVar31 + 0xc) <= uVar43) goto code_r0x001045a0;
code_r0x001045a4:
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1045ae;
                  func_0x(lVar21,7);
                  lVar21 = *(longlong *)(psVar31 + 4);
                }
                *(uint *)((longlong)&uStackX_8 + lVar10 + 0x18) = uVar34 - uVar43;
                puVar36 = (uint *)((ulonglong)uVar43 + lVar21);
              }
            }
            else {
              *(undefined4 *)(&stack0x000000d8 + lVar10) = 0;
              *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                   &stack0x000000d8 + lVar10;
              *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1045f1;
              puVar36 = (uint *)func_0x(psVar31 + 1,puVar44,1);
              if ((((*psVar31 != 0) &&
                   (plVar35 = *(longlong **)(psVar31 + 8), plVar35 != (longlong *)0x0)) &&
                  (*plVar35 != 0)) &&
                 (((*(byte *)((longlong)puVar44 + 6) & 8) == 0 &&
                  ((*(uint *)(&stack0x000000d8 + lVar10) & 1) == 0)))) {
                *(uint *)((longlong)&uStackX_8 + lVar14 + lVar10 + -8) =
                     *(uint *)(&stack0x000000d8 + lVar10);
                *(longlong *)(&stack0xfffffffffffffff8 + lVar14 + lVar10) =
                     (longlong)&uStackX_8 + lVar10 + 0x18;
                *(int *)(&stack0xfffffffffffffff0 + lVar14 + lVar10) = (int)uVar38;
                *(longlong *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = lVar21;
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104641;
                puVar36 = (uint *)func_0x(plVar35,puVar44,puVar36);
              }
              if (puVar36 == (uint *)0x0) goto code_r0x00104649;
            }
code_r0x0010464d:
            if ((*(int *)((longlong)&uStackX_8 + lVar10 + 0x18) == 0) &&
               ((puVar44[0x10] & 0x2000) != 0)) {
              *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = 4;
              puVar36 = (uint *)0xb763dc;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104674;
            iVar33 = func_0x(psVar31);
            if (iVar33 != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104680;
              iVar33 = func_0x(puVar44);
              if (iVar33 != 0) break;
            }
            if ((uint)*(ushort *)(puVar44 + 0xf) < *(uint *)((longlong)&uStackX_8 + lVar10 + 0x18))
            {
              *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1046ad;
              (*_DAT_)(6,0x52,0x16);
            }
            break;
          case 5:
            psVar31 = *(short **)(&stack0x00000028 + lVar10);
            puVar36 = *(uint **)(psVar31 + 4);
            if (*psVar31 == 0) {
              if (*(int *)(psVar31 + 2) == 0) {
                psVar31[1] = 0;
                uVar43 = *(uint *)(psVar31 + 8);
                uVar24 = (ulonglong)uVar43;
                *(uint *)(psVar31 + 10) = uVar43;
                bVar5 = *(byte *)puVar36;
                if ((bVar5 & 0x10) != 0) {
                  uVar43 = uVar43 + 2 + (*(ushort *)(uVar24 + (longlong)puVar36) + 7 >> 3);
                  uVar24 = (ulonglong)uVar43;
                  *(uint *)(psVar31 + 10) = uVar43;
                  bVar5 = *(byte *)puVar36;
                }
                if ((bVar5 & 0x20) == 0) {
                  *(int *)(psVar31 + 2) = (int)uVar24;
                  psVar31[0xe] = 0;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                  puVar41 = puVar36;
                }
                else {
                  puVar32 = (ushort *)(uVar24 + (longlong)puVar36);
                  uVar9 = *puVar32;
                  psVar31[0xe] = uVar9;
                  if (uVar9 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104f1b;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104f24;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104f3e;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104f5a;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104f84;
                          (*_DAT_)(1,0xdd0038,0xeefd08);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104f92;
                    func_0x(uVar13,3);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 10);
                  }
                  uVar43 = uVar43 + (uVar9 + 1) * 2;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                  if (0x1f9e < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104fc3;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104fcc;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104fe6;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105002;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10502c;
                          (*_DAT_)(1,0xdd0038,0xeefd08);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10503a;
                    func_0x(uVar13,4);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 0xc);
                  }
                  uVar24 = (ulonglong)uVar9;
                  uVar9 = puVar32[uVar24];
                  *(uint *)(psVar31 + 2) = uVar9 & 0x7fff;
                  if ((uVar9 & 0x7fff) < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105069;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105072;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10508c;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1050a8;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1050d2;
                          (*_DAT_)(1,0xdd0038,0xeefd08);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1050e0;
                    func_0x(uVar13,4);
                    uVar24 = (ulonglong)(ushort)psVar31[0xe];
                  }
                  if ((short)puVar32[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                    do {
                      lVar12 = *(longlong *)(psVar31 + 4);
                      lVar21 = (ulonglong)*(uint *)(psVar31 + 10) + lVar12;
                      if ((int)uVar24 == 1) {
                        uVar43 = *(uint *)(psVar31 + 0xc);
                        uVar34 = uVar43;
code_r0x0010512e:
                        if ((*(ushort *)(lVar21 + uVar24 * 2) & 0x7fff) < uVar43)
                        goto code_r0x0010513b;
                      }
                      else {
                        uVar43 = *(ushort *)(lVar21 + -2 + uVar24 * 2) & 0x7fff;
                        uVar34 = *(uint *)(psVar31 + 0xc);
                        if (uVar34 <= uVar43) goto code_r0x0010512e;
code_r0x0010513b:
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105148;
                        func_0x(lVar12,7);
                        uVar34 = *(uint *)(psVar31 + 0xc);
                      }
                      if ((uVar43 < uVar34) || (*(uint *)(psVar31 + 2) < uVar43))
                      goto code_r0x001053ac;
                      if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) == 5) {
                        psVar31[1] = psVar31[1] | 2;
                        psVar31[0xe] = psVar31[0xe] + -1;
                        psVar31[0x15] = (short)uVar43;
                        lVar12 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar31 + 4);
                        uVar9 = *(ushort *)(lVar12 + 2);
                        uVar19 = psVar31[0x16] & 0xc7ff;
                        if ((uVar9 >> 0xe & 1) != 0) {
                          uVar19 = uVar9 & 0x3800 | uVar19;
                        }
                        psVar31[0x16] = uVar19;
                        psVar31[0x16] = (uVar19 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar19;
                        goto code_r0x0010521b;
                      }
                      if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) < 0x400)
                      goto code_r0x0010521b;
                      psVar31[1] = psVar31[1] | 1;
                      uVar9 = psVar31[0xe] - 1;
                      psVar31[0xe] = uVar9;
                      if (uVar9 == 0) goto code_r0x0010521b;
                      uVar24 = (ulonglong)uVar9;
                    } while ((short)puVar32[(ulonglong)(uVar9 - 1) + 1] < 0);
                    uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
                    puVar41 = *(uint **)(psVar31 + 4);
                  }
                  else {
code_r0x0010521b:
                    uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
                    puVar41 = *(uint **)(psVar31 + 4);
                  }
                }
                if ((*(byte *)puVar41 & 0x40) == 0) {
                  *(undefined4 *)(psVar31 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar31 + 0x13) = (int)uVar24;
                  *(int *)(psVar31 + 2) = (int)uVar24 + 0xe;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10524f;
                  uVar13 = func_0x(psVar31 + 1);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10525e;
                  func_0x(uVar13,&stack0x00000268 + lVar10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10526a;
                  iVar33 = func_0x(&stack0x00000268 + lVar10);
                  *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar33;
                }
                uVar43 = *(uint *)(psVar31 + 2);
                if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar31 + 0xf) < (ulonglong)uVar43 + *(longlong *)(psVar31 + 4)))
                {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1052a0;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1052a9;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1052c3;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1052df;
                        (*_DAT_)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105309;
                        (*_DAT_)(1,0xdd0038,0xeefd08);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105317;
                  func_0x(uVar13,0x12);
                  uVar43 = *(uint *)(psVar31 + 2);
                }
                if (0x3f3b < uVar43 - 1) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105335;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10533e;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105358;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105374;
                        (*_DAT_)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10539e;
                        (*_DAT_)(1,0xdd0038,0xeefd08);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1053ac;
                  func_0x(uVar13,5);
                }
              }
code_r0x001053ac:
              uVar43 = *(uint *)(psVar31 + 2);
              if ((uVar43 < 9) &&
                 (((**(byte **)(psVar31 + 4) & 0xe) == 0 ||
                  ((**(byte **)(psVar31 + 4) & 0xe) == 0xc)))) {
                *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = 9;
                break;
              }
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1053dc;
              uVar43 = func_0x(psVar31 + 1);
            }
            *(uint *)((longlong)&uStackX_8 + lVar10 + 0x18) = uVar43;
            break;
          case 6:
          case 7:
          case 9:
          case 10:
          case 0xb:
          case 0xe:
          case 0xf:
          case 0x19:
            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1053f9;
            func_0x(&stack0x00000160 + lVar10,puVar44,&stack0x00000068 + lVar10);
            goto code_r0x00103f3f;
          case 8:
            iVar25 = puVar44[0x10] << 0xc;
            uVar9 = *(ushort *)(puVar44 + 0xf);
            psVar31 = *(short **)(&stack0x00000028 + lVar10);
            if (*psVar31 == 0) {
              if ((*puVar44 & 0xc0000000) == 0x80000000) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104ddc;
                iVar33 = func_0x(psVar31 + 1);
                if (iVar33 == 0) {
                  puVar36 = (uint *)0x0;
                  *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104df7;
                  puVar36 = (uint *)func_0x(psVar31 + 0x15,puVar44,
                                                    (longlong)&uStackX_8 + lVar10 + 0x18);
                }
                break;
              }
              if ((iVar25 < 0) || ((*(byte *)((longlong)puVar44 + 6) & 0x10) != 0)) {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                     &stack0x000000e0 + lVar10;
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10472c;
                func_0x(psVar31 + 1,puVar44,iVar25 < 0);
                if ((iVar25 < 0) && (*(int *)(&stack0x000000dc + lVar10) != 0)) {
                  *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = 0;
                  puVar36 = (uint *)0x0;
                  break;
                }
                iVar33 = *(int *)(&stack0x000000e0 + lVar10);
              }
              else {
                *(undefined4 *)(&stack0x000000dc + lVar10) = 0;
                *(undefined4 *)(&stack0x000000e0 + lVar10) = 1;
              }
              if ((iVar33 == 0) && ((*(byte *)((longlong)puVar44 + 6) & 0x10) != 0)) {
                puVar3 = *(undefined4 **)(puVar44 + 2);
                *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = *puVar3;
                puVar36 = puVar3 + 1;
                break;
              }
              if (-1 < (int)*puVar44) {
                if ((*(ushort *)((longlong)puVar44 + 6) & 8) != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10480d;
                  puVar36 = (uint *)func_0x
                                              (psVar31 + 1,puVar44,
                                               (longlong)&uStackX_8 + lVar10 + 0x18);
                  break;
                }
                if ((*(ushort *)((longlong)puVar44 + 6) & 0x10) != 0) {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                       &stack0x00000130 + lVar10;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1047a9;
                  func_0x(psVar31 + 1,puVar44,0);
                  if (*(int *)(&stack0x00000130 + lVar10) == 0) {
                    puVar36 = *(uint **)(puVar44 + 2) + 1;
                    uVar43 = **(uint **)(puVar44 + 2);
                    if ((uVar9 != 0) && (uVar43 != uVar9)) {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1047ed;
                      (*_DAT_)(1,0xf7dda8,0xf7c7a8);
                    }
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x18) = uVar43;
                    break;
                  }
                }
                *(uint *)((longlong)&uStackX_8 + lVar10 + 0x18) = (uint)uVar9;
                goto code_r0x00103eb9;
              }
              if (*(int *)(psVar31 + 2) == 0) {
                psVar31[1] = 0;
                uVar43 = *(uint *)(psVar31 + 8);
                uVar24 = (ulonglong)uVar43;
                *(uint *)(psVar31 + 10) = uVar43;
                pbVar40 = *(byte **)(psVar31 + 4);
                bVar5 = *pbVar40;
                if ((bVar5 & 0x10) != 0) {
                  uVar43 = uVar43 + 2 + (*(ushort *)(pbVar40 + uVar24) + 7 >> 3);
                  uVar24 = (ulonglong)uVar43;
                  *(uint *)(psVar31 + 10) = uVar43;
                  bVar5 = *pbVar40;
                }
                if ((bVar5 & 0x20) == 0) {
                  *(int *)(psVar31 + 2) = (int)uVar24;
                  psVar31[0xe] = 0;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                }
                else {
                  puVar32 = (ushort *)(pbVar40 + uVar24);
                  uVar9 = *puVar32;
                  psVar31[0xe] = uVar9;
                  if (uVar9 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10487f;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104888;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1048a2;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1048be;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1048e8;
                          (*_DAT_)(1,0xdd0038,0xeefd08);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1048f6;
                    func_0x(uVar13,3);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 10);
                  }
                  uVar43 = uVar43 + (uVar9 + 1) * 2;
                  *(uint *)(psVar31 + 0xc) = uVar43;
                  if (0x1f9e < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104927;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104930;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10494a;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104966;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104990;
                          (*_DAT_)(1,0xdd0038,0xeefd08);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10499e;
                    func_0x(uVar13,4);
                    uVar9 = psVar31[0xe];
                    uVar43 = *(uint *)(psVar31 + 0xc);
                  }
                  uVar24 = (ulonglong)uVar9;
                  uVar9 = puVar32[uVar24];
                  *(uint *)(psVar31 + 2) = uVar9 & 0x7fff;
                  if ((uVar9 & 0x7fff) < uVar43) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1049cd;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1049d6;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1049f0;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104a0c;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104a36;
                          (*_DAT_)(1,0xdd0038,0xeefd08);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104a44;
                    func_0x(uVar13,4);
                    uVar24 = (ulonglong)(ushort)psVar31[0xe];
                  }
                  if ((short)puVar32[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                    do {
                      lVar12 = *(longlong *)(psVar31 + 4);
                      lVar21 = (ulonglong)*(uint *)(psVar31 + 10) + lVar12;
                      if ((int)uVar24 == 1) {
                        uVar43 = *(uint *)(psVar31 + 0xc);
                        uVar34 = uVar43;
code_r0x00104a8e:
                        if ((*(ushort *)(lVar21 + uVar24 * 2) & 0x7fff) < uVar43)
                        goto code_r0x00104a9b;
                      }
                      else {
                        uVar43 = *(ushort *)(lVar21 + -2 + uVar24 * 2) & 0x7fff;
                        uVar34 = *(uint *)(psVar31 + 0xc);
                        if (uVar34 <= uVar43) goto code_r0x00104a8e;
code_r0x00104a9b:
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104aa8;
                        func_0x(lVar12,7);
                        uVar34 = *(uint *)(psVar31 + 0xc);
                      }
                      if ((uVar43 < uVar34) || (*(uint *)(psVar31 + 2) < uVar43))
                      goto code_r0x00104d08;
                      if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) == 5) {
                        psVar31[1] = psVar31[1] | 2;
                        psVar31[0xe] = psVar31[0xe] + -1;
                        psVar31[0x15] = (short)uVar43;
                        lVar12 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar31 + 4);
                        uVar9 = *(ushort *)(lVar12 + 2);
                        uVar19 = psVar31[0x16] & 0xc7ff;
                        if ((uVar9 >> 0xe & 1) != 0) {
                          uVar19 = uVar9 & 0x3800 | uVar19;
                        }
                        psVar31[0x16] = uVar19;
                        psVar31[0x16] = (uVar19 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar19;
                        goto code_r0x00104b77;
                      }
                      if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) < 0x400)
                      goto code_r0x00104b77;
                      psVar31[1] = psVar31[1] | 1;
                      uVar9 = psVar31[0xe] - 1;
                      psVar31[0xe] = uVar9;
                      if (uVar9 == 0) goto code_r0x00104b77;
                      uVar24 = (ulonglong)uVar9;
                    } while ((short)puVar32[(ulonglong)(uVar9 - 1) + 1] < 0);
                    pbVar40 = *(byte **)(psVar31 + 4);
                  }
                  else {
code_r0x00104b77:
                    pbVar40 = *(byte **)(psVar31 + 4);
                  }
                }
                if ((*pbVar40 & 0x40) == 0) {
                  *(undefined4 *)(psVar31 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar31 + 0x13) = *(int *)(psVar31 + 2);
                  *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + 0xe;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104bab;
                  uVar13 = func_0x(psVar31 + 1);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104bba;
                  func_0x(uVar13,&stack0x00000260 + lVar10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104bc6;
                  iVar33 = func_0x(&stack0x00000260 + lVar10);
                  *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar33;
                }
                uVar43 = *(uint *)(psVar31 + 2);
                if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar31 + 0xf) < (ulonglong)uVar43 + *(longlong *)(psVar31 + 4)))
                {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104bfc;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104c05;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104c1f;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104c3b;
                        (*_DAT_)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104c65;
                        (*_DAT_)(1,0xdd0038,0xeefd08);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104c73;
                  func_0x(uVar13,0x12);
                  uVar43 = *(uint *)(psVar31 + 2);
                }
                if (0x3f3b < uVar43 - 1) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104c91;
                  cVar6 = func_0x(0x14df2b0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104c9a;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104cb4;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104cd0;
                        (*_DAT_)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104cfa;
                        (*_DAT_)(1,0xdd0038,0xeefd08);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104d08;
                  func_0x(uVar13,5);
                }
              }
code_r0x00104d08:
              sVar7 = -*(short *)puVar44;
              if ((*(byte *)((longlong)puVar44 + 6) & 0x10) != 0) {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                     &stack0x0000015c + lVar10;
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104d3a;
                func_0x(psVar31 + 1,puVar44,0);
                if (*(int *)(&stack0x0000015c + lVar10) == 0) {
                  puVar3 = *(undefined4 **)(puVar44 + 2);
                  *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = *puVar3;
                  puVar36 = puVar3 + 1;
                  break;
                }
              }
              lVar12 = (longlong)sVar7;
              if ((uint)(ushort)psVar31[0xe] < (uint)(int)sVar7) {
                *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = 0;
                puVar36 = *(uint **)(psVar31 + 4);
                break;
              }
              lVar21 = *(longlong *)(psVar31 + 4);
              lVar16 = (ulonglong)*(uint *)(psVar31 + 10) + lVar21;
              if (sVar7 == 1) {
                uVar43 = *(uint *)(psVar31 + 0xc);
                uVar34 = *(ushort *)(lVar16 + lVar12 * 2) & 0x7fff;
code_r0x00104da5:
                if (uVar34 < uVar43) goto code_r0x00104da9;
              }
              else {
                uVar43 = *(ushort *)(lVar16 + -2 + lVar12 * 2) & 0x7fff;
                uVar34 = *(ushort *)(lVar16 + lVar12 * 2) & 0x7fff;
                lVar21 = *(longlong *)(psVar31 + 4);
                if (*(uint *)(psVar31 + 0xc) <= uVar43) goto code_r0x00104da5;
code_r0x00104da9:
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104db6;
                func_0x(lVar21,7);
              }
              *(uint *)((longlong)&uStackX_8 + lVar10 + 0x18) = uVar34 - uVar43;
              uVar24 = (ulonglong)uVar43;
              goto code_r0x00103ebd;
            }
            *(undefined4 *)(&stack0x000000e4 + lVar10) = 0;
            *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = &stack0x000000e4 + lVar10;
            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104e31;
            puVar36 = (uint *)func_0x(psVar31 + 1,puVar44);
            if ((((*psVar31 != 0) &&
                 (plVar35 = *(longlong **)(psVar31 + 8), plVar35 != (longlong *)0x0)) &&
                (*plVar35 != 0)) &&
               (((*(byte *)((longlong)puVar44 + 6) & 8) == 0 &&
                ((*(uint *)(&stack0x000000e4 + lVar10) & 1) == 0)))) {
              *(uint *)((longlong)&uStackX_8 + lVar14 + lVar10 + -8) =
                   *(uint *)(&stack0x000000e4 + lVar10);
              *(longlong *)(&stack0xfffffffffffffff8 + lVar14 + lVar10) =
                   (longlong)&uStackX_8 + lVar10 + 0x18;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar14 + lVar10) = 0;
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x104e97;
              puVar36 = (uint *)func_0x(plVar35,puVar44,puVar36);
            }
            break;
          case 0xd:
          case 0x1b:
            *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18) = 0;
            puVar36 = (uint *)0x0;
            break;
          case 0x10:
            uVar13 = *(undefined8 *)(*(longlong *)(lVar12 + 8) + 0x160);
            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105417;
            piVar15 = (int *)func_0x(uVar13,0);
            *(undefined4 *)(&stack0x00000044 + lVar10) = 0;
            *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
            iVar33 = *(int *)(*(longlong *)(lVar12 + 8) + 0x100);
            if (iVar33 == 2) {
              psVar31 = *(short **)(&stack0x00000028 + lVar10);
              if (*psVar31 == 0) {
                puVar32 = (ushort *)(psVar31 + 1);
                if (*(int *)(psVar31 + 2) == 0) {
                  *puVar32 = 0;
                  uVar43 = *(uint *)(psVar31 + 8);
                  uVar24 = (ulonglong)uVar43;
                  *(uint *)(psVar31 + 10) = uVar43;
                  pbVar40 = *(byte **)(psVar31 + 4);
                  bVar5 = *pbVar40;
                  if ((bVar5 & 0x10) != 0) {
                    uVar43 = uVar43 + 2 + (*(ushort *)(pbVar40 + uVar24) + 7 >> 3);
                    uVar24 = (ulonglong)uVar43;
                    *(uint *)(psVar31 + 10) = uVar43;
                    bVar5 = *pbVar40;
                  }
                  psVar27 = psVar31;
                  if ((bVar5 & 0x20) == 0) {
                    *(int *)(psVar31 + 2) = (int)uVar24;
                    psVar31[0xe] = 0;
                    *(uint *)(psVar31 + 0xc) = uVar43;
                  }
                  else {
                    puVar30 = (ushort *)(pbVar40 + uVar24);
                    uVar9 = *puVar30;
                    psVar31[0xe] = uVar9;
                    if (uVar9 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1054b1;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1054ba;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1054d4;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1054f0;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10551a;
                            (*_DAT_)(1,0xdd0038,0xeefd08);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105528;
                      func_0x(uVar13,3);
                      uVar9 = psVar31[0xe];
                      uVar43 = *(uint *)(psVar31 + 10);
                    }
                    uVar43 = uVar43 + (uVar9 + 1) * 2;
                    *(uint *)(psVar31 + 0xc) = uVar43;
                    if (0x1f9e < uVar43) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105557;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105560;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10557a;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105596;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1055c0;
                            (*_DAT_)(1,0xdd0038,0xeefd08);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1055ce;
                      func_0x(uVar13,4);
                      uVar9 = psVar31[0xe];
                      uVar43 = *(uint *)(psVar31 + 0xc);
                    }
                    uVar24 = (ulonglong)uVar9;
                    uVar9 = puVar30[uVar24];
                    *(uint *)(psVar31 + 2) = uVar9 & 0x7fff;
                    if ((uVar9 & 0x7fff) < uVar43) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1055fb;
                      cVar6 = func_0x(0x14df2b0);
                      if (cVar6 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105604;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10561e;
                          cVar6 = func_0x(0x14df2b0);
                          if (cVar6 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10563a;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105664;
                            (*_DAT_)(1,0xdd0038,0xeefd08);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105672;
                      func_0x(uVar13,4);
                      uVar24 = (ulonglong)(ushort)psVar31[0xe];
                    }
                    if ((short)puVar30[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                      do {
                        lVar12 = *(longlong *)(psVar31 + 4);
                        lVar21 = (ulonglong)*(uint *)(psVar31 + 10) + lVar12;
                        if ((int)uVar24 == 1) {
                          uVar43 = *(uint *)(psVar31 + 0xc);
                          uVar34 = uVar43;
code_r0x001056bf:
                          if ((*(ushort *)(lVar21 + uVar24 * 2) & 0x7fff) < uVar43)
                          goto code_r0x001056cc;
                        }
                        else {
                          uVar43 = *(ushort *)(lVar21 + -2 + uVar24 * 2) & 0x7fff;
                          uVar34 = *(uint *)(*(longlong *)(&stack0x00000028 + lVar10) + 0x18);
                          if (uVar34 <= uVar43) goto code_r0x001056bf;
code_r0x001056cc:
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1056d9;
                          func_0x(lVar12,7);
                          uVar34 = *(uint *)(*(longlong *)(&stack0x00000028 + lVar10) + 0x18);
                        }
                        if ((uVar43 < uVar34) || (*(uint *)(psVar31 + 2) < uVar43))
                        goto code_r0x0010592e;
                        if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) == 5) {
                          *puVar32 = *puVar32 | 2;
                          psVar31[0xe] = psVar31[0xe] + -1;
                          psVar31[0x15] = (short)uVar43;
                          lVar12 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar31 + 4);
                          uVar9 = *(ushort *)(lVar12 + 2);
                          uVar19 = psVar31[0x16] & 0xc7ff;
                          if ((uVar9 >> 0xe & 1) != 0) {
                            uVar19 = uVar9 & 0x3800 | uVar19;
                          }
                          psVar31[0x16] = uVar19;
                          psVar31[0x16] = (uVar19 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar19;
code_r0x0010579f:
                          psVar27 = *(short **)(&stack0x00000028 + lVar10);
                          goto code_r0x001057a3;
                        }
                        if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4)) < 0x400)
                        goto code_r0x0010579f;
                        *puVar32 = *puVar32 | 1;
                        uVar9 = psVar31[0xe] - 1;
                        psVar31[0xe] = uVar9;
                        if (uVar9 == 0) goto code_r0x0010579f;
                        uVar24 = (ulonglong)uVar9;
                      } while ((short)puVar30[(ulonglong)(uVar9 - 1) + 1] < 0);
                      pbVar40 = *(byte **)(psVar31 + 4);
                      psVar27 = *(short **)(&stack0x00000028 + lVar10);
                    }
                    else {
code_r0x001057a3:
                      pbVar40 = *(byte **)(psVar31 + 4);
                    }
                  }
                  if ((*pbVar40 & 0x40) == 0) {
                    *(undefined4 *)(psVar31 + 0x13) = 0;
                    uVar43 = *(uint *)(psVar27 + 2);
                  }
                  else {
                    *(int *)(psVar31 + 0x13) = *(int *)(psVar31 + 2);
                    *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1057d1;
                    uVar13 = func_0x(puVar32);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1057e0;
                    func_0x(uVar13,&stack0x00000270 + lVar10);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1057ec;
                    iVar33 = func_0x(&stack0x00000270 + lVar10);
                    *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar33;
                    uVar43 = *(uint *)(psVar31 + 2);
                  }
                  if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar31 + 0xf) < (ulonglong)uVar43 + *(longlong *)(psVar31 + 4)
                     )) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105823;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10582c;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105846;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105862;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10588c;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x877);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10589a;
                    func_0x(uVar13,0x12);
                    uVar43 = *(uint *)(psVar27 + 2);
                  }
                  if (0x3f3b < uVar43 - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1058b7;
                    cVar6 = func_0x(0x14df2b0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1058c0;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1058da;
                        cVar6 = func_0x(0x14df2b0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1058f6;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105920;
                          (*_DAT_)(1,0xdd0038,0xeefd08,0x87c);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar31 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10592e;
                    func_0x(uVar13,5);
                  }
                }
code_r0x0010592e:
                sVar7 = -*(short *)piVar15;
                if ((*(byte *)((longlong)piVar15 + 6) & 0x10) != 0) {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                       &stack0x00000138 + lVar10;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10595d;
                  func_0x(puVar32,piVar15,0,&stack0x00000200 + lVar10);
                  if (*(int *)(&stack0x00000138 + lVar10) == 0) {
                    piVar15 = *(int **)(piVar15 + 2);
                    iVar33 = *piVar15;
                    *(int *)(&stack0x00000044 + lVar10) = iVar33;
                    puVar42 = (ulonglong *)(piVar15 + 1);
                    goto code_r0x00105a7d;
                  }
                }
                lVar12 = (longlong)sVar7;
                if ((uint)(ushort)psVar31[0xe] < (uint)(int)sVar7) {
                  iVar33 = 0;
                  *(undefined4 *)(&stack0x00000044 + lVar10) = 0;
                  puVar42 = *(ulonglong **)(psVar31 + 4);
                }
                else {
                  lVar21 = *(longlong *)(psVar31 + 4);
                  lVar16 = (ulonglong)*(uint *)(psVar31 + 10) + lVar21;
                  if (sVar7 == 1) {
                    uVar43 = *(uint *)(psVar31 + 0xc);
                    uVar34 = *(ushort *)(lVar16 + lVar12 * 2) & 0x7fff;
code_r0x001059c7:
                    if (uVar34 < uVar43) goto code_r0x001059cb;
                  }
                  else {
                    uVar43 = *(ushort *)(lVar16 + -2 + lVar12 * 2) & 0x7fff;
                    uVar34 = *(ushort *)(lVar16 + lVar12 * 2) & 0x7fff;
                    lVar21 = *(longlong *)(*(longlong *)(&stack0x00000028 + lVar10) + 8);
                    if (*(uint *)(*(longlong *)(&stack0x00000028 + lVar10) + 0x18) <= uVar43)
                    goto code_r0x001059c7;
code_r0x001059cb:
                    *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1059d8;
                    func_0x(lVar21,7);
                  }
                  iVar33 = uVar34 - uVar43;
                  *(int *)(&stack0x00000044 + lVar10) = iVar33;
                  puVar42 = (ulonglong *)((ulonglong)uVar43 + *(longlong *)(psVar31 + 4));
                }
              }
              else {
                *(undefined4 *)(&stack0x000000e8 + lVar10) = 0;
                *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                     &stack0x000000e8 + lVar10;
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105a20;
                puVar42 = (ulonglong *)
                          func_0x(psVar31 + 1,piVar15,1,&stack0x00000044 + lVar10);
                if ((((*psVar31 != 0) &&
                     (plVar35 = *(longlong **)(psVar31 + 8), plVar35 != (longlong *)0x0)) &&
                    (*plVar35 != 0)) &&
                   (((*(byte *)((longlong)piVar15 + 6) & 8) == 0 &&
                    ((*(uint *)(&stack0x000000e8 + lVar10) & 1) == 0)))) {
                  *(uint *)((longlong)&uStackX_8 + lVar14 + lVar10 + -8) =
                       *(uint *)(&stack0x000000e8 + lVar10);
                  *(undefined **)(&stack0xfffffffffffffff8 + lVar14 + lVar10) =
                       &stack0x00000044 + lVar10;
                  *(int *)(&stack0xfffffffffffffff0 + lVar14 + lVar10) = (int)uVar38;
                  *(longlong *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = lVar21;
                  uVar45 = *(undefined4 *)(&stack0x00000044 + lVar10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105a6e;
                  puVar42 = (ulonglong *)func_0x(plVar35,piVar15,puVar42,uVar45);
                }
                if (puVar42 == (ulonglong *)0x0) {
                  puVar42 = *(ulonglong **)(psVar31 + 4);
                }
                iVar33 = *(int *)(&stack0x00000044 + lVar10);
              }
code_r0x00105a7d:
              bVar5 = *(byte *)(puVar44 + 0x11);
              switch(*(undefined *)((longlong)puVar44 + 0x3e)) {
              case 0x30:
                if (iVar33 == 0) {
                  *(undefined *)puVar1 = 0;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 1;
                }
                else {
                  *(byte *)puVar1 = *(byte *)puVar42;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 1;
                }
                break;
              case 0x34:
                if (iVar33 == 0) {
                  *(undefined2 *)puVar1 = 0;
code_r0x00105be9:
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 2;
                }
                else if (iVar33 == 1) {
                  *(ushort *)puVar1 = (*(byte *)puVar42 >> 7) - 1;
                  *(byte *)puVar1 = *(byte *)puVar42 ^ 0x80;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 2;
                }
                else {
                  if (iVar33 != 2) goto code_r0x00105be9;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)puVar1 = *(byte *)((longlong)puVar42 + 1);
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 2;
                }
                break;
              case 0x38:
              case 0x7a:
                if (iVar33 == 0) {
                  *(undefined4 *)puVar1 = 0;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                }
                else if (iVar33 == 1) {
                  *(uint *)puVar1 = (*(byte *)puVar42 >> 7) - 1;
                  *(byte *)puVar1 = *(byte *)puVar42 ^ 0x80;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                }
                else if (iVar33 == 2) {
                  *(uint *)puVar1 = (*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)puVar1 = *(byte *)((longlong)puVar42 + 1);
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                }
                else if (iVar33 == 3) {
                  *(uint *)puVar1 = (*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 2) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)((longlong)puVar42 + 1);
                  *(byte *)puVar1 = *(byte *)((longlong)puVar42 + 2);
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                }
                else {
                  if (iVar33 != 4) goto code_r0x00105e91;
                  uVar43 = *(uint *)puVar42;
                  *(uint *)puVar1 =
                       uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                       uVar43 << 0x18;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 3) = (byte)uVar43 ^ 0x80;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                }
                break;
              case 0x3a:
                if (iVar33 == 4) {
                  *(uint *)puVar1 = *(uint *)puVar42;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                }
                else {
                  *(undefined2 *)puVar1 = 0;
code_r0x00105da8:
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 2) = *(undefined2 *)puVar42;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                }
                break;
              case 0x3b:
                *(undefined4 *)puVar1 = 0;
                if (iVar33 == 1) {
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 3) = *(byte *)puVar42;
code_r0x00105e91:
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                }
                else {
                  if (iVar33 == 2) goto code_r0x00105da8;
                  if (iVar33 == 3) {
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 1) = *(undefined2 *)puVar42;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 3) = *(byte *)((longlong)puVar42 + 2);
                    *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                  }
                  else {
                    if (iVar33 != 4) goto code_r0x00105e91;
                    *(uint *)puVar1 = *(uint *)puVar42;
                    *(undefined4 *)(&stack0x00000048 + lVar10) = 4;
                  }
                }
                break;
              case 0x3c:
              case 0x3d:
              case 0x7f:
                switch(iVar33) {
                case 0:
                  *puVar1 = 0;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 1:
                  *puVar1 = (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)puVar1 = *(byte *)puVar42 ^ 0x80;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 2:
                  *puVar1 = (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)puVar1 = *(byte *)((longlong)puVar42 + 1);
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 3:
                  *puVar1 = (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 2) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)((longlong)puVar42 + 1);
                  *(byte *)puVar1 = *(byte *)((longlong)puVar42 + 2);
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 4:
                  *puVar1 = (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  uVar43 = *(uint *)puVar42;
                  *(uint *)puVar1 =
                       uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                       uVar43 << 0x18;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 3) = *(byte *)puVar42 ^ 0x80;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 5:
                  *puVar1 = (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 4) = *(byte *)puVar42 ^ 0x80;
                  uVar43 = *(uint *)((longlong)puVar42 + 1);
                  *(uint *)puVar1 =
                       uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                       uVar43 << 0x18;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 6:
                  *puVar1 = (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 5) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 4) = *(byte *)((longlong)puVar42 + 1);
                  uVar43 = *(uint *)((longlong)puVar42 + 2);
                  *(uint *)puVar1 =
                       uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                       uVar43 << 0x18;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 7:
                  *puVar1 = (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 6) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 5) = *(byte *)((longlong)puVar42 + 1);
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 4) = *(byte *)((longlong)puVar42 + 2);
                  uVar43 = *(uint *)((longlong)puVar42 + 3);
                  *(uint *)puVar1 =
                       uVar43 >> 0x18 | (uVar43 & 0xff0000) >> 8 | (uVar43 & 0xff00) << 8 |
                       uVar43 << 0x18;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 8:
                  uVar24 = *puVar42;
                  *puVar1 = uVar24 >> 0x38 | (uVar24 & 0xff000000000000) >> 0x28 |
                            (uVar24 & 0xff0000000000) >> 0x18 | (uVar24 & 0xff00000000) >> 8 |
                            (uVar24 & 0xff000000) << 8 | (uVar24 & 0xff0000) << 0x18 |
                            (uVar24 & 0xff00) << 0x28 | uVar24 << 0x38;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = (byte)uVar24 ^ 0x80;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                default:
                  goto code_r0x00105f71;
                }
                break;
              case 0x3e:
                *puVar1 = 0;
                switch(iVar33) {
                case 1:
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = *(byte *)puVar42;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 2:
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 6) = *(undefined2 *)puVar42;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 3:
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 5) = *(undefined2 *)puVar42;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = *(byte *)((longlong)puVar42 + 2);
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 4:
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 4) = *(uint *)puVar42;
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 5:
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 3) = *(uint *)puVar42;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = *(byte *)((longlong)puVar42 + 4);
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 6:
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 2) = *(uint *)puVar42;
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 6) =
                       *(undefined2 *)((longlong)puVar42 + 4);
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 7:
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 1) = *(uint *)puVar42;
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 5) =
                       *(undefined2 *)((longlong)puVar42 + 4);
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = *(byte *)((longlong)puVar42 + 6);
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                  break;
                case 8:
                  *puVar1 = *puVar42;
                default:
code_r0x00105f71:
                  *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                }
                break;
              case 0x6a:
              case 0x6c:
                *(undefined **)(&stack0xfffffffffffffff0 + lVar14 + lVar10) =
                     &stack0x00000048 + lVar10;
                *(ulonglong **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = puVar1;
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105f9a;
                cVar6 = (*pcRam0000000000a4ba40)(puVar42,iVar33,bVar5 & 0x3f);
                if (cVar6 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105fb8;
                  (*_DAT_)(6,0x54,0x16);
                }
                break;
              case 0xad:
              case 0xaf:
                (&stack0xffffffffffffffe8)[lVar14 + lVar10] =
                     *(undefined *)((longlong)puVar44 + 0x3e);
                uVar45 = *(undefined4 *)(&stack0x00000044 + lVar10);
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105dd6;
                func_0x(puVar42,uVar45,puVar1);
                break;
              case 0xbd:
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105e0c;
                func_0x(puVar42,iVar33,puVar1);
                *(undefined4 *)(&stack0x00000048 + lVar10) = 8;
                break;
              case 0xe7:
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                     *(undefined4 *)(&stack0x00000048 + lVar10);
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105fdb;
                uVar45 = (*pcRam0000000000a4ba38)(&stack0x00000370 + lVar10,puVar42,iVar33);
                *(undefined4 *)(&stack0x00000048 + lVar10) = uVar45;
                break;
              case 0xef:
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                     *(undefined4 *)(&stack0x00000048 + lVar10);
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x105df9;
                (*pcRam0000000000a4ba48)(&stack0x00000338 + lVar10,puVar42,iVar33);
              }
            }
            else {
              if (iVar33 != 0) goto code_r0x00106076;
              uVar9 = *(ushort *)(puVar44 + 0xf);
              lVar12 = *(longlong *)(&stack0x00000028 + lVar10);
              if ((*(byte *)((longlong)piVar15 + 6) & 0x10) == 0) {
code_r0x00106065:
                *(uint *)(&stack0x00000044 + lVar10) = (uint)uVar9;
                puVar42 = (ulonglong *)((longlong)*piVar15 + *(longlong *)(lVar12 + 8));
              }
              else {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                     &stack0x0000013c + lVar10;
                *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x10601d;
                func_0x(lVar12 + 2,piVar15,0);
                if (*(int *)(&stack0x0000013c + lVar10) != 0) goto code_r0x00106065;
                puVar42 = (ulonglong *)(*(uint **)(piVar15 + 2) + 1);
                uVar43 = **(uint **)(piVar15 + 2);
                if ((uVar9 != 0) && (uVar43 != uVar9)) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x106060;
                  (*_DAT_)(1,0xf7dda8,0xf7c7a8);
                }
                *(uint *)(&stack0x00000044 + lVar10) = uVar43;
              }
              *puVar1 = *puVar42;
            }
code_r0x00106076:
            lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
            if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
            }
            lVar16 = *(longlong *)(puVar44 + 10);
            *(ulonglong *)(lVar16 + lVar12) = *puVar1;
            uVar43 = puVar44[0x10];
            if ((uVar43 >> 8 & 1) != 0) {
              uVar45 = *(undefined4 *)(&stack0x00000048 + lVar10);
              *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1060b5;
              func_0x(&stack0x00000068 + lVar10,puVar44,uVar45);
              uVar43 = puVar44[0x10];
            }
            uVar38 = (ulonglong)*(uint *)((longlong)auStackX_20 + lVar10 + 4);
            lVar21 = *(longlong *)(&stack0x000000f0 + lVar10);
            if ((uVar43 >> 10 & 1) == 0) {
              lVar12 = *(longlong *)(&stack0x00000058 + lVar10);
            }
            else {
              lVar23 = *(longlong *)(&stack0x00000080 + lVar10);
              if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar23 = *(longlong *)(&stack0x00000088 + lVar10);
              }
              uVar17 = 0;
              if ((ulonglong *)(lVar16 + lVar12) == (ulonglong *)0x0) {
                uVar17 = 3;
              }
              *(undefined *)(lVar23 + *(longlong *)(puVar44 + 0xc)) = uVar17;
              lVar12 = *(longlong *)(&stack0x00000058 + lVar10);
            }
            goto code_r0x00103f3f;
          }
          uVar43 = puVar44[0x10];
          if ((uVar43 >> 10 & 1) != 0) {
            lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
            if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
            }
            uVar17 = 0;
            if (puVar36 == (uint *)0x0) {
              uVar17 = 3;
            }
            *(undefined *)(lVar12 + *(longlong *)(puVar44 + 0xc)) = uVar17;
            uVar43 = puVar44[0x10];
          }
          if ((uVar43 >> 9 & 1) != 0) {
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14 + lVar10) =
                 *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x18);
            *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x103f1d;
            func_0x(&stack0x00000068 + lVar10);
          }
          lVar12 = *(longlong *)(&stack0x00000058 + lVar10);
          lVar21 = *(longlong *)(&stack0x000000f0 + lVar10);
          uVar38 = (ulonglong)*(uint *)((longlong)auStackX_20 + lVar10 + 4);
code_r0x00103f3f:
          uVar43 = (int)puVar37 + 1;
          puVar37 = (uint *)(ulonglong)uVar43;
          puVar44 = puVar44 + 0x14;
          puVar29 = &stack0xffffffffffffffc8 + lVar14 + lVar10;
        } while (uVar43 < *(uint *)(&stack0x00000050 + lVar10));
      }
    }
    else {
      if (*psVar31 == -1) {
        *psVar31 = 1;
        uVar24 = (ulonglong)*(uint *)(&stack0x0000007c + lVar10);
        uVar43 = *(uint *)(&stack0x00000078 + lVar10);
        puVar44 = *(uint **)(&stack0x00000070 + lVar10);
      }
      puVar32 = (ushort *)(psVar31 + 1);
      puVar29 = &stack0xffffffffffffffc8 + lVar10;
      if (((uVar24 & 0x10) != 0) &&
         (puVar29 = &stack0xffffffffffffffc8 + lVar10, puVar37 = puVar36, uVar43 != 0)) {
        do {
          puVar41 = (uint *)0x0;
          switch(*(undefined *)(puVar44 + 0x10)) {
          case 0:
            goto LAB_;
          case 1:
            uVar9 = *(ushort *)(puVar44 + 1);
            if (*puVar32 < uVar9) {
              uVar9 = ~(*(ushort *)((longlong)puVar44 + 6) >> 4) & 1;
            }
            else {
              bVar5 = *(byte *)((longlong)((int)(uVar9 - 1) / 2) + (ulonglong)(ushort)psVar31[0xc] +
                               *(longlong *)(psVar31 + 4));
              bVar18 = bVar5 >> 4;
              if ((uVar9 & 1) != 0) {
                bVar18 = bVar5 & 0xf;
              }
              uVar9 = (ushort)(bVar18 == 0);
            }
            if (uVar9 == 0) goto code_r0x001034d0;
          case 0xd:
          case 0x1b:
            *(undefined4 *)(&stack0x0000004c + lVar10) = 0;
            puVar36 = puVar41;
            break;
          case 2:
code_r0x001034d0:
            puVar36 = puVar41;
            break;
          case 3:
            uVar9 = *(ushort *)(puVar44 + 1);
            if (*puVar32 < uVar9) {
              uVar9 = ~(*(ushort *)((longlong)puVar44 + 6) >> 4) & 1;
            }
            else {
              bVar5 = *(byte *)((longlong)((int)(uVar9 - 1) / 2) + (ulonglong)(ushort)psVar31[0xc] +
                               *(longlong *)(psVar31 + 4));
              bVar18 = bVar5 >> 4;
              if ((uVar9 & 1) != 0) {
                bVar18 = bVar5 & 0xf;
              }
              uVar9 = (ushort)(bVar18 == 0);
            }
            if (uVar9 == 0) goto code_r0x0010353c;
            *(undefined4 *)(&stack0x0000004c + lVar10) = 0;
            puVar36 = puVar41;
            break;
          case 4:
code_r0x0010353c:
            *(undefined4 *)(&stack0x00000114 + lVar10) = 0;
            *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000114 + lVar10;
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103561;
            puVar36 = (uint *)func_0x(puVar32,puVar44,1,&stack0x0000004c + lVar10);
            if (puVar36 == (uint *)0x0) {
              puVar36 = *(uint **)(psVar31 + 4);
            }
            if ((*(int *)(&stack0x0000004c + lVar10) == 0) && ((puVar44[0x10] & 0x2000) != 0)) {
              *(undefined4 *)(&stack0x0000004c + lVar10) = 4;
              puVar36 = (uint *)0xb763dc;
            }
            if (((**(byte **)(psVar31 + 4) & 0x1c) - 0x18 & 0xfffffffb) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1035a9;
              iVar33 = func_0x(puVar44);
              if (iVar33 != 0) break;
            }
            if ((uint)*(ushort *)(puVar44 + 0xf) < *(uint *)(&stack0x0000004c + lVar10)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1035ce;
              (*_DAT_)(6,0x52,0x16,0x91);
            }
            break;
          case 5:
            puVar36 = *(uint **)(psVar31 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103691;
            uVar45 = func_0x(puVar32);
            *(undefined4 *)(&stack0x0000004c + lVar10) = uVar45;
            break;
          case 6:
          case 7:
          case 9:
          case 10:
          case 0xb:
          case 0xe:
          case 0xf:
          case 0x19:
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1036ac;
            func_0x(&stack0x00000160 + lVar10);
            goto LAB_;
          case 8:
            uVar34 = puVar44[0x10];
            *(undefined4 *)(&stack0x00000118 + lVar10) = 0;
            *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000118 + lVar10;
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10367d;
            puVar36 = (uint *)func_0x(puVar32,puVar44,(uVar34 & 0x80000) >> 0x13,
                                              &stack0x0000004c + lVar10);
            break;
          case 0x10:
            uVar13 = *(undefined8 *)
                      (*(longlong *)(*(longlong *)(&stack0x00000058 + lVar10) + 8) + 0x160);
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1036c7;
            uVar13 = func_0x(uVar13,0);
            *(undefined4 *)(&stack0x00000038 + lVar10) = 0;
            *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
            iVar33 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000058 + lVar10) + 8) + 0x100);
            if (iVar33 == 2) {
              *(undefined4 *)(&stack0x0000011c + lVar10) = 0;
              *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x0000011c + lVar10;
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103712;
              puVar42 = (ulonglong *)func_0x(puVar32,uVar13,1,&stack0x00000038 + lVar10);
              if (puVar42 == (ulonglong *)0x0) {
                puVar42 = *(ulonglong **)(psVar31 + 4);
              }
              bVar5 = *(byte *)((longlong)puVar44 + 0x45);
              switch(*(undefined *)((longlong)puVar44 + 0x3e)) {
              case 0x30:
                if (*(int *)(&stack0x00000038 + lVar10) == 0) {
                  *(undefined *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 1;
                }
                else {
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)puVar42;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 1;
                }
                break;
              case 0x34:
                iVar33 = *(int *)(&stack0x00000038 + lVar10);
                if (iVar33 == 0) {
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
code_r0x00103889:
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 2;
                }
                else if (iVar33 == 1) {
                  *(ushort *)((longlong)&uStackX_8 + lVar10 + 8) = (*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)puVar42 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 2;
                }
                else {
                  if (iVar33 != 2) goto code_r0x00103889;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar42 + 1);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 2;
                }
                break;
              case 0x38:
              case 0x7a:
                iVar33 = *(int *)(&stack0x00000038 + lVar10);
                if (iVar33 == 0) {
                  *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                }
                else if (iVar33 == 1) {
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = (*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)puVar42 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                }
                else if (iVar33 == 2) {
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = (*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar42 + 1);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                }
                else if (iVar33 == 3) {
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = (*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 10) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)((longlong)puVar42 + 1);
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar42 + 2);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                }
                else {
                  if (iVar33 != 4) goto code_r0x00103b3e;
                  uVar34 = *(uint *)puVar42;
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                       uVar34 >> 0x18 | (uVar34 & 0xff0000) >> 8 | (uVar34 & 0xff00) << 8 |
                       uVar34 << 0x18;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xb) = (byte)uVar34 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                }
                break;
              case 0x3a:
                if (*(int *)(&stack0x00000038 + lVar10) == 4) {
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = *(uint *)puVar42;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                }
                else {
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
code_r0x00103a4e:
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 10) = *(undefined2 *)puVar42;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                }
                break;
              case 0x3b:
                *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                iVar33 = *(int *)(&stack0x00000038 + lVar10);
                if (iVar33 == 1) {
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xb) = *(byte *)puVar42;
code_r0x00103b3e:
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                }
                else {
                  if (iVar33 == 2) goto code_r0x00103a4e;
                  if (iVar33 == 3) {
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 9) = *(undefined2 *)puVar42;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xb) =
                         *(byte *)((longlong)puVar42 + 2);
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                  else {
                    if (iVar33 != 4) goto code_r0x00103b3e;
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = *(uint *)puVar42;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                }
                break;
              case 0x3c:
              case 0x3d:
              case 0x7f:
                switch(*(undefined4 *)(&stack0x00000038 + lVar10)) {
                case 0:
                  *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 1:
                  *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                       (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)puVar42 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 2:
                  *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                       (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar42 + 1);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 3:
                  *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                       (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 10) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)((longlong)puVar42 + 1);
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar42 + 2);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 4:
                  *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                       (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  uVar34 = *(uint *)puVar42;
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                       uVar34 >> 0x18 | (uVar34 & 0xff0000) >> 8 | (uVar34 & 0xff00) << 8 |
                       uVar34 << 0x18;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xb) = *(byte *)puVar42 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 5:
                  *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                       (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xc) = *(byte *)puVar42 ^ 0x80;
                  uVar34 = *(uint *)((longlong)puVar42 + 1);
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                       uVar34 >> 0x18 | (uVar34 & 0xff0000) >> 8 | (uVar34 & 0xff00) << 8 |
                       uVar34 << 0x18;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 6:
                  *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                       (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xd) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xc) = *(byte *)((longlong)puVar42 + 1);
                  uVar34 = *(uint *)((longlong)puVar42 + 2);
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                       uVar34 >> 0x18 | (uVar34 & 0xff0000) >> 8 | (uVar34 & 0xff00) << 8 |
                       uVar34 << 0x18;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 7:
                  *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                       (ulonglong)(*(byte *)puVar42 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xe) = *(byte *)puVar42 ^ 0x80;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xd) = *(byte *)((longlong)puVar42 + 1);
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xc) = *(byte *)((longlong)puVar42 + 2);
                  uVar34 = *(uint *)((longlong)puVar42 + 3);
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                       uVar34 >> 0x18 | (uVar34 & 0xff0000) >> 8 | (uVar34 & 0xff00) << 8 |
                       uVar34 << 0x18;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 8:
                  uVar24 = *puVar42;
                  *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                       uVar24 >> 0x38 | (uVar24 & 0xff000000000000) >> 0x28 |
                       (uVar24 & 0xff0000000000) >> 0x18 | (uVar24 & 0xff00000000) >> 8 |
                       (uVar24 & 0xff000000) << 8 | (uVar24 & 0xff0000) << 0x18 |
                       (uVar24 & 0xff00) << 0x28 | uVar24 << 0x38;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) = (byte)uVar24 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                default:
                  goto code_r0x00103c1e;
                }
                break;
              case 0x3e:
                *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                switch(*(undefined4 *)(&stack0x00000038 + lVar10)) {
                case 1:
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) = *(byte *)puVar42;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 2:
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0xe) = *(undefined2 *)puVar42;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 3:
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0xd) = *(undefined2 *)puVar42;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) = *(byte *)((longlong)puVar42 + 2);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 4:
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 0xc) = *(uint *)puVar42;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 5:
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 0xb) = *(uint *)puVar42;
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) = *(byte *)((longlong)puVar42 + 4);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 6:
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 10) = *(uint *)puVar42;
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0xe) =
                       *(undefined2 *)((longlong)puVar42 + 4);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 7:
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 9) = *(uint *)puVar42;
                  *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0xd) =
                       *(undefined2 *)((longlong)puVar42 + 4);
                  *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) = *(byte *)((longlong)puVar42 + 6);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 8:
                  *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) = *puVar42;
                default:
code_r0x00103c1e:
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                }
                break;
              case 0x6a:
              case 0x6c:
                *(undefined **)(&stack0xfffffffffffffff0 + lVar10) = &stack0x00000040 + lVar10;
                *(longlong *)(&stack0xffffffffffffffe8 + lVar10) = (longlong)&uStackX_8 + lVar10 + 8
                ;
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103c45;
                cVar6 = (*pcRam0000000000a4ba40)(puVar42);
                if (cVar6 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103c5f;
                  (*_DAT_)(6,0x54,0x16,1);
                }
                break;
              case 0xad:
              case 0xaf:
                (&stack0xffffffffffffffe8)[lVar10] = *(undefined *)((longlong)puVar44 + 0x3e);
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103a7c;
                func_0x
                          (puVar42,*(undefined4 *)(&stack0x00000038 + lVar10),
                           (longlong)&uStackX_8 + lVar10 + 8,
                           *(undefined4 *)(&stack0x00000040 + lVar10));
                break;
              case 0xbd:
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103ab4;
                func_0x
                          (puVar42,*(undefined4 *)(&stack0x00000038 + lVar10),
                           (longlong)&uStackX_8 + lVar10 + 8,bVar5 & 0x3f);
                *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                break;
              case 0xe7:
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar10) =
                     *(undefined4 *)(&stack0x00000040 + lVar10);
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103c80;
                uVar45 = (*pcRam0000000000a4ba38)
                                   (&stack0x00000300 + lVar10,puVar42,
                                    *(undefined4 *)(&stack0x00000038 + lVar10),
                                    (longlong)&uStackX_8 + lVar10 + 8);
                *(undefined4 *)(&stack0x00000040 + lVar10) = uVar45;
                break;
              case 0xef:
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar10) =
                     *(undefined4 *)(&stack0x00000040 + lVar10);
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103aa0;
                (*pcRam0000000000a4ba48)
                          (&stack0x000002c8 + lVar10,puVar42,
                           *(undefined4 *)(&stack0x00000038 + lVar10),
                           (longlong)&uStackX_8 + lVar10 + 8);
              }
            }
            else if (iVar33 == 0) {
              *(longlong *)((longlong)&uStackX_8 + lVar10 + 8) = _DAT_;
            }
            lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
            if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
            }
            lVar21 = *(longlong *)(puVar44 + 10);
            *(undefined8 *)(lVar21 + lVar12) = *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 8);
            uVar34 = puVar44[0x10];
            if ((uVar34 >> 8 & 1) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103cd4;
              func_0x(&stack0x00000068 + lVar10);
              uVar34 = puVar44[0x10];
            }
            if ((uVar34 >> 10 & 1) == 0) {
              psVar31 = *(short **)(&stack0x00000028 + lVar10);
            }
            else {
              lVar14 = *(longlong *)(&stack0x00000080 + lVar10);
              if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar14 = *(longlong *)(&stack0x00000088 + lVar10);
              }
              uVar17 = 0;
              if ((undefined8 *)(lVar21 + lVar12) == (undefined8 *)0x0) {
                uVar17 = 3;
              }
              *(undefined *)(lVar14 + *(longlong *)(puVar44 + 0xc)) = uVar17;
              psVar31 = *(short **)(&stack0x00000028 + lVar10);
            }
            goto LAB_;
          }
          uVar34 = puVar44[0x10];
          if ((uVar34 >> 10 & 1) != 0) {
            lVar12 = *(longlong *)(&stack0x00000080 + lVar10);
            if ((*(byte *)(*(longlong *)(puVar44 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
            }
            uVar17 = 0;
            if (puVar36 == (uint *)0x0) {
              uVar17 = 3;
            }
            *(undefined *)(lVar12 + *(longlong *)(puVar44 + 0xc)) = uVar17;
            uVar34 = puVar44[0x10];
          }
          if ((uVar34 >> 9 & 1) != 0) {
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar10) =
                 *(undefined4 *)(&stack0x0000004c + lVar10);
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x103628;
            func_0x(&stack0x00000068 + lVar10);
          }
LAB_:
          uVar34 = (int)puVar37 + 1;
          puVar44 = puVar44 + 0x14;
          puVar29 = &stack0xffffffffffffffc8 + lVar10;
          puVar37 = (uint *)(ulonglong)uVar34;
        } while (uVar34 < uVar43);
      }
    }
  }
  else {
    lVar12 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x80);
    *(longlong *)(&stack0x00000188 + lVar10) = *(longlong *)(param_1 + 0x30) + 0x128;
    *(undefined **)(&stack0x00000190 + lVar10) = &stack0x00000160 + lVar10;
    *(undefined4 *)(&stack0x00000198 + lVar10) = 1;
    *(undefined4 *)(&stack0x0000019c + lVar10) = 1;
    *(longlong *)(&stack0x000001a0 + lVar10) = lVar12;
    lVar12 = *(longlong *)(lVar12 + 8);
    lVar21 = lVar12;
    if (*(longlong *)(lVar12 + 0x478) != 0) {
      lVar21 = *(longlong *)(lVar12 + 0x478);
    }
    if ((*(short *)(lVar21 + 0x440) == 0) && (*(short *)(lVar12 + 0xce) == 0)) {
      uVar43 = *(uint *)(&stack0x000001bc + lVar10);
    }
    else {
      uVar43 = *(uint *)(&stack0x000001bc + lVar10) | 1;
      *(uint *)(&stack0x000001bc + lVar10) = uVar43;
    }
    lVar12 = *(longlong *)(&stack0x000001a0 + lVar10);
    if ((0x1f7c < *(uint *)(*(longlong *)(lVar12 + 8) + 0xb0)) &&
       ((*(byte *)(*(longlong *)(lVar12 + 8) + 0x106) & 4) == 0)) {
      uVar43 = uVar43 | 2;
      *(uint *)(&stack0x000001bc + lVar10) = uVar43;
    }
    *(undefined4 *)(&stack0x000001a8 + lVar10) =
         *(undefined4 *)(*(longlong *)(lVar12 + 0x20) + 0x664);
    *(ulonglong *)(&stack0x000001b0 + lVar10) = (ulonglong)*(uint6 *)(lVar12 + 0x14) << 0x10;
    *(undefined2 *)(&stack0x000001b8 + lVar10) =
         *(undefined2 *)(*(longlong *)(lVar12 + 0x20) + 0x660);
    *(uint *)(&stack0x000001bc + lVar10) = uVar43 | 4;
    *(undefined8 *)(&stack0x000003e8 + lVar10) = 0;
    *(undefined8 *)(&stack0x000003f0 + lVar10) = 0;
    *(undefined4 *)(&stack0x000003f8 + lVar10) = 0;
    *(undefined8 *)(&stack0x00000400 + lVar10) = 0;
    *(undefined4 *)(&stack0x00000408 + lVar10) = 0;
    *(undefined8 *)(&stack0x00000168 + lVar10) = param_2;
    *(undefined8 *)(&stack0x00000170 + lVar10) = 0;
    lVar12 = *(longlong *)(&stack0x00000068 + lVar10);
    if ((*(byte *)(lVar12 + 0x38) & 8) != 0) {
      puVar36 = (uint *)(&stack0x000003e8 + lVar10);
      uVar9 = *(ushort *)(lVar12 + 0x62);
      *(uint *)(&stack0x000003e8 + lVar10) = (uint)uVar9;
      *(undefined4 *)(&stack0x00000408 + lVar10) = 0x1f9e;
      *(undefined **)(&stack0x00000400 + lVar10) = &stack0x0000040c + lVar10;
      uVar22 = (ulonglong)(uint)uVar9 * 0x40;
      uVar24 = uVar22 + 0xf;
      if (uVar24 <= uVar22) {
        uVar24 = 0xffffffffffffff0;
      }
      uVar24 = uVar24 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1062a4;
      func_0x();
      lVar14 = -uVar24;
      puVar28 = &stack0xffffffffffffffc8 + lVar14 + lVar10;
      lVar21 = (longlong)&uStackX_8 + lVar14 + lVar10;
      *(longlong *)(&stack0x000003f0 + lVar10) = lVar21;
      *(undefined8 *)((longlong)&uStack_40 + lVar14 + lVar10) = 0x1062ba;
      func_0x(lVar21,0);
    }
    *(undefined8 *)(puVar28 + 0x28) = 0;
    *(undefined **)(puVar28 + 0x20) = &stack0x00000140 + lVar10;
    *(undefined8 *)(puVar28 + -8) = 0x1062e8;
    uVar45 = func_0x
                       (&stack0x00000188 + lVar10,&stack0x00000068 + lVar10,puVar36,
                        &stack0x00000208 + lVar10);
    if (*(int *)(&stack0x00000140 + lVar10) == 2) {
      pcVar2 = *(code **)(_DAT_ + 0x10);
      *(undefined8 *)(puVar28 + -8) = 0x1062fe;
      uVar45 = (*pcVar2)(0);
    }
    uVar24 = 0;
    if ((*(byte *)(lVar12 + 0x38) & 8) != 0) {
      *(undefined **)(puVar28 + 0x28) = &stack0x00000068 + lVar10;
      *(undefined8 *)(puVar28 + 0x20) = 0;
      *(undefined8 *)(puVar28 + -8) = 0x106322;
      func_0x(uVar45,0,0,puVar36);
    }
    lVar12 = *(longlong *)(&stack0x000003f0 + lVar10);
    if ((lVar12 != 0) &&
       (uVar43 = *(uint *)(&stack0x000003e8 + lVar10), uVar22 = uVar24, uVar43 != 0)) {
      do {
        lVar21 = uVar22 * 0x40;
        if ((*(byte *)(lVar12 + 0x18 + lVar21) & 4) != 0) {
          uVar13 = *(undefined8 *)(lVar12 + 0x20 + lVar21);
          *(undefined8 *)(puVar28 + -8) = 0x106358;
          (*_DAT_)(uVar13);
          pbVar40 = (byte *)(*(longlong *)(&stack0x000003f0 + lVar10) + 0x18 + lVar21);
          *pbVar40 = *pbVar40 & 0xfb;
          lVar12 = *(longlong *)(&stack0x000003f0 + lVar10);
          uVar43 = *(uint *)(&stack0x000003e8 + lVar10);
        }
        uVar34 = (int)uVar22 + 1;
        uVar22 = (ulonglong)uVar34;
      } while (uVar34 < uVar43);
    }
    lVar12 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x28);
    puVar29 = puVar28;
    if (lVar12 != 0) {
      uVar22 = uVar24;
      if (*(int *)(*(longlong *)(param_1 + 0x18) + *(longlong *)(lVar12 + 0x30)) != 3) {
        uVar22 = *(longlong *)(lVar12 + 0x28) + *(longlong *)(param_1 + 0x18);
      }
      *(undefined8 *)(puVar28 + -8) = 0x1063a3;
      lVar12 = func_0x();
      if (lVar12 != 0) {
        *(undefined8 *)(puVar28 + -8) = 0x1063ad;
        lVar12 = func_0x();
        uVar13 = *(undefined8 *)(param_1 + 0x30);
        uVar4 = *(undefined8 *)(lVar12 + 0x110);
        *(undefined8 *)(puVar28 + -8) = 0x1063bd;
        lVar12 = func_0x(uVar4,uVar13);
        if (lVar12 != 0) {
          uVar24 = *(ulonglong *)(lVar12 + 8);
        }
      }
      uVar13 = *(undefined8 *)(param_1 + 0x40);
      *(undefined8 *)(puVar28 + -8) = 0x1063d9;
      func_0x(param_1 + 0x48,uVar13,uVar22,uVar24);
    }
  }
LAB_:
  uVar24 = *(ulonglong *)(&stack0x000023b8 + lVar10);
  *(undefined8 *)(puVar29 + -8) = 0x1063e8;
  func_0x(uVar24 ^ (ulonglong)puVar1);
  return;
}

