
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 *param_2,undefined4 *param_3)

{
  byte *pbVar1;
  undefined2 uVar2;
  short sVar3;
  undefined4 uVar4;
  longlong lVar5;
  char cVar6;
  longlong lVar7;
  short *psVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  undefined8 unaff_RBX;
  byte **ppbVar9;
  ulonglong uVar10;
  undefined4 uStackX_c;
  undefined8 auStackX_10 [3];
  undefined8 uStack_2378;
  undefined2 uStack_2370;
  undefined4 uStack_2368;
  undefined4 uStack_2360;
  undefined2 uStack_235c;
  undefined4 uStack_2358;
  undefined2 uStack_2354;
  undefined4 uStack_2350;
  undefined2 uStack_234c;
  undefined2 uStack_234a;
  undefined4 *puStack_2348;
  longlong *plStack_2340;
  undefined uStack_2338;
  undefined4 uStack_2334;
  longlong lStack_2328;
  undefined8 uStack_2320;
  short sStack_2098;
  undefined4 uStack_2094;
  byte *pbStack_2090;
  byte **ppbStack_2088;
  undefined8 uStack_207a;
  undefined2 uStack_2072;
  undefined2 uStack_2070;
  undefined6 uStack_206e;
  undefined4 uStack_2064;
  undefined auStack_2060 [16];
  undefined auStack_2050 [8];
  undefined8 uStack_2048;
  undefined8 uStack_2040;
  undefined6 uStack_2038;
  undefined2 uStack_2032;
  undefined6 uStack_2030;
  undefined2 uStack_202a;
  undefined8 uStack_2028;
  undefined auStack_2020 [16];
  undefined auStack_2010 [16];
  undefined auStack_2000 [16];
  undefined8 uStack_1ff0;
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  uStack_2320 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000023e8 + lVar7) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar7);
  *param_2 = *param_3;
  *(undefined2 *)(param_2 + 1) = *(undefined2 *)(param_3 + 1);
  plStack_2340 = (longlong *)0x0;
  uStack_2338 = 0;
  uStack_2334 = 0;
  *(undefined8 *)(&stack0x00000040 + lVar7) = 0;
  *(undefined8 *)((longlong)auStackX_10 + lVar7) = 0;
  *(undefined4 *)((longlong)&uStackX_c + lVar7) = 0;
  *(undefined8 *)((longlong)auStackX_10 + lVar7 + 0x16) = 0;
  *(undefined8 *)(&stack0x00000030 + lVar7) = 0;
  *(undefined8 *)((longlong)auStackX_10 + lVar7 + 8) = 0;
  sStack_2098 = -1;
  pbStack_2090 = (byte *)0x0;
  uStack_2094 = 0;
  uStack_207a = 0;
  uStack_2070 = 0;
  uStack_206e = 0;
  ppbStack_2088 = (byte **)0x0;
  uVar4 = *param_3;
  uVar2 = *(undefined2 *)(param_3 + 1);
  puStack_2348 = param_2;
  lStack_2328 = param_1;
  if (*(char *)(*(longlong *)(param_1 + 0x20) + 0x1cde) == '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10011b;
    uStack_2360 = uVar4;
    uStack_235c = uVar2;
    func_0x(param_1,&plStack_2340,&uStack_2360,0);
  }
  else {
    uStack_234a = 0;
    (&stack0xfffffffffffffff0)[lVar7] = 0;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100146;
    uStack_2350 = uVar4;
    uStack_234c = uVar2;
    func_0x(param_1,&uStack_2350,&plStack_2340,1);
  }
  lVar5 = *plStack_2340;
  uStack_2064 = 0;
  if (-1 < *(char *)(lVar5 + 2)) goto LAB_;
  pbVar1 = (byte *)(lVar5 + 0x60);
  if ((sStack_2098 == 0) || (ppbVar9 = ppbStack_2088, ppbStack_2088 == (byte **)0x0)) {
    uStack_2038 = 0;
    uStack_202a = 0;
    auStack_2010 = ZEXT816(0);
    auStack_2060 = ZEXT816(0);
    stack0xffffffffffffdfb2 = SUB1614(ZEXT816(0),2);
    auStack_2050._0_2_ = 0xffff;
    uStack_2048 = 0;
    uStack_2032 = 0;
    uStack_2030 = 0;
    uStack_2028 = 0;
    uStack_2040 = 0;
    auStack_2020 = ZEXT816(0);
    auStack_2000._0_12_ = ZEXT812(0);
    auStack_2000._12_4_ = 0;
    uStack_1ff0 = 0;
    ppbVar9 = (byte **)auStack_2060;
  }
  if (*(short *)(lVar5 + 0x24) == 0) {
LAB_:
    uStack_2378 = *(undefined8 *)(lVar5 + 0x28);
    uStack_2370 = *(undefined2 *)(lVar5 + 0x30);
  }
  else {
    cVar6 = *(char *)(lVar5 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(lVar5 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar5 + 0x18) != 99) goto LAB_;
    }
    uStack_2358 = *(undefined4 *)(lVar5 + 0x20);
    uStack_2354 = *(undefined2 *)(lVar5 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10027c;
    cVar6 = func_0x(&uStack_2358,0xfffffffffee00620,0x12b9e48);
    if (cVar6 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10028c;
    func_0x(lVar5,&uStack_2378);
  }
  *ppbVar9 = pbVar1;
  *(undefined4 *)(ppbVar9 + 0xc) = (undefined4)uStack_2378;
  *(int *)((longlong)ppbVar9 + 100) = (int)((ulonglong)uStack_2378 >> 0x20);
  *(undefined2 *)(ppbVar9 + 0xd) = uStack_2370;
  *(undefined4 *)((longlong)ppbVar9 + 0x6c) = *(undefined4 *)(lVar5 + 0x20);
  *(undefined2 *)(ppbVar9 + 0xe) = *(undefined2 *)(lVar5 + 0x24);
  *(undefined2 *)((longlong)ppbVar9 + 0x72) = 0;
  uStack_2368 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x133a450);
  uVar10 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x133a454);
  *(undefined2 *)(ppbVar9 + 2) = 0xffff;
  ppbVar9[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar9 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar9 + 0x2e) = 0;
  ppbVar9[7] = (byte *)0x0;
  ppbVar9[4] = (byte *)0x0;
  ppbVar9[9] = (byte *)0x0;
  ppbVar9[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar9 + 0xb) = 0;
  if ((**ppbVar9 & 2) != 0) {
    pbVar1 = pbVar1 + uVar10;
    if ((*pbVar1 & 1) == 0) {
      *(undefined2 *)(ppbVar9 + 2) = 0;
      ppbVar9[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar9 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar9 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001004f2 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x101abc) - 0x11ff9e0))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar9 + 2) = 1;
    ppbVar9[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x101a9c) * 4 +
                           0x101a8c) - 0x11ff9e0);
                    /* WARNING: Could not emulate address calculation at 0x00100357 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar9 & 4) != 0) {
    uStack_2368._2_2_ = (short)((uint)uStack_2368 >> 0x10);
    if (uStack_2368._2_2_ != 0) {
      uVar10 = (ulonglong)*(ushort *)(lVar5 + 0x61 + (longlong)uStack_2368._2_2_ * 2);
    }
    psVar8 = (short *)(pbVar1 + uVar10);
    ppbVar9[9] = (byte *)psVar8;
    sVar3 = *psVar8;
    ppbVar9[10] = (byte *)(psVar8 + 1);
    *(short *)(ppbVar9 + 0xb) = (sVar3 + 1) * 2;
  }
  pbVar1 = ppbVar9[1];
  if (pbVar1 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1005ab;
    func_0x(pbVar1,ppbVar9);
  }
LAB_:
  pbStack_2090 = (byte *)((ulonglong)*(ushort *)(lVar5 + 0x1ffe) + lVar5);
  if ((*pbStack_2090 & 1) == 0) {
    sStack_2098 = 0;
    uStack_2094 = 0;
    uStack_2072 = 0;
    uStack_2070 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007e3 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_2090 & 0xe) * 4 + 0x101b28) - 0x11ff9e0
              ))(0x12b9e48);
    return;
  }
  sStack_2098 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_2090 & 0x1c) + 0x101b08) * 4
                         + 0x101af8) - 0x11ff9e0);
                    /* WARNING: Could not emulate address calculation at 0x0010060d */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_2090,0x12b9e48);
  return;
}

