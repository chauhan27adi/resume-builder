
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,short *param_3)

{
  longlong lVar1;
  uint uVar2;
  int aiStack_38 [6];
  ulonglong uStack_20;
  
  uStack_20 = _DAT_ ^ (ulonglong)aiStack_38;
  if (*(ushort *)(param_1 + 4) != 0) {
    if (*param_3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = *(ushort *)(param_1 + 4) - 1;
    lVar1 = (ulonglong)(uVar2 >> 3) + (longlong)*(int *)(param_3 + 8) + *(longlong *)(param_3 + 4);
    *(byte *)(lVar1 + 2) = *(byte *)(lVar1 + 2) & ~(byte)(1 << (uVar2 & 7));
  }
  if ((*(byte *)(param_1 + 0x21) & 0x20) == 0) {
    if (param_2 != 0) {
      aiStack_38[0] = param_2;
      func_0x(param_3,param_1,aiStack_38,4);
      func_0x(uStack_20 ^ (ulonglong)aiStack_38);
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

