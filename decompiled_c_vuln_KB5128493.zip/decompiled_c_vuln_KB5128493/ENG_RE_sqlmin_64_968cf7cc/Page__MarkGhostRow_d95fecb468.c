
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,undefined8 param_3,undefined8 param_4,uint param_5)

{
  longlong lVar1;
  byte *pbVar2;
  
  func_0x();
  if ((param_5 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (-1 < *(char *)(param_1 + 2)) {
    pbVar2 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)param_2) * 2) + param_1);
    if ((*pbVar2 & 1) == 0) {
      lVar1 = (longlong)(int)(*pbVar2 & 0xe);
                    /* WARNING: Could not emulate address calculation at 0x001000f9 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)(lVar1 * 4 + 0x100660) + 0x8b020))
                (0xfff - (longlong)param_2,lVar1,0);
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

