
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 *param_2,undefined8 param_3,undefined8 param_4)

{
  byte *pbVar1;
  uint *puVar2;
  byte bVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  longlong *plVar7;
  code *pcVar8;
  int *piVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  undefined8 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  char cVar15;
  char cVar16;
  undefined uVar17;
  short sVar18;
  ushort uVar19;
  int iVar20;
  uint uVar21;
  int iVar22;
  int iVar23;
  int iVar24;
  undefined4 uVar25;
  longlong lVar26;
  ulonglong uVar27;
  byte **ppbVar28;
  undefined8 uVar29;
  undefined8 *puVar30;
  undefined4 *puVar31;
  short *psVar32;
  longlong lVar33;
  ulonglong *puVar34;
  longlong lVar35;
  longlong lVar36;
  undefined4 *puVar37;
  byte bVar38;
  longlong lVar39;
  longlong lVar40;
  byte bVar41;
  short sVar42;
  ushort uVar43;
  uint uVar44;
  uint uVar45;
  ulonglong uVar46;
  longlong *plVar47;
  longlong lVar48;
  undefined8 unaff_RBX;
  undefined *puVar49;
  ushort *puVar50;
  byte *pbVar51;
  short *psVar52;
  undefined2 *puVar53;
  longlong *plVar54;
  longlong *plVar55;
  ulonglong uVar56;
  ushort *puVar57;
  longlong unaff_GS_OFFSET;
  bool bVar58;
  undefined8 uStackX_8;
  undefined8 uStackX_16;
  undefined8 uStackX_20;
  undefined auStack_f8 [112];
  undefined auStack_88 [8];
  undefined8 uStack_80;
  undefined2 auStack_78 [2];
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_5a;
  undefined8 uStack_50;
  undefined auStack_48 [8];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar26 = func_0x();
  lVar26 = -lVar26;
  puVar49 = &stack0xffffffffffffffc8 + lVar26;
  puVar2 = (uint *)(&stack0x00000038 + lVar26);
  *(undefined8 *)(&stack0x000002a8 + lVar26) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002aa0 + lVar26) = unaff_RBX;
  *(ulonglong *)(&stack0x00002a48 + lVar26) = _DAT_ ^ (ulonglong)puVar2;
  *(undefined8 *)(&stack0x00000250 + lVar26) = param_4;
  *(undefined8 *)(&stack0x00000128 + lVar26) = param_3;
  *(longlong *)(&stack0x00000178 + lVar26) = param_1;
  *(longlong *)(&stack0x00000120 + lVar26) = param_1;
  *(undefined8 **)(&stack0x00000258 + lVar26) = *(undefined8 **)(&stack0x00002ab8 + lVar26);
  *(undefined2 *)(&stack0x00000060 + lVar26) = 0xffff;
  uVar46 = 0;
  *(undefined8 *)(&stack0x00000068 + lVar26) = 0;
  *(undefined4 *)(&stack0x00000064 + lVar26) = 0;
  *(undefined8 *)(&stack0x0000007e + lVar26) = 0;
  *(undefined8 *)(&stack0x00000088 + lVar26) = 0;
  *(undefined8 *)(&stack0x00000070 + lVar26) = 0;
  *(undefined2 *)(&stack0x00000892 + lVar26) = 0;
  *(undefined4 *)(&stack0x000001e8 + lVar26) = _DAT_;
  *(undefined4 *)(&stack0x000001ec + lVar26) = uRam0000000001e8726c;
  *(undefined4 *)(&stack0x000001f0 + lVar26) = _DAT_;
  *(undefined4 *)(&stack0x000001f4 + lVar26) = uRam0000000001e87274;
  *(undefined4 *)(&stack0x00000098 + lVar26) = 0xffffffff;
  *(undefined4 *)(&stack0x00000048 + lVar26) = 1;
  *(undefined8 *)(&stack0x000001d0 + lVar26) =
       *(undefined8 *)(*(longlong *)(*(longlong *)(param_1 + 0x2e0) + 8) + 0x30);
  **(undefined8 **)(&stack0x00002ab8 + lVar26) = 0;
  lVar40 = *(longlong *)(param_1 + 0xae8);
  if (lVar40 == param_1 + 0xae0) {
LAB_:
    *(undefined4 *)(&stack0x000000bc + lVar26) = 0x75f;
    (&stack0xffffffffffffffe8)[lVar26] = 5;
    uVar29 = *(undefined8 *)(param_1 + 0x1f0);
    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10013e;
    lVar40 = (*_DAT_)(0x638,uVar29,0x1771318,0x75f);
    *(longlong *)(&stack0x000000f8 + lVar26) = lVar40;
    uVar27 = uVar46;
    if (lVar40 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100152;
      uVar27 = func_0x(lVar40);
    }
    *(ulonglong *)(&stack0x000000d0 + lVar26) = uVar27;
    uVar29 = *(undefined8 *)(param_1 + 0x2d8);
    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100170;
    func_0x(uVar27,uVar29);
  }
  else {
    uVar27 = uVar46;
    if (lVar40 != 0) {
      uVar27 = lVar40 - 0x10;
    }
    *(ulonglong *)(&stack0x000000d0 + lVar26) = uVar27;
    if (uVar27 == 0) goto LAB_;
    plVar55 = *(longlong **)(uVar27 + 0x18);
    lVar40 = *(longlong *)(uVar27 + 0x10);
    *(longlong **)(lVar40 + 8) = plVar55;
    *plVar55 = lVar40;
    *(undefined8 *)(uVar27 + 0x18) = 0;
    *(undefined8 *)(uVar27 + 0x10) = 0;
  }
  plVar55 = (longlong *)(uVar27 + 0x10);
  *(undefined8 *)(uVar27 + 0x18) = *(undefined8 *)(param_1 + 0xaf8);
  **(longlong ***)(param_1 + 0xaf8) = plVar55;
  *(longlong **)(param_1 + 0xaf8) = plVar55;
  *plVar55 = param_1 + 0xaf0;
  uVar21 = **(uint **)(param_1 + 0x108);
  puVar30 = *(undefined8 **)(param_1 + 0x2e0);
  *(undefined4 *)(&stack0x000000bc + lVar26) = 0x10;
  if (*(int *)(uVar27 + 0x630) == 1) {
    *(undefined8 **)(uVar27 + 0x28) = puVar30;
    *(undefined8 **)(uVar27 + 0x38) = puVar30;
    *(longlong *)(uVar27 + 0x100) = *(longlong *)(*(longlong *)(uVar27 + 0x30) + 0x48) + 0x28;
    *(undefined4 *)(uVar27 + 0xf0) = 2;
    if (*(int *)(*(longlong *)(*(longlong *)(uVar27 + 0x20) + 0x48) + 0x18) != 1) {
      uVar29 = *puVar30;
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10020d;
      func_0x(uVar27 + 0x538,uVar29,uVar21 >> 0x1b & 1);
      lVar40 = *(longlong *)(uVar27 + 0x20);
      bVar41 = 0;
      bVar38 = bVar41;
      if (*(int *)(lVar40 + 0x40) == 3) {
        bVar38 = 8;
      }
      bVar3 = *(byte *)(uVar27 + 0x530);
      *(byte *)(uVar27 + 0x530) = bVar38 | bVar3 & 0xf7;
      if (*(int *)(lVar40 + 0x40) == 4) {
        bVar41 = 0x10;
      }
      bVar41 = bVar41 | bVar38 | bVar3 & 0xe7;
      *(byte *)(uVar27 + 0x530) = bVar41;
      *(byte *)(uVar27 + 0x530) =
           ((char)((*(int *)(*(longlong *)(lVar40 + 0x10) + 0x50) << 0x1f) >> 0x1f) << 5 ^ bVar41) &
           0x20 ^ bVar41;
      *(undefined4 *)(uVar27 + 0x548) = *(undefined4 *)(*(longlong *)(lVar40 + 0x48) + 0x188);
      *(undefined4 *)(uVar27 + 0x54c) = *(undefined4 *)(puVar30 + 4);
    }
    *(undefined4 *)(uVar27 + 0x630) = 2;
  }
  *(ulonglong *)(&stack0x000000c0 + lVar26) = uVar27;
  *(undefined4 *)(&stack0x00000880 + lVar26) = *param_2;
  *(undefined2 *)(&stack0x00000884 + lVar26) = *(undefined2 *)(param_2 + 1);
  *(undefined2 *)(&stack0x00000886 + lVar26) = 0;
  *(undefined8 *)(&stack0x00000878 + lVar26) = 0;
  *(undefined4 *)(&stack0x00000894 + lVar26) = 0;
  *(undefined8 *)(&stack0x00000888 + lVar26) = 0;
  *(undefined2 *)(&stack0x00000890 + lVar26) = 0;
  puVar30 = *(undefined8 **)(*(longlong *)(&stack0x00000178 + lVar26) + 0x2d8);
  *(undefined **)(&stack0xffffffffffffffe8 + lVar26) = &stack0x000001e8 + lVar26;
  uVar29 = *puVar30;
  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1002fd;
  iVar20 = func_0x(uVar29,&stack0x00000878 + lVar26,3,2);
  if (iVar20 != 0) {
    *(uint *)(uVar27 + 0x634) = *(uint *)(uVar27 + 0x634) & 0xfffffffe;
    plVar55 = (longlong *)(uVar27 + 0x30);
    (&stack0x00000866)[lVar26] = 1;
    uVar29 = *(undefined8 *)*plVar55;
    plVar7 = *(longlong **)(*(longlong *)(uVar27 + 0x38) + 8);
    uVar25 = *(undefined4 *)(&stack0x000001ec + lVar26);
    uVar6 = *(undefined4 *)(&stack0x000001f0 + lVar26);
    uVar13 = *(undefined4 *)(&stack0x000001f4 + lVar26);
    *(undefined4 *)(uVar27 + 0x40) = *(undefined4 *)(&stack0x000001e8 + lVar26);
    *(undefined4 *)(uVar27 + 0x44) = uVar25;
    *(undefined4 *)(uVar27 + 0x48) = uVar6;
    *(undefined4 *)(uVar27 + 0x4c) = uVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10033f;
    func_0x(uVar29,uVar27 + 0x40,uVar27 + 0x58);
    *(undefined8 *)(uVar27 + 0x288) = **(undefined8 **)(uVar27 + 0x58);
    *(undefined4 *)(uVar27 + 0x88) = 3;
    *(undefined4 *)(uVar27 + 0x29c) = 0;
    lVar40 = *(longlong *)(*plVar55 + 0x18);
    uVar21 = *(uint *)(*(longlong *)(uVar27 + 0x100) + 0x10);
    if (((((uVar21 & 1) != 0) && ((uVar21 & 0x40) == 0)) &&
        (lVar33 = plVar7[6], *(char *)(lVar33 + 0x1cd2) != '\0')) &&
       (*(char *)(lVar33 + 0x2050) == '\0')) {
      uVar25 = *(undefined4 *)(*(longlong *)(uVar27 + 0x40) + 0x90);
      uVar4 = *(undefined2 *)(*(longlong *)(uVar27 + 0x40) + 0x94);
      uVar5 = *(undefined2 *)(lVar33 + 0x6b8);
      (&stack0x00000866)[lVar26] = 6;
      *(undefined2 *)(&stack0x00000864 + lVar26) = uVar5;
      *(undefined8 *)(&stack0x0000085c + lVar26) = 0;
      *(undefined4 *)(&stack0x00000858 + lVar26) = uVar25;
      *(undefined2 *)(&stack0x0000085c + lVar26) = uVar4;
      uVar29 = *(undefined8 *)(*(longlong *)(uVar27 + 0x38) + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1003f5;
      cVar15 = func_0x(uVar29,CONCAT71((uint7)(byte)((ushort)uVar4 >> 8),6),
                               &stack0x00000858 + lVar26,1);
      if (cVar15 == '\0') {
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100401;
        func_0x(plVar55);
        lVar33 = *(longlong *)(*plVar55 + 0x18);
        lVar36 = *(longlong *)(uVar27 + 0x38);
        (&stack0xffffffffffffffe8)[lVar26] = 1;
        uVar25 = *(undefined4 *)(lVar33 + 0x18);
        uVar29 = *(undefined8 *)(lVar36 + 8);
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100427;
        func_0x(uVar29,6,uVar25,&stack0x00000858 + lVar26);
      }
    }
    if (*(char *)(lVar40 + 2) != '\0') {
      pcVar8 = *(code **)(*plVar7 + 0x28);
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10043b;
      cVar15 = (*pcVar8)(plVar7);
      if (cVar15 == '\0') {
        uVar25 = *(undefined4 *)(*(longlong *)(uVar27 + 0x40) + 0x90);
        uVar4 = *(undefined2 *)(*(longlong *)(uVar27 + 0x40) + 0x94);
        uVar5 = *(undefined2 *)
                 (*(longlong *)(*(longlong *)(*(longlong *)(uVar27 + 0x38) + 8) + 0x30) + 0x6b8);
        (&stack0x00000866)[lVar26] = 6;
        *(undefined2 *)(&stack0x00000864 + lVar26) = uVar5;
        *(undefined8 *)(&stack0x0000085c + lVar26) = 0;
        *(undefined4 *)(&stack0x00000858 + lVar26) = uVar25;
        *(undefined2 *)(&stack0x0000085c + lVar26) = uVar4;
        *(undefined4 *)((longlong)&uStackX_20 + lVar26 + -0x20) = 1;
        *(undefined4 *)(&stack0xfffffffffffffff8 + lVar26) = 1;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar26) = 1;
        *(ulonglong *)(&stack0xffffffffffffffe8 + lVar26) = uVar27 + 0xc0;
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1004c4;
        iVar20 = func_0x(plVar55,&stack0x00000858 + lVar26,2,lVar40);
        if (iVar20 < 0) {
          if ((*(longlong *)(uVar27 + 0x40) != CONCAT44(uRam0000000001e8726c,_DAT_)) ||
             (*(longlong *)(uVar27 + 0x48) != CONCAT44(uRam0000000001e87274,_DAT_))) {
            if ((*(byte *)(uVar27 + 0xa0) & 2) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1004ff;
              iVar20 = func_0x(uVar27 + 0xa8);
              if (iVar20 != 0) {
                *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
              }
            }
            *(undefined *)(uVar27 + 0xa0) = 0;
            *(undefined4 *)(uVar27 + 0x9c) = 0;
            *(undefined4 *)(uVar27 + 0xb8) = 0;
            if ((*(byte *)(uVar27 + 0xd0) & 2) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100538;
              iVar20 = func_0x(uVar27 + 0xd8);
              if (iVar20 != 0) {
                *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
              }
            }
            *(undefined *)(uVar27 + 0xd0) = 0;
            *(undefined4 *)(uVar27 + 0xcc) = 0;
            *(undefined4 *)(uVar27 + 0xe8) = 0;
            if (*(longlong *)(uVar27 + 0x58) != 0) {
              if (*(longlong *)(uVar27 + 0x58) != 0) {
                *(undefined *)(uVar27 + 0x66) = 0;
                *(undefined8 *)(uVar27 + 0x58) = 0;
                *(undefined2 *)(uVar27 + 100) = 0;
              }
              *(undefined4 *)(*(longlong *)(uVar27 + 0x40) + 0x48) = 0;
            }
            uVar29 = *(undefined8 *)*plVar55;
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10058e;
            func_0x(uVar29,uVar27 + 0x40);
            uVar13 = uRam0000000001e87274;
            uVar6 = _DAT_;
            uVar25 = uRam0000000001e8726c;
            *(undefined4 *)(uVar27 + 0x40) = _DAT_;
            *(undefined4 *)(uVar27 + 0x44) = uVar25;
            *(undefined4 *)(uVar27 + 0x48) = uVar6;
            *(undefined4 *)(uVar27 + 0x4c) = uVar13;
            *(undefined4 *)(uVar27 + 0x50) = 0xffffffff;
            *(undefined4 *)(uVar27 + 0x270) = 0;
            *(undefined8 *)(uVar27 + 0x288) = 0;
            *(undefined8 *)(uVar27 + 0x280) = 0;
            *(undefined8 *)(uVar27 + 0x290) = 0;
            *(undefined4 *)(uVar27 + 0x2a0) = 0xffffffff;
            *(undefined2 *)(uVar27 + 0x2a4) = 0xffff;
            *(undefined8 *)(uVar27 + 0x2a6) = 0;
            *(undefined4 *)(uVar27 + 0xf0) = 2;
          }
          *(uint *)(uVar27 + 0x634) = *(uint *)(uVar27 + 0x634) | 1;
          goto LAB_;
        }
      }
    }
    *(undefined4 *)(uVar27 + 0xf0) = 3;
    if (*(longlong *)(uVar27 + 0x58) != 0) {
LAB_:
      uVar21 = *(uint *)(uVar27 + 0x634) | 1;
      *(uint *)(uVar27 + 0x634) = uVar21;
      iVar20 = *(int *)(&stack0x000000bc + lVar26);
      uVar56 = uVar27;
LAB_:
      lVar40 = 0;
      lVar33 = *(longlong *)(uVar56 + 0x288);
      if (*(longlong *)(uVar56 + 0x288) == 0) {
        *(uint *)(uVar56 + 0x634) = uVar21 & 0xfffffffe;
        if (*(int *)(uVar56 + 0x370) == 4) {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1006ac;
          func_0x(uVar56 + 0x2b0);
        }
        if (*(longlong **)(uVar27 + 0x58) == (longlong *)0x0) {
          if (*(int *)(uVar27 + 0xf0) != 2) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1006d1;
            func_0x(plVar55,1);
            if (*(int *)(uVar27 + 0xf0) != 2) {
              lVar40 = **(longlong **)(uVar27 + 0x58);
            }
          }
        }
        else {
          lVar40 = **(longlong **)(uVar27 + 0x58);
        }
        lVar33 = lVar40;
        if (*(char *)(*(longlong *)(uVar56 + 0x28) + 0xb5) == '\0') {
          *(uint *)(uVar56 + 0x634) = *(uint *)(uVar56 + 0x634) | 1;
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100706;
      iVar22 = func_0x(lVar33,*(undefined4 *)(&stack0x00000098 + lVar26));
      *(int *)(&stack0x00000098 + lVar26) = iVar22;
      *(uint *)(uVar56 + 0x634) = *(uint *)(uVar56 + 0x634) & 0xfffffffe;
      if (iVar22 != -1) {
        iVar22 = 0;
        *(undefined4 *)(&stack0x000000c8 + lVar26) = 0;
        uVar25 = *(undefined4 *)(&stack0x00000048 + lVar26);
LAB_:
        *(undefined4 *)(&stack0x00000048 + lVar26) = uVar25;
        *puVar2 = (uint)uVar46;
        if ((*(int *)(uVar56 + 0x370) == 4) &&
           ((*(longlong *)(uVar56 + 0x2c0) != CONCAT44(uRam0000000001e8726c,_DAT_) ||
            (*(longlong *)(uVar56 + 0x2c8) != CONCAT44(uRam0000000001e87274,_DAT_))))) {
          if ((*(byte *)(uVar56 + 800) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10078f;
            iVar23 = func_0x();
            if (iVar23 != 0) {
              plVar7 = (longlong *)(*(longlong *)(uVar56 + 0x2b0) + 0x30);
              *plVar7 = *plVar7 + -1;
            }
          }
          *(undefined *)(uVar56 + 800) = 0;
          *(undefined4 *)(uVar56 + 0x31c) = 0;
          *(undefined4 *)(uVar56 + 0x338) = 0;
          if ((*(byte *)(uVar56 + 0x350) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1007cc;
            iVar23 = func_0x();
            if (iVar23 != 0) {
              plVar7 = (longlong *)(*(longlong *)(uVar56 + 0x2b0) + 0x30);
              *plVar7 = *plVar7 + -1;
            }
          }
          *(undefined *)(uVar56 + 0x350) = 0;
          *(undefined4 *)(uVar56 + 0x34c) = 0;
          *(undefined4 *)(uVar56 + 0x368) = 0;
          if (*(longlong *)(uVar56 + 0x2d8) != 0) {
            *(undefined *)(uVar56 + 0x2e6) = 0;
            *(undefined8 *)(uVar56 + 0x2d8) = 0;
            *(undefined2 *)(uVar56 + 0x2e4) = 0;
            *(undefined4 *)(*(longlong *)(uVar56 + 0x2c0) + 0x48) = 0;
          }
          uVar29 = **(undefined8 **)(uVar56 + 0x2b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100834;
          func_0x(uVar29,uVar56 + 0x2c0);
          uVar14 = uRam0000000001e87274;
          uVar13 = _DAT_;
          uVar6 = uRam0000000001e8726c;
          *(undefined4 *)(uVar56 + 0x2c0) = _DAT_;
          *(undefined4 *)(uVar56 + 0x2c4) = uVar6;
          *(undefined4 *)(uVar56 + 0x2c8) = uVar13;
          *(undefined4 *)(uVar56 + 0x2cc) = uVar14;
          *(undefined4 *)(uVar56 + 0x2d0) = 0xffffffff;
          *(undefined4 *)(uVar56 + 0x4f0) = 0;
          *(undefined8 *)(uVar56 + 0x508) = 0;
          *(undefined8 *)(uVar56 + 0x500) = 0;
          *(undefined8 *)(uVar56 + 0x510) = 0;
          *(undefined4 *)(uVar56 + 0x520) = 0xffffffff;
          *(undefined2 *)(uVar56 + 0x524) = 0xffff;
          *(undefined8 *)(uVar56 + 0x526) = 0;
          *(undefined4 *)(uVar56 + 0x370) = 2;
        }
        if (iVar22 < 1) {
          if (iVar22 == 0) goto LAB_;
        }
        else {
          if (*(longlong *)(uVar27 + 0x58) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1008b4;
            func_0x(plVar55,0);
          }
          if (*(int *)(uVar27 + 0x270) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1008cb;
            func_0x(plVar55,1);
          }
          uVar46 = (ulonglong)*(uint *)(uVar27 + 0x268);
          *puVar2 = *(uint *)(uVar27 + 0x268);
          uVar25 = *(undefined4 *)(uVar27 + 0x26c);
          *(undefined4 *)(&stack0x00000048 + lVar26) = uVar25;
        }
        if (*(char *)(*(longlong *)(uVar56 + 0x28) + 0x29) != '\0') {
LAB_:
          lVar40 = *(longlong *)(*(longlong *)(uVar27 + 0x38) + 8);
          *(longlong *)(&stack0x000000f8 + lVar26) = lVar40;
          *(undefined2 *)(&stack0x000008c8 + lVar26) = 0xffff;
          *(undefined8 *)(&stack0x000008d0 + lVar26) = 0;
          *(undefined4 *)(&stack0x000008cc + lVar26) = 0;
          *(undefined8 *)(&stack0x000008e6 + lVar26) = 0;
          *(undefined8 *)(&stack0x000008f0 + lVar26) = 0;
          *(undefined8 *)(&stack0x000008d8 + lVar26) = 0;
          *(undefined4 *)(&stack0x000008fc + lVar26) = 0xffffffff;
          *(undefined4 *)(&stack0x000000e4 + lVar26) = 0;
          *(undefined2 *)(&stack0x000000e8 + lVar26) = 0;
          lVar33 = *(longlong *)(*plVar55 + 0x18);
          *(longlong *)(&stack0x00000130 + lVar26) = lVar33;
          (&stack0x0000003c)[lVar26] = 0;
          if ((*(byte *)(uVar27 + 0xa0) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100b5f;
            iVar20 = func_0x(uVar27 + 0xa8);
            if (iVar20 != 0) {
              *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
            }
          }
          *(undefined *)(uVar27 + 0xa0) = 0;
          *(undefined4 *)(uVar27 + 0x9c) = 0;
          *(undefined4 *)(uVar27 + 0xb8) = 0;
          *(undefined4 *)(uVar27 + 0x50) = *(undefined4 *)(&stack0x00000098 + lVar26);
          uVar21 = *(uint *)(*(longlong *)(uVar27 + 0x100) + 0x10);
          if (((((uVar21 & 1) != 0) && ((uVar21 & 0x40) == 0)) &&
              (*(char *)(*(longlong *)(lVar40 + 0x30) + 0x1cd2) != '\0')) &&
             (*(char *)(*(longlong *)(lVar40 + 0x30) + 0x2050) == '\0')) {
            (&stack0x00000a36)[lVar26] = 1;
            lVar36 = **(longlong **)(uVar27 + 0x58);
            uVar6 = *(undefined4 *)(uVar27 + 0x50);
            *(undefined4 *)(&stack0x000001a8 + lVar26) = *(undefined4 *)(lVar36 + 0x20);
            *(undefined2 *)(&stack0x000001ac + lVar26) = *(undefined2 *)(lVar36 + 0x24);
            *(short *)(&stack0x000001ae + lVar26) = (short)uVar6;
            uVar4 = *(undefined2 *)(*(longlong *)(lVar40 + 0x30) + 0x6b8);
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100c09;
            func_0x(&stack0x00000a28 + lVar26,uVar4,&stack0x000001a8 + lVar26);
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100c1d;
            cVar15 = func_0x(lVar40,3,&stack0x00000a28 + lVar26,1);
            if (cVar15 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100c29;
              func_0x(plVar55);
              lVar36 = *(longlong *)(*plVar55 + 0x18);
              (&stack0xffffffffffffffe8)[lVar26] = 1;
              uVar6 = *(undefined4 *)(lVar36 + 0x18);
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100c4a;
              func_0x(lVar40,3,uVar6,&stack0x00000a28 + lVar26);
              if (*(longlong *)(uVar27 + 0x58) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100c5b;
                func_0x(plVar55,0);
              }
            }
          }
          *(int *)(&stack0x000000dc + lVar26) = _DAT_;
          *(undefined2 *)(&stack0x00000058 + lVar26) = _DAT_;
          do {
            ppbVar28 = (byte **)0x0;
            *(int *)(&stack0x000000a8 + lVar26) = (int)uVar46;
            if (((*(char *)(*(longlong *)(uVar27 + 0x38) + 0x29) != '\0') &&
                ((*(uint *)(lVar33 + 4) & 0x140) == 0)) &&
               (lVar36 = *(longlong *)(uVar27 + 0x288),
               *(ushort *)(uVar27 + 0x50) < *(ushort *)(lVar36 + 0x16))) {
              iVar20 = *(int *)(uVar27 + 0x50);
              *(longlong *)(&stack0x00000120 + lVar26) = (longlong)iVar20;
              if (*(short *)(lVar36 + (0xfff - (longlong)iVar20) * 2) != 0) {
                *(int *)(&stack0x000008fc + lVar26) = iVar20;
                if (*(char *)(lVar36 + 2) < '\0') {
                  pbVar51 = (byte *)(lVar36 + 0x60);
                  if ((*(short *)(&stack0x000008c8 + lVar26) == 0) ||
                     (ppbVar28 = *(byte ***)(&stack0x000008d8 + lVar26), ppbVar28 == (byte **)0x0))
                  {
                    *(undefined (*) [16])(&stack0x00000900 + lVar26) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000910 + lVar26) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000920 + lVar26) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000930 + lVar26) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000940 + lVar26) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000950 + lVar26) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000960 + lVar26) = ZEXT816(0);
                    *(undefined8 *)(&stack0x00000970 + lVar26) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100d55;
                    ppbVar28 = (byte **)func_0x(&stack0x00000900 + lVar26);
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100d6d;
                  puVar31 = (undefined4 *)
                            func_0x(lVar36,&stack0x00000a68 + lVar26,0,0);
                  if (pbVar51 == *ppbVar28) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100d81;
                    func_0x(puVar31,ppbVar28 + 0xc);
                  }
                  *ppbVar28 = pbVar51;
                  uVar4 = *(undefined2 *)(puVar31 + 2);
                  uVar6 = puVar31[1];
                  *(undefined4 *)(ppbVar28 + 0xc) = *puVar31;
                  *(undefined4 *)((longlong)ppbVar28 + 100) = uVar6;
                  *(undefined2 *)(ppbVar28 + 0xd) = uVar4;
                  *(undefined4 *)((longlong)ppbVar28 + 0x6c) = *(undefined4 *)(lVar36 + 0x20);
                  *(undefined2 *)(ppbVar28 + 0xe) = *(undefined2 *)(lVar36 + 0x24);
                  sVar42 = 0;
                  *(undefined2 *)((longlong)ppbVar28 + 0x72) = 0;
                  bVar38 = *pbVar51;
                  *(undefined4 *)(&stack0x00000110 + lVar26) =
                       *(undefined4 *)((ulonglong)bVar38 * 6 + 0x15637c0);
                  sVar18 = *(short *)((ulonglong)bVar38 * 6 + 0x15637c4);
                  *(short *)(&stack0x000000b8 + lVar26) = sVar18;
                  *(undefined2 *)(ppbVar28 + 2) = 0xffff;
                  ppbVar28[3] = (byte *)0x0;
                  uVar21 = 0;
                  *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                  *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
                  ppbVar28[7] = (byte *)0x0;
                  ppbVar28[4] = (byte *)0x0;
                  ppbVar28[9] = (byte *)0x0;
                  ppbVar28[10] = (byte *)0x0;
                  *(undefined2 *)(ppbVar28 + 0xb) = 0;
                  if ((**ppbVar28 & 2) != 0) {
                    pbVar1 = pbVar51 + sVar18;
                    if ((*pbVar1 & 1) == 0) {
                      *(undefined2 *)(ppbVar28 + 2) = 0;
                      ppbVar28[3] = pbVar1;
                      *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                      *(undefined4 *)((longlong)ppbVar28 + 0x36) = 0;
                      switch(*pbVar1 & 0xe) {
                      default:
                        uVar21 = (uint)*(ushort *)(pbVar1 + 2);
                        if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101016;
                          func_0x(pbVar1,6);
                        }
                        break;
                      case 4:
                        uVar21 = 9;
                        break;
                      case 6:
                      case 10:
                        break;
                      case 0xe:
                        uVar21 = 1;
                      }
                      *(uint *)(ppbVar28 + 4) = uVar21;
                      *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
                      *puVar2 = *puVar2;
                      *(undefined4 *)(&stack0x00000048 + lVar26) =
                           *(undefined4 *)(&stack0x00000048 + lVar26);
                    }
                    else {
                      *(undefined2 *)(ppbVar28 + 2) = 1;
                      *(undefined4 *)(&stack0x00000048 + lVar26) = uVar25;
                      uVar21 = *(uint *)(&stack0x000000a8 + lVar26);
                      *puVar2 = uVar21;
                      ppbVar28[3] = pbVar1;
                      bVar38 = *pbVar1;
                      switch(bVar38 & 0x1c) {
                      default:
                        if ((char)pbVar1[1] < '\0') {
                          uVar43 = *(ushort *)(pbVar1 + 1);
                          *(ushort *)((longlong)ppbVar28 + 0x12) = uVar43;
                          sVar18 = 3;
                          uVar43 = (uVar43 & 0x7f) << 8 | uVar43 >> 8;
                        }
                        else {
                          sVar18 = 2;
                          uVar43 = (ushort)pbVar1[1];
                        }
                        *(ushort *)((longlong)ppbVar28 + 0x12) = uVar43;
                        *(short *)(ppbVar28 + 5) = sVar18;
                        *(short *)((longlong)ppbVar28 + 0x2c) =
                             (short)(*(ushort *)((longlong)ppbVar28 + 0x12) + 1 >> 1) + sVar18;
                        if (0x1e < *(ushort *)((longlong)ppbVar28 + 0x12)) {
                          iVar20 = *(ushort *)((longlong)ppbVar28 + 0x12) - 1;
                          sVar42 = ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                                   (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                        }
                        *(short *)((longlong)ppbVar28 + 0x2a) = sVar42;
                        *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                        *(undefined4 *)(ppbVar28 + 8) = 0;
                        *puVar2 = uVar21;
                        *(undefined4 *)(&stack0x00000048 + lVar26) = uVar25;
                        ppbVar28[7] = (byte *)0x0;
                        ppbVar28[4] = (byte *)0x0;
                        break;
                      case 4:
                        if (((bVar38 & 0x1c) == 4) && ((bVar38 & 2) != 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100f22;
                          func_0x((longlong)ppbVar28 + 0x12);
                          ppbVar28[3] = pbVar1;
                          *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0xf;
                          *(undefined4 *)(ppbVar28 + 8) = 0;
                          *(undefined4 *)(ppbVar28 + 8) = 1;
                          ppbVar28[7] = (byte *)0x0;
                          ppbVar28[4] = (byte *)0x0;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100f56;
                          func_0x((longlong)ppbVar28 + 0x12);
                          ppbVar28[3] = pbVar1;
                          *(undefined4 *)((longlong)ppbVar28 + 0x14) = 1;
                          *puVar2 = *(uint *)(&stack0x000000a8 + lVar26);
                          *(undefined4 *)(&stack0x00000048 + lVar26) = uVar25;
                          *(undefined4 *)(ppbVar28 + 8) = 0;
                          ppbVar28[7] = (byte *)0x0;
                          ppbVar28[4] = (byte *)0x0;
                        }
                        break;
                      case 8:
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100ef4;
                        func_0x((longlong)ppbVar28 + 0x12);
                        ppbVar28[3] = pbVar1;
                        *(undefined4 *)((longlong)ppbVar28 + 0x14) = 9;
                        *(undefined4 *)(ppbVar28 + 8) = 0;
                        *puVar2 = *(uint *)(&stack0x000000a8 + lVar26);
                        *(undefined4 *)(&stack0x00000048 + lVar26) = uVar25;
                        ppbVar28[7] = (byte *)0x0;
                        ppbVar28[4] = (byte *)0x0;
                      }
                    }
                    sVar18 = *(short *)(&stack0x000000b8 + lVar26);
                  }
                  if ((**ppbVar28 & 4) != 0) {
                    if (*(short *)(&stack0x00000112 + lVar26) == 0) {
                      uVar46 = (ulonglong)sVar18;
                    }
                    else {
                      uVar46 = (ulonglong)
                               *(ushort *)
                                (lVar36 + 0x61 + (longlong)*(short *)(&stack0x00000112 + lVar26) * 2
                                );
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1010a2;
                    func_0x(ppbVar28 + 9,pbVar51 + uVar46);
                  }
                  pbVar51 = ppbVar28[1];
                  if (pbVar51 != (byte *)0x0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1010b6;
                    func_0x(pbVar51,ppbVar28);
                  }
                  uVar46 = (ulonglong)*puVar2;
                }
                uVar21 = (uint)*(ushort *)(lVar36 + 0xe);
                pbVar51 = (byte *)((ulonglong)
                                   *(ushort *)
                                    (lVar36 + (0xfff - *(longlong *)(&stack0x00000120 + lVar26)) * 2
                                    ) + lVar36);
                bVar38 = *pbVar51;
                *(byte **)(&stack0x000008d0 + lVar26) = pbVar51;
                if ((bVar38 & 1) == 0) {
                  *(undefined2 *)(&stack0x000008c8 + lVar26) = 0;
                  *(undefined4 *)(&stack0x000008cc + lVar26) = 0;
                  *(undefined4 *)(&stack0x000008ee + lVar26) = 0;
                  switch(*pbVar51 & 0xe) {
                  default:
                    uVar21 = (uint)*(ushort *)(pbVar51 + 2);
                    if (0x1f9d < *(ushort *)(pbVar51 + 2) - 1) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10130a;
                      func_0x(pbVar51,6);
                    }
                    break;
                  case 4:
                    uVar21 = 9;
                    break;
                  case 6:
                  case 10:
                    break;
                  case 0xe:
                    uVar21 = 1;
                  }
                  *(uint *)(&stack0x000008d8 + lVar26) = uVar21;
                  *(longlong *)(&stack0x000008e6 + lVar26) = lVar36 + 0x2000;
                }
                else {
                  *(undefined2 *)(&stack0x000008c8 + lVar26) = 1;
                  bVar38 = *pbVar51;
                  switch(bVar38 & 0x1c) {
                  default:
                    if ((char)pbVar51[1] < '\0') {
                      uVar43 = (*(ushort *)(pbVar51 + 1) & 0x7f) << 8 |
                               *(ushort *)(pbVar51 + 1) >> 8;
                      *(ushort *)(&stack0x000008ca + lVar26) = uVar43;
                      sVar18 = 3;
                      *(undefined2 *)(&stack0x000008e0 + lVar26) = 3;
                    }
                    else {
                      uVar43 = (ushort)pbVar51[1];
                      *(ushort *)(&stack0x000008ca + lVar26) = uVar43;
                      sVar18 = 2;
                      *(undefined2 *)(&stack0x000008e0 + lVar26) = 2;
                    }
                    *(short *)(&stack0x000008e4 + lVar26) = (short)(uVar43 + 1 >> 1) + sVar18;
                    if (uVar43 < 0x1f) {
                      *(undefined2 *)(&stack0x000008e2 + lVar26) = 0;
                      *(undefined4 *)(&stack0x000008cc + lVar26) = 0;
                      *(undefined4 *)(&stack0x000008f8 + lVar26) = 0;
                    }
                    else {
                      iVar20 = uVar43 - 1;
                      *(short *)(&stack0x000008e2 + lVar26) =
                           ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                           (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                      *(undefined4 *)(&stack0x000008cc + lVar26) = 0;
                      *(undefined4 *)(&stack0x000008f8 + lVar26) = 0;
                    }
code_r0x001012a1:
                    *(longlong *)(&stack0x000008f0 + lVar26) = lVar36 + 0x2000;
                    *(byte ***)(&stack0x000008d8 + lVar26) = ppbVar28;
                    break;
                  case 4:
                    if (((bVar38 & 0x1c) == 4) && ((bVar38 & 2) != 0)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101225;
                      func_0x(&stack0x000008ca + lVar26);
                      *(byte **)(&stack0x000008d0 + lVar26) = pbVar51;
                      *(undefined4 *)(&stack0x000008cc + lVar26) = 0xf;
                      *(undefined4 *)(&stack0x000008f8 + lVar26) = 1;
                      goto code_r0x001012a1;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10124a;
                    func_0x(&stack0x000008ca + lVar26);
                    *(byte **)(&stack0x000008d0 + lVar26) = pbVar51;
                    *(undefined4 *)(&stack0x000008cc + lVar26) = 1;
                    *(undefined4 *)(&stack0x000008f8 + lVar26) = 0;
                    *(longlong *)(&stack0x000008f0 + lVar26) = lVar36 + 0x2000;
                    *(byte ***)(&stack0x000008d8 + lVar26) = ppbVar28;
                    break;
                  case 8:
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1011d8;
                    func_0x(&stack0x000008ca + lVar26);
                    *(byte **)(&stack0x000008d0 + lVar26) = pbVar51;
                    *(undefined4 *)(&stack0x000008cc + lVar26) = 9;
                    *(undefined4 *)(&stack0x000008f8 + lVar26) = 0;
                    *(longlong *)(&stack0x000008f0 + lVar26) = lVar36 + 0x2000;
                    *(byte ***)(&stack0x000008d8 + lVar26) = ppbVar28;
                  }
                }
                if (*(short *)(&stack0x000008c8 + lVar26) == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101378;
                  func_0x();
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10137f;
                  func_0x(&stack0x000008ca + lVar26,&stack0x0000016a + lVar26);
                }
                iVar20 = *(int *)(&stack0x0000016a + lVar26);
                *(int *)(&stack0x000000e4 + lVar26) = iVar20;
                sVar18 = *(short *)(&stack0x0000016e + lVar26);
                *(short *)(&stack0x000000e8 + lVar26) = sVar18;
                if ((sVar18 == *(short *)(&stack0x00000058 + lVar26)) &&
                   (iVar20 == *(int *)(&stack0x000000dc + lVar26))) {
                  lVar40 = *(longlong *)(&stack0x000000f8 + lVar26);
                }
                else {
                  *(int *)(&stack0x00000198 + lVar26) = iVar20;
                  *(short *)(&stack0x0000019c + lVar26) = sVar18;
                  lVar40 = *(longlong *)(&stack0x000000f8 + lVar26);
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1013ca;
                  iVar20 = func_0x(lVar40,&stack0x00000198 + lVar26);
                  if (iVar20 == 3) {
                    iVar20 = 1;
                    uVar56 = *(ulonglong *)(&stack0x000000d0 + lVar26);
                    goto code_r0x00100906;
                  }
                  *(undefined4 *)(&stack0x000000dc + lVar26) =
                       *(undefined4 *)(&stack0x000000e4 + lVar26);
                  *(undefined2 *)(&stack0x00000058 + lVar26) =
                       *(undefined2 *)(&stack0x000000e8 + lVar26);
                }
                uVar25 = *(undefined4 *)(&stack0x00000048 + lVar26);
              }
              lVar33 = *(longlong *)(&stack0x00000130 + lVar26);
            }
            *(undefined4 *)(&stack0x000000b8 + lVar26) = uVar25;
            *(int *)(&stack0x000000a8 + lVar26) = (int)uVar46;
            if ((&stack0x0000003c)[lVar26] != '\0') goto LAB_;
            (&stack0x00000a56)[lVar26] = 1;
            lVar36 = **(longlong **)(uVar27 + 0x58);
            uVar6 = *(undefined4 *)(uVar27 + 0x50);
            *(undefined4 *)(&stack0x000001b0 + lVar26) = *(undefined4 *)(lVar36 + 0x20);
            *(undefined2 *)(&stack0x000001b4 + lVar26) = *(undefined2 *)(lVar36 + 0x24);
            *(short *)(&stack0x000001b6 + lVar26) = (short)uVar6;
            uVar4 = *(undefined2 *)(*(longlong *)(lVar40 + 0x30) + 0x6b8);
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101460;
            func_0x(&stack0x00000a48 + lVar26,uVar4,&stack0x000001b0 + lVar26);
            *(undefined4 *)((longlong)&uStackX_20 + lVar26 + -0x20) = 1;
            *(undefined4 *)(&stack0xfffffffffffffff8 + lVar26) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff0 + lVar26) = 1;
            *(ulonglong *)(&stack0xffffffffffffffe8 + lVar26) = uVar27 + 0x90;
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101491;
            iVar22 = func_0x(plVar55,&stack0x00000a48 + lVar26);
            iVar20 = 1;
            if (iVar22 < 0) {
              *(undefined4 *)(uVar27 + 0xf0) = 3;
              *(undefined4 *)(uVar27 + 0x50) = 0xffffffff;
              uVar56 = *(ulonglong *)(&stack0x000000d0 + lVar26);
              goto code_r0x00100906;
            }
            if (iVar22 != 1) goto LAB_;
            (&stack0x0000003c)[lVar26] = 1;
          } while( true );
        }
        if (iVar20 == 0) goto LAB_;
        goto code_r0x00100906;
      }
      if (*(int *)(uVar56 + 0x370) == 4) {
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10793e;
        func_0x(uVar56 + 0x2b0);
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10794b;
      func_0x(plVar55,0,0);
      *(uint *)(uVar56 + 0x634) = *(uint *)(uVar56 + 0x634) | 1;
      goto LAB_;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10064b;
    func_0x(plVar55,1);
    if (*(int *)(uVar27 + 0xf0) == 3) goto LAB_;
    *(uint *)(uVar27 + 0x634) = *(uint *)(uVar27 + 0x634) | 1;
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1005ff;
  func_0x(*(undefined8 *)(&stack0x00000178 + lVar26),&stack0x000000c0 + lVar26);
  puVar49 = &stack0xffffffffffffffc8 + lVar26;
LAB_:
  uVar46 = *(ulonglong *)(&stack0x00002a48 + lVar26);
  *(undefined8 *)(puVar49 + -8) = 0x10060e;
  func_0x(uVar46 ^ (ulonglong)puVar2);
  return;
LAB_:
  *(undefined4 *)(uVar27 + 0xf0) = 4;
  lVar40 = *(longlong *)(lVar40 + 0x30);
  if (*(longlong *)(lVar40 + 0x1b28) != 0) {
    uVar21 = *(uint *)(*(longlong *)(uVar27 + 0x100) + 0x10);
    if (((((uVar21 & 1) == 0) || ((uVar21 & 0x40) != 0)) || (*(char *)(lVar40 + 0x1cd2) == '\0')) ||
       (*(char *)(lVar40 + 0x2050) != '\0')) {
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1014f5;
      cVar15 = func_0x(lVar33);
      if (cVar15 != '\0') goto LAB_;
    }
    lVar40 = *(longlong *)(uVar27 + 0x288);
    if (*(ushort *)(uVar27 + 0x50) < *(ushort *)(lVar40 + 0x16)) {
      iVar20 = *(int *)(uVar27 + 0x50);
      lVar33 = 0xfff - (longlong)iVar20;
      *(longlong *)(&stack0x00000120 + lVar26) = lVar33;
      if (*(short *)(lVar40 + lVar33 * 2) != 0) {
        *(int *)(&stack0x000008fc + lVar26) = iVar20;
        if (*(char *)(lVar40 + 2) < '\0') {
          pbVar51 = (byte *)(lVar40 + 0x60);
          if ((*(short *)(&stack0x000008c8 + lVar26) == 0) ||
             (ppbVar28 = *(byte ***)(&stack0x000008d8 + lVar26), ppbVar28 == (byte **)0x0)) {
            *(undefined (*) [16])(&stack0x00000900 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000910 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000920 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000930 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000940 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000950 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000960 + lVar26) = ZEXT816(0);
            *(undefined8 *)(&stack0x00000970 + lVar26) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1015b4;
            ppbVar28 = (byte **)func_0x(&stack0x00000900 + lVar26);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1015cc;
          puVar31 = (undefined4 *)func_0x(lVar40,&stack0x00000a78 + lVar26,0,0);
          if (pbVar51 == *ppbVar28) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1015e0;
            func_0x(puVar31,ppbVar28 + 0xc);
          }
          *ppbVar28 = pbVar51;
          uVar4 = *(undefined2 *)(puVar31 + 2);
          uVar25 = puVar31[1];
          *(undefined4 *)(ppbVar28 + 0xc) = *puVar31;
          *(undefined4 *)((longlong)ppbVar28 + 100) = uVar25;
          *(undefined2 *)(ppbVar28 + 0xd) = uVar4;
          *(undefined4 *)((longlong)ppbVar28 + 0x6c) = *(undefined4 *)(lVar40 + 0x20);
          *(undefined2 *)(ppbVar28 + 0xe) = *(undefined2 *)(lVar40 + 0x24);
          sVar42 = 0;
          *(undefined2 *)((longlong)ppbVar28 + 0x72) = 0;
          bVar38 = *pbVar51;
          *(undefined4 *)(&stack0x00000118 + lVar26) =
               *(undefined4 *)((ulonglong)bVar38 * 6 + 0x15637c0);
          sVar18 = *(short *)((ulonglong)bVar38 * 6 + 0x15637c4);
          *(short *)(&stack0x00000058 + lVar26) = sVar18;
          *(undefined2 *)(ppbVar28 + 2) = 0xffff;
          ppbVar28[3] = (byte *)0x0;
          uVar21 = 0;
          *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
          ppbVar28[7] = (byte *)0x0;
          ppbVar28[4] = (byte *)0x0;
          ppbVar28[9] = (byte *)0x0;
          ppbVar28[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar28 + 0xb) = 0;
          if ((**ppbVar28 & 2) != 0) {
            pbVar1 = pbVar51 + sVar18;
            if ((*pbVar1 & 1) == 0) {
              *(undefined2 *)(ppbVar28 + 2) = 0;
              ppbVar28[3] = pbVar1;
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar28 + 0x36) = 0;
              switch(*pbVar1 & 0xe) {
              default:
                uVar21 = (uint)*(ushort *)(pbVar1 + 2);
                if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101898;
                  func_0x(pbVar1,6);
                }
                break;
              case 4:
                uVar21 = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar21 = 1;
              }
              *(uint *)(ppbVar28 + 4) = uVar21;
              *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
              *puVar2 = *puVar2;
              *(undefined4 *)(&stack0x00000048 + lVar26) =
                   *(undefined4 *)(&stack0x00000048 + lVar26);
              lVar33 = *(longlong *)(&stack0x00000120 + lVar26);
            }
            else {
              *(undefined2 *)(ppbVar28 + 2) = 1;
              uVar25 = *(undefined4 *)(&stack0x000000b8 + lVar26);
              *(undefined4 *)(&stack0x00000048 + lVar26) = uVar25;
              uVar21 = *(uint *)(&stack0x000000a8 + lVar26);
              *puVar2 = uVar21;
              ppbVar28[3] = pbVar1;
              bVar38 = *pbVar1;
              switch(bVar38 & 0x1c) {
              default:
                if ((char)pbVar1[1] < '\0') {
                  uVar43 = *(ushort *)(pbVar1 + 1);
                  *(ushort *)((longlong)ppbVar28 + 0x12) = uVar43;
                  sVar18 = 3;
                  uVar43 = (uVar43 & 0x7f) << 8 | uVar43 >> 8;
                }
                else {
                  sVar18 = 2;
                  uVar43 = (ushort)pbVar1[1];
                }
                *(ushort *)((longlong)ppbVar28 + 0x12) = uVar43;
                *(short *)(ppbVar28 + 5) = sVar18;
                *(short *)((longlong)ppbVar28 + 0x2c) =
                     (short)(*(ushort *)((longlong)ppbVar28 + 0x12) + 1 >> 1) + sVar18;
                if (0x1e < *(ushort *)((longlong)ppbVar28 + 0x12)) {
                  iVar20 = *(ushort *)((longlong)ppbVar28 + 0x12) - 1;
                  sVar42 = ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                           (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                }
                *(short *)((longlong)ppbVar28 + 0x2a) = sVar42;
                *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                *(undefined4 *)(ppbVar28 + 8) = 0;
                *(undefined4 *)(&stack0x00000048 + lVar26) = uVar25;
                *puVar2 = uVar21;
                ppbVar28[7] = (byte *)0x0;
                ppbVar28[4] = (byte *)0x0;
                break;
              case 4:
                if (((bVar38 & 0x1c) == 4) && ((bVar38 & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101797;
                  func_0x((longlong)ppbVar28 + 0x12);
                  ppbVar28[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0xf;
                  *(undefined4 *)(ppbVar28 + 8) = 0;
                  *(undefined4 *)(ppbVar28 + 8) = 1;
                  ppbVar28[7] = (byte *)0x0;
                  ppbVar28[4] = (byte *)0x0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1017cb;
                  func_0x((longlong)ppbVar28 + 0x12);
                  ppbVar28[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar28 + 0x14) = 1;
                  *puVar2 = *(uint *)(&stack0x000000a8 + lVar26);
                  *(undefined4 *)(&stack0x00000048 + lVar26) =
                       *(undefined4 *)(&stack0x000000b8 + lVar26);
                  *(undefined4 *)(ppbVar28 + 8) = 0;
                  ppbVar28[7] = (byte *)0x0;
                  ppbVar28[4] = (byte *)0x0;
                }
                break;
              case 8:
                *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101769;
                func_0x((longlong)ppbVar28 + 0x12);
                ppbVar28[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar28 + 0x14) = 9;
                *(undefined4 *)(ppbVar28 + 8) = 0;
                *(undefined4 *)(&stack0x00000048 + lVar26) =
                     *(undefined4 *)(&stack0x000000b8 + lVar26);
                *puVar2 = *(uint *)(&stack0x000000a8 + lVar26);
                ppbVar28[7] = (byte *)0x0;
                ppbVar28[4] = (byte *)0x0;
              }
            }
            sVar18 = *(short *)(&stack0x00000058 + lVar26);
          }
          if ((**ppbVar28 & 4) != 0) {
            if (*(short *)(&stack0x0000011a + lVar26) == 0) {
              uVar46 = (ulonglong)sVar18;
            }
            else {
              uVar46 = (ulonglong)
                       *(ushort *)
                        (lVar40 + 0x61 + (longlong)*(short *)(&stack0x0000011a + lVar26) * 2);
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10192a;
            func_0x(ppbVar28 + 9,pbVar51 + uVar46);
          }
          pbVar51 = ppbVar28[1];
          if (pbVar51 != (byte *)0x0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10193e;
            func_0x(pbVar51,ppbVar28);
          }
          uVar46 = (ulonglong)*puVar2;
        }
        else {
          ppbVar28 = (byte **)0x0;
        }
        uVar21 = (uint)*(ushort *)(lVar40 + 0xe);
        pbVar51 = (byte *)((ulonglong)*(ushort *)(lVar40 + lVar33 * 2) + lVar40);
        bVar38 = *pbVar51;
        *(byte **)(&stack0x000008d0 + lVar26) = pbVar51;
        if ((bVar38 & 1) == 0) {
          *(undefined2 *)(&stack0x000008c8 + lVar26) = 0;
          *(undefined4 *)(&stack0x000008cc + lVar26) = 0;
          *(undefined4 *)(&stack0x000008ee + lVar26) = 0;
          switch(*pbVar51 & 0xe) {
          default:
            uVar21 = (uint)*(ushort *)(pbVar51 + 2);
            if (0x1f9d < *(ushort *)(pbVar51 + 2) - 1) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101bc6;
              func_0x(pbVar51,6);
            }
            break;
          case 4:
            uVar21 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar21 = 1;
          }
          *(uint *)(&stack0x000008d8 + lVar26) = uVar21;
          *(longlong *)(&stack0x000008e6 + lVar26) = lVar40 + 0x2000;
        }
        else {
          *(undefined2 *)(&stack0x000008c8 + lVar26) = 1;
          bVar38 = *pbVar51;
          switch(bVar38 & 0x1c) {
          default:
            if ((char)pbVar51[1] < '\0') {
              uVar43 = (*(ushort *)(pbVar51 + 1) & 0x7f) << 8 | *(ushort *)(pbVar51 + 1) >> 8;
              *(ushort *)(&stack0x000008ca + lVar26) = uVar43;
              sVar18 = 3;
              *(undefined2 *)(&stack0x000008e0 + lVar26) = 3;
            }
            else {
              uVar43 = (ushort)pbVar51[1];
              *(ushort *)(&stack0x000008ca + lVar26) = uVar43;
              sVar18 = 2;
              *(undefined2 *)(&stack0x000008e0 + lVar26) = 2;
            }
            *(short *)(&stack0x000008e4 + lVar26) = (short)(uVar43 + 1 >> 1) + sVar18;
            if (uVar43 < 0x1f) {
              *(undefined2 *)(&stack0x000008e2 + lVar26) = 0;
              *(undefined4 *)(&stack0x000008cc + lVar26) = 0;
              *(undefined4 *)(&stack0x000008f8 + lVar26) = 0;
              *(longlong *)(&stack0x000008f0 + lVar26) = lVar40 + 0x2000;
              *(byte ***)(&stack0x000008d8 + lVar26) = ppbVar28;
            }
            else {
              iVar20 = uVar43 - 1;
              *(short *)(&stack0x000008e2 + lVar26) =
                   ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                   (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
              *(undefined4 *)(&stack0x000008cc + lVar26) = 0;
              *(undefined4 *)(&stack0x000008f8 + lVar26) = 0;
              *(longlong *)(&stack0x000008f0 + lVar26) = lVar40 + 0x2000;
              *(byte ***)(&stack0x000008d8 + lVar26) = ppbVar28;
            }
            break;
          case 4:
            if (((bVar38 & 0x1c) == 4) && ((bVar38 & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101acb;
              func_0x(&stack0x000008ca + lVar26);
              *(byte **)(&stack0x000008d0 + lVar26) = pbVar51;
              *(undefined4 *)(&stack0x000008cc + lVar26) = 0xf;
              *(undefined4 *)(&stack0x000008f8 + lVar26) = 1;
              *(longlong *)(&stack0x000008f0 + lVar26) = lVar40 + 0x2000;
              *(byte ***)(&stack0x000008d8 + lVar26) = ppbVar28;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101b08;
              func_0x(&stack0x000008ca + lVar26);
              *(byte **)(&stack0x000008d0 + lVar26) = pbVar51;
              *(undefined4 *)(&stack0x000008cc + lVar26) = 1;
              *(undefined4 *)(&stack0x000008f8 + lVar26) = 0;
              *(longlong *)(&stack0x000008f0 + lVar26) = lVar40 + 0x2000;
              *(byte ***)(&stack0x000008d8 + lVar26) = ppbVar28;
            }
            break;
          case 8:
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101a7e;
            func_0x(&stack0x000008ca + lVar26);
            *(byte **)(&stack0x000008d0 + lVar26) = pbVar51;
            *(undefined4 *)(&stack0x000008cc + lVar26) = 9;
            *(undefined4 *)(&stack0x000008f8 + lVar26) = 0;
            *(longlong *)(&stack0x000008f0 + lVar26) = lVar40 + 0x2000;
            *(byte ***)(&stack0x000008d8 + lVar26) = ppbVar28;
          }
        }
        iVar20 = 1;
        if (*(short *)(&stack0x000008c8 + lVar26) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101c37;
          func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101c3e;
          func_0x(&stack0x000008ca + lVar26,&stack0x00000164 + lVar26);
        }
        *(undefined4 *)(&stack0x000000e4 + lVar26) = *(undefined4 *)(&stack0x00000164 + lVar26);
        *(undefined2 *)(&stack0x000000e8 + lVar26) = *(undefined2 *)(&stack0x00000168 + lVar26);
        *(undefined4 *)(&stack0x00000188 + lVar26) = *(undefined4 *)(&stack0x00000164 + lVar26);
        *(undefined2 *)(&stack0x0000018c + lVar26) = *(undefined2 *)(&stack0x00000168 + lVar26);
        lVar40 = *(longlong *)(&stack0x000000f8 + lVar26);
        uVar29 = *(undefined8 *)(lVar40 + 0x30);
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101c7c;
        cVar15 = func_0x(uVar29,&stack0x00000188 + lVar26);
        if (cVar15 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101c91;
          cVar15 = func_0x(lVar40,3);
          if (cVar15 == '\0') {
            *(undefined4 *)(uVar27 + 0xf0) = 3;
            *(undefined4 *)(uVar27 + 0x50) = 0xffffffff;
            uVar56 = *(ulonglong *)(&stack0x000000d0 + lVar26);
            goto code_r0x00100906;
          }
        }
      }
    }
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101ca6;
  func_0x(plVar55);
  uVar46 = (ulonglong)*(uint *)(uVar27 + 0x268);
  *puVar2 = *(uint *)(uVar27 + 0x268);
  uVar25 = *(undefined4 *)(uVar27 + 0x26c);
  *(undefined4 *)(&stack0x00000048 + lVar26) = uVar25;
  iVar20 = 0;
  uVar56 = *(ulonglong *)(&stack0x000000d0 + lVar26);
  iVar22 = *(int *)(&stack0x000000c8 + lVar26);
LAB_:
  if ((int)uVar46 != 3) {
code_r0x00100906:
    iVar22 = *(int *)(&stack0x00000048 + lVar26);
    goto LAB_;
  }
  bVar58 = false;
  if (*(char *)(*(longlong *)(uVar56 + 0x28) + 0x29) == '\0') {
    lVar40 = *(longlong *)(*(longlong *)(uVar56 + 0x20) + 0x18);
    if ((*(int *)(lVar40 + 0x1c) != 0) &&
       ((((*(char *)(lVar40 + 1) != '\x01' && (*(char *)(lVar40 + 1) != '\b')) ||
         (*(char *)(lVar40 + 2) != '\0')) || (*(char *)(lVar40 + 3) != '\0')))) {
      *(undefined8 *)(&stack0x00000108 + lVar26) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101e39;
      func_0x(uVar56,1);
LAB_:
      if (*(longlong *)(uVar56 + 0x2d8) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101e59;
        func_0x(uVar56 + 0x2b0,0);
      }
      if (*(int *)(uVar56 + 0x4f0) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101e72;
        func_0x(uVar56 + 0x2b0,1);
      }
      iVar22 = *(int *)(uVar56 + 0x4ec);
      *(int *)(&stack0x00000048 + lVar26) = iVar22;
LAB_:
      *(uint *)(uVar56 + 0x634) = *(uint *)(uVar56 + 0x634) | 1;
      uVar21 = *(uint *)(uVar56 + 0x634);
      if (((iVar20 != 0) || ((int)uVar46 == 1)) || (iVar22 == 0)) goto LAB_;
      puVar31 = *(undefined4 **)(&stack0x00000128 + lVar26);
      lVar40 = *(longlong *)(&stack0x000000c0 + lVar26);
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100951;
      func_0x(lVar40,puVar31,0,1);
      if ((int)uVar46 != 4) goto LAB_;
      *(undefined4 *)(&stack0x00000880 + lVar26) = *puVar31;
      *(undefined2 *)(&stack0x00000884 + lVar26) = *(undefined2 *)(puVar31 + 1);
      *(undefined2 *)(&stack0x00000886 + lVar26) = 0;
      *(undefined8 *)(&stack0x00000878 + lVar26) = 0;
      *(undefined4 *)(&stack0x00000894 + lVar26) = 0;
      *(undefined8 *)(&stack0x00000888 + lVar26) = 0;
      *(undefined2 *)(&stack0x00000890 + lVar26) = 0;
      puVar30 = *(undefined8 **)(*(longlong *)(&stack0x00000178 + lVar26) + 0x2d8);
      *(undefined **)(&stack0xffffffffffffffe8 + lVar26) = &stack0x000001e8 + lVar26;
      uVar29 = *puVar30;
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1009cc;
      iVar20 = func_0x(uVar29,&stack0x00000878 + lVar26,3);
      if (iVar20 == 0) goto LAB_;
      plVar55 = (longlong *)(lVar40 + 0x30);
      lVar33 = CONCAT44(uRam0000000001e8726c,_DAT_);
      if ((*(longlong *)(lVar40 + 0x40) != lVar33) ||
         (lVar36 = CONCAT44(uRam0000000001e87274,_DAT_),
         *(longlong *)(lVar40 + 0x48) != lVar36)) {
        if ((*(byte *)(lVar40 + 0xa0) & 2) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100a05;
          iVar20 = func_0x(lVar40 + 0xa8);
          if (iVar20 != 0) {
            *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
          }
        }
        *(undefined *)(lVar40 + 0xa0) = 0;
        *(undefined4 *)(lVar40 + 0x9c) = 0;
        *(undefined4 *)(lVar40 + 0xb8) = 0;
        if ((*(byte *)(lVar40 + 0xd0) & 2) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100a34;
          iVar20 = func_0x(lVar40 + 0xd8);
          if (iVar20 != 0) {
            *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
          }
        }
        *(undefined *)(lVar40 + 0xd0) = 0;
        *(undefined4 *)(lVar40 + 0xcc) = 0;
        *(undefined4 *)(lVar40 + 0xe8) = 0;
        if (*(longlong *)(lVar40 + 0x58) != 0) {
          *(undefined *)(lVar40 + 0x66) = 0;
          *(undefined8 *)(lVar40 + 0x58) = 0;
          *(undefined2 *)(lVar40 + 100) = 0;
          *(undefined4 *)(*(longlong *)(lVar40 + 0x40) + 0x48) = 0;
        }
        uVar29 = *(undefined8 *)*plVar55;
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x100a7e;
        func_0x(uVar29,lVar40 + 0x40);
        uVar13 = uRam0000000001e87274;
        uVar6 = _DAT_;
        uVar25 = uRam0000000001e8726c;
        *(undefined4 *)(lVar40 + 0x40) = _DAT_;
        *(undefined4 *)(lVar40 + 0x44) = uVar25;
        *(undefined4 *)(lVar40 + 0x48) = uVar6;
        *(undefined4 *)(lVar40 + 0x4c) = uVar13;
        *(undefined4 *)(lVar40 + 0x50) = 0xffffffff;
        *(undefined4 *)(lVar40 + 0x270) = 0;
        *(undefined8 *)(lVar40 + 0x288) = 0;
        *(undefined8 *)(lVar40 + 0x280) = 0;
        *(undefined8 *)(lVar40 + 0x290) = 0;
        *(undefined4 *)(lVar40 + 0x2a0) = 0xffffffff;
        *(undefined2 *)(lVar40 + 0x2a4) = 0xffff;
        *(undefined8 *)(lVar40 + 0x2a6) = 0;
        *(undefined4 *)(lVar40 + 0xf0) = 2;
        lVar36 = CONCAT44(uRam0000000001e87274,_DAT_);
        lVar33 = CONCAT44(uRam0000000001e8726c,_DAT_);
      }
      lVar35 = *(longlong *)(&stack0x000000c0 + lVar26);
      if ((*(longlong *)(lVar35 + 0x2c0) != lVar33) || (*(longlong *)(lVar35 + 0x2c8) != lVar36)) {
        if ((*(byte *)(lVar35 + 800) & 2) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101ec1;
          iVar20 = func_0x(lVar35 + 0x328);
          if (iVar20 != 0) {
            plVar7 = (longlong *)(*(longlong *)(lVar35 + 0x2b0) + 0x30);
            *plVar7 = *plVar7 + -1;
          }
        }
        *(undefined *)(lVar35 + 800) = 0;
        *(undefined4 *)(lVar35 + 0x31c) = 0;
        *(undefined4 *)(lVar35 + 0x338) = 0;
        if ((*(byte *)(lVar35 + 0x350) & 2) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101efa;
          iVar20 = func_0x(lVar35 + 0x358);
          if (iVar20 != 0) {
            plVar7 = (longlong *)(*(longlong *)(lVar35 + 0x2b0) + 0x30);
            *plVar7 = *plVar7 + -1;
          }
        }
        *(undefined *)(lVar35 + 0x350) = 0;
        *(undefined4 *)(lVar35 + 0x34c) = 0;
        *(undefined4 *)(lVar35 + 0x368) = 0;
        if (*(longlong *)(lVar35 + 0x2d8) != 0) {
          *(undefined *)(lVar35 + 0x2e6) = 0;
          *(undefined8 *)(lVar35 + 0x2d8) = 0;
          *(undefined2 *)(lVar35 + 0x2e4) = 0;
          *(undefined4 *)(*(longlong *)(lVar35 + 0x2c0) + 0x48) = 0;
        }
        uVar29 = **(undefined8 **)(lVar35 + 0x2b0);
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101f5e;
        func_0x(uVar29,lVar35 + 0x2c0);
        uVar13 = uRam0000000001e87274;
        uVar6 = _DAT_;
        uVar25 = uRam0000000001e8726c;
        *(undefined4 *)(lVar35 + 0x2c0) = _DAT_;
        *(undefined4 *)(lVar35 + 0x2c4) = uVar25;
        *(undefined4 *)(lVar35 + 0x2c8) = uVar6;
        *(undefined4 *)(lVar35 + 0x2cc) = uVar13;
        *(undefined4 *)(lVar35 + 0x2d0) = 0xffffffff;
        *(undefined4 *)(lVar35 + 0x4f0) = 0;
        *(undefined8 *)(lVar35 + 0x508) = 0;
        *(undefined8 *)(lVar35 + 0x500) = 0;
        *(undefined8 *)(lVar35 + 0x510) = 0;
        *(undefined4 *)(lVar35 + 0x520) = 0xffffffff;
        *(undefined2 *)(lVar35 + 0x524) = 0xffff;
        *(undefined8 *)(lVar35 + 0x526) = 0;
        *(undefined4 *)(lVar35 + 0x370) = 2;
      }
      lVar33 = *(longlong *)(&stack0x000000c0 + lVar26);
      *(undefined4 *)(lVar33 + 0x634) = 0;
      (&stack0x00000876)[lVar26] = 1;
      uVar29 = *(undefined8 *)*plVar55;
      plVar7 = *(longlong **)(*(longlong *)(lVar40 + 0x38) + 8);
      uVar25 = *(undefined4 *)(&stack0x000001ec + lVar26);
      uVar6 = *(undefined4 *)(&stack0x000001f0 + lVar26);
      uVar13 = *(undefined4 *)(&stack0x000001f4 + lVar26);
      *(undefined4 *)(lVar40 + 0x40) = *(undefined4 *)(&stack0x000001e8 + lVar26);
      *(undefined4 *)(lVar40 + 0x44) = uVar25;
      *(undefined4 *)(lVar40 + 0x48) = uVar6;
      *(undefined4 *)(lVar40 + 0x4c) = uVar13;
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101fea;
      func_0x(uVar29,lVar40 + 0x40,lVar40 + 0x58);
      *(undefined8 *)(lVar40 + 0x288) = **(undefined8 **)(lVar40 + 0x58);
      *(undefined4 *)(lVar40 + 0x88) = 3;
      *(undefined4 *)(lVar40 + 0x29c) = 0;
      lVar36 = *(longlong *)(*plVar55 + 0x18);
      uVar21 = *(uint *)(*(longlong *)(lVar40 + 0x100) + 0x10);
      if (((((uVar21 & 1) != 0) && ((uVar21 & 0x40) == 0)) &&
          (lVar35 = plVar7[6], *(char *)(lVar35 + 0x1cd2) != '\0')) &&
         (*(char *)(lVar35 + 0x2050) == '\0')) {
        uVar25 = *(undefined4 *)(*(longlong *)(lVar40 + 0x40) + 0x90);
        uVar4 = *(undefined2 *)(*(longlong *)(lVar40 + 0x40) + 0x94);
        uVar5 = *(undefined2 *)(lVar35 + 0x6b8);
        (&stack0x00000876)[lVar26] = 6;
        *(undefined2 *)(&stack0x00000874 + lVar26) = uVar5;
        *(undefined8 *)(&stack0x0000086c + lVar26) = 0;
        *(undefined4 *)(&stack0x00000868 + lVar26) = uVar25;
        *(undefined2 *)(&stack0x0000086c + lVar26) = uVar4;
        uVar29 = *(undefined8 *)(*(longlong *)(lVar40 + 0x38) + 8);
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10209f;
        cVar15 = func_0x(uVar29,CONCAT71((uint7)(byte)((ushort)uVar4 >> 8),6),
                                 &stack0x00000868 + lVar26);
        if (cVar15 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1020ab;
          func_0x(plVar55);
          lVar35 = *(longlong *)(*plVar55 + 0x18);
          lVar39 = *(longlong *)(lVar40 + 0x38);
          (&stack0xffffffffffffffe8)[lVar26] = 1;
          uVar25 = *(undefined4 *)(lVar35 + 0x18);
          uVar29 = *(undefined8 *)(lVar39 + 8);
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1020d1;
          func_0x(uVar29,6,uVar25);
        }
      }
      if (*(char *)(lVar36 + 2) == '\0') {
LAB_:
        *(undefined4 *)(lVar40 + 0xf0) = 3;
        if (*(longlong *)(lVar40 + 0x58) != 0) {
LAB_:
          uVar21 = *(uint *)(lVar33 + 0x634);
          *(uint *)(lVar33 + 0x634) = uVar21 | 1;
          iVar23 = (int)*(short *)(*(longlong *)(&stack0x00000128 + lVar26) + 6);
          *(int *)(&stack0x000000dc + lVar26) = iVar23;
          lVar40 = *(longlong *)(&stack0x000000c0 + lVar26);
          *(longlong *)(&stack0x000000d0 + lVar26) = lVar40;
          iVar22 = 0;
          *(undefined4 *)(&stack0x000000c8 + lVar26) = 0;
          *(uint *)(lVar33 + 0x634) = uVar21 & 0xfffffffe;
          iVar20 = *(int *)(&stack0x000000bc + lVar26);
          uVar21 = *puVar2;
LAB_:
          *puVar2 = uVar21;
          lVar33 = *(longlong *)(&stack0x000000c0 + lVar26);
          if ((*(int *)(lVar33 + 0x370) == 4) &&
             ((*(longlong *)(lVar33 + 0x2c0) != CONCAT44(uRam0000000001e8726c,_DAT_) ||
              (*(longlong *)(lVar33 + 0x2c8) != CONCAT44(uRam0000000001e87274,_DAT_))))) {
            if ((*(byte *)(lVar33 + 800) & 2) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102363;
              iVar24 = func_0x(lVar33 + 0x328);
              if (iVar24 != 0) {
                plVar55 = (longlong *)(*(longlong *)(lVar33 + 0x2b0) + 0x30);
                *plVar55 = *plVar55 + -1;
              }
            }
            *(undefined *)(lVar33 + 800) = 0;
            *(undefined4 *)(lVar33 + 0x31c) = 0;
            *(undefined4 *)(lVar33 + 0x338) = 0;
            if ((*(byte *)(lVar33 + 0x350) & 2) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10239e;
              iVar24 = func_0x(lVar33 + 0x358);
              if (iVar24 != 0) {
                plVar55 = (longlong *)(*(longlong *)(lVar33 + 0x2b0) + 0x30);
                *plVar55 = *plVar55 + -1;
              }
            }
            *(undefined *)(lVar33 + 0x350) = 0;
            *(undefined4 *)(lVar33 + 0x34c) = 0;
            *(undefined4 *)(lVar33 + 0x368) = 0;
            if (*(longlong *)(lVar33 + 0x2d8) != 0) {
              *(undefined *)(lVar33 + 0x2e6) = 0;
              *(undefined8 *)(lVar33 + 0x2d8) = 0;
              *(undefined2 *)(lVar33 + 0x2e4) = 0;
              *(undefined4 *)(*(longlong *)(lVar33 + 0x2c0) + 0x48) = 0;
            }
            uVar29 = **(undefined8 **)(lVar33 + 0x2b0);
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102405;
            func_0x(uVar29,lVar33 + 0x2c0);
            uVar13 = uRam0000000001e87274;
            uVar6 = _DAT_;
            uVar25 = uRam0000000001e8726c;
            *(undefined4 *)(lVar33 + 0x2c0) = _DAT_;
            *(undefined4 *)(lVar33 + 0x2c4) = uVar25;
            *(undefined4 *)(lVar33 + 0x2c8) = uVar6;
            *(undefined4 *)(lVar33 + 0x2cc) = uVar13;
            *(undefined4 *)(lVar33 + 0x2d0) = 0xffffffff;
            *(undefined4 *)(lVar33 + 0x4f0) = 0;
            *(undefined8 *)(lVar33 + 0x508) = 0;
            *(undefined8 *)(lVar33 + 0x500) = 0;
            *(undefined8 *)(lVar33 + 0x510) = 0;
            *(undefined4 *)(lVar33 + 0x520) = 0xffffffff;
            *(undefined2 *)(lVar33 + 0x524) = 0xffff;
            *(undefined8 *)(lVar33 + 0x526) = 0;
            *(undefined4 *)(lVar33 + 0x370) = 2;
          }
          if (iVar22 < 1) {
            if (iVar22 == 0) goto LAB_;
            uVar21 = *puVar2;
          }
          else {
            lVar33 = *(longlong *)(&stack0x000000c0 + lVar26);
            if (*(longlong *)(lVar33 + 0x58) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102488;
              func_0x(lVar33 + 0x30,0);
            }
            if (*(int *)(lVar33 + 0x270) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10249f;
              func_0x(lVar33 + 0x30,1);
            }
            uVar21 = *(uint *)(lVar33 + 0x268);
          }
          if (*(char *)(*(longlong *)(*(longlong *)(&stack0x000000c0 + lVar26) + 0x28) + 0x29) !=
              '\0') {
LAB_:
            lVar40 = *(longlong *)(&stack0x000000c0 + lVar26);
            plVar55 = (longlong *)(lVar40 + 0x30);
            lVar33 = *(longlong *)(*(longlong *)(lVar40 + 0x38) + 8);
            *(longlong *)(&stack0x000000f8 + lVar26) = lVar33;
            *(undefined2 *)(&stack0x00000978 + lVar26) = 0xffff;
            *(undefined8 *)(&stack0x00000980 + lVar26) = 0;
            *(undefined4 *)(&stack0x0000097c + lVar26) = 0;
            *(undefined8 *)(&stack0x00000996 + lVar26) = 0;
            *(undefined8 *)(&stack0x000009a0 + lVar26) = 0;
            *(undefined8 *)(&stack0x00000988 + lVar26) = 0;
            *(undefined4 *)(&stack0x000009ac + lVar26) = 0xffffffff;
            *(undefined4 *)(&stack0x000000ec + lVar26) = 0;
            *(undefined2 *)(&stack0x000000f0 + lVar26) = 0;
            lVar36 = *(longlong *)(*plVar55 + 0x18);
            *(longlong *)(&stack0x00000130 + lVar26) = lVar36;
            (&stack0x0000003c)[lVar26] = 0;
            if ((*(byte *)(lVar40 + 0xa0) & 2) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10255b;
              iVar20 = func_0x(lVar40 + 0xa8);
              if (iVar20 != 0) {
                *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
              }
            }
            *(undefined *)(lVar40 + 0xa0) = 0;
            *(undefined4 *)(lVar40 + 0x9c) = 0;
            *(undefined4 *)(lVar40 + 0xb8) = 0;
            *(int *)(lVar40 + 0x50) = iVar23;
            uVar21 = *(uint *)(*(longlong *)(lVar40 + 0x100) + 0x10);
            if ((((uVar21 & 1) != 0) && ((uVar21 & 0x40) == 0)) &&
               ((*(char *)(*(longlong *)(lVar33 + 0x30) + 0x1cd2) != '\0' &&
                (*(char *)(*(longlong *)(lVar33 + 0x30) + 0x2050) == '\0')))) {
              (&stack0x00000a46)[lVar26] = 1;
              lVar35 = **(longlong **)(lVar40 + 0x58);
              uVar25 = *(undefined4 *)(lVar40 + 0x50);
              *(undefined4 *)(&stack0x000001b8 + lVar26) = *(undefined4 *)(lVar35 + 0x20);
              *(undefined2 *)(&stack0x000001bc + lVar26) = *(undefined2 *)(lVar35 + 0x24);
              *(short *)(&stack0x000001be + lVar26) = (short)uVar25;
              uVar4 = *(undefined2 *)(*(longlong *)(lVar33 + 0x30) + 0x6b8);
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10260a;
              func_0x(&stack0x00000a38 + lVar26,uVar4,&stack0x000001b8 + lVar26);
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10261e;
              cVar15 = func_0x(lVar33,3,&stack0x00000a38 + lVar26);
              if (cVar15 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10262a;
                func_0x(plVar55);
                lVar35 = *(longlong *)(*plVar55 + 0x18);
                (&stack0xffffffffffffffe8)[lVar26] = 1;
                uVar25 = *(undefined4 *)(lVar35 + 0x18);
                *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10264c;
                func_0x(lVar33,3,uVar25);
                if (*(longlong *)(lVar40 + 0x58) == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10265e;
                  func_0x(plVar55,0);
                }
              }
            }
            *(int *)(&stack0x00000098 + lVar26) = _DAT_;
            *(undefined2 *)(&stack0x000000b8 + lVar26) = _DAT_;
            iVar20 = _DAT_;
            do {
              ppbVar28 = (byte **)0x0;
              if (((*(char *)(*(longlong *)(lVar40 + 0x38) + 0x29) != '\0') &&
                  ((*(uint *)(lVar36 + 4) & 0x140) == 0)) &&
                 (lVar35 = *(longlong *)(lVar40 + 0x288),
                 *(ushort *)(lVar40 + 0x50) < *(ushort *)(lVar35 + 0x16))) {
                iVar22 = *(int *)(lVar40 + 0x50);
                lVar39 = (longlong)iVar22;
                *(longlong *)(&stack0x00000120 + lVar26) = lVar39;
                if (*(short *)(lVar35 + (0xfff - lVar39) * 2) != 0) {
                  *(int *)(&stack0x000009ac + lVar26) = iVar22;
                  if (*(char *)(lVar35 + 2) < '\0') {
                    pbVar51 = (byte *)(lVar35 + 0x60);
                    if ((*(short *)(&stack0x00000978 + lVar26) == 0) ||
                       (ppbVar28 = *(byte ***)(&stack0x00000988 + lVar26), ppbVar28 == (byte **)0x0)
                       ) {
                      *(undefined (*) [16])(&stack0x000009b0 + lVar26) = ZEXT816(0);
                      *(undefined (*) [16])(&stack0x000009c0 + lVar26) = ZEXT816(0);
                      *(undefined (*) [16])(&stack0x000009d0 + lVar26) = ZEXT816(0);
                      *(undefined (*) [16])(&stack0x000009e0 + lVar26) = ZEXT816(0);
                      *(undefined (*) [16])(&stack0x000009f0 + lVar26) = ZEXT816(0);
                      *(undefined (*) [16])(&stack0x00000a00 + lVar26) = ZEXT816(0);
                      *(undefined (*) [16])(&stack0x00000a10 + lVar26) = ZEXT816(0);
                      *(undefined8 *)(&stack0x00000a20 + lVar26) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102754;
                      ppbVar28 = (byte **)func_0x(&stack0x000009b0 + lVar26);
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10276c;
                    puVar31 = (undefined4 *)
                              func_0x(lVar35,&stack0x00000a88 + lVar26,0);
                    if (pbVar51 == *ppbVar28) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102780;
                      func_0x(puVar31,ppbVar28 + 0xc);
                    }
                    *ppbVar28 = pbVar51;
                    uVar4 = *(undefined2 *)(puVar31 + 2);
                    uVar25 = puVar31[1];
                    *(undefined4 *)(ppbVar28 + 0xc) = *puVar31;
                    *(undefined4 *)((longlong)ppbVar28 + 100) = uVar25;
                    *(undefined2 *)(ppbVar28 + 0xd) = uVar4;
                    *(undefined4 *)((longlong)ppbVar28 + 0x6c) = *(undefined4 *)(lVar35 + 0x20);
                    *(undefined2 *)(ppbVar28 + 0xe) = *(undefined2 *)(lVar35 + 0x24);
                    *(undefined2 *)((longlong)ppbVar28 + 0x72) = 0;
                    bVar38 = *pbVar51;
                    *(undefined4 *)(&stack0x00000118 + lVar26) =
                         *(undefined4 *)((ulonglong)bVar38 * 6 + 0x15637c0);
                    sVar18 = *(short *)((ulonglong)bVar38 * 6 + 0x15637c4);
                    *(short *)(&stack0x00000058 + lVar26) = sVar18;
                    *(undefined2 *)(ppbVar28 + 2) = 0xffff;
                    ppbVar28[3] = (byte *)0x0;
                    uVar21 = 0;
                    *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                    *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
                    ppbVar28[7] = (byte *)0x0;
                    ppbVar28[4] = (byte *)0x0;
                    ppbVar28[9] = (byte *)0x0;
                    ppbVar28[10] = (byte *)0x0;
                    *(undefined2 *)(ppbVar28 + 0xb) = 0;
                    if ((**ppbVar28 & 2) != 0) {
                      pbVar1 = pbVar51 + sVar18;
                      if ((*pbVar1 & 1) == 0) {
                        *(undefined2 *)(ppbVar28 + 2) = 0;
                        ppbVar28[3] = pbVar1;
                        *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                        *(undefined4 *)((longlong)ppbVar28 + 0x36) = 0;
                        switch(*pbVar1 & 0xe) {
                        default:
                          uVar21 = (uint)*(ushort *)(pbVar1 + 2);
                          if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102a0c;
                            func_0x(pbVar1,6);
                          }
                          break;
                        case 4:
                          uVar21 = 9;
                          break;
                        case 6:
                        case 10:
                          break;
                        case 0xe:
                          uVar21 = 1;
                        }
                        *(uint *)(ppbVar28 + 4) = uVar21;
                        *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
                        lVar39 = *(longlong *)(&stack0x00000120 + lVar26);
                      }
                      else {
                        *(undefined2 *)(ppbVar28 + 2) = 1;
                        ppbVar28[3] = pbVar1;
                        bVar38 = *pbVar1;
                        switch(bVar38 & 0x1c) {
                        default:
                          if ((char)pbVar1[1] < '\0') {
                            uVar43 = *(ushort *)(pbVar1 + 1);
                            *(ushort *)((longlong)ppbVar28 + 0x12) = uVar43;
                            sVar18 = 3;
                            uVar43 = (uVar43 & 0x7f) << 8 | uVar43 >> 8;
                          }
                          else {
                            sVar18 = 2;
                            uVar43 = (ushort)pbVar1[1];
                          }
                          *(ushort *)((longlong)ppbVar28 + 0x12) = uVar43;
                          *(short *)(ppbVar28 + 5) = sVar18;
                          *(short *)((longlong)ppbVar28 + 0x2c) =
                               (short)(*(ushort *)((longlong)ppbVar28 + 0x12) + 1 >> 1) + sVar18;
                          if (*(ushort *)((longlong)ppbVar28 + 0x12) < 0x1f) {
                            *(undefined2 *)((longlong)ppbVar28 + 0x2a) = 0;
                            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                            *(undefined4 *)(ppbVar28 + 8) = 0;
                            ppbVar28[7] = (byte *)0x0;
                            ppbVar28[4] = (byte *)0x0;
                          }
                          else {
                            iVar20 = *(ushort *)((longlong)ppbVar28 + 0x12) - 1;
                            *(short *)((longlong)ppbVar28 + 0x2a) =
                                 ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                                 (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                            *(undefined4 *)(ppbVar28 + 8) = 0;
                            ppbVar28[7] = (byte *)0x0;
                            ppbVar28[4] = (byte *)0x0;
                          }
                          break;
                        case 4:
                          if (((bVar38 & 0x1c) == 4) && ((bVar38 & 2) != 0)) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10292e;
                            func_0x((longlong)ppbVar28 + 0x12);
                            ppbVar28[3] = pbVar1;
                            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0xf;
                            *(undefined4 *)(ppbVar28 + 8) = 0;
                            *(undefined4 *)(ppbVar28 + 8) = 1;
                            ppbVar28[7] = (byte *)0x0;
                            ppbVar28[4] = (byte *)0x0;
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102962;
                            func_0x((longlong)ppbVar28 + 0x12);
                            ppbVar28[3] = pbVar1;
                            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 1;
                            *(undefined4 *)(ppbVar28 + 8) = 0;
                            ppbVar28[7] = (byte *)0x0;
                            ppbVar28[4] = (byte *)0x0;
                          }
                          break;
                        case 8:
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1028f4;
                          func_0x((longlong)ppbVar28 + 0x12);
                          ppbVar28[3] = pbVar1;
                          *(undefined4 *)((longlong)ppbVar28 + 0x14) = 9;
                          *(undefined4 *)(ppbVar28 + 8) = 0;
                          ppbVar28[7] = (byte *)0x0;
                          ppbVar28[4] = (byte *)0x0;
                        }
                      }
                      sVar18 = *(short *)(&stack0x00000058 + lVar26);
                    }
                    if ((**ppbVar28 & 4) != 0) {
                      uVar46 = (ulonglong)sVar18;
                      if (*(short *)(&stack0x0000011a + lVar26) != 0) {
                        uVar46 = (ulonglong)
                                 *(ushort *)
                                  (lVar35 + 0x61 +
                                  (longlong)*(short *)(&stack0x0000011a + lVar26) * 2);
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102a8d;
                      func_0x(ppbVar28 + 9,pbVar51 + uVar46);
                    }
                    pbVar51 = ppbVar28[1];
                    if (pbVar51 != (byte *)0x0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102aa1;
                      func_0x(pbVar51,ppbVar28);
                    }
                    iVar20 = *(int *)(&stack0x00000098 + lVar26);
                  }
                  uVar21 = (uint)*(ushort *)(lVar35 + 0xe);
                  pbVar51 = (byte *)((ulonglong)*(ushort *)(lVar35 + (0xfff - lVar39) * 2) + lVar35)
                  ;
                  bVar38 = *pbVar51;
                  *(byte **)(&stack0x00000980 + lVar26) = pbVar51;
                  if ((bVar38 & 1) == 0) {
                    *(undefined2 *)(&stack0x00000978 + lVar26) = 0;
                    *(undefined4 *)(&stack0x0000097c + lVar26) = 0;
                    *(undefined4 *)(&stack0x0000099e + lVar26) = 0;
                    switch(*pbVar51 & 0xe) {
                    default:
                      uVar21 = (uint)*(ushort *)(pbVar51 + 2);
                      if (0x1f9d < *(ushort *)(pbVar51 + 2) - 1) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102d31;
                        func_0x(pbVar51,6);
                      }
                      break;
                    case 4:
                      uVar21 = 9;
                      break;
                    case 6:
                    case 10:
                      break;
                    case 0xe:
                      uVar21 = 1;
                    }
                    *(uint *)(&stack0x00000988 + lVar26) = uVar21;
                    *(longlong *)(&stack0x00000996 + lVar26) = lVar35 + 0x2000;
                  }
                  else {
                    *(undefined2 *)(&stack0x00000978 + lVar26) = 1;
                    bVar38 = *pbVar51;
                    switch(bVar38 & 0x1c) {
                    default:
                      if ((char)pbVar51[1] < '\0') {
                        uVar43 = (*(ushort *)(pbVar51 + 1) & 0x7f) << 8 |
                                 *(ushort *)(pbVar51 + 1) >> 8;
                        *(ushort *)(&stack0x0000097a + lVar26) = uVar43;
                        sVar18 = 3;
                        *(undefined2 *)(&stack0x00000990 + lVar26) = 3;
                      }
                      else {
                        uVar43 = (ushort)pbVar51[1];
                        *(ushort *)(&stack0x0000097a + lVar26) = uVar43;
                        sVar18 = 2;
                        *(undefined2 *)(&stack0x00000990 + lVar26) = 2;
                      }
                      *(short *)(&stack0x00000994 + lVar26) = (short)(uVar43 + 1 >> 1) + sVar18;
                      if (uVar43 < 0x1f) {
                        *(undefined2 *)(&stack0x00000992 + lVar26) = 0;
                        *(undefined4 *)(&stack0x0000097c + lVar26) = 0;
                        *(undefined4 *)(&stack0x000009a8 + lVar26) = 0;
                        *(longlong *)(&stack0x000009a0 + lVar26) = lVar35 + 0x2000;
                        *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
                      }
                      else {
                        iVar22 = uVar43 - 1;
                        *(short *)(&stack0x00000992 + lVar26) =
                             ((short)(iVar22 / 0x1e) + (short)(iVar22 >> 0x1f)) -
                             (short)((longlong)iVar22 * 0x88888889 >> 0x3f);
                        *(undefined4 *)(&stack0x0000097c + lVar26) = 0;
                        *(undefined4 *)(&stack0x000009a8 + lVar26) = 0;
                        *(longlong *)(&stack0x000009a0 + lVar26) = lVar35 + 0x2000;
                        *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
                      }
                      break;
                    case 4:
                      if (((bVar38 & 0x1c) == 4) && ((bVar38 & 2) != 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102c36;
                        func_0x(&stack0x0000097a + lVar26);
                        *(byte **)(&stack0x00000980 + lVar26) = pbVar51;
                        *(undefined4 *)(&stack0x0000097c + lVar26) = 0xf;
                        *(undefined4 *)(&stack0x000009a8 + lVar26) = 1;
                        *(longlong *)(&stack0x000009a0 + lVar26) = lVar35 + 0x2000;
                        *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102c73;
                        func_0x(&stack0x0000097a + lVar26);
                        *(byte **)(&stack0x00000980 + lVar26) = pbVar51;
                        *(undefined4 *)(&stack0x0000097c + lVar26) = 1;
                        *(undefined4 *)(&stack0x000009a8 + lVar26) = 0;
                        *(longlong *)(&stack0x000009a0 + lVar26) = lVar35 + 0x2000;
                        *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
                      }
                      break;
                    case 8:
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102be9;
                      func_0x(&stack0x0000097a + lVar26);
                      *(byte **)(&stack0x00000980 + lVar26) = pbVar51;
                      *(undefined4 *)(&stack0x0000097c + lVar26) = 9;
                      *(undefined4 *)(&stack0x000009a8 + lVar26) = 0;
                      *(longlong *)(&stack0x000009a0 + lVar26) = lVar35 + 0x2000;
                      *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
                    }
                  }
                  if (*(short *)(&stack0x00000978 + lVar26) == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102d9d;
                    func_0x();
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102da4;
                    func_0x(&stack0x0000097a + lVar26,&stack0x0000015e + lVar26);
                  }
                  iVar22 = *(int *)(&stack0x0000015e + lVar26);
                  *(int *)(&stack0x000000ec + lVar26) = iVar22;
                  sVar18 = *(short *)(&stack0x00000162 + lVar26);
                  *(short *)(&stack0x000000f0 + lVar26) = sVar18;
                  if ((sVar18 == *(short *)(&stack0x000000b8 + lVar26)) && (iVar22 == iVar20)) {
                    lVar33 = *(longlong *)(&stack0x000000f8 + lVar26);
                  }
                  else {
                    *(int *)(&stack0x000000a8 + lVar26) = iVar22;
                    *(short *)(&stack0x000000ac + lVar26) = sVar18;
                    lVar33 = *(longlong *)(&stack0x000000f8 + lVar26);
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102de6;
                    iVar20 = func_0x(lVar33,&stack0x000000a8 + lVar26);
                    if (iVar20 == 3) goto code_r0x0010377e;
                    iVar20 = *(int *)(&stack0x000000ec + lVar26);
                    *(int *)(&stack0x00000098 + lVar26) = iVar20;
                    *(undefined2 *)(&stack0x000000b8 + lVar26) =
                         *(undefined2 *)(&stack0x000000f0 + lVar26);
                  }
                  lVar36 = *(longlong *)(&stack0x00000130 + lVar26);
                }
              }
              if ((&stack0x0000003c)[lVar26] != '\0') goto LAB_;
              (&stack0x00000a66)[lVar26] = 1;
              lVar35 = **(longlong **)(lVar40 + 0x58);
              uVar25 = *(undefined4 *)(lVar40 + 0x50);
              *(undefined4 *)(&stack0x000001c0 + lVar26) = *(undefined4 *)(lVar35 + 0x20);
              *(undefined2 *)(&stack0x000001c4 + lVar26) = *(undefined2 *)(lVar35 + 0x24);
              *(short *)(&stack0x000001c6 + lVar26) = (short)uVar25;
              uVar4 = *(undefined2 *)(*(longlong *)(lVar33 + 0x30) + 0x6b8);
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102e74;
              func_0x(&stack0x00000a58 + lVar26,uVar4,&stack0x000001c0 + lVar26);
              *(undefined4 *)((longlong)&uStackX_20 + lVar26 + -0x20) = 1;
              *(undefined4 *)(&stack0xfffffffffffffff8 + lVar26) = 0;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar26) = 1;
              *(longlong *)(&stack0xffffffffffffffe8 + lVar26) = lVar40 + 0x90;
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102ea2;
              iVar22 = func_0x(plVar55,&stack0x00000a58 + lVar26);
              if (iVar22 < 0) goto LAB_;
              if (iVar22 != 1) goto LAB_;
              (&stack0x0000003c)[lVar26] = 1;
            } while( true );
          }
          if (iVar20 == 0) goto LAB_;
          goto LAB_;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1022af;
        func_0x(plVar55,1);
        if (*(int *)(lVar40 + 0xf0) == 3) goto LAB_;
      }
      else {
        pcVar8 = *(code **)(*plVar7 + 0x28);
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1020e6;
        cVar15 = (*pcVar8)(plVar7);
        if (cVar15 != '\0') goto LAB_;
        uVar25 = *(undefined4 *)(*(longlong *)(lVar40 + 0x40) + 0x90);
        uVar4 = *(undefined2 *)(*(longlong *)(lVar40 + 0x40) + 0x94);
        uVar5 = *(undefined2 *)
                 (*(longlong *)(*(longlong *)(*(longlong *)(lVar40 + 0x38) + 8) + 0x30) + 0x6b8);
        (&stack0x00000876)[lVar26] = 6;
        *(undefined2 *)(&stack0x00000874 + lVar26) = uVar5;
        *(undefined8 *)(&stack0x0000086c + lVar26) = 0;
        *(undefined4 *)(&stack0x00000868 + lVar26) = uVar25;
        *(undefined2 *)(&stack0x0000086c + lVar26) = uVar4;
        *(undefined4 *)((longlong)&uStackX_20 + lVar26 + -0x20) = 1;
        *(undefined4 *)(&stack0xfffffffffffffff8 + lVar26) = 1;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar26) = 1;
        *(longlong *)(&stack0xffffffffffffffe8 + lVar26) = lVar40 + 0xc0;
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10216b;
        iVar20 = func_0x(plVar55,&stack0x00000868 + lVar26,2);
        if (-1 < iVar20) goto LAB_;
        if ((*(longlong *)(lVar40 + 0x40) != CONCAT44(uRam0000000001e8726c,_DAT_)) ||
           (*(longlong *)(lVar40 + 0x48) != CONCAT44(uRam0000000001e87274,_DAT_))) {
          if ((*(byte *)(lVar40 + 0xa0) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1021a6;
            iVar20 = func_0x(lVar40 + 0xa8);
            if (iVar20 != 0) {
              *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
            }
          }
          *(undefined *)(lVar40 + 0xa0) = 0;
          *(undefined4 *)(lVar40 + 0x9c) = 0;
          *(undefined4 *)(lVar40 + 0xb8) = 0;
          if ((*(byte *)(lVar40 + 0xd0) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1021db;
            iVar20 = func_0x(lVar40 + 0xd8);
            if (iVar20 != 0) {
              *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
            }
          }
          *(undefined *)(lVar40 + 0xd0) = 0;
          *(undefined4 *)(lVar40 + 0xcc) = 0;
          *(undefined4 *)(lVar40 + 0xe8) = 0;
          if (*(longlong *)(lVar40 + 0x58) != 0) {
            if (*(longlong *)(lVar40 + 0x58) != 0) {
              *(undefined *)(lVar40 + 0x66) = 0;
              *(undefined8 *)(lVar40 + 0x58) = 0;
              *(undefined2 *)(lVar40 + 100) = 0;
            }
            *(undefined4 *)(*(longlong *)(lVar40 + 0x40) + 0x48) = 0;
          }
          uVar29 = *(undefined8 *)*plVar55;
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102231;
          func_0x(uVar29,lVar40 + 0x40);
          uVar13 = uRam0000000001e87274;
          uVar6 = _DAT_;
          uVar25 = uRam0000000001e8726c;
          *(undefined4 *)(lVar40 + 0x40) = _DAT_;
          *(undefined4 *)(lVar40 + 0x44) = uVar25;
          *(undefined4 *)(lVar40 + 0x48) = uVar6;
          *(undefined4 *)(lVar40 + 0x4c) = uVar13;
          *(undefined4 *)(lVar40 + 0x50) = 0xffffffff;
          *(undefined4 *)(lVar40 + 0x270) = 0;
          *(undefined8 *)(lVar40 + 0x288) = 0;
          *(undefined8 *)(lVar40 + 0x280) = 0;
          *(undefined8 *)(lVar40 + 0x290) = 0;
          *(undefined4 *)(lVar40 + 0x2a0) = 0xffffffff;
          *(undefined2 *)(lVar40 + 0x2a4) = 0xffff;
          *(undefined8 *)(lVar40 + 0x2a6) = 0;
          *(undefined4 *)(lVar40 + 0xf0) = 2;
        }
      }
      *(uint *)(lVar33 + 0x634) = *(uint *)(lVar33 + 0x634) | 1;
      goto LAB_;
    }
    if (iVar22 < 3) {
      *(undefined8 *)(&stack0x00000108 + lVar26) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101db1;
      iVar23 = func_0x(uVar56);
      goto LAB_;
    }
  }
  else {
    bVar58 = iVar22 < 0x32;
  }
  *(undefined8 *)(&stack0x00000108 + lVar26) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101d0c;
  iVar23 = func_0x(uVar56);
  if (!bVar58) goto LAB_;
LAB_:
  if (1 < iVar23 - 1U) goto LAB_;
  iVar22 = iVar22 + 1;
  *(int *)(&stack0x000000c8 + lVar26) = iVar22;
  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101d31;
  func_0x(plVar55);
  if (*(char *)(*(longlong *)(uVar56 + 0x28) + 0x29) == '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x101d4e;
    func_0x();
  }
  goto LAB_;
LAB_:
  *(undefined4 *)(lVar40 + 0xf0) = 4;
  lVar33 = *(longlong *)(lVar33 + 0x30);
  if (*(longlong *)(lVar33 + 0x1b28) != 0) {
    uVar21 = *(uint *)(*(longlong *)(lVar40 + 0x100) + 0x10);
    if (((((uVar21 & 1) == 0) || ((uVar21 & 0x40) != 0)) || (*(char *)(lVar33 + 0x1cd2) == '\0')) ||
       (*(char *)(lVar33 + 0x2050) != '\0')) {
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102f07;
      cVar15 = func_0x(lVar36);
      if (cVar15 != '\0') goto LAB_;
    }
    lVar33 = *(longlong *)(lVar40 + 0x288);
    if (*(ushort *)(lVar40 + 0x50) < *(ushort *)(lVar33 + 0x16)) {
      iVar20 = *(int *)(lVar40 + 0x50);
      lVar36 = 0xfff - (longlong)iVar20;
      *(longlong *)(&stack0x00000120 + lVar26) = lVar36;
      if (*(short *)(lVar33 + lVar36 * 2) != 0) {
        *(int *)(&stack0x000009ac + lVar26) = iVar20;
        if (*(char *)(lVar33 + 2) < '\0') {
          pbVar51 = (byte *)(lVar33 + 0x60);
          if ((*(short *)(&stack0x00000978 + lVar26) == 0) ||
             (ppbVar28 = *(byte ***)(&stack0x00000988 + lVar26), ppbVar28 == (byte **)0x0)) {
            *(undefined (*) [16])(&stack0x000009b0 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000009c0 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000009d0 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000009e0 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000009f0 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000a00 + lVar26) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000a10 + lVar26) = ZEXT816(0);
            *(undefined8 *)(&stack0x00000a20 + lVar26) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102fc8;
            ppbVar28 = (byte **)func_0x(&stack0x000009b0 + lVar26);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102fe0;
          puVar31 = (undefined4 *)func_0x(lVar33,&stack0x00000a98 + lVar26,0);
          if (pbVar51 == *ppbVar28) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x102ff4;
            func_0x(puVar31,ppbVar28 + 0xc);
          }
          *ppbVar28 = pbVar51;
          uVar4 = *(undefined2 *)(puVar31 + 2);
          uVar25 = puVar31[1];
          *(undefined4 *)(ppbVar28 + 0xc) = *puVar31;
          *(undefined4 *)((longlong)ppbVar28 + 100) = uVar25;
          *(undefined2 *)(ppbVar28 + 0xd) = uVar4;
          *(undefined4 *)((longlong)ppbVar28 + 0x6c) = *(undefined4 *)(lVar33 + 0x20);
          *(undefined2 *)(ppbVar28 + 0xe) = *(undefined2 *)(lVar33 + 0x24);
          *(undefined2 *)((longlong)ppbVar28 + 0x72) = 0;
          bVar38 = *pbVar51;
          *(undefined4 *)(&stack0x00000110 + lVar26) =
               *(undefined4 *)((ulonglong)bVar38 * 6 + 0x15637c0);
          sVar18 = *(short *)((ulonglong)bVar38 * 6 + 0x15637c4);
          *(short *)(&stack0x0000003c + lVar26) = sVar18;
          *(undefined2 *)(ppbVar28 + 2) = 0xffff;
          ppbVar28[3] = (byte *)0x0;
          uVar21 = 0;
          *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
          ppbVar28[7] = (byte *)0x0;
          ppbVar28[4] = (byte *)0x0;
          ppbVar28[9] = (byte *)0x0;
          ppbVar28[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar28 + 0xb) = 0;
          if ((**ppbVar28 & 2) != 0) {
            pbVar1 = pbVar51 + sVar18;
            if ((*pbVar1 & 1) == 0) {
              *(undefined2 *)(ppbVar28 + 2) = 0;
              ppbVar28[3] = pbVar1;
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar28 + 0x36) = 0;
              switch(*pbVar1 & 0xe) {
              default:
                uVar21 = (uint)*(ushort *)(pbVar1 + 2);
                if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103285;
                  func_0x(pbVar1,6);
                  sVar18 = *(short *)(&stack0x0000003c + lVar26);
                }
                break;
              case 4:
                uVar21 = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar21 = 1;
              }
              *(uint *)(ppbVar28 + 4) = uVar21;
              *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
              lVar36 = *(longlong *)(&stack0x00000120 + lVar26);
            }
            else {
              *(undefined2 *)(ppbVar28 + 2) = 1;
              ppbVar28[3] = pbVar1;
              bVar38 = *pbVar1;
              switch(bVar38 & 0x1c) {
              default:
                if ((char)pbVar1[1] < '\0') {
                  uVar43 = *(ushort *)(pbVar1 + 1);
                  *(ushort *)((longlong)ppbVar28 + 0x12) = uVar43;
                  sVar42 = 3;
                  uVar43 = (uVar43 & 0x7f) << 8 | uVar43 >> 8;
                }
                else {
                  sVar42 = 2;
                  uVar43 = (ushort)pbVar1[1];
                }
                *(ushort *)((longlong)ppbVar28 + 0x12) = uVar43;
                *(short *)(ppbVar28 + 5) = sVar42;
                *(short *)((longlong)ppbVar28 + 0x2c) =
                     (short)(*(ushort *)((longlong)ppbVar28 + 0x12) + 1 >> 1) + sVar42;
                if (*(ushort *)((longlong)ppbVar28 + 0x12) < 0x1f) {
                  *(undefined2 *)((longlong)ppbVar28 + 0x2a) = 0;
                  *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                  *(undefined4 *)(ppbVar28 + 8) = 0;
                  ppbVar28[7] = (byte *)0x0;
                  ppbVar28[4] = (byte *)0x0;
                }
                else {
                  iVar20 = *(ushort *)((longlong)ppbVar28 + 0x12) - 1;
                  *(short *)((longlong)ppbVar28 + 0x2a) =
                       ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                       (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
                  *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
                  *(undefined4 *)(ppbVar28 + 8) = 0;
                  ppbVar28[7] = (byte *)0x0;
                  ppbVar28[4] = (byte *)0x0;
                }
                break;
              case 4:
                if (((bVar38 & 0x1c) == 4) && ((bVar38 & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1031a4;
                  func_0x((longlong)ppbVar28 + 0x12);
                  ppbVar28[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0xf;
                  *(undefined4 *)(ppbVar28 + 8) = 0;
                  *(undefined4 *)(ppbVar28 + 8) = 1;
                  sVar18 = *(short *)(&stack0x0000003c + lVar26);
                  ppbVar28[7] = (byte *)0x0;
                  ppbVar28[4] = (byte *)0x0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1031d9;
                  func_0x((longlong)ppbVar28 + 0x12);
                  ppbVar28[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar28 + 0x14) = 1;
                  *(undefined4 *)(ppbVar28 + 8) = 0;
                  sVar18 = *(short *)(&stack0x0000003c + lVar26);
                  ppbVar28[7] = (byte *)0x0;
                  ppbVar28[4] = (byte *)0x0;
                }
                break;
              case 8:
                *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103169;
                func_0x((longlong)ppbVar28 + 0x12);
                ppbVar28[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar28 + 0x14) = 9;
                *(undefined4 *)(ppbVar28 + 8) = 0;
                sVar18 = *(short *)(&stack0x0000003c + lVar26);
                ppbVar28[7] = (byte *)0x0;
                ppbVar28[4] = (byte *)0x0;
              }
            }
          }
          if ((**ppbVar28 & 4) != 0) {
            uVar46 = (ulonglong)sVar18;
            if (*(short *)(&stack0x00000112 + lVar26) != 0) {
              uVar46 = (ulonglong)
                       *(ushort *)
                        (lVar33 + 0x61 + (longlong)*(short *)(&stack0x00000112 + lVar26) * 2);
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103304;
            func_0x(ppbVar28 + 9,pbVar51 + uVar46);
          }
          pbVar51 = ppbVar28[1];
          if (pbVar51 != (byte *)0x0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103318;
            func_0x(pbVar51,ppbVar28);
          }
        }
        else {
          ppbVar28 = (byte **)0x0;
        }
        uVar21 = (uint)*(ushort *)(lVar33 + 0xe);
        pbVar51 = (byte *)((ulonglong)*(ushort *)(lVar33 + lVar36 * 2) + lVar33);
        bVar38 = *pbVar51;
        *(byte **)(&stack0x00000980 + lVar26) = pbVar51;
        if ((bVar38 & 1) == 0) {
          *(undefined2 *)(&stack0x00000978 + lVar26) = 0;
          *(undefined4 *)(&stack0x0000097c + lVar26) = 0;
          *(undefined4 *)(&stack0x0000099e + lVar26) = 0;
          switch(*pbVar51 & 0xe) {
          default:
            uVar21 = (uint)*(ushort *)(pbVar51 + 2);
            if (0x1f9d < *(ushort *)(pbVar51 + 2) - 1) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10359c;
              func_0x(pbVar51,6);
            }
            break;
          case 4:
            uVar21 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar21 = 1;
          }
          *(uint *)(&stack0x00000988 + lVar26) = uVar21;
          *(longlong *)(&stack0x00000996 + lVar26) = lVar33 + 0x2000;
        }
        else {
          *(undefined2 *)(&stack0x00000978 + lVar26) = 1;
          bVar38 = *pbVar51;
          switch(bVar38 & 0x1c) {
          default:
            if ((char)pbVar51[1] < '\0') {
              uVar43 = (*(ushort *)(pbVar51 + 1) & 0x7f) << 8 | *(ushort *)(pbVar51 + 1) >> 8;
              *(ushort *)(&stack0x0000097a + lVar26) = uVar43;
              sVar18 = 3;
              *(undefined2 *)(&stack0x00000990 + lVar26) = 3;
            }
            else {
              uVar43 = (ushort)pbVar51[1];
              *(ushort *)(&stack0x0000097a + lVar26) = uVar43;
              sVar18 = 2;
              *(undefined2 *)(&stack0x00000990 + lVar26) = 2;
            }
            *(short *)(&stack0x00000994 + lVar26) = (short)(uVar43 + 1 >> 1) + sVar18;
            if (uVar43 < 0x1f) {
              *(undefined2 *)(&stack0x00000992 + lVar26) = 0;
              *(undefined4 *)(&stack0x0000097c + lVar26) = 0;
              *(undefined4 *)(&stack0x000009a8 + lVar26) = 0;
              *(longlong *)(&stack0x000009a0 + lVar26) = lVar33 + 0x2000;
              *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
            }
            else {
              iVar20 = uVar43 - 1;
              *(short *)(&stack0x00000992 + lVar26) =
                   ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                   (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
              *(undefined4 *)(&stack0x0000097c + lVar26) = 0;
              *(undefined4 *)(&stack0x000009a8 + lVar26) = 0;
              *(longlong *)(&stack0x000009a0 + lVar26) = lVar33 + 0x2000;
              *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
            }
            break;
          case 4:
            if (((bVar38 & 0x1c) == 4) && ((bVar38 & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1034a1;
              func_0x(&stack0x0000097a + lVar26);
              *(byte **)(&stack0x00000980 + lVar26) = pbVar51;
              *(undefined4 *)(&stack0x0000097c + lVar26) = 0xf;
              *(undefined4 *)(&stack0x000009a8 + lVar26) = 1;
              *(longlong *)(&stack0x000009a0 + lVar26) = lVar33 + 0x2000;
              *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1034de;
              func_0x(&stack0x0000097a + lVar26);
              *(byte **)(&stack0x00000980 + lVar26) = pbVar51;
              *(undefined4 *)(&stack0x0000097c + lVar26) = 1;
              *(undefined4 *)(&stack0x000009a8 + lVar26) = 0;
              *(longlong *)(&stack0x000009a0 + lVar26) = lVar33 + 0x2000;
              *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
            }
            break;
          case 8:
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103454;
            func_0x(&stack0x0000097a + lVar26);
            *(byte **)(&stack0x00000980 + lVar26) = pbVar51;
            *(undefined4 *)(&stack0x0000097c + lVar26) = 9;
            *(undefined4 *)(&stack0x000009a8 + lVar26) = 0;
            *(longlong *)(&stack0x000009a0 + lVar26) = lVar33 + 0x2000;
            *(byte ***)(&stack0x00000988 + lVar26) = ppbVar28;
          }
        }
        if (*(short *)(&stack0x00000978 + lVar26) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103608;
          func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10360f;
          func_0x(&stack0x0000097a + lVar26,&stack0x00000158 + lVar26);
        }
        *(undefined4 *)(&stack0x000000ec + lVar26) = *(undefined4 *)(&stack0x00000158 + lVar26);
        *(undefined2 *)(&stack0x000000f0 + lVar26) = *(undefined2 *)(&stack0x0000015c + lVar26);
        *(undefined4 *)(&stack0x00000048 + lVar26) = *(undefined4 *)(&stack0x00000158 + lVar26);
        *(undefined2 *)(&stack0x0000004c + lVar26) = *(undefined2 *)(&stack0x0000015c + lVar26);
        lVar33 = *(longlong *)(&stack0x000000f8 + lVar26);
        uVar29 = *(undefined8 *)(lVar33 + 0x30);
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103644;
        cVar15 = func_0x(uVar29,&stack0x00000048 + lVar26);
        if (cVar15 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103659;
          cVar15 = func_0x(lVar33,3,&stack0x000000ec + lVar26);
          if (cVar15 == '\0') {
LAB_:
            *(undefined4 *)(lVar40 + 0xf0) = 3;
            *(undefined4 *)(lVar40 + 0x50) = 0xffffffff;
code_r0x0010377e:
            *(uint *)(*(longlong *)(&stack0x000000d0 + lVar26) + 0x634) =
                 *(uint *)(*(longlong *)(&stack0x000000d0 + lVar26) + 0x634) | 1;
            goto LAB_;
          }
        }
      }
    }
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10366e;
  func_0x(plVar55,1);
  uVar21 = *(uint *)(lVar40 + 0x268);
  iVar20 = 0;
  lVar40 = *(longlong *)(&stack0x000000d0 + lVar26);
  iVar22 = *(int *)(&stack0x000000c8 + lVar26);
  iVar23 = *(int *)(&stack0x000000dc + lVar26);
LAB_:
  if (uVar21 != 3) goto LAB_;
  bVar58 = false;
  if (*(char *)(*(longlong *)(lVar40 + 0x28) + 0x29) == '\0') {
    lVar33 = *(longlong *)(*(longlong *)(lVar40 + 0x20) + 0x18);
    if ((*(int *)(lVar33 + 0x1c) != 0) &&
       ((((*(char *)(lVar33 + 1) != '\x01' && (*(char *)(lVar33 + 1) != '\b')) ||
         (*(char *)(lVar33 + 2) != '\0')) || (*(char *)(lVar33 + 3) != '\0')))) {
      *(undefined8 *)(&stack0x00000100 + lVar26) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1037b7;
      func_0x(lVar40,1,0,&stack0x00000100 + lVar26);
LAB_:
      if (*(longlong *)(lVar40 + 0x2d8) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1037d7;
        func_0x(lVar40 + 0x2b0,0);
      }
      if (*(int *)(lVar40 + 0x4f0) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1037ef;
        func_0x(lVar40 + 0x2b0,1);
      }
LAB_:
      *(uint *)(lVar40 + 0x634) = *(uint *)(lVar40 + 0x634) | 1;
      if (iVar20 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103816;
        uVar29 = func_0x(*(undefined8 *)(&stack0x000000c0 + lVar26),1,0);
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10381e;
        puVar30 = (undefined8 *)func_0x(uVar29);
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103834;
        (*_DAT_)(6,0x55,0x10,1);
        if (puVar30 == (undefined8 *)0x0) {
          *(undefined8 *)(&stack0x00000170 + lVar26) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103854;
          puVar31 = (undefined4 *)(*_DAT_)();
          *puVar31 = 0x16;
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103861;
          (*_DAT_)();
          uVar29 = *(undefined8 *)(&stack0x00000170 + lVar26);
        }
        else {
          uVar29 = *puVar30;
          *(undefined8 *)(&stack0x00000170 + lVar26) = uVar29;
        }
        piVar9 = *(int **)(&stack0x00000128 + lVar26);
        if (((*piVar9 != (int)uVar29) ||
            (*(short *)(piVar9 + 1) != *(short *)(&stack0x00000174 + lVar26))) ||
           (*(short *)((longlong)piVar9 + 6) != *(short *)(&stack0x00000176 + lVar26))) {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1038c0;
          (*_DAT_)(1,0x1917a00,0x18eb0a8,0x13b1);
        }
LAB_:
        uVar29 = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1038d7;
        psVar32 = (short *)func_0x(*(undefined8 *)(&stack0x000000c0 + lVar26),1,0);
        sVar18 = *psVar32;
        *(short *)(&stack0x00000060 + lVar26) = sVar18;
        iVar20 = 0;
        if (sVar18 == 0) {
          if (*(int *)(psVar32 + 2) == 0) {
            psVar32[1] = 0;
            uVar21 = *(uint *)(psVar32 + 8);
            uVar46 = (ulonglong)uVar21;
            *(uint *)(psVar32 + 10) = uVar21;
            pbVar51 = *(byte **)(psVar32 + 4);
            bVar38 = *pbVar51;
            if ((bVar38 & 0x10) != 0) {
              uVar21 = uVar21 + (*(ushort *)(pbVar51 + uVar46) + 7 >> 3) + 2;
              uVar46 = (ulonglong)uVar21;
              *(uint *)(psVar32 + 10) = uVar21;
              bVar38 = *pbVar51;
            }
            if ((bVar38 & 0x20) == 0) {
              *(int *)(psVar32 + 2) = (int)uVar46;
              psVar32[0xe] = 0;
              *(uint *)(psVar32 + 0xc) = uVar21;
            }
            else {
              puVar57 = (ushort *)(pbVar51 + uVar46);
              uVar43 = *puVar57;
              psVar32[0xe] = uVar43;
              if (uVar43 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar40 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0)) &&
                   ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                    (*(char *)(lVar40 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1039dd;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103a03;
                    (*_DAT_)(1,0x1766cd8,0x18869a8,0x80f);
                  }
                }
                uVar29 = *(undefined8 *)(psVar32 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103a11;
                func_0x(uVar29,3);
                uVar43 = psVar32[0xe];
                uVar21 = *(uint *)(psVar32 + 10);
              }
              uVar21 = uVar21 + (uVar43 + 1) * 2;
              *(uint *)(psVar32 + 0xc) = uVar21;
              if (0x1f9e < uVar21) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar40 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0 &&
                    ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                     (*(char *)(lVar40 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103aab;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103ad1;
                    (*_DAT_)(1,0x1766cd8,0x18869a8,0x816);
                  }
                }
                uVar29 = *(undefined8 *)(psVar32 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103adf;
                func_0x(uVar29,4);
                uVar21 = *(uint *)(psVar32 + 0xc);
              }
              uVar43 = puVar57[(ushort)psVar32[0xe]];
              *(uint *)(psVar32 + 2) = uVar43 & 0x7fff;
              if ((uVar43 & 0x7fff) < uVar21) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar40 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0)) &&
                   ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                    (*(char *)(lVar40 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103b76;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103b9c;
                    (*_DAT_)(1,0x1766cd8,0x18869a8,0x81d);
                  }
                }
                uVar29 = *(undefined8 *)(psVar32 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103baa;
                func_0x(uVar29,4);
              }
              do {
                uVar43 = psVar32[0xe];
                uVar46 = (ulonglong)uVar43;
                if (-1 < (short)puVar57[(ulonglong)(uVar43 - 1) + 1]) break;
                lVar40 = *(longlong *)(psVar32 + 4);
                lVar33 = (ulonglong)*(uint *)(psVar32 + 10) + lVar40;
                if (uVar43 == 1) {
                  uVar27 = (ulonglong)*(uint *)(psVar32 + 0xc);
                  uVar43 = *(ushort *)(lVar33 + uVar46 * 2);
LAB_:
                  if ((uVar43 & 0x7fff) < (uint)uVar27) goto LAB_;
                }
                else {
                  uVar21 = *(ushort *)(lVar33 + -2 + uVar46 * 2) & 0x7fff;
                  uVar27 = (ulonglong)uVar21;
                  uVar43 = *(ushort *)(lVar33 + uVar46 * 2);
                  if (*(uint *)(psVar32 + 0xc) <= uVar21) goto LAB_;
LAB_:
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103c04;
                  func_0x(lVar40,7);
                  lVar40 = *(longlong *)(psVar32 + 4);
                  if ((uint)uVar27 < *(uint *)(psVar32 + 0xc)) goto LAB_;
                }
                if (*(uint *)(psVar32 + 2) < (uint)uVar27) goto LAB_;
                if (*(ushort *)(lVar40 + uVar27) == 5) {
                  psVar32[1] = psVar32[1] | 2;
                  psVar32[0xe] = psVar32[0xe] + -1;
                  psVar32[0x15] = (short)uVar27;
                  lVar40 = (uVar27 & 0xffff) + *(longlong *)(psVar32 + 4);
                  uVar43 = *(ushort *)(lVar40 + 2);
                  uVar19 = psVar32[0x16] & 0xc7ff;
                  if ((uVar43 & 0x4000) != 0) {
                    uVar19 = uVar43 & 0x3800 | uVar19;
                  }
                  psVar32[0x16] = uVar19;
                  psVar32[0x16] = (uVar19 ^ *(ushort *)(lVar40 + 2)) & 0x7ff ^ uVar19;
                  pbVar51 = *(byte **)(psVar32 + 4);
                  goto LAB_;
                }
                if (*(ushort *)(lVar40 + uVar27) < 0x400) break;
                psVar32[1] = psVar32[1] | 1;
                psVar52 = psVar32 + 0xe;
                *psVar52 = *psVar52 + -1;
              } while (*psVar52 != 0);
              pbVar51 = *(byte **)(psVar32 + 4);
            }
LAB_:
            if ((*pbVar51 & 0x40) == 0) {
              *(undefined4 *)(psVar32 + 0x13) = 0;
            }
            else {
              *(int *)(psVar32 + 0x13) = *(int *)(psVar32 + 2);
              *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + 0xe;
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103ce9;
              puVar34 = (ulonglong *)func_0x(psVar32 + 1);
              uVar46 = *puVar34;
              uVar43 = (ushort)(uVar46 >> 0x30);
              if ((((uint)(int)(short)uVar43 >> 1 ^ (int)(short)uVar43) & 0x2000) != 0) {
                if ((uVar46 & 0x4000000000000000) == 0) {
                  uVar43 = uVar43 & 0xdfff;
                }
                else {
                  uVar43 = uVar43 | 0x2000;
                }
              }
              iVar22 = iVar20;
              if (uVar43 == 0xfffc) {
                iVar22 = (int)((uVar46 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + iVar22;
              pbVar51 = *(byte **)(psVar32 + 4);
            }
            uVar21 = *(uint *)(psVar32 + 2);
            if ((*(byte **)(psVar32 + 0xf) != (byte *)0x0) &&
               (*(byte **)(psVar32 + 0xf) < pbVar51 + uVar21)) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar40 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0 &&
                   (lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0)) &&
                  (*(char *)(lVar40 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103dcf;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103df5;
                  (*_DAT_)(1,0x1766cd8,0x18869a8,0x877);
                }
              }
              uVar29 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103e03;
              func_0x(uVar29,0x12);
              uVar21 = *(uint *)(psVar32 + 2);
            }
            if (0x3f3b < uVar21 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar40 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0 &&
                  ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                   (*(char *)(lVar40 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103e8e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103eb4;
                  (*_DAT_)(1,0x1766cd8,0x18869a8,0x87c);
                }
              }
              uVar29 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103ec2;
              func_0x(uVar29,5);
            }
          }
LAB_:
          *(undefined4 *)(&stack0x00000070 + lVar26) = *(undefined4 *)(psVar32 + 8);
          *(short *)(&stack0x00000062 + lVar26) = psVar32[1];
          *(undefined4 *)(&stack0x00000064 + lVar26) = *(undefined4 *)(psVar32 + 2);
          *(short *)(&stack0x0000007c + lVar26) = psVar32[0xe];
          *(undefined4 *)(&stack0x00000074 + lVar26) = *(undefined4 *)(psVar32 + 10);
          *(undefined4 *)(&stack0x00000078 + lVar26) = *(undefined4 *)(psVar32 + 0xc);
          *(undefined4 *)(&stack0x00000086 + lVar26) = *(undefined4 *)(psVar32 + 0x13);
          uVar29 = *(undefined8 *)(psVar32 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103f26;
          func_0x(&stack0x00000aa8 + lVar26,0x1f9e,uVar29);
          *(undefined **)(&stack0x00000068 + lVar26) = &stack0x00000aa8 + lVar26;
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103f3a;
          iVar22 = func_0x(&stack0x00000062 + lVar26);
          pbVar51 = *(byte **)(&stack0x00000068 + lVar26);
          if (iVar22 != 0) {
            puVar57 = (ushort *)(pbVar51 + *(uint *)(&stack0x00000074 + lVar26));
            uVar21 = *puVar57 - 1;
            if (((&stack0x00000062)[lVar26] & 1) == 0) {
              uVar21 = (uint)*puVar57;
            }
            uVar44 = *(uint *)(&stack0x00000078 + lVar26);
            if (uVar21 != 1) {
              uVar44 = puVar57[(longlong)(int)uVar21 + -1] & 0x7fff;
            }
            if ((uVar44 < *(uint *)(&stack0x00000078 + lVar26)) ||
               ((puVar57[(int)uVar21] & 0x7fff) < uVar44)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103f95;
              func_0x(pbVar51,7);
              pbVar51 = *(byte **)(&stack0x00000068 + lVar26);
            }
            *(short *)(&stack0x0000008a + lVar26) = (short)uVar44;
            uVar43 = *(ushort *)(&stack0x0000008c + lVar26);
            if ((*(ushort *)(pbVar51 + (ulonglong)(uVar44 & 0xffff) + 2) & 0x4000) == 0) {
              uVar43 = uVar43 & 0xc7ff;
            }
            else {
              uVar43 = uVar43 ^ (*(ushort *)(pbVar51 + (ulonglong)(uVar44 & 0xffff) + 2) ^ uVar43) &
                                0x3800;
            }
            *(ushort *)(&stack0x0000008c + lVar26) = uVar43;
            *(ushort *)(&stack0x0000008c + lVar26) =
                 (uVar43 ^ *(ushort *)(pbVar51 + (ulonglong)(uVar44 & 0xffff) + 2)) & 0x7ff ^ uVar43
            ;
          }
        }
        else {
          if (((*psVar32 == 0) || (*(longlong **)(psVar32 + 8) == (longlong *)0x0)) ||
             (**(longlong **)(psVar32 + 8) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10404c;
            func_0x(&stack0x00000062 + lVar26,&stack0x00000aa8 + lVar26,0x1f9e);
            if (*psVar32 != 0) {
              uVar29 = *(undefined8 *)(psVar32 + 8);
            }
            *(undefined8 *)(&stack0x00000070 + lVar26) = uVar29;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104030;
            func_0x(&stack0x00000060 + lVar26,&stack0x00000aa8 + lVar26,0x1f9e);
          }
          pbVar51 = *(byte **)(&stack0x00000068 + lVar26);
        }
        lVar40 = *(longlong *)(&stack0x000001d0 + lVar26);
        if (*(char *)(lVar40 + 0x1cde) == '\0') {
          if (*(short *)(&stack0x00000060 + lVar26) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104e8a;
            func_0x(&stack0x00000062 + lVar26);
          }
          else if ((*pbVar51 & 2) != 0) {
            if (*(int *)(&stack0x00000064 + lVar26) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104ea1;
              func_0x(&stack0x00000062 + lVar26);
              pbVar51 = *(byte **)(&stack0x00000068 + lVar26);
            }
            *pbVar51 = *pbVar51 & 0xfd;
LAB_:
            uVar25 = *(undefined4 *)(&stack0x00000090 + lVar26);
            *(undefined4 *)(&stack0x00000090 + lVar26) = 0;
            *(undefined4 *)(&stack0x00000064 + lVar26) = uVar25;
          }
        }
        else {
          if (*(short *)(&stack0x00000060 + lVar26) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10408c;
            func_0x();
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104093;
            func_0x(&stack0x00000062 + lVar26,&stack0x000000c8 + lVar26);
          }
          *(undefined4 *)(&stack0x000000dc + lVar26) = *(undefined4 *)(&stack0x000000c8 + lVar26);
          *(undefined2 *)(&stack0x000000e0 + lVar26) = *(undefined2 *)(&stack0x000000cc + lVar26);
          if (*(short *)(&stack0x00000060 + lVar26) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1040c4;
            func_0x();
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1040cb;
            func_0x(&stack0x00000062 + lVar26,&stack0x000001d8 + lVar26);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1040e5;
          iVar22 = func_0x(lVar40 + 0x19c8,&stack0x000000dc + lVar26,
                                   &stack0x000001d8 + lVar26);
          if (iVar22 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10411e;
            cVar15 = func_0x(lVar40 + 0x19c8,&stack0x000000dc + lVar26);
            if (cVar15 == '\0') {
              uVar21 = *(uint *)(&stack0x00000064 + lVar26);
              uVar46 = (ulonglong)uVar21;
              if (*(short *)(&stack0x00000060 + lVar26) == 0) {
                pbVar51 = *(byte **)(&stack0x00000068 + lVar26);
                if ((*pbVar51 & 0xe) == 2) goto LAB_;
                if (uVar21 == 0) {
                  *(undefined2 *)(&stack0x00000062 + lVar26) = 0;
                  uVar21 = *(uint *)(&stack0x00000070 + lVar26);
                  uVar46 = (ulonglong)uVar21;
                  *(uint *)(&stack0x00000074 + lVar26) = uVar21;
                  if ((*pbVar51 & 0x10) != 0) {
                    uVar21 = uVar21 + 2 + (*(ushort *)(pbVar51 + uVar46) + 7 >> 3);
                    uVar46 = (ulonglong)uVar21;
                    *(uint *)(&stack0x00000074 + lVar26) = uVar21;
                  }
                  if ((**(byte **)(&stack0x00000068 + lVar26) & 0x20) == 0) {
                    *(int *)(&stack0x00000064 + lVar26) = (int)uVar46;
                    *(undefined2 *)(&stack0x0000007c + lVar26) = 0;
                    *(int *)(&stack0x00000078 + lVar26) = (int)uVar46;
                  }
                  else {
                    puVar57 = (ushort *)(*(byte **)(&stack0x00000068 + lVar26) + uVar46);
                    uVar43 = *puVar57;
                    *(ushort *)(&stack0x0000007c + lVar26) = uVar43;
                    if (uVar43 == 0) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar40 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0)) &&
                         ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                          (*(char *)(lVar40 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10420e;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104234;
                          (*_DAT_)(1,0x1766cd8,0x18869a8,0x80f);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104242;
                      func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),3);
                      uVar43 = *(ushort *)(&stack0x0000007c + lVar26);
                    }
                    uVar21 = *(int *)(&stack0x00000074 + lVar26) + 2 + (uint)uVar43 * 2;
                    *(uint *)(&stack0x00000078 + lVar26) = uVar21;
                    if (0x1f9e < uVar21) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar40 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0 &&
                          ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                           (*(char *)(lVar40 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1042e0;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104306;
                          (*_DAT_)(1,0x1766cd8,0x18869a8,0x816);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104314;
                      func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),4);
                      uVar43 = *(ushort *)(&stack0x0000007c + lVar26);
                      uVar21 = *(uint *)(&stack0x00000078 + lVar26);
                    }
                    uVar27 = (ulonglong)uVar43;
                    uVar44 = puVar57[uVar27] & 0x7fff;
                    *(uint *)(&stack0x00000064 + lVar26) = uVar44;
                    if (uVar44 < uVar21) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar40 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0)) &&
                         ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                          (*(char *)(lVar40 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1043b1;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1043d7;
                          (*_DAT_)(1,0x1766cd8,0x18869a8,0x81d);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1043e5;
                      func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),4);
                      uVar27 = (ulonglong)*(ushort *)(&stack0x0000007c + lVar26);
                      uVar21 = *(uint *)(&stack0x00000078 + lVar26);
                      uVar44 = *(uint *)(&stack0x00000064 + lVar26);
                    }
                    uVar46 = (ulonglong)uVar44;
                    do {
                      if (-1 < (short)puVar57[(ulonglong)((int)uVar27 - 1) + 1]) break;
                      uVar44 = uVar21;
                      if ((int)uVar27 != 1) {
                        uVar44 = *(ushort *)
                                  ((ulonglong)*(uint *)(&stack0x00000074 + lVar26) +
                                   *(longlong *)(&stack0x00000068 + lVar26) + -2 + uVar27 * 2) &
                                 0x7fff;
                      }
                      if ((uVar44 < uVar21) ||
                         ((*(ushort *)
                            ((ulonglong)*(uint *)(&stack0x00000074 + lVar26) +
                             *(longlong *)(&stack0x00000068 + lVar26) + uVar27 * 2) & 0x7fff) <
                          uVar44)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104456;
                        func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),7);
                        uVar27 = (ulonglong)*(ushort *)(&stack0x0000007c + lVar26);
                        uVar21 = *(uint *)(&stack0x00000078 + lVar26);
                        uVar46 = (ulonglong)*(uint *)(&stack0x00000064 + lVar26);
                      }
                      if ((uVar44 < uVar21) || ((uint)uVar46 < uVar44)) goto LAB_;
                      if (*(ushort *)((ulonglong)uVar44 + *(longlong *)(&stack0x00000068 + lVar26))
                          == 5) {
                        *(ushort *)(&stack0x00000062 + lVar26) =
                             *(ushort *)(&stack0x00000062 + lVar26) | 2;
                        *(short *)(&stack0x0000007c + lVar26) = (short)uVar27 + -1;
                        *(short *)(&stack0x0000008a + lVar26) = (short)uVar44;
                        lVar40 = (ulonglong)(uVar44 & 0xffff) +
                                 *(longlong *)(&stack0x00000068 + lVar26);
                        uVar43 = *(ushort *)(lVar40 + 2);
                        uVar19 = *(ushort *)(&stack0x0000008c + lVar26);
                        if ((uVar43 & 0x4000) == 0) {
                          uVar19 = uVar19 & 0xc7ff;
                        }
                        else {
                          uVar19 = uVar19 ^ (uVar43 ^ uVar19) & 0x3800;
                        }
                        *(ushort *)(&stack0x0000008c + lVar26) = uVar19;
                        *(ushort *)(&stack0x0000008c + lVar26) =
                             (uVar19 ^ *(ushort *)(lVar40 + 2)) & 0x7ff ^ uVar19;
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar44 + *(longlong *)(&stack0x00000068 + lVar26))
                          < 0x400) break;
                      *(ushort *)(&stack0x00000062 + lVar26) =
                           *(ushort *)(&stack0x00000062 + lVar26) | 1;
                      uVar43 = (short)uVar27 - 1;
                      uVar27 = (ulonglong)uVar43;
                      *(ushort *)(&stack0x0000007c + lVar26) = uVar43;
                    } while (uVar43 != 0);
                  }
                  if ((**(byte **)(&stack0x00000068 + lVar26) & 0x40) == 0) {
                    *(undefined4 *)(&stack0x00000086 + lVar26) = 0;
                  }
                  else {
                    *(int *)(&stack0x00000086 + lVar26) = (int)uVar46;
                    *(int *)(&stack0x00000064 + lVar26) = (int)uVar46 + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10452d;
                    puVar34 = (ulonglong *)func_0x(&stack0x00000062 + lVar26);
                    uVar46 = *puVar34;
                    uVar43 = (ushort)(uVar46 >> 0x30);
                    if ((((uint)(int)(short)uVar43 >> 1 ^ (int)(short)uVar43) & 0x2000) != 0) {
                      if ((uVar46 & 0x4000000000000000) == 0) {
                        uVar43 = uVar43 & 0xdfff;
                      }
                      else {
                        uVar43 = uVar43 | 0x2000;
                      }
                    }
                    iVar22 = iVar20;
                    if (uVar43 == 0xfffc) {
                      iVar22 = (int)((uVar46 >> 0x20 & 0xffff) >> 5);
                    }
                    uVar46 = (ulonglong)(uint)(*(int *)(&stack0x00000064 + lVar26) + iVar22);
                    *(int *)(&stack0x00000064 + lVar26) =
                         *(int *)(&stack0x00000064 + lVar26) + iVar22;
                  }
                  if ((*(ulonglong *)(&stack0x0000007e + lVar26) != 0) &&
                     (*(ulonglong *)(&stack0x0000007e + lVar26) <
                      uVar46 + *(longlong *)(&stack0x00000068 + lVar26))) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       (((lVar40 = *(longlong *)
                                    ((ulonglong)*_DAT_ +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0 &&
                         (lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0)) &&
                        (*(char *)(lVar40 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104617;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10463d;
                        (*_DAT_)(1,0x1766cd8,0x18869a8,0x877);
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10464b;
                    func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),0x12);
                    uVar46 = (ulonglong)*(uint *)(&stack0x00000064 + lVar26);
                  }
                  if (0x3f3b < (int)uVar46 - 1U) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar40 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0 &&
                        ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                         (*(char *)(lVar40 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1046d6;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1046fc;
                        (*_DAT_)(1,0x1766cd8,0x18869a8,0x87c);
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10470a;
                    func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),5);
                    uVar46 = (ulonglong)*(uint *)(&stack0x00000064 + lVar26);
                  }
                }
LAB_:
                uVar21 = (uint)uVar46;
                if ((uVar21 < 9) &&
                   (((**(byte **)(&stack0x00000068 + lVar26) & 0xe) == 0 ||
                    ((**(byte **)(&stack0x00000068 + lVar26) & 0xe) == 0xc)))) {
                  uVar21 = 9;
                  bVar38 = **(byte **)(&stack0x00000068 + lVar26);
                  bVar58 = (bVar38 & 0x40) == 0;
                  uVar44 = *(uint *)(&stack0x00000086 + lVar26);
                }
                else {
                  bVar38 = **(byte **)(&stack0x00000068 + lVar26);
                  bVar58 = (bVar38 & 0x40) == 0;
                  uVar44 = *(uint *)(&stack0x00000086 + lVar26);
                }
LAB_:
                uVar45 = (uint)uVar46;
                if (bVar58) {
                  uVar44 = uVar21;
                }
                uVar21 = 0x10;
                if (*(short *)(&stack0x00000060 + lVar26) == 0) {
                  uVar21 = 0x16;
                }
                if (uVar44 < uVar21) goto LAB_;
              }
              else {
                if (((**(byte **)(&stack0x00000068 + lVar26) & 0x1c) - 0x10 & 0xfffffffb) != 0) {
                  if (uVar21 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10476e;
                    func_0x(&stack0x00000062 + lVar26);
                    uVar46 = (ulonglong)*(uint *)(&stack0x00000064 + lVar26);
                    if (*(uint *)(&stack0x00000064 + lVar26) == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10477e;
                      func_0x(&stack0x00000062 + lVar26);
                      uVar46 = (ulonglong)*(uint *)(&stack0x00000064 + lVar26);
                    }
                  }
                  uVar21 = (uint)uVar46;
                  if ((uVar21 < 9) &&
                     (((**(byte **)(&stack0x00000068 + lVar26) & 0x1c) == 0 ||
                      ((**(byte **)(&stack0x00000068 + lVar26) & 0x1c) == 0xc)))) {
                    uVar21 = 9;
                  }
                  bVar38 = **(byte **)(&stack0x00000068 + lVar26);
                  bVar58 = (bVar38 & 2) == 0;
                  uVar44 = *(uint *)(&stack0x00000090 + lVar26);
                  goto LAB_;
                }
LAB_:
                uVar45 = (uint)uVar46;
                if (*(short *)(&stack0x00000060 + lVar26) == 0) {
LAB_:
                  if ((int)uVar46 == 0) {
                    *(undefined2 *)(&stack0x00000062 + lVar26) = 0;
                    uVar21 = *(uint *)(&stack0x00000070 + lVar26);
                    uVar46 = (ulonglong)uVar21;
                    *(uint *)(&stack0x00000074 + lVar26) = uVar21;
                    if ((**(byte **)(&stack0x00000068 + lVar26) & 0x10) != 0) {
                      uVar21 = uVar21 + 2 +
                               (*(ushort *)(*(byte **)(&stack0x00000068 + lVar26) + uVar46) + 7 >> 3
                               );
                      uVar46 = (ulonglong)uVar21;
                      *(uint *)(&stack0x00000074 + lVar26) = uVar21;
                    }
                    if ((**(byte **)(&stack0x00000068 + lVar26) & 0x20) == 0) {
                      *(int *)(&stack0x00000064 + lVar26) = (int)uVar46;
                      *(undefined2 *)(&stack0x0000007c + lVar26) = 0;
                      *(int *)(&stack0x00000078 + lVar26) = (int)uVar46;
                    }
                    else {
                      puVar57 = (ushort *)(*(byte **)(&stack0x00000068 + lVar26) + uVar46);
                      uVar43 = *puVar57;
                      *(ushort *)(&stack0x0000007c + lVar26) = uVar43;
                      if (uVar43 == 0) {
                        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                            (lVar40 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0)) &&
                           ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                            (*(char *)(lVar40 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1048a9;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1048cf;
                            (*_DAT_)(1,0x1766cd8,0x18869a8,0x80f);
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1048dd;
                        func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),3);
                        uVar43 = *(ushort *)(&stack0x0000007c + lVar26);
                      }
                      uVar21 = *(int *)(&stack0x00000074 + lVar26) + 2 + (uint)uVar43 * 2;
                      *(uint *)(&stack0x00000078 + lVar26) = uVar21;
                      if (0x1f9e < uVar21) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           ((lVar40 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0 &&
                            ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                             (*(char *)(lVar40 + 0x499) != '\0')))))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10497b;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1049a1;
                            (*_DAT_)(1,0x1766cd8,0x18869a8,0x816);
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1049af;
                        func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),4);
                        uVar43 = *(ushort *)(&stack0x0000007c + lVar26);
                        uVar21 = *(uint *)(&stack0x00000078 + lVar26);
                      }
                      uVar27 = (ulonglong)uVar43;
                      uVar44 = puVar57[uVar27] & 0x7fff;
                      *(uint *)(&stack0x00000064 + lVar26) = uVar44;
                      if (uVar44 < uVar21) {
                        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                            (lVar40 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0)) &&
                           ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                            (*(char *)(lVar40 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104a4c;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104a72;
                            (*_DAT_)(1,0x1766cd8,0x18869a8,0x81d);
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104a80;
                        func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),4);
                        uVar27 = (ulonglong)*(ushort *)(&stack0x0000007c + lVar26);
                        uVar21 = *(uint *)(&stack0x00000078 + lVar26);
                        uVar44 = *(uint *)(&stack0x00000064 + lVar26);
                      }
                      uVar46 = (ulonglong)uVar44;
                      do {
                        if (-1 < (short)puVar57[(ulonglong)((int)uVar27 - 1) + 1]) break;
                        uVar44 = uVar21;
                        if ((int)uVar27 != 1) {
                          uVar44 = *(ushort *)
                                    ((ulonglong)*(uint *)(&stack0x00000074 + lVar26) +
                                     *(longlong *)(&stack0x00000068 + lVar26) + -2 + uVar27 * 2) &
                                   0x7fff;
                        }
                        if ((uVar44 < uVar21) ||
                           ((*(ushort *)
                              ((ulonglong)*(uint *)(&stack0x00000074 + lVar26) +
                               *(longlong *)(&stack0x00000068 + lVar26) + uVar27 * 2) & 0x7fff) <
                            uVar44)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104ae7;
                          func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),7);
                          uVar27 = (ulonglong)*(ushort *)(&stack0x0000007c + lVar26);
                          uVar21 = *(uint *)(&stack0x00000078 + lVar26);
                          uVar46 = (ulonglong)*(uint *)(&stack0x00000064 + lVar26);
                        }
                        if ((uVar44 < uVar21) || ((uint)uVar46 < uVar44)) goto LAB_;
                        if (*(ushort *)
                             ((ulonglong)uVar44 + *(longlong *)(&stack0x00000068 + lVar26)) == 5) {
                          *(ushort *)(&stack0x00000062 + lVar26) =
                               *(ushort *)(&stack0x00000062 + lVar26) | 2;
                          *(short *)(&stack0x0000007c + lVar26) = (short)uVar27 + -1;
                          *(short *)(&stack0x0000008a + lVar26) = (short)uVar44;
                          lVar40 = (ulonglong)(uVar44 & 0xffff) +
                                   *(longlong *)(&stack0x00000068 + lVar26);
                          uVar43 = *(ushort *)(lVar40 + 2);
                          uVar19 = *(ushort *)(&stack0x0000008c + lVar26);
                          if ((uVar43 & 0x4000) == 0) {
                            uVar19 = uVar19 & 0xc7ff;
                          }
                          else {
                            uVar19 = uVar19 ^ (uVar19 ^ uVar43) & 0x3800;
                          }
                          *(ushort *)(&stack0x0000008c + lVar26) = uVar19;
                          *(ushort *)(&stack0x0000008c + lVar26) =
                               (uVar19 ^ *(ushort *)(lVar40 + 2)) & 0x7ff ^ uVar19;
                          break;
                        }
                        if (*(ushort *)
                             ((ulonglong)uVar44 + *(longlong *)(&stack0x00000068 + lVar26)) < 0x400)
                        break;
                        *(ushort *)(&stack0x00000062 + lVar26) =
                             *(ushort *)(&stack0x00000062 + lVar26) | 1;
                        uVar43 = (short)uVar27 - 1;
                        uVar27 = (ulonglong)uVar43;
                        *(ushort *)(&stack0x0000007c + lVar26) = uVar43;
                      } while (uVar43 != 0);
                    }
                    if ((**(byte **)(&stack0x00000068 + lVar26) & 0x40) == 0) {
                      *(undefined4 *)(&stack0x00000086 + lVar26) = 0;
                    }
                    else {
                      *(int *)(&stack0x00000086 + lVar26) = (int)uVar46;
                      *(int *)(&stack0x00000064 + lVar26) = (int)uVar46 + 0xe;
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104bc2;
                      puVar34 = (ulonglong *)func_0x(&stack0x00000062 + lVar26);
                      uVar46 = *puVar34;
                      uVar43 = (ushort)(uVar46 >> 0x30);
                      if ((((uint)(int)(short)uVar43 >> 1 ^ (int)(short)uVar43) & 0x2000) != 0) {
                        if ((uVar46 & 0x4000000000000000) == 0) {
                          uVar43 = uVar43 & 0xdfff;
                        }
                        else {
                          uVar43 = uVar43 | 0x2000;
                        }
                      }
                      if (uVar43 == 0xfffc) {
                        iVar20 = (int)((uVar46 >> 0x20 & 0xffff) >> 5);
                      }
                      uVar46 = (ulonglong)(uint)(*(int *)(&stack0x00000064 + lVar26) + iVar20);
                      *(int *)(&stack0x00000064 + lVar26) =
                           *(int *)(&stack0x00000064 + lVar26) + iVar20;
                    }
                    if ((*(ulonglong *)(&stack0x0000007e + lVar26) != 0) &&
                       (*(ulonglong *)(&stack0x0000007e + lVar26) <
                        uVar46 + *(longlong *)(&stack0x00000068 + lVar26))) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         (((lVar40 = *(longlong *)
                                      ((ulonglong)*_DAT_ +
                                       *(longlong *)
                                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                        (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0 &&
                           (lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0)) &&
                          (*(char *)(lVar40 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104cac;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104cd2;
                          (*_DAT_)(1,0x1766cd8,0x18869a8,0x877);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104ce0;
                      func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),0x12);
                      uVar46 = (ulonglong)*(uint *)(&stack0x00000064 + lVar26);
                    }
                    if (0x3f3b < (int)uVar46 - 1U) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar40 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar40 != 0 &&
                          ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                           (*(char *)(lVar40 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104d6b;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar26) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104d91;
                          (*_DAT_)(1,0x1766cd8,0x18869a8,0x87c);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104d9f;
                      func_0x(*(undefined8 *)(&stack0x00000068 + lVar26),5);
                      uVar46 = (ulonglong)*(uint *)(&stack0x00000064 + lVar26);
                    }
                  }
LAB_:
                  uVar45 = (uint)uVar46;
                  if ((uVar45 < 9) &&
                     (((**(byte **)(&stack0x00000068 + lVar26) & 0xe) == 0 ||
                      ((**(byte **)(&stack0x00000068 + lVar26) & 0xe) == 0xc)))) {
                    bVar38 = **(byte **)(&stack0x00000068 + lVar26);
                    bVar58 = (bVar38 & 0x40) == 0;
                    uVar44 = *(uint *)(&stack0x00000086 + lVar26);
                    uVar21 = 9;
                  }
                  else {
                    bVar38 = **(byte **)(&stack0x00000068 + lVar26);
                    bVar58 = (bVar38 & 0x40) == 0;
                    uVar44 = *(uint *)(&stack0x00000086 + lVar26);
                    uVar21 = uVar45;
                  }
                }
                else {
                  if (uVar45 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104dee;
                    func_0x(&stack0x00000062 + lVar26);
                    uVar45 = *(uint *)(&stack0x00000064 + lVar26);
                    if (uVar45 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104dfe;
                      func_0x(&stack0x00000062 + lVar26);
                      uVar45 = *(uint *)(&stack0x00000064 + lVar26);
                    }
                  }
                  uVar21 = uVar45;
                  if ((uVar45 < 9) &&
                     (((**(byte **)(&stack0x00000068 + lVar26) & 0x1c) == 0 ||
                      ((**(byte **)(&stack0x00000068 + lVar26) & 0x1c) == 0xc)))) {
                    uVar21 = 9;
                  }
                  bVar38 = **(byte **)(&stack0x00000068 + lVar26);
                  bVar58 = (bVar38 & 2) == 0;
                  uVar44 = *(uint *)(&stack0x00000090 + lVar26);
                }
                if (bVar58) {
                  uVar44 = uVar21;
                }
                uVar21 = 0x18;
                if (*(short *)(&stack0x00000060 + lVar26) == 0) {
                  uVar21 = 0x20;
                }
                if (uVar44 < uVar21) goto LAB_;
              }
              if (*(short *)(&stack0x00000060 + lVar26) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104e5d;
                func_0x(&stack0x00000062 + lVar26);
              }
              else if ((bVar38 & 2) != 0) {
                if (uVar45 == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104e71;
                  func_0x(&stack0x00000062 + lVar26);
                }
                **(byte **)(&stack0x00000068 + lVar26) =
                     **(byte **)(&stack0x00000068 + lVar26) & 0xfd;
                goto LAB_;
              }
            }
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104102;
            func_0x(lVar40 + 0x1b30,&stack0x000000c8 + lVar26);
          }
        }
LAB_:
        if (*(short *)(&stack0x00000060 + lVar26) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104ec3;
          func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104eca;
          func_0x(&stack0x00000062 + lVar26);
        }
        lVar40 = *(longlong *)(&stack0x000000c0 + lVar26);
        lVar33 = *(longlong *)(&stack0x00000178 + lVar26);
        *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104ee9;
        func_0x(lVar33,lVar40,0);
        plVar55 = (longlong *)(lVar40 + 0x30);
        lVar36 = CONCAT44(uRam0000000001e8726c,_DAT_);
        if ((*(longlong *)(lVar40 + 0x40) != lVar36) ||
           (lVar35 = CONCAT44(uRam0000000001e87274,_DAT_),
           *(longlong *)(lVar40 + 0x48) != lVar35)) {
          if ((*(byte *)(lVar40 + 0xa0) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104f1f;
            iVar20 = func_0x(lVar40 + 0xa8);
            if (iVar20 != 0) {
              *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
            }
          }
          *(undefined *)(lVar40 + 0xa0) = 0;
          *(undefined4 *)(lVar40 + 0x9c) = 0;
          *(undefined4 *)(lVar40 + 0xb8) = 0;
          if ((*(byte *)(lVar40 + 0xd0) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104f56;
            iVar20 = func_0x(lVar40 + 0xd8);
            if (iVar20 != 0) {
              *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
            }
          }
          *(undefined *)(lVar40 + 0xd0) = 0;
          *(undefined4 *)(lVar40 + 0xcc) = 0;
          *(undefined4 *)(lVar40 + 0xe8) = 0;
          if (*(longlong *)(lVar40 + 0x58) != 0) {
            *(undefined *)(lVar40 + 0x66) = 0;
            *(undefined8 *)(lVar40 + 0x58) = 0;
            *(undefined2 *)(lVar40 + 100) = 0;
            *(undefined4 *)(*(longlong *)(lVar40 + 0x40) + 0x48) = 0;
          }
          uVar29 = *(undefined8 *)*plVar55;
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x104fae;
          func_0x(uVar29,lVar40 + 0x40);
          uVar13 = uRam0000000001e87274;
          uVar6 = _DAT_;
          uVar25 = uRam0000000001e8726c;
          *(undefined4 *)(lVar40 + 0x40) = _DAT_;
          *(undefined4 *)(lVar40 + 0x44) = uVar25;
          *(undefined4 *)(lVar40 + 0x48) = uVar6;
          *(undefined4 *)(lVar40 + 0x4c) = uVar13;
          *(undefined4 *)(lVar40 + 0x50) = 0xffffffff;
          *(undefined4 *)(lVar40 + 0x270) = 0;
          *(undefined8 *)(lVar40 + 0x288) = 0;
          *(undefined8 *)(lVar40 + 0x280) = 0;
          *(undefined8 *)(lVar40 + 0x290) = 0;
          *(undefined4 *)(lVar40 + 0x2a0) = 0xffffffff;
          *(undefined2 *)(lVar40 + 0x2a4) = 0xffff;
          *(undefined8 *)(lVar40 + 0x2a6) = 0;
          *(undefined4 *)(lVar40 + 0xf0) = 2;
          lVar35 = CONCAT44(uRam0000000001e87274,_DAT_);
          lVar36 = CONCAT44(uRam0000000001e8726c,_DAT_);
        }
        lVar39 = *(longlong *)(&stack0x000000c0 + lVar26);
        if ((*(longlong *)(lVar39 + 0x2c0) != lVar36) || (*(longlong *)(lVar39 + 0x2c8) != lVar35))
        {
          if ((*(byte *)(lVar39 + 800) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x105067;
            iVar20 = func_0x(lVar39 + 0x328);
            if (iVar20 != 0) {
              plVar7 = (longlong *)(*(longlong *)(lVar39 + 0x2b0) + 0x30);
              *plVar7 = *plVar7 + -1;
            }
          }
          *(undefined *)(lVar39 + 800) = 0;
          *(undefined4 *)(lVar39 + 0x31c) = 0;
          *(undefined4 *)(lVar39 + 0x338) = 0;
          if ((*(byte *)(lVar39 + 0x350) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1050a0;
            iVar20 = func_0x(lVar39 + 0x358);
            if (iVar20 != 0) {
              plVar7 = (longlong *)(*(longlong *)(lVar39 + 0x2b0) + 0x30);
              *plVar7 = *plVar7 + -1;
            }
          }
          *(undefined *)(lVar39 + 0x350) = 0;
          *(undefined4 *)(lVar39 + 0x34c) = 0;
          *(undefined4 *)(lVar39 + 0x368) = 0;
          if (*(longlong *)(lVar39 + 0x2d8) != 0) {
            *(undefined *)(lVar39 + 0x2e6) = 0;
            *(undefined8 *)(lVar39 + 0x2d8) = 0;
            *(undefined2 *)(lVar39 + 0x2e4) = 0;
            *(undefined4 *)(*(longlong *)(lVar39 + 0x2c0) + 0x48) = 0;
          }
          uVar29 = **(undefined8 **)(lVar39 + 0x2b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x105105;
          func_0x(uVar29,lVar39 + 0x2c0);
          uVar13 = uRam0000000001e87274;
          uVar6 = _DAT_;
          uVar25 = uRam0000000001e8726c;
          *(undefined4 *)(lVar39 + 0x2c0) = _DAT_;
          *(undefined4 *)(lVar39 + 0x2c4) = uVar25;
          *(undefined4 *)(lVar39 + 0x2c8) = uVar6;
          *(undefined4 *)(lVar39 + 0x2cc) = uVar13;
          *(undefined4 *)(lVar39 + 0x2d0) = 0xffffffff;
          *(undefined4 *)(lVar39 + 0x4f0) = 0;
          *(undefined8 *)(lVar39 + 0x508) = 0;
          *(undefined8 *)(lVar39 + 0x500) = 0;
          *(undefined8 *)(lVar39 + 0x510) = 0;
          *(undefined4 *)(lVar39 + 0x520) = 0xffffffff;
          *(undefined2 *)(lVar39 + 0x524) = 0xffff;
          *(undefined8 *)(lVar39 + 0x526) = 0;
          *(undefined4 *)(lVar39 + 0x370) = 2;
        }
        lVar36 = *(longlong *)(&stack0x000000c0 + lVar26);
        *(longlong *)(&stack0x00000118 + lVar26) = lVar36;
        *(undefined4 *)(lVar36 + 0x634) = 0;
        if (((*(byte *)(*(longlong *)(**(longlong **)(*(uint **)(lVar33 + 0x108) + 8) + 8) + 0x107)
             & 0x40) == 0) || ((**(uint **)(lVar33 + 0x108) & 0x1000000) != 0)) {
          bVar38 = 0;
        }
        else {
          bVar38 = 4;
        }
        lVar35 = **(longlong **)(lVar33 + 0x2e0);
        lVar39 = *(longlong *)(&stack0x000000c0 + lVar26);
        *(longlong *)(&stack0x00000110 + lVar26) = lVar39;
        plVar7 = *(longlong **)(*(longlong *)(lVar39 + 0x28) + 8);
        *(undefined8 *)(&stack0x00000218 + lVar26) = 0;
        uVar21 = 0;
        *(undefined4 *)(&stack0x000000c8 + lVar26) = 0;
        *(undefined **)(&stack0x00000210 + lVar26) = &stack0x00000060 + lVar26;
        puVar49 = &stack0xffffffffffffffc8 + lVar26;
        if (*(int *)(*(longlong *)(lVar35 + 8) + 0x100) == 2) {
          puVar53 = (undefined2 *)(&stack0xfffffffffffffff8 + lVar26);
          *puVar53 = 0xffff;
          *(undefined8 *)((longlong)&uStackX_20 + lVar26 + -0x20) = 0;
          *(undefined4 *)(&stack0xfffffffffffffffc + lVar26) = 0;
          *(undefined8 *)((longlong)&uStackX_16 + lVar26) = 0;
          *(undefined8 *)((longlong)&uStackX_20 + lVar26) = 0;
          *(undefined8 *)((longlong)&uStackX_8 + lVar26) = 0;
          *(undefined8 *)((longlong)&uStack_80 + lVar26) = 0x10521f;
          lVar35 = func_0x();
          lVar35 = -lVar35;
          puVar49 = auStack_f8 + lVar35 + lVar26;
          *(undefined (*) [16])(auStack_88 + lVar35 + lVar26) = ZEXT816(0);
          *(undefined (*) [16])((longlong)auStack_78 + lVar35 + lVar26) = ZEXT816(0);
          *(undefined (*) [16])((longlong)&uStack_68 + lVar35 + lVar26) = ZEXT816(0);
          *(undefined (*) [16])((longlong)&uStack_5a + lVar35 + lVar26 + 2) = ZEXT816(0);
          *(undefined (*) [16])(auStack_48 + lVar35 + lVar26) = ZEXT816(0);
          *(undefined (*) [16])(&stack0xffffffffffffffc8 + lVar35 + lVar26) = ZEXT816(0);
          *(undefined (*) [16])(&stack0xffffffffffffffd8 + lVar35 + lVar26) = ZEXT816(0);
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar35 + lVar26) = 0;
          *(undefined2 *)((longlong)auStack_78 + lVar35 + lVar26) = 0xffff;
          *(undefined8 *)((longlong)&uStack_70 + lVar35 + lVar26) = 0;
          *(undefined4 *)((longlong)&uStack_74 + lVar35 + lVar26) = 0;
          *(undefined8 *)((longlong)&uStack_5a + lVar35 + lVar26) = 0;
          *(undefined8 *)((longlong)&uStack_50 + lVar35 + lVar26) = 0;
          *(undefined8 *)((longlong)&uStack_68 + lVar35 + lVar26) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar35 + lVar26) = 0;
          *(undefined8 *)(&stack0xffffffffffffffd8 + lVar35 + lVar26) = 0;
          *(undefined4 *)(&stack0xffffffffffffffe0 + lVar35 + lVar26) = 0;
          *(undefined2 *)(&stack0xffffffffffffffea + lVar35 + lVar26) = 0;
          *(undefined2 **)(&stack0x00000218 + lVar26) = puVar53;
          *(undefined **)(&stack0x00000220 + lVar26) = &stack0xfffffffffffffff8 + lVar35 + lVar26;
          *(undefined4 *)(&stack0x00000228 + lVar26) = 0x239e;
          *(undefined (**) [16])(&stack0x00000230 + lVar26) =
               (undefined (*) [16])(auStack_88 + lVar35 + lVar26);
        }
        plVar10 = *(longlong **)(lVar39 + 0x28);
        plVar47 = (longlong *)plVar10[3];
        plVar54 = plVar10;
        if (plVar47 == (longlong *)0x0) {
          plVar47 = (longlong *)(plVar10[1] + 0x208);
          plVar10[3] = (longlong)plVar47;
          plVar54 = *(longlong **)(lVar39 + 0x28);
        }
        if ((*plVar47 == (ulonglong)*(uint6 *)(*plVar10 + 0x14) * 0x10000) &&
           (*(int *)(plVar47 + 1) != 0)) {
          *(undefined4 *)(&stack0x000000c8 + lVar26) = 1;
          *(undefined4 *)(&stack0x00000098 + lVar26) = 0;
          lVar35 = *(longlong *)(&stack0x000000c0 + lVar26);
          iVar20 = *(int *)(lVar35 + 0x548);
          *(int *)(&stack0x000000a8 + lVar26) = iVar20;
          if (iVar20 == 0) {
            *(undefined4 *)(&stack0x000000a8 + lVar26) = *(undefined4 *)(&stack0x000000bc + lVar26);
            *puVar2 = *(uint *)(&stack0x000000bc + lVar26);
          }
          else {
            *(undefined4 *)(&stack0x00000098 + lVar26) = 1;
            *puVar2 = *(uint *)(lVar35 + 0x54c);
            lVar48 = plVar54[3];
            iVar20 = *(int *)(lVar48 + 8);
            if ((iVar20 == 0) || (*(int *)(lVar48 + 0xc) != 0)) {
              if (iVar20 != 0) goto LAB_;
            }
            else {
              uVar21 = 2;
LAB_:
              if (*(int *)(lVar48 + 0xc) == iVar20 + -1) {
                uVar21 = uVar21 | 1;
              }
            }
            *(uint *)(lVar35 + 0x548) = uVar21;
            *(undefined4 *)(lVar35 + 0x54c) = *(undefined4 *)(plVar54 + 4);
          }
        }
        else {
          *(undefined4 *)(&stack0x00000098 + lVar26) = *(undefined4 *)(&stack0x000000bc + lVar26);
          *(undefined4 *)(&stack0x000000a8 + lVar26) = *(undefined4 *)(&stack0x000000bc + lVar26);
          *puVar2 = *(uint *)(&stack0x000000bc + lVar26);
        }
        *(uint *)(lVar36 + 0x634) = *(uint *)(lVar36 + 0x634) & 0xfffffffe;
        lVar35 = *(longlong *)(&stack0x000000c0 + lVar26);
        puVar31 = (undefined4 *)(lVar35 + 0x530);
        *(byte *)puVar31 = (*(byte *)puVar31 & 0xfa | bVar38) & 0x7f;
        *(undefined4 *)(lVar35 + 0x54c) = *(undefined4 *)(*(longlong *)(lVar39 + 0x28) + 0x20);
        if (*(int *)(*(longlong *)(lVar35 + 0x20) + 0x40) != 1) {
          pcVar8 = *(code **)(*plVar7 + 0x270);
          *(undefined8 *)(puVar49 + -8) = 0x1053d3;
          (*pcVar8)(plVar7);
        }
        *(byte *)(*(longlong *)(&stack0x000000c0 + lVar26) + 0x531) =
             *(byte *)(*(longlong *)(&stack0x000000c0 + lVar26) + 0x531) & 0xfb;
        lVar48 = 2;
        puVar37 = (undefined4 *)(&stack0x00000358 + lVar26);
        do {
          uVar25 = puVar31[1];
          uVar6 = puVar31[2];
          uVar13 = puVar31[3];
          *puVar37 = *puVar31;
          puVar37[1] = uVar25;
          puVar37[2] = uVar6;
          puVar37[3] = uVar13;
          uVar25 = puVar31[5];
          uVar6 = puVar31[6];
          uVar13 = puVar31[7];
          puVar37[4] = puVar31[4];
          puVar37[5] = uVar25;
          puVar37[6] = uVar6;
          puVar37[7] = uVar13;
          uVar25 = puVar31[9];
          uVar6 = puVar31[10];
          uVar13 = puVar31[0xb];
          puVar37[8] = puVar31[8];
          puVar37[9] = uVar25;
          puVar37[10] = uVar6;
          puVar37[0xb] = uVar13;
          uVar25 = puVar31[0xd];
          uVar6 = puVar31[0xe];
          uVar13 = puVar31[0xf];
          puVar37[0xc] = puVar31[0xc];
          puVar37[0xd] = uVar25;
          puVar37[0xe] = uVar6;
          puVar37[0xf] = uVar13;
          uVar25 = puVar31[0x11];
          uVar6 = puVar31[0x12];
          uVar13 = puVar31[0x13];
          puVar37[0x10] = puVar31[0x10];
          puVar37[0x11] = uVar25;
          puVar37[0x12] = uVar6;
          puVar37[0x13] = uVar13;
          uVar25 = puVar31[0x15];
          uVar6 = puVar31[0x16];
          uVar13 = puVar31[0x17];
          puVar37[0x14] = puVar31[0x14];
          puVar37[0x15] = uVar25;
          puVar37[0x16] = uVar6;
          puVar37[0x17] = uVar13;
          uVar25 = puVar31[0x19];
          uVar6 = puVar31[0x1a];
          uVar13 = puVar31[0x1b];
          puVar37[0x18] = puVar31[0x18];
          puVar37[0x19] = uVar25;
          puVar37[0x1a] = uVar6;
          puVar37[0x1b] = uVar13;
          uVar25 = puVar31[0x1d];
          uVar6 = puVar31[0x1e];
          uVar13 = puVar31[0x1f];
          puVar37[0x1c] = puVar31[0x1c];
          puVar37[0x1d] = uVar25;
          puVar37[0x1e] = uVar6;
          puVar37[0x1f] = uVar13;
          puVar31 = puVar31 + 0x20;
          lVar48 = lVar48 + -1;
          puVar37 = puVar37 + 0x20;
        } while (lVar48 != 0);
        pcVar8 = *(code **)(*plVar7 + 0x28);
        *(undefined8 *)(puVar49 + -8) = 0x10544b;
        cVar15 = (*pcVar8)(plVar7);
        puVar30 = (undefined8 *)(lVar33 + 0xa40);
        if (cVar15 != '\0') {
          puVar30 = (undefined8 *)0x0;
        }
        *(undefined8 **)(&stack0x000000d0 + lVar26) = puVar30;
        bVar38 = (&stack0x00000359)[lVar26];
        if ((puVar30 != (undefined8 *)0x0) &&
           (((*(int *)(puVar30 + 1) != 0 || (*(short *)((longlong)puVar30 + 0xc) != 0)) &&
            ((bVar38 & 4) == 0)))) {
          puVar11 = (undefined8 *)*plVar55;
          *(undefined **)(puVar49 + 0x20) = &stack0x000002b0 + lVar26;
          uVar29 = *puVar11;
          *(undefined8 *)(puVar49 + -8) = 0x1054b1;
          iVar20 = func_0x(uVar29,puVar30,3);
          if (iVar20 != 0) {
            puVar31 = (undefined4 *)(&stack0x00000358 + lVar26);
            lVar33 = 2;
            puVar37 = (undefined4 *)(&stack0x00000458 + lVar26);
            do {
              uVar25 = puVar31[1];
              uVar6 = puVar31[2];
              uVar13 = puVar31[3];
              *puVar37 = *puVar31;
              puVar37[1] = uVar25;
              puVar37[2] = uVar6;
              puVar37[3] = uVar13;
              uVar25 = puVar31[5];
              uVar6 = puVar31[6];
              uVar13 = puVar31[7];
              puVar37[4] = puVar31[4];
              puVar37[5] = uVar25;
              puVar37[6] = uVar6;
              puVar37[7] = uVar13;
              uVar25 = puVar31[9];
              uVar6 = puVar31[10];
              uVar13 = puVar31[0xb];
              puVar37[8] = puVar31[8];
              puVar37[9] = uVar25;
              puVar37[10] = uVar6;
              puVar37[0xb] = uVar13;
              uVar25 = puVar31[0xd];
              uVar6 = puVar31[0xe];
              uVar13 = puVar31[0xf];
              puVar37[0xc] = puVar31[0xc];
              puVar37[0xd] = uVar25;
              puVar37[0xe] = uVar6;
              puVar37[0xf] = uVar13;
              uVar25 = puVar31[0x11];
              uVar6 = puVar31[0x12];
              uVar13 = puVar31[0x13];
              puVar37[0x10] = puVar31[0x10];
              puVar37[0x11] = uVar25;
              puVar37[0x12] = uVar6;
              puVar37[0x13] = uVar13;
              uVar25 = puVar31[0x15];
              uVar6 = puVar31[0x16];
              uVar13 = puVar31[0x17];
              puVar37[0x14] = puVar31[0x14];
              puVar37[0x15] = uVar25;
              puVar37[0x16] = uVar6;
              puVar37[0x17] = uVar13;
              uVar25 = puVar31[0x19];
              uVar6 = puVar31[0x1a];
              uVar13 = puVar31[0x1b];
              puVar37[0x18] = puVar31[0x18];
              puVar37[0x19] = uVar25;
              puVar37[0x1a] = uVar6;
              puVar37[0x1b] = uVar13;
              uVar25 = puVar31[0x1d];
              uVar6 = puVar31[0x1e];
              uVar13 = puVar31[0x1f];
              puVar37[0x1c] = puVar31[0x1c];
              puVar37[0x1d] = uVar25;
              puVar37[0x1e] = uVar6;
              puVar37[0x1f] = uVar13;
              puVar31 = puVar31 + 0x20;
              lVar33 = lVar33 + -1;
              puVar37 = puVar37 + 0x20;
            } while (lVar33 != 0);
            *(undefined4 *)(puVar49 + 0x30) = 0;
            *(undefined **)(puVar49 + 0x28) = &stack0x00000458 + lVar26;
            *(undefined8 *)(puVar49 + 0x20) = 0;
            *(undefined8 *)(puVar49 + -8) = 0x105552;
            func_0x(plVar55,&stack0x000002b0 + lVar26,&stack0x00000210 + lVar26,0);
          }
        }
        if (*(int *)(lVar40 + 0xf0) != 4) {
          if ((bVar38 & 4) == 0) {
            *(undefined4 *)(&stack0x00000290 + lVar26) = 0;
            (&stack0x000002a0)[lVar26] = 0;
            *(undefined8 *)(&stack0x000008b0 + lVar26) = 0;
            *(undefined8 *)(&stack0x0000089c + lVar26) = 0;
            *(undefined8 *)(&stack0x000008a4 + lVar26) = 0;
            *(undefined4 *)(&stack0x00000898 + lVar26) = 0;
            *(undefined4 *)(&stack0x000008ac + lVar26) = 0;
            *(undefined8 *)(&stack0x0000031c + lVar26) = 0;
            *(undefined4 *)(&stack0x0000032c + lVar26) = 0;
            plVar7 = *(longlong **)(lVar40 + 0x38);
            lVar33 = *plVar7;
            *(longlong *)(&stack0x000000f8 + lVar26) = lVar33;
            *(longlong *)(&stack0x000001d0 + lVar26) = *(longlong *)(lVar33 + 8) + 0x3c0;
            plVar7 = (longlong *)plVar7[1];
            pcVar8 = *(code **)(*plVar7 + 0x58);
            *(undefined8 *)(puVar49 + -8) = 0x1055d6;
            (*pcVar8)(plVar7);
            (&stack0x000008c6)[lVar26] = 1;
            (&stack0x000001f8)[lVar26] = (&stack0x000001f8)[lVar26] & 0xfc;
            *(undefined8 *)(puVar49 + -8) = 0x1055f0;
            func_0x(&stack0x00000200 + lVar26);
            *(undefined4 *)(&stack0x00000200 + lVar26) = *(undefined4 *)(&stack0x00000360 + lVar26);
            *(undefined4 *)(&stack0x00000204 + lVar26) = *(undefined4 *)(&stack0x00000364 + lVar26);
            *(undefined4 *)(&stack0x00000208 + lVar26) = *(undefined4 *)(&stack0x00000368 + lVar26);
            *(undefined4 *)(&stack0x0000020c + lVar26) = *(undefined4 *)(&stack0x0000036c + lVar26);
            (&stack0x000001f8)[lVar26] =
                 (byte)(&stack0x00000358)[lVar26] >> 6 & 2 | (&stack0x000001f8)[lVar26] & 0xfc |
                 (&stack0x00000358)[lVar26] & 1;
            *(undefined4 *)(&stack0x00000138 + lVar26) = *(undefined4 *)(&stack0x000001f8 + lVar26);
            *(undefined4 *)(&stack0x0000013c + lVar26) = *(undefined4 *)(&stack0x000001fc + lVar26);
            *(undefined4 *)(&stack0x00000140 + lVar26) = *(undefined4 *)(&stack0x00000200 + lVar26);
            *(undefined4 *)(&stack0x00000144 + lVar26) = *(undefined4 *)(&stack0x00000204 + lVar26);
            *(undefined4 *)(&stack0x00000150 + lVar26) = *(undefined4 *)(&stack0x00000368 + lVar26);
            *(undefined4 *)(&stack0x00000154 + lVar26) = *(undefined4 *)(&stack0x0000036c + lVar26);
            psVar32 = *(short **)(&stack0x00000210 + lVar26);
            *(short **)(&stack0x00000128 + lVar26) = psVar32;
            puVar57 = (ushort *)(psVar32 + 1);
            if (*psVar32 == 0) {
              if (*(int *)(psVar32 + 2) == 0) {
                *puVar57 = 0;
                uVar21 = *(uint *)(psVar32 + 8);
                uVar46 = (ulonglong)uVar21;
                *(uint *)(psVar32 + 10) = uVar21;
                pbVar51 = *(byte **)(psVar32 + 4);
                bVar38 = *pbVar51;
                if ((bVar38 & 0x10) != 0) {
                  uVar21 = uVar21 + 2 + (*(ushort *)(pbVar51 + uVar46) + 7 >> 3);
                  uVar46 = (ulonglong)uVar21;
                  *(uint *)(psVar32 + 10) = uVar21;
                  bVar38 = *pbVar51;
                }
                if ((bVar38 & 0x20) == 0) {
                  *(int *)(psVar32 + 2) = (int)uVar46;
                  psVar32[0xe] = 0;
                  *(undefined4 *)(psVar32 + 0xc) = *(undefined4 *)(psVar32 + 10);
                }
                else {
                  puVar50 = (ushort *)(pbVar51 + uVar46);
                  uVar43 = *puVar50;
                  psVar32[0xe] = uVar43;
                  if (uVar43 == 0) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar33 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                        ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                         (*(char *)(lVar33 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar49 + -8) = 0x105724;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x10574a;
                        (*_DAT_)(1,0x1766cd8,0x18869a8,0x80f);
                      }
                    }
                    uVar29 = *(undefined8 *)(psVar32 + 4);
                    *(undefined8 *)(puVar49 + -8) = 0x105758;
                    func_0x(uVar29,3);
                    uVar43 = psVar32[0xe];
                  }
                  uVar21 = *(int *)(psVar32 + 10) + 2 + (uint)uVar43 * 2;
                  *(uint *)(psVar32 + 0xc) = uVar21;
                  if (0x1f9e < uVar21) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar33 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0)) &&
                       ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                        (*(char *)(lVar33 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar49 + -8) = 0x1057f1;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x105817;
                        (*_DAT_)(1,0x1766cd8,0x18869a8,0x816);
                      }
                    }
                    uVar29 = *(undefined8 *)(psVar32 + 4);
                    *(undefined8 *)(puVar49 + -8) = 0x105825;
                    func_0x(uVar29,4);
                  }
                  uVar43 = puVar50[(ushort)psVar32[0xe]];
                  *(uint *)(psVar32 + 2) = uVar43 & 0x7fff;
                  if ((uVar43 & 0x7fff) < *(uint *)(psVar32 + 0xc)) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar33 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                        ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                         (*(char *)(lVar33 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar49 + -8) = 0x1058b9;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x1058df;
                        (*_DAT_)(1,0x1766cd8,0x18869a8,0x81d);
                      }
                    }
                    uVar29 = *(undefined8 *)(psVar32 + 4);
                    *(undefined8 *)(puVar49 + -8) = 0x1058ed;
                    func_0x(uVar29,4);
                  }
                  uVar43 = psVar32[0xe];
                  do {
                    uVar46 = (ulonglong)uVar43;
                    if (-1 < (short)puVar50[(ulonglong)(uVar43 - 1) + 1]) break;
                    lVar33 = *(longlong *)(psVar32 + 4);
                    lVar36 = (ulonglong)*(uint *)(psVar32 + 10) + lVar33;
                    if (uVar43 == 1) {
                      uVar21 = *(uint *)(psVar32 + 0xc);
                      uVar43 = *(ushort *)(lVar36 + uVar46 * 2);
                      uVar44 = uVar21;
LAB_:
                      if ((uVar43 & 0x7fff) < uVar21) goto LAB_;
                    }
                    else {
                      uVar21 = *(ushort *)(lVar36 + -2 + uVar46 * 2) & 0x7fff;
                      uVar44 = *(uint *)(psVar32 + 0xc);
                      uVar43 = *(ushort *)(lVar36 + uVar46 * 2);
                      if (uVar44 <= uVar21) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar49 + -8) = 0x10595d;
                      func_0x(lVar33,7);
                      uVar44 = *(uint *)(psVar32 + 0xc);
                      lVar33 = *(longlong *)(psVar32 + 4);
                    }
                    if ((uVar21 < uVar44) || (*(uint *)(psVar32 + 2) < uVar21)) goto LAB_;
                    if (*(ushort *)(lVar33 + (ulonglong)uVar21) == 5) {
                      *puVar57 = *puVar57 | 2;
                      psVar32[0xe] = psVar32[0xe] + -1;
                      psVar32[0x15] = (short)uVar21;
                      lVar33 = (ulonglong)(uVar21 & 0xffff) + *(longlong *)(psVar32 + 4);
                      uVar43 = *(ushort *)(lVar33 + 2);
                      uVar19 = psVar32[0x16] & 0xc7ff;
                      if ((uVar43 & 0x4000) != 0) {
                        uVar19 = uVar43 & 0x3800 | uVar19;
                      }
                      psVar32[0x16] = uVar19;
                      psVar32[0x16] = (uVar19 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar19;
                      break;
                    }
                    if (*(ushort *)(lVar33 + (ulonglong)uVar21) < 0x400) break;
                    *puVar57 = *puVar57 | 1;
                    uVar43 = psVar32[0xe] - 1;
                    psVar32[0xe] = uVar43;
                  } while (uVar43 != 0);
                }
                iVar20 = 0;
                if ((**(byte **)(psVar32 + 4) & 0x40) == 0) {
                  *(undefined4 *)(psVar32 + 0x13) = 0;
                }
                else {
                  *(undefined4 *)(psVar32 + 0x13) = *(undefined4 *)(psVar32 + 2);
                  *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + 0xe;
                  *(undefined8 *)(puVar49 + -8) = 0x105a43;
                  puVar34 = (ulonglong *)func_0x(puVar57);
                  uVar46 = *puVar34;
                  uVar43 = (ushort)(uVar46 >> 0x30);
                  if ((((uint)(int)(short)uVar43 >> 1 ^ (int)(short)uVar43) & 0x2000) != 0) {
                    if ((uVar46 & 0x4000000000000000) == 0) {
                      uVar43 = uVar43 & 0xdfff;
                    }
                    else {
                      uVar43 = uVar43 | 0x2000;
                    }
                  }
                  if (uVar43 == 0xfffc) {
                    iVar20 = (int)((uVar46 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + iVar20;
                }
                uVar21 = *(uint *)(psVar32 + 2);
                if ((*(ulonglong *)(psVar32 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar32 + 0xf) < (ulonglong)uVar21 + *(longlong *)(psVar32 + 4)))
                {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar33 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                       (lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0)) &&
                      (*(char *)(lVar33 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar49 + -8) = 0x105b2c;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar49 + 0x20) = 0;
                      *(undefined8 *)(puVar49 + -8) = 0x105b52;
                      (*_DAT_)(1,0x1766cd8,0x18869a8,0x877);
                    }
                  }
                  uVar29 = *(undefined8 *)(psVar32 + 4);
                  *(undefined8 *)(puVar49 + -8) = 0x105b60;
                  func_0x(uVar29,0x12);
                  uVar21 = *(uint *)(psVar32 + 2);
                }
                if (0x3f3b < uVar21 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar33 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                      ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                       (*(char *)(lVar33 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar49 + -8) = 0x105beb;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      uVar29 = *(undefined8 *)(psVar32 + 4);
                      *(undefined8 *)(puVar49 + -8) = 0x105bf9;
                      func_0x(uVar29,5);
                      goto LAB_;
                    }
                    *(undefined8 *)(puVar49 + 0x20) = 0;
                    *(undefined8 *)(puVar49 + -8) = 0x105c1f;
                    (*_DAT_)(1,0x1766cd8,0x18869a8,0x87c);
                  }
                  uVar29 = *(undefined8 *)(psVar32 + 4);
                  *(undefined8 *)(puVar49 + -8) = 0x105c2d;
                  func_0x(uVar29,5);
                }
              }
LAB_:
              uVar21 = *(uint *)(psVar32 + 2);
              if (uVar21 < 9) {
                bVar38 = **(byte **)(psVar32 + 4);
                if (((bVar38 & 0xe) != 0) && ((bVar38 & 0xe) != 0xc)) goto LAB_;
                uVar21 = 9;
              }
              else {
LAB_:
                bVar38 = **(byte **)(psVar32 + 4);
              }
              if ((bVar38 & 0x40) != 0) {
                uVar21 = *(uint *)(psVar32 + 0x13);
              }
              psVar52 = *(short **)(&stack0x00000128 + lVar26);
            }
            else {
              uVar21 = *(uint *)(psVar32 + 2);
              if (uVar21 == 0) {
                *(undefined8 *)(puVar49 + -8) = 0x105c7f;
                func_0x(puVar57);
                uVar21 = *(uint *)(psVar32 + 2);
                if (uVar21 == 0) {
                  *(undefined8 *)(puVar49 + -8) = 0x105c90;
                  func_0x(puVar57);
                  uVar21 = *(uint *)(psVar32 + 2);
                }
              }
              if (uVar21 < 9) {
                bVar38 = **(byte **)(psVar32 + 4);
                if (((bVar38 & 0x1c) != 0) && ((bVar38 & 0x1c) != 0xc)) goto LAB_;
                uVar21 = 9;
              }
              else {
LAB_:
                bVar38 = **(byte **)(psVar32 + 4);
              }
              psVar52 = psVar32;
              if ((bVar38 & 2) != 0) {
                uVar21 = *(uint *)(psVar32 + 0x18);
              }
            }
            pcVar8 = *(code **)*plVar7;
            *(undefined8 *)(puVar49 + -8) = 0x105cce;
            cVar15 = (*pcVar8)(plVar7);
            if (cVar15 == '\0') {
              if (((&stack0x00000138)[lVar26] & 1) == 0) {
LAB_:
                lVar33 = plVar7[0x1a];
                if (((&stack0x00000140)[lVar26] & 1) != 0) goto LAB_;
                pcVar8 = *(code **)*plVar7;
                *(undefined8 *)(puVar49 + -8) = 0x106311;
                cVar15 = (*pcVar8)(plVar7);
                if (cVar15 != '\0') goto LAB_;
                pcVar8 = *(code **)(*plVar7 + 0x88);
                *(undefined8 *)(puVar49 + -8) = 0x106326;
                cVar15 = (*pcVar8)(plVar7);
                if (cVar15 != '\0') {
                  if ((&stack0x00000141)[lVar26] != '\0') goto LAB_;
                  if (lVar33 == 0) {
                    pcVar8 = *(code **)(*plVar7 + 0x18);
                    *(undefined8 *)(puVar49 + -8) = 0x10634a;
                    cVar15 = (*pcVar8)(plVar7);
                    if (cVar15 == '\0') goto LAB_;
                  }
                  if ((*(byte *)(plVar7 + 0x4a) & 4) == 0) {
                    if ((*(byte *)(plVar7 + 0x4a) & 0x5a) == 0) {
                      if ((*(byte *)(plVar7 + 0x43) & 1) != 0) {
                        if (plVar7[0x1a] == 0) {
                          pcVar8 = *(code **)(*plVar7 + 0x88);
                          *(undefined8 *)(puVar49 + -8) = 0x10638f;
                          cVar15 = (*pcVar8)(plVar7);
                          if (cVar15 != '\0') {
                            pcVar8 = *(code **)(*plVar7 + 0x18);
                            *(undefined8 *)(puVar49 + -8) = 0x10639d;
                            cVar15 = (*pcVar8)(plVar7);
                            if (cVar15 == '\0') {
                              *(byte *)(plVar7 + 0x4a) = *(byte *)(plVar7 + 0x4a) | 4;
                              goto LAB_;
                            }
                          }
                        }
                        *(undefined8 *)(puVar49 + -8) = 0x1063b6;
                        iVar20 = func_0x(plVar7);
                        if (iVar20 == 0) {
                          pcVar8 = *(code **)(*plVar7 + 0x270);
                          *(undefined8 *)(puVar49 + -8) = 0x1063c7;
                          (*pcVar8)(plVar7);
                        }
                        if ((*(byte *)(plVar7 + 0x43) & 4) == 0) {
                          if ((*(byte *)(plVar7 + 0x4a) & 0x52) == 2) {
                            lVar36 = plVar7[0x1a];
                            *(undefined8 *)(puVar49 + -8) = 0x106402;
                            cVar15 = func_0x(lVar36);
                            if (((cVar15 != '\0') && (*(char *)(plVar7[0x1a] + 0x130) == '\0')) &&
                               (*(undefined *)(plVar7[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                              *(undefined8 *)(puVar49 + 0x20) = 0;
                              *(undefined8 *)(puVar49 + -8) = 0x106447;
                              func_0x(0x1e7a710,0x1c,0x10,1);
                            }
                          }
                          uVar44 = (uint)((*(byte *)(plVar7 + 0x4a) & 0x5a) != 0);
                        }
                        else {
                          pcVar8 = *(code **)(*plVar7 + 0x1e8);
                          *(undefined8 *)(puVar49 + -8) = 0x1063de;
                          uVar29 = (*pcVar8)(plVar7);
                          *(undefined8 *)(puVar49 + -8) = 0x1063e6;
                          uVar44 = func_0x(uVar29);
                        }
                        if (uVar44 != 0) goto LAB_;
                      }
                    }
                    else {
LAB_:
                      if (((*(byte *)(plVar7 + 0x4a) & 0x40) != 0) &&
                         ((&stack0x00000142)[lVar26] != '\0')) goto LAB_;
                    }
                  }
                }
LAB_:
                if (((&stack0x00000140)[lVar26] & 0x1c) == 0) {
                  lVar36 = *(longlong *)(&stack0x00000148 + lVar26);
                  if (lVar36 != 0) {
                    iVar20 = *(int *)(*(longlong *)(lVar36 + 8) + 0x68);
                    bVar58 = iVar20 < 0;
                    if (bVar58) {
                      *(undefined8 *)(puVar49 + 0x20) = 0;
                      *(undefined8 *)(puVar49 + -8) = 0x1064bd;
                      (*_DAT_)(1,0x1915658,0x1913d28,0xc9d);
                      iVar20 = *(int *)(*(longlong *)(lVar36 + 8) + 0x68);
                      bVar58 = iVar20 < 0;
                    }
                    if (((iVar20 != 0 && !bVar58) &&
                        (iVar20 = *(int *)(*(longlong *)
                                            (*(longlong *)(&stack0x00000148 + lVar26) + 8) + 0x100),
                        iVar20 != 0)) && (1 < iVar20 - 3U)) {
                      *(undefined8 *)(puVar49 + 0x20) = 0;
                      *(undefined8 *)(puVar49 + -8) = 0x106508;
                      (*_DAT_)(1,0x1915680,0x19156d0,0x116);
                    }
                    uVar29 = *(undefined8 *)(&stack0x00000148 + lVar26);
                    *(undefined8 *)(puVar49 + -8) = 0x106518;
                    iVar20 = func_0x(uVar29);
                    if ((((iVar20 != 0) &&
                         ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000148 + lVar26) + 8) +
                                    0x109) & 1) == 0)) &&
                        (iVar20 = *(int *)(*(longlong *)
                                            (*(longlong *)(&stack0x00000148 + lVar26) + 8) + 0x100),
                        iVar20 != 0)) && (1 < iVar20 - 3U)) {
                      *(undefined8 *)(puVar49 + 0x20) = 0;
                      *(undefined8 *)(puVar49 + -8) = 0x106568;
                      (*_DAT_)(1,0x1915700,0x19156d0,0x119);
                    }
                  }
                  if ((lVar33 != 0) &&
                     ((0 < *(int *)(lVar33 + 0x78) || (0 < *(int *)(lVar33 + 0x74)))))
                  goto LAB_;
                  if ((*(byte *)(plVar7 + 0x4a) & 4) != 0) goto LAB_;
                  if ((*(byte *)(plVar7 + 0x4a) & 0x5a) != 0) goto LAB_;
                  if ((*(byte *)(plVar7 + 0x43) & 1) == 0) goto LAB_;
                  if (plVar7[0x1a] != 0) {
LAB_:
                    *(undefined8 *)(puVar49 + -8) = 0x1065e3;
                    iVar20 = func_0x(plVar7);
                    if (iVar20 == 0) {
                      pcVar8 = *(code **)(*plVar7 + 0x270);
                      *(undefined8 *)(puVar49 + -8) = 0x1065f4;
                      (*pcVar8)(plVar7);
                    }
                    if ((*(byte *)(plVar7 + 0x43) & 4) == 0) {
                      if ((*(byte *)(plVar7 + 0x4a) & 0x52) == 2) {
                        lVar36 = plVar7[0x1a];
                        *(undefined8 *)(puVar49 + -8) = 0x10662f;
                        cVar15 = func_0x(lVar36);
                        if (((cVar15 != '\0') && (*(char *)(plVar7[0x1a] + 0x130) == '\0')) &&
                           (*(undefined *)(plVar7[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                          *(undefined8 *)(puVar49 + 0x20) = 0;
                          *(undefined8 *)(puVar49 + -8) = 0x106673;
                          func_0x(0x1e7a710,0x1c,0x10,1);
                        }
                      }
                      uVar44 = (uint)((*(byte *)(plVar7 + 0x4a) & 0x5a) != 0);
                    }
                    else {
                      pcVar8 = *(code **)(*plVar7 + 0x1e8);
                      *(undefined8 *)(puVar49 + -8) = 0x10660b;
                      uVar29 = (*pcVar8)(plVar7);
                      *(undefined8 *)(puVar49 + -8) = 0x106613;
                      uVar44 = func_0x(uVar29);
                    }
                    if (uVar44 == 0) goto LAB_;
                    goto LAB_;
                  }
                  pcVar8 = *(code **)(*plVar7 + 0x88);
                  *(undefined8 *)(puVar49 + -8) = 0x1065c5;
                  cVar15 = (*pcVar8)(plVar7);
                  if (cVar15 == '\0') goto LAB_;
                  pcVar8 = *(code **)(*plVar7 + 0x18);
                  *(undefined8 *)(puVar49 + -8) = 0x1065d3;
                  cVar15 = (*pcVar8)(plVar7);
                  if (cVar15 != '\0') goto LAB_;
LAB_:
                  *(byte *)(plVar7 + 0x4a) = *(byte *)(plVar7 + 0x4a) | 4;
                  goto LAB_;
                }
LAB_:
                if (lVar33 != 0) {
LAB_:
                  if (((&stack0x00000140)[lVar26] & 0x1c) == 0) {
                    lVar36 = *(longlong *)(&stack0x00000148 + lVar26);
                    if (lVar36 != 0) {
                      iVar20 = *(int *)(*(longlong *)(lVar36 + 8) + 0x68);
                      bVar58 = iVar20 < 0;
                      if (bVar58) {
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x1066df;
                        (*_DAT_)(1,0x1915658,0x1913d28,0xc9d);
                        iVar20 = *(int *)(*(longlong *)(lVar36 + 8) + 0x68);
                        bVar58 = iVar20 < 0;
                      }
                      if (((iVar20 != 0 && !bVar58) &&
                          (iVar20 = *(int *)(*(longlong *)
                                              (*(longlong *)(&stack0x00000148 + lVar26) + 8) + 0x100
                                            ), iVar20 != 0)) && (1 < iVar20 - 3U)) {
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x10672a;
                        (*_DAT_)(1,0x1915680,0x19156d0,0x116);
                      }
                      uVar29 = *(undefined8 *)(&stack0x00000148 + lVar26);
                      *(undefined8 *)(puVar49 + -8) = 0x10673a;
                      iVar20 = func_0x(uVar29);
                      if (((iVar20 != 0) &&
                          ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000148 + lVar26) + 8) +
                                     0x109) & 1) == 0)) &&
                         ((iVar20 = *(int *)(*(longlong *)
                                              (*(longlong *)(&stack0x00000148 + lVar26) + 8) + 0x100
                                            ), iVar20 != 0 && (1 < iVar20 - 3U)))) {
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x10678a;
                        (*_DAT_)(1,0x1915700,0x19156d0,0x119);
                      }
                    }
                    if ((*(int *)(lVar33 + 0x78) < 1) && (*(int *)(lVar33 + 0x74) < 1)) {
                      if ((*(byte *)(plVar7 + 0x4a) & 4) == 0) {
                        if ((*(byte *)(plVar7 + 0x4a) & 0x5a) == 0) {
                          if ((*(byte *)(plVar7 + 0x43) & 1) != 0) {
                            if (plVar7[0x1a] == 0) {
                              pcVar8 = *(code **)(*plVar7 + 0x88);
                              *(undefined8 *)(puVar49 + -8) = 0x1067e2;
                              cVar15 = (*pcVar8)(plVar7);
                              if (cVar15 != '\0') {
                                pcVar8 = *(code **)(*plVar7 + 0x18);
                                *(undefined8 *)(puVar49 + -8) = 0x1067f0;
                                cVar15 = (*pcVar8)(plVar7);
                                if (cVar15 == '\0') {
                                  *(byte *)(plVar7 + 0x4a) = *(byte *)(plVar7 + 0x4a) | 4;
                                  goto LAB_;
                                }
                              }
                            }
                            *(undefined8 *)(puVar49 + -8) = 0x106809;
                            iVar20 = func_0x(plVar7);
                            if (iVar20 == 0) {
                              pcVar8 = *(code **)(*plVar7 + 0x270);
                              *(undefined8 *)(puVar49 + -8) = 0x10681a;
                              (*pcVar8)(plVar7);
                            }
                            if ((*(byte *)(plVar7 + 0x43) & 4) == 0) {
                              if ((*(byte *)(plVar7 + 0x4a) & 0x52) == 2) {
                                lVar36 = plVar7[0x1a];
                                *(undefined8 *)(puVar49 + -8) = 0x106855;
                                cVar15 = func_0x(lVar36);
                                if (((cVar15 != '\0') && (*(char *)(plVar7[0x1a] + 0x130) == '\0'))
                                   && (*(undefined *)(plVar7[0x1a] + 0x130) = 1,
                                      *_DAT_ != '\0')) {
                                  *(undefined8 *)(puVar49 + 0x20) = 0;
                                  *(undefined8 *)(puVar49 + -8) = 0x106899;
                                  func_0x(0x1e7a710,0x1c,0x10,1);
                                }
                              }
                              uVar44 = (uint)((*(byte *)(plVar7 + 0x4a) & 0x5a) != 0);
                            }
                            else {
                              pcVar8 = *(code **)(*plVar7 + 0x1e8);
                              *(undefined8 *)(puVar49 + -8) = 0x106831;
                              uVar29 = (*pcVar8)(plVar7);
                              *(undefined8 *)(puVar49 + -8) = 0x106839;
                              uVar44 = func_0x(uVar29);
                            }
                            if (uVar44 != 0) goto LAB_;
                          }
                        }
                        else {
LAB_:
                          if ((*(byte *)(plVar7 + 0x4a) & 0x10) != 0) goto LAB_;
                        }
                      }
LAB_:
                      if ((*(byte *)(plVar7 + 0x4a) & 4) == 0) {
                        if ((*(byte *)(plVar7 + 0x4a) & 0x5a) == 0) {
                          if ((*(byte *)(plVar7 + 0x43) & 1) != 0) {
                            if (plVar7[0x1a] == 0) {
                              pcVar8 = *(code **)(*plVar7 + 0x88);
                              *(undefined8 *)(puVar49 + -8) = 0x1068f8;
                              cVar15 = (*pcVar8)(plVar7);
                              if (cVar15 != '\0') {
                                pcVar8 = *(code **)(*plVar7 + 0x18);
                                *(undefined8 *)(puVar49 + -8) = 0x106906;
                                cVar15 = (*pcVar8)(plVar7);
                                if (cVar15 == '\0') {
                                  *(byte *)(plVar7 + 0x4a) = *(byte *)(plVar7 + 0x4a) | 4;
                                  goto LAB_;
                                }
                              }
                            }
                            *(undefined8 *)(puVar49 + -8) = 0x10691f;
                            iVar20 = func_0x(plVar7);
                            if (iVar20 == 0) {
                              pcVar8 = *(code **)(*plVar7 + 0x270);
                              *(undefined8 *)(puVar49 + -8) = 0x106930;
                              (*pcVar8)(plVar7);
                            }
                            if ((*(byte *)(plVar7 + 0x43) & 4) == 0) {
                              if ((*(byte *)(plVar7 + 0x4a) & 0x52) == 2) {
                                lVar36 = plVar7[0x1a];
                                *(undefined8 *)(puVar49 + -8) = 0x10696b;
                                cVar15 = func_0x(lVar36);
                                if (((cVar15 != '\0') && (*(char *)(plVar7[0x1a] + 0x130) == '\0'))
                                   && (*(undefined *)(plVar7[0x1a] + 0x130) = 1,
                                      *_DAT_ != '\0')) {
                                  *(undefined8 *)(puVar49 + 0x20) = 0;
                                  *(undefined8 *)(puVar49 + -8) = 0x1069af;
                                  func_0x(0x1e7a710,0x1c,0x10,1);
                                }
                              }
                              uVar44 = (uint)((*(byte *)(plVar7 + 0x4a) & 0x5a) != 0);
                            }
                            else {
                              pcVar8 = *(code **)(*plVar7 + 0x1e8);
                              *(undefined8 *)(puVar49 + -8) = 0x106947;
                              uVar29 = (*pcVar8)(plVar7);
                              *(undefined8 *)(puVar49 + -8) = 0x10694f;
                              uVar44 = func_0x(uVar29);
                            }
                            if (uVar44 != 0) goto LAB_;
                          }
                        }
                        else {
LAB_:
                          if ((*(byte *)(plVar7 + 0x4a) & 0x40) != 0) goto LAB_;
                        }
                      }
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar49 + -8) = 0x1069d7;
                  func_0x(lVar33,0);
                }
LAB_:
                *(undefined8 *)(puVar49 + -8) = 0x1069df;
                iVar20 = func_0x(plVar7);
                if (iVar20 == 0) {
                  pcVar8 = *(code **)(*plVar7 + 0x270);
                  *(undefined8 *)(puVar49 + -8) = 0x1069f0;
                  (*pcVar8)(plVar7);
                }
                lVar33 = plVar7[0x1a];
                if (((&stack0x00000140)[lVar26] & 0x24) == 0) {
                  if ((*(byte *)(plVar7 + 0x4a) & 4) == 0) {
                    if ((*(byte *)(plVar7 + 0x4a) & 0x5a) != 0) goto LAB_;
                    if ((*(byte *)(plVar7 + 0x43) & 1) != 0) {
                      if (lVar33 == 0) {
                        pcVar8 = *(code **)(*plVar7 + 0x88);
                        *(undefined8 *)(puVar49 + -8) = 0x106a3c;
                        cVar15 = (*pcVar8)(plVar7);
                        if (cVar15 != '\0') {
                          pcVar8 = *(code **)(*plVar7 + 0x18);
                          *(undefined8 *)(puVar49 + -8) = 0x106a4a;
                          cVar15 = (*pcVar8)(plVar7);
                          if (cVar15 == '\0') goto LAB_;
                        }
                      }
                      *(undefined8 *)(puVar49 + -8) = 0x106a5a;
                      iVar20 = func_0x(plVar7);
                      if (iVar20 == 0) {
                        pcVar8 = *(code **)(*plVar7 + 0x270);
                        *(undefined8 *)(puVar49 + -8) = 0x106a6b;
                        (*pcVar8)(plVar7);
                      }
                      if ((*(byte *)(plVar7 + 0x43) & 4) == 0) {
                        if ((*(byte *)(plVar7 + 0x4a) & 0x52) == 2) {
                          lVar36 = plVar7[0x1a];
                          *(undefined8 *)(puVar49 + -8) = 0x106aa6;
                          cVar15 = func_0x(lVar36);
                          if (((cVar15 != '\0') && (*(char *)(plVar7[0x1a] + 0x130) == '\0')) &&
                             (*(undefined *)(plVar7[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                            *(undefined8 *)(puVar49 + 0x20) = 0;
                            *(undefined8 *)(puVar49 + -8) = 0x106aeb;
                            func_0x(0x1e7a710,0x1c,0x10,1);
                          }
                        }
                        uVar44 = (uint)((*(byte *)(plVar7 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        pcVar8 = *(code **)(*plVar7 + 0x1e8);
                        *(undefined8 *)(puVar49 + -8) = 0x106a82;
                        uVar29 = (*pcVar8)(plVar7);
                        *(undefined8 *)(puVar49 + -8) = 0x106a8a;
                        uVar44 = func_0x(uVar29);
                      }
                      if (uVar44 != 0) goto LAB_;
                    }
                  }
                  if ((lVar33 == 0) || (*(int *)(lVar33 + 0x74) < 1)) goto LAB_;
                }
LAB_:
                psVar32 = *(short **)(&stack0x00000128 + lVar26);
                *(undefined8 *)(puVar49 + -8) = 0x106b21;
                iVar20 = func_0x(psVar32);
                if (iVar20 != 0) {
                  if (*psVar32 == 0) {
                    *(undefined8 *)(puVar49 + -8) = 0x106b3a;
                    func_0x();
                  }
                  else {
                    *(undefined8 *)(puVar49 + -8) = 0x106b41;
                    func_0x(puVar57,&stack0x000001c8 + lVar26);
                  }
                  uVar44 = 0;
                  uVar43 = *(ushort *)(&stack0x000001ce + lVar26);
                  if ((((uint)(int)(short)uVar43 >> 1 ^ (int)(short)uVar43) & 0x2000) != 0) {
                    if ((uVar43 >> 0xe & 1) == 0) {
                      uVar43 = uVar43 & 0xdfff;
                    }
                    else {
                      uVar43 = uVar43 | 0x2000;
                    }
                  }
                  if (uVar43 == 0xfffc) {
                    uVar44 = (uint)(*(ushort *)(&stack0x000001cc + lVar26) >> 5);
                  }
                  uVar21 = uVar21 + uVar44;
                }
                lVar33 = plVar7[0x1a];
                pcVar8 = *(code **)(*plVar7 + 0x88);
                *(undefined8 *)(puVar49 + -8) = 0x106b9d;
                cVar15 = (*pcVar8)(plVar7);
                if ((((cVar15 == '\0') && (lVar33 != 0)) &&
                    ((0 < *(int *)(lVar33 + 0x78) || (0 < *(int *)(lVar33 + 0x74))))) &&
                   (uVar21 < 0x1f74)) {
                  uVar21 = uVar21 + 8;
                }
                uVar21 = uVar21 + 0xe;
              }
              else {
                pcVar8 = *(code **)(*plVar7 + 0x88);
                *(undefined8 *)(puVar49 + -8) = 0x1062de;
                cVar15 = (*pcVar8)(plVar7);
                if (cVar15 == '\0') goto LAB_;
                pcVar8 = *(code **)(*plVar7 + 0x18);
                *(undefined8 *)(puVar49 + -8) = 0x1062ec;
                cVar15 = (*pcVar8)(plVar7);
                if (cVar15 != '\0') goto LAB_;
LAB_:
                psVar52 = *(short **)(&stack0x00000128 + lVar26);
                *(undefined8 *)(puVar49 + -8) = 0x106bdf;
                iVar20 = func_0x(psVar52);
                if (iVar20 != 0) {
                  if (*psVar52 != 0) goto LAB_;
                  if (*(int *)(psVar32 + 2) == 0) {
                    *puVar57 = 0;
                    uVar21 = *(uint *)(psVar32 + 8);
                    uVar46 = (ulonglong)uVar21;
                    *(uint *)(psVar32 + 10) = uVar21;
                    pbVar51 = *(byte **)(psVar32 + 4);
                    bVar38 = *pbVar51;
                    if ((bVar38 & 0x10) != 0) {
                      uVar21 = uVar21 + 2 + (*(ushort *)(pbVar51 + uVar46) + 7 >> 3);
                      uVar46 = (ulonglong)uVar21;
                      *(uint *)(psVar32 + 10) = uVar21;
                      bVar38 = *pbVar51;
                    }
                    if ((bVar38 & 0x20) == 0) {
                      *(int *)(psVar32 + 2) = (int)uVar46;
                      psVar32[0xe] = 0;
                      *(undefined4 *)(psVar32 + 0xc) = *(undefined4 *)(psVar32 + 10);
                    }
                    else {
                      puVar50 = (ushort *)(pbVar51 + uVar46);
                      uVar43 = *puVar50;
                      psVar32[0xe] = uVar43;
                      if (uVar43 == 0) {
                        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                            (lVar33 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0)) &&
                           ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                            (*(char *)(lVar33 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar49 + -8) = 0x106cc0;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar49 + 0x20) = 0;
                            *(undefined8 *)(puVar49 + -8) = 0x106ce6;
                            (*_DAT_)(1,0x1766cd8,0x18869a8,0x80f);
                          }
                        }
                        uVar29 = *(undefined8 *)(psVar32 + 4);
                        *(undefined8 *)(puVar49 + -8) = 0x106cf4;
                        func_0x(uVar29,3);
                        uVar43 = psVar32[0xe];
                      }
                      uVar21 = *(int *)(psVar32 + 10) + 2 + (uint)uVar43 * 2;
                      *(uint *)(psVar32 + 0xc) = uVar21;
                      if (0x1f9e < uVar21) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           ((lVar33 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                            ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                             (*(char *)(lVar33 + 0x499) != '\0')))))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar49 + -8) = 0x106d8d;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar49 + 0x20) = 0;
                            *(undefined8 *)(puVar49 + -8) = 0x106db3;
                            (*_DAT_)(1,0x1766cd8,0x18869a8,0x816);
                          }
                        }
                        uVar29 = *(undefined8 *)(psVar32 + 4);
                        *(undefined8 *)(puVar49 + -8) = 0x106dc1;
                        func_0x(uVar29,4);
                      }
                      uVar43 = puVar50[(ushort)psVar32[0xe]];
                      *(uint *)(psVar32 + 2) = uVar43 & 0x7fff;
                      if ((uVar43 & 0x7fff) < *(uint *)(psVar32 + 0xc)) {
                        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                            (lVar33 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0)) &&
                           ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                            (*(char *)(lVar33 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar49 + -8) = 0x106e55;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar49 + 0x20) = 0;
                            *(undefined8 *)(puVar49 + -8) = 0x106e7b;
                            (*_DAT_)(1,0x1766cd8,0x18869a8,0x81d);
                          }
                        }
                        uVar29 = *(undefined8 *)(psVar32 + 4);
                        *(undefined8 *)(puVar49 + -8) = 0x106e89;
                        func_0x(uVar29,4);
                      }
                      uVar43 = psVar32[0xe];
                      do {
                        uVar46 = (ulonglong)uVar43;
                        if (-1 < (short)puVar50[(ulonglong)(uVar43 - 1) + 1]) break;
                        lVar33 = *(longlong *)(psVar32 + 4);
                        lVar36 = (ulonglong)*(uint *)(psVar32 + 10) + lVar33;
                        if (uVar43 == 1) {
                          uVar21 = *(uint *)(psVar32 + 0xc);
                          uVar27 = (ulonglong)uVar21;
                          uVar43 = *(ushort *)(lVar36 + uVar46 * 2);
LAB_:
                          if ((uVar43 & 0x7fff) < (uint)uVar27) goto LAB_;
                        }
                        else {
                          uVar44 = *(ushort *)(lVar36 + -2 + uVar46 * 2) & 0x7fff;
                          uVar27 = (ulonglong)uVar44;
                          uVar21 = *(uint *)(psVar32 + 0xc);
                          uVar43 = *(ushort *)(lVar36 + uVar46 * 2);
                          if (uVar21 <= uVar44) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar49 + -8) = 0x106eed;
                          func_0x(lVar33,7);
                          uVar21 = *(uint *)(psVar32 + 0xc);
                        }
                        if (((uint)uVar27 < uVar21) || (*(uint *)(psVar32 + 2) < (uint)uVar27))
                        goto LAB_;
                        if (*(ushort *)(uVar27 + *(longlong *)(psVar32 + 4)) == 5) {
                          *puVar57 = *puVar57 | 2;
                          psVar32[0xe] = psVar32[0xe] + -1;
                          psVar32[0x15] = (short)uVar27;
                          lVar33 = (uVar27 & 0xffff) + *(longlong *)(psVar32 + 4);
                          uVar43 = *(ushort *)(lVar33 + 2);
                          uVar19 = psVar32[0x16] & 0xc7ff;
                          if ((uVar43 & 0x4000) != 0) {
                            uVar19 = uVar43 & 0x3800 | uVar19;
                          }
                          psVar32[0x16] = uVar19;
                          psVar32[0x16] = (uVar19 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar19;
                          break;
                        }
                        if (*(ushort *)(uVar27 + *(longlong *)(psVar32 + 4)) < 0x400) break;
                        *puVar57 = *puVar57 | 1;
                        uVar43 = psVar32[0xe] - 1;
                        psVar32[0xe] = uVar43;
                      } while (uVar43 != 0);
                    }
                    iVar20 = 0;
                    if ((**(byte **)(psVar32 + 4) & 0x40) == 0) {
                      *(undefined4 *)(psVar32 + 0x13) = 0;
                    }
                    else {
                      *(undefined4 *)(psVar32 + 0x13) = *(undefined4 *)(psVar32 + 2);
                      *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + 0xe;
                      *(undefined8 *)(puVar49 + -8) = 0x106fd6;
                      puVar34 = (ulonglong *)func_0x(puVar57);
                      uVar46 = *puVar34;
                      uVar43 = (ushort)(uVar46 >> 0x30);
                      if ((((uint)(int)(short)uVar43 >> 1 ^ (int)(short)uVar43) & 0x2000) != 0) {
                        if ((uVar46 & 0x4000000000000000) == 0) {
                          uVar43 = uVar43 & 0xdfff;
                        }
                        else {
                          uVar43 = uVar43 | 0x2000;
                        }
                      }
                      if (uVar43 == 0xfffc) {
                        iVar20 = (int)((uVar46 >> 0x20 & 0xffff) >> 5);
                      }
                      *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + iVar20;
                    }
                    uVar21 = *(uint *)(psVar32 + 2);
                    if ((*(ulonglong *)(psVar32 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar32 + 0xf) <
                        (ulonglong)uVar21 + *(longlong *)(psVar32 + 4))) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         (((lVar33 = *(longlong *)
                                      ((ulonglong)*_DAT_ +
                                       *(longlong *)
                                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                        (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                           (lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0)) &&
                          (*(char *)(lVar33 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar49 + -8) = 0x1070bf;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(puVar49 + 0x20) = 0;
                          *(undefined8 *)(puVar49 + -8) = 0x1070e5;
                          (*_DAT_)(1,0x1766cd8,0x18869a8,0x877);
                        }
                      }
                      uVar29 = *(undefined8 *)(psVar32 + 4);
                      *(undefined8 *)(puVar49 + -8) = 0x1070f3;
                      func_0x(uVar29,0x12);
                      uVar21 = *(uint *)(psVar32 + 2);
                    }
                    if (0x3f3b < uVar21 - 1) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar33 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                          ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                           (*(char *)(lVar33 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) goto LAB_;
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x10719a;
                        (*_DAT_)(1,0x1766cd8,0x18869a8,0x87c);
                      }
                      goto LAB_;
                    }
                  }
                  goto LAB_;
                }
              }
            }
            else if (*psVar52 == 0) {
              if (*(int *)(psVar32 + 2) == 0) {
                *puVar57 = 0;
                uVar21 = *(uint *)(psVar32 + 8);
                uVar46 = (ulonglong)uVar21;
                *(uint *)(psVar32 + 10) = uVar21;
                pbVar51 = *(byte **)(psVar32 + 4);
                bVar38 = *pbVar51;
                if ((bVar38 & 0x10) != 0) {
                  uVar21 = uVar21 + 2 + (*(ushort *)(pbVar51 + uVar46) + 7 >> 3);
                  uVar46 = (ulonglong)uVar21;
                  *(uint *)(psVar32 + 10) = uVar21;
                  bVar38 = *pbVar51;
                }
                if ((bVar38 & 0x20) == 0) {
                  *(int *)(psVar32 + 2) = (int)uVar46;
                  psVar32[0xe] = 0;
                  *(undefined4 *)(psVar32 + 0xc) = *(undefined4 *)(psVar32 + 10);
                }
                else {
                  puVar50 = (ushort *)(pbVar51 + uVar46);
                  uVar43 = *puVar50;
                  psVar32[0xe] = uVar43;
                  if (uVar43 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar33 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0)) &&
                       ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                        (*(char *)(lVar33 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar49 + -8) = 0x105dac;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x105dd2;
                        (*_DAT_)(1,0x1766cd8,0x18869a8,0x80f);
                      }
                    }
                    uVar29 = *(undefined8 *)(psVar32 + 4);
                    *(undefined8 *)(puVar49 + -8) = 0x105de0;
                    func_0x(uVar29,3);
                    uVar43 = psVar32[0xe];
                  }
                  uVar21 = *(int *)(psVar32 + 10) + 2 + (uint)uVar43 * 2;
                  *(uint *)(psVar32 + 0xc) = uVar21;
                  if (0x1f9e < uVar21) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar33 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                        ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                         (*(char *)(lVar33 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar49 + -8) = 0x105e79;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x105e9f;
                        (*_DAT_)(1,0x1766cd8,0x18869a8,0x816);
                      }
                    }
                    uVar29 = *(undefined8 *)(psVar32 + 4);
                    *(undefined8 *)(puVar49 + -8) = 0x105ead;
                    func_0x(uVar29,4);
                  }
                  uVar43 = puVar50[(ushort)psVar32[0xe]];
                  *(uint *)(psVar32 + 2) = uVar43 & 0x7fff;
                  if ((uVar43 & 0x7fff) < *(uint *)(psVar32 + 0xc)) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar33 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0)) &&
                       ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                        (*(char *)(lVar33 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar49 + -8) = 0x105f41;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar49 + 0x20) = 0;
                        *(undefined8 *)(puVar49 + -8) = 0x105f67;
                        (*_DAT_)(1,0x1766cd8,0x18869a8,0x81d);
                      }
                    }
                    uVar29 = *(undefined8 *)(psVar32 + 4);
                    *(undefined8 *)(puVar49 + -8) = 0x105f75;
                    func_0x(uVar29,4);
                  }
                  uVar43 = psVar32[0xe];
                  do {
                    uVar46 = (ulonglong)uVar43;
                    if (-1 < (short)puVar50[(ulonglong)(uVar43 - 1) + 1]) break;
                    lVar33 = *(longlong *)(psVar32 + 4);
                    lVar36 = (ulonglong)*(uint *)(psVar32 + 10) + lVar33;
                    if (uVar43 == 1) {
                      uVar21 = *(uint *)(psVar32 + 0xc);
                      uVar43 = *(ushort *)(lVar36 + uVar46 * 2);
                      uVar44 = uVar21;
LAB_:
                      if ((uVar43 & 0x7fff) < uVar21) goto LAB_;
                    }
                    else {
                      uVar21 = *(ushort *)(lVar36 + -2 + uVar46 * 2) & 0x7fff;
                      uVar44 = *(uint *)(psVar32 + 0xc);
                      uVar43 = *(ushort *)(lVar36 + uVar46 * 2);
                      if (uVar44 <= uVar21) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar49 + -8) = 0x105fdd;
                      func_0x(lVar33,7);
                      uVar44 = *(uint *)(psVar32 + 0xc);
                    }
                    if ((uVar21 < uVar44) || (*(uint *)(psVar32 + 2) < uVar21)) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar21 + *(longlong *)(psVar32 + 4)) == 5) {
                      *puVar57 = *puVar57 | 2;
                      psVar32[0xe] = psVar32[0xe] + -1;
                      psVar32[0x15] = (short)uVar21;
                      lVar33 = (ulonglong)(uVar21 & 0xffff) + *(longlong *)(psVar32 + 4);
                      uVar43 = *(ushort *)(lVar33 + 2);
                      uVar19 = psVar32[0x16] & 0xc7ff;
                      if ((uVar43 & 0x4000) != 0) {
                        uVar19 = uVar43 & 0x3800 | uVar19;
                      }
                      psVar32[0x16] = uVar19;
                      psVar32[0x16] = (uVar19 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar19;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar21 + *(longlong *)(psVar32 + 4)) < 0x400) break;
                    *puVar57 = *puVar57 | 1;
                    uVar43 = psVar32[0xe] - 1;
                    psVar32[0xe] = uVar43;
                  } while (uVar43 != 0);
                }
                iVar20 = 0;
                if ((**(byte **)(psVar32 + 4) & 0x40) == 0) {
                  *(undefined4 *)(psVar32 + 0x13) = 0;
                }
                else {
                  *(undefined4 *)(psVar32 + 0x13) = *(undefined4 *)(psVar32 + 2);
                  *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + 0xe;
                  *(undefined8 *)(puVar49 + -8) = 0x1060c6;
                  puVar34 = (ulonglong *)func_0x(puVar57);
                  uVar46 = *puVar34;
                  uVar43 = (ushort)(uVar46 >> 0x30);
                  if ((((uint)(int)(short)uVar43 >> 1 ^ (int)(short)uVar43) & 0x2000) != 0) {
                    if ((uVar46 & 0x4000000000000000) == 0) {
                      uVar43 = uVar43 & 0xdfff;
                    }
                    else {
                      uVar43 = uVar43 | 0x2000;
                    }
                  }
                  if (uVar43 == 0xfffc) {
                    iVar20 = (int)((uVar46 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + iVar20;
                }
                uVar21 = *(uint *)(psVar32 + 2);
                if ((*(ulonglong *)(psVar32 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar32 + 0xf) < (ulonglong)uVar21 + *(longlong *)(psVar32 + 4)))
                {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar33 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                       (lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0)) &&
                      (*(char *)(lVar33 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar49 + -8) = 0x1061af;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar49 + 0x20) = 0;
                      *(undefined8 *)(puVar49 + -8) = 0x1061d5;
                      (*_DAT_)(1,0x1766cd8,0x18869a8,0x877);
                    }
                  }
                  uVar29 = *(undefined8 *)(psVar32 + 4);
                  *(undefined8 *)(puVar49 + -8) = 0x1061e3;
                  func_0x(uVar29,0x12);
                  uVar21 = *(uint *)(psVar32 + 2);
                }
                if (uVar21 - 1 < 0x3f3c) goto LAB_;
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar33 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar33 != 0 &&
                    ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                     (*(char *)(lVar33 + 0x499) != '\0')))))) {
                  if ((DAT_ != '\0') || ((DAT_ & 2) != 0)) {
                    *(undefined8 *)(puVar49 + 0x20) = 0;
                    *(undefined8 *)(puVar49 + -8) = 0x106294;
                    (*_DAT_)(1,0x1766cd8,0x18869a8,0x87c);
                    goto LAB_;
                  }
LAB_:
                  *(undefined8 *)(puVar49 + -8) = 0x10626e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
LAB_:
                uVar29 = *(undefined8 *)(psVar32 + 4);
                *(undefined8 *)(puVar49 + -8) = 0x1062a2;
                func_0x(uVar29,5);
              }
LAB_:
              uVar21 = *(uint *)(psVar32 + 2);
              if (uVar21 < 9) {
                bVar38 = **(byte **)(psVar32 + 4) & 0xe;
joined_r0x001071c4:
                if ((bVar38 == 0) || (bVar38 == 0xc)) {
                  uVar21 = 9;
                }
              }
            }
            else {
LAB_:
              uVar21 = *(uint *)(psVar32 + 2);
              if (uVar21 == 0) {
                *(undefined8 *)(puVar49 + -8) = 0x1071b0;
                func_0x(puVar57);
                uVar21 = *(uint *)(psVar32 + 2);
              }
              if (uVar21 < 9) {
                bVar38 = **(byte **)(psVar32 + 4) & 0x1c;
                goto joined_r0x001071c4;
              }
            }
            lVar33 = *plVar55;
            lVar36 = *(longlong *)(&stack0x000000f8 + lVar26);
            bVar38 = *(byte *)(*(longlong *)(lVar36 + 8) + 0x107);
            iVar20 = *(int *)(lVar33 + 0x40);
            *(undefined8 *)(puVar49 + -8) = 0x107205;
            uVar29 = func_0x(lVar36,&stack0x00000270 + lVar26);
            *(undefined8 *)(puVar49 + 0x40) = *(undefined8 *)(lVar33 + 0x10);
            lVar33 = *(longlong *)(&stack0x000001d0 + lVar26);
            *(undefined2 *)(puVar49 + 0x38) = *(undefined2 *)(lVar33 + 8);
            *(longlong *)(puVar49 + 0x30) = lVar33;
            *(uint *)(puVar49 + 0x28) = bVar38 >> 6 & 1;
            *(uint *)(puVar49 + 0x20) = (uint)(iVar20 != 1);
            lVar33 = *(longlong *)(&stack0x000000f8 + lVar26);
            *(undefined8 *)(puVar49 + -8) = 0x107247;
            func_0x(&stack0x000002f8 + lVar26,plVar7,uVar29,lVar33);
            *(undefined *)(lVar40 + 0x2ae) = 0;
            if (*(char *)(*(longlong *)(lVar33 + 0x20) + 0x1cdf) == '\0') {
              bVar41 = 0;
              bVar38 = 0;
            }
            else if (*(char *)(*(longlong *)(lVar33 + 0x20) + 0x1cdc) == '\0') {
              bVar41 = 0;
              bVar38 = 0;
            }
            else {
              bVar41 = *(byte *)(*(longlong *)(lVar33 + 8) + 0x109) >> 6 & 1;
              bVar38 = *(byte *)(*(longlong *)(lVar33 + 8) + 0x109) >> 6 & 1;
            }
            lVar36 = *plVar55;
            *(uint *)(puVar49 + 0x28) = (uint)bVar41 * 2;
            *(uint *)(puVar49 + 0x20) = (uint)bVar38;
            uVar29 = *(undefined8 *)(lVar36 + 0x20);
            *(undefined8 *)(puVar49 + -8) = 0x1072c9;
            func_0x(&stack0x00000280 + lVar26,&stack0x000002f8 + lVar26,uVar29,uVar21);
            *(undefined8 *)(&stack0x00000238 + lVar26) = *(undefined8 *)(lVar33 + 0x14);
            *(undefined8 *)(puVar49 + -8) = 0x1072e3;
            uVar29 = func_0x(&stack0x00000238 + lVar26);
            lVar36 = plVar7[6];
            *(undefined8 *)(puVar49 + -8) = 0x1072ef;
            cVar15 = func_0x(lVar36,uVar29);
            if (cVar15 != '\0') {
              *(undefined4 *)(&stack0x000000bc + lVar26) = 1;
            }
            uVar21 = 0;
            do {
              *(undefined8 *)(puVar49 + -8) = 0x107323;
              func_0x(&stack0x00000280 + lVar26);
              if ((*(int *)(&stack0x000008a0 + lVar26) == 0) &&
                 (*(short *)(&stack0x000008a4 + lVar26) == 0)) goto LAB_;
              if (*(char *)(*(longlong *)(*plVar55 + 0x20) + 1) == '\x05') {
LAB_:
                puVar30 = (undefined8 *)*plVar55;
                *(undefined **)(puVar49 + 0x20) = &stack0x000002c0 + lVar26;
                uVar29 = *puVar30;
                *(undefined8 *)(puVar49 + -8) = 0x1074c3;
                iVar20 = func_0x(uVar29,&stack0x00000898 + lVar26,3,2);
                if (iVar20 == 0) {
                  if ((*(char *)(*(longlong *)(*plVar55 + 0x20) + 1) != '\x05') &&
                     (*(char *)(*(longlong *)(*plVar55 + 0x20) + 2) != '\0')) {
                    if ((*(byte *)(lVar40 + 0xd0) & 2) != 0) {
                      *(undefined8 *)(puVar49 + -8) = 0x1075ac;
                      iVar20 = func_0x(lVar40 + 0xd8);
                      if (iVar20 != 0) {
                        *(longlong *)(*plVar55 + 0x30) = *(longlong *)(*plVar55 + 0x30) + -1;
                      }
                    }
                    *(undefined *)(lVar40 + 0xd0) = 0;
                    *(undefined4 *)(lVar40 + 0xcc) = 0;
                    *(undefined4 *)(lVar40 + 0xe8) = 0;
                    goto LAB_;
                  }
                }
                else {
                  puVar31 = (undefined4 *)(&stack0x00000358 + lVar26);
                  puVar37 = (undefined4 *)(&stack0x00000558 + lVar26);
                  lVar36 = 2;
                  do {
                    uVar25 = puVar31[1];
                    uVar6 = puVar31[2];
                    uVar13 = puVar31[3];
                    *puVar37 = *puVar31;
                    puVar37[1] = uVar25;
                    puVar37[2] = uVar6;
                    puVar37[3] = uVar13;
                    uVar25 = puVar31[5];
                    uVar6 = puVar31[6];
                    uVar13 = puVar31[7];
                    puVar37[4] = puVar31[4];
                    puVar37[5] = uVar25;
                    puVar37[6] = uVar6;
                    puVar37[7] = uVar13;
                    uVar25 = puVar31[9];
                    uVar6 = puVar31[10];
                    uVar13 = puVar31[0xb];
                    puVar37[8] = puVar31[8];
                    puVar37[9] = uVar25;
                    puVar37[10] = uVar6;
                    puVar37[0xb] = uVar13;
                    uVar25 = puVar31[0xd];
                    uVar6 = puVar31[0xe];
                    uVar13 = puVar31[0xf];
                    puVar37[0xc] = puVar31[0xc];
                    puVar37[0xd] = uVar25;
                    puVar37[0xe] = uVar6;
                    puVar37[0xf] = uVar13;
                    uVar25 = puVar31[0x11];
                    uVar6 = puVar31[0x12];
                    uVar13 = puVar31[0x13];
                    puVar37[0x10] = puVar31[0x10];
                    puVar37[0x11] = uVar25;
                    puVar37[0x12] = uVar6;
                    puVar37[0x13] = uVar13;
                    uVar25 = puVar31[0x15];
                    uVar6 = puVar31[0x16];
                    uVar13 = puVar31[0x17];
                    puVar37[0x14] = puVar31[0x14];
                    puVar37[0x15] = uVar25;
                    puVar37[0x16] = uVar6;
                    puVar37[0x17] = uVar13;
                    uVar25 = puVar31[0x19];
                    uVar6 = puVar31[0x1a];
                    uVar13 = puVar31[0x1b];
                    puVar37[0x18] = puVar31[0x18];
                    puVar37[0x19] = uVar25;
                    puVar37[0x1a] = uVar6;
                    puVar37[0x1b] = uVar13;
                    uVar25 = puVar31[0x1d];
                    uVar6 = puVar31[0x1e];
                    uVar13 = puVar31[0x1f];
                    puVar37[0x1c] = puVar31[0x1c];
                    puVar37[0x1d] = uVar25;
                    puVar37[0x1e] = uVar6;
                    puVar37[0x1f] = uVar13;
                    puVar31 = puVar31 + 0x20;
                    lVar36 = lVar36 + -1;
                    puVar37 = puVar37 + 0x20;
                  } while (lVar36 != 0);
                  *(undefined4 *)(puVar49 + 0x30) = 1;
                  *(undefined **)(puVar49 + 0x28) = &stack0x00000558 + lVar26;
                  *(undefined8 *)(puVar49 + 0x20) = 0;
                  *(undefined8 *)(puVar49 + -8) = 0x107567;
                  func_0x
                            (plVar55,&stack0x000002c0 + lVar26,&stack0x00000210 + lVar26,0);
                }
                if (*(int *)(lVar40 + 0xf0) == 4) {
                  *(undefined8 *)(puVar49 + -8) = 0x1075e1;
                  uVar17 = func_0x(&stack0x00000280 + lVar26);
                  *(undefined *)(lVar40 + 0x2ae) = uVar17;
                  break;
                }
              }
              else {
                pcVar8 = *(code **)(*plVar7 + 0x28);
                *(undefined8 *)(puVar49 + -8) = 0x107356;
                cVar16 = (*pcVar8)(plVar7);
                if ((cVar16 != '\0') ||
                   (((*(uint *)(lVar33 + 0x14) & 0xe0000000) == 0x80000000 &&
                    (*(ushort *)(lVar33 + 0x18) < 0x100)))) goto LAB_;
                uVar4 = *(undefined2 *)(plVar7[6] + 0x6b8);
                (&stack0x000008c6)[lVar26] = 6;
                *(undefined2 *)(&stack0x000008c4 + lVar26) = uVar4;
                *(undefined8 *)(&stack0x000008bc + lVar26) = 0;
                *(undefined4 *)(&stack0x000008b8 + lVar26) =
                     *(undefined4 *)(&stack0x000008a0 + lVar26);
                *(undefined2 *)(&stack0x000008bc + lVar26) =
                     *(undefined2 *)(&stack0x000008a4 + lVar26);
                if ((*(char *)(*(longlong *)(*plVar55 + 0x20) + 2) == '\0') &&
                   (((*(char *)(*(longlong *)(lVar33 + 0x20) + 0x1cdf) == '\0' ||
                     (*(char *)(*(longlong *)(lVar33 + 0x20) + 0x1cdc) == '\0')) ||
                    ((*(byte *)(*(longlong *)(lVar33 + 8) + 0x109) & 0x40) == 0)))) {
                  uVar29 = *(undefined8 *)(lVar33 + 0x14);
                  if (((int)uVar29 == 8) && ((short)((ulonglong)uVar29 >> 0x20) == 0))
                  goto LAB_;
                  *(undefined8 *)(&stack0x00000240 + lVar26) = uVar29;
                  lVar36 = *(longlong *)(lVar40 + 0x38);
                  *(undefined8 *)(puVar49 + 0x60) = 0;
                  *(longlong *)(puVar49 + 0x58) = lVar40 + 0xc0;
                  *(undefined **)(puVar49 + 0x50) = &stack0x00000240 + lVar26;
                  *(undefined8 *)(puVar49 + 0x48) = 0;
                  *(undefined4 *)(puVar49 + 0x40) = 0;
                  puVar49[0x38] = 0;
                  *(undefined4 *)(puVar49 + 0x30) = 0;
                  *(undefined4 *)(puVar49 + 0x28) = 1;
                  *(undefined4 *)(puVar49 + 0x20) = 1;
                  uVar29 = *(undefined8 *)(lVar36 + 8);
                  *(undefined8 *)(puVar49 + -8) = 0x107462;
                  iVar20 = func_0x(uVar29,&stack0x000008b8 + lVar26,8,1);
                }
                else {
                  *(undefined4 *)(puVar49 + 0x38) = 1;
                  *(undefined4 *)(puVar49 + 0x30) = 0;
                  *(undefined4 *)(puVar49 + 0x28) = 0;
                  *(longlong *)(puVar49 + 0x20) = lVar40 + 0xc0;
                  *(undefined8 *)(puVar49 + -8) = 0x107493;
                  iVar20 = func_0x(plVar55,&stack0x000008b8 + lVar26,2);
                }
                if (-1 < iVar20) goto LAB_;
              }
LAB_:
              uVar21 = uVar21 + 1;
            } while (uVar21 < *(uint *)(&stack0x000000bc + lVar26));
            if (((cVar15 == '\0') || (*(int *)(lVar40 + 0xf0) == 4)) ||
               ((*(int *)(&stack0x000008a0 + lVar26) == 0 &&
                (*(short *)(&stack0x000008a4 + lVar26) == 0)))) {
LAB_:
              lVar39 = *(longlong *)(&stack0x00000110 + lVar26);
              lVar36 = *(longlong *)(&stack0x00000118 + lVar26);
              puVar30 = *(undefined8 **)(&stack0x000000d0 + lVar26);
            }
            else {
              *(undefined8 *)(puVar49 + -8) = 0x107624;
              func_0x(&stack0x000001e0 + lVar26);
              lVar33 = *(longlong *)(lVar33 + 8);
              *(undefined8 *)(puVar49 + -8) = 0x10763b;
              func_0x(&stack0x000001e0 + lVar26,lVar33 + 0x3c0);
              *(undefined4 *)(&stack0x00000180 + lVar26) =
                   *(undefined4 *)(&stack0x000008a0 + lVar26);
              *(undefined2 *)(&stack0x00000184 + lVar26) =
                   *(undefined2 *)(&stack0x000008a4 + lVar26);
              *(undefined8 *)(puVar49 + -8) = 0x107668;
              func_0x(&stack0x00000248 + lVar26,&stack0x00000180 + lVar26);
              (&stack0x000000d8)[lVar26] = 4;
              *(undefined8 *)(puVar49 + -8) = 0x10767e;
              uVar25 = func_0x(4,1);
              *(undefined8 *)(puVar49 + -8) = 0x107688;
              uVar25 = func_0x(uVar25,2);
              *(undefined8 *)(puVar49 + -8) = 0x107692;
              uVar25 = func_0x(uVar25,0x20);
              *(undefined8 *)(puVar49 + -8) = 0x1076a0;
              func_0x(&stack0x000002d0 + lVar26,uVar25);
              *(longlong **)(puVar49 + 0x30) = plVar7;
              puVar49[0x28] = 1;
              *(undefined4 *)(puVar49 + 0x20) = 1;
              lVar33 = plVar7[6];
              *(undefined8 *)(puVar49 + -8) = 0x1076cc;
              func_0x
                        (lVar33,&stack0x000001e0 + lVar26,&stack0x00000248 + lVar26,
                         &stack0x000000d8 + lVar26);
              *(undefined8 *)(puVar49 + -8) = 0x1076d9;
              func_0x(&stack0x000002d0 + lVar26);
              puVar30 = *(undefined8 **)(&stack0x000000d0 + lVar26);
              lVar36 = *(longlong *)(&stack0x00000118 + lVar26);
              lVar39 = *(longlong *)(&stack0x00000110 + lVar26);
            }
          }
          if (*(int *)(lVar40 + 0xf0) != 4) {
            puVar31 = (undefined4 *)(&stack0x00000358 + lVar26);
            lVar33 = 2;
            puVar37 = (undefined4 *)(&stack0x00000658 + lVar26);
            do {
              uVar25 = puVar31[1];
              uVar6 = puVar31[2];
              uVar13 = puVar31[3];
              *puVar37 = *puVar31;
              puVar37[1] = uVar25;
              puVar37[2] = uVar6;
              puVar37[3] = uVar13;
              uVar25 = puVar31[5];
              uVar6 = puVar31[6];
              uVar13 = puVar31[7];
              puVar37[4] = puVar31[4];
              puVar37[5] = uVar25;
              puVar37[6] = uVar6;
              puVar37[7] = uVar13;
              uVar25 = puVar31[9];
              uVar6 = puVar31[10];
              uVar13 = puVar31[0xb];
              puVar37[8] = puVar31[8];
              puVar37[9] = uVar25;
              puVar37[10] = uVar6;
              puVar37[0xb] = uVar13;
              uVar25 = puVar31[0xd];
              uVar6 = puVar31[0xe];
              uVar13 = puVar31[0xf];
              puVar37[0xc] = puVar31[0xc];
              puVar37[0xd] = uVar25;
              puVar37[0xe] = uVar6;
              puVar37[0xf] = uVar13;
              uVar25 = puVar31[0x11];
              uVar6 = puVar31[0x12];
              uVar13 = puVar31[0x13];
              puVar37[0x10] = puVar31[0x10];
              puVar37[0x11] = uVar25;
              puVar37[0x12] = uVar6;
              puVar37[0x13] = uVar13;
              uVar25 = puVar31[0x15];
              uVar6 = puVar31[0x16];
              uVar13 = puVar31[0x17];
              puVar37[0x14] = puVar31[0x14];
              puVar37[0x15] = uVar25;
              puVar37[0x16] = uVar6;
              puVar37[0x17] = uVar13;
              uVar25 = puVar31[0x19];
              uVar6 = puVar31[0x1a];
              uVar13 = puVar31[0x1b];
              puVar37[0x18] = puVar31[0x18];
              puVar37[0x19] = uVar25;
              puVar37[0x1a] = uVar6;
              puVar37[0x1b] = uVar13;
              uVar25 = puVar31[0x1d];
              uVar6 = puVar31[0x1e];
              uVar13 = puVar31[0x1f];
              puVar37[0x1c] = puVar31[0x1c];
              puVar37[0x1d] = uVar25;
              puVar37[0x1e] = uVar6;
              puVar37[0x1f] = uVar13;
              puVar31 = puVar31 + 0x20;
              lVar33 = lVar33 + -1;
              puVar37 = puVar37 + 0x20;
            } while (lVar33 != 0);
            *(undefined **)(puVar49 + 0x20) = &stack0x00000658 + lVar26;
            *(undefined8 *)(puVar49 + -8) = 0x1077b3;
            func_0x(plVar55,&stack0x00000210 + lVar26,0,0);
          }
          if (puVar30 != (undefined8 *)0x0) {
            if (*(longlong **)(lVar40 + 0x58) == (longlong *)0x0) {
              if (*(int *)(lVar40 + 0xf0) != 2) {
                *(undefined8 *)(puVar49 + -8) = 0x1077e0;
                func_0x(plVar55,1);
                if (*(int *)(lVar40 + 0xf0) != 2) {
                  lVar40 = **(longlong **)(lVar40 + 0x58);
                  goto LAB_;
                }
              }
              lVar40 = 0;
            }
            else {
              lVar40 = **(longlong **)(lVar40 + 0x58);
            }
LAB_:
            *(undefined4 *)(puVar30 + 1) = *(undefined4 *)(lVar40 + 0x20);
            *(undefined2 *)((longlong)puVar30 + 0xc) = *(undefined2 *)(lVar40 + 0x24);
            *(undefined2 *)((longlong)puVar30 + 0xe) = 0;
            *puVar30 = 0;
            *(undefined4 *)((longlong)puVar30 + 0x1c) = 1;
            puVar30[2] = 0;
            *(undefined2 *)(puVar30 + 3) = 0;
          }
        }
        puVar31 = (undefined4 *)(lVar35 + 0x530);
        lVar40 = 2;
        puVar37 = (undefined4 *)(&stack0x00000758 + lVar26);
        do {
          uVar25 = puVar31[1];
          uVar6 = puVar31[2];
          uVar13 = puVar31[3];
          *puVar37 = *puVar31;
          puVar37[1] = uVar25;
          puVar37[2] = uVar6;
          puVar37[3] = uVar13;
          uVar25 = puVar31[5];
          uVar6 = puVar31[6];
          uVar13 = puVar31[7];
          puVar37[4] = puVar31[4];
          puVar37[5] = uVar25;
          puVar37[6] = uVar6;
          puVar37[7] = uVar13;
          uVar25 = puVar31[9];
          uVar6 = puVar31[10];
          uVar13 = puVar31[0xb];
          puVar37[8] = puVar31[8];
          puVar37[9] = uVar25;
          puVar37[10] = uVar6;
          puVar37[0xb] = uVar13;
          uVar25 = puVar31[0xd];
          uVar6 = puVar31[0xe];
          uVar13 = puVar31[0xf];
          puVar37[0xc] = puVar31[0xc];
          puVar37[0xd] = uVar25;
          puVar37[0xe] = uVar6;
          puVar37[0xf] = uVar13;
          uVar25 = puVar31[0x11];
          uVar6 = puVar31[0x12];
          uVar13 = puVar31[0x13];
          puVar37[0x10] = puVar31[0x10];
          puVar37[0x11] = uVar25;
          puVar37[0x12] = uVar6;
          puVar37[0x13] = uVar13;
          uVar25 = puVar31[0x15];
          uVar6 = puVar31[0x16];
          uVar13 = puVar31[0x17];
          puVar37[0x14] = puVar31[0x14];
          puVar37[0x15] = uVar25;
          puVar37[0x16] = uVar6;
          puVar37[0x17] = uVar13;
          uVar25 = puVar31[0x19];
          uVar6 = puVar31[0x1a];
          uVar13 = puVar31[0x1b];
          puVar37[0x18] = puVar31[0x18];
          puVar37[0x19] = uVar25;
          puVar37[0x1a] = uVar6;
          puVar37[0x1b] = uVar13;
          uVar25 = puVar31[0x1d];
          uVar6 = puVar31[0x1e];
          uVar13 = puVar31[0x1f];
          puVar37[0x1c] = puVar31[0x1c];
          puVar37[0x1d] = uVar25;
          puVar37[0x1e] = uVar6;
          puVar37[0x1f] = uVar13;
          puVar31 = puVar31 + 0x20;
          lVar40 = lVar40 + -1;
          puVar37 = puVar37 + 0x20;
        } while (lVar40 != 0);
        *(undefined8 *)(puVar49 + 0x20) = 0;
        *(undefined8 *)(puVar49 + -8) = 0x1078b0;
        func_0x(plVar55,&stack0x00000210 + lVar26,&stack0x00000758 + lVar26,1);
        *(uint *)(lVar36 + 0x634) = *(uint *)(lVar36 + 0x634) | 1;
        if (*(int *)(&stack0x000000c8 + lVar26) != 0) {
          puVar30 = *(undefined8 **)(*(longlong *)(lVar39 + 0x28) + 0x18);
          *(int *)((longlong)puVar30 + 0xc) = *(int *)((longlong)puVar30 + 0xc) + 1;
          if (*(uint *)(puVar30 + 1) <= *(uint *)((longlong)puVar30 + 0xc)) {
            *(undefined4 *)(puVar30 + 1) = 0;
            *puVar30 = 0;
          }
          if (*(int *)(&stack0x00000098 + lVar26) != 0) {
            *(undefined4 *)(*(longlong *)(&stack0x000000c0 + lVar26) + 0x548) =
                 *(undefined4 *)(&stack0x000000a8 + lVar26);
            *(uint *)(lVar35 + 0x54c) = *puVar2;
          }
        }
        uVar29 = *(undefined8 *)(&stack0x00000250 + lVar26);
        uVar12 = *(undefined8 *)(&stack0x000000c0 + lVar26);
        *(undefined8 *)(puVar49 + -8) = 0x107919;
        func_0x(uVar12,uVar29,0,1);
        **(undefined8 **)(&stack0x00000258 + lVar26) = uVar12;
        goto LAB_;
      }
      goto LAB_;
    }
    if (iVar22 < 3) {
      *(undefined8 *)(&stack0x00000100 + lVar26) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x103763;
      iVar24 = func_0x(lVar40);
      goto LAB_;
    }
  }
  else {
    bVar58 = iVar22 < 0x32;
  }
  *(undefined8 *)(&stack0x00000100 + lVar26) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1036d0;
  iVar24 = func_0x(lVar40);
  if (!bVar58) goto LAB_;
LAB_:
  if (1 < iVar24 - 1U) goto LAB_;
  iVar22 = iVar22 + 1;
  *(int *)(&stack0x000000c8 + lVar26) = iVar22;
  *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x1036f6;
  func_0x(lVar40 + 0x30);
  uVar21 = 3;
  if (*(char *)(*(longlong *)(lVar40 + 0x28) + 0x29) == '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar26) = 0x10370e;
    func_0x(10);
  }
  goto LAB_;
}

