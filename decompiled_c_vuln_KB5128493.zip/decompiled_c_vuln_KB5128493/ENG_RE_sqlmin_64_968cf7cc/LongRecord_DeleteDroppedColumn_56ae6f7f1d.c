
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,uint *param_3,short *param_4,byte param_5,
                 undefined4 *param_6)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  ulonglong *puVar7;
  ulonglong uVar8;
  longlong lVar9;
  ushort uVar10;
  uint uVar11;
  ulonglong uVar12;
  undefined *puVar13;
  undefined4 uVar14;
  uint *puVar15;
  ushort *puVar16;
  short sVar17;
  byte *pbVar18;
  uint uVar19;
  longlong unaff_GS_OFFSET;
  undefined auStack_88 [64];
  uint uStack_48;
  uint uStack_44;
  undefined auStack_40 [8];
  ulonglong uStack_38;
  
  puVar13 = auStack_88;
  uStack_38 = _DAT_ ^ (ulonglong)&uStack_48;
  lVar1 = *(longlong *)(param_1 + 8);
  lVar9 = 0;
  puVar15 = (uint *)0x0;
  uVar14 = 0;
  if (*(int *)(lVar1 + 0x100) == 2) {
    if ((*(byte *)(lVar1 + 0x42) & 4) == 0) {
      uVar12 = (ulonglong)*(uint *)(lVar1 + 0xb0);
      if (0x1f9e < *(uint *)(lVar1 + 0xb0)) {
        uVar12 = 0x1f9e;
      }
    }
    else {
      uVar12 = 0x1f9e;
    }
    uVar14 = (undefined4)uVar12;
    uVar8 = uVar12 + 0xf;
    if (uVar8 <= uVar12) {
      uVar8 = 0xffffffffffffff0;
    }
    uVar8 = uVar8 & 0xfffffffffffffff0;
    func_0x();
    puVar13 = auStack_88 + -uVar8;
    lVar9 = (longlong)&uStack_48 + -uVar8;
  }
  *(undefined8 *)(puVar13 + -8) = 0x100098;
  iVar6 = func_0x(param_4,param_3);
  if (iVar6 == 0) {
    if ((param_5 & 0x10) == 0) goto LAB_;
    *(undefined8 *)(puVar13 + -8) = 0x100ac6;
    func_0x(param_4,param_3);
  }
  else {
    if (*param_4 == 0) {
      uVar11 = *param_3;
      if ((uVar11 & 0xc0000000) == 0x80000000) {
        *(undefined8 *)(puVar13 + -8) = 0x1008fc;
        iVar6 = func_0x(param_4 + 1);
        if (iVar6 == 0) {
          uStack_48 = 0;
        }
        else {
          *(undefined8 *)(puVar13 + -8) = 0x100918;
          puVar15 = (uint *)func_0x(param_4 + 0x15,param_3,&uStack_48,auStack_40);
        }
      }
      else {
        uVar5 = *(ushort *)((longlong)param_3 + 6);
        if ((uVar5 & 0x10) != 0) {
          bVar4 = **(byte **)(param_4 + 4);
          if ((bVar4 & 0x10) == 0) {
            if ((1 << (bVar4 & 0xe) & 0x1105U) == 0) goto LAB_;
          }
          else if (((int)uVar11 < (int)*(uint *)(param_4 + 8)) &&
                  (*(ushort *)(param_3 + 1) <=
                   *(ushort *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 8))))
          goto LAB_;
          goto LAB_;
        }
LAB_:
        if ((int)uVar11 < 0) {
          if (*(int *)(param_4 + 2) == 0) {
            pbVar18 = *(byte **)(param_4 + 4);
            uVar11 = *(uint *)(param_4 + 8);
            uVar12 = (ulonglong)uVar11;
            param_4[1] = 0;
            *(uint *)(param_4 + 10) = uVar11;
            bVar4 = *pbVar18;
            if ((bVar4 & 0x10) != 0) {
              uVar11 = uVar11 + 2 + (*(ushort *)(pbVar18 + uVar12) + 7 >> 3);
              uVar12 = (ulonglong)uVar11;
              *(uint *)(param_4 + 10) = uVar11;
              bVar4 = *pbVar18;
            }
            if ((bVar4 & 0x20) == 0) {
              *(int *)(param_4 + 2) = (int)uVar12;
              param_4[0xe] = 0;
              *(int *)(param_4 + 0xc) = (int)uVar12;
            }
            else {
              puVar16 = (ushort *)(pbVar18 + uVar12);
              uVar5 = *puVar16;
              param_4[0xe] = uVar5;
              if (uVar5 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar9 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar9 != 0)) &&
                   ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar13 + -8) = 0x1002c9;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar13 + 0x20) = 0;
                    *(undefined8 *)(puVar13 + -8) = 0x10030b;
                    (*_DAT_)(1,0xa9c868,0xbbc538,0x80f);
                  }
                }
                uVar2 = *(undefined8 *)(param_4 + 4);
                *(undefined8 *)(puVar13 + -8) = 0x1002da;
                func_0x(uVar2,3);
                uVar12 = (ulonglong)*(uint *)(param_4 + 10);
                uVar5 = param_4[0xe];
              }
              uVar11 = (int)uVar12 + (uVar5 + 1) * 2;
              *(uint *)(param_4 + 0xc) = uVar11;
              if (0x1f9e < uVar11) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar9 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar9 != 0 &&
                    ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                     (*(char *)(lVar9 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar13 + -8) = 0x1003a8;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar13 + 0x20) = 0;
                    *(undefined8 *)(puVar13 + -8) = 0x1003ce;
                    (*_DAT_)(1,0xa9c868,0xbbc538,0x816);
                  }
                }
                uVar2 = *(undefined8 *)(param_4 + 4);
                *(undefined8 *)(puVar13 + -8) = 0x1003dc;
                func_0x(uVar2,4);
                uVar5 = param_4[0xe];
                uVar11 = *(uint *)(param_4 + 0xc);
              }
              uVar12 = (ulonglong)uVar5;
              uVar5 = puVar16[uVar12];
              *(uint *)(param_4 + 2) = uVar5 & 0x7fff;
              if ((uVar5 & 0x7fff) < uVar11) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar9 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar9 != 0)) &&
                   ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar13 + -8) = 0x10047b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar13 + 0x20) = 0;
                    *(undefined8 *)(puVar13 + -8) = 0x1004a1;
                    (*_DAT_)(1,0xa9c868,0xbbc538,0x81d);
                  }
                }
                uVar2 = *(undefined8 *)(param_4 + 4);
                *(undefined8 *)(puVar13 + -8) = 0x1004af;
                func_0x(uVar2,4);
                uVar12 = (ulonglong)(ushort)param_4[0xe];
              }
              if ((short)puVar16[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
                lVar9 = *(longlong *)(param_4 + 4);
                do {
                  if ((int)uVar12 == 1) {
                    uVar11 = *(uint *)(param_4 + 0xc);
                    uVar19 = uVar11;
LAB_:
                    if ((*(ushort *)((ulonglong)*(uint *)(param_4 + 10) + lVar9 + uVar12 * 2) &
                        0x7fff) < uVar11) goto LAB_;
                  }
                  else {
                    uVar19 = *(uint *)(param_4 + 0xc);
                    uVar11 = *(ushort *)
                              ((ulonglong)*(uint *)(param_4 + 10) + lVar9 + -2 + uVar12 * 2) &
                             0x7fff;
                    if (uVar19 <= uVar11) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar13 + -8) = 0x100515;
                    func_0x(lVar9,7);
                    uVar19 = *(uint *)(param_4 + 0xc);
                  }
                  if ((uVar11 < uVar19) || (*(uint *)(param_4 + 2) < uVar11)) goto LAB_;
                  lVar9 = *(longlong *)(param_4 + 4);
                  if (*(ushort *)(lVar9 + (ulonglong)uVar11) == 5) {
                    param_4[1] = param_4[1] | 2;
                    param_4[0xe] = param_4[0xe] + -1;
                    param_4[0x15] = (short)uVar11;
                    lVar9 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(param_4 + 4);
                    uVar5 = param_4[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar9 + 2) & 0x4000) != 0) {
                      uVar5 = *(ushort *)(lVar9 + 2) & 0x3800 | param_4[0x16] & 0xc7ffU;
                    }
                    param_4[0x16] = uVar5;
                    param_4[0x16] = (uVar5 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar5;
                    uVar12 = (ulonglong)*(uint *)(param_4 + 2);
                    pbVar18 = *(byte **)(param_4 + 4);
                    goto LAB_;
                  }
                  if (*(ushort *)(lVar9 + (ulonglong)uVar11) < 0x400) break;
                  param_4[1] = param_4[1] | 1;
                  uVar5 = param_4[0xe] - 1;
                  param_4[0xe] = uVar5;
                  if ((uVar5 == 0) ||
                     (uVar12 = (ulonglong)uVar5, -1 < (short)puVar16[(ulonglong)(uVar5 - 1) + 1]))
                  break;
                } while( true );
              }
              uVar12 = (ulonglong)*(uint *)(param_4 + 2);
              pbVar18 = *(byte **)(param_4 + 4);
            }
LAB_:
            iVar6 = 0;
            if ((*pbVar18 & 0x40) == 0) {
              *(undefined4 *)(param_4 + 0x13) = 0;
            }
            else {
              *(int *)(param_4 + 0x13) = (int)uVar12;
              *(int *)(param_4 + 2) = (int)uVar12 + 0xe;
              *(undefined8 *)(puVar13 + -8) = 0x100623;
              puVar7 = (ulonglong *)func_0x(param_4 + 1);
              uVar12 = *puVar7;
              uVar10 = (ushort)(uVar12 >> 0x30);
              uVar5 = uVar10;
              if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
                uVar5 = uVar10 & 0xdfff;
                if ((uVar12 & 0x4000000000000000) != 0) {
                  uVar5 = uVar10 | 0x2000;
                }
              }
              if (uVar5 == 0xfffc) {
                iVar6 = (int)((uVar12 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + iVar6;
              uVar12 = (ulonglong)*(uint *)(param_4 + 2);
            }
            iVar6 = (int)uVar12;
            if ((*(ulonglong *)(param_4 + 0xf) != 0) &&
               (*(ulonglong *)(param_4 + 0xf) < uVar12 + *(longlong *)(param_4 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar9 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                   lVar9 != 0 && (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) &&
                  (*(char *)(lVar9 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar13 + -8) = 0x10071f;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar13 + 0x20) = 0;
                  *(undefined8 *)(puVar13 + -8) = 0x100745;
                  (*_DAT_)(1,0xa9c868,0xbbc538,0x877);
                }
              }
              uVar2 = *(undefined8 *)(param_4 + 4);
              *(undefined8 *)(puVar13 + -8) = 0x100753;
              func_0x(uVar2,0x12);
              iVar6 = *(int *)(param_4 + 2);
            }
            if (0x3f3b < iVar6 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar9 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar9 != 0 &&
                  ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                   (*(char *)(lVar9 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar13 + -8) = 0x1007e0;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar13 + 0x20) = 0;
                  *(undefined8 *)(puVar13 + -8) = 0x100806;
                  (*_DAT_)(1,0xa9c868,0xbbc538,0x87c);
                }
              }
              uVar2 = *(undefined8 *)(param_4 + 4);
              *(undefined8 *)(puVar13 + -8) = 0x100814;
              func_0x(uVar2,5);
            }
          }
LAB_:
          sVar17 = -*(short *)param_3;
          if ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0) {
            bVar4 = **(byte **)(param_4 + 4);
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar15 = *(uint **)(param_3 + 2) + 1;
                uStack_48 = **(uint **)(param_3 + 2);
                goto LAB_;
              }
            }
            else {
              if ((int)*(uint *)(param_4 + 8) <= (int)*param_3) goto LAB_;
              if (*(ushort *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 8)) <
                  *(ushort *)(param_3 + 1)) {
                puVar15 = *(uint **)(param_3 + 2) + 1;
                uStack_48 = **(uint **)(param_3 + 2);
                goto LAB_;
              }
            }
          }
          puVar15 = *(uint **)(param_4 + 4);
          lVar9 = (longlong)sVar17;
          if ((uint)(ushort)param_4[0xe] < (uint)(int)sVar17) {
            uStack_48 = 0;
          }
          else {
            uVar11 = *(uint *)(param_4 + 10);
            if (sVar17 == 1) {
              uVar19 = *(uint *)(param_4 + 0xc);
              uVar11 = *(ushort *)((longlong)puVar15 + lVar9 * 2 + (ulonglong)uVar11) & 0x7fff;
LAB_:
              if (uVar11 < uVar19) goto LAB_;
            }
            else {
              puVar16 = (ushort *)((longlong)puVar15 + lVar9 * 2 + (ulonglong)uVar11);
              uVar19 = *(ushort *)((longlong)puVar15 + lVar9 * 2 + ((ulonglong)uVar11 - 2)) & 0x7fff
              ;
              puVar15 = *(uint **)(param_4 + 4);
              uVar11 = *puVar16 & 0x7fff;
              if (*(uint *)(param_4 + 0xc) <= uVar19) goto LAB_;
LAB_:
              *(undefined8 *)(puVar13 + -8) = 0x1008d9;
              func_0x(puVar15,7);
              puVar15 = *(uint **)(param_4 + 4);
            }
            puVar15 = (uint *)((longlong)puVar15 + (ulonglong)uVar19);
            uStack_48 = uVar11 - uVar19;
          }
        }
        else {
          if ((uVar5 & 8) != 0) {
            puVar15 = (uint *)0x8212a4;
            uStack_48 = 1;
            if ((*(byte *)((longlong)(int)uVar11 + *(longlong *)(param_4 + 4)) &
                (byte)(1 << ((byte)uVar5 & 7))) == 0) {
              puVar15 = (uint *)0x8218c8;
            }
            goto LAB_;
          }
          if ((uVar5 & 0x10) != 0) {
            bVar4 = **(byte **)(param_4 + 4);
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                uStack_48 = **(uint **)(param_3 + 2);
                puVar15 = *(uint **)(param_3 + 2) + 1;
                if (uStack_48 != 0x1f9e) {
                  *(undefined8 *)(puVar13 + 0x20) = 0;
                  *(undefined8 *)(puVar13 + -8) = 0x1001b6;
                  (*_DAT_)(1,0xc4a5d8,0xc48fd8,0x381);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_4 + 8) <= (int)uVar11) ||
                    (*(ushort *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 8)) <
                     *(ushort *)(param_3 + 1))) goto LAB_;
          }
          puVar15 = (uint *)((longlong)(int)uVar11 + *(longlong *)(param_4 + 4));
          uStack_48 = 0x1f9e;
        }
      }
    }
    else {
      uStack_44 = 0;
      *(uint **)(puVar13 + 0x20) = &uStack_44;
      *(undefined8 *)(puVar13 + -8) = 0x100a1d;
      puVar15 = (uint *)func_0x(param_4 + 1,param_3);
      uVar11 = uStack_48;
      if ((((*param_4 != 0) && (plVar3 = *(longlong **)(param_4 + 8), plVar3 != (longlong *)0x0)) &&
          (*plVar3 != 0)) &&
         (((*(byte *)((longlong)param_3 + 6) & 8) == 0 && ((uStack_44 & 1) == 0)))) {
        if ((puVar15 == (uint *)0x0) || (puVar15 == (uint *)0x8212a4)) {
          puVar15 = (uint *)0x0;
          uStack_48 = 0;
        }
        else {
          *(uint *)(puVar13 + 0x38) = uStack_44;
          *(uint **)(puVar13 + 0x30) = &uStack_48;
          *(undefined4 *)(puVar13 + 0x28) = uVar14;
          *(longlong *)(puVar13 + 0x20) = lVar9;
          *(undefined8 *)(puVar13 + -8) = 0x100a8b;
          puVar15 = (uint *)func_0x(plVar3,param_3,puVar15,uVar11);
        }
      }
    }
LAB_:
    if ((puVar15 == (uint *)0x0) || (uStack_48 == 0)) goto LAB_;
    if (uStack_48 < 0xd) {
LAB_:
      if ((uStack_48 != 0x10) || (sVar17 = *(short *)puVar15, sVar17 != 0)) goto LAB_;
    }
    else {
      uVar12 = ((ulonglong)uStack_48 - 0xc) / 0xc;
      if ((((0x1f8 < (uint)uVar12) || (sVar17 = *(short *)puVar15, (sVar17 - 1U & 0xfffc) != 0)) ||
          (sVar17 == 3)) || ((ulonglong)uStack_48 - 0xc != uVar12 * 0xc)) goto LAB_;
    }
    if (0xc < uStack_48) {
      uVar12 = ((ulonglong)uStack_48 - 0xc) / 0xc;
      if ((((uint)uVar12 < 0x1f9) && (sVar17 == 2)) && ((ulonglong)uStack_48 - 0xc == uVar12 * 0xc))
      {
        if ((param_5 & 0x80) == 0) goto LAB_;
        *(undefined8 *)(puVar13 + -8) = 0x1009f2;
        func_0x(param_2,param_4,param_3);
        goto LAB_;
      }
    }
    if ((param_5 & 0x40) == 0) goto LAB_;
    *(undefined8 *)(puVar13 + -8) = 0x100ab3;
    func_0x(param_2,param_4,param_3);
  }
LAB_:
  *param_6 = 1;
LAB_:
  uVar12 = uStack_38 ^ (ulonglong)&uStack_48;
  *(undefined8 *)(puVar13 + -8) = 0x100adc;
  func_0x(uVar12);
  return;
}

