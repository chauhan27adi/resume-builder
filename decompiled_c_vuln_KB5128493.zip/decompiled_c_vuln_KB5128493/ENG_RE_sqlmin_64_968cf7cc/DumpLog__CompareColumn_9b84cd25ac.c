
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  ushort *puVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  byte *pbVar4;
  undefined8 uVar5;
  longlong *plVar6;
  byte bVar7;
  ushort uVar8;
  int iVar9;
  int iVar10;
  longlong lVar11;
  ulonglong *puVar12;
  int *piVar13;
  longlong lVar14;
  ushort uVar15;
  short sVar16;
  uint uVar17;
  ulonglong uVar18;
  undefined8 unaff_RBX;
  undefined8 unaff_RSI;
  ushort *puVar19;
  int *piVar20;
  undefined8 unaff_R12;
  int iVar21;
  uint uVar22;
  undefined8 unaff_R15;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [2];
  longlong lStackX_10;
  uint auStackX_18 [2];
  int aiStackX_20 [2];
  ulonglong uStack_38;
  undefined8 uStack_28;
  
  uStack_28 = 0x100019;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  uStack_38 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffe0 + lVar11);
  uVar2 = *(undefined2 *)(param_1 + 0x110);
  sVar16 = *(short *)(param_1 + 0x112);
  piVar20 = (int *)0x0;
  *(undefined8 *)(&stack0x00002020 + lVar11) = unaff_RBX;
  *(undefined4 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
  *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10005f;
  func_0x(&stack0x00000028 + lVar11,(int)sVar16,uVar2,0);
  puVar1 = (ushort *)(param_2 + 1);
  if (*param_2 != 0) {
    *(undefined4 *)(&stack0x00000038 + lVar11) = 0;
    *(undefined **)((longlong)aiStackX_20 + lVar11 + -0x20) = &stack0x00000038 + lVar11;
    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100940;
    piVar13 = (int *)func_0x(puVar1,&stack0x00000028 + lVar11);
    if ((((*param_2 != 0) && (plVar6 = *(longlong **)(param_2 + 8), plVar6 != (longlong *)0x0)) &&
        (*plVar6 != 0)) &&
       ((((&stack0x0000002e)[lVar11] & 8) == 0 && ((*(uint *)(&stack0x00000038 + lVar11) & 1) == 0))
       )) {
      if ((piVar13 == (int *)0x0) || (piVar13 == (int *)0xa4fbf4)) {
        *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        piVar13 = piVar20;
      }
      else {
        *(uint *)((longlong)auStackX_18 + lVar11) = *(uint *)(&stack0x00000038 + lVar11);
        *(longlong *)((longlong)&lStackX_10 + lVar11) = (longlong)aiStackX_20 + lVar11;
        *(undefined4 *)((longlong)auStackX_8 + lVar11) = 0x1f9e;
        *(undefined **)((longlong)aiStackX_20 + lVar11 + -0x20) = &stack0x00000040 + lVar11;
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1009a7;
        piVar13 = (int *)func_0x
                                   (plVar6,&stack0x00000028 + lVar11,piVar13,
                                    *(undefined4 *)((longlong)aiStackX_20 + lVar11));
      }
    }
    goto LAB_;
  }
  if ((*(uint *)(&stack0x00000028 + lVar11) & 0xc0000000) == 0x80000000) {
    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1008f1;
    iVar10 = func_0x(puVar1);
    if (iVar10 == 0) {
      *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
      piVar13 = piVar20;
    }
    else {
      *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10090d;
      piVar13 = (int *)func_0x(param_2 + 0x15,&stack0x00000028 + lVar11,
                                       (longlong)aiStackX_20 + lVar11,&stack0x0000003c + lVar11);
    }
    goto LAB_;
  }
  pbVar4 = *(byte **)(param_2 + 4);
  *(undefined8 *)(&stack0x00002030 + lVar11) = unaff_RSI;
  *(undefined8 *)(&stack0x00001ff0 + lVar11) = unaff_R15;
  iVar21 = 1;
  bVar7 = *pbVar4;
  iVar10 = 0;
  iVar9 = iVar10;
  if ((bVar7 & 0x10) == 0) {
    if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
      uVar8 = ~(*(ushort *)(&stack0x0000002e + lVar11) >> 4);
      goto LAB_;
    }
LAB_:
    if (*(int *)(&stack0x00000028 + lVar11) < 0) {
      if (*(int *)(param_2 + 2) == 0) {
        uVar17 = *(uint *)(param_2 + 8);
        uVar18 = (ulonglong)uVar17;
        *(uint *)(param_2 + 10) = uVar17;
        *puVar1 = 0;
        bVar7 = *pbVar4;
        if ((bVar7 & 0x10) != 0) {
          uVar17 = uVar17 + 2 + (*(ushort *)(pbVar4 + uVar18) + 7 >> 3);
          uVar18 = (ulonglong)uVar17;
          *(uint *)(param_2 + 10) = uVar17;
          bVar7 = *pbVar4;
        }
        *(undefined8 *)(&stack0x00002038 + lVar11) = unaff_R12;
        if ((bVar7 & 0x20) == 0) {
          *(int *)(param_2 + 2) = (int)uVar18;
          param_2[0xe] = 0;
          *(int *)(param_2 + 0xc) = (int)uVar18;
        }
        else {
          puVar19 = (ushort *)(pbVar4 + uVar18);
          uVar8 = *puVar19;
          param_2[0xe] = uVar8;
          if (uVar8 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar14 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar14 != 0)) &&
               ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                (*(char *)(lVar14 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1002ff;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100323;
                (*_DAT_)(1,0xccb1b8,0xdeae88,0x80f);
              }
            }
            uVar5 = *(undefined8 *)(param_2 + 4);
            *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100331;
            func_0x(uVar5,3);
            uVar18 = (ulonglong)*(uint *)(param_2 + 10);
            uVar8 = param_2[0xe];
          }
          uVar17 = (int)uVar18 + (uVar8 + 1) * 2;
          *(uint *)(param_2 + 0xc) = uVar17;
          if (0x1f9e < uVar17) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar14 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar14 != 0 &&
                ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                 (*(char *)(lVar14 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1003d0;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1003f4;
                (*_DAT_)(1,0xccb1b8,0xdeae88,0x816);
              }
            }
            uVar5 = *(undefined8 *)(param_2 + 4);
            *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100402;
            func_0x(uVar5,4);
            uVar8 = param_2[0xe];
            uVar17 = *(uint *)(param_2 + 0xc);
          }
          uVar18 = (ulonglong)uVar8;
          uVar8 = puVar19[uVar18];
          *(uint *)(param_2 + 2) = uVar8 & 0x7fff;
          if ((uVar8 & 0x7fff) < uVar17) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar14 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar14 != 0)) &&
               ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                (*(char *)(lVar14 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1004a0;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1004c4;
                (*_DAT_)(1,0xccb1b8,0xdeae88,0x81d);
              }
            }
            uVar5 = *(undefined8 *)(param_2 + 4);
            *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1004d2;
            func_0x(uVar5,4);
            uVar18 = (ulonglong)(ushort)param_2[0xe];
          }
          if ((short)puVar19[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
            lVar14 = *(longlong *)(param_2 + 4);
            do {
              if ((int)uVar18 == 1) {
                uVar17 = *(uint *)(param_2 + 0xc);
                uVar22 = uVar17;
LAB_:
                if ((*(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar14 + uVar18 * 2) & 0x7fff)
                    < uVar17) goto LAB_;
              }
              else {
                uVar22 = *(uint *)(param_2 + 0xc);
                uVar17 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar14 + -2 + uVar18 * 2)
                         & 0x7fff;
                if (uVar22 <= uVar17) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100542;
                func_0x(lVar14,7);
                uVar22 = *(uint *)(param_2 + 0xc);
              }
              if ((uVar17 < uVar22) || (*(uint *)(param_2 + 2) < uVar17)) goto LAB_;
              lVar14 = *(longlong *)(param_2 + 4);
              if (*(ushort *)((ulonglong)uVar17 + lVar14) == 5) {
                *puVar1 = *puVar1 | 2;
                param_2[0xe] = param_2[0xe] + -1;
                param_2[0x15] = (short)uVar17;
                lVar14 = (ulonglong)(uVar17 & 0xffff) + *(longlong *)(param_2 + 4);
                uVar8 = param_2[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar14 + 2) & 0x4000) != 0) {
                  uVar8 = *(ushort *)(lVar14 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                }
                param_2[0x16] = uVar8;
                param_2[0x16] = (uVar8 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar8;
                break;
              }
              if (*(ushort *)((ulonglong)uVar17 + lVar14) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar8 = param_2[0xe] - 1;
              param_2[0xe] = uVar8;
              if ((uVar8 == 0) ||
                 (uVar18 = (ulonglong)uVar8, -1 < (short)puVar19[(ulonglong)(uVar8 - 1) + 1]))
              goto LAB_;
            } while( true );
          }
          uVar18 = (ulonglong)*(uint *)(param_2 + 2);
        }
        goto LAB_;
      }
      goto LAB_;
    }
    if ((*(ushort *)(&stack0x0000002e + lVar11) & 8) == 0) {
      if ((*(ushort *)(&stack0x0000002e + lVar11) & 0x10) != 0) {
        if ((bVar7 & 0x10) == 0) {
          if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
            iVar10 = **(int **)(&stack0x00000030 + lVar11);
            piVar20 = *(int **)(&stack0x00000030 + lVar11) + 1;
            if (iVar10 != 0x1f9e) {
              *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1001f2;
              (*_DAT_)(1,0xe78f28,0xe77928,0x381);
            }
            goto LAB_;
          }
        }
        else if (((int)*(uint *)(param_2 + 8) <= *(int *)(&stack0x00000028 + lVar11)) ||
                (*(ushort *)(pbVar4 + *(uint *)(param_2 + 8)) <
                 *(ushort *)(&stack0x0000002c + lVar11))) goto LAB_;
      }
      piVar20 = (int *)(pbVar4 + *(int *)(&stack0x00000028 + lVar11));
      iVar10 = 0x1f9e;
    }
    else {
      piVar20 = (int *)0xa4fbf4;
      iVar10 = iVar21;
      if ((pbVar4[*(int *)(&stack0x00000028 + lVar11)] &
          (byte)(1 << ((&stack0x0000002e)[lVar11] & 7))) == 0) {
        piVar20 = (int *)0xa50218;
      }
    }
  }
  else {
    uVar17 = *(uint *)(param_2 + 8);
    if (*(int *)(&stack0x00000028 + lVar11) < (int)uVar17) {
      if ((uint)*(ushort *)(pbVar4 + uVar17) < (uint)*(ushort *)(&stack0x0000002c + lVar11)) {
        uVar8 = ~(*(ushort *)(&stack0x0000002e + lVar11) >> 4);
      }
      else {
        uVar22 = *(ushort *)(&stack0x0000002c + lVar11) - 1;
        uVar8 = (ushort)(pbVar4[(ulonglong)uVar17 + (ulonglong)(uVar22 >> 3) + 2] >>
                        ((byte)uVar22 & 7));
        iVar9 = iVar21;
      }
    }
    else {
      uVar8 = ~(*(ushort *)(&stack0x0000002e + lVar11) >> 4);
    }
LAB_:
    if ((uVar8 & 1) == 0) {
      if ((iVar9 != 0) || (((&stack0x0000002e)[lVar11] & 0x10) == 0)) goto LAB_;
      piVar20 = *(int **)(&stack0x00000030 + lVar11) + 1;
      iVar10 = **(int **)(&stack0x00000030 + lVar11);
    }
  }
  goto LAB_;
LAB_:
  uVar18 = (ulonglong)*(uint *)(param_2 + 2);
LAB_:
  if ((**(byte **)(param_2 + 4) & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0x13) = 0;
  }
  else {
    *(int *)(param_2 + 0x13) = (int)uVar18;
    *(int *)(param_2 + 2) = (int)uVar18 + 0xe;
    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10062b;
    puVar12 = (ulonglong *)func_0x(puVar1);
    uVar18 = *puVar12;
    uVar15 = (ushort)(uVar18 >> 0x30);
    uVar8 = uVar15;
    if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
      uVar8 = uVar15 & 0xdfff;
      if ((uVar18 & 0x4000000000000000) != 0) {
        uVar8 = uVar15 | 0x2000;
      }
    }
    iVar9 = iVar10;
    if (uVar8 == 0xfffc) {
      iVar9 = (int)((uVar18 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar9;
    uVar18 = (ulonglong)*(uint *)(param_2 + 2);
  }
  iVar9 = (int)uVar18;
  if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
     (*(ulonglong *)(param_2 + 0xf) < uVar18 + *(longlong *)(param_2 + 4))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar14 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar14 != 0 &&
         (lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0)) &&
        (*(char *)(lVar14 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100726;
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10074a;
        (*_DAT_)(1,0xccb1b8,0xdeae88,0x877);
      }
    }
    uVar5 = *(undefined8 *)(param_2 + 4);
    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100758;
    func_0x(uVar5,0x12);
    iVar9 = *(int *)(param_2 + 2);
  }
  if (0x3f3b < iVar9 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar14 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar14 != 0 &&
        ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 && (*(char *)(lVar14 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1007e4;
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100808;
        (*_DAT_)(1,0xccb1b8,0xdeae88,0x87c);
      }
    }
    uVar5 = *(undefined8 *)(param_2 + 4);
    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100816;
    func_0x(uVar5,5);
  }
LAB_:
  sVar16 = -*(short *)(&stack0x00000028 + lVar11);
  if (((&stack0x0000002e)[lVar11] & 0x10) != 0) {
    bVar7 = **(byte **)(param_2 + 4);
    if ((bVar7 & 0x10) == 0) {
      if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
        piVar20 = *(int **)(&stack0x00000030 + lVar11) + 1;
        iVar10 = **(int **)(&stack0x00000030 + lVar11);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(param_2 + 8) <= *(int *)(&stack0x00000028 + lVar11)) ||
            (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
             *(ushort *)(&stack0x0000002c + lVar11))) goto LAB_;
  }
  piVar20 = *(int **)(param_2 + 4);
  lVar14 = (longlong)sVar16;
  if ((uint)(int)sVar16 <= (uint)(ushort)param_2[0xe]) {
    uVar17 = *(uint *)(param_2 + 10);
    if (sVar16 == 1) {
      uVar22 = *(uint *)(param_2 + 0xc);
      uVar17 = *(ushort *)((longlong)piVar20 + lVar14 * 2 + (ulonglong)uVar17) & 0x7fff;
LAB_:
      if (uVar17 < uVar22) goto LAB_;
    }
    else {
      puVar1 = (ushort *)((longlong)piVar20 + lVar14 * 2 + (ulonglong)uVar17);
      uVar22 = *(ushort *)((longlong)piVar20 + lVar14 * 2 + ((ulonglong)uVar17 - 2)) & 0x7fff;
      piVar20 = *(int **)(param_2 + 4);
      uVar17 = *puVar1 & 0x7fff;
      if (*(uint *)(param_2 + 0xc) <= uVar22) goto LAB_;
LAB_:
      *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1008d6;
      func_0x(piVar20,7);
      piVar20 = *(int **)(param_2 + 4);
    }
    piVar20 = (int *)((longlong)piVar20 + (ulonglong)uVar22);
    iVar10 = uVar17 - uVar22;
  }
LAB_:
  *(int *)((longlong)aiStackX_20 + lVar11) = iVar10;
  piVar13 = piVar20;
LAB_:
  if (piVar13 != (int *)0x0) {
    uVar3 = *(undefined4 *)(param_1 + 0x114);
    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1009db;
    func_0x(piVar13,param_1 + 0x118,uVar3);
  }
  *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1009f3;
  func_0x(uStack_38 ^ (ulonglong)(&stack0xffffffffffffffe0 + lVar11));
  return;
}

