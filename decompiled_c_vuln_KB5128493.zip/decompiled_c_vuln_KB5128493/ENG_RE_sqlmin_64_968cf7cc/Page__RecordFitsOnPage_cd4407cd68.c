
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_(longlong param_1,short **param_2,uint param_3,uint param_4)

{
  ushort *puVar1;
  byte bVar2;
  ushort uVar3;
  ulonglong *puVar4;
  short *psVar5;
  ulonglong uVar6;
  ushort uVar7;
  short sVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  ulonglong uVar12;
  ushort *puVar13;
  int iVar14;
  byte *pbVar15;
  longlong lVar16;
  int iVar17;
  longlong unaff_GS_OFFSET;
  
  if ((*(char *)(param_1 + 2) < '\0') &&
     (func_0x(param_2,param_1), *(char *)(param_1 + 2) < '\0')) {
    psVar5 = param_2[1];
  }
  else {
    psVar5 = *param_2;
  }
  puVar1 = (ushort *)(psVar5 + 1);
  iVar17 = 0;
  if (*psVar5 == 0) {
    if (*(int *)(psVar5 + 2) == 0) {
      pbVar15 = *(byte **)(psVar5 + 4);
      uVar9 = *(uint *)(psVar5 + 8);
      uVar12 = (ulonglong)uVar9;
      *puVar1 = 0;
      *(uint *)(psVar5 + 10) = uVar9;
      bVar2 = *pbVar15;
      if ((bVar2 & 0x10) != 0) {
        uVar9 = uVar9 + 2 + (*(ushort *)(pbVar15 + uVar12) + 7 >> 3);
        uVar12 = (ulonglong)uVar9;
        *(uint *)(psVar5 + 10) = uVar9;
        bVar2 = *pbVar15;
      }
      if ((bVar2 & 0x20) == 0) {
        *(int *)(psVar5 + 2) = (int)uVar12;
        psVar5[0xe] = 0;
        *(int *)(psVar5 + 0xc) = (int)uVar12;
      }
      else {
        puVar13 = (ushort *)(pbVar15 + uVar12);
        uVar3 = *puVar13;
        psVar5[0xe] = uVar3;
        if (uVar3 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar16 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar16 != 0)) &&
             ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
              (*(char *)(lVar16 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x13136e8,0x14333b8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(psVar5 + 4),3);
          uVar12 = (ulonglong)*(uint *)(psVar5 + 10);
          uVar3 = psVar5[0xe];
        }
        uVar9 = (int)uVar12 + (uVar3 + 1) * 2;
        *(uint *)(psVar5 + 0xc) = uVar9;
        if (0x1f9e < uVar9) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar16 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar16 != 0 &&
              ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
               (*(char *)(lVar16 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x13136e8,0x14333b8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(psVar5 + 4),4);
          uVar3 = psVar5[0xe];
          uVar9 = *(uint *)(psVar5 + 0xc);
        }
        uVar6 = (ulonglong)uVar3;
        uVar10 = puVar13[uVar6] & 0x7fff;
        *(uint *)(psVar5 + 2) = uVar10;
        if (uVar10 < uVar9) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar16 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar16 != 0)) &&
             ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
              (*(char *)(lVar16 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x13136e8,0x14333b8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(psVar5 + 4),4);
          uVar6 = (ulonglong)(ushort)psVar5[0xe];
          uVar10 = *(uint *)(psVar5 + 2);
        }
        uVar12 = (ulonglong)uVar10;
        if ((short)puVar13[(ulonglong)((int)uVar6 - 1) + 1] < 0) {
          pbVar15 = *(byte **)(psVar5 + 4);
          do {
            if ((int)uVar6 == 1) {
              uVar9 = *(uint *)(psVar5 + 0xc);
              uVar10 = uVar9;
LAB_:
              if ((*(ushort *)(pbVar15 + uVar6 * 2 + (ulonglong)*(uint *)(psVar5 + 10)) & 0x7fff) <
                  uVar9) goto LAB_;
            }
            else {
              uVar10 = *(uint *)(psVar5 + 0xc);
              uVar9 = *(ushort *)(pbVar15 + uVar6 * 2 + ((ulonglong)*(uint *)(psVar5 + 10) - 2)) &
                      0x7fff;
              if (uVar10 <= uVar9) goto LAB_;
LAB_:
              func_0x(pbVar15,7);
              uVar10 = *(uint *)(psVar5 + 0xc);
            }
            if ((uVar9 < uVar10) ||
               (uVar12 = (ulonglong)*(uint *)(psVar5 + 2), *(uint *)(psVar5 + 2) < uVar9))
            goto LAB_;
            pbVar15 = *(byte **)(psVar5 + 4);
            if (*(ushort *)(pbVar15 + uVar9) == 5) {
              *puVar1 = *puVar1 | 2;
              psVar5[0xe] = psVar5[0xe] + -1;
              psVar5[0x15] = (short)uVar9;
              lVar16 = (ulonglong)(uVar9 & 0xffff) + *(longlong *)(psVar5 + 4);
              uVar3 = psVar5[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar16 + 2) >> 0xe & 1) != 0) {
                uVar3 = *(ushort *)(lVar16 + 2) & 0x3800 | psVar5[0x16] & 0xc7ffU;
              }
              psVar5[0x16] = uVar3;
              psVar5[0x16] = (uVar3 ^ *(ushort *)(lVar16 + 2)) & 0x7ff ^ uVar3;
              uVar12 = (ulonglong)*(uint *)(psVar5 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar15 + uVar9) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar3 = psVar5[0xe] - 1;
            psVar5[0xe] = uVar3;
            if (uVar3 == 0) goto LAB_;
            uVar6 = (ulonglong)uVar3;
          } while ((short)puVar13[(ulonglong)(uVar3 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar15 = *(byte **)(psVar5 + 4);
        }
      }
      if ((*pbVar15 & 0x40) == 0) {
        *(undefined4 *)(psVar5 + 0x13) = 0;
      }
      else {
        *(int *)(psVar5 + 0x13) = (int)uVar12;
        *(int *)(psVar5 + 2) = (int)uVar12 + 0xe;
        puVar4 = (ulonglong *)func_0x(puVar1);
        uVar7 = (ushort)(*puVar4 >> 0x30);
        uVar3 = uVar7;
        if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
          uVar3 = uVar7 & 0xdfff;
          if ((uVar7 >> 0xe & 1) != 0) {
            uVar3 = uVar7 | 0x2000;
          }
        }
        iVar14 = iVar17;
        if (uVar3 == 0xfffc) {
          iVar14 = (int)((*puVar4 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + iVar14;
        uVar12 = (ulonglong)*(uint *)(psVar5 + 2);
      }
      iVar14 = (int)uVar12;
      if ((*(ulonglong *)(psVar5 + 0xf) != 0) &&
         (*(ulonglong *)(psVar5 + 0xf) < uVar12 + *(longlong *)(psVar5 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar16 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar16 != 0 &&
             (lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0)) &&
            (*(char *)(lVar16 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x13136e8,0x14333b8,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(psVar5 + 4),0x12);
        iVar14 = *(int *)(psVar5 + 2);
      }
      if (0x3f3b < iVar14 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar16 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar16 != 0 &&
            ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
             (*(char *)(lVar16 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x13136e8,0x14333b8,0x87c,0);
          }
        }
        func_0x(*(undefined8 *)(psVar5 + 4),5);
      }
    }
LAB_:
    uVar9 = *(uint *)(psVar5 + 2);
    if ((uVar9 < 9) &&
       (((**(byte **)(psVar5 + 4) & 0xe) == 0 || ((**(byte **)(psVar5 + 4) & 0xe) == 0xc)))) {
      uVar9 = 9;
    }
  }
  else {
    uVar9 = *(uint *)(psVar5 + 2);
    if (uVar9 == 0) {
      func_0x(puVar1);
      uVar9 = *(uint *)(psVar5 + 2);
    }
    if ((uVar9 < 9) &&
       (((**(byte **)(psVar5 + 4) & 0x1c) == 0 || ((**(byte **)(psVar5 + 4) & 0x1c) == 0xc)))) {
      uVar9 = 9;
    }
  }
  uVar10 = 9;
  sVar8 = 1 << ((byte)*(undefined2 *)(param_1 + 4) & 2);
  if (param_4 <= (ushort)(sVar8 + -1 + (short)uVar9 & -sVar8)) {
    if (*(char *)(param_1 + 2) < '\0') {
      psVar5 = param_2[1];
    }
    else {
      psVar5 = *param_2;
    }
    puVar1 = (ushort *)(psVar5 + 1);
    if (*psVar5 == 0) {
      if (*(int *)(psVar5 + 2) == 0) {
        pbVar15 = *(byte **)(psVar5 + 4);
        uVar9 = *(uint *)(psVar5 + 8);
        uVar12 = (ulonglong)uVar9;
        *puVar1 = 0;
        *(uint *)(psVar5 + 10) = uVar9;
        bVar2 = *pbVar15;
        if ((bVar2 & 0x10) != 0) {
          uVar9 = uVar9 + 2 + (*(ushort *)(pbVar15 + uVar12) + 7 >> 3);
          uVar12 = (ulonglong)uVar9;
          *(uint *)(psVar5 + 10) = uVar9;
          bVar2 = *pbVar15;
        }
        if ((bVar2 & 0x20) == 0) {
          *(int *)(psVar5 + 2) = (int)uVar12;
          psVar5[0xe] = 0;
          *(int *)(psVar5 + 0xc) = (int)uVar12;
        }
        else {
          puVar13 = (ushort *)(pbVar15 + uVar12);
          uVar3 = *puVar13;
          psVar5[0xe] = uVar3;
          if (uVar3 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar16 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar16 != 0)) &&
               ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
                (*(char *)(lVar16 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x13136e8,0x14333b8,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(psVar5 + 4),3);
            uVar12 = (ulonglong)*(uint *)(psVar5 + 10);
            uVar3 = psVar5[0xe];
          }
          uVar9 = (int)uVar12 + (uVar3 + 1) * 2;
          *(uint *)(psVar5 + 0xc) = uVar9;
          if (0x1f9e < uVar9) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar16 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar16 != 0 &&
                ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
                 (*(char *)(lVar16 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x13136e8,0x14333b8,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(psVar5 + 4),4);
            uVar3 = psVar5[0xe];
            uVar9 = *(uint *)(psVar5 + 0xc);
          }
          uVar6 = (ulonglong)uVar3;
          uVar11 = puVar13[uVar6] & 0x7fff;
          *(uint *)(psVar5 + 2) = uVar11;
          if (uVar11 < uVar9) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar16 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar16 != 0)) &&
               ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
                (*(char *)(lVar16 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x13136e8,0x14333b8,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(psVar5 + 4),4);
            uVar6 = (ulonglong)(ushort)psVar5[0xe];
            uVar11 = *(uint *)(psVar5 + 2);
          }
          uVar12 = (ulonglong)uVar11;
          if ((short)puVar13[(ulonglong)((int)uVar6 - 1) + 1] < 0) {
            pbVar15 = *(byte **)(psVar5 + 4);
            do {
              if ((int)uVar6 == 1) {
                uVar9 = *(uint *)(psVar5 + 0xc);
                uVar11 = uVar9;
LAB_:
                if ((*(ushort *)(pbVar15 + uVar6 * 2 + (ulonglong)*(uint *)(psVar5 + 10)) & 0x7fff)
                    < uVar9) goto LAB_;
              }
              else {
                uVar11 = *(uint *)(psVar5 + 0xc);
                uVar9 = *(ushort *)(pbVar15 + uVar6 * 2 + ((ulonglong)*(uint *)(psVar5 + 10) - 2)) &
                        0x7fff;
                if (uVar11 <= uVar9) goto LAB_;
LAB_:
                func_0x(pbVar15,7);
                uVar11 = *(uint *)(psVar5 + 0xc);
              }
              if ((uVar9 < uVar11) ||
                 (uVar12 = (ulonglong)*(uint *)(psVar5 + 2), *(uint *)(psVar5 + 2) < uVar9))
              goto LAB_;
              pbVar15 = *(byte **)(psVar5 + 4);
              if (*(ushort *)(pbVar15 + uVar9) == 5) {
                *puVar1 = *puVar1 | 2;
                psVar5[0xe] = psVar5[0xe] + -1;
                psVar5[0x15] = (short)uVar9;
                lVar16 = (ulonglong)(uVar9 & 0xffff) + *(longlong *)(psVar5 + 4);
                uVar3 = psVar5[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar16 + 2) >> 0xe & 1) != 0) {
                  uVar3 = *(ushort *)(lVar16 + 2) & 0x3800 | psVar5[0x16] & 0xc7ffU;
                }
                psVar5[0x16] = uVar3;
                psVar5[0x16] = (uVar3 ^ *(ushort *)(lVar16 + 2)) & 0x7ff ^ uVar3;
                uVar12 = (ulonglong)*(uint *)(psVar5 + 2);
                goto LAB_;
              }
              if (*(ushort *)(pbVar15 + uVar9) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar3 = psVar5[0xe] - 1;
              psVar5[0xe] = uVar3;
              if (uVar3 == 0) goto LAB_;
              uVar6 = (ulonglong)uVar3;
            } while ((short)puVar13[(ulonglong)(uVar3 - 1) + 1] < 0);
          }
          else {
LAB_:
            pbVar15 = *(byte **)(psVar5 + 4);
          }
        }
        if ((*pbVar15 & 0x40) == 0) {
          *(undefined4 *)(psVar5 + 0x13) = 0;
        }
        else {
          *(int *)(psVar5 + 0x13) = (int)uVar12;
          *(int *)(psVar5 + 2) = (int)uVar12 + 0xe;
          puVar4 = (ulonglong *)func_0x(puVar1);
          uVar7 = (ushort)(*puVar4 >> 0x30);
          uVar3 = uVar7;
          if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
            uVar3 = uVar7 & 0xdfff;
            if ((uVar7 >> 0xe & 1) != 0) {
              uVar3 = uVar7 | 0x2000;
            }
          }
          if (uVar3 == 0xfffc) {
            iVar17 = (int)((*puVar4 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + iVar17;
          uVar12 = (ulonglong)*(uint *)(psVar5 + 2);
        }
        iVar17 = (int)uVar12;
        if ((*(ulonglong *)(psVar5 + 0xf) != 0) &&
           (*(ulonglong *)(psVar5 + 0xf) < uVar12 + *(longlong *)(psVar5 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar16 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar16 != 0 &&
               (lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0)) &&
              (*(char *)(lVar16 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x13136e8,0x14333b8,0x877,0);
            }
          }
          func_0x(*(undefined8 *)(psVar5 + 4),0x12);
          iVar17 = *(int *)(psVar5 + 2);
        }
        if (0x3f3b < iVar17 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar16 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar16 != 0 &&
              ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
               (*(char *)(lVar16 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x13136e8,0x14333b8,0x87c,0);
            }
          }
          func_0x(*(undefined8 *)(psVar5 + 4),5);
        }
      }
LAB_:
      if ((8 < *(uint *)(psVar5 + 2)) ||
         (((**(byte **)(psVar5 + 4) & 0xe) != 0 && ((**(byte **)(psVar5 + 4) & 0xe) != 0xc)))) {
        uVar10 = *(uint *)(psVar5 + 2);
      }
    }
    else {
      uVar9 = *(uint *)(psVar5 + 2);
      if (uVar9 == 0) {
        func_0x(puVar1);
        uVar9 = *(uint *)(psVar5 + 2);
      }
      if ((8 < uVar9) ||
         (((**(byte **)(psVar5 + 4) & 0x1c) != 0 && ((**(byte **)(psVar5 + 4) & 0x1c) != 0xc)))) {
        uVar10 = uVar9;
      }
    }
    sVar8 = 1 << ((byte)*(undefined2 *)(param_1 + 4) & 2);
    param_4 = (uint)(ushort)(sVar8 + -1 + (short)uVar10 & -sVar8);
  }
  return param_4 <= param_3;
}

