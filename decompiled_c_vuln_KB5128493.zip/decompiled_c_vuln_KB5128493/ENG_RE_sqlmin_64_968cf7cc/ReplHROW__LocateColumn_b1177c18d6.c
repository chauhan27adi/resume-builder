
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,byte *param_2,uint *param_3,undefined8 param_4,undefined4 *param_5)

{
  undefined4 uVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined8 uVar6;
  ulonglong *puVar7;
  ushort uVar8;
  uint uVar9;
  uint uVar10;
  ushort uVar11;
  short sVar12;
  longlong lVar13;
  ulonglong uVar14;
  longlong lVar15;
  uint *puVar16;
  uint *puVar17;
  longlong *plVar18;
  byte *pbVar19;
  uint uVar20;
  ushort *puVar21;
  longlong unaff_GS_OFFSET;
  bool bVar22;
  undefined auStack_248 [32];
  undefined8 uStack_228;
  undefined8 uStack_220;
  undefined8 uStack_218;
  undefined8 uStack_210;
  undefined4 uStack_208;
  uint uStack_1f8;
  ushort uStack_1f4;
  ushort uStack_1f2;
  uint *puStack_1f0;
  ushort uStack_1e8;
  uint uStack_1e4;
  uint uStack_1e0;
  uint *puStack_1d8;
  uint uStack_1d0;
  uint uStack_1cc;
  undefined4 *puStack_1c8;
  undefined auStack_1c0 [8];
  longlong *plStack_1b8;
  undefined8 uStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined8 uStack_198;
  undefined4 uStack_190;
  undefined uStack_18c;
  undefined8 uStack_188;
  longlong lStack_180;
  short *psStack_178;
  undefined8 uStack_170;
  undefined4 uStack_168;
  undefined8 uStack_160;
  uint auStack_158 [68];
  ulonglong uStack_48;
  
  uStack_160 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_248;
  puStack_1c8 = param_5;
  puVar16 = (uint *)0x0;
  iVar4 = 0;
  uVar20 = 0;
  *param_5 = 0;
  uStack_1f8 = 0;
  uVar8 = 0;
  uStack_1f4 = 0;
  uStack_1f2 = uStack_1f2 & 0xffe0;
  puStack_1f0 = (uint *)0x0;
  uStack_1cc = 0;
  lVar15 = *(longlong *)(param_1 + 0x20);
  puStack_1d8 = param_3;
  if (*(uint *)(lVar15 + 0x230) != 0) {
    puVar17 = puVar16;
    do {
      if ((*(int *)(*(longlong *)(lVar15 + 0x238) + 0x20 + (longlong)puVar17 * 0x30) ==
           *(int *)(param_2 + 0x20)) &&
         (plVar18 = *(longlong **)(lVar15 + 0x250), plVar18 != (longlong *)0x0)) {
        do {
          if (*plVar18 == *(longlong *)(param_1 + 0x24)) {
            lVar13 = (longlong)puVar17 * 0x30 + plVar18[2];
            uStack_1e0 = *(uint *)(lVar13 + 0x24);
            uStack_1e8 = *(ushort *)(plVar18[5] + (longlong)puVar17 * 2);
            bVar2 = *(byte *)(lVar13 + 0x28);
            lVar15 = (longlong)puVar17 * 0x106 + *(longlong *)(lVar15 + 0x228);
            uVar11 = *(ushort *)(lVar15 + 0x102);
            uVar6 = (*_DAT_)();
            uStack_228 = (uint *)CONCAT44(uStack_228._4_4_,(uint)uVar11);
            uStack_220 = (uint *)lVar15;
            iVar3 = func_0x(auStack_158,0x80,0x187fe90,uVar6);
            if (iVar3 < 0) {
              uStack_218 = (uint *)CONCAT44(uStack_218._4_4_,iVar3);
              uStack_220 = (uint *)CONCAT44(uStack_220._4_4_,0x51);
              uStack_228 = (uint *)0x1a291e8;
              (*_DAT_)(4,7,0x10,1);
            }
            uVar9 = (uint)uVar11 + (uint)uVar11;
            if (0x100 < (uint)uVar11 + (uint)uVar11) {
              uVar9 = 0x100;
            }
            uStack_1f8 = uStack_1e0;
            if ((uStack_1e0 & 0xc0000000) == 0x80000000) {
              uVar8 = uStack_1f2 & 0xfff0;
            }
            else {
              uStack_1f4 = uStack_1e8;
              if (*param_2 == 0x68) {
                uVar8 = 8;
              }
              uVar8 = uStack_1f2 & 0xfff0 | (ushort)(bVar2 & 7) | uVar8;
            }
            uStack_1f2 = uVar8 & 0xffef;
            if ((*(short *)(param_2 + 0x10) != -1) &&
               (*(char *)((ulonglong)*(byte *)((ulonglong)*param_2 + 0x17b6750) + 0x216bdc8) == '\0'
               )) {
              *puStack_1c8 = 0;
              iVar4 = func_0x(param_1,&uStack_1f8);
              if (iVar4 == 0) {
                iVar4 = func_0x(param_1,param_2,&uStack_1f8);
                if (iVar4 != 0) {
                  uVar8 = *(ushort *)(param_2 + 0x10);
                  if ((uVar8 == 0xffff) ||
                     (*(char *)((ulonglong)*(byte *)((ulonglong)*param_2 + 0x17b6750) + 0x216bdc8)
                      != '\0')) {
                    uVar8 = 0x1fa4;
                  }
                  if ((uVar8 != 0) && (*(uint *)(param_1 + 0x30) < (uint)uVar8)) {
                    if (*(longlong *)(param_1 + 0x2c) != 0) {
                      (*_DAT_)(*(longlong *)(param_1 + 0x2c),1);
                      uStack_228 = (uint *)0x0;
                      func_0x(**(undefined2 **)(param_1 + 0x20),0x32,0);
                    }
                    uStack_220 = (uint *)CONCAT71(uStack_220._1_7_,6);
                    uStack_228 = (uint *)CONCAT44(uStack_228._4_4_,0xea);
                    uVar6 = (*_DAT_)(uVar8,_DAT_,1,0x1a291e8);
                    *(undefined8 *)(param_1 + 0x2c) = uVar6;
                    uStack_228 = (uint *)0x0;
                    func_0x(**(undefined2 **)(param_1 + 0x20),0x32,uVar8);
                    if (*(longlong *)(param_1 + 0x2c) == 0) {
                      uStack_228 = (uint *)0x0;
                      (*_DAT_)(1,0x1bdb600,0x1bb55e0,0xec);
                    }
                    *(uint *)(param_1 + 0x30) = (uint)uVar8;
                  }
                }
                uStack_170 = *(undefined8 *)(param_1 + 0x2c);
                uStack_168 = *(undefined4 *)(param_1 + 0x30);
                sVar12 = *(short *)(param_2 + 0x10);
                if ((sVar12 == -1) ||
                   (*(char *)((ulonglong)*(byte *)((ulonglong)*param_2 + 0x17b6750) + 0x216bdc8) !=
                    '\0')) {
                  sVar12 = 0x1fa4;
                }
                uStack_208 = 0;
                uStack_210 = 0;
                uStack_218 = &uStack_1cc;
                uStack_220 = puStack_1d8;
                uStack_228 = (uint *)CONCAT44(uStack_228._4_4_,(uint)(uStack_1f4 != 0));
                psStack_178 = param_1;
                func_0x(&psStack_178,param_2,&uStack_1f8,sVar12);
              }
              else {
                lVar15 = *(longlong *)(param_1 + 0x1c);
                if (lVar15 == 0) {
                  uStack_228 = (uint *)0x0;
                  (*_DAT_)(1,0x1bdb5e0,0x1bb55e0,0xca);
                  lVar15 = *(longlong *)(param_1 + 0x1c);
                }
                uVar1 = *(undefined4 *)(param_2 + 0x20);
                *(uint *)(lVar15 + 0x88) = uVar9;
                *(undefined4 *)(lVar15 + 400) = uVar1;
                uVar6 = (*_DAT_)();
                uStack_220 = auStack_158;
                uStack_228 = (uint *)(ulonglong)(uVar9 >> 1);
                iVar4 = func_0x(lVar15 + 0x8c,0x81,0x187fe90,uVar6);
                if (iVar4 < 0) {
                  uStack_218 = (uint *)CONCAT44(uStack_218._4_4_,iVar4);
                  uStack_220 = (uint *)CONCAT44(uStack_220._4_4_,0x260);
                  uStack_228 = (uint *)0x1a291e8;
                  (*_DAT_)(4,7,0x10,1);
                }
                iVar4 = *(int *)(param_1 + 0x28);
                lVar15 = *(longlong *)(param_1 + 0x1c);
                lVar13 = *(longlong *)(lVar15 + 0x10);
                if (lVar13 == 0) {
                  *(undefined4 *)(lVar15 + 0x4c) = 1;
                }
                else {
                  if (*(int *)(lVar13 + 0x78) != iVar4) {
                    *(int *)(lVar13 + 0x78) = iVar4;
                    *(undefined4 *)(lVar15 + 0x4c) = 1;
                  }
                  lVar13 = lVar15 + 0x58;
                  if (iVar4 == 0) {
                    lVar13 = lVar15 + 0x68;
                  }
                  *(longlong *)(lVar15 + 0x78) = lVar13;
                }
                lVar15 = *(longlong *)(lVar15 + 0x18);
                if ((lVar15 != 0) && (*(int *)(lVar15 + 0x30) != iVar4)) {
                  *(int *)(lVar15 + 0x30) = iVar4;
                }
                *(uint *)(*(longlong *)(param_1 + 0x1c) + 0x54) =
                     *(uint *)(param_2 + 0x28) >> 0xb & 1;
                func_0x(*(undefined8 *)(param_1 + 0x1c),uStack_1e0,uStack_1e8,puStack_1d8);
              }
              goto LAB_;
            }
            *puStack_1c8 = 1;
            iVar3 = func_0x(param_1,&uStack_1f8);
            lVar15 = *(longlong *)(param_1 + 0x1c);
            if (lVar15 == 0) {
              uStack_228 = (uint *)0x0;
              (*_DAT_)(1,0x1bdb5e0,0x1bb55e0,0xa9);
              lVar15 = *(longlong *)(param_1 + 0x1c);
            }
            uVar1 = *(undefined4 *)(param_2 + 0x20);
            *(uint *)(lVar15 + 0x88) = uVar9;
            *(undefined4 *)(lVar15 + 400) = uVar1;
            uVar6 = (*_DAT_)();
            uStack_220 = auStack_158;
            uStack_228 = (uint *)(ulonglong)(uVar9 >> 1);
            iVar5 = func_0x(lVar15 + 0x8c,0x81,0x187fe90,uVar6);
            if (iVar5 < 0) {
              uStack_218 = (uint *)CONCAT44(uStack_218._4_4_,iVar5);
              uStack_220 = (uint *)CONCAT44(uStack_220._4_4_,0x260);
              uStack_228 = (uint *)0x1a291e8;
              (*_DAT_)(4,7,0x10,1);
            }
            iVar5 = *(int *)(param_1 + 0x28);
            lVar15 = *(longlong *)(param_1 + 0x1c);
            lVar13 = *(longlong *)(lVar15 + 0x10);
            if (lVar13 == 0) {
              *(undefined4 *)(lVar15 + 0x4c) = 1;
            }
            else {
              if (*(int *)(lVar13 + 0x78) != iVar5) {
                *(int *)(lVar13 + 0x78) = iVar5;
                *(undefined4 *)(lVar15 + 0x4c) = 1;
              }
              lVar13 = 0x58;
              if (iVar5 == 0) {
                lVar13 = 0x68;
              }
              *(longlong *)(lVar15 + 0x78) = lVar13 + lVar15;
            }
            lVar15 = *(longlong *)(lVar15 + 0x18);
            if ((lVar15 != 0) && (*(int *)(lVar15 + 0x30) != iVar5)) {
              *(int *)(lVar15 + 0x30) = iVar5;
            }
            *(uint *)(*(longlong *)(param_1 + 0x1c) + 0x54) = *(uint *)(param_2 + 0x28) >> 0xb & 1;
            if (iVar3 != 0) {
              func_0x(*(undefined8 *)(param_1 + 0x1c),uStack_1e0,uStack_1e8,puStack_1d8);
              goto LAB_;
            }
            uStack_1e4 = 0;
            uVar8 = *(ushort *)(param_2 + 0x10);
            if ((uVar8 == 0xffff) ||
               (*(char *)((ulonglong)*(byte *)((ulonglong)*param_2 + 0x17b6750) + 0x216bdc8) != '\0'
               )) {
              uVar8 = 0x1fa4;
            }
            bVar22 = uStack_1f4 != 0;
            if (*param_1 != 0) {
              uStack_1d0 = 0;
              uStack_228 = &uStack_1d0;
              puVar17 = (uint *)func_0x(param_1 + 1,&uStack_1f8);
              uVar20 = uStack_1e4;
              if ((((*param_1 != 0) &&
                   (plVar18 = *(longlong **)(param_1 + 8), plVar18 != (longlong *)0x0)) &&
                  (*plVar18 != 0)) && (((uStack_1f2 & 8) == 0 && ((uStack_1d0 & 1) == 0)))) {
                if ((puVar17 == (uint *)0x0) || (puVar17 == (uint *)0x17b62b4)) {
                  uStack_1e4 = 0;
                  puVar17 = puVar16;
                  uVar20 = uStack_1e4;
                }
                else {
                  uStack_210 = CONCAT44(uStack_210._4_4_,uStack_1d0);
                  uStack_218 = &uStack_1e4;
                  uStack_220 = (uint *)((ulonglong)uStack_220 & 0xffffffff00000000);
                  uStack_228 = (uint *)0x0;
                  puVar17 = (uint *)func_0x(plVar18,&uStack_1f8,puVar17,uStack_1e4);
                  uVar20 = uStack_1e4;
                }
              }
              goto LAB_;
            }
            if ((uStack_1f8 & 0xc0000000) == 0x80000000) {
              iVar4 = func_0x(param_1 + 1);
              if (iVar4 == 0) {
                puVar17 = (uint *)0x0;
                uVar20 = uStack_1e4;
              }
              else {
                puVar17 = (uint *)func_0x(param_1 + 0x15,&uStack_1f8,&uStack_1e4,auStack_1c0
                                                 );
                uVar20 = uStack_1e4;
              }
              goto LAB_;
            }
            if ((bVar22) || ((uStack_1f2 & 0x10) != 0)) {
              pbVar19 = *(byte **)(param_1 + 4);
              if ((*pbVar19 & 0x10) == 0) {
                if ((1 << (*pbVar19 & 0xe) & 0x1105U) != 0) goto LAB_;
                uVar9 = uVar20;
                iVar3 = 1;
LAB_:
                if (bVar22) goto LAB_;
              }
              else {
                uVar9 = *(uint *)(param_1 + 8);
                if ((int)uVar9 <= (int)uStack_1f8) {
LAB_:
                  uVar9 = ~(uint)(uStack_1f2 >> 4) & 1;
                  iVar3 = iVar4;
                  goto LAB_;
                }
                if ((uint)*(ushort *)(pbVar19 + uVar9) < (uint)uStack_1f4) goto LAB_;
                if (!bVar22) goto LAB_;
                uVar10 = uStack_1f4 - 1;
                uVar9 = pbVar19[(ulonglong)(uVar10 >> 3) + (ulonglong)uVar9 + 2] >>
                        ((byte)uVar10 & 7) & 1;
                iVar3 = 1;
LAB_:
                puVar17 = puVar16;
                if (uVar9 != 0) goto LAB_;
              }
              if ((iVar3 == 0) && ((uStack_1f2 & 0x10) != 0)) {
                puVar17 = puStack_1f0 + 1;
                uVar20 = *puStack_1f0;
                goto LAB_;
              }
            }
LAB_:
            if (-1 < (int)uStack_1f8) {
              if ((uStack_1f2 & 8) != 0) {
                puVar17 = (uint *)0x17b62b4;
                if ((*(byte *)((longlong)(int)uStack_1f8 + *(longlong *)(param_1 + 4)) &
                    (byte)(1 << ((byte)uStack_1f2 & 7))) == 0) {
                  puVar17 = (uint *)0x17b68d8;
                }
                uStack_1e4 = 1;
                uVar20 = uStack_1e4;
                goto LAB_;
              }
              uVar9 = (uint)uVar8;
              if ((uStack_1f2 & 0x10) != 0) {
                bVar2 = **(byte **)(param_1 + 4);
                if ((bVar2 & 0x10) == 0) {
                  if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
LAB_:
                    puVar17 = puStack_1f0 + 1;
                    uVar20 = *puStack_1f0;
                    if ((uVar9 != 0) && (uVar20 != uVar9)) {
                      uStack_228 = (uint *)0x0;
                      (*_DAT_)(1,0x1bdf5e8,0x1bddfe8,0x381);
                    }
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_1f8) ||
                        (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < uStack_1f4)
                        ) goto LAB_;
              }
              puVar17 = (uint *)((longlong)(int)uStack_1f8 + *(longlong *)(param_1 + 4));
              uVar20 = uVar9;
              goto LAB_;
            }
            if (*(int *)(param_1 + 2) != 0) goto LAB_;
            param_1[1] = 0;
            uVar9 = *(uint *)(param_1 + 8);
            uVar14 = (ulonglong)uVar9;
            *(uint *)(param_1 + 10) = uVar9;
            pbVar19 = *(byte **)(param_1 + 4);
            bVar2 = *pbVar19;
            if ((bVar2 & 0x10) != 0) {
              uVar9 = uVar9 + 2 + (*(ushort *)(pbVar19 + uVar14) + 7 >> 3);
              uVar14 = (ulonglong)uVar9;
              *(uint *)(param_1 + 10) = uVar9;
              bVar2 = *pbVar19;
            }
            if ((bVar2 & 0x20) == 0) {
              *(int *)(param_1 + 2) = (int)uVar14;
              param_1[0xe] = 0;
              *(int *)(param_1 + 0xc) = (int)uVar14;
              goto LAB_;
            }
            puVar21 = (ushort *)(pbVar19 + uVar14);
            uVar8 = *puVar21;
            param_1[0xe] = uVar8;
            if (uVar8 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar15 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar15 != 0)) &&
                 ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_228 = (uint *)0x0;
                  (*_DAT_)(1,0x1a31878,0x1b51548,0x80f);
                }
              }
              func_0x(*(undefined8 *)(param_1 + 4),3);
              uVar14 = (ulonglong)*(uint *)(param_1 + 10);
              uVar8 = param_1[0xe];
            }
            uVar9 = (int)uVar14 + (uVar8 + 1) * 2;
            *(uint *)(param_1 + 0xc) = uVar9;
            if (0x1f9e < uVar9) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar15 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar15 != 0 &&
                  ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                   (*(char *)(lVar15 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_228 = (uint *)0x0;
                  (*_DAT_)(1,0x1a31878,0x1b51548,0x816);
                }
              }
              func_0x(*(undefined8 *)(param_1 + 4),4);
              uVar8 = param_1[0xe];
              uVar9 = *(uint *)(param_1 + 0xc);
            }
            uVar14 = (ulonglong)uVar8;
            uVar8 = puVar21[uVar14];
            *(uint *)(param_1 + 2) = uVar8 & 0x7fff;
            if ((uVar8 & 0x7fff) < uVar9) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar15 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar15 != 0)) &&
                 ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_228 = (uint *)0x0;
                  (*_DAT_)(1,0x1a31878,0x1b51548,0x81d);
                }
              }
              func_0x(*(undefined8 *)(param_1 + 4),4);
              uVar14 = (ulonglong)(ushort)param_1[0xe];
            }
            if (-1 < (short)puVar21[(ulonglong)((int)uVar14 - 1) + 1]) goto LAB_;
            lVar15 = *(longlong *)(param_1 + 4);
            goto LAB_;
          }
          plVar18 = (longlong *)plVar18[7];
        } while (plVar18 != (longlong *)0x0);
      }
      uVar9 = (int)puVar17 + 1;
      puVar17 = (uint *)(ulonglong)uVar9;
    } while (uVar9 < *(uint *)(lVar15 + 0x230));
  }
  uStack_228 = *(uint **)(param_1 + 0x24);
  func_0x(0x49a1,0x10,1,*(int *)(param_2 + 0x20));
  goto LAB_;
LAB_:
  lVar13 = (ulonglong)*(uint *)(param_1 + 10) + lVar15;
  if ((int)uVar14 == 1) {
    uVar9 = *(uint *)(param_1 + 0xc);
    uVar8 = *(ushort *)(lVar13 + uVar14 * 2);
    uVar10 = uVar9;
LAB_:
    if ((uVar8 & 0x7fff) < uVar9) goto LAB_;
  }
  else {
    uVar9 = *(ushort *)(lVar13 + -2 + uVar14 * 2) & 0x7fff;
    uVar10 = *(uint *)(param_1 + 0xc);
    uVar8 = *(ushort *)(lVar13 + uVar14 * 2);
    if (uVar10 <= uVar9) goto LAB_;
LAB_:
    func_0x(lVar15,7);
    uVar10 = *(uint *)(param_1 + 0xc);
  }
  if ((uVar9 < uVar10) || (*(uint *)(param_1 + 2) < uVar9)) goto LAB_;
  lVar15 = *(longlong *)(param_1 + 4);
  if (*(ushort *)(lVar15 + (ulonglong)uVar9) == 5) {
    param_1[1] = param_1[1] | 2;
    param_1[0xe] = param_1[0xe] + -1;
    param_1[0x15] = (short)uVar9;
    lVar15 = (ulonglong)(uVar9 & 0xffff) + *(longlong *)(param_1 + 4);
    uVar8 = param_1[0x16] & 0xc7ffU;
    if ((*(ushort *)(lVar15 + 2) & 0x4000) != 0) {
      uVar8 = *(ushort *)(lVar15 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
    }
    param_1[0x16] = uVar8;
    param_1[0x16] = (uVar8 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar8;
LAB_:
    uVar14 = (ulonglong)*(uint *)(param_1 + 2);
    pbVar19 = *(byte **)(param_1 + 4);
    goto LAB_;
  }
  if (0x3ff < *(ushort *)(lVar15 + (ulonglong)uVar9)) goto code_r0x00100bbb;
  goto LAB_;
code_r0x00100bbb:
  param_1[1] = param_1[1] | 1;
  uVar8 = param_1[0xe] - 1;
  param_1[0xe] = uVar8;
  if ((uVar8 == 0) || (uVar14 = (ulonglong)uVar8, -1 < (short)puVar21[(ulonglong)(uVar8 - 1) + 1]))
  goto LAB_;
  goto LAB_;
LAB_:
  uVar14 = (ulonglong)*(uint *)(param_1 + 2);
  pbVar19 = *(byte **)(param_1 + 4);
LAB_:
  if ((*pbVar19 & 0x40) == 0) {
    *(undefined4 *)(param_1 + 0x13) = 0;
  }
  else {
    *(int *)(param_1 + 0x13) = (int)uVar14;
    *(int *)(param_1 + 2) = (int)uVar14 + 0xe;
    puVar7 = (ulonglong *)func_0x(param_1 + 1);
    uVar14 = *puVar7;
    uVar11 = (ushort)(uVar14 >> 0x30);
    uVar8 = uVar11;
    if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
      uVar8 = uVar11 & 0xdfff;
      if ((uVar14 & 0x4000000000000000) != 0) {
        uVar8 = uVar11 | 0x2000;
      }
    }
    if (uVar8 == 0xfffc) {
      iVar4 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar4;
    uVar14 = (ulonglong)*(uint *)(param_1 + 2);
  }
  iVar4 = (int)uVar14;
  if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
     (*(ulonglong *)(param_1 + 0xf) < uVar14 + *(longlong *)(param_1 + 4))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar15 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8),
         lVar15 != 0 && (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
        (*(char *)(lVar15 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        uStack_228 = (uint *)0x0;
        (*_DAT_)(1,0x1a31878,0x1b51548,0x877);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 4),0x12);
    iVar4 = *(int *)(param_1 + 2);
  }
  if (0x3f3b < iVar4 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar15 = *(longlong *)
                   ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8),
        lVar15 != 0 &&
        ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 && (*(char *)(lVar15 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        uStack_228 = (uint *)0x0;
        (*_DAT_)(1,0x1a31878,0x1b51548,0x87c);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 4),5);
  }
LAB_:
  sVar12 = -(short)uStack_1f8;
  if ((uStack_1f2 & 0x10) == 0) {
LAB_:
    lVar15 = (longlong)sVar12;
    puVar17 = *(uint **)(param_1 + 4);
    if ((uint)(int)sVar12 <= (uint)(ushort)param_1[0xe]) {
      uVar20 = *(uint *)(param_1 + 10);
      if (sVar12 == 1) {
        uVar9 = *(uint *)(param_1 + 0xc);
        uVar20 = *(ushort *)((longlong)puVar17 + lVar15 * 2 + (ulonglong)uVar20) & 0x7fff;
LAB_:
        if (uVar20 < uVar9) goto LAB_;
      }
      else {
        uVar9 = *(ushort *)((longlong)puVar17 + lVar15 * 2 + ((ulonglong)uVar20 - 2)) & 0x7fff;
        uVar20 = *(ushort *)((longlong)puVar17 + lVar15 * 2 + (ulonglong)uVar20) & 0x7fff;
        puVar17 = *(uint **)(param_1 + 4);
        if (*(uint *)(param_1 + 0xc) <= uVar9) goto LAB_;
LAB_:
        func_0x(puVar17,7);
        puVar17 = *(uint **)(param_1 + 4);
      }
      puVar17 = (uint *)((longlong)puVar17 + (ulonglong)uVar9);
      uVar20 = uVar20 - uVar9;
    }
  }
  else {
    bVar2 = **(byte **)(param_1 + 4);
    if ((bVar2 & 0x10) == 0) {
      if ((1 << (bVar2 & 0xe) & 0x1105U) == 0) goto LAB_;
    }
    else if (((int)uStack_1f8 < (int)*(uint *)(param_1 + 8)) &&
            (uStack_1f4 <= *(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8))))
    goto LAB_;
    puVar17 = puStack_1f0 + 1;
    uVar20 = *puStack_1f0;
  }
LAB_:
  uStack_1e4 = uVar20;
  uVar20 = uStack_1e4;
  uVar8 = uStack_1e8;
  lVar15 = *(longlong *)(param_1 + 0x1c);
  *(undefined4 *)(lVar15 + 0x50) = 1;
  if (puVar17 != (uint *)0x0) {
    iVar4 = func_0x(lVar15);
    if (iVar4 == 0) {
      uStack_228 = (uint *)0x1bdb670;
      (*_DAT_)(1,0x1bb2bb0,0x1bb55e0,0x33d);
      *puStack_1d8 = 0;
      goto LAB_;
    }
    func_0x(lVar15);
    uStack_198 = *(undefined8 *)(lVar15 + 8);
    uStack_1a0 = *(undefined8 *)(lVar15 + 0x10);
    uStack_18c = 0;
    uStack_190 = 0;
    uStack_188 = 0;
    uStack_1a8 = 0;
    uStack_1b0 = 0x17ab200;
    lStack_180 = lVar15;
    iVar4 = func_0x(&uStack_1b0,puVar17,uVar20);
    if (iVar4 == 0) {
      uStack_218 = (uint *)CONCAT44(uStack_218._4_4_,uVar20);
      uStack_228 = (uint *)0x1bdb7d0;
      uStack_220 = puVar17;
      (*_DAT_)(1,0x1bb2bb0,0x1bb55e0,0x34b);
      uStack_1b0 = 0x17ab180;
      *puStack_1d8 = 0;
      goto LAB_;
    }
    *(uint *)(lVar15 + 0x20) = (uint)uVar8;
    *(uint *)(lVar15 + 0x24) = uStack_1e0;
    *(undefined4 *)(lVar15 + 0x4c) = 0;
    uStack_1b0 = 0x17ab180;
    if (*(longlong *)(lVar15 + 0x30) == 0) {
      uStack_228 = (uint *)0x1bdb778;
      (*_DAT_)(1,0x1bb2bb0,0x1bb55e0,0x35a);
      *puStack_1d8 = 0;
      goto LAB_;
    }
    plStack_1b8 = (longlong *)0x0;
    plStack_1b8 = (longlong *)
                  (**(code **)(**(longlong **)(lVar15 + 0x30) + 8))(*(longlong **)(lVar15 + 0x30),0)
    ;
    if (plStack_1b8 != (longlong *)0x0) {
      (**(code **)(*plStack_1b8 + 0x10))(plStack_1b8);
      *puStack_1d8 = *(uint *)(lVar15 + 0x38);
      goto LAB_;
    }
    uStack_228 = (uint *)0x1bdb7a0;
    (*_DAT_)(1,0x1bb2bb0,0x1bb55e0,0x364);
  }
  *puStack_1d8 = 0;
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_248);
  return;
}

