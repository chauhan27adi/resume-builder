
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined2 param_1,uint *param_2,uint *param_3)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  ulonglong uVar6;
  longlong unaff_GS_OFFSET;
  undefined auStack_148 [32];
  undefined8 uStack_128;
  undefined8 uStack_120;
  undefined uStack_118;
  undefined8 uStack_110;
  undefined4 uStack_108;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined8 uStack_f0;
  undefined4 uStack_e8;
  undefined auStack_e0 [16];
  undefined8 uStack_d0;
  longlong lStack_c8;
  undefined2 uStack_c0;
  undefined8 uStack_b8;
  int iStack_b0;
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  longlong lStack_68;
  uint uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_d0 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_148;
  if ((DAT_ & 0x20) != 0) {
    puVar5 = (uint *)0x0;
    uStack_f0 = 0;
    uStack_e8 = 1;
    auStack_e0._0_8_ =
         *(longlong **)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
          0x90);
    auStack_e0._8_8_ = 0;
    cVar1 = (**(code **)(*(longlong *)auStack_e0._0_8_ + 0x1d0))();
    if (cVar1 == '\0') {
      uStack_108 = 0;
      uStack_110 = 0;
      uStack_118 = 0;
      uStack_120 = CONCAT44(uStack_120._4_4_,2);
      uStack_128 = CONCAT44(uStack_128._4_4_,1);
      (**(code **)(*(longlong *)auStack_e0._0_8_ + 8))(auStack_e0._0_8_,0x1a76938,0x20,1);
      uStack_f0 = CONCAT44(uStack_f0._4_4_,2);
    }
    else {
      (**(code **)(*(longlong *)auStack_e0._0_8_ + 0xe8))
                (auStack_e0._0_8_,1,1,(longlong)&uStack_f0 + 4);
      uStack_e8 = 1;
      uStack_f0 = CONCAT44(uStack_f0._4_4_,4);
    }
    iVar2 = func_0x(param_1,0x1a76938);
    if (iVar2 != 0) {
      uStack_b8 = (**(code **)(*(longlong *)auStack_e0._0_8_ + 0x1b0))();
      lStack_c8 = 0;
      auStack_a8 = ZEXT816(0);
      auStack_98 = ZEXT816(0);
      auStack_88 = ZEXT816(0);
      auStack_78 = ZEXT816(0);
      lStack_68 = 0;
      uStack_60 = 0;
      uStack_58 = 0;
      uStack_50 = 0;
      uStack_c0 = param_1;
      iStack_b0 = iVar2;
      iVar2 = func_0x(&lStack_c8,3,1);
      if (iVar2 != 0) {
        uStack_120 = lStack_c8;
        uStack_128 = uStack_58;
        iVar2 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1,0);
        if (iVar2 == 0) {
          uStack_f8 = 0;
          puVar4 = puVar5;
          if (lStack_c8 != 0) {
            uVar3 = func_0x(&lStack_c8,0x1a768d8,&uStack_f8);
            uVar6 = (ulonglong)uVar3;
            if ((ulonglong)uVar3 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_68)) {
LAB_:
              if (uVar3 <= uStack_60) {
                puVar4 = (uint *)(*(longlong *)((ulonglong)(uVar3 - 1) * 0x58 + 8 + lStack_68) +
                                 lStack_c8);
              }
            }
            else {
              uVar3 = 1;
              if (uStack_60 != 0) {
                do {
                  if (uVar6 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_68))
                  goto LAB_;
                  uVar3 = uVar3 + 1;
                } while (uVar3 <= uStack_60);
              }
            }
          }
          *param_2 = *puVar4;
          uStack_f4 = 0;
          if (lStack_c8 != 0) {
            uVar3 = func_0x(&lStack_c8,0x1a768f0,&uStack_f4);
            uVar6 = (ulonglong)uVar3;
            if (uVar6 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_68)) {
LAB_:
              puVar5 = (uint *)0x0;
              if (uVar3 <= uStack_60) {
                puVar5 = (uint *)(lStack_c8 +
                                 *(longlong *)((ulonglong)(uVar3 - 1) * 0x58 + 8 + lStack_68));
              }
            }
            else {
              uVar3 = 1;
              if (uStack_60 != 0) {
                do {
                  if (uVar6 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_68))
                  goto LAB_;
                  uVar3 = uVar3 + 1;
                } while (uVar3 <= uStack_60);
              }
            }
          }
          uVar3 = *puVar5;
          *param_3 = uVar3;
          if (10 < *param_2) {
            *param_2 = 10;
            uVar3 = *param_3;
          }
          if (10 < uVar3) {
            *param_3 = 10;
          }
        }
      }
      func_0x(&lStack_c8);
    }
    func_0x(&uStack_f0,0);
    func_0x(0x1a76800,*param_2,*param_3);
    if ((int)uStack_f0 != 0) {
      func_0x(&uStack_f0,0);
    }
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_148);
  return;
}

