
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined2 param_1,int param_2,undefined4 *param_3)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  byte *pbVar4;
  ulonglong uVar5;
  longlong unaff_GS_OFFSET;
  undefined auStack_2f8 [32];
  undefined8 uStack_2d8;
  undefined8 uStack_2d0;
  ulonglong uStack_2c8;
  undefined8 uStack_2c0;
  undefined4 uStack_2b8;
  int aiStack_2a8 [2];
  uint auStack_2a0 [2];
  uint auStack_298 [2];
  undefined8 uStack_290;
  undefined4 uStack_288;
  undefined auStack_280 [16];
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined auStack_268 [16];
  undefined auStack_258 [16];
  undefined auStack_248 [16];
  undefined auStack_238 [16];
  undefined auStack_228 [16];
  undefined8 uStack_218;
  undefined auStack_208 [16];
  undefined auStack_1f8 [16];
  undefined auStack_1e8 [16];
  undefined auStack_1d8 [16];
  undefined auStack_1c8 [16];
  undefined8 uStack_1b8;
  undefined8 uStack_1a8;
  undefined auStack_1a0 [16];
  undefined auStack_190 [16];
  undefined auStack_180 [16];
  undefined auStack_170 [16];
  undefined auStack_160 [16];
  undefined auStack_150 [24];
  longlong lStack_138;
  undefined2 uStack_130;
  undefined8 uStack_128;
  int iStack_120;
  undefined auStack_118 [16];
  undefined auStack_108 [16];
  undefined auStack_f8 [16];
  undefined auStack_e8 [16];
  longlong lStack_d8;
  uint uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  longlong lStack_b8;
  undefined2 uStack_b0;
  undefined8 uStack_a8;
  int iStack_a0;
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  longlong lStack_58;
  uint uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  
  uStack_1a8 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_2f8;
  pbVar4 = (byte *)0x0;
  uStack_290 = 0;
  uStack_288 = 1;
  auStack_280 = ZEXT816(0);
  aiStack_2a8[0] = param_2;
  if (param_2 != 0) {
    uStack_288 = 1;
    auStack_280._0_8_ =
         *(longlong **)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
          0x90);
    auStack_280._8_8_ = 0;
    cVar1 = (**(code **)(*(longlong *)auStack_280._0_8_ + 0x1d0))();
    if (cVar1 == '\0') {
      uStack_2b8 = 0;
      uStack_2c0 = 0;
      uStack_2c8 = uStack_2c8 & 0xffffffffffffff00;
      uStack_2d0 = (undefined8 *)CONCAT44(uStack_2d0._4_4_,2);
      uStack_2d8 = CONCAT44(uStack_2d8._4_4_,1);
      (**(code **)(*(longlong *)auStack_280._0_8_ + 8))(auStack_280._0_8_,0x1a4de60,9,1);
      uStack_290 = CONCAT44(uStack_290._4_4_,2);
    }
    else {
      (**(code **)(*(longlong *)auStack_280._0_8_ + 0xe8))
                (auStack_280._0_8_,1,1,(longlong)&uStack_290 + 4);
      uStack_288 = 1;
      uStack_290 = CONCAT44(uStack_290._4_4_,4);
    }
    iVar2 = func_0x(param_1,0x1a4de20);
    if (iVar2 != 0) {
      uStack_128 = (**(code **)(*(longlong *)auStack_280._0_8_ + 0x1b0))();
      lStack_138 = 0;
      auStack_118 = ZEXT816(0);
      auStack_108 = ZEXT816(0);
      auStack_f8 = ZEXT816(0);
      auStack_e8 = ZEXT816(0);
      lStack_d8 = 0;
      uStack_d0 = 0;
      uStack_c8 = 0;
      uStack_c0 = 0;
      uStack_130 = param_1;
      iStack_120 = iVar2;
      iVar2 = func_0x(&lStack_138,3,1);
      if (iVar2 == 0) {
        *param_3 = 0;
        func_0x(&lStack_138);
      }
      else {
        auStack_2a0[0] = 4;
        auStack_180._0_4_ = func_0x(&lStack_138,0x1850730,auStack_2a0);
        auStack_1a0 = ZEXT816(0);
        auStack_190 = ZEXT816(0);
        auStack_180._4_12_ = SUB1612(ZEXT816(0),4);
        uStack_218 = 0;
        auStack_228 = ZEXT416(auStack_2a0[0]) << 0x40;
        auStack_258 = ZEXT816(0);
        auStack_268 = ZEXT416((uint)auStack_180._0_4_);
        auStack_238._0_12_ = ZEXT412(1) << 0x40;
        auStack_238._12_4_ = 0;
        auStack_248._8_8_ = 0;
        auStack_248._0_8_ = auStack_1a0;
        uStack_2c8 = 0;
        uStack_2d0 = &uStack_c0;
        uStack_2d8 = 0;
        (**(code **)(*(longlong *)auStack_108._8_8_ + 0x20))(auStack_108._8_8_,2,1,auStack_268);
        uStack_2c8 = uStack_2c8 & 0xffffffff00000000;
        uStack_2d0 = (undefined8 *)aiStack_2a8;
        uStack_2d8 = 1;
        (**(code **)(*(longlong *)auStack_f8._8_8_ + 0x28))
                  (auStack_f8._8_8_,uStack_c0,1,aiStack_2a8);
        *param_3 = 0;
        uStack_2d0 = (undefined8 *)lStack_138;
        uStack_2d8 = uStack_c8;
        iVar2 = (**(code **)(*(longlong *)auStack_118._8_8_ + 0x18))(auStack_118._8_8_,0,1,0);
        if (iVar2 == 0) {
          uStack_270 = 0;
          if (lStack_138 != 0) {
            uVar3 = func_0x(&lStack_138,0x17e8be0,&uStack_270);
            uVar5 = (ulonglong)uVar3;
            if ((ulonglong)uVar3 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_d8)) {
LAB_:
              pbVar4 = (byte *)0x0;
              if (uVar3 <= uStack_d0) {
                pbVar4 = (byte *)(lStack_138 +
                                 *(longlong *)((ulonglong)(uVar3 - 1) * 0x58 + 8 + lStack_d8));
              }
            }
            else {
              uVar3 = 1;
              if (uStack_d0 != 0) {
                do {
                  if (uVar5 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_d8))
                  goto LAB_;
                  uVar3 = uVar3 + 1;
                } while (uVar3 <= uStack_d0);
              }
            }
          }
          if ((*pbVar4 & 1) != 0) {
            *param_3 = 1;
          }
        }
        else {
          iVar2 = func_0x(param_1,0x1a4dde8);
          if (iVar2 == 0) {
            func_0x(0x4977,0x10,1,0x1a4dde8);
          }
          else {
            uStack_a8 = (**(code **)(*(longlong *)auStack_280._0_8_ + 0x1b0))();
            lStack_b8 = 0;
            auStack_98 = ZEXT816(0);
            auStack_88 = ZEXT816(0);
            auStack_78 = ZEXT816(0);
            auStack_68 = ZEXT816(0);
            lStack_58 = 0;
            uStack_50 = 0;
            uStack_48 = 0;
            uStack_40 = 0;
            uStack_b0 = param_1;
            iStack_a0 = iVar2;
            iVar2 = func_0x(&lStack_b8,3,1);
            if (iVar2 == 0) {
              func_0x(0x49aa,0x10,1,0x1a4dde8);
            }
            else {
              auStack_298[0] = 4;
              auStack_150._0_4_ = func_0x(&lStack_b8,0x1850730,auStack_298);
              auStack_170 = ZEXT816(0);
              auStack_160 = ZEXT816(0);
              auStack_150._4_12_ = SUB1612(ZEXT816(0),4);
              uStack_1b8 = 0;
              auStack_1c8 = ZEXT416(auStack_298[0]) << 0x40;
              auStack_1f8 = ZEXT816(0);
              auStack_208 = ZEXT416((uint)auStack_150._0_4_);
              auStack_1d8._0_12_ = ZEXT412(1) << 0x40;
              auStack_1d8._12_4_ = 0;
              auStack_1e8._8_8_ = 0;
              auStack_1e8._0_8_ = auStack_170;
              uStack_2c8 = 0;
              uStack_2d0 = &uStack_40;
              uStack_2d8 = 0;
              (**(code **)(*(longlong *)auStack_88._8_8_ + 0x20))(auStack_88._8_8_,2,1,auStack_208);
              uStack_2c8 = uStack_2c8 & 0xffffffff00000000;
              uStack_2d0 = (undefined8 *)aiStack_2a8;
              uStack_2d8 = 1;
              (**(code **)(*(longlong *)auStack_78._8_8_ + 0x28))
                        (auStack_78._8_8_,uStack_40,1,aiStack_2a8);
              *param_3 = 0;
              uStack_2d0 = (undefined8 *)lStack_b8;
              uStack_2d8 = uStack_48;
              iVar2 = (**(code **)(*(longlong *)auStack_98._8_8_ + 0x18))(auStack_98._8_8_,0,1,0);
              if (iVar2 == 0) {
                uStack_26c = 0;
                if (lStack_b8 != 0) {
                  uVar3 = func_0x(&lStack_b8,0x17e8be0,&uStack_26c);
                  uVar5 = (ulonglong)uVar3;
                  if ((ulonglong)uVar3 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_58))
                  {
LAB_:
                    pbVar4 = (byte *)0x0;
                    if (uVar3 <= uStack_50) {
                      pbVar4 = (byte *)(lStack_b8 +
                                       *(longlong *)((ulonglong)(uVar3 - 1) * 0x58 + 8 + lStack_58))
                      ;
                    }
                  }
                  else {
                    uVar3 = 1;
                    if (uStack_50 != 0) {
                      do {
                        if (uVar5 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_58))
                        goto LAB_;
                        uVar3 = uVar3 + 1;
                      } while (uVar3 <= uStack_50);
                    }
                  }
                }
                if ((*pbVar4 & 1) != 0) {
                  *param_3 = 1;
                }
              }
            }
            func_0x(&lStack_b8);
          }
        }
        func_0x(&lStack_138);
        func_0x(&uStack_290,0);
      }
      goto LAB_;
    }
  }
  *param_3 = 0;
LAB_:
  if ((int)uStack_290 != 0) {
    func_0x(&uStack_290,0);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_2f8);
  return;
}

