
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ushort *param_1,uint *param_2,int param_3)

{
  byte bVar1;
  ushort uVar2;
  ulonglong *puVar3;
  longlong lVar4;
  uint uVar5;
  ushort uVar6;
  int iVar7;
  byte *pbVar8;
  ulonglong uVar10;
  uint uVar11;
  ushort uVar12;
  uint uVar13;
  ushort uVar14;
  ushort *puVar15;
  longlong lVar16;
  longlong unaff_GS_OFFSET;
  ulonglong uVar9;
  
  uVar11 = 0;
  iVar7 = 0;
  if (*(int *)(param_1 + 1) == 0) {
    pbVar8 = *(byte **)(param_1 + 3);
    uVar13 = *(uint *)(param_1 + 7);
    uVar9 = (ulonglong)uVar13;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar13;
    bVar1 = *pbVar8;
    if ((bVar1 & 0x10) != 0) {
      uVar13 = uVar13 + 2 + (*(ushort *)(pbVar8 + uVar9) + 7 >> 3);
      uVar9 = (ulonglong)uVar13;
      *(uint *)(param_1 + 9) = uVar13;
      bVar1 = *pbVar8;
    }
    if ((bVar1 & 0x20) == 0) {
      *(int *)(param_1 + 1) = (int)uVar9;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = (int)uVar9;
    }
    else {
      puVar15 = (ushort *)(pbVar8 + uVar9);
      uVar2 = *puVar15;
      param_1[0xd] = uVar2;
      if (uVar2 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar4 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar4 != 0)) &&
           ((lVar4 = *(longlong *)(lVar4 + 0x60), lVar4 != 0 && (*(char *)(lVar4 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9ea828,0xb0a4f8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar9 = (ulonglong)*(uint *)(param_1 + 9);
        uVar2 = param_1[0xd];
      }
      uVar13 = (int)uVar9 + (uVar2 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar13;
      if (0x1f9e < uVar13) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar4 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar4 != 0 &&
            ((lVar4 = *(longlong *)(lVar4 + 0x60), lVar4 != 0 && (*(char *)(lVar4 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ea828,0xb0a4f8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar2 = param_1[0xd];
        uVar13 = *(uint *)(param_1 + 0xb);
      }
      uVar9 = (ulonglong)uVar2;
      uVar2 = puVar15[uVar9];
      *(uint *)(param_1 + 1) = uVar2 & 0x7fff;
      if ((uVar2 & 0x7fff) < uVar13) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar4 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar4 != 0)) &&
           ((lVar4 = *(longlong *)(lVar4 + 0x60), lVar4 != 0 && (*(char *)(lVar4 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ea828,0xb0a4f8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar9 = (ulonglong)param_1[0xd];
      }
      if ((short)puVar15[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
        lVar4 = *(longlong *)(param_1 + 3);
        do {
          if ((int)uVar9 == 1) {
            uVar13 = *(uint *)(param_1 + 0xb);
            uVar5 = uVar13;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar4 + uVar9 * 2) & 0x7fff) <
                uVar13) goto LAB_;
          }
          else {
            uVar5 = *(uint *)(param_1 + 0xb);
            uVar13 = *(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar4 + -2 + uVar9 * 2) &
                     0x7fff;
            if (uVar5 <= uVar13) goto LAB_;
LAB_:
            func_0x(lVar4,7);
            uVar5 = *(uint *)(param_1 + 0xb);
          }
          if ((uVar13 < uVar5) || (*(uint *)(param_1 + 1) < uVar13)) goto LAB_;
          lVar4 = *(longlong *)(param_1 + 3);
          if (*(ushort *)((ulonglong)uVar13 + lVar4) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = param_1[0xd] - 1;
            param_1[0x14] = (ushort)uVar13;
            lVar4 = (ulonglong)(uVar13 & 0xffff) + *(longlong *)(param_1 + 3);
            uVar2 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(lVar4 + 2) & 0x4000) != 0) {
              uVar2 = *(ushort *)(lVar4 + 2) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar2;
            param_1[0x15] = (uVar2 ^ *(ushort *)(lVar4 + 2)) & 0x7ff ^ uVar2;
            uVar9 = (ulonglong)*(uint *)(param_1 + 1);
            pbVar8 = *(byte **)(param_1 + 3);
            goto LAB_;
          }
          if (*(ushort *)((ulonglong)uVar13 + lVar4) < 0x400) break;
          *param_1 = *param_1 | 1;
          uVar2 = param_1[0xd] - 1;
          param_1[0xd] = uVar2;
          if ((uVar2 == 0) ||
             (uVar9 = (ulonglong)uVar2, -1 < (short)puVar15[(ulonglong)(uVar2 - 1) + 1])) break;
        } while( true );
      }
      uVar9 = (ulonglong)*(uint *)(param_1 + 1);
      pbVar8 = *(byte **)(param_1 + 3);
    }
LAB_:
    if ((*pbVar8 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar9;
      *(int *)(param_1 + 1) = (int)uVar9 + 0xe;
      puVar3 = (ulonglong *)func_0x(param_1);
      uVar9 = *puVar3;
      uVar12 = (ushort)(uVar9 >> 0x30);
      uVar2 = uVar12;
      if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
        uVar2 = uVar12 & 0xdfff;
        if ((uVar9 & 0x4000000000000000) != 0) {
          uVar2 = uVar12 | 0x2000;
        }
      }
      if (uVar2 == 0xfffc) {
        iVar7 = (int)((uVar9 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar7;
      uVar9 = (ulonglong)*(uint *)(param_1 + 1);
    }
    iVar7 = (int)uVar9;
    if ((*(ulonglong *)(param_1 + 0xe) != 0) &&
       (*(ulonglong *)(param_1 + 0xe) < uVar9 + *(longlong *)(param_1 + 3))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar4 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar4 != 0 &&
           (lVar4 = *(longlong *)(lVar4 + 0x60), lVar4 != 0)) && (*(char *)(lVar4 + 0x499) != '\0'))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9ea828,0xb0a4f8,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      iVar7 = *(int *)(param_1 + 1);
    }
    if (0x3f3b < iVar7 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar4 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar4 != 0 &&
          ((lVar4 = *(longlong *)(lVar4 + 0x60), lVar4 != 0 && (*(char *)(lVar4 + 0x499) != '\0'))))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9ea828,0xb0a4f8,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
    }
  }
LAB_:
  uVar13 = *param_2;
  if ((uVar13 & 0xc0000000) != 0x80000000) {
    uVar13 = ~uVar13;
    puVar15 = (ushort *)((ulonglong)*(uint *)(param_1 + 9) + *(longlong *)(param_1 + 3));
    if (*puVar15 <= uVar13) {
      return;
    }
    if (param_3 != 0) {
      puVar15[(ulonglong)uVar13 + 1] = puVar15[(ulonglong)uVar13 + 1] | 0x8000;
      return;
    }
    puVar15[(ulonglong)uVar13 + 1] = puVar15[(ulonglong)uVar13 + 1] & 0x7fff;
    return;
  }
  uVar2 = param_1[0x15];
  uVar9 = (ulonglong)param_1[0x14];
  lVar16 = *(longlong *)(param_1 + 3);
  uVar14 = (ushort)(uVar13 >> 0x10) & 7;
  lVar4 = uVar9 + lVar16;
  uVar12 = uVar2 >> 0xb & 7;
  if (uVar12 == 0) {
    uVar12 = uVar2;
    if (uVar14 != (*(ushort *)(lVar4 + 2) >> 0xb & 7)) {
      return;
    }
    goto LAB_;
  }
  uVar9 = 0;
  uVar6 = 0;
  if (uVar12 == 0) {
LAB_:
    if (uVar14 < (*(ushort *)(lVar4 + 4) >> 0xb & 7)) {
      return;
    }
  }
  else {
    do {
      uVar6 = (ushort)uVar9;
      if (uVar14 <= (*(ushort *)(lVar4 + 4 + uVar9 * 2) >> 0xb & 7)) break;
      uVar6 = uVar6 + 1;
      uVar9 = (ulonglong)uVar6;
    } while (uVar6 < uVar12);
    if (uVar6 == 0) goto LAB_;
  }
  if (uVar12 <= uVar6) {
    return;
  }
  if (uVar6 != 0) {
    uVar11 = *(ushort *)(lVar4 + 2 + (ulonglong)uVar6 * 2) & 0x7ff;
  }
  uVar2 = param_1[0x15];
  lVar16 = *(longlong *)(param_1 + 3);
  uVar9 = (ulonglong)param_1[0x14];
  uVar12 = *(ushort *)(lVar4 + 4 + (ulonglong)uVar6 * 2);
LAB_:
  uVar10 = (ulonglong)((uVar2 >> 0xb & 7) * 2);
  iVar7 = (uVar12 & 0x7ff) - 1;
  do {
    uVar5 = (int)(uVar11 + iVar7) >> 1;
    uVar12 = *(ushort *)(lVar16 + uVar9 + uVar10 + 4 + (longlong)(int)uVar5 * 2);
    if (uVar12 < (ushort)uVar13) {
      uVar11 = uVar5 + 1;
    }
    else {
      if (uVar12 <= (ushort)uVar13) {
        lVar4 = (ulonglong)((uVar2 & 0x7ff) * 2) + lVar16 + ((ulonglong)uVar5 + 2) * 2 + uVar10;
        if (param_3 != 0) {
          puVar15 = (ushort *)(lVar4 + uVar9);
          *puVar15 = *puVar15 | 0x8000;
          return;
        }
        puVar15 = (ushort *)(lVar4 + uVar9);
        *puVar15 = *puVar15 & 0x7fff;
        return;
      }
      iVar7 = uVar5 - 1;
    }
  } while ((int)uVar11 <= iVar7);
  return;
}

