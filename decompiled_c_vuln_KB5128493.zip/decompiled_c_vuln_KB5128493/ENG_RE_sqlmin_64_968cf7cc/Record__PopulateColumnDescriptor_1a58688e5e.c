
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,undefined4 param_2,uint *param_3,undefined4 *param_4)

{
  byte **ppbVar1;
  byte bVar2;
  ushort uVar3;
  ushort uVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  ulonglong *puVar8;
  uint uVar9;
  short sVar10;
  uint uVar11;
  ulonglong uVar12;
  uint uVar13;
  byte *pbVar14;
  ushort *puVar15;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  int aiStackX_10 [2];
  undefined4 auStackX_18 [2];
  int aiStackX_20 [2];
  undefined auStack_58 [4];
  undefined auStack_54 [20];
  
  sVar10 = *(short *)(param_3 + 1);
  *(undefined4 *)((longlong)param_4 + 6) = 0;
  *param_4 = param_2;
  aiStackX_10[0] = 0;
  if (*param_1 != 0) {
    if (*param_1 != 1) {
      (*_DAT_)(1,0xb74ca0,0xb7b098,0x362,0x76fe48);
      return;
    }
    auStackX_8[0] = 0;
    auStackX_18[0] = 0;
    func_0x(param_1 + 1,param_3,param_3,aiStackX_10,auStackX_8);
    *(undefined2 *)(param_4 + 1) = (undefined2)aiStackX_10[0];
    if ((auStackX_8[0] & 1) != 0) {
      *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 1;
    }
    if ((auStackX_8[0] & 0x10) != 0) {
      *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 2;
    }
    if ((auStackX_8[0] & 4) != 0) {
      *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 4;
    }
    if (*param_1 == 0) {
      return;
    }
    ppbVar1 = *(byte ***)(param_1 + 8);
    if (ppbVar1 == (byte **)0x0) {
      return;
    }
    if ((**ppbVar1 & 2) == 0) {
      return;
    }
    lVar7 = func_0x(ppbVar1,param_3,auStackX_18);
    if (lVar7 == 0) {
      return;
    }
    *(undefined2 *)(param_4 + 2) = (undefined2)auStackX_18[0];
    return;
  }
  uVar11 = *param_3;
  if ((uVar11 & 0xc0000000) == 0x80000000) {
    iVar5 = func_0x(param_1 + 1);
    iVar6 = aiStackX_10[0];
    if (iVar5 != 0) {
      func_0x(param_1 + 0x15,param_3,aiStackX_10,auStack_58);
      iVar6 = aiStackX_10[0];
    }
  }
  else {
    uVar3 = 1;
    if ((sVar10 != 0) || ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0)) {
      pbVar14 = *(byte **)(param_1 + 4);
      if ((*pbVar14 & 0x10) == 0) {
        uVar3 = 1;
        uVar4 = 0;
        if ((1 << (*pbVar14 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
        if (sVar10 != 0) goto LAB_;
      }
      else {
        uVar13 = *(uint *)(param_1 + 8);
        if ((int)uVar13 <= (int)uVar11) {
LAB_:
          uVar4 = ~(*(ushort *)((longlong)param_3 + 6) >> 4) & 1;
          uVar3 = 0;
          goto LAB_;
        }
        if ((uint)*(ushort *)(pbVar14 + uVar13) < (uint)*(ushort *)(param_3 + 1)) goto LAB_;
        if (sVar10 == 0) goto LAB_;
        uVar9 = *(ushort *)(param_3 + 1) - 1;
        uVar4 = pbVar14[(ulonglong)uVar13 + (ulonglong)(uVar9 >> 3) + 2] >> ((byte)uVar9 & 7) & 1;
LAB_:
        iVar6 = aiStackX_10[0];
        if (uVar4 != 0) goto LAB_;
      }
      if ((uVar3 == 0) && ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0)) {
        iVar6 = **(int **)(param_3 + 2);
        goto LAB_;
      }
    }
LAB_:
    if ((int)uVar11 < 0) {
      if (*(int *)(param_1 + 2) == 0) {
        pbVar14 = *(byte **)(param_1 + 4);
        uVar11 = *(uint *)(param_1 + 8);
        uVar12 = (ulonglong)uVar11;
        param_1[1] = 0;
        *(uint *)(param_1 + 10) = uVar11;
        bVar2 = *pbVar14;
        if ((bVar2 & 0x10) != 0) {
          uVar11 = uVar11 + 2 + (*(ushort *)(pbVar14 + uVar12) + 7 >> 3);
          uVar12 = (ulonglong)uVar11;
          *(uint *)(param_1 + 10) = uVar11;
          bVar2 = *pbVar14;
        }
        if ((bVar2 & 0x20) == 0) {
          *(int *)(param_1 + 2) = (int)uVar12;
          param_1[0xe] = 0;
          *(int *)(param_1 + 0xc) = (int)uVar12;
        }
        else {
          puVar15 = (ushort *)(pbVar14 + uVar12);
          uVar3 = *puVar15;
          param_1[0xe] = uVar3;
          if (uVar3 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar7 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar7 != 0)) &&
               ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                (*(char *)(lVar7 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x9f3968,0xb13638,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),3);
            uVar12 = (ulonglong)*(uint *)(param_1 + 10);
            uVar3 = param_1[0xe];
          }
          uVar11 = (int)uVar12 + (uVar3 + 1) * 2;
          *(uint *)(param_1 + 0xc) = uVar11;
          if (0x1f9e < uVar11) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar7 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar7 != 0 &&
                ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                 (*(char *)(lVar7 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9f3968,0xb13638,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
            uVar3 = param_1[0xe];
            uVar11 = *(uint *)(param_1 + 0xc);
          }
          uVar12 = (ulonglong)uVar3;
          uVar3 = puVar15[uVar12];
          *(uint *)(param_1 + 2) = uVar3 & 0x7fff;
          if ((uVar3 & 0x7fff) < uVar11) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar7 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar7 != 0)) &&
               ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                (*(char *)(lVar7 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9f3968,0xb13638,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
            uVar12 = (ulonglong)(ushort)param_1[0xe];
          }
          if ((short)puVar15[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
            lVar7 = *(longlong *)(param_1 + 4);
            do {
              if ((int)uVar12 == 1) {
                uVar11 = *(uint *)(param_1 + 0xc);
                uVar13 = uVar11;
LAB_:
                if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar7 + uVar12 * 2) & 0x7fff)
                    < uVar11) goto LAB_;
              }
              else {
                uVar13 = *(uint *)(param_1 + 0xc);
                uVar11 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar7 + -2 + uVar12 * 2) &
                         0x7fff;
                if (uVar13 <= uVar11) goto LAB_;
LAB_:
                func_0x(lVar7,7);
                uVar13 = *(uint *)(param_1 + 0xc);
              }
              if ((uVar11 < uVar13) || (*(uint *)(param_1 + 2) < uVar11)) goto LAB_;
              lVar7 = *(longlong *)(param_1 + 4);
              if (*(ushort *)(lVar7 + (ulonglong)uVar11) == 5) {
                param_1[1] = param_1[1] | 2;
                param_1[0xe] = param_1[0xe] + -1;
                uVar4 = param_1[0x16] & 0xc7ff;
                param_1[0x15] = (short)uVar11;
                lVar7 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(param_1 + 4);
                uVar3 = *(ushort *)(lVar7 + 2);
                if ((uVar3 & 0x4000) != 0) {
                  uVar4 = uVar3 & 0x3800 | uVar4;
                }
                param_1[0x16] = uVar4;
                param_1[0x16] = (uVar4 ^ *(ushort *)(lVar7 + 2)) & 0x7ff ^ uVar4;
                uVar12 = (ulonglong)*(uint *)(param_1 + 2);
                pbVar14 = *(byte **)(param_1 + 4);
                goto LAB_;
              }
              if (*(ushort *)(lVar7 + (ulonglong)uVar11) < 0x400) break;
              param_1[1] = param_1[1] | 1;
              uVar3 = param_1[0xe] - 1;
              param_1[0xe] = uVar3;
              if ((uVar3 == 0) ||
                 (uVar12 = (ulonglong)uVar3, -1 < (short)puVar15[(ulonglong)(uVar3 - 1) + 1]))
              break;
            } while( true );
          }
          uVar12 = (ulonglong)*(uint *)(param_1 + 2);
          pbVar14 = *(byte **)(param_1 + 4);
        }
LAB_:
        if ((*pbVar14 & 0x40) == 0) {
          *(undefined4 *)(param_1 + 0x13) = 0;
        }
        else {
          *(int *)(param_1 + 0x13) = *(int *)(param_1 + 2);
          *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + 0xe;
          puVar8 = (ulonglong *)func_0x(param_1 + 1);
          iVar6 = 0;
          uVar12 = *puVar8;
          uVar3 = (ushort)(uVar12 >> 0x30);
          if ((((uint)(int)(short)uVar3 >> 1 ^ (int)(short)uVar3) & 0x2000) != 0) {
            if ((uVar12 & 0x4000000000000000) == 0) {
              uVar3 = uVar3 & 0xdfff;
            }
            else {
              uVar3 = uVar3 | 0x2000;
            }
          }
          if (uVar3 == 0xfffc) {
            iVar6 = (int)((uVar12 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar6;
          uVar12 = (ulonglong)*(uint *)(param_1 + 2);
        }
        iVar6 = (int)uVar12;
        if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
           (*(ulonglong *)(param_1 + 0xf) < uVar12 + *(longlong *)(param_1 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar7 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar7 != 0 &&
               (lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0)) &&
              (*(char *)(lVar7 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x9f3968,0xb13638,0x877,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),0x12);
          iVar6 = *(int *)(param_1 + 2);
        }
        if (0x3f3b < iVar6 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar7 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar7 != 0 &&
              ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
               (*(char *)(lVar7 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x9f3968,0xb13638,0x87c,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),5);
        }
      }
LAB_:
      sVar10 = -*(short *)param_3;
      if ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0) {
        bVar2 = **(byte **)(param_1 + 4);
        if ((bVar2 & 0x10) == 0) {
          if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
LAB_:
            iVar6 = **(int **)(param_3 + 2);
            goto LAB_;
          }
        }
        else if (((int)*(uint *)(param_1 + 8) <= (int)*param_3) ||
                (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
                 *(ushort *)(param_3 + 1))) goto LAB_;
      }
      iVar6 = aiStackX_10[0];
      if ((uint)(int)sVar10 <= (uint)(ushort)param_1[0xe]) {
        lVar7 = (ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4);
        uVar11 = *(ushort *)(lVar7 + (longlong)sVar10 * 2) & 0x7fff;
        if (sVar10 == 1) {
          uVar13 = *(uint *)(param_1 + 0xc);
LAB_:
          if (uVar11 < uVar13) goto LAB_;
        }
        else {
          uVar13 = *(ushort *)(lVar7 + -2 + (longlong)sVar10 * 2) & 0x7fff;
          if (*(uint *)(param_1 + 0xc) <= uVar13) goto LAB_;
LAB_:
          func_0x(*(longlong *)(param_1 + 4),7);
        }
        iVar6 = uVar11 - uVar13;
      }
    }
    else if ((*(ushort *)((longlong)param_3 + 6) & 8) == 0) {
      if ((*(ushort *)((longlong)param_3 + 6) & 0x10) != 0) {
        bVar2 = **(byte **)(param_1 + 4);
        if ((bVar2 & 0x10) == 0) {
          if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
LAB_:
            iVar6 = **(int **)(param_3 + 2);
            if (iVar6 != 0x1f9e) {
              (*_DAT_)(1,0xba16d8,0xba00d8,0x381,0);
            }
            goto LAB_;
          }
        }
        else if (((int)*(uint *)(param_1 + 8) <= (int)uVar11) ||
                (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
                 *(ushort *)(param_3 + 1))) goto LAB_;
      }
      aiStackX_10[0] = 0x1f9e;
      iVar6 = aiStackX_10[0];
    }
    else {
      aiStackX_10[0] = 1;
      iVar6 = aiStackX_10[0];
    }
  }
LAB_:
  aiStackX_10[0] = iVar6;
  *(undefined2 *)(param_4 + 1) = (undefined2)aiStackX_10[0];
  uVar11 = *param_3;
  aiStackX_20[0] = 0;
  if ((uVar11 & 0xc0000000) == 0x80000000) {
    iVar6 = func_0x(param_1 + 1);
    if ((iVar6 == 0) ||
       (func_0x(param_1 + 0x15,param_3,auStack_54,aiStackX_20), aiStackX_20[0] == 0))
    goto LAB_;
  }
  else {
    if ((-1 < (int)uVar11) ||
       (((**(byte **)(param_1 + 4) & 0x20) == 0 ||
        (iVar6 = func_0x(param_1 + 1), iVar6 < (int)-uVar11)))) goto LAB_;
    if (((uint)*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4)) <=
         ~uVar11) ||
       (-1 < (short)((ushort *)((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4)))
                    [(ulonglong)~uVar11 + 1])) goto LAB_;
  }
  *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 1;
LAB_:
  if ((*param_3 & 0xc0000000) == 0x80000000) {
    *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 2;
  }
  return;
}

