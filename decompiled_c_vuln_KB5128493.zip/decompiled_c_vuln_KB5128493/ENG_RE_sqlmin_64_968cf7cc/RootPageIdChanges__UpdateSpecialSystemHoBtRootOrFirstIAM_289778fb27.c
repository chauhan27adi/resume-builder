
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,longlong param_3)

{
  byte bVar1;
  ushort uVar2;
  undefined4 uVar3;
  longlong **pplVar4;
  char cVar5;
  int iVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  ushort *puVar10;
  longlong lVar11;
  undefined8 uVar12;
  ulonglong uVar13;
  short *psVar14;
  uint uVar15;
  undefined2 *puVar16;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong *plVar17;
  undefined8 *puVar18;
  longlong lVar19;
  ulonglong uVar20;
  uint *puVar21;
  byte **ppbVar22;
  byte *pbVar23;
  ushort uVar24;
  undefined2 uVar25;
  short sVar26;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [2];
  longlong *plStackX_10;
  char acStackX_18 [8];
  int aiStackX_20 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  *(undefined8 *)(&stack0x00000698 + lVar7) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002ac8 + lVar7) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar7);
  *(longlong *)(&stack0x00000338 + lVar7) = param_3;
  *(longlong *)(&stack0x00000378 + lVar7) = param_2;
  *(undefined8 *)(&stack0x00000388 + lVar7) = param_1;
  *(undefined (*) [16])(&stack0x00000288 + lVar7) = ZEXT816(0);
  plVar9 = (longlong *)0x0;
  *(undefined4 *)(&stack0x00000298 + lVar7) = 0;
  *(undefined4 *)(&stack0x000000b8 + lVar7) = 0;
  *(undefined2 *)(&stack0x000009d0 + lVar7) = 0xffff;
  *(undefined8 *)(&stack0x000009d8 + lVar7) = 0;
  *(undefined4 *)(&stack0x000009d4 + lVar7) = 0;
  *(undefined8 *)(&stack0x000009ee + lVar7) = 0;
  *(undefined8 *)(&stack0x000009f8 + lVar7) = 0;
  *(undefined8 *)(&stack0x000009e0 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000a04 + lVar7) = 0xffffffff;
  *(undefined4 *)((longlong)auStackX_8 + lVar7) = 0;
  *(undefined4 *)(&stack0x000000bc + lVar7) = 1;
  uVar25 = *(undefined2 *)(param_3 + 0x3c4);
  *(undefined4 *)(&stack0x000000d0 + lVar7) = *(undefined4 *)(param_3 + 0x3c0);
  *(undefined2 *)(&stack0x000000d4 + lVar7) = uVar25;
  *(undefined2 *)(&stack0x000000d6 + lVar7) = 0;
  lVar19 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar11 = *(longlong *)(lVar19 + 0x100);
  if (lVar11 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100116;
    (*_DAT_)(0);
    lVar11 = *(longlong *)(lVar19 + 0x100);
  }
  *(undefined8 *)(&stack0x000002a0 + lVar7) = *(undefined8 *)(lVar11 + 1000);
  *(longlong *)(&stack0x000002a8 + lVar7) = param_2;
  *(undefined8 *)(&stack0x000002b0 + lVar7) = 0;
  (&stack0x000002b8)[lVar7] = 0;
  if ((*(int *)(&stack0x000000d0 + lVar7) != 0) ||
     (plVar17 = plVar9, *(short *)(&stack0x000000d4 + lVar7) != 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10016a;
    plVar8 = (longlong *)func_0x(&stack0x000002a0 + lVar7);
    *(longlong **)(&stack0x000006a0 + lVar7) = plVar8;
    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar8 + 0x18);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10018a;
    lVar11 = (*UNRECOVERED_JUMPTABLE_00)(plVar8,&stack0x000000d0 + lVar7,0);
    plVar17 = (longlong *)(lVar11 + 8);
    if (lVar11 == 0) {
      plVar17 = plVar9;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1001a3;
    lVar11 = func_0x(&stack0x000002a0 + lVar7,plVar17);
    plVar17 = (longlong *)(lVar11 + -8);
    if (lVar11 == 0) {
      plVar17 = plVar9;
    }
    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar8 + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1001bb;
    (*UNRECOVERED_JUMPTABLE_00)(plVar8,1);
  }
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar17 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1001cc;
  (*UNRECOVERED_JUMPTABLE_00)(plVar17,&stack0x00000a80 + lVar7);
  *(undefined4 *)(&stack0x0000004c + lVar7) = *(undefined4 *)(&stack0x00000a82 + lVar7);
  *(undefined2 *)(&stack0x00000050 + lVar7) = *(undefined2 *)(&stack0x00000a86 + lVar7);
  *(undefined4 *)(&stack0x000001b0 + lVar7) = 0x654;
  lVar19 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar11 = *(longlong *)(lVar19 + 0x100);
  if (lVar11 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100228;
    (*_DAT_)(0);
    lVar11 = *(longlong *)(lVar19 + 0x100);
  }
  uVar12 = *(undefined8 *)(lVar11 + 1000);
  *(undefined8 *)(&stack0x00000270 + lVar7) = uVar12;
  (&stack0xffffffffffffffe8)[lVar7] = 5;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10025b;
  plVar8 = (longlong *)(*_DAT_)(0x18,uVar12,0x10fadd8,0x654);
  *(longlong **)(&stack0x00000208 + lVar7) = plVar8;
  plVar17 = plVar9;
  if (plVar8 != (longlong *)0x0) {
    *plVar8 = 0;
    *(undefined *)(plVar8 + 1) = 0;
    *(undefined4 *)((longlong)plVar8 + 0xc) = 0;
    plVar17 = plVar8;
  }
  *(longlong **)((longlong)&plStackX_10 + lVar7) = plVar17;
  lVar11 = *(longlong *)(param_2 + 0x30);
  *(longlong *)(&stack0x00000038 + lVar7) = lVar11;
  *(undefined4 *)(&stack0x000006fc + lVar7) = 0;
  *(undefined4 *)(&stack0x00000700 + lVar7) = 0;
  cVar5 = *_DAT_;
  (&stack0x000000c8)[lVar7] = cVar5;
  if ((cVar5 == '\0') || ((&stack0x000000c9)[lVar7] = DAT_ >> 7, (char)DAT_ < '\0'))
  goto LAB_;
  *(undefined4 *)(&stack0x000001e8 + lVar7) = 0;
  lVar11 = *(longlong *)(unaff_GS_OFFSET + 0x58);
  *(longlong *)(&stack0x000006a8 + lVar7) = lVar11;
  plVar17 = (longlong *)
            ((ulonglong)*_DAT_ + *(longlong *)(lVar11 + (ulonglong)*_DAT_ * 8));
  *(longlong **)(&stack0x000006b0 + lVar7) = plVar17;
  lVar11 = *plVar17;
  *(longlong *)(&stack0x000006b8 + lVar7) = lVar11;
  if (lVar11 == 0) {
LAB_:
    *(undefined8 *)(&stack0x00000320 + lVar7) = 0;
  }
  else {
    lVar11 = **(longlong **)(lVar11 + 0x38);
    *(longlong *)(&stack0x000006c0 + lVar7) = lVar11;
    if (lVar11 == 0) goto LAB_;
    *(longlong *)(&stack0x00000320 + lVar7) = lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10033a;
    iVar6 = (*_DAT_)(lVar11,0x337);
    *(int *)(&stack0x000001e8 + lVar7) = iVar6;
    if (iVar6 != 0) {
      lVar11 = *(longlong *)(&stack0x00000038 + lVar7);
      goto LAB_;
    }
  }
  lVar11 = *(longlong *)(unaff_GS_OFFSET + 0x58);
  *(longlong *)(&stack0x000006c8 + lVar7) = lVar11;
  lVar11 = (ulonglong)*_DAT_ + *(longlong *)(lVar11 + (ulonglong)*_DAT_ * 8);
  *(longlong *)(&stack0x000006d0 + lVar7) = lVar11;
  lVar19 = *(longlong *)(lVar11 + 8);
  *(longlong *)(&stack0x000006d8 + lVar7) = lVar19;
  lVar11 = *(longlong *)(&stack0x00000038 + lVar7);
  if (lVar19 != 0) {
    plVar9 = *(longlong **)(lVar19 + 0x60);
  }
LAB_:
  *(longlong **)(&stack0x00000130 + lVar7) = plVar9;
  plVar9 = (longlong *)(lVar11 + 0x728);
  *(longlong *)(&stack0x00000270 + lVar7) = *plVar9;
  *(undefined **)(&stack0x00000208 + lVar7) = &stack0x000006f8 + lVar7;
  do {
    *(undefined4 *)(&stack0x000000a4 + lVar7) = 0;
    if (**(longlong **)((longlong)&plStackX_10 + lVar7) != 0) {
      puVar10 = (ushort *)(**(longlong **)((longlong)&plStackX_10 + lVar7) + 0x62);
      *(ushort **)(&stack0x000006e0 + lVar7) = puVar10;
      uVar2 = *puVar10;
      *(ushort *)(&stack0x000000c0 + lVar7) = uVar2;
      if (((uVar2 & 0x400) == 0) ||
         (*(short *)(*(longlong *)((longlong)&plStackX_10 + lVar7) + 0xc) < 3)) {
        plVar17 = *(longlong **)((longlong)&plStackX_10 + lVar7);
        *(int *)(&stack0x00000028 + lVar7) = (int)*(short *)((longlong)plVar17 + 0xc);
        lVar11 = *plVar17;
        *(longlong *)(&stack0x000000f8 + lVar7) = lVar11;
        puVar16 = (undefined2 *)(lVar11 + 0x62);
        *(undefined2 **)(&stack0x000006f0 + lVar7) = puVar16;
        uVar25 = *puVar16;
        *(undefined2 *)(&stack0x00000078 + lVar7) = uVar25;
        if (((byte)uVar25 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x00000028 + lVar7) == 3) {
            *(undefined4 *)(&stack0x00000028 + lVar7) = 4;
          }
          else if (*(int *)(&stack0x00000028 + lVar7) < 2) goto LAB_;
          *(uint **)(&stack0x00000710 + lVar7) =
               (uint *)(*(longlong *)(&stack0x000000f8 + lVar7) + 100);
          uVar15 = *(uint *)(*(longlong *)(&stack0x000000f8 + lVar7) + 100);
          *(uint *)(&stack0x000001f0 + lVar7) = uVar15;
          if ((((uVar15 & 8) != 0) &&
              (lVar11 = *(longlong *)(*(longlong *)(&stack0x000000f8 + lVar7) + 0x90), lVar11 != 0))
             && (*(longlong *)(&stack0x000006e8 + lVar7) = lVar11,
                *(longlong *)(lVar11 + 0x758) != 0)) {
            uVar12 = *(undefined8 *)(lVar11 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1004e0;
            func_0x
                      (uVar12,*(undefined8 *)(&stack0x000000f8 + lVar7),
                       *(undefined4 *)(&stack0x00000028 + lVar7));
          }
        }
LAB_:
        (&stack0x000000ca)[lVar7] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar21 = (uint *)(*(longlong *)(&stack0x000000f8 + lVar7) + 100);
          *(uint **)(&stack0x000003e8 + lVar7) = puVar21;
          uVar15 = *puVar21;
          *(uint *)(&stack0x00000218 + lVar7) = uVar15;
          if (((uVar15 & 8) != 0) && (2 < *(int *)(&stack0x00000028 + lVar7))) {
            *(uint **)(&stack0x000003f0 + lVar7) = puVar21;
            uVar15 = *puVar21;
            *(uint *)(&stack0x00000220 + lVar7) = uVar15;
            if (((uVar15 & 0xc0000000) != 0x40000000) &&
               (lVar11 = **(longlong **)(&stack0x000000f8 + lVar7), lVar11 != 0)) {
              *(undefined4 *)(&stack0x00000398 + lVar7) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10056c;
              iVar6 = (*_DAT_)(lVar11,0x2000,2,&stack0x0000039c + lVar7);
              if (iVar6 != 0) {
                LOCK();
                *puVar21 = *puVar21 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar21 = *puVar21 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar11 = *(longlong *)(&stack0x000000f8 + lVar7);
        uVar3 = *(undefined4 *)(&stack0x00000028 + lVar7);
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10059a;
        func_0x(lVar11 + 0x98,uVar3);
        if ((_DAT_ != 0) &&
           ((&stack0x000000a0)[lVar7] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1005c4;
          func_0x(lVar11,0,uVar3);
        }
        *(uint *)((longlong)plVar17 + 0xc) = *(uint *)((longlong)plVar17 + 0xc) & 0xffff0000;
        **(undefined8 **)((longlong)&plStackX_10 + lVar7) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1003d0;
        func_0x(*(longlong *)((longlong)&plStackX_10 + lVar7));
      }
      lVar11 = *(longlong *)(&stack0x00000038 + lVar7);
    }
    if (*plVar9 != 0) {
      plVar17 = *(longlong **)((longlong)&plStackX_10 + lVar7);
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100600;
      func_0x(plVar17,&stack0x0000004c + lVar7,lVar11);
      lVar19 = *plVar17;
      if (lVar19 != 0) {
        puVar10 = (ushort *)(lVar19 + 0x62);
        *(ushort **)(&stack0x000003f8 + lVar7) = puVar10;
        uVar2 = *puVar10;
        *(ushort *)(&stack0x00000080 + lVar7) = uVar2;
        if (((uVar2 & 0x400) == 0) ||
           (*(short *)(*(longlong *)((longlong)&plStackX_10 + lVar7) + 0xc) < 3)) {
          plVar17 = *(longlong **)((longlong)&plStackX_10 + lVar7);
          *(int *)(&stack0x00000030 + lVar7) = (int)*(short *)((longlong)plVar17 + 0xc);
          lVar11 = *plVar17;
          *(longlong *)(&stack0x00000100 + lVar7) = lVar11;
          puVar16 = (undefined2 *)(lVar11 + 0x62);
          *(undefined2 **)(&stack0x00000400 + lVar7) = puVar16;
          uVar25 = *puVar16;
          *(undefined2 *)(&stack0x00000088 + lVar7) = uVar25;
          if (((byte)uVar25 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x00000030 + lVar7) == 3) {
              *(undefined4 *)(&stack0x00000030 + lVar7) = 4;
            }
            else if (*(int *)(&stack0x00000030 + lVar7) < 2) goto LAB_;
            *(uint **)(&stack0x00000408 + lVar7) =
                 (uint *)(*(longlong *)(&stack0x00000100 + lVar7) + 100);
            uVar15 = *(uint *)(*(longlong *)(&stack0x00000100 + lVar7) + 100);
            *(uint *)(&stack0x00000228 + lVar7) = uVar15;
            if ((((uVar15 & 8) != 0) &&
                (lVar11 = *(longlong *)(*(longlong *)(&stack0x00000100 + lVar7) + 0x90), lVar11 != 0
                )) && (*(longlong *)(&stack0x00000410 + lVar7) = lVar11,
                      *(longlong *)(lVar11 + 0x758) != 0)) {
              uVar12 = *(undefined8 *)(lVar11 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1006f3;
              func_0x
                        (uVar12,*(undefined8 *)(&stack0x00000100 + lVar7),
                         *(undefined4 *)(&stack0x00000030 + lVar7));
            }
          }
LAB_:
          (&stack0x000000cb)[lVar7] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar21 = (uint *)(*(longlong *)(&stack0x00000100 + lVar7) + 100);
            *(uint **)(&stack0x00000418 + lVar7) = puVar21;
            uVar15 = *puVar21;
            *(uint *)(&stack0x00000230 + lVar7) = uVar15;
            if (((uVar15 & 8) != 0) && (2 < *(int *)(&stack0x00000030 + lVar7))) {
              *(uint **)(&stack0x00000420 + lVar7) = puVar21;
              uVar15 = *puVar21;
              *(uint *)(&stack0x00000238 + lVar7) = uVar15;
              if (((uVar15 & 0xc0000000) != 0x40000000) &&
                 (lVar11 = **(longlong **)(&stack0x00000100 + lVar7), lVar11 != 0)) {
                *(undefined4 *)(&stack0x000003a0 + lVar7) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10077f;
                iVar6 = (*_DAT_)(lVar11,0x2000,2,&stack0x000003a4 + lVar7);
                if (iVar6 != 0) {
                  LOCK();
                  *puVar21 = *puVar21 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar21 = *puVar21 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar11 = *(longlong *)(&stack0x00000100 + lVar7);
          uVar3 = *(undefined4 *)(&stack0x00000030 + lVar7);
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1007ad;
          func_0x(lVar11 + 0x98,uVar3);
          if ((_DAT_ != 0) &&
             ((&stack0x000000cc)[lVar7] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1007d7;
            func_0x(lVar11,0,uVar3);
          }
          *(uint *)((longlong)plVar17 + 0xc) = *(uint *)((longlong)plVar17 + 0xc) & 0xffff0000;
          **(undefined8 **)((longlong)&plStackX_10 + lVar7) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10063d;
          func_0x(*(longlong *)((longlong)&plStackX_10 + lVar7));
        }
        lVar11 = *(longlong *)(&stack0x00000038 + lVar7);
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1007fb;
    func_0x(lVar11,&stack0x0000004c + lVar7);
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar7) = *(undefined8 *)(&stack0x00000208 + lVar7);
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar7) = 3;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10082f;
    plVar17 = (longlong *)
              func_0x
                        (_DAT_,lVar11,&stack0x0000004c + lVar7,&stack0x000000a4 + lVar7);
    pplVar4 = *(longlong ***)((longlong)&plStackX_10 + lVar7);
    *pplVar4 = plVar17;
    uVar15 = *(uint *)((longlong)pplVar4 + 0xc) & 0xffff0003 | 3;
    *(uint *)((longlong)pplVar4 + 0xc) = uVar15;
    if (*(longlong *)(&stack0x00000130 + lVar7) != 0) {
      lVar19 = *plVar17;
      *(longlong *)(&stack0x00000428 + lVar7) = lVar19;
      plVar8 = (longlong *)(*(longlong *)(&stack0x00000130 + lVar7) + 0x500);
      *(longlong **)(&stack0x00000430 + lVar7) = plVar8;
      plVar17 = plVar8 + (ulonglong)(*(uint *)plVar8 & 0xf) + 1;
      *(longlong **)(&stack0x00000438 + lVar7) = plVar17;
      if (*plVar17 != lVar19) {
        *plVar17 = lVar19;
        *plVar8 = *plVar8 + 1;
        uVar15 = *(uint *)((longlong)pplVar4 + 0xc);
      }
    }
    *(uint *)((longlong)pplVar4 + 0xc) =
         (*(uint *)(&stack0x000000a4 + lVar7) >> 3 & 1) << 0x18 | uVar15 & 0xffffff;
    *(uint *)(*(longlong *)((longlong)&plStackX_10 + lVar7) + 0x10) =
         *(uint *)(&stack0x000000a4 + lVar7) >> 4 & 1 |
         *(uint *)(*(longlong *)((longlong)&plStackX_10 + lVar7) + 0x10) & 0xffffff00;
    lVar19 = *(longlong *)(&stack0x00000270 + lVar7);
    if (((lVar19 != 0) && (*(longlong *)(&stack0x00000130 + lVar7) != 0)) &&
       (*(longlong *)(&stack0x00000130 + lVar7) == *(longlong *)(lVar11 + 0x1c38))) {
      cVar5 = *(char *)((longlong)pplVar4 + 0xf);
      *(int *)(&stack0x000003a8 + lVar7) = (int)cVar5;
      *(longlong *)(&stack0x00000440 + lVar7) = lVar19 + 0x59b8;
      *(longlong *)(lVar19 + 0x5b28) = *(longlong *)(lVar19 + 0x5b28) + 1;
      puVar21 = *(uint **)(&stack0x00000208 + lVar7);
      if (puVar21[1] != 0) {
        *(longlong *)(lVar19 + 0x5b30) = *(longlong *)(lVar19 + 0x5b30) + 1;
        *(longlong *)(lVar19 + 0x5b38) = *(longlong *)(lVar19 + 0x5b38) + (ulonglong)*puVar21;
        if (cVar5 != '\0') {
          *(longlong *)(lVar19 + 0x5b40) = *(longlong *)(lVar19 + 0x5b40) + 1;
          *(longlong *)(lVar19 + 0x5b48) = *(longlong *)(lVar19 + 0x5b48) + (ulonglong)*puVar21;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10094c;
    cVar5 = func_0x(lVar11);
    if ((cVar5 == '\0') || (*(char *)(lVar11 + 0x2050) == '\0')) goto LAB_;
    if (*(int *)(&stack0x0000004c + lVar7) == 0) {
LAB_:
      acStackX_18[lVar7 + 3] = '\x01';
      goto LAB_;
    }
    *(undefined4 *)(&stack0x000001b0 + lVar7) = 9;
    *(undefined2 *)(&stack0x000001b4 + lVar7) = 1;
    if ((*(int *)(&stack0x0000004c + lVar7) == 9) && (*(short *)(&stack0x00000050 + lVar7) == 1))
    goto LAB_;
    acStackX_18[lVar7 + 3] = '\0';
    lVar19 = ***(longlong ***)((longlong)&plStackX_10 + lVar7);
    *(longlong *)(&stack0x00000448 + lVar7) = lVar19;
    acStackX_18[lVar7] = '\0';
    if (*(short *)(lVar19 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000140 + lVar7) = *(undefined8 *)(lVar19 + 0x28);
      *(undefined2 *)(&stack0x00000148 + lVar7) = *(undefined2 *)(lVar19 + 0x30);
    }
    else {
      cVar5 = *(char *)(lVar19 + 1);
      if ((((cVar5 == '\v') || (cVar5 == '\b')) || (cVar5 == '\t')) &&
         (*(int *)(lVar19 + 0x18) == 99)) {
        *(undefined **)(&stack0x00000450 + lVar7) = &stack0x00000170 + lVar7;
        *(undefined4 **)(&stack0x00000458 + lVar7) = (undefined4 *)(lVar19 + 0x20);
        *(undefined4 *)(&stack0x00000170 + lVar7) = *(undefined4 *)(lVar19 + 0x20);
        *(undefined2 *)(&stack0x00000174 + lVar7) = *(undefined2 *)(lVar19 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100a13;
        cVar5 = func_0x(&stack0x00000170 + lVar7);
        if (cVar5 == '\0') goto LAB_;
        cVar5 = '\x01';
      }
      else {
LAB_:
        cVar5 = '\0';
      }
      acStackX_18[lVar7] = cVar5;
      if (cVar5 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100a35;
      func_0x(lVar19,&stack0x00000140 + lVar7);
    }
    *(undefined **)(&stack0x00000460 + lVar7) = &stack0x00000140 + lVar7;
    *(longlong *)(&stack0x00000328 + lVar7) = lVar11 + 0x20fc;
    *(undefined4 *)(&stack0x00000124 + lVar7) = 0;
    *(undefined4 *)(&stack0x00000128 + lVar7) = 0;
    *(undefined2 *)(&stack0x0000012c + lVar7) = 0;
    *(undefined2 *)(&stack0x0000012e + lVar7) = 0;
    puVar21 = (uint *)(lVar11 + 0x2108);
    *(uint **)(&stack0x00000468 + lVar7) = puVar21;
    uVar15 = *puVar21;
    *(uint *)(&stack0x00000114 + lVar7) = uVar15;
    *(uint **)(&stack0x00000330 + lVar7) = puVar21;
    do {
      *(uint *)(&stack0x00000240 + lVar7) = uVar15 & 0xfffffffe;
      *(undefined8 *)(&stack0x00000124 + lVar7) = **(undefined8 **)(&stack0x00000328 + lVar7);
      *(undefined4 *)(&stack0x0000012c + lVar7) =
           *(undefined4 *)(*(undefined8 **)(&stack0x00000328 + lVar7) + 1);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar7) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar7);
      UNLOCK();
      uVar15 = **(uint **)(&stack0x00000330 + lVar7);
      *(uint *)(&stack0x00000114 + lVar7) = uVar15;
    } while (*(uint *)(&stack0x00000240 + lVar7) != uVar15);
    if ((*(uint *)(&stack0x00000140 + lVar7) <= *(uint *)(&stack0x00000124 + lVar7)) &&
       ((*(uint *)(&stack0x00000124 + lVar7) != *(uint *)(&stack0x00000140 + lVar7) ||
        ((uVar15 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000124 + lVar7) >> 0x20),
         *(uint *)(&stack0x00000144 + lVar7) <= uVar15 &&
         ((uVar15 != *(uint *)(&stack0x00000144 + lVar7) ||
          (*(ushort *)(&stack0x00000148 + lVar7) <= *(ushort *)(&stack0x0000012c + lVar7)))))))))
    goto LAB_;
    if (*(char *)(*(longlong *)(&stack0x00000038 + lVar7) + 0x6ac8) == '\0') {
      lVar19 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00000470 + lVar7) = lVar19;
      lVar19 = (ulonglong)*_DAT_ + *(longlong *)(lVar19 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00000478 + lVar7) = lVar19;
      lVar19 = *(longlong *)(lVar19 + 8);
      *(longlong *)(&stack0x00000480 + lVar7) = lVar19;
      lVar19 = *(longlong *)(lVar19 + 0x60);
      *(longlong *)(&stack0x00000488 + lVar7) = lVar19;
      if (lVar19 != *(longlong *)(*(longlong *)(&stack0x00000038 + lVar7) + 0x2120)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100bae;
        cVar5 = func_0x();
        if (cVar5 == '\0') {
          *(longlong *)(&stack0x00000258 + lVar7) = lVar11 + 0x20fc;
          *(undefined4 *)(&stack0x00000108 + lVar7) = 0;
          *(undefined4 *)(&stack0x0000010c + lVar7) = 0;
          *(undefined2 *)(&stack0x00000110 + lVar7) = 0;
          *(undefined2 *)(&stack0x00000112 + lVar7) = 0;
          *(uint **)(&stack0x00000490 + lVar7) = puVar21;
          uVar15 = *puVar21;
          *(uint *)(&stack0x00000118 + lVar7) = uVar15;
          puVar18 = *(undefined8 **)(&stack0x00000258 + lVar7);
          *(longlong *)(&stack0x00000210 + lVar7) = (longlong)puVar18 + 0xc;
          while( true ) {
            *(uint *)(&stack0x00000244 + lVar7) = uVar15 & 0xfffffffe;
            *(undefined8 *)(&stack0x00000108 + lVar7) = *puVar18;
            *(undefined4 *)(&stack0x00000110 + lVar7) = *(undefined4 *)(puVar18 + 1);
            LOCK();
            *(undefined4 *)(&stack0xffffffffffffffc8 + lVar7) =
                 *(undefined4 *)(&stack0xffffffffffffffc8 + lVar7);
            UNLOCK();
            uVar15 = **(uint **)(&stack0x00000210 + lVar7);
            *(uint *)(&stack0x00000118 + lVar7) = uVar15;
            if (*(uint *)(&stack0x00000244 + lVar7) == uVar15) break;
            puVar18 = *(undefined8 **)(&stack0x00000258 + lVar7);
          }
          *(undefined8 *)(&stack0x000002c0 + lVar7) = *(undefined8 *)(&stack0x00000108 + lVar7);
          uVar2 = *(ushort *)(&stack0x00000110 + lVar7);
          *(ushort *)(&stack0x000002c8 + lVar7) = uVar2;
          lVar11 = ***(longlong ***)((longlong)&plStackX_10 + lVar7);
          acStackX_18[lVar7 + 1] = '\0';
          if (*(short *)(lVar11 + 0x24) == 0) {
LAB_:
            *(undefined8 *)(&stack0x00000150 + lVar7) = *(undefined8 *)(lVar11 + 0x28);
            uVar24 = *(ushort *)(lVar11 + 0x30);
            *(ushort *)(&stack0x00000158 + lVar7) = uVar24;
          }
          else {
            cVar5 = *(char *)(lVar11 + 1);
            if ((((cVar5 == '\v') || (cVar5 == '\b')) || (cVar5 == '\t')) &&
               (*(int *)(lVar11 + 0x18) == 99)) {
              *(undefined **)(&stack0x00000498 + lVar7) = &stack0x00000160 + lVar7;
              *(undefined4 *)(&stack0x00000160 + lVar7) = *(undefined4 *)(lVar11 + 0x20);
              *(undefined2 *)(&stack0x00000164 + lVar7) = *(undefined2 *)(lVar11 + 0x24);
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100ce1;
              cVar5 = func_0x(&stack0x00000160 + lVar7);
              if (cVar5 == '\0') goto LAB_;
              cVar5 = '\x01';
            }
            else {
LAB_:
              cVar5 = '\0';
            }
            acStackX_18[lVar7 + 1] = cVar5;
            if (cVar5 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100d03;
            func_0x(lVar11,&stack0x00000150 + lVar7);
            uVar24 = *(ushort *)(&stack0x00000158 + lVar7);
          }
          if ((*(uint *)(&stack0x00000108 + lVar7) < *(uint *)(&stack0x00000150 + lVar7)) ||
             ((*(uint *)(&stack0x00000108 + lVar7) == *(uint *)(&stack0x00000150 + lVar7) &&
              ((uVar15 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000150 + lVar7) >> 0x20),
               *(uint *)(&stack0x0000010c + lVar7) < uVar15 ||
               ((*(uint *)(&stack0x0000010c + lVar7) == uVar15 && (uVar2 < uVar24)))))))) {
            lVar11 = *(longlong *)(&stack0x00000038 + lVar7);
            lVar19 = *(longlong *)(lVar11 + 0x6b0);
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100d8f;
            func_0x(&stack0x00000150 + lVar7,&stack0x00000ac0 + lVar7,
                            &stack0x00000180 + lVar7);
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100dac;
            func_0x(&stack0x000002c0 + lVar7,&stack0x00000af0 + lVar7,
                            &stack0x00000180 + lVar7);
            *(undefined4 *)(&stack0x00000210 + lVar7) = 0x1d;
            *(undefined4 *)(&stack0x00000214 + lVar7) = 0x10000;
            if ((_DAT_ & 0x10000) != 0) {
              *(undefined2 *)(&stack0x000001d0 + lVar7) = 6;
              *(undefined **)(&stack0x000004a0 + lVar7) = &stack0x00000720 + lVar7;
              *(undefined2 *)(&stack0x00000720 + lVar7) = 0;
              *(undefined2 *)(&stack0x00000722 + lVar7) = 6;
              *(undefined4 *)(&stack0x00000728 + lVar7) = 0;
              *(undefined **)(&stack0x00000730 + lVar7) = &stack0x00000748 + lVar7;
              *(undefined **)(&stack0x00000738 + lVar7) = &stack0x000007a8 + lVar7;
              *(undefined4 *)(&stack0x00000968 + lVar7) = 0;
              *(undefined4 *)(&stack0x0000096c + lVar7) = 0;
              *(undefined8 *)(&stack0x00000740 + lVar7) = 0;
              *(undefined8 *)(&stack0x00000970 + lVar7) = 0;
              *(undefined **)(&stack0x000004a8 + lVar7) = &stack0x00000748 + lVar7;
              *(undefined **)(&stack0x00000748 + lVar7) = &stack0x00000978 + lVar7;
              *(undefined4 *)(&stack0x00000750 + lVar7) = 0x34;
              *(undefined2 *)(&stack0x00000754 + lVar7) = 5;
              *(undefined2 *)(&stack0x00000756 + lVar7) = 0;
              *(undefined **)(&stack0x000004b0 + lVar7) = &stack0x00000758 + lVar7;
              *(undefined8 *)(&stack0x00000758 + lVar7) = 0xfbae98;
              *(undefined4 *)(&stack0x00000760 + lVar7) = 0x10;
              *(undefined2 *)(&stack0x00000764 + lVar7) = 5;
              *(undefined2 *)(&stack0x00000766 + lVar7) = 0;
              *(undefined **)(&stack0x000004b8 + lVar7) = &stack0x00000768 + lVar7;
              *(undefined8 *)(&stack0x00000768 + lVar7) = 0xfbae98;
              *(undefined4 *)(&stack0x00000770 + lVar7) = 0x10;
              *(undefined2 *)(&stack0x00000774 + lVar7) = 6;
              *(undefined2 *)(&stack0x00000776 + lVar7) = 0;
              *(undefined **)(&stack0x000004c0 + lVar7) = &stack0x00000778 + lVar7;
              *(undefined8 *)(&stack0x00000778 + lVar7) = 0;
              *(undefined4 *)(&stack0x00000780 + lVar7) = 0;
              *(undefined2 *)(&stack0x00000784 + lVar7) = 7;
              *(undefined2 *)(&stack0x00000786 + lVar7) = 0;
              *(undefined **)(&stack0x000004c8 + lVar7) = &stack0x00000788 + lVar7;
              *(undefined8 *)(&stack0x00000788 + lVar7) = 0;
              *(undefined4 *)(&stack0x00000790 + lVar7) = 0;
              *(undefined2 *)(&stack0x00000794 + lVar7) = 8;
              *(undefined2 *)(&stack0x00000796 + lVar7) = 0;
              *(undefined **)(&stack0x000004d0 + lVar7) = &stack0x00000798 + lVar7;
              *(undefined8 *)(&stack0x00000798 + lVar7) = 0;
              *(undefined4 *)(&stack0x000007a0 + lVar7) = 0;
              *(undefined2 *)(&stack0x000007a4 + lVar7) = 9;
              *(undefined2 *)(&stack0x000007a6 + lVar7) = 0;
              *(uint *)(&stack0x00000978 + lVar7) = (uint)*(ushort *)(lVar11 + 0x6b8);
              *(undefined2 *)(&stack0x0000097c + lVar7) = *(undefined2 *)(&stack0x00000050 + lVar7);
              *(undefined4 *)(&stack0x0000097e + lVar7) = *(undefined4 *)(&stack0x0000004c + lVar7);
              (&stack0x00000982)[lVar7] = 1;
              (&stack0x00000983)[lVar7] =
                   *(undefined *)(***(longlong ***)((longlong)&plStackX_10 + lVar7) + 1);
              *(undefined **)(&stack0x000004d8 + lVar7) = &stack0x00000758 + lVar7;
              *(longlong *)(&stack0x00000758 + lVar7) = lVar19 + 0x254;
              *(undefined4 *)(&stack0x00000760 + lVar7) = 0x10;
              *(undefined2 *)(&stack0x00000764 + lVar7) = 5;
              *(undefined2 *)(&stack0x00000766 + lVar7) = 0;
              *(undefined **)(&stack0x000004e0 + lVar7) = &stack0x00000768 + lVar7;
              *(longlong *)(&stack0x00000768 + lVar7) = lVar19 + 0x244;
              *(undefined4 *)(&stack0x00000770 + lVar7) = 0x10;
              *(undefined2 *)(&stack0x00000774 + lVar7) = 6;
              *(undefined2 *)(&stack0x00000776 + lVar7) = 0;
              *(undefined **)(&stack0x000004e8 + lVar7) = &stack0x00000ac0 + lVar7;
              lVar11 = -1;
              do {
                lVar11 = lVar11 + 1;
              } while (*(short *)(&stack0x00000ac0 + lVar11 * 2 + lVar7) != 0);
              iVar6 = (int)lVar11 * 2;
              *(int *)(&stack0x000003b0 + lVar7) = iVar6;
              *(undefined **)(&stack0x000004f0 + lVar7) = &stack0x00000778 + lVar7;
              *(undefined **)(&stack0x00000778 + lVar7) = &stack0x00000ac0 + lVar7;
              *(int *)(&stack0x00000780 + lVar7) = iVar6;
              *(undefined2 *)(&stack0x00000784 + lVar7) = 7;
              *(undefined2 *)(&stack0x00000786 + lVar7) = 0;
              *(undefined **)(&stack0x000004f8 + lVar7) = &stack0x00000af0 + lVar7;
              lVar11 = -1;
              do {
                lVar11 = lVar11 + 1;
              } while (*(short *)(&stack0x00000af0 + lVar11 * 2 + lVar7) != 0);
              iVar6 = (int)lVar11 * 2;
              *(int *)(&stack0x000003b4 + lVar7) = iVar6;
              *(undefined **)(&stack0x00000500 + lVar7) = &stack0x00000788 + lVar7;
              *(undefined **)(&stack0x00000788 + lVar7) = &stack0x00000af0 + lVar7;
              *(int *)(&stack0x00000790 + lVar7) = iVar6;
              *(undefined2 *)(&stack0x00000794 + lVar7) = 8;
              *(undefined2 *)(&stack0x00000796 + lVar7) = 0;
              *(undefined4 *)(&stack0x00000184 + lVar7) = 0;
              UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10114c;
              lVar11 = (*UNRECOVERED_JUMPTABLE_00)(lVar19,&stack0x00000184 + lVar7);
              iVar6 = 0;
              if (lVar11 != 0) {
                lVar19 = -1;
                do {
                  lVar19 = lVar19 + 1;
                } while (*(short *)(lVar11 + lVar19 * 2) != 0);
                iVar6 = (int)lVar19 * 2;
              }
              *(int *)(&stack0x000003b8 + lVar7) = iVar6;
              lVar19 = *(longlong *)(&stack0x00000730 + lVar7);
              *(longlong *)(lVar19 + 0x50) = lVar11;
              *(int *)(lVar19 + 0x58) = iVar6;
              *(undefined2 *)(lVar19 + 0x5c) = 9;
              *(undefined2 *)(lVar19 + 0x5e) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1011a0;
              func_0x(&stack0x00000718 + lVar7);
            }
          }
LAB_:
          if ((1 < *(short *)((longlong)*(longlong ***)((longlong)&plStackX_10 + lVar7) + 0xc)) &&
             (lVar11 = ***(longlong ***)((longlong)&plStackX_10 + lVar7),
             *(char *)(lVar11 + 1) != '\x01')) {
            if (*(longlong *)(&stack0x00000130 + lVar7) != 0) {
              *(longlong *)(*(longlong *)(&stack0x00000130 + lVar7) + 0x588) = lVar11;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1015d2;
            lVar11 = func_0x();
            if (lVar11 == 0) {
LAB_:
              *(undefined4 *)(&stack0x000001a0 + lVar7) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1015dc;
              lVar11 = func_0x();
              if (*(longlong *)(lVar11 + 0x30) == 0) goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1015e8;
              lVar11 = func_0x();
              uVar15 = *(uint *)(*(longlong *)(lVar11 + 0x30) + 0xc);
              *(uint *)(&stack0x000003d0 + lVar7) = uVar15;
              if ((0xd < uVar15) || (iVar6 = 1, (0x2640U >> (uVar15 & 0x1f) & 1) == 0)) {
                iVar6 = 0;
              }
              *(int *)(&stack0x000001a0 + lVar7) = iVar6;
              if (iVar6 != 0) goto LAB_;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101627;
            func_0x(0,8);
          }
LAB_:
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101644;
          func_0x
                    (&stack0x000002a0 + lVar7,&stack0x000000d0 + lVar7,&stack0x00000ab0 + lVar7);
          lVar11 = ***(longlong ***)((longlong)&plStackX_10 + lVar7);
          if (lVar11 == 0) {
            *(undefined (*) [16])(&stack0x00000288 + lVar7) = ZEXT816(0);
          }
          else {
            *(longlong *)(&stack0x00000288 + lVar7) = lVar11;
            *(longlong *)(&stack0x00000290 + lVar7) = lVar11 + 0x2000;
          }
          *(undefined4 *)(&stack0x00000298 + lVar7) = 0;
          lVar11 = -0x16ae890;
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1016a7;
          uVar13 = func_0x(&stack0x00000288 + lVar7);
          if (uVar13 == 0) {
            lVar19 = (ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
            lVar11 = *(longlong *)(lVar19 + 0x100);
            if (lVar11 == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x103130;
              (*_DAT_)();
              lVar11 = *(longlong *)(lVar19 + 0x100);
            }
            if (*(int *)(lVar11 + 0x22c) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x103146;
              (*_DAT_)();
            }
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0x1254bd0;
            uVar13 = 0x12186a4;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10316f;
            (*_DAT_)(1,0x12186a4,0x12146d8,0x6ba);
            lVar11 = *(longlong *)(&stack0x000002b0 + lVar7);
            if (lVar11 != 0) {
              *(undefined8 *)(&stack0x00000390 + lVar7) = 0xe32630;
              if (*(int *)(lVar11 + 8) != 0) {
                uVar13 = uVar13 & 0xffffffffffffff00;
                for (uVar15 = *(int *)(lVar11 + 8) - 1; uVar15 != 0; uVar15 = uVar15 >> 3) {
                  uVar13 = CONCAT71((int7)(uVar13 >> 8),(char)uVar13 + '\x03');
                }
                *(undefined4 *)(lVar11 + 8) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1031bd;
                func_0x(lVar11,uVar13,&stack0x00000390 + lVar7);
                lVar11 = *(longlong *)(&stack0x000002b0 + lVar7);
              }
              if (lVar11 != 0) {
                if (*(int *)(lVar11 + 8) != 0) {
                  uVar13 = uVar13 & 0xffffffffffffff00;
                  for (uVar15 = *(int *)(lVar11 + 8) - 1; uVar15 != 0; uVar15 = uVar15 >> 3) {
                    uVar13 = CONCAT71((int7)(uVar13 >> 8),(char)uVar13 + '\x03');
                  }
                  *(undefined4 *)(lVar11 + 8) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1031f8;
                  func_0x(lVar11,uVar13,0);
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10320e;
                (*_DAT_)(lVar11,0x10);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10321e;
            func_0x
                      (*(ulonglong *)(&stack0x00002ac8 + lVar7) ^
                       (ulonglong)(&stack0xffffffffffffffc8 + lVar7));
            return;
          }
          uVar20 = uVar13 & 0xffffffffffffe000;
          *(ulonglong *)(&stack0x00000590 + lVar7) = uVar20;
          iVar6 = (int)((longlong)((uVar20 - uVar13) + 0x1ffe) >> 1);
          *(int *)(&stack0x00000a04 + lVar7) = iVar6;
          if (-1 < *(char *)(uVar20 + 2)) {
            *(undefined8 *)(&stack0x000001f8 + lVar7) = 0;
            goto LAB_;
          }
          pbVar23 = (byte *)(uVar20 + 0x60);
          if (*(short *)(&stack0x000009d0 + lVar7) == 0) {
            *(undefined8 *)(&stack0x000001f8 + lVar7) = 0;
LAB_:
            *(undefined **)(&stack0x00000598 + lVar7) = &stack0x00000a08 + lVar7;
            *(undefined (*) [16])(&stack0x00000a08 + lVar7) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000a18 + lVar7) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000a28 + lVar7) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000a38 + lVar7) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000a48 + lVar7) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000a58 + lVar7) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000a68 + lVar7) = ZEXT816(0);
            *(undefined8 *)(&stack0x00000a78 + lVar7) = 0;
            *(undefined **)(&stack0x000005a0 + lVar7) = &stack0x00000a08 + lVar7;
            *(undefined (*) [16])(&stack0x00000a08 + lVar7) = ZEXT816(0);
            *(undefined **)(&stack0x000005a8 + lVar7) = &stack0x00000a18 + lVar7;
            *(undefined2 *)(&stack0x00000a18 + lVar7) = 0xffff;
            *(undefined8 *)(&stack0x00000a20 + lVar7) = 0;
            *(undefined4 *)(&stack0x00000a1c + lVar7) = 0;
            *(undefined8 *)(&stack0x00000a36 + lVar7) = 0;
            *(undefined8 *)(&stack0x00000a40 + lVar7) = 0;
            *(undefined8 *)(&stack0x00000a28 + lVar7) = 0;
            *(undefined **)(&stack0x000005b0 + lVar7) = &stack0x00000a50 + lVar7;
            *(undefined8 *)(&stack0x00000a50 + lVar7) = 0;
            *(undefined **)(&stack0x000005b8 + lVar7) = &stack0x00000a68 + lVar7;
            *(undefined4 *)(&stack0x00000a68 + lVar7) = 0;
            *(undefined4 *)(&stack0x00000a6c + lVar7) = 0;
            *(undefined2 *)(&stack0x00000a70 + lVar7) = 0;
            *(undefined2 *)(&stack0x00000a72 + lVar7) = 0;
            *(undefined **)(&stack0x000005c0 + lVar7) = &stack0x00000a74 + lVar7;
            *(undefined2 *)(&stack0x00000a7a + lVar7) = 0;
            ppbVar22 = (byte **)(&stack0x00000a08 + lVar7);
            *(byte ***)(&stack0x000001f8 + lVar7) = ppbVar22;
          }
          else {
            ppbVar22 = *(byte ***)(&stack0x000009e0 + lVar7);
            *(byte ***)(&stack0x000001f8 + lVar7) = ppbVar22;
            if (ppbVar22 == (byte **)0x0) goto LAB_;
          }
          acStackX_18[lVar7 + 4] = '\0';
          if (*(short *)(uVar20 + 0x24) == 0) {
LAB_:
            *(undefined8 *)(&stack0x000000e0 + lVar7) = *(undefined8 *)(uVar20 + 0x28);
            sVar26 = *(short *)(uVar20 + 0x30);
            *(short *)(&stack0x000000e8 + lVar7) = sVar26;
          }
          else {
            cVar5 = *(char *)(uVar20 + 1);
            if ((((cVar5 == '\v') || (cVar5 == '\b')) || (cVar5 == '\t')) &&
               (*(int *)(uVar20 + 0x18) == 99)) {
              *(undefined **)(&stack0x000005c8 + lVar7) = &stack0x00000168 + lVar7;
              *(undefined4 *)(&stack0x00000168 + lVar7) = *(undefined4 *)(uVar20 + 0x20);
              *(undefined2 *)(&stack0x0000016c + lVar7) = *(undefined2 *)(uVar20 + 0x24);
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10189e;
              cVar5 = func_0x(&stack0x00000168 + lVar7);
              if (cVar5 == '\0') goto LAB_;
              cVar5 = '\x01';
            }
            else {
LAB_:
              cVar5 = '\0';
            }
            acStackX_18[lVar7 + 4] = cVar5;
            if (cVar5 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1018c0;
            func_0x(uVar20,&stack0x000000e0 + lVar7);
            sVar26 = *(short *)(&stack0x000000e8 + lVar7);
          }
          *(undefined **)(&stack0x000005d0 + lVar7) = &stack0x000000e0 + lVar7;
          *(byte ***)(&stack0x000005d8 + lVar7) = ppbVar22;
          if (((pbVar23 == *ppbVar22) && (sVar26 == *(short *)(ppbVar22 + 0xd))) &&
             ((*(int *)(&stack0x000000e0 + lVar7) == *(int *)(ppbVar22 + 0xc) &&
              (*(int *)(&stack0x000000e4 + lVar7) == *(int *)((longlong)ppbVar22 + 100))))) {
            *(longlong *)(&stack0x000005e0 + lVar7) = (longlong)ppbVar22 + 0x6c;
          }
          *ppbVar22 = pbVar23;
          uVar25 = *(undefined2 *)(&stack0x000000e8 + lVar7);
          uVar3 = *(undefined4 *)(&stack0x000000e4 + lVar7);
          *(undefined4 *)(&stack0x000002e0 + lVar7) = *(undefined4 *)(&stack0x000000e0 + lVar7);
          *(undefined4 *)(ppbVar22 + 0xc) = *(undefined4 *)(&stack0x000000e0 + lVar7);
          *(undefined4 *)((longlong)ppbVar22 + 100) = uVar3;
          *(undefined2 *)(ppbVar22 + 0xd) = uVar25;
          *(undefined4 *)((longlong)ppbVar22 + 0x6c) = *(undefined4 *)(uVar20 + 0x20);
          *(undefined2 *)(ppbVar22 + 0xe) = *(undefined2 *)(uVar20 + 0x24);
          *(undefined2 *)((longlong)ppbVar22 + 0x72) = 0;
          uVar13 = (ulonglong)*pbVar23;
          *(ushort *)(&stack0x000001d8 + lVar7) = (ushort)*pbVar23;
          *(undefined4 *)(&stack0x00000280 + lVar7) = *(undefined4 *)(uVar13 * 6 + 0xe8b5a0);
          *(undefined2 *)(&stack0x00000284 + lVar7) = *(undefined2 *)(uVar13 * 6 + 0xe8b5a4);
          *(undefined4 *)(&stack0x00000278 + lVar7) = *(undefined4 *)(uVar13 * 6 + 0xe8b5a0);
          uVar13 = (ulonglong)*(short *)(uVar13 * 6 + 0xe8b5a4);
          *(undefined2 *)(ppbVar22 + 2) = 0xffff;
          ppbVar22[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
          ppbVar22[7] = (byte *)0x0;
          ppbVar22[4] = (byte *)0x0;
          ppbVar22[9] = (byte *)0x0;
          ppbVar22[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar22 + 0xb) = 0;
          if ((**ppbVar22 & 2) != 0) {
            pbVar23 = pbVar23 + uVar13;
            bVar1 = *pbVar23;
            *(ushort *)(ppbVar22 + 2) = (ushort)(bVar1 & 1);
            if ((bVar1 & 1) != 0) {
              ppbVar22[3] = pbVar23;
              UNRECOVERED_JUMPTABLE_00 =
                   (code *)((ulonglong)
                            *(uint *)((ulonglong)
                                      *(byte *)((longlong)(int)(*pbVar23 & 0x1c) + 0x103280) * 4 +
                                     0x103270) - 0x16ae890);
                    /* WARNING: Could not emulate address calculation at 0x00101af5 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
              return;
            }
            *(undefined4 *)(&stack0x000000a8 + lVar7) = 0;
            ppbVar22[3] = pbVar23;
            *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar22 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101a29 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*ppbVar22[3] & 0xe) * 4 + 0x103234) -
                      0x16ae890))();
            return;
          }
          if ((**ppbVar22 & 4) != 0) {
            if (*(short *)(&stack0x0000027a + lVar7) != 0) {
              uVar13 = (ulonglong)
                       *(ushort *)
                        (uVar20 + 0x61 + (longlong)*(short *)(&stack0x0000027a + lVar7) * 2);
            }
            psVar14 = (short *)(pbVar23 + uVar13);
            *(short **)(&stack0x00000600 + lVar7) = psVar14;
            ppbVar22[9] = (byte *)psVar14;
            sVar26 = *psVar14;
            *(short *)(&stack0x000001e0 + lVar7) = sVar26;
            ppbVar22[10] = (byte *)(psVar14 + 1);
            *(short *)(ppbVar22 + 0xb) = (sVar26 + 1) * 2;
          }
          pbVar23 = ppbVar22[1];
          if (pbVar23 != (byte *)0x0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101d2d;
            func_0x(pbVar23,ppbVar22);
          }
          lVar11 = -0x16ae890;
LAB_:
          uVar2 = *(ushort *)(uVar20 + 0xe);
          pbVar23 = (byte *)(*(ushort *)(uVar20 + (0xfff - (longlong)iVar6) * 2) + uVar20);
          bVar1 = *pbVar23;
          *(ushort *)(&stack0x000009d0 + lVar7) = (ushort)(bVar1 & 1);
          if ((bVar1 & 1) != 0) {
            *(undefined **)(&stack0x00000618 + lVar7) = &stack0x000009d2 + lVar7;
            *(byte **)(&stack0x000009d8 + lVar7) = pbVar23;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)(lVar11 + 0x17b1b6c +
                                   (ulonglong)
                                   *(byte *)(lVar11 + 0x17b1b7c + (longlong)(int)(*pbVar23 & 0x1c))
                                   * 4) + lVar11);
                    /* WARNING: Could not recover jumptable at 0x00101e76. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          *(uint *)(&stack0x000000b0 + lVar7) = (uint)uVar2;
          *(undefined **)(&stack0x00000608 + lVar7) = &stack0x000009d2 + lVar7;
          *(byte **)(&stack0x000009d8 + lVar7) = pbVar23;
          *(undefined4 *)(&stack0x000009d4 + lVar7) = 0;
          *(undefined4 *)(&stack0x000009f6 + lVar7) = 0;
          *(byte **)(&stack0x00000610 + lVar7) = pbVar23;
                    /* WARNING: Could not recover jumptable at 0x00101dc1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)(lVar11 + 0x17b1b30 + (longlong)(int)(*pbVar23 & 0xe) * 4)
                    + lVar11))();
          return;
        }
      }
    }
    lVar11 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x00000508 + lVar7) = lVar11;
    lVar11 = (ulonglong)*_DAT_ + *(longlong *)(lVar11 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x00000510 + lVar7) = lVar11;
    lVar11 = *(longlong *)(lVar11 + 8);
    *(longlong *)(&stack0x00000518 + lVar7) = lVar11;
    lVar19 = *(longlong *)(lVar11 + 0x60);
    *(longlong *)(&stack0x00000520 + lVar7) = lVar19;
    lVar11 = *(longlong *)(&stack0x00000038 + lVar7);
    if (lVar19 == *(longlong *)(lVar11 + 0x2120)) goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101206;
    cVar5 = func_0x(lVar11);
    if (cVar5 != '\0') goto LAB_;
    if (*(longlong *)(&stack0x00000130 + lVar7) == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10121e;
      uVar12 = func_0x();
      *(undefined8 *)(&stack0x00000130 + lVar7) = uVar12;
    }
    *(undefined **)(&stack0x00000528 + lVar7) = &stack0x00000058 + lVar7;
    lVar19 = ***(longlong ***)((longlong)&plStackX_10 + lVar7);
    *(longlong *)(&stack0x00000530 + lVar7) = lVar19;
    acStackX_18[lVar7 + 2] = '\0';
    if (*(short *)(lVar19 + 0x24) == 0) {
LAB_:
      uVar12 = *(undefined8 *)(lVar19 + 0x28);
      *(undefined8 *)(&stack0x00000058 + lVar7) = uVar12;
      uVar25 = *(undefined2 *)(lVar19 + 0x30);
      *(undefined2 *)(&stack0x00000060 + lVar7) = uVar25;
    }
    else {
      cVar5 = *(char *)(lVar19 + 1);
      if ((((cVar5 == '\v') || (cVar5 == '\b')) || (cVar5 == '\t')) &&
         (*(int *)(lVar19 + 0x18) == 99)) {
        *(undefined **)(&stack0x00000538 + lVar7) = &stack0x00000178 + lVar7;
        *(undefined4 **)(&stack0x00000540 + lVar7) = (undefined4 *)(lVar19 + 0x20);
        *(undefined4 *)(&stack0x00000178 + lVar7) = *(undefined4 *)(lVar19 + 0x20);
        *(undefined2 *)(&stack0x0000017c + lVar7) = *(undefined2 *)(lVar19 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1012b0;
        cVar5 = func_0x(&stack0x00000178 + lVar7);
        if (cVar5 == '\0') goto LAB_;
        cVar5 = '\x01';
      }
      else {
LAB_:
        cVar5 = '\0';
      }
      acStackX_18[lVar7 + 2] = cVar5;
      if (cVar5 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1012d2;
      func_0x(lVar19,&stack0x00000058 + lVar7);
      uVar25 = *(undefined2 *)(&stack0x00000060 + lVar7);
      uVar12 = *(undefined8 *)(&stack0x00000058 + lVar7);
    }
    *(undefined **)(&stack0x00000548 + lVar7) = &stack0x00000058 + lVar7;
    *(undefined8 *)(&stack0x000003c0 + lVar7) = uVar12;
    *(undefined2 *)(&stack0x000003c8 + lVar7) = uVar25;
    *(undefined2 *)(&stack0x000003ca + lVar7) = 0;
    if (**(longlong **)((longlong)&plStackX_10 + lVar7) != 0) {
      puVar10 = (ushort *)(**(longlong **)((longlong)&plStackX_10 + lVar7) + 0x62);
      *(ushort **)(&stack0x00000550 + lVar7) = puVar10;
      uVar2 = *puVar10;
      *(ushort *)(&stack0x00000090 + lVar7) = uVar2;
      if (((uVar2 & 0x400) == 0) || (*(short *)((longlong)pplVar4 + 0xc) < 3)) {
        *(int *)((longlong)aiStackX_20 + lVar7) = (int)*(short *)((longlong)pplVar4 + 0xc);
        lVar11 = **(longlong **)((longlong)&plStackX_10 + lVar7);
        *(longlong *)(&stack0x000000f0 + lVar7) = lVar11;
        puVar16 = (undefined2 *)(lVar11 + 0x62);
        *(undefined2 **)(&stack0x00000558 + lVar7) = puVar16;
        uVar25 = *puVar16;
        *(undefined2 *)(&stack0x00000098 + lVar7) = uVar25;
        if (((byte)uVar25 >> 3 & 1) != 0) {
          if (*(int *)((longlong)aiStackX_20 + lVar7) == 3) {
            *(undefined4 *)((longlong)aiStackX_20 + lVar7) = 4;
          }
          else if (*(int *)((longlong)aiStackX_20 + lVar7) < 2) goto LAB_;
          *(uint **)(&stack0x00000560 + lVar7) =
               (uint *)(*(longlong *)(&stack0x000000f0 + lVar7) + 100);
          uVar15 = *(uint *)(*(longlong *)(&stack0x000000f0 + lVar7) + 100);
          *(uint *)(&stack0x00000188 + lVar7) = uVar15;
          if ((((uVar15 & 8) != 0) &&
              (lVar11 = *(longlong *)(*(longlong *)(&stack0x000000f0 + lVar7) + 0x90), lVar11 != 0))
             && (*(longlong *)(&stack0x00000568 + lVar7) = lVar11,
                *(longlong *)(lVar11 + 0x758) != 0)) {
            uVar12 = *(undefined8 *)(lVar11 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101422;
            func_0x
                      (uVar12,*(undefined8 *)(&stack0x000000f0 + lVar7),
                       *(undefined4 *)((longlong)aiStackX_20 + lVar7));
          }
        }
LAB_:
        (&stack0x000000cd)[lVar7] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar21 = (uint *)(*(longlong *)(&stack0x000000f0 + lVar7) + 100);
          *(uint **)(&stack0x00000570 + lVar7) = puVar21;
          uVar15 = *puVar21;
          *(uint *)(&stack0x00000190 + lVar7) = uVar15;
          if (((uVar15 & 8) != 0) && (2 < *(int *)((longlong)aiStackX_20 + lVar7))) {
            *(uint **)(&stack0x00000578 + lVar7) = puVar21;
            uVar15 = *puVar21;
            *(uint *)(&stack0x00000198 + lVar7) = uVar15;
            if (((uVar15 & 0xc0000000) != 0x40000000) &&
               (lVar11 = **(longlong **)(&stack0x000000f0 + lVar7), lVar11 != 0)) {
              *(undefined4 *)(&stack0x000003bc + lVar7) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1014b2;
              iVar6 = (*_DAT_)(lVar11,0x2000,2,&stack0x000003cc + lVar7);
              if (iVar6 != 0) {
                LOCK();
                *puVar21 = *puVar21 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar21 = *puVar21 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar11 = *(longlong *)(&stack0x000000f0 + lVar7);
        uVar3 = *(undefined4 *)((longlong)aiStackX_20 + lVar7);
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1014e0;
        func_0x(lVar11 + 0x98,uVar3);
        if ((_DAT_ != 0) &&
           ((&stack0x000000d8)[lVar7] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10150a;
          func_0x(lVar11,0,uVar3);
        }
        *(uint *)((longlong)pplVar4 + 0xc) = *(uint *)((longlong)pplVar4 + 0xc) & 0xffff0000;
        **(undefined8 **)((longlong)&plStackX_10 + lVar7) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10136c;
        func_0x(*(undefined8 *)((longlong)&plStackX_10 + lVar7));
      }
      uVar12 = *(undefined8 *)(&stack0x00000058 + lVar7);
      uVar25 = *(undefined2 *)(&stack0x00000060 + lVar7);
      lVar11 = *(longlong *)(&stack0x00000038 + lVar7);
    }
    *(undefined **)(&stack0x00000580 + lVar7) = &stack0x000002d0 + lVar7;
    *(undefined8 *)(&stack0x000002d0 + lVar7) = uVar12;
    *(undefined2 *)(&stack0x000002d8 + lVar7) = uVar25;
    *(undefined **)(&stack0x00000588 + lVar7) = &stack0x00000248 + lVar7;
    *(undefined8 *)(&stack0x00000248 + lVar7) = uVar12;
    *(undefined2 *)(&stack0x00000250 + lVar7) = uVar25;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    lVar19 = *plVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101592;
    func_0x(lVar19,&stack0x00000248 + lVar7,4);
  } while( true );
}

