
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Possible PIC construction at 0x0010021f: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x00100224) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3,longlong param_4)

{
  int iVar1;
  char cVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  if (*(longlong *)(param_3 + 0x6b8) != param_4) {
    return;
  }
  if ((((DAT_ == '\0') && (lVar3 = (*_DAT_)(), *(char *)(lVar3 + 0x283) == '\0')) &&
      (lVar3 = (*_DAT_)(), *(char *)(lVar3 + 0x196) == '\0')) && (_DAT_ != 0)) {
    return;
  }
  func_0x(param_1,param_2);
  switch(*(undefined4 *)(param_2 + 0x48)) {
  case 1:
  case 3:
  case 4:
  case 6:
  case 7:
    return;
  case 2:
  case 5:
  case 8:
    break;
  default:
    (*_DAT_)(1,0x22da0f0,0x22da998,0x1208,0x1ed5298);
    return;
  }
  cVar2 = func_0x(param_3,param_2 + 0x50,param_2 + 0x5c,param_2 + 0x68,param_2 + 0x74,
                          param_2 + 0x88,param_2 + 0x94,param_2 + 0xb0,param_2 + 0xa0,param_2 + 0xb8
                          ,param_2 + 0xc4,param_2 + 0xcc,*(undefined4 *)(param_2 + 0xd8));
  iVar1 = *(int *)(param_2 + 0xd8);
  if (cVar2 == '\0') {
    if ((iVar1 != 0x44) && (iVar1 != 0x49)) {
      uVar5 = 0;
      uVar4 = 0x2ab3020;
      goto code_r0x001001db;
    }
    uVar5 = 0;
  }
  else {
    if ((iVar1 != 0x44) && (iVar1 != 0x49)) {
      uVar5 = 1;
      uVar4 = 0x2ab3020;
      goto code_r0x001001db;
    }
    uVar5 = 1;
  }
  uVar4 = 0x2ab3070;
code_r0x001001db:
  uStack_58 = *(undefined4 *)(param_1 + 0x32c);
  uStack_54 = *(undefined4 *)(param_1 + 0x330);
  uStack_50 = *(undefined4 *)(param_1 + 0x334);
  uStack_4c = *(undefined4 *)(param_1 + 0x338);
  uStack_48 = *(undefined4 *)(param_1 + 0x33c);
  uStack_44 = *(undefined4 *)(param_1 + 0x340);
  uStack_40 = *(undefined4 *)(param_1 + 0x344);
  uStack_3c = *(undefined4 *)(param_1 + 0x348);
  uStack_38 = *(undefined4 *)(param_1 + 0x34c);
  uStack_34 = *(undefined4 *)(param_1 + 0x350);
  uStack_30 = *(undefined4 *)(param_1 + 0x354);
  uStack_2c = *(undefined4 *)(param_1 + 0x358);
  func_0x(uVar4,&uStack_58,uVar5);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

