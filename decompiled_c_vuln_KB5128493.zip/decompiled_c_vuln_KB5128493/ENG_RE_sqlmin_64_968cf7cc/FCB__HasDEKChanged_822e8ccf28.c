
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_(longlong param_1,short *param_2,undefined8 param_3)

{
  ushort *puVar1;
  byte *pbVar2;
  longlong *plVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  ulonglong *puVar7;
  int *piVar8;
  longlong lVar9;
  ushort uVar10;
  uint uVar11;
  ulonglong uVar12;
  short sVar13;
  uint uVar14;
  ushort *puVar15;
  longlong unaff_GS_OFFSET;
  int aiStackX_10 [2];
  uint auStackX_18 [4];
  ulonglong in_stack_ffffffffffffffa0;
  int iStack_48;
  ushort uStack_44;
  ushort uStack_42;
  int *piStack_40;
  
  iStack_48 = -0x2e;
  uStack_44 = 0x2e;
  puVar1 = (ushort *)(param_2 + 1);
  piStack_40 = (int *)0x0;
  uStack_42 = uStack_42 & 0xffe0;
  iVar6 = 0;
  if (*param_2 != 0) {
    auStackX_18[0] = 0;
    piVar8 = (int *)func_0x(puVar1,&iStack_48,param_3,aiStackX_10,auStackX_18);
    if ((((*param_2 != 0) && (plVar3 = *(longlong **)(param_2 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) && (((uStack_42 & 8) == 0 && ((auStackX_18[0] & 1) == 0)))) {
      if ((piVar8 == (int *)0x0) || (piVar8 == (int *)0x11c7dd4)) {
        aiStackX_10[0] = 0;
        piVar8 = (int *)0x0;
      }
      else {
        piVar8 = (int *)func_0x
                                  (plVar3,&iStack_48,piVar8,aiStackX_10[0],0,
                                   in_stack_ffffffffffffffa0 & 0xffffffff00000000,aiStackX_10,
                                   auStackX_18[0]);
      }
    }
    goto LAB_;
  }
  pbVar2 = *(byte **)(param_2 + 4);
  if ((*pbVar2 & 0x10) == 0) {
    uVar11 = 1 << (*pbVar2 & 0xe) & 0x1105;
LAB_:
    if (uVar11 == 0) {
      if (*(int *)(param_2 + 2) == 0) {
        uVar11 = *(uint *)(param_2 + 8);
        uVar12 = (ulonglong)uVar11;
        *(uint *)(param_2 + 10) = uVar11;
        *puVar1 = 0;
        bVar4 = *pbVar2;
        if ((bVar4 & 0x10) != 0) {
          uVar11 = uVar11 + 2 + (*(ushort *)(pbVar2 + uVar12) + 7 >> 3);
          uVar12 = (ulonglong)uVar11;
          *(uint *)(param_2 + 10) = uVar11;
          bVar4 = *pbVar2;
        }
        if ((bVar4 & 0x20) == 0) {
          *(int *)(param_2 + 2) = (int)uVar12;
          param_2[0xe] = 0;
          *(int *)(param_2 + 0xc) = (int)uVar12;
        }
        else {
          puVar15 = (ushort *)(pbVar2 + uVar12);
          uVar5 = *puVar15;
          param_2[0xe] = uVar5;
          if (uVar5 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar9 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar9 != 0)) &&
               ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                (*(char *)(lVar9 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x1443398,0x1563068,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),3);
            uVar12 = (ulonglong)*(uint *)(param_2 + 10);
            uVar5 = param_2[0xe];
          }
          uVar11 = (int)uVar12 + (uVar5 + 1) * 2;
          *(uint *)(param_2 + 0xc) = uVar11;
          if (0x1f9e < uVar11) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar9 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar9 != 0 &&
                ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                 (*(char *)(lVar9 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x1443398,0x1563068,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar5 = param_2[0xe];
            uVar11 = *(uint *)(param_2 + 0xc);
          }
          uVar12 = (ulonglong)uVar5;
          uVar5 = puVar15[uVar12];
          *(uint *)(param_2 + 2) = uVar5 & 0x7fff;
          if ((uVar5 & 0x7fff) < uVar11) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar9 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar9 != 0)) &&
               ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                (*(char *)(lVar9 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x1443398,0x1563068,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar12 = (ulonglong)(ushort)param_2[0xe];
          }
          if ((short)puVar15[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
            lVar9 = *(longlong *)(param_2 + 4);
            do {
              if ((int)uVar12 == 1) {
                uVar11 = *(uint *)(param_2 + 0xc);
                uVar14 = uVar11;
LAB_:
                if ((*(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar9 + uVar12 * 2) & 0x7fff)
                    < uVar11) goto LAB_;
              }
              else {
                uVar14 = *(uint *)(param_2 + 0xc);
                uVar11 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar9 + -2 + uVar12 * 2) &
                         0x7fff;
                if (uVar14 <= uVar11) goto LAB_;
LAB_:
                func_0x(lVar9,7);
                uVar14 = *(uint *)(param_2 + 0xc);
              }
              if ((uVar11 < uVar14) || (*(uint *)(param_2 + 2) < uVar11)) goto LAB_;
              lVar9 = *(longlong *)(param_2 + 4);
              if (*(ushort *)((ulonglong)uVar11 + lVar9) == 5) {
                *puVar1 = *puVar1 | 2;
                param_2[0xe] = param_2[0xe] + -1;
                param_2[0x15] = (short)uVar11;
                lVar9 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(param_2 + 4);
                uVar5 = param_2[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar9 + 2) & 0x4000) != 0) {
                  uVar5 = *(ushort *)(lVar9 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                }
                param_2[0x16] = uVar5;
                param_2[0x16] = (uVar5 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar5;
                break;
              }
              if (*(ushort *)((ulonglong)uVar11 + lVar9) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar5 = param_2[0xe] - 1;
              param_2[0xe] = uVar5;
              if ((uVar5 == 0) ||
                 (uVar12 = (ulonglong)uVar5, -1 < (short)puVar15[(ulonglong)(uVar5 - 1) + 1]))
              goto LAB_;
            } while( true );
          }
          uVar12 = (ulonglong)*(uint *)(param_2 + 2);
        }
        goto LAB_;
      }
      goto LAB_;
    }
  }
  else {
    uVar11 = *(uint *)(param_2 + 8);
    if ((-0x2e < (int)uVar11) && (0x2d < *(ushort *)(pbVar2 + uVar11))) {
      uVar11 = pbVar2[(ulonglong)uVar11 + 7] >> 5 & 1;
      goto LAB_;
    }
  }
  aiStackX_10[0] = 0;
  piVar8 = (int *)0x0;
  goto LAB_;
LAB_:
  uVar12 = (ulonglong)*(uint *)(param_2 + 2);
LAB_:
  if ((**(byte **)(param_2 + 4) & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0x13) = 0;
  }
  else {
    *(int *)(param_2 + 0x13) = (int)uVar12;
    *(int *)(param_2 + 2) = (int)uVar12 + 0xe;
    puVar7 = (ulonglong *)func_0x(puVar1);
    uVar12 = *puVar7;
    uVar10 = (ushort)(uVar12 >> 0x30);
    uVar5 = uVar10;
    if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
      uVar5 = uVar10 & 0xdfff;
      if ((uVar12 & 0x4000000000000000) != 0) {
        uVar5 = uVar10 | 0x2000;
      }
    }
    if (uVar5 == 0xfffc) {
      iVar6 = (int)((uVar12 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar6;
    uVar12 = (ulonglong)*(uint *)(param_2 + 2);
  }
  iVar6 = (int)uVar12;
  if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
     (*(ulonglong *)(param_2 + 0xf) < uVar12 + *(longlong *)(param_2 + 4))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar9 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar9 != 0 &&
         (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) && (*(char *)(lVar9 + 0x499) != '\0'))))
    {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x1443398,0x1563068,0x877,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),0x12);
    iVar6 = *(int *)(param_2 + 2);
  }
  if (0x3f3b < iVar6 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar9 = *(longlong *)
                  (*(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                  (ulonglong)*_DAT_), lVar9 != 0 &&
        ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))))))
    {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x1443398,0x1563068,0x87c,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),5);
  }
LAB_:
  sVar13 = -(short)iStack_48;
  if ((uStack_42 & 0x10) != 0) {
    bVar4 = **(byte **)(param_2 + 4);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
        aiStackX_10[0] = *piStack_40;
        piVar8 = piStack_40 + 1;
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(param_2 + 8) <= iStack_48) ||
            (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) < uStack_44))
    goto LAB_;
  }
  piVar8 = *(int **)(param_2 + 4);
  lVar9 = (longlong)sVar13;
  if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar13) {
    aiStackX_10[0] = 0;
    goto LAB_;
  }
  uVar11 = *(uint *)(param_2 + 10);
  if (sVar13 == 1) {
    uVar14 = *(uint *)(param_2 + 0xc);
    uVar11 = *(ushort *)((longlong)piVar8 + lVar9 * 2 + (ulonglong)uVar11) & 0x7fff;
LAB_:
    if (uVar11 < uVar14) goto LAB_;
  }
  else {
    puVar1 = (ushort *)((longlong)piVar8 + lVar9 * 2 + (ulonglong)uVar11);
    uVar14 = *(ushort *)((longlong)piVar8 + lVar9 * 2 + ((ulonglong)uVar11 - 2)) & 0x7fff;
    piVar8 = *(int **)(param_2 + 4);
    uVar11 = *puVar1 & 0x7fff;
    if (*(uint *)(param_2 + 0xc) <= uVar14) goto LAB_;
LAB_:
    func_0x(piVar8,7);
    piVar8 = *(int **)(param_2 + 4);
  }
  aiStackX_10[0] = uVar11 - uVar14;
  piVar8 = (int *)((longlong)piVar8 + (ulonglong)uVar14);
LAB_:
  if (aiStackX_10[0] == 0) {
    return *(longlong *)(param_1 + 0x370) != 0;
  }
  if ((piVar8 != (int *)0x0) && (aiStackX_10[0] == 600)) {
    if (*(longlong *)(param_1 + 0x370) == 0) {
      if ((*(byte *)piVar8 & 0x1f) == 0) {
        return false;
      }
    }
    else {
      iVar6 = (*_DAT_)(*(longlong *)(param_1 + 0x370),piVar8,600);
      if (iVar6 != 0) {
        return false;
      }
    }
    return true;
  }
  (*_DAT_)(0x33,0x48,0x10,0x51,param_1 + 0x940,0x1469440);
  return false;
}

