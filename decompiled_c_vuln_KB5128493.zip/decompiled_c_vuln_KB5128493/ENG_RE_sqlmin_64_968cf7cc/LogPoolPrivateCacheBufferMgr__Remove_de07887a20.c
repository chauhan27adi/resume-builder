
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  func_0x(param_1,param_2,0);
  if (*(longlong **)(param_1 + 0x28) == param_2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong **)(param_1 + 0x30) != param_2) {
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + -1;
    lVar1 = *param_2;
    plVar2 = (longlong *)param_2[1];
    *(longlong **)(lVar1 + 8) = plVar2;
    *plVar2 = lVar1;
    param_2[1] = 0;
    *param_2 = 0;
    *(longlong *)(param_1 + 0x38) =
         *(longlong *)(param_1 + 0x38) - (ulonglong)*(uint *)(param_2 + 0x47);
    if (param_2 == *(longlong **)(param_1 + 0x20)) {
      *(undefined8 *)(param_1 + 0x20) = 0;
    }
    if ((DAT_ & 0x10) == 0) {
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

