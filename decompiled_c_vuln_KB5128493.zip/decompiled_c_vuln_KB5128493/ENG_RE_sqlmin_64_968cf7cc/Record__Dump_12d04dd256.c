
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(short *param_1)

{
  byte bVar1;
  ushort uVar2;
  ulonglong *puVar3;
  ulonglong uVar4;
  ushort uVar5;
  uint uVar6;
  uint uVar7;
  ulonglong uVar8;
  ushort *puVar9;
  byte *pbVar10;
  longlong lVar11;
  int iVar12;
  longlong unaff_GS_OFFSET;
  
  iVar12 = 0;
  if (*param_1 == 0) {
    if (*(int *)(param_1 + 2) == 0) {
      pbVar10 = *(byte **)(param_1 + 4);
      uVar6 = *(uint *)(param_1 + 8);
      uVar8 = (ulonglong)uVar6;
      param_1[1] = 0;
      *(uint *)(param_1 + 10) = uVar6;
      bVar1 = *pbVar10;
      if ((bVar1 & 0x10) != 0) {
        uVar6 = uVar6 + 2 + (*(ushort *)(pbVar10 + uVar8) + 7 >> 3);
        uVar8 = (ulonglong)uVar6;
        *(uint *)(param_1 + 10) = uVar6;
        bVar1 = *pbVar10;
      }
      if ((bVar1 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar8;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar8;
      }
      else {
        puVar9 = (ushort *)(pbVar10 + uVar8);
        uVar2 = *puVar9;
        param_1[0xe] = uVar2;
        if (uVar2 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x9f5fc8,0xb15c98,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar8 = (ulonglong)*(uint *)(param_1 + 10);
          uVar2 = param_1[0xe];
        }
        uVar6 = (int)uVar8 + (uVar2 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar6;
        if (0x1f9e < uVar6) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x9f5fc8,0xb15c98,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar2 = param_1[0xe];
          uVar6 = *(uint *)(param_1 + 0xc);
        }
        uVar4 = (ulonglong)uVar2;
        uVar7 = puVar9[uVar4] & 0x7fff;
        *(uint *)(param_1 + 2) = uVar7;
        if (uVar7 < uVar6) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x9f5fc8,0xb15c98,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar4 = (ulonglong)(ushort)param_1[0xe];
          uVar7 = *(uint *)(param_1 + 2);
        }
        uVar8 = (ulonglong)uVar7;
        if ((short)puVar9[(ulonglong)((int)uVar4 - 1) + 1] < 0) {
          pbVar10 = *(byte **)(param_1 + 4);
          do {
            if ((int)uVar4 == 1) {
              uVar6 = *(uint *)(param_1 + 0xc);
              uVar7 = uVar6;
LAB_:
              if ((*(ushort *)(pbVar10 + uVar4 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff) <
                  uVar6) goto LAB_;
            }
            else {
              uVar7 = *(uint *)(param_1 + 0xc);
              uVar6 = *(ushort *)(pbVar10 + uVar4 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
                      0x7fff;
              if (uVar7 <= uVar6) goto LAB_;
LAB_:
              func_0x(pbVar10,7);
              uVar7 = *(uint *)(param_1 + 0xc);
            }
            if ((uVar6 < uVar7) ||
               (uVar8 = (ulonglong)*(uint *)(param_1 + 2), *(uint *)(param_1 + 2) < uVar6))
            goto LAB_;
            pbVar10 = *(byte **)(param_1 + 4);
            if (*(ushort *)(pbVar10 + uVar6) == 5) {
              param_1[1] = param_1[1] | 2;
              param_1[0xe] = param_1[0xe] + -1;
              param_1[0x15] = (short)uVar6;
              lVar11 = (ulonglong)(uVar6 & 0xffff) + *(longlong *)(param_1 + 4);
              uVar2 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar11 + 2) >> 0xe & 1) != 0) {
                uVar2 = *(ushort *)(lVar11 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar2;
              param_1[0x16] = (uVar2 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar2;
              uVar8 = (ulonglong)*(uint *)(param_1 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar10 + uVar6) < 0x400) goto LAB_;
            param_1[1] = param_1[1] | 1;
            uVar2 = param_1[0xe] - 1;
            param_1[0xe] = uVar2;
            if (uVar2 == 0) goto LAB_;
            uVar4 = (ulonglong)uVar2;
          } while ((short)puVar9[(ulonglong)(uVar2 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar10 = *(byte **)(param_1 + 4);
        }
      }
      if ((*pbVar10 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar8;
        *(int *)(param_1 + 2) = (int)uVar8 + 0xe;
        puVar3 = (ulonglong *)func_0x(param_1 + 1);
        uVar5 = (ushort)(*puVar3 >> 0x30);
        uVar2 = uVar5;
        if ((((uint)(int)(short)uVar5 >> 1 ^ (int)(short)uVar5) & 0x2000) != 0) {
          uVar2 = uVar5 & 0xdfff;
          if ((uVar5 >> 0xe & 1) != 0) {
            uVar2 = uVar5 | 0x2000;
          }
        }
        if (uVar2 == 0xfffc) {
          iVar12 = (int)((*puVar3 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar12;
        uVar8 = (ulonglong)*(uint *)(param_1 + 2);
      }
      iVar12 = (int)uVar8;
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar8 + *(longlong *)(param_1 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar11 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar11 != 0 &&
             (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x9f5fc8,0xb15c98,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        iVar12 = *(int *)(param_1 + 2);
      }
      if (0x3f3b < iVar12 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar11 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar11 != 0 &&
            ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
             (*(char *)(lVar11 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x9f5fc8,0xb15c98,0x87c,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
      }
    }
  }
  else if (*(int *)(param_1 + 2) == 0) {
    func_0x(param_1 + 1);
  }
LAB_:
  if ((**(byte **)(param_1 + 4) & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((**(byte **)(param_1 + 4) & 1) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  (*_DAT_)(1,0xb77300,0xbd3368,0x10b,0x7724a8);
  return 0;
}

