
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  uint uVar3;
  int iVar4;
  longlong unaff_GS_OFFSET;
  
  uVar3 = *(int *)(param_1 + 0x8c) + 1U & 0xf;
  *(uint *)(param_1 + 0x8c) = uVar3;
  if (uVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           0x100);
  if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(*(longlong *)(lVar1 + 600) + 0xbc) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x78) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x78) != 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(char *)(param_1 + 0x99) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x84) == 0) {
    plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x40) + 8);
    (**(code **)(*plVar2 + 0xb0))(plVar2,param_2);
  }
  *(undefined4 *)(param_1 + 0x84) = 0x40ec6;
  iVar4 = (**(code **)(***(longlong ***)(param_1 + 0x40) + 0x98))
                    (**(longlong ***)(param_1 + 0x40),param_2,param_2);
  *(int *)(param_1 + 0x80) = iVar4;
  if (iVar4 == 0x40ec6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar4 == 0x4ffff) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(param_1,param_2,1);
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x40) + 8);
  iVar4 = (**(code **)(*plVar2 + 0x98))(plVar2,param_2,0);
  *(int *)(param_1 + 0x84) = iVar4;
  if (iVar4 != 0x40ec6) {
    if (*(int *)(param_1 + 0x84) != 0x40ec6) {
      *(undefined4 *)(param_1 + 0x88) = 0;
      *(undefined4 *)(param_1 + 0x78) = 2;
      return 0;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

