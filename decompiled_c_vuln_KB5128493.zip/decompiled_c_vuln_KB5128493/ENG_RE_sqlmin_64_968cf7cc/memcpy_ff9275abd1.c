
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 param_1,undefined8 param_2,ulonglong param_3)

{
  if (param_3 < 0x10) {
                    /* WARNING: Could not emulate address calculation at 0x00100019 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)(param_3 * 4 + 0x32c29c0) + 0xfd9c0))();
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

