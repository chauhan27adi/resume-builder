
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,ulonglong param_2,longlong *param_3,longlong param_4)

{
  uint *puVar1;
  byte *pbVar2;
  undefined uVar3;
  byte bVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  ulonglong *puVar8;
  longlong *plVar9;
  undefined auVar10 [16];
  undefined auVar11 [16];
  undefined auVar12 [16];
  undefined auVar13 [16];
  uint uVar14;
  char cVar15;
  uint uVar16;
  longlong lVar17;
  undefined4 *puVar18;
  undefined8 uVar19;
  undefined4 *puVar20;
  longlong lVar21;
  byte bVar22;
  ulonglong uVar23;
  longlong lVar24;
  uint uVar25;
  undefined *puVar26;
  undefined uVar27;
  ushort uVar28;
  undefined8 unaff_RBX;
  longlong lVar29;
  undefined *puVar30;
  uint uVar31;
  uint *puVar32;
  code *pcVar33;
  longlong *plVar34;
  int iVar35;
  longlong lVar36;
  longlong unaff_GS_OFFSET;
  
  lVar17 = func_0x();
  lVar17 = -lVar17;
  puVar30 = &stack0xffffffffffffffc8 + lVar17;
  puVar1 = (uint *)(&stack0x00000028 + lVar17);
  *(undefined8 *)(&stack0x000000b0 + lVar17) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000082a0 + lVar17) = unaff_RBX;
  *(ulonglong *)(&stack0x00008248 + lVar17) = _DAT_ ^ (ulonglong)puVar1;
  *(longlong *)(&stack0x00000068 + lVar17) = param_4;
  *(longlong **)(&stack0x000000a8 + lVar17) = param_3;
  *(int *)(&stack0x00000040 + lVar17) = (int)param_2;
  *(longlong **)(&stack0x00000038 + lVar17) = param_1;
  puVar32 = *(uint **)(&stack0x000082b8 + lVar17);
  *(uint **)(&stack0x000000a0 + lVar17) = puVar32;
  lVar24 = *(longlong *)(*param_1 + 0x58);
  *(longlong *)(&stack0x00000060 + lVar17) = lVar24;
  uVar23 = 0;
  *(undefined4 *)(&stack0x00000030 + lVar17) = 0;
  puVar26 = &stack0xffffffffffffffc8 + lVar17;
  if (*(int *)(param_4 + 4) != 0) {
    do {
      puVar30 = puVar26;
      puVar18 = (undefined4 *)0x0;
      uVar19 = 0x83dc98;
      pcVar33 = (code *)puVar18;
      if (((int)param_2 == 1) &&
         (pcVar33 = (code *)0x0, (*(byte *)(*(longlong *)(lVar24 + 8) + 0x107) & 0x40) != 0)) {
        pcVar33 = FUN_;
      }
      *(ulonglong *)(&stack0x00000098 + lVar17) = uVar23 * 0x40;
      lVar36 = *(longlong *)(param_4 + 8) + uVar23 * 0x40;
      if ((*(byte *)(*param_3 + (uVar23 >> 3)) >> ((byte)uVar23 & 7) & 1) == 0) {
        param_4 = *(longlong *)(&stack0x00000068 + lVar17);
        goto LAB_;
      }
      *(undefined8 *)(puVar30 + -8) = 0x1000f4;
      func_0x(&stack0x00000138 + lVar17,&stack0x00000240 + lVar17);
      *(undefined8 *)(&stack0x00000138 + lVar17) = uVar19;
      uVar25 = *(uint *)(lVar36 + 8);
      if ((uVar25 & 0xc0000000) == 0x80000000) {
LAB_:
        uVar19 = **(undefined8 **)(*(longlong *)(lVar24 + 8) + 0x160);
        *(undefined8 *)(puVar30 + -8) = 0x100161;
        puVar18 = (undefined4 *)func_0x(uVar19,uVar25 & 0x1fffffff);
      }
      else {
        if ((int)uVar25 < (int)*puVar32) {
          *puVar32 = uVar25;
          uVar25 = (uint)*(ushort *)(lVar36 + 8);
        }
        uVar25 = (uint)(short)uVar25;
        if ((int)uVar25 < 0) {
          if ((uVar25 & 0xc0000000) == 0x80000000) goto LAB_;
          uVar19 = *(undefined8 *)(*(longlong *)(lVar24 + 8) + 0x160);
          *(undefined8 *)(puVar30 + -8) = 0x100146;
          puVar18 = (undefined4 *)func_0x(uVar19);
        }
      }
      uVar28 = *(ushort *)(puVar18 + 0xe);
      if ((uVar28 == 0xffff) ||
         (iVar35 = 1,
         *(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar18 + 0xd) + 0x8286b0) + 0x11ddd28)
         != '\0')) {
        iVar35 = 2;
      }
      *(int *)(&stack0x0000002c + lVar17) = iVar35;
      uVar25 = (uint)pcVar33;
      if ((*(byte *)(lVar36 + 0x2c) & 1) == 0) {
        if ((*(byte *)((longlong)puVar18 + 0x21) & 0x20) == 0) {
          *puVar1 = *(uint *)(lVar36 + 0x28);
          puVar26 = *(undefined **)(lVar36 + 0x20);
        }
        else {
          if (0x1f9e < uVar28) {
            uVar28 = 0x1f9e;
          }
          *puVar1 = (uint)uVar28;
          iVar5 = *(int *)(lVar36 + 0x28);
          puVar8 = *(ulonglong **)(lVar36 + 0x20);
          switch(*(undefined *)(puVar18 + 0xd)) {
          case 0x30:
            if (iVar5 == 0) {
              (&stack0x00004308)[lVar17] = 0;
              *puVar1 = 1;
            }
            else {
              (&stack0x00004308)[lVar17] = *(byte *)puVar8;
              *puVar1 = 1;
            }
            break;
          case 0x34:
            if (iVar5 == 0) {
              *(undefined2 *)(&stack0x00004308 + lVar17) = 0;
code_r0x00100358:
              *puVar1 = 2;
            }
            else if (iVar5 == 1) {
              *(ushort *)(&stack0x00004308 + lVar17) = (*(byte *)puVar8 >> 7) - 1;
              (&stack0x00004308)[lVar17] = *(byte *)puVar8 ^ 0x80;
              *puVar1 = 2;
            }
            else {
              if (iVar5 != 2) goto code_r0x00100358;
              (&stack0x00004309)[lVar17] = *(byte *)puVar8 ^ 0x80;
              (&stack0x00004308)[lVar17] = *(byte *)((longlong)puVar8 + 1);
              *puVar1 = 2;
            }
            break;
          case 0x38:
          case 0x7a:
            if (iVar5 == 0) {
              *(undefined4 *)(&stack0x00004308 + lVar17) = 0;
              *puVar1 = 4;
            }
            else if (iVar5 == 1) {
              *(uint *)(&stack0x00004308 + lVar17) = (*(byte *)puVar8 >> 7) - 1;
              (&stack0x00004308)[lVar17] = *(byte *)puVar8 ^ 0x80;
              *puVar1 = 4;
            }
            else if (iVar5 == 2) {
              *(uint *)(&stack0x00004308 + lVar17) = (*(byte *)puVar8 >> 7) - 1;
              (&stack0x00004309)[lVar17] = *(byte *)puVar8 ^ 0x80;
              (&stack0x00004308)[lVar17] = *(byte *)((longlong)puVar8 + 1);
              *puVar1 = 4;
            }
            else if (iVar5 == 3) {
              *(uint *)(&stack0x00004308 + lVar17) = (*(byte *)puVar8 >> 7) - 1;
              (&stack0x0000430a)[lVar17] = *(byte *)puVar8 ^ 0x80;
              (&stack0x00004309)[lVar17] = *(byte *)((longlong)puVar8 + 1);
              (&stack0x00004308)[lVar17] = *(byte *)((longlong)puVar8 + 2);
              *puVar1 = 4;
            }
            else {
              if (iVar5 != 4) goto code_r0x0010066e;
              uVar16 = *(uint *)puVar8;
              *(uint *)(&stack0x00004308 + lVar17) =
                   uVar16 >> 0x18 | (uVar16 & 0xff0000) >> 8 | (uVar16 & 0xff00) << 8 |
                   uVar16 << 0x18;
              (&stack0x0000430b)[lVar17] = (byte)uVar16 ^ 0x80;
              *puVar1 = 4;
            }
            break;
          case 0x3a:
            if (iVar5 == 4) {
              *(uint *)(&stack0x00004308 + lVar17) = *(uint *)puVar8;
              *puVar1 = 4;
            }
            else {
              *(undefined2 *)(&stack0x00004308 + lVar17) = 0;
code_r0x00100568:
              *(undefined2 *)(&stack0x0000430a + lVar17) = *(undefined2 *)puVar8;
              *puVar1 = 4;
            }
            break;
          case 0x3b:
            *(undefined4 *)(&stack0x00004308 + lVar17) = 0;
            if (iVar5 == 1) {
              (&stack0x0000430b)[lVar17] = *(byte *)puVar8;
code_r0x0010066e:
              *puVar1 = 4;
            }
            else {
              if (iVar5 == 2) goto code_r0x00100568;
              if (iVar5 == 3) {
                *(undefined2 *)(&stack0x00004309 + lVar17) = *(undefined2 *)puVar8;
                (&stack0x0000430b)[lVar17] = *(byte *)((longlong)puVar8 + 2);
                *puVar1 = 4;
              }
              else {
                if (iVar5 != 4) goto code_r0x0010066e;
                *(uint *)(&stack0x00004308 + lVar17) = *(uint *)puVar8;
                *puVar1 = 4;
              }
            }
            break;
          case 0x3c:
          case 0x3d:
          case 0x7f:
            switch(iVar5) {
            case 0:
              *(undefined8 *)(&stack0x00004308 + lVar17) = 0;
              *puVar1 = 8;
              break;
            case 1:
              *(ulonglong *)(&stack0x00004308 + lVar17) = (ulonglong)(*(byte *)puVar8 >> 7) - 1;
              (&stack0x00004308)[lVar17] = *(byte *)puVar8 ^ 0x80;
              *puVar1 = 8;
              break;
            case 2:
              *(ulonglong *)(&stack0x00004308 + lVar17) = (ulonglong)(*(byte *)puVar8 >> 7) - 1;
              (&stack0x00004309)[lVar17] = *(byte *)puVar8 ^ 0x80;
              (&stack0x00004308)[lVar17] = *(byte *)((longlong)puVar8 + 1);
              *puVar1 = 8;
              break;
            case 3:
              *(ulonglong *)(&stack0x00004308 + lVar17) = (ulonglong)(*(byte *)puVar8 >> 7) - 1;
              (&stack0x0000430a)[lVar17] = *(byte *)puVar8 ^ 0x80;
              (&stack0x00004309)[lVar17] = *(byte *)((longlong)puVar8 + 1);
              (&stack0x00004308)[lVar17] = *(byte *)((longlong)puVar8 + 2);
              *puVar1 = 8;
              break;
            case 4:
              *(ulonglong *)(&stack0x00004308 + lVar17) = (ulonglong)(*(byte *)puVar8 >> 7) - 1;
              uVar16 = *(uint *)puVar8;
              *(uint *)(&stack0x00004308 + lVar17) =
                   uVar16 >> 0x18 | (uVar16 & 0xff0000) >> 8 | (uVar16 & 0xff00) << 8 |
                   uVar16 << 0x18;
              (&stack0x0000430b)[lVar17] = *(byte *)puVar8 ^ 0x80;
              *puVar1 = 8;
              break;
            case 5:
              *(ulonglong *)(&stack0x00004308 + lVar17) = (ulonglong)(*(byte *)puVar8 >> 7) - 1;
              (&stack0x0000430c)[lVar17] = *(byte *)puVar8 ^ 0x80;
              uVar16 = *(uint *)((longlong)puVar8 + 1);
              *(uint *)(&stack0x00004308 + lVar17) =
                   uVar16 >> 0x18 | (uVar16 & 0xff0000) >> 8 | (uVar16 & 0xff00) << 8 |
                   uVar16 << 0x18;
              *puVar1 = 8;
              break;
            case 6:
              *(ulonglong *)(&stack0x00004308 + lVar17) = (ulonglong)(*(byte *)puVar8 >> 7) - 1;
              (&stack0x0000430d)[lVar17] = *(byte *)puVar8 ^ 0x80;
              (&stack0x0000430c)[lVar17] = *(byte *)((longlong)puVar8 + 1);
              uVar16 = *(uint *)((longlong)puVar8 + 2);
              *(uint *)(&stack0x00004308 + lVar17) =
                   uVar16 >> 0x18 | (uVar16 & 0xff0000) >> 8 | (uVar16 & 0xff00) << 8 |
                   uVar16 << 0x18;
              *puVar1 = 8;
              break;
            case 7:
              *(ulonglong *)(&stack0x00004308 + lVar17) = (ulonglong)(*(byte *)puVar8 >> 7) - 1;
              (&stack0x0000430e)[lVar17] = *(byte *)puVar8 ^ 0x80;
              (&stack0x0000430d)[lVar17] = *(byte *)((longlong)puVar8 + 1);
              (&stack0x0000430c)[lVar17] = *(byte *)((longlong)puVar8 + 2);
              uVar16 = *(uint *)((longlong)puVar8 + 3);
              *(uint *)(&stack0x00004308 + lVar17) =
                   uVar16 >> 0x18 | (uVar16 & 0xff0000) >> 8 | (uVar16 & 0xff00) << 8 |
                   uVar16 << 0x18;
              *puVar1 = 8;
              break;
            case 8:
              uVar23 = *puVar8;
              *(ulonglong *)(&stack0x00004308 + lVar17) =
                   uVar23 >> 0x38 | (uVar23 & 0xff000000000000) >> 0x28 |
                   (uVar23 & 0xff0000000000) >> 0x18 | (uVar23 & 0xff00000000) >> 8 |
                   (uVar23 & 0xff000000) << 8 | (uVar23 & 0xff0000) << 0x18 |
                   (uVar23 & 0xff00) << 0x28 | uVar23 << 0x38;
              (&stack0x0000430f)[lVar17] = (byte)uVar23 ^ 0x80;
              *puVar1 = 8;
              break;
            default:
              goto code_r0x00100773;
            }
            break;
          case 0x3e:
            *(undefined8 *)(&stack0x00004308 + lVar17) = 0;
            switch(iVar5) {
            case 1:
              (&stack0x0000430f)[lVar17] = *(byte *)puVar8;
              *puVar1 = 8;
              break;
            case 2:
              *(undefined2 *)(&stack0x0000430e + lVar17) = *(undefined2 *)puVar8;
              *puVar1 = 8;
              break;
            case 3:
              *(undefined2 *)(&stack0x0000430d + lVar17) = *(undefined2 *)puVar8;
              (&stack0x0000430f)[lVar17] = *(byte *)((longlong)puVar8 + 2);
              *puVar1 = 8;
              break;
            case 4:
              *(uint *)(&stack0x0000430c + lVar17) = *(uint *)puVar8;
              *puVar1 = 8;
              break;
            case 5:
              *(uint *)(&stack0x0000430b + lVar17) = *(uint *)puVar8;
              (&stack0x0000430f)[lVar17] = *(byte *)((longlong)puVar8 + 4);
              *puVar1 = 8;
              break;
            case 6:
              *(uint *)(&stack0x0000430a + lVar17) = *(uint *)puVar8;
              *(undefined2 *)(&stack0x0000430e + lVar17) = *(undefined2 *)((longlong)puVar8 + 4);
              *puVar1 = 8;
              break;
            case 7:
              *(uint *)(&stack0x00004309 + lVar17) = *(uint *)puVar8;
              *(undefined2 *)(&stack0x0000430d + lVar17) = *(undefined2 *)((longlong)puVar8 + 4);
              (&stack0x0000430f)[lVar17] = *(byte *)((longlong)puVar8 + 6);
              *puVar1 = 8;
              break;
            case 8:
              *(ulonglong *)(&stack0x00004308 + lVar17) = *puVar8;
            default:
code_r0x00100773:
              *puVar1 = 8;
            }
            break;
          case 0x6a:
          case 0x6c:
            *(uint **)(puVar30 + 0x28) = puVar1;
            *(undefined **)(puVar30 + 0x20) = &stack0x00004308 + lVar17;
            uVar27 = *(undefined *)((longlong)puVar18 + 0x36);
            uVar3 = *(undefined *)((longlong)puVar18 + 0x35);
            *(undefined8 *)(puVar30 + -8) = 0x1007a4;
            cVar15 = (*pcRam000000000071f1e0)(puVar8,iVar5,uVar3,uVar27);
            if (cVar15 == '\0') {
              *(undefined8 *)(puVar30 + -8) = 0x1007be;
              (*pcRam00000000007215d8)(6,0x54,0x16,1);
            }
            break;
          case 0xad:
          case 0xaf:
            puVar30[0x20] = *(undefined *)(puVar18 + 0xd);
            uVar16 = *puVar1;
            *(undefined8 *)(puVar30 + -8) = 0x10059a;
            func_0x(puVar8,iVar5,&stack0x00004308 + lVar17,uVar16);
            break;
          case 0xbd:
            *(undefined8 *)(puVar30 + -8) = 0x1005d4;
            func_0x(puVar8,iVar5,&stack0x00004308 + lVar17);
            *puVar1 = 8;
            break;
          case 0xe7:
            *(uint *)(puVar30 + 0x20) = (uint)uVar28;
            *(undefined8 *)(puVar30 + -8) = 0x1007df;
            uVar16 = (*pcRam000000000071f1d8)
                               (&stack0x00000100 + lVar17,puVar8,iVar5,&stack0x00004308 + lVar17);
            *puVar1 = uVar16;
            break;
          case 0xef:
            *(uint *)(puVar30 + 0x20) = *puVar1;
            *(undefined8 *)(puVar30 + -8) = 0x1005c0;
            (*pcRam000000000071f1e8)
                      (&stack0x000000c8 + lVar17,puVar8,iVar5,&stack0x00004308 + lVar17);
          }
          puVar26 = &stack0x00004308 + lVar17;
        }
        uVar16 = *puVar1;
        *(undefined8 *)(&stack0x00000070 + lVar17) = 0xa15cc0;
        *(undefined8 *)(&stack0x00000070 + lVar17) = 0x823678;
        *(undefined4 *)(&stack0x00000078 + lVar17) = 1;
        *(undefined4 *)(&stack0x0000007c + lVar17) = 1;
        *(undefined8 *)(&stack0x00000070 + lVar17) = 0x823588;
        *(undefined4 *)(&stack0x0000007c + lVar17) = 1;
        *(undefined8 *)(puVar30 + -8) = 0x100831;
        (*_DAT_)(&stack0x00000070 + lVar17,puVar26,uVar16);
        (&stack0x00000080)[lVar17] = 0;
        uVar28 = *(ushort *)((longlong)puVar18 + 0x3a);
        uVar6 = *(undefined4 *)(lVar36 + 8);
        *(undefined4 *)(&stack0x000001c0 + lVar17) = 0;
        *(undefined2 *)(&stack0x000001c4 + lVar17) = 0;
        *(undefined4 *)(puVar30 + 0x40) = 0;
        *(ulonglong *)(puVar30 + 0x38) = (ulonglong)uVar28;
        *(int *)(puVar30 + 0x30) = iVar35;
        *(uint *)(puVar30 + 0x28) = uVar25 | 8;
        *(undefined4 *)(puVar30 + 0x20) = uVar6;
        plVar34 = *(longlong **)(&stack0x00000038 + lVar17);
        lVar24 = *plVar34;
        *(undefined8 *)(puVar30 + -8) = 0x10087d;
        func_0x(&stack0x00000138 + lVar17,lVar24,0,0);
        pcVar33 = *(code **)(*(longlong *)(&stack0x00000138 + lVar17) + 0x38);
        *(undefined8 *)(puVar30 + -8) = 0x10088e;
        uVar19 = (*pcVar33)(&stack0x00000138 + lVar17);
        *(undefined **)(puVar30 + 0x20) = &stack0x000000b8 + lVar17;
        *(undefined8 *)(puVar30 + -8) = 0x1008af;
        func_0x(&stack0x00000138 + lVar17,0,&stack0x00000070 + lVar17,uVar19);
        *(undefined8 *)(&stack0x00000070 + lVar17) = 0x823588;
        if ((&stack0x00000080)[lVar17] != '\0') {
          uVar19 = *(undefined8 *)(&stack0x00000088 + lVar17);
          *(undefined8 *)(puVar30 + -8) = 0x1008c9;
          (*_DAT_)(uVar19,1);
        }
        *(undefined8 *)(&stack0x00000070 + lVar17) = 0x823678;
      }
      else {
        uVar28 = *(ushort *)((longlong)puVar18 + 0x3a);
        uVar23 = (ulonglong)uVar28;
        if (iVar35 == 2) {
          bVar22 = *(byte *)(*(longlong *)(lVar24 + 8) + 0x41);
          if (((((bVar22 & 0x40) == 0) &&
               (bVar4 = *(byte *)(*(longlong *)(lVar24 + 8) + 0x109), (bVar4 & 2) == 0)) &&
              (-1 < (char)bVar22)) && ((bVar4 & 1) == 0)) goto LAB_;
          uVar6 = *(undefined4 *)(lVar36 + 0x28);
          *(undefined8 *)(&stack0x00000058 + lVar17) = 0;
          uVar16 = *(uint *)(lVar36 + 0x28);
          if (uVar16 < 0x1f9f) {
            lVar24 = *(longlong *)(lVar36 + 0x20);
            if (uVar16 != 0) {
              if ((lVar24 == 0) || (0x1f9e < uVar16)) {
                *(undefined8 *)(puVar30 + -8) = 0x10095e;
                func_0x(&stack0x000062a8 + lVar17,0,0x1f9e);
                if (lVar24 == 0) {
                  *(undefined8 *)(puVar30 + -8) = 0x10096d;
                  puVar20 = (undefined4 *)(*_DAT_)();
                  *puVar20 = 0x16;
                }
                else {
                  if (uVar16 < 0x1f9f) goto LAB_;
                  *(undefined8 *)(puVar30 + -8) = 0x100b5d;
                  puVar20 = (undefined4 *)(*_DAT_)();
                  *puVar20 = 0x22;
                }
                *(undefined8 *)(puVar30 + -8) = 0x100979;
                (*_DAT_)();
              }
              else {
                *(undefined8 *)(puVar30 + -8) = 0x100948;
                func_0x(&stack0x000062a8 + lVar17,lVar24,uVar16);
              }
            }
          }
          else {
            *(undefined8 *)(puVar30 + 0x20) = 0xc7fdc0;
            *(undefined8 *)(puVar30 + -8) = 0x100b93;
            (*_DAT_)(1,0xc2d3c4,0xc2ae10,0x1154);
          }
LAB_:
          *(undefined4 *)(&stack0x00000048 + lVar17) = 0;
          *(undefined2 *)(&stack0x0000004c + lVar17) = 0;
          uVar16 = puVar18[0xf];
          *(undefined **)(puVar30 + 0x50) = &stack0x00000048 + lVar17;
          *(undefined4 *)(puVar30 + 0x48) = 0;
          *(undefined **)(puVar30 + 0x40) = &stack0x00000058 + lVar17;
          *(uint *)(puVar30 + 0x38) = uVar25;
          *(ulonglong *)(puVar30 + 0x30) = (ulonglong)uVar16;
          *(undefined4 *)(puVar30 + 0x28) = uVar6;
          *(undefined **)(puVar30 + 0x20) = &stack0x000062a8 + lVar17;
          uVar19 = **(undefined8 **)(&stack0x00000038 + lVar17);
          *(undefined8 *)(puVar30 + -8) = 0x1009cd;
          func_0x(0,0,uVar19,1);
          uVar16 = *(uint *)(lVar36 + 0x28);
          uVar7 = *puVar18;
          uVar19 = *(undefined8 *)(lVar36 + 0x20);
          *(undefined4 *)(&stack0x000001c0 + lVar17) = 0;
          *(undefined2 *)(&stack0x000001c4 + lVar17) = 0;
          *(undefined4 *)(puVar30 + 0x40) = 0;
          *(ulonglong *)(puVar30 + 0x38) = (ulonglong)uVar16;
          *(undefined4 *)(puVar30 + 0x30) = *(undefined4 *)(&stack0x0000002c + lVar17);
          *(uint *)(puVar30 + 0x28) = uVar25 | 8;
          *(undefined4 *)(puVar30 + 0x20) = uVar7;
          plVar34 = *(longlong **)(&stack0x00000038 + lVar17);
          lVar24 = *plVar34;
          *(undefined8 *)(puVar30 + -8) = 0x100a17;
          func_0x(&stack0x00000138 + lVar17,lVar24,uVar19);
          pcVar33 = *(code **)(*(longlong *)(&stack0x00000138 + lVar17) + 0x38);
          *(undefined8 *)(puVar30 + -8) = 0x100a28;
          uVar19 = (*pcVar33)(&stack0x00000138 + lVar17);
          *(undefined **)(puVar30 + 0x20) = &stack0x000000c0 + lVar17;
          plVar9 = *(longlong **)(&stack0x00000058 + lVar17);
          *(undefined8 *)(puVar30 + -8) = 0x100a4c;
          func_0x(&stack0x00000138 + lVar17,0,plVar9,uVar19);
          if (uVar28 == 0x10) {
            *(uint *)(&stack0x00000174 + lVar17) = *(uint *)(&stack0x00000174 + lVar17) & 0xfffff7ff
            ;
            *(undefined8 *)(&stack0x00000230 + lVar17) = 0;
            *(undefined4 *)(&stack0x00000200 + lVar17) = 1;
            *(undefined4 *)(&stack0x00000204 + lVar17) = 0x1f68;
            *(undefined4 *)(&stack0x00000208 + lVar17) = 0x1f5;
LAB_:
            *(undefined4 *)(&stack0x00000210 + lVar17) = 0x40;
            *(undefined4 *)(&stack0x0000020c + lVar17) = 5;
          }
          else {
            *(ulonglong *)(&stack0x00000230 + lVar17) = uVar23;
            bVar22 = *(byte *)(*(longlong *)(&stack0x00000148 + lVar17) + 0x79);
            *(undefined4 *)(&stack0x00000200 + lVar17) = 1;
            *(undefined4 *)(&stack0x00000204 + lVar17) = 0x1f68;
            *(undefined4 *)(&stack0x00000208 + lVar17) = 0x1f5;
            if (uVar28 == 0) goto LAB_;
            if ((bVar22 & 8) == 0) {
              auVar10._8_8_ = 0;
              auVar10._0_8_ = uVar23 - 0xc;
              uVar23 = SUB168(ZEXT816(0xaaaaaaaaaaaaaaab) * auVar10,8);
              uVar25 = 5;
            }
            else {
              auVar11._8_8_ = 0;
              auVar11._0_8_ = uVar23 - 0xc;
              uVar23 = SUB168(ZEXT816(0xaaaaaaaaaaaaaaab) * auVar11,8);
              uVar25 = 0x1f5;
            }
            uVar16 = (uint)(uVar23 >> 3);
            if (uVar16 < uVar25) {
              uVar25 = uVar16;
            }
            *(uint *)(&stack0x0000020c + lVar17) = uVar25;
            *(undefined4 *)(&stack0x00000210 + lVar17) = *(undefined4 *)(&stack0x00000230 + lVar17);
          }
          *(undefined8 *)(puVar30 + -8) = 0x100aa4;
          func_0x(&stack0x00000138 + lVar17);
          *(undefined4 *)(puVar30 + 0x20) = puVar18[0xf];
          *(undefined8 *)(puVar30 + -8) = 0x100ac1;
          cVar15 = func_0x(plVar34,&stack0x000062a8 + lVar17,uVar6,1);
          if (cVar15 != '\0') {
            *(undefined8 *)(puVar30 + -8) = 0x100ad8;
            func_0x(&stack0x000021d8 + lVar17,&stack0x000022e0 + lVar17);
            *(undefined8 *)(&stack0x000021d8 + lVar17) = 0x83dc98;
            *(undefined4 *)(puVar30 + 0x28) = 0;
            *(undefined4 *)(puVar30 + 0x20) = *puVar18;
            lVar24 = *plVar34;
            *(undefined8 *)(puVar30 + -8) = 0x100b0d;
            func_0x
                      (&stack0x000021d8 + lVar17,lVar24,&stack0x000062a8 + lVar17,uVar6);
            *(undefined8 *)(puVar30 + -8) = 0x100b19;
            func_0x(&stack0x000021d8 + lVar17);
            *(undefined8 *)(puVar30 + -8) = 0x100b25;
            func_0x(&stack0x000021d8 + lVar17);
            *(undefined8 *)(puVar30 + -8) = 0x100b32;
            func_0x(&stack0x000021d8 + lVar17);
          }
          if (plVar9 != (longlong *)0x0) {
            pcVar33 = *(code **)(*plVar9 + 0x10);
            *(undefined8 *)(puVar30 + -8) = 0x100b45;
            (*pcVar33)(plVar9);
          }
        }
        else {
LAB_:
          uVar16 = *(uint *)(lVar36 + 0x28);
          uVar6 = *puVar18;
          uVar19 = *(undefined8 *)(lVar36 + 0x20);
          *(undefined4 *)(&stack0x000001c0 + lVar17) = 0;
          *(undefined2 *)(&stack0x000001c4 + lVar17) = 0;
          *(undefined4 *)(puVar30 + 0x40) = 0;
          *(ulonglong *)(puVar30 + 0x38) = (ulonglong)uVar16;
          *(int *)(puVar30 + 0x30) = iVar35;
          *(uint *)(puVar30 + 0x28) = uVar25;
          *(undefined4 *)(puVar30 + 0x20) = uVar6;
          plVar34 = *(longlong **)(&stack0x00000038 + lVar17);
          lVar24 = *plVar34;
          *(undefined8 *)(puVar30 + -8) = 0x100c5a;
          func_0x(&stack0x00000138 + lVar17,lVar24,uVar19);
          if (uVar28 == 0x10) {
            *(uint *)(&stack0x00000174 + lVar17) = *(uint *)(&stack0x00000174 + lVar17) & 0xfffff7ff
            ;
            *(undefined8 *)(&stack0x00000230 + lVar17) = 0;
            *(undefined4 *)(&stack0x00000200 + lVar17) = 1;
            *(undefined4 *)(&stack0x00000204 + lVar17) = 0x1f68;
            *(undefined4 *)(&stack0x00000208 + lVar17) = 0x1f5;
LAB_:
            *(undefined4 *)(&stack0x00000210 + lVar17) = 0x40;
            *(undefined4 *)(&stack0x0000020c + lVar17) = 5;
          }
          else {
            *(ulonglong *)(&stack0x00000230 + lVar17) = uVar23;
            bVar22 = *(byte *)(*(longlong *)(&stack0x00000148 + lVar17) + 0x79);
            *(undefined4 *)(&stack0x00000200 + lVar17) = 1;
            *(undefined4 *)(&stack0x00000204 + lVar17) = 0x1f68;
            *(undefined4 *)(&stack0x00000208 + lVar17) = 0x1f5;
            if (uVar28 == 0) goto LAB_;
            if ((bVar22 & 8) == 0) {
              auVar12._8_8_ = 0;
              auVar12._0_8_ = uVar23 - 0xc;
              uVar23 = SUB168(ZEXT816(0xaaaaaaaaaaaaaaab) * auVar12,8);
              uVar25 = 5;
            }
            else {
              auVar13._8_8_ = 0;
              auVar13._0_8_ = uVar23 - 0xc;
              uVar23 = SUB168(ZEXT816(0xaaaaaaaaaaaaaaab) * auVar13,8);
              uVar25 = 0x1f5;
            }
            uVar16 = (uint)(uVar23 >> 3);
            if (uVar16 < uVar25) {
              uVar25 = uVar16;
            }
            *(uint *)(&stack0x0000020c + lVar17) = uVar25;
            *(undefined4 *)(&stack0x00000210 + lVar17) = *(undefined4 *)(&stack0x00000230 + lVar17);
          }
          *(undefined8 *)(puVar30 + -8) = 0x100cb2;
          func_0x(&stack0x00000138 + lVar17);
        }
      }
      uVar25 = 0;
      if ((((*(uint *)(&stack0x00000174 + lVar17) & 0x800) == 0) ||
          (*(int *)(&stack0x00000158 + lVar17) != 0)) ||
         (*(short *)(&stack0x0000015c + lVar17) != 0)) {
        uVar28 = 0x10;
LAB_:
        uVar25 = 1;
      }
      else {
        lVar24 = *(longlong *)(&stack0x00000188 + lVar17);
        if ((*(byte *)(lVar24 + 0xc) & 0xf) != 0) {
          uVar28 = (*(short *)(lVar24 + 0x10) + 1) * 0xc;
          goto LAB_;
        }
        uVar28 = *(ushort *)(lVar24 + 0xe);
      }
      if (*(uint *)(lVar36 + 0x28) < (uint)uVar28) {
        *(undefined8 *)(puVar30 + 0x20) = 0;
        *(undefined8 *)(puVar30 + -8) = 0x100dc4;
        (*_DAT_)(1,0xc7fdf0,0xc2ae10,0x11b3);
      }
      uVar23 = (ulonglong)uVar28 + 0xf;
      if (uVar23 <= uVar28) {
        uVar23 = 0xffffffffffffff0;
      }
      uVar23 = uVar23 & 0xfffffffffffffff0;
      *(undefined8 *)(puVar30 + -8) = 0x100deb;
      func_0x();
      lVar36 = -uVar23;
      puVar26 = puVar30 + lVar36 + 0x60;
      uVar16 = (uint)uVar28;
      *(undefined8 *)(puVar30 + lVar36 + -8) = 0x100e04;
      func_0x(&stack0x00000138 + lVar17,uVar28,puVar26);
      *(undefined8 *)(puVar30 + lVar36 + -8) = 0x100e10;
      func_0x(&stack0x00000138 + lVar17);
      lVar24 = *plVar34;
      if (*_DAT_ != '\0') {
        lVar21 = *(longlong *)(lVar24 + 0x20) + 1;
        *(longlong *)(lVar24 + 0x20) = lVar21;
        if (lVar21 < 0x65) {
          *(undefined4 *)(lVar24 + 8) = 1;
        }
        else {
          *(undefined8 *)(puVar30 + lVar36 + -8) = 0x100e39;
          func_0x(lVar24);
          *(undefined4 *)(lVar24 + 8) = 0;
          *(undefined8 *)(lVar24 + 0x10) = 0;
          *(undefined8 *)(lVar24 + 0x18) = 0;
          *(undefined8 *)(lVar24 + 0x20) = 0;
          *(undefined8 *)(lVar24 + 0x28) = 0;
        }
      }
      if ((uVar25 != 0) && (*(int *)(&stack0x0000002c + lVar17) == 2)) {
        lVar24 = *(longlong *)(*(longlong *)(&stack0x00000060 + lVar17) + 8);
        bVar22 = *(byte *)(lVar24 + 0x41) & 0x40;
        if ((bVar22 != 0) ||
           ((((*(byte *)(lVar24 + 0x109) & 2) != 0 || ((char)*(byte *)(lVar24 + 0x41) < '\0')) ||
            ((*(byte *)(lVar24 + 0x109) & 1) != 0)))) {
          *(undefined (*) [16])(&stack0x00004278 + lVar17) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00004288 + lVar17) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00004298 + lVar17) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x000042a8 + lVar17) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x000042b8 + lVar17) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x000042c8 + lVar17) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x000042d8 + lVar17) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x000042e8 + lVar17) = ZEXT816(0);
          *(undefined4 *)(&stack0x000042f8 + lVar17) = 0;
          *(undefined2 *)(&stack0x000042fc + lVar17) = 0;
          if ((bVar22 != 0) || (uVar27 = 2, (*(byte *)(lVar24 + 0x109) & 2) != 0)) {
            uVar27 = 1;
          }
          (&stack0x00004278)[lVar17] = (char)uVar25;
          *(undefined4 *)(&stack0x0000427c + lVar17) = puVar18[0xf];
          *(uint *)(&stack0x00004280 + lVar17) = uVar16;
          *(undefined8 *)(puVar30 + lVar36 + -8) = 0x100f1f;
          func_0x(&stack0x00004284 + lVar17,uVar28,puVar26,uVar28);
          plVar34 = *(longlong **)(*plVar34 + 0x170);
          lVar24 = *plVar34;
          *(undefined4 *)(puVar30 + lVar36 + 0x28) = 0;
          *(undefined8 *)(puVar30 + lVar36 + 0x20) = 0;
          pcVar33 = *(code **)(lVar24 + 0x10);
          *(undefined8 *)(puVar30 + lVar36 + -8) = 0x100f4b;
          (*pcVar33)(plVar34,&stack0x00004278 + lVar17,0x86,uVar27);
        }
      }
      param_4 = *(longlong *)(&stack0x00000068 + lVar17);
      lVar24 = *(longlong *)(param_4 + 8);
      lVar21 = *(longlong *)(&stack0x00000098 + lVar17);
      bVar22 = *(byte *)(lVar24 + 0x18 + lVar21);
      uVar31 = (uint)uVar28;
      if ((bVar22 & 2) == 0) {
        if (*(uint *)(lVar24 + 0x28 + lVar21) < uVar31) {
          *(undefined8 *)(puVar30 + lVar36 + 0x20) = 0;
          *(undefined8 *)(puVar30 + lVar36 + -8) = 0x100f90;
          (*_DAT_)(1,0xc7fe38,0xc4ec80,0x84);
          lVar24 = *(longlong *)(param_4 + 8);
        }
        uVar16 = *(uint *)(lVar24 + 0x28 + lVar21);
        uVar14 = uVar31;
        if (uVar16 <= uVar31) {
          uVar14 = uVar16;
        }
        uVar19 = *(undefined8 *)(lVar24 + 0x20 + lVar21);
        *(undefined8 *)(puVar30 + lVar36 + -8) = 0x100faf;
        func_0x(uVar19,uVar16,puVar26,uVar14);
        *(uint *)(*(longlong *)(param_4 + 8) + 0x28 + lVar21) = uVar31;
        lVar24 = *(longlong *)(param_4 + 8);
        puVar32 = (uint *)(lVar24 + 0x2c + lVar21);
        *puVar32 = *puVar32 & 0xfffffffe;
        puVar32 = (uint *)(lVar24 + 0x2c + lVar21);
        *puVar32 = *puVar32 | uVar25;
      }
      else {
        if ((bVar22 & 4) != 0) {
          *(undefined8 *)(puVar30 + lVar36 + 0x20) = 0;
          *(undefined8 *)(puVar30 + lVar36 + -8) = 0x100ff8;
          (*_DAT_)(1,0xc7fe18,0xc4ec80,0x93);
        }
        if (*(uint *)(param_4 + 0x20) < *(int *)(param_4 + 0x10) + uVar16) {
          lVar29 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar24 = *(longlong *)(lVar29 + 0x100);
          if (lVar24 == 0) {
            *(undefined8 *)(puVar30 + lVar36 + -8) = 0x101037;
            (*_DAT_)(0);
            lVar24 = *(longlong *)(lVar29 + 0x100);
          }
          puVar30[lVar36 + 0x20] = 5;
          uVar19 = *(undefined8 *)(lVar24 + 1000);
          *(undefined8 *)(puVar30 + lVar36 + -8) = 0x101062;
          uVar19 = (*_DAT_)(0x1f9e,uVar19,0xbc1918,0x98);
          *(undefined8 *)(param_4 + 0x18) = uVar19;
          *(undefined4 *)(param_4 + 0x10) = 0;
          pbVar2 = (byte *)(*(longlong *)(param_4 + 8) + 0x18 + lVar21);
          *pbVar2 = *pbVar2 | 4;
          *(undefined4 *)(param_4 + 0x20) = 0x1f9e;
        }
        pbVar2 = (byte *)(*(longlong *)(param_4 + 8) + 0x18 + lVar21);
        *pbVar2 = *pbVar2 & 0xfd;
        lVar21 = *(longlong *)(param_4 + 8) + lVar21;
        *(ulonglong *)(lVar21 + 0x20) =
             (ulonglong)*(uint *)(param_4 + 0x10) + *(longlong *)(param_4 + 0x18);
        *(uint *)(lVar21 + 0x28) = uVar16;
        uVar16 = *(uint *)(lVar21 + 0x2c);
        *(uint *)(lVar21 + 0x2c) = uVar25 | uVar16 & 0xfffffffa;
        *(undefined4 *)(lVar21 + 0x30) = *(undefined4 *)(lVar21 + 8);
        *(undefined4 *)(lVar21 + 0x34) = *(undefined4 *)(lVar21 + 0xc);
        *(undefined4 *)(lVar21 + 0x38) = *(undefined4 *)(lVar21 + 0x10);
        *(undefined4 *)(lVar21 + 0x3c) = *(undefined4 *)(lVar21 + 0x14);
        *(uint *)(lVar21 + 0x2c) = uVar25 | uVar16 & 0xfffffff0;
        uVar25 = *(uint *)(param_4 + 0x10);
        iVar35 = *(int *)(param_4 + 0x20);
        lVar24 = *(longlong *)(param_4 + 0x18);
        *(undefined8 *)(puVar30 + lVar36 + -8) = 0x1010d5;
        func_0x((ulonglong)uVar25 + lVar24,iVar35 - uVar25,puVar26,uVar28);
        *(int *)(param_4 + 0x10) = *(int *)(param_4 + 0x10) + uVar31;
      }
      *(undefined8 *)(puVar30 + lVar36 + -8) = 0x1010e5;
      func_0x(&stack0x00000138 + lVar17);
      lVar24 = *(longlong *)(&stack0x00000060 + lVar17);
      uVar23 = (ulonglong)*(uint *)(&stack0x00000030 + lVar17);
      puVar32 = *(uint **)(&stack0x000000a0 + lVar17);
      param_3 = *(longlong **)(&stack0x000000a8 + lVar17);
      puVar30 = puVar30 + lVar36;
LAB_:
      uVar25 = (int)uVar23 + 1;
      uVar23 = (ulonglong)uVar25;
      *(uint *)(&stack0x00000030 + lVar17) = uVar25;
      param_2 = (ulonglong)*(uint *)(&stack0x00000040 + lVar17);
      puVar26 = puVar30;
    } while (uVar25 < *(uint *)(param_4 + 4));
  }
  uVar23 = *(ulonglong *)(&stack0x00008248 + lVar17);
  *(undefined8 *)(puVar30 + -8) = 0x10113a;
  func_0x(uVar23 ^ (ulonglong)puVar1);
  return;
}

