
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,undefined8 param_3)

{
  ushort *puVar1;
  longlong *plVar2;
  byte bVar3;
  int iVar4;
  ulonglong *puVar5;
  uint uVar6;
  longlong lVar7;
  ushort uVar8;
  short sVar9;
  uint uVar10;
  ulonglong uVar11;
  uint *puVar12;
  longlong lVar13;
  byte *pbVar14;
  ushort uVar15;
  ushort *puVar16;
  longlong unaff_GS_OFFSET;
  undefined auStack_98 [32];
  uint *puStack_78;
  undefined4 uStack_70;
  undefined4 *puStack_68;
  uint uStack_60;
  undefined4 uStack_58;
  uint uStack_54;
  undefined auStack_50 [4];
  uint auStack_4c [3];
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_98;
  lVar13 = *(longlong *)(param_1 + 8);
  puVar1 = (ushort *)(param_2 + 1);
  puVar12 = (uint *)(lVar13 + 0x210);
  if (*param_2 != 0) {
    puStack_78 = &uStack_54;
    uStack_54 = 0;
    lVar7 = func_0x(puVar1,puVar12,param_3,&uStack_58);
    if ((((((*param_2 != 0) && (plVar2 = *(longlong **)(param_2 + 8), plVar2 != (longlong *)0x0)) &&
          (*plVar2 != 0)) && (((*(byte *)(lVar13 + 0x216) & 8) == 0 && ((uStack_54 & 1) == 0)))) &&
        (lVar7 != 0)) && (lVar7 != 0xa5ba64)) {
      uStack_60 = uStack_54;
      puStack_68 = &uStack_58;
      puStack_78 = auStack_4c;
      uStack_70 = 6;
      func_0x(plVar2,puVar12,lVar7,uStack_58);
    }
    goto LAB_;
  }
  uVar10 = *puVar12;
  if ((uVar10 & 0xc0000000) == 0x80000000) {
    iVar4 = func_0x(puVar1);
    if (iVar4 != 0) {
      func_0x(param_2 + 0x15,puVar12,&uStack_58,auStack_50);
    }
    goto LAB_;
  }
  uVar15 = *(ushort *)(lVar13 + 0x216) & 0x10;
  if (uVar15 != 0) {
    bVar3 = **(byte **)(param_2 + 4);
    if ((bVar3 & 0x10) == 0) {
      if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) goto LAB_;
    }
    else if (((int)*(uint *)(param_2 + 8) <= (int)uVar10) ||
            (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
             *(ushort *)(lVar13 + 0x214))) goto LAB_;
  }
  if (-1 < (int)uVar10) {
    if ((*(ushort *)(lVar13 + 0x216) & 8) != 0) goto LAB_;
    if (uVar15 != 0) {
      bVar3 = **(byte **)(param_2 + 4);
      if ((bVar3 & 0x10) == 0) {
        if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
          if (**(int **)(lVar13 + 0x218) != 6) {
            puStack_78 = (uint *)0x0;
            (*_DAT_)(1,0xe84d98,0xe83798,0x381);
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_2 + 8) <= (int)uVar10) ||
              (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
               *(ushort *)(lVar13 + 0x214))) goto LAB_;
    }
    uStack_58 = 6;
    goto LAB_;
  }
  if (*(int *)(param_2 + 2) == 0) {
    pbVar14 = *(byte **)(param_2 + 4);
    uVar10 = *(uint *)(param_2 + 8);
    uVar11 = (ulonglong)uVar10;
    *puVar1 = 0;
    *(uint *)(param_2 + 10) = uVar10;
    bVar3 = *pbVar14;
    if ((bVar3 & 0x10) != 0) {
      uVar10 = uVar10 + 2 + (*(ushort *)(pbVar14 + uVar11) + 7 >> 3);
      uVar11 = (ulonglong)uVar10;
      *(uint *)(param_2 + 10) = uVar10;
      bVar3 = *pbVar14;
    }
    if ((bVar3 & 0x20) == 0) {
      *(int *)(param_2 + 2) = (int)uVar11;
      param_2[0xe] = 0;
      *(int *)(param_2 + 0xc) = (int)uVar11;
    }
    else {
      puVar16 = (ushort *)(pbVar14 + uVar11);
      uVar15 = *puVar16;
      param_2[0xe] = uVar15;
      if (uVar15 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar7 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar7 != 0)) &&
           ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            puStack_78 = (uint *)0x0;
            (*_DAT_)(1,0xcd7028,0xdf6cf8,0x80f);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),3);
        uVar11 = (ulonglong)*(uint *)(param_2 + 10);
        uVar15 = param_2[0xe];
      }
      uVar10 = (int)uVar11 + (uVar15 + 1) * 2;
      *(uint *)(param_2 + 0xc) = uVar10;
      if (0x1f9e < uVar10) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar7 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar7 != 0 &&
            ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puStack_78 = (uint *)0x0;
            (*_DAT_)(1,0xcd7028,0xdf6cf8,0x816);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),4);
        uVar15 = param_2[0xe];
        uVar10 = *(uint *)(param_2 + 0xc);
      }
      uVar11 = (ulonglong)uVar15;
      uVar15 = puVar16[uVar11];
      *(uint *)(param_2 + 2) = uVar15 & 0x7fff;
      if ((uVar15 & 0x7fff) < uVar10) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar7 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar7 != 0)) &&
           ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puStack_78 = (uint *)0x0;
            (*_DAT_)(1,0xcd7028,0xdf6cf8,0x81d);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),4);
        uVar11 = (ulonglong)(ushort)param_2[0xe];
      }
      if ((short)puVar16[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
        pbVar14 = *(byte **)(param_2 + 4);
        do {
          if ((int)uVar11 == 1) {
            uVar10 = *(uint *)(param_2 + 0xc);
            uVar6 = uVar10;
LAB_:
            if ((*(ushort *)(pbVar14 + uVar11 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff) <
                uVar10) goto LAB_;
          }
          else {
            uVar6 = *(uint *)(param_2 + 0xc);
            uVar10 = *(ushort *)(pbVar14 + uVar11 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                     0x7fff;
            if (uVar6 <= uVar10) goto LAB_;
LAB_:
            func_0x(pbVar14,7);
            uVar6 = *(uint *)(param_2 + 0xc);
          }
          if ((uVar10 < uVar6) || (*(uint *)(param_2 + 2) < uVar10)) goto LAB_;
          pbVar14 = *(byte **)(param_2 + 4);
          if (*(ushort *)(pbVar14 + uVar10) == 5) {
            *puVar1 = *puVar1 | 2;
            param_2[0xe] = param_2[0xe] + -1;
            param_2[0x15] = (short)uVar10;
            lVar7 = (ulonglong)(uVar10 & 0xffff) + *(longlong *)(param_2 + 4);
            uVar15 = param_2[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar7 + 2) >> 0xe & 1) != 0) {
              uVar15 = *(ushort *)(lVar7 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
            }
            param_2[0x16] = uVar15;
            param_2[0x16] = (uVar15 ^ *(ushort *)(lVar7 + 2)) & 0x7ff ^ uVar15;
            goto LAB_;
          }
          if (*(ushort *)(pbVar14 + uVar10) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar15 = param_2[0xe] - 1;
          param_2[0xe] = uVar15;
          if (uVar15 == 0) goto LAB_;
          uVar11 = (ulonglong)uVar15;
        } while ((short)puVar16[(ulonglong)(uVar15 - 1) + 1] < 0);
        uVar11 = (ulonglong)*(uint *)(param_2 + 2);
      }
      else {
LAB_:
        uVar11 = (ulonglong)*(uint *)(param_2 + 2);
        pbVar14 = *(byte **)(param_2 + 4);
      }
    }
    iVar4 = 0;
    if ((*pbVar14 & 0x40) == 0) {
      *(undefined4 *)(param_2 + 0x13) = 0;
    }
    else {
      *(int *)(param_2 + 0x13) = (int)uVar11;
      *(int *)(param_2 + 2) = (int)uVar11 + 0xe;
      puVar5 = (ulonglong *)func_0x(puVar1);
      uVar8 = (ushort)(*puVar5 >> 0x30);
      uVar15 = uVar8;
      if ((((uint)(int)(short)uVar8 >> 1 ^ (int)(short)uVar8) & 0x2000) != 0) {
        uVar15 = uVar8 & 0xdfff;
        if ((uVar8 >> 0xe & 1) != 0) {
          uVar15 = uVar8 | 0x2000;
        }
      }
      if (uVar15 == 0xfffc) {
        iVar4 = (int)((*puVar5 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar4;
      uVar11 = (ulonglong)*(uint *)(param_2 + 2);
    }
    iVar4 = (int)uVar11;
    if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
       (*(ulonglong *)(param_2 + 0xf) < uVar11 + *(longlong *)(param_2 + 4))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar7 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar7 != 0 &&
           (lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0)) && (*(char *)(lVar7 + 0x499) != '\0'))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          puStack_78 = (uint *)0x0;
          (*_DAT_)(1,0xcd7028,0xdf6cf8,0x877);
        }
      }
      func_0x(*(undefined8 *)(param_2 + 4),0x12);
      iVar4 = *(int *)(param_2 + 2);
    }
    if (0x3f3b < iVar4 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar7 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar7 != 0 &&
          ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0'))))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          puStack_78 = (uint *)0x0;
          (*_DAT_)(1,0xcd7028,0xdf6cf8,0x87c);
        }
      }
      func_0x(*(undefined8 *)(param_2 + 4),5);
    }
  }
LAB_:
  sVar9 = -*(short *)puVar12;
  if ((*(byte *)(lVar13 + 0x216) & 0x10) != 0) {
    bVar3 = **(byte **)(param_2 + 4);
    if ((bVar3 & 0x10) == 0) {
      if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) goto LAB_;
    }
    else if (((int)*(uint *)(param_2 + 8) <= (int)*puVar12) ||
            (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
             *(ushort *)(lVar13 + 0x214))) goto LAB_;
  }
  lVar13 = *(longlong *)(param_2 + 4);
  if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar9) goto LAB_;
  lVar7 = (ulonglong)*(uint *)(param_2 + 10) + lVar13;
  if (sVar9 == 1) {
    uVar10 = *(uint *)(param_2 + 0xc);
LAB_:
    if (uVar10 <= (*(ushort *)(lVar7 + (longlong)sVar9 * 2) & 0x7fff)) goto LAB_;
  }
  else {
    lVar13 = *(longlong *)(param_2 + 4);
    uVar10 = *(ushort *)(lVar7 + -2 + (longlong)sVar9 * 2) & 0x7fff;
    if (*(uint *)(param_2 + 0xc) <= uVar10) goto LAB_;
  }
  func_0x(lVar13,7);
LAB_:
  func_0x(uStack_40 ^ (ulonglong)auStack_98);
  return;
}

