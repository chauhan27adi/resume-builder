
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(int *param_1,int param_2)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  longlong lVar10;
  int iVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined8 in_stack_ffffffffffffffc8;
  undefined4 uVar14;
  
  uVar14 = (undefined4)((ulonglong)in_stack_ffffffffffffffc8 >> 0x20);
  if (*(char *)(param_1 + 0x12) == '\0') {
    if (-1 < param_2) {
      return;
    }
    (*_DAT_)(0x9e,5,0x10,param_1[1],*(undefined8 *)(param_1 + 0xc),param_2);
    return;
  }
  lVar10 = *(longlong *)(param_1 + 0x10);
  if (lVar10 == 0) {
    lVar10 = *(longlong *)(param_1 + 0xe);
  }
  iVar11 = *param_1;
  if (-0x7cffffff < iVar11) {
    if (iVar11 == -0x7cfffffe) {
      if ((uint)param_1[5] < 2) {
        uVar13 = 0x1954160;
        if (param_1[5] == 0) {
          uVar9 = 0x1954160;
        }
        else {
          uVar9 = **(undefined8 **)(param_1 + 8);
        }
      }
      else {
        uVar13 = (*(undefined8 **)(param_1 + 8))[1];
        uVar9 = **(undefined8 **)(param_1 + 8);
      }
      uVar7 = 0x38;
    }
    else {
      if (iVar11 == -0x7cfffffd) {
        if ((uint)param_1[5] < 2) {
          lVar10 = 0x1954160;
          if (param_1[5] == 0) {
            uVar13 = 0x1954160;
          }
          else {
            uVar13 = **(undefined8 **)(param_1 + 8);
          }
        }
        else {
          lVar10 = (*(undefined8 **)(param_1 + 8))[1];
          uVar13 = **(undefined8 **)(param_1 + 8);
        }
        uVar9 = 0x39;
        goto LAB_;
      }
      if (iVar11 != -0x7cfffffc) {
        if (iVar11 == -0x7cfffffb) {
          (*_DAT_)(0x9e,0x62,0x10,param_1[1]);
          return;
        }
        if (iVar11 == -0x7cfffffa) {
          if (param_1[5] == 0) {
            uVar13 = 0x1954160;
          }
          else {
            uVar13 = **(undefined8 **)(param_1 + 8);
          }
          iVar11 = param_1[1];
          uVar9 = 99;
          goto code_r0x00100a15;
        }
        goto LAB_;
      }
      if ((uint)param_1[5] < 2) {
        uVar13 = 0x1954160;
        if (param_1[5] == 0) {
          uVar9 = 0x1954160;
          uVar7 = 0x56;
        }
        else {
          uVar7 = 0x56;
          uVar9 = **(undefined8 **)(param_1 + 8);
        }
      }
      else {
        uVar7 = 0x56;
        uVar13 = (*(undefined8 **)(param_1 + 8))[1];
        uVar9 = **(undefined8 **)(param_1 + 8);
      }
    }
    uVar12 = *(undefined8 *)(param_1 + 0xe);
    uVar8 = 0x9e;
code_r0x00100b27:
    (*_DAT_)(uVar8,uVar7,0x10,param_1[1],uVar12,uVar9,uVar13);
    return;
  }
  if (iVar11 == -0x7cffffff) {
    if (param_1[5] == 0) {
      uVar13 = 0x1954160;
    }
    else {
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    lVar10 = *(longlong *)(param_1 + 0xc);
    uVar9 = 0x2d;
    iVar11 = param_1[1];
    goto LAB_;
  }
  switch(iVar11) {
  case -0x7dffffff:
    uVar3 = param_1[5];
    if (uVar3 < 3) {
      lVar5 = 0x1954160;
      uVar13 = 0x1954160;
      if (uVar3 < 2) {
        if (uVar3 == 0) {
          uVar9 = 0x1954160;
        }
        else {
          uVar9 = **(undefined8 **)(param_1 + 8);
        }
      }
      else {
        lVar5 = (*(undefined8 **)(param_1 + 8))[1];
        uVar9 = **(undefined8 **)(param_1 + 8);
      }
    }
    else {
      puVar1 = *(undefined8 **)(param_1 + 8);
      uVar13 = puVar1[2];
      lVar5 = puVar1[1];
      uVar9 = *puVar1;
    }
    uVar12 = 0x9e;
    uVar7 = 0xe;
    goto code_r0x00100571;
  case -0x7dfffffe:
    if (param_1[5] == 0) {
      uVar13 = 0x1954160;
    }
    else {
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    lVar10 = *(longlong *)(param_1 + 0xe);
    uVar9 = 0xf;
    goto LAB_;
  case -0x7dfffffd:
    uVar13 = *(undefined8 *)(param_1 + 0xe);
    uVar9 = 0xb;
    iVar11 = param_1[1];
code_r0x00100a15:
    (*_DAT_)(0x9e,uVar9,0x10,iVar11,uVar13);
    return;
  case -0x7dfffffc:
    uVar13 = *(undefined8 *)(param_1 + 0xe);
    uVar9 = 0xc;
    lVar10 = 0x400;
    goto LAB_;
  case -0x7dfffffb:
    if (param_1[5] == 0) {
      uVar13 = 0x1954160;
      uVar9 = 0x37;
    }
    else {
      uVar9 = 0x37;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    goto LAB_;
  case -0x7dfffffa:
    if (param_1[5] == 0) {
      lVar10 = 0x1954160;
    }
    else {
      lVar10 = **(longlong **)(param_1 + 8);
    }
    lVar6 = *(longlong *)(param_1 + 0xe);
    uVar7 = 6;
    uVar13 = CONCAT44(uVar14,0x80);
    uVar9 = 0x100;
    goto code_r0x0010056c;
  case -0x7dfffff9:
    uVar3 = param_1[5];
    if (uVar3 < 3) {
      uVar13 = 0x1954160;
      lVar6 = 0x1954160;
      if (uVar3 < 2) {
        if (uVar3 == 0) {
          uVar9 = 0x1954160;
        }
        else {
          uVar9 = **(undefined8 **)(param_1 + 8);
        }
      }
      else {
        uVar13 = (*(undefined8 **)(param_1 + 8))[1];
        uVar9 = **(undefined8 **)(param_1 + 8);
      }
    }
    else {
      puVar1 = *(undefined8 **)(param_1 + 8);
      lVar6 = puVar1[2];
      uVar13 = puVar1[1];
      uVar9 = *puVar1;
    }
    uVar7 = 7;
    goto code_r0x0010056c;
  case -0x7dfffff8:
    uVar3 = param_1[5];
    if (uVar3 < 3) {
      uVar13 = 0x1954160;
      lVar6 = 0x1954160;
      if (uVar3 < 2) {
        if (uVar3 == 0) {
          uVar9 = 0x1954160;
        }
        else {
          uVar9 = **(undefined8 **)(param_1 + 8);
        }
      }
      else {
        uVar13 = (*(undefined8 **)(param_1 + 8))[1];
        uVar9 = **(undefined8 **)(param_1 + 8);
      }
    }
    else {
      puVar1 = *(undefined8 **)(param_1 + 8);
      lVar6 = puVar1[2];
      uVar13 = puVar1[1];
      uVar9 = *puVar1;
    }
    uVar7 = 8;
    goto code_r0x0010056c;
  case -0x7dfffff7:
    uVar3 = param_1[5];
    if (uVar3 < 4) {
      uVar9 = 0x1954160;
      lVar5 = 0x1954160;
      if (uVar3 < 3) {
        uVar13 = 0x1954160;
        if (uVar3 < 2) {
          if (uVar3 == 0) {
            uVar7 = 0x1954160;
          }
          else {
            uVar7 = **(undefined8 **)(param_1 + 8);
          }
        }
        else {
          uVar9 = (*(undefined8 **)(param_1 + 8))[1];
          uVar7 = **(undefined8 **)(param_1 + 8);
        }
      }
      else {
        puVar1 = *(undefined8 **)(param_1 + 8);
        uVar13 = puVar1[2];
        uVar9 = puVar1[1];
        uVar7 = *puVar1;
      }
    }
    else {
      puVar1 = *(undefined8 **)(param_1 + 8);
      lVar5 = puVar1[3];
      uVar13 = puVar1[2];
      uVar9 = puVar1[1];
      uVar7 = *puVar1;
    }
    uVar12 = 9;
    lVar6 = lVar10;
    goto code_r0x001003ea;
  case -0x7dfffff6:
    if ((uint)param_1[5] < 2) {
      uVar13 = 0x1954160;
      if (param_1[5] == 0) {
        uVar12 = 0x1954160;
      }
      else {
        uVar12 = **(undefined8 **)(param_1 + 8);
      }
    }
    else {
      uVar13 = (*(undefined8 **)(param_1 + 8))[1];
      uVar12 = **(undefined8 **)(param_1 + 8);
    }
    uVar9 = *(undefined8 *)(param_1 + 0xe);
    uVar7 = 0x1d;
    uVar8 = 0xa5;
    goto code_r0x00100b27;
  case -0x7dfffff5:
    if (param_1[5] == 0) {
      uVar13 = 0x1954160;
    }
    else {
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    (*_DAT_)(0xa5,0x1e,0x10,param_1[1],*(undefined8 *)(param_1 + 0xe),uVar13);
    return;
  case -0x7dfffff4:
    if (param_1[5] == 0) {
      uVar9 = 0x20;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x20;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dfffff3:
    if (param_1[5] == 0) {
      uVar9 = 0x21;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x21;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dfffff2:
    if (param_1[5] == 0) {
      uVar9 = 0x22;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x22;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dfffff1:
    if (param_1[5] == 0) {
      uVar9 = 0x23;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x23;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dfffff0:
    if (param_1[5] == 0) {
      uVar9 = 0x24;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x24;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dffffef:
    if (param_1[5] == 0) {
      uVar9 = 0x25;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x25;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dffffee:
    if (param_1[5] == 0) {
      uVar9 = 0x26;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x26;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dffffed:
    if (param_1[5] == 0) {
      uVar9 = 0x27;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x27;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dffffec:
    if (param_1[5] == 0) {
      uVar9 = 0x28;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x28;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dffffeb:
    if (param_1[5] == 0) {
      uVar9 = 0x29;
      uVar13 = 0x1954160;
      uVar7 = 0x1d4;
    }
    else {
      uVar9 = 0x29;
      uVar7 = 0x1d4;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
    break;
  case -0x7dffffea:
    uVar3 = param_1[5];
    if (uVar3 < 4) {
      uVar9 = 0x1954160;
      uVar13 = 0x1954160;
      if (uVar3 < 3) {
        lVar6 = 0x1954160;
        if (uVar3 < 2) {
          if (uVar3 == 0) {
            uVar7 = 0x1954160;
          }
          else {
            uVar7 = **(undefined8 **)(param_1 + 8);
          }
        }
        else {
          uVar9 = (*(undefined8 **)(param_1 + 8))[1];
          uVar7 = **(undefined8 **)(param_1 + 8);
        }
      }
      else {
        puVar1 = *(undefined8 **)(param_1 + 8);
        lVar6 = puVar1[2];
        uVar9 = puVar1[1];
        uVar7 = *puVar1;
      }
    }
    else {
      puVar1 = *(undefined8 **)(param_1 + 8);
      uVar13 = puVar1[3];
      lVar6 = puVar1[2];
      uVar9 = puVar1[1];
      uVar7 = *puVar1;
    }
    uVar12 = 0x3c;
    lVar5 = lVar10;
code_r0x001003ea:
    (*_DAT_)(0xa5,uVar12,0x10,param_1[1],uVar7,uVar9,lVar6,uVar13,lVar5);
    return;
  case -0x7dffffe9:
    uVar3 = param_1[5];
    if (uVar3 < 3) {
      uVar13 = 0x1954160;
      lVar6 = 0x1954160;
      if (uVar3 < 2) {
        if (uVar3 == 0) {
          uVar9 = 0x1954160;
        }
        else {
          uVar9 = **(undefined8 **)(param_1 + 8);
        }
      }
      else {
        uVar13 = (*(undefined8 **)(param_1 + 8))[1];
        uVar9 = **(undefined8 **)(param_1 + 8);
      }
    }
    else {
      puVar1 = *(undefined8 **)(param_1 + 8);
      lVar6 = puVar1[2];
      uVar13 = puVar1[1];
      uVar9 = *puVar1;
    }
    uVar7 = 0x4b;
code_r0x0010056c:
    uVar12 = 0xa5;
    lVar5 = lVar10;
    lVar10 = lVar6;
code_r0x00100571:
    (*_DAT_)(uVar12,uVar7,0x10,param_1[1],uVar9,lVar5,uVar13,lVar10);
    return;
  default:
LAB_:
    uVar3 = param_1[0x14];
    uVar4 = uVar3;
    if (param_1[0x18] != 1) {
      uVar4 = uVar3 & 0xffff;
    }
    if (uVar4 != 0) {
      iVar11 = (int)uVar3 % 100;
      if (iVar11 == 0x2c) {
        (*_DAT_)(0xa5,0x2c,0x10,param_1[0x17]);
        return;
      }
      if ((iVar11 == 0x3c) || (iVar11 == 0x3d)) {
        uVar13 = *(undefined8 *)(param_1 + 0xe);
        if (*(longlong *)(param_1 + 0x1a) != 0) {
          (*_DAT_)(0x30,0x3d,10,param_1[0x17],uVar13,*(longlong *)(param_1 + 0x1a));
          return;
        }
        uVar9 = 0x23;
      }
      else {
        if (iVar11 == 0x46) {
          (*_DAT_)(0x30,0x46,10,param_1[0x17],*(undefined8 *)(param_1 + 0xe),
                           *(undefined8 *)(param_1 + 0x1a));
          return;
        }
        uVar13 = *(undefined8 *)(param_1 + 0xe);
        uVar9 = 0x24;
      }
      uVar7 = 0xa5;
      break;
    }
    if (param_1[5] == 0) {
      uVar13 = 0x1954160;
      uVar9 = 0xd;
    }
    else {
      uVar9 = 0xd;
      uVar13 = **(undefined8 **)(param_1 + 8);
    }
LAB_:
    iVar11 = param_1[1];
LAB_:
    (*_DAT_)(0x9e,uVar9,0x10,iVar11,uVar13,lVar10);
    return;
  case -0x7dffffe7:
    uVar3 = param_1[5];
    if (uVar3 < 4) {
      uVar9 = 0x1954160;
      uVar13 = 0x1954160;
      if (uVar3 < 3) {
        uVar7 = 0x1954160;
        if (uVar3 < 2) {
          if (uVar3 == 0) {
            uVar12 = 0x1954160;
          }
          else {
            uVar12 = **(undefined8 **)(param_1 + 8);
          }
        }
        else {
          uVar9 = (*(undefined8 **)(param_1 + 8))[1];
          uVar12 = **(undefined8 **)(param_1 + 8);
        }
      }
      else {
        puVar1 = *(undefined8 **)(param_1 + 8);
        uVar7 = puVar1[2];
        uVar9 = puVar1[1];
        uVar12 = *puVar1;
      }
    }
    else {
      puVar1 = *(undefined8 **)(param_1 + 8);
      uVar13 = puVar1[3];
      uVar7 = puVar1[2];
      uVar9 = puVar1[1];
      uVar12 = *puVar1;
    }
    uVar2 = (*pcRam0000000001784538)(uVar7,0,10);
    uVar9 = (*pcRam00000000017845d0)(uVar9,0,10);
    (*_DAT_)(0x8a,0xc,0x10,param_1[1],uVar12,uVar9,CONCAT44(uVar14,uVar2),uVar13,lVar10);
    return;
  case -0x7dffffe6:
    uVar13 = 0x1954160;
    if (param_1[5] == 0) {
      uVar9 = 0x1954160;
    }
    else {
      uVar9 = **(undefined8 **)(param_1 + 8);
      if (1 < (uint)param_1[5]) {
        uVar13 = (*(undefined8 **)(param_1 + 8))[1];
      }
    }
    uVar3 = (*pcRam0000000001784528)(uVar13,0,10);
    (*_DAT_)(10,0x37,0x10,param_1[1],(ulonglong)uVar3 * 2,uVar9);
    (*_DAT_)(10,0x37,0x19,param_1[1]);
    return;
  }
  (*_DAT_)(uVar7,uVar9,0x10,param_1[1],uVar13);
  return;
}

