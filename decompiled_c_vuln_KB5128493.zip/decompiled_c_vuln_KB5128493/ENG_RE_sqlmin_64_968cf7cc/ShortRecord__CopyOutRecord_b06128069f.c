
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,ulonglong param_3,short *param_4,int param_5)

{
  short sVar1;
  short *psVar2;
  byte bVar3;
  int iVar4;
  undefined8 uVar5;
  ulonglong *puVar6;
  byte *pbVar7;
  ushort uVar8;
  ushort uVar9;
  ulonglong uVar10;
  uint uVar11;
  undefined4 uVar12;
  uint uVar13;
  longlong lVar14;
  ushort *puVar15;
  longlong unaff_GS_OFFSET;
  
  uVar12 = (undefined4)param_3;
  if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
    uVar5 = (**(code **)**(undefined8 **)(param_1 + 0x10))();
    param_3 = param_3 & 0xffffffff;
    *(undefined8 *)(param_1 + 8) = uVar5;
  }
  psVar2 = *(short **)(param_1 + 8);
  sVar1 = *psVar2;
  *param_4 = sVar1;
  if (sVar1 != 0) {
    if ((((param_5 == 0) || (*psVar2 == 0)) || (*(longlong **)(psVar2 + 8) == (longlong *)0x0)) ||
       (**(longlong **)(psVar2 + 8) == 0)) {
      func_0x(param_4 + 1,param_2,param_3,psVar2 + 1);
      if (*psVar2 == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = *(undefined8 *)(psVar2 + 8);
      }
      *(undefined8 *)(param_4 + 8) = uVar5;
    }
    else {
      func_0x(param_4,param_2,param_3,psVar2);
    }
    goto LAB_;
  }
  if (*(int *)(psVar2 + 2) == 0) {
    pbVar7 = *(byte **)(psVar2 + 4);
    uVar13 = *(uint *)(psVar2 + 8);
    uVar10 = (ulonglong)uVar13;
    psVar2[1] = 0;
    *(uint *)(psVar2 + 10) = uVar13;
    bVar3 = *pbVar7;
    if ((bVar3 & 0x10) != 0) {
      uVar13 = uVar13 + 2 + (*(ushort *)(pbVar7 + uVar10) + 7 >> 3);
      uVar10 = (ulonglong)uVar13;
      *(uint *)(psVar2 + 10) = uVar13;
      bVar3 = *pbVar7;
    }
    if ((bVar3 & 0x20) == 0) {
      *(int *)(psVar2 + 2) = (int)uVar10;
      psVar2[0xe] = 0;
      *(int *)(psVar2 + 0xc) = (int)uVar10;
    }
    else {
      puVar15 = (ushort *)(pbVar7 + uVar10);
      uVar8 = *puVar15;
      psVar2[0xe] = uVar8;
      if (uVar8 == 0) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar14 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar14 != 0 &&
            ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
             (*(char *)(lVar14 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9fbc98,0xb1b968,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(psVar2 + 4),3);
        uVar10 = (ulonglong)*(uint *)(psVar2 + 10);
        uVar8 = psVar2[0xe];
      }
      uVar13 = (int)uVar10 + (uVar8 + 1) * 2;
      *(uint *)(psVar2 + 0xc) = uVar13;
      if (0x1f9e < uVar13) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar14 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar14 != 0)) &&
           ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
            (*(char *)(lVar14 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9fbc98,0xb1b968,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(psVar2 + 4),4);
        uVar8 = psVar2[0xe];
      }
      uVar10 = (ulonglong)uVar8;
      uVar8 = puVar15[uVar10];
      *(uint *)(psVar2 + 2) = uVar8 & 0x7fff;
      if ((uVar8 & 0x7fff) < *(uint *)(psVar2 + 0xc)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar14 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar14 != 0 &&
            ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
             (*(char *)(lVar14 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9fbc98,0xb1b968,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(psVar2 + 4),4);
        uVar10 = (ulonglong)(ushort)psVar2[0xe];
      }
      if ((short)puVar15[(ulonglong)((int)uVar10 - 1) + 1] < 0) {
        do {
          lVar14 = *(longlong *)(psVar2 + 4);
          if ((int)uVar10 == 1) {
            uVar13 = *(uint *)(psVar2 + 0xc);
            uVar11 = uVar13;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(psVar2 + 10) + lVar14 + uVar10 * 2) & 0x7fff) <
                uVar13) goto LAB_;
          }
          else {
            uVar11 = *(uint *)(psVar2 + 0xc);
            uVar13 = *(ushort *)((ulonglong)*(uint *)(psVar2 + 10) + lVar14 + -2 + uVar10 * 2) &
                     0x7fff;
            if (uVar11 <= uVar13) goto LAB_;
LAB_:
            func_0x(lVar14,7);
            uVar11 = *(uint *)(psVar2 + 0xc);
            lVar14 = *(longlong *)(psVar2 + 4);
            uVar10 = (ulonglong)(ushort)psVar2[0xe];
          }
          if ((uVar13 < uVar11) || (*(uint *)(psVar2 + 2) < uVar13)) goto LAB_;
          if (*(ushort *)(lVar14 + (ulonglong)uVar13) == 5) {
            psVar2[1] = psVar2[1] | 2;
            psVar2[0xe] = (short)uVar10 + -1;
            psVar2[0x15] = (short)uVar13;
            lVar14 = (ulonglong)(uVar13 & 0xffff) + *(longlong *)(psVar2 + 4);
            uVar8 = psVar2[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar14 + 2) & 0x4000) != 0) {
              uVar8 = *(ushort *)(lVar14 + 2) & 0x3800 | psVar2[0x16] & 0xc7ffU;
            }
            psVar2[0x16] = uVar8;
            psVar2[0x16] = (uVar8 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar8;
            uVar10 = (ulonglong)*(uint *)(psVar2 + 2);
            pbVar7 = *(byte **)(psVar2 + 4);
            goto LAB_;
          }
          if (*(ushort *)(lVar14 + (ulonglong)uVar13) < 0x400) break;
          psVar2[1] = psVar2[1] | 1;
          uVar8 = (short)uVar10 - 1;
          psVar2[0xe] = uVar8;
          if ((uVar8 == 0) ||
             (uVar10 = (ulonglong)uVar8, -1 < (short)puVar15[(ulonglong)(uVar8 - 1) + 1])) break;
        } while( true );
      }
      uVar10 = (ulonglong)*(uint *)(psVar2 + 2);
      pbVar7 = *(byte **)(psVar2 + 4);
    }
LAB_:
    iVar4 = 0;
    if ((*pbVar7 & 0x40) == 0) {
      *(undefined4 *)(psVar2 + 0x13) = 0;
    }
    else {
      *(int *)(psVar2 + 0x13) = *(int *)(psVar2 + 2);
      *(int *)(psVar2 + 2) = *(int *)(psVar2 + 2) + 0xe;
      puVar6 = (ulonglong *)func_0x(psVar2 + 1);
      uVar10 = *puVar6;
      uVar9 = (ushort)(uVar10 >> 0x30);
      uVar8 = uVar9;
      if ((((uint)(int)(short)uVar9 >> 1 ^ (int)(short)uVar9) & 0x2000) != 0) {
        uVar8 = uVar9 & 0xdfff;
        if ((uVar10 & 0x4000000000000000) != 0) {
          uVar8 = uVar9 | 0x2000;
        }
      }
      if (uVar8 == 0xfffc) {
        iVar4 = (int)((uVar10 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(psVar2 + 2) = *(int *)(psVar2 + 2) + iVar4;
      uVar10 = (ulonglong)*(uint *)(psVar2 + 2);
      pbVar7 = *(byte **)(psVar2 + 4);
    }
    iVar4 = (int)uVar10;
    if ((*(byte **)(psVar2 + 0xf) != (byte *)0x0) && (*(byte **)(psVar2 + 0xf) < pbVar7 + uVar10)) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar14 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar14 != 0 &&
           (lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0)) &&
          (*(char *)(lVar14 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9fbc98,0xb1b968,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(psVar2 + 4),0x12);
      iVar4 = *(int *)(psVar2 + 2);
    }
    if (0x3f3b < iVar4 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar14 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar14 != 0 &&
          ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
           (*(char *)(lVar14 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9fbc98,0xb1b968,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(psVar2 + 4),5);
    }
  }
LAB_:
  uVar13 = *(uint *)(psVar2 + 2);
  if ((uVar13 < 9) &&
     (((**(byte **)(psVar2 + 4) & 0xe) == 0 || ((**(byte **)(psVar2 + 4) & 0xe) == 0xc)))) {
    uVar13 = 9;
  }
  *(undefined4 *)(param_4 + 8) = *(undefined4 *)(psVar2 + 8);
  param_4[1] = psVar2[1];
  *(undefined4 *)(param_4 + 2) = *(undefined4 *)(psVar2 + 2);
  param_4[0xe] = psVar2[0xe];
  *(undefined4 *)(param_4 + 10) = *(undefined4 *)(psVar2 + 10);
  *(undefined4 *)(param_4 + 0xc) = *(undefined4 *)(psVar2 + 0xc);
  *(undefined4 *)(param_4 + 0x13) = *(undefined4 *)(psVar2 + 0x13);
  func_0x(param_2,uVar12,*(undefined8 *)(psVar2 + 4),uVar13);
  *(undefined8 *)(param_4 + 4) = param_2;
  iVar4 = func_0x(param_4 + 1);
  if (iVar4 == 0) goto LAB_;
  puVar15 = (ushort *)((ulonglong)*(uint *)(param_4 + 10) + *(longlong *)(param_4 + 4));
  uVar13 = *puVar15 - 1;
  if ((*(byte *)(param_4 + 1) & 1) == 0) {
    uVar13 = (uint)*puVar15;
  }
  if (uVar13 == 1) {
    uVar11 = *(uint *)(param_4 + 0xc);
LAB_:
    if ((puVar15[(int)uVar13] & 0x7fff) < uVar11) goto LAB_;
  }
  else {
    uVar11 = puVar15[(longlong)(int)uVar13 + -1] & 0x7fff;
    if (*(uint *)(param_4 + 0xc) <= uVar11) goto LAB_;
LAB_:
    func_0x(*(longlong *)(param_4 + 4),7);
  }
  param_4[0x15] = (short)uVar11;
  lVar14 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(param_4 + 4);
  uVar8 = param_4[0x16] & 0xc7ffU;
  if ((*(ushort *)(lVar14 + 2) >> 0xe & 1) != 0) {
    uVar8 = *(ushort *)(lVar14 + 2) & 0x3800 | param_4[0x16] & 0xc7ffU;
  }
  param_4[0x16] = uVar8;
  param_4[0x16] = (uVar8 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar8;
LAB_:
  if (*param_4 == 0) {
    func_0x();
  }
  else {
    func_0x(param_4 + 1);
  }
  if (*(longlong **)(param_1 + 0x10) == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0010086e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x10) + 8))();
  return;
}

