
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined (*param_2) [16],ulonglong param_3)

{
  ushort uVar1;
  ushort uVar2;
  undefined4 *puVar3;
  code *pcVar4;
  undefined auVar5 [16];
  undefined2 **ppuVar6;
  char cVar7;
  byte bVar8;
  ushort uVar9;
  int iVar10;
  int iVar11;
  longlong lVar12;
  longlong lVar13;
  ulonglong *puVar14;
  longlong lVar15;
  longlong *plVar16;
  undefined8 uVar17;
  undefined2 uVar18;
  ushort uVar19;
  uint uVar20;
  undefined8 unaff_RBX;
  longlong *plVar21;
  uint uVar22;
  uint uVar23;
  ulonglong uVar24;
  ulonglong uVar25;
  ushort *puVar26;
  uint uVar27;
  longlong *plVar28;
  byte *pbVar29;
  short sVar30;
  undefined2 uVar31;
  uint uVar32;
  longlong unaff_GS_OFFSET;
  bool bVar33;
  bool bVar34;
  undefined4 extraout_XMM0_Da;
  uint uStackX_8;
  uint uStackX_c;
  ushort auStackX_10 [2];
  int iStackX_14;
  int iStackX_18;
  ushort uStackX_1c;
  ushort uStackX_1e;
  undefined8 uStackX_20;
  uint uStack_4698;
  ushort uStack_4694;
  undefined4 uStack_4688;
  undefined2 uStack_4684;
  uint uStack_4678;
  ushort uStack_4674;
  undefined4 uStack_4670;
  ushort uStack_466c;
  int iStack_4668;
  ushort uStack_4664;
  undefined4 uStack_4660;
  undefined8 uStack_4658;
  longlong lStack_4648;
  longlong lStack_4640;
  undefined4 uStack_4638;
  undefined4 auStack_4630 [2];
  undefined8 uStack_4628;
  undefined8 uStack_4620;
  undefined8 uStack_4618;
  undefined8 uStack_4610;
  undefined8 uStack_4608;
  undefined auStack_45f8 [8];
  undefined4 uStack_45f0;
  undefined4 uStack_45e8;
  undefined2 **ppuStack_45e0;
  undefined *puStack_45d8;
  undefined8 uStack_45d0;
  undefined2 *puStack_45c8;
  undefined4 uStack_45c0;
  undefined4 uStack_45bc;
  longlong lStack_45b8;
  uint uStack_45b0;
  undefined4 uStack_45ac;
  undefined8 uStack_45a8;
  undefined4 uStack_45a0;
  undefined4 uStack_459c;
  undefined auStack_4598 [496];
  undefined8 uStack_43a8;
  undefined8 uStack_43a0;
  undefined2 auStack_4398 [16];
  undefined auStack_4378 [8];
  undefined4 uStack_4370;
  undefined4 uStack_4368;
  undefined2 **ppuStack_4360;
  undefined *puStack_4358;
  undefined8 uStack_4350;
  undefined2 *puStack_4348;
  undefined4 uStack_4340;
  undefined4 uStack_433c;
  longlong lStack_4338;
  uint uStack_4330;
  undefined4 uStack_432c;
  undefined8 uStack_4328;
  undefined4 uStack_4320;
  undefined4 uStack_431c;
  undefined auStack_4318 [496];
  undefined8 uStack_4128;
  undefined8 uStack_4120;
  undefined2 auStack_4118 [16];
  short sStack_40f8;
  ushort uStack_40f6;
  uint uStack_40f4;
  longlong *plStack_40f0;
  undefined8 uStack_40e8;
  undefined4 uStack_40e0;
  ushort uStack_40dc;
  undefined2 uStack_40da;
  undefined6 uStack_40d8;
  undefined2 uStack_40d2;
  undefined2 uStack_40d0;
  undefined2 uStack_40ce;
  ushort uStack_40cc;
  undefined2 uStack_40ca;
  undefined4 uStack_40c8;
  undefined4 uStack_40c4;
  undefined auStack_40c0 [16];
  undefined auStack_40b0 [2];
  undefined auStack_40ae [2];
  undefined auStack_40ac [12];
  uint uStack_40a0;
  undefined4 uStack_409c;
  short sStack_4098;
  short sStack_4096;
  short sStack_4094;
  undefined2 uStack_4092;
  undefined6 uStack_4090;
  undefined2 uStack_408a;
  undefined2 uStack_4088;
  undefined6 uStack_4086;
  uint uStack_4080;
  undefined4 uStack_407c;
  short *psStack_4078;
  undefined *puStack_4070;
  short sStack_4068;
  undefined6 uStack_4066;
  undefined auStack_4060 [8];
  undefined2 uStack_4058;
  undefined auStack_4056 [6];
  undefined8 uStack_4050;
  undefined8 uStack_4048;
  ushort uStack_403a;
  int iStack_4030;
  undefined4 uStack_4028;
  ushort uStack_4024;
  undefined8 uStack_4020;
  undefined2 uStack_4018;
  undefined auStack_3fe8 [2];
  ushort auStack_3fe6 [4046];
  ushort uStack_204a;
  short asStack_2048 [2048];
  short asStack_1048 [2048];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  uStack_4608 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000046f8 + lVar12) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12);
  uVar24 = param_3 & 0xffffffff;
  *(int *)((longlong)&uStackX_8 + lVar12) = (int)param_3;
  *(undefined (**) [16])(&stack0x00000030 + lVar12) = param_2;
  if ((*param_2)[1] != 'd') {
    plVar21 = (longlong *)0x0;
    uVar20 = 0;
    if (((*(uint *)(param_1 + 0x15f8) & 0x4000) != 0) && ((int)param_3 != 0)) {
      puVar26 = (ushort *)(param_2[2] + 4);
      uVar9 = *(ushort *)((longlong)auStackX_10 + lVar12);
      uVar22 = *(uint *)((longlong)&uStackX_c + lVar12);
      plVar16 = plVar21;
      do {
        uVar32 = 1;
        if (((ulonglong)plVar16 & 7) == 0) {
          uVar22 = *(uint *)(puVar26 + -2);
          uVar9 = *puVar26;
          *(ushort *)((longlong)auStackX_10 + lVar12) = uVar9;
        }
        else {
          uVar22 = uVar22 + 1;
        }
        *(uint *)((longlong)&uStackX_c + lVar12) = uVar22;
        if (*(char *)((longlong)puVar26 + -0x23) != 'e') {
          if ((puVar26[-0x10] & 0x200) == 0) {
            if ((puVar26[-0x10] & 0x100) != 0) {
              if (1 < (byte)((*(byte *)(puVar26 + 0xc) & 3) - 1)) goto LAB_;
              do {
                if ((*(byte *)((ulonglong)(uVar32 << 9) + 0x1db + (longlong)puVar26) & 3) !=
                    (*(byte *)(puVar26 + 0xc) & 3)) goto LAB_;
                uVar32 = uVar32 + 1;
              } while (uVar32 < 0x10);
            }
          }
          else {
            if ((*(uint *)(puVar26 + -2) == uVar22) && (*puVar26 == uVar9)) {
              uVar32 = *(uint *)(puVar26 + 0xc);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000f6;
              iVar10 = func_0x
                                 (puVar26 + -0x12,0x2000,(uVar32 >> 1) + uVar32 * -0x80000000);
              if (iVar10 == *(int *)(puVar26 + 0xc)) goto LAB_;
            }
LAB_:
            if ((_DAT_ == 0) || (DAT_ == '\0')) {
              uVar32 = *(uint *)(param_1 + 0x15f8);
LAB_:
              *(uint *)(param_1 + 0x1604) = *(uint *)(param_1 + 0x1604) | 0x4000;
            }
            else {
              uVar32 = *(uint *)(param_1 + 0x15f8);
              if (((uVar32 >> 0x19 & 1) != 0) || ((*(byte *)(param_1 + 0x1018) & 0x10) != 0))
              goto LAB_;
            }
            if (((uVar32 >> 0x19 & 1) == 0) &&
               (((_DAT_ == 0 || (DAT_ == '\0')) ||
                ((*(byte *)(param_1 + 0x1018) & 0x10) != 0)))) {
              uVar17 = *(undefined8 *)(param_1 + 0xb0);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001cc;
              uStack_4698 = uVar22;
              uStack_4694 = uVar9;
              func_0x(2,&uStack_4698,uVar17);
            }
            else {
              if ((DAT_ & 4) == 0) {
                lVar13 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
                if ((lVar13 != 0) && (lVar13 = **(longlong **)(lVar13 + 0x38), lVar13 != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100218;
                  iVar10 = (*_DAT_)(lVar13,0xbba);
                  if (iVar10 != 0) {
                    uVar9 = *(ushort *)((longlong)auStackX_10 + lVar12);
                    uVar22 = *(uint *)((longlong)&uStackX_c + lVar12);
                    goto LAB_;
                  }
                }
                uVar9 = *(ushort *)((longlong)auStackX_10 + lVar12);
                uVar17 = *(undefined8 *)(param_1 + 0xb0);
                uVar22 = *(uint *)((longlong)&uStackX_c + lVar12);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100249;
                func_0x(0xc6f,uVar9,uVar22,uVar17);
              }
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100251;
              iVar10 = func_0x(param_1);
              if (iVar10 == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100267;
                lVar13 = func_0x(extraout_XMM0_Da,0,uVar9);
                if ((*(uint *)(param_1 + 0x15f8) & 0x2000000) == 0) {
                  if (lVar13 == 0) {
LAB_:
                    uVar17 = *(undefined8 *)(param_1 + 0xb0);
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10038e;
                    func_0x(0xcd9330,uVar9,uVar22,uVar17);
                  }
                  else {
                    bVar33 = uVar9 < *(ushort *)(lVar13 + 0x19c);
                    bVar34 = uVar9 == *(ushort *)(lVar13 + 0x19c);
                    if (bVar34) {
                      bVar33 = uVar22 < *(uint *)(lVar13 + 0x198);
                      bVar34 = uVar22 == *(uint *)(lVar13 + 0x198);
                    }
                    if (bVar33 || bVar34) {
                      lVar13 = *(longlong *)(param_1 + 0xb0);
                      uVar24 = 0xffffffffffffffff;
                      do {
                        uVar24 = uVar24 + 1;
                      } while (*(short *)(lVar13 + uVar24 * 2) != 0);
                      if (_DAT_ != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100342;
                        cVar7 = func_0x(_DAT_,lVar13,uVar24 & 0xffffffff,
                                                (longlong)&uStackX_c + lVar12);
                        if (cVar7 != '\0') goto LAB_;
                      }
                      uVar17 = 2;
                      if (_DAT_ != 0) {
                        uVar17 = 4;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10036e;
                      (*_DAT_)(0x76,uVar17,0x10,0xb);
                      goto LAB_;
                    }
                    if (lVar13 == 0) goto LAB_;
                    uStack_4688 = *(undefined4 *)(lVar13 + 0x198);
                    uStack_4684 = *(undefined2 *)(lVar13 + 0x19c);
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) =
                         *(undefined8 *)(param_1 + 0xb0);
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003c6;
                    func_0x(0xcd9210,uVar9,&uStack_4688,uVar22);
                  }
                  uVar17 = *(undefined8 *)(param_1 + 0xb0);
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003e3;
                  uStack_4678 = uVar22;
                  uStack_4674 = uVar9;
                  func_0x(1,&uStack_4678,uVar17);
                }
                else if (lVar13 != 0) {
                  bVar33 = uVar9 < *(ushort *)(lVar13 + 0x19c);
                  bVar34 = uVar9 == *(ushort *)(lVar13 + 0x19c);
                  if (bVar34) {
                    bVar33 = uVar22 + 7 < *(uint *)(lVar13 + 0x198);
                    bVar34 = uVar22 + 7 == *(uint *)(lVar13 + 0x198);
                  }
                  if (bVar33 || bVar34) {
                    uVar19 = puVar26[-0x10];
                    uVar1 = *(ushort *)(lVar13 + 0x40);
                    uVar2 = *(ushort *)(*(longlong *)(lVar13 + 0x108) + 0x1490);
                    if (_DAT_ != 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002ea;
                      func_0x(_DAT_,(longlong)&uStackX_c + lVar12,
                                      (uint)uVar1 * 0x10000 + (uint)uVar2,
                                      3 - (uint)((uVar19 & 0x200) != 0));
                    }
                  }
                }
LAB_:
                uVar24 = (ulonglong)*(uint *)((longlong)&uStackX_8 + lVar12);
              }
            }
          }
        }
LAB_:
        uVar32 = (int)plVar16 + 1;
        plVar16 = (longlong *)(ulonglong)uVar32;
        puVar26 = puVar26 + 0x1000;
      } while (uVar32 < (uint)uVar24);
      param_2 = *(undefined (**) [16])(&stack0x00000030 + lVar12);
    }
    uVar22 = (uint)uVar24;
    plVar16 = *(longlong **)(param_1 + 0x868);
    if (*(longlong **)(param_1 + 0x868) == (longlong *)(param_1 + 0x860)) {
      plVar16 = plVar21;
    }
    plVar28 = (longlong *)0x60;
    if (plVar16 != (longlong *)0x0) {
      plVar28 = plVar16 + 7;
    }
    lStack_4648 = *(longlong *)(*(longlong *)(*plVar28 + 0x10) + 0xf0);
    if ((lStack_4648 != 0) && (uVar22 != 0)) {
      param_2 = param_2 + 2;
      do {
        if (*(int *)*param_2 == 9) {
          if (*(short *)(*param_2 + 4) != 1) {
LAB_:
            uVar31 = *(undefined2 *)(*param_2 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100493;
            lVar13 = func_0x(param_1,0,uVar31);
            plVar16 = plVar21;
            if (lVar13 != 0) {
              plVar16 = *(longlong **)(lVar13 + 0x4e0);
            }
            uVar9 = *(ushort *)(param_2[-2] + 4);
            if ((uVar9 >> 9 & 1) == 0) {
              plVar28 = plVar21;
              if ((uVar9 >> 8 & 1) != 0) {
                plVar28 = (longlong *)0x2;
              }
            }
            else {
              plVar28 = (longlong *)0x1;
            }
            if ((uVar9 & 0xc00) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1004d2;
              func_0x(param_2 + -2,plVar28,plVar16);
            }
          }
        }
        else if (*(int *)*param_2 != 0) goto LAB_;
        param_2 = param_2 + 0x200;
        uVar24 = uVar24 - 1;
      } while (uVar24 != 0);
      param_2 = *(undefined (**) [16])(&stack0x00000030 + lVar12);
      uVar22 = *(uint *)((longlong)&uStackX_8 + lVar12);
    }
    *(uint *)((longlong)&uStackX_8 + lVar12) = uVar22 >> 3;
    *(undefined4 *)(&stack0x00000028 + lVar12) = 0;
    uVar22 = *(uint *)((longlong)&uStackX_8 + lVar12);
    plVar16 = plVar21;
    if (uVar22 != 0) {
      do {
        iVar10 = (int)plVar16;
        if ((*param_2)[1] != 'e') {
          iVar11 = *(int *)param_2[2];
          *(int *)((longlong)&uStackX_c + lVar12) = iVar11;
          uVar9 = *(ushort *)(param_2[2] + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10052a;
          lVar13 = func_0x(param_1,0,uVar9);
          if (lVar13 == 0) {
LAB_:
            *(uint *)(param_1 + 0x1604) = *(uint *)(param_1 + 0x1604) | 0x5000;
            if ((*(uint *)(param_1 + 0x15f8) >> 0x19 & 1) == 0) {
              uVar17 = *(undefined8 *)(param_1 + 0xb0);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c7f;
              iStack_4668 = iVar11;
              uStack_4664 = uVar9;
              func_0x(3,&iStack_4668,uVar17);
            }
            else {
              if (((*(uint *)(param_1 + 0x15f8) >> 0xe & 1) == 0) && ((DAT_ & 4) == 0)) {
                lVar13 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
                if ((lVar13 != 0) && (**(longlong **)(lVar13 + 0x38) != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1005cb;
                  iVar11 = (*_DAT_)();
                  if (iVar11 != 0) goto LAB_;
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1005e7;
                func_0x(0xc6f,uVar9,*(undefined4 *)((longlong)&uStackX_c + lVar12));
              }
LAB_:
              uStack_4658 = 0;
              *param_2 = ZEXT816(0);
              param_2[1] = ZEXT816(0);
              param_2[2] = ZEXT816(0);
              param_2[3] = ZEXT816(0);
              param_2[4] = ZEXT816(0);
              param_2[5] = ZEXT816(0);
              (*param_2)[0] = 1;
              *(undefined2 *)(param_2[2] + 4) = 0;
              *(undefined4 *)(param_2[1] + 0xc) = 0x601fa0;
              *(undefined8 *)(param_2[2] + 8) = 0;
              *(undefined2 *)param_2[3] = 1;
              if (1 < (0xfd0 - (ulonglong)*(ushort *)(param_2[1] + 6)) * 2) {
                *(undefined2 *)param_2[6] = 0;
              }
              (*param_2)[1] = 0x65;
            }
          }
          else if ((*(byte *)(param_1 + 0x1614) & 0x10) == 0) {
            bVar33 = uVar9 < *(ushort *)(lVar13 + 0x19c);
            bVar34 = uVar9 == *(ushort *)(lVar13 + 0x19c);
            if (bVar34) {
              bVar33 = iVar11 + 7U < *(uint *)(lVar13 + 0x198);
              bVar34 = iVar11 + 7U == *(uint *)(lVar13 + 0x198);
            }
            if (!bVar33 && !bVar34) goto LAB_;
          }
          else {
            uVar22 = *(uint *)(lVar13 + 0x198);
            uVar24 = (ulonglong)(uVar22 + 1);
            uVar19 = *(ushort *)(lVar13 + 0x19c);
            bVar33 = uVar9 < uVar19;
            if (uVar9 == uVar19) {
              bVar33 = iVar11 + 7U < uVar22;
            }
            if (bVar33 || uVar9 == uVar19 && iVar11 + 7U == uVar22) {
              if (((*param_2)[1] == '\x0f') && (iVar11 == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006aa;
                func_0x(&uStack_4048,param_2,0x2000);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006c4;
                iVar10 = func_0x(&uStack_4048,1,lStack_4648,1);
                if (iVar10 == 0) {
                  uVar31 = 0xffff;
                  sStack_40f8 = 0xffff;
                  plStack_40f0 = (longlong *)0x0;
                  uStack_40f4 = 0;
                  uStack_40da = 0;
                  uStack_40d8 = 0;
                  uStack_40d0 = 0;
                  uStack_40ce = 0;
                  uStack_40cc = 0;
                  uStack_40ca = 0;
                  uStack_40e8 = (longlong *)0x0;
                  *(undefined4 *)((longlong)&iStackX_18 + lVar12) = 0;
                  *(undefined2 *)((longlong)&uStackX_1c + lVar12) = 0;
                  puVar26 = (ushort *)((longlong)&uStackX_1c + lVar12 + 2);
                  *puVar26 = *puVar26 & 0xffe0;
                  *(undefined8 *)((longlong)&uStackX_1c + lVar12 + 4) = 0;
                  uStack_40c4 = 0;
                  plVar16 = plVar21;
                  if ((uStack_4048._2_1_ & 0x80) != 0) {
                    sStack_4098 = 0;
                    sStack_4096 = 0;
                    sStack_4094 = 0;
                    uStack_408a = 0;
                    uStack_4080 = SUB164(ZEXT816(0),0);
                    uStack_4080 = 0;
                    uStack_407c = SUB164(ZEXT816(0),4);
                    uStack_407c = 0;
                    puStack_4070 = (undefined *)0x0;
                    sStack_4068 = 0;
                    uStack_4066 = 0;
                    auStack_40c0 = ZEXT816(0);
                    uVar17 = 0;
                    _auStack_40ae = SUB1614(ZEXT816(0),2);
                    auStack_40b0 = (undefined  [2])0xffff;
                    auStack_40ac._4_8_ = 0;
                    uStack_4092 = 0;
                    uStack_4090 = 0;
                    uStack_4088 = 0;
                    uStack_4086 = 0;
                    uStack_40a0 = 0;
                    uStack_409c = 0;
                    psStack_4078 = (short *)0x0;
                    _auStack_4060 = ZEXT812(0);
                    auStack_4056._2_4_ = 0;
                    uStack_4050 = 0;
                    if ((uStack_4024 == 0) ||
                       ((((uStack_4048._1_1_ != '\v' || (iStack_4030 != 99)) &&
                         ((uStack_4048._1_1_ != '\b' || (iStack_4030 != 99)))) &&
                        ((uStack_4048._1_1_ != '\t' || (iStack_4030 != 99)))))) {
LAB_:
                      auStack_40c0._8_8_ = uVar17;
                      *(undefined8 *)(&stack0x00000038 + lVar12) = uStack_4020;
                      *(undefined2 *)(&stack0x00000040 + lVar12) = uStack_4018;
                      uVar18 = uStack_4018;
                    }
                    else {
                      uStack_4670 = uStack_4028;
                      uStack_466c = uStack_4024;
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10080d;
                      uVar31 = 0xffff;
                      cVar7 = func_0x(&uStack_4670);
                      uVar17 = auStack_40c0._8_8_;
                      if (cVar7 == '\0') goto LAB_;
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100822;
                      func_0x(&uStack_4048,&stack0x00000038 + lVar12);
                      uVar18 = *(undefined2 *)(&stack0x00000040 + lVar12);
                    }
                    auVar5 = _auStack_4060;
                    auStack_40c0._0_8_ = auStack_3fe8;
                    auStack_4060._4_4_ =
                         (int)((ulonglong)*(undefined8 *)(&stack0x00000038 + lVar12) >> 0x20);
                    auStack_4060._0_4_ = *(undefined4 *)(&stack0x00000038 + lVar12);
                    auStack_4056 = auVar5._10_6_;
                    uStack_4058 = uVar18;
                    auStack_4056._2_4_ = uStack_4028;
                    uStack_4660 = *(undefined4 *)((ulonglong)auStack_3fe8[0] * 6 + 0x9d5c70);
                    uVar25 = (ulonglong)*(short *)((ulonglong)auStack_3fe8[0] * 6 + 0x9d5c74);
                    auStack_40b0 = (undefined  [2])uVar31;
                    _auStack_40b0 = _auStack_40b0 & 0xffffffff;
                    auStack_40ac._4_8_ = 0;
                    uStack_4092 = 0;
                    uStack_4090 = 0;
                    uStack_4088 = 0;
                    uStack_4086 = 0;
                    uStack_40a0 = 0;
                    uStack_409c = 0;
                    psStack_4078 = (short *)0x0;
                    puStack_4070 = (undefined *)0x0;
                    sStack_4068 = 0;
                    if ((auStack_3fe8[0] & 2) != 0) {
                      pbVar29 = auStack_3fe8 + uVar25;
                      auStack_40ac._4_8_ = pbVar29;
                      auVar5 = _auStack_40b0;
                      if ((*pbVar29 & 1) == 0) {
                        auVar5._14_2_ = 0;
                        auVar5._0_14_ = _auStack_40ae;
                        _auStack_40b0 = auVar5 << 0x10;
                        uStack_408a = 0;
                        uStack_4088 = 0;
                        uVar32 = uVar20;
                        switch(*pbVar29 & 0xe) {
                        default:
                          uVar32 = (uint)*(ushort *)(auStack_3fe8 + uVar25 + 2);
                          if (0x1f9d < *(ushort *)(auStack_3fe8 + uVar25 + 2) - 1) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100b0b;
                            func_0x(pbVar29,6);
                          }
                          break;
                        case 4:
                          uVar32 = 9;
                          break;
                        case 6:
                        case 10:
                          break;
                        case 0xe:
                          uVar32 = 1;
                        }
                        uStack_40a0 = uVar32;
                        uStack_4092 = 0;
                        uStack_4090 = 0;
                      }
                      else {
                        auStack_40b0 = (undefined  [2])0x1;
                        bVar8 = *pbVar29;
                        auStack_40ac = auVar5._4_12_;
                        switch(bVar8 & 0x1c) {
                        default:
                          if ((char)auStack_3fe8[uVar25 + 1] < '\0') {
                            sStack_4098 = 3;
                            auStack_40ae = (undefined  [2])
                                           ((*(ushort *)(auStack_3fe8 + uVar25 + 1) & 0x7f) << 8 |
                                           *(ushort *)(auStack_3fe8 + uVar25 + 1) >> 8);
                          }
                          else {
                            sStack_4098 = 2;
                            auStack_40ae = (undefined  [2])(ushort)(byte)auStack_3fe8[uVar25 + 1];
                          }
                          auStack_40b0 = (undefined  [2])0x1;
                          sStack_4094 = (short)((ushort)auStack_40ae + 1 >> 1) + sStack_4098;
                          if ((ushort)auStack_40ae < 0x1f) {
                            sStack_4096 = 0;
                            uStack_4080 = 0;
                            uStack_4088 = 0;
                            uStack_4086 = 0;
                            uStack_40a0 = 0;
                            uStack_409c = 0;
                          }
                          else {
                            iVar10 = (ushort)auStack_40ae - 1;
                            sStack_4096 = ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                                          (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
                            uStack_4080 = 0;
                            uStack_4088 = 0;
                            uStack_4086 = 0;
                            uStack_40a0 = 0;
                            uStack_409c = 0;
                          }
                          break;
                        case 4:
                          if (((bVar8 & 0x1c) == 4) && ((bVar8 & 2) != 0)) {
                            auStack_40ac._0_4_ = 0xf;
                            uStack_4080 = 1;
                          }
                          else {
                            auStack_40ac._0_4_ = 1;
                            uStack_4080 = uVar20;
                          }
                          sStack_4098 = 0;
                          sStack_4096 = 0;
                          sStack_4094 = 0;
                          uStack_408a = 0;
                          _auStack_40b0 = 1;
                          uStack_4088 = 0;
                          uStack_4086 = 0;
                          uStack_40a0 = 0;
                          uStack_409c = 0;
                          break;
                        case 8:
                          sStack_4098 = 0;
                          sStack_4096 = 0;
                          sStack_4094 = 0;
                          uStack_408a = 0;
                          _auStack_40b0 = 0x900000001;
                          uStack_4080 = 0;
                          uStack_4088 = 0;
                          uStack_4086 = 0;
                          uStack_40a0 = 0;
                          uStack_409c = 0;
                        }
                      }
                    }
                    uStack_4090 = 0;
                    uStack_4092 = 0;
                    if ((*(byte *)auStack_40c0._0_8_ & 4) != 0) {
                      if (uStack_4660._2_2_ != 0) {
                        uVar25 = (ulonglong)
                                 *(ushort *)(auStack_3fe8 + (longlong)uStack_4660._2_2_ * 2 + 1);
                      }
                      psStack_4078 = (short *)(auStack_3fe8 + uVar25);
                      puStack_4070 = auStack_3fe8 + uVar25 + 2;
                      sStack_4068 = (*(short *)(auStack_3fe8 + uVar25) + 1) * 2;
                    }
                    plVar16 = (longlong *)auStack_40c0;
                    if (auStack_40c0._8_8_ != 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100bb8;
                      func_0x(auStack_40c0._8_8_,auStack_40c0);
                    }
                  }
                  plVar28 = (longlong *)(ulonglong)uStack_403a;
                  uVar25 = (ulonglong)uStack_204a;
                  plStack_40f0 = (longlong *)((longlong)&uStack_4048 + uVar25);
                  if ((*(byte *)plStack_40f0 & 1) == 0) {
                    sStack_40f8 = 0;
                    uStack_40f4 = 0;
                    uStack_40d2 = 0;
                    uStack_40d0 = 0;
                    switch(*(byte *)plStack_40f0 & 0xe) {
                    default:
                      uVar9 = *(ushort *)((longlong)&uStack_4048 + uVar25 + 2);
                      plVar28 = (longlong *)(ulonglong)uVar9;
                      if (0x1f9d < uVar9 - 1) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100dd6;
                        func_0x(plStack_40f0,6);
                      }
                      break;
                    case 4:
                      plVar28 = (longlong *)0x9;
                      break;
                    case 6:
                    case 10:
                      break;
                    case 0xe:
                      plVar28 = (longlong *)0x1;
                    }
                    uStack_40e8 = (longlong *)CONCAT44(uStack_40e8._4_4_,(int)plVar28);
                    uStack_40da = SUB82(asStack_2048,0);
                    uStack_40d8 = (undefined6)((ulonglong)asStack_2048 >> 0x10);
                    plVar16 = plVar28;
                  }
                  else {
                    sStack_40f8 = 1;
                    bVar8 = *(byte *)plStack_40f0;
                    switch(bVar8 & 0x1c) {
                    default:
                      bVar8 = *(byte *)((longlong)&uStack_4048 + uVar25 + 1);
                      if ((char)bVar8 < '\0') {
                        uVar9 = *(ushort *)((longlong)&uStack_4048 + uVar25 + 1);
                        uStack_40f6 = (uVar9 & 0x7f) << 8 | uVar9 >> 8;
                        uStack_40e0._0_2_ = 3;
                        sVar30 = 3;
                      }
                      else {
                        uStack_40f6 = (ushort)bVar8;
                        uStack_40e0._0_2_ = 2;
                        sVar30 = 2;
                      }
                      uStack_40dc = (short)(uStack_40f6 + 1 >> 1) + sVar30;
                      if (uStack_40f6 < 0x1f) {
                        uStack_40e0._2_2_ = 0;
                        uStack_40f4 = 0;
                        uStack_40c8 = 0;
                      }
                      else {
                        iVar10 = uStack_40f6 - 1;
                        uStack_40e0._2_2_ =
                             ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                             (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
                        uStack_40f4 = 0;
                        uStack_40c8 = 0;
                      }
                      break;
                    case 4:
                      if (((bVar8 & 0x1c) == 4) && ((bVar8 & 2) != 0)) {
                        uStack_40e0._0_2_ = 0;
                        uStack_40e0._2_2_ = 0;
                        uStack_40dc = 0;
                        uStack_40da = 0;
                        uStack_40f6 = 0;
                        uStack_40d8 = 0;
                        uStack_40d2 = 0;
                        uStack_40f4 = 0xf;
                        uStack_40c8 = 1;
                      }
                      else {
                        uStack_40e0._0_2_ = 0;
                        uStack_40e0._2_2_ = 0;
                        uStack_40dc = 0;
                        uStack_40da = 0;
                        uStack_40f6 = 0;
                        uStack_40d8 = 0;
                        uStack_40d2 = 0;
                        uStack_40f4 = 1;
                        uStack_40c8 = 0;
                      }
                      break;
                    case 8:
                      uStack_40e0._0_2_ = 0;
                      uStack_40e0._2_2_ = 0;
                      uStack_40dc = 0;
                      uStack_40da = 0;
                      uStack_40f6 = 0;
                      uStack_40d8 = 0;
                      uStack_40d2 = 0;
                      uStack_40f4 = 9;
                      uStack_40c8 = 0;
                    }
                    uStack_40d0 = SUB82(asStack_2048,0);
                    uStack_40ce = (undefined2)((ulonglong)asStack_2048 >> 0x10);
                    uStack_40cc = (ushort)((ulonglong)asStack_2048 >> 0x20);
                    uStack_40ca = (undefined2)((ulonglong)asStack_2048 >> 0x30);
                    uStack_40e8 = plVar16;
                    plVar28 = (longlong *)((ulonglong)plVar16 & 0xffffffff);
                  }
                  *(undefined4 *)((longlong)&iStackX_18 + lVar12) = 0xfffffffb;
                  *(undefined2 *)((longlong)&uStackX_1c + lVar12) = 5;
                  uVar9 = *(ushort *)((longlong)&uStackX_1c + lVar12 + 2) & 0xffe0;
                  *(ushort *)((longlong)&uStackX_1c + lVar12 + 2) = uVar9;
                  *(undefined8 *)((longlong)&uStackX_1c + lVar12 + 4) = 0;
                  if (sStack_40f8 == 0) {
                    if ((*(byte *)plStack_40f0 & 0x10) == 0) {
                      if ((1 << (*(byte *)plStack_40f0 & 0xe) & 0x1105U) != 0) {
                        bVar8 = 0xff;
                        uVar32 = uVar20;
                        goto code_r0x00100ee2;
                      }
code_r0x00100f12:
                      uVar23 = uStack_40e0;
                      uVar32 = uStack_40e0;
                      if (uStack_40f4 == 0) {
                        uStack_40f6 = 0;
                        uVar32 = (uint)uStack_40e8;
                        if ((*(byte *)plStack_40f0 & 0x10) != 0) {
                          uVar32 = (uint)uStack_40e8 + 2 +
                                   (*(ushort *)
                                     (((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)plStack_40f0
                                     ) + 7 >> 3);
                        }
                        uStack_40e8 = (longlong *)CONCAT44(uVar32,(uint)uStack_40e8);
                        if ((*(byte *)plStack_40f0 & 0x20) == 0) {
                          uVar25 = (ulonglong)uVar32;
                          uStack_40f4 = uVar32;
                          uStack_40dc = 0;
                          uStack_40e0._0_2_ = (undefined2)uVar32;
                          uStack_40e0._2_2_ = (short)(uVar32 >> 0x10);
                          uStack_40e0 = uVar32;
                        }
                        else {
                          puVar26 = (ushort *)((ulonglong)uVar32 + (longlong)plStack_40f0);
                          uStack_40dc = *puVar26;
                          if (*puVar26 == 0) {
                            if ((((cRam00000000012e875b != '\0') ||
                                 ((bRam00000000012f9060 & 1) != 0)) &&
                                (lVar15 = *(longlong *)
                                           ((ulonglong)*_DAT_ +
                                            *(longlong *)
                                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                             (ulonglong)*_DAT_ * 8) + 8), lVar15 != 0)) &&
                               ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                                (*(char *)(lVar15 + 0x499) != '\0')))) {
                              if ((cRam00000000012e864b == '\0') &&
                                 ((bRam00000000012f9060 & 2) == 0)) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ff8;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10101c;
                                (*_DAT_)(1,0xbd9188,0xcf8e58,0x80f);
                              }
                            }
                            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10102d;
                            func_0x(plStack_40f0,3);
                          }
                          uVar32 = uStack_40e8._4_4_ + (uStack_40dc + 1) * 2;
                          uStack_40e0._0_2_ = (undefined2)uVar32;
                          uStack_40e0._2_2_ = (short)(uVar32 >> 0x10);
                          uStack_40e0 = uVar32;
                          if (0x1f9e < uVar32) {
                            if (((cRam00000000012e875b != '\0') || ((bRam00000000012f9060 & 1) != 0)
                                ) && ((lVar15 = *(longlong *)
                                                 ((ulonglong)*_DAT_ +
                                                  *(longlong *)
                                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                                   (ulonglong)*_DAT_ * 8) + 8), lVar15 != 0
                                      && ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                                          (*(char *)(lVar15 + 0x499) != '\0')))))) {
                              if ((cRam00000000012e864b == '\0') &&
                                 ((bRam00000000012f9060 & 2) == 0)) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1010d0;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1010f4;
                                (*_DAT_)(1,0xbd9188,0xcf8e58,0x816);
                              }
                            }
                            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101107;
                            func_0x(plStack_40f0,4);
                          }
                          uStack_40f4 = puVar26[uStack_40dc] & 0x7fff;
                          uVar25 = (ulonglong)uStack_40f4;
                          uVar32 = uStack_40e0;
                          if (uStack_40f4 < uStack_40e0) {
                            if ((((cRam00000000012e875b != '\0') ||
                                 ((bRam00000000012f9060 & 1) != 0)) &&
                                (lVar15 = *(longlong *)
                                           ((ulonglong)*_DAT_ +
                                            *(longlong *)
                                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                             (ulonglong)*_DAT_ * 8) + 8), lVar15 != 0)) &&
                               ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                                (*(char *)(lVar15 + 0x499) != '\0')))) {
                              if ((cRam00000000012e864b == '\0') &&
                                 ((bRam00000000012f9060 & 2) == 0)) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1011b2;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1011d6;
                                (*_DAT_)(1,0xbd9188,0xcf8e58,0x81d);
                              }
                            }
                            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1011e4;
                            func_0x(plStack_40f0,4);
                            uVar25 = (ulonglong)uStack_40f4;
                            uVar32 = uStack_40e0;
                          }
                          do {
                            if (-1 < (short)puVar26[(ulonglong)(uStack_40dc - 1) + 1]) break;
                            uVar27 = uStack_40e0;
                            if (uStack_40dc != 1) {
                              uVar27 = *(ushort *)
                                        ((longlong)plStack_40f0 +
                                        (ulonglong)uStack_40dc * 2 +
                                        (((ulonglong)uStack_40e8 >> 0x20) - 2)) & 0x7fff;
                            }
                            if ((uVar27 < uStack_40e0) ||
                               ((*(ushort *)
                                  ((longlong)plStack_40f0 +
                                  (ulonglong)uStack_40dc * 2 + ((ulonglong)uStack_40e8 >> 0x20)) &
                                0x7fff) < uVar27)) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10125c;
                              uStack_40e0 = uVar32;
                              func_0x(plStack_40f0);
                              uVar25 = (ulonglong)uStack_40f4;
                              uVar32 = uStack_40e0;
                            }
                            uVar23 = uStack_40e0;
                            if ((uVar27 < uStack_40e0) || ((uint)uVar25 < uVar27))
                            goto code_r0x0010159e;
                            if (*(ushort *)((ulonglong)uVar27 + (longlong)plStack_40f0) == 5) {
                              uStack_40f6 = uStack_40f6 | 2;
                              uStack_40dc = uStack_40dc - 1;
                              uStack_40ce = (short)uVar27;
                              uVar9 = *(ushort *)
                                       ((longlong)plStack_40f0 + (ulonglong)(uVar27 & 0xffff) + 2);
                              if ((uVar9 & 0x4000) == 0) {
                                uStack_40cc = uStack_40cc & 0xc7ff;
                              }
                              else {
                                uStack_40cc = uStack_40cc ^ (uVar9 ^ uStack_40cc) & 0x3800;
                              }
                              uStack_40cc = uStack_40cc ^
                                            (uStack_40cc ^
                                            *(ushort *)
                                             ((longlong)plStack_40f0 +
                                             (ulonglong)(uVar27 & 0xffff) + 2)) & 0x7ff;
                              break;
                            }
                            if (*(ushort *)((ulonglong)uVar27 + (longlong)plStack_40f0) < 0x400)
                            break;
                            uStack_40f6 = uStack_40f6 | 1;
                            uStack_40dc = uStack_40dc - 1;
                          } while (uStack_40dc != 0);
                        }
                        if ((*(byte *)plStack_40f0 & 0x40) == 0) {
                          uStack_40d2 = 0;
                          uStack_40d0 = 0;
                        }
                        else {
                          uStack_40d2 = (undefined2)uVar25;
                          uStack_40d0 = (undefined2)(uVar25 >> 0x10);
                          uStack_40f4 = (int)uVar25 + 0xe;
                          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10138a;
                          uStack_40e0 = uVar32;
                          puVar14 = (ulonglong *)func_0x(&uStack_40f6);
                          uVar25 = *puVar14;
                          uVar19 = (ushort)(uVar25 >> 0x30);
                          uVar9 = uVar19;
                          if ((((uint)(int)(short)uVar19 >> 1 ^ (int)(short)uVar19) & 0x2000) != 0)
                          {
                            uVar9 = uVar19 & 0xdfff;
                            if ((uVar25 & 0x4000000000000000) != 0) {
                              uVar9 = uVar19 | 0x2000;
                            }
                          }
                          uVar32 = uVar20;
                          if (uVar9 == 0xfffc) {
                            uVar32 = (uint)((uVar25 >> 0x20 & 0xffff) >> 5);
                          }
                          uVar25 = (ulonglong)(uStack_40f4 + uVar32);
                          uStack_40f4 = uStack_40f4 + uVar32;
                          uVar32 = uStack_40e0;
                        }
                        uVar27 = (uint)uVar25;
                        if (((byte *)CONCAT62(uStack_40d8,uStack_40da) != (byte *)0x0) &&
                           ((byte *)CONCAT62(uStack_40d8,uStack_40da) <
                            (byte *)(uVar25 + (longlong)plStack_40f0))) {
                          uStack_40e0 = uVar32;
                          if (((cRam00000000012e875b != '\0') || ((bRam00000000012f9060 & 1) != 0))
                             && (((lVar15 = *(longlong *)
                                             ((ulonglong)*_DAT_ +
                                              *(longlong *)
                                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                               (ulonglong)*_DAT_ * 8) + 8), lVar15 != 0 &&
                                  (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
                                 (*(char *)(lVar15 + 0x499) != '\0')))) {
                            if ((cRam00000000012e864b == '\0') && ((bRam00000000012f9060 & 2) == 0))
                            {
                              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101499;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1014bd;
                              (*_DAT_)(1,0xbd9188,0xcf8e58,0x877);
                            }
                          }
                          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1014ce;
                          func_0x(plStack_40f0);
                          uVar27 = uStack_40f4;
                          uVar32 = uStack_40e0;
                        }
                        uVar23 = uStack_40e0;
                        if (0x3f3b < uVar27 - 1) {
                          uStack_40e0 = uVar32;
                          if (((cRam00000000012e875b != '\0') || ((bRam00000000012f9060 & 1) != 0))
                             && ((lVar15 = *(longlong *)
                                            ((ulonglong)*_DAT_ +
                                             *(longlong *)
                                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                              (ulonglong)*_DAT_ * 8) + 8), lVar15 != 0 &&
                                 ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                                  (*(char *)(lVar15 + 0x499) != '\0')))))) {
                            if ((cRam00000000012e864b == '\0') && ((bRam00000000012f9060 & 2) == 0))
                            {
                              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101565;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101589;
                              (*_DAT_)(1,0xbd9188,0xcf8e58,0x87c);
                            }
                          }
                          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101597;
                          func_0x(plStack_40f0);
                          uVar23 = uStack_40e0;
                          uVar32 = uStack_40e0;
                        }
                      }
code_r0x0010159e:
                      sVar30 = -*(short *)((longlong)&iStackX_18 + lVar12);
                      uStack_40e0 = uVar32;
                      if ((*(byte *)((longlong)&uStackX_1c + lVar12 + 2) & 0x10) != 0) {
                        if ((*(byte *)plStack_40f0 & 0x10) == 0) {
                          if ((1 << (*(byte *)plStack_40f0 & 0xe) & 0x1105U) != 0) {
code_r0x00101615:
                            puVar3 = *(undefined4 **)((longlong)&uStackX_1c + lVar12 + 4);
                            plVar16 = (longlong *)(puVar3 + 1);
                            *(undefined4 *)((longlong)&iStackX_14 + lVar12) = *puVar3;
                            goto code_r0x00101724;
                          }
                        }
                        else if (((int)(uint)uStack_40e8 <= *(int *)((longlong)&iStackX_18 + lVar12)
                                 ) || (*(ushort *)
                                        ((longlong)plStack_40f0 +
                                        ((ulonglong)uStack_40e8 & 0xffffffff)) <
                                       *(ushort *)((longlong)&uStackX_1c + lVar12)))
                        goto code_r0x00101615;
                      }
                      if ((uint)uStack_40dc < (uint)(int)sVar30) {
                        *(undefined4 *)((longlong)&iStackX_14 + lVar12) = 0;
                        plVar16 = plStack_40f0;
                      }
                      else {
                        uVar27 = uVar23;
                        if (sVar30 != 1) {
                          uVar23 = *(ushort *)
                                    ((longlong)plStack_40f0 +
                                    (longlong)sVar30 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) &
                                   0x7fff;
                          uVar27 = uVar32;
                        }
                        uVar32 = *(ushort *)
                                  ((longlong)plStack_40f0 +
                                  (longlong)sVar30 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) & 0x7fff;
                        if ((uVar23 < uVar27) || (uVar32 < uVar23)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101662;
                          func_0x(plStack_40f0);
                        }
                        *(uint *)((longlong)&iStackX_14 + lVar12) = uVar32 - uVar23;
                        plVar16 = (longlong *)((ulonglong)uVar23 + (longlong)plStack_40f0);
                      }
                    }
                    else {
                      if ((int)plVar16 < -4) {
                        bVar8 = 0xff;
                        uVar32 = 0;
                      }
                      else if (*(ushort *)((longlong)plVar28 + (longlong)plStack_40f0) < 5) {
                        bVar8 = 0xff;
                        uVar32 = 0;
                      }
                      else {
                        bVar8 = ((byte *)((longlong)plVar28 + 2))[(longlong)plStack_40f0] >> 4;
                        uVar32 = 1;
                      }
code_r0x00100ee2:
                      if ((bVar8 & 1) == 0) {
                        if ((uVar32 != 0) ||
                           ((*(byte *)((longlong)&uStackX_1c + lVar12 + 2) & 0x10) == 0))
                        goto code_r0x00100f12;
                        *(undefined4 *)((longlong)&iStackX_14 + lVar12) =
                             **(undefined4 **)((longlong)&uStackX_1c + lVar12 + 4);
                        plVar16 = (longlong *)0x4;
                      }
                      else {
                        *(undefined4 *)((longlong)&iStackX_14 + lVar12) = 0;
                        plVar16 = plVar21;
                      }
                    }
                  }
                  else {
                    *(undefined4 *)(&stack0x0000002c + lVar12) = 0;
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar12) = &stack0x0000002c + lVar12;
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1016ac;
                    plVar16 = (longlong *)
                              func_0x(&uStack_40f6,(longlong)&iStackX_18 + lVar12,uVar9,
                                              (longlong)&iStackX_14 + lVar12);
                    plVar28 = uStack_40e8;
                    if ((((sStack_40f8 != 0) && (uStack_40e8 != (longlong *)0x0)) &&
                        (*uStack_40e8 != 0)) &&
                       (((*(byte *)((longlong)&uStackX_1c + lVar12 + 2) & 8) == 0 &&
                        ((*(uint *)(&stack0x0000002c + lVar12) & 1) == 0)))) {
                      if ((plVar16 == (longlong *)0x0) || (plVar16 == (longlong *)0x95dbc4)) {
                        *(undefined4 *)((longlong)&iStackX_14 + lVar12) = 0;
                        plVar16 = (longlong *)0x0;
                      }
                      else {
                        *(uint *)((longlong)&uStackX_1c + lVar12 + -0x1c) =
                             *(uint *)(&stack0x0000002c + lVar12);
                        *(longlong *)(&stack0xfffffffffffffff8 + lVar12) =
                             (longlong)&iStackX_14 + lVar12;
                        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar12) = 0;
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101718;
                        plVar16 = (longlong *)
                                  func_0x
                                            (plVar28,(longlong)&iStackX_18 + lVar12,plVar16,
                                             *(undefined4 *)((longlong)&iStackX_14 + lVar12));
                      }
                    }
                  }
code_r0x00101724:
                  uVar32 = *(uint *)plVar16;
                  if (uVar22 + 1 < uVar32) {
                    if ((_DAT_ & 0x2000000) != 0) {
                      uStack_45f0 = 0x30000;
                      uStack_45e8 = 0;
                      ppuStack_45e0 = &puStack_45c8;
                      puStack_45d8 = auStack_4598;
                      uStack_43a8 = 0;
                      uStack_45d0 = 0;
                      uStack_43a0 = 0;
                      puStack_45c8 = auStack_4398;
                      uStack_45c0 = 0x12;
                      uStack_45bc = 2;
                      uStack_45ac = 2;
                      uStack_45a8 = 0;
                      uStack_45a0 = 0;
                      uStack_459c = 3;
                      auStack_4398[0] = 0x101;
                      lStack_45b8 = *(longlong *)(param_1 + 0xb0);
                      uStack_45b0 = uVar20;
                      if (lStack_45b8 != 0) {
                        lVar15 = -1;
                        do {
                          lVar15 = lVar15 + 1;
                        } while (*(short *)(lStack_45b8 + lVar15 * 2) != 0);
                        uStack_45b0 = (int)lVar15 * 2;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1017ed;
                      func_0x(asStack_2048,0,0x1000);
                      *(int *)(&stack0xffffffffffffffe8 + lVar12) = *(int *)(lVar13 + 0x198) + 1;
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101816;
                      func_0x(asStack_2048,0x800,0xcd9d90,uVar32);
                      ppuVar6 = ppuStack_45e0;
                      lVar15 = -1;
                      do {
                        lVar15 = lVar15 + 1;
                      } while (asStack_2048[lVar15] != 0);
                      ppuStack_45e0[4] = asStack_2048;
                      *(int *)(ppuVar6 + 5) = (int)lVar15 * 2;
                      *(undefined4 *)((longlong)ppuVar6 + 0x2c) = 3;
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101852;
                      func_0x(auStack_45f8);
                    }
                    if ((DAT_ & 0x40) == 0) {
                      lVar15 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8));
                      if ((lVar15 != 0) && (**(longlong **)(lVar15 + 0x38) != 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101899;
                        iVar10 = (*_DAT_)();
                        if (iVar10 != 0) goto code_r0x001018a0;
                      }
                    }
                    else {
code_r0x001018a0:
                      iVar10 = *(int *)(lVar13 + 0x198);
                      uVar17 = *(undefined8 *)(param_1 + 0xb0);
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1018c1;
                      func_0x(0xcd9cd0,uVar17,uVar32,iVar10 + 1);
                    }
                    uVar24 = (ulonglong)uVar32;
                  }
                  param_2 = *(undefined (**) [16])(&stack0x00000030 + lVar12);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101a1c;
                  func_0x(0xcd9f10);
                }
              }
            }
            else {
              uVar24 = (ulonglong)(iVar11 + 8);
            }
            uVar22 = (uint)uVar24;
            if (*(int *)(lVar13 + 0x198) + 1U < uVar22) {
              uStack_4638 = 0;
              auStack_4630[0] = 0x4000e1;
              uStack_4628 = 0;
              uStack_4618 = 0;
              uStack_4620 = 0;
              uStack_4610 = 0;
              (&stack0xffffffffffffffe8)[lVar12] = 1;
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10191d;
              lStack_4640 = param_1;
              iVar10 = (*_DAT_)(param_1 + 0x1598,0xffffffff,auStack_4630,0);
              if (iVar10 != 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c89;
                func_0x(param_1);
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
              }
              uStack_4638 = 1;
              uVar32 = *(int *)(lVar13 + 0x198) + 1;
              if (uVar32 < uVar22) {
                if ((_DAT_ & 0x2000000) != 0) {
                  uStack_4370 = 0x30000;
                  uStack_4368 = 0;
                  ppuStack_4360 = &puStack_4348;
                  puStack_4358 = auStack_4318;
                  uStack_4128 = 0;
                  uStack_4350 = 0;
                  uStack_4120 = 0;
                  puStack_4348 = auStack_4118;
                  uStack_4340 = 0x12;
                  uStack_433c = 2;
                  uStack_432c = 2;
                  uStack_4328 = 0;
                  uStack_4320 = 0;
                  uStack_431c = 3;
                  auStack_4118[0] = 0x101;
                  lStack_4338 = *(longlong *)(param_1 + 0xb0);
                  uStack_4330 = uVar20;
                  if (lStack_4338 != 0) {
                    lVar15 = -1;
                    do {
                      lVar15 = lVar15 + 1;
                    } while (*(short *)(lStack_4338 + lVar15 * 2) != 0);
                    uStack_4330 = (int)lVar15 * 2;
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101a44;
                  func_0x(asStack_1048,0,0x1000);
                  *(uint *)(&stack0xffffffffffffffe8 + lVar12) = uVar22;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101a64;
                  func_0x(asStack_1048,0x800,0xcd9e30);
                  ppuVar6 = ppuStack_4360;
                  lVar15 = -1;
                  do {
                    lVar15 = lVar15 + 1;
                  } while (asStack_1048[lVar15] != 0);
                  ppuStack_4360[4] = asStack_1048;
                  *(int *)(ppuVar6 + 5) = (int)lVar15 * 2;
                  *(undefined4 *)((longlong)ppuVar6 + 0x2c) = 3;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101aa6;
                  func_0x(auStack_4378);
                }
                if ((DAT_ & 0x40) == 0) {
                  lVar15 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            );
                  if ((lVar15 != 0) && (**(longlong **)(lVar15 + 0x38) != 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101aed;
                    iVar10 = (*_DAT_)();
                    if (iVar10 != 0) goto code_r0x00101af4;
                  }
                }
                else {
code_r0x00101af4:
                  uVar17 = *(undefined8 *)(param_1 + 0xb0);
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b0d;
                  func_0x(0xcd9ab0,uVar17,uVar32);
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b15;
                iVar10 = func_0x(param_1);
                if (iVar10 == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b25;
                  lVar15 = func_0x(lVar13);
                  if (lVar15 == 0) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b4c;
                    (*_DAT_)(1,0xdb0b48,0xd601d0);
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b54;
                  lVar15 = func_0x(lVar13);
                  if ((*(uint *)(lVar15 + 0x1fc) >> 2 & 1) == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b71;
                    plVar16 = (longlong *)func_0x(lVar13);
                    pcVar4 = *(code **)(*plVar16 + 0x60);
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b84;
                    (*pcVar4)(plVar16,uVar24,1);
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b8c;
                    uVar17 = func_0x(lVar13);
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b97;
                    func_0x(uVar17,uVar24);
                    if (((_DAT_ != 0) && (DAT_ != '\0')) &&
                       ((DAT_ & 2) == 0)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101bba;
                      plVar16 = (longlong *)func_0x(lVar13);
                      pcVar4 = *(code **)(*plVar16 + 0x170);
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101bc6;
                      iVar10 = (*pcVar4)(plVar16);
                      if (iVar10 == 0) goto LAB_;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101bd5;
                    plVar16 = (longlong *)func_0x(lVar13);
                    pcVar4 = *(code **)(*plVar16 + 0x20);
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101be9;
                    (*pcVar4)(plVar16,0,uVar32);
                  }
                }
LAB_:
                *(int *)(lVar13 + 0x198) = *(int *)(lVar13 + 0x198) + (uVar22 - uVar32);
                *(ulonglong *)(lVar13 + 0x90) = uVar24;
              }
              uStack_4638 = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c12;
              func_0x(param_1 + 0x1598);
            }
            iVar10 = *(int *)(&stack0x00000028 + lVar12);
          }
          uVar22 = *(uint *)((longlong)&uStackX_8 + lVar12);
        }
        uVar32 = iVar10 + 1;
        plVar16 = (longlong *)(ulonglong)uVar32;
        *(uint *)(&stack0x00000028 + lVar12) = uVar32;
        param_2 = param_2 + 0x1000;
        *(undefined (**) [16])(&stack0x00000030 + lVar12) = param_2;
      } while (uVar32 < uVar22);
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c48;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12));
  return;
}

