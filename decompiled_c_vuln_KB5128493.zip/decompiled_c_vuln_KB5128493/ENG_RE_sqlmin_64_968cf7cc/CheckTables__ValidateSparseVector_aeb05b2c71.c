
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2,longlong param_3)

{
  byte bVar1;
  ushort uVar2;
  int iVar3;
  ulonglong *puVar4;
  longlong lVar5;
  ulonglong uVar6;
  uint uVar7;
  undefined4 uVar8;
  longlong lVar9;
  ulonglong uVar10;
  uint uVar11;
  longlong lVar12;
  ulonglong uVar13;
  ushort *puVar14;
  ushort uVar15;
  ushort uVar16;
  byte *pbVar17;
  undefined8 uVar18;
  uint uVar19;
  int iVar20;
  longlong unaff_GS_OFFSET;
  uint uStackX_20;
  ulonglong uStack_68;
  longlong lStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined2 uStack_50;
  undefined2 uStack_4e;
  
  iVar20 = 0;
  uStack_68 = 0;
  uStackX_20 = 0xffffffff;
  iVar3 = func_0x(param_3 + 0xa0);
  if (0 < iVar3) {
    lStack_60 = 0;
    do {
      uVar13 = 0;
      if (*(int *)(param_3 + 0xa4) == 0) {
        pbVar17 = *(byte **)(param_3 + 0xa8);
        uVar11 = *(uint *)(param_3 + 0xb0);
        uVar10 = (ulonglong)uVar11;
        *(undefined2 *)(param_3 + 0xa2) = 0;
        *(uint *)(param_3 + 0xb4) = uVar11;
        bVar1 = *pbVar17;
        if ((bVar1 & 0x10) != 0) {
          uVar11 = uVar11 + 2 + (*(ushort *)(pbVar17 + uVar10) + 7 >> 3);
          uVar10 = (ulonglong)uVar11;
          *(uint *)(param_3 + 0xb4) = uVar11;
          bVar1 = *pbVar17;
        }
        if ((bVar1 & 0x20) == 0) {
          *(int *)(param_3 + 0xa4) = (int)uVar10;
          *(undefined2 *)(param_3 + 0xbc) = 0;
          *(int *)(param_3 + 0xb8) = (int)uVar10;
        }
        else {
          puVar14 = (ushort *)(pbVar17 + uVar10);
          uVar2 = *puVar14;
          *(ushort *)(param_3 + 0xbc) = uVar2;
          if (uVar2 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar5 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar5 != 0)) &&
               ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                (*(char *)(lVar5 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0xd74df8,0xe94ac8,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 0xa8),3);
            uVar10 = (ulonglong)*(uint *)(param_3 + 0xb4);
            uVar2 = *(ushort *)(param_3 + 0xbc);
          }
          uVar11 = (int)uVar10 + (uVar2 + 1) * 2;
          *(uint *)(param_3 + 0xb8) = uVar11;
          if (0x1f9e < uVar11) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar5 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar5 != 0 &&
                ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                 (*(char *)(lVar5 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xd74df8,0xe94ac8,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 0xa8),4);
            uVar2 = *(ushort *)(param_3 + 0xbc);
            uVar11 = *(uint *)(param_3 + 0xb8);
          }
          uVar10 = (ulonglong)uVar2;
          uVar2 = puVar14[uVar10];
          *(uint *)(param_3 + 0xa4) = uVar2 & 0x7fff;
          if ((uVar2 & 0x7fff) < uVar11) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar5 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar5 != 0)) &&
               ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                (*(char *)(lVar5 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xd74df8,0xe94ac8,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 0xa8),4);
            uVar10 = (ulonglong)*(ushort *)(param_3 + 0xbc);
          }
          if ((short)puVar14[(ulonglong)((int)uVar10 - 1) + 1] < 0) {
            lVar5 = *(longlong *)(param_3 + 0xa8);
            do {
              lVar12 = (ulonglong)*(uint *)(param_3 + 0xb4) + lVar5;
              if ((int)uVar10 == 1) {
                uVar11 = *(uint *)(param_3 + 0xb8);
                uVar7 = uVar11;
LAB_:
                if ((*(ushort *)(lVar12 + uVar10 * 2) & 0x7fff) < uVar11) goto LAB_;
              }
              else {
                uVar7 = *(uint *)(param_3 + 0xb8);
                uVar11 = *(ushort *)(lVar12 + -2 + uVar10 * 2) & 0x7fff;
                if (uVar7 <= uVar11) goto LAB_;
LAB_:
                func_0x(lVar5,7);
                uVar7 = *(uint *)(param_3 + 0xb8);
              }
              if ((uVar11 < uVar7) || (*(uint *)(param_3 + 0xa4) < uVar11)) goto LAB_;
              lVar5 = *(longlong *)(param_3 + 0xa8);
              if (*(ushort *)(lVar5 + (ulonglong)uVar11) == 5) {
                *(ushort *)(param_3 + 0xa2) = *(ushort *)(param_3 + 0xa2) | 2;
                *(short *)(param_3 + 0xbc) = *(short *)(param_3 + 0xbc) + -1;
                uVar2 = *(ushort *)(param_3 + 0xcc) & 0xc7ff;
                *(short *)(param_3 + 0xca) = (short)uVar11;
                lVar5 = (ulonglong)(uVar11 & 0xffff) + lVar5;
                if ((*(ushort *)(lVar5 + 2) >> 0xe & 1) != 0) {
                  uVar2 = *(ushort *)(lVar5 + 2) & 0x3800 | uVar2;
                }
                *(ushort *)(param_3 + 0xcc) = uVar2;
                *(ushort *)(param_3 + 0xcc) = (uVar2 ^ *(ushort *)(lVar5 + 2)) & 0x7ff ^ uVar2;
                break;
              }
              if (*(ushort *)(lVar5 + (ulonglong)uVar11) < 0x400) break;
              *(ushort *)(param_3 + 0xa2) = *(ushort *)(param_3 + 0xa2) | 1;
              uVar2 = *(short *)(param_3 + 0xbc) - 1;
              *(ushort *)(param_3 + 0xbc) = uVar2;
              if ((uVar2 == 0) ||
                 (uVar10 = (ulonglong)uVar2, -1 < (short)puVar14[(ulonglong)(uVar2 - 1) + 1]))
              break;
            } while( true );
          }
          uVar10 = (ulonglong)*(uint *)(param_3 + 0xa4);
          pbVar17 = *(byte **)(param_3 + 0xa8);
        }
        iVar3 = 0;
        if ((*pbVar17 & 0x40) == 0) {
          *(undefined4 *)(param_3 + 0xc6) = 0;
        }
        else {
          *(int *)(param_3 + 0xc6) = *(int *)(param_3 + 0xa4);
          *(int *)(param_3 + 0xa4) = *(int *)(param_3 + 0xa4) + 0xe;
          puVar4 = (ulonglong *)func_0x(param_3 + 0xa2);
          uVar16 = (ushort)(*puVar4 >> 0x30);
          uVar2 = uVar16;
          if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
            uVar2 = uVar16 & 0xdfff;
            if ((uVar16 >> 0xe & 1) != 0) {
              uVar2 = uVar16 | 0x2000;
            }
          }
          if (uVar2 == 0xfffc) {
            iVar3 = (int)((*puVar4 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_3 + 0xa4) = *(int *)(param_3 + 0xa4) + iVar3;
          uVar10 = (ulonglong)*(uint *)(param_3 + 0xa4);
        }
        iVar3 = (int)uVar10;
        if ((*(ulonglong *)(param_3 + 0xbe) != 0) &&
           (*(ulonglong *)(param_3 + 0xbe) < uVar10 + *(longlong *)(param_3 + 0xa8))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar5 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar5 != 0 &&
               (lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0)) &&
              (*(char *)(lVar5 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0xd74df8,0xe94ac8,0x877,0);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 0xa8),0x12);
          iVar3 = *(int *)(param_3 + 0xa4);
        }
        if (0x3f3b < iVar3 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar5 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar5 != 0 &&
              ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
               (*(char *)(lVar5 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              func_0x(*(undefined8 *)(param_3 + 0xa8),5);
              goto LAB_;
            }
            (*_DAT_)(1,0xd74df8,0xe94ac8,0x87c,0);
          }
          func_0x(*(undefined8 *)(param_3 + 0xa8),5);
        }
      }
LAB_:
      iVar3 = func_0x(param_3 + 0xa2);
      uVar11 = uStackX_20;
      if (iVar3 == 0) {
        iVar3 = func_0x(param_3 + 0xa2);
        if (iVar3 == 0) {
          (*_DAT_)(1,0xf30478,0xf21568,0xd67,0);
        }
      }
      else {
        if (-1 < lStack_60) {
          uVar2 = *(ushort *)(param_3 + 0xcc);
          if (iVar20 < (int)(uVar2 & 0x7ff)) {
            uVar13 = (ulonglong)*(ushort *)(param_3 + 0xca);
            lVar12 = *(longlong *)(param_3 + 0xa8);
            uVar16 = 0;
            lVar5 = lVar12 + uVar13;
            if ((uVar2 & 0x3800) == 0) {
              uVar15 = *(ushort *)(lVar5 + 2);
LAB_:
              uVar16 = uVar15 >> 0xb & 7;
            }
            else {
              lVar9 = 0;
              if ((uVar2 >> 0xb & 7) != 0) {
                do {
                  if (lVar9 == 0) {
                    uVar11 = 0;
                  }
                  else {
                    uVar11 = *(ushort *)(lVar5 + 2 + lVar9 * 2) & 0x7ff;
                  }
                  if (((int)uVar11 <= iVar20) &&
                     (uVar15 = *(ushort *)(lVar5 + 4 + lVar9 * 2),
                     iVar20 <= (int)((uVar15 & 0x7ff) - 1))) goto LAB_;
                  lVar9 = lVar9 + 1;
                } while (lVar9 < (longlong)(ulonglong)(uVar2 >> 0xb & 7));
              }
            }
            uVar19 = uVar2 >> 0xb & 7;
            uVar10 = (ulonglong)(uVar19 * 2);
            uVar11 = (uint)*(ushort *)(uVar10 + (lStack_60 + 2) * 2 + lVar12 + uVar13) +
                     (uint)uVar16 * 0x10000;
            uVar7 = (uVar2 & 0x7ff) * 2;
            if (lStack_60 == 0) {
              uVar13 = (ulonglong)((uVar7 + uVar19) * 2 + 4) + lVar5;
            }
            else {
              uVar13 = (ulonglong)
                       (*(ushort *)(uVar10 + uVar7 + (lStack_60 + 1) * 2 + lVar12 + uVar13) & 0x7fff
                       ) + lVar5;
            }
            goto LAB_;
          }
        }
        (*_DAT_)(1,0xf30448,0xf30490,0x3c6,0);
        uVar13 = 0;
      }
LAB_:
      uVar10 = 0;
      lVar5 = func_0x
                        (**(undefined8 **)(*(longlong *)(*(longlong *)(param_2 + 0x80) + 8) + 0x160)
                         ,uVar11);
      if (lVar5 == 0) {
        uVar18 = 0xe56268;
        uVar8 = 0x16;
LAB_:
        uVar6 = (ulonglong)uVar11;
code_r0x001008ba:
        uStack_58 = *(undefined4 *)(param_3 + 0x154);
        uStack_54 = *(undefined4 *)(param_3 + 0x158);
        uStack_50 = *(undefined2 *)(param_3 + 0x15c);
        uStack_4e = *(undefined2 *)(param_3 + 0x15e);
        func_0x(&uStack_58,*(undefined4 *)(param_3 + 0xd4),param_3 + 0x60,uVar18,uVar8,uVar6
                        ,uVar10);
        func_0x(param_1,2,param_3 + 0x60);
        return 0;
      }
      if (-1 < *(char *)(lVar5 + 0x21)) {
        uVar18 = 0xe561c8;
        uVar8 = 0x17;
        goto LAB_;
      }
      if (lStack_60 != 0) {
        uVar6 = (ulonglong)uStackX_20;
        if (uVar11 <= uStackX_20) {
          uVar18 = 0xe561f8;
          uVar10 = (ulonglong)uVar11;
          uVar8 = 0x18;
          goto code_r0x001008ba;
        }
        if (uVar13 < uStack_68) {
          uVar18 = 0xe55f60;
          uVar8 = 0x19;
          uVar10 = uStack_68;
          uVar6 = uVar13;
          goto code_r0x001008ba;
        }
      }
      lStack_60 = lStack_60 + 1;
      iVar20 = iVar20 + 1;
      iVar3 = func_0x(param_3 + 0xa0);
      uStackX_20 = uVar11;
      uStack_68 = uVar13;
    } while (iVar20 < iVar3);
  }
  return 1;
}

