
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,undefined8 param_3)

{
  short *psVar1;
  char *pcVar2;
  char cVar3;
  undefined2 uVar4;
  code *pcVar5;
  uint *puVar6;
  undefined8 uVar7;
  uint6 uVar8;
  undefined *puVar9;
  bool bVar10;
  bool bVar11;
  undefined uVar12;
  char cVar13;
  char cVar14;
  ushort uVar15;
  int iVar16;
  uint uVar17;
  undefined4 uVar18;
  longlong lVar19;
  longlong *plVar20;
  longlong *plVar21;
  longlong lVar22;
  longlong lVar23;
  ulonglong *puVar24;
  undefined8 uVar25;
  longlong *plVar26;
  undefined8 uVar27;
  longlong lVar28;
  undefined8 *puVar29;
  ushort uVar30;
  ulonglong uVar31;
  byte *pbVar32;
  byte bVar33;
  uint uVar34;
  uint uVar35;
  int iVar36;
  longlong lVar37;
  int iVar38;
  uint uVar39;
  undefined8 unaff_RBX;
  ushort *puVar40;
  ulonglong uVar41;
  ulonglong uVar42;
  undefined *puVar43;
  ushort *puVar44;
  uint uVar45;
  ulonglong uVar46;
  short sVar47;
  undefined *puVar48;
  int iVar49;
  short *psVar50;
  longlong unaff_GS_OFFSET;
  bool bVar51;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar19 = func_0x();
  lVar19 = -lVar19;
  pcVar2 = &stack0x00000038 + lVar19;
  *(undefined8 *)(&stack0x00000228 + lVar19) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000051b0 + lVar19) = unaff_RBX;
  *(ulonglong *)(&stack0x00005148 + lVar19) = _DAT_ ^ (ulonglong)pcVar2;
  *(undefined8 *)(&stack0x000000c0 + lVar19) = param_3;
  *(undefined8 *)(&stack0x00000138 + lVar19) = param_2;
  *(longlong **)(&stack0x00000088 + lVar19) = param_1;
  lVar28 = *(longlong *)(param_1[5] + 8);
  *(longlong *)(&stack0x000000c8 + lVar19) = lVar28;
  lVar28 = *(longlong *)(lVar28 + 0x30);
  *(longlong *)(&stack0x00000168 + lVar19) = lVar28;
  uVar17 = *(uint *)(param_1 + 2);
  *(uint *)(param_1 + 2) = uVar17 & 0xfffffeff;
  if (((char)(uVar17 & 0xfffffeff) < '\0') || ((*(byte *)((longlong)param_1 + 0x34) & 1) == 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100091;
    plVar20 = (longlong *)func_0x();
  }
  else {
    plVar20 = param_1 + 9;
  }
  *(undefined4 *)(&stack0x00000084 + lVar19) = 0;
  if (*(short *)plVar20 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1000b4;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1000bb;
    func_0x((short *)((longlong)plVar20 + 2),&stack0x000000f8 + lVar19);
  }
  iVar16 = *(int *)(&stack0x000000f8 + lVar19);
  *(int *)(&stack0x000000e8 + lVar19) = iVar16;
  *(int *)(&stack0x00000154 + lVar19) = iVar16;
  sVar47 = *(short *)(&stack0x000000fc + lVar19);
  *(short *)(&stack0x000000d2 + lVar19) = sVar47;
  *(short *)(&stack0x00000158 + lVar19) = sVar47;
  *(int *)(&stack0x000000d4 + lVar19) = iVar16;
  *(short *)(&stack0x000000d8 + lVar19) = sVar47;
  if (*(short *)plVar20 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10010d;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100114;
    func_0x((short *)((longlong)plVar20 + 2),&stack0x00000122 + lVar19);
  }
  *(undefined4 *)(&stack0x000000b0 + lVar19) = *(undefined4 *)(&stack0x00000122 + lVar19);
  *(undefined2 *)(&stack0x000000b4 + lVar19) = *(undefined2 *)(&stack0x00000126 + lVar19);
  *(undefined2 *)(&stack0x000000b6 + lVar19) = *(undefined2 *)(&stack0x00000128 + lVar19);
  bVar33 = *(byte *)plVar20[1] >> 1;
  if (*(short *)plVar20 == 0) {
    bVar33 = *(byte *)plVar20[1] >> 6;
  }
  puVar43 = &stack0xffffffffffffffc8 + lVar19;
  if (((bVar33 & 1) != 0) &&
     ((_DAT_ != sVar47 ||
      (puVar43 = &stack0xffffffffffffffc8 + lVar19, _DAT_ != iVar16)))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100187;
    iVar16 = func_0x(lVar28 + 0x19c8,&stack0x000000d4 + lVar19,&stack0x000000b0 + lVar19);
    puVar43 = &stack0xffffffffffffffc8 + lVar19;
    if (iVar16 != 0) {
      *(undefined2 *)(&stack0x00000518 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x00000520 + lVar19) = 0;
      *(undefined4 *)(&stack0x0000051c + lVar19) = 0;
      *(undefined8 *)(&stack0x00000536 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000540 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000528 + lVar19) = 0;
      *(undefined4 *)(&stack0x0000054c + lVar19) = 0xffffffff;
      *(undefined2 *)(&stack0x000005d8 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x000005e0 + lVar19) = 0;
      *(undefined4 *)(&stack0x000005dc + lVar19) = 0;
      *(undefined8 *)(&stack0x000005f6 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000600 + lVar19) = 0;
      *(undefined8 *)(&stack0x000005e8 + lVar19) = 0;
      *(undefined4 *)(&stack0x0000060c + lVar19) = 0xffffffff;
      *(undefined2 *)(&stack0x00000688 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x00000690 + lVar19) = 0;
      *(undefined4 *)(&stack0x0000068c + lVar19) = 0;
      *(undefined8 *)(&stack0x000006a6 + lVar19) = 0;
      *(undefined8 *)(&stack0x000006b0 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000698 + lVar19) = 0;
      *(undefined8 *)(&stack0x000006c0 + lVar19) = 0;
      *(undefined4 *)(&stack0x000006c8 + lVar19) = 0;
      *(undefined2 *)(&stack0x00000040 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x00000048 + lVar19) = 0;
      *(undefined4 *)(&stack0x00000044 + lVar19) = 0;
      *(undefined8 *)(&stack0x0000005e + lVar19) = 0;
      *(undefined8 *)(&stack0x00000068 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000050 + lVar19) = 0;
      lVar37 = *(longlong *)param_1[5];
      *(longlong *)(&stack0x00000090 + lVar19) = lVar37;
      *(undefined4 *)(&stack0x00000078 + lVar19) = 0;
      (&stack0x0000007c)[lVar19] = 0;
      (&stack0x000000a4)[lVar19] = 0;
      *(undefined8 *)(&stack0x00000160 + lVar19) = 0;
      *(undefined8 *)(&stack0x000005c8 + lVar19) = 0;
      *(undefined4 *)(&stack0x000005d0 + lVar19) = 0;
      *(undefined2 *)(&stack0x000005d4 + lVar19) = 0;
      *pcVar2 = '\0';
      *(undefined2 *)(&stack0x000006f0 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x000006f8 + lVar19) = 0;
      *(undefined4 *)(&stack0x000006f4 + lVar19) = 0;
      *(undefined8 *)(&stack0x0000070e + lVar19) = 0;
      *(undefined8 *)(&stack0x00000718 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000700 + lVar19) = 0;
      *(undefined4 *)(&stack0x00000724 + lVar19) = 0xffffffff;
      (&stack0x0000007e)[lVar19] = 0;
      if (*(char *)(lVar28 + 0x2050) != '\0') {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1002c4;
        func_0x(0x298,10,2);
        uVar27 = *(undefined8 *)(lVar28 + 0x6b0);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1002d0;
        func_0x(uVar27);
      }
      *(undefined8 *)(&stack0x000000e0 + lVar19) = 0;
      (&stack0x0000007f)[lVar19] = 1;
      plVar21 = *(longlong **)(&stack0x000000c0 + lVar19);
      if (plVar21 == (longlong *)0x0) {
        (&stack0x0000007f)[lVar19] = 0;
        plVar21 = *(longlong **)(&stack0x000000e0 + lVar19);
        if (plVar21 == (longlong *)0x0) {
          pcVar5 = *(code **)(**_DAT_ + 8);
          *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100317;
          plVar21 = (longlong *)(*pcVar5)();
          plVar26 = *(longlong **)(&stack0x000000e0 + lVar19);
          if ((plVar26 != plVar21) && (plVar26 != (longlong *)0x0)) {
            pcVar5 = *(code **)*plVar26;
            *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100333;
            (*pcVar5)(plVar26,1);
          }
          *(longlong **)(&stack0x000000e0 + lVar19) = plVar21;
        }
        lVar22 = *plVar21;
        (&stack0xffffffffffffffe8)[lVar19] = 0;
        pcVar5 = *(code **)(lVar22 + 0x18);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100358;
        (*pcVar5)(plVar21,0x18551a8,0x36);
        pcVar5 = *(code **)(**(longlong **)(&stack0x000000e0 + lVar19) + 0x58);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100368;
        plVar21 = (longlong *)(*pcVar5)(*(longlong **)(&stack0x000000e0 + lVar19),lVar28);
        *(longlong **)(&stack0x000000c0 + lVar19) = plVar21;
        pcVar5 = *(code **)(*plVar21 + 0x348);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100381;
        (*pcVar5)(plVar21,0);
      }
      pcVar5 = *(code **)(*plVar21 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10038a;
      uVar12 = (*pcVar5)(plVar21);
      (&stack0x00000039)[lVar19] = uVar12;
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10039c;
      func_0x(&stack0x000005d8 + lVar19,plVar20);
      if (((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
           (*(longlong **)(param_1[3] + 0x30) != (longlong *)0x0)) &&
          (lVar22 = **(longlong **)(param_1[3] + 0x30), lVar22 != 0)) && (lVar22 != param_1[4])) {
        param_1[4] = lVar22;
      }
      if ((*(char *)(param_1[4] + 2) < '\0') &&
         (*(char *)((*(ulonglong *)(&stack0x000005e0 + lVar19) & 0xffffffffffffe000) + 2) < '\0')) {
        puVar48 = *(undefined **)(&stack0x000006c0 + lVar19);
        if (puVar48 != (undefined *)0x0) goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100404;
        lVar22 = func_0x();
        puVar48 = &stack0x00000038 + -lVar22 + lVar19;
        *(undefined **)(&stack0x000006c0 + lVar19) = puVar48;
        uVar18 = 0x1f9e;
        *(undefined4 *)(&stack0x000006c8 + lVar19) = 0x1f9e;
        puVar43 = &stack0xffffffffffffffc8 + -lVar22 + lVar19;
      }
      else {
        puVar48 = *(undefined **)(&stack0x000006c0 + lVar19);
LAB_:
        uVar18 = *(undefined4 *)(&stack0x000006c8 + lVar19);
        puVar43 = &stack0xffffffffffffffc8 + lVar19;
      }
      pbVar32 = *(byte **)(&stack0x000005e0 + lVar19);
      if (*(char *)(((ulonglong)pbVar32 & 0xffffffffffffe000) + 2) < '\0') {
        *(short *)(&stack0x00000688 + lVar19) = *(short *)(&stack0x000005d8 + lVar19);
        if (*(short *)(&stack0x000005d8 + lVar19) == 0) {
          uVar17 = *(uint *)(&stack0x000005dc + lVar19);
          if (uVar17 == 0) {
            *(undefined2 *)(&stack0x000005da + lVar19) = 0;
            uVar17 = *(uint *)(&stack0x000005e8 + lVar19);
            uVar31 = (ulonglong)uVar17;
            *(uint *)(&stack0x000005ec + lVar19) = uVar17;
            if ((**(byte **)(&stack0x000005e0 + lVar19) & 0x10) != 0) {
              uVar17 = uVar17 + 2 +
                       (*(ushort *)(*(byte **)(&stack0x000005e0 + lVar19) + uVar31) + 7 >> 3);
              uVar31 = (ulonglong)uVar17;
              *(uint *)(&stack0x000005ec + lVar19) = uVar17;
            }
            if ((**(byte **)(&stack0x000005e0 + lVar19) & 0x20) == 0) {
              *(int *)(&stack0x000005dc + lVar19) = (int)uVar31;
              *(undefined2 *)(&stack0x000005f4 + lVar19) = 0;
              *(int *)(&stack0x000005f0 + lVar19) = (int)uVar31;
              uVar46 = uVar31;
            }
            else {
              psVar50 = (short *)(*(byte **)(&stack0x000005e0 + lVar19) + uVar31);
              sVar47 = *psVar50;
              *(short *)(&stack0x000005f4 + lVar19) = sVar47;
              if (sVar47 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar22 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar22 != 0)) &&
                   ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                    (*(char *)(lVar22 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x100568;
                    (*_DAT_)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10058e;
                    (*_DAT_)(1,0x184bf58,0x196bc28);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x000005e0 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x10059f;
                func_0x(uVar27,3);
              }
              uVar17 = *(int *)(&stack0x000005ec + lVar19) +
                       (*(ushort *)(&stack0x000005f4 + lVar19) + 1) * 2;
              *(uint *)(&stack0x000005f0 + lVar19) = uVar17;
              if (0x1f9e < uVar17) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar22 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar22 != 0 &&
                    ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                     (*(char *)(lVar22 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x100645;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10066b;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x000005e0 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x10067c;
                func_0x(uVar27,4);
                uVar17 = *(uint *)(&stack0x000005f0 + lVar19);
              }
              uVar46 = (ulonglong)uVar17;
              uVar45 = (ushort)psVar50[*(ushort *)(&stack0x000005f4 + lVar19)] & 0x7fff;
              uVar31 = (ulonglong)uVar45;
              *(uint *)(&stack0x000005dc + lVar19) = uVar45;
              if (uVar45 < uVar17) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar22 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar22 != 0)) &&
                   ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                    (*(char *)(lVar22 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10071d;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x100746;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x000005e0 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x100757;
                func_0x(uVar27,4);
                uVar46 = (ulonglong)*(uint *)(&stack0x000005f0 + lVar19);
                uVar31 = (ulonglong)*(uint *)(&stack0x000005dc + lVar19);
              }
              do {
                uVar15 = *(ushort *)(&stack0x000005f4 + lVar19);
                if (-1 < psVar50[(ulonglong)(uVar15 - 1) + 1]) break;
                uVar45 = (uint)uVar46;
                if (uVar15 != 1) {
                  uVar45 = *(ushort *)
                            ((ulonglong)*(uint *)(&stack0x000005ec + lVar19) +
                             *(longlong *)(&stack0x000005e0 + lVar19) + -2 + (ulonglong)uVar15 * 2)
                           & 0x7fff;
                }
                if ((uVar45 < (uint)uVar46) ||
                   ((*(ushort *)
                      ((ulonglong)*(uint *)(&stack0x000005ec + lVar19) +
                       *(longlong *)(&stack0x000005e0 + lVar19) + (ulonglong)uVar15 * 2) & 0x7fff) <
                    uVar45)) {
                  uVar27 = *(undefined8 *)(&stack0x000005e0 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x1007c7;
                  func_0x(uVar27,7);
                  uVar46 = (ulonglong)*(uint *)(&stack0x000005f0 + lVar19);
                  uVar31 = (ulonglong)*(uint *)(&stack0x000005dc + lVar19);
                }
                uVar17 = (uint)uVar31;
                uVar34 = (uint)uVar46;
                if ((uVar45 < uVar34) || (uVar17 < uVar45)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar45 + *(longlong *)(&stack0x000005e0 + lVar19)) == 5)
                {
                  *(ushort *)(&stack0x000005da + lVar19) =
                       *(ushort *)(&stack0x000005da + lVar19) | 2;
                  *(short *)(&stack0x000005f4 + lVar19) = *(short *)(&stack0x000005f4 + lVar19) + -1
                  ;
                  *(short *)(&stack0x00000602 + lVar19) = (short)uVar45;
                  lVar22 = (ulonglong)(uVar45 & 0xffff) + *(longlong *)(&stack0x000005e0 + lVar19);
                  uVar15 = *(ushort *)(lVar22 + 2);
                  uVar30 = *(ushort *)(&stack0x00000604 + lVar19);
                  if ((uVar15 & 0x4000) == 0) {
                    uVar30 = uVar30 & 0xc7ff;
                  }
                  else {
                    uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                  }
                  *(ushort *)(&stack0x00000604 + lVar19) = uVar30;
                  *(ushort *)(&stack0x00000604 + lVar19) =
                       (uVar30 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar30;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar45 + *(longlong *)(&stack0x000005e0 + lVar19)) <
                    0x400) break;
                *(ushort *)(&stack0x000005da + lVar19) = *(ushort *)(&stack0x000005da + lVar19) | 1;
                psVar1 = (short *)(&stack0x000005f4 + lVar19);
                *psVar1 = *psVar1 + -1;
              } while (*psVar1 != 0);
            }
            uVar34 = (uint)uVar46;
            if ((**(byte **)(&stack0x000005e0 + lVar19) & 0x40) == 0) {
              *(undefined4 *)(&stack0x000005fe + lVar19) = 0;
            }
            else {
              *(int *)(&stack0x000005fe + lVar19) = (int)uVar31;
              *(int *)(&stack0x000005dc + lVar19) = (int)uVar31 + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x1008fc;
              puVar24 = (ulonglong *)func_0x(&stack0x000005da + lVar19);
              uVar31 = *puVar24;
              iVar16 = 0;
              uVar30 = (ushort)(uVar31 >> 0x30);
              uVar15 = uVar30;
              if ((((uint)(int)(short)uVar30 >> 1 ^ (int)(short)uVar30) & 0x2000) != 0) {
                uVar15 = uVar30 & 0xdfff;
                if ((uVar31 & 0x4000000000000000) != 0) {
                  uVar15 = uVar30 | 0x2000;
                }
              }
              if (uVar15 == 0xfffc) {
                iVar16 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
              }
              uVar31 = (ulonglong)(uint)(*(int *)(&stack0x000005dc + lVar19) + iVar16);
              *(int *)(&stack0x000005dc + lVar19) = *(int *)(&stack0x000005dc + lVar19) + iVar16;
              uVar34 = *(uint *)(&stack0x000005f0 + lVar19);
            }
            uVar17 = (uint)uVar31;
            if ((*(ulonglong *)(&stack0x000005f6 + lVar19) != 0) &&
               (*(ulonglong *)(&stack0x000005f6 + lVar19) <
                uVar31 + *(longlong *)(&stack0x000005e0 + lVar19))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar22 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar22 != 0 &&
                   (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
                  (*(char *)(lVar22 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x100a07;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x100a2d;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                }
              }
              uVar27 = *(undefined8 *)(&stack0x000005e0 + lVar19);
              *(undefined8 *)(puVar43 + -8) = 0x100a3e;
              func_0x(uVar27,0x12);
              uVar34 = *(uint *)(&stack0x000005f0 + lVar19);
              uVar17 = *(uint *)(&stack0x000005dc + lVar19);
            }
            if (0x3f3b < uVar17 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar22 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar22 != 0 &&
                  ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                   (*(char *)(lVar22 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x100ad3;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x100afc;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                }
              }
              uVar27 = *(undefined8 *)(&stack0x000005e0 + lVar19);
              *(undefined8 *)(puVar43 + -8) = 0x100b0d;
              func_0x(uVar27,5);
              uVar17 = *(uint *)(&stack0x000005dc + lVar19);
              goto LAB_;
            }
          }
          else {
LAB_:
            uVar34 = *(uint *)(&stack0x000005f0 + lVar19);
          }
LAB_:
          uVar45 = uVar17;
          if ((uVar17 < 9) &&
             (((**(byte **)(&stack0x000005e0 + lVar19) & 0xe) == 0 ||
              ((**(byte **)(&stack0x000005e0 + lVar19) & 0xe) == 0xc)))) {
            uVar45 = 9;
          }
          *(undefined4 *)(&stack0x00000698 + lVar19) = *(undefined4 *)(&stack0x000005e8 + lVar19);
          *(undefined2 *)(&stack0x0000068a + lVar19) = *(undefined2 *)(&stack0x000005da + lVar19);
          *(uint *)(&stack0x0000068c + lVar19) = uVar17;
          *(undefined2 *)(&stack0x000006a4 + lVar19) = *(undefined2 *)(&stack0x000005f4 + lVar19);
          *(undefined4 *)(&stack0x0000069c + lVar19) = *(undefined4 *)(&stack0x000005ec + lVar19);
          *(uint *)(&stack0x000006a0 + lVar19) = uVar34;
          *(undefined4 *)(&stack0x000006ae + lVar19) = *(undefined4 *)(&stack0x000005fe + lVar19);
          uVar27 = *(undefined8 *)(&stack0x000005e0 + lVar19);
          *(undefined8 *)(puVar43 + -8) = 0x100b9c;
          func_0x(puVar48,uVar18,uVar27,uVar45);
          *(undefined **)(&stack0x00000690 + lVar19) = puVar48;
          *(undefined8 *)(puVar43 + -8) = 0x100baf;
          iVar16 = func_0x(&stack0x0000068a + lVar19);
          if (iVar16 != 0) {
            puVar40 = (ushort *)
                      ((ulonglong)*(uint *)(&stack0x0000069c + lVar19) +
                      *(longlong *)(&stack0x00000690 + lVar19));
            uVar17 = *puVar40 - 1;
            if (((&stack0x0000068a)[lVar19] & 1) == 0) {
              uVar17 = (uint)*puVar40;
            }
            uVar45 = *(uint *)(&stack0x000006a0 + lVar19);
            if (uVar17 != 1) {
              uVar45 = puVar40[(longlong)(int)uVar17 + -1] & 0x7fff;
            }
            if ((uVar45 < *(uint *)(&stack0x000006a0 + lVar19)) ||
               ((puVar40[(int)uVar17] & 0x7fff) < uVar45)) {
              uVar27 = *(undefined8 *)(&stack0x00000690 + lVar19);
              *(undefined8 *)(puVar43 + -8) = 0x100c17;
              func_0x(uVar27,7);
            }
            *(short *)(&stack0x000006b2 + lVar19) = (short)uVar45;
            lVar22 = (ulonglong)(uVar45 & 0xffff) + *(longlong *)(&stack0x00000690 + lVar19);
            uVar15 = *(ushort *)(lVar22 + 2);
            uVar30 = *(ushort *)(&stack0x000006b4 + lVar19);
            if ((uVar15 >> 0xe & 1) == 0) {
              uVar30 = uVar30 & 0xc7ff;
            }
            else {
              uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
            }
            *(ushort *)(&stack0x000006b4 + lVar19) = uVar30;
            *(ushort *)(&stack0x000006b4 + lVar19) =
                 (uVar30 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar30;
          }
        }
        else if ((*(longlong **)(&stack0x000005e8 + lVar19) == (longlong *)0x0) ||
                (**(longlong **)(&stack0x000005e8 + lVar19) == 0)) {
          *(undefined8 *)(puVar43 + -8) = 0x100cc2;
          func_0x(&stack0x0000068a + lVar19,puVar48,uVar18,&stack0x000005da + lVar19);
          uVar27 = *(undefined8 *)(&stack0x000005e8 + lVar19);
          if (*(short *)(&stack0x000005d8 + lVar19) == 0) {
            uVar27 = 0;
          }
          *(undefined8 *)(&stack0x00000698 + lVar19) = uVar27;
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x100ca7;
          func_0x(&stack0x00000688 + lVar19,puVar48,uVar18,&stack0x000005d8 + lVar19);
        }
        puVar48 = &stack0x00000688;
        puVar9 = &stack0x0000068a;
        pbVar32 = *(byte **)(&stack0x00000690 + lVar19);
      }
      else {
        puVar48 = &stack0x000005d8;
        puVar9 = &stack0x000005da;
      }
      psVar50 = (short *)(puVar48 + lVar19);
      puVar40 = (ushort *)(puVar9 + lVar19);
      sVar47 = *psVar50;
      if (sVar47 == 0) {
        bVar33 = *pbVar32 & 0xe;
        *(undefined4 *)(&stack0x000000b8 + lVar19) = 0;
        if (bVar33 == 2) {
          *(uint *)(&stack0x000000b8 + lVar19) = (uint)((pbVar32[1] & 1) != 0);
        }
        else if (((bVar33 - 10 & 0xf9) == 0) && (bVar33 != 0x10)) {
          uVar17 = 1;
          goto LAB_;
        }
      }
      else {
        uVar17 = (uint)(((*pbVar32 & 0x1c) - 4 & 0xffffffe7) == 0);
LAB_:
        *(uint *)(&stack0x000000b8 + lVar19) = uVar17;
      }
      *(uint *)(&stack0x00000180 + lVar19) =
           ((uint)(int)*(short *)(&stack0x000000b6 + lVar19) >> 1 ^
           (int)*(short *)(&stack0x000000b6 + lVar19)) >> 0xd & 1;
      uVar17 = *(uint *)(puVar40 + 1);
      *(uint *)(&stack0x000000a8 + lVar19) = uVar17;
      if (sVar47 == 0) {
        if (uVar17 == 0) {
          *puVar40 = 0;
          uVar17 = *(uint *)(puVar40 + 7);
          uVar31 = (ulonglong)uVar17;
          *(uint *)(puVar40 + 9) = uVar17;
          pbVar32 = *(byte **)(puVar40 + 3);
          bVar33 = *pbVar32;
          if ((bVar33 & 0x10) != 0) {
            uVar17 = uVar17 + (*(ushort *)(pbVar32 + uVar31) + 7 >> 3) + 2;
            uVar31 = (ulonglong)uVar17;
            *(uint *)(puVar40 + 9) = uVar17;
            bVar33 = *pbVar32;
          }
          if ((bVar33 & 0x20) == 0) {
            *(int *)(puVar40 + 1) = (int)uVar31;
            puVar40[0xd] = 0;
            *(uint *)(puVar40 + 0xb) = uVar17;
          }
          else {
            puVar44 = (ushort *)(pbVar32 + uVar31);
            uVar15 = *puVar44;
            puVar40[0xd] = uVar15;
            if (uVar15 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar22 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar22 != 0)) &&
                 ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                  (*(char *)(lVar22 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x100e50;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x100e76;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                }
              }
              uVar27 = *(undefined8 *)(puVar40 + 3);
              *(undefined8 *)(puVar43 + -8) = 0x100e84;
              func_0x(uVar27,3);
              uVar15 = puVar40[0xd];
              uVar17 = *(uint *)(puVar40 + 9);
            }
            uVar17 = uVar17 + (uVar15 + 1) * 2;
            *(uint *)(puVar40 + 0xb) = uVar17;
            if (0x1f9e < uVar17) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar22 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar22 != 0 &&
                  ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                   (*(char *)(lVar22 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x100f1c;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x100f42;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                }
              }
              uVar27 = *(undefined8 *)(puVar40 + 3);
              *(undefined8 *)(puVar43 + -8) = 0x100f50;
              func_0x(uVar27,4);
              uVar17 = *(uint *)(puVar40 + 0xb);
            }
            uVar31 = (ulonglong)puVar40[0xd];
            uVar15 = puVar44[uVar31];
            *(uint *)(puVar40 + 1) = uVar15 & 0x7fff;
            if ((uVar15 & 0x7fff) < uVar17) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar22 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar22 != 0)) &&
                 ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                  (*(char *)(lVar22 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x100fe5;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10100b;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                }
              }
              uVar27 = *(undefined8 *)(puVar40 + 3);
              *(undefined8 *)(puVar43 + -8) = 0x101019;
              func_0x(uVar27,4);
              uVar31 = (ulonglong)puVar40[0xd];
            }
            while ((short)puVar44[(ulonglong)((int)uVar31 - 1) + 1] < 0) {
              lVar22 = *(longlong *)(puVar40 + 3);
              lVar23 = (ulonglong)*(uint *)(puVar40 + 9) + lVar22;
              if ((int)uVar31 == 1) {
                uVar17 = *(uint *)(puVar40 + 0xb);
                uVar46 = (ulonglong)uVar17;
                uVar15 = *(ushort *)(lVar23 + uVar31 * 2);
LAB_:
                if ((uVar15 & 0x7fff) < (uint)uVar46) goto LAB_;
              }
              else {
                uVar45 = *(ushort *)(lVar23 + -2 + uVar31 * 2) & 0x7fff;
                uVar46 = (ulonglong)uVar45;
                uVar17 = *(uint *)(puVar40 + 0xb);
                uVar15 = *(ushort *)(lVar23 + uVar31 * 2);
                if (uVar17 <= uVar45) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x10107d;
                func_0x(lVar22,7);
                uVar17 = *(uint *)(puVar40 + 0xb);
              }
              if (((uint)uVar46 < uVar17) || (*(uint *)(puVar40 + 1) < (uint)uVar46))
              goto LAB_;
              if (*(ushort *)(uVar46 + *(longlong *)(puVar40 + 3)) == 5) {
                *puVar40 = *puVar40 | 2;
                puVar40[0xd] = puVar40[0xd] - 1;
                puVar40[0x14] = (ushort)uVar46;
                lVar22 = (uVar46 & 0xffff) + *(longlong *)(puVar40 + 3);
                uVar15 = puVar40[0x15] & 0xc7ff;
                if ((*(ushort *)(lVar22 + 2) >> 0xe & 1) != 0) {
                  uVar15 = *(ushort *)(lVar22 + 2) & 0x3800 | puVar40[0x15] & 0xc7ff;
                }
                puVar40[0x15] = uVar15;
                puVar40[0x15] = (uVar15 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar15;
                break;
              }
              if (*(ushort *)(uVar46 + *(longlong *)(puVar40 + 3)) < 0x400) break;
              *puVar40 = *puVar40 | 1;
              uVar15 = puVar40[0xd] - 1;
              puVar40[0xd] = uVar15;
              if (uVar15 == 0) break;
              uVar31 = (ulonglong)uVar15;
            }
            pbVar32 = *(byte **)(puVar40 + 3);
          }
          iVar16 = 0;
          if ((*pbVar32 & 0x40) == 0) {
            *(undefined4 *)(puVar40 + 0x12) = 0;
          }
          else {
            *(int *)(puVar40 + 0x12) = *(int *)(puVar40 + 1);
            *(int *)(puVar40 + 1) = *(int *)(puVar40 + 1) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x10114f;
            puVar24 = (ulonglong *)func_0x(puVar40);
            uVar30 = (ushort)(*puVar24 >> 0x30);
            uVar15 = uVar30;
            if ((((uint)(int)(short)uVar30 >> 1 ^ (int)(short)uVar30) & 0x2000) != 0) {
              uVar15 = uVar30 & 0xdfff;
              if ((uVar30 >> 0xe & 1) != 0) {
                uVar15 = uVar30 | 0x2000;
              }
            }
            if (uVar15 == 0xfffc) {
              iVar16 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(puVar40 + 1) = *(int *)(puVar40 + 1) + iVar16;
          }
          uVar17 = *(uint *)(puVar40 + 1);
          if ((*(ulonglong *)(puVar40 + 0xe) != 0) &&
             (*(ulonglong *)(puVar40 + 0xe) < (ulonglong)uVar17 + *(longlong *)(puVar40 + 3))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar22 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar22 != 0 &&
                 (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
                (*(char *)(lVar22 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x101245;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10126b;
                (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
              }
            }
            uVar27 = *(undefined8 *)(puVar40 + 3);
            *(undefined8 *)(puVar43 + -8) = 0x101279;
            func_0x(uVar27,0x12);
            uVar17 = *(uint *)(puVar40 + 1);
          }
          if (0x3f3b < uVar17 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar22 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar22 != 0 &&
                ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                 (*(char *)(lVar22 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x101304;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10132a;
                (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
              }
            }
            uVar27 = *(undefined8 *)(puVar40 + 3);
            *(undefined8 *)(puVar43 + -8) = 0x101338;
            func_0x(uVar27,5);
          }
        }
LAB_:
        uVar17 = *(uint *)(puVar40 + 1);
        *(uint *)(&stack0x000000a8 + lVar19) = uVar17;
        if (uVar17 < 9) {
          bVar33 = **(byte **)(puVar40 + 3) & 0xe;
joined_r0x00101375:
          if ((bVar33 == 0) || (bVar33 == 0xc)) {
            *(undefined4 *)(&stack0x000000a8 + lVar19) = 9;
          }
        }
      }
      else {
        if (uVar17 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x101360;
          func_0x(puVar40);
          uVar17 = *(uint *)(puVar40 + 1);
          *(uint *)(&stack0x000000a8 + lVar19) = uVar17;
        }
        if (uVar17 < 9) {
          bVar33 = **(byte **)(puVar40 + 3) & 0x1c;
          goto joined_r0x00101375;
        }
      }
      uVar27 = 0;
      *(undefined8 *)(&stack0x000006e0 + lVar19) = 0;
      *(undefined2 *)(&stack0x000006e8 + lVar19) = 0;
      *(undefined8 *)(puVar43 + 0x28) = 0;
      *(undefined **)(puVar43 + 0x20) = &stack0x000001c0 + lVar19;
      *(undefined8 *)(puVar43 + -8) = 0x1013b4;
      uVar18 = func_0x(&stack0x000000b0 + lVar19,lVar28);
      *(undefined4 *)(&stack0x00000148 + lVar19) = uVar18;
      *(undefined **)(puVar43 + 0x28) = &stack0x00000040 + lVar19;
      *(undefined8 *)(puVar43 + -8) = 0x1013d8;
      func_0x(lVar37,psVar50,0,&stack0x000007a8 + lVar19);
      if (((&stack0x00000039)[lVar19] == '\0') &&
         (bVar33 = *(byte *)(*(longlong *)(lVar37 + 8) + 0x108) >> 6 & 1,
         (&stack0x0000007c)[lVar19] = bVar33, bVar33 != 0)) {
        *(undefined8 *)(puVar43 + -8) = 0x101403;
        uVar12 = func_0x(lVar37,psVar50);
      }
      else {
        uVar12 = (&stack0x00000080)[lVar19];
      }
      (&stack0x0000007d)[lVar19] = uVar12;
      lVar28 = *(longlong *)(&stack0x00000088 + lVar19);
      if (((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
           (plVar20 = *(longlong **)(*(longlong *)(lVar28 + 0x18) + 0x30),
           plVar20 != (longlong *)0x0)) && (lVar37 = *plVar20, lVar37 != 0)) &&
         (lVar37 != *(longlong *)(lVar28 + 0x20))) {
        *(longlong *)(lVar28 + 0x20) = lVar37;
      }
      lVar37 = *(longlong *)(lVar28 + 0x20);
      if (*(short *)(lVar37 + 0x24) == 0) {
LAB_:
        uVar25 = *(undefined8 *)(lVar37 + 0x28);
        *(undefined8 *)(&stack0x00000170 + lVar19) = uVar25;
        uVar4 = *(undefined2 *)(lVar37 + 0x30);
        *(undefined2 *)(&stack0x000000a0 + lVar19) = uVar4;
        *(undefined2 *)(&stack0x00000178 + lVar19) = uVar4;
      }
      else {
        cVar13 = *(char *)(lVar37 + 1);
        if (cVar13 == '\v') {
          if (*(int *)(lVar37 + 0x18) != 99) {
LAB_:
            if (cVar13 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar13 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar37 + 0x18) != 99) goto LAB_;
        }
        *(undefined4 *)(&stack0x0000014c + lVar19) = *(undefined4 *)(lVar37 + 0x20);
        *(undefined2 *)(&stack0x00000150 + lVar19) = *(undefined2 *)(lVar37 + 0x24);
        *(undefined8 *)(puVar43 + -8) = 0x101490;
        cVar13 = func_0x(&stack0x0000014c + lVar19);
        if (cVar13 == '\0') goto LAB_;
        *(undefined8 *)(puVar43 + -8) = 0x1014a3;
        func_0x(lVar37,&stack0x00000170 + lVar19);
        *(undefined2 *)(&stack0x000000a0 + lVar19) = *(undefined2 *)(&stack0x00000178 + lVar19);
        uVar25 = *(undefined8 *)(&stack0x00000170 + lVar19);
      }
      *(undefined8 *)(&stack0x000001b0 + lVar19) = uVar25;
      if ((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
          (plVar20 = *(longlong **)(*(longlong *)(lVar28 + 0x18) + 0x30), plVar20 != (longlong *)0x0
          )) && ((lVar37 = *plVar20, lVar37 != 0 && (lVar37 != *(longlong *)(lVar28 + 0x20))))) {
        *(longlong *)(lVar28 + 0x20) = lVar37;
      }
      uVar4 = *(undefined2 *)(*(longlong *)(lVar28 + 0x20) + 4);
      if ((*(uint *)(&stack0x000000b0 + lVar19) & 0x80000000) == 0) {
LAB_:
        psVar50 = (short *)(lVar28 + 0x48);
        puVar48 = (undefined *)(lVar28 + 0x4a);
      }
      else {
        uVar15 = *(ushort *)(&stack0x000000b6 + lVar19);
        uVar30 = uVar15;
        if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
          uVar30 = uVar15 & 0xdfff;
          if ((uVar15 >> 0xe & 1) != 0) {
            uVar30 = uVar15 | 0x2000;
          }
        }
        if (uVar30 == 0xfffc) {
          *(undefined8 *)(puVar43 + 0x20) = 0;
          *(undefined8 *)(puVar43 + -8) = 0x101589;
          (*_DAT_)(1,0x19f6760,0x19cfea0,0x4ec);
        }
        *(undefined8 *)(puVar43 + -8) = 0x101592;
        cVar13 = func_0x(&stack0x000000b0 + lVar19);
        if (cVar13 == '\0') {
          *(undefined8 *)(puVar43 + -8) = 0x10159f;
          cVar13 = func_0x(&stack0x000000b0 + lVar19);
          if ((cVar13 == '\0') &&
             (((uint)(int)*(short *)(&stack0x000000b6 + lVar19) >> 0xc & 1) != 0))
          goto LAB_;
        }
        sVar47 = *psVar50;
        *(short *)(&stack0x000006f0 + lVar19) = sVar47;
        if (sVar47 == 0) {
          if (*(int *)(psVar50 + 2) == 0) {
            psVar50[1] = 0;
            uVar17 = *(uint *)(psVar50 + 8);
            uVar31 = (ulonglong)uVar17;
            *(uint *)(psVar50 + 10) = uVar17;
            pbVar32 = *(byte **)(psVar50 + 4);
            bVar33 = *pbVar32;
            if ((bVar33 & 0x10) != 0) {
              uVar17 = uVar17 + (*(ushort *)(pbVar32 + uVar31) + 7 >> 3) + 2;
              uVar31 = (ulonglong)uVar17;
              *(uint *)(psVar50 + 10) = uVar17;
              bVar33 = *pbVar32;
            }
            if ((bVar33 & 0x20) == 0) {
              *(int *)(psVar50 + 2) = (int)uVar31;
              psVar50[0xe] = 0;
              *(uint *)(psVar50 + 0xc) = uVar17;
            }
            else {
              puVar40 = (ushort *)(pbVar32 + uVar31);
              uVar15 = *puVar40;
              psVar50[0xe] = uVar15;
              if (uVar15 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1016a0;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1016c6;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                  }
                }
                uVar27 = *(undefined8 *)(psVar50 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x1016d4;
                func_0x(uVar27,3);
                uVar15 = psVar50[0xe];
                uVar17 = *(uint *)(psVar50 + 10);
              }
              uVar17 = uVar17 + (uVar15 + 1) * 2;
              *(uint *)(psVar50 + 0xc) = uVar17;
              if (0x1f9e < uVar17) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10176f;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x101795;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                  }
                }
                uVar27 = *(undefined8 *)(psVar50 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x1017a3;
                func_0x(uVar27,4);
                uVar17 = *(uint *)(psVar50 + 0xc);
              }
              uVar15 = puVar40[(ushort)psVar50[0xe]];
              *(uint *)(psVar50 + 2) = uVar15 & 0x7fff;
              if ((uVar15 & 0x7fff) < uVar17) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10183c;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x101862;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                  }
                }
                uVar27 = *(undefined8 *)(psVar50 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x101870;
                func_0x(uVar27,4);
              }
              do {
                uVar15 = psVar50[0xe];
                uVar31 = (ulonglong)uVar15;
                if (-1 < (short)puVar40[(ulonglong)(uVar15 - 1) + 1]) break;
                lVar37 = *(longlong *)(psVar50 + 4);
                lVar22 = (ulonglong)*(uint *)(psVar50 + 10) + lVar37;
                if (uVar15 == 1) {
                  uVar46 = (ulonglong)*(uint *)(psVar50 + 0xc);
                  uVar15 = *(ushort *)(lVar22 + uVar31 * 2);
LAB_:
                  if ((uVar15 & 0x7fff) < (uint)uVar46) goto LAB_;
                }
                else {
                  uVar17 = *(ushort *)(lVar22 + -2 + uVar31 * 2) & 0x7fff;
                  uVar46 = (ulonglong)uVar17;
                  uVar15 = *(ushort *)(lVar22 + uVar31 * 2);
                  if (*(uint *)(psVar50 + 0xc) <= uVar17) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x1018ce;
                  func_0x(lVar37,7);
                  lVar37 = *(longlong *)(psVar50 + 4);
                  if ((uint)uVar46 < *(uint *)(psVar50 + 0xc)) goto LAB_;
                }
                if (*(uint *)(psVar50 + 2) < (uint)uVar46) goto LAB_;
                if (*(ushort *)(uVar46 + lVar37) == 5) {
                  psVar50[1] = psVar50[1] | 2;
                  psVar50[0xe] = psVar50[0xe] + -1;
                  psVar50[0x15] = (short)uVar46;
                  lVar37 = (uVar46 & 0xffff) + *(longlong *)(psVar50 + 4);
                  uVar15 = psVar50[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar37 + 2) >> 0xe & 1) != 0) {
                    uVar15 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar50[0x16] & 0xc7ffU;
                  }
                  psVar50[0x16] = uVar15;
                  psVar50[0x16] = (uVar15 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar15;
                  break;
                }
                if (*(ushort *)(uVar46 + lVar37) < 0x400) break;
                psVar50[1] = psVar50[1] | 1;
                psVar1 = psVar50 + 0xe;
                *psVar1 = *psVar1 + -1;
              } while (*psVar1 != 0);
              pbVar32 = *(byte **)(psVar50 + 4);
            }
            iVar16 = 0;
            if ((*pbVar32 & 0x40) == 0) {
              *(undefined4 *)(psVar50 + 0x13) = 0;
            }
            else {
              *(int *)(psVar50 + 0x13) = *(int *)(psVar50 + 2);
              *(int *)(psVar50 + 2) = *(int *)(psVar50 + 2) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x1019b0;
              puVar24 = (ulonglong *)func_0x(psVar50 + 1);
              uVar30 = (ushort)(*puVar24 >> 0x30);
              uVar15 = uVar30;
              if ((((uint)(int)(short)uVar30 >> 1 ^ (int)(short)uVar30) & 0x2000) != 0) {
                uVar15 = uVar30 & 0xdfff;
                if ((uVar30 >> 0xe & 1) != 0) {
                  uVar15 = uVar30 | 0x2000;
                }
              }
              if (uVar15 == 0xfffc) {
                iVar16 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar50 + 2) = *(int *)(psVar50 + 2) + iVar16;
              pbVar32 = *(byte **)(psVar50 + 4);
            }
            uVar17 = *(uint *)(psVar50 + 2);
            if ((*(byte **)(psVar50 + 0xf) != (byte *)0x0) &&
               (*(byte **)(psVar50 + 0xf) < pbVar32 + uVar17)) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar37 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                   (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x101aa6;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101acc;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                }
              }
              uVar27 = *(undefined8 *)(psVar50 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x101ada;
              func_0x(uVar27,0x12);
              uVar17 = *(uint *)(psVar50 + 2);
            }
            if (0x3f3b < uVar17 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x101b66;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101b8c;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                }
              }
              uVar27 = *(undefined8 *)(psVar50 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x101b9a;
              func_0x(uVar27,5);
            }
          }
LAB_:
          uVar17 = *(uint *)(psVar50 + 2);
          if (uVar17 < 9) {
            pbVar32 = *(byte **)(psVar50 + 4);
            if (((*pbVar32 & 0xe) != 0) && ((*pbVar32 & 0xe) != 0xc)) goto LAB_;
            uVar45 = 9;
          }
          else {
LAB_:
            pbVar32 = *(byte **)(psVar50 + 4);
            uVar45 = uVar17;
          }
          *(undefined4 *)(&stack0x00000700 + lVar19) = *(undefined4 *)(psVar50 + 8);
          *(short *)(&stack0x000006f2 + lVar19) = psVar50[1];
          *(uint *)(&stack0x000006f4 + lVar19) = uVar17;
          *(short *)(&stack0x0000070c + lVar19) = psVar50[0xe];
          *(undefined4 *)(&stack0x00000704 + lVar19) = *(undefined4 *)(psVar50 + 10);
          *(undefined4 *)(&stack0x00000708 + lVar19) = *(undefined4 *)(psVar50 + 0xc);
          *(undefined4 *)(&stack0x00000716 + lVar19) = *(undefined4 *)(psVar50 + 0x13);
          *(undefined8 *)(puVar43 + -8) = 0x101c18;
          func_0x(&stack0x00001208 + lVar19,0x1f9e,pbVar32,uVar45);
          *(undefined **)(&stack0x000006f8 + lVar19) = &stack0x00001208 + lVar19;
          *(undefined8 *)(puVar43 + -8) = 0x101c32;
          iVar16 = func_0x(&stack0x000006f2 + lVar19);
          if (iVar16 != 0) {
            lVar37 = *(longlong *)(&stack0x000006f8 + lVar19);
            puVar40 = (ushort *)((ulonglong)*(uint *)(&stack0x00000704 + lVar19) + lVar37);
            uVar17 = *puVar40 - 1;
            if (((&stack0x000006f2)[lVar19] & 1) == 0) {
              uVar17 = (uint)*puVar40;
            }
            uVar45 = *(uint *)(&stack0x00000708 + lVar19);
            if (uVar17 != 1) {
              uVar45 = puVar40[(longlong)(int)uVar17 + -1] & 0x7fff;
            }
            if ((uVar45 < *(uint *)(&stack0x00000708 + lVar19)) ||
               ((puVar40[(int)uVar17] & 0x7fff) < uVar45)) {
              *(undefined8 *)(puVar43 + -8) = 0x101c99;
              func_0x(lVar37,7);
              lVar37 = *(longlong *)(&stack0x000006f8 + lVar19);
            }
            *(short *)(&stack0x0000071a + lVar19) = (short)uVar45;
            lVar37 = (ulonglong)(uVar45 & 0xffff) + lVar37;
            uVar15 = *(ushort *)(lVar37 + 2);
            uVar30 = *(ushort *)(&stack0x0000071c + lVar19);
            if ((uVar15 >> 0xe & 1) == 0) {
              uVar30 = uVar30 & 0xc7ff;
            }
            else {
              uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
            }
            *(ushort *)(&stack0x0000071c + lVar19) = uVar30;
            *(ushort *)(&stack0x0000071c + lVar19) =
                 (uVar30 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar30;
          }
        }
        else if ((*(longlong **)(psVar50 + 8) == (longlong *)0x0) ||
                (**(longlong **)(psVar50 + 8) == 0)) {
          *(undefined8 *)(puVar43 + -8) = 0x101d4a;
          func_0x(&stack0x000006f2 + lVar19,&stack0x00001208 + lVar19,0x1f9e,psVar50 + 1);
          if (*psVar50 != 0) {
            uVar27 = *(undefined8 *)(psVar50 + 8);
          }
          *(undefined8 *)(&stack0x00000700 + lVar19) = uVar27;
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x101d2b;
          func_0x(&stack0x000006f0 + lVar19,&stack0x00001208 + lVar19,0x1f9e,psVar50);
        }
        *(undefined8 *)(puVar43 + -8) = 0x101d66;
        func_0x(lVar28);
        if ((*(byte *)(lVar28 + 0x10) & 0x80) == 0) {
          uVar27 = *(undefined8 *)(lVar28 + 0x18);
          *(undefined8 *)(puVar43 + -8) = 0x101d76;
          func_0x(uVar27);
          *(uint *)(lVar28 + 0x10) = *(uint *)(lVar28 + 0x10) | 0x80;
        }
        (&stack0x0000007e)[lVar19] = 1;
        psVar50 = (short *)(&stack0x000006f0 + lVar19);
        puVar48 = &stack0x000006f2 + lVar19;
      }
      *(undefined8 *)(&stack0x000006d0 + lVar19) = 0;
      *(undefined2 *)(&stack0x000006d8 + lVar19) = 0;
      plVar20 = *(longlong **)(*(longlong *)(lVar28 + 0xf8) + 0x18);
      plVar21 = *(longlong **)(&stack0x000000c8 + lVar19);
      lVar28 = plVar21[6];
      cVar13 = *(char *)(lVar28 + 0x1cde);
      if ((*(char *)(lVar28 + 0x2050) != '\0') && ((*(byte *)(plVar20 + 2) & 1) != 0)) {
        pcVar5 = *(code **)(*plVar21 + 0xf0);
        *(undefined8 *)(puVar43 + -8) = 0x101de4;
        iVar16 = (*pcVar5)(plVar21);
        if (iVar16 == 0) {
          lVar37 = plVar21[0x49];
        }
        else {
          pcVar5 = *(code **)(*plVar21 + 0x1e8);
          *(undefined8 *)(puVar43 + -8) = 0x101df4;
          lVar37 = (*pcVar5)(plVar21);
          lVar37 = *(longlong *)(lVar37 + 0x248);
        }
        if (*(char *)(lVar37 + 0x16) == '\0') {
          *(undefined8 *)(puVar43 + -8) = 0x101e20;
          (*_DAT_)(0x27,0x30,0x10,2);
        }
      }
      *(undefined8 *)(puVar43 + -8) = 0x101e2f;
      func_0x(&stack0x00000518 + lVar19,psVar50);
      *(undefined4 *)(&stack0x00000078 + lVar19) = 1;
      if (((byte)((ushort)uVar4 >> 0xd) & 1) == 0) {
        if ((DAT_ & 8) == 0) {
          lVar28 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
          if ((lVar28 != 0) && (lVar28 = **(longlong **)(lVar28 + 0x38), lVar28 != 0)) {
            *(undefined8 *)(puVar43 + -8) = 0x102294;
            iVar16 = (*_DAT_)(lVar28,0xf73);
            if (iVar16 != 0) goto LAB_;
          }
        }
        else {
LAB_:
          if (plVar21[0x1a] == 0) {
            uVar27 = 0;
          }
          else {
            uVar27 = *(undefined8 *)(plVar21[0x1a] + 0x40);
          }
          uVar4 = *(undefined2 *)(plVar21[6] + 0x6b8);
          pcVar5 = *(code **)(*(longlong *)plVar21[0x52] + 0x138);
          *(undefined8 *)(puVar43 + -8) = 0x1022ce;
          uVar25 = (*pcVar5)();
          *(undefined8 *)(puVar43 + 0x20) = uVar27;
          lVar28 = plVar20[5];
          *(undefined8 *)(puVar43 + -8) = 0x1022e8;
          func_0x(0x1854ff0,uVar4,lVar28,uVar25);
        }
        goto LAB_;
      }
      lVar37 = plVar21[6];
      if (*(char *)(lVar37 + 0x1ad8) == '\0') {
        if (*psVar50 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x101e66;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x101e6d;
          func_0x(puVar48,&stack0x0000019c + lVar19);
        }
        *(undefined8 *)(puVar43 + -8) = 0x101e79;
        cVar14 = func_0x(&stack0x0000019c + lVar19);
        if (cVar14 == '\0') goto LAB_;
LAB_:
        if (*(short *)(&stack0x00000518 + lVar19) == 0) {
          bVar33 = **(byte **)(&stack0x00000520 + lVar19) >> 6;
        }
        else {
          bVar33 = **(byte **)(&stack0x00000520 + lVar19) >> 1;
        }
        if ((bVar33 & 1) == 0) goto LAB_;
        if (*(short *)(&stack0x00000518 + lVar19) == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x101ff0;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x101ff7;
          func_0x(&stack0x0000051a + lVar19,&stack0x000000fe + lVar19);
        }
        if ((*(short *)(&stack0x00000102 + lVar19) == 0) &&
           (*(int *)(&stack0x000000fe + lVar19) == 0)) goto LAB_;
        if ((plVar20 == (longlong *)0x0) || ((*(byte *)(plVar20 + 2) & 0x20) == 0)) {
LAB_:
          *(undefined8 *)(puVar43 + 0x58) = 0;
          if (*psVar50 == 1) {
            *(undefined **)(puVar43 + 0x50) = &stack0x000006d0 + lVar19;
            *(undefined8 *)(puVar43 + 0x48) = 0;
            *(undefined8 *)(puVar43 + 0x40) = 0;
            puVar43[0x38] = 1;
            *(undefined **)(puVar43 + 0x30) = &stack0x00000078 + lVar19;
            *(undefined **)(puVar43 + 0x28) = &stack0x00000518 + lVar19;
            *(longlong **)(puVar43 + 0x20) = plVar20;
            *(undefined8 *)(puVar43 + -8) = 0x1021fe;
            func_0x(psVar50,&stack0x000031a8 + lVar19,0x1f9e,plVar21);
          }
          else {
            puVar43[0x50] = 0;
            *(undefined **)(puVar43 + 0x48) = &stack0x000006d0 + lVar19;
            *(undefined8 *)(puVar43 + 0x40) = 0;
            *(undefined8 *)(puVar43 + 0x38) = 0;
            puVar43[0x30] = 1;
            *(undefined **)(puVar43 + 0x28) = &stack0x00000078 + lVar19;
            *(undefined **)(puVar43 + 0x20) = &stack0x00000518 + lVar19;
            *(undefined8 *)(puVar43 + -8) = 0x102248;
            func_0x(&stack0x000031a8 + lVar19,0x1f9e,plVar21,plVar20);
          }
        }
        else {
          plVar26 = plVar21;
          if ((*(byte *)(plVar21 + 0x43) & 4) != 0) {
            pcVar5 = *(code **)(*plVar21 + 0x1e8);
            *(undefined8 *)(puVar43 + -8) = 0x10203e;
            plVar26 = (longlong *)(*pcVar5)(plVar21);
          }
          if (*(short *)(&stack0x00000518 + lVar19) == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10205f;
            func_0x();
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x102066;
            func_0x(&stack0x0000051a + lVar19,&stack0x00000104 + lVar19);
          }
          if ((*(short *)(&stack0x00000108 + lVar19) != *(short *)((longlong)plVar26 + 0x2c)) ||
             (*(int *)(&stack0x00000104 + lVar19) != *(int *)(plVar26 + 5))) goto LAB_;
          lVar37 = plVar21[0x1a];
          if (cVar13 == '\0') {
LAB_:
            *(undefined8 *)(puVar43 + 0x50) = 0;
            *(undefined **)(puVar43 + 0x48) = &stack0x00000078 + lVar19;
            puVar43[0x40] = 0;
            *(undefined8 *)(puVar43 + 0x38) = 0;
            *(undefined **)(puVar43 + 0x30) = &stack0x00000518 + lVar19;
            *(longlong *)(puVar43 + 0x28) = *plVar20;
            *(undefined4 *)(puVar43 + 0x20) = 0x1f9e;
            uVar27 = *(undefined8 *)(lVar28 + 0x6b0);
            lVar37 = plVar20[4];
            lVar22 = plVar21[0x1a];
            *(undefined8 *)(puVar43 + -8) = 0x102115;
            func_0x(lVar22,lVar37,uVar27,&stack0x000031a8 + lVar19);
            if (cVar13 != '\0') goto LAB_;
          }
          else {
            if (((lVar37 != 0) && (*(char *)(lVar37 + 0x34) != '\0')) &&
               (*(longlong *)(lVar37 + 0x40) != 0)) {
              LOCK();
              lVar22 = *(longlong *)(lVar37 + 0x128);
              if (lVar22 == 0) {
                *(longlong *)(lVar37 + 0x128) = 0;
                lVar22 = 0;
              }
              UNLOCK();
              if (*(longlong *)(*plVar20 + 0x28) != lVar22) goto LAB_;
            }
LAB_:
            if (*(short *)(&stack0x00000518 + lVar19) == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x10213b;
              func_0x();
            }
            else {
              *(undefined8 *)(puVar43 + -8) = 0x102142;
              func_0x(&stack0x0000051a + lVar19,&stack0x00000184 + lVar19);
            }
            if (*(short *)(&stack0x00000518 + lVar19) == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x10215f;
              func_0x();
            }
            else {
              *(undefined8 *)(puVar43 + -8) = 0x102166;
              func_0x(&stack0x0000051a + lVar19,&stack0x0000010a + lVar19);
            }
            *(undefined4 *)(&stack0x000000d4 + lVar19) = *(undefined4 *)(&stack0x0000010a + lVar19);
            *(undefined2 *)(&stack0x000000d8 + lVar19) = *(undefined2 *)(&stack0x0000010e + lVar19);
            *(undefined8 *)(puVar43 + -8) = 0x10219a;
            iVar16 = func_0x(lVar28 + 0x19c8,&stack0x000000d4 + lVar19,
                                     &stack0x00000184 + lVar19);
            if (iVar16 != 0) goto LAB_;
          }
        }
      }
      else {
LAB_:
        puVar6 = *(uint **)(*(longlong *)(lVar37 + 0x6b0) + 0x2c0);
        uVar17 = *(uint *)(&stack0x000001b0 + lVar19);
        if ((((*(short *)((longlong)puVar6 + 10) == 2) && (uVar17 == 0)) || (*puVar6 < uVar17)) ||
           ((uVar17 == *puVar6 &&
            ((puVar6[1] < *(uint *)(&stack0x000001b4 + lVar19) ||
             ((*(uint *)(&stack0x000001b4 + lVar19) == puVar6[1] &&
              (*(ushort *)(puVar6 + 2) < *(ushort *)(&stack0x000000a0 + lVar19)))))))))
        goto LAB_;
        if (*(char *)(lVar37 + 0x2050) != '\0') {
          if (*psVar50 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x101eec;
            func_0x();
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x101ef3;
            func_0x(puVar48,&stack0x000001a4 + lVar19);
          }
          *(undefined8 *)(puVar43 + -8) = 0x101eff;
          cVar14 = func_0x(&stack0x000001a4 + lVar19);
          if (cVar14 != '\0') goto LAB_;
        }
        if ((DAT_ & 8) == 0) {
          lVar28 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
          if ((lVar28 != 0) && (lVar28 = **(longlong **)(lVar28 + 0x38), lVar28 != 0)) {
            *(undefined8 *)(puVar43 + -8) = 0x101f56;
            iVar16 = (*_DAT_)(lVar28,0xf73);
            if (iVar16 != 0) goto LAB_;
          }
        }
        else {
LAB_:
          if (plVar21[0x1a] == 0) {
            uVar27 = 0;
          }
          else {
            uVar27 = *(undefined8 *)(plVar21[0x1a] + 0x40);
          }
          uVar4 = *(undefined2 *)(plVar21[6] + 0x6b8);
          pcVar5 = *(code **)(*(longlong *)plVar21[0x52] + 0x138);
          *(undefined8 *)(puVar43 + -8) = 0x101f91;
          uVar25 = (*pcVar5)();
          *(undefined8 *)(puVar43 + 0x20) = uVar27;
          lVar28 = plVar20[5];
          *(undefined8 *)(puVar43 + -8) = 0x101fab;
          func_0x(0x1854f40,uVar4,lVar28,uVar25);
        }
LAB_:
        if ((DAT_ & 8) == 0) {
          lVar28 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
          if ((lVar28 != 0) && (lVar28 = **(longlong **)(lVar28 + 0x38), lVar28 != 0)) {
            *(undefined8 *)(puVar43 + -8) = 0x10233d;
            iVar16 = (*_DAT_)(lVar28,0xf73);
            if (iVar16 != 0) goto LAB_;
          }
        }
        else {
LAB_:
          *(undefined8 *)(puVar43 + -8) = 0x102352;
          (*_DAT_)(&stack0x00000248 + lVar19);
          *(undefined8 *)(puVar43 + -8) = 0x102359;
          uVar27 = (*_DAT_)();
          *(undefined8 *)(puVar43 + -8) = 0x10236a;
          lVar28 = (*_DAT_)(uVar27,0,0x6c0);
          *(longlong *)(&stack0x000001c0 + lVar19) = lVar28;
          if (lVar28 == 0) {
            puVar29 = (undefined8 *)0x0;
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x102380;
            puVar29 = (undefined8 *)func_0x(lVar28,0);
          }
          if (puVar29 != (undefined8 *)0x0) {
            *(undefined8 *)(puVar43 + -8) = 0x1023a3;
            iVar16 = (*_DAT_)(&stack0x00000248 + lVar19,puVar29);
            if (iVar16 == 0) {
              pcVar5 = *(code **)*puVar29;
              *(undefined8 *)(puVar43 + -8) = 0x1023b4;
              (*pcVar5)(puVar29,1);
            }
          }
          *(undefined8 *)(puVar43 + -8) = 0x1023c7;
          func_0x(&stack0x00000518 + lVar19,&stack0x00000248 + lVar19);
          *(undefined8 *)(puVar43 + -8) = 0x1023d5;
          (*_DAT_)(&stack0x00000248 + lVar19);
        }
      }
      cVar13 = (&stack0x00000039)[lVar19];
      if ((cVar13 != '\0') && (*(int *)(&stack0x00000078 + lVar19) == 1)) {
        pcVar5 = *(code **)(**(longlong **)(&stack0x00000088 + lVar19) + 8);
        *(undefined8 *)(puVar43 + -8) = 0x1023f3;
        (*pcVar5)();
        puVar29 = *(undefined8 **)(&stack0x000000e0 + lVar19);
        if (puVar29 != (undefined8 *)0x0) {
          pcVar5 = *(code **)*puVar29;
          *(undefined8 *)(puVar43 + -8) = 0x10240b;
          (*pcVar5)(puVar29,1);
        }
        goto LAB_;
      }
      if ((2 < *(int *)(&stack0x00000078 + lVar19) - 2U) &&
         (*(int *)(&stack0x00000078 + lVar19) != 0)) {
        *(undefined8 *)(puVar43 + 0x20) = 0;
        *(undefined8 *)(puVar43 + -8) = 0x10244c;
        (*_DAT_)(1,0x19fb208,0x19d02d0,0xc58);
      }
      sVar47 = *(short *)(&stack0x00000518 + lVar19);
      pbVar32 = *(byte **)(&stack0x00000520 + lVar19);
      if (sVar47 == 0) {
        bVar33 = *pbVar32 >> 6;
      }
      else {
        bVar33 = *pbVar32 >> 1;
      }
      if ((bVar33 & 1) != 0) {
        if (sVar47 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x102493;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x10249a;
          func_0x(&stack0x0000051a + lVar19,&stack0x000000c8 + lVar19);
        }
        sVar47 = *(short *)(&stack0x00000518 + lVar19);
        pbVar32 = *(byte **)(&stack0x00000520 + lVar19);
      }
      if (*(int *)(&stack0x00000078 + lVar19) == 0) {
LAB_:
        bVar51 = true;
      }
      else {
        bVar51 = false;
        if (sVar47 == 0) {
          bVar33 = *pbVar32 & 0xe;
          if (bVar33 == 2) {
            bVar51 = (pbVar32[1] & 1) != 0;
          }
          else if (((bVar33 - 10 & 0xf9) == 0) && (bVar33 != 0x10)) {
            bVar51 = true;
          }
        }
        else {
          bVar51 = ((*pbVar32 & 0x1c) - 4 & 0xffffffe7) == 0;
        }
        if (bVar51) goto LAB_;
        bVar51 = false;
      }
      if (cVar13 != '\0') {
        *pcVar2 = '\0';
        cVar13 = '\0';
        bVar11 = false;
        if (!bVar51) goto LAB_;
        goto LAB_;
      }
      if (bVar51) {
        if ((&stack0x0000007c)[lVar19] != '\0') {
          if (*(int *)(&stack0x00000078 + lVar19) == 0) {
            cVar13 = '\0';
          }
          else {
            uVar27 = *(undefined8 *)(&stack0x00000090 + lVar19);
            *(undefined8 *)(puVar43 + -8) = 0x10252b;
            cVar13 = func_0x(uVar27,&stack0x00000518 + lVar19);
            sVar47 = *(short *)(&stack0x00000518 + lVar19);
          }
          if ((&stack0x0000007d)[lVar19] == '\x04') {
            uVar17 = *(uint *)(&stack0x000000a4 + lVar19) & 0xff;
            if (cVar13 == '\0') {
              uVar17 = 1;
            }
            *(uint *)(&stack0x000000a4 + lVar19) = uVar17;
          }
        }
        if (*(int *)(&stack0x00000078 + lVar19) == 0) {
LAB_:
          bVar11 = false;
        }
        else {
          if (sVar47 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10256f;
            func_0x();
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x102576;
            func_0x(&stack0x0000051a + lVar19,&stack0x00000110 + lVar19);
          }
          if ((*(short *)(&stack0x00000114 + lVar19) == 0) &&
             (*(int *)(&stack0x00000110 + lVar19) == 0)) goto LAB_;
          if (*(short *)(&stack0x00000518 + lVar19) == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x1025aa;
            func_0x();
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x1025b1;
            func_0x(&stack0x0000051a + lVar19,&stack0x0000018c + lVar19);
          }
          *(undefined8 *)(&stack0x000005c8 + lVar19) = *(undefined8 *)(&stack0x0000018c + lVar19);
          if (*(short *)(&stack0x00000518 + lVar19) == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x1025dc;
            func_0x();
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x1025e3;
            func_0x(&stack0x0000051a + lVar19,&stack0x00000116 + lVar19);
          }
          *(undefined4 *)(&stack0x000005d0 + lVar19) = *(undefined4 *)(&stack0x00000116 + lVar19);
          *(undefined2 *)(&stack0x000005d4 + lVar19) = *(undefined2 *)(&stack0x0000011a + lVar19);
          bVar11 = true;
          *pcVar2 = '\x01';
        }
        cVar13 = (char)*(undefined4 *)(&stack0x000000a4 + lVar19);
LAB_:
        bVar10 = bVar11;
        cVar14 = cVar13;
        lVar37 = *(longlong *)(&stack0x00000088 + lVar19);
      }
      else {
LAB_:
        cVar14 = '\0';
        bVar10 = false;
        *pcVar2 = '\0';
        cVar13 = '\0';
        bVar11 = false;
        if (*(longlong *)(&stack0x00000138 + lVar19) == 0) goto LAB_;
        cVar3 = *(char *)(*(longlong *)(&stack0x00000138 + lVar19) + 3);
        *pcVar2 = '\0';
        if (cVar3 == '\0') goto LAB_;
        lVar28 = *(longlong *)(*(longlong *)(&stack0x00000090 + lVar19) + 8);
        *pcVar2 = '\0';
        lVar37 = *(longlong *)(&stack0x00000088 + lVar19);
        if (*(char *)(lVar28 + 0x751) == '\0') {
          *(longlong *)(puVar43 + 0x20) = *(longlong *)(&stack0x00000090 + lVar19);
          *(undefined8 *)(puVar43 + -8) = 0x10266d;
          iVar16 = func_0x(lVar37,cVar3,&stack0x00000518 + lVar19,plVar21);
          if (iVar16 != 0) {
            *(undefined8 *)(puVar43 + 0x20) = 0;
            *(undefined8 *)(puVar43 + -8) = 0x102693;
            (*_DAT_)(1,0x19fb1f0,0x19d02d0,0xccb);
          }
          *pcVar2 = '\0';
        }
      }
      if ((&stack0x0000007e)[lVar19] == '\0') {
        *(undefined8 *)(puVar43 + -8) = 0x1026b1;
        func_0x(lVar37);
        if ((*(byte *)(lVar37 + 0x10) & 0x80) == 0) {
          uVar27 = *(undefined8 *)(lVar37 + 0x18);
          *(undefined8 *)(puVar43 + -8) = 0x1026c1;
          func_0x(uVar27);
          *(uint *)(lVar37 + 0x10) = *(uint *)(lVar37 + 0x10) | 0x80;
        }
      }
      puVar48 = &stack0x00000518 + lVar19;
      if (*(int *)(&stack0x00000078 + lVar19) == 0) {
        puVar48 = (undefined *)0x0;
      }
      uVar12 = (&stack0x00000180)[lVar19];
      uVar17 = *(uint *)(&stack0x000000b8 + lVar19);
      *(undefined8 *)(puVar43 + -8) = 0x1026f7;
      iVar16 = func_0x(puVar48,uVar17 & 0xff,&stack0x00000154 + lVar19,uVar12);
      if ((&stack0x00000039)[lVar19] == '\0') {
        cVar13 = (char)uVar17;
        if (bVar51) {
          if (cVar14 != '\0') goto LAB_;
          if (cVar13 == '\0') {
LAB_:
            if (bVar10) {
              uVar17 = *(uint *)(&stack0x0000051c + lVar19);
              if (*(short *)(&stack0x00000518 + lVar19) == 0) {
                if (uVar17 == 0) {
                  *(undefined2 *)(&stack0x0000051a + lVar19) = 0;
                  uVar17 = *(uint *)(&stack0x00000528 + lVar19);
                  uVar31 = (ulonglong)uVar17;
                  *(uint *)(&stack0x0000052c + lVar19) = uVar17;
                  if ((**(byte **)(&stack0x00000520 + lVar19) & 0x10) != 0) {
                    uVar17 = uVar17 + 2 +
                             (*(ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31) + 7 >> 3);
                    uVar31 = (ulonglong)uVar17;
                    *(uint *)(&stack0x0000052c + lVar19) = uVar17;
                  }
                  if ((**(byte **)(&stack0x00000520 + lVar19) & 0x20) == 0) {
                    *(int *)(&stack0x0000051c + lVar19) = (int)uVar31;
                    *(undefined2 *)(&stack0x00000534 + lVar19) = 0;
                    *(int *)(&stack0x00000530 + lVar19) = (int)uVar31;
                  }
                  else {
                    puVar40 = (ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31);
                    uVar15 = *puVar40;
                    *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                    if (uVar15 == 0) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar28 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                         ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                          (*(char *)(lVar28 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x1059b6;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x1059dc;
                          (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                        }
                      }
                      uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                      *(undefined8 *)(puVar43 + -8) = 0x1059ed;
                      func_0x(uVar27,3);
                      uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                    }
                    uVar17 = *(int *)(&stack0x0000052c + lVar19) + 2 + (uint)uVar15 * 2;
                    *(uint *)(&stack0x00000530 + lVar19) = uVar17;
                    if (0x1f9e < uVar17) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar28 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                          ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                           (*(char *)(lVar28 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x105a90;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x105ab6;
                          (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                        }
                      }
                      uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                      *(undefined8 *)(puVar43 + -8) = 0x105ac7;
                      func_0x(uVar27,4);
                      uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                      uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                    }
                    uVar45 = puVar40[uVar15] & 0x7fff;
                    *(uint *)(&stack0x0000051c + lVar19) = uVar45;
                    if (uVar45 < uVar17) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar28 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                         ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                          (*(char *)(lVar28 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x105b68;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x105b8e;
                          (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                        }
                      }
                      uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                      *(undefined8 *)(puVar43 + -8) = 0x105b9f;
                      func_0x(uVar27,4);
                      uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                      uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                      uVar45 = *(uint *)(&stack0x0000051c + lVar19);
                    }
                    uVar46 = (ulonglong)uVar17;
                    uVar31 = (ulonglong)uVar45;
                    do {
                      if (-1 < (short)puVar40[(ulonglong)(uVar15 - 1) + 1]) break;
                      uVar41 = uVar46;
                      if (uVar15 != 1) {
                        uVar41 = (ulonglong)
                                 (*(ushort *)
                                   ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                                    *(longlong *)(&stack0x00000520 + lVar19) + -2 +
                                   (ulonglong)uVar15 * 2) & 0x7fff);
                      }
                      uVar45 = (uint)uVar41;
                      if ((uVar45 < (uint)uVar46) ||
                         ((*(ushort *)
                            ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                             *(longlong *)(&stack0x00000520 + lVar19) + (ulonglong)uVar15 * 2) &
                          0x7fff) < uVar45)) {
                        uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                        *(undefined8 *)(puVar43 + -8) = 0x105c18;
                        func_0x(uVar27,7);
                        uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                        uVar46 = (ulonglong)*(uint *)(&stack0x00000530 + lVar19);
                        uVar31 = (ulonglong)*(uint *)(&stack0x0000051c + lVar19);
                      }
                      uVar17 = (uint)uVar31;
                      if ((uVar45 < (uint)uVar46) || (uVar17 < uVar45)) goto LAB_;
                      if (*(ushort *)(uVar41 + *(longlong *)(&stack0x00000520 + lVar19)) == 5) {
                        *(ushort *)(&stack0x0000051a + lVar19) =
                             *(ushort *)(&stack0x0000051a + lVar19) | 2;
                        *(ushort *)(&stack0x00000534 + lVar19) = uVar15 - 1;
                        *(short *)(&stack0x00000542 + lVar19) = (short)uVar41;
                        lVar28 = (uVar41 & 0xffff) + *(longlong *)(&stack0x00000520 + lVar19);
                        uVar15 = *(ushort *)(lVar28 + 2);
                        uVar30 = *(ushort *)(&stack0x00000544 + lVar19);
                        if ((uVar15 & 0x4000) == 0) {
                          uVar30 = uVar30 & 0xc7ff;
                        }
                        else {
                          uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000544 + lVar19) = uVar30;
                        *(ushort *)(&stack0x00000544 + lVar19) =
                             (uVar30 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar30;
                        break;
                      }
                      if (*(ushort *)(uVar41 + *(longlong *)(&stack0x00000520 + lVar19)) < 0x400)
                      break;
                      *(ushort *)(&stack0x0000051a + lVar19) =
                           *(ushort *)(&stack0x0000051a + lVar19) | 1;
                      uVar15 = uVar15 - 1;
                      *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                    } while (uVar15 != 0);
                  }
                  iVar49 = 0;
                  if ((**(byte **)(&stack0x00000520 + lVar19) & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000053e + lVar19) = 0;
                  }
                  else {
                    *(int *)(&stack0x0000053e + lVar19) = (int)uVar31;
                    *(int *)(&stack0x0000051c + lVar19) = (int)uVar31 + 0xe;
                    *(undefined8 *)(puVar43 + -8) = 0x105d49;
                    puVar24 = (ulonglong *)func_0x(&stack0x0000051a + lVar19);
                    uVar31 = *puVar24;
                    uVar15 = (ushort)(uVar31 >> 0x30);
                    if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
                      if ((uVar31 & 0x4000000000000000) == 0) {
                        uVar15 = uVar15 & 0xdfff;
                      }
                      else {
                        uVar15 = uVar15 | 0x2000;
                      }
                    }
                    if (uVar15 == 0xfffc) {
                      iVar49 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                    }
                    uVar31 = (ulonglong)(uint)(*(int *)(&stack0x0000051c + lVar19) + iVar49);
                    *(int *)(&stack0x0000051c + lVar19) =
                         *(int *)(&stack0x0000051c + lVar19) + iVar49;
                  }
                  uVar17 = (uint)uVar31;
                  if ((*(ulonglong *)(&stack0x00000536 + lVar19) != 0) &&
                     (*(ulonglong *)(&stack0x00000536 + lVar19) <
                      uVar31 + *(longlong *)(&stack0x00000520 + lVar19))) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       (((lVar28 = *(longlong *)
                                    ((ulonglong)*_DAT_ +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                         (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                        (*(char *)(lVar28 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x105e43;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x105e69;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                      }
                    }
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x105e7a;
                    func_0x(uVar27,0x12);
                    uVar17 = *(uint *)(&stack0x0000051c + lVar19);
                  }
                  if (0x3f3b < uVar17 - 1) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                        ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                         (*(char *)(lVar28 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x105f08;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x105f2e;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                      }
                    }
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x105f3f;
                    func_0x(uVar27,5);
                    uVar17 = *(uint *)(&stack0x0000051c + lVar19);
                  }
                }
LAB_:
                if (uVar17 < 9) {
                  bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0xe;
joined_r0x00105f86:
                  if ((bVar33 == 0) || (bVar33 == 0xc)) {
                    uVar17 = 9;
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    goto LAB_;
                  }
                }
              }
              else {
                if (uVar17 == 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x105f6e;
                  func_0x(&stack0x0000051a + lVar19);
                  uVar17 = *(uint *)(&stack0x0000051c + lVar19);
                }
                if (uVar17 < 9) {
                  bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0x1c;
                  goto joined_r0x00105f86;
                }
              }
              uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
            }
            else {
              uVar17 = 0;
              uVar27 = 0;
            }
LAB_:
            uVar45 = 9;
            if (*(short *)(&stack0x00000040 + lVar19) == 0) {
              uVar34 = *(uint *)(&stack0x00000044 + lVar19);
              if (uVar34 == 0) {
                *(undefined2 *)(&stack0x00000042 + lVar19) = 0;
                uVar34 = *(uint *)(&stack0x00000050 + lVar19);
                uVar31 = (ulonglong)uVar34;
                *(uint *)(&stack0x00000054 + lVar19) = uVar34;
                if ((**(byte **)(&stack0x00000048 + lVar19) & 0x10) != 0) {
                  uVar34 = uVar34 + 2 +
                           (*(ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31) + 7 >> 3);
                  uVar31 = (ulonglong)uVar34;
                  *(uint *)(&stack0x00000054 + lVar19) = uVar34;
                }
                if ((**(byte **)(&stack0x00000048 + lVar19) & 0x20) == 0) {
                  *(int *)(&stack0x00000044 + lVar19) = (int)uVar31;
                  *(undefined2 *)(&stack0x0000005c + lVar19) = 0;
                  *(int *)(&stack0x00000058 + lVar19) = (int)uVar31;
                }
                else {
                  puVar40 = (ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31);
                  uVar15 = *puVar40;
                  *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
                  if (uVar15 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                       ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                        (*(char *)(lVar28 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x106097;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x1060bd;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                      }
                    }
                    uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x1060cb;
                    func_0x(uVar25,3);
                    uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
                  }
                  uVar34 = *(int *)(&stack0x00000054 + lVar19) + 2 + (uint)uVar15 * 2;
                  *(uint *)(&stack0x00000058 + lVar19) = uVar34;
                  if (0x1f9e < uVar34) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                        ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                         (*(char *)(lVar28 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x106169;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10618f;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                      }
                    }
                    uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x10619d;
                    func_0x(uVar25,4);
                    uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
                    uVar34 = *(uint *)(&stack0x00000058 + lVar19);
                  }
                  uVar41 = (ulonglong)uVar34;
                  uVar46 = (ulonglong)uVar15;
                  uVar35 = puVar40[uVar46] & 0x7fff;
                  uVar31 = (ulonglong)uVar35;
                  *(uint *)(&stack0x00000044 + lVar19) = uVar35;
                  if (uVar35 < uVar34) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                       ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                        (*(char *)(lVar28 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10623a;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x106260;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                      }
                    }
                    uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x10626e;
                    func_0x(uVar25,4);
                    uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                    uVar41 = (ulonglong)*(uint *)(&stack0x00000058 + lVar19);
                    uVar31 = (ulonglong)*(uint *)(&stack0x00000044 + lVar19);
                  }
                  do {
                    if (-1 < (short)puVar40[(ulonglong)((int)uVar46 - 1) + 1]) break;
                    uVar42 = uVar41;
                    if ((int)uVar46 != 1) {
                      uVar42 = (ulonglong)
                               (*(ushort *)
                                 ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                                  *(longlong *)(&stack0x00000048 + lVar19) + -2 + uVar46 * 2) &
                               0x7fff);
                    }
                    uVar35 = (uint)uVar42;
                    if ((uVar35 < (uint)uVar41) ||
                       ((*(ushort *)
                          ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                           *(longlong *)(&stack0x00000048 + lVar19) + uVar46 * 2) & 0x7fff) < uVar35
                       )) {
                      uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                      *(undefined8 *)(puVar43 + -8) = 0x1062d6;
                      func_0x(uVar25,7);
                      uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                      uVar41 = (ulonglong)*(uint *)(&stack0x00000058 + lVar19);
                      uVar31 = (ulonglong)*(uint *)(&stack0x00000044 + lVar19);
                    }
                    uVar34 = (uint)uVar31;
                    if ((uVar35 < (uint)uVar41) || (uVar34 < uVar35)) goto LAB_;
                    if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000048 + lVar19)) == 5) {
                      *(ushort *)(&stack0x00000042 + lVar19) =
                           *(ushort *)(&stack0x00000042 + lVar19) | 2;
                      *(short *)(&stack0x0000005c + lVar19) = (short)uVar46 + -1;
                      *(short *)(&stack0x0000006a + lVar19) = (short)uVar42;
                      lVar28 = (uVar42 & 0xffff) + *(longlong *)(&stack0x00000048 + lVar19);
                      uVar15 = *(ushort *)(lVar28 + 2);
                      uVar30 = *(ushort *)(&stack0x0000006c + lVar19);
                      if ((uVar15 & 0x4000) == 0) {
                        uVar30 = uVar30 & 0xc7ff;
                      }
                      else {
                        uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                      }
                      *(ushort *)(&stack0x0000006c + lVar19) = uVar30;
                      *(ushort *)(&stack0x0000006c + lVar19) =
                           (uVar30 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar30;
                      break;
                    }
                    if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000048 + lVar19)) < 0x400)
                    break;
                    *(ushort *)(&stack0x00000042 + lVar19) =
                         *(ushort *)(&stack0x00000042 + lVar19) | 1;
                    uVar15 = (short)uVar46 - 1;
                    uVar46 = (ulonglong)uVar15;
                    *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
                  } while (uVar15 != 0);
                }
                iVar49 = 0;
                if ((**(byte **)(&stack0x00000048 + lVar19) & 0x40) == 0) {
                  *(undefined4 *)(&stack0x00000066 + lVar19) = 0;
                }
                else {
                  *(int *)(&stack0x00000066 + lVar19) = (int)uVar31;
                  *(int *)(&stack0x00000044 + lVar19) = (int)uVar31 + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x1063dd;
                  puVar24 = (ulonglong *)func_0x(&stack0x00000042 + lVar19);
                  uVar31 = *puVar24;
                  uVar15 = (ushort)(uVar31 >> 0x30);
                  if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
                    if ((uVar31 & 0x4000000000000000) == 0) {
                      uVar15 = uVar15 & 0xdfff;
                    }
                    else {
                      uVar15 = uVar15 | 0x2000;
                    }
                  }
                  if (uVar15 == 0xfffc) {
                    iVar49 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                  }
                  uVar31 = (ulonglong)(uint)(*(int *)(&stack0x00000044 + lVar19) + iVar49);
                  *(int *)(&stack0x00000044 + lVar19) = *(int *)(&stack0x00000044 + lVar19) + iVar49
                  ;
                }
                uVar34 = (uint)uVar31;
                if ((*(ulonglong *)(&stack0x0000005e + lVar19) != 0) &&
                   (*(ulonglong *)(&stack0x0000005e + lVar19) <
                    uVar31 + *(longlong *)(&stack0x00000048 + lVar19))) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar28 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                       (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                      (*(char *)(lVar28 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1064c8;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1064ee;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                    }
                  }
                  uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x1064fc;
                  func_0x(uVar25,0x12);
                  uVar34 = *(uint *)(&stack0x00000044 + lVar19);
                }
                if (0x3f3b < uVar34 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar28 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                      ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                       (*(char *)(lVar28 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x106587;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1065ad;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                    }
                  }
                  uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x1065bb;
                  func_0x(uVar25,5);
                  uVar34 = *(uint *)(&stack0x00000044 + lVar19);
                }
              }
LAB_:
              if ((8 < uVar34) ||
                 (((**(byte **)(&stack0x00000048 + lVar19) & 0xe) != 0 &&
                  ((**(byte **)(&stack0x00000048 + lVar19) & 0xe) != 0xc)))) {
                uVar45 = uVar34;
              }
            }
            else {
              uVar34 = *(uint *)(&stack0x00000044 + lVar19);
              if (uVar34 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x1065e9;
                func_0x(&stack0x00000042 + lVar19);
                uVar34 = *(uint *)(&stack0x00000044 + lVar19);
              }
              if ((8 < uVar34) ||
                 (((**(byte **)(&stack0x00000048 + lVar19) & 0x1c) != 0 &&
                  ((**(byte **)(&stack0x00000048 + lVar19) & 0x1c) != 0xc)))) {
                uVar45 = uVar34;
              }
            }
            uVar8 = *(uint6 *)(*(longlong *)(&stack0x00000090 + lVar19) + 0x14);
            uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
            lVar28 = *(longlong *)(&stack0x000000c0 + lVar19);
            *(undefined8 *)(puVar43 + -8) = 0x106635;
            func_0x(lVar28,(ulonglong)uVar8 << 0x10,1);
            puVar43[0x40] = iVar16 == 0;
          }
          else {
            if (bVar10) {
              uVar17 = *(uint *)(&stack0x0000051c + lVar19);
              if (*(short *)(&stack0x00000518 + lVar19) == 0) {
                if (uVar17 == 0) {
                  *(undefined2 *)(&stack0x0000051a + lVar19) = 0;
                  uVar17 = *(uint *)(&stack0x00000528 + lVar19);
                  uVar31 = (ulonglong)uVar17;
                  *(uint *)(&stack0x0000052c + lVar19) = uVar17;
                  if ((**(byte **)(&stack0x00000520 + lVar19) & 0x10) != 0) {
                    uVar17 = uVar17 + 2 +
                             (*(ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31) + 7 >> 3);
                    uVar31 = (ulonglong)uVar17;
                    *(uint *)(&stack0x0000052c + lVar19) = uVar17;
                  }
                  if ((**(byte **)(&stack0x00000520 + lVar19) & 0x20) == 0) {
                    *(int *)(&stack0x0000051c + lVar19) = (int)uVar31;
                    *(undefined2 *)(&stack0x00000534 + lVar19) = 0;
                    *(int *)(&stack0x00000530 + lVar19) = (int)uVar31;
                  }
                  else {
                    puVar40 = (ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31);
                    uVar15 = *puVar40;
                    *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                    if (uVar15 == 0) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar28 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                         ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                          (*(char *)(lVar28 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x10365d;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x103683;
                          (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                        }
                      }
                      uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                      *(undefined8 *)(puVar43 + -8) = 0x103694;
                      func_0x(uVar27,3);
                      uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                    }
                    uVar17 = *(int *)(&stack0x0000052c + lVar19) + 2 + (uint)uVar15 * 2;
                    *(uint *)(&stack0x00000530 + lVar19) = uVar17;
                    if (0x1f9e < uVar17) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar28 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                          ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                           (*(char *)(lVar28 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x103737;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x10375d;
                          (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                        }
                      }
                      uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                      *(undefined8 *)(puVar43 + -8) = 0x10376e;
                      func_0x(uVar27,4);
                      uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                      uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                    }
                    uVar45 = puVar40[uVar15] & 0x7fff;
                    *(uint *)(&stack0x0000051c + lVar19) = uVar45;
                    if (uVar45 < uVar17) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar28 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                         ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                          (*(char *)(lVar28 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x10380f;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x103835;
                          (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                        }
                      }
                      uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                      *(undefined8 *)(puVar43 + -8) = 0x103846;
                      func_0x(uVar27,4);
                      uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                      uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                      uVar45 = *(uint *)(&stack0x0000051c + lVar19);
                    }
                    uVar46 = (ulonglong)uVar17;
                    uVar31 = (ulonglong)uVar45;
                    do {
                      if (-1 < (short)puVar40[(ulonglong)(uVar15 - 1) + 1]) break;
                      uVar41 = uVar46;
                      if (uVar15 != 1) {
                        uVar41 = (ulonglong)
                                 (*(ushort *)
                                   ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                                    *(longlong *)(&stack0x00000520 + lVar19) + -2 +
                                   (ulonglong)uVar15 * 2) & 0x7fff);
                      }
                      uVar45 = (uint)uVar41;
                      if ((uVar45 < (uint)uVar46) ||
                         ((*(ushort *)
                            ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                             *(longlong *)(&stack0x00000520 + lVar19) + (ulonglong)uVar15 * 2) &
                          0x7fff) < uVar45)) {
                        uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                        *(undefined8 *)(puVar43 + -8) = 0x1038bf;
                        func_0x(uVar27,7);
                        uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                        uVar46 = (ulonglong)*(uint *)(&stack0x00000530 + lVar19);
                        uVar31 = (ulonglong)*(uint *)(&stack0x0000051c + lVar19);
                      }
                      uVar17 = (uint)uVar31;
                      if ((uVar45 < (uint)uVar46) || (uVar17 < uVar45)) goto LAB_;
                      if (*(ushort *)(uVar41 + *(longlong *)(&stack0x00000520 + lVar19)) == 5) {
                        *(ushort *)(&stack0x0000051a + lVar19) =
                             *(ushort *)(&stack0x0000051a + lVar19) | 2;
                        *(ushort *)(&stack0x00000534 + lVar19) = uVar15 - 1;
                        *(short *)(&stack0x00000542 + lVar19) = (short)uVar41;
                        lVar28 = (uVar41 & 0xffff) + *(longlong *)(&stack0x00000520 + lVar19);
                        uVar15 = *(ushort *)(lVar28 + 2);
                        uVar30 = *(ushort *)(&stack0x00000544 + lVar19);
                        if ((uVar15 & 0x4000) == 0) {
                          uVar30 = uVar30 & 0xc7ff;
                        }
                        else {
                          uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000544 + lVar19) = uVar30;
                        *(ushort *)(&stack0x00000544 + lVar19) =
                             (uVar30 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar30;
                        break;
                      }
                      if (*(ushort *)(uVar41 + *(longlong *)(&stack0x00000520 + lVar19)) < 0x400)
                      break;
                      *(ushort *)(&stack0x0000051a + lVar19) =
                           *(ushort *)(&stack0x0000051a + lVar19) | 1;
                      uVar15 = uVar15 - 1;
                      *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                    } while (uVar15 != 0);
                  }
                  iVar16 = 0;
                  if ((**(byte **)(&stack0x00000520 + lVar19) & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000053e + lVar19) = 0;
                  }
                  else {
                    *(int *)(&stack0x0000053e + lVar19) = (int)uVar31;
                    *(int *)(&stack0x0000051c + lVar19) = (int)uVar31 + 0xe;
                    *(undefined8 *)(puVar43 + -8) = 0x1039f0;
                    puVar24 = (ulonglong *)func_0x(&stack0x0000051a + lVar19);
                    uVar31 = *puVar24;
                    uVar30 = (ushort)(uVar31 >> 0x30);
                    uVar15 = uVar30;
                    if ((((uint)(int)(short)uVar30 >> 1 ^ (int)(short)uVar30) & 0x2000) != 0) {
                      uVar15 = uVar30 & 0xdfff;
                      if ((uVar31 & 0x4000000000000000) != 0) {
                        uVar15 = uVar30 | 0x2000;
                      }
                    }
                    if (uVar15 == 0xfffc) {
                      iVar16 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                    }
                    uVar31 = (ulonglong)(uint)(*(int *)(&stack0x0000051c + lVar19) + iVar16);
                    *(int *)(&stack0x0000051c + lVar19) =
                         *(int *)(&stack0x0000051c + lVar19) + iVar16;
                  }
                  uVar17 = (uint)uVar31;
                  if ((*(ulonglong *)(&stack0x00000536 + lVar19) != 0) &&
                     (*(ulonglong *)(&stack0x00000536 + lVar19) <
                      uVar31 + *(longlong *)(&stack0x00000520 + lVar19))) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       (((lVar28 = *(longlong *)
                                    ((ulonglong)*_DAT_ +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                         (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                        (*(char *)(lVar28 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x103af5;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x103b1b;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                      }
                    }
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x103b2c;
                    func_0x(uVar27,0x12);
                    uVar17 = *(uint *)(&stack0x0000051c + lVar19);
                  }
                  if (0x3f3b < uVar17 - 1) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                        ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                         (*(char *)(lVar28 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x103bba;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x103be0;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                      }
                    }
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x103bf1;
                    func_0x(uVar27,5);
                    uVar17 = *(uint *)(&stack0x0000051c + lVar19);
                  }
                }
LAB_:
                if (uVar17 < 9) {
                  bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0xe;
joined_r0x00103c38:
                  if ((bVar33 == 0) || (bVar33 == 0xc)) {
                    uVar17 = 9;
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    goto LAB_;
                  }
                }
              }
              else {
                if (uVar17 == 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x103c20;
                  func_0x(&stack0x0000051a + lVar19);
                  uVar17 = *(uint *)(&stack0x0000051c + lVar19);
                }
                if (uVar17 < 9) {
                  bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0x1c;
                  goto joined_r0x00103c38;
                }
              }
              uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
            }
            else {
              uVar17 = 0;
              uVar27 = 0;
            }
LAB_:
            uVar45 = 9;
            if (*(short *)(&stack0x00000040 + lVar19) == 0) {
              uVar34 = *(uint *)(&stack0x00000044 + lVar19);
              if (uVar34 == 0) {
                *(undefined2 *)(&stack0x00000042 + lVar19) = 0;
                uVar34 = *(uint *)(&stack0x00000050 + lVar19);
                uVar31 = (ulonglong)uVar34;
                *(uint *)(&stack0x00000054 + lVar19) = uVar34;
                if ((**(byte **)(&stack0x00000048 + lVar19) & 0x10) != 0) {
                  uVar34 = uVar34 + 2 +
                           (*(ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31) + 7 >> 3);
                  uVar31 = (ulonglong)uVar34;
                  *(uint *)(&stack0x00000054 + lVar19) = uVar34;
                }
                if ((**(byte **)(&stack0x00000048 + lVar19) & 0x20) == 0) {
                  *(int *)(&stack0x00000044 + lVar19) = (int)uVar31;
                  *(undefined2 *)(&stack0x0000005c + lVar19) = 0;
                  *(int *)(&stack0x00000058 + lVar19) = (int)uVar31;
                }
                else {
                  puVar40 = (ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31);
                  uVar15 = *puVar40;
                  *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
                  if (uVar15 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                       ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                        (*(char *)(lVar28 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x103d4f;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x103d75;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                      }
                    }
                    uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x103d83;
                    func_0x(uVar25,3);
                    uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
                  }
                  uVar35 = *(int *)(&stack0x00000054 + lVar19) + 2 + (uint)uVar15 * 2;
                  *(uint *)(&stack0x00000058 + lVar19) = uVar35;
                  if (0x1f9e < uVar35) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                        ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                         (*(char *)(lVar28 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x103e21;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x103e47;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                      }
                    }
                    uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x103e55;
                    func_0x(uVar25,4);
                    uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
                    uVar35 = *(uint *)(&stack0x00000058 + lVar19);
                  }
                  uVar46 = (ulonglong)uVar15;
                  uVar34 = puVar40[uVar46] & 0x7fff;
                  uVar31 = (ulonglong)uVar34;
                  *(uint *)(&stack0x00000044 + lVar19) = uVar34;
                  if (uVar34 < uVar35) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                       ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                        (*(char *)(lVar28 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x103ef2;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x103f18;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                      }
                    }
                    uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x103f26;
                    func_0x(uVar25,4);
                    uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                    uVar35 = *(uint *)(&stack0x00000058 + lVar19);
                    uVar31 = (ulonglong)*(uint *)(&stack0x00000044 + lVar19);
                  }
                  do {
                    if (-1 < (short)puVar40[(ulonglong)((int)uVar46 - 1) + 1]) break;
                    uVar39 = uVar35;
                    if ((int)uVar46 != 1) {
                      uVar39 = *(ushort *)
                                ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                                 *(longlong *)(&stack0x00000048 + lVar19) + -2 + uVar46 * 2) &
                               0x7fff;
                    }
                    if ((uVar39 < uVar35) ||
                       ((*(ushort *)
                          ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                           *(longlong *)(&stack0x00000048 + lVar19) + uVar46 * 2) & 0x7fff) < uVar39
                       )) {
                      uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                      *(undefined8 *)(puVar43 + -8) = 0x103f96;
                      func_0x(uVar25,7);
                      uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                      uVar35 = *(uint *)(&stack0x00000058 + lVar19);
                      uVar31 = (ulonglong)*(uint *)(&stack0x00000044 + lVar19);
                    }
                    uVar34 = (uint)uVar31;
                    if ((uVar39 < uVar35) || (uVar34 < uVar39)) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(&stack0x00000048 + lVar19)) ==
                        5) {
                      *(ushort *)(&stack0x00000042 + lVar19) =
                           *(ushort *)(&stack0x00000042 + lVar19) | 2;
                      *(short *)(&stack0x0000005c + lVar19) = (short)uVar46 + -1;
                      *(short *)(&stack0x0000006a + lVar19) = (short)uVar39;
                      lVar28 = (ulonglong)(uVar39 & 0xffff) +
                               *(longlong *)(&stack0x00000048 + lVar19);
                      uVar15 = *(ushort *)(lVar28 + 2);
                      uVar30 = *(ushort *)(&stack0x0000006c + lVar19);
                      if ((uVar15 & 0x4000) == 0) {
                        uVar30 = uVar30 & 0xc7ff;
                      }
                      else {
                        uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                      }
                      *(ushort *)(&stack0x0000006c + lVar19) = uVar30;
                      *(ushort *)(&stack0x0000006c + lVar19) =
                           (uVar30 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar30;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(&stack0x00000048 + lVar19)) <
                        0x400) break;
                    *(ushort *)(&stack0x00000042 + lVar19) =
                         *(ushort *)(&stack0x00000042 + lVar19) | 1;
                    uVar15 = (short)uVar46 - 1;
                    uVar46 = (ulonglong)uVar15;
                    *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
                  } while (uVar15 != 0);
                }
                iVar16 = 0;
                if ((**(byte **)(&stack0x00000048 + lVar19) & 0x40) == 0) {
                  *(undefined4 *)(&stack0x00000066 + lVar19) = 0;
                }
                else {
                  *(int *)(&stack0x00000066 + lVar19) = (int)uVar31;
                  *(int *)(&stack0x00000044 + lVar19) = (int)uVar31 + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x10408e;
                  puVar24 = (ulonglong *)func_0x(&stack0x00000042 + lVar19);
                  uVar31 = *puVar24;
                  uVar30 = (ushort)(uVar31 >> 0x30);
                  uVar15 = uVar30;
                  if ((((uint)(int)(short)uVar30 >> 1 ^ (int)(short)uVar30) & 0x2000) != 0) {
                    uVar15 = uVar30 & 0xdfff;
                    if ((uVar31 & 0x4000000000000000) != 0) {
                      uVar15 = uVar30 | 0x2000;
                    }
                  }
                  if (uVar15 == 0xfffc) {
                    iVar16 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                  }
                  uVar31 = (ulonglong)(uint)(*(int *)(&stack0x00000044 + lVar19) + iVar16);
                  *(int *)(&stack0x00000044 + lVar19) = *(int *)(&stack0x00000044 + lVar19) + iVar16
                  ;
                }
                uVar34 = (uint)uVar31;
                if ((*(ulonglong *)(&stack0x0000005e + lVar19) != 0) &&
                   (*(ulonglong *)(&stack0x0000005e + lVar19) <
                    uVar31 + *(longlong *)(&stack0x00000048 + lVar19))) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar28 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                       (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                      (*(char *)(lVar28 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x104185;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1041ab;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                    }
                  }
                  uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x1041b9;
                  func_0x(uVar25,0x12);
                  uVar34 = *(uint *)(&stack0x00000044 + lVar19);
                }
                if (0x3f3b < uVar34 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar28 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                      ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                       (*(char *)(lVar28 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x104244;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10426a;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                    }
                  }
                  uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x104278;
                  func_0x(uVar25,5);
                  uVar34 = *(uint *)(&stack0x00000044 + lVar19);
                }
              }
LAB_:
              if ((8 < uVar34) ||
                 (((**(byte **)(&stack0x00000048 + lVar19) & 0xe) != 0 &&
                  ((**(byte **)(&stack0x00000048 + lVar19) & 0xe) != 0xc)))) {
                uVar45 = uVar34;
              }
            }
            else {
              uVar34 = *(uint *)(&stack0x00000044 + lVar19);
              if (uVar34 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x1042a6;
                func_0x(&stack0x00000042 + lVar19);
                uVar34 = *(uint *)(&stack0x00000044 + lVar19);
              }
              if ((8 < uVar34) ||
                 (((**(byte **)(&stack0x00000048 + lVar19) & 0x1c) != 0 &&
                  ((**(byte **)(&stack0x00000048 + lVar19) & 0x1c) != 0xc)))) {
                uVar45 = uVar34;
              }
            }
            uVar8 = *(uint6 *)(*(longlong *)(&stack0x00000090 + lVar19) + 0x14);
            uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
            lVar28 = *(longlong *)(&stack0x000000c0 + lVar19);
            *(undefined8 *)(puVar43 + -8) = 0x1042f2;
            func_0x(lVar28,(ulonglong)uVar8 << 0x10,1);
            puVar43[0x40] = 0;
          }
          puVar48 = &stack0x000005c8 + lVar19;
          if (*pcVar2 == '\0') {
            puVar48 = (undefined *)0x0;
          }
          puVar43[0x38] = cVar13;
          *(uint *)(puVar43 + 0x30) = uVar17;
          *(undefined8 *)(puVar43 + 0x28) = uVar27;
          *(undefined8 *)(puVar43 + 0x20) = 0;
          uVar27 = *(undefined8 *)(lVar28 + 0x2268);
          *(undefined8 *)(puVar43 + -8) = 0x10432b;
          iVar16 = func_0x(uVar27,uVar25,uVar45,puVar48);
          *(int *)(&stack0x00000084 + lVar19) = iVar16;
          goto LAB_;
        }
        if (cVar14 != '\0') {
LAB_:
          (&stack0x00000080)[lVar19] = 0;
          if (bVar10) {
            uVar17 = *(uint *)(&stack0x0000051c + lVar19);
            if (*(short *)(&stack0x00000518 + lVar19) == 0) {
              if (uVar17 == 0) {
                *(undefined2 *)(&stack0x0000051a + lVar19) = 0;
                uVar17 = *(uint *)(&stack0x00000528 + lVar19);
                uVar31 = (ulonglong)uVar17;
                *(uint *)(&stack0x0000052c + lVar19) = uVar17;
                if ((**(byte **)(&stack0x00000520 + lVar19) & 0x10) != 0) {
                  uVar17 = uVar17 + 2 +
                           (*(ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31) + 7 >> 3);
                  uVar31 = (ulonglong)uVar17;
                  *(uint *)(&stack0x0000052c + lVar19) = uVar17;
                }
                if ((**(byte **)(&stack0x00000520 + lVar19) & 0x20) == 0) {
                  *(int *)(&stack0x0000051c + lVar19) = (int)uVar31;
                  *(undefined2 *)(&stack0x00000534 + lVar19) = 0;
                  *(int *)(&stack0x00000530 + lVar19) = (int)uVar31;
                }
                else {
                  puVar40 = (ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31);
                  uVar15 = *puVar40;
                  *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                  if (uVar15 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                       ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                        (*(char *)(lVar28 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10443c;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x104462;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                      }
                    }
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x104473;
                    func_0x(uVar27,3);
                    uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                  }
                  uVar17 = *(int *)(&stack0x0000052c + lVar19) + 2 + (uint)uVar15 * 2;
                  *(uint *)(&stack0x00000530 + lVar19) = uVar17;
                  if (0x1f9e < uVar17) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                        ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                         (*(char *)(lVar28 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x104516;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10453c;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                      }
                    }
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x10454d;
                    func_0x(uVar27,4);
                    uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                    uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                  }
                  uVar45 = puVar40[uVar15] & 0x7fff;
                  *(uint *)(&stack0x0000051c + lVar19) = uVar45;
                  if (uVar45 < uVar17) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar28 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                       ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                        (*(char *)(lVar28 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x1045ee;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x104614;
                        (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                      }
                    }
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x104625;
                    func_0x(uVar27,4);
                    uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                    uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                    uVar45 = *(uint *)(&stack0x0000051c + lVar19);
                  }
                  uVar46 = (ulonglong)uVar17;
                  uVar31 = (ulonglong)uVar45;
                  do {
                    if (-1 < (short)puVar40[(ulonglong)(uVar15 - 1) + 1]) break;
                    uVar41 = uVar46;
                    if (uVar15 != 1) {
                      uVar41 = (ulonglong)
                               (*(ushort *)
                                 ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                                  *(longlong *)(&stack0x00000520 + lVar19) + -2 +
                                 (ulonglong)uVar15 * 2) & 0x7fff);
                    }
                    uVar45 = (uint)uVar41;
                    if ((uVar45 < (uint)uVar46) ||
                       ((*(ushort *)
                          ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                           *(longlong *)(&stack0x00000520 + lVar19) + (ulonglong)uVar15 * 2) &
                        0x7fff) < uVar45)) {
                      uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                      *(undefined8 *)(puVar43 + -8) = 0x10469f;
                      func_0x(uVar27,7);
                      uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                      uVar46 = (ulonglong)*(uint *)(&stack0x00000530 + lVar19);
                      uVar31 = (ulonglong)*(uint *)(&stack0x0000051c + lVar19);
                    }
                    uVar17 = (uint)uVar31;
                    if ((uVar45 < (uint)uVar46) || (uVar17 < uVar45)) goto LAB_;
                    if (*(ushort *)(uVar41 + *(longlong *)(&stack0x00000520 + lVar19)) == 5) {
                      *(ushort *)(&stack0x0000051a + lVar19) =
                           *(ushort *)(&stack0x0000051a + lVar19) | 2;
                      *(ushort *)(&stack0x00000534 + lVar19) = uVar15 - 1;
                      *(short *)(&stack0x00000542 + lVar19) = (short)uVar41;
                      lVar28 = (uVar41 & 0xffff) + *(longlong *)(&stack0x00000520 + lVar19);
                      uVar15 = *(ushort *)(lVar28 + 2);
                      uVar30 = *(ushort *)(&stack0x00000544 + lVar19);
                      if ((uVar15 & 0x4000) == 0) {
                        uVar30 = uVar30 & 0xc7ff;
                      }
                      else {
                        uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                      }
                      *(ushort *)(&stack0x00000544 + lVar19) = uVar30;
                      *(ushort *)(&stack0x00000544 + lVar19) =
                           (uVar30 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar30;
                      break;
                    }
                    if (*(ushort *)(uVar41 + *(longlong *)(&stack0x00000520 + lVar19)) < 0x400)
                    break;
                    *(ushort *)(&stack0x0000051a + lVar19) =
                         *(ushort *)(&stack0x0000051a + lVar19) | 1;
                    uVar15 = uVar15 - 1;
                    *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                  } while (uVar15 != 0);
                }
                iVar49 = 0;
                if ((**(byte **)(&stack0x00000520 + lVar19) & 0x40) == 0) {
                  *(undefined4 *)(&stack0x0000053e + lVar19) = 0;
                }
                else {
                  *(int *)(&stack0x0000053e + lVar19) = (int)uVar31;
                  *(int *)(&stack0x0000051c + lVar19) = (int)uVar31 + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x1047d0;
                  puVar24 = (ulonglong *)func_0x(&stack0x0000051a + lVar19);
                  uVar31 = *puVar24;
                  uVar15 = (ushort)(uVar31 >> 0x30);
                  if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
                    if ((uVar31 & 0x4000000000000000) == 0) {
                      uVar15 = uVar15 & 0xdfff;
                    }
                    else {
                      uVar15 = uVar15 | 0x2000;
                    }
                  }
                  if (uVar15 == 0xfffc) {
                    iVar49 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                  }
                  uVar31 = (ulonglong)(uint)(*(int *)(&stack0x0000051c + lVar19) + iVar49);
                  *(int *)(&stack0x0000051c + lVar19) = *(int *)(&stack0x0000051c + lVar19) + iVar49
                  ;
                }
                uVar17 = (uint)uVar31;
                if ((*(ulonglong *)(&stack0x00000536 + lVar19) != 0) &&
                   (*(ulonglong *)(&stack0x00000536 + lVar19) <
                    uVar31 + *(longlong *)(&stack0x00000520 + lVar19))) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar28 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                       (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                      (*(char *)(lVar28 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1048ca;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1048f0;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x104901;
                  func_0x(uVar27,0x12);
                  uVar17 = *(uint *)(&stack0x0000051c + lVar19);
                }
                if (0x3f3b < uVar17 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar28 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                      ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                       (*(char *)(lVar28 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10498f;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1049b5;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x1049c6;
                  func_0x(uVar27,5);
                  uVar17 = *(uint *)(&stack0x0000051c + lVar19);
                }
              }
LAB_:
              if (uVar17 < 9) {
                bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0xe;
joined_r0x00104a0d:
                if ((bVar33 == 0) || (bVar33 == 0xc)) {
                  uVar17 = 9;
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  goto LAB_;
                }
              }
            }
            else {
              if (uVar17 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x1049f5;
                func_0x(&stack0x0000051a + lVar19);
                uVar17 = *(uint *)(&stack0x0000051c + lVar19);
              }
              if (uVar17 < 9) {
                bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0x1c;
                goto joined_r0x00104a0d;
              }
            }
            uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
          }
          else {
            uVar17 = 0;
            uVar27 = 0;
          }
LAB_:
          uVar45 = 9;
          if (*(short *)(&stack0x00000040 + lVar19) == 0) {
            uVar34 = *(uint *)(&stack0x00000044 + lVar19);
            if (uVar34 == 0) {
              *(undefined2 *)(&stack0x00000042 + lVar19) = 0;
              uVar34 = *(uint *)(&stack0x00000050 + lVar19);
              uVar31 = (ulonglong)uVar34;
              *(uint *)(&stack0x00000054 + lVar19) = uVar34;
              if ((**(byte **)(&stack0x00000048 + lVar19) & 0x10) != 0) {
                uVar34 = uVar34 + 2 +
                         (*(ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31) + 7 >> 3);
                uVar31 = (ulonglong)uVar34;
                *(uint *)(&stack0x00000054 + lVar19) = uVar34;
              }
              if ((**(byte **)(&stack0x00000048 + lVar19) & 0x20) == 0) {
                *(int *)(&stack0x00000044 + lVar19) = (int)uVar31;
                *(undefined2 *)(&stack0x0000005c + lVar19) = 0;
                *(int *)(&stack0x00000058 + lVar19) = (int)uVar31;
              }
              else {
                puVar40 = (ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31);
                uVar15 = *puVar40;
                *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
                if (uVar15 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar28 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                     ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                      (*(char *)(lVar28 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x104b1e;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x104b44;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                    }
                  }
                  uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x104b52;
                  func_0x(uVar25,3);
                  uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
                }
                uVar34 = *(int *)(&stack0x00000054 + lVar19) + 2 + (uint)uVar15 * 2;
                *(uint *)(&stack0x00000058 + lVar19) = uVar34;
                if (0x1f9e < uVar34) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar28 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                      ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                       (*(char *)(lVar28 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x104bf0;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x104c16;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                    }
                  }
                  uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x104c24;
                  func_0x(uVar25,4);
                  uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
                  uVar34 = *(uint *)(&stack0x00000058 + lVar19);
                }
                uVar41 = (ulonglong)uVar34;
                uVar46 = (ulonglong)uVar15;
                uVar35 = puVar40[uVar46] & 0x7fff;
                uVar31 = (ulonglong)uVar35;
                *(uint *)(&stack0x00000044 + lVar19) = uVar35;
                if (uVar35 < uVar34) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar28 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                     ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                      (*(char *)(lVar28 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x104cc1;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x104ce7;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                    }
                  }
                  uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x104cf5;
                  func_0x(uVar25,4);
                  uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                  uVar41 = (ulonglong)*(uint *)(&stack0x00000058 + lVar19);
                  uVar31 = (ulonglong)*(uint *)(&stack0x00000044 + lVar19);
                }
                do {
                  if (-1 < (short)puVar40[(ulonglong)((int)uVar46 - 1) + 1]) break;
                  uVar42 = uVar41;
                  if ((int)uVar46 != 1) {
                    uVar42 = (ulonglong)
                             (*(ushort *)
                               ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                                *(longlong *)(&stack0x00000048 + lVar19) + -2 + uVar46 * 2) & 0x7fff
                             );
                  }
                  uVar35 = (uint)uVar42;
                  if ((uVar35 < (uint)uVar41) ||
                     ((*(ushort *)
                        ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                         *(longlong *)(&stack0x00000048 + lVar19) + uVar46 * 2) & 0x7fff) < uVar35))
                  {
                    uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x104d66;
                    func_0x(uVar25,7);
                    uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                    uVar41 = (ulonglong)*(uint *)(&stack0x00000058 + lVar19);
                    uVar31 = (ulonglong)*(uint *)(&stack0x00000044 + lVar19);
                  }
                  uVar34 = (uint)uVar31;
                  if ((uVar35 < (uint)uVar41) || (uVar34 < uVar35)) goto LAB_;
                  if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000048 + lVar19)) == 5) {
                    *(ushort *)(&stack0x00000042 + lVar19) =
                         *(ushort *)(&stack0x00000042 + lVar19) | 2;
                    *(short *)(&stack0x0000005c + lVar19) = (short)uVar46 + -1;
                    *(short *)(&stack0x0000006a + lVar19) = (short)uVar42;
                    lVar28 = (uVar42 & 0xffff) + *(longlong *)(&stack0x00000048 + lVar19);
                    uVar15 = *(ushort *)(lVar28 + 2);
                    uVar30 = *(ushort *)(&stack0x0000006c + lVar19);
                    if ((uVar15 & 0x4000) == 0) {
                      uVar30 = uVar30 & 0xc7ff;
                    }
                    else {
                      uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                    }
                    *(ushort *)(&stack0x0000006c + lVar19) = uVar30;
                    *(ushort *)(&stack0x0000006c + lVar19) =
                         (uVar30 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar30;
                    break;
                  }
                  if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000048 + lVar19)) < 0x400) break;
                  *(ushort *)(&stack0x00000042 + lVar19) =
                       *(ushort *)(&stack0x00000042 + lVar19) | 1;
                  uVar15 = (short)uVar46 - 1;
                  uVar46 = (ulonglong)uVar15;
                  *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
                } while (uVar15 != 0);
              }
              iVar49 = 0;
              if ((**(byte **)(&stack0x00000048 + lVar19) & 0x40) == 0) {
                *(undefined4 *)(&stack0x00000066 + lVar19) = 0;
              }
              else {
                *(int *)(&stack0x00000066 + lVar19) = (int)uVar31;
                *(int *)(&stack0x00000044 + lVar19) = (int)uVar31 + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x104e6d;
                puVar24 = (ulonglong *)func_0x(&stack0x00000042 + lVar19);
                uVar31 = *puVar24;
                uVar15 = (ushort)(uVar31 >> 0x30);
                if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
                  if ((uVar31 & 0x4000000000000000) == 0) {
                    uVar15 = uVar15 & 0xdfff;
                  }
                  else {
                    uVar15 = uVar15 | 0x2000;
                  }
                }
                if (uVar15 == 0xfffc) {
                  iVar49 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                }
                uVar31 = (ulonglong)(uint)(*(int *)(&stack0x00000044 + lVar19) + iVar49);
                *(int *)(&stack0x00000044 + lVar19) = *(int *)(&stack0x00000044 + lVar19) + iVar49;
              }
              uVar34 = (uint)uVar31;
              if ((*(ulonglong *)(&stack0x0000005e + lVar19) != 0) &&
                 (*(ulonglong *)(&stack0x0000005e + lVar19) <
                  uVar31 + *(longlong *)(&stack0x00000048 + lVar19))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar28 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                     (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                    (*(char *)(lVar28 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x104f58;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x104f7e;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                  }
                }
                uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x104f8c;
                func_0x(uVar25,0x12);
                uVar34 = *(uint *)(&stack0x00000044 + lVar19);
              }
              if (0x3f3b < uVar34 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar28 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                    ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                     (*(char *)(lVar28 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x105017;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10503d;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                  }
                }
                uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x10504b;
                func_0x(uVar25,5);
                uVar34 = *(uint *)(&stack0x00000044 + lVar19);
              }
            }
LAB_:
            if ((8 < uVar34) ||
               (((**(byte **)(&stack0x00000048 + lVar19) & 0xe) != 0 &&
                ((**(byte **)(&stack0x00000048 + lVar19) & 0xe) != 0xc)))) {
              uVar45 = uVar34;
            }
          }
          else {
            uVar34 = *(uint *)(&stack0x00000044 + lVar19);
            if (uVar34 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x105079;
              func_0x(&stack0x00000042 + lVar19);
              uVar34 = *(uint *)(&stack0x00000044 + lVar19);
            }
            if ((8 < uVar34) ||
               (((**(byte **)(&stack0x00000048 + lVar19) & 0x1c) != 0 &&
                ((**(byte **)(&stack0x00000048 + lVar19) & 0x1c) != 0xc)))) {
              uVar45 = uVar34;
            }
          }
          uVar8 = *(uint6 *)(*(longlong *)(&stack0x00000090 + lVar19) + 0x14);
          uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
          lVar28 = *(longlong *)(&stack0x000000c0 + lVar19);
          *(undefined8 *)(puVar43 + -8) = 0x1050c5;
          func_0x(lVar28,(ulonglong)uVar8 << 0x10,1);
          puVar48 = &stack0x000005c8 + lVar19;
          if (*pcVar2 == '\0') {
            puVar48 = (undefined *)0x0;
          }
          puVar43[0x40] = iVar16 == 0;
          puVar43[0x38] = cVar13;
          *(uint *)(puVar43 + 0x30) = uVar17;
          *(undefined8 *)(puVar43 + 0x28) = uVar27;
          *(undefined **)(puVar43 + 0x20) = &stack0x00000080 + lVar19;
          uVar27 = *(undefined8 *)(lVar28 + 0x2268);
          *(undefined8 *)(puVar43 + -8) = 0x10510d;
          iVar16 = func_0x(uVar27,uVar25,uVar45,puVar48);
          *(int *)(&stack0x00000084 + lVar19) = iVar16;
          goto LAB_;
        }
        if (cVar13 == '\0') {
          if (bVar51) goto LAB_;
          if (*(short *)(&stack0x00000518 + lVar19) == 0) {
            bVar33 = **(byte **)(&stack0x00000520 + lVar19) >> 6;
          }
          else {
            bVar33 = **(byte **)(&stack0x00000520 + lVar19) >> 1;
          }
          if ((bVar33 & 1) != 0) {
            if (*(short *)(&stack0x00000518 + lVar19) == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x106695;
              func_0x();
            }
            else {
              *(undefined8 *)(puVar43 + -8) = 0x10669c;
              func_0x(&stack0x0000051a + lVar19,&stack0x0000011c + lVar19);
            }
            uVar18 = *(undefined4 *)(&stack0x0000011c + lVar19);
            uVar4 = *(undefined2 *)(&stack0x00000120 + lVar19);
            if (*(short *)(&stack0x00000518 + lVar19) == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x1066c6;
              func_0x();
            }
            else {
              *(undefined8 *)(puVar43 + -8) = 0x1066cd;
              func_0x(&stack0x0000051a + lVar19,&stack0x00000194 + lVar19);
            }
            lVar28 = plVar21[6];
            *(undefined4 *)(&stack0x00000138 + lVar19) = uVar18;
            *(undefined2 *)(&stack0x0000013c + lVar19) = uVar4;
            puVar43[0x40] = 0;
            puVar43[0x38] = 0;
            puVar43[0x30] = 0;
            puVar43[0x28] = 0;
            puVar43[0x20] = 0;
            uVar27 = *(undefined8 *)(lVar28 + 0x6b0);
            *(undefined8 *)(puVar43 + -8) = 0x106718;
            cVar13 = func_0x
                               (uVar27,&stack0x00000138 + lVar19,&stack0x00000194 + lVar19,
                                &stack0x000000e8 + lVar19);
            if (cVar13 == '\0') {
              if (*(short *)(&stack0x00000518 + lVar19) == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x106736;
                func_0x(&stack0x0000051a + lVar19);
              }
              else if ((**(byte **)(&stack0x00000520 + lVar19) & 2) != 0) {
                if (*(int *)(&stack0x0000051c + lVar19) == 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x106869;
                  func_0x(&stack0x0000051a + lVar19);
                }
                **(byte **)(&stack0x00000520 + lVar19) =
                     **(byte **)(&stack0x00000520 + lVar19) & 0xfd;
                *(undefined4 *)(&stack0x0000051c + lVar19) =
                     *(undefined4 *)(&stack0x00000548 + lVar19);
                *(undefined4 *)(&stack0x00000548 + lVar19) = 0;
              }
            }
          }
          iVar38 = 0;
          lVar28 = *(longlong *)(&stack0x00000090 + lVar19);
          iVar49 = *(int *)(*(longlong *)(lVar28 + 8) + 0x100);
          *(undefined8 *)(&stack0x00000090 + lVar19) = 0;
          *(undefined2 *)(&stack0x00000098 + lVar19) = 0;
          if (*(short *)(&stack0x00000040 + lVar19) == 0) {
            if (*(int *)(&stack0x00000044 + lVar19) == 0) {
              *(undefined2 *)(&stack0x00000042 + lVar19) = 0;
              uVar17 = *(uint *)(&stack0x00000050 + lVar19);
              uVar31 = (ulonglong)uVar17;
              *(uint *)(&stack0x00000054 + lVar19) = uVar17;
              if ((**(byte **)(&stack0x00000048 + lVar19) & 0x10) != 0) {
                uVar17 = uVar17 + 2 +
                         (*(ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31) + 7 >> 3);
                uVar31 = (ulonglong)uVar17;
                *(uint *)(&stack0x00000054 + lVar19) = uVar17;
              }
              if ((**(byte **)(&stack0x00000048 + lVar19) & 0x20) == 0) {
                *(int *)(&stack0x00000044 + lVar19) = (int)uVar31;
                *(undefined2 *)(&stack0x0000005c + lVar19) = 0;
                *(int *)(&stack0x00000058 + lVar19) = (int)uVar31;
              }
              else {
                puVar40 = (ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31);
                uVar15 = *puVar40;
                *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
                if (uVar15 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x106842;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1068b2;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x1068c0;
                  func_0x(uVar27,3);
                  uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
                }
                uVar17 = *(int *)(&stack0x00000054 + lVar19) + 2 + (uint)uVar15 * 2;
                *(uint *)(&stack0x00000058 + lVar19) = uVar17;
                if (0x1f9e < uVar17) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10695e;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x106984;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x106992;
                  func_0x(uVar27,4);
                  uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
                  uVar17 = *(uint *)(&stack0x00000058 + lVar19);
                }
                uVar46 = (ulonglong)uVar15;
                uVar45 = puVar40[uVar46] & 0x7fff;
                *(uint *)(&stack0x00000044 + lVar19) = uVar45;
                if (uVar45 < uVar17) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x106a2f;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x106a55;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x106a63;
                  func_0x(uVar27,4);
                  uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                  uVar17 = *(uint *)(&stack0x00000058 + lVar19);
                  uVar45 = *(uint *)(&stack0x00000044 + lVar19);
                }
                uVar31 = (ulonglong)uVar45;
                do {
                  if (-1 < (short)puVar40[(ulonglong)((int)uVar46 - 1) + 1]) break;
                  uVar45 = uVar17;
                  if ((int)uVar46 != 1) {
                    uVar45 = *(ushort *)
                              ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                               *(longlong *)(&stack0x00000048 + lVar19) + -2 + uVar46 * 2) & 0x7fff;
                  }
                  if ((uVar45 < uVar17) ||
                     ((*(ushort *)
                        ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                         *(longlong *)(&stack0x00000048 + lVar19) + uVar46 * 2) & 0x7fff) < uVar45))
                  {
                    uVar27 = *(undefined8 *)(&stack0x00000048 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x106ad6;
                    func_0x(uVar27,7);
                    uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                    uVar17 = *(uint *)(&stack0x00000058 + lVar19);
                    uVar31 = (ulonglong)*(uint *)(&stack0x00000044 + lVar19);
                  }
                  if ((uVar45 < uVar17) || ((uint)uVar31 < uVar45)) goto LAB_;
                  if (*(ushort *)((ulonglong)uVar45 + *(longlong *)(&stack0x00000048 + lVar19)) == 5
                     ) {
                    *(ushort *)(&stack0x00000042 + lVar19) =
                         *(ushort *)(&stack0x00000042 + lVar19) | 2;
                    *(short *)(&stack0x0000005c + lVar19) = (short)uVar46 + -1;
                    *(short *)(&stack0x0000006a + lVar19) = (short)uVar45;
                    lVar37 = (ulonglong)(uVar45 & 0xffff) + *(longlong *)(&stack0x00000048 + lVar19)
                    ;
                    uVar15 = *(ushort *)(lVar37 + 2);
                    uVar30 = *(ushort *)(&stack0x0000006c + lVar19);
                    if ((uVar15 & 0x4000) == 0) {
                      uVar30 = uVar30 & 0xc7ff;
                    }
                    else {
                      uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                    }
                    *(ushort *)(&stack0x0000006c + lVar19) = uVar30;
                    *(ushort *)(&stack0x0000006c + lVar19) =
                         (uVar30 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar30;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar45 + *(longlong *)(&stack0x00000048 + lVar19)) <
                      0x400) break;
                  *(ushort *)(&stack0x00000042 + lVar19) =
                       *(ushort *)(&stack0x00000042 + lVar19) | 1;
                  uVar15 = (short)uVar46 - 1;
                  uVar46 = (ulonglong)uVar15;
                  *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
                } while (uVar15 != 0);
              }
              if ((**(byte **)(&stack0x00000048 + lVar19) & 0x40) == 0) {
                *(undefined4 *)(&stack0x00000066 + lVar19) = 0;
              }
              else {
                *(int *)(&stack0x00000066 + lVar19) = (int)uVar31;
                *(int *)(&stack0x00000044 + lVar19) = (int)uVar31 + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x106bc0;
                puVar24 = (ulonglong *)func_0x(&stack0x00000042 + lVar19);
                uVar31 = *puVar24;
                uVar15 = (ushort)(uVar31 >> 0x30);
                if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
                  if ((uVar31 & 0x4000000000000000) == 0) {
                    uVar15 = uVar15 & 0xdfff;
                  }
                  else {
                    uVar15 = uVar15 | 0x2000;
                  }
                }
                iVar36 = iVar38;
                if (uVar15 == 0xfffc) {
                  iVar36 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                }
                uVar31 = (ulonglong)(uint)(*(int *)(&stack0x00000044 + lVar19) + iVar36);
                *(int *)(&stack0x00000044 + lVar19) = *(int *)(&stack0x00000044 + lVar19) + iVar36;
              }
              iVar36 = (int)uVar31;
              if ((*(ulonglong *)(&stack0x0000005e + lVar19) != 0) &&
                 (*(ulonglong *)(&stack0x0000005e + lVar19) <
                  uVar31 + *(longlong *)(&stack0x00000048 + lVar19))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar37 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                     (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x106cac;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x106cd2;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x00000048 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x106ce0;
                func_0x(uVar27,0x12);
                iVar36 = *(int *)(&stack0x00000044 + lVar19);
              }
              if (0x3f3b < iVar36 - 1U) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x106d6b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    uVar27 = *(undefined8 *)(&stack0x00000048 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x106d79;
                    func_0x(uVar27,5);
                    goto LAB_;
                  }
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x106d9f;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                }
                uVar27 = *(undefined8 *)(&stack0x00000048 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x106dad;
                func_0x(uVar27,5);
              }
            }
          }
          else if (*(int *)(&stack0x00000044 + lVar19) == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x106dbe;
            func_0x(&stack0x00000042 + lVar19);
          }
LAB_:
          if (*(short *)(&stack0x00000518 + lVar19) == 0) {
            if (*(int *)(&stack0x0000051c + lVar19) == 0) {
              *(undefined2 *)(&stack0x0000051a + lVar19) = 0;
              uVar17 = *(uint *)(&stack0x00000528 + lVar19);
              uVar31 = (ulonglong)uVar17;
              *(uint *)(&stack0x0000052c + lVar19) = uVar17;
              if ((**(byte **)(&stack0x00000520 + lVar19) & 0x10) != 0) {
                uVar17 = uVar17 + 2 +
                         (*(ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31) + 7 >> 3);
                uVar31 = (ulonglong)uVar17;
                *(uint *)(&stack0x0000052c + lVar19) = uVar17;
              }
              if ((**(byte **)(&stack0x00000520 + lVar19) & 0x20) == 0) {
                *(int *)(&stack0x0000051c + lVar19) = (int)uVar31;
                *(undefined2 *)(&stack0x00000534 + lVar19) = 0;
                *(int *)(&stack0x00000530 + lVar19) = (int)uVar31;
              }
              else {
                puVar40 = (ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31);
                uVar15 = *puVar40;
                *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                if (uVar15 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x106eaf;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x106ed5;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x106ee6;
                  func_0x(uVar27,3);
                  uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                }
                uVar17 = *(int *)(&stack0x0000052c + lVar19) + 2 + (uint)uVar15 * 2;
                *(uint *)(&stack0x00000530 + lVar19) = uVar17;
                if (0x1f9e < uVar17) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x106f8c;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x106fb2;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x106fc3;
                  func_0x(uVar27,4);
                  uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                  uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                }
                uVar31 = (ulonglong)uVar15;
                uVar15 = puVar40[uVar31];
                *(uint *)(&stack0x0000051c + lVar19) = uVar15 & 0x7fff;
                if ((uVar15 & 0x7fff) < uVar17) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x107067;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10708d;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x10709e;
                  func_0x(uVar27,4);
                  uVar31 = (ulonglong)*(ushort *)(&stack0x00000534 + lVar19);
                  uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                }
                do {
                  if (-1 < (short)puVar40[(ulonglong)((int)uVar31 - 1) + 1]) break;
                  uVar45 = uVar17;
                  if ((int)uVar31 != 1) {
                    uVar45 = *(ushort *)
                              ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                               *(longlong *)(&stack0x00000520 + lVar19) + -2 + uVar31 * 2) & 0x7fff;
                  }
                  if ((uVar45 < uVar17) ||
                     ((*(ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                         *(longlong *)(&stack0x00000520 + lVar19) + uVar31 * 2) & 0x7fff) < uVar45))
                  {
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x10711f;
                    func_0x(uVar27,7);
                    uVar31 = (ulonglong)*(ushort *)(&stack0x00000534 + lVar19);
                    uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                  }
                  if ((uVar45 < uVar17) || (*(uint *)(&stack0x0000051c + lVar19) < uVar45))
                  goto LAB_;
                  if (*(ushort *)((ulonglong)uVar45 + *(longlong *)(&stack0x00000520 + lVar19)) == 5
                     ) {
                    *(ushort *)(&stack0x0000051a + lVar19) =
                         *(ushort *)(&stack0x0000051a + lVar19) | 2;
                    *(short *)(&stack0x00000534 + lVar19) = (short)uVar31 + -1;
                    *(short *)(&stack0x00000542 + lVar19) = (short)uVar45;
                    lVar37 = (ulonglong)(uVar45 & 0xffff) + *(longlong *)(&stack0x00000520 + lVar19)
                    ;
                    uVar15 = *(ushort *)(lVar37 + 2);
                    uVar30 = *(ushort *)(&stack0x00000544 + lVar19);
                    if ((uVar15 & 0x4000) == 0) {
                      uVar30 = uVar30 & 0xc7ff;
                    }
                    else {
                      uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                    }
                    *(ushort *)(&stack0x00000544 + lVar19) = uVar30;
                    *(ushort *)(&stack0x00000544 + lVar19) =
                         (uVar30 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar30;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar45 + *(longlong *)(&stack0x00000520 + lVar19)) <
                      0x400) break;
                  *(ushort *)(&stack0x0000051a + lVar19) =
                       *(ushort *)(&stack0x0000051a + lVar19) | 1;
                  uVar15 = (short)uVar31 - 1;
                  uVar31 = (ulonglong)uVar15;
                  *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                } while (uVar15 != 0);
              }
              if ((**(byte **)(&stack0x00000520 + lVar19) & 0x40) == 0) {
                *(undefined4 *)(&stack0x0000053e + lVar19) = 0;
              }
              else {
                *(undefined4 *)(&stack0x0000053e + lVar19) =
                     *(undefined4 *)(&stack0x0000051c + lVar19);
                *(int *)(&stack0x0000051c + lVar19) = *(int *)(&stack0x0000051c + lVar19) + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x107243;
                puVar24 = (ulonglong *)func_0x(&stack0x0000051a + lVar19);
                uVar31 = *puVar24;
                uVar15 = (ushort)(uVar31 >> 0x30);
                if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
                  if ((uVar31 & 0x4000000000000000) == 0) {
                    uVar15 = uVar15 & 0xdfff;
                  }
                  else {
                    uVar15 = uVar15 | 0x2000;
                  }
                }
                if (uVar15 == 0xfffc) {
                  iVar38 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(&stack0x0000051c + lVar19) = *(int *)(&stack0x0000051c + lVar19) + iVar38;
              }
              if ((*(ulonglong *)(&stack0x00000536 + lVar19) != 0) &&
                 (*(ulonglong *)(&stack0x00000536 + lVar19) <
                  (ulonglong)*(uint *)(&stack0x0000051c + lVar19) +
                  *(longlong *)(&stack0x00000520 + lVar19))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar37 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                     (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10733a;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x107360;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x107371;
                func_0x(uVar27,0x12);
              }
              if (0x3f3b < *(int *)(&stack0x0000051c + lVar19) - 1U) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1073fe;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x107424;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x107435;
                func_0x(uVar27,5);
              }
            }
LAB_:
            if (8 < *(uint *)(&stack0x0000051c + lVar19)) goto LAB_;
            bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0xe;
joined_r0x0010747d:
            if ((bVar33 != 0) && (bVar33 != 0xc)) goto LAB_;
            uVar18 = 9;
          }
          else {
            if (*(int *)(&stack0x0000051c + lVar19) == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x107467;
              func_0x(&stack0x0000051a + lVar19);
            }
            if (*(uint *)(&stack0x0000051c + lVar19) < 9) {
              bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0x1c;
              goto joined_r0x0010747d;
            }
LAB_:
            uVar18 = *(undefined4 *)(&stack0x0000051c + lVar19);
          }
          uVar8 = *(uint6 *)(lVar28 + 0x14);
          puVar43[0x60] = 1;
          puVar43[0x58] = iVar16 == -1;
          *(uint *)(puVar43 + 0x50) = (uint)(iVar49 == 2);
          *(undefined **)(puVar43 + 0x48) = &stack0x00000090 + lVar19;
          *(undefined8 *)(puVar43 + 0x38) = *(undefined8 *)(&stack0x00000048 + lVar19);
          *(undefined4 *)(puVar43 + 0x30) = *(undefined4 *)(&stack0x000000a8 + lVar19);
          *(undefined4 *)(puVar43 + 0x28) = 0;
          *(undefined4 *)(puVar43 + 0x20) = uVar18;
          uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
          uVar25 = *(undefined8 *)(&stack0x000000c0 + lVar19);
          *(undefined8 *)(puVar43 + -8) = 0x1074ee;
          func_0x(uVar25,(ulonglong)uVar8 << 0x10,0,uVar27);
          iVar16 = *(int *)(&stack0x00000084 + lVar19);
          goto LAB_;
        }
        sVar47 = *(short *)(&stack0x00000518 + lVar19);
        if (sVar47 == 0) {
          bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0xe;
          bVar51 = false;
          if (bVar33 == 2) {
            bVar51 = (*(byte *)(*(longlong *)(&stack0x00000520 + lVar19) + 1) & 1) != 0;
          }
          else if (((bVar33 - 10 & 0xf9) == 0) && (bVar33 != 0x10)) {
            bVar51 = true;
          }
        }
        else {
          bVar51 = ((**(byte **)(&stack0x00000520 + lVar19) & 0x1c) - 4 & 0xffffffe7) == 0;
        }
        if (bVar51) {
          *(undefined8 *)(puVar43 + 0x20) = 0;
          *(undefined8 *)(puVar43 + -8) = 0x1051ad;
          (*_DAT_)(1,0x19fb1d0,0x19d02d0,0xd2d);
          sVar47 = *(short *)(&stack0x00000518 + lVar19);
        }
        if (sVar47 == 0) {
          if (*(int *)(&stack0x0000051c + lVar19) == 0) {
            *(undefined2 *)(&stack0x0000051a + lVar19) = 0;
            uVar17 = *(uint *)(&stack0x00000528 + lVar19);
            uVar31 = (ulonglong)uVar17;
            *(uint *)(&stack0x0000052c + lVar19) = uVar17;
            if ((**(byte **)(&stack0x00000520 + lVar19) & 0x10) != 0) {
              uVar17 = uVar17 + 2 +
                       (*(ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31) + 7 >> 3);
              uVar31 = (ulonglong)uVar17;
              *(uint *)(&stack0x0000052c + lVar19) = uVar17;
            }
            if ((**(byte **)(&stack0x00000520 + lVar19) & 0x20) == 0) {
              *(int *)(&stack0x0000051c + lVar19) = (int)uVar31;
              *(undefined2 *)(&stack0x00000534 + lVar19) = 0;
              *(int *)(&stack0x00000530 + lVar19) = (int)uVar31;
            }
            else {
              puVar40 = (ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31);
              uVar15 = *puVar40;
              *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
              if (uVar15 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar28 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                   ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                    (*(char *)(lVar28 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1052ac;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1052cf;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x1052e0;
                func_0x(uVar27,3);
                uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
              }
              uVar17 = *(int *)(&stack0x0000052c + lVar19) + 2 + (uint)uVar15 * 2;
              *(uint *)(&stack0x00000530 + lVar19) = uVar17;
              if (0x1f9e < uVar17) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar28 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                    ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                     (*(char *)(lVar28 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x105387;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1053aa;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x1053bb;
                func_0x(uVar27,4);
                uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                uVar17 = *(uint *)(&stack0x00000530 + lVar19);
              }
              uVar46 = (ulonglong)uVar15;
              uVar45 = puVar40[uVar46] & 0x7fff;
              *(uint *)(&stack0x0000051c + lVar19) = uVar45;
              if (uVar45 < uVar17) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar28 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                   ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                    (*(char *)(lVar28 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x105461;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x105484;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x105495;
                func_0x(uVar27,4);
                uVar46 = (ulonglong)*(ushort *)(&stack0x00000534 + lVar19);
                uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                uVar45 = *(uint *)(&stack0x0000051c + lVar19);
              }
              uVar41 = (ulonglong)uVar17;
              uVar31 = (ulonglong)uVar45;
              do {
                if (-1 < (short)puVar40[(ulonglong)((int)uVar46 - 1) + 1]) break;
                uVar42 = uVar41;
                if ((int)uVar46 != 1) {
                  uVar42 = (ulonglong)
                           (*(ushort *)
                             ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                              *(longlong *)(&stack0x00000520 + lVar19) + -2 + uVar46 * 2) & 0x7fff);
                }
                uVar17 = (uint)uVar42;
                if ((uVar17 < (uint)uVar41) ||
                   ((*(ushort *)
                      ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                       *(longlong *)(&stack0x00000520 + lVar19) + uVar46 * 2) & 0x7fff) < uVar17)) {
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x10550f;
                  func_0x(uVar27,7);
                  uVar46 = (ulonglong)*(ushort *)(&stack0x00000534 + lVar19);
                  uVar41 = (ulonglong)*(uint *)(&stack0x00000530 + lVar19);
                  uVar31 = (ulonglong)*(uint *)(&stack0x0000051c + lVar19);
                }
                if ((uVar17 < (uint)uVar41) || ((uint)uVar31 < uVar17)) goto LAB_;
                if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000520 + lVar19)) == 5) {
                  *(ushort *)(&stack0x0000051a + lVar19) =
                       *(ushort *)(&stack0x0000051a + lVar19) | 2;
                  *(short *)(&stack0x00000534 + lVar19) = (short)uVar46 + -1;
                  *(short *)(&stack0x00000542 + lVar19) = (short)uVar42;
                  lVar28 = (uVar42 & 0xffff) + *(longlong *)(&stack0x00000520 + lVar19);
                  uVar15 = *(ushort *)(lVar28 + 2);
                  uVar30 = *(ushort *)(&stack0x00000544 + lVar19);
                  if ((uVar15 & 0x4000) == 0) {
                    uVar30 = uVar30 & 0xc7ff;
                  }
                  else {
                    uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                  }
                  *(ushort *)(&stack0x00000544 + lVar19) = uVar30;
                  *(ushort *)(&stack0x00000544 + lVar19) =
                       (uVar30 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar30;
                  break;
                }
                if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000520 + lVar19)) < 0x400) break;
                *(ushort *)(&stack0x0000051a + lVar19) = *(ushort *)(&stack0x0000051a + lVar19) | 1;
                uVar15 = (short)uVar46 - 1;
                uVar46 = (ulonglong)uVar15;
                *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
              } while (uVar15 != 0);
            }
            iVar49 = 0;
            if ((**(byte **)(&stack0x00000520 + lVar19) & 0x40) == 0) {
              *(undefined4 *)(&stack0x0000053e + lVar19) = 0;
            }
            else {
              *(int *)(&stack0x0000053e + lVar19) = (int)uVar31;
              *(int *)(&stack0x0000051c + lVar19) = (int)uVar31 + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x105648;
              puVar24 = (ulonglong *)func_0x(&stack0x0000051a + lVar19);
              uVar31 = *puVar24;
              uVar15 = (ushort)(uVar31 >> 0x30);
              if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
                if ((uVar31 & 0x4000000000000000) == 0) {
                  uVar15 = uVar15 & 0xdfff;
                }
                else {
                  uVar15 = uVar15 | 0x2000;
                }
              }
              if (uVar15 == 0xfffc) {
                iVar49 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
              }
              uVar31 = (ulonglong)(uint)(*(int *)(&stack0x0000051c + lVar19) + iVar49);
              *(int *)(&stack0x0000051c + lVar19) = *(int *)(&stack0x0000051c + lVar19) + iVar49;
            }
            iVar49 = (int)uVar31;
            if ((*(ulonglong *)(&stack0x00000536 + lVar19) != 0) &&
               (*(ulonglong *)(&stack0x00000536 + lVar19) <
                uVar31 + *(longlong *)(&stack0x00000520 + lVar19))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar28 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                   (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                  (*(char *)(lVar28 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x105742;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x105765;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                }
              }
              uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
              *(undefined8 *)(puVar43 + -8) = 0x105776;
              func_0x(uVar27,0x12);
              iVar49 = *(int *)(&stack0x0000051c + lVar19);
            }
            if (0x3f3b < iVar49 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar28 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                  ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                   (*(char *)(lVar28 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x105804;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x105815;
                  func_0x(uVar27,5);
                  goto LAB_;
                }
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x105838;
                (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
              }
              uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
              *(undefined8 *)(puVar43 + -8) = 0x105849;
              func_0x(uVar27,5);
            }
          }
        }
        else if (*(int *)(&stack0x0000051c + lVar19) == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x105860;
          func_0x(&stack0x0000051a + lVar19);
        }
LAB_:
        uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
        uVar8 = *(uint6 *)(*(longlong *)(&stack0x00000090 + lVar19) + 0x14);
        lVar28 = *(longlong *)(&stack0x000000c0 + lVar19);
        *(undefined8 *)(puVar43 + -8) = 0x105893;
        func_0x(lVar28,(ulonglong)uVar8 << 0x10,1);
        uVar25 = *(undefined8 *)(lVar28 + 0x2268);
        *(undefined8 *)(puVar43 + -8) = 0x1058a9;
        func_0x(uVar25,uVar27,iVar16 == 0);
        iVar16 = *(int *)(&stack0x00000084 + lVar19);
        cVar13 = '\0';
      }
      else {
        if (*(int *)(&stack0x00000078 + lVar19) == 0) {
          uVar17 = 0;
LAB_:
          uVar27 = 0;
        }
        else {
          uVar17 = *(uint *)(&stack0x0000051c + lVar19);
          if (*(short *)(&stack0x00000518 + lVar19) == 0) {
            if (uVar17 == 0) {
              *(undefined2 *)(&stack0x0000051a + lVar19) = 0;
              uVar17 = *(uint *)(&stack0x00000528 + lVar19);
              uVar31 = (ulonglong)uVar17;
              *(uint *)(&stack0x0000052c + lVar19) = uVar17;
              if ((**(byte **)(&stack0x00000520 + lVar19) & 0x10) != 0) {
                uVar17 = uVar17 + 2 +
                         (*(ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31) + 7 >> 3);
                uVar31 = (ulonglong)uVar17;
                *(uint *)(&stack0x0000052c + lVar19) = uVar17;
              }
              if ((**(byte **)(&stack0x00000520 + lVar19) & 0x20) == 0) {
                *(int *)(&stack0x0000051c + lVar19) = (int)uVar31;
                *(undefined2 *)(&stack0x00000534 + lVar19) = 0;
                *(int *)(&stack0x00000530 + lVar19) = (int)uVar31;
              }
              else {
                puVar40 = (ushort *)(*(byte **)(&stack0x00000520 + lVar19) + uVar31);
                uVar15 = *puVar40;
                *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                if (uVar15 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar28 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                     ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                      (*(char *)(lVar28 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x102808;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10282e;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x10283f;
                  func_0x(uVar27,3);
                  uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                }
                uVar17 = *(int *)(&stack0x0000052c + lVar19) + 2 + (uint)uVar15 * 2;
                *(uint *)(&stack0x00000530 + lVar19) = uVar17;
                if (0x1f9e < uVar17) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar28 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                      ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                       (*(char *)(lVar28 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1028e5;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10290b;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x10291c;
                  func_0x(uVar27,4);
                  uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                  uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                }
                uVar45 = puVar40[uVar15] & 0x7fff;
                *(uint *)(&stack0x0000051c + lVar19) = uVar45;
                if (uVar45 < uVar17) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar28 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                     ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                      (*(char *)(lVar28 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1029c0;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1029e6;
                      (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                    }
                  }
                  uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x1029f7;
                  func_0x(uVar27,4);
                  uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                  uVar17 = *(uint *)(&stack0x00000530 + lVar19);
                  uVar45 = *(uint *)(&stack0x0000051c + lVar19);
                }
                uVar46 = (ulonglong)uVar17;
                uVar31 = (ulonglong)uVar45;
                do {
                  if (-1 < (short)puVar40[(ulonglong)(uVar15 - 1) + 1]) break;
                  uVar41 = uVar46;
                  if (uVar15 != 1) {
                    uVar41 = (ulonglong)
                             (*(ushort *)
                               ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                                *(longlong *)(&stack0x00000520 + lVar19) + -2 +
                               (ulonglong)uVar15 * 2) & 0x7fff);
                  }
                  uVar45 = (uint)uVar41;
                  if ((uVar45 < (uint)uVar46) ||
                     ((*(ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
                         *(longlong *)(&stack0x00000520 + lVar19) + (ulonglong)uVar15 * 2) & 0x7fff)
                      < uVar45)) {
                    uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                    *(undefined8 *)(puVar43 + -8) = 0x102a70;
                    func_0x(uVar27,7);
                    uVar15 = *(ushort *)(&stack0x00000534 + lVar19);
                    uVar46 = (ulonglong)*(uint *)(&stack0x00000530 + lVar19);
                    uVar31 = (ulonglong)*(uint *)(&stack0x0000051c + lVar19);
                  }
                  uVar17 = (uint)uVar31;
                  if ((uVar45 < (uint)uVar46) || (uVar17 < uVar45)) goto LAB_;
                  if (*(ushort *)(uVar41 + *(longlong *)(&stack0x00000520 + lVar19)) == 5) {
                    *(ushort *)(&stack0x0000051a + lVar19) =
                         *(ushort *)(&stack0x0000051a + lVar19) | 2;
                    *(ushort *)(&stack0x00000534 + lVar19) = uVar15 - 1;
                    *(short *)(&stack0x00000542 + lVar19) = (short)uVar41;
                    lVar28 = (uVar41 & 0xffff) + *(longlong *)(&stack0x00000520 + lVar19);
                    uVar15 = *(ushort *)(lVar28 + 2);
                    uVar30 = *(ushort *)(&stack0x00000544 + lVar19);
                    if ((uVar15 & 0x4000) == 0) {
                      uVar30 = uVar30 & 0xc7ff;
                    }
                    else {
                      uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                    }
                    *(ushort *)(&stack0x00000544 + lVar19) = uVar30;
                    *(ushort *)(&stack0x00000544 + lVar19) =
                         (uVar30 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar30;
                    break;
                  }
                  if (*(ushort *)(uVar41 + *(longlong *)(&stack0x00000520 + lVar19)) < 0x400) break;
                  *(ushort *)(&stack0x0000051a + lVar19) =
                       *(ushort *)(&stack0x0000051a + lVar19) | 1;
                  uVar15 = uVar15 - 1;
                  *(ushort *)(&stack0x00000534 + lVar19) = uVar15;
                } while (uVar15 != 0);
              }
              iVar49 = 0;
              if ((**(byte **)(&stack0x00000520 + lVar19) & 0x40) == 0) {
                *(undefined4 *)(&stack0x0000053e + lVar19) = 0;
              }
              else {
                *(int *)(&stack0x0000053e + lVar19) = (int)uVar31;
                *(int *)(&stack0x0000051c + lVar19) = (int)uVar31 + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x102b92;
                puVar24 = (ulonglong *)func_0x(&stack0x0000051a + lVar19);
                uVar31 = *puVar24;
                uVar30 = (ushort)(uVar31 >> 0x30);
                uVar15 = uVar30;
                if ((((uint)(int)(short)uVar30 >> 1 ^ (int)(short)uVar30) & 0x2000) != 0) {
                  uVar15 = uVar30 & 0xdfff;
                  if ((uVar31 & 0x4000000000000000) != 0) {
                    uVar15 = uVar30 | 0x2000;
                  }
                }
                if (uVar15 == 0xfffc) {
                  iVar49 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                }
                uVar31 = (ulonglong)(uint)(*(int *)(&stack0x0000051c + lVar19) + iVar49);
                *(int *)(&stack0x0000051c + lVar19) = *(int *)(&stack0x0000051c + lVar19) + iVar49;
              }
              uVar17 = (uint)uVar31;
              if ((*(ulonglong *)(&stack0x00000536 + lVar19) != 0) &&
                 (*(ulonglong *)(&stack0x00000536 + lVar19) <
                  uVar31 + *(longlong *)(&stack0x00000520 + lVar19))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar28 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                     (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                    (*(char *)(lVar28 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x102c98;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x102cbe;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x102ccf;
                func_0x(uVar27,0x12);
                uVar17 = *(uint *)(&stack0x0000051c + lVar19);
              }
              if (0x3f3b < uVar17 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar28 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                    ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                     (*(char *)(lVar28 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x102d5d;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x102d83;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                  }
                }
                uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x102d94;
                func_0x(uVar27,5);
                uVar17 = *(uint *)(&stack0x0000051c + lVar19);
              }
            }
LAB_:
            if (uVar17 < 9) {
              bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0xe;
joined_r0x00102ddb:
              if ((bVar33 == 0) || (bVar33 == 0xc)) {
                uVar17 = 9;
              }
            }
          }
          else {
            if (uVar17 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x102dc3;
              func_0x(&stack0x0000051a + lVar19);
              uVar17 = *(uint *)(&stack0x0000051c + lVar19);
            }
            if (uVar17 < 9) {
              bVar33 = **(byte **)(&stack0x00000520 + lVar19) & 0x1c;
              goto joined_r0x00102ddb;
            }
          }
          if (*(int *)(&stack0x00000078 + lVar19) == 0) goto LAB_;
          uVar27 = *(undefined8 *)(&stack0x00000520 + lVar19);
        }
        uVar45 = 9;
        lVar28 = *(longlong *)(&stack0x00000090 + lVar19);
        iVar49 = *(int *)(*(longlong *)(lVar28 + 8) + 0x100);
        if (*(short *)(&stack0x00000040 + lVar19) == 0) {
          uVar34 = *(uint *)(&stack0x00000044 + lVar19);
          if (uVar34 == 0) {
            *(undefined2 *)(&stack0x00000042 + lVar19) = 0;
            uVar34 = *(uint *)(&stack0x00000050 + lVar19);
            uVar31 = (ulonglong)uVar34;
            *(uint *)(&stack0x00000054 + lVar19) = uVar34;
            if ((**(byte **)(&stack0x00000048 + lVar19) & 0x10) != 0) {
              uVar34 = uVar34 + 2 +
                       (*(ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31) + 7 >> 3);
              uVar31 = (ulonglong)uVar34;
              *(uint *)(&stack0x00000054 + lVar19) = uVar34;
            }
            if ((**(byte **)(&stack0x00000048 + lVar19) & 0x20) == 0) {
              *(int *)(&stack0x00000044 + lVar19) = (int)uVar31;
              *(undefined2 *)(&stack0x0000005c + lVar19) = 0;
              *(int *)(&stack0x00000058 + lVar19) = (int)uVar31;
            }
            else {
              puVar40 = (ushort *)(*(byte **)(&stack0x00000048 + lVar19) + uVar31);
              uVar15 = *puVar40;
              *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
              if (uVar15 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar28 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                   ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                    (*(char *)(lVar28 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x102ef7;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x102f1d;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x80f);
                  }
                }
                uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x102f2b;
                func_0x(uVar25,3);
                uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
              }
              uVar34 = *(int *)(&stack0x00000054 + lVar19) + 2 + (uint)uVar15 * 2;
              *(uint *)(&stack0x00000058 + lVar19) = uVar34;
              if (0x1f9e < uVar34) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar28 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                    ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                     (*(char *)(lVar28 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x102fc9;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x102fef;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x816);
                  }
                }
                uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x102ffd;
                func_0x(uVar25,4);
                uVar15 = *(ushort *)(&stack0x0000005c + lVar19);
                uVar34 = *(uint *)(&stack0x00000058 + lVar19);
              }
              uVar41 = (ulonglong)uVar34;
              uVar46 = (ulonglong)uVar15;
              uVar35 = puVar40[uVar46] & 0x7fff;
              uVar31 = (ulonglong)uVar35;
              *(uint *)(&stack0x00000044 + lVar19) = uVar35;
              if (uVar35 < uVar34) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar28 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0)) &&
                   ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                    (*(char *)(lVar28 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10309a;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1030c0;
                    (*_DAT_)(1,0x184bf58,0x196bc28,0x81d);
                  }
                }
                uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                *(undefined8 *)(puVar43 + -8) = 0x1030ce;
                func_0x(uVar25,4);
                uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                uVar41 = (ulonglong)*(uint *)(&stack0x00000058 + lVar19);
                uVar31 = (ulonglong)*(uint *)(&stack0x00000044 + lVar19);
              }
              do {
                if (-1 < (short)puVar40[(ulonglong)((int)uVar46 - 1) + 1]) break;
                uVar42 = uVar41;
                if ((int)uVar46 != 1) {
                  uVar42 = (ulonglong)
                           (*(ushort *)
                             ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                              *(longlong *)(&stack0x00000048 + lVar19) + -2 + uVar46 * 2) & 0x7fff);
                }
                uVar35 = (uint)uVar42;
                if ((uVar35 < (uint)uVar41) ||
                   ((*(ushort *)
                      ((ulonglong)*(uint *)(&stack0x00000054 + lVar19) +
                       *(longlong *)(&stack0x00000048 + lVar19) + uVar46 * 2) & 0x7fff) < uVar35)) {
                  uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
                  *(undefined8 *)(puVar43 + -8) = 0x103136;
                  func_0x(uVar25,7);
                  uVar46 = (ulonglong)*(ushort *)(&stack0x0000005c + lVar19);
                  uVar41 = (ulonglong)*(uint *)(&stack0x00000058 + lVar19);
                  uVar31 = (ulonglong)*(uint *)(&stack0x00000044 + lVar19);
                }
                uVar34 = (uint)uVar31;
                if ((uVar35 < (uint)uVar41) || (uVar34 < uVar35)) goto LAB_;
                if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000048 + lVar19)) == 5) {
                  *(ushort *)(&stack0x00000042 + lVar19) =
                       *(ushort *)(&stack0x00000042 + lVar19) | 2;
                  *(short *)(&stack0x0000005c + lVar19) = (short)uVar46 + -1;
                  *(short *)(&stack0x0000006a + lVar19) = (short)uVar42;
                  lVar28 = (uVar42 & 0xffff) + *(longlong *)(&stack0x00000048 + lVar19);
                  uVar15 = *(ushort *)(lVar28 + 2);
                  uVar30 = *(ushort *)(&stack0x0000006c + lVar19);
                  if ((uVar15 & 0x4000) == 0) {
                    uVar30 = uVar30 & 0xc7ff;
                  }
                  else {
                    uVar30 = uVar30 ^ (uVar30 ^ uVar15) & 0x3800;
                  }
                  *(ushort *)(&stack0x0000006c + lVar19) = uVar30;
                  *(ushort *)(&stack0x0000006c + lVar19) =
                       (uVar30 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar30;
                  break;
                }
                if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000048 + lVar19)) < 0x400) break;
                *(ushort *)(&stack0x00000042 + lVar19) = *(ushort *)(&stack0x00000042 + lVar19) | 1;
                uVar15 = (short)uVar46 - 1;
                uVar46 = (ulonglong)uVar15;
                *(ushort *)(&stack0x0000005c + lVar19) = uVar15;
              } while (uVar15 != 0);
            }
            iVar38 = 0;
            if ((**(byte **)(&stack0x00000048 + lVar19) & 0x40) == 0) {
              *(undefined4 *)(&stack0x00000066 + lVar19) = 0;
            }
            else {
              *(int *)(&stack0x00000066 + lVar19) = (int)uVar31;
              *(int *)(&stack0x00000044 + lVar19) = (int)uVar31 + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x10323d;
              puVar24 = (ulonglong *)func_0x(&stack0x00000042 + lVar19);
              uVar31 = *puVar24;
              uVar30 = (ushort)(uVar31 >> 0x30);
              uVar15 = uVar30;
              if ((((uint)(int)(short)uVar30 >> 1 ^ (int)(short)uVar30) & 0x2000) != 0) {
                uVar15 = uVar30 & 0xdfff;
                if ((uVar31 & 0x4000000000000000) != 0) {
                  uVar15 = uVar30 | 0x2000;
                }
              }
              if (uVar15 == 0xfffc) {
                iVar38 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
              }
              uVar31 = (ulonglong)(uint)(*(int *)(&stack0x00000044 + lVar19) + iVar38);
              *(int *)(&stack0x00000044 + lVar19) = *(int *)(&stack0x00000044 + lVar19) + iVar38;
            }
            uVar34 = (uint)uVar31;
            if ((*(ulonglong *)(&stack0x0000005e + lVar19) != 0) &&
               (*(ulonglong *)(&stack0x0000005e + lVar19) <
                uVar31 + *(longlong *)(&stack0x00000048 + lVar19))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar28 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                   (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                  (*(char *)(lVar28 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x103333;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x103359;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x877);
                }
              }
              uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
              *(undefined8 *)(puVar43 + -8) = 0x103367;
              func_0x(uVar25,0x12);
              uVar34 = *(uint *)(&stack0x00000044 + lVar19);
            }
            if (0x3f3b < uVar34 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar28 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar28 != 0 &&
                  ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                   (*(char *)(lVar28 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x1033f2;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x103418;
                  (*_DAT_)(1,0x184bf58,0x196bc28,0x87c);
                }
              }
              uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
              *(undefined8 *)(puVar43 + -8) = 0x103426;
              func_0x(uVar25,5);
              uVar34 = *(uint *)(&stack0x00000044 + lVar19);
            }
LAB_:
            lVar28 = *(longlong *)(&stack0x00000090 + lVar19);
          }
          if ((8 < uVar34) ||
             (((**(byte **)(&stack0x00000048 + lVar19) & 0xe) != 0 &&
              ((**(byte **)(&stack0x00000048 + lVar19) & 0xe) != 0xc)))) {
            uVar45 = uVar34;
          }
        }
        else {
          uVar34 = *(uint *)(&stack0x00000044 + lVar19);
          if (uVar34 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x103458;
            func_0x(&stack0x00000042 + lVar19);
            uVar34 = *(uint *)(&stack0x00000044 + lVar19);
            lVar28 = *(longlong *)(&stack0x00000090 + lVar19);
          }
          if ((8 < uVar34) ||
             (((**(byte **)(&stack0x00000048 + lVar19) & 0x1c) != 0 &&
              ((**(byte **)(&stack0x00000048 + lVar19) & 0x1c) != 0xc)))) {
            uVar45 = uVar34;
          }
        }
        uVar8 = *(uint6 *)(lVar28 + 0x14);
        uVar25 = *(undefined8 *)(&stack0x00000048 + lVar19);
        pcVar5 = *(code **)(**(longlong **)(&stack0x000000c0 + lVar19) + 8);
        *(undefined8 *)(puVar43 + -8) = 0x10349d;
        cVar13 = (*pcVar5)();
        if (cVar13 == '\0') {
          *(undefined8 *)(puVar43 + 0x20) = 0;
          *(undefined8 *)(puVar43 + -8) = 0x1034c8;
          (*_DAT_)(1,0x1a1eff0,0x19d2870,0xf27);
        }
        lVar28 = *(longlong *)(&stack0x000000c0 + lVar19);
        *(undefined8 *)(puVar43 + -8) = 0x1034e1;
        func_0x(lVar28,(ulonglong)uVar8 << 0x10,1);
        *(undefined4 *)(&stack0x000000e8 + lVar19) = *(undefined4 *)(&stack0x000000e8 + lVar19);
        *(undefined2 *)(&stack0x000000ec + lVar19) = *(undefined2 *)(&stack0x000000d2 + lVar19);
        *(undefined4 *)(puVar43 + 0x40) = *(undefined4 *)(&stack0x00000148 + lVar19);
        *(undefined **)(puVar43 + 0x38) = &stack0x000000e8 + lVar19;
        *(int *)(puVar43 + 0x30) = iVar16;
        puVar43[0x28] = iVar49 == 2;
        *(uint *)(puVar43 + 0x20) = uVar45;
        uVar7 = *(undefined8 *)(lVar28 + 0x2268);
        *(undefined8 *)(puVar43 + -8) = 0x10353b;
        iVar16 = func_0x(uVar7,uVar27,uVar17,uVar25);
        *(int *)(&stack0x00000084 + lVar19) = iVar16;
LAB_:
        cVar13 = (&stack0x00000039)[lVar19];
      }
      if ((&stack0x0000007f)[lVar19] == '\0') {
        pcVar5 = *(code **)(**(longlong **)(&stack0x000000e0 + lVar19) + 0x28);
        *(undefined8 *)(puVar43 + -8) = 0x107509;
        (*pcVar5)();
      }
      if (((iVar16 - 1U & 0xfffffffc) != 0) || (iVar16 == 3)) {
        lVar28 = *(longlong *)(&stack0x00000168 + lVar19);
        if ((_DAT_ & 0x4000000) != 0) {
          *(undefined4 *)(&stack0x000002b0 + lVar19) = 0x10000;
          *(undefined4 *)(&stack0x000002b8 + lVar19) = 0;
          *(undefined **)(&stack0x000002c0 + lVar19) = &stack0x000002d8 + lVar19;
          *(undefined **)(&stack0x000002c8 + lVar19) = &stack0x000002e8 + lVar19;
          *(undefined8 *)(&stack0x000004f8 + lVar19) = 0;
          *(undefined8 *)(&stack0x000002d0 + lVar19) = 0;
          *(undefined8 *)(&stack0x00000500 + lVar19) = 0;
          *(undefined **)(&stack0x000002d8 + lVar19) = &stack0x00000508 + lVar19;
          *(undefined8 *)(&stack0x000002e0 + lVar19) = 8;
          *(undefined2 *)(&stack0x00000508 + lVar19) = *(undefined2 *)(lVar28 + 0x6b8);
          *(undefined4 *)(&stack0x0000050a + lVar19) =
               *(undefined4 *)(*(longlong *)(&stack0x00000088 + lVar19) + 0x100);
          *(undefined2 *)(&stack0x0000050e + lVar19) =
               *(undefined2 *)(*(longlong *)(&stack0x00000088 + lVar19) + 0x104);
          *(undefined8 *)(puVar43 + -8) = 0x1075d0;
          func_0x(&stack0x000002a8 + lVar19);
        }
        *(longlong *)(lVar28 + 0x1f0) = *(longlong *)(lVar28 + 0x1f0) + 1;
        if (cVar13 != '\0') {
          *(longlong *)(lVar28 + 0x3d8) = *(longlong *)(lVar28 + 0x3d8) + 1;
        }
      }
      puVar29 = *(undefined8 **)(&stack0x000000e0 + lVar19);
      if (puVar29 != (undefined8 *)0x0) {
        pcVar5 = *(code **)*puVar29;
        *(undefined8 *)(puVar43 + -8) = 0x1075ff;
        (*pcVar5)(puVar29,1);
      }
      param_1 = *(longlong **)(&stack0x00000088 + lVar19);
    }
  }
  pcVar5 = *(code **)(*param_1 + 8);
  *(undefined8 *)(puVar43 + -8) = 0x10760d;
  (*pcVar5)(param_1);
LAB_:
  uVar31 = *(ulonglong *)(&stack0x00005148 + lVar19);
  *(undefined8 *)(puVar43 + -8) = 0x10761f;
  func_0x(uVar31 ^ (ulonglong)pcVar2);
  return;
}

