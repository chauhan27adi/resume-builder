
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2)

{
  byte *pbVar1;
  byte bVar2;
  uint uVar3;
  longlong *plVar4;
  int iVar5;
  byte **ppbVar6;
  undefined8 uVar7;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar8;
  longlong lVar9;
  uint *puVar10;
  ulonglong uVar11;
  longlong unaff_GS_OFFSET;
  undefined auStack_668 [32];
  undefined8 uStack_648;
  longlong ***ppplStack_640;
  int iStack_620;
  byte bStack_610;
  ushort uStack_608;
  undefined2 uStack_600;
  byte bStack_5f8;
  undefined4 uStack_5f0;
  uint uStack_5e8;
  longlong *plStack_5d8;
  undefined4 uStack_5d0;
  undefined2 uStack_5cc;
  undefined4 uStack_5bc;
  undefined2 uStack_5b8;
  longlong alStack_5b0 [6];
  ushort uStack_580;
  ushort uStack_57c;
  ushort uStack_578;
  ushort uStack_570;
  uint uStack_550;
  uint uStack_548;
  uint uStack_540;
  ushort uStack_538;
  ushort uStack_536;
  undefined4 uStack_52c;
  undefined2 uStack_528;
  undefined4 uStack_524;
  short sStack_520;
  undefined4 uStack_518;
  undefined2 uStack_514;
  undefined4 uStack_510;
  undefined2 uStack_50c;
  longlong **pplStack_500;
  undefined4 uStack_4f0;
  undefined4 uStack_4ec;
  undefined2 uStack_4e8;
  undefined4 uStack_4d0;
  undefined4 uStack_4cc;
  undefined2 uStack_4c8;
  undefined4 *puStack_4c0;
  byte **ppbStack_4b8;
  int *piStack_4b0;
  undefined8 uStack_4a8;
  longlong lStack_488;
  longlong **pplStack_480;
  longlong lStack_478;
  uint uStack_454;
  int iStack_450;
  int iStack_448;
  undefined4 uStack_420;
  undefined auStack_41c [4];
  undefined4 uStack_418;
  longlong lStack_3f0;
  longlong lStack_3d0;
  longlong lStack_3c0;
  longlong lStack_3b8;
  longlong lStack_3b0;
  undefined4 *puStack_3a8;
  undefined4 *puStack_3a0;
  longlong **pplStack_398;
  longlong lStack_390;
  longlong **pplStack_388;
  undefined4 *puStack_380;
  longlong lStack_378;
  longlong lStack_370;
  byte *pbStack_368;
  undefined8 uStack_360;
  undefined *puStack_358;
  longlong lStack_350;
  undefined8 uStack_348;
  byte *pbStack_340;
  byte **ppbStack_338;
  longlong lStack_330;
  longlong lStack_328;
  byte **ppbStack_320;
  byte **ppbStack_318;
  byte *pbStack_310;
  byte **ppbStack_308;
  longlong lStack_300;
  byte *pbStack_2f8;
  longlong lStack_2f0;
  byte *pbStack_2e8;
  byte *pbStack_2c0;
  byte *pbStack_2b8;
  undefined *puStack_2b0;
  byte *pbStack_2a8;
  undefined *puStack_2a0;
  byte *pbStack_298;
  ushort *puStack_1b0;
  undefined2 *puStack_1a8;
  uint *puStack_1a0;
  longlong lStack_198;
  uint *puStack_190;
  uint *puStack_188;
  undefined8 *puStack_180;
  undefined8 uStack_178;
  undefined4 *puStack_170;
  longlong lStack_168;
  undefined8 uStack_130;
  longlong lStack_128;
  ushort uStack_f8;
  undefined auStack_f6 [2];
  undefined4 uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [16];
  undefined auStack_a0 [16];
  undefined auStack_90 [16];
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [16];
  undefined8 uStack_50;
  undefined auStack_48 [24];
  ulonglong uStack_30;
  
  uStack_130 = 0xfffffffffffffffe;
  uStack_30 = _DAT_ ^ (ulonglong)auStack_668;
  uStack_52c = 0;
  uStack_528 = 0;
  uVar3 = *(uint *)(**(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x10) + 8) + 0x160) + 0x1c
                   );
  alStack_5b0[0] = 0;
  lStack_3c0 = *(longlong *)(param_1 + 0x328);
  uStack_4a8 = param_2;
  lStack_488 = param_1;
  lStack_3d0 = param_1;
  if ((lStack_3c0 == 0) || (*(uint *)(lStack_3c0 + 0xc) < uVar3)) {
    lStack_128 = lStack_3c0;
    (*_DAT_)(lStack_3c0,0x18);
    *(undefined8 *)(param_1 + 0x328) = 0;
    func_0x
              (*(undefined8 *)(*(longlong *)(param_1 + 0x2e0) + 8),uVar3,param_1 + 0x328);
    lStack_3c0 = *(longlong *)(param_1 + 0x328);
  }
  *(undefined4 *)(lStack_3c0 + 0x10) = 1;
  *(undefined4 *)(lStack_3c0 + 0x14) = 0;
  func_0x(*(undefined8 *)(*(longlong *)(param_1 + 0x2e0) + 8),uVar3,alStack_5b0);
  lStack_3b8 = alStack_5b0[0];
  *(undefined4 *)(alStack_5b0[0] + 0x10) = 2;
  *(undefined4 *)(alStack_5b0[0] + 0x14) = 0;
  func_0x(param_1,*(undefined8 *)(param_1 + 0x328),alStack_5b0[0]);
  func_0x(*(undefined8 *)(param_1 + 0x2f8),*(undefined8 *)(param_1 + 0x388));
  lStack_3b0 = *(longlong *)(param_1 + 0x2f8);
  *(undefined4 *)(lStack_3b0 + 0xf4) = 0;
  puStack_3a8 = (undefined4 *)(lStack_3b0 + 0x118);
  uStack_518 = 0;
  uStack_514 = 0;
  *puStack_3a8 = 0;
  *(undefined2 *)(lStack_3b0 + 0x11c) = 0;
  uStack_4f0 = 0;
  uStack_4ec = 0;
  uStack_4e8 = 0;
  *(undefined8 *)(lStack_3b0 + 0x124) = 0;
  *(undefined2 *)(lStack_3b0 + 300) = 0;
  *(undefined4 *)(lStack_3b0 + 0x120) = 0;
  *(undefined4 *)(lStack_3b0 + 0x130) = 0;
  *(undefined4 *)(lStack_3b0 + 0xd0) = 0;
  ppplStack_640 = &pplStack_480;
  uStack_648 = 0;
  puStack_3a0 = puStack_3a8;
  func_0x(*(undefined8 *)(param_1 + 0x2f8),*(undefined8 *)(param_1 + 0x328),0,0);
  while (lVar8 = *(longlong *)(param_1 + 0x2f8), pplStack_480 != (longlong **)0x0) {
    pplStack_398 = pplStack_480;
    pplStack_388 = pplStack_480;
    lStack_390 = lVar8;
    if (*(int *)(pplStack_480 + 5) == 0) {
      lVar8 = *(longlong *)(**(longlong **)(lVar8 + 8) + 8);
      lStack_378 = lVar8 + 0x200;
      lVar9 = **pplStack_480;
      piStack_4b0 = (int *)(lVar8 + 0x210);
      iStack_448 = *(int *)(pplStack_480 + 3);
      lStack_3f0 = (longlong)iStack_448;
      uStack_580 = *(ushort *)(lVar9 + (0xfff - lStack_3f0) * 2);
      pbStack_368 = (byte *)((ulonglong)uStack_580 + lVar9);
      uStack_57c = (ushort)(*pbStack_368 & 1);
      lStack_370 = lVar9;
      if ((*pbStack_368 & 1) != 0) {
        uStack_f8 = 0xffff;
        pbStack_f0 = (byte *)0x0;
        uStack_f4 = 0;
        uStack_da = 0;
        uStack_d0 = 0;
        uStack_ce = 0;
        uStack_e8 = 0;
        iStack_c4 = iStack_448;
        if (*(char *)(lVar9 + 2) < '\0') {
          pbVar1 = (byte *)(lVar9 + 0x60);
          uStack_360 = 0;
          ppbStack_4b8 = (byte **)0x0;
          puStack_358 = auStack_c0;
          auStack_c0 = ZEXT816(0);
          auStack_b0 = ZEXT816(0);
          auStack_a0 = ZEXT816(0);
          auStack_90 = ZEXT816(0);
          auStack_80 = ZEXT816(0);
          auStack_70 = ZEXT816(0);
          auStack_60 = ZEXT816(0);
          uStack_50 = 0;
          ppbVar6 = (byte **)func_0x(auStack_c0);
          lStack_350 = lVar9 + 0x20;
          ppbStack_4b8 = ppbVar6;
          uVar7 = func_0x(lVar9,auStack_48,0,0);
          uStack_348 = uVar7;
          pbStack_340 = pbVar1;
          ppbStack_338 = ppbVar6;
          if ((pbVar1 == *ppbVar6) &&
             (iVar5 = func_0x(uVar7,ppbVar6 + 0xc), iVar5 != 0)) {
            lStack_330 = (longlong)ppbVar6 + 0x6c;
          }
          *ppbVar6 = pbVar1;
          func_0x(ppbVar6 + 0xc,uVar7);
          func_0x((longlong)ppbVar6 + 0x6c);
          uVar11 = (ulonglong)*pbVar1;
          uStack_578 = (ushort)*pbVar1;
          uStack_5bc = *(undefined4 *)(uVar11 * 6 + 0x15c46f0);
          uStack_5b8 = *(undefined2 *)(uVar11 * 6 + 0x15c46f4);
          uStack_524 = *(undefined4 *)(uVar11 * 6 + 0x15c46f0);
          sStack_520 = *(short *)(uVar11 * 6 + 0x15c46f4);
          uVar11 = (ulonglong)sStack_520;
          lStack_328 = lVar9 + 99;
          ppbStack_320 = ppbVar6 + 2;
          *(undefined2 *)ppbStack_320 = 0xffff;
          ppbVar6[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar6 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar6 + 0x2e) = 0;
          ppbVar6[7] = (byte *)0x0;
          ppbVar6[4] = (byte *)0x0;
          ppbStack_318 = ppbVar6 + 9;
          *ppbStack_318 = (byte *)0x0;
          ppbVar6[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar6 + 0xb) = 0;
          if ((**ppbVar6 & 2) != 0) {
            pbStack_310 = pbVar1 + uVar11;
            bVar2 = *pbStack_310;
            uStack_570 = (ushort)(bVar2 & 1);
            *(ushort *)ppbStack_320 = uStack_570;
            lStack_300 = (longlong)ppbVar6 + 0x12;
            ppbStack_308 = ppbStack_320;
            if ((bVar2 & 1) != 0) {
              ppbVar6[3] = pbStack_310;
              UNRECOVERED_JUMPTABLE_00 =
                   (code *)((ulonglong)
                            *(uint *)((ulonglong)
                                      *(byte *)((longlong)(int)(*pbStack_310 & 0x1c) + 0x101aac) * 4
                                     + 0x101a9c) - 0xf75740);
              lStack_2f0 = lStack_300;
              pbStack_2e8 = pbStack_310;
                    /* WARNING: Could not emulate address calculation at 0x00100624 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
              return;
            }
            uStack_5f0 = 0;
            ppbVar6[3] = pbStack_310;
            *(undefined4 *)((longlong)ppbVar6 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar6 + 0x36) = 0;
            pbStack_2f8 = ppbVar6[3];
                    /* WARNING: Could not emulate address calculation at 0x00100550 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_2f8 & 0xe) * 4 + 0x101a60) -
                      0xf75740))();
            return;
          }
          if ((**ppbVar6 & 4) != 0) {
            uStack_524._2_2_ = (short)((uint)uStack_524 >> 0x10);
            if (uStack_524._2_2_ != 0) {
              uVar11 = (ulonglong)*(ushort *)(lVar9 + 0x61 + (longlong)uStack_524._2_2_ * 2);
            }
            pbStack_2c0 = pbVar1 + uVar11;
            func_0x(ppbStack_318);
          }
          if (ppbVar6[1] != (byte *)0x0) {
            func_0x(ppbVar6[1],ppbVar6);
          }
        }
        else {
          ppbStack_4b8 = (byte **)0x0;
        }
        uStack_5e8 = (uint)*(ushort *)(lVar9 + 0xe);
        uStack_538 = *(ushort *)(lVar9 + (0xfff - lStack_3f0) * 2);
        pbStack_2b8 = (byte *)((ulonglong)uStack_538 + lVar9);
        uStack_536 = (ushort)(*pbStack_2b8 & 1);
        puStack_2b0 = auStack_f6;
        uStack_454 = uStack_5e8;
        uStack_f8 = uStack_536;
        pbStack_f0 = pbStack_2b8;
        if ((*pbStack_2b8 & 1) != 0) {
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)
                                  *(byte *)((longlong)(int)(*pbStack_2b8 & 0x1c) + 0x101b18) * 4 +
                                 0x101b08) - 0xf75740);
          puStack_2a0 = puStack_2b0;
          pbStack_298 = pbStack_2b8;
                    /* WARNING: Could not emulate address calculation at 0x00100943 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_2b8,pbStack_2b8);
          return;
        }
        uStack_f4 = 0;
        uStack_d2 = 0;
        uStack_d0 = 0;
        pbStack_2a8 = pbStack_2b8;
                    /* WARNING: Could not emulate address calculation at 0x00100885 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_2b8 & 0xe) * 4 + 0x101acc) -
                  0xf75740))();
        return;
      }
      iStack_450 = *piStack_4b0;
      puStack_4c0 = (undefined4 *)(pbStack_368 + iStack_450);
      uStack_5d0 = *puStack_4c0;
      uStack_5cc = *(undefined2 *)(puStack_4c0 + 1);
    }
    else {
      puStack_380 = (undefined4 *)((longlong)pplStack_480 + 0x34);
      uStack_5d0 = *puStack_380;
      uStack_5cc = *(undefined2 *)(pplStack_480 + 7);
    }
    func_0x(param_2,&uStack_5d0,&uStack_52c);
    func_0x(*(undefined8 *)(param_1 + 0x2f8),0,&pplStack_480);
  }
  lStack_478 = lVar8;
  if (*(int *)(lVar8 + 0xd0) == 2) goto LAB_;
  pplStack_500 = (longlong **)(lVar8 + 0x68);
  if (*pplStack_500 != (longlong *)0x0) {
    puStack_1b0 = (ushort *)((longlong)*pplStack_500 + 0x62);
    uStack_608 = *puStack_1b0;
    if (((uStack_608 & 0x400) == 0) || (*(short *)(lVar8 + 0x74) < 3)) {
      iStack_620 = (int)*(short *)(lVar8 + 0x74);
      plStack_5d8 = *pplStack_500;
      puStack_1a8 = (undefined2 *)((longlong)plStack_5d8 + 0x62);
      uStack_600 = *puStack_1a8;
      if (((byte)uStack_600 >> 3 & 1) != 0) {
        if (iStack_620 == 3) {
          iStack_620 = 4;
        }
        else if (iStack_620 < 2) goto LAB_;
        puStack_1a0 = (uint *)((longlong)plStack_5d8 + 100);
        uStack_550 = *puStack_1a0;
        if ((((uStack_550 & 8) != 0) && (lVar9 = plStack_5d8[0x12], lVar9 != 0)) &&
           (lStack_198 = lVar9, *(longlong *)(lVar9 + 0x758) != 0)) {
          func_0x(*(undefined8 *)(lVar9 + 0x758),plStack_5d8,iStack_620);
        }
      }
LAB_:
      bStack_5f8 = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar10 = (uint *)((longlong)plStack_5d8 + 100);
        uStack_548 = *puVar10;
        puStack_190 = puVar10;
        if ((((uStack_548 & 8) != 0) && (2 < iStack_620)) &&
           ((uStack_540 = *puVar10, puStack_188 = puVar10, (uStack_540 & 0xc0000000) != 0x40000000
            && (*plStack_5d8 != 0)))) {
          uStack_420 = 2;
          iVar5 = (*_DAT_)(*plStack_5d8,0x2000,2,auStack_41c);
          if (iVar5 != 0) {
            LOCK();
            *puVar10 = *puVar10 & 0x3fffffff;
            UNLOCK();
            LOCK();
            *puVar10 = *puVar10 | 0x40000000;
            UNLOCK();
          }
        }
      }
      plVar4 = plStack_5d8;
      iVar5 = iStack_620;
      func_0x(plStack_5d8 + 0x13,iStack_620);
      if ((_DAT_ != 0) && (bStack_610 = DAT_ >> 1, (bStack_610 & 1) != 0)) {
        func_0x(plVar4,0,iVar5);
      }
      *(uint *)(lVar8 + 0x74) = *(uint *)(lVar8 + 0x74) & 0xffff0000;
      *pplStack_500 = (longlong *)0x0;
    }
    else {
      func_0x(pplStack_500);
    }
  }
  lVar8 = lStack_478;
  *(undefined4 *)(lStack_478 + 0x80) = 0xffffffff;
  puStack_180 = (undefined8 *)(lStack_478 + 0x88);
  if (*(int *)(lStack_478 + 0x90) != 0) {
    uStack_418 = *(undefined4 *)(lStack_478 + 0x94);
    uStack_178 = *puStack_180;
    func_0x();
    *(undefined4 *)(lVar8 + 0x90) = 0;
  }
  uStack_510 = 0;
  uStack_50c = 0;
  puStack_170 = (undefined4 *)(lVar8 + 0x9c);
  *puStack_170 = 0;
  *(undefined2 *)(lVar8 + 0xa0) = 0;
  uStack_4d0 = 0;
  uStack_4cc = 0;
  uStack_4c8 = 0;
  *(undefined8 *)(lVar8 + 0xbc) = 0;
  *(undefined2 *)(lVar8 + 0xc4) = 0;
  *(int *)(lVar8 + 0xd0) = 2;
LAB_:
  if (alStack_5b0[0] != 0) {
    lStack_168 = alStack_5b0[0];
    (*_DAT_)(alStack_5b0[0],0x18);
  }
  lVar9 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar8 = *(longlong *)(lVar9 + 0x100);
  if (lVar8 == 0) {
    (*_DAT_)();
    lVar8 = *(longlong *)(lVar9 + 0x100);
  }
  if (*(int *)(lVar8 + 0x22c) != 0) {
    (*_DAT_)();
  }
  func_0x(uStack_30 ^ (ulonglong)auStack_668);
  return;
}

