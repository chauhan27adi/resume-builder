
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  func_0x();
  *param_1 = 0x245aa40;
  uVar3 = 0;
  *(undefined2 *)(param_1 + 0x4e) = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  func_0x(param_1);
  (*_DAT_)(param_1[10],*(undefined8 *)(param_1[9] + 0x1b8),
                   *(longlong *)(param_1[10] + 0x1a8) + 0x138,param_1 + 0x46,uVar4);
  func_0x(param_1);
  if (*(char *)(param_3 + 0x201) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  (*_DAT_)(param_1[10],*(undefined8 *)(param_1[9] + 0x1c0),
                   *(longlong *)(param_1[10] + 0x1a8) + 0x138,param_1 + 0x47);
  (*_DAT_)(param_1[10],*(undefined8 *)(param_1[9] + 0x1c8),
                   *(longlong *)(param_1[10] + 0x1a8) + 0x138,param_1 + 0x48);
  *(undefined4 *)(param_1 + 0x4a) = 0;
  param_1[0x4b] = 0;
  *(undefined4 *)(param_1 + 0x45) = 1;
  if (*(short *)(*(longlong *)(param_1[10] + 0x1a8) + 0x238) != 0) {
    uVar1 = param_1[9];
    lVar2 = *(longlong *)(*(longlong *)(*(longlong *)(param_1[10] + 0x1a8) + 0x230) + 0x280);
    lVar2 = *(longlong *)
             (*(longlong *)(lVar2 + 0x10) +
             ((ulonglong)(uint)((int)(uVar1 >> 4) + (int)uVar1) % (ulonglong)*(uint *)(lVar2 + 8)) *
             8);
    if (lVar2 != 0) {
      if (*(ulonglong *)(lVar2 + 8) != uVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar3 = *(undefined8 *)(lVar2 + 0x10);
    }
    param_1[0x50] = uVar3;
    return param_1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

