
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,byte *param_2)

{
  byte bVar1;
  code *UNRECOVERED_JUMPTABLE;
  undefined auStack_258 [80];
  undefined4 uStack_208;
  undefined2 uStack_200;
  undefined4 uStack_1fc;
  byte *pbStack_1f8;
  undefined8 uStack_1f0;
  undefined8 uStack_1e2;
  undefined2 uStack_1da;
  undefined2 uStack_1d8;
  undefined6 uStack_1d6;
  ushort uStack_1c2;
  undefined8 uStack_1b8;
  undefined8 uStack_c0;
  ulonglong uStack_38;
  
  uStack_c0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_258;
  uStack_1fc = 0;
  uStack_1e2 = 0;
  uStack_1d8 = 0;
  uStack_1d6 = 0;
  uStack_1f0 = 0;
  uStack_208 = 0;
  uStack_1c2 = uStack_1c2 & 0xffe0;
  bVar1 = *param_2;
  pbStack_1f8 = param_2;
  uStack_1b8 = param_1;
  if ((bVar1 & 1) != 0) {
    uStack_200 = 1;
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(bVar1 & 0x1c) + 0x10c56c) * 4 +
                           0x10c55c) - 0x1325ca0);
                    /* WARNING: Could not emulate address calculation at 0x001000a6 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
  uStack_200 = 0;
  uStack_1da = 0;
  uStack_1d8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010021c */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(bVar1 & 0xe) * 4 + 0x10c58c) - 0x1325ca0))();
  return;
}

