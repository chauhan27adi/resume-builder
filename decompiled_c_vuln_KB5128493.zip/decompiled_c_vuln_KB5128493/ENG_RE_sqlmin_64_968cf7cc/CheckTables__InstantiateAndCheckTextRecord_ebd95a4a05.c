
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,byte param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  short sVar3;
  undefined4 uVar4;
  ushort uVar5;
  ulonglong *puVar6;
  ulonglong uVar7;
  longlong lVar8;
  bool bVar9;
  ushort uVar10;
  int iVar11;
  longlong lVar12;
  byte *pbVar13;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar14;
  uint uVar15;
  ulonglong uVar16;
  ushort *puVar17;
  byte bVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  ushort *puVar22;
  longlong unaff_GS_OFFSET;
  undefined auStack_198 [32];
  undefined8 uStack_178;
  undefined8 *puStack_170;
  ulonglong uStack_168;
  undefined8 uStack_160;
  undefined4 uStack_158;
  undefined4 uStack_150;
  int iStack_148;
  undefined4 uStack_140;
  uint *puStack_138;
  undefined4 uStack_130;
  undefined8 *puStack_128;
  undefined4 uStack_120;
  undefined8 uStack_118;
  undefined2 uStack_110;
  undefined4 uStack_108;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  undefined2 uStack_f0;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  byte *pbStack_d8;
  undefined2 uStack_d0;
  undefined2 uStack_ce;
  undefined8 uStack_c8;
  longlong lStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 auStack_88 [8];
  ulonglong uStack_48;
  
  uStack_b0 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_198;
  bVar9 = false;
  sVar3 = *(short *)(param_2 + 0xa0);
  pbStack_d8 = *(byte **)(param_2 + 0xa8);
  uVar20 = 1;
  uVar19 = 0;
  if (sVar3 == 0) {
    uVar15 = (uint)*pbStack_d8;
    bVar18 = *pbStack_d8 & 0xe;
    if (bVar18 == 2) {
      uVar14 = (uint)((pbStack_d8[1] & 1) != 0);
    }
    else {
      uVar14 = uVar19;
      if (((bVar18 - 10 & 0xf9) == 0) && (bVar18 != 0x10)) {
        uVar14 = uVar20;
      }
    }
  }
  else {
    uVar15 = (uint)*pbStack_d8;
    uVar14 = (uint)(((uVar15 & 0x1c) - 4 & 0xffffffe7) == 0);
  }
  uVar21 = 9;
  bVar18 = (byte)uVar15;
  uStack_c8 = param_1;
  if (uVar14 == 0) {
    if ((sVar3 != 0) || ((bVar18 & 0xe) != 8)) goto LAB_;
LAB_:
    uVar14 = *(uint *)(param_2 + 0xb0);
    if ((bVar18 & 0xe) != 0xe) {
LAB_:
      if (uVar14 < 0xe) {
        if (sVar3 == 0) {
          uVar20 = *(uint *)(param_2 + 0xb0);
        }
        else {
          bVar18 = **(byte **)(param_2 + 0xa8) & 0x1c;
          if ((bVar18 != 4) && (uVar20 = uVar21, bVar18 != 0x10)) {
            uVar20 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
          }
        }
        pbStack_d8 = *(byte **)(param_2 + 0x154);
        uStack_d0 = *(undefined2 *)(param_2 + 0x15c);
        uStack_ce = *(undefined2 *)(param_2 + 0x15e);
        puStack_170 = (undefined8 *)(ulonglong)uVar20;
        uStack_168 = 0xe;
        uStack_178 = (undefined4 *)CONCAT44(uStack_178._4_4_,8);
        func_0x(&pbStack_d8,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,0xe5c130);
      }
      else {
        uStack_a8 = *(ushort *)(pbStack_d8 + 0xc) & 0xf;
        if (((uStack_a8 < 2) ||
            (uVar10 = *(ushort *)(pbStack_d8 + 0xc) & 0xf, (ushort)(uVar10 - 3) < 4)) ||
           (uVar10 == 8)) {
          bVar9 = true;
        }
        if ((param_3 == 3) == bVar9) {
          if (uStack_a8 < 9) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)*(uint *)((longlong)(int)uStack_a8 * 4 + 0x101eac) - 0x19c2a20)
            ;
                    /* WARNING: Could not emulate address calculation at 0x001011bf */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          auStack_88[0] = *(undefined8 *)(pbStack_d8 + 4);
          lVar8 = func_0x();
          uStack_c8 = CONCAT44(uStack_c8._4_4_,*(undefined4 *)(lVar8 + 0x68));
          uStack_e8 = 0;
          uStack_e0 = 0;
          uVar4 = *(undefined4 *)(param_2 + 0xd4);
          lVar8 = *(longlong *)(*(longlong *)(param_1 + 0x168) + 8);
          LOCK();
          piVar1 = (int *)(lVar8 + 8);
          iStack_148 = *piVar1;
          *piVar1 = *piVar1 + 1;
          UNLOCK();
          iStack_148 = iStack_148 + 1;
          uStack_f0 = 0;
          uStack_f8 = 0;
          uStack_100 = 0;
          uStack_108 = 0;
          uStack_110 = 1;
          uStack_118 = 0;
          uStack_120 = 0;
          puStack_128 = auStack_88;
          uStack_130 = 1;
          puStack_138 = &uStack_a8;
          uStack_140 = 1;
          uStack_150 = 1;
          uStack_158 = 0x10;
          uStack_160 = CONCAT44(uStack_160._4_4_,0x2302);
          uStack_168 = uStack_168 & 0xffffffff00000000;
          puStack_170 = &uStack_e8;
          uStack_178 = (undefined4 *)(param_2 + 0x60);
          func_0x(lVar8,&uStack_c8,param_2 + 0x154,uVar4);
          func_0x(param_1,2,(undefined4 *)(param_2 + 0x60));
        }
        else {
          auStack_88[0] = *(undefined8 *)(pbStack_d8 + 4);
          uStack_a4 = (uint)param_3;
          lVar8 = func_0x();
          uStack_c8 = CONCAT44(uStack_c8._4_4_,*(undefined4 *)(lVar8 + 0x68));
          uStack_e8 = 0;
          uStack_e0 = 0;
          uVar4 = *(undefined4 *)(param_2 + 0xd4);
          lVar8 = *(longlong *)(*(longlong *)(param_1 + 0x168) + 8);
          LOCK();
          piVar1 = (int *)(lVar8 + 8);
          iStack_148 = *piVar1;
          *piVar1 = *piVar1 + 1;
          UNLOCK();
          iStack_148 = iStack_148 + 1;
          puVar2 = (undefined4 *)(param_2 + 0x60);
          uStack_f0 = 0;
          uStack_f8 = 0;
          uStack_100 = 0;
          uStack_108 = 0;
          uStack_110 = 1;
          uStack_118 = 0;
          uStack_120 = 0;
          puStack_128 = auStack_88;
          uStack_130 = 1;
          puStack_138 = &uStack_a8;
          uStack_140 = 2;
          uStack_150 = 1;
          uStack_158 = 0x10;
          uStack_160 = CONCAT44(uStack_160._4_4_,0x2303);
          uStack_168 = uStack_168 & 0xffffffff00000000;
          puStack_170 = &uStack_e8;
          uStack_178 = puVar2;
          func_0x(lVar8,&uStack_c8,param_2 + 0x154,uVar4);
          pbStack_d8 = *(byte **)(pbStack_d8 + 4);
          if (*(longlong *)(param_1 + 0x2a8) != 0) {
            lVar8 = param_1 + 0x1f0;
            uStack_b8._0_4_ = 0;
            uStack_b8._4_4_ = 4;
            uStack_158 = 0;
            uStack_160 = 0;
            uStack_168 = 0;
            puStack_170 = (undefined8 *)((ulonglong)puStack_170 & 0xffffffff00000000);
            uStack_178 = (undefined4 *)0x0;
            lStack_c0 = lVar8;
            uStack_b8._0_4_ = func_0x(lVar8,4,0xffffffff);
            func_0x(*(undefined8 *)(param_1 + 0x2a8),&pbStack_d8,*puVar2);
            func_0x(lVar8,4);
            uStack_b8 = (ulonglong)uStack_b8._4_4_ << 0x20;
          }
          func_0x(param_1,2,puVar2);
        }
      }
      goto LAB_;
    }
  }
  else {
    if (sVar3 == 0) goto LAB_;
    uVar14 = uVar20;
    if (((bVar18 & 0x1c) != 4) || ((uVar15 & 2) == 0)) {
      if ((uVar15 & 0x1c) != 4) {
        if ((uVar15 & 0x1c) == 0x10) {
          uVar14 = 9;
        }
        else {
          uVar14 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
        }
      }
      goto LAB_;
    }
    if ((uVar15 & 0x1c) != 4) {
      if ((uVar15 & 0x1c) == 0x10) {
        uVar14 = 9;
      }
      else {
        uVar14 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
      }
    }
  }
  if (uVar14 == 1) goto LAB_;
  if (sVar3 == 0) {
    uVar20 = *(uint *)(param_2 + 0xb0);
    puVar17 = (ushort *)(param_2 + 0xa2);
    if (*(int *)(param_2 + 0xa4) == 0) {
      *puVar17 = 0;
      uVar14 = *(uint *)(param_2 + 0xb0);
      uVar16 = (ulonglong)uVar14;
      *(uint *)(param_2 + 0xb4) = uVar14;
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar18 = *pbVar13;
      if ((bVar18 & 0x10) != 0) {
        uVar14 = uVar14 + 2 + (*(ushort *)(pbVar13 + uVar16) + 7 >> 3);
        uVar16 = (ulonglong)uVar14;
        *(uint *)(param_2 + 0xb4) = uVar14;
        bVar18 = *pbVar13;
      }
      if ((bVar18 & 0x20) == 0) {
        *(int *)(param_2 + 0xa4) = (int)uVar16;
        *(undefined2 *)(param_2 + 0xbc) = 0;
        *(int *)(param_2 + 0xb8) = (int)uVar16;
      }
      else {
        puVar22 = (ushort *)(pbVar13 + uVar16);
        uVar10 = *puVar22;
        *(ushort *)(param_2 + 0xbc) = uVar10;
        if (uVar10 == 0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0 &&
              ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
               (*(char *)(lVar8 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd7a928,0xe9a5f8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),3);
          uVar16 = (ulonglong)*(uint *)(param_2 + 0xb4);
          uVar10 = *(ushort *)(param_2 + 0xbc);
        }
        uVar14 = (int)uVar16 + (uVar10 + 1) * 2;
        *(uint *)(param_2 + 0xb8) = uVar14;
        if (0x1f9e < uVar14) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd7a928,0xe9a5f8,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),4);
          uVar10 = *(ushort *)(param_2 + 0xbc);
          uVar14 = *(uint *)(param_2 + 0xb8);
        }
        uVar7 = (ulonglong)uVar10;
        uVar15 = puVar22[uVar7] & 0x7fff;
        *(uint *)(param_2 + 0xa4) = uVar15;
        if (uVar15 < uVar14) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0 &&
              ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
               (*(char *)(lVar8 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd7a928,0xe9a5f8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),4);
          uVar7 = (ulonglong)*(ushort *)(param_2 + 0xbc);
          uVar15 = *(uint *)(param_2 + 0xa4);
        }
        uVar16 = (ulonglong)uVar15;
        if ((short)puVar22[(ulonglong)((int)uVar7 - 1) + 1] < 0) {
          do {
            lVar8 = *(longlong *)(param_2 + 0xa8);
            lVar12 = (ulonglong)*(uint *)(param_2 + 0xb4) + lVar8;
            if ((int)uVar7 == 1) {
              uVar14 = *(uint *)(param_2 + 0xb8);
              uVar15 = uVar14;
LAB_:
              if ((*(ushort *)(lVar12 + uVar7 * 2) & 0x7fff) < uVar14) goto LAB_;
            }
            else {
              uVar14 = *(ushort *)(lVar12 + -2 + uVar7 * 2) & 0x7fff;
              uVar15 = *(uint *)(param_2 + 0xb8);
              if (uVar15 <= uVar14) goto LAB_;
LAB_:
              func_0x(lVar8,7);
              uVar15 = *(uint *)(param_2 + 0xb8);
              lVar8 = *(longlong *)(param_2 + 0xa8);
            }
            if ((uVar14 < uVar15) ||
               (uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4), *(uint *)(param_2 + 0xa4) < uVar14))
            goto LAB_;
            if (*(ushort *)((ulonglong)uVar14 + lVar8) == 5) {
              *puVar17 = *puVar17 | 2;
              *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
              *(short *)(param_2 + 0xca) = (short)uVar14;
              lVar8 = (ulonglong)(uVar14 & 0xffff) + *(longlong *)(param_2 + 0xa8);
              uVar10 = *(ushort *)(lVar8 + 2);
              uVar5 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
              if ((uVar10 >> 0xe & 1) != 0) {
                uVar5 = uVar10 & 0x3800 | uVar5;
              }
              *(ushort *)(param_2 + 0xcc) = uVar5;
              *(ushort *)(param_2 + 0xcc) = (uVar5 ^ *(ushort *)(lVar8 + 2)) & 0x7ff ^ uVar5;
              uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
              goto LAB_;
            }
            if (*(ushort *)((ulonglong)uVar14 + lVar8) < 0x400) goto LAB_;
            *puVar17 = *puVar17 | 1;
            uVar10 = *(short *)(param_2 + 0xbc) - 1;
            *(ushort *)(param_2 + 0xbc) = uVar10;
            if (uVar10 == 0) goto LAB_;
            uVar7 = (ulonglong)uVar10;
          } while ((short)puVar22[(ulonglong)(uVar10 - 1) + 1] < 0);
          pbVar13 = *(byte **)(param_2 + 0xa8);
        }
        else {
LAB_:
          pbVar13 = *(byte **)(param_2 + 0xa8);
        }
      }
      if ((*pbVar13 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0xc6) = 0;
      }
      else {
        *(int *)(param_2 + 0xc6) = (int)uVar16;
        *(int *)(param_2 + 0xa4) = (int)uVar16 + 0xe;
        puVar6 = (ulonglong *)func_0x(puVar17);
        uVar10 = (ushort)(*puVar6 >> 0x30);
        if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
          if ((uVar10 >> 0xe & 1) == 0) {
            uVar10 = uVar10 & 0xdfff;
          }
          else {
            uVar10 = uVar10 | 0x2000;
          }
        }
        uVar14 = uVar19;
        if (uVar10 == 0xfffc) {
          uVar14 = (uint)((*puVar6 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + uVar14;
        uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
      iVar11 = (int)uVar16;
      if ((*(byte **)(param_2 + 0xbe) != (byte *)0x0) &&
         (*(byte **)(param_2 + 0xbe) < pbVar13 + uVar16)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar8 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar8 != 0 &&
             (lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0)) &&
            (*(char *)(lVar8 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_178 = (undefined4 *)0x0;
            (*_DAT_)(1,0xd7a928,0xe9a5f8,0x877);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
        iVar11 = *(int *)(param_2 + 0xa4);
      }
      if (0x3f3b < iVar11 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar8 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar8 != 0 &&
            ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_178 = (undefined4 *)0x0;
            (*_DAT_)(1,0xd7a928,0xe9a5f8,0x87c);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 0xa8),5);
      }
    }
LAB_:
    uVar14 = *(uint *)(param_2 + 0xa4);
    uVar16 = (ulonglong)uVar14;
    if (uVar14 < 9) {
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar18 = *pbVar13;
      if (((bVar18 & 0xe) != 0) && ((bVar18 & 0xe) != 0xc)) goto LAB_;
      uVar14 = 9;
    }
    else {
LAB_:
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar18 = *pbVar13;
    }
    if ((bVar18 & 0x40) != 0) {
      uVar14 = *(uint *)(param_2 + 0xc6);
    }
  }
  else {
    if ((uVar15 & 0x1c) != 4) {
      if ((uVar15 & 0x1c) == 0x10) {
        uVar20 = 9;
      }
      else {
        uVar20 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
      }
    }
    uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
    if (*(uint *)(param_2 + 0xa4) == 0) {
      func_0x(param_2 + 0xa2);
      uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
      if (*(uint *)(param_2 + 0xa4) == 0) {
        func_0x(param_2 + 0xa2);
        uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
      }
    }
    if ((uint)uVar16 < 9) {
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar18 = *pbVar13;
      if (((bVar18 & 0x1c) != 0) && ((bVar18 & 0x1c) != 0xc)) goto LAB_;
      uVar7 = 9;
    }
    else {
LAB_:
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar18 = *pbVar13;
      uVar7 = uVar16;
    }
    uVar14 = (uint)uVar7;
    if ((bVar18 & 2) != 0) {
      uVar14 = *(uint *)(param_2 + 0xd0);
    }
  }
  puVar17 = (ushort *)(param_2 + 0xa2);
  if (uVar20 == uVar14) goto LAB_;
  if (*(short *)(param_2 + 0xa0) == 0) {
    if ((int)uVar16 == 0) {
      *puVar17 = 0;
      uVar20 = *(uint *)(param_2 + 0xb0);
      uVar16 = (ulonglong)uVar20;
      *(uint *)(param_2 + 0xb4) = uVar20;
      if ((*pbVar13 & 0x10) != 0) {
        uVar20 = uVar20 + 2 + (*(ushort *)(pbVar13 + uVar16) + 7 >> 3);
        uVar16 = (ulonglong)uVar20;
        *(uint *)(param_2 + 0xb4) = uVar20;
      }
      if ((*pbVar13 & 0x20) == 0) {
        *(int *)(param_2 + 0xa4) = (int)uVar16;
        *(undefined2 *)(param_2 + 0xbc) = 0;
        *(int *)(param_2 + 0xb8) = (int)uVar16;
      }
      else {
        puVar22 = (ushort *)(pbVar13 + uVar16);
        uVar10 = *puVar22;
        *(ushort *)(param_2 + 0xbc) = uVar10;
        if (uVar10 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd7a928,0xe9a5f8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),3);
          uVar16 = (ulonglong)*(uint *)(param_2 + 0xb4);
          uVar10 = *(ushort *)(param_2 + 0xbc);
        }
        uVar20 = (int)uVar16 + (uVar10 + 1) * 2;
        *(uint *)(param_2 + 0xb8) = uVar20;
        if (0x1f9e < uVar20) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0 &&
              ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
               (*(char *)(lVar8 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd7a928,0xe9a5f8,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),4);
          uVar10 = *(ushort *)(param_2 + 0xbc);
          uVar20 = *(uint *)(param_2 + 0xb8);
        }
        uVar7 = (ulonglong)uVar10;
        uVar14 = puVar22[uVar7] & 0x7fff;
        *(uint *)(param_2 + 0xa4) = uVar14;
        if (uVar14 < uVar20) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd7a928,0xe9a5f8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),4);
          uVar7 = (ulonglong)*(ushort *)(param_2 + 0xbc);
          uVar14 = *(uint *)(param_2 + 0xa4);
        }
        uVar16 = (ulonglong)uVar14;
        if ((short)puVar22[(ulonglong)((int)uVar7 - 1) + 1] < 0) {
          do {
            pbVar13 = *(byte **)(param_2 + 0xa8);
            if ((int)uVar7 == 1) {
              uVar20 = *(uint *)(param_2 + 0xb8);
              uVar14 = uVar20;
LAB_:
              if ((*(ushort *)(pbVar13 + uVar7 * 2 + (ulonglong)*(uint *)(param_2 + 0xb4)) & 0x7fff)
                  < uVar20) goto LAB_;
            }
            else {
              uVar20 = *(ushort *)(pbVar13 + uVar7 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2))
                       & 0x7fff;
              uVar14 = *(uint *)(param_2 + 0xb8);
              if (uVar14 <= uVar20) goto LAB_;
LAB_:
              func_0x(pbVar13,7);
              uVar14 = *(uint *)(param_2 + 0xb8);
              pbVar13 = *(byte **)(param_2 + 0xa8);
            }
            if ((uVar20 < uVar14) ||
               (uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4), *(uint *)(param_2 + 0xa4) < uVar20))
            goto LAB_;
            if (*(ushort *)(pbVar13 + uVar20) == 5) {
              *puVar17 = *puVar17 | 2;
              *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
              *(short *)(param_2 + 0xca) = (short)uVar20;
              lVar8 = (ulonglong)(uVar20 & 0xffff) + *(longlong *)(param_2 + 0xa8);
              uVar10 = *(ushort *)(lVar8 + 2);
              uVar5 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
              if ((uVar10 >> 0xe & 1) != 0) {
                uVar5 = uVar10 & 0x3800 | uVar5;
              }
              *(ushort *)(param_2 + 0xcc) = uVar5;
              *(ushort *)(param_2 + 0xcc) = (uVar5 ^ *(ushort *)(lVar8 + 2)) & 0x7ff ^ uVar5;
              uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
              goto LAB_;
            }
            if (*(ushort *)(pbVar13 + uVar20) < 0x400) goto LAB_;
            *puVar17 = *puVar17 | 1;
            uVar10 = *(short *)(param_2 + 0xbc) - 1;
            *(ushort *)(param_2 + 0xbc) = uVar10;
            if (uVar10 == 0) goto LAB_;
            uVar7 = (ulonglong)uVar10;
          } while ((short)puVar22[(ulonglong)(uVar10 - 1) + 1] < 0);
          pbVar13 = *(byte **)(param_2 + 0xa8);
        }
        else {
LAB_:
          pbVar13 = *(byte **)(param_2 + 0xa8);
        }
      }
      if ((*pbVar13 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0xc6) = 0;
      }
      else {
        *(int *)(param_2 + 0xc6) = (int)uVar16;
        *(int *)(param_2 + 0xa4) = (int)uVar16 + 0xe;
        puVar6 = (ulonglong *)func_0x(puVar17);
        uVar10 = (ushort)(*puVar6 >> 0x30);
        if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
          if ((uVar10 >> 0xe & 1) == 0) {
            uVar10 = uVar10 & 0xdfff;
          }
          else {
            uVar10 = uVar10 | 0x2000;
          }
        }
        if (uVar10 == 0xfffc) {
          uVar19 = (uint)((*puVar6 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + uVar19;
        uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
      uVar20 = (uint)uVar16;
      if ((*(byte **)(param_2 + 0xbe) != (byte *)0x0) &&
         (*(byte **)(param_2 + 0xbe) < pbVar13 + uVar16)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar8 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar8 != 0 &&
             (lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0)) &&
            (*(char *)(lVar8 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_178 = (undefined4 *)0x0;
            (*_DAT_)(1,0xd7a928,0xe9a5f8,0x877);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
        uVar20 = *(uint *)(param_2 + 0xa4);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
      if ((uVar20 == 0) || (0x3f3c < uVar20)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar8 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar8 != 0 &&
             (lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0)) &&
            (*(char *)(lVar8 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_178 = (undefined4 *)0x0;
            (*_DAT_)(1,0xd7a928,0xe9a5f8,0x87c);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 0xa8),5);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
    }
LAB_:
    uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
    if (*(uint *)(param_2 + 0xa4) < 9) {
      bVar18 = *pbVar13;
      if (((bVar18 & 0xe) != 0) && ((bVar18 & 0xe) != 0xc)) goto LAB_;
      uVar16 = 9;
    }
    else {
LAB_:
      bVar18 = *pbVar13;
    }
    if ((bVar18 & 0x40) != 0) {
      uVar16 = (ulonglong)*(uint *)(param_2 + 0xc6);
    }
  }
  else {
    if ((int)uVar16 == 0) {
      func_0x(puVar17);
      uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
      pbVar13 = *(byte **)(param_2 + 0xa8);
      if (*(uint *)(param_2 + 0xa4) == 0) {
        func_0x(puVar17);
        uVar16 = (ulonglong)*(uint *)(param_2 + 0xa4);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
    }
    if (((uint)uVar16 < 9) && (((*pbVar13 & 0x1c) == 0 || ((*pbVar13 & 0x1c) == 0xc)))) {
      uVar16 = 9;
    }
    if ((*pbVar13 & 2) != 0) {
      uVar16 = (ulonglong)*(uint *)(param_2 + 0xd0);
    }
  }
  if (*(short *)(param_2 + 0xa0) == 0) {
    uVar21 = *(uint *)(param_2 + 0xb0);
  }
  else if ((*pbVar13 & 0x1c) == 4) {
    uVar21 = 1;
  }
  else if ((*pbVar13 & 0x1c) != 0x10) {
    uVar21 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
  }
  pbStack_d8 = *(byte **)(param_2 + 0x154);
  uStack_d0 = *(undefined2 *)(param_2 + 0x15c);
  uStack_ce = *(undefined2 *)(param_2 + 0x15e);
  puStack_170 = (undefined8 *)(ulonglong)uVar21;
  uStack_178 = (undefined4 *)CONCAT44(uStack_178._4_4_,7);
  uStack_168 = uVar16;
  func_0x(&pbStack_d8,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,0xe5c080);
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_198);
  return;
}

