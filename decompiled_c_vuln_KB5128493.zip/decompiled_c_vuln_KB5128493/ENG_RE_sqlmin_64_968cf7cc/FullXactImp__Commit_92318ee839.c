
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(void)

{
  longlong lVar1;
  undefined8 unaff_RBX;
  undefined8 unaff_RSI;
  
  lVar1 = func_0x();
  lVar1 = -lVar1;
  *(undefined8 *)(&stack0x00000058 + lVar1) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000010c0 + lVar1) = unaff_RBX;
  *(undefined8 *)(&stack0x000010d0 + lVar1) = unaff_RSI;
  *(ulonglong *)(&stack0x00001078 + lVar1) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffd8 + lVar1);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

