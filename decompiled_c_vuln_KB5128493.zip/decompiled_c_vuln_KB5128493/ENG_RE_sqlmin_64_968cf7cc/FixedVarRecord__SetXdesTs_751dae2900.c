// NOTE: 2 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1)

{
  if (*(int *)(param_1 + 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

