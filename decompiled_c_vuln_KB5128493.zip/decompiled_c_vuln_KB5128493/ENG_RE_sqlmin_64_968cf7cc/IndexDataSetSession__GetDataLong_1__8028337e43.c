
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 *param_2,longlong param_3,undefined4 *param_4)

{
  undefined *puVar1;
  byte *pbVar2;
  undefined8 uVar3;
  code *pcVar4;
  uint uVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  uint uVar9;
  ulonglong uVar10;
  undefined *puVar11;
  ulonglong uVar12;
  longlong lStackX_8;
  undefined4 auStackX_10 [2];
  longlong lStackX_18;
  undefined4 uStackX_20;
  undefined auStackX_24 [4];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar6 = func_0x();
  lVar6 = -lVar6;
  puVar11 = &stack0xffffffffffffffc0 + lVar6;
  puVar1 = &stack0xfffffffffffffff0 + lVar6;
  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar6) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00001fd0 + lVar6) = _DAT_ ^ (ulonglong)puVar1;
  uVar10 = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar6 + -0x20) = 0;
  *(undefined8 *)((longlong)&lStackX_8 + lVar6) = 0;
  *(undefined4 *)((longlong)auStackX_10 + lVar6) = 0;
  *(undefined8 *)((longlong)&lStackX_18 + lVar6) = 0;
  *(undefined4 *)((longlong)&uStackX_20 + lVar6) = 0;
  lVar8 = *(longlong *)(param_3 + 8);
  uVar12 = uVar10;
  if ((*(byte *)(lVar8 + 0x38) & 8) != 0) {
    uVar12 = (longlong)&uStackX_20 + lVar6 + -0x20;
    *(uint *)((longlong)&uStackX_20 + lVar6 + -0x20) = (uint)*(ushort *)(lVar8 + 0x62);
    *(undefined4 *)((longlong)&uStackX_20 + lVar6) = 0x1f9e;
    *(undefined **)((longlong)&lStackX_18 + lVar6) = auStackX_24 + lVar6;
    *(undefined8 *)((longlong)&uStack_48 + lVar6) = 0x1000a4;
    lVar7 = func_0x();
    lVar7 = -lVar7;
    puVar11 = &stack0xffffffffffffffc0 + lVar7 + lVar6;
    *(undefined **)((longlong)&lStackX_8 + lVar6) = &stack0xfffffffffffffff0 + lVar7 + lVar6;
    *(undefined8 *)((longlong)&uStack_48 + lVar7 + lVar6) = 0x1000b7;
    func_0x(&stack0xfffffffffffffff0 + lVar7 + lVar6,0);
  }
  *(undefined8 *)(param_1 + 0x3a0) = 0;
  *(undefined8 **)(param_1 + 0x3a8) = param_2;
  if ((*(ushort *)(lVar8 + 0x38) & 0x1000) != 0) {
    if ((*(byte *)(param_1 + 0x3ec) & 4) == 0) {
      uVar5 = **(uint **)(param_1 + 0x108);
      uVar9 = **(uint **)(param_1 + 0x108);
      *(undefined8 *)(puVar11 + 0x28) = *(undefined8 *)(param_1 + 0x10);
      *(uint *)(puVar11 + 0x20) = ((int)uVar5 >> 0x1f & 1U) + 1;
      uVar3 = *(undefined8 *)(param_1 + 0x1e8);
      *(undefined8 *)(puVar11 + -8) = 0x100122;
      func_0x
                (param_1 + 0x3b8,uVar3,param_1 + 0x398,((uVar9 & 0x4000000) != 0) + '\x01');
    }
    *(longlong *)(param_1 + 0x3f0) = param_1 + 0x2b8;
  }
  *(undefined8 *)(puVar11 + 0x28) = *(undefined8 *)(*(longlong *)(param_1 + 0x108) + 0x130);
  *(undefined4 **)(puVar11 + 0x20) = param_4;
  *(undefined8 *)(puVar11 + -8) = 0x10015e;
  func_0x(param_1 + 0x3b8,param_3,uVar12,puVar1);
  if (*(short *)(lVar8 + 0x3a) != 0) {
    if ((*(byte *)(lVar8 + 0x38) & 8) != 0) {
      *(undefined8 *)(param_1 + 0x3a0) = 0;
      *(undefined8 **)(param_1 + 0x3a8) = param_2;
      *(longlong *)(puVar11 + 0x28) = param_3;
      *(undefined8 *)(puVar11 + 0x20) = *(undefined8 *)(param_1 + 0x1e8);
      *(undefined8 *)(puVar11 + -8) = 0x10019a;
      func_0x();
      *param_4 = 0;
    }
    if ((*(longlong *)(*(longlong *)(param_1 + 0x108) + 0x130) != 0) &&
       (*(short *)(*(longlong *)(param_3 + 8) + 0x62) != 0)) {
      pcVar4 = *(code **)*param_2;
      *(undefined8 *)(puVar11 + -8) = 0x100229;
      (*pcVar4)(param_2);
      *(undefined8 *)(puVar11 + -8) = 0x10022e;
      func_0x();
      pcVar4 = (code *)swi(3);
      (*pcVar4)();
      return;
    }
  }
  lVar8 = *(longlong *)((longlong)&lStackX_8 + lVar6);
  if ((lVar8 != 0) && (uVar5 = *(uint *)((longlong)&uStackX_20 + lVar6 + -0x20), uVar5 != 0)) {
    do {
      lVar7 = uVar10 * 0x40;
      if ((*(byte *)(lVar7 + 0x18 + lVar8) & 4) != 0) {
        uVar3 = *(undefined8 *)(lVar7 + 0x20 + lVar8);
        *(undefined8 *)(puVar11 + -8) = 0x1001e8;
        (*_DAT_)(uVar3);
        pbVar2 = (byte *)(lVar7 + 0x18 + *(longlong *)((longlong)&lStackX_8 + lVar6));
        *pbVar2 = *pbVar2 & 0xfb;
        lVar8 = *(longlong *)((longlong)&lStackX_8 + lVar6);
        uVar5 = *(uint *)((longlong)&uStackX_20 + lVar6 + -0x20);
      }
      uVar9 = (int)uVar10 + 1;
      uVar10 = (ulonglong)uVar9;
    } while (uVar9 < uVar5);
  }
  uVar12 = *(ulonglong *)(&stack0x00001fd0 + lVar6);
  *(undefined8 *)(puVar11 + -8) = 0x10020d;
  func_0x(uVar12 ^ (ulonglong)puVar1);
  return;
}

