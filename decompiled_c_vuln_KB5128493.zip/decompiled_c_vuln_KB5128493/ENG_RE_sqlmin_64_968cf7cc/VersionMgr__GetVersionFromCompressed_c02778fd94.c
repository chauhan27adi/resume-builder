
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,longlong param_2,undefined4 param_3,undefined8 *param_4,
                 longlong *param_5,undefined8 *param_6,int *param_7,undefined param_8,
                 undefined8 param_9,longlong param_10,undefined8 param_11,undefined8 param_12)

{
  longlong lVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int *piVar9;
  byte *pbVar10;
  char cVar11;
  short sVar12;
  int iVar13;
  undefined8 uVar14;
  longlong *plVar15;
  longlong lVar16;
  ulonglong *puVar17;
  short *psVar18;
  ulonglong uVar19;
  ushort uVar20;
  ushort uVar21;
  uint uVar22;
  undefined *puVar23;
  uint uVar24;
  longlong *plVar25;
  ulonglong uVar26;
  ushort *puVar27;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_280;
  undefined auStack_278 [32];
  undefined8 uStack_258;
  undefined *puStack_250;
  undefined8 uStack_248;
  undefined8 *puStack_240;
  uint uStack_238;
  longlong lStack_230;
  undefined8 uStack_228;
  undefined8 uStack_220;
  uint6 uStack_218;
  ushort uStack_212;
  undefined8 uStack_210;
  longlong *plStack_208;
  undefined uStack_200;
  undefined auStack_1ff [7];
  longlong lStack_1f8;
  undefined4 uStack_1f0;
  short *psStack_1e8;
  undefined8 uStack_1e0;
  undefined8 uStack_1d8;
  int *piStack_1d0;
  longlong lStack_1c8;
  undefined8 uStack_1c0;
  undefined8 uStack_1b8;
  undefined auStack_1a8 [96];
  short sStack_148;
  ushort uStack_146;
  uint uStack_144;
  byte *pbStack_140;
  undefined8 uStack_138;
  uint uStack_130;
  ushort uStack_12c;
  byte *pbStack_12a;
  undefined2 uStack_122;
  undefined2 uStack_120;
  undefined2 uStack_11e;
  ushort uStack_11c;
  undefined2 uStack_11a;
  undefined4 uStack_114;
  short sStack_98;
  ushort uStack_96;
  uint uStack_94;
  longlong lStack_90;
  longlong *plStack_88;
  uint uStack_80;
  ushort uStack_7c;
  undefined8 uStack_7a;
  undefined2 uStack_72;
  undefined2 uStack_70;
  undefined2 uStack_6e;
  ushort uStack_6c;
  undefined2 uStack_6a;
  longlong lStack_60;
  undefined4 uStack_58;
  ulonglong uStack_50;
  
  uStack_1b8 = 0xfffffffffffffffe;
  uStack_50 = _DAT_ ^ (ulonglong)&uStack_218;
  plStack_208 = param_5;
  piStack_1d0 = param_7;
  uStack_1c0 = param_9;
  lStack_1f8 = param_10;
  uStack_1d8 = param_11;
  uStack_1e0 = param_12;
  sStack_148 = -1;
  plVar15 = (longlong *)0x0;
  pbStack_140 = (byte *)0x0;
  uVar22 = 0;
  uStack_144 = 0;
  pbStack_12a = (byte *)0x0;
  uStack_120 = 0;
  uStack_11e = 0;
  uStack_11c = 0;
  uStack_11a = 0;
  uStack_138 = (longlong *)0x0;
  uStack_114 = 0xffffffff;
  sStack_98 = -1;
  lStack_90 = 0;
  uStack_94 = 0;
  uStack_7a = 0;
  uStack_70 = 0;
  uStack_6e = 0;
  uStack_6c = 0;
  uStack_6a = 0;
  plStack_88 = (longlong *)0x0;
  lStack_60 = 0;
  uStack_58 = 0;
  uStack_210 = 0;
  uStack_1f0 = param_3;
  psStack_1e8 = param_1;
  lStack_1c8 = param_2;
  if (*param_1 == 0) {
    uStack_280 = 0x100113;
    func_0x(param_1 + 1);
  }
  else {
    uStack_280 = 0x10011e;
    func_0x(param_1 + 1,&uStack_218);
  }
  uVar21 = uStack_212;
  if ((((uint)(int)(short)uStack_212 >> 1 ^ (int)(short)uStack_212) & 0x2000) != 0) {
    uVar21 = uStack_212 & 0xdfff;
    if ((uStack_212 >> 0xe & 1) != 0) {
      uVar21 = uStack_212 | 0x2000;
    }
  }
  puVar23 = auStack_278;
  if (uVar21 == 0xfffc) {
    if (*param_1 == 0) {
      uStack_280 = 0x100171;
      func_0x();
    }
    else {
      uStack_280 = 0x100178;
      func_0x(param_1 + 1,&uStack_218);
    }
    uStack_280 = 0x100181;
    sVar12 = func_0x(&uStack_218);
    puVar23 = auStack_278;
    if (sVar12 != 3) {
      lVar1 = param_4[0x1a];
      if (*(short *)param_6 == 0) {
        uStack_280 = 0x1001a5;
        func_0x();
      }
      else {
        uStack_280 = 0x1001ac;
        func_0x((longlong)param_6 + 2,&uStack_218);
      }
      *piStack_1d0 = 1;
      plVar25 = plVar15;
      if (lStack_1f8 == 0) {
        lVar16 = param_4[0x1a];
        uStack_280 = 0x1001d5;
        cVar11 = (**(code **)*param_4)(param_4);
        param_5 = plStack_208;
        if (cVar11 != '\0') goto LAB_;
        uVar24 = *(uint *)(plStack_208 + 2);
        if ((uVar24 & 8) == 0) {
          if (plStack_208[1] == 0) {
            if ((uVar24 & 0x10) == 0) {
              if (-1 < (char)uVar24) goto LAB_;
              goto LAB_;
            }
            plVar25 = *(longlong **)(*plStack_208 + 0x38);
          }
          else {
            plVar25 = *(longlong **)(plStack_208[1] + 0x38);
          }
        }
        else {
LAB_:
          plVar25 = (longlong *)(lVar16 + 0xa8);
        }
        if (plVar25 == (longlong *)0x0) goto LAB_;
      }
      else {
LAB_:
        if ((*(char *)(param_4[6] + 0x1cde) == '\0') && (puVar23 = auStack_278, lStack_1f8 == 0))
        goto LAB_;
      }
      uStack_220 = uStack_1e0;
      uStack_228 = uStack_1d8;
      lStack_230 = lStack_1f8;
      puStack_240 = param_6;
      uStack_248 = CONCAT71(uStack_248._1_7_,param_8);
      puStack_250 = &uStack_200;
      uStack_258 = auStack_1ff;
      uStack_280 = 0x100282;
      cVar11 = func_0x(param_4,param_5,plVar25,&uStack_218);
      param_1 = psStack_1e8;
      if (cVar11 != '\0') {
        puVar23 = auStack_278;
        if (((lVar1 == 0) || (puVar23 = auStack_278, *(char *)(lVar1 + 0x34) == '\0')) ||
           (puVar23 = auStack_278, *(longlong *)(lVar1 + 0x40) == 0)) goto LAB_;
        if ((DAT_ & 8) == 0) {
          lVar16 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
          puVar23 = auStack_278;
          if ((lVar16 == 0) ||
             (lVar16 = **(longlong **)(lVar16 + 0x38), puVar23 = auStack_278, lVar16 == 0))
          goto LAB_;
          uStack_280 = 0x1002f6;
          iVar13 = (*_DAT_)(lVar16,0xf73);
          puVar23 = auStack_278;
          if (iVar13 == 0) goto LAB_;
        }
        uVar24 = uVar22;
        if (plVar25 != (longlong *)0x0) {
          uVar24 = *(uint *)(plVar25 + 4);
        }
        uVar21 = *(ushort *)(param_4[6] + 0x6b8);
        if (*(short *)param_6 == 0) {
          uStack_280 = 0x100339;
          func_0x();
        }
        else {
          uStack_280 = 0x100340;
          func_0x((longlong)param_6 + 2,&uStack_210);
        }
        uVar20 = uStack_210._6_2_;
        if ((((uint)(int)(short)uStack_210._6_2_ >> 1 ^ (int)(short)uStack_210._6_2_) & 0x2000) != 0
           ) {
          uVar20 = uStack_210._6_2_ & 0xdfff;
          if ((uStack_210._6_2_ >> 0xe & 1) != 0) {
            uVar20 = uStack_210._6_2_ | 0x2000;
          }
        }
        if (uVar20 == 0xfffc) {
          uVar22 = (uint)(uStack_210._4_2_ >> 5);
        }
        puStack_240 = *(undefined8 **)(lVar1 + 0x40);
        uStack_248 = *(undefined8 *)(lVar1 + 0xf8);
        puStack_250 = (undefined *)plStack_208[5];
        uStack_258 = (undefined *)CONCAT44(uStack_258._4_4_,(uint)uVar21);
        uStack_280 = 0x1003ce;
        uStack_238 = uVar24;
        func_0x(0xf55e70,0xf55c80,uVar22 + 0xe,(ulonglong)uStack_218);
        uStack_280 = 0x1003d8;
        (*_DAT_)(auStack_1a8);
        uStack_280 = 0x1003df;
        uVar14 = (*_DAT_)();
        uStack_280 = 0x1003f0;
        lStack_1c8 = (*_DAT_)(uVar14,0,0x6c0);
        if (lStack_1c8 != 0) {
          uStack_280 = 0x100403;
          plVar15 = (longlong *)func_0x(lStack_1c8,0);
        }
        if (plVar15 != (longlong *)0x0) {
          uStack_280 = 0x100418;
          iVar13 = (*_DAT_)(auStack_1a8,plVar15);
          if (iVar13 == 0) {
            uStack_280 = 0x100429;
            (**(code **)*plVar15)(plVar15,1);
          }
        }
        uStack_280 = 0x100435;
        func_0x(param_6,auStack_1a8);
        uStack_280 = 0x100440;
        (*_DAT_)(auStack_1a8);
        puVar23 = auStack_278;
        goto LAB_;
      }
      uStack_280 = 0x100458;
      func_0x(&sStack_148,psStack_1e8);
      uVar19 = (ulonglong)pbStack_140 & 0xffffffffffffe000;
      puVar23 = auStack_278;
      param_5 = plStack_208;
      if ((*(char *)(uVar19 + 2) < '\0') && (puVar23 = auStack_278, lStack_60 == 0)) {
        uStack_280 = 0x100486;
        lVar16 = func_0x();
        lVar16 = -lVar16;
        lVar1 = (longlong)&uStack_218 + lVar16;
        uStack_210 = lVar1;
        lStack_60 = lVar1;
        uStack_58 = 0x1f9e;
        param_6[1] = 0;
        *param_6 = 0xffff;
        param_6[3] = 0;
        param_6[4] = 0;
        param_6[2] = 0;
        *(undefined4 *)(param_6 + 6) = 0;
        param_6[5] = 0;
        if (*(char *)(uVar19 + 2) < '\0') {
          sStack_98 = sStack_148;
          if (sStack_148 == 0) {
            uVar22 = uStack_144;
            uStack_80 = uStack_130;
            if (uStack_144 == 0) {
              uStack_146 = 0;
              uVar19 = (ulonglong)uStack_138 & 0xffffffff;
              uVar22 = (uint)uStack_138;
              if ((*pbStack_140 & 0x10) != 0) {
                uVar22 = (uint)uStack_138 + 2 + (*(ushort *)(pbStack_140 + uVar19) + 7 >> 3);
                uVar19 = (ulonglong)uVar22;
              }
              uStack_138 = (longlong *)CONCAT44(uVar22,(uint)uStack_138);
              uStack_130 = (uint)uVar19;
              if ((*pbStack_140 & 0x20) == 0) {
                uStack_12c = 0;
                uVar26 = uVar19;
                uStack_144 = uStack_130;
              }
              else {
                puVar27 = (ushort *)(pbStack_140 + uVar19);
                uStack_12c = *puVar27;
                if (uStack_12c == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar1 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar1 != 0)) &&
                     ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
                      (*(char *)(lVar1 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1005cd;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                      *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1005f3;
                      (*_DAT_)(1,0xeb33d8,0xfd30a8,0x80f);
                    }
                  }
                  pbVar10 = pbStack_140;
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100604;
                  func_0x(pbVar10,3);
                }
                uStack_130 = uStack_138._4_4_ + (uStack_12c + 1) * 2;
                if (0x1f9e < uStack_130) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar1 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar1 != 0 &&
                      ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
                       (*(char *)(lVar1 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1006a5;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                      *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1006cb;
                      (*_DAT_)(1,0xeb33d8,0xfd30a8,0x816);
                    }
                  }
                  pbVar10 = pbStack_140;
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1006dc;
                  func_0x(pbVar10,4);
                }
                uStack_144 = puVar27[uStack_12c] & 0x7fff;
                if (uStack_144 < uStack_130) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar1 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar1 != 0)) &&
                     ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
                      (*(char *)(lVar1 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10077c;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                      *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1007a2;
                      (*_DAT_)(1,0xeb33d8,0xfd30a8,0x81d);
                    }
                  }
                  pbVar10 = pbStack_140;
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1007b3;
                  func_0x(pbVar10,4);
                }
                uVar26 = (ulonglong)uStack_130;
                uVar19 = (ulonglong)uStack_144;
                do {
                  pbVar10 = pbStack_140;
                  if (-1 < (short)puVar27[(ulonglong)(uStack_12c - 1) + 1]) break;
                  uVar24 = (uint)uVar26;
                  if (((uStack_12c != 1) &&
                      (uVar24 = *(ushort *)
                                 (pbStack_140 +
                                 (ulonglong)uStack_12c * 2 + (((ulonglong)uStack_138 >> 0x20) - 2))
                                & 0x7fff, uVar24 < (uint)uVar26)) ||
                     ((*(ushort *)
                        (pbStack_140 + (ulonglong)uStack_12c * 2 + ((ulonglong)uStack_138 >> 0x20))
                      & 0x7fff) < uVar24)) {
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100830;
                    func_0x(pbVar10,7);
                    uVar26 = (ulonglong)uStack_130;
                    uVar19 = (ulonglong)uStack_144;
                  }
                  uVar22 = (uint)uVar19;
                  uStack_80 = (uint)uVar26;
                  if ((uVar24 < uStack_80) || (uVar22 < uVar24)) goto LAB_;
                  if (*(ushort *)(pbStack_140 + uVar24) == 5) {
                    uStack_146 = uStack_146 | 2;
                    uStack_12c = uStack_12c - 1;
                    uStack_11e = (undefined2)uVar24;
                    if ((*(ushort *)(pbStack_140 + (ulonglong)(uVar24 & 0xffff) + 2) & 0x4000) == 0)
                    {
                      uStack_11c = uStack_11c & 0xc7ff;
                    }
                    else {
                      uStack_11c = uStack_11c ^
                                   (*(ushort *)(pbStack_140 + (ulonglong)(uVar24 & 0xffff) + 2) ^
                                   uStack_11c) & 0x3800;
                    }
                    uStack_11c = (uStack_11c ^
                                 *(ushort *)(pbStack_140 + (ulonglong)(uVar24 & 0xffff) + 2)) &
                                 0x7ff ^ uStack_11c;
                    goto LAB_;
                  }
                  if (*(ushort *)(pbStack_140 + uVar24) < 0x400) break;
                  uStack_146 = uStack_146 | 1;
                  uStack_12c = uStack_12c - 1;
                } while (uStack_12c != 0);
              }
              uStack_80 = (uint)uVar26;
LAB_:
              if ((*pbStack_140 & 0x40) == 0) {
                uStack_122 = 0;
                uStack_120 = 0;
              }
              else {
                uStack_122 = (undefined2)uVar19;
                uStack_120 = (undefined2)(uVar19 >> 0x10);
                uStack_144 = (int)uVar19 + 0xe;
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100995;
                puVar17 = (ulonglong *)func_0x(&uStack_146);
                uVar19 = *puVar17;
                iVar13 = 0;
                uVar20 = (ushort)(uVar19 >> 0x30);
                uVar21 = uVar20;
                if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
                  uVar21 = uVar20 & 0xdfff;
                  if ((uVar19 & 0x4000000000000000) != 0) {
                    uVar21 = uVar20 | 0x2000;
                  }
                }
                if (uVar21 == 0xfffc) {
                  iVar13 = (int)((uVar19 >> 0x20 & 0xffff) >> 5);
                }
                uStack_144 = uStack_144 + iVar13;
                uVar19 = (ulonglong)uStack_144;
                uStack_80 = uStack_130;
              }
              uVar22 = (uint)uVar19;
              if ((pbStack_12a != (byte *)0x0) && (pbStack_12a < pbStack_140 + uVar19)) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar1 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                     lVar1 != 0 && (lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0)) &&
                    (*(char *)(lVar1 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100aa2;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100ac8;
                    (*_DAT_)(1,0xeb33d8,0xfd30a8,0x877);
                  }
                }
                pbVar10 = pbStack_140;
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100ad9;
                func_0x(pbVar10,0x12);
                uVar22 = uStack_144;
                uStack_80 = uStack_130;
              }
              if (0x3f3b < uVar22 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar1 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar1 != 0 &&
                    ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
                     (*(char *)(lVar1 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100b6c;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100b92;
                    (*_DAT_)(1,0xeb33d8,0xfd30a8,0x87c);
                  }
                }
                pbVar10 = pbStack_140;
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100ba3;
                func_0x(pbVar10,5);
                uVar22 = uStack_144;
                uStack_80 = uStack_130;
              }
            }
LAB_:
            pbVar10 = pbStack_140;
            lVar1 = uStack_210;
            uVar24 = uVar22;
            if ((uVar22 < 9) && (((*pbStack_140 & 0xe) == 0 || ((*pbStack_140 & 0xe) == 0xc)))) {
              uVar24 = 9;
            }
            uStack_96 = uStack_146;
            uStack_7c = uStack_12c;
            plStack_88 = uStack_138;
            uStack_72 = uStack_122;
            uStack_70 = uStack_120;
            uStack_94 = uVar22;
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100c33;
            func_0x(lVar1,0x1f9e,pbVar10,uVar24);
            lStack_90 = lVar1;
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100c46;
            iVar13 = func_0x(&uStack_96);
            lVar1 = lStack_90;
            param_1 = psStack_1e8;
            if (iVar13 != 0) {
              puVar27 = (ushort *)(((ulonglong)plStack_88 >> 0x20) + lStack_90);
              uVar22 = *puVar27 - 1;
              if ((uStack_96 & 1) == 0) {
                uVar22 = (uint)*puVar27;
              }
              uVar24 = uStack_80;
              if (((uVar22 != 1) &&
                  (uVar24 = puVar27[(longlong)(int)uVar22 + -1] & 0x7fff, uVar24 < uStack_80)) ||
                 ((puVar27[(int)uVar22] & 0x7fff) < uVar24)) {
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100cab;
                func_0x(lVar1,7);
              }
              uStack_6e = (short)uVar24;
              uVar21 = *(ushort *)((ulonglong)(uVar24 & 0xffff) + 2 + lStack_90);
              if ((uVar21 >> 0xe & 1) == 0) {
                uStack_6c = uStack_6c & 0xc7ff;
              }
              else {
                uStack_6c = uStack_6c ^ (uVar21 ^ uStack_6c) & 0x3800;
              }
              uStack_6c = (uStack_6c ^ *(ushort *)((ulonglong)(uVar24 & 0xffff) + 2 + lStack_90)) &
                          0x7ff ^ uStack_6c;
              param_1 = psStack_1e8;
            }
          }
          else if ((uStack_138 == (longlong *)0x0) || (*uStack_138 == 0)) {
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100d90;
            func_0x(&uStack_96,lVar1,0x1f9e,&uStack_146);
            plStack_88 = uStack_138;
            if (sStack_148 == 0) {
              plStack_88 = plVar15;
            }
          }
          else {
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100d72;
            func_0x(&sStack_98,lVar1,0x1f9e,&sStack_148);
          }
          psVar18 = &sStack_98;
        }
        else {
          psVar18 = &sStack_148;
        }
        sVar12 = *psVar18;
        *(short *)param_6 = sVar12;
        uVar2 = *(undefined4 *)(psVar18 + 3);
        uVar3 = *(undefined4 *)(psVar18 + 5);
        uVar4 = *(undefined4 *)(psVar18 + 7);
        uVar5 = *(undefined4 *)(psVar18 + 9);
        uVar6 = *(undefined4 *)(psVar18 + 0xb);
        uVar7 = *(undefined4 *)(psVar18 + 0xd);
        uVar8 = *(undefined4 *)(psVar18 + 0xf);
        param_5 = plStack_208;
        if (sVar12 == 0) {
          *(undefined4 *)((longlong)param_6 + 2) = *(undefined4 *)(psVar18 + 1);
          *(undefined4 *)((longlong)param_6 + 6) = uVar2;
          *(undefined4 *)((longlong)param_6 + 10) = uVar3;
          *(undefined4 *)((longlong)param_6 + 0xe) = uVar4;
          *(undefined4 *)((longlong)param_6 + 0x12) = uVar5;
          *(undefined4 *)((longlong)param_6 + 0x16) = uVar6;
          *(undefined4 *)((longlong)param_6 + 0x1a) = uVar7;
          *(undefined4 *)((longlong)param_6 + 0x1e) = uVar8;
          *(undefined8 *)((longlong)param_6 + 0x22) = *(undefined8 *)(psVar18 + 0x11);
          *(undefined4 *)((longlong)param_6 + 0x2a) = *(undefined4 *)(psVar18 + 0x15);
          puVar23 = auStack_278 + lVar16;
        }
        else {
          *(undefined4 *)((longlong)param_6 + 2) = *(undefined4 *)(psVar18 + 1);
          *(undefined4 *)((longlong)param_6 + 6) = uVar2;
          *(undefined4 *)((longlong)param_6 + 10) = uVar3;
          *(undefined4 *)((longlong)param_6 + 0xe) = uVar4;
          *(undefined4 *)((longlong)param_6 + 0x12) = uVar5;
          *(undefined4 *)((longlong)param_6 + 0x16) = uVar6;
          *(undefined4 *)((longlong)param_6 + 0x1a) = uVar7;
          *(undefined4 *)((longlong)param_6 + 0x1e) = uVar8;
          uVar2 = *(undefined4 *)(psVar18 + 0x13);
          uVar3 = *(undefined4 *)(psVar18 + 0x15);
          uVar4 = *(undefined4 *)(psVar18 + 0x17);
          *(undefined4 *)((longlong)param_6 + 0x22) = *(undefined4 *)(psVar18 + 0x11);
          *(undefined4 *)((longlong)param_6 + 0x26) = uVar2;
          *(undefined4 *)((longlong)param_6 + 0x2a) = uVar3;
          *(undefined4 *)((longlong)param_6 + 0x2e) = uVar4;
          *(short *)((longlong)param_6 + 0x32) = psVar18[0x19];
          param_6[2] = param_6[2];
          puVar23 = auStack_278 + lVar16;
        }
      }
    }
  }
  *(undefined8 *)(puVar23 + 0x58) = uStack_1e0;
  puVar23[0x50] = 0;
  *(undefined8 *)(puVar23 + 0x48) = uStack_1d8;
  *(longlong *)(puVar23 + 0x40) = lStack_1f8;
  *(undefined8 *)(puVar23 + 0x38) = uStack_1c0;
  puVar23[0x30] = param_8;
  piVar9 = piStack_1d0;
  *(int **)(puVar23 + 0x28) = piStack_1d0;
  *(undefined8 **)(puVar23 + 0x20) = param_6;
  lVar1 = lStack_1c8;
  uVar2 = uStack_1f0;
  *(undefined8 *)(puVar23 + -8) = 0x100e27;
  func_0x(lVar1,uVar2,param_4,param_5);
  if ((uStack_210 != 0) && (2 < *piVar9 - 2U)) {
    param_6[1] = 0;
    *param_6 = 0xffff;
    param_6[3] = 0;
    param_6[4] = 0;
    param_6[2] = 0;
    *(undefined4 *)(param_6 + 6) = 0;
    param_6[5] = 0;
    *(undefined8 *)(puVar23 + -8) = 0x100e60;
    func_0x(param_6,param_1);
  }
LAB_:
  uVar19 = uStack_50 ^ (ulonglong)&uStack_218;
  *(undefined8 *)(puVar23 + -8) = 0x100e6f;
  func_0x(uVar19);
  return;
}

