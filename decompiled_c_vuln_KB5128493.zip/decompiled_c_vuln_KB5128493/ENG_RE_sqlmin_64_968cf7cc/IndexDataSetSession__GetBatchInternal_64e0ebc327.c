
/* WARNING: Instruction at (ram,0x00101fe4) overlaps instruction at (ram,0x00101fde)
    */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,longlong *param_3)

{
  ushort *puVar1;
  char *pcVar2;
  byte *pbVar3;
  int *piVar4;
  longlong *plVar5;
  int *piVar6;
  char cVar7;
  char cVar8;
  byte bVar9;
  ushort uVar10;
  ushort uVar11;
  ushort uVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  undefined4 uVar16;
  int iVar17;
  uint uVar18;
  byte **ppbVar19;
  undefined8 uVar20;
  uint *puVar21;
  ulonglong uVar22;
  longlong lVar23;
  longlong *plVar24;
  longlong lVar25;
  code *UNRECOVERED_JUMPTABLE;
  undefined8 *puVar26;
  longlong **pplVar27;
  longlong lVar28;
  short *psVar29;
  short sVar30;
  uint uVar31;
  byte *pbVar32;
  longlong lVar33;
  ulonglong uVar34;
  uint *puVar35;
  longlong *plVar36;
  undefined4 *puVar37;
  longlong *plVar38;
  uint *puVar39;
  longlong unaff_GS_OFFSET;
  bool bVar40;
  bool bVar41;
  undefined auStack_588 [32];
  undefined8 uStack_568;
  undefined4 uStack_560;
  undefined8 uStack_558;
  undefined8 uStack_550;
  undefined4 uStack_530;
  undefined4 uStack_52c;
  longlong *plStack_528;
  undefined4 uStack_520;
  uint uStack_51c;
  undefined8 uStack_518;
  char acStack_510 [4];
  int iStack_50c;
  longlong *plStack_508;
  uint uStack_500;
  char cStack_4f8;
  int iStack_4f0;
  undefined8 uStack_4e8;
  undefined4 uStack_4d8;
  undefined8 uStack_4d0;
  int aiStack_4c8 [2];
  longlong **pplStack_4c0;
  int iStack_4b8;
  short sStack_4b4;
  int iStack_4b0;
  short sStack_4ac;
  longlong lStack_4a8;
  uint uStack_4a0;
  longlong lStack_498;
  longlong lStack_490;
  longlong *plStack_488;
  uint uStack_480;
  int iStack_460;
  int iStack_45c;
  uint auStack_458 [2];
  longlong lStack_450;
  int iStack_448;
  int iStack_444;
  int iStack_440;
  int iStack_43c;
  uint uStack_438;
  int iStack_434;
  uint uStack_430;
  int aiStack_42c [21];
  int iStack_3d8;
  short sStack_3d4;
  int iStack_3c8;
  short sStack_3c4;
  int iStack_3b8;
  short sStack_3b4;
  int iStack_3a8;
  short sStack_3a4;
  undefined8 *puStack_398;
  longlong lStack_390;
  longlong lStack_388;
  longlong *plStack_368;
  undefined4 uStack_360;
  undefined4 uStack_358;
  undefined auStack_340 [32];
  ulonglong uStack_320;
  ulonglong auStack_318 [2];
  undefined auStack_308 [4];
  int iStack_304;
  undefined auStack_300 [4];
  int iStack_2fc;
  undefined auStack_2f8 [4];
  undefined auStack_2f4 [28];
  undefined auStack_2d8 [4];
  undefined auStack_2d4 [4];
  undefined auStack_2d0 [16];
  longlong lStack_2c0;
  undefined8 uStack_2b8;
  longlong lStack_2b0;
  undefined auStack_2a8 [8];
  undefined auStack_2a0 [72];
  undefined auStack_258 [6];
  undefined auStack_252 [10];
  undefined8 uStack_248;
  undefined8 uStack_240;
  undefined8 uStack_238;
  undefined8 uStack_230;
  longlong *plStack_228;
  undefined auStack_220 [2];
  undefined4 uStack_21e;
  longlong lStack_21a;
  uint uStack_212;
  undefined4 uStack_1fc;
  undefined auStack_1f0 [2];
  undefined4 uStack_1ee;
  longlong lStack_1ea;
  uint uStack_1e2;
  undefined4 uStack_1cc;
  undefined auStack_1b8 [16];
  undefined auStack_1a8 [352];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_588;
  lStack_2b0 = *(longlong *)(param_1 + 0x108);
  plStack_528 = param_3;
  iStack_50c = param_2;
  lStack_490 = param_1;
  if ((*(byte *)(param_1 + 0x2d8) & 0x10) == 0) goto LAB_;
  uVar34 = 0;
  if (*(int *)(param_1 + 0x1cc) == 0) {
    *(undefined4 *)(param_1 + 0x1d4) = 1;
  }
  else {
    if ((*(longlong *)(param_1 + 0x158) != 0) || (uVar16 = 0, *(longlong *)(param_1 + 0x160) != 0))
    {
      uVar16 = 1;
    }
    piVar4 = (int *)param_3[1];
    if (*(int *)(param_1 + 0x1b8) == 0) {
      if (piVar4 == (int *)0x0) {
        bVar40 = *(longlong *)(param_1 + 0x1c0) == -1;
      }
      else {
        bVar40 = *(longlong *)(piVar4 + 0x38) == *(longlong *)(param_1 + 0x1c0);
      }
      if (!bVar40) goto LAB_;
    }
    else {
LAB_:
      uStack_568 = piVar4;
      uStack_560 = uVar16;
      uStack_558 = *(undefined8 *)(param_1 + 0x170);
      uStack_550 = *(undefined8 *)(param_1 + 0x178);
      func_0x
                ((undefined4 *)(param_1 + 0x1d4),*(undefined8 *)(param_1 + 0x10),lStack_2b0);
      *(undefined4 *)(param_1 + 0x1b8) = 0;
    }
    if (*(char *)(param_1 + 0x479) != '\0') {
      *(undefined4 *)(param_1 + 0x1d4) = 0;
    }
  }
  puVar37 = (undefined4 *)(param_1 + 0x1d4);
  acStack_510[0] = '\0';
  uStack_480 = 0;
  aiStack_4c8[0] = 0;
  uStack_4a0 = 0;
  if (((*(longlong *)(param_1 + 0x158) != 0) && (*(longlong *)(param_1 + 0x168) != 0)) &&
     (func_0x(*param_3,acStack_510,aiStack_4c8), aiStack_4c8[0] != 0)) {
    (*_DAT_)(auStack_318);
  }
  if (*(int *)(*param_3 + 0x40) + 1 < *(int *)(*param_3 + 0x2c)) {
    uStack_500 = auStack_458[0];
    do {
      if ((aiStack_4c8[0] != 0) && ((int)uVar34 == aiStack_4c8[0])) break;
      pplVar27 = (longlong **)(param_1 + 800);
      plStack_508 = *(longlong **)(param_1 + 0x310);
      uStack_4e8 = (longlong *)CONCAT44(uStack_4e8._4_4_,*puVar37);
      pplStack_4c0 = pplVar27;
      if (*(int *)(plStack_508 + 1) == 1) {
        cStack_4f8 = '\0';
        iStack_4f0 = _DAT_;
        uStack_530 = CONCAT22(uStack_530._2_2_,_DAT_);
        lStack_450 = *(longlong *)(plStack_508[3] + 8);
        lStack_388 = *(longlong *)(lStack_450 + 0x30);
        plVar36 = plStack_508;
        uVar15 = uStack_500;
LAB_:
        plVar38 = plVar36;
        iVar14 = *(int *)(plVar38 + 7);
        if (iVar14 == 0) {
          puStack_398 = (undefined8 *)plVar38[0x11];
          iVar14 = *(int *)(plVar38 + 0x12);
          iVar17 = *(int *)(plVar38 + 0x1aa);
          *(uint *)(plVar38 + 0x18) = *(uint *)(plVar38 + 0x18) & 0xfffffeff;
          uStack_500 = 0;
          if ((*(uint *)(plVar38 + 0x18) & 0x10080) == 0) {
            iVar13 = 4;
            if (iVar17 == 2) {
              iVar13 = 2;
            }
            if (iVar13 != *(int *)(plVar38[0x19] + 0x60)) goto LAB_;
          }
          else {
LAB_:
            iVar13 = func_0x(plVar38 + 0x16,iVar17);
            if (iVar13 == 1) {
              func_0x(plVar38 + 0x16,iVar17);
            }
          }
          uVar15 = *(uint *)(plVar38 + 0x1c);
          if ((*(byte *)((longlong)plVar38 + 0xe4) & 1) == 0) {
            if (param_2 == -1) {
              uVar15 = uVar15 - 1;
            }
          }
          else {
            uVar15 = uVar15 + param_2;
          }
          uStack_518 = CONCAT44(uStack_518._4_4_,uVar15);
          if (puStack_398 != (undefined8 *)0x0) {
            lStack_390 = (longlong)param_2;
            lStack_498 = (longlong)(int)uVar15;
            if (iVar14 == 0) {
              lVar28 = lStack_390 * -2;
              lVar33 = ((0xfff - lStack_498) - lStack_390) * 2;
              puVar26 = puStack_398;
              while( true ) {
                if ((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
                    (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
                   ((lVar25 = **(longlong **)(plVar38[0x19] + 0x30), lVar25 != 0 &&
                    (lVar25 != plVar38[0x1a])))) {
                  plVar38[0x1a] = lVar25;
                }
                uVar31 = param_2 + uVar15;
                if (*(ushort *)(plVar38[0x1a] + 0x16) <= uVar31) break;
                if ((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
                    (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
                   ((lVar25 = **(longlong **)(plVar38[0x19] + 0x30), lVar25 != 0 &&
                    (lVar25 != plVar38[0x1a])))) {
                  plVar38[0x1a] = lVar25;
                }
                lVar25 = plVar38[0x1a];
                if (uVar15 + iStack_50c * 2 < (uint)*(ushort *)(lVar25 + 0x16)) {
                  if (((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
                       (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
                      (lVar25 = **(longlong **)(plVar38[0x19] + 0x30), lVar25 != 0)) &&
                     (lVar25 != plVar38[0x1a])) {
                    plVar38[0x1a] = lVar25;
                  }
                  lVar25 = plVar38[0x1a];
                }
                if ((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
                    (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
                   ((lVar23 = **(longlong **)(plVar38[0x19] + 0x30), lVar23 != 0 &&
                    (lVar23 != lVar25)))) {
                  plVar38[0x1a] = lVar23;
                  lVar25 = lVar23;
                }
                piVar4 = *(int **)(*(longlong *)(*(longlong *)puVar26[1] + 0x28) + 0x70);
                uVar10 = *(ushort *)((longlong)piVar4 + 6);
                lVar23 = (ulonglong)*(ushort *)(lVar25 + (0xfff - lStack_498) * 2) + lVar25;
                if ((uVar10 & 0x10) == 0) {
                  lVar23 = *piVar4 + lVar23;
                }
                else {
                  uStack_212 = (uint)*(ushort *)(lVar23 + 2);
                  uStack_21e = 0;
                  uStack_1fc = 0;
                  lStack_21a = lVar23;
                  if ((*(byte *)((longlong)piVar4 + 6) & 0x10) != 0) {
                    uStack_568 = &iStack_448;
                    func_0x(auStack_220,piVar4,0,auStack_2d0);
                    if (iStack_448 == 0) {
                      uVar10 = *(ushort *)((longlong)piVar4 + 6);
                      lVar23 = *(longlong *)(piVar4 + 2) + 4;
                      goto LAB_;
                    }
                  }
                  uVar10 = *(ushort *)((longlong)piVar4 + 6);
                  lVar23 = *piVar4 + lStack_21a;
                }
LAB_:
                lStack_498 = lStack_498 + lStack_390;
                lVar25 = (ulonglong)*(ushort *)(lVar33 + lVar25) + lVar25;
                if ((uVar10 & 0x10) != 0) {
                  uStack_1e2 = (uint)*(ushort *)(lVar25 + 2);
                  uStack_1ee = 0;
                  uStack_1cc = 0;
                  lStack_1ea = lVar25;
                  if ((*(byte *)((longlong)piVar4 + 6) & 0x10) != 0) {
                    uStack_568 = &iStack_444;
                    func_0x(auStack_1f0,piVar4,0,auStack_2d4);
                  }
                }
                puVar26 = puStack_398;
                iVar14 = (**(code **)*puStack_398)(puStack_398,lVar23);
                if (iVar14 != 0) break;
                lVar33 = lVar33 + lVar28;
                uStack_518 = CONCAT44(uStack_518._4_4_,uVar31);
                param_2 = iStack_50c;
                uVar15 = uVar31;
              }
            }
            else {
              plVar36 = plVar38 + 0x1f;
              plStack_488 = *(longlong **)puStack_398[1];
              uStack_240 = *(undefined8 *)plVar38[0x1b];
              uStack_248 = 0x15902d0;
              uStack_238 = 0;
              uStack_230 = 0;
              if ((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
                  (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
                 ((lVar33 = **(longlong **)(plVar38[0x19] + 0x30), lVar33 != 0 &&
                  (lVar33 != plVar38[0x1a])))) {
                plVar38[0x1a] = lVar33;
              }
              lVar33 = plVar38[0x1a];
              uVar31 = param_2 + uVar15;
              uStack_4d0 = (longlong *)CONCAT44(uStack_4d0._4_4_,uVar31);
              plStack_368 = plVar36;
              plStack_228 = plVar36;
              if (uVar31 < *(ushort *)(lVar33 + 0x16)) {
                if (((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
                     (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
                    (lVar28 = **(longlong **)(plVar38[0x19] + 0x30), lVar28 != 0)) &&
                   (lVar28 != lVar33)) {
                  plVar38[0x1a] = lVar28;
                  lVar33 = lVar28;
                }
                if (uVar31 < *(ushort *)(lVar33 + 0x16)) {
                  if ((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
                      (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
                     ((lVar33 = **(longlong **)(plVar38[0x19] + 0x30), lVar33 != 0 &&
                      (lVar33 != plVar38[0x1a])))) {
                    plVar38[0x1a] = lVar33;
                  }
                  lVar33 = plVar38[0x1a];
                }
                lStack_4a8 = lVar33;
                if ((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
                    (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
                   ((lVar28 = **(longlong **)(plVar38[0x19] + 0x30), lVar28 != 0 &&
                    (lVar28 != lVar33)))) {
                  plVar38[0x1a] = lVar28;
                  lStack_4a8 = lVar28;
                }
                lVar33 = lStack_4a8;
                *(uint *)((longlong)plVar38 + 300) = uVar15;
                if (*(char *)(lStack_4a8 + 2) < '\0') {
                  pbVar32 = (byte *)(lStack_4a8 + 0x60);
                  if ((*(short *)plVar36 == 0) ||
                     (ppbVar19 = (byte **)plVar38[0x21], ppbVar19 == (byte **)0x0)) {
                    *(undefined (*) [16])(plVar38 + 0x26) = ZEXT816(0);
                    *(undefined (*) [16])(plVar38 + 0x28) = ZEXT816(0);
                    *(undefined (*) [16])(plVar38 + 0x2a) = ZEXT816(0);
                    *(undefined (*) [16])(plVar38 + 0x2c) = ZEXT816(0);
                    *(undefined (*) [16])(plVar38 + 0x2e) = ZEXT816(0);
                    *(undefined (*) [16])(plVar38 + 0x30) = ZEXT816(0);
                    *(undefined (*) [16])(plVar38 + 0x32) = ZEXT816(0);
                    plVar38[0x34] = 0;
                    ppbVar19 = (byte **)func_0x();
                  }
                  uVar20 = func_0x(lVar33,auStack_1b8,0,0);
                  if ((((pbVar32 != *ppbVar19) ||
                       (iVar14 = func_0x(uVar20,ppbVar19 + 0xc), iVar14 == 0)) ||
                      (*(int *)(lVar33 + 0x20) != *(int *)((longlong)ppbVar19 + 0x6c))) ||
                     (*(short *)(lVar33 + 0x24) != *(short *)(ppbVar19 + 0xe))) {
                    *ppbVar19 = pbVar32;
                    func_0x(ppbVar19 + 0xc,uVar20);
                    func_0x((longlong)ppbVar19 + 0x6c,lVar33 + 0x20);
                    uStack_358 = *(undefined4 *)((ulonglong)*pbVar32 * 6 + 0x1610ac0);
                    uVar34 = (ulonglong)*(short *)((ulonglong)*pbVar32 * 6 + 0x1610ac4);
                    *(undefined2 *)(ppbVar19 + 2) = 0xffff;
                    ppbVar19[3] = (byte *)0x0;
                    *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                    *(undefined8 *)((longlong)ppbVar19 + 0x2e) = 0;
                    ppbVar19[7] = (byte *)0x0;
                    ppbVar19[4] = (byte *)0x0;
                    ppbVar19[9] = (byte *)0x0;
                    ppbVar19[10] = (byte *)0x0;
                    *(undefined2 *)(ppbVar19 + 0xb) = 0;
                    if ((**ppbVar19 & 2) != 0) {
                      pbVar3 = pbVar32 + uVar34;
                      if ((pbVar32[uVar34] & 1) == 0) {
                        *(undefined2 *)(ppbVar19 + 2) = 0;
                        ppbVar19[3] = pbVar3;
                        *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                        *(undefined4 *)((longlong)ppbVar19 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100ab8 */
                    /* WARNING: Treating indirect jump as call */
                        (*(code *)((ulonglong)
                                   *(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107c98) -
                                  0xf29370))();
                        return;
                      }
                      *(undefined2 *)(ppbVar19 + 2) = 1;
                      ppbVar19[3] = pbVar3;
                      UNRECOVERED_JUMPTABLE =
                           (code *)((ulonglong)
                                    *(uint *)((ulonglong)
                                              *(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107c78)
                                              * 4 + 0x107c68) - 0xf29370);
                    /* WARNING: Could not emulate address calculation at 0x0010091f */
                    /* WARNING: Treating indirect jump as call */
                      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                      return;
                    }
                    if ((**ppbVar19 & 4) != 0) {
                      uStack_358._2_2_ = (short)((uint)uStack_358 >> 0x10);
                      if (uStack_358._2_2_ != 0) {
                        uVar34 = (ulonglong)
                                 *(ushort *)(lVar33 + 0x61 + (longlong)uStack_358._2_2_ * 2);
                      }
                      func_0x(ppbVar19 + 9,pbVar32 + uVar34);
                    }
                    plVar36 = plStack_368;
                    if (ppbVar19[1] != (byte *)0x0) {
                      func_0x(ppbVar19[1],ppbVar19);
                      plVar36 = plStack_368;
                    }
                  }
                }
                pbVar32 = (byte *)((ulonglong)*(ushort *)(lVar33 + (0xfff - lStack_498) * 2) +
                                  lVar33);
                if ((*pbVar32 & 1) == 0) {
                  *(short *)plVar36 = 0;
                  plVar36[1] = (longlong)pbVar32;
                  *(undefined4 *)((longlong)plVar36 + 4) = 0;
                  *(undefined4 *)((longlong)plVar36 + 0x26) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100d99 */
                    /* WARNING: Treating indirect jump as call */
                  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar32 & 0xe) * 4 + 0x107d10) -
                            0xf29370))();
                  return;
                }
                *(short *)plVar36 = 1;
                plVar36[1] = (longlong)pbVar32;
                UNRECOVERED_JUMPTABLE =
                     (code *)((ulonglong)
                              *(uint *)((ulonglong)
                                        *(byte *)((longlong)(int)(*pbVar32 & 0x1c) + 0x107cf0) * 4 +
                                       0x107ce0) - 0xf29370);
                    /* WARNING: Could not emulate address calculation at 0x00100bc1 */
                    /* WARNING: Treating indirect jump as call */
                (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                return;
              }
            }
          }
          if ((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
              (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
             ((lVar33 = **(longlong **)(plVar38[0x19] + 0x30), lVar33 != 0 &&
              (lVar33 != plVar38[0x1a])))) {
            plVar38[0x1a] = lVar33;
          }
          if ((uint)uStack_518 < *(ushort *)(plVar38[0x1a] + 0x16)) {
            if (((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
                 (*(longlong **)(plVar38[0x19] + 0x30) != (longlong *)0x0)) &&
                (lVar33 = **(longlong **)(plVar38[0x19] + 0x30), lVar33 != 0)) &&
               (lVar33 != plVar38[0x1a])) {
              plVar38[0x1a] = lVar33;
            }
            lVar33 = plVar38[0x1a];
            *(uint *)((longlong)plVar38 + 300) = (uint)uStack_518;
            plStack_488 = (longlong *)lVar33;
            if (*(char *)(lVar33 + 2) < '\0') {
              pbVar32 = (byte *)(lVar33 + 0x60);
              if ((*(short *)(plStack_508 + 0x1f) == 0) ||
                 (ppbVar19 = (byte **)plStack_508[0x21], ppbVar19 == (byte **)0x0)) {
                *(undefined (*) [16])(plStack_508 + 0x26) = ZEXT816(0);
                *(undefined (*) [16])(plStack_508 + 0x28) = ZEXT816(0);
                *(undefined (*) [16])(plStack_508 + 0x2a) = ZEXT816(0);
                *(undefined (*) [16])(plStack_508 + 0x2c) = ZEXT816(0);
                *(undefined (*) [16])(plStack_508 + 0x2e) = ZEXT816(0);
                *(undefined (*) [16])(plStack_508 + 0x30) = ZEXT816(0);
                *(undefined (*) [16])(plStack_508 + 0x32) = ZEXT816(0);
                plStack_508[0x34] = 0;
                ppbVar19 = (byte **)func_0x();
              }
              uVar20 = func_0x(lVar33,auStack_1a8,0,0);
              if (((pbVar32 != *ppbVar19) ||
                  (iVar14 = func_0x(uVar20,ppbVar19 + 0xc), iVar14 == 0)) ||
                 ((*(int *)(lVar33 + 0x20) != *(int *)((longlong)ppbVar19 + 0x6c) ||
                  (plVar38 = plStack_508, *(short *)(lVar33 + 0x24) != *(short *)(ppbVar19 + 0xe))))
                 ) {
                *ppbVar19 = pbVar32;
                func_0x(ppbVar19 + 0xc,uVar20);
                func_0x((longlong)ppbVar19 + 0x6c,lVar33 + 0x20);
                uStack_360 = *(undefined4 *)((ulonglong)*pbVar32 * 6 + 0x1610ac0);
                uVar34 = (ulonglong)*(short *)((ulonglong)*pbVar32 * 6 + 0x1610ac4);
                *(undefined2 *)(ppbVar19 + 2) = 0xffff;
                ppbVar19[3] = (byte *)0x0;
                *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                *(undefined8 *)((longlong)ppbVar19 + 0x2e) = 0;
                ppbVar19[7] = (byte *)0x0;
                ppbVar19[4] = (byte *)0x0;
                ppbVar19[9] = (byte *)0x0;
                ppbVar19[10] = (byte *)0x0;
                *(undefined2 *)(ppbVar19 + 0xb) = 0;
                if ((**ppbVar19 & 2) != 0) {
                  pbVar3 = pbVar32 + uVar34;
                  if ((pbVar32[uVar34] & 1) == 0) {
                    *(undefined2 *)(ppbVar19 + 2) = 0;
                    ppbVar19[3] = pbVar3;
                    *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                    *(undefined4 *)((longlong)ppbVar19 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001011ed */
                    /* WARNING: Treating indirect jump as call */
                    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107d7c) -
                              0xf29370))();
                    return;
                  }
                  *(undefined2 *)(ppbVar19 + 2) = 1;
                  ppbVar19[3] = pbVar3;
                  UNRECOVERED_JUMPTABLE =
                       (code *)((ulonglong)
                                *(uint *)((ulonglong)
                                          *(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107d5c) * 4
                                         + 0x107d4c) - 0xf29370);
                    /* WARNING: Could not emulate address calculation at 0x00101054 */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                  return;
                }
                if ((**ppbVar19 & 4) != 0) {
                  uStack_360._2_2_ = (short)((uint)uStack_360 >> 0x10);
                  if (uStack_360._2_2_ != 0) {
                    uVar34 = (ulonglong)*(ushort *)(lVar33 + 0x61 + (longlong)uStack_360._2_2_ * 2);
                  }
                  func_0x(ppbVar19 + 9,pbVar32 + uVar34);
                }
                plVar38 = plStack_508;
                if (ppbVar19[1] != (byte *)0x0) {
                  func_0x(ppbVar19[1],ppbVar19);
                  plVar38 = plStack_508;
                }
              }
            }
            pbVar32 = (byte *)((ulonglong)
                               *(ushort *)(lVar33 + (0xfff - (longlong)(int)(uint)uStack_518) * 2) +
                              lVar33);
            if ((*pbVar32 & 1) == 0) {
              *(undefined2 *)(plVar38 + 0x1f) = 0;
              plVar38[0x20] = (longlong)pbVar32;
              *(undefined4 *)((longlong)plVar38 + 0xfc) = 0;
              *(undefined4 *)((longlong)plVar38 + 0x11e) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101468 */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar32 & 0xe) * 4 + 0x107de8) -
                        0xf29370))();
              return;
            }
            *(undefined2 *)(plVar38 + 0x1f) = 1;
            plVar38[0x20] = (longlong)pbVar32;
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)
                                    *(byte *)((longlong)(int)(*pbVar32 & 0x1c) + 0x107dc8) * 4 +
                                   0x107db8) - 0xf29370);
                    /* WARNING: Could not emulate address calculation at 0x001012f9 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          func_0x(plVar38 + 0x1f);
          uVar15 = 1;
          uStack_500 = 1;
          *(uint *)(plVar38 + 0x18) = *(uint *)(plVar38 + 0x18) & 0xfffeffbf | 0x8000;
          param_2 = iStack_50c;
        }
        else if (iVar14 == 1) {
          if (*(int *)(plVar38 + 10) == 0) {
            func_0x();
          }
          else {
            func_0x(plVar38,param_2);
          }
          if (plVar38[0x15] == 0) {
            *(undefined4 *)(plVar38 + 7) = 2;
            goto LAB_;
          }
          plVar38[0x1ab] = plVar38[0x1ab] + 1;
          uVar15 = (uint)(plVar38[0x20] == 0);
          uStack_500 = (uint)(plVar38[0x20] == 0);
        }
        else {
          if (iVar14 == 2) {
LAB_:
            if (plVar38[0x15] == 0) {
              uStack_4d0 = (longlong *)0x0;
              *pplStack_4c0 = (longlong *)0x0;
              pplVar27 = pplStack_4c0;
              param_3 = plStack_528;
            }
            else {
              func_0x(plVar38 + 0x16);
              if (plVar38[0x19] != 0) {
                func_0x();
                piVar6 = (int *)plVar38[0x19];
                piVar4 = piVar6 + 2;
                *piVar4 = *piVar4 + -1;
                if (*piVar4 == 0) {
                  if (*piVar6 == 1) {
                    func_0x(piVar6);
                    (*_DAT_)(piVar6,0xa8);
                  }
                  else if ((piVar6[1] & 4U) != 0) {
                    if ((piVar6[1] & 0x10U) == 0) {
                      if ((*(longlong *)(piVar6 + 0x12) !=
                           CONCAT44(iRam0000000001f3456c,_DAT_)) ||
                         (*(longlong *)(piVar6 + 0x14) !=
                          CONCAT44(iRam0000000001f34574,_DAT_))) {
                        func_0x
                                  (*(undefined8 *)(piVar6 + 0x16),piVar6 + 0x12,piVar6 + 0xc,
                                   piVar6 + 0xc);
                      }
                      iVar13 = iRam0000000001f34574;
                      iVar17 = _DAT_;
                      iVar14 = iRam0000000001f3456c;
                      piVar6[0x12] = _DAT_;
                      piVar6[0x13] = iVar14;
                      piVar6[0x14] = iVar17;
                      piVar6[0x15] = iVar13;
                      *(undefined8 *)(piVar6 + 0x16) = 0;
                    }
                    func_0x
                              (*(undefined8 *)(*(longlong *)(piVar6 + 6) + 0x10),piVar6 + 8);
                    piVar6[1] = piVar6[1] & 0xffffff6b;
                  }
                }
              }
              plVar38[0x19] = 0;
              plVar38[0x1a] = 0;
              *(undefined4 *)(plVar38 + 0x1c) = 0xffffffff;
              *(undefined4 *)(plVar38 + 0x18) = 2;
              *(undefined4 *)(plVar38 + 0x41) = 1;
              plVar38[0x15] = 0;
              *pplStack_4c0 = (longlong *)0x0;
              uStack_4d0 = (longlong *)0x0;
              pplVar27 = pplStack_4c0;
              param_3 = plStack_528;
            }
            goto LAB_;
          }
          uStack_568 = (int *)0x15904b8;
          (*_DAT_)(1,0x1995310,0x19c31b8,0x2be);
        }
        while (plVar36 = plVar38, uVar15 != 0) {
          iVar14 = func_0x(plVar38,param_2);
          if (iVar14 != 0) {
            if (iVar14 == 4) {
              iVar14 = func_0x(plVar38,param_2);
              if (iVar14 != 1) {
                *(undefined4 *)(plVar38 + 7) = 2;
              }
              goto LAB_;
            }
            if (iVar14 == 8) goto LAB_;
            uStack_4d0 = (longlong *)0x0;
            pplVar27 = pplStack_4c0;
            param_3 = plStack_528;
            goto LAB_;
          }
          uStack_500 = 0;
          if (plVar38[0x20] == 0) {
            uStack_500 = uVar15;
          }
          plVar38[0x1ab] = plVar38[0x1ab] + 1;
          uVar15 = uStack_500;
        }
        plVar24 = plVar38 + 0x1f;
        *(uint *)(plVar38 + 0x18) = *(uint *)(plVar38 + 0x18) & 0xffffdfff;
        uVar15 = *(uint *)(plVar38[0x19] + 0xa0);
        uStack_4d0 = plVar24;
        if ((uVar15 & 0x10) != 0) {
          uVar15 = func_0x(plVar38,iStack_50c);
        }
        if (*(short *)plVar24 == 0) {
          bVar40 = ((*(byte *)plVar38[0x20] & 0xe) - 10 & 0xfd) == 0;
        }
        else {
          bVar40 = ((*(byte *)plVar38[0x20] & 0x1c) - 0xc & 0xffffffef) == 0;
        }
        if ((*(uint *)(plVar38 + 9) & 4) == 0) {
          if (iStack_50c == 1) {
            uVar31 = uVar15 & 1;
LAB_:
            if (uVar31 != 0) goto LAB_;
          }
          else if (iStack_50c == -1) {
            uVar31 = uVar15 & 2;
            goto LAB_;
          }
          iVar14 = func_0x(plVar38,plVar24);
          if (iVar14 != 4) goto LAB_;
        }
        else if ((*(uint *)(plVar38 + 9) & 8) != 0) {
LAB_:
          if ((*(char *)(plVar38[3] + 0x29) == '\0') || ((*(uint *)(plVar38[5] + 4) & 0x140) != 0))
          {
LAB_:
            if (((uVar15 & 4) == 0) || (((uint)uStack_4e8 == 0 && ((uVar15 & 8) != 0)))) {
              iVar14 = func_0x(plVar38,bVar40,0);
              param_2 = iStack_50c;
              uVar15 = uStack_500;
              if (iVar14 == 2) goto LAB_;
            }
            else {
              iVar14 = 0;
            }
          }
          else {
            uVar20 = func_0x(plVar24,auStack_252);
            func_0x(uVar20,&iStack_4b8);
            lVar33 = lStack_450;
            if (((short)uStack_530 == sStack_4b4) && (iStack_4f0 == iStack_4b8)) goto LAB_;
            sStack_3b4 = sStack_4b4;
            iStack_3b8 = iStack_4b8;
            iVar14 = func_0x(lStack_450,&iStack_3b8);
            if (iVar14 != 3) {
              uStack_530 = CONCAT22(uStack_530._2_2_,sStack_4b4);
              iStack_4f0 = iStack_4b8;
              goto LAB_;
            }
            if ((*(byte *)(plVar38[5] + 4) & 4) == 0) {
              *(uint *)(plVar38 + 0x18) = *(uint *)(plVar38 + 0x18) | 0x100;
              func_0x(plVar38 + 0x16);
              iStack_3a8 = iStack_4b8;
              sStack_3a4 = sStack_4b4;
              uStack_560 = *(undefined4 *)(plVar38[5] + 0x18);
              uStack_568 = (int *)CONCAT71(uStack_568._1_7_,3);
              uVar16 = func_0x(*(undefined2 *)(lStack_388 + 0x6b8),&iStack_3a8,lVar33,1);
              func_0x(uVar16,0x48);
              *(uint *)(plVar38 + 0x18) = *(uint *)(plVar38 + 0x18) & 0xfffffeff;
              uStack_530 = CONCAT22(uStack_530._2_2_,sStack_4b4);
              iStack_4f0 = iStack_4b8;
              param_2 = iStack_50c;
              uVar15 = uStack_500;
              goto LAB_;
            }
            iVar14 = 3;
          }
          plVar24 = plVar38 + 0x16;
          func_0x(plVar24);
          *(uint *)(plVar38 + 7) = (*(uint *)(plVar38 + 9) & 4) >> 1;
          if ((iVar14 == 3) && (*(char *)(lStack_388 + 0x1cde) != '\0')) {
LAB_:
            if (bVar40 == false) goto LAB_;
            if (*_DAT_ != '\0') {
              uStack_568 = (int *)0x0;
              func_0x(0x1f27a10,0xd,0x48,1);
            }
LAB_:
            param_2 = iStack_50c;
            uVar15 = uStack_500;
            if ((*(byte *)((longlong)plVar36 + 0x54) & 0x40) == 0) goto LAB_;
          }
          else {
            puVar26 = *(undefined8 **)(plVar38[3] + 8);
            plVar5 = *(longlong **)(plVar38[4] + 0x18);
            iVar17 = *(int *)(plVar5 + 2);
            cVar8 = *(char *)(puVar26[6] + 0x1cde);
            cVar7 = (**(code **)*puVar26)(puVar26);
            plVar36 = plStack_508;
            if (cVar7 != '\0') goto LAB_;
            if (cVar8 == '\0') {
              if (iVar17 << 0x1f < 0) {
                if ((*(byte *)(plVar5 + 2) & 0x40) == 0) goto LAB_;
                lVar33 = puVar26[0x1a];
                if (((lVar33 != 0) && (*(char *)(lVar33 + 0x34) != '\0')) &&
                   (*(longlong *)(lVar33 + 0x40) != 0)) {
                  lVar25 = *(longlong *)(*plVar5 + 0x28);
                  LOCK();
                  lVar28 = *(longlong *)(lVar33 + 0x128);
                  if (lVar28 == 0) {
                    *(longlong *)(lVar33 + 0x128) = 0;
                    lVar28 = 0;
                  }
                  UNLOCK();
                  if (lVar25 != lVar28) goto LAB_;
                }
              }
              goto LAB_;
            }
LAB_:
            if ((*(uint *)(plVar38 + 0x18) & 0x2000) == 0) {
              iVar17 = func_0x(plVar24);
              bVar41 = iVar17 == 0;
            }
            else {
              bVar41 = *(int *)(plVar38 + 0x41) != 0;
            }
            plVar36 = plStack_508;
            param_2 = iStack_50c;
            uVar15 = uStack_500;
            if (!bVar41) goto LAB_;
            cStack_4f8 = *(int *)(plStack_508 + 0x41) - 2U < 3;
            *(uint *)(plVar38 + 0x18) = *(uint *)(plVar38 + 0x18) & 0xfffffeff;
            if (((char)*(uint *)(plVar38 + 0x18) < '\0') ||
               ((*(byte *)((longlong)plVar38 + 0xe4) & 1) == 0)) {
              uStack_4d0 = (longlong *)func_0x(plVar24,0);
            }
            else if ((*(uint *)(plVar38 + 0x18) >> 0xd & 1) == 0) {
              uStack_4d0 = plVar38 + 0x1f;
            }
            else {
              uStack_4d0 = (longlong *)plVar38[0x3f];
            }
            if ((((byte)*(undefined4 *)(*(longlong *)(plVar36[3] + 8) + 0x218) & 5) == 1) &&
               ((*(byte *)(*(longlong *)(plVar36[3] + 8) + 0x2d8) & 2) != 0)) goto LAB_;
LAB_:
            if (iVar14 == 3) goto LAB_;
          }
          *pplStack_4c0 = plVar24;
          pplVar27 = pplStack_4c0;
          param_3 = plStack_528;
          if (_DAT_ == 0) goto LAB_;
          puVar26 = *(undefined8 **)(plVar36[3] + 8);
          plVar38 = *(longlong **)(plVar36[4] + 0x18);
          iVar14 = *(int *)(plVar38 + 2);
          cVar8 = *(char *)(puVar26[6] + 0x1cde);
          cVar7 = (**(code **)*puVar26)(puVar26);
          pplVar27 = pplStack_4c0;
          param_3 = plStack_528;
          if (cVar7 != '\0') goto LAB_;
          if (cVar8 == '\0') {
            if (-1 < iVar14 << 0x1f) goto LAB_;
            if ((*(byte *)(plVar38 + 2) & 0x40) != 0) {
              lVar33 = puVar26[0x1a];
              if (((lVar33 == 0) || (*(char *)(lVar33 + 0x34) == '\0')) ||
                 (*(longlong *)(lVar33 + 0x40) == 0)) goto LAB_;
              lVar25 = *(longlong *)(*plVar38 + 0x28);
              LOCK();
              lVar28 = *(longlong *)(lVar33 + 0x128);
              if (lVar28 == 0) {
                *(longlong *)(lVar33 + 0x128) = 0;
                lVar28 = 0;
              }
              UNLOCK();
              if (lVar25 == lVar28) goto LAB_;
            }
          }
          if (cStack_4f8 == '\0') {
            func_0x(*(undefined8 *)(plVar36[3] + 8));
            pplVar27 = pplStack_4c0;
            param_3 = plStack_528;
          }
          else {
            func_0x();
            pplVar27 = pplStack_4c0;
            param_3 = plStack_528;
          }
          goto LAB_;
        }
        lVar33 = lStack_450;
        if (*(int *)(plVar38[5] + 8) == 0x100000) {
          if (((*(char *)(plVar38[3] + 0x29) != '\0') && ((*(uint *)(plVar38[5] + 4) & 0x140) == 0))
             && ((((byte)*(undefined4 *)(lStack_450 + 0x218) & 5) != 1 ||
                 ((*(byte *)(lStack_450 + 0x2d8) & 2) == 0)))) {
            uVar20 = func_0x(plVar24,auStack_258);
            func_0x(uVar20,&iStack_4b0);
            if ((((short)uStack_530 != sStack_4ac) || (iStack_4f0 != iStack_4b0)) &&
               ((*(byte *)(plVar38[5] + 4) & 4) == 0)) {
              iStack_3d8 = iStack_4b0;
              sStack_3d4 = sStack_4ac;
              iVar14 = func_0x(lVar33,&iStack_3d8);
              if (iVar14 == 3) {
                *(uint *)(plVar38 + 0x18) = *(uint *)(plVar38 + 0x18) | 0x100;
                iStack_3c8 = iStack_4b0;
                sStack_3c4 = sStack_4ac;
                uStack_560 = *(undefined4 *)(plVar38[5] + 0x18);
                uStack_568 = (int *)CONCAT71(uStack_568._1_7_,3);
                uVar16 = func_0x(*(undefined2 *)(lStack_388 + 0x6b8),&iStack_3c8,lVar33,1);
                func_0x(uVar16,0x48);
                *(uint *)(plVar38 + 0x18) = *(uint *)(plVar38 + 0x18) & 0xfffffeff;
                iStack_4f0 = iStack_4b0;
                uStack_530 = CONCAT22(uStack_530._2_2_,sStack_4ac);
                param_2 = iStack_50c;
                uVar15 = uStack_500;
                goto LAB_;
              }
              iStack_4f0 = iStack_4b0;
              uStack_530 = CONCAT22(uStack_530._2_2_,sStack_4ac);
            }
          }
          iVar14 = func_0x(plVar38,bVar40,1);
          param_2 = iStack_50c;
          uVar15 = uStack_500;
          if (iVar14 == 2) goto LAB_;
        }
        *(undefined4 *)(plVar38 + 7) = 2;
        param_2 = iStack_50c;
        uVar15 = uStack_500;
        goto LAB_;
      }
      uStack_4d0 = (longlong *)
                   (**(code **)(*plStack_508 + 0x40))(plStack_508,param_2,*puVar37,pplVar27);
LAB_:
      param_1 = lStack_490;
      cVar8 = acStack_510[0];
      plVar36 = *pplVar27;
      if (plVar36 == (longlong *)0x0) {
        if ((*(int *)(lStack_490 + 0x150) != 2) ||
           (iVar14 = func_0x(lStack_490,auStack_340,1), plVar38 = param_3,
           iVar14 != 0)) goto LAB_;
LAB_:
        param_3 = plVar38;
        uStack_480 = uStack_480 + *(int *)(param_3 + 3);
        if (0x100000 < uStack_480) {
code_r0x00101fde:
          lVar28 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar33 = *(longlong *)(lVar28 + 0x100);
          puVar21 = _DAT_;
          if (lVar33 == 0) {
            puVar21 = (uint *)(*_DAT_)();
            lVar33 = *(longlong *)(lVar28 + 0x100);
          }
          uVar22 = rdtsc();
          uVar34 = *(ulonglong *)(lVar33 + 0x340);
          uVar22 = CONCAT44((int)((ulonglong)puVar21 >> 0x20),(int)uVar22) |
                   uVar22 & 0xffffffff00000000;
          if ((uVar34 < uVar22) ||
             ((uVar34 != 0x7fffffffffffffff &&
              (*(ulonglong *)(*(longlong *)(lVar33 + 0x260) + 0xdf0) < uVar34 - uVar22)))) {
            (*_DAT_)();
          }
          uStack_480 = 0;
        }
      }
      else {
        uStack_4a0 = uStack_4a0 + 1;
        lStack_450 = *(longlong *)(lStack_490 + 0x178);
        pcVar2 = (char *)(lStack_490 + 0x3f8);
        plStack_488 = *(longlong **)(lStack_490 + 0x170);
        lVar33 = *(longlong *)(lStack_490 + 0x158);
        puVar26 = *(undefined8 **)(lStack_490 + 0x168);
        plVar38 = *(longlong **)(lStack_490 + 0x160);
        lVar28 = lStack_490 + 400;
        if ((lVar33 == 0) && (puVar26 == (undefined8 *)0x0)) {
LAB_:
          if (plVar38 != (longlong *)0x0) {
            plVar24 = *(longlong **)plVar38[1];
            *(longlong **)(param_1 + 0x1b0) = uStack_4d0;
            *(longlong **)(param_1 + 0x1a8) = plVar36;
            (**(code **)(*plVar24 + 0x20))(plVar24,lVar28,&uStack_2b8);
            iVar14 = (**(code **)(*plVar38 + 8))(plVar38,uStack_2b8);
            if (iVar14 == 0) goto LAB_;
          }
          if (plStack_488 != (longlong *)0x0) {
            *(longlong **)(param_1 + 0x1b0) = uStack_4d0;
            *(longlong **)(param_1 + 0x1a8) = plVar36;
            iVar14 = func_0x(lVar28,plStack_488,lStack_450);
            if (iVar14 == 0) goto LAB_;
          }
          param_1 = lStack_490;
          *(int *)(*plStack_528 + 0x40) = *(int *)(*plStack_528 + 0x40) + 1;
          plVar36 = *(longlong **)(lStack_490 + 800);
          plStack_488 = plVar36;
          if (*(int *)(plStack_528 + 3) == 0) {
            (**(code **)(*plVar36 + 8))(plVar36);
            plVar38 = plStack_528;
            goto LAB_;
          }
          if ((((*(uint *)(lStack_490 + 0x2d8) & 0x1000) == 0) || (plVar36 == (longlong *)0x0)) ||
             (*(char *)(plVar36 + 0x179) == '\0')) {
            if ((*(short *)(plStack_528[1] + 0x3a) != 0) || (*(int *)(plStack_528[1] + 0x50) != 0))
            {
              func_0x(lStack_490,plVar36,plStack_528,auStack_458);
              plVar38 = plStack_528;
              if ((auStack_458[0] != 1) &&
                 ((*(longlong *)(*(longlong *)(param_1 + 0x108) + 0x70) != 0 &&
                  ((*(uint *)(*(longlong *)(param_1 + 0x108) + 0x120) & 0x100) != 0)))) {
                func_0x(plVar36);
                plVar38 = plStack_528;
              }
              goto LAB_;
            }
            *(uint *)(plVar36 + 2) = *(uint *)(plVar36 + 2) & 0xfffffeff;
            if (((char)*(uint *)(plVar36 + 2) < '\0') ||
               ((*(byte *)((longlong)plVar36 + 0x34) & 1) == 0)) {
              uStack_4e8 = (longlong *)func_0x(plVar36,0);
            }
            else if ((*(uint *)(plVar36 + 2) >> 0xd & 1) == 0) {
              uStack_4e8 = plVar36 + 9;
            }
            else {
              uStack_4e8 = (longlong *)plVar36[0x29];
            }
            plVar38 = uStack_4e8;
            lVar28 = plStack_528[1];
            lVar33 = param_1 + 0x110;
            plStack_508 = (longlong *)(param_1 + 0x398);
            uStack_518 = lVar33;
            if ((*(byte *)(lVar28 + 0x30) & 1) == 0) {
LAB_:
              *(undefined8 *)(param_1 + 0x3a0) = 0;
              *(longlong **)(param_1 + 0x3a8) = plVar36;
              lVar23 = (**(code **)*plVar36)(plVar36);
              lVar25 = uStack_518;
              plVar36 = plStack_528;
              plStack_508[1] = lVar23;
              if (*(short *)plVar38 == 0) {
                *(short *)plVar38 = 0;
                uVar31 = 0;
                uVar15 = *(uint *)(plStack_528 + 3);
                lVar28 = plStack_528[2];
                uStack_530 = uVar15;
                if (uVar15 != 0) {
                  do {
                    if (*(byte *)(lVar28 + 0x40) < 0x1c) {
                      UNRECOVERED_JUMPTABLE =
                           (code *)((ulonglong)
                                    *(uint *)((longlong)(char)*(byte *)(lVar28 + 0x40) * 4 +
                                             0x107e24) - 0xf29370);
                    /* WARNING: Could not emulate address calculation at 0x00103064 */
                    /* WARNING: Treating indirect jump as call */
                      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                      return;
                    }
                    uVar18 = *(uint *)(lVar28 + 0x40);
                    if ((uVar18 >> 10 & 1) != 0) {
                      func_0x(plStack_528,lVar28);
                      uVar18 = *(uint *)(lVar28 + 0x40);
                    }
                    if ((uVar18 >> 9 & 1) != 0) {
                      uStack_568 = (int *)CONCAT44(uStack_568._4_4_,uStack_520);
                      func_0x(plStack_528,lVar33,lVar28,0);
                    }
                    uVar31 = uVar31 + 1;
                    lVar28 = lVar28 + 0x50;
                  } while (uVar31 < uVar15);
                }
              }
              else if (*(int *)(*(longlong *)(param_1 + 0x118) + 0x100) == 2) {
                iStack_4f0 = *(int *)(lVar28 + 0x34);
                uStack_4d0 = (longlong *)((ulonglong)uStack_4d0 & 0xffffffff00000000);
                lVar33 = plStack_528[2];
                lStack_4a8 = *(undefined8 *)(*plStack_528 + 0x30);
                uStack_4e8 = (longlong *)CONCAT44(uStack_4e8._4_4_,*(int *)(plStack_528 + 3));
                if (*(int *)(plStack_528 + 3) != 0) {
                  do {
                    if (*(byte *)(lVar33 + 0x40) < 0x1c) {
                      UNRECOVERED_JUMPTABLE =
                           (code *)((ulonglong)
                                    *(uint *)((longlong)(char)*(byte *)(lVar33 + 0x40) * 4 +
                                             0x108174) - 0xf29370);
                    /* WARNING: Could not emulate address calculation at 0x001058c6 */
                    /* WARNING: Treating indirect jump as call */
                      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                      return;
                    }
                    uVar15 = *(uint *)(lVar33 + 0x40);
                    if ((uVar15 >> 10 & 1) != 0) {
                      func_0x(plVar36,lVar33);
                      uVar15 = *(uint *)(lVar33 + 0x40);
                    }
                    if ((uVar15 >> 9 & 1) != 0) {
                      uStack_568 = (int *)CONCAT44(uStack_568._4_4_,uStack_52c);
                      func_0x(plVar36,uStack_518,lVar33,0);
                    }
                    lVar33 = lVar33 + 0x50;
                    uVar15 = (int)uStack_4d0 + 1;
                    uStack_4d0 = (longlong *)CONCAT44(uStack_4d0._4_4_,uVar15);
                  } while (uVar15 < (uint)uStack_4e8);
                }
              }
              else {
                if (*(short *)plVar38 == -1) {
                  *(short *)plVar38 = 1;
                }
                uVar31 = 0;
                uVar15 = *(uint *)(plStack_528 + 3);
                lVar33 = plStack_528[2];
                if (uVar15 != 0) {
                  do {
                    if (*(byte *)(lVar33 + 0x40) < 0x1c) {
                      UNRECOVERED_JUMPTABLE =
                           (code *)((ulonglong)
                                    *(uint *)((longlong)(char)*(byte *)(lVar33 + 0x40) * 4 +
                                             0x107fcc) - 0xf29370);
                    /* WARNING: Could not emulate address calculation at 0x00104fb5 */
                    /* WARNING: Treating indirect jump as call */
                      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                      return;
                    }
                    uVar18 = *(uint *)(lVar33 + 0x40);
                    if ((uVar18 >> 10 & 1) != 0) {
                      func_0x(plStack_528,lVar33);
                      uVar18 = *(uint *)(lVar33 + 0x40);
                    }
                    if ((uVar18 >> 9 & 1) != 0) {
                      uStack_568 = (int *)CONCAT44(uStack_568._4_4_,uStack_4d8);
                      func_0x(plStack_528,lVar25,lVar33,0);
                    }
                    uVar31 = uVar31 + 1;
                    lVar33 = lVar33 + 0x50;
                  } while (uVar31 < uVar15);
                }
              }
              (**(code **)(*(longlong *)plStack_508[2] + 8))();
            }
            else {
              puVar1 = (ushort *)((longlong)uStack_4e8 + 2);
              if (*(short *)uStack_4e8 == 0) {
                if ((*(byte *)uStack_4e8[1] & 0x10) == 0) {
                  uVar15 = 0;
                }
                else {
                  uVar15 = (uint)*(ushort *)((byte *)uStack_4e8[1] + *(uint *)(uStack_4e8 + 2));
                }
              }
              else {
                uVar15 = (uint)*puVar1;
              }
              if (uVar15 < *(uint *)(lVar28 + 0x18)) goto LAB_;
              puVar21 = (uint *)0x0;
              *(short *)uStack_4e8 = 0;
              puVar39 = (uint *)plStack_528[2];
              uVar10 = *(ushort *)(plStack_528[1] + 0x62);
              puVar35 = puVar21;
              if (uVar10 != 0) {
                do {
                  plVar36 = uStack_4e8;
                  cVar8 = *(char *)(puVar39 + 0x10);
                  if (cVar8 == '\x01') {
                    if ((*(byte *)((longlong)puVar39 + 6) & 0x10) == 0) {
                      uVar15 = *(byte *)((ulonglong)(*(ushort *)(puVar39 + 1) - 1 >> 3) +
                                         (ulonglong)*(uint *)(plVar38 + 2) + 2 + plVar38[1]) >>
                               ((byte)(*(ushort *)(puVar39 + 1) - 1) & 7) & 1;
                    }
                    else {
                      uStack_568 = &iStack_304;
                      func_0x(puVar1,puVar39,1,&uStack_430);
                      uVar15 = uStack_430;
                    }
                    if (uVar15 == 0) goto LAB_;
                    func_0x(plStack_528,puVar39);
                  }
                  else {
                    if (cVar8 == '\x02') {
LAB_:
                      uVar11 = *(ushort *)(puVar39 + 0xf);
                      if ((*(byte *)((longlong)puVar39 + 6) & 0x10) == 0) {
LAB_:
                        puVar21 = (uint *)((longlong)(int)*puVar39 + plVar38[1]);
                        uVar15 = (uint)uVar11;
                      }
                      else {
                        uStack_568 = aiStack_42c;
                        func_0x(puVar1,puVar39,0,auStack_308);
                        if (aiStack_42c[0] != 0) goto LAB_;
                        uVar15 = **(uint **)(puVar39 + 2);
                        puVar21 = *(uint **)(puVar39 + 2) + 1;
                        if ((uVar11 != 0) && (uVar15 != uVar11)) {
                          uStack_568 = (int *)0x0;
                          (*_DAT_)(1,0x19c1d48,0x19c0748,0x381);
                        }
                      }
                    }
                    else {
                      if (cVar8 == '\x03') {
                        if ((*(byte *)((longlong)puVar39 + 6) & 0x10) == 0) {
                          uVar15 = *(byte *)((ulonglong)(*(ushort *)(puVar39 + 1) - 1 >> 3) +
                                             (ulonglong)*(uint *)(plVar38 + 2) + 2 + plVar38[1]) >>
                                   ((byte)(*(ushort *)(puVar39 + 1) - 1) & 7) & 1;
                        }
                        else {
                          uStack_568 = &iStack_2fc;
                          func_0x(puVar1,puVar39,1,&uStack_438);
                          uVar15 = uStack_438;
                        }
                        if (uVar15 != 0) {
                          func_0x(plStack_528,puVar39);
                          goto LAB_;
                        }
                      }
                      else if (cVar8 != '\x04') {
                        if (cVar8 != '\b') {
                          uStack_568 = (int *)0x15904b8;
                          (*_DAT_)(1,0x1995310,0x19c1c50,0x27d);
                          uVar15 = uStack_51c;
                          goto LAB_;
                        }
                        uVar11 = *(ushort *)(puVar39 + 0xf);
                        iVar14 = puVar39[0x10] << 0xc;
                        if ((*puVar39 & 0xc0000000) == 0x80000000) {
                          iVar14 = func_0x(puVar1);
                          if (iVar14 == 0) {
                            uStack_51c = 0;
                            func_0x(plStack_528,puVar39);
                            puVar21 = (uint *)0x0;
                            goto LAB_;
                          }
                          puVar21 = (uint *)func_0x((short *)((longlong)plVar38 + 0x2a),
                                                            puVar39,&uStack_51c,auStack_2f8);
                          uVar15 = uStack_51c;
                        }
                        else {
                          if ((iVar14 < 0) || ((*(byte *)((longlong)puVar39 + 6) & 0x10) != 0)) {
                            uStack_568 = &iStack_460;
                            func_0x(puVar1,puVar39,iVar14 < 0,&iStack_45c);
                            if ((iVar14 < 0) && (iStack_45c != 0)) {
                              uStack_51c = 0;
                              puVar21 = (uint *)0x0;
                              uVar15 = uStack_51c;
                              goto LAB_;
                            }
                          }
                          else {
                            iStack_45c = 0;
                            iStack_460 = 1;
                          }
                          if ((iStack_460 == 0) && ((*(byte *)((longlong)puVar39 + 6) & 0x10) != 0))
                          {
                            puVar21 = *(uint **)(puVar39 + 2) + 1;
                            uVar15 = **(uint **)(puVar39 + 2);
                          }
                          else if ((int)*puVar39 < 0) {
                            if (*(int *)((longlong)plVar38 + 4) == 0) {
                              *puVar1 = 0;
                              uVar15 = *(uint *)(plVar38 + 2);
                              uVar34 = (ulonglong)uVar15;
                              *(uint *)((longlong)plVar38 + 0x14) = uVar15;
                              pbVar32 = (byte *)plVar38[1];
                              bVar9 = *pbVar32;
                              if ((bVar9 & 0x10) != 0) {
                                uVar15 = uVar15 + (*(ushort *)(pbVar32 + uVar34) + 7 >> 3) + 2;
                                uVar34 = (ulonglong)uVar15;
                                *(uint *)((longlong)plVar38 + 0x14) = uVar15;
                                bVar9 = *pbVar32;
                              }
                              if ((bVar9 & 0x20) == 0) {
                                *(int *)((longlong)plVar38 + 4) = (int)uVar34;
                                *(short *)((longlong)plVar38 + 0x1c) = 0;
                                *(uint *)(plVar38 + 3) = uVar15;
                              }
                              else {
                                psVar29 = (short *)(pbVar32 + uVar34);
                                sVar30 = *psVar29;
                                *(short *)((longlong)plVar38 + 0x1c) = sVar30;
                                if (sVar30 == 0) {
                                  cVar8 = func_0x(0x1f23250);
                                  if (((cVar8 != '\0') &&
                                      (lVar33 = func_0x(), lVar33 != 0)) &&
                                     (*(char *)(lVar33 + 0x499) != '\0')) {
                                    cVar8 = func_0x(0x1f23250);
                                    if (cVar8 == '\0') {
                                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                    }
                                    else {
                                      uStack_568 = (int *)0x0;
                                      (*_DAT_)(1,0x1813fd8,0x1933ca8,0x80f);
                                    }
                                  }
                                  func_0x(plVar38[1],3);
                                }
                                uVar15 = *(int *)((longlong)plVar38 + 0x14) +
                                         (*(ushort *)((longlong)plVar38 + 0x1c) + 1) * 2;
                                *(uint *)(plVar38 + 3) = uVar15;
                                if (0x1f9e < uVar15) {
                                  cVar8 = func_0x(0x1f23250);
                                  if (((cVar8 != '\0') &&
                                      (lVar33 = func_0x(), lVar33 != 0)) &&
                                     (*(char *)(lVar33 + 0x499) != '\0')) {
                                    cVar8 = func_0x(0x1f23250);
                                    if (cVar8 == '\0') {
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      uStack_568 = (int *)0x0;
                                      (*_DAT_)(1,0x1813fd8,0x1933ca8,0x816);
                                    }
                                  }
                                  func_0x(plVar38[1],4);
                                }
                                uVar11 = psVar29[*(ushort *)((longlong)plVar38 + 0x1c)];
                                *(uint *)((longlong)plVar38 + 4) = uVar11 & 0x7fff;
                                if ((uVar11 & 0x7fff) < *(uint *)(plVar38 + 3)) {
                                  cVar8 = func_0x(0x1f23250);
                                  if (((cVar8 != '\0') &&
                                      (lVar33 = func_0x(), lVar33 != 0)) &&
                                     (*(char *)(lVar33 + 0x499) != '\0')) {
                                    cVar8 = func_0x(0x1f23250);
                                    if (cVar8 == '\0') {
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      uStack_568 = (int *)0x0;
                                      (*_DAT_)(1,0x1813fd8,0x1933ca8,0x81d);
                                    }
                                  }
                                  func_0x(plVar38[1],4);
                                }
                                uVar11 = *(ushort *)((longlong)plVar38 + 0x1c);
                                if (psVar29[(ulonglong)(uVar11 - 1) + 1] < 0) {
                                  do {
                                    lVar33 = (ulonglong)*(uint *)((longlong)plVar38 + 0x14) +
                                             plVar38[1];
                                    if (uVar11 == 1) {
                                      uVar15 = *(uint *)(plVar38 + 3);
                                      uVar31 = uVar15;
LAB_:
                                      if ((*(ushort *)(lVar33 + (ulonglong)uVar11 * 2) & 0x7fff) <
                                          uVar15) goto LAB_;
                                    }
                                    else {
                                      uVar31 = *(uint *)(plVar38 + 3);
                                      uVar15 = *(ushort *)(lVar33 + -2 + (ulonglong)uVar11 * 2) &
                                               0x7fff;
                                      if (uVar31 <= uVar15) goto LAB_;
LAB_:
                                      func_0x(plVar38[1],7);
                                      uVar31 = *(uint *)(plVar38 + 3);
                                    }
                                    if ((uVar15 < uVar31) ||
                                       (*(uint *)((longlong)plVar38 + 4) < uVar15))
                                    goto LAB_;
                                    if (*(ushort *)((ulonglong)uVar15 + plVar38[1]) == 5) {
                                      *puVar1 = *puVar1 | 2;
                                      *(short *)((longlong)plVar38 + 0x1c) =
                                           *(short *)((longlong)plVar38 + 0x1c) + -1;
                                      *(short *)((longlong)plVar38 + 0x2a) = (short)uVar15;
                                      lVar33 = (ulonglong)(uVar15 & 0xffff) + plVar38[1];
                                      uVar12 = *(ushort *)((longlong)plVar38 + 0x2c) & 0xc7ff;
                                      uVar11 = *(ushort *)(lVar33 + 2);
                                      if ((uVar11 >> 0xe & 1) != 0) {
                                        uVar12 = uVar11 & 0x3800 | uVar12;
                                      }
                                      *(ushort *)((longlong)plVar38 + 0x2c) = uVar12;
                                      *(ushort *)((longlong)plVar38 + 0x2c) =
                                           (uVar12 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar12;
                                      break;
                                    }
                                    if (*(ushort *)((ulonglong)uVar15 + plVar38[1]) < 0x400) break;
                                    *puVar1 = *puVar1 | 1;
                                    uVar11 = *(short *)((longlong)plVar38 + 0x1c) - 1;
                                    *(ushort *)((longlong)plVar38 + 0x1c) = uVar11;
                                    if ((uVar11 == 0) || (-1 < psVar29[(ulonglong)(uVar11 - 1) + 1])
                                       ) break;
                                  } while( true );
                                }
                              }
                              if ((*(byte *)plVar38[1] & 0x40) == 0) {
                                *(undefined4 *)((longlong)plVar38 + 0x26) = 0;
                              }
                              else {
                                *(int *)((longlong)plVar38 + 0x26) = *(int *)((longlong)plVar38 + 4)
                                ;
                                *(int *)((longlong)plVar38 + 4) =
                                     *(int *)((longlong)plVar38 + 4) + 0xe;
                                uVar20 = func_0x(puVar1);
                                func_0x(uVar20,auStack_2a8);
                                iVar14 = func_0x(auStack_2a8);
                                *(int *)((longlong)plVar38 + 4) =
                                     *(int *)((longlong)plVar38 + 4) + iVar14;
                              }
                              uVar15 = *(uint *)((longlong)plVar38 + 4);
                              if ((*(ulonglong *)((longlong)plVar38 + 0x1e) != 0) &&
                                 (*(ulonglong *)((longlong)plVar38 + 0x1e) <
                                  (ulonglong)uVar15 + plVar38[1])) {
                                cVar8 = func_0x(0x1f23250);
                                if ((cVar8 != '\0') &&
                                   ((lVar33 = func_0x(), lVar33 != 0 &&
                                    (*(char *)(lVar33 + 0x499) != '\0')))) {
                                  cVar8 = func_0x(0x1f23250);
                                  if (cVar8 == '\0') {
                                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                  }
                                  else {
                                    uStack_568 = (int *)0x0;
                                    (*_DAT_)(1,0x1813fd8,0x1933ca8,0x877);
                                  }
                                }
                                func_0x(plVar38[1],0x12);
                                uVar15 = *(uint *)((longlong)plVar38 + 4);
                              }
                              if (0x3f3b < uVar15 - 1) {
                                cVar8 = func_0x(0x1f23250);
                                if (((cVar8 != '\0') &&
                                    (lVar33 = func_0x(), lVar33 != 0)) &&
                                   (*(char *)(lVar33 + 0x499) != '\0')) {
                                  cVar8 = func_0x(0x1f23250);
                                  if (cVar8 == '\0') {
                                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                  }
                                  else {
                                    uStack_568 = (int *)0x0;
                                    (*_DAT_)(1,0x1813fd8,0x1933ca8,0x87c);
                                  }
                                }
                                func_0x(plVar38[1],5);
                              }
                            }
LAB_:
                            sVar30 = -*(short *)puVar39;
                            if ((*(byte *)((longlong)puVar39 + 6) & 0x10) != 0) {
                              uStack_568 = &iStack_43c;
                              func_0x(puVar1,puVar39,0,auStack_2f4);
                              if (iStack_43c == 0) {
                                puVar21 = *(uint **)(puVar39 + 2) + 1;
                                uVar15 = **(uint **)(puVar39 + 2);
                                goto LAB_;
                              }
                            }
                            lVar33 = (longlong)sVar30;
                            if ((uint)*(ushort *)((longlong)plVar38 + 0x1c) < (uint)(int)sVar30) {
                              uStack_51c = 0;
                              puVar21 = (uint *)plVar38[1];
                              uVar15 = uStack_51c;
                            }
                            else {
                              lVar28 = plVar38[1];
                              lVar25 = (ulonglong)*(uint *)((longlong)plVar38 + 0x14) + lVar28;
                              if (sVar30 == 1) {
                                uVar31 = *(ushort *)(lVar25 + lVar33 * 2) & 0x7fff;
                                uVar15 = *(uint *)(uStack_4e8 + 3);
LAB_:
                                if (uVar31 < uVar15) goto LAB_;
                              }
                              else {
                                uVar15 = *(ushort *)(lVar25 + -2 + lVar33 * 2) & 0x7fff;
                                uVar31 = *(ushort *)(lVar25 + lVar33 * 2) & 0x7fff;
                                lVar28 = plVar38[1];
                                if (*(uint *)(uStack_4e8 + 3) <= uVar15) goto LAB_;
LAB_:
                                func_0x(lVar28,7);
                              }
                              puVar21 = (uint *)((ulonglong)uVar15 + plVar38[1]);
                              uVar15 = uVar31 - uVar15;
                            }
                          }
                          else if ((*(ushort *)((longlong)puVar39 + 6) & 8) == 0) {
                            if ((*(ushort *)((longlong)puVar39 + 6) & 0x10) != 0) {
                              uStack_568 = &iStack_440;
                              func_0x(puVar1,puVar39,0,auStack_2d8);
                              if (iStack_440 == 0) {
                                uVar15 = **(uint **)(puVar39 + 2);
                                puVar21 = *(uint **)(puVar39 + 2) + 1;
                                if ((uVar11 != 0) && (uVar15 != uVar11)) {
                                  uStack_568 = (int *)0x0;
                                  (*_DAT_)(1,0x19c1d48,0x19c0748,0x381);
                                }
                                goto LAB_;
                              }
                            }
                            puVar21 = (uint *)((longlong)(int)*puVar39 + plVar38[1]);
                            uVar15 = (uint)uVar11;
                          }
                          else {
                            puVar21 = (uint *)func_0x(puVar1,puVar39);
                            uVar15 = uStack_51c;
                          }
                        }
LAB_:
                        uStack_51c = uVar15;
                        uVar15 = uStack_51c;
                        if (puVar21 != (uint *)0x0) goto LAB_;
                        func_0x(plStack_528,puVar39);
                        goto LAB_;
                      }
                      if (*(int *)((longlong)plVar38 + 4) == 0) {
                        *puVar1 = 0;
                        uVar15 = *(uint *)(plVar38 + 2);
                        uVar34 = (ulonglong)uVar15;
                        *(uint *)((longlong)plVar38 + 0x14) = uVar15;
                        pbVar32 = (byte *)plVar38[1];
                        bVar9 = *pbVar32;
                        if ((bVar9 & 0x10) != 0) {
                          uVar15 = uVar15 + (*(ushort *)(pbVar32 + uVar34) + 7 >> 3) + 2;
                          uVar34 = (ulonglong)uVar15;
                          *(uint *)((longlong)plVar38 + 0x14) = uVar15;
                          bVar9 = *pbVar32;
                        }
                        if ((bVar9 & 0x20) == 0) {
                          *(int *)((longlong)plVar38 + 4) = (int)uVar34;
                          *(short *)((longlong)plVar38 + 0x1c) = 0;
                          *(uint *)(plVar38 + 3) = uVar15;
                        }
                        else {
                          psVar29 = (short *)(pbVar32 + uVar34);
                          sVar30 = *psVar29;
                          *(short *)((longlong)plVar38 + 0x1c) = sVar30;
                          if (sVar30 == 0) {
                            cVar8 = func_0x(0x1f23250);
                            if (((cVar8 != '\0') &&
                                (lVar33 = func_0x(), lVar33 != 0)) &&
                               (*(char *)(lVar33 + 0x499) != '\0')) {
                              cVar8 = func_0x(0x1f23250);
                              if (cVar8 == '\0') {
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                uStack_568 = (int *)0x0;
                                (*_DAT_)(1,0x1813fd8,0x1933ca8,0x80f);
                              }
                            }
                            func_0x(plVar38[1],3);
                          }
                          uVar15 = *(int *)((longlong)plVar38 + 0x14) +
                                   (*(ushort *)((longlong)plVar38 + 0x1c) + 1) * 2;
                          *(uint *)(plVar38 + 3) = uVar15;
                          if (0x1f9e < uVar15) {
                            cVar8 = func_0x(0x1f23250);
                            if (((cVar8 != '\0') &&
                                (lVar33 = func_0x(), lVar33 != 0)) &&
                               (*(char *)(lVar33 + 0x499) != '\0')) {
                              cVar8 = func_0x(0x1f23250);
                              if (cVar8 == '\0') {
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                uStack_568 = (int *)0x0;
                                (*_DAT_)(1,0x1813fd8,0x1933ca8,0x816);
                              }
                            }
                            func_0x(plVar38[1],4);
                          }
                          uVar11 = psVar29[*(ushort *)((longlong)plVar38 + 0x1c)];
                          *(uint *)((longlong)plVar38 + 4) = uVar11 & 0x7fff;
                          if ((uVar11 & 0x7fff) < *(uint *)(plVar38 + 3)) {
                            cVar8 = func_0x(0x1f23250);
                            if (((cVar8 != '\0') &&
                                (lVar33 = func_0x(), lVar33 != 0)) &&
                               (*(char *)(lVar33 + 0x499) != '\0')) {
                              cVar8 = func_0x(0x1f23250);
                              if (cVar8 == '\0') {
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                uStack_568 = (int *)0x0;
                                (*_DAT_)(1,0x1813fd8,0x1933ca8,0x81d);
                              }
                            }
                            func_0x(plVar38[1],4);
                          }
                          uVar11 = *(ushort *)((longlong)plVar38 + 0x1c);
                          if (psVar29[(ulonglong)(uVar11 - 1) + 1] < 0) {
                            do {
                              lVar33 = plVar38[1];
                              lVar28 = (ulonglong)*(uint *)((longlong)plVar38 + 0x14) + lVar33;
                              if (uVar11 == 1) {
                                uVar15 = *(uint *)(plVar38 + 3);
                                uVar31 = uVar15;
LAB_:
                                if ((*(ushort *)(lVar28 + (ulonglong)uVar11 * 2) & 0x7fff) < uVar15)
                                goto LAB_;
                              }
                              else {
                                uVar31 = *(uint *)(plVar38 + 3);
                                uVar15 = *(ushort *)(lVar28 + -2 + (ulonglong)uVar11 * 2) & 0x7fff;
                                if (uVar31 <= uVar15) goto LAB_;
LAB_:
                                func_0x(lVar33,7);
                                uVar31 = *(uint *)(plVar38 + 3);
                                lVar33 = plVar38[1];
                              }
                              if ((uVar15 < uVar31) || (*(uint *)((longlong)plVar38 + 4) < uVar15))
                              goto LAB_;
                              if (*(ushort *)((ulonglong)uVar15 + lVar33) == 5) {
                                *puVar1 = *puVar1 | 2;
                                *(short *)((longlong)plVar38 + 0x1c) =
                                     *(short *)((longlong)plVar38 + 0x1c) + -1;
                                *(short *)((longlong)plVar38 + 0x2a) = (short)uVar15;
                                lVar33 = (ulonglong)(uVar15 & 0xffff) + plVar38[1];
                                uVar12 = *(ushort *)((longlong)plVar38 + 0x2c) & 0xc7ff;
                                uVar11 = *(ushort *)(lVar33 + 2);
                                if ((uVar11 >> 0xe & 1) != 0) {
                                  uVar12 = uVar11 & 0x3800 | uVar12;
                                }
                                *(ushort *)((longlong)plVar38 + 0x2c) = uVar12;
                                *(ushort *)((longlong)plVar38 + 0x2c) =
                                     (uVar12 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar12;
                                break;
                              }
                              if (*(ushort *)((ulonglong)uVar15 + lVar33) < 0x400) break;
                              *puVar1 = *puVar1 | 1;
                              uVar11 = *(short *)((longlong)plVar38 + 0x1c) - 1;
                              *(ushort *)((longlong)plVar38 + 0x1c) = uVar11;
                              if ((uVar11 == 0) || (-1 < psVar29[(ulonglong)(uVar11 - 1) + 1]))
                              break;
                            } while( true );
                          }
                        }
                        if ((*(byte *)plVar38[1] & 0x40) == 0) {
                          *(undefined4 *)((longlong)plVar38 + 0x26) = 0;
                        }
                        else {
                          *(int *)((longlong)plVar38 + 0x26) = *(int *)((longlong)plVar38 + 4);
                          *(int *)((longlong)plVar38 + 4) = *(int *)((longlong)plVar38 + 4) + 0xe;
                          uVar20 = func_0x(puVar1);
                          func_0x(uVar20,auStack_2a0);
                          iVar14 = func_0x(auStack_2a0);
                          *(int *)((longlong)plVar38 + 4) = *(int *)((longlong)plVar38 + 4) + iVar14
                          ;
                        }
                        uVar15 = *(uint *)((longlong)plVar38 + 4);
                        if ((*(ulonglong *)((longlong)plVar38 + 0x1e) != 0) &&
                           (*(ulonglong *)((longlong)plVar38 + 0x1e) <
                            (ulonglong)uVar15 + plVar38[1])) {
                          cVar8 = func_0x(0x1f23250);
                          if ((cVar8 != '\0') &&
                             ((lVar33 = func_0x(), lVar33 != 0 &&
                              (*(char *)(lVar33 + 0x499) != '\0')))) {
                            cVar8 = func_0x(0x1f23250);
                            if (cVar8 == '\0') {
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              uStack_568 = (int *)0x0;
                              (*_DAT_)(1,0x1813fd8,0x1933ca8,0x877);
                            }
                          }
                          func_0x(plVar38[1],0x12);
                          uVar15 = *(uint *)((longlong)plVar38 + 4);
                        }
                        if (0x3f3b < uVar15 - 1) {
                          cVar8 = func_0x(0x1f23250);
                          if (((cVar8 != '\0') && (lVar33 = func_0x(), lVar33 != 0))
                             && (*(char *)(lVar33 + 0x499) != '\0')) {
                            cVar8 = func_0x(0x1f23250);
                            if (cVar8 == '\0') {
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              uStack_568 = (int *)0x0;
                              (*_DAT_)(1,0x1813fd8,0x1933ca8,0x87c);
                            }
                          }
                          func_0x(plVar38[1],5);
                        }
                      }
LAB_:
                      sVar30 = -*(short *)puVar39;
                      if ((*(byte *)((longlong)puVar39 + 6) & 0x10) == 0) {
LAB_:
                        lVar33 = (longlong)sVar30;
                        if ((uint)*(ushort *)((longlong)plVar38 + 0x1c) < (uint)(int)sVar30) {
                          uStack_51c = 0;
                          puVar21 = (uint *)plVar38[1];
                        }
                        else {
                          lVar28 = plVar38[1];
                          lVar25 = (ulonglong)*(uint *)((longlong)plVar38 + 0x14) + lVar28;
                          if (sVar30 == 1) {
                            uVar34 = (ulonglong)*(uint *)(plVar36 + 3);
                            uVar15 = *(ushort *)(lVar25 + lVar33 * 2) & 0x7fff;
LAB_:
                            if (uVar15 < (uint)uVar34) goto LAB_;
                          }
                          else {
                            uVar31 = *(ushort *)(lVar25 + -2 + lVar33 * 2) & 0x7fff;
                            uVar34 = (ulonglong)uVar31;
                            lVar28 = plVar38[1];
                            uVar15 = *(ushort *)(lVar25 + lVar33 * 2) & 0x7fff;
                            if (*(uint *)(plVar36 + 3) <= uVar31) goto LAB_;
LAB_:
                            func_0x(lVar28,7);
                          }
                          uStack_51c = uVar15 - (int)uVar34;
                          puVar21 = (uint *)(uVar34 + plVar38[1]);
                        }
                      }
                      else {
                        uStack_568 = &iStack_434;
                        func_0x(puVar1,puVar39,0,auStack_300);
                        if (iStack_434 != 0) goto LAB_;
                        uStack_51c = **(uint **)(puVar39 + 2);
                        puVar21 = *(uint **)(puVar39 + 2) + 1;
                      }
                      if (((puVar39[0x10] & 0x2000) != 0) && (uStack_51c == 0)) {
                        uStack_51c = 4;
                        puVar21 = (uint *)0x15ba37c;
                      }
                      if ((((1 << (*(byte *)plVar38[1] & 0xe) & 0x440U) == 0) ||
                          (iVar14 = func_0x(puVar39), uVar15 = uStack_51c,
                          iVar14 == 0)) &&
                         (uVar15 = uStack_51c, *(ushort *)(puVar39 + 0xf) < uStack_51c)) {
                        (*_DAT_)(6,0x52,0x16,0x91);
                        uVar15 = uStack_51c;
                      }
                    }
LAB_:
                    uStack_51c = uVar15;
                    uStack_568 = (int *)CONCAT44(uStack_568._4_4_,uStack_51c);
                    func_0x
                              (*plStack_528,puVar39[10],*(undefined *)((longlong)puVar39 + 0x3e),
                               puVar21);
                  }
LAB_:
                  uVar15 = (int)puVar35 + 1;
                  puVar35 = (uint *)(ulonglong)uVar15;
                  puVar39 = puVar39 + 0x14;
                } while (uVar15 < uVar10);
                (**(code **)(*plStack_488 + 8))();
                plVar38 = plStack_528;
                param_1 = lStack_490;
                goto LAB_;
              }
            }
            (**(code **)(*plStack_488 + 8))();
            plVar38 = plStack_528;
            param_1 = lStack_490;
            goto LAB_;
          }
          plVar24 = plStack_528;
          param_3 = (longlong *)func_0x();
          plVar38 = plStack_528;
          if (plVar36[0x17a] == 0) goto LAB_;
          *(char *)param_3 = *(char *)param_3 + (char)param_3;
          *(char *)((longlong)param_3 + -0x75) =
               *(char *)((longlong)param_3 + -0x75) + (char)plVar24;
          goto code_r0x00101fde;
        }
        *(longlong **)(lStack_490 + 0x1b0) = uStack_4d0;
        *(longlong **)(lStack_490 + 0x1a8) = plVar36;
        lStack_2c0 = lVar28;
        if ((((acStack_510[0] == '\0') ||
             ((puVar26 == (undefined8 *)0x0 ||
              (cVar7 = (**(code **)*puVar26)(puVar26,lVar28), cVar7 != '\0')))) &&
            ((lVar33 == 0 ||
             (((**(code **)(lVar33 + 8))(&lStack_2c0,lVar33,pcVar2), *pcVar2 != '\x03' &&
              (*(char *)(param_1 + 0x400) != '\0')))))) &&
           ((cVar8 != '\0' ||
            ((puVar26 == (undefined8 *)0x0 ||
             (cVar8 = (**(code **)*puVar26)(puVar26,lVar28), cVar8 != '\0')))))) goto LAB_;
LAB_:
        param_1 = lStack_490;
        if ((*(int *)(lStack_2b0 + 0x68) == 0x10000) ||
           ((*(longlong *)(lStack_2b0 + 0x70) != 0 && (*(int *)(lStack_2b0 + 0x68) != 0x100000)))) {
          puVar21 = (uint *)(*(longlong *)(lStack_490 + 800) + 0x10);
          *puVar21 = *puVar21 | 0x4000;
        }
        (**(code **)(**(longlong **)(lStack_490 + 800) + 8))();
        param_3 = plStack_528;
      }
      if (*(int *)(*param_3 + 0x2c) <= *(int *)(*param_3 + 0x40) + 1) goto LAB_;
      puVar37 = (undefined4 *)(param_1 + 0x1d4);
      uVar34 = (ulonglong)uStack_4a0;
      param_2 = iStack_50c;
    } while( true );
  }
  goto LAB_;
LAB_:
  uVar34 = (ulonglong)uStack_4a0;
LAB_:
  if (aiStack_4c8[0] != 0) {
    (*_DAT_)(&uStack_320);
    lVar33 = uStack_320 - auStack_318[0];
    if (uStack_320 < auStack_318[0]) {
      lVar33 = 0;
    }
    func_0x(*param_3,acStack_510[0],uVar34,lVar33);
  }
  lVar33 = *(longlong *)(*(longlong *)(param_1 + 0x1e0) + 0x58);
  if (lVar33 != 0) {
    plVar36 = (longlong *)(lVar33 + 0x58);
    *plVar36 = *plVar36 + uVar34;
  }
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_588);
  return;
}

