
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,longlong param_3,undefined8 *param_4,
                 uint param_5,short **param_6,uint param_7,longlong *param_8,int param_9,
                 uint param_10,int param_11)

{
  ushort *puVar1;
  undefined2 uVar2;
  uint uVar3;
  uint *puVar4;
  bool bVar5;
  char cVar6;
  ushort uVar7;
  int iVar8;
  int iVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  ulonglong *puVar13;
  short *psVar14;
  undefined8 *puVar15;
  longlong *plVar16;
  undefined8 uVar17;
  byte bVar18;
  uint uVar19;
  code *UNRECOVERED_JUMPTABLE;
  ushort uVar20;
  uint uVar21;
  ulonglong uVar22;
  byte bVar23;
  ushort *puVar24;
  longlong **pplVar25;
  ulonglong uVar26;
  short sVar27;
  int iVar28;
  byte *pbVar29;
  longlong unaff_GS_OFFSET;
  bool bVar30;
  undefined auStack_728 [32];
  undefined8 uStack_708;
  undefined8 uStack_700;
  undefined8 uStack_6f8;
  undefined4 uStack_6f0;
  longlong *plStack_6e8;
  int iStack_6d8;
  char cStack_6d0;
  ushort auStack_6cc [2];
  short asStack_6c8 [2];
  uint uStack_6c4;
  undefined2 uStack_6c0;
  undefined4 uStack_6bc;
  byte *pbStack_6b8;
  undefined8 uStack_6b0;
  undefined8 uStack_6a2;
  undefined2 uStack_69a;
  undefined2 uStack_698;
  undefined6 uStack_696;
  uint uStack_688;
  longlong *plStack_680;
  longlong **pplStack_678;
  short **ppsStack_670;
  int iStack_668;
  longlong *plStack_660;
  undefined8 uStack_658;
  int iStack_650;
  longlong lStack_648;
  int iStack_640;
  longlong lStack_638;
  short sStack_630;
  undefined4 uStack_628;
  undefined2 uStack_624;
  short *psStack_620;
  undefined8 uStack_618;
  undefined8 *puStack_610;
  undefined2 uStack_608;
  undefined8 uStack_600;
  ushort uStack_5f8;
  undefined8 uStack_5f0;
  ushort uStack_5e8;
  undefined4 uStack_5e0;
  undefined2 uStack_5dc;
  undefined4 uStack_5d8;
  undefined2 uStack_5d4;
  undefined8 uStack_5d0;
  longlong lStack_5c8;
  undefined auStack_5b8 [96];
  undefined8 uStack_558;
  short sStack_550;
  undefined auStack_548 [2];
  undefined2 uStack_546;
  undefined4 uStack_538;
  undefined2 uStack_534;
  undefined uStack_532;
  undefined uStack_531;
  longlong lStack_518;
  int iStack_510;
  ushort uStack_50c;
  ushort uStack_50a;
  undefined2 auStack_508 [64];
  undefined auStack_488 [528];
  undefined auStack_278 [528];
  int aiStack_68 [4];
  undefined *apuStack_58 [3];
  ulonglong uStack_40;
  
  uStack_5d0 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_728;
  ppsStack_670 = param_6;
  plStack_680 = param_8;
  iStack_668 = 0;
  asStack_6c8[0] = 0;
  uStack_6c4 = 1;
  plStack_660 = (longlong *)0x0;
  uStack_688 = 0;
  uStack_658 = 0;
  auStack_6cc[0] = 0;
  psStack_620 = (short *)0x0;
  iStack_650 = 0;
  uStack_628 = 0;
  uStack_624 = 0;
  lStack_648 = 0;
  iStack_640 = 0;
  pplStack_678 = param_1;
  lStack_638 = param_3;
  uStack_618 = param_2;
  puStack_610 = param_4;
  cVar6 = (**(code **)(*param_8 + 8))();
  if (cVar6 == '\0') {
    uStack_708 = (longlong *)0x0;
    (*_DAT_)(1,0x149db48,0x14741e0,0x16d3);
  }
  if (param_11 == 0) {
    lVar10 = func_0x(_DAT_,*param_1,1,0);
    *(ushort *)(lVar10 + 4) = *(ushort *)(lVar10 + 4) & 0xedff;
    *(undefined4 *)(lVar10 + 0x40) = 1;
    plVar16 = *param_1;
    if (*(short *)((longlong)plVar16 + 0x2c) != 2) {
      lVar10 = plVar16[0x12];
      if (lVar10 == 0) {
        func_0x(plVar16);
        lVar10 = plVar16[0x12];
        plVar16 = *param_1;
      }
      if (((*(byte *)(*(longlong *)(lVar10 + 0x6b0) + 0x3c) & 1) != 0) &&
         (*(longlong *)(*(longlong *)(lVar10 + 0x6b0) + 0x280) == 0)) {
        lVar10 = plVar16[0x12];
        if (lVar10 == 0) {
          func_0x(plVar16);
          lVar10 = plVar16[0x12];
        }
        cVar6 = func_0x(lVar10);
        if (cVar6 == '\0') goto LAB_;
      }
      plVar16 = *param_1;
      lVar10 = plVar16[0x12];
      if (lVar10 == 0) {
        func_0x(plVar16);
        lVar10 = plVar16[0x12];
      }
      if ((*(byte *)(lVar10 + 0x1cd0) & 0x20) == 0) {
        lVar10 = **param_1;
        if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
          uStack_600 = *(undefined8 *)(lVar10 + 0x28);
          uStack_5f8 = *(ushort *)(lVar10 + 0x30);
        }
        else {
          cVar6 = *(char *)(lVar10 + 1);
          if (cVar6 == '\v') {
            if (*(int *)(lVar10 + 0x18) != 99) {
LAB_:
              if (cVar6 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar6 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar10 + 0x18) != 99) goto LAB_;
          }
          uStack_5e0 = *(undefined4 *)(lVar10 + 0x20);
          uStack_5dc = *(undefined2 *)(lVar10 + 0x24);
          cVar6 = func_0x(&uStack_5e0);
          if (cVar6 == '\0') goto LAB_;
          func_0x(lVar10,&uStack_600);
        }
        uVar7 = uStack_5f8;
        plVar16 = *param_1;
        lVar10 = plVar16[0x12];
        if (lVar10 == 0) {
          func_0x(plVar16);
          lVar10 = plVar16[0x12];
        }
        lVar11 = func_0x
                           (*(undefined8 *)(lVar10 + 0x6a0),
                            *(undefined2 *)((longlong)plVar16 + 0x74),0);
        plVar16 = *param_1;
        lVar10 = plVar16[0x12];
        if (lVar10 == 0) {
          func_0x(plVar16);
          lVar10 = plVar16[0x12];
          plVar16 = *param_1;
        }
        if (*(int *)(*(longlong *)(lVar10 + 0x7a8) + 0x58) == 0) {
          if ((uint)uStack_600 < *(uint *)(lVar11 + 0x130)) goto LAB_;
          if (*(uint *)(lVar11 + 0x130) == (uint)uStack_600) {
            if ((uStack_600._4_4_ < *(uint *)(lVar11 + 0x134)) ||
               ((*(uint *)(lVar11 + 0x134) == uStack_600._4_4_ &&
                (uVar7 < *(ushort *)(lVar11 + 0x138))))) goto LAB_;
          }
        }
        else {
LAB_:
          lVar10 = plVar16[0x12];
          if (lVar10 == 0) {
            func_0x(plVar16);
            lVar10 = plVar16[0x12];
            plVar16 = *param_1;
          }
          if (((*(byte *)(*(longlong *)(lVar10 + 0x6b0) + 0x3c) & 1) == 0) ||
             (*(longlong *)(*(longlong *)(lVar10 + 0x6b0) + 0x280) != 0)) {
            lVar10 = plVar16[0x12];
            if (lVar10 == 0) {
              func_0x(plVar16);
              lVar10 = plVar16[0x12];
              plVar16 = *param_1;
            }
            func_0x(lVar10,*plVar16 + 0x20);
            param_6 = ppsStack_670;
            goto LAB_;
          }
        }
        lVar10 = plVar16[0x12];
        if (lVar10 == 0) {
          func_0x(plVar16);
          lVar10 = plVar16[0x12];
          plVar16 = *param_1;
        }
        lVar11 = *plVar16;
        param_6 = ppsStack_670;
        if ((*(int *)(*(longlong *)(lVar10 + 0x7a8) + 0x110) != 0) &&
           (uVar19 = *(uint *)(lVar11 + 0x20) & 0xfffffff8, uVar19 != (uVar19 / 0x7cd00) * 0x7cd00))
        {
          lVar10 = plVar16[0x12];
          if (lVar10 == 0) {
            func_0x(plVar16);
            lVar10 = plVar16[0x12];
            lVar11 = **param_1;
          }
          func_0x(*(undefined8 *)(lVar10 + 0x7a8),lVar11 + 0x20);
          param_6 = ppsStack_670;
        }
      }
    }
LAB_:
    lVar10 = **param_1;
    if ((*(ushort *)(lVar10 + 4) & 0x2000) != 0) {
      if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
        uStack_5f0 = *(undefined8 *)(lVar10 + 0x28);
        uStack_5e8 = *(ushort *)(lVar10 + 0x30);
      }
      else {
        cVar6 = *(char *)(lVar10 + 1);
        if (cVar6 == '\v') {
          if (*(int *)(lVar10 + 0x18) != 99) {
LAB_:
            if (cVar6 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar6 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar10 + 0x18) != 99) goto LAB_;
        }
        uStack_5d8 = *(undefined4 *)(lVar10 + 0x20);
        uStack_5d4 = *(undefined2 *)(lVar10 + 0x24);
        cVar6 = func_0x(&uStack_5d8);
        if (cVar6 == '\0') goto LAB_;
        func_0x(lVar10,&uStack_5f0);
      }
      uVar7 = uStack_5e8;
      plVar16 = *param_1;
      lVar10 = plVar16[0x12];
      if (lVar10 == 0) {
        func_0x(plVar16);
        lVar10 = plVar16[0x12];
      }
      puVar4 = *(uint **)(*(longlong *)(lVar10 + 0x6b0) + 0x2c0);
      if (((*(short *)((longlong)puVar4 + 10) != 2) || ((uint)uStack_5f0 != 0)) &&
         ((uint)uStack_5f0 <= *puVar4)) {
        if ((uint)uStack_5f0 == *puVar4) {
          if ((puVar4[1] < uStack_5f0._4_4_) ||
             ((uStack_5f0._4_4_ == puVar4[1] && (*(ushort *)(puVar4 + 2) < uVar7))))
          goto LAB_;
        }
        func_0x(param_1);
      }
    }
  }
LAB_:
  uVar19 = 0;
  lVar10 = **param_1;
  cStack_6d0 = *(char *)(lVar10 + 2);
  if ((param_5 < *(ushort *)(lVar10 + 0x16)) &&
     (uVar7 = *(ushort *)(lVar10 + (0xfff - (longlong)(int)param_5) * 2), uVar7 != 0)) {
    iStack_6d8 = 0;
    uStack_6bc = 0;
    uStack_6a2 = 0;
    uStack_698 = 0;
    uStack_696 = 0;
    uStack_6b0 = 0;
    pbStack_6b8 = (byte *)(lVar10 + (ulonglong)uVar7);
    if ((*pbStack_6b8 & 1) != 0) {
      uStack_6c0 = 1;
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_6b8 & 0x1c) + 0x102834)
                              * 4 + 0x102824) - 0x144e0d0);
                    /* WARNING: Could not emulate address calculation at 0x001004eb */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
    uStack_6c0 = 0;
    uStack_69a = 0;
    uStack_698 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010068e */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_6b8 & 0xe) * 4 + 0x102854) - 0x144e0d0)
    )();
    return;
  }
  iStack_6d8 = 0;
  if (param_6 != (short **)0x0) {
    psVar14 = *param_6;
    puVar1 = (ushort *)(psVar14 + 1);
    psStack_620 = psVar14;
    if (*psVar14 == 0) {
      if (*(int *)(psVar14 + 2) == 0) {
        *puVar1 = 0;
        uVar19 = *(uint *)(psVar14 + 8);
        uVar22 = (ulonglong)uVar19;
        *(uint *)(psVar14 + 10) = uVar19;
        pbVar29 = *(byte **)(psVar14 + 4);
        bVar18 = *pbVar29;
        if ((bVar18 & 0x10) != 0) {
          uVar19 = uVar19 + 2 + (*(ushort *)(pbVar29 + uVar22) + 7 >> 3);
          uVar22 = (ulonglong)uVar19;
          *(uint *)(psVar14 + 10) = uVar19;
          bVar18 = *pbVar29;
        }
        if ((bVar18 & 0x20) == 0) {
          *(int *)(psVar14 + 2) = (int)uVar22;
          psVar14[0xe] = 0;
          *(int *)(psVar14 + 0xc) = (int)uVar22;
        }
        else {
          puVar24 = (ushort *)(pbVar29 + uVar22);
          uVar7 = *puVar24;
          psVar14[0xe] = uVar7;
          if (uVar7 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x12ef278,0x140ef48,0x80f);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),3);
            uVar7 = psVar14[0xe];
            uVar22 = (ulonglong)*(uint *)(psVar14 + 10);
          }
          uVar19 = (int)uVar22 + (uVar7 + 1) * 2;
          *(uint *)(psVar14 + 0xc) = uVar19;
          if (0x1f9e < uVar19) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar11 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar11 != 0 &&
                ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                 (*(char *)(lVar11 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x12ef278,0x140ef48,0x816);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),4);
            uVar7 = psVar14[0xe];
            uVar19 = *(uint *)(psVar14 + 0xc);
          }
          uVar21 = puVar24[uVar7] & 0x7fff;
          *(uint *)(psVar14 + 2) = uVar21;
          if (uVar21 < uVar19) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x12ef278,0x140ef48,0x81d);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),4);
            uVar7 = psVar14[0xe];
            uVar21 = *(uint *)(psVar14 + 2);
          }
          if ((short)puVar24[(ulonglong)(uVar7 - 1) + 1] < 0) {
            lVar11 = *(longlong *)(psVar14 + 4);
            do {
              uVar22 = (ulonglong)uVar7;
              lVar12 = (ulonglong)*(uint *)(psVar14 + 10) + lVar11;
              if (uVar7 == 1) {
                uVar19 = *(uint *)(psVar14 + 0xc);
                uVar7 = *(ushort *)(lVar12 + uVar22 * 2);
                uVar21 = uVar19;
LAB_:
                if ((uVar7 & 0x7fff) < uVar19) goto LAB_;
              }
              else {
                uVar19 = *(ushort *)(lVar12 + -2 + uVar22 * 2) & 0x7fff;
                uVar21 = *(uint *)(psVar14 + 0xc);
                uVar7 = *(ushort *)(lVar12 + uVar22 * 2);
                if (uVar21 <= uVar19) goto LAB_;
LAB_:
                func_0x(lVar11,7);
                uVar21 = *(uint *)(psVar14 + 0xc);
              }
              if ((uVar19 < uVar21) || (uVar21 = *(uint *)(psVar14 + 2), uVar21 < uVar19))
              goto LAB_;
              lVar11 = *(longlong *)(psVar14 + 4);
              if (*(ushort *)((ulonglong)uVar19 + lVar11) == 5) {
                *puVar1 = *puVar1 | 2;
                psVar14[0xe] = psVar14[0xe] + -1;
                psVar14[0x15] = (short)uVar19;
                lVar11 = (ulonglong)(uVar19 & 0xffff) + *(longlong *)(psVar14 + 4);
                uVar7 = psVar14[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar11 + 2) & 0x4000) != 0) {
                  uVar7 = *(ushort *)(lVar11 + 2) & 0x3800 | psVar14[0x16] & 0xc7ffU;
                }
                psVar14[0x16] = uVar7;
                psVar14[0x16] = (uVar7 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar7;
                uVar22 = (ulonglong)*(uint *)(psVar14 + 2);
                pbVar29 = *(byte **)(psVar14 + 4);
                goto LAB_;
              }
              if (*(ushort *)((ulonglong)uVar19 + lVar11) < 0x400) break;
              *puVar1 = *puVar1 | 1;
              uVar7 = psVar14[0xe] - 1;
              psVar14[0xe] = uVar7;
              if ((uVar7 == 0) || (-1 < (short)puVar24[(ulonglong)(uVar7 - 1) + 1])) break;
            } while( true );
          }
          uVar22 = (ulonglong)uVar21;
          pbVar29 = *(byte **)(psVar14 + 4);
        }
LAB_:
        iVar8 = 0;
        if ((*pbVar29 & 0x40) == 0) {
          *(undefined4 *)(psVar14 + 0x13) = 0;
        }
        else {
          *(int *)(psVar14 + 0x13) = (int)uVar22;
          *(int *)(psVar14 + 2) = (int)uVar22 + 0xe;
          puVar13 = (ulonglong *)func_0x(puVar1);
          uVar22 = *puVar13;
          uVar20 = (ushort)(uVar22 >> 0x30);
          uVar7 = uVar20;
          if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
            uVar7 = uVar20 & 0xdfff;
            if ((uVar22 & 0x4000000000000000) != 0) {
              uVar7 = uVar20 | 0x2000;
            }
          }
          if (uVar7 == 0xfffc) {
            iVar8 = (int)((uVar22 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + iVar8;
          uVar22 = (ulonglong)*(uint *)(psVar14 + 2);
        }
        iVar8 = (int)uVar22;
        if ((*(ulonglong *)(psVar14 + 0xf) != 0) &&
           (*(ulonglong *)(psVar14 + 0xf) < uVar22 + *(longlong *)(psVar14 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar11 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar11 != 0 && (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0))
              && (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_708 = (longlong *)0x0;
              (*_DAT_)(1,0x12ef278,0x140ef48,0x877);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),0x12);
          iVar8 = *(int *)(psVar14 + 2);
        }
        if (0x3f3b < iVar8 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              func_0x(*(undefined8 *)(psVar14 + 4),5);
              goto LAB_;
            }
            uStack_708 = (longlong *)0x0;
            (*_DAT_)(1,0x12ef278,0x140ef48,0x87c);
          }
          func_0x(*(undefined8 *)(psVar14 + 4),5);
        }
      }
LAB_:
      uStack_688 = *(uint *)(psVar14 + 2);
      param_6 = ppsStack_670;
      if ((uStack_688 < 9) &&
         (((**(byte **)(psVar14 + 4) & 0xe) == 0 || ((**(byte **)(psVar14 + 4) & 0xe) == 0xc)))) {
        uStack_688 = 9;
      }
    }
    else {
      uStack_688 = *(uint *)(psVar14 + 2);
      if (uStack_688 == 0) {
        func_0x();
        uStack_688 = *(uint *)(psVar14 + 2);
      }
      if ((uStack_688 < 9) &&
         (((**(byte **)(psVar14 + 4) & 0x1c) == 0 || ((**(byte **)(psVar14 + 4) & 0x1c) == 0xc)))) {
        uStack_688 = 9;
      }
    }
    if (cStack_6d0 < '\0') {
      psVar14 = param_6[1];
    }
    else {
      psVar14 = *param_6;
    }
    puVar1 = (ushort *)(psVar14 + 1);
    if (*psVar14 == 0) {
      if (*(int *)(psVar14 + 2) == 0) {
        *puVar1 = 0;
        uVar19 = *(uint *)(psVar14 + 8);
        uVar22 = (ulonglong)uVar19;
        *(uint *)(psVar14 + 10) = uVar19;
        pbVar29 = *(byte **)(psVar14 + 4);
        bVar18 = *pbVar29;
        if ((bVar18 & 0x10) != 0) {
          uVar19 = uVar19 + 2 + (*(ushort *)(pbVar29 + uVar22) + 7 >> 3);
          uVar22 = (ulonglong)uVar19;
          *(uint *)(psVar14 + 10) = uVar19;
          bVar18 = *pbVar29;
        }
        if ((bVar18 & 0x20) == 0) {
          *(int *)(psVar14 + 2) = (int)uVar22;
          psVar14[0xe] = 0;
          *(int *)(psVar14 + 0xc) = (int)uVar22;
        }
        else {
          puVar24 = (ushort *)(pbVar29 + uVar22);
          uVar7 = *puVar24;
          psVar14[0xe] = uVar7;
          if (uVar7 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x12ef278,0x140ef48,0x80f);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),3);
            uVar7 = psVar14[0xe];
            uVar22 = (ulonglong)*(uint *)(psVar14 + 10);
          }
          uVar19 = (int)uVar22 + (uVar7 + 1) * 2;
          *(uint *)(psVar14 + 0xc) = uVar19;
          if (0x1f9e < uVar19) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar11 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar11 != 0 &&
                ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                 (*(char *)(lVar11 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x12ef278,0x140ef48,0x816);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),4);
            uVar7 = psVar14[0xe];
            uVar19 = *(uint *)(psVar14 + 0xc);
          }
          uVar21 = puVar24[uVar7] & 0x7fff;
          *(uint *)(psVar14 + 2) = uVar21;
          if (uVar21 < uVar19) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x12ef278,0x140ef48,0x81d);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),4);
            uVar7 = psVar14[0xe];
            uVar21 = *(uint *)(psVar14 + 2);
          }
          uVar22 = (ulonglong)uVar21;
          if ((short)puVar24[(ulonglong)(uVar7 - 1) + 1] < 0) {
            pbVar29 = *(byte **)(psVar14 + 4);
            do {
              uVar22 = (ulonglong)uVar7;
              uVar19 = *(uint *)(psVar14 + 10);
              if (uVar7 == 1) {
                uVar21 = *(uint *)(psVar14 + 0xc);
                uVar26 = (ulonglong)uVar21;
                uVar7 = *(ushort *)(pbVar29 + uVar22 * 2 + (ulonglong)uVar19);
LAB_:
                if ((uVar7 & 0x7fff) < (uint)uVar26) goto LAB_;
              }
              else {
                uVar26 = (ulonglong)
                         (*(ushort *)(pbVar29 + uVar22 * 2 + ((ulonglong)uVar19 - 2)) & 0x7fff);
                uVar21 = *(uint *)(psVar14 + 0xc);
                uVar7 = *(ushort *)(pbVar29 + uVar22 * 2 + (ulonglong)uVar19);
                if (uVar21 <= (*(ushort *)(pbVar29 + uVar22 * 2 + ((ulonglong)uVar19 - 2)) & 0x7fff)
                   ) goto LAB_;
LAB_:
                func_0x(pbVar29,7);
                uVar21 = *(uint *)(psVar14 + 0xc);
              }
              if (((uint)uVar26 < uVar21) ||
                 (uVar22 = (ulonglong)*(uint *)(psVar14 + 2), *(uint *)(psVar14 + 2) < (uint)uVar26)
                 ) goto LAB_;
              pbVar29 = *(byte **)(psVar14 + 4);
              if (*(ushort *)(pbVar29 + uVar26) == 5) {
                *puVar1 = *puVar1 | 2;
                psVar14[0xe] = psVar14[0xe] + -1;
                psVar14[0x15] = (short)uVar26;
                lVar11 = (uVar26 & 0xffff) + *(longlong *)(psVar14 + 4);
                uVar7 = psVar14[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar11 + 2) & 0x4000) != 0) {
                  uVar7 = *(ushort *)(lVar11 + 2) & 0x3800 | psVar14[0x16] & 0xc7ffU;
                }
                psVar14[0x16] = uVar7;
                psVar14[0x16] = (uVar7 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar7;
                uVar22 = (ulonglong)*(uint *)(psVar14 + 2);
                goto LAB_;
              }
              if (*(ushort *)(pbVar29 + uVar26) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar7 = psVar14[0xe] - 1;
              psVar14[0xe] = uVar7;
              if (uVar7 == 0) goto LAB_;
            } while ((short)puVar24[(ulonglong)(uVar7 - 1) + 1] < 0);
          }
          else {
LAB_:
            pbVar29 = *(byte **)(psVar14 + 4);
          }
        }
        iVar8 = 0;
        if ((*pbVar29 & 0x40) == 0) {
          *(undefined4 *)(psVar14 + 0x13) = 0;
        }
        else {
          *(int *)(psVar14 + 0x13) = (int)uVar22;
          *(int *)(psVar14 + 2) = (int)uVar22 + 0xe;
          puVar13 = (ulonglong *)func_0x(puVar1);
          uVar22 = *puVar13;
          uVar20 = (ushort)(uVar22 >> 0x30);
          uVar7 = uVar20;
          if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
            uVar7 = uVar20 & 0xdfff;
            if ((uVar22 & 0x4000000000000000) != 0) {
              uVar7 = uVar20 | 0x2000;
            }
          }
          if (uVar7 == 0xfffc) {
            iVar8 = (int)((uVar22 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + iVar8;
          uVar22 = (ulonglong)*(uint *)(psVar14 + 2);
        }
        iVar8 = (int)uVar22;
        if ((*(ulonglong *)(psVar14 + 0xf) != 0) &&
           (*(ulonglong *)(psVar14 + 0xf) < uVar22 + *(longlong *)(psVar14 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar11 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar11 != 0 && (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0))
              && (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_708 = (longlong *)0x0;
              (*_DAT_)(1,0x12ef278,0x140ef48,0x877);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),0x12);
          iVar8 = *(int *)(psVar14 + 2);
        }
        if (0x3f3b < iVar8 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_708 = (longlong *)0x0;
              (*_DAT_)(1,0x12ef278,0x140ef48,0x87c);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),5);
        }
      }
LAB_:
      uVar19 = *(uint *)(psVar14 + 2);
      if (uVar19 < 9) {
        bVar18 = **(byte **)(psVar14 + 4) & 0xe;
joined_r0x00101a6d:
        if ((bVar18 == 0) || (bVar18 == 0xc)) {
          uVar19 = 9;
        }
      }
    }
    else {
      uVar19 = *(uint *)(psVar14 + 2);
      if (uVar19 == 0) {
        func_0x();
        uVar19 = *(uint *)(psVar14 + 2);
      }
      if (uVar19 < 9) {
        bVar18 = **(byte **)(psVar14 + 4) & 0x1c;
        goto joined_r0x00101a6d;
      }
    }
  }
  uVar21 = param_10;
  if ((param_10 >> 0x12 & 1) != 0) {
    uStack_708 = (longlong *)0x0;
    (*_DAT_)(1,0x14a98a8,0x14741e0,0x16f5);
  }
  uStack_658 = *param_4;
  plVar16 = *param_1;
  if ((param_7 >> 0x16 & 1) == 0) {
    if (((*(uint *)((longlong)plVar16 + 100) >> 0x13 & 1) != 0) &&
       (1 < (byte)(*(char *)(**pplStack_678 + 1) - 3U))) {
      uStack_708 = (longlong *)0x0;
      (*_DAT_)(1,0x14a98e0,0x14741e0,0x9dd);
    }
    bVar5 = false;
  }
  else {
    lVar11 = plVar16[0x12];
    if (lVar11 == 0) {
      func_0x(plVar16);
      lVar11 = plVar16[0x12];
    }
    pplVar25 = pplStack_678;
    lVar11 = *(longlong *)(lVar11 + 0x6b0);
    sVar27 = *(short *)(lVar11 + 0x28);
    bVar5 = true;
    uVar21 = param_10;
    if (sVar27 == 2) {
      uVar3 = *(uint *)(**pplStack_678 + 0x18);
      uVar7 = *(ushort *)(**pplStack_678 + 6);
      if (((uVar3 & 0xe0000000) != 0x80000000) || (0xff < uVar7)) {
        if (uVar3 == _DAT_) {
          uVar20 = 0;
          if (uVar7 != 1) {
            uVar20 = uVar7;
          }
          uVar7 = _DAT_;
          if (_DAT_ == 1) {
            uVar7 = 0;
          }
          if (uVar20 == uVar7) {
            bVar5 = true;
            goto LAB_;
          }
        }
        if ((~*(uint *)(plStack_680 + 0x43) & 1) == 0) goto LAB_;
        bVar5 = true;
      }
    }
    else {
LAB_:
      if ((*(uint *)((longlong)*pplStack_678 + 100) >> 0x13 & 1) == 0) {
        if ((*(byte *)(lVar11 + 0x278) & 0xc) == 0) {
          if ((~*(uint *)(plStack_680 + 0x43) & 1) != 0) {
            (*_DAT_)(auStack_5b8);
            (*_DAT_)(auStack_278);
            (*_DAT_)(auStack_488);
            uVar17 = (*_DAT_)();
            lStack_5c8 = (*_DAT_)(uVar17,0,0x6c0);
            if (lStack_5c8 == 0) {
              puVar15 = (undefined8 *)0x0;
            }
            else {
              puVar15 = (undefined8 *)func_0x(lStack_5c8,0);
            }
            if (puVar15 == (undefined8 *)0x0) {
LAB_:
              plVar16 = (longlong *)(*_DAT_)();
              uStack_708 = (longlong *)CONCAT44(uStack_708._4_4_,0xffffffff);
              (**(code **)(*plVar16 + 0xa8))(plVar16,0x1328f20,0x21,1);
            }
            else {
              iVar8 = (*_DAT_)(auStack_5b8,puVar15);
              if (iVar8 == 0) {
                (**(code **)*puVar15)(puVar15,1);
                goto LAB_;
              }
              bVar18 = DAT_ >> 1;
              bVar23 = DAT_ >> 5;
              lVar12 = func_0x();
              (*_DAT_)(0x9c9,*(undefined2 *)
                                      (*(longlong *)(*(longlong *)(lVar12 + 0x50) + 0x48) + 0x10),0,
                               0);
              lVar12 = func_0x();
              (*_DAT_)(0xe15,*(undefined2 *)
                                      (*(longlong *)(*(longlong *)(lVar12 + 0x50) + 0x48) + 0x10),0,
                               0);
              (*_DAT_)(auStack_278,auStack_5b8,0x1328ef0);
              func_0x(lVar11,auStack_5b8);
              (*_DAT_)(auStack_488,auStack_5b8,0x1328ed0);
              func_0x(*pplStack_678,auStack_5b8,0);
              if ((bVar23 & 1) == 0) {
                lVar11 = func_0x();
                (*_DAT_)(0xe15,*(undefined2 *)
                                        (*(longlong *)(*(longlong *)(lVar11 + 0x50) + 0x48) + 0x10),
                                 0,0);
              }
              pplVar25 = pplStack_678;
              if ((bVar18 & 1) == 0) {
                lVar11 = func_0x();
                (*_DAT_)(0x9c9,*(undefined2 *)
                                        (*(longlong *)(*(longlong *)(lVar11 + 0x50) + 0x48) + 0x10),
                                 0,0);
                pplVar25 = pplStack_678;
              }
            }
            if ((~*(uint *)(plStack_680 + 0x43) & 1) != 0) {
              uStack_708 = (longlong *)0x0;
              (*_DAT_)(1,0x14a97b8,0x14741e0,0x9ae);
            }
            (*_DAT_)(auStack_488);
            (*_DAT_)(auStack_278);
            (*_DAT_)();
          }
          if (((*(uint *)((longlong)*pplVar25 + 100) >> 0x13 & 1) != 0) &&
             (1 < (byte)(*(char *)(**pplVar25 + 1) - 3U))) {
            uStack_708 = (longlong *)0x0;
            (*_DAT_)(1,0x14a98e0,0x14741e0,0x9b8);
          }
        }
        else {
          if ((*(uint *)((longlong)*pplStack_678 + 100) >> 0x13 & 1) != 0) goto LAB_;
          if ((~*(uint *)(plStack_680 + 0x43) & 1) != 0) {
            uStack_708 = (longlong *)0x0;
            (*_DAT_)(1,0x14a97b8,0x14741e0,0x958);
          }
          plVar16 = *pplVar25;
          if ((((*(byte *)(*plVar16 + 4) & 0x20) != 0) &&
              ((*(uint *)((longlong)plVar16 + 100) & 2) != 0)) && (sVar27 != 2)) {
            uStack_708 = (longlong *)0x0;
            (*_DAT_)(1,0x14a9a90,0x14741e0,0x96a);
          }
        }
        bVar5 = false;
        uVar21 = param_10;
      }
      else {
        bVar5 = true;
      }
    }
  }
LAB_:
  if (*(char *)(lVar10 + 1) == '\x03') {
LAB_:
    iVar8 = 0;
LAB_:
    iVar9 = func_0x(plStack_680);
    if (iVar9 == 0) {
      (**(code **)(*plStack_680 + 0x270))();
    }
    func_0x(plStack_680[6] + 0x19c8);
    iVar9 = iStack_6d8;
    uStack_708 = plStack_680 + 5;
    iVar28 = 0;
    lVar11 = (ulonglong)*(ushort *)(lVar10 + 0x16) - 1;
    if (-1 < lVar11) {
      psVar14 = (short *)(lVar10 + (0xfff - lVar11) * 2);
      do {
        if (*psVar14 != 0) break;
        iVar28 = iVar28 + 1;
        psVar14 = psVar14 + 1;
        lVar11 = lVar11 + -1;
      } while (-1 < lVar11);
    }
    iStack_650 = (uint)*(ushort *)(lVar10 + 0x1c) + iVar28 * 2;
    uStack_6c4 = ~(uVar21 >> 0xf) & 0x10;
    bVar18 = (byte)*(undefined2 *)(lVar10 + 4);
    if (iStack_6d8 == 0) {
      uVar21 = 0;
    }
    else {
      iVar28 = (1 << (bVar18 & 2)) + -1;
      uVar21 = iVar28 + iStack_6d8 & 0xffffU & (uint)(ushort)~(ushort)iVar28;
    }
    iVar28 = (1 << (bVar18 & 2)) + -1;
    uStack_6f8 = auStack_6cc;
    uStack_700 = (longlong *)&uStack_628;
    plStack_660 = uStack_708;
    func_0x
              (lVar10,uVar21,
               (uVar21 - iStack_6d8) + uVar19 + iVar28 & 0xffff & (uint)(ushort)~(ushort)iVar28,
               uStack_6c4);
  }
  else {
    if ((*(char *)(lVar10 + 1) == '\x01') && ((param_7 & 1) == 0)) {
      if (((*(uint *)(lVar10 + 0x18) & 0xe0000000) != 0x80000000) ||
         (iVar8 = 1, 0xff < *(ushort *)(lVar10 + 6))) goto LAB_;
      goto LAB_;
    }
    iVar8 = 2;
    iVar9 = iStack_6d8;
  }
  if (iVar9 == 0) {
    uStack_6f8 = (ushort *)asStack_6c8;
    uStack_700 = (longlong *)&iStack_668;
    uStack_708 = plStack_660;
    iVar9 = func_0x(lVar10,param_5,uVar19,uStack_6c4);
  }
  else {
    plStack_6e8 = plStack_660;
    uStack_6f0 = uStack_6c4;
    uStack_6f8 = (ushort *)asStack_6c8;
    uStack_700 = (longlong *)&iStack_668;
    uStack_708 = (longlong *)((ulonglong)uStack_708 & 0xffffffff00000000);
    iVar9 = func_0x(lVar10,param_5,iVar9,uVar19);
  }
  if (iVar9 != 0) goto LAB_;
  param_10 = param_10 & 0x200;
  if (param_10 != 0) {
    auStack_6cc[0] = auStack_6cc[0] | 0x200;
  }
  if (param_9 != 0) {
    func_0x(&lStack_648,uStack_618);
  }
  if (iVar8 == 2) {
    if (psStack_620 != (short *)0x0) {
      pbVar29 = *(byte **)(psStack_620 + 4);
      if (*psStack_620 == 0) {
        bVar18 = *pbVar29 & 0xe;
        if (bVar18 == 2) {
          bVar30 = (pbVar29[1] & 1) != 0;
        }
        else {
          bVar30 = false;
          if (((bVar18 - 10 & 0xf9) == 0) && (bVar30 = false, bVar18 != 0x10)) {
            bVar30 = true;
          }
        }
      }
      else {
        bVar30 = ((*pbVar29 & 0x1c) - 4 & 0xffffffe7) == 0;
      }
      if (bVar30) {
        if (*(short *)(lVar10 + 0x3a) == 0) goto LAB_;
        if ((*(short *)(lVar10 + 0x3a) == 1) && (*(int *)(lVar10 + 8) == 0)) {
          bVar30 = *(short *)(lVar10 + 0xc) == 0;
          goto LAB_;
        }
      }
    }
  }
  else {
    iVar28 = 0;
    iVar9 = 0;
    lVar11 = 0;
    while( true ) {
      iVar28 = iVar28 + 1;
      iVar9 = iVar9 + 1;
      lVar11 = lVar11 + 1;
      if ((int)(uint)*(ushort *)(lVar10 + 0x16) <= iVar9) break;
      psVar14 = (short *)(lVar10 + (0xfff - lVar11) * 2);
      while (*psVar14 == 0) {
        iVar9 = iVar9 + 1;
        lVar11 = lVar11 + 1;
        psVar14 = psVar14 + -1;
        if ((int)(uint)*(ushort *)(lVar10 + 0x16) <= iVar9) goto LAB_;
      }
      if (lVar11 == -1) break;
    }
LAB_:
    if (psStack_620 == (short *)0x0) {
      bVar30 = iVar28 == 1;
    }
    else {
      pbVar29 = *(byte **)(psStack_620 + 4);
      bVar30 = false;
      if (*psStack_620 == 0) {
        bVar18 = *pbVar29 & 0xe;
        if (bVar18 == 2) {
          bVar30 = (pbVar29[1] & 1) != 0;
        }
        else if (((bVar18 - 10 & 0xf9) == 0) && (bVar18 != 0x10)) {
          bVar30 = true;
        }
      }
      else {
        bVar30 = ((*pbVar29 & 0x1c) - 4 & 0xffffffe7) == 0;
      }
      if (!bVar30) goto LAB_;
      bVar30 = *(short *)(lVar10 + 0x3a) == 0;
    }
LAB_:
    if (bVar30) {
LAB_:
      if (((byte)*(undefined2 *)((longlong)*pplStack_678 + 0x62) >> 2 & 1) == 0) {
        func_0x
                  (*pplStack_678,(*(short *)((longlong)*pplStack_678 + 0x2c) != 2) + '\x02',1);
        LOCK();
        puVar4 = (uint *)(*(longlong *)(plStack_680[6] + 0x6b0) + 0x1540);
        *puVar4 = *puVar4 & 0xfffffff7;
        UNLOCK();
      }
    }
  }
LAB_:
  pplVar25 = pplStack_678;
  if (bVar5) {
    if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
      lStack_638 = *(longlong *)(lVar10 + 0x28);
      sStack_630 = *(short *)(lVar10 + 0x30);
    }
    else {
      cVar6 = *(char *)(lVar10 + 1);
      if (cVar6 == '\v') {
        if (*(int *)(lVar10 + 0x18) != 99) {
LAB_:
          if (cVar6 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar6 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar10 + 0x18) != 99) goto LAB_;
      }
      uStack_618 = CONCAT26(uStack_618._6_2_,*(undefined6 *)(lVar10 + 0x20));
      cVar6 = func_0x(&uStack_618);
      if (cVar6 == '\0') goto LAB_;
      func_0x(lVar10,&lStack_638);
    }
    pplVar25 = pplStack_678;
    plVar16 = *pplStack_678;
    lVar11 = plVar16[0x12];
    uStack_558 = lStack_638;
    sStack_550 = sStack_630;
    if (lVar11 == 0) {
      func_0x(plVar16);
      lVar11 = plVar16[0x12];
      plVar16 = *pplVar25;
    }
    func_0x(*(undefined8 *)(lVar11 + 0x758),plVar16,0);
    plVar16 = plStack_680;
    iVar9 = iStack_6d8;
  }
  else {
    uStack_538 = 0;
    uStack_534 = 0;
    uStack_50a = 0;
    uStack_532 = 0x7b;
    uVar2 = *(undefined2 *)((longlong)*pplStack_678 + 0x62);
    uStack_531 = func_0x(lVar10,param_7);
    uStack_700 = (longlong *)(CONCAT71(uStack_700._1_7_,(byte)uVar2 >> 3) & 0xffffffffffffff01);
    uStack_708 = (longlong *)((ulonglong)uStack_708 & 0xffffffffffff0000);
    func_0x(auStack_548,puStack_610,lVar10,param_5);
    plVar16 = plStack_680;
    iVar9 = iStack_6d8;
    lStack_518 = lStack_638;
    uStack_50c = auStack_6cc[0] & 0xfbff;
    iStack_510 = iStack_6d8 << 0x10;
    uVar7 = 1;
    if (ppsStack_670 == (short **)0x0) {
      auStack_508[uStack_50a] = 0;
    }
    else {
      auStack_508[uStack_50a] = (short)uStack_688;
      aiStack_68[1] = uStack_688;
      apuStack_58[1] = *(undefined **)(psStack_620 + 4);
      uVar7 = 2;
    }
    if (param_9 == 0) {
      auStack_508[(ushort)(uStack_50a + 1)] = 0;
    }
    else {
      auStack_508[(ushort)(uStack_50a + 1)] = 4;
      aiStack_68[uVar7] = 4;
      apuStack_58[uVar7] = (undefined *)&param_9;
      uVar7 = uVar7 + 1;
    }
    uStack_50a = uStack_50a + 2;
    uStack_546 = 0x3e;
    aiStack_68[0] = (uint)uStack_50a * 2 + 0x40;
    apuStack_58[0] = auStack_548;
    uStack_708 = &uStack_558;
    (**(code **)(*plStack_680 + 0x288))(plStack_680,uVar7,aiStack_68,apuStack_58);
    if ((DAT_ != '\0') || ((DAT_ & 0x10) != 0)) {
      uVar17 = func_0x();
      uStack_6f8 = (ushort *)((ulonglong)uStack_6f8 & 0xffffffffffff0000);
      uStack_700 = (longlong *)0x0;
      uStack_708 = (longlong *)((ulonglong)uStack_708 & 0xffffffffffff0000);
      func_0x(*pplVar25,uVar17);
    }
  }
  if (asStack_6c8[0] != 0) {
    sVar27 = 0;
    uVar7 = *(ushort *)(lVar10 + 0x16);
    lVar11 = (ulonglong)uVar7 - 1;
    if ((longlong)(ulonglong)(ushort)(uVar7 - asStack_6c8[0]) <= lVar11) {
      psVar14 = (short *)(lVar10 + (0xfff - lVar11) * 2);
      do {
        if (*psVar14 != 0) break;
        sVar27 = sVar27 + 1;
        lVar11 = lVar11 + -1;
        psVar14 = psVar14 + 1;
      } while ((longlong)(ulonglong)(ushort)(uVar7 - asStack_6c8[0]) <= lVar11);
    }
    *(ushort *)(lVar10 + 0x16) = uVar7 - sVar27;
    *(short *)(lVar10 + 0x1c) = *(short *)(lVar10 + 0x1c) + sVar27 * 2;
  }
  if (iStack_668 != 0) {
    uVar21 = 0xffffffff;
    if (iVar9 != 0) {
      uVar21 = param_5;
    }
    func_0x(lVar10,uVar21);
  }
  if (iVar9 == 0) {
    if (cStack_6d0 < '\0') {
      psVar14 = ppsStack_670[1];
    }
    else {
      psVar14 = *ppsStack_670;
    }
    uStack_700 = plStack_660;
    uStack_708 = (longlong *)CONCAT62(uStack_708._2_6_,auStack_6cc[0]);
    func_0x(lVar10,param_5,psVar14,uStack_6c4);
  }
  else if (ppsStack_670 == (short **)0x0) {
    uStack_708 = plStack_660;
    func_0x(lVar10,param_5,uStack_6c4,auStack_6cc[0]);
  }
  else {
    if (cStack_6d0 < '\0') {
      psVar14 = ppsStack_670[1];
    }
    else {
      psVar14 = *ppsStack_670;
    }
    plStack_6e8 = plStack_660;
    uStack_6f0 = CONCAT22(uStack_6f0._2_2_,auStack_6cc[0]);
    uStack_6f8 = (ushort *)CONCAT44(uStack_6f8._4_4_,uStack_6c4);
    uStack_700 = *(longlong **)(psVar14 + 4);
    uStack_708 = (longlong *)CONCAT44(uStack_708._4_4_,uVar19);
    func_0x(lVar10,param_5,0,iVar9);
  }
  if (((*(short *)(lVar10 + 0x30) != sStack_550) || (*(int *)(lVar10 + 0x28) != (int)uStack_558)) ||
     (*(int *)(lVar10 + 0x2c) != uStack_558._4_4_)) {
    *(longlong *)(lVar10 + 0x28) = uStack_558;
    *(short *)(lVar10 + 0x30) = sStack_550;
    *(ushort *)(lVar10 + 4) = *(ushort *)(lVar10 + 4) & 0xffdf;
  }
  puStack_610 = (undefined8 *)0x0;
  uStack_608 = 0;
  func_0x(_DAT_,*pplVar25,0,&puStack_610);
  lVar11 = lStack_648;
  if ((DAT_ & 2) != 0) {
    LOCK();
    *(uint *)((longlong)*pplVar25 + 100) = *(uint *)((longlong)*pplVar25 + 100) & 0xffffffef;
    UNLOCK();
  }
  lVar12 = (longlong)param_9;
  iVar9 = 0;
  if (param_9 != 0) {
    func_0x(*(undefined8 *)(lStack_648 + 8));
    func_0x(*(undefined8 *)(lVar11 + 8),lVar12);
    if (iStack_640 != 0) {
      func_0x(*(longlong *)(lVar11 + 8) + 0x630,2);
      iStack_640 = 0;
    }
    lStack_648 = 0;
    pplVar25 = pplStack_678;
  }
  if (iVar8 == 0) {
    lVar11 = (ulonglong)*(ushort *)(lVar10 + 0x16) - 1;
    if (-1 < lVar11) {
      psVar14 = (short *)(lVar10 + (0xfff - lVar11) * 2);
      iVar9 = 0;
      do {
        if (*psVar14 != 0) break;
        iVar9 = iVar9 + 1;
        psVar14 = psVar14 + 1;
        lVar11 = lVar11 + -1;
      } while (-1 < lVar11);
    }
    if (param_10 == 0) {
      uStack_700 = (longlong *)
                   CONCAT44(uStack_700._4_4_,(uint)*(ushort *)(lVar10 + 0x1c) + iVar9 * 2);
      uStack_708 = (longlong *)CONCAT44(uStack_708._4_4_,iStack_650);
      func_0x(pplVar25,&uStack_658,plVar16,1);
    }
  }
LAB_:
  if (lStack_648 != 0) {
    if (iStack_640 != 0) {
      func_0x(*(longlong *)(lStack_648 + 8) + 0x630,2);
      iStack_640 = 0;
    }
    lStack_648 = 0;
  }
  func_0x(uStack_40 ^ (ulonglong)auStack_728);
  return;
}

