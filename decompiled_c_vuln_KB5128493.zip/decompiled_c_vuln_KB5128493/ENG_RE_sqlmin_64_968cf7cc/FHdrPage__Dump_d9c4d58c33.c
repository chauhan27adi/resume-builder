
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2)

{
  byte *pbVar1;
  byte bVar2;
  ushort uVar3;
  short sVar4;
  uint uVar5;
  char cVar6;
  longlong lVar7;
  short *psVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  uint uVar9;
  undefined8 unaff_RBX;
  byte **ppbVar10;
  ulonglong uVar11;
  undefined4 uStackX_8;
  undefined4 uStack_18ac;
  undefined2 uStack_18a8;
  undefined8 uStack_18a0;
  undefined8 uStack_1898;
  undefined8 uStack_1508;
  undefined2 uStack_1500;
  undefined4 uStack_14f8;
  undefined2 uStack_14f4;
  ushort uStack_14f2;
  undefined8 uStack_14f0;
  short sStack_1488;
  undefined4 uStack_1484;
  byte *pbStack_1480;
  byte **ppbStack_1478;
  undefined8 uStack_146a;
  undefined2 uStack_1462;
  undefined2 uStack_1460;
  undefined6 uStack_145e;
  undefined4 uStack_1454;
  undefined auStack_1450 [16];
  undefined auStack_1440 [8];
  undefined8 uStack_1438;
  undefined8 uStack_1430;
  undefined6 uStack_1428;
  undefined2 uStack_1422;
  undefined6 uStack_1420;
  undefined2 uStack_141a;
  undefined8 uStack_1418;
  undefined auStack_1410 [16];
  undefined auStack_1400 [16];
  undefined auStack_13f0 [16];
  undefined8 uStack_13e0;
  undefined auStack_11c8 [4480];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  uStack_1898 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00001cd8 + lVar7) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar7);
  sStack_1488 = -1;
  pbStack_1480 = (byte *)0x0;
  uStack_1484 = 0;
  uStack_146a = 0;
  uStack_1460 = 0;
  uStack_145e = 0;
  ppbStack_1478 = (byte **)0x0;
  uStack_1454 = 0xffffffff;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100097;
  uStack_18a0 = param_2;
  (*_DAT_)(auStack_11c8);
  uStack_14f8 = 0;
  uStack_14f4 = 0;
  uStack_14f2 = uStack_14f2 & 0xffe0;
  uStack_14f0 = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1000d1;
  (*_DAT_)(auStack_11c8,param_2,0x13daa30);
  uVar3 = *(ushort *)(param_1 + 0x16);
  uVar9 = (uint)uVar3;
  if ((*(byte *)(param_1 + 4) & 8) != 0) {
    uVar11 = (ulonglong)(uint)uVar3;
    if (uVar3 == 0) goto LAB_;
    psVar8 = (short *)(param_1 + 0x1ffe);
    do {
      uVar5 = uVar9 - 1;
      if (*psVar8 != 0) {
        uVar5 = uVar9;
      }
      uVar9 = uVar5;
      psVar8 = psVar8 + -1;
      uVar11 = uVar11 - 1;
    } while (uVar11 != 0);
  }
  if ((int)uVar9 < 1) {
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100114;
    (*_DAT_)(param_2);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100124;
    (*_DAT_)(param_2,0x13daa10);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10012d;
    (*_DAT_)(param_2);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10013b;
    (*_DAT_)(auStack_11c8);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x11717c;
    func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar7));
    return;
  }
  uStack_1454 = 0;
  if (-1 < *(char *)(param_1 + 2)) goto LAB_;
  pbVar1 = (byte *)(param_1 + 0x60);
  if ((sStack_1488 == 0) || (ppbVar10 = ppbStack_1478, ppbStack_1478 == (byte **)0x0)) {
    uStack_1428 = 0;
    uStack_141a = 0;
    auStack_1400 = ZEXT816(0);
    auStack_1450 = ZEXT816(0);
    stack0xffffffffffffebc2 = SUB1614(ZEXT816(0),2);
    auStack_1440._0_2_ = 0xffff;
    uStack_1438 = 0;
    uStack_1422 = 0;
    uStack_1420 = 0;
    uStack_1418 = 0;
    uStack_1430 = 0;
    auStack_1410 = ZEXT816(0);
    auStack_13f0._0_12_ = ZEXT812(0);
    auStack_13f0._12_4_ = 0;
    uStack_13e0 = 0;
    ppbVar10 = (byte **)auStack_1450;
  }
  if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
    uStack_1508 = *(undefined8 *)(param_1 + 0x28);
    uStack_1500 = *(undefined2 *)(param_1 + 0x30);
  }
  else {
    cVar6 = *(char *)(param_1 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
    }
    uStack_18ac = *(undefined4 *)(param_1 + 0x20);
    uStack_18a8 = *(undefined2 *)(param_1 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100289;
    cVar6 = func_0x(&uStack_18ac);
    if (cVar6 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10029c;
    func_0x(param_1,&uStack_1508);
  }
  *ppbVar10 = pbVar1;
  *(undefined4 *)(ppbVar10 + 0xc) = (undefined4)uStack_1508;
  *(int *)((longlong)ppbVar10 + 100) = (int)((ulonglong)uStack_1508 >> 0x20);
  *(undefined2 *)(ppbVar10 + 0xd) = uStack_1500;
  *(undefined4 *)((longlong)ppbVar10 + 0x6c) = *(undefined4 *)(param_1 + 0x20);
  *(undefined2 *)(ppbVar10 + 0xe) = *(undefined2 *)(param_1 + 0x24);
  *(undefined2 *)((longlong)ppbVar10 + 0x72) = 0;
  bVar2 = *pbVar1;
  *(undefined4 *)((longlong)&uStackX_8 + lVar7) = *(undefined4 *)((ulonglong)bVar2 * 6 + 0x11a5740);
  uVar11 = (ulonglong)*(short *)((ulonglong)bVar2 * 6 + 0x11a5744);
  *(undefined2 *)(ppbVar10 + 2) = 0xffff;
  ppbVar10[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
  ppbVar10[7] = (byte *)0x0;
  ppbVar10[4] = (byte *)0x0;
  ppbVar10[9] = (byte *)0x0;
  ppbVar10[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar10 + 0xb) = 0;
  if ((**ppbVar10 & 2) != 0) {
    pbVar1 = pbVar1 + uVar11;
    if ((*pbVar1 & 1) == 0) {
      *(undefined2 *)(ppbVar10 + 2) = 0;
      ppbVar10[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar10 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100565 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x119e90) - 0x13946f0))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar10 + 2) = 1;
    ppbVar10[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x119e70) * 4 +
                           0x119e60) - 0x13946f0);
                    /* WARNING: Could not emulate address calculation at 0x00100373 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar10 & 4) != 0) {
    sVar4 = *(short *)((longlong)&uStackX_8 + lVar7 + 2);
    if (sVar4 != 0) {
      uVar11 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)sVar4 * 2);
    }
    psVar8 = (short *)(pbVar1 + uVar11);
    ppbVar10[9] = (byte *)psVar8;
    sVar4 = *psVar8;
    ppbVar10[10] = (byte *)(psVar8 + 1);
    *(short *)(ppbVar10 + 0xb) = (sVar4 + 1) * 2;
  }
  pbVar1 = ppbVar10[1];
  if (pbVar1 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10061f;
    func_0x(pbVar1,ppbVar10);
  }
LAB_:
  pbStack_1480 = (byte *)((ulonglong)*(ushort *)(param_1 + 0x1ffe) + param_1);
  if ((*pbStack_1480 & 1) == 0) {
    sStack_1488 = 0;
    uStack_1484 = 0;
    uStack_1462 = 0;
    uStack_1460 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001008c2 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1480 & 0xe) * 4 + 0x119efc) - 0x13946f0
              ))(0x1125138);
    return;
  }
  sStack_1488 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1480 & 0x1c) + 0x119edc) * 4
                         + 0x119ecc) - 0x13946f0);
                    /* WARNING: Could not emulate address calculation at 0x00100675 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

