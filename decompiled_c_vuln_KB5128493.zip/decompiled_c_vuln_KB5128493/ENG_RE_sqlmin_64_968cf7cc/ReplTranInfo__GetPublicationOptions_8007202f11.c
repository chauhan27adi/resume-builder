
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  short *psVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  longlong lVar9;
  longlong unaff_GS_OFFSET;
  undefined auStack_1d8 [32];
  undefined8 uStack_1b8;
  undefined8 uStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined4 uStack_198;
  uint auStack_188 [2];
  int aiStack_180 [2];
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined8 uStack_170;
  undefined4 uStack_168;
  undefined auStack_160 [24];
  undefined auStack_148 [16];
  undefined auStack_138 [16];
  undefined auStack_128 [16];
  undefined auStack_118 [16];
  undefined auStack_108 [16];
  undefined8 uStack_f8;
  undefined8 uStack_e8;
  undefined auStack_e0 [16];
  undefined auStack_d0 [16];
  undefined auStack_c0 [24];
  longlong lStack_a8;
  undefined2 uStack_a0;
  undefined8 uStack_98;
  int iStack_90;
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  longlong lStack_48;
  uint uStack_40;
  undefined8 uStack_38;
  undefined8 uStack_30;
  ulonglong uStack_28;
  
  uStack_e8 = 0xfffffffffffffffe;
  uStack_28 = _DAT_ ^ (ulonglong)auStack_1d8;
  aiStack_180[0] = param_3;
  if (param_2 == 0) {
    if (param_3 == 0) goto LAB_;
  }
  else if (param_2 - 0x25U < 2) goto LAB_;
  psVar5 = *(short **)(_DAT_ + 0xd8);
  if (psVar5 != (short *)0x0) {
    do {
      if (*psVar5 == *(short *)(param_1 + 0x128)) {
        for (lVar9 = *(longlong *)(psVar5 + 0x10); lVar9 != 0; lVar9 = *(longlong *)(lVar9 + 0x18))
        {
          for (lVar1 = *(longlong *)(lVar9 + 0x10); lVar1 != 0; lVar1 = *(longlong *)(lVar1 + 0xed0)
              ) {
            if (*(int *)(lVar1 + 0xc) == param_3) goto LAB_;
          }
        }
      }
      psVar5 = *(short **)(psVar5 + 0x14);
    } while (psVar5 != (short *)0x0);
  }
  uVar7 = 0;
  uStack_170 = 0;
  uStack_178 = 0;
  uStack_168 = 1;
  auStack_160._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_160._8_8_ = 0;
  cVar2 = (**(code **)(*(longlong *)auStack_160._0_8_ + 0x1d0))();
  if (cVar2 == '\0') {
    uStack_198 = 0;
    uStack_1a0 = 0;
    uStack_1a8 = uStack_1a8 & 0xffffffffffffff00;
    uStack_1b0 = (undefined8 *)CONCAT44(uStack_1b0._4_4_,2);
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,1);
    (**(code **)(*(longlong *)auStack_160._0_8_ + 8))(auStack_160._0_8_,0x1a671d0,0x14,1);
    uStack_170 = CONCAT44(uStack_170._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_160._0_8_ + 0xe8))
              (auStack_160._0_8_,1,1,(longlong)&uStack_170 + 4);
    uStack_168 = 1;
    uStack_170 = CONCAT44(uStack_170._4_4_,4);
  }
  iVar3 = func_0x(*(undefined2 *)(param_1 + 0x128),0x1a668d0);
  if (iVar3 != 0) {
    uStack_98 = (**(code **)(*(longlong *)auStack_160._0_8_ + 0x1b0))();
    uStack_a0 = *(undefined2 *)(param_1 + 0x128);
    lStack_a8 = 0;
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    auStack_68 = ZEXT816(0);
    auStack_58 = ZEXT816(0);
    lStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    uStack_30 = 0;
    iStack_90 = iVar3;
    iVar3 = func_0x(&lStack_a8,3,1);
    if (iVar3 != 0) {
      auStack_188[0] = 4;
      auStack_c0._0_4_ = func_0x(&lStack_a8,0x1a671e8,auStack_188);
      auStack_e0 = ZEXT816(0);
      auStack_d0 = ZEXT816(0);
      auStack_c0._4_12_ = SUB1612(ZEXT816(0),4);
      uStack_f8 = 0;
      auStack_108 = ZEXT416(auStack_188[0]) << 0x40;
      auStack_138 = ZEXT816(0);
      auStack_148 = ZEXT416((uint)auStack_c0._0_4_);
      auStack_118._0_12_ = ZEXT412(1) << 0x40;
      auStack_118._12_4_ = 0;
      auStack_128._8_8_ = 0;
      auStack_128._0_8_ = auStack_e0;
      uStack_1a8 = 0;
      uStack_1b0 = &uStack_30;
      uStack_1b8 = 0;
      (**(code **)(*(longlong *)auStack_78._8_8_ + 0x20))(auStack_78._8_8_,2,1,auStack_148);
      uStack_1a8 = CONCAT44(uStack_1a8._4_4_,0x10);
      uStack_1b0 = (undefined8 *)aiStack_180;
      uStack_1b8 = 1;
      (**(code **)(*(longlong *)auStack_68._8_8_ + 0x28))(auStack_68._8_8_,uStack_30,1,aiStack_180);
      uStack_1b0 = (undefined8 *)lStack_a8;
      uStack_1b8 = uStack_38;
      (**(code **)(*(longlong *)auStack_88._8_8_ + 0x18))(auStack_88._8_8_,0,1,0);
      uStack_174 = 0;
      uVar6 = uVar7;
      if (lStack_a8 != 0) {
        uVar4 = func_0x(&lStack_a8,0x19c2088,&uStack_174);
        uVar8 = (ulonglong)uVar4;
        if (uVar8 == *(ulonglong *)((ulonglong)(uVar4 - 1) * 0x58 + lStack_48)) {
LAB_:
          uVar6 = 0;
          uVar7 = 0;
          if (uVar4 <= uStack_40) {
            lVar9 = (ulonglong)(uVar4 - 1) * 0x58 + lStack_48;
            uVar6 = *(ulonglong *)(lStack_a8 + *(longlong *)(lVar9 + 0x10));
            uVar7 = *(longlong *)(lVar9 + 8) + lStack_a8;
            if (4 < uVar6) goto LAB_;
          }
        }
        else {
          uVar4 = 1;
          if (uStack_40 != 0) {
            do {
              if (uVar8 == *(ulonglong *)((ulonglong)(uVar4 - 1) * 0x58 + lStack_48))
              goto LAB_;
              uVar4 = uVar4 + 1;
              uVar6 = 0;
            } while (uVar4 <= uStack_40);
          }
        }
      }
      func_0x(&uStack_178,uVar7,uVar6);
    }
LAB_:
    func_0x(&lStack_a8);
  }
  func_0x(&uStack_170,0);
  if ((int)uStack_170 != 0) {
    func_0x(&uStack_170,0);
  }
LAB_:
  func_0x(uStack_28 ^ (ulonglong)auStack_1d8);
  return;
}

