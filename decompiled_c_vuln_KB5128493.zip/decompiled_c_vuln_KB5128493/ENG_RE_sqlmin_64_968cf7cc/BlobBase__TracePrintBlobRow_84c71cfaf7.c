
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint param_2,undefined4 param_3,undefined8 param_4)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  undefined2 uVar4;
  undefined auVar5 [16];
  char cVar6;
  longlong lVar7;
  undefined *puVar8;
  undefined *puVar9;
  ulonglong *puVar10;
  undefined8 uVar11;
  int iVar12;
  undefined8 *puVar13;
  ushort uVar14;
  ushort uVar15;
  undefined *puVar16;
  ulonglong uVar17;
  ushort *puVar18;
  short sVar19;
  uint uVar20;
  ulonglong uVar21;
  uint uVar22;
  undefined4 uVar23;
  uint uVar24;
  uint uVar25;
  longlong unaff_GS_OFFSET;
  undefined auStack_318 [32];
  undefined8 uStack_2f8;
  uint uStack_2e8;
  undefined2 uStack_2e4;
  undefined2 uStack_2e2;
  undefined auStack_2e0 [8];
  undefined4 uStack_2d8;
  undefined2 uStack_2d4;
  uint uStack_2d0;
  undefined8 uStack_2c8;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined2 uStack_2b8;
  undefined2 uStack_2b6;
  undefined8 uStack_2b0;
  ushort *puStack_2a8;
  undefined8 uStack_2a0;
  undefined2 uStack_298;
  undefined8 uStack_290;
  undefined8 uStack_288;
  undefined auStack_280 [8];
  undefined auStack_278 [8];
  undefined auStack_270 [8];
  undefined auStack_268 [8];
  undefined auStack_260 [8];
  undefined auStack_258 [8];
  undefined auStack_250 [8];
  undefined auStack_248 [8];
  undefined auStack_240 [8];
  undefined auStack_238 [8];
  undefined auStack_230 [8];
  undefined auStack_228 [8];
  undefined auStack_220 [8];
  undefined auStack_218 [8];
  undefined auStack_210 [8];
  undefined auStack_208 [8];
  undefined auStack_200 [8];
  undefined auStack_1f8 [8];
  undefined auStack_1f0 [8];
  undefined auStack_1e8 [8];
  undefined auStack_1e0 [8];
  undefined auStack_1d8 [8];
  undefined auStack_1d0 [8];
  undefined auStack_1c8 [8];
  undefined auStack_1c0 [8];
  undefined auStack_1b8 [8];
  undefined auStack_1b0 [8];
  undefined auStack_1a8 [8];
  undefined auStack_1a0 [8];
  undefined auStack_198 [8];
  undefined auStack_190 [8];
  undefined auStack_188 [8];
  undefined auStack_180 [8];
  undefined auStack_178 [8];
  undefined auStack_170 [8];
  undefined auStack_168 [8];
  undefined auStack_160 [8];
  undefined auStack_158 [8];
  undefined8 uStack_150;
  short sStack_148;
  ushort uStack_146;
  uint uStack_144;
  byte *pbStack_140;
  undefined8 uStack_138;
  undefined4 uStack_130;
  ushort uStack_12c;
  undefined2 uStack_12a;
  undefined6 uStack_128;
  undefined2 uStack_122;
  undefined2 uStack_120;
  undefined2 uStack_11e;
  ushort uStack_11c;
  undefined2 uStack_11a;
  undefined4 uStack_118;
  uint uStack_114;
  undefined auStack_110 [16];
  undefined auStack_100 [2];
  undefined auStack_fe [2];
  undefined auStack_fc [12];
  uint uStack_f0;
  undefined4 uStack_ec;
  short sStack_e8;
  short sStack_e6;
  short sStack_e4;
  undefined2 uStack_e2;
  undefined6 uStack_e0;
  undefined2 uStack_da;
  undefined2 uStack_d8;
  undefined6 uStack_d6;
  uint uStack_d0;
  undefined4 uStack_cc;
  short *psStack_c8;
  short *psStack_c0;
  short sStack_b8;
  undefined6 uStack_b6;
  undefined auStack_b0 [10];
  undefined auStack_a6 [6];
  undefined8 uStack_a0;
  undefined8 auStack_98 [4];
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  ulonglong uStack_48;
  
  uStack_150 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_318;
  sStack_148 = -1;
  puVar16 = (undefined *)0x0;
  pbStack_140 = (byte *)0x0;
  uVar22 = 0;
  uStack_144 = 0;
  uStack_12a = 0;
  uStack_128 = 0;
  uStack_120 = 0;
  uStack_11e = 0;
  uStack_11c = 0;
  uStack_11a = 0;
  uStack_138 = (undefined *)0x0;
  auStack_98[0] = 0x153d9a8;
  auStack_98[1] = 0x153d928;
  auStack_98[2] = 0x153d938;
  auStack_98[3] = 0x153d9e4;
  uStack_78 = 0x153d9f0;
  uStack_70 = 0x153d9b8;
  uStack_68 = 0x153d9d0;
  uStack_60 = 0x12cab88;
  uStack_58 = 0x12ce724;
  cVar6 = *(char *)(param_1 + 1);
  uStack_2d0 = param_2;
  uStack_2c0 = param_3;
  uStack_290 = param_4;
  if ((byte)(cVar6 - 3U) < 2) {
    if ((param_2 < *(ushort *)(param_1 + 0x16)) &&
       (puStack_2a8 = (ushort *)((0xfff - (longlong)(int)param_2) * 2 + param_1), *puStack_2a8 != 0)
       ) {
      uStack_2e8 = 9;
      uVar23 = 0xf;
      uVar24 = 0xf;
      uVar20 = 0;
      puVar9 = puVar16;
      uStack_114 = param_2;
      if (*(char *)(param_1 + 2) < '\0') {
        pbVar1 = (byte *)(param_1 + 0x60);
        sStack_e8 = 0;
        sStack_e6 = 0;
        sStack_e4 = 0;
        uStack_da = 0;
        uStack_d0 = 0;
        uStack_cc = 0;
        psStack_c0 = (short *)0x0;
        sStack_b8 = 0;
        uStack_b6 = 0;
        auStack_110._8_8_ = 0;
        _auStack_fe = SUB1614(ZEXT816(0),2);
        auStack_100 = (undefined  [2])0xffff;
        auStack_fc._4_8_ = 0;
        uStack_e2 = 0;
        uStack_e0 = 0;
        uStack_d8 = 0;
        uStack_d6 = 0;
        uStack_f0 = 0;
        uStack_ec = 0;
        psStack_c8 = (short *)0x0;
        _auStack_b0 = ZEXT812(0);
        auStack_a6._2_4_ = 0;
        uStack_a0 = 0;
        uVar11 = 0;
        if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
          auStack_110._8_8_ = uVar11;
          uStack_2a0 = *(undefined8 *)(param_1 + 0x28);
          uStack_298 = *(undefined2 *)(param_1 + 0x30);
        }
        else {
          if (cVar6 == '\v') {
            if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
              if (cVar6 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar6 != '\b') goto LAB_;
LAB_:
            uVar11 = auStack_110._8_8_;
            if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
          }
          uStack_2d8 = *(undefined4 *)(param_1 + 0x20);
          uStack_2d4 = *(undefined2 *)(param_1 + 0x24);
          auStack_110 = ZEXT816(0);
          cVar6 = func_0x(&uStack_2d8);
          uVar11 = auStack_110._8_8_;
          if (cVar6 == '\0') goto LAB_;
          func_0x(param_1,&uStack_2a0);
        }
        auStack_110._0_8_ = pbVar1;
        auStack_b0._8_2_ = uStack_298;
        auStack_b0._0_8_ = uStack_2a0;
        auStack_a6._2_4_ = *(undefined4 *)(param_1 + 0x20);
        lVar7 = (ulonglong)*pbVar1 * 6;
        uStack_2d8 = *(undefined4 *)(lVar7 + 0x1322e00);
        uVar17 = (ulonglong)*(short *)(lVar7 + 0x1322e04);
        auStack_100 = (undefined  [2])0xffff;
        _auStack_100 = _auStack_100 & 0xffffffff;
        auStack_fc._4_8_ = 0;
        uStack_e2 = 0;
        uStack_e0 = 0;
        uStack_d8 = 0;
        uStack_d6 = 0;
        uStack_f0 = 0;
        uStack_ec = 0;
        psStack_c8 = (short *)0x0;
        psStack_c0 = (short *)0x0;
        sStack_b8 = 0;
        uVar25 = uStack_f0;
        if ((*pbVar1 & 2) != 0) {
          pbVar2 = pbVar1 + uVar17;
          auStack_fc._4_8_ = pbVar2;
          if ((*pbVar2 & 1) == 0) {
            auVar5._14_2_ = 0;
            auVar5._0_14_ = _auStack_fe;
            _auStack_100 = auVar5 << 0x10;
            uStack_da = 0;
            uStack_d8 = 0;
            uVar25 = uVar20;
            switch(*pbVar2 & 0xe) {
            default:
              uVar15 = *(ushort *)(pbVar2 + 2);
              uVar25 = (uint)uVar15;
              if (0x1f9d < uVar15 - 1) {
                func_0x(pbVar2,6);
              }
              break;
            case 4:
              uVar25 = 9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar25 = 1;
            }
          }
          else {
            bVar3 = *pbVar2;
            switch(bVar3 & 0x1c) {
            default:
              if ((char)pbVar2[1] < '\0') {
                sStack_e8 = 3;
                auStack_fe = (undefined  [2])
                             ((*(ushort *)(pbVar2 + 1) & 0x7f) << 8 | *(ushort *)(pbVar2 + 1) >> 8);
              }
              else {
                sStack_e8 = 2;
                auStack_fe = (undefined  [2])(ushort)pbVar2[1];
              }
              auStack_100 = (undefined  [2])0x1;
              sStack_e4 = (short)((ushort)auStack_fe + 1 >> 1) + sStack_e8;
              if ((ushort)auStack_fe < 0x1f) {
                sStack_e6 = 0;
                uStack_d0 = 0;
                uStack_d8 = 0;
                uStack_d6 = 0;
                uStack_f0 = 0;
                uStack_ec = 0;
                uVar25 = uStack_f0;
              }
              else {
                iVar12 = (ushort)auStack_fe - 1;
                sStack_e6 = ((short)(iVar12 / 0x1e) + (short)(iVar12 >> 0x1f)) -
                            (short)((longlong)iVar12 * 0x88888889 >> 0x3f);
                uStack_d0 = 0;
                uStack_d8 = 0;
                uStack_d6 = 0;
                uStack_f0 = 0;
                uStack_ec = 0;
                uVar25 = uStack_f0;
              }
              break;
            case 4:
              if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
                uStack_d0 = 1;
              }
              else {
                uVar23 = 1;
                uStack_d0 = uVar22;
              }
              sStack_e8 = 0;
              sStack_e6 = 0;
              sStack_e4 = 0;
              uStack_da = 0;
              auStack_fc._0_4_ = uVar23;
              _auStack_100 = 1;
              uStack_d8 = 0;
              uStack_d6 = 0;
              uStack_f0 = 0;
              uStack_ec = 0;
              uVar25 = uStack_f0;
              break;
            case 8:
              sStack_e8 = 0;
              sStack_e6 = 0;
              sStack_e4 = 0;
              uStack_da = 0;
              _auStack_100 = 0x900000001;
              uStack_d0 = 0;
              uStack_d8 = 0;
              uStack_d6 = 0;
              uStack_f0 = 0;
              uStack_ec = 0;
              uVar25 = uStack_f0;
            }
          }
        }
        uStack_f0 = uVar25;
        uStack_e0 = 0;
        uStack_e2 = 0;
        if ((*(byte *)auStack_110._0_8_ & 4) != 0) {
          if (uStack_2d8._2_2_ != 0) {
            uVar17 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)uStack_2d8._2_2_ * 2);
          }
          psStack_c8 = (short *)(pbVar1 + uVar17);
          psStack_c0 = psStack_c8 + 1;
          sStack_b8 = (*psStack_c8 + 1) * 2;
        }
        puVar9 = auStack_110;
        if (auStack_110._8_8_ != 0) {
          func_0x(auStack_110._8_8_,auStack_110);
        }
      }
      uVar25 = 9;
      sVar19 = 2;
      pbStack_140 = (byte *)((ulonglong)*puStack_2a8 + param_1);
      if ((*pbStack_140 & 1) == 0) {
        sStack_148 = 0;
        uStack_144 = 0;
        uStack_122 = 0;
        uStack_120 = 0;
        uVar22 = (uint)*(ushort *)(param_1 + 0xe);
        switch(*pbStack_140 & 0xe) {
        default:
          uVar15 = *(ushort *)(pbStack_140 + 2);
          uVar22 = (uint)uVar15;
          if (0x1f9d < uVar15 - 1) {
            func_0x(pbStack_140,6);
          }
          break;
        case 4:
          uVar22 = uVar25;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar22 = 1;
        }
        uStack_138 = (undefined *)CONCAT44(uStack_138._4_4_,uVar22);
        puVar9 = (undefined *)(param_1 + 0x2000);
        if (param_1 == 0) {
          puVar9 = puVar16;
        }
        uStack_12a = SUB82(puVar9,0);
        uStack_128 = (undefined6)((ulonglong)puVar9 >> 0x10);
        puVar9 = (undefined *)(ulonglong)uVar22;
        uVar24 = uStack_144;
      }
      else {
        sStack_148 = 1;
        bVar3 = *pbStack_140;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbStack_140[1] < '\0') {
            uStack_146 = (*(ushort *)(pbStack_140 + 1) & 0x7f) << 8 |
                         *(ushort *)(pbStack_140 + 1) >> 8;
            uStack_130._0_2_ = 3;
            sVar19 = 3;
          }
          else {
            uStack_146 = (ushort)pbStack_140[1];
            uStack_130._0_2_ = 2;
          }
          uStack_12c = (short)(uStack_146 + 1 >> 1) + sVar19;
          uVar24 = uVar22;
          if (uStack_146 < 0x1f) {
            uStack_130._2_2_ = 0;
            uStack_144 = 0;
            uStack_118 = 0;
          }
          else {
            iVar12 = uStack_146 - 1;
            uStack_130._2_2_ =
                 ((short)(iVar12 / 0x1e) + (short)(iVar12 >> 0x1f)) -
                 (short)((longlong)iVar12 * 0x88888889 >> 0x3f);
            uStack_144 = 0;
            uStack_118 = 0;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
            uStack_130._0_2_ = 0;
            uStack_130._2_2_ = 0;
            uStack_12c = 0;
            uStack_12a = 0;
            uStack_146 = 0;
            uStack_128 = 0;
            uStack_122 = 0;
            uStack_144 = 0xf;
            uStack_118 = 1;
          }
          else {
            uStack_130._0_2_ = 0;
            uStack_130._2_2_ = 0;
            uStack_12c = 0;
            uStack_12a = 0;
            uStack_146 = 0;
            uStack_128 = 0;
            uStack_122 = 0;
            uVar24 = 1;
            uStack_144 = 1;
            uStack_118 = 0;
          }
          break;
        case 8:
          uStack_130._0_2_ = 0;
          uStack_130._2_2_ = 0;
          uStack_12c = 0;
          uStack_12a = 0;
          uStack_146 = 0;
          uStack_128 = 0;
          uStack_122 = 0;
          uStack_144 = 9;
          uStack_118 = 0;
          uVar24 = uVar25;
        }
        puVar8 = (undefined *)(param_1 + 0x2000);
        if (param_1 == 0) {
          puVar8 = puVar16;
        }
        uStack_120 = SUB82(puVar8,0);
        uStack_11e = (undefined2)((ulonglong)puVar8 >> 0x10);
        uStack_11c = (ushort)((ulonglong)puVar8 >> 0x20);
        uStack_11a = (undefined2)((ulonglong)puVar8 >> 0x30);
        uStack_138 = puVar9;
      }
      uVar22 = CONCAT22(uStack_130._2_2_,(undefined2)uStack_130);
      if (sStack_148 == 0) {
        if (uVar24 == 0) {
          uStack_146 = 0;
          uVar24 = (uint)puVar9;
          if ((*pbStack_140 & 0x10) != 0) {
            uVar24 = uVar24 + 2 +
                     (*(ushort *)(pbStack_140 + ((ulonglong)puVar9 & 0xffffffff)) + 7 >> 3);
          }
          uStack_138 = (undefined *)CONCAT44(uVar24,(uint)uStack_138);
          if ((*pbStack_140 & 0x20) == 0) {
            uStack_12c = 0;
            uStack_144 = uVar24;
            uVar22 = uVar24;
          }
          else {
            puVar18 = (ushort *)(pbStack_140 + uVar24);
            uStack_12c = *puVar18;
            if (uStack_12c == 0) {
              if ((((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
                  (lVar7 = *(longlong *)
                            ((ulonglong)*puRam00000000011a4180 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0)) &&
                 ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                  (*(char *)(lVar7 + 0x499) != '\0')))) {
                if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                  (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_2f8 = 0;
                  (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x80f);
                }
              }
              func_0x(pbStack_140,3);
            }
            uStack_130 = uStack_138._4_4_ + 2 + (uint)uStack_12c * 2;
            if (0x1f9e < uStack_130) {
              if (((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
                 ((lVar7 = *(longlong *)
                            ((ulonglong)*puRam00000000011a4180 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0 &&
                  ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                   (*(char *)(lVar7 + 0x499) != '\0')))))) {
                if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                  (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2f8 = 0;
                  (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x816);
                }
              }
              func_0x(pbStack_140,4);
            }
            uStack_144 = puVar18[uStack_12c] & 0x7fff;
            uVar24 = uStack_144;
            uVar22 = uStack_130;
            if (uStack_144 < uStack_130) {
              if ((((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
                  (lVar7 = *(longlong *)
                            ((ulonglong)*puRam00000000011a4180 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0)) &&
                 ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                  (*(char *)(lVar7 + 0x499) != '\0')))) {
                if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                  (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2f8 = 0;
                  (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x81d);
                }
              }
              func_0x(pbStack_140,4);
              uVar24 = uStack_144;
              uVar22 = uStack_130;
            }
            do {
              if (-1 < (short)puVar18[(ulonglong)(uStack_12c - 1) + 1]) break;
              uVar25 = uStack_130;
              if (uStack_12c != 1) {
                uVar25 = *(ushort *)
                          (pbStack_140 +
                          (ulonglong)uStack_12c * 2 + (((ulonglong)uStack_138 >> 0x20) - 2)) &
                         0x7fff;
              }
              if ((uVar25 < uStack_130) ||
                 ((*(ushort *)
                    (pbStack_140 + (ulonglong)uStack_12c * 2 + ((ulonglong)uStack_138 >> 0x20)) &
                  0x7fff) < uVar25)) {
                uStack_130 = uVar22;
                func_0x(pbStack_140,7);
                uVar24 = uStack_144;
                uVar22 = uStack_130;
              }
              if ((uVar25 < uStack_130) || (uVar24 < uVar25)) goto code_r0x00100fbd;
              if (*(ushort *)(pbStack_140 + uVar25) == 5) {
                uStack_146 = uStack_146 | 2;
                uStack_12c = uStack_12c - 1;
                uStack_11e = (undefined2)uVar25;
                if ((*(ushort *)(pbStack_140 + (ulonglong)(uVar25 & 0xffff) + 2) & 0x4000) == 0) {
                  uStack_11c = uStack_11c & 0xc7ff;
                }
                else {
                  uStack_11c = uStack_11c ^
                               (*(ushort *)(pbStack_140 + (ulonglong)(uVar25 & 0xffff) + 2) ^
                               uStack_11c) & 0x3800;
                }
                uStack_11c = (uStack_11c ^
                             *(ushort *)(pbStack_140 + (ulonglong)(uVar25 & 0xffff) + 2)) & 0x7ff ^
                             uStack_11c;
                break;
              }
              if (*(ushort *)(pbStack_140 + uVar25) < 0x400) break;
              uStack_146 = uStack_146 | 1;
              uStack_12c = uStack_12c - 1;
            } while (uStack_12c != 0);
          }
          if ((*pbStack_140 & 0x40) == 0) {
            uStack_122 = 0;
            uStack_120 = 0;
          }
          else {
            uStack_122 = (undefined2)uVar24;
            uStack_120 = (undefined2)(uVar24 >> 0x10);
            uStack_144 = uVar24 + 0xe;
            uStack_130 = uVar22;
            puVar10 = (ulonglong *)func_0x(&uStack_146);
            uVar17 = *puVar10;
            uVar14 = (ushort)(uVar17 >> 0x30);
            uVar15 = uVar14;
            if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
              uVar15 = uVar14 & 0xdfff;
              if ((uVar17 & 0x4000000000000000) != 0) {
                uVar15 = uVar14 | 0x2000;
              }
            }
            uVar24 = uVar20;
            if (uVar15 == 0xfffc) {
              uVar24 = (uint)((uVar17 >> 0x20 & 0xffff) >> 5);
            }
            uVar24 = uStack_144 + uVar24;
            uStack_144 = uVar24;
            uVar22 = uStack_130;
          }
          uStack_130 = uVar22;
          if (((byte *)CONCAT62(uStack_128,uStack_12a) != (byte *)0x0) &&
             ((byte *)CONCAT62(uStack_128,uStack_12a) < pbStack_140 + uVar24)) {
            if (((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
               (((lVar7 = *(longlong *)
                           ((ulonglong)*puRam00000000011a4180 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0 &&
                 (lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0)) &&
                (*(char *)(lVar7 + 0x499) != '\0')))) {
              if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_2f8 = 0;
                (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x877);
              }
            }
            func_0x(pbStack_140,0x12);
            uVar24 = uStack_144;
          }
          uVar22 = uStack_130;
          if (0x3f3b < uVar24 - 1) {
            if (((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
               ((lVar7 = *(longlong *)
                          ((ulonglong)*puRam00000000011a4180 +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0 &&
                ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                 (*(char *)(lVar7 + 0x499) != '\0')))))) {
              if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_2f8 = 0;
                (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x87c);
              }
            }
            func_0x(pbStack_140,5);
            uVar24 = uStack_144;
            uVar22 = uStack_130;
          }
        }
code_r0x00100fbd:
        if ((uVar24 < 9) && (((*pbStack_140 & 0xe) == 0 || ((*pbStack_140 & 0xe) == 0xc)))) {
          uVar24 = 9;
        }
      }
      else {
        if (uVar24 == 0) {
          func_0x(&uStack_146);
          uVar24 = uStack_144;
        }
        uVar22 = CONCAT22(uStack_130._2_2_,(undefined2)uStack_130);
        if ((uVar24 < 9) && (((*pbStack_140 & 0x1c) == 0 || ((*pbStack_140 & 0x1c) == 0xc)))) {
          uVar24 = uVar25;
        }
      }
      pbVar1 = pbStack_140;
      bVar3 = *pbStack_140;
      uStack_130 = uVar22;
      if (sStack_148 == 0) {
        if ((bVar3 & 0xe) == 0xe) {
code_r0x00101073:
          (*_DAT_)(&uStack_2b0,0x1e2fb00);
          uVar11 = (*_DAT_)(&uStack_2b0);
          (*_DAT_)(auStack_278,uVar11);
          func_0x(uVar11);
          (*_DAT_)(auStack_278);
          if (sStack_148 == 0) {
            uVar24 = uStack_144;
            uVar22 = uStack_130;
            if (uStack_144 == 0) {
              uStack_146 = 0;
              uVar17 = (ulonglong)uStack_138 & 0xffffffff;
              uVar22 = (uint)uStack_138;
              if ((*pbStack_140 & 0x10) != 0) {
                uVar22 = (uint)uStack_138 + 2 + (*(ushort *)(pbStack_140 + uVar17) + 7 >> 3);
                uVar17 = (ulonglong)uVar22;
              }
              uStack_138 = (undefined *)CONCAT44(uVar22,(uint)uStack_138);
              uVar22 = (uint)uVar17;
              if ((*pbStack_140 & 0x20) == 0) {
                uStack_12c = 0;
                uStack_144 = uVar22;
              }
              else {
                puVar18 = (ushort *)(pbStack_140 + uVar17);
                uStack_12c = *puVar18;
                if (uStack_12c == 0) {
                  if ((((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
                      (lVar7 = *(longlong *)
                                ((ulonglong)*puRam00000000011a4180 +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0)) &&
                     ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                      (*(char *)(lVar7 + 0x499) != '\0')))) {
                    if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                      (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_2f8 = 0;
                      (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x80f);
                    }
                  }
                  func_0x(pbStack_140,3);
                }
                uStack_130 = uStack_138._4_4_ + 2 + (uint)uStack_12c * 2;
                if (0x1f9e < uStack_130) {
                  if (((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
                     ((lVar7 = *(longlong *)
                                ((ulonglong)*puRam00000000011a4180 +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0 &&
                      ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                       (*(char *)(lVar7 + 0x499) != '\0')))))) {
                    if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                      (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_2f8 = 0;
                      (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x816);
                    }
                  }
                  func_0x(pbStack_140,4);
                }
                uVar21 = (ulonglong)uStack_12c;
                uStack_144 = puVar18[uVar21] & 0x7fff;
                uVar17 = (ulonglong)uStack_144;
                uVar22 = uStack_130;
                if (uStack_144 < uStack_130) {
                  if ((((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
                      (lVar7 = *(longlong *)
                                ((ulonglong)*puRam00000000011a4180 +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0)) &&
                     ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                      (*(char *)(lVar7 + 0x499) != '\0')))) {
                    if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                      (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_2f8 = 0;
                      (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x81d);
                    }
                  }
                  func_0x(pbStack_140,4);
                  uVar21 = (ulonglong)uStack_12c;
                  uVar17 = (ulonglong)uStack_144;
                  uVar22 = uStack_130;
                }
                do {
                  if (-1 < (short)puVar18[(ulonglong)((int)uVar21 - 1) + 1]) break;
                  uVar25 = uStack_130;
                  if ((int)uVar21 != 1) {
                    uVar25 = *(ushort *)
                              (pbStack_140 + uVar21 * 2 + (((ulonglong)uStack_138 >> 0x20) - 2)) &
                             0x7fff;
                  }
                  if ((uVar25 < uStack_130) ||
                     ((*(ushort *)(pbStack_140 + uVar21 * 2 + ((ulonglong)uStack_138 >> 0x20)) &
                      0x7fff) < uVar25)) {
                    uStack_130 = uVar22;
                    func_0x(pbStack_140,7);
                    uVar21 = (ulonglong)uStack_12c;
                    uVar17 = (ulonglong)uStack_144;
                    uVar22 = uStack_130;
                  }
                  uVar24 = (uint)uVar17;
                  if ((uVar25 < uStack_130) || (uVar24 < uVar25)) goto code_r0x00101736;
                  if (*(ushort *)(pbStack_140 + uVar25) == 5) {
                    uStack_146 = uStack_146 | 2;
                    uStack_12c = (short)uVar21 - 1;
                    uStack_11e = (undefined2)uVar25;
                    if ((*(ushort *)(pbStack_140 + (ulonglong)(uVar25 & 0xffff) + 2) & 0x4000) == 0)
                    {
                      uStack_11c = uStack_11c & 0xc7ff;
                    }
                    else {
                      uStack_11c = uStack_11c ^
                                   (*(ushort *)(pbStack_140 + (ulonglong)(uVar25 & 0xffff) + 2) ^
                                   uStack_11c) & 0x3800;
                    }
                    uStack_11c = (uStack_11c ^
                                 *(ushort *)(pbStack_140 + (ulonglong)(uVar25 & 0xffff) + 2)) &
                                 0x7ff ^ uStack_11c;
                    break;
                  }
                  if (*(ushort *)(pbStack_140 + uVar25) < 0x400) break;
                  uStack_146 = uStack_146 | 1;
                  uStack_12c = (short)uVar21 - 1;
                  uVar21 = (ulonglong)uStack_12c;
                } while (uStack_12c != 0);
              }
              if ((*pbStack_140 & 0x40) == 0) {
                uStack_122 = 0;
                uStack_120 = 0;
              }
              else {
                uStack_122 = (undefined2)uVar17;
                uStack_120 = (undefined2)(uVar17 >> 0x10);
                uStack_144 = (int)uVar17 + 0xe;
                uStack_130 = uVar22;
                puVar10 = (ulonglong *)func_0x(&uStack_146);
                uVar17 = *puVar10;
                uVar14 = (ushort)(uVar17 >> 0x30);
                uVar15 = uVar14;
                if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
                  uVar15 = uVar14 & 0xdfff;
                  if ((uVar17 & 0x4000000000000000) != 0) {
                    uVar15 = uVar14 | 0x2000;
                  }
                }
                if (uVar15 == 0xfffc) {
                  uVar20 = (uint)((uVar17 >> 0x20 & 0xffff) >> 5);
                }
                uStack_144 = uStack_144 + uVar20;
                uVar17 = (ulonglong)uStack_144;
                uVar22 = uStack_130;
              }
              uVar24 = (uint)uVar17;
              uStack_130 = uVar22;
              if (((byte *)CONCAT62(uStack_128,uStack_12a) != (byte *)0x0) &&
                 ((byte *)CONCAT62(uStack_128,uStack_12a) < pbStack_140 + uVar17)) {
                if (((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
                   (((lVar7 = *(longlong *)
                               ((ulonglong)*puRam00000000011a4180 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0 &&
                     (lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0)) &&
                    (*(char *)(lVar7 + 0x499) != '\0')))) {
                  if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                    (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_2f8 = 0;
                    (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x877);
                  }
                }
                func_0x(pbStack_140,0x12);
                uVar24 = uStack_144;
              }
              uVar22 = uStack_130;
              if (0x3f3b < uVar24 - 1) {
                if (((cRam0000000001c358eb != '\0') || ((bRam0000000001c461f0 & 1) != 0)) &&
                   ((lVar7 = *(longlong *)
                              ((ulonglong)*puRam00000000011a4180 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000011a4178 * 8) + 8), lVar7 != 0 &&
                    ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 &&
                     (*(char *)(lVar7 + 0x499) != '\0')))))) {
                  if ((cRam0000000001c357db == '\0') && ((bRam0000000001c461f0 & 2) == 0)) {
                    (*pcRam00000000011a4118)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_2f8 = 0;
                    (*pcRam00000000011a4110)(1,0x1526318,0x1645fe8,0x87c);
                  }
                }
                func_0x(pbStack_140,5);
                uVar24 = uStack_144;
                uVar22 = uStack_130;
              }
            }
code_r0x00101736:
            uStack_130 = uVar22;
            if ((8 < uVar24) || (((*pbStack_140 & 0xe) != 0 && ((*pbStack_140 & 0xe) != 0xc)))) {
              uStack_2e8 = uVar24;
            }
          }
          else {
            if (uStack_144 == 0) {
              func_0x(&uStack_146);
            }
            if ((uStack_144 < 9) && (((*pbStack_140 & 0x1c) == 0 || ((*pbStack_140 & 0x1c) == 0xc)))
               ) {
              uStack_2e8 = 9;
            }
            else {
              uStack_2e8 = uStack_144;
            }
          }
          uVar22 = uStack_2d0;
          uStack_2bc = *(undefined4 *)(param_1 + 0x20);
          uStack_2b8 = *(undefined2 *)(param_1 + 0x24);
          uStack_2b6 = (undefined2)uStack_2d0;
          lVar7 = (*_DAT_)(&uStack_2b0);
          (*_DAT_)(auStack_270,lVar7);
          func_0x(lVar7 + 0x10,0x153da08);
          (*_DAT_)(auStack_270);
          (*_DAT_)(auStack_268,lVar7);
          func_0x(lVar7 + 0x10,0x153db58);
          (*_DAT_)(auStack_268);
          lVar7 = func_0x(lVar7,&uStack_2bc);
          (*_DAT_)(auStack_260,lVar7);
          func_0x(lVar7 + 0x10,0x153db60);
          (*_DAT_)(auStack_260);
          (*_DAT_)(auStack_258,lVar7);
          (*pcRam00000000011a4280)(lVar7 + 0x10,uVar22 & 0xffff);
          (*_DAT_)(auStack_258);
          (*_DAT_)(auStack_250,lVar7);
          func_0x(lVar7 + 0x10,0x153da18);
          (*_DAT_)(auStack_250);
          (*_DAT_)(auStack_248,lVar7);
          (*pcRam00000000011a4328)(lVar7 + 0x10,uStack_2e8);
          (*_DAT_)(auStack_248);
          (*_DAT_)(auStack_240,lVar7);
          func_0x(lVar7 + 0x10,0x153da70);
          (*_DAT_)(auStack_240);
          (*_DAT_)(auStack_238,lVar7);
          func_0x(lVar7);
          (*_DAT_)(auStack_238);
          if (sStack_148 == 0) {
            bVar3 = *pbStack_140 >> 6;
          }
          else {
            bVar3 = *pbStack_140 >> 1;
          }
          if ((bVar3 & 1) != 0) {
            func_0x(&sStack_148,uStack_290);
          }
          puVar13 = &uStack_2b0;
          goto LAB_;
        }
      }
      else if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) goto code_r0x00101073;
      uVar22 = *(ushort *)(pbStack_140 + 0xc) & 0xf;
      if (uVar22 < 9) {
        uStack_2c8 = auStack_98[uVar22];
      }
      else {
        uStack_2c8 = 0x153db50;
      }
      (*_DAT_)(auStack_2e0,0x1e2fb00);
      uVar11 = (*_DAT_)(auStack_2e0);
      (*_DAT_)(auStack_230,uVar11);
      func_0x(uVar11);
      (*_DAT_)(auStack_230);
      uVar20 = uStack_2d0;
      uStack_2e8 = *(uint *)(param_1 + 0x20);
      uStack_2e4 = *(undefined2 *)(param_1 + 0x24);
      uStack_2e2 = (undefined2)uStack_2d0;
      lVar7 = (*_DAT_)(auStack_2e0);
      (*_DAT_)(auStack_228,lVar7);
      func_0x(lVar7 + 0x10,0x153da08);
      (*_DAT_)(auStack_228);
      (*_DAT_)(auStack_220,lVar7);
      func_0x(lVar7 + 0x10,0x153db58);
      (*_DAT_)(auStack_220);
      lVar7 = func_0x(lVar7,&uStack_2e8);
      (*_DAT_)(auStack_218,lVar7);
      func_0x(lVar7 + 0x10,0x153db60);
      (*_DAT_)(auStack_218);
      (*_DAT_)(auStack_210,lVar7);
      (*pcRam00000000011a4280)(lVar7 + 0x10,uVar20 & 0xffff);
      (*_DAT_)(auStack_210);
      (*_DAT_)(auStack_208,lVar7);
      func_0x(lVar7 + 0x10,0x153da18);
      (*_DAT_)(auStack_208);
      (*_DAT_)(auStack_200,lVar7);
      (*pcRam00000000011a4328)(lVar7 + 0x10,uVar24);
      (*_DAT_)(auStack_200);
      (*_DAT_)(auStack_1f8,lVar7);
      func_0x(lVar7 + 0x10,0x153da88);
      (*_DAT_)(auStack_1f8);
      (*_DAT_)(auStack_1f0,lVar7);
      (*_DAT_)(lVar7 + 0x10,uVar22);
      (*_DAT_)(auStack_1f0);
      (*_DAT_)(auStack_1e8,lVar7);
      func_0x(lVar7 + 0x10,0x153da50);
      (*_DAT_)(auStack_1e8);
      (*_DAT_)(auStack_1e0,lVar7);
      func_0x(lVar7 + 0x10,uStack_2c8);
      (*_DAT_)(auStack_1e0);
      (*_DAT_)(auStack_1d8,lVar7);
      func_0x(lVar7 + 0x10,0x1501144);
      (*_DAT_)(auStack_1d8);
      (*_DAT_)(auStack_1d0,lVar7);
      func_0x(lVar7);
      (*_DAT_)(auStack_1d0);
      if (sStack_148 == 0) {
        bVar3 = *pbStack_140 >> 6;
      }
      else {
        bVar3 = *pbStack_140 >> 1;
      }
      if ((bVar3 & 1) != 0) {
        func_0x(&sStack_148,uStack_290);
      }
      switch(uVar22) {
      case 0:
        if (uVar24 < 0x14) {
          lVar7 = (*_DAT_)();
          (*_DAT_)(auStack_1c8,lVar7);
          func_0x(lVar7 + 0x10,0x153da58);
          (*_DAT_)(auStack_1c8);
          (*_DAT_)(auStack_1c0,lVar7);
          (*pcRam00000000011a4328)(lVar7 + 0x10,uVar24);
          (*_DAT_)(auStack_1c0);
          (*_DAT_)(auStack_1b8,lVar7);
          func_0x(lVar7);
          (*_DAT_)(auStack_1b8);
        }
        else {
          uVar11 = *(undefined8 *)(pbVar1 + 4);
          lVar7 = (*_DAT_)(auStack_2e0);
          (*_DAT_)(auStack_1b0,lVar7);
          func_0x(lVar7 + 0x10,0x153dab0);
          (*_DAT_)(auStack_1b0);
          (*_DAT_)(auStack_1a8,lVar7);
          (*pcRam00000000011a42a8)(lVar7 + 0x10,uVar11);
          (*_DAT_)(auStack_1a8);
          (*_DAT_)(auStack_1a0,lVar7);
          func_0x(lVar7 + 0x10,0x153dac0);
          (*_DAT_)(auStack_1a0);
          uVar4 = *(undefined2 *)(pbVar1 + 0xe);
          (*_DAT_)(auStack_198,lVar7);
          (*pcRam00000000011a42b0)(lVar7 + 0x10,uVar4);
          (*_DAT_)(auStack_198);
          (*_DAT_)(auStack_190,lVar7);
          func_0x(lVar7);
          (*_DAT_)(auStack_190);
          func_0x(pbVar1 + 0x14,*(undefined2 *)(pbVar1 + 0xe));
          uVar11 = (*_DAT_)(auStack_2e0);
          (*_DAT_)(auStack_188,uVar11);
          func_0x(uVar11);
          (*_DAT_)(auStack_188);
        }
        break;
      case 1:
      case 2:
      case 4:
      case 5:
      case 6:
        if (uVar24 < 0x14) {
          lVar7 = (*_DAT_)(auStack_2e0);
          (*_DAT_)(auStack_180,lVar7);
          func_0x(lVar7 + 0x10,0x153da58);
          (*_DAT_)(auStack_180);
          (*_DAT_)(auStack_178,lVar7);
          (*pcRam00000000011a4328)(lVar7 + 0x10,uVar24);
          (*_DAT_)(auStack_178);
          (*_DAT_)(auStack_170,lVar7);
          func_0x(lVar7);
          (*_DAT_)(auStack_170);
        }
        else {
          func_0x(pbVar1);
        }
        break;
      case 3:
        func_0x(pbVar1,uStack_2c0,uVar24 - 0xe);
      }
      (*_DAT_)(auStack_2e0);
      goto code_r0x00101f0c;
    }
    (*_DAT_)(&uStack_288,0x1e2fb00);
    lVar7 = (*_DAT_)(&uStack_288);
    (*_DAT_)(auStack_168,lVar7);
    func_0x(lVar7 + 0x10,0x153da40);
    (*_DAT_)(auStack_168);
    (*_DAT_)(auStack_160,lVar7);
    func_0x(lVar7);
    (*_DAT_)(auStack_160);
    puVar13 = &uStack_288;
  }
  else {
    (*_DAT_)(&uStack_2c8,0x1e2fb00);
    lVar7 = (*_DAT_)(&uStack_2c8);
    (*_DAT_)(auStack_158,lVar7);
    func_0x(lVar7 + 0x10,0x153da28);
    (*_DAT_)(auStack_158);
    (*_DAT_)(auStack_280,lVar7);
    (*_DAT_)(lVar7 + 0x10,cVar6);
    (*_DAT_)(auStack_280);
    (*_DAT_)(&puStack_2a8,lVar7);
    func_0x(lVar7);
    (*_DAT_)(&puStack_2a8);
    puVar13 = &uStack_2c8;
  }
LAB_:
  (*_DAT_)(puVar13);
code_r0x00101f0c:
  func_0x(uStack_48 ^ (ulonglong)auStack_318);
  return;
}

