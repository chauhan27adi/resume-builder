
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint *param_2,longlong *param_3)

{
  byte **ppbVar1;
  byte **ppbVar2;
  int *piVar3;
  short *psVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  byte *pbVar7;
  longlong lVar8;
  byte *pbVar9;
  code *pcVar10;
  bool bVar11;
  char cVar12;
  byte bVar13;
  undefined uVar14;
  ushort uVar15;
  undefined2 uVar16;
  int iVar17;
  int iVar18;
  uint uVar19;
  undefined4 uVar20;
  longlong lVar21;
  ushort *puVar22;
  undefined2 *puVar23;
  undefined8 uVar24;
  byte **ppbVar25;
  ulonglong uVar26;
  longlong lVar27;
  undefined8 uVar28;
  uint uVar29;
  uint *puVar30;
  longlong lVar31;
  undefined4 *puVar32;
  uint uVar33;
  uint uVar34;
  longlong *plVar35;
  longlong *plVar36;
  undefined8 *puVar37;
  int *piVar38;
  short sVar39;
  longlong **pplVar40;
  ushort *puVar41;
  short *psVar42;
  longlong lVar43;
  byte *pbVar44;
  ushort uVar45;
  ulonglong uVar46;
  longlong **pplVar47;
  longlong unaff_GS_OFFSET;
  char acStackX_8 [8];
  longlong *plStackX_10;
  char acStackX_18 [4];
  uint uStackX_1c;
  uint auStackX_20 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar21 = func_0x();
  lVar21 = -lVar21;
  *(undefined8 *)(&stack0x00001330 + lVar21) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002330 + lVar21) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar21);
  *(longlong **)(&stack0x00000208 + lVar21) = param_3;
  *(uint **)(&stack0x00000328 + lVar21) = param_2;
  *(longlong *)(&stack0x000000c8 + lVar21) = param_1;
  *(longlong *)(&stack0x000008d0 + lVar21) = param_1;
  *(undefined4 *)(&stack0x00000044 + lVar21) = 0;
  *(undefined2 *)(&stack0x00000048 + lVar21) = 0;
  *(undefined8 *)((longlong)&plStackX_10 + lVar21) = 0;
  acStackX_18[lVar21] = '\0';
  uVar29 = *(uint *)((longlong)&uStackX_1c + lVar21);
  *(uint *)((longlong)&uStackX_1c + lVar21) = uVar29 & 0xffff0000;
  *(uint *)((longlong)&uStackX_1c + lVar21) = uVar29 & 0xff000000;
  *(undefined4 *)((longlong)&uStackX_1c + lVar21) = 0;
  acStackX_8[lVar21] = '\x01';
  if (*(int *)(param_1 + 0xd0) != 2) {
LAB_:
    if (acStackX_8[lVar21] != '\0') {
      *(undefined4 **)(&stack0x00001338 + lVar21) = (undefined4 *)(param_1 + 0x170);
      *(undefined4 **)(&stack0x00001340 + lVar21) = (undefined4 *)(param_1 + 0x16c);
      *(undefined4 *)(param_1 + 0x16c) = 0;
      *(undefined4 *)(param_1 + 0x170) = 0;
      pplVar47 = (longlong **)(param_1 + 0x68);
      *(longlong ***)(&stack0x00001348 + lVar21) = pplVar47;
      if (((*pplVar47 != (longlong *)0x0) && (*(short *)(param_1 + 0x74) != 1)) ||
         (*(int *)(param_1 + 0x90) != 0)) goto LAB_;
      lVar27 = **(longlong **)(param_1 + 8);
      *(longlong *)(&stack0x00000678 + lVar21) = lVar27;
      *(longlong ***)(&stack0x00001350 + lVar21) = pplVar47;
      if ((*(int *)(param_1 + 0x80) != -1) || (bVar11 = true, *(int *)(param_1 + 0x90) != 0)) {
        bVar11 = false;
      }
      if (bVar11) {
LAB_:
        (&stack0x0000187c)[lVar21] = 0;
        uVar29 = (uint)(*(short *)(*(longlong *)(lVar27 + 8) + 0x3c4) != 1);
        *(uint *)(&stack0x00000750 + lVar21) = uVar29;
        iVar17 = *(int *)(param_1 + 0xf4);
        *(undefined8 *)((longlong)auStackX_20 + lVar21 + -0x20) = 0;
        *(undefined **)(&stack0xfffffffffffffff8 + lVar21) = &stack0x00001868 + lVar21;
        *(longlong ***)(&stack0xfffffffffffffff0 + lVar21) = pplVar47;
        *(uint *)(&stack0xffffffffffffffe8 + lVar21) = uVar29 + iVar17;
        uVar24 = *(undefined8 *)(param_1 + 0xa8);
        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10068b;
        func_0x(param_1,uVar24,0,0);
      }
      else {
        *(undefined4 *)(&stack0x00000954 + lVar21) = 0;
        *(undefined4 *)(&stack0x00000958 + lVar21) = 0;
        (&stack0xfffffffffffffff8)[lVar21] = 1;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar21) = 0;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar21) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10017a;
        func_0x(pplVar47,2,0xffffffff,&stack0x00000950 + lVar21);
        if (*(int *)(&stack0x00000954 + lVar21) != 0) {
          lVar43 = **pplVar47;
          *(longlong *)(&stack0x00001358 + lVar21) = lVar43;
          uVar14 = *(undefined *)(lVar43 + 1);
          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1001ac;
          func_0x(lVar27,uVar14,&stack0x00000950 + lVar21,0xffffffff);
        }
        lVar43 = **pplVar47;
        *(longlong *)(&stack0x00001360 + lVar21) = lVar43;
        *(int **)(&stack0x00001368 + lVar21) = (int *)(param_1 + 0xbc);
        lVar31 = **(longlong **)(param_1 + 8);
        puVar30 = (uint *)(lVar31 + 0x14);
        *(uint **)(&stack0x00001370 + lVar21) = puVar30;
        if (((*puVar30 & 0xe0000000) == 0x80000000) && (*(ushort *)(lVar31 + 0x18) < 0x100)) {
LAB_:
          *(undefined4 *)(&stack0x000005e0 + lVar21) = 1;
          *(longlong ***)(&stack0x00000550 + lVar21) = pplVar47;
          if (*pplVar47 != (longlong *)0x0) {
            puVar23 = (undefined2 *)((longlong)*pplVar47 + 0x62);
            *(undefined2 **)(&stack0x000013a0 + lVar21) = puVar23;
            *(undefined2 *)(&stack0x00000100 + lVar21) = *puVar23;
            plVar35 = *(longlong **)(&stack0x00000550 + lVar21);
            if (((*(ushort *)(&stack0x00000100 + lVar21) & 0x400) == 0) ||
               (*(short *)((longlong)plVar35 + 0xc) < 3)) {
              *(int *)(&stack0x000000a0 + lVar21) = (int)*(short *)((longlong)plVar35 + 0xc);
              lVar27 = *plVar35;
              *(longlong *)(&stack0x00000218 + lVar21) = lVar27;
              puVar23 = (undefined2 *)(lVar27 + 0x62);
              *(undefined2 **)(&stack0x000013a8 + lVar21) = puVar23;
              uVar16 = *puVar23;
              *(undefined2 *)(&stack0x00000108 + lVar21) = uVar16;
              if (((byte)uVar16 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000a0 + lVar21) == 3) {
                  *(undefined4 *)(&stack0x000000a0 + lVar21) = 4;
                }
                else if (*(int *)(&stack0x000000a0 + lVar21) < 2) goto LAB_;
                *(uint **)(&stack0x000013b0 + lVar21) =
                     (uint *)(*(longlong *)(&stack0x00000218 + lVar21) + 100);
                uVar29 = *(uint *)(*(longlong *)(&stack0x00000218 + lVar21) + 100);
                *(uint *)(&stack0x000005e8 + lVar21) = uVar29;
                if ((((uVar29 & 8) != 0) &&
                    (lVar27 = *(longlong *)(*(longlong *)(&stack0x00000218 + lVar21) + 0x90),
                    lVar27 != 0)) &&
                   (*(longlong *)(&stack0x000013b8 + lVar21) = lVar27,
                   *(longlong *)(lVar27 + 0x758) != 0)) {
                  uVar24 = *(undefined8 *)(lVar27 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1004a0;
                  func_0x
                            (uVar24,*(undefined8 *)(&stack0x00000218 + lVar21),
                             *(undefined4 *)(&stack0x000000a0 + lVar21));
                }
              }
LAB_:
              (&stack0x000001b0)[lVar21] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar30 = (uint *)(*(longlong *)(&stack0x00000218 + lVar21) + 100);
                *(uint **)(&stack0x000013c0 + lVar21) = puVar30;
                uVar29 = *puVar30;
                *(uint *)(&stack0x000005f0 + lVar21) = uVar29;
                if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x000000a0 + lVar21))) {
                  *(uint **)(&stack0x000013c8 + lVar21) = puVar30;
                  uVar29 = *puVar30;
                  *(uint *)(&stack0x000005f8 + lVar21) = uVar29;
                  if (((uVar29 & 0xc0000000) != 0x40000000) &&
                     (lVar27 = **(longlong **)(&stack0x00000218 + lVar21), lVar27 != 0)) {
                    *(undefined4 *)(&stack0x00000938 + lVar21) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100533;
                    iVar17 = (*_DAT_)(lVar27,0x2000,2,&stack0x00000738 + lVar21);
                    if (iVar17 != 0) {
                      LOCK();
                      *puVar30 = *puVar30 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar30 = *puVar30 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar27 = *(longlong *)(&stack0x00000218 + lVar21);
              uVar20 = *(undefined4 *)(&stack0x000000a0 + lVar21);
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100564;
              func_0x(lVar27 + 0x98,uVar20);
              if ((_DAT_ != 0) &&
                 ((&stack0x000001b1)[lVar21] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10058e;
                func_0x(lVar27,0,uVar20);
              }
              *(uint *)((longlong)plVar35 + 0xc) = *(uint *)((longlong)plVar35 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x00000550 + lVar21) = 0;
              param_1 = *(longlong *)(&stack0x000000c8 + lVar21);
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1003dc;
              func_0x(plVar35);
            }
            lVar27 = *(longlong *)(&stack0x00000678 + lVar21);
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          iVar17 = *(int *)(param_1 + 0xcc);
          if (iVar17 != 0) {
            *(int *)(&stack0x00000740 + lVar21) = iVar17;
            lVar31 = (longlong)*(int *)(param_1 + 200);
            *(int *)(&stack0x00000748 + lVar21) = *(int *)(param_1 + 200);
            lVar43 = *(longlong *)(lVar27 + 0x20);
            *(longlong *)(&stack0x000013d0 + lVar21) = lVar43;
            lVar43 = *(longlong *)(lVar43 + 0x6c10);
            *(longlong *)(&stack0x000013d8 + lVar21) = lVar43;
            if (lVar43 != 0) {
              if (iVar17 == 1) {
                plVar35 = (longlong *)(lVar43 + lVar31 * 0x28);
                *plVar35 = *plVar35 + 1;
              }
              else if (iVar17 == 2) {
                plVar35 = (longlong *)(lVar43 + 8 + lVar31 * 0x28);
                *plVar35 = *plVar35 + 1;
              }
              else if (iVar17 == 3) {
                plVar35 = (longlong *)(lVar43 + 0x18 + lVar31 * 0x28);
                *plVar35 = *plVar35 + 1;
              }
            }
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
          goto LAB_;
        }
        (&stack0x00000030)[lVar21] = 0;
        if (*(short *)(lVar43 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x00000290 + lVar21) = *(undefined8 *)(lVar43 + 0x28);
          sVar39 = *(short *)(lVar43 + 0x30);
          *(short *)(&stack0x00000298 + lVar21) = sVar39;
        }
        else {
          cVar12 = *(char *)(lVar43 + 1);
          if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
             (*(int *)(lVar43 + 0x18) == 99)) {
            *(undefined **)(&stack0x00001378 + lVar21) = &stack0x000002e0 + lVar21;
            *(undefined4 **)(&stack0x00001380 + lVar21) = (undefined4 *)(lVar43 + 0x20);
            *(undefined4 *)(&stack0x000002e0 + lVar21) = *(undefined4 *)(lVar43 + 0x20);
            *(undefined2 *)(&stack0x000002e4 + lVar21) = *(undefined2 *)(lVar43 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100260;
            cVar12 = func_0x(&stack0x000002e0 + lVar21);
            if (cVar12 == '\0') goto LAB_;
            cVar12 = '\x01';
          }
          else {
LAB_:
            cVar12 = '\0';
          }
          (&stack0x00000030)[lVar21] = cVar12;
          if (cVar12 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100282;
          func_0x(lVar43,&stack0x00000290 + lVar21);
          sVar39 = *(short *)(&stack0x00000298 + lVar21);
        }
        *(undefined **)(&stack0x00001388 + lVar21) = &stack0x00000290 + lVar21;
        if (((sVar39 != *(short *)(param_1 + 0xc4)) ||
            (*(int *)(&stack0x00000290 + lVar21) != *(int *)(param_1 + 0xbc))) ||
           (*(int *)(&stack0x00000294 + lVar21) != *(int *)(param_1 + 0xc0))) goto LAB_;
        *(undefined4 *)(&stack0x000005e0 + lVar21) = 0;
        iVar17 = *(int *)(param_1 + 0xcc);
        if (iVar17 == 0) goto LAB_;
        *(int *)(&stack0x00000928 + lVar21) = iVar17;
        lVar43 = (longlong)*(int *)(param_1 + 200);
        *(int *)(&stack0x00000930 + lVar21) = *(int *)(param_1 + 200);
        lVar27 = *(longlong *)(lVar27 + 0x20);
        *(longlong *)(&stack0x00001390 + lVar21) = lVar27;
        lVar27 = *(longlong *)(lVar27 + 0x6c10);
        *(longlong *)(&stack0x00001398 + lVar21) = lVar27;
        if (lVar27 == 0) {
LAB_:
          *(undefined4 *)(param_1 + 0xcc) = 0;
        }
        else {
          if (iVar17 == 1) {
            plVar35 = (longlong *)(lVar27 + 0x10 + lVar43 * 0x28);
            *plVar35 = *plVar35 + 1;
            goto LAB_;
          }
          if (iVar17 == 2) {
            plVar35 = (longlong *)(lVar27 + 8 + lVar43 * 0x28);
            *plVar35 = *plVar35 + 1;
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
          else {
            if (iVar17 != 3) goto LAB_;
            plVar35 = (longlong *)(lVar27 + 0x20 + lVar43 * 0x28);
            *plVar35 = *plVar35 + 1;
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
        }
      }
LAB_:
      if (*(int *)(param_1 + 0x90) == 0) {
        lVar27 = **pplVar47;
        *(longlong *)(&stack0x000000d0 + lVar21) = lVar27;
        *(longlong *)(&stack0x000006c8 + lVar21) = lVar27;
        *(uint *)(&stack0x00000288 + lVar21) = (uint)*(ushort *)(lVar27 + 0x16);
        iVar17 = *(int *)(*(longlong *)(&stack0x000000c8 + lVar21) + 0x80);
        *(int *)(&stack0x000000d8 + lVar21) = iVar17;
        *(int *)(&stack0x000001f0 + lVar21) = iVar17;
        acStackX_8[lVar21] = '\0';
LAB_:
        do {
          ppbVar25 = (byte **)0x0;
          uVar15 = *(ushort *)(lVar27 + (0xfff - (longlong)iVar17) * 2);
          *(ushort *)(&stack0x00000498 + lVar21) = uVar15;
          pbVar44 = (byte *)(lVar27 + (ulonglong)uVar15);
          *(byte **)(&stack0x000009f8 + lVar21) = pbVar44;
          bVar13 = *pbVar44;
          *(ushort *)(&stack0x0000049c + lVar21) = (ushort)(bVar13 & 1);
          if ((bVar13 & 1) == 0) {
            uVar29 = *param_2;
            *(uint *)(&stack0x00000768 + lVar21) = uVar29;
            piVar38 = (int *)(pbVar44 + (int)uVar29);
          }
          else {
            *(undefined2 *)(&stack0x000016e8 + lVar21) = 0xffff;
            *(undefined8 *)(&stack0x000016f0 + lVar21) = 0;
            *(undefined4 *)(&stack0x000016ec + lVar21) = 0;
            *(undefined8 *)(&stack0x00001706 + lVar21) = 0;
            *(undefined8 *)(&stack0x00001710 + lVar21) = 0;
            *(undefined8 *)(&stack0x000016f8 + lVar21) = 0;
            *(undefined4 *)(&stack0x0000171c + lVar21) = 0xffffffff;
            *(int *)(&stack0x0000171c + lVar21) = iVar17;
            if (*(char *)(lVar27 + 2) < '\0') {
              pbVar44 = (byte *)(lVar27 + 0x60);
              *(undefined8 *)(&stack0x00000a00 + lVar21) = 0;
              *(undefined8 *)(&stack0x00000680 + lVar21) = 0;
              *(undefined **)(&stack0x00000a08 + lVar21) = &stack0x00001720 + lVar21;
              *(undefined (*) [16])(&stack0x00001720 + lVar21) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001730 + lVar21) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001740 + lVar21) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001750 + lVar21) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001760 + lVar21) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001770 + lVar21) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001780 + lVar21) = ZEXT816(0);
              *(undefined8 *)(&stack0x00001790 + lVar21) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100adc;
              ppbVar25 = (byte **)func_0x(&stack0x00001720 + lVar21);
              *(byte ***)(&stack0x00000680 + lVar21) = ppbVar25;
              (&stack0x00000031)[lVar21] = 0;
              if (*(short *)(lVar27 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x000016b8 + lVar21) = *(undefined8 *)(lVar27 + 0x28);
                sVar39 = *(short *)(lVar27 + 0x30);
                *(short *)(&stack0x000016c0 + lVar21) = sVar39;
              }
              else {
                cVar12 = *(char *)(lVar27 + 1);
                if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                   (*(int *)(lVar27 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00000a10 + lVar21) = &stack0x000002e8 + lVar21;
                  *(undefined4 **)(&stack0x00000a18 + lVar21) = (undefined4 *)(lVar27 + 0x20);
                  *(undefined4 *)(&stack0x000002e8 + lVar21) = *(undefined4 *)(lVar27 + 0x20);
                  *(undefined2 *)(&stack0x000002ec + lVar21) = *(undefined2 *)(lVar27 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100b4e;
                  cVar12 = func_0x(&stack0x000002e8 + lVar21);
                  if (cVar12 == '\0') goto LAB_;
                  cVar12 = '\x01';
                }
                else {
LAB_:
                  cVar12 = '\0';
                }
                (&stack0x00000031)[lVar21] = cVar12;
                if (cVar12 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100b70;
                func_0x(lVar27,&stack0x000016b8 + lVar21);
                sVar39 = *(short *)(&stack0x000016c0 + lVar21);
              }
              *(undefined **)(&stack0x00000a20 + lVar21) = &stack0x000016b8 + lVar21;
              *(longlong *)(&stack0x00000a28 + lVar21) = lVar27 + 0x20;
              *(byte **)(&stack0x00000a30 + lVar21) = pbVar44;
              *(byte ***)(&stack0x00000a38 + lVar21) = ppbVar25;
              if (pbVar44 == *ppbVar25) {
                *(byte ***)(&stack0x00000a40 + lVar21) = ppbVar25 + 0xc;
                if (((sVar39 == *(short *)(ppbVar25 + 0xd)) &&
                    (*(int *)(&stack0x000016b8 + lVar21) == *(int *)(ppbVar25 + 0xc))) &&
                   (*(int *)(&stack0x000016bc + lVar21) == *(int *)((longlong)ppbVar25 + 100))) {
                  *(longlong *)(&stack0x00000a48 + lVar21) = (longlong)ppbVar25 + 0x6c;
                }
              }
              *ppbVar25 = pbVar44;
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100c13;
              func_0x(ppbVar25 + 0xc,&stack0x000016b8 + lVar21);
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100c1f;
              func_0x((longlong)ppbVar25 + 0x6c);
              bVar13 = *pbVar44;
              *(ushort *)(&stack0x000004a0 + lVar21) = (ushort)bVar13;
              lVar43 = (ulonglong)bVar13 * 6;
              *(undefined4 *)(&stack0x000006d0 + lVar21) = *(undefined4 *)(lVar43 + 0x15126a0);
              *(undefined2 *)(&stack0x000006d4 + lVar21) = *(undefined2 *)(lVar43 + 0x15126a4);
              *(undefined4 *)(&stack0x000004c0 + lVar21) = *(undefined4 *)(lVar43 + 0x15126a0);
              uVar46 = (ulonglong)*(short *)(lVar43 + 0x15126a4);
              *(short *)(&stack0x000004c4 + lVar21) = *(short *)(lVar43 + 0x15126a4);
              *(longlong *)(&stack0x00000a50 + lVar21) = lVar27 + 99;
              ppbVar1 = ppbVar25 + 2;
              *(byte ***)(&stack0x00000a58 + lVar21) = ppbVar1;
              *(undefined2 *)ppbVar1 = 0xffff;
              ppbVar25[3] = (byte *)0x0;
              uVar29 = 0;
              *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
              *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
              ppbVar25[7] = (byte *)0x0;
              ppbVar25[4] = (byte *)0x0;
              ppbVar2 = ppbVar25 + 9;
              *(byte ***)(&stack0x00000a60 + lVar21) = ppbVar2;
              *ppbVar2 = (byte *)0x0;
              ppbVar25[10] = (byte *)0x0;
              *(undefined2 *)(ppbVar25 + 0xb) = 0;
              if ((**ppbVar25 & 2) != 0) {
                pbVar9 = pbVar44 + uVar46;
                *(byte **)(&stack0x00000a68 + lVar21) = pbVar9;
                *(byte ***)(&stack0x00000a70 + lVar21) = ppbVar1;
                bVar13 = *pbVar9 & 1;
                *(ushort *)(&stack0x000004a8 + lVar21) = (ushort)bVar13;
                *(ushort *)ppbVar1 = (ushort)bVar13;
                puVar22 = (ushort *)((longlong)ppbVar25 + 0x12);
                if (bVar13 == 0) {
                  *(undefined4 *)(&stack0x000001c0 + lVar21) = 0;
                  *(ushort **)(&stack0x00000a78 + lVar21) = puVar22;
                  ppbVar25[3] = pbVar9;
                  *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                  *(undefined4 *)((longlong)ppbVar25 + 0x36) = 0;
                  pbVar7 = ppbVar25[3];
                  *(byte **)(&stack0x00000a80 + lVar21) = pbVar7;
                  switch(*pbVar7 & 0xe) {
                  default:
                    uVar15 = *(ushort *)(pbVar9 + 2);
                    uVar29 = (uint)uVar15;
                    *(uint *)(&stack0x000001c0 + lVar21) = (uint)uVar15;
                    if (uVar15 - 1 < 0x1f9e) goto code_r0x00100dd1;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100d5d;
                    func_0x(pbVar7,6);
                    *(uint *)(ppbVar25 + 4) = (uint)uVar15;
                    *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                    break;
                  case 4:
                    *(undefined4 *)(&stack0x000001c0 + lVar21) = 9;
                    *(undefined4 *)(ppbVar25 + 4) = 9;
                    *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                    break;
                  case 6:
                  case 10:
code_r0x00100dd1:
                    *(uint *)(ppbVar25 + 4) = uVar29;
                    *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                    break;
                  case 0xe:
                    *(undefined4 *)(&stack0x000001c0 + lVar21) = 1;
                    *(undefined4 *)(ppbVar25 + 4) = 1;
                    *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                  }
                }
                else {
                  *(ushort **)(&stack0x00000a88 + lVar21) = puVar22;
                  ppbVar25[3] = pbVar9;
                  *(byte **)(&stack0x00000a90 + lVar21) = pbVar9;
                  bVar13 = *pbVar9;
                  switch(bVar13 & 0x1c) {
                  default:
                    puVar41 = (ushort *)(pbVar9 + 1);
                    *(ushort **)(&stack0x00000a98 + lVar21) = puVar41;
                    if ((char)*(byte *)puVar41 < '\0') {
                      uVar15 = *puVar41;
                      *puVar22 = uVar15;
                      *puVar22 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
                      uVar16 = 3;
                      sVar39 = 3;
                    }
                    else {
                      *puVar22 = (ushort)*(byte *)puVar41;
                      uVar16 = 2;
                      sVar39 = 2;
                    }
                    *(undefined2 *)(ppbVar25 + 5) = uVar16;
                    *(short *)((longlong)ppbVar25 + 0x2c) = (short)(*puVar22 + 1 >> 1) + sVar39;
                    if (*puVar22 < 0x1f) {
                      *(undefined2 *)((longlong)ppbVar25 + 0x2a) = 0;
                      *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                      *(undefined4 *)(ppbVar25 + 8) = 0;
                    }
                    else {
                      iVar17 = *puVar22 - 1;
                      *(short *)((longlong)ppbVar25 + 0x2a) =
                           ((short)(iVar17 / 0x1e) + (short)(iVar17 >> 0x1f)) -
                           (short)((longlong)iVar17 * 0x88888889 >> 0x3f);
                      *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                      *(undefined4 *)(ppbVar25 + 8) = 0;
                    }
                    break;
                  case 4:
                    *(byte **)(&stack0x00000aa8 + lVar21) = pbVar9;
                    *(byte **)(&stack0x00000ab0 + lVar21) = pbVar9;
                    if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100ef4;
                      func_0x(puVar22);
                      ppbVar25[3] = pbVar9;
                      *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0xf;
                      *(undefined4 *)(ppbVar25 + 8) = 0;
                      *(undefined4 *)(ppbVar25 + 8) = 1;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100f16;
                      func_0x(puVar22);
                      ppbVar25[3] = pbVar9;
                      *(undefined4 *)((longlong)ppbVar25 + 0x14) = 1;
                      *(undefined4 *)(ppbVar25 + 8) = 0;
                    }
                    break;
                  case 8:
                    *(byte **)(&stack0x00000aa0 + lVar21) = pbVar9;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100eb8;
                    func_0x(puVar22);
                    ppbVar25[3] = pbVar9;
                    *(undefined4 *)((longlong)ppbVar25 + 0x14) = 9;
                    *(undefined4 *)(ppbVar25 + 8) = 0;
                  }
                  ppbVar25[7] = (byte *)0x0;
                  ppbVar25[4] = (byte *)0x0;
                }
              }
              if ((**ppbVar25 & 4) != 0) {
                if (*(short *)(&stack0x000004c2 + lVar21) != 0) {
                  uVar46 = (ulonglong)
                           *(ushort *)
                            (lVar27 + 0x61 + (longlong)*(short *)(&stack0x000004c2 + lVar21) * 2);
                }
                *(byte **)(&stack0x00000ab8 + lVar21) = pbVar44 + uVar46;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100f96;
                func_0x(ppbVar2);
              }
              pbVar44 = ppbVar25[1];
              if (pbVar44 != (byte *)0x0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100fa7;
                func_0x(pbVar44,ppbVar25);
              }
              param_3 = *(longlong **)(&stack0x00000208 + lVar21);
              param_2 = *(uint **)(&stack0x00000328 + lVar21);
              lVar27 = *(longlong *)(&stack0x000000d0 + lVar21);
            }
            else {
              *(undefined8 *)(&stack0x00000680 + lVar21) = 0;
            }
            iVar17 = 0;
            uVar15 = *(ushort *)(lVar27 + 0xe);
            uVar29 = (uint)uVar15;
            *(uint *)(&stack0x0000076c + lVar21) = (uint)uVar15;
            uVar45 = *(ushort *)
                      (lVar27 + (0xfff - (longlong)*(int *)(&stack0x000000d8 + lVar21)) * 2);
            *(ushort *)(&stack0x000004aa + lVar21) = uVar45;
            piVar38 = (int *)((ulonglong)uVar45 + lVar27);
            *(int **)(&stack0x00000ac0 + lVar21) = piVar38;
            bVar13 = *(byte *)piVar38 & 1;
            *(ushort *)(&stack0x000004ac + lVar21) = (ushort)bVar13;
            *(ushort *)(&stack0x000016e8 + lVar21) = (ushort)bVar13;
            if (bVar13 == 0) {
              *(uint *)(&stack0x000001c8 + lVar21) = (uint)uVar15;
              *(undefined **)(&stack0x00000ac8 + lVar21) = &stack0x000016ea + lVar21;
              *(int **)(&stack0x000016f0 + lVar21) = piVar38;
              *(undefined4 *)(&stack0x000016ec + lVar21) = 0;
              *(undefined4 *)(&stack0x0000170e + lVar21) = 0;
              *(int **)(&stack0x00000ad0 + lVar21) = piVar38;
              switch(*(byte *)piVar38 & 0xe) {
              default:
                uVar15 = *(ushort *)((longlong)piVar38 + 2);
                uVar29 = (uint)uVar15;
                *(uint *)(&stack0x000001c8 + lVar21) = (uint)uVar15;
                if (0x1f9d < uVar15 - 1) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10108d;
                  func_0x(piVar38,6);
                  piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                }
                break;
              case 4:
                uVar29 = 9;
                *(undefined4 *)(&stack0x000001c8 + lVar21) = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar29 = 1;
                *(undefined4 *)(&stack0x000001c8 + lVar21) = 1;
              }
              *(uint *)(&stack0x000016f8 + lVar21) = uVar29;
              *(longlong *)(&stack0x00001706 + lVar21) = lVar27 + 0x2000;
            }
            else {
              *(undefined **)(&stack0x00000ad8 + lVar21) = &stack0x000016ea + lVar21;
              *(int **)(&stack0x000016f0 + lVar21) = piVar38;
              *(int **)(&stack0x00000ae0 + lVar21) = piVar38;
              bVar13 = *(byte *)piVar38;
              switch(bVar13 & 0x1c) {
              default:
                puVar22 = (ushort *)((longlong)piVar38 + 1);
                *(ushort **)(&stack0x00000ae8 + lVar21) = puVar22;
                uVar15 = (ushort)*(byte *)puVar22;
                if ((char)*(byte *)puVar22 < '\0') {
                  uVar15 = *puVar22;
                  *(ushort *)(&stack0x000016ea + lVar21) = uVar15;
                  uVar15 = uVar15 >> 8 | (uVar15 & 0x7f) << 8;
                  sVar39 = 3;
                }
                else {
                  sVar39 = 2;
                }
                *(ushort *)(&stack0x000016ea + lVar21) = uVar15;
                *(short *)(&stack0x00001700 + lVar21) = sVar39;
                *(short *)(&stack0x00001704 + lVar21) = (short)(uVar15 + 1 >> 1) + sVar39;
                if (uVar15 < 0x1f) {
                  *(undefined2 *)(&stack0x00001702 + lVar21) = 0;
                  *(undefined4 *)(&stack0x000016ec + lVar21) = 0;
                  *(undefined4 *)(&stack0x00001718 + lVar21) = 0;
                }
                else {
                  iVar18 = uVar15 - 1;
                  *(short *)(&stack0x00001702 + lVar21) =
                       ((short)(iVar18 / 0x1e) + (short)(iVar18 >> 0x1f)) -
                       (short)((longlong)iVar18 * 0x88888889 >> 0x3f);
                  *(undefined4 *)(&stack0x000016ec + lVar21) = 0;
                  *(undefined4 *)(&stack0x00001718 + lVar21) = 0;
                }
                break;
              case 4:
                *(int **)(&stack0x00000af8 + lVar21) = piVar38;
                *(int **)(&stack0x00000b00 + lVar21) = piVar38;
                if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10125a;
                  func_0x(&stack0x000016ea + lVar21);
                  *(int **)(&stack0x000016f0 + lVar21) = piVar38;
                  *(undefined4 *)(&stack0x000016ec + lVar21) = 0xf;
                  *(undefined4 *)(&stack0x00001718 + lVar21) = 0;
                  *(undefined4 *)(&stack0x00001718 + lVar21) = 1;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101293;
                  func_0x(&stack0x000016ea + lVar21);
                  *(int **)(&stack0x000016f0 + lVar21) = piVar38;
                  *(undefined4 *)(&stack0x000016ec + lVar21) = 1;
                  *(undefined4 *)(&stack0x00001718 + lVar21) = 0;
                }
                break;
              case 8:
                *(int **)(&stack0x00000af0 + lVar21) = piVar38;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10120b;
                func_0x(&stack0x000016ea + lVar21);
                *(int **)(&stack0x000016f0 + lVar21) = piVar38;
                *(undefined4 *)(&stack0x000016ec + lVar21) = 9;
                *(undefined4 *)(&stack0x00001718 + lVar21) = 0;
              }
              *(longlong *)(&stack0x00001710 + lVar21) = lVar27 + 0x2000;
              *(byte ***)(&stack0x000016f8 + lVar21) = ppbVar25;
              uVar29 = (uint)ppbVar25;
            }
            if (*(short *)(&stack0x000016e8 + lVar21) == 0) {
              *(undefined **)(&stack0x00000b08 + lVar21) = &stack0x000016ea + lVar21;
              if ((*param_2 & 0xc0000000) == 0x80000000) {
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101d44;
                iVar17 = func_0x(&stack0x000016ea + lVar21);
                if (iVar17 == 0) {
                  *(undefined4 *)(&stack0x0000002c + lVar21) = 0;
                  piVar38 = (int *)0x0;
                  *(undefined8 *)(&stack0x00000670 + lVar21) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101d65;
                  piVar38 = (int *)func_0x(&stack0x00001712 + lVar21,param_2,
                                                   &stack0x0000002c + lVar21);
                  *(int **)(&stack0x00000670 + lVar21) = piVar38;
                }
              }
              else {
                if ((*(byte *)((longlong)param_2 + 6) & 0x10) == 0) {
                  *(undefined4 *)(&stack0x00000618 + lVar21) = 0;
                  *(undefined4 *)(&stack0x00000254 + lVar21) = 1;
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar21) = &stack0x00000254 + lVar21;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101367;
                  func_0x(&stack0x000016ea + lVar21,param_2,0);
                  if ((*(int *)(&stack0x00000254 + lVar21) == 0) &&
                     ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
                    puVar32 = *(undefined4 **)(param_2 + 2);
                    piVar38 = puVar32 + 1;
                    *(int **)(&stack0x00000b10 + lVar21) = piVar38;
                    uVar20 = *puVar32;
                    *(undefined4 *)(&stack0x00000770 + lVar21) = uVar20;
                    *(undefined4 *)(&stack0x0000002c + lVar21) = uVar20;
                    *(int **)(&stack0x00000560 + lVar21) = piVar38;
                    *(int **)(&stack0x00000670 + lVar21) = piVar38;
                    goto LAB_;
                  }
                  uVar29 = *(uint *)(&stack0x000016f8 + lVar21);
                  piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                }
                uVar19 = *param_2;
                *(uint *)(&stack0x00000774 + lVar21) = uVar19;
                if ((int)uVar19 < 0) {
                  if (*(int *)(&stack0x000016ec + lVar21) == 0) {
                    *(undefined4 *)(&stack0x00000040 + lVar21) = 0;
                    *(undefined2 *)(&stack0x000016ea + lVar21) = 0;
                    *(uint *)(&stack0x000016fc + lVar21) = uVar29;
                    *(int **)(&stack0x00000b20 + lVar21) = piVar38;
                    if ((*(byte *)piVar38 & 0x10) != 0) {
                      *(int **)(&stack0x00000b28 + lVar21) = piVar38;
                      *(uint *)(&stack0x000016fc + lVar21) =
                           uVar29 + 2 +
                           (*(ushort *)((ulonglong)uVar29 + (longlong)piVar38) + 7 >> 3);
                    }
                    *(int **)(&stack0x00000b30 + lVar21) = piVar38;
                    if ((*(byte *)piVar38 & 0x20) == 0) {
                      uVar29 = *(uint *)(&stack0x000016fc + lVar21);
                      *(uint *)(&stack0x000016ec + lVar21) = uVar29;
                      *(undefined2 *)(&stack0x00001704 + lVar21) = 0;
                      *(uint *)(&stack0x00001700 + lVar21) = uVar29;
                    }
                    else {
                      psVar42 = (short *)((ulonglong)*(uint *)(&stack0x000016fc + lVar21) +
                                         (longlong)piVar38);
                      *(short **)(&stack0x00000b38 + lVar21) = psVar42;
                      sVar39 = *psVar42;
                      *(short *)(&stack0x00001704 + lVar21) = sVar39;
                      if (sVar39 == 0) {
                        iVar17 = 1;
                        *(undefined4 *)(&stack0x00000040 + lVar21) = 1;
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1015a1;
                        cVar12 = func_0x(0x1e24e30);
                        if (cVar12 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1015aa;
                          lVar27 = func_0x();
                          *(longlong *)(&stack0x00000b40 + lVar21) = lVar27;
                          if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1015cc;
                            cVar12 = func_0x(0x1e24e30);
                            if (cVar12 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1015e8;
                              (*pcRam00000000013939b8)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar21) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10160c;
                              (*pcRam00000000013939b0)(1,0x1715bb8,0x1835888);
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10161e;
                        func_0x(*(undefined8 *)(&stack0x000016f0 + lVar21),3);
                        piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                      }
                      uVar29 = *(int *)(&stack0x000016fc + lVar21) +
                               (*(ushort *)(&stack0x00001704 + lVar21) + 1) * 2;
                      *(uint *)(&stack0x00001700 + lVar21) = uVar29;
                      if (0x1f9e < uVar29) {
                        iVar17 = iVar17 + 1;
                        *(int *)(&stack0x00000040 + lVar21) = iVar17;
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10165f;
                        cVar12 = func_0x(0x1e24e30);
                        if (cVar12 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101668;
                          lVar27 = func_0x();
                          *(longlong *)(&stack0x00000b48 + lVar21) = lVar27;
                          if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10168a;
                            cVar12 = func_0x(0x1e24e30);
                            if (cVar12 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1016a6;
                              (*pcRam00000000013939b8)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar21) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1016ca;
                              (*pcRam00000000013939b0)(1,0x1715bb8,0x1835888);
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1016dc;
                        func_0x(*(undefined8 *)(&stack0x000016f0 + lVar21),4);
                        piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                      }
                      uVar15 = psVar42[*(ushort *)(&stack0x00001704 + lVar21)];
                      *(ushort *)(&stack0x000004b0 + lVar21) = uVar15;
                      uVar29 = uVar15 & 0x7fff;
                      *(uint *)(&stack0x000016ec + lVar21) = uVar29;
                      if (uVar29 < *(uint *)(&stack0x00001700 + lVar21)) {
                        iVar17 = iVar17 + 1;
                        *(int *)(&stack0x00000040 + lVar21) = iVar17;
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101729;
                        cVar12 = func_0x(0x1e24e30);
                        if (cVar12 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101732;
                          lVar27 = func_0x();
                          *(longlong *)(&stack0x00000b50 + lVar21) = lVar27;
                          if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101754;
                            cVar12 = func_0x(0x1e24e30);
                            if (cVar12 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101770;
                              (*pcRam00000000013939b8)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar21) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101794;
                              (*pcRam00000000013939b0)(1,0x1715bb8,0x1835888);
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1017a6;
                        func_0x(*(undefined8 *)(&stack0x000016f0 + lVar21),4);
                        piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                        uVar29 = *(uint *)(&stack0x000016ec + lVar21);
                      }
                      do {
                        uVar15 = *(ushort *)(&stack0x00001704 + lVar21);
                        *(short **)(&stack0x00000b58 + lVar21) =
                             psVar42 + (ulonglong)(uVar15 - 1) + 1;
                        if (-1 < psVar42[(ulonglong)(uVar15 - 1) + 1]) break;
                        *(uint *)(&stack0x00000788 + lVar21) = (uint)uVar15;
                        pbVar44 = (byte *)((ulonglong)*(uint *)(&stack0x000016fc + lVar21) +
                                          (longlong)piVar38);
                        *(byte **)(&stack0x00000b60 + lVar21) = pbVar44;
                        if (uVar15 == 1) {
                          uVar19 = *(uint *)(&stack0x00001700 + lVar21);
                        }
                        else {
                          uVar45 = *(ushort *)(pbVar44 + (longlong)(int)(uVar15 - 2) * 2 + 2);
                          *(ushort *)(&stack0x000004b4 + lVar21) = uVar45;
                          uVar19 = uVar45 & 0x7fff;
                        }
                        uVar15 = *(ushort *)(pbVar44 + (longlong)(int)(uVar15 - 1) * 2 + 2);
                        *(ushort *)(&stack0x000004b8 + lVar21) = uVar15;
                        uVar34 = uVar15 & 0x7fff;
                        *(uint *)(&stack0x00000790 + lVar21) = uVar34;
                        if ((uVar19 < *(uint *)(&stack0x00001700 + lVar21)) || (uVar34 < uVar19)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101861;
                          func_0x(piVar38,7);
                          piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                          uVar29 = *(uint *)(&stack0x000016ec + lVar21);
                        }
                        *(uint *)(&stack0x00000794 + lVar21) = uVar19;
                        if ((uVar19 < *(uint *)(&stack0x00001700 + lVar21)) || (uVar29 < uVar19)) {
                          iVar17 = iVar17 + 1;
                          goto code_r0x00101b77;
                        }
                        uVar15 = *(ushort *)((ulonglong)uVar19 + (longlong)piVar38);
                        *(ushort *)(&stack0x000004bc + lVar21) = uVar15;
                        if (uVar15 == 5) {
                          *(ushort *)(&stack0x000016ea + lVar21) =
                               *(ushort *)(&stack0x000016ea + lVar21) | 2;
                          *(short *)(&stack0x00001704 + lVar21) =
                               *(short *)(&stack0x00001704 + lVar21) + -1;
                          *(undefined **)(&stack0x00000b68 + lVar21) = &stack0x00001712 + lVar21;
                          *(short *)(&stack0x00001712 + lVar21) = (short)uVar19;
                          *(undefined **)(&stack0x00000b70 + lVar21) = &stack0x000016ea + lVar21;
                          pbVar44 = (byte *)((ulonglong)(uVar19 & 0xffff) + (longlong)piVar38);
                          *(byte **)(&stack0x00000b78 + lVar21) = pbVar44;
                          uVar15 = *(ushort *)(&stack0x00001714 + lVar21);
                          if ((*(ushort *)(pbVar44 + 2) >> 0xe & 1) == 0) {
                            uVar15 = uVar15 & 0xc7ff;
                          }
                          else {
                            uVar15 = uVar15 ^ (uVar15 ^ *(ushort *)(pbVar44 + 2)) & 0x3800;
                          }
                          *(ushort *)(&stack0x00001714 + lVar21) = uVar15;
                          *(ushort *)(&stack0x00001714 + lVar21) =
                               (uVar15 ^ *(ushort *)(pbVar44 + 2)) & 0x7ff ^ uVar15;
                          break;
                        }
                        if (uVar15 < 0x400) break;
                        *(ushort *)(&stack0x000016ea + lVar21) =
                             *(ushort *)(&stack0x000016ea + lVar21) | 1;
                        psVar4 = (short *)(&stack0x00001704 + lVar21);
                        *psVar4 = *psVar4 + -1;
                      } while (*psVar4 != 0);
                    }
                    *(int **)(&stack0x00000b80 + lVar21) = piVar38;
                    if ((*(byte *)piVar38 & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000170e + lVar21) = 0;
                    }
                    else {
                      *(uint *)(&stack0x0000170e + lVar21) = uVar29;
                      *(uint *)(&stack0x000016ec + lVar21) = uVar29 + 0xe;
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1019c8;
                      uVar24 = func_0x(&stack0x000016ea + lVar21);
                      *(undefined8 *)(&stack0x00000b88 + lVar21) = uVar24;
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1019e0;
                      func_0x(uVar24,&stack0x00000870 + lVar21);
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1019ed;
                      iVar18 = func_0x(&stack0x00000870 + lVar21);
                      uVar29 = *(int *)(&stack0x000016ec + lVar21) + iVar18;
                      *(uint *)(&stack0x000016ec + lVar21) = uVar29;
                      piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                    }
                    if ((*(byte **)(&stack0x00001706 + lVar21) != (byte *)0x0) &&
                       (*(byte **)(&stack0x00001706 + lVar21) <
                        (byte *)((ulonglong)uVar29 + (longlong)piVar38))) {
                      iVar17 = iVar17 + 1;
                      *(int *)(&stack0x00000040 + lVar21) = iVar17;
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101a44;
                      cVar12 = func_0x(0x1e24e30);
                      if (cVar12 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101a4d;
                        lVar27 = func_0x();
                        *(longlong *)(&stack0x00000b90 + lVar21) = lVar27;
                        if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101a6f;
                          cVar12 = func_0x(0x1e24e30);
                          if (cVar12 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101a8b;
                            (*pcRam00000000013939b8)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar21) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101aaf;
                            (*pcRam00000000013939b0)(1,0x1715bb8,0x1835888);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101ac1;
                      func_0x(*(undefined8 *)(&stack0x000016f0 + lVar21),0x12);
                      piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                      uVar29 = *(uint *)(&stack0x000016ec + lVar21);
                    }
                    if (0x3f3b < uVar29 - 1) {
                      iVar17 = iVar17 + 1;
                      *(int *)(&stack0x00000040 + lVar21) = iVar17;
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101af2;
                      cVar12 = func_0x(0x1e24e30);
                      if (cVar12 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101afb;
                        lVar27 = func_0x();
                        *(longlong *)(&stack0x00000b98 + lVar21) = lVar27;
                        if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101b1d;
                          cVar12 = func_0x(0x1e24e30);
                          if (cVar12 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101b39;
                            (*pcRam00000000013939b8)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar21) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101b5d;
                            (*pcRam00000000013939b0)(1,0x1715bb8,0x1835888);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101b6f;
                      func_0x(*(undefined8 *)(&stack0x000016f0 + lVar21),5);
                      piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                    }
code_r0x00101b77:
                    *(int *)(&stack0x00000040 + lVar21) = iVar17;
                  }
                  uVar29 = *param_2;
                  *(uint *)(&stack0x00000798 + lVar21) = uVar29;
                  sVar39 = -(short)uVar29;
                  *(short *)(&stack0x000004e0 + lVar21) = sVar39;
                  if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar21) = &stack0x0000036c + lVar21;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101bc1;
                    func_0x(&stack0x000016ea + lVar21,param_2,0);
                    if (*(int *)(&stack0x0000036c + lVar21) == 0) {
                      puVar32 = *(undefined4 **)(param_2 + 2);
                      piVar38 = puVar32 + 1;
                      *(int **)(&stack0x00000ba0 + lVar21) = piVar38;
                      uVar20 = *puVar32;
                      *(undefined4 *)(&stack0x000007a0 + lVar21) = uVar20;
                      *(undefined4 *)(&stack0x0000002c + lVar21) = uVar20;
                      *(int **)(&stack0x00000688 + lVar21) = piVar38;
                      *(int **)(&stack0x00000560 + lVar21) = piVar38;
                      *(int **)(&stack0x00000670 + lVar21) = piVar38;
                      goto LAB_;
                    }
                    piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                  }
                  uVar29 = (uint)sVar39;
                  if (*(ushort *)(&stack0x00001704 + lVar21) < uVar29) {
                    *(undefined4 *)(&stack0x0000002c + lVar21) = 0;
                    *(int **)(&stack0x00000688 + lVar21) = piVar38;
                    *(int **)(&stack0x00000560 + lVar21) = piVar38;
                    *(int **)(&stack0x00000670 + lVar21) = piVar38;
                  }
                  else {
                    *(uint *)(&stack0x00000370 + lVar21) = uVar29;
                    pbVar44 = (byte *)((ulonglong)*(uint *)(&stack0x000016fc + lVar21) +
                                      (longlong)piVar38);
                    *(byte **)(&stack0x00000878 + lVar21) = pbVar44;
                    if (uVar29 == 1) {
                      uVar29 = *(uint *)(&stack0x00001700 + lVar21);
                      iVar17 = 1;
                    }
                    else {
                      iVar17 = *(int *)(&stack0x00000370 + lVar21);
                      pbVar44 = *(byte **)(&stack0x00000878 + lVar21);
                      uVar15 = *(ushort *)(pbVar44 + (longlong)(iVar17 + -2) * 2 + 2);
                      *(ushort *)(&stack0x000004e4 + lVar21) = uVar15;
                      uVar29 = uVar15 & 0x7fff;
                      *(undefined4 *)(&stack0x000000d8 + lVar21) =
                           *(undefined4 *)(&stack0x000001f0 + lVar21);
                      *(undefined8 *)(&stack0x000000d0 + lVar21) =
                           *(undefined8 *)(&stack0x000006c8 + lVar21);
                      piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                    }
                    *(uint *)(&stack0x00000378 + lVar21) = uVar29;
                    uVar15 = *(ushort *)(pbVar44 + (longlong)(iVar17 + -1) * 2 + 2);
                    *(ushort *)(&stack0x000004e8 + lVar21) = uVar15;
                    uVar19 = uVar15 & 0x7fff;
                    *(uint *)(&stack0x000007e8 + lVar21) = uVar19;
                    if ((uVar29 < *(uint *)(&stack0x00001700 + lVar21)) || (uVar19 < uVar29)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101cdd;
                      func_0x(piVar38,7);
                      piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                    }
                    *(uint *)(&stack0x0000002c + lVar21) = uVar19 - uVar29;
                    *(uint *)(&stack0x000007a4 + lVar21) = uVar29;
                    piVar38 = (int *)((ulonglong)uVar29 + (longlong)piVar38);
                    *(int **)(&stack0x00000688 + lVar21) = piVar38;
                    *(int **)(&stack0x00000560 + lVar21) = piVar38;
                    *(int **)(&stack0x00000670 + lVar21) = piVar38;
                  }
                }
                else if ((*(ushort *)((longlong)param_2 + 6) & 8) == 0) {
                  if ((*(ushort *)((longlong)param_2 + 6) & 0x10) != 0) {
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar21) = &stack0x0000061c + lVar21;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10142a;
                    func_0x(&stack0x000016ea + lVar21,param_2,0);
                    if (*(int *)(&stack0x0000061c + lVar21) == 0) {
                      piVar3 = *(int **)(param_2 + 2);
                      piVar38 = piVar3 + 1;
                      *(int **)(&stack0x00000b18 + lVar21) = piVar38;
                      iVar17 = *piVar3;
                      *(int *)(&stack0x0000077c + lVar21) = iVar17;
                      if (iVar17 != 6) {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar21) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101475;
                        (*pcRam00000000013939b0)(1,0x18c3928,0x18c2328);
                      }
                      *(int *)(&stack0x0000002c + lVar21) = iVar17;
                      *(int **)(&stack0x00000868 + lVar21) = piVar38;
                      *(int **)(&stack0x00000560 + lVar21) = piVar38;
                      *(int **)(&stack0x00000670 + lVar21) = piVar38;
                      goto LAB_;
                    }
                    piVar38 = *(int **)(&stack0x000016f0 + lVar21);
                  }
                  *(undefined4 *)(&stack0x0000002c + lVar21) = 6;
                  uVar29 = *param_2;
                  *(uint *)(&stack0x00000780 + lVar21) = uVar29;
                  piVar38 = (int *)((longlong)(int)uVar29 + (longlong)piVar38);
                  *(int **)(&stack0x00000868 + lVar21) = piVar38;
                  *(int **)(&stack0x00000560 + lVar21) = piVar38;
                  *(int **)(&stack0x00000670 + lVar21) = piVar38;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1014e8;
                  piVar38 = (int *)func_0x
                                             (&stack0x000016ea + lVar21,param_2,
                                              &stack0x0000002c + lVar21);
                  *(int **)(&stack0x00000560 + lVar21) = piVar38;
                  *(int **)(&stack0x00000670 + lVar21) = piVar38;
                }
              }
            }
            else {
              *(undefined4 *)(&stack0x00000268 + lVar21) = 0;
              *(undefined **)(&stack0xffffffffffffffe8 + lVar21) = &stack0x00000268 + lVar21;
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101db7;
              piVar38 = (int *)func_0x(&stack0x000016ea + lVar21,param_2,0);
              *(int **)(&stack0x00000880 + lVar21) = piVar38;
              if (*(short *)(&stack0x000016e8 + lVar21) != 0) {
                plVar35 = *(longlong **)(&stack0x000016f8 + lVar21);
                *(longlong **)(&stack0x00000ba8 + lVar21) = plVar35;
                if ((plVar35 != (longlong *)0x0) &&
                   (*(longlong **)(&stack0x00000bb0 + lVar21) = plVar35, *plVar35 != 0)) {
                  *(undefined4 *)(&stack0x0000026c + lVar21) = 1;
                  if (((*(byte *)((longlong)param_2 + 6) & 8) == 0) &&
                     ((*(uint *)(&stack0x00000268 + lVar21) & 1) == 0)) {
                    *(undefined4 *)(&stack0x000007ac + lVar21) =
                         *(undefined4 *)(&stack0x0000002c + lVar21);
                    *(int **)(&stack0x00000bb8 + lVar21) = piVar38;
                    *(longlong **)(&stack0x00000bc0 + lVar21) = plVar35;
                    *(uint *)((longlong)auStackX_20 + lVar21 + -0x20) =
                         *(uint *)(&stack0x00000268 + lVar21);
                    *(undefined **)(&stack0xfffffffffffffff8 + lVar21) = &stack0x0000002c + lVar21;
                    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar21) = 6;
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar21) = &stack0x000022c8 + lVar21;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x101e63;
                    piVar38 = (int *)func_0x(plVar35,param_2,piVar38);
                    *(int **)(&stack0x00000880 + lVar21) = piVar38;
                  }
                  goto LAB_;
                }
              }
              *(undefined4 *)(&stack0x0000026c + lVar21) = 0;
            }
          }
LAB_:
          uVar29 = 0;
          *(int **)(&stack0x00000690 + lVar21) = piVar38;
          iVar17 = *piVar38;
          *(int *)(&stack0x000006e4 + lVar21) = iVar17;
          uVar15 = *(ushort *)(piVar38 + 1);
          *(ushort *)(&stack0x000006e8 + lVar21) = uVar15;
          iVar18 = *(int *)(param_3 + 1);
          bVar11 = false;
          if (iVar18 == 0) {
            *(ushort *)(&stack0x000004f0 + lVar21) = uVar15;
            puVar30 = (uint *)param_3[5];
            *(uint **)(&stack0x00000bc8 + lVar21) = puVar30;
            *(undefined4 *)(&stack0x0000037c + lVar21) = 0;
            uVar19 = *puVar30;
            *(uint *)(&stack0x00000380 + lVar21) = uVar19;
            uVar34 = uVar29;
            while (uVar19 != uVar34) {
              uVar33 = uVar19 + uVar34 >> 1;
              *(uint *)(&stack0x000007b0 + lVar21) = uVar33;
              puVar22 = (ushort *)(*(longlong *)(puVar30 + 2) + (ulonglong)uVar33 * 8);
              uVar45 = *puVar22;
              if (uVar45 == uVar15) {
                uVar20 = *(undefined4 *)(puVar22 + 2);
                goto LAB_;
              }
              if (uVar45 < uVar15) {
                *(uint *)(&stack0x0000037c + lVar21) = uVar33;
                uVar34 = uVar33;
              }
              else {
                if (uVar15 < uVar45) {
                  uVar19 = uVar33;
                }
                *(uint *)(&stack0x00000380 + lVar21) = uVar19;
              }
            }
            uVar20 = 0xffffffff;
LAB_:
            *(undefined4 *)(&stack0x000007b4 + lVar21) = uVar20;
            *(undefined4 *)((longlong)param_3 + 0x1c) = uVar20;
          }
          piVar38 = (int *)(*param_3 + (longlong)iVar18 * 8);
          *(int **)(&stack0x00000bd0 + lVar21) = piVar38;
          *piVar38 = iVar17;
          *(ushort *)(piVar38 + 1) = uVar15;
          *(undefined2 *)((longlong)piVar38 + 6) = 0;
          *(int *)(param_3 + 1) = *(int *)(param_3 + 1) + 1;
          iVar17 = *(int *)(param_3 + 1);
          if (iVar17 < *(int *)(param_3 + 2)) {
LAB_:
            *(undefined4 *)(&stack0x000000e0 + lVar21) = 0;
          }
          else {
            if (iVar17 != *(int *)(param_3 + 2)) {
              *(ushort *)(&stack0x00000500 + lVar21) = uVar15;
              if (iVar17 < *(int *)((longlong)param_3 + 0x14)) {
                if (*(ushort *)(param_3 + 4) == uVar15) goto LAB_;
LAB_:
                *(ushort *)(&stack0x00000508 + lVar21) = uVar15;
                puVar30 = (uint *)param_3[5];
                *(uint **)(&stack0x00000be0 + lVar21) = puVar30;
                *(undefined4 *)(&stack0x0000038c + lVar21) = 0;
                uVar19 = *puVar30;
                *(uint *)(&stack0x00000390 + lVar21) = uVar19;
                while (uVar19 != uVar29) {
                  uVar34 = uVar19 + uVar29 >> 1;
                  *(uint *)(&stack0x000007c0 + lVar21) = uVar34;
                  puVar22 = (ushort *)(*(longlong *)(puVar30 + 2) + (ulonglong)uVar34 * 8);
                  uVar45 = *puVar22;
                  if (uVar45 == uVar15) {
                    iVar17 = *(int *)(puVar22 + 2);
                    goto LAB_;
                  }
                  if (uVar45 < uVar15) {
                    *(uint *)(&stack0x0000038c + lVar21) = uVar34;
                    uVar29 = uVar34;
                  }
                  else {
                    if (uVar15 < uVar45) {
                      uVar19 = uVar34;
                    }
                    *(uint *)(&stack0x00000390 + lVar21) = uVar19;
                  }
                }
                iVar17 = -1;
LAB_:
                *(int *)(&stack0x000007c4 + lVar21) = iVar17;
                if (iVar17 == *(int *)((longlong)param_3 + 0x1c)) {
                  if (*(ushort *)(param_3 + 4) != uVar15) {
                    *(ushort *)(param_3 + 4) = uVar15;
                  }
                  goto LAB_;
                }
              }
              else if (iVar17 != *(int *)((longlong)param_3 + 0x14)) goto LAB_;
              *(undefined4 *)(&stack0x000000e0 + lVar21) = 1;
              param_1 = *(longlong *)(&stack0x000000c8 + lVar21);
              goto LAB_;
            }
            *(ushort *)(&stack0x000004f8 + lVar21) = uVar15;
            puVar30 = (uint *)param_3[5];
            *(uint **)(&stack0x00000bd8 + lVar21) = puVar30;
            *(undefined4 *)(&stack0x00000384 + lVar21) = 0;
            uVar19 = *puVar30;
            *(uint *)(&stack0x00000388 + lVar21) = uVar19;
            while (uVar19 != uVar29) {
              uVar34 = uVar19 + uVar29 >> 1;
              *(uint *)(&stack0x000007b8 + lVar21) = uVar34;
              puVar22 = (ushort *)(*(longlong *)(puVar30 + 2) + (ulonglong)uVar34 * 8);
              uVar45 = *puVar22;
              if (uVar45 == uVar15) {
                uVar20 = *(undefined4 *)(puVar22 + 2);
                goto LAB_;
              }
              if (uVar15 <= uVar45) {
                if (uVar15 <= uVar45 && uVar45 != uVar15) {
                  uVar19 = uVar34;
                }
                *(uint *)(&stack0x00000388 + lVar21) = uVar19;
              }
              else {
                *(uint *)(&stack0x00000384 + lVar21) = uVar34;
                uVar29 = uVar34;
              }
            }
            uVar20 = 0xffffffff;
LAB_:
            *(undefined4 *)(&stack0x000007bc + lVar21) = uVar20;
            *(undefined4 *)((longlong)param_3 + 0x1c) = uVar20;
            *(ushort *)(param_3 + 4) = uVar15;
            bVar11 = true;
            *(undefined4 *)(&stack0x000000e0 + lVar21) = 2;
          }
          if (bVar11) {
            *(undefined2 *)(&stack0x00001798 + lVar21) = 0xffff;
            *(undefined8 *)(&stack0x000017a0 + lVar21) = 0;
            *(undefined4 *)(&stack0x0000179c + lVar21) = 0;
            *(undefined8 *)(&stack0x000017b6 + lVar21) = 0;
            *(undefined8 *)(&stack0x000017c0 + lVar21) = 0;
            *(undefined8 *)(&stack0x000017a8 + lVar21) = 0;
            *(undefined4 *)(&stack0x000017cc + lVar21) = 0xffffffff;
            param_1 = *(longlong *)(&stack0x000000c8 + lVar21);
            pplVar47 = (longlong **)(param_1 + 0x68);
            *(longlong ***)(&stack0x000000f0 + lVar21) = pplVar47;
            lVar27 = **pplVar47;
            *(longlong *)(&stack0x00000be8 + lVar21) = lVar27;
            lVar43 = *(longlong *)(param_1 + 0xd8);
            *(longlong *)(&stack0x00000bf0 + lVar21) = lVar43;
            if (*(int *)(lVar43 + 0x20) == 0) {
              lVar43 = *(longlong *)(lVar43 + 0x18);
            }
            else {
              lVar43 = *(longlong *)(lVar43 + 0x10);
            }
            *(longlong *)(&stack0x000000e8 + lVar21) = lVar43;
            *(longlong *)(&stack0x00000bf8 + lVar21) = lVar43;
            lVar31 = **(longlong **)(param_1 + 8);
            *(longlong *)(&stack0x00000220 + lVar21) = lVar31;
            *(longlong *)(&stack0x00000c00 + lVar21) = lVar31;
            piVar3 = (int *)(param_1 + 0x118);
            *(int **)(&stack0x00000c08 + lVar21) = piVar3;
            piVar38 = (int *)(lVar27 + 0x20);
            *(int **)(&stack0x00000c10 + lVar21) = piVar38;
            if ((*piVar38 == *piVar3) && (*(short *)(lVar27 + 0x24) == *(short *)(param_1 + 0x11c)))
            {
              *(int **)(&stack0x00000c18 + lVar21) = (int *)(param_1 + 0x124);
              *(uint **)(&stack0x00000c20 + lVar21) = (uint *)(lVar31 + 0x14);
              if (((*(uint *)(lVar31 + 0x14) & 0xe0000000) == 0x80000000) &&
                 (*(ushort *)(lVar31 + 0x18) < 0x100)) {
LAB_:
                pplVar47 = *(longlong ***)(&stack0x000000f0 + lVar21);
                *(undefined4 *)(&stack0x0000028c + lVar21) = 1;
                goto LAB_;
              }
              (&stack0x0000003d)[lVar21] = 0;
              if (*(short *)(lVar27 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x000002a0 + lVar21) = *(undefined8 *)(lVar27 + 0x28);
                sVar39 = *(short *)(lVar27 + 0x30);
                *(short *)(&stack0x000002a8 + lVar21) = sVar39;
              }
              else {
                cVar12 = *(char *)(lVar27 + 1);
                if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                   (*(int *)(lVar27 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00000c28 + lVar21) = &stack0x000002f0 + lVar21;
                  *(int **)(&stack0x00000c30 + lVar21) = piVar38;
                  *(int *)(&stack0x000002f0 + lVar21) = *piVar38;
                  *(undefined2 *)(&stack0x000002f4 + lVar21) = *(undefined2 *)(lVar27 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102219;
                  cVar12 = func_0x(&stack0x000002f0 + lVar21);
                  if (cVar12 == '\0') goto LAB_;
                  cVar12 = '\x01';
                }
                else {
LAB_:
                  cVar12 = '\0';
                }
                (&stack0x0000003d)[lVar21] = cVar12;
                if (cVar12 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10223b;
                func_0x(lVar27,&stack0x000002a0 + lVar21);
                sVar39 = *(short *)(&stack0x000002a8 + lVar21);
              }
              *(undefined **)(&stack0x00000c38 + lVar21) = &stack0x000002a0 + lVar21;
              if (((sVar39 != *(short *)(param_1 + 300)) ||
                  (*(int *)(&stack0x000002a0 + lVar21) != *(int *)(param_1 + 0x124))) ||
                 (*(int *)(&stack0x000002a4 + lVar21) != *(int *)(param_1 + 0x128)))
              goto LAB_;
              *(undefined4 *)(&stack0x0000028c + lVar21) = 0;
            }
            else {
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1022bd;
              func_0x(piVar3);
              *(int **)(&stack0x00000c40 + lVar21) = piVar38;
              *(int **)(&stack0x00000c48 + lVar21) = piVar3;
              *piVar3 = *piVar38;
              *(undefined2 *)(param_1 + 0x11c) = *(undefined2 *)(lVar27 + 0x24);
              (&stack0x00000032)[lVar21] = 0;
              if (*(short *)(lVar27 + 0x24) == 0) {
LAB_:
                uVar24 = *(undefined8 *)(lVar27 + 0x28);
                *(undefined8 *)(&stack0x00000340 + lVar21) = uVar24;
                uVar16 = *(undefined2 *)(lVar27 + 0x30);
                *(undefined2 *)(&stack0x00000348 + lVar21) = uVar16;
              }
              else {
                cVar12 = *(char *)(lVar27 + 1);
                if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                   (*(int *)(lVar27 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00000c50 + lVar21) = &stack0x00000320 + lVar21;
                  *(int **)(&stack0x00000c58 + lVar21) = piVar38;
                  *(int *)(&stack0x00000320 + lVar21) = *piVar38;
                  *(undefined2 *)(&stack0x00000324 + lVar21) = *(undefined2 *)(lVar27 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10233d;
                  cVar12 = func_0x(&stack0x00000320 + lVar21);
                  if (cVar12 == '\0') goto LAB_;
                  cVar12 = '\x01';
                }
                else {
LAB_:
                  cVar12 = '\0';
                }
                (&stack0x00000032)[lVar21] = cVar12;
                if (cVar12 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10235f;
                func_0x(lVar27,&stack0x00000340 + lVar21);
                uVar16 = *(undefined2 *)(&stack0x00000348 + lVar21);
                uVar24 = *(undefined8 *)(&stack0x00000340 + lVar21);
              }
              *(undefined **)(&stack0x00000c60 + lVar21) = &stack0x00000340 + lVar21;
              *(undefined8 *)(param_1 + 0x124) = uVar24;
              *(undefined2 *)(param_1 + 300) = uVar16;
              *(undefined4 *)(param_1 + 0x130) = 1;
              iVar17 = *(int *)(lVar43 + 0x10);
              *(int *)(&stack0x000007c8 + lVar21) = iVar17;
              if (iVar17 == 0) {
                lVar8 = **pplVar47;
                *(longlong *)(&stack0x00000c68 + lVar21) = lVar8;
                iVar17 = *(ushort *)(lVar8 + 0x16) - 1;
                *(int *)(&stack0x00000088 + lVar21) = iVar17;
                *(int *)(&stack0x000007d0 + lVar21) = iVar17;
                *(int *)(&stack0x000017cc + lVar21) = iVar17;
                if (*(char *)(lVar27 + 2) < '\0') {
                  pbVar44 = (byte *)(lVar27 + 0x60);
                  if (*(short *)(&stack0x00001798 + lVar21) == 0) {
                    *(undefined8 *)(&stack0x00000568 + lVar21) = 0;
LAB_:
                    *(undefined **)(&stack0x00000c78 + lVar21) = &stack0x000017d0 + lVar21;
                    *(undefined (*) [16])(&stack0x000017d0 + lVar21) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x000017e0 + lVar21) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x000017f0 + lVar21) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00001800 + lVar21) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00001810 + lVar21) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00001820 + lVar21) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00001830 + lVar21) = ZEXT816(0);
                    *(undefined8 *)(&stack0x00001840 + lVar21) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1024ae;
                    ppbVar25 = (byte **)func_0x(&stack0x000017d0 + lVar21);
                    *(byte ***)(&stack0x00000568 + lVar21) = ppbVar25;
                  }
                  else {
                    ppbVar25 = *(byte ***)(&stack0x000017a8 + lVar21);
                    *(byte ***)(&stack0x00000c70 + lVar21) = ppbVar25;
                    *(byte ***)(&stack0x00000568 + lVar21) = ppbVar25;
                    if (ppbVar25 == (byte **)0x0) goto LAB_;
                  }
                  (&stack0x00000033)[lVar21] = 0;
                  if (*(short *)(lVar27 + 0x24) == 0) {
LAB_:
                    *(undefined8 *)(&stack0x000016c8 + lVar21) = *(undefined8 *)(lVar27 + 0x28);
                    sVar39 = *(short *)(lVar27 + 0x30);
                    *(short *)(&stack0x000016d0 + lVar21) = sVar39;
                  }
                  else {
                    cVar12 = *(char *)(lVar27 + 1);
                    if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                       (*(int *)(lVar27 + 0x18) == 99)) {
                      *(undefined **)(&stack0x00000c80 + lVar21) = &stack0x000002f8 + lVar21;
                      *(int **)(&stack0x00000c88 + lVar21) = piVar38;
                      *(int *)(&stack0x000002f8 + lVar21) = *piVar38;
                      *(undefined2 *)(&stack0x000002fc + lVar21) = *(undefined2 *)(lVar27 + 0x24);
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102517;
                      cVar12 = func_0x(&stack0x000002f8 + lVar21);
                      if (cVar12 == '\0') goto LAB_;
                      cVar12 = '\x01';
                    }
                    else {
LAB_:
                      cVar12 = '\0';
                    }
                    (&stack0x00000033)[lVar21] = cVar12;
                    if (cVar12 == '\0') goto LAB_;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102539;
                    func_0x(lVar27,&stack0x000016c8 + lVar21);
                    sVar39 = *(short *)(&stack0x000016d0 + lVar21);
                  }
                  *(undefined **)(&stack0x00000c90 + lVar21) = &stack0x000016c8 + lVar21;
                  *(int **)(&stack0x00000c98 + lVar21) = piVar38;
                  *(byte **)(&stack0x00000ca0 + lVar21) = pbVar44;
                  *(byte ***)(&stack0x00000ca8 + lVar21) = ppbVar25;
                  if (pbVar44 == *ppbVar25) {
                    *(byte ***)(&stack0x00000cb0 + lVar21) = ppbVar25 + 0xc;
                    if (((sVar39 == *(short *)(ppbVar25 + 0xd)) &&
                        (*(int *)(&stack0x000016c8 + lVar21) == *(int *)(ppbVar25 + 0xc))) &&
                       (*(int *)(&stack0x000016cc + lVar21) == *(int *)((longlong)ppbVar25 + 100)))
                    {
                      *(longlong *)(&stack0x00000cb8 + lVar21) = (longlong)ppbVar25 + 0x6c;
                    }
                  }
                  *ppbVar25 = pbVar44;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1025d7;
                  func_0x(ppbVar25 + 0xc,&stack0x000016c8 + lVar21);
                  *(int **)(&stack0x00000cc0 + lVar21) = (int *)((longlong)ppbVar25 + 0x6c);
                  *(int *)((longlong)ppbVar25 + 0x6c) = *piVar38;
                  *(undefined2 *)(ppbVar25 + 0xe) = *(undefined2 *)(lVar27 + 0x24);
                  *(undefined2 *)((longlong)ppbVar25 + 0x72) = 0;
                  uVar46 = (ulonglong)*pbVar44;
                  *(ushort *)(&stack0x00000510 + lVar21) = (ushort)*pbVar44;
                  *(undefined4 *)(&stack0x000006ec + lVar21) =
                       *(undefined4 *)(uVar46 * 6 + 0x15126a0);
                  *(undefined2 *)(&stack0x000006f0 + lVar21) =
                       *(undefined2 *)(uVar46 * 6 + 0x15126a4);
                  *(undefined4 *)(&stack0x000004c8 + lVar21) =
                       *(undefined4 *)(uVar46 * 6 + 0x15126a0);
                  sVar39 = *(short *)(uVar46 * 6 + 0x15126a4);
                  uVar46 = (ulonglong)sVar39;
                  *(short *)(&stack0x000004cc + lVar21) = sVar39;
                  *(longlong *)(&stack0x00000cc8 + lVar21) = lVar27 + 99;
                  ppbVar1 = ppbVar25 + 2;
                  *(byte ***)(&stack0x00000cd0 + lVar21) = ppbVar1;
                  *(undefined2 *)ppbVar1 = 0xffff;
                  ppbVar25[3] = (byte *)0x0;
                  uVar29 = 0;
                  *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                  *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                  ppbVar25[7] = (byte *)0x0;
                  ppbVar25[4] = (byte *)0x0;
                  *(byte ***)(&stack0x00000cd8 + lVar21) = ppbVar25 + 9;
                  ppbVar25[9] = (byte *)0x0;
                  ppbVar25[10] = (byte *)0x0;
                  *(undefined2 *)(ppbVar25 + 0xb) = 0;
                  if ((**ppbVar25 & 2) != 0) {
                    pbVar44 = pbVar44 + uVar46;
                    *(byte **)(&stack0x00000ce0 + lVar21) = pbVar44;
                    *(byte ***)(&stack0x00000ce8 + lVar21) = ppbVar1;
                    bVar13 = *pbVar44 & 1;
                    *(ushort *)(&stack0x00000518 + lVar21) = (ushort)bVar13;
                    *(ushort *)ppbVar1 = (ushort)bVar13;
                    puVar22 = (ushort *)((longlong)ppbVar25 + 0x12);
                    if (bVar13 == 0) {
                      *(undefined4 *)(&stack0x000001d0 + lVar21) = 0;
                      *(ushort **)(&stack0x00000cf0 + lVar21) = puVar22;
                      ppbVar25[3] = pbVar44;
                      *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                      *(undefined4 *)((longlong)ppbVar25 + 0x36) = 0;
                      pbVar9 = ppbVar25[3];
                      *(byte **)(&stack0x00000cf8 + lVar21) = pbVar9;
                      switch(*pbVar9 & 0xe) {
                      default:
                        uVar15 = *(ushort *)(pbVar44 + 2);
                        uVar29 = (uint)uVar15;
                        *(uint *)(&stack0x000001d0 + lVar21) = (uint)uVar15;
                        if (uVar15 - 1 < 0x1f9e) goto code_r0x001027b4;
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102740;
                        func_0x(pbVar9,6);
                        *(uint *)(ppbVar25 + 4) = (uint)uVar15;
                        *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                        break;
                      case 4:
                        *(undefined4 *)(&stack0x000001d0 + lVar21) = 9;
                        *(undefined4 *)(ppbVar25 + 4) = 9;
                        *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                        break;
                      case 6:
                      case 10:
code_r0x001027b4:
                        *(uint *)(ppbVar25 + 4) = uVar29;
                        *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                        break;
                      case 0xe:
                        *(undefined4 *)(&stack0x000001d0 + lVar21) = 1;
                        *(undefined4 *)(ppbVar25 + 4) = 1;
                        *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                      }
                    }
                    else {
                      *(ushort **)(&stack0x00000d00 + lVar21) = puVar22;
                      ppbVar25[3] = pbVar44;
                      *(byte **)(&stack0x00000d08 + lVar21) = pbVar44;
                      bVar13 = *pbVar44;
                      switch(bVar13 & 0x1c) {
                      default:
                        puVar41 = (ushort *)(pbVar44 + 1);
                        *(ushort **)(&stack0x00000d10 + lVar21) = puVar41;
                        if ((char)*(byte *)puVar41 < '\0') {
                          uVar15 = *puVar41;
                          *puVar22 = uVar15;
                          *puVar22 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
                          uVar16 = 3;
                          sVar39 = 3;
                        }
                        else {
                          *puVar22 = (ushort)*(byte *)puVar41;
                          uVar16 = 2;
                          sVar39 = 2;
                        }
                        *(undefined2 *)(ppbVar25 + 5) = uVar16;
                        *(short *)((longlong)ppbVar25 + 0x2c) = (short)(*puVar22 + 1 >> 1) + sVar39;
                        if (*puVar22 < 0x1f) {
                          *(undefined2 *)((longlong)ppbVar25 + 0x2a) = 0;
                          *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                          *(undefined4 *)(ppbVar25 + 8) = 0;
                        }
                        else {
                          iVar17 = *puVar22 - 1;
                          *(short *)((longlong)ppbVar25 + 0x2a) =
                               ((short)(iVar17 / 0x1e) + (short)(iVar17 >> 0x1f)) -
                               (short)((longlong)iVar17 * 0x88888889 >> 0x3f);
                          *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                          *(undefined4 *)(ppbVar25 + 8) = 0;
                        }
                        break;
                      case 4:
                        *(byte **)(&stack0x00000d20 + lVar21) = pbVar44;
                        *(byte **)(&stack0x00000d28 + lVar21) = pbVar44;
                        if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1028d8;
                          func_0x(puVar22);
                          ppbVar25[3] = pbVar44;
                          *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0xf;
                          *(undefined4 *)(ppbVar25 + 8) = 0;
                          *(undefined4 *)(ppbVar25 + 8) = 1;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1028fc;
                          func_0x(puVar22);
                          ppbVar25[3] = pbVar44;
                          *(undefined4 *)((longlong)ppbVar25 + 0x14) = 1;
                          *(undefined4 *)(ppbVar25 + 8) = 0;
                        }
                        break;
                      case 8:
                        *(byte **)(&stack0x00000d18 + lVar21) = pbVar44;
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10289a;
                        func_0x(puVar22);
                        ppbVar25[3] = pbVar44;
                        *(undefined4 *)((longlong)ppbVar25 + 0x14) = 9;
                        *(undefined4 *)(ppbVar25 + 8) = 0;
                      }
                      ppbVar25[7] = (byte *)0x0;
                      ppbVar25[4] = (byte *)0x0;
                    }
                  }
                  if ((**ppbVar25 & 4) != 0) {
                    if (*(short *)(&stack0x000004ca + lVar21) != 0) {
                      uVar46 = (ulonglong)
                               *(ushort *)
                                (lVar27 + 0x61 + (longlong)*(short *)(&stack0x000004ca + lVar21) * 2
                                );
                    }
                    *(ulonglong *)(&stack0x00000d30 + lVar21) = uVar46 + lVar27 + 0x60;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102981;
                    func_0x(ppbVar25 + 9);
                  }
                  pbVar44 = ppbVar25[1];
                  if (pbVar44 != (byte *)0x0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102995;
                    func_0x(pbVar44,ppbVar25);
                  }
                  lVar31 = *(longlong *)(&stack0x00000220 + lVar21);
                  lVar43 = *(longlong *)(&stack0x000000e8 + lVar21);
                }
                else {
                  ppbVar25 = (byte **)0x0;
                  *(undefined8 *)(&stack0x00000568 + lVar21) = 0;
                }
                uVar15 = *(ushort *)(lVar27 + 0xe);
                uVar29 = (uint)uVar15;
                *(uint *)(&stack0x000007d8 + lVar21) = (uint)uVar15;
                uVar45 = *(ushort *)
                          (lVar27 + (0xfff - (longlong)*(int *)(&stack0x00000088 + lVar21)) * 2);
                *(ushort *)(&stack0x0000051a + lVar21) = uVar45;
                pbVar44 = (byte *)((ulonglong)uVar45 + lVar27);
                *(byte **)(&stack0x00000d38 + lVar21) = pbVar44;
                bVar13 = *pbVar44 & 1;
                *(ushort *)(&stack0x0000051c + lVar21) = (ushort)bVar13;
                *(ushort *)(&stack0x00001798 + lVar21) = (ushort)bVar13;
                if (bVar13 == 0) {
                  *(uint *)(&stack0x000001d8 + lVar21) = (uint)uVar15;
                  *(undefined **)(&stack0x00000d40 + lVar21) = &stack0x0000179a + lVar21;
                  *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                  *(undefined4 *)(&stack0x0000179c + lVar21) = 0;
                  *(undefined4 *)(&stack0x000017be + lVar21) = 0;
                  *(byte **)(&stack0x00000d48 + lVar21) = pbVar44;
                  switch(*pbVar44 & 0xe) {
                  default:
                    uVar15 = *(ushort *)(pbVar44 + 2);
                    uVar29 = (uint)uVar15;
                    *(uint *)(&stack0x000001d8 + lVar21) = (uint)uVar15;
                    if (0x1f9d < uVar15 - 1) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102a72;
                      func_0x(pbVar44,6);
                    }
                    break;
                  case 4:
                    uVar29 = 9;
                    *(undefined4 *)(&stack0x000001d8 + lVar21) = 9;
                    break;
                  case 6:
                  case 10:
                    break;
                  case 0xe:
                    uVar29 = 1;
                    *(undefined4 *)(&stack0x000001d8 + lVar21) = 1;
                  }
                  *(uint *)(&stack0x000017a8 + lVar21) = uVar29;
                  *(longlong *)(&stack0x000017b6 + lVar21) = lVar27 + 0x2000;
                }
                else {
                  *(undefined **)(&stack0x00000d50 + lVar21) = &stack0x0000179a + lVar21;
                  *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                  *(byte **)(&stack0x00000d58 + lVar21) = pbVar44;
                  bVar13 = *pbVar44;
                  switch(bVar13 & 0x1c) {
                  default:
                    puVar22 = (ushort *)(pbVar44 + 1);
                    *(ushort **)(&stack0x00000d60 + lVar21) = puVar22;
                    uVar15 = (ushort)*(byte *)puVar22;
                    if ((char)*(byte *)puVar22 < '\0') {
                      uVar15 = *puVar22;
                      *(ushort *)(&stack0x0000179a + lVar21) = uVar15;
                      uVar15 = uVar15 >> 8 | (uVar15 & 0x7f) << 8;
                      sVar39 = 3;
                    }
                    else {
                      sVar39 = 2;
                    }
                    *(ushort *)(&stack0x0000179a + lVar21) = uVar15;
                    *(short *)(&stack0x000017b0 + lVar21) = sVar39;
                    *(short *)(&stack0x000017b4 + lVar21) = (short)(uVar15 + 1 >> 1) + sVar39;
                    if (uVar15 < 0x1f) {
                      *(undefined2 *)(&stack0x000017b2 + lVar21) = 0;
                      *(undefined4 *)(&stack0x0000179c + lVar21) = 0;
                      *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                    }
                    else {
                      iVar17 = uVar15 - 1;
                      *(short *)(&stack0x000017b2 + lVar21) =
                           ((short)(iVar17 / 0x1e) + (short)(iVar17 >> 0x1f)) -
                           (short)((longlong)iVar17 * 0x88888889 >> 0x3f);
                      *(undefined4 *)(&stack0x0000179c + lVar21) = 0;
                      *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                    }
                    break;
                  case 4:
                    *(byte **)(&stack0x00000d70 + lVar21) = pbVar44;
                    *(byte **)(&stack0x00000d78 + lVar21) = pbVar44;
                    if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102c35;
                      func_0x(&stack0x0000179a + lVar21);
                      *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                      *(undefined4 *)(&stack0x0000179c + lVar21) = 0xf;
                      *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                      *(undefined4 *)(&stack0x000017c8 + lVar21) = 1;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102c6c;
                      func_0x(&stack0x0000179a + lVar21);
                      *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                      *(undefined4 *)(&stack0x0000179c + lVar21) = 1;
                      *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                    }
                    break;
                  case 8:
                    *(byte **)(&stack0x00000d68 + lVar21) = pbVar44;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102be8;
                    func_0x(&stack0x0000179a + lVar21);
                    *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                    *(undefined4 *)(&stack0x0000179c + lVar21) = 9;
                    *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                  }
                  *(longlong *)(&stack0x000017c0 + lVar21) = lVar27 + 0x2000;
                  *(byte ***)(&stack0x000017a8 + lVar21) = ppbVar25;
                }
                uVar20 = *(undefined4 *)(lVar43 + 8);
                *(undefined4 *)(&stack0x000007dc + lVar21) = uVar20;
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar21) = 1;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102cf5;
                uVar20 = func_0x(&stack0x00001798 + lVar21,lVar43,uVar20,lVar31);
                param_1 = *(longlong *)(&stack0x000000c8 + lVar21);
                *(undefined4 *)(param_1 + 0x130) = uVar20;
              }
            }
            puVar32 = (undefined4 *)(lVar27 + 0x20);
            if (*(int *)(param_1 + 0x130) == 0) {
              uVar20 = *(undefined4 *)(param_1 + 0x80);
              *(undefined4 *)(&stack0x00000088 + lVar21) = uVar20;
              *(undefined4 *)(&stack0x000007e0 + lVar21) = uVar20;
              *(undefined4 *)(&stack0x000017cc + lVar21) = uVar20;
              if (*(char *)(lVar27 + 2) < '\0') {
                pbVar44 = (byte *)(lVar27 + 0x60);
                if (*(short *)(&stack0x00001798 + lVar21) == 0) {
                  *(undefined8 *)(&stack0x00000570 + lVar21) = 0;
LAB_:
                  *(undefined **)(&stack0x00000d88 + lVar21) = &stack0x000017d0 + lVar21;
                  *(undefined (*) [16])(&stack0x000017d0 + lVar21) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000017e0 + lVar21) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000017f0 + lVar21) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001800 + lVar21) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001810 + lVar21) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001820 + lVar21) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001830 + lVar21) = ZEXT816(0);
                  *(undefined8 *)(&stack0x00001840 + lVar21) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102de4;
                  ppbVar25 = (byte **)func_0x(&stack0x000017d0 + lVar21);
                  *(byte ***)(&stack0x00000570 + lVar21) = ppbVar25;
                }
                else {
                  ppbVar25 = *(byte ***)(&stack0x000017a8 + lVar21);
                  *(byte ***)(&stack0x00000d80 + lVar21) = ppbVar25;
                  *(byte ***)(&stack0x00000570 + lVar21) = ppbVar25;
                  if (ppbVar25 == (byte **)0x0) goto LAB_;
                }
                (&stack0x00000034)[lVar21] = 0;
                if (*(short *)(lVar27 + 0x24) == 0) {
LAB_:
                  *(undefined8 *)(&stack0x000016d8 + lVar21) = *(undefined8 *)(lVar27 + 0x28);
                  sVar39 = *(short *)(lVar27 + 0x30);
                  *(short *)(&stack0x000016e0 + lVar21) = sVar39;
                }
                else {
                  cVar12 = *(char *)(lVar27 + 1);
                  if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                     (*(int *)(lVar27 + 0x18) == 99)) {
                    *(undefined **)(&stack0x00000d90 + lVar21) = &stack0x00000310 + lVar21;
                    *(undefined4 **)(&stack0x00000d98 + lVar21) = puVar32;
                    *(undefined4 *)(&stack0x00000310 + lVar21) = *puVar32;
                    *(undefined2 *)(&stack0x00000314 + lVar21) = *(undefined2 *)(lVar27 + 0x24);
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102e4d;
                    cVar12 = func_0x(&stack0x00000310 + lVar21);
                    if (cVar12 == '\0') goto LAB_;
                    cVar12 = '\x01';
                  }
                  else {
LAB_:
                    cVar12 = '\0';
                  }
                  (&stack0x00000034)[lVar21] = cVar12;
                  if (cVar12 == '\0') goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102e6f;
                  func_0x(lVar27,&stack0x000016d8 + lVar21);
                  sVar39 = *(short *)(&stack0x000016e0 + lVar21);
                }
                *(undefined **)(&stack0x00000da0 + lVar21) = &stack0x000016d8 + lVar21;
                *(undefined4 **)(&stack0x00000da8 + lVar21) = puVar32;
                *(byte **)(&stack0x00000db0 + lVar21) = pbVar44;
                *(byte ***)(&stack0x00000db8 + lVar21) = ppbVar25;
                if (pbVar44 == *ppbVar25) {
                  *(byte ***)(&stack0x00000dc0 + lVar21) = ppbVar25 + 0xc;
                  if (((sVar39 == *(short *)(ppbVar25 + 0xd)) &&
                      (*(int *)(&stack0x000016d8 + lVar21) == *(int *)(ppbVar25 + 0xc))) &&
                     (*(int *)(&stack0x000016dc + lVar21) == *(int *)((longlong)ppbVar25 + 100))) {
                    *(longlong *)(&stack0x00000dc8 + lVar21) = (longlong)ppbVar25 + 0x6c;
                  }
                }
                *ppbVar25 = pbVar44;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x102f0d;
                func_0x(ppbVar25 + 0xc,&stack0x000016d8 + lVar21);
                *(undefined4 **)(&stack0x00000dd0 + lVar21) =
                     (undefined4 *)((longlong)ppbVar25 + 0x6c);
                *(undefined4 *)((longlong)ppbVar25 + 0x6c) = *puVar32;
                *(undefined2 *)(ppbVar25 + 0xe) = *(undefined2 *)(lVar27 + 0x24);
                *(undefined2 *)((longlong)ppbVar25 + 0x72) = 0;
                uVar46 = (ulonglong)*pbVar44;
                *(ushort *)(&stack0x00000520 + lVar21) = (ushort)*pbVar44;
                *(undefined4 *)(&stack0x000006f2 + lVar21) = *(undefined4 *)(uVar46 * 6 + 0x15126a0)
                ;
                *(undefined2 *)(&stack0x000006f6 + lVar21) = *(undefined2 *)(uVar46 * 6 + 0x15126a4)
                ;
                *(undefined4 *)(&stack0x000004d0 + lVar21) = *(undefined4 *)(uVar46 * 6 + 0x15126a0)
                ;
                sVar39 = *(short *)(uVar46 * 6 + 0x15126a4);
                uVar46 = (ulonglong)sVar39;
                *(short *)(&stack0x000004d4 + lVar21) = sVar39;
                lVar43 = lVar27 + 99;
                *(longlong *)(&stack0x00000698 + lVar21) = lVar43;
                ppbVar1 = ppbVar25 + 2;
                *(byte ***)(&stack0x00000dd8 + lVar21) = ppbVar1;
                *(undefined2 *)ppbVar1 = 0xffff;
                ppbVar25[3] = (byte *)0x0;
                uVar29 = 0;
                *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                ppbVar25[7] = (byte *)0x0;
                ppbVar25[4] = (byte *)0x0;
                ppbVar2 = ppbVar25 + 9;
                *(byte ***)(&stack0x00000de0 + lVar21) = ppbVar2;
                *ppbVar2 = (byte *)0x0;
                ppbVar25[10] = (byte *)0x0;
                *(undefined2 *)(ppbVar25 + 0xb) = 0;
                if ((**ppbVar25 & 2) != 0) {
                  pbVar44 = pbVar44 + uVar46;
                  *(byte **)(&stack0x00000de8 + lVar21) = pbVar44;
                  *(byte ***)(&stack0x00000df0 + lVar21) = ppbVar1;
                  bVar13 = *pbVar44 & 1;
                  *(ushort *)(&stack0x00000528 + lVar21) = (ushort)bVar13;
                  *(ushort *)ppbVar1 = (ushort)bVar13;
                  puVar22 = (ushort *)((longlong)ppbVar25 + 0x12);
                  if (bVar13 == 0) {
                    *(undefined4 *)(&stack0x000001e0 + lVar21) = 0;
                    *(ushort **)(&stack0x00000df8 + lVar21) = puVar22;
                    ppbVar25[3] = pbVar44;
                    *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                    *(undefined4 *)((longlong)ppbVar25 + 0x36) = 0;
                    pbVar9 = ppbVar25[3];
                    *(byte **)(&stack0x00000e00 + lVar21) = pbVar9;
                    switch(*pbVar9 & 0xe) {
                    default:
                      uVar15 = *(ushort *)(pbVar44 + 2);
                      uVar29 = (uint)uVar15;
                      *(uint *)(&stack0x000001e0 + lVar21) = (uint)uVar15;
                      if (0x1f9d < uVar15 - 1) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103077;
                        func_0x(pbVar9,6);
                      }
                      break;
                    case 4:
                      uVar29 = 9;
                      *(undefined4 *)(&stack0x000001e0 + lVar21) = 9;
                      break;
                    case 6:
                    case 10:
                      break;
                    case 0xe:
                      uVar29 = 1;
                      *(undefined4 *)(&stack0x000001e0 + lVar21) = 1;
                    }
                    *(uint *)(ppbVar25 + 4) = uVar29;
                    *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
                    lVar43 = *(longlong *)(&stack0x00000698 + lVar21);
                  }
                  else {
                    *(ushort **)(&stack0x00000e08 + lVar21) = puVar22;
                    ppbVar25[3] = pbVar44;
                    *(byte **)(&stack0x00000e10 + lVar21) = pbVar44;
                    bVar13 = *pbVar44;
                    switch(bVar13 & 0x1c) {
                    default:
                      puVar41 = (ushort *)(pbVar44 + 1);
                      *(ushort **)(&stack0x00000e18 + lVar21) = puVar41;
                      if ((char)*(byte *)puVar41 < '\0') {
                        uVar15 = *puVar41;
                        *puVar22 = uVar15;
                        *puVar22 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
                        uVar16 = 3;
                        sVar39 = 3;
                      }
                      else {
                        *puVar22 = (ushort)*(byte *)puVar41;
                        uVar16 = 2;
                        sVar39 = 2;
                      }
                      *(undefined2 *)(ppbVar25 + 5) = uVar16;
                      *(short *)((longlong)ppbVar25 + 0x2c) = (short)(*puVar22 + 1 >> 1) + sVar39;
                      if (*puVar22 < 0x1f) {
                        *(undefined2 *)((longlong)ppbVar25 + 0x2a) = 0;
                        *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                        *(undefined4 *)(ppbVar25 + 8) = 0;
                      }
                      else {
                        iVar17 = *puVar22 - 1;
                        *(short *)((longlong)ppbVar25 + 0x2a) =
                             ((short)(iVar17 / 0x1e) + (short)(iVar17 >> 0x1f)) -
                             (short)((longlong)iVar17 * 0x88888889 >> 0x3f);
                        *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                        *(undefined4 *)(ppbVar25 + 8) = 0;
                      }
                      break;
                    case 4:
                      *(byte **)(&stack0x00000e28 + lVar21) = pbVar44;
                      *(byte **)(&stack0x00000e30 + lVar21) = pbVar44;
                      if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1031f9;
                        func_0x(puVar22);
                        ppbVar25[3] = pbVar44;
                        *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0xf;
                        *(undefined4 *)(ppbVar25 + 8) = 0;
                        *(undefined4 *)(ppbVar25 + 8) = 1;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10321d;
                        func_0x(puVar22);
                        ppbVar25[3] = pbVar44;
                        *(undefined4 *)((longlong)ppbVar25 + 0x14) = 1;
                        *(undefined4 *)(ppbVar25 + 8) = 0;
                      }
                      break;
                    case 8:
                      *(byte **)(&stack0x00000e20 + lVar21) = pbVar44;
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1031bb;
                      func_0x(puVar22);
                      ppbVar25[3] = pbVar44;
                      *(undefined4 *)((longlong)ppbVar25 + 0x14) = 9;
                      *(undefined4 *)(ppbVar25 + 8) = 0;
                    }
                    ppbVar25[7] = (byte *)0x0;
                    ppbVar25[4] = (byte *)0x0;
                    lVar43 = *(longlong *)(&stack0x00000698 + lVar21);
                  }
                }
                if ((**ppbVar25 & 4) != 0) {
                  if (*(short *)(&stack0x000004d2 + lVar21) != 0) {
                    uVar46 = (ulonglong)
                             *(ushort *)
                              (lVar43 + -2 + (longlong)*(short *)(&stack0x000004d2 + lVar21) * 2);
                  }
                  *(ulonglong *)(&stack0x00000e38 + lVar21) = uVar46 + lVar27 + 0x60;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1032ab;
                  func_0x(ppbVar2);
                }
                pbVar44 = ppbVar25[1];
                if (pbVar44 != (byte *)0x0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1032bc;
                  func_0x(pbVar44,ppbVar25);
                }
                lVar31 = *(longlong *)(&stack0x00000220 + lVar21);
                lVar43 = *(longlong *)(&stack0x000000e8 + lVar21);
              }
              else {
                ppbVar25 = (byte **)0x0;
                *(undefined8 *)(&stack0x00000570 + lVar21) = 0;
              }
              uVar15 = *(ushort *)(lVar27 + 0xe);
              uVar29 = (uint)uVar15;
              *(uint *)(&stack0x0000082c + lVar21) = (uint)uVar15;
              uVar45 = *(ushort *)
                        (lVar27 + (0xfff - (longlong)*(int *)(&stack0x00000088 + lVar21)) * 2);
              *(ushort *)(&stack0x0000052a + lVar21) = uVar45;
              pbVar44 = (byte *)((ulonglong)uVar45 + lVar27);
              *(byte **)(&stack0x00000e40 + lVar21) = pbVar44;
              bVar13 = *pbVar44 & 1;
              *(ushort *)(&stack0x0000052c + lVar21) = (ushort)bVar13;
              *(ushort *)(&stack0x00001798 + lVar21) = (ushort)bVar13;
              if (bVar13 == 0) {
                *(uint *)(&stack0x000001e8 + lVar21) = (uint)uVar15;
                *(undefined **)(&stack0x00000e48 + lVar21) = &stack0x0000179a + lVar21;
                *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                *(undefined4 *)(&stack0x0000179c + lVar21) = 0;
                *(undefined4 *)(&stack0x000017be + lVar21) = 0;
                *(byte **)(&stack0x00000e50 + lVar21) = pbVar44;
                switch(*pbVar44 & 0xe) {
                default:
                  uVar15 = *(ushort *)(pbVar44 + 2);
                  uVar29 = (uint)uVar15;
                  *(uint *)(&stack0x000001e8 + lVar21) = (uint)uVar15;
                  if (0x1f9d < uVar15 - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103392;
                    func_0x(pbVar44,6);
                  }
                  break;
                case 4:
                  uVar29 = 9;
                  *(undefined4 *)(&stack0x000001e8 + lVar21) = 9;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar29 = 1;
                  *(undefined4 *)(&stack0x000001e8 + lVar21) = 1;
                }
                *(uint *)(&stack0x000017a8 + lVar21) = uVar29;
                *(longlong *)(&stack0x000017b6 + lVar21) = lVar27 + 0x2000;
              }
              else {
                *(undefined **)(&stack0x00000e58 + lVar21) = &stack0x0000179a + lVar21;
                *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                *(byte **)(&stack0x00000e60 + lVar21) = pbVar44;
                bVar13 = *pbVar44;
                switch(bVar13 & 0x1c) {
                default:
                  puVar22 = (ushort *)(pbVar44 + 1);
                  *(ushort **)(&stack0x00000e68 + lVar21) = puVar22;
                  uVar15 = (ushort)*(byte *)puVar22;
                  if ((char)*(byte *)puVar22 < '\0') {
                    uVar15 = *puVar22;
                    *(ushort *)(&stack0x0000179a + lVar21) = uVar15;
                    uVar15 = uVar15 >> 8 | (uVar15 & 0x7f) << 8;
                    sVar39 = 3;
                  }
                  else {
                    sVar39 = 2;
                  }
                  *(ushort *)(&stack0x0000179a + lVar21) = uVar15;
                  *(short *)(&stack0x000017b0 + lVar21) = sVar39;
                  *(short *)(&stack0x000017b4 + lVar21) = (short)(uVar15 + 1 >> 1) + sVar39;
                  if (uVar15 < 0x1f) {
                    *(undefined2 *)(&stack0x000017b2 + lVar21) = 0;
                    *(undefined4 *)(&stack0x0000179c + lVar21) = 0;
                    *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                  }
                  else {
                    iVar17 = uVar15 - 1;
                    *(short *)(&stack0x000017b2 + lVar21) =
                         ((short)(iVar17 / 0x1e) + (short)(iVar17 >> 0x1f)) -
                         (short)((longlong)iVar17 * 0x88888889 >> 0x3f);
                    *(undefined4 *)(&stack0x0000179c + lVar21) = 0;
                    *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                  }
                  break;
                case 4:
                  *(byte **)(&stack0x00000e78 + lVar21) = pbVar44;
                  *(byte **)(&stack0x00000e80 + lVar21) = pbVar44;
                  if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103554;
                    func_0x(&stack0x0000179a + lVar21);
                    *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                    *(undefined4 *)(&stack0x0000179c + lVar21) = 0xf;
                    *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                    *(undefined4 *)(&stack0x000017c8 + lVar21) = 1;
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10358a;
                    func_0x(&stack0x0000179a + lVar21);
                    *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                    *(undefined4 *)(&stack0x0000179c + lVar21) = 1;
                    *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                  }
                  break;
                case 8:
                  *(byte **)(&stack0x00000e70 + lVar21) = pbVar44;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103508;
                  func_0x(&stack0x0000179a + lVar21);
                  *(byte **)(&stack0x000017a0 + lVar21) = pbVar44;
                  *(undefined4 *)(&stack0x0000179c + lVar21) = 9;
                  *(undefined4 *)(&stack0x000017c8 + lVar21) = 0;
                }
                *(longlong *)(&stack0x000017c0 + lVar21) = lVar27 + 0x2000;
                *(byte ***)(&stack0x000017a8 + lVar21) = ppbVar25;
              }
              uVar20 = *(undefined4 *)(lVar43 + 8);
              *(undefined4 *)(&stack0x000007ec + lVar21) = uVar20;
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar21) = 1;
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103612;
              iVar17 = func_0x(&stack0x00001798 + lVar21,lVar43,uVar20,lVar31);
              if (iVar17 != 0) {
                *(undefined4 *)(&stack0x00000088 + lVar21) = 1;
                param_2 = *(uint **)(&stack0x00000328 + lVar21);
                param_3 = *(longlong **)(&stack0x00000208 + lVar21);
                goto LAB_;
              }
              *(undefined4 *)(&stack0x00000088 + lVar21) = 0;
              lVar27 = *(longlong *)(&stack0x000000c8 + lVar21);
              if (*(int *)(lVar27 + 0xd0) != 2) {
                *(longlong **)(&stack0x00000578 + lVar21) =
                     *(longlong **)(&stack0x000000f0 + lVar21);
                lVar43 = **(longlong **)(&stack0x000000f0 + lVar21);
                if (lVar43 != 0) {
                  puVar23 = (undefined2 *)(lVar43 + 0x62);
                  *(undefined2 **)(&stack0x00000e88 + lVar21) = puVar23;
                  *(undefined2 *)(&stack0x00000120 + lVar21) = *puVar23;
                  plVar35 = *(longlong **)(&stack0x00000578 + lVar21);
                  if (((*(ushort *)(&stack0x00000120 + lVar21) & 0x400) == 0) ||
                     (*(short *)((longlong)plVar35 + 0xc) < 3)) {
                    *(int *)(&stack0x00000060 + lVar21) = (int)*(short *)((longlong)plVar35 + 0xc);
                    lVar43 = *plVar35;
                    *(longlong *)(&stack0x00000238 + lVar21) = lVar43;
                    puVar23 = (undefined2 *)(lVar43 + 0x62);
                    *(undefined2 **)(&stack0x00000e90 + lVar21) = puVar23;
                    uVar16 = *puVar23;
                    *(undefined2 *)(&stack0x00000128 + lVar21) = uVar16;
                    if (((byte)uVar16 >> 3 & 1) != 0) {
                      if (*(int *)(&stack0x00000060 + lVar21) == 3) {
                        *(undefined4 *)(&stack0x00000060 + lVar21) = 4;
                      }
                      else if (*(int *)(&stack0x00000060 + lVar21) < 2) goto code_r0x0010391b;
                      *(uint **)(&stack0x00000e98 + lVar21) =
                           (uint *)(*(longlong *)(&stack0x00000238 + lVar21) + 100);
                      uVar29 = *(uint *)(*(longlong *)(&stack0x00000238 + lVar21) + 100);
                      *(uint *)(&stack0x00000398 + lVar21) = uVar29;
                      if ((((uVar29 & 8) != 0) &&
                          (lVar43 = *(longlong *)(*(longlong *)(&stack0x00000238 + lVar21) + 0x90),
                          lVar43 != 0)) &&
                         (*(longlong *)(&stack0x00000ea0 + lVar21) = lVar43,
                         *(longlong *)(lVar43 + 0x758) != 0)) {
                        uVar24 = *(undefined8 *)(lVar43 + 0x758);
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10391b;
                        func_0x
                                  (uVar24,*(undefined8 *)(&stack0x00000238 + lVar21),
                                   *(undefined4 *)(&stack0x00000060 + lVar21));
                      }
                    }
code_r0x0010391b:
                    (&stack0x000001b4)[lVar21] = DAT_ >> 7;
                    if ((char)DAT_ < '\0') {
                      puVar30 = (uint *)(*(longlong *)(&stack0x00000238 + lVar21) + 100);
                      *(uint **)(&stack0x00000ea8 + lVar21) = puVar30;
                      uVar29 = *puVar30;
                      *(uint *)(&stack0x000003a0 + lVar21) = uVar29;
                      if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x00000060 + lVar21))) {
                        *(uint **)(&stack0x00000eb0 + lVar21) = puVar30;
                        uVar29 = *puVar30;
                        *(uint *)(&stack0x000003a8 + lVar21) = uVar29;
                        if (((uVar29 & 0xc0000000) != 0x40000000) &&
                           (lVar43 = **(longlong **)(&stack0x00000238 + lVar21), lVar43 != 0)) {
                          *(undefined4 *)(&stack0x000007f0 + lVar21) = 2;
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1039ae;
                          iVar17 = (*_DAT_)(lVar43,0x2000,2,&stack0x000007f4 + lVar21);
                          if (iVar17 != 0) {
                            LOCK();
                            *puVar30 = *puVar30 & 0x3fffffff;
                            UNLOCK();
                            LOCK();
                            *puVar30 = *puVar30 | 0x40000000;
                            UNLOCK();
                          }
                        }
                      }
                    }
                    lVar43 = *(longlong *)(&stack0x00000238 + lVar21);
                    uVar20 = *(undefined4 *)(&stack0x00000060 + lVar21);
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1039dd;
                    func_0x(lVar43 + 0x98,uVar20);
                    if ((_DAT_ != 0) &&
                       ((&stack0x000001b5)[lVar21] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0
                       )) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103a07;
                      func_0x(lVar43,0,uVar20);
                    }
                    *(uint *)((longlong)plVar35 + 0xc) =
                         *(uint *)((longlong)plVar35 + 0xc) & 0xffff0000;
                    **(undefined8 **)(&stack0x00000578 + lVar21) = 0;
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103695;
                    func_0x(plVar35);
                  }
                }
                *(undefined4 *)(lVar27 + 0x80) = 0xffffffff;
                *(undefined8 **)(&stack0x00000eb8 + lVar21) = (undefined8 *)(lVar27 + 0x88);
                if (*(int *)(lVar27 + 0x90) != 0) {
                  *(undefined4 *)(&stack0x000007f8 + lVar21) = *(undefined4 *)(lVar27 + 0x94);
                  *(undefined8 *)(&stack0x00000ec0 + lVar21) = *(undefined8 *)(lVar27 + 0x88);
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1036d4;
                  func_0x();
                  *(undefined4 *)(lVar27 + 0x90) = 0;
                }
                *(undefined4 *)(&stack0x000000c8 + lVar21) = 0;
                *(undefined2 *)(&stack0x000000cc + lVar21) = 0;
                *(undefined4 **)(&stack0x00000ec8 + lVar21) = (undefined4 *)(lVar27 + 0x9c);
                *(undefined4 *)(lVar27 + 0x9c) = 0;
                *(undefined2 *)(lVar27 + 0xa0) = 0;
                *(undefined4 *)(&stack0x00000620 + lVar21) = 0;
                *(undefined4 *)(&stack0x00000624 + lVar21) = 0;
                *(undefined2 *)(&stack0x00000628 + lVar21) = 0;
                *(undefined8 *)(lVar27 + 0xbc) = *(undefined8 *)(&stack0x00000620 + lVar21);
                *(undefined2 *)(lVar27 + 0xc4) = 0;
                *(undefined4 *)(lVar27 + 0xd0) = 2;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103741;
              func_0x((longlong)&plStackX_10 + lVar21);
              goto LAB_;
            }
            *(undefined4 *)(&stack0x00000088 + lVar21) = 1;
            param_2 = *(uint **)(&stack0x00000328 + lVar21);
            param_3 = *(longlong **)(&stack0x00000208 + lVar21);
          }
          else {
LAB_:
            param_1 = *(longlong *)(&stack0x000000c8 + lVar21);
          }
          uVar24 = 0;
          iVar17 = *(int *)(&stack0x000000d8 + lVar21) + 1;
          *(int *)(&stack0x000000d8 + lVar21) = iVar17;
          *(int *)(&stack0x000001f0 + lVar21) = iVar17;
          if (iVar17 == *(int *)(&stack0x00000288 + lVar21)) {
            pplVar47 = (longlong **)(param_1 + 0x68);
            lVar27 = **pplVar47;
            *(longlong *)(&stack0x00000ed0 + lVar21) = lVar27;
            *(int **)(&stack0x00000ed8 + lVar21) = (int *)(lVar27 + 0x10);
            iVar17 = *(int *)(lVar27 + 0x10);
            *(int *)(&stack0x000006d6 + lVar21) = iVar17;
            sVar39 = *(short *)(lVar27 + 0x14);
            *(short *)(&stack0x000006da + lVar21) = sVar39;
            *(int *)(&stack0x00000044 + lVar21) = iVar17;
            *(short *)(&stack0x00000048 + lVar21) = sVar39;
            iVar18 = 0;
            *(undefined4 *)(&stack0x000006dc + lVar21) = 0;
            *(undefined2 *)(&stack0x000006e0 + lVar21) = 0;
            if ((iVar17 != 0) || (sVar39 != 0)) {
              *(undefined **)(&stack0x00000f28 + lVar21) = &stack0x000004d8 + lVar21;
              *(int *)(&stack0x000004d8 + lVar21) = iVar17;
              *(short *)(&stack0x000004dc + lVar21) = sVar39;
              *(longlong ***)(&stack0x000006b0 + lVar21) = pplVar47;
              plVar35 = *(longlong **)(param_1 + 8);
              *(longlong **)(&stack0x000006c0 + lVar21) = plVar35;
              *(undefined8 *)(&stack0x000005a8 + lVar21) = *(undefined8 *)(param_1 + 0x10);
              *(undefined4 *)(&stack0x00000350 + lVar21) = 0;
              *(undefined4 *)(&stack0x00000354 + lVar21) = 0;
              *(undefined2 *)(&stack0x00000358 + lVar21) = 0;
              lVar27 = *plVar35;
              *(longlong *)(&stack0x000006b8 + lVar21) = lVar27;
              *(undefined4 *)(&stack0x0000096c + lVar21) = 0;
              *(undefined4 *)(&stack0x00000970 + lVar21) = 0;
              lVar43 = *(longlong *)(lVar27 + 0x20);
              *(longlong *)(&stack0x000000c0 + lVar21) = lVar43;
              *(uint6 **)(&stack0x00000f30 + lVar21) = (uint6 *)(lVar27 + 0x14);
              lVar31 = (ulonglong)*(uint6 *)(lVar27 + 0x14) * 0x10000;
              *(longlong *)(&stack0x00000f38 + lVar21) = lVar31;
              lVar27 = *(longlong *)(lVar43 + 2000);
              if ((lVar27 == lVar31) && (lVar27 - 1U < 0xfffffffffffffffe)) {
                (&stack0x00000035)[lVar21] = 1;
              }
              else {
                (&stack0x00000035)[lVar21] = 0;
                if ((*(longlong *)(*(longlong *)(&stack0x000000c0 + lVar21) + 0x7d8) == lVar31) &&
                   (*(longlong *)(*(longlong *)(&stack0x000000c0 + lVar21) + 0x7d8) - 1U <
                    0xfffffffffffffffe)) {
                  (&stack0x00000036)[lVar21] = 1;
                }
                else {
                  (&stack0x00000036)[lVar21] = 0;
                  lVar27 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000f40 + lVar21) = lVar27;
                  lVar43 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar27 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x00000f48 + lVar21) = lVar43;
                  lVar27 = *(longlong *)(lVar43 + 0x100);
                  *(longlong *)(&stack0x00000888 + lVar21) = lVar27;
                  puVar30 = _DAT_;
                  if (lVar27 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103de7;
                    puVar30 = (uint *)(*_DAT_)();
                    lVar27 = *(longlong *)(lVar43 + 0x100);
                    *(longlong *)(&stack0x00000888 + lVar21) = lVar27;
                  }
                  *(longlong *)(&stack0x00000f50 + lVar21) = lVar27;
                  uVar46 = rdtsc();
                  uVar26 = CONCAT44((int)((ulonglong)puVar30 >> 0x20),(int)uVar46) |
                           uVar46 & 0xffffffff00000000;
                  *(ulonglong *)(&stack0x00000f58 + lVar21) = uVar26;
                  uVar46 = *(ulonglong *)(lVar27 + 0x340);
                  if ((uVar46 < uVar26) ||
                     ((uVar46 != 0x7fffffffffffffff &&
                      (*(ulonglong *)(*(longlong *)(lVar27 + 0x260) + 0xdf0) < uVar46 - uVar26)))) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103eb6;
                    iVar17 = func_0x(0,0x1e361a0);
                    *(int *)(&stack0x00000258 + lVar21) = iVar17;
                    if (iVar17 == 2) {
LAB_:
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103ec9;
                      func_0x(0x7c);
                    }
                  }
                  else {
                    lVar27 = *(longlong *)(lVar27 + 600);
                    *(longlong *)(&stack0x00000890 + lVar21) = lVar27;
                    puVar30 = (uint *)(lVar27 + 0xbc);
                    *(uint **)(&stack0x00000f60 + lVar21) = puVar30;
                    if ((*puVar30 & 4) != 0) {
                      lVar27 = *(longlong *)(*(longlong *)(&stack0x00000890 + lVar21) + 0x98);
                      *(longlong *)(&stack0x00000f68 + lVar21) = lVar27;
                      if (((*(byte *)(lVar27 + 0x268) & 1) == 0) &&
                         ((*(uint *)(lVar27 + 800) & 0x180) == 0)) {
                        *(undefined4 *)(&stack0x00000258 + lVar21) = 2;
                        goto LAB_;
                      }
                    }
                    *(undefined4 *)(&stack0x00000258 + lVar21) = 0;
                  }
                }
              }
              *(undefined4 *)(&stack0x000006f8 + lVar21) = 0;
              *(undefined4 *)(&stack0x000006fc + lVar21) = 0;
              *(undefined2 *)(&stack0x00000700 + lVar21) = 0;
              if (*(longlong *)(&stack0x000006b0 + lVar21) == 0) {
                (&stack0x00000028)[lVar21] = 0;
              }
              else {
                (&stack0x00000028)[lVar21] = 1;
                uVar14 = 0xff;
                if (*(char *)(*(longlong *)(&stack0x000000c0 + lVar21) + 0x2050) != '\0')
                goto LAB_;
              }
              uVar14 = 2;
LAB_:
              (&stack0x00000029)[lVar21] = uVar14;
              do {
                *(undefined **)(&stack0x000006a0 + lVar21) = &stack0x00000968 + lVar21;
                *(undefined4 *)(&stack0x0000168c + lVar21) = 0;
                *(undefined4 *)(&stack0x00001690 + lVar21) = 0;
                cVar12 = *_DAT_;
                (&stack0x000001b8)[lVar21] = cVar12;
                uVar28 = uVar24;
                if ((cVar12 != '\0') &&
                   ((&stack0x000001f4)[lVar21] = DAT_ >> 7, -1 < (char)DAT_)) {
                  *(undefined4 *)(&stack0x000003c8 + lVar21) = 0;
                  lVar27 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000f70 + lVar21) = lVar27;
                  plVar35 = (longlong *)
                            ((ulonglong)*_DAT_ +
                            *(longlong *)(lVar27 + (ulonglong)*_DAT_ * 8));
                  *(longlong **)(&stack0x00000f78 + lVar21) = plVar35;
                  lVar27 = *plVar35;
                  *(longlong *)(&stack0x00000f80 + lVar21) = lVar27;
                  if (lVar27 == 0) {
LAB_:
                    *(undefined8 *)(&stack0x00000900 + lVar21) = 0;
                  }
                  else {
                    lVar27 = **(longlong **)(lVar27 + 0x38);
                    *(longlong *)(&stack0x00000f88 + lVar21) = lVar27;
                    if (lVar27 == 0) goto LAB_;
                    *(longlong *)(&stack0x00000900 + lVar21) = lVar27;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103fe8;
                    iVar17 = (*_DAT_)(lVar27,0x337);
                    *(int *)(&stack0x000003c8 + lVar21) = iVar17;
                    if (iVar17 != 0) goto LAB_;
                  }
                  lVar27 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000f90 + lVar21) = lVar27;
                  lVar27 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar27 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x00000f98 + lVar21) = lVar27;
                  lVar27 = *(longlong *)(lVar27 + 8);
                  *(longlong *)(&stack0x00000fa0 + lVar21) = lVar27;
                  if (lVar27 != 0) {
                    uVar28 = *(undefined8 *)(lVar27 + 0x60);
                  }
                }
LAB_:
                *(undefined8 *)(&stack0x00000260 + lVar21) = uVar28;
                lVar27 = *(longlong *)(&stack0x000000c0 + lVar21);
                *(undefined8 *)(&stack0x000008a0 + lVar21) = *(undefined8 *)(lVar27 + 0x728);
LAB_:
                *(undefined4 *)(&stack0x00000270 + lVar21) = 0;
                if (*(longlong *)((longlong)&plStackX_10 + lVar21) != 0) {
                  puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 0x62);
                  *(undefined2 **)(&stack0x00000fa8 + lVar21) = puVar23;
                  *(undefined2 *)(&stack0x000001a8 + lVar21) = *puVar23;
                  if (((*(ushort *)(&stack0x000001a8 + lVar21) & 0x400) == 0) ||
                     (*(short *)((longlong)&uStackX_1c + lVar21) < 3)) {
                    *(int *)(&stack0x00000058 + lVar21) =
                         (int)*(short *)((longlong)&uStackX_1c + lVar21);
                    *(undefined8 *)(&stack0x00000588 + lVar21) =
                         *(undefined8 *)((longlong)&plStackX_10 + lVar21);
                    *(undefined2 **)(&stack0x00000fb0 + lVar21) = puVar23;
                    uVar16 = *puVar23;
                    *(undefined2 *)(&stack0x00000140 + lVar21) = uVar16;
                    if (((byte)uVar16 >> 3 & 1) != 0) {
                      if (*(int *)(&stack0x00000058 + lVar21) == 3) {
                        *(undefined4 *)(&stack0x00000058 + lVar21) = 4;
                      }
                      else if (*(int *)(&stack0x00000058 + lVar21) < 2) goto LAB_;
                      puVar30 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 100);
                      *(uint **)(&stack0x00000fb8 + lVar21) = puVar30;
                      uVar29 = *puVar30;
                      *(uint *)(&stack0x000003d0 + lVar21) = uVar29;
                      if ((((uVar29 & 8) != 0) &&
                          (lVar43 = *(longlong *)
                                     (*(longlong *)((longlong)&plStackX_10 + lVar21) + 0x90),
                          lVar43 != 0)) &&
                         (*(longlong *)(&stack0x00000fc0 + lVar21) = lVar43,
                         *(longlong *)(lVar43 + 0x758) != 0)) {
                        uVar28 = *(undefined8 *)(lVar43 + 0x758);
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104178;
                        func_0x
                                  (uVar28,*(undefined8 *)((longlong)&plStackX_10 + lVar21),
                                   *(undefined4 *)(&stack0x00000058 + lVar21));
                      }
                    }
LAB_:
                    (&stack0x000001f5)[lVar21] = DAT_ >> 7;
                    if ((char)DAT_ < '\0') {
                      puVar30 = (uint *)(*(longlong *)(&stack0x00000588 + lVar21) + 100);
                      *(uint **)(&stack0x00000fc8 + lVar21) = puVar30;
                      uVar29 = *puVar30;
                      *(uint *)(&stack0x000003d8 + lVar21) = uVar29;
                      if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x00000058 + lVar21))) {
                        *(uint **)(&stack0x00000fd0 + lVar21) = puVar30;
                        uVar29 = *puVar30;
                        *(uint *)(&stack0x000003e0 + lVar21) = uVar29;
                        if (((uVar29 & 0xc0000000) != 0x40000000) &&
                           (lVar43 = **(longlong **)(&stack0x00000588 + lVar21), lVar43 != 0)) {
                          *(undefined4 *)(&stack0x00000810 + lVar21) = 2;
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104207;
                          iVar17 = (*_DAT_)(lVar43,0x2000,2,&stack0x00000814 + lVar21);
                          if (iVar17 != 0) {
                            LOCK();
                            *puVar30 = *puVar30 & 0x3fffffff;
                            UNLOCK();
                            LOCK();
                            *puVar30 = *puVar30 | 0x40000000;
                            UNLOCK();
                          }
                        }
                      }
                    }
                    lVar43 = *(longlong *)(&stack0x00000588 + lVar21);
                    uVar20 = *(undefined4 *)(&stack0x00000058 + lVar21);
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104236;
                    func_0x(lVar43 + 0x98,uVar20);
                    if ((_DAT_ != 0) &&
                       ((&stack0x000001f6)[lVar21] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0
                       )) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104260;
                      func_0x(lVar43,0,uVar20);
                    }
                    *(uint *)((longlong)&uStackX_1c + lVar21) =
                         *(uint *)((longlong)&uStackX_1c + lVar21) & 0xffff0000;
                    *(undefined8 *)((longlong)&plStackX_10 + lVar21) = 0;
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104071;
                    func_0x((longlong)&plStackX_10 + lVar21);
                  }
                }
                if (*(longlong *)(lVar27 + 0x728) != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104297;
                  func_0x((longlong)&plStackX_10 + lVar21,&stack0x00000044 + lVar21,
                                  *(undefined8 *)(&stack0x000000c0 + lVar21));
                  if (*(longlong *)((longlong)&plStackX_10 + lVar21) != 0) {
                    puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 0x62);
                    *(undefined2 **)(&stack0x00000fd8 + lVar21) = puVar23;
                    *(undefined2 *)(&stack0x00000148 + lVar21) = *puVar23;
                    if (((*(ushort *)(&stack0x00000148 + lVar21) & 0x400) == 0) ||
                       (*(short *)((longlong)&uStackX_1c + lVar21) < 3)) {
                      *(int *)(&stack0x00000050 + lVar21) =
                           (int)*(short *)((longlong)&uStackX_1c + lVar21);
                      *(undefined8 *)(&stack0x00000590 + lVar21) =
                           *(undefined8 *)((longlong)&plStackX_10 + lVar21);
                      *(undefined2 **)(&stack0x00000fe0 + lVar21) = puVar23;
                      uVar16 = *puVar23;
                      *(undefined2 *)(&stack0x00000150 + lVar21) = uVar16;
                      if (((byte)uVar16 >> 3 & 1) != 0) {
                        if (*(int *)(&stack0x00000050 + lVar21) == 3) {
                          *(undefined4 *)(&stack0x00000050 + lVar21) = 4;
                        }
                        else if (*(int *)(&stack0x00000050 + lVar21) < 2) goto LAB_;
                        puVar30 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 100);
                        *(uint **)(&stack0x00000fe8 + lVar21) = puVar30;
                        uVar29 = *puVar30;
                        *(uint *)(&stack0x000003e8 + lVar21) = uVar29;
                        if ((((uVar29 & 8) != 0) &&
                            (lVar43 = *(longlong *)
                                       (*(longlong *)((longlong)&plStackX_10 + lVar21) + 0x90),
                            lVar43 != 0)) &&
                           (*(longlong *)(&stack0x00000ff0 + lVar21) = lVar43,
                           *(longlong *)(lVar43 + 0x758) != 0)) {
                          uVar28 = *(undefined8 *)(lVar43 + 0x758);
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10438d;
                          func_0x
                                    (uVar28,*(undefined8 *)((longlong)&plStackX_10 + lVar21),
                                     *(undefined4 *)(&stack0x00000050 + lVar21));
                        }
                      }
LAB_:
                      (&stack0x000001f7)[lVar21] = DAT_ >> 7;
                      if ((char)DAT_ < '\0') {
                        puVar30 = (uint *)(*(longlong *)(&stack0x00000590 + lVar21) + 100);
                        *(uint **)(&stack0x00000ff8 + lVar21) = puVar30;
                        uVar29 = *puVar30;
                        *(uint *)(&stack0x000003f0 + lVar21) = uVar29;
                        if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x00000050 + lVar21))) {
                          *(uint **)(&stack0x00001000 + lVar21) = puVar30;
                          uVar29 = *puVar30;
                          *(uint *)(&stack0x000003f8 + lVar21) = uVar29;
                          if (((uVar29 & 0xc0000000) != 0x40000000) &&
                             (lVar43 = **(longlong **)(&stack0x00000590 + lVar21), lVar43 != 0)) {
                            *(undefined4 *)(&stack0x00000818 + lVar21) = 2;
                            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10441c;
                            iVar17 = (*_DAT_)(lVar43,0x2000,2,&stack0x0000081c + lVar21);
                            if (iVar17 != 0) {
                              LOCK();
                              *puVar30 = *puVar30 & 0x3fffffff;
                              UNLOCK();
                              LOCK();
                              *puVar30 = *puVar30 | 0x40000000;
                              UNLOCK();
                            }
                          }
                        }
                      }
                      lVar43 = *(longlong *)(&stack0x00000590 + lVar21);
                      uVar20 = *(undefined4 *)(&stack0x00000050 + lVar21);
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10444b;
                      func_0x(lVar43 + 0x98,uVar20);
                      if ((_DAT_ != 0) &&
                         ((&stack0x000001f8)[lVar21] = DAT_ >> 1,
                         (DAT_ >> 1 & 1) != 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104475;
                        func_0x(lVar43,0,uVar20);
                      }
                      *(uint *)((longlong)&uStackX_1c + lVar21) =
                           *(uint *)((longlong)&uStackX_1c + lVar21) & 0xffff0000;
                      *(undefined8 *)((longlong)&plStackX_10 + lVar21) = 0;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1042db;
                      func_0x((longlong)&plStackX_10 + lVar21);
                    }
                  }
                }
                *(undefined8 *)(&stack0xfffffffffffffff0 + lVar21) =
                     *(undefined8 *)(&stack0x000006a0 + lVar21);
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar21) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1044b5;
                plVar35 = (longlong *)
                          func_0x
                                    (_DAT_,*(undefined8 *)(&stack0x000000c0 + lVar21),
                                     &stack0x00000044 + lVar21,&stack0x00000270 + lVar21);
                *(longlong **)((longlong)&plStackX_10 + lVar21) = plVar35;
                uVar29 = *(uint *)((longlong)&uStackX_1c + lVar21) & 0xffff0002 | 2;
                *(uint *)((longlong)&uStackX_1c + lVar21) = uVar29;
                if (*(longlong *)(&stack0x00000260 + lVar21) != 0) {
                  lVar43 = *plVar35;
                  *(longlong *)(&stack0x00001008 + lVar21) = lVar43;
                  plVar36 = (longlong *)(*(longlong *)(&stack0x00000260 + lVar21) + 0x500);
                  *(longlong **)(&stack0x00001010 + lVar21) = plVar36;
                  plVar35 = plVar36 + (ulonglong)(*(uint *)plVar36 & 0xf) + 1;
                  *(longlong **)(&stack0x00001018 + lVar21) = plVar35;
                  if (*plVar35 != lVar43) {
                    *plVar35 = lVar43;
                    *plVar36 = *plVar36 + 1;
                    uVar29 = *(uint *)((longlong)&uStackX_1c + lVar21);
                  }
                }
                uVar19 = *(uint *)(&stack0x00000270 + lVar21) >> 3 & 1;
                *(uint *)((longlong)&uStackX_1c + lVar21) = uVar19 << 0x18 | uVar29 & 0xffffff;
                *(uint *)((longlong)auStackX_20 + lVar21) =
                     *(uint *)(&stack0x00000270 + lVar21) >> 4 & 1 |
                     *(uint *)((longlong)auStackX_20 + lVar21) & 0xffffff00;
                lVar43 = *(longlong *)(&stack0x000008a0 + lVar21);
                if (((lVar43 != 0) && (*(longlong *)(&stack0x00000260 + lVar21) != 0)) &&
                   (*(longlong *)(&stack0x00000260 + lVar21) ==
                    *(longlong *)(*(longlong *)(&stack0x000000c0 + lVar21) + 0x1c38))) {
                  *(uint *)(&stack0x000008d8 + lVar21) = uVar19;
                  *(longlong *)(&stack0x00001020 + lVar21) = lVar43 + 0x59b8;
                  *(longlong *)(lVar43 + 0x5b28) = *(longlong *)(lVar43 + 0x5b28) + 1;
                  puVar30 = *(uint **)(&stack0x000006a0 + lVar21);
                  if (puVar30[1] != 0) {
                    *(longlong *)(lVar43 + 0x5b30) = *(longlong *)(lVar43 + 0x5b30) + 1;
                    *(longlong *)(lVar43 + 0x5b38) =
                         *(longlong *)(lVar43 + 0x5b38) + (ulonglong)*puVar30;
                    if (uVar19 != 0) {
                      *(longlong *)(lVar43 + 0x5b40) = *(longlong *)(lVar43 + 0x5b40) + 1;
                      *(longlong *)(lVar43 + 0x5b48) =
                           *(longlong *)(lVar43 + 0x5b48) + (ulonglong)*puVar30;
                    }
                  }
                }
                lVar43 = *(longlong *)(&stack0x000000c0 + lVar21);
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1045db;
                cVar12 = func_0x(lVar43);
                if ((cVar12 == '\0') || (*(char *)(lVar43 + 0x2050) == '\0')) goto LAB_;
                if (*(int *)(&stack0x00000044 + lVar21) == 0) {
LAB_:
                  (&stack0x0000003a)[lVar21] = 1;
                  goto LAB_;
                }
                *(undefined4 *)(&stack0x000000e8 + lVar21) = 9;
                *(undefined2 *)(&stack0x000000ec + lVar21) = 1;
                if ((*(int *)(&stack0x00000044 + lVar21) == 9) &&
                   (*(short *)(&stack0x00000048 + lVar21) == 1)) goto LAB_;
                (&stack0x0000003a)[lVar21] = 0;
                lVar43 = **(longlong **)((longlong)&plStackX_10 + lVar21);
                *(longlong *)(&stack0x00001028 + lVar21) = lVar43;
                (&stack0x00000037)[lVar21] = 0;
                if (*(short *)(lVar43 + 0x24) == 0) {
LAB_:
                  *(undefined8 *)(&stack0x000002b0 + lVar21) = *(undefined8 *)(lVar43 + 0x28);
                  *(undefined2 *)(&stack0x000002b8 + lVar21) = *(undefined2 *)(lVar43 + 0x30);
                }
                else {
                  cVar12 = *(char *)(lVar43 + 1);
                  if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                     (*(int *)(lVar43 + 0x18) == 99)) {
                    *(undefined **)(&stack0x00001030 + lVar21) = &stack0x00000318 + lVar21;
                    *(undefined4 **)(&stack0x00001038 + lVar21) = (undefined4 *)(lVar43 + 0x20);
                    *(undefined4 *)(&stack0x00000318 + lVar21) = *(undefined4 *)(lVar43 + 0x20);
                    *(undefined2 *)(&stack0x0000031c + lVar21) = *(undefined2 *)(lVar43 + 0x24);
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1046a1;
                    cVar12 = func_0x(&stack0x00000318 + lVar21);
                    if (cVar12 == '\0') goto LAB_;
                    cVar12 = '\x01';
                  }
                  else {
LAB_:
                    cVar12 = '\0';
                  }
                  (&stack0x00000037)[lVar21] = cVar12;
                  if (cVar12 == '\0') goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1046c3;
                  func_0x(lVar43,&stack0x000002b0 + lVar21);
                }
                *(undefined **)(&stack0x00001040 + lVar21) = &stack0x000002b0 + lVar21;
                lVar43 = *(longlong *)(&stack0x000000c0 + lVar21) + 0x20fc;
                *(longlong *)(&stack0x000008a8 + lVar21) = lVar43;
                *(undefined4 *)(&stack0x00000274 + lVar21) = 0;
                *(undefined4 *)(&stack0x00000278 + lVar21) = 0;
                *(undefined2 *)(&stack0x0000027c + lVar21) = 0;
                *(undefined2 *)(&stack0x0000027e + lVar21) = 0;
                puVar30 = (uint *)(*(longlong *)(&stack0x000000c0 + lVar21) + 0x2108);
                *(uint **)(&stack0x00001048 + lVar21) = puVar30;
                uVar29 = *puVar30;
                *(uint *)(&stack0x00000280 + lVar21) = uVar29;
                *(uint **)(&stack0x000008b0 + lVar21) = puVar30;
                do {
                  *(uint *)(&stack0x00000400 + lVar21) = uVar29 & 0xfffffffe;
                  *(undefined8 *)(&stack0x00000274 + lVar21) =
                       **(undefined8 **)(&stack0x000008a8 + lVar21);
                  *(undefined4 *)(&stack0x0000027c + lVar21) =
                       *(undefined4 *)(*(undefined8 **)(&stack0x000008a8 + lVar21) + 1);
                  LOCK();
                  *(undefined4 *)(&stack0xffffffffffffffc8 + lVar21) =
                       *(undefined4 *)(&stack0xffffffffffffffc8 + lVar21);
                  UNLOCK();
                  uVar29 = **(uint **)(&stack0x000008b0 + lVar21);
                  *(uint *)(&stack0x00000280 + lVar21) = uVar29;
                } while (*(uint *)(&stack0x00000400 + lVar21) != uVar29);
                if ((*(uint *)(&stack0x000002b0 + lVar21) <= *(uint *)(&stack0x00000274 + lVar21))
                   && ((*(uint *)(&stack0x00000274 + lVar21) != *(uint *)(&stack0x000002b0 + lVar21)
                       || ((uVar29 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000274 + lVar21) >>
                                           0x20), *(uint *)(&stack0x000002b4 + lVar21) <= uVar29 &&
                           ((uVar29 != *(uint *)(&stack0x000002b4 + lVar21) ||
                            (*(ushort *)(&stack0x000002b8 + lVar21) <=
                             *(ushort *)(&stack0x0000027c + lVar21))))))))) goto LAB_;
                if (*(char *)(*(longlong *)(&stack0x000000c0 + lVar21) + 0x6ac8) != '\0') {
LAB_:
                  if ((&stack0x00000028)[lVar21] != '\0') goto LAB_;
                  lVar43 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00001118 + lVar21) = lVar43;
                  lVar43 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar43 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x00001120 + lVar21) = lVar43;
                  lVar43 = *(longlong *)(lVar43 + 8);
                  *(longlong *)(&stack0x00001128 + lVar21) = lVar43;
                  lVar43 = *(longlong *)(lVar43 + 0x60);
                  *(longlong *)(&stack0x00001130 + lVar21) = lVar43;
                  if (lVar43 == *(longlong *)(*(longlong *)(&stack0x000000c0 + lVar21) + 0x2120))
                  goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104efc;
                  cVar12 = func_0x(*(longlong *)(&stack0x000000c0 + lVar21));
                  if (cVar12 != '\0') goto LAB_;
                  if (*(longlong *)(&stack0x00000260 + lVar21) == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104f14;
                    uVar28 = func_0x();
                    *(undefined8 *)(&stack0x00000260 + lVar21) = uVar28;
                  }
                  *(undefined **)(&stack0x00001138 + lVar21) = &stack0x000002d0 + lVar21;
                  lVar43 = **(longlong **)((longlong)&plStackX_10 + lVar21);
                  *(longlong *)(&stack0x00001140 + lVar21) = lVar43;
                  (&stack0x00000039)[lVar21] = 0;
                  if (*(short *)(lVar43 + 0x24) == 0) {
LAB_:
                    uVar28 = *(undefined8 *)(lVar43 + 0x28);
                    *(undefined8 *)(&stack0x000002d0 + lVar21) = uVar28;
                    uVar16 = *(undefined2 *)(lVar43 + 0x30);
                    *(undefined2 *)(&stack0x000002d8 + lVar21) = uVar16;
                  }
                  else {
                    cVar12 = *(char *)(lVar43 + 1);
                    if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                       (*(int *)(lVar43 + 0x18) == 99)) {
                      *(undefined **)(&stack0x00001148 + lVar21) = &stack0x00000300 + lVar21;
                      *(undefined4 **)(&stack0x00001150 + lVar21) = (undefined4 *)(lVar43 + 0x20);
                      *(undefined4 *)(&stack0x00000300 + lVar21) = *(undefined4 *)(lVar43 + 0x20);
                      *(undefined2 *)(&stack0x00000304 + lVar21) = *(undefined2 *)(lVar43 + 0x24);
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104fa3;
                      cVar12 = func_0x(&stack0x00000300 + lVar21);
                      if (cVar12 == '\0') goto LAB_;
                      cVar12 = '\x01';
                    }
                    else {
LAB_:
                      cVar12 = '\0';
                    }
                    (&stack0x00000039)[lVar21] = cVar12;
                    if (cVar12 == '\0') goto LAB_;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104fc5;
                    func_0x(lVar43,&stack0x000002d0 + lVar21);
                    uVar16 = *(undefined2 *)(&stack0x000002d8 + lVar21);
                    uVar28 = *(undefined8 *)(&stack0x000002d0 + lVar21);
                  }
                  *(undefined **)(&stack0x00001158 + lVar21) = &stack0x000002d0 + lVar21;
                  *(undefined8 *)(&stack0x00000360 + lVar21) = uVar28;
                  *(undefined2 *)(&stack0x00000368 + lVar21) = uVar16;
                  *(undefined2 *)(&stack0x0000036a + lVar21) = 0;
                  if (*(longlong *)((longlong)&plStackX_10 + lVar21) != 0) {
                    puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 0x62);
                    *(undefined2 **)(&stack0x00001160 + lVar21) = puVar23;
                    *(undefined2 *)(&stack0x00000158 + lVar21) = *puVar23;
                    if (((*(ushort *)(&stack0x00000158 + lVar21) & 0x400) == 0) ||
                       (*(short *)((longlong)&uStackX_1c + lVar21) < 3)) {
                      *(int *)(&stack0x000000b8 + lVar21) =
                           (int)*(short *)((longlong)&uStackX_1c + lVar21);
                      *(undefined8 *)(&stack0x00000598 + lVar21) =
                           *(undefined8 *)((longlong)&plStackX_10 + lVar21);
                      *(undefined2 **)(&stack0x00001168 + lVar21) = puVar23;
                      uVar16 = *puVar23;
                      *(undefined2 *)(&stack0x00000160 + lVar21) = uVar16;
                      if (((byte)uVar16 >> 3 & 1) != 0) {
                        if (*(int *)(&stack0x000000b8 + lVar21) == 3) {
                          *(undefined4 *)(&stack0x000000b8 + lVar21) = 4;
                        }
                        else if (*(int *)(&stack0x000000b8 + lVar21) < 2) goto LAB_;
                        puVar30 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 100);
                        *(uint **)(&stack0x00001170 + lVar21) = puVar30;
                        uVar29 = *puVar30;
                        *(uint *)(&stack0x00000410 + lVar21) = uVar29;
                        if ((((uVar29 & 8) != 0) &&
                            (lVar43 = *(longlong *)
                                       (*(longlong *)((longlong)&plStackX_10 + lVar21) + 0x90),
                            lVar43 != 0)) &&
                           (*(longlong *)(&stack0x00001178 + lVar21) = lVar43,
                           *(longlong *)(lVar43 + 0x758) != 0)) {
                          uVar28 = *(undefined8 *)(lVar43 + 0x758);
                          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10511c;
                          func_0x
                                    (uVar28,*(undefined8 *)((longlong)&plStackX_10 + lVar21),
                                     *(undefined4 *)(&stack0x000000b8 + lVar21));
                        }
                      }
LAB_:
                      (&stack0x000001f9)[lVar21] = DAT_ >> 7;
                      if ((char)DAT_ < '\0') {
                        puVar30 = (uint *)(*(longlong *)(&stack0x00000598 + lVar21) + 100);
                        *(uint **)(&stack0x00001180 + lVar21) = puVar30;
                        uVar29 = *puVar30;
                        *(uint *)(&stack0x00000418 + lVar21) = uVar29;
                        if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x000000b8 + lVar21))) {
                          *(uint **)(&stack0x00001188 + lVar21) = puVar30;
                          uVar29 = *puVar30;
                          *(uint *)(&stack0x00000420 + lVar21) = uVar29;
                          if (((uVar29 & 0xc0000000) != 0x40000000) &&
                             (lVar43 = **(longlong **)(&stack0x00000598 + lVar21), lVar43 != 0)) {
                            *(undefined4 *)(&stack0x000008ec + lVar21) = 2;
                            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1051ab;
                            iVar17 = (*_DAT_)(lVar43,0x2000,2,&stack0x000008f0 + lVar21);
                            if (iVar17 != 0) {
                              LOCK();
                              *puVar30 = *puVar30 & 0x3fffffff;
                              UNLOCK();
                              LOCK();
                              *puVar30 = *puVar30 | 0x40000000;
                              UNLOCK();
                            }
                          }
                        }
                      }
                      lVar43 = *(longlong *)(&stack0x00000598 + lVar21);
                      uVar20 = *(undefined4 *)(&stack0x000000b8 + lVar21);
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1051da;
                      func_0x(lVar43 + 0x98,uVar20);
                      if ((_DAT_ != 0) &&
                         ((&stack0x000001fa)[lVar21] = DAT_ >> 1,
                         (DAT_ >> 1 & 1) != 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105204;
                        func_0x(lVar43,0,uVar20);
                      }
                      *(uint *)((longlong)&uStackX_1c + lVar21) =
                           *(uint *)((longlong)&uStackX_1c + lVar21) & 0xffff0000;
                      *(undefined8 *)((longlong)&plStackX_10 + lVar21) = 0;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10506a;
                      func_0x((longlong)&plStackX_10 + lVar21);
                    }
                    uVar28 = *(undefined8 *)(&stack0x00000360 + lVar21);
                    uVar16 = *(undefined2 *)(&stack0x00000368 + lVar21);
                  }
                  *(undefined **)(&stack0x00001190 + lVar21) = &stack0x00000718 + lVar21;
                  *(undefined8 *)(&stack0x00000718 + lVar21) = uVar28;
                  *(undefined2 *)(&stack0x00000720 + lVar21) = uVar16;
                  *(undefined **)(&stack0x00001198 + lVar21) = &stack0x00000650 + lVar21;
                  *(undefined8 *)(&stack0x00000650 + lVar21) = uVar28;
                  *(undefined2 *)(&stack0x00000658 + lVar21) = uVar16;
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar21) = 0;
                  uVar28 = *(undefined8 *)(lVar27 + 0x728);
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105289;
                  func_0x(uVar28,&stack0x00000650 + lVar21,4);
                  goto LAB_;
                }
                lVar31 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                *(longlong *)(&stack0x00001050 + lVar21) = lVar31;
                lVar31 = (ulonglong)*_DAT_ +
                         *(longlong *)(lVar31 + (ulonglong)*_DAT_ * 8);
                *(longlong *)(&stack0x00001058 + lVar21) = lVar31;
                lVar31 = *(longlong *)(lVar31 + 8);
                *(longlong *)(&stack0x00001060 + lVar21) = lVar31;
                lVar31 = *(longlong *)(lVar31 + 0x60);
                *(longlong *)(&stack0x00001068 + lVar21) = lVar31;
                if (lVar31 == *(longlong *)(*(longlong *)(&stack0x000000c0 + lVar21) + 0x2120))
                goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10485a;
                cVar12 = func_0x(*(longlong *)(&stack0x000000c0 + lVar21));
                if (cVar12 != '\0') goto LAB_;
                *(longlong *)(&stack0x000006a8 + lVar21) = lVar43;
                *(undefined4 *)(&stack0x00000248 + lVar21) = 0;
                *(undefined4 *)(&stack0x0000024c + lVar21) = 0;
                *(undefined2 *)(&stack0x00000250 + lVar21) = 0;
                *(undefined2 *)(&stack0x00000252 + lVar21) = 0;
                *(uint **)(&stack0x00001070 + lVar21) = puVar30;
                uVar29 = *puVar30;
                *(uint *)(&stack0x00000284 + lVar21) = uVar29;
                puVar37 = *(undefined8 **)(&stack0x000006a8 + lVar21);
                *(longlong *)(&stack0x000008b8 + lVar21) = (longlong)puVar37 + 0xc;
                while( true ) {
                  *(uint *)(&stack0x00000404 + lVar21) = uVar29 & 0xfffffffe;
                  *(undefined8 *)(&stack0x00000248 + lVar21) = *puVar37;
                  *(undefined4 *)(&stack0x00000250 + lVar21) = *(undefined4 *)(puVar37 + 1);
                  LOCK();
                  *(undefined4 *)(&stack0xffffffffffffffc8 + lVar21) =
                       *(undefined4 *)(&stack0xffffffffffffffc8 + lVar21);
                  UNLOCK();
                  uVar29 = **(uint **)(&stack0x000008b8 + lVar21);
                  *(uint *)(&stack0x00000284 + lVar21) = uVar29;
                  if (*(uint *)(&stack0x00000404 + lVar21) == uVar29) break;
                  puVar37 = *(undefined8 **)(&stack0x000006a8 + lVar21);
                }
                *(undefined8 *)(&stack0x00000708 + lVar21) =
                     *(undefined8 *)(&stack0x00000248 + lVar21);
                uVar15 = *(ushort *)(&stack0x00000250 + lVar21);
                *(ushort *)(&stack0x00000710 + lVar21) = uVar15;
                lVar27 = **(longlong **)((longlong)&plStackX_10 + lVar21);
                *(longlong *)(&stack0x00001078 + lVar21) = lVar27;
                (&stack0x00000038)[lVar21] = 0;
                if (*(short *)(lVar27 + 0x24) == 0) {
LAB_:
                  *(undefined8 *)(&stack0x000002c0 + lVar21) = *(undefined8 *)(lVar27 + 0x28);
                  uVar45 = *(ushort *)(lVar27 + 0x30);
                  *(ushort *)(&stack0x000002c8 + lVar21) = uVar45;
                }
                else {
                  cVar12 = *(char *)(lVar27 + 1);
                  if ((((cVar12 == '\v') || (cVar12 == '\b')) || (cVar12 == '\t')) &&
                     (*(int *)(lVar27 + 0x18) == 99)) {
                    *(undefined **)(&stack0x00001080 + lVar21) = &stack0x00000308 + lVar21;
                    *(undefined4 **)(&stack0x00001088 + lVar21) = (undefined4 *)(lVar27 + 0x20);
                    *(undefined4 *)(&stack0x00000308 + lVar21) = *(undefined4 *)(lVar27 + 0x20);
                    *(undefined2 *)(&stack0x0000030c + lVar21) = *(undefined2 *)(lVar27 + 0x24);
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104994;
                    cVar12 = func_0x(&stack0x00000308 + lVar21);
                    if (cVar12 == '\0') goto LAB_;
                    cVar12 = '\x01';
                  }
                  else {
LAB_:
                    cVar12 = '\0';
                  }
                  (&stack0x00000038)[lVar21] = cVar12;
                  if (cVar12 == '\0') goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1049b6;
                  func_0x(lVar27,&stack0x000002c0 + lVar21);
                  uVar45 = *(ushort *)(&stack0x000002c8 + lVar21);
                }
                if ((*(uint *)(&stack0x00000248 + lVar21) < *(uint *)(&stack0x000002c0 + lVar21)) ||
                   ((iVar17 = iVar18,
                    *(uint *)(&stack0x00000248 + lVar21) == *(uint *)(&stack0x000002c0 + lVar21) &&
                    ((uVar29 = (uint)((ulonglong)*(undefined8 *)(&stack0x000002c0 + lVar21) >> 0x20)
                     , *(uint *)(&stack0x0000024c + lVar21) < uVar29 ||
                     ((*(uint *)(&stack0x0000024c + lVar21) == uVar29 && (uVar15 < uVar45)))))))) {
                  iVar17 = 1;
                }
                if (iVar17 != 0) {
                  lVar27 = *(longlong *)(&stack0x000000c0 + lVar21);
                  lVar43 = *(longlong *)(lVar27 + 0x6b0);
                  *(longlong *)(&stack0x00001090 + lVar21) = lVar43;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104a53;
                  func_0x(&stack0x000002c0 + lVar21,&stack0x000022d0 + lVar21,
                                  &stack0x00000408 + lVar21);
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104a70;
                  func_0x(&stack0x00000708 + lVar21,&stack0x00002300 + lVar21,
                                  &stack0x00000408 + lVar21);
                  *(undefined4 *)(&stack0x000008c0 + lVar21) = 0x1d;
                  *(undefined4 *)(&stack0x000008c4 + lVar21) = 0x10000;
                  if ((_DAT_ & 0x10000) != 0) {
                    *(undefined2 *)(&stack0x00000530 + lVar21) = 6;
                    *(undefined **)(&stack0x00001098 + lVar21) = &stack0x000013f0 + lVar21;
                    *(undefined2 *)(&stack0x000013f0 + lVar21) = 0;
                    *(undefined2 *)(&stack0x000013f2 + lVar21) = 6;
                    *(undefined4 *)(&stack0x000013f8 + lVar21) = 0;
                    *(undefined **)(&stack0x00001400 + lVar21) = &stack0x00001418 + lVar21;
                    *(undefined **)(&stack0x00001408 + lVar21) = &stack0x00001478 + lVar21;
                    *(undefined4 *)(&stack0x00001638 + lVar21) = 0;
                    *(undefined4 *)(&stack0x0000163c + lVar21) = 0;
                    *(undefined8 *)(&stack0x00001410 + lVar21) = 0;
                    *(undefined8 *)(&stack0x00001640 + lVar21) = 0;
                    *(undefined **)(&stack0x000010a0 + lVar21) = &stack0x00001418 + lVar21;
                    *(undefined **)(&stack0x00001418 + lVar21) = &stack0x00001648 + lVar21;
                    *(undefined4 *)(&stack0x00001420 + lVar21) = 0x34;
                    *(undefined2 *)(&stack0x00001424 + lVar21) = 5;
                    *(undefined2 *)(&stack0x00001426 + lVar21) = 0;
                    *(undefined **)(&stack0x000010a8 + lVar21) = &stack0x00001428 + lVar21;
                    *(undefined8 *)(&stack0x00001428 + lVar21) = 0x1641f98;
                    *(undefined4 *)(&stack0x00001430 + lVar21) = 0x10;
                    *(undefined2 *)(&stack0x00001434 + lVar21) = 5;
                    *(undefined2 *)(&stack0x00001436 + lVar21) = 0;
                    *(undefined **)(&stack0x000010b0 + lVar21) = &stack0x00001438 + lVar21;
                    *(undefined8 *)(&stack0x00001438 + lVar21) = 0x1641f98;
                    *(undefined4 *)(&stack0x00001440 + lVar21) = 0x10;
                    *(undefined2 *)(&stack0x00001444 + lVar21) = 6;
                    *(undefined2 *)(&stack0x00001446 + lVar21) = 0;
                    *(undefined **)(&stack0x000010b8 + lVar21) = &stack0x00001448 + lVar21;
                    *(undefined8 *)(&stack0x00001448 + lVar21) = 0;
                    *(undefined4 *)(&stack0x00001450 + lVar21) = 0;
                    *(undefined2 *)(&stack0x00001454 + lVar21) = 7;
                    *(undefined2 *)(&stack0x00001456 + lVar21) = 0;
                    *(undefined **)(&stack0x000010c0 + lVar21) = &stack0x00001458 + lVar21;
                    *(undefined8 *)(&stack0x00001458 + lVar21) = 0;
                    *(undefined4 *)(&stack0x00001460 + lVar21) = 0;
                    *(undefined2 *)(&stack0x00001464 + lVar21) = 8;
                    *(undefined2 *)(&stack0x00001466 + lVar21) = 0;
                    *(undefined **)(&stack0x000010c8 + lVar21) = &stack0x00001468 + lVar21;
                    *(undefined8 *)(&stack0x00001468 + lVar21) = 0;
                    *(undefined4 *)(&stack0x00001470 + lVar21) = 0;
                    *(undefined2 *)(&stack0x00001474 + lVar21) = 9;
                    *(undefined2 *)(&stack0x00001476 + lVar21) = 0;
                    *(uint *)(&stack0x00001648 + lVar21) = (uint)*(ushort *)(lVar27 + 0x6b8);
                    *(undefined2 *)(&stack0x0000164c + lVar21) =
                         *(undefined2 *)(&stack0x00000048 + lVar21);
                    *(undefined4 *)(&stack0x0000164e + lVar21) =
                         *(undefined4 *)(&stack0x00000044 + lVar21);
                    (&stack0x00001652)[lVar21] = (&stack0x00000029)[lVar21];
                    lVar27 = **(longlong **)((longlong)&plStackX_10 + lVar21);
                    *(longlong *)(&stack0x000010d0 + lVar21) = lVar27;
                    (&stack0x00001653)[lVar21] = *(undefined *)(lVar27 + 1);
                    *(undefined **)(&stack0x000010d8 + lVar21) = &stack0x00001428 + lVar21;
                    *(longlong *)(&stack0x00001428 + lVar21) = lVar43 + 0x254;
                    *(undefined4 *)(&stack0x00001430 + lVar21) = 0x10;
                    *(undefined2 *)(&stack0x00001434 + lVar21) = 5;
                    *(undefined2 *)(&stack0x00001436 + lVar21) = 0;
                    *(undefined **)(&stack0x000010e0 + lVar21) = &stack0x00001438 + lVar21;
                    *(longlong *)(&stack0x00001438 + lVar21) = lVar43 + 0x244;
                    *(undefined4 *)(&stack0x00001440 + lVar21) = 0x10;
                    *(undefined2 *)(&stack0x00001444 + lVar21) = 6;
                    *(undefined2 *)(&stack0x00001446 + lVar21) = 0;
                    *(undefined **)(&stack0x000010e8 + lVar21) = &stack0x000022d0 + lVar21;
                    lVar27 = -1;
                    do {
                      lVar27 = lVar27 + 1;
                    } while (*(short *)(&stack0x000022d0 + lVar27 * 2 + lVar21) != 0);
                    iVar17 = (int)lVar27 * 2;
                    *(int *)(&stack0x000008e0 + lVar21) = iVar17;
                    *(undefined **)(&stack0x000010f0 + lVar21) = &stack0x00001448 + lVar21;
                    *(undefined **)(&stack0x00001448 + lVar21) = &stack0x000022d0 + lVar21;
                    *(int *)(&stack0x00001450 + lVar21) = iVar17;
                    *(undefined2 *)(&stack0x00001454 + lVar21) = 7;
                    *(undefined2 *)(&stack0x00001456 + lVar21) = 0;
                    *(undefined **)(&stack0x000010f8 + lVar21) = &stack0x00002300 + lVar21;
                    lVar27 = -1;
                    do {
                      lVar27 = lVar27 + 1;
                    } while (*(short *)(&stack0x00002300 + lVar27 * 2 + lVar21) != 0);
                    iVar17 = (int)lVar27 * 2;
                    *(int *)(&stack0x000008e4 + lVar21) = iVar17;
                    *(undefined **)(&stack0x00001100 + lVar21) = &stack0x00001458 + lVar21;
                    *(undefined **)(&stack0x00001458 + lVar21) = &stack0x00002300 + lVar21;
                    *(int *)(&stack0x00001460 + lVar21) = iVar17;
                    *(undefined2 *)(&stack0x00001464 + lVar21) = 8;
                    *(undefined2 *)(&stack0x00001466 + lVar21) = 0;
                    *(undefined4 *)(&stack0x0000040c + lVar21) = 0;
                    pcVar10 = *(code **)(_DAT_ + 0x10);
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104e29;
                    lVar27 = (*pcVar10)(lVar43,&stack0x0000040c + lVar21);
                    *(longlong *)(&stack0x00001108 + lVar21) = lVar27;
                    iVar17 = iVar18;
                    if (lVar27 != 0) {
                      lVar43 = -1;
                      do {
                        lVar43 = lVar43 + 1;
                      } while (*(short *)(lVar27 + lVar43 * 2) != 0);
                      iVar17 = (int)lVar43 * 2;
                    }
                    *(int *)(&stack0x000008e8 + lVar21) = iVar17;
                    lVar43 = *(longlong *)(&stack0x00001400 + lVar21);
                    *(longlong **)(&stack0x00001110 + lVar21) = (longlong *)(lVar43 + 0x50);
                    *(longlong *)(lVar43 + 0x50) = lVar27;
                    *(int *)(lVar43 + 0x58) = iVar17;
                    *(undefined2 *)(lVar43 + 0x5c) = 9;
                    *(undefined2 *)(lVar43 + 0x5e) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x104e88;
                    func_0x(&stack0x000013e8 + lVar21);
                  }
                }
LAB_:
                if ((1 < *(short *)((longlong)&uStackX_1c + lVar21)) &&
                   ((&stack0x00000029)[lVar21] != -1)) {
                  lVar27 = **(longlong **)((longlong)&plStackX_10 + lVar21);
                  *(longlong *)(&stack0x000011a0 + lVar21) = lVar27;
                  if (*(char *)(lVar27 + 1) != (&stack0x00000029)[lVar21]) {
                    if (*(longlong *)(&stack0x00000260 + lVar21) != 0) {
                      *(longlong *)(&stack0x000011a8 + lVar21) = lVar27;
                      *(longlong *)(*(longlong *)(&stack0x00000260 + lVar21) + 0x588) = lVar27;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1052e3;
                    lVar27 = func_0x();
                    if (lVar27 == 0) {
LAB_:
                      *(undefined4 *)(&stack0x00000428 + lVar21) = 0;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1052ed;
                      lVar27 = func_0x();
                      if (*(longlong *)(lVar27 + 0x30) == 0) goto LAB_;
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1052f9;
                      lVar27 = func_0x();
                      uVar29 = *(uint *)(*(longlong *)(lVar27 + 0x30) + 0xc);
                      *(uint *)(&stack0x0000093c + lVar21) = uVar29;
                      if ((0xd < uVar29) || (iVar17 = 1, (0x2640U >> (uVar29 & 0x1f) & 1) == 0)) {
                        iVar17 = iVar18;
                      }
                      *(int *)(&stack0x00000428 + lVar21) = iVar17;
                      if (iVar17 != 0) goto LAB_;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10533f;
                    func_0x(0,8);
                  }
                }
LAB_:
                *(undefined4 *)(&stack0x00000728 + lVar21) = 0;
                *(undefined4 *)(&stack0x0000072c + lVar21) = 0;
                *(undefined2 *)(&stack0x00000730 + lVar21) = 0;
                if (((*(short *)(&stack0x00000358 + lVar21) == 0) &&
                    (*(int *)(&stack0x00000350 + lVar21) == 0)) &&
                   (*(int *)(&stack0x00000354 + lVar21) == 0)) goto LAB_;
                lVar27 = **(longlong **)((longlong)&plStackX_10 + lVar21);
                *(longlong *)(&stack0x000011b0 + lVar21) = lVar27;
                if ((*(byte *)(lVar27 + 4) & 1) == 0) goto LAB_;
                puVar23 = (undefined2 *)
                          ((longlong)*(longlong **)((longlong)&plStackX_10 + lVar21) + 0x62);
                *(undefined2 **)(&stack0x000011b8 + lVar21) = puVar23;
                *(undefined2 *)(&stack0x00000168 + lVar21) = *puVar23;
                if (((*(ushort *)(&stack0x00000168 + lVar21) & 0x400) == 0) ||
                   (*(short *)((longlong)&uStackX_1c + lVar21) < 3)) {
                  *(int *)(&stack0x00000098 + lVar21) =
                       (int)*(short *)((longlong)&uStackX_1c + lVar21);
                  *(undefined8 *)(&stack0x000005a0 + lVar21) =
                       *(undefined8 *)((longlong)&plStackX_10 + lVar21);
                  *(undefined2 **)(&stack0x000011c0 + lVar21) = puVar23;
                  uVar16 = *puVar23;
                  *(undefined2 *)(&stack0x00000170 + lVar21) = uVar16;
                  if (((byte)uVar16 >> 3 & 1) != 0) {
                    if (*(int *)(&stack0x00000098 + lVar21) == 3) {
                      *(undefined4 *)(&stack0x00000098 + lVar21) = 4;
                    }
                    else if (*(int *)(&stack0x00000098 + lVar21) < 2) goto LAB_;
                    puVar30 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 100);
                    *(uint **)(&stack0x000011c8 + lVar21) = puVar30;
                    uVar29 = *puVar30;
                    *(uint *)(&stack0x00000430 + lVar21) = uVar29;
                    if ((((uVar29 & 8) != 0) &&
                        (lVar27 = *(longlong *)
                                   (*(longlong *)((longlong)&plStackX_10 + lVar21) + 0x90),
                        lVar27 != 0)) &&
                       (*(longlong *)(&stack0x000011d0 + lVar21) = lVar27,
                       *(longlong *)(lVar27 + 0x758) != 0)) {
                      uVar28 = *(undefined8 *)(lVar27 + 0x758);
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105484;
                      func_0x
                                (uVar28,*(undefined8 *)((longlong)&plStackX_10 + lVar21),
                                 *(undefined4 *)(&stack0x00000098 + lVar21));
                    }
                  }
LAB_:
                  (&stack0x000001fb)[lVar21] = DAT_ >> 7;
                  if ((char)DAT_ < '\0') {
                    puVar30 = (uint *)(*(longlong *)(&stack0x000005a0 + lVar21) + 100);
                    *(uint **)(&stack0x000011d8 + lVar21) = puVar30;
                    uVar29 = *puVar30;
                    *(uint *)(&stack0x00000438 + lVar21) = uVar29;
                    if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x00000098 + lVar21))) {
                      *(uint **)(&stack0x000011e0 + lVar21) = puVar30;
                      uVar29 = *puVar30;
                      *(uint *)(&stack0x00000440 + lVar21) = uVar29;
                      if (((uVar29 & 0xc0000000) != 0x40000000) &&
                         (lVar27 = **(longlong **)(&stack0x000005a0 + lVar21), lVar27 != 0)) {
                        *(undefined4 *)(&stack0x00000940 + lVar21) = 2;
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105513;
                        iVar17 = (*_DAT_)(lVar27,0x2000,2,&stack0x00000944 + lVar21);
                        if (iVar17 != 0) {
                          LOCK();
                          *puVar30 = *puVar30 & 0x3fffffff;
                          UNLOCK();
                          LOCK();
                          *puVar30 = *puVar30 | 0x40000000;
                          UNLOCK();
                        }
                      }
                    }
                  }
                  lVar27 = *(longlong *)(&stack0x000005a0 + lVar21);
                  uVar20 = *(undefined4 *)(&stack0x00000098 + lVar21);
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105542;
                  func_0x(lVar27 + 0x98,uVar20);
                  if ((_DAT_ != 0) &&
                     ((&stack0x000001fc)[lVar21] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0))
                  {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10556c;
                    func_0x(lVar27,0,uVar20);
                  }
                  *(uint *)((longlong)&uStackX_1c + lVar21) =
                       *(uint *)((longlong)&uStackX_1c + lVar21) & 0xffff0000;
                  *(undefined8 *)((longlong)&plStackX_10 + lVar21) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1053d1;
                  func_0x((longlong)&plStackX_10 + lVar21);
                }
                *(undefined4 *)(&stack0x00000990 + lVar21) = 0x400060;
                *(undefined8 *)(&stack0x00000998 + lVar21) = 0;
                *(undefined8 *)(&stack0x000009a8 + lVar21) = 0;
                *(undefined8 *)(&stack0x000009a0 + lVar21) = 0;
                *(undefined8 *)(&stack0x000009b0 + lVar21) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1055b6;
                func_0x(10,&stack0x00000990 + lVar21);
              } while( true );
            }
            if (*(int *)(param_1 + 0xd0) != 2) {
              *(longlong ***)(&stack0x00000580 + lVar21) = pplVar47;
              if (*pplVar47 != (longlong *)0x0) {
                puVar23 = (undefined2 *)((longlong)*pplVar47 + 0x62);
                *(undefined2 **)(&stack0x00000ee0 + lVar21) = puVar23;
                *(undefined2 *)(&stack0x00000130 + lVar21) = *puVar23;
                plVar35 = *(longlong **)(&stack0x00000580 + lVar21);
                if (((*(ushort *)(&stack0x00000130 + lVar21) & 0x400) == 0) ||
                   (*(short *)((longlong)plVar35 + 0xc) < 3)) {
                  *(int *)(&stack0x00000090 + lVar21) = (int)*(short *)((longlong)plVar35 + 0xc);
                  lVar27 = *plVar35;
                  *(longlong *)(&stack0x00000200 + lVar21) = lVar27;
                  puVar23 = (undefined2 *)(lVar27 + 0x62);
                  *(undefined2 **)(&stack0x00000ee8 + lVar21) = puVar23;
                  uVar16 = *puVar23;
                  *(undefined2 *)(&stack0x00000138 + lVar21) = uVar16;
                  if (((byte)uVar16 >> 3 & 1) != 0) {
                    if (*(int *)(&stack0x00000090 + lVar21) == 3) {
                      *(undefined4 *)(&stack0x00000090 + lVar21) = 4;
                    }
                    else if (*(int *)(&stack0x00000090 + lVar21) < 2) goto LAB_;
                    *(uint **)(&stack0x00000ef0 + lVar21) =
                         (uint *)(*(longlong *)(&stack0x00000200 + lVar21) + 100);
                    uVar29 = *(uint *)(*(longlong *)(&stack0x00000200 + lVar21) + 100);
                    *(uint *)(&stack0x000003b0 + lVar21) = uVar29;
                    if ((((uVar29 & 8) != 0) &&
                        (lVar27 = *(longlong *)(*(longlong *)(&stack0x00000200 + lVar21) + 0x90),
                        lVar27 != 0)) &&
                       (*(longlong *)(&stack0x00000ef8 + lVar21) = lVar27,
                       *(longlong *)(lVar27 + 0x758) != 0)) {
                      uVar24 = *(undefined8 *)(lVar27 + 0x758);
                      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103afe;
                      func_0x
                                (uVar24,*(undefined8 *)(&stack0x00000200 + lVar21),
                                 *(undefined4 *)(&stack0x00000090 + lVar21));
                    }
                  }
LAB_:
                  (&stack0x000001b6)[lVar21] = DAT_ >> 7;
                  if ((char)DAT_ < '\0') {
                    puVar30 = (uint *)(*(longlong *)(&stack0x00000200 + lVar21) + 100);
                    *(uint **)(&stack0x00000f00 + lVar21) = puVar30;
                    uVar29 = *puVar30;
                    *(uint *)(&stack0x000003b8 + lVar21) = uVar29;
                    if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x00000090 + lVar21))) {
                      *(uint **)(&stack0x00000f08 + lVar21) = puVar30;
                      uVar29 = *puVar30;
                      *(uint *)(&stack0x000003c0 + lVar21) = uVar29;
                      if (((uVar29 & 0xc0000000) != 0x40000000) &&
                         (lVar27 = **(longlong **)(&stack0x00000200 + lVar21), lVar27 != 0)) {
                        *(undefined4 *)(&stack0x00000800 + lVar21) = 2;
                        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103b91;
                        iVar17 = (*_DAT_)(lVar27,0x2000,2,&stack0x00000804 + lVar21);
                        if (iVar17 != 0) {
                          LOCK();
                          *puVar30 = *puVar30 & 0x3fffffff;
                          UNLOCK();
                          LOCK();
                          *puVar30 = *puVar30 | 0x40000000;
                          UNLOCK();
                        }
                      }
                    }
                  }
                  lVar27 = *(longlong *)(&stack0x00000200 + lVar21);
                  uVar20 = *(undefined4 *)(&stack0x00000090 + lVar21);
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103bc0;
                  func_0x(lVar27 + 0x98,uVar20);
                  if ((_DAT_ != 0) &&
                     ((&stack0x000001b7)[lVar21] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0))
                  {
                    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103bea;
                    func_0x(lVar27,0,uVar20);
                  }
                  *(uint *)((longlong)plVar35 + 0xc) =
                       *(uint *)((longlong)plVar35 + 0xc) & 0xffff0000;
                  **(undefined8 **)(&stack0x00000580 + lVar21) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103857;
                  func_0x(plVar35);
                }
              }
              *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
              *(undefined8 **)(&stack0x00000f10 + lVar21) = (undefined8 *)(param_1 + 0x88);
              if (*(int *)(param_1 + 0x90) != 0) {
                *(undefined4 *)(&stack0x00000808 + lVar21) = *(undefined4 *)(param_1 + 0x94);
                *(undefined8 *)(&stack0x00000f18 + lVar21) = *(undefined8 *)(param_1 + 0x88);
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x103c39;
                func_0x();
                *(undefined4 *)(param_1 + 0x90) = 0;
              }
              *(undefined4 *)(&stack0x00000220 + lVar21) = 0;
              *(undefined2 *)(&stack0x00000224 + lVar21) = 0;
              *(undefined4 **)(&stack0x00000f20 + lVar21) = (undefined4 *)(param_1 + 0x9c);
              *(undefined4 *)(param_1 + 0x9c) = 0;
              *(undefined2 *)(param_1 + 0xa0) = 0;
              *(undefined4 *)(&stack0x00000640 + lVar21) = 0;
              *(undefined4 *)(&stack0x00000644 + lVar21) = 0;
              *(undefined2 *)(&stack0x00000648 + lVar21) = 0;
              *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x00000640 + lVar21);
              *(undefined2 *)(param_1 + 0xc4) = 0;
              *(undefined4 *)(param_1 + 0xd0) = 2;
            }
            goto LAB_;
          }
          *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x80) + 1;
          lVar27 = *(longlong *)(&stack0x000000d0 + lVar21);
        } while( true );
      }
      if (*(int *)(param_1 + 0xd0) != 2) {
        *(longlong ***)(&stack0x00000558 + lVar21) = pplVar47;
        if (*pplVar47 != (longlong *)0x0) {
          puVar22 = (ushort *)((longlong)*pplVar47 + 0x62);
          *(ushort **)(&stack0x000013e0 + lVar21) = puVar22;
          uVar15 = *puVar22;
          *(ushort *)(&stack0x00000110 + lVar21) = uVar15;
          plVar35 = *(longlong **)(&stack0x00000558 + lVar21);
          if (((uVar15 & 0x400) == 0) || (*(short *)((longlong)plVar35 + 0xc) < 3)) {
            *(int *)(&stack0x000000a8 + lVar21) = (int)*(short *)((longlong)plVar35 + 0xc);
            lVar27 = *plVar35;
            *(longlong *)(&stack0x00000228 + lVar21) = lVar27;
            puVar23 = (undefined2 *)(lVar27 + 0x62);
            *(undefined2 **)(&stack0x000009b8 + lVar21) = puVar23;
            uVar16 = *puVar23;
            *(undefined2 *)(&stack0x00000118 + lVar21) = uVar16;
            if (((byte)uVar16 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000a8 + lVar21) == 3) {
                *(undefined4 *)(&stack0x000000a8 + lVar21) = 4;
              }
              else if (*(int *)(&stack0x000000a8 + lVar21) < 2) goto LAB_;
              *(uint **)(&stack0x000009c0 + lVar21) =
                   (uint *)(*(longlong *)(&stack0x00000228 + lVar21) + 100);
              uVar29 = *(uint *)(*(longlong *)(&stack0x00000228 + lVar21) + 100);
              *(uint *)(&stack0x00000600 + lVar21) = uVar29;
              if ((((uVar29 & 8) != 0) &&
                  (lVar27 = *(longlong *)(*(longlong *)(&stack0x00000228 + lVar21) + 0x90),
                  lVar27 != 0)) &&
                 (*(longlong *)(&stack0x000009c8 + lVar21) = lVar27,
                 *(longlong *)(lVar27 + 0x758) != 0)) {
                uVar24 = *(undefined8 *)(lVar27 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1007c5;
                func_0x
                          (uVar24,*(undefined8 *)(&stack0x00000228 + lVar21),
                           *(undefined4 *)(&stack0x000000a8 + lVar21));
              }
            }
LAB_:
            (&stack0x000001b2)[lVar21] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar30 = (uint *)(*(longlong *)(&stack0x00000228 + lVar21) + 100);
              *(uint **)(&stack0x000009d0 + lVar21) = puVar30;
              uVar29 = *puVar30;
              *(uint *)(&stack0x00000608 + lVar21) = uVar29;
              if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x000000a8 + lVar21))) {
                *(uint **)(&stack0x000009d8 + lVar21) = puVar30;
                uVar29 = *puVar30;
                *(uint *)(&stack0x00000610 + lVar21) = uVar29;
                if (((uVar29 & 0xc0000000) != 0x40000000) &&
                   (lVar27 = **(longlong **)(&stack0x00000228 + lVar21), lVar27 != 0)) {
                  *(undefined4 *)(&stack0x00000754 + lVar21) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100853;
                  iVar17 = (*_DAT_)(lVar27,0x2000,2,&stack0x00000758 + lVar21);
                  if (iVar17 != 0) {
                    LOCK();
                    *puVar30 = *puVar30 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar30 = *puVar30 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar27 = *(longlong *)(&stack0x00000228 + lVar21);
            uVar20 = *(undefined4 *)(&stack0x000000a8 + lVar21);
            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100882;
            func_0x(lVar27 + 0x98,uVar20);
            if ((_DAT_ != 0) &&
               ((&stack0x000001b3)[lVar21] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1008ac;
              func_0x(lVar27,0,uVar20);
            }
            *(uint *)((longlong)plVar35 + 0xc) = *(uint *)((longlong)plVar35 + 0xc) & 0xffff0000;
            **(undefined8 **)(&stack0x00000558 + lVar21) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100701;
            func_0x(plVar35);
          }
        }
        *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
        *(undefined8 **)(&stack0x000009e0 + lVar21) = (undefined8 *)(param_1 + 0x88);
        if (*(int *)(param_1 + 0x90) != 0) {
          *(undefined4 *)(&stack0x00000760 + lVar21) = *(undefined4 *)(param_1 + 0x94);
          *(undefined8 *)(&stack0x000009e8 + lVar21) = *(undefined8 *)(param_1 + 0x88);
          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1008fb;
          func_0x();
          *(undefined4 *)(param_1 + 0x90) = 0;
        }
        *(undefined4 *)(&stack0x000000d8 + lVar21) = 0;
        *(undefined2 *)(&stack0x000000dc + lVar21) = 0;
        *(undefined4 **)(&stack0x000009f0 + lVar21) = (undefined4 *)(param_1 + 0x9c);
        *(undefined4 *)(param_1 + 0x9c) = 0;
        *(undefined2 *)(param_1 + 0xa0) = 0;
        *(undefined4 *)(&stack0x00000630 + lVar21) = 0;
        *(undefined4 *)(&stack0x00000634 + lVar21) = 0;
        *(undefined2 *)(&stack0x00000638 + lVar21) = 0;
        *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x00000630 + lVar21);
        *(undefined2 *)(param_1 + 0xc4) = 0;
        *(undefined4 *)(param_1 + 0xd0) = 2;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x100970;
      func_0x((longlong)&plStackX_10 + lVar21);
      goto LAB_;
    }
    lVar43 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar27 = *(longlong *)(lVar43 + 0x100);
    if (lVar27 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10609c;
      (*_DAT_)();
      lVar27 = *(longlong *)(lVar43 + 0x100);
    }
    if (*(int *)(lVar27 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1060b2;
      (*_DAT_)();
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1060bd;
  func_0x((longlong)&plStackX_10 + lVar21);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1060cd;
  func_0x
            (*(ulonglong *)(&stack0x00002330 + lVar21) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar21));
  return;
LAB_:
  lVar27 = *(longlong *)(&stack0x000005a8 + lVar21);
  *(int *)(lVar27 + 4) = *(int *)(lVar27 + 4) + 1;
  if (*(longlong *)(lVar27 + 0x58) != 0) {
    piVar38 = (int *)(*(longlong *)(lVar27 + 0x58) + 4);
    *piVar38 = *piVar38 + 1;
  }
  if ((*(uint *)((longlong)&uStackX_1c + lVar21) & 0xff000000) != 0) {
    *(int *)(*(longlong *)(&stack0x000005a8 + lVar21) + 8) =
         *(int *)(*(longlong *)(&stack0x000005a8 + lVar21) + 8) + 1;
    if (*(longlong *)(lVar27 + 0x58) != 0) {
      piVar38 = (int *)(*(longlong *)(lVar27 + 0x58) + 8);
      *piVar38 = *piVar38 + 1;
    }
    if (*(char *)((longlong)auStackX_20 + lVar21) != '\0') {
      *(int *)(*(longlong *)(&stack0x000005a8 + lVar21) + 0xc) =
           *(int *)(*(longlong *)(&stack0x000005a8 + lVar21) + 0xc) + 1;
      if (*(longlong *)(lVar27 + 0x58) != 0) {
        piVar38 = (int *)(*(longlong *)(lVar27 + 0x58) + 0xc);
        *piVar38 = *piVar38 + 1;
      }
    }
  }
  if (*(int *)(&stack0x0000096c + lVar21) != 0) {
    lVar27 = **(longlong **)((longlong)&plStackX_10 + lVar21);
    *(longlong *)(&stack0x000011e8 + lVar21) = lVar27;
    uVar14 = *(undefined *)(lVar27 + 1);
    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10564a;
    func_0x
              (*(undefined8 *)(&stack0x000006b8 + lVar21),uVar14,&stack0x00000968 + lVar21,
               0xffffffff);
  }
  if ((*(longlong *)(&stack0x000006b0 + lVar21) == 0) ||
     (*(char *)(*(longlong *)(&stack0x000000c0 + lVar21) + 0x2050) == '\0')) {
    (&stack0x0000003b)[lVar21] = 0;
    cVar12 = '\x01';
    (&stack0x0000003c)[lVar21] = 1;
LAB_:
    *(undefined4 *)(&stack0x000000d0 + lVar21) = 0;
    *(undefined2 *)(&stack0x000000d4 + lVar21) = 0;
    *(undefined2 *)(&stack0x000000d6 + lVar21) = 0;
    lVar27 = **(longlong **)(&stack0x000006c0 + lVar21);
    *(longlong *)(&stack0x000008c8 + lVar21) = lVar27;
    lVar43 = **(longlong **)((longlong)&plStackX_10 + lVar21);
    *(longlong *)(&stack0x000011f0 + lVar21) = lVar43;
    lVar31 = *(longlong *)(lVar27 + 8);
    piVar38 = (int *)(lVar31 + 0x3c0);
    *(int **)(&stack0x000011f8 + lVar21) = piVar38;
    *(undefined4 *)(&stack0x00000448 + lVar21) = 0;
    if (*(int *)(lVar43 + 0x18) == *piVar38) {
      uVar15 = *(ushort *)(lVar31 + 0x3c4);
      if ((*(ushort *)(lVar43 + 6) == uVar15) || ((uVar15 | *(ushort *)(lVar43 + 6)) < 2)) {
        *(undefined4 *)(&stack0x00000448 + lVar21) = 1;
        goto LAB_;
      }
    }
    *(longlong *)(&stack0x00001200 + lVar21) = lVar43;
    *(undefined4 *)(&stack0x000000f0 + lVar21) = 0;
    *(undefined2 *)(&stack0x000000f4 + lVar21) = 0;
    *(undefined2 *)(&stack0x000000f6 + lVar21) = 0;
    uVar20 = *(undefined4 *)(lVar43 + 0x18);
    *(undefined4 *)(&stack0x000000f0 + lVar21) = uVar20;
    uVar16 = *(undefined2 *)(lVar43 + 6);
    *(undefined2 *)(&stack0x000000f4 + lVar21) = uVar16;
    *(undefined4 *)(&stack0x000000d0 + lVar21) = uVar20;
    *(undefined2 *)(&stack0x000000d4 + lVar21) = uVar16;
    *(undefined2 *)(&stack0x000000d6 + lVar21) = 0;
    puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 0x62);
    *(undefined2 **)(&stack0x00001208 + lVar21) = puVar23;
    *(undefined2 *)(&stack0x00000178 + lVar21) = *puVar23;
    if (((*(ushort *)(&stack0x00000178 + lVar21) & 0x400) == 0) ||
       (*(short *)((longlong)&uStackX_1c + lVar21) < 3)) {
      *(int *)(&stack0x000000b0 + lVar21) = (int)*(short *)((longlong)&uStackX_1c + lVar21);
      *(undefined8 *)(&stack0x000005b0 + lVar21) = *(undefined8 *)((longlong)&plStackX_10 + lVar21);
      *(undefined2 **)(&stack0x00001210 + lVar21) = puVar23;
      uVar5 = *puVar23;
      *(undefined2 *)(&stack0x00000180 + lVar21) = uVar5;
      if (((byte)uVar5 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x000000b0 + lVar21) == 3) {
          *(undefined4 *)(&stack0x000000b0 + lVar21) = 4;
        }
        else if (*(int *)(&stack0x000000b0 + lVar21) < 2) goto LAB_;
        puVar30 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 100);
        *(uint **)(&stack0x00001218 + lVar21) = puVar30;
        uVar29 = *puVar30;
        *(uint *)(&stack0x00000450 + lVar21) = uVar29;
        if ((((uVar29 & 8) != 0) &&
            (lVar43 = *(longlong *)(*(longlong *)((longlong)&plStackX_10 + lVar21) + 0x90),
            lVar43 != 0)) &&
           (*(longlong *)(&stack0x00001220 + lVar21) = lVar43, *(longlong *)(lVar43 + 0x758) != 0))
        {
          uVar24 = *(undefined8 *)(lVar43 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105884;
          func_0x
                    (uVar24,*(undefined8 *)((longlong)&plStackX_10 + lVar21),
                     *(undefined4 *)(&stack0x000000b0 + lVar21));
        }
      }
LAB_:
      (&stack0x000001fd)[lVar21] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar30 = (uint *)(*(longlong *)(&stack0x000005b0 + lVar21) + 100);
        *(uint **)(&stack0x00001228 + lVar21) = puVar30;
        uVar29 = *puVar30;
        *(uint *)(&stack0x00000458 + lVar21) = uVar29;
        if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x000000b0 + lVar21))) {
          *(uint **)(&stack0x00001230 + lVar21) = puVar30;
          uVar29 = *puVar30;
          *(uint *)(&stack0x00000460 + lVar21) = uVar29;
          if (((uVar29 & 0xc0000000) != 0x40000000) &&
             (lVar43 = **(longlong **)(&stack0x000005b0 + lVar21), lVar43 != 0)) {
            *(undefined4 *)(&stack0x00000948 + lVar21) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105917;
            iVar17 = (*_DAT_)(lVar43,0x2000,2,&stack0x00000820 + lVar21);
            if (iVar17 != 0) {
              LOCK();
              *puVar30 = *puVar30 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar30 = *puVar30 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar43 = *(longlong *)(&stack0x000005b0 + lVar21);
      uVar6 = *(undefined4 *)(&stack0x000000b0 + lVar21);
      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105946;
      func_0x(lVar43 + 0x98,uVar6);
      if ((_DAT_ != 0) &&
         ((&stack0x000001fe)[lVar21] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105970;
        func_0x(lVar43,0,uVar6);
      }
      *(uint *)((longlong)&uStackX_1c + lVar21) =
           *(uint *)((longlong)&uStackX_1c + lVar21) & 0xffff0000;
      *(undefined8 *)((longlong)&plStackX_10 + lVar21) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1057d2;
      func_0x((longlong)&plStackX_10 + lVar21);
    }
    *(undefined **)(&stack0x00001238 + lVar21) = &stack0x00000330 + lVar21;
    *(undefined **)(&stack0x00001240 + lVar21) = &stack0x00000338 + lVar21;
    lVar27 = *(longlong *)(lVar27 + 8);
    puVar32 = (undefined4 *)(lVar27 + 0x3c0);
    *(undefined4 **)(&stack0x00001248 + lVar21) = puVar32;
    *(undefined4 *)(&stack0x00000330 + lVar21) = *puVar32;
    *(undefined2 *)(&stack0x00000334 + lVar21) = *(undefined2 *)(lVar27 + 0x3c4);
    *(undefined2 *)(&stack0x00000336 + lVar21) = 0;
    *(undefined4 *)(&stack0x00000338 + lVar21) = uVar20;
    *(undefined2 *)(&stack0x0000033c + lVar21) = uVar16;
    *(undefined2 *)(&stack0x0000033e + lVar21) = 0;
    pcVar10 = *(code **)**(undefined8 **)(&stack0x000008c8 + lVar21);
    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x1059fb;
    uVar16 = (*pcVar10)();
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar21) =
         *(undefined4 *)(*(longlong *)(&stack0x000006c0 + lVar21) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105a28;
    func_0x
              (&stack0x00000044 + lVar21,&stack0x00000338 + lVar21,uVar16,&stack0x00000330 + lVar21)
    ;
    param_1 = *(longlong *)(&stack0x000000c8 + lVar21);
  }
  else {
    (&stack0x0000003b)[lVar21] = 1;
    (&stack0xfffffffffffffff8)[lVar21] = 0;
    *(longlong *)(&stack0xfffffffffffffff0 + lVar21) = *(longlong *)(&stack0x000006b0 + lVar21);
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar21) = *(undefined8 *)(&stack0x000006b8 + lVar21);
    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105695;
    cVar12 = func_0x((longlong)&plStackX_10 + lVar21);
    (&stack0x0000003c)[lVar21] = cVar12;
    if (cVar12 != '\0') goto LAB_;
  }
LAB_:
  (&stack0x000001ff)[lVar21] = cVar12;
  if (cVar12 == '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105a53;
    func_0x(param_1,param_1 + 0x68);
    acStackX_8[lVar21] = '\x01';
    lVar27 = **(longlong **)(param_1 + 8);
    *(longlong *)(&stack0x00001250 + lVar21) = lVar27;
    uVar46 = *(ulonglong *)(lVar27 + 0x14);
    *(ulonglong *)(&stack0x00001258 + lVar21) = uVar46;
    lVar27 = *(longlong *)(lVar27 + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105aa0;
    func_0x((longlong)&plStackX_10 + lVar21,lVar27 + 0xa0,
                    ((uVar46 >> 0x20 & 0xffff) << 0x20 | uVar46 & 0xffffffff) << 0x10);
    *(undefined4 *)(param_1 + 200) = 3;
    *(uint *)(param_1 + 0xcc) = 2 - (uint)(acStackX_18[lVar21] != '\0');
    goto LAB_;
  }
  lVar27 = **(longlong **)((longlong)&plStackX_10 + lVar21);
  *(longlong *)(&stack0x00001260 + lVar21) = lVar27;
  if (((*(byte *)(lVar27 + 4) & 1) != 0) || (*(int *)(param_1 + 0x16c) != 0)) goto LAB_;
  pplVar47 = (longlong **)(param_1 + 0x68);
  *(longlong ***)(&stack0x000005b8 + lVar21) = pplVar47;
  if (*pplVar47 != (longlong *)0x0) {
    puVar22 = (ushort *)((longlong)*pplVar47 + 0x62);
    *(ushort **)(&stack0x00001268 + lVar21) = puVar22;
    uVar15 = *puVar22;
    *(ushort *)(&stack0x00000188 + lVar21) = uVar15;
    plVar35 = *(longlong **)(&stack0x000005b8 + lVar21);
    if (((uVar15 & 0x400) == 0) || (*(short *)((longlong)plVar35 + 0xc) < 3)) {
      *(int *)(&stack0x00000068 + lVar21) = (int)*(short *)((longlong)plVar35 + 0xc);
      lVar27 = *plVar35;
      *(longlong *)(&stack0x00000230 + lVar21) = lVar27;
      puVar23 = (undefined2 *)(lVar27 + 0x62);
      *(undefined2 **)(&stack0x00001270 + lVar21) = puVar23;
      uVar16 = *puVar23;
      *(undefined2 *)(&stack0x00000190 + lVar21) = uVar16;
      if (((byte)uVar16 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000068 + lVar21) == 3) {
          *(undefined4 *)(&stack0x00000068 + lVar21) = 4;
        }
        else if (*(int *)(&stack0x00000068 + lVar21) < 2) goto LAB_;
        *(uint **)(&stack0x00001278 + lVar21) =
             (uint *)(*(longlong *)(&stack0x00000230 + lVar21) + 100);
        uVar29 = *(uint *)(*(longlong *)(&stack0x00000230 + lVar21) + 100);
        *(uint *)(&stack0x00000468 + lVar21) = uVar29;
        if ((((uVar29 & 8) != 0) &&
            (lVar27 = *(longlong *)(*(longlong *)(&stack0x00000230 + lVar21) + 0x90), lVar27 != 0))
           && (*(longlong *)(&stack0x00001280 + lVar21) = lVar27, *(longlong *)(lVar27 + 0x758) != 0
              )) {
          uVar24 = *(undefined8 *)(lVar27 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105c12;
          func_0x
                    (uVar24,*(undefined8 *)(&stack0x00000230 + lVar21),
                     *(undefined4 *)(&stack0x00000068 + lVar21));
        }
      }
LAB_:
      (&stack0x000000f8)[lVar21] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar30 = (uint *)(*(longlong *)(&stack0x00000230 + lVar21) + 100);
        *(uint **)(&stack0x00001288 + lVar21) = puVar30;
        uVar29 = *puVar30;
        *(uint *)(&stack0x00000470 + lVar21) = uVar29;
        if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x00000068 + lVar21))) {
          *(uint **)(&stack0x00001290 + lVar21) = puVar30;
          uVar29 = *puVar30;
          *(uint *)(&stack0x00000478 + lVar21) = uVar29;
          if (((uVar29 & 0xc0000000) != 0x40000000) &&
             (lVar27 = **(longlong **)(&stack0x00000230 + lVar21), lVar27 != 0)) {
            *(undefined4 *)(&stack0x00000824 + lVar21) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105ca1;
            iVar17 = (*_DAT_)(lVar27,0x2000,2,&stack0x00000828 + lVar21);
            if (iVar17 != 0) {
              LOCK();
              *puVar30 = *puVar30 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar30 = *puVar30 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar27 = *(longlong *)(&stack0x00000230 + lVar21);
      uVar20 = *(undefined4 *)(&stack0x00000068 + lVar21);
      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105cd0;
      func_0x(lVar27 + 0x98,uVar20);
      if ((_DAT_ != 0) &&
         ((&stack0x000000f9)[lVar21] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105cfa;
        func_0x(lVar27,0,uVar20);
      }
      *(uint *)((longlong)plVar35 + 0xc) = *(uint *)((longlong)plVar35 + 0xc) & 0xffff0000;
      **(undefined8 **)(&stack0x000005b8 + lVar21) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105b4e;
      func_0x(plVar35);
    }
  }
  *(longlong ***)(&stack0x000005c0 + lVar21) = pplVar47;
  pplVar40 = pplVar47;
  if (*pplVar47 != (longlong *)0x0) {
    puVar22 = (ushort *)((longlong)*pplVar47 + 0x62);
    *(ushort **)(&stack0x00001298 + lVar21) = puVar22;
    uVar15 = *puVar22;
    *(ushort *)(&stack0x00000198 + lVar21) = uVar15;
    pplVar40 = *(longlong ***)(&stack0x000005c0 + lVar21);
    if (((uVar15 & 0x400) == 0) || (*(short *)((longlong)pplVar40 + 0xc) < 3)) {
      *(int *)(&stack0x00000070 + lVar21) = (int)*(short *)((longlong)pplVar40 + 0xc);
      plVar35 = *pplVar40;
      *(longlong **)(&stack0x00000210 + lVar21) = plVar35;
      puVar23 = (undefined2 *)((longlong)plVar35 + 0x62);
      *(undefined2 **)(&stack0x000012a0 + lVar21) = puVar23;
      uVar16 = *puVar23;
      *(undefined2 *)(&stack0x000001a0 + lVar21) = uVar16;
      if (((byte)uVar16 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000070 + lVar21) == 3) {
          *(undefined4 *)(&stack0x00000070 + lVar21) = 4;
        }
        else if (*(int *)(&stack0x00000070 + lVar21) < 2) goto LAB_;
        *(uint **)(&stack0x000012a8 + lVar21) =
             (uint *)(*(longlong *)(&stack0x00000210 + lVar21) + 100);
        uVar29 = *(uint *)(*(longlong *)(&stack0x00000210 + lVar21) + 100);
        *(uint *)(&stack0x00000480 + lVar21) = uVar29;
        if ((((uVar29 & 8) != 0) &&
            (lVar27 = *(longlong *)(*(longlong *)(&stack0x00000210 + lVar21) + 0x90), lVar27 != 0))
           && (*(longlong *)(&stack0x000012b0 + lVar21) = lVar27, *(longlong *)(lVar27 + 0x758) != 0
              )) {
          uVar24 = *(undefined8 *)(lVar27 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105e1f;
          func_0x
                    (uVar24,*(undefined8 *)(&stack0x00000210 + lVar21),
                     *(undefined4 *)(&stack0x00000070 + lVar21));
        }
      }
LAB_:
      (&stack0x000000fa)[lVar21] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar30 = (uint *)(*(longlong *)(&stack0x00000210 + lVar21) + 100);
        *(uint **)(&stack0x000012b8 + lVar21) = puVar30;
        uVar29 = *puVar30;
        *(uint *)(&stack0x00000488 + lVar21) = uVar29;
        if (((uVar29 & 8) != 0) && (2 < *(int *)(&stack0x00000070 + lVar21))) {
          *(uint **)(&stack0x000012c0 + lVar21) = puVar30;
          uVar29 = *puVar30;
          *(uint *)(&stack0x00000490 + lVar21) = uVar29;
          if (((uVar29 & 0xc0000000) != 0x40000000) &&
             (lVar27 = **(longlong **)(&stack0x00000210 + lVar21), lVar27 != 0)) {
            *(undefined4 *)(&stack0x00000830 + lVar21) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105eae;
            iVar17 = (*_DAT_)(lVar27,0x2000,2,&stack0x00000834 + lVar21);
            if (iVar17 != 0) {
              LOCK();
              *puVar30 = *puVar30 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar30 = *puVar30 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar27 = *(longlong *)(&stack0x00000210 + lVar21);
      uVar20 = *(undefined4 *)(&stack0x00000070 + lVar21);
      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105edd;
      func_0x(lVar27 + 0x98,uVar20);
      if ((_DAT_ != 0) &&
         ((&stack0x000000fb)[lVar21] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105f07;
        func_0x(lVar27,0,uVar20);
      }
      *(uint *)((longlong)pplVar40 + 0xc) = *(uint *)((longlong)pplVar40 + 0xc) & 0xffff0000;
      pplVar40 = *(longlong ***)(&stack0x000005c0 + lVar21);
      *pplVar40 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105d5b;
      func_0x(pplVar40);
    }
  }
  *pplVar40 = *(longlong **)((longlong)&plStackX_10 + lVar21);
  *(uint *)((longlong)pplVar40 + 0xc) =
       *(uint *)((longlong)pplVar40 + 0xc) & 0xffff0000 |
       (uint)*(ushort *)((longlong)&uStackX_1c + lVar21);
  *(undefined8 *)((longlong)&plStackX_10 + lVar21) = 0;
  *(uint *)((longlong)&uStackX_1c + lVar21) = *(uint *)((longlong)&uStackX_1c + lVar21) & 0xffff0000
  ;
  *(undefined4 *)(*(longlong *)(&stack0x000000c8 + lVar21) + 0x80) = 0;
  lVar27 = **pplVar47;
  *(longlong *)(&stack0x000000d0 + lVar21) = lVar27;
  *(longlong *)(&stack0x000006c8 + lVar21) = lVar27;
  *(uint *)(&stack0x00000288 + lVar21) = (uint)*(ushort *)(lVar27 + 0x16);
  iVar17 = 0;
  *(undefined4 *)(&stack0x000000d8 + lVar21) = 0;
  *(undefined4 *)(&stack0x000001f0 + lVar21) = 0;
  param_3 = *(longlong **)(&stack0x00000208 + lVar21);
  *(int *)((longlong)param_3 + 0xc) = *(int *)((longlong)param_3 + 0xc) + 1;
  goto LAB_;
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105fa9;
  func_0x((longlong)&plStackX_10 + lVar21);
  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105fb5;
  func_0x(param_1,param_1 + 0x68);
  *(undefined8 *)(&stack0x00001848 + lVar21) = 0;
  *(undefined **)(&stack0x000012c8 + lVar21) = &stack0x00001850 + lVar21;
  (&stack0x0000185e)[lVar21] = 1;
  (&stack0x0000185f)[lVar21] = 0;
  uVar24 = **(undefined8 **)(param_1 + 8);
  uVar28 = (*(undefined8 **)(param_1 + 8))[1];
  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x105ffa;
  uVar20 = func_0x(&stack0x00001848 + lVar21,&stack0x00000044 + lVar21,uVar28,uVar24);
  *(undefined4 *)(&stack0x00000838 + lVar21) = uVar20;
  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10600a;
  func_0x(uVar20,0x15);
  *(undefined4 *)(param_1 + 200) = 3;
  *(undefined4 *)(param_1 + 0xcc) = 3;
  acStackX_8[lVar21] = '\x01';
  *(undefined8 *)((longlong)&uStack_40 + lVar21) = 0x10602f;
  func_0x(&stack0x00001848 + lVar21);
LAB_:
  param_3 = *(longlong **)(&stack0x00000208 + lVar21);
  goto LAB_;
}

