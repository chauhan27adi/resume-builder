
/* WARNING: Switch with 1 destination removed at 0x00100064 : 10 cases all go to same destination */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 in_stack_ffffffffffffffd8;
  undefined4 uVar3;
  
  uVar3 = (undefined4)((ulonglong)in_stack_ffffffffffffffd8 >> 0x20);
  if (*(char *)(param_1 + 0x18) == '\0') {
    uVar3 = 0;
    (*_DAT_)(1,0x2371628,0x23619d0,0x1f7,0);
  }
  iVar1 = *(int *)(param_1 + 0x14);
  if (iVar1 - 1U < 10) {
    uVar2 = (*pcRam0000000001e5dd10)();
    iVar1 = func_0x(param_2,param_3,0x2178080,uVar2,CONCAT44(uVar3,iVar1));
    if (-1 < iVar1) {
      return;
    }
  }
  else {
    (*_DAT_)(1,0x23612d0,0x23619d0,0x20e,0x1f5c478);
    iVar1 = -0x7fffbffb;
  }
  (*_DAT_)(4,7,0x10,1,0x2178058,0x214,iVar1);
  return;
}

