
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2)

{
  ushort *puVar1;
  undefined4 uVar2;
  longlong *plVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  longlong lVar7;
  uint *puVar8;
  ulonglong *puVar9;
  longlong lVar10;
  uint uVar11;
  uint *puVar12;
  ushort uVar13;
  uint uVar14;
  uint uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  uint *puVar18;
  short sVar19;
  byte *pbVar20;
  uint uVar21;
  uint uVar22;
  ushort *puVar23;
  longlong unaff_GS_OFFSET;
  undefined auStack_138 [32];
  uint *puStack_118;
  undefined8 uStack_110;
  uint *puStack_108;
  uint uStack_100;
  undefined4 uStack_f8;
  undefined4 uStack_f0;
  int iStack_e8;
  undefined4 uStack_e0;
  uint *puStack_d8;
  undefined4 uStack_d0;
  undefined8 uStack_c8;
  undefined4 uStack_c0;
  undefined8 uStack_b8;
  undefined2 uStack_b0;
  undefined4 uStack_a8;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined2 uStack_90;
  uint uStack_88;
  uint uStack_84;
  undefined4 uStack_80;
  undefined8 uStack_7c;
  undefined4 uStack_74;
  undefined auStack_70 [4];
  uint uStack_6c;
  uint auStack_68 [8];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_138;
  puVar12 = (uint *)0x0;
  uVar21 = 0;
  uStack_88 = 0;
  lVar10 = *(longlong *)(*(longlong *)(param_2 + 0x98) + 0x80);
  if (lVar10 == 0) {
    lVar7 = func_0x();
    if (lVar7 == 0) {
      puVar8 = (uint *)0x4;
    }
    else {
      lVar7 = func_0x();
      puVar8 = (uint *)(lVar7 + 0x10);
    }
    *puVar8 = *puVar8 | 2;
    (*_DAT_)(0x59,0x43,0x10,0xd6);
  }
  lVar10 = *(longlong *)(lVar10 + 8);
  if ((((*(int *)(lVar10 + 0xe8) == 0) || ((*(byte *)(lVar10 + 0x108) & 0x40) != 0)) ||
      ((*(byte *)(lVar10 + 0x41) & 8) == 0)) || (*(longlong **)(lVar10 + 0x160) == (longlong *)0x0))
  goto LAB_;
  lVar10 = **(longlong **)(lVar10 + 0x160);
  uVar15 = *(uint *)(lVar10 + 100);
  if (uVar15 == 0xffffffff) goto LAB_;
  puVar8 = *(uint **)(lVar10 + 8);
  if (uVar15 < *puVar8) {
    uVar17 = (ulonglong)uVar15 / (ulonglong)puVar8[9];
    uVar16 = (ulonglong)uVar15 % (ulonglong)puVar8[9];
    lVar10 = *(longlong *)(puVar8 + 4);
  }
  else {
    uVar17 = (ulonglong)(uVar15 - *puVar8) / (ulonglong)puVar8[0x11];
    uVar16 = (ulonglong)(uVar15 - *puVar8) % (ulonglong)puVar8[0x11];
    lVar10 = *(longlong *)(puVar8 + 0xc);
  }
  puVar8 = (uint *)(uVar16 * 0x1c0 + *(longlong *)(lVar10 + uVar17 * 8));
  if (puVar8 == (uint *)0x0) goto LAB_;
  puVar1 = (ushort *)(param_2 + 0xa2);
  bVar4 = *(byte *)(puVar8 + 8);
  if (*(short *)(param_2 + 0xa0) == 0) {
    uVar15 = *puVar8;
    if ((uVar15 & 0xc0000000) == 0x80000000) {
      iVar6 = func_0x(puVar1);
      if (iVar6 != 0) {
        puVar18 = (uint *)func_0x(param_2 + 0xca,puVar8,&uStack_88,auStack_70);
        uVar21 = uStack_88;
        goto LAB_;
      }
LAB_:
      puVar18 = (uint *)0x0;
      uVar21 = uStack_88;
    }
    else {
      uVar22 = 1;
      if (((bVar4 & 2) != 0) || ((*(byte *)((longlong)puVar8 + 6) & 0x10) != 0)) {
        pbVar20 = *(byte **)(param_2 + 0xa8);
        if ((*pbVar20 & 0x10) == 0) {
          uVar22 = 1;
          uVar14 = uVar21;
          if ((1 << (*pbVar20 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
          if ((bVar4 & 2) != 0) goto LAB_;
        }
        else {
          uVar14 = *(uint *)(param_2 + 0xb0);
          if ((int)uVar14 <= (int)uVar15) {
LAB_:
            uVar22 = uVar21;
            uVar14 = ~(uint)(*(ushort *)((longlong)puVar8 + 6) >> 4) & 1;
            goto LAB_;
          }
          if ((uint)*(ushort *)(pbVar20 + uVar14) < (uint)*(ushort *)(puVar8 + 1))
          goto LAB_;
          if ((bVar4 & 2) == 0) goto LAB_;
          uVar11 = *(ushort *)(puVar8 + 1) - 1;
          uVar14 = pbVar20[(ulonglong)(uVar11 >> 3) + (ulonglong)uVar14 + 2] >> ((byte)uVar11 & 7) &
                   1;
LAB_:
          if (uVar14 != 0) goto LAB_;
        }
        if ((uVar22 == 0) && ((*(byte *)((longlong)puVar8 + 6) & 0x10) != 0)) {
          puVar18 = *(uint **)(puVar8 + 2) + 1;
          uVar21 = **(uint **)(puVar8 + 2);
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar15 < 0) {
        if (*(int *)(param_2 + 0xa4) == 0) {
          pbVar20 = *(byte **)(param_2 + 0xa8);
          uVar15 = *(uint *)(param_2 + 0xb0);
          uVar17 = (ulonglong)uVar15;
          *puVar1 = 0;
          *(uint *)(param_2 + 0xb4) = uVar15;
          bVar4 = *pbVar20;
          if ((bVar4 & 0x10) != 0) {
            uVar15 = uVar15 + 2 + (*(ushort *)(pbVar20 + uVar17) + 7 >> 3);
            uVar17 = (ulonglong)uVar15;
            *(uint *)(param_2 + 0xb4) = uVar15;
            bVar4 = *pbVar20;
          }
          if ((bVar4 & 0x20) == 0) {
            *(int *)(param_2 + 0xa4) = (int)uVar17;
            *(undefined2 *)(param_2 + 0xbc) = 0;
            *(int *)(param_2 + 0xb8) = (int)uVar17;
          }
          else {
            puVar23 = (ushort *)(pbVar20 + uVar17);
            uVar5 = *puVar23;
            *(ushort *)(param_2 + 0xbc) = uVar5;
            if (uVar5 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar10 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar10 != 0)) &&
                 ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                  (*(char *)(lVar10 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  puStack_118 = (uint *)0x0;
                  (*_DAT_)(1,0xd759d8,0xe956a8,0x80f);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),3);
              uVar17 = (ulonglong)*(uint *)(param_2 + 0xb4);
              uVar5 = *(ushort *)(param_2 + 0xbc);
            }
            uVar15 = (int)uVar17 + (uVar5 + 1) * 2;
            *(uint *)(param_2 + 0xb8) = uVar15;
            if (0x1f9e < uVar15) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar10 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar10 != 0 &&
                  ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                   (*(char *)(lVar10 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_118 = (uint *)0x0;
                  (*_DAT_)(1,0xd759d8,0xe956a8,0x816);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
              uVar5 = *(ushort *)(param_2 + 0xbc);
              uVar15 = *(uint *)(param_2 + 0xb8);
            }
            uVar17 = (ulonglong)uVar5;
            uVar5 = puVar23[uVar17];
            *(uint *)(param_2 + 0xa4) = uVar5 & 0x7fff;
            if ((uVar5 & 0x7fff) < uVar15) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar10 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar10 != 0)) &&
                 ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                  (*(char *)(lVar10 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_118 = (uint *)0x0;
                  (*_DAT_)(1,0xd759d8,0xe956a8,0x81d);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
              uVar17 = (ulonglong)*(ushort *)(param_2 + 0xbc);
            }
            if ((short)puVar23[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
              lVar10 = *(longlong *)(param_2 + 0xa8);
              do {
                lVar7 = (ulonglong)*(uint *)(param_2 + 0xb4) + lVar10;
                if ((int)uVar17 == 1) {
                  uVar15 = *(uint *)(param_2 + 0xb8);
                  uVar22 = uVar15;
LAB_:
                  if ((*(ushort *)(lVar7 + uVar17 * 2) & 0x7fff) < uVar15) goto LAB_;
                }
                else {
                  uVar22 = *(uint *)(param_2 + 0xb8);
                  uVar15 = *(ushort *)(lVar7 + -2 + uVar17 * 2) & 0x7fff;
                  if (uVar22 <= uVar15) goto LAB_;
LAB_:
                  func_0x(lVar10,7);
                  uVar22 = *(uint *)(param_2 + 0xb8);
                }
                if ((uVar15 < uVar22) || (*(uint *)(param_2 + 0xa4) < uVar15)) goto LAB_;
                lVar10 = *(longlong *)(param_2 + 0xa8);
                if (*(ushort *)(lVar10 + (ulonglong)uVar15) == 5) {
                  *puVar1 = *puVar1 | 2;
                  *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
                  uVar5 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
                  *(short *)(param_2 + 0xca) = (short)uVar15;
                  lVar10 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(param_2 + 0xa8);
                  if ((*(ushort *)(lVar10 + 2) & 0x4000) != 0) {
                    uVar5 = *(ushort *)(lVar10 + 2) & 0x3800 | uVar5;
                  }
                  *(ushort *)(param_2 + 0xcc) = uVar5;
                  *(ushort *)(param_2 + 0xcc) = (uVar5 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar5;
                  uVar17 = (ulonglong)*(uint *)(param_2 + 0xa4);
                  pbVar20 = *(byte **)(param_2 + 0xa8);
                  goto LAB_;
                }
                if (*(ushort *)(lVar10 + (ulonglong)uVar15) < 0x400) break;
                *puVar1 = *puVar1 | 1;
                uVar5 = *(short *)(param_2 + 0xbc) - 1;
                *(ushort *)(param_2 + 0xbc) = uVar5;
                if ((uVar5 == 0) ||
                   (uVar17 = (ulonglong)uVar5, -1 < (short)puVar23[(ulonglong)(uVar5 - 1) + 1]))
                break;
              } while( true );
            }
            uVar17 = (ulonglong)*(uint *)(param_2 + 0xa4);
            pbVar20 = *(byte **)(param_2 + 0xa8);
          }
LAB_:
          if ((*pbVar20 & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0xc6) = 0;
          }
          else {
            *(int *)(param_2 + 0xc6) = (int)uVar17;
            *(int *)(param_2 + 0xa4) = (int)uVar17 + 0xe;
            puVar9 = (ulonglong *)func_0x(puVar1);
            uVar17 = *puVar9;
            uVar13 = (ushort)(uVar17 >> 0x30);
            uVar5 = uVar13;
            if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
              uVar5 = uVar13 & 0xdfff;
              if ((uVar17 & 0x4000000000000000) != 0) {
                uVar5 = uVar13 | 0x2000;
              }
            }
            if (uVar5 == 0xfffc) {
              uVar21 = (uint)((uVar17 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + uVar21;
            uVar17 = (ulonglong)*(uint *)(param_2 + 0xa4);
          }
          iVar6 = (int)uVar17;
          if ((*(ulonglong *)(param_2 + 0xbe) != 0) &&
             (*(ulonglong *)(param_2 + 0xbe) < uVar17 + *(longlong *)(param_2 + 0xa8))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar10 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar10 != 0 &&
                 (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                puStack_118 = (uint *)0x0;
                (*_DAT_)(1,0xd759d8,0xe956a8,0x877);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
            iVar6 = *(int *)(param_2 + 0xa4);
          }
          if (0x3f3b < iVar6 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                puStack_118 = (uint *)0x0;
                (*_DAT_)(1,0xd759d8,0xe956a8,0x87c);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),5);
          }
        }
LAB_:
        sVar19 = -*(short *)puVar8;
        if ((*(byte *)((longlong)puVar8 + 6) & 0x10) == 0) {
LAB_:
          puVar18 = *(uint **)(param_2 + 0xa8);
          lVar10 = (longlong)sVar19;
          if ((uint)*(ushort *)(param_2 + 0xbc) < (uint)(int)sVar19) {
            uStack_88 = 0;
            uVar21 = uStack_88;
          }
          else {
            uVar21 = *(uint *)(param_2 + 0xb4);
            if (sVar19 == 1) {
              uVar15 = *(uint *)(param_2 + 0xb8);
              uVar21 = *(ushort *)((longlong)puVar18 + lVar10 * 2 + (ulonglong)uVar21) & 0x7fff;
LAB_:
              if (uVar21 < uVar15) goto LAB_;
            }
            else {
              puVar1 = (ushort *)((longlong)puVar18 + lVar10 * 2 + (ulonglong)uVar21);
              uVar15 = *(ushort *)((longlong)puVar18 + lVar10 * 2 + ((ulonglong)uVar21 - 2)) &
                       0x7fff;
              puVar18 = *(uint **)(param_2 + 0xa8);
              uVar21 = *puVar1 & 0x7fff;
              if (*(uint *)(param_2 + 0xb8) <= uVar15) goto LAB_;
LAB_:
              func_0x(puVar18,7);
              puVar18 = *(uint **)(param_2 + 0xa8);
            }
            puVar18 = (uint *)((longlong)puVar18 + (ulonglong)uVar15);
            uVar21 = uVar21 - uVar15;
          }
        }
        else {
          bVar4 = **(byte **)(param_2 + 0xa8);
          if ((bVar4 & 0x10) == 0) {
            if ((1 << (bVar4 & 0xe) & 0x1105U) == 0) goto LAB_;
          }
          else if (((int)*puVar8 < (int)*(uint *)(param_2 + 0xb0)) &&
                  (*(ushort *)(puVar8 + 1) <=
                   *(ushort *)(*(byte **)(param_2 + 0xa8) + *(uint *)(param_2 + 0xb0))))
          goto LAB_;
          puVar18 = *(uint **)(puVar8 + 2) + 1;
          uVar21 = **(uint **)(puVar8 + 2);
        }
      }
      else {
        uVar5 = *(ushort *)((longlong)puVar8 + 6);
        if ((uVar5 & 8) == 0) {
          uVar22 = (uint)*(ushort *)(puVar8 + 0xe);
          if ((uVar5 & 0x10) != 0) {
            bVar4 = **(byte **)(param_2 + 0xa8);
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                uVar21 = **(uint **)(puVar8 + 2);
                puVar18 = *(uint **)(puVar8 + 2) + 1;
                if ((uVar22 != 0) && (uVar21 != uVar22)) {
                  puStack_118 = (uint *)0x0;
                  (*_DAT_)(1,0xf23748,0xf22148,0x381);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_2 + 0xb0) <= (int)uVar15) ||
                    (*(ushort *)(*(byte **)(param_2 + 0xa8) + *(uint *)(param_2 + 0xb0)) <
                     *(ushort *)(puVar8 + 1))) goto LAB_;
          }
          puVar18 = (uint *)((longlong)(int)*puVar8 + *(longlong *)(param_2 + 0xa8));
          uVar21 = uVar22;
        }
        else {
          puVar18 = (uint *)0xafa414;
          uStack_88 = 1;
          uVar21 = uStack_88;
          if ((*(byte *)((longlong)(int)uVar15 + *(longlong *)(param_2 + 0xa8)) &
              (byte)(1 << ((byte)uVar5 & 7))) == 0) {
            puVar18 = (uint *)0xafaa38;
          }
        }
      }
    }
  }
  else {
    puStack_118 = &uStack_84;
    uStack_84 = 0;
    puVar18 = (uint *)func_0x(puVar1,puVar8,uVar16,&uStack_88);
    uVar21 = uStack_88;
    if (((*(short *)(param_2 + 0xa0) != 0) &&
        (plVar3 = *(longlong **)(param_2 + 0xb0), plVar3 != (longlong *)0x0)) &&
       ((*plVar3 != 0 && (((*(byte *)((longlong)puVar8 + 6) & 8) == 0 && ((uStack_84 & 1) == 0))))))
    {
      if ((puVar18 == (uint *)0x0) || (puVar18 == (uint *)0xafa414)) {
        uStack_88 = 0;
        puVar18 = puVar12;
        uVar21 = uStack_88;
      }
      else {
        uStack_100 = uStack_84;
        puStack_108 = &uStack_88;
        puStack_118 = &uStack_6c;
        uStack_110 = (undefined8 *)CONCAT44(uStack_110._4_4_,4);
        puVar18 = (uint *)func_0x(plVar3,puVar8,puVar18,uStack_88);
        uVar21 = uStack_88;
      }
    }
  }
LAB_:
  uStack_88 = uVar21;
  if ((puVar18 != (uint *)0x0) && (*(byte *)puVar18 != 0)) {
    auStack_68[0] = (uint)*(byte *)puVar18;
    lVar10 = func_0x();
    uStack_80 = *(undefined4 *)(lVar10 + 0x68);
    uStack_7c = 0;
    uStack_74 = 0;
    lVar10 = func_0x();
    if ((lVar10 != 0) && (lVar10 = func_0x(), *(longlong *)(lVar10 + 0x30) != 0)) {
      lVar10 = func_0x();
      uVar21 = *(uint *)(*(longlong *)(lVar10 + 0x30) + 0xc);
      if ((uVar21 < 0xe) && ((0x2640U >> (uVar21 & 0x1f) & 1) != 0)) {
        lVar10 = func_0x();
        if (*(longlong *)(lVar10 + 0xa0) != 0) {
          puVar12 = *(uint **)(*(longlong *)(lVar10 + 0xa0) + 8);
        }
      }
    }
    uVar2 = *(undefined4 *)(param_2 + 0xd4);
    LOCK();
    puVar8 = puVar12 + 2;
    uVar21 = *puVar8;
    *puVar8 = *puVar8 + 1;
    UNLOCK();
    uStack_90 = 0;
    puStack_d8 = auStack_68;
    uStack_98 = 0;
    uStack_a0 = 0;
    uStack_a8 = 0;
    iStack_e8 = uVar21 + 1;
    uStack_b0 = 1;
    uStack_b8 = 0;
    uStack_c0 = 0;
    uStack_c8 = 0;
    uStack_d0 = 0;
    uStack_e0 = 1;
    uStack_110 = &uStack_7c;
    uStack_f0 = 1;
    uStack_f8 = 0x10;
    uStack_100 = 0x146c;
    puStack_108 = (uint *)((ulonglong)puStack_108 & 0xffffffff00000000);
    puStack_118 = (uint *)(param_2 + 0x60);
    func_0x(puVar12,&uStack_80,param_2 + 0x154,uVar2);
    func_0x(param_1,2,(uint *)(param_2 + 0x60));
  }
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_138);
  return;
}

