
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2)

{
  ushort *puVar1;
  byte bVar2;
  ushort uVar3;
  undefined4 uVar4;
  bool bVar5;
  char cVar6;
  int iVar7;
  longlong lVar8;
  short *psVar9;
  uint uVar10;
  ulonglong uVar11;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar13;
  undefined8 unaff_RBX;
  undefined *puVar14;
  undefined8 unaff_RSI;
  undefined8 unaff_RDI;
  ulonglong uVar15;
  byte *pbVar16;
  short sVar17;
  ushort auStackX_8 [4];
  undefined2 auStackX_10 [2];
  undefined4 uStackX_14;
  undefined8 auStackX_18 [2];
  undefined8 uStack_30;
  ulonglong uVar12;
  
  uStack_30 = 0x100014;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  puVar14 = &stack0xffffffffffffffd8 + lVar8;
  puVar1 = (ushort *)((longlong)auStackX_8 + lVar8);
  *(undefined8 *)(&stack0x00002180 + lVar8) = unaff_RBX;
  *(undefined8 *)(&stack0x00002188 + lVar8) = unaff_RSI;
  *(undefined8 *)(&stack0x00002190 + lVar8) = unaff_RDI;
  *(ulonglong *)(&stack0x00002138 + lVar8) = _DAT_ ^ (ulonglong)puVar1;
  uVar3 = *(ushort *)(param_1 + 0x16);
  uVar15 = (ulonglong)uVar3;
  lVar13 = 0;
  *(undefined4 *)(&stack0x00000064 + lVar8) = param_2;
  *(undefined8 *)(&stack0x00000070 + lVar8) = 0;
  *(undefined2 *)((longlong)auStackX_10 + lVar8) = 0xffff;
  *(undefined8 *)((longlong)auStackX_18 + lVar8) = 0;
  *(undefined4 *)((longlong)&uStackX_14 + lVar8) = 0;
  *(undefined8 *)(&stack0x0000002e + lVar8) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar8) = 0;
  *(undefined8 *)((longlong)auStackX_18 + lVar8 + 8) = 0;
  *puVar1 = uVar3;
  *(undefined4 *)(&stack0x00000048 + lVar8) = 0;
  if (uVar3 != 0) {
    uVar11 = uVar15 * 2 + 0xf;
    if (uVar11 <= uVar15 * 2) {
      uVar11 = 0xffffffffffffff0;
    }
    uVar11 = uVar11 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_30 + lVar8) = 0x1000ab;
    func_0x();
    puVar14 = &stack0xffffffffffffffd8 + -uVar11 + lVar8;
    lVar13 = (longlong)auStackX_8 + -uVar11 + lVar8;
    *(longlong *)(&stack0x00000070 + lVar8) = lVar13;
  }
  uVar12 = 0;
  *(int *)(&stack0x00000060 + lVar8) = (int)uVar15;
  *(undefined4 *)(&stack0x0000004c + lVar8) = 0;
  uVar11 = uVar12;
  if ((int)uVar15 != 0) {
    do {
      uVar10 = (uint)uVar12;
      if ((*(ushort *)(param_1 + 0x16) <= uVar10) ||
         (bVar5 = true, *(short *)(param_1 + (0xfff - uVar11) * 2) == 0)) {
        bVar5 = false;
      }
      if (bVar5) {
        cVar6 = *(char *)(param_1 + 2);
        *(undefined2 *)(&stack0x000000e8 + lVar8) = 0xffff;
        *(undefined8 *)(&stack0x000000f0 + lVar8) = 0;
        *(undefined4 *)(&stack0x000000ec + lVar8) = 0;
        *(undefined8 *)(&stack0x00000106 + lVar8) = 0;
        *(undefined8 *)(&stack0x00000110 + lVar8) = 0;
        *(undefined8 *)(&stack0x000000f8 + lVar8) = 0;
        *(uint *)(&stack0x0000011c + lVar8) = uVar10;
        if (-1 < cVar6) goto LAB_;
        pbVar16 = (byte *)(param_1 + 0x60);
        *(undefined (*) [16])(&stack0x00000130 + lVar8) = ZEXT816(0);
        *(undefined8 *)(&stack0x00000190 + lVar8) = 0;
        *(undefined (*) [16])(&stack0x00000140 + lVar8) = ZEXT816(0);
        *(undefined2 *)(&stack0x00000130 + lVar8) = 0xffff;
        *(undefined (*) [16])(&stack0x00000150 + lVar8) = ZEXT816(0);
        *(undefined8 *)(&stack0x00000138 + lVar8) = 0;
        *(undefined (*) [16])(&stack0x00000180 + lVar8) = ZEXT816(0);
        *(undefined4 *)(&stack0x00000134 + lVar8) = 0;
        *(undefined (*) [16])(&stack0x00000160 + lVar8) = ZEXT816(0);
        *(undefined8 *)(&stack0x0000014e + lVar8) = 0;
        *(undefined8 *)(&stack0x00000158 + lVar8) = 0;
        *(undefined8 *)(&stack0x00000140 + lVar8) = 0;
        *(undefined8 *)(&stack0x00000168 + lVar8) = 0;
        *(undefined8 *)(&stack0x00000180 + lVar8) = 0;
        *(undefined4 *)(&stack0x00000188 + lVar8) = 0;
        *(undefined2 *)(&stack0x00000192 + lVar8) = 0;
        *(undefined (*) [16])(&stack0x00000170 + lVar8) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00000120 + lVar8) = ZEXT816(0);
        if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
          sVar17 = *(short *)(param_1 + 0x30);
          *(undefined8 *)(&stack0x00000050 + lVar8) = *(undefined8 *)(param_1 + 0x28);
          *(short *)(&stack0x00000058 + lVar8) = sVar17;
        }
        else {
          cVar6 = *(char *)(param_1 + 1);
          if (cVar6 == '\v') {
            if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
              if (cVar6 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar6 != '\b') goto LAB_;
LAB_:
            if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
          }
          *(undefined4 *)(&stack0x00000068 + lVar8) = *(undefined4 *)(param_1 + 0x20);
          *(undefined2 *)(&stack0x0000006c + lVar8) = *(undefined2 *)(param_1 + 0x24);
          *(undefined8 *)(puVar14 + -8) = 0x10021b;
          cVar6 = func_0x(&stack0x00000068 + lVar8);
          if (cVar6 == '\0') goto LAB_;
          *(undefined8 *)(puVar14 + -8) = 0x10022b;
          func_0x(param_1,&stack0x00000050 + lVar8);
          sVar17 = *(short *)(&stack0x00000058 + lVar8);
        }
        iVar7 = (int)((ulonglong)*(undefined8 *)(&stack0x00000050 + lVar8) >> 0x20);
        if ((((pbVar16 != *(byte **)(&stack0x00000120 + lVar8)) ||
             (sVar17 != *(short *)(&stack0x00000188 + lVar8))) ||
            (*(int *)(&stack0x00000050 + lVar8) != *(int *)(&stack0x00000180 + lVar8))) ||
           (((iVar7 != *(int *)(&stack0x00000184 + lVar8) ||
             (*(int *)(param_1 + 0x20) != *(int *)(&stack0x0000018c + lVar8))) ||
            (*(short *)(param_1 + 0x24) != *(short *)(&stack0x00000190 + lVar8))))) {
          *(undefined4 *)(&stack0x0000018c + lVar8) = *(undefined4 *)(param_1 + 0x20);
          *(undefined2 *)(&stack0x00000190 + lVar8) = *(undefined2 *)(param_1 + 0x24);
          *(int *)(&stack0x00000180 + lVar8) = *(int *)(&stack0x00000050 + lVar8);
          bVar2 = *pbVar16;
          *(int *)(&stack0x00000184 + lVar8) = iVar7;
          *(byte **)(&stack0x00000120 + lVar8) = pbVar16;
          *(short *)(&stack0x00000188 + lVar8) = sVar17;
          *(undefined2 *)(&stack0x00000192 + lVar8) = 0;
          *(undefined2 *)(&stack0x00000130 + lVar8) = 0xffff;
          lVar13 = (ulonglong)bVar2 * 6;
          uVar15 = (ulonglong)*(short *)(lVar13 + 0x1525644);
          *(undefined4 *)(&stack0x00000078 + lVar8) = *(undefined4 *)(lVar13 + 0x1525640);
          *(undefined8 *)(&stack0x00000138 + lVar8) = 0;
          *(undefined4 *)(&stack0x00000134 + lVar8) = 0;
          *(undefined8 *)(&stack0x0000014e + lVar8) = 0;
          *(undefined8 *)(&stack0x00000158 + lVar8) = 0;
          *(undefined8 *)(&stack0x00000140 + lVar8) = 0;
          *(undefined2 *)(&stack0x00000178 + lVar8) = 0;
          *(undefined (*) [16])(&stack0x00000168 + lVar8) = ZEXT816(0);
          if ((bVar2 & 2) != 0) {
            bVar2 = pbVar16[uVar15];
            pbVar16 = pbVar16 + uVar15;
            *(byte **)(&stack0x00000138 + lVar8) = pbVar16;
            if ((bVar2 & 1) == 0) {
              *(undefined2 *)(&stack0x00000130 + lVar8) = 0;
              *(undefined4 *)(&stack0x00000156 + lVar8) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100531 */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar16 & 0xe) * 4 + 0x101270) -
                        0x10147f0))();
              return;
            }
            *(undefined2 *)(&stack0x00000130 + lVar8) = 1;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)
                                    *(byte *)((longlong)(int)(*pbVar16 & 0x1c) + 0x101250) * 4 +
                                   0x101240) - 0x10147f0);
                    /* WARNING: Could not emulate address calculation at 0x0010036d */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          if ((**(byte **)(&stack0x00000120 + lVar8) & 4) != 0) {
            if (*(short *)(&stack0x0000007a + lVar8) != 0) {
              uVar15 = (ulonglong)
                       *(ushort *)
                        (param_1 + 0x61 + (longlong)*(short *)(&stack0x0000007a + lVar8) * 2);
            }
            psVar9 = (short *)(pbVar16 + uVar15);
            *(short **)(&stack0x00000168 + lVar8) = psVar9;
            sVar17 = *psVar9;
            *(short **)(&stack0x00000170 + lVar8) = psVar9 + 1;
            *(short *)(&stack0x00000178 + lVar8) = (sVar17 + 1) * 2;
          }
          lVar13 = *(longlong *)(&stack0x00000128 + lVar8);
          if (lVar13 != 0) {
            *(undefined8 *)(puVar14 + -8) = 0x100602;
            func_0x(lVar13,&stack0x00000120 + lVar8);
          }
        }
LAB_:
        pbVar16 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - uVar11) * 2) + param_1);
        bVar2 = *pbVar16;
        *(byte **)(&stack0x000000f0 + lVar8) = pbVar16;
        if ((bVar2 & 1) == 0) {
          *(undefined2 *)(&stack0x000000e8 + lVar8) = 0;
          *(undefined4 *)(&stack0x000000ec + lVar8) = 0;
          *(undefined4 *)(&stack0x0000010e + lVar8) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100838 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar16 & 0xe) * 4 + 0x1012dc) -
                    0x10147f0))();
          return;
        }
        *(undefined2 *)(&stack0x000000e8 + lVar8) = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar16 & 0x1c) + 0x1012bc) *
                                4 + 0x1012ac) - 0x10147f0);
                    /* WARNING: Could not emulate address calculation at 0x00100651 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      *(undefined2 *)(lVar13 + uVar11 * 2) = 0xffff;
      uVar10 = uVar10 + 1;
      uVar12 = (ulonglong)uVar10;
      *(uint *)(&stack0x0000004c + lVar8) = uVar10;
      uVar11 = uVar11 + 1;
    } while ((int)uVar10 < *(int *)(&stack0x00000060 + lVar8));
    uVar15 = (ulonglong)*puVar1;
  }
  *(longlong *)(&stack0x00000098 + lVar8) = lVar13;
  *(short *)(&stack0x000000a0 + lVar8) = (short)uVar15;
  uVar4 = *(undefined4 *)(&stack0x00000064 + lVar8);
  *(undefined **)(&stack0x00000088 + lVar8) = &stack0x00000198 + lVar8;
  *(undefined2 *)(&stack0x000000b0 + lVar8) = 0xffff;
  *(undefined8 *)(&stack0x000000b8 + lVar8) = 0;
  *(undefined4 *)(&stack0x000000b4 + lVar8) = 0;
  *(undefined8 *)(&stack0x000000ce + lVar8) = 0;
  *(undefined8 *)(&stack0x000000d8 + lVar8) = 0;
  *(undefined8 *)(&stack0x000000c0 + lVar8) = 0;
  *(undefined4 *)(&stack0x00000090 + lVar8) = 0x1f9e;
  *(undefined8 *)(&stack0x000000a8 + lVar8) = 0;
  *(undefined8 *)(puVar14 + -8) = 0x10120a;
  func_0x(param_1,&stack0x00000088 + lVar8,uVar4);
  uVar15 = *(ulonglong *)(&stack0x00002138 + lVar8);
  *(undefined8 *)(puVar14 + -8) = 0x101219;
  func_0x(uVar15 ^ (ulonglong)puVar1);
  return;
}

