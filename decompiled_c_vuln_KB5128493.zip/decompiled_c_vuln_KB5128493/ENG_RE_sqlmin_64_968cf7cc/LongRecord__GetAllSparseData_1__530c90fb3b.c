
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,undefined8 param_3,longlong param_4)

{
  ushort *puVar1;
  code *pcVar2;
  byte bVar3;
  ushort uVar4;
  int iVar5;
  ulonglong *puVar6;
  longlong lVar7;
  uint uVar8;
  int iVar9;
  ushort uVar10;
  uint uVar11;
  ulonglong uVar12;
  longlong lVar13;
  uint uVar14;
  byte *pbVar15;
  ushort *puVar16;
  longlong unaff_GS_OFFSET;
  undefined8 uStackX_18;
  
  uStackX_18 = param_3;
  func_0x(param_4);
  puVar1 = (ushort *)(param_4 + 2);
  uVar14 = 0;
  if (*(int *)(param_4 + 4) == 0) {
    pbVar15 = *(byte **)(param_4 + 8);
    uVar11 = *(uint *)(param_4 + 0x10);
    uVar12 = (ulonglong)uVar11;
    *puVar1 = 0;
    *(uint *)(param_4 + 0x14) = uVar11;
    bVar3 = *pbVar15;
    if ((bVar3 & 0x10) != 0) {
      uVar11 = uVar11 + 2 + (*(ushort *)(pbVar15 + uVar12) + 7 >> 3);
      uVar12 = (ulonglong)uVar11;
      *(uint *)(param_4 + 0x14) = uVar11;
      bVar3 = *pbVar15;
    }
    if ((bVar3 & 0x20) == 0) {
      *(int *)(param_4 + 4) = (int)uVar12;
      *(undefined2 *)(param_4 + 0x1c) = 0;
      *(int *)(param_4 + 0x18) = (int)uVar12;
    }
    else {
      puVar16 = (ushort *)(pbVar15 + uVar12);
      uVar4 = *puVar16;
      *(ushort *)(param_4 + 0x1c) = uVar4;
      if (uVar4 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar7 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar7 != 0)) &&
           ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xa8f958,0xbaf628,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),3);
        uVar12 = (ulonglong)*(uint *)(param_4 + 0x14);
        uVar4 = *(ushort *)(param_4 + 0x1c);
      }
      uVar11 = (int)uVar12 + (uVar4 + 1) * 2;
      *(uint *)(param_4 + 0x18) = uVar11;
      if (0x1f9e < uVar11) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar7 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar7 != 0 &&
            ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xa8f958,0xbaf628,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar4 = *(ushort *)(param_4 + 0x1c);
        uVar11 = *(uint *)(param_4 + 0x18);
      }
      uVar12 = (ulonglong)uVar4;
      uVar4 = puVar16[uVar12];
      *(uint *)(param_4 + 4) = uVar4 & 0x7fff;
      if ((uVar4 & 0x7fff) < uVar11) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar7 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar7 != 0)) &&
           ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xa8f958,0xbaf628,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar12 = (ulonglong)*(ushort *)(param_4 + 0x1c);
      }
      if ((short)puVar16[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
        lVar7 = *(longlong *)(param_4 + 8);
        do {
          lVar13 = (ulonglong)*(uint *)(param_4 + 0x14) + lVar7;
          if ((int)uVar12 == 1) {
            uVar11 = *(uint *)(param_4 + 0x18);
            uVar8 = uVar11;
LAB_:
            if ((*(ushort *)(lVar13 + uVar12 * 2) & 0x7fff) < uVar11) goto LAB_;
          }
          else {
            uVar8 = *(uint *)(param_4 + 0x18);
            uVar11 = *(ushort *)(lVar13 + -2 + uVar12 * 2) & 0x7fff;
            if (uVar8 <= uVar11) goto LAB_;
LAB_:
            func_0x(lVar7,7);
            uVar8 = *(uint *)(param_4 + 0x18);
          }
          if ((uVar11 < uVar8) || (*(uint *)(param_4 + 4) < uVar11)) goto LAB_;
          lVar7 = *(longlong *)(param_4 + 8);
          if (*(ushort *)(lVar7 + (ulonglong)uVar11) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(param_4 + 0x1c) = *(short *)(param_4 + 0x1c) + -1;
            uVar4 = *(ushort *)(param_4 + 0x2c) & 0xc7ff;
            *(short *)(param_4 + 0x2a) = (short)uVar11;
            lVar7 = (ulonglong)(uVar11 & 0xffff) + lVar7;
            if ((*(ushort *)(lVar7 + 2) >> 0xe & 1) != 0) {
              uVar4 = *(ushort *)(lVar7 + 2) & 0x3800 | uVar4;
            }
            *(ushort *)(param_4 + 0x2c) = uVar4;
            *(ushort *)(param_4 + 0x2c) = (uVar4 ^ *(ushort *)(lVar7 + 2)) & 0x7ff ^ uVar4;
            uVar12 = (ulonglong)*(uint *)(param_4 + 4);
            pbVar15 = *(byte **)(param_4 + 8);
            goto LAB_;
          }
          if (*(ushort *)(lVar7 + (ulonglong)uVar11) < 0x400) break;
          *puVar1 = *puVar1 | 1;
          uVar4 = *(short *)(param_4 + 0x1c) - 1;
          *(ushort *)(param_4 + 0x1c) = uVar4;
          if ((uVar4 == 0) ||
             (uVar12 = (ulonglong)uVar4, -1 < (short)puVar16[(ulonglong)(uVar4 - 1) + 1])) break;
        } while( true );
      }
      uVar12 = (ulonglong)*(uint *)(param_4 + 4);
      pbVar15 = *(byte **)(param_4 + 8);
    }
LAB_:
    if ((*pbVar15 & 0x40) == 0) {
      *(undefined4 *)(param_4 + 0x26) = 0;
    }
    else {
      *(int *)(param_4 + 0x26) = *(int *)(param_4 + 4);
      *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 0xe;
      puVar6 = (ulonglong *)func_0x(puVar1);
      uVar10 = (ushort)(*puVar6 >> 0x30);
      uVar4 = uVar10;
      if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
        uVar4 = uVar10 & 0xdfff;
        if ((uVar10 >> 0xe & 1) != 0) {
          uVar4 = uVar10 | 0x2000;
        }
      }
      uVar11 = uVar14;
      if (uVar4 == 0xfffc) {
        uVar11 = (uint)((*puVar6 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + uVar11;
      uVar12 = (ulonglong)*(uint *)(param_4 + 4);
    }
    iVar5 = (int)uVar12;
    if ((*(ulonglong *)(param_4 + 0x1e) != 0) &&
       (*(ulonglong *)(param_4 + 0x1e) < uVar12 + *(longlong *)(param_4 + 8))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar7 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar7 != 0 &&
           (lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0)) && (*(char *)(lVar7 + 0x499) != '\0'))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0xa8f958,0xbaf628,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),0x12);
      iVar5 = *(int *)(param_4 + 4);
    }
    if (0x3f3b < iVar5 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar7 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar7 != 0 &&
          ((lVar7 = *(longlong *)(lVar7 + 0x60), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0'))))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
          func_0x(*(undefined8 *)(param_4 + 8),5);
          goto LAB_;
        }
        (*_DAT_)(1,0xa8f958,0xbaf628,0x87c,0);
      }
      func_0x(*(undefined8 *)(param_4 + 8),5);
    }
  }
LAB_:
  iVar5 = func_0x(puVar1);
  if (iVar5 != 0) {
    uVar4 = *(ushort *)(param_4 + 0x2c);
    uVar11 = (uint)uVar4;
    iVar9 = *(int *)(param_4 + 4) - (uint)*(ushort *)(param_4 + 0x2a);
    iVar5 = iVar9 + -10;
    if ((*(byte *)puVar1 & 1) == 0) {
      iVar5 = iVar9;
    }
    if ((**(byte **)(param_4 + 8) & 0x40) != 0) {
      lVar7 = func_0x(puVar1,&uStackX_18);
      uVar4 = *(ushort *)(lVar7 + 6);
      uVar10 = uVar4;
      if ((((uint)(int)(short)uVar4 >> 1 ^ (int)(short)uVar4) & 0x2000) != 0) {
        uVar10 = uVar4 & 0xdfff;
        if ((uVar4 >> 0xe & 1) != 0) {
          uVar10 = uVar4 | 0x2000;
        }
      }
      if (uVar10 == 0xfffc) {
        uVar14 = (uint)(*(ushort *)(lVar7 + 4) >> 5);
      }
      uVar4 = *(ushort *)(param_4 + 0x2c);
      iVar5 = (iVar5 - uVar14) + -0xe;
    }
    uVar14 = (uVar11 & 0x7ff) * 4 + -4 + iVar5 + ((uVar4 >> 0xb & 7) + (uVar4 & 0x7ff)) * -2;
  }
  uVar4 = func_0x(param_2);
  if ((uint)uVar4 < uVar14 + 0x17) {
    (*_DAT_)(1,0xc6bd90,0xc6be60,0x4cd,0);
  }
  func_0x();
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}

