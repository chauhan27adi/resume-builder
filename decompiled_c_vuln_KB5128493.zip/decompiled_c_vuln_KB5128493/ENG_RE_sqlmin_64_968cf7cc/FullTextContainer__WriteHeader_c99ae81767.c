
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  longlong lVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  ulonglong *puVar6;
  byte bVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ushort uVar10;
  ushort uVar11;
  uint uVar12;
  ulonglong uVar13;
  int iVar14;
  ushort *puVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  longlong unaff_GS_OFFSET;
  undefined auStack_8d8 [32];
  undefined8 uStack_8b8;
  ulonglong uStack_8b0;
  undefined4 uStack_8a8;
  uint auStack_898 [2];
  undefined4 auStack_890 [2];
  undefined auStack_888 [16];
  short sStack_878;
  ushort uStack_876;
  uint uStack_874;
  byte *pbStack_870;
  undefined8 uStack_868;
  uint uStack_860;
  ushort uStack_85c;
  byte *pbStack_85a;
  undefined2 uStack_852;
  undefined2 uStack_850;
  undefined2 uStack_84e;
  ushort uStack_84c;
  undefined2 uStack_84a;
  undefined auStack_844 [2060];
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)auStack_8d8;
  iVar14 = 0;
  pbStack_870 = (byte *)0x0;
  uStack_874 = 0;
  pbStack_85a = (byte *)0x0;
  uStack_850 = 0;
  uStack_84e = 0;
  uStack_84c = 0;
  uStack_84a = 0;
  uStack_868 = 0;
  if (*(longlong *)(param_1 + 0x310) == 0) {
    uStack_8b8 = 0;
    (*_DAT_)(1,0xd8a8e8,0xd39270,0x3c9);
  }
  if ((*(longlong *)(param_1 + 0x348) == _DAT_) &&
     (*(longlong *)(param_1 + 0x350) == _DAT_)) {
    uStack_8b8 = 0;
    (*_DAT_)(1,0xd8a8c8,0xd39270,0x3cd);
  }
  if (*(int *)(param_1 + 0x32c) != 0) goto LAB_;
  auStack_890[0] = 4;
  func_0x(auStack_844,0,0x800);
  uStack_8b0 = uStack_8b0 & 0xffffffffffffff00;
  sStack_878 = 0;
  uStack_8b8._0_4_ = 0x3c;
  func_0x(&uStack_876,auStack_844);
  iVar4 = 0;
  uStack_8b8 = (ulonglong)uStack_8b8._4_4_ << 0x20;
  func_0x(auStack_888,4,1,0);
  func_0x(&sStack_878,auStack_888,auStack_890,4);
  func_0x(&sStack_878,1,param_1 + 0x348);
  func_0x(&sStack_878,0x18,param_1 + 0x358,0x10);
  func_0x(&sStack_878,3,param_1 + 0x368,4);
  func_0x(&sStack_878,4,param_1 + 0x36c,4);
  func_0x(&sStack_878,0x19,param_1 + 0x370,4);
  func_0x(&sStack_878,0x14,param_1 + 0x3d4,0xc);
  func_0x(&sStack_878,0x13,param_1 + 0x3ec,0xc);
  func_0x(&sStack_878,0x1a,param_1 + 0x404,0xc);
  func_0x(&sStack_878,0x11,param_1 + 0x3f8,0xc);
  func_0x(&sStack_878,0x1b,param_1 + 0x374,8);
  func_0x(&sStack_878,0x16,param_1 + 0x37c,0x10);
  func_0x(&sStack_878,0x1d,param_1 + 0x38c,0x10);
  func_0x(&sStack_878,0x12,param_1 + 0x39c,0x1c);
  lVar5 = -1;
  do {
    lVar1 = lVar5 * 2;
    lVar5 = lVar5 + 1;
  } while (*(short *)(param_1 + 0x20a + lVar1) != 0);
  func_0x(&sStack_878,0x1c,param_1 + 0x208,(int)lVar5 * 2);
  func_0x(&sStack_878,0x29,param_1 + 0x3b8,0x1c);
  iVar2 = (*_DAT_)(*(undefined8 *)(param_1 + 0x310),0,auStack_890,0);
  if (iVar2 == 0) {
    uVar3 = (*_DAT_)();
    func_0x(6,uVar3,0xca3340);
  }
  uVar13 = (ulonglong)uStack_874;
  if (sStack_878 == 0) {
    if (uStack_874 == 0) {
      uVar13 = uStack_868 & 0xffffffff;
      uStack_876 = 0;
      uVar17 = (uint)uStack_868;
      if ((*pbStack_870 & 0x10) != 0) {
        uVar17 = (uint)uStack_868 + 2 + (*(ushort *)(pbStack_870 + uVar13) + 7 >> 3);
        uVar13 = (ulonglong)uVar17;
      }
      uStack_868 = CONCAT44(uVar17,(uint)uStack_868);
      uStack_860 = (uint)uVar13;
      if ((*pbStack_870 & 0x20) == 0) {
        uStack_85c = 0;
        uStack_874 = uStack_860;
      }
      else {
        puVar15 = (ushort *)(pbStack_870 + uVar13);
        uStack_85c = *puVar15;
        if (uStack_85c == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar5 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar5 != 0)) &&
             ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 && (*(char *)(lVar5 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbb2148,0xcd1e18,0x80f);
            }
          }
          func_0x(pbStack_870,3);
        }
        uStack_860 = uStack_868._4_4_ + 2 + (uint)uStack_85c * 2;
        if (0x1f9e < uStack_860) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar5 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar5 != 0 &&
              ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
               (*(char *)(lVar5 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbb2148,0xcd1e18,0x816);
            }
          }
          func_0x(pbStack_870,4);
        }
        uStack_874 = puVar15[uStack_85c] & 0x7fff;
        uVar13 = (ulonglong)uStack_874;
        uVar17 = uStack_860;
        if (uStack_874 < uStack_860) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar5 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar5 != 0)) &&
             ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 && (*(char *)(lVar5 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbb2148,0xcd1e18,0x81d);
            }
          }
          func_0x(pbStack_870,4);
          uVar13 = (ulonglong)uStack_874;
          uVar17 = uStack_860;
        }
        do {
          uVar8 = (ulonglong)uStack_85c;
          if (-1 < (short)puVar15[(ulonglong)(uStack_85c - 1) + 1]) break;
          if (uStack_85c == 1) {
            uVar8 = 1;
            uVar12 = uVar17;
LAB_:
            if ((*(ushort *)(pbStack_870 + uVar8 * 2 + (uStack_868 >> 0x20)) & 0x7fff) < uVar12)
            goto LAB_;
          }
          else {
            uVar12 = *(ushort *)(pbStack_870 + uVar8 * 2 + ((uStack_868 >> 0x20) - 2)) & 0x7fff;
            if (uVar17 <= uVar12) goto LAB_;
LAB_:
            func_0x(pbStack_870,7);
            uVar13 = (ulonglong)uStack_874;
            uVar17 = uStack_860;
          }
          if ((uVar12 < uVar17) || ((uint)uVar13 < uVar12)) goto LAB_;
          if (*(ushort *)(pbStack_870 + uVar12) == 5) {
            uStack_876 = uStack_876 | 2;
            uStack_85c = uStack_85c - 1;
            uStack_84e = (undefined2)uVar12;
            if ((*(ushort *)(pbStack_870 + (ulonglong)(uVar12 & 0xffff) + 2) >> 0xe & 1) == 0) {
              uStack_84c = uStack_84c & 0xc7ff;
            }
            else {
              uStack_84c = uStack_84c ^
                           (uStack_84c ^ *(ushort *)(pbStack_870 + (ulonglong)(uVar12 & 0xffff) + 2)
                           ) & 0x3800;
            }
            uStack_84c = (uStack_84c ^ *(ushort *)(pbStack_870 + (ulonglong)(uVar12 & 0xffff) + 2))
                         & 0x7ff ^ uStack_84c;
            break;
          }
          if (*(ushort *)(pbStack_870 + uVar12) < 0x400) break;
          uStack_876 = uStack_876 | 1;
          uStack_85c = uStack_85c - 1;
        } while (uStack_85c != 0);
      }
      if ((*pbStack_870 & 0x40) == 0) {
        uStack_852 = 0;
        uStack_850 = 0;
      }
      else {
        uStack_852 = (undefined2)uVar13;
        uStack_850 = (undefined2)(uVar13 >> 0x10);
        uStack_874 = (int)uVar13 + 0xe;
        puVar6 = (ulonglong *)func_0x(&uStack_876);
        uVar10 = (ushort)(*puVar6 >> 0x30);
        uVar11 = uVar10;
        if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
          uVar11 = uVar10 & 0xdfff;
          if ((uVar10 >> 0xe & 1) != 0) {
            uVar11 = uVar10 | 0x2000;
          }
        }
        if (uVar11 == 0xfffc) {
          iVar4 = (int)((*puVar6 >> 0x20 & 0xffff) >> 5);
        }
        uStack_874 = uStack_874 + iVar4;
        uVar13 = (ulonglong)uStack_874;
      }
      if ((pbStack_85a != (byte *)0x0) && (pbStack_85a < pbStack_870 + uVar13)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar5 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar5 != 0 &&
             (lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0)) &&
            (*(char *)(lVar5 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_8b8 = 0;
            (*_DAT_)(1,0xbb2148,0xcd1e18,0x877);
          }
        }
        func_0x(pbStack_870,0x12);
        uVar13 = (ulonglong)uStack_874;
      }
      if (0x3f3b < (int)uVar13 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar5 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar5 != 0 &&
            ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 && (*(char *)(lVar5 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_8b8 = 0;
            (*_DAT_)(1,0xbb2148,0xcd1e18,0x87c);
          }
        }
        func_0x(pbStack_870,5);
        uVar13 = (ulonglong)uStack_874;
      }
    }
LAB_:
    if ((uint)uVar13 < 9) {
      bVar7 = *pbStack_870 & 0xe;
joined_r0x001009b1:
      if ((bVar7 == 0) || (bVar7 == 0xc)) {
        uVar13 = 9;
      }
    }
  }
  else {
    if (uStack_874 == 0) {
      func_0x(&uStack_876);
      uVar13 = (ulonglong)uStack_874;
    }
    if ((uint)uVar13 < 9) {
      bVar7 = *pbStack_870 & 0x1c;
      goto joined_r0x001009b1;
    }
  }
  uVar17 = 9;
  uStack_8b8 = 0;
  iVar4 = (*_DAT_)(*(undefined8 *)(param_1 + 0x310),pbStack_870,uVar13,auStack_898);
  if (iVar4 == 0) {
LAB_:
    uVar3 = (*_DAT_)();
    uStack_8a8 = 0x436;
    uStack_8b0 = 0xd39270;
    uStack_8b8 = param_1;
    func_0x(3,uVar3,0,0xc9d6b0);
  }
  else {
    if (sStack_878 == 0) {
      uVar12 = uStack_874;
      if (uStack_874 == 0) {
        uVar13 = uStack_868 & 0xffffffff;
        uStack_876 = 0;
        uVar12 = (uint)uStack_868;
        if ((*pbStack_870 & 0x10) != 0) {
          uVar12 = (uint)uStack_868 + 2 + (*(ushort *)(pbStack_870 + uVar13) + 7 >> 3);
          uVar13 = (ulonglong)uVar12;
        }
        uStack_868 = CONCAT44(uVar12,(uint)uStack_868);
        if ((*pbStack_870 & 0x20) == 0) {
          uStack_85c = 0;
          uStack_874 = (uint)uVar13;
          uStack_860 = (uint)uVar13;
        }
        else {
          puVar15 = (ushort *)(pbStack_870 + uVar13);
          uStack_85c = *puVar15;
          if (uStack_85c == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar5 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar5 != 0)) &&
               ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                (*(char *)(lVar5 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_8b8 = 0;
                (*_DAT_)(1,0xbb2148,0xcd1e18,0x80f);
              }
            }
            func_0x(pbStack_870,3);
          }
          uStack_860 = uStack_868._4_4_ + 2 + (uint)uStack_85c * 2;
          if (0x1f9e < uStack_860) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar5 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar5 != 0 &&
                ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                 (*(char *)(lVar5 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_8b8 = 0;
                (*_DAT_)(1,0xbb2148,0xcd1e18,0x816);
              }
            }
            func_0x(pbStack_870,4);
          }
          uVar8 = (ulonglong)uStack_85c;
          uStack_874 = puVar15[uVar8] & 0x7fff;
          uVar13 = (ulonglong)uStack_874;
          uVar18 = uStack_860;
          if (uStack_874 < uStack_860) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar5 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar5 != 0)) &&
               ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                (*(char *)(lVar5 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_8b8 = 0;
                (*_DAT_)(1,0xbb2148,0xcd1e18,0x81d);
              }
            }
            func_0x(pbStack_870,4);
            uVar8 = (ulonglong)uStack_85c;
            uVar13 = (ulonglong)uStack_874;
            uVar18 = uStack_860;
          }
          do {
            if (-1 < (short)puVar15[(ulonglong)((int)uVar8 - 1) + 1]) break;
            if ((int)uVar8 == 1) {
              uVar9 = 1;
              uVar16 = uVar18;
LAB_:
              if ((*(ushort *)(pbStack_870 + uVar9 * 2 + (uStack_868 >> 0x20)) & 0x7fff) < uVar16)
              goto LAB_;
            }
            else {
              uVar16 = *(ushort *)(pbStack_870 + uVar8 * 2 + ((uStack_868 >> 0x20) - 2)) & 0x7fff;
              uVar9 = uVar8;
              if (uVar18 <= uVar16) goto LAB_;
LAB_:
              func_0x(pbStack_870,7);
              uVar8 = (ulonglong)uStack_85c;
              uVar13 = (ulonglong)uStack_874;
              uVar18 = uStack_860;
            }
            uVar12 = (uint)uVar13;
            if ((uVar16 < uVar18) || (uVar12 < uVar16)) goto LAB_;
            if (*(ushort *)(pbStack_870 + uVar16) == 5) {
              uStack_876 = uStack_876 | 2;
              uStack_85c = (short)uVar8 - 1;
              uStack_84e = (undefined2)uVar16;
              if ((*(ushort *)(pbStack_870 + (ulonglong)(uVar16 & 0xffff) + 2) & 0x4000) == 0) {
                uStack_84c = uStack_84c & 0xc7ff;
              }
              else {
                uStack_84c = uStack_84c ^
                             (*(ushort *)(pbStack_870 + (ulonglong)(uVar16 & 0xffff) + 2) ^
                             uStack_84c) & 0x3800;
              }
              uStack_84c = (uStack_84c ^ *(ushort *)(pbStack_870 + (ulonglong)(uVar16 & 0xffff) + 2)
                           ) & 0x7ff ^ uStack_84c;
              break;
            }
            if (*(ushort *)(pbStack_870 + uVar16) < 0x400) break;
            uStack_876 = uStack_876 | 1;
            uStack_85c = (short)uVar8 - 1;
            uVar8 = (ulonglong)uStack_85c;
          } while (uStack_85c != 0);
        }
        if ((*pbStack_870 & 0x40) == 0) {
          uStack_852 = 0;
          uStack_850 = 0;
        }
        else {
          uStack_852 = (undefined2)uVar13;
          uStack_850 = (undefined2)(uVar13 >> 0x10);
          uStack_874 = (int)uVar13 + 0xe;
          puVar6 = (ulonglong *)func_0x(&uStack_876);
          uVar13 = *puVar6;
          uVar10 = (ushort)(uVar13 >> 0x30);
          uVar11 = uVar10;
          if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
            uVar11 = uVar10 & 0xdfff;
            if ((uVar13 & 0x4000000000000000) != 0) {
              uVar11 = uVar10 | 0x2000;
            }
          }
          if (uVar11 == 0xfffc) {
            iVar14 = (int)((uVar13 >> 0x20 & 0xffff) >> 5);
          }
          uStack_874 = uStack_874 + iVar14;
          uVar13 = (ulonglong)uStack_874;
        }
        uVar12 = (uint)uVar13;
        if ((pbStack_85a != (byte *)0x0) && (pbStack_85a < pbStack_870 + uVar13)) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar5 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar5 != 0 &&
               (lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0)) &&
              (*(char *)(lVar5 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbb2148,0xcd1e18,0x877);
            }
          }
          func_0x(pbStack_870,0x12);
          uVar12 = uStack_874;
        }
        if (0x3f3b < uVar12 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar5 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar5 != 0 &&
              ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
               (*(char *)(lVar5 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbb2148,0xcd1e18,0x87c);
            }
          }
          func_0x(pbStack_870,5);
          uVar12 = uStack_874;
        }
      }
LAB_:
      if ((8 < uVar12) || (((*pbStack_870 & 0xe) != 0 && ((*pbStack_870 & 0xe) != 0xc)))) {
        uVar17 = uVar12;
      }
    }
    else {
      if (uStack_874 == 0) {
        func_0x(&uStack_876);
      }
      if ((8 < uStack_874) || (((*pbStack_870 & 0x1c) != 0 && ((*pbStack_870 & 0x1c) != 0xc)))) {
        uVar17 = uStack_874;
      }
    }
    if (auStack_898[0] != uVar17) goto LAB_;
  }
  func_0x(*(undefined8 *)(param_1 + 0x310),param_1,6);
  *(undefined4 *)(param_1 + 0x31c) = 1;
LAB_:
  func_0x(uStack_38 ^ (ulonglong)auStack_8d8);
  return;
}

