
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,longlong *param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  code *pcVar4;
  ulonglong uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong lVar9;
  undefined8 *puVar10;
  undefined8 unaff_RBX;
  undefined8 *puVar11;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  *(undefined8 *)(&stack0x00004c60 + lVar9) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004cb0 + lVar9) = unaff_RBX;
  puVar11 = (undefined8 *)((ulonglong)(&stack0x00000058 + lVar9) & 0xffffffffffffffc0);
  puVar11[0x980] = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9);
  if (param_2 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((*(short *)(*(longlong *)(param_1 + 0x90) + 0x6b8) == 2) &&
      (lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x90) + 0x65f0), lVar1 != 0)) &&
     (*(char *)(lVar1 + 0x1bc1) != '\0')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_2 == 1) && ((*(byte *)(param_1 + 0x40) & 8) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(param_1 + 0x70) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 100) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000bf;
    func_0x(puVar11 + 0x658);
    if (*(int *)(param_1 + 0x480) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((_DAT_ == *(short *)((longlong)param_3 + 0x2c)) &&
       (_DAT_ == *(int *)(param_3 + 5))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(puVar11 + 4) = 0xc5a;
    uVar2 = _DAT_;
    puVar11[2] = _DAT_;
    (&stack0xffffffffffffffe8)[lVar9] = 5;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100118;
    puVar10 = (undefined8 *)(*_DAT_)(0x48,uVar2,0x24414b0,0xc5a);
    *puVar11 = puVar10;
    if (puVar10 != (undefined8 *)0x0) {
      uVar2 = *(undefined8 *)(param_1 + 0x84);
      uVar3 = *(undefined8 *)(*(longlong *)(param_1 + 0x90) + 0x710);
      puVar10[1] = 0;
      puVar10[2] = 0;
      puVar10[3] = 0;
      puVar10[4] = 0;
      *puVar10 = 0x23df500;
      *(undefined2 *)((longlong)puVar10 + 0x46) = 0;
      puVar10[7] = uVar3;
      *(int *)(puVar10 + 8) = (int)uVar2;
      *(short *)((longlong)puVar10 + 0x44) = (short)((ulonglong)uVar2 >> 0x20);
      uVar6 = *(undefined4 *)((longlong)param_3 + 0x7c);
      uVar7 = *(undefined4 *)(param_3 + 0x10);
      uVar8 = *(undefined4 *)((longlong)param_3 + 0x84);
      *(undefined4 *)(param_1 + 0x70) = *(undefined4 *)(param_3 + 0xf);
      *(undefined4 *)(param_1 + 0x74) = uVar6;
      *(undefined4 *)(param_1 + 0x78) = uVar7;
      *(undefined4 *)(param_1 + 0x7c) = uVar8;
      pcVar4 = *(code **)(*param_3 + 0x158);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10018a;
      (*pcVar4)(param_3,puVar10);
      LOCK();
      *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 1;
      UNLOCK();
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001ac;
      func_0x(puVar11 + 0x7c0,0x1c0,8,0x154cc0);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001cb;
      func_0x(puVar11 + 0x750,0x1c0,2,0x154cc0);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001e7;
      func_0x(puVar11 + 0x6d8,0x1c0,2,0x154cc0);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100203;
      func_0x(puVar11 + 0x660,0x1c0,2,0x154cc0);
      uVar5 = puVar11[0x980];
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100217;
      func_0x(uVar5 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9));
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

