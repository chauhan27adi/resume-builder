
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,longlong param_2,undefined8 param_3,longlong *param_4,
                 int *param_5,int param_6,byte **param_7,short *param_8)

{
  byte *pbVar1;
  undefined2 uVar2;
  uint *puVar3;
  short *psVar4;
  char cVar5;
  short sVar6;
  int iVar7;
  longlong lVar8;
  longlong lVar9;
  longlong *plVar10;
  short *psVar11;
  undefined8 *puVar12;
  byte bVar13;
  byte bVar14;
  ushort uVar15;
  uint uVar16;
  undefined4 uVar17;
  int iVar18;
  undefined8 *puVar19;
  ushort uVar20;
  uint uVar21;
  uint uVar22;
  longlong *plVar23;
  longlong lVar24;
  ulonglong uVar25;
  byte **ppbVar26;
  ushort *puVar27;
  ulonglong uVar28;
  ushort *puVar29;
  ulonglong *puVar30;
  byte *pbVar31;
  longlong lVar32;
  ulonglong uVar33;
  longlong unaff_GS_OFFSET;
  undefined auStack_2b8 [32];
  undefined8 uStack_298;
  uint uStack_290;
  uint uStack_288;
  undefined8 uStack_280;
  undefined8 uStack_278;
  uint uStack_270;
  longlong *plStack_268;
  int *piStack_260;
  undefined8 uStack_258;
  undefined8 uStack_250;
  undefined4 uStack_248;
  undefined4 uStack_240;
  undefined8 uStack_238;
  undefined8 *puStack_230;
  uint uStack_228;
  short sStack_220;
  ushort uStack_21e;
  uint uStack_21c;
  byte *pbStack_218;
  undefined8 uStack_210;
  uint uStack_208;
  ushort uStack_204;
  byte *pbStack_202;
  undefined2 uStack_1fa;
  undefined2 uStack_1f8;
  undefined2 uStack_1f6;
  ushort uStack_1f4;
  undefined2 uStack_1f2;
  undefined4 uStack_1f0;
  short *psStack_1e8;
  longlong **pplStack_1e0;
  int iStack_1d8;
  undefined4 uStack_1d4;
  longlong *plStack_1d0;
  longlong lStack_1c8;
  undefined8 uStack_1c0;
  ushort uStack_1b8;
  undefined8 uStack_1b0;
  ushort uStack_1a8;
  undefined8 uStack_1a0;
  undefined2 uStack_198;
  int iStack_190;
  uint uStack_18c;
  int iStack_188;
  undefined4 uStack_184;
  undefined2 uStack_180;
  undefined4 uStack_17c;
  undefined2 uStack_178;
  undefined4 uStack_174;
  undefined2 uStack_170;
  byte **ppbStack_168;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined8 uStack_158;
  undefined8 uStack_150;
  longlong lStack_148;
  undefined4 uStack_140;
  int *piStack_138;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  byte *pbStack_118;
  short sStack_108;
  ushort uStack_106;
  uint uStack_104;
  byte *pbStack_100;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  ushort uStack_ec;
  undefined2 uStack_ea;
  undefined6 uStack_e8;
  undefined2 uStack_e2;
  undefined2 uStack_e0;
  undefined2 uStack_de;
  ushort uStack_dc;
  undefined2 uStack_da;
  undefined4 uStack_d8;
  int iStack_d4;
  undefined auStack_d0 [16];
  undefined auStack_c0 [8];
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  undefined6 uStack_a8;
  undefined2 uStack_a2;
  undefined6 uStack_a0;
  undefined2 uStack_9a;
  undefined8 uStack_98;
  undefined auStack_90 [16];
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined8 uStack_60;
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_2b8;
  lVar32 = param_4[6];
  piStack_138 = param_5;
  ppbStack_168 = param_7;
  psStack_1e8 = param_8;
  bVar13 = *(byte *)(param_7 + 2);
  puVar12 = (undefined8 *)0x0;
  uStack_18c = bVar13 & 1;
  pbStack_100 = (byte *)0x0;
  uStack_104 = 0;
  uStack_ea = 0;
  uStack_e8 = 0;
  iStack_188 = (bVar13 & 2) << 0x15;
  sStack_108 = -1;
  iStack_d4 = -1;
  uStack_e0 = 0;
  uStack_de = 0;
  uStack_dc = 0;
  uStack_da = 0;
  lStack_148 = (ulonglong)*(uint6 *)(param_2 + 0x14) << 0x10;
  uStack_f8 = (byte **)0x0;
  pplStack_1e0 = param_1;
  plStack_1d0 = param_4;
  uStack_150 = param_3;
  if ((bVar13 & 4) != 0) {
    uStack_298 = (short *)0x146d378;
    (*_DAT_)(1,0x1472e68,0x143d090,0xcf);
  }
  lVar8 = _DAT_;
  plVar10 = *param_1;
  uVar2 = *(undefined2 *)(lVar32 + 0x6b8);
  iStack_1d8 = param_6;
  if (_DAT_ != 0) {
    LOCK();
    plVar23 = (longlong *)(_DAT_ + 0x10);
    lVar24 = *plVar23;
    *plVar23 = *plVar23 + 1;
    UNLOCK();
    puVar30 = (ulonglong *)
              (((ulonglong)*(uint *)(lVar8 + 4) & lVar24 + 1U & 0xffffffff) * 0x60 +
              *(longlong *)(lVar8 + 0x18));
    *puVar30 = lVar24 + 1U;
    *(undefined2 *)(puVar30 + 1) = uVar2;
    *(undefined4 *)((longlong)puVar30 + 10) = *(undefined4 *)(plVar10 + 0xe);
    *(undefined2 *)((longlong)puVar30 + 0xe) = *(undefined2 *)((longlong)plVar10 + 0x74);
    *(short *)(puVar30 + 2) = (short)param_6;
    *(undefined4 *)((longlong)puVar30 + 0x14) = 3;
    *(undefined4 *)(puVar30 + 3) = *(undefined4 *)(param_4 + 5);
    *(undefined2 *)((longlong)puVar30 + 0x1c) = *(undefined2 *)((longlong)param_4 + 0x2c);
    plVar10 = *param_1;
  }
  lVar8 = func_0x(_DAT_,plVar10,1,0);
  *(ushort *)(lVar8 + 4) = *(ushort *)(lVar8 + 4) & 0xedff;
  *(undefined4 *)(lVar8 + 0x40) = 1;
  plVar10 = *param_1;
  uStack_1d4 = 2;
  lStack_1c8 = lVar8;
  if (*(short *)((longlong)plVar10 + 0x2c) != 2) {
    lVar24 = plVar10[0x12];
    if (lVar24 == 0) {
      func_0x(plVar10);
      lVar24 = plVar10[0x12];
      plVar10 = *param_1;
    }
    if (((*(byte *)(*(longlong *)(lVar24 + 0x6b0) + 0x3c) & 1) != 0) &&
       (*(longlong *)(*(longlong *)(lVar24 + 0x6b0) + 0x280) == 0)) {
      lVar24 = plVar10[0x12];
      if (lVar24 == 0) {
        func_0x(plVar10);
        lVar24 = plVar10[0x12];
      }
      cVar5 = func_0x(lVar24);
      if (cVar5 == '\0') goto LAB_;
    }
    plVar10 = *param_1;
    lVar24 = plVar10[0x12];
    if (lVar24 == 0) {
      func_0x(plVar10);
      lVar24 = plVar10[0x12];
    }
    if ((*(byte *)(lVar24 + 0x1cd0) & 0x20) == 0) {
      lVar24 = **param_1;
      if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
        uStack_1c0 = *(undefined8 *)(lVar24 + 0x28);
        uStack_1b8 = *(ushort *)(lVar24 + 0x30);
      }
      else {
        cVar5 = *(char *)(lVar24 + 1);
        if (cVar5 == '\v') {
          if (*(int *)(lVar24 + 0x18) != 99) {
LAB_:
            if (cVar5 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar5 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar24 + 0x18) != 99) goto LAB_;
        }
        uStack_184 = *(undefined4 *)(lVar24 + 0x20);
        uStack_180 = *(undefined2 *)(lVar24 + 0x24);
        cVar5 = func_0x(&uStack_184);
        if (cVar5 == '\0') goto LAB_;
        func_0x(lVar24,&uStack_1c0);
      }
      uVar15 = uStack_1b8;
      plVar10 = *param_1;
      lVar24 = plVar10[0x12];
      if (lVar24 == 0) {
        func_0x(plVar10);
        lVar24 = plVar10[0x12];
      }
      lVar9 = func_0x
                        (*(undefined8 *)(lVar24 + 0x6a0),*(undefined2 *)((longlong)plVar10 + 0x74),0
                        );
      plVar10 = *pplStack_1e0;
      lVar24 = plVar10[0x12];
      if (lVar24 == 0) {
        func_0x(plVar10);
        lVar24 = plVar10[0x12];
        plVar10 = *pplStack_1e0;
      }
      if (*(int *)(*(longlong *)(lVar24 + 0x7a8) + 0x58) == 0) {
        if ((uint)uStack_1c0 < *(uint *)(lVar9 + 0x130)) goto LAB_;
        if (*(uint *)(lVar9 + 0x130) == (uint)uStack_1c0) {
          if ((uStack_1c0._4_4_ < *(uint *)(lVar9 + 0x134)) ||
             ((*(uint *)(lVar9 + 0x134) == uStack_1c0._4_4_ && (uVar15 < *(ushort *)(lVar9 + 0x138))
              ))) goto LAB_;
        }
      }
      else {
LAB_:
        lVar24 = plVar10[0x12];
        if (lVar24 == 0) {
          func_0x(plVar10);
          lVar24 = plVar10[0x12];
          plVar10 = *pplStack_1e0;
        }
        param_1 = pplStack_1e0;
        if (((*(byte *)(*(longlong *)(lVar24 + 0x6b0) + 0x3c) & 1) == 0) ||
           (*(longlong *)(*(longlong *)(lVar24 + 0x6b0) + 0x280) != 0)) {
          lVar24 = plVar10[0x12];
          plVar23 = plVar10;
          if (lVar24 == 0) {
            func_0x(plVar10);
            plVar23 = *param_1;
            lVar24 = plVar10[0x12];
          }
          func_0x(lVar24,*plVar23 + 0x20);
          goto LAB_;
        }
      }
      lVar24 = plVar10[0x12];
      if (lVar24 == 0) {
        func_0x(plVar10);
        lVar24 = plVar10[0x12];
        plVar10 = *pplStack_1e0;
      }
      param_1 = pplStack_1e0;
      if ((*(int *)(*(longlong *)(lVar24 + 0x7a8) + 0x110) != 0) &&
         (lVar24 = *plVar10, uVar16 = *(uint *)(lVar24 + 0x20) & 0xfffffff8,
         uVar16 != (uVar16 / 0x7cd00) * 0x7cd00)) {
        lVar9 = plVar10[0x12];
        if (lVar9 == 0) {
          func_0x(plVar10);
          lVar9 = plVar10[0x12];
          lVar24 = **param_1;
        }
        func_0x(*(undefined8 *)(lVar9 + 0x7a8),lVar24 + 0x20);
      }
    }
  }
LAB_:
  lVar24 = **param_1;
  if ((*(ushort *)(lVar24 + 4) & 0x2000) != 0) {
    if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
      uStack_1b0 = *(undefined8 *)(lVar24 + 0x28);
      uStack_1a8 = *(ushort *)(lVar24 + 0x30);
    }
    else {
      cVar5 = *(char *)(lVar24 + 1);
      if (cVar5 == '\v') {
        if (*(int *)(lVar24 + 0x18) != 99) {
LAB_:
          if (cVar5 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar5 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar24 + 0x18) != 99) goto LAB_;
      }
      uStack_17c = *(undefined4 *)(lVar24 + 0x20);
      uStack_178 = *(undefined2 *)(lVar24 + 0x24);
      cVar5 = func_0x(&uStack_17c);
      if (cVar5 == '\0') goto LAB_;
      func_0x(lVar24,&uStack_1b0);
    }
    uVar15 = uStack_1a8;
    plVar10 = *param_1;
    lVar24 = plVar10[0x12];
    if (lVar24 == 0) {
      func_0x(plVar10);
      lVar24 = plVar10[0x12];
    }
    puVar3 = *(uint **)(*(longlong *)(lVar24 + 0x6b0) + 0x2c0);
    if (((*(short *)((longlong)puVar3 + 10) != 2) || ((uint)uStack_1b0 != 0)) &&
       ((uint)uStack_1b0 <= *puVar3)) {
      if ((uint)uStack_1b0 == *puVar3) {
        if ((puVar3[1] < uStack_1b0._4_4_) ||
           ((uStack_1b0._4_4_ == puVar3[1] && (*(ushort *)(puVar3 + 2) < uVar15))))
        goto LAB_;
      }
      func_0x(param_1);
    }
  }
LAB_:
  plVar10 = plStack_1d0;
  cVar5 = (**(code **)*plStack_1d0)(plStack_1d0);
  if (cVar5 != '\0') {
    bVar13 = **(byte **)(psStack_1e8 + 4) >> 1;
    if (*psStack_1e8 == 0) {
      bVar13 = **(byte **)(psStack_1e8 + 4) >> 6;
    }
    if ((bVar13 & 1) != 0) {
      plVar23 = *param_1;
      lVar24 = plVar23[0x12];
      if (lVar24 == 0) {
        func_0x(plVar23);
        lVar24 = plVar23[0x12];
      }
      if (*(ushort *)(lVar24 + 0x67e) < 0x387) {
        uVar15 = (ushort)(byte)~(*(byte *)(*plVar23 + 2) >> 6);
      }
      else {
        uVar15 = (ushort)~*(ushort *)((longlong)plVar23 + 0x62) >> 8;
      }
      if ((uVar15 & 1) != 0) {
        func_0x(param_1,1,plVar10);
      }
    }
  }
  uStack_128 = *(undefined4 *)ppbStack_168;
  uStack_124 = *(undefined4 *)((longlong)ppbStack_168 + 4);
  uStack_120 = *(undefined4 *)(ppbStack_168 + 1);
  uStack_11c = *(undefined4 *)((longlong)ppbStack_168 + 0xc);
  pbStack_118 = ppbStack_168[2];
  iVar7 = func_0x(param_1,plVar10,&uStack_128);
  uStack_228 = 9;
  ppbVar26 = ppbStack_168;
  if (iVar7 != 0) {
    plVar23 = *param_1;
    lVar24 = plVar23[0x12];
    if (lVar24 == 0) {
      func_0x(plVar23);
      lVar24 = plVar23[0x12];
    }
    if (*(ushort *)(lVar24 + 0x67e) < 0x387) {
      uVar15 = (ushort)(byte)~(*(byte *)(*plVar23 + 2) >> 6);
    }
    else {
      uVar15 = (ushort)~*(ushort *)((longlong)plVar23 + 0x62) >> 8;
    }
    if (((uVar15 & 1) != 0) && (cVar5 = (**(code **)(*plVar10 + 0x88))(plVar10), cVar5 == '\0')) {
      func_0x(param_1,1,plVar10);
    }
    if ((*(byte *)(plVar10 + 0x43) & 4) != 0) {
      plVar10 = (longlong *)(**(code **)(*plVar10 + 0x1e8))(plVar10);
    }
    psVar4 = psStack_1e8;
    puVar29 = (ushort *)(psStack_1e8 + 1);
    if (*psStack_1e8 == 0) {
      func_0x();
    }
    else {
      func_0x(puVar29,plVar10 + 5);
    }
    iStack_d4 = iStack_1d8;
    if (*(char *)(lVar8 + 2) < '\0') {
      pbVar31 = (byte *)(lVar8 + 0x60);
      if ((sStack_108 == 0) || (ppbVar26 = uStack_f8, uStack_f8 == (byte **)0x0)) {
        ppbVar26 = (byte **)auStack_d0;
        stack0xffffffffffffff42 = SUB1614(ZEXT816(0),2);
        auStack_c0._0_2_ = 0xffff;
        uStack_a8 = 0;
        uStack_9a = 0;
        uStack_b8 = 0;
        uStack_a2 = 0;
        uStack_a0 = 0;
        uStack_98 = 0;
        uStack_b0 = 0;
        auStack_90 = ZEXT816(0);
        auStack_70._0_12_ = ZEXT812(0);
        auStack_70._12_4_ = 0;
        uStack_60 = 0;
        auStack_80 = ZEXT816(0);
        auStack_d0 = ZEXT816(0);
      }
      if (*(short *)(lVar8 + 0x24) == 0) {
LAB_:
        uStack_1a0 = *(undefined8 *)(lVar8 + 0x28);
        uStack_198 = *(undefined2 *)(lVar8 + 0x30);
      }
      else {
        cVar5 = *(char *)(lVar8 + 1);
        if (cVar5 == '\v') {
          if (*(int *)(lVar8 + 0x18) != 99) {
LAB_:
            if (cVar5 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar5 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar8 + 0x18) != 99) goto LAB_;
        }
        uStack_174 = *(undefined4 *)(lVar8 + 0x20);
        uStack_170 = *(undefined2 *)(lVar8 + 0x24);
        cVar5 = func_0x(&uStack_174);
        if (cVar5 == '\0') goto LAB_;
        func_0x(lVar8,&uStack_1a0);
      }
      *ppbVar26 = pbVar31;
      *(undefined4 *)(ppbVar26 + 0xc) = (undefined4)uStack_1a0;
      *(undefined2 *)(ppbVar26 + 0xd) = uStack_198;
      *(int *)((longlong)ppbVar26 + 100) = (int)((ulonglong)uStack_1a0 >> 0x20);
      *(undefined4 *)((longlong)ppbVar26 + 0x6c) = *(undefined4 *)(lVar8 + 0x20);
      *(undefined2 *)(ppbVar26 + 0xe) = *(undefined2 *)(lVar8 + 0x24);
      *(undefined2 *)((longlong)ppbVar26 + 0x72) = 0;
      uStack_140 = *(undefined4 *)((ulonglong)*pbVar31 * 6 + 0x10b4b50);
      uVar33 = (ulonglong)*(short *)((ulonglong)*pbVar31 * 6 + 0x10b4b54);
      *(undefined2 *)(ppbVar26 + 2) = 0xffff;
      ppbVar26[3] = (byte *)0x0;
      uVar16 = 0;
      *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
      ppbVar26[7] = (byte *)0x0;
      ppbVar26[4] = (byte *)0x0;
      ppbVar26[9] = (byte *)0x0;
      ppbVar26[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar26 + 0xb) = 0;
      if ((**ppbVar26 & 2) != 0) {
        pbVar1 = pbVar31 + uVar33;
        if ((pbVar31[uVar33] & 1) == 0) {
          *(undefined2 *)(ppbVar26 + 2) = 0;
          ppbVar26[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar26 + 0x36) = 0;
          switch(*pbVar1 & 0xe) {
          default:
            uVar16 = (uint)*(ushort *)(pbVar1 + 2);
            if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
              func_0x(pbVar1,6);
            }
            break;
          case 4:
            uVar16 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar16 = 1;
          }
          *(uint *)(ppbVar26 + 4) = uVar16;
          *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
        }
        else {
          *(undefined2 *)(ppbVar26 + 2) = 1;
          ppbVar26[3] = pbVar1;
          bVar13 = *pbVar1;
          switch(bVar13 & 0x1c) {
          default:
            if ((char)pbVar1[1] < '\0') {
              uVar15 = *(ushort *)(pbVar1 + 1);
              sVar6 = 3;
              *(ushort *)((longlong)ppbVar26 + 0x12) = uVar15;
              uVar15 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
            }
            else {
              sVar6 = 2;
              uVar15 = (ushort)pbVar1[1];
            }
            *(ushort *)((longlong)ppbVar26 + 0x12) = uVar15;
            *(short *)(ppbVar26 + 5) = sVar6;
            uVar15 = *(ushort *)((longlong)ppbVar26 + 0x12);
            *(short *)((longlong)ppbVar26 + 0x2c) = (short)(uVar15 + 1 >> 1) + sVar6;
            if (uVar15 < 0x1f) {
              *(undefined2 *)((longlong)ppbVar26 + 0x2a) = 0;
              *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
              *(undefined4 *)(ppbVar26 + 8) = 0;
              ppbVar26[7] = (byte *)0x0;
              ppbVar26[4] = (byte *)0x0;
            }
            else {
              iVar7 = uVar15 - 1;
              *(short *)((longlong)ppbVar26 + 0x2a) =
                   ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                   (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
              *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
              *(undefined4 *)(ppbVar26 + 8) = 0;
              ppbVar26[7] = (byte *)0x0;
              ppbVar26[4] = (byte *)0x0;
            }
            break;
          case 4:
            if (((bVar13 & 0x1c) != 4) || (uVar22 = 1, (bVar13 & 2) == 0)) {
              uVar22 = uVar16;
            }
            if (uVar22 == 0) {
              uVar17 = 1;
            }
            else {
              *(undefined4 *)(ppbVar26 + 8) = 0;
              uVar17 = 0xf;
            }
            ppbVar26[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar26 + 0x12) = 0;
            ppbVar26[6] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = uVar17;
            *(uint *)(ppbVar26 + 8) = (uint)(uVar22 != 0);
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
            break;
          case 8:
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar26 + 0x12) = 0;
            ppbVar26[6] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
            ppbVar26[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = 9;
            *(undefined4 *)(ppbVar26 + 8) = 0;
            ppbVar26[4] = (byte *)0x0;
          }
        }
      }
      if ((**ppbVar26 & 4) != 0) {
        if (uStack_140._2_2_ != 0) {
          uVar33 = (ulonglong)*(ushort *)(lVar8 + 0x61 + (longlong)uStack_140._2_2_ * 2);
        }
        psVar11 = (short *)(pbVar31 + uVar33);
        ppbVar26[9] = (byte *)psVar11;
        sVar6 = *psVar11;
        ppbVar26[10] = (byte *)(psVar11 + 1);
        *(short *)(ppbVar26 + 0xb) = (sVar6 + 1) * 2;
      }
      lVar8 = lStack_1c8;
      if (ppbVar26[1] != (byte *)0x0) {
        func_0x(ppbVar26[1],ppbVar26);
        lVar8 = lStack_1c8;
      }
    }
    else {
      ppbVar26 = (byte **)0x0;
    }
    uVar16 = 0;
    uVar22 = (uint)*(ushort *)(lVar8 + 0xe);
    pbStack_100 = (byte *)((ulonglong)*(ushort *)(lVar8 + (0xfff - (longlong)iStack_1d8) * 2) +
                          lVar8);
    if ((*pbStack_100 & 1) == 0) {
      sStack_108 = 0;
      uStack_104 = 0;
      uStack_e2 = 0;
      uStack_e0 = 0;
      switch(*pbStack_100 & 0xe) {
      default:
        uVar22 = (uint)*(ushort *)(pbStack_100 + 2);
        if (0x1f9d < *(ushort *)(pbStack_100 + 2) - 1) {
          func_0x(pbStack_100,6);
        }
        break;
      case 4:
        uVar22 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar22 = 1;
      }
      uStack_f8 = (byte **)CONCAT44(uStack_f8._4_4_,uVar22);
      uStack_ea = (undefined2)(lVar8 + 0x2000);
      uStack_e8 = (undefined6)((ulonglong)(lVar8 + 0x2000) >> 0x10);
      ppbVar26 = (byte **)(ulonglong)uVar22;
      uVar16 = uStack_104;
    }
    else {
      sStack_108 = 1;
      bVar13 = *pbStack_100;
      switch(bVar13 & 0x1c) {
      default:
        if ((char)pbStack_100[1] < '\0') {
          uStack_106 = (*(ushort *)(pbStack_100 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_100 + 1) >> 8;
          uStack_f0._0_2_ = 3;
          sVar6 = 3;
        }
        else {
          uStack_106 = (ushort)pbStack_100[1];
          uStack_f0._0_2_ = 2;
          sVar6 = 2;
        }
        uStack_ec = ((ushort)(uStack_106 + 1) >> 1) + sVar6;
        if (uStack_106 < 0x1f) {
          uStack_f0._2_2_ = 0;
          uStack_104 = 0;
          uStack_d8 = 0;
        }
        else {
          iVar7 = uStack_106 - 1;
          uStack_104 = 0;
          uStack_d8 = 0;
          uStack_f0._2_2_ =
               ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
               (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
        }
        break;
      case 4:
        if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
          uVar16 = 0xf;
          uStack_f0._0_2_ = 0;
          uStack_f0._2_2_ = 0;
          uStack_ec = 0;
          uStack_ea = 0;
          uStack_104 = 0xf;
          uStack_106 = 0;
          uStack_e8 = 0;
          uStack_e2 = 0;
          uStack_d8 = 1;
        }
        else {
          uStack_f0._0_2_ = 0;
          uStack_f0._2_2_ = 0;
          uStack_ec = 0;
          uStack_ea = 0;
          uVar16 = 1;
          uStack_106 = 0;
          uStack_e8 = 0;
          uStack_e2 = 0;
          uStack_104 = 1;
          uStack_d8 = 0;
        }
        break;
      case 8:
        uVar16 = 9;
        uStack_f0._0_2_ = 0;
        uStack_f0._2_2_ = 0;
        uStack_ec = 0;
        uStack_ea = 0;
        uStack_104 = 9;
        uStack_106 = 0;
        uStack_e8 = 0;
        uStack_e2 = 0;
        uStack_d8 = 0;
      }
      lVar24 = lVar8 + 0x2000;
      uStack_e0 = (undefined2)lVar24;
      uStack_de = (undefined2)((ulonglong)lVar24 >> 0x10);
      uStack_dc = (ushort)((ulonglong)lVar24 >> 0x20);
      uStack_da = (undefined2)((ulonglong)lVar24 >> 0x30);
      uStack_f8 = ppbVar26;
    }
    if (sStack_108 == 0) {
      if (uVar16 == 0) {
        uVar16 = (uint)ppbVar26;
        uVar33 = (ulonglong)ppbVar26 & 0xffffffff;
        uStack_106 = 0;
        if ((*pbStack_100 & 0x10) != 0) {
          uVar16 = uVar16 + 2 +
                   (*(ushort *)(pbStack_100 + ((ulonglong)ppbVar26 & 0xffffffff)) + 7 >> 3);
          uVar33 = (ulonglong)uVar16;
        }
        uStack_f8 = (byte **)CONCAT44(uVar16,(undefined4)uStack_f8);
        if ((*pbStack_100 & 0x20) == 0) {
          uStack_ec = 0;
          uStack_104 = (uint)uVar33;
          uStack_f0 = (uint)uVar33;
        }
        else {
          puVar27 = (ushort *)(pbStack_100 + uVar33);
          uStack_ec = *puVar27;
          if (uStack_ec == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar24 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar24 != 0)) &&
               ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                (*(char *)(lVar24 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_298 = (short *)0x0;
                (*_DAT_)(1,0x12b8068,0x13d7d38,0x80f);
              }
            }
            func_0x(pbStack_100,3);
          }
          uStack_f0 = uStack_f8._4_4_ + 2 + (uint)uStack_ec * 2;
          if (0x1f9e < uStack_f0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar24 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar24 != 0 &&
                ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                 (*(char *)(lVar24 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_298 = (short *)0x0;
                (*_DAT_)(1,0x12b8068,0x13d7d38,0x816);
              }
            }
            func_0x(pbStack_100,4);
          }
          uVar25 = (ulonglong)uStack_f0;
          uStack_104 = puVar27[uStack_ec] & 0x7fff;
          uVar33 = (ulonglong)uStack_104;
          if (uStack_104 < uStack_f0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar24 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar24 != 0)) &&
               ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                (*(char *)(lVar24 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_298 = (short *)0x0;
                (*_DAT_)(1,0x12b8068,0x13d7d38,0x81d);
              }
            }
            func_0x(pbStack_100,4);
            uVar25 = (ulonglong)uStack_f0;
            uVar33 = (ulonglong)uStack_104;
          }
          do {
            if (-1 < (short)puVar27[(ulonglong)(uStack_ec - 1) + 1]) break;
            uVar28 = uVar25;
            if (((uStack_ec != 1) &&
                (uVar28 = (ulonglong)
                          (*(ushort *)
                            (pbStack_100 +
                            (ulonglong)uStack_ec * 2 + (((ulonglong)uStack_f8 >> 0x20) - 2)) &
                          0x7fff),
                (*(ushort *)
                  (pbStack_100 + (ulonglong)uStack_ec * 2 + (((ulonglong)uStack_f8 >> 0x20) - 2)) &
                0x7fff) < (uint)uVar25)) ||
               ((*(ushort *)
                  (pbStack_100 + (ulonglong)uStack_ec * 2 + ((ulonglong)uStack_f8 >> 0x20)) & 0x7fff
                ) < (uint)uVar28)) {
              func_0x(pbStack_100,7);
              uVar25 = (ulonglong)uStack_f0;
              uVar33 = (ulonglong)uStack_104;
            }
            uVar16 = (uint)uVar33;
            if (((uint)uVar28 < (uint)uVar25) || (uVar16 < (uint)uVar28)) goto code_r0x00101439;
            if (*(ushort *)(pbStack_100 + uVar28) == 5) {
              uStack_106 = uStack_106 | 2;
              uStack_ec = uStack_ec - 1;
              uStack_de = (undefined2)uVar28;
              if ((*(ushort *)(pbStack_100 + (uVar28 & 0xffff) + 2) & 0x4000) == 0) {
                uStack_dc = uStack_dc & 0xc7ff;
              }
              else {
                uStack_dc = uStack_dc ^
                            (uStack_dc ^ *(ushort *)(pbStack_100 + (uVar28 & 0xffff) + 2)) & 0x3800;
              }
              uStack_dc = (uStack_dc ^ *(ushort *)(pbStack_100 + (uVar28 & 0xffff) + 2)) & 0x7ff ^
                          uStack_dc;
              break;
            }
            if (*(ushort *)(pbStack_100 + uVar28) < 0x400) break;
            uStack_106 = uStack_106 | 1;
            uStack_ec = uStack_ec - 1;
          } while (uStack_ec != 0);
        }
        if ((*pbStack_100 & 0x40) == 0) {
          uStack_e2 = 0;
          uStack_e0 = 0;
        }
        else {
          uStack_e2 = (undefined2)uVar33;
          uStack_e0 = (undefined2)(uVar33 >> 0x10);
          uStack_104 = (int)uVar33 + 0xe;
          puVar30 = (ulonglong *)func_0x(&uStack_106);
          iVar7 = 0;
          uVar33 = *puVar30;
          uVar20 = (ushort)(uVar33 >> 0x30);
          uVar15 = uVar20;
          if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
            uVar15 = uVar20 & 0xdfff;
            if ((uVar33 & 0x4000000000000000) != 0) {
              uVar15 = uVar20 | 0x2000;
            }
          }
          if (uVar15 == 0xfffc) {
            iVar7 = (int)((uVar33 >> 0x20 & 0xffff) >> 5);
          }
          uStack_104 = uStack_104 + iVar7;
          uVar33 = (ulonglong)uStack_104;
        }
        uVar16 = (uint)uVar33;
        if (((byte *)CONCAT62(uStack_e8,uStack_ea) != (byte *)0x0) &&
           ((byte *)CONCAT62(uStack_e8,uStack_ea) < pbStack_100 + uVar33)) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar24 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar24 != 0 &&
               (lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0)) &&
              (*(char *)(lVar24 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x877);
            }
          }
          func_0x(pbStack_100,0x12);
          uVar16 = uStack_104;
        }
        if (0x3f3b < uVar16 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar24 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar24 != 0 &&
              ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
               (*(char *)(lVar24 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x87c);
            }
          }
          func_0x(pbStack_100,5);
          uVar16 = uStack_104;
        }
      }
code_r0x00101439:
      if (uVar16 < 9) {
        bVar13 = *pbStack_100 & 0xe;
joined_r0x0010147e:
        if ((bVar13 == 0) || (bVar13 == 0xc)) {
          uVar16 = 9;
        }
      }
    }
    else {
      if (uVar16 == 0) {
        func_0x(&uStack_106);
        uVar16 = uStack_104;
      }
      if (uVar16 < 9) {
        bVar13 = *pbStack_100 & 0x1c;
        goto joined_r0x0010147e;
      }
    }
    psVar11 = psStack_1e8;
    if (*psStack_1e8 == 0) {
      if (*(int *)(psVar4 + 2) == 0) {
        pbVar31 = *(byte **)(psVar4 + 4);
        uVar22 = *(uint *)(psVar4 + 8);
        uVar33 = (ulonglong)uVar22;
        *puVar29 = 0;
        *(uint *)(psVar4 + 10) = uVar22;
        bVar13 = *pbVar31;
        if ((bVar13 & 0x10) != 0) {
          uVar22 = uVar22 + 2 + (*(ushort *)(pbVar31 + uVar33) + 7 >> 3);
          uVar33 = (ulonglong)uVar22;
          *(uint *)(psVar4 + 10) = uVar22;
          bVar13 = *pbVar31;
        }
        if ((bVar13 & 0x20) == 0) {
          *(int *)(psVar4 + 2) = (int)uVar33;
          psVar4[0xe] = 0;
          *(int *)(psVar4 + 0xc) = (int)uVar33;
        }
        else {
          puVar27 = (ushort *)(pbVar31 + uVar33);
          uVar15 = *puVar27;
          psVar4[0xe] = uVar15;
          if (uVar15 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar24 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar24 != 0)) &&
               ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                (*(char *)(lVar24 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_298 = (short *)0x0;
                (*_DAT_)(1,0x12b8068,0x13d7d38,0x80f);
              }
            }
            func_0x(*(undefined8 *)(psVar4 + 4),3);
            uVar15 = psVar4[0xe];
            uVar33 = (ulonglong)*(uint *)(psVar4 + 10);
          }
          uVar22 = (int)uVar33 + (uVar15 + 1) * 2;
          *(uint *)(psVar4 + 0xc) = uVar22;
          if (0x1f9e < uVar22) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar24 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar24 != 0 &&
                ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                 (*(char *)(lVar24 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_298 = (short *)0x0;
                (*_DAT_)(1,0x12b8068,0x13d7d38,0x816);
              }
            }
            func_0x(*(undefined8 *)(psVar4 + 4),4);
            uVar15 = psVar4[0xe];
            uVar22 = *(uint *)(psVar4 + 0xc);
          }
          uVar21 = puVar27[uVar15] & 0x7fff;
          *(uint *)(psVar4 + 2) = uVar21;
          if (uVar21 < uVar22) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar24 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar24 != 0)) &&
               ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                (*(char *)(lVar24 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_298 = (short *)0x0;
                (*_DAT_)(1,0x12b8068,0x13d7d38,0x81d);
              }
            }
            func_0x(*(undefined8 *)(psVar4 + 4),4);
            uVar15 = psVar4[0xe];
            uVar21 = *(uint *)(psVar4 + 2);
          }
          uVar33 = (ulonglong)uVar21;
          if ((short)puVar27[(ulonglong)(uVar15 - 1) + 1] < 0) {
            pbVar31 = *(byte **)(psVar4 + 4);
            do {
              if (uVar15 == 1) {
                uVar22 = *(uint *)(psVar4 + 0xc);
                uVar25 = (ulonglong)uVar22;
code_r0x00101787:
                if ((*(ushort *)
                      (pbVar31 + (ulonglong)uVar15 * 2 + (ulonglong)*(uint *)(psVar4 + 10)) & 0x7fff
                    ) < (uint)uVar25) goto code_r0x00101794;
              }
              else {
                uVar22 = *(uint *)(psVar4 + 0xc);
                uVar25 = (ulonglong)
                         (*(ushort *)
                           (pbVar31 +
                           (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2)) & 0x7fff
                         );
                if (uVar22 <= (*(ushort *)
                                (pbVar31 +
                                (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2)) &
                              0x7fff)) goto code_r0x00101787;
code_r0x00101794:
                func_0x(pbVar31,7);
                uVar22 = *(uint *)(psVar4 + 0xc);
              }
              if (((uint)uVar25 < uVar22) ||
                 (uVar33 = (ulonglong)*(uint *)(psVar4 + 2), *(uint *)(psVar4 + 2) < (uint)uVar25))
              goto code_r0x00101a80;
              pbVar31 = *(byte **)(psVar4 + 4);
              if (*(ushort *)(pbVar31 + uVar25) == 5) {
                *puVar29 = *puVar29 | 2;
                psVar4[0xe] = psVar4[0xe] + -1;
                psVar4[0x15] = (short)uVar25;
                lVar24 = (uVar25 & 0xffff) + *(longlong *)(psVar4 + 4);
                uVar15 = psVar4[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar24 + 2) >> 0xe & 1) != 0) {
                  uVar15 = *(ushort *)(lVar24 + 2) & 0x3800 | psVar4[0x16] & 0xc7ffU;
                }
                psVar4[0x16] = uVar15;
                psVar4[0x16] = (uVar15 ^ *(ushort *)(lVar24 + 2)) & 0x7ff ^ uVar15;
                uVar33 = (ulonglong)*(uint *)(psStack_1e8 + 2);
                goto code_r0x00101867;
              }
              if (*(ushort *)(pbVar31 + uVar25) < 0x400) goto code_r0x00101867;
              sVar6 = psVar4[0xe];
              *puVar29 = *puVar29 | 1;
              uVar15 = sVar6 - 1;
              psVar4[0xe] = uVar15;
              if (uVar15 == 0) goto code_r0x00101867;
            } while ((short)puVar27[(ulonglong)(uVar15 - 1) + 1] < 0);
          }
          else {
code_r0x00101867:
            pbVar31 = *(byte **)(psVar4 + 4);
          }
        }
        iVar7 = 0;
        if ((*pbVar31 & 0x40) == 0) {
          *(undefined4 *)(psVar4 + 0x13) = 0;
        }
        else {
          *(int *)(psVar4 + 0x13) = (int)uVar33;
          *(int *)(psVar4 + 2) = (int)uVar33 + 0xe;
          puVar30 = (ulonglong *)func_0x(puVar29);
          uVar20 = (ushort)(*puVar30 >> 0x30);
          uVar15 = uVar20;
          if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
            uVar15 = uVar20 & 0xdfff;
            if ((uVar20 >> 0xe & 1) != 0) {
              uVar15 = uVar20 | 0x2000;
            }
          }
          if (uVar15 == 0xfffc) {
            iVar7 = (int)((*puVar30 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(psVar4 + 2) = *(int *)(psVar4 + 2) + iVar7;
          uVar33 = (ulonglong)*(uint *)(psVar4 + 2);
        }
        iVar7 = (int)uVar33;
        if ((*(ulonglong *)(psVar4 + 0xf) != 0) &&
           (*(ulonglong *)(psVar4 + 0xf) < uVar33 + *(longlong *)(psVar4 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar24 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar24 != 0 &&
               (lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0)) &&
              (*(char *)(lVar24 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x877);
            }
          }
          func_0x(*(undefined8 *)(psVar4 + 4),0x12);
          iVar7 = *(int *)(psVar4 + 2);
        }
        if (0x3f3b < iVar7 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar24 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar24 != 0 &&
              ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
               (*(char *)(lVar24 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x87c);
            }
          }
          func_0x(*(undefined8 *)(psVar4 + 4),5);
        }
      }
code_r0x00101a80:
      uVar22 = *(uint *)(psVar4 + 2);
      psVar11 = psStack_1e8;
      if ((uVar22 < 9) &&
         (((**(byte **)(psVar4 + 4) & 0xe) == 0 || ((**(byte **)(psVar4 + 4) & 0xe) == 0xc)))) {
        uVar22 = 9;
      }
    }
    else {
      uVar22 = *(uint *)(psVar4 + 2);
      if (uVar22 == 0) {
        func_0x(puVar29);
        uVar22 = *(uint *)(psVar4 + 2);
      }
      if ((uVar22 < 9) &&
         (((**(byte **)(psVar4 + 4) & 0x1c) == 0 || ((**(byte **)(psVar4 + 4) & 0x1c) == 0xc)))) {
        uVar22 = 9;
      }
    }
    if (uVar16 < uVar22) {
      iVar7 = func_0x(pplStack_1e0,plStack_1d0);
      if (*psVar11 == 0) {
        if (*(int *)(psVar4 + 2) == 0) {
          pbVar31 = *(byte **)(psVar4 + 4);
          uVar22 = *(uint *)(psVar4 + 8);
          uVar33 = (ulonglong)uVar22;
          *puVar29 = 0;
          *(uint *)(psVar4 + 10) = uVar22;
          bVar13 = *pbVar31;
          if ((bVar13 & 0x10) != 0) {
            uVar22 = uVar22 + 2 + (*(ushort *)(pbVar31 + uVar33) + 7 >> 3);
            uVar33 = (ulonglong)uVar22;
            *(uint *)(psVar4 + 10) = uVar22;
            bVar13 = *pbVar31;
          }
          if ((bVar13 & 0x20) == 0) {
            *(int *)(psVar4 + 2) = (int)uVar33;
            psVar4[0xe] = 0;
            *(int *)(psVar4 + 0xc) = (int)uVar33;
          }
          else {
            puVar27 = (ushort *)(pbVar31 + uVar33);
            uVar15 = *puVar27;
            psVar4[0xe] = uVar15;
            if (uVar15 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar8 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar8 != 0)) &&
                 ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
                  (*(char *)(lVar8 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_298 = (short *)0x0;
                  (*_DAT_)(1,0x12b8068,0x13d7d38,0x80f);
                }
              }
              func_0x(*(undefined8 *)(psVar4 + 4),3);
              uVar15 = psVar4[0xe];
              uVar33 = (ulonglong)*(uint *)(psVar4 + 10);
            }
            uVar22 = (int)uVar33 + (uVar15 + 1) * 2;
            *(uint *)(psVar4 + 0xc) = uVar22;
            if (0x1f9e < uVar22) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar8 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar8 != 0 &&
                  ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
                   (*(char *)(lVar8 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_298 = (short *)0x0;
                  (*_DAT_)(1,0x12b8068,0x13d7d38,0x816);
                }
              }
              func_0x(*(undefined8 *)(psVar4 + 4),4);
              uVar15 = psVar4[0xe];
              uVar22 = *(uint *)(psVar4 + 0xc);
            }
            uVar21 = puVar27[uVar15] & 0x7fff;
            *(uint *)(psVar4 + 2) = uVar21;
            if (uVar21 < uVar22) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar8 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar8 != 0)) &&
                 ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
                  (*(char *)(lVar8 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_298 = (short *)0x0;
                  (*_DAT_)(1,0x12b8068,0x13d7d38,0x81d);
                }
              }
              func_0x(*(undefined8 *)(psVar4 + 4),4);
              uVar15 = psVar4[0xe];
              uVar21 = *(uint *)(psVar4 + 2);
            }
            uVar33 = (ulonglong)uVar21;
            if ((short)puVar27[(ulonglong)(uVar15 - 1) + 1] < 0) {
              pbVar31 = *(byte **)(psVar4 + 4);
              do {
                if (uVar15 == 1) {
                  uVar22 = *(uint *)(psVar4 + 0xc);
                  uVar25 = (ulonglong)uVar22;
code_r0x00101de7:
                  if ((*(ushort *)
                        (pbVar31 + (ulonglong)uVar15 * 2 + (ulonglong)*(uint *)(psVar4 + 10)) &
                      0x7fff) < (uint)uVar25) goto code_r0x00101df4;
                }
                else {
                  uVar22 = *(uint *)(psVar4 + 0xc);
                  uVar25 = (ulonglong)
                           (*(ushort *)
                             (pbVar31 +
                             (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2)) &
                           0x7fff);
                  if (uVar22 <= (*(ushort *)
                                  (pbVar31 +
                                  (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2)) &
                                0x7fff)) goto code_r0x00101de7;
code_r0x00101df4:
                  func_0x(pbVar31,7);
                  uVar22 = *(uint *)(psVar4 + 0xc);
                }
                if (((uint)uVar25 < uVar22) ||
                   (uVar33 = (ulonglong)*(uint *)(psVar4 + 2), *(uint *)(psVar4 + 2) < (uint)uVar25)
                   ) goto code_r0x001020e0;
                pbVar31 = *(byte **)(psVar4 + 4);
                if (*(ushort *)(pbVar31 + uVar25) == 5) {
                  *puVar29 = *puVar29 | 2;
                  psVar4[0xe] = psVar4[0xe] + -1;
                  psVar4[0x15] = (short)uVar25;
                  lVar8 = (uVar25 & 0xffff) + *(longlong *)(psVar4 + 4);
                  uVar15 = psVar4[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar8 + 2) >> 0xe & 1) != 0) {
                    uVar15 = *(ushort *)(lVar8 + 2) & 0x3800 | psVar4[0x16] & 0xc7ffU;
                  }
                  psVar4[0x16] = uVar15;
                  psVar4[0x16] = (uVar15 ^ *(ushort *)(lVar8 + 2)) & 0x7ff ^ uVar15;
                  uVar33 = (ulonglong)*(uint *)(psStack_1e8 + 2);
                  goto code_r0x00101ec7;
                }
                if (*(ushort *)(pbVar31 + uVar25) < 0x400) goto code_r0x00101ec7;
                sVar6 = psVar4[0xe];
                *puVar29 = *puVar29 | 1;
                uVar15 = sVar6 - 1;
                psVar4[0xe] = uVar15;
                if (uVar15 == 0) goto code_r0x00101ec7;
              } while ((short)puVar27[(ulonglong)(uVar15 - 1) + 1] < 0);
            }
            else {
code_r0x00101ec7:
              pbVar31 = *(byte **)(psVar4 + 4);
            }
          }
          iVar18 = 0;
          if ((*pbVar31 & 0x40) == 0) {
            *(undefined4 *)(psVar4 + 0x13) = 0;
          }
          else {
            *(int *)(psVar4 + 0x13) = (int)uVar33;
            *(int *)(psVar4 + 2) = (int)uVar33 + 0xe;
            puVar30 = (ulonglong *)func_0x(puVar29);
            uVar20 = (ushort)(*puVar30 >> 0x30);
            uVar15 = uVar20;
            if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
              uVar15 = uVar20 & 0xdfff;
              if ((uVar20 >> 0xe & 1) != 0) {
                uVar15 = uVar20 | 0x2000;
              }
            }
            if (uVar15 == 0xfffc) {
              iVar18 = (int)((*puVar30 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar4 + 2) = *(int *)(psVar4 + 2) + iVar18;
            uVar33 = (ulonglong)*(uint *)(psVar4 + 2);
          }
          iVar18 = (int)uVar33;
          if ((*(ulonglong *)(psVar4 + 0xf) != 0) &&
             (*(ulonglong *)(psVar4 + 0xf) < uVar33 + *(longlong *)(psVar4 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar8 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar8 != 0 &&
                 (lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0)) &&
                (*(char *)(lVar8 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_298 = (short *)0x0;
                (*_DAT_)(1,0x12b8068,0x13d7d38,0x877);
              }
            }
            func_0x(*(undefined8 *)(psVar4 + 4),0x12);
            iVar18 = *(int *)(psVar4 + 2);
          }
          if (0x3f3b < iVar18 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar8 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar8 != 0 &&
                ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
                 (*(char *)(lVar8 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_298 = (short *)0x0;
                (*_DAT_)(1,0x12b8068,0x13d7d38,0x87c);
              }
            }
            func_0x(*(undefined8 *)(psVar4 + 4),5);
          }
        }
code_r0x001020e0:
        uVar22 = *(uint *)(psVar4 + 2);
        psVar11 = psStack_1e8;
        if ((uVar22 < 9) &&
           (((**(byte **)(psVar4 + 4) & 0xe) == 0 || ((**(byte **)(psVar4 + 4) & 0xe) == 0xc)))) {
          uVar22 = 9;
        }
      }
      else {
        uVar22 = *(uint *)(psVar4 + 2);
        if (uVar22 == 0) {
          func_0x(puVar29);
          uVar22 = *(uint *)(psVar4 + 2);
        }
        if ((uVar22 < 9) &&
           (((**(byte **)(psVar4 + 4) & 0x1c) == 0 || ((**(byte **)(psVar4 + 4) & 0x1c) == 0xc)))) {
          uVar22 = 9;
        }
      }
      lVar8 = lStack_1c8;
      if (iVar7 + uVar16 < uVar22) {
        if (*psVar11 == 0) {
          if (*(int *)(psVar4 + 2) == 0) {
            pbVar31 = *(byte **)(psVar4 + 4);
            uVar16 = *(uint *)(psVar4 + 8);
            uVar33 = (ulonglong)uVar16;
            *puVar29 = 0;
            *(uint *)(psVar4 + 10) = uVar16;
            bVar13 = *pbVar31;
            if ((bVar13 & 0x10) != 0) {
              uVar16 = uVar16 + 2 + (*(ushort *)(pbVar31 + uVar33) + 7 >> 3);
              uVar33 = (ulonglong)uVar16;
              *(uint *)(psVar4 + 10) = uVar16;
              bVar13 = *pbVar31;
            }
            if ((bVar13 & 0x20) == 0) {
              *(int *)(psVar4 + 2) = (int)uVar33;
              psVar4[0xe] = 0;
              *(int *)(psVar4 + 0xc) = (int)uVar33;
            }
            else {
              puVar27 = (ushort *)(pbVar31 + uVar33);
              uVar15 = *puVar27;
              psVar4[0xe] = uVar15;
              if (uVar15 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar32 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar32 != 0)) &&
                   ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
                    (*(char *)(lVar32 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_298 = (short *)0x0;
                    (*_DAT_)(1,0x12b8068,0x13d7d38,0x80f);
                  }
                }
                func_0x(*(undefined8 *)(psVar4 + 4),3);
                uVar15 = psVar4[0xe];
                uVar33 = (ulonglong)*(uint *)(psVar4 + 10);
              }
              uVar16 = (int)uVar33 + (uVar15 + 1) * 2;
              *(uint *)(psVar4 + 0xc) = uVar16;
              if (0x1f9e < uVar16) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar32 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar32 != 0 &&
                    ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
                     (*(char *)(lVar32 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_298 = (short *)0x0;
                    (*_DAT_)(1,0x12b8068,0x13d7d38,0x816);
                  }
                }
                func_0x(*(undefined8 *)(psVar4 + 4),4);
                uVar15 = psVar4[0xe];
                uVar16 = *(uint *)(psVar4 + 0xc);
              }
              uVar22 = puVar27[uVar15] & 0x7fff;
              *(uint *)(psVar4 + 2) = uVar22;
              if (uVar22 < uVar16) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar32 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar32 != 0)) &&
                   ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
                    (*(char *)(lVar32 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_298 = (short *)0x0;
                    (*_DAT_)(1,0x12b8068,0x13d7d38,0x81d);
                  }
                }
                func_0x(*(undefined8 *)(psVar4 + 4),4);
                uVar15 = psVar4[0xe];
                uVar22 = *(uint *)(psVar4 + 2);
              }
              uVar33 = (ulonglong)uVar22;
              if ((short)puVar27[(ulonglong)(uVar15 - 1) + 1] < 0) {
                pbVar31 = *(byte **)(psVar4 + 4);
                do {
                  if (uVar15 == 1) {
                    uVar16 = *(uint *)(psVar4 + 0xc);
                    uVar25 = (ulonglong)uVar16;
code_r0x00102437:
                    if ((*(ushort *)
                          (pbVar31 + (ulonglong)uVar15 * 2 + (ulonglong)*(uint *)(psVar4 + 10)) &
                        0x7fff) < (uint)uVar25) goto code_r0x00102444;
                  }
                  else {
                    uVar16 = *(uint *)(psVar4 + 0xc);
                    uVar25 = (ulonglong)
                             (*(ushort *)
                               (pbVar31 +
                               (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2)) &
                             0x7fff);
                    if (uVar16 <= (*(ushort *)
                                    (pbVar31 +
                                    (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2))
                                  & 0x7fff)) goto code_r0x00102437;
code_r0x00102444:
                    func_0x(pbVar31,7);
                    uVar16 = *(uint *)(psVar4 + 0xc);
                  }
                  if (((uint)uVar25 < uVar16) ||
                     (uVar33 = (ulonglong)*(uint *)(psVar4 + 2),
                     *(uint *)(psVar4 + 2) < (uint)uVar25)) goto code_r0x00102730;
                  pbVar31 = *(byte **)(psVar4 + 4);
                  if (*(ushort *)(pbVar31 + uVar25) == 5) {
                    *puVar29 = *puVar29 | 2;
                    psVar4[0xe] = psVar4[0xe] + -1;
                    psVar4[0x15] = (short)uVar25;
                    lVar32 = (uVar25 & 0xffff) + *(longlong *)(psVar4 + 4);
                    uVar15 = psVar4[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar32 + 2) >> 0xe & 1) != 0) {
                      uVar15 = *(ushort *)(lVar32 + 2) & 0x3800 | psVar4[0x16] & 0xc7ffU;
                    }
                    psVar4[0x16] = uVar15;
                    psVar4[0x16] = (uVar15 ^ *(ushort *)(lVar32 + 2)) & 0x7ff ^ uVar15;
                    uVar33 = (ulonglong)*(uint *)(psStack_1e8 + 2);
                    goto code_r0x00102517;
                  }
                  if (*(ushort *)(pbVar31 + uVar25) < 0x400) goto code_r0x00102517;
                  sVar6 = psVar4[0xe];
                  *puVar29 = *puVar29 | 1;
                  uVar15 = sVar6 - 1;
                  psVar4[0xe] = uVar15;
                  if (uVar15 == 0) goto code_r0x00102517;
                } while ((short)puVar27[(ulonglong)(uVar15 - 1) + 1] < 0);
              }
              else {
code_r0x00102517:
                pbVar31 = *(byte **)(psVar4 + 4);
              }
            }
            iVar7 = 0;
            if ((*pbVar31 & 0x40) == 0) {
              *(undefined4 *)(psVar4 + 0x13) = 0;
            }
            else {
              *(int *)(psVar4 + 0x13) = (int)uVar33;
              *(int *)(psVar4 + 2) = (int)uVar33 + 0xe;
              puVar30 = (ulonglong *)func_0x(puVar29);
              uVar20 = (ushort)(*puVar30 >> 0x30);
              uVar15 = uVar20;
              if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
                uVar15 = uVar20 & 0xdfff;
                if ((uVar20 >> 0xe & 1) != 0) {
                  uVar15 = uVar20 | 0x2000;
                }
              }
              if (uVar15 == 0xfffc) {
                iVar7 = (int)((*puVar30 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar4 + 2) = *(int *)(psVar4 + 2) + iVar7;
              uVar33 = (ulonglong)*(uint *)(psVar4 + 2);
            }
            iVar7 = (int)uVar33;
            if ((*(ulonglong *)(psVar4 + 0xf) != 0) &&
               (*(ulonglong *)(psVar4 + 0xf) < uVar33 + *(longlong *)(psVar4 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar32 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                   lVar32 != 0 && (lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0)) &&
                  (*(char *)(lVar32 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  uStack_298 = (short *)0x0;
                  (*_DAT_)(1,0x12b8068,0x13d7d38,0x877);
                }
              }
              func_0x(*(undefined8 *)(psVar4 + 4),0x12);
              iVar7 = *(int *)(psVar4 + 2);
            }
            if (0x3f3b < iVar7 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar32 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar32 != 0 &&
                  ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
                   (*(char *)(lVar32 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  uStack_298 = (short *)0x0;
                  (*_DAT_)(1,0x12b8068,0x13d7d38,0x87c);
                }
              }
              func_0x(*(undefined8 *)(psVar4 + 4),5);
            }
          }
code_r0x00102730:
          uVar16 = *(uint *)(psVar4 + 2);
          if ((8 < uVar16) ||
             (((**(byte **)(psVar4 + 4) & 0xe) != 0 && ((**(byte **)(psVar4 + 4) & 0xe) != 0xc))))
          goto code_r0x0010392f;
        }
        else {
          uVar16 = *(uint *)(psVar4 + 2);
          if (uVar16 == 0) {
            func_0x(puVar29);
            uVar16 = *(uint *)(psVar4 + 2);
          }
          uStack_228 = uVar16;
          if ((uVar16 < 9) &&
             (((**(byte **)(psVar4 + 4) & 0x1c) == 0 || ((**(byte **)(psVar4 + 4) & 0x1c) == 0xc))))
          {
            uStack_228 = 9;
            uVar16 = uStack_228;
            goto code_r0x0010392f;
          }
        }
        uVar16 = uStack_228;
        goto code_r0x0010392f;
      }
    }
    ppbVar26 = ppbStack_168;
    plVar10 = plStack_1d0;
    if ((*(char *)(lVar32 + 0x1cde) != '\0') || (*(char *)(lVar32 + 0x1cd9) != '\0')) {
      *(longlong *)(lVar32 + 0x1a8) = *(longlong *)(lVar32 + 0x1a8) + 1;
    }
    if (((sStack_108 == 0) || (uStack_f8 == (byte **)0x0)) || (*uStack_f8 == (byte *)0x0)) {
      uVar17 = 0;
    }
    else {
      uVar17 = 1;
    }
    puVar12 = (undefined8 *)0x0;
    uStack_258 = &uStack_158;
    uStack_248 = 0;
    uStack_160 = *(undefined4 *)(ppbStack_168 + 1);
    uStack_15c = *(undefined4 *)((longlong)ppbStack_168 + 0xc);
    uStack_250 = 0;
    piStack_260 = &iStack_190;
    plStack_268 = (longlong *)((ulonglong)plStack_268 & 0xffffffff00000000);
    uStack_270 = 0;
    uStack_278 = 0;
    uStack_280 = CONCAT44(uStack_280._4_4_,uVar17);
    uStack_288 = 1;
    uStack_298 = &sStack_108;
    uStack_290 = 0;
    ppbStack_168 = (byte **)*ppbStack_168;
    func_0x(&ppbStack_168,lStack_148,plStack_1d0,lVar8);
    psVar11 = psStack_1e8;
    if (*psStack_1e8 == 0) {
      func_0x(puVar29,&uStack_158);
    }
    else {
      if (*(int *)(psVar4 + 2) == 0) {
        func_0x(puVar29);
      }
      func_0x(puVar29);
      puVar19 = puVar12;
      if ((**(byte **)(psVar4 + 4) & 2) != 0) {
        puVar19 = (undefined8 *)(*(byte **)(psVar4 + 4) + *(uint *)(psVar4 + 0x18));
      }
      *puVar19 = uStack_158;
      *(undefined4 *)(psVar4 + 2) = 0;
      func_0x(puVar29);
    }
    if (*psVar11 == 0) {
      puVar12 = (undefined8 *)func_0x();
    }
    else {
      func_0x(puVar29);
      if ((**(byte **)(psVar4 + 4) & 2) != 0) {
        puVar12 = (undefined8 *)(*(byte **)(psVar4 + 4) + *(uint *)(psVar4 + 0x18));
      }
    }
    if (((iStack_190 == 2) &&
        (lVar32 = *(longlong *)(*(longlong *)(param_2 + 8) + 0x488), lVar32 != 0)) &&
       ((*pcRam0000000000f35638 != '\0' && ((bRam00000000019d79f0 & 2) == 0)))) {
      if (*(longlong *)(lVar32 + 0x20) != 0) {
        lVar24 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar8 = *(longlong *)(lVar24 + 0x100);
        if (lVar8 == 0) {
          (*pcRam0000000000f35ee0)(0);
          lVar8 = *(longlong *)(lVar24 + 0x100);
        }
        if (*(longlong *)(lVar8 + 0x260) == 0) {
          uVar33 = 0;
        }
        else {
          uVar33 = (ulonglong)*(uint *)(*(longlong *)(lVar8 + 0x260) + 0xe68);
        }
        if ((uint)uVar33 < *(uint *)(lRam00000000019d8610 + 8)) {
          lVar32 = *(longlong *)(*(longlong *)(lVar32 + 0x20) + uVar33 * 8);
          *(longlong *)(lVar32 + 0x140) = *(longlong *)(lVar32 + 0x140) + 1;
          goto code_r0x001029be;
        }
      }
      LOCK();
      plVar23 = (longlong *)(*(longlong *)(lVar32 + 0x18) + 0x140);
      *plVar23 = *plVar23 + 1;
      UNLOCK();
    }
  }
code_r0x001029be:
  psVar4 = psStack_1e8;
  bVar13 = *(byte *)ppbVar26;
  puVar29 = (ushort *)(psStack_1e8 + 1);
  if (*psStack_1e8 == 0) {
    if (*(int *)(psStack_1e8 + 2) == 0) {
      pbVar31 = *(byte **)(psStack_1e8 + 4);
      uVar16 = *(uint *)(psStack_1e8 + 8);
      uVar33 = (ulonglong)uVar16;
      *puVar29 = 0;
      *(uint *)(psStack_1e8 + 10) = uVar16;
      bVar14 = *pbVar31;
      if ((bVar14 & 0x10) != 0) {
        uVar16 = uVar16 + 2 + (*(ushort *)(pbVar31 + uVar33) + 7 >> 3);
        uVar33 = (ulonglong)uVar16;
        *(uint *)(psStack_1e8 + 10) = uVar16;
        bVar14 = *pbVar31;
      }
      if ((bVar14 & 0x20) == 0) {
        *(int *)(psStack_1e8 + 2) = (int)uVar33;
        psStack_1e8[0xe] = 0;
        *(int *)(psStack_1e8 + 0xc) = (int)uVar33;
      }
      else {
        puVar27 = (ushort *)(pbVar31 + uVar33);
        uVar15 = *puVar27;
        psStack_1e8[0xe] = uVar15;
        if (uVar15 == 0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar32 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar32 != 0 &&
              ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
               (*(char *)(lVar32 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar4 + 4),3);
          uVar15 = psVar4[0xe];
          uVar33 = (ulonglong)*(uint *)(psVar4 + 10);
        }
        uVar16 = (int)uVar33 + (uVar15 + 1) * 2;
        *(uint *)(psVar4 + 0xc) = uVar16;
        if (0x1f9e < uVar16) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar32 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar32 != 0)) &&
             ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
              (*(char *)(lVar32 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar4 + 4),4);
          uVar15 = psVar4[0xe];
          uVar16 = *(uint *)(psVar4 + 0xc);
        }
        uVar22 = puVar27[uVar15] & 0x7fff;
        *(uint *)(psVar4 + 2) = uVar22;
        if (uVar22 < uVar16) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar32 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar32 != 0 &&
              ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
               (*(char *)(lVar32 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar4 + 4),4);
          uVar15 = psVar4[0xe];
          uVar22 = *(uint *)(psVar4 + 2);
        }
        uVar33 = (ulonglong)uVar22;
        if ((short)puVar27[(ulonglong)(uVar15 - 1) + 1] < 0) {
          pbVar31 = *(byte **)(psVar4 + 4);
          do {
            if (uVar15 == 1) {
              uVar16 = *(uint *)(psVar4 + 0xc);
              uVar22 = uVar16;
LAB_:
              if ((*(ushort *)(pbVar31 + (ulonglong)uVar15 * 2 + (ulonglong)*(uint *)(psVar4 + 10))
                  & 0x7fff) < uVar16) goto LAB_;
            }
            else {
              uVar22 = *(uint *)(psVar4 + 0xc);
              uVar16 = *(ushort *)
                        (pbVar31 + (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2))
                       & 0x7fff;
              if (uVar22 <= uVar16) goto LAB_;
LAB_:
              func_0x(pbVar31,7);
              uVar22 = *(uint *)(psVar4 + 0xc);
            }
            if ((uVar16 < uVar22) ||
               (uVar33 = (ulonglong)*(uint *)(psVar4 + 2), *(uint *)(psVar4 + 2) < uVar16))
            goto LAB_;
            pbVar31 = *(byte **)(psVar4 + 4);
            if (*(ushort *)(pbVar31 + uVar16) == 5) {
              *puVar29 = *puVar29 | 2;
              psVar4[0xe] = psVar4[0xe] + -1;
              psVar4[0x15] = (short)uVar16;
              lVar32 = (ulonglong)(uVar16 & 0xffff) + *(longlong *)(psVar4 + 4);
              uVar15 = psVar4[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar32 + 2) >> 0xe & 1) != 0) {
                uVar15 = *(ushort *)(lVar32 + 2) & 0x3800 | psVar4[0x16] & 0xc7ffU;
              }
              psVar4[0x16] = uVar15;
              psVar4[0x16] = (uVar15 ^ *(ushort *)(lVar32 + 2)) & 0x7ff ^ uVar15;
              uVar33 = (ulonglong)*(uint *)(psVar4 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar31 + uVar16) < 0x400) goto LAB_;
            sVar6 = psVar4[0xe];
            *puVar29 = *puVar29 | 1;
            uVar15 = sVar6 - 1;
            psVar4[0xe] = uVar15;
            if (uVar15 == 0) goto LAB_;
          } while ((short)puVar27[(ulonglong)(uVar15 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar31 = *(byte **)(psVar4 + 4);
        }
      }
      iVar7 = 0;
      if ((*pbVar31 & 0x40) == 0) {
        *(undefined4 *)(psVar4 + 0x13) = 0;
      }
      else {
        *(int *)(psVar4 + 0x13) = (int)uVar33;
        *(int *)(psVar4 + 2) = (int)uVar33 + 0xe;
        puVar30 = (ulonglong *)func_0x(puVar29);
        uVar20 = (ushort)(*puVar30 >> 0x30);
        uVar15 = uVar20;
        if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
          uVar15 = uVar20 & 0xdfff;
          if ((uVar20 >> 0xe & 1) != 0) {
            uVar15 = uVar20 | 0x2000;
          }
        }
        if (uVar15 == 0xfffc) {
          iVar7 = (int)((*puVar30 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar4 + 2) = *(int *)(psVar4 + 2) + iVar7;
        uVar33 = (ulonglong)*(uint *)(psVar4 + 2);
      }
      iVar7 = (int)uVar33;
      if ((*(ulonglong *)(psVar4 + 0xf) != 0) &&
         (*(ulonglong *)(psVar4 + 0xf) < uVar33 + *(longlong *)(psVar4 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar32 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar32 != 0 &&
             (lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0)) &&
            (*(char *)(lVar32 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_298 = (short *)0x0;
            (*_DAT_)(1,0x12b8068,0x13d7d38,0x877);
          }
        }
        func_0x(*(undefined8 *)(psVar4 + 4),0x12);
        iVar7 = *(int *)(psVar4 + 2);
      }
      if (0x3f3b < iVar7 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar32 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar32 != 0 &&
            ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
             (*(char *)(lVar32 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_298 = (short *)0x0;
            (*_DAT_)(1,0x12b8068,0x13d7d38,0x87c);
          }
        }
        func_0x(*(undefined8 *)(psVar4 + 4),5);
      }
    }
LAB_:
    uVar16 = *(uint *)(psVar4 + 2);
    if (uVar16 < 9) {
      bVar14 = **(byte **)(psVar4 + 4) & 0xe;
joined_r0x00102ff2:
      if ((bVar14 == 0) || (bVar14 == 0xc)) {
        uVar16 = 9;
      }
    }
  }
  else {
    uVar16 = *(uint *)(psStack_1e8 + 2);
    if (uVar16 == 0) {
      func_0x(puVar29);
      uVar16 = *(uint *)(psVar4 + 2);
    }
    if (uVar16 < 9) {
      bVar14 = **(byte **)(psVar4 + 4) & 0x1c;
      goto joined_r0x00102ff2;
    }
  }
  lVar32 = lStack_1c8;
  iVar7 = iStack_1d8;
  uVar25 = 0;
  uStack_21c = 0;
  pbStack_202 = (byte *)0x0;
  uVar33 = 0;
  uStack_1f6 = 0;
  uStack_1f4 = 0;
  uStack_1f2 = 0;
  pbStack_218 = (byte *)((ulonglong)*(ushort *)(lStack_1c8 + (0xfff - (longlong)iStack_1d8) * 2) +
                        lStack_1c8);
  uStack_210 = 0;
  if ((*pbStack_218 & 1) == 0) {
    sStack_220 = 0;
    uStack_1fa = 0;
    uStack_1f8 = 0;
    uVar28 = (ulonglong)*(ushort *)(lStack_1c8 + 0xe);
    switch(*pbStack_218 & 0xe) {
    default:
      uVar15 = *(ushort *)(pbStack_218 + 2);
      uVar28 = (ulonglong)uVar15;
      uVar25 = uVar33;
      if (0x1f9d < uVar15 - 1) {
        func_0x(pbStack_218,6);
        uVar25 = (ulonglong)uStack_21c;
      }
      break;
    case 4:
      uVar28 = 9;
      uVar25 = uVar33;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar28 = 1;
      uVar25 = uVar33;
    }
    uVar33 = uVar25;
    uVar25 = uVar28;
    pbStack_202 = (byte *)(lVar32 + 0x2000);
    uStack_210 = CONCAT44(uStack_210._4_4_,(int)uVar25);
  }
  else {
    sStack_220 = 1;
    bVar14 = *pbStack_218;
    switch(bVar14 & 0x1c) {
    default:
      if ((char)pbStack_218[1] < '\0') {
        uStack_21e = (*(ushort *)(pbStack_218 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_218 + 1) >> 8;
        uVar15 = 3;
        uStack_1d4 = CONCAT22(uStack_1d4._2_2_,3);
      }
      else {
        uStack_21e = (ushort)pbStack_218[1];
        uVar15 = 2;
      }
      uStack_204 = ((ushort)(uStack_21e + 1) >> 1) + (short)uStack_1d4;
      if (uStack_21e < 0x1f) {
        lVar32 = lStack_1c8 + 0x2000;
        uStack_208 = (uint)uVar15;
        uStack_1f8 = (undefined2)lVar32;
        uStack_1f6 = (undefined2)((ulonglong)lVar32 >> 0x10);
        uStack_1f4 = (ushort)((ulonglong)lVar32 >> 0x20);
        uStack_1f2 = (undefined2)((ulonglong)lVar32 >> 0x30);
        uStack_1f0 = 0;
        uVar33 = uVar25;
      }
      else {
        iVar18 = uStack_21e - 1;
        uStack_1f0 = 0;
        uVar25 = 0;
        lVar32 = lStack_1c8 + 0x2000;
        uStack_1f8 = (undefined2)lVar32;
        uStack_1f6 = (undefined2)((ulonglong)lVar32 >> 0x10);
        uStack_1f4 = (ushort)((ulonglong)lVar32 >> 0x20);
        uStack_1f2 = (undefined2)((ulonglong)lVar32 >> 0x30);
        uStack_208 = CONCAT22(((short)(iVar18 / 0x1e) + (short)(iVar18 >> 0x1f)) -
                              (short)((longlong)iVar18 * 0x88888889 >> 0x3f),uVar15);
      }
      break;
    case 4:
      if (((bVar14 & 0x1c) == 4) && ((bVar14 & 2) != 0)) {
        uVar33 = 0xf;
        uStack_208 = 0;
        lVar32 = lStack_1c8 + 0x2000;
        uStack_21c = 0xf;
        uStack_1f8 = (undefined2)lVar32;
        uStack_1f6 = (undefined2)((ulonglong)lVar32 >> 0x10);
        uStack_1f4 = (ushort)((ulonglong)lVar32 >> 0x20);
        uStack_1f2 = (undefined2)((ulonglong)lVar32 >> 0x30);
        uVar25 = 0;
        uStack_21e = 0;
        uStack_204 = 0;
        uStack_1fa = 0;
        uStack_1f0 = 1;
      }
      else {
        lVar32 = lStack_1c8 + 0x2000;
        uStack_208 = 0;
        uStack_1f8 = (undefined2)lVar32;
        uStack_1f6 = (undefined2)((ulonglong)lVar32 >> 0x10);
        uStack_1f4 = (ushort)((ulonglong)lVar32 >> 0x20);
        uStack_1f2 = (undefined2)((ulonglong)lVar32 >> 0x30);
        uVar33 = 1;
        uStack_21e = 0;
        uVar25 = 0;
        uStack_204 = 0;
        uStack_1fa = 0;
        uStack_21c = 1;
        uStack_1f0 = 0;
      }
      break;
    case 8:
      uVar33 = 9;
      uStack_208 = 0;
      lVar32 = lStack_1c8 + 0x2000;
      uStack_21c = 9;
      uStack_1f8 = (undefined2)lVar32;
      uStack_1f6 = (undefined2)((ulonglong)lVar32 >> 0x10);
      uStack_1f4 = (ushort)((ulonglong)lVar32 >> 0x20);
      uStack_1f2 = (undefined2)((ulonglong)lVar32 >> 0x30);
      uVar25 = 0;
      uStack_21e = 0;
      uStack_204 = 0;
      uStack_1fa = 0;
      uStack_1f0 = 0;
    }
  }
  uVar22 = (uint)uVar33;
  if (sStack_220 == 0) {
    if (uVar22 == 0) {
      uVar22 = (uint)uVar25;
      uStack_21e = 0;
      uVar33 = uVar25;
      if ((*pbStack_218 & 0x10) != 0) {
        uVar22 = uVar22 + 2 + (*(ushort *)(pbStack_218 + uVar25) + 7 >> 3);
        uVar33 = (ulonglong)uVar22;
      }
      uStack_210 = CONCAT44(uVar22,(undefined4)uStack_210);
      if ((*pbStack_218 & 0x20) == 0) {
        uStack_204 = 0;
        uStack_21c = (uint)uVar33;
        uStack_208 = (uint)uVar33;
      }
      else {
        puVar29 = (ushort *)(pbStack_218 + uVar33);
        uStack_204 = *puVar29;
        if (uStack_204 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar32 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar32 != 0)) &&
             ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
              (*(char *)(lVar32 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x80f);
            }
          }
          func_0x(pbStack_218,3);
        }
        uStack_208 = uStack_210._4_4_ + 2 + (uint)uStack_204 * 2;
        if (0x1f9e < uStack_208) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar32 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar32 != 0 &&
              ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
               (*(char *)(lVar32 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x816);
            }
          }
          func_0x(pbStack_218,4);
        }
        uStack_21c = puVar29[uStack_204] & 0x7fff;
        uVar33 = (ulonglong)uStack_21c;
        uVar22 = uStack_208;
        if (uStack_21c < uStack_208) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar32 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar32 != 0)) &&
             ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
              (*(char *)(lVar32 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_298 = (short *)0x0;
              (*_DAT_)(1,0x12b8068,0x13d7d38,0x81d);
            }
          }
          func_0x(pbStack_218,4);
          uVar33 = (ulonglong)uStack_21c;
          uVar22 = uStack_208;
        }
        do {
          if (-1 < (short)puVar29[(ulonglong)(uStack_204 - 1) + 1]) break;
          uVar21 = uVar22;
          if (((uStack_204 != 1) &&
              (uVar21 = *(ushort *)
                         (pbStack_218 + (ulonglong)uStack_204 * 2 + ((uStack_210 >> 0x20) - 2)) &
                        0x7fff, uVar21 < uVar22)) ||
             ((*(ushort *)(pbStack_218 + (ulonglong)uStack_204 * 2 + (uStack_210 >> 0x20)) & 0x7fff)
              < uVar21)) {
            func_0x(pbStack_218,7);
            uVar33 = (ulonglong)uStack_21c;
            uVar22 = uStack_208;
          }
          if ((uVar21 < uVar22) || ((uint)uVar33 < uVar21)) goto code_r0x0010389f;
          if (*(ushort *)(pbStack_218 + uVar21) == 5) {
            uStack_21e = uStack_21e | 2;
            uStack_204 = uStack_204 - 1;
            uStack_1f6 = (undefined2)uVar21;
            uVar15 = *(ushort *)(pbStack_218 + (ulonglong)(uVar21 & 0xffff) + 2);
            uVar20 = uStack_1f4 & 0xc7ff;
            if ((uVar15 & 0x4000) != 0) {
              uVar20 = (uStack_1f4 ^ uVar15) & 0x3800 ^ uStack_1f4;
            }
            uStack_1f4 = (uVar20 ^ uVar15) & 0x7ff ^ uVar20;
            break;
          }
          if (*(ushort *)(pbStack_218 + uVar21) < 0x400) break;
          uStack_21e = uStack_21e | 1;
          uStack_204 = uStack_204 - 1;
        } while (uStack_204 != 0);
      }
      if ((*pbStack_218 & 0x40) == 0) {
        uStack_1fa = 0;
        uStack_1f8 = 0;
      }
      else {
        uStack_1fa = (undefined2)uVar33;
        uStack_1f8 = (undefined2)(uVar33 >> 0x10);
        uStack_21c = (int)uVar33 + 0xe;
        puVar30 = (ulonglong *)func_0x(&uStack_21e);
        iVar18 = 0;
        uVar33 = *puVar30;
        uVar20 = (ushort)(uVar33 >> 0x30);
        uVar15 = uVar20;
        if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
          uVar15 = uVar20 & 0xdfff;
          if ((uVar33 & 0x4000000000000000) != 0) {
            uVar15 = uVar20 | 0x2000;
          }
        }
        if (uVar15 == 0xfffc) {
          iVar18 = (int)((uVar33 >> 0x20 & 0xffff) >> 5);
        }
        uStack_21c = uStack_21c + iVar18;
        uVar33 = (ulonglong)uStack_21c;
      }
      if ((pbStack_202 != (byte *)0x0) && (pbStack_202 < pbStack_218 + uVar33)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar32 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar32 != 0 &&
             (lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0)) &&
            (*(char *)(lVar32 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_298 = (short *)0x0;
            (*_DAT_)(1,0x12b8068,0x13d7d38,0x877);
          }
        }
        func_0x(pbStack_218,0x12);
        uVar33 = (ulonglong)uStack_21c;
      }
      if (0x3f3b < (int)uVar33 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar32 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar32 != 0 &&
            ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
             (*(char *)(lVar32 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_298 = (short *)0x0;
            (*_DAT_)(1,0x12b8068,0x13d7d38,0x87c);
          }
        }
        func_0x(pbStack_218,5);
        uVar33 = (ulonglong)uStack_21c;
      }
    }
code_r0x0010389f:
    uVar22 = (uint)uVar33;
    if ((8 < uVar22) || (((*pbStack_218 & 0xe) != 0 && ((*pbStack_218 & 0xe) != 0xc)))) {
code_r0x001038b6:
      uStack_228 = uVar22;
    }
  }
  else {
    if (uVar22 == 0) {
      func_0x();
      uVar22 = uStack_21c;
    }
    if ((8 < uVar22) || (((*pbStack_218 & 0x1c) != 0 && ((*pbStack_218 & 0x1c) != 0xc))))
    goto code_r0x001038b6;
    uStack_228 = 9;
  }
  uStack_238 = 0;
  uStack_240 = 1;
  uStack_248 = 0;
  uStack_250 = 0;
  uStack_258 = (undefined8 *)CONCAT44(uStack_258._4_4_,((byte)~bVar13 & 2) << 0x17);
  piStack_260 = piStack_138;
  uStack_270 = uStack_18c;
  uStack_278 = CONCAT44(uStack_278._4_4_,iStack_188);
  uStack_280 = *(undefined8 *)(psStack_1e8 + 4);
  uStack_290 = uStack_228;
  uStack_298 = (short *)((ulonglong)uStack_298._4_4_ << 0x20);
  uStack_288 = uVar16;
  plStack_268 = plVar10;
  puStack_230 = puVar12;
  func_0x(pplStack_1e0,lStack_148,uStack_150,iVar7);
  uVar16 = uStack_228;
code_r0x0010392f:
  uStack_228 = uVar16;
  func_0x(uStack_58 ^ (ulonglong)auStack_2b8);
  return;
}

