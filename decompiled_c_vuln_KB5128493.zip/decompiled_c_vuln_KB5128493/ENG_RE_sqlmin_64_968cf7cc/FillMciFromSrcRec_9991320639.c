
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,short *param_3,longlong *param_4,
                 undefined8 param_5,int param_6,int param_7,longlong param_8,longlong param_9,
                 uint *param_10)

{
  ushort *puVar1;
  int *piVar2;
  uint *puVar3;
  undefined2 uVar4;
  code *pcVar5;
  longlong *plVar6;
  longlong lVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  byte bVar14;
  ushort uVar15;
  uint uVar16;
  int iVar17;
  int *piVar18;
  ulonglong *puVar19;
  undefined8 uVar20;
  byte bVar21;
  uint uVar22;
  uint uVar23;
  ulonglong uVar24;
  longlong lVar25;
  ulonglong uVar26;
  longlong lVar27;
  undefined *puVar28;
  ushort *puVar29;
  uint *puVar30;
  ushort uVar31;
  ushort uVar32;
  int iVar33;
  uint uVar34;
  ulonglong uVar35;
  byte *pbVar36;
  ulonglong uVar37;
  longlong lVar38;
  short *psVar39;
  longlong unaff_GS_OFFSET;
  undefined auStack_c8 [64];
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  undefined8 uStack_78;
  uint uStack_70;
  int iStack_6c;
  longlong lStack_68;
  short *psStack_60;
  uint uStack_58;
  longlong lStack_50;
  longlong lStack_48;
  longlong *plStack_40;
  ulonglong uStack_38;
  
  puVar28 = auStack_c8;
  uStack_38 = _DAT_ ^ (ulonglong)&uStack_88;
  uVar37 = 0;
  uStack_7c = 0;
  lStack_68 = 0;
  lVar27 = *(longlong *)(param_2 + 8);
  iStack_6c = -1;
  psStack_60 = param_3;
  lStack_50 = param_2;
  lStack_48 = param_1;
  plStack_40 = param_4;
  if (*(int *)(lVar27 + 0x100) == 2) {
    if ((*(byte *)(lVar27 + 0x42) & 4) == 0) {
      uVar37 = (ulonglong)*(uint *)(lVar27 + 0xb0);
      if (0x1f9e < *(uint *)(lVar27 + 0xb0)) {
        uVar37 = 0x1f9e;
      }
    }
    else {
      uVar37 = 0x1f9e;
    }
    uStack_7c = (uint)uVar37;
    uVar24 = uVar37 + 0xf;
    if (uVar24 <= uVar37) {
      uVar24 = 0xffffffffffffff0;
    }
    uVar24 = uVar24 & 0xfffffffffffffff0;
    func_0x();
    puVar28 = auStack_c8 + -uVar24;
    lStack_68 = (longlong)&uStack_88 + -uVar24;
  }
  lVar27 = lStack_68;
  if (param_4 != (longlong *)0x0) {
    pcVar5 = *(code **)*param_4;
    *(undefined8 *)(puVar28 + -8) = 0x1000ce;
    param_3 = (short *)(*pcVar5)(param_4);
    psStack_60 = param_3;
  }
  puVar1 = (ushort *)(param_3 + 1);
  if (*param_3 == 0) {
    *(undefined8 *)(puVar28 + -8) = 0x1000e8;
    uVar16 = func_0x(puVar1);
  }
  else {
    uVar16 = (uint)*puVar1;
  }
  uVar16 = uVar16 + param_6;
  uStack_78 = CONCAT44(uStack_78._4_4_,uVar16);
  uStack_80 = 0;
  psVar39 = param_3;
  if (0 < (int)uVar16) {
    do {
      uStack_84 = uVar16;
      uVar24 = 0;
      uStack_58 = ~uStack_80;
      if ((uStack_58 & 0xc0000000) == 0x80000000) {
        uVar16 = uStack_58 & 0x1fffffff;
        uVar20 = **(undefined8 **)(*(longlong *)(param_2 + 8) + 0x160);
        *(undefined8 *)(puVar28 + -8) = 0x100163;
        piVar18 = (int *)func_0x(uVar20,uVar16);
        uVar24 = 0;
      }
      else {
        uVar20 = *(undefined8 *)(*(longlong *)(param_2 + 8) + 0x160);
        *(undefined8 *)(puVar28 + -8) = 0x100148;
        piVar18 = (int *)func_0x(uVar20);
      }
      if ((piVar18 != (int *)0x0) && ((*(byte *)((longlong)piVar18 + 0x21) & 0x10) != 0)) {
        uVar35 = (ulonglong)*(uint *)(*(longlong *)(param_1 + 8) + 0x14);
        lVar25 = *(longlong *)(*(longlong *)(param_1 + 8) + 0x18);
        if (uVar35 != 0) {
          uVar26 = uVar24;
          do {
            if (*(int *)(*(longlong *)(lVar25 + 0x48) + 4) == piVar18[9]) {
              if (lVar25 != 0) goto LAB_;
              break;
            }
            uVar26 = uVar26 + 1;
            lVar25 = lVar25 + 0x50;
          } while (uVar26 < uVar35);
        }
        if ((*(byte *)(piVar18 + 8) & 0x40) != 0) {
          if (*psVar39 == 0) {
            pbVar36 = *(byte **)(psVar39 + 4);
            if ((*pbVar36 & 0x10) == 0) {
              uVar26 = uVar35;
              uVar16 = (uint)uVar24;
              if ((1 << (*pbVar36 & 0xe) & 0x1105U) != 0) {
LAB_:
                uVar35 = uVar26;
                uVar16 = ~(uint)(*(ushort *)((longlong)piVar18 + 6) >> 4) & 1;
              }
            }
            else {
              uVar26 = (ulonglong)*(uint *)(psVar39 + 8);
              if (*piVar18 < (int)*(uint *)(psVar39 + 8)) {
                if ((uint)*(ushort *)(pbVar36 + uVar26) < (uint)*(ushort *)(piVar18 + 1))
                goto LAB_;
                uVar16 = *(ushort *)(piVar18 + 1) - 1;
                uVar35 = uVar26;
                uVar16 = pbVar36[(uVar16 >> 3) + uVar26 + 2] >> ((byte)uVar16 & 7) & 1;
              }
              else {
                uVar16 = ~(uint)(*(ushort *)((longlong)piVar18 + 6) >> 4) & 1;
              }
            }
          }
          else {
            uVar15 = *(ushort *)(piVar18 + 1);
            uVar35 = (ulonglong)uVar15;
            if (*puVar1 < uVar15) {
              uVar16 = ~(uint)(*(ushort *)((longlong)piVar18 + 6) >> 4) & 1;
            }
            else {
              bVar14 = *(byte *)((longlong)((int)(uVar15 - 1) / 2) + (ulonglong)(ushort)param_3[0xc]
                                + *(longlong *)(param_3 + 4));
              uVar35 = (ulonglong)uVar15 & 0xffffffffffffff01;
              bVar21 = bVar14 >> 4;
              if ((uVar15 & 1) != 0) {
                bVar21 = bVar14 & 0xf;
              }
              uVar16 = (uint)CONCAT71((int7)(uVar24 >> 8),bVar21 == 0);
            }
          }
          if (uVar16 != 0) goto LAB_;
        }
        if (*psVar39 == 0) {
          iVar17 = *piVar18;
          if (*(int *)(param_3 + 2) == 0) {
            pbVar36 = *(byte **)(param_3 + 4);
            uVar16 = *(uint *)(param_3 + 8);
            uVar37 = (ulonglong)uVar16;
            *puVar1 = (ushort)uVar24;
            *(uint *)(param_3 + 10) = uVar16;
            bVar14 = *pbVar36;
            if ((bVar14 & 0x10) != 0) {
              uVar16 = uVar16 + 2 + (*(ushort *)(pbVar36 + uVar37) + 7 >> 3);
              uVar37 = (ulonglong)uVar16;
              *(uint *)(param_3 + 10) = uVar16;
              bVar14 = *pbVar36;
            }
            if ((bVar14 & 0x20) == 0) {
              *(int *)(param_3 + 2) = (int)uVar37;
              param_3[0xe] = (ushort)uVar24;
              *(int *)(param_3 + 0xc) = (int)uVar37;
            }
            else {
              puVar29 = (ushort *)(pbVar36 + uVar37);
              uVar15 = *puVar29;
              param_3[0xe] = uVar15;
              if (uVar15 == 0) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar27 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar27 != 0 &&
                    ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                     (*(char *)(lVar27 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar28 + -8) = 0x10037d;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(ulonglong *)(puVar28 + 0x20) = uVar24;
                    *(undefined8 *)(puVar28 + -8) = 0x1003a3;
                    (*_DAT_)(1,0xaa79b8,0xbc7688,0x80f);
                  }
                }
                uVar20 = *(undefined8 *)(param_3 + 4);
                *(undefined8 *)(puVar28 + -8) = 0x1003b1;
                func_0x(uVar20,3);
                uVar37 = (ulonglong)*(uint *)(param_3 + 10);
                uVar24 = 0;
                uVar15 = param_3[0xe];
              }
              uVar16 = (int)uVar37 + (uVar15 + 1) * 2;
              *(uint *)(param_3 + 0xc) = uVar16;
              if (0x1f9e < uVar16) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar27 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar27 != 0)) &&
                   ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                    (*(char *)(lVar27 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar28 + -8) = 0x100453;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(ulonglong *)(puVar28 + 0x20) = uVar24;
                    *(undefined8 *)(puVar28 + -8) = 0x100479;
                    (*_DAT_)(1,0xaa79b8,0xbc7688,0x816);
                  }
                }
                uVar20 = *(undefined8 *)(param_3 + 4);
                *(undefined8 *)(puVar28 + -8) = 0x100487;
                func_0x(uVar20,4);
                uVar15 = param_3[0xe];
                uVar16 = *(uint *)(param_3 + 0xc);
              }
              uVar37 = (ulonglong)uVar15;
              uVar15 = puVar29[uVar37];
              *(uint *)(param_3 + 2) = uVar15 & 0x7fff;
              if ((uVar15 & 0x7fff) < uVar16) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar27 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar27 != 0 &&
                    ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                     (*(char *)(lVar27 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar28 + -8) = 0x100525;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar28 + 0x20) = 0;
                    *(undefined8 *)(puVar28 + -8) = 0x10054d;
                    (*_DAT_)(1,0xaa79b8,0xbc7688,0x81d);
                  }
                }
                uVar20 = *(undefined8 *)(param_3 + 4);
                *(undefined8 *)(puVar28 + -8) = 0x10055b;
                func_0x(uVar20,4);
                uVar37 = (ulonglong)(ushort)param_3[0xe];
              }
              if ((short)puVar29[(ulonglong)((int)uVar37 - 1) + 1] < 0) {
                pbVar36 = *(byte **)(param_3 + 4);
                do {
                  if ((int)uVar37 == 1) {
                    uVar16 = *(uint *)(param_3 + 0xc);
                    uVar34 = uVar16;
LAB_:
                    if ((*(ushort *)(pbVar36 + uVar37 * 2 + (ulonglong)*(uint *)(param_3 + 10)) &
                        0x7fff) < uVar16) goto LAB_;
                  }
                  else {
                    uVar34 = *(uint *)(param_3 + 0xc);
                    uVar16 = *(ushort *)
                              (pbVar36 + uVar37 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                             0x7fff;
                    if (uVar34 <= uVar16) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar28 + -8) = 0x1005c2;
                    func_0x(pbVar36);
                    uVar34 = *(uint *)(param_3 + 0xc);
                  }
                  if ((uVar16 < uVar34) || (*(uint *)(param_3 + 2) < uVar16)) goto LAB_;
                  pbVar36 = *(byte **)(param_3 + 4);
                  if (*(ushort *)(pbVar36 + uVar16) == 5) {
                    *puVar1 = *puVar1 | 2;
                    param_3[0xe] = param_3[0xe] + -1;
                    param_3[0x15] = (short)uVar16;
                    lVar27 = (ulonglong)(uVar16 & 0xffff) + *(longlong *)(param_3 + 4);
                    uVar15 = param_3[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar27 + 2) >> 0xe & 1) != 0) {
                      uVar15 = *(ushort *)(lVar27 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
                    }
                    param_3[0x16] = uVar15;
                    param_3[0x16] = (uVar15 ^ *(ushort *)(lVar27 + 2)) & 0x7ff ^ uVar15;
                    goto LAB_;
                  }
                  if (*(ushort *)(pbVar36 + uVar16) < 0x400) goto LAB_;
                  *puVar1 = *puVar1 | 1;
                  uVar15 = param_3[0xe] - 1;
                  param_3[0xe] = uVar15;
                  if (uVar15 == 0) goto LAB_;
                  uVar37 = (ulonglong)uVar15;
                } while ((short)puVar29[(ulonglong)(uVar15 - 1) + 1] < 0);
                uVar37 = (ulonglong)*(uint *)(param_3 + 2);
                uVar24 = 0;
              }
              else {
LAB_:
                uVar37 = (ulonglong)*(uint *)(param_3 + 2);
                uVar24 = 0;
                pbVar36 = *(byte **)(param_3 + 4);
              }
            }
            if ((*pbVar36 & 0x40) == 0) {
              *(int *)(param_3 + 0x13) = (int)uVar24;
            }
            else {
              *(int *)(param_3 + 0x13) = (int)uVar37;
              *(int *)(param_3 + 2) = (int)uVar37 + 0xe;
              *(undefined8 *)(puVar28 + -8) = 0x1006b5;
              puVar19 = (ulonglong *)func_0x(puVar1);
              uVar24 = 0;
              iVar33 = 0;
              uVar32 = (ushort)(*puVar19 >> 0x30);
              uVar15 = uVar32;
              if ((((uint)(int)(short)uVar32 >> 1 ^ (int)(short)uVar32) & 0x2000) != 0) {
                uVar15 = uVar32 & 0xdfff;
                if ((uVar32 >> 0xe & 1) != 0) {
                  uVar15 = uVar32 | 0x2000;
                }
              }
              if (uVar15 == 0xfffc) {
                iVar33 = (int)((*puVar19 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar33;
              uVar37 = (ulonglong)*(uint *)(param_3 + 2);
            }
            iVar33 = (int)uVar37;
            if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
               (*(ulonglong *)(param_3 + 0xf) < uVar37 + *(longlong *)(param_3 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar27 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                   lVar27 != 0 && (lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0)) &&
                  (*(char *)(lVar27 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar28 + -8) = 0x1007b5;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(ulonglong *)(puVar28 + 0x20) = uVar24;
                  *(undefined8 *)(puVar28 + -8) = 0x1007db;
                  (*_DAT_)(1,0xaa79b8,0xbc7688,0x877);
                }
              }
              uVar20 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar28 + -8) = 0x1007e9;
              func_0x(uVar20);
              iVar33 = *(int *)(param_3 + 2);
            }
            if (0x3f3b < iVar33 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar27 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar27 != 0 &&
                  ((lVar27 = *(longlong *)(lVar27 + 0x60), lVar27 != 0 &&
                   (*(char *)(lVar27 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar28 + -8) = 0x100875;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar28 + 0x20) = 0;
                  *(undefined8 *)(puVar28 + -8) = 0x10089d;
                  (*_DAT_)(1,0xaa79b8,0xbc7688,0x87c);
                }
              }
              uVar20 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar28 + -8) = 0x1008ab;
              func_0x(uVar20);
            }
LAB_:
            uVar24 = 0;
          }
          uStack_84 = (uint)uVar24;
          if ((*(byte *)((longlong)piVar18 + 6) & 0x10) == 0) {
LAB_:
            uVar16 = -iVar17;
            if ((ushort)param_3[0xe] < uVar16) {
              puVar30 = *(uint **)(param_3 + 4);
              uStack_88 = uStack_84;
            }
            else {
              lVar27 = (ulonglong)*(uint *)(param_3 + 10) + *(longlong *)(param_3 + 4);
              if (uVar16 == 1) {
                uVar34 = *(uint *)(param_3 + 0xc);
              }
              else {
                uVar34 = *(ushort *)(lVar27 + -2 + (longlong)(int)uVar16 * 2) & 0x7fff;
              }
              uStack_88 = (*(ushort *)(lVar27 + (longlong)(int)uVar16 * 2) & 0x7fff) - uVar34;
              if (uStack_88 != 0) {
                uStack_84 = (uint)(*(ushort *)(lVar27 + 2 + (ulonglong)(uVar16 - 1) * 2) >> 0xf);
              }
              puVar30 = (uint *)((ulonglong)uVar34 + *(longlong *)(param_3 + 4));
            }
          }
          else {
            bVar14 = **(byte **)(param_3 + 4);
            if ((bVar14 & 0x10) == 0) {
              if ((1 << (bVar14 & 0xe) & 0x1105U) == 0) goto LAB_;
            }
            else if ((*piVar18 < (int)*(uint *)(param_3 + 8)) &&
                    (*(ushort *)(piVar18 + 1) <=
                     *(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8))))
            goto LAB_;
            uStack_88 = **(uint **)(piVar18 + 2);
            puVar30 = *(uint **)(piVar18 + 2) + 1;
          }
        }
        else {
          uStack_70 = (uint)uVar24;
          *(uint **)(puVar28 + 0x20) = &uStack_70;
          *(undefined8 *)(puVar28 + -8) = 0x100b59;
          puVar30 = (uint *)func_0x(puVar1,piVar18,uVar35,&uStack_88);
          uVar34 = uStack_70;
          uVar16 = uStack_88;
          if ((((*psVar39 != 0) && (plVar6 = *(longlong **)(psVar39 + 8), plVar6 != (longlong *)0x0)
               ) && (*plVar6 != 0)) &&
             (((*(byte *)((longlong)piVar18 + 6) & 8) == 0 && ((uStack_70 & 1) == 0)))) {
            if ((puVar30 == (uint *)0x0) || (puVar30 == (uint *)0x82c3f4)) {
              uStack_84 = uStack_70 & 1;
              uStack_88 = 0;
              puVar30 = *(uint **)(psVar39 + 4);
              goto LAB_;
            }
            *(uint *)(puVar28 + 0x38) = uStack_70;
            *(uint **)(puVar28 + 0x30) = &uStack_88;
            *(int *)(puVar28 + 0x28) = (int)uVar37;
            *(longlong *)(puVar28 + 0x20) = lVar27;
            *(undefined8 *)(puVar28 + -8) = 0x100bba;
            puVar30 = (uint *)func_0x(plVar6,piVar18,puVar30,uVar16);
          }
          uStack_84 = uVar34 & 1;
          if (puVar30 == (uint *)0x0) {
            puVar30 = *(uint **)(psVar39 + 4);
          }
        }
LAB_:
        uVar16 = uStack_88;
        param_2 = lStack_50;
        param_1 = lStack_48;
        if (0x18 < uStack_88) {
          uVar34 = *(uint *)(param_8 + 4);
          lVar27 = (ulonglong)uVar34 * 0x40;
          pbVar36 = (byte *)(lVar27 + 0x18 + *(longlong *)(param_8 + 8));
          *pbVar36 = *pbVar36 & 0xfb;
          if (*(uint *)(param_8 + 0x20) < *(int *)(param_8 + 0x10) + uStack_88) {
            lVar38 = (ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
            lVar25 = *(longlong *)(lVar38 + 0x100);
            if (lVar25 == 0) {
              *(undefined8 *)(puVar28 + -8) = 0x1009d2;
              (*_DAT_)(0);
              lVar25 = *(longlong *)(lVar38 + 0x100);
            }
            uVar20 = *(undefined8 *)(lVar25 + 1000);
            puVar28[0x20] = 5;
            *(undefined8 *)(puVar28 + -8) = 0x1009fd;
            uVar20 = (*_DAT_)(0x1f9e,uVar20,0xbc5af8,0xcd);
            *(undefined8 *)(param_8 + 0x18) = uVar20;
            *(undefined4 *)(param_8 + 0x10) = 0;
            pbVar36 = (byte *)(lVar27 + 0x18 + *(longlong *)(param_8 + 8));
            *pbVar36 = *pbVar36 | 4;
            *(undefined4 *)(param_8 + 0x20) = 0x1f9e;
          }
          iVar17 = piVar18[1];
          iVar33 = piVar18[2];
          iVar8 = piVar18[3];
          piVar2 = (int *)(lVar27 + 8 + *(longlong *)(param_8 + 8));
          *piVar2 = *piVar18;
          piVar2[1] = iVar17;
          piVar2[2] = iVar33;
          piVar2[3] = iVar8;
          *(undefined4 *)(lVar27 + *(longlong *)(param_8 + 8)) = 0;
          pbVar36 = (byte *)(lVar27 + 0x18 + *(longlong *)(param_8 + 8));
          *pbVar36 = *pbVar36 & 0xfe;
          pbVar36 = (byte *)(lVar27 + 0x18 + *(longlong *)(param_8 + 8));
          *pbVar36 = *pbVar36 & 0xfd;
          lVar27 = *(longlong *)(param_8 + 8) + lVar27;
          *(ulonglong *)(lVar27 + 0x20) =
               (ulonglong)*(uint *)(param_8 + 0x10) + *(longlong *)(param_8 + 0x18);
          *(uint *)(lVar27 + 0x28) = uVar16;
          uVar22 = *(uint *)(lVar27 + 0x2c) & 0xfffffffa | uStack_84 & 0xfffffffb;
          *(uint *)(lVar27 + 0x2c) = uVar22;
          iVar17 = *piVar18;
          iVar33 = piVar18[1];
          iVar8 = piVar18[2];
          iVar9 = piVar18[3];
          *(uint *)(lVar27 + 0x2c) = uVar22 & 0xfffffff5;
          *(int *)(lVar27 + 0x30) = iVar17;
          *(int *)(lVar27 + 0x34) = iVar33;
          *(int *)(lVar27 + 0x38) = iVar8;
          *(int *)(lVar27 + 0x3c) = iVar9;
          uVar22 = *(uint *)(param_8 + 0x10);
          iVar17 = *(int *)(param_8 + 0x20);
          lVar27 = *(longlong *)(param_8 + 0x18);
          *(undefined8 *)(puVar28 + -8) = 0x100a9f;
          func_0x((ulonglong)uVar22 + lVar27,iVar17 - uVar22,puVar30,uVar16);
          *(int *)(param_8 + 4) = *(int *)(param_8 + 4) + 1;
          *(int *)(param_8 + 0x10) = *(int *)(param_8 + 0x10) + uVar16;
          uVar4 = *(undefined2 *)((longlong)piVar18 + 0x3a);
          puVar30 = (uint *)((ulonglong)*param_10 * 0x20 + param_9);
          *puVar30 = uStack_88;
          puVar30[4] = uStack_58;
          *(ulonglong *)(puVar30 + 2) = (ulonglong)uVar34;
          puVar30[5] = 2;
          *(undefined2 *)(puVar30 + 6) = uVar4;
          *param_10 = *param_10 + 1;
          param_2 = lStack_50;
          param_1 = lStack_48;
          psVar39 = psStack_60;
        }
      }
LAB_:
      uVar37 = (ulonglong)uStack_7c;
      uStack_80 = uStack_80 + 1;
      lVar27 = lStack_68;
      uVar16 = uStack_84;
    } while ((int)uStack_80 < (int)uStack_78);
  }
  if (param_7 == 0) {
    *(undefined8 *)(puVar28 + -8) = 0x100bfc;
    iVar17 = func_0x(psVar39);
  }
  else {
    iVar17 = 0;
  }
  psStack_60 = (short *)(longlong)iVar17;
  uStack_80 = 0;
  if (0 < (longlong)psStack_60) {
    lStack_68 = 0;
    do {
      lVar27 = lStack_68;
      uVar34 = uStack_80;
      uStack_78 = 0;
      if (*(int *)(param_3 + 2) == 0) {
        pbVar36 = *(byte **)(param_3 + 4);
        uVar22 = *(uint *)(param_3 + 8);
        uVar37 = (ulonglong)uVar22;
        *puVar1 = 0;
        *(uint *)(param_3 + 10) = uVar22;
        bVar14 = *pbVar36;
        if ((bVar14 & 0x10) != 0) {
          uVar22 = uVar22 + 2 + (*(ushort *)(pbVar36 + uVar37) + 7 >> 3);
          uVar37 = (ulonglong)uVar22;
          *(uint *)(param_3 + 10) = uVar22;
          bVar14 = *pbVar36;
        }
        if ((bVar14 & 0x20) == 0) {
          *(int *)(param_3 + 2) = (int)uVar37;
          param_3[0xe] = 0;
          *(int *)(param_3 + 0xc) = (int)uVar37;
        }
        else {
          puVar29 = (ushort *)(pbVar36 + uVar37);
          uVar15 = *puVar29;
          param_3[0xe] = uVar15;
          if (uVar15 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar25 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar25 != 0)) &&
               ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                (*(char *)(lVar25 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar28 + -8) = 0x100cf2;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar28 + 0x20) = 0;
                *(undefined8 *)(puVar28 + -8) = 0x100d18;
                (*_DAT_)(1,0xaa79b8,0xbc7688,0x80f);
              }
            }
            uVar20 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar28 + -8) = 0x100d26;
            func_0x(uVar20,3);
            uVar37 = (ulonglong)*(uint *)(param_3 + 10);
            uVar15 = param_3[0xe];
          }
          uVar22 = (int)uVar37 + (uVar15 + 1) * 2;
          *(uint *)(param_3 + 0xc) = uVar22;
          if (0x1f9e < uVar22) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar25 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar25 != 0 &&
                ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                 (*(char *)(lVar25 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar28 + -8) = 0x100dc8;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar28 + 0x20) = 0;
                *(undefined8 *)(puVar28 + -8) = 0x100dee;
                (*_DAT_)(1,0xaa79b8,0xbc7688,0x816);
              }
            }
            uVar20 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar28 + -8) = 0x100dfc;
            func_0x(uVar20,4);
            uVar15 = param_3[0xe];
            uVar22 = *(uint *)(param_3 + 0xc);
          }
          uVar37 = (ulonglong)uVar15;
          uVar15 = puVar29[uVar37];
          *(uint *)(param_3 + 2) = uVar15 & 0x7fff;
          if ((uVar15 & 0x7fff) < uVar22) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar25 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar25 != 0)) &&
               ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                (*(char *)(lVar25 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar28 + -8) = 0x100e9a;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar28 + 0x20) = 0;
                *(undefined8 *)(puVar28 + -8) = 0x100ec0;
                (*_DAT_)(1,0xaa79b8,0xbc7688,0x81d);
              }
            }
            uVar20 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar28 + -8) = 0x100ece;
            func_0x(uVar20,4);
            uVar37 = (ulonglong)(ushort)param_3[0xe];
          }
          if ((short)puVar29[(ulonglong)((int)uVar37 - 1) + 1] < 0) {
            pbVar36 = *(byte **)(param_3 + 4);
            do {
              if ((int)uVar37 == 1) {
                uVar22 = *(uint *)(param_3 + 0xc);
                uVar23 = uVar22;
LAB_:
                if ((*(ushort *)(pbVar36 + uVar37 * 2 + (ulonglong)*(uint *)(param_3 + 10)) & 0x7fff
                    ) < uVar22) goto LAB_;
              }
              else {
                uVar23 = *(uint *)(param_3 + 0xc);
                uVar22 = *(ushort *)
                          (pbVar36 + uVar37 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) & 0x7fff
                ;
                if (uVar23 <= uVar22) goto LAB_;
LAB_:
                *(undefined8 *)(puVar28 + -8) = 0x100f32;
                func_0x(pbVar36,7);
                uVar23 = *(uint *)(param_3 + 0xc);
              }
              if ((uVar22 < uVar23) || (*(uint *)(param_3 + 2) < uVar22)) goto LAB_;
              pbVar36 = *(byte **)(param_3 + 4);
              if (*(ushort *)(pbVar36 + uVar22) == 5) {
                *puVar1 = *puVar1 | 2;
                param_3[0xe] = param_3[0xe] + -1;
                param_3[0x15] = (short)uVar22;
                lVar25 = (ulonglong)(uVar22 & 0xffff) + *(longlong *)(param_3 + 4);
                uVar15 = param_3[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar25 + 2) >> 0xe & 1) != 0) {
                  uVar15 = *(ushort *)(lVar25 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
                }
                param_3[0x16] = uVar15;
                param_3[0x16] = (uVar15 ^ *(ushort *)(lVar25 + 2)) & 0x7ff ^ uVar15;
                goto LAB_;
              }
              if (*(ushort *)(pbVar36 + uVar22) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar15 = param_3[0xe] - 1;
              param_3[0xe] = uVar15;
              if (uVar15 == 0) goto LAB_;
              uVar37 = (ulonglong)uVar15;
            } while ((short)puVar29[(ulonglong)(uVar15 - 1) + 1] < 0);
            uVar37 = (ulonglong)*(uint *)(param_3 + 2);
          }
          else {
LAB_:
            uVar37 = (ulonglong)*(uint *)(param_3 + 2);
            pbVar36 = *(byte **)(param_3 + 4);
          }
        }
        if ((*pbVar36 & 0x40) == 0) {
          *(undefined4 *)(param_3 + 0x13) = 0;
        }
        else {
          *(int *)(param_3 + 0x13) = (int)uVar37;
          *(int *)(param_3 + 2) = (int)uVar37 + 0xe;
          *(undefined8 *)(puVar28 + -8) = 0x101025;
          puVar19 = (ulonglong *)func_0x(puVar1);
          iVar17 = 0;
          uVar32 = (ushort)(*puVar19 >> 0x30);
          uVar15 = uVar32;
          if ((((uint)(int)(short)uVar32 >> 1 ^ (int)(short)uVar32) & 0x2000) != 0) {
            uVar15 = uVar32 & 0xdfff;
            if ((uVar32 >> 0xe & 1) != 0) {
              uVar15 = uVar32 | 0x2000;
            }
          }
          if (uVar15 == 0xfffc) {
            iVar17 = (int)((*puVar19 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar17;
          uVar37 = (ulonglong)*(uint *)(param_3 + 2);
        }
        iVar17 = (int)uVar37;
        if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
           (*(ulonglong *)(param_3 + 0xf) < uVar37 + *(longlong *)(param_3 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar25 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar25 != 0 &&
               (lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0)) &&
              (*(char *)(lVar25 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar28 + -8) = 0x101125;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar28 + 0x20) = 0;
              *(undefined8 *)(puVar28 + -8) = 0x10114b;
              (*_DAT_)(1,0xaa79b8,0xbc7688,0x877);
            }
          }
          uVar20 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)(puVar28 + -8) = 0x101159;
          func_0x(uVar20,0x12);
          iVar17 = *(int *)(param_3 + 2);
        }
        if (0x3f3b < iVar17 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar25 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar25 != 0 &&
              ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
               (*(char *)(lVar25 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar28 + -8) = 0x1011e5;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(puVar28 + 0x20) = 0;
              *(undefined8 *)(puVar28 + -8) = 0x10120b;
              (*_DAT_)(1,0xaa79b8,0xbc7688,0x87c);
            }
          }
          uVar20 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)(puVar28 + -8) = 0x101219;
          func_0x(uVar20,5);
        }
      }
LAB_:
      *(undefined8 *)(puVar28 + -8) = 0x101221;
      iVar17 = func_0x();
      if (iVar17 == 0) {
        *(undefined8 *)(puVar28 + -8) = 0x10136d;
        iVar17 = func_0x(puVar1);
        if (iVar17 == 0) {
          *(undefined8 *)(puVar28 + 0x20) = 0;
          *(undefined8 *)(puVar28 + -8) = 0x101395;
          (*_DAT_)(1,0xc63038,0xc54128,0xd67);
        }
      }
      else {
        uVar15 = param_3[0x16];
        lVar25 = 0;
        uStack_78 = 0;
        if (uVar34 < (uVar15 & 0x7ff)) {
          uVar37 = (ulonglong)(ushort)param_3[0x15];
          lVar7 = *(longlong *)(param_3 + 4);
          uVar32 = 0;
          lVar38 = lVar7 + uVar37;
          if ((uVar15 & 0x3800) == 0) {
            uVar31 = *(ushort *)(lVar38 + 2);
LAB_:
            uVar32 = uVar31 >> 0xb & 7;
          }
          else if ((uVar15 >> 0xb & 7) != 0) {
            do {
              if (((lVar25 == 0) || ((*(ushort *)(lVar38 + 2 + lVar25 * 2) & 0x7ff) <= uVar34)) &&
                 (uVar31 = *(ushort *)(lVar38 + 4 + lVar25 * 2),
                 (int)uVar34 <= (int)((uVar31 & 0x7ff) - 1))) goto LAB_;
              lVar25 = lVar25 + 1;
            } while (lVar25 < (longlong)(ulonglong)(uVar15 >> 0xb & 7));
          }
          uVar22 = uVar15 >> 0xb & 7;
          uVar16 = (uVar15 & 0x7ff) * 2;
          uVar24 = (ulonglong)(uVar22 * 2);
          iStack_6c = (uint)*(ushort *)(uVar24 + (lVar27 + 2) * 2 + lVar7 + uVar37) +
                      (uint)uVar32 * 0x10000;
          lVar25 = uVar24 + uVar16 + lVar7 + uVar37;
          if (lVar27 == 0) {
            uVar22 = (uVar16 + uVar22) * 2 + 4;
          }
          else {
            uVar22 = *(ushort *)(lVar25 + 2 + lVar27 * 2) & 0x7fff;
          }
          uStack_88 = (*(ushort *)(lVar25 + 4 + lVar27 * 2) & 0x7fff) - uVar22;
          uVar16 = (uint)(*(ushort *)(lVar25 + 4 + lVar27 * 2) >> 0xf);
          uStack_78 = (ulonglong)uVar22 + lVar38;
        }
        else {
          *(undefined8 *)(puVar28 + 0x20) = 0;
          *(undefined8 *)(puVar28 + -8) = 0x101363;
          (*_DAT_)(1,0xc63008,0xc63050,0x3c6);
        }
      }
      iVar17 = iStack_6c;
      uVar22 = uStack_88;
      uVar20 = **(undefined8 **)(*(longlong *)(lStack_50 + 8) + 0x160);
      *(undefined8 *)(puVar28 + -8) = 0x1013b4;
      puVar30 = (uint *)func_0x(uVar20,iVar17);
      if ((puVar30 != (uint *)0x0) &&
         (uVar37 = 0, (*(byte *)((longlong)puVar30 + 0x21) & 0x10) != 0)) {
        uVar24 = (ulonglong)*(uint *)(*(longlong *)(lStack_48 + 8) + 0x14);
        lVar27 = *(longlong *)(*(longlong *)(lStack_48 + 8) + 0x18);
        if (uVar24 != 0) {
          do {
            if (*(int *)(*(longlong *)(lVar27 + 0x48) + 4) == iVar17) {
              if (lVar27 != 0) goto LAB_;
              break;
            }
            uVar37 = uVar37 + 1;
            lVar27 = lVar27 + 0x50;
          } while (uVar37 < uVar24);
        }
        if (0x18 < uVar22) {
          uVar34 = *(uint *)(param_8 + 4);
          lVar27 = (ulonglong)uVar34 * 0x40;
          pbVar36 = (byte *)(lVar27 + 0x18 + *(longlong *)(param_8 + 8));
          *pbVar36 = *pbVar36 & 0xfb;
          if (*(uint *)(param_8 + 0x20) < *(int *)(param_8 + 0x10) + uVar22) {
            lVar38 = (ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
            lVar25 = *(longlong *)(lVar38 + 0x100);
            if (lVar25 == 0) {
              *(undefined8 *)(puVar28 + -8) = 0x10146b;
              (*_DAT_)(0);
              lVar25 = *(longlong *)(lVar38 + 0x100);
            }
            uVar20 = *(undefined8 *)(lVar25 + 1000);
            puVar28[0x20] = 5;
            *(undefined8 *)(puVar28 + -8) = 0x101496;
            uVar20 = (*_DAT_)(0x1f9e,uVar20,0xbc5af8,0xcd);
            *(undefined8 *)(param_8 + 0x18) = uVar20;
            *(undefined4 *)(param_8 + 0x10) = 0;
            pbVar36 = (byte *)(lVar27 + 0x18 + *(longlong *)(param_8 + 8));
            *pbVar36 = *pbVar36 | 4;
            *(undefined4 *)(param_8 + 0x20) = 0x1f9e;
          }
          lVar25 = uStack_78;
          uVar23 = puVar30[1];
          uVar10 = puVar30[2];
          uVar11 = puVar30[3];
          puVar3 = (uint *)(lVar27 + 8 + *(longlong *)(param_8 + 8));
          *puVar3 = *puVar30;
          puVar3[1] = uVar23;
          puVar3[2] = uVar10;
          puVar3[3] = uVar11;
          *(undefined4 *)(lVar27 + *(longlong *)(param_8 + 8)) = 0;
          pbVar36 = (byte *)(lVar27 + 0x18 + *(longlong *)(param_8 + 8));
          *pbVar36 = *pbVar36 & 0xfe;
          pbVar36 = (byte *)(lVar27 + 0x18 + *(longlong *)(param_8 + 8));
          *pbVar36 = *pbVar36 & 0xfd;
          lVar27 = *(longlong *)(param_8 + 8) + lVar27;
          uVar23 = *(uint *)(lVar27 + 0x2c);
          *(ulonglong *)(lVar27 + 0x20) =
               (ulonglong)*(uint *)(param_8 + 0x10) + *(longlong *)(param_8 + 0x18);
          *(uint *)(lVar27 + 0x28) = uVar22;
          *(uint *)(lVar27 + 0x2c) = uVar23 & 0xfffffffa | uVar16 & 1;
          uVar10 = *puVar30;
          uVar11 = puVar30[1];
          uVar12 = puVar30[2];
          uVar13 = puVar30[3];
          *(uint *)(lVar27 + 0x2c) = uVar23 & 0xfffffff0 | uVar16 & 1;
          *(uint *)(lVar27 + 0x30) = uVar10;
          *(uint *)(lVar27 + 0x34) = uVar11;
          *(uint *)(lVar27 + 0x38) = uVar12;
          *(uint *)(lVar27 + 0x3c) = uVar13;
          uVar23 = *(uint *)(param_8 + 0x10);
          iVar17 = *(int *)(param_8 + 0x20);
          lVar27 = *(longlong *)(param_8 + 0x18);
          *(undefined8 *)(puVar28 + -8) = 0x101531;
          func_0x((ulonglong)uVar23 + lVar27,iVar17 - uVar23,lVar25,uVar22);
          *(int *)(param_8 + 4) = *(int *)(param_8 + 4) + 1;
          *(int *)(param_8 + 0x10) = *(int *)(param_8 + 0x10) + uVar22;
          uVar4 = *(undefined2 *)((longlong)puVar30 + 0x3a);
          uVar22 = *puVar30;
          puVar30 = (uint *)((ulonglong)*param_10 * 0x20 + param_9);
          *(ulonglong *)(puVar30 + 2) = (ulonglong)uVar34;
          *puVar30 = uStack_88;
          puVar30[4] = uVar22;
          puVar30[5] = 2;
          *(undefined2 *)(puVar30 + 6) = uVar4;
          *param_10 = *param_10 + 1;
          uVar34 = uStack_80;
        }
      }
LAB_:
      uStack_80 = uVar34 + 1;
      lStack_68 = lStack_68 + 1;
    } while (lStack_68 < (longlong)psStack_60);
  }
  if (plStack_40 != (longlong *)0x0) {
    pcVar5 = *(code **)(*plStack_40 + 8);
    *(undefined8 *)(puVar28 + -8) = 0x1015a3;
    (*pcVar5)();
  }
  uVar37 = uStack_38 ^ (ulonglong)&uStack_88;
  *(undefined8 *)(puVar28 + -8) = 0x1015af;
  func_0x(uVar37);
  return;
}

