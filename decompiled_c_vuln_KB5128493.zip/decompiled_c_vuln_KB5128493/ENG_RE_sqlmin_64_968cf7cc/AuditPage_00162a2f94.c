
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(byte *param_1,int param_2,int param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  undefined4 uVar4;
  longlong lVar5;
  char cVar6;
  short sVar7;
  ushort uVar8;
  int iVar9;
  uint uVar10;
  short *psVar11;
  ushort uVar12;
  code *UNRECOVERED_JUMPTABLE;
  undefined8 uVar13;
  byte **ppbVar14;
  int iVar15;
  ulonglong uVar16;
  longlong unaff_GS_OFFSET;
  undefined auStack_178 [32];
  uint uStack_158;
  uint uStack_150;
  int iStack_148;
  undefined4 uStack_144;
  ushort *puStack_130;
  undefined8 uStack_128;
  undefined2 uStack_120;
  undefined4 uStack_118;
  undefined2 uStack_114;
  longlong lStack_108;
  undefined4 uStack_100;
  short sStack_f8;
  undefined4 uStack_f4;
  byte *pbStack_f0;
  byte **ppbStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined8 uStack_88;
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [16];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_178;
  iVar15 = 0;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  ppbStack_e8 = (byte **)0x0;
  sStack_f8 = -1;
  iStack_c4 = 0xffffffff;
  if ((*param_1 != 1) && (iVar15 = 1, param_3 == 2)) {
    uStack_150 = 1;
    uStack_158 = (uint)*param_1;
    func_0x(0x22eb,param_1,0x1342f10,5);
  }
  bVar3 = param_1[1];
  if ((0x65 < (byte)(bVar3 - 1)) &&
     (((bVar3 != 0xff || (param_2 != 2)) && (iVar15 = iVar15 + 1, param_3 == 2)))) {
    uStack_158 = (uint)bVar3;
    uStack_150 = uStack_158;
    func_0x(0x22eb,param_1,0x1342de0,6);
  }
  if ((char)param_1[2] < '\0') {
    if ((6 < param_1[0x60]) && (iVar15 = iVar15 + 1, param_3 == 2)) {
      uStack_150 = 0xffffffff;
      uStack_158 = 0xffffffff;
      func_0x(0x22eb,param_1,0x1342d50,0x35);
    }
    if (iVar15 != 0) {
      if (((DAT_ & 0x40) != 0) ||
         (((lVar5 = *(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
           lVar5 != 0 && (lVar5 = **(longlong **)(lVar5 + 0x38), lVar5 != 0)) &&
          (iVar9 = (*_DAT_)(lVar5,0x279e), iVar9 != 0)))) {
        func_0x(0x1342cf0,0x1342cb0,iVar15);
      }
      goto LAB_;
    }
    iVar15 = 0;
    if (*(short *)((ulonglong)param_1[0x60] * 6 + 0x1107704) == -1) {
      if (param_3 == 2) {
        uStack_150 = 0xffffffff;
        uStack_158 = 0xffffffff;
        func_0x(0x22eb,param_1,0x1343160,0x32);
      }
      if (((DAT_ & 0x40) != 0) ||
         (((lVar5 = *(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
           lVar5 != 0 && (lVar5 = **(longlong **)(lVar5 + 0x38), lVar5 != 0)) &&
          (iVar15 = (*_DAT_)(lVar5,0x279e), iVar15 != 0)))) {
        func_0x(0x13430f0,0x1342cb0,1);
      }
      goto LAB_;
    }
  }
  uVar8 = 0x60;
  if ((char)param_1[2] < '\0') {
    sVar7 = func_0x(param_1 + 0x60);
    uVar8 = sVar7 + 0x60;
  }
  uVar12 = *(ushort *)(param_1 + 0x1e);
  if (((uVar12 < uVar8) ||
      ((0x1000 - (ulonglong)*(ushort *)(param_1 + 0x16)) * 2 < (ulonglong)uVar12)) &&
     (iVar15 = iVar15 + 1, param_3 == 2)) {
    uStack_150 = (0x1000 - (uint)*(ushort *)(param_1 + 0x16)) * 2;
    uStack_158 = (uint)uVar12;
    func_0x(0x22eb,param_1,0x1342ff0,7);
  }
  if ((char)param_1[2] < '\0') {
    sVar7 = func_0x(param_1 + 0x60);
    uVar8 = sVar7 + 0x60;
  }
  else {
    uVar8 = 0x60;
  }
  uVar12 = *(ushort *)(param_1 + 0x1c);
  if (((int)(0x2000 - (uint)uVar8) < (int)(uint)uVar12) && (iVar15 = iVar15 + 1, param_3 == 2)) {
    if ((char)param_1[2] < '\0') {
      sVar7 = func_0x(param_1 + 0x60);
      uVar12 = *(ushort *)(param_1 + 0x1c);
      uVar8 = sVar7 + 0x60;
    }
    else {
      uVar8 = 0x60;
    }
    uStack_158 = (uint)uVar12;
    uStack_150 = 0x2000 - uVar8;
    func_0x(0x22eb,param_1,0x1342f70,8);
  }
  if ((((uint)*(ushort *)(param_1 + 0x1e) & (1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1U) !=
       0) && (iVar15 = iVar15 + 1, param_3 == 2)) {
    func_0x(param_1,0x1343360,9);
  }
  uVar8 = *(ushort *)(param_1 + 0x16);
  if (((0xfcf < uVar8) && (iVar15 = iVar15 + 1, param_3 != 0)) && (param_3 == 2)) {
    uStack_150 = 0xfd0;
    uStack_158 = (uint)uVar8;
    func_0x(0x22eb,param_1,0x1343320,10);
    uVar8 = *(ushort *)(param_1 + 0x16);
  }
  if (((uVar8 < *(ushort *)(param_1 + 0x3a)) && (iVar15 = iVar15 + 1, param_3 != 0)) &&
     (param_3 == 2)) {
    uStack_150 = (uint)uVar8;
    uStack_158 = (uint)*(ushort *)(param_1 + 0x3a);
    func_0x(0x22eb,param_1,0x13432d0,0xb);
    uVar8 = *(ushort *)(param_1 + 0x16);
  }
  if (uVar8 != 0) {
    if ((char)param_1[2] < '\0') {
      sVar7 = func_0x(param_1 + 0x60);
      uVar8 = sVar7 + 0x60;
    }
    else {
      uVar8 = 0x60;
    }
    uVar12 = *(ushort *)(param_1 + 0x1ffe);
    if (((uVar12 < uVar8) && (uVar12 != 0)) &&
       ((iVar15 = iVar15 + 1, param_3 != 0 && (param_3 == 2)))) {
      if ((char)param_1[2] < '\0') {
        sVar7 = func_0x(param_1 + 0x60);
        uVar12 = *(ushort *)(param_1 + 0x1ffe);
        uVar8 = sVar7 + 0x60;
      }
      else {
        uVar8 = 0x60;
      }
      uStack_150 = (uint)uVar8;
      uStack_158 = (uint)uVar12;
      func_0x(0x22eb,param_1,0x13431e0,0x33);
      uVar12 = *(ushort *)(param_1 + 0x1ffe);
    }
    if ((0x1fff < uVar12) && (iVar15 = iVar15 + 1, param_3 == 2)) {
      uStack_150 = 0x2000;
      uStack_158 = (uint)uVar12;
      func_0x(0x22eb,param_1,0x13434a0,0x34);
    }
  }
  if (((*(short *)(param_1 + 0xc) == 0) && (*(uint *)(param_1 + 8) != 0)) &&
     (iVar15 = iVar15 + 1, param_3 == 2)) {
    uStack_150 = 0;
    uStack_158 = *(uint *)(param_1 + 8);
    func_0x(0x22eb,param_1,0x1343450,0x36);
  }
  if (((*(short *)(param_1 + 0x14) == 0) && (*(uint *)(param_1 + 0x10) != 0)) &&
     (iVar15 = iVar15 + 1, param_3 == 2)) {
    uStack_150 = 0;
    uStack_158 = *(uint *)(param_1 + 0x10);
    func_0x(0x22eb,param_1,0x1343400,0x38);
  }
  if (((*(short *)(param_1 + 0x24) == 0) && (*(uint *)(param_1 + 0x20) != 0)) &&
     (iVar15 = iVar15 + 1, param_3 == 2)) {
    uStack_150 = 0;
    uStack_158 = *(uint *)(param_1 + 0x20);
    func_0x(0x22eb,param_1,0x13433b0,0x3a);
  }
  if (iVar15 == 0) {
    if (param_2 == 2) goto LAB_;
    iVar9 = 0;
    if ((char)param_1[2] < '\0') {
      uVar8 = func_0x(param_1 + 0x60);
      bVar3 = param_1[1];
      if (((1 < (byte)(bVar3 - 1)) && (bVar3 != 0x13)) && (iVar9 = 1, param_3 == 2)) {
        uStack_150 = (uint)bVar3;
        uStack_158 = (uint)param_1[2];
        func_0x(0x22eb,param_1,0x1343590,0x2d);
      }
      if ((0x1fa0 < uVar8) && (iVar9 = iVar9 + 1, param_3 == 2)) {
        uStack_150 = 0x1fa0;
        uStack_158 = (uint)uVar8;
        func_0x(0x22eb,param_1,0x1343530,0x2f);
      }
    }
    uVar10 = param_1[1] - 1;
    if (uVar10 < 0xff) {
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)uVar10 + 0x101d94) * 4 + 0x101d68)
                   - 0x1432730);
                    /* WARNING: Could not emulate address calculation at 0x0010061c */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
    iVar15 = iVar9 + 1;
    if (param_3 == 2) {
      func_0x(0,param_1,5,param_1[1]);
    }
    if (((char)*(ushort *)(param_1 + 4) < '\0') && (iVar15 = iVar9 + 2, param_3 == 2)) {
      uStack_150 = 0x80;
      uStack_158 = (uint)*(ushort *)(param_1 + 4);
      func_0x(0x22eb,param_1,0x1343ef0,0x29);
    }
    if (iVar15 != 0) {
      if (((DAT_ & 0x40) == 0) &&
         (((lVar5 = *(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
           lVar5 == 0 || (lVar5 = **(longlong **)(lVar5 + 0x38), lVar5 == 0)) ||
          (iVar9 = (*_DAT_)(lVar5,0x279e), iVar9 == 0)))) goto LAB_;
      uVar13 = 0x1344230;
      goto LAB_;
    }
    if ((char)param_1[2] < '\0') {
      iVar15 = func_0x(param_3,param_1);
    }
    if (param_2 == 1) {
LAB_:
      if (param_1[1] != 7) {
        iVar9 = func_0x(param_1,param_2,param_3);
        iVar15 = iVar15 + iVar9;
      }
LAB_:
      if (param_2 != 1) goto LAB_;
    }
    else {
      if (param_1[1] == 7) goto LAB_;
      if ((DAT_ & 0x80) != 0) goto LAB_;
      uVar8 = *(ushort *)(param_1 + 0x16);
      uStack_144 = 0;
      iStack_148 = 0;
      if (uVar8 != 0) {
        lStack_108 = 0;
        do {
          lVar5 = lStack_108;
          if ((*(ushort *)(param_1 + 4) & 0x1000) != 0) {
            uVar10 = (uint)*(ushort *)(param_1 + 0xe) * iStack_148 + 0x60;
            if ((*(ushort *)(param_1 + (0xfff - lStack_108) * 2) != uVar10) &&
               (iVar15 = iVar15 + 1, param_3 == 2)) {
              uStack_158 = (uint)*(ushort *)(param_1 + (0xfff - lStack_108) * 2);
              uStack_150 = uVar10;
              func_0x(0x22eb,param_1,0x1344190,0x2b);
            }
          }
          puStack_130 = (ushort *)(param_1 + (0xfff - lVar5) * 2);
          if (*(short *)(param_1 + (0xfff - lVar5) * 2) != 0) {
            iStack_c4 = iStack_148;
            if (-1 < (char)param_1[2]) goto LAB_;
            pbVar1 = param_1 + 0x60;
            if ((sStack_f8 == 0) || (ppbVar14 = ppbStack_e8, ppbStack_e8 == (byte **)0x0)) {
              uStack_98 = 0;
              stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
              auStack_b0._0_2_ = 0xffff;
              uStack_8a = 0;
              uStack_a8 = 0;
              uStack_92 = 0;
              uStack_90 = 0;
              uStack_88 = 0;
              uStack_a0 = 0;
              auStack_80 = ZEXT816(0);
              auStack_60._0_12_ = ZEXT812(0);
              auStack_60._12_4_ = 0;
              uStack_50 = 0;
              auStack_70 = ZEXT816(0);
              auStack_c0 = ZEXT816(0);
              ppbVar14 = (byte **)auStack_c0;
            }
            if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
              uStack_128 = *(undefined8 *)(param_1 + 0x28);
              uStack_120 = *(undefined2 *)(param_1 + 0x30);
            }
            else {
              bVar3 = param_1[1];
              if (bVar3 == 0xb) {
                if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
                  if (bVar3 != 9) goto LAB_;
                  goto LAB_;
                }
              }
              else {
                if (bVar3 != 8) goto LAB_;
LAB_:
                if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
              }
              uStack_118 = *(undefined4 *)(param_1 + 0x20);
              uStack_114 = *(undefined2 *)(param_1 + 0x24);
              cVar6 = func_0x(&uStack_118);
              if (cVar6 == '\0') goto LAB_;
              func_0x(param_1,&uStack_128);
            }
            *ppbVar14 = pbVar1;
            *(undefined4 *)(ppbVar14 + 0xc) = (undefined4)uStack_128;
            *(undefined2 *)(ppbVar14 + 0xd) = uStack_120;
            *(int *)((longlong)ppbVar14 + 100) = (int)((ulonglong)uStack_128 >> 0x20);
            *(undefined4 *)((longlong)ppbVar14 + 0x6c) = *(undefined4 *)(param_1 + 0x20);
            *(undefined2 *)(ppbVar14 + 0xe) = *(undefined2 *)(param_1 + 0x24);
            *(undefined2 *)((longlong)ppbVar14 + 0x72) = 0;
            uVar4 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1107700);
            uVar16 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1107704);
            *(undefined2 *)(ppbVar14 + 2) = 0xffff;
            ppbVar14[3] = (byte *)0x0;
            *(undefined4 *)((longlong)ppbVar14 + 0x14) = 0;
            *(undefined8 *)((longlong)ppbVar14 + 0x2e) = 0;
            ppbVar14[7] = (byte *)0x0;
            ppbVar14[4] = (byte *)0x0;
            ppbVar14[9] = (byte *)0x0;
            ppbVar14[10] = (byte *)0x0;
            *(undefined2 *)(ppbVar14 + 0xb) = 0;
            uStack_100 = uVar4;
            if ((**ppbVar14 & 2) != 0) {
              pbVar2 = pbVar1 + uVar16;
              if ((pbVar1[uVar16] & 1) == 0) {
                *(undefined2 *)(ppbVar14 + 2) = 0;
                ppbVar14[3] = pbVar2;
                *(undefined4 *)((longlong)ppbVar14 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar14 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101057 */
                    /* WARNING: Treating indirect jump as call */
                (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x101ec4) -
                          0x1432730))();
                return;
              }
              *(undefined2 *)(ppbVar14 + 2) = 1;
              ppbVar14[3] = pbVar2;
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((ulonglong)
                                      *(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x101ea4) * 4 +
                                     0x101e94) - 0x1432730);
                    /* WARNING: Could not emulate address calculation at 0x00100ec6 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            if ((**ppbVar14 & 4) != 0) {
              uStack_100._2_2_ = (short)((uint)uVar4 >> 0x10);
              if (uStack_100._2_2_ != 0) {
                uVar16 = (ulonglong)*(ushort *)(param_1 + (longlong)uStack_100._2_2_ * 2 + 0x61);
              }
              psVar11 = (short *)(pbVar1 + uVar16);
              ppbVar14[9] = (byte *)psVar11;
              sVar7 = *psVar11;
              ppbVar14[10] = (byte *)(psVar11 + 1);
              *(short *)(ppbVar14 + 0xb) = (sVar7 + 1) * 2;
            }
            if (ppbVar14[1] != (byte *)0x0) {
              func_0x(ppbVar14[1],ppbVar14);
            }
LAB_:
            pbStack_f0 = param_1 + *puStack_130;
            if ((*pbStack_f0 & 1) == 0) {
              sStack_f8 = 0;
              uStack_f4 = 0;
              uStack_d2 = 0;
              uStack_d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001012e9 */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_f0 & 0xe) * 4 + 0x101f30) -
                        0x1432730))(0xfffffffffebcd8d0,(longlong)(int)(*pbStack_f0 & 0xe),0);
              return;
            }
            sStack_f8 = 1;
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)
                                    *(byte *)((longlong)(int)(*pbStack_f0 & 0x1c) + 0x101f10) * 4 +
                                   0x101f00) - 0x1432730);
                    /* WARNING: Could not emulate address calculation at 0x00101156 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          iStack_148 = iStack_148 + 1;
          uVar8 = *(ushort *)(param_1 + 0x16);
          lStack_108 = lStack_108 + 1;
        } while (iStack_148 < (int)(uint)uVar8);
      }
      if ((char)param_1[2] < '\0') {
        sVar7 = func_0x(param_1 + 0x60);
        uVar8 = *(ushort *)(param_1 + 0x16);
        uVar12 = sVar7 + 0x60;
      }
      else {
        uVar12 = 0x60;
      }
      uVar10 = ((0x1000 - (uint)uVar8) * 2 - (uint)uVar12) - (uint)*(ushort *)(param_1 + 0x1c);
      if ((uVar10 != 0) && (iVar15 = iVar15 + 1, param_3 == 2)) {
        uStack_158 = 0;
        uStack_150 = uVar10;
        func_0x(0x22eb,param_1,0x1344398,0x27);
      }
      if (iVar15 != 0) {
        if (((DAT_ & 0x40) == 0) &&
           (((lVar5 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
             lVar5 == 0 || (lVar5 = **(longlong **)(lVar5 + 0x38), lVar5 == 0)) ||
            (iVar9 = (*_DAT_)(lVar5,0x279e), iVar9 == 0)))) goto LAB_;
        uVar13 = 0x1344310;
        goto LAB_;
      }
LAB_:
      if ((DAT_ & 0x80) == 0) goto LAB_;
    }
    if ((iVar15 == 0) ||
       (((DAT_ & 0x40) == 0 &&
        (((lVar5 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
          lVar5 == 0 || (lVar5 = **(longlong **)(lVar5 + 0x38), lVar5 == 0)) ||
         (iVar9 = (*_DAT_)(lVar5,0x279e), iVar9 == 0)))))) goto LAB_;
    uVar13 = 0x13442c0;
  }
  else {
    if (((DAT_ & 0x40) == 0) &&
       (((lVar5 = *(longlong *)
                   ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
         lVar5 == 0 || (lVar5 = **(longlong **)(lVar5 + 0x38), lVar5 == 0)) ||
        (iVar9 = (*_DAT_)(lVar5,0x279e), iVar9 == 0)))) goto LAB_;
    uVar13 = 0x1343670;
  }
LAB_:
  func_0x(uVar13,0x1342cb0,iVar15);
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_178);
  return;
}

