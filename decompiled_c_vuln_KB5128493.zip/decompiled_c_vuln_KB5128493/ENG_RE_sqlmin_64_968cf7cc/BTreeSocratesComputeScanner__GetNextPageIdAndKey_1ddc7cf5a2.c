
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 *param_3,undefined8 *param_4,
                 undefined4 *param_5,undefined8 *param_6)

{
  byte *pbVar1;
  byte bVar2;
  undefined2 uVar3;
  longlong lVar4;
  longlong **pplVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined8 uVar10;
  undefined8 *puVar11;
  byte **ppbVar12;
  ulonglong uVar13;
  longlong lVar14;
  ushort uVar15;
  short sVar16;
  short sVar17;
  byte *pbVar18;
  int *piVar19;
  longlong *plVar20;
  uint uVar21;
  ushort *puVar22;
  int *piVar23;
  longlong lVar24;
  undefined auStack_2c8 [32];
  undefined8 uStack_2a8;
  undefined8 uStack_2a0;
  int *piStack_298;
  uint uStack_290;
  undefined4 uStack_288;
  int iStack_284;
  uint uStack_280;
  undefined4 uStack_27c;
  undefined2 uStack_278;
  undefined8 uStack_270;
  longlong lStack_268;
  longlong *plStack_260;
  undefined4 uStack_258;
  uint uStack_254;
  uint auStack_250 [2];
  undefined8 uStack_248;
  undefined8 *puStack_240;
  undefined4 *puStack_238;
  undefined8 uStack_230;
  undefined2 uStack_228;
  undefined auStack_220 [4];
  undefined auStack_21c [4];
  undefined auStack_218 [8];
  undefined8 *puStack_210;
  undefined8 *puStack_208;
  short sStack_200;
  ushort uStack_1fe;
  uint uStack_1fc;
  int *piStack_1f8;
  undefined8 uStack_1f0;
  uint uStack_1e8;
  ushort uStack_1e4;
  byte *pbStack_1e2;
  undefined2 uStack_1da;
  undefined2 uStack_1d8;
  undefined2 uStack_1d6;
  ushort uStack_1d4;
  undefined2 uStack_1d2;
  undefined4 uStack_1d0;
  int iStack_1cc;
  undefined auStack_1c8 [16];
  undefined auStack_1b8 [16];
  undefined auStack_1a8 [16];
  undefined auStack_198 [16];
  undefined auStack_188 [16];
  undefined auStack_178 [16];
  undefined auStack_168 [16];
  undefined8 uStack_158;
  short sStack_150;
  ushort uStack_14e;
  undefined4 uStack_14c;
  byte *pbStack_148;
  undefined8 uStack_140;
  undefined2 uStack_138;
  short sStack_136;
  short sStack_134;
  longlong lStack_132;
  undefined2 uStack_12a;
  undefined2 uStack_128;
  undefined6 uStack_126;
  undefined4 uStack_120;
  uint uStack_11c;
  undefined auStack_118 [16];
  undefined auStack_108 [16];
  undefined auStack_f8 [16];
  undefined auStack_e8 [16];
  undefined auStack_d8 [16];
  undefined auStack_c8 [16];
  undefined auStack_b8 [16];
  undefined8 uStack_a8;
  ushort *apuStack_a0 [2];
  undefined auStack_90 [16];
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [16];
  uint auStack_50 [2];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_2c8;
  puStack_238 = param_5;
  uVar9 = *(uint *)(param_1 + 0xc);
  puStack_208 = param_6;
  lStack_268 = param_1;
  puStack_240 = param_3;
  puStack_210 = param_4;
  if ((uVar9 & 2) != 0) goto LAB_;
  plVar20 = (longlong *)(param_1 + 0x30);
  plStack_260 = plVar20;
  if (*plVar20 == 0) {
    uStack_2a8 = (uint *)0x0;
    uStack_2a0 = plVar20;
    func_0x(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_1 + 0x20));
    lVar14 = *(longlong *)(param_1 + 0x18);
    sStack_150 = -1;
    uStack_11c = 0xffffffff;
    pbStack_148 = (byte *)0x0;
    uStack_14c = 0;
    lStack_132 = 0;
    uStack_128 = 0;
    uStack_126 = 0;
    uStack_140 = (byte **)0x0;
    lVar4 = **(longlong **)(lVar14 + 0x68);
    lVar24 = *(longlong *)(lVar14 + 0xd8);
    if (*(int *)(lVar24 + 0x20) == 0) {
      lVar24 = *(longlong *)(lVar24 + 0x18);
    }
    else {
      lVar24 = *(longlong *)(lVar24 + 0x10);
    }
    piVar19 = (int *)(lVar4 + 0x20);
    uStack_248 = **(undefined8 **)(lVar14 + 8);
    uStack_270 = lVar24;
    if (((*piVar19 == *(int *)(lVar14 + 0x118)) &&
        (*(short *)(lVar4 + 0x24) == *(short *)(lVar14 + 0x11c))) &&
       (iVar7 = func_0x(), iVar7 == 0)) {
      uVar10 = func_0x(lVar4,auStack_90);
      iVar7 = func_0x(uVar10,lVar14 + 0x124);
      if (iVar7 == 0) goto LAB_;
    }
    else {
LAB_:
      func_0x(lVar14 + 0x118);
      *(int *)(lVar14 + 0x118) = *piVar19;
      *(undefined2 *)(lVar14 + 0x11c) = *(undefined2 *)(lVar4 + 0x24);
      puVar11 = (undefined8 *)func_0x(lVar4,auStack_80);
      *(undefined8 *)(lVar14 + 0x124) = *puVar11;
      *(undefined2 *)(lVar14 + 300) = *(undefined2 *)(puVar11 + 1);
      *(undefined4 *)(lVar14 + 0x130) = 1;
      if (*(int *)(lVar24 + 0x10) == 0) {
        uStack_280 = (uint)*(ushort *)(**(longlong **)(lVar14 + 0x68) + 0x16);
        uStack_11c = uStack_280 - 1;
        if (*(char *)(lVar4 + 2) < '\0') {
          pbVar18 = (byte *)(lVar4 + 0x60);
          if ((sStack_150 == 0) || (ppbVar12 = uStack_140, uStack_140 == (byte **)0x0)) {
            auStack_118 = ZEXT816(0);
            uStack_a8 = 0;
            auStack_108 = ZEXT816(0);
            auStack_f8 = ZEXT816(0);
            auStack_e8 = ZEXT816(0);
            auStack_d8 = ZEXT816(0);
            auStack_c8 = ZEXT816(0);
            auStack_b8 = ZEXT816(0);
            ppbVar12 = (byte **)func_0x(auStack_118);
          }
          uVar10 = func_0x(lVar4,auStack_70,0);
          if (pbVar18 == *ppbVar12) {
            func_0x(uVar10,ppbVar12 + 0xc);
          }
          *ppbVar12 = pbVar18;
          func_0x(ppbVar12 + 0xc,uVar10);
          func_0x((longlong)ppbVar12 + 0x6c,piVar19);
          uStack_27c = *(undefined4 *)((ulonglong)*pbVar18 * 6 + 0x16dac90);
          sVar17 = *(short *)((ulonglong)*pbVar18 * 6 + 0x16dac94);
          *(undefined2 *)(ppbVar12 + 2) = 0xffff;
          ppbVar12[3] = (byte *)0x0;
          uVar9 = 0;
          *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
          ppbVar12[7] = (byte *)0x0;
          ppbVar12[4] = (byte *)0x0;
          ppbVar12[9] = (byte *)0x0;
          ppbVar12[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar12 + 0xb) = 0;
          uStack_288 = CONCAT22(uStack_288._2_2_,sVar17);
          if ((**ppbVar12 & 2) != 0) {
            pbVar1 = pbVar18 + sVar17;
            if ((pbVar18[sVar17] & 1) == 0) {
              *(undefined2 *)(ppbVar12 + 2) = 0;
              ppbVar12[3] = pbVar1;
              *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar12 + 0x36) = 0;
              switch(*pbVar1 & 0xe) {
              default:
                uVar9 = (uint)*(ushort *)(pbVar1 + 2);
                if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                  func_0x(pbVar1,6);
                  sVar17 = (short)uStack_288;
                }
                break;
              case 4:
                uVar9 = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar9 = 1;
              }
              *(uint *)(ppbVar12 + 4) = uVar9;
              *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
            }
            else {
              *(undefined2 *)(ppbVar12 + 2) = 1;
              ppbVar12[3] = pbVar1;
              bVar2 = *pbVar1;
              switch(bVar2 & 0x1c) {
              default:
                if ((char)pbVar1[1] < '\0') {
                  uVar15 = *(ushort *)(pbVar1 + 1);
                  sVar16 = 3;
                  *(ushort *)((longlong)ppbVar12 + 0x12) = uVar15;
                  uVar15 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
                }
                else {
                  sVar16 = 2;
                  uVar15 = (ushort)pbVar1[1];
                }
                *(ushort *)((longlong)ppbVar12 + 0x12) = uVar15;
                *(short *)(ppbVar12 + 5) = sVar16;
                uVar15 = *(ushort *)((longlong)ppbVar12 + 0x12);
                *(short *)((longlong)ppbVar12 + 0x2c) = (short)(uVar15 + 1 >> 1) + sVar16;
                if (uVar15 < 0x1f) {
                  *(undefined2 *)((longlong)ppbVar12 + 0x2a) = 0;
                  *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
                  *(undefined4 *)(ppbVar12 + 8) = 0;
                  ppbVar12[7] = (byte *)0x0;
                  ppbVar12[4] = (byte *)0x0;
                }
                else {
                  iVar7 = uVar15 - 1;
                  *(short *)((longlong)ppbVar12 + 0x2a) =
                       ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                       (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
                  *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
                  *(undefined4 *)(ppbVar12 + 8) = 0;
                  ppbVar12[7] = (byte *)0x0;
                  ppbVar12[4] = (byte *)0x0;
                }
                break;
              case 4:
                if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
                  func_0x((longlong)ppbVar12 + 0x12);
                  *(undefined4 *)(ppbVar12 + 8) = 0;
                  ppbVar12[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0xf;
                  *(undefined4 *)(ppbVar12 + 8) = 1;
                  ppbVar12[7] = (byte *)0x0;
                  ppbVar12[4] = (byte *)0x0;
                  sVar17 = (short)uStack_288;
                }
                else {
                  func_0x((longlong)ppbVar12 + 0x12);
                  ppbVar12[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar12 + 0x14) = 1;
                  *(undefined4 *)(ppbVar12 + 8) = 0;
                  ppbVar12[7] = (byte *)0x0;
                  ppbVar12[4] = (byte *)0x0;
                  sVar17 = (short)uStack_288;
                }
                break;
              case 8:
                func_0x((longlong)ppbVar12 + 0x12);
                *(undefined4 *)(ppbVar12 + 8) = 0;
                ppbVar12[7] = (byte *)0x0;
                ppbVar12[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar12 + 0x14) = 9;
                ppbVar12[4] = (byte *)0x0;
                sVar17 = (short)uStack_288;
              }
            }
          }
          if ((**ppbVar12 & 4) != 0) {
            if (uStack_27c._2_2_ == 0) {
              uVar13 = (ulonglong)sVar17;
            }
            else {
              uVar13 = (ulonglong)*(ushort *)(lVar4 + 0x61 + (longlong)uStack_27c._2_2_ * 2);
            }
            func_0x(ppbVar12 + 9,pbVar18 + uVar13);
          }
          lVar24 = uStack_270;
          if (ppbVar12[1] != (byte *)0x0) {
            func_0x(ppbVar12[1],ppbVar12);
            lVar24 = uStack_270;
          }
        }
        else {
          ppbVar12 = (byte **)0x0;
        }
        uVar9 = (uint)*(ushort *)(lVar4 + 0xe);
        pbVar18 = (byte *)((ulonglong)*(ushort *)(lVar4 + (0x1000 - (longlong)(int)uStack_280) * 2)
                          + lVar4);
        pbStack_148 = pbVar18;
        if ((*pbVar18 & 1) == 0) {
          sStack_150 = 0;
          uStack_14c = 0;
          uStack_12a = 0;
          uStack_128 = 0;
          switch(*pbVar18 & 0xe) {
          default:
            uVar9 = (uint)*(ushort *)(pbVar18 + 2);
            if (0x1f9d < *(ushort *)(pbVar18 + 2) - 1) {
              func_0x(pbVar18,6);
            }
            break;
          case 4:
            uVar9 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar9 = 1;
          }
          lStack_132 = lVar4 + 0x2000;
          uStack_140 = (byte **)CONCAT44(uStack_140._4_4_,uVar9);
        }
        else {
          sStack_150 = 1;
          bVar2 = *pbVar18;
          switch(bVar2 & 0x1c) {
          default:
            if ((char)pbVar18[1] < '\0') {
              uStack_14e = (*(ushort *)(pbVar18 + 1) & 0x7f) << 8 | *(ushort *)(pbVar18 + 1) >> 8;
              uStack_138 = 3;
              sStack_134 = 3;
            }
            else {
              uStack_14e = (ushort)pbVar18[1];
              uStack_138 = 2;
              sStack_134 = 2;
            }
            sStack_134 = ((ushort)(uStack_14e + 1) >> 1) + sStack_134;
            if (uStack_14e < 0x1f) {
              sStack_136 = 0;
              uStack_14c = 0;
              uStack_120 = 0;
            }
            else {
              iVar7 = uStack_14e - 1;
              uStack_14c = 0;
              uStack_120 = 0;
              sStack_136 = ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                           (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
            }
            break;
          case 4:
            if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
              func_0x(&uStack_14e);
              uStack_14c = 0xf;
              uStack_120 = 1;
            }
            else {
              func_0x(&uStack_14e);
              uStack_120 = 0;
              uStack_14c = 1;
            }
            break;
          case 8:
            func_0x(&uStack_14e);
            uStack_120 = 0;
            uStack_14c = 9;
          }
          uStack_128 = (undefined2)(lVar4 + 0x2000);
          uStack_126 = (undefined6)((ulonglong)(lVar4 + 0x2000) >> 0x10);
          pbStack_148 = pbVar18;
          uStack_140 = ppbVar12;
        }
        uStack_2a8 = (uint *)CONCAT44(uStack_2a8._4_4_,1);
        uVar8 = func_0x(&sStack_150,lVar24,*(undefined4 *)(lVar24 + 8),uStack_248);
        *(undefined4 *)(lVar14 + 0x130) = uVar8;
        param_1 = lStack_268;
      }
    }
    if (*(int *)(lVar14 + 0x130) != 0) {
LAB_:
      uVar9 = *(uint *)(param_1 + 0xc);
      plVar20 = (longlong *)(param_1 + 0x30);
      goto LAB_;
    }
    uVar9 = *(uint *)(lVar14 + 0x80);
    uStack_280 = uVar9;
    uStack_11c = uVar9;
    if (*(char *)(lVar4 + 2) < '\0') {
      pbVar18 = (byte *)(lVar4 + 0x60);
      if ((sStack_150 == 0) || (ppbVar12 = uStack_140, uStack_140 == (byte **)0x0)) {
        auStack_118 = ZEXT816(0);
        uStack_a8 = 0;
        auStack_108 = ZEXT816(0);
        auStack_f8 = ZEXT816(0);
        auStack_e8 = ZEXT816(0);
        auStack_d8 = ZEXT816(0);
        auStack_c8 = ZEXT816(0);
        auStack_b8 = ZEXT816(0);
        ppbVar12 = (byte **)func_0x(auStack_118);
      }
      uVar10 = func_0x(lVar4,apuStack_a0,0,0);
      if (pbVar18 == *ppbVar12) {
        func_0x(uVar10,ppbVar12 + 0xc);
      }
      *ppbVar12 = pbVar18;
      func_0x(ppbVar12 + 0xc,uVar10);
      func_0x((longlong)ppbVar12 + 0x6c,lVar4 + 0x20);
      uStack_27c = *(undefined4 *)((ulonglong)*pbVar18 * 6 + 0x16dac90);
      sVar17 = *(short *)((ulonglong)*pbVar18 * 6 + 0x16dac94);
      *(undefined2 *)(ppbVar12 + 2) = 0xffff;
      ppbVar12[3] = (byte *)0x0;
      uVar21 = 0;
      *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
      ppbVar12[7] = (byte *)0x0;
      ppbVar12[4] = (byte *)0x0;
      ppbVar12[9] = (byte *)0x0;
      ppbVar12[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar12 + 0xb) = 0;
      uStack_288 = CONCAT22(uStack_288._2_2_,sVar17);
      if ((**ppbVar12 & 2) != 0) {
        pbVar1 = pbVar18 + sVar17;
        if ((pbVar18[sVar17] & 1) == 0) {
          *(undefined2 *)(ppbVar12 + 2) = 0;
          ppbVar12[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar12 + 0x36) = 0;
          switch(*pbVar1 & 0xe) {
          default:
            uVar21 = (uint)*(ushort *)(pbVar1 + 2);
            if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
              func_0x(pbVar1,6);
            }
            break;
          case 4:
            uVar21 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar21 = 1;
          }
          *(uint *)(ppbVar12 + 4) = uVar21;
          *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
          uVar9 = uStack_280;
        }
        else {
          *(undefined2 *)(ppbVar12 + 2) = 1;
          ppbVar12[3] = pbVar1;
          bVar2 = *pbVar1;
          switch(bVar2 & 0x1c) {
          default:
            if ((char)pbVar1[1] < '\0') {
              uVar15 = *(ushort *)(pbVar1 + 1);
              sVar17 = 3;
              *(ushort *)((longlong)ppbVar12 + 0x12) = uVar15;
              uVar15 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
            }
            else {
              sVar17 = 2;
              uVar15 = (ushort)pbVar1[1];
            }
            *(ushort *)((longlong)ppbVar12 + 0x12) = uVar15;
            *(short *)(ppbVar12 + 5) = sVar17;
            uVar15 = *(ushort *)((longlong)ppbVar12 + 0x12);
            *(short *)((longlong)ppbVar12 + 0x2c) = (short)(uVar15 + 1 >> 1) + sVar17;
            if (uVar15 < 0x1f) {
              *(undefined2 *)((longlong)ppbVar12 + 0x2a) = 0;
              *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
              *(undefined4 *)(ppbVar12 + 8) = 0;
              ppbVar12[7] = (byte *)0x0;
              ppbVar12[4] = (byte *)0x0;
            }
            else {
              iVar7 = uVar15 - 1;
              *(short *)((longlong)ppbVar12 + 0x2a) =
                   ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                   (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
              *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
              *(undefined4 *)(ppbVar12 + 8) = 0;
              ppbVar12[7] = (byte *)0x0;
              ppbVar12[4] = (byte *)0x0;
            }
            break;
          case 4:
            if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
              func_0x((longlong)ppbVar12 + 0x12);
              *(undefined4 *)(ppbVar12 + 8) = 0;
              ppbVar12[3] = pbVar1;
              *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0xf;
              *(undefined4 *)(ppbVar12 + 8) = 1;
              ppbVar12[7] = (byte *)0x0;
              ppbVar12[4] = (byte *)0x0;
            }
            else {
              func_0x((longlong)ppbVar12 + 0x12);
              ppbVar12[3] = pbVar1;
              *(undefined4 *)((longlong)ppbVar12 + 0x14) = 1;
              *(undefined4 *)(ppbVar12 + 8) = 0;
              ppbVar12[7] = (byte *)0x0;
              ppbVar12[4] = (byte *)0x0;
            }
            break;
          case 8:
            func_0x((longlong)ppbVar12 + 0x12);
            ppbVar12[3] = pbVar1;
            *(undefined4 *)(ppbVar12 + 8) = 0;
            ppbVar12[7] = (byte *)0x0;
            *(undefined4 *)((longlong)ppbVar12 + 0x14) = 9;
            ppbVar12[4] = (byte *)0x0;
          }
        }
        sVar17 = (short)uStack_288;
      }
      if ((**ppbVar12 & 4) != 0) {
        if (uStack_27c._2_2_ == 0) {
          uVar13 = (ulonglong)sVar17;
        }
        else {
          uVar13 = (ulonglong)*(ushort *)(lVar4 + 0x61 + (longlong)uStack_27c._2_2_ * 2);
        }
        func_0x(ppbVar12 + 9,pbVar18 + uVar13);
      }
      if (ppbVar12[1] != (byte *)0x0) {
        func_0x(ppbVar12[1],ppbVar12);
      }
    }
    else {
      ppbVar12 = (byte **)0x0;
    }
    uVar21 = (uint)*(ushort *)(lVar4 + 0xe);
    pbVar18 = (byte *)((ulonglong)*(ushort *)(lVar4 + (0xfff - (longlong)(int)uVar9) * 2) + lVar4);
    pbStack_148 = pbVar18;
    if ((*pbVar18 & 1) == 0) {
      sStack_150 = 0;
      uStack_14c = 0;
      uStack_12a = 0;
      uStack_128 = 0;
      switch(*pbVar18 & 0xe) {
      default:
        uVar21 = (uint)*(ushort *)(pbVar18 + 2);
        if (0x1f9d < *(ushort *)(pbVar18 + 2) - 1) {
          func_0x(pbVar18,6);
        }
        break;
      case 4:
        uVar21 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar21 = 1;
      }
      lStack_132 = lVar4 + 0x2000;
      uStack_140 = (byte **)CONCAT44(uStack_140._4_4_,uVar21);
    }
    else {
      sStack_150 = 1;
      bVar2 = *pbVar18;
      switch(bVar2 & 0x1c) {
      default:
        if ((char)pbVar18[1] < '\0') {
          uStack_14e = (*(ushort *)(pbVar18 + 1) & 0x7f) << 8 | *(ushort *)(pbVar18 + 1) >> 8;
          uStack_138 = 3;
          sStack_134 = 3;
        }
        else {
          uStack_14e = (ushort)pbVar18[1];
          uStack_138 = 2;
          sStack_134 = 2;
        }
        sStack_134 = ((ushort)(uStack_14e + 1) >> 1) + sStack_134;
        if (uStack_14e < 0x1f) {
          sStack_136 = 0;
          uStack_14c = 0;
          uStack_120 = 0;
        }
        else {
          iVar7 = uStack_14e - 1;
          uStack_14c = 0;
          uStack_120 = 0;
          sStack_136 = ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                       (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
        }
        break;
      case 4:
        if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
          func_0x(&uStack_14e);
          uStack_14c = 0xf;
          uStack_120 = 1;
        }
        else {
          func_0x(&uStack_14e);
          uStack_120 = 0;
          uStack_14c = 1;
        }
        break;
      case 8:
        func_0x(&uStack_14e);
        uStack_120 = 0;
        uStack_14c = 9;
      }
      uStack_128 = (undefined2)(lVar4 + 0x2000);
      uStack_126 = (undefined6)((ulonglong)(lVar4 + 0x2000) >> 0x10);
      pbStack_148 = pbVar18;
      uStack_140 = ppbVar12;
    }
    uStack_2a8 = (uint *)CONCAT44(uStack_2a8._4_4_,1);
    iVar7 = func_0x
                      (&sStack_150,uStack_270,*(undefined4 *)(uStack_270 + 8),uStack_248);
    param_1 = lStack_268;
    if (iVar7 != 0) goto LAB_;
    *plStack_260 = 0;
  }
  else {
    if ((uVar9 & 8) == 0) {
      func_0x(*(undefined8 *)(param_1 + 0x18),0,plVar20);
      uVar9 = *(uint *)(param_1 + 0xc);
    }
LAB_:
    *(uint *)(param_1 + 0xc) = uVar9 & 0xfffffff7;
    while( true ) {
      ppbVar12 = (byte **)0x0;
      pplVar5 = (longlong **)*plVar20;
      if (pplVar5 == (longlong **)0x0) break;
      if (*(int *)(pplVar5 + 5) == 0) {
        iVar7 = *(int *)(pplVar5 + 3);
        lVar14 = **pplVar5;
        plStack_260 = (longlong *)
                      (*(longlong *)(**(longlong **)(*(longlong *)(param_1 + 0x18) + 8) + 8) + 0x210
                      );
        apuStack_a0[0] = (ushort *)((0xfff - (longlong)iVar7) * 2 + lVar14);
        if ((*(byte *)((ulonglong)*apuStack_a0[0] + lVar14) & 1) == 0) {
          piVar19 = (int *)((byte *)((ulonglong)*apuStack_a0[0] + lVar14) + *(int *)plStack_260);
          iVar7 = iStack_284;
        }
        else {
          sStack_200 = 0xffff;
          piStack_1f8 = (int *)0x0;
          uStack_1fc = 0;
          pbStack_1e2 = (byte *)0x0;
          uStack_1d8 = 0;
          uStack_1d6 = 0;
          uStack_1d4 = 0;
          uStack_1d2 = 0;
          uStack_1f0 = (byte **)0x0;
          iStack_1cc = iVar7;
          if (*(char *)(lVar14 + 2) < '\0') {
            pbVar18 = (byte *)(lVar14 + 0x60);
            auStack_1c8 = ZEXT816(0);
            uStack_158 = 0;
            auStack_1b8 = ZEXT816(0);
            auStack_1a8 = ZEXT816(0);
            auStack_198 = ZEXT816(0);
            auStack_188 = ZEXT816(0);
            auStack_178 = ZEXT816(0);
            auStack_168 = ZEXT816(0);
            ppbVar12 = (byte **)func_0x(auStack_1c8);
            uVar10 = func_0x(lVar14,auStack_60,0);
            if (pbVar18 == *ppbVar12) {
              func_0x(uVar10,ppbVar12 + 0xc);
            }
            *ppbVar12 = pbVar18;
            func_0x(ppbVar12 + 0xc,uVar10);
            func_0x((longlong)ppbVar12 + 0x6c,lVar14 + 0x20);
            uVar13 = (ulonglong)*(short *)((ulonglong)*pbVar18 * 6 + 0x16dac94);
            uStack_270 = CONCAT44(uStack_270._4_4_,
                                  *(undefined4 *)((ulonglong)*pbVar18 * 6 + 0x16dac90));
            *(undefined2 *)(ppbVar12 + 2) = 0xffff;
            ppbVar12[3] = (byte *)0x0;
            uVar9 = 0;
            *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
            *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
            ppbVar12[7] = (byte *)0x0;
            ppbVar12[4] = (byte *)0x0;
            ppbVar12[9] = (byte *)0x0;
            ppbVar12[10] = (byte *)0x0;
            *(undefined2 *)(ppbVar12 + 0xb) = 0;
            if ((**ppbVar12 & 2) != 0) {
              pbVar1 = pbVar18 + uVar13;
              if ((pbVar18[uVar13] & 1) == 0) {
                *(undefined2 *)(ppbVar12 + 2) = 0;
                ppbVar12[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar12 + 0x36) = 0;
                switch(*pbVar1 & 0xe) {
                default:
                  uVar9 = (uint)*(ushort *)(pbVar1 + 2);
                  if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                    func_0x(pbVar1,6);
                  }
                  break;
                case 4:
                  uVar9 = 9;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar9 = 1;
                }
                *(uint *)(ppbVar12 + 4) = uVar9;
                *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
              }
              else {
                *(undefined2 *)(ppbVar12 + 2) = 1;
                ppbVar12[3] = pbVar1;
                bVar2 = *pbVar1;
                switch(bVar2 & 0x1c) {
                default:
                  if ((char)pbVar1[1] < '\0') {
                    uVar15 = *(ushort *)(pbVar1 + 1);
                    sVar17 = 3;
                    *(ushort *)((longlong)ppbVar12 + 0x12) = uVar15;
                    uVar15 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
                  }
                  else {
                    sVar17 = 2;
                    uVar15 = (ushort)pbVar1[1];
                  }
                  *(ushort *)((longlong)ppbVar12 + 0x12) = uVar15;
                  *(short *)(ppbVar12 + 5) = sVar17;
                  uVar15 = *(ushort *)((longlong)ppbVar12 + 0x12);
                  *(short *)((longlong)ppbVar12 + 0x2c) = (short)(uVar15 + 1 >> 1) + sVar17;
                  if (uVar15 < 0x1f) {
                    *(undefined2 *)((longlong)ppbVar12 + 0x2a) = 0;
                    *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
                    *(undefined4 *)(ppbVar12 + 8) = 0;
                    ppbVar12[7] = (byte *)0x0;
                    ppbVar12[4] = (byte *)0x0;
                  }
                  else {
                    iVar7 = uVar15 - 1;
                    *(short *)((longlong)ppbVar12 + 0x2a) =
                         ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                         (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
                    *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
                    *(undefined4 *)(ppbVar12 + 8) = 0;
                    ppbVar12[7] = (byte *)0x0;
                    ppbVar12[4] = (byte *)0x0;
                  }
                  break;
                case 4:
                  if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
                    func_0x((longlong)ppbVar12 + 0x12);
                    *(undefined4 *)(ppbVar12 + 8) = 0;
                    ppbVar12[3] = pbVar1;
                    *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0xf;
                    *(undefined4 *)(ppbVar12 + 8) = 1;
                    ppbVar12[7] = (byte *)0x0;
                    ppbVar12[4] = (byte *)0x0;
                  }
                  else {
                    func_0x((longlong)ppbVar12 + 0x12);
                    ppbVar12[3] = pbVar1;
                    *(undefined4 *)((longlong)ppbVar12 + 0x14) = 1;
                    *(undefined4 *)(ppbVar12 + 8) = 0;
                    ppbVar12[7] = (byte *)0x0;
                    ppbVar12[4] = (byte *)0x0;
                  }
                  break;
                case 8:
                  func_0x((longlong)ppbVar12 + 0x12);
                  ppbVar12[3] = pbVar1;
                  *(undefined4 *)(ppbVar12 + 8) = 0;
                  ppbVar12[7] = (byte *)0x0;
                  *(undefined4 *)((longlong)ppbVar12 + 0x14) = 9;
                  ppbVar12[4] = (byte *)0x0;
                }
              }
            }
            if ((**ppbVar12 & 4) != 0) {
              if (uStack_270._2_2_ != 0) {
                uVar13 = (ulonglong)*(ushort *)(lVar14 + 0x61 + (longlong)uStack_270._2_2_ * 2);
              }
              func_0x(ppbVar12 + 9,pbVar18 + uVar13);
            }
            if (ppbVar12[1] != (byte *)0x0) {
              func_0x(ppbVar12[1],ppbVar12);
            }
          }
          plVar20 = plStack_260;
          uVar13 = (ulonglong)*(ushort *)(lVar14 + 0xe);
          piVar19 = (int *)((ulonglong)*apuStack_a0[0] + lVar14);
          piStack_1f8 = piVar19;
          if ((*(byte *)piVar19 & 1) == 0) {
            sStack_200 = 0;
            uStack_1fc = 0;
            uStack_1da = 0;
            uStack_1d8 = 0;
            switch(*(byte *)piVar19 & 0xe) {
            default:
              uVar13 = (ulonglong)*(ushort *)((longlong)piVar19 + 2);
              if (0x1f9d < *(ushort *)((longlong)piVar19 + 2) - 1) {
                func_0x(piVar19,6);
              }
              break;
            case 4:
              uVar13 = 9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar13 = 1;
            }
            pbStack_1e2 = (byte *)(lVar14 + 0x2000);
            uStack_1f0 = (byte **)CONCAT44(uStack_1f0._4_4_,(int)uVar13);
          }
          else {
            sStack_200 = 1;
            bVar2 = *(byte *)piVar19;
            switch(bVar2 & 0x1c) {
            default:
              if ((char)*(byte *)((longlong)piVar19 + 1) < '\0') {
                uStack_1fe = (*(ushort *)((longlong)piVar19 + 1) & 0x7f) << 8 |
                             *(ushort *)((longlong)piVar19 + 1) >> 8;
                uVar15 = 3;
                sVar17 = 3;
              }
              else {
                uStack_1fe = (ushort)*(byte *)((longlong)piVar19 + 1);
                uVar15 = 2;
                sVar17 = 2;
              }
              uStack_1e8 = (uint)uVar15;
              uStack_1e4 = (short)(uStack_1fe + 1 >> 1) + sVar17;
              if (uStack_1fe < 0x1f) {
                uStack_1fc = 0;
                uStack_1d0 = 0;
              }
              else {
                uStack_1fc = 0;
                uStack_1d0 = 0;
                uStack_1e8 = CONCAT22((short)((int)(uStack_1fe - 1) / 0x1e),uVar15);
              }
              break;
            case 4:
              if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
                func_0x(&uStack_1fe);
                uStack_1fc = 0xf;
                uStack_1d0 = 1;
              }
              else {
                func_0x(&uStack_1fe);
                uStack_1fc = 1;
                uStack_1d0 = 0;
              }
              break;
            case 8:
              func_0x(&uStack_1fe);
              uStack_1fc = 9;
              uStack_1d0 = 0;
            }
            lVar14 = lVar14 + 0x2000;
            uStack_1d8 = (undefined2)lVar14;
            uStack_1d6 = (undefined2)((ulonglong)lVar14 >> 0x10);
            uStack_1d4 = (ushort)((ulonglong)lVar14 >> 0x20);
            uStack_1d2 = (undefined2)((ulonglong)lVar14 >> 0x30);
            uVar13 = (ulonglong)ppbVar12 & 0xffffffff;
            piStack_1f8 = piVar19;
            uStack_1f0 = ppbVar12;
          }
          if (sStack_200 == 0) {
            if ((*(uint *)plVar20 & 0xc0000000) == 0x80000000) {
              iVar7 = func_0x(&uStack_1fe);
              if (iVar7 == 0) {
code_r0x00101b58:
                iStack_284 = 0;
                piVar19 = (int *)0x0;
                param_1 = lStack_268;
                iVar7 = iStack_284;
              }
              else {
                piVar19 = (int *)func_0x(&uStack_1d6,plVar20,&iStack_284,&uStack_248);
                param_1 = lStack_268;
                iVar7 = iStack_284;
              }
            }
            else {
              if ((*(byte *)((longlong)plVar20 + 6) & 0x10) == 0) {
                uStack_258 = 0;
                uStack_288 = 1;
              }
              else {
                uStack_2a8 = &uStack_288;
                func_0x(&uStack_1fe,plVar20,0,&uStack_258);
                if ((uStack_288 == 0) && ((*(byte *)((longlong)plVar20 + 6) & 0x10) != 0)) {
                  piVar19 = (int *)plVar20[1] + 1;
                  param_1 = lStack_268;
                  iVar7 = *(int *)plVar20[1];
                  goto code_r0x00101c08;
                }
                uVar13 = (ulonglong)uStack_1f0 & 0xffffffff;
              }
              if (*(int *)plVar20 < 0) {
                piVar19 = piStack_1f8;
                if (uStack_1fc == 0) {
                  uStack_1fe = 0;
                  uVar9 = (uint)uVar13;
                  if ((*(byte *)piStack_1f8 & 0x10) != 0) {
                    uVar9 = uVar9 + 2 + (*(ushort *)(uVar13 + (longlong)piStack_1f8) + 7 >> 3);
                  }
                  uStack_1f0 = (byte **)CONCAT44(uVar9,(undefined4)uStack_1f0);
                  if ((*(byte *)piStack_1f8 & 0x20) == 0) {
                    uVar13 = (ulonglong)uVar9;
                    uStack_1e4 = 0;
                    uStack_1fc = uVar9;
                    uStack_1e8 = uVar9;
                  }
                  else {
                    puVar22 = (ushort *)((ulonglong)uVar9 + (longlong)piStack_1f8);
                    uStack_1e4 = *puVar22;
                    if (uStack_1e4 == 0) {
                      cVar6 = func_0x(0x1fed420);
                      if (((cVar6 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                         (*(char *)(lVar14 + 0x499) != '\0')) {
                        cVar6 = func_0x(0x1fed420);
                        if (cVar6 == '\0') {
                          (*pcRam000000000155bfa8)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          uStack_2a8 = (uint *)0x0;
                          (*pcRam000000000155bfa0)(1,0x18de1a8,0x19fde78,0x80f);
                        }
                      }
                      func_0x(piStack_1f8,3);
                    }
                    uStack_1e8 = uStack_1f0._4_4_ + (uStack_1e4 + 1) * 2;
                    if (0x1f9e < uStack_1e8) {
                      cVar6 = func_0x(0x1fed420);
                      if (((cVar6 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                         (*(char *)(lVar14 + 0x499) != '\0')) {
                        cVar6 = func_0x(0x1fed420);
                        if (cVar6 == '\0') {
                          (*pcRam000000000155bfa8)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_2a8 = (uint *)0x0;
                          (*pcRam000000000155bfa0)(1,0x18de1a8,0x19fde78,0x816);
                        }
                      }
                      func_0x(piStack_1f8,4);
                    }
                    uStack_1fc = puVar22[uStack_1e4] & 0x7fff;
                    if (uStack_1fc < uStack_1e8) {
                      cVar6 = func_0x(0x1fed420);
                      if (((cVar6 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                         (*(char *)(lVar14 + 0x499) != '\0')) {
                        cVar6 = func_0x(0x1fed420);
                        if (cVar6 == '\0') {
                          (*pcRam000000000155bfa8)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_2a8 = (uint *)0x0;
                          (*pcRam000000000155bfa0)(1,0x18de1a8,0x19fde78,0x81d);
                        }
                      }
                      func_0x(piStack_1f8,4);
                    }
                    uVar13 = (ulonglong)uStack_1fc;
                    piVar19 = piStack_1f8;
                    do {
                      if (-1 < (short)puVar22[(ulonglong)(uStack_1e4 - 1) + 1]) break;
                      uVar9 = uStack_1e8;
                      if (((uStack_1e4 != 1) &&
                          (uVar9 = *(ushort *)
                                    ((longlong)piVar19 +
                                    (ulonglong)uStack_1e4 * 2 +
                                    (((ulonglong)uStack_1f0 >> 0x20) - 2)) & 0x7fff,
                          uVar9 < uStack_1e8)) ||
                         ((*(ushort *)
                            ((longlong)piVar19 +
                            (ulonglong)uStack_1e4 * 2 + ((ulonglong)uStack_1f0 >> 0x20)) & 0x7fff) <
                          uVar9)) {
                        func_0x(piVar19,7);
                        uVar13 = (ulonglong)uStack_1fc;
                        piVar19 = piStack_1f8;
                      }
                      if ((uVar9 < uStack_1e8) || ((uint)uVar13 < uVar9)) goto code_r0x00101a5f;
                      if (*(ushort *)((ulonglong)uVar9 + (longlong)piVar19) == 5) {
                        uStack_1fe = uStack_1fe | 2;
                        uStack_1e4 = uStack_1e4 - 1;
                        uStack_1d6 = (undefined2)uVar9;
                        uVar15 = *(ushort *)((ulonglong)(uVar9 & 0xffff) + 2 + (longlong)piVar19);
                        if ((uVar15 >> 0xe & 1) == 0) {
                          uStack_1d4 = uStack_1d4 & 0xc7ff;
                        }
                        else {
                          uStack_1d4 = uStack_1d4 ^ (uVar15 ^ uStack_1d4) & 0x3800;
                        }
                        uStack_1d4 = uStack_1d4 ^
                                     (uStack_1d4 ^
                                     *(ushort *)
                                      ((ulonglong)(uVar9 & 0xffff) + 2 + (longlong)piVar19)) & 0x7ff
                        ;
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar9 + (longlong)piVar19) < 0x400) break;
                      uStack_1fe = uStack_1fe | 1;
                      uStack_1e4 = uStack_1e4 - 1;
                    } while (uStack_1e4 != 0);
                  }
                  if ((*(byte *)piVar19 & 0x40) == 0) {
                    uStack_1da = 0;
                    uStack_1d8 = 0;
                  }
                  else {
                    uStack_1da = (undefined2)uVar13;
                    uStack_1d8 = (undefined2)(uVar13 >> 0x10);
                    uStack_1fc = (int)uVar13 + 0xe;
                    uVar10 = func_0x(&uStack_1fe);
                    func_0x(uVar10,auStack_218);
                    iVar7 = func_0x(auStack_218);
                    uStack_1fc = uStack_1fc + iVar7;
                    uVar13 = (ulonglong)uStack_1fc;
                    piVar19 = piStack_1f8;
                  }
                  if ((pbStack_1e2 != (byte *)0x0) &&
                     (pbStack_1e2 < (byte *)(uVar13 + (longlong)piVar19))) {
                    cVar6 = func_0x(0x1fed420);
                    if ((cVar6 != '\0') &&
                       ((lVar14 = func_0x(), lVar14 != 0 &&
                        (*(char *)(lVar14 + 0x499) != '\0')))) {
                      cVar6 = func_0x(0x1fed420);
                      if (cVar6 == '\0') {
                        (*pcRam000000000155bfa8)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        uStack_2a8 = (uint *)0x0;
                        (*pcRam000000000155bfa0)(1,0x18de1a8,0x19fde78,0x877);
                      }
                    }
                    func_0x(piStack_1f8,0x12);
                    uVar13 = (ulonglong)uStack_1fc;
                    piVar19 = piStack_1f8;
                  }
                  if (0x3f3b < (int)uVar13 - 1U) {
                    cVar6 = func_0x(0x1fed420);
                    if (((cVar6 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                       (*(char *)(lVar14 + 0x499) != '\0')) {
                      cVar6 = func_0x(0x1fed420);
                      if (cVar6 == '\0') {
                        (*pcRam000000000155bfa8)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        uStack_2a8 = (uint *)0x0;
                        (*pcRam000000000155bfa0)(1,0x18de1a8,0x19fde78,0x87c);
                      }
                    }
                    func_0x(piStack_1f8,5);
                    piVar19 = piStack_1f8;
                  }
                }
code_r0x00101a5f:
                sVar17 = -*(short *)plVar20;
                if ((*(byte *)((longlong)plVar20 + 6) & 0x10) != 0) {
                  uStack_2a8 = auStack_250;
                  func_0x(&uStack_1fe,plVar20,0,auStack_21c);
                  piVar19 = piStack_1f8;
                  if (auStack_250[0] == 0) {
                    piVar19 = (int *)plVar20[1] + 1;
                    param_1 = lStack_268;
                    iVar7 = *(int *)plVar20[1];
                    goto code_r0x00101c08;
                  }
                }
                if ((uint)uStack_1e4 < (uint)(int)sVar17) {
                  iStack_284 = 0;
                  param_1 = lStack_268;
                  iVar7 = iStack_284;
                }
                else {
                  piVar23 = piVar19;
                  uVar9 = uStack_1e8;
                  if (sVar17 != 1) {
                    piVar23 = piStack_1f8;
                    uVar9 = *(ushort *)
                             ((longlong)piVar19 +
                             (longlong)sVar17 * 2 + (((ulonglong)uStack_1f0 >> 0x20) - 2)) & 0x7fff;
                  }
                  uVar21 = *(ushort *)
                            ((longlong)piVar19 +
                            (longlong)sVar17 * 2 + ((ulonglong)uStack_1f0 >> 0x20)) & 0x7fff;
                  if ((uVar9 < uStack_1e8) || (uVar21 < uVar9)) {
                    func_0x(piVar23,7);
                    piVar23 = piStack_1f8;
                  }
                  piVar19 = (int *)((ulonglong)uVar9 + (longlong)piVar23);
                  param_1 = lStack_268;
                  iVar7 = uVar21 - uVar9;
                }
              }
              else if ((*(ushort *)((longlong)plVar20 + 6) & 8) == 0) {
                if ((*(ushort *)((longlong)plVar20 + 6) & 0x10) != 0) {
                  uStack_2a8 = &uStack_254;
                  func_0x(&uStack_1fe,plVar20,0,auStack_220);
                  if (uStack_254 == 0) {
                    iVar7 = *(int *)plVar20[1];
                    piVar19 = (int *)plVar20[1] + 1;
                    param_1 = lStack_268;
                    if (iVar7 != 6) {
                      uStack_2a8 = (uint *)0x0;
                      (*pcRam000000000155bfa0)(1,0x1a8bf18,0x1a8a918,0x381);
                      param_1 = lStack_268;
                    }
                    goto code_r0x00101c08;
                  }
                }
                piVar19 = (int *)((longlong)*(int *)plVar20 + (longlong)piStack_1f8);
                param_1 = lStack_268;
                iVar7 = 6;
              }
              else {
                piVar19 = (int *)func_0x(&uStack_1fe,plVar20,&iStack_284);
                param_1 = lStack_268;
                iVar7 = iStack_284;
              }
            }
          }
          else {
            uStack_2a8 = &uStack_280;
            uStack_280 = 0;
            piVar19 = (int *)func_0x(&uStack_1fe,plVar20,0,&iStack_284);
            param_1 = lStack_268;
            iVar7 = iStack_284;
            if ((((sStack_200 != 0) && (uStack_1f0 != (byte **)0x0)) && (*uStack_1f0 != (byte *)0x0)
                ) && (((*(byte *)((longlong)plVar20 + 6) & 8) == 0 && ((uStack_280 & 1) == 0)))) {
              if ((piVar19 == (int *)0x0) || (piVar19 == (int *)0x1662be4)) goto code_r0x00101b58;
              uStack_290 = uStack_280;
              piStack_298 = &iStack_284;
              uStack_2a8 = auStack_50;
              uStack_2a0 = (longlong *)CONCAT44(uStack_2a0._4_4_,6);
              piVar19 = (int *)func_0x(uStack_1f0,plVar20,piVar19,iStack_284);
              param_1 = lStack_268;
              iVar7 = iStack_284;
            }
          }
        }
code_r0x00101c08:
        iStack_284 = iVar7;
        iVar7 = *piVar19;
        sVar17 = *(short *)(piVar19 + 1);
        plVar20 = (longlong *)(param_1 + 0x30);
      }
      else {
        iVar7 = *(int *)((longlong)pplVar5 + 0x34);
        sVar17 = *(short *)(pplVar5 + 7);
      }
      if ((*(short *)(param_1 + 0x28) == 0) || (*(short *)(param_1 + 0x28) == sVar17)) {
        *(int *)(puStack_210 + 1) = iVar7;
        *(short *)((longlong)puStack_210 + 0xc) = sVar17;
        *(undefined2 *)((longlong)puStack_210 + 0xe) = 0;
        *puStack_210 = 0;
        *(undefined4 *)((longlong)puStack_210 + 0x1c) = 0;
        puStack_210[2] = 0;
        *(undefined2 *)(puStack_210 + 3) = 0;
        break;
      }
      func_0x(*(undefined8 *)(param_1 + 0x18),0,plVar20);
    }
    if (*plVar20 != 0) {
      uStack_2a8 = (uint *)CONCAT44(uStack_2a8._4_4_,*(undefined4 *)(param_1 + 0x88));
      func_0x
                (*(undefined8 *)(param_1 + 0x18),*plVar20,*(undefined8 *)(param_1 + 0x80),
                 param_1 + 0x8c);
      *puStack_240 = *(undefined8 *)(param_1 + 0x80);
      lVar14 = **(longlong **)*plVar20;
      *puStack_238 = *(undefined4 *)(lVar14 + 0x34);
      *(undefined2 *)(puStack_238 + 1) = *(undefined2 *)(lVar14 + 0x38);
      lVar14 = **(longlong **)*plVar20;
      if (*(short *)(lVar14 + 0x24) != 0) {
        cVar6 = *(char *)(lVar14 + 1);
        if (cVar6 == '\v') {
          if (*(int *)(lVar14 + 0x18) != 99) {
LAB_:
            if (cVar6 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar6 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_27c = *(undefined4 *)(lVar14 + 0x20);
        uStack_278 = *(undefined2 *)(lVar14 + 0x24);
        cVar6 = func_0x(&uStack_27c);
        if (cVar6 != '\0') {
          func_0x(lVar14,&uStack_230);
          *puStack_208 = uStack_230;
          *(undefined2 *)(puStack_208 + 1) = uStack_228;
          goto LAB_;
        }
      }
LAB_:
      uVar3 = *(undefined2 *)(lVar14 + 0x30);
      *puStack_208 = *(undefined8 *)(lVar14 + 0x28);
      *(undefined2 *)(puStack_208 + 1) = uVar3;
      goto LAB_;
    }
    *puStack_240 = 0;
    *puStack_238 = _DAT_;
    *(undefined2 *)(puStack_238 + 1) = _DAT_;
  }
  func_0x(param_1);
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_2c8);
  return;
}

