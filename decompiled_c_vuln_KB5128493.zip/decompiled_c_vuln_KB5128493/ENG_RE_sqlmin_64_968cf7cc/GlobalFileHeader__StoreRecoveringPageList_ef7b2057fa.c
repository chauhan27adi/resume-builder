
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,ulonglong param_3)

{
  undefined2 uVar1;
  longlong lVar2;
  undefined8 uVar3;
  code *pcVar4;
  byte *pbVar5;
  uint **ppuVar6;
  char cVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  longlong lVar11;
  longlong lVar12;
  uint *puVar13;
  longlong lVar14;
  ulonglong *puVar15;
  ushort uVar16;
  ushort uVar17;
  short *psVar18;
  ulonglong uVar19;
  ushort *puVar20;
  short sVar21;
  longlong lVar22;
  longlong *plVar23;
  uint uVar24;
  ulonglong uVar25;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_4d0;
  undefined4 auStack_4c8 [8];
  undefined8 uStack_4a8;
  uint *apuStack_4a0 [3];
  undefined8 uStack_488;
  undefined uStack_480;
  uint uStack_47c;
  uint uStack_478;
  int iStack_470;
  short sStack_46c;
  short sStack_468;
  ushort uStack_466;
  uint uStack_464;
  byte *pbStack_460;
  undefined8 uStack_458;
  uint uStack_450;
  ushort uStack_44c;
  byte *pbStack_44a;
  undefined2 uStack_442;
  undefined2 uStack_440;
  undefined2 uStack_43e;
  ushort uStack_43c;
  undefined2 uStack_43a;
  short asStack_430 [2];
  undefined8 uStack_42c;
  undefined4 uStack_424;
  uint auStack_420 [2];
  undefined8 uStack_418;
  ushort uStack_410;
  undefined8 uStack_408;
  ushort uStack_400;
  undefined auStack_3f8 [4];
  undefined4 uStack_3f4;
  int iStack_3f0;
  undefined4 uStack_3ec;
  undefined2 uStack_3e8;
  undefined4 uStack_3e4;
  undefined2 uStack_3e0;
  undefined4 uStack_3dc;
  undefined2 uStack_3d8;
  undefined8 uStack_3d0;
  undefined2 uStack_3c8;
  undefined8 uStack_3c0;
  undefined2 uStack_3b8;
  undefined8 uStack_3b0;
  undefined2 uStack_3a8;
  undefined8 uStack_3a0;
  ushort uStack_398;
  undefined auStack_390 [4];
  undefined auStack_38c [4];
  undefined auStack_388 [4];
  undefined auStack_384 [4];
  longlong lStack_380;
  longlong *plStack_378;
  uint uStack_370;
  undefined8 uStack_36c;
  undefined8 uStack_358;
  undefined auStack_348 [8];
  undefined4 uStack_340;
  undefined4 uStack_338;
  uint **ppuStack_330;
  undefined *puStack_328;
  undefined8 uStack_320;
  uint *puStack_318;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  longlong lStack_308;
  undefined4 uStack_300;
  undefined4 uStack_2fc;
  longlong lStack_2f8;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  short *psStack_2e8;
  int iStack_2e0;
  undefined4 uStack_2dc;
  short *psStack_2d8;
  int iStack_2d0;
  undefined4 uStack_2cc;
  undefined8 uStack_2c8;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined auStack_2b8 [448];
  undefined8 uStack_f8;
  undefined8 uStack_f0;
  uint uStack_e8;
  short sStack_e4;
  int iStack_e2;
  undefined uStack_de;
  undefined uStack_dd;
  short asStack_a8 [24];
  short asStack_78 [24];
  ulonglong uStack_48;
  
  uStack_358 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_488;
  uStack_488 = (longlong *)0x0;
  uStack_480 = 0;
  uStack_47c = 0;
  sStack_468 = -1;
  pbStack_460 = (byte *)0x0;
  uStack_464 = 0;
  pbStack_44a = (byte *)0x0;
  uStack_440 = 0;
  uStack_43e = 0;
  uStack_43c = 0;
  uStack_43a = 0;
  uStack_458 = 0;
  uVar25 = (param_3 & 0xffffffff) * 4;
  plStack_378 = param_1;
  if (uVar25 < 0x100000000) {
    uVar24 = (int)uVar25 + 4;
    uVar19 = uVar25 & 0xffffffff;
    if (uVar24 < 4) goto LAB_;
  }
  else {
    uVar19 = 0xffffffff;
    uStack_4d0 = 0x1000bf;
    func_0x(0x80070216,param_3 & 0xffffffff,4);
LAB_:
    uStack_4d0 = 0x1000d7;
    func_0x(0x80070216,4,uVar19);
    uVar24 = 0xffffffff;
  }
  uVar19 = (ulonglong)uVar24;
  uStack_4d0 = 0x1000f6;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  lStack_380 = (longlong)&uStack_488 + lVar11;
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100118;
  func_0x((longlong)&uStack_488 + lVar11 + 4,uVar19 - 4,param_2,uVar25);
  lVar14 = param_1[1];
  if (lVar14 == 0) {
    *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100145;
    (*_DAT_)(1,0x152c7d8,0x14fbfd8,0xe67);
    lVar14 = param_1[1];
  }
  lVar12 = 0;
  sStack_46c = *(short *)(*param_1 + 0x20);
  iStack_470 = 0;
  uStack_36c = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar2 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar2 != 0) && (lVar2 = **(longlong **)(lVar2 + 0x38), lVar2 != 0)) {
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1001b9;
      iVar8 = (*_DAT_)(lVar2,0x337);
      if (iVar8 != 0) goto LAB_;
    }
    lVar2 = *(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8);
    if (lVar2 != 0) {
      lVar12 = *(longlong *)(lVar2 + 0x60);
    }
  }
LAB_:
  lVar2 = *(longlong *)(lVar14 + 0x728);
LAB_:
  plVar23 = uStack_488;
  auStack_420[0] = 0;
  if (uStack_488 != (longlong *)0x0) {
    iVar8 = (int)(short)uStack_47c;
    if (((*(ushort *)((longlong)uStack_488 + 0x62) & 0x400) == 0) || (iVar8 < 3)) {
      if (((byte)*(undefined2 *)((longlong)uStack_488 + 0x62) >> 3 & 1) != 0) {
        if (iVar8 == 3) {
          iVar8 = 4;
        }
        else if (iVar8 < 2) goto LAB_;
        if ((((*(uint *)((longlong)uStack_488 + 100) & 8) != 0) &&
            (lVar22 = uStack_488[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0)) {
          uVar3 = *(undefined8 *)(lVar22 + 0x758);
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10028c;
          func_0x(uVar3,plVar23,iVar8);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar23 + 100) & 8) != 0)) &&
         ((2 < iVar8 &&
          (((*(uint *)((longlong)plVar23 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar22 = *plVar23, lVar22 != 0)))))) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1002ce;
        iVar10 = (*_DAT_)(lVar22,0x2000,2,auStack_390);
        if (iVar10 != 0) {
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1002f0;
      func_0x(plVar23 + 0x13,iVar8);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10030f;
        func_0x(plVar23,0,iVar8);
      }
      uStack_47c = uStack_47c & 0xffff0000;
      uStack_488 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10022b;
      func_0x(&uStack_488);
    }
  }
  if (*(longlong *)(lVar14 + 0x728) != 0) {
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10033f;
    func_0x(&uStack_488,&iStack_470,lVar14);
    plVar23 = uStack_488;
    if (uStack_488 != (longlong *)0x0) {
      iVar8 = (int)(short)uStack_47c;
      if (((*(ushort *)((longlong)uStack_488 + 0x62) & 0x400) == 0) || (iVar8 < 3)) {
        if (((byte)*(undefined2 *)((longlong)uStack_488 + 0x62) >> 3 & 1) != 0) {
          if (iVar8 == 3) {
            iVar8 = 4;
          }
          else if (iVar8 < 2) goto LAB_;
          if ((((*(uint *)((longlong)uStack_488 + 100) & 8) != 0) &&
              (lVar22 = uStack_488[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0)) {
            uVar3 = *(undefined8 *)(lVar22 + 0x758);
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1003c8;
            func_0x(uVar3,plVar23,iVar8);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar23 + 100) & 8) != 0)) &&
           ((2 < iVar8 &&
            (((*(uint *)((longlong)plVar23 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar22 = *plVar23, lVar22 != 0)))))) {
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10040a;
          iVar10 = (*_DAT_)(lVar22,0x2000,2,auStack_38c);
          if (iVar10 != 0) {
            LOCK();
            *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10042c;
        func_0x(plVar23 + 0x13,iVar8);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10044b;
          func_0x(plVar23,0,iVar8);
        }
        uStack_47c = uStack_47c & 0xffff0000;
        uStack_488 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100367;
        func_0x(&uStack_488);
      }
    }
  }
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100464;
  func_0x(lVar14,&iStack_470);
  *(uint **)((longlong)apuStack_4a0 + lVar11) = &uStack_370;
  *(undefined4 *)((longlong)&uStack_4a8 + lVar11) = 4;
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10048f;
  uStack_488 = (longlong *)func_0x(_DAT_,lVar14,&iStack_470,auStack_420);
  if (lVar12 != 0) {
    uVar25 = (ulonglong)(*(uint *)(lVar12 + 0x500) & 0xf);
    if (*(longlong *)(lVar12 + 0x508 + uVar25 * 8) != *uStack_488) {
      *(longlong *)(lVar12 + 0x508 + uVar25 * 8) = *uStack_488;
      *(longlong *)(lVar12 + 0x500) = *(longlong *)(lVar12 + 0x500) + 1;
    }
  }
  uStack_47c = (auStack_420[0] >> 3 & 1) << 0x18 | uStack_47c & 0xff0004 | 4;
  uStack_478 = auStack_420[0] >> 4 & 1 | uStack_478 & 0xffffff00;
  if (((lVar2 != 0) && (lVar12 != 0)) && (lVar12 == *(longlong *)(lVar14 + 0x1c38))) {
    *(longlong *)(lVar2 + 0x5b28) = *(longlong *)(lVar2 + 0x5b28) + 1;
    if ((int)uStack_36c != 0) {
      *(longlong *)(lVar2 + 0x5b30) = *(longlong *)(lVar2 + 0x5b30) + 1;
      *(longlong *)(lVar2 + 0x5b38) = *(longlong *)(lVar2 + 0x5b38) + (ulonglong)uStack_370;
      if (0xffffff < uStack_47c) {
        *(longlong *)(lVar2 + 0x5b40) = *(longlong *)(lVar2 + 0x5b40) + 1;
        *(longlong *)(lVar2 + 0x5b48) = *(longlong *)(lVar2 + 0x5b48) + (ulonglong)uStack_370;
      }
    }
  }
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10055e;
  cVar7 = func_0x(lVar14);
  uVar25 = 9;
  if (((cVar7 == '\0') || (*(char *)(lVar14 + 0x2050) == '\0')) ||
     ((iStack_470 == 0 || ((iStack_470 == 9 && (sStack_46c == 1)))))) goto LAB_;
  lVar22 = *uStack_488;
  if (*(short *)(lVar22 + 0x24) == 0) {
LAB_:
    uStack_408 = *(undefined8 *)(lVar22 + 0x28);
    uStack_400 = *(ushort *)(lVar22 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar22 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar22 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar22 + 0x18) != 99) goto LAB_;
    }
    uStack_3ec = *(undefined4 *)(lVar22 + 0x20);
    uStack_3e8 = *(undefined2 *)(lVar22 + 0x24);
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1005e7;
    cVar7 = func_0x(&uStack_3ec);
    if (cVar7 == '\0') goto LAB_;
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1005fa;
    func_0x(lVar22,&uStack_408);
  }
  uVar24 = *(uint *)(lVar14 + 0x2108);
  do {
    uVar9 = uVar24 & 0xfffffffe;
    uStack_42c = *(undefined8 *)(lVar14 + 0x20fc);
    uStack_424 = *(undefined4 *)(lVar14 + 0x2104);
    LOCK();
    *(undefined4 *)((longlong)auStack_4c8 + lVar11) =
         *(undefined4 *)((longlong)auStack_4c8 + lVar11);
    UNLOCK();
    uVar24 = *(uint *)(lVar14 + 0x2108);
  } while (uVar9 != uVar24);
  if ((uint)uStack_408 <= (uint)uStack_42c) {
    if ((uint)uStack_42c != (uint)uStack_408) goto LAB_;
    uVar24 = (uint)((ulonglong)uStack_42c >> 0x20);
    if ((uStack_408._4_4_ <= uVar24) &&
       ((uVar24 != uStack_408._4_4_ || (uStack_400 <= (ushort)uStack_424)))) goto LAB_;
  }
  if ((*(char *)(lVar14 + 0x6ac8) == '\0') &&
     (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) != *(longlong *)(lVar14 + 0x2120))) {
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1006c3;
    cVar7 = func_0x(lVar14);
    if (cVar7 == '\0') {
      uVar24 = *(uint *)(lVar14 + 0x2108);
      do {
        uVar9 = uVar24 & 0xfffffffe;
        uVar3 = *(undefined8 *)(lVar14 + 0x20fc);
        uStack_42c = uVar3;
        uStack_424 = *(undefined4 *)(lVar14 + 0x2104);
        LOCK();
        *(undefined4 *)((longlong)auStack_4c8 + lVar11) =
             *(undefined4 *)((longlong)auStack_4c8 + lVar11);
        UNLOCK();
        uVar24 = *(uint *)(lVar14 + 0x2108);
      } while (uVar9 != uVar24);
      uVar17 = (ushort)uStack_424;
      uStack_398 = (ushort)uStack_424;
      lVar12 = *uStack_488;
      uStack_3a0 = uVar3;
      if (*(short *)(lVar12 + 0x24) == 0) {
LAB_:
        uStack_418 = *(undefined8 *)(lVar12 + 0x28);
        uStack_410 = *(ushort *)(lVar12 + 0x30);
      }
      else {
        cVar7 = *(char *)(lVar12 + 1);
        if (cVar7 == '\v') {
          if (*(int *)(lVar12 + 0x18) != 99) {
LAB_:
            if (cVar7 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar7 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar12 + 0x18) != 99) goto LAB_;
        }
        uStack_3dc = *(undefined4 *)(lVar12 + 0x20);
        uStack_3d8 = *(undefined2 *)(lVar12 + 0x24);
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1009a3;
        cVar7 = func_0x(&uStack_3dc);
        if (cVar7 == '\0') goto LAB_;
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1009b3;
        func_0x(lVar12,&uStack_418);
      }
      if ((uint)uStack_42c < (uint)uStack_418) {
LAB_:
        lVar12 = *(longlong *)(lVar14 + 0x6b0);
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100a18;
        func_0x(&uStack_418,asStack_a8,auStack_3f8);
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100a32;
        func_0x(&uStack_3a0,asStack_78,auStack_3f8);
        if ((_DAT_ & 0x10000) != 0) {
          uStack_340 = 0x60000;
          iVar8 = 0;
          uStack_338 = 0;
          ppuStack_330 = &puStack_318;
          puStack_328 = auStack_2b8;
          uStack_f8 = 0;
          uStack_320 = 0;
          uStack_f0 = 0;
          puStack_318 = &uStack_e8;
          uStack_310 = 0x34;
          uStack_30c = 5;
          uStack_300 = 0x10;
          uStack_2fc = 5;
          uStack_2f0 = 0x10;
          uStack_2ec = 6;
          psStack_2e8 = (short *)0x0;
          iStack_2e0 = 0;
          uStack_2dc = 7;
          psStack_2d8 = (short *)0x0;
          iStack_2d0 = 0;
          uStack_2cc = 8;
          uStack_2c8 = 0;
          uStack_2c0 = 0;
          uStack_2bc = 9;
          uStack_e8 = (uint)*(ushort *)(lVar14 + 0x6b8);
          sStack_e4 = sStack_46c;
          iStack_e2 = iStack_470;
          uStack_de = 0xff;
          uStack_dd = *(undefined *)(*uStack_488 + 1);
          lStack_308 = lVar12 + 0x254;
          lStack_2f8 = lVar12 + 0x244;
          lVar14 = -1;
          do {
            lVar14 = lVar14 + 1;
          } while (asStack_a8[lVar14] != 0);
          psStack_2e8 = asStack_a8;
          iStack_2e0 = (int)lVar14 * 2;
          lVar14 = -1;
          do {
            lVar14 = lVar14 + 1;
          } while (asStack_78[lVar14] != 0);
          iStack_2d0 = (int)lVar14 * 2;
          psStack_2d8 = asStack_78;
          uStack_3f4 = 0;
          pcVar4 = *(code **)(_DAT_ + 0x10);
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100bed;
          puVar13 = (uint *)(*pcVar4)(lVar12,&uStack_3f4);
          ppuVar6 = ppuStack_330;
          if (puVar13 != (uint *)0x0) {
            lVar14 = -1;
            do {
              lVar14 = lVar14 + 1;
            } while (*(short *)((longlong)puVar13 + lVar14 * 2) != 0);
            iVar8 = (int)lVar14 * 2;
          }
          ppuStack_330[10] = puVar13;
          *(int *)(ppuVar6 + 0xb) = iVar8;
          *(undefined4 *)((longlong)ppuVar6 + 0x5c) = 9;
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100c2d;
          func_0x(auStack_348);
        }
      }
      else if ((uint)uStack_42c == (uint)uStack_418) {
        uVar24 = (uint)((ulonglong)uStack_418 >> 0x20);
        if ((uStack_42c._4_4_ < uVar24) || ((uStack_42c._4_4_ == uVar24 && (uVar17 < uStack_410))))
        goto LAB_;
      }
LAB_:
      plVar23 = uStack_488;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100c53;
      lVar14 = func_0x(_DAT_,plVar23,1,0);
      *(ushort *)(lVar14 + 4) = *(ushort *)(lVar14 + 4) & 0xedff;
      *(undefined4 *)(lVar14 + 0x40) = 1;
      lVar14 = *uStack_488;
      if ((1 < *(ushort *)(lVar14 + 0x16)) && (*(short *)(lVar14 + 0x1ffc) != 0)) {
        *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100c8e;
        func_0x(lVar14,1,0,0);
      }
      sStack_468 = 0;
      *(undefined *)((longlong)apuStack_4a0 + lVar11) = 0;
      *(undefined4 *)((longlong)&uStack_4a8 + lVar11) = 0;
      lVar12 = lStack_380;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100cb0;
      func_0x(&uStack_466,lVar12);
      if (sStack_468 == 0) {
        uVar19 = (ulonglong)uStack_464;
        if (uStack_464 == 0) {
          uStack_466 = 0;
          uVar19 = uStack_458 & 0xffffffff;
          uVar24 = (uint)uStack_458;
          if ((*pbStack_460 & 0x10) != 0) {
            uVar24 = (uint)uStack_458 + 2 + (*(ushort *)(pbStack_460 + uVar19) + 7 >> 3);
            uVar19 = (ulonglong)uVar24;
          }
          uStack_458 = CONCAT44(uVar24,(uint)uStack_458);
          uStack_450 = (uint)uVar19;
          if ((*pbStack_460 & 0x20) == 0) {
            uStack_44c = 0;
            uStack_464 = uStack_450;
          }
          else {
            puVar20 = (ushort *)(pbStack_460 + uVar19);
            uStack_44c = *puVar20;
            if (uStack_44c == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar12 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0)) &&
                 ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                  (*(char *)(lVar12 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100d8b;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100dc5;
                  (*_DAT_)(1,0x1377228,0x1496ef8,0x80f);
                }
              }
              pbVar5 = pbStack_460;
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100d9b;
              func_0x(pbVar5,3);
            }
            uStack_450 = uStack_458._4_4_ + 2 + (uint)uStack_44c * 2;
            if (0x1f9e < uStack_450) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar12 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0 &&
                  ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                   (*(char *)(lVar12 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100e62;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100e86;
                  (*_DAT_)(1,0x1377228,0x1496ef8,0x816);
                }
              }
              pbVar5 = pbStack_460;
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100e94;
              func_0x(pbVar5,4);
            }
            uStack_464 = puVar20[uStack_44c] & 0x7fff;
            if (uStack_464 < uStack_450) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar12 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0)) &&
                 ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                  (*(char *)(lVar12 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100f32;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100f56;
                  (*_DAT_)(1,0x1377228,0x1496ef8,0x81d);
                }
              }
              pbVar5 = pbStack_460;
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100f64;
              func_0x(pbVar5,4);
            }
            uVar19 = (ulonglong)uStack_464;
            uVar24 = uStack_450;
            do {
              pbVar5 = pbStack_460;
              if (-1 < (short)puVar20[(ulonglong)(uStack_44c - 1) + 1]) break;
              uVar9 = uVar24;
              if (uStack_44c != 1) {
                uVar9 = *(ushort *)
                         (pbStack_460 + (ulonglong)uStack_44c * 2 + ((uStack_458 >> 0x20) - 2)) &
                        0x7fff;
              }
              if ((uVar9 < uVar24) ||
                 ((*(ushort *)(pbStack_460 + (ulonglong)uStack_44c * 2 + (uStack_458 >> 0x20)) &
                  0x7fff) < uVar9)) {
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100fd6;
                func_0x(pbVar5,7);
                uVar19 = (ulonglong)uStack_464;
                uVar24 = uStack_450;
              }
              if ((uVar9 < uVar24) || ((uint)uVar19 < uVar9)) goto LAB_;
              if (*(ushort *)(pbStack_460 + uVar9) == 5) {
                uStack_466 = uStack_466 | 2;
                uStack_44c = uStack_44c - 1;
                uVar24 = uVar9 & 0xffff;
                uStack_43e = (undefined2)uVar9;
                uVar17 = uStack_43c & 0xc7ff;
                if ((*(ushort *)(pbStack_460 + (ulonglong)uVar24 + 2) >> 0xe & 1) != 0) {
                  uVar17 = (uStack_43c ^ *(ushort *)(pbStack_460 + (ulonglong)uVar24 + 2)) & 0x3800
                           ^ uStack_43c;
                }
                uStack_43c = (uVar17 ^ *(ushort *)(pbStack_460 + (ulonglong)uVar24 + 2)) & 0x7ff ^
                             uVar17;
                break;
              }
              if (*(ushort *)(pbStack_460 + uVar9) < 0x400) break;
              uStack_466 = uStack_466 | 1;
              uStack_44c = uStack_44c - 1;
            } while (uStack_44c != 0);
          }
          iVar8 = 0;
          if ((*pbStack_460 & 0x40) == 0) {
            uStack_442 = 0;
            uStack_440 = 0;
          }
          else {
            uStack_442 = (undefined2)uVar19;
            uStack_440 = (undefined2)(uVar19 >> 0x10);
            uStack_464 = (int)uVar19 + 0xe;
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101052;
            puVar15 = (ulonglong *)func_0x(&uStack_466);
            uVar16 = (ushort)(*puVar15 >> 0x30);
            uVar17 = uVar16;
            if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
              uVar17 = uVar16 & 0xdfff;
              if ((uVar16 >> 0xe & 1) != 0) {
                uVar17 = uVar16 | 0x2000;
              }
            }
            if (uVar17 == 0xfffc) {
              iVar8 = (int)((*puVar15 >> 0x20 & 0xffff) >> 5);
            }
            uStack_464 = uStack_464 + iVar8;
            uVar19 = (ulonglong)uStack_464;
          }
          if ((pbStack_44a != (byte *)0x0) && (pbStack_44a < pbStack_460 + uVar19)) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar12 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar12 != 0 &&
                 (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
                (*(char *)(lVar12 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1011c2;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1011e6;
                (*_DAT_)(1,0x1377228,0x1496ef8,0x877);
              }
            }
            pbVar5 = pbStack_460;
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1011f4;
            func_0x(pbVar5,0x12);
            uVar19 = (ulonglong)uStack_464;
          }
          if (0x3f3b < (int)uVar19 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar12 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar12 != 0 &&
                ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                 (*(char *)(lVar12 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101281;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1012a5;
                (*_DAT_)(1,0x1377228,0x1496ef8,0x87c);
              }
            }
            pbVar5 = pbStack_460;
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1012b1;
            func_0x(pbVar5,5);
            uVar19 = (ulonglong)uStack_464;
          }
        }
LAB_:
        if ((8 < (uint)uVar19) || (((*pbStack_460 & 0xe) != 0 && ((*pbStack_460 & 0xe) != 0xc)))) {
          uVar25 = uVar19;
        }
      }
      else {
        if (uStack_464 == 0) {
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1012ea;
          func_0x(&uStack_466);
        }
        if ((8 < uStack_464) || (((*pbStack_460 & 0x1c) != 0 && ((*pbStack_460 & 0x1c) != 0xc)))) {
          uVar25 = (ulonglong)uStack_464;
        }
      }
      *(short **)((longlong)apuStack_4a0 + lVar11 + 8) = asStack_430;
      *(int **)((longlong)apuStack_4a0 + lVar11) = &iStack_3f0;
      *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101331;
      iVar8 = func_0x(lVar14,1,uVar25,0);
      sVar21 = 0;
      if (iVar8 == 0) {
        if (asStack_430[0] != 0) {
          uVar17 = *(ushort *)(lVar14 + 0x16);
          lVar12 = (ulonglong)uVar17 - 1;
          if ((longlong)(ulonglong)(ushort)(uVar17 - asStack_430[0]) <= lVar12) {
            psVar18 = (short *)(lVar14 + (0xfff - lVar12) * 2);
            do {
              if (*psVar18 != 0) break;
              sVar21 = sVar21 + 1;
              lVar12 = lVar12 + -1;
              psVar18 = psVar18 + 1;
            } while ((longlong)(ulonglong)(ushort)(uVar17 - asStack_430[0]) <= lVar12);
          }
          *(ushort *)(lVar14 + 0x16) = uVar17 - sVar21;
          *(short *)(lVar14 + 0x1c) = *(short *)(lVar14 + 0x1c) + sVar21 * 2;
        }
        if (iStack_3f0 != 0) {
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1013df;
          func_0x(lVar14,0xffffffff);
        }
      }
      else {
        *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101357;
        (*_DAT_)(1,0x152bec8,0x14fbfd8,0xe88);
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10136d;
        (*_DAT_)(0x24,0x18,0x14,100);
      }
      *(undefined8 *)((longlong)apuStack_4a0 + lVar11) = 0;
      *(undefined2 *)((longlong)&uStack_4a8 + lVar11) = 0;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1013fb;
      func_0x(lVar14,1,&sStack_468,0);
      plVar23 = uStack_488;
      uVar3 = *(undefined8 *)(plStack_378[1] + 0x758);
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101419;
      func_0x(uVar3,plVar23,0);
      plVar23 = uStack_488;
      uStack_3c0 = 0;
      uStack_3b8 = 0;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101445;
      func_0x(_DAT_,plVar23,0,&uStack_3c0);
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10144e;
      func_0x(&uStack_488);
      plVar23 = uStack_488;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101459;
      func_0x(plVar23,0);
      plVar23 = uStack_488;
      lVar14 = uStack_488[0x12];
      if (lVar14 == 0) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101471;
        func_0x(plVar23);
        lVar14 = plVar23[0x12];
      }
      uVar1 = *(undefined2 *)((longlong)plVar23 + 0x74);
      uVar3 = *(undefined8 *)(lVar14 + 0x6a0);
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10148c;
      lVar14 = func_0x(uVar3,uVar1,0);
      if ((((_DAT_ != 0) || ((_DAT_ & 0x40) != 0)) && ((_DAT_ & 8) == 0)) &&
         (*(short *)(lVar14 + 0x60) != 2)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1014b8;
        func_0x(lVar14,1);
      }
      plVar23 = uStack_488;
      if (uStack_488 == (longlong *)0x0) goto LAB_;
      iVar8 = (int)(short)uStack_47c;
      if (((*(ushort *)((longlong)uStack_488 + 0x62) >> 10 & 1) != 0) && (2 < iVar8)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1014e2;
        func_0x(&uStack_488);
        goto LAB_;
      }
      if (((byte)*(undefined2 *)((longlong)uStack_488 + 0x62) >> 3 & 1) != 0) {
        if (iVar8 == 3) {
          iVar8 = 4;
        }
        else if (iVar8 < 2) goto LAB_;
        if ((((*(uint *)((longlong)uStack_488 + 100) & 8) != 0) &&
            (lVar14 = uStack_488[0x12], lVar14 != 0)) && (*(longlong *)(lVar14 + 0x758) != 0)) {
          uVar3 = *(undefined8 *)(lVar14 + 0x758);
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101543;
          func_0x(uVar3,plVar23,iVar8);
        }
      }
LAB_:
      if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar23 + 100) & 8) != 0)) &&
          (2 < iVar8)) &&
         (((*(uint *)((longlong)plVar23 + 100) & 0xc0000000) != 0x40000000 &&
          (lVar14 = *plVar23, lVar14 != 0)))) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101587;
        iVar10 = (*_DAT_)(lVar14,0x2000,2,auStack_384);
        if (iVar10 != 0) {
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1015a9;
      func_0x(plVar23 + 0x13,iVar8);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1015c8;
        func_0x(plVar23,0,iVar8);
      }
      uStack_47c = uStack_47c & 0xffff0000;
      uStack_488 = (longlong *)0x0;
LAB_:
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1015de;
      func_0x(&uStack_488);
      uVar25 = uStack_48 ^ (ulonglong)&uStack_488;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1015ed;
      func_0x(uVar25);
      return;
    }
  }
  if (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) == *(longlong *)(lVar14 + 0x2120)) goto LAB_;
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100707;
  cVar7 = func_0x(lVar14);
  if (cVar7 != '\0') goto LAB_;
  if (lVar12 == 0) {
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100719;
    lVar12 = func_0x();
  }
  lVar22 = *uStack_488;
  if (*(short *)(lVar22 + 0x24) == 0) {
LAB_:
    uStack_3d0 = *(undefined8 *)(lVar22 + 0x28);
    uStack_3c8 = *(undefined2 *)(lVar22 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar22 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar22 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar22 + 0x18) != 99) goto LAB_;
    }
    uStack_3e4 = *(undefined4 *)(lVar22 + 0x20);
    uStack_3e0 = *(undefined2 *)(lVar22 + 0x24);
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100771;
    cVar7 = func_0x(&uStack_3e4);
    if (cVar7 == '\0') goto LAB_;
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100784;
    func_0x(lVar22,&uStack_3d0);
  }
  plVar23 = uStack_488;
  if (uStack_488 != (longlong *)0x0) {
    iVar8 = (int)(short)uStack_47c;
    if (((*(ushort *)((longlong)uStack_488 + 0x62) & 0x400) == 0) || (iVar8 < 3)) {
      if (((byte)*(undefined2 *)((longlong)uStack_488 + 0x62) >> 3 & 1) != 0) {
        if (iVar8 == 3) {
          iVar8 = 4;
        }
        else if (iVar8 < 2) goto LAB_;
        if ((((*(uint *)((longlong)uStack_488 + 100) & 8) != 0) &&
            (lVar22 = uStack_488[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0)) {
          uVar3 = *(undefined8 *)(lVar22 + 0x758);
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100832;
          func_0x(uVar3,plVar23,iVar8);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar23 + 100) & 8) != 0)) &&
         ((2 < iVar8 &&
          (((*(uint *)((longlong)plVar23 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar22 = *plVar23, lVar22 != 0)))))) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100876;
        iVar10 = (*_DAT_)(lVar22,0x2000,2,auStack_388);
        if (iVar10 != 0) {
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100898;
      func_0x(plVar23 + 0x13,iVar8);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1008b7;
        func_0x(plVar23,0,iVar8);
      }
      uStack_47c = uStack_47c & 0xffff0000;
      uStack_488 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1007d1;
      func_0x(&uStack_488);
    }
  }
  uStack_3b0 = uStack_3d0;
  uStack_3a8 = uStack_3c8;
  *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
  uVar3 = *(undefined8 *)(lVar14 + 0x728);
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100908;
  func_0x(uVar3,&uStack_3b0,4);
  goto LAB_;
}

