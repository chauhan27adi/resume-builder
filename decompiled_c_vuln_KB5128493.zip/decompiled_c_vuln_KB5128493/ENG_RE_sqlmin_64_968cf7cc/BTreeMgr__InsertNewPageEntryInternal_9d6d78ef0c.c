
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00f8460e) */
/* WARNING: Removing unreachable block (ram,0x00f82ab4) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,int param_6)

{
  longlong *plVar1;
  uint uVar2;
  int iVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong lVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  int *piVar12;
  undefined8 *puVar13;
  ulonglong uVar14;
  longlong lVar15;
  undefined2 uStack_e48;
  undefined auStack_e46 [2];
  undefined4 uStack_e44;
  longlong lStack_e40;
  undefined8 uStack_e38;
  undefined8 uStack_e2a;
  undefined8 uStack_e20;
  byte bStack_e10;
  char acStack_e0f [7];
  int *piStack_e08;
  uint uStack_e00;
  longlong alStack_df8 [2];
  longlong lStack_de8;
  longlong lStack_de0;
  longlong lStack_dd8;
  longlong lStack_dd0;
  undefined4 auStack_dc8 [3];
  uint uStack_dbc;
  int iStack_db8;
  int iStack_db4;
  undefined4 uStack_db0;
  undefined2 uStack_dac;
  undefined2 uStack_daa;
  longlong lStack_d98;
  int *piStack_d90;
  uint uStack_d88;
  undefined4 uStack_d84;
  longlong lStack_d80;
  longlong lStack_d78;
  undefined8 uStack_d70;
  undefined4 uStack_d68;
  longlong lStack_d40;
  undefined4 uStack_d38;
  uint uStack_d34;
  undefined4 uStack_d30;
  uint uStack_d2c;
  undefined4 uStack_d28;
  uint uStack_d24;
  undefined8 uStack_d20;
  uint uStack_d18;
  undefined4 uStack_d14;
  longlong *plStack_ce8;
  undefined8 uStack_ce0;
  longlong lStack_cd8;
  undefined8 uStack_cd0;
  longlong lStack_cc8;
  longlong **pplStack_cc0;
  undefined auStack_c98 [16];
  undefined auStack_aa8 [2656];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_e48;
  lVar8 = **(longlong **)(param_1 + 8);
  uStack_ce0 = param_5;
  lVar4 = *(longlong *)(lVar8 + 8);
  if (*(char *)(lVar4 + 0x106) < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = *(uint *)(**(longlong **)(lVar4 + 0x160) + 0x1c);
  uStack_db0 = *(undefined4 *)(lVar4 + 0x3c0);
  lStack_cc8 = (ulonglong)*(uint6 *)(lVar8 + 0x14) << 0x10;
  uStack_dac = *(undefined2 *)(lVar4 + 0x3c4);
  uStack_daa = 0;
  plStack_ce8 = *(longlong **)(lVar8 + 8);
  piStack_e08 = (int *)param_4;
  lStack_dd8 = lVar8;
  lStack_dd0 = param_1;
  uStack_cd0 = param_2;
  if (*(int *)(param_1 + 0x40) != 0) {
    (**(code **)(*plStack_ce8 + 0xa0))(plStack_ce8,param_2,param_5);
    lVar8 = *(longlong *)(*(longlong *)(lVar8 + 8) + 0x488);
    if (((lVar8 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar8 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      plVar1 = (longlong *)(*(longlong *)(lVar8 + 0x18) + 0x20);
      *plVar1 = *plVar1 + 1;
      UNLOCK();
    }
    func_0x(uStack_48 ^ (ulonglong)&uStack_e48);
    return;
  }
  lVar8 = *(longlong *)(param_1 + 0x138);
  lStack_e40 = 0;
  uStack_e44 = 0;
  iStack_db4 = *(int *)(param_1 + 0x30) + 1;
  if (param_6 != 0) {
    iStack_db4 = *(int *)(param_1 + 0x30);
  }
  uStack_e2a = 0;
  uStack_e20 = 0;
  uStack_e38 = 0;
  uStack_d84 = 0;
  auStack_c98 = ZEXT816(0);
  if (lVar8 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((short)uVar2 != *(short *)(lVar8 + 0x62)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(ushort *)(lVar8 + 0x60) != 0) &&
     (puVar10 = *(undefined4 **)(lVar8 + 0x70), puVar10 != (undefined4 *)0x0)) {
    uVar14 = (ulonglong)*(ushort *)(lVar8 + 0x60);
    uVar7 = uVar14;
    puVar9 = puVar10;
    do {
      *(ushort *)((longlong)puVar9 + 6) = *(ushort *)((longlong)puVar9 + 6) & 0xffe0;
      *(undefined *)(puVar9 + 0x10) = 0;
      puVar9[0x10] = puVar9[0x10] & 0xffffe0ff;
      *(undefined *)(puVar9 + 0x10) = 0x1c;
      puVar9[0x10] = puVar9[0x10] & 0xffc01fff;
      *puVar9 = 0;
      *(undefined2 *)(puVar9 + 1) = 0;
      *(undefined8 *)(puVar9 + 2) = 0;
      *(undefined8 *)(puVar9 + 10) = 0;
      *(undefined8 *)(puVar9 + 0xc) = 0;
      puVar9[0xe] = 0xffffffff;
      *(undefined2 *)(puVar9 + 4) = 0xffff;
      *(undefined8 *)(puVar9 + 0x12) = 0;
      puVar9 = puVar9 + 0x14;
      uVar7 = uVar7 - 1;
    } while (uVar7 != 0);
    puVar13 = (undefined8 *)(puVar10 + 0x12);
    do {
      *puVar13 = puVar9;
      func_0x(puVar10);
      puVar10 = puVar10 + 0x14;
      puVar13 = puVar13 + 10;
      puVar9 = puVar9 + 0xc;
      uVar14 = uVar14 - 1;
    } while (uVar14 != 0);
    if ((*(longlong *)(lVar8 + 0xe8) != 0) && (uVar7 = 0, *(short *)(lVar8 + 0x60) != 0)) {
      do {
        uVar11 = (int)uVar7 + 1;
        *(ulonglong *)(*(longlong *)(lVar8 + 0xe8) + uVar7 * 8) =
             uVar7 * 0x50 + *(longlong *)(lVar8 + 0x70);
        uVar7 = (ulonglong)uVar11;
      } while (uVar11 < *(ushort *)(lVar8 + 0x60));
    }
  }
  lVar6 = lStack_dd0;
  lVar15 = 0;
  lVar8 = *(longlong *)(lStack_dd8 + 8);
  if ((*(byte *)(lVar8 + 0x42) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar11 = *(uint *)(lVar8 + 0xb4);
  if (0xa58 < *(uint *)(lVar8 + 0xb4)) {
    uVar11 = 0xa58;
  }
  uVar11 = *(int *)(**(longlong **)(lVar8 + 0x160) + 0x1c) + uVar11;
  uVar2 = uVar11 + (uVar2 & 0xffff) * 9;
  if (uVar2 < uVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(lStack_dd0 + 0x140) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(uint *)(lStack_dd0 + 0x148) < uVar2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(lStack_dd8,piStack_e08,*(undefined8 *)(lStack_dd0 + 0x138),auStack_dc8,
                  *(longlong *)(lStack_dd0 + 0x140),*(uint *)(lStack_dd0 + 0x148));
  lVar8 = *(longlong *)(lVar6 + 0x138);
  pplStack_cc0 = (longlong **)(lVar6 + 0x18);
  uStack_e00 = 0;
  uStack_d28 = 2;
  lStack_cd8 = **pplStack_cc0;
  uStack_d38 = *(undefined4 *)(lVar8 + 0x3c);
  uStack_d34 = (uint)*(ushort *)(lStack_cd8 + 0xe);
  uStack_d30 = auStack_dc8[0];
  uStack_d24 = (uint)*(ushort *)(lVar8 + 0x62);
  uVar5 = *(undefined8 *)(lVar8 + 0x70);
  *(undefined4 *)(lVar8 + 0x10) = uStack_d38;
  *(uint *)(lVar8 + 0x14) = uStack_d34;
  *(undefined4 *)(lVar8 + 0x18) = auStack_dc8[0];
  *(undefined4 *)(lVar8 + 0x1c) = 0;
  uStack_d20._0_4_ = (undefined4)uVar5;
  uStack_d20._4_4_ = (undefined4)((ulonglong)uVar5 >> 0x20);
  *(undefined4 *)(lVar8 + 0x20) = 2;
  *(uint *)(lVar8 + 0x24) = uStack_d24;
  *(undefined4 *)(lVar8 + 0x28) = (undefined4)uStack_d20;
  *(undefined4 *)(lVar8 + 0x2c) = uStack_d20._4_4_;
  uStack_d84 = 0x10;
  *(ulonglong *)(lVar8 + 0x30) = CONCAT44(uStack_d14,uStack_d18) & 0xfffffffffffffffe;
  lVar8 = *(longlong *)(lVar6 + 0x138);
  lStack_de0 = *(longlong *)(lVar6 + 0x140);
  piVar12 = *(int **)(lVar8 + 0x70);
  uStack_d88 = (uint)*(ushort *)(lVar8 + 0x62);
  lVar6 = **(longlong **)(*(longlong *)(lStack_dd8 + 8) + 0x160);
  uStack_d70 = *(undefined8 *)(lVar6 + 0xa8);
  uStack_d68 = *(undefined4 *)(lVar6 + 0xb0);
  if ((*(ushort *)(lVar8 + 0x38) & 0x400) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bStack_e10 = *(byte *)(*(longlong *)(lStack_dd8 + 8) + 0x42) & 4;
  if (*(int *)(lVar4 + 0x100) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_e48 = 0;
  iVar3 = *(int *)(lVar8 + 0x10);
  piStack_e08 = piVar12;
  lStack_de8 = lVar15;
  iStack_db8 = -iVar3;
  lStack_d98 = lVar8;
  piStack_d90 = piVar12;
  lStack_d80 = lStack_de0;
  lStack_d78 = lVar15;
  lStack_d40 = lVar15;
  uStack_d2c = uStack_e00;
  uStack_d20 = uVar5;
  uStack_d18 = uStack_d18 & 0xfffffffe;
  func_0x(auStack_e46,auStack_aa8,lStack_de0,*(int *)(lVar8 + 0x14) + -1,
                  *(undefined4 *)(lVar8 + 0x18),6);
  if (-iVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_dbc = (uint)*(ushort *)(lVar8 + 0x62);
  alStack_df8[0] = lVar15;
  if (uStack_dbc != 0) {
    while( true ) {
      func_0x(&lStack_d98,piVar12,acStack_e0f,0x4000);
      if (acStack_e0f[0] == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(short *)(piVar12 + 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(&lStack_d98,piVar12,alStack_df8);
      if ((*(char *)(piVar12 + 0x10) != '\x01') && (*(char *)(piVar12 + 0x10) != '\x02')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((uint)piVar12[0x10] >> 8 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((piVar12[0x10] & 0x8000U) != 0) break;
      lVar8 = lStack_de0;
      if ((*(byte *)(*(longlong *)(piVar12 + 0x12) + 0x2a) & 0x10) != 0) {
        lVar8 = lVar15;
      }
      uVar2 = *(uint *)(lVar8 + *(longlong *)(*(longlong *)(piVar12 + 0x12) + 0x18));
      uVar11 = (uint)*(ushort *)(piVar12 + 0xf);
      if (uVar2 < uVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (uVar2 >= uVar11 && uVar2 != uVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((alStack_df8[0] != 0) && (uVar2 != 0)) {
        func_0x(*piVar12 + lStack_e40,alStack_df8[0],uVar2);
      }
      uStack_e00 = uStack_e00 + 1;
      piVar12 = piVar12 + 0x14;
      piStack_e08 = piVar12;
      if (uStack_dbc <= uStack_e00) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

