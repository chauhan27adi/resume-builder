
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,undefined8 param_3)

{
  ushort *puVar1;
  short *psVar2;
  uint *puVar3;
  undefined4 uVar4;
  char *pcVar5;
  longlong *plVar6;
  code *pcVar7;
  char cVar8;
  undefined2 uVar9;
  undefined4 uVar10;
  int iVar11;
  longlong lVar12;
  longlong lVar13;
  longlong lVar14;
  undefined8 uVar15;
  undefined4 *puVar16;
  undefined uVar17;
  byte bVar18;
  ushort uVar19;
  uint uVar20;
  undefined8 uVar21;
  uint uVar22;
  int iVar23;
  byte *pbVar24;
  int *piVar25;
  uint uVar26;
  undefined8 unaff_RBX;
  ulonglong uVar27;
  uint *puVar28;
  undefined *puVar29;
  undefined *puVar30;
  ulonglong uVar31;
  uint uVar32;
  ushort *puVar33;
  ushort uVar34;
  ulonglong uVar35;
  longlong lVar36;
  uint uVar37;
  bool bVar38;
  longlong alStackX_8 [2];
  short sStackX_18;
  ushort uStackX_1a;
  uint uStackX_1c;
  byte *pbStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar29 = &stack0xffffffffffffffc8 + lVar12;
  puVar30 = &stack0xffffffffffffffc8 + lVar12;
  psVar2 = (short *)((longlong)&sStackX_18 + lVar12);
  *(undefined8 *)(&stack0x000000e8 + lVar12) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002200 + lVar12) = unaff_RBX;
  *(ulonglong *)(&stack0x00002198 + lVar12) = _DAT_ ^ (ulonglong)psVar2;
  *(undefined8 *)(&stack0x000000d0 + lVar12) = param_3;
  *(longlong **)(&stack0x00000068 + lVar12) = param_2;
  *(longlong *)(&stack0x00000060 + lVar12) = param_1;
  *(longlong *)(&stack0x000000d8 + lVar12) = *param_2;
  lVar13 = *(longlong *)(param_1 + 0x10);
  *(longlong *)(&stack0x000000c8 + lVar12) = lVar13;
  *psVar2 = -1;
  lVar14 = 0;
  *(undefined8 *)((longlong)&pbStackX_20 + lVar12) = 0;
  *(undefined4 *)((longlong)&sStackX_18 + lVar12 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar12) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar12) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar12) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000a3;
  func_0x(&stack0x000000e0 + lVar12,param_1,1);
  lVar13 = *(longlong *)(lVar13 + 8);
  bVar18 = *(byte *)(lVar13 + 0x106);
  uVar37 = **(uint **)(param_1 + 0x108) & 0x20000000;
  *(uint *)(&stack0x00000054 + lVar12) = uVar37;
  iVar11 = *(int *)(lVar13 + 0x100);
  bVar38 = false;
  if ((iVar11 != 0) && (iVar11 != 3 && iVar11 != 4)) {
    bVar38 = true;
  }
  lVar13 = *param_2;
  if ((*(byte *)(lVar13 + 0x38) & 0x20) == 0) {
    uVar37 = *(uint *)((longlong)param_2 + 0x14) & 0x10;
    if (bVar38) {
      *(undefined8 *)(&stack0x00000078 + lVar12) = 0;
      lVar36 = lVar14;
      if (uVar37 != 0) {
        lVar36 = lVar13;
      }
      uVar37 = -*(int *)(lVar36 + 0x10);
      *(uint *)(&stack0x00000074 + lVar12) = uVar37;
      uVar10 = *(undefined4 *)(lVar36 + 0x18);
      uVar4 = *(undefined4 *)(lVar36 + 0x14);
      *(undefined2 *)(&stack0xfffffffffffffff0 + lVar12) = 1;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) = uVar10;
      if ((bVar18 & 1) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101aec;
        func_0x(psVar2,&stack0x000001f8 + lVar12,0x1f9e,uVar4);
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101ae5;
        func_0x();
      }
      puVar29 = &stack0xffffffffffffffc8 + lVar12;
      if (uVar37 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b16;
        lVar13 = func_0x();
        lVar13 = -lVar13;
        puVar29 = &stack0xffffffffffffffc8 + lVar13 + lVar12;
        lVar14 = (longlong)&sStackX_18 + lVar13 + lVar12;
        *(longlong *)(&stack0x00000078 + lVar12) = lVar14;
        *(undefined8 *)((longlong)&uStack_40 + lVar13 + lVar12) = 0x101b2c;
        func_0x(lVar14,0);
      }
      uVar34 = *(ushort *)(*param_2 + 0x62);
      *(undefined8 *)(&stack0x00000058 + lVar12) = 0;
      puVar28 = (uint *)param_2[1];
      if (uVar34 != 0) {
        *(ulonglong *)(&stack0x00000080 + lVar12) = (ulonglong)uVar34;
        lVar14 = *(longlong *)(&stack0x00000078 + lVar12);
        do {
          uVar37 = *puVar28;
          *(undefined8 *)(puVar29 + -8) = 0x101b71;
          func_0x(param_2,puVar28,&stack0x00000050 + lVar12);
          if ((&stack0x00000050)[lVar12] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar28 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar28[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar29 + -8) = 0x101e48;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar29 + -8) = 0x101e5a;
            func_0x(psVar2,puVar28,0,0);
            if ((int)uVar37 < 0) {
              puVar3 = (uint *)((longlong)(int)~uVar37 * 0x20 + 0xc + lVar14);
              *puVar3 = *puVar3 | 2;
            }
          }
          else {
            if (*(short *)(puVar28 + 1) != 0) {
              if (*psVar2 == 0) {
                *(undefined8 *)(puVar29 + -8) = 0x101b95;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar29 + -8) = 0x101b9c;
                func_0x((longlong)&sStackX_18 + lVar12 + 2,puVar28);
              }
            }
            *(undefined8 *)(puVar29 + -8) = 0x101bab;
            func_0x(param_2,puVar28,&stack0x00000058 + lVar12);
            cVar8 = *(char *)(puVar28 + 0x10);
            if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
              lVar13 = *(longlong *)(&stack0x00000058 + lVar12);
              if ((puVar28[0x10] >> 8 & 1) == 0) {
                uVar37 = *puVar28;
                lVar36 = *(longlong *)((longlong)&pbStackX_20 + lVar12);
                uVar9 = *(undefined2 *)(puVar28 + 0xf);
                *(undefined8 *)(puVar29 + -8) = 0x101d18;
                func_0x((int)uVar37 + lVar36,lVar13,uVar9);
              }
              else {
                iVar11 = 0;
                if (((puVar28[0x10] & 0x8000) == 0) ||
                   ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  if ((*(byte *)(*(longlong *)(puVar28 + 0x12) + 0x2a) & 0x10) == 0) {
                    lVar36 = param_2[3];
                  }
                  else {
                    lVar36 = param_2[4];
                  }
                  uVar37 = *(uint *)(*(longlong *)(*(longlong *)(puVar28 + 0x12) + 0x18) + lVar36);
                }
                else {
                  uVar37 = *(uint *)(param_2[7] + (ulonglong)puVar28[0xe] * 8);
                }
                uVar26 = (uint)*(ushort *)(puVar28 + 0xf);
                if (uVar37 < uVar26) {
                  iVar11 = uVar26 - uVar37;
                }
                else if (uVar26 < uVar37) {
                  *(undefined8 *)(puVar29 + -8) = 0x101d7a;
                  (*_DAT_)(6,0x5c,0x16);
                }
                uVar17 = *(undefined *)(*(longlong *)(puVar28 + 0x12) + 0x24);
                lVar36 = (longlong)(int)*puVar28 + *(longlong *)((longlong)&pbStackX_20 + lVar12);
                if ((lVar13 != 0) && (uVar37 != 0)) {
                  *(undefined8 *)(puVar29 + -8) = 0x101da1;
                  func_0x(lVar36,lVar13,uVar37);
                }
                if (iVar11 != 0) {
                  *(undefined8 *)(puVar29 + -8) = 0x101db5;
                  func_0x((ulonglong)uVar37 + lVar36,uVar17,iVar11);
                }
                param_2 = *(longlong **)(&stack0x00000068 + lVar12);
              }
            }
            else {
              uVar26 = 0;
              if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
                uVar32 = puVar28[0x10];
                piVar25 = *(int **)(&stack0x00000058 + lVar12);
                if (((uVar32 >> 0xd & 1) == 0) || (*piVar25 != 0)) {
                  if (((uVar32 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0))
                  {
                    lVar13 = *(longlong *)(puVar28 + 0x12);
                    if ((uVar32 >> 8 & 1) == 0) {
                      uVar26 = (uint)*(ushort *)(lVar13 + 2);
                    }
                    else if ((*(byte *)(lVar13 + 0x2a) & 0x10) == 0) {
                      uVar26 = *(uint *)(*(longlong *)(lVar13 + 0x18) + param_2[3]);
                    }
                    else {
                      uVar26 = *(uint *)(*(longlong *)(lVar13 + 0x18) + param_2[4]);
                    }
                  }
                  else {
                    uVar26 = *(uint *)(param_2[7] + (ulonglong)puVar28[0xe] * 8);
                  }
                }
                if (*(ushort *)(puVar28 + 0xf) < uVar26) {
                  *(undefined8 *)(puVar29 + -8) = 0x101ccd;
                  (*_DAT_)(6,0x52,0x16);
                  piVar25 = *(int **)(&stack0x00000058 + lVar12);
                }
                *(undefined4 *)(puVar29 + 0x28) = 0;
                *(uint **)(puVar29 + 0x20) = puVar28;
                *(undefined8 *)(puVar29 + -8) = 0x101cf2;
                func_0x((longlong)(int)~uVar37 * 0x20 + lVar14,piVar25,uVar26);
              }
              else if (cVar8 == '\b') {
                if (*psVar2 == 0) {
                  uVar15 = *(undefined8 *)(&stack0x00000058 + lVar12);
                  *(undefined8 *)(puVar29 + -8) = 0x101c25;
                  func_0x(psVar2,puVar28,uVar15);
                }
                else {
                  *(undefined4 *)(puVar29 + 0x28) = 0;
                  *(uint **)(puVar29 + 0x20) = puVar28;
                  uVar15 = *(undefined8 *)(&stack0x00000058 + lVar12);
                  *(undefined8 *)(puVar29 + -8) = 0x101c50;
                  func_0x((longlong)(int)~uVar37 * 0x20 + lVar14,uVar15,1);
                }
              }
              else {
                *(undefined8 *)(puVar29 + 0x20) = 0x156e3e8;
                *(undefined8 *)(puVar29 + -8) = 0x101c03;
                (*_DAT_)(1,0x1973240,0x199fb80);
              }
            }
          }
          puVar28 = puVar28 + 0x14;
          plVar6 = (longlong *)(&stack0x00000080 + lVar12);
          *plVar6 = *plVar6 + -1;
        } while (*plVar6 != 0);
        uVar37 = *(uint *)(&stack0x00000074 + lVar12);
        lVar14 = *(longlong *)(&stack0x00000078 + lVar12);
      }
      puVar33 = (ushort *)0x0;
      if (uVar37 != 0) {
        if (*psVar2 == 0) {
          do {
            uVar31 = (ulonglong)uVar37;
            uVar26 = uVar37 - 1;
            if (*(int *)((ulonglong)uVar26 * 0x20 + 8 + lVar14) != 0) {
              *(ushort *)(&stack0x00000034 + lVar12) = (ushort)uVar37;
              iVar11 = *(int *)(&stack0x0000002c + lVar12) + 2 + uVar37 * 2;
              *(int *)(&stack0x00000030 + lVar12) = iVar11;
              *(int *)((longlong)&sStackX_18 + lVar12 + 4) = iVar11;
              **(byte **)((longlong)&pbStackX_20 + lVar12) =
                   **(byte **)((longlong)&pbStackX_20 + lVar12) | 0x20;
              uVar26 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
              if (uVar26 < 0x1f7d) {
                puVar33 = (ushort *)
                          ((ulonglong)*(uint *)(&stack0x0000002c + lVar12) +
                          *(longlong *)((longlong)&pbStackX_20 + lVar12));
                *puVar33 = (ushort)uVar37;
                uVar26 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
              }
              if (uVar37 != 0) {
                puVar28 = (uint *)(lVar14 + 0xc);
                do {
                  puVar33 = puVar33 + 1;
                  uVar27 = (ulonglong)uVar26;
                  lVar14 = *(longlong *)((longlong)&pbStackX_20 + lVar12);
                  uVar37 = puVar28[-1];
                  uVar26 = uVar26 + uVar37;
                  *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar26;
                  if (uVar26 < 0x1f7d) {
                    *puVar33 = (ushort)((*puVar28 & 1) << 0xf) | (ushort)uVar26 & 0x7fff;
                    uVar15 = *(undefined8 *)(puVar28 + -3);
                    *(undefined8 *)(puVar29 + -8) = 0x101ef9;
                    func_0x(uVar27 + lVar14,uVar37,uVar15,uVar37);
                    uVar26 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                  }
                  puVar28 = puVar28 + 8;
                  uVar31 = uVar31 - 1;
                } while (uVar31 != 0);
              }
              break;
            }
            uVar37 = uVar26;
          } while (uVar26 != 0);
        }
        else {
          *(undefined **)(puVar29 + 0x28) = &stack0x0000008c + lVar12;
          *(longlong *)(puVar29 + 0x20) = lVar14;
          *(undefined8 *)(puVar29 + -8) = 0x101f32;
          func_0x((longlong)&sStackX_18 + lVar12 + 2,0x1f9e,0x1f7c,uVar37);
        }
      }
    }
    else {
      *psVar2 = 0;
      *(undefined8 *)(&stack0x00000098 + lVar12) = 0;
      if (uVar37 != 0) {
        lVar14 = lVar13;
      }
      uVar37 = -*(int *)(lVar14 + 0x10);
      *(uint *)(&stack0x00000074 + lVar12) = uVar37;
      uVar17 = 0;
      bVar38 = (bVar18 & 1) == 0;
      if (bVar38) {
        uVar17 = 6;
      }
      iVar11 = 4;
      if (bVar38) {
        iVar11 = 1;
      }
      iVar23 = *(int *)(lVar14 + 0x14);
      (&stack0xfffffffffffffff0)[lVar12] = uVar17;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) = *(undefined4 *)(lVar14 + 0x18);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100178;
      func_0x
                ((longlong)&sStackX_18 + lVar12 + 2,&stack0x000001f8 + lVar12,0x1f9e,iVar23 - iVar11
                );
      if (uVar37 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001a0;
        lVar13 = func_0x();
        lVar13 = -lVar13;
        puVar29 = &stack0xffffffffffffffc8 + lVar13 + lVar12;
        lVar14 = (longlong)&sStackX_18 + lVar13 + lVar12;
        *(longlong *)(&stack0x00000098 + lVar12) = lVar14;
        *(undefined8 *)((longlong)&uStack_40 + lVar13 + lVar12) = 0x1001b9;
        func_0x(lVar14,0);
      }
      uVar34 = *(ushort *)(*param_2 + 0x62);
      *(uint *)(&stack0x000000a4 + lVar12) = (uint)uVar34;
      *(undefined8 *)(&stack0x00000090 + lVar12) = 0;
      *(undefined4 *)(&stack0x00000088 + lVar12) = 0;
      puVar28 = (uint *)param_2[1];
      *(uint **)(&stack0x00000058 + lVar12) = puVar28;
      if (uVar34 != 0) {
        do {
          uVar31 = 0;
          uVar37 = *puVar28;
          *(undefined8 *)(puVar29 + -8) = 0x100202;
          func_0x(param_2,puVar28,&stack0x00000050 + lVar12);
          if ((&stack0x00000050)[lVar12] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar28 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar28[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar29 + -8) = 0x1019ca;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar29 + -8) = 0x1019dc;
            func_0x((longlong)&sStackX_18 + lVar12 + 2,puVar28,0,0);
            if ((int)uVar37 < 0) {
              puVar3 = (uint *)((longlong)(int)~uVar37 * 0x20 + 0xc +
                               *(longlong *)(&stack0x00000098 + lVar12));
              *puVar3 = *puVar3 | 2;
            }
            goto LAB_;
          }
          if (*(short *)(puVar28 + 1) != 0) {
            *(undefined8 *)(puVar29 + -8) = 0x100220;
            func_0x((longlong)&sStackX_18 + lVar12 + 2,puVar28);
          }
          *(undefined8 *)(puVar29 + -8) = 0x10022f;
          func_0x(param_2,puVar28,&stack0x00000090 + lVar12);
          cVar8 = *(char *)(puVar28 + 0x10);
          uVar26 = 0;
          if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
            lVar14 = *(longlong *)(&stack0x00000090 + lVar12);
            puVar28 = *(uint **)(&stack0x00000058 + lVar12);
            if ((puVar28[0x10] >> 8 & 1) == 0) {
              uVar37 = *puVar28;
              lVar13 = *(longlong *)((longlong)&pbStackX_20 + lVar12);
              uVar9 = *(undefined2 *)(puVar28 + 0xf);
              *(undefined8 *)(puVar29 + -8) = 0x1018f9;
              func_0x((int)uVar37 + lVar13,lVar14,uVar9);
              goto LAB_;
            }
            if (((puVar28[0x10] & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0))
            {
              if ((*(byte *)(*(longlong *)(puVar28 + 0x12) + 0x2a) & 0x10) == 0) {
                lVar13 = param_2[3];
              }
              else {
                lVar13 = param_2[4];
              }
              uVar37 = *(uint *)(*(longlong *)(*(longlong *)(puVar28 + 0x12) + 0x18) + lVar13);
            }
            else {
              uVar37 = *(uint *)(param_2[7] + (ulonglong)puVar28[0xe] * 8);
            }
            uVar32 = (uint)*(ushort *)(puVar28 + 0xf);
            if (uVar37 < uVar32) {
              uVar26 = uVar32 - uVar37;
            }
            else if (uVar32 < uVar37) {
              *(undefined8 *)(puVar29 + -8) = 0x10195c;
              (*_DAT_)(6,0x5c,0x16);
            }
            uVar17 = *(undefined *)(*(longlong *)(puVar28 + 0x12) + 0x24);
            lVar13 = (longlong)(int)*puVar28 + *(longlong *)((longlong)&pbStackX_20 + lVar12);
            if ((lVar14 != 0) && (uVar37 != 0)) {
              *(undefined8 *)(puVar29 + -8) = 0x101983;
              func_0x(lVar13,lVar14,uVar37);
            }
            if (uVar26 != 0) {
              *(undefined8 *)(puVar29 + -8) = 0x10199b;
              func_0x((ulonglong)uVar37 + lVar13,uVar17,uVar26);
            }
LAB_:
            param_2 = *(longlong **)(&stack0x00000068 + lVar12);
            puVar28 = *(uint **)(&stack0x00000058 + lVar12);
          }
          else if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
            uVar32 = puVar28[0x10];
            piVar25 = *(int **)(&stack0x00000090 + lVar12);
            if (((uVar32 >> 0xd & 1) == 0) || (*piVar25 != 0)) {
              if (((uVar32 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                lVar14 = *(longlong *)(puVar28 + 0x12);
                if ((uVar32 >> 8 & 1) == 0) {
                  uVar26 = (uint)*(ushort *)(lVar14 + 2);
                }
                else if ((*(byte *)(lVar14 + 0x2a) & 0x10) == 0) {
                  uVar26 = *(uint *)(*(longlong *)(lVar14 + 0x18) + param_2[3]);
                }
                else {
                  uVar26 = *(uint *)(*(longlong *)(lVar14 + 0x18) + param_2[4]);
                }
              }
              else {
                uVar26 = *(uint *)(param_2[7] + (ulonglong)puVar28[0xe] * 8);
              }
            }
            if (*(ushort *)(puVar28 + 0xf) < uVar26) {
              *(undefined8 *)(puVar29 + -8) = 0x1018a3;
              (*_DAT_)(6,0x52,0x16);
              piVar25 = *(int **)(&stack0x00000090 + lVar12);
            }
            lVar14 = *(longlong *)(&stack0x00000098 + lVar12);
            *(undefined4 *)(puVar29 + 0x28) = 0;
            *(uint **)(puVar29 + 0x20) = puVar28;
            *(undefined8 *)(puVar29 + -8) = 0x1018cf;
            func_0x((longlong)(int)~uVar37 * 0x20 + lVar14,piVar25,uVar26);
          }
          else if (cVar8 == '\b') {
            pcVar5 = *(char **)(&stack0x00000090 + lVar12);
            *(char **)(&stack0x00000080 + lVar12) = pcVar5;
            uVar37 = *puVar28;
            if ((int)uVar37 < 0) {
              if ((uVar37 & 0xc0000000) != 0x80000000) {
                if (*(int *)((longlong)&sStackX_18 + lVar12 + 4) == 0) {
                  *(undefined2 *)((longlong)&sStackX_18 + lVar12 + 2) = 0;
                  uVar37 = *(uint *)(&stack0x00000028 + lVar12);
                  uVar31 = (ulonglong)uVar37;
                  *(uint *)(&stack0x0000002c + lVar12) = uVar37;
                  pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                  if ((*pbVar24 & 0x10) != 0) {
                    uVar37 = uVar37 + 2 + (*(ushort *)(pbVar24 + uVar31) + 7 >> 3);
                    uVar31 = (ulonglong)uVar37;
                    *(uint *)(&stack0x0000002c + lVar12) = uVar37;
                  }
                  uVar37 = (uint)uVar31;
                  if ((*pbVar24 & 0x20) == 0) {
                    *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37;
                    *(undefined2 *)(&stack0x00000034 + lVar12) = 0;
                    *(uint *)(&stack0x00000030 + lVar12) = uVar37;
                  }
                  else {
                    puVar33 = (ushort *)(pbVar24 + uVar31);
                    uVar34 = *puVar33;
                    *(ushort *)(&stack0x00000034 + lVar12) = uVar34;
                    if (uVar34 == 0) {
                      *(undefined8 *)(puVar29 + -8) = 0x1008b0;
                      cVar8 = func_0x(0x1f01180);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x1008b9;
                        lVar14 = func_0x();
                        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x1008d3;
                          cVar8 = func_0x(0x1f01180);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x1008ef;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x100915;
                            (*_DAT_)(1,0x17f1f08,0x1911bd8,0x80f);
                          }
                        }
                      }
                      uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                      *(undefined8 *)(puVar29 + -8) = 0x100923;
                      func_0x(uVar15,3);
                      uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                      uVar31 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                      pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                    }
                    uVar26 = (int)uVar31 + (uVar34 + 1) * 2;
                    *(uint *)(&stack0x00000030 + lVar12) = uVar26;
                    if (0x1f9e < uVar26) {
                      *(undefined8 *)(puVar29 + -8) = 0x100957;
                      cVar8 = func_0x(0x1f01180);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x100960;
                        lVar14 = func_0x();
                        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x10097a;
                          cVar8 = func_0x(0x1f01180);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x100996;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x1009bc;
                            (*_DAT_)(1,0x17f1f08,0x1911bd8,0x816);
                          }
                        }
                      }
                      uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                      *(undefined8 *)(puVar29 + -8) = 0x1009ca;
                      func_0x(uVar15,4);
                      uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                      uVar26 = *(uint *)(&stack0x00000030 + lVar12);
                      uVar31 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                      pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                    }
                    uVar27 = (ulonglong)uVar34;
                    uVar37 = puVar33[uVar27] & 0x7fff;
                    *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37;
                    if (uVar37 < uVar26) {
                      *(undefined8 *)(puVar29 + -8) = 0x1009ff;
                      cVar8 = func_0x(0x1f01180);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x100a08;
                        lVar14 = func_0x();
                        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x100a22;
                          cVar8 = func_0x(0x1f01180);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x100a3e;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x100a64;
                            (*_DAT_)(1,0x17f1f08,0x1911bd8,0x81d);
                          }
                        }
                      }
                      uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                      *(undefined8 *)(puVar29 + -8) = 0x100a72;
                      func_0x(uVar15,4);
                      uVar27 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar12);
                      uVar26 = *(uint *)(&stack0x00000030 + lVar12);
                      uVar31 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                      pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                      uVar37 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                    }
                    do {
                      if (-1 < (short)puVar33[(ulonglong)((int)uVar27 - 1) + 1]) break;
                      uVar32 = uVar26;
                      if ((int)uVar27 != 1) {
                        uVar32 = *(ushort *)(pbVar24 + uVar27 * 2 + (uVar31 - 2)) & 0x7fff;
                      }
                      if ((uVar32 < uVar26) ||
                         ((*(ushort *)(pbVar24 + uVar27 * 2 + uVar31) & 0x7fff) < uVar32)) {
                        *(undefined8 *)(puVar29 + -8) = 0x100ad7;
                        func_0x(pbVar24,7);
                        uVar27 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar12);
                        uVar26 = *(uint *)(&stack0x00000030 + lVar12);
                        uVar31 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                        pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                        uVar37 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                      }
                      if ((uVar32 < uVar26) || (uVar37 < uVar32)) goto LAB_;
                      if (*(ushort *)(pbVar24 + uVar32) == 5) {
                        puVar33 = (ushort *)((longlong)&sStackX_18 + lVar12 + 2);
                        *puVar33 = *puVar33 | 2;
                        *(short *)(&stack0x00000034 + lVar12) = (short)uVar27 + -1;
                        *(short *)(&stack0x00000042 + lVar12) = (short)uVar32;
                        uVar34 = *(ushort *)(&stack0x00000044 + lVar12);
                        if ((*(ushort *)(pbVar24 + (ulonglong)(uVar32 & 0xffff) + 2) >> 0xe & 1) ==
                            0) {
                          uVar34 = uVar34 & 0xc7ff;
                        }
                        else {
                          uVar34 = uVar34 ^ (*(ushort *)(pbVar24 + (ulonglong)(uVar32 & 0xffff) + 2)
                                            ^ uVar34) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000044 + lVar12) = uVar34;
                        *(ushort *)(&stack0x00000044 + lVar12) =
                             uVar34 ^ (uVar34 ^ *(ushort *)
                                                 (pbVar24 + (ulonglong)(uVar32 & 0xffff) + 2)) &
                                      0x7ff;
                        break;
                      }
                      if (*(ushort *)(pbVar24 + uVar32) < 0x400) break;
                      puVar1 = (ushort *)((longlong)&sStackX_18 + lVar12 + 2);
                      *puVar1 = *puVar1 | 1;
                      uVar34 = (short)uVar27 - 1;
                      uVar27 = (ulonglong)uVar34;
                      *(ushort *)(&stack0x00000034 + lVar12) = uVar34;
                    } while (uVar34 != 0);
                  }
                  if ((*pbVar24 & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000003e + lVar12) = 0;
                  }
                  else {
                    *(uint *)(&stack0x0000003e + lVar12) = uVar37;
                    *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37 + 0xe;
                    *(undefined8 *)(puVar29 + -8) = 0x100bb4;
                    uVar15 = func_0x((longlong)&sStackX_18 + lVar12 + 2);
                    *(undefined8 *)(puVar29 + -8) = 0x100bc3;
                    func_0x(uVar15,&stack0x000000b8 + lVar12);
                    *(undefined8 *)(puVar29 + -8) = 0x100bcf;
                    iVar11 = func_0x(&stack0x000000b8 + lVar12);
                    uVar37 = *(int *)((longlong)&sStackX_18 + lVar12 + 4) + iVar11;
                    *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37;
                    pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                  }
                  if ((*(byte **)(&stack0x00000036 + lVar12) != (byte *)0x0) &&
                     (*(byte **)(&stack0x00000036 + lVar12) < pbVar24 + uVar37)) {
                    *(undefined8 *)(puVar29 + -8) = 0x100c0c;
                    cVar8 = func_0x(0x1f01180);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar29 + -8) = 0x100c15;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar29 + -8) = 0x100c2f;
                        cVar8 = func_0x(0x1f01180);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x100c4b;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar29 + 0x20) = 0;
                          *(undefined8 *)(puVar29 + -8) = 0x100c71;
                          (*_DAT_)(1,0x17f1f08,0x1911bd8);
                        }
                      }
                    }
                    uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                    *(undefined8 *)(puVar29 + -8) = 0x100c7f;
                    func_0x(uVar15,0x12);
                    uVar37 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                  }
                  if (0x3f3b < uVar37 - 1) {
                    *(undefined8 *)(puVar29 + -8) = 0x100c9a;
                    cVar8 = func_0x(0x1f01180);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar29 + -8) = 0x100ca3;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar29 + -8) = 0x100cbd;
                        cVar8 = func_0x(0x1f01180);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x100cd9;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar29 + 0x20) = 0;
                          *(undefined8 *)(puVar29 + -8) = 0x100cff;
                          (*_DAT_)(1,0x17f1f08,0x1911bd8);
                        }
                      }
                    }
                    uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                    *(undefined8 *)(puVar29 + -8) = 0x100d0d;
                    func_0x(uVar15,5);
                  }
                }
LAB_:
                uVar37 = -*puVar28;
                *(undefined8 *)(puVar29 + -8) = 0x100d1f;
                func_0x(&stack0x00000118 + lVar12);
                pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                bVar18 = *pbVar24;
                if ((bVar18 >> 6 & 1) != 0) {
                  *(undefined8 *)(puVar29 + -8) = 0x100d41;
                  func_0x
                            ((longlong)&sStackX_18 + lVar12 + 2,&stack0x00000118 + lVar12);
                  pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                }
                if ((*pbVar24 & 0x20) == 0) {
                  *(undefined8 *)(puVar29 + -8) = 0x100d54;
                  func_0x((longlong)&sStackX_18 + lVar12 + 2);
                  pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                }
                uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                uVar32 = (uint)uVar34;
                uVar26 = (uint)uVar34;
                if (uVar26 < uVar37) {
                  puVar33 = (ushort *)(pbVar24 + *(uint *)(&stack0x0000002c + lVar12));
                  uVar32 = *(uint *)(&stack0x0000002c + lVar12) + 2 + uVar26 * 2;
                  uVar20 = (uVar37 - uVar34) * 2;
                  uVar22 = 0;
                  if (*puVar33 != 0) {
                    do {
                      uVar19 = puVar33[(ulonglong)uVar22 + 1];
                      puVar33[(ulonglong)(uVar22 & 0xffff) + 1] =
                           puVar33[(ulonglong)(uVar22 & 0xffff) + 1] & 0x8000;
                      puVar33[(ulonglong)(uVar22 & 0xffff) + 1] =
                           puVar33[(ulonglong)(uVar22 & 0xffff) + 1] |
                           (uVar19 & 0x7fff) + (short)uVar20 & 0x7fff;
                      uVar22 = uVar22 + 1;
                    } while (uVar22 < *puVar33);
                    pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                  }
                  iVar11 = *(int *)((longlong)&sStackX_18 + lVar12 + 4);
                  *(undefined8 *)(puVar29 + -8) = 0x100dda;
                  func_0x
                            (pbVar24 + (ulonglong)uVar20 + (ulonglong)uVar32,pbVar24 + uVar32,
                             iVar11 - uVar32);
                  piVar25 = (int *)((longlong)&sStackX_18 + lVar12 + 4);
                  *piVar25 = *piVar25 + uVar20;
                  uVar20 = *(int *)(&stack0x00000030 + lVar12) + uVar20;
                  *(uint *)(&stack0x00000030 + lVar12) = uVar20;
                  if (uVar34 != 0) {
                    uVar20 = puVar33[(ulonglong)(uVar26 - 1) + 1] & 0x7fff;
                  }
                  do {
                    puVar33[(ulonglong)(uVar26 & 0xffff) + 1] = (ushort)uVar20 & 0x7fff;
                    uVar26 = uVar26 + 1;
                  } while (uVar26 < uVar37);
                  *puVar33 = *puVar33 + (short)(uVar37 - uVar34);
                  *(undefined8 *)(puVar29 + -8) = 0x100e1c;
                  iVar11 = func_0x((longlong)&sStackX_18 + lVar12 + 2);
                  if (iVar11 != 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x100e30;
                    uVar9 = func_0x
                                      ((longlong)&sStackX_18 + lVar12 + 2,&stack0x000000a8 + lVar12)
                    ;
                    *(undefined2 *)(&stack0x00000042 + lVar12) = uVar9;
                  }
                  uVar32 = uVar37 & 0xffff;
                  *(short *)(&stack0x00000034 + lVar12) = (short)uVar37;
                  pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                }
                uVar31 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                if (uVar32 < uVar37) {
                  uVar26 = *(ushort *)(pbVar24 + (ulonglong)uVar32 * 2 + uVar31) & 0x7fff;
                  iVar11 = 0;
LAB_:
                  puVar33 = (ushort *)(pbVar24 + uVar31);
                  uVar10 = *(undefined4 *)((longlong)&sStackX_18 + lVar12 + 4);
                  *(undefined8 *)(puVar29 + -8) = 0x100ec1;
                  uVar10 = func_0x(uVar10,iVar11 + uVar26);
                  lVar14 = *(longlong *)((longlong)&pbStackX_20 + lVar12);
                  *(undefined8 *)(puVar29 + -8) = 0x100edd;
                  func_0x
                            (lVar14 + 1 + (ulonglong)uVar26,
                             (longlong)iVar11 + (ulonglong)uVar26 + lVar14,uVar10);
                  uVar37 = uVar37 - 1;
                  if ((int)uVar37 < (int)(uint)*puVar33) {
                    do {
                      uVar34 = puVar33[(longlong)(int)uVar37 + 1];
                      puVar33[((ulonglong)uVar37 & 0xffff) + 1] =
                           puVar33[((ulonglong)uVar37 & 0xffff) + 1] & 0x8000;
                      puVar33[((ulonglong)uVar37 & 0xffff) + 1] =
                           puVar33[((ulonglong)uVar37 & 0xffff) + 1] |
                           ((uVar34 & 0x7fff) - (short)iVar11) + 1 & 0x7fff;
                      uVar37 = uVar37 + 1;
                    } while ((int)uVar37 < (int)(uint)*puVar33);
                  }
                  piVar25 = (int *)((longlong)&sStackX_18 + lVar12 + 4);
                  *piVar25 = *piVar25 + (1 - iVar11);
                  *(undefined8 *)(puVar29 + -8) = 0x100f30;
                  iVar11 = func_0x((longlong)&sStackX_18 + lVar12 + 2);
                  if (iVar11 != 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x100f44;
                    uVar9 = func_0x
                                      ((longlong)&sStackX_18 + lVar12 + 2,&stack0x000000ac + lVar12)
                    ;
                    *(undefined2 *)(&stack0x00000042 + lVar12) = uVar9;
                  }
                  pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                }
                else {
                  uVar26 = *(uint *)(&stack0x00000030 + lVar12);
                  if (uVar37 != 1) {
                    uVar26 = *(ushort *)(pbVar24 + (longlong)(int)uVar37 * 2 + (uVar31 - 2)) &
                             0x7fff;
                  }
                  uVar34 = *(ushort *)(pbVar24 + (longlong)(int)uVar37 * 2 + uVar31);
                  if ((uVar26 < *(uint *)(&stack0x00000030 + lVar12)) ||
                     ((uVar34 & 0x7fff) < uVar26)) {
                    *(undefined8 *)(puVar29 + -8) = 0x100e88;
                    func_0x(pbVar24,7);
                    uVar31 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                    pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                  }
                  iVar11 = (uVar34 & 0x7fff) - uVar26;
                  if (iVar11 != 1) goto LAB_;
                }
                pbVar24[uVar26] = **(byte **)(&stack0x00000080 + lVar12);
                if ((bVar18 >> 6 & 1) != 0) {
                  *(undefined8 *)(puVar29 + -8) = 0x100f6f;
                  func_0x
                            ((longlong)&sStackX_18 + lVar12 + 2,&stack0x00000118 + lVar12);
                }
                goto LAB_;
              }
              *(undefined8 *)(puVar29 + -8) = 0x1010a7;
              func_0x(&stack0x00000118 + lVar12);
              *(undefined4 *)(&stack0x00000070 + lVar12) = 0;
              if (*(int *)((longlong)&sStackX_18 + lVar12 + 4) == 0) {
                *(undefined2 *)((longlong)&sStackX_18 + lVar12 + 2) = 0;
                uVar37 = *(uint *)(&stack0x00000028 + lVar12);
                uVar27 = (ulonglong)uVar37;
                *(uint *)(&stack0x0000002c + lVar12) = uVar37;
                pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                if ((*pbVar24 & 0x10) != 0) {
                  uVar37 = uVar37 + 2 + (*(ushort *)(pbVar24 + uVar27) + 7 >> 3);
                  uVar27 = (ulonglong)uVar37;
                  *(uint *)(&stack0x0000002c + lVar12) = uVar37;
                }
                uVar37 = (uint)uVar27;
                if ((*pbVar24 & 0x20) == 0) {
                  *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37;
                  *(undefined2 *)(&stack0x00000034 + lVar12) = 0;
                  *(uint *)(&stack0x00000030 + lVar12) = uVar37;
                }
                else {
                  puVar33 = (ushort *)(pbVar24 + uVar27);
                  uVar34 = *puVar33;
                  *(ushort *)(&stack0x00000034 + lVar12) = uVar34;
                  if (uVar34 == 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x10110b;
                    cVar8 = func_0x(0x1f01180);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar29 + -8) = 0x101114;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar29 + -8) = 0x10112e;
                        cVar8 = func_0x(0x1f01180);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x10114a;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar29 + 0x20) = 0;
                          *(undefined8 *)(puVar29 + -8) = 0x101170;
                          (*_DAT_)(1,0x17f1f08,0x1911bd8,0x80f);
                        }
                      }
                    }
                    uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                    *(undefined8 *)(puVar29 + -8) = 0x10117e;
                    func_0x(uVar15,3);
                    uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                    uVar27 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                    pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                  }
                  uVar32 = (int)uVar27 + (uVar34 + 1) * 2;
                  *(uint *)(&stack0x00000030 + lVar12) = uVar32;
                  if (0x1f9e < uVar32) {
                    *(undefined8 *)(puVar29 + -8) = 0x1011b2;
                    cVar8 = func_0x(0x1f01180);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar29 + -8) = 0x1011bb;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar29 + -8) = 0x1011d5;
                        cVar8 = func_0x(0x1f01180);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x1011f1;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar29 + 0x20) = 0;
                          *(undefined8 *)(puVar29 + -8) = 0x101217;
                          (*_DAT_)(1,0x17f1f08,0x1911bd8,0x816);
                        }
                      }
                    }
                    uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                    *(undefined8 *)(puVar29 + -8) = 0x101225;
                    func_0x(uVar15,4);
                    uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                    uVar32 = *(uint *)(&stack0x00000030 + lVar12);
                    uVar27 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                    pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                  }
                  uVar35 = (ulonglong)uVar34;
                  uVar37 = puVar33[uVar35] & 0x7fff;
                  *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37;
                  if (uVar37 < uVar32) {
                    *(undefined8 *)(puVar29 + -8) = 0x10125a;
                    cVar8 = func_0x(0x1f01180);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar29 + -8) = 0x101263;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar29 + -8) = 0x10127d;
                        cVar8 = func_0x(0x1f01180);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x101299;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar29 + 0x20) = 0;
                          *(undefined8 *)(puVar29 + -8) = 0x1012bf;
                          (*_DAT_)(1,0x17f1f08,0x1911bd8,0x81d);
                        }
                      }
                    }
                    uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                    *(undefined8 *)(puVar29 + -8) = 0x1012cd;
                    func_0x(uVar15,4);
                    uVar35 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar12);
                    uVar32 = *(uint *)(&stack0x00000030 + lVar12);
                    uVar27 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                    pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                    uVar37 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                  }
                  do {
                    if (-1 < (short)puVar33[(ulonglong)((int)uVar35 - 1) + 1]) break;
                    uVar20 = uVar32;
                    if ((int)uVar35 != 1) {
                      uVar20 = *(ushort *)(pbVar24 + uVar35 * 2 + (uVar27 - 2)) & 0x7fff;
                    }
                    if ((uVar20 < uVar32) ||
                       ((*(ushort *)(pbVar24 + uVar35 * 2 + uVar27) & 0x7fff) < uVar20)) {
                      *(undefined8 *)(puVar29 + -8) = 0x101337;
                      func_0x(pbVar24,7);
                      uVar35 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar12);
                      uVar32 = *(uint *)(&stack0x00000030 + lVar12);
                      uVar27 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12);
                      pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                      uVar37 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                    }
                    if ((uVar20 < uVar32) || (uVar37 < uVar20)) goto LAB_;
                    if (*(ushort *)(pbVar24 + uVar20) == 5) {
                      puVar33 = (ushort *)((longlong)&sStackX_18 + lVar12 + 2);
                      *puVar33 = *puVar33 | 2;
                      *(short *)(&stack0x00000034 + lVar12) = (short)uVar35 + -1;
                      *(short *)(&stack0x00000042 + lVar12) = (short)uVar20;
                      uVar34 = *(ushort *)(&stack0x00000044 + lVar12);
                      if ((*(ushort *)(pbVar24 + (ulonglong)(uVar20 & 0xffff) + 2) >> 0xe & 1) == 0)
                      {
                        uVar34 = uVar34 & 0xc7ff;
                      }
                      else {
                        uVar34 = uVar34 ^ (*(ushort *)(pbVar24 + (ulonglong)(uVar20 & 0xffff) + 2) ^
                                          uVar34) & 0x3800;
                      }
                      *(ushort *)(&stack0x00000044 + lVar12) = uVar34;
                      *(ushort *)(&stack0x00000044 + lVar12) =
                           uVar34 ^ (uVar34 ^ *(ushort *)
                                               (pbVar24 + (ulonglong)(uVar20 & 0xffff) + 2)) & 0x7ff
                      ;
                      break;
                    }
                    if (*(ushort *)(pbVar24 + uVar20) < 0x400) break;
                    puVar1 = (ushort *)((longlong)&sStackX_18 + lVar12 + 2);
                    *puVar1 = *puVar1 | 1;
                    uVar34 = (short)uVar35 - 1;
                    uVar35 = (ulonglong)uVar34;
                    *(ushort *)(&stack0x00000034 + lVar12) = uVar34;
                  } while (uVar34 != 0);
                }
                if ((*pbVar24 & 0x40) == 0) {
                  *(undefined4 *)(&stack0x0000003e + lVar12) = 0;
                }
                else {
                  *(uint *)(&stack0x0000003e + lVar12) = uVar37;
                  *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37 + 0xe;
                  *(undefined8 *)(puVar29 + -8) = 0x101414;
                  uVar15 = func_0x((longlong)&sStackX_18 + lVar12 + 2);
                  *(undefined8 *)(puVar29 + -8) = 0x101423;
                  func_0x(uVar15,&stack0x000000c0 + lVar12);
                  *(undefined8 *)(puVar29 + -8) = 0x10142f;
                  iVar11 = func_0x(&stack0x000000c0 + lVar12);
                  uVar37 = *(int *)((longlong)&sStackX_18 + lVar12 + 4) + iVar11;
                  *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37;
                  pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                }
                if ((*(byte **)(&stack0x00000036 + lVar12) != (byte *)0x0) &&
                   (*(byte **)(&stack0x00000036 + lVar12) < pbVar24 + uVar37)) {
                  *(undefined8 *)(puVar29 + -8) = 0x10146c;
                  cVar8 = func_0x(0x1f01180);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x101475;
                    lVar14 = func_0x();
                    if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar29 + -8) = 0x10148f;
                      cVar8 = func_0x(0x1f01180);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x1014ab;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar29 + 0x20) = 0;
                        *(undefined8 *)(puVar29 + -8) = 0x1014d1;
                        (*_DAT_)(1,0x17f1f08,0x1911bd8,0x877);
                      }
                    }
                  }
                  uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                  *(undefined8 *)(puVar29 + -8) = 0x1014df;
                  func_0x(uVar15,0x12);
                  uVar37 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                }
                if (0x3f3b < uVar37 - 1) {
                  *(undefined8 *)(puVar29 + -8) = 0x1014fa;
                  cVar8 = func_0x(0x1f01180);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x101503;
                    lVar14 = func_0x();
                    if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar29 + -8) = 0x10151d;
                      cVar8 = func_0x(0x1f01180);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x101539;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar29 + 0x20) = 0;
                        *(undefined8 *)(puVar29 + -8) = 0x10155f;
                        (*_DAT_)(1,0x17f1f08,0x1911bd8,0x87c);
                      }
                    }
                  }
                  uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                  *(undefined8 *)(puVar29 + -8) = 0x10156d;
                  func_0x(uVar15,5);
                }
              }
LAB_:
              *(undefined8 *)(puVar29 + -8) = 0x101576;
              func_0x((longlong)&sStackX_18 + lVar12 + 2);
              bVar18 = **(byte **)((longlong)&pbStackX_20 + lVar12) >> 6;
              if ((bVar18 & 1) != 0) {
                *(undefined8 *)(puVar29 + -8) = 0x101598;
                func_0x
                          ((longlong)&sStackX_18 + lVar12 + 2,&stack0x00000118 + lVar12);
              }
              if ((*(byte *)((longlong)&sStackX_18 + lVar12 + 2) & 1) != 0) {
                *(undefined8 *)(puVar29 + -8) = 0x1015b0;
                puVar16 = (undefined4 *)
                          func_0x((longlong)&sStackX_18 + lVar12 + 2,0x400,
                                          &stack0x00000070 + lVar12);
                *(undefined4 *)(&stack0x00000078 + lVar12) = *puVar16;
                *(undefined2 *)(&stack0x0000007c + lVar12) = *(undefined2 *)(puVar16 + 1);
                *(undefined2 *)(&stack0x0000007e + lVar12) = *(undefined2 *)((longlong)puVar16 + 6);
              }
              if ((**(byte **)((longlong)&pbStackX_20 + lVar12) & 0x20) == 0) {
                *(undefined8 *)(puVar29 + -8) = 0x1015d7;
                func_0x((longlong)&sStackX_18 + lVar12 + 2);
              }
              lVar13 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12) +
                       *(longlong *)((longlong)&pbStackX_20 + lVar12);
              *(undefined8 *)(puVar29 + -8) = 0x1015e7;
              iVar11 = func_0x((longlong)&sStackX_18 + lVar12 + 2);
              lVar14 = *(longlong *)((longlong)&pbStackX_20 + lVar12);
              if (iVar11 == 0) {
                uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                uVar27 = (ulonglong)uVar34;
                puVar33 = (ushort *)(lVar14 + (ulonglong)*(uint *)(&stack0x0000002c + lVar12));
                uVar37 = *(uint *)(&stack0x0000002c + lVar12) + (uVar34 + 1) * 2;
                if (*puVar33 != 0) {
                  do {
                    uVar19 = puVar33[uVar31 + 1];
                    puVar33[(uVar31 & 0xffff) + 1] = puVar33[(uVar31 & 0xffff) + 1] & 0x8000;
                    puVar33[(uVar31 & 0xffff) + 1] =
                         puVar33[(uVar31 & 0xffff) + 1] | (uVar19 & 0x7fff) + 2 & 0x7fff;
                    uVar32 = (int)uVar31 + 1;
                    uVar31 = (ulonglong)uVar32;
                  } while (uVar32 < *puVar33);
                  lVar14 = *(longlong *)((longlong)&pbStackX_20 + lVar12);
                }
                iVar11 = *(int *)((longlong)&sStackX_18 + lVar12 + 4);
                *(undefined8 *)(puVar29 + -8) = 0x1016ba;
                func_0x
                          ((ulonglong)uVar37 + 2 + lVar14,(ulonglong)uVar37 + lVar14,iVar11 - uVar37
                          );
                piVar25 = (int *)((longlong)&sStackX_18 + lVar12 + 4);
                *piVar25 = *piVar25 + 2;
                uVar37 = *(int *)(&stack0x00000030 + lVar12) + 2;
                *(uint *)(&stack0x00000030 + lVar12) = uVar37;
                if (uVar34 != 0) {
                  uVar37 = puVar33[(ulonglong)(uVar34 - 1) + 1] & 0x7fff;
                }
                if ((uint)uVar34 < uVar34 + 1) {
                  do {
                    puVar33[(uVar27 & 0xffff) + 1] = (ushort)uVar37 & 0x7fff;
                    uVar32 = (int)uVar27 + 1;
                    uVar27 = (ulonglong)uVar32;
                  } while (uVar32 < uVar34 + 1);
                }
                *puVar33 = *puVar33 + 1;
                *(undefined8 *)(puVar29 + -8) = 0x1016fb;
                func_0x((longlong)&sStackX_18 + lVar12 + 2);
                uVar34 = *(ushort *)
                          (lVar13 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar12) * 2);
                *(undefined8 *)(puVar29 + -8) = 0x101713;
                func_0x(&stack0x00000100 + lVar12);
                *(undefined4 *)(puVar29 + 0x28) = 0;
                *(uint **)(puVar29 + 0x20) = puVar28;
                uVar15 = *(undefined8 *)(&stack0x00000080 + lVar12);
                *(undefined8 *)(puVar29 + -8) = 0x101734;
                func_0x(&stack0x000000f0 + lVar12,uVar15,1);
                *(undefined **)(puVar29 + 0x28) = &stack0x000000a0 + lVar12;
                *(undefined **)(puVar29 + 0x20) = &stack0x000000f0 + lVar12;
                *(undefined8 *)(puVar29 + -8) = 0x101766;
                func_0x(&stack0x00000042 + lVar12,uVar34 & 0x7fff,0x1f9e);
                iVar11 = *(int *)(&stack0x000000a0 + lVar12);
              }
              else {
                uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                uVar37 = *(uint *)(&stack0x00000030 + lVar12);
                if (uVar34 != 0) {
                  uVar37 = *(ushort *)
                            ((ulonglong)*(uint *)(&stack0x0000002c + lVar12) + lVar14 +
                            (ulonglong)uVar34 * 2) & 0x7fff;
                }
                uVar26 = *(ushort *)
                          ((ulonglong)*(uint *)(&stack0x0000002c + lVar12) + lVar14 + 2 +
                          (ulonglong)uVar34 * 2) & 0x7fff;
                if ((uVar37 < *(uint *)(&stack0x00000030 + lVar12)) || (uVar26 < uVar37)) {
                  *(undefined8 *)(puVar29 + -8) = 0x10162b;
                  func_0x(lVar14,7);
                }
                uVar26 = uVar26 - uVar37;
                uVar15 = *(undefined8 *)(&stack0x00000080 + lVar12);
                *(undefined8 *)(puVar29 + -8) = 0x101643;
                iVar11 = func_0x(&stack0x00000042 + lVar12,puVar28,uVar15);
              }
              iVar23 = (iVar11 - uVar26) + *(int *)((longlong)&sStackX_18 + lVar12 + 4);
              *(int *)((longlong)&sStackX_18 + lVar12 + 4) = iVar23;
              if ((*(byte *)((longlong)&sStackX_18 + lVar12 + 2) & 1) != 0) {
                *(ushort *)
                 (lVar13 + 2 + (ulonglong)(*(ushort *)(&stack0x00000034 + lVar12) + 1) * 2) =
                     (ushort)iVar23 | 0x8000;
                iVar23 = (*(int *)((longlong)&sStackX_18 + lVar12 + 4) -
                         *(int *)(&stack0x00000070 + lVar12)) + -2;
              }
              *(ushort *)(lVar13 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar12) * 2) =
                   (ushort)iVar23 | 0x8000;
              lVar14 = (longlong)&sStackX_18 + lVar12 + 2;
              if (iVar11 == 0) {
                uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                *(undefined8 *)(puVar29 + -8) = 0x1017ba;
                func_0x(lVar14,uVar34 + 1);
                if ((**(byte **)((longlong)&pbStackX_20 + lVar12) & 0x20) != 0) {
                  *(short *)(&stack0x00000034 + lVar12) = *(short *)(&stack0x00000034 + lVar12) + 1;
                  puVar33 = (ushort *)((longlong)&sStackX_18 + lVar12 + 2);
                  *puVar33 = *puVar33 & 0xfffd;
                  *(undefined8 *)(puVar29 + -8) = 0x1017d9;
                  func_0x(&stack0x00000042 + lVar12);
                }
              }
              else {
                puVar33 = (ushort *)((longlong)&sStackX_18 + lVar12 + 2);
                *puVar33 = *puVar33 | 2;
                *(undefined8 *)(puVar29 + -8) = 0x1017e9;
                uVar9 = func_0x(lVar14,&stack0x0000008c + lVar12);
                *(undefined2 *)(&stack0x00000042 + lVar12) = uVar9;
              }
              if ((*(byte *)((longlong)&sStackX_18 + lVar12 + 2) & 1) != 0) {
                uVar10 = *(undefined4 *)(&stack0x00000070 + lVar12);
                *(undefined8 *)(puVar29 + -8) = 0x10180b;
                func_0x((longlong)&sStackX_18 + lVar12 + 2,0x400,uVar10);
              }
              if ((bVar18 & 1) != 0) {
                *(undefined8 *)(puVar29 + -8) = 0x101820;
                func_0x
                          ((longlong)&sStackX_18 + lVar12 + 2,&stack0x00000118 + lVar12);
              }
              param_2 = *(longlong **)(&stack0x00000068 + lVar12);
            }
            else {
              bVar18 = (byte)*(ushort *)((longlong)puVar28 + 6);
              if ((*(ushort *)((longlong)puVar28 + 6) & 8) == 0) {
                if (*(int *)((longlong)&sStackX_18 + lVar12 + 4) == 0) {
                  *(undefined2 *)((longlong)&sStackX_18 + lVar12 + 2) = 0;
                  uVar37 = *(uint *)(&stack0x00000028 + lVar12);
                  *(uint *)(&stack0x0000002c + lVar12) = uVar37;
                  if ((**(byte **)((longlong)&pbStackX_20 + lVar12) & 0x10) != 0) {
                    *(uint *)(&stack0x0000002c + lVar12) =
                         uVar37 + 2 +
                         (*(ushort *)(*(byte **)((longlong)&pbStackX_20 + lVar12) + uVar37) + 7 >> 3
                         );
                  }
                  if ((**(byte **)((longlong)&pbStackX_20 + lVar12) & 0x20) == 0) {
                    uVar37 = *(uint *)(&stack0x0000002c + lVar12);
                    *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37;
                    *(undefined2 *)(&stack0x00000034 + lVar12) = 0;
                    *(uint *)(&stack0x00000030 + lVar12) = uVar37;
                  }
                  else {
                    puVar33 = (ushort *)
                              (*(byte **)((longlong)&pbStackX_20 + lVar12) +
                              *(uint *)(&stack0x0000002c + lVar12));
                    uVar34 = *puVar33;
                    *(ushort *)(&stack0x00000034 + lVar12) = uVar34;
                    if (uVar34 == 0) {
                      *(undefined8 *)(puVar29 + -8) = 0x100384;
                      cVar8 = func_0x(0x1f01180);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x10038d;
                        lVar14 = func_0x();
                        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x1003a7;
                          cVar8 = func_0x(0x1f01180);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x1003c3;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x1003e9;
                            (*_DAT_)(1,0x17f1f08,0x1911bd8,0x80f);
                          }
                        }
                      }
                      uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                      *(undefined8 *)(puVar29 + -8) = 0x1003f7;
                      func_0x(uVar15,3);
                      uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                    }
                    uVar26 = *(int *)(&stack0x0000002c + lVar12) + 2 + (uint)uVar34 * 2;
                    *(uint *)(&stack0x00000030 + lVar12) = uVar26;
                    if (0x1f9e < uVar26) {
                      *(undefined8 *)(puVar29 + -8) = 0x100427;
                      cVar8 = func_0x(0x1f01180);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x100430;
                        lVar14 = func_0x();
                        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x10044a;
                          cVar8 = func_0x(0x1f01180);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x100466;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x10048c;
                            (*_DAT_)(1,0x17f1f08,0x1911bd8,0x816);
                          }
                        }
                      }
                      uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                      *(undefined8 *)(puVar29 + -8) = 0x10049a;
                      func_0x(uVar15,4);
                      uVar34 = *(ushort *)(&stack0x00000034 + lVar12);
                      uVar26 = *(uint *)(&stack0x00000030 + lVar12);
                    }
                    uVar31 = (ulonglong)uVar34;
                    uVar37 = puVar33[uVar31] & 0x7fff;
                    *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37;
                    if (uVar37 < uVar26) {
                      *(undefined8 *)(puVar29 + -8) = 0x1004c8;
                      cVar8 = func_0x(0x1f01180);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x1004d1;
                        lVar14 = func_0x();
                        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x1004eb;
                          cVar8 = func_0x(0x1f01180);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x100507;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x10052d;
                            (*_DAT_)(1,0x17f1f08,0x1911bd8,0x81d);
                          }
                        }
                      }
                      uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                      *(undefined8 *)(puVar29 + -8) = 0x10053b;
                      func_0x(uVar15,4);
                      uVar31 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar12);
                      uVar26 = *(uint *)(&stack0x00000030 + lVar12);
                      uVar37 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                    }
                    do {
                      if (-1 < (short)puVar33[(ulonglong)((int)uVar31 - 1) + 1]) break;
                      lVar14 = (ulonglong)*(uint *)(&stack0x0000002c + lVar12) +
                               *(longlong *)((longlong)&pbStackX_20 + lVar12);
                      uVar32 = uVar26;
                      if ((int)uVar31 != 1) {
                        uVar32 = *(ushort *)(lVar14 + -2 + uVar31 * 2) & 0x7fff;
                      }
                      if ((uVar32 < uVar26) ||
                         ((*(ushort *)(lVar14 + uVar31 * 2) & 0x7fff) < uVar32)) {
                        uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                        *(undefined8 *)(puVar29 + -8) = 0x10059a;
                        func_0x(uVar15,7);
                        uVar31 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar12);
                        uVar26 = *(uint *)(&stack0x00000030 + lVar12);
                        uVar37 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                      }
                      if ((uVar32 < uVar26) || (uVar37 < uVar32)) goto LAB_;
                      uVar34 = *(ushort *)
                                ((ulonglong)uVar32 + *(longlong *)((longlong)&pbStackX_20 + lVar12))
                      ;
                      if (uVar34 == 5) {
                        puVar33 = (ushort *)((longlong)&sStackX_18 + lVar12 + 2);
                        *puVar33 = *puVar33 | 2;
                        *(short *)(&stack0x00000034 + lVar12) = (short)uVar31 + -1;
                        *(short *)(&stack0x00000042 + lVar12) = (short)uVar32;
                        lVar14 = (ulonglong)(uVar32 & 0xffff) +
                                 *(longlong *)((longlong)&pbStackX_20 + lVar12);
                        uVar34 = *(ushort *)(lVar14 + 2);
                        uVar19 = *(ushort *)(&stack0x00000044 + lVar12);
                        if ((uVar34 >> 0xe & 1) == 0) {
                          uVar19 = uVar19 & 0xc7ff;
                        }
                        else {
                          uVar19 = uVar19 ^ (uVar19 ^ uVar34) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000044 + lVar12) = uVar19;
                        *(ushort *)(&stack0x00000044 + lVar12) =
                             uVar19 ^ (uVar19 ^ *(ushort *)(lVar14 + 2)) & 0x7ff;
                        break;
                      }
                      if (uVar34 < 0x400) break;
                      puVar1 = (ushort *)((longlong)&sStackX_18 + lVar12 + 2);
                      *puVar1 = *puVar1 | 1;
                      uVar34 = (short)uVar31 - 1;
                      uVar31 = (ulonglong)uVar34;
                      *(ushort *)(&stack0x00000034 + lVar12) = uVar34;
                    } while (uVar34 != 0);
                  }
                  if ((**(byte **)((longlong)&pbStackX_20 + lVar12) & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000003e + lVar12) = 0;
                  }
                  else {
                    *(uint *)(&stack0x0000003e + lVar12) = uVar37;
                    *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37 + 0xe;
                    *(undefined8 *)(puVar29 + -8) = 0x100689;
                    uVar15 = func_0x((longlong)&sStackX_18 + lVar12 + 2);
                    *(undefined8 *)(puVar29 + -8) = 0x100698;
                    func_0x(uVar15,&stack0x000000b0 + lVar12);
                    *(undefined8 *)(puVar29 + -8) = 0x1006a4;
                    iVar11 = func_0x(&stack0x000000b0 + lVar12);
                    uVar37 = *(int *)((longlong)&sStackX_18 + lVar12 + 4) + iVar11;
                    *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar37;
                  }
                  if ((*(ulonglong *)(&stack0x00000036 + lVar12) != 0) &&
                     (*(ulonglong *)(&stack0x00000036 + lVar12) <
                      (ulonglong)uVar37 + *(longlong *)((longlong)&pbStackX_20 + lVar12))) {
                    *(undefined8 *)(puVar29 + -8) = 0x1006de;
                    cVar8 = func_0x(0x1f01180);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar29 + -8) = 0x1006e7;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar29 + -8) = 0x100701;
                        cVar8 = func_0x(0x1f01180);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x10071d;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(puVar29 + 0x20) = 0;
                          *(undefined8 *)(puVar29 + -8) = 0x100743;
                          (*_DAT_)(1,0x17f1f08,0x1911bd8,0x877);
                        }
                      }
                    }
                    uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                    *(undefined8 *)(puVar29 + -8) = 0x100751;
                    func_0x(uVar15,0x12);
                    uVar37 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                  }
                  if (0x3f3b < uVar37 - 1) {
                    *(undefined8 *)(puVar29 + -8) = 0x10076c;
                    cVar8 = func_0x(0x1f01180);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar29 + -8) = 0x100775;
                      lVar14 = func_0x();
                      if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar29 + -8) = 0x10078f;
                        cVar8 = func_0x(0x1f01180);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x1007ab;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(puVar29 + 0x20) = 0;
                          *(undefined8 *)(puVar29 + -8) = 0x1007d1;
                          (*_DAT_)(1,0x17f1f08,0x1911bd8,0x87c);
                        }
                      }
                    }
                    uVar15 = *(undefined8 *)((longlong)&pbStackX_20 + lVar12);
                    *(undefined8 *)(puVar29 + -8) = 0x1007df;
                    func_0x(uVar15,5);
                  }
                }
LAB_:
                uVar26 = *puVar28;
                uVar37 = uVar26 + 1;
                uVar32 = *(uint *)(&stack0x00000028 + lVar12);
                if (uVar32 < uVar37) {
                  *(undefined8 *)(puVar29 + -8) = 0x100802;
                  func_0x((longlong)&sStackX_18 + lVar12 + 2,0,uVar37 - uVar32);
                  if ((1 << (**(byte **)((longlong)&pbStackX_20 + lVar12) & 0xe) & 0x1105U) != 0) {
                    *(short *)(*(byte **)((longlong)&pbStackX_20 + lVar12) + 2) = (short)uVar37;
                  }
                  *(uint *)(&stack0x00000028 + lVar12) = uVar37;
                  uVar26 = *puVar28;
                }
                if (pcVar5 != (char *)0x0) {
                  *(char *)((longlong)(int)uVar26 + *(longlong *)((longlong)&pbStackX_20 + lVar12))
                       = *pcVar5;
                }
              }
              else {
                cVar8 = *pcVar5;
                uVar32 = uVar37 + 1;
                uVar26 = *(uint *)(&stack0x00000028 + lVar12);
                if (uVar26 < uVar32) {
                  *(undefined8 *)(puVar29 + -8) = 0x1002cb;
                  func_0x((longlong)&sStackX_18 + lVar12 + 2,0,uVar32 - uVar26);
                  pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                  if ((1 << (*pbVar24 & 0xe) & 0x1105U) != 0) {
                    *(short *)(pbVar24 + 2) = (short)uVar32;
                    pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                  }
                  *(uint *)(&stack0x00000028 + lVar12) = uVar32;
                  bVar18 = *(byte *)((longlong)puVar28 + 6);
                }
                else {
                  pbVar24 = *(byte **)((longlong)&pbStackX_20 + lVar12);
                }
                if (cVar8 == '\0') {
                  pbVar24[(int)uVar37] = pbVar24[(int)uVar37] & ~(byte)(1 << (bVar18 & 7));
                }
                else {
                  pbVar24[(int)uVar37] = pbVar24[(int)uVar37] | (byte)(1 << (bVar18 & 7));
                }
              }
            }
          }
          else {
            *(undefined8 *)(puVar29 + 0x20) = 0x156e3e8;
            *(undefined8 *)(puVar29 + -8) = 0x100288;
            (*_DAT_)(1,0x1973240,0x199fb80);
          }
LAB_:
          puVar28 = puVar28 + 0x14;
          *(uint **)(&stack0x00000058 + lVar12) = puVar28;
          iVar11 = *(int *)(&stack0x00000088 + lVar12);
          *(uint *)(&stack0x00000088 + lVar12) = iVar11 + 1U;
        } while (iVar11 + 1U < *(uint *)(&stack0x000000a4 + lVar12));
        uVar37 = *(uint *)(&stack0x00000074 + lVar12);
      }
      puVar33 = (ushort *)0x0;
      if (uVar37 != 0) {
        lVar14 = *(longlong *)(&stack0x00000098 + lVar12);
        do {
          uVar31 = (ulonglong)uVar37;
          uVar26 = uVar37 - 1;
          if (*(int *)((ulonglong)uVar26 * 0x20 + 8 + lVar14) != 0) {
            *(ushort *)(&stack0x00000034 + lVar12) = (ushort)uVar37;
            iVar11 = *(int *)(&stack0x0000002c + lVar12) + 2 + uVar37 * 2;
            *(int *)(&stack0x00000030 + lVar12) = iVar11;
            *(int *)((longlong)&sStackX_18 + lVar12 + 4) = iVar11;
            **(byte **)((longlong)&pbStackX_20 + lVar12) =
                 **(byte **)((longlong)&pbStackX_20 + lVar12) | 0x20;
            uVar26 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
            if (uVar26 < 0x1f7d) {
              puVar33 = (ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000002c + lVar12) +
                        *(longlong *)((longlong)&pbStackX_20 + lVar12));
              *puVar33 = (ushort)uVar37;
              uVar26 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
            }
            if (uVar37 != 0) {
              puVar28 = (uint *)(lVar14 + 0xc);
              do {
                puVar33 = puVar33 + 1;
                uVar27 = (ulonglong)uVar26;
                lVar14 = *(longlong *)((longlong)&pbStackX_20 + lVar12);
                uVar37 = puVar28[-1];
                uVar26 = uVar26 + uVar37;
                *(uint *)((longlong)&sStackX_18 + lVar12 + 4) = uVar26;
                if (uVar26 < 0x1f7d) {
                  *puVar33 = (ushort)((*puVar28 & 1) << 0xf) | (ushort)uVar26 & 0x7fff;
                  uVar15 = *(undefined8 *)(puVar28 + -3);
                  *(undefined8 *)(puVar29 + -8) = 0x101a88;
                  func_0x(uVar27 + lVar14,uVar37,uVar15,uVar37);
                  uVar26 = *(uint *)((longlong)&sStackX_18 + lVar12 + 4);
                }
                puVar28 = puVar28 + 8;
                uVar31 = uVar31 - 1;
              } while (uVar31 != 0);
            }
            break;
          }
          uVar37 = uVar26;
        } while (uVar26 != 0);
      }
    }
    param_1 = *(longlong *)(&stack0x00000060 + lVar12);
    uVar37 = *(uint *)(&stack0x00000054 + lVar12);
    puVar30 = puVar29;
  }
  else {
    if (bVar38) {
      uVar15 = 0x1f69a10;
      uVar21 = 0x1f5bf78;
    }
    else {
      uVar15 = 0x1f5c3c8;
      uVar21 = 0x1f5bf40;
    }
    if ((bVar18 & 1) == 0) {
      uVar15 = uVar21;
    }
    *(undefined8 *)(param_1 + 0x3a0) = uVar15;
    *(undefined8 *)(param_1 + 0x3a8) = 0;
    *(longlong *)((longlong)alStackX_8 + lVar12) = param_1 + 0x290;
    *(undefined **)((longlong)&pbStackX_20 + lVar12 + -0x20) = &stack0x0000008c + lVar12;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar12) = 0x1f7c;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar12) = 0x1f9e;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar12) = &stack0x000001f8 + lVar12;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101fbb;
    func_0x(param_1 + 0x3b8,param_2,2,psVar2);
  }
  uVar15 = *(undefined8 *)(&stack0x000000c8 + lVar12);
  *(undefined8 *)(puVar30 + -8) = 0x100fe3;
  iVar11 = func_0x(uVar15);
  if ((iVar11 == 0) && (uVar37 == 0)) {
    *(undefined8 *)(puVar30 + -8) = 0x100ffb;
    func_0x(uVar15,1);
  }
  *(undefined8 *)(puVar30 + 0x28) = *(undefined8 *)(&stack0x000000d0 + lVar12);
  *(undefined8 *)(puVar30 + 0x20) = 0;
  *(undefined8 *)(puVar30 + -8) = 0x10101e;
  iVar11 = func_0x(param_1,psVar2,0,0);
  if ((iVar11 != 0) && (*(int *)(param_1 + 0x1cc) != 0)) {
    *(short **)(param_1 + 0x3a0) = psVar2;
    *(undefined8 *)(param_1 + 0x3a8) = 0;
    lVar14 = *(longlong *)(&stack0x000000d8 + lVar12);
    *(undefined8 *)(puVar30 + -8) = 0x101054;
    func_0x(param_1 + 0x3b8,lVar14 + 0x78);
  }
  plVar6 = *(longlong **)(&stack0x000000e0 + lVar12);
  if (plVar6 != (longlong *)0x0) {
    pcVar7 = *(code **)(*plVar6 + 0xd0);
    *(undefined8 *)(puVar30 + -8) = 0x10106f;
    (*pcVar7)(plVar6,0);
  }
  uVar31 = *(ulonglong *)(&stack0x00002198 + lVar12);
  *(undefined8 *)(puVar30 + -8) = 0x101081;
  func_0x(uVar31 ^ (ulonglong)psVar2);
  return;
}

