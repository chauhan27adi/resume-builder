
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined *
FUN_(byte **param_1,undefined (*param_2) [16],undefined *param_3,uint param_4,
            undefined *param_5,undefined4 param_6,uint *param_7,uint *param_8)

{
  longlong *plVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  ulonglong *puVar6;
  ushort uVar7;
  uint uVar8;
  ulonglong uVar9;
  uint uVar10;
  ushort uVar11;
  short sVar12;
  longlong lVar13;
  byte *pbVar14;
  ushort *puVar15;
  longlong unaff_GS_OFFSET;
  undefined auStackX_8 [8];
  int iStack_58;
  uint uStack_54;
  undefined auStack_50 [8];
  undefined auStack_48 [6];
  byte bStack_42;
  int *piStack_40;
  
  if ((**param_1 & 2) != 0) {
    _auStack_48 = *param_2;
    uVar11 = SUB162(_auStack_48,6);
    if ((SUB168(_auStack_48,0) >> 0x30 & 0x10) != 0) {
      uVar11 = uVar11 & 0xffef;
      _auStack_48 = SUB168(_auStack_48,0) & 0xffefffffffffffff;
      piStack_40 = (int *)0x0;
    }
    if (param_1[1] == (byte *)0x0) {
      iVar4 = 0;
      if (*(short *)(param_1 + 2) == 0) {
        if ((auStack_48._0_4_ & 0xc0000000) == 0x80000000) {
          iVar4 = func_0x((longlong)param_1 + 0x12);
          if (iVar4 == 0) {
            iStack_58 = 0;
            piVar5 = (int *)0x0;
          }
          else {
            piVar5 = (int *)func_0x((longlong)param_1 + 0x3a,auStack_48,&iStack_58,
                                            auStack_50);
          }
        }
        else {
          pbVar14 = param_1[3];
          bVar2 = *pbVar14;
          iVar3 = iVar4;
          if ((bVar2 & 0x10) == 0) {
            if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
              uVar11 = ~(uVar11 >> 4);
              goto LAB_;
            }
LAB_:
            if ((int)auStack_48._0_4_ < 0) {
              if (*(int *)((longlong)param_1 + 0x14) == 0) {
                uVar8 = *(uint *)(param_1 + 4);
                uVar9 = (ulonglong)uVar8;
                *(uint *)((longlong)param_1 + 0x24) = uVar8;
                *(undefined2 *)((longlong)param_1 + 0x12) = 0;
                bVar2 = *pbVar14;
                if ((bVar2 & 0x10) != 0) {
                  uVar8 = uVar8 + 2 + (*(ushort *)(pbVar14 + uVar9) + 7 >> 3);
                  uVar9 = (ulonglong)uVar8;
                  *(uint *)((longlong)param_1 + 0x24) = uVar8;
                  bVar2 = *pbVar14;
                }
                if ((bVar2 & 0x20) == 0) {
                  *(int *)((longlong)param_1 + 0x14) = (int)uVar9;
                  *(undefined2 *)((longlong)param_1 + 0x2c) = 0;
                  *(int *)(param_1 + 5) = (int)uVar9;
                }
                else {
                  puVar15 = (ushort *)(pbVar14 + uVar9);
                  uVar11 = *puVar15;
                  *(ushort *)((longlong)param_1 + 0x2c) = uVar11;
                  if (uVar11 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar13 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar13 != 0)) &&
                       ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                        (*(char *)(lVar13 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        (*_DAT_)(1,0x17218a8,0x1841578,0x80f,0);
                      }
                    }
                    func_0x(param_1[3],3);
                    uVar11 = *(ushort *)((longlong)param_1 + 0x2c);
                    uVar9 = (ulonglong)*(uint *)((longlong)param_1 + 0x24);
                  }
                  uVar8 = (int)uVar9 + (uVar11 + 1) * 2;
                  *(uint *)(param_1 + 5) = uVar8;
                  if (0x1f9e < uVar8) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar13 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar13 != 0 &&
                        ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                         (*(char *)(lVar13 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        (*_DAT_)(1,0x17218a8,0x1841578,0x816,0);
                      }
                    }
                    func_0x(param_1[3],4);
                    uVar11 = *(ushort *)((longlong)param_1 + 0x2c);
                    uVar8 = *(uint *)(param_1 + 5);
                  }
                  uVar9 = (ulonglong)uVar11;
                  uVar11 = puVar15[uVar9];
                  *(uint *)((longlong)param_1 + 0x14) = uVar11 & 0x7fff;
                  if ((uVar11 & 0x7fff) < uVar8) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar13 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar13 != 0)) &&
                       ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                        (*(char *)(lVar13 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        (*_DAT_)(1,0x17218a8,0x1841578,0x81d,0);
                      }
                    }
                    func_0x(param_1[3],4);
                    uVar9 = (ulonglong)*(ushort *)((longlong)param_1 + 0x2c);
                  }
                  if ((short)puVar15[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
                    pbVar14 = param_1[3];
                    do {
                      if ((int)uVar9 == 1) {
                        uVar8 = *(uint *)(param_1 + 5);
                        uVar10 = uVar8;
LAB_:
                        if ((*(ushort *)
                              (pbVar14 + uVar9 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x24))
                            & 0x7fff) < uVar8) goto LAB_;
                      }
                      else {
                        uVar10 = *(uint *)(param_1 + 5);
                        uVar8 = *(ushort *)
                                 (pbVar14 +
                                 uVar9 * 2 + ((ulonglong)*(uint *)((longlong)param_1 + 0x24) - 2)) &
                                0x7fff;
                        if (uVar10 <= uVar8) goto LAB_;
LAB_:
                        func_0x(pbVar14,7);
                        uVar10 = *(uint *)(param_1 + 5);
                      }
                      if ((uVar8 < uVar10) || (*(uint *)((longlong)param_1 + 0x14) < uVar8))
                      goto LAB_;
                      pbVar14 = param_1[3];
                      if (*(ushort *)(pbVar14 + uVar8) == 5) {
                        *(ushort *)((longlong)param_1 + 0x12) =
                             *(ushort *)((longlong)param_1 + 0x12) | 2;
                        *(short *)((longlong)param_1 + 0x2c) =
                             *(short *)((longlong)param_1 + 0x2c) + -1;
                        uVar11 = *(ushort *)((longlong)param_1 + 0x3c) & 0xc7ff;
                        uVar10 = uVar8 & 0xffff;
                        *(short *)((longlong)param_1 + 0x3a) = (short)uVar8;
                        pbVar14 = param_1[3];
                        if ((*(ushort *)(pbVar14 + (ulonglong)uVar10 + 2) & 0x4000) != 0) {
                          uVar11 = *(ushort *)(pbVar14 + (ulonglong)uVar10 + 2) & 0x3800 | uVar11;
                        }
                        *(ushort *)((longlong)param_1 + 0x3c) = uVar11;
                        *(ushort *)((longlong)param_1 + 0x3c) =
                             (uVar11 ^ *(ushort *)(pbVar14 + (ulonglong)uVar10 + 2)) & 0x7ff ^
                             uVar11;
                        break;
                      }
                      if (*(ushort *)(pbVar14 + uVar8) < 0x400) goto LAB_;
                      *(ushort *)((longlong)param_1 + 0x12) =
                           *(ushort *)((longlong)param_1 + 0x12) | 1;
                      uVar11 = *(short *)((longlong)param_1 + 0x2c) - 1;
                      *(ushort *)((longlong)param_1 + 0x2c) = uVar11;
                      if ((uVar11 == 0) ||
                         (uVar9 = (ulonglong)uVar11,
                         -1 < (short)puVar15[(ulonglong)(uVar11 - 1) + 1])) goto LAB_;
                    } while( true );
                  }
                  uVar9 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
                }
                goto LAB_;
              }
              goto LAB_;
            }
            if ((_auStack_48 & (undefined  [16])0x8000000000000) != (undefined  [16])0x0) {
              iStack_58 = 1;
              piVar5 = (int *)0x14a62e4;
              if ((pbVar14[(int)auStack_48._0_4_] & (byte)(1 << (bStack_42 & 7))) == 0) {
                piVar5 = (int *)0x14a6908;
              }
              goto LAB_;
            }
            if ((_auStack_48 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
              if ((bVar2 & 0x10) == 0) {
                if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) goto LAB_;
              }
              else {
                if ((int)*(uint *)(param_1 + 4) <= (int)auStack_48._0_4_) goto LAB_;
                if (*(ushort *)(pbVar14 + *(uint *)(param_1 + 4)) < (ushort)auStack_48._4_2_) {
                  iStack_58 = *piStack_40;
                  piVar5 = piStack_40 + 1;
                  goto LAB_;
                }
              }
            }
            piVar5 = (int *)(pbVar14 + (int)auStack_48._0_4_);
            goto LAB_;
          }
          uVar8 = *(uint *)(param_1 + 4);
          if ((int)auStack_48._0_4_ < (int)uVar8) {
            if ((uint)*(ushort *)(pbVar14 + uVar8) < (uint)(ushort)auStack_48._4_2_) {
              uVar11 = ~(uVar11 >> 4);
            }
            else {
              uVar10 = (ushort)auStack_48._4_2_ - 1;
              iVar3 = 1;
              uVar11 = (ushort)(pbVar14[(ulonglong)uVar8 + (ulonglong)(uVar10 >> 3) + 2] >>
                               ((byte)uVar10 & 7));
            }
          }
          else {
            uVar11 = ~(uVar11 >> 4);
          }
LAB_:
          if ((uVar11 & 1) == 0) {
            if ((iVar3 != 0) ||
               ((_auStack_48 & (undefined  [16])0x10000000000000) == (undefined  [16])0x0))
            goto LAB_;
            iStack_58 = *piStack_40;
            piVar5 = piStack_40 + 1;
          }
          else {
            iStack_58 = 0;
            piVar5 = (int *)0x0;
          }
        }
      }
      else {
        uStack_54 = 0;
        piVar5 = (int *)func_0x((longlong)param_1 + 0x12,auStack_48,uVar11,&iStack_58,
                                        &uStack_54);
        if ((((*(short *)(param_1 + 2) != 0) &&
             (plVar1 = (longlong *)param_1[4], plVar1 != (longlong *)0x0)) && (*plVar1 != 0)) &&
           (((_auStack_48 & (undefined  [16])0x8000000000000) == (undefined  [16])0x0 &&
            ((uStack_54 & 1) == 0)))) {
          if ((piVar5 == (int *)0x0) || (piVar5 == (int *)0x14a62e4)) {
            iStack_58 = 0;
            piVar5 = (int *)0x0;
          }
          else {
            piVar5 = (int *)func_0x
                                      (plVar1,auStack_48,piVar5,iStack_58,0,0,&iStack_58,uStack_54);
          }
        }
      }
    }
    else {
      piVar5 = (int *)func_0x(param_1[1] + 0x18,auStack_48,&iStack_58);
    }
    goto LAB_;
  }
  goto LAB_;
LAB_:
  uVar9 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
LAB_:
  if ((*param_1[3] & 0x40) == 0) {
    *(undefined4 *)((longlong)param_1 + 0x36) = 0;
  }
  else {
    *(int *)((longlong)param_1 + 0x36) = (int)uVar9;
    *(int *)((longlong)param_1 + 0x14) = (int)uVar9 + 0xe;
    puVar6 = (ulonglong *)func_0x((longlong)param_1 + 0x12);
    uVar9 = *puVar6;
    uVar7 = (ushort)(uVar9 >> 0x30);
    uVar11 = uVar7;
    if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
      uVar11 = uVar7 & 0xdfff;
      if ((uVar9 & 0x4000000000000000) != 0) {
        uVar11 = uVar7 | 0x2000;
      }
    }
    if (uVar11 == 0xfffc) {
      iVar4 = (int)((uVar9 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)((longlong)param_1 + 0x14) = *(int *)((longlong)param_1 + 0x14) + iVar4;
    uVar9 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
  }
  iVar4 = (int)uVar9;
  if ((*(byte **)((longlong)param_1 + 0x2e) != (byte *)0x0) &&
     (*(byte **)((longlong)param_1 + 0x2e) < param_1[3] + uVar9)) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar13 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar13 != 0 &&
         (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
        (*(char *)(lVar13 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x17218a8,0x1841578,0x877,0);
      }
    }
    func_0x(param_1[3],0x12);
    iVar4 = *(int *)((longlong)param_1 + 0x14);
  }
  if (0x3f3b < iVar4 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar13 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar13 != 0 &&
        ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 && (*(char *)(lVar13 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x17218a8,0x1841578,0x87c,0);
      }
    }
    func_0x(param_1[3],5);
  }
LAB_:
  sVar12 = -auStack_48._0_2_;
  if ((_auStack_48 & (undefined  [16])0x10000000000000) == (undefined  [16])0x0) {
LAB_:
    piVar5 = (int *)param_1[3];
    lVar13 = (longlong)sVar12;
    if ((uint)*(ushort *)((longlong)param_1 + 0x2c) < (uint)(int)sVar12) {
LAB_:
      iStack_58 = 0;
    }
    else {
      uVar8 = *(uint *)((longlong)param_1 + 0x24);
      if (sVar12 == 1) {
        uVar10 = *(uint *)(param_1 + 5);
        uVar8 = *(ushort *)((longlong)piVar5 + lVar13 * 2 + (ulonglong)uVar8) & 0x7fff;
LAB_:
        if (uVar8 < uVar10) goto LAB_;
      }
      else {
        puVar15 = (ushort *)((longlong)piVar5 + lVar13 * 2 + (ulonglong)uVar8);
        uVar10 = *(ushort *)((longlong)piVar5 + lVar13 * 2 + ((ulonglong)uVar8 - 2)) & 0x7fff;
        piVar5 = (int *)param_1[3];
        uVar8 = *puVar15 & 0x7fff;
        if (*(uint *)(param_1 + 5) <= uVar10) goto LAB_;
LAB_:
        func_0x(piVar5,7);
        piVar5 = (int *)param_1[3];
      }
      iStack_58 = uVar8 - uVar10;
      piVar5 = (int *)((longlong)piVar5 + (ulonglong)uVar10);
    }
  }
  else {
    bVar2 = *param_1[3];
    if ((bVar2 & 0x10) == 0) {
      if ((1 << (bVar2 & 0xe) & 0x1105U) == 0) goto LAB_;
    }
    else if (((int)auStack_48._0_4_ < (int)*(uint *)(param_1 + 4)) &&
            ((ushort)auStack_48._4_2_ <= *(ushort *)(param_1[3] + *(uint *)(param_1 + 4))))
    goto LAB_;
LAB_:
    iStack_58 = *piStack_40;
    piVar5 = piStack_40 + 1;
  }
LAB_:
  if (piVar5 != (int *)0x0) {
    param_3 = (undefined *)func_0x(param_3,param_4,piVar5,iStack_58,param_5,param_6,param_7)
    ;
    goto LAB_;
  }
LAB_:
  *param_7 = param_4;
LAB_:
  if ((((**param_1 & 4) != 0) && (1 < *param_7)) &&
     (iVar4 = func_0x(param_1,param_3,*param_7,auStackX_8), iVar4 != 0)) {
    *param_7 = 1;
    *param_8 = *param_8 | 4;
    *param_5 = auStackX_8[0];
    return param_5;
  }
  return param_3;
}

