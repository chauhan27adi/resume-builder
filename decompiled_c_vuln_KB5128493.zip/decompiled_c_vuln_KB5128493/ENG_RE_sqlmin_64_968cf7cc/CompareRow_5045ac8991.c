
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x010fedd5) */
/* WARNING: Removing unreachable block (ram,0x00100d96) */
/* WARNING: Removing unreachable block (ram,0x0010e228) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,undefined8 *param_2,int param_3,longlong param_4)

{
  uint *puVar1;
  uint *puVar2;
  char cVar3;
  ushort uVar4;
  int iVar5;
  byte *pbVar6;
  byte bVar7;
  uint uVar8;
  longlong lVar9;
  uint uVar10;
  longlong lVar11;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar12;
  undefined8 unaff_RBX;
  uint uVar13;
  longlong lVar14;
  ulonglong uVar15;
  uint auStackX_18 [2];
  ulonglong *puStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  puVar2 = (uint *)((longlong)auStackX_18 + lVar9);
  *(undefined8 *)(&stack0x00002238 + lVar9) = unaff_RBX;
  *(ulonglong *)(&stack0x000021d8 + lVar9) = _DAT_ ^ (ulonglong)puVar2;
  *(int *)(&stack0x00000088 + lVar9) = param_3;
  *(undefined8 **)(&stack0x000000c0 + lVar9) = param_2;
  *(short **)(&stack0x000000b0 + lVar9) = param_1;
  uVar8 = *(uint *)(&stack0x00002248 + lVar9);
  uVar12 = (ulonglong)uVar8;
  *(longlong *)(&stack0x000000b8 + lVar9) = param_4;
  lVar14 = *(longlong *)(param_4 + 8);
  *(undefined4 *)(&stack0x00000038 + lVar9) = 0;
  uVar15 = (ulonglong)(uVar8 != 0);
  *(undefined8 *)(&stack0x00000090 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000098 + lVar9) = 0;
  iVar5 = *(int *)(lVar14 + 0x100);
  uVar8 = (uint)(uVar8 != 0);
  *(uint *)(&stack0x0000008c + lVar9) = uVar8;
  if (iVar5 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined4 *)(&stack0x00000084 + lVar9) = 0;
  if (param_3 == 0) {
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100378;
    func_0x(*(ulonglong *)(&stack0x000021d8 + lVar9) ^ (ulonglong)puVar2,uVar12,uVar15);
    return;
  }
  *(ulonglong *)(&stack0x000000d0 + lVar9) = uVar15 * 0x10;
  *(undefined8 *)(&stack0x000000a8 + lVar9) = 0;
  *(short **)(&stack0x000000a0 + lVar9) = param_1 + 1;
  *(undefined8 *)((longlong)&puStackX_20 + lVar9) = *param_2;
  lVar14 = **(longlong **)(*(longlong *)(param_4 + 8) + 0x160);
  lVar11 = *(longlong *)(lVar14 + 0x38);
  if (lVar11 == lVar14 + 0x30) {
    lVar11 = 0;
  }
  lVar14 = 0;
  if (lVar11 != 0) {
    lVar14 = lVar11 + -0x160;
  }
  *(longlong *)(&stack0x00000030 + lVar9) = lVar14;
  puVar1 = (uint *)(uVar15 * 0x10 + lVar14);
  if (uVar8 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bVar7 = *(byte *)(lVar14 + 0x20) >> 1;
  uVar4 = *(ushort *)(lVar14 + 0x38);
  if (*param_1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar8 = *puVar1;
  if ((uVar8 & 0xc0000000) == 0x80000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((bVar7 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pbVar6 = *(byte **)(param_1 + 4);
  if ((*pbVar6 & 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar13 = *(uint *)(param_1 + 8);
  if ((int)uVar8 < (int)uVar13) {
    if ((uint)*(ushort *)(puVar1 + 1) <= (uint)*(ushort *)(pbVar6 + uVar13)) {
      if (((bVar7 & 1) != 0) &&
         (uVar10 = *(ushort *)(puVar1 + 1) - 1,
         (pbVar6[(ulonglong)uVar13 + (ulonglong)(uVar10 >> 3) + 2] >> ((byte)uVar10 & 7) & 1) != 0))
      {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((int)uVar8 < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(ushort *)((longlong)puVar1 + 6) & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(ushort *)((longlong)puVar1 + 6) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *puVar2 = (uint)uVar4;
      if ((*(byte *)(lVar14 + 0x21) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(char *)(lVar14 + 0x34) == '8') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar15 = 0;
      uVar12 = **(ulonglong **)((longlong)&puStackX_20 + lVar9);
      if ((longlong)(int)*puVar1 + *(longlong *)(param_1 + 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (uVar12 != 0) {
        uVar13 = (uint)*(byte *)(lVar14 + 0x34);
        uVar8 = *(byte *)(lVar14 + 0x34) - 0x6a;
        if (uVar8 < 0x86) {
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)uVar8 + 0x1005f4) * 4 +
                                 0x1005ec) + 0xef050);
                    /* WARNING: Could not emulate address calculation at 0x00100254 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if (uVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(short *)((longlong)*(ulonglong **)((longlong)&puStackX_20 + lVar9) + 0xc) != 0) {
          if (uVar13 != 0xa7) {
            if (uVar13 == 0xad) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            if (uVar13 != 0xaf) {
              if ((uVar13 == 0xe7) || (uVar13 == 0xef)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              if ((*(byte *)(*(longlong *)(&stack0x00000030 + lVar9) + 0x21) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              if (uVar13 - 0x24 < 0xcd) {
                UNRECOVERED_JUMPTABLE_00 =
                     (code *)((ulonglong)
                              *(uint *)((ulonglong)
                                        *(byte *)((longlong)(int)(uVar13 - 0x24) + 0x1006c8) * 4 +
                                       0x10067c) + 0xef050);
                    /* WARNING: Could not emulate address calculation at 0x001002df */
                    /* WARNING: Treating indirect jump as call */
                (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                return;
              }
              cVar3 = *(char *)(*(longlong *)((longlong)&puStackX_20 + lVar9) + 0xe);
              if (((cVar3 + 0x7fU & 0xf9) != 0) || (cVar3 == -0x79)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              iVar5 = *(int *)(&stack0x00000084 + lVar9);
              *(uint *)(&stack0x00000084 + lVar9) = iVar5 + 1U;
              *(longlong *)(&stack0x000000a8 + lVar9) = *(longlong *)(&stack0x000000a8 + lVar9) + 1;
              if (iVar5 + 1U < *(uint *)(&stack0x00000088 + lVar9)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              goto LAB_;
            }
          }
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

