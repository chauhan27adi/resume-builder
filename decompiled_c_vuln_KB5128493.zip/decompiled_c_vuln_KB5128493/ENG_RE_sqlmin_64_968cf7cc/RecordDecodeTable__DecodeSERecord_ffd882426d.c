
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,byte *param_2,uint param_3)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  code *UNRECOVERED_JUMPTABLE;
  longlong lVar4;
  uint uVar5;
  longlong lVar6;
  longlong lVar7;
  longlong unaff_GS_OFFSET;
  ulonglong uVar8;
  ulonglong uVar9;
  ushort uStack_c48;
  undefined auStack_c46 [2];
  undefined4 uStack_c44;
  byte *pbStack_c40;
  undefined8 uStack_c38;
  undefined8 uStack_c2a;
  undefined2 uStack_c22;
  undefined2 uStack_c20;
  undefined6 uStack_c1e;
  uint uStack_b68;
  undefined4 uStack_a8c;
  ushort uStack_9b8;
  ushort uStack_9b4;
  undefined4 uStack_868;
  undefined2 uStack_864;
  longlong lStack_800;
  uint uStack_62c;
  undefined4 uStack_618;
  longlong lStack_4f0;
  undefined *puStack_488;
  undefined8 uStack_368;
  byte *pbStack_1f0;
  undefined *puStack_1e8;
  byte *pbStack_1e0;
  undefined auStack_1d8 [400];
  ulonglong uStack_48;
  
  uStack_368 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_c48;
  uStack_a8c = 0;
  lVar6 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar7 = *(longlong *)(lVar6 + 0x100);
  if (lVar7 == 0) {
    lStack_800 = lVar7;
    (*_DAT_)(0);
    lVar7 = *(longlong *)(lVar6 + 0x100);
  }
  *(uint *)(lVar7 + 0x268) = *(uint *)(lVar7 + 0x268) | 0x40;
  uVar9 = 0;
  uVar8 = _DAT_;
  lStack_800 = lVar7;
  lStack_4f0 = lVar7;
  func_0x(auStack_1d8,0,0,0,_DAT_,0);
  uStack_c48 = 0xffff;
  pbStack_c40 = (byte *)0x0;
  uStack_c44 = 0;
  uStack_c2a = 0;
  uStack_c20 = 0;
  uStack_c1e = 0;
  uStack_c38 = 0;
  if (*(int *)(param_1 + 0x1e8) == 0) {
    uVar5 = (uint)*(ushort *)(*(longlong *)(param_1 + 0xf0) + 0xb8);
  }
  else {
    uVar5 = *(ushort *)(*(longlong *)(param_1 + 0xf0) + 0xba) - 6;
  }
  uStack_62c = uVar5;
  pbStack_1f0 = param_2;
  if (param_3 != 0) {
    uStack_868 = 0;
    uStack_864 = 0;
    iVar3 = func_0x(param_2,uVar5,&uStack_868,0,uVar8 & 0xffffffff00000000,
                            uVar9 & 0xffffffffffff0000,param_2 + param_3,3,&uStack_c48);
    if (iVar3 == 0) {
      uStack_618 = 1;
      bVar1 = *param_2;
      bVar2 = bVar1 & 1;
      uStack_9b8 = (ushort)bVar2;
      uStack_c48 = (ushort)bVar2;
      puStack_488 = auStack_c46;
      pbStack_c40 = param_2;
      uStack_9b4 = uStack_9b8;
      if (bVar2 == 0) {
        uStack_c44 = 0;
        uStack_c22 = 0;
        uStack_c20 = 0;
        uStack_b68 = uVar5;
        puStack_1e8 = puStack_488;
        pbStack_1e0 = param_2;
                    /* WARNING: Could not emulate address calculation at 0x001001df */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(bVar1 & 0xe) * 4 + 0x10737c) - 0x1103350))()
        ;
        return;
      }
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(bVar1 & 0x1c) + 0x1073c8) * 4 +
                             0x1073b8) - 0x1103350);
                    /* WARNING: Could not emulate address calculation at 0x0010029c */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
  }
  func_0x(auStack_1d8);
  lVar4 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar6 = *(longlong *)(lVar4 + 0x100);
  if (lVar6 == 0) {
    (*_DAT_)();
    lVar6 = *(longlong *)(lVar4 + 0x100);
  }
  if (*(int *)(lVar6 + 0x22c) != 0) {
    (*_DAT_)();
  }
  *(uint *)(lVar7 + 0x268) = *(uint *)(lVar7 + 0x268) & 0xffffffbf;
  func_0x(uStack_48 ^ (ulonglong)&uStack_c48);
  return;
}

