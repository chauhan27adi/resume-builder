
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined2 param_1,longlong param_2,undefined8 *param_3,undefined8 *param_4,
                 undefined8 param_5,undefined4 param_6,int param_7,uint param_8)

{
  undefined2 uVar1;
  short sVar2;
  uint uVar3;
  short sVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  ulonglong uVar8;
  undefined8 uVar9;
  longlong lVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  longlong lVar13;
  longlong lVar14;
  ulonglong uVar15;
  longlong unaff_GS_OFFSET;
  bool bVar16;
  undefined auStack_268 [32];
  undefined8 uStack_248;
  undefined8 uStack_240;
  uint uStack_238;
  undefined8 uStack_230;
  undefined4 uStack_228;
  undefined4 uStack_220;
  uint uStack_218;
  undefined4 uStack_210;
  undefined4 uStack_208;
  uint uStack_200;
  longlong lStack_1f8;
  short asStack_1f0 [2];
  short asStack_1ec [2];
  undefined8 uStack_1e8;
  undefined4 uStack_1e0;
  uint uStack_1dc;
  short sStack_1d8;
  undefined2 uStack_1d6;
  undefined8 uStack_1d0;
  undefined8 *puStack_1c0;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined8 uStack_1b0;
  undefined8 uStack_198;
  undefined4 uStack_190;
  undefined auStack_188 [16];
  undefined8 uStack_178;
  undefined2 uStack_170;
  undefined8 uStack_168;
  undefined2 uStack_160;
  int aiStack_158 [2];
  longlong lStack_150;
  undefined8 uStack_148;
  undefined2 uStack_140;
  undefined8 uStack_13e;
  undefined2 uStack_136;
  undefined uStack_134;
  ulonglong uStack_130;
  ulonglong uStack_128;
  ulonglong uStack_120;
  ulonglong uStack_118;
  ulonglong uStack_110;
  ulonglong uStack_108;
  ulonglong uStack_100;
  ulonglong uStack_f8;
  undefined8 uStack_f0;
  undefined8 uStack_e8;
  longlong lStack_d8;
  undefined2 uStack_d0;
  undefined8 uStack_c8;
  int iStack_c0;
  undefined auStack_b8 [16];
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  longlong lStack_78;
  uint uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  ulonglong uStack_58;
  
  uStack_e8 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_268;
  uStack_f0 = param_5;
  uVar12 = 0;
  uStack_1dc = 0;
  uStack_178 = 0;
  uStack_170 = 0;
  uStack_1e8 = 0;
  uStack_1e0 = 0;
  lStack_1f8 = param_2;
  uStack_1d6 = param_1;
  puStack_1c0 = param_3;
  uStack_1b0 = param_4;
  if (param_2 == 0) {
    uStack_248 = 0;
    (*_DAT_)(1,0x1c31a7c,0x1c0c288,0x84);
  }
  if (((byte)param_8 & 0x41) == 0x41) {
    uStack_198 = 0;
    asStack_1ec[0] = 0;
    asStack_1f0[0] = 0;
    uStack_190 = 1;
    auStack_188._0_8_ =
         *(longlong **)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
          0x90);
    auStack_188._8_8_ = 0;
    cVar5 = (**(code **)(*(longlong *)auStack_188._0_8_ + 0x1d0))();
    if (cVar5 == '\0') {
      uStack_228 = 0;
      uStack_230 = 0;
      uStack_238 = uStack_238 & 0xffffff00;
      uStack_240 = CONCAT44(uStack_240._4_4_,2);
      uStack_248 = CONCAT44(uStack_248._4_4_,1);
      (**(code **)(*(longlong *)auStack_188._0_8_ + 8))(auStack_188._0_8_,0x1a79f58,0x10);
      uStack_198 = CONCAT44(uStack_198._4_4_,2);
    }
    else {
      (**(code **)(*(longlong *)auStack_188._0_8_ + 0xe8))(auStack_188._0_8_,1,1);
      uStack_190 = 1;
      uStack_198 = CONCAT44(uStack_198._4_4_,4);
    }
    iVar6 = func_0x(*(undefined2 *)(lStack_1f8 + 0x28),0x1a79f20);
    if (iVar6 == 0) {
      func_0x(0x4977,0x10,1,0x1a79f20);
    }
    else {
      uStack_c8 = (**(code **)(*(longlong *)auStack_188._0_8_ + 0x1b0))();
      uStack_d0 = *(undefined2 *)(lStack_1f8 + 0x28);
      lStack_d8 = 0;
      auStack_b8 = ZEXT816(0);
      auStack_a8 = ZEXT816(0);
      auStack_98 = ZEXT816(0);
      auStack_88 = ZEXT816(0);
      lStack_78 = 0;
      uStack_70 = 0;
      uStack_68 = 0;
      uStack_60 = 0;
      iStack_c0 = iVar6;
      iVar6 = func_0x(&lStack_d8,3,1);
      if (iVar6 == 0) {
        func_0x(0x49aa,0x10,4,0x1a79f20);
      }
      else {
        uStack_240 = lStack_d8;
        uVar8 = uVar12;
        lVar13 = uStack_240;
        do {
          uStack_240 = lVar13;
          uStack_248 = uStack_68;
          iVar6 = (**(code **)(*(longlong *)auStack_b8._8_8_ + 0x18))(auStack_b8._8_8_,0,1);
          if (iVar6 != 0) goto LAB_;
          uStack_1b8 = 0;
          uVar11 = uVar12;
          if (lStack_d8 == 0) {
LAB_:
            lVar13 = lStack_d8;
            if (uVar8 < 3) {
              func_0x(asStack_1ec,uVar11,uVar8);
            }
            else {
              asStack_1ec[0] = 0;
            }
          }
          else {
            uVar7 = func_0x(&lStack_d8,0x18188c0,&uStack_1b8);
            lVar13 = lStack_d8;
            uVar8 = (ulonglong)uVar7;
            if ((ulonglong)uVar7 == *(ulonglong *)((ulonglong)(uVar7 - 1) * 0x58 + lStack_78)) {
LAB_:
              if (uVar7 <= uStack_70) {
                lVar13 = (ulonglong)(uVar7 - 1) * 0x58 + lStack_78;
                uVar8 = *(ulonglong *)(lStack_d8 + *(longlong *)(lVar13 + 0x10));
                uVar11 = *(longlong *)(lVar13 + 8) + lStack_d8;
                goto LAB_;
              }
            }
            else {
              uVar7 = 1;
              if (uStack_70 != 0) {
                do {
                  if (uVar8 == *(ulonglong *)((ulonglong)(uVar7 - 1) * 0x58 + lStack_78))
                  goto LAB_;
                  uVar7 = uVar7 + 1;
                } while (uVar7 <= uStack_70);
                func_0x(asStack_1ec,0,0);
                uVar8 = uVar12;
                goto LAB_;
              }
            }
            func_0x(asStack_1ec,0,0);
            uVar8 = uVar12;
          }
LAB_:
          uStack_1b4 = 0;
          uVar11 = uVar12;
          if (lVar13 == 0) {
            lVar13 = 0;
LAB_:
            if (uVar8 < 3) goto LAB_;
            asStack_1f0[0] = 0;
          }
          else {
            uVar7 = func_0x(&lStack_d8,0x1a79f40,&uStack_1b4);
            uVar15 = (ulonglong)uVar7;
            lVar13 = lStack_d8;
            if (uVar15 == *(ulonglong *)((ulonglong)(uVar7 - 1) * 0x58 + lStack_78)) {
LAB_:
              uVar8 = uVar12;
              if (uVar7 <= uStack_70) {
                lVar10 = (ulonglong)(uVar7 - 1) * 0x58 + lStack_78;
                uVar8 = *(ulonglong *)(lStack_d8 + *(longlong *)(lVar10 + 0x10));
                uVar11 = *(longlong *)(lVar10 + 8) + lStack_d8;
                goto LAB_;
              }
            }
            else {
              uVar7 = 1;
              uVar8 = uVar12;
              if (uStack_70 != 0) {
                do {
                  if (uVar15 == *(ulonglong *)((ulonglong)(uVar7 - 1) * 0x58 + lStack_78))
                  goto LAB_;
                  uVar7 = uVar7 + 1;
                } while (uVar7 <= uStack_70);
              }
            }
LAB_:
            func_0x(asStack_1f0,uVar11,uVar8);
          }
        } while ((asStack_1ec[0] != 1) || (asStack_1f0[0] != 0));
        uStack_1dc = 1;
      }
LAB_:
      func_0x(&lStack_d8);
    }
    func_0x(&uStack_198);
    if ((int)uStack_198 != 0) {
      func_0x(&uStack_198);
    }
  }
  lVar13 = lStack_1f8;
  uVar8 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
  if (*(int *)(lStack_1f8 + 0x1500) == 0) {
    LOCK();
    bVar16 = *(ulonglong *)(lStack_1f8 + 0x1500) == 0;
    if (bVar16) {
      *(ulonglong *)(lStack_1f8 + 0x1500) = uVar8;
    }
    UNLOCK();
    if (!bVar16) goto LAB_;
  }
  else {
LAB_:
    lVar10 = 0;
    if (((byte)*_DAT_ & 0x84) == 0x84) {
      lVar14 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      if ((lVar14 != 0) && (*(longlong *)(lVar14 + 0x110) == lVar14)) {
        lVar10 = *(longlong *)(lVar14 + 0x100);
      }
      if ((lVar10 != 0) && (uVar12 = _DAT_, *_DAT_ != 0)) {
        (*_DAT_)(&uStack_130);
        uVar12 = uStack_130;
      }
    }
    if (*(char *)(_DAT_ + 199) < '\0') {
      func_0x(lVar13 + 0x1500,lVar10,uVar8);
    }
    else {
      func_0x(lVar13 + 0x1500,uVar8);
    }
    if (lVar10 != 0) {
      uVar8 = _DAT_;
      if (*_DAT_ != 0) {
        (*_DAT_)(&uStack_128);
        uVar8 = uStack_128;
      }
      lVar13 = uVar8 - uVar12;
      if (uVar8 < uVar12) {
        lVar13 = 0;
      }
      *(longlong *)(lVar10 + 0xc78) = *(longlong *)(lVar10 + 0xc78) + lVar13;
    }
  }
  iVar6 = func_0x(lStack_1f8,param_3);
  if (iVar6 != 0) goto LAB_;
  uStack_1d0 = *(undefined8 *)(lStack_1f8 + 0x9c8);
  sStack_1d8 = *(short *)(lStack_1f8 + 0x9d0);
  if ((DAT_ & 0x10) != 0) {
    uStack_200 = (uint)*(ushort *)(lStack_1f8 + 0x9dc);
    uStack_208 = *(undefined4 *)(lStack_1f8 + 0x9d8);
    uStack_210 = *(undefined4 *)(lStack_1f8 + 0x9d4);
    uStack_218 = (uint)*(ushort *)(lStack_1f8 + 0x9d0);
    uStack_220 = *(undefined4 *)(lStack_1f8 + 0x9cc);
    uStack_228 = *(undefined4 *)(lStack_1f8 + 0x9c8);
    uStack_238 = *(undefined4 *)(lStack_1f8 + 0x9c0);
    uStack_230._0_4_ = (uint)*(ushort *)(lStack_1f8 + 0x9c4);
    uStack_240._0_4_ = *(undefined4 *)(lStack_1f8 + 0x9bc);
    uStack_248._0_4_ = (uint)*(ushort *)(lStack_1f8 + 0x9b8);
    func_0x(0x1a79df0,*(undefined2 *)(lStack_1f8 + 0x28),*(undefined4 *)(lStack_1f8 + 0x9b0)
                    ,*(undefined4 *)(lStack_1f8 + 0x9b4));
    param_4 = uStack_1b0;
    uStack_230._0_4_ = (uint)*(ushort *)(uStack_1b0 + 1);
    uStack_238 = *(uint *)((longlong)uStack_1b0 + 4);
    uStack_240._0_4_ = *(uint *)uStack_1b0;
    uStack_248._0_4_ = (uint)*(ushort *)(puStack_1c0 + 1);
    func_0x(0x1a79ea0,*(undefined2 *)(lStack_1f8 + 0x28),*(undefined4 *)puStack_1c0,
                    *(undefined4 *)((longlong)puStack_1c0 + 4));
    uStack_230 = CONCAT44(uStack_230._4_4_,(uint)*(ushort *)(lStack_1f8 + 0xa00));
    uStack_238 = *(uint *)(lStack_1f8 + 0x9fc);
    uStack_240 = CONCAT44(uStack_240._4_4_,*(undefined4 *)(lStack_1f8 + 0x9f8));
    uStack_248 = CONCAT44(uStack_248._4_4_,(uint)*(ushort *)(lStack_1f8 + 0x9f4));
    func_0x(0x1a79cf0,*(undefined2 *)(lStack_1f8 + 0x28),*(undefined4 *)(lStack_1f8 + 0x9ec)
                    ,*(undefined4 *)(lStack_1f8 + 0x9f0));
  }
  sVar4 = sStack_1d8;
  lVar13 = lStack_1f8;
  if (((((int)*(uint *)param_4 < 1) || ((int)*(uint *)((longlong)param_4 + 4) < 1)) ||
      (*(short *)(param_4 + 1) == 0)) ||
     ((((0 < *(int *)(lStack_1f8 + 0x9ec) && (0 < *(int *)(lStack_1f8 + 0x9f0))) &&
       (*(short *)(lStack_1f8 + 0x9f4) != 0)) &&
      ((*(uint *)(lStack_1f8 + 0x9ec) < *(uint *)param_4 ||
       ((*(uint *)(lStack_1f8 + 0x9ec) == *(uint *)param_4 &&
        ((*(uint *)(lStack_1f8 + 0x9f0) < *(uint *)((longlong)param_4 + 4) ||
         ((*(uint *)(lStack_1f8 + 0x9f0) == *(uint *)((longlong)param_4 + 4) &&
          (*(ushort *)(lStack_1f8 + 0x9f4) < *(ushort *)(param_4 + 1))))))))))))) {
    *(undefined8 *)(lStack_1f8 + 0x9c8) = *(undefined8 *)(lStack_1f8 + 0x9ec);
    *(undefined2 *)(lStack_1f8 + 0x9d0) = *(undefined2 *)(lStack_1f8 + 0x9f4);
    uVar1 = *(undefined2 *)(lStack_1f8 + 0x9f4);
    uVar3 = *(uint *)(lStack_1f8 + 0x9f0);
    uVar7 = *(uint *)(lStack_1f8 + 0x9ec);
  }
  else {
    uVar1 = *(undefined2 *)(param_4 + 1);
    *(undefined8 *)(lStack_1f8 + 0x9c8) = *param_4;
    *(undefined2 *)(lStack_1f8 + 0x9d0) = uVar1;
    uVar1 = *(undefined2 *)(param_4 + 1);
    uVar3 = *(uint *)((longlong)param_4 + 4);
    uVar7 = *(uint *)param_4;
  }
  uStack_1e8 = CONCAT44(uVar3,uVar7);
  uStack_1e0 = CONCAT22(uStack_1e0._2_2_,uVar1);
  uStack_1b0 = *(undefined8 **)(lStack_1f8 + 0x9c8);
  sVar2 = *(short *)(lStack_1f8 + 0x9d0);
  if ((*_DAT_ != '\0') && (iVar6 = (*_DAT_)(), iVar6 == (iVar6 / 5) * 5)) {
    func_0x();
  }
  lVar10 = lStack_1f8;
  uVar12 = 0;
  *(undefined8 *)(lVar13 + 0x1500) = 0;
  if (DAT_ != '\0') {
    uVar8 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    if (*(int *)(lStack_1f8 + 0x1500) == 0) {
      LOCK();
      bVar16 = *(ulonglong *)(lStack_1f8 + 0x1500) == 0;
      if (bVar16) {
        *(ulonglong *)(lStack_1f8 + 0x1500) = uVar8;
      }
      UNLOCK();
      if (!bVar16) goto LAB_;
    }
    else {
LAB_:
      uVar11 = uVar12;
      if (((byte)*_DAT_ & 0x84) == 0x84) {
        lVar13 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        if ((lVar13 != 0) && (*(longlong *)(lVar13 + 0x110) == lVar13)) {
          uVar12 = *(ulonglong *)(lVar13 + 0x100);
        }
        uVar11 = 0;
        if ((uVar12 != 0) && (uVar11 = _DAT_, *_DAT_ != 0)) {
          (*_DAT_)(&uStack_120);
          uVar11 = uStack_120;
        }
      }
      if (*(char *)(_DAT_ + 199) < '\0') {
        func_0x(lVar10 + 0x1500,uVar12,uVar8);
      }
      else {
        func_0x(lVar10 + 0x1500,uVar8);
      }
      if (uVar12 != 0) {
        uVar8 = _DAT_;
        if (*_DAT_ != 0) {
          (*_DAT_)(&uStack_118);
          uVar8 = uStack_118;
        }
        lVar13 = uVar8 - uVar11;
        if (uVar8 < uVar11) {
          lVar13 = 0;
        }
        *(longlong *)(uVar12 + 0xc78) = *(longlong *)(uVar12 + 0xc78) + lVar13;
      }
    }
    lVar10 = lStack_1f8;
    uVar12 = 0;
    lVar13 = *(longlong *)(lStack_1f8 + 0x1210);
    if ((*_DAT_ != '\0') && (iVar6 = (*_DAT_)(), iVar6 == (iVar6 / 5) * 5)) {
      func_0x();
    }
    *(undefined8 *)(lVar10 + 0x1500) = 0;
    if ((((sVar4 == 0) && ((int)uStack_1d0 == 0)) && (uStack_1d0._4_4_ == 0)) &&
       (((sVar2 != 0 || ((int)uStack_1b0 != 0)) || (uStack_1b0._4_4_ != 0)))) {
      aiStack_158[0] = 0;
      uStack_148 = 0;
      uStack_140 = 0;
      uStack_13e = 0;
      uStack_136 = 0;
      uStack_134 = 0;
      uStack_168 = 0;
      uStack_160 = 0;
      lStack_150 = lVar13;
      func_0x(aiStack_158,&uStack_168,6);
      lVar10 = *(longlong *)(lVar13 + 0x6b0);
      uVar8 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      if (*(int *)(lVar10 + 0x1500) == 0) {
        LOCK();
        bVar16 = *(ulonglong *)(lVar10 + 0x1500) == 0;
        if (bVar16) {
          *(ulonglong *)(lVar10 + 0x1500) = uVar8;
        }
        UNLOCK();
        if (!bVar16) goto LAB_;
      }
      else {
LAB_:
        uVar11 = uVar12;
        if (((byte)*_DAT_ & 0x84) == 0x84) {
          lVar14 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          if ((lVar14 != 0) && (*(longlong *)(lVar14 + 0x110) == lVar14)) {
            uVar11 = *(ulonglong *)(lVar14 + 0x100);
          }
          if ((uVar11 != 0) && (uVar12 = _DAT_, *_DAT_ != 0)) {
            (*_DAT_)(&uStack_110);
            uVar12 = uStack_110;
          }
        }
        if (*(char *)(_DAT_ + 199) < '\0') {
          func_0x(lVar10 + 0x1500,uVar11,uVar8);
        }
        else {
          func_0x(lVar10 + 0x1500,uVar8);
        }
        if (uVar11 != 0) {
          uVar8 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&uStack_108);
            uVar8 = uStack_108;
          }
          lVar10 = uVar8 - uVar12;
          if (uVar8 < uVar12) {
            lVar10 = 0;
          }
          *(longlong *)(uVar11 + 0xc78) = *(longlong *)(uVar11 + 0xc78) + lVar10;
        }
      }
      *(undefined8 *)(lVar13 + 0x878) = *(undefined8 *)(lStack_1f8 + 0x9c8);
      *(undefined2 *)(lVar13 + 0x880) = *(undefined2 *)(lStack_1f8 + 0x9d0);
      lVar13 = *(longlong *)(lVar13 + 0x6b0);
      if ((*_DAT_ != '\0') && (iVar6 = (*_DAT_)(), iVar6 == (iVar6 / 5) * 5)) {
        func_0x();
      }
      *(undefined8 *)(lVar13 + 0x1500) = 0;
      if (aiStack_158[0] != 0) {
        func_0x(aiStack_158);
      }
    }
  }
  lVar13 = lStack_1f8;
  uVar12 = 0;
  uVar8 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
  if (*(int *)(lStack_1f8 + 0x1500) == 0) {
    LOCK();
    bVar16 = *(ulonglong *)(lStack_1f8 + 0x1500) == 0;
    if (bVar16) {
      *(ulonglong *)(lStack_1f8 + 0x1500) = uVar8;
    }
    UNLOCK();
    if (!bVar16) goto LAB_;
  }
  else {
LAB_:
    uVar11 = uVar12;
    if (((byte)*_DAT_ & 0x84) == 0x84) {
      lVar10 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      if ((lVar10 != 0) && (*(longlong *)(lVar10 + 0x110) == lVar10)) {
        uVar11 = *(ulonglong *)(lVar10 + 0x100);
      }
      if ((uVar11 != 0) && (uVar12 = _DAT_, *_DAT_ != 0)) {
        (*_DAT_)(&uStack_100);
        uVar12 = uStack_100;
      }
    }
    if (*(char *)(_DAT_ + 199) < '\0') {
      func_0x(lVar13 + 0x1500,uVar11,uVar8);
    }
    else {
      func_0x(lVar13 + 0x1500,uVar8);
    }
    if (uVar11 != 0) {
      uVar8 = _DAT_;
      if (*_DAT_ != 0) {
        (*_DAT_)(&uStack_f8);
        uVar8 = uStack_f8;
      }
      lVar13 = uVar8 - uVar12;
      if (uVar8 < uVar12) {
        lVar13 = 0;
      }
      *(longlong *)(uVar11 + 0xc78) = *(longlong *)(uVar11 + 0xc78) + lVar13;
    }
  }
  if ((param_8 & 1) == 0) {
    if ((param_8 & 0x40) != 0) goto LAB_;
  }
  else if ((uStack_1dc == 0) && ((param_8 & 0x40) != 0)) {
LAB_:
    uStack_1d0 = 0;
    *(undefined8 *)(lStack_1f8 + 0x9b0) = 0;
    *(undefined2 *)(lStack_1f8 + 0x9b8) = 0;
  }
  else {
    uVar1 = *(undefined2 *)(puStack_1c0 + 1);
    *(undefined8 *)(lStack_1f8 + 0x9b0) = *puStack_1c0;
    *(undefined2 *)(lStack_1f8 + 0x9b8) = uVar1;
  }
  if (param_7 != 0) {
    uStack_238 = uStack_1dc;
    uStack_240 = CONCAT44(uStack_240._4_4_,param_8);
    uStack_248 = CONCAT44(uStack_248._4_4_,param_6);
    func_0x(uStack_1d6,lStack_1f8,puStack_1c0,uStack_f0);
  }
LAB_:
  lVar13 = lStack_1f8;
  if ((*_DAT_ != '\0') && (iVar6 = (*_DAT_)(), iVar6 == (iVar6 / 5) * 5)) {
    func_0x();
  }
  *(undefined8 *)(lVar13 + 0x1500) = 0;
  if ((((((short)uStack_1e0 != 0) || ((int)uStack_1e8 != 0)) || (uStack_1e8._4_4_ != 0)) &&
      ((*(longlong *)(lStack_1f8 + 0x1210) != 0 &&
       (*(longlong *)(*(longlong *)(lStack_1f8 + 0x1210) + 0x6c8) != 0)))) &&
     (lVar13 = (**(code **)(**(longlong **)(*(longlong *)(lStack_1f8 + 0x1210) + 0x6c8) + 0x290))(),
     lVar13 != 0)) {
    uVar9 = (**(code **)(**(longlong **)(*(longlong *)(lStack_1f8 + 0x1210) + 0x6c8) + 0x290))();
    func_0x(uVar9,6,&uStack_1e8);
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_268);
  return;
}

