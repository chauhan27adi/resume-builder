
/* WARNING: Removing unreachable block (ram,0x001009ea) */
/* WARNING: Removing unreachable block (ram,0x001009f4) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ulonglong param_1,short *param_2,undefined4 *param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined (*param_6) [16],undefined8 *param_7,
                 undefined8 *param_8)

{
  ushort *puVar1;
  byte *pbVar2;
  longlong *plVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined (*pauVar7) [16];
  undefined8 *puVar8;
  byte bVar9;
  ushort uVar10;
  ulonglong *puVar11;
  undefined4 *puVar12;
  longlong lVar13;
  ushort uVar14;
  uint uVar15;
  ulonglong uVar16;
  ushort *puVar17;
  short *psVar18;
  uint uVar19;
  undefined8 *puVar20;
  short sVar21;
  int iVar22;
  undefined8 *puVar23;
  int iVar24;
  int iVar25;
  longlong unaff_GS_OFFSET;
  undefined8 uStackX_8;
  short *psStackX_10;
  uint uStackX_18;
  undefined4 *puStackX_20;
  undefined8 uStack_88;
  undefined2 uStack_80;
  undefined8 uStack_78;
  undefined2 uStack_70;
  undefined8 uStack_68;
  undefined2 uStack_60;
  int iStack_58;
  ushort uStack_54;
  ushort uStack_52;
  int *piStack_50;
  
  pauVar7 = param_6;
  puVar1 = (ushort *)(param_2 + 1);
  puVar23 = (undefined8 *)0x0;
  iVar25 = 0;
  *param_5 = 0;
  *param_4 = 0;
  iVar24 = 0;
  *param_3 = 0;
  uVar6 = uRam000000000113b144;
  uVar5 = uRam000000000113b140;
  uVar4 = uRam000000000113b13c;
  *(undefined4 *)*param_6 = _DAT_;
  *(undefined4 *)(*param_6 + 4) = uVar4;
  *(undefined4 *)(*param_6 + 8) = uVar5;
  *(undefined4 *)(*param_6 + 0xc) = uVar6;
  *param_7 = 0;
  *(undefined2 *)(param_7 + 1) = 0;
  uStack_54 = 0x18;
  uStack_52 = uStack_52 & 0xffe0;
  uStackX_8 = param_1 & 0xffffffff00000000;
  iStack_58 = -0x18;
  piStack_50 = (undefined4 *)0x0;
  psStackX_10 = param_2;
  puStackX_20 = param_4;
  if (*param_2 == 0) {
    pbVar2 = *(byte **)(param_2 + 4);
    puVar20 = puVar23;
    if ((*pbVar2 & 0x10) == 0) {
      uVar15 = 1 << (*pbVar2 & 0xe) & 0x1105;
LAB_:
      if (uVar15 == 0) {
        if (*(int *)(param_2 + 2) == 0) {
          uVar15 = *(uint *)(param_2 + 8);
          uVar16 = (ulonglong)uVar15;
          *(uint *)(param_2 + 10) = uVar15;
          *puVar1 = 0;
          bVar9 = *pbVar2;
          if ((bVar9 & 0x10) != 0) {
            uVar15 = uVar15 + 2 + (*(ushort *)(pbVar2 + uVar16) + 7 >> 3);
            uVar16 = (ulonglong)uVar15;
            *(uint *)(param_2 + 10) = uVar15;
            bVar9 = *pbVar2;
          }
          if ((bVar9 & 0x20) == 0) {
            *(int *)(param_2 + 2) = (int)uVar16;
            param_2[0xe] = 0;
            *(int *)(param_2 + 0xc) = (int)uVar16;
          }
          else {
            puVar17 = (ushort *)(pbVar2 + uVar16);
            uVar10 = *puVar17;
            param_2[0xe] = uVar10;
            if (uVar10 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar13 != 0)) &&
                 ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                  (*(char *)(lVar13 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x13b63c8,0x14d6098,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),3);
              uVar10 = param_2[0xe];
              uVar16 = (ulonglong)*(uint *)(param_2 + 10);
            }
            uVar15 = (int)uVar16 + (uVar10 + 1) * 2;
            *(uint *)(param_2 + 0xc) = uVar15;
            if (0x1f9e < uVar15) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar13 != 0 &&
                  ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                   (*(char *)(lVar13 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x13b63c8,0x14d6098,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar10 = param_2[0xe];
              uVar15 = *(uint *)(param_2 + 0xc);
            }
            uVar16 = (ulonglong)uVar10;
            uVar10 = puVar17[uVar16];
            *(uint *)(param_2 + 2) = uVar10 & 0x7fff;
            if ((uVar10 & 0x7fff) < uVar15) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar13 != 0)) &&
                 ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                  (*(char *)(lVar13 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x13b63c8,0x14d6098,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar16 = (ulonglong)(ushort)param_2[0xe];
            }
            if ((short)puVar17[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
              lVar13 = *(longlong *)(param_2 + 4);
              do {
                if ((int)uVar16 == 1) {
                  uVar15 = *(uint *)(param_2 + 0xc);
                  uVar19 = uVar15;
LAB_:
                  if ((*(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar13 + uVar16 * 2) &
                      0x7fff) < uVar15) goto LAB_;
                }
                else {
                  uVar19 = *(uint *)(param_2 + 0xc);
                  uVar15 = *(ushort *)
                            ((ulonglong)*(uint *)(param_2 + 10) + lVar13 + -2 + uVar16 * 2) & 0x7fff
                  ;
                  if (uVar19 <= uVar15) goto LAB_;
LAB_:
                  func_0x(lVar13,7);
                  uVar19 = *(uint *)(param_2 + 0xc);
                }
                if ((uVar15 < uVar19) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
                lVar13 = *(longlong *)(param_2 + 4);
                if (*(ushort *)(lVar13 + (ulonglong)uVar15) == 5) {
                  *puVar1 = *puVar1 | 2;
                  param_2[0xe] = param_2[0xe] + -1;
                  param_2[0x15] = (short)uVar15;
                  lVar13 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(param_2 + 4);
                  uVar10 = param_2[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar13 + 2) >> 0xe & 1) != 0) {
                    uVar10 = *(ushort *)(lVar13 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                  }
                  param_2[0x16] = uVar10;
                  param_2[0x16] = (uVar10 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar10;
                  goto LAB_;
                }
                if (*(ushort *)(lVar13 + (ulonglong)uVar15) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar10 = param_2[0xe] - 1;
                param_2[0xe] = uVar10;
                if (uVar10 == 0) goto LAB_;
                uVar16 = (ulonglong)uVar10;
              } while ((short)puVar17[(ulonglong)(uVar10 - 1) + 1] < 0);
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
            else {
LAB_:
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
          }
          if ((**(byte **)(param_2 + 4) & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0x13) = 0;
          }
          else {
            *(int *)(param_2 + 0x13) = (int)uVar16;
            *(int *)(param_2 + 2) = (int)uVar16 + 0xe;
            puVar11 = (ulonglong *)func_0x(puVar1);
            uVar14 = (ushort)(*puVar11 >> 0x30);
            uVar10 = uVar14;
            if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
              uVar10 = uVar14 & 0xdfff;
              if ((uVar14 >> 0xe & 1) != 0) {
                uVar10 = uVar14 | 0x2000;
              }
            }
            iVar22 = iVar24;
            if (uVar10 == 0xfffc) {
              iVar22 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar22;
            uVar16 = (ulonglong)*(uint *)(param_2 + 2);
          }
          iVar22 = (int)uVar16;
          if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
             (*(ulonglong *)(param_2 + 0xf) < uVar16 + *(longlong *)(param_2 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar13 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar13 != 0 &&
                 (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
                (*(char *)(lVar13 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x13b63c8,0x14d6098,0x877,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),0x12);
            iVar22 = *(int *)(param_2 + 2);
          }
          if (0x3f3b < iVar22 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar13 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar13 != 0 &&
                ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                 (*(char *)(lVar13 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x13b63c8,0x14d6098,0x87c,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),5);
          }
        }
LAB_:
        sVar21 = -(short)iStack_58;
        if ((uStack_52 & 0x10) != 0) {
          bVar9 = **(byte **)(param_2 + 4);
          if ((bVar9 & 0x10) == 0) {
            if ((1 << (bVar9 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar20 = (undefined8 *)(piStack_50 + 1);
              uStackX_8 = CONCAT44(uStackX_8._4_4_,*piStack_50);
              psVar18 = psStackX_10;
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_2 + 8) <= iStack_58) ||
                  (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) < uStack_54))
          goto LAB_;
        }
        puVar20 = *(undefined8 **)(param_2 + 4);
        lVar13 = (longlong)sVar21;
        if ((uint)(int)sVar21 <= (uint)(ushort)param_2[0xe]) {
          uVar15 = *(uint *)(param_2 + 10);
          if (sVar21 == 1) {
            uVar19 = *(uint *)(psStackX_10 + 0xc);
            uVar15 = *(ushort *)((longlong)puVar20 + lVar13 * 2 + (ulonglong)uVar15) & 0x7fff;
LAB_:
            if (uVar15 < uVar19) goto LAB_;
          }
          else {
            puVar17 = (ushort *)((longlong)puVar20 + lVar13 * 2 + (ulonglong)uVar15);
            uVar19 = *(ushort *)((longlong)puVar20 + lVar13 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
            puVar20 = *(undefined8 **)(param_2 + 4);
            uVar15 = *puVar17 & 0x7fff;
            if (*(uint *)(psStackX_10 + 0xc) <= uVar19) goto LAB_;
LAB_:
            func_0x(puVar20,7);
            puVar20 = *(undefined8 **)(param_2 + 4);
          }
          puVar20 = (undefined8 *)((longlong)puVar20 + (ulonglong)uVar19);
          uStackX_8 = CONCAT44(uStackX_8._4_4_,uVar15 - uVar19);
          psVar18 = psStackX_10;
          goto LAB_;
        }
      }
    }
    else {
      uVar15 = *(uint *)(param_2 + 8);
      if ((-0x18 < (int)uVar15) && (0x17 < *(ushort *)(pbVar2 + uVar15))) {
        uVar15 = (uint)(pbVar2[(ulonglong)uVar15 + 4] >> 7);
        goto LAB_;
      }
    }
    uStackX_8 = uStackX_8 & 0xffffffff00000000;
    psVar18 = psStackX_10;
  }
  else {
    param_5._0_4_ = 0;
    puVar20 = (undefined8 *)func_0x(puVar1,&iStack_58,param_3,&uStackX_8,&param_5);
    psVar18 = param_2;
    if ((((*param_2 != 0) && (plVar3 = *(longlong **)(param_2 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) && (((uStack_52 & 8) == 0 && (((uint)param_5 & 1) == 0)))) {
      if ((puVar20 == (undefined8 *)0x0) || (puVar20 == (undefined8 *)0x113ae04)) {
        uStackX_8 = uStackX_8 & 0xffffffff00000000;
        puVar20 = (undefined8 *)0x0;
      }
      else {
        puVar20 = (undefined8 *)
                  func_0x
                            (plVar3,&iStack_58,puVar20,uStackX_8 & 0xffffffff,0,0,&uStackX_8,
                             (uint)param_5);
      }
    }
  }
LAB_:
  if ((puVar20 == (undefined8 *)0x0) || ((int)uStackX_8 != 0x10)) {
    uStack_88 = *param_8;
    uStack_80 = *(undefined2 *)(param_8 + 1);
    (*_DAT_)(0x5a,0xf,0x17,1,&uStack_88);
    if (puVar20 != (undefined8 *)0x0) goto LAB_;
    *pauVar7 = ZEXT816(0);
    puVar12 = (undefined4 *)(*_DAT_)();
    *puVar12 = 0x16;
    (*_DAT_)();
  }
  else {
LAB_:
    uVar4 = *(undefined4 *)((longlong)puVar20 + 4);
    uVar5 = *(undefined4 *)(puVar20 + 1);
    uVar6 = *(undefined4 *)((longlong)puVar20 + 0xc);
    *(undefined4 *)*pauVar7 = *(undefined4 *)puVar20;
    *(undefined4 *)(*pauVar7 + 4) = uVar4;
    *(undefined4 *)(*pauVar7 + 8) = uVar5;
    *(undefined4 *)(*pauVar7 + 0xc) = uVar6;
  }
  iStack_58 = -0x14;
  uStack_52 = uStack_52 & 0xffe0;
  uStack_54 = 0x14;
  piStack_50 = (undefined4 *)0x0;
  if (*psVar18 == 0) {
    pbVar2 = *(byte **)(param_2 + 4);
    puVar20 = puVar23;
    if ((*pbVar2 & 0x10) == 0) {
      if ((1 << (*pbVar2 & 0xe) & 0x1105U) == 0) {
LAB_:
        if (*(int *)(param_2 + 2) == 0) {
          uVar15 = *(uint *)(param_2 + 8);
          uVar16 = (ulonglong)uVar15;
          *(uint *)(param_2 + 10) = uVar15;
          *puVar1 = 0;
          bVar9 = *pbVar2;
          if ((bVar9 & 0x10) != 0) {
            uVar15 = uVar15 + 2 + (*(ushort *)(pbVar2 + uVar16) + 7 >> 3);
            uVar16 = (ulonglong)uVar15;
            *(uint *)(param_2 + 10) = uVar15;
            bVar9 = *pbVar2;
          }
          if ((bVar9 & 0x20) == 0) {
            *(int *)(param_2 + 2) = (int)uVar16;
            param_2[0xe] = 0;
            *(int *)(param_2 + 0xc) = (int)uVar16;
          }
          else {
            puVar17 = (ushort *)(pbVar2 + uVar16);
            uVar10 = *puVar17;
            param_2[0xe] = uVar10;
            if (uVar10 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar13 != 0)) &&
                 ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                  (*(char *)(lVar13 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x13b63c8,0x14d6098,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),3);
              uVar10 = param_2[0xe];
              uVar16 = (ulonglong)*(uint *)(param_2 + 10);
            }
            uVar15 = (int)uVar16 + (uVar10 + 1) * 2;
            *(uint *)(param_2 + 0xc) = uVar15;
            if (0x1f9e < uVar15) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar13 != 0 &&
                  ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                   (*(char *)(lVar13 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x13b63c8,0x14d6098,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar10 = param_2[0xe];
              uVar15 = *(uint *)(param_2 + 0xc);
            }
            uVar16 = (ulonglong)uVar10;
            uVar10 = puVar17[uVar16];
            *(uint *)(param_2 + 2) = uVar10 & 0x7fff;
            if ((uVar10 & 0x7fff) < uVar15) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar13 != 0)) &&
                 ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                  (*(char *)(lVar13 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x13b63c8,0x14d6098,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar16 = (ulonglong)(ushort)param_2[0xe];
            }
            if ((short)puVar17[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
              lVar13 = *(longlong *)(param_2 + 4);
              do {
                if ((int)uVar16 == 1) {
                  uVar15 = *(uint *)(param_2 + 0xc);
                  uVar19 = uVar15;
LAB_:
                  if ((*(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar13 + uVar16 * 2) &
                      0x7fff) < uVar15) goto LAB_;
                }
                else {
                  uVar19 = *(uint *)(param_2 + 0xc);
                  uVar15 = *(ushort *)
                            ((ulonglong)*(uint *)(param_2 + 10) + lVar13 + -2 + uVar16 * 2) & 0x7fff
                  ;
                  if (uVar19 <= uVar15) goto LAB_;
LAB_:
                  func_0x(lVar13,7);
                  uVar19 = *(uint *)(param_2 + 0xc);
                }
                if ((uVar15 < uVar19) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
                lVar13 = *(longlong *)(param_2 + 4);
                if (*(ushort *)(lVar13 + (ulonglong)uVar15) == 5) {
                  *puVar1 = *puVar1 | 2;
                  param_2[0xe] = param_2[0xe] + -1;
                  param_2[0x15] = (short)uVar15;
                  lVar13 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(param_2 + 4);
                  uVar10 = param_2[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar13 + 2) >> 0xe & 1) != 0) {
                    uVar10 = *(ushort *)(lVar13 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                  }
                  param_2[0x16] = uVar10;
                  param_2[0x16] = (uVar10 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar10;
                  goto LAB_;
                }
                if (*(ushort *)(lVar13 + (ulonglong)uVar15) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar10 = param_2[0xe] - 1;
                param_2[0xe] = uVar10;
                if (uVar10 == 0) goto LAB_;
                uVar16 = (ulonglong)uVar10;
              } while ((short)puVar17[(ulonglong)(uVar10 - 1) + 1] < 0);
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
            else {
LAB_:
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
          }
          if ((**(byte **)(param_2 + 4) & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0x13) = 0;
          }
          else {
            *(int *)(param_2 + 0x13) = (int)uVar16;
            *(int *)(param_2 + 2) = (int)uVar16 + 0xe;
            puVar11 = (ulonglong *)func_0x(puVar1);
            uVar14 = (ushort)(*puVar11 >> 0x30);
            uVar10 = uVar14;
            if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
              uVar10 = uVar14 & 0xdfff;
              if ((uVar14 >> 0xe & 1) != 0) {
                uVar10 = uVar14 | 0x2000;
              }
            }
            iVar22 = iVar24;
            if (uVar10 == 0xfffc) {
              iVar22 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar22;
            uVar16 = (ulonglong)*(uint *)(param_2 + 2);
          }
          iVar22 = (int)uVar16;
          if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
             (*(ulonglong *)(param_2 + 0xf) < uVar16 + *(longlong *)(param_2 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar13 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar13 != 0 &&
                 (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
                (*(char *)(lVar13 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x13b63c8,0x14d6098,0x877,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),0x12);
            iVar22 = *(int *)(param_2 + 2);
          }
          if (0x3f3b < iVar22 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar13 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar13 != 0 &&
                ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                 (*(char *)(lVar13 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x13b63c8,0x14d6098,0x87c,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),5);
          }
        }
LAB_:
        sVar21 = -(short)iStack_58;
        if ((uStack_52 & 0x10) != 0) {
          bVar9 = **(byte **)(param_2 + 4);
          if ((bVar9 & 0x10) == 0) {
            if ((1 << (bVar9 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar20 = (undefined8 *)(piStack_50 + 1);
              uStackX_8 = CONCAT44(uStackX_8._4_4_,*piStack_50);
              psVar18 = psStackX_10;
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_2 + 8) <= iStack_58) ||
                  (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) < uStack_54))
          goto LAB_;
        }
        puVar20 = *(undefined8 **)(param_2 + 4);
        lVar13 = (longlong)sVar21;
        if ((uint)(int)sVar21 <= (uint)(ushort)param_2[0xe]) {
          uVar15 = *(uint *)(param_2 + 10);
          if (sVar21 == 1) {
            uVar19 = *(uint *)(psStackX_10 + 0xc);
            uVar15 = *(ushort *)((longlong)puVar20 + lVar13 * 2 + (ulonglong)uVar15) & 0x7fff;
LAB_:
            if (uVar15 < uVar19) goto LAB_;
          }
          else {
            puVar17 = (ushort *)((longlong)puVar20 + lVar13 * 2 + (ulonglong)uVar15);
            uVar19 = *(ushort *)((longlong)puVar20 + lVar13 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
            puVar20 = *(undefined8 **)(param_2 + 4);
            uVar15 = *puVar17 & 0x7fff;
            if (*(uint *)(psStackX_10 + 0xc) <= uVar19) goto LAB_;
LAB_:
            func_0x(puVar20,7);
            puVar20 = *(undefined8 **)(param_2 + 4);
          }
          puVar20 = (undefined8 *)((longlong)puVar20 + (ulonglong)uVar19);
          uStackX_8 = CONCAT44(uStackX_8._4_4_,uVar15 - uVar19);
          psVar18 = psStackX_10;
          goto LAB_;
        }
      }
    }
    else {
      uVar15 = *(uint *)(param_2 + 8);
      if (((-0x14 < (int)uVar15) && (0x13 < *(ushort *)(pbVar2 + uVar15))) &&
         ((pbVar2[(ulonglong)uVar15 + 4] >> 3 & 1) == 0)) goto LAB_;
    }
    uStackX_8 = uStackX_8 & 0xffffffff00000000;
    psVar18 = psStackX_10;
  }
  else {
    param_6._0_4_ = 0;
    puVar20 = (undefined8 *)func_0x(puVar1,&iStack_58);
    if ((((*psVar18 != 0) && (plVar3 = *(longlong **)(psVar18 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) && (((uStack_52 & 8) == 0 && (((uint)param_6 & 1) == 0)))) {
      if ((puVar20 == (undefined8 *)0x0) || (puVar20 == (undefined8 *)0x113ae04)) {
        uStackX_8 = uStackX_8 & 0xffffffff00000000;
        puVar20 = (undefined8 *)0x0;
      }
      else {
        puVar20 = (undefined8 *)
                  func_0x
                            (plVar3,&iStack_58,puVar20,uStackX_8 & 0xffffffff,0,0,&uStackX_8,
                             (uint)param_6);
      }
    }
  }
LAB_:
  puVar8 = param_8;
  if ((puVar20 == (undefined8 *)0x0) || ((int)uStackX_8 != 10)) {
    uStack_70 = *(undefined2 *)(param_8 + 1);
    uStack_78 = *param_8;
    (*_DAT_)(0x5a,0xf,0x17,2,&uStack_78);
    if (puVar20 != (undefined8 *)0x0) goto LAB_;
    *param_7 = 0;
    *(undefined2 *)(param_7 + 1) = 0;
    puVar12 = (undefined4 *)(*_DAT_)();
    *puVar12 = 0x16;
    (*_DAT_)();
  }
  else {
LAB_:
    *param_7 = *puVar20;
    *(undefined2 *)(param_7 + 1) = *(undefined2 *)(puVar20 + 1);
  }
  uStack_52 = uStack_52 & 0xffe0;
  iStack_58 = -6;
  uStack_54 = 6;
  piStack_50 = (int *)0x0;
  if (*psVar18 == 0) {
    pbVar2 = *(byte **)(param_2 + 4);
    if ((*pbVar2 & 0x10) == 0) {
      iVar22 = 1;
      if ((1 << (*pbVar2 & 0xe) & 0x1105U) == 0) {
LAB_:
        if (*(int *)(param_2 + 2) == 0) {
          uVar15 = *(uint *)(param_2 + 8);
          uVar16 = (ulonglong)uVar15;
          *(uint *)(param_2 + 10) = uVar15;
          *puVar1 = 0;
          bVar9 = *pbVar2;
          if ((bVar9 & 0x10) != 0) {
            uVar15 = uVar15 + 2 + (*(ushort *)(pbVar2 + uVar16) + 7 >> 3);
            uVar16 = (ulonglong)uVar15;
            *(uint *)(param_2 + 10) = uVar15;
            bVar9 = *pbVar2;
          }
          if ((bVar9 & 0x20) == 0) {
            *(int *)(param_2 + 2) = (int)uVar16;
            param_2[0xe] = 0;
            *(int *)(param_2 + 0xc) = (int)uVar16;
          }
          else {
            puVar17 = (ushort *)(pbVar2 + uVar16);
            uVar10 = *puVar17;
            param_2[0xe] = uVar10;
            if (uVar10 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar13 != 0)) &&
                 ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                  (*(char *)(lVar13 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(iVar22,0x13b63c8,0x14d6098,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),3);
              uVar10 = param_2[0xe];
              uVar16 = (ulonglong)*(uint *)(param_2 + 10);
            }
            uVar15 = (int)uVar16 + (uVar10 + 1) * 2;
            *(uint *)(param_2 + 0xc) = uVar15;
            if (0x1f9e < uVar15) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar13 != 0 &&
                  ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                   (*(char *)(lVar13 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(iVar22,0x13b63c8,0x14d6098,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar10 = param_2[0xe];
              uVar15 = *(uint *)(param_2 + 0xc);
            }
            uVar16 = (ulonglong)uVar10;
            uVar10 = puVar17[uVar16];
            *(uint *)(param_2 + 2) = uVar10 & 0x7fff;
            if ((uVar10 & 0x7fff) < uVar15) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar13 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar13 != 0)) &&
                 ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                  (*(char *)(lVar13 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(iVar22,0x13b63c8,0x14d6098,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar16 = (ulonglong)(ushort)param_2[0xe];
            }
            if ((short)puVar17[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
              lVar13 = *(longlong *)(param_2 + 4);
              do {
                if ((int)uVar16 == 1) {
                  uVar15 = *(uint *)(param_2 + 0xc);
                  uVar19 = uVar15;
LAB_:
                  if ((*(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar13 + uVar16 * 2) &
                      0x7fff) < uVar15) goto LAB_;
                }
                else {
                  uVar19 = *(uint *)(param_2 + 0xc);
                  uVar15 = *(ushort *)
                            ((ulonglong)*(uint *)(param_2 + 10) + lVar13 + -2 + uVar16 * 2) & 0x7fff
                  ;
                  if (uVar19 <= uVar15) goto LAB_;
LAB_:
                  func_0x(lVar13,7);
                  uVar19 = *(uint *)(param_2 + 0xc);
                }
                if ((uVar15 < uVar19) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
                lVar13 = *(longlong *)(param_2 + 4);
                if (*(ushort *)(lVar13 + (ulonglong)uVar15) == 5) {
                  *puVar1 = *puVar1 | 2;
                  param_2[0xe] = param_2[0xe] + -1;
                  param_2[0x15] = (short)uVar15;
                  lVar13 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(param_2 + 4);
                  uVar10 = param_2[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar13 + 2) >> 0xe & 1) != 0) {
                    uVar10 = *(ushort *)(lVar13 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                  }
                  param_2[0x16] = uVar10;
                  param_2[0x16] = (uVar10 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar10;
                  goto LAB_;
                }
                if (*(ushort *)(lVar13 + (ulonglong)uVar15) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar10 = param_2[0xe] - 1;
                param_2[0xe] = uVar10;
                if (uVar10 == 0) goto LAB_;
                uVar16 = (ulonglong)uVar10;
              } while ((short)puVar17[(ulonglong)(uVar10 - 1) + 1] < 0);
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
            else {
LAB_:
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
          }
          if ((**(byte **)(param_2 + 4) & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0x13) = 0;
          }
          else {
            *(int *)(param_2 + 0x13) = (int)uVar16;
            *(int *)(param_2 + 2) = (int)uVar16 + 0xe;
            puVar11 = (ulonglong *)func_0x(puVar1);
            uVar14 = (ushort)(*puVar11 >> 0x30);
            uVar10 = uVar14;
            if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
              uVar10 = uVar14 & 0xdfff;
              if ((uVar14 >> 0xe & 1) != 0) {
                uVar10 = uVar14 | 0x2000;
              }
            }
            if (uVar10 == 0xfffc) {
              iVar24 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar24;
            uVar16 = (ulonglong)*(uint *)(param_2 + 2);
          }
          iVar24 = (int)uVar16;
          if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
             (*(ulonglong *)(param_2 + 0xf) < uVar16 + *(longlong *)(param_2 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar13 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar13 != 0 &&
                 (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
                (*(char *)(lVar13 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(iVar22,0x13b63c8,0x14d6098,0x877,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),0x12);
            iVar24 = *(int *)(param_2 + 2);
          }
          if (0x3f3b < iVar24 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar13 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar13 != 0 &&
                ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                 (*(char *)(lVar13 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(iVar22,0x13b63c8,0x14d6098,0x87c,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),5);
          }
        }
LAB_:
        sVar21 = -(short)iStack_58;
        if ((uStack_52 & 0x10) == 0) {
LAB_:
          puVar23 = *(undefined8 **)(param_2 + 4);
          lVar13 = (longlong)sVar21;
          if ((uint)(int)sVar21 <= (uint)(ushort)param_2[0xe]) {
            uVar15 = *(uint *)(param_2 + 10);
            if (sVar21 == 1) {
              uVar19 = *(uint *)(psStackX_10 + 0xc);
              uVar15 = *(ushort *)((longlong)puVar23 + lVar13 * 2 + (ulonglong)uVar15) & 0x7fff;
LAB_:
              if (uVar15 < uVar19) goto LAB_;
            }
            else {
              puVar1 = (ushort *)((longlong)puVar23 + lVar13 * 2 + (ulonglong)uVar15);
              uVar19 = *(ushort *)((longlong)puVar23 + lVar13 * 2 + ((ulonglong)uVar15 - 2)) &
                       0x7fff;
              puVar23 = *(undefined8 **)(param_2 + 4);
              uVar15 = *puVar1 & 0x7fff;
              if (*(uint *)(psStackX_10 + 0xc) <= uVar19) goto LAB_;
LAB_:
              func_0x(puVar23,7);
              puVar23 = *(undefined8 **)(param_2 + 4);
            }
            iVar25 = uVar15 - uVar19;
            puVar23 = (undefined8 *)((longlong)puVar23 + (ulonglong)uVar19);
          }
        }
        else {
          bVar9 = **(byte **)(param_2 + 4);
          if ((bVar9 & 0x10) == 0) {
            if ((iVar22 << (bVar9 & 0xe) & 0x1105U) == 0) goto LAB_;
          }
          else if ((iStack_58 < (int)*(uint *)(param_2 + 8)) &&
                  (uStack_54 <= *(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8))))
          goto LAB_;
          iVar25 = *piStack_50;
          puVar23 = (undefined8 *)(piStack_50 + 1);
        }
      }
    }
    else {
      uVar15 = *(uint *)(param_2 + 8);
      if (((-6 < (int)uVar15) && (5 < *(ushort *)(pbVar2 + uVar15))) &&
         ((pbVar2[(ulonglong)uVar15 + 2] >> 5 & 1) == 0)) {
        iVar22 = (pbVar2[(ulonglong)uVar15 + 2] >> 5 & 1) + 1;
        goto LAB_;
      }
    }
  }
  else {
    uStackX_18 = 0;
    puVar20 = (undefined8 *)func_0x(puVar1,&iStack_58);
    if ((((*psVar18 == 0) || (plVar3 = *(longlong **)(psVar18 + 8), plVar3 == (longlong *)0x0)) ||
        (*plVar3 == 0)) || (((uStack_52 & 8) != 0 || ((uStackX_18 & 1) != 0)))) goto LAB_;
    if ((puVar20 != (undefined8 *)0x0) && (puVar20 != (undefined8 *)0x113ae04)) {
      puVar20 = (undefined8 *)
                func_0x
                          (plVar3,&iStack_58,puVar20,uStackX_8 & 0xffffffff,0,0,&uStackX_8,
                           uStackX_18);
      goto LAB_;
    }
  }
  puVar20 = puVar23;
  uStackX_8 = CONCAT44(uStackX_8._4_4_,iVar25);
LAB_:
  if ((puVar20 == (undefined8 *)0x0) || ((int)uStackX_8 != 4)) {
    uStack_60 = *(undefined2 *)(puVar8 + 1);
    uStack_68 = *puVar8;
    (*_DAT_)(0x5a,0xf,0x17,3,&uStack_68);
  }
  *puStackX_20 = *(undefined4 *)puVar20;
  return;
}

