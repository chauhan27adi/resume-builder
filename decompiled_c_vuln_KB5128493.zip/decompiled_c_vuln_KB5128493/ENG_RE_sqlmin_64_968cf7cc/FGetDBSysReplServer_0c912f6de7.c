
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined2 param_1,undefined8 param_2,longlong param_3,ulonglong *param_4,
                 longlong param_5)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong unaff_GS_OFFSET;
  undefined auStack_118 [32];
  undefined8 uStack_f8;
  longlong lStack_f0;
  undefined4 auStack_e8 [2];
  longlong *plStack_e0;
  undefined8 uStack_d8;
  longlong lStack_c8;
  undefined2 uStack_c0;
  longlong lStack_b8;
  int iStack_b0;
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  longlong lStack_68;
  uint uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_d8 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_118;
  plVar5 = (longlong *)0x0;
  plStack_e0 = (longlong *)0x0;
  *param_4 = 0;
  plVar4 = plVar5;
  if (param_5 == 0) {
    plVar4 = *(longlong **)
              (*(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                ) + 0x90);
    if ((plVar4 == (longlong *)0x0) ||
       (cVar1 = (**(code **)(*plVar4 + 0x1d0))(plVar4), cVar1 == '\0')) {
      plVar4 = (longlong *)(***(code ***)*_DAT_)();
      plStack_e0 = plVar4;
      (**(code **)(*plVar4 + 8))(plVar4,0x1a29ec0,0x1e);
      param_5 = (**(code **)(*plVar4 + 0x48))(plVar4);
    }
    else {
      param_5 = (**(code **)(*plVar4 + 0x1b0))(plVar4);
      plVar4 = plStack_e0;
    }
  }
  iVar2 = func_0x(param_1,0x1a29ec0);
  if (iVar2 != 0) {
    lStack_c8 = 0;
    auStack_a8 = ZEXT816(0);
    auStack_98 = ZEXT816(0);
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    lStack_68 = 0;
    uStack_60 = 0;
    uStack_58 = 0;
    uStack_50 = 0;
    uStack_c0 = param_1;
    lStack_b8 = param_5;
    iStack_b0 = iVar2;
    iVar2 = func_0x(&lStack_c8,3,1);
    if (iVar2 != 0) {
      lStack_f0 = lStack_c8;
      uStack_f8 = uStack_58;
      iVar2 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1);
      if (iVar2 == 0) {
        auStack_e8[0] = 0;
        if (lStack_c8 != 0) {
          *param_4 = 0;
          uVar3 = func_0x(&lStack_c8,0x1a29e78,auStack_e8);
          uVar7 = (ulonglong)uVar3;
          if ((ulonglong)uVar3 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_68)) {
LAB_:
            plVar5 = (longlong *)0x0;
            if (uVar3 <= uStack_60) {
              lVar6 = (ulonglong)(uVar3 - 1) * 0x58 + lStack_68;
              *param_4 = *(ulonglong *)(lStack_c8 + *(longlong *)(lVar6 + 0x10));
              plVar5 = (longlong *)(*(longlong *)(lVar6 + 8) + lStack_c8);
              plVar4 = plStack_e0;
            }
          }
          else {
            uVar3 = 1;
            if (uStack_60 != 0) {
              do {
                if (uVar7 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_68))
                goto LAB_;
                uVar3 = uVar3 + 1;
              } while (uVar3 <= uStack_60);
            }
          }
        }
        if (*param_4 <= (ulonglong)(param_3 * 2)) {
          func_0x(param_2,plVar5);
        }
      }
    }
    func_0x(&lStack_c8);
  }
  if (plVar4 != (longlong *)0x0) {
    (**(code **)*plVar4)(plVar4,1);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_118);
  return;
}

