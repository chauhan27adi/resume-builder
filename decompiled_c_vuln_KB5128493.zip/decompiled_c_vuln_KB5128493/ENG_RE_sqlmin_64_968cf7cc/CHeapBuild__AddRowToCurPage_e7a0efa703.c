
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,short *param_2)

{
  ushort uVar1;
  ulonglong *puVar2;
  undefined8 uVar3;
  byte bVar4;
  ulonglong uVar5;
  ushort uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  ulonglong uVar10;
  uint uVar11;
  ushort *puVar12;
  longlong lVar13;
  byte *pbVar14;
  int iVar15;
  int iVar16;
  longlong unaff_GS_OFFSET;
  
  iVar16 = 0;
  if (*param_2 == 0) {
    if (*(int *)(param_2 + 2) == 0) {
      pbVar14 = *(byte **)(param_2 + 4);
      param_2[1] = 0;
      uVar7 = *(uint *)(param_2 + 8);
      uVar10 = (ulonglong)uVar7;
      *(uint *)(param_2 + 10) = uVar7;
      bVar4 = *pbVar14;
      if ((bVar4 & 0x10) != 0) {
        uVar7 = uVar7 + 2 + (*(ushort *)(pbVar14 + uVar10) + 7 >> 3);
        uVar10 = (ulonglong)uVar7;
        *(uint *)(param_2 + 10) = uVar7;
        bVar4 = *pbVar14;
      }
      if ((bVar4 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar10;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar10;
      }
      else {
        puVar12 = (ushort *)(pbVar14 + uVar10);
        uVar1 = *puVar12;
        param_2[0xe] = uVar1;
        if (uVar1 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0)) &&
             ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
              (*(char *)(lVar13 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x1279b78,0x1399848,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar10 = (ulonglong)*(uint *)(param_2 + 10);
          uVar1 = param_2[0xe];
        }
        uVar7 = (int)uVar10 + (uVar1 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar7;
        if (0x1f9e < uVar7) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0 &&
              ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
               (*(char *)(lVar13 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x1279b78,0x1399848,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar1 = param_2[0xe];
          uVar7 = *(uint *)(param_2 + 0xc);
        }
        uVar5 = (ulonglong)uVar1;
        uVar8 = puVar12[uVar5] & 0x7fff;
        *(uint *)(param_2 + 2) = uVar8;
        if (uVar8 < uVar7) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0)) &&
             ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
              (*(char *)(lVar13 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x1279b78,0x1399848,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar5 = (ulonglong)(ushort)param_2[0xe];
          uVar8 = *(uint *)(param_2 + 2);
        }
        uVar10 = (ulonglong)uVar8;
        if ((short)puVar12[(ulonglong)((int)uVar5 - 1) + 1] < 0) {
          pbVar14 = *(byte **)(param_2 + 4);
          do {
            if ((int)uVar5 == 1) {
              uVar7 = *(uint *)(param_2 + 0xc);
              uVar8 = uVar7;
LAB_:
              if ((*(ushort *)(pbVar14 + uVar5 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff) <
                  uVar7) goto LAB_;
            }
            else {
              uVar8 = *(uint *)(param_2 + 0xc);
              uVar7 = *(ushort *)(pbVar14 + uVar5 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                      0x7fff;
              if (uVar8 <= uVar7) goto LAB_;
LAB_:
              func_0x(pbVar14,7);
              uVar8 = *(uint *)(param_2 + 0xc);
            }
            if ((uVar7 < uVar8) ||
               (uVar10 = (ulonglong)*(uint *)(param_2 + 2), *(uint *)(param_2 + 2) < uVar7))
            goto LAB_;
            pbVar14 = *(byte **)(param_2 + 4);
            if (*(ushort *)(pbVar14 + uVar7) == 5) {
              param_2[1] = param_2[1] | 2;
              param_2[0xe] = param_2[0xe] + -1;
              param_2[0x15] = (short)uVar7;
              lVar13 = (ulonglong)(uVar7 & 0xffff) + *(longlong *)(param_2 + 4);
              uVar1 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar13 + 2) >> 0xe & 1) != 0) {
                uVar1 = *(ushort *)(lVar13 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar1;
              param_2[0x16] = (uVar1 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar1;
              uVar10 = (ulonglong)*(uint *)(param_2 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar14 + uVar7) < 0x400) goto LAB_;
            param_2[1] = param_2[1] | 1;
            uVar1 = param_2[0xe] - 1;
            param_2[0xe] = uVar1;
            if (uVar1 == 0) goto LAB_;
            uVar5 = (ulonglong)uVar1;
          } while ((short)puVar12[(ulonglong)(uVar1 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar14 = *(byte **)(param_2 + 4);
        }
      }
      if ((*pbVar14 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar10;
        *(int *)(param_2 + 2) = (int)uVar10 + 0xe;
        puVar2 = (ulonglong *)func_0x(param_2 + 1);
        uVar6 = (ushort)(*puVar2 >> 0x30);
        uVar1 = uVar6;
        if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
          uVar1 = uVar6 & 0xdfff;
          if ((uVar6 >> 0xe & 1) != 0) {
            uVar1 = uVar6 | 0x2000;
          }
        }
        iVar15 = iVar16;
        if (uVar1 == 0xfffc) {
          iVar15 = (int)((*puVar2 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar15;
        uVar10 = (ulonglong)*(uint *)(param_2 + 2);
      }
      iVar15 = (int)uVar10;
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar10 + *(longlong *)(param_2 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar13 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar13 != 0 &&
             (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
            (*(char *)(lVar13 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x1279b78,0x1399848,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        iVar15 = *(int *)(param_2 + 2);
      }
      if (0x3f3b < iVar15 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar13 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar13 != 0 &&
            ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
             (*(char *)(lVar13 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x1279b78,0x1399848,0x87c,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
      }
    }
LAB_:
    uVar7 = *(uint *)(param_2 + 2);
    uVar8 = uVar7;
    if (8 < uVar7) goto LAB_;
    bVar4 = **(byte **)(param_2 + 4) & 0xe;
  }
  else {
    uVar7 = *(uint *)(param_2 + 2);
    if (uVar7 == 0) {
      func_0x(param_2 + 1);
      uVar7 = *(uint *)(param_2 + 2);
    }
    uVar8 = uVar7;
    if (8 < uVar7) goto LAB_;
    bVar4 = **(byte **)(param_2 + 4) & 0x1c;
  }
  if ((bVar4 == 0) || (uVar8 = uVar7, bVar4 == 0xc)) {
    uVar8 = 9;
  }
LAB_:
  uVar11 = 9;
  uVar1 = *(ushort *)(*(longlong *)(param_1 + 0x250) + 0x1c);
  iVar15 = (1 << ((byte)*(undefined2 *)(*(longlong *)(param_1 + 0x250) + 4) & 2)) + -1;
  uVar9 = uVar1 - 2;
  if (uVar1 < 3) {
    uVar9 = 0;
  }
  if (uVar9 < (iVar15 + uVar8 & 0xffff & (uint)(ushort)~(ushort)iVar15)) {
    uVar3 = 0xffffffff;
  }
  else {
    if (*param_2 == 0) {
      if (uVar7 == 0) {
        pbVar14 = *(byte **)(param_2 + 4);
        uVar7 = *(uint *)(param_2 + 8);
        uVar10 = (ulonglong)uVar7;
        param_2[1] = 0;
        *(uint *)(param_2 + 10) = uVar7;
        bVar4 = *pbVar14;
        if ((bVar4 & 0x10) != 0) {
          uVar7 = uVar7 + 2 + (*(ushort *)(pbVar14 + uVar10) + 7 >> 3);
          uVar10 = (ulonglong)uVar7;
          *(uint *)(param_2 + 10) = uVar7;
          bVar4 = *pbVar14;
        }
        if ((bVar4 & 0x20) == 0) {
          *(int *)(param_2 + 2) = (int)uVar10;
          param_2[0xe] = 0;
          *(int *)(param_2 + 0xc) = (int)uVar10;
        }
        else {
          puVar12 = (ushort *)(pbVar14 + uVar10);
          uVar1 = *puVar12;
          param_2[0xe] = uVar1;
          if (uVar1 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar13 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar13 != 0)) &&
               ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                (*(char *)(lVar13 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x1279b78,0x1399848,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),3);
            uVar10 = (ulonglong)*(uint *)(param_2 + 10);
            uVar1 = param_2[0xe];
          }
          uVar7 = (int)uVar10 + (uVar1 + 1) * 2;
          *(uint *)(param_2 + 0xc) = uVar7;
          if (0x1f9e < uVar7) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar13 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar13 != 0 &&
                ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                 (*(char *)(lVar13 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x1279b78,0x1399848,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar1 = param_2[0xe];
            uVar7 = *(uint *)(param_2 + 0xc);
          }
          uVar5 = (ulonglong)uVar1;
          uVar8 = puVar12[uVar5] & 0x7fff;
          *(uint *)(param_2 + 2) = uVar8;
          if (uVar8 < uVar7) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar13 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar13 != 0)) &&
               ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
                (*(char *)(lVar13 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x1279b78,0x1399848,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar5 = (ulonglong)(ushort)param_2[0xe];
            uVar8 = *(uint *)(param_2 + 2);
          }
          uVar10 = (ulonglong)uVar8;
          if ((short)puVar12[(ulonglong)((int)uVar5 - 1) + 1] < 0) {
            lVar13 = *(longlong *)(param_2 + 4);
            do {
              if ((int)uVar5 == 1) {
                uVar7 = *(uint *)(param_2 + 0xc);
                uVar8 = uVar7;
LAB_:
                if ((*(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar13 + uVar5 * 2) & 0x7fff)
                    < uVar7) goto LAB_;
              }
              else {
                uVar8 = *(uint *)(param_2 + 0xc);
                uVar7 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar13 + -2 + uVar5 * 2) &
                        0x7fff;
                if (uVar8 <= uVar7) goto LAB_;
LAB_:
                func_0x(lVar13,7);
                uVar8 = *(uint *)(param_2 + 0xc);
              }
              if ((uVar7 < uVar8) ||
                 (uVar10 = (ulonglong)*(uint *)(param_2 + 2), *(uint *)(param_2 + 2) < uVar7))
              goto LAB_;
              lVar13 = *(longlong *)(param_2 + 4);
              if (*(ushort *)((ulonglong)uVar7 + lVar13) == 5) {
                param_2[1] = param_2[1] | 2;
                param_2[0xe] = param_2[0xe] + -1;
                param_2[0x15] = (short)uVar7;
                lVar13 = (ulonglong)(uVar7 & 0xffff) + *(longlong *)(param_2 + 4);
                uVar1 = param_2[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar13 + 2) & 0x4000) != 0) {
                  uVar1 = *(ushort *)(lVar13 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                }
                param_2[0x16] = uVar1;
                param_2[0x16] = (uVar1 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar1;
                uVar10 = (ulonglong)*(uint *)(param_2 + 2);
                pbVar14 = *(byte **)(param_2 + 4);
                goto LAB_;
              }
              if (*(ushort *)((ulonglong)uVar7 + lVar13) < 0x400) break;
              param_2[1] = param_2[1] | 1;
              uVar1 = param_2[0xe] - 1;
              param_2[0xe] = uVar1;
              if ((uVar1 == 0) ||
                 (uVar5 = (ulonglong)uVar1, -1 < (short)puVar12[(ulonglong)(uVar1 - 1) + 1])) break;
            } while( true );
          }
          pbVar14 = *(byte **)(param_2 + 4);
        }
LAB_:
        if ((*pbVar14 & 0x40) == 0) {
          *(undefined4 *)(param_2 + 0x13) = 0;
        }
        else {
          *(int *)(param_2 + 0x13) = (int)uVar10;
          *(int *)(param_2 + 2) = (int)uVar10 + 0xe;
          puVar2 = (ulonglong *)func_0x(param_2 + 1);
          uVar10 = *puVar2;
          uVar6 = (ushort)(uVar10 >> 0x30);
          uVar1 = uVar6;
          if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
            uVar1 = uVar6 & 0xdfff;
            if ((uVar10 & 0x4000000000000000) != 0) {
              uVar1 = uVar6 | 0x2000;
            }
          }
          if (uVar1 == 0xfffc) {
            iVar16 = (int)((uVar10 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar16;
          uVar10 = (ulonglong)*(uint *)(param_2 + 2);
        }
        iVar16 = (int)uVar10;
        if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
           (*(ulonglong *)(param_2 + 0xf) < uVar10 + *(longlong *)(param_2 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar13 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar13 != 0 &&
               (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
              (*(char *)(lVar13 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x1279b78,0x1399848,0x877,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),0x12);
          iVar16 = *(int *)(param_2 + 2);
        }
        if (0x3f3b < iVar16 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0 &&
              ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
               (*(char *)(lVar13 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x1279b78,0x1399848,0x87c,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),5);
        }
      }
LAB_:
      if ((8 < *(uint *)(param_2 + 2)) ||
         (((**(byte **)(param_2 + 4) & 0xe) != 0 && ((**(byte **)(param_2 + 4) & 0xe) != 0xc)))) {
        uVar11 = *(uint *)(param_2 + 2);
      }
    }
    else {
      if (uVar7 == 0) {
        func_0x(param_2 + 1);
        uVar7 = *(uint *)(param_2 + 2);
      }
      if ((8 < uVar7) ||
         (((**(byte **)(param_2 + 4) & 0x1c) != 0 && ((**(byte **)(param_2 + 4) & 0x1c) != 0xc)))) {
        uVar11 = uVar7;
      }
    }
    uVar3 = func_0x
                      (*(undefined8 *)(param_1 + 0x250),*(undefined8 *)(param_2 + 4),uVar11);
  }
  return uVar3;
}

