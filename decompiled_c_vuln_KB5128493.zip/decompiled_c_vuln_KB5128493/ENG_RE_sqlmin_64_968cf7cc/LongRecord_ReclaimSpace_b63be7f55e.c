
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,short *param_3,uint param_4,
                 undefined4 *param_5)

{
  uint6 uVar1;
  byte bVar2;
  ushort uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint6 *puVar7;
  ulonglong *puVar8;
  int *piVar9;
  uint6 *puVar10;
  byte bVar11;
  uint uVar12;
  longlong lVar13;
  ushort uVar14;
  ulonglong uVar15;
  uint uVar16;
  ushort *puVar17;
  uint uVar18;
  uint6 *puVar19;
  byte *pbVar20;
  longlong lVar21;
  undefined8 uVar22;
  uint6 *puVar23;
  int iVar24;
  longlong unaff_GS_OFFSET;
  undefined8 in_stack_ffffffffffffff98;
  undefined4 uVar25;
  longlong lStack_58;
  int iStack_48;
  undefined2 uStack_44;
  ushort uStack_42;
  undefined8 uStack_40;
  
  iStack_48 = 0;
  uStack_42 = uStack_42 & 0xffe0;
  uStack_44 = 0;
  *param_5 = 0;
  uStack_40 = 0;
  if ((param_4 & 0xd0) != 0) {
    if (*param_3 == 0) {
      uVar4 = func_0x(param_3 + 1);
    }
    else {
      uVar4 = (uint)(ushort)param_3[1];
    }
    uVar16 = 0;
    if (0 < (int)uVar4) {
      do {
        uVar22 = 0;
        uVar18 = ~uVar16;
        if ((uVar18 & 0xc0000000) == 0x80000000) {
          puVar7 = (uint6 *)func_0x
                                      (**(undefined8 **)(*(longlong *)(param_1 + 8) + 0x160),
                                       uVar18 & 0x1fffffff);
          uVar22 = 0;
        }
        else {
          puVar7 = (uint6 *)func_0x
                                      (*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x160));
        }
        uVar25 = (undefined4)((ulonglong)in_stack_ffffffffffffff98 >> 0x20);
        if (puVar7 == (uint6 *)0x0) {
          func_0x(param_1,uVar18,&iStack_48);
LAB_:
          in_stack_ffffffffffffff98 = CONCAT44(uVar25,param_4);
          func_0x(param_1,param_2,&iStack_48,param_3,in_stack_ffffffffffffff98,param_5);
        }
        else {
          iStack_48 = *(int *)puVar7;
          uVar1 = *puVar7;
          uStack_40 = *(undefined8 *)(puVar7 + 1);
          uStack_44 = (undefined2)*(int *)((longlong)puVar7 + 4);
          uStack_42 = (ushort)((uint)*(int *)((longlong)puVar7 + 4) >> 0x10);
          if ((*(byte *)(puVar7 + 4) & 0x40) != 0) {
            uVar18 = (uint)uVar22;
            if (*param_3 == 0) {
              pbVar20 = *(byte **)(param_3 + 4);
              if ((*pbVar20 & 0x10) == 0) {
                if ((1 << (*pbVar20 & 0xe) & 0x1105U) != 0) {
LAB_:
                  uVar18 = ~(uint)(((ulonglong)uStack_42 << 0x30) >> 0x34) & 1;
                }
              }
              else {
                uVar18 = *(uint *)(param_3 + 8);
                if ((int)uVar18 <= iStack_48) goto LAB_;
                uVar12 = (uint)(ushort)(*puVar7 >> 0x20);
                if (*(ushort *)(pbVar20 + uVar18) < uVar12) {
                  uVar18 = ~(uint)(CONCAT26(uStack_42,*puVar7) >> 0x34) & 1;
                }
                else {
                  uVar12 = uVar12 - 1;
                  uVar18 = pbVar20[(ulonglong)(uVar12 >> 3) + (ulonglong)uVar18 + 2] >>
                           ((byte)uVar12 & 7) & 1;
                }
              }
            }
            else {
              uVar18 = (uint)(CONCAT26(uStack_42,uVar1) >> 0x20);
              if ((ushort)param_3[1] < (ushort)(uVar1 >> 0x20)) {
                uVar18 = ~(uVar18 >> 0x14) & 1;
              }
              else {
                bVar2 = *(byte *)((longlong)((int)((uVar18 & 0xffff) - 1) / 2) +
                                  (ulonglong)(ushort)param_3[0xc] + *(longlong *)(param_3 + 4));
                bVar11 = bVar2 >> 4;
                if ((uVar1 & 0x100000000) != 0) {
                  bVar11 = bVar2 & 0xf;
                }
                uVar18 = (uint)CONCAT71((int7)((ulonglong)uVar22 >> 8),bVar11 == 0);
              }
            }
            if (uVar18 != 0) goto LAB_;
          }
        }
        uVar16 = uVar16 + 1;
      } while ((int)uVar16 < (int)uVar4);
    }
    iVar24 = -1;
    uVar4 = 0;
    iVar5 = func_0x(param_3);
    if (0 < (longlong)iVar5) {
      lStack_58 = 0;
      do {
        if (*(int *)(param_3 + 2) == 0) {
          pbVar20 = *(byte **)(param_3 + 4);
          uVar16 = *(uint *)(param_3 + 8);
          uVar15 = (ulonglong)uVar16;
          param_3[1] = 0;
          *(uint *)(param_3 + 10) = uVar16;
          bVar2 = *pbVar20;
          if ((bVar2 & 0x10) != 0) {
            uVar16 = uVar16 + 2 + (*(ushort *)(pbVar20 + uVar15) + 7 >> 3);
            uVar15 = (ulonglong)uVar16;
            *(uint *)(param_3 + 10) = uVar16;
            bVar2 = *pbVar20;
          }
          if ((bVar2 & 0x20) == 0) {
            *(int *)(param_3 + 2) = (int)uVar15;
            param_3[0xe] = 0;
            *(int *)(param_3 + 0xc) = (int)uVar15;
          }
          else {
            puVar17 = (ushort *)(pbVar20 + uVar15);
            uVar3 = *puVar17;
            param_3[0xe] = uVar3;
            if (uVar3 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar21 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar21 != 0)) &&
                 ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                  (*(char *)(lVar21 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0xa9bd68,0xbbba38,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),3);
              uVar15 = (ulonglong)*(uint *)(param_3 + 10);
              uVar3 = param_3[0xe];
            }
            uVar16 = (int)uVar15 + (uVar3 + 1) * 2;
            *(uint *)(param_3 + 0xc) = uVar16;
            if (0x1f9e < uVar16) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar21 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar21 != 0 &&
                  ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                   (*(char *)(lVar21 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0xa9bd68,0xbbba38,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),4);
              uVar3 = param_3[0xe];
              uVar16 = *(uint *)(param_3 + 0xc);
            }
            uVar15 = (ulonglong)uVar3;
            uVar3 = puVar17[uVar15];
            *(uint *)(param_3 + 2) = uVar3 & 0x7fff;
            if ((uVar3 & 0x7fff) < uVar16) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar21 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar21 != 0)) &&
                 ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                  (*(char *)(lVar21 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0xa9bd68,0xbbba38,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),4);
              uVar15 = (ulonglong)(ushort)param_3[0xe];
            }
            if ((short)puVar17[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
              pbVar20 = *(byte **)(param_3 + 4);
              do {
                if ((int)uVar15 == 1) {
                  uVar16 = *(uint *)(param_3 + 0xc);
                  uVar18 = uVar16;
LAB_:
                  if ((*(ushort *)(pbVar20 + uVar15 * 2 + (ulonglong)*(uint *)(param_3 + 10)) &
                      0x7fff) < uVar16) goto LAB_;
                }
                else {
                  uVar18 = *(uint *)(param_3 + 0xc);
                  uVar16 = *(ushort *)
                            (pbVar20 + uVar15 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                           0x7fff;
                  if (uVar18 <= uVar16) goto LAB_;
LAB_:
                  func_0x(pbVar20,7);
                  uVar18 = *(uint *)(param_3 + 0xc);
                }
                if ((uVar16 < uVar18) || (*(uint *)(param_3 + 2) < uVar16)) goto LAB_;
                pbVar20 = *(byte **)(param_3 + 4);
                if (*(ushort *)(pbVar20 + uVar16) == 5) {
                  param_3[1] = param_3[1] | 2;
                  param_3[0xe] = param_3[0xe] + -1;
                  uVar18 = uVar16 & 0xffff;
                  param_3[0x15] = (short)uVar16;
                  uVar3 = param_3[0x16] & 0xc7ffU;
                  if ((*(ushort *)(pbVar20 + (ulonglong)uVar18 + 2) >> 0xe & 1) != 0) {
                    uVar3 = *(ushort *)(pbVar20 + (ulonglong)uVar18 + 2) & 0x3800 |
                            param_3[0x16] & 0xc7ffU;
                  }
                  param_3[0x16] = uVar3;
                  param_3[0x16] =
                       (uVar3 ^ *(ushort *)(pbVar20 + (ulonglong)uVar18 + 2)) & 0x7ff ^ uVar3;
                  goto LAB_;
                }
                if (*(ushort *)(pbVar20 + uVar16) < 0x400) goto LAB_;
                param_3[1] = param_3[1] | 1;
                uVar3 = param_3[0xe] - 1;
                param_3[0xe] = uVar3;
                if (uVar3 == 0) goto LAB_;
                uVar15 = (ulonglong)uVar3;
              } while ((short)puVar17[(ulonglong)(uVar3 - 1) + 1] < 0);
              uVar15 = (ulonglong)*(uint *)(param_3 + 2);
            }
            else {
LAB_:
              uVar15 = (ulonglong)*(uint *)(param_3 + 2);
              pbVar20 = *(byte **)(param_3 + 4);
            }
          }
          iVar6 = 0;
          if ((*pbVar20 & 0x40) == 0) {
            *(undefined4 *)(param_3 + 0x13) = 0;
          }
          else {
            *(int *)(param_3 + 0x13) = (int)uVar15;
            *(int *)(param_3 + 2) = (int)uVar15 + 0xe;
            puVar8 = (ulonglong *)func_0x(param_3 + 1);
            uVar14 = (ushort)(*puVar8 >> 0x30);
            uVar3 = uVar14;
            if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
              uVar3 = uVar14 & 0xdfff;
              if ((uVar14 >> 0xe & 1) != 0) {
                uVar3 = uVar14 | 0x2000;
              }
            }
            if (uVar3 == 0xfffc) {
              iVar6 = (int)((*puVar8 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar6;
            uVar15 = (ulonglong)*(uint *)(param_3 + 2);
          }
          iVar6 = (int)uVar15;
          if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
             (*(ulonglong *)(param_3 + 0xf) < uVar15 + *(longlong *)(param_3 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar21 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar21 != 0 &&
                 (lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0)) &&
                (*(char *)(lVar21 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0xa9bd68,0xbbba38,0x877,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),0x12);
            iVar6 = *(int *)(param_3 + 2);
          }
          if (0x3f3b < iVar6 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar21 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar21 != 0 &&
                ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                 (*(char *)(lVar21 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                func_0x(*(undefined8 *)(param_3 + 4),5);
                goto LAB_;
              }
              (*_DAT_)(1,0xa9bd68,0xbbba38,0x87c,0);
            }
            func_0x(*(undefined8 *)(param_3 + 4),5);
          }
        }
LAB_:
        iVar6 = func_0x(param_3 + 1);
        if (iVar6 == 0) {
          iVar6 = func_0x(param_3 + 1);
          if (iVar6 == 0) {
            (*_DAT_)(1,0xc573e8,0xc484d8,0xd67,0);
          }
        }
        else {
          uVar3 = param_3[0x16];
          if (uVar4 < (uVar3 & 0x7ff)) {
            lVar21 = *(longlong *)(param_3 + 4) + (ulonglong)(ushort)param_3[0x15];
            if ((uVar3 & 0x3800) == 0) {
              uVar14 = *(ushort *)(lVar21 + 2);
LAB_:
              uVar14 = uVar14 >> 0xb & 7;
            }
            else {
              lVar13 = 0;
              uVar14 = 0;
              if ((uVar3 >> 0xb & 7) != 0) {
                do {
                  if (((lVar13 == 0) || ((*(ushort *)(lVar21 + 2 + lVar13 * 2) & 0x7ff) <= uVar4))
                     && (uVar14 = *(ushort *)(lVar21 + 4 + lVar13 * 2),
                        (int)uVar4 <= (int)((uVar14 & 0x7ff) - 1))) goto LAB_;
                  lVar13 = lVar13 + 1;
                  uVar14 = 0;
                } while (lVar13 < (longlong)(ulonglong)(uVar3 >> 0xb & 7));
              }
            }
            iVar24 = (uint)*(ushort *)
                            ((ulonglong)((uVar3 >> 0xb & 7) * 2) + *(longlong *)(param_3 + 4) +
                             lStack_58 * 2 + 4 + (ulonglong)(ushort)param_3[0x15]) +
                     (uint)uVar14 * 0x10000;
          }
          else {
            (*_DAT_)(1,0xc573b8,0xc57400,0x3c6,0);
          }
        }
        piVar9 = (int *)func_0x
                                  (**(undefined8 **)(*(longlong *)(param_1 + 8) + 0x160),iVar24);
        iStack_48 = *piVar9;
        uStack_40 = *(undefined8 *)(piVar9 + 2);
        uStack_44 = (undefined2)piVar9[1];
        uStack_42 = (ushort)((uint)piVar9[1] >> 0x10);
        if ((*(byte *)(piVar9 + 8) & 0x10) != 0) {
          func_0x(param_1,param_2,&iStack_48,param_3,param_4,param_5);
        }
        lStack_58 = lStack_58 + 1;
        uVar4 = uVar4 + 1;
      } while (lStack_58 < iVar5);
    }
  }
  puVar7 = (uint6 *)0x0;
  if (((param_4 & 2) != 0) &&
     (lVar21 = *(longlong *)(param_1 + 8), puVar19 = puVar7, puVar10 = puVar7,
     0 < *(int *)(**(longlong **)(lVar21 + 0x160) + 0x14))) {
    do {
      iVar5 = *(int *)(**(longlong **)(lVar21 + 0x160) + 0x14);
      puVar23 = puVar10;
      if (iVar5 != 0) {
        if (puVar7 == (uint6 *)0x0) {
          iVar24 = 0;
        }
        else {
          iVar24 = *(int *)puVar7;
        }
        iVar24 = iVar24 + -1;
        iVar6 = -iVar24;
        if (iVar6 <= iVar5) {
          do {
            puVar10 = (uint6 *)func_0x(*(undefined8 *)(lVar21 + 0x160),iVar24);
            if ((puVar10 != (uint6 *)0x0) && ((*(byte *)(puVar10 + 4) & 0x10) == 0)) {
              if ((*(short *)(puVar10 + 7) == -1) ||
                 (*(char *)((ulonglong)
                            *(byte *)((ulonglong)*(byte *)((longlong)puVar10 + 0x34) + 0x820c40) +
                           0x11d62b8) != '\0')) {
                iStack_48 = *(int *)puVar10;
                uVar1 = *puVar10;
                uStack_40 = *(undefined8 *)(puVar10 + 1);
                uStack_44 = (undefined2)*(int *)((longlong)puVar10 + 4);
                uStack_42 = (ushort)((uint)*(int *)((longlong)puVar10 + 4) >> 0x10);
                if ((*(byte *)(puVar10 + 4) & 0x40) != 0) {
                  uVar4 = (uint)puVar23;
                  if (*param_3 == 0) {
                    pbVar20 = *(byte **)(param_3 + 4);
                    if ((*pbVar20 & 0x10) == 0) {
                      if ((1 << (*pbVar20 & 0xe) & 0x1105U) != 0) {
LAB_:
                        uVar4 = ~(uint)(((ulonglong)uStack_42 << 0x30) >> 0x34) & 1;
                      }
                    }
                    else {
                      uVar4 = *(uint *)(param_3 + 8);
                      if ((int)uVar4 <= iStack_48) goto LAB_;
                      uVar16 = (uint)(ushort)(*puVar10 >> 0x20);
                      if (*(ushort *)(pbVar20 + uVar4) < uVar16) {
                        uVar4 = ~(uint)(CONCAT26(uStack_42,*puVar10) >> 0x34) & 1;
                      }
                      else {
                        uVar16 = uVar16 - 1;
                        uVar4 = pbVar20[(ulonglong)(uVar16 >> 3) + (ulonglong)uVar4 + 2] >>
                                ((byte)uVar16 & 7) & 1;
                      }
                    }
                  }
                  else {
                    uVar4 = (uint)(CONCAT26(uStack_42,uVar1) >> 0x20);
                    if ((ushort)param_3[1] < (ushort)(uVar1 >> 0x20)) {
                      uVar4 = ~(uVar4 >> 0x14) & 1;
                    }
                    else {
                      bVar2 = *(byte *)((longlong)((int)((uVar4 & 0xffff) - 1) / 2) +
                                        (ulonglong)(ushort)param_3[0xc] + *(longlong *)(param_3 + 4)
                                       );
                      bVar11 = bVar2 >> 4;
                      if ((uVar1 & 0x100000000) != 0) {
                        bVar11 = bVar2 & 0xf;
                      }
                      uVar4 = (uint)CONCAT71((int7)((ulonglong)puVar23 >> 8),bVar11 == 0);
                    }
                  }
                  if (uVar4 != 0) {
                    iVar5 = func_0x(param_3,&iStack_48);
                    if (iVar5 != 0) {
                      func_0x(param_2,param_3,&iStack_48);
                      *param_5 = 1;
                    }
                    puVar23 = (uint6 *)0x0;
                  }
                }
              }
              break;
            }
            lVar21 = *(longlong *)(param_1 + 8);
            iVar24 = iVar24 + -1;
            iVar6 = iVar6 + 1;
            puVar10 = puVar23;
          } while (iVar6 <= *(int *)(**(longlong **)(lVar21 + 0x160) + 0x14));
        }
      }
      lVar21 = *(longlong *)(param_1 + 8);
      uVar4 = (int)puVar19 + 1;
      puVar7 = puVar10;
      puVar19 = (uint6 *)(ulonglong)uVar4;
      puVar10 = puVar23;
    } while ((int)uVar4 < *(int *)(**(longlong **)(lVar21 + 0x160) + 0x14));
  }
  return;
}

