
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined2 param_2,undefined8 param_3)

{
  int iVar1;
  uint uVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined4 uVar5;
  undefined auStack_f8 [32];
  undefined8 uStack_d8;
  undefined4 auStack_c8 [2];
  undefined8 uStack_c0;
  longlong lStack_b8;
  undefined2 uStack_b0;
  undefined8 uStack_a8;
  int iStack_a0;
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  longlong lStack_58;
  uint uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  
  uStack_c0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_f8;
  uVar5 = 0x35;
  if (*(int *)(param_1 + 0x24f8) == 0x34) {
    uVar5 = 0x34;
  }
  iVar1 = func_0x(param_2,0x1a4b778);
  if (iVar1 == 0) {
    func_0x(0x4977,0x10,3,0x1a4b778);
  }
  else {
    lStack_b8 = 0;
    auStack_98 = ZEXT816(0);
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    auStack_68 = ZEXT816(0);
    lStack_58 = 0;
    uStack_50 = 0;
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_b0 = param_2;
    uStack_a8 = param_3;
    iStack_a0 = iVar1;
    iVar1 = func_0x(&lStack_b8,3,2,0);
    if (iVar1 == 0) {
      func_0x(0x49aa,0x10,7,0x1a4b778);
    }
    else {
      auStack_c8[0] = 0;
      if ((lStack_b8 != 0) && ((undefined4 *)(param_1 + 0x2510) != (undefined4 *)0x0)) {
        uVar2 = func_0x(&lStack_b8,0x17e7700,auStack_c8);
        uVar4 = (ulonglong)uVar2;
        if ((ulonglong)uVar2 == *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + lStack_58)) {
LAB_:
          if (uVar2 <= uStack_50) {
            lVar3 = (ulonglong)(uVar2 - 1) * 0x58;
            *(undefined8 *)(lStack_b8 + *(longlong *)(lVar3 + 0x10 + lStack_58)) = 4;
            *(undefined4 *)(lStack_b8 + *(longlong *)(lStack_58 + 8 + lVar3)) =
                 *(undefined4 *)(param_1 + 0x2510);
          }
        }
        else {
          uVar2 = 1;
          if (uStack_50 != 0) {
            do {
              if (uVar4 == *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + lStack_58))
              goto LAB_;
              uVar2 = uVar2 + 1;
            } while (uVar2 <= uStack_50);
          }
        }
      }
      auStack_c8[0] = 0;
      if ((lStack_b8 != 0) && (param_1 + 0x2524 != 0)) {
        uVar2 = func_0x(&lStack_b8,0x1a4b760,auStack_c8);
        uVar4 = (ulonglong)uVar2;
        if ((ulonglong)uVar2 == *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + lStack_58)) {
LAB_:
          if (uVar2 <= uStack_50) {
            lVar3 = (ulonglong)(uVar2 - 1) * 0x58;
            *(undefined8 *)(lStack_b8 + *(longlong *)(lVar3 + 0x10 + lStack_58)) = 10;
            func_0x
                      (*(longlong *)(lVar3 + 8 + lStack_58) + lStack_b8,param_1 + 0x2524,10);
          }
        }
        else {
          uVar2 = 1;
          if (uStack_50 != 0) {
            do {
              if (uVar4 == *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + lStack_58))
              goto LAB_;
              uVar2 = uVar2 + 1;
            } while (uVar2 <= uStack_50);
          }
        }
      }
      auStack_c8[0] = 0;
      if ((lStack_b8 != 0) && (param_1 + 0x252e != 0)) {
        uVar2 = func_0x(&lStack_b8,0x1a4b740,auStack_c8);
        uVar4 = (ulonglong)uVar2;
        if ((ulonglong)uVar2 == *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + lStack_58)) {
LAB_:
          if (uVar2 <= uStack_50) {
            lVar3 = (ulonglong)(uVar2 - 1) * 0x58;
            *(undefined8 *)(lStack_b8 + *(longlong *)(lVar3 + 0x10 + lStack_58)) = 10;
            func_0x
                      (*(longlong *)(lVar3 + 8 + lStack_58) + lStack_b8,param_1 + 0x252e,10);
          }
        }
        else {
          uVar2 = 1;
          if (uStack_50 != 0) {
            do {
              if (uVar4 == *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + lStack_58))
              goto LAB_;
              uVar2 = uVar2 + 1;
            } while (uVar2 <= uStack_50);
          }
        }
      }
      if (uStack_50 == 4) {
        auStack_c8[0] = 0;
        if (lStack_b8 != 0) {
          uVar2 = func_0x(&lStack_b8,0x1a4b750,auStack_c8);
          uVar4 = (ulonglong)uVar2;
          if ((ulonglong)uVar2 == *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + lStack_58)) {
LAB_:
            if (uVar2 <= uStack_50) {
              lVar3 = (ulonglong)(uVar2 - 1) * 0x58;
              *(undefined8 *)(lStack_b8 + *(longlong *)(lVar3 + 0x10 + lStack_58)) = 4;
              *(undefined4 *)(lStack_b8 + *(longlong *)(lVar3 + 8 + lStack_58)) = uVar5;
            }
          }
          else {
            uVar2 = 1;
            if (uStack_50 != 0) {
              do {
                if (uVar4 == *(ulonglong *)((ulonglong)(uVar2 - 1) * 0x58 + lStack_58))
                goto LAB_;
                uVar2 = uVar2 + 1;
              } while (uVar2 <= uStack_50);
            }
          }
        }
        uStack_d8 = auStack_c8;
        iVar1 = (**(code **)(*(longlong *)auStack_68._0_8_ + 0x28))
                          (auStack_68._0_8_,0,uStack_48,lStack_b8);
        if (iVar1 != 0) {
          uStack_d8 = (undefined4 *)CONCAT44(uStack_d8._4_4_,iVar1);
          (*_DAT_)(0xbc,2,0x10,1);
        }
      }
    }
    func_0x(&lStack_b8);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_f8);
  return;
}

