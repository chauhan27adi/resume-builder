
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int *param_2,int *param_3,int param_4,longlong param_5,
                 longlong param_6,undefined8 *param_7,undefined8 *param_8)

{
  undefined8 uVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 *puVar9;
  int iVar10;
  undefined8 *puVar11;
  ulonglong uVar12;
  undefined auStack_278 [32];
  undefined8 uStack_258;
  longlong lStack_250;
  int iStack_248;
  int iStack_244;
  int iStack_240;
  int iStack_23c;
  longlong lStack_238;
  longlong lStack_230;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined8 *puStack_210;
  longlong lStack_208;
  undefined8 uStack_200;
  undefined8 uStack_1f8;
  undefined2 uStack_1f0;
  longlong lStack_1e8;
  undefined2 uStack_1e0;
  undefined8 uStack_1d8;
  int iStack_1d0;
  undefined auStack_1c8 [16];
  undefined auStack_1b8 [16];
  undefined auStack_1a8 [16];
  undefined auStack_198 [16];
  longlong lStack_188;
  uint uStack_180;
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined auStack_168 [272];
  ulonglong uStack_58;
  
  uStack_200 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_278;
  lStack_238 = param_5;
  lStack_230 = param_6;
  puStack_210 = param_7;
  puVar11 = (undefined8 *)0x0;
  *param_2 = 0;
  *param_3 = 0;
  *param_7 = 0;
  *(undefined2 *)(param_7 + 1) = 0;
  *param_8 = 0;
  *(undefined2 *)(param_8 + 1) = 0;
  iStack_244 = param_4;
  lStack_208 = param_1;
  iVar4 = func_0x(*(undefined2 *)(param_1 + 8),0x1a31268);
  if (iVar4 == 0) {
    func_0x(0x4977,0x10,1,0x1a31268);
  }
  else {
    uStack_1d8 = *(undefined8 *)(param_1 + 0x10);
    uStack_1e0 = *(undefined2 *)(param_1 + 8);
    lStack_1e8 = 0;
    auStack_1c8 = ZEXT816(0);
    auStack_1b8 = ZEXT816(0);
    auStack_1a8 = ZEXT816(0);
    auStack_198 = ZEXT816(0);
    lStack_188 = 0;
    uStack_180 = 0;
    uStack_178 = 0;
    uStack_170 = 0;
    iStack_23c = 0;
    iStack_240 = 0;
    iStack_1d0 = iVar4;
    iVar4 = func_0x(&lStack_1e8,3,1);
    if (iVar4 == 0) {
      func_0x(0x49aa,0x10,7,0x1a31268);
    }
    else {
      lStack_250 = lStack_1e8;
      uStack_258 = uStack_178;
      iVar5 = (**(code **)(*(longlong *)auStack_1c8._8_8_ + 0x18))(auStack_1c8._8_8_,0,1);
      iVar4 = iStack_248;
      iVar10 = iStack_248;
      lVar8 = lStack_1e8;
      while (lStack_1e8 = lVar8, iVar5 == 0) {
        if (DAT_ == '\0') {
LAB_:
          uStack_224 = 0;
          if (lVar8 == 0) {
            lVar8 = 0;
            puVar9 = (undefined8 *)0x0;
LAB_:
            if (puVar11 < (undefined8 *)0x5) goto LAB_;
          }
          else {
            puVar11 = (undefined8 *)0x0;
            uVar6 = func_0x(&lStack_1e8,0x18a2d68,&uStack_224);
            uVar12 = (ulonglong)uVar6;
            lVar8 = lStack_1e8;
            if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188)) {
LAB_:
              if (uVar6 <= uStack_180) {
                lVar7 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_188;
                puVar11 = *(undefined8 **)(lStack_1e8 + *(longlong *)(lVar7 + 0x10));
                puVar9 = (undefined8 *)(*(longlong *)(lVar7 + 8) + lStack_1e8);
                goto LAB_;
              }
            }
            else {
              uVar6 = 1;
              if (uStack_180 != 0) {
                do {
                  if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                  goto LAB_;
                  uVar6 = uVar6 + 1;
                } while (uVar6 <= uStack_180);
                puVar9 = (undefined8 *)0x0;
                puVar11 = (undefined8 *)0x0;
                goto LAB_;
              }
            }
            puVar9 = (undefined8 *)0x0;
LAB_:
            func_0x(&iStack_23c,puVar9,puVar11);
          }
          if (iStack_23c == *(int *)(lStack_208 + 0x18)) {
            lVar7 = 0;
            uStack_220 = 0;
            if (lVar8 == 0) {
              lVar8 = 0;
            }
            else {
              puVar11 = (undefined8 *)0x0;
              uVar6 = func_0x(&lStack_1e8,0x17cf8d8,&uStack_220);
              uVar12 = (ulonglong)uVar6;
              lVar8 = lStack_1e8;
              if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188)) {
LAB_:
                if (uStack_180 < uVar6) {
LAB_:
                  lVar7 = 0;
                }
                else {
                  lVar7 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_188;
                  puVar11 = *(undefined8 **)(lStack_1e8 + *(longlong *)(lVar7 + 0x10));
                  lVar7 = *(longlong *)(lVar7 + 8) + lStack_1e8;
                }
              }
              else {
                uVar6 = 1;
                if (uStack_180 == 0) goto LAB_;
                do {
                  if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                  goto LAB_;
                  uVar6 = uVar6 + 1;
                } while (uVar6 <= uStack_180);
                lVar7 = 0;
              }
            }
            if (*param_2 == 0) {
              if (puVar11 < (undefined8 *)0x5) {
                func_0x(param_2,lVar7,puVar11);
              }
              lVar7 = 0;
              uStack_21c = 0;
              if (lVar8 != 0) {
                puVar11 = (undefined8 *)0x0;
                uVar6 = func_0x(&lStack_1e8,0x1a31218,&uStack_21c);
                uVar12 = (ulonglong)uVar6;
                lVar8 = lStack_1e8;
                if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                {
LAB_:
                  if (uVar6 <= uStack_180) {
                    lVar7 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_188;
                    puVar11 = *(undefined8 **)(lStack_1e8 + *(longlong *)(lVar7 + 0x10));
                    lVar7 = *(longlong *)(lVar7 + 8) + lStack_1e8;
                  }
                }
                else {
                  uVar6 = 1;
                  if (uStack_180 != 0) {
                    do {
                      if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                      goto LAB_;
                      uVar6 = uVar6 + 1;
                    } while (uVar6 <= uStack_180);
                  }
                }
              }
              iVar4 = (int)puVar11;
              if (iStack_244 + -2 < (int)puVar11) {
                iVar4 = iStack_244 + -2;
              }
              func_0x(lStack_238,lVar7,(longlong)iVar4);
              iVar5 = iVar4;
              if (iVar4 < 0) {
                iVar5 = iVar4 + 1;
              }
              puVar9 = (undefined8 *)0x0;
              *(undefined2 *)(lStack_238 + (longlong)(iVar5 >> 1) * 2) = 0;
              uStack_218 = 0;
              if (lVar8 == 0) {
                lVar8 = 0;
LAB_:
                if (puVar11 == (undefined8 *)0xa) {
                  uVar1 = *puVar9;
                  uVar2 = *(undefined2 *)(puVar9 + 1);
                  uStack_1f8._0_1_ = (undefined)uVar1;
                  uStack_1f8._1_1_ = (undefined)((ulonglong)uVar1 >> 8);
                  uStack_1f8._2_1_ = (undefined)((ulonglong)uVar1 >> 0x10);
                  uStack_1f8._3_1_ = (undefined)((ulonglong)uVar1 >> 0x18);
                  uStack_1f8._4_1_ = (undefined)((ulonglong)uVar1 >> 0x20);
                  uStack_1f8._5_1_ = (undefined)((ulonglong)uVar1 >> 0x28);
                  uStack_1f8._6_1_ = (undefined)((ulonglong)uVar1 >> 0x30);
                  uStack_1f8._7_1_ = (undefined)((ulonglong)uVar1 >> 0x38);
                  uStack_1f0._0_1_ = (undefined)uVar2;
                  uStack_1f0._1_1_ = (undefined)((ushort)uVar2 >> 8);
                  *(uint *)puStack_210 =
                       CONCAT31(CONCAT21(CONCAT11((undefined)uStack_1f8,uStack_1f8._1_1_),
                                         uStack_1f8._2_1_),uStack_1f8._3_1_);
                  *(uint *)((longlong)puStack_210 + 4) =
                       CONCAT31(CONCAT21(CONCAT11(uStack_1f8._4_1_,uStack_1f8._5_1_),
                                         uStack_1f8._6_1_),uStack_1f8._7_1_);
                  *(ushort *)(puStack_210 + 1) = CONCAT11((undefined)uStack_1f0,uStack_1f0._1_1_);
                  uStack_1f8 = uVar1;
                  uStack_1f0 = uVar2;
                }
              }
              else {
                uVar6 = func_0x(&lStack_1e8,0x18a1a90,&uStack_218);
                uVar12 = (ulonglong)uVar6;
                if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                {
LAB_:
                  if (uVar6 <= uStack_180) {
                    lVar8 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_188;
                    puVar11 = *(undefined8 **)(lStack_1e8 + *(longlong *)(lVar8 + 0x10));
                    puVar9 = (undefined8 *)(*(longlong *)(lVar8 + 8) + lStack_1e8);
                    lVar8 = lStack_1e8;
                    goto LAB_;
                  }
                }
                else {
                  uVar6 = 1;
                  if (uStack_180 != 0) {
                    do {
                      if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                      goto LAB_;
                      uVar6 = uVar6 + 1;
                      lVar8 = lStack_1e8;
                      puVar11 = puVar9;
                    } while (uVar6 <= uStack_180);
                    goto LAB_;
                  }
                }
LAB_:
                lVar8 = lStack_1e8;
                puVar11 = (undefined8 *)0x0;
              }
            }
            else {
              iVar5 = *param_3;
              if (iVar5 != 0) goto LAB_;
              if (puVar11 < (undefined8 *)0x5) {
                func_0x(param_3,lVar7,puVar11);
              }
              lVar7 = 0;
              uStack_214 = 0;
              if (lVar8 != 0) {
                puVar11 = (undefined8 *)0x0;
                uVar6 = func_0x(&lStack_1e8,0x1a31218,&uStack_214);
                uVar12 = (ulonglong)uVar6;
                lVar8 = lStack_1e8;
                if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188)) {
LAB_:
                  if (uVar6 <= uStack_180) {
                    lVar7 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_188;
                    puVar11 = *(undefined8 **)(lStack_1e8 + *(longlong *)(lVar7 + 0x10));
                    lVar7 = *(longlong *)(lVar7 + 8) + lStack_1e8;
                  }
                }
                else {
                  uVar6 = 1;
                  if (uStack_180 != 0) {
                    do {
                      if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                      goto LAB_;
                      uVar6 = uVar6 + 1;
                    } while (uVar6 <= uStack_180);
                  }
                }
              }
              iVar10 = (int)puVar11;
              if (iStack_244 + -2 < (int)puVar11) {
                iVar10 = iStack_244 + -2;
              }
              func_0x(lStack_230,lVar7,(longlong)iVar10);
              iVar5 = iVar10;
              if (iVar10 < 0) {
                iVar5 = iVar10 + 1;
              }
              puVar9 = (undefined8 *)0x0;
              *(undefined2 *)(lStack_230 + (longlong)(iVar5 >> 1) * 2) = 0;
              iStack_248 = 0;
              if (lVar8 != 0) {
                uVar6 = func_0x(&lStack_1e8,0x18a1a90,&iStack_248);
                uVar12 = (ulonglong)uVar6;
                if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                {
LAB_:
                  if (uVar6 <= uStack_180) {
                    lVar8 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_188;
                    puVar11 = *(undefined8 **)(lStack_1e8 + *(longlong *)(lVar8 + 0x10));
                    puVar9 = (undefined8 *)(*(longlong *)(lVar8 + 8) + lStack_1e8);
                    lVar8 = lStack_1e8;
                    goto LAB_;
                  }
                }
                else {
                  uVar6 = 1;
                  if (uStack_180 != 0) {
                    do {
                      if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                      goto LAB_;
                      uVar6 = uVar6 + 1;
                      lVar8 = lStack_1e8;
                      puVar11 = (undefined8 *)0x0;
                    } while (uVar6 <= uStack_180);
                    goto LAB_;
                  }
                }
                goto LAB_;
              }
              lVar8 = 0;
LAB_:
              if (puVar11 == (undefined8 *)0xa) {
                uVar1 = *puVar9;
                uVar2 = *(undefined2 *)(puVar9 + 1);
                uStack_1f8._0_1_ = (undefined)uVar1;
                uStack_1f8._1_1_ = (undefined)((ulonglong)uVar1 >> 8);
                uStack_1f8._2_1_ = (undefined)((ulonglong)uVar1 >> 0x10);
                uStack_1f8._3_1_ = (undefined)((ulonglong)uVar1 >> 0x18);
                uStack_1f8._4_1_ = (undefined)((ulonglong)uVar1 >> 0x20);
                uStack_1f8._5_1_ = (undefined)((ulonglong)uVar1 >> 0x28);
                uStack_1f8._6_1_ = (undefined)((ulonglong)uVar1 >> 0x30);
                uStack_1f8._7_1_ = (undefined)((ulonglong)uVar1 >> 0x38);
                uStack_1f0._0_1_ = (undefined)uVar2;
                uStack_1f0._1_1_ = (undefined)((ushort)uVar2 >> 8);
                *(uint *)param_8 =
                     CONCAT31(CONCAT21(CONCAT11((undefined)uStack_1f8,uStack_1f8._1_1_),
                                       uStack_1f8._2_1_),uStack_1f8._3_1_);
                *(uint *)((longlong)param_8 + 4) =
                     CONCAT31(CONCAT21(CONCAT11(uStack_1f8._4_1_,uStack_1f8._5_1_),uStack_1f8._6_1_)
                              ,uStack_1f8._7_1_);
                *(ushort *)(param_8 + 1) = CONCAT11((undefined)uStack_1f0,uStack_1f0._1_1_);
                uStack_1f8 = uVar1;
                uStack_1f0 = uVar2;
              }
            }
          }
        }
        else {
          uStack_228 = 0;
          puVar9 = (undefined8 *)0x0;
          if (lVar8 == 0) {
LAB_:
            lVar8 = lStack_1e8;
            if (puVar11 < (undefined8 *)0x5) goto LAB_;
          }
          else {
            puVar11 = (undefined8 *)0x0;
            uVar6 = func_0x(&lStack_1e8,0x1a31200,&uStack_228);
            uVar12 = (ulonglong)uVar6;
            if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188)) {
LAB_:
              if (uVar6 <= uStack_180) {
                lVar8 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_188;
                puVar11 = *(undefined8 **)(lStack_1e8 + *(longlong *)(lVar8 + 0x10));
                puVar9 = (undefined8 *)(*(longlong *)(lVar8 + 8) + lStack_1e8);
                goto LAB_;
              }
            }
            else {
              uVar6 = 1;
              if (uStack_180 != 0) {
                do {
                  if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_188))
                  goto LAB_;
                  uVar6 = uVar6 + 1;
                } while (uVar6 <= uStack_180);
                puVar9 = (undefined8 *)0x0;
                puVar11 = (undefined8 *)0x0;
                goto LAB_;
              }
            }
            puVar9 = (undefined8 *)0x0;
LAB_:
            lVar8 = lStack_1e8;
            func_0x(&iStack_240,puVar9,puVar11);
          }
          if (iStack_240 != 0) goto LAB_;
        }
LAB_:
        uStack_258 = uStack_178;
        lStack_250 = lVar8;
        iVar5 = (**(code **)(*(longlong *)auStack_1c8._8_8_ + 0x18))(auStack_1c8._8_8_,0,1);
        lVar8 = lStack_1e8;
      }
      iVar5 = *param_3;
      if (iVar5 != 0) {
LAB_:
        lVar8 = lStack_238;
        iVar3 = *param_2;
        if (iVar5 < iVar3) {
          *param_2 = iVar5;
          *param_3 = iVar3;
          iVar4 = iVar4 + 2;
          if (iVar4 < 0x82) {
            func_0x(auStack_168,lStack_238,(longlong)iVar4);
          }
          lVar7 = lStack_230;
          iVar5 = iStack_244;
          if (iVar10 + 2 <= iStack_244) {
            func_0x(lVar8,lStack_230,(longlong)(iVar10 + 2));
          }
          if (iVar4 <= iVar5) {
            func_0x(lVar7,auStack_168,(longlong)iVar4);
          }
          uStack_1f8 = *puStack_210;
          uVar2 = *(undefined2 *)(puStack_210 + 1);
          *puStack_210 = *param_8;
          *(undefined4 *)(puStack_210 + 1) = *(undefined4 *)(param_8 + 1);
          *(undefined4 *)param_8 = (undefined4)uStack_1f8;
          *(int *)((longlong)param_8 + 4) = (int)((ulonglong)uStack_1f8 >> 0x20);
          *(undefined2 *)(param_8 + 1) = uVar2;
        }
      }
    }
    func_0x(&lStack_1e8);
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_278);
  return;
}

