
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,longlong param_2,undefined8 param_3,int param_4,
                 undefined8 param_5,undefined8 param_6)

{
  byte *pbVar1;
  byte *pbVar2;
  longlong lVar3;
  longlong lVar4;
  undefined auVar5 [16];
  char cVar6;
  longlong lVar7;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar8;
  undefined8 auStack_3c0 [13];
  undefined auStack_358 [8];
  longlong lStack_350;
  undefined2 uStack_348;
  undefined4 uStack_344;
  undefined8 uStack_340;
  undefined8 uStack_338;
  undefined8 uStack_32a;
  undefined8 uStack_320;
  undefined8 uStack_310;
  undefined4 uStack_308;
  undefined uStack_300;
  int iStack_2fc;
  longlong **pplStack_2f0;
  undefined4 uStack_2dc;
  undefined2 uStack_2d8;
  undefined8 uStack_2c8;
  undefined2 uStack_2c0;
  undefined *puStack_290;
  undefined8 uStack_288;
  undefined8 uStack_280;
  longlong lStack_278;
  undefined auStack_270 [16];
  undefined2 uStack_240;
  undefined4 uStack_23c;
  byte *pbStack_238;
  undefined8 uStack_230;
  undefined8 uStack_222;
  undefined2 uStack_21a;
  undefined2 uStack_218;
  undefined6 uStack_216;
  int iStack_20c;
  undefined auStack_208 [16];
  undefined auStack_1f8 [2];
  undefined auStack_1f6 [14];
  undefined8 uStack_1e8;
  undefined6 uStack_1e0;
  undefined2 uStack_1da;
  undefined6 uStack_1d8;
  undefined2 uStack_1d2;
  undefined2 uStack_1d0;
  undefined6 uStack_1ce;
  undefined8 uStack_1c8;
  short *psStack_1c0;
  short *psStack_1b8;
  short sStack_1b0;
  undefined6 uStack_1ae;
  undefined auStack_1a8 [10];
  undefined auStack_19e [6];
  undefined8 uStack_198;
  undefined2 uStack_190;
  undefined4 uStack_18c;
  undefined8 uStack_188;
  undefined8 uStack_180;
  undefined8 uStack_172;
  undefined8 uStack_168;
  undefined8 uStack_158;
  undefined4 uStack_150;
  undefined8 uStack_138;
  undefined4 uStack_130;
  undefined2 uStack_12c;
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_358;
  uStack_288 = param_6;
  lVar3 = **param_1;
  lStack_278 = (ulonglong)*(uint6 *)(param_2 + 0x14) << 0x10;
  uStack_240 = 0xffff;
  uStack_138 = 0;
  uStack_348 = 0xffff;
  uStack_310 = 0;
  uStack_130 = 0;
  uStack_12c = 0;
  uStack_340 = 0;
  uStack_344 = 0;
  uStack_32a = 0;
  uStack_320 = 0;
  uStack_338 = 0;
  auStack_270 = ZEXT816(0);
  auStack_358[0] = 0;
  uStack_300 = 0;
  auStack_3c0[0] = 0x1000c6;
  lStack_350 = param_2;
  iStack_2fc = param_4;
  pplStack_2f0 = param_1;
  uStack_280 = param_3;
  iStack_20c = param_4;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  pbStack_238 = (byte *)0x0;
  uStack_23c = 0;
  puStack_290 = auStack_358 + lVar7;
  uStack_222 = 0;
  uStack_218 = 0;
  uStack_216 = 0;
  uStack_230 = 0;
  uStack_188 = 0;
  uStack_18c = 0;
  uStack_172 = 0;
  uStack_168 = 0;
  uStack_180 = 0;
  uStack_158 = 0;
  uStack_150 = 0;
  uStack_310 = CONCAT44(uStack_310._4_4_,9);
  uStack_190 = uStack_240;
  if (-1 < *(char *)(lVar3 + 2)) goto LAB_;
  pbVar1 = (byte *)(lVar3 + 0x60);
  uStack_1e0 = 0;
  auStack_1f6 = SUB1614(ZEXT816(0),2);
  auStack_1f8 = (undefined  [2])uStack_240;
  uStack_1d2 = 0;
  auStack_1f6._6_8_ = 0;
  uStack_1c8 = 0;
  uStack_1da = 0;
  uStack_1d8 = 0;
  uStack_1d0 = 0;
  uStack_1ce = 0;
  uStack_1e8 = 0;
  psStack_1c0 = (short *)0x0;
  _auStack_1a8 = ZEXT812(0);
  auStack_19e._2_4_ = 0;
  uStack_198 = 0;
  psStack_1b8 = (short *)0x0;
  sStack_1b0 = 0;
  uStack_1ae = 0;
  auStack_208 = ZEXT816(0);
  lVar4 = 0;
  if (*(short *)(lVar3 + 0x24) == 0) {
LAB_:
    auStack_208._8_8_ = lVar4;
    uStack_2c8 = *(undefined8 *)(lVar3 + 0x28);
    uStack_2c0 = *(undefined2 *)(lVar3 + 0x30);
  }
  else {
    cVar6 = *(char *)(lVar3 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(lVar3 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar3 + 0x18) != 99) goto LAB_;
    }
    uStack_2dc = *(undefined4 *)(lVar3 + 0x20);
    uStack_2d8 = *(undefined2 *)(lVar3 + 0x24);
    *(undefined8 *)((longlong)auStack_3c0 + lVar7) = 0x10023d;
    cVar6 = func_0x(&uStack_2dc,0x16319e8);
    lVar4 = auStack_208._8_8_;
    if (cVar6 == '\0') goto LAB_;
    *(undefined8 *)((longlong)auStack_3c0 + lVar7) = 0x100250;
    func_0x(lVar3,&uStack_2c8);
  }
  lVar4 = auStack_208._8_8_;
  auStack_208._0_8_ = pbVar1;
  auStack_1a8._8_2_ = uStack_2c0;
  auStack_1a8._0_8_ = uStack_2c8;
  auStack_19e._2_4_ = *(undefined4 *)(lVar3 + 0x20);
  uStack_1da = 0;
  uStack_1d8 = 0;
  uStack_1d0 = 0;
  uStack_1ce = 0;
  uStack_308 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x16b1ff0);
  uVar8 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x16b1ff4);
  auStack_1f6._6_8_ = 0;
  auStack_1f6._0_6_ = (uint6)(_auStack_1f8 >> 0x10) & 0xffff;
  auStack_1f8 = (undefined  [2])0xffff;
  uStack_1e8 = 0;
  psStack_1c0 = (short *)0x0;
  psStack_1b8 = (short *)0x0;
  sStack_1b0 = 0;
  if ((*pbVar1 & 2) != 0) {
    pbVar2 = pbVar1 + uVar8;
    auStack_1f6._6_8_ = pbVar2;
    if ((pbVar1[uVar8] & 1) == 0) {
      auVar5._14_2_ = 0;
      auVar5._0_14_ = auStack_1f6;
      _auStack_1f8 = auVar5 << 0x10;
      uStack_1d2 = 0;
      uStack_1d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010050d */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x102bf0) - 0xe87e40))();
      return;
    }
    auStack_1f8 = (undefined  [2])0x1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x102bd0) * 4 +
                           0x102bc0) - 0xe87e40);
                    /* WARNING: Could not emulate address calculation at 0x00100355 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar1 & 4) != 0) {
    uStack_308._2_2_ = (short)((uint)uStack_308 >> 0x10);
    if (uStack_308._2_2_ != 0) {
      uVar8 = (ulonglong)*(ushort *)(lVar3 + 0x61 + (longlong)uStack_308._2_2_ * 2);
    }
    psStack_1c0 = (short *)(pbVar1 + uVar8);
    psStack_1b8 = psStack_1c0 + 1;
    sStack_1b0 = (*psStack_1c0 + 1) * 2;
  }
  if (auStack_208._8_8_ != 0) {
    *(undefined8 *)((longlong)auStack_3c0 + lVar7) = 0x1005e4;
    func_0x(lVar4,auStack_208);
  }
LAB_:
  pbStack_238 = (byte *)((ulonglong)*(ushort *)(lVar3 + (0xfff - (longlong)iStack_2fc) * 2) + lVar3)
  ;
  if ((*pbStack_238 & 1) == 0) {
    uStack_240 = 0;
    uStack_23c = 0;
    uStack_21a = 0;
    uStack_218 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100865 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_238 & 0xe) * 4 + 0x102c60) - 0xe87e40))
              ((longlong)(int)(*pbStack_238 & 0xe),0x16319e8,pbStack_238,9);
    return;
  }
  uStack_240 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_238 & 0x1c) + 0x102c40) * 4
                         + 0x102c30) - 0xe87e40);
                    /* WARNING: Could not emulate address calculation at 0x00100646 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

