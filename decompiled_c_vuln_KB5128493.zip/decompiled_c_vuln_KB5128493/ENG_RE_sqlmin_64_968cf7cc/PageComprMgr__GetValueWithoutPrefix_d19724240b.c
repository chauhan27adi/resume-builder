
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ushort * FUN_(byte **param_1,undefined (*param_2) [16],ushort *param_3,int param_4,
                     byte param_5,uint *param_6,int *param_7)

{
  ushort *puVar1;
  longlong lVar2;
  longlong *plVar3;
  int *piVar4;
  byte bVar5;
  int iVar6;
  byte *pbVar7;
  ulonglong *puVar8;
  byte *pbVar9;
  uint uVar10;
  ushort uVar11;
  short sVar12;
  int iVar13;
  ulonglong uVar14;
  byte *pbVar15;
  ushort uVar16;
  uint uVar17;
  ushort *puVar18;
  uint *puVar19;
  longlong unaff_GS_OFFSET;
  undefined auStack_38 [6];
  byte bStack_32;
  longlong lStack_30;
  
  piVar4 = param_7;
  puVar19 = param_6;
  pbVar15 = (byte *)0x0;
  *param_6 = 0;
  *param_7 = param_4;
  if ((param_3 == (ushort *)0x0) || (param_3 == (ushort *)0x14a4dd4)) {
    *param_7 = 0;
    return (ushort *)0x0;
  }
  if ((param_5 & 4) != 0) {
    bVar5 = *(byte *)param_3;
    puVar1 = (ushort *)param_1[10];
    if (bVar5 == 0) {
      param_3 = (ushort *)(param_1[9] + (uint)*(ushort *)(param_1 + 0xb));
      iVar13 = (uint)*puVar1 - (uint)*(ushort *)(param_1 + 0xb);
    }
    else {
      param_3 = (ushort *)(param_1[9] + (uint)puVar1[(ulonglong)bVar5 - 1]);
      iVar13 = (uint)puVar1[bVar5] - (uint)puVar1[(ulonglong)bVar5 - 1];
    }
    *param_7 = iVar13;
  }
  if ((**param_1 & 2) == 0) {
    return param_3;
  }
  _auStack_38 = *param_2;
  uVar16 = SUB162(_auStack_38,6);
  if ((SUB168(_auStack_38,0) >> 0x30 & 0x10) != 0) {
    uVar16 = uVar16 & 0xffef;
    _auStack_38 = SUB168(_auStack_38,0) & 0xffefffffffffffff;
    lStack_30 = 0;
  }
  if (param_1[1] != (byte *)0x0) {
    pbVar7 = (byte *)func_0x(param_1[1] + 0x18,auStack_38,&param_7);
    goto LAB_;
  }
  puVar1 = (ushort *)((longlong)param_1 + 0x12);
  if (*(short *)(param_1 + 2) != 0) {
    param_6._0_4_ = 0;
    pbVar9 = (byte *)func_0x(puVar1,auStack_38,uVar16,&param_7,&param_6);
    pbVar7 = pbVar9;
    if (((((*(short *)(param_1 + 2) != 0) &&
          (plVar3 = (longlong *)param_1[4], plVar3 != (longlong *)0x0)) && (*plVar3 != 0)) &&
        (((_auStack_38 & (undefined  [16])0x8000000000000) == (undefined  [16])0x0 &&
         (((uint)param_6 & 1) == 0)))) &&
       ((pbVar7 = pbVar15, pbVar9 != (byte *)0x0 && (pbVar9 != (byte *)0x14a4dd4)))) {
      pbVar7 = (byte *)func_0x
                                 (plVar3,auStack_38,pbVar9,param_7._0_4_,0,0,&param_7,(uint)param_6)
      ;
    }
    goto LAB_;
  }
  if ((auStack_38._0_4_ & 0xc0000000) == 0x80000000) {
    iVar13 = func_0x(puVar1);
    pbVar7 = (byte *)0x0;
    if (iVar13 != 0) {
      pbVar7 = (byte *)func_0x((longlong)param_1 + 0x3a,auStack_38,&param_7,&param_6);
    }
    goto LAB_;
  }
  pbVar9 = param_1[3];
  bVar5 = *pbVar9;
  iVar13 = 0;
  if ((bVar5 & 0x10) == 0) {
    if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
      uVar16 = ~(uVar16 >> 4);
      iVar6 = 0;
      goto LAB_;
    }
  }
  else {
    uVar10 = *(uint *)(param_1 + 4);
    iVar6 = iVar13;
    if ((int)auStack_38._0_4_ < (int)uVar10) {
      if ((uint)*(ushort *)(pbVar9 + uVar10) < (uint)(ushort)auStack_38._4_2_) {
        uVar16 = ~(uVar16 >> 4);
      }
      else {
        uVar17 = (ushort)auStack_38._4_2_ - 1;
        iVar6 = 1;
        uVar16 = (ushort)(pbVar9[(ulonglong)(uVar17 >> 3) + (ulonglong)uVar10 + 2] >>
                         ((byte)uVar17 & 7));
      }
    }
    else {
      uVar16 = ~(uVar16 >> 4);
    }
LAB_:
    pbVar7 = pbVar15;
    if ((uVar16 & 1) != 0) goto LAB_;
    if ((iVar6 == 0) && ((_auStack_38 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0))
    {
      pbVar7 = (byte *)(lStack_30 + 4);
      goto LAB_;
    }
  }
  if ((int)auStack_38._0_4_ < 0) {
    if (*(int *)((longlong)param_1 + 0x14) == 0) {
      uVar10 = *(uint *)(param_1 + 4);
      uVar14 = (ulonglong)uVar10;
      *(uint *)((longlong)param_1 + 0x24) = uVar10;
      *puVar1 = 0;
      bVar5 = *pbVar9;
      if ((bVar5 & 0x10) != 0) {
        uVar10 = uVar10 + 2 + (*(ushort *)(pbVar9 + uVar14) + 7 >> 3);
        uVar14 = (ulonglong)uVar10;
        *(uint *)((longlong)param_1 + 0x24) = uVar10;
        bVar5 = *pbVar9;
      }
      if ((bVar5 & 0x20) == 0) {
        *(int *)((longlong)param_1 + 0x14) = (int)uVar14;
        *(undefined2 *)((longlong)param_1 + 0x2c) = 0;
        *(int *)(param_1 + 5) = (int)uVar14;
      }
      else {
        puVar18 = (ushort *)(pbVar9 + uVar14);
        uVar16 = *puVar18;
        *(ushort *)((longlong)param_1 + 0x2c) = uVar16;
        if (uVar16 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar2 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar2 != 0)) &&
             ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 && (*(char *)(lVar2 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x1720398,0x1840068,0x80f,0);
            }
          }
          func_0x(param_1[3],3);
          uVar16 = *(ushort *)((longlong)param_1 + 0x2c);
          uVar14 = (ulonglong)*(uint *)((longlong)param_1 + 0x24);
        }
        uVar10 = (int)uVar14 + (uVar16 + 1) * 2;
        *(uint *)(param_1 + 5) = uVar10;
        if (0x1f9e < uVar10) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar2 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar2 != 0 &&
              ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 &&
               (*(char *)(lVar2 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x1720398,0x1840068,0x816,0);
            }
          }
          func_0x(param_1[3],4);
          uVar16 = *(ushort *)((longlong)param_1 + 0x2c);
          uVar10 = *(uint *)(param_1 + 5);
        }
        uVar14 = (ulonglong)uVar16;
        uVar16 = puVar18[uVar14];
        *(uint *)((longlong)param_1 + 0x14) = uVar16 & 0x7fff;
        if ((uVar16 & 0x7fff) < uVar10) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar2 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar2 != 0)) &&
             ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 && (*(char *)(lVar2 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x1720398,0x1840068,0x81d,0);
            }
          }
          func_0x(param_1[3],4);
          uVar14 = (ulonglong)*(ushort *)((longlong)param_1 + 0x2c);
        }
        if ((short)puVar18[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
          pbVar15 = param_1[3];
          do {
            if ((int)uVar14 == 1) {
              uVar10 = *(uint *)(param_1 + 5);
              uVar17 = uVar10;
LAB_:
              if ((*(ushort *)
                    (pbVar15 + uVar14 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x24)) & 0x7fff
                  ) < uVar10) goto LAB_;
            }
            else {
              uVar17 = *(uint *)(param_1 + 5);
              uVar10 = *(ushort *)
                        (pbVar15 + uVar14 * 2 + ((ulonglong)*(uint *)((longlong)param_1 + 0x24) - 2)
                        ) & 0x7fff;
              if (uVar17 <= uVar10) goto LAB_;
LAB_:
              func_0x(pbVar15,7);
              uVar17 = *(uint *)(param_1 + 5);
            }
            if ((uVar10 < uVar17) || (*(uint *)((longlong)param_1 + 0x14) < uVar10))
            goto LAB_;
            pbVar15 = param_1[3];
            if (*(ushort *)(pbVar15 + uVar10) == 5) {
              *puVar1 = *puVar1 | 2;
              *(short *)((longlong)param_1 + 0x2c) = *(short *)((longlong)param_1 + 0x2c) + -1;
              uVar16 = *(ushort *)((longlong)param_1 + 0x3c) & 0xc7ff;
              uVar17 = uVar10 & 0xffff;
              *(short *)((longlong)param_1 + 0x3a) = (short)uVar10;
              pbVar15 = param_1[3];
              if ((*(ushort *)(pbVar15 + (ulonglong)uVar17 + 2) & 0x4000) != 0) {
                uVar16 = *(ushort *)(pbVar15 + (ulonglong)uVar17 + 2) & 0x3800 | uVar16;
              }
              *(ushort *)((longlong)param_1 + 0x3c) = uVar16;
              *(ushort *)((longlong)param_1 + 0x3c) =
                   (uVar16 ^ *(ushort *)(pbVar15 + (ulonglong)uVar17 + 2)) & 0x7ff ^ uVar16;
              break;
            }
            if (*(ushort *)(pbVar15 + uVar10) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar16 = *(short *)((longlong)param_1 + 0x2c) - 1;
            *(ushort *)((longlong)param_1 + 0x2c) = uVar16;
            if ((uVar16 == 0) ||
               (uVar14 = (ulonglong)uVar16, -1 < (short)puVar18[(ulonglong)(uVar16 - 1) + 1]))
            goto LAB_;
          } while( true );
        }
        uVar14 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
      }
      goto LAB_;
    }
    goto LAB_;
  }
  if ((_auStack_38 & (undefined  [16])0x8000000000000) != (undefined  [16])0x0) {
    pbVar7 = (byte *)0x14a4dd4;
    if ((pbVar9[(int)auStack_38._0_4_] & (byte)(1 << (bStack_32 & 7))) == 0) {
      pbVar7 = (byte *)0x14a53f8;
    }
    goto LAB_;
  }
  if ((_auStack_38 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
    if ((bVar5 & 0x10) == 0) {
      if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) goto LAB_;
    }
    else {
      if ((int)*(uint *)(param_1 + 4) <= (int)auStack_38._0_4_) goto LAB_;
      if (*(ushort *)(pbVar9 + *(uint *)(param_1 + 4)) < (ushort)auStack_38._4_2_) {
        pbVar7 = (byte *)(lStack_30 + 4);
        goto LAB_;
      }
    }
  }
  pbVar7 = pbVar9 + (int)auStack_38._0_4_;
LAB_:
  puVar19 = (uint *)CONCAT44(param_6._4_4_,(uint)param_6);
  goto LAB_;
LAB_:
  uVar14 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
LAB_:
  if ((*param_1[3] & 0x40) == 0) {
    *(undefined4 *)((longlong)param_1 + 0x36) = 0;
  }
  else {
    *(int *)((longlong)param_1 + 0x36) = (int)uVar14;
    *(int *)((longlong)param_1 + 0x14) = (int)uVar14 + 0xe;
    puVar8 = (ulonglong *)func_0x(puVar1);
    uVar14 = *puVar8;
    uVar11 = (ushort)(uVar14 >> 0x30);
    uVar16 = uVar11;
    if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
      uVar16 = uVar11 & 0xdfff;
      if ((uVar14 & 0x4000000000000000) != 0) {
        uVar16 = uVar11 | 0x2000;
      }
    }
    if (uVar16 == 0xfffc) {
      iVar13 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)((longlong)param_1 + 0x14) = *(int *)((longlong)param_1 + 0x14) + iVar13;
    uVar14 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
  }
  iVar13 = (int)uVar14;
  if ((*(byte **)((longlong)param_1 + 0x2e) != (byte *)0x0) &&
     (*(byte **)((longlong)param_1 + 0x2e) < param_1[3] + uVar14)) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar2 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar2 != 0 &&
         (lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0)) && (*(char *)(lVar2 + 0x499) != '\0'))))
    {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x1720398,0x1840068,0x877,0);
      }
    }
    func_0x(param_1[3],0x12);
    iVar13 = *(int *)((longlong)param_1 + 0x14);
  }
  if (0x3f3b < iVar13 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar2 = *(longlong *)
                  (*(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                  (ulonglong)*_DAT_), lVar2 != 0 &&
        ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 && (*(char *)(lVar2 + 0x499) != '\0'))))))
    {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x1720398,0x1840068,0x87c,0);
      }
    }
    func_0x(param_1[3],5);
  }
LAB_:
  sVar12 = -auStack_38._0_2_;
  if ((_auStack_38 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
    bVar5 = *param_1[3];
    if ((bVar5 & 0x10) == 0) {
      if ((1 << (bVar5 & 0xe) & 0x1105U) == 0) goto LAB_;
    }
    else if (((int)auStack_38._0_4_ < (int)*(uint *)(param_1 + 4)) &&
            ((ushort)auStack_38._4_2_ <= *(ushort *)(param_1[3] + *(uint *)(param_1 + 4))))
    goto LAB_;
LAB_:
    puVar19 = (uint *)CONCAT44(param_6._4_4_,(uint)param_6);
    pbVar7 = (byte *)(lStack_30 + 4);
    goto LAB_;
  }
LAB_:
  pbVar7 = param_1[3];
  if ((uint)*(ushort *)((longlong)param_1 + 0x2c) < (uint)(int)sVar12) goto LAB_;
  if (sVar12 == 1) {
    uVar10 = *(uint *)(param_1 + 5);
LAB_:
    if ((*(ushort *)(pbVar7 + (longlong)sVar12 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x24))
        & 0x7fff) < uVar10) goto LAB_;
  }
  else {
    uVar10 = *(ushort *)
              (pbVar7 + (longlong)sVar12 * 2 + ((ulonglong)*(uint *)((longlong)param_1 + 0x24) - 2))
             & 0x7fff;
    if (*(uint *)(param_1 + 5) <= uVar10) goto LAB_;
LAB_:
    func_0x(pbVar7,7);
    pbVar7 = param_1[3];
  }
  puVar19 = (uint *)CONCAT44(param_6._4_4_,(uint)param_6);
  pbVar7 = pbVar7 + uVar10;
LAB_:
  if ((pbVar7 != (byte *)0x0) && (param_4 != 0)) {
    bVar5 = *(byte *)param_3;
    iVar13 = *piVar4;
    if ((char)bVar5 < '\0') {
      uVar16 = *param_3;
      param_3 = param_3 + 1;
      uVar10 = (uVar16 & 0x7f) << 8 | (uint)(uVar16 >> 8);
      *puVar19 = uVar10;
      *piVar4 = iVar13 + -2 + uVar10;
    }
    else {
      *puVar19 = (uint)bVar5;
      param_3 = (ushort *)((longlong)param_3 + 1);
      *piVar4 = (uint)bVar5 + iVar13 + -1;
    }
  }
  return param_3;
}

