
undefined8 FUN_(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  longlong *plVar3;
  bool bVar4;
  undefined2 uVar5;
  short sVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  byte bVar12;
  undefined8 uVar13;
  undefined8 uStackX_8;
  undefined8 uStackX_18;
  undefined8 uStackX_20;
  longlong in_stack_ffffffffffffff78;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined4 auStack_58 [2];
  ulonglong uStack_50;
  undefined8 uStack_48;
  undefined4 uStack_40;
  
  bVar4 = true;
LAB_:
  lVar1 = ***(longlong ***)(param_1 + 0x40);
  if (bVar4) {
    uVar10 = (**(code **)(lVar1 + 0xa0))();
  }
  else {
    uVar10 = (**(code **)(lVar1 + 0x98))(**(longlong ***)(param_1 + 0x40),param_2,param_3);
  }
  if ((int)uVar10 != 0) {
    return uVar10;
  }
  auStack_58[0] = 3;
  uStack_50 = 0;
  uStack_48 = 0;
  uStack_40 = 0;
  (**(code **)(*(longlong *)(param_1 + 0x78) + 8))(param_2,*(longlong *)(param_1 + 0x78),auStack_58)
  ;
  uVar7 = (undefined4)((ulonglong)in_stack_ffffffffffffff78 >> 0x20);
  if ((char)auStack_58[0] == '\x03') {
    return 0;
  }
  plVar2 = *(longlong **)
            (*(longlong *)(*(longlong *)(param_1 + 0x48) + 0x88) + (uStack_50 & 0xffffffff) * 8);
  param_3 = param_2;
  switch(*(uint *)(plVar2 + 2) & 0x1ff) {
  case 0:
  case 2:
  case 3:
  case 7:
  case 8:
  case 0x21:
    lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
    uVar10 = *(undefined8 *)(lVar1 + 0x40);
    plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
    bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
    uVar5 = (**(code **)(*plVar3 + 0x238))();
    uVar13 = 0x2f;
    goto code_r0x001000fc;
  case 1:
    lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
    uVar10 = *(undefined8 *)(lVar1 + 0x40);
    plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
    bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
    uVar5 = (**(code **)(*plVar3 + 0x238))();
    uVar13 = 0x30;
    goto code_r0x001000fc;
  case 4:
    uVar11 = 0x39;
    uVar10 = 0x2c;
    break;
  case 5:
  case 6:
    uVar11 = 0x32;
    uVar10 = 5;
    break;
  case 9:
    lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
    uVar10 = *(undefined8 *)(lVar1 + 0x40);
    plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
    bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
    uVar5 = (**(code **)(*plVar3 + 0x238))();
    uVar13 = 0xd;
code_r0x001000fc:
    uVar11 = 5;
    goto code_r0x00100101;
  case 10:
    (**(code **)(*(longlong *)(param_1 + 0xb8) + 8))
              (param_2,*(longlong *)(param_1 + 0xb8),param_1 + 0xc0);
    if ((((*(longlong *)(param_1 + 0x48) == 0) ||
         (plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x48) + 0x28), plVar2 == (longlong *)0x0))
        || ((*(byte *)(plVar2 + 8) & 0x20) == 0)) ||
       ((sVar6 = (**(code **)(*plVar2 + 0x238))(plVar2), sVar6 != 0xc5 &&
        (sVar6 = (**(code **)(*plVar2 + 0x238))(plVar2), sVar6 != 0xc4)))) {
      in_stack_ffffffffffffff78 = param_1 + 200;
      (*pcRam0000000001b87238)(5,0x20,0x10,1,in_stack_ffffffffffffff78);
      bVar4 = false;
    }
    else {
      (*pcRam0000000001b87238)(0xa9,0x22,0x10);
      bVar4 = false;
    }
    goto LAB_;
  case 0xb:
    uVar11 = 0xc;
    uVar10 = 5;
    break;
  default:
    goto LAB_;
  case 0xe:
    in_stack_ffffffffffffff78 = 0;
    (*pcRam0000000001b87238)(0x56,0x1e,0x10,0x27,0);
    bVar4 = false;
    goto LAB_;
  case 0xf:
    bVar4 = false;
    *(undefined *)
     (*(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8) + 0x20) + 0x98) = 1;
    goto LAB_;
  case 0x12:
    uVar9 = (**(code **)(*plVar2 + 0x18))(plVar2);
    in_stack_ffffffffffffff78 = CONCAT44(uVar7,uVar9);
    (*pcRam0000000001b87238)(5,0x1e,0x10,1,in_stack_ffffffffffffff78);
    bVar4 = false;
    goto LAB_;
  case 0x13:
  case 0x14:
    uStackX_18 = 0;
    uVar9 = (*pcRam0000000002614a08)(plVar2,&uStackX_18);
    uStackX_8 = 0;
    uVar8 = (*pcRam0000000002614a10)(plVar2,&uStackX_8);
    in_stack_ffffffffffffff78 = CONCAT44(uVar7,uVar9);
    (*pcRam0000000001b87238)
              (0x35,((*(uint *)(plVar2 + 2) & 0x1ff) != 0x13) + '\x02',0x10,1,
               in_stack_ffffffffffffff78,uStackX_18,uVar8,uStackX_8);
    bVar4 = false;
    goto LAB_;
  case 0x15:
    uVar11 = 0x48;
    uVar10 = 0x56;
    break;
  case 0x16:
  case 0x17:
  case 0x18:
    uStackX_20 = 0;
    uVar9 = (*pcRam0000000002614a08)(plVar2,&uStackX_20);
    if ((*(uint *)(plVar2 + 2) & 0x1ff) == 0x16) {
      uVar8 = 0x19;
    }
    else {
      uVar8 = 0x20;
      if ((*(uint *)(plVar2 + 2) & 0x1ff) == 0x17) {
        uVar8 = 0x1a;
      }
    }
    uVar11 = 0x35;
    in_stack_ffffffffffffff78 = CONCAT44(uVar7,uVar9);
    uVar10 = uStackX_20;
    goto code_r0x0010059a;
  case 0x19:
    uVar11 = 0x4c;
    uVar10 = 0x56;
    break;
  case 0x1a:
    lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
    uVar10 = *(undefined8 *)(lVar1 + 0x40);
    plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
    bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
    uVar5 = (**(code **)(*plVar3 + 0x238))();
    uVar11 = 0x1c2;
    uVar13 = 0x16;
    goto code_r0x00100101;
  case 0x1b:
    lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
    uVar10 = *(undefined8 *)(lVar1 + 0x40);
    plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
    bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
    uVar5 = (**(code **)(*plVar3 + 0x238))();
    uVar11 = 0x87;
    uVar13 = 0x23;
    goto code_r0x00100101;
  case 0x1c:
    uVar7 = (**(code **)(*plVar2 + 0x28))(plVar2);
    switch(uVar7) {
    case 0:
      lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
      uVar10 = *(undefined8 *)(lVar1 + 0x40);
      plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
      bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
      uVar5 = (**(code **)(*plVar3 + 0x238))();
      uVar11 = 0x87;
      uVar13 = 0x28;
      break;
    case 1:
      lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
      uVar10 = *(undefined8 *)(lVar1 + 0x40);
      plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
      bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
      uVar5 = (**(code **)(*plVar3 + 0x238))();
      uVar11 = 0x87;
      uVar13 = 0x2a;
      break;
    case 2:
      lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
      uVar10 = *(undefined8 *)(lVar1 + 0x40);
      plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
      bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
      uVar5 = (**(code **)(*plVar3 + 0x238))();
      uVar11 = 0x87;
      uVar13 = 0x4b;
      break;
    case 3:
      lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
      uVar10 = *(undefined8 *)(lVar1 + 0x40);
      plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
      bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
      uVar5 = (**(code **)(*plVar3 + 0x238))();
      uVar11 = 0x87;
      uVar13 = 0x49;
      break;
    case 4:
    case 5:
      lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
      uVar10 = *(undefined8 *)(lVar1 + 0x40);
      plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x20) + 0x88);
      bVar12 = (byte)((ulonglong)plVar3[8] >> 0x3c) & 1;
      uVar5 = (**(code **)(*plVar3 + 0x238))();
      uVar11 = 0x89;
      uVar13 = 0x2a;
      break;
    default:
      goto LAB_;
    }
code_r0x00100101:
    in_stack_ffffffffffffff78 = *(longlong *)(param_1 + 0x60);
    func_0x(plVar2,uVar11,uVar13,uVar10,in_stack_ffffffffffffff78,uVar5,bVar12);
    bVar4 = false;
    goto LAB_;
  case 0x1d:
    uStack_68 = 0;
    uVar9 = (*pcRam0000000002614a08)(plVar2,&uStack_68);
    uVar8 = 4;
    in_stack_ffffffffffffff78 = CONCAT44(uVar7,uVar9);
    uVar11 = 0x14f;
    uVar10 = uStack_68;
    goto code_r0x0010059a;
  case 0x1e:
    uVar11 = 0x4b;
    uVar10 = 0x94;
    break;
  case 0x1f:
    uVar9 = (*pcRam0000000002614a10)(plVar2,&uStack_60);
    uVar8 = 0x15;
    in_stack_ffffffffffffff78 = CONCAT44(uVar7,uVar9);
    uVar11 = 0x8b;
    uVar10 = uStack_60;
code_r0x0010059a:
    (*pcRam0000000001b87238)(uVar11,uVar8,0x10,1,in_stack_ffffffffffffff78,uVar10);
    bVar4 = false;
    goto LAB_;
  case 0x20:
    uVar11 = 0x28;
    uVar10 = 0x4d;
    break;
  case 0x22:
    uVar11 = 0x4f;
    uVar10 = 0x56;
  }
  (*pcRam0000000001b87238)(uVar10,uVar11,0x10);
LAB_:
  bVar4 = false;
  goto LAB_;
}

