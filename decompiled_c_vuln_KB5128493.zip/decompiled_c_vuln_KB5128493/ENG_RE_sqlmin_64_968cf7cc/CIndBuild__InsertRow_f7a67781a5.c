
/* WARNING: Removing unreachable block (ram,0x001013da) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,short *param_3,int param_4,undefined8 param_5,
                 undefined4 param_6)

{
  byte *pbVar1;
  byte bVar2;
  short sVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong lVar7;
  undefined auVar8 [16];
  longlong lVar9;
  undefined4 uVar10;
  int iVar11;
  longlong lVar12;
  ulonglong *puVar13;
  longlong *plVar14;
  short *psVar15;
  int iVar16;
  uint uVar17;
  code *UNRECOVERED_JUMPTABLE_00;
  short sVar18;
  ushort uVar19;
  ushort uVar20;
  ushort *puVar21;
  byte **ppbVar22;
  ushort *puVar23;
  uint uVar24;
  uint uVar25;
  byte *pbVar26;
  ulonglong uVar27;
  longlong unaff_GS_OFFSET;
  char cVar28;
  short sStack_1a8;
  ushort uStack_1a6;
  uint uStack_1a4;
  byte *pbStack_1a0;
  undefined8 uStack_198;
  uint uStack_190;
  ushort uStack_18c;
  byte *pbStack_18a;
  undefined2 uStack_182;
  undefined2 uStack_180;
  undefined2 uStack_17e;
  ushort uStack_17c;
  undefined2 uStack_17a;
  undefined4 uStack_170;
  undefined2 uStack_168;
  uint uStack_164;
  byte *pbStack_160;
  undefined8 uStack_158;
  undefined8 uStack_14a;
  undefined2 uStack_142;
  undefined2 uStack_140;
  undefined6 uStack_13e;
  longlong lStack_130;
  int iStack_128;
  undefined2 uStack_124;
  uint uStack_120;
  undefined8 uStack_118;
  undefined2 uStack_110;
  undefined8 uStack_108;
  undefined4 uStack_100;
  undefined2 uStack_f8;
  undefined4 uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  undefined8 uStack_80;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [10];
  undefined auStack_56 [6];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&sStack_1a8;
  uVar27 = 0;
  uVar17 = 0;
  uVar4 = *(undefined8 *)(param_2 + 8);
  sVar3 = *(short *)(param_2 + 0x18);
  uStack_108 = param_5;
  sStack_1a8 = -1;
  pbStack_1a0 = (byte *)0x0;
  iVar16 = 0;
  uStack_1a4 = 0;
  pbStack_18a = (byte *)0x0;
  uStack_180 = 0;
  uStack_17e = 0;
  uStack_17c = 0;
  uStack_17a = 0;
  uStack_198 = (longlong *)0x0;
  uStack_120 = 9;
  uStack_170 = 0xf;
  lStack_130 = param_1;
  iStack_128 = param_4;
  if (*(int *)(param_1 + 0xf84) != 0) {
    if ((*(byte *)(param_2 + 0x1e) & 1) == 0) {
      *(undefined4 *)(param_1 + 0xf80) = 0;
    }
    else {
      iVar16 = *(int *)(param_1 + 0xf80) + 1;
      *(int *)(param_1 + 0xf80) = iVar16;
      if (iVar16 != 0) goto LAB_;
    }
    if ((*(byte *)(*(longlong *)(param_1 + 0x28) + 0x108) & 8) != 0) {
LAB_:
      uStack_164 = 0;
      uStack_14a = 0;
      uStack_140 = 0;
      uStack_13e = 0;
      uStack_158 = 0;
      if (iVar16 == 0x7fffffff) {
        (*_DAT_)(6,0x42,0x10,1,(ulonglong)*(uint6 *)(param_1 + 0x34) << 0x10);
        uVar27 = (ulonglong)uStack_164;
      }
      pbStack_160 = *(byte **)(param_2 + 8);
      if ((*pbStack_160 & 1) == 0) {
        uStack_168 = 0;
        uStack_142 = 0;
        uStack_140 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001002d5 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_160 & 0xe) * 4 + 0x1034cc) -
                  0x1496e10))
                  (0xfffffffffeb691f0,(longlong)(int)(*pbStack_160 & 0xe),pbStack_160,uVar27);
        return;
      }
      uStack_168 = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_160 & 0x1c) + 0x1034ac)
                              * 4 + 0x10349c) - 0x1496e10);
                    /* WARNING: Could not emulate address calculation at 0x0010015c */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
  }
  if (*(int *)(param_1 + 0xf98) != 0) {
    pbStack_1a0 = *(byte **)(param_2 + 8);
    if ((*pbStack_1a0 & 1) == 0) {
      sStack_1a8 = 0;
      uStack_1a4 = 0;
      uStack_182 = 0;
      uStack_180 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101372 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1a0 & 0xe) * 4 + 0x103540) -
                0x1496e10))();
      return;
    }
    sStack_1a8 = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1a0 & 0x1c) + 0x103520) *
                            4 + 0x103510) - 0x1496e10);
                    /* WARNING: Could not emulate address calculation at 0x0010118c */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  lVar12 = *(longlong *)(param_1 + 0xdf0);
  iVar16 = -1;
  if (lVar12 != 0) {
    uVar24 = 0x2000 - *(int *)(param_1 + 0xb38);
    sVar18 = 1 << ((byte)*(undefined2 *)(lVar12 + 4) & 2);
    uVar25 = (uint)(ushort)(sVar18 + -1 + sVar3 & -sVar18);
    if (uVar25 <= uVar24) {
      uVar25 = uVar24;
    }
    if (2 < *(ushort *)(lVar12 + 0x1c)) {
      uVar17 = *(ushort *)(lVar12 + 0x1c) - 2;
    }
    uVar27 = 0;
    if (uVar25 <= uVar17) {
      iVar16 = func_0x(lVar12,uVar4,sVar3);
      uVar27 = (ulonglong)uStack_1a4;
    }
  }
  if (iVar16 == -1) {
    lVar12 = *(longlong *)(param_1 + 0xdf0);
    iVar16 = 0;
    if (lVar12 != 0) {
      *(ushort *)(lVar12 + 4) = *(ushort *)(lVar12 + 4) | 4;
      if (*(ushort *)(lVar12 + 0x16) != 0) {
        puVar21 = (ushort *)(lVar12 + 0x1ffe);
        do {
          if ((*puVar21 != 0) &&
             ((bVar2 = *(byte *)((ulonglong)*puVar21 + lVar12), (bVar2 & 1) != 0 ||
              ((bVar2 & 0x20) != 0)))) {
            *(ushort *)(lVar12 + 4) = *(ushort *)(lVar12 + 4) & 0xfffb;
            break;
          }
          iVar16 = iVar16 + 1;
          puVar21 = puVar21 + -1;
        } while (iVar16 < (int)(uint)*(ushort *)(lVar12 + 0x16));
      }
    }
    *(longlong *)(param_1 + 0xe28) = *(longlong *)(param_1 + 0xe28) + 1;
    lVar12 = func_0x(param_1 + 0xb50,0);
    *(longlong *)(param_1 + 0xdf0) = lVar12;
    if ((DAT_ != '\0') || ((DAT_ & 0x80) != 0)) {
      plVar14 = *(longlong **)(param_1 + 0xb78);
      if (*plVar14 != lVar12) {
        (*_DAT_)(1,0x14615f8,0x142b580,0x39b,0);
      }
      LOCK();
      puVar21 = (ushort *)((longlong)plVar14 + 0x62);
      *puVar21 = *puVar21 | 0x800;
      UNLOCK();
      param_1 = lStack_130;
    }
    if (*(int *)(param_1 + 0xf98) != 0) {
      *(undefined8 *)(param_1 + 0x1000) = 0;
      *(undefined2 *)(param_1 + 0x1008) = 0;
      *(undefined8 *)(param_1 + 0x100c) = 1;
      puVar5 = *(undefined8 **)(param_1 + 0xfa8);
      *(undefined8 *)(param_1 + 4000) = 0;
      if (puVar5 != (undefined8 *)0x0) {
        puVar6 = (undefined8 *)puVar5[1];
        if (puVar6 != (undefined8 *)0x0) {
          *puVar6 = 0;
          *(undefined4 *)(puVar6 + 0x481) = 0;
        }
        puVar5[3] = 0;
        *(undefined2 *)(puVar5 + 4) = 0;
        *puVar5 = 0;
        *(undefined4 *)(puVar5 + 0x14b) = 0;
      }
    }
    lVar12 = *(longlong *)(param_1 + 0x60);
    if ((*(int *)(lVar12 + 0xc) == 0) && (*(short *)(lVar12 + 0x10) == 0)) {
      lVar7 = *(longlong *)(param_1 + 0xdf0);
      *(undefined4 *)(lVar12 + 0xc) = *(undefined4 *)(lVar7 + 0x20);
      *(undefined2 *)(lVar12 + 0x10) = *(undefined2 *)(lVar7 + 0x24);
      *(undefined2 *)(lVar12 + 0x12) = 0;
      *(undefined4 *)(param_1 + 0x98) = *(undefined4 *)(*(longlong *)(param_1 + 0xdf0) + 0x20);
      *(undefined2 *)(param_1 + 0x9c) = *(undefined2 *)(*(longlong *)(param_1 + 0xdf0) + 0x24);
    }
    lVar12 = *(longlong *)(param_1 + 0xdf0);
    iVar16 = -1;
    if (lVar12 != 0) {
      uVar25 = 0x2000 - *(int *)(param_1 + 0xb38);
      sVar18 = 1 << ((byte)*(undefined2 *)(lVar12 + 4) & 2);
      uVar17 = (uint)(ushort)(sVar18 + -1 + sVar3 & -sVar18);
      if (uVar17 <= uVar25) {
        uVar17 = uVar25;
      }
      if (*(ushort *)(lVar12 + 0x1c) < 3) {
        uVar25 = 0;
      }
      else {
        uVar25 = *(ushort *)(lVar12 + 0x1c) - 2;
      }
      if (uVar17 <= uVar25) {
        iVar16 = func_0x(lVar12,uVar4,sVar3);
        lVar12 = *(longlong *)(param_1 + 0xdf0);
      }
    }
    if ((*(int *)(lVar12 + 0x20) != *(int *)(param_1 + 0x98)) ||
       (*(short *)(lVar12 + 0x24) != *(short *)(param_1 + 0x9c))) {
      uVar10 = func_0x(param_1,lVar12,param_1 + 0xdc,0xa58);
      lVar9 = lStack_130;
      *(undefined4 *)(param_1 + 0xd8) = uVar10;
      lVar12 = lStack_130 + 0xa0;
      lVar7 = *(longlong *)(lStack_130 + 0xa8);
      cVar28 = *(short *)(*(longlong *)(param_1 + 0x28) + 0x3c4) != 1;
      if (lVar7 == 0) {
LAB_:
        func_0x(lVar9,lVar12,cVar28);
      }
      else {
        iVar11 = func_0x(lStack_130,lVar7,cVar28,lVar7);
        lVar12 = lVar7;
        while (iVar11 != 0) {
          if (cVar28 == -1) {
            (*_DAT_)(6,0x56,0x10,2,(ulonglong)*(uint6 *)(lVar9 + 0x34) << 0x10);
          }
          lVar7 = *(longlong *)(lVar12 + 8);
          cVar28 = cVar28 + '\x01';
          if (lVar7 == 0) goto LAB_;
          iVar11 = func_0x(lVar9,lVar7,cVar28,lVar7);
          lVar12 = lVar7;
        }
      }
    }
    uVar27 = (ulonglong)uStack_1a4;
  }
  if (iStack_128 != 0) {
    if (*(int *)(lStack_130 + 0xf98) != 0) {
      *param_3 = sStack_1a8;
      if (sStack_1a8 != 0) {
        if ((uStack_198 == (longlong *)0x0) || (*uStack_198 == 0)) {
          func_0x(param_3 + 1,uStack_108,param_6,&uStack_1a6);
          plVar14 = uStack_198;
          if (sStack_1a8 == 0) {
            plVar14 = (longlong *)0x0;
          }
          *(longlong **)(param_3 + 8) = plVar14;
        }
        else {
          func_0x(param_3,uStack_108,param_6,&sStack_1a8);
        }
        goto LAB_;
      }
      puVar21 = (ushort *)(param_3 + 1);
      if ((int)uVar27 == 0) {
        uVar27 = (ulonglong)uStack_198 & 0xffffffff;
        uStack_1a6 = 0;
        uVar17 = (uint)uStack_198;
        if ((*pbStack_1a0 & 0x10) != 0) {
          uVar17 = (uint)uStack_198 + 2 + (*(ushort *)(pbStack_1a0 + uVar27) + 7 >> 3);
          uVar27 = (ulonglong)uVar17;
        }
        uStack_198 = (longlong *)CONCAT44(uVar17,(uint)uStack_198);
        uStack_190 = (uint)uVar27;
        if ((*pbStack_1a0 & 0x20) == 0) {
          uStack_18c = 0;
          uStack_1a4 = uStack_190;
        }
        else {
          puVar23 = (ushort *)(pbStack_1a0 + uVar27);
          uStack_18c = *puVar23;
          if (uStack_18c == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar12 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar12 != 0)) &&
               ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                (*(char *)(lVar12 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x12a6538,0x13c6208,0x80f,0);
              }
            }
            func_0x(pbStack_1a0,3);
          }
          uStack_190 = uStack_198._4_4_ + (uStack_18c + 1) * 2;
          if (0x1f9e < uStack_190) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar12 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar12 != 0 &&
                ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                 (*(char *)(lVar12 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x12a6538,0x13c6208,0x816,0);
              }
            }
            func_0x(pbStack_1a0,4);
          }
          uStack_1a4 = puVar23[uStack_18c] & 0x7fff;
          if (uStack_1a4 < uStack_190) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar12 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar12 != 0)) &&
               ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                (*(char *)(lVar12 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x12a6538,0x13c6208,0x81d,0);
              }
            }
            func_0x(pbStack_1a0,4);
          }
          uVar27 = (ulonglong)uStack_1a4;
          do {
            if (-1 < (short)puVar23[(ulonglong)(uStack_18c - 1) + 1]) break;
            uVar17 = uStack_190;
            if (((uStack_18c != 1) &&
                (uVar17 = *(ushort *)
                           (pbStack_1a0 +
                           (ulonglong)uStack_18c * 2 + (((ulonglong)uStack_198 >> 0x20) - 2)) &
                          0x7fff, uVar17 < uStack_190)) ||
               ((*(ushort *)
                  (pbStack_1a0 + (ulonglong)uStack_18c * 2 + ((ulonglong)uStack_198 >> 0x20)) &
                0x7fff) < uVar17)) {
              func_0x(pbStack_1a0,7);
              uVar27 = (ulonglong)uStack_1a4;
            }
            if ((uVar17 < uStack_190) || ((uint)uVar27 < uVar17)) goto LAB_;
            if (*(ushort *)(pbStack_1a0 + uVar17) == 5) {
              uStack_1a6 = uStack_1a6 | 2;
              uStack_18c = uStack_18c - 1;
              uStack_17e = (undefined2)uVar17;
              if ((*(ushort *)(pbStack_1a0 + (ulonglong)(uVar17 & 0xffff) + 2) & 0x4000) == 0) {
                uStack_17c = uStack_17c & 0xc7ff;
              }
              else {
                uStack_17c = uStack_17c ^
                             (*(ushort *)(pbStack_1a0 + (ulonglong)(uVar17 & 0xffff) + 2) ^
                             uStack_17c) & 0x3800;
              }
              uStack_17c = (uStack_17c ^ *(ushort *)(pbStack_1a0 + (ulonglong)(uVar17 & 0xffff) + 2)
                           ) & 0x7ff ^ uStack_17c;
              break;
            }
            if (*(ushort *)(pbStack_1a0 + uVar17) < 0x400) break;
            uStack_1a6 = uStack_1a6 | 1;
            uStack_18c = uStack_18c - 1;
          } while (uStack_18c != 0);
        }
        iVar16 = 0;
        if ((*pbStack_1a0 & 0x40) == 0) {
          uStack_182 = 0;
          uStack_180 = 0;
        }
        else {
          uStack_182 = (undefined2)uVar27;
          uStack_180 = (undefined2)(uVar27 >> 0x10);
          uStack_1a4 = (int)uVar27 + 0xe;
          puVar13 = (ulonglong *)func_0x(&uStack_1a6);
          uVar27 = *puVar13;
          uVar20 = (ushort)(uVar27 >> 0x30);
          uVar19 = uVar20;
          if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
            uVar19 = uVar20 & 0xdfff;
            if ((uVar27 & 0x4000000000000000) != 0) {
              uVar19 = uVar20 | 0x2000;
            }
          }
          if (uVar19 == 0xfffc) {
            iVar16 = (int)((uVar27 >> 0x20 & 0xffff) >> 5);
          }
          uStack_1a4 = uStack_1a4 + iVar16;
          uVar27 = (ulonglong)uStack_1a4;
        }
        if ((pbStack_18a != (byte *)0x0) && (pbStack_18a < pbStack_1a0 + uVar27)) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar12 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar12 != 0 &&
               (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x12a6538,0x13c6208,0x877,0);
            }
          }
          func_0x(pbStack_1a0,0x12);
          uVar27 = (ulonglong)uStack_1a4;
        }
        if (0x3f3b < (int)uVar27 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar12 != 0 &&
              ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
               (*(char *)(lVar12 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x12a6538,0x13c6208,0x87c,0);
            }
          }
          func_0x(pbStack_1a0,5);
          uVar27 = (ulonglong)uStack_1a4;
        }
      }
LAB_:
      uVar4 = uStack_108;
      uVar17 = (uint)uVar27;
      if ((8 < uVar17) || (((*pbStack_1a0 & 0xe) != 0 && ((*pbStack_1a0 & 0xe) != 0xc)))) {
        uStack_120 = uVar17;
      }
      *(uint *)(param_3 + 8) = (uint)uStack_198;
      *puVar21 = uStack_1a6;
      param_3[0xe] = uStack_18c;
      *(int *)(param_3 + 10) = uStack_198._4_4_;
      *(uint *)(param_3 + 0xc) = uStack_190;
      *(uint *)(param_3 + 2) = uVar17;
      *(uint *)(param_3 + 0x13) = CONCAT22(uStack_180,uStack_182);
      func_0x(uStack_108,param_6,pbStack_1a0,uStack_120);
      *(undefined8 *)(param_3 + 4) = uVar4;
      iVar16 = func_0x(puVar21);
      if (iVar16 == 0) goto LAB_;
      puVar23 = (ushort *)((ulonglong)*(uint *)(param_3 + 10) + *(longlong *)(param_3 + 4));
      uVar17 = *puVar23 - 1;
      if ((*(byte *)puVar21 & 1) == 0) {
        uVar17 = (uint)*puVar23;
      }
      if (uVar17 == 1) {
        uVar25 = *(uint *)(param_3 + 0xc);
LAB_:
        if ((puVar23[(int)uVar17] & 0x7fff) < uVar25) goto LAB_;
      }
      else {
        uVar25 = puVar23[(longlong)(int)uVar17 + -1] & 0x7fff;
        if (*(uint *)(param_3 + 0xc) <= uVar25) goto LAB_;
LAB_:
        func_0x(*(longlong *)(param_3 + 4),7);
      }
      param_3[0x15] = (short)uVar25;
      lVar12 = (ulonglong)(uVar25 & 0xffff) + *(longlong *)(param_3 + 4);
      uVar19 = param_3[0x16] & 0xc7ffU;
      if ((*(ushort *)(lVar12 + 2) >> 0xe & 1) != 0) {
        uVar19 = *(ushort *)(lVar12 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
      }
      param_3[0x16] = uVar19;
      param_3[0x16] = (uVar19 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar19;
LAB_:
      plVar14 = *(longlong **)(lStack_130 + 0x68);
      if (plVar14 != (longlong *)0x0) {
        *plVar14 = *plVar14 + 1;
      }
      func_0x(uStack_48 ^ (ulonglong)&sStack_1a8);
      return;
    }
    lVar12 = *(longlong *)(lStack_130 + 0xdf0);
    pbStack_f0 = (byte *)0x0;
    uStack_f8 = 0xffff;
    uStack_f4 = 0;
    uStack_da = 0;
    uStack_d0 = 0;
    uStack_ce = 0;
    uStack_e8 = 0;
    iStack_c4 = iVar16;
    if (-1 < *(char *)(lVar12 + 2)) goto LAB_;
    pbVar26 = (byte *)(lVar12 + 0x60);
    stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
    auStack_b0._0_2_ = 0xffff;
    uStack_98 = 0;
    uStack_8a = 0;
    uStack_a8 = 0;
    uStack_80 = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    psStack_78 = (short *)0x0;
    _auStack_60 = ZEXT812(0);
    auStack_56._2_4_ = 0;
    uStack_50 = 0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uStack_66 = 0;
    auStack_c0 = ZEXT816(0);
    lVar7 = 0;
    if (*(short *)(lVar12 + 0x24) == 0) {
LAB_:
      auStack_c0._8_8_ = lVar7;
      uStack_118 = *(undefined8 *)(lVar12 + 0x28);
      uStack_110 = *(undefined2 *)(lVar12 + 0x30);
    }
    else {
      cVar28 = *(char *)(lVar12 + 1);
      if (cVar28 == '\v') {
        if (*(int *)(lVar12 + 0x18) != 99) {
LAB_:
          if (cVar28 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar28 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar12 + 0x18) != 99) goto LAB_;
      }
      iStack_128 = *(int *)(lVar12 + 0x20);
      uStack_124 = *(undefined2 *)(lVar12 + 0x24);
      cVar28 = func_0x(&iStack_128);
      lVar7 = auStack_c0._8_8_;
      if (cVar28 == '\0') goto LAB_;
      func_0x(lVar12,&uStack_118);
    }
    auStack_c0._0_8_ = pbVar26;
    auStack_60._8_2_ = uStack_110;
    auStack_60._0_8_ = uStack_118;
    auStack_56._2_4_ = *(undefined4 *)(lVar12 + 0x20);
    auStack_b0._0_2_ = 0xffff;
    auStack_b0 = (undefined  [8])((ulonglong)auStack_b0 & 0xffffffff);
    uStack_a8 = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uVar10 = *(undefined4 *)((ulonglong)*pbVar26 * 6 + 0x10a3020);
    uVar27 = (ulonglong)*(short *)((ulonglong)*pbVar26 * 6 + 0x10a3024);
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    psStack_78 = (short *)0x0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uStack_100 = uVar10;
    if ((*pbVar26 & 2) != 0) {
      pbVar1 = pbVar26 + uVar27;
      uStack_a8 = pbVar1;
      if ((pbVar26[uVar27] & 1) == 0) {
        auVar8._14_2_ = 0;
        auVar8._0_14_ = stack0xffffffffffffff52;
        _auStack_b0 = auVar8 << 0x10;
        uStack_8a = 0;
        uStack_88 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101b40 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x1035ac) - 0x1496e10))
                  ();
        return;
      }
      auStack_b0._0_2_ = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x10358c) * 4 +
                             0x10357c) - 0x1496e10);
                    /* WARNING: Could not emulate address calculation at 0x00101976 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    if ((*pbVar26 & 4) != 0) {
      uStack_100._2_2_ = (short)((uint)uVar10 >> 0x10);
      if (uStack_100._2_2_ != 0) {
        uVar27 = (ulonglong)*(ushort *)(lVar12 + 0x61 + (longlong)uStack_100._2_2_ * 2);
      }
      psStack_78 = (short *)(pbVar26 + uVar27);
      psStack_70 = psStack_78 + 1;
      sStack_68 = (*psStack_78 + 1) * 2;
    }
    if (auStack_c0._8_8_ != 0) {
      func_0x(auStack_c0._8_8_,auStack_c0);
    }
LAB_:
    pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar12 + (0xfff - (longlong)iVar16) * 2) + lVar12);
    if ((*pbStack_f0 & 1) == 0) {
      uStack_f8 = 0;
      uStack_f4 = 0;
      uStack_d2 = 0;
      uStack_d0 = 0;
      uStack_170 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101e54 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_f0 & 0xe) * 4 + 0x103618) - 0x1496e10
                ))();
      return;
    }
    uStack_f8 = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_f0 & 0x1c) + 0x1035f8) * 4
                           + 0x1035e8) - 0x1496e10);
                    /* WARNING: Could not emulate address calculation at 0x00101c6c */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  lVar12 = *(longlong *)(lStack_130 + 0xdf0);
  *(int *)(param_3 + 0x1a) = iVar16;
  if (-1 < *(char *)(lVar12 + 2)) goto LAB_;
  pbVar26 = (byte *)(lVar12 + 0x60);
  if ((*param_3 == 0) || (ppbVar22 = *(byte ***)(param_3 + 8), ppbVar22 == (byte **)0x0)) {
    ppbVar22 = (byte **)(param_3 + 0x1c);
    *(undefined (*) [16])(param_3 + 0x20) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x28) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x30) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x38) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x40) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x48) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x50) = ZEXT816(0);
    *ppbVar22 = (byte *)0x0;
    *(undefined8 *)(param_3 + 0x20) = 0;
    param_3[0x24] = -1;
    *(undefined8 *)(param_3 + 0x28) = 0;
    *(undefined4 *)(param_3 + 0x26) = 0;
    *(undefined8 *)(param_3 + 0x33) = 0;
    *(undefined8 *)(param_3 + 0x38) = 0;
    *(undefined8 *)(param_3 + 0x2c) = 0;
    *(undefined8 *)(param_3 + 0x40) = 0;
    *(undefined8 *)(param_3 + 0x4c) = 0;
    *(undefined4 *)(param_3 + 0x50) = 0;
    param_3[0x55] = 0;
  }
  if (*(short *)(lVar12 + 0x24) == 0) {
LAB_:
    uStack_118 = *(undefined8 *)(lVar12 + 0x28);
    uStack_110 = *(undefined2 *)(lVar12 + 0x30);
  }
  else {
    cVar28 = *(char *)(lVar12 + 1);
    if (cVar28 == '\v') {
      if (*(int *)(lVar12 + 0x18) != 99) {
LAB_:
        if (cVar28 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar28 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar12 + 0x18) != 99) goto LAB_;
    }
    iStack_128 = *(int *)(lVar12 + 0x20);
    uStack_124 = *(undefined2 *)(lVar12 + 0x24);
    cVar28 = func_0x(&iStack_128);
    if (cVar28 == '\0') goto LAB_;
    func_0x(lVar12,&uStack_118);
  }
  *ppbVar22 = pbVar26;
  *(undefined4 *)(ppbVar22 + 0xc) = (undefined4)uStack_118;
  *(undefined2 *)(ppbVar22 + 0xd) = uStack_110;
  *(int *)((longlong)ppbVar22 + 100) = (int)((ulonglong)uStack_118 >> 0x20);
  *(undefined4 *)((longlong)ppbVar22 + 0x6c) = *(undefined4 *)(lVar12 + 0x20);
  *(undefined2 *)(ppbVar22 + 0xe) = *(undefined2 *)(lVar12 + 0x24);
  *(undefined2 *)((longlong)ppbVar22 + 0x72) = 0;
  uVar10 = *(undefined4 *)((ulonglong)*pbVar26 * 6 + 0x10a3020);
  uVar27 = (ulonglong)*(short *)((ulonglong)*pbVar26 * 6 + 0x10a3024);
  *(undefined2 *)(ppbVar22 + 2) = 0xffff;
  ppbVar22[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
  ppbVar22[7] = (byte *)0x0;
  ppbVar22[4] = (byte *)0x0;
  ppbVar22[9] = (byte *)0x0;
  ppbVar22[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar22 + 0xb) = 0;
  uStack_100 = uVar10;
  if ((**ppbVar22 & 2) != 0) {
    pbVar1 = pbVar26 + uVar27;
    if ((pbVar26[uVar27] & 1) == 0) {
      *(undefined2 *)(ppbVar22 + 2) = 0;
      ppbVar22[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar22 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010311d */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x103684) - 0x1496e10))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar22 + 2) = 1;
    ppbVar22[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x103664) * 4 +
                           0x103654) - 0x1496e10);
                    /* WARNING: Could not emulate address calculation at 0x00102f8c */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar22 & 4) != 0) {
    uStack_100._2_2_ = (short)((uint)uVar10 >> 0x10);
    if (uStack_100._2_2_ != 0) {
      uVar27 = (ulonglong)*(ushort *)(lVar12 + 0x61 + (longlong)uStack_100._2_2_ * 2);
    }
    psVar15 = (short *)(pbVar26 + uVar27);
    ppbVar22[9] = (byte *)psVar15;
    sVar3 = *psVar15;
    ppbVar22[10] = (byte *)(psVar15 + 1);
    *(short *)(ppbVar22 + 0xb) = (sVar3 + 1) * 2;
  }
  if (ppbVar22[1] != (byte *)0x0) {
    func_0x(ppbVar22[1],ppbVar22);
  }
LAB_:
  pbVar26 = (byte *)((ulonglong)*(ushort *)(lVar12 + (0xfff - (longlong)iVar16) * 2) + lVar12);
  if ((*pbVar26 & 1) == 0) {
    *param_3 = 0;
    *(byte **)(param_3 + 4) = pbVar26;
    *(undefined4 *)(param_3 + 2) = 0;
    *(undefined4 *)(param_3 + 0x13) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001033eb */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar26 & 0xe) * 4 + 0x1036f0) - 0x1496e10))();
    return;
  }
  *param_3 = 1;
  *(byte **)(param_3 + 4) = pbVar26;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar26 & 0x1c) + 0x1036d0) * 4 +
                         0x1036c0) - 0x1496e10);
                    /* WARNING: Could not emulate address calculation at 0x0010322d */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

