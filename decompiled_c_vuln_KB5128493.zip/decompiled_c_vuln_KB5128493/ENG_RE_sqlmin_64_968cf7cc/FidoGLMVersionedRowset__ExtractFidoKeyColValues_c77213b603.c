
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint *param_2,undefined8 *param_3,undefined *param_4)

{
  ushort *puVar1;
  uint *puVar2;
  longlong *plVar3;
  short *psVar4;
  byte bVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  int iVar9;
  short *psVar10;
  ulonglong *puVar11;
  longlong lVar12;
  uint uVar13;
  longlong lVar14;
  longlong lVar15;
  ushort uVar16;
  short sVar17;
  uint uVar18;
  ulonglong uVar19;
  undefined8 *puVar20;
  uint uVar21;
  byte *pbVar22;
  int iVar23;
  ushort *puVar24;
  longlong unaff_GS_OFFSET;
  undefined auStack_d8 [32];
  uint *puStack_b8;
  undefined4 uStack_b0;
  uint *puStack_a8;
  uint uStack_a0;
  uint uStack_98;
  uint uStack_94;
  uint auStack_90 [2];
  short *psStack_88;
  undefined *puStack_80;
  undefined auStack_78 [4];
  undefined auStack_74 [4];
  longlong lStack_70;
  undefined8 *puStack_68;
  uint auStack_60 [2];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_d8;
  uVar7 = 0;
  iVar23 = 1;
  iVar9 = 0;
  puStack_80 = param_4;
  lStack_70 = param_1;
  puStack_68 = param_3;
  if ((*(longlong *)(param_1 + 0x280) == 0) ||
     (*(int *)(**(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x280) + 8) + 0x160) + 0x1c) ==
      0)) {
    puStack_b8 = (uint *)0x0;
    (*_DAT_)(1,0xbad020,0xb56bc8,0x3ca);
  }
  psVar10 = (short *)(***(code ***)**(undefined8 **)(param_2 + 4))();
  if (*(char *)(param_2 + 6) != '\0') {
    *param_2 = *param_2 | ~*(uint *)(*(longlong *)(param_2 + 2) + 0x268) & 0x40;
    puVar2 = (uint *)(*(longlong *)(param_2 + 2) + 0x268);
    *puVar2 = *puVar2 | 0x40;
  }
  puVar1 = (ushort *)(psVar10 + 1);
  puVar2 = *(uint **)(param_1 + 0x310);
  bVar5 = *(byte *)(puVar2 + 8);
  psStack_88 = psVar10;
  if (*psVar10 == 0) {
    uVar18 = *puVar2;
    if ((uVar18 & 0xc0000000) == 0x80000000) {
      iVar8 = func_0x(puVar1);
      if (iVar8 == 0) {
LAB_:
        uStack_98 = 0;
        puVar20 = (undefined8 *)0x0;
        lVar15 = param_1;
      }
      else {
        puVar20 = (undefined8 *)func_0x(psVar10 + 0x15,puVar2,&uStack_98,auStack_78);
        lVar15 = param_1;
      }
    }
    else {
      lVar15 = lStack_70;
      if (((bVar5 & 2) != 0) || ((*(byte *)((longlong)puVar2 + 6) & 0x10) != 0)) {
        pbVar22 = *(byte **)(psVar10 + 4);
        iVar8 = iVar23;
        if ((*pbVar22 & 0x10) == 0) {
          uVar6 = uVar7;
          if ((1 << (*pbVar22 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
          if ((bVar5 & 2) != 0) goto LAB_;
        }
        else {
          uVar21 = *(uint *)(psVar10 + 8);
          if ((int)uVar21 <= (int)uVar18) {
LAB_:
            iVar8 = iVar9;
            uVar6 = ~(*(ushort *)((longlong)puVar2 + 6) >> 4) & 1;
            goto LAB_;
          }
          if ((uint)*(ushort *)(pbVar22 + uVar21) < (uint)*(ushort *)(puVar2 + 1))
          goto LAB_;
          if ((bVar5 & 2) == 0) goto LAB_;
          uVar13 = *(ushort *)(puVar2 + 1) - 1;
          uVar6 = pbVar22[(ulonglong)(uVar13 >> 3) + (ulonglong)uVar21 + 2] >> ((byte)uVar13 & 7) &
                  1;
LAB_:
          if (uVar6 != 0) {
            uStack_98 = 0;
            puVar20 = (undefined8 *)0x0;
            goto LAB_;
          }
        }
        if ((iVar8 == 0) && ((*(byte *)((longlong)puVar2 + 6) & 0x10) != 0)) {
          puVar20 = (undefined8 *)(*(uint **)(puVar2 + 2) + 1);
          uStack_98 = **(uint **)(puVar2 + 2);
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar18 < 0) {
        if (*(int *)(psVar10 + 2) == 0) {
          pbVar22 = *(byte **)(psVar10 + 4);
          uVar18 = *(uint *)(psVar10 + 8);
          uVar19 = (ulonglong)uVar18;
          *puVar1 = 0;
          *(uint *)(psVar10 + 10) = uVar18;
          bVar5 = *pbVar22;
          if ((bVar5 & 0x10) != 0) {
            uVar18 = uVar18 + 2 + (*(ushort *)(pbVar22 + uVar19) + 7 >> 3);
            uVar19 = (ulonglong)uVar18;
            *(uint *)(psVar10 + 10) = uVar18;
            bVar5 = *pbVar22;
          }
          if ((bVar5 & 0x20) == 0) {
            *(int *)(psVar10 + 2) = (int)uVar19;
            psVar10[0xe] = 0;
            *(int *)(psVar10 + 0xc) = (int)uVar19;
          }
          else {
            puVar24 = (ushort *)(pbVar22 + uVar19);
            uVar6 = *puVar24;
            psVar10[0xe] = uVar6;
            if (uVar6 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar15 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar15 != 0)) &&
                 ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  puStack_b8 = (uint *)0x0;
                  (*_DAT_)(1,0x9cf378,0xaef048,0x80f);
                }
              }
              func_0x(*(undefined8 *)(psVar10 + 4),3);
              uVar19 = (ulonglong)*(uint *)(psVar10 + 10);
              uVar6 = psVar10[0xe];
            }
            uVar18 = (int)uVar19 + (uVar6 + 1) * 2;
            *(uint *)(psVar10 + 0xc) = uVar18;
            if (0x1f9e < uVar18) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar15 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar15 != 0 &&
                  ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                   (*(char *)(lVar15 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_b8 = (uint *)0x0;
                  (*_DAT_)(1,0x9cf378,0xaef048,0x816);
                }
              }
              func_0x(*(undefined8 *)(psVar10 + 4),4);
              uVar6 = psVar10[0xe];
              uVar18 = *(uint *)(psVar10 + 0xc);
            }
            uVar19 = (ulonglong)uVar6;
            uVar6 = puVar24[uVar19];
            *(uint *)(psVar10 + 2) = uVar6 & 0x7fff;
            if ((uVar6 & 0x7fff) < uVar18) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar15 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar15 != 0)) &&
                 ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_b8 = (uint *)0x0;
                  (*_DAT_)(1,0x9cf378,0xaef048,0x81d);
                }
              }
              func_0x(*(undefined8 *)(psVar10 + 4),4);
              uVar19 = (ulonglong)(ushort)psVar10[0xe];
            }
            if ((short)puVar24[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
              pbVar22 = *(byte **)(psVar10 + 4);
              do {
                if ((int)uVar19 == 1) {
                  uVar18 = *(uint *)(psVar10 + 0xc);
                  uVar21 = uVar18;
LAB_:
                  if ((*(ushort *)(pbVar22 + uVar19 * 2 + (ulonglong)*(uint *)(psVar10 + 10)) &
                      0x7fff) < uVar18) goto LAB_;
                }
                else {
                  uVar21 = *(uint *)(psVar10 + 0xc);
                  uVar18 = *(ushort *)
                            (pbVar22 + uVar19 * 2 + ((ulonglong)*(uint *)(psVar10 + 10) - 2)) &
                           0x7fff;
                  if (uVar21 <= uVar18) goto LAB_;
LAB_:
                  func_0x(pbVar22,7);
                  uVar21 = *(uint *)(psVar10 + 0xc);
                }
                if ((uVar18 < uVar21) || (*(uint *)(psVar10 + 2) < uVar18)) goto LAB_;
                pbVar22 = *(byte **)(psVar10 + 4);
                if (*(ushort *)(pbVar22 + uVar18) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar10[0xe] = psVar10[0xe] + -1;
                  psVar10[0x15] = (short)uVar18;
                  lVar15 = (ulonglong)(uVar18 & 0xffff) + *(longlong *)(psVar10 + 4);
                  uVar6 = psVar10[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar15 + 2) >> 0xe & 1) != 0) {
                    uVar6 = *(ushort *)(lVar15 + 2) & 0x3800 | psVar10[0x16] & 0xc7ffU;
                  }
                  psVar10[0x16] = uVar6;
                  psVar10[0x16] = (uVar6 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar6;
                  goto LAB_;
                }
                if (*(ushort *)(pbVar22 + uVar18) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar6 = psVar10[0xe] - 1;
                psVar10[0xe] = uVar6;
                if (uVar6 == 0) goto LAB_;
                uVar19 = (ulonglong)uVar6;
              } while ((short)puVar24[(ulonglong)(uVar6 - 1) + 1] < 0);
              uVar19 = (ulonglong)*(uint *)(psVar10 + 2);
            }
            else {
LAB_:
              uVar19 = (ulonglong)*(uint *)(psVar10 + 2);
              pbVar22 = *(byte **)(psVar10 + 4);
            }
          }
          if ((*pbVar22 & 0x40) == 0) {
            *(undefined4 *)(psVar10 + 0x13) = 0;
          }
          else {
            *(int *)(psVar10 + 0x13) = (int)uVar19;
            *(int *)(psVar10 + 2) = (int)uVar19 + 0xe;
            puVar11 = (ulonglong *)func_0x(puVar1);
            uVar16 = (ushort)(*puVar11 >> 0x30);
            uVar6 = uVar16;
            if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
              uVar6 = uVar16 & 0xdfff;
              if ((uVar16 >> 0xe & 1) != 0) {
                uVar6 = uVar16 | 0x2000;
              }
            }
            iVar8 = iVar9;
            if (uVar6 == 0xfffc) {
              iVar8 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar10 + 2) = *(int *)(psVar10 + 2) + iVar8;
            uVar19 = (ulonglong)*(uint *)(psVar10 + 2);
          }
          iVar8 = (int)uVar19;
          if ((*(ulonglong *)(psVar10 + 0xf) != 0) &&
             (*(ulonglong *)(psVar10 + 0xf) < uVar19 + *(longlong *)(psVar10 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar15 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar15 != 0 &&
                 (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
                (*(char *)(lVar15 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                puStack_b8 = (uint *)0x0;
                (*_DAT_)(1,0x9cf378,0xaef048,0x877);
              }
            }
            func_0x(*(undefined8 *)(psVar10 + 4),0x12);
            iVar8 = *(int *)(psVar10 + 2);
          }
          if (0x3f3b < iVar8 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar15 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar15 != 0 &&
                ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                 (*(char *)(lVar15 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                puStack_b8 = (uint *)0x0;
                (*_DAT_)(1,0x9cf378,0xaef048,0x87c);
              }
            }
            func_0x(*(undefined8 *)(psVar10 + 4),5);
          }
        }
LAB_:
        sVar17 = -*(short *)puVar2;
        lVar15 = lStack_70;
        if ((*(byte *)((longlong)puVar2 + 6) & 0x10) != 0) {
          bVar5 = **(byte **)(psVar10 + 4);
          if ((bVar5 & 0x10) == 0) {
            if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar20 = (undefined8 *)(*(uint **)(puVar2 + 2) + 1);
              uStack_98 = **(uint **)(puVar2 + 2);
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(psVar10 + 8) <= (int)*puVar2) ||
                  (*(ushort *)(*(byte **)(psVar10 + 4) + *(uint *)(psVar10 + 8)) <
                   *(ushort *)(puVar2 + 1))) goto LAB_;
        }
        lVar14 = (longlong)sVar17;
        if ((uint)(ushort)psVar10[0xe] < (uint)(int)sVar17) {
          uStack_98 = 0;
          puVar20 = *(undefined8 **)(psVar10 + 4);
        }
        else {
          lVar15 = *(longlong *)(psVar10 + 4);
          lVar12 = (ulonglong)*(uint *)(psVar10 + 10) + lVar15;
          if (sVar17 == 1) {
            uVar21 = *(ushort *)(lVar12 + lVar14 * 2) & 0x7fff;
            uVar18 = *(uint *)(psStack_88 + 0xc);
LAB_:
            if (uVar21 < uVar18) goto LAB_;
          }
          else {
            uVar18 = *(ushort *)(lVar12 + -2 + lVar14 * 2) & 0x7fff;
            uVar21 = *(ushort *)(lVar12 + lVar14 * 2) & 0x7fff;
            lVar15 = *(longlong *)(psVar10 + 4);
            if (*(uint *)(psStack_88 + 0xc) <= uVar18) goto LAB_;
LAB_:
            func_0x(lVar15,7);
          }
          puVar20 = (undefined8 *)((ulonglong)uVar18 + *(longlong *)(psVar10 + 4));
          lVar15 = lStack_70;
          uStack_98 = uVar21 - uVar18;
        }
      }
      else {
        uVar6 = *(ushort *)((longlong)puVar2 + 6);
        if ((uVar6 & 8) == 0) {
          uVar21 = (uint)*(ushort *)(puVar2 + 0xe);
          if ((uVar6 & 0x10) != 0) {
            bVar5 = **(byte **)(psVar10 + 4);
            if ((bVar5 & 0x10) == 0) {
              if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                uStack_98 = **(uint **)(puVar2 + 2);
                puVar20 = (undefined8 *)(*(uint **)(puVar2 + 2) + 1);
                if ((uVar21 != 0) && (uStack_98 != uVar21)) {
                  puStack_b8 = (uint *)0x0;
                  (*_DAT_)(1,0xb7d0e8,0xb7bae8,0x381);
                  lVar15 = lStack_70;
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(psVar10 + 8) <= (int)uVar18) ||
                    (*(ushort *)(*(byte **)(psVar10 + 4) + *(uint *)(psVar10 + 8)) <
                     *(ushort *)(puVar2 + 1))) goto LAB_;
          }
          puVar20 = (undefined8 *)((longlong)(int)*puVar2 + *(longlong *)(psVar10 + 4));
          uStack_98 = uVar21;
        }
        else {
          puVar20 = (undefined8 *)0x753db4;
          uStack_98 = 1;
          if ((*(byte *)((longlong)(int)uVar18 + *(longlong *)(psVar10 + 4)) &
              (byte)(1 << ((byte)uVar6 & 7))) == 0) {
            puVar20 = (undefined8 *)0x7543d8;
          }
        }
      }
    }
  }
  else {
    puStack_b8 = &uStack_94;
    uStack_94 = 0;
    puVar20 = (undefined8 *)func_0x(puVar1,puVar2);
    lVar15 = param_1;
    if ((((*psStack_88 != 0) &&
         (plVar3 = *(longlong **)(psStack_88 + 8), lVar15 = param_1, plVar3 != (longlong *)0x0)) &&
        (lVar15 = param_1, *plVar3 != 0)) &&
       ((lVar15 = param_1, (*(byte *)((longlong)puVar2 + 6) & 8) == 0 &&
        (lVar15 = param_1, (uStack_94 & 1) == 0)))) {
      if ((puVar20 == (undefined8 *)0x0) || (puVar20 == (undefined8 *)0x753db4)) goto LAB_;
      uStack_a0 = uStack_94;
      puStack_a8 = &uStack_98;
      puStack_b8 = auStack_60;
      uStack_b0 = 8;
      puVar20 = (undefined8 *)func_0x(plVar3,puVar2,puVar20,uStack_98);
      lVar15 = param_1;
    }
  }
LAB_:
  psVar4 = psStack_88;
  if ((uStack_98 == 0) || (puVar20 == (undefined8 *)0x0)) {
    if (*(longlong *)(param_2 + 4) != 0) {
      *(uint *)(*(longlong *)(param_2 + 2) + 0x268) =
           *(uint *)(*(longlong *)(param_2 + 2) + 0x268) & ~*param_2;
      (**(code **)(***(longlong ***)(param_2 + 4) + 8))();
      *(undefined8 *)(param_2 + 4) = 0;
    }
    uVar19 = *(ulonglong *)(*(longlong *)(lVar15 + 0x280) + 0x14);
    puStack_b8 = (uint *)(((uVar19 >> 0x20 & 0xffff) << 0x20 | uVar19 & 0xffffffff) << 0x10);
    (*_DAT_)(0xdf,0xd,0x10,6);
    goto LAB_;
  }
  *puStack_68 = *puVar20;
  puVar2 = *(uint **)(lVar15 + 0x318);
  bVar5 = *(byte *)(puVar2 + 8);
  if (*psStack_88 == 0) {
    uVar21 = *puVar2;
    if ((uVar21 & 0xc0000000) == 0x80000000) {
      iVar9 = func_0x(puVar1);
      if (iVar9 != 0) {
        puVar20 = (undefined8 *)func_0x(psVar10 + 0x15,puVar2,&uStack_98,auStack_74);
        uVar18 = uStack_98;
        goto LAB_;
      }
LAB_:
      uStack_98 = 0;
      puVar20 = (undefined8 *)0x0;
      uVar18 = uStack_98;
    }
    else {
      if (((bVar5 & 2) != 0) || ((*(byte *)((longlong)puVar2 + 6) & 0x10) != 0)) {
        pbVar22 = *(byte **)(psVar10 + 4);
        if ((*pbVar22 & 0x10) == 0) {
          if ((1 << (*pbVar22 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
          if ((bVar5 & 2) != 0) goto LAB_;
        }
        else {
          uVar18 = *(uint *)(psVar10 + 8);
          if ((int)uVar18 <= (int)uVar21) {
LAB_:
            uVar7 = ~(*(ushort *)((longlong)puVar2 + 6) >> 4) & 1;
            iVar23 = iVar9;
            goto LAB_;
          }
          if ((uint)*(ushort *)(pbVar22 + uVar18) < (uint)*(ushort *)(puVar2 + 1))
          goto LAB_;
          if ((bVar5 & 2) == 0) goto LAB_;
          uVar13 = *(ushort *)(puVar2 + 1) - 1;
          uVar7 = pbVar22[(ulonglong)(uVar13 >> 3) + (ulonglong)uVar18 + 2] >> ((byte)uVar13 & 7) &
                  1;
LAB_:
          if (uVar7 != 0) goto LAB_;
        }
        if ((iVar23 == 0) && ((*(byte *)((longlong)puVar2 + 6) & 0x10) != 0)) {
          puVar20 = (undefined8 *)(*(uint **)(puVar2 + 2) + 1);
          uVar18 = **(uint **)(puVar2 + 2);
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar21 < 0) {
        if (*(int *)(psVar10 + 2) == 0) {
          pbVar22 = *(byte **)(psVar10 + 4);
          uVar18 = *(uint *)(psVar10 + 8);
          uVar19 = (ulonglong)uVar18;
          *puVar1 = 0;
          *(uint *)(psVar10 + 10) = uVar18;
          bVar5 = *pbVar22;
          if ((bVar5 & 0x10) != 0) {
            uVar18 = uVar18 + 2 + (*(ushort *)(pbVar22 + uVar19) + 7 >> 3);
            uVar19 = (ulonglong)uVar18;
            *(uint *)(psVar10 + 10) = uVar18;
            bVar5 = *pbVar22;
          }
          if ((bVar5 & 0x20) == 0) {
            *(int *)(psVar10 + 2) = (int)uVar19;
            psVar10[0xe] = 0;
            *(int *)(psVar10 + 0xc) = (int)uVar19;
          }
          else {
            puVar24 = (ushort *)(pbVar22 + uVar19);
            uVar7 = *puVar24;
            psVar10[0xe] = uVar7;
            if (uVar7 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar15 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar15 != 0)) &&
                 ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  puStack_b8 = (uint *)0x0;
                  (*_DAT_)(1,0x9cf378,0xaef048,0x80f);
                }
              }
              func_0x(*(undefined8 *)(psVar10 + 4),3);
              uVar19 = (ulonglong)*(uint *)(psVar10 + 10);
              uVar7 = psVar10[0xe];
            }
            uVar18 = (int)uVar19 + (uVar7 + 1) * 2;
            *(uint *)(psVar10 + 0xc) = uVar18;
            if (0x1f9e < uVar18) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar15 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar15 != 0 &&
                  ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                   (*(char *)(lVar15 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_b8 = (uint *)0x0;
                  (*_DAT_)(1,0x9cf378,0xaef048,0x816);
                }
              }
              func_0x(*(undefined8 *)(psVar10 + 4),4);
              uVar7 = psVar10[0xe];
              uVar18 = *(uint *)(psVar10 + 0xc);
            }
            uVar19 = (ulonglong)uVar7;
            uVar7 = puVar24[uVar19];
            *(uint *)(psVar10 + 2) = uVar7 & 0x7fff;
            if ((uVar7 & 0x7fff) < uVar18) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar15 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar15 != 0)) &&
                 ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_b8 = (uint *)0x0;
                  (*_DAT_)(1,0x9cf378,0xaef048,0x81d);
                }
              }
              func_0x(*(undefined8 *)(psVar10 + 4),4);
              uVar19 = (ulonglong)(ushort)psVar10[0xe];
            }
            if ((short)puVar24[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
              pbVar22 = *(byte **)(psVar10 + 4);
              do {
                if ((int)uVar19 == 1) {
                  uVar18 = *(uint *)(psVar10 + 0xc);
                  uVar21 = uVar18;
LAB_:
                  if ((*(ushort *)(pbVar22 + uVar19 * 2 + (ulonglong)*(uint *)(psVar10 + 10)) &
                      0x7fff) < uVar18) goto LAB_;
                }
                else {
                  uVar21 = *(uint *)(psVar10 + 0xc);
                  uVar18 = *(ushort *)
                            (pbVar22 + uVar19 * 2 + ((ulonglong)*(uint *)(psVar10 + 10) - 2)) &
                           0x7fff;
                  if (uVar21 <= uVar18) goto LAB_;
LAB_:
                  func_0x(pbVar22,7);
                  uVar21 = *(uint *)(psVar10 + 0xc);
                }
                if ((uVar18 < uVar21) || (*(uint *)(psVar10 + 2) < uVar18)) goto LAB_;
                pbVar22 = *(byte **)(psVar10 + 4);
                if (*(ushort *)(pbVar22 + uVar18) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar10[0xe] = psVar10[0xe] + -1;
                  psVar10[0x15] = (short)uVar18;
                  lVar15 = (ulonglong)(uVar18 & 0xffff) + *(longlong *)(psVar10 + 4);
                  uVar7 = psVar10[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar15 + 2) >> 0xe & 1) != 0) {
                    uVar7 = *(ushort *)(lVar15 + 2) & 0x3800 | psVar10[0x16] & 0xc7ffU;
                  }
                  psVar10[0x16] = uVar7;
                  psVar10[0x16] = (uVar7 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar7;
                  goto LAB_;
                }
                if (*(ushort *)(pbVar22 + uVar18) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar7 = psVar10[0xe] - 1;
                psVar10[0xe] = uVar7;
                if (uVar7 == 0) goto LAB_;
                uVar19 = (ulonglong)uVar7;
              } while ((short)puVar24[(ulonglong)(uVar7 - 1) + 1] < 0);
              uVar19 = (ulonglong)*(uint *)(psVar10 + 2);
            }
            else {
LAB_:
              uVar19 = (ulonglong)*(uint *)(psVar10 + 2);
              pbVar22 = *(byte **)(psVar10 + 4);
            }
          }
          if ((*pbVar22 & 0x40) == 0) {
            *(undefined4 *)(psVar10 + 0x13) = 0;
          }
          else {
            *(int *)(psVar10 + 0x13) = (int)uVar19;
            *(int *)(psVar10 + 2) = (int)uVar19 + 0xe;
            puVar11 = (ulonglong *)func_0x(puVar1);
            uVar6 = (ushort)(*puVar11 >> 0x30);
            uVar7 = uVar6;
            if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
              uVar7 = uVar6 & 0xdfff;
              if ((uVar6 >> 0xe & 1) != 0) {
                uVar7 = uVar6 | 0x2000;
              }
            }
            if (uVar7 == 0xfffc) {
              iVar9 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar10 + 2) = *(int *)(psVar10 + 2) + iVar9;
            uVar19 = (ulonglong)*(uint *)(psVar10 + 2);
          }
          iVar9 = (int)uVar19;
          if ((*(ulonglong *)(psVar10 + 0xf) != 0) &&
             (*(ulonglong *)(psVar10 + 0xf) < uVar19 + *(longlong *)(psVar10 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar15 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar15 != 0 &&
                 (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
                (*(char *)(lVar15 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                puStack_b8 = (uint *)0x0;
                (*_DAT_)(1,0x9cf378,0xaef048,0x877);
              }
            }
            func_0x(*(undefined8 *)(psVar10 + 4),0x12);
            iVar9 = *(int *)(psVar10 + 2);
          }
          if (0x3f3b < iVar9 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar15 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar15 != 0 &&
                ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
                 (*(char *)(lVar15 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                puStack_b8 = (uint *)0x0;
                (*_DAT_)(1,0x9cf378,0xaef048,0x87c);
              }
            }
            func_0x(*(undefined8 *)(psVar10 + 4),5);
          }
        }
LAB_:
        sVar17 = -*(short *)puVar2;
        if ((*(byte *)((longlong)puVar2 + 6) & 0x10) != 0) {
          bVar5 = **(byte **)(psVar10 + 4);
          if ((bVar5 & 0x10) == 0) {
            if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar20 = (undefined8 *)(*(uint **)(puVar2 + 2) + 1);
              uVar18 = **(uint **)(puVar2 + 2);
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(psVar10 + 8) <= (int)*puVar2) ||
                  (*(ushort *)(*(byte **)(psVar10 + 4) + *(uint *)(psVar10 + 8)) <
                   *(ushort *)(puVar2 + 1))) goto LAB_;
        }
        lVar15 = (longlong)sVar17;
        if ((uint)(ushort)psVar10[0xe] < (uint)(int)sVar17) {
          uStack_98 = 0;
          puVar20 = *(undefined8 **)(psVar10 + 4);
          uVar18 = uStack_98;
        }
        else {
          lVar14 = *(longlong *)(psVar10 + 4);
          lVar12 = (ulonglong)*(uint *)(psVar10 + 10) + lVar14;
          if (sVar17 == 1) {
            uVar19 = (ulonglong)*(uint *)(psVar4 + 0xc);
            uVar21 = *(ushort *)(lVar12 + lVar15 * 2) & 0x7fff;
LAB_:
            if (uVar21 < (uint)uVar19) goto LAB_;
          }
          else {
            uVar18 = *(ushort *)(lVar12 + -2 + lVar15 * 2) & 0x7fff;
            uVar19 = (ulonglong)uVar18;
            lVar14 = *(longlong *)(psVar10 + 4);
            uVar21 = *(ushort *)(lVar12 + lVar15 * 2) & 0x7fff;
            if (*(uint *)(psVar4 + 0xc) <= uVar18) goto LAB_;
LAB_:
            func_0x(lVar14,7);
          }
          puVar20 = (undefined8 *)(uVar19 + *(longlong *)(psVar10 + 4));
          uVar18 = uVar21 - (int)uVar19;
        }
      }
      else {
        uVar7 = *(ushort *)((longlong)puVar2 + 6);
        if ((uVar7 & 8) == 0) {
          uVar13 = (uint)*(ushort *)(puVar2 + 0xe);
          if ((uVar7 & 0x10) != 0) {
            bVar5 = **(byte **)(psVar10 + 4);
            if ((bVar5 & 0x10) == 0) {
              if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                uVar18 = **(uint **)(puVar2 + 2);
                puVar20 = (undefined8 *)(*(uint **)(puVar2 + 2) + 1);
                if ((uVar13 != 0) && (uVar18 != uVar13)) {
                  puStack_b8 = (uint *)0x0;
                  (*_DAT_)(1,0xb7d0e8,0xb7bae8,0x381);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(psVar10 + 8) <= (int)uVar21) ||
                    (*(ushort *)(*(byte **)(psVar10 + 4) + *(uint *)(psVar10 + 8)) <
                     *(ushort *)(puVar2 + 1))) goto LAB_;
          }
          puVar20 = (undefined8 *)((longlong)(int)*puVar2 + *(longlong *)(psVar10 + 4));
          uVar18 = uVar13;
        }
        else {
          puVar20 = (undefined8 *)0x753db4;
          uStack_98 = 1;
          uVar18 = uStack_98;
          if ((*(byte *)(*(longlong *)(psVar10 + 4) + (longlong)(int)uVar21) &
              (byte)(1 << ((byte)uVar7 & 7))) == 0) {
            puVar20 = (undefined8 *)0x7543d8;
          }
        }
      }
    }
  }
  else {
    puStack_b8 = auStack_90;
    auStack_90[0] = 0;
    puVar20 = (undefined8 *)func_0x(puVar1,puVar2);
    uVar18 = uStack_98;
    if ((((*psVar4 != 0) && (plVar3 = *(longlong **)(psVar4 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) &&
       (((*(byte *)((longlong)puVar2 + 6) & 8) == 0 && ((auStack_90[0] & 1) == 0)))) {
      if ((puVar20 == (undefined8 *)0x0) || (puVar20 == (undefined8 *)0x753db4)) {
        uStack_98 = 0;
        puVar20 = (undefined8 *)0x0;
        uVar18 = uStack_98;
      }
      else {
        uStack_a0 = auStack_90[0];
        puStack_a8 = &uStack_98;
        puStack_b8 = auStack_60;
        uStack_b0 = 8;
        puVar20 = (undefined8 *)func_0x(plVar3,puVar2,puVar20,uStack_98);
        uVar18 = uStack_98;
      }
    }
  }
LAB_:
  uStack_98 = uVar18;
  if ((uStack_98 == 0) || (puVar20 == (undefined8 *)0x0)) {
    *puStack_80 = 0;
  }
  else {
    *puStack_80 = *(char *)puVar20 == '1';
  }
LAB_:
  func_0x(uStack_58 ^ (ulonglong)auStack_d8);
  return;
}

