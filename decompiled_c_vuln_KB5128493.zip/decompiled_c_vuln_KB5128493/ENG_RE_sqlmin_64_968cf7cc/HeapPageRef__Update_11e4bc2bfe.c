
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,undefined8 *param_3,undefined8 param_4)

{
  byte *pbVar1;
  byte bVar2;
  short sVar3;
  longlong *plVar4;
  longlong lVar5;
  code **ppcVar6;
  longlong lVar7;
  undefined8 uVar8;
  undefined uVar9;
  char cVar10;
  longlong lVar11;
  short *psVar12;
  code *UNRECOVERED_JUMPTABLE_00;
  undefined2 uVar13;
  undefined4 uVar14;
  byte **ppbVar15;
  byte *pbVar16;
  ulonglong uVar17;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  *(ulonglong *)(&stack0x00002510 + lVar11) = _DAT_ ^ (ulonglong)(&stack0x00000060 + lVar11)
  ;
  ppbVar15 = (byte **)0x0;
  *(longlong ***)(&stack0x00000110 + lVar11) = param_1;
  *(undefined8 **)(&stack0x00000140 + lVar11) = *(undefined8 **)(&stack0x000025a8 + lVar11);
  plVar4 = *param_1;
  *(undefined8 *)(&stack0x000001b0 + lVar11) = param_4;
  *(undefined8 **)(&stack0x000000b0 + lVar11) = param_3;
  *(undefined8 *)(&stack0x000000c0 + lVar11) = param_2;
  lVar5 = *plVar4;
  *(undefined2 *)(&stack0x000003a0 + lVar11) = 0xffff;
  *(undefined8 *)(&stack0x000003a8 + lVar11) = 0;
  *(undefined4 *)(&stack0x000003a4 + lVar11) = 0;
  *(undefined8 *)(&stack0x000003be + lVar11) = 0;
  *(undefined8 *)(&stack0x000003c8 + lVar11) = 0;
  *(undefined8 *)(&stack0x000003b0 + lVar11) = 0;
  *(undefined2 *)(&stack0x00000450 + lVar11) = 0xffff;
  *(undefined8 *)(&stack0x00000458 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000454 + lVar11) = 0;
  *(undefined8 *)(&stack0x0000046e + lVar11) = 0;
  *(undefined8 *)(&stack0x00000478 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000460 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000488 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000490 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000068 + lVar11) = **(undefined8 **)(&stack0x000025a8 + lVar11);
  *(undefined4 *)(&stack0x00000118 + lVar11) = 0;
  *(undefined4 *)(&stack0x000000f8 + lVar11) = 0;
  ppcVar6 = (code **)*param_3;
  *(undefined8 *)(&stack0x000000f0 + lVar11) = *(undefined8 *)(&stack0x00002598 + lVar11);
  *(undefined8 *)(&stack0x000000d8 + lVar11) = *(undefined8 *)(&stack0x000025a0 + lVar11);
  *(undefined8 *)(&stack0x000000e8 + lVar11) = 0;
  *(undefined8 *)(&stack0x000000d0 + lVar11) = 0;
  UNRECOVERED_JUMPTABLE_00 = *ppcVar6;
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10010b;
  uVar9 = (*UNRECOVERED_JUMPTABLE_00)(param_3);
  (&stack0x000000a8)[lVar11] = uVar9;
  lVar7 = param_3[6];
  *(longlong *)(&stack0x000001a8 + lVar11) = lVar7;
  *(undefined4 *)(&stack0x000000fc + lVar11) = *(undefined4 *)(&stack0x00002590 + lVar11);
  *(undefined8 *)(&stack0x00000108 + lVar11) = 0;
  uVar9 = *(undefined *)(lVar7 + 0x1cde);
  *(undefined4 *)(&stack0x000003d4 + lVar11) = *(undefined4 *)(&stack0x00002590 + lVar11);
  *(undefined4 *)(&stack0x000000b8 + lVar11) = 9;
  (&stack0x00000060)[lVar11] = uVar9;
  if (-1 < *(char *)(lVar5 + 2)) goto LAB_;
  pbVar16 = (byte *)(lVar5 + 0x60);
  if ((*(short *)(&stack0x000003a0 + lVar11) == 0) ||
     (ppbVar15 = *(byte ***)(&stack0x000003b0 + lVar11), ppbVar15 == (byte **)0x0)) {
    *(undefined (*) [16])(&stack0x00000438 + lVar11) = ZEXT816(0);
    *(undefined8 *)(&stack0x00000448 + lVar11) = 0;
    *(undefined (*) [16])(&stack0x000003e8 + lVar11) = ZEXT816(0);
    *(byte ***)(&stack0x000003f0 + lVar11) = ppbVar15;
    *(undefined (*) [16])(&stack0x000003f8 + lVar11) = ZEXT816(0);
    uVar14 = SUB84(ppbVar15,0);
    *(undefined4 *)(&stack0x000003ec + lVar11) = uVar14;
    *(undefined (*) [16])(&stack0x00000408 + lVar11) = ZEXT816(0);
    *(byte ***)(&stack0x00000406 + lVar11) = ppbVar15;
    *(undefined (*) [16])(&stack0x00000418 + lVar11) = ZEXT816(0);
    *(byte ***)(&stack0x00000410 + lVar11) = ppbVar15;
    *(byte ***)(&stack0x000003f8 + lVar11) = ppbVar15;
    *(byte ***)(&stack0x00000420 + lVar11) = ppbVar15;
    *(undefined4 *)(&stack0x00000438 + lVar11) = uVar14;
    *(undefined4 *)(&stack0x0000043c + lVar11) = uVar14;
    uVar13 = SUB82(ppbVar15,0);
    *(undefined2 *)(&stack0x00000440 + lVar11) = uVar13;
    *(undefined2 *)(&stack0x00000442 + lVar11) = uVar13;
    *(undefined2 *)(&stack0x0000044a + lVar11) = uVar13;
    ppbVar15 = (byte **)(&stack0x000003d8 + lVar11);
    *(undefined (*) [16])(&stack0x000003d8 + lVar11) = ZEXT816(0);
    *(undefined2 *)(&stack0x000003e8 + lVar11) = 0xffff;
    *(undefined (*) [16])(&stack0x00000428 + lVar11) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000003d8 + lVar11) = ZEXT816(0);
  }
  if (*(short *)(lVar5 + 0x24) == 0) {
LAB_:
    *(undefined8 *)(&stack0x00000158 + lVar11) = *(undefined8 *)(lVar5 + 0x28);
    *(undefined2 *)(&stack0x00000160 + lVar11) = *(undefined2 *)(lVar5 + 0x30);
  }
  else {
    cVar10 = *(char *)(lVar5 + 1);
    if (cVar10 == '\v') {
      if (*(int *)(lVar5 + 0x18) != 99) {
LAB_:
        if (cVar10 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar10 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar5 + 0x18) != 99) goto LAB_;
    }
    *(undefined4 *)(&stack0x00000178 + lVar11) = *(undefined4 *)(lVar5 + 0x20);
    *(undefined2 *)(&stack0x0000017c + lVar11) = *(undefined2 *)(lVar5 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10027a;
    cVar10 = func_0x(&stack0x00000178 + lVar11,0x164f778);
    if (cVar10 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10028d;
    func_0x(lVar5,&stack0x00000158 + lVar11);
  }
  *ppbVar15 = pbVar16;
  uVar8 = *(undefined8 *)(&stack0x00000158 + lVar11);
  uVar13 = *(undefined2 *)(&stack0x00000160 + lVar11);
  *(undefined4 *)(ppbVar15 + 0xc) = *(undefined4 *)(&stack0x00000158 + lVar11);
  *(int *)((longlong)ppbVar15 + 100) = (int)((ulonglong)uVar8 >> 0x20);
  *(undefined2 *)(ppbVar15 + 0xd) = uVar13;
  *(undefined4 *)((longlong)ppbVar15 + 0x6c) = *(undefined4 *)(lVar5 + 0x20);
  *(undefined2 *)(ppbVar15 + 0xe) = *(undefined2 *)(lVar5 + 0x24);
  *(undefined2 *)((longlong)ppbVar15 + 0x72) = 0;
  uVar14 = *(undefined4 *)((ulonglong)*pbVar16 * 6 + 0x16cfd80);
  uVar17 = (ulonglong)*(short *)((ulonglong)*pbVar16 * 6 + 0x16cfd84);
  *(undefined2 *)(ppbVar15 + 2) = 0xffff;
  ppbVar15[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar15 + 0x2e) = 0;
  ppbVar15[7] = (byte *)0x0;
  ppbVar15[4] = (byte *)0x0;
  ppbVar15[9] = (byte *)0x0;
  ppbVar15[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar15 + 0xb) = 0;
  *(undefined4 *)(&stack0x00000100 + lVar11) = uVar14;
  if ((**ppbVar15 & 2) != 0) {
    pbVar1 = pbVar16 + uVar17;
    if ((pbVar16[uVar17] & 1) == 0) {
      *(undefined2 *)(ppbVar15 + 2) = 0;
      ppbVar15[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar15 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100566 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x109a88) - 0xe6a0b0))();
      return;
    }
    *(undefined2 *)(ppbVar15 + 2) = 1;
    ppbVar15[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x109a68) * 4 +
                           0x109a58) - 0xe6a0b0);
                    /* WARNING: Could not emulate address calculation at 0x00100367 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar15 & 4) != 0) {
    if (*(short *)(&stack0x00000102 + lVar11) != 0) {
      uVar17 = (ulonglong)
               *(ushort *)(lVar5 + 0x61 + (longlong)*(short *)(&stack0x00000102 + lVar11) * 2);
    }
    psVar12 = (short *)(pbVar16 + uVar17);
    ppbVar15[9] = (byte *)psVar12;
    sVar3 = *psVar12;
    ppbVar15[10] = (byte *)(psVar12 + 1);
    *(short *)(ppbVar15 + 0xb) = (sVar3 + 1) * 2;
  }
  pbVar16 = ppbVar15[1];
  if (pbVar16 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100641;
    func_0x(pbVar16,ppbVar15);
  }
LAB_:
  pbVar16 = (byte *)((ulonglong)
                     *(ushort *)
                      (lVar5 + (0xfff - (longlong)*(int *)(&stack0x000000fc + lVar11)) * 2) + lVar5)
  ;
  bVar2 = *pbVar16;
  *(byte **)(&stack0x000003a8 + lVar11) = pbVar16;
  if ((bVar2 & 1) == 0) {
    *(undefined2 *)(&stack0x000003a0 + lVar11) = 0;
    *(undefined4 *)(&stack0x000003a4 + lVar11) = 0;
    *(undefined4 *)(&stack0x000003c6 + lVar11) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100968 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar16 & 0xe) * 4 + 0x109af4) - 0xe6a0b0))
              ((longlong)(int)(*pbVar16 & 0xe),0x164f778,pbVar16,9);
    return;
  }
  *(undefined2 *)(&stack0x000003a0 + lVar11) = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar16 & 0x1c) + 0x109ad4) * 4 +
                         0x109ac4) - 0xe6a0b0);
                    /* WARNING: Could not emulate address calculation at 0x001006a7 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

