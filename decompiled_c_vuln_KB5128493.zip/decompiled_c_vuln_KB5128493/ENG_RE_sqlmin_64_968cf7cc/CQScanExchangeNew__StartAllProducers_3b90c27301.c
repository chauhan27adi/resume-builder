
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  int *piVar1;
  uint uVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 uVar6;
  longlong lVar7;
  ulonglong uVar8;
  uint uVar9;
  longlong unaff_GS_OFFSET;
  longlong lStack_468;
  undefined4 uStack_460;
  undefined8 uStack_3e0;
  longlong lStack_318;
  longlong lStack_310;
  undefined8 uStack_68;
  longlong lStack_60;
  undefined8 uStack_58;
  
  uStack_68 = 0xfffffffffffffffe;
  uVar8 = 0;
  lVar3 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8) + 0x20);
  lVar7 = *(longlong *)(*(longlong *)(lVar3 + 0x78) + 0x1a8);
  lStack_468 = *(longlong *)(lVar7 + 0x228) + 0x20;
  uStack_460 = 0;
  lStack_318 = lVar3;
  func_0x(&lStack_468,0x400302);
  lVar7 = *(longlong *)(lVar7 + 0x228);
  uVar5 = uVar8;
  if (lVar7 != 0) {
    uVar5 = *(ulonglong *)(lVar7 + 8);
  }
  uStack_3e0 = *(undefined8 *)(uVar5 + 0x28);
  uVar2 = *(uint *)(uVar5 + 0xc);
  lVar7 = *(longlong *)(param_2 + 0x20);
  func_0x(param_2);
  if (*(uint *)(*(longlong *)(param_2 + 0x18) + 0x5c) < uVar2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  LOCK();
  piVar1 = (int *)(*(longlong *)
                    (*(longlong *)
                      (*(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8) + 0x60) + 0x450) + 0x18);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  lVar4 = *(longlong *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8) + 0x60) + 0x450);
  lStack_310 = lVar4;
  func_0x(lVar4);
  if (*(longlong *)(lVar4 + 0x30) == lVar4 + 0x28) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(lVar4);
  uVar5 = uVar8;
  if (*(longlong *)
       ((ulonglong)*_DAT_ +
        *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 0x100
       ) != 0) {
    while ((uint)uVar5 < uVar2) {
      uVar9 = (uint)uVar5 + 1;
      uVar6 = func_0x(param_1,param_2,uVar9);
      *(undefined8 *)(lVar7 + uVar5 * 8) = uVar6;
      uVar5 = (ulonglong)uVar9;
    }
    lStack_60 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
    if (*(longlong *)(*(longlong *)(lStack_60 + 0x228) + 0x18) == 0) {
      uStack_58 = *(undefined8 *)(lStack_60 + 0x1f0);
      uVar6 = SUB168(ZEXT816(8) * ZEXT416(uVar2),0);
      if (SUB168(ZEXT816(8) * ZEXT416(uVar2),8) != 0) {
        uVar6 = 0xffffffffffffffff;
      }
      lVar7 = (*_DAT_)(uVar6,uStack_58,0x24d8550,0x35f,1);
      for (; (uint)uVar8 < uVar2; uVar8 = (ulonglong)((uint)uVar8 + 1)) {
        *(longlong *)(lVar7 + uVar8 * 8) = lVar3;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

