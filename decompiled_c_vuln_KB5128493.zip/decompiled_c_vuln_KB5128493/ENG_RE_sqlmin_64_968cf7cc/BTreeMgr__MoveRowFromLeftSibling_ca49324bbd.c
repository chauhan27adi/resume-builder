
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,undefined8 param_3,undefined4 param_4)

{
  byte **ppbVar1;
  short **ppsVar2;
  undefined uVar3;
  ushort uVar4;
  undefined2 uVar5;
  longlong **pplVar6;
  longlong lVar7;
  char cVar8;
  byte bVar9;
  short sVar10;
  undefined2 uVar11;
  int iVar12;
  int iVar13;
  longlong lVar14;
  ushort *puVar15;
  longlong *plVar16;
  undefined2 *puVar17;
  ulonglong uVar18;
  undefined8 uVar19;
  ulonglong uVar20;
  short *psVar21;
  uint uVar22;
  longlong lVar23;
  longlong lVar24;
  undefined4 *puVar25;
  code *UNRECOVERED_JUMPTABLE_00;
  uint uVar26;
  longlong *plVar27;
  int *piVar28;
  undefined8 *puVar29;
  uint *puVar30;
  longlong *plVar31;
  byte *pbVar32;
  ushort uVar33;
  byte **ppbVar34;
  longlong unaff_GS_OFFSET;
  undefined4 uVar35;
  undefined4 uVar36;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  *(undefined8 *)(&stack0x00001cd0 + lVar14) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00003348 + lVar14) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar14);
  *(undefined4 *)(&stack0x00000454 + lVar14) = param_4;
  *(undefined8 *)(&stack0x00000920 + lVar14) = param_3;
  *(longlong ***)(&stack0x00000a68 + lVar14) = param_2;
  *(longlong *)(&stack0x00000448 + lVar14) = param_1;
  pplVar6 = *(longlong ***)(&stack0x000033c0 + lVar14);
  *(longlong ***)(&stack0x00000a70 + lVar14) = pplVar6;
  *(longlong *)(&stack0x00000d90 + lVar14) = param_1;
  *(longlong ***)(&stack0x00000da0 + lVar14) = param_2;
  *(undefined8 *)(&stack0x00000d88 + lVar14) = *(undefined8 *)(&stack0x000033b8 + lVar14);
  *(longlong ***)(&stack0x00000d98 + lVar14) = pplVar6;
  *(undefined8 *)(&stack0x00000038 + lVar14) = 0;
  (&stack0x00000040)[lVar14] = 0;
  uVar22 = *(uint *)(&stack0x00000044 + lVar14);
  *(uint *)(&stack0x00000044 + lVar14) = uVar22 & 0xffff0000;
  *(uint *)(&stack0x00000044 + lVar14) = uVar22 & 0xff000000;
  *(undefined4 *)(&stack0x00000044 + lVar14) = 0;
  *(undefined2 *)(&stack0x00002710 + lVar14) = 0xffff;
  *(undefined8 *)(&stack0x00002718 + lVar14) = 0;
  *(undefined4 *)(&stack0x00002714 + lVar14) = 0;
  *(undefined8 *)(&stack0x0000272e + lVar14) = 0;
  *(undefined8 *)(&stack0x00002738 + lVar14) = 0;
  *(undefined8 *)(&stack0x00002720 + lVar14) = 0;
  *(undefined4 *)(&stack0x00002744 + lVar14) = 0xffffffff;
  *(undefined (*) [16])(&stack0x00002680 + lVar14) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000058 + lVar14) = 0;
  (&stack0x00000060)[lVar14] = 0;
  uVar22 = *(uint *)(&stack0x00000064 + lVar14);
  *(uint *)(&stack0x00000064 + lVar14) = uVar22 & 0xffff0000;
  *(uint *)(&stack0x00000064 + lVar14) = uVar22 & 0xff000000;
  *(undefined4 *)(&stack0x00000064 + lVar14) = 0;
  plVar27 = *param_2;
  lVar23 = *plVar27;
  *(undefined4 *)(&stack0x0000009c + lVar14) = *(undefined4 *)(lVar23 + 8);
  *(undefined2 *)(&stack0x000000a0 + lVar14) = *(undefined2 *)(lVar23 + 0xc);
  *(undefined4 *)(&stack0x00000180 + lVar14) = *(undefined4 *)(plVar27 + 0xe);
  *(undefined2 *)(&stack0x00000184 + lVar14) = *(undefined2 *)((longlong)plVar27 + 0x74);
  puVar29 = (undefined8 *)**(longlong **)(param_1 + 8);
  *(ulonglong *)(&stack0x00000a60 + lVar14) =
       (ulonglong)*(uint6 *)((longlong)puVar29 + 0x14) << 0x10;
  lVar23 = puVar29[1];
  *(undefined4 *)(&stack0x00000188 + lVar14) = *(undefined4 *)(lVar23 + 0x3c0);
  *(undefined2 *)(&stack0x0000018c + lVar14) = *(undefined2 *)(lVar23 + 0x3c4);
  *(undefined2 *)(&stack0x0000018e + lVar14) = 0;
  uVar35 = 2;
  if (*(int *)(param_1 + 0xfc) == 3) {
    uVar35 = 0;
  }
  *(undefined4 *)(&stack0x00000f30 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000ef8 + lVar14) = 0;
  *(undefined8 **)(&stack0x00000f00 + lVar14) = puVar29;
  UNRECOVERED_JUMPTABLE_00 = *(code **)*puVar29;
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1001e7;
  sVar10 = (*UNRECOVERED_JUMPTABLE_00)(puVar29);
  if (sVar10 == 2) {
    uVar35 = 2;
  }
  *(undefined4 *)(&stack0x00000f34 + lVar14) = uVar35;
  (&stack0x00000053)[lVar14] = 1;
  if ((*(int *)(&stack0x0000009c + lVar14) == 0) && (*(short *)(&stack0x000000a0 + lVar14) == 0)) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100233;
    (*_DAT_)(1,0x1ad6900,0x1aad398,0x13cb);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100243;
  func_0x(param_1,0x1931940);
  *(undefined8 *)(&stack0x00000ef8 + lVar14) = *(undefined8 *)(param_1 + 0x110);
  if (*param_2 != (longlong *)0x0) {
    puVar15 = (ushort *)((longlong)*param_2 + 0x62);
    *(ushort **)(&stack0x00001cd8 + lVar14) = puVar15;
    uVar4 = *puVar15;
    *(ushort *)(&stack0x000001b0 + lVar14) = uVar4;
    if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
      *(int *)(&stack0x00000168 + lVar14) = (int)*(short *)((longlong)param_2 + 0xc);
      plVar27 = *param_2;
      *(longlong **)(&stack0x00000398 + lVar14) = plVar27;
      puVar17 = (undefined2 *)((longlong)plVar27 + 0x62);
      *(undefined2 **)(&stack0x00001ce0 + lVar14) = puVar17;
      uVar11 = *puVar17;
      *(undefined2 *)(&stack0x000001b8 + lVar14) = uVar11;
      if (((byte)uVar11 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000168 + lVar14) == 3) {
          *(undefined4 *)(&stack0x00000168 + lVar14) = 4;
        }
        else if (*(int *)(&stack0x00000168 + lVar14) < 2) goto LAB_;
        *(uint **)(&stack0x00001ce8 + lVar14) =
             (uint *)(*(longlong *)(&stack0x00000398 + lVar14) + 100);
        uVar22 = *(uint *)(*(longlong *)(&stack0x00000398 + lVar14) + 100);
        *(uint *)(&stack0x000007f8 + lVar14) = uVar22;
        if ((((uVar22 & 8) != 0) &&
            (lVar23 = *(longlong *)(*(longlong *)(&stack0x00000398 + lVar14) + 0x90), lVar23 != 0))
           && (*(longlong *)(&stack0x00001cf0 + lVar14) = lVar23, *(longlong *)(lVar23 + 0x758) != 0
              )) {
          uVar19 = *(undefined8 *)(lVar23 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10035a;
          func_0x
                    (uVar19,*(undefined8 *)(&stack0x00000398 + lVar14),
                     *(undefined4 *)(&stack0x00000168 + lVar14));
        }
      }
LAB_:
      (&stack0x00000308)[lVar14] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar30 = (uint *)(*(longlong *)(&stack0x00000398 + lVar14) + 100);
        *(uint **)(&stack0x00001cf8 + lVar14) = puVar30;
        uVar22 = *puVar30;
        *(uint *)(&stack0x00000800 + lVar14) = uVar22;
        if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000168 + lVar14))) {
          *(uint **)(&stack0x00001d00 + lVar14) = puVar30;
          uVar22 = *puVar30;
          *(uint *)(&stack0x00000808 + lVar14) = uVar22;
          if (((uVar22 & 0xc0000000) != 0x40000000) &&
             (lVar23 = **(longlong **)(&stack0x00000398 + lVar14), lVar23 != 0)) {
            *(undefined4 *)(&stack0x00000e04 + lVar14) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1003e9;
            iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000e08 + lVar14);
            if (iVar12 != 0) {
              LOCK();
              *puVar30 = *puVar30 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar30 = *puVar30 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar23 = *(longlong *)(&stack0x00000398 + lVar14);
      uVar35 = *(undefined4 *)(&stack0x00000168 + lVar14);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100418;
      func_0x(lVar23 + 0x98,uVar35);
      if ((_DAT_ != 0) &&
         ((&stack0x00000309)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100442;
        func_0x(lVar23,0,uVar35);
      }
      *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
      *param_2 = (longlong *)0x0;
      param_1 = *(longlong *)(&stack0x00000448 + lVar14);
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100293;
      func_0x(param_2);
    }
  }
  if (*pplVar6 == (longlong *)0x0) {
    plVar27 = *(longlong **)(param_1 + 8);
    *(longlong **)(&stack0x00000a48 + lVar14) = plVar27;
    *(undefined8 *)(&stack0x000008d0 + lVar14) = *(undefined8 *)(param_1 + 0x10);
    *(undefined4 *)(&stack0x000005f8 + lVar14) = 0;
    *(undefined4 *)(&stack0x000005fc + lVar14) = 0;
    *(undefined2 *)(&stack0x00000600 + lVar14) = 0;
    lVar23 = *plVar27;
    *(longlong *)(&stack0x00000cd8 + lVar14) = lVar23;
    *(undefined4 *)(&stack0x00000e9c + lVar14) = 0;
    *(undefined4 *)(&stack0x00000ea0 + lVar14) = 0;
    lVar24 = *(longlong *)(lVar23 + 0x20);
    *(longlong *)(&stack0x00000080 + lVar14) = lVar24;
    *(uint6 **)(&stack0x00001d08 + lVar14) = (uint6 *)(lVar23 + 0x14);
    lVar23 = (ulonglong)*(uint6 *)(lVar23 + 0x14) * 0x10000;
    *(longlong *)(&stack0x00001d10 + lVar14) = lVar23;
    if ((*(longlong *)(lVar24 + 2000) == lVar23) &&
       (*(longlong *)(lVar24 + 2000) - 1U < 0xfffffffffffffffe)) {
      (&stack0x00000088)[lVar14] = 1;
      goto LAB_;
    }
    (&stack0x00000088)[lVar14] = 0;
    if ((*(longlong *)(lVar24 + 0x7d8) == lVar23) &&
       (*(longlong *)(lVar24 + 0x7d8) - 1U < 0xfffffffffffffffe)) {
      (&stack0x00000089)[lVar14] = 1;
      goto LAB_;
    }
    (&stack0x00000089)[lVar14] = 0;
    lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x00001d18 + lVar14) = lVar23;
    lVar24 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x00001d20 + lVar14) = lVar24;
    lVar23 = *(longlong *)(lVar24 + 0x100);
    *(longlong *)(&stack0x00000c98 + lVar14) = lVar23;
    puVar30 = _DAT_;
    if (lVar23 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10059a;
      puVar30 = (uint *)(*_DAT_)(0);
      lVar23 = *(longlong *)(lVar24 + 0x100);
      *(longlong *)(&stack0x00000c98 + lVar14) = lVar23;
    }
    *(longlong *)(&stack0x00001d28 + lVar14) = lVar23;
    uVar20 = rdtsc();
    uVar18 = CONCAT44((int)((ulonglong)puVar30 >> 0x20),(int)uVar20) | uVar20 & 0xffffffff00000000;
    *(ulonglong *)(&stack0x00001d30 + lVar14) = uVar18;
    uVar20 = *(ulonglong *)(lVar23 + 0x340);
    if ((uVar20 < uVar18) ||
       ((uVar20 != 0x7fffffffffffffff &&
        (*(ulonglong *)(*(longlong *)(lVar23 + 0x260) + 0xdf0) < uVar20 - uVar18)))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100663;
      iVar12 = func_0x(0,0x2049690);
      *(int *)(&stack0x00000450 + lVar14) = iVar12;
      if (iVar12 == 2) {
LAB_:
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100676;
        func_0x(0x7c);
      }
    }
    else {
      lVar23 = *(longlong *)(lVar23 + 600);
      *(longlong *)(&stack0x00000ca0 + lVar14) = lVar23;
      puVar30 = (uint *)(lVar23 + 0xbc);
      *(uint **)(&stack0x00001d38 + lVar14) = puVar30;
      if ((*puVar30 & 4) != 0) {
        lVar23 = *(longlong *)(*(longlong *)(&stack0x00000ca0 + lVar14) + 0x98);
        *(longlong *)(&stack0x00001d40 + lVar14) = lVar23;
        if (((*(byte *)(lVar23 + 0x268) & 1) == 0) && ((*(uint *)(lVar23 + 800) & 0x180) == 0)) {
          *(undefined4 *)(&stack0x00000450 + lVar14) = 2;
          goto LAB_;
        }
      }
      *(undefined4 *)(&stack0x00000450 + lVar14) = 0;
    }
    lVar24 = *(longlong *)(&stack0x00000080 + lVar14);
LAB_:
    *(undefined4 *)(&stack0x00000ac0 + lVar14) = 0;
    *(undefined4 *)(&stack0x00000ac4 + lVar14) = 0;
    *(undefined2 *)(&stack0x00000ac8 + lVar14) = 0;
    (&stack0x0000008c)[lVar14] = 0;
    (&stack0x00000050)[lVar14] = 0xff;
    do {
      uVar19 = 0;
      *(undefined **)(&stack0x00000a38 + lVar14) = &stack0x00000e98 + lVar14;
      *(undefined4 *)(&stack0x0000263c + lVar14) = 0;
      *(undefined4 *)(&stack0x00002640 + lVar14) = 0;
      cVar8 = *_DAT_;
      (&stack0x0000030a)[lVar14] = cVar8;
      if ((cVar8 != '\0') &&
         ((&stack0x00000340)[lVar14] = DAT_ >> 7, -1 < (char)DAT_)) {
        *(undefined4 *)(&stack0x00000810 + lVar14) = 0;
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001d48 + lVar14) = lVar23;
        plVar27 = (longlong *)
                  ((ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8)
                  );
        *(longlong **)(&stack0x00001d50 + lVar14) = plVar27;
        lVar23 = *plVar27;
        *(longlong *)(&stack0x00001d58 + lVar14) = lVar23;
        if (lVar23 == 0) {
LAB_:
          *(undefined8 *)(&stack0x00000ca8 + lVar14) = 0;
        }
        else {
          lVar23 = **(longlong **)(lVar23 + 0x38);
          *(longlong *)(&stack0x00001d60 + lVar14) = lVar23;
          if (lVar23 == 0) goto LAB_;
          *(longlong *)(&stack0x00000ca8 + lVar14) = lVar23;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100775;
          iVar12 = (*_DAT_)(lVar23,0x337);
          *(int *)(&stack0x00000810 + lVar14) = iVar12;
          if (iVar12 != 0) {
            lVar24 = *(longlong *)(&stack0x00000080 + lVar14);
            goto LAB_;
          }
        }
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001d68 + lVar14) = lVar23;
        lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00001d70 + lVar14) = lVar23;
        lVar23 = *(longlong *)(lVar23 + 8);
        *(longlong *)(&stack0x00001d78 + lVar14) = lVar23;
        lVar24 = *(longlong *)(&stack0x00000080 + lVar14);
        if (lVar23 != 0) {
          uVar19 = *(undefined8 *)(lVar23 + 0x60);
        }
      }
LAB_:
      *(undefined8 *)(&stack0x00000498 + lVar14) = uVar19;
      plVar27 = (longlong *)(lVar24 + 0x728);
      *(longlong *)(&stack0x00000cb0 + lVar14) = *plVar27;
LAB_:
      *(undefined4 *)(&stack0x0000030c + lVar14) = 0;
      if (*pplVar6 != (longlong *)0x0) {
        puVar15 = (ushort *)((longlong)*pplVar6 + 0x62);
        *(ushort **)(&stack0x00001d80 + lVar14) = puVar15;
        uVar4 = *puVar15;
        *(ushort *)(&stack0x000001c0 + lVar14) = uVar4;
        if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)pplVar6 + 0xc) < 3)) {
          *(int *)(&stack0x00000170 + lVar14) = (int)*(short *)((longlong)pplVar6 + 0xc);
          plVar16 = *pplVar6;
          *(longlong **)(&stack0x000003a0 + lVar14) = plVar16;
          puVar17 = (undefined2 *)((longlong)plVar16 + 0x62);
          *(undefined2 **)(&stack0x00001d88 + lVar14) = puVar17;
          uVar11 = *puVar17;
          *(undefined2 *)(&stack0x000001c8 + lVar14) = uVar11;
          if (((byte)uVar11 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x00000170 + lVar14) == 3) {
              *(undefined4 *)(&stack0x00000170 + lVar14) = 4;
            }
            else if (*(int *)(&stack0x00000170 + lVar14) < 2) goto LAB_;
            *(uint **)(&stack0x00001d90 + lVar14) =
                 (uint *)(*(longlong *)(&stack0x000003a0 + lVar14) + 100);
            uVar22 = *(uint *)(*(longlong *)(&stack0x000003a0 + lVar14) + 100);
            *(uint *)(&stack0x00000818 + lVar14) = uVar22;
            if ((((uVar22 & 8) != 0) &&
                (lVar23 = *(longlong *)(*(longlong *)(&stack0x000003a0 + lVar14) + 0x90),
                lVar23 != 0)) &&
               (*(longlong *)(&stack0x00001d98 + lVar14) = lVar23,
               *(longlong *)(lVar23 + 0x758) != 0)) {
              uVar19 = *(undefined8 *)(lVar23 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100914;
              func_0x
                        (uVar19,*(undefined8 *)(&stack0x000003a0 + lVar14),
                         *(undefined4 *)(&stack0x00000170 + lVar14));
            }
          }
LAB_:
          (&stack0x00000341)[lVar14] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar30 = (uint *)(*(longlong *)(&stack0x000003a0 + lVar14) + 100);
            *(uint **)(&stack0x00001da0 + lVar14) = puVar30;
            uVar22 = *puVar30;
            *(uint *)(&stack0x00000820 + lVar14) = uVar22;
            if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000170 + lVar14))) {
              *(uint **)(&stack0x00001da8 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x00000828 + lVar14) = uVar22;
              if (((uVar22 & 0xc0000000) != 0x40000000) &&
                 (lVar23 = **(longlong **)(&stack0x000003a0 + lVar14), lVar23 != 0)) {
                *(undefined4 *)(&stack0x00000e0c + lVar14) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1009a7;
                iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000e10 + lVar14);
                if (iVar12 != 0) {
                  LOCK();
                  *puVar30 = *puVar30 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar30 = *puVar30 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar23 = *(longlong *)(&stack0x000003a0 + lVar14);
          uVar35 = *(undefined4 *)(&stack0x00000170 + lVar14);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1009d6;
          func_0x(lVar23 + 0x98,uVar35);
          if ((_DAT_ != 0) &&
             ((&stack0x00000350)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100a00;
            func_0x(lVar23,0,uVar35);
          }
          *(uint *)((longlong)pplVar6 + 0xc) = *(uint *)((longlong)pplVar6 + 0xc) & 0xffff0000;
          *pplVar6 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1007f1;
          func_0x(pplVar6);
        }
        lVar24 = *(longlong *)(&stack0x00000080 + lVar14);
      }
      if (*plVar27 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100a33;
        func_0x(pplVar6,&stack0x0000009c + lVar14,lVar24);
        if (*pplVar6 != (longlong *)0x0) {
          puVar15 = (ushort *)((longlong)*pplVar6 + 0x62);
          *(ushort **)(&stack0x00001db0 + lVar14) = puVar15;
          uVar4 = *puVar15;
          *(ushort *)(&stack0x000001d0 + lVar14) = uVar4;
          if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)pplVar6 + 0xc) < 3)) {
            *(int *)(&stack0x00000118 + lVar14) = (int)*(short *)((longlong)pplVar6 + 0xc);
            plVar16 = *pplVar6;
            *(longlong **)(&stack0x000003a8 + lVar14) = plVar16;
            puVar17 = (undefined2 *)((longlong)plVar16 + 0x62);
            *(undefined2 **)(&stack0x00001db8 + lVar14) = puVar17;
            uVar11 = *puVar17;
            *(undefined2 *)(&stack0x000002c8 + lVar14) = uVar11;
            if (((byte)uVar11 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x00000118 + lVar14) == 3) {
                *(undefined4 *)(&stack0x00000118 + lVar14) = 4;
              }
              else if (*(int *)(&stack0x00000118 + lVar14) < 2) goto LAB_;
              *(uint **)(&stack0x00001dc0 + lVar14) =
                   (uint *)(*(longlong *)(&stack0x000003a8 + lVar14) + 100);
              uVar22 = *(uint *)(*(longlong *)(&stack0x000003a8 + lVar14) + 100);
              *(uint *)(&stack0x00000830 + lVar14) = uVar22;
              if ((((uVar22 & 8) != 0) &&
                  (lVar23 = *(longlong *)(*(longlong *)(&stack0x000003a8 + lVar14) + 0x90),
                  lVar23 != 0)) &&
                 (*(longlong *)(&stack0x00001dc8 + lVar14) = lVar23,
                 *(longlong *)(lVar23 + 0x758) != 0)) {
                uVar19 = *(undefined8 *)(lVar23 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100b33;
                func_0x
                          (uVar19,*(undefined8 *)(&stack0x000003a8 + lVar14),
                           *(undefined4 *)(&stack0x00000118 + lVar14));
              }
            }
LAB_:
            (&stack0x00000351)[lVar14] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar30 = (uint *)(*(longlong *)(&stack0x000003a8 + lVar14) + 100);
              *(uint **)(&stack0x00001dd0 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x00000838 + lVar14) = uVar22;
              if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000118 + lVar14))) {
                *(uint **)(&stack0x00001dd8 + lVar14) = puVar30;
                uVar22 = *puVar30;
                *(uint *)(&stack0x00000840 + lVar14) = uVar22;
                if (((uVar22 & 0xc0000000) != 0x40000000) &&
                   (lVar23 = **(longlong **)(&stack0x000003a8 + lVar14), lVar23 != 0)) {
                  *(undefined4 *)(&stack0x00000e14 + lVar14) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100bc6;
                  iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000e18 + lVar14);
                  if (iVar12 != 0) {
                    LOCK();
                    *puVar30 = *puVar30 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar30 = *puVar30 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar23 = *(longlong *)(&stack0x000003a8 + lVar14);
            uVar35 = *(undefined4 *)(&stack0x00000118 + lVar14);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100bf5;
            func_0x(lVar23 + 0x98,uVar35);
            if ((_DAT_ != 0) &&
               ((&stack0x00000352)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100c1f;
              func_0x(lVar23,0,uVar35);
            }
            *(uint *)((longlong)pplVar6 + 0xc) = *(uint *)((longlong)pplVar6 + 0xc) & 0xffff0000;
            *pplVar6 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100a6d;
            func_0x(pplVar6);
          }
          lVar24 = *(longlong *)(&stack0x00000080 + lVar14);
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100c45;
      func_0x(lVar24,&stack0x0000009c + lVar14);
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) =
           *(undefined8 *)(&stack0x00000a38 + lVar14);
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 4;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100c79;
      plVar16 = (longlong *)
                func_0x
                          (_DAT_,lVar24,&stack0x0000009c + lVar14,&stack0x0000030c + lVar14)
      ;
      *pplVar6 = plVar16;
      uVar22 = *(uint *)((longlong)pplVar6 + 0xc) & 0xffff0004 | 4;
      *(uint *)((longlong)pplVar6 + 0xc) = uVar22;
      if (*(longlong *)(&stack0x00000498 + lVar14) != 0) {
        lVar23 = *plVar16;
        *(longlong *)(&stack0x00001de0 + lVar14) = lVar23;
        plVar31 = (longlong *)(*(longlong *)(&stack0x00000498 + lVar14) + 0x500);
        *(longlong **)(&stack0x00001de8 + lVar14) = plVar31;
        plVar16 = plVar31 + (ulonglong)(*(uint *)plVar31 & 0xf) + 1;
        *(longlong **)(&stack0x00001df0 + lVar14) = plVar16;
        if (*plVar16 != lVar23) {
          *plVar16 = lVar23;
          *plVar31 = *plVar31 + 1;
          uVar22 = *(uint *)((longlong)pplVar6 + 0xc);
        }
      }
      uVar26 = *(uint *)(&stack0x0000030c + lVar14) >> 3 & 1;
      *(uint *)((longlong)pplVar6 + 0xc) = uVar26 << 0x18 | uVar22 & 0xffffff;
      *(uint *)(pplVar6 + 2) =
           *(uint *)(&stack0x0000030c + lVar14) >> 4 & 1 | *(uint *)(pplVar6 + 2) & 0xffffff00;
      lVar23 = *(longlong *)(&stack0x00000cb0 + lVar14);
      if (((lVar23 != 0) && (*(longlong *)(&stack0x00000498 + lVar14) != 0)) &&
         (*(longlong *)(&stack0x00000498 + lVar14) == *(longlong *)(lVar24 + 0x1c38))) {
        *(uint *)(&stack0x00000e20 + lVar14) = uVar26;
        *(longlong *)(&stack0x00001df8 + lVar14) = lVar23 + 0x59b8;
        *(longlong *)(lVar23 + 0x5b28) = *(longlong *)(lVar23 + 0x5b28) + 1;
        puVar30 = *(uint **)(&stack0x00000a38 + lVar14);
        if (puVar30[1] != 0) {
          *(longlong *)(lVar23 + 0x5b30) = *(longlong *)(lVar23 + 0x5b30) + 1;
          *(longlong *)(lVar23 + 0x5b38) = *(longlong *)(lVar23 + 0x5b38) + (ulonglong)*puVar30;
          if (uVar26 != 0) {
            *(longlong *)(lVar23 + 0x5b40) = *(longlong *)(lVar23 + 0x5b40) + 1;
            *(longlong *)(lVar23 + 0x5b48) = *(longlong *)(lVar23 + 0x5b48) + (ulonglong)*puVar30;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d92;
      cVar8 = func_0x(lVar24);
      if ((cVar8 == '\0') || (*(char *)(lVar24 + 0x2050) == '\0')) goto LAB_;
      if (*(int *)(&stack0x0000009c + lVar14) == 0) {
LAB_:
        (&stack0x0000008e)[lVar14] = 1;
        goto LAB_;
      }
      *(undefined4 *)(&stack0x00000a80 + lVar14) = 9;
      *(undefined2 *)(&stack0x00000a84 + lVar14) = 1;
      if ((*(int *)(&stack0x0000009c + lVar14) == 9) && (*(short *)(&stack0x000000a0 + lVar14) == 1)
         ) goto LAB_;
      (&stack0x0000008e)[lVar14] = 0;
      lVar23 = **pplVar6;
      *(longlong *)(&stack0x00001e00 + lVar14) = lVar23;
      (&stack0x0000008a)[lVar14] = 0;
      if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
        *(undefined8 *)(&stack0x00000508 + lVar14) = *(undefined8 *)(lVar23 + 0x28);
        *(undefined2 *)(&stack0x00000510 + lVar14) = *(undefined2 *)(lVar23 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar23 + 1);
        if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) &&
           (*(int *)(lVar23 + 0x18) == 99)) {
          *(undefined **)(&stack0x00001e08 + lVar14) = &stack0x00000598 + lVar14;
          *(undefined4 **)(&stack0x00001e10 + lVar14) = (undefined4 *)(lVar23 + 0x20);
          *(undefined4 *)(&stack0x00000598 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
          *(undefined2 *)(&stack0x0000059c + lVar14) = *(undefined2 *)(lVar23 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e5e;
          cVar8 = func_0x(&stack0x00000598 + lVar14);
          if (cVar8 == '\0') goto LAB_;
          cVar8 = '\x01';
        }
        else {
LAB_:
          cVar8 = '\0';
        }
        (&stack0x0000008a)[lVar14] = cVar8;
        if (cVar8 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e83;
        func_0x(lVar23,&stack0x00000508 + lVar14);
      }
      *(undefined **)(&stack0x00001e18 + lVar14) = &stack0x00000508 + lVar14;
      *(longlong *)(&stack0x00000cb8 + lVar14) = lVar24 + 0x20fc;
      *(undefined4 *)(&stack0x00000458 + lVar14) = 0;
      *(undefined4 *)(&stack0x0000045c + lVar14) = 0;
      *(undefined2 *)(&stack0x00000460 + lVar14) = 0;
      *(undefined2 *)(&stack0x00000462 + lVar14) = 0;
      puVar30 = (uint *)(lVar24 + 0x2108);
      *(uint **)(&stack0x00001e20 + lVar14) = puVar30;
      uVar22 = *puVar30;
      *(uint *)(&stack0x00000480 + lVar14) = uVar22;
      *(uint **)(&stack0x00000cc0 + lVar14) = puVar30;
      do {
        *(uint *)(&stack0x00000848 + lVar14) = uVar22 & 0xfffffffe;
        *(undefined8 *)(&stack0x00000458 + lVar14) = **(undefined8 **)(&stack0x00000cb8 + lVar14);
        *(undefined4 *)(&stack0x00000460 + lVar14) =
             *(undefined4 *)(*(undefined8 **)(&stack0x00000cb8 + lVar14) + 1);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14);
        UNLOCK();
        uVar22 = **(uint **)(&stack0x00000cc0 + lVar14);
        *(uint *)(&stack0x00000480 + lVar14) = uVar22;
      } while (*(uint *)(&stack0x00000848 + lVar14) != uVar22);
      if ((*(uint *)(&stack0x00000508 + lVar14) <= *(uint *)(&stack0x00000458 + lVar14)) &&
         ((*(uint *)(&stack0x00000458 + lVar14) != *(uint *)(&stack0x00000508 + lVar14) ||
          ((uVar22 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000458 + lVar14) >> 0x20),
           *(uint *)(&stack0x0000050c + lVar14) <= uVar22 &&
           ((uVar22 != *(uint *)(&stack0x0000050c + lVar14) ||
            (*(ushort *)(&stack0x00000510 + lVar14) <= *(ushort *)(&stack0x00000460 + lVar14))))))))
         ) goto LAB_;
      if (*(char *)(*(longlong *)(&stack0x00000080 + lVar14) + 0x6ac8) != '\0') {
LAB_:
        if ((&stack0x0000008c)[lVar14] != '\0') goto LAB_;
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001080 + lVar14) = lVar23;
        lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00001088 + lVar14) = lVar23;
        lVar23 = *(longlong *)(lVar23 + 8);
        *(longlong *)(&stack0x00001090 + lVar14) = lVar23;
        lVar23 = *(longlong *)(lVar23 + 0x60);
        *(longlong *)(&stack0x00001098 + lVar14) = lVar23;
        lVar24 = *(longlong *)(&stack0x00000080 + lVar14);
        if (lVar23 == *(longlong *)(lVar24 + 0x2120)) goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1016a0;
        cVar8 = func_0x(lVar24);
        if (cVar8 != '\0') goto LAB_;
        if (*(longlong *)(&stack0x00000498 + lVar14) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1016b8;
          uVar19 = func_0x();
          *(undefined8 *)(&stack0x00000498 + lVar14) = uVar19;
        }
        *(undefined **)(&stack0x000010a0 + lVar14) = &stack0x00000528 + lVar14;
        lVar23 = **pplVar6;
        *(longlong *)(&stack0x000010a8 + lVar14) = lVar23;
        (&stack0x0000008d)[lVar14] = 0;
        if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
          uVar19 = *(undefined8 *)(lVar23 + 0x28);
          uVar35 = (undefined4)uVar19;
          uVar36 = (undefined4)((ulonglong)uVar19 >> 0x20);
          *(undefined8 *)(&stack0x00000528 + lVar14) = uVar19;
          uVar11 = *(undefined2 *)(lVar23 + 0x30);
          *(undefined2 *)(&stack0x00000530 + lVar14) = uVar11;
        }
        else {
          cVar8 = *(char *)(lVar23 + 1);
          if (((cVar8 == '\v') && (*(int *)(lVar23 + 0x18) == 99)) ||
             (((cVar8 == '\b' || (cVar8 == '\t')) && (*(int *)(lVar23 + 0x18) == 99)))) {
            *(undefined **)(&stack0x000010b0 + lVar14) = &stack0x00000560 + lVar14;
            *(undefined4 **)(&stack0x000010b8 + lVar14) = (undefined4 *)(lVar23 + 0x20);
            *(undefined4 *)(&stack0x00000560 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
            *(undefined2 *)(&stack0x00000564 + lVar14) = *(undefined2 *)(lVar23 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101750;
            cVar8 = func_0x(&stack0x00000560 + lVar14);
            if (cVar8 == '\0') goto LAB_;
            cVar8 = '\x01';
          }
          else {
LAB_:
            cVar8 = '\0';
          }
          (&stack0x0000008d)[lVar14] = cVar8;
          if (cVar8 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101775;
          func_0x(lVar23,&stack0x00000528 + lVar14);
          uVar11 = *(undefined2 *)(&stack0x00000530 + lVar14);
          uVar35 = (undefined4)*(undefined8 *)(&stack0x00000528 + lVar14);
          uVar36 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x00000528 + lVar14) >> 0x20);
        }
        *(undefined **)(&stack0x000010c0 + lVar14) = &stack0x00000528 + lVar14;
        *(ulonglong *)(&stack0x00000628 + lVar14) = CONCAT44(uVar36,uVar35);
        *(undefined2 *)(&stack0x00000630 + lVar14) = uVar11;
        *(undefined2 *)(&stack0x00000632 + lVar14) = 0;
        if (*pplVar6 != (longlong *)0x0) {
          puVar15 = (ushort *)((longlong)*pplVar6 + 0x62);
          *(ushort **)(&stack0x000010c8 + lVar14) = puVar15;
          uVar4 = *puVar15;
          *(ushort *)(&stack0x000001d8 + lVar14) = uVar4;
          if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)pplVar6 + 0xc) < 3)) {
            *(int *)(&stack0x000000a8 + lVar14) = (int)*(short *)((longlong)pplVar6 + 0xc);
            plVar16 = *pplVar6;
            *(longlong **)(&stack0x000003b0 + lVar14) = plVar16;
            puVar17 = (undefined2 *)((longlong)plVar16 + 0x62);
            *(undefined2 **)(&stack0x000010d0 + lVar14) = puVar17;
            uVar11 = *puVar17;
            *(undefined2 *)(&stack0x000001e0 + lVar14) = uVar11;
            if (((byte)uVar11 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000a8 + lVar14) == 3) {
                *(undefined4 *)(&stack0x000000a8 + lVar14) = 4;
              }
              else if (*(int *)(&stack0x000000a8 + lVar14) < 2) goto LAB_;
              *(uint **)(&stack0x000010d8 + lVar14) =
                   (uint *)(*(longlong *)(&stack0x000003b0 + lVar14) + 100);
              uVar22 = *(uint *)(*(longlong *)(&stack0x000003b0 + lVar14) + 100);
              *(uint *)(&stack0x00000858 + lVar14) = uVar22;
              if ((((uVar22 & 8) != 0) &&
                  (lVar23 = *(longlong *)(*(longlong *)(&stack0x000003b0 + lVar14) + 0x90),
                  lVar23 != 0)) &&
                 (*(longlong *)(&stack0x000010e0 + lVar14) = lVar23,
                 *(longlong *)(lVar23 + 0x758) != 0)) {
                uVar19 = *(undefined8 *)(lVar23 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1018d1;
                func_0x
                          (uVar19,*(undefined8 *)(&stack0x000003b0 + lVar14),
                           *(undefined4 *)(&stack0x000000a8 + lVar14));
              }
            }
LAB_:
            (&stack0x00000353)[lVar14] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar30 = (uint *)(*(longlong *)(&stack0x000003b0 + lVar14) + 100);
              *(uint **)(&stack0x000010e8 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x00000860 + lVar14) = uVar22;
              if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000a8 + lVar14))) {
                *(uint **)(&stack0x000010f0 + lVar14) = puVar30;
                uVar22 = *puVar30;
                *(uint *)(&stack0x00000868 + lVar14) = uVar22;
                if (((uVar22 & 0xc0000000) != 0x40000000) &&
                   (lVar23 = **(longlong **)(&stack0x000003b0 + lVar14), lVar23 != 0)) {
                  *(undefined4 *)(&stack0x00000e34 + lVar14) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101964;
                  iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000e40 + lVar14);
                  if (iVar12 != 0) {
                    LOCK();
                    *puVar30 = *puVar30 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar30 = *puVar30 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar23 = *(longlong *)(&stack0x000003b0 + lVar14);
            uVar35 = *(undefined4 *)(&stack0x000000a8 + lVar14);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101993;
            func_0x(lVar23 + 0x98,uVar35);
            if ((_DAT_ != 0) &&
               ((&stack0x00000354)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1019bd;
              func_0x(lVar23,0,uVar35);
            }
            *(uint *)((longlong)pplVar6 + 0xc) = *(uint *)((longlong)pplVar6 + 0xc) & 0xffff0000;
            *pplVar6 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10180c;
            func_0x(pplVar6);
          }
          uVar35 = (undefined4)*(undefined8 *)(&stack0x00000628 + lVar14);
          uVar36 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x00000628 + lVar14) >> 0x20);
          uVar11 = *(undefined2 *)(&stack0x00000630 + lVar14);
          lVar24 = *(longlong *)(&stack0x00000080 + lVar14);
        }
        *(undefined **)(&stack0x000010f8 + lVar14) = &stack0x00000ae0 + lVar14;
        *(ulonglong *)(&stack0x00000ae0 + lVar14) = CONCAT44(uVar36,uVar35);
        *(undefined2 *)(&stack0x00000ae8 + lVar14) = uVar11;
        *(undefined **)(&stack0x00001100 + lVar14) = &stack0x00000a00 + lVar14;
        *(ulonglong *)(&stack0x00000a00 + lVar14) = CONCAT44(uVar36,uVar35);
        *(undefined2 *)(&stack0x00000a08 + lVar14) = uVar11;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
        lVar23 = *plVar27;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a47;
        func_0x(lVar23,&stack0x00000a00 + lVar14,4);
        goto LAB_;
      }
      lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00001e28 + lVar14) = lVar23;
      lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00001e30 + lVar14) = lVar23;
      lVar23 = *(longlong *)(lVar23 + 8);
      *(longlong *)(&stack0x00001e38 + lVar14) = lVar23;
      lVar23 = *(longlong *)(lVar23 + 0x60);
      *(longlong *)(&stack0x00001e40 + lVar14) = lVar23;
      if (lVar23 == *(longlong *)(*(longlong *)(&stack0x00000080 + lVar14) + 0x2120))
      goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10100a;
      cVar8 = func_0x(*(longlong *)(&stack0x00000080 + lVar14));
      if (cVar8 != '\0') goto LAB_;
      *(longlong *)(&stack0x00000a40 + lVar14) = lVar24 + 0x20fc;
      *(undefined4 *)(&stack0x00000424 + lVar14) = 0;
      *(undefined4 *)(&stack0x00000428 + lVar14) = 0;
      *(undefined2 *)(&stack0x0000042c + lVar14) = 0;
      *(undefined2 *)(&stack0x0000042e + lVar14) = 0;
      *(uint **)(&stack0x00001e48 + lVar14) = puVar30;
      uVar22 = *puVar30;
      *(uint *)(&stack0x0000047c + lVar14) = uVar22;
      puVar29 = *(undefined8 **)(&stack0x00000a40 + lVar14);
      *(longlong *)(&stack0x00000cc8 + lVar14) = (longlong)puVar29 + 0xc;
      while( true ) {
        *(uint *)(&stack0x0000084c + lVar14) = uVar22 & 0xfffffffe;
        *(undefined8 *)(&stack0x00000424 + lVar14) = *puVar29;
        *(undefined4 *)(&stack0x0000042c + lVar14) = *(undefined4 *)(puVar29 + 1);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14);
        UNLOCK();
        uVar22 = **(uint **)(&stack0x00000cc8 + lVar14);
        *(uint *)(&stack0x0000047c + lVar14) = uVar22;
        if (*(uint *)(&stack0x0000084c + lVar14) == uVar22) break;
        puVar29 = *(undefined8 **)(&stack0x00000a40 + lVar14);
      }
      *(undefined8 *)(&stack0x00000ad0 + lVar14) = *(undefined8 *)(&stack0x00000424 + lVar14);
      uVar4 = *(ushort *)(&stack0x0000042c + lVar14);
      *(ushort *)(&stack0x00000ad8 + lVar14) = uVar4;
      lVar23 = **pplVar6;
      *(longlong *)(&stack0x00001e50 + lVar14) = lVar23;
      (&stack0x0000008b)[lVar14] = 0;
      if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
        *(undefined8 *)(&stack0x00000518 + lVar14) = *(undefined8 *)(lVar23 + 0x28);
        uVar33 = *(ushort *)(lVar23 + 0x30);
        *(ushort *)(&stack0x00000520 + lVar14) = uVar33;
      }
      else {
        cVar8 = *(char *)(lVar23 + 1);
        if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) &&
           (*(int *)(lVar23 + 0x18) == 99)) {
          *(undefined **)(&stack0x00000fe8 + lVar14) = &stack0x00000558 + lVar14;
          *(undefined4 **)(&stack0x00000ff0 + lVar14) = (undefined4 *)(lVar23 + 0x20);
          *(undefined4 *)(&stack0x00000558 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
          *(undefined2 *)(&stack0x0000055c + lVar14) = *(undefined2 *)(lVar23 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101143;
          cVar8 = func_0x(&stack0x00000558 + lVar14);
          if (cVar8 == '\0') goto LAB_;
          cVar8 = '\x01';
        }
        else {
LAB_:
          cVar8 = '\0';
        }
        (&stack0x0000008b)[lVar14] = cVar8;
        if (cVar8 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101168;
        func_0x(lVar23,&stack0x00000518 + lVar14);
        uVar33 = *(ushort *)(&stack0x00000520 + lVar14);
      }
      if ((*(uint *)(&stack0x00000424 + lVar14) < *(uint *)(&stack0x00000518 + lVar14)) ||
         ((*(uint *)(&stack0x00000424 + lVar14) == *(uint *)(&stack0x00000518 + lVar14) &&
          ((uVar22 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000518 + lVar14) >> 0x20),
           *(uint *)(&stack0x00000428 + lVar14) < uVar22 ||
           ((*(uint *)(&stack0x00000428 + lVar14) == uVar22 && (uVar4 < uVar33)))))))) {
        lVar23 = *(longlong *)(&stack0x00000080 + lVar14);
        lVar24 = *(longlong *)(lVar23 + 0x6b0);
        *(longlong *)(&stack0x00000ff8 + lVar14) = lVar24;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1011ff;
        func_0x(&stack0x00000518 + lVar14,&stack0x000027c0 + lVar14,
                        &stack0x00000850 + lVar14);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10121c;
        func_0x(&stack0x00000ad0 + lVar14,&stack0x000027f0 + lVar14,
                        &stack0x00000850 + lVar14);
        *(undefined4 *)(&stack0x00000cd0 + lVar14) = 0x1d;
        *(undefined4 *)(&stack0x00000cd4 + lVar14) = 0x10000;
        if ((_DAT_ & 0x10000) != 0) {
          *(undefined2 *)(&stack0x00000748 + lVar14) = 6;
          *(undefined **)(&stack0x00001000 + lVar14) = &stack0x00001e60 + lVar14;
          *(undefined2 *)(&stack0x00001e60 + lVar14) = 0;
          *(undefined2 *)(&stack0x00001e62 + lVar14) = 6;
          *(undefined4 *)(&stack0x00001e68 + lVar14) = 0;
          *(undefined **)(&stack0x00001e70 + lVar14) = &stack0x00001e88 + lVar14;
          *(undefined **)(&stack0x00001e78 + lVar14) = &stack0x00001ee8 + lVar14;
          *(undefined4 *)(&stack0x000020a8 + lVar14) = 0;
          *(undefined4 *)(&stack0x000020ac + lVar14) = 0;
          *(undefined8 *)(&stack0x00001e80 + lVar14) = 0;
          *(undefined8 *)(&stack0x000020b0 + lVar14) = 0;
          *(undefined **)(&stack0x00001008 + lVar14) = &stack0x00001e88 + lVar14;
          *(undefined **)(&stack0x00001e88 + lVar14) = &stack0x000020b8 + lVar14;
          *(undefined4 *)(&stack0x00001e90 + lVar14) = 0x34;
          *(undefined2 *)(&stack0x00001e94 + lVar14) = 5;
          *(undefined2 *)(&stack0x00001e96 + lVar14) = 0;
          *(undefined **)(&stack0x00001010 + lVar14) = &stack0x00001e98 + lVar14;
          *(undefined8 *)(&stack0x00001e98 + lVar14) = 0x1855488;
          *(undefined4 *)(&stack0x00001ea0 + lVar14) = 0x10;
          *(undefined2 *)(&stack0x00001ea4 + lVar14) = 5;
          *(undefined2 *)(&stack0x00001ea6 + lVar14) = 0;
          *(undefined **)(&stack0x00001018 + lVar14) = &stack0x00001ea8 + lVar14;
          *(undefined8 *)(&stack0x00001ea8 + lVar14) = 0x1855488;
          *(undefined4 *)(&stack0x00001eb0 + lVar14) = 0x10;
          *(undefined2 *)(&stack0x00001eb4 + lVar14) = 6;
          *(undefined2 *)(&stack0x00001eb6 + lVar14) = 0;
          *(undefined **)(&stack0x00001020 + lVar14) = &stack0x00001eb8 + lVar14;
          *(undefined8 *)(&stack0x00001eb8 + lVar14) = 0;
          *(undefined4 *)(&stack0x00001ec0 + lVar14) = 0;
          *(undefined2 *)(&stack0x00001ec4 + lVar14) = 7;
          *(undefined2 *)(&stack0x00001ec6 + lVar14) = 0;
          *(undefined **)(&stack0x00001028 + lVar14) = &stack0x00001ec8 + lVar14;
          *(undefined8 *)(&stack0x00001ec8 + lVar14) = 0;
          *(undefined4 *)(&stack0x00001ed0 + lVar14) = 0;
          *(undefined2 *)(&stack0x00001ed4 + lVar14) = 8;
          *(undefined2 *)(&stack0x00001ed6 + lVar14) = 0;
          *(undefined **)(&stack0x00001030 + lVar14) = &stack0x00001ed8 + lVar14;
          *(undefined8 *)(&stack0x00001ed8 + lVar14) = 0;
          *(undefined4 *)(&stack0x00001ee0 + lVar14) = 0;
          *(undefined2 *)(&stack0x00001ee4 + lVar14) = 9;
          *(undefined2 *)(&stack0x00001ee6 + lVar14) = 0;
          *(uint *)(&stack0x000020b8 + lVar14) = (uint)*(ushort *)(lVar23 + 0x6b8);
          *(undefined2 *)(&stack0x000020bc + lVar14) = *(undefined2 *)(&stack0x000000a0 + lVar14);
          *(undefined4 *)(&stack0x000020be + lVar14) = *(undefined4 *)(&stack0x0000009c + lVar14);
          (&stack0x000020c2)[lVar14] = (&stack0x00000050)[lVar14];
          lVar23 = **pplVar6;
          *(longlong *)(&stack0x00001038 + lVar14) = lVar23;
          (&stack0x000020c3)[lVar14] = *(undefined *)(lVar23 + 1);
          *(undefined **)(&stack0x00001040 + lVar14) = &stack0x00001e98 + lVar14;
          *(longlong *)(&stack0x00001e98 + lVar14) = lVar24 + 0x254;
          *(undefined4 *)(&stack0x00001ea0 + lVar14) = 0x10;
          *(undefined2 *)(&stack0x00001ea4 + lVar14) = 5;
          *(undefined2 *)(&stack0x00001ea6 + lVar14) = 0;
          *(undefined **)(&stack0x00001048 + lVar14) = &stack0x00001ea8 + lVar14;
          *(longlong *)(&stack0x00001ea8 + lVar14) = lVar24 + 0x244;
          *(undefined4 *)(&stack0x00001eb0 + lVar14) = 0x10;
          *(undefined2 *)(&stack0x00001eb4 + lVar14) = 6;
          *(undefined2 *)(&stack0x00001eb6 + lVar14) = 0;
          *(undefined **)(&stack0x00001050 + lVar14) = &stack0x000027c0 + lVar14;
          lVar23 = -1;
          do {
            lVar23 = lVar23 + 1;
          } while (*(short *)(&stack0x000027c0 + lVar23 * 2 + lVar14) != 0);
          iVar12 = (int)lVar23 * 2;
          *(int *)(&stack0x00000e28 + lVar14) = iVar12;
          *(undefined **)(&stack0x00001058 + lVar14) = &stack0x00001eb8 + lVar14;
          *(undefined **)(&stack0x00001eb8 + lVar14) = &stack0x000027c0 + lVar14;
          *(int *)(&stack0x00001ec0 + lVar14) = iVar12;
          *(undefined2 *)(&stack0x00001ec4 + lVar14) = 7;
          *(undefined2 *)(&stack0x00001ec6 + lVar14) = 0;
          *(undefined **)(&stack0x00001060 + lVar14) = &stack0x000027f0 + lVar14;
          lVar23 = -1;
          do {
            lVar23 = lVar23 + 1;
          } while (*(short *)(&stack0x000027f0 + lVar23 * 2 + lVar14) != 0);
          iVar12 = (int)lVar23 * 2;
          *(int *)(&stack0x00000e2c + lVar14) = iVar12;
          *(undefined **)(&stack0x00001068 + lVar14) = &stack0x00001ec8 + lVar14;
          *(undefined **)(&stack0x00001ec8 + lVar14) = &stack0x000027f0 + lVar14;
          *(int *)(&stack0x00001ed0 + lVar14) = iVar12;
          *(undefined2 *)(&stack0x00001ed4 + lVar14) = 8;
          *(undefined2 *)(&stack0x00001ed6 + lVar14) = 0;
          *(undefined4 *)(&stack0x00000854 + lVar14) = 0;
          UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1015ce;
          lVar23 = (*UNRECOVERED_JUMPTABLE_00)(lVar24,&stack0x00000854 + lVar14);
          *(longlong *)(&stack0x00001070 + lVar14) = lVar23;
          if (lVar23 == 0) {
            iVar12 = 0;
          }
          else {
            lVar24 = -1;
            do {
              lVar24 = lVar24 + 1;
            } while (*(short *)(lVar23 + lVar24 * 2) != 0);
            iVar12 = (int)lVar24 * 2;
          }
          *(int *)(&stack0x00000e30 + lVar14) = iVar12;
          lVar24 = *(longlong *)(&stack0x00001e70 + lVar14);
          *(longlong **)(&stack0x00001078 + lVar14) = (longlong *)(lVar24 + 0x50);
          *(longlong *)(lVar24 + 0x50) = lVar23;
          *(int *)(lVar24 + 0x58) = iVar12;
          *(undefined2 *)(lVar24 + 0x5c) = 9;
          *(undefined2 *)(lVar24 + 0x5e) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101629;
          func_0x(&stack0x00001e58 + lVar14);
        }
      }
LAB_:
      if ((1 < *(short *)((longlong)pplVar6 + 0xc)) && ((&stack0x00000050)[lVar14] != -1)) {
        lVar23 = **pplVar6;
        *(longlong *)(&stack0x00001108 + lVar14) = lVar23;
        if (*(char *)(lVar23 + 1) != (&stack0x00000050)[lVar14]) {
          if (*(longlong *)(&stack0x00000498 + lVar14) != 0) {
            *(longlong *)(&stack0x00001110 + lVar14) = lVar23;
            *(longlong *)(*(longlong *)(&stack0x00000498 + lVar14) + 0x588) = lVar23;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ab6;
          lVar23 = func_0x();
          if (lVar23 == 0) {
LAB_:
            *(undefined4 *)(&stack0x00000870 + lVar14) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ac0;
            lVar23 = func_0x();
            if (*(longlong *)(lVar23 + 0x30) == 0) goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101acc;
            lVar23 = func_0x();
            uVar22 = *(uint *)(*(longlong *)(lVar23 + 0x30) + 0xc);
            *(uint *)(&stack0x00000b70 + lVar14) = uVar22;
            if ((0xd < uVar22) || (iVar12 = 1, (0x2640U >> (uVar22 & 0x1f) & 1) == 0)) {
              iVar12 = 0;
            }
            *(int *)(&stack0x00000870 + lVar14) = iVar12;
            if (iVar12 != 0) goto LAB_;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b0d;
          func_0x(0,8);
        }
      }
LAB_:
      *(undefined4 *)(&stack0x00000af0 + lVar14) = 0;
      *(undefined4 *)(&stack0x00000af4 + lVar14) = 0;
      *(undefined2 *)(&stack0x00000af8 + lVar14) = 0;
      if (((*(short *)(&stack0x00000600 + lVar14) == 0) &&
          (*(int *)(&stack0x000005f8 + lVar14) == 0)) && (*(int *)(&stack0x000005fc + lVar14) == 0))
      {
LAB_:
        lVar23 = *(longlong *)(&stack0x000008d0 + lVar14);
        *(int *)(lVar23 + 4) = *(int *)(lVar23 + 4) + 1;
        if (*(longlong *)(lVar23 + 0x58) != 0) {
          piVar28 = (int *)(*(longlong *)(lVar23 + 0x58) + 4);
          *piVar28 = *piVar28 + 1;
        }
        if ((*(uint *)((longlong)pplVar6 + 0xc) & 0xff000000) != 0) {
          *(int *)(*(longlong *)(&stack0x000008d0 + lVar14) + 8) =
               *(int *)(*(longlong *)(&stack0x000008d0 + lVar14) + 8) + 1;
          if (*(longlong *)(lVar23 + 0x58) != 0) {
            piVar28 = (int *)(*(longlong *)(lVar23 + 0x58) + 8);
            *piVar28 = *piVar28 + 1;
          }
          if (*(char *)(pplVar6 + 2) != '\0') {
            *(int *)(*(longlong *)(&stack0x000008d0 + lVar14) + 0xc) =
                 *(int *)(*(longlong *)(&stack0x000008d0 + lVar14) + 0xc) + 1;
            if (*(longlong *)(lVar23 + 0x58) != 0) {
              piVar28 = (int *)(*(longlong *)(lVar23 + 0x58) + 0xc);
              *piVar28 = *piVar28 + 1;
            }
          }
        }
        if (*(int *)(&stack0x00000e9c + lVar14) != 0) {
          lVar23 = **pplVar6;
          *(longlong *)(&stack0x00001150 + lVar14) = lVar23;
          uVar3 = *(undefined *)(lVar23 + 1);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101e24;
          func_0x
                    (*(undefined8 *)(&stack0x00000cd8 + lVar14),uVar3,&stack0x00000e98 + lVar14,
                     0xffffffff);
        }
        (&stack0x00000357)[lVar14] = 0;
        (&stack0x00000358)[lVar14] = 1;
        *(undefined4 *)(&stack0x000004a0 + lVar14) = 0;
        *(undefined2 *)(&stack0x000004a4 + lVar14) = 0;
        *(undefined2 *)(&stack0x000004a6 + lVar14) = 0;
        lVar23 = **(longlong **)(&stack0x00000a48 + lVar14);
        *(longlong *)(&stack0x00000ce0 + lVar14) = lVar23;
        plVar27 = *pplVar6;
        lVar24 = *plVar27;
        *(longlong *)(&stack0x00001158 + lVar14) = lVar24;
        lVar7 = *(longlong *)(lVar23 + 8);
        piVar28 = (int *)(lVar7 + 0x3c0);
        *(int **)(&stack0x00001160 + lVar14) = piVar28;
        *(undefined4 *)(&stack0x00000890 + lVar14) = 0;
        if (*(int *)(lVar24 + 0x18) == *piVar28) {
          uVar4 = *(ushort *)(lVar7 + 0x3c4);
          if ((*(ushort *)(lVar24 + 6) != uVar4) && (1 < (uVar4 | *(ushort *)(lVar24 + 6))))
          goto LAB_;
          *(undefined4 *)(&stack0x00000890 + lVar14) = 1;
        }
        else {
LAB_:
          *(longlong *)(&stack0x00001168 + lVar14) = lVar24;
          *(undefined4 *)(&stack0x000005c8 + lVar14) = 0;
          *(undefined2 *)(&stack0x000005cc + lVar14) = 0;
          *(undefined2 *)(&stack0x000005ce + lVar14) = 0;
          uVar35 = *(undefined4 *)(lVar24 + 0x18);
          *(undefined4 *)(&stack0x000005c8 + lVar14) = uVar35;
          uVar11 = *(undefined2 *)(lVar24 + 6);
          *(undefined2 *)(&stack0x000005cc + lVar14) = uVar11;
          *(undefined4 *)(&stack0x000004a0 + lVar14) = uVar35;
          *(undefined2 *)(&stack0x000004a4 + lVar14) = uVar11;
          *(undefined2 *)(&stack0x000004a6 + lVar14) = 0;
          puVar17 = (undefined2 *)((longlong)plVar27 + 0x62);
          *(undefined2 **)(&stack0x00001170 + lVar14) = puVar17;
          *(undefined2 *)(&stack0x000001f8 + lVar14) = *puVar17;
          if (((*(ushort *)(&stack0x000001f8 + lVar14) & 0x400) == 0) ||
             (*(short *)((longlong)pplVar6 + 0xc) < 3)) {
            *(int *)(&stack0x000000b8 + lVar14) = (int)*(short *)((longlong)pplVar6 + 0xc);
            plVar27 = *pplVar6;
            *(longlong **)(&stack0x000003c0 + lVar14) = plVar27;
            puVar17 = (undefined2 *)((longlong)plVar27 + 0x62);
            *(undefined2 **)(&stack0x00001178 + lVar14) = puVar17;
            uVar5 = *puVar17;
            *(undefined2 *)(&stack0x00000200 + lVar14) = uVar5;
            if (((byte)uVar5 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000b8 + lVar14) == 3) {
                *(undefined4 *)(&stack0x000000b8 + lVar14) = 4;
              }
              else if (*(int *)(&stack0x000000b8 + lVar14) < 2) goto LAB_;
              *(uint **)(&stack0x00001180 + lVar14) =
                   (uint *)(*(longlong *)(&stack0x000003c0 + lVar14) + 100);
              uVar22 = *(uint *)(*(longlong *)(&stack0x000003c0 + lVar14) + 100);
              *(uint *)(&stack0x00000898 + lVar14) = uVar22;
              if ((((uVar22 & 8) != 0) &&
                  (lVar24 = *(longlong *)(*(longlong *)(&stack0x000003c0 + lVar14) + 0x90),
                  lVar24 != 0)) &&
                 (*(longlong *)(&stack0x00001188 + lVar14) = lVar24,
                 *(longlong *)(lVar24 + 0x758) != 0)) {
                uVar19 = *(undefined8 *)(lVar24 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102002;
                func_0x
                          (uVar19,*(undefined8 *)(&stack0x000003c0 + lVar14),
                           *(undefined4 *)(&stack0x000000b8 + lVar14));
              }
            }
LAB_:
            (&stack0x00000359)[lVar14] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar30 = (uint *)(*(longlong *)(&stack0x000003c0 + lVar14) + 100);
              *(uint **)(&stack0x00001190 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x000008a0 + lVar14) = uVar22;
              if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000b8 + lVar14))) {
                *(uint **)(&stack0x00001198 + lVar14) = puVar30;
                uVar22 = *puVar30;
                *(uint *)(&stack0x000008a8 + lVar14) = uVar22;
                if (((uVar22 & 0xc0000000) != 0x40000000) &&
                   (lVar24 = **(longlong **)(&stack0x000003c0 + lVar14), lVar24 != 0)) {
                  *(undefined4 *)(&stack0x00000b7c + lVar14) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102097;
                  iVar12 = (*_DAT_)(lVar24,0x2000,2,&stack0x00000b80 + lVar14);
                  if (iVar12 != 0) {
                    LOCK();
                    *puVar30 = *puVar30 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar30 = *puVar30 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar24 = *(longlong *)(&stack0x000003c0 + lVar14);
            uVar36 = *(undefined4 *)(&stack0x000000b8 + lVar14);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1020c6;
            func_0x(lVar24 + 0x98,uVar36);
            if ((_DAT_ != 0) &&
               ((&stack0x0000035a)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1020f0;
              func_0x(lVar24,0,uVar36);
            }
            *(uint *)((longlong)pplVar6 + 0xc) = *(uint *)((longlong)pplVar6 + 0xc) & 0xffff0000;
            *pplVar6 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101f3c;
            func_0x(pplVar6);
          }
          *(undefined **)(&stack0x000011a0 + lVar14) = &stack0x000005b8 + lVar14;
          *(undefined **)(&stack0x000011a8 + lVar14) = &stack0x000005f0 + lVar14;
          lVar23 = *(longlong *)(lVar23 + 8);
          puVar25 = (undefined4 *)(lVar23 + 0x3c0);
          *(undefined4 **)(&stack0x000011b0 + lVar14) = puVar25;
          *(undefined4 *)(&stack0x000005b8 + lVar14) = *puVar25;
          *(undefined2 *)(&stack0x000005bc + lVar14) = *(undefined2 *)(lVar23 + 0x3c4);
          *(undefined2 *)(&stack0x000005be + lVar14) = 0;
          *(undefined4 *)(&stack0x000005f0 + lVar14) = uVar35;
          *(undefined2 *)(&stack0x000005f4 + lVar14) = uVar11;
          *(undefined2 *)(&stack0x000005f6 + lVar14) = 0;
          UNRECOVERED_JUMPTABLE_00 = *(code **)**(undefined8 **)(&stack0x00000ce0 + lVar14);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102173;
          uVar11 = (*UNRECOVERED_JUMPTABLE_00)();
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) =
               *(undefined4 *)(*(longlong *)(&stack0x00000a48 + lVar14) + 0x10);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1021a3;
          func_0x(&stack0x0000009c + lVar14,&stack0x000005f0 + lVar14,uVar11,
                          &stack0x000005b8 + lVar14);
        }
        goto LAB_;
      }
      plVar27 = *pplVar6;
      lVar23 = *plVar27;
      *(longlong *)(&stack0x00001118 + lVar14) = lVar23;
      if ((*(byte *)(lVar23 + 4) & 1) == 0) goto LAB_;
      puVar15 = (ushort *)((longlong)plVar27 + 0x62);
      *(ushort **)(&stack0x00001120 + lVar14) = puVar15;
      uVar4 = *puVar15;
      *(ushort *)(&stack0x000001e8 + lVar14) = uVar4;
      if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)pplVar6 + 0xc) < 3)) {
        *(int *)(&stack0x000000b0 + lVar14) = (int)*(short *)((longlong)pplVar6 + 0xc);
        plVar27 = *pplVar6;
        *(longlong **)(&stack0x000003b8 + lVar14) = plVar27;
        puVar17 = (undefined2 *)((longlong)plVar27 + 0x62);
        *(undefined2 **)(&stack0x00001128 + lVar14) = puVar17;
        uVar11 = *puVar17;
        *(undefined2 *)(&stack0x000001f0 + lVar14) = uVar11;
        if (((byte)uVar11 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x000000b0 + lVar14) == 3) {
            *(undefined4 *)(&stack0x000000b0 + lVar14) = 4;
          }
          else if (*(int *)(&stack0x000000b0 + lVar14) < 2) goto LAB_;
          *(uint **)(&stack0x00001130 + lVar14) =
               (uint *)(*(longlong *)(&stack0x000003b8 + lVar14) + 100);
          uVar22 = *(uint *)(*(longlong *)(&stack0x000003b8 + lVar14) + 100);
          *(uint *)(&stack0x00000878 + lVar14) = uVar22;
          if ((((uVar22 & 8) != 0) &&
              (lVar23 = *(longlong *)(*(longlong *)(&stack0x000003b8 + lVar14) + 0x90), lVar23 != 0)
              ) && (*(longlong *)(&stack0x00001138 + lVar14) = lVar23,
                   *(longlong *)(lVar23 + 0x758) != 0)) {
            uVar19 = *(undefined8 *)(lVar23 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101c52;
            func_0x
                      (uVar19,*(undefined8 *)(&stack0x000003b8 + lVar14),
                       *(undefined4 *)(&stack0x000000b0 + lVar14));
          }
        }
LAB_:
        (&stack0x00000355)[lVar14] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar30 = (uint *)(*(longlong *)(&stack0x000003b8 + lVar14) + 100);
          *(uint **)(&stack0x00001140 + lVar14) = puVar30;
          uVar22 = *puVar30;
          *(uint *)(&stack0x00000880 + lVar14) = uVar22;
          if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000b0 + lVar14))) {
            *(uint **)(&stack0x00001148 + lVar14) = puVar30;
            uVar22 = *puVar30;
            *(uint *)(&stack0x00000888 + lVar14) = uVar22;
            if (((uVar22 & 0xc0000000) != 0x40000000) &&
               (lVar23 = **(longlong **)(&stack0x000003b8 + lVar14), lVar23 != 0)) {
              *(undefined4 *)(&stack0x00000b74 + lVar14) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ce5;
              iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000b78 + lVar14);
              if (iVar12 != 0) {
                LOCK();
                *puVar30 = *puVar30 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar30 = *puVar30 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar23 = *(longlong *)(&stack0x000003b8 + lVar14);
        uVar35 = *(undefined4 *)(&stack0x000000b0 + lVar14);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101d14;
        func_0x(lVar23 + 0x98,uVar35);
        if ((_DAT_ != 0) &&
           ((&stack0x00000356)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101d3e;
          func_0x(lVar23,0,uVar35);
        }
        *(uint *)((longlong)pplVar6 + 0xc) = *(uint *)((longlong)pplVar6 + 0xc) & 0xffff0000;
        *pplVar6 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b8c;
        func_0x(pplVar6);
      }
      *(undefined4 *)(&stack0x00000f70 + lVar14) = 0x400060;
      *(undefined8 *)(&stack0x00000f78 + lVar14) = 0;
      *(undefined8 *)(&stack0x00000f88 + lVar14) = 0;
      *(undefined8 *)(&stack0x00000f80 + lVar14) = 0;
      *(undefined8 *)(&stack0x00000f90 + lVar14) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101d89;
      func_0x(10,&stack0x00000f70 + lVar14);
      lVar24 = *(longlong *)(&stack0x00000080 + lVar14);
    } while( true );
  }
  (&stack0x00000053)[lVar14] = 0;
LAB_:
  plVar27 = *(longlong **)(*(longlong *)(&stack0x00000448 + lVar14) + 8);
  *(longlong **)(&stack0x00000a20 + lVar14) = plVar27;
  *(undefined8 *)(&stack0x000008d8 + lVar14) =
       *(undefined8 *)(*(longlong *)(&stack0x00000448 + lVar14) + 0x10);
  *(undefined4 *)(&stack0x00000608 + lVar14) = 0;
  *(undefined4 *)(&stack0x0000060c + lVar14) = 0;
  *(undefined2 *)(&stack0x00000610 + lVar14) = 0;
  lVar23 = *plVar27;
  *(longlong *)(&stack0x00000d28 + lVar14) = lVar23;
  *(undefined4 *)(&stack0x00000eb4 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000eb8 + lVar14) = 0;
  lVar24 = *(longlong *)(lVar23 + 0x20);
  *(longlong *)(&stack0x00000070 + lVar14) = lVar24;
  *(uint6 **)(&stack0x000011b8 + lVar14) = (uint6 *)(lVar23 + 0x14);
  lVar23 = (ulonglong)*(uint6 *)(lVar23 + 0x14) * 0x10000;
  *(longlong *)(&stack0x000011c0 + lVar14) = lVar23;
  if ((*(longlong *)(lVar24 + 2000) == lVar23) &&
     (*(longlong *)(lVar24 + 2000) - 1U < 0xfffffffffffffffe)) {
    (&stack0x0000008f)[lVar14] = 1;
    goto LAB_;
  }
  (&stack0x0000008f)[lVar14] = 0;
  if ((*(longlong *)(lVar24 + 0x7d8) == lVar23) &&
     (*(longlong *)(lVar24 + 0x7d8) - 1U < 0xfffffffffffffffe)) {
    (&stack0x00000090)[lVar14] = 1;
    goto LAB_;
  }
  (&stack0x00000090)[lVar14] = 0;
  lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
  *(longlong *)(&stack0x000011c8 + lVar14) = lVar23;
  lVar24 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
  *(longlong *)(&stack0x000011d0 + lVar14) = lVar24;
  lVar23 = *(longlong *)(lVar24 + 0x100);
  *(longlong *)(&stack0x00000ce8 + lVar14) = lVar23;
  puVar30 = _DAT_;
  if (lVar23 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1022d0;
    puVar30 = (uint *)(*_DAT_)();
    lVar23 = *(longlong *)(lVar24 + 0x100);
    *(longlong *)(&stack0x00000ce8 + lVar14) = lVar23;
  }
  *(longlong *)(&stack0x000011d8 + lVar14) = lVar23;
  uVar20 = rdtsc();
  uVar18 = CONCAT44((int)((ulonglong)puVar30 >> 0x20),(int)uVar20) | uVar20 & 0xffffffff00000000;
  *(ulonglong *)(&stack0x000011e0 + lVar14) = uVar18;
  uVar20 = *(ulonglong *)(lVar23 + 0x340);
  if ((uVar20 < uVar18) ||
     ((uVar20 != 0x7fffffffffffffff &&
      (*(ulonglong *)(*(longlong *)(lVar23 + 0x260) + 0xdf0) < uVar20 - uVar18)))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10238f;
    iVar12 = func_0x(0,0x2049690);
    *(int *)(&stack0x0000043c + lVar14) = iVar12;
    if (iVar12 == 2) {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1023a2;
      func_0x(0x7c);
    }
  }
  else {
    lVar23 = *(longlong *)(lVar23 + 600);
    *(longlong *)(&stack0x00000cf0 + lVar14) = lVar23;
    puVar30 = (uint *)(lVar23 + 0xbc);
    *(uint **)(&stack0x000011e8 + lVar14) = puVar30;
    if ((*puVar30 & 4) != 0) {
      lVar23 = *(longlong *)(*(longlong *)(&stack0x00000cf0 + lVar14) + 0x98);
      *(longlong *)(&stack0x000011f0 + lVar14) = lVar23;
      if (((*(byte *)(lVar23 + 0x268) & 1) == 0) && ((*(uint *)(lVar23 + 800) & 0x180) == 0)) {
        *(undefined4 *)(&stack0x0000043c + lVar14) = 2;
        goto LAB_;
      }
    }
    *(undefined4 *)(&stack0x0000043c + lVar14) = 0;
  }
  lVar24 = *(longlong *)(&stack0x00000070 + lVar14);
LAB_:
  *(undefined4 *)(&stack0x00000b00 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000b04 + lVar14) = 0;
  *(undefined2 *)(&stack0x00000b08 + lVar14) = 0;
  (&stack0x0000009a)[lVar14] = 0;
  (&stack0x00000051)[lVar14] = 0xff;
  do {
    uVar19 = 0;
    *(undefined **)(&stack0x00000a50 + lVar14) = &stack0x00000eb0 + lVar14;
    *(undefined4 *)(&stack0x00002654 + lVar14) = 0;
    *(undefined4 *)(&stack0x00002658 + lVar14) = 0;
    cVar8 = *_DAT_;
    (&stack0x0000035b)[lVar14] = cVar8;
    if ((cVar8 != '\0') && ((&stack0x0000035c)[lVar14] = DAT_ >> 7, -1 < (char)DAT_)
       ) {
      *(undefined4 *)(&stack0x000008b0 + lVar14) = 0;
      lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x000011f8 + lVar14) = lVar23;
      plVar27 = (longlong *)
                ((ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8));
      *(longlong **)(&stack0x00001200 + lVar14) = plVar27;
      lVar23 = *plVar27;
      *(longlong *)(&stack0x00001208 + lVar14) = lVar23;
      if (lVar23 == 0) {
LAB_:
        *(undefined8 *)(&stack0x00000cf8 + lVar14) = 0;
      }
      else {
        lVar23 = **(longlong **)(lVar23 + 0x38);
        *(longlong *)(&stack0x00001210 + lVar14) = lVar23;
        if (lVar23 == 0) goto LAB_;
        *(longlong *)(&stack0x00000cf8 + lVar14) = lVar23;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1024a5;
        iVar12 = (*_DAT_)(lVar23,0x337);
        *(int *)(&stack0x000008b0 + lVar14) = iVar12;
        if (iVar12 != 0) {
          lVar24 = *(longlong *)(&stack0x00000070 + lVar14);
          goto LAB_;
        }
      }
      lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00001218 + lVar14) = lVar23;
      lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00001220 + lVar14) = lVar23;
      lVar23 = *(longlong *)(lVar23 + 8);
      *(longlong *)(&stack0x00001228 + lVar14) = lVar23;
      lVar24 = *(longlong *)(&stack0x00000070 + lVar14);
      if (lVar23 != 0) {
        uVar19 = *(undefined8 *)(lVar23 + 0x60);
      }
    }
LAB_:
    *(undefined8 *)(&stack0x000004a8 + lVar14) = uVar19;
    plVar27 = (longlong *)(lVar24 + 0x728);
    *(longlong *)(&stack0x00000d00 + lVar14) = *plVar27;
LAB_:
    *(undefined4 *)(&stack0x00000310 + lVar14) = 0;
    if (*param_2 != (longlong *)0x0) {
      puVar15 = (ushort *)((longlong)*param_2 + 0x62);
      *(ushort **)(&stack0x00001230 + lVar14) = puVar15;
      uVar4 = *puVar15;
      *(ushort *)(&stack0x00000208 + lVar14) = uVar4;
      if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
        *(int *)(&stack0x000000c0 + lVar14) = (int)*(short *)((longlong)param_2 + 0xc);
        plVar16 = *param_2;
        *(longlong **)(&stack0x000003c8 + lVar14) = plVar16;
        puVar17 = (undefined2 *)((longlong)plVar16 + 0x62);
        *(undefined2 **)(&stack0x00001238 + lVar14) = puVar17;
        uVar11 = *puVar17;
        *(undefined2 *)(&stack0x00000210 + lVar14) = uVar11;
        if (((byte)uVar11 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x000000c0 + lVar14) == 3) {
            *(undefined4 *)(&stack0x000000c0 + lVar14) = 4;
          }
          else if (*(int *)(&stack0x000000c0 + lVar14) < 2) goto LAB_;
          *(uint **)(&stack0x00001240 + lVar14) =
               (uint *)(*(longlong *)(&stack0x000003c8 + lVar14) + 100);
          uVar22 = *(uint *)(*(longlong *)(&stack0x000003c8 + lVar14) + 100);
          *(uint *)(&stack0x000008b8 + lVar14) = uVar22;
          if ((((uVar22 & 8) != 0) &&
              (lVar23 = *(longlong *)(*(longlong *)(&stack0x000003c8 + lVar14) + 0x90), lVar23 != 0)
              ) && (*(longlong *)(&stack0x00001248 + lVar14) = lVar23,
                   *(longlong *)(lVar23 + 0x758) != 0)) {
            uVar19 = *(undefined8 *)(lVar23 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102646;
            func_0x
                      (uVar19,*(undefined8 *)(&stack0x000003c8 + lVar14),
                       *(undefined4 *)(&stack0x000000c0 + lVar14));
          }
        }
LAB_:
        (&stack0x0000035d)[lVar14] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar30 = (uint *)(*(longlong *)(&stack0x000003c8 + lVar14) + 100);
          *(uint **)(&stack0x00001250 + lVar14) = puVar30;
          uVar22 = *puVar30;
          *(uint *)(&stack0x000008c0 + lVar14) = uVar22;
          if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000c0 + lVar14))) {
            *(uint **)(&stack0x00001258 + lVar14) = puVar30;
            uVar22 = *puVar30;
            *(uint *)(&stack0x000008c8 + lVar14) = uVar22;
            if (((uVar22 & 0xc0000000) != 0x40000000) &&
               (lVar23 = **(longlong **)(&stack0x000003c8 + lVar14), lVar23 != 0)) {
              *(undefined4 *)(&stack0x00000b84 + lVar14) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1026d9;
              iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000b88 + lVar14);
              if (iVar12 != 0) {
                LOCK();
                *puVar30 = *puVar30 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar30 = *puVar30 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar23 = *(longlong *)(&stack0x000003c8 + lVar14);
        uVar35 = *(undefined4 *)(&stack0x000000c0 + lVar14);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102708;
        func_0x(lVar23 + 0x98,uVar35);
        if ((_DAT_ != 0) &&
           ((&stack0x0000035e)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102732;
          func_0x(lVar23,0,uVar35);
        }
        *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
        *param_2 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102522;
        func_0x(param_2);
      }
      lVar24 = *(longlong *)(&stack0x00000070 + lVar14);
    }
    if (*plVar27 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102766;
      func_0x(param_2,&stack0x00000180 + lVar14,lVar24);
      if (*param_2 != (longlong *)0x0) {
        puVar15 = (ushort *)((longlong)*param_2 + 0x62);
        *(ushort **)(&stack0x00001260 + lVar14) = puVar15;
        uVar4 = *puVar15;
        *(ushort *)(&stack0x00000218 + lVar14) = uVar4;
        if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
          *(int *)(&stack0x000000c8 + lVar14) = (int)*(short *)((longlong)param_2 + 0xc);
          plVar16 = *param_2;
          *(longlong **)(&stack0x000003d0 + lVar14) = plVar16;
          puVar17 = (undefined2 *)((longlong)plVar16 + 0x62);
          *(undefined2 **)(&stack0x00001268 + lVar14) = puVar17;
          uVar11 = *puVar17;
          *(undefined2 *)(&stack0x00000220 + lVar14) = uVar11;
          if (((byte)uVar11 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x000000c8 + lVar14) == 3) {
              *(undefined4 *)(&stack0x000000c8 + lVar14) = 4;
            }
            else if (*(int *)(&stack0x000000c8 + lVar14) < 2) goto LAB_;
            *(uint **)(&stack0x00001270 + lVar14) =
                 (uint *)(*(longlong *)(&stack0x000003d0 + lVar14) + 100);
            uVar22 = *(uint *)(*(longlong *)(&stack0x000003d0 + lVar14) + 100);
            *(uint *)(&stack0x00000938 + lVar14) = uVar22;
            if ((((uVar22 & 8) != 0) &&
                (lVar23 = *(longlong *)(*(longlong *)(&stack0x000003d0 + lVar14) + 0x90),
                lVar23 != 0)) &&
               (*(longlong *)(&stack0x00001278 + lVar14) = lVar23,
               *(longlong *)(lVar23 + 0x758) != 0)) {
              uVar19 = *(undefined8 *)(lVar23 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102868;
              func_0x
                        (uVar19,*(undefined8 *)(&stack0x000003d0 + lVar14),
                         *(undefined4 *)(&stack0x000000c8 + lVar14));
            }
          }
LAB_:
          (&stack0x0000035f)[lVar14] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar30 = (uint *)(*(longlong *)(&stack0x000003d0 + lVar14) + 100);
            *(uint **)(&stack0x00001280 + lVar14) = puVar30;
            uVar22 = *puVar30;
            *(uint *)(&stack0x00000940 + lVar14) = uVar22;
            if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000c8 + lVar14))) {
              *(uint **)(&stack0x00001288 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x00000948 + lVar14) = uVar22;
              if (((uVar22 & 0xc0000000) != 0x40000000) &&
                 (lVar23 = **(longlong **)(&stack0x000003d0 + lVar14), lVar23 != 0)) {
                *(undefined4 *)(&stack0x00000b8c + lVar14) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1028fb;
                iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000b90 + lVar14);
                if (iVar12 != 0) {
                  LOCK();
                  *puVar30 = *puVar30 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar30 = *puVar30 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar23 = *(longlong *)(&stack0x000003d0 + lVar14);
          uVar35 = *(undefined4 *)(&stack0x000000c8 + lVar14);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10292a;
          func_0x(lVar23 + 0x98,uVar35);
          if ((_DAT_ != 0) &&
             ((&stack0x00000360)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102954;
            func_0x(lVar23,0,uVar35);
          }
          *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
          *param_2 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1027a1;
          func_0x(param_2);
        }
        lVar24 = *(longlong *)(&stack0x00000070 + lVar14);
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10297b;
    func_0x(lVar24,&stack0x00000180 + lVar14);
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) = *(undefined8 *)(&stack0x00000a50 + lVar14);
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 4;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1029af;
    plVar16 = (longlong *)
              func_0x
                        (_DAT_,lVar24,&stack0x00000180 + lVar14,&stack0x00000310 + lVar14);
    *param_2 = plVar16;
    uVar22 = *(uint *)((longlong)param_2 + 0xc) & 0xffff0004 | 4;
    *(uint *)((longlong)param_2 + 0xc) = uVar22;
    if (*(longlong *)(&stack0x000004a8 + lVar14) != 0) {
      lVar23 = **param_2;
      *(longlong *)(&stack0x00001290 + lVar14) = lVar23;
      plVar31 = (longlong *)(*(longlong *)(&stack0x000004a8 + lVar14) + 0x500);
      *(longlong **)(&stack0x00001298 + lVar14) = plVar31;
      plVar16 = plVar31 + (ulonglong)(*(uint *)plVar31 & 0xf) + 1;
      *(longlong **)(&stack0x000012a0 + lVar14) = plVar16;
      if (*plVar16 != lVar23) {
        *plVar16 = lVar23;
        *plVar31 = *plVar31 + 1;
        uVar22 = *(uint *)((longlong)param_2 + 0xc);
      }
    }
    uVar26 = *(uint *)(&stack0x00000310 + lVar14) >> 3 & 1;
    *(uint *)((longlong)param_2 + 0xc) = uVar26 << 0x18 | uVar22 & 0xffffff;
    *(uint *)(param_2 + 2) =
         *(uint *)(&stack0x00000310 + lVar14) >> 4 & 1 | *(uint *)(param_2 + 2) & 0xffffff00;
    lVar23 = *(longlong *)(&stack0x00000d00 + lVar14);
    if (((lVar23 != 0) && (*(longlong *)(&stack0x000004a8 + lVar14) != 0)) &&
       (*(longlong *)(&stack0x000004a8 + lVar14) == *(longlong *)(lVar24 + 0x1c38))) {
      *(uint *)(&stack0x00000b98 + lVar14) = uVar26;
      *(longlong *)(&stack0x000012a8 + lVar14) = lVar23 + 0x59b8;
      *(longlong *)(lVar23 + 0x5b28) = *(longlong *)(lVar23 + 0x5b28) + 1;
      puVar30 = *(uint **)(&stack0x00000a50 + lVar14);
      if (puVar30[1] != 0) {
        *(longlong *)(lVar23 + 0x5b30) = *(longlong *)(lVar23 + 0x5b30) + 1;
        *(longlong *)(lVar23 + 0x5b38) = *(longlong *)(lVar23 + 0x5b38) + (ulonglong)*puVar30;
        if (uVar26 != 0) {
          *(longlong *)(lVar23 + 0x5b40) = *(longlong *)(lVar23 + 0x5b40) + 1;
          *(longlong *)(lVar23 + 0x5b48) = *(longlong *)(lVar23 + 0x5b48) + (ulonglong)*puVar30;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102ad2;
    cVar8 = func_0x(lVar24);
    if ((cVar8 == '\0') || (*(char *)(lVar24 + 0x2050) == '\0')) goto LAB_;
    if (*(int *)(&stack0x00000180 + lVar14) == 0) {
LAB_:
      (&stack0x000000a7)[lVar14] = 1;
      goto LAB_;
    }
    *(undefined4 *)(&stack0x00000a86 + lVar14) = 9;
    *(undefined2 *)(&stack0x00000a8a + lVar14) = 1;
    if ((*(int *)(&stack0x00000180 + lVar14) == 9) && (*(short *)(&stack0x00000184 + lVar14) == 1))
    goto LAB_;
    (&stack0x000000a7)[lVar14] = 0;
    lVar23 = **param_2;
    *(longlong *)(&stack0x000012b0 + lVar14) = lVar23;
    (&stack0x00000091)[lVar14] = 0;
    if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000538 + lVar14) = *(undefined8 *)(lVar23 + 0x28);
      *(undefined2 *)(&stack0x00000540 + lVar14) = *(undefined2 *)(lVar23 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar23 + 1);
      if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) &&
         (*(int *)(lVar23 + 0x18) == 99)) {
        *(undefined **)(&stack0x000012b8 + lVar14) = &stack0x00000568 + lVar14;
        *(undefined4 **)(&stack0x000012c0 + lVar14) = (undefined4 *)(lVar23 + 0x20);
        *(undefined4 *)(&stack0x00000568 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
        *(undefined2 *)(&stack0x0000056c + lVar14) = *(undefined2 *)(lVar23 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102b9b;
        cVar8 = func_0x(&stack0x00000568 + lVar14);
        if (cVar8 == '\0') goto LAB_;
        cVar8 = '\x01';
      }
      else {
LAB_:
        cVar8 = '\0';
      }
      (&stack0x00000091)[lVar14] = cVar8;
      if (cVar8 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102bc0;
      func_0x(lVar23,&stack0x00000538 + lVar14);
    }
    *(undefined **)(&stack0x000012c8 + lVar14) = &stack0x00000538 + lVar14;
    *(longlong *)(&stack0x00000d08 + lVar14) = lVar24 + 0x20fc;
    *(undefined4 *)(&stack0x00000464 + lVar14) = 0;
    *(undefined4 *)(&stack0x00000468 + lVar14) = 0;
    *(undefined2 *)(&stack0x0000046c + lVar14) = 0;
    *(undefined2 *)(&stack0x0000046e + lVar14) = 0;
    puVar30 = (uint *)(lVar24 + 0x2108);
    *(uint **)(&stack0x000012d0 + lVar14) = puVar30;
    uVar22 = *puVar30;
    *(uint *)(&stack0x00000440 + lVar14) = uVar22;
    *(uint **)(&stack0x00000d10 + lVar14) = puVar30;
    do {
      *(uint *)(&stack0x00000950 + lVar14) = uVar22 & 0xfffffffe;
      *(undefined8 *)(&stack0x00000464 + lVar14) = **(undefined8 **)(&stack0x00000d08 + lVar14);
      *(undefined4 *)(&stack0x0000046c + lVar14) =
           *(undefined4 *)(*(undefined8 **)(&stack0x00000d08 + lVar14) + 1);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14);
      UNLOCK();
      uVar22 = **(uint **)(&stack0x00000d10 + lVar14);
      *(uint *)(&stack0x00000440 + lVar14) = uVar22;
    } while (*(uint *)(&stack0x00000950 + lVar14) != uVar22);
    if ((*(uint *)(&stack0x00000538 + lVar14) <= *(uint *)(&stack0x00000464 + lVar14)) &&
       ((*(uint *)(&stack0x00000464 + lVar14) != *(uint *)(&stack0x00000538 + lVar14) ||
        ((uVar22 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000464 + lVar14) >> 0x20),
         *(uint *)(&stack0x0000053c + lVar14) <= uVar22 &&
         ((uVar22 != *(uint *)(&stack0x0000053c + lVar14) ||
          (*(ushort *)(&stack0x00000540 + lVar14) <= *(ushort *)(&stack0x0000046c + lVar14)))))))))
    goto LAB_;
    if (*(char *)(*(longlong *)(&stack0x00000070 + lVar14) + 0x6ac8) != '\0') {
LAB_:
      if ((&stack0x0000009a)[lVar14] != '\0') goto LAB_;
      lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x000013a0 + lVar14) = lVar23;
      lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x000013a8 + lVar14) = lVar23;
      lVar23 = *(longlong *)(lVar23 + 8);
      *(longlong *)(&stack0x000013b0 + lVar14) = lVar23;
      lVar23 = *(longlong *)(lVar23 + 0x60);
      *(longlong *)(&stack0x000013b8 + lVar14) = lVar23;
      lVar24 = *(longlong *)(&stack0x00000070 + lVar14);
      if (lVar23 == *(longlong *)(lVar24 + 0x2120)) goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1033cd;
      cVar8 = func_0x(lVar24);
      if (cVar8 != '\0') goto LAB_;
      if (*(longlong *)(&stack0x000004a8 + lVar14) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1033e5;
        uVar19 = func_0x();
        *(undefined8 *)(&stack0x000004a8 + lVar14) = uVar19;
      }
      *(undefined **)(&stack0x000013c0 + lVar14) = &stack0x000004c8 + lVar14;
      lVar23 = **param_2;
      *(longlong *)(&stack0x000013c8 + lVar14) = lVar23;
      (&stack0x00000099)[lVar14] = 0;
      if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
        uVar19 = *(undefined8 *)(lVar23 + 0x28);
        uVar35 = (undefined4)uVar19;
        uVar36 = (undefined4)((ulonglong)uVar19 >> 0x20);
        *(undefined8 *)(&stack0x000004c8 + lVar14) = uVar19;
        uVar11 = *(undefined2 *)(lVar23 + 0x30);
        *(undefined2 *)(&stack0x000004d0 + lVar14) = uVar11;
      }
      else {
        cVar8 = *(char *)(lVar23 + 1);
        if (((cVar8 == '\v') && (*(int *)(lVar23 + 0x18) == 99)) ||
           (((cVar8 == '\b' || (cVar8 == '\t')) && (*(int *)(lVar23 + 0x18) == 99)))) {
          *(undefined **)(&stack0x000013d0 + lVar14) = &stack0x00000578 + lVar14;
          *(undefined4 **)(&stack0x000013d8 + lVar14) = (undefined4 *)(lVar23 + 0x20);
          *(undefined4 *)(&stack0x00000578 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
          *(undefined2 *)(&stack0x0000057c + lVar14) = *(undefined2 *)(lVar23 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10347d;
          cVar8 = func_0x(&stack0x00000578 + lVar14);
          if (cVar8 == '\0') goto LAB_;
          cVar8 = '\x01';
        }
        else {
LAB_:
          cVar8 = '\0';
        }
        (&stack0x00000099)[lVar14] = cVar8;
        if (cVar8 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1034a2;
        func_0x(lVar23,&stack0x000004c8 + lVar14);
        uVar11 = *(undefined2 *)(&stack0x000004d0 + lVar14);
        uVar35 = (undefined4)*(undefined8 *)(&stack0x000004c8 + lVar14);
        uVar36 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x000004c8 + lVar14) >> 0x20);
      }
      *(undefined **)(&stack0x000013e0 + lVar14) = &stack0x000004c8 + lVar14;
      *(ulonglong *)(&stack0x00000634 + lVar14) = CONCAT44(uVar36,uVar35);
      *(undefined2 *)(&stack0x0000063c + lVar14) = uVar11;
      *(undefined2 *)(&stack0x0000063e + lVar14) = 0;
      if (*param_2 != (longlong *)0x0) {
        puVar15 = (ushort *)((longlong)*param_2 + 0x62);
        *(ushort **)(&stack0x000013e8 + lVar14) = puVar15;
        uVar4 = *puVar15;
        *(ushort *)(&stack0x00000228 + lVar14) = uVar4;
        if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
          *(int *)(&stack0x000000d0 + lVar14) = (int)*(short *)((longlong)param_2 + 0xc);
          plVar16 = *param_2;
          *(longlong **)(&stack0x000003d8 + lVar14) = plVar16;
          puVar17 = (undefined2 *)((longlong)plVar16 + 0x62);
          *(undefined2 **)(&stack0x000013f0 + lVar14) = puVar17;
          uVar11 = *puVar17;
          *(undefined2 *)(&stack0x00000230 + lVar14) = uVar11;
          if (((byte)uVar11 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x000000d0 + lVar14) == 3) {
              *(undefined4 *)(&stack0x000000d0 + lVar14) = 4;
            }
            else if (*(int *)(&stack0x000000d0 + lVar14) < 2) goto LAB_;
            *(uint **)(&stack0x000013f8 + lVar14) =
                 (uint *)(*(longlong *)(&stack0x000003d8 + lVar14) + 100);
            uVar22 = *(uint *)(*(longlong *)(&stack0x000003d8 + lVar14) + 100);
            *(uint *)(&stack0x00000960 + lVar14) = uVar22;
            if ((((uVar22 & 8) != 0) &&
                (lVar23 = *(longlong *)(*(longlong *)(&stack0x000003d8 + lVar14) + 0x90),
                lVar23 != 0)) &&
               (*(longlong *)(&stack0x00001400 + lVar14) = lVar23,
               *(longlong *)(lVar23 + 0x758) != 0)) {
              uVar19 = *(undefined8 *)(lVar23 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103600;
              func_0x
                        (uVar19,*(undefined8 *)(&stack0x000003d8 + lVar14),
                         *(undefined4 *)(&stack0x000000d0 + lVar14));
            }
          }
LAB_:
          (&stack0x00000361)[lVar14] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar30 = (uint *)(*(longlong *)(&stack0x000003d8 + lVar14) + 100);
            *(uint **)(&stack0x00001408 + lVar14) = puVar30;
            uVar22 = *puVar30;
            *(uint *)(&stack0x00000968 + lVar14) = uVar22;
            if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000d0 + lVar14))) {
              *(uint **)(&stack0x00001410 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x00000970 + lVar14) = uVar22;
              if (((uVar22 & 0xc0000000) != 0x40000000) &&
                 (lVar23 = **(longlong **)(&stack0x000003d8 + lVar14), lVar23 != 0)) {
                *(undefined4 *)(&stack0x00000bac + lVar14) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103693;
                iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000bb0 + lVar14);
                if (iVar12 != 0) {
                  LOCK();
                  *puVar30 = *puVar30 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar30 = *puVar30 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar23 = *(longlong *)(&stack0x000003d8 + lVar14);
          uVar35 = *(undefined4 *)(&stack0x000000d0 + lVar14);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1036c2;
          func_0x(lVar23 + 0x98,uVar35);
          if ((_DAT_ != 0) &&
             ((&stack0x00000362)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1036ec;
            func_0x(lVar23,0,uVar35);
          }
          *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
          *param_2 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10353a;
          func_0x(param_2);
        }
        uVar35 = (undefined4)*(undefined8 *)(&stack0x00000634 + lVar14);
        uVar36 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x00000634 + lVar14) >> 0x20);
        uVar11 = *(undefined2 *)(&stack0x0000063c + lVar14);
        lVar24 = *(longlong *)(&stack0x00000070 + lVar14);
      }
      *(undefined **)(&stack0x00001418 + lVar14) = &stack0x00000b20 + lVar14;
      *(ulonglong *)(&stack0x00000b20 + lVar14) = CONCAT44(uVar36,uVar35);
      *(undefined2 *)(&stack0x00000b28 + lVar14) = uVar11;
      *(undefined **)(&stack0x00001420 + lVar14) = &stack0x000009f0 + lVar14;
      *(ulonglong *)(&stack0x000009f0 + lVar14) = CONCAT44(uVar36,uVar35);
      *(undefined2 *)(&stack0x000009f8 + lVar14) = uVar11;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
      lVar23 = *plVar27;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103777;
      func_0x(lVar23,&stack0x000009f0 + lVar14,4);
      goto LAB_;
    }
    lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x000012d8 + lVar14) = lVar23;
    lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x000012e0 + lVar14) = lVar23;
    lVar23 = *(longlong *)(lVar23 + 8);
    *(longlong *)(&stack0x000012e8 + lVar14) = lVar23;
    lVar23 = *(longlong *)(lVar23 + 0x60);
    *(longlong *)(&stack0x000012f0 + lVar14) = lVar23;
    if (lVar23 == *(longlong *)(*(longlong *)(&stack0x00000070 + lVar14) + 0x2120))
    goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102d4a;
    cVar8 = func_0x(*(longlong *)(&stack0x00000070 + lVar14));
    if (cVar8 != '\0') goto LAB_;
    *(longlong *)(&stack0x00000a58 + lVar14) = lVar24 + 0x20fc;
    iVar12 = 0;
    *(undefined4 *)(&stack0x00000430 + lVar14) = 0;
    *(undefined4 *)(&stack0x00000434 + lVar14) = 0;
    *(undefined2 *)(&stack0x00000438 + lVar14) = 0;
    *(undefined2 *)(&stack0x0000043a + lVar14) = 0;
    *(uint **)(&stack0x000012f8 + lVar14) = puVar30;
    uVar22 = *puVar30;
    *(uint *)(&stack0x00000484 + lVar14) = uVar22;
    puVar29 = *(undefined8 **)(&stack0x00000a58 + lVar14);
    *(longlong *)(&stack0x00000d18 + lVar14) = (longlong)puVar29 + 0xc;
    while( true ) {
      *(uint *)(&stack0x00000954 + lVar14) = uVar22 & 0xfffffffe;
      *(undefined8 *)(&stack0x00000430 + lVar14) = *puVar29;
      *(undefined4 *)(&stack0x00000438 + lVar14) = *(undefined4 *)(puVar29 + 1);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14);
      UNLOCK();
      uVar22 = **(uint **)(&stack0x00000d18 + lVar14);
      *(uint *)(&stack0x00000484 + lVar14) = uVar22;
      if (*(uint *)(&stack0x00000954 + lVar14) == uVar22) break;
      puVar29 = *(undefined8 **)(&stack0x00000a58 + lVar14);
    }
    *(undefined8 *)(&stack0x00000b10 + lVar14) = *(undefined8 *)(&stack0x00000430 + lVar14);
    uVar4 = *(ushort *)(&stack0x00000438 + lVar14);
    *(ushort *)(&stack0x00000b18 + lVar14) = uVar4;
    lVar23 = **param_2;
    *(longlong *)(&stack0x00001300 + lVar14) = lVar23;
    (&stack0x000000a4)[lVar14] = 0;
    if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000548 + lVar14) = *(undefined8 *)(lVar23 + 0x28);
      uVar33 = *(ushort *)(lVar23 + 0x30);
      *(ushort *)(&stack0x00000550 + lVar14) = uVar33;
    }
    else {
      cVar8 = *(char *)(lVar23 + 1);
      if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) &&
         (*(int *)(lVar23 + 0x18) == 99)) {
        *(undefined **)(&stack0x00001308 + lVar14) = &stack0x00000570 + lVar14;
        *(undefined4 **)(&stack0x00001310 + lVar14) = (undefined4 *)(lVar23 + 0x20);
        *(undefined4 *)(&stack0x00000570 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
        *(undefined2 *)(&stack0x00000574 + lVar14) = *(undefined2 *)(lVar23 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102e83;
        cVar8 = func_0x(&stack0x00000570 + lVar14);
        if (cVar8 == '\0') goto LAB_;
        cVar8 = '\x01';
      }
      else {
LAB_:
        cVar8 = '\0';
      }
      (&stack0x000000a4)[lVar14] = cVar8;
      if (cVar8 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102ea8;
      func_0x(lVar23,&stack0x00000548 + lVar14);
      uVar33 = *(ushort *)(&stack0x00000550 + lVar14);
    }
    if ((*(uint *)(&stack0x00000430 + lVar14) < *(uint *)(&stack0x00000548 + lVar14)) ||
       ((*(uint *)(&stack0x00000430 + lVar14) == *(uint *)(&stack0x00000548 + lVar14) &&
        ((uVar22 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000548 + lVar14) >> 0x20),
         *(uint *)(&stack0x00000434 + lVar14) < uVar22 ||
         ((*(uint *)(&stack0x00000434 + lVar14) == uVar22 && (uVar4 < uVar33)))))))) {
      lVar23 = *(longlong *)(&stack0x00000070 + lVar14);
      lVar24 = *(longlong *)(lVar23 + 0x6b0);
      *(longlong *)(&stack0x00001318 + lVar14) = lVar24;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102f3f;
      func_0x(&stack0x00000548 + lVar14,&stack0x00002820 + lVar14,&stack0x00000958 + lVar14)
      ;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102f5c;
      func_0x(&stack0x00000b10 + lVar14,&stack0x00002850 + lVar14,&stack0x00000958 + lVar14)
      ;
      *(undefined4 *)(&stack0x00000d20 + lVar14) = 0x1d;
      *(undefined4 *)(&stack0x00000d24 + lVar14) = 0x10000;
      if ((_DAT_ & 0x10000) != 0) {
        *(undefined2 *)(&stack0x00000750 + lVar14) = 6;
        *(undefined **)(&stack0x00001320 + lVar14) = &stack0x00002100 + lVar14;
        *(undefined2 *)(&stack0x00002100 + lVar14) = 0;
        *(undefined2 *)(&stack0x00002102 + lVar14) = 6;
        *(undefined4 *)(&stack0x00002108 + lVar14) = 0;
        *(undefined **)(&stack0x00002110 + lVar14) = &stack0x00002128 + lVar14;
        *(undefined **)(&stack0x00002118 + lVar14) = &stack0x00002188 + lVar14;
        *(undefined4 *)(&stack0x00002348 + lVar14) = 0;
        *(undefined4 *)(&stack0x0000234c + lVar14) = 0;
        *(undefined8 *)(&stack0x00002120 + lVar14) = 0;
        *(undefined8 *)(&stack0x00002350 + lVar14) = 0;
        *(undefined **)(&stack0x00001328 + lVar14) = &stack0x00002128 + lVar14;
        *(undefined **)(&stack0x00002128 + lVar14) = &stack0x00002358 + lVar14;
        *(undefined4 *)(&stack0x00002130 + lVar14) = 0x34;
        *(undefined2 *)(&stack0x00002134 + lVar14) = 5;
        *(undefined2 *)(&stack0x00002136 + lVar14) = 0;
        *(undefined **)(&stack0x00001330 + lVar14) = &stack0x00002138 + lVar14;
        *(undefined8 *)(&stack0x00002138 + lVar14) = 0x1855488;
        *(undefined4 *)(&stack0x00002140 + lVar14) = 0x10;
        *(undefined2 *)(&stack0x00002144 + lVar14) = 5;
        *(undefined2 *)(&stack0x00002146 + lVar14) = 0;
        *(undefined **)(&stack0x00001338 + lVar14) = &stack0x00002148 + lVar14;
        *(undefined8 *)(&stack0x00002148 + lVar14) = 0x1855488;
        *(undefined4 *)(&stack0x00002150 + lVar14) = 0x10;
        *(undefined2 *)(&stack0x00002154 + lVar14) = 6;
        *(undefined2 *)(&stack0x00002156 + lVar14) = 0;
        *(undefined **)(&stack0x00001340 + lVar14) = &stack0x00002158 + lVar14;
        *(undefined8 *)(&stack0x00002158 + lVar14) = 0;
        *(undefined4 *)(&stack0x00002160 + lVar14) = 0;
        *(undefined2 *)(&stack0x00002164 + lVar14) = 7;
        *(undefined2 *)(&stack0x00002166 + lVar14) = 0;
        *(undefined **)(&stack0x00001348 + lVar14) = &stack0x00002168 + lVar14;
        *(undefined8 *)(&stack0x00002168 + lVar14) = 0;
        *(undefined4 *)(&stack0x00002170 + lVar14) = 0;
        *(undefined2 *)(&stack0x00002174 + lVar14) = 8;
        *(undefined2 *)(&stack0x00002176 + lVar14) = 0;
        *(undefined **)(&stack0x00001350 + lVar14) = &stack0x00002178 + lVar14;
        *(undefined8 *)(&stack0x00002178 + lVar14) = 0;
        *(undefined4 *)(&stack0x00002180 + lVar14) = 0;
        *(undefined2 *)(&stack0x00002184 + lVar14) = 9;
        *(undefined2 *)(&stack0x00002186 + lVar14) = 0;
        *(uint *)(&stack0x00002358 + lVar14) = (uint)*(ushort *)(lVar23 + 0x6b8);
        *(undefined2 *)(&stack0x0000235c + lVar14) = *(undefined2 *)(&stack0x00000184 + lVar14);
        *(undefined4 *)(&stack0x0000235e + lVar14) = *(undefined4 *)(&stack0x00000180 + lVar14);
        (&stack0x00002362)[lVar14] = (&stack0x00000051)[lVar14];
        lVar23 = **param_2;
        *(longlong *)(&stack0x00001358 + lVar14) = lVar23;
        (&stack0x00002363)[lVar14] = *(undefined *)(lVar23 + 1);
        *(undefined **)(&stack0x00001360 + lVar14) = &stack0x00002138 + lVar14;
        *(longlong *)(&stack0x00002138 + lVar14) = lVar24 + 0x254;
        *(undefined4 *)(&stack0x00002140 + lVar14) = 0x10;
        *(undefined2 *)(&stack0x00002144 + lVar14) = 5;
        *(undefined2 *)(&stack0x00002146 + lVar14) = 0;
        *(undefined **)(&stack0x00001368 + lVar14) = &stack0x00002148 + lVar14;
        *(longlong *)(&stack0x00002148 + lVar14) = lVar24 + 0x244;
        *(undefined4 *)(&stack0x00002150 + lVar14) = 0x10;
        *(undefined2 *)(&stack0x00002154 + lVar14) = 6;
        *(undefined2 *)(&stack0x00002156 + lVar14) = 0;
        *(undefined **)(&stack0x00001370 + lVar14) = &stack0x00002820 + lVar14;
        lVar23 = -1;
        do {
          lVar23 = lVar23 + 1;
        } while (*(short *)(&stack0x00002820 + lVar23 * 2 + lVar14) != 0);
        iVar13 = (int)lVar23 * 2;
        *(int *)(&stack0x00000ba0 + lVar14) = iVar13;
        *(undefined **)(&stack0x00001378 + lVar14) = &stack0x00002158 + lVar14;
        *(undefined **)(&stack0x00002158 + lVar14) = &stack0x00002820 + lVar14;
        *(int *)(&stack0x00002160 + lVar14) = iVar13;
        *(undefined2 *)(&stack0x00002164 + lVar14) = 7;
        *(undefined2 *)(&stack0x00002166 + lVar14) = 0;
        *(undefined **)(&stack0x00001380 + lVar14) = &stack0x00002850 + lVar14;
        lVar23 = -1;
        do {
          lVar23 = lVar23 + 1;
        } while (*(short *)(&stack0x00002850 + lVar23 * 2 + lVar14) != 0);
        iVar13 = (int)lVar23 * 2;
        *(int *)(&stack0x00000ba4 + lVar14) = iVar13;
        *(undefined **)(&stack0x00001388 + lVar14) = &stack0x00002168 + lVar14;
        *(undefined **)(&stack0x00002168 + lVar14) = &stack0x00002850 + lVar14;
        *(int *)(&stack0x00002170 + lVar14) = iVar13;
        *(undefined2 *)(&stack0x00002174 + lVar14) = 8;
        *(undefined2 *)(&stack0x00002176 + lVar14) = 0;
        *(undefined4 *)(&stack0x0000095c + lVar14) = 0;
        UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1032f9;
        lVar23 = (*UNRECOVERED_JUMPTABLE_00)(lVar24,&stack0x0000095c + lVar14);
        *(longlong *)(&stack0x00001390 + lVar14) = lVar23;
        if (lVar23 != 0) {
          lVar24 = -1;
          do {
            lVar24 = lVar24 + 1;
          } while (*(short *)(lVar23 + lVar24 * 2) != 0);
          iVar12 = (int)lVar24 * 2;
        }
        *(int *)(&stack0x00000ba8 + lVar14) = iVar12;
        lVar24 = *(longlong *)(&stack0x00002110 + lVar14);
        *(longlong **)(&stack0x00001398 + lVar14) = (longlong *)(lVar24 + 0x50);
        *(longlong *)(lVar24 + 0x50) = lVar23;
        *(int *)(lVar24 + 0x58) = iVar12;
        *(undefined2 *)(lVar24 + 0x5c) = 9;
        *(undefined2 *)(lVar24 + 0x5e) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103356;
        func_0x(&stack0x000020f8 + lVar14);
      }
    }
LAB_:
    if ((1 < *(short *)((longlong)param_2 + 0xc)) && ((&stack0x00000051)[lVar14] != -1)) {
      lVar23 = **param_2;
      *(longlong *)(&stack0x00001428 + lVar14) = lVar23;
      if (*(char *)(lVar23 + 1) != (&stack0x00000051)[lVar14]) {
        if (*(longlong *)(&stack0x000004a8 + lVar14) != 0) {
          *(longlong *)(&stack0x00001430 + lVar14) = lVar23;
          *(longlong *)(*(longlong *)(&stack0x000004a8 + lVar14) + 0x588) = lVar23;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1037dc;
        lVar23 = func_0x();
        if (lVar23 == 0) {
LAB_:
          *(undefined4 *)(&stack0x00000978 + lVar14) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1037e6;
          lVar23 = func_0x();
          if (*(longlong *)(lVar23 + 0x30) == 0) goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1037f2;
          lVar23 = func_0x();
          uVar22 = *(uint *)(*(longlong *)(lVar23 + 0x30) + 0xc);
          *(uint *)(&stack0x00000bb4 + lVar14) = uVar22;
          if ((uVar22 < 0xe) && ((0x2640U >> (uVar22 & 0x1f) & 1) != 0)) {
            iVar12 = 1;
          }
          else {
            iVar12 = 0;
          }
          *(int *)(&stack0x00000978 + lVar14) = iVar12;
          if (iVar12 != 0) goto LAB_;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103837;
        func_0x(0,8);
      }
    }
LAB_:
    *(undefined4 *)(&stack0x00000b30 + lVar14) = 0;
    *(undefined4 *)(&stack0x00000b34 + lVar14) = 0;
    *(undefined2 *)(&stack0x00000b38 + lVar14) = 0;
    if (((*(short *)(&stack0x00000610 + lVar14) == 0) && (*(int *)(&stack0x00000608 + lVar14) == 0))
       && (*(int *)(&stack0x0000060c + lVar14) == 0)) goto LAB_;
    plVar27 = *param_2;
    lVar23 = *plVar27;
    *(longlong *)(&stack0x00001438 + lVar14) = lVar23;
    if ((*(byte *)(lVar23 + 4) & 1) == 0) goto LAB_;
    puVar15 = (ushort *)((longlong)plVar27 + 0x62);
    *(ushort **)(&stack0x00001440 + lVar14) = puVar15;
    uVar4 = *puVar15;
    *(ushort *)(&stack0x00000238 + lVar14) = uVar4;
    if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
      *(int *)(&stack0x000000d8 + lVar14) = (int)*(short *)((longlong)param_2 + 0xc);
      plVar27 = *param_2;
      *(longlong **)(&stack0x000003e0 + lVar14) = plVar27;
      puVar17 = (undefined2 *)((longlong)plVar27 + 0x62);
      *(undefined2 **)(&stack0x00001448 + lVar14) = puVar17;
      uVar11 = *puVar17;
      *(undefined2 *)(&stack0x00000240 + lVar14) = uVar11;
      if (((byte)uVar11 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x000000d8 + lVar14) == 3) {
          *(undefined4 *)(&stack0x000000d8 + lVar14) = 4;
        }
        else if (*(int *)(&stack0x000000d8 + lVar14) < 2) goto LAB_;
        *(uint **)(&stack0x00001450 + lVar14) =
             (uint *)(*(longlong *)(&stack0x000003e0 + lVar14) + 100);
        uVar22 = *(uint *)(*(longlong *)(&stack0x000003e0 + lVar14) + 100);
        *(uint *)(&stack0x00000980 + lVar14) = uVar22;
        if ((((uVar22 & 8) != 0) &&
            (lVar23 = *(longlong *)(*(longlong *)(&stack0x000003e0 + lVar14) + 0x90), lVar23 != 0))
           && (*(longlong *)(&stack0x00001458 + lVar14) = lVar23, *(longlong *)(lVar23 + 0x758) != 0
              )) {
          uVar19 = *(undefined8 *)(lVar23 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10397c;
          func_0x
                    (uVar19,*(undefined8 *)(&stack0x000003e0 + lVar14),
                     *(undefined4 *)(&stack0x000000d8 + lVar14));
        }
      }
LAB_:
      (&stack0x00000363)[lVar14] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar30 = (uint *)(*(longlong *)(&stack0x000003e0 + lVar14) + 100);
        *(uint **)(&stack0x00001460 + lVar14) = puVar30;
        uVar22 = *puVar30;
        *(uint *)(&stack0x00000988 + lVar14) = uVar22;
        if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000d8 + lVar14))) {
          *(uint **)(&stack0x00001468 + lVar14) = puVar30;
          uVar22 = *puVar30;
          *(uint *)(&stack0x00000990 + lVar14) = uVar22;
          if (((uVar22 & 0xc0000000) != 0x40000000) &&
             (lVar23 = **(longlong **)(&stack0x000003e0 + lVar14), lVar23 != 0)) {
            *(undefined4 *)(&stack0x00000bb8 + lVar14) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103a0f;
            iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000bbc + lVar14);
            if (iVar12 != 0) {
              LOCK();
              *puVar30 = *puVar30 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar30 = *puVar30 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar23 = *(longlong *)(&stack0x000003e0 + lVar14);
      uVar35 = *(undefined4 *)(&stack0x000000d8 + lVar14);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103a3e;
      func_0x(lVar23 + 0x98,uVar35);
      if ((_DAT_ != 0) &&
         ((&stack0x00000364)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103a68;
        func_0x(lVar23,0,uVar35);
      }
      *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
      *param_2 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1038b6;
      func_0x(param_2);
    }
    *(undefined4 *)(&stack0x00000f98 + lVar14) = 0x400060;
    *(undefined8 *)(&stack0x00000fa0 + lVar14) = 0;
    *(undefined8 *)(&stack0x00000fb0 + lVar14) = 0;
    *(undefined8 *)(&stack0x00000fa8 + lVar14) = 0;
    *(undefined8 *)(&stack0x00000fb8 + lVar14) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103ab4;
    func_0x(10,&stack0x00000f98 + lVar14);
    lVar24 = *(longlong *)(&stack0x00000070 + lVar14);
  } while( true );
LAB_:
  lVar23 = *(longlong *)(&stack0x00000900 + lVar14);
  *(int *)(lVar23 + 4) = *(int *)(lVar23 + 4) + 1;
  if (*(longlong *)(lVar23 + 0x58) != 0) {
    piVar28 = (int *)(*(longlong *)(lVar23 + 0x58) + 4);
    *piVar28 = *piVar28 + 1;
  }
  if ((*(uint *)(&stack0x00000044 + lVar14) & 0xff000000) != 0) {
    *(int *)(*(longlong *)(&stack0x00000900 + lVar14) + 8) =
         *(int *)(*(longlong *)(&stack0x00000900 + lVar14) + 8) + 1;
    if (*(longlong *)(lVar23 + 0x58) != 0) {
      piVar28 = (int *)(*(longlong *)(lVar23 + 0x58) + 8);
      *piVar28 = *piVar28 + 1;
    }
    if ((&stack0x00000048)[lVar14] != '\0') {
      *(int *)(*(longlong *)(&stack0x00000900 + lVar14) + 0xc) =
           *(int *)(*(longlong *)(&stack0x00000900 + lVar14) + 0xc) + 1;
      if (*(longlong *)(lVar23 + 0x58) != 0) {
        piVar28 = (int *)(*(longlong *)(lVar23 + 0x58) + 0xc);
        *piVar28 = *piVar28 + 1;
      }
    }
  }
  if (*(int *)(&stack0x00000ecc + lVar14) != 0) {
    lVar23 = **(longlong **)(&stack0x00000038 + lVar14);
    *(longlong *)(&stack0x000017b8 + lVar14) = lVar23;
    uVar3 = *(undefined *)(lVar23 + 1);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105919;
    func_0x
              (*(undefined8 *)(&stack0x00000d78 + lVar14),uVar3,&stack0x00000ec8 + lVar14,0xffffffff
              );
  }
  (&stack0x00000196)[lVar14] = 0;
  (&stack0x00000197)[lVar14] = 1;
  *(undefined4 *)(&stack0x000004c0 + lVar14) = 0;
  *(undefined2 *)(&stack0x000004c4 + lVar14) = 0;
  *(undefined2 *)(&stack0x000004c6 + lVar14) = 0;
  lVar23 = **(longlong **)(&stack0x00000a78 + lVar14);
  *(longlong *)(&stack0x00000d80 + lVar14) = lVar23;
  lVar24 = **(longlong **)(&stack0x00000038 + lVar14);
  *(longlong *)(&stack0x000017c0 + lVar14) = lVar24;
  lVar7 = *(longlong *)(lVar23 + 8);
  piVar28 = (int *)(lVar7 + 0x3c0);
  *(int **)(&stack0x000017c8 + lVar14) = piVar28;
  *(undefined4 *)(&stack0x00000698 + lVar14) = 0;
  if (*(int *)(lVar24 + 0x18) == *piVar28) {
    uVar4 = *(ushort *)(lVar7 + 0x3c4);
    if ((*(ushort *)(lVar24 + 6) != uVar4) && (1 < (uVar4 | *(ushort *)(lVar24 + 6))))
    goto LAB_;
    *(undefined4 *)(&stack0x00000698 + lVar14) = 1;
  }
  else {
LAB_:
    *(longlong *)(&stack0x000017d0 + lVar14) = lVar24;
    *(undefined4 *)(&stack0x000005b0 + lVar14) = 0;
    *(undefined2 *)(&stack0x000005b4 + lVar14) = 0;
    *(undefined2 *)(&stack0x000005b6 + lVar14) = 0;
    uVar35 = *(undefined4 *)(lVar24 + 0x18);
    *(undefined4 *)(&stack0x000005b0 + lVar14) = uVar35;
    uVar11 = *(undefined2 *)(lVar24 + 6);
    *(undefined2 *)(&stack0x000005b4 + lVar14) = uVar11;
    *(undefined4 *)(&stack0x000004c0 + lVar14) = uVar35;
    *(undefined2 *)(&stack0x000004c4 + lVar14) = uVar11;
    *(undefined2 *)(&stack0x000004c6 + lVar14) = 0;
    puVar17 = (undefined2 *)((longlong)*(longlong **)(&stack0x00000038 + lVar14) + 0x62);
    *(undefined2 **)(&stack0x000017d8 + lVar14) = puVar17;
    *(undefined2 *)(&stack0x00000298 + lVar14) = *puVar17;
    if (((*(ushort *)(&stack0x00000298 + lVar14) & 0x400) == 0) ||
       (*(short *)(&stack0x00000044 + lVar14) < 3)) {
      *(int *)(&stack0x00000108 + lVar14) = (int)*(short *)(&stack0x00000044 + lVar14);
      *(undefined8 *)(&stack0x00000908 + lVar14) = *(undefined8 *)(&stack0x00000038 + lVar14);
      *(undefined2 **)(&stack0x000017e0 + lVar14) = puVar17;
      uVar5 = *puVar17;
      *(undefined2 *)(&stack0x000002a0 + lVar14) = uVar5;
      if (((byte)uVar5 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000108 + lVar14) == 3) {
          *(undefined4 *)(&stack0x00000108 + lVar14) = 4;
        }
        else if (*(int *)(&stack0x00000108 + lVar14) < 2) goto LAB_;
        *(uint **)(&stack0x000017e8 + lVar14) =
             (uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
        uVar22 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
        *(uint *)(&stack0x000006a0 + lVar14) = uVar22;
        if ((((uVar22 & 8) != 0) &&
            (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar14) + 0x90), lVar24 != 0))
           && (*(longlong *)(&stack0x000017f0 + lVar14) = lVar24, *(longlong *)(lVar24 + 0x758) != 0
              )) {
          uVar19 = *(undefined8 *)(lVar24 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105ae4;
          func_0x
                    (uVar19,*(undefined8 *)(&stack0x00000038 + lVar14),
                     *(undefined4 *)(&stack0x00000108 + lVar14));
        }
      }
LAB_:
      (&stack0x00000198)[lVar14] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar30 = (uint *)(*(longlong *)(&stack0x00000908 + lVar14) + 100);
        *(uint **)(&stack0x000017f8 + lVar14) = puVar30;
        uVar22 = *puVar30;
        *(uint *)(&stack0x000006a8 + lVar14) = uVar22;
        if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000108 + lVar14))) {
          *(uint **)(&stack0x00001800 + lVar14) = puVar30;
          uVar22 = *puVar30;
          *(uint *)(&stack0x000006b0 + lVar14) = uVar22;
          if (((uVar22 & 0xc0000000) != 0x40000000) &&
             (lVar24 = **(longlong **)(&stack0x00000908 + lVar14), lVar24 != 0)) {
            *(undefined4 *)(&stack0x00000c00 + lVar14) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105b79;
            iVar12 = (*_DAT_)(lVar24,0x2000,2,&stack0x00000c04 + lVar14);
            if (iVar12 != 0) {
              LOCK();
              *puVar30 = *puVar30 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar30 = *puVar30 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar24 = *(longlong *)(&stack0x00000908 + lVar14);
      uVar36 = *(undefined4 *)(&stack0x00000108 + lVar14);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105ba8;
      func_0x(lVar24 + 0x98,uVar36);
      if ((_DAT_ != 0) &&
         ((&stack0x00000199)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105bd2;
        func_0x(lVar24,0,uVar36);
      }
      *(uint *)(&stack0x00000044 + lVar14) = *(uint *)(&stack0x00000044 + lVar14) & 0xffff0000;
      *(undefined8 *)(&stack0x00000038 + lVar14) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105a33;
      func_0x(&stack0x00000038 + lVar14);
    }
    *(undefined **)(&stack0x00001808 + lVar14) = &stack0x000005c0 + lVar14;
    *(undefined **)(&stack0x00001810 + lVar14) = &stack0x000005d0 + lVar14;
    lVar23 = *(longlong *)(lVar23 + 8);
    puVar25 = (undefined4 *)(lVar23 + 0x3c0);
    *(undefined4 **)(&stack0x00001818 + lVar14) = puVar25;
    *(undefined4 *)(&stack0x000005c0 + lVar14) = *puVar25;
    *(undefined2 *)(&stack0x000005c4 + lVar14) = *(undefined2 *)(lVar23 + 0x3c4);
    *(undefined2 *)(&stack0x000005c6 + lVar14) = 0;
    *(undefined4 *)(&stack0x000005d0 + lVar14) = uVar35;
    *(undefined2 *)(&stack0x000005d4 + lVar14) = uVar11;
    *(undefined2 *)(&stack0x000005d6 + lVar14) = 0;
    UNRECOVERED_JUMPTABLE_00 = *(code **)**(undefined8 **)(&stack0x00000d80 + lVar14);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105c57;
    uVar11 = (*UNRECOVERED_JUMPTABLE_00)();
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) =
         *(undefined4 *)(*(longlong *)(&stack0x00000a78 + lVar14) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105c87;
    func_0x(&stack0x00000178 + lVar14,&stack0x000005d0 + lVar14,uVar11,
                    &stack0x000005c0 + lVar14);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105c99;
  func_0x(&stack0x00000ef8 + lVar14,&stack0x00000038 + lVar14);
  lVar23 = **param_2;
  goto LAB_;
LAB_:
  lVar23 = *(longlong *)(&stack0x000008d8 + lVar14);
  *(int *)(lVar23 + 4) = *(int *)(lVar23 + 4) + 1;
  if (*(longlong *)(lVar23 + 0x58) != 0) {
    piVar28 = (int *)(*(longlong *)(lVar23 + 0x58) + 4);
    *piVar28 = *piVar28 + 1;
  }
  if ((*(uint *)((longlong)param_2 + 0xc) & 0xff000000) != 0) {
    *(int *)(*(longlong *)(&stack0x000008d8 + lVar14) + 8) =
         *(int *)(*(longlong *)(&stack0x000008d8 + lVar14) + 8) + 1;
    if (*(longlong *)(lVar23 + 0x58) != 0) {
      piVar28 = (int *)(*(longlong *)(lVar23 + 0x58) + 8);
      *piVar28 = *piVar28 + 1;
    }
    if (*(char *)(param_2 + 2) != '\0') {
      *(int *)(*(longlong *)(&stack0x000008d8 + lVar14) + 0xc) =
           *(int *)(*(longlong *)(&stack0x000008d8 + lVar14) + 0xc) + 1;
      if (*(longlong *)(lVar23 + 0x58) != 0) {
        piVar28 = (int *)(*(longlong *)(lVar23 + 0x58) + 0xc);
        *piVar28 = *piVar28 + 1;
      }
    }
  }
  if (*(int *)(&stack0x00000eb4 + lVar14) != 0) {
    lVar23 = **param_2;
    *(longlong *)(&stack0x00001470 + lVar14) = lVar23;
    uVar3 = *(undefined *)(lVar23 + 1);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103b4f;
    func_0x
              (*(undefined8 *)(&stack0x00000d28 + lVar14),uVar3,&stack0x00000eb0 + lVar14,0xffffffff
              );
  }
  (&stack0x00000365)[lVar14] = 0;
  (&stack0x00000366)[lVar14] = 1;
  *(undefined4 *)(&stack0x000004b0 + lVar14) = 0;
  *(undefined2 *)(&stack0x000004b4 + lVar14) = 0;
  *(undefined2 *)(&stack0x000004b6 + lVar14) = 0;
  lVar23 = **(longlong **)(&stack0x00000a20 + lVar14);
  *(longlong *)(&stack0x00000d30 + lVar14) = lVar23;
  plVar27 = *param_2;
  lVar24 = *plVar27;
  *(longlong *)(&stack0x00001478 + lVar14) = lVar24;
  lVar7 = *(longlong *)(lVar23 + 8);
  piVar28 = (int *)(lVar7 + 0x3c0);
  *(int **)(&stack0x00001480 + lVar14) = piVar28;
  *(undefined4 *)(&stack0x00000998 + lVar14) = 0;
  if (*(int *)(lVar24 + 0x18) == *piVar28) {
    uVar4 = *(ushort *)(lVar7 + 0x3c4);
    if ((*(ushort *)(lVar24 + 6) != uVar4) && (1 < (uVar4 | *(ushort *)(lVar24 + 6))))
    goto LAB_;
    *(undefined4 *)(&stack0x00000998 + lVar14) = 1;
  }
  else {
LAB_:
    *(longlong *)(&stack0x00001488 + lVar14) = lVar24;
    *(undefined4 *)(&stack0x000005d8 + lVar14) = 0;
    *(undefined2 *)(&stack0x000005dc + lVar14) = 0;
    *(undefined2 *)(&stack0x000005de + lVar14) = 0;
    uVar35 = *(undefined4 *)(lVar24 + 0x18);
    *(undefined4 *)(&stack0x000005d8 + lVar14) = uVar35;
    uVar11 = *(undefined2 *)(lVar24 + 6);
    *(undefined2 *)(&stack0x000005dc + lVar14) = uVar11;
    *(undefined4 *)(&stack0x000004b0 + lVar14) = uVar35;
    *(undefined2 *)(&stack0x000004b4 + lVar14) = uVar11;
    *(undefined2 *)(&stack0x000004b6 + lVar14) = 0;
    puVar17 = (undefined2 *)((longlong)plVar27 + 0x62);
    *(undefined2 **)(&stack0x00001490 + lVar14) = puVar17;
    *(undefined2 *)(&stack0x00000248 + lVar14) = *puVar17;
    if (((*(ushort *)(&stack0x00000248 + lVar14) & 0x400) == 0) ||
       (*(short *)((longlong)param_2 + 0xc) < 3)) {
      *(int *)(&stack0x000000e0 + lVar14) = (int)*(short *)((longlong)param_2 + 0xc);
      plVar27 = *param_2;
      *(longlong **)(&stack0x000003e8 + lVar14) = plVar27;
      puVar17 = (undefined2 *)((longlong)plVar27 + 0x62);
      *(undefined2 **)(&stack0x00001498 + lVar14) = puVar17;
      uVar5 = *puVar17;
      *(undefined2 *)(&stack0x00000250 + lVar14) = uVar5;
      if (((byte)uVar5 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x000000e0 + lVar14) == 3) {
          *(undefined4 *)(&stack0x000000e0 + lVar14) = 4;
        }
        else if (*(int *)(&stack0x000000e0 + lVar14) < 2) goto LAB_;
        *(uint **)(&stack0x000014a0 + lVar14) =
             (uint *)(*(longlong *)(&stack0x000003e8 + lVar14) + 100);
        uVar22 = *(uint *)(*(longlong *)(&stack0x000003e8 + lVar14) + 100);
        *(uint *)(&stack0x000009a0 + lVar14) = uVar22;
        if ((((uVar22 & 8) != 0) &&
            (lVar24 = *(longlong *)(*(longlong *)(&stack0x000003e8 + lVar14) + 0x90), lVar24 != 0))
           && (*(longlong *)(&stack0x000014a8 + lVar14) = lVar24, *(longlong *)(lVar24 + 0x758) != 0
              )) {
          uVar19 = *(undefined8 *)(lVar24 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103d31;
          func_0x
                    (uVar19,*(undefined8 *)(&stack0x000003e8 + lVar14),
                     *(undefined4 *)(&stack0x000000e0 + lVar14));
        }
      }
LAB_:
      (&stack0x00000367)[lVar14] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar30 = (uint *)(*(longlong *)(&stack0x000003e8 + lVar14) + 100);
        *(uint **)(&stack0x000014b0 + lVar14) = puVar30;
        uVar22 = *puVar30;
        *(uint *)(&stack0x000009a8 + lVar14) = uVar22;
        if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000e0 + lVar14))) {
          *(uint **)(&stack0x000014b8 + lVar14) = puVar30;
          uVar22 = *puVar30;
          *(uint *)(&stack0x000009b0 + lVar14) = uVar22;
          if (((uVar22 & 0xc0000000) != 0x40000000) &&
             (lVar24 = **(longlong **)(&stack0x000003e8 + lVar14), lVar24 != 0)) {
            *(undefined4 *)(&stack0x00000bc0 + lVar14) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103dc6;
            iVar12 = (*_DAT_)(lVar24,0x2000,2,&stack0x00000bc4 + lVar14);
            if (iVar12 != 0) {
              LOCK();
              *puVar30 = *puVar30 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar30 = *puVar30 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar24 = *(longlong *)(&stack0x000003e8 + lVar14);
      uVar36 = *(undefined4 *)(&stack0x000000e0 + lVar14);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103df5;
      func_0x(lVar24 + 0x98,uVar36);
      if ((_DAT_ != 0) &&
         ((&stack0x00000368)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103e1f;
        func_0x(lVar24,0,uVar36);
      }
      *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
      *param_2 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103c6b;
      func_0x(param_2);
    }
    *(undefined **)(&stack0x000014c0 + lVar14) = &stack0x000005e0 + lVar14;
    *(undefined **)(&stack0x000014c8 + lVar14) = &stack0x000005e8 + lVar14;
    lVar23 = *(longlong *)(lVar23 + 8);
    puVar25 = (undefined4 *)(lVar23 + 0x3c0);
    *(undefined4 **)(&stack0x000014d0 + lVar14) = puVar25;
    *(undefined4 *)(&stack0x000005e0 + lVar14) = *puVar25;
    *(undefined2 *)(&stack0x000005e4 + lVar14) = *(undefined2 *)(lVar23 + 0x3c4);
    *(undefined2 *)(&stack0x000005e6 + lVar14) = 0;
    *(undefined4 *)(&stack0x000005e8 + lVar14) = uVar35;
    *(undefined2 *)(&stack0x000005ec + lVar14) = uVar11;
    *(undefined2 *)(&stack0x000005ee + lVar14) = 0;
    UNRECOVERED_JUMPTABLE_00 = *(code **)**(undefined8 **)(&stack0x00000d30 + lVar14);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103ea3;
    uVar11 = (*UNRECOVERED_JUMPTABLE_00)();
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) =
         *(undefined4 *)(*(longlong *)(&stack0x00000a20 + lVar14) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103ed3;
    func_0x(&stack0x00000180 + lVar14,&stack0x000005e8 + lVar14,uVar11,
                    &stack0x000005e0 + lVar14);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103eee;
  func_0x(&stack0x00000ef8 + lVar14,*(undefined8 *)(&stack0x00000920 + lVar14));
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103efe;
  func_0x(&stack0x00000ef8 + lVar14,pplVar6);
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103f0e;
  func_0x(&stack0x00000ef8 + lVar14,param_2);
  plVar27 = *pplVar6;
  lVar23 = *plVar27;
  *(longlong *)(&stack0x000014d8 + lVar14) = lVar23;
  if (*(short *)(lVar23 + 0x16) != 1) {
    *(undefined2 *)(&stack0x00000f38 + lVar14) = 0xffff;
    *(undefined8 *)(&stack0x00000f40 + lVar14) = 0;
    *(undefined4 *)(&stack0x00000f3c + lVar14) = 0;
    *(undefined8 *)(&stack0x00000f56 + lVar14) = 0;
    *(undefined8 *)(&stack0x00000f60 + lVar14) = 0;
    *(undefined8 *)(&stack0x00000f48 + lVar14) = 0;
    *(undefined (*) [16])(&stack0x000026d0 + lVar14) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000026a8 + lVar14) = ZEXT816(0);
    lVar23 = *plVar27;
    *(longlong *)(&stack0x000019d8 + lVar14) = lVar23;
    iVar12 = *(ushort *)(lVar23 + 0x16) - 1;
    *(int *)(&stack0x00000338 + lVar14) = iVar12;
    *(int *)(&stack0x00000c44 + lVar14) = iVar12;
    *(longlong *)(&stack0x000019e0 + lVar14) = lVar23;
    *(int *)(&stack0x00002744 + lVar14) = iVar12;
    if (-1 < *(char *)(lVar23 + 2)) {
      *(undefined8 *)(&stack0x00000918 + lVar14) = 0;
      goto LAB_;
    }
    if (*(short *)(&stack0x00002710 + lVar14) == 0) {
      *(undefined8 *)(&stack0x00000918 + lVar14) = 0;
LAB_:
      *(undefined **)(&stack0x000019e8 + lVar14) = &stack0x00002748 + lVar14;
      *(undefined (*) [16])(&stack0x00002748 + lVar14) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002758 + lVar14) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002768 + lVar14) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002778 + lVar14) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002788 + lVar14) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002798 + lVar14) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x000027a8 + lVar14) = ZEXT816(0);
      *(undefined8 *)(&stack0x000027b8 + lVar14) = 0;
      *(undefined **)(&stack0x000019f0 + lVar14) = &stack0x00002748 + lVar14;
      *(undefined (*) [16])(&stack0x00002748 + lVar14) = ZEXT816(0);
      *(undefined **)(&stack0x000019f8 + lVar14) = &stack0x00002758 + lVar14;
      *(undefined2 *)(&stack0x00002758 + lVar14) = 0xffff;
      *(undefined8 *)(&stack0x00002760 + lVar14) = 0;
      *(undefined4 *)(&stack0x0000275c + lVar14) = 0;
      *(undefined8 *)(&stack0x00002776 + lVar14) = 0;
      *(undefined8 *)(&stack0x00002780 + lVar14) = 0;
      *(undefined8 *)(&stack0x00002768 + lVar14) = 0;
      *(undefined **)(&stack0x00001a00 + lVar14) = &stack0x00002790 + lVar14;
      *(undefined8 *)(&stack0x00002790 + lVar14) = 0;
      *(undefined **)(&stack0x00001a08 + lVar14) = &stack0x000027a8 + lVar14;
      *(undefined4 *)(&stack0x000027a8 + lVar14) = 0;
      *(undefined4 *)(&stack0x000027ac + lVar14) = 0;
      *(undefined2 *)(&stack0x000027b0 + lVar14) = 0;
      *(undefined2 *)(&stack0x000027b2 + lVar14) = 0;
      *(undefined **)(&stack0x00001a10 + lVar14) = &stack0x000027b4 + lVar14;
      *(undefined2 *)(&stack0x000027ba + lVar14) = 0;
      ppbVar34 = (byte **)(&stack0x00002748 + lVar14);
      *(byte ***)(&stack0x00000918 + lVar14) = ppbVar34;
    }
    else {
      ppbVar34 = *(byte ***)(&stack0x00002720 + lVar14);
      *(byte ***)(&stack0x00000918 + lVar14) = ppbVar34;
      if (ppbVar34 == (byte **)0x0) goto LAB_;
    }
    (&stack0x00000098)[lVar14] = 0;
    if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000380 + lVar14) = *(undefined8 *)(lVar23 + 0x28);
      sVar10 = *(short *)(lVar23 + 0x30);
      *(short *)(&stack0x00000388 + lVar14) = sVar10;
    }
    else {
      cVar8 = *(char *)(lVar23 + 1);
      if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) &&
         (*(int *)(lVar23 + 0x18) == 99)) {
        *(undefined **)(&stack0x00001a18 + lVar14) = &stack0x000005a0 + lVar14;
        *(undefined4 **)(&stack0x00001a20 + lVar14) = (undefined4 *)(lVar23 + 0x20);
        *(undefined4 *)(&stack0x000005a0 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
        *(undefined2 *)(&stack0x000005a4 + lVar14) = *(undefined2 *)(lVar23 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x107087;
        cVar8 = func_0x(&stack0x000005a0 + lVar14);
        if (cVar8 == '\0') goto LAB_;
        cVar8 = '\x01';
      }
      else {
LAB_:
        cVar8 = '\0';
      }
      (&stack0x00000098)[lVar14] = cVar8;
      if (cVar8 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1070ac;
      func_0x(lVar23,&stack0x00000380 + lVar14);
      sVar10 = *(short *)(&stack0x00000388 + lVar14);
    }
    *(undefined **)(&stack0x00001a28 + lVar14) = &stack0x00000380 + lVar14;
    *(undefined4 **)(&stack0x00001a30 + lVar14) = (undefined4 *)(lVar23 + 0x20);
    pbVar32 = (byte *)(lVar23 + 0x60);
    *(byte **)(&stack0x00001a38 + lVar14) = pbVar32;
    *(byte ***)(&stack0x00001a40 + lVar14) = ppbVar34;
    if (pbVar32 == *ppbVar34) {
      *(byte ***)(&stack0x00001a48 + lVar14) = ppbVar34 + 0xc;
      if (((sVar10 == *(short *)(ppbVar34 + 0xd)) &&
          (*(int *)(&stack0x00000380 + lVar14) == *(int *)(ppbVar34 + 0xc))) &&
         (*(int *)(&stack0x00000384 + lVar14) == *(int *)((longlong)ppbVar34 + 100))) {
        *(longlong *)(&stack0x00001a50 + lVar14) = (longlong)ppbVar34 + 0x6c;
      }
    }
    *ppbVar34 = pbVar32;
    *(byte ***)(&stack0x00001a58 + lVar14) = ppbVar34 + 0xc;
    uVar11 = *(undefined2 *)(&stack0x00000388 + lVar14);
    *(undefined2 *)(&stack0x00000780 + lVar14) = uVar11;
    uVar35 = *(undefined4 *)(&stack0x00000384 + lVar14);
    *(undefined4 *)(&stack0x00000c48 + lVar14) = uVar35;
    *(undefined4 *)(&stack0x00000c50 + lVar14) = *(undefined4 *)(&stack0x00000380 + lVar14);
    *(undefined4 *)(ppbVar34 + 0xc) = *(undefined4 *)(&stack0x00000380 + lVar14);
    *(undefined4 *)((longlong)ppbVar34 + 100) = uVar35;
    *(undefined2 *)(ppbVar34 + 0xd) = uVar11;
    *(undefined4 **)(&stack0x00001a60 + lVar14) = (undefined4 *)((longlong)ppbVar34 + 0x6c);
    *(undefined4 *)((longlong)ppbVar34 + 0x6c) = *(undefined4 *)(lVar23 + 0x20);
    *(undefined2 *)(ppbVar34 + 0xe) = *(undefined2 *)(lVar23 + 0x24);
    *(undefined2 *)((longlong)ppbVar34 + 0x72) = 0;
    uVar20 = (ulonglong)*pbVar32;
    *(ushort *)(&stack0x00000788 + lVar14) = (ushort)*pbVar32;
    *(undefined4 *)(&stack0x00000a98 + lVar14) = *(undefined4 *)(uVar20 * 6 + 0x1725b90);
    *(undefined2 *)(&stack0x00000a9c + lVar14) = *(undefined2 *)(uVar20 * 6 + 0x1725b94);
    *(undefined4 *)(&stack0x000007b0 + lVar14) = *(undefined4 *)(uVar20 * 6 + 0x1725b90);
    sVar10 = *(short *)(uVar20 * 6 + 0x1725b94);
    *(short *)(&stack0x00000054 + lVar14) = sVar10;
    *(short *)(&stack0x000007b4 + lVar14) = sVar10;
    *(longlong *)(&stack0x00001a68 + lVar14) = lVar23 + 99;
    ppbVar1 = ppbVar34 + 2;
    *(byte ***)(&stack0x00001a70 + lVar14) = ppbVar1;
    *(undefined2 *)ppbVar1 = 0xffff;
    ppbVar34[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar34 + 0x2e) = 0;
    ppbVar34[7] = (byte *)0x0;
    ppbVar34[4] = (byte *)0x0;
    ppsVar2 = (short **)(ppbVar34 + 9);
    *(short ***)(&stack0x00001a78 + lVar14) = ppsVar2;
    *ppsVar2 = (short *)0x0;
    ppbVar34[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar34 + 0xb) = 0;
    if ((**ppbVar34 & 2) != 0) {
      pbVar32 = pbVar32 + sVar10;
      *(byte **)(&stack0x00001a80 + lVar14) = pbVar32;
      *(byte ***)(&stack0x00001a88 + lVar14) = ppbVar1;
      bVar9 = *pbVar32 & 1;
      *(ushort *)(&stack0x00000790 + lVar14) = (ushort)bVar9;
      *(ushort *)ppbVar1 = (ushort)bVar9;
      if (bVar9 != 0) {
        *(longlong *)(&stack0x00001aa0 + lVar14) = (longlong)ppbVar34 + 0x12;
        ppbVar34[3] = pbVar32;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar32 & 0x1c) + 0x1086ac) *
                                4 + 0x10869c) - 0xe142a0);
                    /* WARNING: Could not emulate address calculation at 0x00107373 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      *(undefined4 *)(&stack0x00000328 + lVar14) = 0;
      *(longlong *)(&stack0x00001a90 + lVar14) = (longlong)ppbVar34 + 0x12;
      ppbVar34[3] = pbVar32;
      *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar34 + 0x36) = 0;
      pbVar32 = ppbVar34[3];
      *(byte **)(&stack0x00001a98 + lVar14) = pbVar32;
                    /* WARNING: Could not emulate address calculation at 0x001072be */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar32 & 0xe) * 4 + 0x108660) - 0xe142a0))()
      ;
      return;
    }
    if ((**ppbVar34 & 4) != 0) {
      if (*(short *)(&stack0x000007b2 + lVar14) == 0) {
        uVar20 = (ulonglong)sVar10;
      }
      else {
        uVar20 = (ulonglong)
                 *(ushort *)(lVar23 + 0x61 + (longlong)*(short *)(&stack0x000007b2 + lVar14) * 2);
      }
      psVar21 = (short *)(pbVar32 + uVar20);
      *(short **)(&stack0x00001ac8 + lVar14) = psVar21;
      *(short ***)(&stack0x00001ad0 + lVar14) = ppsVar2;
      *ppsVar2 = psVar21;
      sVar10 = *psVar21;
      *(short *)(&stack0x00000794 + lVar14) = sVar10;
      ppbVar34[10] = (byte *)(psVar21 + 1);
      *(short *)(ppbVar34 + 0xb) = (sVar10 + 1) * 2;
    }
    pbVar32 = ppbVar34[1];
    if (pbVar32 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10761c;
      func_0x(pbVar32,ppbVar34);
    }
LAB_:
    uVar4 = *(ushort *)(lVar23 + 0xe);
    *(uint *)(&stack0x00000c58 + lVar14) = (uint)uVar4;
    pbVar32 = (byte *)((ulonglong)
                       *(ushort *)
                        (lVar23 + (0xfff - (longlong)*(int *)(&stack0x00000338 + lVar14)) * 2) +
                      lVar23);
    *(byte **)(&stack0x00001ad8 + lVar14) = pbVar32;
    bVar9 = *pbVar32 & 1;
    *(ushort *)(&stack0x00000798 + lVar14) = (ushort)bVar9;
    *(ushort *)(&stack0x00002710 + lVar14) = (ushort)bVar9;
    if (bVar9 != 0) {
      *(undefined **)(&stack0x00001af0 + lVar14) = &stack0x00002712 + lVar14;
      *(byte **)(&stack0x00002718 + lVar14) = pbVar32;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar32 & 0x1c) + 0x108718) * 4
                             + 0x108708) - 0xe142a0);
                    /* WARNING: Could not emulate address calculation at 0x00107750 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    *(uint *)(&stack0x00000330 + lVar14) = (uint)uVar4;
    *(undefined **)(&stack0x00001ae0 + lVar14) = &stack0x00002712 + lVar14;
    *(byte **)(&stack0x00002718 + lVar14) = pbVar32;
    *(undefined4 *)(&stack0x00002714 + lVar14) = 0;
    *(undefined4 *)(&stack0x00002736 + lVar14) = 0;
    *(byte **)(&stack0x00001ae8 + lVar14) = pbVar32;
                    /* WARNING: Could not emulate address calculation at 0x001076a7 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar32 & 0xe) * 4 + 0x1086cc) - 0xe142a0))();
    return;
  }
  *(undefined4 *)(&stack0x00000a8c + lVar14) = 0;
  *(undefined2 *)(&stack0x00000a90 + lVar14) = 0;
  lVar23 = **param_2;
  *(longlong *)(&stack0x000014e0 + lVar14) = lVar23;
  piVar28 = (int *)(lVar23 + 0x10);
  *(int **)(&stack0x000014e8 + lVar14) = piVar28;
  iVar12 = *piVar28;
  *(int *)(&stack0x00000a92 + lVar14) = iVar12;
  sVar10 = *(short *)(lVar23 + 0x14);
  *(short *)(&stack0x00000a96 + lVar14) = sVar10;
  if ((iVar12 != 0) || (sVar10 != 0)) {
    *(longlong *)(&stack0x000014f0 + lVar14) = lVar23;
    *(int **)(&stack0x000014f8 + lVar14) = piVar28;
    *(int *)(&stack0x00000178 + lVar14) = iVar12;
    *(undefined2 *)(&stack0x0000017c + lVar14) = *(undefined2 *)(lVar23 + 0x14);
    plVar27 = *(longlong **)(*(longlong *)(&stack0x00000448 + lVar14) + 8);
    *(longlong **)(&stack0x00000a78 + lVar14) = plVar27;
    *(undefined8 *)(&stack0x00000900 + lVar14) =
         *(undefined8 *)(*(longlong *)(&stack0x00000448 + lVar14) + 0x10);
    *(undefined4 *)(&stack0x00000618 + lVar14) = 0;
    *(undefined4 *)(&stack0x0000061c + lVar14) = 0;
    *(undefined2 *)(&stack0x00000620 + lVar14) = 0;
    lVar23 = *plVar27;
    *(longlong *)(&stack0x00000d78 + lVar14) = lVar23;
    *(undefined4 *)(&stack0x00000ecc + lVar14) = 0;
    *(undefined4 *)(&stack0x00000ed0 + lVar14) = 0;
    lVar24 = *(longlong *)(lVar23 + 0x20);
    *(longlong *)(&stack0x00000078 + lVar14) = lVar24;
    *(uint6 **)(&stack0x00001500 + lVar14) = (uint6 *)(lVar23 + 0x14);
    lVar23 = (ulonglong)*(uint6 *)(lVar23 + 0x14) * 0x10000;
    *(longlong *)(&stack0x00001508 + lVar14) = lVar23;
    if ((*(longlong *)(lVar24 + 2000) == lVar23) &&
       (*(longlong *)(lVar24 + 2000) - 1U < 0xfffffffffffffffe)) {
      (&stack0x000000a5)[lVar14] = 1;
    }
    else {
      (&stack0x000000a5)[lVar14] = 0;
      if ((*(longlong *)(lVar24 + 0x7d8) == lVar23) &&
         (*(longlong *)(lVar24 + 0x7d8) - 1U < 0xfffffffffffffffe)) {
        (&stack0x000000a6)[lVar14] = 1;
      }
      else {
        (&stack0x000000a6)[lVar14] = 0;
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001510 + lVar14) = lVar23;
        lVar24 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00001518 + lVar14) = lVar24;
        lVar23 = *(longlong *)(lVar24 + 0x100);
        *(longlong *)(&stack0x00000d38 + lVar14) = lVar23;
        puVar30 = _DAT_;
        if (lVar23 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1040b4;
          puVar30 = (uint *)(*_DAT_)();
          lVar23 = *(longlong *)(lVar24 + 0x100);
          *(longlong *)(&stack0x00000d38 + lVar14) = lVar23;
        }
        *(longlong *)(&stack0x00001520 + lVar14) = lVar23;
        uVar20 = rdtsc();
        uVar18 = CONCAT44((int)((ulonglong)puVar30 >> 0x20),(int)uVar20) |
                 uVar20 & 0xffffffff00000000;
        *(ulonglong *)(&stack0x00001528 + lVar14) = uVar18;
        uVar20 = *(ulonglong *)(lVar23 + 0x340);
        if ((uVar20 < uVar18) ||
           ((uVar20 != 0x7fffffffffffffff &&
            (*(ulonglong *)(*(longlong *)(lVar23 + 0x260) + 0xdf0) < uVar20 - uVar18)))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104181;
          iVar12 = func_0x(0,0x2049690);
          *(int *)(&stack0x00000488 + lVar14) = iVar12;
          if (iVar12 == 2) {
LAB_:
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104194;
            func_0x(0x7c);
          }
        }
        else {
          lVar23 = *(longlong *)(lVar23 + 600);
          *(longlong *)(&stack0x00000d40 + lVar14) = lVar23;
          puVar30 = (uint *)(lVar23 + 0xbc);
          *(uint **)(&stack0x00001530 + lVar14) = puVar30;
          if ((*puVar30 & 4) != 0) {
            lVar23 = *(longlong *)(*(longlong *)(&stack0x00000d40 + lVar14) + 0x98);
            *(longlong *)(&stack0x00001538 + lVar14) = lVar23;
            if (((*(byte *)(lVar23 + 0x268) & 1) == 0) && ((*(uint *)(lVar23 + 800) & 0x180) == 0))
            {
              *(undefined4 *)(&stack0x00000488 + lVar14) = 2;
              goto LAB_;
            }
          }
          *(undefined4 *)(&stack0x00000488 + lVar14) = 0;
        }
        lVar24 = *(longlong *)(&stack0x00000078 + lVar14);
      }
    }
    *(undefined4 *)(&stack0x00000b40 + lVar14) = 0;
    *(undefined4 *)(&stack0x00000b44 + lVar14) = 0;
    *(undefined2 *)(&stack0x00000b48 + lVar14) = 0;
    (&stack0x00000094)[lVar14] = 0;
    (&stack0x00000052)[lVar14] = 0xff;
    do {
      uVar19 = 0;
      *(undefined **)(&stack0x00000a28 + lVar14) = &stack0x00000ec8 + lVar14;
      *(undefined4 *)(&stack0x0000266c + lVar14) = 0;
      *(undefined4 *)(&stack0x00002670 + lVar14) = 0;
      cVar8 = *_DAT_;
      (&stack0x00000369)[lVar14] = cVar8;
      if ((cVar8 != '\0') &&
         ((&stack0x0000036a)[lVar14] = DAT_ >> 7, -1 < (char)DAT_)) {
        *(undefined4 *)(&stack0x000009b8 + lVar14) = 0;
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001540 + lVar14) = lVar23;
        plVar27 = (longlong *)
                  ((ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8)
                  );
        *(longlong **)(&stack0x00001548 + lVar14) = plVar27;
        lVar23 = *plVar27;
        *(longlong *)(&stack0x00001550 + lVar14) = lVar23;
        if (lVar23 == 0) {
LAB_:
          *(undefined8 *)(&stack0x00000d48 + lVar14) = 0;
        }
        else {
          lVar23 = **(longlong **)(lVar23 + 0x38);
          *(longlong *)(&stack0x00001558 + lVar14) = lVar23;
          if (lVar23 == 0) goto LAB_;
          *(longlong *)(&stack0x00000d48 + lVar14) = lVar23;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104295;
          iVar12 = (*_DAT_)(lVar23,0x337);
          *(int *)(&stack0x000009b8 + lVar14) = iVar12;
          if (iVar12 != 0) {
            lVar24 = *(longlong *)(&stack0x00000078 + lVar14);
            goto LAB_;
          }
        }
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001560 + lVar14) = lVar23;
        lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00001568 + lVar14) = lVar23;
        lVar23 = *(longlong *)(lVar23 + 8);
        *(longlong *)(&stack0x00001570 + lVar14) = lVar23;
        lVar24 = *(longlong *)(&stack0x00000078 + lVar14);
        if (lVar23 != 0) {
          uVar19 = *(undefined8 *)(lVar23 + 0x60);
        }
      }
LAB_:
      *(undefined8 *)(&stack0x000004b8 + lVar14) = uVar19;
      plVar27 = (longlong *)(lVar24 + 0x728);
      *(longlong *)(&stack0x00000d50 + lVar14) = *plVar27;
LAB_:
      *(undefined4 *)(&stack0x0000048c + lVar14) = 0;
      if (*(longlong *)(&stack0x00000038 + lVar14) != 0) {
        puVar17 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar14) + 0x62);
        *(undefined2 **)(&stack0x00001578 + lVar14) = puVar17;
        *(undefined2 *)(&stack0x00000258 + lVar14) = *puVar17;
        if (((*(ushort *)(&stack0x00000258 + lVar14) & 0x400) == 0) ||
           (*(short *)(&stack0x00000044 + lVar14) < 3)) {
          *(int *)(&stack0x000000e8 + lVar14) = (int)*(short *)(&stack0x00000044 + lVar14);
          *(undefined8 *)(&stack0x000008e0 + lVar14) = *(undefined8 *)(&stack0x00000038 + lVar14);
          *(undefined2 **)(&stack0x00001580 + lVar14) = puVar17;
          uVar11 = *puVar17;
          *(undefined2 *)(&stack0x00000260 + lVar14) = uVar11;
          if (((byte)uVar11 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x000000e8 + lVar14) == 3) {
              *(undefined4 *)(&stack0x000000e8 + lVar14) = 4;
            }
            else if (*(int *)(&stack0x000000e8 + lVar14) < 2) goto LAB_;
            *(uint **)(&stack0x00001588 + lVar14) =
                 (uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
            uVar22 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
            *(uint *)(&stack0x000009c0 + lVar14) = uVar22;
            if ((((uVar22 & 8) != 0) &&
                (lVar23 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar14) + 0x90),
                lVar23 != 0)) &&
               (*(longlong *)(&stack0x00001590 + lVar14) = lVar23,
               *(longlong *)(lVar23 + 0x758) != 0)) {
              uVar19 = *(undefined8 *)(lVar23 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10442b;
              func_0x
                        (uVar19,*(undefined8 *)(&stack0x00000038 + lVar14),
                         *(undefined4 *)(&stack0x000000e8 + lVar14));
            }
          }
LAB_:
          (&stack0x0000036b)[lVar14] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar30 = (uint *)(*(longlong *)(&stack0x000008e0 + lVar14) + 100);
            *(uint **)(&stack0x00001598 + lVar14) = puVar30;
            uVar22 = *puVar30;
            *(uint *)(&stack0x000009c8 + lVar14) = uVar22;
            if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000e8 + lVar14))) {
              *(uint **)(&stack0x000015a0 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x000009d0 + lVar14) = uVar22;
              if (((uVar22 & 0xc0000000) != 0x40000000) &&
                 (lVar23 = **(longlong **)(&stack0x000008e0 + lVar14), lVar23 != 0)) {
                *(undefined4 *)(&stack0x00000bc8 + lVar14) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1044be;
                iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000bcc + lVar14);
                if (iVar12 != 0) {
                  LOCK();
                  *puVar30 = *puVar30 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar30 = *puVar30 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar23 = *(longlong *)(&stack0x000008e0 + lVar14);
          uVar35 = *(undefined4 *)(&stack0x000000e8 + lVar14);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1044ed;
          func_0x(lVar23 + 0x98,uVar35);
          if ((_DAT_ != 0) &&
             ((&stack0x00000390)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104517;
            func_0x(lVar23,0,uVar35);
          }
          *(uint *)(&stack0x00000044 + lVar14) = *(uint *)(&stack0x00000044 + lVar14) & 0xffff0000;
          *(undefined8 *)(&stack0x00000038 + lVar14) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10431c;
          func_0x(&stack0x00000038 + lVar14);
        }
        lVar24 = *(longlong *)(&stack0x00000078 + lVar14);
      }
      if (*plVar27 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10454d;
        func_0x(&stack0x00000038 + lVar14,&stack0x00000178 + lVar14,lVar24);
        if (*(longlong *)(&stack0x00000038 + lVar14) != 0) {
          puVar17 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar14) + 0x62);
          *(undefined2 **)(&stack0x000015a8 + lVar14) = puVar17;
          *(undefined2 *)(&stack0x00000268 + lVar14) = *puVar17;
          if (((*(ushort *)(&stack0x00000268 + lVar14) & 0x400) == 0) ||
             (*(short *)(&stack0x00000044 + lVar14) < 3)) {
            *(int *)(&stack0x000000f0 + lVar14) = (int)*(short *)(&stack0x00000044 + lVar14);
            *(undefined8 *)(&stack0x000008e8 + lVar14) = *(undefined8 *)(&stack0x00000038 + lVar14);
            *(undefined2 **)(&stack0x000015b0 + lVar14) = puVar17;
            uVar11 = *puVar17;
            *(undefined2 *)(&stack0x00000270 + lVar14) = uVar11;
            if (((byte)uVar11 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000f0 + lVar14) == 3) {
                *(undefined4 *)(&stack0x000000f0 + lVar14) = 4;
              }
              else if (*(int *)(&stack0x000000f0 + lVar14) < 2) goto LAB_;
              *(uint **)(&stack0x000015b8 + lVar14) =
                   (uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
              uVar22 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
              *(uint *)(&stack0x000009d8 + lVar14) = uVar22;
              if ((((uVar22 & 8) != 0) &&
                  (lVar23 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar14) + 0x90),
                  lVar23 != 0)) &&
                 (*(longlong *)(&stack0x000015c0 + lVar14) = lVar23,
                 *(longlong *)(lVar23 + 0x758) != 0)) {
                uVar19 = *(undefined8 *)(lVar23 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104644;
                func_0x
                          (uVar19,*(undefined8 *)(&stack0x00000038 + lVar14),
                           *(undefined4 *)(&stack0x000000f0 + lVar14));
              }
            }
LAB_:
            (&stack0x00000190)[lVar14] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar30 = (uint *)(*(longlong *)(&stack0x000008e8 + lVar14) + 100);
              *(uint **)(&stack0x000015c8 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x000009e0 + lVar14) = uVar22;
              if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000f0 + lVar14))) {
                *(uint **)(&stack0x000015d0 + lVar14) = puVar30;
                uVar22 = *puVar30;
                *(uint *)(&stack0x000009e8 + lVar14) = uVar22;
                if (((uVar22 & 0xc0000000) != 0x40000000) &&
                   (lVar23 = **(longlong **)(&stack0x000008e8 + lVar14), lVar23 != 0)) {
                  *(undefined4 *)(&stack0x00000bd0 + lVar14) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1046d7;
                  iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000bd4 + lVar14);
                  if (iVar12 != 0) {
                    LOCK();
                    *puVar30 = *puVar30 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar30 = *puVar30 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar23 = *(longlong *)(&stack0x000008e8 + lVar14);
            uVar35 = *(undefined4 *)(&stack0x000000f0 + lVar14);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104706;
            func_0x(lVar23 + 0x98,uVar35);
            if ((_DAT_ != 0) &&
               ((&stack0x00000191)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104730;
              func_0x(lVar23,0,uVar35);
            }
            *(uint *)(&stack0x00000044 + lVar14) = *(uint *)(&stack0x00000044 + lVar14) & 0xffff0000
            ;
            *(undefined8 *)(&stack0x00000038 + lVar14) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104592;
            func_0x(&stack0x00000038 + lVar14);
          }
          lVar24 = *(longlong *)(&stack0x00000078 + lVar14);
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104757;
      func_0x(lVar24,&stack0x00000178 + lVar14);
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) =
           *(undefined8 *)(&stack0x00000a28 + lVar14);
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 4;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10478b;
      plVar16 = (longlong *)func_0x(_DAT_,lVar24,&stack0x00000178 + lVar14);
      *(longlong **)(&stack0x00000038 + lVar14) = plVar16;
      uVar22 = *(uint *)(&stack0x00000044 + lVar14) & 0xffff0004 | 4;
      *(uint *)(&stack0x00000044 + lVar14) = uVar22;
      if (*(longlong *)(&stack0x000004b8 + lVar14) != 0) {
        lVar23 = *plVar16;
        *(longlong *)(&stack0x000015d8 + lVar14) = lVar23;
        plVar31 = (longlong *)(*(longlong *)(&stack0x000004b8 + lVar14) + 0x500);
        *(longlong **)(&stack0x000015e0 + lVar14) = plVar31;
        plVar16 = plVar31 + (ulonglong)(*(uint *)plVar31 & 0xf) + 1;
        *(longlong **)(&stack0x000015e8 + lVar14) = plVar16;
        if (*plVar16 != lVar23) {
          *plVar16 = lVar23;
          *plVar31 = *plVar31 + 1;
          uVar22 = *(uint *)(&stack0x00000044 + lVar14);
        }
      }
      uVar26 = *(uint *)(&stack0x0000048c + lVar14) >> 3 & 1;
      *(uint *)(&stack0x00000044 + lVar14) = uVar26 << 0x18 | uVar22 & 0xffffff;
      *(uint *)(&stack0x00000048 + lVar14) =
           *(uint *)(&stack0x0000048c + lVar14) >> 4 & 1 |
           *(uint *)(&stack0x00000048 + lVar14) & 0xffffff00;
      lVar23 = *(longlong *)(&stack0x00000d50 + lVar14);
      if (((lVar23 != 0) && (*(longlong *)(&stack0x000004b8 + lVar14) != 0)) &&
         (*(longlong *)(&stack0x000004b8 + lVar14) == *(longlong *)(lVar24 + 0x1c38))) {
        *(uint *)(&stack0x00000bd8 + lVar14) = uVar26;
        *(longlong *)(&stack0x000015f0 + lVar14) = lVar23 + 0x59b8;
        *(longlong *)(lVar23 + 0x5b28) = *(longlong *)(lVar23 + 0x5b28) + 1;
        puVar30 = *(uint **)(&stack0x00000a28 + lVar14);
        if (puVar30[1] != 0) {
          *(longlong *)(lVar23 + 0x5b30) = *(longlong *)(lVar23 + 0x5b30) + 1;
          *(longlong *)(lVar23 + 0x5b38) = *(longlong *)(lVar23 + 0x5b38) + (ulonglong)*puVar30;
          if (uVar26 != 0) {
            *(longlong *)(lVar23 + 0x5b40) = *(longlong *)(lVar23 + 0x5b40) + 1;
            *(longlong *)(lVar23 + 0x5b48) = *(longlong *)(lVar23 + 0x5b48) + (ulonglong)*puVar30;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1048ad;
      cVar8 = func_0x(lVar24);
      if ((cVar8 == '\0') || (*(char *)(lVar24 + 0x2050) == '\0')) goto LAB_;
      if (*(int *)(&stack0x00000178 + lVar14) != 0) {
        *(undefined4 *)(&stack0x00000aa4 + lVar14) = 9;
        *(undefined2 *)(&stack0x00000aa8 + lVar14) = 1;
        if ((*(int *)(&stack0x00000178 + lVar14) == 9) &&
           (*(short *)(&stack0x0000017c + lVar14) == 1)) goto LAB_;
        (&stack0x00000096)[lVar14] = 0;
        lVar23 = **(longlong **)(&stack0x00000038 + lVar14);
        *(longlong *)(&stack0x000015f8 + lVar14) = lVar23;
        (&stack0x00000092)[lVar14] = 0;
        if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x000004f8 + lVar14) = *(undefined8 *)(lVar23 + 0x28);
          *(undefined2 *)(&stack0x00000500 + lVar14) = *(undefined2 *)(lVar23 + 0x30);
        }
        else {
          cVar8 = *(char *)(lVar23 + 1);
          if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) &&
             (*(int *)(lVar23 + 0x18) == 99)) {
            *(undefined **)(&stack0x00001600 + lVar14) = &stack0x00000590 + lVar14;
            *(undefined4 **)(&stack0x00001608 + lVar14) = (undefined4 *)(lVar23 + 0x20);
            *(undefined4 *)(&stack0x00000590 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
            *(undefined2 *)(&stack0x00000594 + lVar14) = *(undefined2 *)(lVar23 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104975;
            cVar8 = func_0x(&stack0x00000590 + lVar14);
            if (cVar8 == '\0') goto LAB_;
            cVar8 = '\x01';
          }
          else {
LAB_:
            cVar8 = '\0';
          }
          (&stack0x00000092)[lVar14] = cVar8;
          if (cVar8 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10499a;
          func_0x(lVar23,&stack0x000004f8 + lVar14);
        }
        *(undefined **)(&stack0x00001610 + lVar14) = &stack0x000004f8 + lVar14;
        *(longlong *)(&stack0x00000d58 + lVar14) = lVar24 + 0x20fc;
        *(undefined4 *)(&stack0x00000470 + lVar14) = 0;
        *(undefined4 *)(&stack0x00000474 + lVar14) = 0;
        *(undefined2 *)(&stack0x00000478 + lVar14) = 0;
        *(undefined2 *)(&stack0x0000047a + lVar14) = 0;
        puVar30 = (uint *)(lVar24 + 0x2108);
        *(uint **)(&stack0x00001618 + lVar14) = puVar30;
        uVar22 = *puVar30;
        *(uint *)(&stack0x00000490 + lVar14) = uVar22;
        *(uint **)(&stack0x00000d60 + lVar14) = puVar30;
        do {
          *(uint *)(&stack0x0000064c + lVar14) = uVar22 & 0xfffffffe;
          *(undefined8 *)(&stack0x00000470 + lVar14) = **(undefined8 **)(&stack0x00000d58 + lVar14);
          *(undefined4 *)(&stack0x00000478 + lVar14) =
               *(undefined4 *)(*(undefined8 **)(&stack0x00000d58 + lVar14) + 1);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14);
          UNLOCK();
          uVar22 = **(uint **)(&stack0x00000d60 + lVar14);
          *(uint *)(&stack0x00000490 + lVar14) = uVar22;
        } while (*(uint *)(&stack0x0000064c + lVar14) != uVar22);
        if ((*(uint *)(&stack0x000004f8 + lVar14) <= *(uint *)(&stack0x00000470 + lVar14)) &&
           ((*(uint *)(&stack0x00000470 + lVar14) != *(uint *)(&stack0x000004f8 + lVar14) ||
            ((uVar22 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000470 + lVar14) >> 0x20),
             *(uint *)(&stack0x000004fc + lVar14) <= uVar22 &&
             ((uVar22 != *(uint *)(&stack0x000004fc + lVar14) ||
              (*(ushort *)(&stack0x00000500 + lVar14) <= *(ushort *)(&stack0x00000478 + lVar14))))))
            ))) goto LAB_;
        if (*(char *)(*(longlong *)(&stack0x00000078 + lVar14) + 0x6ac8) == '\0') {
          lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          *(longlong *)(&stack0x00001620 + lVar14) = lVar23;
          lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8)
          ;
          *(longlong *)(&stack0x00001628 + lVar14) = lVar23;
          lVar23 = *(longlong *)(lVar23 + 8);
          *(longlong *)(&stack0x00001630 + lVar14) = lVar23;
          lVar23 = *(longlong *)(lVar23 + 0x60);
          *(longlong *)(&stack0x00001638 + lVar14) = lVar23;
          if (lVar23 != *(longlong *)(*(longlong *)(&stack0x00000078 + lVar14) + 0x2120)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104b2a;
            cVar8 = func_0x(*(longlong *)(&stack0x00000078 + lVar14));
            if (cVar8 == '\0') {
              *(longlong *)(&stack0x00000a30 + lVar14) = lVar24 + 0x20fc;
              iVar12 = 0;
              *(undefined4 *)(&stack0x00000418 + lVar14) = 0;
              *(undefined4 *)(&stack0x0000041c + lVar14) = 0;
              *(undefined2 *)(&stack0x00000420 + lVar14) = 0;
              *(undefined2 *)(&stack0x00000422 + lVar14) = 0;
              *(uint **)(&stack0x00001640 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x00000494 + lVar14) = uVar22;
              puVar29 = *(undefined8 **)(&stack0x00000a30 + lVar14);
              *(longlong *)(&stack0x00000d68 + lVar14) = (longlong)puVar29 + 0xc;
              while( true ) {
                *(uint *)(&stack0x00000650 + lVar14) = uVar22 & 0xfffffffe;
                *(undefined8 *)(&stack0x00000418 + lVar14) = *puVar29;
                *(undefined4 *)(&stack0x00000420 + lVar14) = *(undefined4 *)(puVar29 + 1);
                LOCK();
                *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14) =
                     *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14);
                UNLOCK();
                uVar22 = **(uint **)(&stack0x00000d68 + lVar14);
                *(uint *)(&stack0x00000494 + lVar14) = uVar22;
                if (*(uint *)(&stack0x00000650 + lVar14) == uVar22) break;
                puVar29 = *(undefined8 **)(&stack0x00000a30 + lVar14);
              }
              *(undefined8 *)(&stack0x00000b50 + lVar14) =
                   *(undefined8 *)(&stack0x00000418 + lVar14);
              uVar4 = *(ushort *)(&stack0x00000420 + lVar14);
              *(ushort *)(&stack0x00000b58 + lVar14) = uVar4;
              lVar23 = **(longlong **)(&stack0x00000038 + lVar14);
              *(longlong *)(&stack0x00001648 + lVar14) = lVar23;
              (&stack0x00000093)[lVar14] = 0;
              if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x000004e8 + lVar14) = *(undefined8 *)(lVar23 + 0x28);
                uVar33 = *(ushort *)(lVar23 + 0x30);
                *(ushort *)(&stack0x000004f0 + lVar14) = uVar33;
              }
              else {
                cVar8 = *(char *)(lVar23 + 1);
                if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) &&
                   (*(int *)(lVar23 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00001650 + lVar14) = &stack0x00000580 + lVar14;
                  *(undefined4 **)(&stack0x00001658 + lVar14) = (undefined4 *)(lVar23 + 0x20);
                  *(undefined4 *)(&stack0x00000580 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
                  *(undefined2 *)(&stack0x00000584 + lVar14) = *(undefined2 *)(lVar23 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104c65;
                  cVar8 = func_0x(&stack0x00000580 + lVar14);
                  if (cVar8 == '\0') goto LAB_;
                  cVar8 = '\x01';
                }
                else {
LAB_:
                  cVar8 = '\0';
                }
                (&stack0x00000093)[lVar14] = cVar8;
                if (cVar8 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104c8a;
                func_0x(lVar23,&stack0x000004e8 + lVar14);
                uVar33 = *(ushort *)(&stack0x000004f0 + lVar14);
              }
              if ((*(uint *)(&stack0x00000418 + lVar14) < *(uint *)(&stack0x000004e8 + lVar14)) ||
                 ((*(uint *)(&stack0x00000418 + lVar14) == *(uint *)(&stack0x000004e8 + lVar14) &&
                  ((uVar22 = (uint)((ulonglong)*(undefined8 *)(&stack0x000004e8 + lVar14) >> 0x20),
                   *(uint *)(&stack0x0000041c + lVar14) < uVar22 ||
                   ((*(uint *)(&stack0x0000041c + lVar14) == uVar22 && (uVar4 < uVar33)))))))) {
                lVar23 = *(longlong *)(&stack0x00000078 + lVar14);
                lVar24 = *(longlong *)(lVar23 + 0x6b0);
                *(longlong *)(&stack0x00001660 + lVar14) = lVar24;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104d21;
                func_0x(&stack0x000004e8 + lVar14,&stack0x00002880 + lVar14,
                                &stack0x00000654 + lVar14);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x104d3e;
                func_0x(&stack0x00000b50 + lVar14,&stack0x000028b0 + lVar14,
                                &stack0x00000654 + lVar14);
                *(undefined4 *)(&stack0x00000d70 + lVar14) = 0x1d;
                *(undefined4 *)(&stack0x00000d74 + lVar14) = 0x10000;
                if ((_DAT_ & 0x10000) != 0) {
                  *(undefined2 *)(&stack0x00000758 + lVar14) = 6;
                  *(undefined **)(&stack0x00001668 + lVar14) = &stack0x000023a0 + lVar14;
                  *(undefined2 *)(&stack0x000023a0 + lVar14) = 0;
                  *(undefined2 *)(&stack0x000023a2 + lVar14) = 6;
                  *(undefined4 *)(&stack0x000023a8 + lVar14) = 0;
                  *(undefined **)(&stack0x000023b0 + lVar14) = &stack0x000023c8 + lVar14;
                  *(undefined **)(&stack0x000023b8 + lVar14) = &stack0x00002428 + lVar14;
                  *(undefined4 *)(&stack0x000025e8 + lVar14) = 0;
                  *(undefined4 *)(&stack0x000025ec + lVar14) = 0;
                  *(undefined8 *)(&stack0x000023c0 + lVar14) = 0;
                  *(undefined8 *)(&stack0x000025f0 + lVar14) = 0;
                  *(undefined **)(&stack0x00001670 + lVar14) = &stack0x000023c8 + lVar14;
                  *(undefined **)(&stack0x000023c8 + lVar14) = &stack0x000025f8 + lVar14;
                  *(undefined4 *)(&stack0x000023d0 + lVar14) = 0x34;
                  *(undefined2 *)(&stack0x000023d4 + lVar14) = 5;
                  *(undefined2 *)(&stack0x000023d6 + lVar14) = 0;
                  *(undefined **)(&stack0x00001678 + lVar14) = &stack0x000023d8 + lVar14;
                  *(undefined8 *)(&stack0x000023d8 + lVar14) = 0x1855488;
                  *(undefined4 *)(&stack0x000023e0 + lVar14) = 0x10;
                  *(undefined2 *)(&stack0x000023e4 + lVar14) = 5;
                  *(undefined2 *)(&stack0x000023e6 + lVar14) = 0;
                  *(undefined **)(&stack0x00001680 + lVar14) = &stack0x000023e8 + lVar14;
                  *(undefined8 *)(&stack0x000023e8 + lVar14) = 0x1855488;
                  *(undefined4 *)(&stack0x000023f0 + lVar14) = 0x10;
                  *(undefined2 *)(&stack0x000023f4 + lVar14) = 6;
                  *(undefined2 *)(&stack0x000023f6 + lVar14) = 0;
                  *(undefined **)(&stack0x00001688 + lVar14) = &stack0x000023f8 + lVar14;
                  *(undefined8 *)(&stack0x000023f8 + lVar14) = 0;
                  *(undefined4 *)(&stack0x00002400 + lVar14) = 0;
                  *(undefined2 *)(&stack0x00002404 + lVar14) = 7;
                  *(undefined2 *)(&stack0x00002406 + lVar14) = 0;
                  *(undefined **)(&stack0x00001690 + lVar14) = &stack0x00002408 + lVar14;
                  *(undefined8 *)(&stack0x00002408 + lVar14) = 0;
                  *(undefined4 *)(&stack0x00002410 + lVar14) = 0;
                  *(undefined2 *)(&stack0x00002414 + lVar14) = 8;
                  *(undefined2 *)(&stack0x00002416 + lVar14) = 0;
                  *(undefined **)(&stack0x00001698 + lVar14) = &stack0x00002418 + lVar14;
                  *(undefined8 *)(&stack0x00002418 + lVar14) = 0;
                  *(undefined4 *)(&stack0x00002420 + lVar14) = 0;
                  *(undefined2 *)(&stack0x00002424 + lVar14) = 9;
                  *(undefined2 *)(&stack0x00002426 + lVar14) = 0;
                  *(uint *)(&stack0x000025f8 + lVar14) = (uint)*(ushort *)(lVar23 + 0x6b8);
                  *(undefined2 *)(&stack0x000025fc + lVar14) =
                       *(undefined2 *)(&stack0x0000017c + lVar14);
                  *(undefined4 *)(&stack0x000025fe + lVar14) =
                       *(undefined4 *)(&stack0x00000178 + lVar14);
                  (&stack0x00002602)[lVar14] = (&stack0x00000052)[lVar14];
                  lVar23 = **(longlong **)(&stack0x00000038 + lVar14);
                  *(longlong *)(&stack0x000016a0 + lVar14) = lVar23;
                  (&stack0x00002603)[lVar14] = *(undefined *)(lVar23 + 1);
                  *(undefined **)(&stack0x000016a8 + lVar14) = &stack0x000023d8 + lVar14;
                  *(longlong *)(&stack0x000023d8 + lVar14) = lVar24 + 0x254;
                  *(undefined4 *)(&stack0x000023e0 + lVar14) = 0x10;
                  *(undefined2 *)(&stack0x000023e4 + lVar14) = 5;
                  *(undefined2 *)(&stack0x000023e6 + lVar14) = 0;
                  *(undefined **)(&stack0x000016b0 + lVar14) = &stack0x000023e8 + lVar14;
                  *(longlong *)(&stack0x000023e8 + lVar14) = lVar24 + 0x244;
                  *(undefined4 *)(&stack0x000023f0 + lVar14) = 0x10;
                  *(undefined2 *)(&stack0x000023f4 + lVar14) = 6;
                  *(undefined2 *)(&stack0x000023f6 + lVar14) = 0;
                  *(undefined **)(&stack0x000016b8 + lVar14) = &stack0x00002880 + lVar14;
                  lVar23 = -1;
                  do {
                    lVar23 = lVar23 + 1;
                  } while (*(short *)(&stack0x00002880 + lVar23 * 2 + lVar14) != 0);
                  iVar13 = (int)lVar23 * 2;
                  *(int *)(&stack0x00000be0 + lVar14) = iVar13;
                  *(undefined **)(&stack0x000016c0 + lVar14) = &stack0x000023f8 + lVar14;
                  *(undefined **)(&stack0x000023f8 + lVar14) = &stack0x00002880 + lVar14;
                  *(int *)(&stack0x00002400 + lVar14) = iVar13;
                  *(undefined2 *)(&stack0x00002404 + lVar14) = 7;
                  *(undefined2 *)(&stack0x00002406 + lVar14) = 0;
                  *(undefined **)(&stack0x000016c8 + lVar14) = &stack0x000028b0 + lVar14;
                  lVar23 = -1;
                  do {
                    lVar23 = lVar23 + 1;
                  } while (*(short *)(&stack0x000028b0 + lVar23 * 2 + lVar14) != 0);
                  iVar13 = (int)lVar23 * 2;
                  *(int *)(&stack0x00000be4 + lVar14) = iVar13;
                  *(undefined **)(&stack0x000016d0 + lVar14) = &stack0x00002408 + lVar14;
                  *(undefined **)(&stack0x00002408 + lVar14) = &stack0x000028b0 + lVar14;
                  *(int *)(&stack0x00002410 + lVar14) = iVar13;
                  *(undefined2 *)(&stack0x00002414 + lVar14) = 8;
                  *(undefined2 *)(&stack0x00002416 + lVar14) = 0;
                  *(undefined4 *)(&stack0x00000658 + lVar14) = 0;
                  UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1050d9;
                  lVar23 = (*UNRECOVERED_JUMPTABLE_00)(lVar24,&stack0x00000658 + lVar14);
                  *(longlong *)(&stack0x000016d8 + lVar14) = lVar23;
                  if (lVar23 != 0) {
                    lVar24 = -1;
                    do {
                      lVar24 = lVar24 + 1;
                    } while (*(short *)(lVar23 + lVar24 * 2) != 0);
                    iVar12 = (int)lVar24 * 2;
                  }
                  *(int *)(&stack0x00000be8 + lVar14) = iVar12;
                  lVar24 = *(longlong *)(&stack0x000023b0 + lVar14);
                  *(longlong **)(&stack0x000016e0 + lVar14) = (longlong *)(lVar24 + 0x50);
                  *(longlong *)(lVar24 + 0x50) = lVar23;
                  *(int *)(lVar24 + 0x58) = iVar12;
                  *(undefined2 *)(lVar24 + 0x5c) = 9;
                  *(undefined2 *)(lVar24 + 0x5e) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105136;
                  func_0x(&stack0x00002398 + lVar14);
                }
              }
              goto LAB_;
            }
          }
        }
        if ((&stack0x00000094)[lVar14] != '\0') goto LAB_;
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x000016e8 + lVar14) = lVar23;
        lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x000016f0 + lVar14) = lVar23;
        lVar23 = *(longlong *)(lVar23 + 8);
        *(longlong *)(&stack0x000016f8 + lVar14) = lVar23;
        lVar23 = *(longlong *)(lVar23 + 0x60);
        *(longlong *)(&stack0x00001700 + lVar14) = lVar23;
        lVar24 = *(longlong *)(&stack0x00000078 + lVar14);
        if (lVar23 == *(longlong *)(lVar24 + 0x2120)) goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1051b0;
        cVar8 = func_0x(lVar24);
        if (cVar8 != '\0') goto LAB_;
        if (*(longlong *)(&stack0x000004b8 + lVar14) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1051c8;
          uVar19 = func_0x();
          *(undefined8 *)(&stack0x000004b8 + lVar14) = uVar19;
        }
        *(undefined **)(&stack0x00001708 + lVar14) = &stack0x000004d8 + lVar14;
        lVar23 = **(longlong **)(&stack0x00000038 + lVar14);
        *(longlong *)(&stack0x00001710 + lVar14) = lVar23;
        (&stack0x00000095)[lVar14] = 0;
        if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
          uVar19 = *(undefined8 *)(lVar23 + 0x28);
          uVar35 = (undefined4)uVar19;
          uVar36 = (undefined4)((ulonglong)uVar19 >> 0x20);
          *(undefined8 *)(&stack0x000004d8 + lVar14) = uVar19;
          uVar11 = *(undefined2 *)(lVar23 + 0x30);
          *(undefined2 *)(&stack0x000004e0 + lVar14) = uVar11;
        }
        else {
          cVar8 = *(char *)(lVar23 + 1);
          if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) &&
             (*(int *)(lVar23 + 0x18) == 99)) {
            *(undefined **)(&stack0x00001718 + lVar14) = &stack0x000005a8 + lVar14;
            *(undefined4 **)(&stack0x00001720 + lVar14) = (undefined4 *)(lVar23 + 0x20);
            *(undefined4 *)(&stack0x000005a8 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
            *(undefined2 *)(&stack0x000005ac + lVar14) = *(undefined2 *)(lVar23 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10525b;
            cVar8 = func_0x(&stack0x000005a8 + lVar14);
            if (cVar8 == '\0') goto LAB_;
            cVar8 = '\x01';
          }
          else {
LAB_:
            cVar8 = '\0';
          }
          (&stack0x00000095)[lVar14] = cVar8;
          if (cVar8 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105280;
          func_0x(lVar23,&stack0x000004d8 + lVar14);
          uVar11 = *(undefined2 *)(&stack0x000004e0 + lVar14);
          uVar35 = (undefined4)*(undefined8 *)(&stack0x000004d8 + lVar14);
          uVar36 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x000004d8 + lVar14) >> 0x20);
        }
        *(undefined **)(&stack0x00001728 + lVar14) = &stack0x000004d8 + lVar14;
        *(ulonglong *)(&stack0x00000640 + lVar14) = CONCAT44(uVar36,uVar35);
        *(undefined2 *)(&stack0x00000648 + lVar14) = uVar11;
        *(undefined2 *)(&stack0x0000064a + lVar14) = 0;
        if (*(longlong *)(&stack0x00000038 + lVar14) != 0) {
          puVar17 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar14) + 0x62);
          *(undefined2 **)(&stack0x00001730 + lVar14) = puVar17;
          *(undefined2 *)(&stack0x00000278 + lVar14) = *puVar17;
          if (((*(ushort *)(&stack0x00000278 + lVar14) & 0x400) == 0) ||
             (*(short *)(&stack0x00000044 + lVar14) < 3)) {
            *(int *)(&stack0x000000f8 + lVar14) = (int)*(short *)(&stack0x00000044 + lVar14);
            *(undefined8 *)(&stack0x000008f0 + lVar14) = *(undefined8 *)(&stack0x00000038 + lVar14);
            *(undefined2 **)(&stack0x00001738 + lVar14) = puVar17;
            uVar11 = *puVar17;
            *(undefined2 *)(&stack0x00000280 + lVar14) = uVar11;
            if (((byte)uVar11 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000f8 + lVar14) == 3) {
                *(undefined4 *)(&stack0x000000f8 + lVar14) = 4;
              }
              else if (*(int *)(&stack0x000000f8 + lVar14) < 2) goto LAB_;
              *(uint **)(&stack0x00001740 + lVar14) =
                   (uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
              uVar22 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
              *(uint *)(&stack0x00000660 + lVar14) = uVar22;
              if ((((uVar22 & 8) != 0) &&
                  (lVar23 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar14) + 0x90),
                  lVar23 != 0)) &&
                 (*(longlong *)(&stack0x00001748 + lVar14) = lVar23,
                 *(longlong *)(lVar23 + 0x758) != 0)) {
                uVar19 = *(undefined8 *)(lVar23 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1053d3;
                func_0x
                          (uVar19,*(undefined8 *)(&stack0x00000038 + lVar14),
                           *(undefined4 *)(&stack0x000000f8 + lVar14));
              }
            }
LAB_:
            (&stack0x00000192)[lVar14] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar30 = (uint *)(*(longlong *)(&stack0x000008f0 + lVar14) + 100);
              *(uint **)(&stack0x00001750 + lVar14) = puVar30;
              uVar22 = *puVar30;
              *(uint *)(&stack0x00000668 + lVar14) = uVar22;
              if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000f8 + lVar14))) {
                *(uint **)(&stack0x00001758 + lVar14) = puVar30;
                uVar22 = *puVar30;
                *(uint *)(&stack0x00000670 + lVar14) = uVar22;
                if (((uVar22 & 0xc0000000) != 0x40000000) &&
                   (lVar23 = **(longlong **)(&stack0x000008f0 + lVar14), lVar23 != 0)) {
                  *(undefined4 *)(&stack0x00000bec + lVar14) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105466;
                  iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000bf0 + lVar14);
                  if (iVar12 != 0) {
                    LOCK();
                    *puVar30 = *puVar30 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar30 = *puVar30 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar23 = *(longlong *)(&stack0x000008f0 + lVar14);
            uVar35 = *(undefined4 *)(&stack0x000000f8 + lVar14);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105495;
            func_0x(lVar23 + 0x98,uVar35);
            if ((_DAT_ != 0) &&
               ((&stack0x00000193)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1054bf;
              func_0x(lVar23,0,uVar35);
            }
            *(uint *)(&stack0x00000044 + lVar14) = *(uint *)(&stack0x00000044 + lVar14) & 0xffff0000
            ;
            *(undefined8 *)(&stack0x00000038 + lVar14) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105322;
            func_0x(&stack0x00000038 + lVar14);
          }
          uVar35 = (undefined4)*(undefined8 *)(&stack0x00000640 + lVar14);
          uVar36 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x00000640 + lVar14) >> 0x20);
          uVar11 = *(undefined2 *)(&stack0x00000648 + lVar14);
          lVar24 = *(longlong *)(&stack0x00000078 + lVar14);
        }
        *(undefined **)(&stack0x00001760 + lVar14) = &stack0x00000ab0 + lVar14;
        *(ulonglong *)(&stack0x00000ab0 + lVar14) = CONCAT44(uVar36,uVar35);
        *(undefined2 *)(&stack0x00000ab8 + lVar14) = uVar11;
        *(undefined **)(&stack0x00001768 + lVar14) = &stack0x00000a10 + lVar14;
        *(ulonglong *)(&stack0x00000a10 + lVar14) = CONCAT44(uVar36,uVar35);
        *(undefined2 *)(&stack0x00000a18 + lVar14) = uVar11;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
        lVar23 = *plVar27;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10554a;
        func_0x(lVar23,&stack0x00000a10 + lVar14,4);
        goto LAB_;
      }
LAB_:
      (&stack0x00000096)[lVar14] = 1;
LAB_:
      iVar12 = 0;
      if ((1 < *(short *)(&stack0x00000044 + lVar14)) && ((&stack0x00000052)[lVar14] != -1)) {
        lVar23 = **(longlong **)(&stack0x00000038 + lVar14);
        *(longlong *)(&stack0x00001770 + lVar14) = lVar23;
        if (*(char *)(lVar23 + 1) != (&stack0x00000052)[lVar14]) {
          if (*(longlong *)(&stack0x000004b8 + lVar14) != 0) {
            *(longlong *)(&stack0x00001778 + lVar14) = lVar23;
            *(longlong *)(*(longlong *)(&stack0x000004b8 + lVar14) + 0x588) = lVar23;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1055b2;
          lVar23 = func_0x();
          if (lVar23 == 0) {
LAB_:
            *(int *)(&stack0x00000678 + lVar14) = iVar12;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1055bc;
            lVar23 = func_0x();
            if (*(longlong *)(lVar23 + 0x30) == 0) goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1055c8;
            lVar23 = func_0x();
            uVar22 = *(uint *)(*(longlong *)(lVar23 + 0x30) + 0xc);
            *(uint *)(&stack0x00000bf4 + lVar14) = uVar22;
            if ((0xd < uVar22) || (iVar13 = 1, (0x2640U >> (uVar22 & 0x1f) & 1) == 0)) {
              iVar13 = iVar12;
            }
            *(int *)(&stack0x00000678 + lVar14) = iVar13;
            if (iVar13 != 0) goto LAB_;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105609;
          func_0x(0,8);
        }
      }
LAB_:
      *(undefined4 *)(&stack0x00000b60 + lVar14) = 0;
      *(undefined4 *)(&stack0x00000b64 + lVar14) = 0;
      *(undefined2 *)(&stack0x00000b68 + lVar14) = 0;
      if (((*(short *)(&stack0x00000620 + lVar14) == 0) &&
          (*(int *)(&stack0x00000618 + lVar14) == 0)) && (*(int *)(&stack0x0000061c + lVar14) == 0))
      goto LAB_;
      lVar23 = **(longlong **)(&stack0x00000038 + lVar14);
      *(longlong *)(&stack0x00001780 + lVar14) = lVar23;
      if ((*(byte *)(lVar23 + 4) & 1) == 0) goto LAB_;
      puVar17 = (undefined2 *)((longlong)*(longlong **)(&stack0x00000038 + lVar14) + 0x62);
      *(undefined2 **)(&stack0x00001788 + lVar14) = puVar17;
      *(undefined2 *)(&stack0x00000288 + lVar14) = *puVar17;
      if (((*(ushort *)(&stack0x00000288 + lVar14) & 0x400) == 0) ||
         (*(short *)(&stack0x00000044 + lVar14) < 3)) {
        *(int *)(&stack0x00000100 + lVar14) = (int)*(short *)(&stack0x00000044 + lVar14);
        *(undefined8 *)(&stack0x000008f8 + lVar14) = *(undefined8 *)(&stack0x00000038 + lVar14);
        *(undefined2 **)(&stack0x00001790 + lVar14) = puVar17;
        uVar11 = *puVar17;
        *(undefined2 *)(&stack0x00000290 + lVar14) = uVar11;
        if (((byte)uVar11 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x00000100 + lVar14) == 3) {
            *(undefined4 *)(&stack0x00000100 + lVar14) = 4;
          }
          else if (*(int *)(&stack0x00000100 + lVar14) < 2) goto LAB_;
          *(uint **)(&stack0x00001798 + lVar14) =
               (uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
          uVar22 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar14) + 100);
          *(uint *)(&stack0x00000680 + lVar14) = uVar22;
          if ((((uVar22 & 8) != 0) &&
              (lVar23 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar14) + 0x90), lVar23 != 0)
              ) && (*(longlong *)(&stack0x000017a0 + lVar14) = lVar23,
                   *(longlong *)(lVar23 + 0x758) != 0)) {
            uVar19 = *(undefined8 *)(lVar23 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105743;
            func_0x
                      (uVar19,*(undefined8 *)(&stack0x00000038 + lVar14),
                       *(undefined4 *)(&stack0x00000100 + lVar14));
          }
        }
LAB_:
        (&stack0x00000194)[lVar14] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar30 = (uint *)(*(longlong *)(&stack0x000008f8 + lVar14) + 100);
          *(uint **)(&stack0x000017a8 + lVar14) = puVar30;
          uVar22 = *puVar30;
          *(uint *)(&stack0x00000688 + lVar14) = uVar22;
          if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000100 + lVar14))) {
            *(uint **)(&stack0x000017b0 + lVar14) = puVar30;
            uVar22 = *puVar30;
            *(uint *)(&stack0x00000690 + lVar14) = uVar22;
            if (((uVar22 & 0xc0000000) != 0x40000000) &&
               (lVar23 = **(longlong **)(&stack0x000008f8 + lVar14), lVar23 != 0)) {
              *(undefined4 *)(&stack0x00000bf8 + lVar14) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1057d6;
              iVar12 = (*_DAT_)(lVar23,0x2000,2,&stack0x00000bfc + lVar14);
              if (iVar12 != 0) {
                LOCK();
                *puVar30 = *puVar30 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar30 = *puVar30 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar23 = *(longlong *)(&stack0x000008f8 + lVar14);
        uVar35 = *(undefined4 *)(&stack0x00000100 + lVar14);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105805;
        func_0x(lVar23 + 0x98,uVar35);
        if ((_DAT_ != 0) &&
           ((&stack0x00000195)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10582f;
          func_0x(lVar23,0,uVar35);
        }
        *(uint *)(&stack0x00000044 + lVar14) = *(uint *)(&stack0x00000044 + lVar14) & 0xffff0000;
        *(undefined8 *)(&stack0x00000038 + lVar14) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105692;
        func_0x(&stack0x00000038 + lVar14);
      }
      *(undefined4 *)(&stack0x00000fc0 + lVar14) = 0x400060;
      *(undefined8 *)(&stack0x00000fc8 + lVar14) = 0;
      *(undefined8 *)(&stack0x00000fd8 + lVar14) = 0;
      *(undefined8 *)(&stack0x00000fd0 + lVar14) = 0;
      *(undefined8 *)(&stack0x00000fe0 + lVar14) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10587b;
      func_0x(10,&stack0x00000fc0 + lVar14);
      lVar24 = *(longlong *)(&stack0x00000078 + lVar14);
    } while( true );
  }
LAB_:
  *(longlong *)(&stack0x00001820 + lVar14) = lVar23;
  *(undefined4 *)(&stack0x00002744 + lVar14) = 0;
  if (-1 < *(char *)(lVar23 + 2)) {
    *(undefined8 *)(&stack0x00000910 + lVar14) = 0;
    goto LAB_;
  }
  if (*(short *)(&stack0x00002710 + lVar14) == 0) {
    *(undefined8 *)(&stack0x00000910 + lVar14) = 0;
LAB_:
    *(undefined **)(&stack0x00001828 + lVar14) = &stack0x00002748 + lVar14;
    *(undefined (*) [16])(&stack0x00002748 + lVar14) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002758 + lVar14) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002768 + lVar14) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002778 + lVar14) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002788 + lVar14) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002798 + lVar14) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000027a8 + lVar14) = ZEXT816(0);
    *(undefined8 *)(&stack0x000027b8 + lVar14) = 0;
    *(undefined **)(&stack0x00001830 + lVar14) = &stack0x00002748 + lVar14;
    *(undefined (*) [16])(&stack0x00002748 + lVar14) = ZEXT816(0);
    *(undefined **)(&stack0x00001838 + lVar14) = &stack0x00002758 + lVar14;
    *(undefined2 *)(&stack0x00002758 + lVar14) = 0xffff;
    *(undefined8 *)(&stack0x00002760 + lVar14) = 0;
    *(undefined4 *)(&stack0x0000275c + lVar14) = 0;
    *(undefined8 *)(&stack0x00002776 + lVar14) = 0;
    *(undefined8 *)(&stack0x00002780 + lVar14) = 0;
    *(undefined8 *)(&stack0x00002768 + lVar14) = 0;
    *(undefined **)(&stack0x00001840 + lVar14) = &stack0x00002790 + lVar14;
    *(undefined8 *)(&stack0x00002790 + lVar14) = 0;
    *(undefined **)(&stack0x00001848 + lVar14) = &stack0x000027a8 + lVar14;
    *(undefined4 *)(&stack0x000027a8 + lVar14) = 0;
    *(undefined4 *)(&stack0x000027ac + lVar14) = 0;
    *(undefined2 *)(&stack0x000027b0 + lVar14) = 0;
    *(undefined2 *)(&stack0x000027b2 + lVar14) = 0;
    *(undefined **)(&stack0x00001850 + lVar14) = &stack0x000027b4 + lVar14;
    *(undefined2 *)(&stack0x000027ba + lVar14) = 0;
    ppbVar34 = (byte **)(&stack0x00002748 + lVar14);
    *(byte ***)(&stack0x00000910 + lVar14) = ppbVar34;
  }
  else {
    ppbVar34 = *(byte ***)(&stack0x00002720 + lVar14);
    *(byte ***)(&stack0x00000910 + lVar14) = ppbVar34;
    if (ppbVar34 == (byte **)0x0) goto LAB_;
  }
  (&stack0x00000097)[lVar14] = 0;
  if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
    *(undefined8 *)(&stack0x00000370 + lVar14) = *(undefined8 *)(lVar23 + 0x28);
    sVar10 = *(short *)(lVar23 + 0x30);
    *(short *)(&stack0x00000378 + lVar14) = sVar10;
  }
  else {
    cVar8 = *(char *)(lVar23 + 1);
    if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) && (*(int *)(lVar23 + 0x18) == 99)
       ) {
      *(undefined **)(&stack0x00001858 + lVar14) = &stack0x00000588 + lVar14;
      *(undefined4 **)(&stack0x00001860 + lVar14) = (undefined4 *)(lVar23 + 0x20);
      *(undefined4 *)(&stack0x00000588 + lVar14) = *(undefined4 *)(lVar23 + 0x20);
      *(undefined2 *)(&stack0x0000058c + lVar14) = *(undefined2 *)(lVar23 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105ea3;
      cVar8 = func_0x(&stack0x00000588 + lVar14);
      if (cVar8 == '\0') goto LAB_;
      cVar8 = '\x01';
    }
    else {
LAB_:
      cVar8 = '\0';
    }
    (&stack0x00000097)[lVar14] = cVar8;
    if (cVar8 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x105ec8;
    func_0x(lVar23,&stack0x00000370 + lVar14);
    sVar10 = *(short *)(&stack0x00000378 + lVar14);
  }
  *(undefined **)(&stack0x00001868 + lVar14) = &stack0x00000370 + lVar14;
  *(undefined4 **)(&stack0x00001870 + lVar14) = (undefined4 *)(lVar23 + 0x20);
  pbVar32 = (byte *)(lVar23 + 0x60);
  *(byte **)(&stack0x00001878 + lVar14) = pbVar32;
  *(byte ***)(&stack0x00001880 + lVar14) = ppbVar34;
  if (pbVar32 == *ppbVar34) {
    *(byte ***)(&stack0x00001888 + lVar14) = ppbVar34 + 0xc;
    if (((sVar10 == *(short *)(ppbVar34 + 0xd)) &&
        (*(int *)(&stack0x00000370 + lVar14) == *(int *)(ppbVar34 + 0xc))) &&
       (*(int *)(&stack0x00000374 + lVar14) == *(int *)((longlong)ppbVar34 + 100))) {
      *(longlong *)(&stack0x00001890 + lVar14) = (longlong)ppbVar34 + 0x6c;
    }
  }
  *ppbVar34 = pbVar32;
  *(byte ***)(&stack0x00001898 + lVar14) = ppbVar34 + 0xc;
  uVar11 = *(undefined2 *)(&stack0x00000378 + lVar14);
  *(undefined2 *)(&stack0x00000760 + lVar14) = uVar11;
  uVar35 = *(undefined4 *)(&stack0x00000374 + lVar14);
  *(undefined4 *)(&stack0x00000c08 + lVar14) = uVar35;
  *(undefined4 *)(&stack0x00000c10 + lVar14) = *(undefined4 *)(&stack0x00000370 + lVar14);
  *(undefined4 *)(ppbVar34 + 0xc) = *(undefined4 *)(&stack0x00000370 + lVar14);
  *(undefined4 *)((longlong)ppbVar34 + 100) = uVar35;
  *(undefined2 *)(ppbVar34 + 0xd) = uVar11;
  *(undefined4 **)(&stack0x000018a0 + lVar14) = (undefined4 *)((longlong)ppbVar34 + 0x6c);
  *(undefined4 *)((longlong)ppbVar34 + 0x6c) = *(undefined4 *)(lVar23 + 0x20);
  *(undefined2 *)(ppbVar34 + 0xe) = *(undefined2 *)(lVar23 + 0x24);
  *(undefined2 *)((longlong)ppbVar34 + 0x72) = 0;
  uVar20 = (ulonglong)*pbVar32;
  *(ushort *)(&stack0x00000768 + lVar14) = (ushort)*pbVar32;
  *(undefined4 *)(&stack0x00000a9e + lVar14) = *(undefined4 *)(uVar20 * 6 + 0x1725b90);
  *(undefined2 *)(&stack0x00000aa2 + lVar14) = *(undefined2 *)(uVar20 * 6 + 0x1725b94);
  *(undefined4 *)(&stack0x000007a8 + lVar14) = *(undefined4 *)(uVar20 * 6 + 0x1725b90);
  sVar10 = *(short *)(uVar20 * 6 + 0x1725b94);
  *(short *)(&stack0x00000054 + lVar14) = sVar10;
  *(short *)(&stack0x000007ac + lVar14) = sVar10;
  *(longlong *)(&stack0x000018a8 + lVar14) = lVar23 + 99;
  ppbVar1 = ppbVar34 + 2;
  *(byte ***)(&stack0x000018b0 + lVar14) = ppbVar1;
  *(undefined2 *)ppbVar1 = 0xffff;
  ppbVar34[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar34 + 0x2e) = 0;
  ppbVar34[7] = (byte *)0x0;
  ppbVar34[4] = (byte *)0x0;
  ppsVar2 = (short **)(ppbVar34 + 9);
  *(short ***)(&stack0x000018b8 + lVar14) = ppsVar2;
  *ppsVar2 = (short *)0x0;
  ppbVar34[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar34 + 0xb) = 0;
  if ((**ppbVar34 & 2) != 0) {
    pbVar32 = pbVar32 + sVar10;
    *(byte **)(&stack0x000018c0 + lVar14) = pbVar32;
    *(byte ***)(&stack0x000018c8 + lVar14) = ppbVar1;
    bVar9 = *pbVar32 & 1;
    *(ushort *)(&stack0x00000770 + lVar14) = (ushort)bVar9;
    *(ushort *)ppbVar1 = (ushort)bVar9;
    if (bVar9 != 0) {
      *(longlong *)(&stack0x000018e0 + lVar14) = (longlong)ppbVar34 + 0x12;
      ppbVar34[3] = pbVar32;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar32 & 0x1c) + 0x1085d4) * 4
                             + 0x1085c4) - 0xe142a0);
                    /* WARNING: Could not emulate address calculation at 0x0010618f */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    *(undefined4 *)(&stack0x00000318 + lVar14) = 0;
    *(longlong *)(&stack0x000018d0 + lVar14) = (longlong)ppbVar34 + 0x12;
    ppbVar34[3] = pbVar32;
    *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
    *(undefined4 *)((longlong)ppbVar34 + 0x36) = 0;
    pbVar32 = ppbVar34[3];
    *(byte **)(&stack0x000018d8 + lVar14) = pbVar32;
                    /* WARNING: Could not emulate address calculation at 0x001060da */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar32 & 0xe) * 4 + 0x108588) - 0xe142a0))();
    return;
  }
  if ((**ppbVar34 & 4) != 0) {
    if (*(short *)(&stack0x000007aa + lVar14) == 0) {
      uVar20 = (ulonglong)sVar10;
    }
    else {
      uVar20 = (ulonglong)
               *(ushort *)(lVar23 + 0x61 + (longlong)*(short *)(&stack0x000007aa + lVar14) * 2);
    }
    psVar21 = (short *)(pbVar32 + uVar20);
    *(short **)(&stack0x00001908 + lVar14) = psVar21;
    *(short ***)(&stack0x00001910 + lVar14) = ppsVar2;
    *ppsVar2 = psVar21;
    sVar10 = *psVar21;
    *(short *)(&stack0x00000774 + lVar14) = sVar10;
    ppbVar34[10] = (byte *)(psVar21 + 1);
    *(short *)(ppbVar34 + 0xb) = (sVar10 + 1) * 2;
  }
  pbVar32 = ppbVar34[1];
  if (pbVar32 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x106438;
    func_0x(pbVar32,ppbVar34);
  }
LAB_:
  uVar4 = *(ushort *)(lVar23 + 0xe);
  *(uint *)(&stack0x00000c18 + lVar14) = (uint)uVar4;
  pbVar32 = (byte *)((ulonglong)*(ushort *)(lVar23 + 0x1ffe) + lVar23);
  *(byte **)(&stack0x00001918 + lVar14) = pbVar32;
  bVar9 = *pbVar32 & 1;
  *(ushort *)(&stack0x00000778 + lVar14) = (ushort)bVar9;
  *(ushort *)(&stack0x00002710 + lVar14) = (ushort)bVar9;
  if (bVar9 != 0) {
    *(undefined **)(&stack0x00001930 + lVar14) = &stack0x00002712 + lVar14;
    *(byte **)(&stack0x00002718 + lVar14) = pbVar32;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar32 & 0x1c) + 0x108640) * 4 +
                           0x108630) - 0xe142a0);
                    /* WARNING: Could not emulate address calculation at 0x0010655f */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  *(uint *)(&stack0x00000320 + lVar14) = (uint)uVar4;
  *(undefined **)(&stack0x00001920 + lVar14) = &stack0x00002712 + lVar14;
  *(byte **)(&stack0x00002718 + lVar14) = pbVar32;
  *(undefined4 *)(&stack0x00002714 + lVar14) = 0;
  *(undefined4 *)(&stack0x00002736 + lVar14) = 0;
  *(byte **)(&stack0x00001928 + lVar14) = pbVar32;
                    /* WARNING: Could not emulate address calculation at 0x001064b6 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar32 & 0xe) * 4 + 0x1085f4) - 0xe142a0))();
  return;
}

