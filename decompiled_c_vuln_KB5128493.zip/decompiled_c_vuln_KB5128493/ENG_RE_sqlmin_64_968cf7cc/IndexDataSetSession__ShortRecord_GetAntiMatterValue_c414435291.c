
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(longlong param_1,short *param_2)

{
  ushort *puVar1;
  longlong *plVar2;
  byte bVar3;
  ushort uVar4;
  longlong *in_RAX;
  uint *puVar5;
  ulonglong *puVar6;
  uint *puVar7;
  uint uVar8;
  int iVar9;
  uint *puVar10;
  ushort uVar11;
  short sVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  longlong lVar17;
  uint uVar18;
  uint *puVar19;
  byte *pbVar20;
  uint *puVar21;
  ushort *puVar22;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [2];
  uint auStackX_18 [2];
  undefined auStackX_20 [8];
  undefined auStack_48 [16];
  
  puVar19 = (uint *)0x0;
  lVar17 = *(longlong *)(param_1 + 8);
  uVar18 = 0;
  auStackX_8[0] = 0;
  if ((((*(byte *)(lVar17 + 0x41) & 8) == 0) && ((*(byte *)(lVar17 + 0x108) & 0x40) == 0)) ||
     (in_RAX = *(longlong **)(lVar17 + 0x160), in_RAX == (longlong *)0x0)) {
LAB_:
    return (ulonglong)in_RAX & 0xffffffffffffff00;
  }
  lVar17 = *in_RAX;
  uVar14 = *(uint *)(lVar17 + 100);
  in_RAX = (longlong *)(ulonglong)uVar14;
  if (uVar14 == 0xffffffff) goto LAB_;
  puVar5 = *(uint **)(lVar17 + 8);
  if (uVar14 < *puVar5) {
    uVar16 = (ulonglong)uVar14 / (ulonglong)puVar5[9];
    uVar15 = (ulonglong)uVar14 % (ulonglong)puVar5[9];
    puVar5 = *(uint **)(puVar5 + 4);
  }
  else {
    uVar16 = (ulonglong)(uVar14 - *puVar5) / (ulonglong)puVar5[0x11];
    uVar15 = (ulonglong)(uVar14 - *puVar5) % (ulonglong)puVar5[0x11];
    puVar5 = *(uint **)(puVar5 + 0xc);
  }
  puVar21 = (uint *)(uVar15 * 0x1c0 + *(longlong *)(puVar5 + uVar16 * 2));
  if (puVar21 == (uint *)0x0) goto LAB_;
  bVar3 = *(byte *)(puVar21 + 8);
  puVar1 = (ushort *)(param_2 + 1);
  if (*param_2 == 0) {
    uVar14 = *puVar21;
    puVar5 = (uint *)(ulonglong)(uVar14 & 0xc0000000);
    if ((uVar14 & 0xc0000000) == 0x80000000) {
      puVar5 = (uint *)func_0x(puVar1);
      puVar10 = (uint *)0x0;
      if ((int)puVar5 != 0) {
        puVar5 = (uint *)func_0x(param_2 + 0x15,puVar21,auStackX_8,auStackX_20);
        puVar10 = puVar5;
      }
    }
    else {
      if (((bVar3 & 2) != 0) || ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0)) {
        pbVar20 = *(byte **)(param_2 + 4);
        if ((*pbVar20 & 0x10) == 0) {
          if ((1 << (*pbVar20 & 0xe) & 0x1105U) != 0) goto LAB_;
          puVar5 = (uint *)0x1;
          uVar13 = uVar18;
LAB_:
          if ((bVar3 & 2) != 0) goto LAB_;
        }
        else {
          uVar13 = *(uint *)(param_2 + 8);
          if ((int)uVar13 <= (int)uVar14) {
LAB_:
            uVar13 = ~(uint)(*(ushort *)((longlong)puVar21 + 6) >> 4) & 1;
            puVar5 = puVar19;
            goto LAB_;
          }
          puVar5 = (uint *)(ulonglong)*(ushort *)(pbVar20 + uVar13);
          if ((uint)*(ushort *)(pbVar20 + uVar13) < (uint)*(ushort *)(puVar21 + 1))
          goto LAB_;
          if ((bVar3 & 2) == 0) goto LAB_;
          uVar8 = *(ushort *)(puVar21 + 1) - 1;
          puVar5 = (uint *)0x1;
          uVar13 = pbVar20[(ulonglong)(uVar8 >> 3) + (ulonglong)uVar13 + 2] >> ((byte)uVar8 & 7) & 1
          ;
LAB_:
          puVar10 = puVar19;
          if (uVar13 != 0) goto LAB_;
        }
        if (((int)puVar5 == 0) && ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0)) {
          puVar5 = (uint *)(ulonglong)**(uint **)(puVar21 + 2);
          puVar10 = *(uint **)(puVar21 + 2) + 1;
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar14 < 0) {
        if (*(int *)(param_2 + 2) == 0) {
          pbVar20 = *(byte **)(param_2 + 4);
          uVar14 = *(uint *)(param_2 + 8);
          uVar16 = (ulonglong)uVar14;
          *puVar1 = 0;
          *(uint *)(param_2 + 10) = uVar14;
          bVar3 = *pbVar20;
          if ((bVar3 & 0x10) != 0) {
            uVar14 = uVar14 + 2 + (*(ushort *)(pbVar20 + uVar16) + 7 >> 3);
            uVar16 = (ulonglong)uVar14;
            *(uint *)(param_2 + 10) = uVar14;
            bVar3 = *pbVar20;
          }
          if ((bVar3 & 0x20) == 0) {
            *(int *)(param_2 + 2) = (int)uVar16;
            param_2[0xe] = 0;
            *(int *)(param_2 + 0xc) = (int)uVar16;
          }
          else {
            puVar22 = (ushort *)(pbVar20 + uVar16);
            uVar4 = *puVar22;
            param_2[0xe] = uVar4;
            if (uVar4 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar17 != 0)) &&
                 ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x17c5c58,0x18e5928,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),3);
              uVar16 = (ulonglong)*(uint *)(param_2 + 10);
              uVar4 = param_2[0xe];
            }
            uVar14 = (int)uVar16 + (uVar4 + 1) * 2;
            *(uint *)(param_2 + 0xc) = uVar14;
            if (0x1f9e < uVar14) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar17 != 0 &&
                  ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                   (*(char *)(lVar17 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x17c5c58,0x18e5928,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar4 = param_2[0xe];
              uVar14 = *(uint *)(param_2 + 0xc);
            }
            uVar16 = (ulonglong)uVar4;
            uVar4 = puVar22[uVar16];
            *(uint *)(param_2 + 2) = uVar4 & 0x7fff;
            if ((uVar4 & 0x7fff) < uVar14) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar17 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar17 != 0)) &&
                 ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                  (*(char *)(lVar17 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x17c5c58,0x18e5928,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar16 = (ulonglong)(ushort)param_2[0xe];
            }
            if ((short)puVar22[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
              pbVar20 = *(byte **)(param_2 + 4);
              do {
                if ((int)uVar16 == 1) {
                  uVar14 = *(uint *)(param_2 + 0xc);
                  uVar13 = uVar14;
LAB_:
                  if ((*(ushort *)(pbVar20 + uVar16 * 2 + (ulonglong)*(uint *)(param_2 + 10)) &
                      0x7fff) < uVar14) goto LAB_;
                }
                else {
                  uVar13 = *(uint *)(param_2 + 0xc);
                  uVar14 = *(ushort *)
                            (pbVar20 + uVar16 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                           0x7fff;
                  if (uVar13 <= uVar14) goto LAB_;
LAB_:
                  func_0x(pbVar20,7);
                  uVar13 = *(uint *)(param_2 + 0xc);
                }
                if ((uVar14 < uVar13) || (*(uint *)(param_2 + 2) < uVar14)) goto LAB_;
                pbVar20 = *(byte **)(param_2 + 4);
                if (*(ushort *)(pbVar20 + uVar14) == 5) {
                  *puVar1 = *puVar1 | 2;
                  param_2[0xe] = param_2[0xe] + -1;
                  param_2[0x15] = (short)uVar14;
                  lVar17 = (ulonglong)(uVar14 & 0xffff) + *(longlong *)(param_2 + 4);
                  uVar4 = param_2[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar17 + 2) >> 0xe & 1) != 0) {
                    uVar4 = *(ushort *)(lVar17 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                  }
                  param_2[0x16] = uVar4;
                  param_2[0x16] = (uVar4 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar4;
                  goto LAB_;
                }
                if (*(ushort *)(pbVar20 + uVar14) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar4 = param_2[0xe] - 1;
                param_2[0xe] = uVar4;
                if (uVar4 == 0) goto LAB_;
                uVar16 = (ulonglong)uVar4;
              } while ((short)puVar22[(ulonglong)(uVar4 - 1) + 1] < 0);
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
            else {
LAB_:
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
              pbVar20 = *(byte **)(param_2 + 4);
            }
          }
          if ((*pbVar20 & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0x13) = 0;
          }
          else {
            *(int *)(param_2 + 0x13) = (int)uVar16;
            *(int *)(param_2 + 2) = (int)uVar16 + 0xe;
            puVar6 = (ulonglong *)func_0x(puVar1);
            uVar11 = (ushort)(*puVar6 >> 0x30);
            uVar4 = uVar11;
            if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
              uVar4 = uVar11 & 0xdfff;
              if ((uVar11 >> 0xe & 1) != 0) {
                uVar4 = uVar11 | 0x2000;
              }
            }
            if (uVar4 == 0xfffc) {
              uVar18 = (uint)((*puVar6 >> 0x20 & 0xffff) >> 5);
            }
            *(uint *)(param_2 + 2) = *(int *)(param_2 + 2) + uVar18;
            uVar16 = (ulonglong)*(uint *)(param_2 + 2);
          }
          iVar9 = (int)uVar16;
          if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
             (*(ulonglong *)(param_2 + 0xf) < uVar16 + *(longlong *)(param_2 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar17 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar17 != 0 &&
                 (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x17c5c58,0x18e5928,0x877,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),0x12);
            iVar9 = *(int *)(param_2 + 2);
          }
          if (0x3f3b < iVar9 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar17 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar17 != 0 &&
                ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                 (*(char *)(lVar17 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x17c5c58,0x18e5928,0x87c,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),5);
          }
        }
LAB_:
        sVar12 = -*(short *)puVar21;
        if ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0) {
          bVar3 = **(byte **)(param_2 + 4);
          if ((bVar3 & 0x10) == 0) {
            if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar5 = *(uint **)(puVar21 + 2);
              puVar10 = *(uint **)(puVar21 + 2) + 1;
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_2 + 8) <= (int)*puVar21) ||
                  (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
                   *(ushort *)(puVar21 + 1))) goto LAB_;
        }
        puVar5 = (uint *)(ulonglong)(ushort)param_2[0xe];
        puVar10 = *(uint **)(param_2 + 4);
        lVar17 = (longlong)sVar12;
        if ((uint)(int)sVar12 <= (uint)(ushort)param_2[0xe]) {
          uVar18 = *(uint *)(param_2 + 10);
          if (sVar12 == 1) {
            uVar4 = *(ushort *)((longlong)puVar10 + lVar17 * 2 + (ulonglong)uVar18);
            uVar18 = *(uint *)(param_2 + 0xc);
LAB_:
            if ((uVar4 & 0x7fff) < uVar18) goto LAB_;
          }
          else {
            uVar4 = *(ushort *)((longlong)puVar10 + lVar17 * 2 + (ulonglong)uVar18);
            uVar18 = *(ushort *)((longlong)puVar10 + lVar17 * 2 + ((ulonglong)uVar18 - 2)) & 0x7fff;
            puVar10 = *(uint **)(param_2 + 4);
            if (*(uint *)(param_2 + 0xc) <= uVar18) goto LAB_;
LAB_:
            func_0x(puVar10,7);
            puVar10 = *(uint **)(param_2 + 4);
          }
          puVar5 = (uint *)(ulonglong)uVar18;
          puVar10 = (uint *)((longlong)puVar10 + (longlong)puVar5);
        }
      }
      else {
        uVar4 = *(ushort *)((longlong)puVar21 + 6);
        if ((uVar4 & 8) == 0) {
          if ((uVar4 & 0x10) != 0) {
            bVar3 = **(byte **)(param_2 + 4);
            puVar5 = (uint *)0x0;
            if ((bVar3 & 0x10) == 0) {
              if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar5 = *(uint **)(puVar21 + 2);
                puVar10 = puVar5 + 1;
                if ((*(ushort *)(puVar21 + 0xe) != 0) &&
                   (*puVar5 != (uint)*(ushort *)(puVar21 + 0xe))) {
                  puVar5 = (uint *)(*_DAT_)(1,0x19739c8,0x19723c8,0x381,0);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_2 + 8) <= (int)uVar14) ||
                    (puVar5 = (uint *)(ulonglong)*(ushort *)(puVar21 + 1),
                    *(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
                    *(ushort *)(puVar21 + 1))) goto LAB_;
          }
          puVar10 = (uint *)((longlong)(int)*puVar21 + *(longlong *)(param_2 + 4));
        }
        else {
          puVar5 = (uint *)0x154acb8;
          puVar10 = (uint *)0x154a694;
          if ((*(byte *)(*(longlong *)(param_2 + 4) + (longlong)(int)uVar14) &
              (byte)(1 << ((byte)uVar4 & 7))) == 0) {
            puVar10 = (uint *)0x154acb8;
          }
        }
      }
    }
  }
  else {
    auStackX_18[0] = 0;
    puVar7 = (uint *)func_0x(puVar1,puVar21,uVar15,auStackX_8,auStackX_18);
    puVar5 = puVar7;
    puVar10 = puVar7;
    if ((((*param_2 != 0) && (plVar2 = *(longlong **)(param_2 + 8), plVar2 != (longlong *)0x0)) &&
        ((*plVar2 != 0 &&
         (((*(byte *)((longlong)puVar21 + 6) & 8) == 0 && ((auStackX_18[0] & 1) == 0)))))) &&
       ((puVar5 = puVar19, puVar10 = puVar19, puVar7 != (uint *)0x0 && (puVar7 != (uint *)0x154a694)
        ))) {
      puVar5 = (uint *)func_0x
                                 (plVar2,puVar21,puVar7,auStackX_8[0],auStack_48,4,auStackX_8,
                                  auStackX_18[0]);
      puVar10 = puVar5;
    }
  }
LAB_:
  if (puVar10 != (uint *)0x0) {
    return (ulonglong)*(byte *)puVar10;
  }
LAB_:
  return (ulonglong)puVar5 & 0xffffffffffffff00;
}

