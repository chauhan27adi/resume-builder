
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3,longlong param_4)

{
  ushort *puVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  short sVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  undefined auVar7 [14];
  undefined auVar8 [14];
  undefined auVar9 [14];
  undefined auVar10 [14];
  undefined auVar11 [14];
  undefined auVar12 [14];
  undefined auVar13 [14];
  undefined auVar14 [14];
  undefined auVar15 [14];
  undefined auVar16 [14];
  uint6 uVar17;
  undefined auVar18 [14];
  undefined auVar19 [14];
  undefined auVar20 [14];
  undefined auVar21 [14];
  undefined auVar22 [14];
  byte bVar23;
  undefined2 uVar24;
  ushort uVar25;
  int iVar26;
  ulonglong *puVar27;
  longlong lVar28;
  ulonglong uVar29;
  ulonglong uVar30;
  longlong lVar31;
  ulonglong uVar32;
  byte *pbVar33;
  int *piVar34;
  uint uVar35;
  uint uVar36;
  int iVar37;
  longlong lVar38;
  ushort *puVar39;
  short *psVar40;
  ushort uVar41;
  undefined *puVar42;
  undefined8 *puVar43;
  longlong unaff_GS_OFFSET;
  undefined2 uVar45;
  int iVar44;
  int iVar46;
  int iStackX_20;
  longlong lStack_58;
  undefined auStack_50 [16];
  
  uVar24 = func_0x(param_4);
  puVar1 = (ushort *)(param_4 + 2);
  iStackX_20 = 0;
  if (*(int *)(param_4 + 4) == 0) {
    pbVar33 = *(byte **)(param_4 + 8);
    uVar35 = *(uint *)(param_4 + 0x10);
    uVar29 = (ulonglong)uVar35;
    *puVar1 = 0;
    *(uint *)(param_4 + 0x14) = uVar35;
    bVar23 = *pbVar33;
    if ((bVar23 & 0x10) != 0) {
      uVar35 = uVar35 + 2 + (*(ushort *)(pbVar33 + uVar29) + 7 >> 3);
      uVar29 = (ulonglong)uVar35;
      *(uint *)(param_4 + 0x14) = uVar35;
      bVar23 = *pbVar33;
    }
    if ((bVar23 & 0x20) == 0) {
      *(int *)(param_4 + 4) = (int)uVar29;
      *(undefined2 *)(param_4 + 0x1c) = 0;
      *(int *)(param_4 + 0x18) = (int)uVar29;
    }
    else {
      puVar39 = (ushort *)(pbVar33 + uVar29);
      uVar25 = *puVar39;
      *(ushort *)(param_4 + 0x1c) = uVar25;
      if (uVar25 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar28 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar28 != 0)) &&
           ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
            (*(char *)(lVar28 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xa916f8,0xbb13c8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),3);
        uVar29 = (ulonglong)*(uint *)(param_4 + 0x14);
        uVar25 = *(ushort *)(param_4 + 0x1c);
      }
      uVar35 = (int)uVar29 + (uVar25 + 1) * 2;
      *(uint *)(param_4 + 0x18) = uVar35;
      if (0x1f9e < uVar35) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar28 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar28 != 0 &&
            ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
             (*(char *)(lVar28 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xa916f8,0xbb13c8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar25 = *(ushort *)(param_4 + 0x1c);
        uVar35 = *(uint *)(param_4 + 0x18);
      }
      uVar30 = (ulonglong)uVar25;
      uVar36 = puVar39[uVar30] & 0x7fff;
      *(uint *)(param_4 + 4) = uVar36;
      if (uVar36 < uVar35) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar28 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar28 != 0)) &&
           ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
            (*(char *)(lVar28 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xa916f8,0xbb13c8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar30 = (ulonglong)*(ushort *)(param_4 + 0x1c);
        uVar36 = *(uint *)(param_4 + 4);
      }
      uVar29 = (ulonglong)uVar36;
      if ((short)puVar39[(ulonglong)((int)uVar30 - 1) + 1] < 0) {
        do {
          lVar28 = *(longlong *)(param_4 + 8);
          lVar31 = (ulonglong)*(uint *)(param_4 + 0x14) + lVar28;
          if ((int)uVar30 == 1) {
            uVar35 = *(uint *)(param_4 + 0x18);
            uVar36 = uVar35;
LAB_:
            if ((*(ushort *)(lVar31 + uVar30 * 2) & 0x7fff) < uVar35) goto LAB_;
          }
          else {
            uVar36 = *(uint *)(param_4 + 0x18);
            uVar35 = *(ushort *)(lVar31 + -2 + uVar30 * 2) & 0x7fff;
            if (uVar36 <= uVar35) goto LAB_;
LAB_:
            func_0x(lVar28,7);
            uVar36 = *(uint *)(param_4 + 0x18);
            lVar28 = *(longlong *)(param_4 + 8);
          }
          if ((uVar35 < uVar36) ||
             (uVar29 = (ulonglong)*(uint *)(param_4 + 4), *(uint *)(param_4 + 4) < uVar35))
          goto LAB_;
          if (*(ushort *)((ulonglong)uVar35 + lVar28) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(param_4 + 0x1c) = *(short *)(param_4 + 0x1c) + -1;
            uVar25 = *(ushort *)(param_4 + 0x2c) & 0xc7ff;
            *(short *)(param_4 + 0x2a) = (short)uVar35;
            lVar28 = (ulonglong)(uVar35 & 0xffff) + *(longlong *)(param_4 + 8);
            if ((*(ushort *)(lVar28 + 2) >> 0xe & 1) != 0) {
              uVar25 = *(ushort *)(lVar28 + 2) & 0x3800 | uVar25;
            }
            *(ushort *)(param_4 + 0x2c) = uVar25;
            *(ushort *)(param_4 + 0x2c) = (uVar25 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar25;
            uVar29 = (ulonglong)*(uint *)(param_4 + 4);
            goto LAB_;
          }
          if (*(ushort *)((ulonglong)uVar35 + lVar28) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar25 = *(short *)(param_4 + 0x1c) - 1;
          *(ushort *)(param_4 + 0x1c) = uVar25;
          if (uVar25 == 0) goto LAB_;
          uVar30 = (ulonglong)uVar25;
        } while ((short)puVar39[(ulonglong)(uVar25 - 1) + 1] < 0);
        pbVar33 = *(byte **)(param_4 + 8);
      }
      else {
LAB_:
        pbVar33 = *(byte **)(param_4 + 8);
      }
    }
    iVar26 = 0;
    if ((*pbVar33 & 0x40) == 0) {
      *(undefined4 *)(param_4 + 0x26) = 0;
    }
    else {
      *(int *)(param_4 + 0x26) = (int)uVar29;
      *(int *)(param_4 + 4) = (int)uVar29 + 0xe;
      puVar27 = (ulonglong *)func_0x(puVar1);
      uVar29 = *puVar27;
      uVar41 = (ushort)(uVar29 >> 0x30);
      uVar25 = uVar41;
      if ((((uint)(int)(short)uVar41 >> 1 ^ (int)(short)uVar41) & 0x2000) != 0) {
        uVar25 = uVar41 & 0xdfff;
        if ((uVar29 & 0x4000000000000000) != 0) {
          uVar25 = uVar41 | 0x2000;
        }
      }
      if (uVar25 == 0xfffc) {
        iVar26 = (int)((uVar29 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + iVar26;
      uVar29 = (ulonglong)*(uint *)(param_4 + 4);
      pbVar33 = *(byte **)(param_4 + 8);
    }
    iVar26 = (int)uVar29;
    if ((*(byte **)(param_4 + 0x1e) != (byte *)0x0) &&
       (*(byte **)(param_4 + 0x1e) < pbVar33 + uVar29)) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar28 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar28 != 0 &&
           (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
          (*(char *)(lVar28 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0xa916f8,0xbb13c8,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),0x12);
      iVar26 = *(int *)(param_4 + 4);
    }
    if (0x3f3b < iVar26 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar28 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar28 != 0 &&
          ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
           (*(char *)(lVar28 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0xa916f8,0xbb13c8,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),5);
    }
  }
LAB_:
  iVar26 = func_0x(puVar1);
  if (iVar26 != 0) {
    uVar25 = *(ushort *)(param_4 + 0x2c);
    iVar37 = *(int *)(param_4 + 4) - (uint)*(ushort *)(param_4 + 0x2a);
    uVar35 = (uint)uVar25;
    iVar26 = iVar37 + -10;
    if ((*(byte *)puVar1 & 1) == 0) {
      iVar26 = iVar37;
    }
    if ((**(byte **)(param_4 + 8) & 0x40) != 0) {
      lVar28 = func_0x(puVar1,&lStack_58);
      uVar36 = 0;
      uVar25 = *(ushort *)(lVar28 + 6);
      uVar41 = uVar25;
      if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
        uVar41 = uVar25 & 0xdfff;
        if ((uVar25 >> 0xe & 1) != 0) {
          uVar41 = uVar25 | 0x2000;
        }
      }
      if (uVar41 == 0xfffc) {
        uVar36 = (uint)(*(ushort *)(lVar28 + 4) >> 5);
      }
      uVar25 = *(ushort *)(param_4 + 0x2c);
      iVar26 = (iVar26 - uVar36) + -0xe;
    }
    iStackX_20 = (uVar35 & 0x7ff) * 4 + -4 + iVar26 + ((uVar25 >> 0xb & 7) + (uVar25 & 0x7ff)) * -2;
  }
  lVar28 = *(longlong *)(param_2 + 0x48);
  if ((uint)*(ushort *)(lVar28 + 0x20) < iStackX_20 + 0x17U) {
    (*_DAT_)(1,0xc6db30,0xc6dc00,0x4cd,0);
    lVar28 = *(longlong *)(param_2 + 0x48);
  }
  uVar29 = 0;
  if (((*(uint *)(param_2 + 0x40) & 0x48000) == 0x48000) && ((*(byte *)(param_3 + 0x14) & 8) != 0))
  {
    puVar43 = *(undefined8 **)
               (*(longlong *)(param_3 + 0x40) + (ulonglong)*(uint *)(param_2 + 0x38) * 8);
  }
  else {
    if ((*(byte *)(lVar28 + 0x2a) & 0x10) == 0) {
      lVar28 = *(longlong *)(param_3 + 0x18);
    }
    else {
      lVar28 = *(longlong *)(param_3 + 0x20);
    }
    puVar43 = (undefined8 *)(*(longlong *)(param_2 + 0x28) + lVar28);
    if ((*(uint *)(param_2 + 0x40) >> 0xb & 1) != 0) {
      puVar43 = (undefined8 *)*puVar43;
    }
  }
  *(undefined4 *)((longlong)puVar43 + -4) = 3;
  iVar26 = 0;
  if (*(int *)(param_4 + 4) == 0) {
    pbVar33 = *(byte **)(param_4 + 8);
    uVar35 = *(uint *)(param_4 + 0x10);
    uVar30 = (ulonglong)uVar35;
    *puVar1 = 0;
    *(uint *)(param_4 + 0x14) = uVar35;
    bVar23 = *pbVar33;
    if ((bVar23 & 0x10) != 0) {
      uVar35 = uVar35 + 2 + (*(ushort *)(pbVar33 + uVar30) + 7 >> 3);
      uVar30 = (ulonglong)uVar35;
      *(uint *)(param_4 + 0x14) = uVar35;
      bVar23 = *pbVar33;
    }
    if ((bVar23 & 0x20) == 0) {
      *(int *)(param_4 + 4) = (int)uVar30;
      *(undefined2 *)(param_4 + 0x1c) = 0;
      *(int *)(param_4 + 0x18) = (int)uVar30;
    }
    else {
      puVar39 = (ushort *)(pbVar33 + uVar30);
      uVar25 = *puVar39;
      *(ushort *)(param_4 + 0x1c) = uVar25;
      if (uVar25 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar28 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar28 != 0)) &&
           ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
            (*(char *)(lVar28 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xa916f8,0xbb13c8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),3);
        uVar30 = (ulonglong)*(uint *)(param_4 + 0x14);
        uVar25 = *(ushort *)(param_4 + 0x1c);
      }
      uVar35 = (int)uVar30 + (uVar25 + 1) * 2;
      *(uint *)(param_4 + 0x18) = uVar35;
      if (0x1f9e < uVar35) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar28 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar28 != 0 &&
            ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
             (*(char *)(lVar28 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xa916f8,0xbb13c8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar25 = *(ushort *)(param_4 + 0x1c);
        uVar35 = *(uint *)(param_4 + 0x18);
      }
      uVar32 = (ulonglong)uVar25;
      uVar36 = puVar39[uVar32] & 0x7fff;
      *(uint *)(param_4 + 4) = uVar36;
      if (uVar36 < uVar35) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar28 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar28 != 0)) &&
           ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
            (*(char *)(lVar28 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xa916f8,0xbb13c8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar32 = (ulonglong)*(ushort *)(param_4 + 0x1c);
        uVar36 = *(uint *)(param_4 + 4);
      }
      uVar30 = (ulonglong)uVar36;
      if ((short)puVar39[(ulonglong)((int)uVar32 - 1) + 1] < 0) {
        do {
          lVar28 = *(longlong *)(param_4 + 8);
          lVar31 = (ulonglong)*(uint *)(param_4 + 0x14) + lVar28;
          if ((int)uVar32 == 1) {
            uVar35 = *(uint *)(param_4 + 0x18);
            uVar36 = uVar35;
LAB_:
            if ((*(ushort *)(lVar31 + uVar32 * 2) & 0x7fff) < uVar35) goto LAB_;
          }
          else {
            uVar36 = *(uint *)(param_4 + 0x18);
            uVar35 = *(ushort *)(lVar31 + -2 + uVar32 * 2) & 0x7fff;
            if (uVar36 <= uVar35) goto LAB_;
LAB_:
            func_0x(lVar28,7);
            uVar36 = *(uint *)(param_4 + 0x18);
            lVar28 = *(longlong *)(param_4 + 8);
          }
          if ((uVar35 < uVar36) ||
             (uVar30 = (ulonglong)*(uint *)(param_4 + 4), *(uint *)(param_4 + 4) < uVar35))
          goto LAB_;
          if (*(ushort *)((ulonglong)uVar35 + lVar28) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(param_4 + 0x1c) = *(short *)(param_4 + 0x1c) + -1;
            uVar25 = *(ushort *)(param_4 + 0x2c) & 0xc7ff;
            *(short *)(param_4 + 0x2a) = (short)uVar35;
            lVar28 = (ulonglong)(uVar35 & 0xffff) + *(longlong *)(param_4 + 8);
            if ((*(ushort *)(lVar28 + 2) >> 0xe & 1) != 0) {
              uVar25 = *(ushort *)(lVar28 + 2) & 0x3800 | uVar25;
            }
            *(ushort *)(param_4 + 0x2c) = uVar25;
            *(ushort *)(param_4 + 0x2c) = (uVar25 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar25;
            uVar30 = (ulonglong)*(uint *)(param_4 + 4);
            goto LAB_;
          }
          if (*(ushort *)((ulonglong)uVar35 + lVar28) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar25 = *(short *)(param_4 + 0x1c) - 1;
          *(ushort *)(param_4 + 0x1c) = uVar25;
          if (uVar25 == 0) goto LAB_;
          uVar32 = (ulonglong)uVar25;
        } while ((short)puVar39[(ulonglong)(uVar25 - 1) + 1] < 0);
        pbVar33 = *(byte **)(param_4 + 8);
      }
      else {
LAB_:
        pbVar33 = *(byte **)(param_4 + 8);
      }
    }
    if ((*pbVar33 & 0x40) == 0) {
      *(undefined4 *)(param_4 + 0x26) = 0;
    }
    else {
      *(int *)(param_4 + 0x26) = (int)uVar30;
      *(int *)(param_4 + 4) = (int)uVar30 + 0xe;
      puVar27 = (ulonglong *)func_0x(puVar1);
      uVar30 = *puVar27;
      uVar41 = (ushort)(uVar30 >> 0x30);
      uVar25 = uVar41;
      if ((((uint)(int)(short)uVar41 >> 1 ^ (int)(short)uVar41) & 0x2000) != 0) {
        uVar25 = uVar41 & 0xdfff;
        if ((uVar30 & 0x4000000000000000) != 0) {
          uVar25 = uVar41 | 0x2000;
        }
      }
      if (uVar25 == 0xfffc) {
        iVar26 = (int)((uVar30 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + iVar26;
      uVar30 = (ulonglong)*(uint *)(param_4 + 4);
      pbVar33 = *(byte **)(param_4 + 8);
    }
    iVar26 = (int)uVar30;
    if ((*(byte **)(param_4 + 0x1e) != (byte *)0x0) &&
       (*(byte **)(param_4 + 0x1e) < pbVar33 + uVar30)) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar28 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar28 != 0 &&
           (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
          (*(char *)(lVar28 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0xa916f8,0xbb13c8,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),0x12);
      iVar26 = *(int *)(param_4 + 4);
    }
    if (0x3f3b < iVar26 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar28 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar28 != 0 &&
          ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
           (*(char *)(lVar28 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0xa916f8,0xbb13c8,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),5);
    }
  }
LAB_:
  uVar25 = *(ushort *)(param_4 + 0x2c);
  lVar28 = *(longlong *)(param_4 + 8) + (ulonglong)*(ushort *)(param_4 + 0x2a);
  lVar31 = (ulonglong)*(ushort *)(param_4 + 0x2a) + 4 +
           (ulonglong)((uVar25 >> 0xb & 7) * 2) + *(longlong *)(param_4 + 8);
  puVar39 = (ushort *)(lVar28 + 4);
  uVar30 = uVar29;
  do {
    if ((uVar25 & 0x3800) == 0) {
      uVar41 = *(ushort *)((ulonglong)*(ushort *)(param_4 + 0x2a) + 2 + *(longlong *)(param_4 + 8));
    }
    else {
      uVar41 = *puVar39;
      uVar25 = uVar41;
    }
    uVar32 = (ulonglong)(uVar25 & 0x7ff);
    uVar41 = uVar41 >> 0xb;
    iVar26 = (uVar25 & 0x7ff) - 1;
    iVar37 = (int)uVar30;
    uVar35 = (iVar26 - iVar37) + 1;
    uVar36 = CONCAT22(uVar41,uVar41) & 0x70007;
    if ((iVar37 <= iVar26) && (0xf < uVar35)) {
      if (((undefined *)(lVar31 + -2 + uVar32 * 2) <
           (undefined *)((longlong)puVar43 + (longlong)iVar37 * 4 + 0x17)) ||
         ((undefined *)((longlong)puVar43 + uVar32 * 4 + 0x13) <
          (undefined *)(lVar31 + (longlong)iVar37 * 2))) {
        uVar35 = uVar35 & 0x8000000f;
        if ((int)uVar35 < 0) {
          uVar35 = (uVar35 - 1 | 0xfffffff0) + 1;
        }
        uVar45 = (undefined2)(uVar36 >> 0x10);
        auVar7._12_2_ = uVar45;
        auVar7._0_12_ = ZEXT812(0);
        uVar17 = CONCAT42(auVar7._10_4_,(short)uVar36);
        auVar22._6_8_ = 0;
        auVar22._0_6_ = uVar17;
        auVar16._6_8_ = SUB148(auVar22 << 0x40,6);
        auVar16._0_6_ = CONCAT24(uVar45,CONCAT22(uVar41,uVar41)) & 0xffff00070007;
        iVar37 = uVar36 * 0x10000;
        iVar44 = auVar16._4_4_;
        iVar46 = (int)uVar17;
        uVar36 = auVar7._10_4_ >> 0x10;
        piVar34 = (int *)((longlong)puVar43 + uVar29 * 4 + 0x37);
        puVar27 = (ulonglong *)(lVar31 + 0x10 + uVar29 * 2);
        do {
          uVar2 = puVar27[-2];
          uVar3 = puVar27[-1];
          uVar30 = (ulonglong)((int)uVar30 + 0x10);
          auVar8._8_4_ = 0;
          auVar8._0_8_ = uVar2;
          auVar8._12_2_ = (short)(uVar2 >> 0x30);
          auVar12._8_2_ = (short)(uVar2 >> 0x20);
          auVar12._0_8_ = uVar2;
          auVar12._10_4_ = auVar8._10_4_;
          auVar18._6_8_ = 0;
          auVar18._0_6_ = auVar12._8_6_;
          uVar29 = uVar29 + 0x10;
          auVar9._8_4_ = 0;
          auVar9._0_8_ = uVar3;
          auVar9._12_2_ = (short)(uVar3 >> 0x30);
          auVar13._8_2_ = (short)(uVar3 >> 0x20);
          auVar13._0_8_ = uVar3;
          auVar13._10_4_ = auVar9._10_4_;
          auVar19._6_8_ = 0;
          auVar19._0_6_ = auVar13._8_6_;
          piVar34[-8] = (uint)(ushort)uVar2 + iVar37;
          piVar34[-7] = (int)CONCAT82(SUB148(auVar18 << 0x40,6),(short)(uVar2 >> 0x10)) + iVar44;
          piVar34[-6] = auVar12._8_4_ + iVar46;
          piVar34[-5] = (auVar8._10_4_ >> 0x10) + uVar36;
          uVar2 = *puVar27;
          auVar10._8_4_ = 0;
          auVar10._0_8_ = uVar2;
          auVar10._12_2_ = (short)(uVar2 >> 0x30);
          auVar14._8_2_ = (short)(uVar2 >> 0x20);
          auVar14._0_8_ = uVar2;
          auVar14._10_4_ = auVar10._10_4_;
          auVar20._6_8_ = 0;
          auVar20._0_6_ = auVar14._8_6_;
          piVar34[-4] = (uint)(ushort)uVar3 + iVar37;
          piVar34[-3] = (int)CONCAT82(SUB148(auVar19 << 0x40,6),(short)(uVar3 >> 0x10)) + iVar44;
          piVar34[-2] = auVar13._8_4_ + iVar46;
          piVar34[-1] = (auVar9._10_4_ >> 0x10) + uVar36;
          uVar3 = puVar27[1];
          auVar11._8_4_ = 0;
          auVar11._0_8_ = uVar3;
          auVar11._12_2_ = (short)(uVar3 >> 0x30);
          auVar15._8_2_ = (short)(uVar3 >> 0x20);
          auVar15._0_8_ = uVar3;
          auVar15._10_4_ = auVar11._10_4_;
          auVar21._6_8_ = 0;
          auVar21._0_6_ = auVar15._8_6_;
          *piVar34 = (uint)(ushort)uVar2 + iVar37;
          piVar34[1] = (int)CONCAT82(SUB148(auVar20 << 0x40,6),(short)(uVar2 >> 0x10)) + iVar44;
          piVar34[2] = auVar14._8_4_ + iVar46;
          piVar34[3] = (auVar10._10_4_ >> 0x10) + uVar36;
          piVar34[4] = (uint)(ushort)uVar3 + iVar37;
          piVar34[5] = (int)CONCAT82(SUB148(auVar21 << 0x40,6),(short)(uVar3 >> 0x10)) + iVar44;
          piVar34[6] = auVar15._8_4_ + iVar46;
          piVar34[7] = (auVar11._10_4_ >> 0x10) + uVar36;
          piVar34 = piVar34 + 0x10;
          puVar27 = puVar27 + 4;
        } while ((longlong)uVar29 <= (longlong)(int)(iVar26 - uVar35));
      }
    }
    lVar38 = uVar32 - 1;
    if ((longlong)uVar29 <= lVar38) {
      uVar30 = (ulonglong)(uint)((int)uVar30 + 1 + ((int)lVar38 - (int)uVar29));
      do {
        *(uint *)((longlong)puVar43 + uVar29 * 4 + 0x17) =
             (uint)*(ushort *)(lVar31 + uVar29 * 2) + (uint)(uVar41 & 7) * 0x10000;
        uVar29 = uVar29 + 1;
      } while ((longlong)uVar29 <= lVar38);
    }
    uVar25 = *(ushort *)(param_4 + 0x2c);
    puVar39 = puVar39 + 1;
  } while ((int)uVar30 < (int)(uVar25 & 0x7ff));
  iVar37 = *(int *)(param_4 + 4) - (uint)*(ushort *)(param_4 + 0x2a);
  psVar40 = (short *)(*(byte **)(param_4 + 8) +
                     (ulonglong)*(ushort *)(param_4 + 0x2a) +
                     (ulonglong)((uVar25 >> 0xb & 7) * 2) + (ulonglong)((uVar25 & 0x7ff) * 2) + 4);
  puVar42 = (undefined *)(((ulonglong)uVar25 & 0x7ff) * 4 + 0x17 + (longlong)puVar43);
  iVar26 = iVar37 + -10;
  if ((*(byte *)puVar1 & 1) == 0) {
    iVar26 = iVar37;
  }
  lStack_58 = lVar28;
  if ((**(byte **)(param_4 + 8) & 0x40) != 0) {
    lVar31 = func_0x(puVar1,auStack_50);
    uVar35 = 0;
    uVar25 = *(ushort *)(lVar31 + 6);
    uVar41 = uVar25;
    if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
      uVar41 = uVar25 & 0xdfff;
      if ((uVar25 >> 0xe & 1) != 0) {
        uVar41 = uVar25 | 0x2000;
      }
    }
    if (uVar41 == 0xfffc) {
      uVar35 = (uint)(*(ushort *)(lVar31 + 4) >> 5);
    }
    iVar26 = (iVar26 - uVar35) + -0xe;
  }
  func_0x(puVar42,psVar40,((int)lVar28 - (int)psVar40) + iVar26);
  uVar25 = *(ushort *)(param_4 + 0x2c);
  uVar35 = 0;
  sVar4 = *(short *)(param_4 + 0x2a);
  uVar5 = *(undefined4 *)(param_4 + 8);
  if ((uVar25 & 0x7ff) != 0) {
    do {
      puVar1 = (ushort *)(puVar42 + (ulonglong)uVar35 * 2);
      uVar35 = uVar35 + 1;
      *puVar1 = *puVar1 ^ (*psVar40 -
                           (((sVar4 + ((uVar25 >> 0xb & 7) + 2 + (uVar25 & 0x7ff) * 2) * 2) -
                            (short)lVar28) + (short)uVar5) ^ *puVar1) & 0x7fff;
      psVar40 = psVar40 + 1;
    } while ((int)uVar35 < (int)(*(ushort *)(param_4 + 0x2c) & 0x7ff));
  }
  uVar6 = *(undefined8 *)(param_1 + 0x28);
  uVar45 = *(undefined2 *)(param_1 + 0x30);
  *(undefined4 *)((longlong)puVar43 + 9) = *(undefined4 *)(param_1 + 0x20);
  *(undefined2 *)((longlong)puVar43 + 5) = uVar24;
  *(short *)((longlong)puVar43 + 3) = (short)iStackX_20;
  *(undefined8 *)((longlong)puVar43 + 0xd) = uVar6;
  *(undefined *)puVar43 = 1;
  *(undefined2 *)((longlong)puVar43 + 1) = 0;
  *(undefined2 *)((longlong)puVar43 + 7) = 0xffff;
  *(undefined2 *)((longlong)puVar43 + 0x15) = uVar45;
  if ((*(byte *)(*(longlong *)(param_2 + 0x48) + 0x2a) & 0x10) == 0) {
    lVar28 = *(longlong *)(param_3 + 0x18);
  }
  else {
    lVar28 = *(longlong *)(param_3 + 0x20);
  }
  *(ulonglong *)(lVar28 + *(longlong *)(*(longlong *)(param_2 + 0x48) + 0x18)) =
       (ulonglong)(ushort)((short)iStackX_20 + 0x17);
  return;
}

