
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,undefined8 *param_3)

{
  short *psVar1;
  undefined2 uVar2;
  byte *pbVar3;
  uint *puVar4;
  longlong *plVar5;
  code *pcVar6;
  uint6 uVar7;
  char cVar8;
  int iVar9;
  uint uVar10;
  longlong lVar11;
  longlong lVar12;
  ulonglong *puVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  longlong lVar16;
  undefined8 *puVar17;
  byte bVar18;
  ushort uVar19;
  int iVar20;
  ulonglong uVar21;
  longlong lVar22;
  ushort uVar23;
  ushort uVar24;
  ushort *puVar25;
  undefined8 unaff_RBX;
  short *psVar26;
  undefined8 *puVar27;
  uint uVar28;
  uint uVar29;
  undefined8 *puVar30;
  short sVar31;
  longlong unaff_GS_OFFSET;
  byte *pbStackX_8;
  undefined8 uStackX_10;
  undefined4 uStackX_18;
  ushort uStackX_1c;
  ulonglong uStackX_1e;
  undefined2 uStackX_26;
  undefined8 *puStack_2068;
  undefined auStack_2048 [94];
  ushort auStack_1fea [4049];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  *(undefined8 *)(&stack0x00002100 + lVar11) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11);
  puVar17 = (undefined8 *)0x0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar11 + -0x14) = 0;
  *(undefined8 *)((longlong)&uStackX_18 + lVar11 + 6) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar11) = 0;
  *(undefined8 *)((longlong)&uStackX_10 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000044 + lVar11) = 0;
  lVar16 = *(longlong *)(param_1 + 0x10);
  (&stack0xfffffffffffffff8)[lVar11] = 0;
  lVar12 = *param_2;
  uVar19 = *(ushort *)(lVar12 + 0x18);
  puVar30 = puVar17;
  if (0x1f7c < uVar19) {
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0x1f7c;
    *(uint *)(&stack0xffffffffffffffe8 + lVar11) = (uint)uVar19;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000a6;
    (*_DAT_)(5,0xb,0x10);
    puVar30 = (undefined8 *)(ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + -0x14);
  }
  puVar27 = (undefined8 *)(ulonglong)*(ushort *)(*(longlong *)(lVar16 + 8) + 0xb8);
  pbVar3 = *(byte **)(lVar12 + 8);
  bVar18 = *pbVar3;
  *(byte **)((longlong)&pbStackX_8 + lVar11) = pbVar3;
  iVar9 = 0;
  puStack_2068 = param_3;
  if ((bVar18 & 1) == 0) {
    *(undefined2 *)((longlong)&uStackX_18 + lVar11 + -0x18) = 0;
    *(undefined4 *)((longlong)&uStackX_26 + lVar11) = 0;
    switch(*pbVar3 & 0xe) {
    default:
      puVar27 = (undefined8 *)(ulonglong)*(ushort *)(pbVar3 + 2);
      if (0x1f9d < *(ushort *)(pbVar3 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100289;
        func_0x(pbVar3,6);
        puVar30 = (undefined8 *)(ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + -0x14);
      }
      break;
    case 4:
      puVar27 = (undefined8 *)0x9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      puVar27 = (undefined8 *)0x1;
    }
    *(int *)((longlong)&uStackX_10 + lVar11) = (int)puVar27;
  }
  else {
    *(undefined2 *)((longlong)&uStackX_18 + lVar11 + -0x18) = 1;
    bVar18 = *pbVar3;
    switch(bVar18 & 0x1c) {
    default:
      if ((char)pbVar3[1] < '\0') {
        uVar19 = (*(ushort *)(pbVar3 + 1) & 0x7f) << 8 | *(ushort *)(pbVar3 + 1) >> 8;
        *(ushort *)((longlong)&uStackX_18 + lVar11 + -0x16) = uVar19;
        sVar31 = 3;
        *(undefined2 *)((longlong)&uStackX_18 + lVar11) = 3;
      }
      else {
        uVar19 = (ushort)pbVar3[1];
        *(ushort *)((longlong)&uStackX_18 + lVar11 + -0x16) = uVar19;
        sVar31 = 2;
        *(undefined2 *)((longlong)&uStackX_18 + lVar11) = 2;
      }
      *(short *)((longlong)&uStackX_18 + lVar11 + 4) = (short)(uVar19 + 1 >> 1) + sVar31;
      if (uVar19 < 0x1f) {
        *(undefined2 *)((longlong)&uStackX_18 + lVar11 + 2) = 0;
        *(undefined4 *)(&stack0x00000030 + lVar11) = 0;
        puVar27 = puVar17;
      }
      else {
        iVar20 = uVar19 - 1;
        *(short *)((longlong)&uStackX_18 + lVar11 + 2) =
             ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
             (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
        *(undefined4 *)(&stack0x00000030 + lVar11) = 0;
        puVar27 = (undefined8 *)0x0;
      }
      break;
    case 4:
      if (((bVar18 & 0x1c) == 4) && ((bVar18 & 2) != 0)) {
        *(undefined4 *)((longlong)&uStackX_18 + lVar11) = 0;
        *(undefined2 *)((longlong)&uStackX_18 + lVar11 + -0x16) = 0;
        *(undefined2 *)((longlong)&uStackX_18 + lVar11 + 4) = 0;
        *(undefined2 *)((longlong)&uStackX_26 + lVar11) = 0;
        puVar30 = (undefined8 *)0xf;
        *(undefined4 *)((longlong)&uStackX_18 + lVar11 + -0x14) = 0xf;
        *(undefined4 *)(&stack0x00000030 + lVar11) = 1;
        puVar27 = (undefined8 *)0x0;
      }
      else {
        *(undefined4 *)((longlong)&uStackX_18 + lVar11) = 0;
        *(undefined2 *)((longlong)&uStackX_18 + lVar11 + -0x16) = 0;
        *(undefined2 *)((longlong)&uStackX_18 + lVar11 + 4) = 0;
        *(undefined2 *)((longlong)&uStackX_26 + lVar11) = 0;
        puVar30 = (undefined8 *)0x1;
        *(undefined4 *)((longlong)&uStackX_18 + lVar11 + -0x14) = 1;
        *(undefined4 *)(&stack0x00000030 + lVar11) = 0;
        puVar27 = (undefined8 *)0x0;
      }
      break;
    case 8:
      *(undefined4 *)((longlong)&uStackX_18 + lVar11) = 0;
      *(undefined2 *)((longlong)&uStackX_18 + lVar11 + -0x16) = 0;
      *(undefined2 *)((longlong)&uStackX_18 + lVar11 + 4) = 0;
      *(undefined2 *)((longlong)&uStackX_26 + lVar11) = 0;
      puVar30 = (undefined8 *)0x9;
      *(undefined4 *)((longlong)&uStackX_18 + lVar11 + -0x14) = 9;
      *(undefined4 *)(&stack0x00000030 + lVar11) = 0;
      puVar27 = (undefined8 *)0x0;
    }
  }
  sVar31 = *(short *)((longlong)&uStackX_18 + lVar11 + -0x18);
  *(short *)(&stack0x00000040 + lVar11) = sVar31;
  if (sVar31 == 0) {
    if ((int)puVar30 == 0) {
      *(undefined2 *)((longlong)&uStackX_18 + lVar11 + -0x16) = 0;
      *(int *)((longlong)&uStackX_10 + lVar11 + 4) = (int)puVar27;
      puVar30 = puVar27;
      if ((**(byte **)((longlong)&pbStackX_8 + lVar11) & 0x10) != 0) {
        uVar28 = (int)puVar27 + 2 +
                 (*(ushort *)(*(byte **)((longlong)&pbStackX_8 + lVar11) + (longlong)puVar27) + 7 >>
                 3);
        puVar30 = (undefined8 *)(ulonglong)uVar28;
        *(uint *)((longlong)&uStackX_10 + lVar11 + 4) = uVar28;
      }
      uVar28 = (uint)puVar30;
      if ((**(byte **)((longlong)&pbStackX_8 + lVar11) & 0x20) == 0) {
        *(uint *)((longlong)&uStackX_18 + lVar11 + -0x14) = uVar28;
        *(undefined2 *)((longlong)&uStackX_18 + lVar11 + 4) = 0;
        *(uint *)((longlong)&uStackX_18 + lVar11) = uVar28;
      }
      else {
        psVar26 = (short *)((longlong)puVar30 + (longlong)*(byte **)((longlong)&pbStackX_8 + lVar11)
                           );
        sVar31 = *psVar26;
        *(short *)((longlong)&uStackX_18 + lVar11 + 4) = sVar31;
        if (sVar31 == 0) {
          if ((((cRam0000000001f05b3b != '\0') || ((bRam0000000001f16440 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         ((ulonglong)*puRam00000000014743d0 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014743c8 * 8) + 8), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001f05a2b == '\0') && ((bRam0000000001f16440 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003b2;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003d6;
              (*pcRam0000000001474360)(1,0x17f6568,0x1916238,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003e5;
          func_0x(*(undefined8 *)((longlong)&pbStackX_8 + lVar11),3);
        }
        uVar28 = *(int *)((longlong)&uStackX_10 + lVar11 + 4) +
                 (*(ushort *)((longlong)&uStackX_18 + lVar11 + 4) + 1) * 2;
        *(uint *)((longlong)&uStackX_18 + lVar11) = uVar28;
        if (0x1f9e < uVar28) {
          if (((cRam0000000001f05b3b != '\0') || ((bRam0000000001f16440 & 1) != 0)) &&
             ((lVar12 = *(longlong *)
                         ((ulonglong)*puRam00000000014743d0 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014743c8 * 8) + 8), lVar12 != 0 &&
              ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
               (*(char *)(lVar12 + 0x499) != '\0')))))) {
            if ((cRam0000000001f05a2b == '\0') && ((bRam0000000001f16440 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10047f;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004a3;
              (*pcRam0000000001474360)(1,0x17f6568,0x1916238,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004b2;
          func_0x(*(undefined8 *)((longlong)&pbStackX_8 + lVar11),4);
          uVar28 = *(uint *)((longlong)&uStackX_18 + lVar11);
        }
        uVar29 = (ushort)psVar26[*(ushort *)((longlong)&uStackX_18 + lVar11 + 4)] & 0x7fff;
        *(uint *)((longlong)&uStackX_18 + lVar11 + -0x14) = uVar29;
        if (uVar29 < uVar28) {
          if ((((cRam0000000001f05b3b != '\0') || ((bRam0000000001f16440 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         ((ulonglong)*puRam00000000014743d0 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014743c8 * 8) + 8), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001f05a2b == '\0') && ((bRam0000000001f16440 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10054d;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100571;
              (*pcRam0000000001474360)(1,0x17f6568,0x1916238,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100580;
          func_0x(*(undefined8 *)((longlong)&pbStackX_8 + lVar11),4);
          uVar28 = *(uint *)((longlong)&uStackX_18 + lVar11);
          uVar29 = *(uint *)((longlong)&uStackX_18 + lVar11 + -0x14);
        }
        puVar30 = (undefined8 *)(ulonglong)uVar29;
        do {
          uVar19 = *(ushort *)((longlong)&uStackX_18 + lVar11 + 4);
          uVar21 = (ulonglong)uVar19;
          if (-1 < psVar26[(ulonglong)(uVar19 - 1) + 1]) break;
          lVar12 = (ulonglong)*(uint *)((longlong)&uStackX_10 + lVar11 + 4) +
                   *(longlong *)((longlong)&pbStackX_8 + lVar11);
          if (uVar19 == 1) {
            uVar21 = 1;
            uVar29 = uVar28;
          }
          else {
            uVar29 = *(ushort *)(lVar12 + -2 + uVar21 * 2) & 0x7fff;
          }
          if ((uVar29 < uVar28) || ((*(ushort *)(lVar12 + uVar21 * 2) & 0x7fff) < uVar29)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1005f9;
            func_0x(*(undefined8 *)((longlong)&pbStackX_8 + lVar11),7);
            uVar28 = *(uint *)((longlong)&uStackX_18 + lVar11);
            puVar30 = (undefined8 *)(ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + -0x14);
          }
          if ((uVar29 < uVar28) || ((uint)puVar30 < uVar29)) goto code_r0x001008eb;
          uVar19 = *(ushort *)((ulonglong)uVar29 + *(longlong *)((longlong)&pbStackX_8 + lVar11));
          if (uVar19 == 5) {
            puVar25 = (ushort *)((longlong)&uStackX_18 + lVar11 + -0x16);
            *puVar25 = *puVar25 | 2;
            psVar26 = (short *)((longlong)&uStackX_18 + lVar11 + 4);
            *psVar26 = *psVar26 + -1;
            *(short *)(&stack0x0000002a + lVar11) = (short)uVar29;
            uVar19 = *(ushort *)
                      ((ulonglong)(uVar29 & 0xffff) + *(longlong *)((longlong)&pbStackX_8 + lVar11)
                      + 2);
            uVar24 = *(ushort *)(&stack0x0000002c + lVar11);
            uVar23 = uVar24 & 0xc7ff;
            if ((uVar19 & 0x4000) != 0) {
              uVar23 = (uVar19 ^ uVar24) & 0x3800 ^ uVar24;
            }
            *(ushort *)(&stack0x0000002c + lVar11) = (uVar23 ^ uVar19) & 0x7ff ^ uVar23;
            break;
          }
          if (uVar19 < 0x400) break;
          puVar25 = (ushort *)((longlong)&uStackX_18 + lVar11 + -0x16);
          *puVar25 = *puVar25 | 1;
          psVar1 = (short *)((longlong)&uStackX_18 + lVar11 + 4);
          *psVar1 = *psVar1 + -1;
        } while (*psVar1 != 0);
      }
      if ((**(byte **)((longlong)&pbStackX_8 + lVar11) & 0x40) == 0) {
        *(undefined4 *)((longlong)&uStackX_26 + lVar11) = 0;
      }
      else {
        *(int *)((longlong)&uStackX_26 + lVar11) = (int)puVar30;
        *(int *)((longlong)&uStackX_18 + lVar11 + -0x14) = (int)puVar30 + 0xe;
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006eb;
        puVar13 = (ulonglong *)func_0x((longlong)&uStackX_18 + lVar11 + -0x16);
        uVar21 = *puVar13;
        uVar24 = (ushort)(uVar21 >> 0x30);
        uVar19 = uVar24;
        if ((((uint)(int)(short)uVar24 >> 1 ^ (int)(short)uVar24) & 0x2000) != 0) {
          uVar19 = uVar24 & 0xdfff;
          if ((uVar21 & 0x4000000000000000) != 0) {
            uVar19 = uVar24 | 0x2000;
          }
        }
        if (uVar19 == 0xfffc) {
          iVar9 = (int)((uVar21 >> 0x20 & 0xffff) >> 5);
        }
        uVar28 = *(int *)((longlong)&uStackX_18 + lVar11 + -0x14) + iVar9;
        puVar30 = (undefined8 *)(ulonglong)uVar28;
        *(uint *)((longlong)&uStackX_18 + lVar11 + -0x14) = uVar28;
        uVar28 = *(uint *)((longlong)&uStackX_18 + lVar11);
      }
      uVar21 = *(ulonglong *)((longlong)&uStackX_18 + lVar11 + 6);
      if ((uVar21 != 0) &&
         (uVar21 < (ulonglong)((longlong)puVar30 + *(longlong *)((longlong)&pbStackX_8 + lVar11))))
      {
        if (((cRam0000000001f05b3b != '\0') || ((bRam0000000001f16440 & 1) != 0)) &&
           (((lVar12 = *(longlong *)
                        ((ulonglong)*puRam00000000014743d0 +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000014743c8 * 8) + 8), lVar12 != 0 &&
             (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((cRam0000000001f05a2b == '\0') && ((bRam0000000001f16440 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1007eb;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10080f;
            (*pcRam0000000001474360)(1,0x17f6568,0x1916238,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10081e;
        func_0x(*(undefined8 *)((longlong)&pbStackX_8 + lVar11),0x12);
        uVar28 = *(uint *)((longlong)&uStackX_18 + lVar11);
        puVar30 = (undefined8 *)(ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + -0x14);
      }
      if (0x3f3b < (int)puVar30 - 1U) {
        if (((cRam0000000001f05b3b != '\0') || ((bRam0000000001f16440 & 1) != 0)) &&
           ((lVar12 = *(longlong *)
                       ((ulonglong)*puRam00000000014743d0 +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000014743c8 * 8) + 8), lVar12 != 0 &&
            ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
             (*(char *)(lVar12 + 0x499) != '\0')))))) {
          if ((cRam0000000001f05a2b == '\0') && ((bRam0000000001f16440 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1008ae;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1008d2;
            (*pcRam0000000001474360)(1,0x17f6568,0x1916238,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1008e1;
        func_0x(*(undefined8 *)((longlong)&pbStackX_8 + lVar11),5);
        puVar30 = (undefined8 *)(ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + -0x14);
        goto code_r0x001008e6;
      }
    }
    else {
code_r0x001008e6:
      uVar28 = *(uint *)((longlong)&uStackX_18 + lVar11);
    }
code_r0x001008eb:
    uVar29 = (uint)puVar30;
    if ((8 < uVar29) ||
       ((bVar18 = **(byte **)((longlong)&pbStackX_8 + lVar11) & 0xe, uVar10 = 9, bVar18 != 0 &&
        (bVar18 != 0xc)))) {
      uVar10 = uVar29;
    }
    *(undefined2 *)(&stack0x00000042 + lVar11) =
         *(undefined2 *)((longlong)&uStackX_18 + lVar11 + -0x16);
    *(uint *)(&stack0x00000044 + lVar11) = uVar29;
    uVar29 = *(uint *)((longlong)&uStackX_10 + lVar11 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10094d;
    func_0x
              (auStack_1fea + 1,0x1f9e,*(undefined8 *)((longlong)&pbStackX_8 + lVar11),uVar10);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10095f;
    iVar9 = func_0x(&stack0x00000042 + lVar11);
    if (iVar9 != 0) {
      uVar21 = (ulonglong)uVar29;
      puVar25 = (ushort *)((longlong)(auStack_1fea + 1) + uVar21);
      uVar19 = *puVar25;
      uVar29 = uVar19 - 1;
      if (((&stack0x00000042)[lVar11] & 1) == 0) {
        uVar29 = (uint)uVar19;
      }
      uVar10 = uVar28;
      if (uVar29 != 1) {
        uVar10 = *(ushort *)((longlong)auStack_1fea + (longlong)(int)uVar29 * 2 + uVar21) & 0x7fff;
      }
      if ((uVar10 < uVar28) || ((puVar25[(int)uVar29] & 0x7fff) < uVar10)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1009ba;
        func_0x(auStack_1fea + 1,7);
      }
    }
  }
  else if ((*(longlong **)((longlong)&uStackX_10 + lVar11) == (longlong *)0x0) ||
          (**(longlong **)((longlong)&uStackX_10 + lVar11) == 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a56;
    func_0x(&stack0x00000042 + lVar11,auStack_1fea + 1,0x1f9e,
                    (longlong)&uStackX_18 + lVar11 + -0x16);
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a3b;
    func_0x(&stack0x00000040 + lVar11,auStack_1fea + 1,0x1f9e,
                    (longlong)&uStackX_18 + lVar11 + -0x18);
  }
  lVar12 = *(longlong *)(lVar16 + 8);
  if (*(longlong **)(lVar12 + 0x160) != (longlong *)0x0) {
    lVar22 = **(longlong **)(lVar12 + 0x160);
    uVar28 = *(uint *)(lVar22 + 100);
    if (uVar28 != 0xffffffff) {
      puVar4 = *(uint **)(lVar22 + 8);
      uVar29 = *puVar4;
      if (uVar28 < uVar29) {
        uVar10 = uVar28 / puVar4[9];
        uVar21 = (ulonglong)uVar28 % (ulonglong)puVar4[9];
        lVar22 = *(longlong *)(puVar4 + 4);
      }
      else {
        uVar10 = (uVar28 - uVar29) / puVar4[0x11];
        uVar21 = (ulonglong)(uVar28 - uVar29) % (ulonglong)puVar4[0x11];
        lVar22 = *(longlong *)(puVar4 + 0xc);
      }
      if ((uVar21 * 0x1c0 + *(longlong *)(lVar22 + (ulonglong)uVar10 * 8) != 0) &&
         (((&stack0x00000038)[lVar11] = 0, (*(byte *)(lVar12 + 0x41) & 8) != 0 ||
          ((*(byte *)(lVar12 + 0x108) & 0x40) != 0)))) {
        if (uVar28 < uVar29) {
          uVar29 = uVar28 / puVar4[9];
          uVar21 = (ulonglong)uVar28 % (ulonglong)puVar4[9];
          lVar12 = *(longlong *)(puVar4 + 4);
        }
        else {
          uVar29 = (uVar28 - *puVar4) / puVar4[0x11];
          uVar21 = (ulonglong)(uVar28 - *puVar4) % (ulonglong)puVar4[0x11];
          lVar12 = *(longlong *)(puVar4 + 0xc);
        }
        lVar12 = uVar21 * 0x1c0 + *(longlong *)(lVar12 + (ulonglong)uVar29 * 8);
        if (lVar12 != 0) {
          uVar2 = *(undefined2 *)(lVar12 + 0x38);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b2a;
          func_0x(&stack0x00000040 + lVar11,lVar12,&stack0x00000038 + lVar11,uVar2);
        }
      }
    }
  }
  if (*(longlong *)(param_1 + 0x460) == 0) {
code_r0x00100b8d:
    *(undefined8 **)(&stack0xfffffffffffffff0 + lVar11) = puStack_2068;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100baa;
    iVar9 = func_0x(param_1,&stack0x00000040 + lVar11,0,0);
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b40;
    uVar14 = func_0x(param_1,&stack0x00000040 + lVar11);
    plVar5 = *(longlong **)(param_1 + 0x460);
    uVar15 = *(undefined8 *)(param_1 + 0x468);
    pcVar6 = *(code **)(*plVar5 + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b5c;
    cVar8 = (*pcVar6)(plVar5,uVar15);
    if (cVar8 == '\0') {
      *puStack_2068 = 0;
      (&stack0xfffffffffffffff8)[lVar11] = 1;
      iVar9 = 0;
    }
    else {
      iVar9 = (int)puStack_2068;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b80;
    (*pcRam00000000014743d8)(uVar14,1);
    if ((&stack0xfffffffffffffff8)[lVar11] == '\0') goto code_r0x00100b8d;
  }
  if (iVar9 != 0) {
    if (iVar9 == 1) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cea;
      func_0x(param_1,&stack0x00000040 + lVar11,0,puStack_2068);
    }
    goto code_r0x00100cea;
  }
  if ((bRam0000000001f15eeb & 1) == 0) {
    lVar12 = *(longlong *)
              ((ulonglong)*puRam00000000014743d0 +
              *(longlong *)
               (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam00000000014743c8 * 8));
    if ((lVar12 == 0) || (lVar12 = **(longlong **)(lVar12 + 0x38), lVar12 == 0))
    goto code_r0x00100cea;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c03;
    iVar9 = (*pcRam0000000001474380)(lVar12,600);
    if (iVar9 == 0) goto code_r0x00100cea;
  }
  lVar12 = *(longlong *)(*(longlong *)(param_1 + 0x18) + 0xd0);
  puVar30 = puVar17;
  puVar27 = puVar17;
  if (lVar12 != 0) {
    puVar30 = *(undefined8 **)(lVar12 + 0x40);
    puVar27 = *(undefined8 **)(lVar12 + 0xf8);
  }
  uVar7 = *(uint6 *)(lVar16 + 0x14);
  uVar2 = *(undefined2 *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 0x30) + 0x6b8);
  *(undefined8 **)(&stack0xffffffffffffffe8 + lVar11) = puVar30;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c5e;
  func_0x(0x18000e0,uVar2,(ulonglong)uVar7 << 0x10,puVar27);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c68;
  (*pcRam00000000014732c0)(auStack_2048);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c6f;
  uVar15 = (*pcRam00000000014713f8)();
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c80;
  lVar16 = (*pcRam00000000014713e8)(uVar15,0,0x6c0);
  if (lVar16 != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c93;
    puVar17 = (undefined8 *)func_0x(lVar16,0);
  }
  if (puVar17 != (undefined8 *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100ca8;
    iVar9 = (*pcRam0000000001473640)(auStack_2048,puVar17);
    if (iVar9 == 0) {
      pcVar6 = *(code **)*puVar17;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cb7;
      (*pcVar6)(puVar17,1);
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cc5;
  func_0x(&stack0x00000040 + lVar11,auStack_2048);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cd0;
  (*pcRam00000000014732c8)(auStack_2048);
code_r0x00100cea:
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cf9;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11));
  return;
}

