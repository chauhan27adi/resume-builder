
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,int param_3)

{
  byte *pbVar1;
  undefined2 uVar2;
  short sVar3;
  undefined8 uVar4;
  ushort uVar5;
  uint **ppuVar6;
  char cVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  longlong lVar13;
  longlong *plVar14;
  longlong lVar15;
  uint *puVar16;
  longlong lVar17;
  short *psVar18;
  code *UNRECOVERED_JUMPTABLE_00;
  undefined8 unaff_RBX;
  byte **ppbVar19;
  longlong lVar20;
  longlong lVar21;
  ulonglong uVar22;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [8];
  undefined auStack_49c8 [8];
  longlong *plStack_49c0;
  undefined uStack_49b8;
  uint uStack_49b4;
  uint uStack_49b0;
  int iStack_49a8;
  short sStack_49a4;
  int iStack_49a0;
  undefined8 uStack_499c;
  undefined4 uStack_4994;
  uint auStack_4990 [2];
  undefined8 uStack_4988;
  ushort uStack_4980;
  undefined2 uStack_4978;
  undefined4 uStack_4974;
  undefined8 uStack_4970;
  undefined8 uStack_4968;
  undefined8 uStack_495a;
  undefined8 uStack_4950;
  undefined8 uStack_4940;
  undefined2 uStack_4938;
  undefined8 uStack_4930;
  ushort uStack_4928;
  undefined auStack_4920 [4];
  undefined4 auStack_491c [2];
  undefined4 uStack_4914;
  undefined2 uStack_4910;
  undefined4 uStack_490c;
  undefined2 uStack_4908;
  undefined8 uStack_4900;
  undefined2 uStack_48f8;
  undefined4 uStack_48f0;
  undefined2 uStack_48ec;
  undefined4 uStack_48e8;
  undefined2 uStack_48e4;
  longlong lStack_48d0;
  undefined8 uStack_48c8;
  undefined2 uStack_48c0;
  undefined8 uStack_48b8;
  ushort uStack_48b0;
  undefined auStack_48a8 [4];
  undefined auStack_48a4 [4];
  undefined auStack_48a0 [8];
  undefined8 uStack_4898;
  longlong *plStack_4890;
  uint uStack_4888;
  undefined8 uStack_4884;
  longlong lStack_4870;
  undefined8 auStack_4868 [2];
  undefined8 uStack_4858;
  undefined4 uStack_4850;
  undefined4 uStack_4840;
  undefined uStack_4838;
  undefined4 uStack_4830;
  undefined auStack_4828 [16];
  undefined2 uStack_4800;
  undefined4 uStack_47fc;
  undefined8 uStack_47f8;
  undefined8 uStack_47f0;
  undefined8 uStack_47e2;
  undefined8 uStack_47d8;
  undefined8 uStack_47c8;
  undefined auStack_47b8 [8];
  undefined4 uStack_47b0;
  undefined4 uStack_47a8;
  uint **ppuStack_47a0;
  undefined *puStack_4798;
  undefined8 uStack_4790;
  uint *puStack_4788;
  undefined4 uStack_4780;
  undefined4 uStack_477c;
  longlong lStack_4778;
  undefined4 uStack_4770;
  undefined4 uStack_476c;
  longlong lStack_4768;
  undefined4 uStack_4760;
  undefined4 uStack_475c;
  short *psStack_4758;
  int iStack_4750;
  undefined4 uStack_474c;
  short *psStack_4748;
  int iStack_4740;
  undefined4 uStack_473c;
  undefined8 uStack_4738;
  undefined4 uStack_4730;
  undefined4 uStack_472c;
  undefined auStack_4728 [448];
  undefined8 uStack_4568;
  undefined8 uStack_4560;
  uint uStack_4558;
  short sStack_4554;
  int iStack_4552;
  undefined uStack_454e;
  undefined uStack_454d;
  short sStack_4518;
  undefined4 uStack_4514;
  byte *pbStack_4510;
  byte **ppbStack_4508;
  undefined8 uStack_44fa;
  undefined2 uStack_44f2;
  undefined2 uStack_44f0;
  undefined6 uStack_44ee;
  int iStack_44e4;
  undefined auStack_44e0 [16];
  undefined auStack_44d0 [8];
  undefined8 uStack_44c8;
  undefined8 uStack_44c0;
  undefined6 uStack_44b8;
  undefined2 uStack_44b2;
  undefined6 uStack_44b0;
  undefined2 uStack_44aa;
  undefined8 uStack_44a8;
  undefined auStack_44a0 [16];
  undefined auStack_4490 [16];
  undefined auStack_4480 [16];
  undefined8 uStack_4470;
  undefined auStack_4468 [16];
  undefined2 uStack_4458;
  undefined4 uStack_4454;
  undefined8 uStack_4450;
  undefined8 uStack_4448;
  undefined8 uStack_443a;
  undefined8 uStack_4430;
  undefined8 uStack_4420;
  undefined8 uStack_4408;
  undefined4 uStack_4400;
  undefined2 uStack_43f6;
  short asStack_43e8 [24];
  short asStack_43b8 [8632];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  iStack_49a0 = param_3;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  uStack_47c8 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004a60 + lVar13) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar13);
  sStack_4518 = -1;
  lVar17 = 0;
  pbStack_4510 = (byte *)0x0;
  uStack_4514 = 0;
  uStack_44fa = 0;
  uStack_44f0 = 0;
  uStack_44ee = 0;
  ppbStack_4508 = (byte **)0x0;
  iStack_44e4 = 0xffffffff;
  uStack_4978 = 0xffff;
  uStack_4970 = 0;
  uStack_4974 = 0;
  uStack_495a = 0;
  uStack_4950 = 0;
  uStack_4968 = 0;
  uStack_4800 = 0xffff;
  uStack_47f8 = 0;
  uStack_47fc = 0;
  uStack_47e2 = 0;
  uStack_47d8 = 0;
  uStack_47f0 = 0;
  auStack_4468 = ZEXT816(0);
  uStack_4458 = 0xffff;
  uStack_4450 = 0;
  uStack_4454 = 0;
  uStack_443a = 0;
  uStack_4430 = 0;
  uStack_4448 = 0;
  uStack_4420 = 0;
  uStack_4408 = 0;
  uStack_4400 = 0;
  uStack_43f6 = 0;
  auStack_4828 = ZEXT816(0);
  plStack_49c0 = (longlong *)0x0;
  uStack_49b8 = 0;
  uStack_49b4 = 0;
  auStack_49c8[0] = 5;
  auStack_4868[0] = 0xab8870;
  uStack_4858 = 0;
  uStack_4850 = 0;
  uStack_4840 = 0xffffffff;
  uStack_4830 = 0x80000000;
  uStack_4838 = 0;
  uVar2 = *(undefined2 *)(param_1 + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100196;
  lStack_48d0 = param_1;
  lStack_4870 = param_2;
  plVar14 = (longlong *)func_0x(uVar2);
  plStack_4890 = plVar14;
  if (*(short *)(param_1 + 0x1a) != 1) {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1001ae;
    lVar15 = func_0x();
    if (lVar15 == 0) {
      puVar16 = (uint *)0x4;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1001b8;
      lVar15 = func_0x();
      puVar16 = (uint *)(lVar15 + 0x10);
    }
    *puVar16 = *puVar16 | 2;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1001dc;
    (*_DAT_)(0x59,0x43,0x10,0x9d);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1001e4;
  func_0x(param_1);
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1001e9;
  uVar8 = func_0x();
  *(undefined4 *)((longlong)auStackX_8 + lVar13 + 0x18) = 0;
  *(undefined4 *)((longlong)auStackX_8 + lVar13 + 0x10) = 0;
  *(undefined4 *)((longlong)auStackX_8 + lVar13 + 8) = 1;
  *(undefined4 *)((longlong)auStackX_8 + lVar13) = uVar8;
  *(undefined4 *)((longlong)auStackX_8 + lVar13 + -8) = 1;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar13) = 0;
  *(undefined8 **)(&stack0xffffffffffffffe8 + lVar13) = &uStack_4898;
  uVar4 = *(undefined8 *)(param_1 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10022f;
  func_0x(plVar14,uVar4,auStack_4868,auStack_49c8);
  (&stack0xffffffffffffffe8)[lVar13] = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10024b;
  func_0x(plVar14,uStack_4898,auStack_49c8[0],0);
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar14 + 0x270);
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100257;
  (*UNRECOVERED_JUMPTABLE_00)(plVar14);
  iStack_49a8 = *(int *)(param_2 + 4);
  sStack_49a4 = *(short *)(param_2 + 8);
  lVar15 = plVar14[6];
  uStack_4884 = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar20 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar20 != 0) && (lVar20 = **(longlong **)(lVar20 + 0x38), lVar20 != 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1002c3;
      iVar9 = (*_DAT_)(lVar20,0x337);
      if (iVar9 != 0) goto LAB_;
    }
    lVar20 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar20 != 0) {
      lVar17 = *(longlong *)(lVar20 + 0x60);
    }
  }
LAB_:
  lVar20 = *(longlong *)(lVar15 + 0x728);
  do {
    plVar14 = plStack_49c0;
    auStack_4990[0] = 0;
    if (plStack_49c0 != (longlong *)0x0) {
      iVar9 = (int)(short)uStack_49b4;
      if (((*(ushort *)((longlong)plStack_49c0 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_49c0 + 0x62) >> 3 & 1) != 0) {
          if (iVar9 == 3) {
            iVar9 = 4;
          }
          else if (iVar9 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_49c0 + 100) & 8) != 0) &&
              (lVar21 = plStack_49c0[0x12], lVar21 != 0)) && (*(longlong *)(lVar21 + 0x758) != 0)) {
            uVar4 = *(undefined8 *)(lVar21 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10039c;
            func_0x(uVar4,plStack_49c0,iVar9);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar14 + 100) & 8) != 0)) &&
           ((2 < iVar9 &&
            (((*(uint *)((longlong)plVar14 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar21 = *plVar14, lVar21 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1003de;
          iVar12 = (*_DAT_)(lVar21,0x2000,2,auStack_48a8);
          if (iVar12 != 0) {
            LOCK();
            *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100400;
        func_0x(plVar14 + 0x13,iVar9);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10041f;
          func_0x(plVar14,0,iVar9);
        }
        uStack_49b4 = uStack_49b4 & 0xffff0000;
        plStack_49c0 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10033b;
        func_0x(&plStack_49c0);
      }
    }
    if (*(longlong *)(lVar15 + 0x728) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10044f;
      func_0x(&plStack_49c0,&iStack_49a8,lVar15);
      plVar14 = plStack_49c0;
      if (plStack_49c0 != (longlong *)0x0) {
        iVar9 = (int)(short)uStack_49b4;
        if (((*(ushort *)((longlong)plStack_49c0 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
          if (((byte)*(undefined2 *)((longlong)plStack_49c0 + 0x62) >> 3 & 1) != 0) {
            if (iVar9 == 3) {
              iVar9 = 4;
            }
            else if (iVar9 < 2) goto LAB_;
            if ((((*(uint *)((longlong)plStack_49c0 + 100) & 8) != 0) &&
                (lVar21 = plStack_49c0[0x12], lVar21 != 0)) && (*(longlong *)(lVar21 + 0x758) != 0))
            {
              uVar4 = *(undefined8 *)(lVar21 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1004d8;
              func_0x(uVar4,plStack_49c0,iVar9);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar14 + 100) & 8) != 0)) &&
             ((2 < iVar9 &&
              (((*(uint *)((longlong)plVar14 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar21 = *plVar14, lVar21 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10051a;
            iVar12 = (*_DAT_)(lVar21,0x2000,2,auStack_48a4);
            if (iVar12 != 0) {
              LOCK();
              *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10053c;
          func_0x(plVar14 + 0x13,iVar9);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10055b;
            func_0x(plVar14,0,iVar9);
          }
          uStack_49b4 = uStack_49b4 & 0xffff0000;
          plStack_49c0 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100477;
          func_0x(&plStack_49c0);
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100574;
    func_0x(lVar15,&iStack_49a8);
    *(uint **)(&stack0xfffffffffffffff0 + lVar13) = &uStack_4888;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) = 4;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10059f;
    plStack_49c0 = (longlong *)
                   func_0x(_DAT_,lVar15,&iStack_49a8,auStack_4990);
    if (lVar17 != 0) {
      uVar22 = (ulonglong)(*(uint *)(lVar17 + 0x500) & 0xf);
      if (*(longlong *)(lVar17 + 0x508 + uVar22 * 8) != *plStack_49c0) {
        *(longlong *)(lVar17 + 0x508 + uVar22 * 8) = *plStack_49c0;
        *(longlong *)(lVar17 + 0x500) = *(longlong *)(lVar17 + 0x500) + 1;
      }
    }
    uStack_49b4 = (auStack_4990[0] >> 3 & 1) << 0x18 | uStack_49b4 & 0xff0004 | 4;
    uStack_49b0 = auStack_4990[0] >> 4 & 1 | uStack_49b0 & 0xffffff00;
    if (((lVar20 != 0) && (lVar17 != 0)) && (lVar17 == *(longlong *)(lVar15 + 0x1c38))) {
      *(longlong *)(lVar20 + 0x5b28) = *(longlong *)(lVar20 + 0x5b28) + 1;
      if ((int)uStack_4884 != 0) {
        *(longlong *)(lVar20 + 0x5b30) = *(longlong *)(lVar20 + 0x5b30) + 1;
        *(longlong *)(lVar20 + 0x5b38) = *(longlong *)(lVar20 + 0x5b38) + (ulonglong)uStack_4888;
        if (0xffffff < uStack_49b4) {
          *(longlong *)(lVar20 + 0x5b40) = *(longlong *)(lVar20 + 0x5b40) + 1;
          *(longlong *)(lVar20 + 0x5b48) = *(longlong *)(lVar20 + 0x5b48) + (ulonglong)uStack_4888;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10066e;
    cVar7 = func_0x(lVar15);
    iVar9 = 0;
    if (((cVar7 == '\0') || (*(char *)(lVar15 + 0x2050) == '\0')) ||
       ((iStack_49a8 == 0 || ((iStack_49a8 == 9 && (sStack_49a4 == 1)))))) goto LAB_;
    lVar21 = *plStack_49c0;
    if (*(short *)(lVar21 + 0x24) == 0) {
LAB_:
      uStack_4930 = *(undefined8 *)(lVar21 + 0x28);
      uStack_4928 = *(ushort *)(lVar21 + 0x30);
    }
    else {
      cVar7 = *(char *)(lVar21 + 1);
      if (cVar7 == '\v') {
        if (*(int *)(lVar21 + 0x18) != 99) {
LAB_:
          if (cVar7 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar7 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar21 + 0x18) != 99) goto LAB_;
      }
      uStack_48f0 = *(undefined4 *)(lVar21 + 0x20);
      uStack_48ec = *(undefined2 *)(lVar21 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1006f3;
      cVar7 = func_0x(&uStack_48f0);
      if (cVar7 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100703;
      func_0x(lVar21,&uStack_4930);
    }
    uVar11 = *(uint *)(lVar15 + 0x2108);
    do {
      uVar10 = uVar11 & 0xfffffffe;
      uStack_499c = *(undefined8 *)(lVar15 + 0x20fc);
      uStack_4994 = *(undefined4 *)(lVar15 + 0x2104);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13);
      UNLOCK();
      uVar11 = *(uint *)(lVar15 + 0x2108);
    } while (uVar10 != uVar11);
    if ((uint)uStack_4930 <= (uint)uStack_499c) {
      if ((uint)uStack_499c != (uint)uStack_4930) goto LAB_;
      uVar11 = (uint)((ulonglong)uStack_499c >> 0x20);
      if ((uStack_4930._4_4_ <= uVar11) &&
         ((uVar11 != uStack_4930._4_4_ || (uStack_4928 <= (ushort)uStack_4994)))) goto LAB_;
    }
    if ((*(char *)(lVar15 + 0x6ac8) == '\0') &&
       (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) != *(longlong *)(lVar15 + 0x2120))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1007ba;
      cVar7 = func_0x(lVar15);
      if (cVar7 == '\0') {
        uVar11 = *(uint *)(lVar15 + 0x2108);
        do {
          uVar10 = uVar11 & 0xfffffffe;
          uStack_499c = *(undefined8 *)(lVar15 + 0x20fc);
          uStack_4994 = *(undefined4 *)(lVar15 + 0x2104);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13);
          UNLOCK();
          uVar11 = *(uint *)(lVar15 + 0x2108);
        } while (uVar10 != uVar11);
        uVar5 = (ushort)uStack_4994;
        uStack_48b0 = (ushort)uStack_4994;
        lVar20 = *plStack_49c0;
        uStack_48b8 = uStack_499c;
        if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
          uStack_4988 = *(undefined8 *)(lVar20 + 0x28);
          uStack_4980 = *(ushort *)(lVar20 + 0x30);
        }
        else {
          cVar7 = *(char *)(lVar20 + 1);
          if (cVar7 == '\v') {
            if (*(int *)(lVar20 + 0x18) != 99) {
LAB_:
              if (cVar7 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar7 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar20 + 0x18) != 99) goto LAB_;
          }
          uStack_4914 = *(undefined4 *)(lVar20 + 0x20);
          uStack_4910 = *(undefined2 *)(lVar20 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a79;
          cVar7 = func_0x(&uStack_4914);
          if (cVar7 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a89;
          func_0x(lVar20,&uStack_4988);
        }
        if ((uint)uStack_499c < (uint)uStack_4988) {
LAB_:
          lVar20 = *(longlong *)(lVar15 + 0x6b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100aeb;
          func_0x(&uStack_4988,asStack_43e8,auStack_4920);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b02;
          func_0x(&uStack_48b8,asStack_43b8,auStack_4920);
          if ((_DAT_ & 0x10000) != 0) {
            uStack_47b0 = 0x60000;
            uStack_47a8 = 0;
            ppuStack_47a0 = &puStack_4788;
            puStack_4798 = auStack_4728;
            uStack_4568 = 0;
            uStack_4790 = 0;
            uStack_4560 = 0;
            puStack_4788 = &uStack_4558;
            uStack_4780 = 0x34;
            uStack_477c = 5;
            uStack_4770 = 0x10;
            uStack_476c = 5;
            uStack_4760 = 0x10;
            uStack_475c = 6;
            uStack_474c = 7;
            uStack_473c = 8;
            uStack_4738 = 0;
            uStack_4730 = 0;
            uStack_472c = 9;
            uStack_4558 = (uint)*(ushort *)(lVar15 + 0x6b8);
            sStack_4554 = sStack_49a4;
            iStack_4552 = iStack_49a8;
            uStack_454e = 1;
            uStack_454d = *(undefined *)(*plStack_49c0 + 1);
            lStack_4778 = lVar20 + 0x254;
            lStack_4768 = lVar20 + 0x244;
            lVar15 = -1;
            do {
              lVar15 = lVar15 + 1;
            } while (asStack_43e8[lVar15] != 0);
            iStack_4750 = (int)lVar15 * 2;
            psStack_4758 = asStack_43e8;
            lVar15 = -1;
            do {
              lVar15 = lVar15 + 1;
            } while (asStack_43b8[lVar15] != 0);
            iStack_4740 = (int)lVar15 * 2;
            psStack_4748 = asStack_43b8;
            auStack_491c[0] = 0;
            UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100cc4;
            puVar16 = (uint *)(*UNRECOVERED_JUMPTABLE_00)(lVar20,auStack_491c);
            ppuVar6 = ppuStack_47a0;
            if (puVar16 != (uint *)0x0) {
              lVar15 = -1;
              do {
                lVar15 = lVar15 + 1;
              } while (*(short *)((longlong)puVar16 + lVar15 * 2) != 0);
              iVar9 = (int)lVar15 * 2;
            }
            ppuStack_47a0[10] = puVar16;
            *(int *)(ppuVar6 + 0xb) = iVar9;
            *(undefined4 *)((longlong)ppuVar6 + 0x5c) = 9;
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100cfe;
            func_0x(auStack_47b8);
          }
        }
        else if ((uint)uStack_499c == (uint)uStack_4988) {
          uVar11 = (uint)((ulonglong)uStack_4988 >> 0x20);
          if ((uStack_499c._4_4_ < uVar11) ||
             ((uStack_499c._4_4_ == uVar11 && (uVar5 < uStack_4980)))) goto LAB_;
        }
LAB_:
        uVar22 = 8;
        uVar11 = 0x2640;
        if ((1 < (short)uStack_49b4) && (*(char *)(*plStack_49c0 + 1) != '\x01')) {
          if (lVar17 != 0) {
            *(longlong *)(lVar17 + 0x588) = *plStack_49c0;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100d2f;
          lVar17 = func_0x();
          if (lVar17 != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100d39;
            lVar17 = func_0x();
            if (*(longlong *)(lVar17 + 0x30) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100d45;
              lVar17 = func_0x();
              uVar10 = *(uint *)(*(longlong *)(lVar17 + 0x30) + 0xc);
              if ((uVar10 < 0xe) && ((uVar11 >> (uVar10 & 0x1f) & 1) != 0)) goto LAB_;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100d61;
          func_0x(0,uVar22 & 0xffffffff);
        }
LAB_:
        lVar17 = *plStack_49c0;
        iStack_44e4 = iStack_49a0;
        if (-1 < *(char *)(lVar17 + 2)) goto LAB_;
        pbVar1 = (byte *)(lVar17 + 0x60);
        if ((sStack_4518 == 0) || (ppbVar19 = ppbStack_4508, ppbStack_4508 == (byte **)0x0)) {
          uStack_44b8 = 0;
          uStack_44aa = 0;
          auStack_4490 = ZEXT816(0);
          auStack_44e0 = ZEXT816(0);
          stack0xffffffffffffbb32 = SUB1614(ZEXT816(0),2);
          auStack_44d0._0_2_ = 0xffff;
          uStack_44c8 = 0;
          uStack_44b2 = 0;
          uStack_44b0 = 0;
          uStack_44a8 = 0;
          uStack_44c0 = 0;
          auStack_44a0 = ZEXT816(0);
          auStack_4480._0_12_ = ZEXT812(0);
          auStack_4480._12_4_ = 0;
          uStack_4470 = 0;
          ppbVar19 = (byte **)auStack_44e0;
        }
        if (*(short *)(lVar17 + 0x24) == 0) {
LAB_:
          uStack_4940 = *(undefined8 *)(lVar17 + 0x28);
          uStack_4938 = *(undefined2 *)(lVar17 + 0x30);
        }
        else {
          cVar7 = *(char *)(lVar17 + 1);
          if (cVar7 == '\v') {
            if (*(int *)(lVar17 + 0x18) != 99) {
LAB_:
              if (cVar7 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar7 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar17 + 0x18) != 99) goto LAB_;
          }
          uStack_490c = *(undefined4 *)(lVar17 + 0x20);
          uStack_4908 = *(undefined2 *)(lVar17 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e9b;
          cVar7 = func_0x(&uStack_490c);
          if (cVar7 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100eab;
          func_0x(lVar17,&uStack_4940);
        }
        *ppbVar19 = pbVar1;
        *(undefined4 *)(ppbVar19 + 0xc) = (undefined4)uStack_4940;
        *(int *)((longlong)ppbVar19 + 100) = (int)((ulonglong)uStack_4940 >> 0x20);
        *(undefined2 *)(ppbVar19 + 0xd) = uStack_4938;
        *(undefined4 *)((longlong)ppbVar19 + 0x6c) = *(undefined4 *)(lVar17 + 0x20);
        *(undefined2 *)(ppbVar19 + 0xe) = *(undefined2 *)(lVar17 + 0x24);
        *(undefined2 *)((longlong)ppbVar19 + 0x72) = 0;
        uVar8 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0xb39010);
        uStack_499c = CONCAT44(uStack_499c._4_4_,uVar8);
        uVar4 = uStack_499c;
        uVar22 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0xb39014);
        *(undefined2 *)(ppbVar19 + 2) = 0xffff;
        ppbVar19[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar19 + 0x2e) = 0;
        ppbVar19[7] = (byte *)0x0;
        ppbVar19[4] = (byte *)0x0;
        ppbVar19[9] = (byte *)0x0;
        ppbVar19[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar19 + 0xb) = 0;
        if ((**ppbVar19 & 2) != 0) {
          pbVar1 = pbVar1 + uVar22;
          if ((*pbVar1 & 1) == 0) {
            *(undefined2 *)(ppbVar19 + 2) = 0;
            ppbVar19[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar19 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010110d */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x101f70) -
                      0x1a00e20))();
            return;
          }
          *(undefined2 *)(ppbVar19 + 2) = 1;
          ppbVar19[3] = pbVar1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x101f50) *
                                  4 + 0x101f40) - 0x1a00e20);
                    /* WARNING: Could not emulate address calculation at 0x00100f7d */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if ((**ppbVar19 & 4) != 0) {
          uStack_499c._2_2_ = (short)((uint)uVar8 >> 0x10);
          if (uStack_499c._2_2_ != 0) {
            uVar22 = (ulonglong)*(ushort *)(lVar17 + 0x61 + (longlong)uStack_499c._2_2_ * 2);
          }
          psVar18 = (short *)(pbVar1 + uVar22);
          ppbVar19[9] = (byte *)psVar18;
          sVar3 = *psVar18;
          ppbVar19[10] = (byte *)(psVar18 + 1);
          *(short *)(ppbVar19 + 0xb) = (sVar3 + 1) * 2;
        }
        pbVar1 = ppbVar19[1];
        uStack_499c = uVar4;
        if (pbVar1 != (byte *)0x0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1011cc;
          func_0x(pbVar1,ppbVar19);
        }
LAB_:
        pbStack_4510 = (byte *)((ulonglong)*(ushort *)(lVar17 + (0xfff - (longlong)iStack_49a0) * 2)
                               + lVar17);
        if ((*pbStack_4510 & 1) == 0) {
          sStack_4518 = 0;
          uStack_4514 = 0;
          uStack_44f2 = 0;
          uStack_44f0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101409 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_4510 & 0xe) * 4 + 0x101fdc) -
                    0x1a00e20))();
          return;
        }
        sStack_4518 = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_4510 & 0x1c) + 0x101fbc) * 4 +
                               0x101fac) - 0x1a00e20);
                    /* WARNING: Could not emulate address calculation at 0x0010122f */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
    }
    if (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) == *(longlong *)(lVar15 + 0x2120)) goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1007fe;
    cVar7 = func_0x(lVar15);
    if (cVar7 != '\0') goto LAB_;
    if (lVar17 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100810;
      lVar17 = func_0x();
    }
    lVar21 = *plStack_49c0;
    if (*(short *)(lVar21 + 0x24) == 0) {
LAB_:
      uStack_4900 = *(undefined8 *)(lVar21 + 0x28);
      uStack_48f8 = *(undefined2 *)(lVar21 + 0x30);
    }
    else {
      cVar7 = *(char *)(lVar21 + 1);
      if (cVar7 == '\v') {
        if (*(int *)(lVar21 + 0x18) != 99) {
LAB_:
          if (cVar7 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar7 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar21 + 0x18) != 99) goto LAB_;
      }
      uStack_48e8 = *(undefined4 *)(lVar21 + 0x20);
      uStack_48e4 = *(undefined2 *)(lVar21 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10085f;
      cVar7 = func_0x(&uStack_48e8);
      if (cVar7 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10086f;
      func_0x(lVar21,&uStack_4900);
    }
    plVar14 = plStack_49c0;
    if (plStack_49c0 != (longlong *)0x0) {
      iVar9 = (int)(short)uStack_49b4;
      if (((*(ushort *)((longlong)plStack_49c0 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_49c0 + 0x62) >> 3 & 1) != 0) {
          if (iVar9 == 3) {
            iVar9 = 4;
          }
          else if (iVar9 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_49c0 + 100) & 8) != 0) &&
              (lVar21 = plStack_49c0[0x12], lVar21 != 0)) && (*(longlong *)(lVar21 + 0x758) != 0)) {
            uVar4 = *(undefined8 *)(lVar21 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100917;
            func_0x(uVar4,plStack_49c0,iVar9);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar14 + 100) & 8) != 0)) &&
           ((2 < iVar9 &&
            (((*(uint *)((longlong)plVar14 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar21 = *plVar14, lVar21 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10095b;
          iVar12 = (*_DAT_)(lVar21,0x2000,2,auStack_48a0);
          if (iVar12 != 0) {
            LOCK();
            *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10097d;
        func_0x(plVar14 + 0x13,iVar9);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10099c;
          func_0x(plVar14,0,iVar9);
        }
        uStack_49b4 = uStack_49b4 & 0xffff0000;
        plStack_49c0 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1008b6;
        func_0x(&plStack_49c0);
      }
    }
    uStack_48c8 = uStack_4900;
    uStack_48c0 = uStack_48f8;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
    uVar4 = *(undefined8 *)(lVar15 + 0x728);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1009e7;
    func_0x(uVar4,&uStack_48c8,4);
  } while( true );
}

