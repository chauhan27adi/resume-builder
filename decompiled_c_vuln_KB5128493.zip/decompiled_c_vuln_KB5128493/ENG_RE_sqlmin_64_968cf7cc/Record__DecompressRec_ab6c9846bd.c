
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,longlong param_2,ulonglong param_3,short *param_4)

{
  longlong lVar1;
  longlong *plVar2;
  short *psVar3;
  short sVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  byte bVar9;
  int iVar10;
  longlong lVar11;
  ulonglong *puVar12;
  ulonglong uVar13;
  longlong *plVar14;
  undefined8 uVar15;
  undefined8 *puVar16;
  byte bVar17;
  ushort uVar18;
  ushort uVar19;
  ulonglong uVar20;
  longlong **pplVar21;
  byte *pbVar22;
  uint uVar23;
  uint uVar24;
  ushort uVar25;
  ushort uVar26;
  longlong lVar27;
  longlong *plVar28;
  undefined *puVar29;
  uint uVar30;
  ushort uVar31;
  longlong lVar32;
  longlong lVar33;
  longlong *plVar34;
  ushort uVar35;
  short *psVar36;
  uint uVar37;
  ushort *puVar38;
  longlong *plVar39;
  longlong unaff_GS_OFFSET;
  ushort auStackX_8 [2];
  uint uStackX_c;
  uint auStackX_10 [2];
  ushort uStackX_18;
  ushort auStackX_1a [3];
  int iStackX_20;
  undefined4 uStackX_24;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  plVar2 = (longlong *)((longlong)&iStackX_20 + lVar11 + -0x20);
  *(undefined8 *)(&stack0x00000080 + lVar11) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002a90 + lVar11) = _DAT_ ^ (ulonglong)plVar2;
  *(int *)((longlong)&uStackX_c + lVar11) = (int)param_3;
  *plVar2 = param_2;
  if ((((**(byte **)(param_4 + 4) & 0x1c) - 4 & 0xffffffeb) != 0) ||
     ((**(byte **)(param_4 + 4) & 0x1c) == 0x18)) {
    plVar28 = (longlong *)0x0;
    uVar24 = 0;
    *(undefined4 *)(&stack0x00000030 + lVar11) = 0;
    *(undefined **)(&stack0x00000058 + lVar11) = &stack0x00000af0 + lVar11;
    uVar18 = param_4[1];
    uVar23 = (uint)uVar18;
    *(uint *)(&stack0x0000003c + lVar11) = (uint)uVar18;
    puVar38 = (ushort *)((longlong)&uStackX_24 + lVar11 + 2);
    *puVar38 = *puVar38 & 0xffe0;
    *(undefined (*) [16])(&stack0x00000090 + lVar11) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000000a0 + lVar11) = ZEXT816(0);
    *(undefined8 *)(&stack0x000000b0 + lVar11) = 0;
    *(undefined8 *)(&stack0x000000b8 + lVar11) = 0;
    *(undefined8 *)(&stack0x000000c0 + lVar11) = 0;
    *(undefined4 *)(&stack0x00000ae8 + lVar11) = 0;
    *(undefined4 *)(&stack0x00000040 + lVar11) = 0;
    *(undefined8 *)(param_1 + 8) = 0;
    uVar13 = (ulonglong)(uint)uVar18 * 0x20;
    uVar20 = uVar13 + 0xf;
    if (uVar20 <= uVar13) {
      uVar20 = 0xffffffffffffff0;
    }
    uVar20 = uVar20 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1008e9;
    func_0x();
    lVar32 = -uVar20;
    puVar29 = (undefined *)((longlong)&iStackX_20 + lVar32 + lVar11 + -0x20);
    *(longlong *)(&stack0x00000060 + lVar11) = (longlong)&iStackX_20 + lVar32 + lVar11 + -0x20;
    *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100906;
    func_0x((longlong)&iStackX_20 + lVar32 + lVar11 + -0x20,0,uVar23 << 5);
    uVar18 = 0;
    *(undefined2 *)((longlong)auStackX_8 + lVar11) = 0;
    plVar39 = (longlong *)
              ((ulonglong)(ushort)param_4[0xe] + (ulonglong)(ushort)param_4[0xd] +
              *(longlong *)(param_4 + 4));
    *(longlong **)(&stack0x00000048 + lVar11) = plVar39;
    plVar14 = plVar28;
    if (*param_4 != 0) {
      plVar14 = *(longlong **)(param_4 + 8);
    }
    *(longlong **)(&stack0x00000068 + lVar11) = plVar14;
    puVar16 = (undefined8 *)plVar14[1];
    if (puVar16 == (undefined8 *)0x0) {
      plVar14[1] = (longlong)(&stack0x00000090 + lVar11);
      puVar16 = (undefined8 *)(&stack0x00000090 + lVar11);
      if (*plVar14 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x10096b;
        func_0x(&stack0x00000090 + lVar11,plVar14);
        puVar16 = *(undefined8 **)(*(longlong *)(&stack0x00000068 + lVar11) + 8);
      }
      *(undefined4 *)(&stack0x00000040 + lVar11) = 1;
    }
    if (((**(byte **)*puVar16 & 2) != 0) && (*(int *)((longlong)puVar16 + 0x24) == 0)) {
      lVar33 = puVar16[3];
      if (*(short *)(lVar33 + 0x10) == -1) {
        *(undefined2 *)(lVar33 + 0x10) = 1;
      }
      uVar5 = *(undefined2 *)(puVar16 + 4);
      uVar15 = puVar16[5];
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x1009ad;
      func_0x(lVar33 + 0x12,uVar15,uVar5);
      uVar26 = *(ushort *)(puVar16 + 4);
      uVar15 = puVar16[6];
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x1009c7;
      func_0x(uVar15,0xff,(uVar26 >> 3) + 1);
    }
    *param_1 = 1;
    *(undefined8 *)(param_1 + 8) = 0;
    psVar36 = param_1 + 1;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar32 + lVar11) =
         *(undefined4 *)(&stack0x0000003c + lVar11);
    lVar33 = *plVar2;
    *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x1009f1;
    func_0x(psVar36,lVar33);
    if (*(int *)(param_4 + 2) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100a03;
      func_0x(param_4 + 1);
    }
    *(short *)((longlong)&uStackX_18 + lVar11) = param_4[1];
    *(undefined2 *)((longlong)&uStackX_18 + lVar11 + 2) = 0;
    *(undefined4 *)((longlong)&iStackX_20 + lVar11) = 0;
    *(undefined2 *)((longlong)&uStackX_24 + lVar11) = 0;
    puVar38 = (ushort *)((longlong)&uStackX_24 + lVar11 + 2);
    *puVar38 = *puVar38 & 0xffe0;
    *(undefined8 *)(&stack0x00000028 + lVar11) = 0;
    plVar14 = plVar28;
    uVar26 = uVar18;
    while (uVar26 != *(ushort *)((longlong)&uStackX_18 + lVar11)) {
      uVar25 = uVar26 + 1;
      *(ushort *)((longlong)&uStackX_18 + lVar11 + 2) = uVar25;
      *(ushort *)((longlong)&uStackX_24 + lVar11) = uVar25;
      *(int *)((longlong)&iStackX_20 + lVar11) =
           (int)(short)(*(short *)((longlong)&iStackX_20 + lVar11) + -1);
      plVar34 = (longlong *)0x0;
      uVar23 = 0;
      if ((ushort)param_4[1] < uVar25) {
        uVar37 = 0;
        plVar39 = plVar28;
        uVar30 = uVar23;
        if ((*(byte *)((longlong)&uStackX_24 + lVar11 + 2) & 0x10) != 0) {
          plVar39 = (longlong *)((longlong)plVar14 + 4);
          uVar23 = 0;
          uVar30 = *(uint *)plVar14;
          uVar37 = uVar24;
        }
        goto LAB_;
      }
      lVar33 = *(longlong *)(param_4 + 4);
      uVar30 = (uint)*(ushort *)((longlong)&uStackX_18 + lVar11 + 2);
      uVar23 = uVar30 - 1;
      if ((int)uVar23 < 0) {
        uVar23 = uVar30;
      }
      bVar9 = *(byte *)((ulonglong)(ushort)param_4[0xc] + ((int)uVar23 >> 1) + lVar33);
      bVar17 = bVar9 >> 4;
      if ((*(byte *)((longlong)&uStackX_18 + lVar11 + 2) & 1) != 0) {
        bVar17 = bVar9 & 0xf;
      }
      switch(bVar17) {
      case 0:
        uVar26 = *(short *)((longlong)&uStackX_24 + lVar11) - 1;
        plVar39 = plVar28;
        uVar23 = uVar24;
        uVar30 = uVar24;
        uVar37 = 0;
        goto LAB_;
      case 1:
        uVar30 = *(ushort *)((longlong)&uStackX_24 + lVar11 + 2) >> 3 & 1;
        plVar39 = (longlong *)0x1343e16;
        plVar34 = (longlong *)(ulonglong)(uVar30 * 2);
        break;
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
        uVar26 = *(ushort *)((ulonglong)bVar17 * 4 + 0x81de80);
        uVar30 = (uint)uVar26;
        *(byte **)(&stack0x00000048 + lVar11) = (byte *)((longlong)plVar39 + (ulonglong)uVar26);
        break;
      case 10:
        if (*(int *)(param_4 + 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100b1f;
          func_0x(param_4 + 1);
          lVar33 = *(longlong *)(param_4 + 4);
        }
        uVar26 = *(ushort *)((longlong)auStackX_8 + lVar11);
        *(ushort *)((longlong)auStackX_8 + lVar11) = uVar26 + 1;
        uVar25 = param_4[0xf];
        lVar27 = (ulonglong)uVar25 + 1 + lVar33;
        lVar1 = lVar27 + (ulonglong)uVar26 * 2;
        uVar31 = *(ushort *)(lVar1 + 2);
        uVar35 = uVar31 & 0x7fff;
        uVar19 = uVar18;
        if (uVar26 != 0) {
          uVar19 = *(ushort *)(lVar27 + 2 + (ulonglong)(uVar26 - 1) * 2) & 0x7fff;
          uVar25 = param_4[0xf];
          lVar33 = *(longlong *)(param_4 + 4);
          uVar31 = *(ushort *)(lVar1 + 2);
        }
        uVar30 = (uint)uVar35 - (uint)uVar19;
        plVar39 = (longlong *)
                  ((ulonglong)uVar25 + (ulonglong)uVar19 + lVar33 + (ulonglong)(ushort)param_4[0x12]
                  );
        plVar34 = (longlong *)(ulonglong)(uVar31 >> 0xf);
        break;
      case 0xb:
        uVar26 = *(short *)((longlong)&uStackX_24 + lVar11) - 1;
        plVar39 = (longlong *)0x779384;
        uVar23 = 2;
        uVar30 = *(ushort *)((longlong)&uStackX_24 + lVar11 + 2) >> 3 & 1;
        uVar37 = 0;
        goto LAB_;
      case 0xc:
        uVar30 = 1;
        *(byte **)(&stack0x00000048 + lVar11) = (byte *)((longlong)plVar39 + 1);
        plVar34 = (longlong *)0x4;
        break;
      default:
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar32 + lVar11) = 0x770e28;
        *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100c29;
        (*_DAT_)(1,0xb75c80,0xb7c0a0,0x11e5);
        plVar34 = plVar28;
        plVar39 = plVar28;
        uVar30 = 0;
      }
      uVar26 = *(short *)((longlong)&uStackX_24 + lVar11) - 1;
      uVar37 = (uint)plVar34 & 1;
      uVar23 = (uint)plVar34;
      if (((ulonglong)plVar34 & 1) == 0) {
LAB_:
        plVar14 = plVar28;
        if (*param_4 != 0) {
          plVar14 = *(longlong **)(param_4 + 8);
        }
        if ((plVar39 == (longlong *)0x0) || (plVar39 == (longlong *)0x779384)) {
          *(undefined4 *)((longlong)auStackX_10 + lVar11) = 0;
        }
        else {
          iVar10 = *(int *)(&stack0x00000030 + lVar11);
          *(uint *)(&stack0xfffffffffffffff8 + lVar32 + lVar11) = uVar23;
          *(longlong *)(&stack0xfffffffffffffff0 + lVar32 + lVar11) = (longlong)auStackX_10 + lVar11
          ;
          *(int *)(&stack0xffffffffffffffe8 + lVar32 + lVar11) = 0x1f9e - iVar10;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar32 + lVar11) =
               *(undefined8 *)(&stack0x00000058 + lVar11);
          *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100c93;
          plVar39 = (longlong *)
                    func_0x(plVar14,(longlong)&iStackX_20 + lVar11,plVar39,uVar30);
          if (plVar39 != (longlong *)0x0) {
            if (plVar39 == *(longlong **)(&stack0x00000058 + lVar11)) {
              uVar30 = *(uint *)((longlong)auStackX_10 + lVar11);
              *(uint *)(&stack0x00000030 + lVar11) = *(int *)(&stack0x00000030 + lVar11) + uVar30;
              *(byte **)(&stack0x00000058 + lVar11) =
                   (byte *)((longlong)*(longlong **)(&stack0x00000058 + lVar11) + (ulonglong)uVar30)
              ;
            }
            else {
              uVar30 = *(uint *)((longlong)auStackX_10 + lVar11);
            }
            goto LAB_;
          }
        }
        puVar29 = *(undefined **)(&stack0x00000060 + lVar11);
        *(uint *)(puVar29 + (ulonglong)uVar26 * 0x20 + 0xc) =
             *(uint *)(puVar29 + (ulonglong)uVar26 * 0x20 + 0xc) | 2;
        plVar14 = *(longlong **)(&stack0x00000028 + lVar11);
        uVar26 = *(ushort *)((longlong)&uStackX_18 + lVar11 + 2);
        plVar39 = *(longlong **)(&stack0x00000048 + lVar11);
      }
      else {
        *(uint *)((longlong)auStackX_10 + lVar11) = uVar30;
LAB_:
        pplVar21 = (longlong **)
                   ((ulonglong)uVar26 * 0x20 + *(longlong *)(&stack0x00000060 + lVar11));
        *pplVar21 = plVar39;
        *(uint *)(pplVar21 + 1) = uVar30;
        uVar23 = *(uint *)((longlong)pplVar21 + 0xc);
        *(uint *)((longlong)pplVar21 + 0xc) = uVar37 | uVar23 & 0xfffffffa;
        uVar6 = *(undefined4 *)((longlong)&uStackX_24 + lVar11);
        uVar7 = *(undefined4 *)(&stack0x00000028 + lVar11);
        uVar8 = *(undefined4 *)(&stack0x0000002c + lVar11);
        *(undefined4 *)(pplVar21 + 2) = *(undefined4 *)((longlong)&iStackX_20 + lVar11);
        *(undefined4 *)((longlong)pplVar21 + 0x14) = uVar6;
        *(undefined4 *)(pplVar21 + 3) = uVar7;
        *(undefined4 *)((longlong)pplVar21 + 0x1c) = uVar8;
        *(uint *)((longlong)pplVar21 + 0xc) = uVar37 | uVar23 & 0xfffffff0;
        plVar14 = *(longlong **)(&stack0x00000028 + lVar11);
        uVar26 = *(ushort *)((longlong)&uStackX_18 + lVar11 + 2);
        plVar39 = *(longlong **)(&stack0x00000048 + lVar11);
        puVar29 = *(undefined **)(&stack0x00000060 + lVar11);
      }
    }
    *(undefined **)(&stack0xffffffffffffffe8 + lVar32 + lVar11) = &stack0x00000070 + lVar11;
    *(undefined **)(&stack0xffffffffffffffe0 + lVar32 + lVar11) = puVar29;
    uVar6 = *(undefined4 *)(&stack0x0000003c + lVar11);
    uVar7 = *(undefined4 *)((longlong)&uStackX_c + lVar11);
    *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100d46;
    func_0x(psVar36,uVar7,uVar7,uVar6);
    uVar23 = (uint)**(byte **)(param_4 + 4);
    psVar3 = param_4 + 1;
    if (((uVar23 & 0x1c) - 0x10 & 0xfffffffb) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100d6a;
      uVar15 = func_0x(psVar3);
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100d75;
      func_0x(psVar36,uVar15);
      uVar23 = (uint)**(byte **)(param_4 + 4);
    }
    if ((uVar23 & 2) != 0) {
      if (*(int *)(param_4 + 2) == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100d96;
        func_0x(psVar3);
      }
      *(undefined4 *)plVar2 = 0;
      *(undefined2 *)((longlong)&uStackX_24 + lVar11 + -0x20) = 0;
      uVar26 = 0;
      *(undefined2 *)((longlong)&uStackX_24 + lVar11 + -0x1e) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100daf;
      func_0x(psVar3);
      if (((**(byte **)(param_4 + 4) & 2) != 0) &&
         (puVar16 = (undefined8 *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 0x18)),
         puVar16 != (undefined8 *)0x0)) {
        uVar15 = *puVar16;
        *(int *)plVar2 = (int)uVar15;
        uVar18 = (ushort)((ulonglong)uVar15 >> 0x20);
        *(ushort *)((longlong)&uStackX_24 + lVar11 + -0x20) = uVar18;
        uVar26 = (ushort)((ulonglong)uVar15 >> 0x30);
        *(ushort *)((longlong)&uStackX_24 + lVar11 + -0x1e) = uVar26;
      }
      if (*(int *)(param_4 + 2) == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100dec;
        func_0x(psVar3);
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100df4;
      func_0x(psVar3);
      if (((**(byte **)(param_4 + 4) & 2) == 0) ||
         (pbVar22 = *(byte **)(param_4 + 4) + *(uint *)(param_4 + 0x18), pbVar22 == (byte *)0x0)) {
        *(undefined4 *)(&stack0x00000034 + lVar11) = 0;
        *(undefined2 *)(&stack0x00000038 + lVar11) = 0;
      }
      else {
        *(undefined4 *)(&stack0x00000034 + lVar11) = *(undefined4 *)(pbVar22 + 8);
        *(undefined2 *)(&stack0x00000038 + lVar11) = *(undefined2 *)(pbVar22 + 0xc);
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100e2b;
      func_0x(psVar36,&stack0x00000034 + lVar11);
      uVar25 = uVar26;
      if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
        uVar25 = uVar26 & 0xdfff;
        if ((uVar26 >> 0xe & 1) != 0) {
          uVar25 = uVar26 | 0x2000;
        }
      }
      if ((uVar25 == 0xfffc) && (0x1f < uVar18)) {
        pbVar22 = *(byte **)(param_4 + 4);
        if ((*pbVar22 & 2) != 0) {
          if (*(int *)(param_4 + 2) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100e84;
            func_0x(psVar3);
            pbVar22 = *(byte **)(param_4 + 4);
          }
          plVar28 = (longlong *)(pbVar22 + (ulonglong)*(uint *)(param_4 + 0x18) + 0xe);
        }
        if (*(int *)(param_1 + 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100ea9;
          func_0x(psVar36);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100eb1;
        func_0x(psVar36);
        pbVar22 = *(byte **)(param_1 + 4);
        if ((*pbVar22 & 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100ede;
          func_0x(0,plVar2,plVar28);
        }
        else {
          uVar23 = *(uint *)(param_1 + 0x18);
          *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100ecd;
          func_0x(pbVar22 + uVar23,plVar2,plVar28);
        }
      }
      else {
        if (*(int *)(param_1 + 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100eef;
          func_0x(psVar36);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100ef7;
        func_0x(psVar36);
        if ((**(byte **)(param_1 + 4) & 2) != 0) {
          plVar28 = (longlong *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 0x18));
        }
        *plVar28 = *plVar2;
      }
      *(undefined4 *)(param_1 + 2) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100f1f;
      func_0x(psVar36);
    }
    if (((**(byte **)(param_4 + 4) & 0x1c) - 4 & 0xffffffe7) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100f3d;
      func_0x(psVar36);
    }
    if (*(int *)(&stack0x00000040 + lVar11) != 0) {
      *(undefined8 *)(*(longlong *)(&stack0x00000068 + lVar11) + 8) = 0;
    }
    puVar29 = &stack0xffffffffffffffc0 + lVar32 + lVar11;
    if (*(short *)(&stack0x000000b2 + lVar11) != 0) {
      uVar15 = *(undefined8 *)(&stack0x000000b8 + lVar11);
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100f62;
      (*_DAT_)(uVar15);
      uVar15 = *(undefined8 *)(&stack0x000000c0 + lVar11);
      *(undefined8 *)((longlong)&uStack_48 + lVar32 + lVar11) = 0x100f6f;
      (*_DAT_)(uVar15);
      puVar29 = &stack0xffffffffffffffc0 + lVar32 + lVar11;
    }
    goto LAB_;
  }
  sVar4 = *param_4;
  *param_1 = sVar4;
  if (sVar4 == 0) {
    iVar10 = 0;
    if (*(int *)(param_4 + 2) == 0) {
      param_4[1] = 0;
      uVar23 = *(uint *)(param_4 + 8);
      uVar20 = (ulonglong)uVar23;
      *(uint *)(param_4 + 10) = uVar23;
      pbVar22 = *(byte **)(param_4 + 4);
      bVar9 = *pbVar22;
      if ((bVar9 & 0x10) != 0) {
        uVar23 = uVar23 + 2 + (*(ushort *)(pbVar22 + uVar20) + 7 >> 3);
        uVar20 = (ulonglong)uVar23;
        *(uint *)(param_4 + 10) = uVar23;
        bVar9 = *pbVar22;
      }
      if ((bVar9 & 0x20) == 0) {
        *(int *)(param_4 + 2) = (int)uVar20;
        param_4[0xe] = 0;
        *(int *)(param_4 + 0xc) = (int)uVar20;
      }
      else {
        puVar38 = (ushort *)(pbVar22 + uVar20);
        uVar18 = *puVar38;
        param_4[0xe] = uVar18;
        if (uVar18 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar32 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar32 != 0)) &&
             ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
              (*(char *)(lVar32 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10016e;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100192;
              (*_DAT_)(1,0x9f4948,0xb14618,0x80f);
            }
          }
          uVar15 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1001a1;
          func_0x(uVar15,3);
          uVar18 = param_4[0xe];
          uVar20 = (ulonglong)*(uint *)(param_4 + 10);
        }
        uVar23 = (int)uVar20 + (uVar18 + 1) * 2;
        *(uint *)(param_4 + 0xc) = uVar23;
        if (0x1f9e < uVar23) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar32 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar32 != 0 &&
              ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
               (*(char *)(lVar32 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100250;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100274;
              (*_DAT_)(1,0x9f4948,0xb14618,0x816);
            }
          }
          uVar15 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100283;
          func_0x(uVar15,4);
          uVar18 = param_4[0xe];
          uVar23 = *(uint *)(param_4 + 0xc);
        }
        uVar24 = puVar38[uVar18] & 0x7fff;
        *(uint *)(param_4 + 2) = uVar24;
        if (uVar24 < uVar23) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar32 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar32 != 0)) &&
             ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
              (*(char *)(lVar32 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100328;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10034e;
              (*_DAT_)(1,0x9f4948,0xb14618,0x81d);
            }
          }
          uVar15 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10035d;
          func_0x(uVar15,4);
          uVar18 = param_4[0xe];
          uVar24 = *(uint *)(param_4 + 2);
        }
        if ((short)puVar38[(ulonglong)(uVar18 - 1) + 1] < 0) {
          do {
            lVar32 = *(longlong *)(param_4 + 4);
            if (uVar18 == 1) {
              uVar23 = *(uint *)(param_4 + 0xc);
              uVar24 = uVar23;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(param_4 + 10) + lVar32 + (ulonglong)uVar18 * 2)
                  & 0x7fff) < uVar23) goto LAB_;
            }
            else {
              uVar23 = *(ushort *)
                        ((ulonglong)*(uint *)(param_4 + 10) + lVar32 + -2 + (ulonglong)uVar18 * 2) &
                       0x7fff;
              uVar24 = *(uint *)(param_4 + 0xc);
              if (uVar24 <= uVar23) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1003d9;
              func_0x(lVar32,7);
              uVar24 = *(uint *)(param_4 + 0xc);
              lVar32 = *(longlong *)(param_4 + 4);
              uVar18 = param_4[0xe];
            }
            if ((uVar23 < uVar24) || (uVar24 = *(uint *)(param_4 + 2), uVar24 < uVar23)) {
              param_3 = (ulonglong)*(uint *)((longlong)&uStackX_c + lVar11);
              param_2 = *plVar2;
              goto LAB_;
            }
            if (*(ushort *)(lVar32 + (ulonglong)uVar23) == 5) {
              param_4[1] = param_4[1] | 2;
              param_4[0xe] = uVar18 - 1;
              param_4[0x15] = (short)uVar23;
              lVar32 = (ulonglong)(uVar23 & 0xffff) + *(longlong *)(param_4 + 4);
              uVar18 = param_4[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar32 + 2) & 0x4000) != 0) {
                uVar18 = *(ushort *)(lVar32 + 2) & 0x3800 | param_4[0x16] & 0xc7ffU;
              }
              param_4[0x16] = uVar18;
              param_4[0x16] = (uVar18 ^ *(ushort *)(lVar32 + 2)) & 0x7ff ^ uVar18;
              uVar20 = (ulonglong)*(uint *)(param_4 + 2);
              pbVar22 = *(byte **)(param_4 + 4);
              goto LAB_;
            }
            if (*(ushort *)(lVar32 + (ulonglong)uVar23) < 0x400) break;
            param_4[1] = param_4[1] | 1;
            uVar18 = uVar18 - 1;
            param_4[0xe] = uVar18;
            if ((uVar18 == 0) || (-1 < (short)puVar38[(ulonglong)(uVar18 - 1) + 1])) break;
          } while( true );
        }
        uVar20 = (ulonglong)uVar24;
        pbVar22 = *(byte **)(param_4 + 4);
      }
LAB_:
      if ((*pbVar22 & 0x40) == 0) {
        *(undefined4 *)(param_4 + 0x13) = 0;
      }
      else {
        *(int *)(param_4 + 0x13) = (int)uVar20;
        *(int *)(param_4 + 2) = (int)uVar20 + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100503;
        puVar12 = (ulonglong *)func_0x(param_4 + 1);
        uVar20 = *puVar12;
        uVar26 = (ushort)(uVar20 >> 0x30);
        uVar18 = uVar26;
        if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
          uVar18 = uVar26 & 0xdfff;
          if ((uVar20 & 0x4000000000000000) != 0) {
            uVar18 = uVar26 | 0x2000;
          }
        }
        if (uVar18 == 0xfffc) {
          iVar10 = (int)((uVar20 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + iVar10;
        uVar20 = (ulonglong)*(uint *)(param_4 + 2);
        pbVar22 = *(byte **)(param_4 + 4);
      }
      iVar10 = (int)uVar20;
      if ((*(byte **)(param_4 + 0xf) != (byte *)0x0) &&
         (*(byte **)(param_4 + 0xf) < pbVar22 + uVar20)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar32 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar32 != 0 &&
             (lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0)) &&
            (*(char *)(lVar32 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100609;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10062f;
            (*_DAT_)(1,0x9f4948,0xb14618,0x877);
          }
        }
        uVar15 = *(undefined8 *)(param_4 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10063e;
        func_0x(uVar15,0x12);
        iVar10 = *(int *)(param_4 + 2);
      }
      if (0x3f3b < iVar10 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar32 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar32 != 0 &&
            ((lVar32 = *(longlong *)(lVar32 + 0x60), lVar32 != 0 &&
             (*(char *)(lVar32 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1006cd;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1006f3;
            (*_DAT_)(1,0x9f4948,0xb14618,0x87c);
          }
        }
        uVar15 = *(undefined8 *)(param_4 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100702;
        func_0x(uVar15,5);
      }
      param_2 = *plVar2;
      param_3 = (ulonglong)*(uint *)((longlong)&uStackX_c + lVar11);
    }
LAB_:
    uVar23 = *(uint *)(param_4 + 2);
    if ((uVar23 < 9) &&
       (((**(byte **)(param_4 + 4) & 0xe) == 0 || ((**(byte **)(param_4 + 4) & 0xe) == 0xc)))) {
      uVar23 = 9;
    }
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_4 + 8);
    param_1[1] = param_4[1];
    *(undefined4 *)(param_1 + 2) = *(undefined4 *)(param_4 + 2);
    param_1[0xe] = param_4[0xe];
    *(undefined4 *)(param_1 + 10) = *(undefined4 *)(param_4 + 10);
    *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_4 + 0xc);
    *(undefined4 *)(param_1 + 0x13) = *(undefined4 *)(param_4 + 0x13);
    uVar15 = *(undefined8 *)(param_4 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100791;
    func_0x(param_2,param_3 & 0xffffffff,uVar15,uVar23);
    *(longlong *)(param_1 + 4) = *plVar2;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1007a2;
    iVar10 = func_0x(param_1 + 1);
    if (iVar10 != 0) {
      lVar32 = *(longlong *)(param_1 + 4);
      puVar38 = (ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar32);
      uVar23 = *puVar38 - 1;
      if ((*(byte *)(param_1 + 1) & 1) == 0) {
        uVar23 = (uint)*puVar38;
      }
      if (uVar23 == 1) {
        uVar24 = *(uint *)(param_1 + 0xc);
LAB_:
        if ((puVar38[(int)uVar23] & 0x7fff) < uVar24) goto LAB_;
      }
      else {
        uVar24 = puVar38[(longlong)(int)uVar23 + -1] & 0x7fff;
        if (*(uint *)(param_1 + 0xc) <= uVar24) goto LAB_;
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1007fc;
        func_0x(lVar32,7);
      }
      param_1[0x15] = (short)uVar24;
      lVar32 = (ulonglong)(uVar24 & 0xffff) + *(longlong *)(param_1 + 4);
      uVar18 = param_1[0x16] & 0xc7ffU;
      if ((*(ushort *)(lVar32 + 2) >> 0xe & 1) != 0) {
        uVar18 = *(ushort *)(lVar32 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
      }
      param_1[0x16] = uVar18;
      param_1[0x16] = (uVar18 ^ *(ushort *)(lVar32 + 2)) & 0x7ff ^ uVar18;
      *(undefined8 *)(param_1 + 8) = 0;
      puVar29 = &stack0xffffffffffffffc0 + lVar11;
      goto LAB_;
    }
  }
  else {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100862;
    func_0x(param_1 + 1);
  }
  *(undefined8 *)(param_1 + 8) = 0;
  puVar29 = &stack0xffffffffffffffc0 + lVar11;
LAB_:
  uVar20 = *(ulonglong *)(&stack0x00002a90 + lVar11);
  *(undefined8 *)(puVar29 + -8) = 0x100f7e;
  func_0x(uVar20 ^ (ulonglong)plVar2);
  return;
}

