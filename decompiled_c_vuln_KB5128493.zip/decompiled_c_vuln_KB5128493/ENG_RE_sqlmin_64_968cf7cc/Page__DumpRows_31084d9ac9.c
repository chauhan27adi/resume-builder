
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  short *psVar1;
  longlong lVar2;
  ulonglong uVar3;
  uint *puVar4;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar5;
  int iVar6;
  ulonglong uVar7;
  longlong unaff_GS_OFFSET;
  undefined auStack_6c8 [32];
  undefined8 uStack_6a8;
  undefined8 uStack_6a0;
  ushort uStack_680;
  undefined auStack_67e [2];
  undefined4 uStack_67c;
  byte *pbStack_678;
  undefined8 uStack_670;
  undefined8 uStack_662;
  undefined2 uStack_65a;
  undefined2 uStack_658;
  undefined6 uStack_656;
  undefined2 uStack_648;
  undefined4 uStack_644;
  byte *pbStack_640;
  undefined8 uStack_638;
  undefined8 uStack_62a;
  undefined2 uStack_622;
  undefined2 uStack_620;
  undefined6 uStack_61e;
  int iStack_60c;
  uint uStack_5f8;
  byte *pbStack_5f0;
  undefined4 uStack_5e8;
  longlong lStack_5d0;
  longlong lStack_5c0;
  longlong lStack_5b8;
  longlong lStack_5a8;
  undefined8 uStack_568;
  longlong lStack_560;
  byte *pbStack_4f8;
  undefined *puStack_4f0;
  undefined8 uStack_4d0;
  undefined8 uStack_488;
  undefined *puStack_480;
  undefined auStack_478 [1088];
  ulonglong uStack_38;
  
  uStack_4d0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_6c8;
  uVar3 = 0;
  pbStack_5f0 = (byte *)0x0;
  lStack_5d0 = param_2;
  lStack_5c0 = param_1;
  lStack_5b8 = param_2;
  lStack_5a8 = param_1;
  lStack_560 = param_1;
  if (param_2 != 0) {
    if ((ulonglong)*(ushort *)(param_1 + 0x16) != 0) {
      psVar1 = (short *)(param_1 + 0x1ffe);
      uVar7 = uVar3;
      do {
        iVar6 = (int)uVar7;
        if (*psVar1 != 0) goto LAB_;
        uVar7 = (ulonglong)(iVar6 + 1);
        uVar3 = uVar3 + 1;
        psVar1 = psVar1 + -1;
      } while ((longlong)uVar3 < (longlong)(ulonglong)*(ushort *)(param_1 + 0x16));
    }
    iVar6 = -1;
LAB_:
    lVar5 = -0x140ec00;
    iStack_60c = iVar6;
    if (iVar6 != -1) {
      uStack_5e8 = 0;
      lVar2 = func_0x();
      if (lVar2 != 0) {
        lVar2 = func_0x();
        puVar4 = (uint *)(lVar2 + 0x18);
        if (lVar2 == 0) {
          puVar4 = (uint *)0x4;
        }
        if ((*puVar4 >> 1 & 1) != 0) {
          pbStack_640 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)iVar6) * 2) +
                                param_1);
          uStack_644 = 0;
          uStack_62a = 0;
          uStack_620 = 0;
          uStack_61e = 0;
          uStack_638 = 0;
          pbStack_5f0 = pbStack_640;
          if ((*pbStack_640 & 1) == 0) {
            uStack_648 = 0;
            uStack_622 = 0;
            uStack_620 = 0;
                    /* WARNING: Could not recover jumptable at 0x001003a9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)
                       *(uint *)(lVar5 + 0x1510770 + (longlong)(int)(*pbStack_640 & 0xe) * 4) +
                      lVar5))();
            return;
          }
          uStack_648 = 1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)(lVar5 + 0x1510740 +
                                 (ulonglong)
                                 *(byte *)(lVar5 + 0x1510750 + (longlong)(int)(*pbStack_640 & 0x1c))
                                 * 4) + lVar5);
                    /* WARNING: Could not recover jumptable at 0x001001a4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
      }
      uStack_6a0 = 0;
      uStack_6a8 = _DAT_;
      func_0x(auStack_478,0,0,0);
      uStack_488 = _DAT_;
      lVar2 = (ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar5 = *(longlong *)(lVar2 + 0x100);
      if (lVar5 == 0) {
        (*_DAT_)(0);
        lVar5 = *(longlong *)(lVar2 + 0x100);
      }
      uStack_568 = *(undefined8 *)(lVar5 + 0xc88);
      *(undefined8 *)(lVar5 + 0xc88) = _DAT_;
      pbStack_678 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)iVar6) * 2) +
                            param_1);
      uStack_67c = 0;
      uStack_662 = 0;
      uStack_658 = 0;
      uStack_656 = 0;
      uStack_670 = 0;
      uStack_680 = (ushort)(*pbStack_678 & 1);
      puStack_4f0 = auStack_67e;
      pbStack_5f0 = pbStack_678;
      if ((*pbStack_678 & 1) != 0) {
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_678 & 0x1c) + 0x101bf8) * 4 +
                               0x101be8) - 0x140ec00);
                    /* WARNING: Could not emulate address calculation at 0x00100d33 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      uStack_5f8 = (uint)*(ushort *)(param_1 + 0xe);
      uStack_67c = 0;
      uStack_65a = 0;
      uStack_658 = 0;
      pbStack_4f8 = pbStack_678;
      puStack_480 = puStack_4f0;
                    /* WARNING: Could not emulate address calculation at 0x00100c8a */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_678 & 0xe) * 4 + 0x101bac) -
                0x140ec00))();
      return;
    }
    (*_DAT_)(param_2);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_6c8);
  return;
}

