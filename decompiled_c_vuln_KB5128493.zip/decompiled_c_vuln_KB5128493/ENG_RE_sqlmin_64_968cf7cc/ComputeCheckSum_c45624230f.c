
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4)

{
  ushort *puVar1;
  short *psVar2;
  uint *puVar3;
  byte bVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  bool bVar8;
  int iVar9;
  int iVar10;
  longlong lVar11;
  ulonglong *puVar12;
  ushort uVar13;
  ulonglong uVar14;
  ushort uVar15;
  uint uVar16;
  ulonglong uVar17;
  undefined8 unaff_RBX;
  uint *puVar18;
  undefined *puVar19;
  uint uVar20;
  uint uVar21;
  short *psVar22;
  uint *puVar23;
  uint *puVar24;
  short sVar25;
  uint uVar26;
  uint *puVar27;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  uint *puStackX_10;
  short sStackX_18;
  ushort uStackX_1a;
  uint uStackX_1c;
  uint *puStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  puVar19 = &stack0xffffffffffffffc8 + lVar11;
  puVar3 = (uint *)((longlong)auStackX_8 + lVar11);
  *(undefined8 *)(&stack0x000000b8 + lVar11) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000041a0 + lVar11) = unaff_RBX;
  *(ulonglong *)(&stack0x00004138 + lVar11) = _DAT_ ^ (ulonglong)puVar3;
  *(undefined4 *)(&stack0x00000060 + lVar11) = param_4;
  *(undefined8 *)(&stack0x00000080 + lVar11) = param_2;
  *(undefined2 *)((longlong)&sStackX_18 + lVar11) = 0xffff;
  *(undefined8 *)((longlong)&puStackX_20 + lVar11) = 0;
  *(undefined4 *)((longlong)&sStackX_18 + lVar11 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar11) = 0;
  *puVar3 = 0;
  *(undefined8 *)(&stack0x00000068 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000058 + lVar11) = 0;
  lVar5 = *(longlong *)(param_1 + 8);
  uVar17 = 0x1f9e;
  if (*(int *)(lVar5 + 0x100) == 2) {
    if ((*(byte *)(lVar5 + 0x42) & 4) == 0) {
      uVar16 = *(uint *)(lVar5 + 0xb0);
      if (0x1f9e < uVar16) {
        uVar16 = 0x1f9e;
      }
    }
    else {
      uVar16 = 0x1f9e;
    }
    *(uint *)(&stack0x00000058 + lVar11) = uVar16;
    uVar14 = (ulonglong)uVar16 + 0xf;
    if (uVar14 <= uVar16) {
      uVar14 = 0xffffffffffffff0;
    }
    uVar14 = uVar14 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000cc;
    func_0x();
    puVar19 = &stack0xffffffffffffffc8 + -uVar14 + lVar11;
    *(ulonglong *)(&stack0x00000068 + lVar11) = (longlong)auStackX_8 + -uVar14 + lVar11;
  }
  *(undefined4 *)(puVar19 + 0x20) = 1;
  *(undefined8 *)(puVar19 + -8) = 0x1000f6;
  func_0x(param_3,&stack0x00002198 + lVar11,uVar17 & 0xffffffff,
                  (longlong)&sStackX_18 + lVar11);
  *(longlong *)(&stack0x00000088 + lVar11) = param_1;
  *(undefined4 *)(&stack0x00000090 + lVar11) = 9;
  *(undefined8 *)(&stack0x000000a0 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000098 + lVar11) = 0;
  *(undefined4 *)(&stack0x000000b0 + lVar11) = 0;
  plVar6 = *(longlong **)(*(longlong *)(param_1 + 8) + 0x160);
  *(longlong *)(&stack0x000000a8 + lVar11) = (longlong)&sStackX_18 + lVar11;
  lVar5 = *plVar6;
  *(int *)(&stack0x00000094 + lVar11) = *(int *)(lVar5 + 0x10) - *(int *)(lVar5 + 0x18);
  *(undefined8 *)(puVar19 + -8) = 0x100151;
  iVar9 = func_0x(&stack0x00000088 + lVar11,(longlong)&puStackX_10 + lVar11);
  do {
    if (iVar9 == 0) {
      uVar17 = *(ulonglong *)(&stack0x00004138 + lVar11);
      *(undefined8 *)(puVar19 + -8) = 0x100da2;
      func_0x(uVar17 ^ (ulonglong)puVar3);
      return;
    }
    puVar27 = *(uint **)((longlong)&puStackX_10 + lVar11);
    puVar24 = puVar27 + 1;
    uVar15 = *(ushort *)puVar24;
    *(ushort *)(&stack0x00000054 + lVar11) = uVar15;
    bVar4 = *(byte *)(puVar27 + 8);
    puVar23 = puVar27 + 0xe;
    *(uint **)(&stack0x00000078 + lVar11) = puVar23;
    if (*(short *)((longlong)&sStackX_18 + lVar11) == 0) {
      uVar16 = *puVar27;
      if ((uVar16 & 0xc0000000) == 0x80000000) {
        *(undefined8 *)(puVar19 + -8) = 0x100a43;
        iVar9 = func_0x((longlong)&sStackX_18 + lVar11 + 2);
        if (iVar9 == 0) {
LAB_:
          puVar18 = (uint *)0x0;
          *puVar3 = 0;
        }
        else {
          *(undefined8 *)(puVar19 + -8) = 0x100a5b;
          puVar18 = (uint *)func_0x(&stack0x00000042 + lVar11,puVar27,puVar3,
                                            &stack0x00000070 + lVar11);
        }
      }
      else {
        uVar21 = *(uint *)(&stack0x00000028 + lVar11);
        uVar17 = (ulonglong)uVar21;
        puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
        if (((bVar4 & 2) != 0) || ((*(byte *)((longlong)puVar27 + 6) & 0x10) != 0)) {
          if ((*(byte *)puVar18 & 0x10) == 0) {
            if ((1 << (*(byte *)puVar18 & 0xe) & 0x1105U) == 0) {
              uVar13 = 0;
              bVar8 = true;
            }
            else {
LAB_:
              uVar13 = ~(*(ushort *)((longlong)puVar27 + 6) >> 4) & 1;
              bVar8 = false;
            }
            if ((bVar4 & 2) != 0) goto LAB_;
          }
          else {
            if (((int)uVar21 <= (int)uVar16) || (*(ushort *)((longlong)puVar18 + uVar17) < uVar15))
            goto LAB_;
            if ((bVar4 & 2) == 0) goto LAB_;
            uVar13 = *(byte *)((longlong)puVar18 + uVar17 + (ulonglong)(uVar15 - 1 >> 3) + 2) >>
                     ((byte)(uVar15 - 1) & 7) & 1;
            bVar8 = true;
LAB_:
            if (uVar13 != 0) {
              *puVar3 = 0;
              puVar18 = (uint *)0x0;
              puVar23 = *(uint **)(&stack0x00000078 + lVar11);
              goto LAB_;
            }
          }
          if ((!bVar8) && ((*(byte *)((longlong)puVar27 + 6) & 0x10) != 0)) {
            puVar18 = *(uint **)(puVar27 + 2) + 1;
            *puVar3 = **(uint **)(puVar27 + 2);
            puVar23 = *(uint **)(&stack0x00000078 + lVar11);
            goto LAB_;
          }
        }
LAB_:
        uVar20 = (uint)*(ushort *)puVar23;
        if ((int)uVar16 < 0) {
          uVar16 = 0;
          if (*(int *)((longlong)&sStackX_18 + lVar11 + 4) == 0) {
            *(undefined2 *)((longlong)&sStackX_18 + lVar11 + 2) = 0;
            *(uint *)(&stack0x0000002c + lVar11) = uVar21;
            if ((*(byte *)puVar18 & 0x10) != 0) {
              *(uint *)(&stack0x0000002c + lVar11) =
                   uVar21 + 2 + (*(ushort *)(uVar17 + (longlong)puVar18) + 7 >> 3);
            }
            if ((*(byte *)puVar18 & 0x20) == 0) {
              uVar26 = *(uint *)(&stack0x0000002c + lVar11);
              *(uint *)((longlong)&sStackX_18 + lVar11 + 4) = uVar26;
              *(undefined2 *)(&stack0x00000034 + lVar11) = 0;
              *(uint *)(&stack0x00000030 + lVar11) = uVar26;
              uVar20 = uVar26;
            }
            else {
              psVar22 = (short *)((ulonglong)*(uint *)(&stack0x0000002c + lVar11) +
                                 (longlong)puVar18);
              sVar25 = *psVar22;
              *(short *)(&stack0x00000034 + lVar11) = sVar25;
              if (sVar25 == 0) {
                if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                  lVar5 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8);
                  if ((lVar5 != 0) &&
                     ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                      (*(char *)(lVar5 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar19 + -8) = 0x100411;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar19 + 0x20) = 0;
                      *(undefined8 *)(puVar19 + -8) = 0x100437;
                      (*_DAT_)(1,0x1834148,0x1953e18,0x80f);
                    }
                  }
                  puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
                  puVar27 = *(uint **)((longlong)&puStackX_10 + lVar11);
                }
                *(undefined8 *)(puVar19 + -8) = 0x100449;
                func_0x(puVar18,3);
                puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
              }
              uVar20 = *(int *)(&stack0x0000002c + lVar11) +
                       (*(ushort *)(&stack0x00000034 + lVar11) + 1) * 2;
              *(uint *)(&stack0x00000030 + lVar11) = uVar20;
              if (0x1f9e < uVar20) {
                if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                  lVar5 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8);
                  if ((lVar5 != 0) &&
                     ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                      (*(char *)(lVar5 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar19 + -8) = 0x1004e2;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar19 + 0x20) = 0;
                      *(undefined8 *)(puVar19 + -8) = 0x100508;
                      (*_DAT_)(1,0x1834148,0x1953e18,0x816);
                    }
                  }
                  puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
                  puVar27 = *(uint **)((longlong)&puStackX_10 + lVar11);
                }
                *(undefined8 *)(puVar19 + -8) = 0x10051d;
                func_0x(puVar18,4);
                uVar20 = *(uint *)(&stack0x00000030 + lVar11);
                puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
              }
              uVar26 = (ushort)psVar22[*(ushort *)(&stack0x00000034 + lVar11)] & 0x7fff;
              *(uint *)((longlong)&sStackX_18 + lVar11 + 4) = uVar26;
              if (uVar26 < uVar20) {
                if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                  lVar5 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8);
                  if ((lVar5 != 0) &&
                     ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                      (*(char *)(lVar5 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar19 + -8) = 0x1005bb;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar19 + 0x20) = 0;
                      *(undefined8 *)(puVar19 + -8) = 0x1005e1;
                      (*_DAT_)(1,0x1834148,0x1953e18,0x81d);
                    }
                  }
                  puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
                  puVar27 = *(uint **)((longlong)&puStackX_10 + lVar11);
                }
                *(undefined8 *)(puVar19 + -8) = 0x1005f6;
                func_0x(puVar18,4);
                uVar20 = *(uint *)(&stack0x00000030 + lVar11);
                puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
                uVar26 = *(uint *)((longlong)&sStackX_18 + lVar11 + 4);
              }
              do {
                uVar15 = *(ushort *)(&stack0x00000034 + lVar11);
                if (-1 < psVar22[(ulonglong)(uVar15 - 1) + 1]) break;
                uVar21 = uVar20;
                if (uVar15 != 1) {
                  uVar21 = *(ushort *)
                            ((longlong)puVar18 +
                            (ulonglong)uVar15 * 2 +
                            ((ulonglong)*(uint *)(&stack0x0000002c + lVar11) - 2)) & 0x7fff;
                }
                if ((uVar21 < uVar20) ||
                   ((*(ushort *)
                      ((longlong)puVar18 +
                      (ulonglong)uVar15 * 2 + (ulonglong)*(uint *)(&stack0x0000002c + lVar11)) &
                    0x7fff) < uVar21)) {
                  *(undefined8 *)(puVar19 + -8) = 0x100653;
                  func_0x(puVar18,7);
                  uVar20 = *(uint *)(&stack0x00000030 + lVar11);
                  puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
                  uVar26 = *(uint *)((longlong)&sStackX_18 + lVar11 + 4);
                }
                if ((uVar21 < uVar20) || (uVar26 < uVar21)) {
                  uVar21 = *(uint *)(&stack0x00000028 + lVar11);
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar21 + (longlong)puVar18) == 5) {
                  puVar1 = (ushort *)((longlong)&sStackX_18 + lVar11 + 2);
                  *puVar1 = *puVar1 | 2;
                  *(short *)(&stack0x00000034 + lVar11) = *(short *)(&stack0x00000034 + lVar11) + -1
                  ;
                  *(short *)(&stack0x00000042 + lVar11) = (short)uVar21;
                  uVar15 = *(ushort *)((ulonglong)(uVar21 & 0xffff) + 2 + (longlong)puVar18);
                  uVar13 = *(ushort *)(&stack0x00000044 + lVar11);
                  if ((uVar15 & 0x4000) == 0) {
                    uVar13 = uVar13 & 0xc7ff;
                  }
                  else {
                    uVar13 = uVar13 ^ (uVar15 ^ uVar13) & 0x3800;
                  }
                  *(ushort *)(&stack0x00000044 + lVar11) = uVar13;
                  *(ushort *)(&stack0x00000044 + lVar11) =
                       uVar13 ^ (uVar13 ^ *(ushort *)
                                           ((ulonglong)(uVar21 & 0xffff) + 2 + (longlong)puVar18)) &
                                0x7ff;
                  uVar21 = *(uint *)(&stack0x00000028 + lVar11);
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar21 + (longlong)puVar18) < 0x400) break;
                puVar1 = (ushort *)((longlong)&sStackX_18 + lVar11 + 2);
                *puVar1 = *puVar1 | 1;
                psVar2 = (short *)(&stack0x00000034 + lVar11);
                *psVar2 = *psVar2 + -1;
              } while (*psVar2 != 0);
              uVar21 = *(uint *)(&stack0x00000028 + lVar11);
            }
LAB_:
            if ((*(byte *)puVar18 & 0x40) == 0) {
              *(undefined4 *)(&stack0x0000003e + lVar11) = 0;
            }
            else {
              *(uint *)(&stack0x0000003e + lVar11) = uVar26;
              *(uint *)((longlong)&sStackX_18 + lVar11 + 4) = uVar26 + 0xe;
              *(undefined8 *)(puVar19 + -8) = 0x100745;
              puVar12 = (ulonglong *)func_0x((longlong)&sStackX_18 + lVar11 + 2);
              uVar17 = *puVar12;
              uVar13 = (ushort)(uVar17 >> 0x30);
              uVar15 = uVar13;
              if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
                uVar15 = uVar13 & 0xdfff;
                if ((uVar17 & 0x4000000000000000) != 0) {
                  uVar15 = uVar13 | 0x2000;
                }
              }
              uVar26 = uVar16;
              if (uVar15 == 0xfffc) {
                uVar26 = (uint)((uVar17 >> 0x20 & 0xffff) >> 5);
              }
              uVar26 = *(int *)((longlong)&sStackX_18 + lVar11 + 4) + uVar26;
              *(uint *)((longlong)&sStackX_18 + lVar11 + 4) = uVar26;
              uVar20 = *(uint *)(&stack0x00000030 + lVar11);
              uVar21 = *(uint *)(&stack0x00000028 + lVar11);
              puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
            }
            if ((*(byte **)(&stack0x00000036 + lVar11) != (byte *)0x0) &&
               (*(byte **)(&stack0x00000036 + lVar11) <
                (byte *)((ulonglong)uVar26 + (longlong)puVar18))) {
              if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                lVar5 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8);
                if (((lVar5 != 0) && (lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0)) &&
                   (*(char *)(lVar5 + 0x499) != '\0')) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar19 + -8) = 0x100848;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar19 + 0x20) = 0;
                    *(undefined8 *)(puVar19 + -8) = 0x10086e;
                    (*_DAT_)(1,0x1834148,0x1953e18,0x877);
                  }
                }
                puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
                puVar27 = *(uint **)((longlong)&puStackX_10 + lVar11);
              }
              *(undefined8 *)(puVar19 + -8) = 0x100883;
              func_0x(puVar18,0x12);
              uVar20 = *(uint *)(&stack0x00000030 + lVar11);
              uVar21 = *(uint *)(&stack0x00000028 + lVar11);
              puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
              uVar26 = *(uint *)((longlong)&sStackX_18 + lVar11 + 4);
            }
            if (0x3f3b < uVar26 - 1) {
              if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                lVar5 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8);
                if ((lVar5 != 0) &&
                   ((lVar5 = *(longlong *)(lVar5 + 0x60), lVar5 != 0 &&
                    (*(char *)(lVar5 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar19 + -8) = 0x10091b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar19 + 0x20) = 0;
                    *(undefined8 *)(puVar19 + -8) = 0x100941;
                    (*_DAT_)(1,0x1834148,0x1953e18,0x87c);
                  }
                }
                puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
                puVar27 = *(uint **)((longlong)&puStackX_10 + lVar11);
              }
              *(undefined8 *)(puVar19 + -8) = 0x100956;
              func_0x(puVar18,5);
              uVar21 = *(uint *)(&stack0x00000028 + lVar11);
              puVar18 = *(uint **)((longlong)&puStackX_20 + lVar11);
              goto LAB_;
            }
          }
          else {
LAB_:
            uVar20 = *(uint *)(&stack0x00000030 + lVar11);
          }
LAB_:
          sVar25 = -*(short *)puVar27;
          if ((*(byte *)((longlong)puVar27 + 6) & 0x10) != 0) {
            if ((*(byte *)puVar18 & 0x10) == 0) {
              if ((1 << (*(byte *)puVar18 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar18 = *(uint **)(puVar27 + 2) + 1;
                *puVar3 = **(uint **)(puVar27 + 2);
                puVar23 = *(uint **)(&stack0x00000078 + lVar11);
                goto LAB_;
              }
            }
            else if (((int)uVar21 <= (int)*puVar27) ||
                    (*(ushort *)((ulonglong)uVar21 + (longlong)puVar18) < *(ushort *)puVar24))
            goto LAB_;
          }
          if ((uint)(int)sVar25 <= (uint)*(ushort *)(&stack0x00000034 + lVar11)) {
            puVar24 = puVar18;
            uVar16 = uVar20;
            if (sVar25 != 1) {
              uVar20 = *(uint *)(&stack0x00000030 + lVar11);
              puVar27 = *(uint **)((longlong)&puStackX_10 + lVar11);
              puVar24 = *(uint **)((longlong)&puStackX_20 + lVar11);
              uVar16 = *(ushort *)
                        ((longlong)puVar18 +
                        (longlong)sVar25 * 2 + ((ulonglong)*(uint *)(&stack0x0000002c + lVar11) - 2)
                        ) & 0x7fff;
            }
            uVar21 = *(ushort *)
                      ((longlong)puVar18 +
                      (longlong)sVar25 * 2 + (ulonglong)*(uint *)(&stack0x0000002c + lVar11)) &
                     0x7fff;
            if ((uVar16 < uVar20) || (uVar21 < uVar16)) {
              *(undefined8 *)(puVar19 + -8) = 0x100a12;
              func_0x(puVar24,7);
              puVar24 = *(uint **)((longlong)&puStackX_20 + lVar11);
            }
            puVar18 = (uint *)((ulonglong)uVar16 + (longlong)puVar24);
            *puVar3 = uVar21 - uVar16;
            puVar23 = *(uint **)(&stack0x00000078 + lVar11);
            goto LAB_;
          }
        }
        else {
          uVar13 = *(ushort *)((longlong)puVar27 + 6);
          if ((uVar13 & 8) != 0) {
            bVar4 = *(byte *)((longlong)(int)uVar16 + (longlong)puVar18);
            *puVar3 = 1;
            puVar18 = (uint *)0x15b8b84;
            if ((bVar4 & (byte)(1 << ((byte)uVar13 & 7))) == 0) {
              puVar18 = (uint *)0x15b91a8;
            }
            puVar23 = *(uint **)(&stack0x00000078 + lVar11);
            goto LAB_;
          }
          if ((uVar13 & 0x10) == 0) {
LAB_:
            *puVar3 = uVar20;
            puVar18 = (uint *)((longlong)(int)*puVar27 + (longlong)puVar18);
            puVar23 = *(uint **)(&stack0x00000078 + lVar11);
            goto LAB_;
          }
          if ((*(byte *)puVar18 & 0x10) != 0) {
            if (((int)uVar21 <= (int)uVar16) || (*(ushort *)(uVar17 + (longlong)puVar18) < uVar15))
            goto LAB_;
            goto LAB_;
          }
          if ((1 << (*(byte *)puVar18 & 0xe) & 0x1105U) == 0) goto LAB_;
LAB_:
          puVar18 = *(uint **)(puVar27 + 2) + 1;
          uVar16 = **(uint **)(puVar27 + 2);
          if ((uVar20 != 0) && (uVar16 != uVar20)) {
            *(undefined8 *)(puVar19 + 0x20) = 0;
            *(undefined8 *)(puVar19 + -8) = 0x100301;
            (*_DAT_)(1,0x19e1eb8,0x19e08b8,0x381);
            *puVar3 = uVar16;
            puVar23 = *(uint **)(&stack0x00000078 + lVar11);
            goto LAB_;
          }
        }
        *puVar3 = uVar16;
        puVar23 = *(uint **)(&stack0x00000078 + lVar11);
      }
    }
    else {
      *(undefined4 *)(&stack0x0000005c + lVar11) = 0;
      *(undefined **)(puVar19 + 0x20) = &stack0x0000005c + lVar11;
      *(undefined8 *)(puVar19 + -8) = 0x100b56;
      puVar18 = (uint *)func_0x((longlong)&sStackX_18 + lVar11 + 2,puVar27);
      if ((((*(short *)((longlong)&sStackX_18 + lVar11) != 0) &&
           (plVar6 = *(longlong **)(&stack0x00000028 + lVar11), plVar6 != (longlong *)0x0)) &&
          (*plVar6 != 0)) &&
         (((*(byte *)((longlong)puVar27 + 6) & 8) == 0 &&
          ((*(uint *)(&stack0x0000005c + lVar11) & 1) == 0)))) {
        if ((puVar18 == (uint *)0x0) || (puVar18 == (uint *)0x15b8b84)) goto LAB_;
        *(uint *)(puVar19 + 0x38) = *(uint *)(&stack0x0000005c + lVar11);
        *(uint **)(puVar19 + 0x30) = puVar3;
        *(undefined4 *)(puVar19 + 0x28) = *(undefined4 *)(&stack0x00000058 + lVar11);
        *(undefined8 *)(puVar19 + 0x20) = *(undefined8 *)(&stack0x00000068 + lVar11);
        uVar16 = *puVar3;
        *(undefined8 *)(puVar19 + -8) = 0x100bd5;
        puVar18 = (uint *)func_0x(plVar6,puVar27,puVar18,uVar16);
      }
    }
LAB_:
    if ((puVar18 != (uint *)0x0) &&
       ((iVar9 = *(int *)(&stack0x00000060 + lVar11), iVar9 != 2 ||
        ((*(ushort *)puVar23 != 0xffff &&
         (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar27 + 0xd) + 0x15b9020) +
                   0x1f6e698) == '\0')))))) {
      *(undefined8 *)(puVar19 + -8) = 0x100aee;
      iVar10 = func_0x((longlong)&sStackX_18 + lVar11,puVar27);
      if (iVar10 == 0) {
        for (uVar16 = *puVar3; uVar16 != 0; uVar16 = uVar16 - 1) {
        }
      }
      else if ((iVar9 == 1) ||
              ((*(ushort *)puVar23 != 0xffff &&
               (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar27 + 0xd) + 0x15b9020) +
                         0x1f6e698) == '\0')))) {
        if ((*puVar3 < 0x30) || (bVar8 = true, *(short *)puVar18 != 3)) {
          bVar8 = false;
        }
        if (bVar8) {
          *(undefined8 *)(&stack0x000000e8 + lVar11) = 0;
          *(undefined8 *)(&stack0x000000c0 + lVar11) = 3;
          *(undefined4 *)(&stack0x000000c8 + lVar11) = _DAT_;
          *(undefined4 *)(&stack0x000000cc + lVar11) = uRam00000000015b8ebc;
          *(undefined4 *)(&stack0x000000d0 + lVar11) = uRam00000000015b8ec0;
          *(undefined4 *)(&stack0x000000d4 + lVar11) = uRam00000000015b8ec4;
          *(undefined2 *)(&stack0x000000e2 + lVar11) = 0x100;
          *(undefined4 *)(&stack0x000000dc + lVar11) = _DAT_;
          *(undefined2 *)(&stack0x000000e0 + lVar11) = _DAT_;
          *(undefined4 *)(&stack0x000000d8 + lVar11) = 0;
          *(undefined4 *)(&stack0x000000e4 + lVar11) = 0;
          *(undefined8 *)(puVar19 + -8) = 0x100c92;
          func_0x(&stack0x000000c0 + lVar11,0x30,puVar18);
          *(undefined4 *)(&stack0x00000050 + lVar11) = *(undefined4 *)(&stack0x000000d8 + lVar11);
        }
        else {
          *(undefined8 *)(puVar19 + -8) = 0x100cb0;
          func_0x(&stack0x000000f8 + lVar11,&stack0x00000200 + lVar11);
          *(undefined8 *)(&stack0x000000f8 + lVar11) = 0x15ce608;
          *(undefined4 *)(puVar19 + 0x28) = 0x10000;
          *(uint *)(puVar19 + 0x20) = *puVar27;
          uVar16 = *puVar3;
          uVar7 = *(undefined8 *)(&stack0x00000080 + lVar11);
          *(undefined8 *)(puVar19 + -8) = 0x100ce5;
          func_0x(&stack0x000000f8 + lVar11,uVar7,puVar18,uVar16);
          *(undefined4 *)(&stack0x00000050 + lVar11) = *(undefined4 *)(&stack0x0000012c + lVar11);
          *(undefined8 *)(puVar19 + -8) = 0x100cfa;
          func_0x(&stack0x000000f8 + lVar11);
          *(undefined8 *)(puVar19 + -8) = 0x100d07;
          func_0x(&stack0x000000f8 + lVar11);
        }
      }
    }
    *(undefined8 *)(puVar19 + -8) = 0x100d83;
    iVar9 = func_0x(&stack0x00000088 + lVar11,(longlong)&puStackX_10 + lVar11);
  } while( true );
}

