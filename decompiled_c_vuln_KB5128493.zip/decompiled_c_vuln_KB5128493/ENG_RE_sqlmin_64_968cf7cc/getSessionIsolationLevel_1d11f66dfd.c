
/* WARNING: Control flow encountered bad instruction data */

undefined8 FUN_(char param_1)

{
  if (param_1 == '\x01') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_1 == '\x02') {
    return 0x1000;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

