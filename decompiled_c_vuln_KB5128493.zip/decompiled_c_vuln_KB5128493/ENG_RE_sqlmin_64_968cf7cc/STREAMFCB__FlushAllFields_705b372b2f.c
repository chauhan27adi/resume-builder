
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2)

{
  longlong lVar1;
  longlong lVar2;
  undefined4 uVar3;
  ulonglong *puVar4;
  byte bVar5;
  ulonglong uVar6;
  ushort uVar7;
  ushort uVar8;
  ulonglong uVar9;
  uint uVar10;
  ushort *puVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  ulonglong uVar15;
  byte *pbVar16;
  longlong unaff_GS_OFFSET;
  undefined auStack_fa8 [32];
  undefined8 uStack_f88;
  uint uStack_f80;
  ulonglong uStack_f78;
  undefined8 uStack_f70;
  undefined4 uStack_f68;
  longlong lStack_f60;
  longlong lStack_f58;
  longlong lStack_f50;
  longlong lStack_f48;
  longlong lStack_f40;
  undefined4 uStack_f38;
  longlong lStack_f30;
  longlong lStack_f28;
  longlong lStack_f20;
  longlong lStack_f18;
  undefined8 uStack_f10;
  undefined8 uStack_f08;
  undefined8 uStack_f00;
  undefined8 uStack_ef8;
  longlong lStack_ef0;
  undefined8 uStack_ee8;
  longlong lStack_ee0;
  longlong lStack_ed8;
  longlong lStack_ed0;
  longlong lStack_ec8;
  longlong lStack_ec0;
  longlong lStack_eb8;
  undefined8 uStack_eb0;
  undefined4 auStack_ea8 [2];
  int iStack_ea0;
  longlong lStack_e98;
  undefined8 uStack_e90;
  undefined auStack_e88 [16];
  short sStack_e78;
  ushort uStack_e76;
  uint uStack_e74;
  byte *pbStack_e70;
  undefined8 uStack_e68;
  uint uStack_e60;
  ushort uStack_e5c;
  byte *pbStack_e5a;
  undefined2 uStack_e52;
  undefined2 uStack_e50;
  undefined2 uStack_e4e;
  ushort uStack_e4c;
  undefined2 uStack_e4a;
  undefined auStack_e44 [2060];
  undefined4 uStack_638;
  uint uStack_634;
  byte abStack_630 [1528];
  ulonglong uStack_38;
  
  uStack_e90 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_fa8;
  lStack_eb8 = 0;
  uStack_eb0 = 0;
  pbStack_e70 = (byte *)0x0;
  uStack_e74 = 0;
  pbStack_e5a = (byte *)0x0;
  uStack_e50 = 0;
  uStack_e4e = 0;
  uStack_e4c = 0;
  uStack_e4a = 0;
  uStack_e68 = 0;
  auStack_ea8[0] = 3;
  iStack_ea0 = param_2;
  lStack_e98 = param_1;
  func_0x(auStack_e44,0,0x800);
  sStack_e78 = 0;
  uStack_f80 = uStack_f80 & 0xffffff00;
  uStack_f88._0_4_ = 0x3c;
  func_0x(&uStack_e76,auStack_e44);
  uStack_f88 = (ulonglong)uStack_f88._4_4_ << 0x20;
  func_0x(auStack_e88,4,1,0);
  func_0x(&sStack_e78,auStack_e88,auStack_ea8,4);
  if (param_2 != 0) {
    lStack_eb8 = param_1 + 0x2d78;
    uStack_eb0._4_4_ = 2;
    uStack_f68 = 0;
    uStack_f70 = 0;
    uStack_f78 = 0;
    uStack_f80 = 0;
    uStack_f88 = 0;
    uVar3 = func_0x(lStack_eb8,2,0xffffffff,0);
    uStack_eb0 = CONCAT44(uStack_eb0._4_4_,uVar3);
  }
  lVar2 = lStack_e98;
  lStack_ec0 = param_1 + 0x6c8;
  lStack_ec8 = param_1 + 0x2078;
  lStack_ed0 = param_1 + 0x2068;
  lStack_ed8 = param_1 + 0x205c;
  lStack_ee0 = param_1 + 0x2050;
  lStack_ef0 = param_1 + 0x6d8;
  lStack_f18 = param_1 + 0x2044;
  lStack_f20 = param_1 + 0x1288;
  lStack_f28 = param_1 + 0x127c;
  lStack_f30 = param_1 + 0x1270;
  lStack_f40 = param_1 + 0x12a0;
  lStack_f48 = param_1 + 0x6b8;
  lStack_f50 = param_1 + 0x6ac;
  uStack_ee8 = 0x120eb10;
  uStack_ef8 = 0x120eb10;
  uStack_f00 = 0x120eb10;
  uStack_f08 = 0x1bb9540;
  uStack_f10 = 0x1bb9540;
  uStack_f38 = *(undefined4 *)(lStack_e98 + 0x126c);
  lStack_f58 = lStack_e98 + 0x6a0;
  lStack_f60 = lStack_e98 + 0x694;
  uStack_f68 = *(undefined4 *)(lStack_e98 + 0x650);
  uStack_f70 = *(undefined8 *)(lStack_e98 + 0x700);
  iVar13 = 0;
  uStack_f78 = uStack_f78 & 0xffffffff00000000;
  uStack_f80 = *(undefined4 *)(lStack_e98 + 0x6f4);
  uStack_f88 = uStack_f88 & 0xffffffff00000000;
  func_0x(&sStack_e78,*(undefined4 *)(lStack_e98 + 0xc),*(undefined2 *)(lStack_e98 + 0x10),
                  lStack_e98 + 0x678);
  func_0x(&sStack_e78);
  if (sStack_e78 == 0) {
    uVar10 = uStack_e74;
    if (uStack_e74 == 0) {
      uStack_e76 = 0;
      uVar15 = uStack_e68 & 0xffffffff;
      uVar10 = (uint)uStack_e68;
      if ((*pbStack_e70 & 0x10) != 0) {
        uVar10 = (uint)uStack_e68 + 2 + (*(ushort *)(pbStack_e70 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar10;
      }
      uStack_e68 = CONCAT44(uVar10,(uint)uStack_e68);
      uStack_e60 = (uint)uVar15;
      if ((*pbStack_e70 & 0x20) == 0) {
        uStack_e5c = 0;
        uStack_e74 = uStack_e60;
      }
      else {
        puVar11 = (ushort *)(pbStack_e70 + uVar15);
        uStack_e5c = *puVar11;
        if (uStack_e5c == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_f88 = 0;
              (*_DAT_)(1,0x140b0d8,0x152ada8,0x80f);
            }
          }
          func_0x(pbStack_e70,3);
        }
        uStack_e60 = uStack_e68._4_4_ + 2 + (uint)uStack_e5c * 2;
        if (0x1f9e < uStack_e60) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar1 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), lVar1 != 0 &&
              ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
               (*(char *)(lVar1 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_f88 = 0;
              (*_DAT_)(1,0x140b0d8,0x152ada8,0x816);
            }
          }
          func_0x(pbStack_e70,4);
        }
        uVar9 = (ulonglong)uStack_e5c;
        uStack_e74 = puVar11[uVar9] & 0x7fff;
        if (uStack_e74 < uStack_e60) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_f88 = 0;
              (*_DAT_)(1,0x140b0d8,0x152ada8,0x81d);
            }
          }
          func_0x(pbStack_e70,4);
          uVar9 = (ulonglong)uStack_e5c;
        }
        uVar15 = (ulonglong)uStack_e74;
        uVar14 = uStack_e60;
        do {
          if (-1 < (short)puVar11[(ulonglong)((int)uVar9 - 1) + 1]) break;
          if ((int)uVar9 == 1) {
            uVar6 = 1;
            uVar12 = uVar14;
          }
          else {
            uVar12 = *(ushort *)(pbStack_e70 + uVar9 * 2 + ((uStack_e68 >> 0x20) - 2)) & 0x7fff;
            uVar6 = uVar9;
          }
          if ((uVar12 < uVar14) ||
             ((*(ushort *)(pbStack_e70 + uVar6 * 2 + (uStack_e68 >> 0x20)) & 0x7fff) < uVar12)) {
            func_0x(pbStack_e70,7);
            uVar9 = (ulonglong)uStack_e5c;
            uVar15 = (ulonglong)uStack_e74;
            uVar14 = uStack_e60;
          }
          uVar10 = (uint)uVar15;
          if ((uVar12 < uVar14) || (uVar10 < uVar12)) goto LAB_;
          if (*(ushort *)(pbStack_e70 + uVar12) == 5) {
            uStack_e76 = uStack_e76 | 2;
            uStack_e5c = (short)uVar9 - 1;
            uStack_e4e = (undefined2)uVar12;
            if ((*(ushort *)(pbStack_e70 + (ulonglong)(uVar12 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_e4c = uStack_e4c & 0xc7ff;
            }
            else {
              uStack_e4c = uStack_e4c ^
                           (uStack_e4c ^ *(ushort *)(pbStack_e70 + (ulonglong)(uVar12 & 0xffff) + 2)
                           ) & 0x3800;
            }
            uStack_e4c = (uStack_e4c ^ *(ushort *)(pbStack_e70 + (ulonglong)(uVar12 & 0xffff) + 2))
                         & 0x7ff ^ uStack_e4c;
            break;
          }
          if (*(ushort *)(pbStack_e70 + uVar12) < 0x400) break;
          uStack_e76 = uStack_e76 | 1;
          uStack_e5c = (short)uVar9 - 1;
          uVar9 = (ulonglong)uStack_e5c;
        } while (uStack_e5c != 0);
      }
      if ((*pbStack_e70 & 0x40) == 0) {
        uStack_e52 = 0;
        uStack_e50 = 0;
      }
      else {
        uStack_e52 = (undefined2)uVar15;
        uStack_e50 = (undefined2)(uVar15 >> 0x10);
        uStack_e74 = (int)uVar15 + 0xe;
        puVar4 = (ulonglong *)func_0x(&uStack_e76);
        uVar15 = *puVar4;
        uVar7 = (ushort)(uVar15 >> 0x30);
        uVar8 = uVar7;
        if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
          uVar8 = uVar7 & 0xdfff;
          if ((uVar15 & 0x4000000000000000) != 0) {
            uVar8 = uVar7 | 0x2000;
          }
        }
        if (uVar8 == 0xfffc) {
          iVar13 = (int)((uVar15 >> 0x20 & 0xffff) >> 5);
        }
        uStack_e74 = uStack_e74 + iVar13;
        uVar15 = (ulonglong)uStack_e74;
      }
      uVar10 = (uint)uVar15;
      if ((pbStack_e5a != (byte *)0x0) && (pbStack_e5a < pbStack_e70 + uVar15)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar1 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar1 != 0 && (lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0)) &&
            (*(char *)(lVar1 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_f88 = 0;
            (*_DAT_)(1,0x140b0d8,0x152ada8,0x877);
          }
        }
        func_0x(pbStack_e70,0x12);
        uVar10 = uStack_e74;
      }
      if (0x3f3b < uVar10 - 1) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar1 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
            , lVar1 != 0 &&
            ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_f88 = 0;
            (*_DAT_)(1,0x140b0d8,0x152ada8,0x87c);
          }
        }
        func_0x(pbStack_e70,5);
        uVar10 = uStack_e74;
      }
    }
LAB_:
    if (8 < uVar10) goto LAB_;
    bVar5 = *pbStack_e70 & 0xe;
  }
  else {
    if (uStack_e74 == 0) {
      func_0x(&uStack_e76);
    }
    uVar10 = uStack_e74;
    if (8 < uStack_e74) goto LAB_;
    bVar5 = *pbStack_e70 & 0x1c;
  }
  if ((bVar5 == 0) || (bVar5 == 0xc)) {
    uVar10 = 9;
  }
LAB_:
  func_0x(&uStack_634,0,0x5fc);
  uStack_638 = 4;
  iVar13 = 0x600;
  if (*(char *)(lVar2 + 0x2dac) == '\0') {
    iVar13 = uVar10 + 8;
  }
  func_0x(abStack_630,0x5f8,pbStack_e70,uVar10);
  pbVar16 = abStack_630;
  uVar15 = (ulonglong)(iVar13 - 8U);
  uStack_634 = 0xffffffff;
  if (iVar13 - 8U != 0) {
    do {
      uStack_634 = uStack_634 >> 8 ^
                   *(uint *)((ulonglong)((uStack_634 ^ *pbVar16) & 0xff) * 4 + 0x11a7290);
      pbVar16 = pbVar16 + 1;
      uVar15 = uVar15 - 1;
    } while (uVar15 != 0);
  }
  func_0x(lVar2 + 0x18,&uStack_638,iVar13,iStack_ea0);
  if ((int)uStack_eb0 != 0) {
    func_0x(lStack_eb8,uStack_eb0._4_4_);
    uStack_eb0 = uStack_eb0 & 0xffffffff00000000;
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_fa8);
  return;
}

