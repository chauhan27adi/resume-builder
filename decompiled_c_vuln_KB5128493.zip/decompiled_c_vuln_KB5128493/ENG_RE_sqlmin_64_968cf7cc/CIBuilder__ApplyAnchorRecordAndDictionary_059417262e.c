
/* WARNING: Removing unreachable block (ram,0x001001fd) */
/* WARNING: Heritage AFTER dead removal. Example location: s0xfffffffffffff4d0 : 0x00100213 */
/* WARNING: Removing unreachable block (ram,0x00100219) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_(longlong param_1,longlong param_2,longlong param_3,int param_4,longlong param_5,
                 undefined8 param_6,longlong *param_7)

{
  byte *pbVar1;
  longlong lVar2;
  undefined8 uVar3;
  bool bVar4;
  char cVar5;
  short sVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  short *psVar10;
  byte **ppbVar11;
  ulonglong *puVar12;
  undefined4 uVar13;
  int iVar14;
  uint uVar15;
  ulonglong uVar16;
  byte bVar17;
  ushort uVar18;
  uint uVar19;
  uint uVar20;
  undefined *puVar21;
  ushort *puVar22;
  uint uVar23;
  byte **ppbVar24;
  byte **ppbVar25;
  ulonglong uVar26;
  byte *pbVar27;
  byte **ppbVar28;
  short *psVar29;
  longlong unaff_GS_OFFSET;
  undefined auStack_c88 [48];
  int iStack_c58;
  uint uStack_c54;
  longlong lStack_c50;
  short sStack_c48;
  ushort uStack_c46;
  uint uStack_c44;
  longlong lStack_c40;
  byte **ppbStack_c38;
  uint uStack_c30;
  ushort uStack_c2c;
  undefined8 uStack_c2a;
  undefined2 uStack_c22;
  undefined2 uStack_c20;
  undefined2 uStack_c1e;
  ushort uStack_c1c;
  undefined2 uStack_c1a;
  undefined8 uStack_c10;
  short sStack_c08;
  uint uStack_c00;
  int iStack_bfc;
  uint uStack_bf8;
  undefined4 uStack_bf4;
  undefined2 uStack_bf0;
  longlong lStack_be8;
  longlong lStack_be0;
  longlong lStack_bd8;
  longlong lStack_bd0;
  longlong *plStack_bc8;
  undefined4 uStack_bc0;
  short *psStack_bb8;
  longlong lStack_bb0;
  short asStack_ba8 [2];
  undefined4 uStack_ba4;
  undefined8 uStack_ba0;
  undefined8 uStack_b98;
  undefined8 uStack_b8a;
  undefined8 uStack_b80;
  undefined8 uStack_b70;
  short sStack_b68;
  ushort uStack_b66;
  uint uStack_b64;
  byte *pbStack_b60;
  undefined8 uStack_b58;
  undefined4 uStack_b50;
  ushort uStack_b4c;
  undefined2 uStack_b4a;
  undefined6 uStack_b48;
  undefined2 uStack_b42;
  undefined2 uStack_b40;
  undefined2 uStack_b3e;
  ushort uStack_b3c;
  undefined2 uStack_b3a;
  undefined4 uStack_b38;
  uint uStack_b34;
  undefined auStack_b30 [16];
  undefined auStack_b20 [8];
  undefined8 uStack_b18;
  undefined8 uStack_b10;
  undefined6 uStack_b08;
  undefined2 uStack_b02;
  undefined6 uStack_b00;
  undefined2 uStack_afa;
  undefined8 uStack_af8;
  undefined auStack_af0 [16];
  undefined auStack_ae0 [16];
  undefined auStack_ad0 [16];
  undefined8 uStack_ac0;
  undefined auStack_ab8 [16];
  undefined auStack_aa8 [16];
  undefined8 uStack_a98;
  undefined8 uStack_a90;
  undefined8 uStack_a88;
  undefined4 uStack_60;
  ulonglong uStack_58;
  
  uStack_b70 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)&iStack_c58;
  iStack_bfc = param_4;
  lStack_bb0 = param_3;
  lStack_be8 = param_1;
  lStack_be0 = param_5;
  plStack_bc8 = param_7;
  asStack_ba8[0] = -1;
  ppbVar28 = (byte **)0x0;
  uStack_ba0 = 0;
  uStack_ba4 = 0;
  uStack_b8a = 0;
  uStack_b80 = 0;
  uStack_b98 = 0;
  sStack_b68 = -1;
  pbStack_b60 = (byte *)0x0;
  uStack_b64 = 0;
  uStack_b4a = 0;
  uStack_b48 = 0;
  uStack_b40 = 0;
  uStack_b3e = 0;
  uStack_b3c = 0;
  uStack_b3a = 0;
  uStack_b58 = (byte **)0x0;
  uStack_b34 = 0xffffffff;
  lStack_bd0 = 0;
  sStack_c48 = -1;
  lStack_c40 = 0;
  uStack_c44 = 0;
  uStack_c2a = 0;
  uStack_c20 = 0;
  uStack_c1e = 0;
  uStack_c1c = 0;
  uStack_c1a = 0;
  ppbStack_c38 = (byte **)0x0;
  bVar17 = -(*(char *)(param_2 + 2) >> 7);
  uStack_c00 = (uint)bVar17;
  auStack_ab8 = ZEXT816(0);
  auStack_aa8 = ZEXT816(0);
  uStack_a98 = 0;
  uStack_a90 = 0;
  uStack_a88 = 0;
  uStack_60 = 0;
  puVar21 = auStack_c88;
  iStack_c58 = param_4;
  lStack_c50 = param_3;
  if ((bVar17 != 0) &&
     ((*(int *)(param_1 + 0x1fe4) != 0 || (puVar21 = auStack_c88, *(int *)(param_1 + 0x1fe8) != 0)))
     ) {
    uStack_a98 = 0x100000000;
    uStack_b08 = 0;
    uStack_afa = auStack_ab8._6_2_;
    auStack_ae0 = auStack_ab8;
    auStack_b30 = auStack_ab8;
    stack0xfffffffffffff4e2 = auStack_ab8._2_14_;
    auStack_b20._0_2_ = 0xffff;
    uStack_b18 = 0;
    uStack_b02 = 0;
    uStack_b00 = 0;
    uStack_af8 = 0;
    uStack_b10 = 0;
    auStack_af0 = ZEXT816(0);
    auStack_ad0._0_12_ = ZEXT812(0);
    auStack_ad0._12_4_ = 0;
    uStack_ac0 = 0;
    uStack_b58 = (byte **)auStack_b30;
    uStack_60 = 0;
    uStack_a88 = 0;
    uStack_a90 = 0;
    uStack_a98 = 0x100000000;
    uStack_ac0 = 0;
    uStack_af8 = 0;
    uStack_afa = 0;
    uStack_b00 = 0;
    uStack_b02 = 0;
    uStack_b08 = 0;
    uStack_b10 = 0;
    uStack_b34 = 0xffffffff;
    uStack_b3a = 0;
    uStack_b3c = 0;
    uStack_b3e = 0;
    uStack_b40 = 0;
    uStack_b48 = 0;
    uStack_b4a = 0;
    pbStack_b60 = (byte *)0x0;
    uStack_b64 = 0;
    sStack_b68 = -1;
    uStack_b70 = 0xfffffffffffffffe;
    uStack_b80 = 0;
    uStack_b8a = 0;
    uStack_b98 = 0;
    uStack_ba0 = 0;
    uStack_ba4 = 0;
    asStack_ba8[0] = -1;
    lStack_bd0 = 0;
    uStack_c1a = 0;
    uStack_c1c = 0;
    uStack_c1e = 0;
    uStack_c20 = 0;
    uStack_c2a = 0;
    ppbStack_c38 = (byte **)0x0;
    lStack_c40 = 0;
    uStack_c44 = 0;
    sStack_c48 = -1;
    lVar9 = func_0x();
    puVar21 = auStack_c88 + -lVar9;
    lStack_bd0 = (longlong)&iStack_c58 + -lVar9;
  }
  uStack_c54 = 0;
  if (0 < *(int *)(param_1 + 8)) {
    lStack_bd8 = 0;
    ppbVar25 = ppbVar28;
    ppbVar24 = ppbVar28;
    iVar8 = param_4;
    do {
      lVar9 = 0xfff - lStack_bd8;
      if (*(short *)(param_2 + lVar9 * 2) == 0) {
        *(undefined2 *)(param_5 + lStack_bd8 * 2) = 0xffff;
        uStack_c54 = (uint)ppbVar24;
      }
      else {
        psStack_bb8 = (short *)0x0;
        uStack_bf8 = (int)ppbVar25 + 1;
        uStack_b34 = (uint)ppbVar24;
        uVar23 = 0;
        ppbVar25 = ppbVar28;
        if (*(char *)(param_2 + 2) < '\0') {
          pbVar27 = (byte *)(param_2 + 0x60);
          if ((sStack_b68 == 0) || (ppbVar25 = uStack_b58, uStack_b58 == (byte **)0x0)) {
            auStack_ae0 = ZEXT816(0);
            uStack_b08 = 0;
            uStack_afa = auStack_ae0._6_2_;
            uStack_afa = 0;
            auStack_b30 = auStack_ae0;
            stack0xfffffffffffff4e2 = auStack_ae0._2_14_;
            auStack_b20._0_2_ = 0xffff;
            uStack_b18 = 0;
            uStack_b02 = 0;
            uStack_b00 = 0;
            uStack_af8 = 0;
            uStack_b10 = 0;
            auStack_af0 = ZEXT816(0);
            auStack_ad0._0_12_ = ZEXT812(0);
            auStack_ad0._12_4_ = 0;
            uStack_ac0 = 0;
            ppbVar25 = (byte **)auStack_b30;
          }
          if (*(short *)(param_2 + 0x24) == 0) {
LAB_:
            uStack_c10 = *(undefined8 *)(param_2 + 0x28);
            sStack_c08 = *(short *)(param_2 + 0x30);
          }
          else {
            cVar5 = *(char *)(param_2 + 1);
            if (cVar5 == '\v') {
              if (*(int *)(param_2 + 0x18) != 99) {
LAB_:
                if (cVar5 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar5 != '\b') goto LAB_;
LAB_:
              if (*(int *)(param_2 + 0x18) != 99) goto LAB_;
            }
            uStack_bf4 = *(undefined4 *)(param_2 + 0x20);
            uStack_bf0 = *(undefined2 *)(param_2 + 0x24);
            *(undefined8 *)(puVar21 + -8) = 0x1003c9;
            cVar5 = func_0x(&uStack_bf4);
            if (cVar5 == '\0') goto LAB_;
            *(undefined8 *)(puVar21 + -8) = 0x1003d9;
            func_0x(param_2,&uStack_c10);
          }
          iVar14 = (int)((ulonglong)uStack_c10 >> 0x20);
          if (((((pbVar27 != *ppbVar25) || (sStack_c08 != *(short *)(ppbVar25 + 0xd))) ||
               ((int)uStack_c10 != *(int *)(ppbVar25 + 0xc))) ||
              ((iVar14 != *(int *)((longlong)ppbVar25 + 100) ||
               (*(int *)(param_2 + 0x20) != *(int *)((longlong)ppbVar25 + 0x6c))))) ||
             (iVar8 = iStack_c58, *(short *)(param_2 + 0x24) != *(short *)(ppbVar25 + 0xe))) {
            *ppbVar25 = pbVar27;
            *(int *)(ppbVar25 + 0xc) = (int)uStack_c10;
            *(int *)((longlong)ppbVar25 + 100) = iVar14;
            *(short *)(ppbVar25 + 0xd) = sStack_c08;
            *(undefined4 *)((longlong)ppbVar25 + 0x6c) = *(undefined4 *)(param_2 + 0x20);
            *(undefined2 *)(ppbVar25 + 0xe) = *(undefined2 *)(param_2 + 0x24);
            *(undefined2 *)((longlong)ppbVar25 + 0x72) = 0;
            uStack_bc0 = *(undefined4 *)((ulonglong)*pbVar27 * 6 + 0x1521810);
            uVar16 = (ulonglong)*(short *)((ulonglong)*pbVar27 * 6 + 0x1521814);
            *(undefined2 *)(ppbVar25 + 2) = 0xffff;
            ppbVar25[3] = (byte *)0x0;
            *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
            *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
            ppbVar25[7] = (byte *)0x0;
            ppbVar25[4] = (byte *)0x0;
            ppbVar25[9] = (byte *)0x0;
            ppbVar25[10] = (byte *)0x0;
            *(undefined2 *)(ppbVar25 + 0xb) = 0;
            if ((**ppbVar25 & 2) != 0) {
              pbVar1 = pbVar27 + uVar16;
              if ((*pbVar1 & 1) == 0) {
                *(undefined2 *)(ppbVar25 + 2) = 0;
                ppbVar25[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar25 + 0x36) = 0;
                uVar15 = uVar23;
                switch(*pbVar1 & 0xe) {
                default:
                  uVar15 = (uint)*(ushort *)(pbVar1 + 2);
                  if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                    *(undefined8 *)(puVar21 + -8) = 0x10069b;
                    func_0x(pbVar1,6);
                  }
                  break;
                case 4:
                  uVar15 = 9;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar15 = 1;
                }
                *(uint *)(ppbVar25 + 4) = uVar15;
                *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
              }
              else {
                *(undefined2 *)(ppbVar25 + 2) = 1;
                ppbVar25[3] = pbVar1;
                bVar17 = *pbVar1;
                switch(bVar17 & 0x1c) {
                default:
                  if ((char)pbVar1[1] < '\0') {
                    uVar7 = *(ushort *)(pbVar1 + 1);
                    *(ushort *)((longlong)ppbVar25 + 0x12) = uVar7;
                    sVar6 = 3;
                    uVar7 = (uVar7 & 0x7f) << 8 | uVar7 >> 8;
                  }
                  else {
                    sVar6 = 2;
                    uVar7 = (ushort)pbVar1[1];
                  }
                  *(ushort *)((longlong)ppbVar25 + 0x12) = uVar7;
                  *(short *)(ppbVar25 + 5) = sVar6;
                  uVar7 = *(ushort *)((longlong)ppbVar25 + 0x12);
                  *(short *)((longlong)ppbVar25 + 0x2c) = (short)(uVar7 + 1 >> 1) + sVar6;
                  if (uVar7 < 0x1f) {
                    *(undefined2 *)((longlong)ppbVar25 + 0x2a) = 0;
                    *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                    *(undefined4 *)(ppbVar25 + 8) = 0;
                    ppbVar25[7] = (byte *)0x0;
                    ppbVar25[4] = (byte *)0x0;
                  }
                  else {
                    iVar8 = uVar7 - 1;
                    *(short *)((longlong)ppbVar25 + 0x2a) =
                         ((short)(iVar8 / 0x1e) + (short)(iVar8 >> 0x1f)) -
                         (short)((longlong)iVar8 * 0x88888889 >> 0x3f);
                    *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                    *(undefined4 *)(ppbVar25 + 8) = 0;
                    ppbVar25[7] = (byte *)0x0;
                    ppbVar25[4] = (byte *)0x0;
                  }
                  break;
                case 4:
                  if (((bVar17 & 0x1c) != 4) || (bVar4 = true, (bVar17 & 2) == 0)) {
                    bVar4 = false;
                  }
                  if (!bVar4) {
                    uVar13 = 1;
                  }
                  else {
                    *(undefined4 *)(ppbVar25 + 8) = 0;
                    uVar13 = 0xf;
                  }
                  ppbVar25[5] = (byte *)0x0;
                  *(undefined2 *)((longlong)ppbVar25 + 0x12) = 0;
                  ppbVar25[6] = (byte *)0x0;
                  ppbVar25[4] = (byte *)0x0;
                  ppbVar25[7] = (byte *)0x0;
                  ppbVar25[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar25 + 0x14) = uVar13;
                  *(uint *)(ppbVar25 + 8) = (uint)bVar4;
                  ppbVar25[7] = (byte *)0x0;
                  ppbVar25[4] = (byte *)0x0;
                  break;
                case 8:
                  ppbVar25[5] = (byte *)0x0;
                  *(undefined2 *)((longlong)ppbVar25 + 0x12) = 0;
                  ppbVar25[6] = (byte *)0x0;
                  ppbVar25[4] = (byte *)0x0;
                  ppbVar25[7] = (byte *)0x0;
                  ppbVar25[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar25 + 0x14) = 9;
                  *(undefined4 *)(ppbVar25 + 8) = 0;
                  ppbVar25[7] = (byte *)0x0;
                  ppbVar25[4] = (byte *)0x0;
                }
              }
            }
            if ((**ppbVar25 & 4) != 0) {
              if (uStack_bc0._2_2_ != 0) {
                uVar16 = (ulonglong)*(ushort *)(param_2 + 0x61 + (longlong)uStack_bc0._2_2_ * 2);
              }
              psVar10 = (short *)(pbVar27 + uVar16);
              ppbVar25[9] = (byte *)psVar10;
              sVar6 = *psVar10;
              ppbVar25[10] = (byte *)(psVar10 + 1);
              *(short *)(ppbVar25 + 0xb) = (sVar6 + 1) * 2;
            }
            pbVar27 = ppbVar25[1];
            param_1 = lStack_be8;
            iVar8 = iStack_c58;
            if (pbVar27 != (byte *)0x0) {
              *(undefined8 *)(puVar21 + -8) = 0x100731;
              func_0x(pbVar27,ppbVar25);
              param_1 = lStack_be8;
              iVar8 = iStack_c58;
            }
          }
        }
        uVar15 = (uint)*(ushort *)(param_2 + 0xe);
        pbVar27 = (byte *)((ulonglong)*(ushort *)(param_2 + lVar9 * 2) + param_2);
        pbStack_b60 = pbVar27;
        ppbVar24 = ppbVar28;
        if ((*pbVar27 & 1) == 0) {
          sStack_b68 = 0;
          ppbVar25 = (byte **)0x0;
          uStack_b64 = 0;
          uStack_b42 = 0;
          uStack_b40 = 0;
          switch(*pbVar27 & 0xe) {
          default:
            uVar15 = (uint)*(ushort *)(pbVar27 + 2);
            ppbVar24 = ppbVar25;
            if (0x1f9d < *(ushort *)(pbVar27 + 2) - 1) {
              *(undefined8 *)(puVar21 + -8) = 0x100983;
              func_0x(pbVar27,6);
              ppbVar24 = (byte **)(ulonglong)uStack_b64;
            }
            break;
          case 4:
            uVar15 = 9;
            ppbVar24 = ppbVar25;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar15 = 1;
            ppbVar24 = ppbVar25;
          }
          uStack_b58 = (byte **)CONCAT44(uStack_b58._4_4_,uVar15);
          ppbVar25 = (byte **)(param_2 + 0x2000);
          if (param_2 == 0) {
            ppbVar25 = ppbVar28;
          }
          uStack_b4a = SUB82(ppbVar25,0);
          uStack_b48 = (undefined6)((ulonglong)ppbVar25 >> 0x10);
          uVar19 = uStack_b50;
        }
        else {
          sStack_b68 = 1;
          bVar17 = *pbVar27;
          switch(bVar17 & 0x1c) {
          default:
            if ((char)pbVar27[1] < '\0') {
              uStack_b66 = (*(ushort *)(pbVar27 + 1) & 0x7f) << 8 | *(ushort *)(pbVar27 + 1) >> 8;
              sVar6 = 3;
              uStack_b50._0_2_ = 3;
            }
            else {
              uStack_b66 = (ushort)pbVar27[1];
              sVar6 = 2;
              uStack_b50._0_2_ = 2;
            }
            uStack_b4c = (short)(uStack_b66 + 1 >> 1) + sVar6;
            if (uStack_b66 < 0x1f) {
              uStack_b50._2_2_ = 0;
              uStack_b64 = 0;
              uStack_b38 = 0;
            }
            else {
              iVar14 = uStack_b66 - 1;
              uStack_b50._2_2_ =
                   ((short)(iVar14 / 0x1e) + (short)(iVar14 >> 0x1f)) -
                   (short)((longlong)iVar14 * 0x88888889 >> 0x3f);
              ppbVar24 = (byte **)0x0;
              uStack_b64 = 0;
              uStack_b38 = 0;
            }
            break;
          case 4:
            if (((bVar17 & 0x1c) == 4) && ((bVar17 & 2) != 0)) {
              uStack_b50._0_2_ = 0;
              uStack_b50._2_2_ = 0;
              uStack_b4c = 0;
              uStack_b4a = 0;
              uStack_b66 = 0;
              uStack_b48 = 0;
              uStack_b42 = 0;
              ppbVar24 = (byte **)0xf;
              uStack_b64 = 0xf;
              uStack_b38 = 1;
            }
            else {
              uStack_b50._0_2_ = 0;
              uStack_b50._2_2_ = 0;
              uStack_b4c = 0;
              uStack_b4a = 0;
              uStack_b66 = 0;
              uStack_b48 = 0;
              uStack_b42 = 0;
              ppbVar24 = (byte **)0x1;
              uStack_b64 = 1;
              uStack_b38 = 0;
            }
            break;
          case 8:
            uStack_b50._0_2_ = 0;
            uStack_b50._2_2_ = 0;
            uStack_b4c = 0;
            uStack_b4a = 0;
            uStack_b66 = 0;
            uStack_b48 = 0;
            uStack_b42 = 0;
            ppbVar24 = (byte **)0x9;
            uStack_b64 = 9;
            uStack_b38 = 0;
          }
          ppbVar11 = (byte **)(param_2 + 0x2000);
          if (param_2 == 0) {
            ppbVar11 = ppbVar28;
          }
          uStack_b40 = SUB82(ppbVar11,0);
          uStack_b3e = (undefined2)((ulonglong)ppbVar11 >> 0x10);
          uStack_b3c = (ushort)((ulonglong)ppbVar11 >> 0x20);
          uStack_b3a = (undefined2)((ulonglong)ppbVar11 >> 0x30);
          uStack_b58 = ppbVar25;
          uVar15 = (uint)ppbVar25;
          uVar19 = CONCAT22(uStack_b50._2_2_,(undefined2)uStack_b50);
        }
        uStack_b50 = uVar19;
        if (uStack_c00 == 0) {
          psVar10 = &sStack_b68;
code_r0x0010126b:
          *(longlong **)(puVar21 + 0x20) = plStack_bc8;
          lVar9 = lStack_c50;
          *(undefined8 *)(puVar21 + -8) = 0x10128a;
          func_0x(asStack_ba8,lVar9,iVar8,psVar10);
          psVar29 = asStack_ba8;
        }
        else {
          if ((*(int *)(param_1 + 0x1fe4) == 0) && (*(int *)(param_1 + 0x1fe8) == 0)) {
            lVar9 = lStack_c50;
            psVar29 = &sStack_c48;
          }
          else {
            iVar8 = 0x1f9e;
            lVar9 = lStack_bd0;
            psVar29 = psStack_bb8;
          }
          sStack_c48 = sStack_b68;
          if (sStack_b68 == 0) {
            uVar20 = uVar19;
            if ((int)ppbVar24 == 0) {
              uStack_b66 = 0;
              uStack_b50 = uVar15;
              if ((*pbStack_b60 & 0x10) != 0) {
                uStack_b50 = (int)uStack_b58 + 2 +
                             (*(ushort *)(pbStack_b60 + ((ulonglong)uStack_b58 & 0xffffffff)) + 7 >>
                             3);
              }
              uStack_b58 = (byte **)CONCAT44(uStack_b50,(int)uStack_b58);
              if ((*pbStack_b60 & 0x20) == 0) {
                ppbVar24 = (byte **)(ulonglong)uStack_b50;
                uStack_b4c = 0;
                uStack_b64 = uStack_b50;
                uVar20 = uStack_b50;
              }
              else {
                puVar22 = (ushort *)(pbStack_b60 + uStack_b50);
                uStack_b4c = *puVar22;
                if (uStack_b4c == 0) {
                  if ((((cRam0000000001e342fb != '\0') ||
                       (uStack_b50 = uVar19, (bRam0000000001e44c00 & 1) != 0)) &&
                      (lVar2 = *(longlong *)
                                ((ulonglong)*puRam00000000013a2b90 +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000013a2b88 * 8) + 8), uStack_b50 = uVar19,
                      lVar2 != 0)) &&
                     ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 &&
                      (*(char *)(lVar2 + 0x499) != '\0')))) {
                    if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                      *(undefined8 *)(puVar21 + -8) = 0x100b28;
                      (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar21 + 0x20) = 0;
                      *(undefined8 *)(puVar21 + -8) = 0x100b4e;
                      (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x80f);
                    }
                  }
                  pbVar27 = pbStack_b60;
                  *(undefined8 *)(puVar21 + -8) = 0x100b5f;
                  func_0x(pbVar27,3);
                }
                uStack_b50 = uStack_b58._4_4_ + (uStack_b4c + 1) * 2;
                if (0x1f9e < uStack_b50) {
                  if (((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                     ((lVar2 = *(longlong *)
                                ((ulonglong)*puRam00000000013a2b90 +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar2 != 0 &&
                      ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 &&
                       (*(char *)(lVar2 + 0x499) != '\0')))))) {
                    if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                      *(undefined8 *)(puVar21 + -8) = 0x100c02;
                      (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar21 + 0x20) = 0;
                      *(undefined8 *)(puVar21 + -8) = 0x100c28;
                      (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x816);
                    }
                  }
                  pbVar27 = pbStack_b60;
                  *(undefined8 *)(puVar21 + -8) = 0x100c39;
                  func_0x(pbVar27,4);
                }
                uStack_b64 = puVar22[uStack_b4c] & 0x7fff;
                ppbVar24 = (byte **)(ulonglong)uStack_b64;
                uVar20 = uStack_b50;
                if (uStack_b64 < uStack_b50) {
                  if ((((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                      (lVar2 = *(longlong *)
                                ((ulonglong)*puRam00000000013a2b90 +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar2 != 0)) &&
                     ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 &&
                      (*(char *)(lVar2 + 0x499) != '\0')))) {
                    if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                      *(undefined8 *)(puVar21 + -8) = 0x100cdd;
                      (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar21 + 0x20) = 0;
                      *(undefined8 *)(puVar21 + -8) = 0x100d03;
                      (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x81d);
                    }
                  }
                  pbVar27 = pbStack_b60;
                  *(undefined8 *)(puVar21 + -8) = 0x100d14;
                  func_0x(pbVar27,4);
                  ppbVar24 = (byte **)(ulonglong)uStack_b64;
                  uVar20 = uStack_b50;
                }
                do {
                  pbVar27 = pbStack_b60;
                  if (-1 < (short)puVar22[(ulonglong)(uStack_b4c - 1) + 1]) break;
                  uVar15 = uStack_b50;
                  if (uStack_b4c != 1) {
                    uVar15 = *(ushort *)
                              (pbStack_b60 +
                              (ulonglong)uStack_b4c * 2 + (((ulonglong)uStack_b58 >> 0x20) - 2)) &
                             0x7fff;
                  }
                  if ((uVar15 < uStack_b50) ||
                     ((*(ushort *)
                        (pbStack_b60 + (ulonglong)uStack_b4c * 2 + ((ulonglong)uStack_b58 >> 0x20))
                      & 0x7fff) < uVar15)) {
                    uStack_b50 = uVar20;
                    *(undefined8 *)(puVar21 + -8) = 0x100d8c;
                    func_0x(pbVar27,7);
                    ppbVar24 = (byte **)(ulonglong)uStack_b64;
                    uVar20 = uStack_b50;
                  }
                  uVar19 = uStack_b50;
                  if ((uVar15 < uStack_b50) || (uVar19 = uStack_b50, (uint)ppbVar24 < uVar15))
                  goto code_r0x001010d8;
                  if (*(ushort *)(pbStack_b60 + uVar15) == 5) {
                    uStack_b66 = uStack_b66 | 2;
                    uStack_b4c = uStack_b4c - 1;
                    uStack_b3e = (undefined2)uVar15;
                    if ((*(ushort *)(pbStack_b60 + (ulonglong)(uVar15 & 0xffff) + 2) & 0x4000) == 0)
                    {
                      uStack_b3c = uStack_b3c & 0xc7ff;
                    }
                    else {
                      uStack_b3c = uStack_b3c ^
                                   (*(ushort *)(pbStack_b60 + (ulonglong)(uVar15 & 0xffff) + 2) ^
                                   uStack_b3c) & 0x3800;
                    }
                    uStack_b3c = uStack_b3c ^
                                 (uStack_b3c ^
                                 *(ushort *)(pbStack_b60 + (ulonglong)(uVar15 & 0xffff) + 2)) &
                                 0x7ff;
                    break;
                  }
                  if (*(ushort *)(pbStack_b60 + uVar15) < 0x400) break;
                  uStack_b66 = uStack_b66 | 1;
                  uStack_b4c = uStack_b4c - 1;
                } while (uStack_b4c != 0);
              }
              if ((*pbStack_b60 & 0x40) == 0) {
                uStack_b42 = 0;
                uStack_b40 = 0;
              }
              else {
                uStack_b42 = SUB82(ppbVar24,0);
                uStack_b40 = (undefined2)((ulonglong)ppbVar24 >> 0x10);
                uStack_b64 = (int)ppbVar24 + 0xe;
                uStack_b50 = uVar20;
                *(undefined8 *)(puVar21 + -8) = 0x100eb5;
                puVar12 = (ulonglong *)func_0x(&uStack_b66);
                uVar16 = *puVar12;
                uVar18 = (ushort)(uVar16 >> 0x30);
                uVar7 = uVar18;
                if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
                  uVar7 = uVar18 & 0xdfff;
                  if ((uVar16 & 0x4000000000000000) != 0) {
                    uVar7 = uVar18 | 0x2000;
                  }
                }
                uVar15 = uVar23;
                if (uVar7 == 0xfffc) {
                  uVar15 = (uint)((uVar16 >> 0x20 & 0xffff) >> 5);
                }
                uStack_b64 = uStack_b64 + uVar15;
                ppbVar24 = (byte **)(ulonglong)uStack_b64;
                uVar20 = uStack_b50;
              }
              if (((byte *)CONCAT62(uStack_b48,uStack_b4a) != (byte *)0x0) &&
                 ((byte *)CONCAT62(uStack_b48,uStack_b4a) <
                  (byte *)((longlong)ppbVar24 + (longlong)pbStack_b60))) {
                uStack_b50 = uVar20;
                if (((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                   (((lVar2 = *(longlong *)
                               ((ulonglong)*puRam00000000013a2b90 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar2 != 0 &&
                     (lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0)) &&
                    (*(char *)(lVar2 + 0x499) != '\0')))) {
                  if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                    *(undefined8 *)(puVar21 + -8) = 0x100fc5;
                    (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar21 + 0x20) = 0;
                    *(undefined8 *)(puVar21 + -8) = 0x100feb;
                    (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x877);
                  }
                }
                pbVar27 = pbStack_b60;
                *(undefined8 *)(puVar21 + -8) = 0x100ffc;
                func_0x(pbVar27,0x12);
                ppbVar24 = (byte **)(ulonglong)uStack_b64;
                uVar20 = uStack_b50;
              }
              uVar19 = uStack_b50;
              if (0x3f3b < (int)ppbVar24 - 1U) {
                uStack_b50 = uVar20;
                if (((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                   ((lVar2 = *(longlong *)
                              ((ulonglong)*puRam00000000013a2b90 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar2 != 0 &&
                    ((lVar2 = *(longlong *)(lVar2 + 0x60), lVar2 != 0 &&
                     (*(char *)(lVar2 + 0x499) != '\0')))))) {
                  if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                    *(undefined8 *)(puVar21 + -8) = 0x101093;
                    (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar21 + 0x20) = 0;
                    *(undefined8 *)(puVar21 + -8) = 0x1010b9;
                    (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x87c);
                  }
                }
                pbVar27 = pbStack_b60;
                *(undefined8 *)(puVar21 + -8) = 0x1010ca;
                func_0x(pbVar27,5);
                ppbVar24 = (byte **)(ulonglong)uStack_b64;
                uVar19 = uStack_b50;
                uVar20 = uStack_b50;
              }
            }
code_r0x001010d8:
            uStack_c30 = uVar19;
            pbVar27 = pbStack_b60;
            uStack_c44 = (uint)ppbVar24;
            uVar15 = uStack_c44;
            if ((uStack_c44 < 9) && (((*pbStack_b60 & 0xe) == 0 || ((*pbStack_b60 & 0xe) == 0xc))))
            {
              uVar15 = 9;
            }
            uStack_c46 = uStack_b66;
            uStack_c2c = uStack_b4c;
            ppbStack_c38 = uStack_b58;
            uStack_c22 = uStack_b42;
            uStack_c20 = uStack_b40;
            uStack_b50 = uVar20;
            *(undefined8 *)(puVar21 + -8) = 0x10114a;
            func_0x(lVar9,iVar8,pbVar27,uVar15);
            lStack_c40 = lVar9;
            *(undefined8 *)(puVar21 + -8) = 0x101157;
            iVar8 = func_0x(&uStack_c46);
            lVar9 = lStack_c40;
            if (iVar8 != 0) {
              puVar22 = (ushort *)(((ulonglong)ppbStack_c38 >> 0x20) + lStack_c40);
              uVar15 = *puVar22 - 1;
              if ((uStack_c46 & 1) == 0) {
                uVar15 = (uint)*puVar22;
              }
              uVar19 = uStack_c30;
              if (uVar15 != 1) {
                uVar19 = puVar22[(longlong)(int)uVar15 + -1] & 0x7fff;
              }
              if ((uVar19 < uStack_c30) || ((puVar22[(int)uVar15] & 0x7fff) < uVar19)) {
                *(undefined8 *)(puVar21 + -8) = 0x1011b2;
                func_0x(lVar9,7);
              }
              uStack_c1e = (short)uVar19;
              lVar9 = (ulonglong)(uVar19 & 0xffff) + lStack_c40;
              uVar7 = *(ushort *)(lVar9 + 2);
              if ((uVar7 >> 0xe & 1) == 0) {
                uStack_c1c = uStack_c1c & 0xc7ff;
              }
              else {
                uStack_c1c = uStack_c1c ^ (uVar7 ^ uStack_c1c) & 0x3800;
              }
              uStack_c1c = uStack_c1c ^ (uStack_c1c ^ *(ushort *)(lVar9 + 2)) & 0x7ff;
            }
          }
          else if ((uStack_b58 == (byte **)0x0) || (*uStack_b58 == (byte *)0x0)) {
            *(undefined8 *)(puVar21 + -8) = 0x10123e;
            func_0x(&uStack_c46,lVar9,iVar8,&uStack_b66);
            ppbStack_c38 = uStack_b58;
            if (sStack_b68 == 0) {
              ppbStack_c38 = ppbVar28;
            }
          }
          else {
            *(undefined8 *)(puVar21 + -8) = 0x101226;
            func_0x(&sStack_c48,lVar9,iVar8,&sStack_b68);
          }
          psVar10 = &sStack_c48;
          iVar8 = iStack_c58;
          if (psVar29 == (short *)0x0) goto code_r0x0010126b;
        }
        *(short *)(lStack_be0 + lStack_bd8 * 2) = (short)lStack_c50 - (short)lStack_bb0;
        if (*psVar29 == 0) {
          if (*(int *)(psVar29 + 2) == 0) {
            psVar29[1] = 0;
            uVar15 = *(uint *)(psVar29 + 8);
            uVar16 = (ulonglong)uVar15;
            *(uint *)(psVar29 + 10) = uVar15;
            pbVar27 = *(byte **)(psVar29 + 4);
            bVar17 = *pbVar27;
            if ((bVar17 & 0x10) != 0) {
              uVar15 = uVar15 + 2 + (*(ushort *)(pbVar27 + uVar16) + 7 >> 3);
              uVar16 = (ulonglong)uVar15;
              *(uint *)(psVar29 + 10) = uVar15;
              bVar17 = *pbVar27;
            }
            if ((bVar17 & 0x20) == 0) {
              *(int *)(psVar29 + 2) = (int)uVar16;
              psVar29[0xe] = 0;
              *(int *)(psVar29 + 0xc) = (int)uVar16;
            }
            else {
              puVar22 = (ushort *)(pbVar27 + uVar16);
              uVar7 = *puVar22;
              psVar29[0xe] = uVar7;
              if (uVar7 == 0) {
                if ((((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                    (lVar9 = *(longlong *)
                              ((ulonglong)*puRam00000000013a2b90 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0)) &&
                   ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                    *(undefined8 *)(puVar21 + -8) = 0x101389;
                    (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar21 + 0x20) = 0;
                    *(undefined8 *)(puVar21 + -8) = 0x1013af;
                    (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x80f);
                  }
                }
                uVar3 = *(undefined8 *)(psVar29 + 4);
                *(undefined8 *)(puVar21 + -8) = 0x1013bd;
                func_0x(uVar3,3);
                uVar16 = (ulonglong)*(uint *)(psVar29 + 10);
                uVar7 = psVar29[0xe];
              }
              uVar15 = (int)uVar16 + (uVar7 + 1) * 2;
              *(uint *)(psVar29 + 0xc) = uVar15;
              if (0x1f9e < uVar15) {
                if (((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                   ((lVar9 = *(longlong *)
                              ((ulonglong)*puRam00000000013a2b90 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0 &&
                    ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                     (*(char *)(lVar9 + 0x499) != '\0')))))) {
                  if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                    *(undefined8 *)(puVar21 + -8) = 0x10145b;
                    (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar21 + 0x20) = 0;
                    *(undefined8 *)(puVar21 + -8) = 0x101481;
                    (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x816);
                  }
                }
                uVar3 = *(undefined8 *)(psVar29 + 4);
                *(undefined8 *)(puVar21 + -8) = 0x10148f;
                func_0x(uVar3,4);
                uVar7 = psVar29[0xe];
                uVar15 = *(uint *)(psVar29 + 0xc);
              }
              uVar26 = (ulonglong)uVar7;
              uVar19 = puVar22[uVar26] & 0x7fff;
              *(uint *)(psVar29 + 2) = uVar19;
              if (uVar19 < uVar15) {
                if ((((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                    (lVar9 = *(longlong *)
                              ((ulonglong)*puRam00000000013a2b90 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0)) &&
                   ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                    *(undefined8 *)(puVar21 + -8) = 0x10152c;
                    (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar21 + 0x20) = 0;
                    *(undefined8 *)(puVar21 + -8) = 0x101552;
                    (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x81d);
                  }
                }
                uVar3 = *(undefined8 *)(psVar29 + 4);
                *(undefined8 *)(puVar21 + -8) = 0x101560;
                func_0x(uVar3,4);
                uVar26 = (ulonglong)(ushort)psVar29[0xe];
                uVar19 = *(uint *)(psVar29 + 2);
              }
              uVar16 = (ulonglong)uVar19;
              if ((short)puVar22[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                pbVar27 = *(byte **)(psVar29 + 4);
                do {
                  uVar15 = *(uint *)(psVar29 + 10);
                  if ((int)uVar26 == 1) {
                    uVar19 = *(uint *)(psVar29 + 0xc);
                    uVar7 = *(ushort *)(pbVar27 + uVar26 * 2 + (ulonglong)uVar15);
                    uVar20 = uVar19;
code_r0x001015bd:
                    if ((uVar7 & 0x7fff) < uVar19) goto code_r0x001015c1;
                  }
                  else {
                    uVar19 = *(ushort *)(pbVar27 + uVar26 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
                    uVar20 = *(uint *)(psVar29 + 0xc);
                    uVar7 = *(ushort *)(pbVar27 + uVar26 * 2 + (ulonglong)uVar15);
                    if (uVar20 <= uVar19) goto code_r0x001015bd;
code_r0x001015c1:
                    *(undefined8 *)(puVar21 + -8) = 0x1015ce;
                    func_0x(pbVar27,7);
                    uVar20 = *(uint *)(psVar29 + 0xc);
                  }
                  if ((uVar19 < uVar20) ||
                     (uVar16 = (ulonglong)*(uint *)(psVar29 + 2), *(uint *)(psVar29 + 2) < uVar19))
                  goto code_r0x001018be;
                  pbVar27 = *(byte **)(psVar29 + 4);
                  if (*(ushort *)(pbVar27 + uVar19) == 5) {
                    psVar29[1] = psVar29[1] | 2;
                    psVar29[0xe] = psVar29[0xe] + -1;
                    psVar29[0x15] = (short)uVar19;
                    lVar9 = (ulonglong)(uVar19 & 0xffff) + *(longlong *)(psVar29 + 4);
                    uVar7 = psVar29[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar9 + 2) >> 0xe & 1) != 0) {
                      uVar7 = *(ushort *)(lVar9 + 2) & 0x3800 | psVar29[0x16] & 0xc7ffU;
                    }
                    psVar29[0x16] = uVar7;
                    psVar29[0x16] = (uVar7 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar7;
                    uVar16 = (ulonglong)*(uint *)(psVar29 + 2);
                    goto code_r0x001016a1;
                  }
                  if (*(ushort *)(pbVar27 + uVar19) < 0x400) goto code_r0x001016a1;
                  psVar29[1] = psVar29[1] | 1;
                  uVar7 = psVar29[0xe] - 1;
                  psVar29[0xe] = uVar7;
                  if (uVar7 == 0) goto code_r0x001016a1;
                  uVar26 = (ulonglong)uVar7;
                } while ((short)puVar22[(ulonglong)(uVar7 - 1) + 1] < 0);
              }
              else {
code_r0x001016a1:
                pbVar27 = *(byte **)(psVar29 + 4);
              }
            }
            if ((*pbVar27 & 0x40) == 0) {
              *(undefined4 *)(psVar29 + 0x13) = 0;
            }
            else {
              *(int *)(psVar29 + 0x13) = (int)uVar16;
              *(int *)(psVar29 + 2) = (int)uVar16 + 0xe;
              *(undefined8 *)(puVar21 + -8) = 0x1016d0;
              puVar12 = (ulonglong *)func_0x(psVar29 + 1);
              uVar18 = (ushort)(*puVar12 >> 0x30);
              uVar7 = uVar18;
              if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
                uVar7 = uVar18 & 0xdfff;
                if ((uVar18 >> 0xe & 1) != 0) {
                  uVar7 = uVar18 | 0x2000;
                }
              }
              uVar15 = uVar23;
              if (uVar7 == 0xfffc) {
                uVar15 = (uint)((*puVar12 >> 0x20 & 0xffff) >> 5);
              }
              *(uint *)(psVar29 + 2) = *(int *)(psVar29 + 2) + uVar15;
              uVar16 = (ulonglong)*(uint *)(psVar29 + 2);
            }
            iVar14 = (int)uVar16;
            if ((*(ulonglong *)(psVar29 + 0xf) != 0) &&
               (*(ulonglong *)(psVar29 + 0xf) < uVar16 + *(longlong *)(psVar29 + 4))) {
              if (((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                 (((lVar9 = *(longlong *)
                             ((ulonglong)*puRam00000000013a2b90 +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0 &&
                   (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) &&
                  (*(char *)(lVar9 + 0x499) != '\0')))) {
                if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                  *(undefined8 *)(puVar21 + -8) = 0x1017ca;
                  (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar21 + 0x20) = 0;
                  *(undefined8 *)(puVar21 + -8) = 0x1017f0;
                  (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x877);
                }
              }
              uVar3 = *(undefined8 *)(psVar29 + 4);
              *(undefined8 *)(puVar21 + -8) = 0x1017fe;
              func_0x(uVar3,0x12);
              iVar14 = *(int *)(psVar29 + 2);
            }
            if (0x3f3b < iVar14 - 1U) {
              if (((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                 ((lVar9 = *(longlong *)
                            ((ulonglong)*puRam00000000013a2b90 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0 &&
                  ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                   (*(char *)(lVar9 + 0x499) != '\0')))))) {
                if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                  *(undefined8 *)(puVar21 + -8) = 0x10188a;
                  (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar21 + 0x20) = 0;
                  *(undefined8 *)(puVar21 + -8) = 0x1018b0;
                  (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x87c);
                }
              }
              uVar3 = *(undefined8 *)(psVar29 + 4);
              *(undefined8 *)(puVar21 + -8) = 0x1018be;
              func_0x(uVar3,5);
            }
          }
code_r0x001018be:
          uVar15 = *(uint *)(psVar29 + 2);
          uVar19 = uVar15;
          if (uVar15 < 9) {
            bVar17 = **(byte **)(psVar29 + 4) & 0xe;
joined_r0x001018fc:
            if ((bVar17 == 0) || (uVar19 = uVar15, bVar17 == 0xc)) {
              uVar19 = 9;
            }
          }
        }
        else {
          uVar15 = *(uint *)(psVar29 + 2);
          if (uVar15 == 0) {
            *(undefined8 *)(puVar21 + -8) = 0x1018e9;
            func_0x(psVar29 + 1);
            uVar15 = *(uint *)(psVar29 + 2);
          }
          uVar19 = uVar15;
          if (uVar15 < 9) {
            bVar17 = **(byte **)(psVar29 + 4) & 0x1c;
            goto joined_r0x001018fc;
          }
        }
        iVar8 = iVar8 - uVar19;
        iStack_c58 = iVar8;
        if (*psVar29 == 0) {
          if (uVar15 == 0) {
            psVar29[1] = 0;
            uVar15 = *(uint *)(psVar29 + 8);
            uVar16 = (ulonglong)uVar15;
            *(uint *)(psVar29 + 10) = uVar15;
            pbVar27 = *(byte **)(psVar29 + 4);
            bVar17 = *pbVar27;
            if ((bVar17 & 0x10) != 0) {
              uVar15 = uVar15 + 2 + (*(ushort *)(pbVar27 + uVar16) + 7 >> 3);
              uVar16 = (ulonglong)uVar15;
              *(uint *)(psVar29 + 10) = uVar15;
              bVar17 = *pbVar27;
            }
            if ((bVar17 & 0x20) == 0) {
              *(int *)(psVar29 + 2) = (int)uVar16;
              psVar29[0xe] = 0;
              *(int *)(psVar29 + 0xc) = (int)uVar16;
            }
            else {
              puVar22 = (ushort *)(pbVar27 + uVar16);
              uVar7 = *puVar22;
              psVar29[0xe] = uVar7;
              if (uVar7 == 0) {
                if ((((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                    (lVar9 = *(longlong *)
                              ((ulonglong)*puRam00000000013a2b90 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0)) &&
                   ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                    *(undefined8 *)(puVar21 + -8) = 0x1019ee;
                    (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar21 + 0x20) = 0;
                    *(undefined8 *)(puVar21 + -8) = 0x101a14;
                    (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x80f);
                  }
                }
                uVar3 = *(undefined8 *)(psVar29 + 4);
                *(undefined8 *)(puVar21 + -8) = 0x101a22;
                func_0x(uVar3,3);
                uVar16 = (ulonglong)*(uint *)(psVar29 + 10);
                uVar7 = psVar29[0xe];
              }
              uVar15 = (int)uVar16 + (uVar7 + 1) * 2;
              *(uint *)(psVar29 + 0xc) = uVar15;
              if (0x1f9e < uVar15) {
                if (((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                   ((lVar9 = *(longlong *)
                              ((ulonglong)*puRam00000000013a2b90 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0 &&
                    ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                     (*(char *)(lVar9 + 0x499) != '\0')))))) {
                  if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                    *(undefined8 *)(puVar21 + -8) = 0x101ac0;
                    (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar21 + 0x20) = 0;
                    *(undefined8 *)(puVar21 + -8) = 0x101ae6;
                    (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x816);
                  }
                }
                uVar3 = *(undefined8 *)(psVar29 + 4);
                *(undefined8 *)(puVar21 + -8) = 0x101af4;
                func_0x(uVar3,4);
                uVar7 = psVar29[0xe];
                uVar15 = *(uint *)(psVar29 + 0xc);
              }
              uVar26 = (ulonglong)uVar7;
              uVar19 = puVar22[uVar26] & 0x7fff;
              *(uint *)(psVar29 + 2) = uVar19;
              if (uVar19 < uVar15) {
                if ((((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                    (lVar9 = *(longlong *)
                              ((ulonglong)*puRam00000000013a2b90 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0)) &&
                   ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                    *(undefined8 *)(puVar21 + -8) = 0x101b91;
                    (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar21 + 0x20) = 0;
                    *(undefined8 *)(puVar21 + -8) = 0x101bb7;
                    (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x81d);
                  }
                }
                uVar3 = *(undefined8 *)(psVar29 + 4);
                *(undefined8 *)(puVar21 + -8) = 0x101bc5;
                func_0x(uVar3,4);
                uVar26 = (ulonglong)(ushort)psVar29[0xe];
                uVar19 = *(uint *)(psVar29 + 2);
              }
              uVar16 = (ulonglong)uVar19;
              if ((short)puVar22[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                pbVar27 = *(byte **)(psVar29 + 4);
                do {
                  uVar15 = *(uint *)(psVar29 + 10);
                  if ((int)uVar26 == 1) {
                    uVar19 = *(uint *)(psVar29 + 0xc);
                    uVar7 = *(ushort *)(pbVar27 + uVar26 * 2 + (ulonglong)uVar15);
                    uVar20 = uVar19;
code_r0x00101c2d:
                    if ((uVar7 & 0x7fff) < uVar19) goto code_r0x00101c31;
                  }
                  else {
                    uVar19 = *(ushort *)(pbVar27 + uVar26 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
                    uVar20 = *(uint *)(psVar29 + 0xc);
                    uVar7 = *(ushort *)(pbVar27 + uVar26 * 2 + (ulonglong)uVar15);
                    if (uVar20 <= uVar19) goto code_r0x00101c2d;
code_r0x00101c31:
                    *(undefined8 *)(puVar21 + -8) = 0x101c3e;
                    func_0x(pbVar27,7);
                    uVar20 = *(uint *)(psVar29 + 0xc);
                  }
                  if ((uVar19 < uVar20) ||
                     (uVar16 = (ulonglong)*(uint *)(psVar29 + 2), *(uint *)(psVar29 + 2) < uVar19))
                  goto code_r0x00101f2e;
                  pbVar27 = *(byte **)(psVar29 + 4);
                  if (*(ushort *)(pbVar27 + uVar19) == 5) {
                    psVar29[1] = psVar29[1] | 2;
                    psVar29[0xe] = psVar29[0xe] + -1;
                    psVar29[0x15] = (short)uVar19;
                    lVar9 = (ulonglong)(uVar19 & 0xffff) + *(longlong *)(psVar29 + 4);
                    uVar7 = psVar29[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar9 + 2) >> 0xe & 1) != 0) {
                      uVar7 = *(ushort *)(lVar9 + 2) & 0x3800 | psVar29[0x16] & 0xc7ffU;
                    }
                    psVar29[0x16] = uVar7;
                    psVar29[0x16] = (uVar7 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar7;
                    uVar16 = (ulonglong)*(uint *)(psVar29 + 2);
                    goto code_r0x00101d11;
                  }
                  if (*(ushort *)(pbVar27 + uVar19) < 0x400) goto code_r0x00101d11;
                  psVar29[1] = psVar29[1] | 1;
                  uVar7 = psVar29[0xe] - 1;
                  psVar29[0xe] = uVar7;
                  if (uVar7 == 0) goto code_r0x00101d11;
                  uVar26 = (ulonglong)uVar7;
                } while ((short)puVar22[(ulonglong)(uVar7 - 1) + 1] < 0);
              }
              else {
code_r0x00101d11:
                pbVar27 = *(byte **)(psVar29 + 4);
              }
            }
            if ((*pbVar27 & 0x40) == 0) {
              *(undefined4 *)(psVar29 + 0x13) = 0;
            }
            else {
              *(int *)(psVar29 + 0x13) = (int)uVar16;
              *(int *)(psVar29 + 2) = (int)uVar16 + 0xe;
              *(undefined8 *)(puVar21 + -8) = 0x101d40;
              puVar12 = (ulonglong *)func_0x(psVar29 + 1);
              uVar18 = (ushort)(*puVar12 >> 0x30);
              uVar7 = uVar18;
              if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
                uVar7 = uVar18 & 0xdfff;
                if ((uVar18 >> 0xe & 1) != 0) {
                  uVar7 = uVar18 | 0x2000;
                }
              }
              if (uVar7 == 0xfffc) {
                uVar23 = (uint)((*puVar12 >> 0x20 & 0xffff) >> 5);
              }
              *(uint *)(psVar29 + 2) = *(int *)(psVar29 + 2) + uVar23;
              uVar16 = (ulonglong)*(uint *)(psVar29 + 2);
            }
            iVar14 = (int)uVar16;
            if ((*(ulonglong *)(psVar29 + 0xf) != 0) &&
               (*(ulonglong *)(psVar29 + 0xf) < uVar16 + *(longlong *)(psVar29 + 4))) {
              if (((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                 (((lVar9 = *(longlong *)
                             ((ulonglong)*puRam00000000013a2b90 +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0 &&
                   (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) &&
                  (*(char *)(lVar9 + 0x499) != '\0')))) {
                if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                  *(undefined8 *)(puVar21 + -8) = 0x101e3a;
                  (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar21 + 0x20) = 0;
                  *(undefined8 *)(puVar21 + -8) = 0x101e60;
                  (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x877);
                }
              }
              uVar3 = *(undefined8 *)(psVar29 + 4);
              *(undefined8 *)(puVar21 + -8) = 0x101e6e;
              func_0x(uVar3,0x12);
              iVar14 = *(int *)(psVar29 + 2);
            }
            if (0x3f3b < iVar14 - 1U) {
              if (((cRam0000000001e342fb != '\0') || ((bRam0000000001e44c00 & 1) != 0)) &&
                 ((lVar9 = *(longlong *)
                            ((ulonglong)*puRam00000000013a2b90 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000013a2b88 * 8) + 8), lVar9 != 0 &&
                  ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                   (*(char *)(lVar9 + 0x499) != '\0')))))) {
                if ((cRam0000000001e341eb == '\0') && ((bRam0000000001e44c00 & 2) == 0)) {
                  *(undefined8 *)(puVar21 + -8) = 0x101efa;
                  (*pcRam00000000013a2b28)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar21 + 0x20) = 0;
                  *(undefined8 *)(puVar21 + -8) = 0x101f20;
                  (*pcRam00000000013a2b20)(1,0x1724d28,0x18449f8,0x87c);
                }
              }
              uVar3 = *(undefined8 *)(psVar29 + 4);
              *(undefined8 *)(puVar21 + -8) = 0x101f2e;
              func_0x(uVar3,5);
            }
          }
code_r0x00101f2e:
          uVar15 = *(uint *)(psVar29 + 2);
          if (uVar15 < 9) {
            bVar17 = **(byte **)(psVar29 + 4) & 0xe;
joined_r0x00101f68:
            if ((bVar17 == 0) || (bVar17 == 0xc)) {
              uVar15 = 9;
            }
          }
        }
        else {
          if (uVar15 == 0) {
            *(undefined8 *)(puVar21 + -8) = 0x101f55;
            func_0x(psVar29 + 1);
            uVar15 = *(uint *)(psVar29 + 2);
          }
          if (uVar15 < 9) {
            bVar17 = **(byte **)(psVar29 + 4) & 0x1c;
            goto joined_r0x00101f68;
          }
        }
        lStack_c50 = lStack_c50 + (ulonglong)uVar15;
        if (0x1f9e < iStack_bfc - iVar8) goto LAB_;
        ppbVar25 = (byte **)(ulonglong)uStack_bf8;
        param_1 = lStack_be8;
        param_5 = lStack_be0;
        param_4 = iStack_bfc;
      }
      uStack_c54 = uStack_c54 + 1;
      ppbVar24 = (byte **)(ulonglong)uStack_c54;
      lStack_bd8 = lStack_bd8 + 1;
    } while ((int)uStack_c54 < *(int *)(param_1 + 8));
    iVar14 = (int)ppbVar25;
    if (iVar14 != 0) {
      *(double *)(param_1 + 0x1ff0) = (double)((param_4 - iVar8) / iVar14);
      lVar9 = *plStack_bc8;
      if (lVar9 != 0) {
        *(undefined8 *)(puVar21 + -8) = 0x101ff9;
        func_0x(lVar9,(longlong)(param_4 - iVar8) % (longlong)iVar14 & 0xffffffff);
      }
    }
  }
LAB_:
  uVar3 = uStack_a90;
  if (uStack_a98._2_2_ != 0) {
    *(undefined8 *)(puVar21 + -8) = 0x102021;
    (*_DAT_)(uVar3);
    uVar3 = uStack_a88;
    *(undefined8 *)(puVar21 + -8) = 0x10202e;
    (*_DAT_)(uVar3);
  }
  uVar16 = uStack_58 ^ (ulonglong)&iStack_c58;
  *(undefined8 *)(puVar21 + -8) = 0x102040;
  func_0x(uVar16);
  return;
}

