
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,longlong param_2)

{
  int iVar1;
  undefined4 uVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined auStack_608 [32];
  undefined8 uStack_5e8;
  undefined8 uStack_5e0;
  undefined8 uStack_5d8;
  undefined4 uStack_5d0;
  int iStack_5c8;
  longlong lStack_5c0;
  undefined8 uStack_5b8;
  longlong *plStack_5b0;
  undefined4 uStack_5a8;
  uint uStack_5a4;
  undefined4 uStack_5a0;
  undefined4 uStack_59c;
  undefined4 uStack_598;
  uint uStack_594;
  undefined4 uStack_590;
  undefined4 uStack_58c;
  undefined4 uStack_588;
  uint uStack_584;
  undefined4 uStack_580;
  undefined4 uStack_57c;
  undefined4 uStack_578;
  undefined4 uStack_568;
  undefined2 uStack_564;
  undefined4 uStack_460;
  undefined2 uStack_45c;
  undefined4 uStack_250;
  undefined2 uStack_24c;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  ulonglong uStack_18;
  
  uStack_5b8 = 0xfffffffffffffffe;
  uStack_18 = _DAT_ ^ (ulonglong)auStack_608;
  uStack_5a4 = _DAT_;
  uStack_5a0 = uRam000000000086268c;
  uStack_59c = uRam0000000000862690;
  uStack_598 = uRam0000000000862694;
  uStack_594 = _DAT_;
  uStack_590 = uRam000000000086268c;
  uStack_58c = uRam0000000000862690;
  uStack_588 = uRam0000000000862694;
  uStack_584 = _DAT_;
  uStack_580 = uRam000000000086268c;
  uStack_57c = uRam0000000000862690;
  uStack_578 = uRam0000000000862694;
  lVar5 = 0;
  uVar2 = 0;
  uStack_568 = 0;
  uStack_564 = 0;
  uStack_460 = 0;
  uStack_45c = 0;
  uStack_250 = 0;
  uStack_24c = 0;
  uStack_2c = _DAT_;
  uStack_28 = uRam000000000086268c;
  uStack_24 = uRam0000000000862690;
  uStack_20 = uRam0000000000862694;
  switch(*(undefined4 *)(param_2 + 0x28)) {
  case 0xfa3:
    lVar5 = param_1[0x192];
    uVar2 = *(undefined4 *)(lVar5 + 0x5d0);
    uStack_5e8 = CONCAT44(uStack_5e8._4_4_,3);
    goto code_r0x001000ca;
  default:
    uVar4 = (**(code **)*param_1)(param_1,*(undefined4 *)(param_2 + 0x28));
    func_0x(param_1,0xbf62a8,uVar4);
    break;
  case 0xfa6:
    if ((*(longlong *)(param_2 + 0x48) != 0) &&
       (lVar5 = *(longlong *)(*(longlong *)(param_2 + 0x48) + 0x28), lVar5 != 0)) {
      uVar2 = *(undefined4 *)(lVar5 + 0x38);
    }
    uStack_5a8 = 0;
    uStack_5a4 = _DAT_ & 0xffff0000;
    plVar3 = (longlong *)func_0x(param_1[0x192]);
    plStack_5b0 = plVar3;
    if (plVar3 != (longlong *)0x0) {
      uStack_5e8 = CONCAT44(uStack_5e8._4_4_,uVar2);
      func_0x(plVar3,0x594,0x62,&uStack_5a8);
      (**(code **)(*plVar3 + 0x10))(plVar3);
    }
    break;
  case 0xfaa:
    iVar1 = func_0x(param_1[0x192] + 0x5ab0,param_2);
    if (iVar1 == 0) break;
    lVar5 = *(longlong *)(param_1[0x192] + 0x1a628);
    uStack_5d8 = *(longlong *)(lVar5 + 0x58);
    uStack_5e0 = CONCAT44(uStack_5e0._4_4_,*(undefined4 *)(lVar5 + 0x54));
    uStack_5e8 = CONCAT44(uStack_5e8._4_4_,0x29);
    uVar4 = 0x1b;
    goto code_r0x001000d7;
  case 0xfac:
    if (*(longlong *)(param_2 + 0x48) != 0) {
      lVar5 = *(longlong *)(*(longlong *)(param_2 + 0x48) + 0x28);
    }
    if (*(int *)(lVar5 + 0x3c) == 0x57c) {
      func_0x(param_1[0x192],2,0xfa,*(undefined8 *)(param_2 + 0x50));
      break;
    }
    iStack_5c8 = *(int *)(lVar5 + 0x4c);
    if (iStack_5c8 == 0) {
      lStack_5c0 = 0xbf47e0;
      iStack_5c8 = 0xc;
    }
    else {
      lStack_5c0 = lVar5 + 0x50;
    }
    uStack_5d0 = *(undefined4 *)(lVar5 + 0x40);
    uStack_5d8 = CONCAT44(uStack_5d8._4_4_,*(undefined4 *)(lVar5 + 0x44));
    uStack_5e8 = 0xbf82a0;
    uStack_5e0._0_4_ = *(int *)(lVar5 + 0x3c);
    func_0x(0xe,0x23,*(undefined4 *)(lVar5 + 0x44),1);
    lVar5 = *(longlong *)(param_1[0x192] + 0x1a628);
    uStack_5d8 = *(longlong *)(lVar5 + 0x58);
    uStack_5e0 = CONCAT44(uStack_5e0._4_4_,*(undefined4 *)(lVar5 + 0x54));
    uStack_5e8 = CONCAT44(uStack_5e8._4_4_,1);
    uVar4 = 0x1b;
    goto code_r0x001000d7;
  case 0xfb0:
    *(undefined4 *)(*(longlong *)(param_2 + 0x50) + 0x68) = 2;
    uStack_5e0 = 0;
    uStack_5e8 = *(undefined8 *)(param_2 + 0x50);
    func_0x(param_1[0x192] + 0x3140,0x3fa,param_1[0x192],0);
    *(undefined4 *)(param_1 + 0x193) = 2;
    goto code_r0x001000e6;
  case 0xfb2:
    if (*(int *)(param_1[0x192] + 0x5c4) == 0) {
      func_0x(param_1,param_2);
    }
    else {
      uVar2 = func_0x(&uStack_5a8,param_1[0x192],3);
      *(undefined4 *)((longlong)param_1 + 0xcac) = 2;
      uStack_5e8 = CONCAT44(uStack_5e8._4_4_,3);
      func_0x(param_1[0x192],1,&uStack_5a8,uVar2);
      func_0x(param_1,0x13bfe80,*(undefined8 *)(param_2 + 0x50));
    }
    break;
  case 0xfb5:
    goto code_r0x001000e6;
  case 0xfba:
    func_0x(param_1,param_2);
    break;
  case 0xfbb:
    lVar5 = param_1[0x192];
    uVar2 = *(undefined4 *)(lVar5 + 0x5d0);
    uStack_5e8 = CONCAT44(uStack_5e8._4_4_,0x3f);
code_r0x001000ca:
    uStack_5d8 = lVar5 + 0x5d4;
    uStack_5e0 = CONCAT44(uStack_5e0._4_4_,uVar2);
    uVar4 = 0x12;
    lVar5 = *(longlong *)(lVar5 + 0x1a628);
code_r0x001000d7:
    func_0x(lVar5,0xe,uVar4);
code_r0x001000e6:
    func_0x(param_1,0x13c01e0,*(undefined8 *)(param_2 + 0x50));
  }
  func_0x(uStack_18 ^ (ulonglong)auStack_608);
  return;
}

