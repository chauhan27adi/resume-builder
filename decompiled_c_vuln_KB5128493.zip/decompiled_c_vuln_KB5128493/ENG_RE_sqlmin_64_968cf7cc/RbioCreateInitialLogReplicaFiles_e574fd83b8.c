
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,longlong param_3,longlong param_4,int param_5,
                 undefined4 param_6)

{
  byte *pbVar1;
  byte *pbVar2;
  uint *puVar3;
  byte bVar4;
  code *pcVar5;
  undefined4 *puVar6;
  longlong *plVar7;
  char cVar8;
  undefined4 uVar9;
  longlong lVar10;
  longlong lVar11;
  undefined8 uVar12;
  longlong *plVar13;
  short *psVar14;
  byte **ppbVar15;
  ulonglong *puVar16;
  longlong lVar17;
  byte bVar18;
  ushort uVar19;
  int iVar20;
  ushort uVar21;
  uint uVar22;
  uint uVar23;
  byte **ppbVar24;
  uint uVar25;
  ushort *puVar26;
  uint uVar27;
  longlong lVar28;
  longlong lVar29;
  short sVar30;
  ulonglong uVar31;
  undefined2 uVar32;
  byte **ppbVar33;
  byte **ppbVar34;
  ulonglong uVar35;
  ulonglong uVar36;
  longlong unaff_GS_OFFSET;
  longlong lStackX_8;
  uint uStackX_10;
  ushort uStackX_14;
  ushort uStackX_16;
  undefined8 uStackX_18;
  int iStackX_20;
  int iStackX_24;
  undefined4 uStack_d348;
  undefined2 uStack_d344;
  uint uStack_d340;
  uint uStack_d33c;
  ulonglong uStack_d338;
  undefined8 uStack_d330;
  undefined2 uStack_d328;
  undefined8 uStack_d320;
  undefined2 uStack_d318;
  undefined8 uStack_d310;
  undefined2 uStack_d308;
  undefined4 uStack_d300;
  undefined2 uStack_d2fc;
  undefined4 uStack_d2f8;
  undefined2 uStack_d2f4;
  undefined4 uStack_d2f0;
  undefined2 uStack_d2ec;
  ulonglong uStack_d2e8;
  ulonglong uStack_d2e0;
  longlong *plStack_d2d8;
  longlong *plStack_d2d0;
  undefined8 uStack_d2c8;
  undefined auStack_d2c0 [8];
  longlong lStack_d2b8;
  longlong *plStack_d298;
  undefined8 uStack_d290;
  short sStack_d270;
  ushort uStack_d26e;
  uint uStack_d26c;
  byte *pbStack_d268;
  undefined8 uStack_d260;
  undefined4 uStack_d258;
  ushort uStack_d254;
  undefined2 uStack_d252;
  undefined6 uStack_d250;
  undefined2 uStack_d24a;
  undefined2 uStack_d248;
  undefined2 uStack_d246;
  ushort uStack_d244;
  undefined2 uStack_d242;
  undefined4 uStack_d240;
  undefined4 uStack_d23c;
  undefined auStack_d238 [16];
  undefined auStack_d228 [8];
  undefined8 uStack_d220;
  undefined8 uStack_d218;
  undefined6 uStack_d210;
  undefined2 uStack_d20a;
  undefined6 uStack_d208;
  undefined2 uStack_d202;
  undefined8 uStack_d200;
  undefined auStack_d1f8 [16];
  undefined auStack_d1e8 [16];
  undefined auStack_d1d8 [16];
  undefined8 uStack_d1c8;
  short sStack_d1c0;
  ushort uStack_d1be;
  uint uStack_d1bc;
  byte **ppbStack_d1b8;
  undefined8 uStack_d1b0;
  undefined4 uStack_d1a8;
  ushort uStack_d1a4;
  undefined2 uStack_d1a2;
  undefined6 uStack_d1a0;
  undefined2 uStack_d19a;
  undefined2 uStack_d198;
  undefined2 uStack_d196;
  ushort uStack_d194;
  undefined2 uStack_d192;
  undefined4 uStack_d190;
  undefined4 uStack_d18c;
  undefined auStack_d188 [16];
  undefined auStack_d178 [8];
  undefined8 uStack_d170;
  undefined8 uStack_d168;
  undefined6 uStack_d160;
  undefined2 uStack_d15a;
  undefined6 uStack_d158;
  undefined2 uStack_d152;
  undefined8 uStack_d150;
  undefined auStack_d148 [16];
  undefined auStack_d138 [16];
  undefined auStack_d128 [16];
  undefined8 uStack_d118;
  short sStack_d110;
  ushort uStack_d10e;
  uint uStack_d10c;
  byte **ppbStack_d108;
  undefined8 uStack_d100;
  undefined4 uStack_d0f8;
  ushort uStack_d0f4;
  undefined2 uStack_d0f2;
  undefined6 uStack_d0f0;
  undefined2 uStack_d0ea;
  undefined2 uStack_d0e8;
  undefined2 uStack_d0e6;
  ushort uStack_d0e4;
  undefined2 uStack_d0e2;
  undefined4 uStack_d0e0;
  undefined4 uStack_d0dc;
  undefined auStack_d0d8 [16];
  undefined auStack_d0c8 [8];
  undefined8 uStack_d0c0;
  undefined8 uStack_d0b8;
  undefined6 uStack_d0b0;
  undefined2 uStack_d0aa;
  undefined6 uStack_d0a8;
  undefined2 uStack_d0a2;
  undefined8 uStack_d0a0;
  undefined auStack_d098 [16];
  undefined auStack_d088 [16];
  undefined auStack_d078 [16];
  undefined8 uStack_d068;
  undefined auStack_d058 [12287];
  undefined auStack_a059 [16384];
  undefined auStack_6059 [16384];
  undefined auStack_2059 [8193];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  uStack_d290 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar10);
  ppbVar24 = (byte **)0x0;
  *(undefined4 *)((longlong)&param_5 + lVar10) = 0;
  uStack_d2e0 = (ulonglong)auStack_6059 & 0xffffffffffffe000;
  uVar35 = (ulonglong)auStack_2059 & 0xffffffffffffe000;
  lVar28 = -1;
  sStack_d110 = -1;
  ppbStack_d108 = (byte **)0x0;
  uStack_d10c = 0;
  uStack_d0f2 = 0;
  uStack_d0f0 = 0;
  uStack_d0e8 = 0;
  uStack_d0e6 = 0;
  uStack_d0e4 = 0;
  uStack_d0e2 = 0;
  uStack_d100 = (byte **)0x0;
  sStack_d1c0 = -1;
  ppbStack_d1b8 = (byte **)0x0;
  uStack_d1bc = 0;
  uStack_d1a2 = 0;
  uStack_d1a0 = 0;
  uStack_d198 = 0;
  uStack_d196 = 0;
  uStack_d194 = 0;
  uStack_d192 = 0;
  uStack_d1b0 = (byte **)0x0;
  sStack_d270 = -1;
  pbStack_d268 = (byte *)0x0;
  uStack_d26c = 0;
  uStack_d252 = 0;
  uStack_d250 = 0;
  uStack_d248 = 0;
  uStack_d246 = 0;
  uStack_d244 = 0;
  uStack_d242 = 0;
  uStack_d260 = (byte **)0x0;
  uStack_d23c = 0xffffffff;
  puVar26 = (ushort *)((longlong)&uStackX_14 + lVar10 + 2);
  *puVar26 = *puVar26 & 0xffe0;
  *(longlong *)((longlong)&lStackX_8 + lVar10) = (longlong)&param_5 + lVar10;
  uStack_d338 = (ulonglong)auStack_a059 & 0xffffffffffffe000;
  uStack_d2e8 = uVar35;
  uStack_d2c8 = param_1;
  lStack_d2b8 = param_4;
  *(undefined8 *)((longlong)&iStackX_20 + lVar10 + -0x20) = 0;
  (&stack0xfffffffffffffff8)[lVar10] = 0;
  (&stack0xfffffffffffffff0)[lVar10] = 0;
  (&stack0xffffffffffffffe8)[lVar10] = 0;
  (&stack0xffffffffffffffe0)[lVar10] = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10013b;
  lVar11 = func_0x(param_3,2,3,0);
  if (lVar11 == -1) {
    do {
      lVar28 = lVar28 + 1;
    } while (*(short *)(param_3 + lVar28 * 2) != 0);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100166;
    uVar12 = (*_DAT_)(*(undefined4 *)((longlong)&param_5 + lVar10),auStack_d058,0,0);
    *(int *)(&stack0xfffffffffffffff0 + lVar10) = (int)lVar28 * 2;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar10) = param_3;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = uVar12;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10018a;
    (*_DAT_)(0x33,0x17,0x10,0x42);
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100193;
  (*_DAT_)(lVar11);
  uVar12 = uStack_d2c8;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1001a5;
  plVar13 = (longlong *)func_0x(uStack_d2c8,param_3,0);
  lVar11 = -1;
  do {
    lVar11 = lVar11 + 1;
  } while (*(short *)(param_3 + lVar11 * 2) != 0);
  lVar28 = *plVar13;
  *(undefined4 *)((longlong)&lStackX_8 + lVar10) = 1;
  plStack_d2d0 = plVar13;
  *(undefined4 *)((longlong)&iStackX_20 + lVar10 + -0x20) = 2;
  *(ulonglong *)(&stack0xfffffffffffffff8 + lVar10) = lVar11 * 2 & 0xffffffff;
  *(longlong *)(&stack0xfffffffffffffff0 + lVar10) = param_3;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0x11ebb20;
  pcVar5 = *(code **)(lVar28 + 0x68);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100202;
  (*pcVar5)(plVar13,0,0,1);
  pcVar5 = *(code **)(*plVar13 + 0x50);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10020b;
  (*pcVar5)(plVar13);
  pcVar5 = *(code **)(*plVar13 + 0x60);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10021d;
  (*pcVar5)(plVar13,0x10,1);
  pcVar5 = *(code **)(*plVar13 + 0x20);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100232;
  (*pcVar5)(plVar13,0,0,0x10);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100240;
  plVar13 = (longlong *)func_0x(uVar12,param_2,0);
  lVar11 = -1;
  do {
    lVar11 = lVar11 + 1;
  } while (*(short *)(param_2 + lVar11 * 2) != 0);
  lVar28 = *plVar13;
  *(undefined4 *)((longlong)&lStackX_8 + lVar10) = 1;
  plStack_d2d8 = plVar13;
  *(undefined4 *)((longlong)&iStackX_20 + lVar10 + -0x20) = 0x42;
  *(ulonglong *)(&stack0xfffffffffffffff8 + lVar10) = lVar11 * 2 & 0xffffffff;
  *(longlong *)(&stack0xfffffffffffffff0 + lVar10) = param_2;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0x11ebb20;
  pcVar5 = *(code **)(lVar28 + 0x68);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1002a6;
  (*pcVar5)(plVar13,0,0,2);
  *(undefined4 *)(&stack0x0000002c + lVar10) = 0;
  *(undefined2 *)((longlong)&param_6 + lVar10) = 2;
  pcVar5 = *(code **)(*plVar13 + 0x50);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1002bd;
  (*pcVar5)(plVar13);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1002d0;
  func_0x(plVar13,0,uVar35,&stack0x0000002c + lVar10);
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) = 1;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1002ef;
  lVar11 = func_0x(_DAT_,0,3,0x26);
  uVar12 = *(undefined8 *)(*(longlong *)(lVar11 + 0x1210) + 0x6a0);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100308;
  uVar12 = func_0x(uVar12,1,0);
  uVar23 = 0;
  *(undefined4 *)(&stack0x0000002c + lVar10) = 0;
  *(undefined2 *)((longlong)&param_6 + lVar10) = 1;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100329;
  func_0x(uVar12,0,(ulonglong)auStack_a059 & 0xffffffffffffe000,&stack0x0000002c + lVar10);
  uStack_d0dc = 0;
  ppbVar33 = (byte **)0xf;
  ppbVar34 = ppbVar24;
  if (*(char *)(uVar35 + 2) < '\0') {
    pbVar1 = (byte *)(uVar35 + 0x60);
    if ((sStack_d110 == 0) || (ppbVar34 = uStack_d100, uStack_d100 == (byte **)0x0)) {
      uStack_d0b0 = 0;
      uStack_d0a2 = 0;
      auStack_d088 = ZEXT816(0);
      auStack_d0d8 = ZEXT816(0);
      stack0xffffffffffff2f3a = SUB1614(ZEXT816(0),2);
      auStack_d0c8._0_2_ = 0xffff;
      uStack_d0c0 = 0;
      uStack_d0aa = 0;
      uStack_d0a8 = 0;
      uStack_d0a0 = 0;
      uStack_d0b8 = 0;
      auStack_d098 = ZEXT816(0);
      auStack_d078._0_12_ = ZEXT812(0);
      auStack_d078._12_4_ = 0;
      uStack_d068 = 0;
      ppbVar34 = (byte **)auStack_d0d8;
    }
    if (*(short *)(uVar35 + 0x24) == 0) {
LAB_:
      uStack_d330 = *(undefined8 *)(uVar35 + 0x28);
      uStack_d328 = *(undefined2 *)(uVar35 + 0x30);
    }
    else {
      cVar8 = *(char *)(uVar35 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(uVar35 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar35 + 0x18) != 99) goto LAB_;
      }
      uStack_d300 = *(undefined4 *)(uVar35 + 0x20);
      uStack_d2fc = *(undefined2 *)(uVar35 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100444;
      cVar8 = func_0x(&uStack_d300,0x11e3298);
      if (cVar8 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100454;
      func_0x(uVar35,&uStack_d330);
    }
    *ppbVar34 = pbVar1;
    *(undefined4 *)(ppbVar34 + 0xc) = (undefined4)uStack_d330;
    *(int *)((longlong)ppbVar34 + 100) = (int)((ulonglong)uStack_d330 >> 0x20);
    *(undefined2 *)(ppbVar34 + 0xd) = uStack_d328;
    *(undefined4 *)((longlong)ppbVar34 + 0x6c) = *(undefined4 *)(uVar35 + 0x20);
    *(undefined2 *)(ppbVar34 + 0xe) = *(undefined2 *)(uVar35 + 0x24);
    *(undefined2 *)((longlong)ppbVar34 + 0x72) = 0;
    bVar18 = *pbVar1;
    *(undefined4 *)(&stack0x00000034 + lVar10) = *(undefined4 *)((ulonglong)bVar18 * 6 + 0x12638a0);
    uVar36 = (ulonglong)*(short *)((ulonglong)bVar18 * 6 + 0x12638a4);
    *(undefined2 *)(ppbVar34 + 2) = 0xffff;
    ppbVar34[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar34 + 0x2e) = 0;
    ppbVar34[7] = (byte *)0x0;
    ppbVar34[4] = (byte *)0x0;
    ppbVar34[9] = (byte *)0x0;
    ppbVar34[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar34 + 0xb) = 0;
    if ((**ppbVar34 & 2) != 0) {
      pbVar2 = pbVar1 + uVar36;
      if ((*pbVar2 & 1) == 0) {
        *(undefined2 *)(ppbVar34 + 2) = 0;
        ppbVar34[3] = pbVar2;
        *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar34 + 0x36) = 0;
        uVar22 = uVar23;
        switch(*pbVar2 & 0xe) {
        default:
          uVar22 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1006e1;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar22 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar22 = 1;
        }
        *(uint *)(ppbVar34 + 4) = uVar22;
        *(undefined8 *)((longlong)ppbVar34 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar34 + 2) = 1;
        ppbVar34[3] = pbVar2;
        bVar18 = *pbVar2;
        switch(bVar18 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar19 = *(ushort *)(pbVar2 + 1);
            *(ushort *)((longlong)ppbVar34 + 0x12) = uVar19;
            sVar30 = 3;
            uVar19 = (uVar19 & 0x7f) << 8 | uVar19 >> 8;
          }
          else {
            sVar30 = 2;
            uVar19 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar34 + 0x12) = uVar19;
          *(short *)(ppbVar34 + 5) = sVar30;
          *(short *)((longlong)ppbVar34 + 0x2c) =
               (short)(*(ushort *)((longlong)ppbVar34 + 0x12) + 1 >> 1) + sVar30;
          if (*(ushort *)((longlong)ppbVar34 + 0x12) < 0x1f) {
            *(undefined2 *)((longlong)ppbVar34 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          else {
            iVar20 = *(ushort *)((longlong)ppbVar34 + 0x12) - 1;
            *(short *)((longlong)ppbVar34 + 0x2a) =
                 ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                 (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar18 & 0x1c) != 4) || (uVar22 = 1, (bVar18 & 2) == 0)) {
            uVar22 = uVar23;
          }
          *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
          ppbVar34[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar34 + 0x12) = 0;
          ppbVar34[6] = (byte *)0x0;
          ppbVar34[4] = (byte *)0x0;
          *(undefined4 *)(ppbVar34 + 8) = 0;
          ppbVar34[7] = (byte *)0x0;
          ppbVar34[3] = pbVar2;
          if (uVar22 == 0) {
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 1;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          else {
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0xf;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            *(undefined4 *)(ppbVar34 + 8) = 1;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          break;
        case 8:
          ppbVar34[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar34 + 0x12) = 0;
          ppbVar34[6] = (byte *)0x0;
          ppbVar34[4] = (byte *)0x0;
          ppbVar34[7] = (byte *)0x0;
          ppbVar34[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar34 + 0x14) = 9;
          *(undefined4 *)(ppbVar34 + 8) = 0;
          ppbVar34[7] = (byte *)0x0;
          ppbVar34[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar34 & 4) != 0) {
      if (*(short *)(&stack0x00000036 + lVar10) != 0) {
        uVar36 = (ulonglong)
                 *(ushort *)(uVar35 + 0x61 + (longlong)*(short *)(&stack0x00000036 + lVar10) * 2);
      }
      psVar14 = (short *)(pbVar1 + uVar36);
      ppbVar34[9] = (byte *)psVar14;
      sVar30 = *psVar14;
      ppbVar34[10] = (byte *)(psVar14 + 1);
      *(short *)(ppbVar34 + 0xb) = (sVar30 + 1) * 2;
    }
    pbVar1 = ppbVar34[1];
    uVar35 = uStack_d2e8;
    if (pbVar1 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100775;
      func_0x(pbVar1,ppbVar34);
      uVar35 = uStack_d2e8;
    }
  }
  uVar22 = (uint)*(ushort *)(uVar35 + 0xe);
  ppbStack_d108 = (byte **)(*(ushort *)(uVar35 + 0x1ffe) + uVar35);
  if ((*(byte *)ppbStack_d108 & 1) == 0) {
    sStack_d110 = 0;
    uStack_d10c = 0;
    uStack_d0ea = 0;
    uStack_d0e8 = 0;
    switch(*(byte *)ppbStack_d108 & 0xe) {
    default:
      uVar22 = (uint)*(ushort *)((longlong)ppbStack_d108 + 2);
      if (0x1f9d < *(ushort *)((longlong)ppbStack_d108 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100989;
        func_0x(ppbStack_d108,6);
      }
      break;
    case 4:
      uVar22 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar22 = 1;
    }
    uStack_d100 = (byte **)CONCAT44(uStack_d100._4_4_,uVar22);
    uStack_d0f2 = (undefined2)(uVar35 + 0x2000);
    uStack_d0f0 = (undefined6)(uVar35 + 0x2000 >> 0x10);
  }
  else {
    sStack_d110 = 1;
    bVar18 = *(byte *)ppbStack_d108;
    switch(bVar18 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)ppbStack_d108 + 1) < '\0') {
        uStack_d10e = (*(ushort *)((longlong)ppbStack_d108 + 1) & 0x7f) << 8 |
                      *(ushort *)((longlong)ppbStack_d108 + 1) >> 8;
        uStack_d0f8._0_2_ = 3;
        sVar30 = 3;
      }
      else {
        uStack_d10e = (ushort)*(byte *)((longlong)ppbStack_d108 + 1);
        uStack_d0f8._0_2_ = 2;
        sVar30 = 2;
      }
      uStack_d0f4 = (short)(uStack_d10e + 1 >> 1) + sVar30;
      if (uStack_d10e < 0x1f) {
        uStack_d0f8._2_2_ = 0;
        uStack_d10c = 0;
        uStack_d0e0 = 0;
      }
      else {
        iVar20 = uStack_d10e - 1;
        uStack_d0f8._2_2_ =
             ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
             (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
        uStack_d10c = 0;
        uStack_d0e0 = 0;
      }
      break;
    case 4:
      if (((bVar18 & 0x1c) == 4) && ((bVar18 & 2) != 0)) {
        uStack_d0f8._0_2_ = 0;
        uStack_d0f8._2_2_ = 0;
        uStack_d0f4 = 0;
        uStack_d0f2 = 0;
        uStack_d10e = 0;
        uStack_d0f0 = 0;
        uStack_d0ea = 0;
        uStack_d10c = 0xf;
        uStack_d0e0 = 1;
      }
      else {
        uStack_d0f8._0_2_ = 0;
        uStack_d0f8._2_2_ = 0;
        uStack_d0f4 = 0;
        uStack_d0f2 = 0;
        uStack_d10e = 0;
        uStack_d0f0 = 0;
        uStack_d0ea = 0;
        uStack_d10c = 1;
        uStack_d0e0 = 0;
      }
      break;
    case 8:
      uStack_d0f8._0_2_ = 0;
      uStack_d0f8._2_2_ = 0;
      uStack_d0f4 = 0;
      uStack_d0f2 = 0;
      uStack_d10e = 0;
      uStack_d0f0 = 0;
      uStack_d0ea = 0;
      uStack_d10c = 9;
      uStack_d0e0 = 0;
    }
    lVar11 = uVar35 + 0x2000;
    uStack_d0e8 = (undefined2)lVar11;
    uStack_d0e6 = (undefined2)((ulonglong)lVar11 >> 0x10);
    uStack_d0e4 = (ushort)((ulonglong)lVar11 >> 0x20);
    uStack_d0e2 = (undefined2)((ulonglong)lVar11 >> 0x30);
    uStack_d100 = ppbVar34;
  }
  uVar35 = uStack_d338;
  uStack_d18c = 0;
  ppbVar34 = ppbVar24;
  if (*(char *)(uStack_d338 + 2) < '\0') {
    pbVar1 = (byte *)(uStack_d338 + 0x60);
    if ((sStack_d1c0 == 0) || (ppbVar34 = uStack_d1b0, uStack_d1b0 == (byte **)0x0)) {
      uStack_d160 = 0;
      uStack_d152 = 0;
      auStack_d138 = ZEXT816(0);
      auStack_d188 = ZEXT816(0);
      stack0xffffffffffff2e8a = SUB1614(ZEXT816(0),2);
      auStack_d178._0_2_ = 0xffff;
      uStack_d170 = 0;
      uStack_d15a = 0;
      uStack_d158 = 0;
      uStack_d150 = 0;
      uStack_d168 = 0;
      auStack_d148 = ZEXT816(0);
      auStack_d128._0_12_ = ZEXT812(0);
      auStack_d128._12_4_ = 0;
      uStack_d118 = 0;
      ppbVar34 = (byte **)auStack_d188;
    }
    uVar32 = 0xffff;
    if (*(short *)(uStack_d338 + 0x24) == 0) {
code_r0x00100af6:
      uStack_d320 = *(undefined8 *)(uVar35 + 0x28);
      uStack_d318 = *(undefined2 *)(uVar35 + 0x30);
    }
    else {
      cVar8 = *(char *)(uStack_d338 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(uStack_d338 + 0x18) != 99) {
code_r0x00100ac0:
          if (cVar8 != '\t') goto code_r0x00100af6;
          goto code_r0x00100ac4;
        }
      }
      else {
        if (cVar8 != '\b') goto code_r0x00100ac0;
code_r0x00100ac4:
        if (*(int *)(uStack_d338 + 0x18) != 99) goto code_r0x00100af6;
      }
      uStack_d2f8 = *(undefined4 *)(uStack_d338 + 0x20);
      uStack_d2f4 = *(undefined2 *)(uStack_d338 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ae4;
      uVar32 = 0xffff;
      cVar8 = func_0x(&uStack_d2f8);
      if (cVar8 == '\0') goto code_r0x00100af6;
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100af4;
      func_0x(uVar35,&uStack_d320);
    }
    *ppbVar34 = pbVar1;
    *(undefined4 *)(ppbVar34 + 0xc) = (undefined4)uStack_d320;
    *(int *)((longlong)ppbVar34 + 100) = (int)((ulonglong)uStack_d320 >> 0x20);
    *(undefined2 *)(ppbVar34 + 0xd) = uStack_d318;
    *(undefined4 *)((longlong)ppbVar34 + 0x6c) = *(undefined4 *)(uVar35 + 0x20);
    *(undefined2 *)(ppbVar34 + 0xe) = *(undefined2 *)(uVar35 + 0x24);
    *(undefined2 *)((longlong)ppbVar34 + 0x72) = 0;
    bVar18 = *pbVar1;
    *(undefined4 *)(&stack0x00000034 + lVar10) = *(undefined4 *)((ulonglong)bVar18 * 6 + 0x12638a0);
    uVar36 = (ulonglong)*(short *)((ulonglong)bVar18 * 6 + 0x12638a4);
    *(undefined2 *)(ppbVar34 + 2) = uVar32;
    ppbVar34[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar34 + 0x2e) = 0;
    ppbVar34[7] = (byte *)0x0;
    ppbVar34[4] = (byte *)0x0;
    ppbVar34[9] = (byte *)0x0;
    ppbVar34[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar34 + 0xb) = 0;
    if ((**ppbVar34 & 2) != 0) {
      pbVar2 = pbVar1 + uVar36;
      if ((*pbVar2 & 1) == 0) {
        *(undefined2 *)(ppbVar34 + 2) = 0;
        ppbVar34[3] = pbVar2;
        *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar34 + 0x36) = 0;
        uVar22 = uVar23;
        switch(*pbVar2 & 0xe) {
        default:
          uVar22 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d74;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar22 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar22 = 1;
        }
        *(uint *)(ppbVar34 + 4) = uVar22;
        *(undefined8 *)((longlong)ppbVar34 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar34 + 2) = 1;
        ppbVar34[3] = pbVar2;
        bVar18 = *pbVar2;
        switch(bVar18 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar19 = *(ushort *)(pbVar2 + 1);
            *(ushort *)((longlong)ppbVar34 + 0x12) = uVar19;
            sVar30 = 3;
            uVar19 = (uVar19 & 0x7f) << 8 | uVar19 >> 8;
          }
          else {
            sVar30 = 2;
            uVar19 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar34 + 0x12) = uVar19;
          *(short *)(ppbVar34 + 5) = sVar30;
          *(short *)((longlong)ppbVar34 + 0x2c) =
               (short)(*(ushort *)((longlong)ppbVar34 + 0x12) + 1 >> 1) + sVar30;
          if (*(ushort *)((longlong)ppbVar34 + 0x12) < 0x1f) {
            *(undefined2 *)((longlong)ppbVar34 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          else {
            iVar20 = *(ushort *)((longlong)ppbVar34 + 0x12) - 1;
            *(short *)((longlong)ppbVar34 + 0x2a) =
                 ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                 (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar18 & 0x1c) != 4) || (uVar22 = 1, (bVar18 & 2) == 0)) {
            uVar22 = uVar23;
          }
          *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
          ppbVar34[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar34 + 0x12) = 0;
          ppbVar34[6] = (byte *)0x0;
          ppbVar34[4] = (byte *)0x0;
          *(undefined4 *)(ppbVar34 + 8) = 0;
          ppbVar34[7] = (byte *)0x0;
          ppbVar34[3] = pbVar2;
          if (uVar22 == 0) {
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 1;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          else {
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0xf;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            *(undefined4 *)(ppbVar34 + 8) = 1;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          break;
        case 8:
          ppbVar34[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar34 + 0x12) = 0;
          ppbVar34[6] = (byte *)0x0;
          ppbVar34[4] = (byte *)0x0;
          ppbVar34[7] = (byte *)0x0;
          ppbVar34[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar34 + 0x14) = 9;
          *(undefined4 *)(ppbVar34 + 8) = 0;
          ppbVar34[7] = (byte *)0x0;
          ppbVar34[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar34 & 4) != 0) {
      if (*(short *)(&stack0x00000036 + lVar10) != 0) {
        uVar36 = (ulonglong)
                 *(ushort *)(uVar35 + 0x61 + (longlong)*(short *)(&stack0x00000036 + lVar10) * 2);
      }
      psVar14 = (short *)(pbVar1 + uVar36);
      ppbVar34[9] = (byte *)psVar14;
      sVar30 = *psVar14;
      ppbVar34[10] = (byte *)(psVar14 + 1);
      *(short *)(ppbVar34 + 0xb) = (sVar30 + 1) * 2;
    }
    pbVar1 = ppbVar34[1];
    if (pbVar1 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e01;
      func_0x(pbVar1,ppbVar34);
    }
  }
  uVar35 = uStack_d338;
  uVar22 = (uint)*(ushort *)(uStack_d338 + 0xe);
  ppbStack_d1b8 = (byte **)(*(ushort *)(uStack_d338 + 0x1ffe) + uStack_d338);
  if ((*(byte *)ppbStack_d1b8 & 1) == 0) {
    sStack_d1c0 = 0;
    uStack_d1bc = 0;
    uStack_d19a = 0;
    uStack_d198 = 0;
    switch(*(byte *)ppbStack_d1b8 & 0xe) {
    default:
      uVar22 = (uint)*(ushort *)((longlong)ppbStack_d1b8 + 2);
      if (0x1f9d < *(ushort *)((longlong)ppbStack_d1b8 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101017;
        func_0x(ppbStack_d1b8,6);
      }
      break;
    case 4:
      uVar22 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar22 = 1;
    }
    uStack_d1b0 = (byte **)CONCAT44(uStack_d1b0._4_4_,uVar22);
    uStack_d1a2 = (undefined2)(uVar35 + 0x2000);
    uStack_d1a0 = (undefined6)(uVar35 + 0x2000 >> 0x10);
  }
  else {
    sStack_d1c0 = 1;
    bVar18 = *(byte *)ppbStack_d1b8;
    switch(bVar18 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)ppbStack_d1b8 + 1) < '\0') {
        uStack_d1be = (*(ushort *)((longlong)ppbStack_d1b8 + 1) & 0x7f) << 8 |
                      *(ushort *)((longlong)ppbStack_d1b8 + 1) >> 8;
        uStack_d1a8._0_2_ = 3;
        sVar30 = 3;
      }
      else {
        uStack_d1be = (ushort)*(byte *)((longlong)ppbStack_d1b8 + 1);
        uStack_d1a8._0_2_ = 2;
        sVar30 = 2;
      }
      uStack_d1a4 = (short)(uStack_d1be + 1 >> 1) + sVar30;
      if (uStack_d1be < 0x1f) {
        uStack_d1a8._2_2_ = 0;
        uStack_d1bc = 0;
        uStack_d190 = 0;
      }
      else {
        iVar20 = uStack_d1be - 1;
        uStack_d1a8._2_2_ =
             ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
             (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
        uStack_d1bc = 0;
        uStack_d190 = 0;
      }
      break;
    case 4:
      if (((bVar18 & 0x1c) == 4) && ((bVar18 & 2) != 0)) {
        uStack_d1a8._0_2_ = 0;
        uStack_d1a8._2_2_ = 0;
        uStack_d1a4 = 0;
        uStack_d1a2 = 0;
        uStack_d1be = 0;
        uStack_d1a0 = 0;
        uStack_d19a = 0;
        uStack_d1bc = 0xf;
        uStack_d190 = 1;
      }
      else {
        uStack_d1a8._0_2_ = 0;
        uStack_d1a8._2_2_ = 0;
        uStack_d1a4 = 0;
        uStack_d1a2 = 0;
        uStack_d1be = 0;
        uStack_d1a0 = 0;
        uStack_d19a = 0;
        uStack_d1bc = 1;
        uStack_d190 = 0;
      }
      break;
    case 8:
      uStack_d1a8._0_2_ = 0;
      uStack_d1a8._2_2_ = 0;
      uStack_d1a4 = 0;
      uStack_d1a2 = 0;
      uStack_d1be = 0;
      uStack_d1a0 = 0;
      uStack_d19a = 0;
      uStack_d1bc = 9;
      uStack_d190 = 0;
    }
    lVar11 = uStack_d338 + 0x2000;
    uStack_d198 = (undefined2)lVar11;
    uStack_d196 = (undefined2)((ulonglong)lVar11 >> 0x10);
    uStack_d194 = (ushort)((ulonglong)lVar11 >> 0x20);
    uStack_d192 = (undefined2)((ulonglong)lVar11 >> 0x30);
    uStack_d1b0 = ppbVar34;
  }
  *(undefined4 *)((longlong)&uStackX_10 + lVar10) = 0xffffffff;
  *(undefined2 *)((longlong)&uStackX_14 + lVar10) = 1;
  uVar19 = *(ushort *)((longlong)&uStackX_14 + lVar10 + 2) & 0xffe0;
  *(ushort *)((longlong)&uStackX_14 + lVar10 + 2) = uVar19;
  *(undefined8 *)((longlong)&uStackX_14 + lVar10 + 4) = 0;
  ppbVar34 = (byte **)0x11eb7f4;
  if (sStack_d110 == 0) {
    uVar22 = uVar23;
    if ((*(byte *)ppbStack_d108 & 0x10) == 0) {
      if ((1 << (*(byte *)ppbStack_d108 & 0xe) & 0x1105U) != 0) {
        bVar18 = 0xff;
        goto code_r0x0010111d;
      }
code_r0x00101159:
      uVar22 = uStack_d0f8;
      if (uStack_d10c == 0) {
        uStack_d10e = 0;
        uVar35 = (ulonglong)uStack_d100 & 0xffffffff;
        uVar22 = (uint)uStack_d100;
        if ((*(byte *)ppbStack_d108 & 0x10) != 0) {
          uVar22 = (uint)uStack_d100 + 2 + (*(ushort *)(uVar35 + (longlong)ppbStack_d108) + 7 >> 3);
          uVar35 = (ulonglong)uVar22;
        }
        uStack_d100 = (byte **)CONCAT44(uVar22,(uint)uStack_d100);
        if ((*(byte *)ppbStack_d108 & 0x20) == 0) {
          uStack_d10c = (uint)uVar35;
          uStack_d0f4 = 0;
          uStack_d0f8._0_2_ = (undefined2)uVar35;
          uStack_d0f8._2_2_ = (short)(uVar35 >> 0x10);
          uVar36 = uVar35;
          uStack_d0f8 = (uint)uVar35;
        }
        else {
          puVar26 = (ushort *)(uVar35 + (longlong)ppbStack_d108);
          uStack_d0f4 = *puVar26;
          if (*puVar26 == 0) {
            if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*puRam00000000010e4c20 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101242;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101265;
                (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101276;
            func_0x(ppbStack_d108,3);
          }
          uVar22 = uStack_d100._4_4_ + (uStack_d0f4 + 1) * 2;
          uStack_d0f8._0_2_ = (undefined2)uVar22;
          uStack_d0f8._2_2_ = (short)(uVar22 >> 0x10);
          uStack_d0f8 = uVar22;
          if (0x1f9e < uVar22) {
            if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
               ((lVar11 = *(longlong *)
                           ((ulonglong)*puRam00000000010e4c20 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
                ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                 (*(char *)(lVar11 + 0x499) != '\0')))))) {
              if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101319;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10133c;
                (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10134d;
            func_0x(ppbStack_d108,4);
          }
          uVar36 = (ulonglong)uStack_d0f8;
          uStack_d10c = puVar26[uStack_d0f4] & 0x7fff;
          uVar35 = (ulonglong)uStack_d10c;
          if (uStack_d10c < uStack_d0f8) {
            if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*puRam00000000010e4c20 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1013f1;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101414;
                (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101425;
            func_0x(ppbStack_d108,4);
            uVar36 = (ulonglong)uStack_d0f8;
            uVar35 = (ulonglong)uStack_d10c;
          }
          do {
            if (-1 < (short)puVar26[(ulonglong)(uStack_d0f4 - 1) + 1]) break;
            uVar25 = (uint)uVar36;
            if (uStack_d0f4 != 1) {
              uVar25 = *(ushort *)
                        ((longlong)ppbStack_d108 +
                        (ulonglong)uStack_d0f4 * 2 + (((ulonglong)uStack_d100 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar25 < (uint)uVar36) ||
               ((*(ushort *)
                  ((longlong)ppbStack_d108 +
                  (ulonglong)uStack_d0f4 * 2 + ((ulonglong)uStack_d100 >> 0x20)) & 0x7fff) < uVar25)
               ) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10149c;
              func_0x(ppbStack_d108,7);
              uVar36 = (ulonglong)uStack_d0f8;
              uVar35 = (ulonglong)uStack_d10c;
            }
            uVar22 = (uint)uVar36;
            if ((uVar25 < uVar22) || ((uint)uVar35 < uVar25)) goto code_r0x001017d9;
            if (*(ushort *)((ulonglong)uVar25 + (longlong)ppbStack_d108) == 5) {
              uStack_d10e = uStack_d10e | 2;
              uStack_d0f4 = uStack_d0f4 - 1;
              uStack_d0e6 = (short)uVar25;
              uVar19 = *(ushort *)((longlong)ppbStack_d108 + (ulonglong)(uVar25 & 0xffff) + 2);
              if ((uVar19 & 0x4000) == 0) {
                uStack_d0e4 = uStack_d0e4 & 0xc7ff;
              }
              else {
                uStack_d0e4 = uStack_d0e4 ^ (uVar19 ^ uStack_d0e4) & 0x3800;
              }
              uStack_d0e4 = (uStack_d0e4 ^
                            *(ushort *)((longlong)ppbStack_d108 + (ulonglong)(uVar25 & 0xffff) + 2))
                            & 0x7ff ^ uStack_d0e4;
              break;
            }
            if (*(ushort *)((ulonglong)uVar25 + (longlong)ppbStack_d108) < 0x400) break;
            uStack_d10e = uStack_d10e | 1;
            uStack_d0f4 = uStack_d0f4 - 1;
          } while (uStack_d0f4 != 0);
        }
        uVar22 = (uint)uVar36;
        if ((*(byte *)ppbStack_d108 & 0x40) == 0) {
          uStack_d0ea = 0;
          uStack_d0e8 = 0;
        }
        else {
          uStack_d0ea = (undefined2)uVar35;
          uStack_d0e8 = (undefined2)(uVar35 >> 0x10);
          uStack_d10c = (int)uVar35 + 0xe;
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1015b1;
          puVar16 = (ulonglong *)func_0x(&uStack_d10e);
          uVar35 = *puVar16;
          uVar21 = (ushort)(uVar35 >> 0x30);
          uVar19 = uVar21;
          if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
            uVar19 = uVar21 & 0xdfff;
            if ((uVar35 & 0x4000000000000000) != 0) {
              uVar19 = uVar21 | 0x2000;
            }
          }
          uVar22 = uVar23;
          if (uVar19 == 0xfffc) {
            uVar22 = (uint)((uVar35 >> 0x20 & 0xffff) >> 5);
          }
          uVar35 = (ulonglong)(uStack_d10c + uVar22);
          uStack_d10c = uStack_d10c + uVar22;
          uVar22 = uStack_d0f8;
        }
        uVar25 = (uint)uVar35;
        if ((CONCAT62(uStack_d0f0,uStack_d0f2) != 0) &&
           (CONCAT62(uStack_d0f0,uStack_d0f2) < uVar35 + (longlong)ppbStack_d108)) {
          if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
             (((lVar11 = *(longlong *)
                          ((ulonglong)*puRam00000000010e4c20 +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
               (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1016c3;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1016e9;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x877);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1016fa;
          func_0x(ppbStack_d108,0x12);
          uVar25 = uStack_d10c;
          uVar22 = uStack_d0f8;
        }
        if (0x3f3b < uVar25 - 1) {
          if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         ((ulonglong)*puRam00000000010e4c20 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10178d;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1017d2;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x87c);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1017a3;
          func_0x(ppbStack_d108,5);
          uVar22 = uStack_d0f8;
        }
      }
code_r0x001017d9:
      sVar30 = -*(short *)((longlong)&uStackX_10 + lVar10);
      if ((*(byte *)((longlong)&uStackX_14 + lVar10 + 2) & 0x10) != 0) {
        if ((*(byte *)ppbStack_d108 & 0x10) == 0) {
          if ((1 << (*(byte *)ppbStack_d108 & 0xe) & 0x1105U) != 0) {
code_r0x00101852:
            puVar6 = *(undefined4 **)((longlong)&uStackX_14 + lVar10 + 4);
            ppbVar15 = (byte **)(puVar6 + 1);
            *(undefined4 *)((longlong)&iStackX_24 + lVar10) = *puVar6;
            goto code_r0x00101964;
          }
        }
        else if (((int)(uint)uStack_d100 <= *(int *)((longlong)&uStackX_10 + lVar10)) ||
                (*(ushort *)(((ulonglong)uStack_d100 & 0xffffffff) + (longlong)ppbStack_d108) <
                 *(ushort *)((longlong)&uStackX_14 + lVar10))) goto code_r0x00101852;
      }
      if ((uint)uStack_d0f4 < (uint)(int)sVar30) {
        *(undefined4 *)((longlong)&iStackX_24 + lVar10) = 0;
        ppbVar15 = ppbStack_d108;
      }
      else {
        uVar25 = uVar22;
        if (sVar30 != 1) {
          uVar22 = *(ushort *)
                    ((longlong)ppbStack_d108 +
                    (longlong)sVar30 * 2 + (((ulonglong)uStack_d100 >> 0x20) - 2)) & 0x7fff;
          uVar25 = uStack_d0f8;
        }
        uVar27 = *(ushort *)
                  ((longlong)ppbStack_d108 + (longlong)sVar30 * 2 + ((ulonglong)uStack_d100 >> 0x20)
                  ) & 0x7fff;
        if ((uVar22 < uVar25) || (uVar27 < uVar22)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1018a4;
          func_0x(ppbStack_d108,7);
        }
        *(uint *)((longlong)&iStackX_24 + lVar10) = uVar27 - uVar22;
        ppbVar15 = (byte **)((ulonglong)uVar22 + (longlong)ppbStack_d108);
      }
    }
    else {
      if ((uint)uStack_d100 < 0x80000000) {
        if (*(short *)(((ulonglong)uStack_d100 & 0xffffffff) + (longlong)ppbStack_d108) == 0) {
          bVar18 = 0xff;
        }
        else {
          bVar18 = *(byte *)((longlong)ppbStack_d108 + ((ulonglong)uStack_d100 & 0xffffffff) + 2);
          uVar22 = 1;
        }
      }
      else {
        bVar18 = 0xff;
      }
code_r0x0010111d:
      if ((bVar18 & 1) == 0) {
        if ((uVar22 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar10 + 2) & 0x10) == 0))
        goto code_r0x00101159;
        *(undefined4 *)((longlong)&iStackX_24 + lVar10) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar10 + 4);
        ppbVar15 = (byte **)0x4;
      }
      else {
        *(undefined4 *)((longlong)&iStackX_24 + lVar10) = 0;
        ppbVar15 = ppbVar24;
        uStack_d0f8 = CONCAT22(uStack_d0f8._2_2_,(undefined2)uStack_d0f8);
      }
    }
  }
  else {
    uStack_d340 = 0;
    *(uint **)(&stack0xffffffffffffffe0 + lVar10) = &uStack_d340;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1018f7;
    ppbVar15 = (byte **)func_0x(&uStack_d10e,(longlong)&uStackX_10 + lVar10,uVar19,
                                        (longlong)&iStackX_24 + lVar10);
    uStack_d0f8 = CONCAT22(uStack_d0f8._2_2_,(undefined2)uStack_d0f8);
    if ((((sStack_d110 != 0) &&
         (uStack_d0f8 = CONCAT22(uStack_d0f8._2_2_,(undefined2)uStack_d0f8),
         uStack_d100 != (byte **)0x0)) &&
        (uStack_d0f8 = CONCAT22(uStack_d0f8._2_2_,(undefined2)uStack_d0f8),
        *uStack_d100 != (byte *)0x0)) &&
       ((uStack_d0f8 = CONCAT22(uStack_d0f8._2_2_,(undefined2)uStack_d0f8),
        (*(byte *)((longlong)&uStackX_14 + lVar10 + 2) & 8) == 0 &&
        (uStack_d0f8 = CONCAT22(uStack_d0f8._2_2_,(undefined2)uStack_d0f8), (uStack_d340 & 1) == 0))
       )) {
      if ((ppbVar15 == (byte **)0x0) || (ppbVar15 == (byte **)0x11eb7f4)) {
        *(undefined4 *)((longlong)&iStackX_24 + lVar10) = 0;
        ppbVar15 = (byte **)0x0;
        uStack_d0f8 = CONCAT22(uStack_d0f8._2_2_,(undefined2)uStack_d0f8);
      }
      else {
        *(uint *)(&stack0xfffffffffffffff8 + lVar10) = uStack_d340;
        *(longlong *)(&stack0xfffffffffffffff0 + lVar10) = (longlong)&iStackX_24 + lVar10;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101958;
        ppbVar15 = (byte **)func_0x
                                      (uStack_d100,(longlong)&uStackX_10 + lVar10,ppbVar15,
                                       *(undefined4 *)((longlong)&iStackX_24 + lVar10));
        uStack_d0f8 = CONCAT22(uStack_d0f8._2_2_,(undefined2)uStack_d0f8);
      }
    }
  }
code_r0x00101964:
  uVar22 = 1;
  if ((ppbVar15 == (byte **)0x0) || (*(int *)((longlong)&iStackX_24 + lVar10) == 0)) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0x148a710;
    *(longlong *)(&stack0xffffffffffffffe0 + lVar10) = param_2;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101997;
    (*_DAT_)(0x33,0x48,0x10,0x42);
  }
  if (sStack_d1c0 == 0) {
    if ((*(uint *)((longlong)&uStackX_10 + lVar10) & 0xc0000000) == 0x80000000) {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1022a5;
      iVar20 = func_0x(&uStack_d1be);
      if (iVar20 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1022c3;
        ppbVar34 = (byte **)func_0x(&uStack_d196,(longlong)&uStackX_10 + lVar10,
                                            (longlong)&iStackX_20 + lVar10,auStack_d2c0);
        goto code_r0x0010235d;
      }
      *(undefined4 *)((longlong)&iStackX_20 + lVar10) = 0;
      ppbVar34 = (byte **)0x0;
    }
    else {
      bVar18 = *(byte *)ppbStack_d1b8;
      if ((bVar18 & 0x10) == 0) {
        if ((1 << (bVar18 & 0xe) & 0x1105U) != 0) {
          uVar19 = ~(*(ushort *)((longlong)&uStackX_14 + lVar10 + 2) >> 4);
          uVar22 = uVar23;
          goto code_r0x00101a5e;
        }
code_r0x00101a92:
        if (*(int *)((longlong)&uStackX_10 + lVar10) < 0) {
          uVar25 = uStack_d1a8;
          if (uStack_d1bc == 0) {
            uStack_d1be = 0;
            uVar35 = (ulonglong)uStack_d1b0 & 0xffffffff;
            uVar22 = (uint)uStack_d1b0;
            if ((*(byte *)ppbStack_d1b8 & 0x10) != 0) {
              uVar22 = (uint)uStack_d1b0 + 2 +
                       (*(ushort *)(uVar35 + (longlong)ppbStack_d1b8) + 7 >> 3);
              uVar35 = (ulonglong)uVar22;
            }
            uStack_d1b0 = (byte **)CONCAT44(uVar22,(uint)uStack_d1b0);
            uVar22 = (uint)uVar35;
            if ((*(byte *)ppbStack_d1b8 & 0x20) == 0) {
              uStack_d1bc = uVar22;
              uStack_d1a4 = 0;
              uStack_d1a8._0_2_ = (undefined2)uVar35;
              uStack_d1a8._2_2_ = (short)(uVar35 >> 0x10);
              uVar36 = uVar35;
            }
            else {
              puVar26 = (ushort *)(uVar35 + (longlong)ppbStack_d1b8);
              uStack_d1a4 = *puVar26;
              if (*puVar26 == 0) {
                if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                    (lVar11 = *(longlong *)
                               ((ulonglong)*puRam00000000010e4c20 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
                   ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                    (*(char *)(lVar11 + 0x499) != '\0')))) {
                  if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101c1c;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101c3f;
                    (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x80f);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101c50;
                func_0x(ppbStack_d1b8,3);
              }
              uVar22 = uStack_d1b0._4_4_ + (uStack_d1a4 + 1) * 2;
              uStack_d1a8._0_2_ = (undefined2)uVar22;
              uStack_d1a8._2_2_ = (short)(uVar22 >> 0x10);
              uStack_d1a8 = uVar22;
              if (0x1f9e < uVar22) {
                if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                   ((lVar11 = *(longlong *)
                               ((ulonglong)*puRam00000000010e4c20 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
                    ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                     (*(char *)(lVar11 + 0x499) != '\0')))))) {
                  if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101cf3;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101d16;
                    (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x816);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101d27;
                func_0x(ppbStack_d1b8,4);
              }
              uStack_d1bc = puVar26[uStack_d1a4] & 0x7fff;
              if ((puVar26[uStack_d1a4] & 0x7fff) < uStack_d1a8) {
                if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                    (lVar11 = *(longlong *)
                               ((ulonglong)*puRam00000000010e4c20 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
                   ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                    (*(char *)(lVar11 + 0x499) != '\0')))) {
                  if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101dc8;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101deb;
                    (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x81d);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101dfc;
                func_0x(ppbStack_d1b8,4);
              }
              uVar36 = (ulonglong)uStack_d1a8;
              uVar35 = (ulonglong)uStack_d1bc;
              do {
                uVar22 = uStack_d1a8;
                if (-1 < (short)puVar26[(ulonglong)(uStack_d1a4 - 1) + 1]) break;
                uVar27 = (uint)uVar36;
                if (uStack_d1a4 != 1) {
                  uVar27 = *(ushort *)
                            ((longlong)ppbStack_d1b8 +
                            (ulonglong)uStack_d1a4 * 2 + (((ulonglong)uStack_d1b0 >> 0x20) - 2)) &
                           0x7fff;
                }
                if ((uVar27 < (uint)uVar36) ||
                   ((*(ushort *)
                      ((longlong)ppbStack_d1b8 +
                      (ulonglong)uStack_d1a4 * 2 + ((ulonglong)uStack_d1b0 >> 0x20)) & 0x7fff) <
                    uVar27)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101e73;
                  func_0x(ppbStack_d1b8,7);
                  uVar36 = (ulonglong)uStack_d1a8;
                  uVar35 = (ulonglong)uStack_d1bc;
                }
                uVar25 = (uint)uVar36;
                if ((uVar27 < uVar25) || ((uint)uVar35 < uVar27)) goto code_r0x001021a4;
                if (*(ushort *)((ulonglong)uVar27 + (longlong)ppbStack_d1b8) == 5) {
                  uStack_d1be = uStack_d1be | 2;
                  uStack_d1a4 = uStack_d1a4 - 1;
                  uStack_d196 = (short)uVar27;
                  uVar19 = *(ushort *)((longlong)ppbStack_d1b8 + (ulonglong)(uVar27 & 0xffff) + 2);
                  if ((uVar19 & 0x4000) == 0) {
                    uStack_d194 = uStack_d194 & 0xc7ff;
                  }
                  else {
                    uStack_d194 = uStack_d194 ^ (uVar19 ^ uStack_d194) & 0x3800;
                  }
                  uStack_d194 = (uStack_d194 ^
                                *(ushort *)
                                 ((longlong)ppbStack_d1b8 + (ulonglong)(uVar27 & 0xffff) + 2)) &
                                0x7ff ^ uStack_d194;
                  goto code_r0x00101f63;
                }
                uVar22 = uStack_d1a8;
                if (*(ushort *)((ulonglong)uVar27 + (longlong)ppbStack_d1b8) < 0x400) break;
                uStack_d1be = uStack_d1be | 1;
                uStack_d1a4 = uStack_d1a4 - 1;
              } while (uStack_d1a4 != 0);
            }
            uVar25 = (uint)uVar36;
            uStack_d1a8 = uVar22;
code_r0x00101f63:
            if ((*(byte *)ppbStack_d1b8 & 0x40) == 0) {
              uStack_d19a = 0;
              uStack_d198 = 0;
            }
            else {
              uStack_d19a = (undefined2)uVar35;
              uStack_d198 = (undefined2)(uVar35 >> 0x10);
              uStack_d1bc = (int)uVar35 + 0xe;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101f8e;
              puVar16 = (ulonglong *)func_0x(&uStack_d1be);
              uVar35 = *puVar16;
              uVar21 = (ushort)(uVar35 >> 0x30);
              uVar19 = uVar21;
              if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
                uVar19 = uVar21 & 0xdfff;
                if ((uVar35 & 0x4000000000000000) != 0) {
                  uVar19 = uVar21 | 0x2000;
                }
              }
              uVar22 = uVar23;
              if (uVar19 == 0xfffc) {
                uVar22 = (uint)((uVar35 >> 0x20 & 0xffff) >> 5);
              }
              uVar35 = (ulonglong)(uStack_d1bc + uVar22);
              uStack_d1bc = uStack_d1bc + uVar22;
              uVar25 = uStack_d1a8;
            }
            uVar22 = (uint)uVar35;
            if ((CONCAT62(uStack_d1a0,uStack_d1a2) != 0) &&
               (CONCAT62(uStack_d1a0,uStack_d1a2) < uVar35 + (longlong)ppbStack_d1b8)) {
              if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                 (((lVar11 = *(longlong *)
                              ((ulonglong)*puRam00000000010e4c20 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
                   (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
                  (*(char *)(lVar11 + 0x499) != '\0')))) {
                if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10209a;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1020c0;
                  (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x877);
                }
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1020d1;
              func_0x(ppbStack_d1b8,0x12);
              uVar22 = uStack_d1bc;
              uVar25 = uStack_d1a8;
            }
            if (0x3f3b < uVar22 - 1) {
              if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                 ((lVar11 = *(longlong *)
                             ((ulonglong)*puRam00000000010e4c20 +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
                  ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                   (*(char *)(lVar11 + 0x499) != '\0')))))) {
                if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102166;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10218c;
                  (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x87c);
                }
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10219d;
              func_0x(ppbStack_d1b8,5);
              uVar25 = uStack_d1a8;
            }
          }
code_r0x001021a4:
          sVar30 = -*(short *)((longlong)&uStackX_10 + lVar10);
          if ((*(byte *)((longlong)&uStackX_14 + lVar10 + 2) & 0x10) == 0) {
code_r0x001021d9:
            if ((uint)uStack_d1a4 < (uint)(int)sVar30) {
              *(undefined4 *)((longlong)&iStackX_20 + lVar10) = 0;
              ppbVar34 = ppbStack_d1b8;
            }
            else {
              uVar22 = uVar25;
              if (sVar30 != 1) {
                uVar25 = *(ushort *)
                          ((longlong)ppbStack_d1b8 +
                          (longlong)sVar30 * 2 + (((ulonglong)uStack_d1b0 >> 0x20) - 2)) & 0x7fff;
                uVar22 = uStack_d1a8;
              }
              uVar27 = *(ushort *)
                        ((longlong)ppbStack_d1b8 +
                        (longlong)sVar30 * 2 + ((ulonglong)uStack_d1b0 >> 0x20)) & 0x7fff;
              if ((uVar25 < uVar22) || (uVar27 < uVar25)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102272;
                func_0x(ppbStack_d1b8,7);
              }
              *(uint *)((longlong)&iStackX_20 + lVar10) = uVar27 - uVar25;
              ppbVar34 = (byte **)((ulonglong)uVar25 + (longlong)ppbStack_d1b8);
            }
          }
          else {
            uVar22 = uStack_d1a8;
            if ((*(byte *)ppbStack_d1b8 & 0x10) == 0) {
              if ((1 << (*(byte *)ppbStack_d1b8 & 0xe) & 0x1105U) == 0) goto code_r0x001021d9;
            }
            else if (*(int *)((longlong)&uStackX_10 + lVar10) < (int)(uint)uStack_d1b0) {
              if (*(ushort *)((longlong)ppbStack_d1b8 + ((ulonglong)uStack_d1b0 & 0xffffffff)) <
                  *(ushort *)((longlong)&uStackX_14 + lVar10)) {
                puVar6 = *(undefined4 **)((longlong)&uStackX_14 + lVar10 + 4);
                ppbVar34 = (byte **)(puVar6 + 1);
                *(undefined4 *)((longlong)&iStackX_20 + lVar10) = *puVar6;
                goto code_r0x00102360;
              }
              goto code_r0x001021d9;
            }
code_r0x00101af7:
            puVar6 = *(undefined4 **)((longlong)&uStackX_14 + lVar10 + 4);
            *(undefined4 *)((longlong)&iStackX_20 + lVar10) = *puVar6;
            ppbVar34 = (byte **)(puVar6 + 1);
            uStack_d1a8 = uVar22;
          }
        }
        else {
          bVar4 = *(byte *)((longlong)&uStackX_14 + lVar10 + 2);
          if ((bVar4 & 8) == 0) {
            if ((bVar4 & 0x10) != 0) {
              if ((bVar18 & 0x10) == 0) {
                uVar22 = CONCAT22(uStack_d1a8._2_2_,(undefined2)uStack_d1a8);
                if ((1 << (bVar18 & 0xe) & 0x1105U) == 0) goto code_r0x00101ac2;
              }
              else {
                uVar22 = CONCAT22(uStack_d1a8._2_2_,(undefined2)uStack_d1a8);
                if ((*(int *)((longlong)&uStackX_10 + lVar10) < (int)(uint)uStack_d1b0) &&
                   (uVar22 = uStack_d1a8,
                   *(ushort *)((longlong)&uStackX_14 + lVar10) <=
                   *(ushort *)((longlong)ppbStack_d1b8 + ((ulonglong)uStack_d1b0 & 0xffffffff))))
                goto code_r0x00101ac2;
              }
              goto code_r0x00101af7;
            }
code_r0x00101ac2:
            *(undefined4 *)((longlong)&iStackX_20 + lVar10) = 0;
            ppbVar34 = (byte **)((longlong)*(int *)((longlong)&uStackX_10 + lVar10) +
                                (longlong)ppbStack_d1b8);
          }
          else {
            if ((*(byte *)((longlong)*(int *)((longlong)&uStackX_10 + lVar10) +
                          (longlong)ppbStack_d1b8) &
                (byte)(1 << (*(byte *)((longlong)&uStackX_14 + lVar10 + 2) & 7))) == 0) {
              ppbVar34 = (byte **)0x11ebe18;
            }
            *(undefined4 *)((longlong)&iStackX_20 + lVar10) = 1;
          }
        }
      }
      else {
        if (*(int *)((longlong)&uStackX_10 + lVar10) < (int)(uint)uStack_d1b0) {
          if ((uint)*(ushort *)(((ulonglong)uStack_d1b0 & 0xffffffff) + (longlong)ppbStack_d1b8) <
              (uint)*(ushort *)((longlong)&uStackX_14 + lVar10)) {
            uVar19 = ~(*(ushort *)((longlong)&uStackX_14 + lVar10 + 2) >> 4);
            uVar22 = uVar23;
          }
          else {
            uVar25 = *(ushort *)((longlong)&uStackX_14 + lVar10) - 1;
            uVar19 = (ushort)(*(byte *)((ulonglong)(uVar25 >> 3) +
                                        ((ulonglong)uStack_d1b0 & 0xffffffff) + 2 +
                                       (longlong)ppbStack_d1b8) >> ((byte)uVar25 & 7));
          }
        }
        else {
          uVar19 = ~(*(ushort *)((longlong)&uStackX_14 + lVar10 + 2) >> 4);
          uVar22 = uVar23;
        }
code_r0x00101a5e:
        if ((uVar19 & 1) == 0) {
          if ((uVar22 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar10 + 2) & 0x10) == 0))
          goto code_r0x00101a92;
          puVar6 = *(undefined4 **)((longlong)&uStackX_14 + lVar10 + 4);
          *(undefined4 *)((longlong)&iStackX_20 + lVar10) = *puVar6;
          ppbVar34 = (byte **)(puVar6 + 1);
        }
        else {
          *(undefined4 *)((longlong)&iStackX_20 + lVar10) = 0;
          ppbVar34 = ppbVar24;
        }
      }
    }
  }
  else {
    uStack_d33c = 0;
    *(uint **)(&stack0xffffffffffffffe0 + lVar10) = &uStack_d33c;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1022f6;
    ppbVar34 = (byte **)func_0x(&uStack_d1be,(longlong)&uStackX_10 + lVar10);
    if ((((sStack_d1c0 != 0) && (uStack_d1b0 != (byte **)0x0)) && (*uStack_d1b0 != (byte *)0x0)) &&
       (((*(byte *)((longlong)&uStackX_14 + lVar10 + 2) & 8) == 0 && ((uStack_d33c & 1) == 0)))) {
      if ((ppbVar34 == (byte **)0x0) || (ppbVar34 == (byte **)0x11eb7f4)) {
        *(undefined4 *)((longlong)&iStackX_20 + lVar10) = 0;
        ppbVar34 = ppbVar24;
      }
      else {
        *(uint *)(&stack0xfffffffffffffff8 + lVar10) = uStack_d33c;
        *(longlong *)(&stack0xfffffffffffffff0 + lVar10) = (longlong)&iStackX_20 + lVar10;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102354;
        ppbVar34 = (byte **)func_0x
                                      (uStack_d1b0,(longlong)&uStackX_10 + lVar10,ppbVar34,
                                       *(undefined4 *)((longlong)&iStackX_20 + lVar10));
      }
    }
code_r0x0010235d:
  }
code_r0x00102360:
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102374;
  func_0x
            (ppbVar34,*(undefined4 *)((longlong)&iStackX_20 + lVar10),ppbVar15,
             *(undefined4 *)((longlong)&iStackX_24 + lVar10));
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10238a;
  func_0x(plStack_d2d0);
  uVar36 = uStack_d2e0;
  uStack_d348 = 9;
  uStack_d344 = 1;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1023b3;
  func_0x(uVar12,0,uStack_d2e0,&uStack_d348);
  uVar35 = uStack_d2e8;
  if ((*(ushort *)(uStack_d2e8 + 0x16) < 2) || (*(short *)(uStack_d2e8 + 0x1ffc) == 0)) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1023ed;
    (*pcRam00000000010e4bb0)(1,0x161dab8,0x15ebaf8,0x177d);
  }
  uStack_d23c = 1;
  ppbVar34 = ppbVar24;
  if (*(char *)(uVar35 + 2) < '\0') {
    pbVar1 = (byte *)(uVar35 + 0x60);
    if ((sStack_d270 == 0) || (ppbVar34 = uStack_d260, uStack_d260 == (byte **)0x0)) {
      uStack_d210 = 0;
      uStack_d202 = 0;
      auStack_d1e8 = ZEXT816(0);
      auStack_d238 = ZEXT816(0);
      stack0xffffffffffff2dda = SUB1614(ZEXT816(0),2);
      auStack_d228._0_2_ = 0xffff;
      uStack_d220 = 0;
      uStack_d20a = 0;
      uStack_d208 = 0;
      uStack_d200 = 0;
      uStack_d218 = 0;
      auStack_d1f8 = ZEXT816(0);
      auStack_d1d8._0_12_ = ZEXT812(0);
      auStack_d1d8._12_4_ = 0;
      uStack_d1c8 = 0;
      ppbVar34 = (byte **)auStack_d238;
    }
    uVar32 = 0xffff;
    if (*(short *)(uVar35 + 0x24) == 0) {
code_r0x00102515:
      uStack_d310 = *(undefined8 *)(uVar35 + 0x28);
      uStack_d308 = *(undefined2 *)(uVar35 + 0x30);
    }
    else {
      cVar8 = *(char *)(uVar35 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(uVar35 + 0x18) != 99) {
code_r0x001024dc:
          if (cVar8 != '\t') goto code_r0x00102515;
          goto code_r0x001024e0;
        }
      }
      else {
        if (cVar8 != '\b') goto code_r0x001024dc;
code_r0x001024e0:
        if (*(int *)(uVar35 + 0x18) != 99) goto code_r0x00102515;
      }
      uStack_d2f0 = *(undefined4 *)(uVar35 + 0x20);
      uStack_d2ec = *(undefined2 *)(uVar35 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102503;
      uVar32 = 0xffff;
      cVar8 = func_0x(&uStack_d2f0);
      if (cVar8 == '\0') goto code_r0x00102515;
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102513;
      func_0x(uVar35,&uStack_d310);
    }
    *ppbVar34 = pbVar1;
    *(undefined4 *)(ppbVar34 + 0xc) = (undefined4)uStack_d310;
    *(int *)((longlong)ppbVar34 + 100) = (int)((ulonglong)uStack_d310 >> 0x20);
    *(undefined2 *)(ppbVar34 + 0xd) = uStack_d308;
    *(undefined4 *)((longlong)ppbVar34 + 0x6c) = *(undefined4 *)(uVar35 + 0x20);
    *(undefined2 *)(ppbVar34 + 0xe) = *(undefined2 *)(uVar35 + 0x24);
    *(undefined2 *)((longlong)ppbVar34 + 0x72) = 0;
    uStack_d348 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x12638a0);
    uVar36 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x12638a4);
    *(undefined2 *)(ppbVar34 + 2) = uVar32;
    ppbVar34[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar34 + 0x2e) = 0;
    ppbVar34[7] = (byte *)0x0;
    ppbVar34[4] = (byte *)0x0;
    ppbVar34[9] = (byte *)0x0;
    ppbVar34[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar34 + 0xb) = 0;
    if ((**ppbVar34 & 2) != 0) {
      pbVar2 = pbVar1 + uVar36;
      if ((*pbVar2 & 1) == 0) {
        *(undefined2 *)(ppbVar34 + 2) = 0;
        ppbVar34[3] = pbVar2;
        *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar34 + 0x36) = 0;
        uVar22 = uVar23;
        switch(*pbVar2 & 0xe) {
        default:
          uVar22 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102796;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar22 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar22 = 1;
        }
        *(uint *)(ppbVar34 + 4) = uVar22;
        *(undefined8 *)((longlong)ppbVar34 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar34 + 2) = 1;
        ppbVar34[3] = pbVar2;
        bVar18 = *pbVar2;
        switch(bVar18 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar19 = *(ushort *)(pbVar2 + 1);
            *(ushort *)((longlong)ppbVar34 + 0x12) = uVar19;
            sVar30 = 3;
            uVar19 = (uVar19 & 0x7f) << 8 | uVar19 >> 8;
          }
          else {
            sVar30 = 2;
            uVar19 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar34 + 0x12) = uVar19;
          *(short *)(ppbVar34 + 5) = sVar30;
          *(short *)((longlong)ppbVar34 + 0x2c) =
               (short)(*(ushort *)((longlong)ppbVar34 + 0x12) + 1 >> 1) + sVar30;
          if (*(ushort *)((longlong)ppbVar34 + 0x12) < 0x1f) {
            *(undefined2 *)((longlong)ppbVar34 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          else {
            iVar20 = *(ushort *)((longlong)ppbVar34 + 0x12) - 1;
            *(short *)((longlong)ppbVar34 + 0x2a) =
                 ((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                 (short)((longlong)iVar20 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar18 & 0x1c) != 4) || (uVar22 = 1, (bVar18 & 2) == 0)) {
            uVar22 = uVar23;
          }
          *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0;
          ppbVar34[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar34 + 0x12) = 0;
          ppbVar34[6] = (byte *)0x0;
          ppbVar34[4] = (byte *)0x0;
          *(undefined4 *)(ppbVar34 + 8) = 0;
          ppbVar34[7] = (byte *)0x0;
          ppbVar34[3] = pbVar2;
          if (uVar22 == 0) {
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 1;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          else {
            *(undefined4 *)((longlong)ppbVar34 + 0x14) = 0xf;
            *(undefined4 *)(ppbVar34 + 8) = 0;
            *(undefined4 *)(ppbVar34 + 8) = 1;
            ppbVar34[7] = (byte *)0x0;
            ppbVar34[4] = (byte *)0x0;
          }
          break;
        case 8:
          ppbVar34[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar34 + 0x12) = 0;
          ppbVar34[6] = (byte *)0x0;
          ppbVar34[4] = (byte *)0x0;
          ppbVar34[7] = (byte *)0x0;
          ppbVar34[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar34 + 0x14) = 9;
          *(undefined4 *)(ppbVar34 + 8) = 0;
          ppbVar34[7] = (byte *)0x0;
          ppbVar34[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar34 & 4) != 0) {
      if (uStack_d348._2_2_ != 0) {
        uVar36 = (ulonglong)*(ushort *)(uVar35 + 0x61 + (longlong)uStack_d348._2_2_ * 2);
      }
      psVar14 = (short *)(pbVar1 + uVar36);
      ppbVar34[9] = (byte *)psVar14;
      sVar30 = *psVar14;
      ppbVar34[10] = (byte *)(psVar14 + 1);
      *(short *)(ppbVar34 + 0xb) = (sVar30 + 1) * 2;
    }
    pbVar1 = ppbVar34[1];
    uVar36 = uStack_d2e0;
    if (pbVar1 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102823;
      func_0x(pbVar1,ppbVar34);
      uVar36 = uStack_d2e0;
    }
  }
  uVar22 = (uint)*(ushort *)(uVar35 + 0xe);
  pbStack_d268 = (byte *)(*(ushort *)(uVar35 + 0x1ffc) + uVar35);
  if ((*pbStack_d268 & 1) == 0) {
    sStack_d270 = 0;
    ppbVar34 = (byte **)0x0;
    uStack_d26c = 0;
    uStack_d24a = 0;
    uStack_d248 = 0;
    ppbVar33 = ppbVar24;
    switch(*pbStack_d268 & 0xe) {
    default:
      uVar22 = (uint)*(ushort *)(pbStack_d268 + 2);
      ppbVar33 = ppbVar34;
      if (0x1f9d < *(ushort *)(pbStack_d268 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102a1f;
        func_0x(pbStack_d268,6);
        ppbVar33 = (byte **)(ulonglong)uStack_d26c;
      }
      break;
    case 4:
      uVar22 = 9;
      ppbVar33 = ppbVar34;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar22 = 1;
      ppbVar33 = ppbVar34;
    }
    uStack_d260 = (byte **)CONCAT44(uStack_d260._4_4_,uVar22);
    uStack_d252 = (undefined2)(uVar35 + 0x2000);
    uStack_d250 = (undefined6)(uVar35 + 0x2000 >> 0x10);
    ppbVar34 = (byte **)(ulonglong)uVar22;
  }
  else {
    sStack_d270 = 1;
    bVar18 = *pbStack_d268;
    switch(bVar18 & 0x1c) {
    default:
      if ((char)pbStack_d268[1] < '\0') {
        uStack_d26e = (*(ushort *)(pbStack_d268 + 1) & 0x7f) << 8 |
                      *(ushort *)(pbStack_d268 + 1) >> 8;
        uStack_d258._0_2_ = 3;
        sVar30 = 3;
      }
      else {
        uStack_d26e = (ushort)pbStack_d268[1];
        uStack_d258._0_2_ = 2;
        sVar30 = 2;
      }
      uStack_d254 = (short)(uStack_d26e + 1 >> 1) + sVar30;
      if (uStack_d26e < 0x1f) {
        uStack_d258._2_2_ = 0;
        uStack_d26c = 0;
        uStack_d240 = 0;
        ppbVar33 = ppbVar24;
      }
      else {
        uStack_d258._2_2_ = (undefined2)((int)(uStack_d26e - 1) / 0x1e);
        ppbVar33 = (byte **)0x0;
        uStack_d26c = 0;
        uStack_d240 = 0;
      }
      break;
    case 4:
      if (((bVar18 & 0x1c) == 4) && ((bVar18 & 2) != 0)) {
        uStack_d258._0_2_ = 0;
        uStack_d258._2_2_ = 0;
        uStack_d254 = 0;
        uStack_d252 = 0;
        uStack_d26e = 0;
        uStack_d250 = 0;
        uStack_d24a = 0;
        uStack_d26c = 0xf;
        uStack_d240 = 1;
      }
      else {
        uStack_d258._0_2_ = 0;
        uStack_d258._2_2_ = 0;
        uStack_d254 = 0;
        uStack_d252 = 0;
        uStack_d26e = 0;
        uStack_d250 = 0;
        uStack_d24a = 0;
        ppbVar33 = (byte **)0x1;
        uStack_d26c = 1;
        uStack_d240 = 0;
      }
      break;
    case 8:
      uStack_d258._0_2_ = 0;
      uStack_d258._2_2_ = 0;
      uStack_d254 = 0;
      uStack_d252 = 0;
      uStack_d26e = 0;
      uStack_d250 = 0;
      uStack_d24a = 0;
      ppbVar33 = (byte **)0x9;
      uStack_d26c = 9;
      uStack_d240 = 0;
    }
    lVar11 = uVar35 + 0x2000;
    uStack_d248 = (undefined2)lVar11;
    uStack_d246 = (undefined2)((ulonglong)lVar11 >> 0x10);
    uStack_d244 = (ushort)((ulonglong)lVar11 >> 0x20);
    uStack_d242 = (undefined2)((ulonglong)lVar11 >> 0x30);
    uStack_d260 = ppbVar34;
  }
  uVar22 = CONCAT22(uStack_d258._2_2_,(undefined2)uStack_d258);
  if (sStack_d270 == 0) {
    if ((int)ppbVar33 == 0) {
      uStack_d26e = 0;
      uVar22 = (uint)ppbVar34;
      ppbVar33 = (byte **)((ulonglong)ppbVar34 & 0xffffffff);
      if ((*pbStack_d268 & 0x10) != 0) {
        uVar22 = uVar22 + 2 +
                 (*(ushort *)(pbStack_d268 + ((ulonglong)ppbVar34 & 0xffffffff)) + 7 >> 3);
        ppbVar33 = (byte **)(ulonglong)uVar22;
      }
      uStack_d260 = (byte **)CONCAT44(uVar22,(uint)uStack_d260);
      uVar22 = (uint)ppbVar33;
      if ((*pbStack_d268 & 0x20) == 0) {
        uStack_d254 = 0;
        uStack_d26c = uVar22;
      }
      else {
        puVar26 = (ushort *)((longlong)ppbVar33 + (longlong)pbStack_d268);
        uStack_d254 = *puVar26;
        if (uStack_d254 == 0) {
          if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         ((ulonglong)*puRam00000000010e4c20 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102b4b;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102b6f;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102b7d;
          func_0x(pbStack_d268,3);
        }
        uStack_d258 = uStack_d260._4_4_ + 2 + (uint)uStack_d254 * 2;
        if (0x1f9e < uStack_d258) {
          if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         ((ulonglong)*puRam00000000010e4c20 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102c20;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102c44;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102c52;
          func_0x(pbStack_d268,4);
        }
        uVar35 = (ulonglong)uStack_d254;
        uStack_d26c = puVar26[uVar35] & 0x7fff;
        if (uStack_d26c < uStack_d258) {
          if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         ((ulonglong)*puRam00000000010e4c20 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102cf6;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102d1a;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102d28;
          func_0x(pbStack_d268,4);
          uVar35 = (ulonglong)uStack_d254;
        }
        ppbVar33 = (byte **)(ulonglong)uStack_d26c;
        uVar22 = uStack_d258;
        do {
          if (-1 < (short)puVar26[(ulonglong)((int)uVar35 - 1) + 1]) break;
          uVar25 = uStack_d258;
          if ((int)uVar35 != 1) {
            uVar25 = *(ushort *)(pbStack_d268 + uVar35 * 2 + (((ulonglong)uStack_d260 >> 0x20) - 2))
                     & 0x7fff;
          }
          if ((uVar25 < uStack_d258) ||
             ((*(ushort *)(pbStack_d268 + uVar35 * 2 + ((ulonglong)uStack_d260 >> 0x20)) & 0x7fff) <
              uVar25)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102d96;
            uStack_d258 = uVar22;
            func_0x(pbStack_d268,7);
            uVar35 = (ulonglong)uStack_d254;
            ppbVar33 = (byte **)(ulonglong)uStack_d26c;
            uVar22 = uStack_d258;
          }
          if ((uVar25 < uStack_d258) || ((uint)ppbVar33 < uVar25)) goto code_r0x001030a5;
          if (*(ushort *)(pbStack_d268 + uVar25) == 5) {
            uStack_d26e = uStack_d26e | 2;
            uStack_d254 = (short)uVar35 - 1;
            uStack_d246 = (undefined2)uVar25;
            if ((*(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_d244 = uStack_d244 & 0xc7ff;
            }
            else {
              uStack_d244 = uStack_d244 ^
                            (uStack_d244 ^
                            *(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2)) & 0x3800;
            }
            uStack_d244 = (uStack_d244 ^
                          *(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2)) & 0x7ff ^
                          uStack_d244;
            break;
          }
          if (*(ushort *)(pbStack_d268 + uVar25) < 0x400) break;
          uStack_d26e = uStack_d26e | 1;
          uStack_d254 = (short)uVar35 - 1;
          uVar35 = (ulonglong)uStack_d254;
        } while (uStack_d254 != 0);
      }
      if ((*pbStack_d268 & 0x40) == 0) {
        uStack_d24a = 0;
        uStack_d248 = 0;
      }
      else {
        uStack_d24a = SUB82(ppbVar33,0);
        uStack_d248 = (undefined2)((ulonglong)ppbVar33 >> 0x10);
        uStack_d26c = (int)ppbVar33 + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102ea9;
        uStack_d258 = uVar22;
        puVar16 = (ulonglong *)func_0x(&uStack_d26e);
        uVar35 = *puVar16;
        uVar21 = (ushort)(uVar35 >> 0x30);
        uVar19 = uVar21;
        if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
          uVar19 = uVar21 & 0xdfff;
          if ((uVar35 & 0x4000000000000000) != 0) {
            uVar19 = uVar21 | 0x2000;
          }
        }
        uVar22 = uVar23;
        if (uVar19 == 0xfffc) {
          uVar22 = (uint)((uVar35 >> 0x20 & 0xffff) >> 5);
        }
        uStack_d26c = uStack_d26c + uVar22;
        ppbVar33 = (byte **)(ulonglong)uStack_d26c;
        uVar22 = uStack_d258;
      }
      uStack_d258 = uVar22;
      if (((byte *)CONCAT62(uStack_d250,uStack_d252) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_d250,uStack_d252) <
          (byte *)((longlong)ppbVar33 + (longlong)pbStack_d268))) {
        if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
           (((lVar11 = *(longlong *)
                        ((ulonglong)*puRam00000000010e4c20 +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
             (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102fa8;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102fcc;
            (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102fda;
        func_0x(pbStack_d268,0x12);
        ppbVar33 = (byte **)(ulonglong)uStack_d26c;
      }
      uVar22 = uStack_d258;
      if (0x3f3b < (int)ppbVar33 - 1U) {
        if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
           ((lVar11 = *(longlong *)
                       ((ulonglong)*puRam00000000010e4c20 +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
            ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
             (*(char *)(lVar11 + 0x499) != '\0')))))) {
          if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103067;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10308b;
            (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103099;
        func_0x(pbStack_d268,5);
        ppbVar33 = (byte **)(ulonglong)uStack_d26c;
        uVar22 = uStack_d258;
      }
    }
code_r0x001030a5:
    uVar25 = (uint)ppbVar33;
    if ((uVar25 < 9) && (((*pbStack_d268 & 0xe) == 0 || ((*pbStack_d268 & 0xe) == 0xc)))) {
      uVar25 = 9;
    }
  }
  else {
    if ((int)ppbVar33 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1030d6;
      func_0x(&uStack_d26e);
      ppbVar33 = (byte **)(ulonglong)uStack_d26c;
    }
    uVar22 = CONCAT22(uStack_d258._2_2_,(undefined2)uStack_d258);
    uVar25 = (uint)ppbVar33;
    if ((uVar25 < 9) && (((*pbStack_d268 & 0x1c) == 0 || ((*pbStack_d268 & 0x1c) == 0xc)))) {
      uVar25 = 9;
    }
  }
  uVar27 = 0x6fa;
  uStack_d258 = uVar22;
  if (uVar25 != 0x6fa) {
    if (sStack_d270 == 0) {
      if ((int)ppbVar33 == 0) {
        uStack_d26e = 0;
        ppbVar33 = (byte **)((ulonglong)uStack_d260 & 0xffffffff);
        uVar22 = (uint)uStack_d260;
        if ((*pbStack_d268 & 0x10) != 0) {
          uVar22 = (uint)uStack_d260 + 2 +
                   (*(ushort *)((longlong)ppbVar33 + (longlong)pbStack_d268) + 7 >> 3);
          ppbVar33 = (byte **)(ulonglong)uVar22;
        }
        uStack_d260 = (byte **)CONCAT44(uVar22,(uint)uStack_d260);
        uVar22 = (uint)ppbVar33;
        if ((*pbStack_d268 & 0x20) == 0) {
          uStack_d254 = 0;
          uStack_d26c = uVar22;
        }
        else {
          puVar26 = (ushort *)((longlong)ppbVar33 + (longlong)pbStack_d268);
          uStack_d254 = *puVar26;
          if (uStack_d254 == 0) {
            if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*puRam00000000010e4c20 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1031ef;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103215;
                (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103223;
            func_0x(pbStack_d268,3);
          }
          uStack_d258 = uStack_d260._4_4_ + 2 + (uint)uStack_d254 * 2;
          if (0x1f9e < uStack_d258) {
            if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
               ((lVar11 = *(longlong *)
                           ((ulonglong)*puRam00000000010e4c20 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
                ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                 (*(char *)(lVar11 + 0x499) != '\0')))))) {
              if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1032c6;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1032ec;
                (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1032fa;
            func_0x(pbStack_d268,4);
          }
          uStack_d26c = puVar26[uStack_d254] & 0x7fff;
          ppbVar33 = (byte **)(ulonglong)uStack_d26c;
          uVar22 = uStack_d258;
          if (uStack_d26c < uStack_d258) {
            if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*puRam00000000010e4c20 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10339e;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1033c4;
                (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1033d2;
            func_0x(pbStack_d268,4);
            ppbVar33 = (byte **)(ulonglong)uStack_d26c;
            uVar22 = uStack_d258;
          }
          do {
            if (-1 < (short)puVar26[(ulonglong)(uStack_d254 - 1) + 1]) break;
            uVar25 = uStack_d258;
            if (uStack_d254 != 1) {
              uVar25 = *(ushort *)
                        (pbStack_d268 +
                        (ulonglong)uStack_d254 * 2 + (((ulonglong)uStack_d260 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar25 < uStack_d258) ||
               ((*(ushort *)
                  (pbStack_d268 + (ulonglong)uStack_d254 * 2 + ((ulonglong)uStack_d260 >> 0x20)) &
                0x7fff) < uVar25)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103446;
              uStack_d258 = uVar22;
              func_0x(pbStack_d268,7);
              ppbVar33 = (byte **)(ulonglong)uStack_d26c;
              uVar22 = uStack_d258;
            }
            if ((uVar25 < uStack_d258) || ((uint)ppbVar33 < uVar25)) goto code_r0x00103745;
            if (*(ushort *)(pbStack_d268 + uVar25) == 5) {
              uStack_d26e = uStack_d26e | 2;
              uStack_d254 = uStack_d254 - 1;
              uStack_d246 = (undefined2)uVar25;
              if ((*(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2) & 0x4000) == 0) {
                uStack_d244 = uStack_d244 & 0xc7ff;
              }
              else {
                uStack_d244 = uStack_d244 ^
                              (*(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2) ^
                              uStack_d244) & 0x3800;
              }
              uStack_d244 = (uStack_d244 ^
                            *(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2)) & 0x7ff ^
                            uStack_d244;
              break;
            }
            if (*(ushort *)(pbStack_d268 + uVar25) < 0x400) break;
            uStack_d26e = uStack_d26e | 1;
            uStack_d254 = uStack_d254 - 1;
          } while (uStack_d254 != 0);
        }
        if ((*pbStack_d268 & 0x40) == 0) {
          uStack_d24a = 0;
          uStack_d248 = 0;
        }
        else {
          uStack_d24a = SUB82(ppbVar33,0);
          uStack_d248 = (undefined2)((ulonglong)ppbVar33 >> 0x10);
          uStack_d26c = (int)ppbVar33 + 0xe;
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10354d;
          uStack_d258 = uVar22;
          puVar16 = (ulonglong *)func_0x(&uStack_d26e);
          uVar35 = *puVar16;
          uVar21 = (ushort)(uVar35 >> 0x30);
          uVar19 = uVar21;
          if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
            uVar19 = uVar21 & 0xdfff;
            if ((uVar35 & 0x4000000000000000) != 0) {
              uVar19 = uVar21 | 0x2000;
            }
          }
          uVar22 = uVar23;
          if (uVar19 == 0xfffc) {
            uVar22 = (uint)((uVar35 >> 0x20 & 0xffff) >> 5);
          }
          uStack_d26c = uStack_d26c + uVar22;
          ppbVar33 = (byte **)(ulonglong)uStack_d26c;
          uVar22 = uStack_d258;
        }
        uStack_d258 = uVar22;
        if (((byte *)CONCAT62(uStack_d250,uStack_d252) != (byte *)0x0) &&
           ((byte *)CONCAT62(uStack_d250,uStack_d252) <
            (byte *)((longlong)ppbVar33 + (longlong)pbStack_d268))) {
          if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
             (((lVar11 = *(longlong *)
                          ((ulonglong)*puRam00000000010e4c20 +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
               (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10364c;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103672;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x877);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103680;
          func_0x(pbStack_d268,0x12);
          ppbVar33 = (byte **)(ulonglong)uStack_d26c;
        }
        uVar22 = uStack_d258;
        if (0x3f3b < (int)ppbVar33 - 1U) {
          if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         ((ulonglong)*puRam00000000010e4c20 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10370d;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103733;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x87c);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103741;
          func_0x(pbStack_d268,5);
          ppbVar33 = (byte **)(ulonglong)uStack_d26c;
          uVar22 = uStack_d258;
        }
      }
code_r0x00103745:
      if ((uint)ppbVar33 < 9) {
        bVar18 = *pbStack_d268 & 0xe;
joined_r0x0010377e:
        if ((bVar18 == 0) || (bVar18 == 0xc)) {
          ppbVar33 = (byte **)0x9;
        }
      }
    }
    else {
      if ((int)ppbVar33 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10376a;
        func_0x(&uStack_d26e);
        ppbVar33 = (byte **)(ulonglong)uStack_d26c;
        uVar22 = uStack_d258;
      }
      if ((uint)ppbVar33 < 9) {
        bVar18 = *pbStack_d268 & 0x1c;
        goto joined_r0x0010377e;
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10379d;
    uStack_d258 = uVar22;
    func_0x(0x148a990,ppbVar33,0x6fa);
  }
  uVar19 = *(ushort *)(uVar36 + 0x1ffe);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1037b2;
  func_0x(uVar19 + uVar36,0,0x6fa);
  uVar35 = (ulonglong)uStack_d26c;
  if (sStack_d270 == 0) {
    uVar22 = uStack_d258;
    if (uStack_d26c == 0) {
      uStack_d26e = 0;
      uVar35 = (ulonglong)uStack_d260 & 0xffffffff;
      uVar22 = (uint)uStack_d260;
      if ((*pbStack_d268 & 0x10) != 0) {
        uVar22 = (uint)uStack_d260 + 2 + (*(ushort *)(pbStack_d268 + uVar35) + 7 >> 3);
        uVar35 = (ulonglong)uVar22;
      }
      uStack_d260 = (byte **)CONCAT44(uVar22,(uint)uStack_d260);
      uVar22 = (uint)uVar35;
      if ((*pbStack_d268 & 0x20) == 0) {
        uStack_d254 = 0;
        uStack_d26c = uVar22;
      }
      else {
        puVar26 = (ushort *)(pbStack_d268 + uVar35);
        uStack_d254 = *puVar26;
        if (uStack_d254 == 0) {
          if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         ((ulonglong)*puRam00000000010e4c20 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10388f;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1038b5;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1038c3;
          func_0x(pbStack_d268,3);
        }
        uStack_d258 = uStack_d260._4_4_ + 2 + (uint)uStack_d254 * 2;
        if (0x1f9e < uStack_d258) {
          if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         ((ulonglong)*puRam00000000010e4c20 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103967;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10398d;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10399b;
          func_0x(pbStack_d268,4);
        }
        uVar31 = (ulonglong)uStack_d254;
        uStack_d26c = puVar26[uVar31] & 0x7fff;
        uVar35 = (ulonglong)uStack_d26c;
        uVar22 = uStack_d258;
        if (uStack_d26c < uStack_d258) {
          if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         ((ulonglong)*puRam00000000010e4c20 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103a3e;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103a64;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103a72;
          func_0x(pbStack_d268,4);
          uVar31 = (ulonglong)uStack_d254;
          uVar35 = (ulonglong)uStack_d26c;
          uVar22 = uStack_d258;
        }
        do {
          if (-1 < (short)puVar26[(ulonglong)((int)uVar31 - 1) + 1]) break;
          uVar25 = uStack_d258;
          if ((int)uVar31 != 1) {
            uVar25 = *(ushort *)(pbStack_d268 + uVar31 * 2 + (((ulonglong)uStack_d260 >> 0x20) - 2))
                     & 0x7fff;
          }
          if ((uVar25 < uStack_d258) ||
             ((*(ushort *)(pbStack_d268 + uVar31 * 2 + ((ulonglong)uStack_d260 >> 0x20)) & 0x7fff) <
              uVar25)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103ae6;
            uStack_d258 = uVar22;
            func_0x(pbStack_d268,7);
            uVar31 = (ulonglong)uStack_d254;
            uVar35 = (ulonglong)uStack_d26c;
            uVar22 = uStack_d258;
          }
          if ((uVar25 < uStack_d258) || ((uint)uVar35 < uVar25)) goto code_r0x00103de1;
          if (*(ushort *)(pbStack_d268 + uVar25) == 5) {
            uStack_d26e = uStack_d26e | 2;
            uStack_d254 = (short)uVar31 - 1;
            uStack_d246 = (undefined2)uVar25;
            if ((*(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_d244 = uStack_d244 & 0xc7ff;
            }
            else {
              uStack_d244 = uStack_d244 ^
                            (*(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2) ^
                            uStack_d244) & 0x3800;
            }
            uStack_d244 = (uStack_d244 ^
                          *(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2)) & 0x7ff ^
                          uStack_d244;
            break;
          }
          if (*(ushort *)(pbStack_d268 + uVar25) < 0x400) break;
          uStack_d26e = uStack_d26e | 1;
          uStack_d254 = (short)uVar31 - 1;
          uVar31 = (ulonglong)uStack_d254;
        } while (uStack_d254 != 0);
      }
      if ((*pbStack_d268 & 0x40) == 0) {
        uStack_d24a = 0;
        uStack_d248 = 0;
      }
      else {
        uStack_d24a = (undefined2)uVar35;
        uStack_d248 = (undefined2)(uVar35 >> 0x10);
        uStack_d26c = (int)uVar35 + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103bef;
        uStack_d258 = uVar22;
        puVar16 = (ulonglong *)func_0x(&uStack_d26e);
        uVar35 = *puVar16;
        uVar21 = (ushort)(uVar35 >> 0x30);
        uVar19 = uVar21;
        if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
          uVar19 = uVar21 & 0xdfff;
          if ((uVar35 & 0x4000000000000000) != 0) {
            uVar19 = uVar21 | 0x2000;
          }
        }
        uVar22 = uVar23;
        if (uVar19 == 0xfffc) {
          uVar22 = (uint)((uVar35 >> 0x20 & 0xffff) >> 5);
        }
        uStack_d26c = uStack_d26c + uVar22;
        uVar35 = (ulonglong)uStack_d26c;
        uVar22 = uStack_d258;
      }
      uStack_d258 = uVar22;
      if (((byte *)CONCAT62(uStack_d250,uStack_d252) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_d250,uStack_d252) < pbStack_d268 + uVar35)) {
        if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
           (((lVar11 = *(longlong *)
                        ((ulonglong)*puRam00000000010e4c20 +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
             (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103ceb;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103d11;
            (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103d1f;
        func_0x(pbStack_d268,0x12);
        uVar35 = (ulonglong)uStack_d26c;
      }
      uVar22 = uStack_d258;
      if (0x3f3b < (int)uVar35 - 1U) {
        if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
           ((lVar11 = *(longlong *)
                       ((ulonglong)*puRam00000000010e4c20 +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
            ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
             (*(char *)(lVar11 + 0x499) != '\0')))))) {
          if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103daa;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103dd0;
            (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103dde;
        func_0x(pbStack_d268,5);
        uVar35 = (ulonglong)uStack_d26c;
        uVar22 = uStack_d258;
      }
    }
code_r0x00103de1:
    uStack_d258 = uVar22;
    if (8 < (uint)uVar35) goto code_r0x00103e24;
    bVar18 = *pbStack_d268 & 0xe;
joined_r0x00103e16:
    if ((bVar18 != 0) && (bVar18 != 0xc)) goto code_r0x00103e24;
    uVar22 = 9;
  }
  else {
    if (uStack_d26c == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103e04;
      func_0x(&uStack_d26e);
      uVar35 = (ulonglong)uStack_d26c;
    }
    if ((uint)uVar35 < 9) {
      bVar18 = *pbStack_d268 & 0x1c;
      goto joined_r0x00103e16;
    }
code_r0x00103e24:
    uVar22 = (uint)uVar35;
  }
  uVar25 = (uint)uVar35;
  if (uVar22 < 0x6fb) {
    if (sStack_d270 == 0) {
      uVar22 = uStack_d258;
      if (uVar25 == 0) {
        uStack_d26e = 0;
        uVar35 = (ulonglong)uStack_d260 & 0xffffffff;
        uVar22 = (uint)uStack_d260;
        if ((*pbStack_d268 & 0x10) != 0) {
          uVar22 = (uint)uStack_d260 + 2 + (*(ushort *)(pbStack_d268 + uVar35) + 7 >> 3);
          uVar35 = (ulonglong)uVar22;
        }
        uStack_d260 = (byte **)CONCAT44(uVar22,(uint)uStack_d260);
        uVar22 = (uint)uVar35;
        if ((*pbStack_d268 & 0x20) == 0) {
          uStack_d254 = 0;
          uStack_d26c = uVar22;
        }
        else {
          puVar26 = (ushort *)(pbStack_d268 + uVar35);
          uStack_d254 = *puVar26;
          if (uStack_d254 == 0) {
            if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*puRam00000000010e4c20 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103f09;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103f2f;
                (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103f3d;
            func_0x(pbStack_d268,3);
          }
          uStack_d258 = uStack_d260._4_4_ + 2 + (uint)uStack_d254 * 2;
          if (0x1f9e < uStack_d258) {
            if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
               ((lVar11 = *(longlong *)
                           ((ulonglong)*puRam00000000010e4c20 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
                ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                 (*(char *)(lVar11 + 0x499) != '\0')))))) {
              if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103fe1;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104007;
                (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104015;
            func_0x(pbStack_d268,4);
          }
          uVar31 = (ulonglong)uStack_d254;
          uStack_d26c = puVar26[uVar31] & 0x7fff;
          if (uStack_d26c < uStack_d258) {
            if ((((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           ((ulonglong)*puRam00000000010e4c20 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1040b8;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1040de;
                (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1040ec;
            func_0x(pbStack_d268,4);
            uVar31 = (ulonglong)uStack_d254;
          }
          uVar35 = (ulonglong)uStack_d26c;
          uVar22 = uStack_d258;
          do {
            if (-1 < (short)puVar26[(ulonglong)((int)uVar31 - 1) + 1]) break;
            uVar25 = uStack_d258;
            if ((int)uVar31 != 1) {
              uVar25 = *(ushort *)
                        (pbStack_d268 + uVar31 * 2 + (((ulonglong)uStack_d260 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar25 < uStack_d258) ||
               ((*(ushort *)(pbStack_d268 + uVar31 * 2 + ((ulonglong)uStack_d260 >> 0x20)) & 0x7fff)
                < uVar25)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104166;
              uStack_d258 = uVar22;
              func_0x(pbStack_d268,7);
              uVar31 = (ulonglong)uStack_d254;
              uVar35 = (ulonglong)uStack_d26c;
              uVar22 = uStack_d258;
            }
            if ((uVar25 < uStack_d258) || ((uint)uVar35 < uVar25)) goto code_r0x00104461;
            if (*(ushort *)(pbStack_d268 + uVar25) == 5) {
              uStack_d26e = uStack_d26e | 2;
              uStack_d254 = (short)uVar31 - 1;
              uStack_d246 = (undefined2)uVar25;
              if ((*(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2) & 0x4000) == 0) {
                uStack_d244 = uStack_d244 & 0xc7ff;
              }
              else {
                uStack_d244 = uStack_d244 ^
                              (*(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2) ^
                              uStack_d244) & 0x3800;
              }
              uStack_d244 = (uStack_d244 ^
                            *(ushort *)(pbStack_d268 + (ulonglong)(uVar25 & 0xffff) + 2)) & 0x7ff ^
                            uStack_d244;
              break;
            }
            if (*(ushort *)(pbStack_d268 + uVar25) < 0x400) break;
            uStack_d26e = uStack_d26e | 1;
            uStack_d254 = (short)uVar31 - 1;
            uVar31 = (ulonglong)uStack_d254;
          } while (uStack_d254 != 0);
        }
        if ((*pbStack_d268 & 0x40) == 0) {
          uStack_d24a = 0;
          uStack_d248 = 0;
        }
        else {
          uStack_d24a = (undefined2)uVar35;
          uStack_d248 = (undefined2)(uVar35 >> 0x10);
          uStack_d26c = (int)uVar35 + 0xe;
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10426f;
          uStack_d258 = uVar22;
          puVar16 = (ulonglong *)func_0x(&uStack_d26e);
          uVar35 = *puVar16;
          uVar21 = (ushort)(uVar35 >> 0x30);
          uVar19 = uVar21;
          if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
            uVar19 = uVar21 & 0xdfff;
            if ((uVar35 & 0x4000000000000000) != 0) {
              uVar19 = uVar21 | 0x2000;
            }
          }
          if (uVar19 == 0xfffc) {
            uVar23 = (uint)((uVar35 >> 0x20 & 0xffff) >> 5);
          }
          uStack_d26c = uStack_d26c + uVar23;
          uVar35 = (ulonglong)uStack_d26c;
          uVar22 = uStack_d258;
        }
        uStack_d258 = uVar22;
        if (((byte *)CONCAT62(uStack_d250,uStack_d252) != (byte *)0x0) &&
           ((byte *)CONCAT62(uStack_d250,uStack_d252) < pbStack_d268 + uVar35)) {
          if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
             (((lVar11 = *(longlong *)
                          ((ulonglong)*puRam00000000010e4c20 +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
               (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10436b;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104391;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x877);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10439f;
          func_0x(pbStack_d268,0x12);
          uVar35 = (ulonglong)uStack_d26c;
        }
        uVar22 = uStack_d258;
        if (0x3f3b < (int)uVar35 - 1U) {
          if (((cRam0000000001b7638b != '\0') || ((bRam0000000001b86c90 & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         ((ulonglong)*puRam00000000010e4c20 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000010e4c18 * 8) + 8), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((cRam0000000001b7627b == '\0') && ((bRam0000000001b86c90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10442a;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104450;
              (*pcRam00000000010e4bb0)(1,0x1466db8,0x1586a88,0x87c);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10445e;
          func_0x(pbStack_d268,5);
          uVar35 = (ulonglong)uStack_d26c;
          uVar22 = uStack_d258;
        }
      }
code_r0x00104461:
      uStack_d258 = uVar22;
      uVar27 = (uint)uVar35;
      if (8 < uVar27) goto code_r0x001044a5;
      bVar18 = *pbStack_d268 & 0xe;
    }
    else {
      uVar27 = uVar25;
      if (uVar25 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104484;
        func_0x(&uStack_d26e);
        uVar27 = uStack_d26c;
      }
      if (8 < uVar27) goto code_r0x001044a5;
      bVar18 = *pbStack_d268 & 0x1c;
    }
    if ((bVar18 == 0) || (bVar18 == 0xc)) {
      uVar27 = 9;
    }
  }
code_r0x001044a5:
  uVar19 = *(ushort *)(uVar36 + 0x1ffe);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1044bc;
  func_0x(uVar19 + uVar36,pbStack_d268,uVar27);
  puVar26 = (ushort *)((ulonglong)*(ushort *)(uVar36 + 0x1ffe) + 0x186 + uVar36);
  *puVar26 = *puVar26 | 0x10;
  puVar26 = (ushort *)((ulonglong)*(ushort *)(uVar36 + 0x1ffe) + 0x186 + uVar36);
  *puVar26 = *puVar26 & 0xfffe;
  puVar26 = (ushort *)((ulonglong)*(ushort *)(uVar36 + 0x1ffe) + 0x186 + uVar36);
  *puVar26 = *puVar26 & 0xfffd;
  puVar26 = (ushort *)((ulonglong)*(ushort *)(uVar36 + 0x1ffe) + 0x186 + uVar36);
  *puVar26 = *puVar26 & 0xfffb;
  puVar3 = (uint *)((ulonglong)*(ushort *)(uVar36 + 0x1ffe) + 0x24 + uVar36);
  *puVar3 = *puVar3 & 0xbfffffff;
  uVar19 = *(ushort *)(uVar36 + 0x1ffe);
  *(undefined8 *)((ulonglong)uVar19 + 0x174 + uVar36) = 0;
  *(undefined2 *)((ulonglong)uVar19 + 0x17c + uVar36) = 0;
  uVar19 = *(ushort *)(uVar36 + 0x1ffe);
  *(undefined8 *)((ulonglong)uVar19 + 0x150 + uVar36) = 0;
  *(undefined2 *)((ulonglong)uVar19 + 0x158 + uVar36) = 0;
  uVar19 = *(ushort *)(uVar36 + 0x1ffe);
  *(undefined8 *)((ulonglong)uVar19 + 0x144 + uVar36) = 0;
  *(undefined2 *)((ulonglong)uVar19 + 0x14c + uVar36) = 0;
  *(undefined4 *)(&stack0x00000034 + lVar10) = 9;
  *(undefined2 *)(&stack0x00000038 + lVar10) = 1;
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1045b6;
  func_0x(plStack_d2d0);
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1045d0;
  func_0x(_DAT_,0,0xffffffff,0x26);
  lVar11 = lStack_d2b8;
  if (lStack_d2b8 != 0) {
    *(longlong *)((longlong)&lStackX_8 + lVar10) = (longlong)&param_5 + lVar10;
    *(undefined8 *)((longlong)&iStackX_20 + lVar10 + -0x20) = 0;
    (&stack0xfffffffffffffff8)[lVar10] = 0;
    (&stack0xfffffffffffffff0)[lVar10] = 0;
    (&stack0xffffffffffffffe8)[lVar10] = 0;
    (&stack0xffffffffffffffe0)[lVar10] = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104617;
    lVar17 = func_0x(lVar11,2,3,0);
    lVar28 = -1;
    lVar29 = lVar28;
    if (lVar17 == -1) {
      do {
        lVar29 = lVar29 + 1;
      } while (*(short *)(lVar11 + lVar29 * 2) != 0);
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104655;
      uVar12 = (*_DAT_)(*(undefined4 *)((longlong)&param_5 + lVar10),auStack_d058,0,0);
      *(int *)(&stack0xfffffffffffffff0 + lVar10) = (int)lVar29 * 2;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar10) = lVar11;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = uVar12;
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104679;
      (*_DAT_)(0x33,0x17,0x10,0x43);
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104687;
    (*_DAT_)(lVar17);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104696;
    plVar13 = (longlong *)func_0x(uStack_d2c8,lVar11,0);
    do {
      lVar28 = lVar28 + 1;
    } while (*(short *)(lVar11 + lVar28 * 2) != 0);
    lVar29 = *plVar13;
    *(undefined4 *)((longlong)&lStackX_8 + lVar10) = 1;
    plStack_d298 = plVar13;
    *(undefined4 *)((longlong)&iStackX_20 + lVar10 + -0x20) = 2;
    *(ulonglong *)(&stack0xfffffffffffffff8 + lVar10) = lVar28 * 2 & 0xffffffff;
    *(longlong *)(&stack0xfffffffffffffff0 + lVar10) = lVar11;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0x11ebb20;
    pcVar5 = *(code **)(lVar29 + 0x68);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1046e8;
    (*pcVar5)(plVar13,0,0,2);
    pcVar5 = *(code **)(*plVar13 + 0x50);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1046f1;
    (*pcVar5)(plVar13);
    plVar7 = plStack_d2d8;
    pcVar5 = *(code **)(*plStack_d2d8 + 0x30);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1046fe;
    uVar9 = (*pcVar5)(plStack_d2d8);
    *(undefined4 *)(plVar7 + 0x10) = uVar9;
    if (param_5 == 0) {
      pcVar5 = *(code **)(*plVar13 + 0x60);
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104722;
      (*pcVar5)(plVar13,uVar9,1);
      *(undefined4 *)(plVar13 + 0x10) = uVar9;
      pcVar5 = *(code **)(*plVar13 + 0x20);
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10473c;
      (*pcVar5)(plVar13,0,0,uVar9);
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) = *(undefined4 *)(plVar7 + 0x10);
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104757;
      func_0x(plVar7,plVar13,0,0);
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10476c;
      func_0x(plStack_d2d8,plVar13,param_5,param_6);
    }
    pcVar5 = *(code **)(*plVar13 + 0xb0);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10477c;
    (*pcVar5)(plVar13,1);
  }
  if (plStack_d2d8 != (longlong *)0x0) {
    pcVar5 = *(code **)(*plStack_d2d8 + 0xb0);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104795;
    (*pcVar5)(plStack_d2d8,1);
  }
  if (plStack_d2d0 != (longlong *)0x0) {
    pcVar5 = *(code **)(*plStack_d2d0 + 0xb0);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1047ab;
    (*pcVar5)(plStack_d2d0,1);
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1047ba;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar10));
  return;
}

