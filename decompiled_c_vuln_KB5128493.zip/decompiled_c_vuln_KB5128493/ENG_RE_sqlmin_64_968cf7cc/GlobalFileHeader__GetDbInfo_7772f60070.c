
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2)

{
  byte *pbVar1;
  short sVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  ushort uVar7;
  uint **ppuVar8;
  char cVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  longlong lVar14;
  longlong lVar15;
  uint *puVar16;
  short *psVar17;
  code *UNRECOVERED_JUMPTABLE_00;
  byte **ppbVar18;
  longlong lVar19;
  ulonglong uVar20;
  longlong unaff_GS_OFFSET;
  undefined auStack_528 [32];
  undefined8 uStack_508;
  uint *puStack_500;
  longlong *plStack_4f8;
  undefined uStack_4f0;
  uint uStack_4ec;
  uint uStack_4e8;
  int iStack_4e0;
  short sStack_4dc;
  undefined4 uStack_4d8;
  undefined8 uStack_4d4;
  undefined4 uStack_4cc;
  uint auStack_4c8 [2];
  undefined8 uStack_4c0;
  ushort uStack_4b8;
  undefined8 uStack_4b0;
  ushort uStack_4a8;
  undefined8 uStack_4a0;
  undefined2 uStack_498;
  undefined auStack_490 [4];
  undefined4 uStack_48c;
  undefined4 uStack_488;
  undefined2 uStack_484;
  undefined4 uStack_480;
  undefined2 uStack_47c;
  undefined4 uStack_478;
  undefined2 uStack_474;
  undefined4 uStack_470;
  undefined2 uStack_46c;
  undefined8 uStack_468;
  undefined2 uStack_460;
  longlong *plStack_458;
  undefined8 uStack_450;
  undefined8 uStack_448;
  undefined2 uStack_440;
  undefined8 uStack_438;
  ushort uStack_430;
  undefined auStack_428 [4];
  undefined auStack_424 [4];
  undefined auStack_420 [4];
  undefined auStack_41c [4];
  uint uStack_418;
  undefined8 uStack_414;
  undefined8 uStack_400;
  undefined auStack_3f8 [8];
  undefined4 uStack_3f0;
  undefined4 uStack_3e8;
  uint **ppuStack_3e0;
  undefined *puStack_3d8;
  undefined8 uStack_3d0;
  uint *puStack_3c8;
  undefined4 uStack_3c0;
  undefined4 uStack_3bc;
  longlong lStack_3b8;
  undefined4 uStack_3b0;
  undefined4 uStack_3ac;
  longlong lStack_3a8;
  undefined4 uStack_3a0;
  undefined4 uStack_39c;
  short *psStack_398;
  int iStack_390;
  undefined4 uStack_38c;
  short *psStack_388;
  int iStack_380;
  undefined4 uStack_37c;
  undefined8 uStack_378;
  undefined4 uStack_370;
  undefined4 uStack_36c;
  undefined auStack_368 [448];
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  uint uStack_198;
  short sStack_194;
  int iStack_192;
  undefined uStack_18e;
  undefined uStack_18d;
  short sStack_158;
  undefined4 uStack_154;
  byte *pbStack_150;
  byte **ppbStack_148;
  undefined8 uStack_13a;
  undefined2 uStack_132;
  undefined2 uStack_130;
  undefined6 uStack_12e;
  undefined4 uStack_124;
  undefined auStack_120 [16];
  undefined auStack_110 [8];
  undefined8 uStack_108;
  undefined8 uStack_100;
  undefined6 uStack_f8;
  undefined2 uStack_f2;
  undefined6 uStack_f0;
  undefined2 uStack_ea;
  undefined8 uStack_e8;
  undefined auStack_e0 [16];
  undefined auStack_d0 [16];
  undefined auStack_c0 [16];
  undefined8 uStack_b0;
  short asStack_a8 [24];
  short asStack_78 [24];
  ulonglong uStack_48;
  
  uStack_400 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_528;
  lVar14 = 0;
  plStack_4f8 = (longlong *)0x0;
  uStack_4f0 = 0;
  uStack_4ec = 0;
  sStack_158 = -1;
  pbStack_150 = (byte *)0x0;
  uStack_154 = 0;
  uStack_13a = 0;
  uStack_130 = 0;
  uStack_12e = 0;
  ppbStack_148 = (byte **)0x0;
  uStack_124 = 0xffffffff;
  uStack_4d8 = 0;
  plStack_458 = param_1;
  uStack_450 = param_2;
  if ((*(byte *)(*param_1 + 0x7c) & 1) == 0) {
LAB_:
    func_0x(&plStack_4f8);
    func_0x(uStack_48 ^ (ulonglong)auStack_528);
    return;
  }
  iStack_4e0 = 0;
  sStack_4dc = 2;
  lVar15 = param_1[1];
  uStack_414 = 0;
  if ((((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) &&
      ((lVar4 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar4 == 0 ||
       ((lVar4 = **(longlong **)(lVar4 + 0x38), lVar4 == 0 ||
        (iVar10 = (*_DAT_)(lVar4,0x337), iVar10 == 0)))))) &&
     (lVar4 = *(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8), lVar4 != 0)) {
    lVar14 = *(longlong *)(lVar4 + 0x60);
  }
  lVar4 = *(longlong *)(lVar15 + 0x728);
  do {
    plVar5 = plStack_4f8;
    auStack_4c8[0] = 0;
    if (plStack_4f8 != (longlong *)0x0) {
      iVar10 = (int)(short)uStack_4ec;
      if (((*(ushort *)((longlong)plStack_4f8 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_4f8 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_4f8 + 100) & 8) != 0) &&
              (lVar19 = plStack_4f8[0x12], lVar19 != 0)) && (*(longlong *)(lVar19 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar19 + 0x758),plStack_4f8,iVar10);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
            ((2 < iVar10 &&
             (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0))))))
           && (iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_428), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar5 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar5,0,iVar10);
        }
        uStack_4ec = uStack_4ec & 0xffff0000;
        plStack_4f8 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_4f8);
      }
    }
    if ((*(longlong *)(lVar15 + 0x728) != 0) &&
       (func_0x(&plStack_4f8,&iStack_4e0,lVar15), plVar5 = plStack_4f8,
       plStack_4f8 != (longlong *)0x0)) {
      iVar10 = (int)(short)uStack_4ec;
      if (((*(ushort *)((longlong)plStack_4f8 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_4f8 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_4f8 + 100) & 8) != 0) &&
              (lVar19 = plStack_4f8[0x12], lVar19 != 0)) && (*(longlong *)(lVar19 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar19 + 0x758),plStack_4f8,iVar10);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
            ((2 < iVar10 &&
             (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0))))))
           && (iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_424), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar5 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar5,0,iVar10);
        }
        uStack_4ec = uStack_4ec & 0xffff0000;
        plStack_4f8 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_4f8);
      }
    }
    puStack_500 = &uStack_418;
    uStack_508 = CONCAT44(uStack_508._4_4_,2);
    plStack_4f8 = (longlong *)func_0x(_DAT_,lVar15,&iStack_4e0,auStack_4c8);
    if (lVar14 != 0) {
      uVar20 = (ulonglong)(*(uint *)(lVar14 + 0x500) & 0xf);
      if (*(longlong *)(lVar14 + 0x508 + uVar20 * 8) != *plStack_4f8) {
        *(longlong *)(lVar14 + 0x508 + uVar20 * 8) = *plStack_4f8;
        *(longlong *)(lVar14 + 0x500) = *(longlong *)(lVar14 + 0x500) + 1;
      }
    }
    uStack_4ec = (auStack_4c8[0] >> 3 & 1) << 0x18 | uStack_4ec & 0xff0002 | 2;
    uStack_4e8 = auStack_4c8[0] >> 4 & 1 | uStack_4e8 & 0xffffff00;
    if (((lVar4 != 0) && (lVar14 != 0)) && (lVar14 == *(longlong *)(lVar15 + 0x1c38))) {
      *(longlong *)(lVar4 + 0x5b28) = *(longlong *)(lVar4 + 0x5b28) + 1;
      if ((int)uStack_414 != 0) {
        *(longlong *)(lVar4 + 0x5b30) = *(longlong *)(lVar4 + 0x5b30) + 1;
        *(longlong *)(lVar4 + 0x5b38) = *(longlong *)(lVar4 + 0x5b38) + (ulonglong)uStack_418;
        if (0xffffff < uStack_4ec) {
          *(longlong *)(lVar4 + 0x5b40) = *(longlong *)(lVar4 + 0x5b40) + 1;
          *(longlong *)(lVar4 + 0x5b48) = *(longlong *)(lVar4 + 0x5b48) + (ulonglong)uStack_418;
        }
      }
    }
    cVar9 = func_0x(lVar15);
    if (((cVar9 == '\0') || (*(char *)(lVar15 + 0x2050) == '\0')) ||
       ((iStack_4e0 == 0 || ((iStack_4e0 == 9 && (sStack_4dc == 1)))))) goto LAB_;
    lVar19 = *plStack_4f8;
    if (*(short *)(lVar19 + 0x24) == 0) {
LAB_:
      uStack_4b0 = *(undefined8 *)(lVar19 + 0x28);
      uStack_4a8 = *(ushort *)(lVar19 + 0x30);
    }
    else {
      cVar9 = *(char *)(lVar19 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(lVar19 + 0x18) != 99) {
LAB_:
          if (cVar9 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar9 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar19 + 0x18) != 99) goto LAB_;
      }
      uStack_488 = *(undefined4 *)(lVar19 + 0x20);
      uStack_484 = *(undefined2 *)(lVar19 + 0x24);
      cVar9 = func_0x(&uStack_488);
      if (cVar9 == '\0') goto LAB_;
      func_0x(lVar19,&uStack_4b0);
    }
    uVar12 = *(uint *)(lVar15 + 0x2108);
    do {
      uVar11 = uVar12 & 0xfffffffe;
      uStack_4d4 = *(undefined8 *)(lVar15 + 0x20fc);
      uStack_4cc = *(undefined4 *)(lVar15 + 0x2104);
      LOCK();
      UNLOCK();
      uVar12 = *(uint *)(lVar15 + 0x2108);
    } while (uVar11 != uVar12);
    if ((uint)uStack_4b0 <= (uint)uStack_4d4) {
      if ((uint)uStack_4d4 != (uint)uStack_4b0) goto LAB_;
      uVar12 = (uint)((ulonglong)uStack_4d4 >> 0x20);
      if ((uStack_4b0._4_4_ <= uVar12) &&
         ((uVar12 != uStack_4b0._4_4_ || (uStack_4a8 <= (ushort)uStack_4cc)))) goto LAB_;
    }
    if ((*(char *)(lVar15 + 0x6ac8) == '\0') &&
       ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) != *(longlong *)(lVar15 + 0x2120) &&
        (cVar9 = func_0x(lVar15), cVar9 == '\0')))) {
      uVar12 = *(uint *)(lVar15 + 0x2108);
      do {
        uVar11 = uVar12 & 0xfffffffe;
        uStack_4d4 = *(undefined8 *)(lVar15 + 0x20fc);
        uStack_4cc = *(undefined4 *)(lVar15 + 0x2104);
        LOCK();
        UNLOCK();
        uVar12 = *(uint *)(lVar15 + 0x2108);
      } while (uVar11 != uVar12);
      uVar7 = (ushort)uStack_4cc;
      uStack_430 = (ushort)uStack_4cc;
      lVar14 = *plStack_4f8;
      uStack_438 = uStack_4d4;
      if (*(short *)(lVar14 + 0x24) == 0) {
LAB_:
        uStack_4c0 = *(undefined8 *)(lVar14 + 0x28);
        uStack_4b8 = *(ushort *)(lVar14 + 0x30);
      }
      else {
        cVar9 = *(char *)(lVar14 + 1);
        if (cVar9 == '\v') {
          if (*(int *)(lVar14 + 0x18) != 99) {
LAB_:
            if (cVar9 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar9 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_478 = *(undefined4 *)(lVar14 + 0x20);
        uStack_474 = *(undefined2 *)(lVar14 + 0x24);
        cVar9 = func_0x(&uStack_478);
        if (cVar9 == '\0') goto LAB_;
        func_0x(lVar14,&uStack_4c0);
      }
      if ((uint)uStack_4d4 < (uint)uStack_4c0) {
LAB_:
        lVar14 = *(longlong *)(lVar15 + 0x6b0);
        func_0x(&uStack_4c0,asStack_a8,auStack_490);
        func_0x(&uStack_438,asStack_78,auStack_490);
        if ((_DAT_ & 0x10000) != 0) {
          uStack_3f0 = 0x60000;
          iVar10 = 0;
          uStack_3e8 = 0;
          ppuStack_3e0 = &puStack_3c8;
          puStack_3d8 = auStack_368;
          uStack_1a8 = 0;
          uStack_3d0 = 0;
          uStack_1a0 = 0;
          puStack_3c8 = &uStack_198;
          uStack_3c0 = 0x34;
          uStack_3bc = 5;
          uStack_3b0 = 0x10;
          uStack_3ac = 5;
          uStack_3a0 = 0x10;
          uStack_39c = 6;
          uStack_38c = 7;
          uStack_37c = 8;
          uStack_378 = 0;
          uStack_370 = 0;
          uStack_36c = 9;
          uStack_198 = (uint)*(ushort *)(lVar15 + 0x6b8);
          sStack_194 = sStack_4dc;
          iStack_192 = iStack_4e0;
          uStack_18e = 0xff;
          uStack_18d = *(undefined *)(*plStack_4f8 + 1);
          lStack_3b8 = lVar14 + 0x254;
          lStack_3a8 = lVar14 + 0x244;
          lVar15 = -1;
          do {
            lVar15 = lVar15 + 1;
          } while (asStack_a8[lVar15] != 0);
          iStack_390 = (int)lVar15 * 2;
          psStack_398 = asStack_a8;
          lVar15 = -1;
          do {
            lVar15 = lVar15 + 1;
          } while (asStack_78[lVar15] != 0);
          iStack_380 = (int)lVar15 * 2;
          psStack_388 = asStack_78;
          uStack_48c = 0;
          puVar16 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar14,&uStack_48c);
          ppuVar8 = ppuStack_3e0;
          if (puVar16 != (uint *)0x0) {
            lVar14 = -1;
            do {
              lVar14 = lVar14 + 1;
            } while (*(short *)((longlong)puVar16 + lVar14 * 2) != 0);
            iVar10 = (int)lVar14 * 2;
          }
          ppuStack_3e0[10] = puVar16;
          *(int *)(ppuVar8 + 0xb) = iVar10;
          *(undefined4 *)((longlong)ppuVar8 + 0x5c) = 9;
          func_0x(auStack_3f8);
        }
      }
      else if ((uint)uStack_4d4 == (uint)uStack_4c0) {
        uVar12 = (uint)((ulonglong)uStack_4c0 >> 0x20);
        if ((uStack_4d4._4_4_ < uVar12) || ((uStack_4d4._4_4_ == uVar12 && (uVar7 < uStack_4b8))))
        goto LAB_;
      }
LAB_:
      plVar5 = plStack_4f8;
      lVar14 = *plStack_4f8;
      if ((*(ushort *)(lVar14 + 0x16) < 2) || (*(short *)(lVar14 + 0x1ffc) == 0)) {
        if (plStack_4f8 == (longlong *)0x0) goto LAB_;
        iVar10 = (int)(short)uStack_4ec;
        if (((*(ushort *)((longlong)plStack_4f8 + 0x62) >> 10 & 1) != 0) && (2 < iVar10)) {
          func_0x(&plStack_4f8);
          goto LAB_;
        }
        if (((byte)*(undefined2 *)((longlong)plStack_4f8 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_4f8 + 100) & 8) != 0) &&
              (lVar14 = plStack_4f8[0x12], lVar14 != 0)) && (*(longlong *)(lVar14 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar14 + 0x758),plStack_4f8,iVar10);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
            ((2 < iVar10 &&
             (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0))))))
           && (iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_41c), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar5 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar5,0,iVar10);
        }
        uStack_4ec = uStack_4ec & 0xffff0000;
        plStack_4f8 = (longlong *)0x0;
        goto LAB_;
      }
      uStack_124 = 1;
      if (-1 < *(char *)(lVar14 + 2)) goto LAB_;
      pbVar1 = (byte *)(lVar14 + 0x60);
      if ((sStack_158 == 0) || (ppbVar18 = ppbStack_148, ppbStack_148 == (byte **)0x0)) {
        uStack_f8 = 0;
        uStack_ea = 0;
        auStack_d0 = ZEXT816(0);
        auStack_120 = ZEXT816(0);
        stack0xfffffffffffffef2 = SUB1614(ZEXT816(0),2);
        auStack_110._0_2_ = 0xffff;
        uStack_108 = 0;
        uStack_f2 = 0;
        uStack_f0 = 0;
        uStack_e8 = 0;
        uStack_100 = 0;
        auStack_e0 = ZEXT816(0);
        auStack_c0._0_12_ = ZEXT812(0);
        auStack_c0._12_4_ = 0;
        uStack_b0 = 0;
        ppbVar18 = (byte **)auStack_120;
      }
      if (*(short *)(lVar14 + 0x24) == 0) {
LAB_:
        uStack_4a0 = *(undefined8 *)(lVar14 + 0x28);
        uStack_498 = *(undefined2 *)(lVar14 + 0x30);
      }
      else {
        cVar9 = *(char *)(lVar14 + 1);
        if (cVar9 == '\v') {
          if (*(int *)(lVar14 + 0x18) != 99) {
LAB_:
            if (cVar9 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar9 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_470 = *(undefined4 *)(lVar14 + 0x20);
        uStack_46c = *(undefined2 *)(lVar14 + 0x24);
        cVar9 = func_0x(&uStack_470);
        if (cVar9 == '\0') goto LAB_;
        func_0x(lVar14,&uStack_4a0);
      }
      *ppbVar18 = pbVar1;
      *(undefined4 *)(ppbVar18 + 0xc) = (undefined4)uStack_4a0;
      *(int *)((longlong)ppbVar18 + 100) = (int)((ulonglong)uStack_4a0 >> 0x20);
      *(undefined2 *)(ppbVar18 + 0xd) = uStack_498;
      *(undefined4 *)((longlong)ppbVar18 + 0x6c) = *(undefined4 *)(lVar14 + 0x20);
      *(undefined2 *)(ppbVar18 + 0xe) = *(undefined2 *)(lVar14 + 0x24);
      *(undefined2 *)((longlong)ppbVar18 + 0x72) = 0;
      uVar3 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x117a4b0);
      uStack_4d4 = CONCAT44(uStack_4d4._4_4_,uVar3);
      uVar6 = uStack_4d4;
      uVar20 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x117a4b4);
      *(undefined2 *)(ppbVar18 + 2) = 0xffff;
      ppbVar18[3] = (byte *)0x0;
      *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar18 + 0x2e) = 0;
      ppbVar18[7] = (byte *)0x0;
      ppbVar18[4] = (byte *)0x0;
      ppbVar18[9] = (byte *)0x0;
      ppbVar18[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar18 + 0xb) = 0;
      if ((**ppbVar18 & 2) != 0) {
        pbVar1 = pbVar1 + uVar20;
        if ((*pbVar1 & 1) == 0) {
          *(undefined2 *)(ppbVar18 + 2) = 0;
          ppbVar18[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar18 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100f1d */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x102f60) - 0x13bf980
                    ))();
          return;
        }
        *(undefined2 *)(ppbVar18 + 2) = 1;
        ppbVar18[3] = pbVar1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x102f40) * 4
                               + 0x102f30) - 0x13bf980);
                    /* WARNING: Could not emulate address calculation at 0x00100d81 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      if ((**ppbVar18 & 4) != 0) {
        uStack_4d4._2_2_ = (short)((uint)uVar3 >> 0x10);
        if (uStack_4d4._2_2_ != 0) {
          uVar20 = (ulonglong)*(ushort *)(lVar14 + 0x61 + (longlong)uStack_4d4._2_2_ * 2);
        }
        psVar17 = (short *)(pbVar1 + uVar20);
        ppbVar18[9] = (byte *)psVar17;
        sVar2 = *psVar17;
        ppbVar18[10] = (byte *)(psVar17 + 1);
        *(short *)(ppbVar18 + 0xb) = (sVar2 + 1) * 2;
      }
      uStack_4d4 = uVar6;
      if (ppbVar18[1] != (byte *)0x0) {
        func_0x(ppbVar18[1],ppbVar18);
      }
LAB_:
      pbStack_150 = (byte *)((ulonglong)*(ushort *)(lVar14 + 0x1ffc) + lVar14);
      if ((*pbStack_150 & 1) == 0) {
        sStack_158 = 0;
        uStack_154 = 0;
        uStack_132 = 0;
        uStack_130 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101202 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_150 & 0xe) * 4 + 0x102fd0) -
                  0x13bf980))(0x10f9ea8);
        return;
      }
      sStack_158 = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_150 & 0x1c) + 0x102fb0)
                              * 4 + 0x102fa0) - 0x13bf980);
                    /* WARNING: Could not emulate address calculation at 0x00101037 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    if ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) == *(longlong *)(lVar15 + 0x2120)) ||
       (cVar9 = func_0x(lVar15), cVar9 != '\0')) goto LAB_;
    if (lVar14 == 0) {
      lVar14 = func_0x();
    }
    lVar19 = *plStack_4f8;
    if (*(short *)(lVar19 + 0x24) == 0) {
LAB_:
      uStack_468 = *(undefined8 *)(lVar19 + 0x28);
      uStack_460 = *(undefined2 *)(lVar19 + 0x30);
    }
    else {
      cVar9 = *(char *)(lVar19 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(lVar19 + 0x18) != 99) {
LAB_:
          if (cVar9 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar9 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar19 + 0x18) != 99) goto LAB_;
      }
      uStack_480 = *(undefined4 *)(lVar19 + 0x20);
      uStack_47c = *(undefined2 *)(lVar19 + 0x24);
      cVar9 = func_0x(&uStack_480);
      if (cVar9 == '\0') goto LAB_;
      func_0x(lVar19,&uStack_468);
    }
    plVar5 = plStack_4f8;
    if (plStack_4f8 != (longlong *)0x0) {
      iVar10 = (int)(short)uStack_4ec;
      if (((*(ushort *)((longlong)plStack_4f8 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_4f8 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_4f8 + 100) & 8) != 0) &&
              (lVar19 = plStack_4f8[0x12], lVar19 != 0)) && (*(longlong *)(lVar19 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar19 + 0x758),plStack_4f8,iVar10);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
            ((2 < iVar10 &&
             (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0))))))
           && (iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_420), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar5 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar5,0,iVar10);
        }
        uStack_4ec = uStack_4ec & 0xffff0000;
        plStack_4f8 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_4f8);
      }
    }
    uStack_448 = uStack_468;
    uStack_440 = uStack_460;
    uStack_508 = 0;
    func_0x(*(undefined8 *)(lVar15 + 0x728),&uStack_448,4);
  } while( true );
}

