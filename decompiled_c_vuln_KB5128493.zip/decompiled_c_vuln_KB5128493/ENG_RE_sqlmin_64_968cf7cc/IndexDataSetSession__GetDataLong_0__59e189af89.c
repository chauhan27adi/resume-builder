
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,undefined8 param_4)

{
  undefined *puVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lStackX_8;
  undefined4 auStackX_10 [2];
  undefined8 uStackX_18;
  undefined4 auStackX_20 [2];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar3 = func_0x();
  lVar3 = -lVar3;
  puVar1 = &stack0xfffffffffffffff0 + lVar3;
  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar3) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00001fd0 + lVar3) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined8 *)((longlong)auStackX_20 + lVar3 + -0x20) = 0;
  *(undefined8 *)((longlong)&lStackX_8 + lVar3) = 0;
  *(undefined4 *)((longlong)auStackX_10 + lVar3) = 0;
  *(undefined8 *)((longlong)&uStackX_18 + lVar3) = 0;
  *(undefined4 *)((longlong)auStackX_20 + lVar3) = 0;
  lVar2 = *param_3;
  if ((*(byte *)(lVar2 + 0x38) & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)(param_1 + 0x3a0) = 0;
  *(undefined8 *)(param_1 + 0x3a8) = param_2;
  if ((*(ushort *)(lVar2 + 0x38) & 0x1000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar3) =
       *(undefined8 *)(*(longlong *)(param_1 + 0x108) + 0x130);
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar3) = param_4;
  *(undefined8 *)((longlong)&uStack_48 + lVar3) = 0x1000ba;
  func_0x(param_1 + 0x3b8,param_3,0,puVar1);
  if (*(short *)(lVar2 + 0x3a) != 0) {
    if ((*(byte *)(lVar2 + 0x38) & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(longlong *)(*(longlong *)(param_1 + 0x108) + 0x130) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (*(longlong *)((longlong)&lStackX_8 + lVar3) == 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar3) = 0x1000fe;
    func_0x(*(ulonglong *)(&stack0x00001fd0 + lVar3) ^ (ulonglong)puVar1);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

