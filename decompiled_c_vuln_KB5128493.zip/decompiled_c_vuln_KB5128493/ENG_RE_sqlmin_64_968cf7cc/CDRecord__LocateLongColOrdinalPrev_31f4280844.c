
int FUN_(longlong param_1,ushort param_2)

{
  longlong lVar1;
  byte bVar2;
  uint uVar3;
  uint uVar4;
  ushort uVar5;
  byte *pbVar6;
  ulonglong uVar7;
  uint uVar8;
  uint uVar9;
  ulonglong uVar10;
  uint uVar12;
  ulonglong uVar13;
  short sVar14;
  longlong lVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  int iVar19;
  ulonglong uVar11;
  
  uVar7 = 0;
  uVar17 = 0;
  uVar18 = 0;
  if (param_2 < 0x1f) {
    uVar5 = 1;
    lVar15 = (ulonglong)*(ushort *)(param_1 + 0x16) + *(longlong *)(param_1 + 6);
    uVar16 = uVar18;
  }
  else {
    uVar8 = (int)(param_2 - 1) / 0x1e;
    pbVar6 = (byte *)((ulonglong)*(ushort *)(param_1 + 0x1c) +
                     (ulonglong)*(ushort *)(param_1 + 0x20) + *(longlong *)(param_1 + 6));
    sVar14 = (short)uVar8;
    uVar16 = 0;
    if (sVar14 != 0) {
      uVar10 = (ulonglong)(uVar8 & 0xffff);
      uVar11 = uVar7;
      do {
        bVar2 = *pbVar6;
        pbVar6 = pbVar6 + 1;
        uVar16 = (int)uVar11 + (uint)bVar2;
        uVar11 = (ulonglong)uVar16;
        uVar10 = uVar10 - 1;
      } while (uVar10 != 0);
    }
    uVar5 = sVar14 * 0x1e + 1;
    lVar15 = (ulonglong)*(ushort *)(param_1 + 0x16) +
             (ulonglong)(uVar5 >> 1) + *(longlong *)(param_1 + 6);
  }
  param_2 = param_2 - uVar5;
  uVar8 = 0;
  uVar12 = (uint)(param_2 >> 1);
  if (uVar12 < 2) {
    uVar9 = uVar8;
    uVar3 = 0;
    if (param_2 >> 1 == 0) goto LAB_;
  }
  else {
    uVar4 = (uVar12 - 2 >> 1) + 1;
    uVar13 = (ulonglong)uVar4;
    uVar11 = uVar7;
    uVar10 = uVar7;
    do {
      uVar18 = (int)uVar10 + (uint)*(byte *)((ulonglong)*(byte *)(lVar15 + uVar7) + 0x809170);
      uVar10 = (ulonglong)uVar18;
      lVar1 = uVar7 + 1;
      uVar7 = uVar7 + 2;
      uVar9 = (int)uVar11 + (uint)*(byte *)((ulonglong)*(byte *)(lVar1 + lVar15) + 0x809170);
      uVar11 = (ulonglong)uVar9;
      uVar13 = uVar13 - 1;
    } while (uVar13 != 0);
    uVar17 = uVar9;
    uVar3 = uVar18;
    if (uVar12 <= uVar4 * 2) goto LAB_;
  }
  uVar18 = uVar3;
  uVar8 = (uint)*(byte *)((ulonglong)*(byte *)(lVar15 + uVar7) + 0x809170);
  uVar9 = uVar17;
LAB_:
  iVar19 = uVar8 + uVar9 + uVar18;
  if ((param_2 & 1) == 0) {
    return iVar19 + uVar16;
  }
  return (uint)*(byte *)((ulonglong)(*(byte *)(lVar15 + (int)(param_2 - 1) / 2) & 0xf) + 0x809170) +
         iVar19 + uVar16;
}

