
ulonglong FUN_(longlong param_1)

{
  uint uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uStackX_8;
  
  switch(*(char *)(param_1 + 0x16)) {
  case '\x01':
    return 0x4000000001;
  case '\x02':
  case '\x03':
  case '\x06':
    uVar1 = 0x20000003;
    if (*(short *)(param_1 + 0x3e) == 0) {
      uVar1 = 0x20000001;
    }
    return (ulonglong)uVar1;
  case '\x04':
    return 0x20004003;
  case '\x05':
  case '{':
    return 0x4003;
  case '\a':
    return 0x20000005;
  default:
    return 0;
  case '\n':
    return 0x20001;
  case '\v':
  case '\f':
    return 0x400001;
  case '\r':
  case '\x12':
  case '\x13':
  case '}':
  case '~':
    return 1;
  case '\x10':
  case '\x11':
    break;
  case '\x14':
    return 0x2000000001;
  case '\x15':
    return 0x8000000001;
  case '\x16':
    return 0x20000001;
  case -0x80:
    return 0x100;
  case -0x7f:
  case -0x7e:
    return 0x200;
  case -0x7d:
    return 0x400;
  case -0x7c:
    return 0x800;
  case -0x7a:
    return 0x200400000000;
  case -0x79:
  case -0x72:
  case -0x70:
  case -0x6f:
  case -0x6e:
  case -0xd:
    return 0x400000000;
  case -0x77:
    return 0x1000;
  case -0x76:
  case -0x75:
    return 0x8000000;
  case -0x74:
    return 0x10000000000;
  case -0x73:
    return 0x30000000;
  case -0x71:
    return 0x2000000;
  case -0x6c:
    return 8;
  case -0x6b:
    return 0x80000000000;
  case -0x6a:
    return 0x10;
  case -0x68:
    return 0x20;
  case -0x67:
    return 0x40;
  case -0x66:
    return 0x80;
  case -0x52:
    return 0x800000;
  case -0x50:
    return 0x40000000;
  case -0x38:
    return 0x10000;
  case -0x35:
    return 0x200000;
  case -0x34:
    return 0x100000000;
  case -0x2a:
    return 0x80000000;
  case -0x29:
    return 0x200000000;
  case -0x28:
    return 0x1000000000;
  case -0x23:
    return 0x40000000000;
  case -0x1a:
  case -0x19:
  case -0x18:
  case -0x17:
  case -0x16:
    return 0x400000000000;
  case -0x10:
    (*pcRam000000000094a4b0)(1,0xe562a4,0xe533b8,0xbb9,0);
    return uStackX_8;
  }
  uVar2 = 3;
  if (*(short *)(param_1 + 0x3e) == 0) {
    uVar2 = 1;
  }
  uVar3 = uVar2 | 0x200000000000;
  if (*(char *)(param_1 + 0x16) != '\x10') {
    uVar3 = uVar2;
  }
  return uVar3;
}

