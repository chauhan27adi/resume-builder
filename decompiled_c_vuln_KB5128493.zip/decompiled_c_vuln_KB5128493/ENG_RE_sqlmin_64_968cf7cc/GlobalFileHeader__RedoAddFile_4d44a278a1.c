
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,char param_3)

{
  undefined2 uVar1;
  undefined4 *puVar2;
  longlong *plVar3;
  undefined8 uVar4;
  code *pcVar5;
  uint **ppuVar6;
  char cVar7;
  undefined2 uVar8;
  ushort uVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  int iVar13;
  longlong lVar14;
  ulonglong *puVar15;
  undefined4 *puVar16;
  longlong lVar17;
  longlong *plVar18;
  undefined4 *puVar19;
  longlong lVar20;
  uint *puVar21;
  byte bVar22;
  byte bVar23;
  ulonglong uVar24;
  ushort uVar25;
  uint uVar26;
  undefined8 unaff_RBX;
  ushort *puVar27;
  uint uVar28;
  undefined8 *puVar29;
  ulonglong uVar30;
  short sVar31;
  undefined4 uVar32;
  byte *pbVar33;
  longlong unaff_GS_OFFSET;
  int iStackX_8;
  ushort uStackX_c;
  ushort uStackX_e;
  undefined8 uStackX_10;
  longlong *plStackX_18;
  undefined auStackX_20 [4];
  uint uStackX_24;
  uint uStack_1588;
  uint uStack_1584;
  undefined4 uStack_1580;
  undefined4 uStack_157c;
  undefined4 auStack_1578 [2];
  undefined8 uStack_1570;
  ushort uStack_1568;
  undefined8 uStack_1560;
  ushort uStack_1558;
  undefined4 uStack_1550;
  undefined4 uStack_154c;
  undefined auStack_1548 [4];
  undefined4 uStack_1544;
  undefined4 uStack_1540;
  undefined2 uStack_153c;
  undefined4 uStack_1538;
  undefined2 uStack_1534;
  undefined4 uStack_1530;
  undefined2 uStack_152c;
  undefined8 uStack_1528;
  undefined2 uStack_1520;
  undefined8 uStack_1518;
  undefined8 uStack_1510;
  undefined2 uStack_1508;
  undefined8 uStack_1500;
  ushort uStack_14f8;
  undefined auStack_14f0 [4];
  undefined auStack_14ec [4];
  undefined auStack_14e8 [4];
  undefined auStack_14e4 [4];
  uint uStack_14e0;
  undefined8 uStack_14dc;
  undefined8 uStack_14c8;
  undefined auStack_14b8 [8];
  undefined4 uStack_14b0;
  undefined4 uStack_14a8;
  uint **ppuStack_14a0;
  undefined *puStack_1498;
  undefined8 uStack_1490;
  uint *puStack_1488;
  undefined4 uStack_1480;
  undefined4 uStack_147c;
  longlong lStack_1478;
  undefined4 uStack_1470;
  undefined4 uStack_146c;
  longlong lStack_1468;
  undefined4 uStack_1460;
  undefined4 uStack_145c;
  short *psStack_1458;
  int iStack_1450;
  undefined4 uStack_144c;
  short *psStack_1448;
  int iStack_1440;
  undefined4 uStack_143c;
  undefined8 uStack_1438;
  undefined4 uStack_1430;
  undefined4 uStack_142c;
  undefined auStack_1428 [448];
  undefined8 uStack_1268;
  undefined8 uStack_1260;
  uint uStack_1258;
  undefined2 uStack_1254;
  undefined4 uStack_1252;
  undefined uStack_124e;
  undefined uStack_124d;
  undefined8 uStack_1218;
  undefined2 uStack_1210;
  undefined8 uStack_1208;
  undefined2 uStack_1200;
  undefined8 uStack_11f8;
  undefined2 uStack_11f0;
  undefined8 uStack_11e8;
  undefined2 uStack_11e0;
  undefined8 uStack_11d8;
  undefined2 uStack_11d0;
  undefined8 uStack_11c8;
  undefined2 uStack_11c0;
  undefined8 uStack_11b8;
  undefined2 uStack_11b0;
  undefined8 uStack_11a8;
  undefined2 uStack_11a0;
  undefined2 uStack_119e;
  undefined4 uStack_119c;
  undefined4 uStack_1198;
  undefined4 uStack_1194;
  undefined4 uStack_1190;
  undefined4 uStack_1188;
  undefined4 uStack_1184;
  undefined4 uStack_1180;
  undefined4 uStack_117c;
  undefined4 uStack_1178;
  undefined4 uStack_1174;
  undefined4 uStack_1170;
  undefined4 uStack_116c;
  undefined4 uStack_1168;
  undefined4 uStack_1164;
  undefined4 uStack_1160;
  undefined4 uStack_115c;
  short sStack_1158;
  ushort uStack_1156;
  uint uStack_1154;
  undefined4 *puStack_1150;
  undefined8 uStack_1148;
  uint uStack_1140;
  ushort uStack_113c;
  byte *pbStack_113a;
  undefined2 uStack_1132;
  undefined2 uStack_1130;
  undefined2 uStack_112e;
  ushort uStack_112c;
  undefined2 uStack_112a;
  undefined2 auStack_918 [2];
  undefined4 uStack_914;
  undefined8 uStack_910;
  undefined8 uStack_908;
  undefined8 uStack_8fa;
  undefined8 uStack_8f0;
  short asStack_d8 [24];
  short asStack_a8 [24];
  undefined auStack_78 [48];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  uStack_14c8 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000015e8 + lVar14) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar14);
  puVar19 = (undefined4 *)0x0;
  *(undefined8 *)((longlong)&plStackX_18 + lVar14) = 0;
  auStackX_20[lVar14] = 0;
  uVar28 = *(uint *)((longlong)&uStackX_24 + lVar14);
  *(uint *)((longlong)&uStackX_24 + lVar14) = uVar28 & 0xffff0000;
  *(uint *)((longlong)&uStackX_24 + lVar14) = uVar28 & 0xff000000;
  *(undefined4 *)((longlong)&uStackX_24 + lVar14) = 0;
  sStack_1158 = -1;
  puStack_1150 = (undefined4 *)0x0;
  uStack_1154 = 0;
  pbStack_113a = (byte *)0x0;
  uStack_1130 = 0;
  uStack_112e = 0;
  uStack_112c = 0;
  uStack_112a = 0;
  uStack_1148 = (longlong *)0x0;
  uStack_1188 = *(undefined4 *)(param_1 + 0x88);
  uStack_1184 = *(undefined4 *)(param_1 + 0x8c);
  uStack_1180 = *(undefined4 *)(param_1 + 0x90);
  uStack_117c = *(undefined4 *)(param_1 + 0x94);
  uStack_154c = *(undefined4 *)(param_1 + 0x360);
  puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
  *puVar27 = *puVar27 & 0xffe0;
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1000cf;
  func_0x(&sStack_1158);
  *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffff;
  *(undefined2 *)((longlong)&uStackX_c + lVar14) = 1;
  puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
  *puVar27 = *puVar27 & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100104;
  func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,&uStack_1188,0x10);
  if (sStack_1158 == 0) {
    uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
    uVar24 = (ulonglong)(uVar28 >> 3);
    *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
         *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
         ~(byte)(1 << (uVar28 & 7));
  }
  else {
    uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
    if (uVar9 <= uStack_1156) {
      pbVar33 = (byte *)((longlong)puStack_1150 +
                        (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
      bVar23 = *pbVar33;
      bVar22 = bVar23 >> 4;
      if ((uVar9 & 1) != 0) {
        bVar22 = bVar23 & 0xf;
      }
      if (bVar22 == 0) {
        if ((uVar9 & 1) == 0) {
          bVar23 = bVar23 & 0xf | 0x10;
        }
        else {
          bVar23 = bVar23 & 0xf1 | 1;
        }
        *pbVar33 = bVar23;
      }
    }
  }
  if (param_3 == '\0') {
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffd1;
    uVar8 = 0x2f;
    uVar32 = 4;
    puVar29 = (undefined8 *)&uStack_154c;
  }
  else {
    uStack_1168 = *(undefined4 *)(param_1 + 0xe4);
    uStack_1164 = *(undefined4 *)(param_1 + 0xe8);
    uStack_1160 = *(undefined4 *)(param_1 + 0xec);
    uStack_115c = *(undefined4 *)(param_1 + 0xf0);
    uStack_1178 = *(undefined4 *)(param_1 + 0xd4);
    uStack_1174 = *(undefined4 *)(param_1 + 0xd8);
    uStack_1170 = *(undefined4 *)(param_1 + 0xdc);
    uStack_116c = *(undefined4 *)(param_1 + 0xe0);
    uStack_1550 = *(undefined4 *)(param_1 + 0x1fc);
    uStack_11e8 = *(undefined8 *)(param_1 + 0x200);
    uStack_11e0 = *(undefined2 *)(param_1 + 0x208);
    uStack_11d8 = *(undefined8 *)(param_1 + 0x10c);
    uStack_11d0 = *(undefined2 *)(param_1 + 0x114);
    uStack_11c8 = *(undefined8 *)(param_1 + 0x118);
    uStack_11c0 = *(undefined2 *)(param_1 + 0x120);
    uStack_11b8 = *(undefined8 *)(param_1 + 0x174);
    uStack_11b0 = *(undefined2 *)(param_1 + 0x17c);
    uStack_11a8 = *(undefined8 *)(param_1 + 0x1de);
    uStack_11a0 = *(undefined2 *)(param_1 + 0x1e6);
    uStack_119e = *(undefined2 *)(param_1 + 0x1e8);
    uStack_119c = *(undefined4 *)(param_1 + 0x1ea);
    uStack_1198 = *(undefined4 *)(param_1 + 0x1ee);
    uStack_1194 = *(undefined4 *)(param_1 + 0x1f2);
    uStack_1190 = *(undefined4 *)(param_1 + 0x1f6);
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffe3;
    *(undefined2 *)((longlong)&uStackX_c + lVar14) = 0x1d;
    puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
    *puVar27 = *puVar27 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1002d6;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,&uStack_1178,0x10);
    if (sStack_1158 == 0) {
      uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
      uVar24 = (ulonglong)(uVar28 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar28 & 7));
    }
    else {
      uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
      if (uVar9 <= uStack_1156) {
        pbVar33 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
        bVar23 = *pbVar33;
        bVar22 = bVar23 >> 4;
        if ((uVar9 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar9 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar33 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffe7;
    *(undefined2 *)((longlong)&uStackX_c + lVar14) = 0x19;
    puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
    *puVar27 = *puVar27 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1003b1;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,&uStack_1550,4);
    if (sStack_1158 == 0) {
      uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
      uVar24 = (ulonglong)(uVar28 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar28 & 7));
    }
    else {
      uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
      if (uVar9 <= uStack_1156) {
        pbVar33 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
        bVar23 = *pbVar33;
        bVar22 = bVar23 >> 4;
        if ((uVar9 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar9 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar33 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffe6;
    *(undefined2 *)((longlong)&uStackX_c + lVar14) = 0x1a;
    puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
    *puVar27 = *puVar27 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10048f;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,&uStack_11e8,10);
    if (sStack_1158 == 0) {
      uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
      uVar24 = (ulonglong)(uVar28 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar28 & 7));
    }
    else {
      uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
      if (uVar9 <= uStack_1156) {
        pbVar33 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
        bVar23 = *pbVar33;
        bVar22 = bVar23 >> 4;
        if ((uVar9 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar9 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar33 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffed;
    *(undefined2 *)((longlong)&uStackX_c + lVar14) = 0x13;
    puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
    *puVar27 = *puVar27 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10056d;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,&uStack_11d8,10);
    if (sStack_1158 == 0) {
      uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
      uVar24 = (ulonglong)(uVar28 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar28 & 7));
    }
    else {
      uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
      if (uVar9 <= uStack_1156) {
        pbVar33 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
        bVar23 = *pbVar33;
        bVar22 = bVar23 >> 4;
        if ((uVar9 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar9 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar33 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffef;
    *(undefined2 *)((longlong)&uStackX_c + lVar14) = 0x11;
    puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
    *puVar27 = *puVar27 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10064b;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,&uStack_11c8,10);
    if (sStack_1158 == 0) {
      uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
      uVar24 = (ulonglong)(uVar28 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar28 & 7));
    }
    else {
      uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
      if (uVar9 <= uStack_1156) {
        pbVar33 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
        bVar23 = *pbVar33;
        bVar22 = bVar23 >> 4;
        if ((uVar9 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar9 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar33 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffe9;
    *(undefined2 *)((longlong)&uStackX_c + lVar14) = 0x17;
    puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
    *puVar27 = *puVar27 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100729;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,&uStack_11b8,10);
    if (sStack_1158 == 0) {
      uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
      uVar24 = (ulonglong)(uVar28 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar28 & 7));
    }
    else {
      uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
      if (uVar9 <= uStack_1156) {
        pbVar33 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
        bVar23 = *pbVar33;
        bVar22 = bVar23 >> 4;
        if ((uVar9 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar9 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar33 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffee;
    *(undefined2 *)((longlong)&uStackX_c + lVar14) = 0x12;
    puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
    *puVar27 = *puVar27 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100805;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,param_1 + 0x1a6,0x1c);
    if (sStack_1158 == 0) {
      uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
      uVar24 = (ulonglong)(uVar28 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar28 & 7));
    }
    else {
      uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
      if (uVar9 <= uStack_1156) {
        pbVar33 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
        bVar23 = *pbVar33;
        bVar22 = bVar23 >> 4;
        if ((uVar9 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar9 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar33 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffdc;
    *(undefined2 *)((longlong)&uStackX_c + lVar14) = 0x24;
    puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
    *puVar27 = *puVar27 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1008e3;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,&uStack_1168,0x10);
    if (sStack_1158 == 0) {
      uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
      uVar24 = (ulonglong)(uVar28 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar28 & 7));
    }
    else {
      uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
      if (uVar9 <= uStack_1156) {
        pbVar33 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
        bVar23 = *pbVar33;
        bVar22 = bVar23 >> 4;
        if ((uVar9 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar9 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar33 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffd4;
    uVar8 = 0x2c;
    uVar32 = 0x1c;
    puVar29 = &uStack_11a8;
  }
  *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
  puVar27 = (ushort *)((longlong)&uStackX_c + lVar14 + 2);
  *puVar27 = *puVar27 & 0xffe0;
  *(undefined2 *)((longlong)&uStackX_c + lVar14) = uVar8;
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100a4c;
  func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar14,puVar29,uVar32);
  if (sStack_1158 == 0) {
    uVar28 = *(ushort *)((longlong)&uStackX_c + lVar14) - 1;
    uVar24 = (ulonglong)(uVar28 >> 3);
    *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
         *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
         ~(byte)(1 << (uVar28 & 7));
  }
  else {
    uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14);
    if (uVar9 <= uStack_1156) {
      pbVar33 = (byte *)((longlong)puStack_1150 +
                        (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar9 - 1) / 2));
      bVar23 = *pbVar33;
      bVar22 = bVar23 >> 4;
      if ((uVar9 & 1) != 0) {
        bVar22 = bVar23 & 0xf;
      }
      if (bVar22 == 0) {
        if ((uVar9 & 1) == 0) {
          bVar23 = bVar23 & 0xf | 0x10;
        }
        else {
          bVar23 = bVar23 & 0xf1 | 1;
        }
        *pbVar33 = bVar23;
      }
    }
  }
  if ((*(uint *)(param_1 + 100) >> 8 & 1) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100ab8;
    func_0x(param_1,&sStack_1158,0);
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10218c;
    func_0x((longlong)&plStackX_18 + lVar14);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10219b;
    func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar14));
    return;
  }
  *(undefined4 *)((longlong)&iStackX_8 + lVar14) = 0xffffffd2;
  *(undefined2 *)((longlong)&uStackX_c + lVar14) = 0x2e;
  uVar9 = *(ushort *)((longlong)&uStackX_c + lVar14 + 2) & 0xffe0;
  *(ushort *)((longlong)&uStackX_c + lVar14 + 2) = uVar9;
  *(undefined8 *)((longlong)&uStackX_c + lVar14 + 4) = 0;
  iVar13 = 0;
  if (sStack_1158 == 0) {
    iVar10 = iVar13;
    if ((*(byte *)puStack_1150 & 0x10) == 0) {
      if ((1 << (*(byte *)puStack_1150 & 0xe) & 0x1105U) != 0) {
        bVar23 = 0xff;
        goto LAB_;
      }
LAB_:
      uVar28 = uStack_1140;
      if (uStack_1154 == 0) {
        uStack_1156 = 0;
        uVar24 = (ulonglong)uStack_1148 & 0xffffffff;
        uVar28 = (uint)uStack_1148;
        if ((*(byte *)puStack_1150 & 0x10) != 0) {
          uVar28 = (uint)uStack_1148 + 2 + (*(ushort *)(uVar24 + (longlong)puStack_1150) + 7 >> 3);
          uVar24 = (ulonglong)uVar28;
        }
        uStack_1148 = (longlong *)CONCAT44(uVar28,(uint)uStack_1148);
        uStack_1140 = (uint)uVar24;
        if ((*(byte *)puStack_1150 & 0x20) == 0) {
          uStack_113c = 0;
          uVar30 = uVar24;
          uStack_1154 = uStack_1140;
        }
        else {
          puVar27 = (ushort *)(uVar24 + (longlong)puStack_1150);
          uStack_113c = *puVar27;
          if (uStack_113c == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar17 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar17 != 0)) &&
               ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100ca0;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100cc3;
                (*_DAT_)(1,0x1383d28,0x14a39f8,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100cd4;
            func_0x(puStack_1150,3);
          }
          uStack_1140 = uStack_1148._4_4_ + (uStack_113c + 1) * 2;
          if (0x1f9e < uStack_1140) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar17 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar17 != 0 &&
                ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                 (*(char *)(lVar17 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d77;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d9a;
                (*_DAT_)(1,0x1383d28,0x14a39f8,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100dab;
            func_0x(puStack_1150,4);
          }
          uStack_1154 = puVar27[uStack_113c] & 0x7fff;
          if (uStack_1154 < uStack_1140) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar17 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar17 != 0)) &&
               ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e4c;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e6f;
                (*_DAT_)(1,0x1383d28,0x14a39f8,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e80;
            func_0x(puStack_1150,4);
          }
          uVar30 = (ulonglong)uStack_1140;
          uVar24 = (ulonglong)uStack_1154;
          do {
            if (-1 < (short)puVar27[(ulonglong)(uStack_113c - 1) + 1]) break;
            uVar11 = (uint)uVar30;
            if (uStack_113c != 1) {
              uVar11 = *(ushort *)
                        ((longlong)puStack_1150 +
                        (ulonglong)uStack_113c * 2 + (((ulonglong)uStack_1148 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar11 < (uint)uVar30) ||
               ((*(ushort *)
                  ((longlong)puStack_1150 +
                  (ulonglong)uStack_113c * 2 + ((ulonglong)uStack_1148 >> 0x20)) & 0x7fff) < uVar11)
               ) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100ef5;
              func_0x(puStack_1150,7);
              uVar30 = (ulonglong)uStack_1140;
              uVar24 = (ulonglong)uStack_1154;
            }
            uVar28 = (uint)uVar30;
            if ((uVar11 < uVar28) || ((uint)uVar24 < uVar11)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar11 + (longlong)puStack_1150) == 5) {
              uStack_1156 = uStack_1156 | 2;
              uStack_113c = uStack_113c - 1;
              uStack_112e = (undefined2)uVar11;
              uVar9 = *(ushort *)((longlong)puStack_1150 + (ulonglong)(uVar11 & 0xffff) + 2);
              if ((uVar9 >> 0xe & 1) == 0) {
                uStack_112c = uStack_112c & 0xc7ff;
              }
              else {
                uStack_112c = uStack_112c ^ (uStack_112c ^ uVar9) & 0x3800;
              }
              uStack_112c = (uStack_112c ^
                            *(ushort *)((longlong)puStack_1150 + (ulonglong)(uVar11 & 0xffff) + 2))
                            & 0x7ff ^ uStack_112c;
              break;
            }
            if (*(ushort *)((ulonglong)uVar11 + (longlong)puStack_1150) < 0x400) break;
            uStack_1156 = uStack_1156 | 1;
            uStack_113c = uStack_113c - 1;
          } while (uStack_113c != 0);
        }
        uVar28 = (uint)uVar30;
        if ((*(byte *)puStack_1150 & 0x40) == 0) {
          uStack_1132 = 0;
          uStack_1130 = 0;
        }
        else {
          uStack_1132 = (undefined2)uVar24;
          uStack_1130 = (undefined2)(uVar24 >> 0x10);
          uStack_1154 = (int)uVar24 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101012;
          puVar15 = (ulonglong *)func_0x(&uStack_1156);
          uVar25 = (ushort)(*puVar15 >> 0x30);
          uVar9 = uVar25;
          if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
            uVar9 = uVar25 & 0xdfff;
            if ((uVar25 >> 0xe & 1) != 0) {
              uVar9 = uVar25 | 0x2000;
            }
          }
          iVar10 = iVar13;
          if (uVar9 == 0xfffc) {
            iVar10 = (int)((*puVar15 >> 0x20 & 0xffff) >> 5);
          }
          uStack_1154 = uStack_1154 + iVar10;
          uVar24 = (ulonglong)uStack_1154;
          uVar28 = uStack_1140;
        }
        uVar11 = (uint)uVar24;
        if ((pbStack_113a != (byte *)0x0) &&
           (pbStack_113a < (byte *)(uVar24 + (longlong)puStack_1150))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar17 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar17 != 0 && (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0))
              && (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10111c;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10113f;
              (*_DAT_)(1,0x1383d28,0x14a39f8,0x877);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10114e;
          func_0x(puStack_1150,0x12);
          uVar11 = uStack_1154;
          uVar28 = uStack_1140;
        }
        if (0x3f3b < uVar11 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1011e3;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101206;
              (*_DAT_)(1,0x1383d28,0x14a39f8,0x87c);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101217;
          func_0x(puStack_1150,5);
          uVar28 = uStack_1140;
        }
      }
LAB_:
      sVar31 = -*(short *)((longlong)&iStackX_8 + lVar14);
      if ((*(byte *)((longlong)&uStackX_c + lVar14 + 2) & 0x10) != 0) {
        if ((*(byte *)puStack_1150 & 0x10) == 0) {
          if ((1 << (*(byte *)puStack_1150 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar2 = *(undefined4 **)((longlong)&uStackX_c + lVar14 + 4);
            puVar16 = puVar2 + 1;
            *(undefined4 *)(&stack0x00000030 + lVar14) = *puVar2;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_1148 <= *(int *)((longlong)&iStackX_8 + lVar14)) ||
                (*(ushort *)((longlong)puStack_1150 + ((ulonglong)uStack_1148 & 0xffffffff)) <
                 *(ushort *)((longlong)&uStackX_c + lVar14))) goto LAB_;
      }
      if ((uint)uStack_113c < (uint)(int)sVar31) {
        *(undefined4 *)(&stack0x00000030 + lVar14) = 0;
        puVar16 = puStack_1150;
      }
      else {
        uVar11 = uVar28;
        if (sVar31 != 1) {
          uVar28 = *(ushort *)
                    ((longlong)puStack_1150 +
                    (longlong)sVar31 * 2 + (((ulonglong)uStack_1148 >> 0x20) - 2)) & 0x7fff;
          uVar11 = uStack_1140;
        }
        uVar26 = *(ushort *)
                  ((longlong)puStack_1150 + (longlong)sVar31 * 2 + ((ulonglong)uStack_1148 >> 0x20))
                 & 0x7fff;
        if ((uVar28 < uVar11) || (uVar26 < uVar28)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1012f6;
          func_0x(puStack_1150,7);
        }
        *(uint *)(&stack0x00000030 + lVar14) = uVar26 - uVar28;
        puVar16 = (undefined4 *)((ulonglong)uVar28 + (longlong)puStack_1150);
      }
    }
    else {
      if ((int)(uint)uStack_1148 < -0x2d) {
        bVar23 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_1148 & 0xffffffff) + (longlong)puStack_1150) < 0x2e) {
        bVar23 = 0xff;
      }
      else {
        bVar23 = *(byte *)(((ulonglong)uStack_1148 & 0xffffffff) + 7 + (longlong)puStack_1150) >> 5;
        iVar10 = 1;
      }
LAB_:
      if ((bVar23 & 1) == 0) {
        if ((iVar10 != 0) || ((*(byte *)((longlong)&uStackX_c + lVar14 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)(&stack0x00000030 + lVar14) =
             **(undefined4 **)((longlong)&uStackX_c + lVar14 + 4);
        puVar16 = (undefined4 *)0x4;
      }
      else {
        *(undefined4 *)(&stack0x00000030 + lVar14) = 0;
        puVar16 = puVar19;
      }
    }
  }
  else {
    uStack_1588 = 0;
    *(uint **)(&stack0xffffffffffffffe8 + lVar14) = &uStack_1588;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10134a;
    puVar16 = (undefined4 *)
              func_0x(&uStack_1156,(longlong)&iStackX_8 + lVar14,uVar9,
                              &stack0x00000030 + lVar14);
    plVar18 = uStack_1148;
    if ((((sStack_1158 != 0) && (uStack_1148 != (longlong *)0x0)) && (*uStack_1148 != 0)) &&
       (((*(byte *)((longlong)&uStackX_c + lVar14 + 2) & 8) == 0 && ((uStack_1588 & 1) == 0)))) {
      if ((puVar16 == (undefined4 *)0x0) || (puVar16 == (undefined4 *)0x1108764)) {
        *(undefined4 *)(&stack0x00000030 + lVar14) = 0;
        puVar16 = (undefined4 *)0x0;
      }
      else {
        *(uint *)(auStackX_20 + lVar14 + -0x20) = uStack_1588;
        *(undefined **)(&stack0xfffffffffffffff8 + lVar14) = &stack0x00000030 + lVar14;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar14) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1013b6;
        puVar16 = (undefined4 *)
                  func_0x
                            (plVar18,(longlong)&iStackX_8 + lVar14,puVar16,
                             *(undefined4 *)(&stack0x00000030 + lVar14));
      }
    }
  }
LAB_:
  if ((puVar16 != (undefined4 *)0x0) && (*(int *)(&stack0x00000030 + lVar14) == 600)) {
    bVar23 = *(byte *)puVar16;
    uVar8 = *(undefined2 *)(param_1 + 0x20);
    uVar1 = *(undefined2 *)(param_1 + 0x60);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1013f1;
    func_0x(0x13b5a40,uVar1,uVar8,bVar23 & 0x1f);
  }
  uVar8 = *(undefined2 *)(param_1 + 0x20);
  *(undefined4 *)(&stack0x00000034 + lVar14) = 0;
  *(undefined2 *)(&stack0x00000038 + lVar14) = uVar8;
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101408;
  lVar17 = func_0x(param_1);
  puVar16 = puVar19;
  if ((lVar17 != 0) && (*(short *)(param_1 + 0x62) == 0)) {
    puVar16 = *(undefined4 **)(lVar17 + 0x1210);
  }
  uStack_14dc = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar17 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar17 != 0) && (lVar17 = **(longlong **)(lVar17 + 0x38), lVar17 != 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101477;
      iVar10 = (*_DAT_)(lVar17,0x337);
      if (iVar10 != 0) goto LAB_;
    }
    lVar17 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar17 != 0) {
      puVar19 = *(undefined4 **)(lVar17 + 0x60);
    }
  }
LAB_:
  lVar17 = *(longlong *)(puVar16 + 0x1ca);
  do {
    uStack_1584 = 0;
    lVar20 = *(longlong *)((longlong)&plStackX_18 + lVar14);
    if (lVar20 != 0) {
      iVar10 = (int)*(short *)((longlong)&uStackX_24 + lVar14);
      if (((*(ushort *)(lVar20 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
        plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar14);
        if (((byte)*(undefined2 *)(lVar20 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)((longlong)&plStackX_18 + lVar14) + 100) & 8) != 0) &&
              (lVar20 = *(longlong *)(*(longlong *)((longlong)&plStackX_18 + lVar14) + 0x90),
              lVar20 != 0)) && (*(longlong *)(lVar20 + 0x758) != 0)) {
            uVar4 = *(undefined8 *)(lVar20 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101547;
            func_0x(uVar4,*(undefined8 *)((longlong)&plStackX_18 + lVar14),iVar10);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar18 + 100) & 8) != 0)) &&
           ((2 < iVar10 &&
            (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar20 = *plVar18, lVar20 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101588;
          iVar12 = (*_DAT_)(lVar20,0x2000,2,auStack_14f0);
          if (iVar12 != 0) {
            LOCK();
            *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1015aa;
        func_0x(plVar18 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1015c9;
          func_0x(plVar18,0,iVar10);
        }
        *(uint *)((longlong)&uStackX_24 + lVar14) =
             *(uint *)((longlong)&uStackX_24 + lVar14) & 0xffff0000;
        *(undefined8 *)((longlong)&plStackX_18 + lVar14) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1014e2;
        func_0x((longlong)&plStackX_18 + lVar14);
      }
    }
    if (*(longlong *)(puVar16 + 0x1ca) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1015f6;
      func_0x((longlong)&plStackX_18 + lVar14,&stack0x00000034 + lVar14,puVar16);
      lVar20 = *(longlong *)((longlong)&plStackX_18 + lVar14);
      if (lVar20 != 0) {
        iVar10 = (int)*(short *)((longlong)&uStackX_24 + lVar14);
        if (((*(ushort *)(lVar20 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
          plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar14);
          if (((byte)*(undefined2 *)(lVar20 + 0x62) >> 3 & 1) != 0) {
            if (iVar10 == 3) {
              iVar10 = 4;
            }
            else if (iVar10 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)((longlong)&plStackX_18 + lVar14) + 100) & 8) != 0) &&
                (lVar20 = *(longlong *)(*(longlong *)((longlong)&plStackX_18 + lVar14) + 0x90),
                lVar20 != 0)) && (*(longlong *)(lVar20 + 0x758) != 0)) {
              uVar4 = *(undefined8 *)(lVar20 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10168b;
              func_0x(uVar4,*(undefined8 *)((longlong)&plStackX_18 + lVar14),iVar10)
              ;
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar18 + 100) & 8) != 0)) &&
             ((2 < iVar10 &&
              (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar20 = *plVar18, lVar20 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1016cc;
            iVar12 = (*_DAT_)(lVar20,0x2000,2,auStack_14ec);
            if (iVar12 != 0) {
              LOCK();
              *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1016ee;
          func_0x(plVar18 + 0x13,iVar10);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10170d;
            func_0x(plVar18,0,iVar10);
          }
          *(uint *)((longlong)&uStackX_24 + lVar14) =
               *(uint *)((longlong)&uStackX_24 + lVar14) & 0xffff0000;
          *(undefined8 *)((longlong)&plStackX_18 + lVar14) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101626;
          func_0x((longlong)&plStackX_18 + lVar14);
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10172c;
    func_0x(puVar16,&stack0x00000034 + lVar14);
    *(uint **)(&stack0xfffffffffffffff0 + lVar14) = &uStack_14e0;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 4;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101755;
    plVar18 = (longlong *)
              func_0x(_DAT_,puVar16,&stack0x00000034 + lVar14,&uStack_1584);
    *(longlong **)((longlong)&plStackX_18 + lVar14) = plVar18;
    uVar28 = *(uint *)((longlong)&uStackX_24 + lVar14) & 0xffff0004 | 4;
    *(uint *)((longlong)&uStackX_24 + lVar14) = uVar28;
    if (puVar19 != (undefined4 *)0x0) {
      if (*(longlong *)(puVar19 + (ulonglong)(puVar19[0x140] & 0xf) * 2 + 0x142) != *plVar18) {
        *(longlong *)(puVar19 + (ulonglong)(puVar19[0x140] & 0xf) * 2 + 0x142) = *plVar18;
        *(longlong *)(puVar19 + 0x140) = *(longlong *)(puVar19 + 0x140) + 1;
        uVar28 = *(uint *)((longlong)&uStackX_24 + lVar14);
      }
    }
    uVar28 = (uStack_1584 >> 3 & 1) << 0x18 | uVar28 & 0xffffff;
    *(uint *)((longlong)&uStackX_24 + lVar14) = uVar28;
    *(uint *)(&stack0x00000028 + lVar14) =
         uStack_1584 >> 4 & 1 | *(uint *)(&stack0x00000028 + lVar14) & 0xffffff00;
    if (((lVar17 != 0) && (puVar19 != (undefined4 *)0x0)) &&
       (puVar19 == *(undefined4 **)(puVar16 + 0x70e))) {
      *(longlong *)(lVar17 + 0x5b28) = *(longlong *)(lVar17 + 0x5b28) + 1;
      if ((int)uStack_14dc != 0) {
        *(longlong *)(lVar17 + 0x5b30) = *(longlong *)(lVar17 + 0x5b30) + 1;
        *(longlong *)(lVar17 + 0x5b38) = *(longlong *)(lVar17 + 0x5b38) + (ulonglong)uStack_14e0;
        if (0xffffff < uVar28) {
          *(longlong *)(lVar17 + 0x5b40) = *(longlong *)(lVar17 + 0x5b40) + 1;
          *(longlong *)(lVar17 + 0x5b48) = *(longlong *)(lVar17 + 0x5b48) + (ulonglong)uStack_14e0;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101822;
    cVar7 = func_0x(puVar16);
    if (((cVar7 == '\0') || (*(byte *)(puVar16 + 0x814) == 0)) ||
       ((*(int *)(&stack0x00000034 + lVar14) == 0 ||
        ((*(int *)(&stack0x00000034 + lVar14) == 9 && (*(short *)(&stack0x00000038 + lVar14) == 1)))
        ))) goto LAB_;
    lVar20 = **(longlong **)((longlong)&plStackX_18 + lVar14);
    if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
      uStack_1560 = *(undefined8 *)(lVar20 + 0x28);
      uStack_1558 = *(ushort *)(lVar20 + 0x30);
    }
    else {
      cVar7 = *(char *)(lVar20 + 1);
      if (cVar7 == '\v') {
        if (*(int *)(lVar20 + 0x18) != 99) {
LAB_:
          if (cVar7 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar7 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar20 + 0x18) != 99) goto LAB_;
      }
      uStack_1540 = *(undefined4 *)(lVar20 + 0x20);
      uStack_153c = *(undefined2 *)(lVar20 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1018a4;
      cVar7 = func_0x(&uStack_1540);
      if (cVar7 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1018b4;
      func_0x(lVar20,&uStack_1560);
    }
    uVar28 = puVar16[0x842];
    do {
      uVar11 = uVar28 & 0xfffffffe;
      *(undefined8 *)(&stack0x0000003c + lVar14) = *(undefined8 *)(puVar16 + 0x83f);
      *(undefined4 *)(&stack0x00000044 + lVar14) = puVar16[0x841];
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14);
      UNLOCK();
      uVar28 = puVar16[0x842];
    } while (uVar11 != uVar28);
    if ((uint)uStack_1560 <= *(uint *)(&stack0x0000003c + lVar14)) {
      if (*(uint *)(&stack0x0000003c + lVar14) != (uint)uStack_1560) goto LAB_;
      uVar28 = (uint)((ulonglong)*(undefined8 *)(&stack0x0000003c + lVar14) >> 0x20);
      if ((uStack_1560._4_4_ <= uVar28) &&
         ((uVar28 != uStack_1560._4_4_ || (uStack_1558 <= *(ushort *)(&stack0x00000044 + lVar14)))))
      goto LAB_;
    }
    if ((*(byte *)(puVar16 + 0x1ab2) == 0) &&
       (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) != *(longlong *)(puVar16 + 0x848))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10196f;
      cVar7 = func_0x(puVar16);
      if (cVar7 == '\0') {
        uVar28 = puVar16[0x842];
        do {
          uVar11 = uVar28 & 0xfffffffe;
          uStack_1500 = *(undefined8 *)(puVar16 + 0x83f);
          *(undefined8 *)(&stack0x0000003c + lVar14) = uStack_1500;
          *(undefined4 *)(&stack0x00000044 + lVar14) = puVar16[0x841];
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar14);
          UNLOCK();
          uVar28 = puVar16[0x842];
        } while (uVar11 != uVar28);
        uVar9 = *(ushort *)(&stack0x00000044 + lVar14);
        lVar17 = **(longlong **)((longlong)&plStackX_18 + lVar14);
        uStack_14f8 = uVar9;
        if (*(short *)(lVar17 + 0x24) == 0) {
LAB_:
          uStack_1570 = *(undefined8 *)(lVar17 + 0x28);
          uStack_1568 = *(ushort *)(lVar17 + 0x30);
        }
        else {
          cVar7 = *(char *)(lVar17 + 1);
          if (cVar7 == '\v') {
            if (*(int *)(lVar17 + 0x18) != 99) {
LAB_:
              if (cVar7 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar7 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar17 + 0x18) != 99) goto LAB_;
          }
          uStack_1530 = *(undefined4 *)(lVar17 + 0x20);
          uStack_152c = *(undefined2 *)(lVar17 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101c25;
          cVar7 = func_0x(&uStack_1530);
          if (cVar7 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101c35;
          func_0x(lVar17,&uStack_1570);
        }
        if ((*(uint *)(&stack0x0000003c + lVar14) < (uint)uStack_1570) ||
           ((*(uint *)(&stack0x0000003c + lVar14) == (uint)uStack_1570 &&
            ((uVar28 = (uint)((ulonglong)uStack_1570 >> 0x20),
             *(uint *)(&stack0x00000040 + lVar14) < uVar28 ||
             ((*(uint *)(&stack0x00000040 + lVar14) == uVar28 && (uVar9 < uStack_1568)))))))) {
          lVar17 = *(longlong *)(puVar16 + 0x1ac);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101c99;
          func_0x(&uStack_1570,asStack_a8,auStack_1548);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101cad;
          func_0x(&uStack_1500,asStack_d8,auStack_1548);
          if ((_DAT_ & 0x10000) != 0) {
            uStack_14b0 = 0x60000;
            uStack_14a8 = 0;
            ppuStack_14a0 = &puStack_1488;
            puStack_1498 = auStack_1428;
            uStack_1268 = 0;
            uStack_1490 = 0;
            uStack_1260 = 0;
            puStack_1488 = &uStack_1258;
            uStack_1480 = 0x34;
            uStack_147c = 5;
            uStack_1470 = 0x10;
            uStack_146c = 5;
            uStack_1460 = 0x10;
            uStack_145c = 6;
            uStack_144c = 7;
            uStack_143c = 8;
            uStack_1438 = 0;
            uStack_1430 = 0;
            uStack_142c = 9;
            uStack_1258 = (uint)*(ushort *)(puVar16 + 0x1ae);
            uStack_1254 = *(undefined2 *)(&stack0x00000038 + lVar14);
            uStack_1252 = *(undefined4 *)(&stack0x00000034 + lVar14);
            uStack_124e = 0xf;
            uStack_124d = *(undefined *)(**(longlong **)((longlong)&plStackX_18 + lVar14) + 1);
            lStack_1478 = lVar17 + 0x254;
            lStack_1468 = lVar17 + 0x244;
            lVar20 = -1;
            do {
              lVar20 = lVar20 + 1;
            } while (asStack_a8[lVar20] != 0);
            iStack_1450 = (int)lVar20 * 2;
            psStack_1458 = asStack_a8;
            lVar20 = -1;
            do {
              lVar20 = lVar20 + 1;
            } while (asStack_d8[lVar20] != 0);
            iStack_1440 = (int)lVar20 * 2;
            psStack_1448 = asStack_d8;
            uStack_1544 = 0;
            pcVar5 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101e65;
            puVar21 = (uint *)(*pcVar5)(lVar17,&uStack_1544);
            ppuVar6 = ppuStack_14a0;
            if (puVar21 != (uint *)0x0) {
              lVar17 = -1;
              do {
                lVar17 = lVar17 + 1;
              } while (*(short *)((longlong)puVar21 + lVar17 * 2) != 0);
              iVar13 = (int)lVar17 * 2;
            }
            ppuStack_14a0[10] = puVar21;
            *(int *)(ppuVar6 + 0xb) = iVar13;
            *(undefined4 *)((longlong)ppuVar6 + 0x5c) = 9;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101e9c;
            func_0x(auStack_14b8);
          }
        }
LAB_:
        if ((1 < *(short *)((longlong)&uStackX_24 + lVar14)) &&
           (*(char *)(**(longlong **)((longlong)&plStackX_18 + lVar14) + 1) != '\x0f')) {
          if (puVar19 != (undefined4 *)0x0) {
            *(longlong *)(puVar19 + 0x162) = **(longlong **)((longlong)&plStackX_18 + lVar14);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ecc;
          lVar17 = func_0x();
          if (lVar17 != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ed6;
            lVar17 = func_0x();
            if (*(longlong *)(lVar17 + 0x30) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ee2;
              lVar17 = func_0x();
              uVar28 = *(uint *)(*(longlong *)(lVar17 + 0x30) + 0xc);
              if ((uVar28 < 0xe) && ((0x2640U >> (uVar28 & 0x1f) & 1) != 0)) goto LAB_;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101f01;
          func_0x(0,8);
        }
LAB_:
        auStack_918[0] = 0xffff;
        uStack_910 = 0;
        uStack_914 = 0;
        uStack_8fa = 0;
        uStack_8f0 = 0;
        uStack_908 = 0;
        uVar4 = **(undefined8 **)((longlong)&plStackX_18 + lVar14);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101f3f;
        func_0x(auStack_918,uVar4);
        uStack_1218 = 0;
        uStack_1210 = 0;
        uStack_1580 = 10;
        uStack_1518 = 0;
        uStack_157c = 8;
        uStack_1208 = 0;
        uStack_1200 = 0;
        auStack_1578[0] = 10;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101f8e;
        iVar13 = func_0x(auStack_918,0x32,&uStack_1218,&uStack_1580);
        if (iVar13 != 0) {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0x153c518;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101fbd;
          (*_DAT_)(1,0x153c448,0x1508ad8,0xb45);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101fd9;
        func_0x(&sStack_1158,0x32,&uStack_1218,uStack_1580);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ff2;
        iVar13 = func_0x(auStack_918,0x36,&uStack_1518,&uStack_157c);
        if (iVar13 != 0) {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0x153c460;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102021;
          (*_DAT_)(1,0x153c448,0x1508ad8,0xb4b);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10203a;
        func_0x(&sStack_1158,0x36,&uStack_1518,uStack_157c);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102056;
        iVar13 = func_0x(auStack_918,0x37,&uStack_1208,auStack_1578);
        if (iVar13 != 0) {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0x153c4a0;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102085;
          (*_DAT_)(1,0x153c448,0x1508ad8,0xb53);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1020a1;
        func_0x(&sStack_1158,0x37,&uStack_1208,auStack_1578[0]);
        uStack_11f8 = 0;
        uStack_11f0 = 0;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) = 0;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1020d5;
        func_0x((longlong)&plStackX_18 + lVar14,&sStack_1158,0,&uStack_11f8);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1020df;
        func_0x((longlong)&plStackX_18 + lVar14);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1020f6;
        func_0x(&uStack_1218,auStack_78,auStack_14e4);
        uVar8 = *(undefined2 *)(param_1 + 0x20);
        uVar1 = *(undefined2 *)(param_1 + 0x60);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102113;
        func_0x(0x13b59a0,uVar1,uVar8,auStack_78);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10211f;
        func_0x(*(undefined8 *)((longlong)&plStackX_18 + lVar14),0);
        lVar17 = *(longlong *)((longlong)&plStackX_18 + lVar14);
        lVar20 = *(longlong *)(lVar17 + 0x90);
        if (lVar20 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102138;
          func_0x(lVar17);
          lVar20 = *(longlong *)(lVar17 + 0x90);
        }
        uVar8 = *(undefined2 *)(lVar17 + 0x74);
        uVar4 = *(undefined8 *)(lVar20 + 0x6a0);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102153;
        lVar17 = func_0x(uVar4,uVar8,0);
        if ((((_DAT_ != 0) || ((_DAT_ & 0x40) != 0)) && ((_DAT_ & 8) == 0))
           && (*(short *)(lVar17 + 0x60) != 2)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102181;
          func_0x(lVar17,1);
        }
        goto LAB_;
      }
    }
    if (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) == *(longlong *)(puVar16 + 0x848)) goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1019b3;
    cVar7 = func_0x(puVar16);
    if (cVar7 != '\0') goto LAB_;
    if (puVar19 == (undefined4 *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1019c5;
      puVar19 = (undefined4 *)func_0x();
    }
    plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar14);
    lVar20 = *plVar18;
    if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
      uStack_1528 = *(undefined8 *)(lVar20 + 0x28);
      uStack_1520 = *(undefined2 *)(lVar20 + 0x30);
    }
    else {
      cVar7 = *(char *)(lVar20 + 1);
      if (cVar7 == '\v') {
        if (*(int *)(lVar20 + 0x18) != 99) {
LAB_:
          if (cVar7 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar7 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar20 + 0x18) != 99) goto LAB_;
      }
      uStack_1538 = *(undefined4 *)(lVar20 + 0x20);
      uStack_1534 = *(undefined2 *)(lVar20 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a15;
      cVar7 = func_0x(&uStack_1538);
      if (cVar7 == '\0') {
        plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar14);
        goto LAB_;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a25;
      func_0x(lVar20,&uStack_1528);
      plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar14);
    }
    if (plVar18 != (longlong *)0x0) {
      iVar10 = (int)*(short *)((longlong)&uStackX_24 + lVar14);
      if (((*(ushort *)((longlong)plVar18 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
        plVar3 = *(longlong **)((longlong)&plStackX_18 + lVar14);
        if (((byte)*(undefined2 *)((longlong)plVar18 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)((longlong)&plStackX_18 + lVar14) + 100) & 8) != 0) &&
              (lVar20 = *(longlong *)(*(longlong *)((longlong)&plStackX_18 + lVar14) + 0x90),
              lVar20 != 0)) && (*(longlong *)(lVar20 + 0x758) != 0)) {
            uVar4 = *(undefined8 *)(lVar20 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ad0;
            func_0x(uVar4,*(undefined8 *)((longlong)&plStackX_18 + lVar14),iVar10);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar3 + 100) & 8) != 0)) &&
            (2 < iVar10)) &&
           (((*(uint *)((longlong)plVar3 + 100) & 0xc0000000) != 0x40000000 &&
            (lVar20 = *plVar3, lVar20 != 0)))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b11;
          iVar12 = (*_DAT_)(lVar20,0x2000,2,auStack_14e8);
          if (iVar12 != 0) {
            LOCK();
            *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b33;
        func_0x(plVar3 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b52;
          func_0x(plVar3,0,iVar10);
        }
        *(uint *)((longlong)&uStackX_24 + lVar14) =
             *(uint *)((longlong)&uStackX_24 + lVar14) & 0xffff0000;
        *(undefined8 *)((longlong)&plStackX_18 + lVar14) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a6b;
        func_0x((longlong)&plStackX_18 + lVar14);
      }
    }
    uStack_1510 = uStack_1528;
    uStack_1508 = uStack_1520;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
    uVar4 = *(undefined8 *)(puVar16 + 0x1ca);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b8f;
    func_0x(uVar4,&uStack_1510,4);
  } while( true );
}

