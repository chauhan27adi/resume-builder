
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  byte *pbVar1;
  byte *pbVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong lVar6;
  longlong **pplVar7;
  undefined2 uVar8;
  uint uVar9;
  undefined8 uVar10;
  byte **ppbVar11;
  ulonglong uVar12;
  uint uVar13;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar14;
  undefined4 *puVar15;
  uint uVar16;
  ushort uVar17;
  byte bVar18;
  undefined auStack_1a8 [32];
  undefined8 uStack_188;
  undefined8 *puStack_180;
  short sStack_168;
  ushort *puStack_160;
  undefined8 uStack_148;
  longlong lStack_130;
  undefined2 uStack_110;
  undefined4 uStack_10c;
  byte *pbStack_108;
  undefined8 uStack_100;
  undefined8 uStack_f2;
  undefined2 uStack_ea;
  undefined2 uStack_e8;
  undefined6 uStack_e6;
  int iStack_dc;
  undefined auStack_d8 [16];
  undefined auStack_c8 [16];
  undefined auStack_b8 [16];
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined8 uStack_68;
  undefined auStack_60 [24];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1a8;
  lVar5 = *(longlong *)(param_2 + 0x10);
  uStack_148 = (longlong **)0x0;
  lVar14 = lVar5;
  if (*(int *)(param_2 + 0x20) == 0) {
    lVar14 = *(longlong *)(param_2 + 0x18);
  }
  lStack_130 = param_1;
  func_0x(*(undefined8 *)(param_1 + 0x10));
  lVar6 = *(longlong *)(param_1 + 0x10);
  uVar9 = 0xa58;
  puStack_160 = (ushort *)0x0;
  *(undefined4 *)(lVar6 + 0x118) = 0;
  *(undefined2 *)(lVar6 + 0x11c) = 0;
  *(undefined4 *)(lVar6 + 0xf4) = 0;
  *(undefined8 *)(lVar6 + 0x124) = 0;
  *(undefined2 *)(lVar6 + 300) = 0;
  *(undefined4 *)(lVar6 + 0x120) = 0;
  *(undefined4 *)(lVar6 + 0x130) = 0;
  *(undefined4 *)(lVar6 + 0xd0) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined2 *)(param_1 + 0x6c) = 0;
  *(undefined8 *)(param_1 + 0x74) = 0;
  *(undefined2 *)(param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0xffffffff;
  *(undefined8 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 100) = 0;
  uVar17 = *(ushort *)(lVar5 + 0x14);
  if (uVar17 <= *(ushort *)(lVar14 + 0x14)) {
    uVar17 = *(ushort *)(lVar14 + 0x14);
  }
  lVar6 = *(longlong *)(**(longlong **)(param_1 + 0x28) + 8);
  bVar18 = *(byte *)(lVar6 + 0x42) & 4;
  if (bVar18 == 0) {
    uVar16 = *(uint *)(lVar6 + 0xb4);
    if (0xa58 < uVar16) {
      uVar16 = 0xa58;
    }
  }
  else {
    uVar16 = 0xa58;
  }
  iVar3 = *(int *)(**(longlong **)(lVar6 + 0x160) + 0x1c);
  uVar13 = (uint)uVar17;
  if ((uint)uVar17 < uVar16 + iVar3) {
    if ((bVar18 == 0) && (uVar9 = *(uint *)(lVar6 + 0xb4), 0xa58 < uVar9)) {
      uVar9 = 0xa58;
    }
    uVar13 = iVar3 + uVar9;
  }
  *(uint *)(param_1 + 0x5c) = uVar13;
  uStack_188._0_1_ = 5;
  uVar10 = (*_DAT_)(0,*(undefined8 *)(param_1 + 8),0x1725b08,0x60e);
  *(undefined8 *)(param_1 + 0x48) = uVar10;
  uStack_188 = (undefined4 *)CONCAT71(uStack_188._1_7_,5);
  uVar10 = (*_DAT_)(*(undefined4 *)(param_1 + 0x5c),*(undefined8 *)(param_1 + 8),0x1725b08,
                            0x60f);
  *(undefined8 *)(param_1 + 0x50) = uVar10;
  func_0x
            (*(undefined8 *)(param_1 + 0x38),lVar5,*(undefined8 *)(param_1 + 0x48),
             *(undefined4 *)(param_1 + 0x5c));
  func_0x(*(undefined8 *)(param_1 + 0x30),lVar14);
  puStack_180 = &uStack_148;
  uStack_188 = (undefined4 *)(param_1 + 0x68);
  func_0x(*(undefined8 *)(param_1 + 0x10),lVar5,0,0);
  if (*(int *)(uStack_148 + 5) == 0) {
    iStack_dc = *(int *)(uStack_148 + 3);
    lVar5 = **uStack_148;
    puStack_160 = (ushort *)(lVar5 + (0xfff - (longlong)iStack_dc) * 2);
    if ((*(byte *)((ulonglong)*puStack_160 + lVar5) & 1) != 0) {
      uStack_110 = 0xffff;
      pbStack_108 = (byte *)0x0;
      uStack_10c = 0;
      uStack_f2 = 0;
      uStack_e8 = 0;
      uStack_e6 = 0;
      uStack_100 = 0;
      if (*(char *)(lVar5 + 2) < '\0') {
        auStack_d8 = ZEXT816(0);
        uStack_68 = 0;
        auStack_c8 = ZEXT816(0);
        auStack_b8 = ZEXT816(0);
        auStack_a8 = ZEXT816(0);
        auStack_98 = ZEXT816(0);
        auStack_88 = ZEXT816(0);
        auStack_78 = ZEXT816(0);
        ppbVar11 = (byte **)func_0x(auStack_d8,uStack_148,(longlong)iStack_dc,2);
        uVar10 = func_0x(lVar5,auStack_60,0,0);
        if ((byte *)(lVar5 + 0x60) == *ppbVar11) {
          func_0x(uVar10,ppbVar11 + 0xc);
        }
        *ppbVar11 = (byte *)(lVar5 + 0x60);
        func_0x(ppbVar11 + 0xc,uVar10);
        *(undefined4 *)((longlong)ppbVar11 + 0x6c) = *(undefined4 *)(lVar5 + 0x20);
        pbVar2 = (byte *)(lVar5 + 0x60);
        *(undefined2 *)(ppbVar11 + 0xe) = *(undefined2 *)(lVar5 + 0x24);
        *(undefined2 *)((longlong)ppbVar11 + 0x72) = 0;
        uVar4 = *(undefined4 *)((ulonglong)*pbVar2 * 6 + 0x1516450);
        sStack_168 = *(short *)((ulonglong)*pbVar2 * 6 + 0x1516454);
        uStack_148 = (longlong **)CONCAT44(uStack_148._4_4_,uVar4);
        pplVar7 = uStack_148;
        *(undefined2 *)(ppbVar11 + 2) = 0xffff;
        ppbVar11[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar11 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar11 + 0x2e) = 0;
        ppbVar11[7] = (byte *)0x0;
        ppbVar11[4] = (byte *)0x0;
        ppbVar11[9] = (byte *)0x0;
        ppbVar11[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar11 + 0xb) = 0;
        if ((**ppbVar11 & 2) != 0) {
          pbVar1 = pbVar2 + sStack_168;
          if ((pbVar2[sStack_168] & 1) == 0) {
            *(undefined2 *)(ppbVar11 + 2) = 0;
            ppbVar11[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar11 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar11 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010050e */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x100f88) -
                      0x10239e0))();
            return;
          }
          *(undefined2 *)(ppbVar11 + 2) = 1;
          ppbVar11[3] = pbVar1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x100f68) *
                                  4 + 0x100f58) - 0x10239e0);
                    /* WARNING: Could not emulate address calculation at 0x00100390 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if ((**ppbVar11 & 4) != 0) {
          uStack_148._2_2_ = (short)((uint)uVar4 >> 0x10);
          if (uStack_148._2_2_ == 0) {
            uVar12 = (ulonglong)sStack_168;
          }
          else {
            uVar12 = (ulonglong)*(ushort *)(lVar5 + 0x61 + (longlong)uStack_148._2_2_ * 2);
          }
          uStack_148 = pplVar7;
          func_0x(ppbVar11 + 9,pbVar2 + uVar12);
        }
        if (ppbVar11[1] != (byte *)0x0) {
          func_0x(ppbVar11[1],ppbVar11);
        }
      }
      pbStack_108 = (byte *)((ulonglong)*puStack_160 + lVar5);
      if ((*pbStack_108 & 1) == 0) {
        uStack_110 = 0;
        uStack_10c = 0;
        uStack_ea = 0;
        uStack_e8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010076f */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_108 & 0xe) * 4 + 0x100ff4) -
                  0x10239e0))(0x1495e48,(longlong)(int)(*pbStack_108 & 0xe),pbStack_108,2);
        return;
      }
      uStack_110 = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_108 & 0x1c) + 0x100fd4)
                              * 4 + 0x100fc4) - 0x10239e0);
                    /* WARNING: Could not emulate address calculation at 0x00100615 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    puVar15 = (undefined4 *)
              ((byte *)((ulonglong)*puStack_160 + lVar5) +
              *(int *)(*(longlong *)(**(longlong **)(*(longlong *)(param_1 + 0x10) + 8) + 8) + 0x210
                      ));
    *(undefined4 *)(param_1 + 0x80) = *puVar15;
    uVar8 = *(undefined2 *)(puVar15 + 1);
  }
  else {
    *(undefined4 *)(param_1 + 0x80) = *(undefined4 *)((longlong)uStack_148 + 0x34);
    uVar8 = *(undefined2 *)(uStack_148 + 7);
  }
  *(undefined2 *)(param_1 + 0x84) = uVar8;
  func_0x(uStack_48 ^ (ulonglong)auStack_1a8);
  return;
}

