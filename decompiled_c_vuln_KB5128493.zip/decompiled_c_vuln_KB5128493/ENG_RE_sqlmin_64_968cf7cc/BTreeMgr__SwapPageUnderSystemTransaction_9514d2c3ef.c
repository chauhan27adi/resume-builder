
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,longlong **param_3,undefined8 param_4,
                 undefined8 param_5,int param_6)

{
  byte **ppbVar1;
  byte bVar2;
  short sVar3;
  int iVar4;
  undefined8 *puVar5;
  longlong **pplVar6;
  undefined *puVar7;
  char cVar8;
  short sVar9;
  short sVar10;
  int iVar11;
  ushort uVar12;
  longlong lVar13;
  uint uVar14;
  uint uVar15;
  ushort *puVar16;
  longlong lVar17;
  uint uVar18;
  int *piVar19;
  byte *pbVar20;
  undefined4 uVar21;
  ulonglong uVar22;
  longlong unaff_GS_OFFSET;
  undefined auStack_928 [32];
  undefined8 uStack_908;
  undefined4 uStack_900;
  undefined8 uStack_8f8;
  undefined8 uStack_8f0;
  undefined4 uStack_8e8;
  undefined4 uStack_8e0;
  undefined8 uStack_8d8;
  undefined8 uStack_8d0;
  undefined4 uStack_8c8;
  undefined8 uStack_8c0;
  undefined4 uStack_8b8;
  undefined4 uStack_8b0;
  undefined8 uStack_8a8;
  undefined8 uStack_8a0;
  int iStack_898;
  int iStack_894;
  ushort *puStack_890;
  char cStack_888;
  uint uStack_858;
  undefined4 uStack_854;
  undefined2 uStack_850;
  longlong **pplStack_848;
  uint *puStack_840;
  longlong **pplStack_838;
  longlong lStack_830;
  longlong lStack_828;
  byte bStack_820;
  byte bStack_81f;
  byte bStack_81e;
  byte bStack_814;
  byte bStack_813;
  byte bStack_812;
  uint uStack_810;
  uint uStack_808;
  byte bStack_800;
  byte bStack_7ff;
  byte bStack_7fe;
  byte bStack_7fd;
  byte bStack_7fc;
  byte bStack_7fb;
  byte bStack_7fa;
  longlong lStack_7f8;
  byte bStack_7f0;
  undefined8 uStack_7e8;
  short sStack_7e0;
  longlong lStack_7d8;
  undefined uStack_7d0;
  undefined4 uStack_7cc;
  undefined4 uStack_7c0;
  undefined2 uStack_7bc;
  undefined2 uStack_7ba;
  undefined8 uStack_7b8;
  uint uStack_7b0;
  undefined4 uStack_7ac;
  uint uStack_7a8;
  uint uStack_7a4;
  undefined4 uStack_7a0;
  undefined2 uStack_79c;
  undefined4 uStack_798;
  undefined2 uStack_794;
  undefined4 uStack_790;
  undefined2 uStack_78c;
  longlong *plStack_788;
  int *piStack_780;
  ushort uStack_778;
  ushort uStack_774;
  short sStack_768;
  ushort uStack_764;
  int iStack_748;
  short sStack_744;
  int iStack_740;
  short sStack_73c;
  undefined4 uStack_738;
  short sStack_734;
  ushort uStack_700;
  short sStack_6f8;
  int *piStack_6f0;
  ushort uStack_6e8;
  ushort uStack_6e0;
  short sStack_6dc;
  ushort uStack_6d8;
  ushort uStack_6d4;
  ushort uStack_6d0;
  ushort uStack_6cc;
  ushort *puStack_6c8;
  undefined8 uStack_6c0;
  int *piStack_6b8;
  int *piStack_6b0;
  undefined8 uStack_6a8;
  undefined uStack_6a0;
  undefined4 uStack_69c;
  undefined4 uStack_690;
  undefined2 uStack_68c;
  undefined4 uStack_68a;
  undefined2 uStack_686;
  undefined4 uStack_684;
  undefined2 uStack_680;
  undefined4 uStack_67e;
  undefined2 uStack_67a;
  undefined4 uStack_678;
  undefined2 uStack_674;
  int iStack_670;
  uint uStack_668;
  uint uStack_664;
  int iStack_660;
  int iStack_65c;
  uint uStack_658;
  uint uStack_650;
  uint uStack_64c;
  uint uStack_648;
  undefined auStack_644 [4];
  int iStack_640;
  uint uStack_638;
  int iStack_630;
  int iStack_558;
  int iStack_550;
  undefined *puStack_548;
  int *piStack_540;
  longlong lStack_538;
  longlong lStack_530;
  longlong lStack_528;
  ulonglong uStack_520;
  longlong lStack_518;
  longlong lStack_510;
  int *piStack_508;
  longlong **pplStack_500;
  undefined8 uStack_4f8;
  longlong **pplStack_4f0;
  uint uStack_4e8;
  int iStack_4e0;
  int iStack_4dc;
  undefined8 uStack_4d8;
  undefined8 *puStack_4d0;
  undefined4 uStack_4a0;
  undefined4 uStack_49c;
  undefined8 uStack_488;
  undefined4 *puStack_480;
  undefined8 uStack_478;
  longlong lStack_470;
  int *piStack_468;
  longlong lStack_460;
  undefined *puStack_458;
  undefined *puStack_450;
  undefined *puStack_448;
  short **ppsStack_440;
  undefined *puStack_438;
  undefined *puStack_430;
  undefined4 *puStack_428;
  undefined4 *puStack_420;
  undefined8 *puStack_418;
  undefined4 *puStack_410;
  byte *pbStack_408;
  undefined *puStack_400;
  undefined *puStack_3f8;
  undefined *puStack_3f0;
  undefined *puStack_3e8;
  longlong lStack_3e0;
  undefined *puStack_3d8;
  short **ppsStack_3d0;
  byte *pbStack_3c8;
  undefined *puStack_3c0;
  undefined *puStack_3b8;
  byte *pbStack_3b0;
  undefined *puStack_3a8;
  ushort *puStack_3a0;
  byte *pbStack_398;
  byte *pbStack_390;
  byte *pbStack_388;
  short *psStack_380;
  short **ppsStack_378;
  byte *pbStack_370;
  ushort *puStack_368;
  byte *pbStack_360;
  ushort *puStack_358;
  ushort *puStack_350;
  byte *pbStack_348;
  byte *pbStack_340;
  byte *pbStack_338;
  byte *pbStack_330;
  int *piStack_328;
  byte *pbStack_320;
  int *piStack_318;
  byte *pbStack_310;
  int *piStack_308;
  longlong lStack_300;
  longlong lStack_2f8;
  longlong lStack_2f0;
  longlong lStack_2e8;
  longlong lStack_2e0;
  longlong lStack_2d8;
  longlong lStack_2d0;
  longlong lStack_2c8;
  longlong lStack_2c0;
  ushort *puStack_2b8;
  byte *pbStack_2b0;
  ushort *puStack_2a8;
  longlong lStack_2a0;
  ulonglong *puStack_298;
  ulonglong *puStack_290;
  longlong lStack_288;
  longlong lStack_280;
  longlong lStack_278;
  longlong lStack_270;
  longlong lStack_268;
  longlong lStack_260;
  byte *pbStack_258;
  int *piStack_250;
  longlong lStack_248;
  longlong *plStack_240;
  longlong *plStack_238;
  int *piStack_230;
  longlong *plStack_228;
  undefined4 *puStack_130;
  undefined8 uStack_128;
  longlong lStack_120;
  undefined4 *puStack_118;
  ushort uStack_f8;
  ushort uStack_f6;
  uint uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  uint uStack_e0;
  ushort uStack_dc;
  longlong lStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  undefined4 uStack_c8;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [2];
  undefined auStack_ae [6];
  undefined8 uStack_a8;
  uint uStack_a0;
  undefined4 uStack_9c;
  undefined2 uStack_98;
  short sStack_96;
  short sStack_94;
  undefined2 uStack_92;
  undefined2 uStack_90;
  undefined2 uStack_8e;
  undefined2 uStack_8c;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [8];
  short sStack_58;
  undefined auStack_56 [2];
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined8 uStack_48;
  ulonglong uStack_40;
  
  uStack_128 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_928;
  uStack_7b8 = param_5;
  uStack_6c0 = param_5;
  puVar5 = (undefined8 *)**(longlong **)(param_1 + 8);
  lStack_828 = (ulonglong)*(uint6 *)((longlong)puVar5 + 0x14) << 0x10;
  uStack_7c0 = *(undefined4 *)(puVar5[1] + 0x3c0);
  uStack_7bc = *(undefined2 *)(puVar5[1] + 0x3c4);
  uStack_7ba = 0;
  lVar13 = **param_2;
  iVar11 = *(int *)(lVar13 + 8);
  sVar10 = *(short *)(lVar13 + 0xc);
  iVar4 = *(int *)(lVar13 + 0x10);
  sVar3 = *(short *)(lVar13 + 0x14);
  lStack_7d8 = 0;
  uStack_7d0 = 0;
  uStack_7cc = 0;
  uStack_854 = 0;
  uStack_850 = 0;
  uStack_858 = 2;
  uVar21 = 2;
  if (*(int *)(param_1 + 0xfc) == 3) {
    uVar21 = 0;
  }
  uStack_4a0 = 0;
  uStack_4d8 = 0;
  pplStack_848 = param_2;
  pplStack_838 = param_3;
  lStack_830 = param_1;
  lStack_7f8 = param_1;
  iStack_748 = iVar4;
  sStack_744 = sVar3;
  iStack_740 = iVar11;
  sStack_73c = sVar10;
  pplStack_500 = param_2;
  uStack_4f8 = param_4;
  pplStack_4f0 = param_3;
  puStack_4d0 = puVar5;
  sVar9 = (**(code **)*puVar5)(puVar5);
  uStack_49c = uVar21;
  if (sVar9 == 2) {
    uStack_49c = 2;
  }
  if ((*(byte *)(**pplStack_848 + 2) & 0x20) != 0) {
    uStack_908 = (undefined8 *)0x0;
    (*_DAT_)(1,0x1ae9e30,0x1ac06b8,0xc25);
  }
  func_0x(lStack_7f8,0x1944b80);
  uStack_4d8 = *(undefined8 *)(lStack_7f8 + 0x110);
  if (*pplStack_838 != (longlong *)0x0) {
    func_0x(&uStack_4d8,pplStack_838);
  }
  uStack_67e = 0;
  uStack_67a = 0;
  if ((iVar11 != 0) || (sVar10 != 0)) {
    func_0x(&uStack_4d8,param_4);
  }
  func_0x(&uStack_4d8,pplStack_848);
  uStack_68a = 0;
  uStack_686 = 0;
  if ((iVar4 != 0) || (sVar3 != 0)) {
    func_0x(&uStack_4d8,uStack_7b8);
  }
  lStack_120 = **pplStack_848;
  uStack_900 = 1;
  uStack_908 = (undefined8 *)CONCAT44(uStack_908._4_4_,(uint)*(byte *)(lStack_120 + 3));
  func_0x(lStack_7f8,&lStack_7d8,&iStack_740,&iStack_748);
  puStack_130 = (undefined4 *)(lStack_7d8 + 0x70);
  uStack_854 = *puStack_130;
  uStack_850 = *(undefined2 *)(lStack_7d8 + 0x74);
  func_0x(&uStack_4d8,&lStack_7d8);
  lVar13 = lStack_7f8;
  uStack_684 = 0;
  uStack_680 = 0;
  if ((iVar11 != 0) || (sVar10 != 0)) {
    puStack_118 = &uStack_790;
    uStack_790 = uStack_854;
    uStack_78c = uStack_850;
    uStack_8f8 = *(int **)(lStack_7f8 + 0x110);
    uStack_908 = (undefined8 *)&uStack_790;
    uStack_900 = uVar21;
    uStack_488 = uStack_8f8;
    func_0x(param_4,&uStack_7c0);
  }
  uStack_678 = 0;
  uStack_674 = 0;
  if ((iVar4 != 0) || (sVar3 != 0)) {
    puStack_480 = &uStack_7a0;
    uStack_7a0 = uStack_854;
    uStack_79c = uStack_850;
    uStack_8f8 = *(int **)(lVar13 + 0x110);
    uStack_908 = (undefined8 *)&uStack_7a0;
    uStack_900 = uVar21;
    uStack_478 = uStack_8f8;
    func_0x(uStack_7b8,&uStack_7c0);
  }
  pplVar6 = pplStack_848;
  if (*(char *)(puVar5[4] + 0x1cdf) == '\0') {
    bStack_814 = 0;
  }
  else if (*(char *)(puVar5[4] + 0x1cdc) == '\0') {
    bStack_814 = 0;
  }
  else {
    bStack_814 = *(byte *)(puVar5[1] + 0x109) >> 6 & 1;
  }
  lStack_470 = **pplStack_848;
  uStack_8f0 = (undefined4 *)CONCAT71(uStack_8f0._1_7_,bStack_814);
  uStack_8f8 = *(int **)(lVar13 + 0x110);
  uStack_900 = *(undefined4 *)(lVar13 + 0x100);
  uStack_908 = (undefined8 *)CONCAT44(uStack_908._4_4_,(uint)*(ushort *)(lStack_470 + 0x16));
  func_0x(&lStack_7d8,&uStack_7c0,pplStack_848,0);
  if (*pplStack_838 == (longlong *)0x0) {
    func_0x(lVar13,pplVar6,&uStack_854,&uStack_4d8);
    goto code_r0x0010233a;
  }
  uStack_6a8 = 0;
  uStack_6a0 = 0;
  uStack_69c = 0;
  uStack_f8 = 0xffff;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  lStack_da = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_e8 = (longlong *)0x0;
  piStack_780 = (int *)(puVar5[1] + 0x200);
  lVar13 = **pplStack_838;
  iStack_c4 = param_6;
  piStack_468 = piStack_780;
  lStack_460 = lVar13;
  if (*(char *)(lVar13 + 2) < '\0') {
    puStack_458 = auStack_c0;
    uStack_98 = 0;
    sStack_96 = 0;
    sStack_94 = 0;
    uStack_8a = 0;
    uStack_80 = SUB164(ZEXT816(0),0);
    uStack_80 = 0;
    uStack_7c = SUB164(ZEXT816(0),4);
    uStack_7c = 0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uStack_66 = 0;
    puStack_450 = auStack_c0;
    auStack_c0 = ZEXT816(0);
    puStack_448 = auStack_b0;
    _auStack_ae = SUB1614(ZEXT816(0),2);
    auStack_b0 = (undefined  [2])0xffff;
    uStack_a8 = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_8e = 0;
    uStack_8c = 0;
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    ppsStack_440 = &psStack_78;
    psStack_78 = (short *)0x0;
    puStack_438 = auStack_60;
    _auStack_60 = ZEXT812(0);
    uStack_54 = 0;
    puStack_430 = auStack_56 + 2;
    uStack_50 = 0;
    plStack_788 = (longlong *)auStack_c0;
    cStack_888 = '\0';
    if (*(short *)(lVar13 + 0x24) == 0) {
LAB_:
      uStack_7e8 = *(undefined8 *)(lVar13 + 0x28);
      sStack_7e0 = *(short *)(lVar13 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar13 + 1);
      if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) &&
         (*(int *)(lVar13 + 0x18) == 99)) {
        puStack_428 = &uStack_798;
        puStack_420 = (undefined4 *)(lVar13 + 0x20);
        uStack_798 = *puStack_420;
        uStack_794 = *(undefined2 *)(lVar13 + 0x24);
        cVar8 = func_0x(&uStack_798);
        if (cVar8 == '\0') goto LAB_;
        cStack_888 = '\x01';
      }
      else {
LAB_:
        cStack_888 = '\0';
      }
      if (cStack_888 == '\0') goto LAB_;
      func_0x(lVar13,&uStack_7e8);
    }
    puStack_418 = &uStack_7e8;
    puStack_410 = (undefined4 *)(lVar13 + 0x20);
    pbVar20 = (byte *)(lVar13 + 0x60);
    puStack_400 = auStack_c0;
    puVar7 = puStack_548;
    if (pbVar20 == (byte *)auStack_c0._0_8_) {
      puStack_3f8 = auStack_60;
      if ((sStack_7e0 == sStack_58) && ((int)uStack_7e8 == auStack_60._0_4_)) {
        puVar7 = auStack_56 + 2;
        if (uStack_7e8._4_4_ != auStack_60._4_4_) {
          puVar7 = puStack_548;
        }
      }
    }
    puStack_548 = puVar7;
    auStack_c0._0_8_ = pbVar20;
    puStack_3f0 = auStack_60;
    iStack_558 = uStack_7e8._4_4_;
    iStack_550 = (int)uStack_7e8;
    sStack_58 = sStack_7e0;
    auStack_60 = (undefined  [8])uStack_7e8;
    puStack_3e8 = auStack_56 + 2;
    uStack_54 = *puStack_410;
    uVar22 = (ulonglong)*pbVar20;
    uStack_6e8 = (ushort)*pbVar20;
    uStack_690 = *(undefined4 *)(uVar22 * 6 + 0x1738eb0);
    uStack_68c = *(undefined2 *)(uVar22 * 6 + 0x1738eb4);
    uStack_738 = *(undefined4 *)(uVar22 * 6 + 0x1738eb0);
    sStack_734 = *(short *)(uVar22 * 6 + 0x1738eb4);
    uVar22 = (ulonglong)sStack_734;
    lStack_3e0 = lVar13 + 99;
    puStack_3d8 = auStack_b0;
    auStack_b0 = (undefined  [2])0xffff;
    uVar15 = 0;
    _auStack_b0 = _auStack_b0 & 0xffffffff;
    uStack_a8 = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_8e = 0;
    uStack_8c = 0;
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    ppsStack_3d0 = &psStack_78;
    psStack_78 = (short *)0x0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    sStack_6f8 = sStack_7e0;
    pbStack_408 = pbVar20;
    if ((*pbVar20 & 2) != 0) {
      pbStack_3c8 = pbVar20 + uVar22;
      puStack_3c0 = auStack_b0;
      uStack_6e0 = CONCAT11(0,*pbStack_3c8 & 1);
      auStack_ae = (undefined  [6])(int6)(_auStack_b0 >> 0x10);
      auStack_b0 = (undefined  [2])uStack_6e0;
      puVar7 = auStack_b0 + 2;
      if ((*pbStack_3c8 & 1) == 0) {
        uStack_810 = 0;
        uStack_a8 = pbStack_3c8;
        uStack_8a = 0;
        uStack_88 = 0;
        puStack_3b8 = puVar7;
        pbStack_3b0 = pbStack_3c8;
        switch(*pbStack_3c8 & 0xe) {
        default:
          uVar12 = *(ushort *)(pbStack_3c8 + 2);
          uVar15 = (uint)uVar12;
          uStack_810 = (uint)uVar12;
          if (0x1f9d < uVar12 - 1) {
            func_0x(pbStack_3c8,6);
          }
          break;
        case 4:
          uVar15 = 9;
          uStack_810 = uVar15;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar15 = 1;
          uStack_810 = uVar15;
        }
        uStack_a0 = uVar15;
        uStack_92 = 0;
        uStack_90 = 0;
        uStack_8e = 0;
        uStack_8c = 0;
        goto code_r0x00100e36;
      }
      bVar2 = *pbStack_3c8;
      switch(bVar2 & 0x1c) {
      default:
        puStack_3a0 = (ushort *)(pbStack_3c8 + 1);
        bVar2 = *(byte *)puStack_3a0;
        if ((char)bVar2 < '\0') {
          uVar12 = (*puStack_3a0 & 0x7f) << 8 | *puStack_3a0 >> 8;
          _auStack_b0 = CONCAT22(uVar12,uStack_6e0);
          uStack_98 = 3;
          sVar10 = 3;
        }
        else {
          uVar12 = (ushort)bVar2;
          _auStack_b0 = (uint)CONCAT12(bVar2,uStack_6e0);
          uStack_98 = 2;
          sVar10 = 2;
        }
        sStack_94 = (short)(uVar12 + 1 >> 1) + sVar10;
        if (uVar12 < 0x1f) {
          sStack_96 = 0;
        }
        else {
          iVar11 = uVar12 - 1;
          sStack_96 = ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                      (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
        }
        auStack_ae._2_4_ = 0;
        uStack_a8 = pbStack_3c8;
        uStack_80 = 0;
        goto code_r0x00100e06;
      case 4:
        pbStack_390 = pbStack_3c8;
        pbStack_388 = pbStack_3c8;
        if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
          uStack_98 = 0;
          auStack_ae._0_2_ = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_92 = 0;
          uStack_90 = 0;
          uStack_8e = 0;
          uStack_8c = 0;
          uStack_8a = 0;
          auStack_ae._2_4_ = 0xf;
          uStack_a8 = pbStack_3c8;
          uStack_80 = 1;
        }
        else {
          uStack_98 = 0;
          auStack_ae._0_2_ = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_92 = 0;
          uStack_90 = 0;
          uStack_8e = 0;
          uStack_8c = 0;
          uStack_8a = 0;
          auStack_ae._2_4_ = 1;
          uStack_a8 = pbStack_3c8;
          uStack_80 = 0;
        }
        break;
      case 8:
        uStack_98 = 0;
        auStack_ae._0_2_ = 0;
        sStack_96 = 0;
        sStack_94 = 0;
        uStack_92 = 0;
        uStack_90 = 0;
        uStack_8e = 0;
        uStack_8c = 0;
        uStack_8a = 0;
        auStack_ae._2_4_ = 9;
        uStack_a8 = pbStack_3c8;
        uStack_80 = 0;
        pbStack_398 = pbStack_3c8;
      }
      uStack_8a = 0;
      sStack_94 = 0;
      sStack_96 = 0;
      uStack_98 = 0;
code_r0x00100e06:
      uStack_88 = 0;
      uStack_86 = 0;
      uStack_a0 = 0;
      uStack_9c = 0;
      puStack_3a8 = puVar7;
    }
code_r0x00100e36:
    uStack_8c = 0;
    uStack_8e = 0;
    uStack_90 = 0;
    uStack_92 = 0;
    if ((*(byte *)auStack_c0._0_8_ & 4) != 0) {
      if (uStack_738._2_2_ != 0) {
        uVar22 = (ulonglong)*(ushort *)(lVar13 + 0x61 + (longlong)uStack_738._2_2_ * 2);
      }
      psStack_380 = (short *)(pbVar20 + uVar22);
      ppsStack_378 = &psStack_78;
      psStack_78 = psStack_380;
      sStack_6dc = *psStack_380;
      psStack_70 = psStack_380 + 1;
      sStack_68 = (sStack_6dc + 1) * 2;
    }
    if (auStack_c0._8_8_ != 0) {
      func_0x(auStack_c0._8_8_,auStack_c0);
    }
  }
  else {
    plStack_788 = (longlong *)0x0;
  }
  uVar15 = (uint)*(ushort *)(lVar13 + 0xe);
  uStack_4e8 = (uint)*(ushort *)(lVar13 + 0xe);
  pbStack_370 = (byte *)((ulonglong)*(ushort *)(lVar13 + (0xfff - (longlong)param_6) * 2) + lVar13);
  uStack_6d8 = (ushort)(*pbStack_370 & 1);
  uStack_f8 = uStack_6d8;
  if ((*pbStack_370 & 1) == 0) {
    pbStack_f0 = pbStack_370;
    uStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
    uStack_808 = uStack_4e8;
    puStack_368 = &uStack_f6;
    pbStack_360 = pbStack_370;
    switch(*pbStack_370 & 0xe) {
    default:
      uVar12 = *(ushort *)(pbStack_370 + 2);
      uVar15 = (uint)uVar12;
      uStack_808 = (uint)uVar12;
      if (0x1f9d < uVar12 - 1) {
        func_0x(pbStack_370,6);
      }
      break;
    case 4:
      uVar15 = 9;
      uStack_808 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar15 = 1;
      uStack_808 = 1;
    }
    uStack_e8 = (longlong *)CONCAT44(uStack_e8._4_4_,uVar15);
    lStack_da = lVar13 + 0x2000;
  }
  else {
    pbStack_f0 = pbStack_370;
    bVar2 = *pbStack_370;
    switch(bVar2 & 0x1c) {
    default:
      puStack_350 = (ushort *)(pbStack_370 + 1);
      if ((char)*(byte *)puStack_350 < '\0') {
        uStack_f6 = (*puStack_350 & 0x7f) << 8 | *puStack_350 >> 8;
        uStack_e0 = 3;
        uStack_858 = 3;
      }
      else {
        uStack_f6 = (ushort)*(byte *)puStack_350;
        uStack_e0 = 2;
      }
      uStack_dc = (short)(uStack_f6 + 1 >> 1) + (short)uStack_858;
      if (uStack_f6 < 0x1f) {
        uStack_f4 = 0;
        uStack_c8 = 0;
      }
      else {
        iVar11 = uStack_f6 - 1;
        uStack_e0 = CONCAT22(((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                             (short)((longlong)iVar11 * 0x88888889 >> 0x3f),(undefined2)uStack_e0);
        uStack_f4 = 0;
        uStack_c8 = 0;
      }
      break;
    case 4:
      pbStack_340 = pbStack_370;
      pbStack_338 = pbStack_370;
      if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
        uStack_f6 = 0;
        uStack_e0 = 0;
        uStack_dc = 0;
        lStack_da = 0;
        uStack_d2 = 0;
        uStack_f4 = 0xf;
        uStack_c8 = 1;
      }
      else {
        uStack_f6 = 0;
        uStack_e0 = 0;
        uStack_dc = 0;
        lStack_da = 0;
        uStack_d2 = 0;
        uStack_f4 = 1;
        uStack_c8 = 0;
      }
      break;
    case 8:
      uStack_f6 = 0;
      uStack_e0 = 0;
      uStack_dc = 0;
      lStack_da = 0;
      uStack_d2 = 0;
      uStack_f4 = 9;
      uStack_c8 = 0;
      pbStack_348 = pbStack_370;
    }
    uStack_d0 = (undefined2)(lVar13 + 0x2000);
    uStack_ce = (undefined6)((ulonglong)(lVar13 + 0x2000) >> 0x10);
    uStack_e8 = plStack_788;
    uVar15 = (uint)plStack_788;
    puStack_358 = &uStack_f6;
  }
  puStack_840 = (uint *)(piStack_780 + 4);
  if (uStack_f8 == 0) {
    puVar16 = &uStack_f6;
    uVar18 = *puStack_840;
    puStack_890 = puVar16;
    if ((uVar18 & 0xc0000000) == 0x80000000) {
      iVar11 = func_0x(&uStack_f6);
      if (iVar11 == 0) {
        iStack_894 = 0;
        piStack_780 = (int *)0x0;
        piStack_508 = (int *)0x0;
        piVar19 = piStack_780;
      }
      else {
        piVar19 = (int *)func_0x(&uStack_ce,puStack_840,&iStack_894,auStack_644);
        piStack_508 = piVar19;
      }
    }
    else {
      uVar12 = *(ushort *)((longlong)piStack_780 + 0x16);
      if ((uVar12 & 0x10) == 0) {
code_r0x0010144c:
        uStack_858 = 1;
code_r0x0010145e:
        iVar11 = 0;
        if ((int)uVar18 < 0) {
          if (uStack_f4 == 0) {
            iStack_898 = 0;
            uStack_f6 = 0;
            if ((*pbStack_f0 & 0x10) != 0) {
              uVar15 = uVar15 + 2 + (*(ushort *)(pbStack_f0 + uVar15) + 7 >> 3);
            }
            uStack_e8 = (longlong *)CONCAT44(uVar15,(undefined4)uStack_e8);
            if ((*pbStack_f0 & 0x20) == 0) {
              uStack_f4 = uVar15;
              uStack_dc = 0;
              uStack_e0 = uVar15;
            }
            else {
              puStack_6c8 = (ushort *)(pbStack_f0 + uVar15);
              uStack_dc = *puStack_6c8;
              if (*puStack_6c8 == 0) {
                iStack_898 = 1;
                if ((cRam000000000204b99b != '\0') ||
                   (bStack_800 = bRam000000000205c2a0, (bRam000000000205c2a0 & 1) != 0)) {
                  lStack_300 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  lStack_2f8 = (ulonglong)*_DAT_ +
                               *(longlong *)(lStack_300 + (ulonglong)*_DAT_ * 8);
                  lStack_2f0 = *(longlong *)(lStack_2f8 + 8);
                  if (lStack_2f0 == 0) {
                    lStack_538 = 0;
                  }
                  else {
                    lStack_538 = *(longlong *)(lStack_2f0 + 0x60);
                    if ((lStack_538 != 0) && (*(char *)(lStack_538 + 0x499) != '\0')) {
                      if ((cRam000000000204b88b == '\0') &&
                         (bStack_7ff = bRam000000000205c2a0 >> 1, (bStack_7ff & 1) == 0)) {
                        (*pcRam00000000015ba1c8)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        uStack_908 = (undefined8 *)0x0;
                        (*_DAT_)(1,0x193c3c8,0x1a5c098,0x80f);
                      }
                    }
                  }
                }
                puVar16 = puStack_890;
                func_0x(pbStack_f0,3);
                uVar15 = uStack_e8._4_4_;
              }
              uStack_e0 = uVar15 + (uStack_dc + 1) * 2;
              if (0x1f9e < uStack_e0) {
                iStack_898 = iStack_898 + 1;
                if ((cRam000000000204b99b != '\0') ||
                   (bStack_7fe = bRam000000000205c2a0, (bRam000000000205c2a0 & 1) != 0)) {
                  lStack_2e8 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  lStack_2e0 = (ulonglong)*_DAT_ +
                               *(longlong *)(lStack_2e8 + (ulonglong)*_DAT_ * 8);
                  lStack_2d8 = *(longlong *)(lStack_2e0 + 8);
                  puVar16 = puStack_890;
                  if (lStack_2d8 == 0) {
                    lStack_530 = 0;
                  }
                  else {
                    lStack_530 = *(longlong *)(lStack_2d8 + 0x60);
                    if ((lStack_530 != 0) && (*(char *)(lStack_530 + 0x499) != '\0')) {
                      if ((cRam000000000204b88b == '\0') &&
                         (bStack_7fd = bRam000000000205c2a0 >> 1, (bStack_7fd & 1) == 0)) {
                        (*pcRam00000000015ba1c8)(0x22,0x44,0x15,0x3ec);
                        puVar16 = puStack_890;
                      }
                      else {
                        uStack_908 = (undefined8 *)0x0;
                        (*_DAT_)(1,0x193c3c8,0x1a5c098,0x816);
                        puVar16 = puStack_890;
                      }
                    }
                  }
                }
                func_0x(pbStack_f0,4);
                uVar15 = uStack_e8._4_4_;
              }
              uVar22 = (ulonglong)uStack_dc;
              uStack_6d4 = puStack_6c8[uVar22];
              uStack_f4 = uStack_6d4 & 0x7fff;
              pbVar20 = pbStack_f0;
              uVar18 = uStack_e0;
              if ((uStack_6d4 & 0x7fff) < uStack_e0) {
                iStack_898 = iStack_898 + 1;
                if ((cRam000000000204b99b != '\0') ||
                   (bStack_7fc = bRam000000000205c2a0, (bRam000000000205c2a0 & 1) != 0)) {
                  lStack_2d0 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  lStack_2c8 = (ulonglong)*_DAT_ +
                               *(longlong *)(lStack_2d0 + (ulonglong)*_DAT_ * 8);
                  lStack_2c0 = *(longlong *)(lStack_2c8 + 8);
                  puVar16 = puStack_890;
                  if (lStack_2c0 == 0) {
                    lStack_528 = 0;
                  }
                  else {
                    lStack_528 = *(longlong *)(lStack_2c0 + 0x60);
                    if ((lStack_528 != 0) && (*(char *)(lStack_528 + 0x499) != '\0')) {
                      if ((cRam000000000204b88b == '\0') &&
                         (bStack_7fb = bRam000000000205c2a0 >> 1, (bStack_7fb & 1) == 0)) {
                        (*pcRam00000000015ba1c8)(0x22,0x44,0x15,0x3ec);
                        puVar16 = puStack_890;
                      }
                      else {
                        uStack_908 = (undefined8 *)0x0;
                        (*_DAT_)(1,0x193c3c8,0x1a5c098,0x81d);
                        puVar16 = puStack_890;
                      }
                    }
                  }
                }
                func_0x(pbStack_f0,4);
                uVar22 = (ulonglong)uStack_dc;
                pbVar20 = pbStack_f0;
                uVar15 = uStack_e8._4_4_;
                uVar18 = uStack_e0;
              }
              do {
                iVar4 = (int)uVar22;
                puStack_2b8 = puStack_6c8 + (ulonglong)(iVar4 - 1) + 1;
                if (-1 < (short)*puStack_2b8) break;
                pbStack_2b0 = pbVar20 + uVar15;
                uVar14 = uVar18;
                if (iVar4 != 1) {
                  uStack_6d0 = *(ushort *)(pbStack_2b0 + (longlong)(iVar4 + -2) * 2 + 2);
                  uVar14 = uStack_6d0 & 0x7fff;
                }
                uStack_6cc = *(ushort *)(pbStack_2b0 + (longlong)(iVar4 + -1) * 2 + 2);
                uStack_668 = uStack_6cc & 0x7fff;
                iStack_670 = iVar4;
                if ((uVar14 < uVar18) || (uStack_668 < uVar14)) {
                  func_0x(pbVar20,7);
                  uVar22 = (ulonglong)uStack_dc;
                  pbVar20 = pbStack_f0;
                  uVar15 = uStack_e8._4_4_;
                  uVar18 = uStack_e0;
                }
                uStack_664 = uVar14;
                if ((uVar14 < uVar18) || (uStack_f4 < uVar14)) {
                  iStack_898 = iStack_898 + 1;
                  goto code_r0x00101e97;
                }
                uStack_778 = *(ushort *)(pbVar20 + uVar14);
                if (uStack_778 == 5) {
                  *puVar16 = *puVar16 | 2;
                  puVar16[0xd] = puVar16[0xd] - 1;
                  puStack_2a8 = puVar16 + 0x14;
                  *puStack_2a8 = (ushort)uVar14;
                  lStack_2a0 = (ulonglong)(uVar14 & 0xffff) + *(longlong *)(puVar16 + 3);
                  uVar12 = *(ushort *)(lStack_2a0 + 2);
                  puVar16[0x15] = puVar16[0x15] & 0xc7ff;
                  if ((uVar12 & 0x4000) != 0) {
                    puVar16[0x15] = puVar16[0x15] | uVar12 & 0x3800;
                  }
                  puVar16[0x15] =
                       (puVar16[0x15] ^ *(ushort *)(lStack_2a0 + 2)) & 0x7ff ^ puVar16[0x15];
                  break;
                }
                if (uStack_778 < 0x400) break;
                uStack_f6 = uStack_f6 | 1;
                uStack_dc = (short)uVar22 - 1;
                uVar22 = (ulonglong)uStack_dc;
              } while (uStack_dc != 0);
            }
            ppbVar1 = (byte **)(puVar16 + 3);
            if ((**ppbVar1 & 0x40) == 0) {
              *(undefined4 *)(puVar16 + 0x12) = 0;
            }
            else {
              *(undefined4 *)(puVar16 + 0x12) = *(undefined4 *)(puVar16 + 1);
              *(int *)(puVar16 + 1) = *(int *)(puVar16 + 1) + 0xe;
              puStack_298 = (ulonglong *)func_0x(puVar16);
              uStack_520 = *puStack_298;
              uStack_774 = (ushort)(uStack_520 >> 0x30);
              if ((((uint)(int)(short)uStack_774 >> 1 ^ (int)(short)uStack_774) & 0x2000) != 0) {
                if ((uStack_520 & 0x4000000000000000) == 0) {
                  uStack_774 = uStack_774 & 0xdfff;
                }
                else {
                  uStack_774 = uStack_774 | 0x2000;
                }
              }
              if (uStack_774 == 0xfffc) {
                puStack_290 = &uStack_520;
                iVar11 = (int)((uStack_520 >> 0x20 & 0xffff) >> 5);
                iStack_660 = iVar11;
              }
              *(int *)(puVar16 + 1) = *(int *)(puVar16 + 1) + iVar11;
            }
            if ((*(byte **)(puVar16 + 0xe) != (byte *)0x0) &&
               (*(byte **)(puVar16 + 0xe) < *ppbVar1 + *(uint *)(puVar16 + 1))) {
              iStack_898 = iStack_898 + 1;
              if ((cRam000000000204b99b != '\0') ||
                 (bStack_7fa = bRam000000000205c2a0, (bRam000000000205c2a0 & 1) != 0)) {
                lStack_288 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                lStack_280 = (ulonglong)*_DAT_ +
                             *(longlong *)(lStack_288 + (ulonglong)*_DAT_ * 8);
                lStack_278 = *(longlong *)(lStack_280 + 8);
                puVar16 = puStack_890;
                if (lStack_278 == 0) {
                  lStack_518 = 0;
                }
                else {
                  lStack_518 = *(longlong *)(lStack_278 + 0x60);
                  if ((lStack_518 != 0) && (*(char *)(lStack_518 + 0x499) != '\0')) {
                    if ((cRam000000000204b88b == '\0') &&
                       (bStack_7f0 = bRam000000000205c2a0 >> 1, (bStack_7f0 & 1) == 0)) {
                      (*pcRam00000000015ba1c8)(0x22,0x44,0x15,0x3fa);
                      puVar16 = puStack_890;
                    }
                    else {
                      uStack_908 = (undefined8 *)0x0;
                      (*_DAT_)(1,0x193c3c8,0x1a5c098,0x877);
                      puVar16 = puStack_890;
                    }
                  }
                }
              }
              func_0x(*ppbVar1,0x12);
            }
            if (0x3f3b < *(int *)(puVar16 + 1) - 1U) {
              iStack_898 = iStack_898 + 1;
              if ((cRam000000000204b99b != '\0') ||
                 (bStack_820 = bRam000000000205c2a0, (bRam000000000205c2a0 & 1) != 0)) {
                lStack_270 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                lStack_268 = (ulonglong)*_DAT_ +
                             *(longlong *)(lStack_270 + (ulonglong)*_DAT_ * 8);
                lStack_260 = *(longlong *)(lStack_268 + 8);
                puVar16 = puStack_890;
                if (lStack_260 == 0) {
                  lStack_510 = 0;
                }
                else {
                  lStack_510 = *(longlong *)(lStack_260 + 0x60);
                  if ((lStack_510 != 0) && (*(char *)(lStack_510 + 0x499) != '\0')) {
                    if ((cRam000000000204b88b == '\0') &&
                       (bStack_81f = bRam000000000205c2a0 >> 1, (bStack_81f & 1) == 0)) {
                      (*pcRam00000000015ba1c8)(0x22,0x44,0x15,0x3ed);
                      puVar16 = puStack_890;
                    }
                    else {
                      uStack_908 = (undefined8 *)0x0;
                      (*_DAT_)(1,0x193c3c8,0x1a5c098,0x87c);
                      puVar16 = puStack_890;
                    }
                  }
                }
              }
              func_0x(*ppbVar1,5);
            }
          }
code_r0x00101e97:
          sStack_768 = -*(short *)puStack_840;
          if ((*(byte *)((longlong)puStack_840 + 6) & 0x10) != 0) {
            pbVar20 = *(byte **)(puVar16 + 3);
            if ((*pbVar20 & 0x10) == 0) {
              bStack_81e = *pbVar20 & 0xe;
              uVar15 = 1 << bStack_81e & 0x1105;
              uStack_7a4 = (uint)(uVar15 == 0);
              pbStack_258 = pbVar20;
              if (uVar15 != 0) {
code_r0x00101f64:
                piStack_6b8 = *(int **)(puStack_840 + 2) + 1;
                iStack_65c = **(int **)(puStack_840 + 2);
                iStack_894 = iStack_65c;
                piVar19 = piStack_6b8;
                piStack_6f0 = piStack_6b8;
                piStack_508 = piStack_6b8;
                piStack_250 = piStack_6b8;
                goto code_r0x0010221d;
              }
            }
            else {
              if (((int)*(uint *)(puVar16 + 7) <= (int)*puStack_840) ||
                 (*(ushort *)(pbVar20 + *(uint *)(puVar16 + 7)) < *(ushort *)(puStack_840 + 1))) {
                uStack_7a4 = 0;
                goto code_r0x00101f64;
              }
              uStack_7a4 = 1;
            }
          }
          uVar15 = (uint)sStack_768;
          if (puVar16[0xd] < uVar15) {
            iStack_894 = 0;
            piStack_6b8 = *(int **)(puVar16 + 3);
            piVar19 = piStack_6b8;
            piStack_6f0 = piStack_6b8;
            piStack_508 = piStack_6b8;
          }
          else {
            lStack_248 = (ulonglong)*(uint *)(puVar16 + 9) + *(longlong *)(puVar16 + 3);
            if (uVar15 == 1) {
              uVar18 = *(uint *)(puVar16 + 0xb);
            }
            else {
              uStack_700 = *(ushort *)(lStack_248 + 2 + (longlong)(int)(uVar15 - 2) * 2);
              uVar18 = uStack_700 & 0x7fff;
            }
            uStack_764 = *(ushort *)(lStack_248 + 2 + (longlong)(int)(uVar15 - 1) * 2);
            uVar14 = uStack_764 & 0x7fff;
            uStack_658 = uVar15;
            uStack_650 = uVar18;
            uStack_64c = uVar14;
            if ((uVar18 < *(uint *)(puVar16 + 0xb)) || (uVar14 < uVar18)) {
              func_0x(*(longlong *)(puVar16 + 3),7);
            }
            piStack_6b8 = (int *)((ulonglong)uVar18 + *(longlong *)(puVar16 + 3));
            iStack_894 = uVar14 - uVar18;
            piVar19 = piStack_6b8;
            piStack_6f0 = piStack_6b8;
            uStack_648 = uVar18;
            piStack_508 = piStack_6b8;
          }
        }
        else if ((uVar12 & 8) == 0) {
          if ((uVar12 & 0x10) == 0) {
code_r0x001014b4:
            iStack_894 = 6;
            piVar19 = (int *)(pbStack_f0 + (int)*puStack_840);
            piStack_6f0 = piVar19;
            piStack_540 = piVar19;
            piStack_508 = piVar19;
          }
          else {
            if ((*pbStack_f0 & 0x10) == 0) {
              bStack_812 = *pbStack_f0 & 0xe;
              uVar15 = 1 << bStack_812 & 0x1105;
              uStack_7a8 = (uint)(uVar15 == 0);
              pbStack_320 = pbStack_f0;
              if (uVar15 == 0) goto code_r0x001014b4;
            }
            else {
              if (((int)uVar18 < (int)uVar15) &&
                 (*(ushort *)(piStack_780 + 5) <= *(ushort *)(pbStack_f0 + uVar15))) {
                uStack_7a8 = 1;
                goto code_r0x001014b4;
              }
              uStack_7a8 = 0;
            }
            piVar19 = *(int **)(piStack_780 + 6) + 1;
            iStack_894 = **(int **)(piStack_780 + 6);
            piStack_6f0 = piVar19;
            piStack_540 = piVar19;
            piStack_508 = piVar19;
            iStack_4dc = iStack_894;
            piStack_318 = piVar19;
            if (iStack_894 != 6) {
              uStack_908 = (undefined8 *)0x0;
              (*_DAT_)(1,0x1aea138,0x1ae8b38,0x381);
            }
          }
        }
        else {
          pbStack_310 = pbStack_f0 + (int)uVar18;
          piStack_308 = (int *)0x16c0e04;
          if ((*pbStack_310 & (byte)(1 << ((byte)uVar12 & 7))) == 0) {
            piStack_308 = (int *)0x16c1428;
          }
          iStack_894 = 1;
          piVar19 = piStack_308;
          piStack_6f0 = piStack_308;
          piStack_508 = piStack_308;
        }
      }
      else {
        if ((*pbStack_f0 & 0x10) == 0) {
          bStack_813 = *pbStack_f0 & 0xe;
          uVar14 = 1 << bStack_813 & 0x1105;
          uStack_858 = (uint)(uVar14 == 0);
          pbStack_330 = pbStack_f0;
          if (uVar14 == 0) goto code_r0x0010145e;
        }
        else {
          if (((int)uVar18 < (int)uVar15) &&
             (*(ushort *)(piStack_780 + 5) <= *(ushort *)(pbStack_f0 + uVar15)))
          goto code_r0x0010144c;
          uStack_858 = 0;
        }
        piStack_328 = *(int **)(piStack_780 + 6) + 1;
        iStack_4e0 = **(int **)(piStack_780 + 6);
        iStack_894 = iStack_4e0;
        piVar19 = piStack_328;
        piStack_6f0 = piStack_328;
        piStack_508 = piStack_328;
      }
    }
  }
  else {
    uStack_7b0 = 0;
    uStack_908 = (undefined8 *)&uStack_7b0;
    piStack_6b0 = (int *)func_0x(&uStack_f6,puStack_840);
    piVar19 = piStack_780;
    piStack_508 = piStack_6b0;
    if (((uStack_f8 == 0) || (plStack_240 = uStack_e8, uStack_e8 == (longlong *)0x0)) ||
       (plStack_238 = uStack_e8, *uStack_e8 == 0)) {
      uStack_7ac = 0;
    }
    else {
      uStack_7ac = 1;
      if (((*(byte *)((longlong)puStack_840 + 6) & 8) == 0) && ((uStack_7b0 & 1) == 0)) {
        iStack_640 = iStack_894;
        plStack_228 = uStack_e8;
        uStack_638 = uStack_7b0;
        piStack_230 = piStack_6b0;
        if ((piStack_6b0 == (int *)0x0) || (piStack_6b0 == (int *)0x16c0e04)) {
          iStack_894 = 0;
          piStack_6b0 = (int *)0x0;
          piStack_508 = piStack_6b0;
        }
        else {
          uStack_8f0 = (undefined4 *)CONCAT44(uStack_8f0._4_4_,uStack_7b0);
          uStack_8f8 = &iStack_894;
          uStack_900 = 6;
          uStack_908 = &uStack_48;
          piStack_6b0 = (int *)func_0x(uStack_e8,puStack_840,piStack_6b0);
          piVar19 = piStack_780;
          piStack_508 = piStack_6b0;
        }
      }
    }
  }
code_r0x0010221d:
  piStack_780 = piVar19;
  lVar13 = lStack_7f8;
  uStack_8a0 = 0;
  uStack_8a8 = 0;
  uStack_8b0 = 0;
  uStack_8b8 = 0;
  uStack_8c0 = 0;
  uStack_8c8 = 0;
  uStack_8d0 = 0;
  uStack_8d8 = *(undefined8 *)(lStack_7f8 + 0x110);
  uStack_8e0 = 0;
  uStack_8e8 = *(undefined4 *)(lStack_7f8 + 0x100);
  uStack_8f0 = &uStack_854;
  uStack_8f8 = (int *)CONCAT44(uStack_8f8._4_4_,6);
  uStack_900 = 6;
  uStack_908 = (undefined8 *)CONCAT44(uStack_908._4_4_,(int)piStack_508 - (int)pbStack_f0);
  iStack_630 = func_0x(pplStack_838,lStack_828,&uStack_7c0,param_6);
  if (iStack_630 != 0) {
    uStack_908 = (undefined8 *)0x0;
    (*_DAT_)(1,0x1ae9ea0,0x1ac06b8,0xcb2);
  }
  uStack_908 = &uStack_4d8;
  func_0x(lVar13,pplStack_848,&uStack_6a8,&uStack_6a8);
  func_0x(&uStack_6a8);
code_r0x0010233a:
  func_0x(&uStack_4d8);
  func_0x(lVar13);
  lVar17 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar13 = *(longlong *)(lVar17 + 0x100);
  if (lVar13 == 0) {
    (*_DAT_)();
    lVar13 = *(longlong *)(lVar17 + 0x100);
  }
  if (*(int *)(lVar13 + 0x22c) != 0) {
    (*_DAT_)();
  }
  func_0x(&lStack_7d8);
  func_0x(uStack_40 ^ (ulonglong)auStack_928);
  return;
}

