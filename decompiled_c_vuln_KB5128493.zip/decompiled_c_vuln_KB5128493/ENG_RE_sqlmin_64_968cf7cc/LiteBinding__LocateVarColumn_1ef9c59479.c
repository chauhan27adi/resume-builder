// NOTE: 2 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 param_1,byte *param_2)

{
  longlong lVar1;
  
  if ((*param_2 & 1) == 0) {
    lVar1 = (longlong)(int)(*param_2 & 0xe);
                    /* WARNING: Could not emulate address calculation at 0x0010006d */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)(lVar1 * 4 + 0xfffb8) - 0xb4f40))
              (lVar1,0xfffffffffff4b0c0,3,param_2);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

