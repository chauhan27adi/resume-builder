
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,undefined8 param_3)

{
  byte bVar1;
  undefined2 uVar2;
  short sVar3;
  ushort uVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined4 uVar8;
  longlong lVar9;
  longlong lVar10;
  longlong *plVar11;
  short *psVar12;
  ulonglong uVar13;
  uint *puVar14;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar15;
  byte *pbVar16;
  int iVar17;
  ulonglong uVar18;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  *(undefined8 *)(&stack0x00000228 + lVar9) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00008ea8 + lVar9) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9);
  *(longlong *)(&stack0x00000030 + lVar9) = param_2;
  *(undefined8 *)(&stack0x00000108 + lVar9) = param_1;
  *(undefined8 *)(&stack0x00000120 + lVar9) = param_1;
  *(undefined8 *)(&stack0x000001b0 + lVar9) = param_1;
  *(longlong *)(&stack0x00000178 + lVar9) = param_2;
  *(undefined8 *)(&stack0x000001b8 + lVar9) = param_3;
  uVar13 = 0;
  *(undefined8 *)(&stack0x00000040 + lVar9) = 0;
  lVar15 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar10 = *(longlong *)(lVar15 + 0x100);
  if (lVar10 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000a4;
    (*_DAT_)(0);
    lVar10 = *(longlong *)(lVar15 + 0x100);
  }
  plVar11 = *(longlong **)(lVar10 + 1000);
  *(longlong **)(&stack0x000042d8 + lVar9) = plVar11;
  *(undefined4 *)(&stack0x000042e0 + lVar9) = 0;
  *(undefined4 *)(&stack0x000042e8 + lVar9) = 0;
  *(undefined4 *)(&stack0x000042ec + lVar9) = 0xffffffff;
  *(undefined8 *)(&stack0x000042f0 + lVar9) = 0;
  *(undefined4 *)(&stack0x000042f8 + lVar9) = _DAT_;
  *(undefined2 *)(&stack0x000042fc + lVar9) = _DAT_;
  *(undefined4 *)(&stack0x000042fe + lVar9) = 0;
  *(undefined2 *)(&stack0x00004302 + lVar9) = 0;
  *(undefined8 *)(&stack0x00004304 + lVar9) = 0;
  *(undefined (*) [16])(&stack0x00004310 + lVar9) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00004320 + lVar9) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00004330 + lVar9) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00004340 + lVar9) = ZEXT816(0);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100145;
  func_0x(&stack0x00004350 + lVar9);
  *(undefined2 *)(&stack0x000043d0 + lVar9) = 0xffff;
  *(undefined8 *)(&stack0x000043d8 + lVar9) = 0;
  *(undefined4 *)(&stack0x000043d4 + lVar9) = 0;
  *(undefined8 *)(&stack0x000043ee + lVar9) = 0;
  *(undefined8 *)(&stack0x000043f8 + lVar9) = 0;
  *(undefined8 *)(&stack0x000043e0 + lVar9) = 0;
  *(undefined4 *)(&stack0x00004404 + lVar9) = 0xffffffff;
  *(undefined8 *)(&stack0x00004480 + lVar9) = 0;
  *(undefined4 *)(&stack0x00004488 + lVar9) = 0;
  *(undefined4 *)(&stack0x00004490 + lVar9) = 0;
  *(undefined (*) [16])(&stack0x00004498 + lVar9) = ZEXT816(0);
  *(undefined4 *)(&stack0x000044a8 + lVar9) = 0;
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar11 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001b7;
  (*UNRECOVERED_JUMPTABLE_00)(plVar11);
  if (param_2 == 0) {
    if (*(longlong *)(&stack0x00004348 + lVar9) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001d0;
      lVar10 = func_0x();
      *(undefined8 *)(lVar10 + 0x110) = 0;
      if (*(longlong *)(&stack0x00004348 + lVar9) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001f1;
        func_0x(*(longlong *)(&stack0x00004348 + lVar9),1);
      }
      *(undefined8 *)(&stack0x00004348 + lVar9) = 0;
    }
    lVar10 = *(longlong *)(&stack0x00004330 + lVar9);
    if (lVar10 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100216;
      func_0x(lVar10);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100224;
      (*_DAT_)(lVar10,0xc0);
      *(undefined (*) [16])(&stack0x00004330 + lVar9) = ZEXT816(0);
      *(undefined8 *)(&stack0x00004340 + lVar9) = 0;
    }
    if (*(longlong **)(&stack0x00004320 + lVar9) != (longlong *)0x0) {
      UNRECOVERED_JUMPTABLE_00 = *(code **)(**(longlong **)(&stack0x00004320 + lVar9) + 0x118);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10024e;
      (*UNRECOVERED_JUMPTABLE_00)();
      *(undefined8 *)(&stack0x00004320 + lVar9) = 0;
      *(undefined8 *)(&stack0x00004318 + lVar9) = 0;
    }
    puVar5 = *(undefined8 **)(&stack0x00004310 + lVar9);
    if (puVar5 != (undefined8 *)0x0) {
      UNRECOVERED_JUMPTABLE_00 = *(code **)*puVar5;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100273;
      (*UNRECOVERED_JUMPTABLE_00)(puVar5,1);
      *(undefined8 *)(&stack0x00004310 + lVar9) = 0;
    }
    if (*(longlong **)(&stack0x000042d8 + lVar9) != (longlong *)0x0) {
      UNRECOVERED_JUMPTABLE_00 = *(code **)(**(longlong **)(&stack0x000042d8 + lVar9) + 0x10);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10028e;
      (*UNRECOVERED_JUMPTABLE_00)();
      *(undefined8 *)(&stack0x000042d8 + lVar9) = 0;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002a3;
    func_0x(&stack0x00004350 + lVar9);
  }
  else {
    plVar11 = *(longlong **)(&stack0x00000040 + lVar9);
    if (plVar11 == (longlong *)0x0) {
      UNRECOVERED_JUMPTABLE_00 = **(code ***)*_DAT_;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002c2;
      plVar11 = (longlong *)(*UNRECOVERED_JUMPTABLE_00)();
      plVar6 = *(longlong **)(&stack0x00000040 + lVar9);
      if ((plVar6 == plVar11) || (plVar6 == (longlong *)0x0)) {
        *(longlong **)(&stack0x00000040 + lVar9) = plVar11;
      }
      else {
        UNRECOVERED_JUMPTABLE_00 = *(code **)*plVar6;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002e2;
        (*UNRECOVERED_JUMPTABLE_00)(plVar6,1);
        *(longlong **)(&stack0x00000040 + lVar9) = plVar11;
      }
    }
    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar11 + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100312;
    (*UNRECOVERED_JUMPTABLE_00)(plVar11,0x1363a60,0x10);
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = _DAT_;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100339;
    func_0x(&stack0x000002d8 + lVar9,0,0,0);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100357;
    uVar8 = func_0x(&stack0x000042d8 + lVar9,*(undefined8 *)(&stack0x000001b8 + lVar9),
                            &stack0x00000040 + lVar9,param_1);
    *(undefined4 *)(&stack0x00000128 + lVar9) = uVar8;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10036b;
    func_0x(&stack0x000002d8 + lVar9);
    lVar15 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar10 = *(longlong *)(lVar15 + 0x100);
    if (lVar10 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003c6;
      (*_DAT_)();
      lVar10 = *(longlong *)(lVar15 + 0x100);
    }
    if (*(int *)(lVar10 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003dc;
      (*_DAT_)();
    }
    if (*(int *)(&stack0x00000128 + lVar9) != 0) {
      lVar10 = *(longlong *)(&stack0x00000108 + lVar9);
      if (*(char *)(lVar10 + 2) < '\0') {
        *(undefined (*) [16])(&stack0x000044c8 + lVar9) = ZEXT816(0);
        *(undefined2 *)(&stack0x000044d8 + lVar9) = 0xffff;
        *(undefined8 *)(&stack0x000044e0 + lVar9) = 0;
        *(undefined4 *)(&stack0x000044dc + lVar9) = 0;
        *(undefined8 *)(&stack0x000044f6 + lVar9) = 0;
        *(undefined8 *)(&stack0x00004500 + lVar9) = 0;
        *(undefined8 *)(&stack0x000044e8 + lVar9) = 0;
        *(undefined8 *)(&stack0x00004510 + lVar9) = 0;
        *(undefined8 *)(&stack0x00004528 + lVar9) = 0;
        *(undefined4 *)(&stack0x00004530 + lVar9) = 0;
        *(undefined2 *)(&stack0x0000453a + lVar9) = 0;
        pbVar16 = (byte *)(lVar10 + 0x60);
        if ((((pbVar16 == (byte *)0x0) && (*(short *)(lVar10 + 0x30) == 0)) &&
            (*(int *)(lVar10 + 0x28) == 0)) &&
           (((*(int *)(lVar10 + 0x2c) == 0 &&
             (*(int *)(lVar10 + 0x20) == *(int *)(&stack0x00004534 + lVar9))) &&
            (*(short *)(lVar10 + 0x24) == *(short *)(&stack0x00004538 + lVar9))))) {
          *(undefined4 *)(&stack0x00000038 + lVar9) = 2;
          *(undefined4 *)(&stack0x0000002c + lVar9) = 9;
        }
        else {
          *(byte **)(&stack0x000044c8 + lVar9) = pbVar16;
          uVar2 = *(undefined2 *)(lVar10 + 0x30);
          uVar8 = *(undefined4 *)(lVar10 + 0x2c);
          *(undefined4 *)(&stack0x00004528 + lVar9) = *(undefined4 *)(lVar10 + 0x28);
          *(undefined4 *)(&stack0x0000452c + lVar9) = uVar8;
          *(undefined2 *)(&stack0x00004530 + lVar9) = uVar2;
          *(undefined4 *)(&stack0x00004534 + lVar9) = *(undefined4 *)(lVar10 + 0x20);
          *(undefined2 *)(&stack0x00004538 + lVar9) = *(undefined2 *)(lVar10 + 0x24);
          bVar1 = *pbVar16;
          *(undefined4 *)(&stack0x00000114 + lVar9) =
               *(undefined4 *)((ulonglong)bVar1 * 6 + 0x1129610);
          uVar18 = (ulonglong)*(short *)((ulonglong)bVar1 * 6 + 0x1129614);
          *(undefined8 *)(&stack0x00004518 + lVar9) = 0;
          *(undefined2 *)(&stack0x00004520 + lVar9) = 0;
          if ((bVar1 & 2) != 0) {
            pbVar16 = pbVar16 + uVar18;
            bVar1 = *pbVar16;
            *(byte **)(&stack0x000044e0 + lVar9) = pbVar16;
            if ((bVar1 & 1) == 0) {
              *(undefined2 *)(&stack0x000044d8 + lVar9) = 0;
              *(undefined4 *)(&stack0x000044fe + lVar9) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100849 */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar16 & 0xe) * 4 + 0x1061b4) -
                        0x1410820))();
              return;
            }
            *(undefined2 *)(&stack0x000044d8 + lVar9) = 1;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)
                                    *(byte *)((longlong)(int)(*pbVar16 & 0x1c) + 0x106194) * 4 +
                                   0x106184) - 0x1410820);
                    /* WARNING: Could not emulate address calculation at 0x0010063d */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          *(undefined4 *)(&stack0x00000038 + lVar9) = 2;
          *(undefined4 *)(&stack0x0000002c + lVar9) = 9;
          if ((**(byte **)(&stack0x000044c8 + lVar9) & 4) != 0) {
            if (*(short *)(&stack0x00000116 + lVar9) != 0) {
              uVar18 = (ulonglong)
                       *(ushort *)
                        (lVar10 + 0x61 + (longlong)*(short *)(&stack0x00000116 + lVar9) * 2);
            }
            psVar12 = (short *)(pbVar16 + uVar18);
            *(short **)(&stack0x00004510 + lVar9) = psVar12;
            sVar3 = *psVar12;
            *(short **)(&stack0x00004518 + lVar9) = psVar12 + 1;
            *(short *)(&stack0x00004520 + lVar9) = (sVar3 + 1) * 2;
          }
          if (*(longlong *)(&stack0x000044d0 + lVar9) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100924;
            func_0x
                      (*(longlong *)(&stack0x000044d0 + lVar9),&stack0x000044c8 + lVar9);
          }
          param_2 = *(longlong *)(&stack0x00000030 + lVar9);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10093c;
        func_0x(&stack0x000044c8 + lVar9,1,param_2);
        lVar10 = *(longlong *)(&stack0x00000108 + lVar9);
      }
      else {
        *(undefined4 *)(&stack0x00000038 + lVar9) = 2;
        *(undefined4 *)(&stack0x0000002c + lVar9) = 9;
      }
      *(undefined4 *)(&stack0x00000028 + lVar9) = 0;
      uVar4 = *(ushort *)(lVar10 + 0x16);
      if ((ulonglong)uVar4 != 0) {
        psVar12 = (short *)(lVar10 + 0x1ffe);
        uVar18 = uVar13;
        do {
          iVar17 = (int)uVar18;
          if (*psVar12 != 0) goto LAB_;
          uVar18 = (ulonglong)(iVar17 + 1U);
          *(uint *)(&stack0x00000028 + lVar9) = iVar17 + 1U;
          uVar13 = uVar13 + 1;
          psVar12 = psVar12 + -1;
        } while ((longlong)uVar13 < (longlong)(ulonglong)uVar4);
      }
      iVar17 = -1;
      *(undefined4 *)(&stack0x00000028 + lVar9) = 0xffffffff;
LAB_:
      *(int *)(&stack0x00000110 + lVar9) = iVar17;
      if (iVar17 != -1) {
        *(undefined4 *)(&stack0x0000012c + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1009bd;
        lVar15 = func_0x();
        if (lVar15 != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1009c7;
          lVar15 = func_0x();
          puVar14 = (uint *)(lVar15 + 0x18);
          if (lVar15 == 0) {
            puVar14 = (uint *)0x4;
          }
          if ((*puVar14 >> 1 & 1) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1009ed;
            func_0x(&stack0x000042d8 + lVar9,lVar10,iVar17);
            goto LAB_;
          }
        }
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = _DAT_;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a18;
        func_0x(&stack0x00000300 + lVar9,0,0,0);
        *(undefined8 *)(&stack0x00000230 + lVar9) = _DAT_;
        lVar15 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar10 = *(longlong *)(lVar15 + 0x100);
        if (lVar10 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a59;
          (*_DAT_)();
          lVar10 = *(longlong *)(lVar15 + 0x100);
        }
        uVar7 = *(undefined8 *)(lVar10 + 0xc88);
        *(undefined8 *)(&stack0x000001a8 + lVar9) = uVar7;
        *(undefined8 *)(lVar10 + 0xc88) = _DAT_;
        *(undefined8 *)(&stack0x00000238 + lVar9) = uVar7;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a9d;
        func_0x(&stack0x000042d8 + lVar9,*(undefined8 *)(&stack0x00000108 + lVar9),iVar17);
        lVar15 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar10 = *(longlong *)(lVar15 + 0x100);
        if (lVar10 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100acf;
          (*_DAT_)();
          lVar10 = *(longlong *)(lVar15 + 0x100);
        }
        *(undefined8 *)(&stack0x00000240 + lVar9) = *(undefined8 *)(&stack0x000001a8 + lVar9);
        *(undefined8 *)(lVar10 + 0xc88) = *(undefined8 *)(&stack0x000001a8 + lVar9);
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100afa;
        func_0x(&stack0x00000300 + lVar9);
        lVar15 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar10 = *(longlong *)(lVar15 + 0x100);
        if (lVar10 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b79;
          (*_DAT_)();
          lVar10 = *(longlong *)(lVar15 + 0x100);
        }
        if (*(int *)(lVar10 + 0x22c) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b8f;
          (*_DAT_)();
        }
LAB_:
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100ba2;
        (*_DAT_)(&stack0x00004578 + lVar9);
        *(undefined2 *)(&stack0x00000050 + lVar9) = 0xffff;
        *(undefined8 *)(&stack0x00000058 + lVar9) = 0;
        *(undefined4 *)(&stack0x00000054 + lVar9) = 0;
        *(undefined8 *)(&stack0x0000006e + lVar9) = 0;
        *(undefined8 *)(&stack0x00000078 + lVar9) = 0;
        *(undefined8 *)(&stack0x00000060 + lVar9) = 0;
        lVar10 = *(longlong *)(&stack0x00000108 + lVar9);
        pbVar16 = (byte *)((ulonglong)*(ushort *)(lVar10 + (0xfff - (longlong)iVar17) * 2) + lVar10)
        ;
        bVar1 = *pbVar16;
        *(byte **)(&stack0x00000058 + lVar9) = pbVar16;
        if ((bVar1 & 1) == 0) {
          *(undefined2 *)(&stack0x00000050 + lVar9) = 0;
          *(undefined4 *)(&stack0x00000076 + lVar9) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100e18 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar16 & 0xe) * 4 + 0x106220) -
                    0x1410820))(lVar10,(longlong)(int)(*pbVar16 & 0xe),0);
          return;
        }
        *(undefined2 *)(&stack0x00000050 + lVar9) = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar16 & 0x1c) + 0x106200) *
                                4 + 0x1061f0) - 0x1410820);
                    /* WARNING: Could not emulate address calculation at 0x00100c20 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x106063;
      (*_DAT_)(param_2);
      if (*(longlong *)(&stack0x00004348 + lVar9) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x106075;
        lVar10 = func_0x();
        *(undefined8 *)(lVar10 + 0x110) = 0;
        if (*(longlong *)(&stack0x00004348 + lVar9) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x106091;
          func_0x(*(longlong *)(&stack0x00004348 + lVar9),1);
        }
        *(undefined8 *)(&stack0x00004348 + lVar9) = 0;
      }
      lVar10 = *(longlong *)(&stack0x00004330 + lVar9);
      if (lVar10 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1060ae;
        func_0x(lVar10);
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1060bc;
        (*_DAT_)(lVar10,0xc0);
        *(undefined (*) [16])(&stack0x00004330 + lVar9) = ZEXT816(0);
        *(undefined8 *)(&stack0x00004340 + lVar9) = 0;
      }
      if (*(longlong **)(&stack0x00004320 + lVar9) != (longlong *)0x0) {
        UNRECOVERED_JUMPTABLE_00 = *(code **)(**(longlong **)(&stack0x00004320 + lVar9) + 0x118);
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1060e6;
        (*UNRECOVERED_JUMPTABLE_00)();
        *(undefined8 *)(&stack0x00004320 + lVar9) = 0;
        *(undefined8 *)(&stack0x00004318 + lVar9) = 0;
      }
      puVar5 = *(undefined8 **)(&stack0x00004310 + lVar9);
      if (puVar5 != (undefined8 *)0x0) {
        UNRECOVERED_JUMPTABLE_00 = *(code **)*puVar5;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10610b;
        (*UNRECOVERED_JUMPTABLE_00)(puVar5,1);
        *(undefined8 *)(&stack0x00004310 + lVar9) = 0;
      }
      if (*(longlong **)(&stack0x000042d8 + lVar9) != (longlong *)0x0) {
        UNRECOVERED_JUMPTABLE_00 = *(code **)(**(longlong **)(&stack0x000042d8 + lVar9) + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x106126;
        (*UNRECOVERED_JUMPTABLE_00)();
        *(undefined8 *)(&stack0x000042d8 + lVar9) = 0;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10613b;
      func_0x(&stack0x00004350 + lVar9);
      puVar5 = *(undefined8 **)(&stack0x00000040 + lVar9);
      if (puVar5 != (undefined8 *)0x0) {
        UNRECOVERED_JUMPTABLE_00 = *(code **)*puVar5;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10614e;
        (*UNRECOVERED_JUMPTABLE_00)(puVar5,1);
      }
      goto LAB_;
    }
    if (*(longlong *)(&stack0x00004348 + lVar9) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003fa;
      lVar10 = func_0x();
      *(undefined8 *)(lVar10 + 0x110) = 0;
      if (*(longlong *)(&stack0x00004348 + lVar9) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100416;
        func_0x(*(longlong *)(&stack0x00004348 + lVar9),1);
      }
      *(undefined8 *)(&stack0x00004348 + lVar9) = 0;
    }
    lVar10 = *(longlong *)(&stack0x00004330 + lVar9);
    if (lVar10 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100433;
      func_0x(lVar10);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100441;
      (*_DAT_)(lVar10,0xc0);
      *(undefined (*) [16])(&stack0x00004330 + lVar9) = ZEXT816(0);
      *(undefined8 *)(&stack0x00004340 + lVar9) = 0;
    }
    if (*(longlong **)(&stack0x00004320 + lVar9) != (longlong *)0x0) {
      UNRECOVERED_JUMPTABLE_00 = *(code **)(**(longlong **)(&stack0x00004320 + lVar9) + 0x118);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10046b;
      (*UNRECOVERED_JUMPTABLE_00)();
      *(undefined8 *)(&stack0x00004320 + lVar9) = 0;
      *(undefined8 *)(&stack0x00004318 + lVar9) = 0;
    }
    puVar5 = *(undefined8 **)(&stack0x00004310 + lVar9);
    if (puVar5 != (undefined8 *)0x0) {
      UNRECOVERED_JUMPTABLE_00 = *(code **)*puVar5;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100490;
      (*UNRECOVERED_JUMPTABLE_00)(puVar5,1);
      *(undefined8 *)(&stack0x00004310 + lVar9) = 0;
    }
    if (*(longlong **)(&stack0x000042d8 + lVar9) != (longlong *)0x0) {
      UNRECOVERED_JUMPTABLE_00 = *(code **)(**(longlong **)(&stack0x000042d8 + lVar9) + 0x10);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004ab;
      (*UNRECOVERED_JUMPTABLE_00)();
      *(undefined8 *)(&stack0x000042d8 + lVar9) = 0;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004c0;
    func_0x(&stack0x00004350 + lVar9);
  }
  puVar5 = *(undefined8 **)(&stack0x00000040 + lVar9);
  if (puVar5 != (undefined8 *)0x0) {
    UNRECOVERED_JUMPTABLE_00 = *(code **)*puVar5;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x105439;
    (*UNRECOVERED_JUMPTABLE_00)(puVar5,1);
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x106160;
  func_0x
            (*(ulonglong *)(&stack0x00008ea8 + lVar9) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar9));
  return;
}

