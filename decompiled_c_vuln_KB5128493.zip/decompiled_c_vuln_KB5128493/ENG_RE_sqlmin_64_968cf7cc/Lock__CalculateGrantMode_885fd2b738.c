
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,undefined8 param_2,int param_3)

{
  ulonglong uVar1;
  ulonglong uVar2;
  uint uVar3;
  int iVar4;
  
  uVar3 = 0;
  if (param_3 == 0) {
    uVar3 = *_DAT_;
    uVar2 = func_0x();
    uVar3 = (uint)((uVar2 & 0xffffffff) % (ulonglong)uVar3) >> ((byte)_DAT_ & 0x1f) & 3;
  }
  iVar4 = 0;
  uVar2 = (ulonglong)uVar3;
  do {
    if (*(longlong *)(param_1 + 0x10 + uVar2 * 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar1 = uVar2 + 1;
    iVar4 = iVar4 + 1;
    uVar2 = 0;
    if ((longlong)uVar1 < 4) {
      uVar2 = uVar1;
    }
  } while (iVar4 < 4);
  return 0;
}

