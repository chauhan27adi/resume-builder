
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,int param_2,undefined4 param_3)

{
  undefined auStack_268 [136];
  undefined8 uStack_1e0;
  ulonglong uStack_38;
  
  uStack_1e0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_268;
  if (param_2 == 0xc) {
    func_0x(param_1,param_3);
    func_0x(uStack_38 ^ (ulonglong)auStack_268);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

