
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,undefined8 param_3,short *param_4)

{
  ushort *puVar1;
  ushort uVar2;
  code *pcVar3;
  uint *puVar4;
  byte *pbVar5;
  undefined *puVar6;
  char cVar7;
  char cVar8;
  short sVar9;
  undefined2 uVar10;
  int iVar11;
  undefined4 uVar12;
  int iVar13;
  longlong lVar14;
  ulonglong *puVar15;
  longlong *plVar16;
  uint *puVar17;
  longlong lVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  undefined8 *puVar21;
  ushort *puVar22;
  short *psVar23;
  longlong lVar24;
  byte bVar25;
  byte bVar26;
  undefined8 uVar27;
  uint uVar28;
  uint uVar29;
  longlong lVar30;
  byte *pbVar31;
  longlong *plVar32;
  byte **ppbVar33;
  longlong lVar34;
  uint uVar35;
  undefined4 *puVar36;
  ushort *puVar37;
  longlong lVar38;
  longlong lVar39;
  ushort uVar40;
  byte *pbVar41;
  ulonglong uVar42;
  byte **ppbVar43;
  ulonglong uVar44;
  longlong unaff_GS_OFFSET;
  longlong alStackX_8 [2];
  longlong alStackX_18 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  *(undefined8 *)(&stack0x00000918 + lVar14) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002c98 + lVar14) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar14);
  *(short **)(&stack0x00000070 + lVar14) = param_4;
  *(undefined8 *)(&stack0x00000180 + lVar14) = param_3;
  *(undefined8 *)(&stack0x00000130 + lVar14) = param_2;
  *(longlong **)(&stack0x00000168 + lVar14) = param_1;
  lVar34 = *(longlong *)(&stack0x00002d08 + lVar14);
  *(longlong *)(&stack0x000001c8 + lVar14) = lVar34;
  *(undefined8 *)(&stack0x00000178 + lVar14) = *(undefined8 *)(&stack0x00002d10 + lVar14);
  *(undefined8 *)(&stack0x00000058 + lVar14) = *(undefined8 *)(&stack0x00002d18 + lVar14);
  *(undefined8 *)(&stack0x00000258 + lVar14) = *(undefined8 *)(&stack0x00002d30 + lVar14);
  *(undefined8 *)(&stack0x00000078 + lVar14) = *(undefined8 *)(&stack0x00002d38 + lVar14);
  *(undefined4 *)(&stack0x00000038 + lVar14) = 0;
  lVar30 = param_1[6];
  *(longlong *)(&stack0x00000188 + lVar14) = lVar30;
  *(undefined8 *)(&stack0x00000460 + lVar14) = *(undefined8 *)(&stack0x00002d38 + lVar14);
  *(undefined8 *)(&stack0x00000140 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000494 + lVar14) = 0;
  puVar22 = (ushort *)(param_4 + 1);
  *(ushort **)(&stack0x00000110 + lVar14) = puVar22;
  if (*param_4 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1000fb;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100102;
    func_0x(puVar22,&stack0x00000160 + lVar14);
  }
  *(int *)(&stack0x000001f0 + lVar14) = *(int *)(&stack0x00000160 + lVar14);
  *(short *)(&stack0x000001f4 + lVar14) = *(short *)(&stack0x00000164 + lVar14);
  sVar9 = *param_4;
  if (sVar9 == 0) {
    bVar25 = **(byte **)(param_4 + 4) >> 6;
  }
  else {
    bVar25 = **(byte **)(param_4 + 4) >> 1;
  }
  *(uint *)(&stack0x00000468 + lVar14) = bVar25 & 1;
  if ((bVar25 & 1) != 0) {
    *(undefined4 *)(&stack0x000001d8 + lVar14) = 0;
    *(undefined2 *)(&stack0x000001dc + lVar14) = 0;
    if ((*(short *)(&stack0x00000164 + lVar14) != 0) || (*(int *)(&stack0x00000160 + lVar14) != 0))
    {
      if (sVar9 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100181;
        func_0x();
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100188;
        func_0x(puVar22,&stack0x00000230 + lVar14);
      }
      *(undefined **)(&stack0x00000928 + lVar14) = &stack0x00000230 + lVar14;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1001b4;
      iVar11 = func_0x(lVar30 + 0x19c8,&stack0x000001f0 + lVar14,&stack0x00000230 + lVar14);
      if (iVar11 != 0) {
        if (*(char *)(lVar30 + 0x2050) != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1001d9;
          func_0x(0x298,10,3);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1001e5;
          func_0x();
        }
        if (*param_4 == 0) {
          *(ushort **)(&stack0x00000040 + lVar14) = puVar22;
          puVar17 = (uint *)(param_4 + 2);
          *(uint **)(&stack0x00000060 + lVar14) = puVar17;
          puVar37 = puVar22;
          if (*puVar17 == 0) {
            *(undefined4 *)(&stack0x0000002c + lVar14) = 0;
            *puVar22 = 0;
            uVar28 = *(uint *)(param_4 + 8);
            puVar4 = (uint *)(param_4 + 10);
            *puVar4 = uVar28;
            ppbVar33 = (byte **)(param_4 + 4);
            pbVar41 = *ppbVar33;
            if ((*pbVar41 & 0x10) != 0) {
              uVar28 = uVar28 + 2 + (*(ushort *)(pbVar41 + *(uint *)(param_4 + 8)) + 7 >> 3);
              *puVar4 = uVar28;
              pbVar41 = *ppbVar33;
            }
            if ((*pbVar41 & 0x20) == 0) {
              *puVar17 = uVar28;
              param_4[0xe] = 0;
              *(uint *)(param_4 + 0xc) = *puVar4;
            }
            else {
              *(byte **)(&stack0x00000278 + lVar14) = pbVar41 + uVar28;
              uVar40 = *(ushort *)(pbVar41 + uVar28);
              puVar1 = (ushort *)(param_4 + 0xe);
              *puVar1 = uVar40;
              if (uVar40 == 0) {
                *(undefined4 *)(&stack0x0000002c + lVar14) = 1;
                if ((DAT_ != '\0') ||
                   ((&stack0x000000a1)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                  *(undefined4 *)(&stack0x0000046c + lVar14) = 0x58;
                  lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000930 + lVar14) = lVar30;
                  lVar30 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x00000938 + lVar14) = lVar30;
                  *(longlong *)(&stack0x000009c8 + lVar14) = lVar30;
                  lVar30 = *(longlong *)(lVar30 + 8);
                  *(longlong *)(&stack0x00000920 + lVar14) = lVar30;
                  *(longlong *)(&stack0x00000940 + lVar14) = lVar30;
                  if (lVar30 == 0) {
                    *(undefined8 *)(&stack0x000003a8 + lVar14) = 0;
                  }
                  else {
                    lVar30 = *(longlong *)(lVar30 + 0x60);
                    *(longlong *)(&stack0x000003a8 + lVar14) = lVar30;
                    if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                      if ((DAT_ == '\0') &&
                         ((&stack0x000000c8)[lVar14] = DAT_ >> 1,
                         (DAT_ >> 1 & 1) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100346;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10036c;
                        (*_DAT_)(1,0x1517798,0x1637468,0x80f);
                      }
                    }
                  }
                  puVar22 = *(ushort **)(&stack0x00000040 + lVar14);
                }
                pbVar41 = *ppbVar33;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100389;
                func_0x(pbVar41,3);
              }
              uVar28 = *puVar4 + (*puVar1 + 1) * 2;
              puVar17 = (uint *)(puVar22 + 0xb);
              *puVar17 = uVar28;
              if (0x1f9e < uVar28) {
                *(int *)(&stack0x0000002c + lVar14) = *(int *)(&stack0x0000002c + lVar14) + 1;
                if ((DAT_ != '\0') ||
                   ((&stack0x000000c9)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                  *(undefined4 *)(&stack0x00000470 + lVar14) = 0x58;
                  lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x000004a8 + lVar14) = lVar30;
                  lVar30 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x000004b0 + lVar14) = lVar30;
                  *(longlong *)(&stack0x000004b8 + lVar14) = lVar30;
                  lVar30 = *(longlong *)(lVar30 + 8);
                  *(longlong *)(&stack0x000004c0 + lVar14) = lVar30;
                  *(longlong *)(&stack0x000004c8 + lVar14) = lVar30;
                  if (lVar30 == 0) {
                    *(undefined8 *)(&stack0x000003b0 + lVar14) = 0;
                  }
                  else {
                    lVar30 = *(longlong *)(lVar30 + 0x60);
                    *(longlong *)(&stack0x000003b0 + lVar14) = lVar30;
                    if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                      if ((DAT_ == '\0') &&
                         ((&stack0x000000ca)[lVar14] = DAT_ >> 1,
                         (DAT_ >> 1 & 1) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100479;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1004a1;
                        (*_DAT_)(1,0x1517798,0x1637468,0x816);
                      }
                    }
                  }
                  puVar22 = *(ushort **)(&stack0x00000040 + lVar14);
                }
                pbVar41 = *ppbVar33;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1004c2;
                func_0x(pbVar41,4);
              }
              uVar40 = *(ushort *)
                        (*(longlong *)(&stack0x00000278 + lVar14) + (ulonglong)*puVar1 * 2);
              *(ushort *)(&stack0x00000254 + lVar14) = uVar40;
              uVar28 = uVar40 & 0x7fff;
              **(uint **)(&stack0x00000060 + lVar14) = uVar28;
              puVar37 = puVar22;
              if (uVar28 < *puVar17) {
                *(int *)(&stack0x0000002c + lVar14) = *(int *)(&stack0x0000002c + lVar14) + 1;
                if ((DAT_ != '\0') ||
                   ((&stack0x000000d8)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                  *(undefined4 *)(&stack0x00000474 + lVar14) = 0x58;
                  lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x000004d0 + lVar14) = lVar30;
                  lVar30 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x000004d8 + lVar14) = lVar30;
                  *(longlong *)(&stack0x000004e0 + lVar14) = lVar30;
                  lVar30 = *(longlong *)(lVar30 + 8);
                  *(longlong *)(&stack0x000004e8 + lVar14) = lVar30;
                  *(longlong *)(&stack0x000004f0 + lVar14) = lVar30;
                  if (lVar30 == 0) {
                    *(undefined8 *)(&stack0x000003b8 + lVar14) = 0;
                  }
                  else {
                    lVar30 = *(longlong *)(lVar30 + 0x60);
                    *(longlong *)(&stack0x000003b8 + lVar14) = lVar30;
                    if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                      if ((DAT_ == '\0') &&
                         ((&stack0x000000d9)[lVar14] = DAT_ >> 1,
                         (DAT_ >> 1 & 1) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1005c9;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1005ef;
                        (*_DAT_)(1,0x1517798,0x1637468,0x81d);
                      }
                    }
                  }
                  puVar22 = *(ushort **)(&stack0x00000040 + lVar14);
                }
                pbVar41 = *ppbVar33;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100609;
                func_0x(pbVar41,4);
                puVar37 = puVar22;
              }
              do {
                uVar40 = *puVar1;
                psVar23 = (short *)(*(longlong *)(&stack0x00000278 + lVar14) + 2 +
                                   (ulonglong)(uVar40 - 1) * 2);
                *(short **)(&stack0x000004f8 + lVar14) = psVar23;
                if (-1 < *psVar23) break;
                *(uint *)(&stack0x00000478 + lVar14) = (uint)uVar40;
                pbVar41 = *ppbVar33;
                pbVar31 = pbVar41 + *puVar4;
                *(byte **)(&stack0x00000500 + lVar14) = pbVar31;
                if (uVar40 == 1) {
                  uVar28 = *puVar17;
                  uVar29 = uVar28;
                }
                else {
                  uVar2 = *(ushort *)(pbVar31 + (longlong)(int)(uVar40 - 2) * 2 + 2);
                  *(ushort *)(&stack0x00000250 + lVar14) = uVar2;
                  uVar28 = uVar2 & 0x7fff;
                  uVar29 = *puVar17;
                }
                *(uint *)(&stack0x000002e0 + lVar14) = uVar28;
                uVar40 = *(ushort *)(pbVar31 + (longlong)(int)(uVar40 - 1) * 2 + 2);
                *(ushort *)(&stack0x0000024c + lVar14) = uVar40;
                uVar35 = uVar40 & 0x7fff;
                *(uint *)(&stack0x000002e4 + lVar14) = uVar35;
                if ((uVar28 < uVar29) || (uVar35 < uVar28)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1006be;
                  func_0x(pbVar41,7);
                  uVar29 = *puVar17;
                }
                *(uint *)(&stack0x000002e8 + lVar14) = uVar35 - uVar28;
                *(uint *)(&stack0x000002ec + lVar14) = uVar28;
                if ((uVar28 < uVar29) || (**(uint **)(&stack0x00000060 + lVar14) < uVar28)) {
                  iVar11 = *(int *)(&stack0x0000002c + lVar14);
                  *(int *)(&stack0x0000002c + lVar14) = iVar11 + 1;
                  *(int *)(&stack0x00000224 + lVar14) = iVar11 + 1;
                  puVar17 = *(uint **)(&stack0x00000060 + lVar14);
                  puVar22 = *(ushort **)(&stack0x00000110 + lVar14);
                  param_4 = *(short **)(&stack0x00000070 + lVar14);
                  goto LAB_;
                }
                uVar40 = *(ushort *)(*ppbVar33 + uVar28);
                *(ushort *)(&stack0x00000214 + lVar14) = uVar40;
                if (uVar40 == 5) {
                  *puVar37 = *puVar37 | 2;
                  *puVar1 = *puVar1 - 1;
                  *(uint *)(&stack0x000002f0 + lVar14) = uVar35 - uVar28;
                  *(ushort **)(&stack0x00000508 + lVar14) = puVar37 + 0x14;
                  puVar37[0x14] = (ushort)uVar28;
                  lVar30 = (ulonglong)(uVar28 & 0xffff) + *(longlong *)(puVar37 + 3);
                  *(longlong *)(&stack0x00000510 + lVar14) = lVar30;
                  uVar40 = *(ushort *)(lVar30 + 2);
                  puVar37[0x15] = puVar37[0x15] & 0xc7ff;
                  if ((uVar40 & 0x4000) != 0) {
                    puVar37[0x15] = puVar37[0x15] | uVar40 & 0x3800;
                  }
                  puVar37[0x15] = (puVar37[0x15] ^ *(ushort *)(lVar30 + 2)) & 0x7ff ^ puVar37[0x15];
                  puVar17 = *(uint **)(&stack0x00000060 + lVar14);
                  goto LAB_;
                }
                if (uVar40 < 0x400) break;
                *puVar37 = *puVar37 | 1;
                *puVar1 = *puVar1 - 1;
              } while (*puVar1 != 0);
              puVar17 = *(uint **)(&stack0x00000060 + lVar14);
            }
LAB_:
            if ((**ppbVar33 & 0x40) == 0) {
              *(undefined4 *)(puVar37 + 0x12) = 0;
            }
            else {
              *(uint *)(puVar37 + 0x12) = *puVar17;
              *puVar17 = *puVar17 + 0xe;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10087b;
              puVar15 = (ulonglong *)func_0x(puVar37);
              *(ulonglong **)(&stack0x00000518 + lVar14) = puVar15;
              uVar44 = *puVar15;
              *(ulonglong *)(&stack0x000003c0 + lVar14) = uVar44;
              *(undefined4 *)(&stack0x00000220 + lVar14) = 0;
              uVar40 = (ushort)(uVar44 >> 0x30);
              if ((((uint)(int)(short)uVar40 >> 1 ^ (int)(short)uVar40) & 0x2000) != 0) {
                if ((uVar44 & 0x4000000000000000) == 0) {
                  uVar40 = uVar40 & 0xdfff;
                }
                else {
                  uVar40 = uVar40 | 0x2000;
                }
              }
              *(ushort *)(&stack0x00000210 + lVar14) = uVar40;
              uVar28 = 0;
              if (uVar40 == 0xfffc) {
                *(undefined **)(&stack0x00000520 + lVar14) = &stack0x000003c0 + lVar14;
                uVar28 = ((uint)(uVar44 >> 0x20) & 0xffff) >> 5;
                *(uint *)(&stack0x00000220 + lVar14) = uVar28;
              }
              *puVar17 = *puVar17 + uVar28;
            }
            if ((*(byte **)(puVar37 + 0xe) != (byte *)0x0) &&
               (*(byte **)(puVar37 + 0xe) < *ppbVar33 + *puVar17)) {
              *(int *)(&stack0x0000002c + lVar14) = *(int *)(&stack0x0000002c + lVar14) + 1;
              if ((DAT_ != '\0') ||
                 ((&stack0x000000da)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                *(undefined4 *)(&stack0x000002f8 + lVar14) = 0x58;
                lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                *(longlong *)(&stack0x00000528 + lVar14) = lVar30;
                lVar30 = (ulonglong)*_DAT_ +
                         *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                *(longlong *)(&stack0x00000530 + lVar14) = lVar30;
                *(longlong *)(&stack0x00000538 + lVar14) = lVar30;
                lVar30 = *(longlong *)(lVar30 + 8);
                *(longlong *)(&stack0x00000540 + lVar14) = lVar30;
                *(longlong *)(&stack0x00000548 + lVar14) = lVar30;
                if (lVar30 == 0) {
                  *(undefined8 *)(&stack0x000003c8 + lVar14) = 0;
                }
                else {
                  lVar30 = *(longlong *)(lVar30 + 0x60);
                  *(longlong *)(&stack0x000003c8 + lVar14) = lVar30;
                  if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                    if ((DAT_ == '\0') &&
                       ((&stack0x000000db)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) == 0
                       )) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100a18;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100a3e;
                      (*_DAT_)(1,0x1517798,0x1637468,0x877);
                    }
                  }
                }
                puVar37 = *(ushort **)(&stack0x00000040 + lVar14);
              }
              pbVar41 = *ppbVar33;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100a5b;
              func_0x(pbVar41,0x12);
            }
            if (0x3f3b < *puVar17 - 1) {
              *(int *)(&stack0x0000002c + lVar14) = *(int *)(&stack0x0000002c + lVar14) + 1;
              if ((DAT_ != '\0') ||
                 ((&stack0x000000f0)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                *(undefined4 *)(&stack0x000002fc + lVar14) = 0x58;
                lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                *(longlong *)(&stack0x00000550 + lVar14) = lVar30;
                lVar30 = (ulonglong)*_DAT_ +
                         *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                *(longlong *)(&stack0x00000558 + lVar14) = lVar30;
                *(longlong *)(&stack0x00000560 + lVar14) = lVar30;
                lVar30 = *(longlong *)(lVar30 + 8);
                *(longlong *)(&stack0x00000568 + lVar14) = lVar30;
                *(longlong *)(&stack0x00000570 + lVar14) = lVar30;
                if (lVar30 == 0) {
                  *(undefined8 *)(&stack0x000003d0 + lVar14) = 0;
                }
                else {
                  lVar30 = *(longlong *)(lVar30 + 0x60);
                  *(longlong *)(&stack0x000003d0 + lVar14) = lVar30;
                  if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                    if ((DAT_ == '\0') &&
                       ((&stack0x000000f1)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) == 0
                       )) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100b38;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100b5e;
                      (*_DAT_)(1,0x1517798,0x1637468,0x87c);
                    }
                  }
                }
                puVar37 = *(ushort **)(&stack0x00000040 + lVar14);
              }
              pbVar41 = *ppbVar33;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100b7b;
              func_0x(pbVar41,5);
            }
            uVar12 = *(undefined4 *)(&stack0x0000002c + lVar14);
            *(undefined4 *)(&stack0x0000002c + lVar14) = uVar12;
            *(undefined4 *)(&stack0x00000224 + lVar14) = uVar12;
            puVar22 = *(ushort **)(&stack0x00000110 + lVar14);
            param_4 = *(short **)(&stack0x00000070 + lVar14);
          }
LAB_:
          uVar28 = *puVar17;
          if (uVar28 < 9) {
            pbVar41 = *(byte **)(puVar37 + 3);
            *(byte **)(&stack0x00000578 + lVar14) = pbVar41;
            bVar25 = *pbVar41 & 0xe;
            (&stack0x000000f2)[lVar14] = bVar25;
            if ((bVar25 == 0) || (bVar25 == 0xc)) {
              uVar28 = 9;
            }
          }
          *(uint *)(&stack0x00000300 + lVar14) = uVar28;
          *(uint *)(&stack0x000000e0 + lVar14) = uVar28;
          lVar34 = *(longlong *)(&stack0x000001c8 + lVar14);
          param_1 = *(longlong **)(&stack0x00000168 + lVar14);
        }
        else {
          *(ushort **)(&stack0x00000580 + lVar14) = puVar22;
          uVar28 = *(uint *)(param_4 + 2);
          if (uVar28 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100bb6;
            func_0x(puVar22);
            uVar28 = *(uint *)(param_4 + 2);
          }
          if (uVar28 < 9) {
            bVar25 = **(byte **)(param_4 + 4);
            uVar29 = bVar25 & 0x1c;
            *(uint *)(&stack0x00000304 + lVar14) = uVar29;
            if (((bVar25 & 0x1c) == 0) || (uVar29 == 0xc)) {
              uVar28 = 9;
            }
          }
          *(uint *)(&stack0x00000308 + lVar14) = uVar28;
          *(uint *)(&stack0x000000e0 + lVar14) = uVar28;
        }
        *(undefined2 *)(&stack0x00000b28 + lVar14) = 0xffff;
        *(undefined8 *)(&stack0x00000b30 + lVar14) = 0;
        *(undefined4 *)(&stack0x00000b2c + lVar14) = 0;
        *(undefined8 *)(&stack0x00000b46 + lVar14) = 0;
        *(undefined8 *)(&stack0x00000b50 + lVar14) = 0;
        *(undefined8 *)(&stack0x00000b38 + lVar14) = 0;
        *(undefined4 *)(&stack0x00000b5c + lVar14) = 0xffffffff;
        *(undefined4 *)(&stack0x0000013c + lVar14) = 0;
        if (*param_4 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100c54;
          func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100c5b;
          func_0x(puVar22,&stack0x00000238 + lVar14);
        }
        *(undefined8 *)(&stack0x00000170 + lVar14) = 0;
        puVar36 = *(undefined4 **)(&stack0x00000178 + lVar14);
        *(int *)(&stack0x00000068 + lVar14) = (int)*(short *)((longlong)puVar36 + 6);
        (&stack0x00000029)[lVar14] = 0;
        *(undefined4 *)(&stack0x0000006c + lVar14) = 0;
        *(undefined **)(&stack0x00000588 + lVar14) = &stack0x00000080 + lVar14;
        bVar25 = (&stack0x00000080)[lVar14];
        (&stack0x00000080)[lVar14] = bVar25 & 0xfe;
        (&stack0x00000080)[lVar14] = bVar25 & 0xfc;
        (&stack0x00000080)[lVar14] = bVar25 & 0xf8;
        (&stack0x00000080)[lVar14] = bVar25 & 0xf0;
        (&stack0x00000080)[lVar14] = bVar25 & 0xe0;
        (&stack0x00000080)[lVar14] = bVar25 & 0xc0;
        (&stack0x00000081)[lVar14] = 0;
        (&stack0x00000082)[lVar14] = 0;
        *(undefined8 *)(&stack0x00000088 + lVar14) = 0;
        bVar25 = (&stack0x00000090)[lVar14];
        (&stack0x00000090)[lVar14] = bVar25 & 0xfe;
        (&stack0x00000090)[lVar14] = bVar25 & 0xfc;
        (&stack0x00000090)[lVar14] = bVar25 & 0xf8;
        (&stack0x00000090)[lVar14] = bVar25 & 0xf0;
        (&stack0x00000090)[lVar14] = bVar25 & 0xe0;
        (&stack0x00000050)[lVar14] = 0;
        (&stack0x00000028)[lVar14] = 1;
        cVar8 = (&stack0x00002d28)[lVar14];
        plVar16 = param_1;
        if (cVar8 != '\0') {
          plVar16 = *(longlong **)(&stack0x00000258 + lVar14);
          if (plVar16 == (longlong *)0x0) {
            (&stack0xffffffffffffffe8)[lVar14] = 0;
            lVar30 = param_1[0x52];
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d64;
            func_0x(&stack0x00000140 + lVar14,0x152f048,0x3c,lVar30);
            pcVar3 = *(code **)(**(longlong **)(&stack0x00000140 + lVar14) + 0x58);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d7a;
            plVar16 = (longlong *)
                      (*pcVar3)(*(longlong **)(&stack0x00000140 + lVar14),
                                *(undefined8 *)(&stack0x00000188 + lVar14));
          }
          *(longlong **)(&stack0x00000170 + lVar14) = plVar16;
          pcVar3 = *(code **)(*plVar16 + 0x348);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d93;
          (*pcVar3)(plVar16,1);
        }
        *(longlong **)(&stack0x00000048 + lVar14) = plVar16;
        pcVar3 = *(code **)(*plVar16 + 8);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100da4;
        cVar7 = (*pcVar3)(plVar16);
        (&stack0x00000036)[lVar14] = cVar7;
        if ((cVar7 == '\0') && (cVar8 != '\0')) {
          *(undefined4 **)(&stack0x00000590 + lVar14) = (undefined4 *)(lVar34 + 0x20);
          uVar12 = *(undefined4 *)(lVar34 + 0x20);
          *(undefined4 *)(&stack0x00000158 + lVar14) = uVar12;
          uVar10 = *(undefined2 *)(lVar34 + 0x24);
          *(undefined2 *)(&stack0x0000015c + lVar14) = uVar10;
          *(undefined **)(&stack0x00000598 + lVar14) = &stack0x00000150 + lVar14;
          *(undefined4 *)(&stack0x00000150 + lVar14) = uVar12;
          *(undefined2 *)(&stack0x00000154 + lVar14) = uVar10;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e0f;
          iVar11 = func_0x(*(undefined8 *)(&stack0x00000170 + lVar14),0,
                                   &stack0x00000150 + lVar14);
          *(int *)(&stack0x00000158 + lVar14) = iVar11;
          if (iVar11 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e2e;
            func_0x(*(undefined8 *)(&stack0x00000078 + lVar14));
            *(undefined **)(&stack0x000005a0 + lVar14) = &stack0x00000148 + lVar14;
            *(undefined4 *)(&stack0x00000148 + lVar14) = uVar12;
            *(undefined2 *)(&stack0x0000014c + lVar14) = uVar10;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e67;
            uVar12 = func_0x(*(undefined8 *)(&stack0x00000170 + lVar14),0xffffffff,
                                     &stack0x00000148 + lVar14);
            *(undefined4 *)(&stack0x00000158 + lVar14) = uVar12;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e77;
            func_0x(uVar12,0x23);
            (&stack0xfffffffffffffff8)[lVar14] = 1;
            *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) = 0;
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100ea5;
            func_0x
                      (*(undefined8 *)(&stack0x00000078 + lVar14),4,0xffffffff,
                       &stack0x00000490 + lVar14);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100eb6;
        cVar8 = func_0x(&stack0x00000238 + lVar14);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100ecb;
          cVar8 = func_0x(&stack0x00000238 + lVar14);
          if (cVar8 != '\0') goto LAB_;
          *(undefined4 *)(&stack0x00000b18 + lVar14) = 0;
          *(undefined4 *)(&stack0x00000b1c + lVar14) = 0;
          *(undefined2 *)(&stack0x00000b20 + lVar14) = 0;
          uVar40 = *(ushort *)(lVar34 + 4);
          *(uint *)(&stack0x0000030c + lVar14) = uVar40 & 0x2000;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100f0e;
          puVar17 = (uint *)func_0x(lVar34,&stack0x000009d0 + lVar14,0,0);
          *(uint **)(&stack0x000005a8 + lVar14) = puVar17;
          plVar16 = *(longlong **)(&stack0x00000048 + lVar14);
          lVar30 = plVar16[6];
          *(longlong *)(&stack0x00000270 + lVar14) = lVar30;
          cVar8 = *(char *)(lVar30 + 0x1cde);
          (&stack0x00000034)[lVar14] = cVar8;
          if ((*(char *)(lVar30 + 0x2050) != '\0') &&
             ((*(byte *)(*(longlong *)(&stack0x00000058 + lVar14) + 0x10) & 1) != 0)) {
            *(longlong *)(&stack0x000005b0 + lVar14) = lVar30;
            *(undefined8 *)(&stack0x000005b8 + lVar14) =
                 *(undefined8 *)(*(longlong *)(lVar30 + 0x728) + 0x5fb0);
            pcVar3 = *(code **)(*plVar16 + 0xf0);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100f81;
            iVar11 = (*pcVar3)(plVar16);
            if (iVar11 == 0) {
              lVar18 = *(longlong *)(&stack0x00000048 + lVar14);
            }
            else {
              pcVar3 = *(code **)(*plVar16 + 0x1e8);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100f92;
              lVar18 = (*pcVar3)(plVar16);
            }
            lVar18 = *(longlong *)(lVar18 + 0x248);
            *(longlong *)(&stack0x000005c0 + lVar14) = lVar18;
            *(longlong *)(&stack0x000005c8 + lVar14) = lVar18;
            if (*(char *)(lVar18 + 0x16) == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100fcf;
              (*_DAT_)(0x27,0x30,0x10,2);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100fe4;
          func_0x
                    (&stack0x00000b28 + lVar14,*(undefined8 *)(&stack0x00000070 + lVar14));
          *(undefined4 *)(&stack0x0000006c + lVar14) = 1;
          if ((uVar40 & 0x2000) == 0) {
            (&stack0x00000098)[lVar14] = DAT_ >> 3;
            uVar20 = 0;
            if ((DAT_ >> 3 & 1) == 0) {
              *(undefined4 *)(&stack0x0000022c + lVar14) = 0;
              *(undefined4 *)(&stack0x00000324 + lVar14) = 0x58;
              lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x00000670 + lVar14) = lVar30;
              plVar32 = (longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8));
              *(longlong **)(&stack0x00000678 + lVar14) = plVar32;
              *(longlong **)(&stack0x00000680 + lVar14) = plVar32;
              lVar30 = *plVar32;
              *(longlong *)(&stack0x00000688 + lVar14) = lVar30;
              *(longlong *)(&stack0x00000690 + lVar14) = lVar30;
              if (lVar30 == 0) {
LAB_:
                *(undefined8 *)(&stack0x000003e0 + lVar14) = 0;
              }
              else {
                lVar30 = **(longlong **)(lVar30 + 0x38);
                *(longlong *)(&stack0x00000698 + lVar14) = lVar30;
                if (lVar30 == 0) goto LAB_;
                *(longlong *)(&stack0x000003e0 + lVar14) = lVar30;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1016a1;
                iVar11 = (*_DAT_)(lVar30,0xf73);
                *(int *)(&stack0x0000022c + lVar14) = iVar11;
                if (iVar11 != 0) goto LAB_;
              }
            }
            else {
LAB_:
              lVar30 = *(longlong *)(*(longlong *)(&stack0x00000048 + lVar14) + 0xd0);
              *(longlong *)(&stack0x000006a0 + lVar14) = lVar30;
              if (lVar30 != 0) {
                uVar20 = *(undefined8 *)(lVar30 + 0x40);
              }
              plVar32 = *(longlong **)(*(longlong *)(&stack0x00000048 + lVar14) + 0x290);
              uVar10 = *(undefined2 *)(plVar16[6] + 0x6b8);
              *(undefined2 *)(&stack0x00000204 + lVar14) = uVar10;
              pcVar3 = *(code **)(*plVar32 + 0x138);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101707;
              uVar19 = (*pcVar3)();
              uVar27 = 0x1520830;
LAB_:
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = uVar20;
              uVar20 = *(undefined8 *)(*(longlong *)(&stack0x00000058 + lVar14) + 0x28);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101729;
              func_0x(uVar27,uVar10,uVar20,uVar19);
            }
LAB_:
            (&stack0x00000035)[lVar14] = 1;
LAB_:
            (&stack0x00000099)[lVar14] = DAT_ >> 3;
            puVar21 = (undefined8 *)0x0;
            if ((DAT_ >> 3 & 1) == 0) {
              *(undefined4 *)(&stack0x00000248 + lVar14) = 0;
              *(undefined4 *)(&stack0x00000328 + lVar14) = 0x58;
              lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x000006a8 + lVar14) = lVar30;
              plVar16 = (longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8));
              *(longlong **)(&stack0x000006b0 + lVar14) = plVar16;
              *(longlong **)(&stack0x000006b8 + lVar14) = plVar16;
              lVar30 = *plVar16;
              *(longlong *)(&stack0x000006c0 + lVar14) = lVar30;
              *(longlong *)(&stack0x000006c8 + lVar14) = lVar30;
              if (lVar30 != 0) {
                lVar30 = **(longlong **)(lVar30 + 0x38);
                *(longlong *)(&stack0x000006d0 + lVar14) = lVar30;
                if (lVar30 != 0) {
                  *(longlong *)(&stack0x000003e8 + lVar14) = lVar30;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1017d3;
                  iVar11 = (*_DAT_)(lVar30,0xf73);
                  *(int *)(&stack0x00000248 + lVar14) = iVar11;
                  if (iVar11 == 0) goto LAB_;
                  goto LAB_;
                }
              }
              *(undefined8 *)(&stack0x000003e8 + lVar14) = 0;
            }
            else {
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1017f0;
              (*_DAT_)(&stack0x000009f8 + lVar14);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1017f7;
              uVar20 = (*_DAT_)();
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101808;
              lVar30 = (*_DAT_)(uVar20,0,0x6c0);
              *(longlong *)(&stack0x000006d8 + lVar14) = lVar30;
              if (lVar30 != 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10181f;
                puVar21 = (undefined8 *)func_0x(lVar30,0);
              }
              *(undefined8 **)(&stack0x000006e0 + lVar14) = puVar21;
              *(undefined8 **)(&stack0x000003f0 + lVar14) = puVar21;
              if (puVar21 != (undefined8 *)0x0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101857;
                iVar11 = (*_DAT_)(&stack0x000009f8 + lVar14,puVar21);
                if (iVar11 == 0) {
                  *(undefined8 **)(&stack0x000006e8 + lVar14) = puVar21;
                  pcVar3 = *(code **)*puVar21;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101870;
                  (*pcVar3)(puVar21,1);
                  *(undefined8 *)(&stack0x000003f0 + lVar14) = 0;
                }
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10188d;
              func_0x(&stack0x00000b28 + lVar14,&stack0x000009f8 + lVar14);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10189c;
              (*_DAT_)(&stack0x000009f8 + lVar14);
            }
          }
          else {
            lVar18 = plVar16[6];
            *(longlong *)(&stack0x000005d0 + lVar14) = lVar18;
            if (*(char *)(lVar18 + 0x1ad8) == '\0') {
              if (**(short **)(&stack0x00000070 + lVar14) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10102c;
                func_0x();
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101033;
                func_0x(*(short **)(&stack0x00000070 + lVar14) + 1,&stack0x00000240 + lVar14
                               );
              }
              *(undefined **)(&stack0x000005d8 + lVar14) = &stack0x00000240 + lVar14;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101050;
              cVar7 = func_0x(&stack0x00000240 + lVar14);
              if (cVar7 == '\0') goto LAB_;
LAB_:
              psVar23 = *(short **)(&stack0x00000070 + lVar14);
            }
            else {
LAB_:
              puVar4 = *(uint **)(*(longlong *)(lVar18 + 0x6b0) + 0x2c0);
              *(uint **)(&stack0x000005e0 + lVar14) = puVar4;
              if ((*(short *)((longlong)puVar4 + 10) == 2) && (*puVar17 == 0)) {
LAB_:
                *(undefined4 *)(&stack0x00000138 + lVar14) = 1;
                goto LAB_;
              }
              *(uint **)(&stack0x000005e8 + lVar14) = puVar4;
              if ((*puVar4 < *puVar17) ||
                 ((*puVar17 == *puVar4 &&
                  ((puVar4[1] < puVar17[1] ||
                   ((puVar17[1] == puVar4[1] && (*(ushort *)(puVar4 + 2) < *(ushort *)(puVar17 + 2))
                    ))))))) goto LAB_;
              *(undefined4 *)(&stack0x00000138 + lVar14) = 0;
              if (*(char *)(lVar18 + 0x2050) == '\0') {
LAB_:
                uVar20 = 0;
                (&stack0x000000f3)[lVar14] = DAT_ >> 3;
                if ((DAT_ >> 3 & 1) != 0) {
LAB_:
                  lVar30 = *(longlong *)(*(longlong *)(&stack0x00000048 + lVar14) + 0xd0);
                  *(longlong *)(&stack0x00000628 + lVar14) = lVar30;
                  if (lVar30 != 0) {
                    uVar20 = *(undefined8 *)(lVar30 + 0x40);
                  }
                  plVar32 = *(longlong **)(*(longlong *)(&stack0x00000048 + lVar14) + 0x290);
                  uVar10 = *(undefined2 *)(plVar16[6] + 0x6b8);
                  *(undefined2 *)(&stack0x00000218 + lVar14) = uVar10;
                  pcVar3 = *(code **)(*plVar32 + 0x138);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10120d;
                  uVar19 = (*pcVar3)();
                  uVar27 = 0x1520780;
                  goto LAB_;
                }
                *(undefined4 *)(&stack0x00000228 + lVar14) = 0;
                *(undefined4 *)(&stack0x00000310 + lVar14) = 0x58;
                lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                *(longlong *)(&stack0x000005f8 + lVar14) = lVar30;
                plVar32 = (longlong *)
                          ((ulonglong)*_DAT_ +
                          *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8));
                *(longlong **)(&stack0x00000600 + lVar14) = plVar32;
                *(longlong **)(&stack0x00000608 + lVar14) = plVar32;
                lVar30 = *plVar32;
                *(longlong *)(&stack0x00000610 + lVar14) = lVar30;
                *(longlong *)(&stack0x00000618 + lVar14) = lVar30;
                if (lVar30 != 0) {
                  lVar30 = **(longlong **)(lVar30 + 0x38);
                  *(longlong *)(&stack0x00000620 + lVar14) = lVar30;
                  if (lVar30 != 0) {
                    *(longlong *)(&stack0x000003d8 + lVar14) = lVar30;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1011b2;
                    iVar11 = (*_DAT_)(lVar30,0xf73);
                    *(int *)(&stack0x00000228 + lVar14) = iVar11;
                    if (iVar11 == 0) goto LAB_;
                    goto LAB_;
                  }
                }
                *(undefined8 *)(&stack0x000003d8 + lVar14) = 0;
                goto LAB_;
              }
              psVar23 = *(short **)(&stack0x00000070 + lVar14);
              if (*psVar23 == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1010df;
                func_0x();
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1010e6;
                func_0x(psVar23 + 1,&stack0x000001b0 + lVar14);
              }
              *(undefined **)(&stack0x000005f0 + lVar14) = &stack0x000001b0 + lVar14;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101103;
              cVar7 = func_0x(&stack0x000001b0 + lVar14);
              if (cVar7 == '\0') goto LAB_;
            }
            (&stack0x00000035)[lVar14] = 0;
            if (*(short *)(&stack0x00000b28 + lVar14) == 0) {
              bVar25 = **(byte **)(&stack0x00000b30 + lVar14) >> 6;
            }
            else {
              bVar25 = **(byte **)(&stack0x00000b30 + lVar14) >> 1;
            }
            *(uint *)(&stack0x00000314 + lVar14) = bVar25 & 1;
            if ((bVar25 & 1) == 0) goto LAB_;
            *(undefined4 *)(&stack0x00000070 + lVar14) = 0;
            *(undefined2 *)(&stack0x00000074 + lVar14) = 0;
            if (*(short *)(&stack0x00000b28 + lVar14) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10129a;
              func_0x();
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1012a1;
              func_0x(&stack0x00000b2a + lVar14,&stack0x0000011e + lVar14);
            }
            *(undefined **)(&stack0x00000630 + lVar14) = &stack0x0000011e + lVar14;
            if ((*(short *)(&stack0x00000122 + lVar14) == 0) &&
               (*(int *)(&stack0x0000011e + lVar14) == 0)) goto LAB_;
            plVar16 = *(longlong **)(&stack0x00000058 + lVar14);
            if ((plVar16 == (longlong *)0x0) || ((*(byte *)(plVar16 + 2) & 0x20) == 0)) {
LAB_:
              sVar9 = *psVar23;
              *(uint *)(&stack0x00000320 + lVar14) = (uint)(sVar9 == 1);
              *(undefined8 *)((longlong)alStackX_18 + lVar14 + 8) = 0;
              if (sVar9 == 1) {
                *(undefined **)((longlong)alStackX_18 + lVar14) = &stack0x00000b18 + lVar14;
                *(undefined8 *)((longlong)alStackX_8 + lVar14 + 8) = 0;
                *(undefined8 *)((longlong)alStackX_8 + lVar14) = 0;
                *(undefined *)((longlong)alStackX_18 + lVar14 + -0x18) = 1;
                *(undefined **)(&stack0xfffffffffffffff8 + lVar14) = &stack0x0000006c + lVar14;
                *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x00000b28 + lVar14;
                *(longlong **)(&stack0xffffffffffffffe8 + lVar14) = plVar16;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1015a4;
                func_0x(psVar23,&stack0x00000cf8 + lVar14,0x1f9e,
                                *(undefined8 *)(&stack0x00000048 + lVar14));
              }
              else {
                *(undefined *)((longlong)alStackX_18 + lVar14) = 1;
                *(undefined **)((longlong)alStackX_8 + lVar14 + 8) = &stack0x00000b18 + lVar14;
                *(undefined8 *)((longlong)alStackX_8 + lVar14) = 0;
                *(undefined8 *)((longlong)alStackX_18 + lVar14 + -0x18) = 0;
                (&stack0xfffffffffffffff8)[lVar14] = 1;
                *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x0000006c + lVar14;
                *(undefined **)(&stack0xffffffffffffffe8 + lVar14) = &stack0x00000b28 + lVar14;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1015f9;
                func_0x
                          (&stack0x00000cf8 + lVar14,0x1f9e,
                           *(undefined8 *)(&stack0x00000048 + lVar14),plVar16);
              }
            }
            else {
              lVar18 = *(longlong *)(&stack0x00000048 + lVar14);
              if ((*(byte *)(lVar18 + 0x218) & 4) != 0) {
                pcVar3 = *(code **)(**(longlong **)(&stack0x00000048 + lVar14) + 0x1e8);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101314;
                lVar18 = (*pcVar3)(*(longlong **)(&stack0x00000048 + lVar14));
              }
              *(int **)(&stack0x00000638 + lVar14) = (int *)(lVar18 + 0x28);
              if (*(short *)(&stack0x00000b28 + lVar14) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101340;
                func_0x();
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101347;
                func_0x(&stack0x00000b2a + lVar14,&stack0x00000118 + lVar14);
              }
              *(undefined **)(&stack0x00000640 + lVar14) = &stack0x00000118 + lVar14;
              if ((*(short *)(&stack0x0000011c + lVar14) != *(short *)(lVar18 + 0x2c)) ||
                 (*(int *)(&stack0x00000118 + lVar14) != *(int *)(lVar18 + 0x28))) {
                plVar16 = *(longlong **)(&stack0x00000058 + lVar14);
                goto LAB_;
              }
              lVar18 = *(longlong *)(&stack0x00000048 + lVar14);
              lVar24 = *(longlong *)(lVar18 + 0xd0);
              *(longlong *)(&stack0x00000648 + lVar14) = lVar24;
              if (cVar8 == '\0') {
                plVar16 = *(longlong **)(&stack0x00000058 + lVar14);
LAB_:
                *(undefined8 *)((longlong)alStackX_18 + lVar14) = 0;
                *(undefined **)((longlong)alStackX_8 + lVar14 + 8) = &stack0x0000006c + lVar14;
                *(undefined *)((longlong)alStackX_8 + lVar14) = 1;
                *(undefined8 *)((longlong)alStackX_18 + lVar14 + -0x18) = 0;
                *(undefined **)(&stack0xfffffffffffffff8 + lVar14) = &stack0x00000b28 + lVar14;
                *(longlong *)(&stack0xfffffffffffffff0 + lVar14) = *plVar16;
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 0x1f9e;
                uVar20 = *(undefined8 *)(lVar30 + 0x6b0);
                lVar24 = plVar16[4];
                uVar19 = *(undefined8 *)(lVar18 + 0xd0);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101452;
                func_0x(uVar19,lVar24,uVar20,&stack0x00000cf8 + lVar14);
              }
              else if ((lVar24 == 0) || (*(char *)(lVar24 + 0x34) == '\0')) {
                plVar16 = *(longlong **)(&stack0x00000058 + lVar14);
              }
              else {
                plVar16 = *(longlong **)(&stack0x00000058 + lVar14);
                if (*(longlong *)(lVar24 + 0x40) != 0) {
                  LOCK();
                  lVar38 = *(longlong *)(lVar24 + 0x128);
                  if (lVar38 == 0) {
                    *(longlong *)(lVar24 + 0x128) = 0;
                    lVar38 = 0;
                  }
                  UNLOCK();
                  *(longlong *)(&stack0x00000650 + lVar14) = lVar38;
                  *(longlong *)(&stack0x00000658 + lVar14) = lVar38;
                  lVar30 = *(longlong *)(&stack0x00000270 + lVar14);
                  cVar8 = (&stack0x00000034)[lVar14];
                  if (*(longlong *)(*plVar16 + 0x28) != lVar38) goto LAB_;
                }
              }
              if (cVar8 != '\0') {
                if (*(short *)(&stack0x00000b28 + lVar14) == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101485;
                  func_0x();
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10148c;
                  func_0x(&stack0x00000b2a + lVar14,&stack0x000001b8 + lVar14);
                }
                *(undefined **)(&stack0x00000660 + lVar14) = &stack0x000001b8 + lVar14;
                if (*(short *)(&stack0x00000b28 + lVar14) == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1014bc;
                  func_0x();
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1014c3;
                  func_0x(&stack0x00000b2a + lVar14,&stack0x00000124 + lVar14);
                }
                *(undefined **)(&stack0x00000668 + lVar14) = &stack0x00000124 + lVar14;
                *(undefined4 *)(&stack0x00000318 + lVar14) =
                     *(undefined4 *)(&stack0x00000124 + lVar14);
                *(undefined2 *)(&stack0x00000208 + lVar14) =
                     *(undefined2 *)(&stack0x00000128 + lVar14);
                *(undefined4 *)(&stack0x000001f8 + lVar14) =
                     *(undefined4 *)(&stack0x00000124 + lVar14);
                *(undefined2 *)(&stack0x000001fc + lVar14) =
                     *(undefined2 *)(&stack0x00000128 + lVar14);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10151c;
                iVar11 = func_0x(lVar30 + 0x19c8,&stack0x000001f8 + lVar14,
                                         &stack0x000001b8 + lVar14);
                if (iVar11 != 0) goto LAB_;
              }
            }
          }
LAB_:
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1018a9;
          iVar11 = func_0x(&stack0x00000b28 + lVar14);
          if ((iVar11 != 0) || (*(int *)(&stack0x0000006c + lVar14) == 0)) {
            (&stack0x00000029)[lVar14] = 1;
LAB_:
            puVar36 = *(undefined4 **)(&stack0x00000178 + lVar14);
            goto LAB_;
          }
          if (*(short *)(&stack0x00000b28 + lVar14) == 0) {
            *(undefined **)(&stack0x00000060 + lVar14) = &stack0x00000b2a + lVar14;
            if (*(int *)(&stack0x00000b2c + lVar14) == 0) {
              *(undefined4 *)(&stack0x00000030 + lVar14) = 0;
              *(undefined2 *)(&stack0x00000b2a + lVar14) = 0;
              uVar28 = *(uint *)(&stack0x00000b38 + lVar14);
              uVar44 = (ulonglong)uVar28;
              *(uint *)(&stack0x00000b3c + lVar14) = uVar28;
              if ((**(byte **)(&stack0x00000b30 + lVar14) & 0x10) != 0) {
                uVar28 = uVar28 + 2 +
                         (*(ushort *)(*(byte **)(&stack0x00000b30 + lVar14) + uVar44) + 7 >> 3);
                uVar44 = (ulonglong)uVar28;
                *(uint *)(&stack0x00000b3c + lVar14) = uVar28;
              }
              if ((**(byte **)(&stack0x00000b30 + lVar14) & 0x20) == 0) {
                *(int *)(&stack0x00000b2c + lVar14) = (int)uVar44;
                *(undefined2 *)(&stack0x00000b44 + lVar14) = 0;
                *(int *)(&stack0x00000b40 + lVar14) = (int)uVar44;
              }
              else {
                puVar22 = (ushort *)(*(byte **)(&stack0x00000b30 + lVar14) + uVar44);
                *(ushort **)(&stack0x00000260 + lVar14) = puVar22;
                uVar40 = *puVar22;
                *(ushort *)(&stack0x00000b44 + lVar14) = uVar40;
                if (uVar40 == 0) {
                  *(undefined4 *)(&stack0x00000030 + lVar14) = 1;
                  if ((DAT_ != '\0') ||
                     ((&stack0x0000009a)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                    *(undefined4 *)(&stack0x0000032c + lVar14) = 0x58;
                    lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                    *(longlong *)(&stack0x000006f0 + lVar14) = lVar30;
                    lVar30 = (ulonglong)*_DAT_ +
                             *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                    *(longlong *)(&stack0x000006f8 + lVar14) = lVar30;
                    *(longlong *)(&stack0x00000700 + lVar14) = lVar30;
                    lVar30 = *(longlong *)(lVar30 + 8);
                    *(longlong *)(&stack0x00000708 + lVar14) = lVar30;
                    *(longlong *)(&stack0x00000710 + lVar14) = lVar30;
                    if (lVar30 == 0) {
                      *(undefined8 *)(&stack0x000003f8 + lVar14) = 0;
                    }
                    else {
                      lVar30 = *(longlong *)(lVar30 + 0x60);
                      *(longlong *)(&stack0x000003f8 + lVar14) = lVar30;
                      if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                        if ((DAT_ == '\0') &&
                           ((&stack0x0000009b)[lVar14] = DAT_ >> 1,
                           (DAT_ >> 1 & 1) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a36;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a5c;
                          (*_DAT_)(1,0x1517798,0x1637468,0x80f);
                        }
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a78;
                  func_0x(*(undefined8 *)(&stack0x00000b30 + lVar14),3);
                  uVar40 = *(ushort *)(&stack0x00000b44 + lVar14);
                  uVar44 = (ulonglong)*(uint *)(&stack0x00000b3c + lVar14);
                }
                uVar28 = (int)uVar44 + (uVar40 + 1) * 2;
                *(uint *)(&stack0x00000b40 + lVar14) = uVar28;
                if (0x1f9e < uVar28) {
                  *(int *)(&stack0x00000030 + lVar14) = *(int *)(&stack0x00000030 + lVar14) + 1;
                  if ((DAT_ != '\0') ||
                     ((&stack0x0000009c)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                    *(undefined4 *)(&stack0x00000330 + lVar14) = 0x58;
                    lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                    *(longlong *)(&stack0x00000718 + lVar14) = lVar30;
                    lVar30 = (ulonglong)*_DAT_ +
                             *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                    *(longlong *)(&stack0x00000720 + lVar14) = lVar30;
                    *(longlong *)(&stack0x00000728 + lVar14) = lVar30;
                    lVar30 = *(longlong *)(lVar30 + 8);
                    *(longlong *)(&stack0x00000730 + lVar14) = lVar30;
                    *(longlong *)(&stack0x00000738 + lVar14) = lVar30;
                    if (lVar30 == 0) {
                      *(undefined8 *)(&stack0x00000400 + lVar14) = 0;
                    }
                    else {
                      lVar30 = *(longlong *)(lVar30 + 0x60);
                      *(longlong *)(&stack0x00000400 + lVar14) = lVar30;
                      if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                        if ((DAT_ == '\0') &&
                           ((&stack0x0000009d)[lVar14] = DAT_ >> 1,
                           (DAT_ >> 1 & 1) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b76;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b9c;
                          (*_DAT_)(1,0x1517798,0x1637468,0x816);
                        }
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101bbc;
                  func_0x(*(undefined8 *)(&stack0x00000b30 + lVar14),4);
                  uVar40 = *(ushort *)(&stack0x00000b44 + lVar14);
                  uVar28 = *(uint *)(&stack0x00000b40 + lVar14);
                  uVar44 = (ulonglong)*(uint *)(&stack0x00000b3c + lVar14);
                }
                uVar42 = (ulonglong)uVar40;
                uVar40 = *(ushort *)(*(longlong *)(&stack0x00000260 + lVar14) + uVar42 * 2);
                *(ushort *)(&stack0x00000200 + lVar14) = uVar40;
                uVar29 = uVar40 & 0x7fff;
                *(uint *)(&stack0x00000b2c + lVar14) = uVar29;
                if (uVar29 < uVar28) {
                  *(int *)(&stack0x00000030 + lVar14) = *(int *)(&stack0x00000030 + lVar14) + 1;
                  if ((DAT_ != '\0') ||
                     ((&stack0x0000009e)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                    *(undefined4 *)(&stack0x00000334 + lVar14) = 0x58;
                    lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                    *(longlong *)(&stack0x00000740 + lVar14) = lVar30;
                    lVar30 = (ulonglong)*_DAT_ +
                             *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                    *(longlong *)(&stack0x00000748 + lVar14) = lVar30;
                    *(longlong *)(&stack0x00000750 + lVar14) = lVar30;
                    lVar30 = *(longlong *)(lVar30 + 8);
                    *(longlong *)(&stack0x00000758 + lVar14) = lVar30;
                    *(longlong *)(&stack0x00000760 + lVar14) = lVar30;
                    if (lVar30 == 0) {
                      *(undefined8 *)(&stack0x00000408 + lVar14) = 0;
                    }
                    else {
                      lVar30 = *(longlong *)(lVar30 + 0x60);
                      *(longlong *)(&stack0x00000408 + lVar14) = lVar30;
                      if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                        if ((DAT_ == '\0') &&
                           ((&stack0x0000009f)[lVar14] = DAT_ >> 1,
                           (DAT_ >> 1 & 1) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101cd8;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101cfe;
                          (*_DAT_)(1,0x1517798,0x1637468,0x81d);
                        }
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101d18;
                  func_0x(*(undefined8 *)(&stack0x00000b30 + lVar14),4);
                  uVar42 = (ulonglong)*(ushort *)(&stack0x00000b44 + lVar14);
                  uVar28 = *(uint *)(&stack0x00000b40 + lVar14);
                  uVar44 = (ulonglong)*(uint *)(&stack0x00000b3c + lVar14);
                }
                do {
                  iVar11 = (int)uVar42;
                  psVar23 = (short *)(*(longlong *)(&stack0x00000260 + lVar14) + 2 +
                                     (ulonglong)(iVar11 - 1) * 2);
                  *(short **)(&stack0x00000768 + lVar14) = psVar23;
                  if (-1 < *psVar23) break;
                  *(int *)(&stack0x00000338 + lVar14) = iVar11;
                  lVar30 = uVar44 + *(longlong *)(&stack0x00000b30 + lVar14);
                  *(longlong *)(&stack0x00000770 + lVar14) = lVar30;
                  uVar29 = uVar28;
                  if (iVar11 != 1) {
                    uVar40 = *(ushort *)(lVar30 + 2 + (longlong)(iVar11 + -2) * 2);
                    *(ushort *)(&stack0x000001e4 + lVar14) = uVar40;
                    uVar29 = uVar40 & 0x7fff;
                  }
                  uVar40 = *(ushort *)(lVar30 + 2 + (longlong)(iVar11 + -1) * 2);
                  *(ushort *)(&stack0x000001d0 + lVar14) = uVar40;
                  uVar35 = uVar40 & 0x7fff;
                  *(uint *)(&stack0x00000340 + lVar14) = uVar35;
                  if ((uVar29 < uVar28) || (uVar35 < uVar29)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101de6;
                    func_0x(*(undefined8 *)(&stack0x00000b30 + lVar14),7);
                    uVar42 = (ulonglong)*(ushort *)(&stack0x00000b44 + lVar14);
                    uVar28 = *(uint *)(&stack0x00000b40 + lVar14);
                    uVar44 = (ulonglong)*(uint *)(&stack0x00000b3c + lVar14);
                  }
                  *(uint *)(&stack0x00000344 + lVar14) = uVar35 - uVar29;
                  *(uint *)(&stack0x00000348 + lVar14) = uVar29;
                  if ((uVar29 < uVar28) || (*(uint *)(&stack0x00000b2c + lVar14) < uVar29)) {
                    iVar11 = *(int *)(&stack0x00000030 + lVar14);
                    *(int *)(&stack0x00000030 + lVar14) = iVar11 + 1;
                    *(int *)(&stack0x000001a4 + lVar14) = iVar11 + 1;
                    goto LAB_;
                  }
                  uVar40 = *(ushort *)((ulonglong)uVar29 + *(longlong *)(&stack0x00000b30 + lVar14))
                  ;
                  *(ushort *)(&stack0x0000021c + lVar14) = uVar40;
                  if (uVar40 == 5) {
                    puVar22 = *(ushort **)(&stack0x00000060 + lVar14);
                    *puVar22 = *puVar22 | 2;
                    puVar22[0xd] = puVar22[0xd] - 1;
                    *(uint *)(&stack0x00000350 + lVar14) = uVar35 - uVar29;
                    *(ushort **)(&stack0x00000778 + lVar14) = puVar22 + 0x14;
                    puVar22[0x14] = (ushort)uVar29;
                    lVar30 = (ulonglong)(uVar29 & 0xffff) + *(longlong *)(puVar22 + 3);
                    *(longlong *)(&stack0x00000780 + lVar14) = lVar30;
                    uVar40 = *(ushort *)(lVar30 + 2);
                    puVar22[0x15] = puVar22[0x15] & 0xc7ff;
                    if ((uVar40 & 0x4000) != 0) {
                      puVar22[0x15] = puVar22[0x15] | uVar40 & 0x3800;
                    }
                    puVar22[0x15] =
                         (puVar22[0x15] ^ *(ushort *)(lVar30 + 2)) & 0x7ff ^ puVar22[0x15];
                    break;
                  }
                  if (uVar40 < 0x400) break;
                  *(ushort *)(&stack0x00000b2a + lVar14) =
                       *(ushort *)(&stack0x00000b2a + lVar14) | 1;
                  uVar40 = (short)uVar42 - 1;
                  uVar42 = (ulonglong)uVar40;
                  *(ushort *)(&stack0x00000b44 + lVar14) = uVar40;
                } while (uVar40 != 0);
              }
              lVar30 = *(longlong *)(&stack0x00000060 + lVar14);
              ppbVar33 = (byte **)(lVar30 + 6);
              iVar11 = 0;
              if ((**ppbVar33 & 0x40) == 0) {
                *(undefined4 *)(*(longlong *)(&stack0x00000060 + lVar14) + 0x24) = 0;
              }
              else {
                *(undefined4 *)(lVar30 + 0x24) = *(undefined4 *)(lVar30 + 2);
                *(int *)(lVar30 + 2) = *(int *)(lVar30 + 2) + 0xe;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101f51;
                puVar15 = (ulonglong *)func_0x(lVar30);
                *(ulonglong **)(&stack0x00000788 + lVar14) = puVar15;
                uVar44 = *puVar15;
                *(ulonglong *)(&stack0x00000410 + lVar14) = uVar44;
                *(undefined4 *)(&stack0x000001a0 + lVar14) = 0;
                uVar40 = (ushort)(uVar44 >> 0x30);
                if ((((uint)(int)(short)uVar40 >> 1 ^ (int)(short)uVar40) & 0x2000) != 0) {
                  if ((uVar44 & 0x4000000000000000) == 0) {
                    uVar40 = uVar40 & 0xdfff;
                  }
                  else {
                    uVar40 = uVar40 | 0x2000;
                  }
                }
                *(ushort *)(&stack0x000001d4 + lVar14) = uVar40;
                if (uVar40 == 0xfffc) {
                  *(undefined **)(&stack0x00000790 + lVar14) = &stack0x00000410 + lVar14;
                  iVar11 = (int)((uVar44 >> 0x20 & 0xffff) >> 5);
                  *(int *)(&stack0x000001a0 + lVar14) = iVar11;
                }
                *(int *)(lVar30 + 2) = *(int *)(lVar30 + 2) + iVar11;
              }
              pbVar41 = *(byte **)(*(longlong *)(&stack0x00000060 + lVar14) + 0x1c);
              if ((pbVar41 != (byte *)0x0) &&
                 (pbVar41 < *ppbVar33 + *(uint *)(*(longlong *)(&stack0x00000060 + lVar14) + 2))) {
                *(int *)(&stack0x00000030 + lVar14) = *(int *)(&stack0x00000030 + lVar14) + 1;
                if ((DAT_ != '\0') ||
                   ((&stack0x000000a0)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                  *(undefined4 *)(&stack0x00000358 + lVar14) = 0x58;
                  lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000798 + lVar14) = lVar30;
                  lVar30 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x000007a0 + lVar14) = lVar30;
                  *(longlong *)(&stack0x000007a8 + lVar14) = lVar30;
                  lVar30 = *(longlong *)(lVar30 + 8);
                  *(longlong *)(&stack0x000007b0 + lVar14) = lVar30;
                  *(longlong *)(&stack0x000007b8 + lVar14) = lVar30;
                  if (lVar30 == 0) {
                    *(undefined8 *)(&stack0x00000418 + lVar14) = 0;
                  }
                  else {
                    lVar30 = *(longlong *)(lVar30 + 0x60);
                    *(longlong *)(&stack0x00000418 + lVar14) = lVar30;
                    if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                      if ((DAT_ == '\0') &&
                         ((&stack0x000000dc)[lVar14] = DAT_ >> 1,
                         (DAT_ >> 1 & 1) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1020f5;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10211b;
                        (*_DAT_)(1,0x1517798,0x1637468,0x877);
                      }
                    }
                  }
                }
                pbVar41 = *ppbVar33;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102132;
                func_0x(pbVar41,0x12);
              }
              if (0x3f3b < *(int *)(*(longlong *)(&stack0x00000060 + lVar14) + 2) - 1U) {
                *(int *)(&stack0x00000030 + lVar14) = *(int *)(&stack0x00000030 + lVar14) + 1;
                if ((DAT_ != '\0') ||
                   ((&stack0x000000a2)[lVar14] = DAT_, (DAT_ & 1) != 0)) {
                  *(undefined4 *)(&stack0x0000035c + lVar14) = 0x58;
                  lVar30 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x000007c0 + lVar14) = lVar30;
                  lVar30 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar30 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x000007c8 + lVar14) = lVar30;
                  *(longlong *)(&stack0x000007d0 + lVar14) = lVar30;
                  lVar30 = *(longlong *)(lVar30 + 8);
                  *(longlong *)(&stack0x000007d8 + lVar14) = lVar30;
                  *(longlong *)(&stack0x000007e0 + lVar14) = lVar30;
                  if (lVar30 == 0) {
                    *(undefined8 *)(&stack0x00000420 + lVar14) = 0;
                  }
                  else {
                    lVar30 = *(longlong *)(lVar30 + 0x60);
                    *(longlong *)(&stack0x00000420 + lVar14) = lVar30;
                    if ((lVar30 != 0) && (*(char *)(lVar30 + 0x499) != '\0')) {
                      if ((DAT_ == '\0') &&
                         ((&stack0x000000a3)[lVar14] = DAT_ >> 1,
                         (DAT_ >> 1 & 1) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102218;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10223e;
                        (*_DAT_)(1,0x1517798,0x1637468,0x87c);
                      }
                    }
                  }
                }
                pbVar41 = *ppbVar33;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102255;
                func_0x(pbVar41,5);
              }
              uVar12 = *(undefined4 *)(&stack0x00000030 + lVar14);
              *(undefined4 *)(&stack0x00000030 + lVar14) = uVar12;
              *(undefined4 *)(&stack0x000001a4 + lVar14) = uVar12;
            }
LAB_:
            uVar28 = *(uint *)(*(longlong *)(&stack0x00000060 + lVar14) + 2);
            if (uVar28 < 9) {
              pbVar41 = *(byte **)(*(longlong *)(&stack0x00000060 + lVar14) + 6);
              *(byte **)(&stack0x000007e8 + lVar14) = pbVar41;
              bVar25 = *pbVar41 & 0xe;
              (&stack0x000000a4)[lVar14] = bVar25;
              if ((bVar25 == 0) || (bVar25 == 0xc)) {
                uVar28 = 9;
              }
            }
            *(uint *)(&stack0x00000360 + lVar14) = uVar28;
            *(uint *)(&stack0x0000013c + lVar14) = uVar28;
            if ((&stack0x00000029)[lVar14] != '\0') goto LAB_;
          }
          else {
            uVar28 = *(uint *)(&stack0x00000b2c + lVar14);
            if (uVar28 == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102458;
              func_0x(&stack0x00000b2a + lVar14);
              uVar28 = *(uint *)(&stack0x00000b2c + lVar14);
            }
            if ((uVar28 < 9) &&
               (((**(byte **)(&stack0x00000b30 + lVar14) & 0x1c) == 0 ||
                ((**(byte **)(&stack0x00000b30 + lVar14) & 0x1c) == 0xc)))) {
              uVar28 = 9;
            }
            *(uint *)(&stack0x0000013c + lVar14) = uVar28;
          }
          iVar11 = (1 << ((byte)*(undefined2 *)(lVar34 + 4) & 2)) + -1;
          *(int *)(&stack0x00000364 + lVar14) = iVar11;
          uVar40 = (ushort)iVar11;
          *(int *)(&stack0x00000368 + lVar14) = iVar11;
          if ((ushort)(*(short *)(&stack0x000000e0 + lVar14) + uVar40 & ~uVar40) <
              (ushort)((short)uVar28 + uVar40 & ~uVar40)) {
            if ((&stack0x00002d28)[lVar14] == '\0') {
              puVar21 = *(undefined8 **)(&stack0x00000140 + lVar14);
              if (puVar21 != (undefined8 *)0x0) {
                pcVar3 = *(code **)*puVar21;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1024fb;
                (*pcVar3)(puVar21,1);
              }
              goto LAB_;
            }
LAB_:
            sVar9 = -1;
            *(undefined2 *)(&stack0x00000a68 + lVar14) = 0xffff;
            ppbVar33 = (byte **)0x0;
            *(undefined8 *)(&stack0x00000a70 + lVar14) = 0;
            *(undefined4 *)(&stack0x00000a6c + lVar14) = 0;
            *(undefined8 *)(&stack0x00000a86 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000a90 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000a78 + lVar14) = 0;
            *(undefined4 *)(&stack0x00000a9c + lVar14) = 0xffffffff;
            *(undefined4 *)(&stack0x000001a8 + lVar14) = 0;
            ppbVar43 = ppbVar33;
            while( true ) {
              iVar11 = (int)ppbVar43;
              if ((int)(uint)*(ushort *)(lVar34 + 0x16) <= iVar11) break;
              if ((iVar11 == *(int *)(&stack0x00000068 + lVar14)) ||
                 (*(short *)(lVar34 + (0xfff - (longlong)iVar11) * 2) == 0)) {
                ppbVar43 = (byte **)(ulonglong)(iVar11 + 1U);
                *(uint *)(&stack0x000001a8 + lVar14) = iVar11 + 1U;
              }
              else {
                *(int *)(&stack0x00000a9c + lVar14) = iVar11;
                if (*(char *)(lVar34 + 2) < '\0') {
                  pbVar41 = (byte *)(lVar34 + 0x60);
                  if (*(short *)(&stack0x00000a68 + lVar14) == 0) {
                    *(undefined8 *)(&stack0x000001c0 + lVar14) = 0;
LAB_:
                    *(undefined (*) [16])(&stack0x00000aa0 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000ab0 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000ac0 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000ad0 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000ae0 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000af0 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000b00 + lVar14) = ZEXT816(0);
                    *(undefined8 *)(&stack0x00000b10 + lVar14) = 0;
                    *(undefined (*) [16])(&stack0x00000aa0 + lVar14) = ZEXT816(0);
                    *(short *)(&stack0x00000ab0 + lVar14) = sVar9;
                    *(undefined8 *)(&stack0x00000ab8 + lVar14) = 0;
                    *(undefined4 *)(&stack0x00000ab4 + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000ace + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000ad8 + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000ac0 + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000ae8 + lVar14) = 0;
                    *(undefined4 *)(&stack0x00000b00 + lVar14) = 0;
                    *(undefined4 *)(&stack0x00000b04 + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000b08 + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000b0a + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000b12 + lVar14) = 0;
                    ppbVar33 = (byte **)(&stack0x00000aa0 + lVar14);
                    *(byte ***)(&stack0x000001c0 + lVar14) = ppbVar33;
                  }
                  else {
                    *(byte ***)(&stack0x000001c0 + lVar14) = ppbVar33;
                    if (ppbVar33 == (byte **)0x0) goto LAB_;
                  }
                  (&stack0x00000051)[lVar14] = 0;
                  if (*(short *)(lVar34 + 0x24) == 0) {
LAB_:
                    *(undefined8 *)(&stack0x00000190 + lVar14) = *(undefined8 *)(lVar34 + 0x28);
                    *(undefined2 *)(&stack0x00000198 + lVar14) = *(undefined2 *)(lVar34 + 0x30);
                  }
                  else {
                    cVar8 = *(char *)(lVar34 + 1);
                    if (cVar8 == '\v') {
                      if (*(int *)(lVar34 + 0x18) == 99) goto LAB_;
LAB_:
                      if (cVar8 == '\t') goto LAB_;
LAB_:
                      cVar8 = '\0';
                    }
                    else {
                      if (cVar8 != '\b') goto LAB_;
LAB_:
                      if (*(int *)(lVar34 + 0x18) != 99) goto LAB_;
LAB_:
                      *(undefined4 *)(&stack0x000001e8 + lVar14) = *(undefined4 *)(lVar34 + 0x20);
                      *(undefined2 *)(&stack0x000001ec + lVar14) = *(undefined2 *)(lVar34 + 0x24);
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102716;
                      cVar8 = func_0x(&stack0x000001e8 + lVar14);
                      if (cVar8 == '\0') goto LAB_;
                      cVar8 = '\x01';
                    }
                    (&stack0x00000051)[lVar14] = cVar8;
                    if (cVar8 == '\0') goto LAB_;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10273b;
                    func_0x(lVar34,&stack0x00000190 + lVar14);
                  }
                  *ppbVar33 = pbVar41;
                  uVar10 = *(undefined2 *)(&stack0x00000198 + lVar14);
                  uVar12 = *(undefined4 *)(&stack0x00000194 + lVar14);
                  *(undefined4 *)(ppbVar33 + 0xc) = *(undefined4 *)(&stack0x00000190 + lVar14);
                  *(undefined4 *)((longlong)ppbVar33 + 100) = uVar12;
                  *(undefined2 *)(ppbVar33 + 0xd) = uVar10;
                  *(undefined4 *)((longlong)ppbVar33 + 0x6c) = *(undefined4 *)(lVar34 + 0x20);
                  *(undefined2 *)(ppbVar33 + 0xe) = *(undefined2 *)(lVar34 + 0x24);
                  *(undefined2 *)((longlong)ppbVar33 + 0x72) = 0;
                  bVar25 = *pbVar41;
                  *(undefined4 *)(&stack0x000002d8 + lVar14) =
                       *(undefined4 *)((ulonglong)bVar25 * 6 + 0x1314280);
                  uVar44 = (ulonglong)*(short *)((ulonglong)bVar25 * 6 + 0x1314284);
                  *(short *)(ppbVar33 + 2) = sVar9;
                  ppbVar33[3] = (byte *)0x0;
                  uVar29 = 0;
                  *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
                  *(undefined8 *)((longlong)ppbVar33 + 0x2e) = 0;
                  ppbVar33[7] = (byte *)0x0;
                  ppbVar33[4] = (byte *)0x0;
                  ppbVar33[9] = (byte *)0x0;
                  ppbVar33[10] = (byte *)0x0;
                  *(undefined2 *)(ppbVar33 + 0xb) = 0;
                  if ((**ppbVar33 & 2) != 0) {
                    pbVar31 = pbVar41 + uVar44;
                    bVar25 = *pbVar31;
                    *(ushort *)(ppbVar33 + 2) = (ushort)(bVar25 & 1);
                    if ((bVar25 & 1) == 0) {
                      *(undefined4 *)(&stack0x000000d0 + lVar14) = 0;
                      ppbVar33[3] = pbVar31;
                      *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
                      *(undefined4 *)((longlong)ppbVar33 + 0x36) = 0;
                      pbVar5 = ppbVar33[3];
                      switch(*pbVar5 & 0xe) {
                      default:
                        uVar40 = *(ushort *)(pbVar31 + 2);
                        uVar29 = (uint)uVar40;
                        *(uint *)(&stack0x000000d0 + lVar14) = (uint)uVar40;
                        if (uVar40 - 1 < 0x1f9e) goto code_r0x001028bc;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10284f;
                        func_0x(pbVar5,6);
                        *(uint *)(ppbVar33 + 4) = (uint)uVar40;
                        *(undefined8 *)((longlong)ppbVar33 + 0x2e) = 0;
                        break;
                      case 4:
                        *(undefined4 *)(&stack0x000000d0 + lVar14) = 9;
                        *(undefined4 *)(ppbVar33 + 4) = 9;
                        *(undefined8 *)((longlong)ppbVar33 + 0x2e) = 0;
                        break;
                      case 6:
                      case 10:
code_r0x001028bc:
                        *(uint *)(ppbVar33 + 4) = uVar29;
                        *(undefined8 *)((longlong)ppbVar33 + 0x2e) = 0;
                        break;
                      case 0xe:
                        *(undefined4 *)(&stack0x000000d0 + lVar14) = 1;
                        *(undefined4 *)(ppbVar33 + 4) = 1;
                        *(undefined8 *)((longlong)ppbVar33 + 0x2e) = 0;
                      }
                    }
                    else {
                      ppbVar33[3] = pbVar31;
                      bVar25 = *pbVar31;
                      switch(bVar25 & 0x1c) {
                      default:
                        if ((char)pbVar31[1] < '\0') {
                          uVar40 = *(ushort *)(pbVar31 + 1);
                          *(ushort *)((longlong)ppbVar33 + 0x12) = uVar40;
                          *(ushort *)((longlong)ppbVar33 + 0x12) =
                               (uVar40 & 0x7f) << 8 | uVar40 >> 8;
                          uVar10 = 3;
                          sVar9 = 3;
                        }
                        else {
                          *(ushort *)((longlong)ppbVar33 + 0x12) = (ushort)pbVar31[1];
                          uVar10 = 2;
                          sVar9 = 2;
                        }
                        *(undefined2 *)(ppbVar33 + 5) = uVar10;
                        *(short *)((longlong)ppbVar33 + 0x2c) =
                             (short)(*(ushort *)((longlong)ppbVar33 + 0x12) + 1 >> 1) + sVar9;
                        if (*(ushort *)((longlong)ppbVar33 + 0x12) < 0x1f) {
                          *(undefined2 *)((longlong)ppbVar33 + 0x2a) = 0;
                          *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
                          *(undefined4 *)(ppbVar33 + 8) = 0;
                        }
                        else {
                          iVar13 = *(ushort *)((longlong)ppbVar33 + 0x12) - 1;
                          *(short *)((longlong)ppbVar33 + 0x2a) =
                               ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                               (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
                          *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
                          *(undefined4 *)(ppbVar33 + 8) = 0;
                        }
                        break;
                      case 4:
                        if (((bVar25 & 0x1c) == 4) && ((bVar25 & 2) != 0)) {
                          ppbVar33[3] = (byte *)0x0;
                          *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
                          *(undefined2 *)(ppbVar33 + 5) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x12) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x2a) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x2c) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x2e) = 0;
                          *(undefined2 *)(ppbVar33 + 6) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x32) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x34) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x36) = 0;
                          ppbVar33[4] = (byte *)0x0;
                          *(undefined4 *)(ppbVar33 + 8) = 0;
                          ppbVar33[7] = (byte *)0x0;
                          ppbVar33[3] = pbVar31;
                          *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0xf;
                          *(undefined4 *)(ppbVar33 + 8) = 0;
                          *(undefined4 *)(ppbVar33 + 8) = 1;
                        }
                        else {
                          ppbVar33[3] = (byte *)0x0;
                          *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
                          *(undefined2 *)(ppbVar33 + 5) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x12) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x2a) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x2c) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x2e) = 0;
                          *(undefined2 *)(ppbVar33 + 6) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x32) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x34) = 0;
                          *(undefined2 *)((longlong)ppbVar33 + 0x36) = 0;
                          ppbVar33[4] = (byte *)0x0;
                          *(undefined4 *)(ppbVar33 + 8) = 0;
                          ppbVar33[7] = (byte *)0x0;
                          ppbVar33[3] = pbVar31;
                          *(undefined4 *)((longlong)ppbVar33 + 0x14) = 1;
                          *(undefined4 *)(ppbVar33 + 8) = 0;
                        }
                        break;
                      case 8:
                        ppbVar33[3] = (byte *)0x0;
                        *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
                        *(undefined2 *)(ppbVar33 + 5) = 0;
                        *(undefined2 *)((longlong)ppbVar33 + 0x12) = 0;
                        *(undefined2 *)((longlong)ppbVar33 + 0x2a) = 0;
                        *(undefined2 *)((longlong)ppbVar33 + 0x2c) = 0;
                        *(undefined2 *)((longlong)ppbVar33 + 0x2e) = 0;
                        *(undefined2 *)(ppbVar33 + 6) = 0;
                        *(undefined2 *)((longlong)ppbVar33 + 0x32) = 0;
                        *(undefined2 *)((longlong)ppbVar33 + 0x34) = 0;
                        *(undefined2 *)((longlong)ppbVar33 + 0x36) = 0;
                        ppbVar33[4] = (byte *)0x0;
                        *(undefined4 *)(ppbVar33 + 8) = 0;
                        ppbVar33[7] = (byte *)0x0;
                        ppbVar33[3] = pbVar31;
                        *(undefined4 *)((longlong)ppbVar33 + 0x14) = 9;
                        *(undefined4 *)(ppbVar33 + 8) = 0;
                      }
                      ppbVar33[7] = (byte *)0x0;
                      ppbVar33[4] = (byte *)0x0;
                    }
                  }
                  if ((**ppbVar33 & 4) != 0) {
                    if (*(short *)(&stack0x000002da + lVar14) != 0) {
                      uVar44 = (ulonglong)
                               *(ushort *)
                                (lVar34 + 0x61 + (longlong)*(short *)(&stack0x000002da + lVar14) * 2
                                );
                    }
                    psVar23 = (short *)(pbVar41 + uVar44);
                    ppbVar33[9] = (byte *)psVar23;
                    sVar9 = *psVar23;
                    ppbVar33[10] = (byte *)(psVar23 + 1);
                    *(short *)(ppbVar33 + 0xb) = (sVar9 + 1) * 2;
                  }
                  pbVar41 = ppbVar33[1];
                  if (pbVar41 != (byte *)0x0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102b0a;
                    func_0x(pbVar41,ppbVar33);
                  }
                  lVar34 = *(longlong *)(&stack0x000001c8 + lVar14);
                }
                else {
                  *(undefined8 *)(&stack0x000001c0 + lVar14) = 0;
                  ppbVar33 = (byte **)0x0;
                }
                uVar40 = *(ushort *)(lVar34 + 0xe);
                uVar29 = (uint)uVar40;
                pbVar41 = (byte *)((ulonglong)*(ushort *)(lVar34 + (0xfff - (longlong)iVar11) * 2) +
                                  lVar34);
                bVar25 = *pbVar41;
                *(ushort *)(&stack0x00000a68 + lVar14) = (ushort)(bVar25 & 1);
                if ((bVar25 & 1) == 0) {
                  *(uint *)(&stack0x000000e8 + lVar14) = (uint)uVar40;
                  *(byte **)(&stack0x00000a70 + lVar14) = pbVar41;
                  *(undefined4 *)(&stack0x00000a6c + lVar14) = 0;
                  *(undefined4 *)(&stack0x00000a8e + lVar14) = 0;
                  switch(*pbVar41 & 0xe) {
                  default:
                    uVar40 = *(ushort *)(pbVar41 + 2);
                    uVar29 = (uint)uVar40;
                    *(uint *)(&stack0x000000e8 + lVar14) = (uint)uVar40;
                    if (0x1f9d < uVar40 - 1) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102ba3;
                      func_0x(pbVar41,6);
                    }
                    break;
                  case 4:
                    uVar29 = 9;
                    *(undefined4 *)(&stack0x000000e8 + lVar14) = 9;
                    break;
                  case 6:
                  case 10:
                    break;
                  case 0xe:
                    uVar29 = 1;
                    *(undefined4 *)(&stack0x000000e8 + lVar14) = 1;
                  }
                  *(uint *)(&stack0x00000a78 + lVar14) = uVar29;
                  *(longlong *)(&stack0x00000a86 + lVar14) = lVar34 + 0x2000;
                  ppbVar33 = *(byte ***)(&stack0x00000a78 + lVar14);
                }
                else {
                  *(byte **)(&stack0x00000a70 + lVar14) = pbVar41;
                  bVar25 = *pbVar41;
                  switch(bVar25 & 0x1c) {
                  default:
                    uVar40 = (ushort)pbVar41[1];
                    if ((char)pbVar41[1] < '\0') {
                      uVar40 = *(ushort *)(pbVar41 + 1);
                      *(ushort *)(&stack0x00000a6a + lVar14) = uVar40;
                      uVar40 = uVar40 >> 8 | (uVar40 & 0x7f) << 8;
                      sVar9 = 3;
                    }
                    else {
                      sVar9 = 2;
                    }
                    *(ushort *)(&stack0x00000a6a + lVar14) = uVar40;
                    *(short *)(&stack0x00000a80 + lVar14) = sVar9;
                    *(short *)(&stack0x00000a84 + lVar14) = (short)(uVar40 + 1 >> 1) + sVar9;
                    if (uVar40 < 0x1f) {
                      *(undefined2 *)(&stack0x00000a82 + lVar14) = 0;
                      *(undefined4 *)(&stack0x00000a6c + lVar14) = 0;
                      *(undefined4 *)(&stack0x00000a98 + lVar14) = 0;
                    }
                    else {
                      iVar13 = uVar40 - 1;
                      *(short *)(&stack0x00000a82 + lVar14) =
                           ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                           (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
                      *(undefined4 *)(&stack0x00000a6c + lVar14) = 0;
                      *(undefined4 *)(&stack0x00000a98 + lVar14) = 0;
                    }
                    break;
                  case 4:
                    if (((bVar25 & 0x1c) == 4) && ((bVar25 & 2) != 0)) {
                      *(undefined8 *)(&stack0x00000a70 + lVar14) = 0;
                      *(undefined4 *)(&stack0x00000a6c + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a80 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a6a + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a82 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a84 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a86 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a88 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a8a + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a8c + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a8e + lVar14) = 0;
                      *(undefined8 *)(&stack0x00000a78 + lVar14) = 0;
                      *(undefined4 *)(&stack0x00000a98 + lVar14) = 0;
                      *(undefined8 *)(&stack0x00000a90 + lVar14) = 0;
                      *(byte **)(&stack0x00000a70 + lVar14) = pbVar41;
                      *(undefined4 *)(&stack0x00000a6c + lVar14) = 0xf;
                      *(undefined4 *)(&stack0x00000a98 + lVar14) = 0;
                      *(undefined4 *)(&stack0x00000a98 + lVar14) = 1;
                    }
                    else {
                      *(undefined8 *)(&stack0x00000a70 + lVar14) = 0;
                      *(undefined4 *)(&stack0x00000a6c + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a80 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a6a + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a82 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a84 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a86 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a88 + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a8a + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a8c + lVar14) = 0;
                      *(undefined2 *)(&stack0x00000a8e + lVar14) = 0;
                      *(undefined8 *)(&stack0x00000a78 + lVar14) = 0;
                      *(undefined4 *)(&stack0x00000a98 + lVar14) = 0;
                      *(undefined8 *)(&stack0x00000a90 + lVar14) = 0;
                      *(byte **)(&stack0x00000a70 + lVar14) = pbVar41;
                      *(undefined4 *)(&stack0x00000a6c + lVar14) = 1;
                      *(undefined4 *)(&stack0x00000a98 + lVar14) = 0;
                    }
                    break;
                  case 8:
                    *(undefined8 *)(&stack0x00000a70 + lVar14) = 0;
                    *(undefined4 *)(&stack0x00000a6c + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a80 + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a6a + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a82 + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a84 + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a86 + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a88 + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a8a + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a8c + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a8e + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000a78 + lVar14) = 0;
                    *(undefined4 *)(&stack0x00000a98 + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000a90 + lVar14) = 0;
                    *(byte **)(&stack0x00000a70 + lVar14) = pbVar41;
                    *(undefined4 *)(&stack0x00000a6c + lVar14) = 9;
                    *(undefined4 *)(&stack0x00000a98 + lVar14) = 0;
                  }
                  *(longlong *)(&stack0x00000a90 + lVar14) = lVar34 + 0x2000;
                  *(byte ***)(&stack0x00000a78 + lVar14) = ppbVar33;
                }
                if (*(short *)(&stack0x00000a68 + lVar14) == 0) {
                  bVar25 = **(byte **)(&stack0x00000a70 + lVar14) >> 6;
                }
                else {
                  bVar25 = **(byte **)(&stack0x00000a70 + lVar14) >> 1;
                }
                if ((bVar25 & 1) == 0) {
                  sVar9 = (bVar25 & 1) - 1;
                  ppbVar43 = (byte **)(ulonglong)(iVar11 + 1U);
                  *(uint *)(&stack0x000001a8 + lVar14) = iVar11 + 1U;
                }
                else {
                  *(undefined4 *)(&stack0x00000110 + lVar14) =
                       **(undefined4 **)(&stack0x00000178 + lVar14);
                  *(undefined2 *)(&stack0x00000114 + lVar14) =
                       *(undefined2 *)(*(undefined4 **)(&stack0x00000178 + lVar14) + 1);
                  *(short *)(&stack0x00000116 + lVar14) = (short)ppbVar43;
                  *(undefined8 *)((longlong)alStackX_18 + lVar14) =
                       *(undefined8 *)(&stack0x00000078 + lVar14);
                  *(undefined8 *)((longlong)alStackX_8 + lVar14 + 8) =
                       *(undefined8 *)(&stack0x00000170 + lVar14);
                  *(undefined *)((longlong)alStackX_8 + lVar14) = 0;
                  cVar8 = (&stack0x00002d20)[lVar14];
                  *(char *)((longlong)alStackX_18 + lVar14 + -0x18) = cVar8;
                  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar14) =
                       *(undefined8 *)(&stack0x00000058 + lVar14);
                  *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x00000110 + lVar14;
                  *(longlong *)(&stack0xffffffffffffffe8 + lVar14) = lVar34;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102fee;
                  iVar13 = FUN_(*(undefined8 *)(&stack0x00000048 + lVar14),
                                        *(undefined8 *)(&stack0x00000130 + lVar14),
                                        *(undefined8 *)(&stack0x00000180 + lVar14));
                  if (iVar13 == 3) {
                    if (cVar8 == '\0') {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10301b;
                      (*_DAT_)(1,0x16cca88,0x169c448,0x14b5);
                    }
                    (&stack0x00000028)[lVar14] = 0;
                    *(undefined4 *)(&stack0x00000038 + lVar14) = 3;
                    goto LAB_;
                  }
                  if (iVar13 == 2) {
                    (&stack0x00000028)[lVar14] = 0;
                    *(undefined4 *)(&stack0x00000038 + lVar14) = 2;
                    goto LAB_;
                  }
                  ppbVar33 = *(byte ***)(&stack0x00000a78 + lVar14);
                  sVar9 = -1;
                  ppbVar43 = (byte **)(ulonglong)(iVar11 + 1U);
                  *(uint *)(&stack0x000001a8 + lVar14) = iVar11 + 1U;
                }
              }
            }
          }
          else if ((&stack0x00000050)[lVar14] != '\0') goto LAB_;
          if ((&stack0x00000028)[lVar14] != '\0') {
            bVar25 = (&stack0x00000090)[lVar14];
            (&stack0x00000090)[lVar14] = bVar25 & 0xfe;
            (&stack0x00000090)[lVar14] = bVar25 & 0xfc;
            bVar26 = 0;
            lVar30 = *(longlong *)(&stack0x00000180 + lVar14);
            if (*(int *)(lVar30 + 0x38) == 3) {
              bVar26 = 4;
            }
            (&stack0x00000090)[lVar14] = bVar26 | bVar25 & 0xf8;
            bVar25 = *(byte *)(lVar30 + 0x78);
            uVar20 = *(undefined8 *)(lVar30 + 0x58);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1030f7;
            func_0x(&stack0x00000080 + lVar14,uVar20,bVar25 >> 5 & 1);
            uVar20 = *(undefined8 *)(lVar30 + 0x58);
            uVar19 = *(undefined8 *)(&stack0x00000048 + lVar14);
            uVar27 = *(undefined8 *)(&stack0x00000130 + lVar14);
            if ((&stack0x00000036)[lVar14] == '\0') {
              *(undefined4 *)(&stack0x00000968 + lVar14) =
                   *(undefined4 *)(&stack0x00000080 + lVar14);
              *(undefined4 *)(&stack0x0000096c + lVar14) =
                   *(undefined4 *)(&stack0x00000084 + lVar14);
              *(undefined4 *)(&stack0x00000970 + lVar14) =
                   *(undefined4 *)(&stack0x00000088 + lVar14);
              *(undefined4 *)(&stack0x00000974 + lVar14) =
                   *(undefined4 *)(&stack0x0000008c + lVar14);
              *(undefined8 *)(&stack0x00000978 + lVar14) =
                   *(undefined8 *)(&stack0x00000090 + lVar14);
              *(undefined **)((longlong)alStackX_18 + lVar14) = &stack0x00000968 + lVar14;
              *(undefined8 *)((longlong)alStackX_8 + lVar14 + 8) =
                   *(undefined8 *)(&stack0x00000b30 + lVar14);
              *(uint *)((longlong)alStackX_8 + lVar14) = uVar28;
              *(undefined4 *)((longlong)alStackX_18 + lVar14 + -0x18) =
                   *(undefined4 *)(&stack0x000000e0 + lVar14);
              *(undefined4 *)(&stack0xfffffffffffffff8 + lVar14) = 0;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar14) =
                   *(undefined4 *)(&stack0x00000068 + lVar14);
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1031dd;
              func_0x
                        (*(undefined8 *)(&stack0x00000078 + lVar14),uVar20,uVar27,uVar19);
              *(longlong *)(*(longlong *)(&stack0x00000188 + lVar14) + 0x200) =
                   *(longlong *)(*(longlong *)(&stack0x00000188 + lVar14) + 0x200) + 1;
              *(undefined4 *)(&stack0x00000038 + lVar14) = 4;
            }
            else {
              *(undefined4 *)(&stack0x00000948 + lVar14) =
                   *(undefined4 *)(&stack0x00000080 + lVar14);
              *(undefined4 *)(&stack0x0000094c + lVar14) =
                   *(undefined4 *)(&stack0x00000084 + lVar14);
              *(undefined4 *)(&stack0x00000950 + lVar14) =
                   *(undefined4 *)(&stack0x00000088 + lVar14);
              *(undefined4 *)(&stack0x00000954 + lVar14) =
                   *(undefined4 *)(&stack0x0000008c + lVar14);
              *(undefined8 *)(&stack0x00000958 + lVar14) =
                   *(undefined8 *)(&stack0x00000090 + lVar14);
              *(undefined **)(&stack0xfffffffffffffff8 + lVar14) = &stack0x00000b28 + lVar14;
              *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x00000948 + lVar14;
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) =
                   *(undefined4 *)(&stack0x00000068 + lVar14);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103166;
              func_0x(*(undefined8 *)(&stack0x00000078 + lVar14));
              *(longlong *)(*(longlong *)(&stack0x00000188 + lVar14) + 0x200) =
                   *(longlong *)(*(longlong *)(&stack0x00000188 + lVar14) + 0x200) + 1;
              *(undefined4 *)(&stack0x00000038 + lVar14) = 4;
            }
          }
        }
        else {
LAB_:
          (&stack0x00000029)[lVar14] = 1;
LAB_:
          bVar25 = 0;
          if ((&stack0x00000036)[lVar14] == '\0') {
            lVar30 = *(longlong *)(&stack0x00000180 + lVar14);
            *(undefined8 *)(&stack0x00000168 + lVar14) = *(undefined8 *)(lVar30 + 0x58);
            *(undefined **)(&stack0x000007f0 + lVar14) = &stack0x00000288 + lVar14;
            *(undefined4 *)(&stack0x00000288 + lVar14) = 0;
            *(undefined2 *)(&stack0x0000028c + lVar14) = 0;
            *(undefined4 *)(&stack0x00000290 + lVar14) = 0;
            *(undefined **)(&stack0x000007f8 + lVar14) = &stack0x00000294 + lVar14;
            *(undefined4 *)(&stack0x00000294 + lVar14) = 0;
            *(undefined2 *)(&stack0x00000298 + lVar14) = 0;
            *(undefined2 *)(&stack0x0000029a + lVar14) = 0;
            *(undefined8 *)(&stack0x000002a0 + lVar14) = 0;
            *(undefined8 *)(&stack0x000002a8 + lVar14) = 0x78;
            *(undefined8 *)(&stack0x000002b0 + lVar14) = 0;
            *(undefined **)(&stack0x000002b8 + lVar14) = &stack0x00000c78 + lVar14;
            *(undefined **)(&stack0x000002c8 + lVar14) = &stack0x00000c7c + lVar14;
            (&stack0x000002d0)[lVar14] = 0;
            (&stack0x000002d1)[lVar14] = 0;
            (&stack0x000002d2)[lVar14] = 0;
            *(undefined **)(&stack0x000002c0 + lVar14) = &stack0x00000c78 + lVar14;
            *(undefined2 *)(&stack0x00000298 + lVar14) = 0;
            *(undefined4 *)(&stack0x00000294 + lVar14) = 0;
            *(undefined **)(&stack0x00000800 + lVar14) = &stack0x00000c78 + lVar14;
            (&stack0x00000c78)[lVar14] = 0;
            (&stack0x00000c79)[lVar14] = 0;
            (&stack0x00000c7a)[lVar14] = 0;
            (&stack0x00000c7b)[lVar14] = 4;
            (&stack0x00000bd8)[lVar14] = 0;
            *(undefined4 *)(&stack0x00000bdc + lVar14) = 0xffffffff;
            *(undefined4 *)(&stack0x00000be0 + lVar14) = 0;
            *(undefined (*) [16])(&stack0x00000be8 + lVar14) = ZEXT816(0);
            *(undefined4 *)(&stack0x00000bf8 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000c08 + lVar14) = 0;
            *(undefined4 *)(&stack0x00000c10 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000c18 + lVar14) = 0;
            (&stack0x00000a66)[lVar14] = 1;
            *(undefined4 *)(&stack0x00000c34 + lVar14) = 0;
            (&stack0x00000c38)[lVar14] = 0;
            *(undefined **)(&stack0x00000808 + lVar14) = &stack0x00000c40 + lVar14;
            *(undefined8 *)(&stack0x00000c40 + lVar14) = 0;
            lVar34 = *(longlong *)(&stack0x00000188 + lVar14);
            uVar10 = *(undefined2 *)(lVar34 + 0x6b8);
            *(undefined2 *)(&stack0x000001e0 + lVar14) = uVar10;
            (&stack0x00000bd8)[lVar14] = 5;
            *(longlong *)(&stack0x00000be8 + lVar14) =
                 *(longlong *)(&stack0x00000048 + lVar14) + 0x38;
            *(undefined4 *)(&stack0x00000be0 + lVar14) = 0x2000000;
            (&stack0x00000a66)[lVar14] = 9;
            *(undefined2 *)(&stack0x00000a64 + lVar14) = uVar10;
            *(undefined4 *)(&stack0x00000a60 + lVar14) = 0;
            *(undefined **)(&stack0x00000810 + lVar14) = &stack0x00000a58 + lVar14;
            *(undefined4 **)(&stack0x00000818 + lVar14) = puVar36;
            *(undefined **)(&stack0x00000820 + lVar14) = &stack0x00000a58 + lVar14;
            *(undefined4 *)(&stack0x00000a58 + lVar14) = *puVar36;
            *(undefined2 *)(&stack0x00000a5c + lVar14) = *(undefined2 *)(puVar36 + 1);
            *(undefined2 *)(&stack0x00000a5e + lVar14) = *(undefined2 *)((longlong)puVar36 + 6);
            *(undefined4 *)(&stack0x00000bdc + lVar14) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103453;
            iVar11 = func_0x
                               (&stack0x00000bd8 + lVar14,&stack0x00000a58 + lVar14,
                                &stack0x00000c28 + lVar14,0);
            *(int *)(&stack0x0000036c + lVar14) = iVar11;
            if (iVar11 < 0) {
              if ((&stack0x00002d20)[lVar14] == '\0') {
                *(undefined4 *)(&stack0x00000bdc + lVar14) = 0xffffffff;
                uVar20 = *(undefined8 *)(&stack0x00000078 + lVar14);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103494;
                func_0x(uVar20);
                cVar8 = (&stack0x00000a66)[lVar14];
                if (cVar8 == '\x05') {
                  iVar11 = *(int *)(&stack0x00000a5c + lVar14);
joined_r0x00103521:
                  if (iVar11 != 0) goto LAB_;
LAB_:
                  if (_DAT_ == 0) goto LAB_;
                  if (cVar8 == '\x02') {
                    uVar28 = (uint)*(byte *)((ulonglong)(byte)(&stack0x00000bd8)[lVar14] + 0x1c51d60
                                            );
                  }
                  else {
                    uVar28 = *(uint *)((ulonglong)(byte)(&stack0x00000bd8)[lVar14] * 0x14 +
                                      0x1c52da0);
                  }
                  *(uint *)(&stack0x00000370 + lVar14) = uVar28;
                  if (uVar28 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1036a3;
                    iVar11 = func_0x
                                       (&stack0x00000bd8 + lVar14,&stack0x00000a58 + lVar14,
                                        &stack0x00000c28 + lVar14);
                  }
                  else {
                    *(undefined **)(&stack0x00000828 + lVar14) = &stack0x00000c28 + lVar14;
                    *(longlong *)(&stack0x00000830 + lVar14) =
                         *(longlong *)(&stack0x00000be8 + lVar14);
                    *(undefined4 *)(&stack0x00000c5c + lVar14) = 0;
                    (&stack0x00000c60)[lVar14] = 0;
                    *(undefined **)(&stack0x00000838 + lVar14) = &stack0x00000c68 + lVar14;
                    *(undefined8 *)(&stack0x00000c68 + lVar14) = 0;
                    *(undefined **)(&stack0x00000840 + lVar14) = &stack0x00000c28 + lVar14;
                    uVar12 = *(undefined4 *)(*(longlong *)(&stack0x00000be8 + lVar14) + 0x7c);
                    *(undefined4 *)(&stack0x00000378 + lVar14) = uVar12;
                    if (cVar8 == '\x02') {
                      *(undefined **)(&stack0x00000858 + lVar14) = &stack0x00000a58 + lVar14;
LAB_:
                      *(undefined4 *)(&stack0x00000a60 + lVar14) = uVar12;
                    }
                    else {
                      if (cVar8 == '\x05') {
                        *(undefined **)(&stack0x00000850 + lVar14) = &stack0x00000a58 + lVar14;
                        goto LAB_;
                      }
                      if (cVar8 == '\v') {
                        *(undefined **)(&stack0x00000848 + lVar14) = &stack0x00000a58 + lVar14;
                        *(short *)(&stack0x00000a62 + lVar14) = (short)uVar12;
                      }
                    }
                    *(uint *)(&stack0x00000c10 + lVar14) =
                         *(uint *)(&stack0x00000c10 + lVar14) | 0x20;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103645;
                    iVar11 = func_0x
                                       (&stack0x00000bd8 + lVar14,&stack0x00000a58 + lVar14,
                                        &stack0x00000c28 + lVar14,0);
                    *(int *)(&stack0x000001ac + lVar14) = iVar11;
                    *(uint *)(&stack0x00000c10 + lVar14) =
                         *(uint *)(&stack0x00000c10 + lVar14) & 0xffffffdf;
                    if (iVar11 == -5) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10367a;
                      iVar11 = func_0x
                                         (&stack0x00000bd8 + lVar14,&stack0x00000a58 + lVar14,
                                          &stack0x00000c28 + lVar14);
                      *(int *)(&stack0x000001ac + lVar14) = iVar11;
                    }
                  }
                }
                else {
                  if (cVar8 == '\v') {
                    if (DAT_ != '\0') goto LAB_;
                  }
                  else if (cVar8 == '\x02') {
                    iVar11 = *(int *)(&stack0x00000a58 + lVar14);
                    goto joined_r0x00103521;
                  }
LAB_:
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1034cb;
                  iVar11 = func_0x
                                     (&stack0x00000bd8 + lVar14,&stack0x00000a58 + lVar14,
                                      &stack0x00000c28 + lVar14,0);
                  *(int *)(&stack0x00000380 + lVar14) = iVar11;
                }
                *(int *)(&stack0x000000f4 + lVar14) = iVar11;
                if (iVar11 < 0) {
                  if (iVar11 != -1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1034f7;
                    func_0x(*(undefined4 *)(&stack0x000000f4 + lVar14),0x19);
                  }
                  *(undefined4 *)(&stack0x00000038 + lVar14) = 3;
                }
                else {
                  (&stack0xfffffffffffffff8)[lVar14] = 1;
                  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) = 0;
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1036d1;
                  func_0x(uVar20,4,0xffffffff,&stack0x00000490 + lVar14);
                  *(undefined4 *)(&stack0x00000038 + lVar14) = 2;
                }
              }
              else {
                *(undefined4 *)(&stack0x00000038 + lVar14) = 3;
              }
            }
            else if (*(int *)(&stack0x00000038 + lVar14) == 0) {
              lVar18 = *(longlong *)(&stack0x00000168 + lVar14);
              plVar16 = *(longlong **)(*(longlong *)(lVar18 + 8) + 0x488);
              if (((plVar16 != (longlong *)0x0) &&
                  (cVar8 = *_DAT_, (&stack0x000000a5)[lVar14] = cVar8, cVar8 != '\0')) &&
                 ((&stack0x000000a6)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) == 0)) {
                *(longlong **)(&stack0x00000430 + lVar14) = plVar16;
                *(undefined8 *)(&stack0x00000860 + lVar14) = 1;
                *(longlong **)(&stack0x00000868 + lVar14) = plVar16;
                if (plVar16[1] != 0) {
                  *(undefined4 *)(&stack0x00000384 + lVar14) = 0x58;
                  lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000870 + lVar14) = lVar24;
                  lVar38 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x00000878 + lVar14) = lVar38;
                  lVar24 = *(longlong *)(lVar38 + 0x100);
                  *(longlong *)(&stack0x00000428 + lVar14) = lVar24;
                  if (lVar24 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1037b0;
                    (*_DAT_)(0);
                    lVar24 = *(longlong *)(lVar38 + 0x100);
                    *(longlong *)(&stack0x00000428 + lVar14) = lVar24;
                  }
                  lVar24 = *(longlong *)(lVar24 + 0x260);
                  *(longlong *)(&stack0x00000880 + lVar14) = lVar24;
                  uVar44 = 0;
                  if (lVar24 != 0) {
                    uVar44 = (ulonglong)*(uint *)(lVar24 + 0xe68);
                  }
                  uVar28 = (uint)uVar44;
                  *(uint *)(&stack0x00000388 + lVar14) = uVar28;
                  *(uint *)(&stack0x0000038c + lVar14) = uVar28;
                  if (uVar28 < *(uint *)(_DAT_ + 8)) {
                    lVar24 = *(longlong *)(plVar16[1] + uVar44 * 8);
                    *(longlong *)(&stack0x00000888 + lVar14) = lVar24;
                    *(longlong *)(lVar24 + 8) = *(longlong *)(lVar24 + 8) + 1;
                    goto LAB_;
                  }
                  plVar16 = *(longlong **)(&stack0x00000430 + lVar14);
                }
                plVar16 = (longlong *)(*plVar16 + 8);
                *(longlong **)(&stack0x00000890 + lVar14) = plVar16;
                LOCK();
                lVar24 = *plVar16;
                *plVar16 = *plVar16 + 1;
                UNLOCK();
                *(longlong *)(&stack0x00000898 + lVar14) = lVar24 + 1;
              }
LAB_:
              if (*(int *)(&stack0x00000c34 + lVar14) != 0) {
                lVar24 = *(longlong *)(*(longlong *)(lVar18 + 8) + 0x488);
                if (((lVar24 != 0) &&
                    (cVar8 = *_DAT_, (&stack0x000000a7)[lVar14] = cVar8, cVar8 != '\0')) &&
                   ((&stack0x000000a8)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) == 0)) {
                  *(longlong *)(&stack0x000008a0 + lVar14) = lVar24;
                  *(undefined8 *)(&stack0x000008a8 + lVar14) = 0x16;
                  plVar16 = (longlong *)(lVar24 + 0x18);
                  *(longlong **)(&stack0x00000440 + lVar14) = plVar16;
                  if (*(longlong *)(lVar24 + 0x20) != 0) {
                    *(undefined4 *)(&stack0x00000390 + lVar14) = 0x58;
                    lVar38 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                    *(longlong *)(&stack0x000008b0 + lVar14) = lVar38;
                    lVar39 = (ulonglong)*_DAT_ +
                             *(longlong *)(lVar38 + (ulonglong)*_DAT_ * 8);
                    *(longlong *)(&stack0x000008b8 + lVar14) = lVar39;
                    lVar38 = *(longlong *)(lVar39 + 0x100);
                    *(longlong *)(&stack0x00000438 + lVar14) = lVar38;
                    if (lVar38 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103919;
                      (*_DAT_)(0);
                      lVar38 = *(longlong *)(lVar39 + 0x100);
                      *(longlong *)(&stack0x00000438 + lVar14) = lVar38;
                    }
                    lVar38 = *(longlong *)(lVar38 + 0x260);
                    *(longlong *)(&stack0x000008c0 + lVar14) = lVar38;
                    if (lVar38 == 0) {
                      uVar44 = 0;
                    }
                    else {
                      uVar44 = (ulonglong)*(uint *)(lVar38 + 0xe68);
                    }
                    uVar28 = (uint)uVar44;
                    *(uint *)(&stack0x00000394 + lVar14) = uVar28;
                    *(uint *)(&stack0x00000398 + lVar14) = uVar28;
                    if (uVar28 < *(uint *)(_DAT_ + 8)) {
                      lVar24 = *(longlong *)(*(longlong *)(lVar24 + 0x20) + uVar44 * 8);
                      *(longlong *)(&stack0x000008c8 + lVar14) = lVar24;
                      *(longlong *)(lVar24 + 0xb0) = *(longlong *)(lVar24 + 0xb0) + 1;
                      goto LAB_;
                    }
                    plVar16 = *(longlong **)(&stack0x00000440 + lVar14);
                  }
                  plVar16 = (longlong *)(*plVar16 + 0xb0);
                  *(longlong **)(&stack0x000008d0 + lVar14) = plVar16;
                  LOCK();
                  lVar24 = *plVar16;
                  *plVar16 = *plVar16 + 1;
                  UNLOCK();
                  *(longlong *)(&stack0x000008d8 + lVar14) = lVar24 + 1;
                }
LAB_:
                uVar44 = (ulonglong)*(uint *)(&stack0x00000c34 + lVar14);
                *(ulonglong *)(&stack0x00000268 + lVar14) = uVar44;
                if (((uVar44 != 0) &&
                    (lVar18 = *(longlong *)(*(longlong *)(lVar18 + 8) + 0x488), lVar18 != 0)) &&
                   ((cVar8 = *_DAT_, (&stack0x000000a9)[lVar14] = cVar8, cVar8 != '\0' &&
                    ((&stack0x000000aa)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) == 0)))
                   ) {
                  *(longlong *)(&stack0x000008e0 + lVar14) = lVar18;
                  *(undefined8 *)(&stack0x000008e8 + lVar14) = 0x17;
                  plVar16 = (longlong *)(lVar18 + 0x18);
                  *(longlong **)(&stack0x00000450 + lVar14) = plVar16;
                  if (*(longlong *)(lVar18 + 0x20) != 0) {
                    *(undefined4 *)(&stack0x0000039c + lVar14) = 0x58;
                    lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                    *(longlong *)(&stack0x000008f0 + lVar14) = lVar24;
                    lVar38 = (ulonglong)*_DAT_ +
                             *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8);
                    *(longlong *)(&stack0x000008f8 + lVar14) = lVar38;
                    lVar24 = *(longlong *)(lVar38 + 0x100);
                    *(longlong *)(&stack0x00000448 + lVar14) = lVar24;
                    if (lVar24 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103a94;
                      (*_DAT_)(0);
                      lVar24 = *(longlong *)(lVar38 + 0x100);
                      *(longlong *)(&stack0x00000448 + lVar14) = lVar24;
                    }
                    lVar24 = *(longlong *)(lVar24 + 0x260);
                    *(longlong *)(&stack0x00000900 + lVar14) = lVar24;
                    if (lVar24 == 0) {
                      uVar44 = 0;
                    }
                    else {
                      uVar44 = (ulonglong)*(uint *)(lVar24 + 0xe68);
                    }
                    uVar28 = (uint)uVar44;
                    *(uint *)(&stack0x000003a0 + lVar14) = uVar28;
                    *(uint *)(&stack0x000003a4 + lVar14) = uVar28;
                    if (uVar28 < *(uint *)(_DAT_ + 8)) {
                      lVar18 = *(longlong *)(*(longlong *)(lVar18 + 0x20) + uVar44 * 8);
                      *(longlong *)(&stack0x00000908 + lVar14) = lVar18;
                      *(longlong *)(lVar18 + 0xb8) =
                           *(longlong *)(lVar18 + 0xb8) + *(longlong *)(&stack0x00000268 + lVar14);
                      goto LAB_;
                    }
                    plVar16 = *(longlong **)(&stack0x00000450 + lVar14);
                    uVar44 = *(ulonglong *)(&stack0x00000268 + lVar14);
                  }
                  LOCK();
                  *(longlong *)(*plVar16 + 0xb8) = *(longlong *)(*plVar16 + 0xb8) + uVar44;
                  UNLOCK();
                }
              }
LAB_:
              puVar6 = *(undefined **)(&stack0x000002b8 + lVar14);
              *(undefined **)(&stack0x000002c0 + lVar14) = puVar6;
              *(undefined **)(&stack0x00000910 + lVar14) = puVar6;
              *puVar6 = 0;
              puVar6[1] = 0;
              puVar6[2] = 0;
              puVar6[3] = 4;
              *(longlong *)(&stack0x000002c8 + lVar14) =
                   *(longlong *)(&stack0x000002b8 + lVar14) + 4;
              *(undefined8 *)(&stack0x000002b0 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103b76;
              uVar20 = func_0x(*(undefined8 *)(&stack0x00000168 + lVar14));
              *(undefined8 *)(&stack0x00000458 + lVar14) = uVar20;
              *(undefined *)(*(longlong *)(&stack0x000002c0 + lVar14) + 2) = 0;
              (&stack0x000002d2)[lVar14] = 1;
              *(undefined **)(&stack0xffffffffffffffe8 + lVar14) = &stack0x00000458 + lVar14;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103bb8;
              func_0x(&stack0x00000288 + lVar14,1,1,8);
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103bd4;
              func_0x(&stack0x00000288 + lVar14,1,2);
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103bf0;
              func_0x(&stack0x00000288 + lVar14,2,3);
              bVar25 = (&stack0x000000b0)[lVar14];
              (&stack0x000000b0)[lVar14] = bVar25 & 0xfe;
              (&stack0x000000b0)[lVar14] = bVar25 & 0xfc;
              (&stack0x000000b0)[lVar14] = bVar25 & 0xf8;
              (&stack0x000000b0)[lVar14] = bVar25 & 0xf0;
              (&stack0x000000b0)[lVar14] = bVar25 & 0xe0;
              (&stack0x000000b0)[lVar14] = bVar25 & 0xc0;
              (&stack0x000000b1)[lVar14] = 0;
              (&stack0x000000b2)[lVar14] = 0;
              *(undefined8 *)(&stack0x000000b8 + lVar14) = 0;
              bVar25 = (&stack0x000000c0)[lVar14];
              (&stack0x000000c0)[lVar14] = bVar25 & 0xfe;
              (&stack0x000000c0)[lVar14] = bVar25 & 0xfc;
              (&stack0x000000c0)[lVar14] = bVar25 & 0xf8;
              (&stack0x000000c0)[lVar14] = bVar25 & 0xf0;
              bVar25 = bVar25 & 0xe0;
              (&stack0x000000c0)[lVar14] = bVar25;
              (&stack0x000000c0)[lVar14] = bVar25;
              (&stack0x000000c0)[lVar14] = bVar25;
              bVar26 = 0;
              if (*(int *)(lVar30 + 0x38) == 3) {
                bVar26 = 4;
              }
              (&stack0x000000c0)[lVar14] = bVar26 | bVar25;
              bVar25 = *(byte *)(lVar30 + 0x78);
              uVar20 = *(undefined8 *)(lVar30 + 0x58);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103cc9;
              func_0x(&stack0x000000b0 + lVar14,uVar20,bVar25 >> 5 & 1);
              (&stack0x000000c0)[lVar14] = (&stack0x000000c0)[lVar14] & 0xef;
              *(undefined4 *)(&stack0x000009a8 + lVar14) =
                   *(undefined4 *)(&stack0x000000b0 + lVar14);
              *(undefined4 *)(&stack0x000009ac + lVar14) =
                   *(undefined4 *)(&stack0x000000b4 + lVar14);
              *(undefined4 *)(&stack0x000009b0 + lVar14) =
                   *(undefined4 *)(&stack0x000000b8 + lVar14);
              *(undefined4 *)(&stack0x000009b4 + lVar14) =
                   *(undefined4 *)(&stack0x000000bc + lVar14);
              *(undefined8 *)(&stack0x000009b8 + lVar14) =
                   *(undefined8 *)(&stack0x000000c0 + lVar14);
              *(undefined **)(&stack0xfffffffffffffff8 + lVar14) = &stack0x000009a8 + lVar14;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar14) =
                   *(undefined4 *)(&stack0x00000068 + lVar14);
              *(undefined **)(&stack0xffffffffffffffe8 + lVar14) = &stack0x00000288 + lVar14;
              uVar20 = *(undefined8 *)(lVar30 + 0x58);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103d39;
              func_0x(*(undefined8 *)(&stack0x00000078 + lVar14),uVar20,
                              *(undefined8 *)(&stack0x00000130 + lVar14),
                              *(undefined8 *)(&stack0x00000048 + lVar14));
              plVar16 = (longlong *)(lVar34 + 0x200);
              *plVar16 = *plVar16 + 1;
              *(undefined4 *)(&stack0x00000038 + lVar14) = 4;
            }
            plVar16 = *(longlong **)(&stack0x00000c08 + lVar14);
            if (plVar16 != (longlong *)0x0) {
              plVar32 = plVar16 + 1;
              LOCK();
              iVar11 = *(int *)plVar32;
              *(int *)plVar32 = *(int *)plVar32 + -1;
              UNLOCK();
              *(int *)(&stack0x000001d8 + lVar14) = iVar11 + -1;
              if (iVar11 + -1 == 0) {
                if (plVar32 == (longlong *)0x0) {
                  plVar16 = (longlong *)0x0;
                }
                pcVar3 = *(code **)(*plVar16 + 8);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103d7c;
                (*pcVar3)();
              }
            }
          }
          else {
            bVar26 = (&stack0x000000f8)[lVar14];
            (&stack0x000000f8)[lVar14] = bVar26 & 0xfe;
            (&stack0x000000f8)[lVar14] = bVar26 & 0xfc;
            (&stack0x000000f8)[lVar14] = bVar26 & 0xf8;
            (&stack0x000000f8)[lVar14] = bVar26 & 0xf0;
            (&stack0x000000f8)[lVar14] = bVar26 & 0xe0;
            (&stack0x000000f8)[lVar14] = bVar26 & 0xc0;
            (&stack0x000000f9)[lVar14] = 0;
            (&stack0x000000fa)[lVar14] = 0;
            *(undefined8 *)(&stack0x00000100 + lVar14) = 0;
            bVar26 = (&stack0x00000108)[lVar14];
            (&stack0x00000108)[lVar14] = bVar26 & 0xfe;
            (&stack0x00000108)[lVar14] = bVar26 & 0xfc;
            (&stack0x00000108)[lVar14] = bVar26 & 0xf8;
            (&stack0x00000108)[lVar14] = bVar26 & 0xf0;
            bVar26 = bVar26 & 0xe0;
            (&stack0x00000108)[lVar14] = bVar26;
            (&stack0x00000108)[lVar14] = bVar26;
            (&stack0x00000108)[lVar14] = bVar26;
            lVar30 = *(longlong *)(&stack0x00000180 + lVar14);
            if (*(int *)(lVar30 + 0x38) == 3) {
              bVar25 = 4;
            }
            (&stack0x00000108)[lVar14] = bVar25 | bVar26;
            bVar25 = *(byte *)(lVar30 + 0x78);
            uVar20 = *(undefined8 *)(lVar30 + 0x58);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1023be;
            func_0x(&stack0x000000f8 + lVar14,uVar20,bVar25 >> 5 & 1);
            *(undefined4 *)(&stack0x00000988 + lVar14) = *(undefined4 *)(&stack0x000000f8 + lVar14);
            *(undefined4 *)(&stack0x0000098c + lVar14) = *(undefined4 *)(&stack0x000000fc + lVar14);
            *(undefined4 *)(&stack0x00000990 + lVar14) = *(undefined4 *)(&stack0x00000100 + lVar14);
            *(undefined4 *)(&stack0x00000994 + lVar14) = *(undefined4 *)(&stack0x00000104 + lVar14);
            *(undefined8 *)(&stack0x00000998 + lVar14) = *(undefined8 *)(&stack0x00000108 + lVar14);
            *(undefined8 *)(&stack0xfffffffffffffff8 + lVar14) = 0;
            *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x00000988 + lVar14;
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) =
                 *(undefined4 *)(&stack0x00000068 + lVar14);
            uVar20 = *(undefined8 *)(lVar30 + 0x58);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10241e;
            func_0x(*(undefined8 *)(&stack0x00000078 + lVar14),uVar20,
                            *(undefined8 *)(&stack0x00000130 + lVar14),
                            *(undefined8 *)(&stack0x00000048 + lVar14));
            lVar30 = *(longlong *)(&stack0x00000188 + lVar14);
            plVar16 = (longlong *)(lVar30 + 0x200);
            *plVar16 = *plVar16 + 1;
            plVar16 = (longlong *)(lVar30 + 0x3d8);
            *plVar16 = *plVar16 + 1;
            *(undefined4 *)(&stack0x00000038 + lVar14) = 4;
          }
        }
LAB_:
        if (((&stack0x00002d28)[lVar14] != '\0') && (*(longlong *)(&stack0x00000258 + lVar14) == 0))
        {
          pcVar3 = *(code **)(**(longlong **)(&stack0x00000140 + lVar14) + 0x28);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103d9f;
          (*pcVar3)();
        }
      }
    }
  }
  lVar34 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar30 = *(longlong *)(lVar34 + 0x100);
  if (lVar30 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103dd1;
    (*_DAT_)();
    lVar30 = *(longlong *)(lVar34 + 0x100);
  }
  if (*(int *)(lVar30 + 0x22c) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103de7;
    (*_DAT_)();
  }
  puVar21 = *(undefined8 **)(&stack0x00000140 + lVar14);
  if (puVar21 != (undefined8 *)0x0) {
    pcVar3 = *(code **)*puVar21;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103dff;
    (*pcVar3)(puVar21,1);
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103e13;
  func_0x
            (*(ulonglong *)(&stack0x00002c98 + lVar14) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar14));
  return;
}

