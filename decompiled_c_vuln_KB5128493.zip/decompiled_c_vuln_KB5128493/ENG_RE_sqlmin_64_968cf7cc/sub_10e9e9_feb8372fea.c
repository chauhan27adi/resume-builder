
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(void)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong unaff_RDI;
  undefined8 *puStack0000000000000088;
  
  uVar2 = *(undefined8 *)(unaff_RDI + 0x1f0);
  lVar1 = *(longlong *)(unaff_RDI + 0x20);
  puStack0000000000000088 = (undefined8 *)(lVar1 + 0x180);
  *puStack0000000000000088 = uVar2;
  uVar2 = (*_DAT_)(0x100,uVar2,0x24c7b57,0x270,1);
  *(undefined8 *)(lVar1 + 400) = uVar2;
  func_0x(uVar2,0,0x100);
  *(undefined4 *)(lVar1 + 0x188) = 0x20;
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

