
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,longlong param_3,undefined8 param_4)

{
  short *psVar1;
  byte *pbVar2;
  uint *puVar3;
  uint *puVar4;
  undefined8 uVar5;
  bool bVar6;
  char cVar7;
  short sVar8;
  int iVar9;
  int iVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  short *psVar14;
  ulonglong *puVar15;
  longlong lVar16;
  undefined8 uVar17;
  byte **ppbVar18;
  byte **ppbVar19;
  longlong lVar20;
  byte bVar21;
  ushort uVar22;
  ushort uVar23;
  uint uVar24;
  uint uVar25;
  ushort *puVar26;
  byte **ppbVar27;
  undefined *puVar28;
  undefined *puVar29;
  undefined *puVar30;
  longlong lVar31;
  uint uVar32;
  longlong lVar33;
  byte **ppbVar34;
  uint uVar35;
  byte *pbVar36;
  uint uVar37;
  undefined2 uVar38;
  longlong *plVar39;
  undefined4 uVar40;
  ulonglong uVar41;
  ulonglong uVar42;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  longlong *plStackX_10;
  uint uStackX_18;
  uint uStackX_1c;
  longlong lStackX_20;
  undefined8 uStack_58;
  undefined auStack_50 [8];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  puVar30 = &stack0xffffffffffffffc0 + lVar11;
  puVar29 = &stack0xffffffffffffffc0 + lVar11;
  puVar28 = &stack0xffffffffffffffc0 + lVar11;
  lVar12 = lVar11 + -0x40;
  puVar3 = (uint *)((longlong)&lStackX_20 + lVar11 + -0x20);
  *(undefined8 *)(&stack0x000001b0 + lVar11) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x0000bbb0 + lVar11) = _DAT_ ^ (ulonglong)puVar3;
  *(undefined8 *)(&stack0x000000e0 + lVar11) = param_4;
  *(longlong *)(&stack0x00000040 + lVar11) = param_3;
  *(longlong ***)((longlong)&plStackX_10 + lVar11) = param_2;
  *(undefined8 *)(&stack0x00000140 + lVar11) = *(undefined8 *)(&stack0x0000bc30 + lVar11);
  *(undefined (*) [16])(&stack0x00000270 + lVar11) = ZEXT816(0);
  *(undefined2 *)(&stack0x00000280 + lVar11) = 0xffff;
  ppbVar27 = (byte **)0x0;
  *(undefined8 *)(&stack0x00000288 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000284 + lVar11) = 0;
  *(undefined8 *)(&stack0x0000029e + lVar11) = 0;
  *(undefined8 *)(&stack0x000002a8 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000290 + lVar11) = 0;
  *(undefined8 *)(&stack0x000002b8 + lVar11) = 0;
  *(undefined8 *)(&stack0x000002d0 + lVar11) = 0;
  *(undefined4 *)(&stack0x000002d8 + lVar11) = 0;
  *(undefined2 *)(&stack0x000002e2 + lVar11) = 0;
  lVar13 = param_1;
  if (param_1 == 0) {
    lVar13 = **param_2;
  }
  *(longlong *)((longlong)&lStackX_20 + lVar11) = lVar13;
  uVar23 = *(ushort *)(lVar13 + 0x16);
  *(uint *)((longlong)auStackX_8 + lVar11) = (uint)uVar23;
  uVar22 = *(ushort *)(**(longlong **)(*(longlong *)(param_3 + 8) + 0x160) + 0x10);
  *(ushort *)puVar3 = uVar22;
  *(undefined4 *)(&stack0x00000028 + lVar11) = 0;
  bVar21 = -(*(char *)(lVar13 + 2) >> 7);
  *(uint *)((longlong)&uStackX_1c + lVar11) = (uint)bVar21;
  if ((uVar23 == 1) && (bVar21 == 0)) goto LAB_;
  *(undefined2 *)(&stack0x000001b8 + lVar11) = 0xffff;
  *(undefined8 *)(&stack0x000001c0 + lVar11) = 0;
  *(undefined4 *)(&stack0x000001bc + lVar11) = 0;
  *(undefined8 *)(&stack0x000001d6 + lVar11) = 0;
  *(undefined8 *)(&stack0x000001e0 + lVar11) = 0;
  *(undefined4 *)(&stack0x000001ec + lVar11) = 0xffffffff;
  *(undefined8 *)(&stack0x000002f0 + lVar11) = 0;
  *(undefined8 *)(&stack0x000002f8 + lVar11) = 0;
  *(undefined2 *)(&stack0x00000300 + lVar11) = 0xffff;
  *(undefined8 *)(&stack0x00000308 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000304 + lVar11) = 0;
  *(undefined8 *)(&stack0x0000031e + lVar11) = 0;
  *(undefined8 *)(&stack0x00000328 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000310 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000338 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000350 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000358 + lVar11) = 0;
  *(undefined2 *)(&stack0x00000362 + lVar11) = 0;
  *(undefined (*) [16])(&stack0x00000370 + lVar11) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000380 + lVar11) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000390 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000398 + lVar11) = 0;
  *(undefined8 *)(&stack0x000003a0 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000dc8 + lVar11) = 0;
  *(undefined8 *)(&stack0x00005860 + lVar11) = 0;
  *(undefined4 *)(&stack0x00007c68 + lVar11) = 0;
  *(undefined (*) [16])(&stack0x00000dd0 + lVar11) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000de0 + lVar11) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000df0 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000df8 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000e00 + lVar11) = 0;
  *(undefined4 *)(&stack0x00001828 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000df4 + lVar11) = 1;
  *(undefined (*) [16])(&stack0x00000200 + lVar11) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000210 + lVar11) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000220 + lVar11) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000230 + lVar11) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000240 + lVar11) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000250 + lVar11) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000260 + lVar11) = 0;
  *(undefined (*) [16])(&stack0x000001f0 + lVar11) = ZEXT816(0);
  *(undefined2 *)(&stack0x00000200 + lVar11) = 0xffff;
  *(undefined8 *)(&stack0x00000208 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000204 + lVar11) = 0;
  *(undefined8 *)(&stack0x0000021e + lVar11) = 0;
  *(undefined8 *)(&stack0x00000228 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000210 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000238 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000250 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000258 + lVar11) = 0;
  *(undefined2 *)(&stack0x00000262 + lVar11) = 0;
  *(undefined **)(&stack0x000001c8 + lVar11) = &stack0x000001f0 + lVar11;
  ppbVar19 = (byte **)(&stack0x000001f0 + lVar11);
  if (*(short *)(&stack0x000001b8 + lVar11) == 0) {
    ppbVar19 = ppbVar27;
  }
  if ((ppbVar19[1] == (byte *)0x0) &&
     (ppbVar19[1] = &stack0x00000dd0 + lVar11, *ppbVar19 != (byte *)0x0)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1002c3;
    func_0x(&stack0x00000dd0 + lVar11);
  }
  *(undefined **)(&stack0x00000378 + lVar11) = &stack0x00005860 + lVar11;
  *(undefined4 *)(&stack0x00000394 + lVar11) = 1;
  if ((*(longlong *)(&stack0x000002f8 + lVar11) == 0) &&
     (*(undefined **)(&stack0x000002f8 + lVar11) = &stack0x00000370 + lVar11,
     *(longlong *)(&stack0x000002f0 + lVar11) != 0)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10030d;
    func_0x(&stack0x00000370 + lVar11,&stack0x000002f0 + lVar11);
  }
  uVar23 = (ushort)*(uint *)((longlong)auStackX_8 + lVar11);
  ppbVar19 = ppbVar27;
  if (uVar23 == 0) {
    lVar12 = *(longlong *)(&stack0x00000040 + lVar11);
    if ((*(char *)(*(longlong *)(lVar12 + 8) + 0x751) != '\0') && (bVar21 == 0)) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10034d;
      (*_DAT_)(1,0x18dec60,0x18b1de8,0xb8);
    }
    uVar24 = *(uint *)(&stack0x0000bc38 + lVar11);
    lVar13 = *(longlong *)((longlong)&lStackX_20 + lVar11);
LAB_:
    ppbVar34 = (byte **)(ulonglong)*(uint *)((longlong)auStackX_8 + lVar11);
    puVar29 = puVar28;
LAB_:
    ppbVar18 = (byte **)(&stack0x000002f0 + lVar11);
    if (*(longlong *)(&stack0x000002f0 + lVar11) == 0) {
      ppbVar18 = ppbVar27;
    }
    *(undefined2 *)(&stack0x00000178 + lVar11) = 0xffff;
    *(undefined8 *)(&stack0x00000180 + lVar11) = 0;
    *(undefined4 *)(&stack0x0000017c + lVar11) = 0;
    *(undefined8 *)(&stack0x00000196 + lVar11) = 0;
    *(undefined8 *)(&stack0x000001a0 + lVar11) = 0;
    *(undefined8 *)(&stack0x00000188 + lVar11) = 0;
    *(undefined **)(&stack0x00000150 + lVar11) = &stack0x00007c70 + lVar11;
    *(undefined4 *)(&stack0x00000158 + lVar11) = 0x3f3c;
    *(byte ***)(&stack0x00000160 + lVar11) = ppbVar19;
    *(short *)(&stack0x00000168 + lVar11) = (short)ppbVar34;
    *(byte ***)(&stack0x00000170 + lVar11) = ppbVar18;
    puVar30 = puVar29;
    if (param_2 == (longlong **)0x0) {
      ppbVar19 = (byte **)0x1;
      if ((*(char *)(lVar13 + 1) == '\x01') && ((uVar24 & 1) == 0)) {
        ppbVar19 = ppbVar27;
      }
      *(undefined8 *)(puVar29 + -8) = 0x1033c8;
      func_0x(lVar13,&stack0x00000150 + lVar11,ppbVar19);
    }
    else {
      lVar12 = *(longlong *)(lVar12 + 8);
      *(uint *)(puVar29 + 0x28) = uVar24;
      *(undefined **)(puVar29 + 0x20) = &stack0x00000150 + lVar11;
      uVar17 = *(undefined8 *)(&stack0x000000e0 + lVar11);
      *(undefined8 *)(puVar29 + -8) = 0x1033a4;
      func_0x(param_2,ppbVar34,lVar12 + 0x3c0,uVar17);
    }
  }
  else {
    uVar25 = 0;
    uVar37 = 0;
    if (uVar23 == 1) {
      if (*(short *)(lVar13 + 0x1ffe) != 0) {
        *(undefined8 *)(&stack0x000000a0 + lVar11) = 0;
        *(undefined4 *)(&stack0x0000009c + lVar11) = 0;
        *(undefined8 *)(&stack0x000000b6 + lVar11) = 0;
        *(undefined8 *)(&stack0x000000c0 + lVar11) = 0;
        *(undefined8 *)(&stack0x000000a8 + lVar11) = 0;
        *(undefined4 *)((longlong)&uStackX_1c + lVar11) = 2;
        if (param_2 != (longlong **)0x0) {
          plVar39 = *param_2;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1003e2;
          lVar12 = func_0x(_DAT_,plVar39,1,0);
          *(ushort *)(lVar12 + 4) = *(ushort *)(lVar12 + 4) & 0xedff;
          *(undefined4 *)(lVar12 + 0x40) = 1;
          plVar39 = *param_2;
          if (*(short *)((longlong)plVar39 + 0x2c) != 2) {
            lVar12 = plVar39[0x12];
            if (lVar12 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100410;
              func_0x(plVar39);
              lVar12 = plVar39[0x12];
              plVar39 = *param_2;
            }
            if (((*(byte *)(*(longlong *)(lVar12 + 0x6b0) + 0x3c) & 1) != 0) &&
               (*(longlong *)(*(longlong *)(lVar12 + 0x6b0) + 0x280) == 0)) {
              lVar12 = plVar39[0x12];
              if (lVar12 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100445;
                func_0x(plVar39);
                lVar12 = plVar39[0x12];
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100451;
              cVar7 = func_0x(lVar12);
              if (cVar7 == '\0') goto LAB_;
            }
            plVar39 = *param_2;
            lVar12 = plVar39[0x12];
            if (lVar12 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100470;
              func_0x(plVar39);
              lVar12 = plVar39[0x12];
            }
            if ((*(byte *)(lVar12 + 0x1cd0) & 0x20) == 0) {
              lVar12 = **param_2;
              if (*(short *)(lVar12 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x00000108 + lVar11) = *(undefined8 *)(lVar12 + 0x28);
                uVar23 = *(ushort *)(lVar12 + 0x30);
              }
              else {
                cVar7 = *(char *)(lVar12 + 1);
                if (cVar7 == '\v') {
                  if (*(int *)(lVar12 + 0x18) != 99) {
LAB_:
                    if (cVar7 != '\t') goto LAB_;
                    goto LAB_;
                  }
                }
                else {
                  if (cVar7 != '\b') goto LAB_;
LAB_:
                  if (*(int *)(lVar12 + 0x18) != 99) goto LAB_;
                }
                *(undefined4 *)(&stack0x000000e8 + lVar11) = *(undefined4 *)(lVar12 + 0x20);
                *(undefined2 *)(&stack0x000000ec + lVar11) = *(undefined2 *)(lVar12 + 0x24);
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1004d5;
                cVar7 = func_0x(&stack0x000000e8 + lVar11);
                if (cVar7 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1004e8;
                func_0x(lVar12,&stack0x00000108 + lVar11);
                uVar23 = *(ushort *)(&stack0x00000110 + lVar11);
              }
              plVar39 = *param_2;
              lVar12 = plVar39[0x12];
              if (lVar12 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10051c;
                func_0x(plVar39);
                lVar12 = plVar39[0x12];
              }
              uVar38 = *(undefined2 *)((longlong)plVar39 + 0x74);
              uVar17 = *(undefined8 *)(lVar12 + 0x6a0);
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100537;
              lVar13 = func_0x(uVar17,uVar38,0);
              param_2 = *(longlong ***)((longlong)&plStackX_10 + lVar11);
              plVar39 = *param_2;
              lVar12 = plVar39[0x12];
              if (lVar12 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100559;
                func_0x(plVar39);
                lVar12 = plVar39[0x12];
                plVar39 = *param_2;
              }
              if (((*(int *)(*(longlong *)(lVar12 + 0x7a8) + 0x58) != 0) ||
                  (*(uint *)(&stack0x00000108 + lVar11) < *(uint *)(lVar13 + 0x130))) ||
                 ((*(uint *)(lVar13 + 0x130) == *(uint *)(&stack0x00000108 + lVar11) &&
                  ((*(uint *)(&stack0x0000010c + lVar11) < *(uint *)(lVar13 + 0x134) ||
                   ((*(uint *)(lVar13 + 0x134) == *(uint *)(&stack0x0000010c + lVar11) &&
                    (uVar23 < *(ushort *)(lVar13 + 0x138))))))))) {
                lVar12 = plVar39[0x12];
                if (lVar12 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1005b2;
                  func_0x(plVar39);
                  lVar12 = plVar39[0x12];
                  plVar39 = *param_2;
                }
                if (((*(byte *)(*(longlong *)(lVar12 + 0x6b0) + 0x3c) & 1) == 0) ||
                   (*(longlong *)(*(longlong *)(lVar12 + 0x6b0) + 0x280) != 0)) {
                  lVar12 = plVar39[0x12];
                  if (lVar12 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100677;
                    func_0x(plVar39);
                    lVar12 = plVar39[0x12];
                    plVar39 = *param_2;
                  }
                  lVar13 = *plVar39;
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10068d;
                  func_0x(lVar12,lVar13 + 0x20);
                  goto LAB_;
                }
              }
              lVar12 = plVar39[0x12];
              if (lVar12 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1005f3;
                func_0x(plVar39);
                lVar12 = plVar39[0x12];
                plVar39 = *param_2;
              }
              lVar13 = *plVar39;
              if ((*(int *)(*(longlong *)(lVar12 + 0x7a8) + 0x110) != 0) &&
                 (uVar24 = *(uint *)(lVar13 + 0x20) & 0xfffffff8,
                 uVar24 != (uVar24 / 0x7cd00) * 0x7cd00)) {
                lVar12 = plVar39[0x12];
                if (lVar12 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100643;
                  func_0x(plVar39);
                  lVar12 = plVar39[0x12];
                  lVar13 = **param_2;
                }
                uVar17 = *(undefined8 *)(lVar12 + 0x7a8);
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100661;
                func_0x(uVar17,lVar13 + 0x20);
              }
            }
          }
LAB_:
          lVar12 = **param_2;
          if ((*(ushort *)(lVar12 + 4) & 0x2000) != 0) {
            if (*(short *)(lVar12 + 0x24) == 0) {
LAB_:
              *(undefined8 *)(&stack0x00000118 + lVar11) = *(undefined8 *)(lVar12 + 0x28);
              uVar23 = *(ushort *)(lVar12 + 0x30);
            }
            else {
              cVar7 = *(char *)(lVar12 + 1);
              if (cVar7 == '\v') {
                if (*(int *)(lVar12 + 0x18) != 99) {
LAB_:
                  if (cVar7 != '\t') goto LAB_;
                  goto LAB_;
                }
              }
              else {
                if (cVar7 != '\b') goto LAB_;
LAB_:
                if (*(int *)(lVar12 + 0x18) != 99) goto LAB_;
              }
              *(undefined4 *)(&stack0x000000f0 + lVar11) = *(undefined4 *)(lVar12 + 0x20);
              *(undefined2 *)(&stack0x000000f4 + lVar11) = *(undefined2 *)(lVar12 + 0x24);
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1006ee;
              cVar7 = func_0x(&stack0x000000f0 + lVar11);
              if (cVar7 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100701;
              func_0x(lVar12,&stack0x00000118 + lVar11);
              uVar23 = *(ushort *)(&stack0x00000120 + lVar11);
            }
            plVar39 = *param_2;
            lVar12 = plVar39[0x12];
            if (lVar12 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100734;
              func_0x(plVar39);
              lVar12 = plVar39[0x12];
            }
            puVar4 = *(uint **)(*(longlong *)(lVar12 + 0x6b0) + 0x2c0);
            uVar24 = *(uint *)(&stack0x00000118 + lVar11);
            if ((((*(short *)((longlong)puVar4 + 10) != 2) || (uVar24 != 0)) && (uVar24 <= *puVar4))
               && ((uVar24 != *puVar4 ||
                   ((*(uint *)(&stack0x0000011c + lVar11) <= puVar4[1] &&
                    ((*(uint *)(&stack0x0000011c + lVar11) != puVar4[1] ||
                     (uVar23 <= *(ushort *)(puVar4 + 2))))))))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100782;
              func_0x(param_2);
            }
          }
          if (param_1 == 0) {
            *(longlong *)((longlong)&lStackX_20 + lVar11) = **param_2;
          }
          else {
            *(longlong *)((longlong)&lStackX_20 + lVar11) = param_1;
          }
        }
        puVar28 = auStack_50 + lVar11;
        *(undefined **)(&stack0x000000d8 + lVar11) = &stack0xfffffffffffffff0 + lVar11;
        *(undefined4 *)(&stack0x000001ec + lVar11) = 0;
        *(undefined4 *)((longlong)&uStackX_18 + lVar11) = 9;
        uVar40 = 0xf;
        *puVar3 = 0xf;
        lVar13 = *(longlong *)((longlong)&lStackX_20 + lVar11);
        if (*(char *)(lVar13 + 2) < '\0') {
          pbVar36 = (byte *)(lVar13 + 0x60);
          if ((*(short *)(&stack0x000001b8 + lVar11) == 0) ||
             (ppbVar19 = *(byte ***)(&stack0x000001c8 + lVar11), ppbVar19 == (byte **)0x0)) {
            *(undefined (*) [16])(&stack0x00000200 + lVar11) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000210 + lVar11) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000220 + lVar11) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000230 + lVar11) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000240 + lVar11) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000250 + lVar11) = ZEXT816(0);
            *(undefined8 *)(&stack0x00000260 + lVar11) = 0;
            *(undefined (*) [16])(&stack0x000001f0 + lVar11) = ZEXT816(0);
            *(undefined2 *)(&stack0x00000200 + lVar11) = 0xffff;
            *(undefined8 *)(&stack0x00000208 + lVar11) = 0;
            *(undefined4 *)(&stack0x00000204 + lVar11) = 0;
            *(undefined8 *)(&stack0x0000021e + lVar11) = 0;
            *(undefined8 *)(&stack0x00000228 + lVar11) = 0;
            *(undefined8 *)(&stack0x00000210 + lVar11) = 0;
            *(undefined8 *)(&stack0x00000238 + lVar11) = 0;
            *(undefined8 *)(&stack0x00000250 + lVar11) = 0;
            *(undefined4 *)(&stack0x00000258 + lVar11) = 0;
            *(undefined2 *)(&stack0x00000262 + lVar11) = 0;
            ppbVar19 = (byte **)(&stack0x000001f0 + lVar11);
          }
          if (*(short *)(lVar13 + 0x24) == 0) {
LAB_:
            *(undefined8 *)(&stack0x00000128 + lVar11) = *(undefined8 *)(lVar13 + 0x28);
            uVar38 = *(undefined2 *)(lVar13 + 0x30);
          }
          else {
            cVar7 = *(char *)(lVar13 + 1);
            if (cVar7 == '\v') {
              if (*(int *)(lVar13 + 0x18) != 99) {
LAB_:
                if (cVar7 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar7 != '\b') goto LAB_;
LAB_:
              if (*(int *)(lVar13 + 0x18) != 99) goto LAB_;
            }
            *(undefined4 *)(&stack0x000000f8 + lVar11) = *(undefined4 *)(lVar13 + 0x20);
            *(undefined2 *)(&stack0x000000fc + lVar11) = *(undefined2 *)(lVar13 + 0x24);
            *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x100907;
            cVar7 = func_0x(&stack0x000000f8 + lVar11);
            if (cVar7 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10091a;
            func_0x(lVar13,&stack0x00000128 + lVar11);
            uVar38 = *(undefined2 *)(&stack0x00000130 + lVar11);
          }
          *ppbVar19 = pbVar36;
          uVar17 = *(undefined8 *)(&stack0x00000128 + lVar11);
          *(undefined4 *)(ppbVar19 + 0xc) = *(undefined4 *)(&stack0x00000128 + lVar11);
          *(int *)((longlong)ppbVar19 + 100) = (int)((ulonglong)uVar17 >> 0x20);
          *(undefined2 *)(ppbVar19 + 0xd) = uVar38;
          *(undefined4 *)((longlong)ppbVar19 + 0x6c) = *(undefined4 *)(lVar13 + 0x20);
          *(undefined2 *)(ppbVar19 + 0xe) = *(undefined2 *)(lVar13 + 0x24);
          *(undefined2 *)((longlong)ppbVar19 + 0x72) = 0;
          bVar21 = *pbVar36;
          *(undefined4 *)(&stack0x00000038 + lVar11) =
               *(undefined4 *)((ulonglong)bVar21 * 6 + 0x152a480);
          uVar42 = (ulonglong)*(short *)((ulonglong)bVar21 * 6 + 0x152a484);
          *(undefined2 *)(ppbVar19 + 2) = 0xffff;
          ppbVar19[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar19 + 0x2e) = 0;
          ppbVar19[7] = (byte *)0x0;
          ppbVar19[4] = (byte *)0x0;
          ppbVar19[9] = (byte *)0x0;
          ppbVar19[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar19 + 0xb) = 0;
          if ((**ppbVar19 & 2) != 0) {
            pbVar2 = pbVar36 + uVar42;
            if ((*pbVar2 & 1) == 0) {
              *(undefined2 *)(ppbVar19 + 2) = 0;
              ppbVar19[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar19 + 0x36) = 0;
              switch(*pbVar2 & 0xe) {
              default:
                uVar37 = (uint)*(ushort *)(pbVar2 + 2);
                if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
                  *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x100b9e;
                  func_0x(pbVar2,6);
                }
                break;
              case 4:
                uVar37 = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar37 = 1;
              }
              *(uint *)(ppbVar19 + 4) = uVar37;
              *(undefined8 *)((longlong)ppbVar19 + 0x2e) = 0;
            }
            else {
              *(undefined2 *)(ppbVar19 + 2) = 1;
              ppbVar19[3] = pbVar2;
              bVar21 = *pbVar2;
              switch(bVar21 & 0x1c) {
              default:
                if ((char)pbVar2[1] < '\0') {
                  uVar23 = *(ushort *)(pbVar2 + 1);
                  *(ushort *)((longlong)ppbVar19 + 0x12) = uVar23;
                  sVar8 = 3;
                  uVar23 = (uVar23 & 0x7f) << 8 | uVar23 >> 8;
                }
                else {
                  sVar8 = 2;
                  uVar23 = (ushort)pbVar2[1];
                }
                *(ushort *)((longlong)ppbVar19 + 0x12) = uVar23;
                *(short *)(ppbVar19 + 5) = sVar8;
                uVar23 = *(ushort *)((longlong)ppbVar19 + 0x12);
                *(short *)((longlong)ppbVar19 + 0x2c) = (short)(uVar23 + 1 >> 1) + sVar8;
                if (uVar23 < 0x1f) {
                  *(undefined2 *)((longlong)ppbVar19 + 0x2a) = 0;
                  *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                  *(undefined4 *)(ppbVar19 + 8) = 0;
                  ppbVar19[7] = (byte *)0x0;
                  ppbVar19[4] = (byte *)0x0;
                }
                else {
                  iVar10 = uVar23 - 1;
                  *(short *)((longlong)ppbVar19 + 0x2a) =
                       ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                       (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
                  *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                  *(undefined4 *)(ppbVar19 + 8) = 0;
                  ppbVar19[7] = (byte *)0x0;
                  ppbVar19[4] = (byte *)0x0;
                }
                break;
              case 4:
                if (((bVar21 & 0x1c) != 4) || (bVar6 = true, (bVar21 & 2) == 0)) {
                  bVar6 = false;
                }
                if (!bVar6) {
                  uVar40 = 1;
                }
                else {
                  *(undefined4 *)(ppbVar19 + 8) = 0;
                }
                ppbVar19[5] = (byte *)0x0;
                *(undefined2 *)((longlong)ppbVar19 + 0x12) = 0;
                ppbVar19[6] = (byte *)0x0;
                ppbVar19[4] = (byte *)0x0;
                ppbVar19[7] = (byte *)0x0;
                ppbVar19[3] = pbVar2;
                *(undefined4 *)((longlong)ppbVar19 + 0x14) = uVar40;
                *(uint *)(ppbVar19 + 8) = (uint)bVar6;
                ppbVar19[7] = (byte *)0x0;
                ppbVar19[4] = (byte *)0x0;
                break;
              case 8:
                ppbVar19[5] = (byte *)0x0;
                *(undefined2 *)((longlong)ppbVar19 + 0x12) = 0;
                ppbVar19[6] = (byte *)0x0;
                ppbVar19[4] = (byte *)0x0;
                ppbVar19[7] = (byte *)0x0;
                ppbVar19[3] = pbVar2;
                *(undefined4 *)((longlong)ppbVar19 + 0x14) = 9;
                *(undefined4 *)(ppbVar19 + 8) = 0;
                ppbVar19[7] = (byte *)0x0;
                ppbVar19[4] = (byte *)0x0;
              }
            }
          }
          if ((**ppbVar19 & 4) != 0) {
            if (*(short *)(&stack0x0000003a + lVar11) != 0) {
              uVar42 = (ulonglong)
                       *(ushort *)
                        (lVar13 + 0x61 + (longlong)*(short *)(&stack0x0000003a + lVar11) * 2);
            }
            psVar14 = (short *)(pbVar36 + uVar42);
            ppbVar19[9] = (byte *)psVar14;
            sVar8 = *psVar14;
            ppbVar19[10] = (byte *)(psVar14 + 1);
            *(short *)(ppbVar19 + 0xb) = (sVar8 + 1) * 2;
          }
          pbVar36 = ppbVar19[1];
          if (pbVar36 != (byte *)0x0) {
            *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x100c31;
            func_0x(pbVar36,ppbVar19);
          }
        }
        uVar37 = 9;
        uVar42 = (ulonglong)*(ushort *)(lVar13 + 0xe);
        pbVar36 = (byte *)((ulonglong)*(ushort *)(lVar13 + 0x1ffe) + lVar13);
        bVar21 = *pbVar36;
        *(byte **)(&stack0x000001c0 + lVar11) = pbVar36;
        if ((bVar21 & 1) == 0) {
          *(undefined2 *)(&stack0x000001b8 + lVar11) = 0;
          *puVar3 = 0;
          *(undefined4 *)(&stack0x000001bc + lVar11) = 0;
          *(undefined4 *)(&stack0x000001de + lVar11) = 0;
          switch(*pbVar36 & 0xe) {
          default:
            uVar42 = (ulonglong)*(ushort *)(pbVar36 + 2);
            if (0x1f9d < *(ushort *)(pbVar36 + 2) - 1) {
              *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x100e69;
              func_0x(pbVar36,6);
              *puVar3 = *(uint *)(&stack0x000001bc + lVar11);
            }
            break;
          case 4:
            uVar42 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar42 = 1;
          }
          *(int *)(&stack0x000001c8 + lVar11) = (int)uVar42;
          *(longlong *)(&stack0x000001d6 + lVar11) = lVar13 + 0x2000;
          ppbVar19 = *(byte ***)(&stack0x000001c8 + lVar11);
        }
        else {
          *(undefined2 *)(&stack0x000001b8 + lVar11) = 1;
          bVar21 = *pbVar36;
          switch(bVar21 & 0x1c) {
          default:
            if ((char)pbVar36[1] < '\0') {
              uVar23 = (*(ushort *)(pbVar36 + 1) & 0x7f) << 8 | *(ushort *)(pbVar36 + 1) >> 8;
              *(ushort *)(&stack0x000001ba + lVar11) = uVar23;
              *(undefined2 *)(&stack0x000001d0 + lVar11) = 3;
              *(undefined2 *)((longlong)&uStackX_1c + lVar11) = 3;
            }
            else {
              uVar23 = (ushort)pbVar36[1];
              *(ushort *)(&stack0x000001ba + lVar11) = uVar23;
              *(undefined2 *)(&stack0x000001d0 + lVar11) = 2;
            }
            *(short *)(&stack0x000001d4 + lVar11) =
                 (short)(uVar23 + 1 >> 1) + (short)*(undefined4 *)((longlong)&uStackX_1c + lVar11);
            if (uVar23 < 0x1f) {
              *(undefined2 *)(&stack0x000001d2 + lVar11) = 0;
              *puVar3 = 0;
              *(undefined4 *)(&stack0x000001bc + lVar11) = 0;
              *(undefined4 *)(&stack0x000001e8 + lVar11) = 0;
            }
            else {
              iVar10 = uVar23 - 1;
              *(short *)(&stack0x000001d2 + lVar11) =
                   ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                   (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
              *puVar3 = 0;
              *(undefined4 *)(&stack0x000001bc + lVar11) = 0;
              *(undefined4 *)(&stack0x000001e8 + lVar11) = 0;
            }
            break;
          case 4:
            if (((bVar21 & 0x1c) != 4) || ((bVar21 & 2) == 0)) {
              *(undefined8 *)(&stack0x000001d0 + lVar11) = 0;
              *(undefined2 *)(&stack0x000001ba + lVar11) = 0;
              *(undefined8 *)(&stack0x000001d8 + lVar11) = 0;
              uVar37 = 1;
              *(undefined4 *)(&stack0x000001bc + lVar11) = 1;
              *(undefined4 *)(&stack0x000001e8 + lVar11) = 0;
              goto code_r0x00100e06;
            }
            *(undefined8 *)(&stack0x000001d0 + lVar11) = 0;
            *(undefined2 *)(&stack0x000001ba + lVar11) = 0;
            *(undefined8 *)(&stack0x000001d8 + lVar11) = 0;
            *(undefined4 *)(&stack0x000001bc + lVar11) = 0xf;
            *(undefined4 *)(&stack0x000001e8 + lVar11) = 1;
            break;
          case 8:
            *(undefined8 *)(&stack0x000001d0 + lVar11) = 0;
            *(undefined2 *)(&stack0x000001ba + lVar11) = 0;
            *(undefined8 *)(&stack0x000001d8 + lVar11) = 0;
            *(undefined4 *)(&stack0x000001bc + lVar11) = 9;
            *(undefined4 *)(&stack0x000001e8 + lVar11) = 0;
code_r0x00100e06:
            *puVar3 = uVar37;
          }
          *(longlong *)(&stack0x000001e0 + lVar11) = lVar13 + 0x2000;
          *(byte ***)(&stack0x000001c8 + lVar11) = ppbVar19;
          uVar42 = (ulonglong)ppbVar19 & 0xffffffff;
        }
        *(short *)(&stack0x00000098 + lVar11) = *(short *)(&stack0x000001b8 + lVar11);
        if (*(short *)(&stack0x000001b8 + lVar11) == 0) {
          uVar41 = (ulonglong)*puVar3;
          if (*puVar3 == 0) {
            *(undefined2 *)(&stack0x000001ba + lVar11) = 0;
            *(int *)(&stack0x000001cc + lVar11) = (int)uVar42;
            if ((**(byte **)(&stack0x000001c0 + lVar11) & 0x10) != 0) {
              uVar37 = (int)uVar42 + 2 +
                       (*(ushort *)(*(byte **)(&stack0x000001c0 + lVar11) + uVar42) + 7 >> 3);
              uVar42 = (ulonglong)uVar37;
              *(uint *)(&stack0x000001cc + lVar11) = uVar37;
            }
            if ((**(byte **)(&stack0x000001c0 + lVar11) & 0x20) == 0) {
              *(int *)(&stack0x000001bc + lVar11) = (int)uVar42;
              *(undefined2 *)(&stack0x000001d4 + lVar11) = 0;
              *(int *)(&stack0x000001d0 + lVar11) = (int)uVar42;
              uVar41 = uVar42;
            }
            else {
              psVar14 = (short *)(*(byte **)(&stack0x000001c0 + lVar11) + uVar42);
              sVar8 = *psVar14;
              *(short *)(&stack0x000001d4 + lVar11) = sVar8;
              if (sVar8 == 0) {
                if ((((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                    (lVar12 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0)) &&
                   ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                    (*(char *)(lVar12 + 0x499) != '\0')))) {
                  if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x100f9c;
                    (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffd0 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10100c;
                    (*_DAT_)(1,0x172d998,0x184d668,0x80f);
                  }
                }
                *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10101b;
                func_0x(*(undefined8 *)(&stack0x000001c0 + lVar11),3);
              }
              uVar37 = *(int *)(&stack0x000001cc + lVar11) +
                       (*(ushort *)(&stack0x000001d4 + lVar11) + 1) * 2;
              *(uint *)(&stack0x000001d0 + lVar11) = uVar37;
              if (0x1f9e < uVar37) {
                if (((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                   ((lVar12 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0 &&
                    ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                     (*(char *)(lVar12 + 0x499) != '\0')))))) {
                  if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x1010bf;
                    (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffd0 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x1010e3;
                    (*_DAT_)(1,0x172d998,0x184d668,0x816);
                  }
                }
                *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x1010f2;
                func_0x(*(undefined8 *)(&stack0x000001c0 + lVar11),4);
                uVar37 = *(uint *)(&stack0x000001d0 + lVar11);
              }
              uVar24 = (ushort)psVar14[*(ushort *)(&stack0x000001d4 + lVar11)] & 0x7fff;
              *(uint *)(&stack0x000001bc + lVar11) = uVar24;
              if (uVar24 < uVar37) {
                if ((((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                    (lVar12 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0)) &&
                   ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                    (*(char *)(lVar12 + 0x499) != '\0')))) {
                  if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x101195;
                    (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffd0 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x1011b9;
                    (*_DAT_)(1,0x172d998,0x184d668,0x81d);
                  }
                }
                *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x1011c8;
                func_0x(*(undefined8 *)(&stack0x000001c0 + lVar11),4);
                uVar37 = *(uint *)(&stack0x000001d0 + lVar11);
                uVar24 = *(uint *)(&stack0x000001bc + lVar11);
              }
              uVar41 = (ulonglong)uVar24;
              uVar42 = (ulonglong)uVar37;
              do {
                uVar23 = *(ushort *)(&stack0x000001d4 + lVar11);
                if (-1 < psVar14[(ulonglong)(uVar23 - 1) + 1]) break;
                uVar24 = (uint)uVar42;
                if (uVar23 != 1) {
                  uVar24 = *(ushort *)
                            ((ulonglong)*(uint *)(&stack0x000001cc + lVar11) +
                             *(longlong *)(&stack0x000001c0 + lVar11) + -2 + (ulonglong)uVar23 * 2)
                           & 0x7fff;
                }
                if ((uVar24 < (uint)uVar42) ||
                   ((*(ushort *)
                      ((ulonglong)*(uint *)(&stack0x000001cc + lVar11) +
                       *(longlong *)(&stack0x000001c0 + lVar11) + (ulonglong)uVar23 * 2) & 0x7fff) <
                    uVar24)) {
                  *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x101242;
                  func_0x(*(undefined8 *)(&stack0x000001c0 + lVar11),7);
                  uVar42 = (ulonglong)*(uint *)(&stack0x000001d0 + lVar11);
                  uVar41 = (ulonglong)*(uint *)(&stack0x000001bc + lVar11);
                }
                uVar37 = (uint)uVar42;
                if ((uVar24 < uVar37) || ((uint)uVar41 < uVar24)) goto code_r0x00101590;
                if (*(ushort *)((ulonglong)uVar24 + *(longlong *)(&stack0x000001c0 + lVar11)) == 5)
                {
                  *(ushort *)(&stack0x000001ba + lVar11) =
                       *(ushort *)(&stack0x000001ba + lVar11) | 2;
                  *(short *)(&stack0x000001d4 + lVar11) = *(short *)(&stack0x000001d4 + lVar11) + -1
                  ;
                  *(short *)(&stack0x000001e2 + lVar11) = (short)uVar24;
                  lVar12 = (ulonglong)(uVar24 & 0xffff) + *(longlong *)(&stack0x000001c0 + lVar11);
                  uVar23 = *(ushort *)(lVar12 + 2);
                  uVar22 = *(ushort *)(&stack0x000001e4 + lVar11);
                  if ((uVar23 >> 0xe & 1) == 0) {
                    uVar22 = uVar22 & 0xc7ff;
                  }
                  else {
                    uVar22 = uVar22 ^ (uVar23 ^ uVar22) & 0x3800;
                  }
                  *(ushort *)(&stack0x000001e4 + lVar11) = uVar22;
                  *(ushort *)(&stack0x000001e4 + lVar11) =
                       (uVar22 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar22;
                  goto code_r0x0010133d;
                }
                if (*(ushort *)((ulonglong)uVar24 + *(longlong *)(&stack0x000001c0 + lVar11)) <
                    0x400) break;
                *(ushort *)(&stack0x000001ba + lVar11) = *(ushort *)(&stack0x000001ba + lVar11) | 1;
                psVar1 = (short *)(&stack0x000001d4 + lVar11);
                *psVar1 = *psVar1 + -1;
              } while (*psVar1 != 0);
            }
            uVar37 = (uint)uVar42;
code_r0x0010133d:
            if ((**(byte **)(&stack0x000001c0 + lVar11) & 0x40) == 0) {
              *(undefined4 *)(&stack0x000001de + lVar11) = 0;
            }
            else {
              *(int *)(&stack0x000001de + lVar11) = (int)uVar41;
              *(int *)(&stack0x000001bc + lVar11) = (int)uVar41 + 0xe;
              *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10136b;
              puVar15 = (ulonglong *)func_0x(&stack0x000001ba + lVar11);
              uVar22 = (ushort)(*puVar15 >> 0x30);
              uVar23 = uVar22;
              if ((((uint)(int)(short)uVar22 >> 1 ^ (int)(short)uVar22) & 0x2000) != 0) {
                uVar23 = uVar22 & 0xdfff;
                if ((uVar22 >> 0xe & 1) != 0) {
                  uVar23 = uVar22 | 0x2000;
                }
              }
              if (uVar23 == 0xfffc) {
                uVar25 = (uint)((*puVar15 >> 0x20 & 0xffff) >> 5);
              }
              uVar41 = (ulonglong)(*(int *)(&stack0x000001bc + lVar11) + uVar25);
              *(uint *)(&stack0x000001bc + lVar11) = *(int *)(&stack0x000001bc + lVar11) + uVar25;
              uVar37 = *(uint *)(&stack0x000001d0 + lVar11);
            }
            uVar25 = (uint)uVar41;
            if ((*(ulonglong *)(&stack0x000001d6 + lVar11) != 0) &&
               (*(ulonglong *)(&stack0x000001d6 + lVar11) <
                uVar41 + *(longlong *)(&stack0x000001c0 + lVar11))) {
              if (((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                 (((lVar12 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0 &&
                   (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
                  (*(char *)(lVar12 + 0x499) != '\0')))) {
                if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10147b;
                  (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffd0 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10149f;
                  (*_DAT_)(1,0x172d998,0x184d668,0x877);
                }
              }
              *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x1014b0;
              func_0x(*(undefined8 *)(&stack0x000001c0 + lVar11),0x12);
              uVar37 = *(uint *)(&stack0x000001d0 + lVar11);
              uVar25 = *(uint *)(&stack0x000001bc + lVar11);
            }
            if (0x3f3b < uVar25 - 1) {
              if (((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                 ((lVar12 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0 &&
                  ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                   (*(char *)(lVar12 + 0x499) != '\0')))))) {
                if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x101546;
                  (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffd0 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10156a;
                  (*_DAT_)(1,0x172d998,0x184d668,0x87c);
                }
              }
              *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10157b;
              func_0x(*(undefined8 *)(&stack0x000001c0 + lVar11),5);
              uVar37 = *(uint *)(&stack0x000001d0 + lVar11);
              uVar25 = *(uint *)(&stack0x000001bc + lVar11);
            }
          }
          else {
            uVar37 = *(uint *)(&stack0x000001d0 + lVar11);
code_r0x00101590:
            uVar25 = (uint)uVar41;
          }
          if ((8 < uVar25) ||
             (((**(byte **)(&stack0x000001c0 + lVar11) & 0xe) != 0 &&
              ((**(byte **)(&stack0x000001c0 + lVar11) & 0xe) != 0xc)))) {
            *(uint *)((longlong)&uStackX_18 + lVar11) = uVar25;
          }
          *(undefined4 *)(&stack0x000000a8 + lVar11) = *(undefined4 *)(&stack0x000001c8 + lVar11);
          *(undefined2 *)(&stack0x0000009a + lVar11) = *(undefined2 *)(&stack0x000001ba + lVar11);
          *(uint *)(&stack0x0000009c + lVar11) = uVar25;
          *(undefined2 *)(&stack0x000000b4 + lVar11) = *(undefined2 *)(&stack0x000001d4 + lVar11);
          *(undefined4 *)(&stack0x000000ac + lVar11) = *(undefined4 *)(&stack0x000001cc + lVar11);
          *(uint *)(&stack0x000000b0 + lVar11) = uVar37;
          *(undefined4 *)(&stack0x000000be + lVar11) = *(undefined4 *)(&stack0x000001de + lVar11);
          *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x101622;
          func_0x
                    (&stack0x00007c70 + lVar11,0x3f3c,*(undefined8 *)(&stack0x000001c0 + lVar11),
                     *(undefined4 *)((longlong)&uStackX_18 + lVar11));
          *(undefined **)(&stack0x000000a0 + lVar11) = &stack0x00007c70 + lVar11;
          *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10163c;
          iVar10 = func_0x(&stack0x0000009a + lVar11);
          if (iVar10 == 0) {
code_r0x00101789:
            ppbVar19 = *(byte ***)(&stack0x000000d8 + lVar11);
            *(undefined2 *)ppbVar19 = 0;
            uVar24 = *(uint *)(&stack0x0000bc38 + lVar11);
            puVar28 = auStack_50 + lVar11;
          }
          else {
            lVar12 = *(longlong *)(&stack0x000000a0 + lVar11);
            puVar26 = (ushort *)((ulonglong)*(uint *)(&stack0x000000ac + lVar11) + lVar12);
            uVar25 = *puVar26 - 1;
            if (((&stack0x0000009a)[lVar11] & 1) == 0) {
              uVar25 = (uint)*puVar26;
            }
            uVar37 = *(uint *)(&stack0x000000b0 + lVar11);
            if (uVar25 != 1) {
              uVar37 = puVar26[(longlong)(int)uVar25 + -1] & 0x7fff;
            }
            if ((uVar37 < *(uint *)(&stack0x000000b0 + lVar11)) ||
               ((puVar26[(int)uVar25] & 0x7fff) < uVar37)) {
              *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x1016a3;
              func_0x(lVar12,7);
              lVar12 = *(longlong *)(&stack0x000000a0 + lVar11);
            }
            *(short *)(&stack0x000000c2 + lVar11) = (short)uVar37;
            lVar12 = (ulonglong)(uVar37 & 0xffff) + lVar12;
            uVar23 = *(ushort *)(lVar12 + 2);
            uVar22 = *(ushort *)(&stack0x000000c4 + lVar11);
            if ((uVar23 >> 0xe & 1) == 0) {
              uVar22 = uVar22 & 0xc7ff;
            }
            else {
              uVar22 = uVar22 ^ (uVar23 ^ uVar22) & 0x3800;
            }
            *(ushort *)(&stack0x000000c4 + lVar11) = uVar22;
            *(ushort *)(&stack0x000000c4 + lVar11) =
                 (uVar22 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar22;
            ppbVar19 = *(byte ***)(&stack0x000000d8 + lVar11);
            *(undefined2 *)ppbVar19 = 0;
            uVar24 = *(uint *)(&stack0x0000bc38 + lVar11);
            puVar28 = auStack_50 + lVar11;
          }
        }
        else {
          if ((ppbVar19 == (byte **)0x0) || (*ppbVar19 == (byte *)0x0)) {
            *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10176f;
            func_0x(&stack0x0000009a + lVar11,&stack0x00007c70 + lVar11,0x3f3c,
                            &stack0x000001ba + lVar11);
            ppbVar19 = *(byte ***)(&stack0x000001c8 + lVar11);
            if (*(short *)(&stack0x000001b8 + lVar11) == 0) {
              ppbVar19 = ppbVar27;
            }
            *(byte ***)(&stack0x000000a8 + lVar11) = ppbVar19;
            goto code_r0x00101789;
          }
          *(undefined8 *)((longlong)&uStack_58 + lVar11) = 0x10173a;
          func_0x(&stack0x00000098 + lVar11,&stack0x00007c70 + lVar11,0x3f3c,
                          &stack0x000001b8 + lVar11);
          ppbVar19 = *(byte ***)(&stack0x000000d8 + lVar11);
          *(undefined2 *)ppbVar19 = 0;
          uVar24 = *(uint *)(&stack0x0000bc38 + lVar11);
        }
code_r0x001032f9:
        lVar12 = *(longlong *)(&stack0x00000040 + lVar11);
        param_2 = *(longlong ***)((longlong)&plStackX_10 + lVar11);
        goto LAB_;
      }
      uVar24 = *(uint *)(&stack0x0000bc38 + lVar11);
      lVar13 = *(longlong *)((longlong)&lStackX_20 + lVar11);
      lVar12 = *(longlong *)(&stack0x00000040 + lVar11);
      ppbVar34 = ppbVar27;
      goto LAB_;
    }
    if (bVar21 == 0) {
LAB_:
      if (param_2 != (longlong **)0x0) {
        plVar39 = *param_2;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101bbc;
        lVar13 = func_0x(_DAT_,plVar39,1,0);
        *(ushort *)(lVar13 + 4) = *(ushort *)(lVar13 + 4) & 0xedff;
        *(undefined4 *)(lVar13 + 0x40) = 1;
        plVar39 = *param_2;
        if (*(short *)((longlong)plVar39 + 0x2c) != 2) {
          lVar13 = plVar39[0x12];
          if (lVar13 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101bef;
            func_0x(plVar39);
            lVar13 = plVar39[0x12];
            plVar39 = *param_2;
          }
          if (((*(byte *)(*(longlong *)(lVar13 + 0x6b0) + 0x3c) & 1) != 0) &&
             (*(longlong *)(*(longlong *)(lVar13 + 0x6b0) + 0x280) == 0)) {
            lVar13 = plVar39[0x12];
            if (lVar13 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101c24;
              func_0x(plVar39);
              lVar13 = plVar39[0x12];
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101c30;
            cVar7 = func_0x(lVar13);
            if (cVar7 == '\0') goto LAB_;
          }
          plVar39 = *param_2;
          lVar13 = plVar39[0x12];
          if (lVar13 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101c4f;
            func_0x(plVar39);
            lVar13 = plVar39[0x12];
          }
          if ((*(byte *)(lVar13 + 0x1cd0) & 0x20) == 0) {
            lVar13 = **param_2;
            if (*(short *)(lVar13 + 0x24) == 0) {
LAB_:
              *(undefined8 *)(&stack0x00000068 + lVar11) = *(undefined8 *)(lVar13 + 0x28);
              uVar23 = *(ushort *)(lVar13 + 0x30);
              *(ushort *)(&stack0x00000070 + lVar11) = uVar23;
            }
            else {
              cVar7 = *(char *)(lVar13 + 1);
              if (cVar7 == '\v') {
                if (*(int *)(lVar13 + 0x18) != 99) {
LAB_:
                  if (cVar7 != '\t') goto LAB_;
                  goto LAB_;
                }
              }
              else {
                if (cVar7 != '\b') goto LAB_;
LAB_:
                if (*(int *)(lVar13 + 0x18) != 99) goto LAB_;
              }
              *(undefined4 *)(&stack0x00000138 + lVar11) = *(undefined4 *)(lVar13 + 0x20);
              *(undefined2 *)(&stack0x0000013c + lVar11) = *(undefined2 *)(lVar13 + 0x24);
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101cb4;
              cVar7 = func_0x(&stack0x00000138 + lVar11);
              if (cVar7 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101cc4;
              func_0x(lVar13,&stack0x00000068 + lVar11);
              uVar23 = *(ushort *)(&stack0x00000070 + lVar11);
            }
            plVar39 = *param_2;
            lVar13 = plVar39[0x12];
            if (lVar13 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101cf7;
              func_0x(plVar39);
              lVar13 = plVar39[0x12];
            }
            uVar38 = *(undefined2 *)((longlong)plVar39 + 0x74);
            uVar17 = *(undefined8 *)(lVar13 + 0x6a0);
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101d12;
            lVar16 = func_0x(uVar17,uVar38,0);
            plVar39 = **(longlong ***)((longlong)&plStackX_10 + lVar11);
            lVar13 = plVar39[0x12];
            if (lVar13 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101d33;
              func_0x(plVar39);
              lVar13 = plVar39[0x12];
              plVar39 = **(longlong ***)((longlong)&plStackX_10 + lVar11);
            }
            if (((*(int *)(*(longlong *)(lVar13 + 0x7a8) + 0x58) != 0) ||
                (*(uint *)(&stack0x00000068 + lVar11) < *(uint *)(lVar16 + 0x130))) ||
               ((*(uint *)(lVar16 + 0x130) == *(uint *)(&stack0x00000068 + lVar11) &&
                ((*(uint *)(&stack0x0000006c + lVar11) < *(uint *)(lVar16 + 0x134) ||
                 ((*(uint *)(lVar16 + 0x134) == *(uint *)(&stack0x0000006c + lVar11) &&
                  (uVar23 < *(ushort *)(lVar16 + 0x138))))))))) {
              lVar13 = plVar39[0x12];
              if (lVar13 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101d89;
                func_0x(plVar39);
                lVar13 = plVar39[0x12];
                param_2 = *(longlong ***)((longlong)&plStackX_10 + lVar11);
                plVar39 = *param_2;
              }
              else {
                param_2 = *(longlong ***)((longlong)&plStackX_10 + lVar11);
              }
              if (((*(byte *)(*(longlong *)(lVar13 + 0x6b0) + 0x3c) & 1) == 0) ||
                 (*(longlong *)(*(longlong *)(lVar13 + 0x6b0) + 0x280) != 0)) {
                lVar13 = plVar39[0x12];
                if (lVar13 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101e59;
                  func_0x(plVar39);
                  lVar13 = plVar39[0x12];
                  plVar39 = *param_2;
                }
                lVar16 = *plVar39;
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101e6f;
                func_0x(lVar13,lVar16 + 0x20);
                goto LAB_;
              }
            }
            lVar13 = plVar39[0x12];
            if (lVar13 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101dd0;
              func_0x(plVar39);
              lVar13 = plVar39[0x12];
              param_2 = *(longlong ***)((longlong)&plStackX_10 + lVar11);
              plVar39 = *param_2;
            }
            else {
              param_2 = *(longlong ***)((longlong)&plStackX_10 + lVar11);
            }
            lVar16 = *plVar39;
            if ((*(int *)(*(longlong *)(lVar13 + 0x7a8) + 0x110) != 0) &&
               (uVar24 = *(uint *)(lVar16 + 0x20) & 0xfffffff8,
               uVar24 != (uVar24 / 0x7cd00) * 0x7cd00)) {
              lVar13 = plVar39[0x12];
              if (lVar13 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101e26;
                func_0x(plVar39);
                lVar13 = plVar39[0x12];
                lVar16 = **param_2;
              }
              uVar17 = *(undefined8 *)(lVar13 + 0x7a8);
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101e43;
              func_0x(uVar17,lVar16 + 0x20);
            }
          }
        }
LAB_:
        lVar13 = **param_2;
        if ((*(ushort *)(lVar13 + 4) & 0x2000) != 0) {
          if (*(short *)(lVar13 + 0x24) == 0) {
LAB_:
            *(undefined8 *)(&stack0x00000078 + lVar11) = *(undefined8 *)(lVar13 + 0x28);
            uVar23 = *(ushort *)(lVar13 + 0x30);
            *(ushort *)(&stack0x00000080 + lVar11) = uVar23;
          }
          else {
            cVar7 = *(char *)(lVar13 + 1);
            if (cVar7 == '\v') {
              if (*(int *)(lVar13 + 0x18) != 99) {
LAB_:
                if (cVar7 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar7 != '\b') goto LAB_;
LAB_:
              if (*(int *)(lVar13 + 0x18) != 99) goto LAB_;
            }
            *(undefined4 *)(&stack0x00000048 + lVar11) = *(undefined4 *)(lVar13 + 0x20);
            *(undefined2 *)(&stack0x0000004c + lVar11) = *(undefined2 *)(lVar13 + 0x24);
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101ec7;
            cVar7 = func_0x(&stack0x00000048 + lVar11);
            if (cVar7 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101ed7;
            func_0x(lVar13,&stack0x00000078 + lVar11);
            uVar23 = *(ushort *)(&stack0x00000080 + lVar11);
          }
          plVar39 = *param_2;
          lVar13 = plVar39[0x12];
          if (lVar13 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101f0e;
            func_0x(plVar39);
            lVar13 = plVar39[0x12];
          }
          puVar4 = *(uint **)(*(longlong *)(lVar13 + 0x6b0) + 0x2c0);
          uVar24 = *(uint *)(&stack0x00000078 + lVar11);
          if ((((*(short *)((longlong)puVar4 + 10) != 2) || (uVar24 != 0)) && (uVar24 <= *puVar4))
             && ((uVar24 != *puVar4 ||
                 ((*(uint *)(&stack0x0000007c + lVar11) <= puVar4[1] &&
                  ((*(uint *)(&stack0x0000007c + lVar11) != puVar4[1] ||
                   (uVar23 <= *(ushort *)(puVar4 + 2))))))))) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101f56;
            func_0x(param_2);
          }
        }
        if (param_1 == 0) {
          *(longlong *)((longlong)&lStackX_20 + lVar11) = **param_2;
        }
        else {
          *(longlong *)((longlong)&lStackX_20 + lVar11) = param_1;
        }
      }
      uVar35 = *(uint *)((longlong)auStackX_8 + lVar11);
      uVar41 = ((ulonglong)uVar35 & 0xffff) * 2;
      uVar42 = uVar41 + 0xf;
      if (uVar42 <= uVar41) {
        uVar42 = 0xffffffffffffff0;
      }
      uVar42 = uVar42 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101f9b;
      func_0x();
      lVar16 = -uVar42;
      puVar28 = &stack0xffffffffffffffc0 + lVar16 + lVar11;
      *(longlong *)(&stack0x000000d8 + lVar11) = (longlong)&lStackX_20 + lVar16 + lVar11 + -0x20;
      if (*_DAT_ != '\0') {
        if (_DAT_ != 0) {
          ppbVar19 = (byte **)(_DAT_ + 0x6800);
        }
        if ((ppbVar19 != (byte **)0x0) && (*ppbVar19 != (byte *)0x0)) {
          LOCK();
          plVar39 = (longlong *)(*ppbVar19 + 0x148);
          *plVar39 = *plVar39 + 1;
          UNLOCK();
        }
      }
      lVar13 = *(longlong *)(&stack0x00000040 + lVar11);
      lVar20 = *(longlong *)(*(longlong *)(lVar13 + 8) + 0x488);
      if (((lVar20 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
        if (*(longlong *)(lVar20 + 0x20) != 0) {
          lVar33 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar31 = *(longlong *)(lVar33 + 0x100);
          if (lVar31 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102057;
            (*_DAT_)(0);
            lVar31 = *(longlong *)(lVar33 + 0x100);
            uVar35 = *(uint *)((longlong)auStackX_8 + lVar11);
          }
          ppbVar19 = ppbVar27;
          if (*(longlong *)(lVar31 + 0x260) != 0) {
            ppbVar19 = (byte **)(ulonglong)*(uint *)(*(longlong *)(lVar31 + 0x260) + 0xe68);
          }
          if ((uint)ppbVar19 < *(uint *)(_DAT_ + 8)) {
            lVar20 = *(longlong *)(*(longlong *)(lVar20 + 0x20) + (longlong)ppbVar19 * 8);
            *(longlong *)(lVar20 + 0x120) = *(longlong *)(lVar20 + 0x120) + 1;
            goto LAB_;
          }
        }
        LOCK();
        plVar39 = (longlong *)(*(longlong *)(lVar20 + 0x18) + 0x120);
        *plVar39 = *plVar39 + 1;
        UNLOCK();
      }
LAB_:
      *(uint *)(&stack0x00000030 + lVar11) = (uint)uVar22;
      uVar32 = (int)((ulonglong)(longlong)(int)((uVar35 & 0xffff) * (uint)uVar22 + -1) >> 9) + 1;
      puVar26 = *(ushort **)(&stack0x00000140 + lVar11);
      if ((int)uVar32 <= (int)(uint)*puVar26) {
        uVar32 = (uint)*puVar26;
      }
      uVar24 = *(uint *)(&stack0x0000bc38 + lVar11);
      *(uint *)((longlong)&uStackX_18 + lVar11) = uVar24;
      if (uVar32 < 0x20) {
        puVar26[0x80] = uVar22;
        puVar26[0x81] = (ushort)uVar35;
        if (*(longlong *)(puVar26 + 0x8c) == 0) {
          lVar31 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar20 = *(longlong *)(lVar31 + 0x100);
          if (lVar20 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x10213e;
            (*_DAT_)(0);
            lVar20 = *(longlong *)(lVar31 + 0x100);
          }
          *(undefined8 *)(puVar26 + 0x8c) = *(undefined8 *)(lVar20 + 1000);
        }
        ppbVar19 = ppbVar27;
        ppbVar34 = ppbVar27;
        if (0 < (int)uVar32) {
          do {
            if ((int)(uint)*puVar26 <= (int)ppbVar19) {
              (&stack0xffffffffffffffe0)[lVar16 + lVar11] = 5;
              uVar17 = *(undefined8 *)(puVar26 + 0x8c);
              *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x10218f;
              uVar17 = (*_DAT_)(0x2000,uVar17,0x1739228,0x4c5);
              *(undefined8 *)(puVar26 + (longlong)ppbVar34 * 4 + 4) = uVar17;
              *puVar26 = *puVar26 + 1;
            }
            uVar17 = *(undefined8 *)(puVar26 + (longlong)ppbVar34 * 4 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1021a7;
            func_0x(uVar17,0,0x2000);
            ppbVar34 = (byte **)((longlong)ppbVar34 + 1);
            ppbVar19 = (byte **)(ulonglong)((int)ppbVar19 + 1);
          } while ((longlong)ppbVar34 < (longlong)(int)uVar32);
          uVar22 = *(ushort *)puVar3;
        }
        uVar23 = puVar26[0x88];
        if (uVar23 < uVar22) {
          if (*(longlong *)(puVar26 + 0x84) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1021d9;
            (*_DAT_)();
            *(undefined8 *)(puVar26 + 0x84) = 0;
          }
          uVar17 = SUB168(ZEXT816(0x10) * ZEXT216(uVar22),0);
          if (SUB168(ZEXT816(0x10) * ZEXT216(uVar22),8) != 0) {
            uVar17 = 0xffffffffffffffff;
          }
          (&stack0xffffffffffffffe0)[lVar16 + lVar11] = 5;
          uVar5 = *(undefined8 *)(puVar26 + 0x8c);
          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102219;
          uVar17 = (*_DAT_)(uVar17,uVar5,0x1739228,0x4da);
          *(undefined8 *)(puVar26 + 0x84) = uVar17;
          puVar26[0x88] = uVar22;
          uVar23 = uVar22;
        }
        else {
          uVar17 = *(undefined8 *)(puVar26 + 0x84);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x10224e;
        func_0x(uVar17,0,(ulonglong)uVar23 << 4);
        if ((*(int *)((longlong)&uStackX_1c + lVar11) != 0) &&
           ((**(byte **)(&stack0x00000270 + lVar11) & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x10226f;
          func_0x(puVar26,&stack0x00000270 + lVar11);
        }
        if ((((*(byte *)((longlong)&uStackX_18 + lVar11) & 1) != 0) ||
            (*(char *)(*(longlong *)(lVar13 + 0x20) + 0x1cdf) == '\0')) ||
           ((*(char *)(*(longlong *)(lVar13 + 0x20) + 0x1cdc) == '\0' ||
            (bVar21 = *(byte *)(*(longlong *)(lVar13 + 8) + 0x109),
            *(undefined *)((longlong)&lStackX_20 + lVar11 + -0x1c) = 1, (bVar21 & 0x40) == 0)))) {
          *(undefined *)((longlong)&lStackX_20 + lVar11 + -0x1c) = 0;
        }
        uVar42 = 0;
        *(undefined2 *)puVar3 = 0;
        uVar24 = *(uint *)((longlong)auStackX_8 + lVar11);
        lVar13 = *(longlong *)((longlong)&lStackX_20 + lVar11);
        if ((short)uVar24 != 0) {
          do {
            if (*(short *)(lVar13 + (0xfff - uVar42) * 2) != 0) {
              *(int *)(&stack0x000001ec + lVar11) = (int)uVar42;
              ppbVar19 = ppbVar27;
              if (*(char *)(lVar13 + 2) < '\0') {
                pbVar36 = (byte *)(lVar13 + 0x60);
                if ((*(short *)(&stack0x000001b8 + lVar11) == 0) ||
                   (ppbVar19 = *(byte ***)(&stack0x000001c8 + lVar11), ppbVar19 == (byte **)0x0)) {
                  *(undefined (*) [16])(&stack0x00000200 + lVar11) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000210 + lVar11) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000220 + lVar11) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000230 + lVar11) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000240 + lVar11) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00000250 + lVar11) = ZEXT816(0);
                  *(undefined8 *)(&stack0x00000260 + lVar11) = 0;
                  *(undefined (*) [16])(&stack0x000001f0 + lVar11) = ZEXT816(0);
                  *(undefined2 *)(&stack0x00000200 + lVar11) = 0xffff;
                  *(undefined8 *)(&stack0x00000208 + lVar11) = 0;
                  *(undefined4 *)(&stack0x00000204 + lVar11) = 0;
                  *(undefined8 *)(&stack0x0000021e + lVar11) = 0;
                  *(undefined8 *)(&stack0x00000228 + lVar11) = 0;
                  *(undefined8 *)(&stack0x00000210 + lVar11) = 0;
                  *(undefined8 *)(&stack0x00000238 + lVar11) = 0;
                  *(undefined8 *)(&stack0x00000250 + lVar11) = 0;
                  *(undefined4 *)(&stack0x00000258 + lVar11) = 0;
                  *(undefined2 *)(&stack0x00000262 + lVar11) = 0;
                  ppbVar19 = (byte **)(&stack0x000001f0 + lVar11);
                }
                if (*(short *)(lVar13 + 0x24) == 0) {
LAB_:
                  *(undefined8 *)(&stack0x00000088 + lVar11) = *(undefined8 *)(lVar13 + 0x28);
                  sVar8 = *(short *)(lVar13 + 0x30);
                  *(short *)(&stack0x00000090 + lVar11) = sVar8;
                }
                else {
                  cVar7 = *(char *)(lVar13 + 1);
                  if (cVar7 == '\v') {
                    if (*(int *)(lVar13 + 0x18) != 99) {
LAB_:
                      if (cVar7 != '\t') goto LAB_;
                      goto LAB_;
                    }
                  }
                  else {
                    if (cVar7 != '\b') goto LAB_;
LAB_:
                    if (*(int *)(lVar13 + 0x18) != 99) goto LAB_;
                  }
                  *(undefined4 *)(&stack0x000000d0 + lVar11) = *(undefined4 *)(lVar13 + 0x20);
                  *(undefined2 *)(&stack0x000000d4 + lVar11) = *(undefined2 *)(lVar13 + 0x24);
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x10241e;
                  cVar7 = func_0x(&stack0x000000d0 + lVar11);
                  if (cVar7 == '\0') goto LAB_;
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102431;
                  func_0x(lVar13,&stack0x00000088 + lVar11);
                  sVar8 = *(short *)(&stack0x00000090 + lVar11);
                }
                iVar10 = *(int *)(&stack0x00000088 + lVar11);
                iVar9 = (int)((ulonglong)*(undefined8 *)(&stack0x00000088 + lVar11) >> 0x20);
                if (((((pbVar36 != *ppbVar19) || (sVar8 != *(short *)(ppbVar19 + 0xd))) ||
                     (iVar10 != *(int *)(ppbVar19 + 0xc))) ||
                    ((iVar9 != *(int *)((longlong)ppbVar19 + 100) ||
                     (*(int *)(lVar13 + 0x20) != *(int *)((longlong)ppbVar19 + 0x6c))))) ||
                   (*(short *)(lVar13 + 0x24) != *(short *)(ppbVar19 + 0xe))) {
                  *ppbVar19 = pbVar36;
                  *(int *)(ppbVar19 + 0xc) = iVar10;
                  *(int *)((longlong)ppbVar19 + 100) = iVar9;
                  *(short *)(ppbVar19 + 0xd) = sVar8;
                  *(undefined4 *)((longlong)ppbVar19 + 0x6c) = *(undefined4 *)(lVar13 + 0x20);
                  *(undefined2 *)(ppbVar19 + 0xe) = *(undefined2 *)(lVar13 + 0x24);
                  *(undefined2 *)((longlong)ppbVar19 + 0x72) = 0;
                  bVar21 = *pbVar36;
                  *(undefined4 *)(&stack0x00000048 + lVar11) =
                       *(undefined4 *)((ulonglong)bVar21 * 6 + 0x152a480);
                  uVar41 = (ulonglong)*(short *)((ulonglong)bVar21 * 6 + 0x152a484);
                  *(undefined2 *)(ppbVar19 + 2) = 0xffff;
                  ppbVar19[3] = (byte *)0x0;
                  *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                  *(undefined8 *)((longlong)ppbVar19 + 0x2e) = 0;
                  ppbVar19[7] = (byte *)0x0;
                  ppbVar19[4] = (byte *)0x0;
                  ppbVar19[9] = (byte *)0x0;
                  ppbVar19[10] = (byte *)0x0;
                  *(undefined2 *)(ppbVar19 + 0xb) = 0;
                  if ((**ppbVar19 & 2) != 0) {
                    pbVar2 = pbVar36 + uVar41;
                    if ((*pbVar2 & 1) == 0) {
                      *(undefined2 *)(ppbVar19 + 2) = 0;
                      ppbVar19[3] = pbVar2;
                      *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                      *(undefined4 *)((longlong)ppbVar19 + 0x36) = 0;
                      uVar24 = uVar25;
                      switch(*pbVar2 & 0xe) {
                      default:
                        uVar24 = (uint)*(ushort *)(pbVar2 + 2);
                        if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1026e7;
                          func_0x(pbVar2,6);
                        }
                        break;
                      case 4:
                        uVar24 = 9;
                        break;
                      case 6:
                      case 10:
                        break;
                      case 0xe:
                        uVar24 = 1;
                      }
                      *(uint *)(ppbVar19 + 4) = uVar24;
                      *(undefined8 *)((longlong)ppbVar19 + 0x2e) = 0;
                    }
                    else {
                      *(undefined2 *)(ppbVar19 + 2) = 1;
                      ppbVar19[3] = pbVar2;
                      bVar21 = *pbVar2;
                      switch(bVar21 & 0x1c) {
                      default:
                        if ((char)pbVar2[1] < '\0') {
                          uVar23 = *(ushort *)(pbVar2 + 1);
                          *(ushort *)((longlong)ppbVar19 + 0x12) = uVar23;
                          sVar8 = 3;
                          uVar23 = (uVar23 & 0x7f) << 8 | uVar23 >> 8;
                        }
                        else {
                          sVar8 = 2;
                          uVar23 = (ushort)pbVar2[1];
                        }
                        *(ushort *)((longlong)ppbVar19 + 0x12) = uVar23;
                        *(short *)(ppbVar19 + 5) = sVar8;
                        uVar23 = *(ushort *)((longlong)ppbVar19 + 0x12);
                        *(short *)((longlong)ppbVar19 + 0x2c) = (short)(uVar23 + 1 >> 1) + sVar8;
                        if (uVar23 < 0x1f) {
                          *(undefined2 *)((longlong)ppbVar19 + 0x2a) = 0;
                          *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                          *(undefined4 *)(ppbVar19 + 8) = 0;
                          ppbVar19[7] = (byte *)0x0;
                          ppbVar19[4] = (byte *)0x0;
                        }
                        else {
                          iVar10 = uVar23 - 1;
                          *(short *)((longlong)ppbVar19 + 0x2a) =
                               ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                               (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
                          *(undefined4 *)((longlong)ppbVar19 + 0x14) = 0;
                          *(undefined4 *)(ppbVar19 + 8) = 0;
                          ppbVar19[7] = (byte *)0x0;
                          ppbVar19[4] = (byte *)0x0;
                        }
                        break;
                      case 4:
                        if (((bVar21 & 0x1c) != 4) || (uVar24 = 1, (bVar21 & 2) == 0)) {
                          uVar24 = uVar25;
                        }
                        if (uVar24 == 0) {
                          uVar40 = 1;
                        }
                        else {
                          *(undefined4 *)(ppbVar19 + 8) = 0;
                          uVar40 = 0xf;
                        }
                        ppbVar19[5] = (byte *)0x0;
                        *(undefined2 *)((longlong)ppbVar19 + 0x12) = 0;
                        ppbVar19[6] = (byte *)0x0;
                        ppbVar19[4] = (byte *)0x0;
                        ppbVar19[7] = (byte *)0x0;
                        ppbVar19[3] = pbVar2;
                        *(undefined4 *)((longlong)ppbVar19 + 0x14) = uVar40;
                        *(uint *)(ppbVar19 + 8) = (uint)(uVar24 != 0);
                        ppbVar19[7] = (byte *)0x0;
                        ppbVar19[4] = (byte *)0x0;
                        break;
                      case 8:
                        ppbVar19[5] = (byte *)0x0;
                        *(undefined2 *)((longlong)ppbVar19 + 0x12) = 0;
                        ppbVar19[6] = (byte *)0x0;
                        ppbVar19[4] = (byte *)0x0;
                        ppbVar19[7] = (byte *)0x0;
                        ppbVar19[3] = pbVar2;
                        *(undefined4 *)((longlong)ppbVar19 + 0x14) = 9;
                        *(undefined4 *)(ppbVar19 + 8) = 0;
                        ppbVar19[7] = (byte *)0x0;
                        ppbVar19[4] = (byte *)0x0;
                      }
                    }
                  }
                  if ((**ppbVar19 & 4) != 0) {
                    if (*(short *)(&stack0x0000004a + lVar11) != 0) {
                      uVar41 = (ulonglong)
                               *(ushort *)
                                (lVar13 + 0x61 + (longlong)*(short *)(&stack0x0000004a + lVar11) * 2
                                );
                    }
                    psVar14 = (short *)(pbVar36 + uVar41);
                    ppbVar19[9] = (byte *)psVar14;
                    sVar8 = *psVar14;
                    ppbVar19[10] = (byte *)(psVar14 + 1);
                    *(short *)(ppbVar19 + 0xb) = (sVar8 + 1) * 2;
                  }
                  pbVar36 = ppbVar19[1];
                  if (pbVar36 != (byte *)0x0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102773;
                    func_0x(pbVar36,ppbVar19);
                  }
                }
              }
              uVar23 = *(ushort *)(lVar13 + 0xe);
              pbVar36 = (byte *)((ulonglong)*(ushort *)(lVar13 + (0xfff - uVar42) * 2) + lVar13);
              bVar21 = *pbVar36;
              *(byte **)(&stack0x000001c0 + lVar11) = pbVar36;
              ppbVar34 = ppbVar27;
              if ((bVar21 & 1) == 0) {
                *(undefined2 *)(&stack0x000001b8 + lVar11) = 0;
                *(undefined4 *)(&stack0x000001bc + lVar11) = 0;
                *(undefined4 *)(&stack0x000001de + lVar11) = 0;
                uVar24 = (uint)uVar23;
                switch(*pbVar36 & 0xe) {
                default:
                  uVar23 = *(ushort *)(pbVar36 + 2);
                  ppbVar34 = (byte **)0x0;
                  uVar24 = (uint)uVar23;
                  if (0x1f9d < uVar23 - 1) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1029ad;
                    func_0x(pbVar36,6);
                    ppbVar34 = (byte **)(ulonglong)*(uint *)(&stack0x000001bc + lVar11);
                    uVar24 = (uint)uVar23;
                  }
                  break;
                case 4:
                  uVar24 = 9;
                  ppbVar34 = (byte **)0x0;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar24 = 1;
                }
                *(uint *)(&stack0x000001c8 + lVar11) = uVar24;
                ppbVar19 = (byte **)(lVar13 + 0x2000);
                if (lVar13 == 0) {
                  ppbVar19 = ppbVar27;
                }
                *(byte ***)(&stack0x000001d6 + lVar11) = ppbVar19;
                ppbVar19 = (byte **)(ulonglong)uVar24;
              }
              else {
                *(undefined2 *)(&stack0x000001b8 + lVar11) = 1;
                bVar21 = *pbVar36;
                switch(bVar21 & 0x1c) {
                default:
                  if ((char)pbVar36[1] < '\0') {
                    *(ushort *)(&stack0x000001ba + lVar11) =
                         (*(ushort *)(pbVar36 + 1) & 0x7f) << 8 | *(ushort *)(pbVar36 + 1) >> 8;
                    sVar8 = 3;
                    *(undefined2 *)(&stack0x000001d0 + lVar11) = 3;
                  }
                  else {
                    *(ushort *)(&stack0x000001ba + lVar11) = (ushort)pbVar36[1];
                    sVar8 = 2;
                    *(undefined2 *)(&stack0x000001d0 + lVar11) = 2;
                  }
                  uVar23 = *(ushort *)(&stack0x000001ba + lVar11);
                  *(short *)(&stack0x000001d4 + lVar11) = (short)(uVar23 + 1 >> 1) + sVar8;
                  if (uVar23 < 0x1f) {
                    *(undefined2 *)(&stack0x000001d2 + lVar11) = 0;
                    *(undefined4 *)(&stack0x000001bc + lVar11) = 0;
                    *(undefined4 *)(&stack0x000001e8 + lVar11) = 0;
                  }
                  else {
                    iVar10 = uVar23 - 1;
                    *(short *)(&stack0x000001d2 + lVar11) =
                         ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                         (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
                    ppbVar34 = (byte **)0x0;
                    *(undefined4 *)(&stack0x000001bc + lVar11) = 0;
                    *(undefined4 *)(&stack0x000001e8 + lVar11) = 0;
                  }
                  break;
                case 4:
                  if (((bVar21 & 0x1c) == 4) && ((bVar21 & 2) != 0)) {
                    *(undefined8 *)(&stack0x000001d0 + lVar11) = 0;
                    *(undefined2 *)(&stack0x000001ba + lVar11) = 0;
                    *(undefined8 *)(&stack0x000001d8 + lVar11) = 0;
                    ppbVar34 = (byte **)0xf;
                    *(undefined4 *)(&stack0x000001bc + lVar11) = 0xf;
                    *(undefined4 *)(&stack0x000001e8 + lVar11) = 1;
                  }
                  else {
                    *(undefined8 *)(&stack0x000001d0 + lVar11) = 0;
                    *(undefined2 *)(&stack0x000001ba + lVar11) = 0;
                    *(undefined8 *)(&stack0x000001d8 + lVar11) = 0;
                    ppbVar34 = (byte **)0x1;
                    *(undefined4 *)(&stack0x000001bc + lVar11) = 1;
                    *(undefined4 *)(&stack0x000001e8 + lVar11) = 0;
                  }
                  break;
                case 8:
                  *(undefined8 *)(&stack0x000001d0 + lVar11) = 0;
                  *(undefined2 *)(&stack0x000001ba + lVar11) = 0;
                  *(undefined8 *)(&stack0x000001d8 + lVar11) = 0;
                  ppbVar34 = (byte **)0x9;
                  *(undefined4 *)(&stack0x000001bc + lVar11) = 9;
                  *(undefined4 *)(&stack0x000001e8 + lVar11) = 0;
                }
                ppbVar18 = (byte **)(lVar13 + 0x2000);
                if (lVar13 == 0) {
                  ppbVar18 = ppbVar27;
                }
                *(byte ***)(&stack0x000001e0 + lVar11) = ppbVar18;
                *(byte ***)(&stack0x000001c8 + lVar11) = ppbVar19;
              }
              uVar24 = (uint)ppbVar34;
              if (*(short *)(&stack0x000001b8 + lVar11) == 0) {
                if (uVar24 == 0) {
                  *(undefined2 *)(&stack0x000001ba + lVar11) = 0;
                  *(uint *)(&stack0x000001cc + lVar11) = *(uint *)(&stack0x000001c8 + lVar11);
                  pbVar36 = *(byte **)(&stack0x000001c0 + lVar11);
                  bVar21 = *pbVar36;
                  *(int *)(&stack0x000001cc + lVar11) = (int)ppbVar19;
                  if ((bVar21 & 0x10) != 0) {
                    uVar24 = uVar25;
                    if ((*pbVar36 & 0x10) != 0) {
                      uVar24 = (uint)*(ushort *)(pbVar36 + *(uint *)(&stack0x000001c8 + lVar11));
                    }
                    uVar24 = (int)ppbVar19 + 2 + (uVar24 + 7 >> 3);
                    ppbVar19 = (byte **)(ulonglong)uVar24;
                    *(uint *)(&stack0x000001cc + lVar11) = uVar24;
                  }
                  if ((**(byte **)(&stack0x000001c0 + lVar11) & 0x20) == 0) {
                    ppbVar34 = (byte **)((ulonglong)ppbVar19 & 0xffffffff);
                    *(int *)(&stack0x000001bc + lVar11) = (int)ppbVar19;
                    *(undefined2 *)(&stack0x000001d4 + lVar11) = 0;
                    *(int *)(&stack0x000001d0 + lVar11) = (int)ppbVar19;
                  }
                  else {
                    puVar26 = (ushort *)
                              (*(byte **)(&stack0x000001c0 + lVar11) +
                              ((ulonglong)ppbVar19 & 0xffffffff));
                    uVar23 = *puVar26;
                    *(ushort *)(&stack0x000001d4 + lVar11) = uVar23;
                    if (uVar23 == 0) {
                      if ((((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                          (lVar20 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar20 != 0)) &&
                         ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                          (*(char *)(lVar20 + 0x499) != '\0')))) {
                        if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102b24;
                          (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar11) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102b48;
                          (*_DAT_)(1,0x172d998,0x184d668,0x80f);
                        }
                      }
                      uVar17 = *(undefined8 *)(&stack0x000001c0 + lVar11);
                      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102b59;
                      func_0x(uVar17,3);
                      uVar23 = *(ushort *)(&stack0x000001d4 + lVar11);
                      ppbVar19 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar11);
                    }
                    uVar24 = (int)ppbVar19 + (uVar23 + 1) * 2;
                    *(uint *)(&stack0x000001d0 + lVar11) = uVar24;
                    if (0x1f9e < uVar24) {
                      if (((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                         ((lVar20 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar20 != 0 &&
                          ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                           (*(char *)(lVar20 + 0x499) != '\0')))))) {
                        if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102bff;
                          (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar11) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102c23;
                          (*_DAT_)(1,0x172d998,0x184d668,0x816);
                        }
                      }
                      uVar17 = *(undefined8 *)(&stack0x000001c0 + lVar11);
                      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102c34;
                      func_0x(uVar17,4);
                      uVar23 = *(ushort *)(&stack0x000001d4 + lVar11);
                      uVar24 = *(uint *)(&stack0x000001d0 + lVar11);
                      ppbVar19 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar11);
                    }
                    uVar42 = (ulonglong)uVar23;
                    uVar35 = puVar26[uVar42] & 0x7fff;
                    *(uint *)(&stack0x000001bc + lVar11) = uVar35;
                    if (uVar35 < uVar24) {
                      if ((((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                          (lVar20 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar20 != 0)) &&
                         ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                          (*(char *)(lVar20 + 0x499) != '\0')))) {
                        if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102ce1;
                          (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar11) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102d05;
                          (*_DAT_)(1,0x172d998,0x184d668,0x81d);
                        }
                      }
                      uVar17 = *(undefined8 *)(&stack0x000001c0 + lVar11);
                      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102d16;
                      func_0x(uVar17,4);
                      uVar42 = (ulonglong)*(ushort *)(&stack0x000001d4 + lVar11);
                      uVar24 = *(uint *)(&stack0x000001d0 + lVar11);
                      ppbVar19 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar11);
                      uVar35 = *(uint *)(&stack0x000001bc + lVar11);
                    }
                    ppbVar34 = (byte **)(ulonglong)uVar35;
                    do {
                      if (-1 < (short)puVar26[(ulonglong)((int)uVar42 - 1) + 1]) break;
                      lVar20 = ((ulonglong)ppbVar19 & 0xffffffff) +
                               *(longlong *)(&stack0x000001c0 + lVar11);
                      uVar35 = uVar24;
                      if ((int)uVar42 != 1) {
                        uVar35 = *(ushort *)(lVar20 + -2 + uVar42 * 2) & 0x7fff;
                      }
                      if ((uVar35 < uVar24) ||
                         ((*(ushort *)(lVar20 + uVar42 * 2) & 0x7fff) < uVar35)) {
                        uVar17 = *(undefined8 *)(&stack0x000001c0 + lVar11);
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102d9c;
                        func_0x(uVar17,7);
                        uVar42 = (ulonglong)*(ushort *)(&stack0x000001d4 + lVar11);
                        uVar24 = *(uint *)(&stack0x000001d0 + lVar11);
                        ppbVar19 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar11);
                        ppbVar34 = (byte **)(ulonglong)*(uint *)(&stack0x000001bc + lVar11);
                      }
                      if ((uVar35 < uVar24) || ((uint)ppbVar34 < uVar35)) goto code_r0x001030d2;
                      if (*(ushort *)((ulonglong)uVar35 + *(longlong *)(&stack0x000001c0 + lVar11))
                          == 5) {
                        *(ushort *)(&stack0x000001ba + lVar11) =
                             *(ushort *)(&stack0x000001ba + lVar11) | 2;
                        *(short *)(&stack0x000001d4 + lVar11) = (short)uVar42 + -1;
                        *(short *)(&stack0x000001e2 + lVar11) = (short)uVar35;
                        lVar20 = (ulonglong)(uVar35 & 0xffff) +
                                 *(longlong *)(&stack0x000001c0 + lVar11);
                        uVar23 = *(ushort *)(lVar20 + 2);
                        uVar22 = *(ushort *)(&stack0x000001e4 + lVar11);
                        if ((uVar23 & 0x4000) == 0) {
                          uVar22 = uVar22 & 0xc7ff;
                        }
                        else {
                          uVar22 = uVar22 ^ (uVar23 ^ uVar22) & 0x3800;
                        }
                        *(ushort *)(&stack0x000001e4 + lVar11) = uVar22;
                        *(ushort *)(&stack0x000001e4 + lVar11) =
                             uVar22 ^ (uVar22 ^ *(ushort *)(lVar20 + 2)) & 0x7ff;
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar35 + *(longlong *)(&stack0x000001c0 + lVar11))
                          < 0x400) break;
                      *(ushort *)(&stack0x000001ba + lVar11) =
                           *(ushort *)(&stack0x000001ba + lVar11) | 1;
                      uVar23 = (short)uVar42 - 1;
                      uVar42 = (ulonglong)uVar23;
                      *(ushort *)(&stack0x000001d4 + lVar11) = uVar23;
                    } while (uVar23 != 0);
                  }
                  if ((**(byte **)(&stack0x000001c0 + lVar11) & 0x40) == 0) {
                    *(undefined4 *)(&stack0x000001de + lVar11) = 0;
                  }
                  else {
                    *(int *)(&stack0x000001de + lVar11) = (int)ppbVar34;
                    *(int *)(&stack0x000001bc + lVar11) = (int)ppbVar34 + 0xe;
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102ec9;
                    puVar15 = (ulonglong *)func_0x(&stack0x000001ba + lVar11);
                    uVar42 = *puVar15;
                    uVar22 = (ushort)(uVar42 >> 0x30);
                    uVar23 = uVar22;
                    if ((((uint)(int)(short)uVar22 >> 1 ^ (int)(short)uVar22) & 0x2000) != 0) {
                      uVar23 = uVar22 & 0xdfff;
                      if ((uVar42 & 0x4000000000000000) != 0) {
                        uVar23 = uVar22 | 0x2000;
                      }
                    }
                    uVar24 = uVar37;
                    if (uVar23 == 0xfffc) {
                      uVar24 = (uint)((uVar42 >> 0x20 & 0xffff) >> 5);
                    }
                    ppbVar34 = (byte **)(ulonglong)(*(int *)(&stack0x000001bc + lVar11) + uVar24);
                    *(uint *)(&stack0x000001bc + lVar11) =
                         *(int *)(&stack0x000001bc + lVar11) + uVar24;
                  }
                  if ((*(ulonglong *)(&stack0x000001d6 + lVar11) != 0) &&
                     (*(ulonglong *)(&stack0x000001d6 + lVar11) <
                      (ulonglong)((longlong)ppbVar34 + *(longlong *)(&stack0x000001c0 + lVar11)))) {
                    if (((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                       (((lVar20 = *(longlong *)
                                    ((ulonglong)*_DAT_ +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8) + 8), lVar20 != 0 &&
                         (lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0)) &&
                        (*(char *)(lVar20 + 0x499) != '\0')))) {
                      if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102fd1;
                        (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar11) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x102ff5;
                        (*_DAT_)(1,0x172d998,0x184d668,0x877);
                      }
                    }
                    uVar17 = *(undefined8 *)(&stack0x000001c0 + lVar11);
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x103006;
                    func_0x(uVar17,0x12);
                    ppbVar34 = (byte **)(ulonglong)*(uint *)(&stack0x000001bc + lVar11);
                  }
                  if (0x3f3b < (int)ppbVar34 - 1U) {
                    if (((cRam0000000001e3cf6b != '\0') || ((bRam0000000001e4d870 & 1) != 0)) &&
                       ((lVar20 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar20 != 0 &&
                        ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                         (*(char *)(lVar20 + 0x499) != '\0')))))) {
                      if ((cRam0000000001e3ce5b == '\0') && ((bRam0000000001e4d870 & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x103096;
                        (*pcRam00000000013ab798)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar11) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1030ba;
                        (*_DAT_)(1,0x172d998,0x184d668,0x87c);
                      }
                    }
                    uVar17 = *(undefined8 *)(&stack0x000001c0 + lVar11);
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1030cb;
                    func_0x(uVar17,5);
                    ppbVar34 = (byte **)(ulonglong)*(uint *)(&stack0x000001bc + lVar11);
                  }
                }
code_r0x001030d2:
                uVar24 = (uint)ppbVar34;
                if (uVar24 < 9) {
                  bVar21 = **(byte **)(&stack0x000001c0 + lVar11) & 0xe;
joined_r0x00103117:
                  if ((bVar21 == 0) || (bVar21 == 0xc)) {
                    uVar24 = 9;
                  }
                }
              }
              else {
                if (uVar24 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1030fd;
                  func_0x(&stack0x000001ba + lVar11);
                  uVar24 = *(uint *)(&stack0x000001bc + lVar11);
                }
                if (uVar24 < 9) {
                  bVar21 = **(byte **)(&stack0x000001c0 + lVar11) & 0x1c;
                  goto joined_r0x00103117;
                }
              }
              *(uint *)(&stack0x00000028 + lVar11) = *(int *)(&stack0x00000028 + lVar11) + uVar24;
              if (*(short *)(&stack0x000001b8 + lVar11) == 0) {
                if ((**(byte **)(&stack0x000001c0 + lVar11) & 0x10) != 0) {
                  uVar23 = *(ushort *)
                            (*(byte **)(&stack0x000001c0 + lVar11) +
                            *(uint *)(&stack0x000001c8 + lVar11));
                  goto code_r0x00103151;
                }
              }
              else {
                uVar23 = *(ushort *)(&stack0x000001ba + lVar11);
code_r0x00103151:
                puVar30 = &stack0xffffffffffffffc0 + lVar16 + lVar11;
                if (*(uint *)(&stack0x00000030 + lVar11) < (uint)uVar23) goto LAB_;
              }
              if (*(char *)((longlong)&lStackX_20 + lVar11 + -0x1c) != '\0') {
                if (*(short *)(&stack0x000001b8 + lVar11) == 0) {
                  bVar21 = **(byte **)(&stack0x000001c0 + lVar11) >> 6;
                }
                else {
                  bVar21 = **(byte **)(&stack0x000001c0 + lVar11) >> 1;
                }
                if ((bVar21 & 1) != 0) {
                  if (*(short *)(&stack0x000001b8 + lVar11) == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x10319c;
                    func_0x();
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1031a3;
                    func_0x(&stack0x000001ba + lVar11,&stack0x00000050 + lVar11);
                  }
                  *(int *)(&stack0x00000038 + lVar11) = *(int *)(&stack0x00000050 + lVar11);
                  *(short *)(&stack0x0000003c + lVar11) = *(short *)(&stack0x00000054 + lVar11);
                  lVar20 = *(longlong *)(&stack0x000000e0 + lVar11);
                  if ((*(short *)(lVar20 + 0x2c) != *(short *)(&stack0x00000054 + lVar11)) ||
                     (*(int *)(lVar20 + 0x28) != *(int *)(&stack0x00000050 + lVar11))) {
                    lVar20 = *(longlong *)(lVar20 + 0x30);
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1031d7;
                    cVar7 = func_0x(lVar20 + 0x19c8,&stack0x00000038 + lVar11);
                    puVar30 = &stack0xffffffffffffffc0 + lVar16 + lVar11;
                    if (cVar7 != '\0') goto LAB_;
                  }
                }
              }
              uVar40 = *(undefined4 *)((longlong)&uStackX_1c + lVar11);
              uVar38 = *(undefined2 *)puVar3;
              puVar26 = *(ushort **)(&stack0x00000140 + lVar11);
              *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1031f9;
              func_0x(puVar26,uVar38,&stack0x000001b8 + lVar11,uVar40);
              uVar42 = (ulonglong)*(ushort *)puVar3;
              uVar24 = *(uint *)((longlong)auStackX_8 + lVar11);
            }
            uVar23 = (short)uVar42 + 1;
            uVar42 = (ulonglong)uVar23;
            *(ushort *)puVar3 = uVar23;
          } while (uVar23 < (ushort)uVar24);
        }
        *(undefined2 *)(&stack0x00001840 + lVar11) = 0xffff;
        *(undefined8 *)(&stack0x00001848 + lVar11) = 0;
        *(undefined4 *)(&stack0x00001844 + lVar11) = 0;
        *(undefined8 *)(&stack0x0000185e + lVar11) = 0;
        *(undefined8 *)(&stack0x00001868 + lVar11) = 0;
        *(undefined8 *)(&stack0x00001850 + lVar11) = 0;
        *(undefined2 *)(&stack0x00005850 + lVar11) = 0;
        *(undefined4 *)(&stack0x00005854 + lVar11) = 0;
        *(ushort **)(&stack0x00001830 + lVar11) = puVar26;
        *(uint *)(&stack0x00001838 + lVar11) = uVar24 & 0xffff;
        *(undefined4 *)(&stack0x0000183c + lVar11) = *(undefined4 *)(&stack0x00000030 + lVar11);
        *(short *)(&stack0x00003840 + lVar11) = (short)uVar24;
        *(undefined8 *)(&stack0x00003814 + lVar11) = 0;
        *(undefined2 *)(&stack0x00005858 + lVar11) = 0;
        *(undefined8 *)(&stack0x00003820 + lVar11) = 0;
        *(undefined **)(&stack0xfffffffffffffff8 + lVar16 + lVar11) = &stack0x000002f0 + lVar11;
        *(uint *)(&stack0xfffffffffffffff0 + lVar16 + lVar11) = uVar24 & 0xffff;
        ppbVar19 = *(byte ***)(&stack0x000000d8 + lVar11);
        *(byte ***)(&stack0xffffffffffffffe8 + lVar16 + lVar11) = ppbVar19;
        *(undefined4 *)(&stack0xffffffffffffffe0 + lVar16 + lVar11) = 0x3f3c;
        uVar40 = *(undefined4 *)(&stack0x00000028 + lVar11);
        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1032e7;
        iVar10 = func_0x(&stack0x00001830 + lVar11,uVar40,lVar13,&stack0x00007c70 + lVar11);
        uVar24 = *(uint *)((longlong)&uStackX_18 + lVar11);
        if (iVar10 == 0) goto code_r0x001032f9;
      }
      else {
        lVar13 = *(longlong *)((longlong)&lStackX_20 + lVar11);
      }
      puVar30 = &stack0xffffffffffffffc0 + lVar16 + lVar12 + 0x40;
      if (*(int *)((longlong)&uStackX_1c + lVar11) != 0) {
        lVar20 = *(longlong *)((longlong)&plStackX_10 + lVar11);
        if (lVar20 == 0) {
          *(undefined2 *)(lVar13 + 0x61) = 0;
          puVar30 = &stack0xffffffffffffffc0 + lVar16 + lVar12 + 0x40;
        }
        else {
          *(uint *)(&stack0xffffffffffffffe0 + lVar16 + lVar11) = uVar24;
          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar11) = 0x1033ff;
          func_0x(lVar20);
          puVar30 = &stack0xffffffffffffffc0 + lVar16 + lVar12 + 0x40;
        }
      }
    }
    else {
      uVar23 = uVar23 >> 2;
      if (uVar23 < 2) {
        uVar23 = 1;
      }
      else if (100 < (*(uint *)((longlong)auStackX_8 + lVar11) & 0xfffc)) {
        uVar23 = 0x19;
      }
      puVar30 = &stack0xffffffffffffffc0 + lVar11;
      if (uVar23 <= *(ushort *)(lVar13 + 0x61)) {
        if (*(short *)(lVar13 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x00000058 + lVar11) = *(undefined8 *)(lVar13 + 0x28);
          uVar38 = *(undefined2 *)(lVar13 + 0x30);
          *(undefined2 *)(&stack0x00000060 + lVar11) = uVar38;
        }
        else {
          cVar7 = *(char *)(lVar13 + 1);
          if (cVar7 == '\v') {
            if (*(int *)(lVar13 + 0x18) != 99) {
LAB_:
              if (cVar7 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar7 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar13 + 0x18) != 99) goto LAB_;
          }
          *(undefined4 *)(&stack0x00000100 + lVar11) = *(undefined4 *)(lVar13 + 0x20);
          *(undefined2 *)(&stack0x00000104 + lVar11) = *(undefined2 *)(lVar13 + 0x24);
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10181e;
          cVar7 = func_0x(&stack0x00000100 + lVar11);
          if (cVar7 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10182e;
          func_0x(lVar13,&stack0x00000058 + lVar11);
          uVar38 = *(undefined2 *)(&stack0x00000060 + lVar11);
        }
        pbVar36 = (byte *)(lVar13 + 0x60);
        *(byte **)(&stack0x00000270 + lVar11) = pbVar36;
        *(undefined4 *)(&stack0x000002d0 + lVar11) = *(undefined4 *)(&stack0x00000058 + lVar11);
        *(int *)(&stack0x000002d4 + lVar11) =
             (int)((ulonglong)*(undefined8 *)(&stack0x00000058 + lVar11) >> 0x20);
        *(undefined2 *)(&stack0x000002d8 + lVar11) = uVar38;
        *(undefined4 *)(&stack0x000002dc + lVar11) = *(undefined4 *)(lVar13 + 0x20);
        *(undefined2 *)(&stack0x000002e0 + lVar11) = *(undefined2 *)(lVar13 + 0x24);
        *(undefined2 *)(&stack0x000002e2 + lVar11) = 0;
        bVar21 = *pbVar36;
        *(undefined4 *)(&stack0x00000038 + lVar11) =
             *(undefined4 *)((ulonglong)bVar21 * 6 + 0x152a480);
        uVar42 = (ulonglong)*(short *)((ulonglong)bVar21 * 6 + 0x152a484);
        *(undefined2 *)(&stack0x00000280 + lVar11) = 0xffff;
        *(undefined8 *)(&stack0x00000288 + lVar11) = 0;
        *(undefined4 *)(&stack0x00000284 + lVar11) = 0;
        *(undefined8 *)(&stack0x0000029e + lVar11) = 0;
        *(undefined8 *)(&stack0x000002a8 + lVar11) = 0;
        *(undefined8 *)(&stack0x00000290 + lVar11) = 0;
        *(undefined8 *)(&stack0x000002b8 + lVar11) = 0;
        *(undefined8 *)(&stack0x000002c0 + lVar11) = 0;
        *(undefined2 *)(&stack0x000002c8 + lVar11) = 0;
        if ((*pbVar36 & 2) != 0) {
          pbVar2 = pbVar36 + uVar42;
          bVar21 = *pbVar2;
          *(byte **)(&stack0x00000288 + lVar11) = pbVar2;
          if ((bVar21 & 1) == 0) {
            *(undefined2 *)(&stack0x00000280 + lVar11) = 0;
            *(undefined4 *)(&stack0x000002a6 + lVar11) = 0;
            uVar24 = uVar25;
            switch(*pbVar2 & 0xe) {
            default:
              uVar24 = (uint)*(ushort *)(pbVar2 + 2);
              if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101ae5;
                func_0x(pbVar2,6);
              }
              break;
            case 4:
              uVar24 = 9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar24 = 1;
            }
            *(uint *)(&stack0x00000290 + lVar11) = uVar24;
          }
          else {
            *(undefined2 *)(&stack0x00000280 + lVar11) = 1;
            bVar21 = *pbVar2;
            switch(bVar21 & 0x1c) {
            default:
              if ((char)pbVar2[1] < '\0') {
                uVar23 = (*(ushort *)(pbVar2 + 1) & 0x7f) << 8 | *(ushort *)(pbVar2 + 1) >> 8;
                *(ushort *)(&stack0x00000282 + lVar11) = uVar23;
                uVar38 = 3;
                sVar8 = 3;
              }
              else {
                uVar23 = (ushort)pbVar2[1];
                *(ushort *)(&stack0x00000282 + lVar11) = uVar23;
                uVar38 = 2;
                sVar8 = 2;
              }
              *(undefined2 *)(&stack0x00000298 + lVar11) = uVar38;
              *(short *)(&stack0x0000029c + lVar11) = (short)(uVar23 + 1 >> 1) + sVar8;
              if (uVar23 < 0x1f) {
                *(undefined2 *)(&stack0x0000029a + lVar11) = 0;
                *(undefined4 *)(&stack0x000002b0 + lVar11) = 0;
              }
              else {
                *(short *)(&stack0x0000029a + lVar11) = (short)((int)(uVar23 - 1) / 0x1e);
                *(undefined4 *)(&stack0x000002b0 + lVar11) = 0;
              }
              break;
            case 4:
              if (((bVar21 & 0x1c) == 4) && ((bVar21 & 2) != 0)) {
                *(undefined4 *)(&stack0x00000298 + lVar11) = 0;
                *(undefined2 *)(&stack0x00000282 + lVar11) = 0;
                *(undefined2 *)(&stack0x0000029c + lVar11) = 0;
                *(undefined2 *)(&stack0x000002a6 + lVar11) = 0;
                *(undefined4 *)(&stack0x00000284 + lVar11) = 0xf;
                *(undefined4 *)(&stack0x000002b0 + lVar11) = 1;
              }
              else {
                *(undefined4 *)(&stack0x00000298 + lVar11) = 0;
                *(undefined2 *)(&stack0x00000282 + lVar11) = 0;
                *(undefined2 *)(&stack0x0000029c + lVar11) = 0;
                *(undefined2 *)(&stack0x000002a6 + lVar11) = 0;
                *(undefined4 *)(&stack0x00000284 + lVar11) = 1;
                *(undefined4 *)(&stack0x000002b0 + lVar11) = 0;
              }
              break;
            case 8:
              *(undefined4 *)(&stack0x00000298 + lVar11) = 0;
              *(undefined2 *)(&stack0x00000282 + lVar11) = 0;
              *(undefined2 *)(&stack0x0000029c + lVar11) = 0;
              *(undefined2 *)(&stack0x000002a6 + lVar11) = 0;
              *(undefined4 *)(&stack0x00000284 + lVar11) = 9;
              *(undefined4 *)(&stack0x000002b0 + lVar11) = 0;
            }
          }
        }
        if ((**(byte **)(&stack0x00000270 + lVar11) & 4) != 0) {
          if (*(short *)(&stack0x0000003a + lVar11) != 0) {
            uVar42 = (ulonglong)
                     *(ushort *)
                      (lVar13 + 0x61 + (longlong)*(short *)(&stack0x0000003a + lVar11) * 2);
          }
          psVar14 = (short *)(pbVar36 + uVar42);
          *(short **)(&stack0x000002b8 + lVar11) = psVar14;
          sVar8 = *psVar14;
          *(short **)(&stack0x000002c0 + lVar11) = psVar14 + 1;
          *(short *)(&stack0x000002c8 + lVar11) = (sVar8 + 1) * 2;
        }
        if (*(longlong *)(&stack0x00000278 + lVar11) != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101b7f;
          func_0x
                    (*(longlong *)(&stack0x00000278 + lVar11),&stack0x00000270 + lVar11);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x101b87;
        uVar23 = func_0x(pbVar36);
        *(uint *)(&stack0x00000028 + lVar11) = (uint)uVar23;
        param_2 = *(longlong ***)((longlong)&plStackX_10 + lVar11);
        goto LAB_;
      }
    }
  }
LAB_:
  if (*(short *)(&stack0x00000df2 + lVar11) != 0) {
    uVar17 = *(undefined8 *)(&stack0x00000df8 + lVar11);
    *(undefined8 *)(puVar30 + -8) = 0x103423;
    (*_DAT_)(uVar17);
    uVar17 = *(undefined8 *)(&stack0x00000e00 + lVar11);
    *(undefined8 *)(puVar30 + -8) = 0x103430;
    (*_DAT_)(uVar17);
  }
  if (*(short *)(&stack0x00000392 + lVar11) != 0) {
    uVar17 = *(undefined8 *)(&stack0x00000398 + lVar11);
    *(undefined8 *)(puVar30 + -8) = 0x103448;
    (*_DAT_)(uVar17);
    uVar17 = *(undefined8 *)(&stack0x000003a0 + lVar11);
    *(undefined8 *)(puVar30 + -8) = 0x103455;
    (*_DAT_)(uVar17);
  }
LAB_:
  uVar42 = *(ulonglong *)(&stack0x0000bbb0 + lVar11);
  *(undefined8 *)(puVar30 + -8) = 0x103466;
  func_0x(uVar42 ^ (ulonglong)puVar3);
  return;
}

