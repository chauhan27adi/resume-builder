
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined4 *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong lVar8;
  longlong unaff_GS_OFFSET;
  undefined auStack_2e8 [32];
  undefined8 uStack_2c8;
  undefined8 uStack_2c0;
  undefined8 uStack_2b8;
  undefined8 uStack_2b0;
  ulonglong uStack_2a8;
  int aiStack_298 [2];
  longlong lStack_290;
  undefined4 auStack_288 [2];
  undefined8 uStack_280;
  undefined4 uStack_278;
  undefined auStack_270 [16];
  undefined8 uStack_260;
  undefined2 uStack_258;
  undefined8 uStack_250;
  longlong lStack_248;
  undefined2 uStack_240;
  undefined8 uStack_238;
  int iStack_230;
  undefined auStack_228 [16];
  undefined auStack_218 [16];
  undefined auStack_208 [16];
  undefined auStack_1f8 [16];
  longlong lStack_1e8;
  uint uStack_1e0;
  undefined8 uStack_1d8;
  undefined8 uStack_1d0;
  undefined2 auStack_1c8 [2];
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined auStack_b8 [144];
  ulonglong uStack_28;
  
  uStack_250 = 0xfffffffffffffffe;
  uStack_28 = _DAT_ ^ (ulonglong)auStack_2e8;
  uStack_280 = 0;
  uStack_278 = 1;
  auStack_270._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_270._8_8_ = 0;
  cVar1 = (**(code **)(*(longlong *)auStack_270._0_8_ + 0x1d0))();
  if (cVar1 == '\0') {
    uStack_2a8 = uStack_2a8 & 0xffffffff00000000;
    uStack_2b0 = 0;
    uStack_2b8 = (undefined8 *)((ulonglong)uStack_2b8 & 0xffffffffffffff00);
    uStack_2c0 = CONCAT44(uStack_2c0._4_4_,2);
    uStack_2c8 = CONCAT44(uStack_2c8._4_4_,1);
    (**(code **)(*(longlong *)auStack_270._0_8_ + 8))(auStack_270._0_8_,0x1a8b918,0x2a,1);
    uStack_280 = CONCAT44(uStack_280._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_270._0_8_ + 0xe8))
              (auStack_270._0_8_,1,1,(longlong)&uStack_280 + 4);
    uStack_278 = 1;
    uStack_280 = CONCAT44(uStack_280._4_4_,4);
  }
  iVar2 = func_0x(*(undefined2 *)((longlong)param_1 + 0x106),0x1a8b880);
  if (iVar2 == 0) {
    uStack_2a8 = 0x1a8b880;
    uStack_2b0 = CONCAT44(uStack_2b0._4_4_,1);
    uStack_2b8 = (undefined8 *)CONCAT44(uStack_2b8._4_4_,0x10);
    uStack_2c0 = CONCAT44(uStack_2c0._4_4_,0x58c3);
    uStack_2c8 = 0;
    func_0x(1,param_1,0,0);
  }
  else {
    uStack_238 = (**(code **)(*(longlong *)auStack_270._0_8_ + 0x1b0))();
    uStack_240 = *(undefined2 *)((longlong)param_1 + 0x106);
    lStack_248 = 0;
    auStack_228 = ZEXT816(0);
    auStack_218 = ZEXT816(0);
    auStack_208 = ZEXT816(0);
    auStack_1f8 = ZEXT816(0);
    lStack_1e8 = 0;
    uStack_1e0 = 0;
    uStack_1d8 = 0;
    uStack_1d0 = 0;
    lStack_290 = 0;
    aiStack_298[0] = 0;
    iStack_230 = iVar2;
    iVar2 = func_0x(&lStack_248,3,1,1);
    if (iVar2 == 0) {
      uStack_2a8 = 0x1a8b880;
      uStack_2b0 = CONCAT44(uStack_2b0._4_4_,0xb);
      uStack_2b8 = (undefined8 *)CONCAT44(uStack_2b8._4_4_,0x10);
      uStack_2c0 = CONCAT44(uStack_2c0._4_4_,0x49aa);
      uStack_2c8 = 0;
      func_0x(1,param_1,0);
    }
    else {
      uStack_2c0 = lStack_248;
      uStack_2c8 = uStack_1d8;
      iVar2 = (**(code **)(*(longlong *)auStack_228._8_8_ + 0x18))(auStack_228._8_8_,0,1,0);
      if (iVar2 == 0) {
        auStack_1c8[0] = 0;
        uStack_1c4 = _DAT_;
        uStack_1c0 = uRam0000000001821bac;
        uStack_1bc = uRam0000000001821bb0;
        uStack_1b8 = uRam0000000001821bb4;
        uStack_1b4 = *param_1;
        uStack_1b0 = param_1[1];
        uStack_1ac = param_1[2];
        uStack_1a8 = param_1[3];
        uStack_1a4 = _DAT_;
        uStack_1a0 = uRam0000000001821bac;
        uStack_19c = uRam0000000001821bb0;
        uStack_198 = uRam0000000001821bb4;
        func_0x(auStack_1c8,0);
        (*_DAT_)(auStack_b8,0x41,0x1a8a620);
        func_0x(auStack_1c8,param_1);
        puVar4 = (undefined4 *)func_0x(&lStack_248,0x1a8b8c0,&lStack_290,aiStack_298);
        if (puVar4 == (undefined4 *)0x0) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1c469d0,0x1c20b90,0x24e);
        }
        if (lStack_290 != 4) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1c46a00,0x1c20b90,0x251);
        }
        if (aiStack_298[0] == 3) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1c469e0,0x1c20b90,0x253);
        }
        param_1[0x53] = *puVar4;
        piVar5 = (int *)func_0x(&lStack_248,0x1a8b780,&lStack_290,aiStack_298);
        if (piVar5 == (int *)0x0) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1c469d0,0x1c20b90,0x24e);
        }
        if (lStack_290 != 4) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1c46a00,0x1c20b90,0x251);
        }
        if (aiStack_298[0] == 3) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1c469e0,0x1c20b90,0x253);
        }
        iVar2 = *piVar5;
        param_1[0x54] = iVar2;
        if (iVar2 < 5) {
          param_1[0x54] = 5;
          func_0x(auStack_1c8,0x1a8b7a0);
        }
        auStack_288[0] = 0;
        if (lStack_248 != 0) {
          uVar3 = func_0x(&lStack_248,0x1a8b758,auStack_288);
          uVar7 = (ulonglong)uVar3;
          if (uVar7 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_1e8)) {
LAB_:
            if (uVar3 <= uStack_1e0) {
              lVar8 = (ulonglong)(uVar3 - 1) * 0x58 + lStack_1e8;
              lVar6 = *(longlong *)(lVar8 + 8) + lStack_248;
              if (((lVar6 != 0) && (*(longlong *)(*(longlong *)(lVar8 + 0x10) + lStack_248) == 10))
                 && (*(int *)(lStack_248 + *(longlong *)(lVar8 + 0x18)) != 3)) {
                puVar4 = param_1 + 0x4f;
                func_0x(puVar4,lVar6,10);
                *puVar4 = CONCAT31(CONCAT21(CONCAT11(*(undefined *)puVar4,
                                                     *(undefined *)((longlong)param_1 + 0x13d)),
                                            *(undefined *)((longlong)param_1 + 0x13e)),
                                   *(undefined *)((longlong)param_1 + 0x13f));
                param_1[0x50] =
                     CONCAT31(CONCAT21(CONCAT11(*(undefined *)(param_1 + 0x50),
                                                *(undefined *)((longlong)param_1 + 0x141)),
                                       *(undefined *)((longlong)param_1 + 0x142)),
                              *(undefined *)((longlong)param_1 + 0x143));
                *(ushort *)(param_1 + 0x51) =
                     CONCAT11(*(undefined *)(param_1 + 0x51),
                              *(undefined *)((longlong)param_1 + 0x145));
              }
            }
          }
          else {
            uVar3 = 1;
            if (uStack_1e0 != 0) {
              do {
                if (uVar7 == *(ulonglong *)((ulonglong)(uVar3 - 1) * 0x58 + lStack_1e8))
                goto LAB_;
                uVar3 = uVar3 + 1;
              } while (uVar3 <= uStack_1e0);
            }
          }
        }
        uStack_260 = *(undefined8 *)(param_1 + 0x4f);
        uStack_258 = *(undefined2 *)(param_1 + 0x51);
        uStack_2b8 = &uStack_260;
        uStack_2c0 = 0x1a8b768;
        uStack_2c8 = CONCAT44(uStack_2c8._4_4_,param_1[0x54]);
        func_0x(auStack_1c8,0x1a8c2c0,param_1[0x53],0x1a8c298);
      }
    }
    func_0x(&lStack_248);
  }
  func_0x(&uStack_280,0);
  if ((int)uStack_280 != 0) {
    func_0x(&uStack_280,0);
  }
  func_0x(uStack_28 ^ (ulonglong)auStack_2e8);
  return;
}

