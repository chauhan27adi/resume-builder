
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,int param_3,longlong param_4,
                 ulonglong param_5,uint param_6,longlong *param_7)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong *plVar3;
  code *pcVar4;
  byte bVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  int iVar9;
  longlong lVar10;
  uint *puVar11;
  short *psVar12;
  longlong lVar13;
  uint *puVar14;
  longlong lVar15;
  ulonglong *puVar16;
  longlong lVar17;
  uint uVar18;
  uint *puVar19;
  ulonglong uVar20;
  short sVar21;
  undefined *puVar22;
  undefined *puVar23;
  ushort *puVar24;
  uint uVar25;
  uint *puVar26;
  byte *pbVar27;
  uint uVar28;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_180;
  undefined auStack_178 [32];
  uint *puStack_158;
  undefined4 auStack_150 [2];
  uint *puStack_148;
  uint auStack_140 [10];
  uint uStack_118;
  uint uStack_114;
  uint uStack_110;
  undefined4 uStack_10c;
  longlong *plStack_108;
  int iStack_100;
  undefined4 uStack_fc;
  undefined2 uStack_f8;
  undefined4 uStack_e8;
  undefined2 uStack_e4;
  longlong lStack_d8;
  longlong *plStack_d0;
  ulonglong uStack_c8;
  longlong lStack_c0;
  longlong *plStack_b8;
  longlong *plStack_b0;
  undefined8 uStack_a8;
  longlong lStack_a0;
  longlong *plStack_98;
  undefined8 uStack_80;
  undefined auStack_78 [32];
  undefined auStack_58 [16];
  ulonglong uStack_48;
  
  puVar23 = auStack_178;
  uStack_80 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_118;
  plStack_b0 = param_7;
  plStack_98 = param_7;
  uStack_110 = param_6;
  uStack_10c = 0x80004005;
  iVar8 = 0;
  plStack_108 = (longlong *)0x0;
  lVar13 = *(longlong *)param_1[0x5c];
  plVar1 = (longlong *)((longlong *)param_1[0x5c])[1];
  *param_7 = 0;
  puVar22 = auStack_178;
  plStack_d0 = plVar1;
  lStack_c0 = lVar13;
  plStack_b8 = param_1;
  uStack_a8 = param_2;
  if ((param_4 == 0) || (puVar22 = auStack_178, param_3 != 0x10)) goto LAB_;
  lVar10 = *(longlong *)(lVar13 + 8);
  if (*(longlong *)(lVar10 + 0x478) != 0) {
    lVar10 = *(longlong *)(lVar10 + 0x478);
  }
  if ((*(byte *)(lVar10 + 0x474) & 1) == 0) {
    puStack_158 = (uint *)auStack_58;
    uStack_180 = 0x100bcc;
    iVar9 = func_0x(lVar13,param_5 & 0xffffffff,0x10);
    puVar22 = auStack_178;
    if (iVar9 == 0) goto LAB_;
    uStack_118 = 0x10;
    puVar22 = auStack_58;
    uVar28 = uStack_110;
  }
  else {
    uStack_180 = 0x1000d8;
    iVar8 = func_0x(lVar13,plVar1);
    puVar22 = auStack_178;
    if (iVar8 == 0) goto LAB_;
    iStack_100 = (int)*(short *)(param_4 + 2);
    uStack_180 = 0x1000fc;
    lVar10 = (**(code **)(*plVar1 + 0xe0))(plVar1,iStack_100,auStack_78);
    puVar22 = auStack_178;
    lStack_d8 = lVar10;
    if (((*(byte *)(lVar10 + 4) & 2) != 0) ||
       (uStack_c8 = param_5, puVar22 = auStack_178,
       param_5 != *(uint *)(*(longlong *)(lVar10 + 8) + 4))) goto LAB_;
    uStack_180 = 0x10013a;
    puVar11 = (uint *)func_0x
                                (*(undefined8 *)(*(longlong *)(lVar13 + 8) + 0x160),
                                 param_5 & 0xffffffff);
    uStack_180 = 0x100157;
    (**(code **)(*param_1 + 0x80))(param_1,*(longlong *)(lVar10 + 8) + 0xc);
    if (plStack_108 == (longlong *)0x0) {
      puStack_158 = (uint *)0x0;
      uStack_180 = 0x100184;
      (*_DAT_)(1,0x192a910,0x18fe2c8,0xcb1);
    }
    plVar1 = plStack_108;
    puVar26 = (uint *)0x0;
    uStack_180 = 0x10019b;
    psVar12 = (short *)func_0x(plStack_108,1);
    uStack_180 = 0x1001a8;
    lVar13 = func_0x();
    lVar13 = -lVar13;
    bVar5 = *(byte *)(puVar11 + 8);
    if (*psVar12 == 0) {
      uVar28 = *puVar11;
      if ((uVar28 & 0xc0000000) == 0x80000000) {
        *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100a64;
        iVar8 = func_0x(psVar12 + 1);
        if (iVar8 != 0) {
          *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100a80;
          puVar26 = (uint *)func_0x(psVar12 + 0x15,puVar11,&uStack_118,&uStack_fc);
          goto LAB_;
        }
LAB_:
        uStack_118 = 0;
      }
      else {
        if (((bVar5 & 2) != 0) || ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0)) {
          pbVar27 = *(byte **)(psVar12 + 4);
          if ((*pbVar27 & 0x10) == 0) {
            if ((1 << (*pbVar27 & 0xe) & 0x1105U) != 0) goto LAB_;
            puVar14 = puVar26;
            puVar19 = (uint *)0x1;
LAB_:
            uVar25 = (uint)puVar14;
            iVar8 = (int)puVar19;
            if ((bVar5 & 2) != 0) goto LAB_;
          }
          else {
            uVar25 = *(uint *)(psVar12 + 8);
            if ((int)uVar25 <= (int)uVar28) {
LAB_:
              puVar14 = (uint *)(ulonglong)(~(uint)(*(ushort *)((longlong)puVar11 + 6) >> 4) & 1);
              puVar19 = puVar26;
              goto LAB_;
            }
            if ((uint)*(ushort *)(pbVar27 + uVar25) < (uint)*(ushort *)(puVar11 + 1))
            goto LAB_;
            if ((bVar5 & 2) == 0) goto LAB_;
            uVar18 = *(ushort *)(puVar11 + 1) - 1;
            uVar25 = pbVar27[(ulonglong)(uVar18 >> 3) + (ulonglong)uVar25 + 2] >> ((byte)uVar18 & 7)
                     & 1;
            iVar8 = 1;
LAB_:
            if (uVar25 != 0) goto LAB_;
          }
          if ((iVar8 == 0) && ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0)) {
            puVar26 = *(uint **)(puVar11 + 2) + 1;
            uStack_118 = **(uint **)(puVar11 + 2);
            goto LAB_;
          }
        }
LAB_:
        if ((int)uVar28 < 0) {
          if (*(int *)(psVar12 + 2) == 0) {
            psVar12[1] = 0;
            uVar28 = *(uint *)(psVar12 + 8);
            uVar20 = (ulonglong)uVar28;
            *(uint *)(psVar12 + 10) = uVar28;
            pbVar27 = *(byte **)(psVar12 + 4);
            bVar5 = *pbVar27;
            if ((bVar5 & 0x10) != 0) {
              uVar28 = uVar28 + (*(ushort *)(pbVar27 + uVar20) + 7 >> 3) + 2;
              uVar20 = (ulonglong)uVar28;
              *(uint *)(psVar12 + 10) = uVar28;
              bVar5 = *pbVar27;
            }
            if ((bVar5 & 0x20) == 0) {
              *(int *)(psVar12 + 2) = (int)uVar20;
              psVar12[0xe] = 0;
              *(int *)(psVar12 + 0xc) = (int)uVar20;
            }
            else {
              puVar24 = (ushort *)(pbVar27 + uVar20);
              uVar6 = *puVar24;
              psVar12[0xe] = uVar6;
              if (uVar6 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar10 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0)) &&
                   ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                    (*(char *)(lVar10 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100440;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_150 + lVar13 + -8) = 0;
                    *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100466;
                    (*_DAT_)(1,0x1779ef8,0x1899bc8,0x80f);
                  }
                }
                uVar2 = *(undefined8 *)(psVar12 + 4);
                *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100474;
                func_0x(uVar2,3);
                uVar6 = psVar12[0xe];
                uVar20 = (ulonglong)*(uint *)(psVar12 + 10);
              }
              uVar28 = (int)uVar20 + (uVar6 + 1) * 2;
              *(uint *)(psVar12 + 0xc) = uVar28;
              if (0x1f9e < uVar28) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar10 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0 &&
                    ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                     (*(char *)(lVar10 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100513;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_150 + lVar13 + -8) = 0;
                    *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100539;
                    (*_DAT_)(1,0x1779ef8,0x1899bc8,0x816);
                  }
                }
                uVar2 = *(undefined8 *)(psVar12 + 4);
                *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100547;
                func_0x(uVar2,4);
                uVar6 = psVar12[0xe];
                uVar28 = *(uint *)(psVar12 + 0xc);
              }
              uVar20 = (ulonglong)uVar6;
              uVar6 = puVar24[uVar20];
              *(uint *)(psVar12 + 2) = uVar6 & 0x7fff;
              if ((uVar6 & 0x7fff) < uVar28) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar10 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0)) &&
                   ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                    (*(char *)(lVar10 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x1005e5;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_150 + lVar13 + -8) = 0;
                    *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x10060b;
                    (*_DAT_)(1,0x1779ef8,0x1899bc8,0x81d);
                  }
                }
                uVar2 = *(undefined8 *)(psVar12 + 4);
                *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100619;
                func_0x(uVar2,4);
                uVar20 = (ulonglong)(ushort)psVar12[0xe];
              }
              if ((short)puVar24[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
                lVar10 = *(longlong *)(psVar12 + 4);
                do {
                  lVar15 = (ulonglong)*(uint *)(psVar12 + 10) + lVar10;
                  if ((int)uVar20 == 1) {
                    uVar28 = *(uint *)(psVar12 + 0xc);
                    uVar6 = *(ushort *)(lVar15 + uVar20 * 2);
                    uVar25 = uVar28;
LAB_:
                    if ((uVar6 & 0x7fff) < uVar28) goto LAB_;
                  }
                  else {
                    uVar28 = *(ushort *)(lVar15 + -2 + uVar20 * 2) & 0x7fff;
                    uVar25 = *(uint *)(psVar12 + 0xc);
                    uVar6 = *(ushort *)(lVar15 + uVar20 * 2);
                    if (uVar25 <= uVar28) goto LAB_;
LAB_:
                    *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x10068e;
                    func_0x(lVar10,7);
                    uVar25 = *(uint *)(psVar12 + 0xc);
                  }
                  if ((uVar28 < uVar25) || (*(uint *)(psVar12 + 2) < uVar28)) goto LAB_;
                  lVar10 = *(longlong *)(psVar12 + 4);
                  if (*(ushort *)(lVar10 + (ulonglong)uVar28) == 5) {
                    psVar12[1] = psVar12[1] | 2;
                    psVar12[0xe] = psVar12[0xe] + -1;
                    psVar12[0x15] = (short)uVar28;
                    lVar10 = (ulonglong)(uVar28 & 0xffff) + *(longlong *)(psVar12 + 4);
                    uVar6 = *(ushort *)(lVar10 + 2);
                    uVar7 = psVar12[0x16] & 0xc7ff;
                    if ((uVar6 & 0x4000) != 0) {
                      uVar7 = uVar6 & 0x3800 | uVar7;
                    }
                    psVar12[0x16] = uVar7;
                    psVar12[0x16] = (uVar7 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar7;
                    uVar20 = (ulonglong)*(uint *)(psVar12 + 2);
                    pbVar27 = *(byte **)(psVar12 + 4);
                    goto LAB_;
                  }
                  if (*(ushort *)(lVar10 + (ulonglong)uVar28) < 0x400) break;
                  psVar12[1] = psVar12[1] | 1;
                  uVar6 = psVar12[0xe] - 1;
                  psVar12[0xe] = uVar6;
                  if ((uVar6 == 0) ||
                     (uVar20 = (ulonglong)uVar6, -1 < (short)puVar24[(ulonglong)(uVar6 - 1) + 1]))
                  break;
                } while( true );
              }
              uVar20 = (ulonglong)*(uint *)(psVar12 + 2);
              pbVar27 = *(byte **)(psVar12 + 4);
            }
LAB_:
            if ((*pbVar27 & 0x40) == 0) {
              *(undefined4 *)(psVar12 + 0x13) = 0;
            }
            else {
              *(int *)(psVar12 + 0x13) = (int)uVar20;
              *(int *)(psVar12 + 2) = (int)uVar20 + 0xe;
              *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x10079d;
              puVar16 = (ulonglong *)func_0x(psVar12 + 1);
              uVar20 = *puVar16;
              iVar8 = 0;
              uVar6 = (ushort)(uVar20 >> 0x30);
              if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
                if ((uVar20 & 0x4000000000000000) == 0) {
                  uVar6 = uVar6 & 0xdfff;
                }
                else {
                  uVar6 = uVar6 | 0x2000;
                }
              }
              if (uVar6 == 0xfffc) {
                iVar8 = (int)((uVar20 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + iVar8;
              uVar20 = (ulonglong)*(uint *)(psVar12 + 2);
            }
            iVar8 = (int)uVar20;
            if ((*(ulonglong *)(psVar12 + 0xf) != 0) &&
               (*(ulonglong *)(psVar12 + 0xf) < uVar20 + *(longlong *)(psVar12 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar10 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0 &&
                   (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
                  (*(char *)(lVar10 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x10088e;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)((longlong)auStack_150 + lVar13 + -8) = 0;
                  *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x1008b4;
                  (*_DAT_)(1,0x1779ef8,0x1899bc8,0x877);
                }
              }
              uVar2 = *(undefined8 *)(psVar12 + 4);
              *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x1008c2;
              func_0x(uVar2,0x12);
              iVar8 = *(int *)(psVar12 + 2);
            }
            if (0x3f3b < iVar8 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar10 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar10 != 0 &&
                  ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                   (*(char *)(lVar10 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x10094e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)((longlong)auStack_150 + lVar13 + -8) = 0;
                  *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100974;
                  (*_DAT_)(1,0x1779ef8,0x1899bc8,0x87c);
                }
              }
              uVar2 = *(undefined8 *)(psVar12 + 4);
              *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100982;
              func_0x(uVar2,5);
            }
          }
LAB_:
          sVar21 = -*(short *)puVar11;
          if ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0) {
            bVar5 = **(byte **)(psVar12 + 4);
            if ((bVar5 & 0x10) == 0) {
              if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar26 = *(uint **)(puVar11 + 2) + 1;
                uStack_118 = **(uint **)(puVar11 + 2);
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(psVar12 + 8) <= (int)*puVar11) ||
                    (*(ushort *)(*(byte **)(psVar12 + 4) + *(uint *)(psVar12 + 8)) <
                     *(ushort *)(puVar11 + 1))) goto LAB_;
          }
          lVar10 = (longlong)sVar21;
          if ((uint)(ushort)psVar12[0xe] < (uint)(int)sVar21) {
            uStack_118 = 0;
            puVar26 = *(uint **)(psVar12 + 4);
          }
          else {
            lVar15 = *(longlong *)(psVar12 + 4);
            lVar17 = (ulonglong)*(uint *)(psVar12 + 10) + lVar15;
            if (sVar21 == 1) {
              uVar28 = *(uint *)(psVar12 + 0xc);
              uVar25 = *(ushort *)(lVar17 + lVar10 * 2) & 0x7fff;
LAB_:
              if (uVar25 < uVar28) goto LAB_;
            }
            else {
              uVar28 = *(ushort *)(lVar17 + -2 + lVar10 * 2) & 0x7fff;
              uVar25 = *(ushort *)(lVar17 + lVar10 * 2) & 0x7fff;
              lVar15 = *(longlong *)(psVar12 + 4);
              if (*(uint *)(psVar12 + 0xc) <= uVar28) goto LAB_;
LAB_:
              *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100a3b;
              func_0x(lVar15,7);
            }
            puVar26 = (uint *)((ulonglong)uVar28 + *(longlong *)(psVar12 + 4));
            uStack_118 = uVar25 - uVar28;
          }
        }
        else {
          uVar6 = *(ushort *)((longlong)puVar11 + 6);
          if ((uVar6 & 8) == 0) {
            if ((uVar6 & 0x10) != 0) {
              bVar5 = **(byte **)(psVar12 + 4);
              if ((bVar5 & 0x10) == 0) {
                if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                  puVar26 = *(uint **)(puVar11 + 2) + 1;
                  uStack_118 = **(uint **)(puVar11 + 2);
                  if (uStack_118 != 0x1f9e) {
                    *(undefined8 *)((longlong)auStack_150 + lVar13 + -8) = 0;
                    *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100329;
                    (*_DAT_)(1,0x1927c68,0x1926668,0x381);
                  }
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(psVar12 + 8) <= (int)uVar28) ||
                      (*(ushort *)(*(byte **)(psVar12 + 4) + *(uint *)(psVar12 + 8)) <
                       *(ushort *)(puVar11 + 1))) goto LAB_;
            }
            uStack_118 = 0x1f9e;
            puVar26 = (uint *)((longlong)(int)*puVar11 + *(longlong *)(psVar12 + 4));
          }
          else {
            uStack_118 = 1;
            puVar26 = (uint *)0x14fe934;
            if ((*(byte *)((longlong)(int)uVar28 + *(longlong *)(psVar12 + 4)) &
                (byte)(1 << ((byte)uVar6 & 7))) == 0) {
              puVar26 = (uint *)0x14fef58;
            }
          }
        }
      }
    }
    else {
      uStack_114 = 0;
      *(uint **)((longlong)auStack_150 + lVar13 + -8) = &uStack_114;
      *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100aa1;
      puVar26 = (uint *)func_0x(psVar12 + 1,puVar11);
      if ((((*psVar12 != 0) && (plVar3 = *(longlong **)(psVar12 + 8), plVar3 != (longlong *)0x0)) &&
          (*plVar3 != 0)) &&
         (((*(byte *)((longlong)puVar11 + 6) & 8) == 0 && ((uStack_114 & 1) == 0)))) {
        if ((puVar26 == (uint *)0x0) || (puVar26 == (uint *)0x14fe934)) {
          puVar26 = (uint *)0x0;
          uStack_118 = 0;
        }
        else {
          *(uint *)((longlong)auStack_140 + lVar13) = uStack_114;
          *(uint **)((longlong)&puStack_148 + lVar13) = &uStack_118;
          *(undefined4 *)((longlong)auStack_150 + lVar13) = 0x1f9e;
          *(longlong *)((longlong)auStack_150 + lVar13 + -8) = (longlong)&uStack_118 + lVar13;
          uVar28 = uStack_118;
          *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100b01;
          puVar26 = (uint *)func_0x(plVar3,puVar11,puVar26,uVar28);
        }
      }
    }
LAB_:
    if (puVar26 == (uint *)0x0) {
      uVar28 = param_6 | 8;
    }
    else {
      *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100b24;
      iVar8 = func_0x(psVar12,puVar11);
      uVar28 = uStack_110;
      if (iVar8 == 0) {
        uVar28 = param_6 | 0x200;
      }
    }
    *(undefined8 *)(auStack_178 + lVar13 + -8) = 0x100b52;
    lVar10 = func_0x();
    lVar10 = -lVar10;
    puVar23 = auStack_178 + lVar10 + lVar13;
    puVar22 = (undefined *)((longlong)&uStack_118 + lVar10 + lVar13);
    *(undefined8 *)(auStack_178 + lVar10 + lVar13 + -8) = 0x100b68;
    func_0x(puVar22);
    if (((*(byte *)(lStack_d8 + 4) & 1) == 0) &&
       ((*(uint *)(*(longlong *)(plStack_d0[6] + 0x6b0) + 0x278) & 0x1000) == 0)) {
      uVar28 = uVar28 | 0x10000;
    }
    pcVar4 = *(code **)(*plVar1 + 8);
    *(undefined8 *)(auStack_178 + lVar10 + lVar13 + -8) = 0x100b9c;
    (*pcVar4)(plVar1);
    lVar13 = lStack_c0;
    param_5 = uStack_c8;
    param_1 = plStack_b8;
    param_7 = plStack_b0;
    iVar8 = iStack_100;
  }
  uStack_fc = 0;
  uStack_f8 = 0;
  uStack_e8 = 0;
  uStack_e4 = 0;
  *(undefined4 **)(puVar23 + 0x50) = &uStack_e8;
  *(int *)(puVar23 + 0x48) = iVar8;
  *(longlong **)(puVar23 + 0x40) = param_7;
  *(uint *)(puVar23 + 0x38) = uVar28 | 0x80;
  *(ulonglong *)(puVar23 + 0x30) = param_5;
  *(uint *)(puVar23 + 0x28) = uStack_118;
  *(undefined **)(puVar23 + 0x20) = puVar22;
  uVar2 = uStack_a8;
  lVar10 = param_1[0x3d];
  *(undefined8 *)(puVar23 + -8) = 0x100c3e;
  iVar8 = func_0x(param_1,uVar2,lVar10,1);
  if (iVar8 != 0) {
    uStack_10c = 0;
    lStack_a0 = *(longlong *)(lVar13 + 8);
    lVar13 = lStack_a0;
    if (*(longlong *)(lStack_a0 + 0x478) != 0) {
      lVar13 = *(longlong *)(lStack_a0 + 0x478);
    }
    if ((*(byte *)(lVar13 + 0x474) & 1) != 0) {
      lVar13 = *param_7;
      *(int *)((longlong)plStack_108 + 0xc) = *(int *)((longlong)plStack_108 + 0xc) + 1;
      *(longlong **)(lVar13 + 0x150) = plStack_108;
      *(undefined4 *)(lVar13 + 0x158) = 1;
      plStack_108 = (longlong *)0x0;
    }
  }
  lVar10 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar13 = *(longlong *)(lVar10 + 0x100);
  if (lVar13 == 0) {
    *(undefined8 *)(puVar23 + -8) = 0x100cc6;
    (*_DAT_)();
    lVar13 = *(longlong *)(lVar10 + 0x100);
  }
  puVar22 = puVar23;
  if (*(int *)(lVar13 + 0x22c) != 0) {
    *(undefined8 *)(puVar23 + -8) = 0x100cdc;
    (*_DAT_)();
  }
LAB_:
  uVar20 = uStack_48 ^ (ulonglong)&uStack_118;
  *(undefined8 *)(puVar22 + -8) = 0x100cf5;
  func_0x(uVar20);
  return;
}

