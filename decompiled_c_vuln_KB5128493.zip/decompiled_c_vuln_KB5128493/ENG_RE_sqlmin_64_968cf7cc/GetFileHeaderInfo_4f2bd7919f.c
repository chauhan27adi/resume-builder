
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,undefined8 param_3)

{
  undefined4 *puVar1;
  code *pcVar2;
  char cVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  undefined8 uVar11;
  ulonglong *puVar12;
  longlong *plVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ushort uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  undefined8 unaff_RBX;
  longlong lVar21;
  int *piVar22;
  ushort *puVar23;
  int *piVar24;
  int *piVar25;
  short sVar26;
  longlong lVar27;
  longlong unaff_GS_OFFSET;
  int aiStackX_8 [2];
  int iStackX_10;
  ushort uStackX_14;
  ushort uStackX_16;
  int *piStackX_18;
  uint uStackX_20;
  uint uStackX_24;
  undefined4 auStack_4148 [2];
  longlong lStack_4140;
  undefined8 uStack_4138;
  short sStack_40f8;
  ushort uStack_40f6;
  uint uStack_40f4;
  int *piStack_40f0;
  undefined8 uStack_40e8;
  uint uStack_40e0;
  ushort uStack_40dc;
  byte *pbStack_40da;
  undefined2 uStack_40d2;
  undefined2 uStack_40d0;
  undefined2 uStack_40ce;
  ushort uStack_40cc;
  undefined2 uStack_40ca;
  undefined4 uStack_40c4;
  undefined auStack_4048 [8191];
  undefined auStack_2049 [8193];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  uStack_4138 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004198 + lVar9) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9);
  *(undefined8 *)(&stack0x00000040 + lVar9) = param_3;
  lVar27 = -1;
  lStack_4140 = -1;
  lVar21 = *param_2;
  lVar10 = -1;
  do {
    lVar10 = lVar10 + 1;
  } while (*(short *)(lVar21 + lVar10 * 2) != 0);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10007c;
  cVar3 = func_0x(lVar21,lVar10 * 2,&lStack_4140,auStack_4148);
  if (cVar3 == '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100091;
    func_0x(param_3,1);
    lVar10 = *param_2;
    lVar21 = -1;
    do {
      lVar21 = lVar21 + 1;
    } while (*(short *)(lVar10 + lVar21 * 2) != 0);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000c3;
    uVar11 = (*_DAT_)(auStack_4148[0],auStack_4048,0,0);
    *(longlong *)(&stack0xfffffffffffffff8 + lVar9) = lVar10;
    *(int *)(&stack0xfffffffffffffff0 + lVar9) = (int)lVar21 * 2;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = uVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000e7;
    (*_DAT_)(0x33,0x17,0x10,0x14);
  }
  sStack_40f8 = -1;
  piVar25 = (int *)0x0;
  piStack_40f0 = (int *)0x0;
  uStack_40f4 = 0;
  pbStack_40da = (byte *)0x0;
  uStack_40d0 = 0;
  uStack_40ce = 0;
  uStack_40cc = 0;
  uStack_40ca = 0;
  uStack_40e8 = (longlong *)0x0;
  uStack_40c4 = 0xffffffff;
  puVar23 = (ushort *)((longlong)&uStackX_14 + lVar9 + 2);
  *puVar23 = *puVar23 & 0xffe0;
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10012c;
  iVar6 = func_0x(&lStack_4140,(ulonglong)auStack_2049 & 0xfffffffffffff000,&sStack_40f8);
  if (iVar6 == 0) {
    lVar10 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100146;
    func_0x(param_3,0x1c,lVar10,0x13f9228);
  }
  *(undefined4 *)((longlong)&iStackX_10 + lVar9) = 0xfffffffc;
  piVar22 = (int *)0x4;
  *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 4;
  *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar9 + 4) = 0;
  iVar8 = 0;
  iVar6 = 0;
  if (sStack_40f8 == 0) {
    if ((*(byte *)piStack_40f0 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_40f0 & 0xe) & 0x1105U) != 0) {
        bVar4 = 0xff;
        iVar7 = 0;
        goto LAB_;
      }
LAB_:
      piVar22 = piStack_40f0;
      uVar18 = uStack_40e0;
      if (uStack_40f4 == 0) {
        uStack_40f6 = 0;
        uVar14 = (ulonglong)uStack_40e8 & 0xffffffff;
        uVar18 = (uint)uStack_40e8;
        if ((*(byte *)piStack_40f0 & 0x10) != 0) {
          uVar18 = (uint)uStack_40e8 + 2 + (*(ushort *)(uVar14 + (longlong)piStack_40f0) + 7 >> 3);
          uVar14 = (ulonglong)uVar18;
        }
        uStack_40e8 = (longlong *)CONCAT44(uVar18,(uint)uStack_40e8);
        uVar18 = (uint)uVar14;
        if ((*(byte *)piStack_40f0 & 0x20) == 0) {
          uStack_40dc = 0;
          uStack_40f4 = uVar18;
          uStack_40e0 = uVar18;
        }
        else {
          puVar23 = (ushort *)(uVar14 + (longlong)piStack_40f0);
          uStack_40dc = *puVar23;
          if (uStack_40dc == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002f7;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10031b;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10032c;
            func_0x(piStack_40f0,3);
          }
          uStack_40e0 = uStack_40e8._4_4_ + (uStack_40dc + 1) * 2;
          if (0x1f9e < uStack_40e0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003ca;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003ee;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003fc;
            func_0x(piStack_40f0,4);
          }
          uStack_40f4 = puVar23[uStack_40dc] & 0x7fff;
          uVar14 = (ulonglong)uStack_40f4;
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
          if (uStack_40f4 < uStack_40e0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10049b;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004bf;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004cd;
            func_0x(piStack_40f0,4);
            uVar14 = (ulonglong)uStack_40f4;
            piVar22 = piStack_40f0;
            uVar18 = uStack_40e0;
          }
          do {
            uVar15 = (ulonglong)uStack_40dc;
            if (-1 < (short)puVar23[(ulonglong)(uStack_40dc - 1) + 1]) break;
            if (uStack_40dc == 1) {
              uVar15 = 1;
              uVar19 = uVar18;
            }
            else {
              uVar19 = *(ushort *)
                        ((longlong)piVar22 + uVar15 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar19 < uVar18) ||
               ((*(ushort *)((longlong)piVar22 + uVar15 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) &
                0x7fff) < uVar19)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100534;
              func_0x(piVar22,7);
              uVar14 = (ulonglong)uStack_40f4;
              piVar22 = piStack_40f0;
              uVar18 = uStack_40e0;
            }
            if ((uVar19 < uVar18) || ((uint)uVar14 < uVar19)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar22) == 5) {
              uStack_40f6 = uStack_40f6 | 2;
              uStack_40dc = uStack_40dc - 1;
              uStack_40ce = (undefined2)uVar19;
              uVar5 = *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar22);
              if ((uVar5 & 0x4000) == 0) {
                uStack_40cc = uStack_40cc & 0xc7ff;
              }
              else {
                uStack_40cc = uStack_40cc ^ (uStack_40cc ^ uVar5) & 0x3800;
              }
              uStack_40cc = (uStack_40cc ^
                            *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar22)) &
                            0x7ff ^ uStack_40cc;
              break;
            }
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar22) < 0x400) break;
            uStack_40f6 = uStack_40f6 | 1;
            uStack_40dc = uStack_40dc - 1;
          } while (uStack_40dc != 0);
        }
        if ((*(byte *)piVar22 & 0x40) == 0) {
          uStack_40d2 = 0;
          uStack_40d0 = 0;
        }
        else {
          uStack_40d2 = (undefined2)uVar14;
          uStack_40d0 = (undefined2)(uVar14 >> 0x10);
          uStack_40f4 = (int)uVar14 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10061c;
          puVar12 = (ulonglong *)func_0x(&uStack_40f6);
          uVar14 = *puVar12;
          uVar17 = (ushort)(uVar14 >> 0x30);
          uVar5 = uVar17;
          if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
            uVar5 = uVar17 & 0xdfff;
            if ((uVar14 & 0x4000000000000000) != 0) {
              uVar5 = uVar17 | 0x2000;
            }
          }
          iVar7 = iVar8;
          if (uVar5 == 0xfffc) {
            iVar7 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
          }
          uStack_40f4 = uStack_40f4 + iVar7;
          uVar14 = (ulonglong)uStack_40f4;
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
        }
        uVar19 = (uint)uVar14;
        if ((pbStack_40da != (byte *)0x0) && (pbStack_40da < (byte *)(uVar14 + (longlong)piVar22)))
        {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar10 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), piVar22 = piStack_40f0, lVar10 != 0 &&
               (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100722;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
              piVar22 = piStack_40f0;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100746;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x877);
              piVar22 = piStack_40f0;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100757;
          func_0x(piVar22,0x12);
          piVar22 = piStack_40f0;
          uVar19 = uStack_40f4;
          uVar18 = uStack_40e0;
        }
        if (0x3f3b < uVar19 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar10 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), piVar22 = piStack_40f0, lVar10 != 0 &&
              ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
               (*(char *)(lVar10 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1007ec;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              piVar22 = piStack_40f0;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100810;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x87c);
              piVar22 = piStack_40f0;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100821;
          func_0x(piVar22,5);
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
        }
      }
LAB_:
      sVar26 = -*(short *)((longlong)&iStackX_10 + lVar9);
      if ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar22 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar22 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar1 = *(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
            piVar22 = puVar1 + 1;
            *(undefined4 *)((longlong)aiStackX_8 + lVar9) = *puVar1;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40e8 <= *(int *)((longlong)&iStackX_10 + lVar9)) ||
                (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piVar22) <
                 *(ushort *)((longlong)&uStackX_14 + lVar9))) goto LAB_;
      }
      if ((uint)uStack_40dc < (uint)(int)sVar26) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
      }
      else {
        piVar24 = piVar22;
        uVar19 = uVar18;
        if (sVar26 != 1) {
          uVar18 = *(ushort *)
                    ((longlong)piVar22 +
                    (longlong)sVar26 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) & 0x7fff;
          piVar24 = piStack_40f0;
          uVar19 = uStack_40e0;
        }
        uVar20 = *(ushort *)
                  ((longlong)piVar22 + (longlong)sVar26 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) &
                 0x7fff;
        if ((uVar18 < uVar19) || (uVar20 < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008e5;
          func_0x(piVar24,7);
          piVar24 = piStack_40f0;
        }
        piVar22 = (int *)((ulonglong)uVar18 + (longlong)piVar24);
        param_3 = *(undefined8 *)(&stack0x00000040 + lVar9);
        *(uint *)((longlong)aiStackX_8 + lVar9) = uVar20 - uVar18;
      }
    }
    else {
      iVar7 = iVar6;
      if ((int)(uint)uStack_40e8 < -3) {
        bVar4 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piStack_40f0) < 4) {
        bVar4 = 0xff;
      }
      else {
        bVar4 = *(byte *)(((ulonglong)uStack_40e8 & 0xffffffff) + 2 + (longlong)piStack_40f0) >> 3;
        iVar7 = 1;
      }
LAB_:
      if ((bVar4 & 1) == 0) {
        if ((iVar7 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = piVar25;
      }
    }
  }
  else {
    *(undefined4 *)((longlong)&uStackX_20 + lVar9) = 0;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar9) = (longlong)&uStackX_20 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10093e;
    piVar22 = (int *)func_0x(&uStack_40f6,(longlong)&iStackX_10 + lVar9);
    plVar13 = uStack_40e8;
    if ((((sStack_40f8 != 0) && (uStack_40e8 != (longlong *)0x0)) && (*uStack_40e8 != 0)) &&
       (((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 8) == 0 &&
        ((*(uint *)((longlong)&uStackX_20 + lVar9) & 1) == 0)))) {
      if ((piVar22 == (int *)0x0) || (piVar22 == (int *)0x114d954)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&uStackX_20 + lVar9 + -0x20) = *(uint *)((longlong)&uStackX_20 + lVar9);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar9) = (longlong)aiStackX_8 + lVar9;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10099a;
        piVar22 = (int *)func_0x
                                   (plVar13,(longlong)&iStackX_10 + lVar9,piVar22,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar9));
      }
    }
  }
LAB_:
  if ((piVar22 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar9) != 2)) {
    lVar10 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1009cb;
    func_0x(param_3,0x15,lVar10,0x13ec018);
  }
  *(short *)((longlong)param_2 + 10) = *(short *)piVar22;
  *(undefined4 *)((longlong)&iStackX_10 + lVar9) = 0xfffffffd;
  *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 3;
  uVar5 = *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) & 0xffe0;
  *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) = uVar5;
  *(undefined8 *)((longlong)&uStackX_14 + lVar9 + 4) = 0;
  if (sStack_40f8 == 0) {
    iVar7 = iVar8;
    if ((*(byte *)piStack_40f0 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_40f0 & 0xe) & 0x1105U) != 0) {
        bVar4 = 0xff;
        goto LAB_;
      }
LAB_:
      if (uStack_40f4 == 0) {
        uStack_40f6 = 0;
        uVar14 = (ulonglong)uStack_40e8 & 0xffffffff;
        uVar18 = (uint)uStack_40e8;
        if ((*(byte *)piStack_40f0 & 0x10) != 0) {
          uVar18 = (uint)uStack_40e8 + 2 + (*(ushort *)(uVar14 + (longlong)piStack_40f0) + 7 >> 3);
          uVar14 = (ulonglong)uVar18;
        }
        uStack_40e8 = (longlong *)CONCAT44(uVar18,(uint)uStack_40e8);
        if ((*(byte *)piStack_40f0 & 0x20) == 0) {
          uStack_40dc = 0;
          uStack_40f4 = (uint)uVar14;
          uStack_40e0 = (uint)uVar14;
        }
        else {
          puVar23 = (ushort *)(uVar14 + (longlong)piStack_40f0);
          uStack_40dc = *puVar23;
          if (uStack_40dc == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b73;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b97;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100ba2;
            func_0x(piStack_40f0,3);
          }
          uStack_40e0 = uStack_40e8._4_4_ + (uStack_40dc + 1) * 2;
          if (0x1f9e < uStack_40e0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c37;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c5b;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c69;
            func_0x(piStack_40f0,4);
          }
          uStack_40f4 = puVar23[uStack_40dc] & 0x7fff;
          if (uStack_40f4 < uStack_40e0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100cfd;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d21;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d2f;
            func_0x(piStack_40f0,4);
          }
          do {
            uVar14 = (ulonglong)uStack_40dc;
            if (-1 < (short)puVar23[(ulonglong)(uStack_40dc - 1) + 1]) break;
            if (uStack_40dc == 1) {
              uVar14 = 1;
              uVar18 = uStack_40e0;
            }
            else {
              uVar18 = *(ushort *)
                        ((longlong)piStack_40f0 +
                        uVar14 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) & 0x7fff;
            }
            if ((uVar18 < uStack_40e0) ||
               ((*(ushort *)((longlong)piStack_40f0 + uVar14 * 2 + ((ulonglong)uStack_40e8 >> 0x20))
                & 0x7fff) < uVar18)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d96;
              func_0x(piStack_40f0,7);
            }
            if ((uVar18 < uStack_40e0) || (uStack_40f4 < uVar18)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar18 + (longlong)piStack_40f0) == 5) {
              uStack_40f6 = uStack_40f6 | 2;
              uStack_40dc = uStack_40dc - 1;
              uStack_40ce = (undefined2)uVar18;
              uVar5 = *(ushort *)((longlong)piStack_40f0 + (ulonglong)(uVar18 & 0xffff) + 2);
              if ((uVar5 & 0x4000) == 0) {
                uStack_40cc = uStack_40cc & 0xc7ff;
              }
              else {
                uStack_40cc = uStack_40cc ^ (uStack_40cc ^ uVar5) & 0x3800;
              }
              uStack_40cc = (uStack_40cc ^
                            *(ushort *)((longlong)piStack_40f0 + (ulonglong)(uVar18 & 0xffff) + 2))
                            & 0x7ff ^ uStack_40cc;
              break;
            }
            if (*(ushort *)((ulonglong)uVar18 + (longlong)piStack_40f0) < 0x400) break;
            uStack_40f6 = uStack_40f6 | 1;
            uStack_40dc = uStack_40dc - 1;
          } while (uStack_40dc != 0);
        }
        if ((*(byte *)piStack_40f0 & 0x40) == 0) {
          uStack_40d2 = 0;
          uStack_40d0 = 0;
        }
        else {
          uStack_40d2 = (undefined2)uStack_40f4;
          uStack_40d0 = (undefined2)(uStack_40f4 >> 0x10);
          uStack_40f4 = uStack_40f4 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100e60;
          puVar12 = (ulonglong *)func_0x(&uStack_40f6);
          uVar14 = *puVar12;
          uVar17 = (ushort)(uVar14 >> 0x30);
          uVar5 = uVar17;
          if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
            uVar5 = uVar17 & 0xdfff;
            if ((uVar14 & 0x4000000000000000) != 0) {
              uVar5 = uVar17 | 0x2000;
            }
          }
          iVar7 = iVar8;
          if (uVar5 == 0xfffc) {
            iVar7 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
          }
          uStack_40f4 = uStack_40f4 + iVar7;
        }
        if ((pbStack_40da != (byte *)0x0) &&
           (pbStack_40da < (byte *)((ulonglong)uStack_40f4 + (longlong)piStack_40f0))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar10 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar10 != 0 && (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0))
              && (*(char *)(lVar10 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100f57;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100f7b;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x877);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100f89;
          func_0x(piStack_40f0,0x12);
        }
        if (0x3f3b < uStack_40f4 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar10 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar10 != 0 &&
              ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
               (*(char *)(lVar10 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101013;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101037;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x87c);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101045;
          func_0x(piStack_40f0,5);
        }
      }
LAB_:
      sVar26 = -*(short *)((longlong)&iStackX_10 + lVar9);
      if ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) != 0) {
        if ((*(byte *)piStack_40f0 & 0x10) == 0) {
          if ((1 << (*(byte *)piStack_40f0 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar1 = *(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
            piVar22 = puVar1 + 1;
            *(undefined4 *)((longlong)aiStackX_8 + lVar9) = *puVar1;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40e8 <= *(int *)((longlong)&iStackX_10 + lVar9)) ||
                (*(ushort *)((longlong)piStack_40f0 + ((ulonglong)uStack_40e8 & 0xffffffff)) <
                 *(ushort *)((longlong)&uStackX_14 + lVar9))) goto LAB_;
      }
      if ((uint)uStack_40dc < (uint)(int)sVar26) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = piStack_40f0;
      }
      else {
        uVar18 = uStack_40e0;
        if (sVar26 != 1) {
          uVar18 = *(ushort *)
                    ((longlong)piStack_40f0 +
                    (longlong)sVar26 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) & 0x7fff;
        }
        uVar19 = *(ushort *)
                  ((longlong)piStack_40f0 + (longlong)sVar26 * 2 + ((ulonglong)uStack_40e8 >> 0x20))
                 & 0x7fff;
        if ((uVar18 < uStack_40e0) || (uVar19 < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1010f5;
          func_0x(piStack_40f0,7);
        }
        *(uint *)((longlong)aiStackX_8 + lVar9) = uVar19 - uVar18;
        piVar22 = (int *)((ulonglong)uVar18 + (longlong)piStack_40f0);
      }
    }
    else {
      if ((int)(uint)uStack_40e8 < -2) {
        bVar4 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piStack_40f0) < 3) {
        bVar4 = 0xff;
      }
      else {
        bVar4 = *(byte *)(((ulonglong)uStack_40e8 & 0xffffffff) + 2 + (longlong)piStack_40f0) >> 2;
        iVar7 = 1;
      }
LAB_:
      if ((bVar4 & 1) == 0) {
        if ((iVar7 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
        piVar22 = (int *)0x4;
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = piVar25;
      }
    }
  }
  else {
    *(undefined4 *)((longlong)&uStackX_24 + lVar9) = 0;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar9) = (longlong)&uStackX_24 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101143;
    piVar22 = (int *)func_0x(&uStack_40f6,(longlong)&iStackX_10 + lVar9,uVar5,
                                     (longlong)aiStackX_8 + lVar9);
    plVar13 = uStack_40e8;
    if ((((sStack_40f8 != 0) && (uStack_40e8 != (longlong *)0x0)) && (*uStack_40e8 != 0)) &&
       (((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 8) == 0 &&
        ((*(uint *)((longlong)&uStackX_24 + lVar9) & 1) == 0)))) {
      if ((piVar22 == (int *)0x0) || (piVar22 == (int *)0x114d954)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&uStackX_20 + lVar9 + -0x20) = *(uint *)((longlong)&uStackX_24 + lVar9);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar9) = (longlong)aiStackX_8 + lVar9;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10119f;
        piVar22 = (int *)func_0x
                                   (plVar13,(longlong)&iStackX_10 + lVar9,piVar22,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar9));
      }
    }
  }
LAB_:
  if ((piVar22 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar9) != 2)) {
    lVar10 = *param_2;
    uVar11 = *(undefined8 *)(&stack0x00000040 + lVar9);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1011d5;
    func_0x(uVar11,0x16,lVar10,0x13ebf00);
  }
  else {
    uVar11 = *(undefined8 *)(&stack0x00000040 + lVar9);
  }
  if (*(short *)(param_2 + 1) != *(short *)piVar22) {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1011f1;
    func_0x(uVar11,1);
    do {
      lVar27 = lVar27 + 1;
    } while (*(short *)(*param_2 + lVar27 * 2) != 0);
    *(longlong *)(&stack0xfffffffffffffff0 + lVar9) = *param_2;
    *(int *)(&stack0xffffffffffffffe8 + lVar9) = (int)lVar27 * 2;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10122d;
    (*_DAT_)(0x33,0x47,0x10,0x16);
  }
  *(undefined4 *)((longlong)&iStackX_10 + lVar9) = 0xfffffffb;
  *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 5;
  uVar5 = *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) & 0xffe0;
  *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) = uVar5;
  *(undefined8 *)((longlong)&uStackX_14 + lVar9 + 4) = 0;
  if (sStack_40f8 == 0) {
    iVar7 = iVar8;
    if ((*(byte *)piStack_40f0 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_40f0 & 0xe) & 0x1105U) != 0) {
        bVar4 = 0xff;
        goto LAB_;
      }
LAB_:
      if (uStack_40f4 == 0) {
        uStack_40f6 = 0;
        uVar14 = (ulonglong)uStack_40e8 & 0xffffffff;
        uVar18 = (uint)uStack_40e8;
        if ((*(byte *)piStack_40f0 & 0x10) != 0) {
          uVar18 = (uint)uStack_40e8 + 2 + (*(ushort *)(uVar14 + (longlong)piStack_40f0) + 7 >> 3);
          uVar14 = (ulonglong)uVar18;
        }
        uStack_40e8 = (longlong *)CONCAT44(uVar18,(uint)uStack_40e8);
        if ((*(byte *)piStack_40f0 & 0x20) == 0) {
          uStack_40dc = 0;
          uStack_40f4 = (uint)uVar14;
          uStack_40e0 = (uint)uVar14;
        }
        else {
          puVar23 = (ushort *)(uVar14 + (longlong)piStack_40f0);
          uStack_40dc = *puVar23;
          if (uStack_40dc == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1013c8;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1013ec;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1013fa;
            func_0x(piStack_40f0,3);
          }
          uStack_40e0 = uStack_40e8._4_4_ + (uStack_40dc + 1) * 2;
          if (0x1f9e < uStack_40e0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10148f;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1014b3;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1014c1;
            func_0x(piStack_40f0,4);
          }
          uStack_40f4 = puVar23[uStack_40dc] & 0x7fff;
          if (uStack_40f4 < uStack_40e0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101555;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101579;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101587;
            func_0x(piStack_40f0,4);
          }
          uVar14 = (ulonglong)uStack_40f4;
          do {
            uVar15 = (ulonglong)uStack_40dc;
            if (-1 < (short)puVar23[(ulonglong)(uStack_40dc - 1) + 1]) break;
            if (uStack_40dc == 1) {
              uVar15 = 1;
              uVar18 = uStack_40e0;
            }
            else {
              uVar18 = *(ushort *)
                        ((longlong)piStack_40f0 +
                        uVar15 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) & 0x7fff;
            }
            if ((uVar18 < uStack_40e0) ||
               ((*(ushort *)((longlong)piStack_40f0 + uVar15 * 2 + ((ulonglong)uStack_40e8 >> 0x20))
                & 0x7fff) < uVar18)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1015e9;
              func_0x(piStack_40f0,7);
              uVar14 = (ulonglong)uStack_40f4;
            }
            if ((uVar18 < uStack_40e0) || ((uint)uVar14 < uVar18)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar18 + (longlong)piStack_40f0) == 5) {
              uStack_40f6 = uStack_40f6 | 2;
              uStack_40dc = uStack_40dc - 1;
              uStack_40ce = (undefined2)uVar18;
              uVar5 = *(ushort *)((longlong)piStack_40f0 + (ulonglong)(uVar18 & 0xffff) + 2);
              if ((uVar5 & 0x4000) == 0) {
                uStack_40cc = uStack_40cc & 0xc7ff;
              }
              else {
                uStack_40cc = uStack_40cc ^ (uVar5 ^ uStack_40cc) & 0x3800;
              }
              uStack_40cc = (uStack_40cc ^
                            *(ushort *)((longlong)piStack_40f0 + (ulonglong)(uVar18 & 0xffff) + 2))
                            & 0x7ff ^ uStack_40cc;
              break;
            }
            if (*(ushort *)((ulonglong)uVar18 + (longlong)piStack_40f0) < 0x400) break;
            uStack_40f6 = uStack_40f6 | 1;
            uStack_40dc = uStack_40dc - 1;
          } while (uStack_40dc != 0);
        }
        if ((*(byte *)piStack_40f0 & 0x40) == 0) {
          uStack_40d2 = 0;
          uStack_40d0 = 0;
        }
        else {
          uStack_40d2 = (undefined2)uVar14;
          uStack_40d0 = (undefined2)(uVar14 >> 0x10);
          uStack_40f4 = (int)uVar14 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1016c2;
          puVar12 = (ulonglong *)func_0x(&uStack_40f6);
          uVar14 = *puVar12;
          uVar17 = (ushort)(uVar14 >> 0x30);
          uVar5 = uVar17;
          if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
            uVar5 = uVar17 & 0xdfff;
            if ((uVar14 & 0x4000000000000000) != 0) {
              uVar5 = uVar17 | 0x2000;
            }
          }
          iVar7 = iVar8;
          if (uVar5 == 0xfffc) {
            iVar7 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
          }
          uStack_40f4 = uStack_40f4 + iVar7;
          uVar14 = (ulonglong)uStack_40f4;
        }
        uVar18 = (uint)uVar14;
        if ((pbStack_40da != (byte *)0x0) &&
           (pbStack_40da < (byte *)(uVar14 + (longlong)piStack_40f0))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar10 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar10 != 0 && (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0))
              && (*(char *)(lVar10 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1017b9;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1017dd;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x877);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1017eb;
          func_0x(piStack_40f0,0x12);
          uVar18 = uStack_40f4;
        }
        if (0x3f3b < uVar18 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar10 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar10 != 0 &&
              ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
               (*(char *)(lVar10 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101876;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10189a;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x87c);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1018a5;
          func_0x(piStack_40f0,5);
        }
      }
LAB_:
      sVar26 = -*(short *)((longlong)&iStackX_10 + lVar9);
      if ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) != 0) {
        if ((*(byte *)piStack_40f0 & 0x10) == 0) {
          if ((1 << (*(byte *)piStack_40f0 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar1 = *(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
            piVar22 = puVar1 + 1;
            *(undefined4 *)((longlong)aiStackX_8 + lVar9) = *puVar1;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40e8 <= *(int *)((longlong)&iStackX_10 + lVar9)) ||
                (*(ushort *)((longlong)piStack_40f0 + ((ulonglong)uStack_40e8 & 0xffffffff)) <
                 *(ushort *)((longlong)&uStackX_14 + lVar9))) goto LAB_;
      }
      if ((uint)uStack_40dc < (uint)(int)sVar26) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = piStack_40f0;
      }
      else {
        uVar18 = uStack_40e0;
        if (sVar26 != 1) {
          uVar18 = *(ushort *)
                    ((longlong)piStack_40f0 +
                    (longlong)sVar26 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) & 0x7fff;
        }
        uVar19 = *(ushort *)
                  ((longlong)piStack_40f0 + (longlong)sVar26 * 2 + ((ulonglong)uStack_40e8 >> 0x20))
                 & 0x7fff;
        if ((uVar18 < uStack_40e0) || (uVar19 < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101955;
          func_0x(piStack_40f0,7);
        }
        *(uint *)((longlong)aiStackX_8 + lVar9) = uVar19 - uVar18;
        piVar22 = (int *)((ulonglong)uVar18 + (longlong)piStack_40f0);
      }
    }
    else {
      if ((int)(uint)uStack_40e8 < -4) {
        bVar4 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piStack_40f0) < 5) {
        bVar4 = 0xff;
      }
      else {
        bVar4 = *(byte *)(((ulonglong)uStack_40e8 & 0xffffffff) + 2 + (longlong)piStack_40f0) >> 4;
        iVar7 = 1;
      }
LAB_:
      if ((bVar4 & 1) == 0) {
        if ((iVar7 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
        piVar22 = (int *)0x4;
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = piVar25;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x00000028 + lVar9) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x00000028 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1019a3;
    piVar22 = (int *)func_0x(&uStack_40f6,(longlong)&iStackX_10 + lVar9,uVar5,
                                     (longlong)aiStackX_8 + lVar9);
    plVar13 = uStack_40e8;
    if ((((sStack_40f8 != 0) && (uStack_40e8 != (longlong *)0x0)) && (*uStack_40e8 != 0)) &&
       (((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 8) == 0 &&
        ((*(uint *)(&stack0x00000028 + lVar9) & 1) == 0)))) {
      if ((piVar22 == (int *)0x0) || (piVar22 == (int *)0x114d954)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&uStackX_20 + lVar9 + -0x20) = *(uint *)(&stack0x00000028 + lVar9);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar9) = (longlong)aiStackX_8 + lVar9;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101a06;
        piVar22 = (int *)func_0x
                                   (plVar13,(longlong)&iStackX_10 + lVar9,piVar22,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar9));
      }
    }
  }
LAB_:
  if ((piVar22 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar9) != 4)) {
    lVar10 = *param_2;
    uVar11 = *(undefined8 *)(&stack0x00000040 + lVar9);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101a3c;
    func_0x(uVar11,0x17,lVar10,0x13ec230);
  }
  else {
    uVar11 = *(undefined8 *)(&stack0x00000040 + lVar9);
  }
  *(int *)((longlong)param_2 + 0xc) = *piVar22;
  *(undefined4 *)((longlong)&iStackX_10 + lVar9) = 0xfffffffa;
  *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 6;
  *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar9 + 4) = 0;
  if (sStack_40f8 == 0) {
    iVar7 = iVar8;
    if ((*(byte *)piStack_40f0 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_40f0 & 0xe) & 0x1105U) != 0) {
        bVar4 = 0xff;
        goto LAB_;
      }
LAB_:
      piVar22 = piStack_40f0;
      uVar18 = uStack_40e0;
      if (uStack_40f4 == 0) {
        uStack_40f6 = 0;
        uVar14 = (ulonglong)uStack_40e8 & 0xffffffff;
        uVar18 = (uint)uStack_40e8;
        if ((*(byte *)piStack_40f0 & 0x10) != 0) {
          uVar18 = (uint)uStack_40e8 + 2 + (*(ushort *)(uVar14 + (longlong)piStack_40f0) + 7 >> 3);
          uVar14 = (ulonglong)uVar18;
        }
        uStack_40e8 = (longlong *)CONCAT44(uVar18,(uint)uStack_40e8);
        uVar18 = (uint)uVar14;
        if ((*(byte *)piStack_40f0 & 0x20) == 0) {
          uStack_40dc = 0;
          uStack_40f4 = uVar18;
          uStack_40e0 = uVar18;
        }
        else {
          puVar23 = (ushort *)(uVar14 + (longlong)piStack_40f0);
          uStack_40dc = *puVar23;
          if (uStack_40dc == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101bda;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101bfe;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101c0f;
            func_0x(piStack_40f0,3);
          }
          uStack_40e0 = uStack_40e8._4_4_ + (uStack_40dc + 1) * 2;
          if (0x1f9e < uStack_40e0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101cad;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101cd1;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101ce2;
            func_0x(piStack_40f0,4);
          }
          uStack_40f4 = puVar23[uStack_40dc] & 0x7fff;
          if (uStack_40f4 < uStack_40e0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101d7e;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101da2;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101db3;
            func_0x(piStack_40f0,4);
          }
          uVar14 = (ulonglong)uStack_40f4;
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
          do {
            uVar15 = (ulonglong)uStack_40dc;
            if (-1 < (short)puVar23[(ulonglong)(uStack_40dc - 1) + 1]) break;
            if (uStack_40dc == 1) {
              uVar15 = 1;
              uVar19 = uVar18;
            }
            else {
              uVar19 = *(ushort *)
                        ((longlong)piVar22 + uVar15 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar19 < uVar18) ||
               ((*(ushort *)((longlong)piVar22 + uVar15 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) &
                0x7fff) < uVar19)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101e27;
              func_0x(piVar22,7);
              uVar14 = (ulonglong)uStack_40f4;
              piVar22 = piStack_40f0;
              uVar18 = uStack_40e0;
            }
            if ((uVar19 < uVar18) || ((uint)uVar14 < uVar19)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar22) == 5) {
              uStack_40f6 = uStack_40f6 | 2;
              uStack_40dc = uStack_40dc - 1;
              uStack_40ce = (undefined2)uVar19;
              uVar5 = *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar22);
              if ((uVar5 & 0x4000) == 0) {
                uStack_40cc = uStack_40cc & 0xc7ff;
              }
              else {
                uStack_40cc = uStack_40cc ^ (uVar5 ^ uStack_40cc) & 0x3800;
              }
              uStack_40cc = (uStack_40cc ^
                            *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar22)) &
                            0x7ff ^ uStack_40cc;
              break;
            }
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar22) < 0x400) break;
            uStack_40f6 = uStack_40f6 | 1;
            uStack_40dc = uStack_40dc - 1;
          } while (uStack_40dc != 0);
        }
        if ((*(byte *)piVar22 & 0x40) == 0) {
          uStack_40d2 = 0;
          uStack_40d0 = 0;
        }
        else {
          uStack_40d2 = (undefined2)uVar14;
          uStack_40d0 = (undefined2)(uVar14 >> 0x10);
          uStack_40f4 = (int)uVar14 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101ef5;
          puVar12 = (ulonglong *)func_0x(&uStack_40f6);
          uVar14 = *puVar12;
          uVar17 = (ushort)(uVar14 >> 0x30);
          uVar5 = uVar17;
          if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
            uVar5 = uVar17 & 0xdfff;
            if ((uVar14 & 0x4000000000000000) != 0) {
              uVar5 = uVar17 | 0x2000;
            }
          }
          iVar7 = iVar8;
          if (uVar5 == 0xfffc) {
            iVar7 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
          }
          uStack_40f4 = uStack_40f4 + iVar7;
          uVar14 = (ulonglong)uStack_40f4;
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
        }
        uVar19 = (uint)uVar14;
        if ((pbStack_40da != (byte *)0x0) && (pbStack_40da < (byte *)(uVar14 + (longlong)piVar22)))
        {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar10 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), piVar22 = piStack_40f0, lVar10 != 0 &&
               (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101ff3;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
              piVar22 = piStack_40f0;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102017;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x877);
              piVar22 = piStack_40f0;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102028;
          func_0x(piVar22,0x12);
          piVar22 = piStack_40f0;
          uVar19 = uStack_40f4;
          uVar18 = uStack_40e0;
        }
        if (0x3f3b < uVar19 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar10 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), piVar22 = piStack_40f0, lVar10 != 0 &&
              ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
               (*(char *)(lVar10 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1020bb;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              piVar22 = piStack_40f0;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1020df;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x87c);
              piVar22 = piStack_40f0;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1020f0;
          func_0x(piVar22,5);
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
        }
      }
LAB_:
      sVar26 = -*(short *)((longlong)&iStackX_10 + lVar9);
      if ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar22 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar22 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar1 = *(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
            piVar22 = puVar1 + 1;
            *(undefined4 *)((longlong)aiStackX_8 + lVar9) = *puVar1;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40e8 <= *(int *)((longlong)&iStackX_10 + lVar9)) ||
                (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piVar22) <
                 *(ushort *)((longlong)&uStackX_14 + lVar9))) goto LAB_;
      }
      if ((uint)uStack_40dc < (uint)(int)sVar26) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
      }
      else {
        piVar24 = piVar22;
        uVar19 = uVar18;
        if (sVar26 != 1) {
          uVar18 = *(ushort *)
                    ((longlong)piVar22 +
                    (longlong)sVar26 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) & 0x7fff;
          piVar24 = piStack_40f0;
          uVar19 = uStack_40e0;
        }
        uVar20 = *(ushort *)
                  ((longlong)piVar22 + (longlong)sVar26 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) &
                 0x7fff;
        if ((uVar18 < uVar19) || (uVar20 < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1021a8;
          func_0x(piVar24,7);
          piVar24 = piStack_40f0;
        }
        piVar22 = (int *)((ulonglong)uVar18 + (longlong)piVar24);
        *(uint *)((longlong)aiStackX_8 + lVar9) = uVar20 - uVar18;
      }
    }
    else {
      if ((int)(uint)uStack_40e8 < -5) {
        bVar4 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piStack_40f0) < 6) {
        bVar4 = 0xff;
      }
      else {
        bVar4 = *(byte *)(((ulonglong)uStack_40e8 & 0xffffffff) + 2 + (longlong)piStack_40f0) >> 5;
        iVar7 = 1;
      }
LAB_:
      if ((bVar4 & 1) == 0) {
        if ((iVar7 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) == 0))
        goto LAB_;
        piVar22 = (int *)0x4;
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = piVar25;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x0000002c + lVar9) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x0000002c + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1021f8;
    piVar22 = (int *)func_0x(&uStack_40f6,(longlong)&iStackX_10 + lVar9);
    plVar13 = uStack_40e8;
    if ((((sStack_40f8 != 0) && (uStack_40e8 != (longlong *)0x0)) && (*uStack_40e8 != 0)) &&
       (((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 8) == 0 &&
        ((*(uint *)(&stack0x0000002c + lVar9) & 1) == 0)))) {
      if ((piVar22 == (int *)0x0) || (piVar22 == (int *)0x114d954)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&uStackX_20 + lVar9 + -0x20) = *(uint *)(&stack0x0000002c + lVar9);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar9) = (longlong)aiStackX_8 + lVar9;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10225b;
        piVar22 = (int *)func_0x
                                   (plVar13,(longlong)&iStackX_10 + lVar9,piVar22,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar9));
      }
    }
  }
LAB_:
  if ((piVar22 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar9) != 4)) {
    lVar10 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10228c;
    func_0x(uVar11,0x18,lVar10,0x13ec1a8);
  }
  *(int *)(param_2 + 2) = *piVar22;
  *(undefined4 *)((longlong)&iStackX_10 + lVar9) = 0xfffffff9;
  *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 7;
  *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar9 + 4) = 0;
  if (sStack_40f8 == 0) {
    if ((*(byte *)piStack_40f0 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_40f0 & 0xe) & 0x1105U) != 0) {
        bVar4 = 0xff;
        goto LAB_;
      }
LAB_:
      piVar22 = piStack_40f0;
      uVar18 = uStack_40e0;
      if (uStack_40f4 == 0) {
        uStack_40f6 = 0;
        uVar14 = (ulonglong)uStack_40e8 & 0xffffffff;
        uVar18 = (uint)uStack_40e8;
        if ((*(byte *)piStack_40f0 & 0x10) != 0) {
          uVar18 = (uint)uStack_40e8 + 2 + (*(ushort *)(uVar14 + (longlong)piStack_40f0) + 7 >> 3);
          uVar14 = (ulonglong)uVar18;
        }
        uStack_40e8 = (longlong *)CONCAT44(uVar18,(uint)uStack_40e8);
        uVar18 = (uint)uVar14;
        if ((*(byte *)piStack_40f0 & 0x20) == 0) {
          uStack_40dc = 0;
          uStack_40f4 = uVar18;
          uStack_40e0 = uVar18;
        }
        else {
          puVar23 = (ushort *)(uVar14 + (longlong)piStack_40f0);
          uStack_40dc = *puVar23;
          if (uStack_40dc == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102424;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102448;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102459;
            func_0x(piStack_40f0,3);
          }
          uStack_40e0 = uStack_40e8._4_4_ + (uStack_40dc + 1) * 2;
          if (0x1f9e < uStack_40e0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1024f7;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10251b;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10252c;
            func_0x(piStack_40f0,4);
          }
          uStack_40f4 = puVar23[uStack_40dc] & 0x7fff;
          if (uStack_40f4 < uStack_40e0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1025c8;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1025ec;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1025fd;
            func_0x(piStack_40f0,4);
          }
          uVar14 = (ulonglong)uStack_40f4;
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
          do {
            uVar15 = (ulonglong)uStack_40dc;
            if (-1 < (short)puVar23[(ulonglong)(uStack_40dc - 1) + 1]) break;
            if (uStack_40dc == 1) {
              uVar15 = 1;
              uVar19 = uVar18;
            }
            else {
              uVar19 = *(ushort *)
                        ((longlong)piVar22 + uVar15 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar19 < uVar18) ||
               ((*(ushort *)((longlong)piVar22 + uVar15 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) &
                0x7fff) < uVar19)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102667;
              func_0x(piVar22,7);
              uVar14 = (ulonglong)uStack_40f4;
              piVar22 = piStack_40f0;
              uVar18 = uStack_40e0;
            }
            if ((uVar19 < uVar18) || ((uint)uVar14 < uVar19)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar22) == 5) {
              uStack_40f6 = uStack_40f6 | 2;
              uStack_40dc = uStack_40dc - 1;
              uStack_40ce = (undefined2)uVar19;
              uVar5 = *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar22);
              if ((uVar5 & 0x4000) == 0) {
                uStack_40cc = uStack_40cc & 0xc7ff;
              }
              else {
                uStack_40cc = uStack_40cc ^ (uStack_40cc ^ uVar5) & 0x3800;
              }
              uStack_40cc = (uStack_40cc ^
                            *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar22)) &
                            0x7ff ^ uStack_40cc;
              break;
            }
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar22) < 0x400) break;
            uStack_40f6 = uStack_40f6 | 1;
            uStack_40dc = uStack_40dc - 1;
          } while (uStack_40dc != 0);
        }
        if ((*(byte *)piVar22 & 0x40) == 0) {
          uStack_40d2 = 0;
          uStack_40d0 = 0;
        }
        else {
          uStack_40d2 = (undefined2)uVar14;
          uStack_40d0 = (undefined2)(uVar14 >> 0x10);
          uStack_40f4 = (int)uVar14 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10273e;
          puVar12 = (ulonglong *)func_0x(&uStack_40f6);
          uVar14 = *puVar12;
          uVar17 = (ushort)(uVar14 >> 0x30);
          uVar5 = uVar17;
          if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
            uVar5 = uVar17 & 0xdfff;
            if ((uVar14 & 0x4000000000000000) != 0) {
              uVar5 = uVar17 | 0x2000;
            }
          }
          iVar8 = iVar6;
          if (uVar5 == 0xfffc) {
            iVar8 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
          }
          uStack_40f4 = uStack_40f4 + iVar8;
          uVar14 = (ulonglong)uStack_40f4;
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
        }
        uVar19 = (uint)uVar14;
        if ((pbStack_40da != (byte *)0x0) && (pbStack_40da < (byte *)(uVar14 + (longlong)piVar22)))
        {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar10 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), piVar22 = piStack_40f0, lVar10 != 0 &&
               (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10283c;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
              piVar22 = piStack_40f0;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102860;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x877);
              piVar22 = piStack_40f0;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102871;
          func_0x(piVar22,0x12);
          piVar22 = piStack_40f0;
          uVar19 = uStack_40f4;
          uVar18 = uStack_40e0;
        }
        if (0x3f3b < uVar19 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar10 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), piVar22 = piStack_40f0, lVar10 != 0 &&
              ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
               (*(char *)(lVar10 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102904;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              piVar22 = piStack_40f0;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102928;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x87c);
              piVar22 = piStack_40f0;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102939;
          func_0x(piVar22,5);
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
        }
      }
LAB_:
      sVar26 = -*(short *)((longlong)&iStackX_10 + lVar9);
      if ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar22 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar22 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar1 = *(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
            piVar22 = puVar1 + 1;
            *(undefined4 *)((longlong)aiStackX_8 + lVar9) = *puVar1;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40e8 <= *(int *)((longlong)&iStackX_10 + lVar9)) ||
                (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piVar22) <
                 *(ushort *)((longlong)&uStackX_14 + lVar9))) goto LAB_;
      }
      if ((uint)uStack_40dc < (uint)(int)sVar26) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
      }
      else {
        piVar24 = piVar22;
        uVar19 = uVar18;
        if (sVar26 != 1) {
          uVar18 = *(ushort *)
                    ((longlong)piVar22 +
                    (longlong)sVar26 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) & 0x7fff;
          piVar24 = piStack_40f0;
          uVar19 = uStack_40e0;
        }
        uVar20 = *(ushort *)
                  ((longlong)piVar22 + (longlong)sVar26 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) &
                 0x7fff;
        if ((uVar18 < uVar19) || (uVar20 < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1029fb;
          func_0x(piVar24,7);
          piVar24 = piStack_40f0;
        }
        piVar22 = (int *)((ulonglong)uVar18 + (longlong)piVar24);
        *(uint *)((longlong)aiStackX_8 + lVar9) = uVar20 - uVar18;
      }
    }
    else {
      if ((int)(uint)uStack_40e8 < -6) {
        bVar4 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piStack_40f0) < 7) {
        bVar4 = 0xff;
      }
      else {
        bVar4 = *(byte *)(((ulonglong)uStack_40e8 & 0xffffffff) + 2 + (longlong)piStack_40f0) >> 6;
        iVar8 = 1;
      }
LAB_:
      if ((bVar4 & 1) == 0) {
        if ((iVar8 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) == 0))
        goto LAB_;
        piVar22 = (int *)0x4;
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = piVar25;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x00000030 + lVar9) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x00000030 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102a4b;
    piVar22 = (int *)func_0x(&uStack_40f6,(longlong)&iStackX_10 + lVar9);
    plVar13 = uStack_40e8;
    if ((((sStack_40f8 != 0) && (uStack_40e8 != (longlong *)0x0)) && (*uStack_40e8 != 0)) &&
       (((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 8) == 0 &&
        ((*(uint *)(&stack0x00000030 + lVar9) & 1) == 0)))) {
      if ((piVar22 == (int *)0x0) || (piVar22 == (int *)0x114d954)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&uStackX_20 + lVar9 + -0x20) = *(uint *)(&stack0x00000030 + lVar9);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar9) = (longlong)aiStackX_8 + lVar9;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102aae;
        piVar22 = (int *)func_0x
                                   (plVar13,(longlong)&iStackX_10 + lVar9,piVar22,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar9));
      }
    }
  }
LAB_:
  if ((piVar22 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar9) != 4)) {
    lVar10 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102adf;
    func_0x(uVar11,0x19,lVar10,0x13ec328);
  }
  *(int *)((longlong)param_2 + 0x14) = *piVar22;
  *(undefined4 *)((longlong)&iStackX_10 + lVar9) = 0xfffffff8;
  *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 8;
  *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar9 + 4) = 0;
  if (sStack_40f8 == 0) {
    iVar8 = iVar6;
    if ((*(byte *)piStack_40f0 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_40f0 & 0xe) & 0x1105U) != 0) {
        bVar4 = 1;
        goto LAB_;
      }
LAB_:
      piVar22 = piStack_40f0;
      uVar18 = uStack_40e0;
      if (uStack_40f4 == 0) {
        uStack_40f6 = 0;
        uVar14 = (ulonglong)uStack_40e8 & 0xffffffff;
        uVar18 = (uint)uStack_40e8;
        if ((*(byte *)piStack_40f0 & 0x10) != 0) {
          uVar18 = (uint)uStack_40e8 + 2 + (*(ushort *)(uVar14 + (longlong)piStack_40f0) + 7 >> 3);
          uVar14 = (ulonglong)uVar18;
        }
        uStack_40e8 = (longlong *)CONCAT44(uVar18,(uint)uStack_40e8);
        uVar18 = (uint)uVar14;
        if ((*(byte *)piStack_40f0 & 0x20) == 0) {
          uStack_40dc = 0;
          uStack_40f4 = uVar18;
          uStack_40e0 = uVar18;
        }
        else {
          puVar23 = (ushort *)(uVar14 + (longlong)piStack_40f0);
          uStack_40dc = *puVar23;
          if (uStack_40dc == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102c7c;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102ca0;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102cb1;
            func_0x(piStack_40f0,3);
          }
          uStack_40e0 = uStack_40e8._4_4_ + (uStack_40dc + 1) * 2;
          if (0x1f9e < uStack_40e0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102d4f;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102d73;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102d84;
            func_0x(piStack_40f0,4);
          }
          uStack_40f4 = puVar23[uStack_40dc] & 0x7fff;
          if (uStack_40f4 < uStack_40e0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102e20;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102e44;
                (*_DAT_)(1,0x13c8f18,0x14e8be8,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102e55;
            func_0x(piStack_40f0,4);
          }
          uVar14 = (ulonglong)uStack_40f4;
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
          do {
            uVar15 = (ulonglong)uStack_40dc;
            if (-1 < (short)puVar23[(ulonglong)(uStack_40dc - 1) + 1]) break;
            if (uStack_40dc == 1) {
              uVar15 = 1;
              uVar19 = uVar18;
            }
            else {
              uVar19 = *(ushort *)
                        ((longlong)piVar22 + uVar15 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar19 < uVar18) ||
               ((*(ushort *)((longlong)piVar22 + uVar15 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) &
                0x7fff) < uVar19)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102ec7;
              func_0x(piVar22,7);
              uVar14 = (ulonglong)uStack_40f4;
              piVar22 = piStack_40f0;
              uVar18 = uStack_40e0;
            }
            if ((uVar19 < uVar18) || ((uint)uVar14 < uVar19)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar22) == 5) {
              uStack_40f6 = uStack_40f6 | 2;
              uStack_40dc = uStack_40dc - 1;
              uStack_40ce = (undefined2)uVar19;
              uVar5 = *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar22);
              if ((uVar5 & 0x4000) == 0) {
                uStack_40cc = uStack_40cc & 0xc7ff;
              }
              else {
                uStack_40cc = uStack_40cc ^ (uStack_40cc ^ uVar5) & 0x3800;
              }
              uStack_40cc = (uStack_40cc ^
                            *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar22)) &
                            0x7ff ^ uStack_40cc;
              break;
            }
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar22) < 0x400) break;
            uStack_40f6 = uStack_40f6 | 1;
            uStack_40dc = uStack_40dc - 1;
          } while (uStack_40dc != 0);
        }
        if ((*(byte *)piVar22 & 0x40) == 0) {
          uStack_40d2 = 0;
          uStack_40d0 = 0;
        }
        else {
          uStack_40d2 = (undefined2)uVar14;
          uStack_40d0 = (undefined2)(uVar14 >> 0x10);
          uStack_40f4 = (int)uVar14 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x102f9e;
          puVar12 = (ulonglong *)func_0x(&uStack_40f6);
          uVar14 = *puVar12;
          uVar17 = (ushort)(uVar14 >> 0x30);
          uVar5 = uVar17;
          if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
            uVar5 = uVar17 & 0xdfff;
            if ((uVar14 & 0x4000000000000000) != 0) {
              uVar5 = uVar17 | 0x2000;
            }
          }
          iVar8 = iVar6;
          if (uVar5 == 0xfffc) {
            iVar8 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
          }
          uStack_40f4 = uStack_40f4 + iVar8;
          uVar14 = (ulonglong)uStack_40f4;
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
        }
        uVar19 = (uint)uVar14;
        if ((pbStack_40da != (byte *)0x0) && (pbStack_40da < (byte *)(uVar14 + (longlong)piVar22)))
        {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar10 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), piVar22 = piStack_40f0, lVar10 != 0 &&
               (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10309c;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
              piVar22 = piStack_40f0;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1030c0;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x877);
              piVar22 = piStack_40f0;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1030d1;
          func_0x(piVar22,0x12);
          piVar22 = piStack_40f0;
          uVar19 = uStack_40f4;
          uVar18 = uStack_40e0;
        }
        if (0x3f3b < uVar19 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar10 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), piVar22 = piStack_40f0, lVar10 != 0 &&
              ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
               (*(char *)(lVar10 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103164;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              piVar22 = piStack_40f0;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103188;
              (*_DAT_)(1,0x13c8f18,0x14e8be8,0x87c);
              piVar22 = piStack_40f0;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103199;
          func_0x(piVar22,5);
          piVar22 = piStack_40f0;
          uVar18 = uStack_40e0;
        }
      }
LAB_:
      sVar26 = -*(short *)((longlong)&iStackX_10 + lVar9);
      if ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar22 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar22 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar1 = *(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
            piVar22 = puVar1 + 1;
            *(undefined4 *)((longlong)aiStackX_8 + lVar9) = *puVar1;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40e8 <= *(int *)((longlong)&iStackX_10 + lVar9)) ||
                (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piVar22) <
                 *(ushort *)((longlong)&uStackX_14 + lVar9))) goto LAB_;
      }
      if ((uint)uStack_40dc < (uint)(int)sVar26) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
      }
      else {
        piVar24 = piVar22;
        uVar19 = uVar18;
        if (sVar26 != 1) {
          uVar18 = *(ushort *)
                    ((longlong)piVar22 +
                    (longlong)sVar26 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) & 0x7fff;
          piVar24 = piStack_40f0;
          uVar19 = uStack_40e0;
        }
        uVar20 = *(ushort *)
                  ((longlong)piVar22 + (longlong)sVar26 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) &
                 0x7fff;
        if ((uVar18 < uVar19) || (uVar20 < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103251;
          func_0x(piVar24,7);
          piVar24 = piStack_40f0;
        }
        piVar22 = (int *)((ulonglong)uVar18 + (longlong)piVar24);
        *(uint *)((longlong)aiStackX_8 + lVar9) = uVar20 - uVar18;
      }
    }
    else {
      if ((int)(uint)uStack_40e8 < -7) {
        bVar4 = 1;
      }
      else if (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piStack_40f0) < 8) {
        bVar4 = 1;
      }
      else {
        bVar4 = *(byte *)(((ulonglong)uStack_40e8 & 0xffffffff) + 2 + (longlong)piStack_40f0) >> 7;
        iVar8 = 1;
      }
LAB_:
      if (bVar4 == 0) {
        if ((iVar8 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) == 0))
        goto LAB_;
        piVar22 = (int *)0x4;
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar9 + 4);
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = piVar25;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x00000034 + lVar9) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x00000034 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1032a1;
    piVar22 = (int *)func_0x(&uStack_40f6,(longlong)&iStackX_10 + lVar9);
    plVar13 = uStack_40e8;
    if ((((sStack_40f8 != 0) && (uStack_40e8 != (longlong *)0x0)) && (*uStack_40e8 != 0)) &&
       (((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 8) == 0 &&
        ((*(uint *)(&stack0x00000034 + lVar9) & 1) == 0)))) {
      if ((piVar22 == (int *)0x0) || (piVar22 == (int *)0x114d954)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        piVar22 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&uStackX_20 + lVar9 + -0x20) = *(uint *)(&stack0x00000034 + lVar9);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar9) = (longlong)aiStackX_8 + lVar9;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103304;
        piVar22 = (int *)func_0x
                                   (plVar13,(longlong)&iStackX_10 + lVar9,piVar22,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar9));
      }
    }
  }
LAB_:
  if ((piVar22 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar9) != 4)) {
    lVar10 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103335;
    func_0x(uVar11,0x1a,lVar10,0x13ec2a8);
  }
  *(int *)((longlong)param_2 + 0x1c) = *piVar22;
  *(undefined4 *)((longlong)&iStackX_10 + lVar9) = 0xfffffff2;
  *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 0xe;
  *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar9 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar9 + 4) = 0;
  if (sStack_40f8 != 0) {
    *(undefined4 *)(&stack0x00000038 + lVar9) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x00000038 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103ae1;
    piVar22 = (int *)func_0x(&uStack_40f6,(longlong)&iStackX_10 + lVar9);
    plVar13 = uStack_40e8;
    if ((((sStack_40f8 != 0) && (uStack_40e8 != (longlong *)0x0)) && (*uStack_40e8 != 0)) &&
       (((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 8) == 0 &&
        ((*(uint *)(&stack0x00000038 + lVar9) & 1) == 0)))) {
      if ((piVar22 == (int *)0x0) || (piVar22 == (int *)0x114d954)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
        goto LAB_;
      }
      *(uint *)((longlong)&uStackX_20 + lVar9 + -0x20) = *(uint *)(&stack0x00000038 + lVar9);
      *(longlong *)(&stack0xfffffffffffffff8 + lVar9) = (longlong)aiStackX_8 + lVar9;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103b49;
      piVar22 = (int *)func_0x
                                 (plVar13,(longlong)&iStackX_10 + lVar9,piVar22,
                                  *(undefined4 *)((longlong)aiStackX_8 + lVar9));
    }
    iVar6 = *(int *)((longlong)aiStackX_8 + lVar9);
    piVar25 = piVar22;
    goto LAB_;
  }
  iVar8 = iVar6;
  if ((*(byte *)piStack_40f0 & 0x10) == 0) {
    if ((1 << (*(byte *)piStack_40f0 & 0xe) & 0x1105U) != 0) {
      bVar4 = 0xff;
      goto LAB_;
    }
  }
  else {
    if ((int)(uint)uStack_40e8 < -0xd) {
      bVar4 = 0xff;
    }
    else if (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piStack_40f0) < 0xe) {
      bVar4 = 0xff;
    }
    else {
      bVar4 = *(byte *)(((ulonglong)uStack_40e8 & 0xffffffff) + 3 + (longlong)piStack_40f0) >> 5;
      iVar8 = 1;
    }
LAB_:
    if ((bVar4 & 1) != 0) {
      *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
      goto LAB_;
    }
    if ((iVar8 == 0) && ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) != 0)) {
      iVar6 = **(int **)((longlong)&uStackX_14 + lVar9 + 4);
      *(int *)((longlong)aiStackX_8 + lVar9) = iVar6;
      piVar25 = (int *)0x4;
      goto LAB_;
    }
  }
  piVar25 = piStack_40f0;
  uVar18 = uStack_40e0;
  if (uStack_40f4 == 0) {
    uStack_40f6 = 0;
    uVar14 = (ulonglong)uStack_40e8 & 0xffffffff;
    uVar18 = (uint)uStack_40e8;
    if ((*(byte *)piStack_40f0 & 0x10) != 0) {
      uVar18 = (uint)uStack_40e8 + 2 + (*(ushort *)(uVar14 + (longlong)piStack_40f0) + 7 >> 3);
      uVar14 = (ulonglong)uVar18;
    }
    uStack_40e8 = (longlong *)CONCAT44(uVar18,(uint)uStack_40e8);
    if ((*(byte *)piStack_40f0 & 0x20) == 0) {
      uStack_40dc = 0;
      uVar15 = uVar14;
      uStack_40f4 = (uint)uVar14;
      uStack_40e0 = (uint)uVar14;
    }
    else {
      puVar23 = (ushort *)(uVar14 + (longlong)piStack_40f0);
      uStack_40dc = *puVar23;
      if (uStack_40dc == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar10 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar10 != 0)) &&
           ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
            (*(char *)(lVar10 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1034c9;
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1034ed;
            (*_DAT_)(1,0x13c8f18,0x14e8be8,0x80f);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1034fe;
        func_0x(piStack_40f0,3);
      }
      uStack_40e0 = uStack_40e8._4_4_ + (uStack_40dc + 1) * 2;
      if (0x1f9e < uStack_40e0) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar10 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar10 != 0 &&
            ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
             (*(char *)(lVar10 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10359c;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1035c0;
            (*_DAT_)(1,0x13c8f18,0x14e8be8,0x816);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1035d1;
        func_0x(piStack_40f0,4);
      }
      uStack_40f4 = puVar23[uStack_40dc] & 0x7fff;
      if (uStack_40f4 < uStack_40e0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar10 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar10 != 0)) &&
           ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
            (*(char *)(lVar10 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10366d;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103691;
            (*_DAT_)(1,0x13c8f18,0x14e8be8,0x81d);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1036a2;
        func_0x(piStack_40f0,4);
      }
      uVar15 = (ulonglong)uStack_40e0;
      uVar14 = (ulonglong)uStack_40f4;
      piVar25 = piStack_40f0;
      do {
        uVar16 = (ulonglong)uStack_40dc;
        if (-1 < (short)puVar23[(ulonglong)(uStack_40dc - 1) + 1]) break;
        if (uStack_40dc == 1) {
          uVar16 = 1;
          uVar19 = (uint)uVar15;
        }
        else {
          uVar19 = *(ushort *)
                    ((longlong)piVar25 + uVar16 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2)) &
                   0x7fff;
        }
        if ((uVar19 < (uint)uVar15) ||
           ((*(ushort *)((longlong)piVar25 + uVar16 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) & 0x7fff
            ) < uVar19)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103717;
          func_0x(piVar25,7);
          uVar15 = (ulonglong)uStack_40e0;
          uVar14 = (ulonglong)uStack_40f4;
          piVar25 = piStack_40f0;
        }
        uVar18 = (uint)uVar15;
        if ((uVar19 < uVar18) || ((uint)uVar14 < uVar19)) goto LAB_;
        if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar25) == 5) {
          uStack_40f6 = uStack_40f6 | 2;
          uStack_40dc = uStack_40dc - 1;
          uStack_40ce = (undefined2)uVar19;
          uVar5 = *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar25);
          if ((uVar5 & 0x4000) == 0) {
            uStack_40cc = uStack_40cc & 0xc7ff;
          }
          else {
            uStack_40cc = uStack_40cc ^ (uVar5 ^ uStack_40cc) & 0x3800;
          }
          uStack_40cc = (uStack_40cc ^
                        *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar25)) & 0x7ff ^
                        uStack_40cc;
          goto LAB_;
        }
        if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar25) < 0x400) break;
        uStack_40f6 = uStack_40f6 | 1;
        uStack_40dc = uStack_40dc - 1;
      } while (uStack_40dc != 0);
    }
    uVar18 = (uint)uVar15;
LAB_:
    if ((*(byte *)piVar25 & 0x40) == 0) {
      uStack_40d2 = 0;
      uStack_40d0 = 0;
    }
    else {
      uStack_40d2 = (undefined2)uVar14;
      uStack_40d0 = (undefined2)(uVar14 >> 0x10);
      uStack_40f4 = (int)uVar14 + 0xe;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1037e5;
      puVar12 = (ulonglong *)func_0x(&uStack_40f6);
      uVar14 = *puVar12;
      uVar17 = (ushort)(uVar14 >> 0x30);
      uVar5 = uVar17;
      if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
        uVar5 = uVar17 & 0xdfff;
        if ((uVar14 & 0x4000000000000000) != 0) {
          uVar5 = uVar17 | 0x2000;
        }
      }
      iVar8 = iVar6;
      if (uVar5 == 0xfffc) {
        iVar8 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
      }
      uStack_40f4 = uStack_40f4 + iVar8;
      uVar14 = (ulonglong)uStack_40f4;
      piVar25 = piStack_40f0;
      uVar18 = uStack_40e0;
    }
    uVar19 = (uint)uVar14;
    if ((pbStack_40da != (byte *)0x0) && (pbStack_40da < (byte *)(uVar14 + (longlong)piVar25))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar10 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
           , piVar25 = piStack_40f0, lVar10 != 0 &&
           (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
          (*(char *)(lVar10 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1038e3;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
          piVar25 = piStack_40f0;
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103907;
          (*_DAT_)(1,0x13c8f18,0x14e8be8,0x877);
          piVar25 = piStack_40f0;
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103918;
      func_0x(piVar25,0x12);
      piVar25 = piStack_40f0;
      uVar19 = uStack_40f4;
      uVar18 = uStack_40e0;
    }
    if (0x3f3b < uVar19 - 1) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar10 = *(longlong *)
                     ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8),
          piVar25 = piStack_40f0, lVar10 != 0 &&
          ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
           (*(char *)(lVar10 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1039ab;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
          piVar25 = piStack_40f0;
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1039cf;
          (*_DAT_)(1,0x13c8f18,0x14e8be8,0x87c);
          piVar25 = piStack_40f0;
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1039e0;
      func_0x(piVar25,5);
      piVar25 = piStack_40f0;
      uVar18 = uStack_40e0;
    }
  }
LAB_:
  sVar26 = -*(short *)((longlong)&iStackX_10 + lVar9);
  if ((*(byte *)((longlong)&uStackX_14 + lVar9 + 2) & 0x10) != 0) {
    if ((*(byte *)piVar25 & 0x10) == 0) {
      if ((1 << (*(byte *)piVar25 & 0xe) & 0x1105U) != 0) {
LAB_:
        piVar25 = *(int **)((longlong)&uStackX_14 + lVar9 + 4);
        iVar6 = *piVar25;
        *(int *)((longlong)aiStackX_8 + lVar9) = iVar6;
        piVar25 = piVar25 + 1;
        goto LAB_;
      }
    }
    else if (((int)(uint)uStack_40e8 <= *(int *)((longlong)&iStackX_10 + lVar9)) ||
            (*(ushort *)(((ulonglong)uStack_40e8 & 0xffffffff) + (longlong)piVar25) <
             *(ushort *)((longlong)&uStackX_14 + lVar9))) goto LAB_;
  }
  if ((uint)uStack_40dc < (uint)(int)sVar26) {
    *(undefined4 *)((longlong)aiStackX_8 + lVar9) = 0;
  }
  else {
    piVar22 = piVar25;
    uVar19 = uVar18;
    if (sVar26 != 1) {
      uVar18 = *(ushort *)
                ((longlong)piVar25 + (longlong)sVar26 * 2 + (((ulonglong)uStack_40e8 >> 0x20) - 2))
               & 0x7fff;
      piVar22 = piStack_40f0;
      uVar19 = uStack_40e0;
    }
    uVar20 = *(ushort *)
              ((longlong)piVar25 + (longlong)sVar26 * 2 + ((ulonglong)uStack_40e8 >> 0x20)) & 0x7fff
    ;
    if ((uVar18 < uVar19) || (uVar20 < uVar18)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103a96;
      func_0x(piVar22,7);
      piVar22 = piStack_40f0;
    }
    iVar6 = uVar20 - uVar18;
    *(int *)((longlong)aiStackX_8 + lVar9) = iVar6;
    piVar25 = (int *)((ulonglong)uVar18 + (longlong)piVar22);
  }
LAB_:
  if (iVar6 != 0) {
    if ((piVar25 == (int *)0x0) || (iVar6 != 4)) {
      lVar10 = *param_2;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103b76;
      func_0x(uVar11,0x1b,lVar10,0x13ed938);
    }
    *(int *)(param_2 + 3) = *piVar25;
  }
  lVar10 = lStack_4140;
  if (lStack_4140 != -1) {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103b8f;
    plVar13 = (longlong *)func_0x(lStack_4140);
    if (plVar13 == (longlong *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103bbd;
      (*_DAT_)(0x32);
    }
    else {
      pcVar2 = *(code **)(*plVar13 + 0xd0);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103ba4;
      (*pcVar2)(plVar13,lVar10);
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x103bcc;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9));
  return;
}

