
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x010ec590) */
/* WARNING: Switch with 1 destination removed at 0x0010027f */
/* WARNING: Exceeded maximum restarts with more pending */

undefined8 FUN_(longlong **param_1,longlong param_2,short *param_3,int param_4)

{
  byte bVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  uint uVar5;
  longlong lVar6;
  longlong lVar7;
  byte *pbVar8;
  uint uVar9;
  int *piVar10;
  short sVar11;
  ushort *puVar12;
  
  lVar6 = *(longlong *)(param_2 + 0x10);
  uVar2 = *(ushort *)(lVar6 + 0x28);
  piVar10 = (int *)((longlong)param_4 * 0x10 + lVar6);
  lVar7 = **param_1;
  if (param_4 == 0) {
    bVar1 = *(byte *)(lVar6 + 0x20) >> 1;
  }
  else {
    if (param_4 != 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    bVar1 = *(byte *)(lVar6 + 0x20);
  }
  if (*param_3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((bVar1 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pbVar8 = *(byte **)(param_3 + 4);
  if ((*pbVar8 & 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar5 = *(uint *)(param_3 + 8);
  if (*piVar10 < (int)uVar5) {
    if ((uint)*(ushort *)(piVar10 + 1) <= (uint)*(ushort *)(pbVar8 + uVar5)) {
      if (((bVar1 & 1) != 0) &&
         (uVar9 = *(ushort *)(piVar10 + 1) - 1,
         (pbVar8[(ulonglong)uVar5 + (ulonglong)(uVar9 >> 3) + 2] >> ((byte)uVar9 & 7) & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (-1 < *piVar10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(int *)(param_3 + 2) == 0) {
        uVar5 = *(uint *)(param_3 + 8);
        param_3[1] = 0;
        *(uint *)(param_3 + 10) = uVar5;
        bVar1 = **(byte **)(param_3 + 4);
        if ((bVar1 & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((bVar1 & 0x20) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        puVar12 = (ushort *)(*(byte **)(param_3 + 4) + uVar5);
        uVar3 = *puVar12;
        param_3[0xe] = uVar3;
        if (uVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar5 = uVar5 + (uVar3 + 1) * 2;
        *(uint *)(param_3 + 0xc) = uVar5;
        if (0x1f9e < uVar5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar4 = puVar12[uVar3];
        *(uint *)(param_3 + 2) = uVar4 & 0x7fff;
        if ((uVar4 & 0x7fff) < uVar5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((short)puVar12[(ulonglong)(uVar3 - 1) + 1] < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((**(byte **)(param_3 + 4) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined4 *)(param_3 + 0x13) = 0;
        if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
           (*(ulonglong *)(param_3 + 0xf) <
            (ulonglong)*(uint *)(param_3 + 2) + *(longlong *)(param_3 + 4))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (0x3f3b < *(uint *)(param_3 + 2) - 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
      sVar11 = -*(short *)piVar10;
      if ((*(byte *)((longlong)piVar10 + 6) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((uint)(ushort)param_3[0xe] < (uint)(int)sVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (sVar11 != 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(ushort *)
            ((ulonglong)*(uint *)(param_3 + 10) + *(longlong *)(param_3 + 4) + (longlong)sVar11 * 2)
          & 0x7fff) < *(uint *)(param_3 + 0xc)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(byte *)(lVar6 + 0x34) == 0x38) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(longlong *)(param_3 + 4) + (ulonglong)*(uint *)(param_3 + 0xc) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(longlong *)((ulonglong)(uVar2 - 1) * 0x10 + lVar7) == 0) {
        return 2;
      }
      if (*(byte *)(lVar6 + 0x34) - 0xa5 < 0x4b) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

