
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_(longlong param_1,int param_2,uint param_3,undefined8 param_4,ulonglong *param_5,
                undefined8 param_6,undefined8 param_7,int *param_8)

{
  ulonglong uVar1;
  int iVar2;
  undefined8 in_RAX;
  ulonglong *puVar3;
  undefined4 uVar4;
  ulonglong uStackX_8;
  
  uVar4 = 0xffffffff;
  if ((param_3 & 1) != 0) {
    uVar4 = 0;
  }
  uVar1 = rdtsc();
  uStackX_8 = CONCAT44((int)((ulonglong)in_RAX >> 0x20),(int)uVar1) | uVar1 & 0xffffffff00000000;
  if (param_5 != (ulonglong *)0x0) {
    *param_5 = uStackX_8;
  }
  if (((byte)*(undefined2 *)(param_1 + 0x62) >> 3 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (_DAT_ != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar3 = &uStackX_8;
  if ((*(byte *)(_DAT_ + 0x2c) & 1) == 0) {
    puVar3 = (ulonglong *)0x0;
  }
  iVar2 = func_0x(param_1 + 0x98,param_2,uVar4,param_4,0,0,puVar3,0,0);
  if (iVar2 != 0) {
    if (2 < param_2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (uStackX_8 == 0) {
      if ((*(uint *)(param_1 + 100) >> 0xb & 1) == 0) {
        if (param_8 != (int *)0x0) {
          *param_8 = param_2;
        }
        return iVar2;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

