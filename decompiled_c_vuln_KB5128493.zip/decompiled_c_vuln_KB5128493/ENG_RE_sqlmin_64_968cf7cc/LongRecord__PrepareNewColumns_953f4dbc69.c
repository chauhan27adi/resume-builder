
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,undefined8 param_3,longlong param_4)

{
  undefined *puVar1;
  int *piVar2;
  byte *pbVar3;
  uint uVar4;
  undefined4 *puVar5;
  longlong lVar6;
  longlong lVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  longlong lVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  longlong lVar15;
  ulonglong uVar16;
  longlong lVar17;
  uint uVar18;
  undefined8 uVar19;
  int *piVar20;
  int iVar21;
  ulonglong uVar23;
  undefined8 *puVar24;
  longlong unaff_GS_OFFSET;
  undefined auStackX_20 [4];
  uint uStackX_24;
  undefined8 uStack_48;
  ulonglong uVar22;
  
  uStack_48 = 0x10001b;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  puVar1 = auStackX_20 + lVar15;
  *(undefined8 *)(&stack0x00000090 + lVar15) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002190 + lVar15) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined8 *)(&stack0x00000030 + lVar15) = param_1;
  *(undefined8 *)(&stack0x00000088 + lVar15) = param_1;
  *(longlong **)(&stack0x00000028 + lVar15) = param_2;
  *(longlong *)(&stack0x00000070 + lVar15) = param_4;
  *(undefined8 *)(&stack0x00000048 + lVar15) = *(undefined8 *)(&stack0x00002210 + lVar15);
  puVar5 = *(undefined4 **)(&stack0x00002218 + lVar15);
  *(undefined4 **)(&stack0x00000040 + lVar15) = puVar5;
  *(undefined4 *)(&stack0x000020c0 + lVar15) = _DAT_;
  *(undefined4 *)(&stack0x000020c4 + lVar15) = uRam000000000244f35c;
  *(undefined4 *)(&stack0x000020c8 + lVar15) = uRam000000000244f360;
  *(undefined4 *)(&stack0x000020cc + lVar15) = uRam000000000244f364;
  uVar23 = 0;
  *(undefined4 *)(&stack0x000020d0 + lVar15) = 0;
  auStackX_20[lVar15 + 1] = 0;
  *puVar1 = 0;
  lVar17 = *param_2;
  *(longlong *)(&stack0x00000068 + lVar15) = lVar17;
  *(longlong *)(&stack0x00000050 + lVar15) = lVar17;
  *(undefined8 *)(&stack0x00000060 + lVar15) = 0;
  *(undefined8 *)(&stack0x00000058 + lVar15) = 0;
  *(undefined8 *)(&stack0x000000f0 + lVar15) = 0;
  *(undefined8 *)(&stack0x000000f8 + lVar15) = 0;
  *(undefined4 *)(&stack0x00000100 + lVar15) = 0;
  *(undefined8 *)(&stack0x00000108 + lVar15) = 0;
  *(undefined4 *)(&stack0x00000110 + lVar15) = 0;
  *puVar5 = 1;
  if (*(longlong *)(lVar17 + 0x98) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar21 = *(int *)(*(longlong *)(lVar17 + 0x80) + 0x14);
  *(int *)(&stack0x000000f0 + lVar15) = iVar21;
  *(undefined4 *)(&stack0x00000110 + lVar15) = 0x1f9e;
  *(undefined **)(&stack0x00000108 + lVar15) = &stack0x00000114 + lVar15;
  uVar18 = iVar21 << 6;
  uVar16 = (ulonglong)uVar18;
  *(uint *)(auStackX_20 + lVar15 + 4) = uVar18;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar15) = _DAT_;
  *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x10012f;
  func_0x(&stack0x000000c0 + lVar15,0,0,0);
  if (uVar16 + 0xf <= (ulonglong)uVar18) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x10014b;
  func_0x();
  lVar11 = -uVar16;
  *(undefined **)(&stack0x00000060 + lVar15) = auStackX_20 + lVar11 + lVar15;
  *(undefined8 *)((longlong)&uStack_48 + lVar11 + lVar15) = 0x100163;
  func_0x(&stack0x000000c0 + lVar15);
  lVar6 = *(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           0x100);
  if (lVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(lVar6 + 0x22c) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar6 = *(longlong *)(&stack0x00000060 + lVar15);
  if (lVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar19 = *(undefined8 *)(&stack0x00000058 + lVar15);
  *(longlong *)(&stack0x000000f8 + lVar15) = lVar6;
  *(undefined8 *)((longlong)&uStack_48 + lVar11 + lVar15) = 0x1001cb;
  func_0x(lVar6,0,uVar18);
  lVar6 = *(longlong *)(&stack0x00000030 + lVar15);
  lVar7 = *(longlong *)(lVar6 + 8);
  *(undefined **)(&stack0xffffffffffffffe8 + lVar11 + lVar15) = auStackX_20 + lVar15 + 4;
  *(undefined **)(&stack0xffffffffffffffe0 + lVar11 + lVar15) = &stack0x000000f0 + lVar15;
  uVar8 = *(undefined8 *)(lVar7 + 0x10);
  uVar9 = *(undefined8 *)(lVar7 + 8);
  uVar10 = *(undefined8 *)(lVar6 + 0x18);
  *(undefined8 *)((longlong)&uStack_48 + lVar11 + lVar15) = 0x1001fe;
  func_0x(param_2,uVar10,uVar9,uVar8);
  if (*(int *)(auStackX_20 + lVar15 + 4) == *(int *)(*(longlong *)(lVar17 + 0x80) + 0x14)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined4 *)(auStackX_20 + lVar15 + 4) = 0;
  *(undefined4 *)(&stack0x00000028 + lVar15) = 0;
  piVar20 = *(int **)(*(longlong *)(lVar17 + 0x80) + 0x18);
  uVar16 = uVar23;
  uVar22 = uVar23;
  if (*(int *)(*(longlong *)(lVar17 + 0x80) + 0x14) != 0) {
    do {
      iVar21 = (int)uVar22;
      if (*piVar20 < 1) {
        uVar18 = piVar20[0x10];
        lVar17 = *(longlong *)(piVar20 + 0x12);
        if ((uVar18 & 0x400) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((*(byte *)(lVar17 + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(int *)(lVar17 + 0x10) == 10) {
          if (*(char *)(param_2[3] + *(longlong *)(piVar20 + 0xc)) == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((uVar18 >> 0xd & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((uVar18 >> 0xf & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((uVar18 >> 8 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(byte *)(lVar17 + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar4 = *(uint *)(param_2[3] + *(longlong *)(lVar17 + 0x18));
          if ((uVar18 & 0x48000) == 0x48000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(byte *)(lVar17 + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          puVar24 = (undefined8 *)(*(longlong *)(piVar20 + 10) + param_2[3]);
          if ((uVar18 >> 0xb & 1) != 0) {
            puVar24 = (undefined8 *)*puVar24;
          }
          if (*(ushort *)(piVar20 + 0xf) < uVar4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          lVar17 = (ulonglong)*(uint *)(param_4 + 4) * 0x40;
          iVar21 = piVar20[1];
          iVar12 = piVar20[2];
          iVar13 = piVar20[3];
          piVar2 = (int *)(lVar17 + 8 + *(longlong *)(param_4 + 8));
          *piVar2 = *piVar20;
          piVar2[1] = iVar21;
          piVar2[2] = iVar12;
          piVar2[3] = iVar13;
          iVar21 = *(int *)(&stack0x00000028 + lVar15);
          *(int *)(lVar17 + *(longlong *)(param_4 + 8)) = iVar21;
          pbVar3 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_4 + 8));
          *pbVar3 = *pbVar3 & 0xfe;
          pbVar3 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_4 + 8));
          *pbVar3 = *pbVar3 & 0xfb;
          pbVar3 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_4 + 8));
          *pbVar3 = *pbVar3 | 2;
          lVar17 = lVar17 + *(longlong *)(param_4 + 8);
          *(undefined8 **)(lVar17 + 0x20) = puVar24;
          *(uint *)(lVar17 + 0x28) = uVar4;
          *(uint *)(lVar17 + 0x2c) = *(uint *)(lVar17 + 0x2c) & 0xfffffffa;
          iVar12 = piVar20[1];
          iVar13 = piVar20[2];
          iVar14 = piVar20[3];
          *(int *)(lVar17 + 0x30) = *piVar20;
          *(int *)(lVar17 + 0x34) = iVar12;
          *(int *)(lVar17 + 0x38) = iVar13;
          *(int *)(lVar17 + 0x3c) = iVar14;
          *(uint *)(lVar17 + 0x2c) = *(uint *)(lVar17 + 0x2c) & 0xfffffff5;
          *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 1;
        }
        else {
          if (*(char *)(param_2[3] + *(longlong *)(piVar20 + 0xc)) != '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (((*(ushort *)(lVar17 + 0xc) & 0x400) == 0) && ((uVar18 >> 0xe & 1) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (4 < *(int *)(lVar17 + 0x10) - 2U) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(int *)(&stack0x00002200 + lVar15) != 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          lVar17 = (ulonglong)*(uint *)(param_4 + 4) * 0x40;
          iVar12 = piVar20[1];
          iVar13 = piVar20[2];
          iVar14 = piVar20[3];
          piVar2 = (int *)(lVar17 + 8 + *(longlong *)(param_4 + 8));
          *piVar2 = *piVar20;
          piVar2[1] = iVar12;
          piVar2[2] = iVar13;
          piVar2[3] = iVar14;
          *(int *)(lVar17 + *(longlong *)(param_4 + 8)) = iVar21;
          pbVar3 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_4 + 8));
          *pbVar3 = *pbVar3 | 1;
          pbVar3 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_4 + 8));
          *pbVar3 = *pbVar3 & 0xfb;
          pbVar3 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_4 + 8));
          *pbVar3 = *pbVar3 & 0xfd;
          lVar17 = lVar17 + *(longlong *)(param_4 + 8);
          *(undefined8 *)(lVar17 + 0x20) = 0;
          *(undefined4 *)(lVar17 + 0x28) = 0;
          *(uint *)(lVar17 + 0x2c) = *(uint *)(lVar17 + 0x2c) & 0xfffffffa;
          iVar12 = piVar20[1];
          iVar13 = piVar20[2];
          iVar14 = piVar20[3];
          *(int *)(lVar17 + 0x30) = *piVar20;
          *(int *)(lVar17 + 0x34) = iVar12;
          *(int *)(lVar17 + 0x38) = iVar13;
          *(int *)(lVar17 + 0x3c) = iVar14;
          *(uint *)(lVar17 + 0x2c) = *(uint *)(lVar17 + 0x2c) & 0xfffffff5;
          *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 1;
          if (*(int *)(*(longlong *)(piVar20 + 0x12) + 0x10) == 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(int *)(*(longlong *)(piVar20 + 0x12) + 0x10) == 2) &&
             (*(int *)(&stack0x000000f4 + lVar15) != 0)) {
            *(int *)(auStackX_20 + lVar15 + 4) = (int)uVar16 + 1;
          }
        }
      }
      uVar18 = iVar21 + 1;
      *(uint *)(&stack0x00000028 + lVar15) = uVar18;
      piVar20 = piVar20 + 0x14;
      uVar16 = (ulonglong)*(uint *)(auStackX_20 + lVar15 + 4);
      uVar22 = (ulonglong)uVar18;
    } while (uVar18 < *(uint *)(*(longlong *)(*(longlong *)(&stack0x00000068 + lVar15) + 0x80) +
                               0x14));
    uVar19 = *(undefined8 *)(&stack0x00000058 + lVar15);
  }
  if ((*(longlong *)(&stack0x000000f8 + lVar15) != 0) && (*(uint *)(&stack0x000000f0 + lVar15) != 0)
     ) {
    do {
      if ((*(byte *)(uVar23 * 0x40 + 0x18 + *(longlong *)(&stack0x000000f8 + lVar15)) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar18 = (int)uVar23 + 1;
      uVar23 = (ulonglong)uVar18;
    } while (uVar18 < *(uint *)(&stack0x000000f0 + lVar15));
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar11 + lVar15) = 0x1002c3;
  (*_DAT_)(uVar19);
  uVar23 = *(ulonglong *)(&stack0x00002190 + lVar15);
  *(undefined8 *)((longlong)&uStack_48 + lVar11 + lVar15) = 0x1002d2;
  func_0x(uVar23 ^ (ulonglong)puVar1);
  return;
}

