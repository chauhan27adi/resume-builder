
/* WARNING: Control flow encountered bad instruction data */

bool FUN_(longlong param_1,longlong param_2,ulonglong param_3,ushort param_4,int param_5,
                 longlong param_6)

{
  int *piVar1;
  longlong *plVar2;
  byte bVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  bool bVar7;
  bool bVar8;
  
  bVar3 = *(byte *)(param_1 + 0x4cc);
  lVar4 = *(longlong *)(param_1 + 0x4c0);
  lVar6 = param_1 + 0x500 + (ulonglong)param_4 * 0xc0;
  bVar7 = *(ulonglong *)(lVar6 + 0x58) < *(ulonglong *)(lVar6 + 0x60);
  if (bVar7) {
    piVar1 = (int *)(lVar6 + 0x68);
    LOCK();
    param_5 = *piVar1;
    *piVar1 = 1;
    UNLOCK();
    if (param_5 == 0) {
      bVar7 = *(ulonglong *)(lVar6 + 0x58) < *(ulonglong *)(lVar6 + 0x60);
      if (bVar7) {
        if (param_6 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        lVar5 = func_0x(param_1 + 0x440,param_4,param_4,0,0);
        if (lVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined4 *)(lVar5 + 0x30) = 0;
        plVar2 = (longlong *)(((param_3 & 0xffffffff) << (bVar3 & 0x3f)) + lVar4 + 8);
        LOCK();
        bVar8 = param_2 == *plVar2;
        if (bVar8) {
          *plVar2 = lVar5;
        }
        UNLOCK();
        if (!bVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        func_0x(param_1,param_2);
        *(longlong *)(lVar6 + 0x58) = *(longlong *)(lVar6 + 0x58) + 1;
        *(undefined8 *)(lVar6 + 0x78) = 0;
      }
      *piVar1 = 0;
    }
  }
  if (bVar7 == false) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_5 != 0) && (*(longlong *)(lVar6 + 0x78) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return bVar7;
}

