
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,longlong param_4)

{
  ushort *puVar1;
  short *psVar2;
  undefined8 *puVar3;
  short *psVar4;
  undefined *puVar5;
  longlong *plVar6;
  bool bVar7;
  char cVar8;
  byte bVar9;
  short sVar10;
  undefined2 uVar11;
  uint uVar12;
  undefined4 uVar13;
  int iVar14;
  int iVar15;
  undefined4 uVar16;
  longlong lVar17;
  longlong lVar18;
  longlong lVar19;
  longlong lVar20;
  undefined4 *puVar21;
  undefined *puVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  ulonglong *puVar25;
  undefined uVar26;
  ushort uVar27;
  uint uVar28;
  ulonglong uVar29;
  undefined8 uVar30;
  code *UNRECOVERED_JUMPTABLE;
  ushort uVar31;
  uint uVar32;
  longlong *plVar33;
  ulonglong uVar34;
  uint uVar35;
  undefined8 unaff_RBX;
  ulonglong uVar36;
  ulonglong uVar37;
  uint *puVar38;
  undefined *puVar39;
  undefined *puVar40;
  longlong lVar41;
  int iVar42;
  uint uVar43;
  byte *pbVar44;
  ushort *puVar45;
  uint *puVar46;
  short *psVar47;
  uint *puVar48;
  uint uVar49;
  ulonglong uVar50;
  uint *puVar51;
  int *piVar52;
  uint *puVar53;
  undefined2 *puVar54;
  char *pcVar55;
  uint **ppuVar56;
  longlong unaff_GS_OFFSET;
  short sStackX_18;
  ushort uStackX_1a;
  uint uStackX_1c;
  uint *puStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar17 = func_0x();
  lVar17 = -lVar17;
  puVar39 = &stack0xffffffffffffffc8 + lVar17;
  psVar4 = (short *)((longlong)&sStackX_18 + lVar17);
  *(undefined8 *)(&stack0x000057c0 + lVar17) = unaff_RBX;
  *(ulonglong *)(&stack0x00005768 + lVar17) = _DAT_ ^ (ulonglong)psVar4;
  lVar20 = *(longlong *)(param_1 + 0x188);
  *(uint *)(&stack0x000001ac + lVar17) = *(uint *)(&stack0x000001ac + lVar17) & 0xfffffff8;
  *(undefined8 *)(&stack0x000001e0 + lVar17) = *(undefined8 *)(&stack0x000057d8 + lVar17);
  *psVar4 = -1;
  lVar41 = *(longlong *)(param_1 + 0x178);
  *(longlong *)(&stack0x00000068 + lVar17) = param_1;
  *(undefined8 *)((longlong)&puStackX_20 + lVar17) = 0;
  *(undefined4 *)((longlong)&sStackX_18 + lVar17 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar17) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar17) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar17) = 0;
  *(undefined4 *)(&stack0x000000fc + lVar17) = 0;
  *(undefined8 *)(&stack0x00000110 + lVar17) = 0;
  *(undefined4 *)(&stack0x00000118 + lVar17) = 0;
  *(undefined8 *)(&stack0x000001f0 + lVar17) = 0x82e5b0;
  *(undefined8 *)(&stack0x00000208 + lVar17) = 0;
  *(undefined8 *)(&stack0x000001b0 + lVar17) = 0;
  *(longlong *)(&stack0x00000078 + lVar17) = lVar20;
  *(longlong *)(&stack0x00000168 + lVar17) = lVar41;
  *(undefined (*) [16])(&stack0x000001f8 + lVar17) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000148 + lVar17) = *(undefined8 *)(lVar41 + 0xd0);
  puVar40 = &stack0xffffffffffffffc8 + lVar17;
  if (param_3 != (longlong *)0x0) {
    puVar3 = (undefined8 *)(param_1 + 0x180);
    if ((*(int *)(param_1 + 0x1a8) == *(int *)(param_3 + 1)) &&
       (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x194) * 0x10000)) {
      UNRECOVERED_JUMPTABLE = *(code **)*puVar3;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100119;
      sVar10 = (*UNRECOVERED_JUMPTABLE)(puVar3);
      if (*(short *)((longlong)param_3 + 0xc) != sVar10) goto LAB_;
      if (param_3[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar17) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar17);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10013b;
      func_0x(param_3);
    }
    uVar27 = *(ushort *)(param_3 + 7);
    uVar31 = *(ushort *)((longlong)param_3 + 0x62);
    uVar32 = (uint)uVar31;
    if ((uVar27 & 0x400) == 0) {
      *(longlong **)(&stack0x000000e8 + lVar17) = param_3;
      *(undefined8 *)(&stack0x00000108 + lVar17) = 0;
      *(undefined8 *)(&stack0x00000140 + lVar17) = 0;
      *(longlong *)(&stack0x000000f0 + lVar17) = param_3[0xe];
      *(uint *)(&stack0x000000f8 + lVar17) = (uint)uVar31;
      *(longlong *)(&stack0x00000100 + lVar17) = param_4;
      if (puVar3 != (undefined8 *)0x0) {
        lVar20 = **(longlong **)(*(longlong *)(param_1 + 0x188) + 0x160);
        *(undefined8 *)(&stack0x00000110 + lVar17) = *(undefined8 *)(lVar20 + 0xa8);
        *(undefined4 *)(&stack0x00000118 + lVar17) = *(undefined4 *)(lVar20 + 0xb0);
      }
      *(uint *)(&stack0x000000fc + lVar17) = *(uint *)(&stack0x000000fc + lVar17) | 0x10;
    }
    else {
      if (uVar31 == 0) {
        lVar41 = 0;
        uVar43 = 0;
        puVar39 = &stack0xffffffffffffffc8 + lVar17;
        lVar20 = lVar41;
        uVar32 = uVar43;
      }
      else {
        uVar43 = (uint)uVar31 * 8;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1001e0;
        lVar18 = func_0x();
        lVar18 = -lVar18;
        lVar20 = (longlong)&sStackX_18 + lVar18 + lVar17;
        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar17) = 0x1001fd;
        lVar19 = func_0x();
        lVar19 = -lVar19;
        puVar39 = &stack0xffffffffffffffc8 + lVar19 + lVar18 + lVar17;
        uVar31 = *(ushort *)(param_3 + 0xb);
        lVar41 = (longlong)&sStackX_18 + lVar19 + lVar18 + lVar17;
        uVar34 = (ulonglong)*(uint *)((longlong)param_3 + 0x54);
        if ((*(uint *)((longlong)param_3 + 0x54) < 0x1f9f) ||
           (uVar34 = (ulonglong)uVar31, 0x1f9d < uVar31)) {
          if ((int)uVar34 == 0) goto LAB_;
        }
        else {
          uVar34 = 0x1f9e;
        }
        *(undefined2 **)(&stack0x00000138 + lVar17) = (undefined2 *)(param_1 + 0x4f0);
        *(longlong *)(param_1 + 0x508) = *(longlong *)(param_1 + 0x500);
        *(ushort *)(param_1 + 0x4f2) = -(ushort)(*(longlong *)(param_1 + 0x500) != 0) & 8000;
        *(undefined2 *)(param_1 + 0x4f0) = 0;
        *(undefined8 *)(param_1 + 0x4f8) = 0;
        *(undefined4 *)(param_1 + 0x4f4) = 0;
        uVar29 = uVar34 + 0xf;
        if (uVar29 <= uVar34) {
          uVar29 = 0xffffffffffffff0;
        }
        uVar29 = uVar29 & 0xfffffffffffffff0;
        *(undefined8 *)((longlong)&uStack_40 + lVar19 + lVar18 + lVar17) = 0x100275;
        func_0x();
        puVar39 = &stack0xffffffffffffffc8 + -uVar29 + lVar19 + lVar18 + lVar17;
        *(ushort *)(param_1 + 0x4f6) = uVar31;
        *(ushort *)(param_1 + 0x4f4) = (short)uVar34 - uVar31;
        *(ulonglong *)(param_1 + 0x4f8) = (longlong)&sStackX_18 + -uVar29 + lVar19 + lVar18 + lVar17
        ;
        uVar32 = (uint)*(ushort *)((longlong)param_3 + 0x62);
        uVar27 = *(ushort *)(param_3 + 7);
      }
LAB_:
      *(uint *)(&stack0x000000f8 + lVar17) = uVar32 & 0xffff;
      *(longlong *)(&stack0x000000f0 + lVar17) = param_3[0xe];
      *(longlong **)(&stack0x000000e8 + lVar17) = param_3;
      *(longlong *)(&stack0x00000100 + lVar17) = param_4;
      *(undefined8 *)(&stack0x00000108 + lVar17) = 0;
      *(undefined8 *)(&stack0x00000140 + lVar17) = 0;
      if (puVar3 != (undefined8 *)0x0) {
        lVar18 = **(longlong **)(*(longlong *)(param_1 + 0x188) + 0x160);
        *(undefined8 *)(&stack0x00000110 + lVar17) = *(undefined8 *)(lVar18 + 0xa8);
        *(undefined4 *)(&stack0x00000118 + lVar17) = *(undefined4 *)(lVar18 + 0xb0);
      }
      uVar32 = *(uint *)(&stack0x000000fc + lVar17);
      *(uint *)(&stack0x000000fc + lVar17) = uVar32 | 0x10;
      if (((uVar27 & 0x400) != 0) && (param_4 != 0)) {
        *(longlong *)(&stack0x00000120 + lVar17) = lVar20;
        *(uint *)(&stack0x000000fc + lVar17) = uVar32 | 0x14;
        *(uint *)(&stack0x00000130 + lVar17) = uVar43;
        *(longlong *)(&stack0x00000128 + lVar17) = lVar41;
        *(uint *)(&stack0x00000134 + lVar17) = uVar43;
        if (lVar20 != 0) {
          *(uint *)(&stack0x000000fc + lVar17) = uVar32 | 0x16;
          *(undefined8 *)(puVar39 + -8) = 0x100377;
          func_0x(&stack0x000000e8 + lVar17);
          *(uint *)(&stack0x000000fc + lVar17) = *(uint *)(&stack0x000000fc + lVar17) | 8;
        }
      }
    }
    lVar20 = *(longlong *)(&stack0x00000078 + lVar17);
    puVar40 = puVar39;
  }
  puVar39 = (undefined *)0x0;
  *(longlong *)(&stack0x00000178 + lVar17) = param_1 + 0x2f0;
  *(undefined4 *)(&stack0x00000188 + lVar17) = 1;
  *(undefined **)(&stack0x00000180 + lVar17) = &stack0x000001f0 + lVar17;
  *(undefined4 *)(&stack0x0000018c + lVar17) = 1;
  *(longlong *)(&stack0x00000190 + lVar17) = param_1 + 0x180;
  lVar41 = *(longlong *)(param_1 + 0x188);
  lVar18 = lVar41;
  if (*(longlong *)(lVar41 + 0x478) != 0) {
    lVar18 = *(longlong *)(lVar41 + 0x478);
  }
  if ((*(short *)(lVar18 + 0x440) == 0) && (*(short *)(lVar41 + 0xce) == 0)) {
    uVar32 = *(uint *)(&stack0x000001ac + lVar17);
  }
  else {
    uVar32 = *(uint *)(&stack0x000001ac + lVar17) | 1;
    *(uint *)(&stack0x000001ac + lVar17) = uVar32;
  }
  lVar41 = *(longlong *)(&stack0x00000190 + lVar17);
  if ((0x1f7c < *(uint *)(*(longlong *)(lVar41 + 8) + 0xb0)) &&
     ((*(byte *)(*(longlong *)(lVar41 + 8) + 0x106) & 4) == 0)) {
    uVar32 = uVar32 | 2;
    *(uint *)(&stack0x000001ac + lVar17) = uVar32;
  }
  lVar18 = *(longlong *)(lVar41 + 0x20);
  uVar24 = *(undefined8 *)(param_1 + 0x228);
  uVar43 = *(uint *)(param_1 + 0x238);
  *(uint *)(&stack0x0000005c + lVar17) = uVar43;
  *(undefined4 *)(&stack0x00000198 + lVar17) = *(undefined4 *)(lVar18 + 0x664);
  *(ulonglong *)(&stack0x000001a0 + lVar17) = (ulonglong)*(uint6 *)(lVar41 + 0x14) << 0x10;
  uVar11 = *(undefined2 *)(*(longlong *)(lVar41 + 0x20) + 0x660);
  *(undefined8 *)(param_1 + 0x228) = *(undefined8 *)(param_1 + 0x230);
  *(undefined8 *)(param_1 + 0x230) = uVar24;
  lVar41 = *(longlong *)(param_1 + 0x188);
  *(undefined2 *)(&stack0x000001a8 + lVar17) = uVar11;
  *(uint *)(&stack0x000001ac + lVar17) = uVar32 | 4;
  bVar9 = *(byte *)(lVar20 + 0x106);
  iVar14 = *(int *)(lVar41 + 0x100);
  bVar7 = false;
  if ((iVar14 != 0) && (iVar14 != 3 && iVar14 != 4)) {
    bVar7 = true;
  }
  puVar5 = *(undefined **)(&stack0x000000e8 + lVar17);
  if ((puVar5[0x38] & 0x20) == 0) {
    if (bVar7) {
      puVar39 = (undefined *)0x0;
      *(undefined8 *)(&stack0x00000090 + lVar17) = 0;
      puVar22 = puVar39;
      if (((&stack0x000000fc)[lVar17] & 0x10) != 0) {
        puVar22 = puVar5;
      }
      uVar13 = *(undefined4 *)(puVar22 + 0x18);
      uVar16 = *(undefined4 *)(puVar22 + 0x14);
      uVar32 = -*(int *)(puVar22 + 0x10);
      *(uint *)(&stack0x00000080 + lVar17) = uVar32;
      *(undefined2 *)(puVar40 + 0x28) = 1;
      *(undefined4 *)(puVar40 + 0x20) = uVar13;
      if ((bVar9 & 1) == 0) {
        *(undefined8 *)(puVar40 + -8) = 0x101ee2;
        func_0x(psVar4,uVar24,uVar43,uVar16);
      }
      else {
        *(undefined8 *)(puVar40 + -8) = 0x101edb;
        func_0x();
      }
      if (uVar32 != 0) {
        *(undefined8 *)(puVar40 + -8) = 0x101f03;
        lVar20 = func_0x();
        lVar20 = -lVar20;
        puVar39 = puVar40 + lVar20 + 0x50;
        *(undefined **)(&stack0x00000090 + lVar17) = puVar39;
        *(undefined8 *)(puVar40 + lVar20 + -8) = 0x101f19;
        func_0x(puVar39,0);
        puVar40 = puVar40 + lVar20;
      }
      uVar27 = *(ushort *)(*(longlong *)(&stack0x000000e8 + lVar17) + 0x62);
      *(undefined8 *)(&stack0x00000088 + lVar17) = 0;
      if (uVar27 != 0) {
        puVar46 = (uint *)(*(longlong *)(&stack0x000000f0 + lVar17) + 0x38);
        *(ulonglong *)(&stack0x00000060 + lVar17) = (ulonglong)uVar27;
        do {
          uVar32 = puVar46[-0xe];
          puVar38 = puVar46 + -0xe;
          *(undefined8 *)(puVar40 + -8) = 0x101f6a;
          func_0x(&stack0x000000e8 + lVar17,puVar38,&stack0x00000055 + lVar17);
          if ((&stack0x00000055)[lVar17] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar46 + 4) + 0xc) & 0x400) == 0) &&
               ((puVar46[2] & 0x4000) == 0)) {
              *(undefined8 *)(puVar40 + -8) = 0x102263;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar40 + -8) = 0x102275;
            func_0x(psVar4,puVar38,0,0);
            if ((int)uVar32 < 0) {
              *(uint *)(puVar39 + (longlong)(int)~uVar32 * 0x20 + 0xc) =
                   *(uint *)(puVar39 + (longlong)(int)~uVar32 * 0x20 + 0xc) | 2;
            }
          }
          else {
            if (*(short *)(puVar46 + -0xd) != 0) {
              if (*psVar4 == 0) {
                *(undefined8 *)(puVar40 + -8) = 0x101f8e;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar40 + -8) = 0x101f95;
                func_0x((longlong)&sStackX_18 + lVar17 + 2,puVar38);
              }
            }
            *(undefined8 *)(puVar40 + -8) = 0x101fa8;
            func_0x(&stack0x000000e8 + lVar17,puVar38,&stack0x00000088 + lVar17);
            cVar8 = *(char *)(puVar46 + 2);
            if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
              lVar20 = *(longlong *)(&stack0x00000088 + lVar17);
              if ((puVar46[2] >> 8 & 1) == 0) {
                uVar32 = *puVar38;
                lVar41 = *(longlong *)((longlong)&puStackX_20 + lVar17);
                uVar11 = *(undefined2 *)(puVar46 + 1);
                *(undefined8 *)(puVar40 + -8) = 0x102181;
                func_0x((int)uVar32 + lVar41,lVar20,uVar11);
              }
              else {
                if (((puVar46[2] >> 0xf & 1) == 0) || (((&stack0x000000fc)[lVar17] & 8) == 0)) {
                  lVar41 = *(longlong *)(&stack0x00000100 + lVar17);
                  if ((*(byte *)(*(longlong *)(puVar46 + 4) + 0x2a) & 0x10) != 0) {
                    lVar41 = *(longlong *)(&stack0x00000108 + lVar17);
                  }
                  uVar32 = *(uint *)(lVar41 + *(longlong *)(*(longlong *)(puVar46 + 4) + 0x18));
                }
                else {
                  uVar32 = *(uint *)(*(longlong *)(&stack0x00000120 + lVar17) +
                                    (ulonglong)*puVar46 * 8);
                }
                uVar43 = (uint)*(ushort *)(puVar46 + 1);
                if (uVar32 < uVar43) {
                  iVar14 = uVar43 - uVar32;
                }
                else {
                  iVar14 = 0;
                  if (uVar43 < uVar32) {
                    *(undefined8 *)(puVar40 + -8) = 0x1021ee;
                    (*_DAT_)(6,0x5c,0x16);
                    iVar14 = 0;
                  }
                }
                lVar41 = (longlong)(int)*puVar38 + *(longlong *)((longlong)&puStackX_20 + lVar17);
                uVar26 = *(undefined *)(*(longlong *)(puVar46 + 4) + 0x24);
                if ((lVar20 != 0) && (uVar32 != 0)) {
                  *(undefined8 *)(puVar40 + -8) = 0x102216;
                  func_0x(lVar41,lVar20,uVar32);
                }
                if (iVar14 != 0) {
                  *(undefined8 *)(puVar40 + -8) = 0x10222f;
                  func_0x((ulonglong)uVar32 + lVar41,uVar26,iVar14);
                }
              }
            }
            else if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
              uVar43 = puVar46[2];
              piVar52 = *(int **)(&stack0x00000088 + lVar17);
              if (((uVar43 >> 0xd & 1) == 0) || (*piVar52 != 0)) {
                if (((uVar43 >> 0xf & 1) == 0) || (((&stack0x000000fc)[lVar17] & 8) == 0)) {
                  lVar20 = *(longlong *)(puVar46 + 4);
                  if ((uVar43 >> 8 & 1) == 0) {
                    uVar43 = (uint)*(ushort *)(lVar20 + 2);
                  }
                  else {
                    lVar41 = *(longlong *)(&stack0x00000100 + lVar17);
                    if ((*(byte *)(lVar20 + 0x2a) & 0x10) != 0) {
                      lVar41 = *(longlong *)(&stack0x00000108 + lVar17);
                    }
                    uVar43 = *(uint *)(lVar41 + *(longlong *)(lVar20 + 0x18));
                  }
                }
                else {
                  uVar43 = *(uint *)(*(longlong *)(&stack0x00000120 + lVar17) +
                                    (ulonglong)*puVar46 * 8);
                }
              }
              else {
                uVar43 = 0;
              }
              if (*(ushort *)(puVar46 + 1) < uVar43) {
                *(undefined8 *)(puVar40 + -8) = 0x1020cd;
                (*_DAT_)(6,0x52,0x16);
                piVar52 = *(int **)(&stack0x00000088 + lVar17);
              }
              *(undefined4 *)(puVar40 + 0x28) = 0;
              *(uint **)(puVar40 + 0x20) = puVar38;
              *(undefined8 *)(puVar40 + -8) = 0x1020f5;
              func_0x(puVar39 + (longlong)(int)~uVar32 * 0x20,piVar52,uVar43);
            }
            else if (cVar8 == '\b') {
              if (*psVar4 == 0) {
                uVar24 = *(undefined8 *)(&stack0x00000088 + lVar17);
                *(undefined8 *)(puVar40 + -8) = 0x102017;
                func_0x(psVar4,puVar38,uVar24);
              }
              else {
                uVar24 = *(undefined8 *)(&stack0x00000088 + lVar17);
                *(undefined4 *)(puVar40 + 0x28) = 0;
                *(uint **)(puVar40 + 0x20) = puVar38;
                *(undefined8 *)(puVar40 + -8) = 0x102045;
                func_0x(puVar39 + (longlong)(int)~uVar32 * 0x20,uVar24,1);
              }
            }
            else {
              *(undefined8 *)(puVar40 + 0x20) = 0x805c28;
              *(undefined8 *)(puVar40 + -8) = 0x101ff5;
              (*_DAT_)(1,0xc0aa80,0xc373c0);
            }
          }
          puVar39 = *(undefined **)(&stack0x00000090 + lVar17);
          puVar46 = puVar46 + 0x14;
          plVar6 = (longlong *)(&stack0x00000060 + lVar17);
          *plVar6 = *plVar6 + -1;
        } while (*plVar6 != 0);
        uVar32 = *(uint *)(&stack0x00000080 + lVar17);
        uVar43 = *(uint *)(&stack0x0000005c + lVar17);
      }
      puVar45 = (ushort *)0x0;
      if (uVar32 != 0) {
        lVar20 = *(longlong *)(&stack0x00000090 + lVar17);
        if (*psVar4 == 0) {
          do {
            uVar34 = (ulonglong)uVar32;
            uVar35 = uVar32 - 1;
            if (*(int *)((ulonglong)uVar35 * 0x20 + 8 + lVar20) != 0) {
              pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
              *(ushort *)(&stack0x00000034 + lVar17) = (ushort)uVar32;
              iVar14 = *(int *)(&stack0x0000002c + lVar17) + 2 + uVar32 * 2;
              *(int *)(&stack0x00000030 + lVar17) = iVar14;
              *(int *)((longlong)&sStackX_18 + lVar17 + 4) = iVar14;
              *pbVar44 = *pbVar44 | 0x20;
              uVar35 = *(uint *)((longlong)&sStackX_18 + lVar17 + 4);
              if (uVar35 < 0x1f7d) {
                puVar45 = (ushort *)
                          ((ulonglong)*(uint *)(&stack0x0000002c + lVar17) +
                          *(longlong *)((longlong)&puStackX_20 + lVar17));
                *puVar45 = (ushort)uVar32;
                uVar35 = *(uint *)((longlong)&sStackX_18 + lVar17 + 4);
              }
              if (uVar32 != 0) {
                puVar46 = (uint *)(lVar20 + 0xc);
                do {
                  puVar45 = puVar45 + 1;
                  uVar32 = puVar46[-1];
                  uVar29 = (ulonglong)uVar35;
                  uVar35 = uVar35 + uVar32;
                  lVar20 = *(longlong *)((longlong)&puStackX_20 + lVar17);
                  *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar35;
                  if ((uVar35 < 0x1f7d) && (uVar35 <= uVar43)) {
                    *puVar45 = (ushort)((*puVar46 & 1) << 0xf) | (ushort)uVar35 & 0x7fff;
                    uVar24 = *(undefined8 *)(puVar46 + -3);
                    *(undefined8 *)(puVar40 + -8) = 0x10231d;
                    func_0x(uVar29 + lVar20,uVar32,uVar24,uVar32);
                    uVar35 = *(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                  }
                  puVar46 = puVar46 + 8;
                  uVar34 = uVar34 - 1;
                } while (uVar34 != 0);
              }
              break;
            }
            uVar32 = uVar35;
          } while (uVar35 != 0);
        }
        else {
          *(undefined **)(puVar40 + 0x28) = &stack0x000001c4 + lVar17;
          *(longlong *)(puVar40 + 0x20) = lVar20;
          *(undefined8 *)(puVar40 + -8) = 0x102359;
          func_0x((longlong)&sStackX_18 + lVar17 + 2,uVar43,0x1f7c,uVar32);
        }
      }
    }
    else {
      *psVar4 = 0;
      puVar22 = puVar39;
      if (((&stack0x000000fc)[lVar17] & 0x10) != 0) {
        puVar22 = puVar5;
      }
      *(undefined8 *)(&stack0x00000160 + lVar17) = 0;
      uVar32 = -*(int *)(puVar22 + 0x10);
      *(uint *)(&stack0x00000080 + lVar17) = uVar32;
      uVar26 = 0;
      if ((bVar9 & 1) == 0) {
        uVar26 = 6;
      }
      iVar14 = *(int *)(puVar22 + 0x14);
      puVar40[0x28] = uVar26;
      iVar42 = 4;
      if ((bVar9 & 1) == 0) {
        iVar42 = 1;
      }
      *(undefined4 *)(puVar40 + 0x20) = *(undefined4 *)(puVar22 + 0x18);
      *(undefined8 *)(puVar40 + -8) = 0x100549;
      func_0x((longlong)&sStackX_18 + lVar17 + 2,uVar24,uVar43,iVar14 - iVar42);
      if (uVar32 != 0) {
        *(undefined8 *)(puVar40 + -8) = 0x100571;
        lVar20 = func_0x();
        lVar20 = -lVar20;
        puVar39 = puVar40 + lVar20 + 0x50;
        *(undefined **)(&stack0x00000160 + lVar17) = puVar39;
        *(undefined8 *)(puVar40 + lVar20 + -8) = 0x10058a;
        func_0x(puVar39,0);
        puVar40 = puVar40 + lVar20;
      }
      puVar46 = *(uint **)(&stack0x000000f0 + lVar17);
      *(undefined4 *)(&stack0x00000058 + lVar17) = 0;
      uVar27 = *(ushort *)(*(longlong *)(&stack0x000000e8 + lVar17) + 0x62);
      *(uint *)(&stack0x00000090 + lVar17) = (uint)uVar27;
      *(undefined8 *)(&stack0x000000d8 + lVar17) = 0;
      if (uVar27 != 0) {
        do {
          uVar32 = *puVar46;
          *(undefined8 *)(puVar40 + -8) = 0x1005d7;
          func_0x(&stack0x000000e8 + lVar17,puVar46,&stack0x00000054 + lVar17);
          if ((&stack0x00000054)[lVar17] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar46 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar46[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar40 + -8) = 0x101dbd;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar40 + -8) = 0x101dcf;
            func_0x((longlong)&sStackX_18 + lVar17 + 2,puVar46,0,0);
            if ((int)uVar32 < 0) {
              *(uint *)(puVar39 + (longlong)(int)~uVar32 * 0x20 + 0xc) =
                   *(uint *)(puVar39 + (longlong)(int)~uVar32 * 0x20 + 0xc) | 2;
            }
          }
          else {
            if (*(short *)(puVar46 + 1) != 0) {
              *(undefined8 *)(puVar40 + -8) = 0x1005f5;
              func_0x((longlong)&sStackX_18 + lVar17 + 2,puVar46);
            }
            *(undefined8 *)(puVar40 + -8) = 0x10060b;
            func_0x(&stack0x000000e8 + lVar17,puVar46,&stack0x000000d8 + lVar17);
            cVar8 = *(char *)(puVar46 + 0x10);
            if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
              lVar20 = *(longlong *)(&stack0x000000d8 + lVar17);
              if ((puVar46[0x10] >> 8 & 1) == 0) {
                uVar32 = *puVar46;
                lVar41 = *(longlong *)((longlong)&puStackX_20 + lVar17);
                uVar11 = *(undefined2 *)(puVar46 + 0xf);
                *(undefined8 *)(puVar40 + -8) = 0x101cdd;
                func_0x((int)uVar32 + lVar41,lVar20,uVar11);
              }
              else {
                if (((puVar46[0x10] & 0x8000) == 0) || (((&stack0x000000fc)[lVar17] & 8) == 0)) {
                  lVar41 = *(longlong *)(&stack0x00000100 + lVar17);
                  if ((*(byte *)(*(longlong *)(puVar46 + 0x12) + 0x2a) & 0x10) != 0) {
                    lVar41 = *(longlong *)(&stack0x00000108 + lVar17);
                  }
                  uVar32 = *(uint *)(lVar41 + *(longlong *)(*(longlong *)(puVar46 + 0x12) + 0x18));
                }
                else {
                  uVar32 = *(uint *)(*(longlong *)(&stack0x00000120 + lVar17) +
                                    (ulonglong)puVar46[0xe] * 8);
                }
                uVar43 = (uint)*(ushort *)(puVar46 + 0xf);
                if (uVar32 < uVar43) {
                  iVar14 = uVar43 - uVar32;
                }
                else {
                  iVar14 = 0;
                  if (uVar43 < uVar32) {
                    *(undefined8 *)(puVar40 + -8) = 0x101d48;
                    (*_DAT_)(6,0x5c,0x16);
                    iVar14 = 0;
                  }
                }
                lVar41 = (longlong)(int)*puVar46 + *(longlong *)((longlong)&puStackX_20 + lVar17);
                uVar26 = *(undefined *)(*(longlong *)(puVar46 + 0x12) + 0x24);
                if ((lVar20 != 0) && (uVar32 != 0)) {
                  *(undefined8 *)(puVar40 + -8) = 0x101d70;
                  func_0x(lVar41,lVar20,uVar32);
                }
                if (iVar14 != 0) {
                  *(undefined8 *)(puVar40 + -8) = 0x101d88;
                  func_0x((ulonglong)uVar32 + lVar41,uVar26,iVar14);
                }
              }
            }
            else if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
              uVar43 = puVar46[0x10];
              piVar52 = *(int **)(&stack0x000000d8 + lVar17);
              if (((uVar43 >> 0xd & 1) == 0) || (*piVar52 != 0)) {
                if (((uVar43 & 0x8000) == 0) || (((&stack0x000000fc)[lVar17] & 8) == 0)) {
                  lVar20 = *(longlong *)(puVar46 + 0x12);
                  if ((uVar43 >> 8 & 1) == 0) {
                    uVar43 = (uint)*(ushort *)(lVar20 + 2);
                  }
                  else {
                    lVar41 = *(longlong *)(&stack0x00000100 + lVar17);
                    if ((*(byte *)(lVar20 + 0x2a) & 0x10) != 0) {
                      lVar41 = *(longlong *)(&stack0x00000108 + lVar17);
                    }
                    uVar43 = *(uint *)(lVar41 + *(longlong *)(lVar20 + 0x18));
                  }
                }
                else {
                  uVar43 = *(uint *)(*(longlong *)(&stack0x00000120 + lVar17) +
                                    (ulonglong)puVar46[0xe] * 8);
                }
              }
              else {
                uVar43 = 0;
              }
              if (*(ushort *)(puVar46 + 0xf) < uVar43) {
                *(undefined8 *)(puVar40 + -8) = 0x101c87;
                (*_DAT_)(6,0x52,0x16);
                piVar52 = *(int **)(&stack0x000000d8 + lVar17);
              }
              *(undefined4 *)(puVar40 + 0x28) = 0;
              *(uint **)(puVar40 + 0x20) = puVar46;
              *(undefined8 *)(puVar40 + -8) = 0x101cb2;
              func_0x(puVar39 + (longlong)(int)~uVar32 * 0x20,piVar52,uVar43);
            }
            else if (cVar8 == '\b') {
              uVar32 = *puVar46;
              pcVar55 = *(char **)(&stack0x000000d8 + lVar17);
              *(char **)(&stack0x00000060 + lVar17) = pcVar55;
              if ((int)uVar32 < 0) {
                if ((uVar32 & 0xc0000000) == 0x80000000) {
                  *(undefined8 *)(puVar40 + -8) = 0x10142a;
                  func_0x(&stack0x000003c8 + lVar17);
                  *(undefined4 *)(&stack0x00000070 + lVar17) = 0;
                  if (*(int *)((longlong)&sStackX_18 + lVar17 + 4) == 0) {
                    pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                    uVar32 = *(uint *)(&stack0x00000028 + lVar17);
                    uVar34 = (ulonglong)uVar32;
                    *(undefined2 *)((longlong)&sStackX_18 + lVar17 + 2) = 0;
                    *(uint *)(&stack0x0000002c + lVar17) = uVar32;
                    if ((*pbVar44 & 0x10) != 0) {
                      uVar32 = uVar32 + 2 + (*(ushort *)(pbVar44 + uVar34) + 7 >> 3);
                      uVar34 = (ulonglong)uVar32;
                      *(uint *)(&stack0x0000002c + lVar17) = uVar32;
                    }
                    if ((*pbVar44 & 0x20) == 0) {
                      *(int *)((longlong)&sStackX_18 + lVar17 + 4) = (int)uVar34;
                      *(undefined2 *)(&stack0x00000034 + lVar17) = 0;
                      *(int *)(&stack0x00000030 + lVar17) = (int)uVar34;
                    }
                    else {
                      puVar45 = (ushort *)(pbVar44 + uVar34);
                      uVar27 = *puVar45;
                      *(ushort *)(&stack0x00000034 + lVar17) = uVar27;
                      uVar29 = uVar34;
                      if (uVar27 == 0) {
                        *(undefined8 *)(puVar40 + -8) = 0x101491;
                        cVar8 = func_0x(0x11989c0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x10149a;
                          lVar20 = func_0x();
                          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x1014b3;
                            cVar8 = func_0x(0x11989c0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x1014cf;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x1014f3;
                              (*_DAT_)(1,0xa89748,0xba9418,0x80f);
                            }
                            pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                          }
                        }
                        *(undefined8 *)(puVar40 + -8) = 0x101504;
                        func_0x(pbVar44,3);
                        uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                        uVar29 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                        pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                      }
                      uVar32 = (int)uVar29 + (uVar27 + 1) * 2;
                      *(uint *)(&stack0x00000030 + lVar17) = uVar32;
                      if (0x1f9e < uVar32) {
                        *(undefined8 *)(puVar40 + -8) = 0x101539;
                        cVar8 = func_0x(0x11989c0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x101542;
                          lVar20 = func_0x();
                          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x10155b;
                            cVar8 = func_0x(0x11989c0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x101577;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x10159b;
                              (*_DAT_)(1,0xa89748,0xba9418,0x816);
                            }
                            pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                          }
                        }
                        *(undefined8 *)(puVar40 + -8) = 0x1015ac;
                        func_0x(pbVar44,4);
                        uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                        uVar32 = *(uint *)(&stack0x00000030 + lVar17);
                        uVar29 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                        pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                      }
                      uVar36 = (ulonglong)uVar32;
                      uVar50 = (ulonglong)uVar27;
                      uVar43 = puVar45[uVar50] & 0x7fff;
                      uVar34 = (ulonglong)uVar43;
                      *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar43;
                      if (uVar43 < uVar32) {
                        *(undefined8 *)(puVar40 + -8) = 0x1015e7;
                        cVar8 = func_0x(0x11989c0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x1015f0;
                          lVar20 = func_0x();
                          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x101609;
                            cVar8 = func_0x(0x11989c0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x101625;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x101649;
                              (*_DAT_)(1,0xa89748,0xba9418,0x81d);
                            }
                            pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                          }
                        }
                        *(undefined8 *)(puVar40 + -8) = 0x10165a;
                        func_0x(pbVar44,4);
                        uVar50 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar17);
                        uVar36 = (ulonglong)*(uint *)(&stack0x00000030 + lVar17);
                        uVar29 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                        uVar34 = (ulonglong)*(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                        pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                      }
                      do {
                        if (-1 < (short)puVar45[(ulonglong)((int)uVar50 - 1) + 1]) break;
                        uVar37 = uVar36;
                        if ((((int)uVar50 != 1) &&
                            (uVar37 = (ulonglong)
                                      (*(ushort *)(pbVar44 + uVar50 * 2 + (uVar29 - 2)) & 0x7fff),
                            (*(ushort *)(pbVar44 + uVar50 * 2 + (uVar29 - 2)) & 0x7fff) <
                            (uint)uVar36)) ||
                           ((*(ushort *)(pbVar44 + uVar50 * 2 + uVar29) & 0x7fff) < (uint)uVar37)) {
                          *(undefined8 *)(puVar40 + -8) = 0x1016c2;
                          func_0x(pbVar44,7);
                          uVar50 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar17);
                          uVar36 = (ulonglong)*(uint *)(&stack0x00000030 + lVar17);
                          uVar29 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                          uVar34 = (ulonglong)*(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                          pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                        }
                        if (((uint)uVar37 < (uint)uVar36) || ((uint)uVar34 < (uint)uVar37))
                        goto LAB_;
                        if (*(ushort *)(pbVar44 + uVar37) == 5) {
                          puVar45 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                          *puVar45 = *puVar45 | 2;
                          uVar27 = *(ushort *)(&stack0x00000044 + lVar17);
                          *(short *)(&stack0x00000034 + lVar17) = (short)uVar50 + -1;
                          *(short *)(&stack0x00000042 + lVar17) = (short)uVar37;
                          if ((*(ushort *)(pbVar44 + (uVar37 & 0xffff) + 2) >> 0xe & 1) == 0) {
                            uVar27 = uVar27 & 0xc7ff;
                          }
                          else {
                            uVar27 = uVar27 ^ (*(ushort *)(pbVar44 + (uVar37 & 0xffff) + 2) ^ uVar27
                                              ) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar17) = uVar27;
                          *(ushort *)(&stack0x00000044 + lVar17) =
                               uVar27 ^ (uVar27 ^ *(ushort *)(pbVar44 + (uVar37 & 0xffff) + 2)) &
                                        0x7ff;
                          break;
                        }
                        if (*(ushort *)(pbVar44 + uVar37) < 0x400) break;
                        puVar1 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                        *puVar1 = *puVar1 | 1;
                        uVar27 = (short)uVar50 - 1;
                        uVar50 = (ulonglong)uVar27;
                        *(ushort *)(&stack0x00000034 + lVar17) = uVar27;
                      } while (uVar27 != 0);
                    }
                    if ((*pbVar44 & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar17) = 0;
                    }
                    else {
                      *(int *)(&stack0x0000003e + lVar17) = (int)uVar34;
                      *(int *)((longlong)&sStackX_18 + lVar17 + 4) = (int)uVar34 + 0xe;
                      *(undefined8 *)(puVar40 + -8) = 0x101738;
                      uVar24 = func_0x((longlong)&sStackX_18 + lVar17 + 2);
                      *(undefined8 *)(puVar40 + -8) = 0x101747;
                      func_0x(uVar24,&stack0x000001d8 + lVar17);
                      *(undefined8 *)(puVar40 + -8) = 0x101753;
                      iVar14 = func_0x(&stack0x000001d8 + lVar17);
                      pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                      uVar32 = *(int *)((longlong)&sStackX_18 + lVar17 + 4) + iVar14;
                      uVar34 = (ulonglong)uVar32;
                      *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar32;
                    }
                    if ((*(byte **)(&stack0x00000036 + lVar17) != (byte *)0x0) &&
                       (*(byte **)(&stack0x00000036 + lVar17) < pbVar44 + uVar34)) {
                      *(undefined8 *)(puVar40 + -8) = 0x101807;
                      cVar8 = func_0x(0x11989c0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x101810;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar40 + -8) = 0x10182a;
                          cVar8 = func_0x(0x11989c0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar40 + -8) = 0x101846;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar40 + 0x20) = 0;
                            *(undefined8 *)(puVar40 + -8) = 0x10186a;
                            (*_DAT_)(1,0xa89748,0xba9418,0x877);
                          }
                          pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                        }
                      }
                      *(undefined8 *)(puVar40 + -8) = 0x10187b;
                      func_0x(pbVar44,0x12);
                      uVar34 = (ulonglong)*(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                      pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                    }
                    if (0x3f3b < (int)uVar34 - 1U) {
                      *(undefined8 *)(puVar40 + -8) = 0x10189e;
                      cVar8 = func_0x(0x11989c0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x1018a7;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar40 + -8) = 0x1018c1;
                          cVar8 = func_0x(0x11989c0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar40 + -8) = 0x1018dd;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar40 + 0x20) = 0;
                            *(undefined8 *)(puVar40 + -8) = 0x101901;
                            (*_DAT_)(1,0xa89748,0xba9418,0x87c);
                          }
                          pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                        }
                      }
                      *(undefined8 *)(puVar40 + -8) = 0x101912;
                      func_0x(pbVar44,5);
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar40 + -8) = 0x10191b;
                  func_0x((longlong)&sStackX_18 + lVar17 + 2);
                  bVar9 = **(byte **)((longlong)&puStackX_20 + lVar17) >> 6;
                  if ((bVar9 & 1) != 0) {
                    *(undefined8 *)(puVar40 + -8) = 0x10193d;
                    func_0x
                              ((longlong)&sStackX_18 + lVar17 + 2,&stack0x000003c8 + lVar17);
                  }
                  if ((*(byte *)((longlong)&sStackX_18 + lVar17 + 2) & 1) != 0) {
                    *(undefined8 *)(puVar40 + -8) = 0x101955;
                    puVar21 = (undefined4 *)
                              func_0x((longlong)&sStackX_18 + lVar17 + 2,0x400,
                                              &stack0x00000070 + lVar17);
                    *(undefined4 *)(&stack0x00000158 + lVar17) = *puVar21;
                    *(undefined2 *)(&stack0x0000015c + lVar17) = *(undefined2 *)(puVar21 + 1);
                    *(undefined2 *)(&stack0x0000015e + lVar17) =
                         *(undefined2 *)((longlong)puVar21 + 6);
                  }
                  if ((**(byte **)((longlong)&puStackX_20 + lVar17) & 0x20) == 0) {
                    *(undefined8 *)(puVar40 + -8) = 0x101985;
                    func_0x((longlong)&sStackX_18 + lVar17 + 2);
                  }
                  lVar41 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17) +
                           *(longlong *)((longlong)&puStackX_20 + lVar17);
                  *(undefined8 *)(puVar40 + -8) = 0x101995;
                  iVar14 = func_0x((longlong)&sStackX_18 + lVar17 + 2);
                  lVar20 = *(longlong *)((longlong)&puStackX_20 + lVar17);
                  if (iVar14 == 0) {
                    uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                    uVar43 = (uint)uVar27;
                    puVar45 = (ushort *)(lVar20 + (ulonglong)*(uint *)(&stack0x0000002c + lVar17));
                    uVar32 = *(uint *)(&stack0x0000002c + lVar17) + 2 + uVar43 * 2;
                    uVar35 = 0;
                    if (*puVar45 != 0) {
                      do {
                        uVar12 = uVar35 & 0xffff;
                        uVar34 = (ulonglong)uVar35;
                        uVar35 = uVar35 + 1;
                        puVar45[(ulonglong)uVar12 + 1] =
                             puVar45[(ulonglong)uVar12 + 1] ^
                             (puVar45[uVar34 + 1] + 2 ^ puVar45[(ulonglong)uVar12 + 1]) & 0x7fff;
                      } while (uVar35 < *puVar45);
                      lVar20 = *(longlong *)((longlong)&puStackX_20 + lVar17);
                      pcVar55 = *(char **)(&stack0x00000060 + lVar17);
                    }
                    iVar14 = *(int *)((longlong)&sStackX_18 + lVar17 + 4);
                    *(undefined8 *)(puVar40 + -8) = 0x101a7d;
                    func_0x
                              ((ulonglong)uVar32 + 2 + lVar20,(ulonglong)uVar32 + lVar20,
                               iVar14 - uVar32);
                    iVar14 = *(int *)(&stack0x00000030 + lVar17);
                    piVar52 = (int *)((longlong)&sStackX_18 + lVar17 + 4);
                    *piVar52 = *piVar52 + 2;
                    uVar32 = iVar14 + 2;
                    *(uint *)(&stack0x00000030 + lVar17) = uVar32;
                    if (uVar27 != 0) {
                      uVar32 = puVar45[(ulonglong)(uVar43 - 1) + 1] & 0x7fff;
                    }
                    uVar35 = uVar43 + 1;
                    if (uVar43 < uVar35) {
                      do {
                        uVar12 = uVar43 & 0xffff;
                        uVar43 = uVar43 + 1;
                        puVar45[(ulonglong)uVar12 + 1] = (ushort)uVar32 & 0x7fff;
                      } while (uVar43 < uVar35);
                    }
                    *puVar45 = *puVar45 + 1;
                    *(undefined8 *)(puVar40 + -8) = 0x101aca;
                    func_0x((longlong)&sStackX_18 + lVar17 + 2);
                    iVar42 = 0;
                    uVar27 = *(ushort *)
                              (lVar41 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar17) * 2);
                    *(undefined8 *)(puVar40 + -8) = 0x101ae3;
                    func_0x(&stack0x00000220 + lVar17);
                    *(undefined4 *)(puVar40 + 0x28) = 0;
                    *(uint **)(puVar40 + 0x20) = puVar46;
                    *(undefined8 *)(puVar40 + -8) = 0x101b04;
                    func_0x(&stack0x00000210 + lVar17,pcVar55,1,0);
                    *(undefined **)(puVar40 + 0x28) = &stack0x00000150 + lVar17;
                    *(undefined **)(puVar40 + 0x20) = &stack0x00000210 + lVar17;
                    *(undefined8 *)(puVar40 + -8) = 0x101b3a;
                    func_0x(&stack0x00000042 + lVar17,uVar27 & 0x7fff,0x1f9e);
                    iVar14 = *(int *)(&stack0x00000150 + lVar17);
                  }
                  else {
                    uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                    uVar32 = *(uint *)(&stack0x00000030 + lVar17);
                    if (uVar27 != 0) {
                      uVar32 = *(ushort *)
                                ((ulonglong)*(uint *)(&stack0x0000002c + lVar17) + lVar20 +
                                (ulonglong)uVar27 * 2) & 0x7fff;
                    }
                    uVar43 = *(ushort *)
                              ((ulonglong)*(uint *)(&stack0x0000002c + lVar17) + lVar20 + 2 +
                              (ulonglong)(uint)uVar27 * 2) & 0x7fff;
                    if ((uVar32 < *(uint *)(&stack0x00000030 + lVar17)) || (uVar43 < uVar32)) {
                      *(undefined8 *)(puVar40 + -8) = 0x1019e3;
                      func_0x(lVar20,7);
                    }
                    iVar42 = uVar43 - uVar32;
                    *(undefined8 *)(puVar40 + -8) = 0x1019fa;
                    iVar14 = func_0x(&stack0x00000042 + lVar17,puVar46,pcVar55);
                  }
                  iVar42 = (*(int *)((longlong)&sStackX_18 + lVar17 + 4) - iVar42) + iVar14;
                  *(int *)((longlong)&sStackX_18 + lVar17 + 4) = iVar42;
                  if ((*(byte *)((longlong)&sStackX_18 + lVar17 + 2) & 1) != 0) {
                    *(ushort *)
                     (lVar41 + 2 + (ulonglong)(*(ushort *)(&stack0x00000034 + lVar17) + 1) * 2) =
                         (ushort)iVar42 | 0x8000;
                    iVar42 = (*(int *)((longlong)&sStackX_18 + lVar17 + 4) -
                             *(int *)(&stack0x00000070 + lVar17)) + -2;
                  }
                  *(ushort *)(lVar41 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar17) * 2) =
                       (ushort)iVar42 | 0x8000;
                  lVar20 = (longlong)&sStackX_18 + lVar17 + 2;
                  if (iVar14 == 0) {
                    uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                    *(undefined8 *)(puVar40 + -8) = 0x101b8b;
                    func_0x(lVar20,uVar27 + 1,0);
                    if ((**(byte **)((longlong)&puStackX_20 + lVar17) & 0x20) != 0) {
                      *(short *)(&stack0x00000034 + lVar17) =
                           *(short *)(&stack0x00000034 + lVar17) + 1;
                      puVar45 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                      *puVar45 = *puVar45 & 0xfffd;
                      *(undefined8 *)(puVar40 + -8) = 0x101baa;
                      func_0x(&stack0x00000042 + lVar17);
                    }
                  }
                  else {
                    puVar45 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                    *puVar45 = *puVar45 | 2;
                    *(undefined8 *)(puVar40 + -8) = 0x101bbd;
                    uVar11 = func_0x(lVar20,&stack0x000001c0 + lVar17);
                    *(undefined2 *)(&stack0x00000042 + lVar17) = uVar11;
                  }
                  if ((*(byte *)((longlong)&sStackX_18 + lVar17 + 2) & 1) != 0) {
                    uVar13 = *(undefined4 *)(&stack0x00000070 + lVar17);
                    *(undefined8 *)(puVar40 + -8) = 0x101be0;
                    func_0x((longlong)&sStackX_18 + lVar17 + 2,0x400,uVar13);
                  }
                  if ((bVar9 & 1) != 0) {
                    *(undefined8 *)(puVar40 + -8) = 0x101bf9;
                    func_0x
                              ((longlong)&sStackX_18 + lVar17 + 2,&stack0x000003c8 + lVar17);
                  }
                }
                else {
                  if (*(int *)((longlong)&sStackX_18 + lVar17 + 4) == 0) {
                    pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                    uVar32 = *(uint *)(&stack0x00000028 + lVar17);
                    uVar34 = (ulonglong)uVar32;
                    *(undefined2 *)((longlong)&sStackX_18 + lVar17 + 2) = 0;
                    *(uint *)(&stack0x0000002c + lVar17) = uVar32;
                    if ((*pbVar44 & 0x10) != 0) {
                      uVar32 = uVar32 + 2 + (*(ushort *)(pbVar44 + uVar34) + 7 >> 3);
                      uVar34 = (ulonglong)uVar32;
                      *(uint *)(&stack0x0000002c + lVar17) = uVar32;
                    }
                    uVar32 = (uint)uVar34;
                    if ((*pbVar44 & 0x20) == 0) {
                      *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar32;
                      *(undefined2 *)(&stack0x00000034 + lVar17) = 0;
                      *(uint *)(&stack0x00000030 + lVar17) = uVar32;
                    }
                    else {
                      puVar45 = (ushort *)(pbVar44 + uVar34);
                      uVar27 = *puVar45;
                      *(ushort *)(&stack0x00000034 + lVar17) = uVar27;
                      if (uVar27 == 0) {
                        *(undefined8 *)(puVar40 + -8) = 0x100c93;
                        cVar8 = func_0x(0x11989c0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x100c9c;
                          lVar20 = func_0x();
                          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x100cb5;
                            cVar8 = func_0x(0x11989c0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x100cd1;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x100cf5;
                              (*_DAT_)(1,0xa89748,0xba9418,0x80f);
                            }
                            pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                          }
                        }
                        *(undefined8 *)(puVar40 + -8) = 0x100d06;
                        func_0x(pbVar44,3);
                        uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                        uVar34 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                        pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                      }
                      uVar43 = (int)uVar34 + (uVar27 + 1) * 2;
                      *(uint *)(&stack0x00000030 + lVar17) = uVar43;
                      if (0x1f9e < uVar43) {
                        *(undefined8 *)(puVar40 + -8) = 0x100d3b;
                        cVar8 = func_0x(0x11989c0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x100d44;
                          lVar20 = func_0x();
                          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x100d5d;
                            cVar8 = func_0x(0x11989c0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x100d79;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x100d9d;
                              (*_DAT_)(1,0xa89748,0xba9418,0x816);
                            }
                            pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                          }
                        }
                        *(undefined8 *)(puVar40 + -8) = 0x100dae;
                        func_0x(pbVar44,4);
                        uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                        uVar43 = *(uint *)(&stack0x00000030 + lVar17);
                        uVar34 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                        pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                      }
                      uVar29 = (ulonglong)uVar27;
                      uVar32 = puVar45[uVar29] & 0x7fff;
                      *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar32;
                      if (uVar32 < uVar43) {
                        *(undefined8 *)(puVar40 + -8) = 0x100dea;
                        cVar8 = func_0x(0x11989c0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x100df3;
                          lVar20 = func_0x();
                          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x100e0c;
                            cVar8 = func_0x(0x11989c0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x100e28;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x100e4c;
                              (*_DAT_)(1,0xa89748,0xba9418,0x81d);
                            }
                            pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                          }
                        }
                        *(undefined8 *)(puVar40 + -8) = 0x100e5d;
                        func_0x(pbVar44,4);
                        uVar29 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar17);
                        uVar43 = *(uint *)(&stack0x00000030 + lVar17);
                        uVar34 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                        uVar32 = *(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                        pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                      }
                      uVar50 = (ulonglong)uVar43;
                      do {
                        if (-1 < (short)puVar45[(ulonglong)((int)uVar29 - 1) + 1]) break;
                        uVar36 = uVar50;
                        if ((((int)uVar29 != 1) &&
                            (uVar36 = (ulonglong)
                                      (*(ushort *)(pbVar44 + uVar29 * 2 + (uVar34 - 2)) & 0x7fff),
                            (*(ushort *)(pbVar44 + uVar29 * 2 + (uVar34 - 2)) & 0x7fff) <
                            (uint)uVar50)) ||
                           ((*(ushort *)(pbVar44 + uVar29 * 2 + uVar34) & 0x7fff) < (uint)uVar36)) {
                          *(undefined8 *)(puVar40 + -8) = 0x100ec8;
                          func_0x(pbVar44,7);
                          uVar29 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar17);
                          uVar50 = (ulonglong)*(uint *)(&stack0x00000030 + lVar17);
                          uVar34 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                          uVar32 = *(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                          pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                        }
                        if (((uint)uVar36 < (uint)uVar50) || (uVar32 < (uint)uVar36))
                        goto LAB_;
                        if (*(ushort *)(pbVar44 + uVar36) == 5) {
                          puVar45 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                          *puVar45 = *puVar45 | 2;
                          uVar27 = *(ushort *)(&stack0x00000044 + lVar17);
                          *(short *)(&stack0x00000034 + lVar17) = (short)uVar29 + -1;
                          *(short *)(&stack0x00000042 + lVar17) = (short)uVar36;
                          if ((*(ushort *)(pbVar44 + (uVar36 & 0xffff) + 2) >> 0xe & 1) == 0) {
                            uVar27 = uVar27 & 0xc7ff;
                          }
                          else {
                            uVar27 = uVar27 ^ (uVar27 ^ *(ushort *)(pbVar44 + (uVar36 & 0xffff) + 2)
                                              ) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar17) = uVar27;
                          *(ushort *)(&stack0x00000044 + lVar17) =
                               uVar27 ^ (uVar27 ^ *(ushort *)(pbVar44 + (uVar36 & 0xffff) + 2)) &
                                        0x7ff;
                          break;
                        }
                        if (*(ushort *)(pbVar44 + uVar36) < 0x400) break;
                        puVar1 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                        *puVar1 = *puVar1 | 1;
                        uVar27 = (short)uVar29 - 1;
                        uVar29 = (ulonglong)uVar27;
                        *(ushort *)(&stack0x00000034 + lVar17) = uVar27;
                      } while (uVar27 != 0);
                    }
                    if ((*pbVar44 & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar17) = 0;
                    }
                    else {
                      *(uint *)(&stack0x0000003e + lVar17) = uVar32;
                      *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar32 + 0xe;
                      *(undefined8 *)(puVar40 + -8) = 0x100f39;
                      uVar24 = func_0x((longlong)&sStackX_18 + lVar17 + 2);
                      *(undefined8 *)(puVar40 + -8) = 0x100f48;
                      func_0x(uVar24,&stack0x000001d0 + lVar17);
                      *(undefined8 *)(puVar40 + -8) = 0x100f54;
                      iVar14 = func_0x(&stack0x000001d0 + lVar17);
                      pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                      uVar32 = *(int *)((longlong)&sStackX_18 + lVar17 + 4) + iVar14;
                      *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar32;
                    }
                    if ((*(byte **)(&stack0x00000036 + lVar17) != (byte *)0x0) &&
                       (*(byte **)(&stack0x00000036 + lVar17) < pbVar44 + uVar32)) {
                      *(undefined8 *)(puVar40 + -8) = 0x101009;
                      cVar8 = func_0x(0x11989c0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x101012;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar40 + -8) = 0x10102c;
                          cVar8 = func_0x(0x11989c0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar40 + -8) = 0x101048;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar40 + 0x20) = 0;
                            *(undefined8 *)(puVar40 + -8) = 0x10106c;
                            (*_DAT_)(1,0xa89748,0xba9418);
                          }
                          pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                        }
                      }
                      *(undefined8 *)(puVar40 + -8) = 0x10107d;
                      func_0x(pbVar44,0x12);
                      uVar32 = *(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                      pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                    }
                    if (0x3f3b < uVar32 - 1) {
                      *(undefined8 *)(puVar40 + -8) = 0x1010a0;
                      cVar8 = func_0x(0x11989c0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x1010a9;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar40 + -8) = 0x1010c3;
                          cVar8 = func_0x(0x11989c0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar40 + -8) = 0x1010df;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar40 + 0x20) = 0;
                            *(undefined8 *)(puVar40 + -8) = 0x101103;
                            (*_DAT_)(1,0xa89748,0xba9418);
                          }
                          pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                        }
                      }
                      *(undefined8 *)(puVar40 + -8) = 0x101114;
                      func_0x(pbVar44,5);
                    }
                  }
LAB_:
                  uVar43 = -*puVar46;
                  *(undefined8 *)(puVar40 + -8) = 0x101127;
                  func_0x(&stack0x000002e8 + lVar17);
                  pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                  bVar9 = *pbVar44;
                  uVar32 = bVar9 >> 6 & 1;
                  *(uint *)(&stack0x000000d0 + lVar17) = uVar32;
                  if ((bVar9 >> 6 & 1) != 0) {
                    *(undefined8 *)(puVar40 + -8) = 0x101150;
                    func_0x
                              ((longlong)&sStackX_18 + lVar17 + 2,&stack0x000002e8 + lVar17);
                    pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                  }
                  if ((*pbVar44 & 0x20) == 0) {
                    *(undefined8 *)(puVar40 + -8) = 0x101163;
                    func_0x((longlong)&sStackX_18 + lVar17 + 2);
                    pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                  }
                  uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                  uVar12 = (uint)uVar27;
                  uVar35 = (uint)uVar27;
                  if (uVar35 < uVar43) {
                    puVar45 = (ushort *)(pbVar44 + *(uint *)(&stack0x0000002c + lVar17));
                    uVar12 = *(uint *)(&stack0x0000002c + lVar17) + 2 + uVar35 * 2;
                    uVar49 = 0;
                    uVar28 = (uVar43 - uVar27) * 2;
                    if (*puVar45 != 0) {
                      do {
                        uVar32 = uVar49 & 0xffff;
                        uVar34 = (ulonglong)uVar49;
                        uVar49 = uVar49 + 1;
                        puVar45[(ulonglong)uVar32 + 1] =
                             puVar45[(ulonglong)uVar32 + 1] ^
                             ((short)uVar28 + puVar45[uVar34 + 1] ^ puVar45[(ulonglong)uVar32 + 1])
                             & 0x7fff;
                      } while (uVar49 < *puVar45);
                      pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                      uVar32 = *(uint *)(&stack0x000000d0 + lVar17);
                    }
                    iVar14 = *(int *)((longlong)&sStackX_18 + lVar17 + 4);
                    *(undefined8 *)(puVar40 + -8) = 0x1011f0;
                    func_0x
                              (pbVar44 + (ulonglong)uVar12 + (ulonglong)uVar28,pbVar44 + uVar12,
                               iVar14 - uVar12);
                    iVar14 = *(int *)(&stack0x00000030 + lVar17);
                    piVar52 = (int *)((longlong)&sStackX_18 + lVar17 + 4);
                    *piVar52 = *piVar52 + uVar28;
                    uVar28 = iVar14 + uVar28;
                    *(uint *)(&stack0x00000030 + lVar17) = uVar28;
                    if (uVar27 != 0) {
                      uVar28 = puVar45[(ulonglong)(uVar35 - 1) + 1] & 0x7fff;
                    }
                    do {
                      uVar12 = uVar35 & 0xffff;
                      uVar35 = uVar35 + 1;
                      puVar45[(ulonglong)uVar12 + 1] = (ushort)uVar28 & 0x7fff;
                    } while (uVar35 < uVar43);
                    *puVar45 = *puVar45 + (short)(uVar43 - uVar27);
                    *(undefined8 *)(puVar40 + -8) = 0x10123b;
                    iVar14 = func_0x((longlong)&sStackX_18 + lVar17 + 2);
                    if (iVar14 != 0) {
                      *(undefined8 *)(puVar40 + -8) = 0x10124f;
                      uVar11 = func_0x
                                         ((longlong)&sStackX_18 + lVar17 + 2,
                                          &stack0x000001b8 + lVar17);
                      *(undefined2 *)(&stack0x00000042 + lVar17) = uVar11;
                    }
                    pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                    uVar12 = uVar43 & 0xffff;
                    *(short *)(&stack0x00000034 + lVar17) = (short)uVar43;
                  }
                  uVar34 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                  if (uVar12 < uVar43) {
                    uVar29 = (ulonglong)
                             (*(ushort *)(pbVar44 + (ulonglong)(ushort)uVar12 * 2 + uVar34) & 0x7fff
                             );
                    iVar14 = 0;
LAB_:
                    uVar13 = *(undefined4 *)((longlong)&sStackX_18 + lVar17 + 4);
                    puVar45 = (ushort *)(pbVar44 + uVar34);
                    *(undefined8 *)(puVar40 + -8) = 0x1012eb;
                    uVar13 = func_0x(uVar13,iVar14 + (int)uVar29);
                    lVar20 = *(longlong *)((longlong)&puStackX_20 + lVar17);
                    *(undefined8 *)(puVar40 + -8) = 0x101307;
                    func_0x(lVar20 + 1 + uVar29,iVar14 + lVar20 + uVar29,uVar13);
                    uVar43 = uVar43 - 1;
                    if ((int)uVar43 < (int)(uint)*puVar45) {
                      do {
                        uVar34 = (ulonglong)uVar43;
                        lVar20 = (longlong)(int)uVar43;
                        uVar43 = uVar43 + 1;
                        puVar45[(uVar34 & 0xffff) + 1] =
                             puVar45[(uVar34 & 0xffff) + 1] ^
                             ((puVar45[lVar20 + 1] - (short)iVar14) + 1 ^
                             puVar45[(uVar34 & 0xffff) + 1]) & 0x7fff;
                      } while ((int)uVar43 < (int)(uint)*puVar45);
                      uVar32 = *(uint *)(&stack0x000000d0 + lVar17);
                    }
                    piVar52 = (int *)((longlong)&sStackX_18 + lVar17 + 4);
                    *piVar52 = *piVar52 + (1 - iVar14);
                    *(undefined8 *)(puVar40 + -8) = 0x101367;
                    iVar14 = func_0x((longlong)&sStackX_18 + lVar17 + 2);
                    if (iVar14 != 0) {
                      *(undefined8 *)(puVar40 + -8) = 0x10137b;
                      uVar11 = func_0x
                                         ((longlong)&sStackX_18 + lVar17 + 2,
                                          &stack0x000001bc + lVar17);
                      *(undefined2 *)(&stack0x00000042 + lVar17) = uVar11;
                    }
                    pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                  }
                  else {
                    uVar35 = *(uint *)(&stack0x00000030 + lVar17);
                    if (uVar43 != 1) {
                      uVar35 = *(ushort *)(pbVar44 + (longlong)(int)uVar43 * 2 + (uVar34 - 2)) &
                               0x7fff;
                    }
                    uVar29 = (ulonglong)uVar35;
                    uVar27 = *(ushort *)(pbVar44 + (longlong)(int)uVar43 * 2 + uVar34);
                    if ((uVar35 < *(uint *)(&stack0x00000030 + lVar17)) ||
                       ((uVar27 & 0x7fff) < uVar35)) {
                      *(undefined8 *)(puVar40 + -8) = 0x1012ad;
                      func_0x(pbVar44,7);
                      uVar34 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17);
                      pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                    }
                    iVar14 = (uVar27 & 0x7fff) - uVar35;
                    if (iVar14 != 1) goto LAB_;
                  }
                  pbVar44[uVar29] = **(byte **)(&stack0x00000060 + lVar17);
                  if (uVar32 != 0) {
                    *(undefined8 *)(puVar40 + -8) = 0x1013a6;
                    func_0x
                              ((longlong)&sStackX_18 + lVar17 + 2,&stack0x000002e8 + lVar17);
                  }
                }
              }
              else {
                bVar9 = (byte)*(ushort *)((longlong)puVar46 + 6);
                if ((*(ushort *)((longlong)puVar46 + 6) & 8) == 0) {
                  if (*(int *)((longlong)&sStackX_18 + lVar17 + 4) == 0) {
                    pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                    uVar32 = *(uint *)(&stack0x00000028 + lVar17);
                    *(undefined2 *)((longlong)&sStackX_18 + lVar17 + 2) = 0;
                    *(uint *)(&stack0x0000002c + lVar17) = uVar32;
                    if ((*pbVar44 & 0x10) != 0) {
                      *(uint *)(&stack0x0000002c + lVar17) =
                           uVar32 + 2 + (*(ushort *)(pbVar44 + uVar32) + 7 >> 3);
                    }
                    if ((**(byte **)((longlong)&puStackX_20 + lVar17) & 0x20) == 0) {
                      uVar32 = *(uint *)(&stack0x0000002c + lVar17);
                      uVar34 = (ulonglong)uVar32;
                      *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar32;
                      *(uint *)(&stack0x00000030 + lVar17) = uVar32;
                      *(undefined2 *)(&stack0x00000034 + lVar17) = 0;
                    }
                    else {
                      puVar45 = (ushort *)
                                (*(byte **)((longlong)&puStackX_20 + lVar17) +
                                *(uint *)(&stack0x0000002c + lVar17));
                      uVar27 = *puVar45;
                      *(ushort *)(&stack0x00000034 + lVar17) = uVar27;
                      if (uVar27 == 0) {
                        *(undefined8 *)(puVar40 + -8) = 0x100760;
                        cVar8 = func_0x(0x11989c0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x100769;
                          lVar20 = func_0x();
                          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x100783;
                            cVar8 = func_0x(0x11989c0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x10079f;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x1007c3;
                              (*_DAT_)(1,0xa89748,0xba9418,0x80f);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)((longlong)&puStackX_20 + lVar17);
                        *(undefined8 *)(puVar40 + -8) = 0x1007d1;
                        func_0x(uVar24,3);
                        uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                      }
                      uVar32 = *(int *)(&stack0x0000002c + lVar17) + 2 + (uint)uVar27 * 2;
                      *(uint *)(&stack0x00000030 + lVar17) = uVar32;
                      if (0x1f9e < uVar32) {
                        *(undefined8 *)(puVar40 + -8) = 0x100801;
                        cVar8 = func_0x(0x11989c0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x10080a;
                          lVar20 = func_0x();
                          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x100824;
                            cVar8 = func_0x(0x11989c0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x100840;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x100864;
                              (*_DAT_)(1,0xa89748,0xba9418,0x816);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)((longlong)&puStackX_20 + lVar17);
                        *(undefined8 *)(puVar40 + -8) = 0x100872;
                        func_0x(uVar24,4);
                        uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                        uVar32 = *(uint *)(&stack0x00000030 + lVar17);
                      }
                      uVar29 = (ulonglong)uVar27;
                      uVar43 = puVar45[uVar29] & 0x7fff;
                      uVar34 = (ulonglong)uVar43;
                      *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar43;
                      if (uVar43 < uVar32) {
                        *(undefined8 *)(puVar40 + -8) = 0x1008a6;
                        cVar8 = func_0x(0x11989c0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x1008af;
                          lVar20 = func_0x();
                          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x1008c9;
                            cVar8 = func_0x(0x11989c0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x1008e5;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x100909;
                              (*_DAT_)(1,0xa89748,0xba9418,0x81d);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)((longlong)&puStackX_20 + lVar17);
                        *(undefined8 *)(puVar40 + -8) = 0x100917;
                        func_0x(uVar24,4);
                        uVar29 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar17);
                        uVar32 = *(uint *)(&stack0x00000030 + lVar17);
                        uVar34 = (ulonglong)*(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                      }
                      do {
                        if (-1 < (short)puVar45[(ulonglong)((int)uVar29 - 1) + 1]) break;
                        lVar20 = (ulonglong)*(uint *)(&stack0x0000002c + lVar17) +
                                 *(longlong *)((longlong)&puStackX_20 + lVar17);
                        uVar43 = uVar32;
                        if ((((int)uVar29 != 1) &&
                            (uVar43 = *(ushort *)(lVar20 + -2 + uVar29 * 2) & 0x7fff,
                            uVar43 < uVar32)) ||
                           ((*(ushort *)(lVar20 + uVar29 * 2) & 0x7fff) < uVar43)) {
                          uVar24 = *(undefined8 *)((longlong)&puStackX_20 + lVar17);
                          *(undefined8 *)(puVar40 + -8) = 0x100979;
                          func_0x(uVar24,7);
                          uVar29 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar17);
                          uVar32 = *(uint *)(&stack0x00000030 + lVar17);
                          uVar34 = (ulonglong)*(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                        }
                        if ((uVar43 < uVar32) || ((uint)uVar34 < uVar43)) goto LAB_;
                        uVar27 = *(ushort *)
                                  ((ulonglong)uVar43 +
                                  *(longlong *)((longlong)&puStackX_20 + lVar17));
                        if (uVar27 == 5) {
                          puVar45 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                          *puVar45 = *puVar45 | 2;
                          uVar27 = *(ushort *)(&stack0x00000044 + lVar17);
                          *(short *)(&stack0x00000042 + lVar17) = (short)uVar43;
                          lVar20 = (ulonglong)(uVar43 & 0xffff) +
                                   *(longlong *)((longlong)&puStackX_20 + lVar17);
                          *(short *)(&stack0x00000034 + lVar17) = (short)uVar29 + -1;
                          uVar31 = *(ushort *)(lVar20 + 2);
                          if ((uVar31 >> 0xe & 1) == 0) {
                            uVar27 = uVar27 & 0xc7ff;
                          }
                          else {
                            uVar27 = uVar27 ^ (uVar27 ^ uVar31) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar17) = uVar27;
                          *(ushort *)(&stack0x00000044 + lVar17) =
                               uVar27 ^ (uVar27 ^ *(ushort *)(lVar20 + 2)) & 0x7ff;
                          break;
                        }
                        if (uVar27 < 0x400) break;
                        puVar1 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                        *puVar1 = *puVar1 | 1;
                        uVar27 = (short)uVar29 - 1;
                        uVar29 = (ulonglong)uVar27;
                        *(ushort *)(&stack0x00000034 + lVar17) = uVar27;
                      } while (uVar27 != 0);
                    }
                    if ((**(byte **)((longlong)&puStackX_20 + lVar17) & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar17) = 0;
                    }
                    else {
                      *(int *)(&stack0x0000003e + lVar17) = (int)uVar34;
                      *(int *)((longlong)&sStackX_18 + lVar17 + 4) = (int)uVar34 + 0xe;
                      *(undefined8 *)(puVar40 + -8) = 0x100a6d;
                      uVar24 = func_0x((longlong)&sStackX_18 + lVar17 + 2);
                      *(undefined8 *)(puVar40 + -8) = 0x100a7c;
                      func_0x(uVar24,&stack0x000001c8 + lVar17);
                      *(undefined8 *)(puVar40 + -8) = 0x100a88;
                      iVar14 = func_0x(&stack0x000001c8 + lVar17);
                      uVar32 = *(int *)((longlong)&sStackX_18 + lVar17 + 4) + iVar14;
                      uVar34 = (ulonglong)uVar32;
                      *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar32;
                    }
                    if ((*(ulonglong *)(&stack0x00000036 + lVar17) != 0) &&
                       (*(ulonglong *)(&stack0x00000036 + lVar17) <
                        uVar34 + *(longlong *)((longlong)&puStackX_20 + lVar17))) {
                      *(undefined8 *)(puVar40 + -8) = 0x100ac1;
                      cVar8 = func_0x(0x11989c0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x100aca;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar40 + -8) = 0x100ae4;
                          cVar8 = func_0x(0x11989c0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar40 + -8) = 0x100b00;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar40 + 0x20) = 0;
                            *(undefined8 *)(puVar40 + -8) = 0x100b24;
                            (*_DAT_)(1,0xa89748,0xba9418);
                          }
                        }
                      }
                      uVar24 = *(undefined8 *)((longlong)&puStackX_20 + lVar17);
                      *(undefined8 *)(puVar40 + -8) = 0x100b32;
                      func_0x(uVar24,0x12);
                      uVar34 = (ulonglong)*(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                    }
                    if (0x3f3b < (int)uVar34 - 1U) {
                      *(undefined8 *)(puVar40 + -8) = 0x100b4d;
                      cVar8 = func_0x(0x11989c0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x100b56;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar40 + -8) = 0x100b70;
                          cVar8 = func_0x(0x11989c0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar40 + -8) = 0x100b8c;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar40 + 0x20) = 0;
                            *(undefined8 *)(puVar40 + -8) = 0x100bb0;
                            (*_DAT_)(1,0xa89748,0xba9418);
                          }
                        }
                      }
                      uVar24 = *(undefined8 *)((longlong)&puStackX_20 + lVar17);
                      *(undefined8 *)(puVar40 + -8) = 0x100bbe;
                      func_0x(uVar24,5);
                    }
                  }
LAB_:
                  uVar32 = *(uint *)(&stack0x00000028 + lVar17);
                  uVar43 = *puVar46 + 1;
                  if (uVar32 < uVar43) {
                    *(undefined8 *)(puVar40 + -8) = 0x100bdf;
                    func_0x((longlong)&sStackX_18 + lVar17 + 2,0,uVar43 - uVar32);
                    if ((1 << (**(byte **)((longlong)&puStackX_20 + lVar17) & 0xe) & 0x1105U) != 0)
                    {
                      *(short *)(*(byte **)((longlong)&puStackX_20 + lVar17) + 2) = (short)uVar43;
                    }
                    *(uint *)(&stack0x00000028 + lVar17) = uVar43;
                  }
                  if (pcVar55 != (char *)0x0) {
                    *(char *)((longlong)(int)*puVar46 +
                             *(longlong *)((longlong)&puStackX_20 + lVar17)) = *pcVar55;
                  }
                }
                else {
                  uVar43 = *(uint *)(&stack0x00000028 + lVar17);
                  uVar35 = uVar32 + 1;
                  cVar8 = *pcVar55;
                  if (uVar43 < uVar35) {
                    *(undefined8 *)(puVar40 + -8) = 0x1006a3;
                    func_0x((longlong)&sStackX_18 + lVar17 + 2,0,uVar35 - uVar43);
                    pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                    if ((1 << (*pbVar44 & 0xe) & 0x1105U) != 0) {
                      *(short *)(pbVar44 + 2) = (short)uVar35;
                      pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                    }
                    *(uint *)(&stack0x00000028 + lVar17) = uVar35;
                    bVar9 = *(byte *)((longlong)puVar46 + 6);
                  }
                  else {
                    pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
                  }
                  if (cVar8 == '\0') {
                    pbVar44[(int)uVar32] = pbVar44[(int)uVar32] & ~(byte)(1 << (bVar9 & 7));
                  }
                  else {
                    pbVar44[(int)uVar32] = pbVar44[(int)uVar32] | (byte)(1 << (bVar9 & 7));
                  }
                }
              }
            }
            else {
              *(undefined8 *)(puVar40 + 0x20) = 0x805c28;
              *(undefined8 *)(puVar40 + -8) = 0x10065b;
              (*_DAT_)(1,0xc0aa80,0xc373c0);
            }
          }
          iVar14 = *(int *)(&stack0x00000058 + lVar17);
          puVar46 = puVar46 + 0x14;
          puVar39 = *(undefined **)(&stack0x00000160 + lVar17);
          *(uint *)(&stack0x00000058 + lVar17) = iVar14 + 1U;
        } while (iVar14 + 1U < *(uint *)(&stack0x00000090 + lVar17));
        uVar32 = *(uint *)(&stack0x00000080 + lVar17);
        uVar43 = *(uint *)(&stack0x0000005c + lVar17);
      }
      puVar45 = (ushort *)0x0;
      if (uVar32 != 0) {
        lVar20 = *(longlong *)(&stack0x00000160 + lVar17);
        do {
          uVar34 = (ulonglong)uVar32;
          uVar35 = uVar32 - 1;
          if (*(int *)((ulonglong)uVar35 * 0x20 + 8 + lVar20) != 0) {
            pbVar44 = *(byte **)((longlong)&puStackX_20 + lVar17);
            *(ushort *)(&stack0x00000034 + lVar17) = (ushort)uVar32;
            iVar14 = *(int *)(&stack0x0000002c + lVar17) + 2 + uVar32 * 2;
            *(int *)(&stack0x00000030 + lVar17) = iVar14;
            *(int *)((longlong)&sStackX_18 + lVar17 + 4) = iVar14;
            *pbVar44 = *pbVar44 | 0x20;
            uVar35 = *(uint *)((longlong)&sStackX_18 + lVar17 + 4);
            if (uVar35 < 0x1f7d) {
              puVar45 = (ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000002c + lVar17) +
                        *(longlong *)((longlong)&puStackX_20 + lVar17));
              *puVar45 = (ushort)uVar32;
              uVar35 = *(uint *)((longlong)&sStackX_18 + lVar17 + 4);
            }
            if (uVar32 != 0) {
              puVar46 = (uint *)(lVar20 + 0xc);
              do {
                puVar45 = puVar45 + 1;
                uVar32 = puVar46[-1];
                uVar29 = (ulonglong)uVar35;
                uVar35 = uVar35 + uVar32;
                lVar20 = *(longlong *)((longlong)&puStackX_20 + lVar17);
                *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar35;
                if ((uVar35 < 0x1f7d) && (uVar35 <= uVar43)) {
                  *puVar45 = (ushort)((*puVar46 & 1) << 0xf) | (ushort)uVar35 & 0x7fff;
                  uVar24 = *(undefined8 *)(puVar46 + -3);
                  *(undefined8 *)(puVar40 + -8) = 0x101e7d;
                  func_0x(uVar29 + lVar20,uVar32,uVar24,uVar32);
                  uVar35 = *(uint *)((longlong)&sStackX_18 + lVar17 + 4);
                }
                puVar46 = puVar46 + 8;
                uVar34 = uVar34 - 1;
              } while (uVar34 != 0);
            }
            break;
          }
          uVar32 = uVar35;
        } while (uVar35 != 0);
      }
    }
  }
  else {
    if (bVar7) {
      uVar23 = 0x1201250;
      uVar30 = 0x11f37b8;
    }
    else {
      uVar23 = 0x11f3c08;
      uVar30 = 0x11f3780;
    }
    *(undefined8 *)(&stack0x00000200 + lVar17) = 0;
    if ((bVar9 & 1) == 0) {
      uVar23 = uVar30;
    }
    *(undefined8 *)(&stack0x000001f8 + lVar17) = uVar23;
    *(longlong *)(puVar40 + 0x40) = param_1 + 0x4c8;
    *(undefined **)(puVar40 + 0x38) = &stack0x000001e8 + lVar17;
    *(undefined4 *)(puVar40 + 0x30) = 0x1f7c;
    *(uint *)(puVar40 + 0x28) = uVar43;
    *(undefined8 *)(puVar40 + 0x20) = uVar24;
    *(undefined8 *)(puVar40 + -8) = 0x1023dc;
    func_0x(&stack0x00000178 + lVar17,&stack0x000000e8 + lVar17,2,psVar4);
  }
  lVar20 = *(longlong *)(&stack0x00000068 + lVar17);
  *(undefined8 *)(puVar40 + -8) = 0x1023ef;
  func_0x(lVar20 + 0x180);
  plVar6 = *(longlong **)(&stack0x00000168 + lVar17);
  lVar41 = plVar6[0x1a];
  if ((*(byte *)(lVar20 + 0x4b8) & 1) == 0) {
    UNRECOVERED_JUMPTABLE = *(code **)*plVar6;
    *(undefined8 *)(puVar40 + -8) = 0x102413;
    cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
    if (cVar8 == '\0') {
      UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x88);
      *(undefined8 *)(puVar40 + -8) = 0x102427;
      cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
      if (cVar8 != '\0') {
        if (*(char *)(lVar20 + 0x4b9) != '\0') goto LAB_;
        if (lVar41 == 0) {
          UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x18);
          *(undefined8 *)(puVar40 + -8) = 0x10244b;
          cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
          if (cVar8 == '\0') goto LAB_;
        }
        if ((*(byte *)(plVar6 + 0x4a) & 4) == 0) {
          if ((*(byte *)(plVar6 + 0x4a) & 0x5a) == 0) {
            if ((*(byte *)(plVar6 + 0x43) & 1) != 0) {
              if (plVar6[0x1a] == 0) {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x88);
                *(undefined8 *)(puVar40 + -8) = 0x10248d;
                cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                if (cVar8 != '\0') {
                  UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x18);
                  *(undefined8 *)(puVar40 + -8) = 0x10249a;
                  cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                  if (cVar8 == '\0') {
                    *(byte *)(plVar6 + 0x4a) = *(byte *)(plVar6 + 0x4a) | 4;
                    goto LAB_;
                  }
                }
              }
              *(undefined8 *)(puVar40 + -8) = 0x1024b2;
              iVar14 = func_0x(plVar6);
              if (iVar14 == 0) {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x270);
                *(undefined8 *)(puVar40 + -8) = 0x1024c2;
                (*UNRECOVERED_JUMPTABLE)(plVar6);
              }
              if ((*(byte *)(plVar6 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar6 + 0x4a) & 0x52) == 2) {
                  lVar18 = plVar6[0x1a];
                  *(undefined8 *)(puVar40 + -8) = 0x1024fa;
                  cVar8 = func_0x(lVar18);
                  if (((cVar8 != '\0') && (*(char *)(plVar6[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(plVar6[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x10253f;
                    func_0x(0x119d180,0x1c,0x10,1);
                  }
                }
                uVar32 = (uint)((*(byte *)(plVar6 + 0x4a) & 0x5a) != 0);
              }
              else {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x1e8);
                *(undefined8 *)(puVar40 + -8) = 0x1024d7;
                uVar24 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                *(undefined8 *)(puVar40 + -8) = 0x1024df;
                uVar32 = func_0x(uVar24);
              }
              if (uVar32 != 0) goto LAB_;
            }
          }
          else {
LAB_:
            if (((*(byte *)(plVar6 + 0x4a) & 0x40) != 0) && (*(char *)(lVar20 + 0x4ba) != '\0'))
            goto LAB_;
          }
        }
      }
LAB_:
      if ((*(byte *)(lVar20 + 0x4b8) & 0x1c) != 0) goto LAB_;
      if (*(longlong *)(lVar20 + 0x4c0) != 0) {
        *(undefined8 *)(puVar40 + -8) = 0x10258a;
        iVar14 = func_0x();
        if (((iVar14 != 0) &&
            (iVar14 = *(int *)(*(longlong *)(*(longlong *)(lVar20 + 0x4c0) + 8) + 0x100),
            iVar14 != 0)) && (1 < iVar14 - 3U)) {
          *(undefined8 *)(puVar40 + 0x20) = 0;
          *(undefined8 *)(puVar40 + -8) = 0x1025cf;
          (*_DAT_)(1,0xc380f0,0xc38140,0x116);
        }
        uVar24 = *(undefined8 *)(lVar20 + 0x4c0);
        *(undefined8 *)(puVar40 + -8) = 0x1025db;
        iVar14 = func_0x(uVar24);
        if ((((iVar14 != 0) &&
             (lVar18 = *(longlong *)(*(longlong *)(lVar20 + 0x4c0) + 8),
             (*(byte *)(lVar18 + 0x109) & 1) == 0)) &&
            (iVar14 = *(int *)(lVar18 + 0x100), iVar14 != 0)) && (1 < iVar14 - 3U)) {
          *(undefined8 *)(puVar40 + 0x20) = 0;
          *(undefined8 *)(puVar40 + -8) = 0x102629;
          (*_DAT_)(1,0xc38170,0xc38140,0x119);
        }
      }
      if ((lVar41 == 0) || ((*(int *)(lVar41 + 0x78) < 1 && (*(int *)(lVar41 + 0x74) < 1)))) {
        if ((*(byte *)(plVar6 + 0x4a) & 4) == 0) {
          if ((*(byte *)(plVar6 + 0x4a) & 0x5a) != 0) {
LAB_:
            if (lVar41 != 0) goto LAB_;
            goto LAB_;
          }
          if ((*(byte *)(plVar6 + 0x43) & 1) != 0) {
            if (plVar6[0x1a] == 0) {
              UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x88);
              *(undefined8 *)(puVar40 + -8) = 0x10267c;
              cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
              if (cVar8 != '\0') {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x18);
                *(undefined8 *)(puVar40 + -8) = 0x102689;
                cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                if (cVar8 == '\0') {
                  *(byte *)(plVar6 + 0x4a) = *(byte *)(plVar6 + 0x4a) | 4;
                  goto LAB_;
                }
              }
            }
            *(undefined8 *)(puVar40 + -8) = 0x1026a1;
            iVar14 = func_0x(plVar6);
            if (iVar14 == 0) {
              UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x270);
              *(undefined8 *)(puVar40 + -8) = 0x1026b1;
              (*UNRECOVERED_JUMPTABLE)(plVar6);
            }
            if ((*(byte *)(plVar6 + 0x43) & 4) == 0) {
              if ((*(byte *)(plVar6 + 0x4a) & 0x52) == 2) {
                lVar18 = plVar6[0x1a];
                *(undefined8 *)(puVar40 + -8) = 0x1026e9;
                cVar8 = func_0x(lVar18);
                if (((cVar8 != '\0') && (*(char *)(plVar6[0x1a] + 0x130) == '\0')) &&
                   (*(undefined *)(plVar6[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x10272e;
                  func_0x(0x119d180,0x1c,0x10,1);
                }
              }
              uVar32 = (uint)((*(byte *)(plVar6 + 0x4a) & 0x5a) != 0);
            }
            else {
              UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x1e8);
              *(undefined8 *)(puVar40 + -8) = 0x1026c6;
              uVar24 = (*UNRECOVERED_JUMPTABLE)(plVar6);
              *(undefined8 *)(puVar40 + -8) = 0x1026ce;
              uVar32 = func_0x(uVar24);
            }
            if (uVar32 != 0) goto LAB_;
          }
        }
      }
      else {
LAB_:
        if ((*(byte *)(lVar20 + 0x4b8) & 0x1c) == 0) {
          if (*(longlong *)(lVar20 + 0x4c0) != 0) {
            *(undefined8 *)(puVar40 + -8) = 0x10276f;
            iVar14 = func_0x();
            if (((iVar14 != 0) &&
                (iVar14 = *(int *)(*(longlong *)(*(longlong *)(lVar20 + 0x4c0) + 8) + 0x100),
                iVar14 != 0)) && (1 < iVar14 - 3U)) {
              *(undefined8 *)(puVar40 + 0x20) = 0;
              *(undefined8 *)(puVar40 + -8) = 0x1027b4;
              (*_DAT_)(1,0xc380f0,0xc38140,0x116);
            }
            uVar24 = *(undefined8 *)(lVar20 + 0x4c0);
            *(undefined8 *)(puVar40 + -8) = 0x1027c0;
            iVar14 = func_0x(uVar24);
            if (((iVar14 != 0) &&
                (lVar18 = *(longlong *)(*(longlong *)(lVar20 + 0x4c0) + 8),
                (*(byte *)(lVar18 + 0x109) & 1) == 0)) &&
               ((iVar14 = *(int *)(lVar18 + 0x100), iVar14 != 0 && (1 < iVar14 - 3U)))) {
              *(undefined8 *)(puVar40 + 0x20) = 0;
              *(undefined8 *)(puVar40 + -8) = 0x10280e;
              (*_DAT_)(1,0xc38170,0xc38140,0x119);
            }
          }
          if ((*(int *)(lVar41 + 0x78) < 1) && (*(int *)(lVar41 + 0x74) < 1)) {
            if ((*(byte *)(plVar6 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar6 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar6 + 0x43) & 1) != 0) {
                  if (plVar6[0x1a] == 0) {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x88);
                    *(undefined8 *)(puVar40 + -8) = 0x10285c;
                    cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                    if (cVar8 != '\0') {
                      UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x18);
                      *(undefined8 *)(puVar40 + -8) = 0x102869;
                      cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                      if (cVar8 == '\0') {
                        *(byte *)(plVar6 + 0x4a) = *(byte *)(plVar6 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)(puVar40 + -8) = 0x102881;
                  iVar14 = func_0x(plVar6);
                  if (iVar14 == 0) {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x270);
                    *(undefined8 *)(puVar40 + -8) = 0x102891;
                    (*UNRECOVERED_JUMPTABLE)(plVar6);
                  }
                  if ((*(byte *)(plVar6 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar6 + 0x4a) & 0x52) == 2) {
                      lVar18 = plVar6[0x1a];
                      *(undefined8 *)(puVar40 + -8) = 0x1028c9;
                      cVar8 = func_0x(lVar18);
                      if (((cVar8 != '\0') && (*(char *)(plVar6[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar6[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x10290e;
                        func_0x(0x119d180,0x1c,0x10,1);
                      }
                    }
                    uVar32 = (uint)((*(byte *)(plVar6 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x1e8);
                    *(undefined8 *)(puVar40 + -8) = 0x1028a6;
                    uVar24 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                    *(undefined8 *)(puVar40 + -8) = 0x1028ae;
                    uVar32 = func_0x(uVar24);
                  }
                  if (uVar32 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if ((*(byte *)(plVar6 + 0x4a) & 0x10) != 0) goto LAB_;
              }
            }
LAB_:
            if ((*(byte *)(plVar6 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar6 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar6 + 0x43) & 1) != 0) {
                  if (plVar6[0x1a] == 0) {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x88);
                    *(undefined8 *)(puVar40 + -8) = 0x102966;
                    cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                    if (cVar8 != '\0') {
                      UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x18);
                      *(undefined8 *)(puVar40 + -8) = 0x102973;
                      cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                      if (cVar8 == '\0') {
                        *(byte *)(plVar6 + 0x4a) = *(byte *)(plVar6 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)(puVar40 + -8) = 0x10298b;
                  iVar14 = func_0x(plVar6);
                  if (iVar14 == 0) {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x270);
                    *(undefined8 *)(puVar40 + -8) = 0x10299b;
                    (*UNRECOVERED_JUMPTABLE)(plVar6);
                  }
                  if ((*(byte *)(plVar6 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar6 + 0x4a) & 0x52) == 2) {
                      lVar18 = plVar6[0x1a];
                      *(undefined8 *)(puVar40 + -8) = 0x1029d3;
                      cVar8 = func_0x(lVar18);
                      if (((cVar8 != '\0') && (*(char *)(plVar6[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar6[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x102a18;
                        func_0x(0x119d180,0x1c,0x10,1);
                      }
                    }
                    uVar32 = (uint)((*(byte *)(plVar6 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x1e8);
                    *(undefined8 *)(puVar40 + -8) = 0x1029b0;
                    uVar24 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                    *(undefined8 *)(puVar40 + -8) = 0x1029b8;
                    uVar32 = func_0x(uVar24);
                  }
                  if (uVar32 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if ((*(byte *)(plVar6 + 0x4a) & 0x40) != 0) goto LAB_;
              }
            }
          }
        }
LAB_:
        *(undefined8 *)(puVar40 + -8) = 0x102a3c;
        func_0x(lVar41,0);
LAB_:
        *(undefined8 *)(puVar40 + -8) = 0x102a44;
        iVar14 = func_0x(plVar6);
        if (iVar14 == 0) {
          UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x270);
          *(undefined8 *)(puVar40 + -8) = 0x102a54;
          (*UNRECOVERED_JUMPTABLE)(plVar6);
        }
        if (*(longlong *)(lVar20 + 0x208) != 0) {
          UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x88);
          *(undefined8 *)(puVar40 + -8) = 0x102a6a;
          cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
          if (cVar8 != '\0') {
            UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x18);
            *(undefined8 *)(puVar40 + -8) = 0x102a77;
            cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
            if ((((cVar8 == '\0') &&
                 ((*(longlong *)(*(longlong *)(lVar20 + 0x188) + 0x70) != 0 ||
                  (*(int *)(*(longlong *)(*(longlong *)(lVar20 + 0x1a0) + 0x710) + 0x40) != 0)))) &&
                (iVar14 = *(int *)(*(longlong *)(lVar20 + 0x188) + 0x100), iVar14 != 0)) &&
               (1 < iVar14 - 3U)) goto LAB_;
          }
        }
        lVar41 = *(longlong *)(&stack0x00000148 + lVar17);
        if ((lVar41 != 0) &&
           (((0 < *(int *)(lVar41 + 0x78) || (0 < *(int *)(lVar41 + 0x74))) &&
            ((*(byte *)(*(longlong *)(lVar20 + 0x48) + 0x70) & 1) != 0)))) {
          uVar24 = *(undefined8 *)(lVar20 + 0x178);
          uVar23 = *(undefined8 *)(lVar20 + 0x290);
          *(undefined8 *)(puVar40 + -8) = 0x102aef;
          func_0x(uVar23,uVar24,psVar4,0);
        }
        lVar41 = plVar6[0x1a];
        if ((*(byte *)(lVar20 + 0x4b8) & 0x24) == 0) {
          if ((*(byte *)(plVar6 + 0x4a) & 4) == 0) {
            if ((*(byte *)(plVar6 + 0x4a) & 0x5a) != 0) goto LAB_;
            if ((*(byte *)(plVar6 + 0x43) & 1) != 0) {
              if (lVar41 == 0) {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x88);
                *(undefined8 *)(puVar40 + -8) = 0x102b39;
                cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                if (cVar8 != '\0') {
                  UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x18);
                  *(undefined8 *)(puVar40 + -8) = 0x102b46;
                  cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                  if (cVar8 == '\0') {
                    *(byte *)(plVar6 + 0x4a) = *(byte *)(plVar6 + 0x4a) | 4;
                    goto LAB_;
                  }
                }
              }
              *(undefined8 *)(puVar40 + -8) = 0x102b5e;
              iVar14 = func_0x(plVar6);
              if (iVar14 == 0) {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x270);
                *(undefined8 *)(puVar40 + -8) = 0x102b6e;
                (*UNRECOVERED_JUMPTABLE)(plVar6);
              }
              if ((*(byte *)(plVar6 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar6 + 0x4a) & 0x52) == 2) {
                  lVar18 = plVar6[0x1a];
                  *(undefined8 *)(puVar40 + -8) = 0x102ba6;
                  cVar8 = func_0x(lVar18);
                  if (((cVar8 != '\0') && (*(char *)(plVar6[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(plVar6[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                    plVar33 = (longlong *)0x0;
                    if (_DAT_ != 0) {
                      plVar33 = (longlong *)(_DAT_ + 0xe000);
                    }
                    if ((plVar33 != (longlong *)0x0) && (*plVar33 != 0)) {
                      LOCK();
                      plVar33 = (longlong *)(*plVar33 + 0x10);
                      *plVar33 = *plVar33 + 1;
                      UNLOCK();
                    }
                  }
                }
                uVar32 = (uint)((*(byte *)(plVar6 + 0x4a) & 0x5a) != 0);
              }
              else {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar6 + 0x1e8);
                *(undefined8 *)(puVar40 + -8) = 0x102b83;
                uVar24 = (*UNRECOVERED_JUMPTABLE)(plVar6);
                *(undefined8 *)(puVar40 + -8) = 0x102b8b;
                uVar32 = func_0x(uVar24);
              }
              if (uVar32 != 0) goto LAB_;
            }
          }
          if ((lVar41 == 0) || (*(int *)(lVar41 + 0x74) < 1)) goto LAB_;
        }
LAB_:
        uVar26 = *(undefined *)(lVar20 + 0x4b4);
        uVar24 = *(undefined8 *)(lVar20 + 0x178);
        puVar40[0x20] = 0;
        *(undefined8 *)(puVar40 + -8) = 0x102c39;
        func_0x(psVar4,uVar24,uVar26,0);
      }
    }
  }
LAB_:
  lVar41 = *(longlong *)(lVar20 + 0x208);
  if (lVar41 != 0) {
    *(undefined8 *)(puVar40 + -8) = 0x102c55;
    func_0x(lVar41,psVar4,lVar20 + 0x27c);
    goto LAB_;
  }
  lVar41 = *(longlong *)(lVar20 + 0x240);
  *(undefined4 *)(&stack0x0000005c + lVar17) = 0;
  *(undefined2 *)(&stack0x00000230 + lVar17) = 0xffff;
  *(undefined8 *)(&stack0x00000238 + lVar17) = 0;
  *(undefined4 *)(&stack0x00000234 + lVar17) = 0;
  *(undefined8 *)(&stack0x0000024e + lVar17) = 0;
  *(undefined8 *)(&stack0x00000258 + lVar17) = 0;
  *(undefined8 *)(&stack0x00000240 + lVar17) = 0;
  *(undefined4 *)(&stack0x00000264 + lVar17) = 0xffffffff;
  *(undefined8 *)(&stack0x00000060 + lVar17) = 0;
  if (lVar41 != 0) {
    *(undefined8 *)(puVar40 + -8) = 0x102cb1;
    iVar14 = func_0x(lVar20 + -8);
    if (iVar14 == 1) {
      if (((*(byte *)(*(longlong *)(&stack0x00000078 + lVar17) + 0x106) & 0x40) == 0) &&
         ((*(byte *)(*(longlong *)(&stack0x00000078 + lVar17) + 0x108) & 8) == 0)) {
        *(undefined8 *)(puVar40 + 0x20) = 0;
        *(undefined8 *)(puVar40 + -8) = 0x102cee;
        (*_DAT_)(1,0xc66098,0xc10da0,0x3a1);
      }
      *(undefined4 *)(&stack0x0000005c + lVar17) = 1;
    }
    else if (iVar14 == 3) {
      pbVar44 = *(byte **)(lVar20 + 0x228);
      *(undefined4 *)(&stack0x0000009c + lVar17) = 0;
      *(undefined8 *)(&stack0x000000b6 + lVar17) = 0;
      *(undefined8 *)(&stack0x000000c0 + lVar17) = 0;
      *(undefined8 *)(&stack0x000000a8 + lVar17) = 0;
      bVar9 = *pbVar44;
      *(byte **)(&stack0x000000a0 + lVar17) = pbVar44;
      if ((bVar9 & 1) != 0) {
        *(undefined2 *)(&stack0x00000098 + lVar17) = 1;
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar44 & 0x1c) + 0x10418c) *
                                4 + 0x10417c) - 0x1cb3c00);
                    /* WARNING: Could not emulate address calculation at 0x00102d70 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return;
      }
      *(undefined2 *)(&stack0x00000098 + lVar17) = 0;
      *(undefined4 *)(&stack0x000000be + lVar17) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00102f1a */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar44 & 0xe) * 4 + 0x1041ac) - 0x1cb3c00))
                ();
      return;
    }
  }
  uVar32 = *(uint *)(lVar20 + 0x518);
  uVar13 = *(undefined4 *)(lVar20 + 0x51c);
  puVar3 = *(undefined8 **)(lVar20 + 0x178);
  if ((uVar32 < *(uint *)(*(longlong *)(lVar20 + 0x188) + 0xb4)) &&
     ((((byte)*(undefined4 *)(puVar3 + 0x43) & 5) != 1 || ((*(byte *)(puVar3 + 0x5b) & 2) == 0)))) {
    UNRECOVERED_JUMPTABLE = *(code **)*puVar3;
    *(undefined8 *)(puVar40 + -8) = 0x103053;
    cVar8 = (*UNRECOVERED_JUMPTABLE)();
    if (cVar8 == '\0') {
      *(undefined4 *)(puVar40 + 0x28) = uVar13;
      *(uint *)(puVar40 + 0x20) = uVar32;
      *(undefined8 *)(puVar40 + -8) = 0x10307b;
      func_0x(lVar20 + 0x180,0,psVar4,lVar20 + 0x298);
    }
  }
  puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
  iVar14 = *(int *)(**(longlong **)(*(longlong *)(lVar20 + 0x188) + 0x160) + 0x1c);
  iVar42 = iVar14 + -1;
  if ((*(byte *)(*(longlong *)(lVar20 + 0x188) + 0x106) & 0x40) == 0) {
    iVar42 = iVar14;
  }
  lVar41 = *(longlong *)(&stack0x00000068 + lVar17);
  ppuVar56 = (uint **)(lVar20 + 0x268);
  sVar10 = *psVar4;
  puVar54 = (undefined2 *)(lVar41 + 0x272);
  *(uint **)(lVar41 + 0x260) = puVar46;
  if (sVar10 == 0) {
    if (*(int *)((longlong)&sStackX_18 + lVar17 + 4) == 0) {
      uVar32 = *(uint *)(&stack0x00000028 + lVar17);
      *(undefined2 *)((longlong)&sStackX_18 + lVar17 + 2) = 0;
      *(uint *)(&stack0x0000002c + lVar17) = uVar32;
      if ((*(byte *)puVar46 & 0x10) != 0) {
        uVar32 = uVar32 + 2 + (*(ushort *)((ulonglong)uVar32 + (longlong)puVar46) + 7 >> 3);
        *(uint *)(&stack0x0000002c + lVar17) = uVar32;
      }
      if ((*(byte *)puVar46 & 0x20) == 0) {
        *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar32;
        *(undefined2 *)(&stack0x00000034 + lVar17) = 0;
        *(uint *)(&stack0x00000030 + lVar17) = uVar32;
      }
      else {
        psVar47 = (short *)((ulonglong)uVar32 + (longlong)puVar46);
        sVar10 = *psVar47;
        *(short *)(&stack0x00000034 + lVar17) = sVar10;
        if (sVar10 == 0) {
          if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
            lVar20 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_);
            if ((lVar20 != 0) &&
               ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                (*(char *)(lVar20 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar40 + -8) = 0x1031a5;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar40 + 0x20) = 0;
                *(undefined8 *)(puVar40 + -8) = 0x1031c8;
                (*_DAT_)(1,0xa89748,0xba9418,0x80f);
              }
            }
            puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
          }
          *(undefined8 *)(puVar40 + -8) = 0x1031d9;
          func_0x(puVar46,3);
          puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
        }
        uVar32 = *(int *)(&stack0x0000002c + lVar17) +
                 (*(ushort *)(&stack0x00000034 + lVar17) + 1) * 2;
        *(uint *)(&stack0x00000030 + lVar17) = uVar32;
        if (0x1f9e < uVar32) {
          if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
            lVar20 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_);
            if ((lVar20 != 0) &&
               ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                (*(char *)(lVar20 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar40 + -8) = 0x103275;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar40 + 0x20) = 0;
                *(undefined8 *)(puVar40 + -8) = 0x103298;
                (*_DAT_)(1,0xa89748,0xba9418,0x816);
              }
            }
            puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
          }
          *(undefined8 *)(puVar40 + -8) = 0x1032a9;
          func_0x(puVar46,4);
          puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
        }
        uVar27 = psVar47[*(ushort *)(&stack0x00000034 + lVar17)];
        *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar27 & 0x7fff;
        if ((uVar27 & 0x7fff) < *(uint *)(&stack0x00000030 + lVar17)) {
          if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
            lVar20 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_);
            if ((lVar20 != 0) &&
               ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                (*(char *)(lVar20 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar40 + -8) = 0x103344;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar40 + 0x20) = 0;
                *(undefined8 *)(puVar40 + -8) = 0x103369;
                (*_DAT_)(1,0xa89748,0xba9418,0x81d);
              }
            }
            puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
          }
          *(undefined8 *)(puVar40 + -8) = 0x10337a;
          func_0x(puVar46,4);
          puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
        }
        do {
          uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
          if (-1 < psVar47[(ulonglong)(uVar27 - 1) + 1]) break;
          if (uVar27 == 1) {
            uVar32 = *(uint *)(&stack0x00000030 + lVar17);
LAB_:
            if ((*(ushort *)
                  ((longlong)puVar46 +
                  (ulonglong)uVar27 * 2 + (ulonglong)*(uint *)(&stack0x0000002c + lVar17)) & 0x7fff)
                < uVar32) goto LAB_;
          }
          else {
            uVar32 = *(ushort *)
                      ((longlong)puVar46 +
                      (ulonglong)uVar27 * 2 + ((ulonglong)*(uint *)(&stack0x0000002c + lVar17) - 2))
                     & 0x7fff;
            if (*(uint *)(&stack0x00000030 + lVar17) <= uVar32) goto LAB_;
LAB_:
            *(undefined8 *)(puVar40 + -8) = 0x1033d4;
            func_0x(puVar46,7);
            puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
          }
          if ((uVar32 < *(uint *)(&stack0x00000030 + lVar17)) ||
             (*(uint *)((longlong)&sStackX_18 + lVar17 + 4) < uVar32)) goto LAB_;
          if (*(ushort *)((longlong)puVar46 + (ulonglong)uVar32) == 5) {
            puVar45 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
            *puVar45 = *puVar45 | 2;
            *(short *)(&stack0x00000034 + lVar17) = *(short *)(&stack0x00000034 + lVar17) + -1;
            uVar27 = *(ushort *)(&stack0x00000044 + lVar17);
            *(short *)(&stack0x00000042 + lVar17) = (short)uVar32;
            uVar31 = *(ushort *)((ulonglong)(uVar32 & 0xffff) + 2 + (longlong)puVar46);
            if ((uVar31 & 0x4000) == 0) {
              uVar27 = uVar27 & 0xc7ff;
            }
            else {
              uVar27 = uVar27 ^ (uVar31 ^ uVar27) & 0x3800;
            }
            *(ushort *)(&stack0x00000044 + lVar17) = uVar27;
            *(ushort *)(&stack0x00000044 + lVar17) =
                 (uVar27 ^ *(ushort *)((ulonglong)(uVar32 & 0xffff) + 2 + (longlong)puVar46)) &
                 0x7ff ^ uVar27;
            break;
          }
          if (*(ushort *)((longlong)puVar46 + (ulonglong)uVar32) < 0x400) break;
          puVar45 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
          *puVar45 = *puVar45 | 1;
          psVar2 = (short *)(&stack0x00000034 + lVar17);
          *psVar2 = *psVar2 + -1;
        } while (*psVar2 != 0);
      }
      if ((*(byte *)puVar46 & 0x40) == 0) {
        *(undefined4 *)(&stack0x0000003e + lVar17) = 0;
      }
      else {
        uVar13 = *(undefined4 *)((longlong)&sStackX_18 + lVar17 + 4);
        piVar52 = (int *)((longlong)&sStackX_18 + lVar17 + 4);
        *piVar52 = *piVar52 + 0xe;
        *(undefined4 *)(&stack0x0000003e + lVar17) = uVar13;
        *(undefined8 *)(puVar40 + -8) = 0x1034b7;
        puVar25 = (ulonglong *)func_0x((longlong)&sStackX_18 + lVar17 + 2);
        iVar14 = 0;
        uVar34 = *puVar25;
        uVar31 = (ushort)(uVar34 >> 0x30);
        uVar27 = uVar31;
        if ((((uint)(int)(short)uVar31 >> 1 ^ (int)(short)uVar31) & 0x2000) != 0) {
          uVar27 = uVar31 & 0xdfff;
          if ((uVar34 & 0x4000000000000000) != 0) {
            uVar27 = uVar31 | 0x2000;
          }
        }
        if (uVar27 == 0xfffc) {
          iVar14 = (int)((uVar34 >> 0x20 & 0xffff) >> 5);
        }
        piVar52 = (int *)((longlong)&sStackX_18 + lVar17 + 4);
        *piVar52 = *piVar52 + iVar14;
        puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
      }
      if ((*(byte **)(&stack0x00000036 + lVar17) != (byte *)0x0) &&
         (*(byte **)(&stack0x00000036 + lVar17) <
          (byte *)((ulonglong)*(uint *)((longlong)&sStackX_18 + lVar17 + 4) + (longlong)puVar46))) {
        if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
          lVar20 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_);
          if (((lVar20 != 0) && (lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0)) &&
             (*(char *)(lVar20 + 0x499) != '\0')) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar40 + -8) = 0x1035a9;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar40 + 0x20) = 0;
              *(undefined8 *)(puVar40 + -8) = 0x1035cf;
              (*_DAT_)(1,0xa89748,0xba9418,0x877);
            }
          }
          puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
        }
        *(undefined8 *)(puVar40 + -8) = 0x1035e0;
        func_0x(puVar46,0x12);
        puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
      }
      if (0x3f3b < *(int *)((longlong)&sStackX_18 + lVar17 + 4) - 1U) {
        if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
          lVar20 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_);
          if ((lVar20 != 0) &&
             ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
              (*(char *)(lVar20 + 0x499) != '\0')))) {
            if ((DAT_ != '\0') || ((DAT_ & 2) != 0)) {
              *(undefined8 *)(puVar40 + 0x20) = 0;
              *(undefined8 *)(puVar40 + -8) = 0x1036af;
              (*_DAT_)(1,0xa89748,0xba9418,0x87c);
              puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
              goto LAB_;
            }
            *(undefined8 *)(puVar40 + -8) = 0x10366b;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
        }
LAB_:
        *(undefined8 *)(puVar40 + -8) = 0x103681;
        func_0x(puVar46,5);
        puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
      }
LAB_:
      lVar41 = *(longlong *)(&stack0x00000068 + lVar17);
    }
    if (8 < *(uint *)((longlong)&sStackX_18 + lVar17 + 4)) goto LAB_;
    bVar9 = *(byte *)puVar46 & 0xe;
joined_r0x001036f2:
    uVar11 = 9;
    if ((bVar9 != 0) && (uVar11 = 9, bVar9 != 0xc)) goto LAB_;
  }
  else {
    if (*(int *)((longlong)&sStackX_18 + lVar17 + 4) == 0) {
      *(undefined8 *)(puVar40 + -8) = 0x1036de;
      func_0x((longlong)&sStackX_18 + lVar17 + 2);
      puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
      lVar41 = *(longlong *)(&stack0x00000068 + lVar17);
    }
    if (*(uint *)((longlong)&sStackX_18 + lVar17 + 4) < 9) {
      bVar9 = *(byte *)puVar46 & 0x1c;
      goto joined_r0x001036f2;
    }
LAB_:
    uVar11 = (undefined2)*(undefined4 *)((longlong)&sStackX_18 + lVar17 + 4);
  }
  uVar34 = 0;
  *(undefined2 *)(lVar41 + 0x270) = uVar11;
  if ((iVar42 != 0) != 0) {
    do {
      puVar53 = (uint *)0x0;
      lVar20 = **(longlong **)(*(longlong *)(lVar41 + 0x188) + 0x160);
      puVar38 = *(uint **)(lVar20 + 0x38);
      puVar51 = (uint *)(lVar20 + 0x30);
      if (puVar38 == puVar51) {
        puVar38 = puVar53;
      }
      puVar48 = puVar53;
      if (puVar38 != (uint *)0x0) {
        puVar48 = puVar38 + -0x58;
      }
      iVar14 = (int)uVar34;
      if (iVar14 != 0) {
        do {
          puVar38 = *(uint **)(puVar48 + 0x5a);
          if (*(uint **)(puVar48 + 0x5a) == puVar51) {
            puVar38 = puVar53;
          }
          puVar48 = puVar53;
          if (puVar38 != (uint *)0x0) {
            puVar48 = puVar38 + -0x58;
          }
          uVar34 = uVar34 - 1;
        } while (uVar34 != 0);
      }
      bVar9 = *(byte *)(puVar48 + 8);
      if (*psVar4 == 0) {
        uVar32 = *puVar48;
        if ((uVar32 & 0xc0000000) == 0x80000000) {
          *(undefined8 *)(puVar40 + -8) = 0x103fcb;
          iVar15 = func_0x((longlong)&sStackX_18 + lVar17 + 2);
          if (iVar15 == 0) {
LAB_:
            puVar38 = (uint *)0x0;
            *(undefined4 *)(&stack0x00000050 + lVar17) = 0;
          }
          else {
            *(undefined8 *)(puVar40 + -8) = 0x103fea;
            puVar38 = (uint *)func_0x(&stack0x00000042 + lVar17,puVar48,
                                              &stack0x00000050 + lVar17,&stack0x00000168 + lVar17);
          }
          goto LAB_;
        }
        if (((bVar9 & 2) == 0) && ((*(byte *)((longlong)puVar48 + 6) & 0x10) == 0)) {
LAB_:
          if ((int)uVar32 < 0) {
            if (*(int *)((longlong)&sStackX_18 + lVar17 + 4) == 0) {
              uVar32 = *(uint *)(&stack0x00000028 + lVar17);
              *(uint *)(&stack0x0000002c + lVar17) = uVar32;
              *(undefined2 *)((longlong)&sStackX_18 + lVar17 + 2) = 0;
              if ((*(byte *)puVar46 & 0x10) != 0) {
                *(uint *)(&stack0x0000002c + lVar17) =
                     uVar32 + 2 + (*(ushort *)((ulonglong)uVar32 + (longlong)puVar46) + 7 >> 3);
              }
              if ((*(byte *)puVar46 & 0x20) == 0) {
                uVar13 = *(undefined4 *)(&stack0x0000002c + lVar17);
                *(undefined4 *)((longlong)&sStackX_18 + lVar17 + 4) = uVar13;
                *(undefined4 *)(&stack0x00000030 + lVar17) = uVar13;
                *(undefined2 *)(&stack0x00000034 + lVar17) = 0;
              }
              else {
                psVar47 = (short *)((ulonglong)*(uint *)(&stack0x0000002c + lVar17) +
                                   (longlong)puVar46);
                sVar10 = *psVar47;
                *(short *)(&stack0x00000034 + lVar17) = sVar10;
                if (sVar10 == 0) {
                  if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                    lVar20 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_);
                    if ((lVar20 != 0) &&
                       ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                        (*(char *)(lVar20 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar40 + -8) = 0x1039e4;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x103a09;
                        (*_DAT_)(1,0xa89748,0xba9418,0x80f);
                      }
                    }
                    puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                  }
                  *(undefined8 *)(puVar40 + -8) = 0x103a1a;
                  func_0x(puVar46,3);
                  puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                }
                uVar32 = *(int *)(&stack0x0000002c + lVar17) +
                         (*(ushort *)(&stack0x00000034 + lVar17) + 1) * 2;
                *(uint *)(&stack0x00000030 + lVar17) = uVar32;
                if (0x1f9e < uVar32) {
                  if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                    lVar20 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_);
                    if ((lVar20 != 0) &&
                       ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                        (*(char *)(lVar20 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar40 + -8) = 0x103ab4;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x103ad9;
                        (*_DAT_)(1,0xa89748,0xba9418,0x816);
                      }
                    }
                    puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                  }
                  *(undefined8 *)(puVar40 + -8) = 0x103aea;
                  func_0x(puVar46,4);
                  puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                }
                uVar27 = psVar47[*(ushort *)(&stack0x00000034 + lVar17)];
                *(uint *)((longlong)&sStackX_18 + lVar17 + 4) = uVar27 & 0x7fff;
                if ((uVar27 & 0x7fff) < *(uint *)(&stack0x00000030 + lVar17)) {
                  if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                    lVar20 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_);
                    if ((lVar20 != 0) &&
                       ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                        (*(char *)(lVar20 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar40 + -8) = 0x103b86;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x103bab;
                        (*_DAT_)(1,0xa89748,0xba9418,0x81d);
                      }
                    }
                    puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                  }
                  *(undefined8 *)(puVar40 + -8) = 0x103bbc;
                  func_0x(puVar46,4);
                  puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                }
                do {
                  uVar27 = *(ushort *)(&stack0x00000034 + lVar17);
                  if (-1 < psVar47[(ulonglong)(uVar27 - 1) + 1]) break;
                  if (uVar27 == 1) {
                    uVar32 = *(uint *)(&stack0x00000030 + lVar17);
LAB_:
                    if ((*(ushort *)
                          ((longlong)puVar46 +
                          (ulonglong)uVar27 * 2 + (ulonglong)*(uint *)(&stack0x0000002c + lVar17)) &
                        0x7fff) < uVar32) goto LAB_;
                  }
                  else {
                    uVar32 = *(ushort *)
                              ((longlong)puVar46 +
                              (ulonglong)uVar27 * 2 +
                              ((ulonglong)*(uint *)(&stack0x0000002c + lVar17) - 2)) & 0x7fff;
                    if (*(uint *)(&stack0x00000030 + lVar17) <= uVar32) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar40 + -8) = 0x103c14;
                    func_0x(puVar46,7);
                    puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                  }
                  if ((uVar32 < *(uint *)(&stack0x00000030 + lVar17)) ||
                     (*(uint *)((longlong)&sStackX_18 + lVar17 + 4) < uVar32)) goto LAB_;
                  if (*(ushort *)((longlong)puVar46 + (ulonglong)uVar32) == 5) {
                    puVar45 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                    *puVar45 = *puVar45 | 2;
                    *(short *)(&stack0x00000034 + lVar17) =
                         *(short *)(&stack0x00000034 + lVar17) + -1;
                    uVar27 = *(ushort *)(&stack0x00000044 + lVar17);
                    *(short *)(&stack0x00000042 + lVar17) = (short)uVar32;
                    uVar31 = *(ushort *)((ulonglong)(uVar32 & 0xffff) + 2 + (longlong)puVar46);
                    if ((uVar31 & 0x4000) == 0) {
                      uVar27 = uVar27 & 0xc7ff;
                    }
                    else {
                      uVar27 = uVar27 ^ (uVar27 ^ uVar31) & 0x3800;
                    }
                    *(ushort *)(&stack0x00000044 + lVar17) = uVar27;
                    *(ushort *)(&stack0x00000044 + lVar17) =
                         uVar27 ^ (uVar27 ^ *(ushort *)
                                             ((ulonglong)(uVar32 & 0xffff) + 2 + (longlong)puVar46))
                                  & 0x7ff;
                    break;
                  }
                  if (*(ushort *)((longlong)puVar46 + (ulonglong)uVar32) < 0x400) break;
                  puVar45 = (ushort *)((longlong)&sStackX_18 + lVar17 + 2);
                  *puVar45 = *puVar45 | 1;
                  psVar2 = (short *)(&stack0x00000034 + lVar17);
                  *psVar2 = *psVar2 + -1;
                } while (*psVar2 != 0);
              }
              if ((*(byte *)puVar46 & 0x40) == 0) {
                *(undefined4 *)(&stack0x0000003e + lVar17) = 0;
              }
              else {
                uVar13 = *(undefined4 *)((longlong)&sStackX_18 + lVar17 + 4);
                piVar52 = (int *)((longlong)&sStackX_18 + lVar17 + 4);
                *piVar52 = *piVar52 + 0xe;
                *(undefined4 *)(&stack0x0000003e + lVar17) = uVar13;
                *(undefined8 *)(puVar40 + -8) = 0x103cf9;
                puVar25 = (ulonglong *)func_0x((longlong)&sStackX_18 + lVar17 + 2);
                iVar15 = 0;
                uVar34 = *puVar25;
                uVar31 = (ushort)(uVar34 >> 0x30);
                uVar27 = uVar31;
                if ((((uint)(int)(short)uVar31 >> 1 ^ (int)(short)uVar31) & 0x2000) != 0) {
                  uVar27 = uVar31 & 0xdfff;
                  if ((uVar34 & 0x4000000000000000) != 0) {
                    uVar27 = uVar31 | 0x2000;
                  }
                }
                if (uVar27 == 0xfffc) {
                  iVar15 = (int)((uVar34 >> 0x20 & 0xffff) >> 5);
                }
                piVar52 = (int *)((longlong)&sStackX_18 + lVar17 + 4);
                *piVar52 = *piVar52 + iVar15;
                puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
              }
              if ((*(byte **)(&stack0x00000036 + lVar17) != (byte *)0x0) &&
                 (*(byte **)(&stack0x00000036 + lVar17) <
                  (byte *)((ulonglong)*(uint *)((longlong)&sStackX_18 + lVar17 + 4) +
                          (longlong)puVar46))) {
                if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                  lVar20 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_);
                  if (((lVar20 != 0) && (lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0)) &&
                     (*(char *)(lVar20 + 0x499) != '\0')) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar40 + -8) = 0x103df2;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x103e18;
                      (*_DAT_)(1,0xa89748,0xba9418,0x877);
                    }
                  }
                  puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                }
                *(undefined8 *)(puVar40 + -8) = 0x103e29;
                func_0x(puVar46,0x12);
                puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
              }
              if (0x3f3b < *(int *)((longlong)&sStackX_18 + lVar17 + 4) - 1U) {
                if ((DAT_ != '\0') || ((DAT_ & 1) != 0)) {
                  lVar20 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_);
                  if ((lVar20 != 0) &&
                     ((lVar20 = *(longlong *)(lVar20 + 0x60), lVar20 != 0 &&
                      (*(char *)(lVar20 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar40 + -8) = 0x103eb8;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x103ede;
                      (*_DAT_)(1,0xa89748,0xba9418,0x87c);
                    }
                  }
                  puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                }
                *(undefined8 *)(puVar40 + -8) = 0x103eef;
                func_0x(puVar46,5);
                puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
              }
            }
LAB_:
            sVar10 = -*(short *)puVar48;
            if ((*(byte *)((longlong)puVar48 + 6) & 0x10) != 0) {
              if ((*(byte *)puVar46 & 0x10) == 0) {
                if ((1 << (*(byte *)puVar46 & 0xe) & 0x1105U) != 0) {
LAB_:
                  puVar38 = *(undefined4 **)(puVar48 + 2) + 1;
                  *(undefined4 *)(&stack0x00000050 + lVar17) = **(undefined4 **)(puVar48 + 2);
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(&stack0x00000028 + lVar17) <= (int)*puVar48) ||
                      (*(ushort *)
                        ((ulonglong)*(uint *)(&stack0x00000028 + lVar17) + (longlong)puVar46) <
                       *(ushort *)(puVar48 + 1))) goto LAB_;
            }
            if ((uint)*(ushort *)(&stack0x00000034 + lVar17) < (uint)(int)sVar10) {
              *(undefined4 *)(&stack0x00000050 + lVar17) = 0;
              puVar38 = puVar46;
            }
            else {
              if (sVar10 == 1) {
                uVar32 = *(uint *)(&stack0x00000030 + lVar17);
              }
              else {
                uVar32 = *(ushort *)
                          ((longlong)puVar46 +
                          (longlong)sVar10 * 2 +
                          ((ulonglong)*(uint *)(&stack0x0000002c + lVar17) - 2)) & 0x7fff;
              }
              uVar43 = *(ushort *)
                        ((longlong)puVar46 +
                        (longlong)sVar10 * 2 + (ulonglong)*(uint *)(&stack0x0000002c + lVar17)) &
                       0x7fff;
              if ((uVar32 < *(uint *)(&stack0x00000030 + lVar17)) || (uVar43 < uVar32)) {
                *(undefined8 *)(puVar40 + -8) = 0x103f98;
                func_0x(puVar46,7);
                puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
              }
              *(uint *)(&stack0x00000050 + lVar17) = uVar43 - uVar32;
              puVar38 = (uint *)((ulonglong)uVar32 + (longlong)puVar46);
            }
          }
          else {
            uVar27 = *(ushort *)((longlong)puVar48 + 6);
            if ((uVar27 & 8) == 0) {
              uVar43 = (uint)*(ushort *)(puVar48 + 0xe);
              if ((uVar27 & 0x10) != 0) {
                if ((*(byte *)puVar46 & 0x10) == 0) {
                  if ((1 << (*(byte *)puVar46 & 0xe) & 0x1105U) != 0) {
LAB_:
                    puVar38 = *(uint **)(puVar48 + 2);
                    uVar32 = *puVar38;
                    if ((uVar43 != 0) && (uVar32 != uVar43)) {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x1038e8;
                      (*_DAT_)(1,0xc374b8,0xc35eb8,0x381);
                      puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
                    }
                    *(uint *)(&stack0x00000050 + lVar17) = uVar32;
                    puVar38 = puVar38 + 1;
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(&stack0x00000028 + lVar17) <= (int)uVar32) ||
                        (*(ushort *)
                          ((ulonglong)*(uint *)(&stack0x00000028 + lVar17) + (longlong)puVar46) <
                         *(ushort *)(puVar48 + 1))) goto LAB_;
              }
              *(uint *)(&stack0x00000050 + lVar17) = uVar43;
              puVar38 = (uint *)((longlong)(int)*puVar48 + (longlong)puVar46);
            }
            else {
              bVar9 = *(byte *)((longlong)puVar46 + (longlong)(int)uVar32);
              *(undefined4 *)(&stack0x00000050 + lVar17) = 1;
              puVar38 = (uint *)0x80e184;
              if ((bVar9 & (byte)(1 << ((byte)uVar27 & 7))) == 0) {
                puVar38 = (uint *)0x80e7a8;
              }
            }
          }
        }
        else if ((*(byte *)puVar46 & 0x10) == 0) {
          if ((1 << (*(byte *)puVar46 & 0xe) & 0x1105U) != 0) goto LAB_;
          uVar27 = 0;
          bVar7 = true;
LAB_:
          if ((bVar9 & 2) != 0) goto LAB_;
LAB_:
          if ((bVar7) || ((*(byte *)((longlong)puVar48 + 6) & 0x10) == 0)) goto LAB_;
          puVar21 = *(undefined4 **)(puVar48 + 2);
          *(undefined4 *)(&stack0x00000050 + lVar17) = *puVar21;
          puVar38 = puVar21 + 1;
        }
        else {
          if (*(int *)(&stack0x00000028 + lVar17) <= (int)uVar32) {
LAB_:
            uVar27 = ~(*(ushort *)((longlong)puVar48 + 6) >> 4) & 1;
            bVar7 = false;
            goto LAB_;
          }
          if ((uint)*(ushort *)((ulonglong)*(uint *)(&stack0x00000028 + lVar17) + (longlong)puVar46)
              < (uint)*(ushort *)(puVar48 + 1)) goto LAB_;
          if ((bVar9 & 2) == 0) goto LAB_;
          uVar43 = *(ushort *)(puVar48 + 1) - 1;
          bVar7 = true;
          uVar27 = *(byte *)((longlong)puVar46 +
                            (ulonglong)*(uint *)(&stack0x00000028 + lVar17) +
                            (ulonglong)(uVar43 >> 3) + 2) >> ((byte)uVar43 & 7) & 1;
LAB_:
          if (uVar27 == 0) goto LAB_;
          *(undefined4 *)(&stack0x00000050 + lVar17) = 0;
          puVar38 = (uint *)0x0;
        }
      }
      else {
        *(undefined4 *)(&stack0x00000148 + lVar17) = 0;
        *(undefined **)(puVar40 + 0x20) = &stack0x00000148 + lVar17;
        *(undefined8 *)(puVar40 + -8) = 0x104013;
        puVar38 = (uint *)func_0x((longlong)&sStackX_18 + lVar17 + 2,puVar48,puVar51,
                                          &stack0x00000050 + lVar17);
        if ((((*psVar4 != 0) &&
             (plVar6 = *(longlong **)(&stack0x00000028 + lVar17), plVar6 != (longlong *)0x0)) &&
            (*plVar6 != 0)) &&
           (((*(byte *)((longlong)puVar48 + 6) & 8) == 0 &&
            ((*(uint *)(&stack0x00000148 + lVar17) & 1) == 0)))) {
          if ((puVar38 == (uint *)0x0) || (puVar38 == (uint *)0x80e184)) goto LAB_;
          uVar13 = *(undefined4 *)(&stack0x00000050 + lVar17);
          *(uint *)(puVar40 + 0x38) = *(uint *)(&stack0x00000148 + lVar17);
          *(undefined **)(puVar40 + 0x30) = &stack0x00000050 + lVar17;
          *(undefined4 *)(puVar40 + 0x28) = 0;
          *(undefined8 *)(puVar40 + 0x20) = 0;
          *(undefined8 *)(puVar40 + -8) = 0x10406d;
          puVar38 = (uint *)func_0x(plVar6,puVar48,puVar38,uVar13);
        }
LAB_:
        puVar46 = *(uint **)((longlong)&puStackX_20 + lVar17);
      }
LAB_:
      uVar11 = *(undefined2 *)(&stack0x00000050 + lVar17);
      uVar32 = iVar14 + 1;
      uVar34 = (ulonglong)uVar32;
      lVar41 = *(longlong *)(&stack0x00000068 + lVar17);
      *ppuVar56 = puVar38;
      ppuVar56 = ppuVar56 + 1;
      *puVar54 = uVar11;
      puVar54 = puVar54 + 1;
    } while (uVar32 < (iVar42 != 0));
  }
  lVar20 = *(longlong *)(&stack0x00000068 + lVar17);
  lVar41 = *(longlong *)(&stack0x00000078 + lVar17);
  iVar14 = *(int *)(&stack0x0000005c + lVar17);
  *(short *)(lVar20 + 0x276) = (short)iVar14;
  bVar9 = *(byte *)(lVar41 + 0x106) & 0x40;
  if ((bVar9 == 0) && ((*(byte *)(lVar41 + 0x108) & 8) == 0)) {
    uVar24 = *(undefined8 *)(&stack0x00000060 + lVar17);
    uVar13 = (undefined4)uVar24;
LAB_:
    if ((*(byte *)(lVar41 + 0x108) & 8) != 0) goto LAB_;
LAB_:
    uVar16 = 0;
  }
  else {
    if (iVar14 == 0) {
      uVar24 = *(undefined8 *)(&stack0x00000060 + lVar17);
      uVar13 = (undefined4)uVar24;
    }
    else {
      uVar24 = *(undefined8 *)(lVar20 + 0x230);
      uVar13 = *(undefined4 *)(lVar20 + 0x238);
    }
    if (bVar9 == 0) goto LAB_;
LAB_:
    if (iVar14 == 0) goto LAB_;
    uVar16 = 1;
  }
  uVar23 = *(undefined8 *)(lVar20 + 0x200);
  *(undefined4 *)(puVar40 + 0x28) = uVar13;
  *(undefined8 *)(puVar40 + 0x20) = uVar24;
  *(undefined8 *)(puVar40 + -8) = 0x104135;
  func_0x(uVar23,lVar20 + 600,&stack0x00000230 + lVar17,uVar16);
LAB_:
  *(longlong *)(lVar20 + 0x240) = *(longlong *)(lVar20 + 0x240) + 1;
  if (*(longlong **)(&stack0x000001e0 + lVar17) != (longlong *)0x0) {
    **(longlong **)(&stack0x000001e0 + lVar17) = lVar20 + 0x38;
  }
  uVar34 = *(ulonglong *)(&stack0x00005768 + lVar17);
  *(undefined8 *)(puVar40 + -8) = 0x104160;
  func_0x(uVar34 ^ (ulonglong)psVar4);
  return;
}

