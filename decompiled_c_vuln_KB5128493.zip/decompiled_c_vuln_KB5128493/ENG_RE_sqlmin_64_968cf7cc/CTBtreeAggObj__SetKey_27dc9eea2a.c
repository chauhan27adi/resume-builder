
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  ushort uVar1;
  ulonglong *puVar2;
  undefined4 *puVar3;
  int iVar4;
  ulonglong uVar5;
  byte bVar6;
  ushort uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  ulonglong uVar11;
  ushort *puVar12;
  longlong lVar13;
  byte *pbVar14;
  longlong unaff_GS_OFFSET;
  
  iVar4 = 0;
  if (param_2 == (short *)0x0) {
    *(undefined *)(param_1 + 0x6e) = 0;
    *(undefined2 *)(param_1 + 0x50) = 0xad8;
    *(undefined4 *)(param_1 + 0x68) = 0;
    return;
  }
  *(undefined *)(param_1 + 0x6e) = 1;
  if (*param_2 == 0) {
    if (*(int *)(param_2 + 2) == 0) {
      pbVar14 = *(byte **)(param_2 + 4);
      param_2[1] = 0;
      uVar8 = *(uint *)(param_2 + 8);
      uVar11 = (ulonglong)uVar8;
      *(uint *)(param_2 + 10) = uVar8;
      bVar6 = *pbVar14;
      if ((bVar6 & 0x10) != 0) {
        uVar8 = uVar8 + 2 + (*(ushort *)(pbVar14 + uVar11) + 7 >> 3);
        uVar11 = (ulonglong)uVar8;
        *(uint *)(param_2 + 10) = uVar8;
        bVar6 = *pbVar14;
      }
      if ((bVar6 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar11;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar11;
      }
      else {
        puVar12 = (ushort *)(pbVar14 + uVar11);
        uVar1 = *puVar12;
        param_2[0xe] = uVar1;
        if (uVar1 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0)) &&
             ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
              (*(char *)(lVar13 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xdaf728,0xecf3f8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar11 = (ulonglong)*(uint *)(param_2 + 10);
          uVar1 = param_2[0xe];
        }
        uVar8 = (int)uVar11 + (uVar1 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar8;
        if (0x1f9e < uVar8) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0 &&
              ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
               (*(char *)(lVar13 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdaf728,0xecf3f8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar1 = param_2[0xe];
          uVar8 = *(uint *)(param_2 + 0xc);
        }
        uVar5 = (ulonglong)uVar1;
        uVar9 = puVar12[uVar5] & 0x7fff;
        *(uint *)(param_2 + 2) = uVar9;
        if (uVar9 < uVar8) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0)) &&
             ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
              (*(char *)(lVar13 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdaf728,0xecf3f8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar5 = (ulonglong)(ushort)param_2[0xe];
          uVar9 = *(uint *)(param_2 + 2);
        }
        uVar11 = (ulonglong)uVar9;
        if ((short)puVar12[(ulonglong)((int)uVar5 - 1) + 1] < 0) {
          pbVar14 = *(byte **)(param_2 + 4);
          do {
            if ((int)uVar5 == 1) {
              uVar8 = *(uint *)(param_2 + 0xc);
              uVar9 = uVar8;
LAB_:
              if ((*(ushort *)(pbVar14 + uVar5 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff) <
                  uVar8) goto LAB_;
            }
            else {
              uVar9 = *(uint *)(param_2 + 0xc);
              uVar8 = *(ushort *)(pbVar14 + uVar5 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                      0x7fff;
              if (uVar9 <= uVar8) goto LAB_;
LAB_:
              func_0x(pbVar14,7);
              uVar9 = *(uint *)(param_2 + 0xc);
            }
            if ((uVar8 < uVar9) ||
               (uVar11 = (ulonglong)*(uint *)(param_2 + 2), *(uint *)(param_2 + 2) < uVar8))
            goto LAB_;
            pbVar14 = *(byte **)(param_2 + 4);
            if (*(ushort *)(pbVar14 + uVar8) == 5) {
              param_2[1] = param_2[1] | 2;
              param_2[0xe] = param_2[0xe] + -1;
              param_2[0x15] = (short)uVar8;
              lVar13 = (ulonglong)(uVar8 & 0xffff) + *(longlong *)(param_2 + 4);
              uVar1 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar13 + 2) >> 0xe & 1) != 0) {
                uVar1 = *(ushort *)(lVar13 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar1;
              param_2[0x16] = (uVar1 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar1;
              uVar11 = (ulonglong)*(uint *)(param_2 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar14 + uVar8) < 0x400) goto LAB_;
            param_2[1] = param_2[1] | 1;
            uVar1 = param_2[0xe] - 1;
            param_2[0xe] = uVar1;
            if (uVar1 == 0) goto LAB_;
            uVar5 = (ulonglong)uVar1;
          } while ((short)puVar12[(ulonglong)(uVar1 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar14 = *(byte **)(param_2 + 4);
        }
      }
      if ((*pbVar14 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar11;
        *(int *)(param_2 + 2) = (int)uVar11 + 0xe;
        puVar2 = (ulonglong *)func_0x(param_2 + 1);
        uVar7 = (ushort)(*puVar2 >> 0x30);
        uVar1 = uVar7;
        if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
          uVar1 = uVar7 & 0xdfff;
          if ((uVar7 >> 0xe & 1) != 0) {
            uVar1 = uVar7 | 0x2000;
          }
        }
        if (uVar1 == 0xfffc) {
          iVar4 = (int)((*puVar2 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar4;
        uVar11 = (ulonglong)*(uint *)(param_2 + 2);
      }
      iVar4 = (int)uVar11;
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar11 + *(longlong *)(param_2 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar13 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar13 != 0 &&
             (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
            (*(char *)(lVar13 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xdaf728,0xecf3f8,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        iVar4 = *(int *)(param_2 + 2);
      }
      if (0x3f3b < iVar4 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar13 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar13 != 0 &&
            ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
             (*(char *)(lVar13 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0xdaf728,0xecf3f8,0x87c,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
      }
    }
LAB_:
    uVar8 = *(uint *)(param_2 + 2);
    if (uVar8 < 9) {
      bVar6 = **(byte **)(param_2 + 4) & 0xe;
joined_r0x001006c0:
      if ((bVar6 == 0) || (bVar6 == 0xc)) {
        uVar8 = 9;
      }
    }
  }
  else {
    uVar8 = *(uint *)(param_2 + 2);
    if (uVar8 == 0) {
      func_0x(param_2 + 1);
      uVar8 = *(uint *)(param_2 + 2);
    }
    if (uVar8 < 9) {
      bVar6 = **(byte **)(param_2 + 4) & 0x1c;
      goto joined_r0x001006c0;
    }
  }
  uVar9 = 9;
  *(short *)(param_1 + 0x50) = (short)uVar8 + 0xad8;
  if (*param_2 == 0) {
    iVar4 = *(int *)(param_2 + 8);
  }
  else if ((**(byte **)(param_2 + 4) & 0x1c) == 4) {
    iVar4 = 1;
  }
  else if ((**(byte **)(param_2 + 4) & 0x1c) == 0x10) {
    iVar4 = 9;
  }
  else {
    iVar4 = (uint)(ushort)param_2[0xe] + (uint)(ushort)param_2[0xd];
  }
  *(int *)(param_1 + 0x68) = iVar4;
  if (*param_2 == 0) {
    if (*(int *)(param_2 + 2) == 0) {
      pbVar14 = *(byte **)(param_2 + 4);
      uVar8 = *(uint *)(param_2 + 8);
      uVar11 = (ulonglong)uVar8;
      param_2[1] = 0;
      *(uint *)(param_2 + 10) = uVar8;
      bVar6 = *pbVar14;
      if ((bVar6 & 0x10) != 0) {
        uVar8 = uVar8 + 2 + (*(ushort *)(pbVar14 + uVar11) + 7 >> 3);
        uVar11 = (ulonglong)uVar8;
        *(uint *)(param_2 + 10) = uVar8;
        bVar6 = *pbVar14;
      }
      if ((bVar6 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar11;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar11;
      }
      else {
        puVar12 = (ushort *)(pbVar14 + uVar11);
        uVar1 = *puVar12;
        param_2[0xe] = uVar1;
        if (uVar1 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0)) &&
             ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
              (*(char *)(lVar13 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xdaf728,0xecf3f8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar11 = (ulonglong)*(uint *)(param_2 + 10);
          uVar1 = param_2[0xe];
        }
        uVar8 = (int)uVar11 + (uVar1 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar8;
        if (0x1f9e < uVar8) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0 &&
              ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
               (*(char *)(lVar13 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdaf728,0xecf3f8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar1 = param_2[0xe];
          uVar8 = *(uint *)(param_2 + 0xc);
        }
        uVar5 = (ulonglong)uVar1;
        uVar10 = puVar12[uVar5] & 0x7fff;
        *(uint *)(param_2 + 2) = uVar10;
        if (uVar10 < uVar8) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar13 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar13 != 0)) &&
             ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
              (*(char *)(lVar13 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdaf728,0xecf3f8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar5 = (ulonglong)(ushort)param_2[0xe];
          uVar10 = *(uint *)(param_2 + 2);
        }
        uVar11 = (ulonglong)uVar10;
        if ((short)puVar12[(ulonglong)((int)uVar5 - 1) + 1] < 0) {
          lVar13 = *(longlong *)(param_2 + 4);
          do {
            if ((int)uVar5 == 1) {
              uVar8 = *(uint *)(param_2 + 0xc);
              uVar10 = uVar8;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar13 + uVar5 * 2) & 0x7fff) <
                  uVar8) goto LAB_;
            }
            else {
              uVar10 = *(uint *)(param_2 + 0xc);
              uVar8 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar13 + -2 + uVar5 * 2) &
                      0x7fff;
              if (uVar10 <= uVar8) goto LAB_;
LAB_:
              func_0x(lVar13,7);
              uVar10 = *(uint *)(param_2 + 0xc);
            }
            if ((uVar8 < uVar10) ||
               (uVar11 = (ulonglong)*(uint *)(param_2 + 2), *(uint *)(param_2 + 2) < uVar8))
            goto LAB_;
            lVar13 = *(longlong *)(param_2 + 4);
            if (*(ushort *)((ulonglong)uVar8 + lVar13) == 5) {
              param_2[1] = param_2[1] | 2;
              param_2[0xe] = param_2[0xe] + -1;
              param_2[0x15] = (short)uVar8;
              lVar13 = (ulonglong)(uVar8 & 0xffff) + *(longlong *)(param_2 + 4);
              uVar1 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar13 + 2) & 0x4000) != 0) {
                uVar1 = *(ushort *)(lVar13 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar1;
              param_2[0x16] = (uVar1 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar1;
              uVar11 = (ulonglong)*(uint *)(param_2 + 2);
              pbVar14 = *(byte **)(param_2 + 4);
              goto LAB_;
            }
            if (*(ushort *)((ulonglong)uVar8 + lVar13) < 0x400) break;
            param_2[1] = param_2[1] | 1;
            uVar1 = param_2[0xe] - 1;
            param_2[0xe] = uVar1;
            if ((uVar1 == 0) ||
               (uVar5 = (ulonglong)uVar1, -1 < (short)puVar12[(ulonglong)(uVar1 - 1) + 1])) break;
          } while( true );
        }
        pbVar14 = *(byte **)(param_2 + 4);
      }
LAB_:
      if ((*pbVar14 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar11;
        *(int *)(param_2 + 2) = (int)uVar11 + 0xe;
        puVar2 = (ulonglong *)func_0x(param_2 + 1);
        iVar4 = 0;
        uVar11 = *puVar2;
        uVar7 = (ushort)(uVar11 >> 0x30);
        uVar1 = uVar7;
        if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
          uVar1 = uVar7 & 0xdfff;
          if ((uVar11 & 0x4000000000000000) != 0) {
            uVar1 = uVar7 | 0x2000;
          }
        }
        if (uVar1 == 0xfffc) {
          iVar4 = (int)((uVar11 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar4;
        uVar11 = (ulonglong)*(uint *)(param_2 + 2);
      }
      iVar4 = (int)uVar11;
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar11 + *(longlong *)(param_2 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar13 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar13 != 0 &&
             (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
            (*(char *)(lVar13 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xdaf728,0xecf3f8,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        iVar4 = *(int *)(param_2 + 2);
      }
      if (0x3f3b < iVar4 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar13 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar13 != 0 &&
            ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
             (*(char *)(lVar13 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0xdaf728,0xecf3f8,0x87c,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
      }
    }
LAB_:
    if ((8 < *(uint *)(param_2 + 2)) ||
       (((**(byte **)(param_2 + 4) & 0xe) != 0 && ((**(byte **)(param_2 + 4) & 0xe) != 0xc)))) {
      uVar9 = *(uint *)(param_2 + 2);
    }
  }
  else {
    uVar8 = *(uint *)(param_2 + 2);
    if (uVar8 == 0) {
      func_0x(param_2 + 1);
      uVar8 = *(uint *)(param_2 + 2);
    }
    if ((8 < uVar8) ||
       (((**(byte **)(param_2 + 4) & 0x1c) != 0 && ((**(byte **)(param_2 + 4) & 0x1c) != 0xc)))) {
      uVar9 = uVar8;
    }
  }
  lVar13 = *(longlong *)(param_2 + 4);
  param_1 = param_1 + 0x7c;
  if (uVar9 == 0) {
    return;
  }
  if (param_1 != 0) {
    if ((lVar13 != 0) && (uVar9 < 0xa59)) {
      func_0x(param_1,lVar13,uVar9);
      return;
    }
    func_0x(param_1,0,0xa58);
    if (lVar13 != 0) {
      if (uVar9 < 0xa59) {
        return;
      }
      puVar3 = (undefined4 *)(*_DAT_)();
      *puVar3 = 0x22;
      goto LAB_;
    }
  }
  puVar3 = (undefined4 *)(*_DAT_)();
  *puVar3 = 0x16;
LAB_:
  (*_DAT_)();
  return;
}

