
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,short *param_3,undefined4 param_4,
                 undefined4 param_5)

{
  short sVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  short *psVar7;
  char cVar8;
  byte bVar9;
  char cVar10;
  ushort uVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  longlong lVar15;
  longlong lVar16;
  ulonglong *puVar17;
  longlong *plVar18;
  undefined4 *puVar19;
  longlong lVar20;
  undefined8 uVar21;
  undefined4 *puVar22;
  byte bVar23;
  ulonglong uVar24;
  undefined4 *puVar25;
  ushort uVar26;
  uint uVar27;
  uint uVar28;
  longlong lVar29;
  undefined8 unaff_RBX;
  ushort *puVar30;
  short *psVar31;
  ulonglong uVar32;
  byte *pbVar33;
  longlong lVar34;
  longlong unaff_GS_OFFSET;
  longlong alStackX_8 [4];
  int iStack_52e8;
  char cStack_52cf;
  char cStack_52ce;
  longlong lStack_52c8;
  undefined8 uStack_52b8;
  int iStack_52b0;
  short sStack_52ac;
  undefined8 uStack_52a8;
  int iStack_52a0;
  short sStack_529c;
  undefined2 uStack_529a;
  undefined auStack_5298 [4];
  ushort uStack_5294;
  ushort uStack_5292;
  longlong *plStack_5290;
  longlong **pplStack_5288;
  undefined4 uStack_5280;
  uint uStack_5278;
  undefined4 uStack_5274;
  undefined4 uStack_5270;
  undefined4 uStack_526c;
  undefined8 uStack_5268;
  undefined8 uStack_5260;
  short *psStack_5258;
  undefined2 *puStack_5250;
  undefined *puStack_5248;
  undefined4 uStack_5240;
  undefined *puStack_5238;
  short *psStack_5230;
  undefined2 *puStack_5228;
  undefined *puStack_5220;
  undefined4 uStack_5218;
  undefined *puStack_5210;
  uint auStack_5208 [2];
  longlong lStack_5200;
  undefined2 auStack_51f8 [2];
  undefined4 uStack_51f4;
  undefined8 uStack_51f0;
  undefined8 uStack_51e8;
  undefined8 uStack_51da;
  undefined8 uStack_51d0;
  undefined2 auStack_51c0 [2];
  undefined4 uStack_51bc;
  undefined8 uStack_51b8;
  undefined8 uStack_51b0;
  undefined8 uStack_51a2;
  undefined8 uStack_5198;
  undefined8 uStack_5188;
  undefined auStack_5170 [16];
  undefined auStack_5160 [24];
  undefined auStack_5148 [16];
  undefined4 uStack_5138;
  undefined uStack_5128;
  undefined auStack_5118 [36];
  undefined8 uStack_50f4;
  undefined4 uStack_50e4;
  byte bStack_50b8;
  uint uStack_50b0;
  undefined4 uStack_50ac;
  undefined4 uStack_50a8;
  undefined4 uStack_50a4;
  ulonglong auStack_4fb8 [32];
  undefined4 auStack_4eb8 [64];
  undefined4 auStack_4db8 [64];
  undefined4 auStack_4cb8 [64];
  undefined4 auStack_4bb8 [64];
  undefined auStack_4ab8 [8];
  int iStack_4ab0;
  short sStack_4aac;
  undefined auStack_4a98 [14];
  undefined uStack_4a8a;
  undefined8 *puStack_4a88;
  longlong *plStack_4a80;
  undefined4 uStack_4a78;
  undefined4 uStack_4a74;
  undefined4 uStack_4a70;
  undefined4 uStack_4a6c;
  undefined4 uStack_4a68;
  longlong *plStack_4a60;
  undefined uStack_4a58;
  uint uStack_4a54;
  undefined8 uStack_4a40;
  undefined4 uStack_4a1c;
  byte bStack_4a18;
  undefined8 auStack_4a10 [2];
  undefined4 uStack_4a00;
  undefined auStack_49f8 [12];
  undefined4 uStack_49ec;
  byte bStack_49e8;
  undefined8 auStack_49e0 [2];
  undefined4 uStack_49d0;
  int iStack_49c8;
  undefined8 uStack_49c0;
  longlong lStack_49b8;
  undefined2 uStack_49b0;
  undefined4 uStack_49ac;
  undefined8 uStack_49a8;
  undefined8 uStack_49a0;
  undefined8 uStack_4992;
  undefined8 uStack_4988;
  undefined4 uStack_497c;
  undefined2 uStack_4900;
  undefined4 uStack_48fc;
  undefined8 uStack_48f8;
  undefined8 uStack_48f0;
  undefined8 uStack_48e2;
  undefined8 uStack_48d8;
  undefined4 uStack_48cc;
  undefined4 uStack_4848;
  undefined8 uStack_4838;
  undefined8 uStack_4830;
  undefined8 uStack_4828;
  undefined4 uStack_4818;
  undefined2 uStack_4814;
  undefined8 uStack_4812;
  undefined uStack_480a;
  undefined auStack_4808 [16];
  undefined2 uStack_47f8;
  undefined4 uStack_47f4;
  undefined8 uStack_47f0;
  undefined8 uStack_47e8;
  undefined8 uStack_47da;
  undefined8 uStack_47d0;
  undefined8 uStack_47c0;
  undefined8 uStack_47a8;
  undefined4 uStack_47a0;
  undefined2 uStack_4796;
  undefined auStack_4788 [9120];
  undefined auStack_23e8 [9120];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  uStack_5188 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00005340 + lVar15) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15);
  *(undefined4 *)(&stack0x0000003c + lVar15) = param_4;
  plVar18 = *(longlong **)(*(longlong *)(param_1 + 0x28) + 8);
  *(longlong ***)(&stack0x00000040 + lVar15) = &plStack_4a60;
  plStack_4a60 = (longlong *)0x0;
  uStack_4a58 = 0;
  uStack_4a54 = 0;
  uStack_4a40 = 0;
  uStack_4a1c = 0;
  bStack_4a18 = 0;
  auStack_4a10[0] = 0;
  uStack_4a00 = 0;
  uStack_49ec = 0;
  bStack_49e8 = 0;
  auStack_49e0[0] = 0;
  uStack_49d0 = 0;
  iStack_49c8 = 0;
  uStack_49b0 = 0xffff;
  uStack_49a8 = 0;
  uStack_49ac = 0;
  uStack_4992 = 0;
  uStack_4988 = 0;
  uStack_49a0 = 0;
  uStack_497c = 0xffffffff;
  uStack_4900 = 0xffff;
  uStack_48f8 = 0;
  uStack_48fc = 0;
  uStack_48e2 = 0;
  uStack_48d8 = 0;
  uStack_48f0 = 0;
  uStack_48cc = 0xffffffff;
  uStack_4818 = 0;
  uStack_4814 = 0;
  auStack_4808 = ZEXT816(0);
  uStack_47f8 = 0xffff;
  uStack_47f0 = 0;
  uStack_47f4 = 0;
  uStack_47da = 0;
  uStack_47d0 = 0;
  uStack_47e8 = 0;
  uStack_47c0 = 0;
  uStack_47a8 = 0;
  uStack_47a0 = 0;
  uStack_4796 = 0;
  auStack_51f8[0] = 0xffff;
  uStack_51f0 = 0;
  uStack_51f4 = 0;
  uStack_51da = 0;
  uStack_51d0 = 0;
  uStack_51e8 = 0;
  auStack_51c0[0] = 0xffff;
  uStack_51b8 = 0;
  uStack_51bc = 0;
  uStack_51a2 = 0;
  uStack_5198 = 0;
  uStack_51b0 = 0;
  plStack_5290 = plVar18;
  pplStack_5288 = (longlong **)param_1;
  if (*param_3 == 0) {
    if (*(int *)(param_3 + 2) == 0) {
      param_3[1] = 0;
      uVar27 = *(uint *)(param_3 + 8);
      uVar24 = (ulonglong)uVar27;
      *(uint *)(param_3 + 10) = uVar27;
      pbVar33 = *(byte **)(param_3 + 4);
      bVar23 = *pbVar33;
      if ((bVar23 & 0x10) != 0) {
        uVar27 = uVar27 + 2 + (*(ushort *)(pbVar33 + uVar24) + 7 >> 3);
        uVar24 = (ulonglong)uVar27;
        *(uint *)(param_3 + 10) = uVar27;
        bVar23 = *pbVar33;
      }
      if ((bVar23 & 0x20) == 0) {
        *(int *)(param_3 + 2) = (int)uVar24;
        param_3[0xe] = 0;
        *(uint *)(param_3 + 0xc) = uVar27;
      }
      else {
        puVar30 = (ushort *)(pbVar33 + uVar24);
        uVar11 = *puVar30;
        param_3[0xe] = uVar11;
        if (uVar11 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar29 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar29 != 0)) &&
             ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
              (*(char *)(lVar29 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1002b3;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1002d9;
              (*_DAT_)(1,0x185a1d8,0x1979ea8,0x80f);
            }
          }
          uVar21 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1002e7;
          func_0x(uVar21,3);
          uVar11 = param_3[0xe];
          uVar27 = *(uint *)(param_3 + 10);
        }
        uVar27 = uVar27 + (uVar11 + 1) * 2;
        *(uint *)(param_3 + 0xc) = uVar27;
        if (0x1f9e < uVar27) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar29 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar29 != 0 &&
              ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
               (*(char *)(lVar29 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100382;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003a8;
              (*_DAT_)(1,0x185a1d8,0x1979ea8,0x816);
            }
          }
          uVar21 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003b6;
          func_0x(uVar21,4);
          uVar27 = *(uint *)(param_3 + 0xc);
        }
        uVar24 = (ulonglong)(ushort)param_3[0xe];
        uVar11 = puVar30[uVar24];
        *(uint *)(param_3 + 2) = uVar11 & 0x7fff;
        if ((uVar11 & 0x7fff) < uVar27) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar29 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar29 != 0)) &&
             ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
              (*(char *)(lVar29 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10044e;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100474;
              (*_DAT_)(1,0x185a1d8,0x1979ea8,0x81d);
            }
          }
          uVar21 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100482;
          func_0x(uVar21,4);
          uVar24 = (ulonglong)(ushort)param_3[0xe];
        }
        while ((short)puVar30[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
          lVar29 = *(longlong *)(param_3 + 4);
          lVar16 = (ulonglong)*(uint *)(param_3 + 10) + lVar29;
          if ((int)uVar24 == 1) {
            uVar27 = *(uint *)(param_3 + 0xc);
            uVar32 = (ulonglong)uVar27;
            uVar11 = *(ushort *)(lVar16 + uVar24 * 2);
LAB_:
            if ((uVar11 & 0x7fff) < (uint)uVar32) goto LAB_;
          }
          else {
            uVar28 = *(ushort *)(lVar16 + -2 + uVar24 * 2) & 0x7fff;
            uVar32 = (ulonglong)uVar28;
            uVar27 = *(uint *)(param_3 + 0xc);
            uVar11 = *(ushort *)(lVar16 + uVar24 * 2);
            if (uVar27 <= uVar28) goto LAB_;
LAB_:
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1004f0;
            func_0x(lVar29,7);
            uVar27 = *(uint *)(param_3 + 0xc);
          }
          if (((uint)uVar32 < uVar27) || (*(uint *)(param_3 + 2) < (uint)uVar32)) goto LAB_;
          if (*(ushort *)(uVar32 + *(longlong *)(param_3 + 4)) == 5) {
            param_3[1] = param_3[1] | 2;
            param_3[0xe] = param_3[0xe] + -1;
            param_3[0x15] = (short)uVar32;
            lVar29 = (uVar32 & 0xffff) + *(longlong *)(param_3 + 4);
            uVar11 = param_3[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar29 + 2) >> 0xe & 1) != 0) {
              uVar11 = *(ushort *)(lVar29 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
            }
            param_3[0x16] = uVar11;
            param_3[0x16] = (uVar11 ^ *(ushort *)(lVar29 + 2)) & 0x7ff ^ uVar11;
            break;
          }
          if (*(ushort *)(uVar32 + *(longlong *)(param_3 + 4)) < 0x400) break;
          param_3[1] = param_3[1] | 1;
          uVar11 = param_3[0xe] - 1;
          param_3[0xe] = uVar11;
          if (uVar11 == 0) break;
          uVar24 = (ulonglong)uVar11;
        }
        pbVar33 = *(byte **)(param_3 + 4);
      }
      iVar13 = 0;
      if ((*pbVar33 & 0x40) == 0) {
        *(undefined4 *)(param_3 + 0x13) = 0;
      }
      else {
        *(int *)(param_3 + 0x13) = *(int *)(param_3 + 2);
        *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + 0xe;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1005de;
        puVar17 = (ulonglong *)func_0x(param_3 + 1);
        uVar26 = (ushort)(*puVar17 >> 0x30);
        uVar11 = uVar26;
        if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
          uVar11 = uVar26 & 0xdfff;
          if ((uVar26 >> 0xe & 1) != 0) {
            uVar11 = uVar26 | 0x2000;
          }
        }
        if (uVar11 == 0xfffc) {
          iVar13 = (int)((*puVar17 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar13;
      }
      uVar27 = *(uint *)(param_3 + 2);
      if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
         (*(ulonglong *)(param_3 + 0xf) < (ulonglong)uVar27 + *(longlong *)(param_3 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar29 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), lVar29 != 0 && (lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0)) &&
            (*(char *)(lVar29 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1006d1;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1006f7;
            (*_DAT_)(1,0x185a1d8,0x1979ea8,0x877);
          }
        }
        uVar21 = *(undefined8 *)(param_3 + 4);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100705;
        func_0x(uVar21,0x12);
        uVar27 = *(uint *)(param_3 + 2);
      }
      if (0x3f3b < uVar27 - 1) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar29 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar29 != 0 &&
            ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
             (*(char *)(lVar29 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100791;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            uVar21 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10079f;
            func_0x(uVar21,5);
            goto LAB_;
          }
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007c5;
          (*_DAT_)(1,0x185a1d8,0x1979ea8,0x87c);
        }
        uVar21 = *(undefined8 *)(param_3 + 4);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007d3;
        func_0x(uVar21,5);
      }
    }
  }
  else if (*(int *)(param_3 + 2) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007e5;
    func_0x(param_3 + 1);
  }
LAB_:
  iStack_52e8 = 0;
  pcVar4 = *(code **)(*plVar18 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007f6;
  cVar8 = (*pcVar4)(plVar18);
  if (cVar8 == '\0') {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10081e;
    (*_DAT_)(1,0x1a08ee8,0x19de538,0x1376);
  }
  puStack_5250 = auStack_51f8;
  puStack_5248 = auStack_4788;
  uStack_5240 = 0x239e;
  puStack_5238 = auStack_4808;
  *(byte *)(param_1 + 0x531) = *(byte *)(param_1 + 0x531) & 0xfd;
  puStack_5228 = auStack_51c0;
  puStack_5220 = auStack_23e8;
  uStack_5218 = 0x239e;
  puStack_5210 = auStack_4808;
  *(uint *)(param_1 + 0x634) = *(uint *)(param_1 + 0x634) | 1;
  puStack_4a88 = *(undefined8 **)(param_1 + 0x20);
  *(int *)((longlong)puStack_4a88 + 0x44) = *(int *)((longlong)puStack_4a88 + 0x44) + 1;
  uStack_49c0 = 0;
  uStack_4a78 = _DAT_;
  uStack_4a74 = uRam0000000001f7a76c;
  uStack_4a70 = _DAT_;
  uStack_4a6c = uRam0000000001f7a774;
  uStack_4a68 = 0xffffffff;
  uStack_4848 = 0;
  uStack_4830 = 0;
  uStack_4838 = 0;
  uStack_4828 = 0;
  uStack_4818 = 0xffffffff;
  uStack_4814 = 0xffff;
  uStack_4812 = 0;
  uStack_480a = 0;
  plStack_4a80 = *(longlong **)(param_1 + 0x28);
  lStack_49b8 = puStack_4a88[9] + 0x28;
  iStack_49c8 = 2;
  uVar27 = *(uint *)(&stack0x0000003c + lVar15) & 4;
  *(uint *)(&stack0x0000003c + lVar15) = uVar27;
  puVar19 = (undefined4 *)(param_1 + 0x530);
  *(undefined4 **)(&stack0x00000040 + lVar15) = puVar19;
  psStack_5258 = param_2;
  psStack_5230 = param_3;
  do {
    pcVar4 = *(code **)(*plVar18 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100954;
    plVar18 = (longlong *)(*pcVar4)(plVar18);
    if ((uVar27 == 0) && (plVar18 != (longlong *)0x0)) {
      pcVar4 = *(code **)(*plVar18 + 0x88);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10096a;
      cVar8 = (*pcVar4)(plVar18);
      if (cVar8 == '\0') goto LAB_;
      bVar23 = 4;
    }
    else {
LAB_:
      bVar23 = 0;
    }
    *(byte *)(param_1 + 0x531) = *(byte *)(param_1 + 0x531) & 0xfb;
    *(byte *)(param_1 + 0x531) = *(byte *)(param_1 + 0x531) | bVar23;
    lVar29 = 2;
    puVar22 = puVar19;
    puVar17 = auStack_4fb8;
    do {
      uVar3 = puVar22[1];
      uVar5 = puVar22[2];
      uVar6 = puVar22[3];
      *(undefined4 *)puVar17 = *puVar22;
      *(undefined4 *)((longlong)puVar17 + 4) = uVar3;
      *(undefined4 *)(puVar17 + 1) = uVar5;
      *(undefined4 *)((longlong)puVar17 + 0xc) = uVar6;
      uVar3 = puVar22[5];
      uVar5 = puVar22[6];
      uVar6 = puVar22[7];
      *(undefined4 *)(puVar17 + 2) = puVar22[4];
      *(undefined4 *)((longlong)puVar17 + 0x14) = uVar3;
      *(undefined4 *)(puVar17 + 3) = uVar5;
      *(undefined4 *)((longlong)puVar17 + 0x1c) = uVar6;
      uVar3 = puVar22[9];
      uVar5 = puVar22[10];
      uVar6 = puVar22[0xb];
      *(undefined4 *)(puVar17 + 4) = puVar22[8];
      *(undefined4 *)((longlong)puVar17 + 0x24) = uVar3;
      *(undefined4 *)(puVar17 + 5) = uVar5;
      *(undefined4 *)((longlong)puVar17 + 0x2c) = uVar6;
      uVar3 = puVar22[0xd];
      uVar5 = puVar22[0xe];
      uVar6 = puVar22[0xf];
      *(undefined4 *)(puVar17 + 6) = puVar22[0xc];
      *(undefined4 *)((longlong)puVar17 + 0x34) = uVar3;
      *(undefined4 *)(puVar17 + 7) = uVar5;
      *(undefined4 *)((longlong)puVar17 + 0x3c) = uVar6;
      uVar3 = puVar22[0x11];
      uVar5 = puVar22[0x12];
      uVar6 = puVar22[0x13];
      *(undefined4 *)(puVar17 + 8) = puVar22[0x10];
      *(undefined4 *)((longlong)puVar17 + 0x44) = uVar3;
      *(undefined4 *)(puVar17 + 9) = uVar5;
      *(undefined4 *)((longlong)puVar17 + 0x4c) = uVar6;
      uVar3 = puVar22[0x15];
      uVar5 = puVar22[0x16];
      uVar6 = puVar22[0x17];
      *(undefined4 *)(puVar17 + 10) = puVar22[0x14];
      *(undefined4 *)((longlong)puVar17 + 0x54) = uVar3;
      *(undefined4 *)(puVar17 + 0xb) = uVar5;
      *(undefined4 *)((longlong)puVar17 + 0x5c) = uVar6;
      uVar3 = puVar22[0x19];
      uVar5 = puVar22[0x1a];
      uVar6 = puVar22[0x1b];
      *(undefined4 *)(puVar17 + 0xc) = puVar22[0x18];
      *(undefined4 *)((longlong)puVar17 + 100) = uVar3;
      *(undefined4 *)(puVar17 + 0xd) = uVar5;
      *(undefined4 *)((longlong)puVar17 + 0x6c) = uVar6;
      uVar3 = puVar22[0x1d];
      uVar5 = puVar22[0x1e];
      uVar6 = puVar22[0x1f];
      *(undefined4 *)(puVar17 + 0xe) = puVar22[0x1c];
      *(undefined4 *)((longlong)puVar17 + 0x74) = uVar3;
      *(undefined4 *)(puVar17 + 0xf) = uVar5;
      *(undefined4 *)((longlong)puVar17 + 0x7c) = uVar6;
      puVar22 = puVar22 + 0x20;
      lVar29 = lVar29 + -1;
      puVar17 = puVar17 + 0x10;
    } while (lVar29 != 0);
    if (iStack_49c8 != 4) {
      if ((auStack_4fb8[0] >> 8 & 4) == 0) {
        lVar29 = 2;
        puVar22 = (undefined4 *)&bStack_50b8;
        do {
          uVar3 = puVar19[1];
          uVar5 = puVar19[2];
          uVar6 = puVar19[3];
          *puVar22 = *puVar19;
          puVar22[1] = uVar3;
          puVar22[2] = uVar5;
          puVar22[3] = uVar6;
          uVar3 = puVar19[5];
          uVar5 = puVar19[6];
          uVar6 = puVar19[7];
          puVar22[4] = puVar19[4];
          puVar22[5] = uVar3;
          puVar22[6] = uVar5;
          puVar22[7] = uVar6;
          uVar3 = puVar19[9];
          uVar5 = puVar19[10];
          uVar6 = puVar19[0xb];
          puVar22[8] = puVar19[8];
          puVar22[9] = uVar3;
          puVar22[10] = uVar5;
          puVar22[0xb] = uVar6;
          uVar3 = puVar19[0xd];
          uVar5 = puVar19[0xe];
          uVar6 = puVar19[0xf];
          puVar22[0xc] = puVar19[0xc];
          puVar22[0xd] = uVar3;
          puVar22[0xe] = uVar5;
          puVar22[0xf] = uVar6;
          uVar3 = puVar19[0x11];
          uVar5 = puVar19[0x12];
          uVar6 = puVar19[0x13];
          puVar22[0x10] = puVar19[0x10];
          puVar22[0x11] = uVar3;
          puVar22[0x12] = uVar5;
          puVar22[0x13] = uVar6;
          uVar3 = puVar19[0x15];
          uVar5 = puVar19[0x16];
          uVar6 = puVar19[0x17];
          puVar22[0x14] = puVar19[0x14];
          puVar22[0x15] = uVar3;
          puVar22[0x16] = uVar5;
          puVar22[0x17] = uVar6;
          uVar3 = puVar19[0x19];
          uVar5 = puVar19[0x1a];
          uVar6 = puVar19[0x1b];
          puVar22[0x18] = puVar19[0x18];
          puVar22[0x19] = uVar3;
          puVar22[0x1a] = uVar5;
          puVar22[0x1b] = uVar6;
          uVar3 = puVar19[0x1d];
          uVar5 = puVar19[0x1e];
          uVar6 = puVar19[0x1f];
          puVar22[0x1c] = puVar19[0x1c];
          puVar22[0x1d] = uVar3;
          puVar22[0x1e] = uVar5;
          puVar22[0x1f] = uVar6;
          puVar19 = puVar19 + 0x20;
          lVar29 = lVar29 + -1;
          puVar22 = puVar22 + 0x20;
        } while (lVar29 != 0);
        uStack_5138 = 0;
        uStack_5128 = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a8b;
        func_0x(auStack_4ab8);
        uStack_50f4 = 0;
        uStack_50e4 = 0;
        lVar29 = *plStack_4a80;
        lVar16 = *(longlong *)(lVar29 + 8);
        plVar18 = (longlong *)plStack_4a80[1];
        pcVar4 = *(code **)(*plVar18 + 0x58);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100abf;
        (*pcVar4)(plVar18);
        uStack_4a8a = 1;
        uStack_5280 = uStack_5280 & 0xfffffffc;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100ad3;
        func_0x(&uStack_5278);
        uVar27 = uStack_50b0;
        psVar7 = psStack_5258;
        uStack_5278 = uStack_50b0;
        uStack_5274 = uStack_50ac;
        uStack_5270 = uStack_50a8;
        uStack_526c = uStack_50a4;
        bVar23 = bStack_50b8 & 1;
        uStack_5280 = CONCAT31(uStack_5280._1_3_,
                               bStack_50b8 >> 6 & 2 | (byte)uStack_5280 & 0xfc | bVar23);
        if (*psStack_5258 == 0) {
          if (*(int *)(psStack_5258 + 2) == 0) {
            psStack_5258[1] = 0;
            uVar28 = *(uint *)(psStack_5258 + 8);
            uVar24 = (ulonglong)uVar28;
            *(uint *)(psStack_5258 + 10) = uVar28;
            pbVar33 = *(byte **)(psStack_5258 + 4);
            bVar9 = *pbVar33;
            if ((bVar9 & 0x10) != 0) {
              uVar28 = uVar28 + 2 + (*(ushort *)(pbVar33 + uVar24) + 7 >> 3);
              uVar24 = (ulonglong)uVar28;
              *(uint *)(psStack_5258 + 10) = uVar28;
              bVar9 = *pbVar33;
            }
            if ((bVar9 & 0x20) == 0) {
              *(int *)(psStack_5258 + 2) = (int)uVar24;
              psStack_5258[0xe] = 0;
              *(undefined4 *)(psStack_5258 + 0xc) = *(undefined4 *)(psStack_5258 + 10);
            }
            else {
              psVar31 = (short *)(pbVar33 + uVar24);
              sVar1 = *psVar31;
              psStack_5258[0xe] = sVar1;
              if (sVar1 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar34 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0)) &&
                   ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                    (*(char *)(lVar34 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100bf1;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c17;
                    (*_DAT_)(1,0x185a1d8,0x1979ea8,0x80f);
                  }
                }
                uVar21 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c25;
                func_0x(uVar21,3);
              }
              uVar28 = *(int *)(psVar7 + 10) + ((ushort)psVar7[0xe] + 1) * 2;
              *(uint *)(psVar7 + 0xc) = uVar28;
              if (0x1f9e < uVar28) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar34 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0 &&
                    ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                     (*(char *)(lVar34 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100cbd;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100ce3;
                    (*_DAT_)(1,0x185a1d8,0x1979ea8,0x816);
                  }
                }
                uVar21 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100cf1;
                func_0x(uVar21,4);
              }
              uVar11 = psVar31[(ushort)psVar7[0xe]];
              *(uint *)(psVar7 + 2) = uVar11 & 0x7fff;
              if ((uVar11 & 0x7fff) < *(uint *)(psVar7 + 0xc)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar34 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0)) &&
                   ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                    (*(char *)(lVar34 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d88;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100dae;
                    (*_DAT_)(1,0x185a1d8,0x1979ea8,0x81d);
                  }
                }
                uVar21 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100dbc;
                func_0x(uVar21,4);
              }
              uVar11 = psVar7[0xe];
              if (psVar31[(ulonglong)(uVar11 - 1) + 1] < 0) {
                do {
                  uVar24 = (ulonglong)uVar11;
                  lVar34 = *(longlong *)(psVar7 + 4);
                  lVar20 = (ulonglong)*(uint *)(psVar7 + 10) + lVar34;
                  if (uVar11 == 1) {
                    uVar28 = *(uint *)(psVar7 + 0xc);
                    uVar11 = *(ushort *)(lVar20 + uVar24 * 2);
                    uVar12 = uVar28;
LAB_:
                    if ((uVar11 & 0x7fff) < uVar28) goto LAB_;
                  }
                  else {
                    uVar28 = *(ushort *)(lVar20 + -2 + uVar24 * 2) & 0x7fff;
                    uVar12 = *(uint *)(psVar7 + 0xc);
                    uVar11 = *(ushort *)(lVar20 + uVar24 * 2);
                    if (uVar12 <= uVar28) goto LAB_;
LAB_:
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100e21;
                    func_0x(lVar34,7);
                    uVar12 = *(uint *)(psVar7 + 0xc);
                    lVar34 = *(longlong *)(psVar7 + 4);
                  }
                  if ((uVar28 < uVar12) || (*(uint *)(psVar7 + 2) < uVar28)) goto LAB_;
                  if (*(ushort *)((ulonglong)uVar28 + lVar34) == 5) {
                    psVar7[1] = psVar7[1] | 2;
                    psVar7[0xe] = psVar7[0xe] + -1;
                    psVar7[0x15] = (short)uVar28;
                    lVar34 = (ulonglong)(uVar28 & 0xffff) + *(longlong *)(psVar7 + 4);
                    uVar11 = psVar7[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar34 + 2) & 0x4000) != 0) {
                      uVar11 = *(ushort *)(lVar34 + 2) & 0x3800 | psVar7[0x16] & 0xc7ffU;
                    }
                    psVar7[0x16] = uVar11;
                    psVar7[0x16] = (uVar11 ^ *(ushort *)(lVar34 + 2)) & 0x7ff ^ uVar11;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar28 + lVar34) < 0x400) break;
                  psVar7[1] = psVar7[1] | 1;
                  uVar11 = psVar7[0xe] - 1;
                  psVar7[0xe] = uVar11;
                  if ((uVar11 == 0) || (-1 < psVar31[(ulonglong)(uVar11 - 1) + 1])) break;
                } while( true );
              }
            }
            iVar13 = 0;
            if ((**(byte **)(psVar7 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar7 + 0x13) = 0;
            }
            else {
              *(undefined4 *)(psVar7 + 0x13) = *(undefined4 *)(psVar7 + 2);
              *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + 0xe;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100eaa;
              puVar17 = (ulonglong *)func_0x(psVar7 + 1);
              uVar24 = *puVar17;
              uVar26 = (ushort)(uVar24 >> 0x30);
              uVar11 = uVar26;
              if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
                uVar11 = uVar26 & 0xdfff;
                if ((uVar24 & 0x4000000000000000) != 0) {
                  uVar11 = uVar26 | 0x2000;
                }
              }
              if (uVar11 == 0xfffc) {
                iVar13 = (int)((uVar24 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + iVar13;
            }
            uVar28 = *(uint *)(psVar7 + 2);
            if ((*(ulonglong *)(psVar7 + 0xf) != 0) &&
               (*(ulonglong *)(psVar7 + 0xf) < (ulonglong)uVar28 + *(longlong *)(psVar7 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar34 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0 &&
                   (lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0)) &&
                  (*(char *)(lVar34 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101027;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10104d;
                  (*_DAT_)(1,0x185a1d8,0x1979ea8,0x877);
                }
              }
              uVar21 = *(undefined8 *)(psVar7 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10105b;
              func_0x(uVar21,0x12);
              uVar28 = *(uint *)(psVar7 + 2);
            }
            if (0x3f3b < uVar28 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar34 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0 &&
                  ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                   (*(char *)(lVar34 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1010e7;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  uVar21 = *(undefined8 *)(psVar7 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1010f5;
                  func_0x(uVar21,5);
                  goto LAB_;
                }
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10111b;
                (*_DAT_)(1,0x185a1d8,0x1979ea8,0x87c);
              }
              uVar21 = *(undefined8 *)(psVar7 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101129;
              func_0x(uVar21,5);
            }
          }
LAB_:
          uVar28 = *(uint *)(psVar7 + 2);
          if (uVar28 < 9) {
            bVar9 = **(byte **)(psVar7 + 4);
            if (((bVar9 & 0xe) != 0) && ((bVar9 & 0xe) != 0xc)) goto LAB_;
            uVar28 = 9;
          }
          else {
LAB_:
            bVar9 = **(byte **)(psVar7 + 4);
          }
          if ((bVar9 & 0x40) != 0) {
            uVar28 = *(uint *)(psVar7 + 0x13);
          }
        }
        else {
          uVar28 = *(uint *)(psStack_5258 + 2);
          if (uVar28 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101172;
            func_0x(psStack_5258 + 1);
            uVar28 = *(uint *)(psVar7 + 2);
            if (uVar28 == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101183;
              func_0x(psVar7 + 1);
              uVar28 = *(uint *)(psVar7 + 2);
            }
          }
          if (uVar28 < 9) {
            bVar9 = **(byte **)(psVar7 + 4);
            if (((bVar9 & 0x1c) != 0) && ((bVar9 & 0x1c) != 0xc)) goto LAB_;
            uVar28 = 9;
          }
          else {
LAB_:
            bVar9 = **(byte **)(psVar7 + 4);
          }
          if ((bVar9 & 2) != 0) {
            uVar28 = *(uint *)(psVar7 + 0x18);
          }
        }
        pcVar4 = *(code **)*plVar18;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1011be;
        cVar8 = (*pcVar4)(plVar18);
        if (cVar8 == '\0') {
          if (bVar23 == 0) {
LAB_:
            lVar34 = plVar18[0x1a];
            if ((uVar27 & 1) != 0) goto LAB_;
            pcVar4 = *(code **)*plVar18;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10183f;
            cVar8 = (*pcVar4)(plVar18);
            if (cVar8 != '\0') goto LAB_;
            pcVar4 = *(code **)(*plVar18 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101853;
            cVar8 = (*pcVar4)(plVar18);
            if (cVar8 != '\0') {
              cStack_52cf = (char)(uVar27 >> 8);
              if (cStack_52cf != '\0') goto LAB_;
              if (lVar34 == 0) {
                pcVar4 = *(code **)(*plVar18 + 0x18);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101873;
                cVar8 = (*pcVar4)(plVar18);
                if (cVar8 == '\0') goto LAB_;
              }
              if ((*(byte *)(plVar18 + 0x4a) & 4) == 0) {
                if ((*(byte *)(plVar18 + 0x4a) & 0x5a) == 0) {
                  if ((*(byte *)(plVar18 + 0x43) & 1) != 0) {
                    if (plVar18[0x1a] == 0) {
                      pcVar4 = *(code **)(*plVar18 + 0x88);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1018b7;
                      cVar8 = (*pcVar4)(plVar18);
                      if (cVar8 != '\0') {
                        pcVar4 = *(code **)(*plVar18 + 0x18);
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1018c4;
                        cVar8 = (*pcVar4)(plVar18);
                        if (cVar8 == '\0') {
                          *(byte *)(plVar18 + 0x4a) = *(byte *)(plVar18 + 0x4a) | 4;
                          goto LAB_;
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1018dd;
                    iVar13 = func_0x(plVar18);
                    if (iVar13 == 0) {
                      pcVar4 = *(code **)(*plVar18 + 0x270);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1018ed;
                      (*pcVar4)(plVar18);
                    }
                    if ((*(byte *)(plVar18 + 0x43) & 4) == 0) {
                      if ((*(byte *)(plVar18 + 0x4a) & 0x52) == 2) {
                        lVar20 = plVar18[0x1a];
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101927;
                        cVar8 = func_0x(lVar20);
                        if (((cVar8 != '\0') && (*(char *)(plVar18[0x1a] + 0x130) == '\0')) &&
                           (*(undefined *)(plVar18[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101970;
                          func_0x(0x1f6dc10,0x1c,0x10,1);
                        }
                      }
                      uVar12 = (uint)((*(byte *)(plVar18 + 0x4a) & 0x5a) != 0);
                    }
                    else {
                      pcVar4 = *(code **)(*plVar18 + 0x1e8);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101903;
                      uVar21 = (*pcVar4)(plVar18);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10190b;
                      uVar12 = func_0x(uVar21);
                    }
                    if (uVar12 != 0) goto LAB_;
                  }
                }
                else {
LAB_:
                  if (((*(byte *)(plVar18 + 0x4a) & 0x40) != 0) &&
                     (cStack_52ce = (char)(uVar27 >> 0x10), cStack_52ce != '\0')) goto LAB_;
                }
              }
            }
LAB_:
            if ((uVar27 & 0x1c) == 0) {
              if (lStack_52c8 != 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1019b4;
                iVar13 = func_0x();
                if (((iVar13 != 0) &&
                    (iVar13 = *(int *)(*(longlong *)(lStack_52c8 + 8) + 0x100), iVar13 != 0)) &&
                   (1 < iVar13 - 3U)) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1019fa;
                  (*_DAT_)(1,0x1a08b80,0x1a08bd0,0x116);
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101a03;
                iVar13 = func_0x(lStack_52c8);
                if ((((iVar13 != 0) &&
                     ((*(byte *)(*(longlong *)(lStack_52c8 + 8) + 0x109) & 1) == 0)) &&
                    (iVar13 = *(int *)(*(longlong *)(lStack_52c8 + 8) + 0x100), iVar13 != 0)) &&
                   (1 < iVar13 - 3U)) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101a52;
                  (*_DAT_)(1,0x1a08c00,0x1a08bd0,0x119);
                }
              }
              if ((lVar34 != 0) && ((0 < *(int *)(lVar34 + 0x78) || (0 < *(int *)(lVar34 + 0x74)))))
              goto LAB_;
              if ((*(byte *)(plVar18 + 0x4a) & 4) != 0) goto LAB_;
              if ((*(byte *)(plVar18 + 0x4a) & 0x5a) != 0) goto LAB_;
              if ((*(byte *)(plVar18 + 0x43) & 1) == 0) goto LAB_;
              if (plVar18[0x1a] != 0) {
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ac4;
                iVar13 = func_0x(plVar18);
                if (iVar13 == 0) {
                  pcVar4 = *(code **)(*plVar18 + 0x270);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ad4;
                  (*pcVar4)(plVar18);
                }
                if ((*(byte *)(plVar18 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar18 + 0x4a) & 0x52) == 2) {
                    lVar20 = plVar18[0x1a];
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101b0e;
                    cVar8 = func_0x(lVar20);
                    if (((cVar8 != '\0') && (*(char *)(plVar18[0x1a] + 0x130) == '\0')) &&
                       (*(undefined *)(plVar18[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101b57;
                      func_0x(0x1f6dc10,0x1c,0x10,1);
                    }
                  }
                  uVar12 = (uint)((*(byte *)(plVar18 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar4 = *(code **)(*plVar18 + 0x1e8);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101aea;
                  uVar21 = (*pcVar4)(plVar18);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101af2;
                  uVar12 = func_0x(uVar21);
                }
                if (uVar12 == 0) goto LAB_;
                goto LAB_;
              }
              pcVar4 = *(code **)(*plVar18 + 0x88);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101aa7;
              cVar8 = (*pcVar4)(plVar18);
              if (cVar8 == '\0') goto LAB_;
              pcVar4 = *(code **)(*plVar18 + 0x18);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ab4;
              cVar8 = (*pcVar4)(plVar18);
              if (cVar8 != '\0') goto LAB_;
LAB_:
              *(byte *)(plVar18 + 0x4a) = *(byte *)(plVar18 + 0x4a) | 4;
              goto LAB_;
            }
LAB_:
            if (lVar34 != 0) {
LAB_:
              if ((uVar27 & 0x1c) == 0) {
                if (lStack_52c8 != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101b94;
                  iVar13 = func_0x();
                  if (((iVar13 != 0) &&
                      (iVar13 = *(int *)(*(longlong *)(lStack_52c8 + 8) + 0x100), iVar13 != 0)) &&
                     (1 < iVar13 - 3U)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101bda;
                    (*_DAT_)(1,0x1a08b80,0x1a08bd0,0x116);
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101be3;
                  iVar13 = func_0x(lStack_52c8);
                  if (((iVar13 != 0) &&
                      ((*(byte *)(*(longlong *)(lStack_52c8 + 8) + 0x109) & 1) == 0)) &&
                     ((iVar13 = *(int *)(*(longlong *)(lStack_52c8 + 8) + 0x100), iVar13 != 0 &&
                      (1 < iVar13 - 3U)))) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101c32;
                    (*_DAT_)(1,0x1a08c00,0x1a08bd0,0x119);
                  }
                }
                if ((*(int *)(lVar34 + 0x78) < 1) && (*(int *)(lVar34 + 0x74) < 1)) {
                  if ((*(byte *)(plVar18 + 0x4a) & 4) == 0) {
                    if ((*(byte *)(plVar18 + 0x4a) & 0x5a) == 0) {
                      if ((*(byte *)(plVar18 + 0x43) & 1) != 0) {
                        if (plVar18[0x1a] == 0) {
                          pcVar4 = *(code **)(*plVar18 + 0x88);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101c82;
                          cVar8 = (*pcVar4)(plVar18);
                          if (cVar8 != '\0') {
                            pcVar4 = *(code **)(*plVar18 + 0x18);
                            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101c8f;
                            cVar8 = (*pcVar4)(plVar18);
                            if (cVar8 == '\0') {
                              *(byte *)(plVar18 + 0x4a) = *(byte *)(plVar18 + 0x4a) | 4;
                              goto LAB_;
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ca8;
                        iVar13 = func_0x(plVar18);
                        if (iVar13 == 0) {
                          pcVar4 = *(code **)(*plVar18 + 0x270);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101cb8;
                          (*pcVar4)(plVar18);
                        }
                        if ((*(byte *)(plVar18 + 0x43) & 4) == 0) {
                          if ((*(byte *)(plVar18 + 0x4a) & 0x52) == 2) {
                            lVar20 = plVar18[0x1a];
                            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101cf2;
                            cVar8 = func_0x(lVar20);
                            if (((cVar8 != '\0') && (*(char *)(plVar18[0x1a] + 0x130) == '\0')) &&
                               (*(undefined *)(plVar18[0x1a] + 0x130) = 1, *_DAT_ != '\0'))
                            {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101d3b;
                              func_0x(0x1f6dc10,0x1c,0x10,1);
                            }
                          }
                          uVar12 = (uint)((*(byte *)(plVar18 + 0x4a) & 0x5a) != 0);
                        }
                        else {
                          pcVar4 = *(code **)(*plVar18 + 0x1e8);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101cce;
                          uVar21 = (*pcVar4)(plVar18);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101cd6;
                          uVar12 = func_0x(uVar21);
                        }
                        if (uVar12 != 0) goto LAB_;
                      }
                    }
                    else {
LAB_:
                      if ((*(byte *)(plVar18 + 0x4a) & 0x10) != 0) goto LAB_;
                    }
                  }
LAB_:
                  if ((*(byte *)(plVar18 + 0x4a) & 4) == 0) {
                    if ((*(byte *)(plVar18 + 0x4a) & 0x5a) == 0) {
                      if ((*(byte *)(plVar18 + 0x43) & 1) != 0) {
                        if (plVar18[0x1a] == 0) {
                          pcVar4 = *(code **)(*plVar18 + 0x88);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101d99;
                          cVar8 = (*pcVar4)(plVar18);
                          if (cVar8 != '\0') {
                            pcVar4 = *(code **)(*plVar18 + 0x18);
                            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101da6;
                            cVar8 = (*pcVar4)(plVar18);
                            if (cVar8 == '\0') {
                              *(byte *)(plVar18 + 0x4a) = *(byte *)(plVar18 + 0x4a) | 4;
                              goto LAB_;
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101dbf;
                        iVar13 = func_0x(plVar18);
                        if (iVar13 == 0) {
                          pcVar4 = *(code **)(*plVar18 + 0x270);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101dcf;
                          (*pcVar4)(plVar18);
                        }
                        if ((*(byte *)(plVar18 + 0x43) & 4) == 0) {
                          if ((*(byte *)(plVar18 + 0x4a) & 0x52) == 2) {
                            lVar20 = plVar18[0x1a];
                            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e09;
                            cVar8 = func_0x(lVar20);
                            if (((cVar8 != '\0') && (*(char *)(plVar18[0x1a] + 0x130) == '\0')) &&
                               (*(undefined *)(plVar18[0x1a] + 0x130) = 1, *_DAT_ != '\0'))
                            {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e52;
                              func_0x(0x1f6dc10,0x1c,0x10,1);
                            }
                          }
                          uVar12 = (uint)((*(byte *)(plVar18 + 0x4a) & 0x5a) != 0);
                        }
                        else {
                          pcVar4 = *(code **)(*plVar18 + 0x1e8);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101de5;
                          uVar21 = (*pcVar4)(plVar18);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ded;
                          uVar12 = func_0x(uVar21);
                        }
                        if (uVar12 != 0) goto LAB_;
                      }
                    }
                    else {
LAB_:
                      if ((*(byte *)(plVar18 + 0x4a) & 0x40) != 0) goto LAB_;
                    }
                  }
                }
              }
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e7a;
              func_0x(lVar34,0);
            }
LAB_:
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e82;
            iVar13 = func_0x(plVar18);
            if (iVar13 == 0) {
              pcVar4 = *(code **)(*plVar18 + 0x270);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e92;
              (*pcVar4)(plVar18);
            }
            lVar34 = plVar18[0x1a];
            if ((uVar27 & 0x24) == 0) {
              if ((*(byte *)(plVar18 + 0x4a) & 4) == 0) {
                if ((*(byte *)(plVar18 + 0x4a) & 0x5a) != 0) goto LAB_;
                if ((*(byte *)(plVar18 + 0x43) & 1) != 0) {
                  if (lVar34 == 0) {
                    pcVar4 = *(code **)(*plVar18 + 0x88);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101eda;
                    cVar8 = (*pcVar4)(plVar18);
                    if (cVar8 != '\0') {
                      pcVar4 = *(code **)(*plVar18 + 0x18);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ee7;
                      cVar8 = (*pcVar4)(plVar18);
                      if (cVar8 == '\0') goto LAB_;
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ef7;
                  iVar13 = func_0x(plVar18);
                  if (iVar13 == 0) {
                    pcVar4 = *(code **)(*plVar18 + 0x270);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101f07;
                    (*pcVar4)(plVar18);
                  }
                  if ((*(byte *)(plVar18 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar18 + 0x4a) & 0x52) == 2) {
                      lVar20 = plVar18[0x1a];
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101f41;
                      cVar8 = func_0x(lVar20);
                      if (((cVar8 != '\0') && (*(char *)(plVar18[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar18[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101f8a;
                        func_0x(0x1f6dc10,0x1c,0x10,1);
                      }
                    }
                    uVar27 = (uint)((*(byte *)(plVar18 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar4 = *(code **)(*plVar18 + 0x1e8);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101f1d;
                    uVar21 = (*pcVar4)(plVar18);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101f25;
                    uVar27 = func_0x(uVar21);
                  }
                  if (uVar27 != 0) goto LAB_;
                }
              }
              if ((lVar34 == 0) || (*(int *)(lVar34 + 0x74) < 1)) goto LAB_;
            }
LAB_:
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101fb9;
            iVar13 = func_0x(psVar7);
            if (iVar13 != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101fc9;
              func_0x(psVar7,auStack_5298);
              uVar27 = 0;
              uVar11 = uStack_5292;
              if ((((uint)(int)(short)uStack_5292 >> 1 ^ (int)(short)uStack_5292) & 0x2000) != 0) {
                uVar11 = uStack_5292 & 0xdfff;
                if ((uStack_5292 >> 0xe & 1) != 0) {
                  uVar11 = uStack_5292 | 0x2000;
                }
              }
              if (uVar11 == 0xfffc) {
                uVar27 = (uint)(uStack_5294 >> 5);
              }
              uVar28 = uVar28 + uVar27;
            }
            lVar34 = plVar18[0x1a];
            pcVar4 = *(code **)(*plVar18 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102027;
            cVar8 = (*pcVar4)(plVar18);
            if ((((cVar8 == '\0') && (lVar34 != 0)) &&
                ((0 < *(int *)(lVar34 + 0x78) || (0 < *(int *)(lVar34 + 0x74))))) &&
               (uVar28 < 0x1f74)) {
              uVar28 = uVar28 + 8;
            }
            uVar28 = uVar28 + 0xe;
          }
          else {
            pcVar4 = *(code **)(*plVar18 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101811;
            cVar8 = (*pcVar4)(plVar18);
            if (cVar8 == '\0') goto LAB_;
            pcVar4 = *(code **)(*plVar18 + 0x18);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10181e;
            cVar8 = (*pcVar4)(plVar18);
            if (cVar8 != '\0') goto LAB_;
LAB_:
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10205f;
            iVar13 = func_0x(psVar7);
            if (iVar13 != 0) {
              if (*psVar7 == 0) {
                if (*(int *)(psVar7 + 2) == 0) {
                  psVar7[1] = 0;
                  uVar27 = *(uint *)(psVar7 + 8);
                  uVar24 = (ulonglong)uVar27;
                  *(uint *)(psVar7 + 10) = uVar27;
                  pbVar33 = *(byte **)(psVar7 + 4);
                  bVar23 = *pbVar33;
                  if ((bVar23 & 0x10) != 0) {
                    uVar27 = uVar27 + 2 + (*(ushort *)(pbVar33 + uVar24) + 7 >> 3);
                    uVar24 = (ulonglong)uVar27;
                    *(uint *)(psVar7 + 10) = uVar27;
                    bVar23 = *pbVar33;
                  }
                  if ((bVar23 & 0x20) == 0) {
                    *(int *)(psVar7 + 2) = (int)uVar24;
                    psVar7[0xe] = 0;
                    *(undefined4 *)(psVar7 + 0xc) = *(undefined4 *)(psVar7 + 10);
                  }
                  else {
                    psVar31 = (short *)(pbVar33 + uVar24);
                    sVar1 = *psVar31;
                    psVar7[0xe] = sVar1;
                    if (sVar1 == 0) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar34 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0)) &&
                         ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                          (*(char *)(lVar34 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102148;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10216e;
                          (*_DAT_)(1,0x185a1d8,0x1979ea8,0x80f);
                        }
                      }
                      uVar21 = *(undefined8 *)(psVar7 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10217c;
                      func_0x(uVar21,3);
                    }
                    uVar27 = *(int *)(psVar7 + 10) + ((ushort)psVar7[0xe] + 1) * 2;
                    *(uint *)(psVar7 + 0xc) = uVar27;
                    if (0x1f9e < uVar27) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar34 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0 &&
                          ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                           (*(char *)(lVar34 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102214;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10223a;
                          (*_DAT_)(1,0x185a1d8,0x1979ea8,0x816);
                        }
                      }
                      uVar21 = *(undefined8 *)(psVar7 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102248;
                      func_0x(uVar21,4);
                    }
                    uVar11 = psVar31[(ushort)psVar7[0xe]];
                    *(uint *)(psVar7 + 2) = uVar11 & 0x7fff;
                    if ((uVar11 & 0x7fff) < *(uint *)(psVar7 + 0xc)) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar34 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0)) &&
                         ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                          (*(char *)(lVar34 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1022df;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102305;
                          (*_DAT_)(1,0x185a1d8,0x1979ea8,0x81d);
                        }
                      }
                      uVar21 = *(undefined8 *)(psVar7 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102313;
                      func_0x(uVar21,4);
                    }
                    uVar11 = psVar7[0xe];
                    if (psVar31[(ulonglong)(uVar11 - 1) + 1] < 0) {
                      do {
                        uVar24 = (ulonglong)uVar11;
                        lVar34 = *(longlong *)(psVar7 + 4);
                        lVar20 = (ulonglong)*(uint *)(psVar7 + 10) + lVar34;
                        if (uVar11 == 1) {
                          uVar27 = *(uint *)(psVar7 + 0xc);
                          uVar11 = *(ushort *)(lVar20 + uVar24 * 2);
                          uVar28 = uVar27;
LAB_:
                          if ((uVar11 & 0x7fff) < uVar27) goto LAB_;
                        }
                        else {
                          uVar27 = *(ushort *)(lVar20 + -2 + uVar24 * 2) & 0x7fff;
                          uVar28 = *(uint *)(psVar7 + 0xc);
                          uVar11 = *(ushort *)(lVar20 + uVar24 * 2);
                          if (uVar28 <= uVar27) goto LAB_;
LAB_:
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102381;
                          func_0x(lVar34,7);
                          uVar28 = *(uint *)(psVar7 + 0xc);
                        }
                        if ((uVar27 < uVar28) || (*(uint *)(psVar7 + 2) < uVar27))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar27 + *(longlong *)(psVar7 + 4)) == 5) {
                          psVar7[1] = psVar7[1] | 2;
                          psVar7[0xe] = psVar7[0xe] + -1;
                          psVar7[0x15] = (short)uVar27;
                          lVar34 = (ulonglong)(uVar27 & 0xffff) + *(longlong *)(psVar7 + 4);
                          uVar11 = psVar7[0x16] & 0xc7ffU;
                          if ((*(ushort *)(lVar34 + 2) & 0x4000) != 0) {
                            uVar11 = *(ushort *)(lVar34 + 2) & 0x3800 | psVar7[0x16] & 0xc7ffU;
                          }
                          psVar7[0x16] = uVar11;
                          psVar7[0x16] = (uVar11 ^ *(ushort *)(lVar34 + 2)) & 0x7ff ^ uVar11;
                          break;
                        }
                        if (*(ushort *)((ulonglong)uVar27 + *(longlong *)(psVar7 + 4)) < 0x400)
                        break;
                        psVar7[1] = psVar7[1] | 1;
                        uVar11 = psVar7[0xe] - 1;
                        psVar7[0xe] = uVar11;
                        if ((uVar11 == 0) || (-1 < psVar31[(ulonglong)(uVar11 - 1) + 1])) break;
                      } while( true );
                    }
                  }
                  iVar13 = 0;
                  if ((**(byte **)(psVar7 + 4) & 0x40) == 0) {
                    *(undefined4 *)(psVar7 + 0x13) = 0;
                  }
                  else {
                    *(undefined4 *)(psVar7 + 0x13) = *(undefined4 *)(psVar7 + 2);
                    *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102409;
                    puVar17 = (ulonglong *)func_0x(psVar7 + 1);
                    uVar24 = *puVar17;
                    uVar26 = (ushort)(uVar24 >> 0x30);
                    uVar11 = uVar26;
                    if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
                      uVar11 = uVar26 & 0xdfff;
                      if ((uVar24 & 0x4000000000000000) != 0) {
                        uVar11 = uVar26 | 0x2000;
                      }
                    }
                    if (uVar11 == 0xfffc) {
                      iVar13 = (int)((uVar24 >> 0x20 & 0xffff) >> 5);
                    }
                    *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + iVar13;
                  }
                  uVar27 = *(uint *)(psVar7 + 2);
                  if ((*(ulonglong *)(psVar7 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar7 + 0xf) < (ulonglong)uVar27 + *(longlong *)(psVar7 + 4)))
                  {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       (((lVar34 = *(longlong *)
                                    ((ulonglong)*_DAT_ +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0 &&
                         (lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0)) &&
                        (*(char *)(lVar34 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102586;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1025ac;
                        (*_DAT_)(1,0x185a1d8,0x1979ea8,0x877);
                      }
                    }
                    uVar21 = *(undefined8 *)(psVar7 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1025ba;
                    func_0x(uVar21,0x12);
                    uVar27 = *(uint *)(psVar7 + 2);
                  }
                  if (0x3f3b < uVar27 - 1) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar34 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0 &&
                        ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                         (*(char *)(lVar34 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) goto LAB_;
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102662;
                      (*_DAT_)(1,0x185a1d8,0x1979ea8,0x87c);
                    }
                    goto LAB_;
                  }
                }
                goto LAB_;
              }
              goto LAB_;
            }
          }
        }
        else if (*psVar7 == 0) {
          if (*(int *)(psVar7 + 2) == 0) {
            psVar7[1] = 0;
            uVar27 = *(uint *)(psVar7 + 8);
            uVar24 = (ulonglong)uVar27;
            *(uint *)(psVar7 + 10) = uVar27;
            pbVar33 = *(byte **)(psVar7 + 4);
            bVar23 = *pbVar33;
            if ((bVar23 & 0x10) != 0) {
              uVar27 = uVar27 + 2 + (*(ushort *)(pbVar33 + uVar24) + 7 >> 3);
              uVar24 = (ulonglong)uVar27;
              *(uint *)(psVar7 + 10) = uVar27;
              bVar23 = *pbVar33;
            }
            if ((bVar23 & 0x20) == 0) {
              *(int *)(psVar7 + 2) = (int)uVar24;
              psVar7[0xe] = 0;
              *(undefined4 *)(psVar7 + 0xc) = *(undefined4 *)(psVar7 + 10);
            }
            else {
              psVar31 = (short *)(pbVar33 + uVar24);
              sVar1 = *psVar31;
              psVar7[0xe] = sVar1;
              if (sVar1 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar34 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0)) &&
                   ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                    (*(char *)(lVar34 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1012a4;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1012ca;
                    (*_DAT_)(1,0x185a1d8,0x1979ea8,0x80f);
                  }
                }
                uVar21 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1012d8;
                func_0x(uVar21,3);
              }
              uVar27 = *(int *)(psVar7 + 10) + ((ushort)psVar7[0xe] + 1) * 2;
              *(uint *)(psVar7 + 0xc) = uVar27;
              if (0x1f9e < uVar27) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar34 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0 &&
                    ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                     (*(char *)(lVar34 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101370;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101396;
                    (*_DAT_)(1,0x185a1d8,0x1979ea8,0x816);
                  }
                }
                uVar21 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1013a4;
                func_0x(uVar21,4);
              }
              uVar11 = psVar31[(ushort)psVar7[0xe]];
              *(uint *)(psVar7 + 2) = uVar11 & 0x7fff;
              if ((uVar11 & 0x7fff) < *(uint *)(psVar7 + 0xc)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar34 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0)) &&
                   ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                    (*(char *)(lVar34 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10143b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101461;
                    (*_DAT_)(1,0x185a1d8,0x1979ea8,0x81d);
                  }
                }
                uVar21 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10146f;
                func_0x(uVar21,4);
              }
              uVar11 = psVar7[0xe];
              if (psVar31[(ulonglong)(uVar11 - 1) + 1] < 0) {
                do {
                  uVar24 = (ulonglong)uVar11;
                  lVar34 = *(longlong *)(psVar7 + 4);
                  lVar20 = (ulonglong)*(uint *)(psVar7 + 10) + lVar34;
                  if (uVar11 == 1) {
                    uVar27 = *(uint *)(psVar7 + 0xc);
                    uVar11 = *(ushort *)(lVar20 + uVar24 * 2);
                    uVar28 = uVar27;
LAB_:
                    if ((uVar11 & 0x7fff) < uVar27) goto LAB_;
                  }
                  else {
                    uVar27 = *(ushort *)(lVar20 + -2 + uVar24 * 2) & 0x7fff;
                    uVar28 = *(uint *)(psVar7 + 0xc);
                    uVar11 = *(ushort *)(lVar20 + uVar24 * 2);
                    if (uVar28 <= uVar27) goto LAB_;
LAB_:
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1014e1;
                    func_0x(lVar34,7);
                    uVar28 = *(uint *)(psVar7 + 0xc);
                  }
                  if ((uVar27 < uVar28) || (*(uint *)(psVar7 + 2) < uVar27)) goto LAB_;
                  if (*(ushort *)((ulonglong)uVar27 + *(longlong *)(psVar7 + 4)) == 5) {
                    psVar7[1] = psVar7[1] | 2;
                    psVar7[0xe] = psVar7[0xe] + -1;
                    psVar7[0x15] = (short)uVar27;
                    lVar34 = (ulonglong)(uVar27 & 0xffff) + *(longlong *)(psVar7 + 4);
                    uVar11 = psVar7[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar34 + 2) & 0x4000) != 0) {
                      uVar11 = *(ushort *)(lVar34 + 2) & 0x3800 | psVar7[0x16] & 0xc7ffU;
                    }
                    psVar7[0x16] = uVar11;
                    psVar7[0x16] = (uVar11 ^ *(ushort *)(lVar34 + 2)) & 0x7ff ^ uVar11;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar27 + *(longlong *)(psVar7 + 4)) < 0x400) break;
                  psVar7[1] = psVar7[1] | 1;
                  uVar11 = psVar7[0xe] - 1;
                  psVar7[0xe] = uVar11;
                  if ((uVar11 == 0) || (-1 < psVar31[(ulonglong)(uVar11 - 1) + 1])) break;
                } while( true );
              }
            }
            iVar13 = 0;
            if ((**(byte **)(psVar7 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar7 + 0x13) = 0;
            }
            else {
              *(undefined4 *)(psVar7 + 0x13) = *(undefined4 *)(psVar7 + 2);
              *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + 0xe;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101569;
              puVar17 = (ulonglong *)func_0x(psVar7 + 1);
              uVar24 = *puVar17;
              uVar26 = (ushort)(uVar24 >> 0x30);
              uVar11 = uVar26;
              if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
                uVar11 = uVar26 & 0xdfff;
                if ((uVar24 & 0x4000000000000000) != 0) {
                  uVar11 = uVar26 | 0x2000;
                }
              }
              if (uVar11 == 0xfffc) {
                iVar13 = (int)((uVar24 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + iVar13;
            }
            uVar27 = *(uint *)(psVar7 + 2);
            if ((*(ulonglong *)(psVar7 + 0xf) != 0) &&
               (*(ulonglong *)(psVar7 + 0xf) < (ulonglong)uVar27 + *(longlong *)(psVar7 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar34 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar34 != 0 &&
                   (lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0)) &&
                  (*(char *)(lVar34 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1016e6;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10170c;
                  (*_DAT_)(1,0x185a1d8,0x1979ea8,0x877);
                }
              }
              uVar21 = *(undefined8 *)(psVar7 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10171a;
              func_0x(uVar21,0x12);
              uVar27 = *(uint *)(psVar7 + 2);
            }
            if (uVar27 - 1 < 0x3f3c) goto LAB_;
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar34 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar34 != 0 &&
                ((lVar34 = *(longlong *)(lVar34 + 0x60), lVar34 != 0 &&
                 (*(char *)(lVar34 + 0x499) != '\0')))))) {
              if ((DAT_ != '\0') || ((DAT_ & 2) != 0)) {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1017cc;
                (*_DAT_)(1,0x185a1d8,0x1979ea8,0x87c);
                goto LAB_;
              }
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1017a6;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
LAB_:
            uVar21 = *(undefined8 *)(psVar7 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1017da;
            func_0x(uVar21,5);
          }
LAB_:
          uVar28 = *(uint *)(psVar7 + 2);
          if (uVar28 < 9) {
            bVar23 = **(byte **)(psVar7 + 4) & 0xe;
            goto joined_r0x001017f1;
          }
        }
        else {
LAB_:
          uVar28 = *(uint *)(psVar7 + 2);
          if (uVar28 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102678;
            func_0x(psVar7 + 1);
            uVar28 = *(uint *)(psVar7 + 2);
          }
          if (uVar28 < 9) {
            bVar23 = **(byte **)(psVar7 + 4) & 0x1c;
joined_r0x001017f1:
            if ((bVar23 == 0) || (bVar23 == 0xc)) {
              uVar28 = 9;
            }
          }
        }
        bVar23 = *(byte *)(*(longlong *)(lVar29 + 8) + 0x107);
        uVar27 = 0;
        iVar13 = *(int *)(puStack_4a88 + 8);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1026cc;
        uVar21 = func_0x(lVar29,auStack_5160);
        *(undefined8 *)((longlong)alStackX_8 + lVar15) = puStack_4a88[2];
        *(undefined2 *)((longlong)alStackX_8 + lVar15 + -8) = *(undefined2 *)(lVar16 + 0x3c8);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar15) = lVar16 + 0x3c0;
        *(uint *)(&stack0xfffffffffffffff0 + lVar15) = bVar23 >> 6 & 1;
        *(uint *)(&stack0xffffffffffffffe8 + lVar15) = (uint)(iVar13 != 1);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102708;
        func_0x(auStack_5118,plVar18,uVar21,lVar29);
        uStack_480a = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102717;
        cVar8 = func_0x(lVar29);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102726;
        cVar10 = func_0x(lVar29);
        *(uint *)(&stack0xfffffffffffffff0 + lVar15) = -(uint)(cVar8 != '\0') & 2;
        *(uint *)(&stack0xffffffffffffffe8 + lVar15) = (uint)(cVar10 != '\0');
        uVar21 = puStack_4a88[4];
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102757;
        func_0x(auStack_5148,auStack_5118,uVar21,uVar28);
        uVar28 = 0x10;
        uVar24 = *(ulonglong *)(lVar29 + 0x14);
        lVar16 = plVar18[6];
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102783;
        cVar8 = func_0x
                          (lVar16,((uVar24 >> 0x20 & 0xffff) << 0x20 | uVar24 & 0xffffffff) << 0x10)
        ;
        if (cVar8 != '\0') {
          uVar28 = 1;
        }
        do {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1027a4;
          func_0x(auStack_5148,auStack_4ab8);
          if ((iStack_4ab0 == 0) && (sStack_4aac == 0)) goto LAB_;
          if (*(char *)(puStack_4a88[4] + 1) == '\x05') {
LAB_:
            *(undefined **)(&stack0xffffffffffffffe8 + lVar15) = auStack_5170;
            uVar21 = *puStack_4a88;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10294d;
            iVar13 = func_0x(uVar21,auStack_4ab8,3);
            if (iVar13 == 0) {
              if ((*(char *)(puStack_4a88[4] + 1) != '\x05') &&
                 (*(char *)(puStack_4a88[4] + 2) != '\0')) {
                if ((bStack_49e8 & 2) != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102a36;
                  iVar13 = func_0x(auStack_49e0);
                  if (iVar13 != 0) {
                    puStack_4a88[6] = puStack_4a88[6] + -1;
                  }
                }
                bStack_49e8 = 0;
                uStack_49ec = 0;
                uStack_49d0 = 0;
                goto LAB_;
              }
            }
            else {
              puVar19 = (undefined4 *)&bStack_50b8;
              lVar16 = 2;
              puVar22 = auStack_4eb8;
              do {
                uVar3 = puVar19[1];
                uVar5 = puVar19[2];
                uVar6 = puVar19[3];
                *puVar22 = *puVar19;
                puVar22[1] = uVar3;
                puVar22[2] = uVar5;
                puVar22[3] = uVar6;
                uVar3 = puVar19[5];
                uVar5 = puVar19[6];
                uVar6 = puVar19[7];
                puVar22[4] = puVar19[4];
                puVar22[5] = uVar3;
                puVar22[6] = uVar5;
                puVar22[7] = uVar6;
                uVar3 = puVar19[9];
                uVar5 = puVar19[10];
                uVar6 = puVar19[0xb];
                puVar22[8] = puVar19[8];
                puVar22[9] = uVar3;
                puVar22[10] = uVar5;
                puVar22[0xb] = uVar6;
                uVar3 = puVar19[0xd];
                uVar5 = puVar19[0xe];
                uVar6 = puVar19[0xf];
                puVar22[0xc] = puVar19[0xc];
                puVar22[0xd] = uVar3;
                puVar22[0xe] = uVar5;
                puVar22[0xf] = uVar6;
                uVar3 = puVar19[0x11];
                uVar5 = puVar19[0x12];
                uVar6 = puVar19[0x13];
                puVar22[0x10] = puVar19[0x10];
                puVar22[0x11] = uVar3;
                puVar22[0x12] = uVar5;
                puVar22[0x13] = uVar6;
                uVar3 = puVar19[0x15];
                uVar5 = puVar19[0x16];
                uVar6 = puVar19[0x17];
                puVar22[0x14] = puVar19[0x14];
                puVar22[0x15] = uVar3;
                puVar22[0x16] = uVar5;
                puVar22[0x17] = uVar6;
                uVar3 = puVar19[0x19];
                uVar5 = puVar19[0x1a];
                uVar6 = puVar19[0x1b];
                puVar22[0x18] = puVar19[0x18];
                puVar22[0x19] = uVar3;
                puVar22[0x1a] = uVar5;
                puVar22[0x1b] = uVar6;
                uVar3 = puVar19[0x1d];
                uVar5 = puVar19[0x1e];
                uVar6 = puVar19[0x1f];
                puVar22[0x1c] = puVar19[0x1c];
                puVar22[0x1d] = uVar3;
                puVar22[0x1e] = uVar5;
                puVar22[0x1f] = uVar6;
                puVar19 = puVar19 + 0x20;
                lVar16 = lVar16 + -1;
                puVar22 = puVar22 + 0x20;
              } while (lVar16 != 0);
              *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 1;
              *(undefined4 **)(&stack0xfffffffffffffff0 + lVar15) = auStack_4eb8;
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1029f6;
              func_0x(&puStack_4a88,auStack_5170,&psStack_5258);
            }
            if (iStack_49c8 == 4) {
              uStack_480a = uStack_5128;
              break;
            }
          }
          else {
            pcVar4 = *(code **)(*plVar18 + 0x28);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1027d9;
            cVar10 = (*pcVar4)(plVar18);
            if (cVar10 != '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1027e9;
            iVar13 = func_0x(lVar29);
            if (iVar13 != 0) goto LAB_;
            iStack_52b0 = iStack_4ab0;
            sStack_52ac = sStack_4aac;
            uVar2 = *(undefined2 *)(plVar18[6] + 0x6b8);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102823;
            func_0x(auStack_4a98,uVar2,&iStack_52b0,0);
            if (*(char *)(puStack_4a88[4] + 2) == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102840;
              cVar10 = func_0x(lVar29);
              if (cVar10 != '\0') goto LAB_;
              uStack_52a8 = 8;
              uStack_5268 = *(undefined8 *)(lVar29 + 0x14);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102866;
              iVar13 = func_0x(&uStack_5268,&uStack_52a8);
              if (iVar13 == 0) goto LAB_;
              uStack_5260 = *(undefined8 *)(lVar29 + 0x14);
              *(undefined8 *)((longlong)&param_5 + lVar15) = 0;
              *(undefined **)((longlong)alStackX_8 + lVar15 + 0x18) = auStack_49f8;
              *(undefined8 **)((longlong)alStackX_8 + lVar15 + 0x10) = &uStack_5260;
              *(undefined8 *)((longlong)alStackX_8 + lVar15 + 8) = 0;
              *(undefined4 *)((longlong)alStackX_8 + lVar15) = 0;
              *(undefined *)((longlong)alStackX_8 + lVar15 + -8) = 0;
              *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar15) = 1;
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
              lVar16 = plStack_4a80[1];
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1028d5;
              iVar13 = func_0x(lVar16,auStack_4a98,8);
            }
            else {
LAB_:
              *(undefined4 *)((longlong)alStackX_8 + lVar15 + -8) = 1;
              *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
              *(undefined **)(&stack0xffffffffffffffe8 + lVar15) = auStack_49f8;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102919;
              iVar13 = func_0x(&puStack_4a88,auStack_4a98,2);
            }
            if (-1 < iVar13) goto LAB_;
          }
LAB_:
          uVar27 = uVar27 + 1;
        } while (uVar27 < uVar28);
        if (cVar8 != '\0') {
          if (iStack_49c8 == 4) {
            puVar19 = *(undefined4 **)(&stack0x00000040 + lVar15);
            goto LAB_;
          }
          if ((iStack_4ab0 != 0) || (sStack_4aac != 0)) {
            uStack_52b8 = 0;
            lVar29 = *(longlong *)(lVar29 + 8);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102aab;
            func_0x(&uStack_52b8,lVar29 + 0x3c0);
            iStack_52a0 = iStack_4ab0;
            sStack_529c = sStack_4aac;
            uStack_529a = 0;
            (&stack0x00000038)[lVar15] = 4;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102ad7;
            func_0x(auStack_5208,0x27);
            *(longlong **)(&stack0xfffffffffffffff8 + lVar15) = plVar18;
            (&stack0xfffffffffffffff0)[lVar15] = 1;
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
            lVar29 = plVar18[6];
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102b00;
            func_0x(lVar29,&uStack_52b8,&iStack_52a0,&stack0x00000038 + lVar15);
            *(uint *)(lStack_5200 + 0x268) = *(uint *)(lStack_5200 + 0x268) & ~auStack_5208[0];
          }
        }
LAB_:
        puVar19 = *(undefined4 **)(&stack0x00000040 + lVar15);
      }
      if (iStack_49c8 != 4) {
        puVar17 = auStack_4fb8;
        lVar29 = 2;
        puVar22 = auStack_4db8;
        do {
          uVar3 = *(undefined4 *)((longlong)puVar17 + 4);
          uVar5 = *(undefined4 *)(puVar17 + 1);
          uVar6 = *(undefined4 *)((longlong)puVar17 + 0xc);
          *puVar22 = *(undefined4 *)puVar17;
          puVar22[1] = uVar3;
          puVar22[2] = uVar5;
          puVar22[3] = uVar6;
          uVar3 = *(undefined4 *)((longlong)puVar17 + 0x14);
          uVar5 = *(undefined4 *)(puVar17 + 3);
          uVar6 = *(undefined4 *)((longlong)puVar17 + 0x1c);
          puVar22[4] = *(undefined4 *)(puVar17 + 2);
          puVar22[5] = uVar3;
          puVar22[6] = uVar5;
          puVar22[7] = uVar6;
          uVar3 = *(undefined4 *)((longlong)puVar17 + 0x24);
          uVar5 = *(undefined4 *)(puVar17 + 5);
          uVar6 = *(undefined4 *)((longlong)puVar17 + 0x2c);
          puVar22[8] = *(undefined4 *)(puVar17 + 4);
          puVar22[9] = uVar3;
          puVar22[10] = uVar5;
          puVar22[0xb] = uVar6;
          uVar3 = *(undefined4 *)((longlong)puVar17 + 0x34);
          uVar5 = *(undefined4 *)(puVar17 + 7);
          uVar6 = *(undefined4 *)((longlong)puVar17 + 0x3c);
          puVar22[0xc] = *(undefined4 *)(puVar17 + 6);
          puVar22[0xd] = uVar3;
          puVar22[0xe] = uVar5;
          puVar22[0xf] = uVar6;
          uVar3 = *(undefined4 *)((longlong)puVar17 + 0x44);
          uVar5 = *(undefined4 *)(puVar17 + 9);
          uVar6 = *(undefined4 *)((longlong)puVar17 + 0x4c);
          puVar22[0x10] = *(undefined4 *)(puVar17 + 8);
          puVar22[0x11] = uVar3;
          puVar22[0x12] = uVar5;
          puVar22[0x13] = uVar6;
          uVar3 = *(undefined4 *)((longlong)puVar17 + 0x54);
          uVar5 = *(undefined4 *)(puVar17 + 0xb);
          uVar6 = *(undefined4 *)((longlong)puVar17 + 0x5c);
          puVar22[0x14] = *(undefined4 *)(puVar17 + 10);
          puVar22[0x15] = uVar3;
          puVar22[0x16] = uVar5;
          puVar22[0x17] = uVar6;
          uVar3 = *(undefined4 *)((longlong)puVar17 + 100);
          uVar5 = *(undefined4 *)(puVar17 + 0xd);
          uVar6 = *(undefined4 *)((longlong)puVar17 + 0x6c);
          puVar22[0x18] = *(undefined4 *)(puVar17 + 0xc);
          puVar22[0x19] = uVar3;
          puVar22[0x1a] = uVar5;
          puVar22[0x1b] = uVar6;
          uVar3 = *(undefined4 *)((longlong)puVar17 + 0x74);
          uVar5 = *(undefined4 *)(puVar17 + 0xf);
          uVar6 = *(undefined4 *)((longlong)puVar17 + 0x7c);
          puVar22[0x1c] = *(undefined4 *)(puVar17 + 0xe);
          puVar22[0x1d] = uVar3;
          puVar22[0x1e] = uVar5;
          puVar22[0x1f] = uVar6;
          puVar17 = puVar17 + 0x10;
          lVar29 = lVar29 + -1;
          puVar22 = puVar22 + 0x20;
        } while (lVar29 != 0);
        *(undefined4 **)(&stack0xffffffffffffffe8 + lVar15) = auStack_4db8;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102bb5;
        func_0x(&puStack_4a88,&psStack_5258,&psStack_5230,0);
      }
    }
LAB_:
    *(byte *)puVar19 = *(byte *)puVar19 & 0xfb;
    *(byte *)puVar19 = *(byte *)puVar19 | 1;
    lVar29 = 2;
    puVar22 = puVar19;
    puVar25 = auStack_4cb8;
    do {
      uVar3 = puVar22[1];
      uVar5 = puVar22[2];
      uVar6 = puVar22[3];
      *puVar25 = *puVar22;
      puVar25[1] = uVar3;
      puVar25[2] = uVar5;
      puVar25[3] = uVar6;
      uVar3 = puVar22[5];
      uVar5 = puVar22[6];
      uVar6 = puVar22[7];
      puVar25[4] = puVar22[4];
      puVar25[5] = uVar3;
      puVar25[6] = uVar5;
      puVar25[7] = uVar6;
      uVar3 = puVar22[9];
      uVar5 = puVar22[10];
      uVar6 = puVar22[0xb];
      puVar25[8] = puVar22[8];
      puVar25[9] = uVar3;
      puVar25[10] = uVar5;
      puVar25[0xb] = uVar6;
      uVar3 = puVar22[0xd];
      uVar5 = puVar22[0xe];
      uVar6 = puVar22[0xf];
      puVar25[0xc] = puVar22[0xc];
      puVar25[0xd] = uVar3;
      puVar25[0xe] = uVar5;
      puVar25[0xf] = uVar6;
      uVar3 = puVar22[0x11];
      uVar5 = puVar22[0x12];
      uVar6 = puVar22[0x13];
      puVar25[0x10] = puVar22[0x10];
      puVar25[0x11] = uVar3;
      puVar25[0x12] = uVar5;
      puVar25[0x13] = uVar6;
      uVar3 = puVar22[0x15];
      uVar5 = puVar22[0x16];
      uVar6 = puVar22[0x17];
      puVar25[0x14] = puVar22[0x14];
      puVar25[0x15] = uVar3;
      puVar25[0x16] = uVar5;
      puVar25[0x17] = uVar6;
      uVar3 = puVar22[0x19];
      uVar5 = puVar22[0x1a];
      uVar6 = puVar22[0x1b];
      puVar25[0x18] = puVar22[0x18];
      puVar25[0x19] = uVar3;
      puVar25[0x1a] = uVar5;
      puVar25[0x1b] = uVar6;
      uVar3 = puVar22[0x1d];
      uVar5 = puVar22[0x1e];
      uVar6 = puVar22[0x1f];
      puVar25[0x1c] = puVar22[0x1c];
      puVar25[0x1d] = uVar3;
      puVar25[0x1e] = uVar5;
      puVar25[0x1f] = uVar6;
      puVar22 = puVar22 + 0x20;
      lVar29 = lVar29 + -1;
      puVar25 = puVar25 + 0x20;
    } while (lVar29 != 0);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102c4c;
    iVar13 = func_0x(&puStack_4a88,&psStack_5258,auStack_4cb8,0);
    if (iVar13 != 0) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102c76;
      (*_DAT_)(1,0x1a08ad8,0x19de538,0x13c4);
    }
    param_1 = (longlong)pplStack_5288;
    *(uint *)((longlong)pplStack_5288 + 0x634) =
         *(uint *)((longlong)pplStack_5288 + 0x634) & 0xfffffffe;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102c99;
    func_0x(pplStack_5288,&puStack_4a88,0);
    *(uint *)(param_1 + 0x634) = *(uint *)(param_1 + 0x634) | 1;
    *(byte *)puVar19 = *(byte *)puVar19 & 0xf8;
    lVar29 = 2;
    puVar22 = puVar19;
    puVar25 = auStack_4bb8;
    do {
      uVar3 = puVar22[1];
      uVar5 = puVar22[2];
      uVar6 = puVar22[3];
      *puVar25 = *puVar22;
      puVar25[1] = uVar3;
      puVar25[2] = uVar5;
      puVar25[3] = uVar6;
      uVar3 = puVar22[5];
      uVar5 = puVar22[6];
      uVar6 = puVar22[7];
      puVar25[4] = puVar22[4];
      puVar25[5] = uVar3;
      puVar25[6] = uVar5;
      puVar25[7] = uVar6;
      uVar3 = puVar22[9];
      uVar5 = puVar22[10];
      uVar6 = puVar22[0xb];
      puVar25[8] = puVar22[8];
      puVar25[9] = uVar3;
      puVar25[10] = uVar5;
      puVar25[0xb] = uVar6;
      uVar3 = puVar22[0xd];
      uVar5 = puVar22[0xe];
      uVar6 = puVar22[0xf];
      puVar25[0xc] = puVar22[0xc];
      puVar25[0xd] = uVar3;
      puVar25[0xe] = uVar5;
      puVar25[0xf] = uVar6;
      uVar3 = puVar22[0x11];
      uVar5 = puVar22[0x12];
      uVar6 = puVar22[0x13];
      puVar25[0x10] = puVar22[0x10];
      puVar25[0x11] = uVar3;
      puVar25[0x12] = uVar5;
      puVar25[0x13] = uVar6;
      uVar3 = puVar22[0x15];
      uVar5 = puVar22[0x16];
      uVar6 = puVar22[0x17];
      puVar25[0x14] = puVar22[0x14];
      puVar25[0x15] = uVar3;
      puVar25[0x16] = uVar5;
      puVar25[0x17] = uVar6;
      uVar3 = puVar22[0x19];
      uVar5 = puVar22[0x1a];
      uVar6 = puVar22[0x1b];
      puVar25[0x18] = puVar22[0x18];
      puVar25[0x19] = uVar3;
      puVar25[0x1a] = uVar5;
      puVar25[0x1b] = uVar6;
      uVar3 = puVar22[0x1d];
      uVar5 = puVar22[0x1e];
      uVar6 = puVar22[0x1f];
      puVar25[0x1c] = puVar22[0x1c];
      puVar25[0x1d] = uVar3;
      puVar25[0x1e] = uVar5;
      puVar25[0x1f] = uVar6;
      puVar22 = puVar22 + 0x20;
      lVar29 = lVar29 + -1;
      puVar25 = puVar25 + 0x20;
    } while (lVar29 != 0);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102d30;
    iVar13 = func_0x(&puStack_4a88,&psStack_5230,auStack_4bb8,param_5);
    if (iVar13 == 0) {
      if (iStack_49c8 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102f37;
        func_0x(&puStack_4a88);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102f44;
        (*_DAT_)(uStack_49c0);
        uStack_49c0 = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102f57;
        func_0x(puStack_4a88);
        puStack_4a88 = (undefined8 *)0x0;
        iStack_49c8 = 0;
      }
      pplStack_5288 = &plStack_4a60;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102f7c;
      func_0x(&plStack_4a60);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102f8b;
      func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15));
      return;
    }
    if (plStack_4a60 == (longlong *)0x0) {
      if (iStack_49c8 != 2) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102d63;
        func_0x(&puStack_4a88,1);
        if (iStack_49c8 != 2) {
          lVar29 = *plStack_4a60;
          goto LAB_;
        }
      }
      lVar29 = 0;
    }
    else {
      lVar29 = *plStack_4a60;
    }
LAB_:
    uVar3 = *(undefined4 *)(lVar29 + 0x20);
    iVar13 = (int)(short)uStack_4a68;
    uVar11 = *(ushort *)(lVar29 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102d9d;
    func_0x(0x18630d0,uVar11);
    if ((CONCAT44(uStack_4a74,uStack_4a78) != CONCAT44(uRam0000000001f7a76c,_DAT_)) ||
       (CONCAT44(uStack_4a6c,uStack_4a70) != CONCAT44(uRam0000000001f7a774,_DAT_))) {
      if ((bStack_4a18 & 2) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102dd6;
        iVar14 = func_0x(auStack_4a10);
        if (iVar14 != 0) {
          puStack_4a88[6] = puStack_4a88[6] + -1;
        }
      }
      bStack_4a18 = 0;
      uStack_4a1c = 0;
      uStack_4a00 = 0;
      if ((bStack_49e8 & 2) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e0f;
        iVar14 = func_0x(auStack_49e0);
        if (iVar14 != 0) {
          puStack_4a88[6] = puStack_4a88[6] + -1;
        }
      }
      bStack_49e8 = 0;
      uStack_49ec = 0;
      uStack_49d0 = 0;
      if (plStack_4a60 != (longlong *)0x0) {
        uStack_4a54 = uStack_4a54 & 0xff000000;
        plStack_4a60 = (longlong *)0x0;
        *(undefined4 *)(CONCAT44(uStack_4a74,uStack_4a78) + 0x48) = 0;
      }
      uVar21 = *puStack_4a88;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e74;
      func_0x(uVar21,&uStack_4a78);
      uStack_4a78 = _DAT_;
      uStack_4a74 = uRam0000000001f7a76c;
      uStack_4a70 = _DAT_;
      uStack_4a6c = uRam0000000001f7a774;
      uStack_4a68 = 0xffffffff;
      uStack_4848 = 0;
      uStack_4830 = 0;
      uStack_4838 = 0;
      uStack_4828 = 0;
      uStack_4818 = 0xffffffff;
      uStack_4814 = 0xffff;
      uStack_4812 = 0;
      iStack_49c8 = 2;
    }
    plVar18 = plStack_5290;
    *(uint *)(param_1 + 0x634) = *(uint *)(param_1 + 0x634) | 1;
    iStack_52e8 = iStack_52e8 + 1;
    uVar27 = *(uint *)(&stack0x0000003c + lVar15);
    if (iStack_52e8 == 10) {
      *(int *)(&stack0xfffffffffffffff8 + lVar15) = iVar13;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar15) = uVar3;
      *(uint *)(&stack0xffffffffffffffe8 + lVar15) = (uint)uVar11;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102f1d;
      (*_DAT_)(0xdc);
    }
  } while( true );
}

