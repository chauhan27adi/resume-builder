
/* WARNING: Control flow encountered bad instruction data */

void FUN_(short *param_1,short *param_2)

{
  ushort uVar1;
  short sVar2;
  byte *pbVar3;
  byte bVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  ulonglong uVar8;
  ushort *puVar9;
  
  if (*param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_2 + 2) == 0) {
    pbVar3 = *(byte **)(param_2 + 4);
    param_2[1] = 0;
    uVar6 = *(uint *)(param_2 + 8);
    uVar8 = (ulonglong)uVar6;
    *(uint *)(param_2 + 10) = uVar6;
    bVar4 = *pbVar3;
    if ((bVar4 & 0x10) != 0) {
      uVar6 = uVar6 + 2 + (*(ushort *)(pbVar3 + uVar8) + 7 >> 3);
      uVar8 = (ulonglong)uVar6;
      *(uint *)(param_2 + 10) = uVar6;
      bVar4 = *pbVar3;
    }
    if ((bVar4 & 0x20) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar9 = (ushort *)(pbVar3 + uVar8);
    uVar1 = *puVar9;
    param_2[0xe] = uVar1;
    if (uVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar6 = (int)uVar8 + (uVar1 + 1) * 2;
    *(uint *)(param_2 + 0xc) = uVar6;
    if (0x1f9e < uVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar7 = puVar9[uVar1] & 0x7fff;
    *(uint *)(param_2 + 2) = uVar7;
    if (uVar7 < uVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((short)puVar9[(ulonglong)(uVar1 - 1) + 1] < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((**(byte **)(param_2 + 4) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(param_2 + 0x13) = 0;
    if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
       (*(ulonglong *)(param_2 + 0xf) < (ulonglong)uVar7 + *(longlong *)(param_2 + 4))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (0x3f3b < uVar7 - 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (*(uint *)(param_2 + 2) < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (0x7ff < *(uint *)(param_2 + 2)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  sVar2 = *param_2;
  *param_1 = sVar2;
  if (sVar2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_2 + 2) != 0) {
    uVar6 = *(uint *)(param_2 + 2);
    if (uVar6 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_2 + 8);
    param_1[1] = param_2[1];
    *(undefined4 *)(param_1 + 2) = *(undefined4 *)(param_2 + 2);
    param_1[0xe] = param_2[0xe];
    *(undefined4 *)(param_1 + 10) = *(undefined4 *)(param_2 + 10);
    *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0xc);
    *(undefined4 *)(param_1 + 0x13) = *(undefined4 *)(param_2 + 0x13);
    func_0x(param_1 + 0x1a,0x800,*(undefined8 *)(param_2 + 4),uVar6);
    *(short **)(param_1 + 4) = param_1 + 0x1a;
    iVar5 = func_0x(param_1 + 1);
    if (iVar5 == 0) {
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

