
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2)

{
  ushort uVar1;
  undefined2 uVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  char cVar7;
  byte bVar8;
  int iVar9;
  undefined2 *puVar10;
  uint *puVar11;
  undefined8 uVar12;
  ushort *puVar13;
  
  (*_DAT_)(param_2 + 0x2b0,param_2 + 0x4f8);
  func_0x(*(undefined8 *)(param_2 + 0x290));
  if (*(longlong *)(param_2 + 0xa8) != 0) {
    puVar13 = (ushort *)(*(longlong *)(param_2 + 0xa8) + 0x62);
    *(ushort **)(param_2 + 0x410) = puVar13;
    uVar1 = *puVar13;
    *(ushort *)(param_2 + 0x198) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)(param_2 + 0xb4) < 3)) {
      *(int *)(param_2 + 0x68) = (int)*(short *)(param_2 + 0xb4);
      *(undefined8 *)(param_2 + 0x138) = *(undefined8 *)(param_2 + 0xa8);
      *(ushort **)(param_2 + 0x418) = puVar13;
      uVar1 = *puVar13;
      *(ushort *)(param_2 + 0x1a0) = uVar1;
      if (((byte)uVar1 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0x68) == 3) {
          *(undefined4 *)(param_2 + 0x68) = 4;
        }
        else if (*(int *)(param_2 + 0x68) < 2) goto LAB_;
        puVar11 = (uint *)(*(longlong *)(param_2 + 0xa8) + 100);
        *(uint **)(param_2 + 0x420) = puVar11;
        uVar3 = *puVar11;
        *(uint *)(param_2 + 0x248) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0xa8) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x428) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0xa8),
                     *(undefined4 *)(param_2 + 0x68));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x200) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0xcb) = -cVar7;
      if (-cVar7 != '\0') {
        puVar11 = (uint *)(*(longlong *)(param_2 + 0x138) + 100);
        *(uint **)(param_2 + 0x430) = puVar11;
        uVar3 = *puVar11;
        *(uint *)(param_2 + 0x208) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0x68))) {
          *(uint **)(param_2 + 0x470) = puVar11;
          uVar3 = *puVar11;
          *(uint *)(param_2 + 0x210) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0x138), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 0x218) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 0x21c);
            if (iVar9 != 0) {
              LOCK();
              *puVar11 = *puVar11 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar11 = *puVar11 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0x138);
      uVar4 = *(undefined4 *)(param_2 + 0x68);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x220) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0xcc) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)(param_2 + 0xb4) = *(uint *)(param_2 + 0xb4) & 0xffff0000;
      *(undefined8 *)(param_2 + 0xa8) = 0;
    }
    else {
      func_0x(param_2 + 0xa8);
    }
  }
  plVar5 = *(longlong **)(param_2 + 0x298);
  if (*plVar5 == 0) goto LAB_;
  puVar13 = (ushort *)(*plVar5 + 0x62);
  *(ushort **)(param_2 + 0x440) = puVar13;
  uVar1 = *puVar13;
  *(ushort *)(param_2 + 0x1b0) = uVar1;
  if (((uVar1 >> 10 & 1) != 0) && (2 < *(short *)((longlong)plVar5 + 0xc))) {
    func_0x(plVar5);
    goto LAB_;
  }
  *(int *)(param_2 + 0x80) = (int)*(short *)((longlong)plVar5 + 0xc);
  lVar6 = *plVar5;
  *(longlong *)(param_2 + 0x88) = lVar6;
  puVar10 = (undefined2 *)(lVar6 + 0x62);
  *(undefined2 **)(param_2 + 0x448) = puVar10;
  uVar2 = *puVar10;
  *(undefined2 *)(param_2 + 0x1b8) = uVar2;
  if (((byte)uVar2 >> 3 & 1) != 0) {
    if (*(int *)(param_2 + 0x80) == 3) {
      *(undefined4 *)(param_2 + 0x80) = 4;
    }
    else if (*(int *)(param_2 + 0x80) < 2) goto LAB_;
    puVar11 = (uint *)(*(longlong *)(param_2 + 0x88) + 100);
    *(uint **)(param_2 + 0x450) = puVar11;
    uVar3 = *puVar11;
    *(uint *)(param_2 + 0x228) = uVar3;
    if ((((uVar3 & 8) != 0) &&
        (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0x88) + 0x90), lVar6 != 0)) &&
       (*(longlong *)(param_2 + 0x458) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
      func_0x
                (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0x88),
                 *(undefined4 *)(param_2 + 0x80));
    }
  }
LAB_:
  cVar7 = DAT_ >> 7;
  *(char *)(param_2 + 0xcd) = -cVar7;
  if (-cVar7 != '\0') {
    puVar11 = (uint *)(*(longlong *)(param_2 + 0x88) + 100);
    *(uint **)(param_2 + 0x460) = puVar11;
    uVar3 = *puVar11;
    *(uint *)(param_2 + 0x230) = uVar3;
    if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0x80))) {
      *(uint **)(param_2 + 0x468) = puVar11;
      uVar3 = *puVar11;
      *(uint *)(param_2 + 0x238) = uVar3;
      if (((uVar3 & 0xc0000000) != 0x40000000) && (**(longlong **)(param_2 + 0x88) != 0)) {
        iVar9 = (*_DAT_)(**(longlong **)(param_2 + 0x88),0x2000,2,param_2 + 0x240);
        if (iVar9 != 0) {
          LOCK();
          *puVar11 = *puVar11 & 0x3fffffff;
          UNLOCK();
          LOCK();
          *puVar11 = *puVar11 | 0x40000000;
          UNLOCK();
        }
      }
    }
  }
  lVar6 = *(longlong *)(param_2 + 0x88);
  uVar4 = *(undefined4 *)(param_2 + 0x80);
  func_0x(lVar6 + 0x98,uVar4);
  if ((_DAT_ != 0) && ((DAT_ >> 1 & 1) != 0)) {
    func_0x(lVar6,0,uVar4);
  }
  *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
  *plVar5 = 0;
LAB_:
  uVar12 = (*_DAT_)(param_2 + 0x2b0);
  (*_DAT_)(uVar12);
  (*_DAT_)(param_2 + 0x2b0);
  return 0xfffffffffe0736c8;
}

