
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2)

{
  undefined4 uVar1;
  longlong lVar2;
  int iVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong unaff_GS_OFFSET;
  undefined auStack_88 [32];
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  ulonglong uStack_28;
  
  uStack_28 = _DAT_ ^ (ulonglong)auStack_88;
  if (param_2 == 6) {
    iVar3 = *(int *)(param_1 + 0x38);
    if (iVar3 == 0xc) goto LAB_;
    *(uint *)(param_1 + 0x24) = *(uint *)(param_1 + 0x24) | 0x1000;
    lVar6 = *(longlong *)(param_1 + 0x40);
    *(undefined4 *)(param_1 + 0x38) = 0xc;
    if (iVar3 == 4) {
      *(int *)(lVar6 + 0xbc) = *(int *)(lVar6 + 0xbc) + 1;
    }
    *(undefined *)(lVar6 + 0xc0) = 0;
    if (*(uint *)(lVar6 + 0xb8) < *(uint *)(lVar6 + 0xbc)) {
      uStack_68 = 0;
      (*_DAT_)(1,0xff42c8,0xfa6b90,0x1d80);
    }
    switch(*(undefined4 *)(param_1 + 0x38)) {
    case 4:
code_r0x001003b3:
      if (*piRam0000000000a9d780 == 0) {
        *(ulonglong *)(param_1 + 0x90) = uRam000000007ffe0008;
      }
      else {
        (*pcRam0000000000a9b658)(&uStack_38);
        *(ulonglong *)(param_1 + 0x90) = CONCAT44(uStack_34,uStack_38);
      }
    default:
      goto LAB_;
    case 6:
      uVar5 = uRam000000007ffe0008;
      if (*piRam0000000000a9d780 != 0) {
        (*pcRam0000000000a9b658)(&uStack_38);
        uVar5 = CONCAT44(uStack_34,uStack_38);
      }
      if (uVar5 < *(ulonglong *)(param_1 + 0x90)) {
        uVar5 = 0;
code_r0x00100441:
        if (*piRam0000000000a9d780 == 0) {
          uVar5 = uVar5 / 10000;
        }
        else {
          uVar5 = (uVar5 * 1000) / *puRam0000000000a9d788;
        }
      }
      else {
        uVar5 = uVar5 - *(ulonglong *)(param_1 + 0x90);
        if (uVar5 != 0xffffffffffffffff) goto code_r0x00100441;
        uVar5 = 0xffffffffffffffff;
      }
      *(ulonglong *)(param_1 + 0x98) = uVar5;
      if ((((bRam000000000153fcdf & 0x20) == 0) &&
          (((lVar6 = *(longlong *)
                      ((ulonglong)*puRam0000000000a9e060 +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                       (ulonglong)*puRam0000000000a9e058 * 8)), lVar6 == 0 ||
            (lVar6 = **(longlong **)(lVar6 + 0x38), lVar6 == 0)) ||
           (iVar3 = (*pcRam0000000000a9e010)(lVar6,0xd7d), iVar3 == 0)))) &&
         (iRam0000000001537520 == 0)) goto LAB_;
      uStack_48 = *(undefined8 *)(param_1 + 0x98);
      uStack_50 = 0xec91f0;
      uStack_58 = 0xbbb;
      break;
    case 7:
    case 9:
code_r0x001000fa:
      if (*piRam0000000000a9d780 == 0) {
        *(ulonglong *)(param_1 + 0xa0) = uRam000000007ffe0008;
      }
      else {
        (*pcRam0000000000a9b658)(&uStack_38);
        *(ulonglong *)(param_1 + 0xa0) = CONCAT44(uStack_34,uStack_38);
      }
      goto LAB_;
    case 0xb:
code_r0x001004fb:
      uVar4 = 0xec92d0;
      if (iVar3 == 7) {
        uVar4 = 0xec92a8;
      }
      uVar5 = uRam000000007ffe0008;
      if (*piRam0000000000a9d780 != 0) {
        (*pcRam0000000000a9b658)(&uStack_38);
        uVar5 = CONCAT44(uStack_34,uStack_38);
      }
      if (uVar5 < *(ulonglong *)(param_1 + 0xa0)) {
        uVar5 = 0;
code_r0x00100550:
        if (*piRam0000000000a9d780 == 0) {
          uVar5 = uVar5 / 10000;
        }
        else {
          uVar5 = (uVar5 * 1000) / *puRam0000000000a9d788;
        }
      }
      else {
        uVar5 = uVar5 - *(ulonglong *)(param_1 + 0xa0);
        if (uVar5 != 0xffffffffffffffff) goto code_r0x00100550;
        uVar5 = 0xffffffffffffffff;
      }
      *(ulonglong *)(param_1 + 0xa8) = uVar5;
      if ((((bRam000000000153fcdf & 0x20) == 0) &&
          (((lVar6 = *(longlong *)
                      ((ulonglong)*puRam0000000000a9e060 +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                       (ulonglong)*puRam0000000000a9e058 * 8)), lVar6 == 0 ||
            (lVar6 = **(longlong **)(lVar6 + 0x38), lVar6 == 0)) ||
           (iVar3 = (*pcRam0000000000a9e010)(lVar6,0xd7d), iVar3 == 0)))) &&
         (iRam0000000001537520 == 0)) goto LAB_;
      uStack_48 = *(undefined8 *)(param_1 + 0xa8);
      uStack_58 = 0xbc9;
      uStack_50 = uVar4;
      break;
    case 0xe:
code_r0x0010022f:
      uVar5 = uRam000000007ffe0008;
      if (*piRam0000000000a9d780 != 0) {
        (*pcRam0000000000a9b658)(&uStack_38);
        uVar5 = CONCAT44(uStack_34,uStack_38);
      }
      if (uVar5 < *(ulonglong *)(param_1 + 0x90)) {
        uVar5 = 0;
code_r0x0010026f:
        if (*piRam0000000000a9d780 == 0) {
          uVar5 = uVar5 / 10000;
        }
        else {
          uVar5 = (uVar5 * 1000) / *puRam0000000000a9d788;
        }
      }
      else {
        uVar5 = uVar5 - *(ulonglong *)(param_1 + 0x90);
        if (uVar5 != 0xffffffffffffffff) goto code_r0x0010026f;
        uVar5 = 0xffffffffffffffff;
      }
      *(ulonglong *)(param_1 + 0x98) = uVar5;
      if ((((bRam000000000153fcdf & 0x20) == 0) &&
          (((lVar6 = *(longlong *)
                      ((ulonglong)*puRam0000000000a9e060 +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                       (ulonglong)*puRam0000000000a9e058 * 8)), lVar6 == 0 ||
            (lVar6 = **(longlong **)(lVar6 + 0x38), lVar6 == 0)) ||
           (iVar3 = (*pcRam0000000000a9e010)(lVar6,0xd7d), iVar3 == 0)))) &&
         (iRam0000000001537520 == 0)) goto LAB_;
      uStack_48 = *(undefined8 *)(param_1 + 0x98);
      uStack_50 = 0xec9260;
      uStack_58 = 0xbc1;
    }
    lVar6 = *(longlong *)(param_1 + 0x10);
    uStack_38 = *(undefined4 *)(lVar6 + 8);
    uStack_34 = *(undefined4 *)(lVar6 + 0xc);
    uStack_30 = *(undefined4 *)(lVar6 + 0x10);
    uStack_2c = *(undefined4 *)(lVar6 + 0x14);
    uVar1 = *(undefined4 *)(lVar6 + 0x18);
code_r0x0010060a:
    lVar6 = *(longlong *)(param_1 + 0x40);
    uStack_60 = 0x3a;
    uVar4 = 1;
    uStack_68 = 0xec9218;
  }
  else {
    if (param_2 == 0x10) {
      iVar3 = *(int *)(param_1 + 0x38);
      if (iVar3 == 0xb) goto LAB_;
      *(uint *)(param_1 + 0x24) = *(uint *)(param_1 + 0x24) | 0x800;
      *(undefined4 *)(param_1 + 0x38) = 0xb;
      lVar6 = *(longlong *)(param_1 + 0x40);
      *(int *)(lVar6 + 0xc4) = *(int *)(lVar6 + 0xc4) + 1;
      if (*(uint *)(lVar6 + 0xb8) < *(uint *)(lVar6 + 0xbc)) {
        uStack_68 = 0;
        (*_DAT_)(1,0xff42c8,0xfa6b90,0x1d80);
      }
      switch(*(undefined4 *)(param_1 + 0x38)) {
      case 4:
        goto code_r0x001003b3;
      default:
        goto LAB_;
      case 6:
        goto code_r0x00100124;
      case 7:
      case 9:
        goto code_r0x001000fa;
      case 0xb:
        goto code_r0x001004fb;
      case 0xe:
        goto code_r0x0010022f;
      }
    }
    lVar2 = *(longlong *)(param_1 + 0x10);
    lVar6 = *(longlong *)(param_1 + 0x40);
    uStack_48 = CONCAT44(uStack_48._4_4_,param_2);
    uStack_50 = 0xec92f8;
    uStack_38 = *(undefined4 *)(lVar2 + 8);
    uStack_34 = *(undefined4 *)(lVar2 + 0xc);
    uStack_30 = *(undefined4 *)(lVar2 + 0x10);
    uStack_2c = *(undefined4 *)(lVar2 + 0x14);
    uStack_58 = 0xd94;
    uStack_60 = 0x44;
    uVar1 = *(undefined4 *)(lVar2 + 0x18);
    uStack_68 = 0xeca300;
    uVar4 = 3;
  }
  (*_DAT_)(uVar4,lVar6 + 200,&uStack_38,uVar1);
LAB_:
  func_0x(uStack_28 ^ (ulonglong)auStack_88);
  return;
code_r0x00100124:
  uVar5 = uRam000000007ffe0008;
  if (*piRam0000000000a9d780 != 0) {
    (*pcRam0000000000a9b658)(&uStack_38);
    uVar5 = CONCAT44(uStack_34,uStack_38);
  }
  if (uVar5 < *(ulonglong *)(param_1 + 0x90)) {
    uVar5 = 0;
code_r0x00100164:
    if (*piRam0000000000a9d780 == 0) {
      uVar5 = uVar5 / 10000;
    }
    else {
      uVar5 = (uVar5 * 1000) / *puRam0000000000a9d788;
    }
  }
  else {
    uVar5 = uVar5 - *(ulonglong *)(param_1 + 0x90);
    if (uVar5 != 0xffffffffffffffff) goto code_r0x00100164;
    uVar5 = 0xffffffffffffffff;
  }
  *(ulonglong *)(param_1 + 0x98) = uVar5;
  if ((((bRam000000000153fcdf & 0x20) == 0) &&
      (((lVar6 = *(longlong *)
                  ((ulonglong)*puRam0000000000a9e060 +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam0000000000a9e058 * 8)),
        lVar6 == 0 || (lVar6 = **(longlong **)(lVar6 + 0x38), lVar6 == 0)) ||
       (iVar3 = (*pcRam0000000000a9e010)(lVar6,0xd7d), iVar3 == 0)))) && (iRam0000000001537520 == 0)
     ) goto LAB_;
  lVar6 = *(longlong *)(param_1 + 0x10);
  uStack_48 = *(undefined8 *)(param_1 + 0x98);
  uStack_50 = 0xec91f0;
  uStack_38 = *(undefined4 *)(lVar6 + 8);
  uStack_34 = *(undefined4 *)(lVar6 + 0xc);
  uStack_30 = *(undefined4 *)(lVar6 + 0x10);
  uStack_2c = *(undefined4 *)(lVar6 + 0x14);
  uStack_58 = 0xbbb;
  uVar1 = *(undefined4 *)(lVar6 + 0x18);
  goto code_r0x0010060a;
}

