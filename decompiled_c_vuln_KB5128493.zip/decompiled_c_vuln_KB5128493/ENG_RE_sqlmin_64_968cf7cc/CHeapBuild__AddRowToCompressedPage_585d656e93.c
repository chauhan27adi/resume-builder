
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2)

{
  undefined2 uVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  uint6 uVar5;
  ushort uVar6;
  int iVar7;
  longlong lVar8;
  ulonglong *puVar9;
  undefined8 uVar10;
  longlong lVar11;
  byte bVar12;
  ulonglong uVar13;
  longlong *plVar14;
  undefined4 *puVar15;
  ushort uVar16;
  uint uVar17;
  uint uVar18;
  ulonglong uVar19;
  undefined8 unaff_RBX;
  ushort *puVar20;
  longlong lVar21;
  longlong lVar22;
  byte *pbVar23;
  longlong *plVar24;
  short *psVar25;
  longlong unaff_GS_OFFSET;
  longlong lStackX_8;
  undefined4 uStackX_10;
  undefined2 auStackX_14 [6];
  short *psStackX_20;
  undefined8 uStack_2bb8;
  undefined *puStack_2bb0;
  undefined2 auStack_2ba8 [2];
  undefined4 uStack_2ba4;
  undefined8 uStack_2ba0;
  undefined8 uStack_2b98;
  undefined8 uStack_2b8a;
  undefined8 uStack_2b80;
  undefined8 uStack_2b70;
  undefined auStack_2b68 [8];
  undefined4 uStack_2b60;
  undefined4 uStack_2b58;
  undefined4 **ppuStack_2b50;
  undefined *puStack_2b48;
  undefined8 uStack_2b40;
  undefined4 *puStack_2b38;
  undefined8 uStack_2b30;
  undefined auStack_2b28 [528];
  undefined8 uStack_2918;
  undefined8 uStack_2910;
  undefined4 uStack_2908;
  uint uStack_2904;
  undefined2 uStack_2900;
  undefined4 uStack_28fe;
  undefined8 uStack_28fa;
  undefined8 uStack_28f2;
  undefined auStack_28e8 [8];
  undefined4 uStack_28e0;
  undefined4 uStack_28d8;
  undefined4 **ppuStack_28d0;
  undefined *puStack_28c8;
  undefined8 uStack_28c0;
  undefined4 *puStack_28b8;
  undefined8 uStack_28b0;
  undefined auStack_28a8 [528];
  undefined8 uStack_2698;
  undefined8 uStack_2690;
  undefined4 uStack_2688;
  uint uStack_2684;
  undefined2 uStack_2680;
  undefined4 uStack_267e;
  undefined8 uStack_267a;
  undefined8 uStack_2672;
  undefined auStack_2668 [8];
  undefined4 uStack_2660;
  undefined4 uStack_2658;
  uint **ppuStack_2650;
  undefined *puStack_2648;
  undefined8 uStack_2640;
  uint *puStack_2638;
  undefined8 uStack_2630;
  undefined auStack_2628 [528];
  undefined8 uStack_2418;
  undefined8 uStack_2410;
  uint uStack_2408;
  undefined2 uStack_2404;
  undefined4 uStack_2402;
  longlong lStack_23fe;
  char cStack_23f6;
  undefined auStack_23e8 [9120];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  uStack_2b70 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002c18 + lVar8) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar8);
  auStack_2ba8[0] = 0xffff;
  plVar24 = (longlong *)0x0;
  uStack_2ba0 = 0;
  uStack_2ba4 = 0;
  uStack_2b8a = 0;
  uStack_2b80 = 0;
  uStack_2b98 = 0;
  *(undefined8 *)((longlong)&psStackX_20 + lVar8) = param_2;
  *(undefined2 **)(&stack0x00000028 + lVar8) = auStack_2ba8;
  *(undefined **)(&stack0x00000030 + lVar8) = auStack_23e8;
  *(undefined4 *)(&stack0x00000038 + lVar8) = 0x239e;
  *(longlong *)(&stack0x00000040 + lVar8) = param_1 + 600;
  lVar22 = *(longlong *)(param_1 + 0x250);
  uVar6 = *(ushort *)(lVar22 + 0x1c);
  plVar14 = (longlong *)(ulonglong)(uVar6 - 2);
  if (uVar6 < 3) {
    plVar14 = plVar24;
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1000ba;
  iVar7 = func_0x(lVar22,(longlong)&psStackX_20 + lVar8,plVar14,0);
  if (iVar7 == 0) {
    uVar2 = *(undefined8 *)(param_1 + 8);
    lVar22 = *(longlong *)(param_1 + 0x250);
    if (lVar22 == 0) {
      puVar15 = (undefined4 *)(_DAT_ + 0x70);
    }
    else {
      puVar15 = (undefined4 *)(lVar22 + 0x20);
    }
    uVar5 = *(uint6 *)(param_1 + 0x24);
    uVar1 = *(undefined2 *)(*(longlong *)(param_1 + 0x30) + 0x6b8);
    *(undefined8 *)((longlong)&lStackX_8 + lVar8) = 0xffffffffffffffff;
    *(undefined2 *)((longlong)auStackX_14 + lVar8 + 2) = 0;
    if ((_DAT_ & 0x1000) == 0) {
      *(longlong *)((longlong)&psStackX_20 + lVar8 + -0x20) = (longlong)&lStackX_8 + lVar8;
      puStack_2bb0 = &stack0xfffffffffffffff8 + lVar8;
    }
    else {
      *(ulonglong *)((longlong)&lStackX_8 + lVar8) = (ulonglong)uVar5 << 0x10;
      *(undefined2 *)((longlong)auStackX_14 + lVar8 + 4) = uVar1;
      *(undefined4 *)((longlong)&uStackX_10 + lVar8) = *puVar15;
      *(undefined2 *)((longlong)auStackX_14 + lVar8) = *(undefined2 *)(puVar15 + 1);
      *(longlong *)((longlong)&psStackX_20 + lVar8 + -0x20) = (longlong)&lStackX_8 + lVar8;
      puStack_2bb0 = &stack0xfffffffffffffff8 + lVar8;
      uVar10 = _DAT_;
      if (*_DAT_ != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100800;
        (*_DAT_)(&uStack_2bb8);
        uVar10 = uStack_2bb8;
      }
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar8) = uVar10;
      uStack_2b60 = 0x10000;
      uStack_2b58 = 0;
      ppuStack_2b50 = &puStack_2b38;
      puStack_2b48 = auStack_2b28;
      uStack_2918 = 0;
      uStack_2b40 = 0;
      uStack_2910 = 0;
      puStack_2b38 = &uStack_2908;
      uStack_2b30 = 0x1e;
      uStack_2908 = 0;
      uStack_28f2 = 0;
      puVar3 = *(undefined8 **)((longlong)&psStackX_20 + lVar8 + -0x20);
      uStack_28fa = *puVar3;
      uStack_2900 = *(undefined2 *)((longlong)puVar3 + 0xc);
      uStack_28fe = *(undefined4 *)(puVar3 + 1);
      uStack_2904 = (uint)*(ushort *)(puVar3 + 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100897;
      func_0x(auStack_2b68);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar8) = 0;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar8) = param_1 + 0x330;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1008ce;
    iVar7 = func_0x(lVar22,0,param_1 + 0x10,uVar2);
    if ((_DAT_ >> 0xc & 1) != 0) {
      uStack_28e0 = 0x10000;
      uStack_28d8 = 0;
      ppuStack_28d0 = &puStack_28b8;
      puStack_28c8 = auStack_28a8;
      uStack_2698 = 0;
      uStack_28c0 = 0;
      uStack_2690 = 0;
      puStack_28b8 = &uStack_2688;
      uStack_28b0 = 0x1e;
      uStack_2688 = 1;
      *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10094d;
      uStack_2672 = func_0x(&stack0xfffffffffffffff8 + lVar8);
      puVar3 = *(undefined8 **)((longlong)&psStackX_20 + lVar8 + -0x20);
      uStack_267a = *puVar3;
      uStack_2680 = *(undefined2 *)((longlong)puVar3 + 0xc);
      uStack_267e = *(undefined4 *)(puVar3 + 1);
      uStack_2684 = (uint)*(ushort *)(puVar3 + 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10098d;
      func_0x(auStack_28e8);
    }
    if (iVar7 != 0) {
      if (lVar22 == 0) {
        puVar15 = (undefined4 *)(_DAT_ + 0x70);
      }
      else {
        puVar15 = (undefined4 *)(lVar22 + 0x20);
      }
      if ((_DAT_ >> 0xb & 1) != 0) {
        uStack_2660 = 0x10000;
        uStack_2658 = 0;
        ppuStack_2650 = &puStack_2638;
        puStack_2648 = auStack_2628;
        uStack_2418 = 0;
        uStack_2640 = 0;
        uStack_2410 = 0;
        puStack_2638 = &uStack_2408;
        uStack_2630 = 0x13;
        uStack_2404 = *(undefined2 *)(puVar15 + 1);
        uStack_2402 = *puVar15;
        uStack_2408 = (uint)*(ushort *)(*(longlong *)(param_1 + 0x30) + 0x6b8);
        lStack_23fe = (ulonglong)*(uint6 *)(param_1 + 0x24) << 0x10;
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x101223;
        cStack_23f6 = (char)iVar7;
        func_0x(auStack_2668);
      }
      goto LAB_;
    }
    if (*_DAT_ != (char)iVar7) {
      plVar14 = plVar24;
      if (_DAT_ != 0) {
        plVar14 = (longlong *)(_DAT_ + 0x6800);
      }
      if ((plVar14 != (longlong *)0x0) && (*plVar14 != 0)) {
        LOCK();
        plVar14 = (longlong *)(*plVar14 + 0x150);
        *plVar14 = *plVar14 + 1;
        UNLOCK();
      }
    }
    lVar22 = *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x488);
    if (((lVar22 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar22 + 0x20) != 0) {
        lVar21 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar11 = *(longlong *)(lVar21 + 0x100);
        if (lVar11 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100a44;
          (*_DAT_)(0);
          lVar11 = *(longlong *)(lVar21 + 0x100);
        }
        plVar14 = plVar24;
        if (*(longlong *)(lVar11 + 0x260) != 0) {
          plVar14 = (longlong *)(ulonglong)*(uint *)(*(longlong *)(lVar11 + 0x260) + 0xe68);
        }
        if ((uint)plVar14 < *(uint *)(_DAT_ + 8)) {
          lVar22 = *(longlong *)(*(longlong *)(lVar22 + 0x20) + (longlong)plVar14 * 8);
          *(longlong *)(lVar22 + 0x128) = *(longlong *)(lVar22 + 0x128) + 1;
          goto LAB_;
        }
      }
      LOCK();
      plVar14 = (longlong *)(*(longlong *)(lVar22 + 0x18) + 0x128);
      *plVar14 = *plVar14 + 1;
      UNLOCK();
    }
LAB_:
    puVar3 = *(undefined8 **)(&stack0x00000028 + lVar8);
    puVar3[1] = 0;
    *puVar3 = 0xffff;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[2] = 0;
    *(undefined4 *)(puVar3 + 6) = 0;
    puVar3[5] = 0;
    puVar3 = *(undefined8 **)(&stack0x00000040 + lVar8);
    *puVar3 = 0;
    puVar3[0xc] = 0;
    *(undefined2 *)(puVar3 + 0xd) = 0;
    *(undefined8 *)((longlong)puVar3 + 0x6c) = 1;
    puVar3 = (undefined8 *)puVar3[1];
    if (puVar3 != (undefined8 *)0x0) {
      puVar4 = (undefined8 *)puVar3[1];
      if (puVar4 != (undefined8 *)0x0) {
        *puVar4 = 0;
        *(undefined4 *)(puVar4 + 0x481) = 0;
      }
      puVar3[3] = 0;
      *(undefined2 *)(puVar3 + 4) = 0;
      *puVar3 = 0;
      *(undefined4 *)(puVar3 + 0x14b) = 0;
    }
    lVar22 = *(longlong *)(param_1 + 0x250);
    uVar6 = *(ushort *)(lVar22 + 0x1c);
    plVar14 = (longlong *)(ulonglong)(uVar6 - 2);
    if (uVar6 < 3) {
      plVar14 = plVar24;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100b2c;
    iVar7 = func_0x(lVar22,(longlong)&psStackX_20 + lVar8,plVar14,0);
    if (iVar7 == 0) goto LAB_;
    psVar25 = *(short **)(&stack0x00000028 + lVar8);
    if (-1 < *(char *)(*(longlong *)(param_1 + 0x250) + 2)) {
      psVar25 = *(short **)((longlong)&psStackX_20 + lVar8);
    }
    if (*psVar25 == 0) {
      if (*(int *)(psVar25 + 2) != 0) goto LAB_;
      psVar25[1] = 0;
      uVar17 = *(uint *)(psVar25 + 8);
      uVar19 = (ulonglong)uVar17;
      *(uint *)(psVar25 + 10) = uVar17;
      pbVar23 = *(byte **)(psVar25 + 4);
      bVar12 = *pbVar23;
      if ((bVar12 & 0x10) != 0) {
        uVar17 = uVar17 + 2 + (*(ushort *)(pbVar23 + uVar19) + 7 >> 3);
        uVar19 = (ulonglong)uVar17;
        *(uint *)(psVar25 + 10) = uVar17;
        bVar12 = *pbVar23;
      }
      if ((bVar12 & 0x20) == 0) {
        *(int *)(psVar25 + 2) = (int)uVar19;
        psVar25[0xe] = 0;
        *(int *)(psVar25 + 0xc) = (int)uVar19;
      }
      else {
        puVar20 = (ushort *)(pbVar23 + uVar19);
        uVar6 = *puVar20;
        psVar25[0xe] = uVar6;
        if (uVar6 == 0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar22 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar22 != 0 &&
              ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
               (*(char *)(lVar22 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100c2e;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100c52;
              (*_DAT_)(1,0x127f938,0x139f608,0x80f);
            }
          }
          uVar2 = *(undefined8 *)(psVar25 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100c60;
          func_0x(uVar2,3);
          uVar19 = (ulonglong)*(uint *)(psVar25 + 10);
          uVar6 = psVar25[0xe];
        }
        uVar17 = (int)uVar19 + (uVar6 + 1) * 2;
        *(uint *)(psVar25 + 0xc) = uVar17;
        if (0x1f9e < uVar17) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar22 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar22 != 0)) &&
             ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
              (*(char *)(lVar22 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100d00;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100d24;
              (*_DAT_)(1,0x127f938,0x139f608,0x816);
            }
          }
          uVar2 = *(undefined8 *)(psVar25 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100d32;
          func_0x(uVar2,4);
          uVar6 = psVar25[0xe];
          uVar17 = *(uint *)(psVar25 + 0xc);
        }
        uVar13 = (ulonglong)uVar6;
        uVar18 = puVar20[uVar13] & 0x7fff;
        *(uint *)(psVar25 + 2) = uVar18;
        if (uVar18 < uVar17) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar22 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar22 != 0 &&
              ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
               (*(char *)(lVar22 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100dd0;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100df4;
              (*_DAT_)(1,0x127f938,0x139f608,0x81d);
            }
          }
          uVar2 = *(undefined8 *)(psVar25 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100e02;
          func_0x(uVar2,4);
          uVar13 = (ulonglong)(ushort)psVar25[0xe];
          uVar18 = *(uint *)(psVar25 + 2);
        }
        if ((short)puVar20[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
          lVar22 = *(longlong *)(psVar25 + 4);
          do {
            if ((int)uVar13 == 1) {
              uVar17 = *(uint *)(psVar25 + 0xc);
              uVar18 = uVar17;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(psVar25 + 10) + lVar22 + uVar13 * 2) & 0x7fff) <
                  uVar17) goto LAB_;
            }
            else {
              uVar17 = *(ushort *)((ulonglong)*(uint *)(psVar25 + 10) + lVar22 + -2 + uVar13 * 2) &
                       0x7fff;
              uVar18 = *(uint *)(psVar25 + 0xc);
              if (uVar18 <= uVar17) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100e74;
              func_0x(lVar22,7);
              uVar18 = *(uint *)(psVar25 + 0xc);
            }
            if ((uVar17 < uVar18) ||
               (uVar19 = (ulonglong)*(uint *)(psVar25 + 2), *(uint *)(psVar25 + 2) < uVar17))
            goto LAB_;
            lVar22 = *(longlong *)(psVar25 + 4);
            if (*(ushort *)((ulonglong)uVar17 + lVar22) == 5) {
              psVar25[1] = psVar25[1] | 2;
              psVar25[0xe] = psVar25[0xe] + -1;
              psVar25[0x15] = (short)uVar17;
              lVar22 = (ulonglong)(uVar17 & 0xffff) + *(longlong *)(psVar25 + 4);
              uVar6 = psVar25[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar22 + 2) & 0x4000) != 0) {
                uVar6 = *(ushort *)(lVar22 + 2) & 0x3800 | psVar25[0x16] & 0xc7ffU;
              }
              psVar25[0x16] = uVar6;
              psVar25[0x16] = (uVar6 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar6;
              uVar18 = *(uint *)(psVar25 + 2);
              break;
            }
            if (*(ushort *)((ulonglong)uVar17 + lVar22) < 0x400) goto LAB_;
            psVar25[1] = psVar25[1] | 1;
            uVar6 = psVar25[0xe] - 1;
            psVar25[0xe] = uVar6;
            if ((uVar6 == 0) ||
               (uVar13 = (ulonglong)uVar6, -1 < (short)puVar20[(ulonglong)(uVar6 - 1) + 1]))
            goto LAB_;
          } while( true );
        }
        uVar19 = (ulonglong)uVar18;
        pbVar23 = *(byte **)(psVar25 + 4);
      }
      goto LAB_;
    }
  }
  else {
    psVar25 = *(short **)(&stack0x00000028 + lVar8);
    if (-1 < *(char *)(*(longlong *)(param_1 + 0x250) + 2)) {
      psVar25 = *(short **)((longlong)&psStackX_20 + lVar8);
    }
    if (*psVar25 == 0) {
      if (*(int *)(psVar25 + 2) == 0) {
        psVar25[1] = 0;
        uVar17 = *(uint *)(psVar25 + 8);
        uVar19 = (ulonglong)uVar17;
        *(uint *)(psVar25 + 10) = uVar17;
        pbVar23 = *(byte **)(psVar25 + 4);
        bVar12 = *pbVar23;
        if ((bVar12 & 0x10) != 0) {
          uVar17 = uVar17 + 2 + (*(ushort *)(pbVar23 + uVar19) + 7 >> 3);
          uVar19 = (ulonglong)uVar17;
          *(uint *)(psVar25 + 10) = uVar17;
          bVar12 = *pbVar23;
        }
        if ((bVar12 & 0x20) == 0) {
          *(int *)(psVar25 + 2) = (int)uVar19;
          psVar25[0xe] = 0;
          *(int *)(psVar25 + 0xc) = (int)uVar19;
        }
        else {
          puVar20 = (ushort *)(pbVar23 + uVar19);
          uVar6 = *puVar20;
          psVar25[0xe] = uVar6;
          if (uVar6 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar22 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar22 != 0)) &&
               ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                (*(char *)(lVar22 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1001c1;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1001e5;
                (*_DAT_)(1,0x127f938,0x139f608,0x80f);
              }
            }
            uVar2 = *(undefined8 *)(psVar25 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1001f3;
            func_0x(uVar2,3);
            uVar19 = (ulonglong)*(uint *)(psVar25 + 10);
            uVar6 = psVar25[0xe];
          }
          uVar17 = (int)uVar19 + (uVar6 + 1) * 2;
          *(uint *)(psVar25 + 0xc) = uVar17;
          if (0x1f9e < uVar17) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar22 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar22 != 0 &&
                ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                 (*(char *)(lVar22 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100293;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1002b7;
                (*_DAT_)(1,0x127f938,0x139f608,0x816);
              }
            }
            uVar2 = *(undefined8 *)(psVar25 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1002c5;
            func_0x(uVar2,4);
            uVar6 = psVar25[0xe];
            uVar17 = *(uint *)(psVar25 + 0xc);
          }
          uVar13 = (ulonglong)uVar6;
          uVar18 = puVar20[uVar13] & 0x7fff;
          *(uint *)(psVar25 + 2) = uVar18;
          if (uVar18 < uVar17) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar22 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar22 != 0)) &&
               ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                (*(char *)(lVar22 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100363;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100387;
                (*_DAT_)(1,0x127f938,0x139f608,0x81d);
              }
            }
            uVar2 = *(undefined8 *)(psVar25 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100395;
            func_0x(uVar2,4);
            uVar13 = (ulonglong)(ushort)psVar25[0xe];
            uVar18 = *(uint *)(psVar25 + 2);
          }
          if ((short)puVar20[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
            lVar22 = *(longlong *)(psVar25 + 4);
            do {
              if ((int)uVar13 == 1) {
                uVar17 = *(uint *)(psVar25 + 0xc);
                uVar18 = uVar17;
LAB_:
                if ((*(ushort *)((ulonglong)*(uint *)(psVar25 + 10) + lVar22 + uVar13 * 2) & 0x7fff)
                    < uVar17) goto LAB_;
              }
              else {
                uVar17 = *(ushort *)((ulonglong)*(uint *)(psVar25 + 10) + lVar22 + -2 + uVar13 * 2)
                         & 0x7fff;
                uVar18 = *(uint *)(psVar25 + 0xc);
                if (uVar18 <= uVar17) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100404;
                func_0x(lVar22,7);
                uVar18 = *(uint *)(psVar25 + 0xc);
              }
              if ((uVar17 < uVar18) ||
                 (uVar19 = (ulonglong)*(uint *)(psVar25 + 2), *(uint *)(psVar25 + 2) < uVar17))
              goto LAB_;
              lVar22 = *(longlong *)(psVar25 + 4);
              if (*(ushort *)((ulonglong)uVar17 + lVar22) == 5) {
                psVar25[1] = psVar25[1] | 2;
                psVar25[0xe] = psVar25[0xe] + -1;
                psVar25[0x15] = (short)uVar17;
                lVar22 = (ulonglong)(uVar17 & 0xffff) + *(longlong *)(psVar25 + 4);
                uVar6 = psVar25[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar22 + 2) & 0x4000) != 0) {
                  uVar6 = *(ushort *)(lVar22 + 2) & 0x3800 | psVar25[0x16] & 0xc7ffU;
                }
                psVar25[0x16] = uVar6;
                psVar25[0x16] = (uVar6 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar6;
                uVar18 = *(uint *)(psVar25 + 2);
                break;
              }
              if (*(ushort *)((ulonglong)uVar17 + lVar22) < 0x400) goto LAB_;
              psVar25[1] = psVar25[1] | 1;
              uVar6 = psVar25[0xe] - 1;
              psVar25[0xe] = uVar6;
              if ((uVar6 == 0) ||
                 (uVar13 = (ulonglong)uVar6, -1 < (short)puVar20[(ulonglong)(uVar6 - 1) + 1]))
              goto LAB_;
            } while( true );
          }
          uVar19 = (ulonglong)uVar18;
          pbVar23 = *(byte **)(psVar25 + 4);
        }
        goto LAB_;
      }
      goto LAB_;
    }
  }
  uVar17 = *(uint *)(psVar25 + 2);
  if (uVar17 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100724;
    func_0x(psVar25 + 1);
    uVar17 = *(uint *)(psVar25 + 2);
  }
  if (uVar17 < 9) {
    bVar12 = **(byte **)(psVar25 + 4) & 0x1c;
    goto joined_r0x0010070b;
  }
  goto LAB_;
LAB_:
  pbVar23 = *(byte **)(psVar25 + 4);
LAB_:
  iVar7 = 0;
  if ((*pbVar23 & 0x40) == 0) {
    *(undefined4 *)(psVar25 + 0x13) = 0;
  }
  else {
    *(int *)(psVar25 + 0x13) = (int)uVar19;
    *(int *)(psVar25 + 2) = (int)uVar19 + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100f7b;
    puVar9 = (ulonglong *)func_0x(psVar25 + 1);
    uVar19 = *puVar9;
    uVar16 = (ushort)(uVar19 >> 0x30);
    uVar6 = uVar16;
    if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
      uVar6 = uVar16 & 0xdfff;
      if ((uVar19 & 0x4000000000000000) != 0) {
        uVar6 = uVar16 | 0x2000;
      }
    }
    if (uVar6 == 0xfffc) {
      iVar7 = (int)((uVar19 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(psVar25 + 2) = *(int *)(psVar25 + 2) + iVar7;
    uVar19 = (ulonglong)*(uint *)(psVar25 + 2);
  }
  iVar7 = (int)uVar19;
  if ((*(ulonglong *)(psVar25 + 0xf) != 0) &&
     (*(ulonglong *)(psVar25 + 0xf) < uVar19 + *(longlong *)(psVar25 + 4))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar22 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar22 != 0 &&
         (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
        (*(char *)(lVar22 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x101077;
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10109b;
        (*_DAT_)(1,0x127f938,0x139f608,0x877);
      }
    }
    uVar2 = *(undefined8 *)(psVar25 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1010a9;
    func_0x(uVar2,0x12);
    iVar7 = *(int *)(psVar25 + 2);
  }
  if (0x3f3b < iVar7 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar22 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar22 != 0 &&
        ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 && (*(char *)(lVar22 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) goto LAB_;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x101150;
      (*_DAT_)(1,0x127f938,0x139f608,0x87c);
    }
    goto LAB_;
  }
  goto LAB_;
LAB_:
  pbVar23 = *(byte **)(psVar25 + 4);
LAB_:
  iVar7 = 0;
  if ((*pbVar23 & 0x40) == 0) {
    *(undefined4 *)(psVar25 + 0x13) = 0;
  }
  else {
    *(int *)(psVar25 + 0x13) = (int)uVar19;
    *(int *)(psVar25 + 2) = (int)uVar19 + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10050a;
    puVar9 = (ulonglong *)func_0x(psVar25 + 1);
    uVar19 = *puVar9;
    uVar16 = (ushort)(uVar19 >> 0x30);
    uVar6 = uVar16;
    if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
      uVar6 = uVar16 & 0xdfff;
      if ((uVar19 & 0x4000000000000000) != 0) {
        uVar6 = uVar16 | 0x2000;
      }
    }
    if (uVar6 == 0xfffc) {
      iVar7 = (int)((uVar19 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(psVar25 + 2) = *(int *)(psVar25 + 2) + iVar7;
    uVar19 = (ulonglong)*(uint *)(psVar25 + 2);
  }
  iVar7 = (int)uVar19;
  if ((*(ulonglong *)(psVar25 + 0xf) != 0) &&
     (*(ulonglong *)(psVar25 + 0xf) < uVar19 + *(longlong *)(psVar25 + 4))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar22 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar22 != 0 &&
         (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
        (*(char *)(lVar22 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100606;
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10062a;
        (*_DAT_)(1,0x127f938,0x139f608,0x877);
      }
    }
    uVar2 = *(undefined8 *)(psVar25 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100638;
    func_0x(uVar2,0x12);
    iVar7 = *(int *)(psVar25 + 2);
  }
  if (0x3f3b < iVar7 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar22 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar22 != 0 &&
        ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 && (*(char *)(lVar22 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
LAB_:
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1006c5;
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1006e9;
        (*_DAT_)(1,0x127f938,0x139f608,0x87c);
      }
    }
LAB_:
    uVar2 = *(undefined8 *)(psVar25 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1006f7;
    func_0x(uVar2,5);
  }
LAB_:
  uVar17 = *(uint *)(psVar25 + 2);
  if (uVar17 < 9) {
    bVar12 = **(byte **)(psVar25 + 4) & 0xe;
joined_r0x0010070b:
    if ((bVar12 == 0) || (bVar12 == 0xc)) {
      uVar17 = 9;
    }
  }
LAB_:
  uVar2 = *(undefined8 *)(psVar25 + 4);
  uVar10 = *(undefined8 *)(param_1 + 0x250);
  *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100755;
  func_0x(uVar10,uVar2,uVar17);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x101235;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar8));
  return;
}

