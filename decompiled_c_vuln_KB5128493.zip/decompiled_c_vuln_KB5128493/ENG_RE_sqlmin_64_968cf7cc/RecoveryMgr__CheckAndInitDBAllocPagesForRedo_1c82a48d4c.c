
void FUN_(longlong *param_1,longlong param_2)

{
  longlong lVar1;
  short sVar2;
  ulonglong *puVar3;
  uint *puVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  byte bVar7;
  int iVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  ushort uVar11;
  ushort uVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  ushort *puVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  ushort *puVar19;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  undefined8 uStackX_10;
  uint uStackX_18;
  undefined auStackX_20 [8];
  short sStack_c8;
  ushort uStack_c6;
  uint uStack_c4;
  byte *pbStack_c0;
  undefined4 uStack_b8;
  uint uStack_b4;
  uint uStack_b0;
  ushort uStack_ac;
  byte *pbStack_aa;
  undefined2 uStack_a2;
  undefined2 uStack_a0;
  undefined2 uStack_9e;
  ushort uStack_9c;
  undefined2 uStack_9a;
  undefined4 uStack_98;
  short sStack_90;
  ushort uStack_8e;
  uint uStack_8c;
  byte *pbStack_88;
  undefined4 uStack_80;
  uint uStack_7c;
  uint uStack_78;
  ushort uStack_74;
  byte *pbStack_72;
  undefined2 uStack_6a;
  undefined2 uStack_68;
  undefined2 uStack_66;
  ushort uStack_64;
  undefined2 uStack_62;
  undefined4 uStack_60;
  undefined4 uStack_58;
  undefined2 uStack_54;
  
  uVar10 = 0;
  pbStack_c0 = (byte *)0x0;
  sStack_c8 = -1;
  uVar14 = 0;
  uVar13 = 0;
  uVar12 = *(ushort *)(param_2 + 0x1c);
  uStack_c4 = 0;
  pbStack_aa = (byte *)0x0;
  uStack_a0 = 0;
  uStack_9e = 0;
  uStack_9c = 0;
  uStack_9a = 0;
  uStack_b8 = 0;
  uStack_b4 = 0;
  uStack_8c = 0;
  pbStack_72 = (byte *)0x0;
  uStack_68 = 0;
  uStack_66 = 0;
  uStack_64 = 0;
  uStack_62 = 0;
  uStack_80 = 0;
  uStack_7c = 0;
  if ((((uVar12 == 0) || (*(ushort *)(*(longlong *)(*param_1 + 0x6a0) + 0x74) < uVar12)) ||
      (uVar18 = *(ulonglong *)
                 (*(longlong *)(*(longlong *)(*param_1 + 0x6a0) + 0x50) + -8 + (ulonglong)uVar12 * 8
                 ), uVar18 == 0)) || ((*(byte *)(uVar18 + 100) & 4) != 0)) {
    uVar18 = uVar10;
  }
  puVar19 = (ushort *)(param_2 + 0x3e);
  uStackX_10 = puVar19;
  pbStack_88 = (byte *)func_0x(puVar19,0,auStackX_8);
  if ((*pbStack_88 & 1) == 0) {
    sStack_90 = 0;
    uStack_6a = 0;
    uStack_68 = 0;
    uVar13 = 0;
    switch(*pbStack_88 & 0xe) {
    default:
      uVar10 = (ulonglong)*(ushort *)(pbStack_88 + 2);
      uVar13 = uVar14;
      if (0x1f9d < *(ushort *)(pbStack_88 + 2) - 1) {
        func_0x(pbStack_88,6,pbStack_88,0xc8df78);
        uVar13 = uStack_8c;
      }
      break;
    case 4:
      uVar10 = 9;
      uVar13 = uVar14;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar10 = 1;
      uVar13 = uVar14;
    }
    uStack_80 = (undefined4)uVar10;
  }
  else {
    sStack_90 = 1;
    bVar7 = *pbStack_88;
    switch(bVar7 & 0x1c) {
    default:
      if ((char)pbStack_88[1] < '\0') {
        sVar2 = 3;
        uStack_78 = 3;
        uStack_8e = (*(ushort *)(pbStack_88 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_88 + 1) >> 8;
      }
      else {
        uStack_8e = (ushort)pbStack_88[1];
        uStack_78 = 2;
        sVar2 = 2;
      }
      uStack_74 = ((ushort)(uStack_8e + 1) >> 1) + sVar2;
      if (uStack_8e < 0x1f) {
        uStack_60 = 0;
        uVar13 = 0;
      }
      else {
        iVar8 = uStack_8e - 1;
        uStack_60 = 0;
        uStack_78 = CONCAT22(((short)(iVar8 / 0x1e) + (short)(iVar8 >> 0x1f)) -
                             (short)((longlong)iVar8 * 0x88888889 >> 0x3f),(undefined2)uStack_78);
      }
      break;
    case 4:
      uVar10 = 0;
      if (((bVar7 & 0x1c) == 4) && ((bVar7 & 2) != 0)) {
        uVar13 = 0xf;
        uStack_78 = 0;
        uStack_8c = 0xf;
        uStack_8e = 0;
        uStack_74 = 0;
        uStack_6a = 0;
        uStack_60 = 1;
      }
      else {
        uVar13 = 1;
        uStack_78 = 0;
        uStack_8c = 1;
        uStack_8e = 0;
        uStack_74 = 0;
        uStack_6a = 0;
        uStack_60 = 0;
      }
      break;
    case 8:
      uVar13 = 9;
      uStack_78 = 0;
      uStack_8c = 9;
      uStack_8e = 0;
      uStack_74 = 0;
      uStack_6a = 0;
      uStack_60 = 0;
    }
  }
  if (sStack_90 == 0) {
    if (uVar13 == 0) {
      uStack_8e = 0;
      uStack_7c = (uint)uVar10;
      if ((*pbStack_88 & 0x10) != 0) {
        uStack_7c = uStack_7c + 2 + (*(ushort *)(pbStack_88 + uVar10) + 7 >> 3);
        uVar10 = (ulonglong)uStack_7c;
      }
      if ((*pbStack_88 & 0x20) == 0) {
        uStack_74 = 0;
        uStack_8c = (uint)uVar10;
        uStack_78 = (uint)uVar10;
      }
      else {
        puVar19 = (ushort *)(pbStack_88 + uVar10);
        uStack_74 = *puVar19;
        if (uStack_74 == 0) {
          if ((((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                        (ulonglong)*puRam0000000000b8f900), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
              (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x80f,0);
            }
          }
          func_0x(pbStack_88,3);
        }
        uStack_78 = uStack_7c + 2 + (uint)uStack_74 * 2;
        if (0x1f9e < uStack_78) {
          if (((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
             ((lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                        (ulonglong)*puRam0000000000b8f900), lVar1 != 0 &&
              ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
               (*(char *)(lVar1 + 0x499) != '\0')))))) {
            if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
              (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x816,0);
            }
          }
          func_0x(pbStack_88,4);
        }
        uVar17 = (ulonglong)uStack_78;
        uStack_8c = puVar19[uStack_74] & 0x7fff;
        uVar10 = (ulonglong)uStack_8c;
        if (uStack_8c < uStack_78) {
          if ((((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                        (ulonglong)*puRam0000000000b8f900), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
              (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x81d,0);
            }
          }
          func_0x(pbStack_88,4);
          uVar17 = (ulonglong)uStack_78;
          uVar10 = (ulonglong)uStack_8c;
        }
        do {
          uVar9 = (ulonglong)uStack_74;
          if (-1 < (short)puVar19[(ulonglong)(uStack_74 - 1) + 1]) break;
          if (uStack_74 == 1) {
            uVar9 = 1;
            uVar15 = uVar17;
code_r0x0010056e:
            if ((*(ushort *)(pbStack_88 + uVar9 * 2 + (ulonglong)uStack_7c) & 0x7fff) < (uint)uVar15
               ) goto code_r0x0010057b;
          }
          else {
            uVar15 = (ulonglong)
                     (*(ushort *)(pbStack_88 + uVar9 * 2 + ((ulonglong)uStack_7c - 2)) & 0x7fff);
            if ((uint)uVar17 <=
                (*(ushort *)(pbStack_88 + uVar9 * 2 + ((ulonglong)uStack_7c - 2)) & 0x7fff))
            goto code_r0x0010056e;
code_r0x0010057b:
            func_0x(pbStack_88,7);
            uVar17 = (ulonglong)uStack_78;
            uVar10 = (ulonglong)uStack_8c;
          }
          uVar13 = (uint)uVar10;
          if (((uint)uVar15 < (uint)uVar17) || (uVar13 < (uint)uVar15)) goto code_r0x00100864;
          if (*(ushort *)(pbStack_88 + uVar15) == 5) {
            uStack_8e = uStack_8e | 2;
            uStack_74 = uStack_74 - 1;
            uStack_66 = (undefined2)uVar15;
            uVar12 = *(ushort *)(pbStack_88 + (uVar15 & 0xffff) + 2);
            uVar11 = uStack_64 & 0xc7ff;
            if ((uVar12 & 0x4000) != 0) {
              uVar11 = (uStack_64 ^ uVar12) & 0x3800 ^ uStack_64;
            }
            uStack_64 = (uVar11 ^ uVar12) & 0x7ff ^ uVar11;
            break;
          }
          if (*(ushort *)(pbStack_88 + uVar15) < 0x400) break;
          uStack_8e = uStack_8e | 1;
          uStack_74 = uStack_74 - 1;
        } while (uStack_74 != 0);
      }
      if ((*pbStack_88 & 0x40) == 0) {
        uStack_6a = 0;
        uStack_68 = 0;
      }
      else {
        uStack_6a = (undefined2)uVar10;
        uStack_68 = (undefined2)(uVar10 >> 0x10);
        uStack_8c = (int)uVar10 + 0xe;
        puVar3 = (ulonglong *)func_0x(&uStack_8e);
        iVar8 = 0;
        uVar10 = *puVar3;
        uVar11 = (ushort)(uVar10 >> 0x30);
        uVar12 = uVar11;
        if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
          uVar12 = uVar11 & 0xdfff;
          if ((uVar10 & 0x4000000000000000) != 0) {
            uVar12 = uVar11 | 0x2000;
          }
        }
        if (uVar12 == 0xfffc) {
          iVar8 = (int)((uVar10 >> 0x20 & 0xffff) >> 5);
        }
        uStack_8c = uStack_8c + iVar8;
        uVar10 = (ulonglong)uStack_8c;
      }
      uVar13 = (uint)uVar10;
      if ((pbStack_72 != (byte *)0x0) && (pbStack_72 < pbStack_88 + uVar10)) {
        if (((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
           (((lVar1 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                       (ulonglong)*puRam0000000000b8f900), lVar1 != 0 &&
             (lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0)) &&
            (*(char *)(lVar1 + 0x499) != '\0')))) {
          if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
            (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x877,0);
          }
        }
        func_0x(pbStack_88,0x12);
        uVar13 = uStack_8c;
      }
      if (0x3f3b < uVar13 - 1) {
        if (((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
           ((lVar1 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                        (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                      (ulonglong)*puRam0000000000b8f900), lVar1 != 0 &&
            ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0'))
            )))) {
          if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
            (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x87c,0);
          }
        }
        func_0x(pbStack_88,5);
        uVar13 = uStack_8c;
      }
    }
code_r0x00100864:
    puVar19 = uStackX_10;
    if ((uVar13 < 9) && (((*pbStack_88 & 0xe) == 0 || ((*pbStack_88 & 0xe) == 0xc)))) {
      uVar13 = 9;
    }
  }
  else {
    if (uVar13 == 0) {
      func_0x(&uStack_8e);
      uVar13 = uStack_8c;
    }
    if ((uVar13 < 9) && (((*pbStack_88 & 0x1c) == 0 || ((*pbStack_88 & 0x1c) == 0xc)))) {
      uVar13 = 9;
    }
  }
  if (auStackX_8[0] != uVar13) {
    (*pcRam0000000000b8f890)(1,0x10a8f90,0x1098280,0x1920,0);
  }
  uVar10 = 0;
  pbStack_c0 = (byte *)func_0x(puVar19,1,auStackX_8);
  if ((*pbStack_c0 & 1) == 0) {
    sStack_c8 = 0;
    uStack_a2 = 0;
    uStack_a0 = 0;
    switch(*pbStack_c0 & 0xe) {
    default:
      uVar10 = (ulonglong)*(ushort *)(pbStack_c0 + 2);
      if (0x1f9d < *(ushort *)(pbStack_c0 + 2) - 1) {
        func_0x(pbStack_c0,6);
      }
      break;
    case 4:
      uVar10 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar10 = 1;
    }
    uStack_b8 = (undefined4)uVar10;
  }
  else {
    sStack_c8 = 1;
    bVar7 = *pbStack_c0;
    switch(bVar7 & 0x1c) {
    default:
      if ((char)pbStack_c0[1] < '\0') {
        uStack_c6 = (*(ushort *)(pbStack_c0 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_c0 + 1) >> 8;
        uVar12 = 3;
        sVar2 = 3;
      }
      else {
        uStack_c6 = (ushort)pbStack_c0[1];
        uVar12 = 2;
        sVar2 = 2;
      }
      uStack_ac = ((ushort)(uStack_c6 + 1) >> 1) + sVar2;
      if (uStack_c6 < 0x1f) {
        uStack_b0 = (uint)uVar12;
        uStack_98 = 0;
      }
      else {
        iVar8 = uStack_c6 - 1;
        uStack_98 = 0;
        uVar10 = 0;
        uStack_b0 = CONCAT22(((short)(iVar8 / 0x1e) + (short)(iVar8 >> 0x1f)) -
                             (short)((longlong)iVar8 * 0x88888889 >> 0x3f),uVar12);
      }
      break;
    case 4:
      if (((bVar7 & 0x1c) == 4) && ((bVar7 & 2) != 0)) {
        uStack_b0 = 0;
        uVar10 = 0;
        uStack_c6 = 0;
        uStack_ac = 0;
        uStack_a2 = 0;
        uStack_c4 = 0xf;
        uStack_98 = 1;
      }
      else {
        uStack_b0 = 0;
        uVar10 = 0;
        uStack_c6 = 0;
        uStack_ac = 0;
        uStack_a2 = 0;
        uStack_c4 = 1;
        uStack_98 = 0;
      }
      break;
    case 8:
      uStack_b0 = 0;
      uVar10 = 0;
      uStack_c6 = 0;
      uStack_ac = 0;
      uStack_a2 = 0;
      uStack_c4 = 9;
      uStack_98 = 0;
    }
  }
  uVar13 = (uint)uVar10;
  if (sStack_c8 == 0) {
    if (uStack_c4 == 0) {
      uStack_c6 = 0;
      if ((*pbStack_c0 & 0x10) != 0) {
        uVar13 = uVar13 + 2 + (*(ushort *)(pbStack_c0 + uVar10) + 7 >> 3);
      }
      uStack_b4 = uVar13;
      if ((*pbStack_c0 & 0x20) == 0) {
        uStack_ac = 0;
        uStack_c4 = uVar13;
        uStack_b0 = uVar13;
      }
      else {
        puVar16 = (ushort *)(pbStack_c0 + uVar13);
        uStack_ac = *puVar16;
        if (uStack_ac == 0) {
          if ((((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                        (ulonglong)*puRam0000000000b8f900), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
              (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x80f,0);
            }
          }
          func_0x(pbStack_c0,3);
        }
        uStack_b0 = uStack_b4 + 2 + (uint)uStack_ac * 2;
        if (0x1f9e < uStack_b0) {
          if (((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
             ((lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                        (ulonglong)*puRam0000000000b8f900), lVar1 != 0 &&
              ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
               (*(char *)(lVar1 + 0x499) != '\0')))))) {
            if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
              (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x816,0);
            }
          }
          func_0x(pbStack_c0,4);
        }
        uStack_c4 = puVar16[uStack_ac] & 0x7fff;
        uVar13 = uStack_b0;
        if (uStack_c4 < uStack_b0) {
          if ((((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                        (ulonglong)*puRam0000000000b8f900), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
              (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x81d,0);
            }
          }
          func_0x(pbStack_c0,4);
          uVar13 = uStack_b0;
        }
        do {
          uVar10 = (ulonglong)uStack_ac;
          if (-1 < (short)puVar16[(ulonglong)(uStack_ac - 1) + 1]) break;
          if (uStack_ac == 1) {
            uVar10 = 1;
            uVar14 = uVar13;
code_r0x00100dad:
            if ((*(ushort *)(pbStack_c0 + uVar10 * 2 + (ulonglong)uStack_b4) & 0x7fff) < uVar14)
            goto code_r0x00100dba;
          }
          else {
            uVar14 = *(ushort *)(pbStack_c0 + uVar10 * 2 + ((ulonglong)uStack_b4 - 2)) & 0x7fff;
            if (uVar13 <= uVar14) goto code_r0x00100dad;
code_r0x00100dba:
            func_0x(pbStack_c0,7);
            uVar13 = uStack_b0;
          }
          if ((uVar14 < uVar13) || (uStack_c4 < uVar14)) goto code_r0x0010109b;
          if (*(ushort *)(pbStack_c0 + uVar14) == 5) {
            uStack_c6 = uStack_c6 | 2;
            uStack_ac = uStack_ac - 1;
            uStack_9e = (undefined2)uVar14;
            uVar12 = *(ushort *)(pbStack_c0 + (ulonglong)(uVar14 & 0xffff) + 2);
            uVar11 = uStack_9c & 0xc7ff;
            if ((uVar12 & 0x4000) != 0) {
              uVar11 = (uStack_9c ^ uVar12) & 0x3800 ^ uStack_9c;
            }
            uStack_9c = (uVar11 ^ uVar12) & 0x7ff ^ uVar11;
            break;
          }
          if (*(ushort *)(pbStack_c0 + uVar14) < 0x400) break;
          uStack_c6 = uStack_c6 | 1;
          uStack_ac = uStack_ac - 1;
        } while (uStack_ac != 0);
      }
      iVar8 = 0;
      if ((*pbStack_c0 & 0x40) == 0) {
        uStack_a2 = 0;
        uStack_a0 = 0;
      }
      else {
        uStack_a2 = (undefined2)uStack_c4;
        uStack_a0 = (undefined2)(uStack_c4 >> 0x10);
        uStack_c4 = uStack_c4 + 0xe;
        puVar3 = (ulonglong *)func_0x(&uStack_c6);
        uVar10 = *puVar3;
        uVar11 = (ushort)(uVar10 >> 0x30);
        uVar12 = uVar11;
        if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
          uVar12 = uVar11 & 0xdfff;
          if ((uVar10 & 0x4000000000000000) != 0) {
            uVar12 = uVar11 | 0x2000;
          }
        }
        if (uVar12 == 0xfffc) {
          iVar8 = (int)((uVar10 >> 0x20 & 0xffff) >> 5);
        }
        uStack_c4 = uStack_c4 + iVar8;
      }
      if ((pbStack_aa != (byte *)0x0) && (pbStack_aa < pbStack_c0 + uStack_c4)) {
        if (((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
           (((lVar1 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                       (ulonglong)*puRam0000000000b8f900), lVar1 != 0 &&
             (lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0)) &&
            (*(char *)(lVar1 + 0x499) != '\0')))) {
          if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
            (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x877,0);
          }
        }
        func_0x(pbStack_c0,0x12);
      }
      if (0x3f3b < uStack_c4 - 1) {
        if (((cRam000000000162106b != '\0') || ((bRam0000000001631970 & 1) != 0)) &&
           ((lVar1 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                        (ulonglong)*puRam0000000000b8f8f8 * 8) + 8 +
                      (ulonglong)*puRam0000000000b8f900), lVar1 != 0 &&
            ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0'))
            )))) {
          if ((cRam0000000001620f5b == '\0') && ((bRam0000000001631970 & 2) == 0)) {
            (*pcRam0000000000b8f898)(0x22,0x44,0x15,0x3ed);
            func_0x(pbStack_c0,5);
            goto code_r0x0010109b;
          }
          (*pcRam0000000000b8f890)(1,0xf11a98,0x1031768,0x87c,0);
        }
        func_0x(pbStack_c0,5);
      }
    }
code_r0x0010109b:
    if (uStack_c4 < 9) {
      bVar7 = *pbStack_c0 & 0xe;
joined_r0x001010d1:
      uVar13 = 9;
      if ((bVar7 == 0) || (uVar13 = 9, bVar7 == 0xc)) goto code_r0x001010dc;
    }
  }
  else {
    if (uStack_c4 == 0) {
      func_0x(&uStack_c6);
    }
    if (uStack_c4 < 9) {
      bVar7 = *pbStack_c0 & 0x1c;
      goto joined_r0x001010d1;
    }
  }
  uVar13 = uStack_c4;
code_r0x001010dc:
  if (auStackX_8[0] != uVar13) {
    (*pcRam0000000000b8f890)(1,0x10a8fc0,0x1098280,0x1924,0);
  }
  iVar8 = func_0x(&sStack_90);
  if (iVar8 != 2) {
    puVar4 = (uint *)func_0x(&sStack_90,5);
    uVar13 = 0;
    if (puVar4 == (uint *)0x0) {
      uStackX_10 = (ushort *)((ulonglong)uStackX_10._4_4_ << 0x20);
      puVar5 = (undefined4 *)(*pcRam0000000000b8fc30)();
      *puVar5 = 0x16;
      (*pcRam0000000000b8fc48)();
      uVar14 = uVar13;
    }
    else {
      uStackX_10 = (ushort *)CONCAT44(uStackX_10._4_4_,*puVar4);
      uVar14 = *puVar4;
    }
    puVar4 = (uint *)func_0x(&sStack_c8,5);
    if (puVar4 == (uint *)0x0) {
      uStackX_18 = 0;
      puVar5 = (undefined4 *)(*pcRam0000000000b8fc30)();
      *puVar5 = 0x16;
      (*pcRam0000000000b8fc48)();
    }
    else {
      uVar13 = *puVar4;
      uStackX_18 = uVar13;
    }
    if ((uVar14 < uVar13) && (uVar14 < *(uint *)(uVar18 + 0x80))) {
      if (*puVar19 < 3) {
        (*pcRam0000000000b8f890)(1,0x10e0ed0,0x1098280,0x1939,0);
      }
      uVar6 = func_0x(puVar19,2,auStackX_20);
      uStack_58 = (undefined4)uStackX_10;
      uStack_54 = *(undefined2 *)(uVar18 + 0x20);
      uVar13 = uStackX_18;
      if (*(uint *)(uVar18 + 0x80) <= uStackX_18) {
        uVar13 = *(uint *)(uVar18 + 0x80);
      }
      func_0x(uVar18,&uStack_58,uVar13,uVar6);
    }
  }
  return;
}

