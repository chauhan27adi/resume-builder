
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,undefined8 param_3,byte *param_4)

{
  ushort *puVar1;
  undefined4 uVar2;
  int iVar3;
  undefined8 uVar4;
  byte *pbVar5;
  undefined8 *puVar6;
  char cVar7;
  longlong lVar8;
  ulonglong uVar9;
  short *psVar10;
  longlong lVar11;
  ulonglong *puVar12;
  byte bVar13;
  short sVar14;
  uint uVar15;
  int iVar16;
  ushort uVar17;
  ushort uVar18;
  uint uVar19;
  byte **ppbVar20;
  uint uVar21;
  uint uVar22;
  byte *pbVar23;
  undefined2 uVar24;
  uint uVar25;
  short sVar26;
  short sVar27;
  ulonglong uVar28;
  ushort *puVar29;
  longlong unaff_GS_OFFSET;
  undefined4 extraout_XMM0_Da;
  undefined4 uStackX_8;
  undefined2 auStackX_c [2];
  int iStackX_10;
  undefined8 uStackX_18;
  byte *pbStackX_20;
  undefined auStack_3918 [16];
  undefined auStack_3908 [8];
  undefined8 uStack_3900;
  undefined8 uStack_38f8;
  undefined6 uStack_38f0;
  undefined2 uStack_38ea;
  undefined6 uStack_38e8;
  undefined2 uStack_38e2;
  undefined8 uStack_38e0;
  undefined auStack_38d8 [16];
  undefined auStack_38c8 [16];
  undefined auStack_38b8 [16];
  undefined8 uStack_38a8;
  undefined2 auStack_3898 [2];
  undefined4 uStack_3894;
  undefined8 uStack_3890;
  undefined8 uStack_3888;
  undefined8 uStack_387a;
  undefined8 uStack_3870;
  undefined auStack_2059 [8193];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10002c;
  iStackX_10 = param_2;
  uStackX_18 = param_3;
  pbStackX_20 = param_4;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar8);
  uVar24 = *(undefined2 *)(param_1 + 0x20);
  ppbVar20 = (byte **)0x0;
  *(longlong *)((longlong)&iStackX_10 + lVar8) = param_1;
  *(undefined8 *)((longlong)&pbStackX_20 + lVar8) = 0;
  uVar28 = (ulonglong)auStack_2059 & 0xfffffffffffff000;
  *(undefined2 *)((longlong)&uStackX_18 + lVar8) = 0xffff;
  *(undefined4 *)((longlong)&uStackX_18 + lVar8 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar8) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar8) = 0;
  auStack_3898[0] = 0xffff;
  uStack_3890 = 0;
  uStack_3894 = 0;
  uStack_387a = 0;
  uStack_3870 = 0;
  uStack_3888 = 0;
  *(undefined4 *)((longlong)&uStackX_8 + lVar8) = 0;
  *(undefined2 *)((longlong)auStackX_c + lVar8) = uVar24;
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1000ac;
  func_0x(extraout_XMM0_Da,0,uVar28,(longlong)&uStackX_8 + lVar8);
  uVar22 = 0xf;
  sVar26 = 2;
  uVar19 = 0;
  sVar27 = 2;
  if (*(char *)(uVar28 + 2) < '\0') {
    pbVar23 = (byte *)(uVar28 + 0x60);
    if ((*(short *)((longlong)&uStackX_18 + lVar8) == 0) ||
       (ppbVar20 = *(byte ***)(&stack0x00000028 + lVar8), ppbVar20 == (byte **)0x0)) {
      ppbVar20 = (byte **)auStack_3918;
      stack0xffffffffffffc6fa = SUB1614(ZEXT816(0),2);
      auStack_3908._0_2_ = 0xffff;
      uStack_38f0 = 0;
      uStack_38e2 = 0;
      uStack_3900 = 0;
      uStack_38ea = 0;
      uStack_38e8 = 0;
      uStack_38e0 = 0;
      uStack_38f8 = 0;
      auStack_38d8 = ZEXT816(0);
      auStack_38b8._0_12_ = ZEXT812(0);
      auStack_38b8._12_4_ = 0;
      uStack_38a8 = 0;
      auStack_38c8 = ZEXT816(0);
      auStack_3918 = ZEXT816(0);
    }
    if (*(short *)(uVar28 + 0x24) == 0) {
LAB_:
      uVar24 = *(undefined2 *)(uVar28 + 0x30);
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar8) = *(undefined8 *)(uVar28 + 0x28);
    }
    else {
      cVar7 = *(char *)(uVar28 + 1);
      if (cVar7 == '\v') {
        if (*(int *)(uVar28 + 0x18) != 99) {
LAB_:
          if (cVar7 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar7 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar28 + 0x18) != 99) goto LAB_;
      }
      *(undefined4 *)(&stack0xfffffffffffffff8 + lVar8) = *(undefined4 *)(uVar28 + 0x20);
      *(undefined2 *)(&stack0xfffffffffffffffc + lVar8) = *(undefined2 *)(uVar28 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10018c;
      cVar7 = func_0x(&stack0xfffffffffffffff8 + lVar8,0x110b098);
      if (cVar7 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10019d;
      func_0x(uVar28,&stack0xfffffffffffffff8 + lVar8);
      uVar24 = *(undefined2 *)(&stack0x00000000 + lVar8);
    }
    uVar2 = *(undefined4 *)(&stack0xfffffffffffffff8 + lVar8);
    *ppbVar20 = pbVar23;
    *(undefined4 *)(ppbVar20 + 0xc) = uVar2;
    uVar4 = *(undefined8 *)(&stack0xfffffffffffffff8 + lVar8);
    *(undefined2 *)(ppbVar20 + 0xd) = uVar24;
    *(int *)((longlong)ppbVar20 + 100) = (int)((ulonglong)uVar4 >> 0x20);
    *(undefined4 *)((longlong)ppbVar20 + 0x6c) = *(undefined4 *)(uVar28 + 0x20);
    *(undefined2 *)(ppbVar20 + 0xe) = *(undefined2 *)(uVar28 + 0x24);
    *(undefined2 *)((longlong)ppbVar20 + 0x72) = 0;
    uVar2 = *(undefined4 *)((ulonglong)*pbVar23 * 6 + 0x118b6a0);
    sVar14 = *(short *)((ulonglong)*pbVar23 * 6 + 0x118b6a4);
    *(undefined2 *)(ppbVar20 + 2) = 0xffff;
    ppbVar20[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
    ppbVar20[7] = (byte *)0x0;
    ppbVar20[4] = (byte *)0x0;
    ppbVar20[9] = (byte *)0x0;
    ppbVar20[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar20 + 0xb) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar8) = uVar2;
    pbVar5 = *ppbVar20;
    *(short *)(&stack0xfffffffffffffff0 + lVar8) = sVar14;
    if ((*pbVar5 & 2) != 0) {
      pbVar5 = pbVar23 + sVar14;
      if ((pbVar23[sVar14] & 1) == 0) {
        *(undefined2 *)(ppbVar20 + 2) = 0;
        ppbVar20[3] = pbVar5;
        *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar20 + 0x36) = 0;
        uVar25 = uVar19;
        switch(*pbVar5 & 0xe) {
        default:
          uVar25 = (uint)*(ushort *)(pbVar5 + 2);
          if (0x1f9d < *(ushort *)(pbVar5 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10041d;
            func_0x(pbVar5,6);
          }
          break;
        case 4:
          uVar25 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar25 = 1;
        }
        *(uint *)(ppbVar20 + 4) = uVar25;
        *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar20 + 2) = 1;
        ppbVar20[3] = pbVar5;
        bVar13 = *pbVar5;
        switch(bVar13 & 0x1c) {
        default:
          if ((char)pbVar5[1] < '\0') {
            uVar17 = *(ushort *)(pbVar5 + 1);
            sVar27 = 3;
            *(ushort *)((longlong)ppbVar20 + 0x12) = uVar17;
            uVar17 = (uVar17 & 0x7f) << 8 | uVar17 >> 8;
          }
          else {
            uVar17 = (ushort)pbVar5[1];
          }
          *(ushort *)((longlong)ppbVar20 + 0x12) = uVar17;
          *(short *)(ppbVar20 + 5) = sVar27;
          uVar17 = *(ushort *)((longlong)ppbVar20 + 0x12);
          *(short *)((longlong)ppbVar20 + 0x2c) = (short)(uVar17 + 1 >> 1) + sVar27;
          if (uVar17 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar20 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
            *(undefined4 *)(ppbVar20 + 8) = 0;
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
          }
          else {
            iVar16 = uVar17 - 1;
            *(short *)((longlong)ppbVar20 + 0x2a) =
                 ((short)(iVar16 / 0x1e) + (short)(iVar16 >> 0x1f)) -
                 (short)((longlong)iVar16 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
            *(undefined4 *)(ppbVar20 + 8) = 0;
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar13 & 0x1c) != 4) || (uVar25 = 1, (bVar13 & 2) == 0)) {
            uVar25 = uVar19;
          }
          if (uVar25 == 0) {
            uVar15 = 1;
          }
          else {
            *(undefined4 *)(ppbVar20 + 8) = 0;
            uVar15 = uVar22;
          }
          ppbVar20[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
          ppbVar20[6] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[3] = pbVar5;
          *(uint *)((longlong)ppbVar20 + 0x14) = uVar15;
          *(uint *)(ppbVar20 + 8) = (uint)(uVar25 != 0);
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
          ppbVar20[6] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          ppbVar20[3] = pbVar5;
          *(undefined4 *)((longlong)ppbVar20 + 0x14) = 9;
          *(undefined4 *)(ppbVar20 + 8) = 0;
          ppbVar20[4] = (byte *)0x0;
        }
      }
      sVar14 = *(short *)(&stack0xfffffffffffffff0 + lVar8);
    }
    if ((**ppbVar20 & 4) != 0) {
      if (*(short *)(&stack0xfffffffffffffffa + lVar8) == 0) {
        uVar9 = (ulonglong)sVar14;
      }
      else {
        uVar9 = (ulonglong)
                *(ushort *)
                 (uVar28 + 0x61 + (longlong)*(short *)(&stack0xfffffffffffffffa + lVar8) * 2);
      }
      psVar10 = (short *)(pbVar23 + uVar9);
      ppbVar20[9] = (byte *)psVar10;
      sVar27 = *psVar10;
      ppbVar20[10] = (byte *)(psVar10 + 1);
      *(short *)(ppbVar20 + 0xb) = (sVar27 + 1) * 2;
    }
    pbVar23 = ppbVar20[1];
    if (pbVar23 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1004b9;
      func_0x(pbVar23,ppbVar20);
    }
  }
  uVar25 = 9;
  uVar17 = *(ushort *)(uVar28 + 0xe);
  pbVar23 = (byte *)(*(ushort *)(uVar28 + 0x1ffe) + uVar28);
  bVar13 = *pbVar23;
  *(byte **)((longlong)&pbStackX_20 + lVar8) = pbVar23;
  if ((bVar13 & 1) == 0) {
    *(undefined2 *)((longlong)&uStackX_18 + lVar8) = 0;
    *(undefined4 *)((longlong)&uStackX_18 + lVar8 + 4) = 0;
    *(undefined4 *)(&stack0x0000003e + lVar8) = 0;
    uVar22 = uVar19;
    uVar15 = (uint)uVar17;
    switch(*pbVar23 & 0xe) {
    default:
      uVar17 = *(ushort *)(pbVar23 + 2);
      uVar15 = (uint)uVar17;
      if (0x1f9d < uVar17 - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100692;
        func_0x(pbVar23,6);
        uVar22 = *(uint *)((longlong)&uStackX_18 + lVar8 + 4);
      }
      break;
    case 4:
      uVar22 = 0;
      uVar15 = uVar25;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar15 = 1;
    }
    *(uint *)(&stack0x00000028 + lVar8) = uVar15;
    *(ulonglong *)(&stack0x00000036 + lVar8) = uVar28 + 0x2000;
    ppbVar20 = (byte **)(ulonglong)uVar15;
  }
  else {
    *(undefined2 *)((longlong)&uStackX_18 + lVar8) = 1;
    bVar13 = *pbVar23;
    switch(bVar13 & 0x1c) {
    default:
      if ((char)pbVar23[1] < '\0') {
        uVar17 = *(ushort *)(pbVar23 + 1);
        sVar26 = 3;
        *(undefined2 *)(&stack0x00000030 + lVar8) = 3;
        uVar17 = (uVar17 & 0x7f) << 8 | uVar17 >> 8;
        *(ushort *)((longlong)&uStackX_18 + lVar8 + 2) = uVar17;
      }
      else {
        uVar17 = (ushort)pbVar23[1];
        *(ushort *)((longlong)&uStackX_18 + lVar8 + 2) = uVar17;
        *(undefined2 *)(&stack0x00000030 + lVar8) = 2;
      }
      *(ushort *)(&stack0x00000034 + lVar8) = ((ushort)(uVar17 + 1) >> 1) + sVar26;
      if (uVar17 < 0x1f) {
        *(undefined2 *)(&stack0x00000032 + lVar8) = 0;
        *(undefined4 *)((longlong)&uStackX_18 + lVar8 + 4) = 0;
        uVar22 = uVar19;
      }
      else {
        iVar16 = uVar17 - 1;
        *(undefined4 *)((longlong)&uStackX_18 + lVar8 + 4) = 0;
        *(short *)(&stack0x00000032 + lVar8) =
             ((short)(iVar16 / 0x1e) + (short)(iVar16 >> 0x1f)) -
             (short)((longlong)iVar16 * 0x88888889 >> 0x3f);
        uVar22 = uVar19;
      }
      break;
    case 4:
      if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
        *(undefined8 *)(&stack0x00000030 + lVar8) = 0;
        *(undefined2 *)((longlong)&uStackX_18 + lVar8 + 2) = 0;
        *(undefined8 *)(&stack0x00000038 + lVar8) = 0;
        *(undefined4 *)((longlong)&uStackX_18 + lVar8 + 4) = 0xf;
      }
      else {
        *(undefined8 *)(&stack0x00000030 + lVar8) = 0;
        uVar22 = 1;
        *(undefined2 *)((longlong)&uStackX_18 + lVar8 + 2) = 0;
        *(undefined8 *)(&stack0x00000038 + lVar8) = 0;
        *(undefined4 *)((longlong)&uStackX_18 + lVar8 + 4) = 1;
      }
      break;
    case 8:
      *(undefined8 *)(&stack0x00000030 + lVar8) = 0;
      *(undefined2 *)((longlong)&uStackX_18 + lVar8 + 2) = 0;
      *(undefined8 *)(&stack0x00000038 + lVar8) = 0;
      *(undefined4 *)((longlong)&uStackX_18 + lVar8 + 4) = 9;
      uVar22 = uVar25;
    }
    *(byte ***)(&stack0x00000028 + lVar8) = ppbVar20;
  }
  if (*(short *)((longlong)&uStackX_18 + lVar8) == 0) {
    if (uVar22 == 0) {
      pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar8);
      uVar22 = (uint)ppbVar20;
      *(undefined2 *)((longlong)&uStackX_18 + lVar8 + 2) = 0;
      *(uint *)(&stack0x0000002c + lVar8) = uVar22;
      if ((*pbVar23 & 0x10) != 0) {
        uVar22 = uVar22 + 2 + (*(ushort *)(pbVar23 + ((ulonglong)ppbVar20 & 0xffffffff)) + 7 >> 3);
        *(uint *)(&stack0x0000002c + lVar8) = uVar22;
      }
      if ((**(byte **)((longlong)&pbStackX_20 + lVar8) & 0x20) == 0) {
        *(uint *)((longlong)&uStackX_18 + lVar8 + 4) = uVar22;
        *(undefined2 *)(&stack0x00000034 + lVar8) = 0;
        *(uint *)(&stack0x00000030 + lVar8) = uVar22;
      }
      else {
        puVar29 = (ushort *)(*(byte **)((longlong)&pbStackX_20 + lVar8) + uVar22);
        uVar17 = *puVar29;
        *(ushort *)(&stack0x00000034 + lVar8) = uVar17;
        if (uVar17 == 0) {
          if ((((cRam0000000001a9e18b != '\0') || ((bRam0000000001aaea90 & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam000000000100ca18 * 8) + 8 +
                         (ulonglong)*puRam000000000100ca20), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((cRam0000000001a9e07b == '\0') && ((bRam0000000001aaea90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007b8;
              (*pcRam000000000100c9b8)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007de;
              (*pcRam000000000100c9b0)(1,0x138ebb8,0x14ae888,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007ed;
          func_0x(*(undefined8 *)((longlong)&pbStackX_20 + lVar8),3);
          uVar17 = *(ushort *)(&stack0x00000034 + lVar8);
        }
        uVar15 = *(int *)(&stack0x0000002c + lVar8) + 2 + (uint)uVar17 * 2;
        *(uint *)(&stack0x00000030 + lVar8) = uVar15;
        if (0x1f9e < uVar15) {
          if (((cRam0000000001a9e18b != '\0') || ((bRam0000000001aaea90 & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam000000000100ca18 * 8) + 8 +
                         (ulonglong)*puRam000000000100ca20), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((cRam0000000001a9e07b == '\0') && ((bRam0000000001aaea90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10088b;
              (*pcRam000000000100c9b8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1008b1;
              (*pcRam000000000100c9b0)(1,0x138ebb8,0x14ae888,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1008c0;
          func_0x(*(undefined8 *)((longlong)&pbStackX_20 + lVar8),4);
          uVar17 = *(ushort *)(&stack0x00000034 + lVar8);
          uVar15 = *(uint *)(&stack0x00000030 + lVar8);
        }
        uVar22 = puVar29[uVar17] & 0x7fff;
        *(uint *)((longlong)&uStackX_18 + lVar8 + 4) = uVar22;
        if (uVar22 < uVar15) {
          if ((((cRam0000000001a9e18b != '\0') || ((bRam0000000001aaea90 & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam000000000100ca18 * 8) + 8 +
                         (ulonglong)*puRam000000000100ca20), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((cRam0000000001a9e07b == '\0') && ((bRam0000000001aaea90 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10095d;
              (*pcRam000000000100c9b8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100983;
              (*pcRam000000000100c9b0)(1,0x138ebb8,0x14ae888,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100992;
          func_0x(*(undefined8 *)((longlong)&pbStackX_20 + lVar8),4);
          uVar17 = *(ushort *)(&stack0x00000034 + lVar8);
          uVar15 = *(uint *)(&stack0x00000030 + lVar8);
          uVar22 = *(uint *)((longlong)&uStackX_18 + lVar8 + 4);
        }
        do {
          if (-1 < (short)puVar29[(ulonglong)(uVar17 - 1) + 1]) break;
          lVar11 = (ulonglong)*(uint *)(&stack0x0000002c + lVar8) +
                   *(longlong *)((longlong)&pbStackX_20 + lVar8);
          uVar21 = uVar15;
          if (((uVar17 != 1) &&
              (uVar21 = *(ushort *)(lVar11 + -2 + (ulonglong)uVar17 * 2) & 0x7fff, uVar21 < uVar15))
             || ((*(ushort *)(lVar11 + (ulonglong)uVar17 * 2) & 0x7fff) < uVar21)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100a06;
            func_0x(*(undefined8 *)((longlong)&pbStackX_20 + lVar8),7);
            uVar17 = *(ushort *)(&stack0x00000034 + lVar8);
            uVar15 = *(uint *)(&stack0x00000030 + lVar8);
            uVar22 = *(uint *)((longlong)&uStackX_18 + lVar8 + 4);
          }
          if ((uVar21 < uVar15) || (uVar22 < uVar21)) goto code_r0x00100ce3;
          uVar18 = *(ushort *)((ulonglong)uVar21 + *(longlong *)((longlong)&pbStackX_20 + lVar8));
          if (uVar18 == 5) {
            puVar29 = (ushort *)((longlong)&uStackX_18 + lVar8 + 2);
            *puVar29 = *puVar29 | 2;
            *(ushort *)(&stack0x00000034 + lVar8) = uVar17 - 1;
            break;
          }
          if (uVar18 < 0x400) break;
          puVar1 = (ushort *)((longlong)&uStackX_18 + lVar8 + 2);
          *puVar1 = *puVar1 | 1;
          uVar17 = uVar17 - 1;
          *(ushort *)(&stack0x00000034 + lVar8) = uVar17;
        } while (uVar17 != 0);
      }
      if ((**(byte **)((longlong)&pbStackX_20 + lVar8) & 0x40) == 0) {
        *(undefined4 *)(&stack0x0000003e + lVar8) = 0;
      }
      else {
        *(uint *)(&stack0x0000003e + lVar8) = uVar22;
        *(uint *)((longlong)&uStackX_18 + lVar8 + 4) = uVar22 + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100aef;
        puVar12 = (ulonglong *)func_0x((longlong)&uStackX_18 + lVar8 + 2);
        uVar9 = *puVar12;
        uVar18 = (ushort)(uVar9 >> 0x30);
        uVar17 = uVar18;
        if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
          uVar17 = uVar18 & 0xdfff;
          if ((uVar9 & 0x4000000000000000) != 0) {
            uVar17 = uVar18 | 0x2000;
          }
        }
        if (uVar17 == 0xfffc) {
          uVar19 = (uint)((uVar9 >> 0x20 & 0xffff) >> 5);
        }
        uVar22 = *(int *)((longlong)&uStackX_18 + lVar8 + 4) + uVar19;
        *(uint *)((longlong)&uStackX_18 + lVar8 + 4) = uVar22;
      }
      if ((*(ulonglong *)(&stack0x00000036 + lVar8) != 0) &&
         (*(ulonglong *)(&stack0x00000036 + lVar8) <
          (ulonglong)uVar22 + *(longlong *)((longlong)&pbStackX_20 + lVar8))) {
        if (((cRam0000000001a9e18b != '\0') || ((bRam0000000001aaea90 & 1) != 0)) &&
           (((lVar11 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam000000000100ca18 * 8) + 8 +
                        (ulonglong)*puRam000000000100ca20), lVar11 != 0 &&
             (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((cRam0000000001a9e07b == '\0') && ((bRam0000000001aaea90 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100beb;
            (*pcRam000000000100c9b8)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100c11;
            (*pcRam000000000100c9b0)(1,0x138ebb8,0x14ae888,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100c20;
        func_0x(*(undefined8 *)((longlong)&pbStackX_20 + lVar8),0x12);
        uVar22 = *(uint *)((longlong)&uStackX_18 + lVar8 + 4);
      }
      if (0x3f3b < uVar22 - 1) {
        if (((cRam0000000001a9e18b != '\0') || ((bRam0000000001aaea90 & 1) != 0)) &&
           ((lVar11 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam000000000100ca18 * 8) + 8 +
                       (ulonglong)*puRam000000000100ca20), lVar11 != 0 &&
            ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
             (*(char *)(lVar11 + 0x499) != '\0')))))) {
          if ((cRam0000000001a9e07b == '\0') && ((bRam0000000001aaea90 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100caa;
            (*pcRam000000000100c9b8)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100cd0;
            (*pcRam000000000100c9b0)(1,0x138ebb8,0x14ae888,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100cdf;
        func_0x(*(undefined8 *)((longlong)&pbStackX_20 + lVar8),5);
        uVar22 = *(uint *)((longlong)&uStackX_18 + lVar8 + 4);
      }
    }
code_r0x00100ce3:
    if (uVar22 < 9) {
      bVar13 = **(byte **)((longlong)&pbStackX_20 + lVar8) & 0xe;
joined_r0x00100d1c:
      if ((bVar13 == 0) || (bVar13 == 0xc)) goto code_r0x00100d26;
    }
  }
  else {
    if (uVar22 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d08;
      func_0x((longlong)&uStackX_18 + lVar8 + 2);
      uVar22 = *(uint *)((longlong)&uStackX_18 + lVar8 + 4);
    }
    if (uVar22 < 9) {
      bVar13 = **(byte **)((longlong)&pbStackX_20 + lVar8) & 0x1c;
      goto joined_r0x00100d1c;
    }
  }
  uVar25 = uVar22;
code_r0x00100d26:
  if (0x7ff < uVar25) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d57;
    (*pcRam000000000100c9b0)(1,0x1547260,0x1513968,0x580);
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d6b;
  func_0x(auStack_3898,uVar28);
  puVar6 = &uStackX_18;
  while (iStackX_10 != 0) {
    iStackX_10 = iStackX_10 + -1;
    iVar16 = *(int *)puVar6;
    uVar4 = puVar6[1];
    iVar3 = *(int *)(puVar6 + 2);
    if (0x3b < iVar16) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100dbe;
      (*pcRam000000000100c9b0)(1,0x1547288,0x1513968,0x58e);
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100dcf;
    func_0x(auStack_3898,iVar16,uVar4,iVar3);
    puVar6 = puVar6 + 3;
  }
  iStackX_10 = -1;
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100ded;
  func_0x(uVar28,auStack_3898);
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100e03;
  func_0x(*(undefined8 *)((longlong)&iStackX_10 + lVar8));
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100e12;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar8));
  return;
}

