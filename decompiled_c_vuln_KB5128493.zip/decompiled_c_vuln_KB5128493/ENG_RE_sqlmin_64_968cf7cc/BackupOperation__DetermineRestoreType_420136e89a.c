
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  uint uVar4;
  
  iVar1 = *(int *)(param_1 + 0x8d4);
  uVar4 = ((*(uint *)(param_2 + 8) >> 0xd) << 2 ^ *(uint *)(param_1 + 0x1614)) & 4 ^
          *(uint *)(param_1 + 0x1614);
  *(uint *)(param_1 + 0x1614) = uVar4;
  switch(*(undefined *)(param_2 + 0x57)) {
  case 0x44:
    if (iVar1 == 5) {
      func_0x(param_1,(*(uint *)(*(longlong *)(param_1 + 0x16e0) + 0x5c) & 0x4000 | 0x88000)
                              >> 0xd);
      goto code_r0x001002af;
    }
    if (iVar1 == 6) goto code_r0x001000c3;
    goto joined_r0x001000ec;
  default:
    (*_DAT_)(1,0xd033e0,0xd092a0,0x17f0,0x8fe588);
    goto code_r0x0010022c;
  case 0x46:
  case 0x50:
    if ((iVar1 == 5) || (iVar1 == 6)) {
code_r0x001000c3:
      *(undefined4 *)(param_1 + 0x8d4) = 6;
      *(undefined4 *)(param_1 + 0x8dc) = 0x46;
      goto code_r0x001002af;
    }
    break;
  case 0x47:
  case 0x51:
    if ((iVar1 == 5) || (iVar1 == 6)) goto code_r0x00100144;
    break;
  case 0x49:
    if (iVar1 == 5) {
      uVar3 = 0x49;
      if ((*(uint *)(*(longlong *)(param_1 + 0x16e0) + 0x5c) & 0x4000) != 0) {
        uVar3 = 0x47;
      }
      func_0x(param_1,uVar3);
      goto code_r0x001002af;
    }
    if (iVar1 != 6) goto joined_r0x001000ec;
code_r0x00100144:
    *(undefined4 *)(param_1 + 0x8d4) = 6;
    *(undefined4 *)(param_1 + 0x8dc) = 0x47;
    goto code_r0x001002af;
  case 0x4c:
    goto code_r0x00100169;
  case 0x5a:
    uVar4 = uVar4 | 4;
    *(uint *)(param_1 + 0x1614) = uVar4;
code_r0x00100169:
    if ((*(uint *)(*(longlong *)(param_1 + 0x16e0) + 0x5c) & 0x4000) != 0) goto code_r0x0010022c;
    if (iVar1 == 5) {
      if (((*(uint *)(param_1 + 0x15f8) & 0x40000000) == 0) && ((uVar4 & 4) == 0)) {
        *(undefined4 *)(param_1 + 0x8d4) = 7;
        *(undefined4 *)(param_1 + 0x8dc) = 0x4c;
      }
      else {
        *(undefined4 *)(param_1 + 0x8d4) = 5;
        *(undefined4 *)(param_1 + 0x8dc) = 0x44;
      }
      goto code_r0x001002af;
    }
    if (iVar1 == 6) {
      uVar4 = uVar4 & 4;
      goto joined_r0x00100198;
    }
joined_r0x001000ec:
    if (iVar1 != 7) goto code_r0x0010022c;
    goto code_r0x0010019e;
  }
  if (iVar1 == 7) {
    uVar4 = *(uint *)(param_2 + 8) & 0x200;
joined_r0x00100198:
    if (uVar4 == 0) {
code_r0x0010019e:
      *(undefined4 *)(param_1 + 0x8d4) = 7;
      *(undefined4 *)(param_1 + 0x8dc) = 0x4c;
      goto code_r0x001002af;
    }
  }
code_r0x0010022c:
  uVar3 = _DAT_;
  switch(*(undefined *)(param_2 + 0x57)) {
  case 0x44:
  case 0x5a:
    uVar3 = 0xc83540;
    break;
  case 0x46:
  case 0x50:
    uVar3 = 0xc81fd8;
    break;
  case 0x47:
  case 0x51:
    uVar3 = 0xc83550;
    break;
  case 0x49:
    uVar3 = 0xc81ff8;
    break;
  case 0x4c:
    uVar3 = uRam0000000000c83b30;
  }
  uVar2 = func_0x(*(undefined8 *)(*(longlong *)(param_3 + 0x18) + 0x30));
  (*_DAT_)(0x1f,0x23,0x10,1,uVar2,uVar3);
code_r0x001002af:
  if ((((*(uint *)(param_1 + 0x15f8) & 0x20000) != 0) && (*(int *)(param_1 + 0x8d4) == 7)) &&
     (*(int *)(param_1 + 0x8dc) == 0x4c)) {
    (*_DAT_)(0x1e,0xf,0x10,2,0xc8c668);
  }
  return;
}

