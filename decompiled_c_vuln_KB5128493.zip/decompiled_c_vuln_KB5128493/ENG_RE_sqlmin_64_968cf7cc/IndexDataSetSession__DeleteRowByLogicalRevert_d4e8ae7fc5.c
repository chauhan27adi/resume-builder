
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,byte *param_2,undefined8 param_3,undefined8 param_4,
                 longlong param_5,byte *param_6,undefined8 param_7,char param_8,undefined param_9)

{
  int *piVar1;
  undefined2 uVar2;
  undefined8 uVar3;
  uint *puVar4;
  code *pcVar5;
  char *pcVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  byte bVar10;
  int iVar11;
  uint uVar12;
  longlong lVar13;
  short *psVar14;
  ulonglong *puVar15;
  undefined8 *puVar16;
  byte bVar17;
  longlong lVar18;
  byte *pbVar19;
  ushort uVar20;
  ushort uVar21;
  longlong lVar23;
  int *piVar24;
  uint uVar25;
  undefined4 uVar26;
  longlong lVar27;
  longlong lVar28;
  short sVar29;
  longlong lVar30;
  longlong lVar31;
  ushort *puVar32;
  longlong unaff_GS_OFFSET;
  undefined8 uStackX_8;
  longlong lStack_2108;
  longlong lStack_2100;
  short sStack_20f8;
  ushort uStack_20f6;
  undefined4 uStack_20f4;
  byte *pbStack_20f0;
  undefined8 uStack_20e8;
  undefined4 uStack_20e0;
  short sStack_20dc;
  undefined8 uStack_20da;
  undefined2 uStack_20d2;
  undefined2 uStack_20d0;
  undefined6 uStack_20ce;
  undefined4 uStack_20c8;
  undefined2 uStack_20c0;
  ushort uStack_20be;
  undefined4 uStack_20bc;
  byte *pbStack_20b8;
  undefined8 uStack_20b0;
  undefined4 uStack_20a8;
  short sStack_20a4;
  undefined8 uStack_20a2;
  undefined2 uStack_209a;
  undefined2 uStack_2098;
  undefined6 uStack_2096;
  undefined4 uStack_2090;
  undefined auStack_2088 [8];
  short sStack_2080;
  ushort uStack_207e;
  undefined4 uStack_207c;
  byte *pbStack_2078;
  ulonglong uStack_2070;
  uint uStack_2068;
  short sStack_2064;
  undefined8 uStack_2062;
  undefined2 uStack_205a;
  undefined2 uStack_2058;
  undefined2 uStack_2056;
  ushort uStack_2054;
  undefined2 uStack_2052;
  undefined4 auStack_2048 [2];
  undefined8 uStack_2040;
  longlong lStack_2038;
  undefined8 uStack_2030;
  undefined8 uStack_2028;
  undefined auStack_2020 [8];
  undefined auStack_2018 [16];
  undefined8 uStack_2008;
  undefined4 auStack_2000 [2];
  undefined8 uStack_1ff8;
  longlong lStack_1ff0;
  undefined8 uStack_1fe8;
  byte abStack_1fd8 [8096];
  ulonglong uStack_38;
  undefined8 uStack_30;
  ulonglong uVar22;
  
  uStack_30 = 0x10002a;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  uStack_38 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffd8 + lVar13);
  lVar23 = 0;
  *(undefined *)((longlong)&param_7 + lVar13) = param_9;
  uStack_20bc = 0;
  uStack_20a2 = 0;
  sStack_2080 = -1;
  bVar10 = *param_2;
  lVar31 = *(longlong *)(param_1 + 0x10);
  uStack_2098 = 0;
  uStack_2096 = 0;
  sVar29 = 3;
  uStack_20b0 = 0;
  pbStack_2078 = (byte *)0x0;
  uStack_207c = 0;
  uStack_2062 = 0;
  uStack_2058 = 0;
  uStack_2056 = 0;
  uStack_2054 = 0;
  uStack_2052 = 0;
  uStack_2070 = 0;
  uStack_2008 = 0;
  auStack_2018 = ZEXT816(0);
  uStack_2028 = 0;
  lStack_2100 = param_5;
  lStack_2108 = 0;
  pbStack_20b8 = param_2;
  lStack_2038 = param_1;
  uStack_2030 = param_4;
  if ((bVar10 & 1) == 0) {
    uStack_20c0 = 0;
    uStack_209a = 0;
    uStack_2098 = 0;
    uVar12 = *(ushort *)(*(longlong *)(lVar31 + 8) + 0xba) - 6;
    switch(bVar10 & 0xe) {
    default:
      uVar12 = (uint)*(ushort *)(param_2 + 2);
      if (0x1f9d < uVar12 - 1) {
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100268;
        func_0x(param_2,6,param_2,0x156ba38);
      }
      break;
    case 4:
      uVar12 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar12 = 1;
    }
    uStack_20b0 = CONCAT44(uStack_20b0._4_4_,uVar12);
  }
  else {
    uStack_20c0 = 1;
    switch(bVar10 & 0x1c) {
    default:
      if ((char)param_2[1] < '\0') {
        uStack_20a8 = 3;
        uStack_20be = (*(ushort *)(param_2 + 1) & 0x7f) << 8 | *(ushort *)(param_2 + 1) >> 8;
      }
      else {
        uStack_20be = (ushort)param_2[1];
        uStack_20a8 = 2;
        sVar29 = 2;
      }
      sStack_20a4 = ((ushort)(uStack_20be + 1) >> 1) + sVar29;
      if (uStack_20be < 0x1f) {
        uStack_2090 = 0;
      }
      else {
        iVar11 = uStack_20be - 1;
        uStack_2090 = 0;
        uStack_20a8 = CONCAT22(((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                               (short)((longlong)iVar11 * 0x88888889 >> 0x3f),
                               (undefined2)uStack_20a8);
      }
      break;
    case 4:
      if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
        uStack_20a8 = 0;
        uStack_20be = 0;
        sStack_20a4 = 0;
        uStack_209a = 0;
        uStack_20bc = 0xf;
        uStack_2090 = 1;
      }
      else {
        uStack_20a8 = 0;
        uStack_20be = 0;
        sStack_20a4 = 0;
        uStack_209a = 0;
        uStack_20bc = 1;
        uStack_2090 = 0;
      }
      break;
    case 8:
      uStack_20a8 = 0;
      uStack_20be = 0;
      sStack_20a4 = 0;
      uStack_209a = 0;
      uStack_20bc = 9;
      uStack_2090 = 0;
    }
  }
  lVar28 = *(longlong *)(param_1 + 0x328);
  if ((lVar28 == 0) ||
     (lVar27 = *(longlong *)(lVar31 + 8),
     *(uint *)(lVar28 + 0xc) < *(uint *)(**(longlong **)(lVar27 + 0x160) + 0x1c))) {
    *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1002ca;
    (*pcRam000000000146d3c8)(lVar28,0x18);
    *(undefined8 *)(param_1 + 0x328) = 0;
    uVar26 = *(undefined4 *)(**(longlong **)(*(longlong *)(lVar31 + 8) + 0x160) + 0x1c);
    uVar3 = *(undefined8 *)(*(longlong *)(param_1 + 0x2e0) + 8);
    *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1002f9;
    func_0x(uVar3,uVar26,param_1 + 0x328);
    lVar27 = *(longlong *)(lVar31 + 8);
    lVar28 = *(longlong *)(param_1 + 0x328);
  }
  auStack_2048[0] = 0;
  uVar12 = *(uint *)(**(longlong **)(lVar27 + 0x160) + 0x1c);
  lVar30 = lVar23;
  if ((*(int *)(lVar27 + 0x100) != 0) && (1 < *(int *)(lVar27 + 0x100) - 3U)) {
    lVar30 = 1;
  }
  uVar25 = 0;
  (&param_9)[lVar13] = 0;
  *(undefined8 *)(lVar28 + 0x10) = 0;
  *(undefined4 *)(lVar28 + 8) = 0;
  if (uVar12 != 0) {
    do {
      lVar27 = **(longlong **)(*(longlong *)(lVar31 + 8) + 0x160);
      if (lVar23 == 0) {
        lVar18 = *(longlong *)(lVar27 + 0x38);
      }
      else {
        lVar18 = *(longlong *)(lVar23 + 0x168);
      }
      if (lVar18 == lVar27 + 0x30) {
        lVar18 = 0;
      }
      lVar23 = 0;
      if (lVar18 != 0) {
        lVar23 = lVar18 + -0x160;
      }
      *(undefined4 **)((longlong)&param_6 + lVar13) = auStack_2048;
      *(undefined8 *)((longlong)&param_5 + lVar13) = 0;
      *(undefined4 *)(&stack0x00000020 + lVar13) = 0;
      (&stack0x00000018)[lVar13] = 0;
      (&stack0x00000010)[lVar13] = 1;
      *(char *)((longlong)&uStackX_8 + lVar13) = (char)lVar30;
      *(undefined4 *)(&stack0x00000000 + lVar13) = 1;
      *(undefined **)(&stack0xfffffffffffffff8 + lVar13) = &param_9 + lVar13;
      *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1003cc;
      func_0x(lVar28,uVar25,&uStack_20c0,lVar23);
      uVar25 = uVar25 + 1;
    } while (uVar25 < uVar12);
  }
  lVar23 = lStack_2038;
  *(undefined **)(&stack0x00000020 + lVar13) = auStack_2088;
  *(undefined **)(&stack0x00000018 + lVar13) = &stack0x00000050 + lVar13;
  uVar3 = *(undefined8 *)(lStack_2038 + 0x328);
  lVar31 = *(longlong *)(lStack_2038 + 0x108) + 0x90;
  *(char **)(&stack0x00000010 + lVar13) = &param_8 + lVar13;
  *(undefined4 *)((longlong)&uStackX_8 + lVar13) = 3;
  *(undefined4 *)(&stack0x00000000 + lVar13) = 0;
  *(longlong *)(&stack0xfffffffffffffff8 + lVar13) = lVar31;
  *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100434;
  iVar11 = func_0x(lVar23,0,0,uVar3);
  if (iVar11 - 1U < 2) {
    if (lStack_2100 != 0) {
      lVar28 = *(longlong *)(*(longlong *)(lVar23 + 0x10) + 8);
      if ((((*(byte *)(lVar28 + 0x41) & 8) != 0) || ((*(byte *)(lVar28 + 0x108) & 0x40) != 0)) &&
         (*(longlong **)(lVar28 + 0x160) != (longlong *)0x0)) {
        lVar28 = **(longlong **)(lVar28 + 0x160);
        uVar12 = *(uint *)(lVar28 + 100);
        if (uVar12 != 0xffffffff) {
          puVar4 = *(uint **)(lVar28 + 8);
          if (uVar12 < *puVar4) {
            lStack_2108 = ((ulonglong)uVar12 % (ulonglong)puVar4[9]) * 0x1c0 +
                          *(longlong *)
                           (*(longlong *)(puVar4 + 4) +
                           ((ulonglong)uVar12 / (ulonglong)puVar4[9]) * 8);
          }
          else {
            lStack_2108 = ((ulonglong)(uVar12 - *puVar4) % (ulonglong)puVar4[0x11]) * 0x1c0 +
                          *(longlong *)
                           (*(longlong *)(puVar4 + 0xc) +
                           ((ulonglong)(uVar12 - *puVar4) / (ulonglong)puVar4[0x11]) * 8);
          }
          goto code_r0x00100665;
        }
      }
      lStack_2108 = 0;
    }
code_r0x00100665:
    if ((param_8 != '\0') || (lStack_2100 != 0)) {
      lVar28 = *(longlong *)(&param_8 + lVar13);
      uVar12 = *(uint *)(lVar28 + 0x10) & 0xfffffeff;
      *(uint *)(lVar28 + 0x10) = uVar12;
      if (((char)uVar12 < '\0') || ((*(byte *)(lVar28 + 0x34) & 1) == 0)) {
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10069d;
        psVar14 = (short *)func_0x(lVar28,1);
      }
      else {
        psVar14 = (short *)(lVar28 + 0x48);
      }
      sStack_2080 = *psVar14;
      if (sStack_2080 == 0) {
        if (*(int *)(psVar14 + 2) == 0) {
          pbVar19 = *(byte **)(psVar14 + 4);
          uVar12 = *(uint *)(psVar14 + 8);
          uVar22 = (ulonglong)uVar12;
          psVar14[1] = 0;
          *(uint *)(psVar14 + 10) = uVar12;
          bVar10 = *pbVar19;
          if ((bVar10 & 0x10) != 0) {
            uVar12 = uVar12 + (*(ushort *)(pbVar19 + uVar22) + 7 >> 3) + 2;
            uVar22 = (ulonglong)uVar12;
            *(uint *)(psVar14 + 10) = uVar12;
            bVar10 = *pbVar19;
          }
          if ((bVar10 & 0x20) == 0) {
            *(int *)(psVar14 + 2) = (int)uVar22;
            psVar14[0xe] = 0;
            *(int *)(psVar14 + 0xc) = (int)uVar22;
          }
          else {
            puVar32 = (ushort *)(pbVar19 + uVar22);
            uVar20 = *puVar32;
            psVar14[0xe] = uVar20;
            if (uVar20 == 0) {
              if (((cRam0000000001efeb2b != '\0') || ((bRam0000000001f0f430 & 1) != 0)) &&
                 ((lVar28 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam000000000146d3b8 * 8) + 8 +
                             (ulonglong)*puRam000000000146d3c0), lVar28 != 0 &&
                  ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                   (*(char *)(lVar28 + 0x499) != '\0')))))) {
                if ((cRam0000000001efea1b == '\0') && ((bRam0000000001f0f430 & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100791;
                  (*pcRam000000000146d358)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
                  *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1007b8;
                  (*pcRam000000000146d350)(1,0x17ef558,0x190f228,0x80f);
                }
              }
              uVar3 = *(undefined8 *)(psVar14 + 4);
              *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1007c6;
              func_0x(uVar3,3);
              uVar20 = psVar14[0xe];
              uVar22 = (ulonglong)*(uint *)(psVar14 + 10);
            }
            uVar12 = (int)uVar22 + (uVar20 + 1) * 2;
            *(uint *)(psVar14 + 0xc) = uVar12;
            if (0x1f9e < uVar12) {
              if ((((cRam0000000001efeb2b != '\0') || ((bRam0000000001f0f430 & 1) != 0)) &&
                  (lVar28 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam000000000146d3b8 * 8) + 8 +
                             (ulonglong)*puRam000000000146d3c0), lVar28 != 0)) &&
                 ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                  (*(char *)(lVar28 + 0x499) != '\0')))) {
                if ((cRam0000000001efea1b == '\0') && ((bRam0000000001f0f430 & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100866;
                  (*pcRam000000000146d358)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
                  *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10088d;
                  (*pcRam000000000146d350)(1,0x17ef558,0x190f228,0x816);
                }
              }
              uVar3 = *(undefined8 *)(psVar14 + 4);
              *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10089b;
              func_0x(uVar3,4);
              uVar20 = psVar14[0xe];
              uVar12 = *(uint *)(psVar14 + 0xc);
            }
            uVar22 = (ulonglong)uVar20;
            uVar20 = puVar32[uVar22];
            *(uint *)(psVar14 + 2) = uVar20 & 0x7fff;
            if ((uVar20 & 0x7fff) < uVar12) {
              if (((cRam0000000001efeb2b != '\0') || ((bRam0000000001f0f430 & 1) != 0)) &&
                 ((lVar28 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam000000000146d3b8 * 8) + 8 +
                             (ulonglong)*puRam000000000146d3c0), lVar28 != 0 &&
                  ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                   (*(char *)(lVar28 + 0x499) != '\0')))))) {
                if ((cRam0000000001efea1b == '\0') && ((bRam0000000001f0f430 & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10093b;
                  (*pcRam000000000146d358)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
                  *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100962;
                  (*pcRam000000000146d350)(1,0x17ef558,0x190f228,0x81d);
                }
              }
              uVar3 = *(undefined8 *)(psVar14 + 4);
              *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100970;
              func_0x(uVar3,4);
              uVar22 = (ulonglong)(ushort)psVar14[0xe];
            }
            if ((short)puVar32[(ulonglong)((int)uVar22 - 1) + 1] < 0) {
              do {
                lVar28 = *(longlong *)(psVar14 + 4);
                if ((int)uVar22 == 1) {
                  uVar12 = *(uint *)(psVar14 + 0xc);
                  uVar25 = uVar12;
code_r0x001009c0:
                  if ((*(ushort *)((ulonglong)*(uint *)(psVar14 + 10) + lVar28 + uVar22 * 2) &
                      0x7fff) < uVar12) goto code_r0x001009cd;
                }
                else {
                  uVar25 = *(uint *)(psVar14 + 0xc);
                  uVar12 = *(ushort *)
                            ((ulonglong)*(uint *)(psVar14 + 10) + lVar28 + -2 + uVar22 * 2) & 0x7fff
                  ;
                  if (uVar25 <= uVar12) goto code_r0x001009c0;
code_r0x001009cd:
                  *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1009da;
                  func_0x(lVar28,7);
                  uVar25 = *(uint *)(psVar14 + 0xc);
                  lVar28 = *(longlong *)(psVar14 + 4);
                  uVar22 = (ulonglong)(ushort)psVar14[0xe];
                }
                if ((uVar12 < uVar25) || (*(uint *)(psVar14 + 2) < uVar12)) goto code_r0x00100ce7;
                if (*(ushort *)(lVar28 + (ulonglong)uVar12) == 5) {
                  psVar14[1] = psVar14[1] | 2;
                  psVar14[0xe] = (short)uVar22 + -1;
                  psVar14[0x15] = (short)uVar12;
                  lVar28 = (ulonglong)(uVar12 & 0xffff) + *(longlong *)(psVar14 + 4);
                  uVar20 = psVar14[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar28 + 2) & 0x4000) != 0) {
                    uVar20 = *(ushort *)(lVar28 + 2) & 0x3800 | psVar14[0x16] & 0xc7ffU;
                  }
                  psVar14[0x16] = uVar20;
                  psVar14[0x16] = (uVar20 ^ *(ushort *)(lVar28 + 2)) & 0x7ff ^ uVar20;
                  uVar22 = (ulonglong)*(uint *)(psVar14 + 2);
                  pbVar19 = *(byte **)(psVar14 + 4);
                  goto code_r0x00100ac7;
                }
                if (*(ushort *)(lVar28 + (ulonglong)uVar12) < 0x400) break;
                psVar14[1] = psVar14[1] | 1;
                uVar20 = (short)uVar22 - 1;
                uVar22 = (ulonglong)uVar20;
                psVar14[0xe] = uVar20;
                if ((uVar20 == 0) || (-1 < (short)puVar32[(ulonglong)(uVar20 - 1) + 1])) break;
              } while( true );
            }
            uVar22 = (ulonglong)*(uint *)(psVar14 + 2);
            pbVar19 = *(byte **)(psVar14 + 4);
          }
code_r0x00100ac7:
          iVar11 = 0;
          if ((*pbVar19 & 0x40) == 0) {
            *(undefined4 *)(psVar14 + 0x13) = 0;
          }
          else {
            *(int *)(psVar14 + 0x13) = *(int *)(psVar14 + 2);
            *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + 0xe;
            *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100ae4;
            puVar15 = (ulonglong *)func_0x(psVar14 + 1);
            uVar22 = *puVar15;
            uVar21 = (ushort)(uVar22 >> 0x30);
            uVar20 = uVar21;
            if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
              uVar20 = uVar21 & 0xdfff;
              if ((uVar22 & 0x4000000000000000) != 0) {
                uVar20 = uVar21 | 0x2000;
              }
            }
            if (uVar20 == 0xfffc) {
              iVar11 = (int)((uVar22 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + iVar11;
            uVar22 = (ulonglong)*(uint *)(psVar14 + 2);
            pbVar19 = *(byte **)(psVar14 + 4);
          }
          iVar11 = (int)uVar22;
          if ((*(byte **)(psVar14 + 0xf) != (byte *)0x0) &&
             (*(byte **)(psVar14 + 0xf) < pbVar19 + uVar22)) {
            if (((cRam0000000001efeb2b != '\0') || ((bRam0000000001f0f430 & 1) != 0)) &&
               (((lVar28 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam000000000146d3b8 * 8) + 8 +
                            (ulonglong)*puRam000000000146d3c0), lVar28 != 0 &&
                 (lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0)) &&
                (*(char *)(lVar28 + 0x499) != '\0')))) {
              if ((cRam0000000001efea1b == '\0') && ((bRam0000000001f0f430 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100be5;
                (*pcRam000000000146d358)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
                *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100c08;
                (*pcRam000000000146d350)(1,0x17ef558,0x190f228,0x877);
              }
            }
            uVar3 = *(undefined8 *)(psVar14 + 4);
            *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100c16;
            func_0x(uVar3,0x12);
            iVar11 = *(int *)(psVar14 + 2);
          }
          if (0x3f3b < iVar11 - 1U) {
            if (((cRam0000000001efeb2b != '\0') || ((bRam0000000001f0f430 & 1) != 0)) &&
               ((lVar28 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam000000000146d3b8 * 8) + 8 +
                           (ulonglong)*puRam000000000146d3c0), lVar28 != 0 &&
                ((lVar28 = *(longlong *)(lVar28 + 0x60), lVar28 != 0 &&
                 (*(char *)(lVar28 + 0x499) != '\0')))))) {
              if ((cRam0000000001efea1b == '\0') && ((bRam0000000001f0f430 & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100ca3;
                (*pcRam000000000146d358)(0x22,0x44,0x15,0x3ed);
                uVar3 = *(undefined8 *)(psVar14 + 4);
                *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100cb1;
                func_0x(uVar3,5);
                goto code_r0x00100ce7;
              }
              *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
              *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100cd4;
              (*pcRam000000000146d350)(1,0x17ef558,0x190f228,0x87c);
            }
            uVar3 = *(undefined8 *)(psVar14 + 4);
            *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100ce2;
            func_0x(uVar3,5);
          }
        }
code_r0x00100ce7:
        uVar12 = *(uint *)(psVar14 + 2);
        if ((uVar12 < 9) &&
           (((**(byte **)(psVar14 + 4) & 0xe) == 0 || ((**(byte **)(psVar14 + 4) & 0xe) == 0xc)))) {
          uVar12 = 9;
        }
        uStack_207e = psVar14[1];
        uStack_207c = *(undefined4 *)(psVar14 + 2);
        sStack_2064 = psVar14[0xe];
        uStack_2070 = *(ulonglong *)(psVar14 + 8);
        uStack_2068 = *(uint *)(psVar14 + 0xc);
        uStack_205a = (undefined2)*(undefined4 *)(psVar14 + 0x13);
        uStack_2058 = (undefined2)((uint)*(undefined4 *)(psVar14 + 0x13) >> 0x10);
        uVar3 = *(undefined8 *)(psVar14 + 4);
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100d53;
        func_0x(abStack_1fd8,0x1f9e,uVar3,uVar12);
        pbStack_2078 = abStack_1fd8;
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100d67;
        iVar11 = func_0x(&uStack_207e);
        if (iVar11 != 0) {
          puVar32 = (ushort *)(pbStack_2078 + (uStack_2070 >> 0x20));
          uVar12 = *puVar32 - 1;
          if ((uStack_207e & 1) == 0) {
            uVar12 = (uint)*puVar32;
          }
          uVar25 = uStack_2068;
          if (((uVar12 != 1) &&
              (uVar25 = puVar32[(longlong)(int)uVar12 + -1] & 0x7fff, uVar25 < uStack_2068)) ||
             ((puVar32[(int)uVar12] & 0x7fff) < uVar25)) {
            *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100dbd;
            func_0x(pbStack_2078,7);
          }
          uStack_2056 = (undefined2)uVar25;
          if ((*(ushort *)(pbStack_2078 + (ulonglong)(uVar25 & 0xffff) + 2) >> 0xe & 1) == 0) {
            uStack_2054 = uStack_2054 & 0xc7ff;
          }
          else {
            uStack_2054 = uStack_2054 ^
                          (*(ushort *)(pbStack_2078 + (ulonglong)(uVar25 & 0xffff) + 2) ^
                          uStack_2054) & 0x3800;
          }
          uStack_2054 = (uStack_2054 ^ *(ushort *)(pbStack_2078 + (ulonglong)(uVar25 & 0xffff) + 2))
                        & 0x7ff ^ uStack_2054;
        }
      }
      else if (((*psVar14 == 0) || (*(longlong **)(psVar14 + 8) == (longlong *)0x0)) ||
              (**(longlong **)(psVar14 + 8) == 0)) {
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100e5a;
        func_0x(&uStack_207e,abStack_1fd8,0x1f9e,psVar14 + 1);
        uStack_2070 = 0;
        if (*psVar14 != 0) {
          uStack_2070 = *(ulonglong *)(psVar14 + 8);
        }
      }
      else {
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100e3e;
        func_0x(&sStack_2080,abStack_1fd8,0x1f9e,psVar14);
      }
    }
    if (param_6 == (byte *)0x0) {
      if (param_8 == '\0') {
        if (lStack_2100 != 0) {
          uVar2 = *(undefined2 *)(lStack_2108 + 0x38);
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10135c;
          func_0x(&sStack_2080,lStack_2108,lStack_2100,uVar2);
          lVar31 = *(longlong *)(lVar23 + 0x108);
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10137b;
          func_0x(*(undefined8 *)(&param_8 + lVar13),lVar31 + 0x90,0,auStack_2020);
          pcVar5 = *(code **)(**(longlong **)(&param_8 + lVar13) + 8);
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101386;
          (*pcVar5)();
          pcVar6 = *(char **)(lVar23 + 0x380);
          if (((pcVar6 == (char *)0x0) || (pcVar6[3] == '\0')) ||
             ((*pcVar6 == '\0' || (pcVar6[1] == '\0')))) {
            uVar26 = *(undefined4 *)(lVar23 + 0x2f0);
          }
          else {
            uVar26 = 2;
          }
          psVar14 = &sStack_2080;
          goto code_r0x001013bf;
        }
code_r0x0010160b:
        bVar10 = *(byte *)((longlong)&param_7 + lVar13);
        uStack_1ff8 = *(undefined8 *)(&param_8 + lVar13);
      }
      else {
        if (sStack_2080 == 0) {
          bVar10 = *pbStack_2078;
          if ((bVar10 & 0xe) == 10) {
            bVar10 = bVar10 & 0xf7 | 6;
            goto code_r0x00101297;
          }
          if ((bVar10 & 0xe) == 0xc) {
            bVar10 = bVar10 & 0xf1;
            goto code_r0x00101297;
          }
          *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0x156ba38;
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10123b;
          (*pcRam000000000146d350)(1,0x1970890,0x19cc958,0x8ab);
        }
        else {
          bVar10 = *pbStack_2078;
          bVar17 = bVar10 & 0x1c;
          if (bVar17 == 0xc) {
            bVar10 = bVar10 & 0xe3;
          }
          else if (bVar17 == 0x14) {
            bVar10 = bVar10 & 0xf3 | 0x10;
          }
          else {
            if (bVar17 != 0x1c) {
              *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0x156ba38;
              *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101287;
              (*pcRam000000000146d350)(1,0x1970890,0x19cc988,0x542);
              goto code_r0x0010129a;
            }
            bVar10 = bVar10 & 0xfb | 0x18;
          }
code_r0x00101297:
          *pbStack_2078 = bVar10;
        }
code_r0x0010129a:
        if (lStack_2100 != 0) {
          uVar2 = *(undefined2 *)(lStack_2108 + 0x38);
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1012bb;
          func_0x(&sStack_2080,lStack_2108,lStack_2100,uVar2);
        }
        pcVar5 = *(code **)(**(longlong **)(&param_8 + lVar13) + 8);
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1012c6;
        (*pcVar5)();
        bVar10 = *(byte *)((longlong)&param_7 + lVar13);
        *(undefined8 **)(&stack0x00000000 + lVar13) = &uStack_2040;
        *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1012f0;
        iVar11 = func_0x(lVar23,&sStack_2080,(uint)bVar10 * 8 + 4,0);
        if (iVar11 != 0) {
          *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101315;
          (*pcRam000000000146d350)(1,0x199fb48,0x1973910,0x2392);
        }
        lVar31 = *(longlong *)(lVar23 + 0x108);
        *(undefined8 *)(&param_8 + lVar13) = uStack_2040;
        lVar31 = lVar31 + 0x90;
        uStack_1ff8 = uStack_2040;
      }
    }
    else {
      bVar10 = *param_6;
      uStack_20f4 = 0;
      uStack_20da = 0;
      uStack_20d0 = 0;
      uStack_20ce = 0;
      uStack_20e8 = 0;
      pbStack_20f0 = param_6;
      if ((bVar10 & 1) == 0) {
        sStack_20f8 = 0;
        uStack_20d2 = 0;
        uStack_20d0 = 0;
        uVar12 = (uint)*(ushort *)(*(longlong *)(*(longlong *)(lVar23 + 0x10) + 8) + 0xb8);
        switch(bVar10 & 0xe) {
        default:
          uVar12 = (uint)*(ushort *)(param_6 + 2);
          if (0x1f9d < *(ushort *)(param_6 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101049;
            func_0x(param_6,6);
          }
          break;
        case 4:
          uVar12 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar12 = 1;
        }
        uStack_20e8 = CONCAT44(uStack_20e8._4_4_,uVar12);
      }
      else {
        sStack_20f8 = 1;
        switch(bVar10 & 0x1c) {
        default:
          if ((char)param_6[1] < '\0') {
            uStack_20f6 = (*(ushort *)(param_6 + 1) & 0x7f) << 8 | *(ushort *)(param_6 + 1) >> 8;
            uStack_20e0 = 3;
            sStack_20dc = 3;
          }
          else {
            uStack_20f6 = (ushort)param_6[1];
            sStack_20dc = 2;
            uStack_20e0 = 2;
          }
          sStack_20dc = ((ushort)(uStack_20f6 + 1) >> 1) + sStack_20dc;
          if (uStack_20f6 < 0x1f) {
            uStack_20c8 = 0;
          }
          else {
            iVar11 = uStack_20f6 - 1;
            uStack_20c8 = 0;
            uStack_20e0 = CONCAT22(((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                                   (short)((longlong)iVar11 * 0x88888889 >> 0x3f),
                                   (undefined2)uStack_20e0);
          }
          break;
        case 4:
          if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
            uStack_20e0 = 0;
            uStack_20f6 = 0;
            sStack_20dc = 0;
            uStack_20d2 = 0;
            uStack_20f4 = 0xf;
            uStack_20c8 = 1;
          }
          else {
            uStack_20e0 = 0;
            uStack_20f6 = 0;
            sStack_20dc = 0;
            uStack_20d2 = 0;
            uStack_20f4 = 1;
            uStack_20c8 = 0;
          }
          break;
        case 8:
          uStack_20e0 = 0;
          uStack_20f6 = 0;
          sStack_20dc = 0;
          uStack_20d2 = 0;
          uStack_20f4 = 9;
          uStack_20c8 = 0;
        }
      }
      if (sStack_20f8 == 0) {
        bVar10 = *pbStack_20f0;
        if ((bVar10 & 0xe) == 10) {
          bVar10 = bVar10 & 0xf7 | 6;
          goto code_r0x0010112a;
        }
        if ((bVar10 & 0xe) == 0xc) {
          bVar10 = bVar10 & 0xf1;
          goto code_r0x0010112a;
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0x156ba38;
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1010ce;
        (*pcRam000000000146d350)(1,0x1970890,0x19cc958,0x8ab);
      }
      else {
        bVar10 = *pbStack_20f0;
        bVar17 = bVar10 & 0x1c;
        if (bVar17 == 0xc) {
          bVar10 = bVar10 & 0xe3;
        }
        else if (bVar17 == 0x14) {
          bVar10 = bVar10 & 0xf3 | 0x10;
        }
        else {
          if (bVar17 != 0x1c) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0x156ba38;
            *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10111a;
            (*pcRam000000000146d350)(1,0x1970890,0x19cc988,0x542);
            goto code_r0x0010112d;
          }
          bVar10 = bVar10 & 0xfb | 0x18;
        }
code_r0x0010112a:
        *pbStack_20f0 = bVar10;
      }
code_r0x0010112d:
      if (param_8 == '\0') {
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1011bb;
        func_0x(*(longlong **)(&param_8 + lVar13),lVar31,0,auStack_2020);
        pcVar6 = *(char **)(lVar23 + 0x380);
        if ((((pcVar6 == (char *)0x0) || (pcVar6[3] == '\0')) || (*pcVar6 == '\0')) ||
           (uVar26 = 2, pcVar6[1] == '\0')) {
          uVar26 = *(undefined4 *)(lVar23 + 0x2f0);
        }
        psVar14 = &sStack_20f8;
code_r0x001013bf:
        *(uint *)(&stack0x00000010 + lVar13) = **(uint **)(lVar23 + 0x108) >> 0x1b & 1;
        *(undefined8 *)((longlong)&uStackX_8 + lVar13) = 0;
        *(undefined8 *)(&stack0x00000000 + lVar13) = 0;
        *(undefined **)(&stack0xfffffffffffffff8 + lVar13) = auStack_2020;
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1013f2;
        func_0x(*(undefined8 *)(&param_8 + lVar13),psVar14,uVar26,0);
        uVar3 = *(undefined8 *)(lVar23 + 0x328);
        lVar31 = *(longlong *)(lVar23 + 0x108) + 0x90;
        *(undefined **)(&stack0x00000020 + lVar13) = auStack_2088;
        *(undefined **)(&stack0x00000018 + lVar13) = &stack0x00000050 + lVar13;
        *(char **)(&stack0x00000010 + lVar13) = &param_8 + lVar13;
        *(undefined4 *)((longlong)&uStackX_8 + lVar13) = 3;
        *(undefined4 *)(&stack0x00000000 + lVar13) = 0;
        *(longlong *)(&stack0xfffffffffffffff8 + lVar13) = lVar31;
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101444;
        iVar11 = func_0x(lVar23,0,0,uVar3);
        if (iVar11 == 2) goto code_r0x0010160b;
        lVar31 = *(longlong *)(&param_8 + lVar13);
        if (lVar31 != 0) {
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101463;
          func_0x(lVar31);
          lVar23 = *(longlong *)(lVar31 + 0x18);
          if (lVar23 != 0) {
            uVar12 = *(uint *)(lVar23 + 4);
            if ((uVar12 & 8) != 0) {
              *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101483;
              iVar11 = func_0x(lVar23 + 0x90);
              if (iVar11 != 0) {
                iVar11 = *(int *)(*(longlong *)(lVar23 + 0x18) + 0x20);
                if (iVar11 != 0) {
                  *(int *)(*(longlong *)(lVar23 + 0x18) + 0x20) = iVar11 + -1;
                }
              }
              uVar12 = *(uint *)(lVar23 + 4) & 0xfffffff7;
            }
            *(uint *)(lVar23 + 4) = uVar12 & 0xffffffdf;
            piVar24 = *(int **)(lVar31 + 0x18);
            piVar1 = piVar24 + 2;
            *piVar1 = *piVar1 + -1;
            if (*piVar1 == 0) {
              if (*piVar24 == 1) {
                *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1014bc;
                func_0x(piVar24,1);
              }
              else if ((piVar24[1] & 4U) != 0) {
                if ((piVar24[1] & 0x10U) == 0) {
                  lVar23 = *(longlong *)(piVar24 + 0x12);
                  if ((lVar23 != CONCAT44(iRam0000000001f0faec,iRam0000000001f0fae8)) ||
                     (*(longlong *)(piVar24 + 0x14) !=
                      CONCAT44(iRam0000000001f0faf4,iRam0000000001f0faf0))) {
                    *(undefined4 *)(lVar23 + 0x48) = 0;
                    *(undefined8 *)(lVar23 + 0x50) = 0;
                    *(undefined *)((longlong)piVar24 + 0x3e) = 0;
                    *(undefined2 *)(piVar24 + 0xf) = 0;
                    *(undefined8 *)(piVar24 + 0xc) = 0;
                  }
                  iVar8 = iRam0000000001f0faf4;
                  iVar7 = iRam0000000001f0faf0;
                  iVar11 = iRam0000000001f0faec;
                  piVar24[0x12] = iRam0000000001f0fae8;
                  piVar24[0x13] = iVar11;
                  piVar24[0x14] = iVar7;
                  piVar24[0x15] = iVar8;
                  *(undefined8 *)(piVar24 + 0x16) = 0;
                }
                uVar3 = *(undefined8 *)(*(longlong *)(piVar24 + 6) + 0x10);
                *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101518;
                func_0x(uVar3,piVar24 + 8);
                piVar24[1] = piVar24[1] & 0xffffff6b;
              }
            }
          }
          *(undefined8 *)(lVar31 + 0x18) = 0;
          *(undefined4 *)(lVar31 + 0x158) = 1;
          *(undefined4 *)(lVar31 + 0x10) = 2;
          *(undefined4 *)(lVar31 + 0x30) = 0xffffffff;
          *(undefined8 *)(lVar31 + 0x20) = 0;
        }
        lVar31 = *(longlong *)(&stack0x00000050 + lVar13);
        if (lVar31 == 0) goto code_r0x00101784;
        uVar12 = *(uint *)(lVar31 + 4);
        if ((uVar12 & 8) != 0) {
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101559;
          iVar11 = func_0x(lVar31 + 0x90);
          if (iVar11 != 0) {
            iVar11 = *(int *)(*(longlong *)(lVar31 + 0x18) + 0x20);
            if (iVar11 != 0) {
              *(int *)(*(longlong *)(lVar31 + 0x18) + 0x20) = iVar11 + -1;
            }
          }
          *(uint *)(lVar31 + 4) = *(uint *)(lVar31 + 4) & 0xfffffff7;
          uVar12 = *(uint *)(lVar31 + 4);
        }
        *(uint *)(lVar31 + 4) = uVar12 & 0xffffffdf;
        piVar24 = *(int **)(&stack0x00000050 + lVar13);
        piVar1 = piVar24 + 2;
        *piVar1 = *piVar1 + -1;
        if (*piVar1 != 0) goto code_r0x00101784;
        if (*piVar24 == 1) goto code_r0x0010158a;
        if ((piVar24[1] & 4U) == 0) goto code_r0x00101784;
        if ((piVar24[1] & 0x10U) == 0) {
          lVar31 = *(longlong *)(piVar24 + 0x12);
          if ((lVar31 != CONCAT44(iRam0000000001f0faec,iRam0000000001f0fae8)) ||
             (*(longlong *)(piVar24 + 0x14) != CONCAT44(iRam0000000001f0faf4,iRam0000000001f0faf0)))
          {
            *(undefined4 *)(lVar31 + 0x48) = 0;
            *(undefined8 *)(lVar31 + 0x50) = 0;
            *(undefined *)((longlong)piVar24 + 0x3e) = 0;
            goto code_r0x001015cd;
          }
          goto code_r0x001015d6;
        }
        goto code_r0x001015e5;
      }
      pcVar5 = *(code **)(**(longlong **)(&param_8 + lVar13) + 8);
      *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101141;
      (*pcVar5)();
      bVar10 = *(byte *)((longlong)&param_7 + lVar13);
      *(undefined8 **)(&stack0x00000000 + lVar13) = &uStack_2040;
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
      *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10116b;
      iVar11 = func_0x(lVar23,&sStack_20f8,(uint)bVar10 * 8 + 4,0);
      if (iVar11 != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101190;
        (*pcRam000000000146d350)(1,0x199fb48,0x1973910,0x2318);
      }
      lVar31 = *(longlong *)(lVar23 + 0x108);
      *(undefined8 *)(&param_8 + lVar13) = uStack_2040;
      lVar31 = lVar31 + 0x90;
      uStack_1ff8 = uStack_2040;
    }
    *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101620;
    func_0x(uStack_1ff8,lVar31);
    uStack_1fe8 = uStack_2030;
    pcVar6 = *(char **)(lVar23 + 0x380);
    auStack_2000[0] = 1;
    if ((((pcVar6 == (char *)0x0) || (pcVar6[3] == '\0')) || (*pcVar6 == '\0')) ||
       (uVar26 = 2, pcVar6[1] == '\0')) {
      uVar26 = *(undefined4 *)(lVar23 + 0x2f0);
    }
    lStack_1ff0 = lVar31;
    *(uint *)(&stack0x00000000 + lVar13) = **(uint **)(lVar23 + 0x108) >> 0x1b & 1;
    puVar16 = &uStack_2028;
    if (bVar10 == 0) {
      puVar16 = (undefined8 *)0x0;
    }
    *(undefined8 **)(&stack0xfffffffffffffff8 + lVar13) = puVar16;
    *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10169d;
    func_0x(*(undefined8 *)(&param_8 + lVar13),uVar26,0,auStack_2000);
    lVar31 = *(longlong *)(&param_8 + lVar13);
    *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1016aa;
    func_0x(lVar31);
    lVar23 = *(longlong *)(lVar31 + 0x18);
    if (lVar23 != 0) {
      uVar12 = *(uint *)(lVar23 + 4);
      if ((uVar12 & 8) != 0) {
        *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1016ca;
        iVar11 = func_0x(lVar23 + 0x90);
        if (iVar11 != 0) {
          iVar11 = *(int *)(*(longlong *)(lVar23 + 0x18) + 0x20);
          if (iVar11 != 0) {
            *(int *)(*(longlong *)(lVar23 + 0x18) + 0x20) = iVar11 + -1;
          }
        }
        uVar12 = *(uint *)(lVar23 + 4) & 0xfffffff7;
      }
      *(uint *)(lVar23 + 4) = uVar12 & 0xffffffdf;
      piVar24 = *(int **)(lVar31 + 0x18);
      piVar1 = piVar24 + 2;
      *piVar1 = *piVar1 + -1;
      if (*piVar1 == 0) {
        if (*piVar24 == 1) {
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101703;
          func_0x(piVar24,1);
        }
        else if ((piVar24[1] & 4U) != 0) {
          if ((piVar24[1] & 0x10U) == 0) {
            lVar23 = *(longlong *)(piVar24 + 0x12);
            if ((lVar23 != CONCAT44(iRam0000000001f0faec,iRam0000000001f0fae8)) ||
               (*(longlong *)(piVar24 + 0x14) != CONCAT44(iRam0000000001f0faf4,iRam0000000001f0faf0)
               )) {
              *(undefined4 *)(lVar23 + 0x48) = 0;
              *(undefined8 *)(lVar23 + 0x50) = 0;
              *(undefined *)((longlong)piVar24 + 0x3e) = 0;
              *(undefined8 *)(piVar24 + 0xc) = 0;
              *(undefined2 *)(piVar24 + 0xf) = 0;
            }
            iVar9 = iRam0000000001f0faf4;
            iVar8 = iRam0000000001f0faf0;
            iVar7 = iRam0000000001f0faec;
            iVar11 = iRam0000000001f0fae8;
            *(undefined8 *)(piVar24 + 0x16) = 0;
            piVar24[0x12] = iVar11;
            piVar24[0x13] = iVar7;
            piVar24[0x14] = iVar8;
            piVar24[0x15] = iVar9;
          }
          uVar3 = *(undefined8 *)(*(longlong *)(piVar24 + 6) + 0x10);
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10175f;
          func_0x(uVar3,piVar24 + 8);
          piVar24[1] = piVar24[1] & 0xffffff6b;
        }
      }
    }
    *(undefined8 *)(lVar31 + 0x18) = 0;
    *(undefined8 *)(lVar31 + 0x20) = 0;
    *(undefined4 *)(lVar31 + 0x30) = 0xffffffff;
    *(undefined4 *)(lVar31 + 0x10) = 2;
    *(undefined4 *)(lVar31 + 0x158) = 1;
  }
  else {
    lVar31 = *(longlong *)(&param_8 + lVar13);
    if (lVar31 != 0) {
      *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100455;
      func_0x(lVar31);
      lVar23 = *(longlong *)(lVar31 + 0x18);
      if (lVar23 != 0) {
        uVar12 = *(uint *)(lVar23 + 4);
        if ((uVar12 & 8) != 0) {
          *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100475;
          iVar11 = func_0x(lVar23 + 0x90);
          if (iVar11 != 0) {
            iVar11 = *(int *)(*(longlong *)(lVar23 + 0x18) + 0x20);
            if (iVar11 != 0) {
              *(int *)(*(longlong *)(lVar23 + 0x18) + 0x20) = iVar11 + -1;
            }
          }
          uVar12 = *(uint *)(lVar23 + 4) & 0xfffffff7;
        }
        *(uint *)(lVar23 + 4) = uVar12 & 0xffffffdf;
        piVar24 = *(int **)(lVar31 + 0x18);
        piVar1 = piVar24 + 2;
        *piVar1 = *piVar1 + -1;
        if (*piVar1 == 0) {
          if (*piVar24 == 1) {
            *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1004ae;
            func_0x(piVar24,1);
          }
          else if ((piVar24[1] & 4U) != 0) {
            if ((piVar24[1] & 0x10U) == 0) {
              lVar23 = *(longlong *)(piVar24 + 0x12);
              if ((lVar23 != CONCAT44(iRam0000000001f0faec,iRam0000000001f0fae8)) ||
                 (*(longlong *)(piVar24 + 0x14) !=
                  CONCAT44(iRam0000000001f0faf4,iRam0000000001f0faf0))) {
                *(undefined4 *)(lVar23 + 0x48) = 0;
                *(undefined8 *)(lVar23 + 0x50) = 0;
                *(undefined *)((longlong)piVar24 + 0x3e) = 0;
                *(undefined8 *)(piVar24 + 0xc) = 0;
                *(undefined2 *)(piVar24 + 0xf) = 0;
              }
              iVar9 = iRam0000000001f0faf4;
              iVar8 = iRam0000000001f0faf0;
              iVar7 = iRam0000000001f0faec;
              iVar11 = iRam0000000001f0fae8;
              *(undefined8 *)(piVar24 + 0x16) = 0;
              piVar24[0x12] = iVar11;
              piVar24[0x13] = iVar7;
              piVar24[0x14] = iVar8;
              piVar24[0x15] = iVar9;
            }
            uVar3 = *(undefined8 *)(*(longlong *)(piVar24 + 6) + 0x10);
            *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x10050a;
            func_0x(uVar3,piVar24 + 8);
            piVar24[1] = piVar24[1] & 0xffffff6b;
          }
        }
      }
      *(undefined8 *)(lVar31 + 0x18) = 0;
      *(undefined4 *)(lVar31 + 0x10) = 2;
      *(undefined8 *)(lVar31 + 0x20) = 0;
      *(undefined4 *)(lVar31 + 0x30) = 0xffffffff;
      *(undefined4 *)(lVar31 + 0x158) = 1;
    }
    lVar31 = *(longlong *)(&stack0x00000050 + lVar13);
    if (lVar31 == 0) goto code_r0x00101784;
    uVar12 = *(uint *)(lVar31 + 4);
    if ((uVar12 & 8) != 0) {
      *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x100559;
      iVar11 = func_0x(lVar31 + 0x90);
      if (iVar11 != 0) {
        iVar11 = *(int *)(*(longlong *)(lVar31 + 0x18) + 0x20);
        if (iVar11 != 0) {
          *(int *)(*(longlong *)(lVar31 + 0x18) + 0x20) = iVar11 + -1;
        }
      }
      *(uint *)(lVar31 + 4) = *(uint *)(lVar31 + 4) & 0xfffffff7;
      uVar12 = *(uint *)(lVar31 + 4);
    }
    *(uint *)(lVar31 + 4) = uVar12 & 0xffffffdf;
    piVar24 = *(int **)(&stack0x00000050 + lVar13);
    piVar1 = piVar24 + 2;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 != 0) goto code_r0x00101784;
    if (*piVar24 == 1) {
code_r0x0010158a:
      *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101594;
      func_0x(piVar24,1);
      goto code_r0x00101784;
    }
    if ((piVar24[1] & 4U) == 0) goto code_r0x00101784;
    if ((piVar24[1] & 0x10U) == 0) {
      lVar31 = *(longlong *)(piVar24 + 0x12);
      if ((lVar31 != CONCAT44(iRam0000000001f0faec,iRam0000000001f0fae8)) ||
         (*(longlong *)(piVar24 + 0x14) != CONCAT44(iRam0000000001f0faf4,iRam0000000001f0faf0))) {
        *(undefined4 *)(lVar31 + 0x48) = 0;
        *(undefined8 *)(lVar31 + 0x50) = 0;
        *(undefined *)((longlong)piVar24 + 0x3e) = 0;
code_r0x001015cd:
        *(undefined2 *)(piVar24 + 0xf) = 0;
        *(undefined8 *)(piVar24 + 0xc) = 0;
      }
code_r0x001015d6:
      iVar8 = iRam0000000001f0faf4;
      iVar7 = iRam0000000001f0faf0;
      iVar11 = iRam0000000001f0faec;
      piVar24[0x12] = iRam0000000001f0fae8;
      piVar24[0x13] = iVar11;
      piVar24[0x14] = iVar7;
      piVar24[0x15] = iVar8;
      *(undefined8 *)(piVar24 + 0x16) = 0;
    }
code_r0x001015e5:
    uVar3 = *(undefined8 *)(*(longlong *)(piVar24 + 6) + 0x10);
    *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x1015f6;
    func_0x(uVar3,piVar24 + 8);
    piVar24[1] = piVar24[1] & 0xffffff6b;
  }
code_r0x00101784:
  *(undefined8 *)((longlong)&uStack_30 + lVar13) = 0x101793;
  func_0x(uStack_38 ^ (ulonglong)(&stack0xffffffffffffffd8 + lVar13));
  return;
}

