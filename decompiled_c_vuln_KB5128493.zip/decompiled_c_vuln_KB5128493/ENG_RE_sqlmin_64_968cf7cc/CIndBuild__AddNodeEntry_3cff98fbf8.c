
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  undefined uVar3;
  longlong lVar4;
  longlong *plVar5;
  int *piVar6;
  uint **ppuVar7;
  char cVar8;
  byte bVar9;
  ushort uVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  ulonglong uVar14;
  longlong lVar15;
  short *psVar16;
  ulonglong *puVar17;
  longlong lVar18;
  longlong lVar19;
  uint *puVar20;
  undefined4 uVar21;
  ushort uVar22;
  uint uVar23;
  uint uVar24;
  int *piVar25;
  ulonglong uVar26;
  uint uVar27;
  byte **ppbVar28;
  ushort *puVar29;
  ulonglong **ppuVar30;
  int *piVar31;
  short sVar32;
  longlong lVar33;
  longlong *plVar34;
  ulonglong uVar35;
  longlong unaff_GS_OFFSET;
  bool bVar36;
  undefined auStack_d88 [32];
  undefined8 uStack_d68;
  undefined8 uStack_d60;
  undefined8 uStack_d58;
  undefined8 uStack_d50;
  longlong lStack_d48;
  undefined8 uStack_d40;
  ulonglong uStack_d38;
  undefined4 uStack_d30;
  undefined8 uStack_d28;
  ulonglong *puStack_d18;
  undefined uStack_d10;
  uint uStack_d0c;
  uint uStack_d08;
  int aiStack_d00 [2];
  longlong *plStack_cf8;
  undefined uStack_cf0;
  uint uStack_cec;
  uint uStack_ce8;
  undefined8 uStack_ce0;
  undefined4 uStack_cd8;
  int iStack_cd0;
  short sStack_ccc;
  undefined8 uStack_cc8;
  undefined4 uStack_cc0;
  undefined2 uStack_cb8;
  ushort uStack_cb6;
  undefined4 uStack_cb4;
  byte *pbStack_cb0;
  undefined8 uStack_ca8;
  uint uStack_ca0;
  short sStack_c9c;
  undefined8 uStack_c9a;
  undefined2 uStack_c92;
  undefined2 uStack_c90;
  undefined6 uStack_c8e;
  undefined4 uStack_c88;
  uint uStack_c80;
  uint uStack_c7c;
  uint uStack_c78;
  uint uStack_c74;
  undefined4 uStack_c70;
  ulonglong uStack_c68;
  longlong *plStack_c60;
  undefined8 uStack_c58;
  ushort uStack_c50;
  undefined8 uStack_c48;
  ushort uStack_c40;
  undefined8 uStack_c38;
  ushort uStack_c30;
  int *piStack_c28;
  undefined8 uStack_c20;
  ushort uStack_c18;
  undefined8 uStack_c10;
  ushort uStack_c08;
  undefined8 uStack_c00;
  ushort uStack_bf8;
  undefined8 uStack_bf0;
  undefined2 uStack_be8;
  undefined auStack_be0 [4];
  undefined4 uStack_bdc;
  undefined auStack_bd8 [4];
  undefined4 uStack_bd4;
  uint uStack_bd0;
  undefined4 uStack_bcc;
  undefined2 uStack_bc8;
  undefined4 uStack_bc4;
  undefined2 uStack_bc0;
  undefined4 uStack_bbc;
  undefined2 uStack_bb8;
  undefined4 uStack_bb4;
  undefined2 uStack_bb0;
  int iStack_bac;
  undefined2 uStack_ba8;
  undefined4 uStack_ba4;
  undefined2 uStack_ba0;
  undefined4 uStack_b9c;
  undefined2 uStack_b98;
  undefined4 uStack_b94;
  undefined2 uStack_b90;
  undefined4 uStack_b8c;
  undefined2 uStack_b88;
  undefined4 uStack_b84;
  undefined2 uStack_b80;
  undefined4 uStack_b7c;
  undefined2 uStack_b78;
  undefined4 uStack_b74;
  undefined2 uStack_b70;
  uint uStack_b6c;
  undefined2 uStack_b68;
  int iStack_b64;
  undefined2 uStack_b60;
  undefined8 uStack_b58;
  undefined2 uStack_b50;
  undefined8 uStack_b48;
  undefined2 uStack_b40;
  undefined8 uStack_b38;
  undefined2 uStack_b30;
  undefined auStack_b28 [4];
  undefined4 uStack_b24;
  ulonglong *puStack_b20;
  undefined uStack_b18;
  undefined4 uStack_b14;
  undefined8 uStack_b08;
  undefined2 uStack_b00;
  longlong lStack_af8;
  ushort uStack_af0;
  undefined8 uStack_ae8;
  undefined2 uStack_ae0;
  int *piStack_ad8;
  ushort uStack_ad0;
  undefined8 uStack_ac8;
  undefined2 uStack_ac0;
  int *piStack_ab8;
  ushort uStack_ab0;
  undefined auStack_aa8 [4];
  undefined auStack_aa4 [4];
  undefined auStack_aa0 [4];
  undefined auStack_a9c [4];
  undefined auStack_a98 [8];
  undefined auStack_a90 [4];
  undefined auStack_a8c [4];
  undefined auStack_a88 [4];
  undefined auStack_a84 [4];
  undefined auStack_a80 [8];
  uint uStack_a78;
  undefined8 uStack_a74;
  uint uStack_a60;
  undefined8 uStack_a5c;
  uint uStack_a48;
  undefined8 uStack_a44;
  longlong lStack_a30;
  undefined8 uStack_a28;
  undefined2 *puStack_a20;
  undefined8 uStack_a18;
  undefined auStack_9f8 [8];
  undefined4 uStack_9f0;
  undefined4 uStack_9e8;
  uint **ppuStack_9e0;
  undefined *puStack_9d8;
  undefined8 uStack_9d0;
  uint *puStack_9c8;
  undefined4 uStack_9c0;
  undefined4 uStack_9bc;
  longlong lStack_9b8;
  undefined4 uStack_9b0;
  undefined4 uStack_9ac;
  longlong lStack_9a8;
  undefined4 uStack_9a0;
  undefined4 uStack_99c;
  short *psStack_998;
  int iStack_990;
  undefined4 uStack_98c;
  short *psStack_988;
  int iStack_980;
  undefined4 uStack_97c;
  undefined8 uStack_978;
  undefined4 uStack_970;
  undefined4 uStack_96c;
  undefined auStack_968 [448];
  undefined8 uStack_7a8;
  undefined8 uStack_7a0;
  uint uStack_798;
  short sStack_794;
  int iStack_792;
  undefined uStack_78e;
  undefined uStack_78d;
  undefined auStack_758 [8];
  undefined4 uStack_750;
  undefined4 uStack_748;
  uint **ppuStack_740;
  undefined *puStack_738;
  undefined8 uStack_730;
  uint *puStack_728;
  undefined4 uStack_720;
  undefined4 uStack_71c;
  longlong lStack_718;
  undefined4 uStack_710;
  undefined4 uStack_70c;
  longlong lStack_708;
  undefined4 uStack_700;
  undefined4 uStack_6fc;
  short *psStack_6f8;
  int iStack_6f0;
  undefined4 uStack_6ec;
  short *psStack_6e8;
  int iStack_6e0;
  undefined4 uStack_6dc;
  undefined8 uStack_6d8;
  undefined4 uStack_6d0;
  undefined4 uStack_6cc;
  undefined auStack_6c8 [448];
  undefined8 uStack_508;
  undefined8 uStack_500;
  uint uStack_4f8;
  undefined2 uStack_4f4;
  int iStack_4f2;
  undefined uStack_4ee;
  undefined uStack_4ed;
  undefined auStack_4b8 [8];
  undefined4 uStack_4b0;
  undefined4 uStack_4a8;
  uint **ppuStack_4a0;
  undefined *puStack_498;
  undefined8 uStack_490;
  uint *puStack_488;
  undefined4 uStack_480;
  undefined4 uStack_47c;
  longlong lStack_478;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  longlong lStack_468;
  undefined4 uStack_460;
  undefined4 uStack_45c;
  short *psStack_458;
  int iStack_450;
  undefined4 uStack_44c;
  short *psStack_448;
  int iStack_440;
  undefined4 uStack_43c;
  undefined8 uStack_438;
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined auStack_428 [448];
  undefined8 uStack_268;
  undefined8 uStack_260;
  uint uStack_258;
  undefined2 uStack_254;
  int iStack_252;
  undefined uStack_24e;
  undefined uStack_24d;
  short sStack_218;
  ushort uStack_216;
  uint uStack_214;
  int *piStack_210;
  undefined8 uStack_208;
  undefined4 uStack_200;
  ushort uStack_1fc;
  undefined2 uStack_1fa;
  undefined6 uStack_1f8;
  undefined2 uStack_1f2;
  undefined2 uStack_1f0;
  undefined2 uStack_1ee;
  ushort uStack_1ec;
  undefined2 uStack_1ea;
  undefined4 uStack_1e8;
  int iStack_1e4;
  undefined auStack_1e0 [16];
  undefined auStack_1d0 [8];
  undefined8 uStack_1c8;
  undefined8 uStack_1c0;
  undefined6 uStack_1b8;
  undefined2 uStack_1b2;
  undefined6 uStack_1b0;
  undefined2 uStack_1aa;
  undefined8 uStack_1a8;
  undefined auStack_1a0 [16];
  undefined auStack_190 [16];
  undefined auStack_180 [16];
  undefined8 uStack_170;
  uint auStack_168 [2];
  short asStack_160 [24];
  short asStack_130 [24];
  short asStack_100 [24];
  short asStack_d0 [24];
  short asStack_a0 [24];
  short asStack_70 [24];
  ulonglong uStack_40;
  
  uStack_a28 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_d88;
  lVar15 = 0;
  puStack_d18 = (ulonglong *)0x0;
  uStack_d10 = 0;
  uStack_d0c = 0;
  puStack_b20 = (ulonglong *)0x0;
  uStack_b18 = 0;
  uStack_b14 = 0;
  uStack_bd0 = 0;
  sStack_218 = -1;
  piStack_210 = (int *)0x0;
  uStack_214 = 0;
  uStack_1fa = 0;
  uStack_1f8 = 0;
  uStack_1f0 = 0;
  uStack_1ee = 0;
  uStack_1ec = 0;
  uStack_1ea = 0;
  uStack_208 = (byte **)0x0;
  iStack_1e4 = -1;
  lVar19 = param_1[5];
  lVar18 = param_1[8];
  uStack_a74 = 0;
  uStack_ce0 = param_2;
  plStack_c60 = param_1;
  piStack_c28 = param_3;
  if ((((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) &&
      ((lVar4 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar4 == 0 ||
       ((lVar4 = **(longlong **)(lVar4 + 0x38), lVar4 == 0 ||
        (iVar11 = (*_DAT_)(lVar4,0x337), iVar11 == 0)))))) &&
     (lVar4 = *(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8), lVar4 != 0)) {
    lVar15 = *(longlong *)(lVar4 + 0x60);
  }
  lVar4 = *(longlong *)(lVar18 + 0x728);
  uStack_c70 = 2;
  do {
    puVar17 = puStack_d18;
    uStack_c80 = 0;
    if (puStack_d18 != (ulonglong *)0x0) {
      iVar11 = (int)(short)uStack_d0c;
      if (((*(ushort *)((longlong)puStack_d18 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)puStack_d18 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)puStack_d18 + 100) & 8) != 0) &&
              (uVar14 = puStack_d18[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d18,iVar11);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar17 + 100) & 8) != 0)) &&
            ((2 < iVar11 &&
             (((*(uint *)((longlong)puVar17 + 100) & 0xc0000000) != 0x40000000 && (*puVar17 != 0))))
            )) && (iVar13 = (*_DAT_)(*puVar17,0x2000,2,auStack_aa8), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(puVar17 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(puVar17,0,iVar11);
        }
        uStack_d0c = uStack_d0c & 0xffff0000;
        puStack_d18 = (ulonglong *)0x0;
      }
      else {
        func_0x(&puStack_d18);
      }
    }
    if ((*(longlong *)(lVar18 + 0x728) != 0) &&
       (func_0x(&puStack_d18,param_2,lVar18), puVar17 = puStack_d18,
       puStack_d18 != (ulonglong *)0x0)) {
      iVar11 = (int)(short)uStack_d0c;
      if (((*(ushort *)((longlong)puStack_d18 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)puStack_d18 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)puStack_d18 + 100) & 8) != 0) &&
              (uVar14 = puStack_d18[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d18,iVar11);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar17 + 100) & 8) != 0)) &&
            ((2 < iVar11 &&
             (((*(uint *)((longlong)puVar17 + 100) & 0xc0000000) != 0x40000000 && (*puVar17 != 0))))
            )) && (iVar13 = (*_DAT_)(*puVar17,0x2000,2,auStack_a8c), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(puVar17 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(puVar17,0,iVar11);
        }
        uStack_d0c = uStack_d0c & 0xffff0000;
        puStack_d18 = (ulonglong *)0x0;
      }
      else {
        func_0x(&puStack_d18);
      }
    }
    func_0x(lVar18,param_2);
    uStack_d60 = (undefined2 **)&uStack_a78;
    uStack_d68 = (ulonglong **)CONCAT44(uStack_d68._4_4_,4);
    puStack_d18 = (ulonglong *)func_0x(_DAT_,lVar18,param_2);
    if (lVar15 != 0) {
      uVar14 = (ulonglong)(*(uint *)(lVar15 + 0x500) & 0xf);
      if (*(ulonglong *)(lVar15 + 0x508 + uVar14 * 8) != *puStack_d18) {
        *(ulonglong *)(lVar15 + 0x508 + uVar14 * 8) = *puStack_d18;
        *(longlong *)(lVar15 + 0x500) = *(longlong *)(lVar15 + 0x500) + 1;
      }
    }
    uStack_d0c = (uStack_c80 >> 3 & 1) << 0x18 | uStack_d0c & 0xff0004 | 4;
    uStack_d08 = uStack_c80 >> 4 & 1 | uStack_d08 & 0xffffff00;
    if (((lVar4 != 0) && (lVar15 != 0)) && (lVar15 == *(longlong *)(lVar18 + 0x1c38))) {
      *(longlong *)(lVar4 + 0x5b28) = *(longlong *)(lVar4 + 0x5b28) + 1;
      if ((int)uStack_a74 != 0) {
        *(longlong *)(lVar4 + 0x5b30) = *(longlong *)(lVar4 + 0x5b30) + 1;
        *(longlong *)(lVar4 + 0x5b38) = *(longlong *)(lVar4 + 0x5b38) + (ulonglong)uStack_a78;
        if (0xffffff < uStack_d0c) {
          *(longlong *)(lVar4 + 0x5b40) = *(longlong *)(lVar4 + 0x5b40) + 1;
          *(longlong *)(lVar4 + 0x5b48) = *(longlong *)(lVar4 + 0x5b48) + (ulonglong)uStack_a78;
        }
      }
    }
    cVar8 = func_0x(lVar18);
    if (((cVar8 == '\0') || (*(char *)(lVar18 + 0x2050) == '\0')) ||
       ((*param_2 == 0 || ((*param_2 == 9 && (*(short *)(param_2 + 1) == 1)))))) goto LAB_;
    uVar14 = *puStack_d18;
    if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
      uStack_c20 = *(undefined8 *)(uVar14 + 0x28);
      uStack_c18 = *(ushort *)(uVar14 + 0x30);
    }
    else {
      cVar8 = *(char *)(uVar14 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
      }
      uStack_bcc = *(undefined4 *)(uVar14 + 0x20);
      uStack_bc8 = *(undefined2 *)(uVar14 + 0x24);
      cVar8 = func_0x(&uStack_bcc);
      if (cVar8 == '\0') goto LAB_;
      func_0x(uVar14,&uStack_c20);
    }
    uVar23 = *(uint *)(lVar18 + 0x2108);
    do {
      uVar12 = uVar23 & 0xfffffffe;
      uStack_cc8 = *(longlong *)(lVar18 + 0x20fc);
      uStack_cc0 = *(undefined4 *)(lVar18 + 0x2104);
      LOCK();
      UNLOCK();
      uVar23 = *(uint *)(lVar18 + 0x2108);
    } while (uVar12 != uVar23);
    if ((uint)uStack_c20 <= (uint)uStack_cc8) {
      if ((uint)uStack_cc8 != (uint)uStack_c20) goto LAB_;
      uVar23 = (uint)((ulonglong)uStack_cc8 >> 0x20);
      if ((uStack_c20._4_4_ <= uVar23) &&
         ((uVar23 != uStack_c20._4_4_ ||
          (uStack_cc0._0_2_ = (ushort)*(undefined4 *)(lVar18 + 0x2104),
          bVar36 = uStack_c18 <= (ushort)uStack_cc0, bVar36)))) goto LAB_;
    }
    if ((*(char *)(lVar18 + 0x6ac8) == '\0') &&
       ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) != *(longlong *)(lVar18 + 0x2120) &&
        (cVar8 = func_0x(lVar18), cVar8 == '\0')))) break;
    if ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) == *(longlong *)(lVar18 + 0x2120)) ||
       (cVar8 = func_0x(lVar18), cVar8 != '\0')) goto LAB_;
    if (lVar15 == 0) {
      lVar15 = func_0x();
    }
    uVar14 = *puStack_d18;
    if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
      uStack_b58 = *(undefined8 *)(uVar14 + 0x28);
      uStack_b50 = *(undefined2 *)(uVar14 + 0x30);
    }
    else {
      cVar8 = *(char *)(uVar14 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
      }
      uStack_bc4 = *(undefined4 *)(uVar14 + 0x20);
      uStack_bc0 = *(undefined2 *)(uVar14 + 0x24);
      cVar8 = func_0x(&uStack_bc4);
      if (cVar8 == '\0') goto LAB_;
      func_0x(uVar14,&uStack_b58);
    }
    puVar17 = puStack_d18;
    if (puStack_d18 != (ulonglong *)0x0) {
      iVar11 = (int)(short)uStack_d0c;
      if (((*(ushort *)((longlong)puStack_d18 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)puStack_d18 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)puStack_d18 + 100) & 8) != 0) &&
              (uVar14 = puStack_d18[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d18,iVar11);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar17 + 100) & 8) != 0)) &&
            ((2 < iVar11 &&
             (((*(uint *)((longlong)puVar17 + 100) & 0xc0000000) != 0x40000000 && (*puVar17 != 0))))
            )) && (iVar13 = (*_DAT_)(*puVar17,0x2000,2,auStack_a90), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(puVar17 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(puVar17,0,iVar11);
        }
        uStack_d0c = uStack_d0c & 0xffff0000;
        puStack_d18 = (ulonglong *)0x0;
      }
      else {
        func_0x(&puStack_d18);
      }
    }
    uStack_b08 = uStack_b58;
    uStack_b00 = uStack_b50;
    uStack_d68 = (ulonglong **)0x0;
    func_0x(*(undefined8 *)(lVar18 + 0x728),&uStack_b08,4);
  } while( true );
  uVar23 = *(uint *)(lVar18 + 0x2108);
  do {
    uVar12 = uVar23 & 0xfffffffe;
    uStack_cc8 = *(longlong *)(lVar18 + 0x20fc);
    uStack_cc0 = *(undefined4 *)(lVar18 + 0x2104);
    uVar21 = uStack_cc0;
    LOCK();
    UNLOCK();
    uVar23 = *(uint *)(lVar18 + 0x2108);
  } while (uVar12 != uVar23);
  uStack_cc0._0_2_ = (ushort)*(undefined4 *)(lVar18 + 0x2104);
  uVar10 = (ushort)uStack_cc0;
  uStack_af0 = (ushort)uStack_cc0;
  uVar14 = *puStack_d18;
  uStack_cc0 = uVar21;
  lStack_af8 = uStack_cc8;
  if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
    uStack_c38 = *(undefined8 *)(uVar14 + 0x28);
    uStack_c30 = *(ushort *)(uVar14 + 0x30);
  }
  else {
    cVar8 = *(char *)(uVar14 + 1);
    if (cVar8 == '\v') {
      if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
        if (cVar8 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar8 != '\b') goto LAB_;
LAB_:
      if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
    }
    uStack_bbc = *(undefined4 *)(uVar14 + 0x20);
    uStack_bb8 = *(undefined2 *)(uVar14 + 0x24);
    cVar8 = func_0x(&uStack_bbc);
    if (cVar8 == '\0') goto LAB_;
    func_0x(uVar14,&uStack_c38);
  }
  if ((uint)uStack_cc8 < (uint)uStack_c38) {
LAB_:
    lVar15 = *(longlong *)(lVar18 + 0x6b0);
    func_0x(&uStack_c38,asStack_70,auStack_b28);
    func_0x(&lStack_af8,asStack_160,auStack_b28);
    if ((_DAT_ & 0x10000) != 0) {
      uStack_750 = 0x60000;
      iVar11 = 0;
      uStack_748 = 0;
      ppuStack_740 = &puStack_728;
      puStack_738 = auStack_6c8;
      uStack_508 = 0;
      uStack_730 = 0;
      uStack_500 = 0;
      puStack_728 = &uStack_4f8;
      uStack_720 = 0x34;
      uStack_71c = 5;
      uStack_710 = 0x10;
      uStack_70c = 5;
      uStack_700 = 0x10;
      uStack_6fc = 6;
      uStack_6ec = 7;
      uStack_6dc = 8;
      uStack_6d8 = 0;
      uStack_6d0 = 0;
      uStack_6cc = 9;
      uStack_4f8 = (uint)*(ushort *)(lVar18 + 0x6b8);
      uStack_4f4 = *(undefined2 *)(param_2 + 1);
      iStack_4f2 = *param_2;
      uStack_4ee = 0xff;
      uStack_4ed = *(undefined *)(*puStack_d18 + 1);
      lStack_718 = lVar15 + 0x254;
      lStack_708 = lVar15 + 0x244;
      lVar18 = -1;
      do {
        lVar18 = lVar18 + 1;
      } while (asStack_70[lVar18] != 0);
      iStack_6f0 = (int)lVar18 * 2;
      psStack_6f8 = asStack_70;
      lVar18 = -1;
      do {
        lVar18 = lVar18 + 1;
      } while (asStack_160[lVar18] != 0);
      iStack_6e0 = (int)lVar18 * 2;
      psStack_6e8 = asStack_160;
      uStack_b24 = 0;
      puVar20 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar15,&uStack_b24);
      ppuVar7 = ppuStack_740;
      if (puVar20 != (uint *)0x0) {
        lVar18 = -1;
        do {
          lVar18 = lVar18 + 1;
        } while (*(short *)((longlong)puVar20 + lVar18 * 2) != 0);
        iVar11 = (int)lVar18 * 2;
      }
      ppuStack_740[10] = puVar20;
      *(int *)(ppuVar7 + 0xb) = iVar11;
      *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
      func_0x(auStack_758);
    }
  }
  else if ((uint)uStack_cc8 == (uint)uStack_c38) {
    uVar23 = (uint)((ulonglong)uStack_c38 >> 0x20);
    if ((uStack_cc8._4_4_ < uVar23) || ((uStack_cc8._4_4_ == uVar23 && (uVar10 < uStack_c30))))
    goto LAB_;
  }
LAB_:
  uVar14 = *puStack_d18;
  if ((*(int *)(uVar14 + 0x20) != *piStack_c28) ||
     (plVar34 = plStack_c60, *(short *)(uVar14 + 0x24) != *(short *)(piStack_c28 + 1))) {
    if (*(int *)(plStack_c60 + 0x1ea) == 0) {
      iVar11 = *(ushort *)(uVar14 + 0x16) - 1;
    }
    else {
      iVar11 = 0;
    }
    ppbVar28 = (byte **)0x0;
    iStack_1e4 = iVar11;
    if (*(char *)(uVar14 + 2) < '\0') {
      pbVar1 = (byte *)(uVar14 + 0x60);
      if ((sStack_218 == 0) || (ppbVar28 = uStack_208, uStack_208 == (byte **)0x0)) {
        uStack_1b8 = 0;
        uStack_1aa = 0;
        auStack_190 = ZEXT816(0);
        auStack_1e0 = ZEXT816(0);
        stack0xfffffffffffffe32 = SUB1614(ZEXT816(0),2);
        auStack_1d0._0_2_ = 0xffff;
        uStack_1c8 = 0;
        uStack_1b2 = 0;
        uStack_1b0 = 0;
        uStack_1a8 = 0;
        uStack_1c0 = 0;
        auStack_1a0 = ZEXT816(0);
        auStack_180._0_12_ = ZEXT812(0);
        auStack_180._12_4_ = 0;
        uStack_170 = 0;
        ppbVar28 = (byte **)auStack_1e0;
      }
      if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
        uStack_bf0 = *(undefined8 *)(uVar14 + 0x28);
        uStack_be8 = *(undefined2 *)(uVar14 + 0x30);
      }
      else {
        cVar8 = *(char *)(uVar14 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_bb4 = *(undefined4 *)(uVar14 + 0x20);
        uStack_bb0 = *(undefined2 *)(uVar14 + 0x24);
        cVar8 = func_0x(&uStack_bb4);
        if (cVar8 == '\0') goto LAB_;
        func_0x(uVar14,&uStack_bf0);
      }
      *ppbVar28 = pbVar1;
      *(undefined4 *)(ppbVar28 + 0xc) = (undefined4)uStack_bf0;
      *(int *)((longlong)ppbVar28 + 100) = (int)((ulonglong)uStack_bf0 >> 0x20);
      *(undefined2 *)(ppbVar28 + 0xd) = uStack_be8;
      *(undefined4 *)((longlong)ppbVar28 + 0x6c) = *(undefined4 *)(uVar14 + 0x20);
      *(undefined2 *)(ppbVar28 + 0xe) = *(undefined2 *)(uVar14 + 0x24);
      *(undefined2 *)((longlong)ppbVar28 + 0x72) = 0;
      uStack_cc8 = CONCAT44(uStack_cc8._4_4_,*(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x10898d0));
      uVar35 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x10898d4);
      *(undefined2 *)(ppbVar28 + 2) = 0xffff;
      ppbVar28[3] = (byte *)0x0;
      uVar23 = 0;
      *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
      ppbVar28[7] = (byte *)0x0;
      ppbVar28[4] = (byte *)0x0;
      ppbVar28[9] = (byte *)0x0;
      ppbVar28[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar28 + 0xb) = 0;
      if ((**ppbVar28 & 2) != 0) {
        pbVar2 = pbVar1 + uVar35;
        if ((*pbVar2 & 1) == 0) {
          *(undefined2 *)(ppbVar28 + 2) = 0;
          ppbVar28[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar28 + 0x36) = 0;
          switch(*pbVar2 & 0xe) {
          default:
            uVar23 = (uint)*(ushort *)(pbVar2 + 2);
            if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
              func_0x(pbVar2,6);
            }
            break;
          case 4:
            uVar23 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar23 = 1;
          }
          *(uint *)(ppbVar28 + 4) = uVar23;
          *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
        }
        else {
          *(undefined2 *)(ppbVar28 + 2) = 1;
          ppbVar28[3] = pbVar2;
          bVar9 = *pbVar2;
          switch(bVar9 & 0x1c) {
          default:
            if ((char)pbVar2[1] < '\0') {
              uVar10 = *(ushort *)(pbVar2 + 1);
              *(ushort *)((longlong)ppbVar28 + 0x12) = uVar10;
              sVar32 = 3;
              uVar10 = (uVar10 & 0x7f) << 8 | uVar10 >> 8;
            }
            else {
              sVar32 = 2;
              uVar10 = (ushort)pbVar2[1];
            }
            *(ushort *)((longlong)ppbVar28 + 0x12) = uVar10;
            *(short *)(ppbVar28 + 5) = sVar32;
            uVar10 = *(ushort *)((longlong)ppbVar28 + 0x12);
            *(short *)((longlong)ppbVar28 + 0x2c) = (short)(uVar10 + 1 >> 1) + sVar32;
            if (uVar10 < 0x1f) {
              *(undefined2 *)((longlong)ppbVar28 + 0x2a) = 0;
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
              *(undefined4 *)(ppbVar28 + 8) = 0;
              ppbVar28[7] = (byte *)0x0;
              ppbVar28[4] = (byte *)0x0;
            }
            else {
              iVar13 = uVar10 - 1;
              *(short *)((longlong)ppbVar28 + 0x2a) =
                   ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                   (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
              *(undefined4 *)(ppbVar28 + 8) = 0;
              ppbVar28[7] = (byte *)0x0;
              ppbVar28[4] = (byte *)0x0;
            }
            break;
          case 4:
            if (((bVar9 & 0x1c) != 4) || (uVar12 = 1, (bVar9 & 2) == 0)) {
              uVar12 = uVar23;
            }
            if (uVar12 == 0) {
              uVar21 = 1;
            }
            else {
              *(undefined4 *)(ppbVar28 + 8) = 0;
              uVar21 = 0xf;
            }
            ppbVar28[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar28 + 0x12) = 0;
            ppbVar28[6] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar28 + 0x14) = uVar21;
            *(uint *)(ppbVar28 + 8) = (uint)(uVar12 != 0);
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
            break;
          case 8:
            ppbVar28[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar28 + 0x12) = 0;
            ppbVar28[6] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 9;
            *(undefined4 *)(ppbVar28 + 8) = 0;
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
          }
        }
      }
      if ((**ppbVar28 & 4) != 0) {
        if (uStack_cc8._2_2_ != 0) {
          uVar35 = (ulonglong)*(ushort *)(uVar14 + 0x61 + (longlong)uStack_cc8._2_2_ * 2);
        }
        psVar16 = (short *)(pbVar1 + uVar35);
        ppbVar28[9] = (byte *)psVar16;
        sVar32 = *psVar16;
        ppbVar28[10] = (byte *)(psVar16 + 1);
        *(short *)(ppbVar28 + 0xb) = (sVar32 + 1) * 2;
      }
      if (ppbVar28[1] != (byte *)0x0) {
        func_0x(ppbVar28[1],ppbVar28);
      }
    }
    piVar6 = piStack_c28;
    piStack_210 = (int *)(*(ushort *)(uVar14 + (0xfff - (longlong)iVar11) * 2) + uVar14);
    if ((*(byte *)piStack_210 & 1) == 0) {
      sStack_218 = 0;
      uStack_214 = 0;
      uStack_1f2 = 0;
      uStack_1f0 = 0;
      ppbVar28 = (byte **)(ulonglong)*(ushort *)(uVar14 + 0xe);
      switch(*(byte *)piStack_210 & 0xe) {
      default:
        ppbVar28 = (byte **)(ulonglong)*(ushort *)((longlong)piStack_210 + 2);
        if (0x1f9d < *(ushort *)((longlong)piStack_210 + 2) - 1) {
          func_0x(piStack_210,6);
        }
        break;
      case 4:
        ppbVar28 = (byte **)0x9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        ppbVar28 = (byte **)0x1;
      }
      uStack_208 = (byte **)CONCAT44(uStack_208._4_4_,(int)ppbVar28);
      uStack_1fa = (undefined2)(uVar14 + 0x2000);
      uStack_1f8 = (undefined6)(uVar14 + 0x2000 >> 0x10);
    }
    else {
      sStack_218 = 1;
      bVar9 = *(byte *)piStack_210;
      switch(bVar9 & 0x1c) {
      default:
        if ((char)*(byte *)((longlong)piStack_210 + 1) < '\0') {
          uStack_216 = (*(ushort *)((longlong)piStack_210 + 1) & 0x7f) << 8 |
                       *(ushort *)((longlong)piStack_210 + 1) >> 8;
          uStack_200._0_2_ = 3;
          sVar32 = 3;
        }
        else {
          uStack_216 = (ushort)*(byte *)((longlong)piStack_210 + 1);
          uStack_200._0_2_ = 2;
          sVar32 = 2;
        }
        uStack_1fc = (short)(uStack_216 + 1 >> 1) + sVar32;
        if (uStack_216 < 0x1f) {
          uStack_200._2_2_ = 0;
          uStack_214 = 0;
          uStack_1e8 = 0;
        }
        else {
          iVar11 = uStack_216 - 1;
          uStack_200._2_2_ =
               ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
               (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
          uStack_214 = 0;
          uStack_1e8 = 0;
        }
        break;
      case 4:
        if (((bVar9 & 0x1c) == 4) && ((bVar9 & 2) != 0)) {
          uStack_200._0_2_ = 0;
          uStack_200._2_2_ = 0;
          uStack_1fc = 0;
          uStack_1fa = 0;
          uStack_216 = 0;
          uStack_1f8 = 0;
          uStack_1f2 = 0;
          uStack_214 = 0xf;
          uStack_1e8 = 1;
        }
        else {
          uStack_200._0_2_ = 0;
          uStack_200._2_2_ = 0;
          uStack_1fc = 0;
          uStack_1fa = 0;
          uStack_216 = 0;
          uStack_1f8 = 0;
          uStack_1f2 = 0;
          uStack_214 = 1;
          uStack_1e8 = 0;
        }
        break;
      case 8:
        uStack_200._0_2_ = 0;
        uStack_200._2_2_ = 0;
        uStack_1fc = 0;
        uStack_1fa = 0;
        uStack_216 = 0;
        uStack_1f8 = 0;
        uStack_1f2 = 0;
        uStack_214 = 9;
        uStack_1e8 = 0;
      }
      lVar18 = uVar14 + 0x2000;
      uStack_1f0 = (undefined2)lVar18;
      uStack_1ee = (undefined2)((ulonglong)lVar18 >> 0x10);
      uStack_1ec = (ushort)((ulonglong)lVar18 >> 0x20);
      uStack_1ea = (undefined2)((ulonglong)lVar18 >> 0x30);
      uStack_208 = ppbVar28;
    }
    puVar20 = (uint *)(lVar19 + 0x210);
    if (sStack_218 == 0) {
      uVar23 = *puVar20;
      if ((uVar23 & 0xc0000000) == 0x80000000) {
        iVar11 = func_0x(&uStack_216);
        if (iVar11 == 0) {
code_r0x00101caa:
          piVar25 = (int *)0x0;
          aiStack_d00[0] = 0;
        }
        else {
          piVar25 = (int *)func_0x(&uStack_1ee,puVar20,aiStack_d00);
        }
        goto code_r0x00101caf;
      }
      uVar10 = *(ushort *)(lVar19 + 0x216);
      if ((uVar10 & 0x10) == 0) {
code_r0x001013c3:
        if ((int)uVar23 < 0) {
          if (uStack_214 == 0) {
            uStack_216 = 0;
            uVar35 = (ulonglong)uStack_208 & 0xffffffff;
            uVar23 = (uint)uStack_208;
            if ((*(byte *)piStack_210 & 0x10) != 0) {
              uVar23 = (uint)uStack_208 + 2 + (*(ushort *)(uVar35 + (longlong)piStack_210) + 7 >> 3)
              ;
              uVar35 = (ulonglong)uVar23;
            }
            uStack_208 = (byte **)CONCAT44(uVar23,(uint)uStack_208);
            if ((*(byte *)piStack_210 & 0x20) == 0) {
              uStack_1fc = 0;
              piVar25 = piStack_210;
              uVar26 = uVar35;
              uStack_214 = (uint)uVar35;
              uStack_200 = (uint)uVar35;
            }
            else {
              puVar29 = (ushort *)(uVar35 + (longlong)piStack_210);
              uStack_1fc = *puVar29;
              if (uStack_1fc == 0) {
                if ((((cRam000000000199c3bb != '\0') || ((bRam00000000019accc0 & 1) != 0)) &&
                    (lVar18 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar18 != 0)) &&
                   ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                    (*(char *)(lVar18 + 0x499) != '\0')))) {
                  if ((cRam000000000199c2ab == '\0') && ((bRam00000000019accc0 & 2) == 0)) {
                    (*pcRam0000000000f0abe8)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_d68 = (ulonglong **)0x0;
                    (*pcRam0000000000f0abe0)(1,0x128cde8,0x13acab8,0x80f);
                  }
                }
                func_0x(piStack_210,3);
              }
              uStack_200 = uStack_208._4_4_ + (uStack_1fc + 1) * 2;
              if (0x1f9e < uStack_200) {
                if (((cRam000000000199c3bb != '\0') || ((bRam00000000019accc0 & 1) != 0)) &&
                   ((lVar18 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar18 != 0 &&
                    ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                     (*(char *)(lVar18 + 0x499) != '\0')))))) {
                  if ((cRam000000000199c2ab == '\0') && ((bRam00000000019accc0 & 2) == 0)) {
                    (*pcRam0000000000f0abe8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_d68 = (ulonglong **)0x0;
                    (*pcRam0000000000f0abe0)(1,0x128cde8,0x13acab8,0x816);
                  }
                }
                func_0x(piStack_210,4);
              }
              uStack_214 = puVar29[uStack_1fc] & 0x7fff;
              if (uStack_214 < uStack_200) {
                if ((((cRam000000000199c3bb != '\0') || ((bRam00000000019accc0 & 1) != 0)) &&
                    (lVar18 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar18 != 0)) &&
                   ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                    (*(char *)(lVar18 + 0x499) != '\0')))) {
                  if ((cRam000000000199c2ab == '\0') && ((bRam00000000019accc0 & 2) == 0)) {
                    (*pcRam0000000000f0abe8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_d68 = (ulonglong **)0x0;
                    (*pcRam0000000000f0abe0)(1,0x128cde8,0x13acab8,0x81d);
                  }
                }
                func_0x(piStack_210,4);
              }
              uVar26 = (ulonglong)uStack_200;
              uVar35 = (ulonglong)uStack_214;
              piVar25 = piStack_210;
              while( true ) {
                if (-1 < (short)puVar29[(ulonglong)(uStack_1fc - 1) + 1]) goto code_r0x001018bc;
                uVar23 = (uint)uVar26;
                if (uStack_1fc != 1) {
                  uVar23 = *(ushort *)
                            ((longlong)piVar25 +
                            (ulonglong)uStack_1fc * 2 + (((ulonglong)uStack_208 >> 0x20) - 2)) &
                           0x7fff;
                }
                if ((uVar23 < (uint)uVar26) ||
                   ((*(ushort *)
                      ((longlong)piVar25 +
                      (ulonglong)uStack_1fc * 2 + ((ulonglong)uStack_208 >> 0x20)) & 0x7fff) <
                    uVar23)) {
                  func_0x(piVar25,7);
                  uVar26 = (ulonglong)uStack_200;
                  uVar35 = (ulonglong)uStack_214;
                  piVar25 = piStack_210;
                }
                if ((uVar23 < (uint)uVar26) || ((uint)uVar35 < uVar23)) goto code_r0x00101b14;
                if (*(ushort *)((ulonglong)uVar23 + (longlong)piVar25) == 5) break;
                if (*(ushort *)((ulonglong)uVar23 + (longlong)piVar25) < 0x400)
                goto code_r0x001018bc;
                uStack_216 = uStack_216 | 1;
                uStack_1fc = uStack_1fc - 1;
                if (uStack_1fc == 0) goto code_r0x001018bc;
              }
              uStack_216 = uStack_216 | 2;
              uStack_1fc = uStack_1fc - 1;
              uStack_1ee = (undefined2)uVar23;
              uVar10 = *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + (longlong)piVar25);
              if ((uVar10 >> 0xe & 1) == 0) {
                uStack_1ec = uStack_1ec & 0xc7ff;
              }
              else {
                uStack_1ec = uStack_1ec ^ (uVar10 ^ uStack_1ec) & 0x3800;
              }
              uStack_1ec = (uStack_1ec ^
                           *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + (longlong)piVar25)) &
                           0x7ff ^ uStack_1ec;
            }
code_r0x001018bc:
            if ((*(byte *)piVar25 & 0x40) == 0) {
              uStack_1f2 = 0;
              uStack_1f0 = 0;
            }
            else {
              uStack_1f2 = (undefined2)uVar35;
              uStack_1f0 = (undefined2)(uVar35 >> 0x10);
              uStack_214 = (int)uVar35 + 0xe;
              puVar17 = (ulonglong *)func_0x(&uStack_216);
              iVar11 = 0;
              uVar22 = (ushort)(*puVar17 >> 0x30);
              uVar10 = uVar22;
              if ((((uint)(int)(short)uVar22 >> 1 ^ (int)(short)uVar22) & 0x2000) != 0) {
                uVar10 = uVar22 & 0xdfff;
                if ((uVar22 >> 0xe & 1) != 0) {
                  uVar10 = uVar22 | 0x2000;
                }
              }
              if (uVar10 == 0xfffc) {
                iVar11 = (int)((*puVar17 >> 0x20 & 0xffff) >> 5);
              }
              uStack_214 = uStack_214 + iVar11;
              uVar35 = (ulonglong)uStack_214;
              uVar26 = (ulonglong)uStack_200;
              piVar25 = piStack_210;
            }
            uVar23 = (uint)uVar35;
            if (((byte *)CONCAT62(uStack_1f8,uStack_1fa) != (byte *)0x0) &&
               ((byte *)CONCAT62(uStack_1f8,uStack_1fa) < (byte *)(uVar35 + (longlong)piVar25))) {
              if (((cRam000000000199c3bb != '\0') || ((bRam00000000019accc0 & 1) != 0)) &&
                 (((lVar18 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), piVar25 = piStack_210,
                   lVar18 != 0 && (lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0)) &&
                  (*(char *)(lVar18 + 0x499) != '\0')))) {
                if ((cRam000000000199c2ab == '\0') && ((bRam00000000019accc0 & 2) == 0)) {
                  (*pcRam0000000000f0abe8)(0x22,0x44,0x15,0x3fa);
                  piVar25 = piStack_210;
                }
                else {
                  uStack_d68 = (ulonglong **)0x0;
                  (*pcRam0000000000f0abe0)(1,0x128cde8,0x13acab8,0x877);
                  piVar25 = piStack_210;
                }
              }
              func_0x(piVar25,0x12);
              uVar26 = (ulonglong)uStack_200;
              piVar25 = piStack_210;
              uVar23 = uStack_214;
            }
            if (0x3f3b < uVar23 - 1) {
              if (((cRam000000000199c3bb != '\0') || ((bRam00000000019accc0 & 1) != 0)) &&
                 ((lVar18 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), piVar25 = piStack_210,
                  lVar18 != 0 &&
                  ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                   (*(char *)(lVar18 + 0x499) != '\0')))))) {
                if ((cRam000000000199c2ab == '\0') && ((bRam00000000019accc0 & 2) == 0)) {
                  (*pcRam0000000000f0abe8)(0x22,0x44,0x15,0x3ed);
                  piVar25 = piStack_210;
                }
                else {
                  uStack_d68 = (ulonglong **)0x0;
                  (*pcRam0000000000f0abe0)(1,0x128cde8,0x13acab8,0x87c);
                  piVar25 = piStack_210;
                }
              }
              func_0x(piVar25,5);
              goto code_r0x00101b0d;
            }
          }
          else {
code_r0x00101b0d:
            uVar26 = (ulonglong)uStack_200;
            piVar25 = piStack_210;
          }
code_r0x00101b14:
          uVar23 = (uint)uVar26;
          sVar32 = -*(short *)puVar20;
          if ((*(byte *)(lVar19 + 0x216) & 0x10) != 0) {
            if ((*(byte *)piVar25 & 0x10) == 0) {
              if ((1 << (*(byte *)piVar25 & 0xe) & 0x1105U) != 0) {
code_r0x00101b77:
                piVar25 = *(int **)(lVar19 + 0x218) + 1;
                aiStack_d00[0] = **(int **)(lVar19 + 0x218);
                goto code_r0x00101cb2;
              }
            }
            else if (((int)(uint)uStack_208 <= (int)*puVar20) ||
                    (*(ushort *)(((ulonglong)uStack_208 & 0xffffffff) + (longlong)piVar25) <
                     *(ushort *)(lVar19 + 0x214))) goto code_r0x00101b77;
          }
          if ((uint)uStack_1fc < (uint)(int)sVar32) {
            aiStack_d00[0] = 0;
          }
          else {
            piVar31 = piVar25;
            if (sVar32 != 1) {
              uVar26 = (ulonglong)
                       (*(ushort *)
                         ((longlong)piVar25 +
                         (longlong)sVar32 * 2 + (((ulonglong)uStack_208 >> 0x20) - 2)) & 0x7fff);
              piVar31 = piStack_210;
              uVar23 = uStack_200;
            }
            uVar27 = *(ushort *)
                      ((longlong)piVar25 + (longlong)sVar32 * 2 + ((ulonglong)uStack_208 >> 0x20)) &
                     0x7fff;
            uVar12 = (uint)uVar26;
            if ((uVar12 < uVar23) || (uVar27 < uVar12)) {
              func_0x(piVar31,7);
              piVar31 = piStack_210;
            }
            piVar25 = (int *)(uVar26 + (longlong)piVar31);
            aiStack_d00[0] = uVar27 - uVar12;
          }
        }
        else if ((uVar10 & 8) == 0) {
          if ((uVar10 & 0x10) != 0) {
            if ((*(byte *)piStack_210 & 0x10) == 0) {
              if ((1 << (*(byte *)piStack_210 & 0xe) & 0x1105U) != 0) goto code_r0x0010141b;
            }
            else if (((int)(uint)uStack_208 <= (int)uVar23) ||
                    (*(ushort *)(((ulonglong)uStack_208 & 0xffffffff) + (longlong)piStack_210) <
                     *(ushort *)(lVar19 + 0x214))) {
code_r0x0010141b:
              piVar25 = *(int **)(lVar19 + 0x218) + 1;
              aiStack_d00[0] = **(int **)(lVar19 + 0x218);
              if (aiStack_d00[0] != 6) {
                uStack_d68 = (ulonglong **)0x0;
                (*pcRam0000000000f0abe0)(1,0x143ab58,0x1439558);
                uStack_200 = CONCAT22(uStack_200._2_2_,(undefined2)uStack_200);
              }
              goto code_r0x00101cb2;
            }
          }
          aiStack_d00[0] = 6;
          piVar25 = (int *)((longlong)(int)*puVar20 + (longlong)piStack_210);
          uStack_200 = CONCAT22(uStack_200._2_2_,(undefined2)uStack_200);
        }
        else {
          aiStack_d00[0] = 1;
          piVar25 = (int *)0x1011824;
          uStack_200 = CONCAT22(uStack_200._2_2_,(undefined2)uStack_200);
          if ((*(byte *)((longlong)(int)uVar23 + (longlong)piStack_210) &
              (byte)(1 << ((byte)uVar10 & 7))) == 0) {
            piVar25 = (int *)0x1011e48;
          }
        }
      }
      else if ((*(byte *)piStack_210 & 0x10) == 0) {
        if ((1 << (*(byte *)piStack_210 & 0xe) & 0x1105U) == 0) goto code_r0x001013c3;
        piVar25 = *(int **)(lVar19 + 0x218) + 1;
        aiStack_d00[0] = **(int **)(lVar19 + 0x218);
        uStack_200 = CONCAT22(uStack_200._2_2_,(undefined2)uStack_200);
      }
      else {
        if (((int)uVar23 < (int)ppbVar28) &&
           (*(ushort *)(lVar19 + 0x214) <=
            *(ushort *)(((ulonglong)ppbVar28 & 0xffffffff) + (longlong)piStack_210)))
        goto code_r0x001013c3;
        piVar25 = *(int **)(lVar19 + 0x218) + 1;
        aiStack_d00[0] = **(int **)(lVar19 + 0x218);
      }
    }
    else {
      uStack_c7c = 0;
      uStack_d68 = (ulonglong **)&uStack_c7c;
      piVar25 = (int *)func_0x(&uStack_216,puVar20);
      if ((((sStack_218 != 0) && (uStack_208 != (byte **)0x0)) && (*uStack_208 != (byte *)0x0)) &&
         (((*(byte *)(lVar19 + 0x216) & 8) == 0 && ((uStack_c7c & 1) == 0)))) {
        if ((piVar25 == (int *)0x0) || (piVar25 == (int *)0x1011824)) goto code_r0x00101caa;
        uStack_d50 = CONCAT44(uStack_d50._4_4_,uStack_c7c);
        uStack_d58 = aiStack_d00;
        uStack_d60 = (undefined2 **)CONCAT44(uStack_d60._4_4_,6);
        uStack_d68 = (ulonglong **)auStack_168;
        piVar25 = (int *)func_0x(uStack_208,puVar20,piVar25);
      }
code_r0x00101caf:
      uStack_200 = CONCAT22(uStack_200._2_2_,(undefined2)uStack_200);
    }
code_r0x00101cb2:
    plVar34 = plStack_c60;
    iStack_b64 = *piVar25;
    uStack_b60 = *(undefined2 *)(piVar25 + 1);
    iStack_bac = *piVar6;
    uStack_ba8 = *(undefined2 *)(piVar6 + 1);
    iVar11 = FUN_(plStack_c60,&iStack_b64,&iStack_bac);
    if (iVar11 == 0) goto code_r0x00103998;
  }
  puVar17 = puStack_d18;
  uStack_cc8 = plVar34[1];
  *(undefined *)(uStack_cc8 + 0x2c9) = 1;
  uVar23 = *(ushort *)(uVar14 + 0x1c) - 2;
  if (*(ushort *)(uVar14 + 0x1c) < 3) {
    uVar23 = 0;
  }
  uVar10 = (short)(1 << ((byte)*(undefined2 *)(uVar14 + 4) & 2)) - 1;
  lStack_a30 = uStack_cc8;
  if (uVar23 < (ushort)(uVar10 + *(short *)(plVar34 + 0x1b) & ~uVar10)) {
    uStack_ba4 = *(undefined4 *)(uVar14 + 0x10);
    uStack_ba0 = *(undefined2 *)(uVar14 + 0x14);
    uVar3 = *(undefined *)(uVar14 + 3);
    uVar10 = *(ushort *)(uVar14 + 0x16);
    if (puStack_d18 != (ulonglong *)0x0) {
      iVar11 = (int)(short)uStack_d0c;
      if (((*(ushort *)((longlong)puStack_d18 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)puStack_d18 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)puStack_d18 + 100) & 8) != 0) &&
              (uVar14 = puStack_d18[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d18,iVar11);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar17 + 100) & 8) != 0)) &&
           ((2 < iVar11 &&
            (((*(uint *)((longlong)puVar17 + 100) & 0xc0000000) != 0x40000000 && (*puVar17 != 0)))))
           ) {
          iVar13 = (*_DAT_)(*puVar17,0x2000,2,auStack_a9c);
          if (iVar13 != 0) {
            LOCK();
            *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        func_0x(puVar17 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(puVar17,0,iVar11);
        }
        uStack_d0c = uStack_d0c & 0xffff0000;
        puStack_d18 = (ulonglong *)0x0;
      }
      else {
        func_0x(&puStack_d18);
      }
    }
    plVar34 = plStack_c60;
    piVar6 = uStack_ce0;
    lVar18 = 0;
    uStack_d68 = &puStack_b20;
    func_0x(plStack_c60,uVar3,uStack_ce0,&uStack_ba4);
    uStack_c68 = *puStack_b20;
    lVar19 = plVar34[8];
    uStack_a5c = 0;
    if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
      lVar15 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar15 != 0) && (lVar15 = **(longlong **)(lVar15 + 0x38), lVar15 != 0)) {
        iVar11 = (*_DAT_)(lVar15,0x337);
        if (iVar11 != 0) goto LAB_;
      }
      lVar15 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
      if (lVar15 != 0) {
        lVar18 = *(longlong *)(lVar15 + 0x60);
      }
    }
LAB_:
    lVar15 = *(longlong *)(lVar19 + 0x728);
    do {
      puVar17 = puStack_d18;
      uStack_c78 = 0;
      if (puStack_d18 != (ulonglong *)0x0) {
        iVar11 = (int)(short)uStack_d0c;
        if (((*(ushort *)((longlong)puStack_d18 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
          if (((byte)*(undefined2 *)((longlong)puStack_d18 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)((longlong)puStack_d18 + 100) & 8) != 0) &&
                (uVar14 = puStack_d18[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0))
            {
              func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d18,iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar17 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)puVar17 + 100) & 0xc0000000) != 0x40000000 && (*puVar17 != 0)))
              ))) {
            iVar13 = (*_DAT_)(*puVar17,0x2000,2,auStack_aa0);
            if (iVar13 != 0) {
              LOCK();
              *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          func_0x(puVar17 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(puVar17,0,iVar11);
          }
          uStack_d0c = uStack_d0c & 0xffff0000;
          puStack_d18 = (ulonglong *)0x0;
        }
        else {
          func_0x(&puStack_d18);
        }
      }
      if (*(longlong *)(lVar19 + 0x728) != 0) {
        func_0x(&puStack_d18,piVar6,lVar19);
        puVar17 = puStack_d18;
        if (puStack_d18 != (ulonglong *)0x0) {
          iVar11 = (int)(short)uStack_d0c;
          if (((*(ushort *)((longlong)puStack_d18 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
            if (((byte)*(undefined2 *)((longlong)puStack_d18 + 0x62) >> 3 & 1) != 0) {
              if (iVar11 == 3) {
                iVar11 = 4;
              }
              else if (iVar11 < 2) goto LAB_;
              if ((((*(uint *)((longlong)puStack_d18 + 100) & 8) != 0) &&
                  (uVar14 = puStack_d18[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)
                 ) {
                func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d18,iVar11);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar17 + 100) & 8) != 0)) &&
               ((2 < iVar11 &&
                (((*(uint *)((longlong)puVar17 + 100) & 0xc0000000) != 0x40000000 && (*puVar17 != 0)
                 ))))) {
              iVar13 = (*_DAT_)(*puVar17,0x2000,2,auStack_aa4);
              if (iVar13 != 0) {
                LOCK();
                *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            func_0x(puVar17 + 0x13,iVar11);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(puVar17,0,iVar11);
            }
            uStack_d0c = uStack_d0c & 0xffff0000;
            puStack_d18 = (ulonglong *)0x0;
          }
          else {
            func_0x(&puStack_d18);
          }
        }
      }
      func_0x(lVar19,piVar6);
      uStack_d60 = (undefined2 **)&uStack_a60;
      uStack_d68 = (ulonglong **)CONCAT44(uStack_d68._4_4_,4);
      puStack_d18 = (ulonglong *)func_0x(_DAT_,lVar19,piVar6,&uStack_c78);
      if (lVar18 != 0) {
        uVar14 = (ulonglong)(*(uint *)(lVar18 + 0x500) & 0xf);
        if (*(ulonglong *)(lVar18 + 0x508 + uVar14 * 8) != *puStack_d18) {
          *(ulonglong *)(lVar18 + 0x508 + uVar14 * 8) = *puStack_d18;
          *(longlong *)(lVar18 + 0x500) = *(longlong *)(lVar18 + 0x500) + 1;
        }
      }
      uStack_d0c = (uStack_c78 >> 3 & 1) << 0x18 | uStack_d0c & 0xff0004 | 4;
      uStack_d08 = uStack_c78 >> 4 & 1 | uStack_d08 & 0xffffff00;
      if (((lVar15 != 0) && (lVar18 != 0)) && (lVar18 == *(longlong *)(lVar19 + 0x1c38))) {
        *(longlong *)(lVar15 + 0x5b28) = *(longlong *)(lVar15 + 0x5b28) + 1;
        if ((int)uStack_a5c != 0) {
          *(longlong *)(lVar15 + 0x5b30) = *(longlong *)(lVar15 + 0x5b30) + 1;
          *(longlong *)(lVar15 + 0x5b38) = *(longlong *)(lVar15 + 0x5b38) + (ulonglong)uStack_a60;
          if (0xffffff < uStack_d0c) {
            *(longlong *)(lVar15 + 0x5b40) = *(longlong *)(lVar15 + 0x5b40) + 1;
            *(longlong *)(lVar15 + 0x5b48) = *(longlong *)(lVar15 + 0x5b48) + (ulonglong)uStack_a60;
          }
        }
      }
      cVar8 = func_0x(lVar19);
      if (((cVar8 == '\0') || (*(char *)(lVar19 + 0x2050) == '\0')) ||
         ((*piVar6 == 0 || ((*piVar6 == 9 && (*(short *)(piVar6 + 1) == 1)))))) goto LAB_;
      uVar14 = *puStack_d18;
      if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
        uStack_c00 = *(undefined8 *)(uVar14 + 0x28);
        uStack_bf8 = *(ushort *)(uVar14 + 0x30);
      }
      else {
        cVar8 = *(char *)(uVar14 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_b9c = *(undefined4 *)(uVar14 + 0x20);
        uStack_b98 = *(undefined2 *)(uVar14 + 0x24);
        cVar8 = func_0x(&uStack_b9c);
        if (cVar8 == '\0') goto LAB_;
        func_0x(uVar14,&uStack_c00);
      }
      uVar23 = *(uint *)(lVar19 + 0x2108);
      do {
        uVar12 = uVar23 & 0xfffffffe;
        uStack_ce0 = *(int **)(lVar19 + 0x20fc);
        uStack_cd8 = *(undefined4 *)(lVar19 + 0x2104);
        LOCK();
        UNLOCK();
        uVar23 = *(uint *)(lVar19 + 0x2108);
      } while (uVar12 != uVar23);
      if ((uint)uStack_c00 <= (uint)uStack_ce0) {
        if ((uint)uStack_ce0 == (uint)uStack_c00) {
          uVar23 = (uint)((ulonglong)uStack_ce0 >> 0x20);
          if ((uVar23 < uStack_c00._4_4_) ||
             ((uVar23 == uStack_c00._4_4_ && ((ushort)uStack_cd8 < uStack_bf8)))) goto LAB_;
        }
        goto LAB_;
      }
LAB_:
      if ((*(char *)(lVar19 + 0x6ac8) == '\0') &&
         (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) != *(longlong *)(lVar19 + 0x2120))) {
        cVar8 = func_0x(lVar19);
        if (cVar8 == '\0') {
          uVar23 = *(uint *)(lVar19 + 0x2108);
          do {
            uVar12 = uVar23 & 0xfffffffe;
            uStack_ce0 = *(int **)(lVar19 + 0x20fc);
            uStack_cd8 = *(undefined4 *)(lVar19 + 0x2104);
            LOCK();
            UNLOCK();
            uVar23 = *(uint *)(lVar19 + 0x2108);
          } while (uVar12 != uVar23);
          uVar22 = (ushort)uStack_cd8;
          uStack_ad0 = (ushort)uStack_cd8;
          uVar14 = *puStack_d18;
          piStack_ad8 = uStack_ce0;
          if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
            uStack_c48 = *(undefined8 *)(uVar14 + 0x28);
            uStack_c40 = *(ushort *)(uVar14 + 0x30);
          }
          else {
            cVar8 = *(char *)(uVar14 + 1);
            if (cVar8 == '\v') {
              if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
                if (cVar8 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar8 != '\b') goto LAB_;
LAB_:
              if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
            }
            uStack_b8c = *(undefined4 *)(uVar14 + 0x20);
            uStack_b88 = *(undefined2 *)(uVar14 + 0x24);
            cVar8 = func_0x(&uStack_b8c);
            if (cVar8 == '\0') goto LAB_;
            func_0x(uVar14,&uStack_c48);
          }
          if ((uint)uStack_ce0 < (uint)uStack_c48) {
LAB_:
            lVar18 = *(longlong *)(lVar19 + 0x6b0);
            func_0x(&uStack_c48,asStack_130,auStack_be0);
            func_0x(&piStack_ad8,asStack_100,auStack_be0);
            if ((_DAT_ & 0x10000) != 0) {
              uStack_4b0 = 0x60000;
              uStack_4a8 = 0;
              ppuStack_4a0 = &puStack_488;
              puStack_498 = auStack_428;
              uStack_268 = 0;
              uStack_490 = 0;
              uStack_260 = 0;
              puStack_488 = &uStack_258;
              uStack_480 = 0x34;
              uStack_47c = 5;
              uStack_470 = 0x10;
              uStack_46c = 5;
              uStack_460 = 0x10;
              uStack_45c = 6;
              uStack_44c = 7;
              uStack_43c = 8;
              uStack_438 = 0;
              uStack_430 = 0;
              uStack_42c = 9;
              uStack_258 = (uint)*(ushort *)(lVar19 + 0x6b8);
              uStack_254 = *(undefined2 *)(piVar6 + 1);
              iStack_252 = *piVar6;
              uStack_24e = 0xff;
              uStack_24d = *(undefined *)(*puStack_d18 + 1);
              lStack_478 = lVar18 + 0x254;
              lStack_468 = lVar18 + 0x244;
              lVar19 = -1;
              do {
                lVar19 = lVar19 + 1;
              } while (asStack_130[lVar19] != 0);
              iStack_450 = (int)lVar19 * 2;
              psStack_458 = asStack_130;
              lVar19 = -1;
              do {
                lVar19 = lVar19 + 1;
              } while (asStack_100[lVar19] != 0);
              iStack_440 = (int)lVar19 * 2;
              psStack_448 = asStack_100;
              iVar11 = 0;
              uStack_bdc = 0;
              puVar20 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar18,&uStack_bdc);
              ppuVar7 = ppuStack_4a0;
              if (puVar20 != (uint *)0x0) {
                lVar19 = -1;
                do {
                  lVar19 = lVar19 + 1;
                } while (*(short *)((longlong)puVar20 + lVar19 * 2) != 0);
                iVar11 = (int)lVar19 * 2;
              }
              ppuStack_4a0[10] = puVar20;
              *(int *)(ppuVar7 + 0xb) = iVar11;
              *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
              func_0x(auStack_4b8);
            }
          }
          else if ((uint)uStack_ce0 == (uint)uStack_c48) {
            uVar23 = (uint)((ulonglong)uStack_c48 >> 0x20);
            if ((uStack_ce0._4_4_ < uVar23) ||
               ((uStack_ce0._4_4_ == uVar23 && (uVar22 < uStack_c40)))) goto LAB_;
          }
          goto LAB_;
        }
      }
      if (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) == *(longlong *)(lVar19 + 0x2120)) goto LAB_;
      cVar8 = func_0x(lVar19);
      if (cVar8 != '\0') goto LAB_;
      if (lVar18 == 0) {
        lVar18 = func_0x();
      }
      uVar14 = *puStack_d18;
      if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
        uStack_b48 = *(undefined8 *)(uVar14 + 0x28);
        uStack_b40 = *(undefined2 *)(uVar14 + 0x30);
      }
      else {
        cVar8 = *(char *)(uVar14 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_b94 = *(undefined4 *)(uVar14 + 0x20);
        uStack_b90 = *(undefined2 *)(uVar14 + 0x24);
        cVar8 = func_0x(&uStack_b94);
        if (cVar8 == '\0') goto LAB_;
        func_0x(uVar14,&uStack_b48);
      }
      puVar17 = puStack_d18;
      if (puStack_d18 != (ulonglong *)0x0) {
        iVar11 = (int)(short)uStack_d0c;
        if (((*(ushort *)((longlong)puStack_d18 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
          if (((byte)*(undefined2 *)((longlong)puStack_d18 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)((longlong)puStack_d18 + 100) & 8) != 0) &&
                (uVar14 = puStack_d18[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0))
            {
              func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d18,iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar17 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)puVar17 + 100) & 0xc0000000) != 0x40000000 && (*puVar17 != 0)))
              ))) {
            iVar13 = (*_DAT_)(*puVar17,0x2000,2,auStack_a98);
            if (iVar13 != 0) {
              LOCK();
              *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)puVar17 + 100) = *(uint *)((longlong)puVar17 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          func_0x(puVar17 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(puVar17,0,iVar11);
          }
          uStack_d0c = uStack_d0c & 0xffff0000;
          puStack_d18 = (ulonglong *)0x0;
        }
        else {
          func_0x(&puStack_d18);
        }
      }
      uStack_ae8 = uStack_b48;
      uStack_ae0 = uStack_b40;
      uStack_d68 = (ulonglong **)0x0;
      func_0x(*(undefined8 *)(lVar19 + 0x728),&uStack_ae8,4);
    } while( true );
  }
  ppuVar30 = &puStack_d18;
  iVar11 = *(int *)(plVar34 + 0x1ea);
  uVar14 = (ulonglong)uStack_bd0;
  uVar23 = uStack_bd0;
  goto LAB_;
LAB_:
  uVar14 = uStack_c68;
  uVar21 = 2;
  if (1 < *(int *)(plVar34 + 3) + 1U) {
    uVar21 = 0;
  }
  uStack_b6c = *(uint *)(uStack_c68 + 0x20);
  uStack_b68 = *(undefined2 *)(uStack_c68 + 0x24);
  uStack_d58 = (int *)plVar34[1];
  uStack_d60 = (undefined2 **)CONCAT44(uStack_d60._4_4_,uVar21);
  uStack_d68 = (ulonglong **)&uStack_b6c;
  func_0x(&plStack_cf8,plVar34[5] + 0x3c0,8);
  func_0x(&plStack_cf8);
  goto LAB_;
LAB_:
  plVar34 = plStack_c60;
  lVar18 = -1;
  lVar19 = 0;
  uVar23 = (uint)(uVar10 >> 1);
  if (*(char *)(plStack_c60[8] + 0x1cdf) == '\0') {
    bVar9 = 0;
  }
  else if (*(char *)(plStack_c60[8] + 0x1cdc) == '\0') {
    bVar9 = 0;
  }
  else {
    bVar9 = *(byte *)(plStack_c60[5] + 0x109) >> 6 & 1;
  }
  iVar11 = uVar10 - uVar23;
  uStack_d50 = CONCAT71(uStack_d50._1_7_,bVar9);
  uStack_d58 = (int *)plStack_c60[1];
  uStack_d60._0_4_ = *(undefined4 *)((longlong)plStack_c60 + 0x1c);
  uStack_d68._0_4_ = iVar11;
  func_0x(&puStack_b20,plStack_c60[5] + 0x3c0,&puStack_d18,uVar23);
  uStack_d28 = 0;
  uStack_d30 = 0;
  uStack_d38 = 0;
  uStack_d40 = CONCAT44(uStack_d40._4_4_,4);
  lStack_d48 = 0;
  uStack_d50 = plVar34[1];
  uStack_d58 = (int *)((ulonglong)uStack_d58 & 0xffffffff00000000);
  uStack_d60 = (undefined2 **)CONCAT44(uStack_d60._4_4_,*(undefined4 *)((longlong)plVar34 + 0x1c));
  uStack_d68 = (ulonglong **)CONCAT44(uStack_d68._4_4_,iVar11);
  func_0x
            (&puStack_d18,(ulonglong)*(uint6 *)((longlong)plVar34 + 0x34) << 0x10,plVar34[5] + 0x3c0
            );
  if ((*(int *)(uStack_c68 + 0x10) != 0) ||
     (uVar14 = uStack_c68, *(short *)(uStack_c68 + 0x14) != 0)) {
    plStack_cf8 = (longlong *)0x0;
    uStack_cf0 = 0;
    uStack_cec = 0;
    lVar15 = *(longlong *)(*plVar34 + 0x30);
    iStack_cd0 = *(int *)(uStack_c68 + 0x10);
    sStack_ccc = *(short *)(uStack_c68 + 0x14);
    uStack_a44 = 0;
    if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
      lVar4 = *(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
      ;
      if ((lVar4 != 0) && (lVar4 = **(longlong **)(lVar4 + 0x38), lVar4 != 0)) {
        iVar11 = (*_DAT_)(lVar4,0x337);
        if (iVar11 != 0) goto LAB_;
      }
      lVar4 = *(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8);
      if (lVar4 != 0) {
        lVar19 = *(longlong *)(lVar4 + 0x60);
      }
    }
LAB_:
    lVar4 = *(longlong *)(lVar15 + 0x728);
    do {
      plVar5 = plStack_cf8;
      uStack_c74 = 0;
      if (plStack_cf8 != (longlong *)0x0) {
        iVar11 = (int)(short)uStack_cec;
        if (((*(ushort *)((longlong)plStack_cf8 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
          if (((byte)*(undefined2 *)((longlong)plStack_cf8 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)((longlong)plStack_cf8 + 100) & 8) != 0) &&
                (lVar33 = plStack_cf8[0x12], lVar33 != 0)) && (*(longlong *)(lVar33 + 0x758) != 0))
            {
              func_0x(*(undefined8 *)(lVar33 + 0x758),plStack_cf8,iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0)))))
             ) {
            iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_a80);
            if (iVar13 != 0) {
              LOCK();
              *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          func_0x(plVar5 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(plVar5,0,iVar11);
          }
          uStack_cec = uStack_cec & 0xffff0000;
          plStack_cf8 = (longlong *)0x0;
        }
        else {
          func_0x(&plStack_cf8);
        }
      }
      if (*(longlong *)(lVar15 + 0x728) != 0) {
        func_0x(&plStack_cf8,&iStack_cd0,lVar15);
        plVar5 = plStack_cf8;
        if (plStack_cf8 != (longlong *)0x0) {
          iVar11 = (int)(short)uStack_cec;
          if (((*(ushort *)((longlong)plStack_cf8 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
            if (((byte)*(undefined2 *)((longlong)plStack_cf8 + 0x62) >> 3 & 1) != 0) {
              if (iVar11 == 3) {
                iVar11 = 4;
              }
              else if (iVar11 < 2) goto LAB_;
              if ((((*(uint *)((longlong)plStack_cf8 + 100) & 8) != 0) &&
                  (lVar33 = plStack_cf8[0x12], lVar33 != 0)) && (*(longlong *)(lVar33 + 0x758) != 0)
                 ) {
                func_0x(*(undefined8 *)(lVar33 + 0x758),plStack_cf8,iVar11);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
               ((2 < iVar11 &&
                (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0)))
                ))) {
              iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_a84);
              if (iVar13 != 0) {
                LOCK();
                *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
                UNLOCK();
              }
            }
            func_0x(plVar5 + 0x13,iVar11);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(plVar5,0,iVar11);
            }
            uStack_cec = uStack_cec & 0xffff0000;
            plStack_cf8 = (longlong *)0x0;
          }
          else {
            func_0x(&plStack_cf8);
          }
        }
      }
      func_0x(lVar15,&iStack_cd0);
      uStack_d60 = (undefined2 **)&uStack_a48;
      uStack_d68 = (ulonglong **)CONCAT44(uStack_d68._4_4_,4);
      plStack_cf8 = (longlong *)
                    func_0x(_DAT_,lVar15,&iStack_cd0,&uStack_c74);
      if (lVar19 != 0) {
        uVar14 = (ulonglong)(*(uint *)(lVar19 + 0x500) & 0xf);
        if (*(longlong *)(lVar19 + 0x508 + uVar14 * 8) != *plStack_cf8) {
          *(longlong *)(lVar19 + 0x508 + uVar14 * 8) = *plStack_cf8;
          *(longlong *)(lVar19 + 0x500) = *(longlong *)(lVar19 + 0x500) + 1;
        }
      }
      uStack_cec = (uStack_c74 >> 3 & 1) << 0x18 | uStack_cec & 0xff0004 | 4;
      uStack_ce8 = uStack_c74 >> 4 & 1 | uStack_ce8 & 0xffffff00;
      if (((lVar4 != 0) && (lVar19 != 0)) && (lVar19 == *(longlong *)(lVar15 + 0x1c38))) {
        *(longlong *)(lVar4 + 0x5b28) = *(longlong *)(lVar4 + 0x5b28) + 1;
        if ((int)uStack_a44 != 0) {
          *(longlong *)(lVar4 + 0x5b30) = *(longlong *)(lVar4 + 0x5b30) + 1;
          *(longlong *)(lVar4 + 0x5b38) = *(longlong *)(lVar4 + 0x5b38) + (ulonglong)uStack_a48;
          if (0xffffff < uStack_cec) {
            *(longlong *)(lVar4 + 0x5b40) = *(longlong *)(lVar4 + 0x5b40) + 1;
            *(longlong *)(lVar4 + 0x5b48) = *(longlong *)(lVar4 + 0x5b48) + (ulonglong)uStack_a48;
          }
        }
      }
      cVar8 = func_0x(lVar15);
      iVar11 = 0;
      if (((cVar8 == '\0') || (*(char *)(lVar15 + 0x2050) == '\0')) ||
         ((iStack_cd0 == 0 || ((iStack_cd0 == 9 && (sStack_ccc == 1)))))) goto LAB_;
      lVar33 = *plStack_cf8;
      if (*(short *)(lVar33 + 0x24) == 0) {
LAB_:
        uStack_c10 = *(undefined8 *)(lVar33 + 0x28);
        uStack_c08 = *(ushort *)(lVar33 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar33 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(lVar33 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar33 + 0x18) != 99) goto LAB_;
        }
        uStack_b84 = *(undefined4 *)(lVar33 + 0x20);
        uStack_b80 = *(undefined2 *)(lVar33 + 0x24);
        cVar8 = func_0x(&uStack_b84);
        if (cVar8 == '\0') goto LAB_;
        func_0x(lVar33,&uStack_c10);
      }
      uVar23 = *(uint *)(lVar15 + 0x2108);
      do {
        uVar12 = uVar23 & 0xfffffffe;
        uStack_ce0 = *(int **)(lVar15 + 0x20fc);
        uStack_cd8 = *(undefined4 *)(lVar15 + 0x2104);
        LOCK();
        UNLOCK();
        uVar23 = *(uint *)(lVar15 + 0x2108);
      } while (uVar12 != uVar23);
      if ((uint)uStack_c10 <= (uint)uStack_ce0) {
        if ((uint)uStack_ce0 == (uint)uStack_c10) {
          uVar23 = (uint)((ulonglong)uStack_ce0 >> 0x20);
          if ((uVar23 < uStack_c10._4_4_) ||
             ((uVar23 == uStack_c10._4_4_ && ((ushort)uStack_cd8 < uStack_c08)))) goto LAB_;
        }
        goto LAB_;
      }
LAB_:
      if ((*(char *)(lVar15 + 0x6ac8) == '\0') &&
         (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) != *(longlong *)(lVar15 + 0x2120))) {
        cVar8 = func_0x(lVar15);
        if (cVar8 == '\0') {
          uVar23 = *(uint *)(lVar15 + 0x2108);
          do {
            uVar12 = uVar23 & 0xfffffffe;
            uStack_ce0 = *(int **)(lVar15 + 0x20fc);
            uStack_cd8 = *(undefined4 *)(lVar15 + 0x2104);
            LOCK();
            UNLOCK();
            uVar23 = *(uint *)(lVar15 + 0x2108);
          } while (uVar12 != uVar23);
          uVar10 = (ushort)uStack_cd8;
          uStack_ab0 = (ushort)uStack_cd8;
          lVar19 = *plStack_cf8;
          piStack_ab8 = uStack_ce0;
          if (*(short *)(lVar19 + 0x24) == 0) {
LAB_:
            uStack_c58 = *(undefined8 *)(lVar19 + 0x28);
            uStack_c50 = *(ushort *)(lVar19 + 0x30);
          }
          else {
            cVar8 = *(char *)(lVar19 + 1);
            if (cVar8 == '\v') {
              if (*(int *)(lVar19 + 0x18) != 99) {
LAB_:
                if (cVar8 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar8 != '\b') goto LAB_;
LAB_:
              if (*(int *)(lVar19 + 0x18) != 99) goto LAB_;
            }
            uStack_b74 = *(undefined4 *)(lVar19 + 0x20);
            uStack_b70 = *(undefined2 *)(lVar19 + 0x24);
            cVar8 = func_0x(&uStack_b74);
            if (cVar8 == '\0') goto LAB_;
            func_0x(lVar19,&uStack_c58);
          }
          if ((uint)uStack_ce0 < (uint)uStack_c58) {
LAB_:
            lVar19 = *(longlong *)(lVar15 + 0x6b0);
            func_0x(&uStack_c58,asStack_d0,auStack_bd8);
            func_0x(&piStack_ab8,asStack_a0,auStack_bd8);
            if ((_DAT_ & 0x10000) != 0) {
              uStack_9f0 = 0x60000;
              uStack_9e8 = 0;
              ppuStack_9e0 = &puStack_9c8;
              puStack_9d8 = auStack_968;
              uStack_7a8 = 0;
              uStack_9d0 = 0;
              uStack_7a0 = 0;
              puStack_9c8 = &uStack_798;
              uStack_9c0 = 0x34;
              uStack_9bc = 5;
              uStack_9b0 = 0x10;
              uStack_9ac = 5;
              uStack_9a0 = 0x10;
              uStack_99c = 6;
              uStack_98c = 7;
              uStack_97c = 8;
              uStack_978 = 0;
              uStack_970 = 0;
              uStack_96c = 9;
              uStack_798 = (uint)*(ushort *)(lVar15 + 0x6b8);
              sStack_794 = sStack_ccc;
              iStack_792 = iStack_cd0;
              uStack_78e = 0xff;
              uStack_78d = *(undefined *)(*plStack_cf8 + 1);
              lStack_9b8 = lVar19 + 0x254;
              lStack_9a8 = lVar19 + 0x244;
              lVar15 = lVar18;
              do {
                lVar15 = lVar15 + 1;
              } while (asStack_d0[lVar15] != 0);
              iStack_990 = (int)lVar15 * 2;
              psStack_998 = asStack_d0;
              lVar15 = lVar18;
              do {
                lVar15 = lVar15 + 1;
              } while (asStack_a0[lVar15] != 0);
              iStack_980 = (int)lVar15 * 2;
              psStack_988 = asStack_a0;
              uStack_bd4 = 0;
              puVar20 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar19,&uStack_bd4);
              ppuVar7 = ppuStack_9e0;
              if (puVar20 != (uint *)0x0) {
                do {
                  lVar18 = lVar18 + 1;
                } while (*(short *)((longlong)puVar20 + lVar18 * 2) != 0);
                iVar11 = (int)lVar18 * 2;
              }
              ppuStack_9e0[10] = puVar20;
              *(int *)(ppuVar7 + 0xb) = iVar11;
              *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
              func_0x(auStack_9f8);
            }
          }
          else if ((uint)uStack_ce0 == (uint)uStack_c58) {
            uVar23 = (uint)((ulonglong)uStack_c58 >> 0x20);
            if ((uStack_ce0._4_4_ < uVar23) ||
               ((uStack_ce0._4_4_ == uVar23 && (uVar10 < uStack_c50)))) goto LAB_;
          }
          goto LAB_;
        }
      }
      if (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) == *(longlong *)(lVar15 + 0x2120)) goto LAB_;
      cVar8 = func_0x(lVar15);
      if (cVar8 != '\0') goto LAB_;
      if (lVar19 == 0) {
        lVar19 = func_0x();
      }
      lVar33 = *plStack_cf8;
      if (*(short *)(lVar33 + 0x24) == 0) {
LAB_:
        uStack_b38 = *(undefined8 *)(lVar33 + 0x28);
        uStack_b30 = *(undefined2 *)(lVar33 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar33 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(lVar33 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar33 + 0x18) != 99) goto LAB_;
        }
        uStack_b7c = *(undefined4 *)(lVar33 + 0x20);
        uStack_b78 = *(undefined2 *)(lVar33 + 0x24);
        cVar8 = func_0x(&uStack_b7c);
        if (cVar8 == '\0') goto LAB_;
        func_0x(lVar33,&uStack_b38);
      }
      plVar5 = plStack_cf8;
      if (plStack_cf8 != (longlong *)0x0) {
        iVar11 = (int)(short)uStack_cec;
        if (((*(ushort *)((longlong)plStack_cf8 + 0x62) >> 10 & 1) == 0) || (iVar11 < 3)) {
          if (((byte)*(undefined2 *)((longlong)plStack_cf8 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)((longlong)plStack_cf8 + 100) & 8) != 0) &&
                (lVar33 = plStack_cf8[0x12], lVar33 != 0)) && (*(longlong *)(lVar33 + 0x758) != 0))
            {
              func_0x(*(undefined8 *)(lVar33 + 0x758),plStack_cf8,iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0)))))
             ) {
            iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_a88);
            if (iVar13 != 0) {
              LOCK();
              *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          func_0x(plVar5 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(plVar5,0,iVar11);
          }
          uStack_cec = uStack_cec & 0xffff0000;
          plStack_cf8 = (longlong *)0x0;
        }
        else {
          func_0x(&plStack_cf8);
        }
      }
      uStack_ac8 = uStack_b38;
      uStack_ac0 = uStack_b30;
      uStack_d68 = (ulonglong **)0x0;
      func_0x(*(undefined8 *)(lVar15 + 0x728),&uStack_ac8,4);
    } while( true );
  }
LAB_:
  iVar11 = *(int *)(plVar34 + 0x1ea);
  ppuVar30 = &puStack_b20;
  if (iVar11 != 0) {
    ppuVar30 = &puStack_d18;
  }
  puVar17 = *ppuVar30;
  uVar23 = 1;
LAB_:
  lVar19 = uStack_cc8;
  uVar12 = 1;
  if (iVar11 == 0) {
    uVar27 = (uint)*(ushort *)(*puVar17 + 0x16);
  }
  else {
    uVar27 = uVar12;
    if ((*(int *)(puVar17 + 0xe) == *piStack_c28) &&
       (*(short *)((longlong)puVar17 + 0x74) == *(short *)(piStack_c28 + 1))) {
      uVar27 = 0;
    }
  }
  uStack_a18 = 0;
  uStack_cb4 = 0;
  uStack_c9a = 0;
  uStack_c90 = 0;
  uStack_c8e = 0;
  uStack_ca8 = 0;
  pbStack_cb0 = (byte *)((longlong)plVar34 + 0xdc);
  bVar9 = *pbStack_cb0;
  if ((bVar9 & 1) == 0) {
    uStack_cb8 = 0;
    uStack_c92 = 0;
    uStack_c90 = 0;
    uVar24 = *(uint *)(plVar34 + 0x168);
    switch(bVar9 & 0xe) {
    default:
      uVar24 = (uint)*(ushort *)((longlong)plVar34 + 0xde);
      if (0x1f9d < uVar24 - 1) {
        func_0x(pbStack_cb0,6);
      }
      break;
    case 4:
      uVar24 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar24 = uVar12;
    }
    uStack_ca8 = CONCAT44(uStack_ca8._4_4_,uVar24);
  }
  else {
    uStack_cb8 = 1;
    switch(bVar9 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)plVar34 + 0xdd) < '\0') {
        uStack_cb6 = (*(ushort *)((longlong)plVar34 + 0xdd) & 0x7f) << 8 |
                     *(ushort *)((longlong)plVar34 + 0xdd) >> 8;
        uVar10 = 3;
        uStack_c70 = CONCAT22(uStack_c70._2_2_,3);
      }
      else {
        uStack_cb6 = (ushort)*(byte *)((longlong)plVar34 + 0xdd);
        uVar10 = 2;
      }
      sStack_c9c = (short)(uStack_cb6 + 1 >> 1) + (short)uStack_c70;
      if (uStack_cb6 < 0x1f) {
        uStack_ca0 = (uint)uVar10;
        uStack_c88 = 0;
      }
      else {
        iVar11 = uStack_cb6 - 1;
        uStack_ca0 = CONCAT22(((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                              (short)((longlong)iVar11 * 0x88888889 >> 0x3f),uVar10);
        uStack_c88 = 0;
      }
      break;
    case 4:
      if (((bVar9 & 0x1c) == 4) && ((bVar9 & 2) != 0)) {
        uStack_ca0 = 0;
        uStack_cb6 = 0;
        sStack_c9c = 0;
        uStack_c92 = 0;
        uStack_cb4 = 0xf;
        uStack_c88 = 1;
      }
      else {
        uStack_ca0 = 0;
        uStack_cb6 = 0;
        sStack_c9c = 0;
        uStack_c92 = 0;
        uStack_cb4 = 1;
        uStack_c88 = 0;
      }
      break;
    case 8:
      uStack_ca0 = 0;
      uStack_cb6 = 0;
      sStack_c9c = 0;
      uStack_c92 = 0;
      uStack_cb4 = 9;
      uStack_c88 = 0;
    }
  }
  puStack_a20 = &uStack_cb8;
  lStack_d48 = plVar34[1];
  uStack_d30 = 0;
  uStack_d38 = uStack_d38 & 0xffffffff00000000;
  uStack_d40 = 0;
  uStack_d50 = CONCAT44(uStack_d50._4_4_,(uint)(*(byte *)(plVar34[5] + 0x107) >> 6)) &
               0xffffffff00000001;
  uStack_d58 = (int *)CONCAT44(uStack_d58._4_4_,*(undefined4 *)((longlong)plVar34 + 0x1c));
  uStack_d60 = &puStack_a20;
  uStack_d68 = (ulonglong **)CONCAT44(uStack_d68._4_4_,1);
  func_0x
            (ppuVar30,(ulonglong)*(uint6 *)((longlong)plVar34 + 0x34) << 0x10,plVar34[5] + 0x3c0,
             uVar27);
  if (uVar23 != 0) {
    func_0x(plVar34,uVar14);
  }
  *(undefined *)(lVar19 + 0x2c9) = 0;
  lStack_a30 = 0;
code_r0x00103998:
  func_0x(&puStack_b20);
  func_0x(&puStack_d18);
  func_0x(uStack_40 ^ (ulonglong)auStack_d88);
  return;
}

