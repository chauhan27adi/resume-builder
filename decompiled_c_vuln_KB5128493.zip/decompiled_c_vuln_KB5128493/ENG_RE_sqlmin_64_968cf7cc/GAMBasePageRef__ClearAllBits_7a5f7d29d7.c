
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined4 param_2,undefined8 param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong lVar5;
  undefined auVar6 [16];
  char cVar7;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar8;
  undefined4 uStack_1b8;
  undefined2 uStack_1b4;
  undefined4 uStack_1b0;
  undefined8 uStack_1a8;
  undefined2 uStack_1a0;
  longlong **pplStack_198;
  undefined8 uStack_190;
  undefined2 uStack_188;
  undefined4 uStack_184;
  undefined8 uStack_180;
  undefined8 uStack_178;
  undefined8 uStack_16a;
  undefined8 uStack_160;
  undefined2 uStack_f8;
  undefined4 uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  undefined4 uStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  undefined8 uStack_80;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [10];
  undefined auStack_56 [6];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_1b8;
  pbStack_f0 = (byte *)0x0;
  uStack_f8 = 0xffff;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_e8 = 0;
  uStack_188 = 0xffff;
  uStack_180 = 0;
  uStack_184 = 0;
  uStack_16a = 0;
  uStack_160 = 0;
  uStack_178 = 0;
  lVar4 = **param_1;
  uStack_c4 = 1;
  uStack_1b0 = param_2;
  pplStack_198 = param_1;
  uStack_190 = param_3;
  if (-1 < *(char *)(lVar4 + 2)) goto LAB_;
  pbVar1 = (byte *)(lVar4 + 0x60);
  stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
  auStack_b0._0_2_ = 0xffff;
  uStack_98 = 0;
  uStack_8a = 0;
  uStack_a8 = 0;
  uStack_80 = 0;
  uStack_92 = 0;
  uStack_90 = 0;
  uStack_88 = 0;
  uStack_86 = 0;
  uStack_a0 = 0;
  psStack_78 = (short *)0x0;
  _auStack_60 = ZEXT812(0);
  auStack_56._2_4_ = 0;
  uStack_50 = 0;
  psStack_70 = (short *)0x0;
  sStack_68 = 0;
  uStack_66 = 0;
  auStack_c0 = ZEXT816(0);
  lVar5 = 0;
  if (*(short *)(lVar4 + 0x24) == 0) {
LAB_:
    auStack_c0._8_8_ = lVar5;
    uStack_1a8 = *(undefined8 *)(lVar4 + 0x28);
    uStack_1a0 = *(undefined2 *)(lVar4 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar4 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar4 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar4 + 0x18) != 99) goto LAB_;
    }
    uStack_1b8 = *(undefined4 *)(lVar4 + 0x20);
    uStack_1b4 = *(undefined2 *)(lVar4 + 0x24);
    cVar7 = func_0x(&uStack_1b8,0x1044f38);
    lVar5 = auStack_c0._8_8_;
    if (cVar7 == '\0') goto LAB_;
    func_0x(lVar4,&uStack_1a8);
  }
  auStack_c0._0_8_ = pbVar1;
  auStack_60._8_2_ = uStack_1a0;
  auStack_60._0_8_ = uStack_1a8;
  auStack_56._2_4_ = *(undefined4 *)(lVar4 + 0x20);
  auStack_b0._0_2_ = 0xffff;
  auStack_b0 = (undefined  [8])((ulonglong)auStack_b0 & 0xffffffff);
  uStack_a8 = 0;
  uStack_92 = 0;
  uStack_90 = 0;
  uVar3 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x10c5540);
  uVar8 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x10c5544);
  uStack_88 = 0;
  uStack_86 = 0;
  uStack_a0 = 0;
  psStack_78 = (short *)0x0;
  psStack_70 = (short *)0x0;
  sStack_68 = 0;
  uStack_1b8 = uVar3;
  if ((*pbVar1 & 2) != 0) {
    pbVar2 = pbVar1 + uVar8;
    uStack_a8 = pbVar2;
    if ((pbVar1[uVar8] & 1) == 0) {
      auVar6._14_2_ = 0;
      auVar6._0_14_ = stack0xffffffffffffff52;
      _auStack_b0 = auVar6 << 0x10;
      uStack_8a = 0;
      uStack_88 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100471 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x101224) - 0x14748f0))()
      ;
      return;
    }
    auStack_b0._0_2_ = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x101204) * 4 +
                           0x1011f4) - 0x14748f0);
                    /* WARNING: Could not emulate address calculation at 0x001002a6 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar1 & 4) != 0) {
    uStack_1b8._2_2_ = (short)((uint)uVar3 >> 0x10);
    if (uStack_1b8._2_2_ != 0) {
      uVar8 = (ulonglong)*(ushort *)(lVar4 + 0x61 + (longlong)uStack_1b8._2_2_ * 2);
    }
    psStack_78 = (short *)(pbVar1 + uVar8);
    psStack_70 = psStack_78 + 1;
    sStack_68 = (*psStack_78 + 1) * 2;
  }
  if (auStack_c0._8_8_ != 0) {
    func_0x(auStack_c0._8_8_,auStack_c0);
  }
LAB_:
  pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar4 + 0x1ffc) + lVar4);
  if ((*pbStack_f0 & 1) == 0) {
    uStack_f8 = 0;
    uStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007dc */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_f0 & 0xe) * 4 + 0x101290) - 0x14748f0))
              ((longlong)(int)(*pbStack_f0 & 0xe),0x1044f38);
    return;
  }
  uStack_f8 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_f0 & 0x1c) + 0x101270) * 4 +
                         0x101260) - 0x14748f0);
                    /* WARNING: Could not emulate address calculation at 0x0010059b */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

