
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint param_2,longlong param_3)

{
  int *piVar1;
  short *psVar2;
  byte *pbVar3;
  uint *puVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  char cVar9;
  short sVar10;
  int iVar11;
  longlong lVar12;
  ulonglong uVar13;
  short *psVar14;
  undefined4 *puVar15;
  ulonglong *puVar16;
  undefined8 uVar17;
  longlong lVar18;
  short sVar19;
  ushort uVar20;
  int iVar21;
  undefined4 uVar22;
  ulonglong uVar23;
  byte bVar24;
  ushort uVar25;
  uint uVar26;
  longlong lVar27;
  undefined8 unaff_RBX;
  undefined *puVar28;
  ulonglong uVar29;
  uint uVar30;
  byte **ppbVar31;
  ulonglong *puVar32;
  int iVar33;
  byte *pbVar34;
  ulonglong *puVar35;
  longlong lVar36;
  short sVar37;
  undefined2 uVar38;
  short sVar39;
  uint uVar40;
  uint uVar41;
  longlong unaff_GS_OFFSET;
  bool bVar42;
  int aiStackX_8 [8];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar4 = (uint *)(&stack0x00000078 + lVar12);
  *(undefined8 *)(&stack0x00001370 + lVar12) = unaff_RBX;
  *(ulonglong *)(&stack0x00001318 + lVar12) = _DAT_ ^ (ulonglong)puVar4;
  sVar39 = *(short *)(param_3 + 6);
  uVar29 = 0;
  iVar21 = *(int *)(param_3 + 0x18);
  *(ushort *)(&stack0x00000086 + lVar12) = *(ushort *)(&stack0x00000086 + lVar12) & 0xffe0;
  cVar9 = *(char *)(param_3 + 1);
  *(longlong *)(&stack0x00000128 + lVar12) = param_1;
  *(undefined4 *)(&stack0x000000e0 + lVar12) = 0;
  *(undefined4 *)(&stack0x000000e4 + lVar12) = 0xffffffff;
  *(undefined8 *)(&stack0x000000e8 + lVar12) = 0;
  *(undefined2 *)(&stack0x000000fa + lVar12) = 0;
  *(undefined8 *)(&stack0x000000fc + lVar12) = 0;
  *(int *)(&stack0x000000f0 + lVar12) = iVar21;
  *(short *)(&stack0x000000f4 + lVar12) = sVar39;
  *(undefined2 *)(&stack0x000000f6 + lVar12) = 0;
  sVar37 = (short)(param_2 >> 0x10);
  *(short *)(&stack0x000000f8 + lVar12) = sVar37;
  *(undefined4 *)(&stack0x00000080 + lVar12) = 0;
  *(undefined2 *)(&stack0x00000084 + lVar12) = 0;
  *(undefined8 *)(&stack0x00000088 + lVar12) = 0;
  puVar28 = &stack0xffffffffffffffc8 + lVar12;
  if ((byte)(cVar9 - 1U) < 2) {
    uVar41 = iVar21 + (param_2 >> 0x10);
    lVar36 = (ulonglong)
             ((uVar41 >> 10) + (uVar41 >> 0x14) + uVar41 &
             *(uint *)(*(longlong *)(param_1 + 0x2b8) + 0x1c)) * 0x10 +
             *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x10);
    lVar27 = *(longlong *)(lVar36 + 8);
LAB_:
    if ((lVar27 == lVar36) || (lVar27 == 0)) goto LAB_;
    if (*(int *)(lVar27 + 0x10) == iVar21) {
      sVar19 = 0;
      if (*(short *)(lVar27 + 0x14) != 1) {
        sVar19 = *(short *)(lVar27 + 0x14);
      }
      sVar10 = sVar39;
      if (sVar39 == 1) {
        sVar10 = 0;
      }
      if ((sVar19 == sVar10) && (*(short *)(lVar27 + 0x16) == sVar37)) {
        if (lVar27 != 0) {
          *(undefined4 *)(&stack0x000000e0 + lVar12) =
               *(undefined4 *)(*(longlong *)(lVar27 + 0x20) + 0x18);
          *(undefined4 *)(&stack0x000000e4 + lVar12) =
               *(undefined4 *)(*(longlong *)(lVar27 + 0x20) + 0x1c);
          uVar17 = *(undefined8 *)(*(longlong *)(lVar27 + 0x20) + 0x28);
          *(undefined4 *)(&stack0x000000fc + lVar12) =
               *(undefined4 *)(*(longlong *)(lVar27 + 0x20) + 0x20);
          *(undefined8 *)(&stack0x000000e8 + lVar12) = uVar17;
          *(undefined2 *)(&stack0x000000f8 + lVar12) =
               *(undefined2 *)(*(longlong *)(lVar27 + 0x20) + 0x30);
          *(undefined2 *)(&stack0x000000fa + lVar12) =
               *(undefined2 *)(*(longlong *)(lVar27 + 0x18) + 0x38);
          puVar28 = &stack0xffffffffffffffc8 + lVar12;
          if ((*(longlong *)(lVar27 + 0x30) == 0) ||
             (puVar28 = &stack0xffffffffffffffc8 + lVar12,
             (*(byte *)(*(longlong *)(lVar27 + 0x30) + 0x18) & 4) == 0)) goto LAB_;
          lVar27 = *(longlong *)(*(longlong *)(lVar27 + 0x20) + 0x80);
          *(longlong *)(&stack0x000000d8 + lVar12) = lVar27;
          lVar27 = *(longlong *)(lVar27 + 8);
          if ((*(byte *)(lVar27 + 0x42) & 4) == 0) {
            uVar41 = *(uint *)(lVar27 + 0xb0);
            uVar13 = (ulonglong)uVar41;
            if (0x1f9e < uVar41) {
              uVar13 = 0x1f9e;
            }
          }
          else {
            uVar13 = 0x1f9e;
          }
          uVar23 = uVar13 + 0xf;
          *(int *)(&stack0x0000009c + lVar12) = (int)uVar13;
          if (uVar23 <= uVar13) {
            uVar23 = 0xffffffffffffff0;
          }
          uVar23 = uVar23 & 0xfffffffffffffff0;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001dc;
          func_0x();
          uVar20 = *(ushort *)(param_3 + 0x16);
          lVar27 = -uVar23;
          *puVar4 = 0;
          *(undefined **)(&stack0x00000148 + lVar12) = &stack0x00000078 + lVar27 + lVar12;
          puVar28 = &stack0xffffffffffffffc8 + lVar27 + lVar12;
          if ((ulonglong)uVar20 == 0) goto LAB_;
          psVar14 = (short *)(param_3 + 0x1ffe);
          uVar13 = uVar29;
          uVar23 = uVar29;
          goto LAB_;
        }
LAB_:
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101f37;
        func_0x(&stack0x000000e0 + lVar12);
        puVar28 = &stack0xffffffffffffffc8 + lVar12;
        goto LAB_;
      }
    }
    lVar27 = *(longlong *)(lVar27 + 8);
    goto LAB_;
  }
  goto LAB_;
code_r0x00100260:
  puVar28 = (undefined *)0x0;
  uVar26 = 1;
  cVar9 = *(char *)(param_3 + 2);
  *(undefined2 *)(&stack0x00000150 + lVar12) = 0xffff;
  *(undefined8 *)(&stack0x00000158 + lVar12) = 0;
  *(undefined4 *)(&stack0x00000154 + lVar12) = 0;
  *(undefined8 *)(&stack0x0000016e + lVar12) = 0;
  *(undefined8 *)(&stack0x00000178 + lVar12) = 0;
  *(undefined8 *)(&stack0x00000160 + lVar12) = 0;
  *(undefined4 *)(&stack0x00000184 + lVar12) = 0xffffffff;
  *(undefined2 *)(&stack0x00000200 + lVar12) = 0xffff;
  *(undefined8 *)(&stack0x00000208 + lVar12) = 0;
  *(undefined4 *)(&stack0x00000204 + lVar12) = 0;
  *(undefined8 *)(&stack0x0000021e + lVar12) = 0;
  *(undefined8 *)(&stack0x00000228 + lVar12) = 0;
  *(undefined8 *)(&stack0x00000210 + lVar12) = 0;
  uVar41 = (uint)uVar23;
  *(uint *)(&stack0x00000234 + lVar12) = uVar41;
  if (cVar9 < '\0') {
    pbVar34 = (byte *)(param_3 + 0x60);
    *(undefined (*) [16])(&stack0x00000248 + lVar12) = ZEXT816(0);
    *(undefined8 *)(&stack0x000002a8 + lVar12) = 0;
    *(undefined (*) [16])(&stack0x00000258 + lVar12) = ZEXT816(0);
    *(undefined8 *)(&stack0x00000250 + lVar12) = 0;
    *(undefined (*) [16])(&stack0x00000268 + lVar12) = ZEXT816(0);
    *(undefined4 *)(&stack0x0000024c + lVar12) = 0;
    *(undefined (*) [16])(&stack0x00000298 + lVar12) = ZEXT816(0);
    *(undefined8 *)(&stack0x00000266 + lVar12) = 0;
    *(undefined (*) [16])(&stack0x00000278 + lVar12) = ZEXT816(0);
    *(undefined8 *)(&stack0x00000270 + lVar12) = 0;
    *(undefined8 *)(&stack0x00000258 + lVar12) = 0;
    *(undefined8 *)(&stack0x00000280 + lVar12) = 0;
    *(undefined2 *)(&stack0x000002aa + lVar12) = 0;
    puVar28 = &stack0x00000238 + lVar12;
    *(undefined (*) [16])(&stack0x00000288 + lVar12) = ZEXT816(0);
    *(undefined2 *)(&stack0x00000248 + lVar12) = 0xffff;
    *(undefined (*) [16])(&stack0x00000238 + lVar12) = ZEXT816(0);
    *(undefined8 *)(&stack0x00000298 + lVar12) = 0;
    *(undefined4 *)(&stack0x000002a0 + lVar12) = 0;
    if (*(short *)(param_3 + 0x24) == 0) {
LAB_:
      uVar38 = *(undefined2 *)(param_3 + 0x30);
      *(undefined8 *)(&stack0x000000a0 + lVar12) = *(undefined8 *)(param_3 + 0x28);
      *(undefined2 *)(&stack0x000000a8 + lVar12) = uVar38;
    }
    else {
      cVar9 = *(char *)(param_3 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(param_3 + 0x18) != 99) {
LAB_:
          if (cVar9 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar9 != '\b') goto LAB_;
LAB_:
        if (*(int *)(param_3 + 0x18) != 99) goto LAB_;
      }
      *(undefined4 *)(&stack0x000000c4 + lVar12) = *(undefined4 *)(param_3 + 0x20);
      *(undefined2 *)(&stack0x000000c8 + lVar12) = *(undefined2 *)(param_3 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x1003a4;
      cVar9 = func_0x(&stack0x000000c4 + lVar12);
      if (cVar9 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x1003b4;
      func_0x(param_3,&stack0x000000a0 + lVar12);
      uVar38 = *(undefined2 *)(&stack0x000000a8 + lVar12);
    }
    bVar24 = *pbVar34;
    *(undefined4 *)(&stack0x00000298 + lVar12) = *(undefined4 *)(&stack0x000000a0 + lVar12);
    *(int *)(&stack0x0000029c + lVar12) =
         (int)((ulonglong)*(undefined8 *)(&stack0x000000a0 + lVar12) >> 0x20);
    *(undefined4 *)(&stack0x000002a4 + lVar12) = *(undefined4 *)(param_3 + 0x20);
    *(undefined2 *)(&stack0x000002a8 + lVar12) = *(undefined2 *)(param_3 + 0x24);
    *(undefined2 *)(&stack0x000002a0 + lVar12) = uVar38;
    lVar36 = (ulonglong)bVar24 * 6;
    *(byte **)(&stack0x00000238 + lVar12) = pbVar34;
    uVar29 = (ulonglong)*(short *)(lVar36 + 0xb52b54);
    *(undefined4 *)(&stack0x00000130 + lVar12) = *(undefined4 *)(lVar36 + 0xb52b50);
    *(undefined2 *)(&stack0x000002aa + lVar12) = 0;
    *(undefined2 *)(&stack0x00000248 + lVar12) = 0xffff;
    *(undefined8 *)(&stack0x00000250 + lVar12) = 0;
    uVar41 = 0;
    *(undefined4 *)(&stack0x0000024c + lVar12) = 0;
    *(undefined8 *)(&stack0x00000266 + lVar12) = 0;
    *(undefined8 *)(&stack0x00000270 + lVar12) = 0;
    *(undefined8 *)(&stack0x00000258 + lVar12) = 0;
    *(undefined2 *)(&stack0x00000290 + lVar12) = 0;
    *(undefined (*) [16])(&stack0x00000280 + lVar12) = ZEXT816(0);
    if ((bVar24 & 2) != 0) {
      bVar24 = pbVar34[uVar29];
      pbVar3 = pbVar34 + uVar29;
      *(byte **)(&stack0x00000250 + lVar12) = pbVar3;
      if ((bVar24 & 1) == 0) {
        *(undefined2 *)(&stack0x00000248 + lVar12) = 0;
        *(undefined4 *)(&stack0x0000026e + lVar12) = 0;
        switch(*pbVar3 & 0xe) {
        default:
          uVar41 = (uint)*(ushort *)(pbVar3 + 2);
          if (0x1f9d < *(ushort *)(pbVar3 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x1006a2;
            func_0x(pbVar3,6);
          }
          break;
        case 4:
          uVar41 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar41 = uVar26;
        }
        *(uint *)(&stack0x00000258 + lVar12) = uVar41;
        *(undefined8 *)(&stack0x00000266 + lVar12) = 0;
      }
      else {
        *(undefined2 *)(&stack0x00000248 + lVar12) = 1;
        bVar24 = *pbVar3;
        switch(bVar24 & 0x1c) {
        default:
          if ((char)pbVar3[1] < '\0') {
            sVar39 = 3;
            uVar20 = (*(ushort *)(pbVar3 + 1) & 0x7f) << 8 | *(ushort *)(pbVar3 + 1) >> 8;
          }
          else {
            sVar39 = 2;
            uVar20 = (ushort)pbVar3[1];
          }
          *(ushort *)(&stack0x0000024a + lVar12) = uVar20;
          *(short *)(&stack0x00000260 + lVar12) = sVar39;
          *(short *)(&stack0x00000264 + lVar12) = (short)(uVar20 + 1 >> 1) + sVar39;
          if (uVar20 < 0x1f) {
            *(undefined4 *)(&stack0x00000278 + lVar12) = 0;
            *(undefined2 *)(&stack0x00000262 + lVar12) = 0;
            *(undefined8 *)(&stack0x00000270 + lVar12) = 0;
            *(undefined8 *)(&stack0x00000258 + lVar12) = 0;
          }
          else {
            iVar21 = uVar20 - 1;
            *(undefined4 *)(&stack0x00000278 + lVar12) = 0;
            *(undefined8 *)(&stack0x00000270 + lVar12) = 0;
            *(undefined8 *)(&stack0x00000258 + lVar12) = 0;
            *(short *)(&stack0x00000262 + lVar12) =
                 ((short)(iVar21 / 0x1e) + (short)(iVar21 >> 0x1f)) -
                 (short)((longlong)iVar21 * 0x88888889 >> 0x3f);
          }
          break;
        case 4:
          uVar40 = uVar26;
          if (((bVar24 & 0x1c) == 4) && ((bVar24 & 2) != 0)) {
            uVar40 = 0xf;
            uVar41 = uVar26;
          }
          *(undefined4 *)(&stack0x00000260 + lVar12) = 0;
          *(undefined2 *)(&stack0x0000024a + lVar12) = 0;
          *(undefined2 *)(&stack0x00000264 + lVar12) = 0;
          *(undefined2 *)(&stack0x0000026e + lVar12) = 0;
          *(uint *)(&stack0x0000024c + lVar12) = uVar40;
          *(uint *)(&stack0x00000278 + lVar12) = uVar41;
          *(undefined8 *)(&stack0x00000270 + lVar12) = 0;
          *(undefined8 *)(&stack0x00000258 + lVar12) = 0;
          break;
        case 8:
          *(undefined4 *)(&stack0x00000260 + lVar12) = 0;
          *(undefined2 *)(&stack0x0000024a + lVar12) = 0;
          *(undefined2 *)(&stack0x00000264 + lVar12) = 0;
          *(undefined2 *)(&stack0x0000026e + lVar12) = 0;
          *(undefined4 *)(&stack0x0000024c + lVar12) = 9;
          *(undefined4 *)(&stack0x00000278 + lVar12) = 0;
          *(undefined8 *)(&stack0x00000270 + lVar12) = 0;
          *(undefined8 *)(&stack0x00000258 + lVar12) = 0;
        }
      }
    }
    if ((**(byte **)(&stack0x00000238 + lVar12) & 4) != 0) {
      if (*(short *)(&stack0x00000132 + lVar12) != 0) {
        uVar29 = (ulonglong)
                 *(ushort *)(param_3 + 0x61 + (longlong)*(short *)(&stack0x00000132 + lVar12) * 2);
      }
      psVar14 = (short *)(pbVar34 + uVar29);
      *(short **)(&stack0x00000280 + lVar12) = psVar14;
      sVar39 = *psVar14;
      *(short **)(&stack0x00000288 + lVar12) = psVar14 + 1;
      *(short *)(&stack0x00000290 + lVar12) = (sVar39 + 1) * 2;
    }
    lVar36 = *(longlong *)(&stack0x00000240 + lVar12);
    if (lVar36 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x100751;
      func_0x(lVar36,&stack0x00000238 + lVar12);
    }
    uVar13 = *(ulonglong *)(&stack0x00000090 + lVar12);
    uVar41 = *puVar4;
  }
  uVar26 = (uint)*(ushort *)(param_3 + 0xe);
  lVar36 = (0xfff - (longlong)(int)uVar41) * 2;
  pbVar34 = (byte *)((ulonglong)*(ushort *)(lVar36 + param_3) + param_3);
  bVar24 = *pbVar34;
  *(byte **)(&stack0x00000208 + lVar12) = pbVar34;
  if ((bVar24 & 1) == 0) {
    *(undefined2 *)(&stack0x00000200 + lVar12) = 0;
    *(undefined4 *)(&stack0x00000204 + lVar12) = 0;
    *(undefined4 *)(&stack0x00000226 + lVar12) = 0;
    switch(*pbVar34 & 0xe) {
    default:
      uVar26 = (uint)*(ushort *)(pbVar34 + 2);
      if (0x1f9d < *(ushort *)(pbVar34 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x100a04;
        func_0x(pbVar34,6);
        pbVar34 = *(byte **)(&stack0x00000208 + lVar12);
      }
      break;
    case 4:
      uVar26 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar26 = 1;
    }
    *(uint *)(&stack0x00000210 + lVar12) = uVar26;
    *(ulonglong *)(&stack0x0000021e + lVar12) = uVar13;
  }
  else {
    *(undefined2 *)(&stack0x00000200 + lVar12) = 1;
    bVar24 = *pbVar34;
    switch(bVar24 & 0x1c) {
    default:
      if ((char)pbVar34[1] < '\0') {
        uVar20 = *(ushort *)(pbVar34 + 1);
        sVar39 = 3;
        *(undefined2 *)(&stack0x00000218 + lVar12) = 3;
        uVar20 = (uVar20 & 0x7f) << 8 | uVar20 >> 8;
        *(ushort *)(&stack0x00000202 + lVar12) = uVar20;
      }
      else {
        uVar20 = (ushort)pbVar34[1];
        *(ushort *)(&stack0x00000202 + lVar12) = uVar20;
        sVar39 = 2;
        *(undefined2 *)(&stack0x00000218 + lVar12) = 2;
      }
      *(short *)(&stack0x0000021c + lVar12) = (short)(uVar20 + 1 >> 1) + sVar39;
      if (uVar20 < 0x1f) {
        *(undefined **)(&stack0x00000210 + lVar12) = puVar28;
        *(undefined2 *)(&stack0x0000021a + lVar12) = 0;
        *(undefined4 *)(&stack0x00000204 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000230 + lVar12) = 0;
        *(ulonglong *)(&stack0x00000228 + lVar12) = uVar13;
      }
      else {
        iVar21 = uVar20 - 1;
        *(undefined **)(&stack0x00000210 + lVar12) = puVar28;
        *(undefined4 *)(&stack0x00000204 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000230 + lVar12) = 0;
        *(ulonglong *)(&stack0x00000228 + lVar12) = uVar13;
        *(short *)(&stack0x0000021a + lVar12) =
             ((short)(iVar21 / 0x1e) + (short)(iVar21 >> 0x1f)) -
             (short)((longlong)iVar21 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar24 & 0x1c) == 4) && ((bVar24 & 2) != 0)) {
        *(undefined **)(&stack0x00000210 + lVar12) = puVar28;
        *(undefined8 *)(&stack0x00000218 + lVar12) = 0;
        *(undefined2 *)(&stack0x00000202 + lVar12) = 0;
        *(undefined8 *)(&stack0x00000220 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000204 + lVar12) = 0xf;
        *(undefined4 *)(&stack0x00000230 + lVar12) = 1;
        *(ulonglong *)(&stack0x00000228 + lVar12) = uVar13;
      }
      else {
        *(undefined **)(&stack0x00000210 + lVar12) = puVar28;
        *(undefined8 *)(&stack0x00000218 + lVar12) = 0;
        *(undefined2 *)(&stack0x00000202 + lVar12) = 0;
        *(undefined8 *)(&stack0x00000220 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000204 + lVar12) = 1;
        *(undefined4 *)(&stack0x00000230 + lVar12) = 0;
        *(ulonglong *)(&stack0x00000228 + lVar12) = uVar13;
      }
      break;
    case 8:
      *(undefined **)(&stack0x00000210 + lVar12) = puVar28;
      *(undefined8 *)(&stack0x00000218 + lVar12) = 0;
      *(undefined2 *)(&stack0x00000202 + lVar12) = 0;
      *(undefined8 *)(&stack0x00000220 + lVar12) = 0;
      *(undefined4 *)(&stack0x00000204 + lVar12) = 9;
      *(undefined4 *)(&stack0x00000230 + lVar12) = 0;
      *(ulonglong *)(&stack0x00000228 + lVar12) = uVar13;
    }
  }
  ppbVar31 = (byte **)0x0;
  bVar42 = false;
  if (*(short *)(&stack0x00000200 + lVar12) == 0) {
    bVar24 = *pbVar34 & 0xe;
    if (bVar24 == 2) {
      bVar42 = (pbVar34[1] & 1) != 0;
    }
    else if (((bVar24 - 10 & 0xf9) == 0) && (bVar24 != 0x10)) {
      bVar42 = true;
    }
  }
  else {
    bVar42 = ((*pbVar34 & 0x1c) - 4 & 0xffffffe7) == 0;
  }
  if (!bVar42) {
    *(uint *)(&stack0x00000184 + lVar12) = uVar41;
    if (-1 < *(char *)(param_3 + 2)) goto code_r0x00100edd;
    pbVar34 = (byte *)(param_3 + 0x60);
    if ((*(short *)(&stack0x00000150 + lVar12) == 0) ||
       (ppbVar31 = *(byte ***)(&stack0x00000160 + lVar12), ppbVar31 == (byte **)0x0)) {
      ppbVar31 = (byte **)(&stack0x00000188 + lVar12);
      *(undefined8 *)(&stack0x000001f8 + lVar12) = 0;
      *(undefined (*) [16])(&stack0x00000198 + lVar12) = ZEXT816(0);
      *(undefined8 *)(&stack0x000001a0 + lVar12) = 0;
      *(undefined (*) [16])(&stack0x000001a8 + lVar12) = ZEXT816(0);
      *(undefined2 *)(&stack0x00000198 + lVar12) = 0xffff;
      *(undefined (*) [16])(&stack0x000001b8 + lVar12) = ZEXT816(0);
      *(undefined4 *)(&stack0x0000019c + lVar12) = 0;
      *(undefined (*) [16])(&stack0x000001e8 + lVar12) = ZEXT816(0);
      *(undefined8 *)(&stack0x000001b6 + lVar12) = 0;
      *(undefined (*) [16])(&stack0x000001c8 + lVar12) = ZEXT816(0);
      *(undefined8 *)(&stack0x000001c0 + lVar12) = 0;
      *(undefined (*) [16])(&stack0x000001d8 + lVar12) = ZEXT816(0);
      *(undefined8 *)(&stack0x000001a8 + lVar12) = 0;
      *(undefined (*) [16])(&stack0x00000188 + lVar12) = ZEXT816(0);
      *(undefined8 *)(&stack0x000001d0 + lVar12) = 0;
      *(undefined8 *)(&stack0x000001e8 + lVar12) = 0;
      *(undefined4 *)(&stack0x000001f0 + lVar12) = 0;
      *(undefined2 *)(&stack0x000001fa + lVar12) = 0;
    }
    uVar41 = 0;
    if (*(short *)(param_3 + 0x24) == 0) {
code_r0x00100bc9:
      uVar38 = *(undefined2 *)(param_3 + 0x30);
      *(undefined8 *)(&stack0x000000b0 + lVar12) = *(undefined8 *)(param_3 + 0x28);
      *(undefined2 *)(&stack0x000000b8 + lVar12) = uVar38;
    }
    else {
      cVar9 = *(char *)(param_3 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(param_3 + 0x18) != 99) {
code_r0x00100b8e:
          if (cVar9 != '\t') goto code_r0x00100bc9;
          goto code_r0x00100b92;
        }
      }
      else {
        if (cVar9 != '\b') goto code_r0x00100b8e;
code_r0x00100b92:
        if (*(int *)(param_3 + 0x18) != 99) goto code_r0x00100bc9;
      }
      *(undefined4 *)(&stack0x000000cc + lVar12) = *(undefined4 *)(param_3 + 0x20);
      *(undefined2 *)(&stack0x000000d0 + lVar12) = *(undefined2 *)(param_3 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x100bb2;
      cVar9 = func_0x(&stack0x000000cc + lVar12);
      if (cVar9 == '\0') goto code_r0x00100bc9;
      *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x100bc2;
      func_0x(param_3,&stack0x000000b0 + lVar12);
      uVar38 = *(undefined2 *)(&stack0x000000b8 + lVar12);
    }
    uVar22 = *(undefined4 *)(&stack0x000000b0 + lVar12);
    *ppbVar31 = pbVar34;
    *(undefined4 *)(ppbVar31 + 0xc) = uVar22;
    uVar17 = *(undefined8 *)(&stack0x000000b0 + lVar12);
    *(undefined2 *)(ppbVar31 + 0xd) = uVar38;
    *(int *)((longlong)ppbVar31 + 100) = (int)((ulonglong)uVar17 >> 0x20);
    *(undefined4 *)((longlong)ppbVar31 + 0x6c) = *(undefined4 *)(param_3 + 0x20);
    *(undefined2 *)(ppbVar31 + 0xe) = *(undefined2 *)(param_3 + 0x24);
    *(undefined2 *)((longlong)ppbVar31 + 0x72) = 0;
    uVar29 = (ulonglong)*(short *)((ulonglong)*pbVar34 * 6 + 0xb52b54);
    *(undefined4 *)(&stack0x00000138 + lVar12) = *(undefined4 *)((ulonglong)*pbVar34 * 6 + 0xb52b50)
    ;
    *(undefined2 *)(ppbVar31 + 2) = 0xffff;
    ppbVar31[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar31 + 0x2e) = 0;
    ppbVar31[7] = (byte *)0x0;
    ppbVar31[4] = (byte *)0x0;
    ppbVar31[9] = (byte *)0x0;
    ppbVar31[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar31 + 0xb) = 0;
    if ((**ppbVar31 & 2) != 0) {
      pbVar3 = pbVar34 + uVar29;
      if ((pbVar34[uVar29] & 1) == 0) {
        *(undefined2 *)(ppbVar31 + 2) = 0;
        *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar31 + 0x36) = 0;
        ppbVar31[3] = pbVar3;
        switch(*pbVar3 & 0xe) {
        default:
          uVar41 = (uint)*(ushort *)(pbVar3 + 2);
          if (0x1f9d < *(ushort *)(pbVar3 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x100e47;
            func_0x(pbVar3,6);
          }
          break;
        case 4:
          uVar41 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar41 = 1;
        }
        *(uint *)(ppbVar31 + 4) = uVar41;
        *(undefined8 *)((longlong)ppbVar31 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar31 + 2) = 1;
        ppbVar31[3] = pbVar3;
        bVar24 = *pbVar3;
        switch(bVar24 & 0x1c) {
        default:
          if ((char)pbVar3[1] < '\0') {
            uVar20 = *(ushort *)(pbVar3 + 1);
            sVar39 = 3;
            *(ushort *)((longlong)ppbVar31 + 0x12) = uVar20;
            uVar20 = (uVar20 & 0x7f) << 8 | uVar20 >> 8;
          }
          else {
            sVar39 = 2;
            uVar20 = (ushort)pbVar3[1];
          }
          *(ushort *)((longlong)ppbVar31 + 0x12) = uVar20;
          *(short *)(ppbVar31 + 5) = sVar39;
          uVar20 = *(ushort *)((longlong)ppbVar31 + 0x12);
          *(short *)((longlong)ppbVar31 + 0x2c) = (short)(uVar20 + 1 >> 1) + sVar39;
          if (uVar20 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar31 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
            *(undefined4 *)(ppbVar31 + 8) = 0;
            ppbVar31[7] = (byte *)0x0;
            ppbVar31[4] = (byte *)0x0;
          }
          else {
            iVar21 = uVar20 - 1;
            *(short *)((longlong)ppbVar31 + 0x2a) =
                 ((short)(iVar21 / 0x1e) + (short)(iVar21 >> 0x1f)) -
                 (short)((longlong)iVar21 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
            *(undefined4 *)(ppbVar31 + 8) = 0;
            ppbVar31[7] = (byte *)0x0;
            ppbVar31[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar24 & 0x1c) != 4) || (bVar42 = true, (bVar24 & 2) == 0)) {
            bVar42 = false;
          }
          if (!bVar42) {
            uVar22 = 1;
          }
          else {
            *(undefined4 *)(ppbVar31 + 8) = 0;
            uVar22 = 0xf;
          }
          ppbVar31[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar31 + 0x12) = 0;
          ppbVar31[6] = (byte *)0x0;
          ppbVar31[4] = (byte *)0x0;
          ppbVar31[7] = (byte *)0x0;
          ppbVar31[3] = pbVar3;
          *(undefined4 *)((longlong)ppbVar31 + 0x14) = uVar22;
          *(uint *)(ppbVar31 + 8) = (uint)bVar42;
          ppbVar31[7] = (byte *)0x0;
          ppbVar31[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar31[7] = (byte *)0x0;
          ppbVar31[7] = (byte *)0x0;
          ppbVar31[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar31 + 0x12) = 0;
          ppbVar31[6] = (byte *)0x0;
          ppbVar31[4] = (byte *)0x0;
          ppbVar31[3] = pbVar3;
          *(undefined4 *)((longlong)ppbVar31 + 0x14) = 9;
          *(undefined4 *)(ppbVar31 + 8) = 0;
          ppbVar31[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar31 & 4) != 0) {
      if (*(short *)(&stack0x0000013a + lVar12) != 0) {
        uVar29 = (ulonglong)
                 *(ushort *)(param_3 + 0x61 + (longlong)*(short *)(&stack0x0000013a + lVar12) * 2);
      }
      psVar14 = (short *)(pbVar34 + uVar29);
      ppbVar31[9] = (byte *)psVar14;
      sVar39 = *psVar14;
      ppbVar31[10] = (byte *)(psVar14 + 1);
      *(short *)(ppbVar31 + 0xb) = (sVar39 + 1) * 2;
    }
    pbVar34 = ppbVar31[1];
    if (pbVar34 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x100eda;
      func_0x(pbVar34,ppbVar31);
    }
code_r0x00100edd:
    iVar21 = 0;
    uVar41 = (uint)*(ushort *)(param_3 + 0xe);
    pbVar34 = (byte *)((ulonglong)*(ushort *)(lVar36 + param_3) + param_3);
    bVar24 = *pbVar34;
    *(byte **)(&stack0x00000158 + lVar12) = pbVar34;
    if ((bVar24 & 1) == 0) {
      *(undefined2 *)(&stack0x00000150 + lVar12) = 0;
      *(undefined4 *)(&stack0x00000154 + lVar12) = 0;
      *(undefined4 *)(&stack0x00000176 + lVar12) = 0;
      switch(*pbVar34 & 0xe) {
      default:
        uVar41 = (uint)*(ushort *)(pbVar34 + 2);
        if (0x1f9d < *(ushort *)(pbVar34 + 2) - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101169;
          func_0x(pbVar34,6);
        }
        break;
      case 4:
        uVar41 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar41 = 1;
      }
      *(undefined8 *)(&stack0x0000016e + lVar12) = *(undefined8 *)(&stack0x00000090 + lVar12);
      *(uint *)(&stack0x00000160 + lVar12) = uVar41;
    }
    else {
      *(undefined2 *)(&stack0x00000150 + lVar12) = 1;
      bVar24 = *pbVar34;
      switch(bVar24 & 0x1c) {
      default:
        if ((char)pbVar34[1] < '\0') {
          uVar20 = *(ushort *)(pbVar34 + 1);
          sVar39 = 3;
          *(undefined2 *)(&stack0x00000168 + lVar12) = 3;
          *(ushort *)(&stack0x00000152 + lVar12) = (uVar20 & 0x7f) << 8 | uVar20 >> 8;
        }
        else {
          *(ushort *)(&stack0x00000152 + lVar12) = (ushort)pbVar34[1];
          sVar39 = 2;
          *(undefined2 *)(&stack0x00000168 + lVar12) = 2;
        }
        uVar20 = *(ushort *)(&stack0x00000152 + lVar12);
        *(short *)(&stack0x0000016c + lVar12) = (short)(uVar20 + 1 >> 1) + sVar39;
        if (uVar20 < 0x1f) {
          *(undefined8 *)(&stack0x00000178 + lVar12) = *(undefined8 *)(&stack0x00000090 + lVar12);
          *(undefined2 *)(&stack0x0000016a + lVar12) = 0;
          *(undefined4 *)(&stack0x00000154 + lVar12) = 0;
          *(undefined4 *)(&stack0x00000180 + lVar12) = 0;
          *(byte ***)(&stack0x00000160 + lVar12) = ppbVar31;
        }
        else {
          iVar11 = uVar20 - 1;
          *(undefined4 *)(&stack0x00000154 + lVar12) = 0;
          *(undefined4 *)(&stack0x00000180 + lVar12) = 0;
          *(byte ***)(&stack0x00000160 + lVar12) = ppbVar31;
          *(undefined8 *)(&stack0x00000178 + lVar12) = *(undefined8 *)(&stack0x00000090 + lVar12);
          *(short *)(&stack0x0000016a + lVar12) =
               ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
               (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
        }
        break;
      case 4:
        if (((bVar24 & 0x1c) == 4) && ((bVar24 & 2) != 0)) {
          *(undefined8 *)(&stack0x00000178 + lVar12) = *(undefined8 *)(&stack0x00000090 + lVar12);
          *(undefined8 *)(&stack0x00000168 + lVar12) = 0;
          *(undefined2 *)(&stack0x00000152 + lVar12) = 0;
          *(undefined8 *)(&stack0x00000170 + lVar12) = 0;
          *(undefined4 *)(&stack0x00000154 + lVar12) = 0xf;
          *(undefined4 *)(&stack0x00000180 + lVar12) = 1;
          *(byte ***)(&stack0x00000160 + lVar12) = ppbVar31;
        }
        else {
          *(undefined8 *)(&stack0x00000178 + lVar12) = *(undefined8 *)(&stack0x00000090 + lVar12);
          *(undefined8 *)(&stack0x00000168 + lVar12) = 0;
          *(undefined2 *)(&stack0x00000152 + lVar12) = 0;
          *(undefined8 *)(&stack0x00000170 + lVar12) = 0;
          *(undefined4 *)(&stack0x00000154 + lVar12) = 1;
          *(undefined4 *)(&stack0x00000180 + lVar12) = 0;
          *(byte ***)(&stack0x00000160 + lVar12) = ppbVar31;
        }
        break;
      case 8:
        *(undefined8 *)(&stack0x00000178 + lVar12) = *(undefined8 *)(&stack0x00000090 + lVar12);
        *(undefined8 *)(&stack0x00000168 + lVar12) = 0;
        *(undefined2 *)(&stack0x00000152 + lVar12) = 0;
        *(undefined8 *)(&stack0x00000170 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000154 + lVar12) = 9;
        *(undefined4 *)(&stack0x00000180 + lVar12) = 0;
        *(byte ***)(&stack0x00000160 + lVar12) = ppbVar31;
      }
    }
    do {
      if (*(short *)(&stack0x00000150 + lVar12) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101199;
        uVar41 = func_0x(&stack0x00000152 + lVar12);
      }
      else {
        uVar41 = (uint)*(ushort *)(&stack0x00000152 + lVar12);
      }
      if ((int)uVar41 <= iVar21) {
        uVar41 = *puVar4;
        uVar13 = *(ulonglong *)(&stack0x00000090 + lVar12);
        break;
      }
      uVar41 = (uint)(short)~(ushort)iVar21;
      if ((short)(ushort)iVar21 < 0) {
code_r0x0010124c:
        uVar17 = *(undefined8 *)(&stack0x000000d8 + lVar12);
        *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x10125b;
        func_0x(uVar17,uVar41,&stack0x00000080 + lVar12);
      }
      else {
        if ((uVar41 & 0xc0000000) == 0x80000000) {
          uVar17 = **(undefined8 **)
                     (*(longlong *)(*(longlong *)(&stack0x000000d8 + lVar12) + 8) + 0x160);
          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x10123e;
          puVar15 = (undefined4 *)func_0x(uVar17,uVar41 & 0x1fffffff);
        }
        else {
          uVar17 = *(undefined8 *)
                    (*(longlong *)(*(longlong *)(&stack0x000000d8 + lVar12) + 8) + 0x160);
          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101223;
          puVar15 = (undefined4 *)func_0x(uVar17);
        }
        if (puVar15 == (undefined4 *)0x0) goto code_r0x0010124c;
        uVar22 = puVar15[1];
        uVar7 = puVar15[2];
        uVar8 = puVar15[3];
        *(undefined4 *)(&stack0x00000080 + lVar12) = *puVar15;
        *(undefined4 *)(&stack0x00000084 + lVar12) = uVar22;
        *(undefined4 *)(&stack0x00000088 + lVar12) = uVar7;
        *(undefined4 *)(&stack0x0000008c + lVar12) = uVar8;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x10126b;
      iVar11 = func_0x(&stack0x00000150 + lVar12,&stack0x00000080 + lVar12);
      if (iVar11 != 0) {
        iVar11 = 0;
        if (*(short *)(&stack0x00000150 + lVar12) == 0) {
          uVar41 = *(uint *)(&stack0x00000080 + lVar12);
          if ((uVar41 & 0xc0000000) == 0x80000000) {
            *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101b77;
            iVar11 = func_0x(&stack0x00000152 + lVar12);
            if (iVar11 == 0) {
code_r0x00101c35:
              puVar32 = (ulonglong *)0x0;
              *(undefined4 *)(&stack0x0000007c + lVar12) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101b9a;
              puVar32 = (ulonglong *)
                        func_0x(&stack0x0000017a + lVar12,&stack0x00000080 + lVar12,
                                        &stack0x0000007c + lVar12);
            }
          }
          else {
            uVar26 = *(uint *)(&stack0x00000160 + lVar12);
            uVar29 = (ulonglong)uVar26;
            puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
            uVar20 = *(ushort *)(&stack0x00000086 + lVar12) >> 4 & 1;
            if (uVar20 != 0) {
              if ((*(byte *)puVar32 & 0x10) == 0) {
                if ((1 << (*(byte *)puVar32 & 0xe) & 0x1105U) == 0) goto code_r0x001012d0;
              }
              else if (((int)uVar41 < (int)uVar26) &&
                      (*(ushort *)(&stack0x00000084 + lVar12) <=
                       *(ushort *)(uVar29 + (longlong)puVar32))) goto code_r0x001012d0;
              goto code_r0x00101324;
            }
code_r0x001012d0:
            if ((int)uVar41 < 0) {
              if (*(int *)(&stack0x00000154 + lVar12) == 0) {
                *(undefined2 *)(&stack0x00000152 + lVar12) = 0;
                *(uint *)(&stack0x00000164 + lVar12) = uVar26;
                if ((*(byte *)puVar32 & 0x10) != 0) {
                  *(uint *)(&stack0x00000164 + lVar12) =
                       uVar26 + 2 + (*(ushort *)(uVar29 + (longlong)puVar32) + 7 >> 3);
                }
                if ((*(byte *)puVar32 & 0x20) == 0) {
                  uVar40 = *(uint *)(&stack0x00000164 + lVar12);
                  *(uint *)(&stack0x00000154 + lVar12) = uVar40;
                  *(uint *)(&stack0x00000168 + lVar12) = uVar40;
                  *(undefined2 *)(&stack0x0000016c + lVar12) = 0;
                  uVar26 = uVar40;
                }
                else {
                  psVar14 = (short *)((ulonglong)*(uint *)(&stack0x00000164 + lVar12) +
                                     (longlong)puVar32);
                  sVar39 = *psVar14;
                  *(short *)(&stack0x0000016c + lVar12) = sVar39;
                  if (sVar39 == 0) {
                    if ((cRam000000000146563b != '\0') || ((bRam0000000001475f40 & 1) != 0)) {
                      lVar36 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000009d3ec8 * 8) + 8 +
                                (ulonglong)*puRam00000000009d3ed0);
                      if ((lVar36 != 0) &&
                         ((lVar36 = *(longlong *)(lVar36 + 0x60), lVar36 != 0 &&
                          (*(char *)(lVar36 + 0x499) != '\0')))) {
                        if ((cRam000000000146552b == '\0') && ((bRam0000000001475f40 & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x10148b;
                          (*pcRam00000000009d3e68)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar27 + lVar12) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x1014af;
                          (*pcRam00000000009d3e60)(1,0xd56068,0xe75d38,0x80f);
                        }
                      }
                      puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x1014c3;
                    func_0x(puVar32,3);
                    puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                  }
                  uVar26 = *(int *)(&stack0x00000164 + lVar12) +
                           (*(ushort *)(&stack0x0000016c + lVar12) + 1) * 2;
                  *(uint *)(&stack0x00000168 + lVar12) = uVar26;
                  if (0x1f9e < uVar26) {
                    if ((cRam000000000146563b != '\0') || ((bRam0000000001475f40 & 1) != 0)) {
                      lVar36 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000009d3ec8 * 8) + 8 +
                                (ulonglong)*puRam00000000009d3ed0);
                      if ((lVar36 != 0) &&
                         ((lVar36 = *(longlong *)(lVar36 + 0x60), lVar36 != 0 &&
                          (*(char *)(lVar36 + 0x499) != '\0')))) {
                        if ((cRam000000000146552b == '\0') && ((bRam0000000001475f40 & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x10156e;
                          (*pcRam00000000009d3e68)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar27 + lVar12) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101592;
                          (*pcRam00000000009d3e60)(1,0xd56068,0xe75d38,0x816);
                        }
                      }
                      puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x1015a6;
                    func_0x(puVar32,4);
                    uVar26 = *(uint *)(&stack0x00000168 + lVar12);
                    puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                  }
                  uVar40 = (ushort)psVar14[*(ushort *)(&stack0x0000016c + lVar12)] & 0x7fff;
                  *(uint *)(&stack0x00000154 + lVar12) = uVar40;
                  if (uVar40 < uVar26) {
                    if ((cRam000000000146563b != '\0') || ((bRam0000000001475f40 & 1) != 0)) {
                      lVar36 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam00000000009d3ec8 * 8) + 8 +
                                (ulonglong)*puRam00000000009d3ed0);
                      if ((lVar36 != 0) &&
                         ((lVar36 = *(longlong *)(lVar36 + 0x60), lVar36 != 0 &&
                          (*(char *)(lVar36 + 0x499) != '\0')))) {
                        if ((cRam000000000146552b == '\0') && ((bRam0000000001475f40 & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101652;
                          (*pcRam00000000009d3e68)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar27 + lVar12) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101676;
                          (*pcRam00000000009d3e60)(1,0xd56068,0xe75d38,0x81d);
                        }
                      }
                      puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x10168a;
                    func_0x(puVar32,4);
                    uVar26 = *(uint *)(&stack0x00000168 + lVar12);
                    puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                    uVar40 = *(uint *)(&stack0x00000154 + lVar12);
                  }
                  do {
                    uVar20 = *(ushort *)(&stack0x0000016c + lVar12);
                    if (-1 < psVar14[(ulonglong)(uVar20 - 1) + 1]) break;
                    uVar30 = uVar26;
                    if (((uVar20 != 1) &&
                        (uVar30 = *(ushort *)
                                   ((longlong)puVar32 +
                                   (ulonglong)uVar20 * 2 +
                                   ((ulonglong)*(uint *)(&stack0x00000164 + lVar12) - 2)) & 0x7fff,
                        uVar30 < uVar26)) ||
                       ((*(ushort *)
                          ((longlong)puVar32 +
                          (ulonglong)uVar20 * 2 + (ulonglong)*(uint *)(&stack0x00000164 + lVar12)) &
                        0x7fff) < uVar30)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x1016f3;
                      func_0x(puVar32,7);
                      uVar26 = *(uint *)(&stack0x00000168 + lVar12);
                      puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                      uVar40 = *(uint *)(&stack0x00000154 + lVar12);
                    }
                    if ((uVar30 < uVar26) || (uVar40 < uVar30)) {
                      uVar41 = *(uint *)(&stack0x00000080 + lVar12);
                      uVar29 = (ulonglong)*(uint *)(&stack0x00000160 + lVar12);
                      goto code_r0x00101a8a;
                    }
                    if (*(ushort *)((ulonglong)uVar30 + (longlong)puVar32) == 5) {
                      *(ushort *)(&stack0x00000152 + lVar12) =
                           *(ushort *)(&stack0x00000152 + lVar12) | 2;
                      *(short *)(&stack0x0000016c + lVar12) =
                           *(short *)(&stack0x0000016c + lVar12) + -1;
                      uVar20 = *(ushort *)(&stack0x0000017c + lVar12);
                      *(short *)(&stack0x0000017a + lVar12) = (short)uVar30;
                      uVar25 = *(ushort *)((ulonglong)(uVar30 & 0xffff) + 2 + (longlong)puVar32);
                      if ((uVar25 & 0x4000) == 0) {
                        uVar20 = uVar20 & 0xc7ff;
                      }
                      else {
                        uVar20 = uVar20 ^ (uVar20 ^ uVar25) & 0x3800;
                      }
                      uVar41 = *(uint *)(&stack0x00000080 + lVar12);
                      uVar29 = (ulonglong)*(uint *)(&stack0x00000160 + lVar12);
                      *(ushort *)(&stack0x0000017c + lVar12) = uVar20;
                      *(ushort *)(&stack0x0000017c + lVar12) =
                           uVar20 ^ (uVar20 ^ *(ushort *)
                                               ((ulonglong)(uVar30 & 0xffff) + 2 + (longlong)puVar32
                                               )) & 0x7ff;
                      goto code_r0x00101810;
                    }
                    if (*(ushort *)((ulonglong)uVar30 + (longlong)puVar32) < 0x400) break;
                    *(ushort *)(&stack0x00000152 + lVar12) =
                         *(ushort *)(&stack0x00000152 + lVar12) | 1;
                    psVar2 = (short *)(&stack0x0000016c + lVar12);
                    *psVar2 = *psVar2 + -1;
                  } while (*psVar2 != 0);
                  uVar41 = *(uint *)(&stack0x00000080 + lVar12);
                  uVar29 = (ulonglong)*(uint *)(&stack0x00000160 + lVar12);
                }
code_r0x00101810:
                if ((*(byte *)puVar32 & 0x40) == 0) {
                  *(undefined4 *)(&stack0x00000176 + lVar12) = 0;
                }
                else {
                  *(uint *)(&stack0x00000176 + lVar12) = uVar40;
                  *(uint *)(&stack0x00000154 + lVar12) = uVar40 + 0xe;
                  *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101838;
                  puVar32 = (ulonglong *)func_0x(&stack0x00000152 + lVar12);
                  uVar29 = *puVar32;
                  uVar25 = (ushort)(uVar29 >> 0x30);
                  uVar20 = uVar25;
                  if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
                    uVar20 = uVar25 & 0xdfff;
                    if ((uVar29 & 0x4000000000000000) != 0) {
                      uVar20 = uVar25 | 0x2000;
                    }
                  }
                  iVar33 = iVar11;
                  if (uVar20 == 0xfffc) {
                    iVar33 = (int)((uVar29 >> 0x20 & 0xffff) >> 5);
                  }
                  uVar41 = *(uint *)(&stack0x00000080 + lVar12);
                  uVar40 = *(int *)(&stack0x00000154 + lVar12) + iVar33;
                  uVar26 = *(uint *)(&stack0x00000168 + lVar12);
                  uVar29 = (ulonglong)*(uint *)(&stack0x00000160 + lVar12);
                  puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                  *(uint *)(&stack0x00000154 + lVar12) = uVar40;
                }
                if ((*(byte **)(&stack0x0000016e + lVar12) != (byte *)0x0) &&
                   (*(byte **)(&stack0x0000016e + lVar12) <
                    (byte *)((ulonglong)uVar40 + (longlong)puVar32))) {
                  if ((cRam000000000146563b != '\0') || ((bRam0000000001475f40 & 1) != 0)) {
                    lVar36 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000009d3ec8 * 8) + 8 +
                              (ulonglong)*puRam00000000009d3ed0);
                    if (((lVar36 != 0) && (lVar36 = *(longlong *)(lVar36 + 0x60), lVar36 != 0)) &&
                       (*(char *)(lVar36 + 0x499) != '\0')) {
                      if ((cRam000000000146552b == '\0') && ((bRam0000000001475f40 & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101959;
                        (*pcRam00000000009d3e68)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar27 + lVar12) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x10197d;
                        (*pcRam00000000009d3e60)(1,0xd56068,0xe75d38,0x877);
                      }
                    }
                    puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101991;
                  func_0x(puVar32,0x12);
                  uVar26 = *(uint *)(&stack0x00000168 + lVar12);
                  uVar29 = (ulonglong)*(uint *)(&stack0x00000160 + lVar12);
                  puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                  uVar40 = *(uint *)(&stack0x00000154 + lVar12);
                  uVar41 = *(uint *)(&stack0x00000080 + lVar12);
                }
                if (0x3f3b < uVar40 - 1) {
                  if ((cRam000000000146563b != '\0') || ((bRam0000000001475f40 & 1) != 0)) {
                    lVar36 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam00000000009d3ec8 * 8) + 8 +
                              (ulonglong)*puRam00000000009d3ed0);
                    if ((lVar36 != 0) &&
                       ((lVar36 = *(longlong *)(lVar36 + 0x60), lVar36 != 0 &&
                        (*(char *)(lVar36 + 0x499) != '\0')))) {
                      if ((cRam000000000146552b == '\0') && ((bRam0000000001475f40 & 2) == 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101a3a;
                        (*pcRam00000000009d3e68)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar27 + lVar12) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101a5e;
                        (*pcRam00000000009d3e60)(1,0xd56068,0xe75d38,0x87c);
                      }
                    }
                    puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101a72;
                  func_0x(puVar32,5);
                  uVar29 = (ulonglong)*(uint *)(&stack0x00000160 + lVar12);
                  puVar32 = *(ulonglong **)(&stack0x00000158 + lVar12);
                  uVar41 = *(uint *)(&stack0x00000080 + lVar12);
                  goto code_r0x00101a83;
                }
              }
              else {
code_r0x00101a83:
                uVar26 = *(uint *)(&stack0x00000168 + lVar12);
              }
code_r0x00101a8a:
              sVar39 = -*(short *)(&stack0x00000080 + lVar12);
              if (((&stack0x00000086)[lVar12] & 0x10) != 0) {
                if ((*(byte *)puVar32 & 0x10) == 0) {
                  if ((1 << (*(byte *)puVar32 & 0xe) & 0x1105U) != 0) {
code_r0x00101324:
                    puVar32 = (ulonglong *)(*(undefined4 **)(&stack0x00000088 + lVar12) + 1);
                    *(undefined4 *)(&stack0x0000007c + lVar12) =
                         **(undefined4 **)(&stack0x00000088 + lVar12);
                    goto code_r0x00101c3c;
                  }
                }
                else {
                  if ((int)uVar29 <= (int)uVar41) goto code_r0x00101324;
                  if (*(ushort *)(uVar29 + (longlong)puVar32) <
                      *(ushort *)(&stack0x00000084 + lVar12)) {
                    puVar32 = (ulonglong *)(*(undefined4 **)(&stack0x00000088 + lVar12) + 1);
                    *(undefined4 *)(&stack0x0000007c + lVar12) =
                         **(undefined4 **)(&stack0x00000088 + lVar12);
                    goto code_r0x00101c3c;
                  }
                }
              }
              if ((uint)(int)sVar39 <= (uint)*(ushort *)(&stack0x0000016c + lVar12)) {
                puVar35 = puVar32;
                uVar41 = uVar26;
                if (sVar39 != 1) {
                  uVar26 = *(ushort *)
                            ((longlong)puVar32 +
                            (longlong)sVar39 * 2 +
                            ((ulonglong)*(uint *)(&stack0x00000164 + lVar12) - 2)) & 0x7fff;
                  puVar35 = *(ulonglong **)(&stack0x00000158 + lVar12);
                  uVar41 = *(uint *)(&stack0x00000168 + lVar12);
                }
                uVar40 = *(ushort *)
                          ((longlong)puVar32 +
                          (longlong)sVar39 * 2 + (ulonglong)*(uint *)(&stack0x00000164 + lVar12)) &
                         0x7fff;
                if ((uVar26 < uVar41) || (uVar40 < uVar26)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101b45;
                  func_0x(puVar35,7);
                  puVar35 = *(ulonglong **)(&stack0x00000158 + lVar12);
                }
                puVar32 = (ulonglong *)((ulonglong)uVar26 + (longlong)puVar35);
                *(uint *)(&stack0x0000007c + lVar12) = uVar40 - uVar26;
                goto code_r0x00101c3c;
              }
            }
            else {
              if (((&stack0x00000086)[lVar12] & 8) != 0) {
                bVar24 = *(byte *)((longlong)(int)uVar41 + (longlong)puVar32);
                puVar32 = (ulonglong *)0xadaaa4;
                *(undefined4 *)(&stack0x0000007c + lVar12) = 1;
                if ((bVar24 & (byte)(1 << ((&stack0x00000086)[lVar12] & 7))) == 0) {
                  puVar32 = (ulonglong *)0xadb0c8;
                }
                goto code_r0x00101c3c;
              }
              if (uVar20 == 0) {
code_r0x00101304:
                puVar32 = (ulonglong *)((longlong)(int)uVar41 + (longlong)puVar32);
                *(undefined4 *)(&stack0x0000007c + lVar12) = 0x1f9e;
                goto code_r0x00101c3c;
              }
              if ((*(byte *)puVar32 & 0x10) == 0) {
                if ((1 << (*(byte *)puVar32 & 0xe) & 0x1105U) == 0) goto code_r0x00101304;
              }
              else if (((int)uVar41 < (int)uVar26) &&
                      (*(ushort *)(&stack0x00000084 + lVar12) <=
                       *(ushort *)(uVar29 + (longlong)puVar32))) goto code_r0x00101304;
              iVar11 = **(int **)(&stack0x00000088 + lVar12);
              puVar32 = (ulonglong *)(*(int **)(&stack0x00000088 + lVar12) + 1);
              if (iVar11 != 0x1f9e) {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar27 + lVar12) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x10137e;
                (*pcRam00000000009d3e60)(1,0xf03dd8,0xf027d8);
                *(int *)(&stack0x0000007c + lVar12) = iVar11;
                goto code_r0x00101c3c;
              }
            }
            *(int *)(&stack0x0000007c + lVar12) = iVar11;
          }
        }
        else {
          *(undefined4 *)(&stack0x00000098 + lVar12) = 0;
          *(undefined **)(&stack0xffffffffffffffe8 + lVar27 + lVar12) = &stack0x00000098 + lVar12;
          *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101bc3;
          puVar32 = (ulonglong *)
                    func_0x(&stack0x00000152 + lVar12,&stack0x00000080 + lVar12);
          if ((((*(short *)(&stack0x00000150 + lVar12) != 0) &&
               (plVar5 = *(longlong **)(&stack0x00000160 + lVar12), plVar5 != (longlong *)0x0)) &&
              (*plVar5 != 0)) &&
             ((((&stack0x00000086)[lVar12] & 8) == 0 &&
              ((*(uint *)(&stack0x00000098 + lVar12) & 1) == 0)))) {
            if ((puVar32 == (ulonglong *)0x0) || (puVar32 == (ulonglong *)0xadaaa4))
            goto code_r0x00101c35;
            *(uint *)((longlong)aiStackX_8 + lVar27 + lVar12 + -8) =
                 *(uint *)(&stack0x00000098 + lVar12);
            *(undefined **)(&stack0xfffffffffffffff8 + lVar27 + lVar12) = &stack0x0000007c + lVar12;
            *(undefined4 *)(&stack0xfffffffffffffff0 + lVar27 + lVar12) =
                 *(undefined4 *)(&stack0x0000009c + lVar12);
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar27 + lVar12) =
                 *(undefined8 *)(&stack0x00000148 + lVar12);
            *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101c30;
            puVar32 = (ulonglong *)func_0x(plVar5,&stack0x00000080 + lVar12,puVar32)
            ;
          }
        }
code_r0x00101c3c:
        if (puVar32 != (ulonglong *)0x0) {
          if ((*(int *)(&stack0x0000007c + lVar12) == 0x10) && (*(short *)puVar32 == 0)) {
            uVar29 = *puVar32;
          }
          else {
            *(ulonglong *)(&stack0x00000120 + lVar12) = (ulonglong)*(uint *)(puVar32 + 1) << 0x10;
            *(undefined2 *)(&stack0x00000120 + lVar12) = 0;
            uVar29 = *(ulonglong *)(&stack0x00000120 + lVar12);
          }
          puVar35 = (ulonglong *)0x0;
          uVar41 = (uint)((longlong)
                          ((ulonglong)(uint)((int)uVar29 >> 0x1f) << 0x20 | uVar29 & 0xffffffff) %
                         (longlong)
                         *(int *)(*(longlong *)(*(longlong *)(&stack0x00000128 + lVar12) + 0x2a8) +
                                 8));
          uVar26 = (int)uVar41 >> 0x1f;
          uVar23 = (longlong)(int)((uVar41 ^ uVar26) - uVar26) * 0x20 +
                   *(longlong *)
                    (*(longlong *)(*(longlong *)(&stack0x00000128 + lVar12) + 0x2a8) + 0x10);
          uVar13 = *(ulonglong *)(uVar23 + 8);
          puVar32 = puVar35;
          if (uVar13 != uVar23) {
            puVar16 = puVar35;
            if (uVar13 != 0) {
              puVar16 = (ulonglong *)(uVar13 - 0x10);
            }
            while (((puVar32 = puVar35, puVar16 != (ulonglong *)0x0 &&
                    (puVar32 = puVar16, *puVar16 != uVar29)) &&
                   (uVar13 = puVar16[3], puVar32 = puVar35, uVar13 != uVar23))) {
              puVar16 = puVar35;
              if (uVar13 != 0) {
                puVar16 = (ulonglong *)(uVar13 - 0x10);
              }
            }
          }
          puVar16 = puVar32 + 1;
          if (puVar32 == (ulonglong *)0x0) {
            puVar16 = puVar35;
          }
          if (puVar16 != (ulonglong *)0x0) goto code_r0x00101d05;
        }
      }
      iVar21 = iVar21 + 1;
    } while( true );
  }
  goto code_r0x00101ec3;
code_r0x00101d05:
  uVar22 = *(undefined4 *)(param_3 + 0x20);
  sVar39 = *(short *)puVar4;
  uVar20 = *(ushort *)(param_3 + 0x24);
  *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101d18;
  uVar17 = (*pcRam00000000009d3de0)();
  *(int *)(&stack0xfffffffffffffff8 + lVar27 + lVar12) = (int)sVar39;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar27 + lVar12) = uVar22;
  *(uint *)(&stack0xffffffffffffffe8 + lVar27 + lVar12) = (uint)uVar20;
  *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101d40;
  func_0x(&stack0x00000318 + lVar12,0x800,0xe38cf0,uVar17);
  lVar36 = 0x800;
  psVar14 = (short *)(&stack0x00000318 + lVar12);
  do {
    if (*psVar14 == 0) break;
    psVar14 = psVar14 + 1;
    lVar36 = lVar36 + -1;
  } while (lVar36 != 0);
  *(uint *)(&stack0x000002b4 + lVar12) = (uint)*(byte *)(param_3 + 1);
  *(int *)(&stack0x000002b0 + lVar12) = iVar21;
  *(ulonglong *)(&stack0x000002d8 + lVar12) = uVar29;
  *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101d7e;
  lVar18 = func_0x();
  lVar6 = *(longlong *)(&stack0x00000128 + lVar12);
  uVar22 = *(undefined4 *)(lVar18 + 0x68);
  *(undefined4 *)(&stack0x00000118 + lVar12) = *(undefined4 *)(param_3 + 0x20);
  lVar18 = *(longlong *)(lVar6 + 0x168);
  *(undefined4 *)(&stack0x000000c0 + lVar12) = uVar22;
  uVar38 = *(undefined2 *)(param_3 + 0x24);
  *(undefined8 *)(&stack0x00000108 + lVar12) = 0;
  iVar11 = 0;
  *(undefined4 *)(&stack0x00000110 + lVar12) = 0;
  *(uint *)(&stack0x00000114 + lVar12) = param_2;
  *(undefined2 *)(&stack0x0000011c + lVar12) = uVar38;
  *(undefined2 *)(&stack0x0000011e + lVar12) = 0;
  lVar18 = *(longlong *)(lVar18 + 8);
  LOCK();
  piVar1 = (int *)(lVar18 + 8);
  iVar21 = *piVar1;
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  uVar41 = *puVar4;
  *(undefined2 *)(&stack0x00000070 + lVar27 + lVar12) = 0;
  *(undefined4 *)(&stack0x00000068 + lVar27 + lVar12) = 0;
  *(undefined8 *)(&stack0x00000060 + lVar27 + lVar12) = 0;
  *(undefined4 *)(&stack0x00000058 + lVar27 + lVar12) = 0;
  *(undefined2 *)(&stack0x00000050 + lVar27 + lVar12) = 1;
  if (lVar36 != 0) {
    iVar11 = 0x800 - (int)lVar36;
  }
  *(undefined **)(&stack0x00000048 + lVar27 + lVar12) = &stack0x00000318 + lVar12;
  *(int *)(&stack0x00000040 + lVar27 + lVar12) = iVar11;
  *(undefined **)(&stack0x00000038 + lVar27 + lVar12) = &stack0x000002d8 + lVar12;
  *(undefined4 *)(&stack0x00000030 + lVar27 + lVar12) = 1;
  *(undefined **)(&stack0x00000028 + lVar27 + lVar12) = &stack0x000002b0 + lVar12;
  *(undefined4 *)((longlong)aiStackX_8 + lVar27 + lVar12 + 0x18) = 2;
  *(int *)((longlong)aiStackX_8 + lVar27 + lVar12 + 0x10) = iVar21 + 1;
  *(undefined4 *)((longlong)aiStackX_8 + lVar27 + lVar12 + 8) = 1;
  *(undefined4 *)((longlong)aiStackX_8 + lVar27 + lVar12) = 0x10;
  *(undefined4 *)((longlong)aiStackX_8 + lVar27 + lVar12 + -8) = 0x22e1;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar27 + lVar12) = 0;
  *(undefined **)(&stack0xfffffffffffffff0 + lVar27 + lVar12) = &stack0x00000108 + lVar12;
  *(undefined **)(&stack0xffffffffffffffe8 + lVar27 + lVar12) = &stack0x000000e0 + lVar12;
  *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101ea1;
  func_0x(lVar18,&stack0x000000c0 + lVar12,&stack0x00000114 + lVar12,uVar41);
  *(undefined8 *)((longlong)&uStack_40 + lVar27 + lVar12) = 0x101eaf;
  func_0x(lVar6,2,&stack0x000000e0 + lVar12);
  uVar13 = *(ulonglong *)(&stack0x00000090 + lVar12);
code_r0x00101ec3:
  uVar20 = *(ushort *)(param_3 + 0x16);
  uVar41 = uVar41 + 1;
  lVar36 = (longlong)(int)uVar41;
  *puVar4 = uVar41;
  if (lVar36 < (longlong)(ulonglong)uVar20) {
    psVar14 = (short *)((0xfff - lVar36) * 2 + param_3);
    do {
      uVar23 = (ulonglong)uVar41;
      if (*psVar14 != 0) goto code_r0x00101f14;
      uVar41 = uVar41 + 1;
      lVar36 = lVar36 + 1;
      psVar14 = psVar14 + -1;
      *puVar4 = uVar41;
    } while (lVar36 < (longlong)(ulonglong)uVar20);
  }
  uVar23 = 0xffffffff;
  *puVar4 = 0xffffffff;
code_r0x00101f14:
  puVar28 = &stack0xffffffffffffffc8 + lVar27 + lVar12;
  if ((int)uVar23 == -1) goto LAB_;
  goto code_r0x00100260;
  while( true ) {
    uVar41 = (int)uVar23 + 1;
    uVar23 = (ulonglong)uVar41;
    uVar13 = uVar13 + 1;
    psVar14 = psVar14 + -1;
    *puVar4 = uVar41;
    puVar28 = &stack0xffffffffffffffc8 + lVar27 + lVar12;
    if ((longlong)(ulonglong)uVar20 <= (longlong)uVar13) break;
LAB_:
    if (*psVar14 != 0) {
      puVar28 = &stack0xffffffffffffffc8 + lVar27 + lVar12;
      if ((int)uVar23 != -1) {
        uVar13 = param_3 + 0x2000;
        if (param_3 == 0) {
          uVar13 = uVar29;
        }
        *(ulonglong *)(&stack0x00000090 + lVar12) = uVar13;
        goto code_r0x00100260;
      }
      break;
    }
  }
LAB_:
  uVar29 = *(ulonglong *)(&stack0x00001318 + lVar12);
  *(undefined8 *)(puVar28 + -8) = 0x101f46;
  func_0x(uVar29 ^ (ulonglong)puVar4);
  return;
}

