
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3,longlong param_4,uint param_5,
                 longlong *param_6,longlong *param_7)

{
  byte bVar1;
  short sVar2;
  longlong lVar3;
  ulonglong *puVar4;
  int iVar5;
  ulonglong uVar6;
  ushort uVar7;
  ushort uVar8;
  uint uVar9;
  ulonglong uVar10;
  ushort *puVar11;
  ushort uVar12;
  ulonglong uVar13;
  uint uVar14;
  ulonglong uVar15;
  byte bVar16;
  uint uVar17;
  ulonglong uVar18;
  longlong unaff_GS_OFFSET;
  undefined auStack_1c8 [32];
  undefined8 uStack_1a8;
  short sStack_198;
  ushort uStack_196;
  uint uStack_194;
  byte *pbStack_190;
  undefined8 uStack_188;
  undefined4 uStack_180;
  ushort uStack_17c;
  undefined2 uStack_17a;
  undefined6 uStack_178;
  undefined2 uStack_172;
  undefined2 uStack_170;
  undefined2 uStack_16e;
  ushort uStack_16c;
  undefined2 uStack_16a;
  undefined4 uStack_168;
  ulonglong uStack_160;
  uint uStack_158;
  longlong lStack_150;
  longlong *plStack_148;
  longlong lStack_140;
  longlong lStack_138;
  undefined auStack_130 [8];
  longlong *plStack_128;
  undefined8 uStack_118;
  undefined4 uStack_110;
  undefined2 uStack_10c;
  ulonglong uStack_38;
  
  uVar14 = CONCAT22(uStack_180._2_2_,(undefined2)uStack_180);
  uStack_38 = _DAT_ ^ (ulonglong)auStack_1c8;
  uVar10 = 0;
  iVar5 = 0;
  uStack_118 = 0;
  *param_6 = 0;
  plStack_128 = param_6;
  *param_7 = 0;
  uVar17 = (uint)*(ushort *)(param_1 + 0x16);
  if ((int)(param_5 * 8) <= (int)(uint)*(ushort *)(param_1 + 0x16)) {
    uVar17 = param_5 * 8;
  }
  plStack_148 = param_7;
  sStack_198 = -1;
  pbStack_190 = (byte *)0x0;
  uStack_194 = 0;
  uStack_17a = 0;
  uStack_178 = 0;
  uStack_170 = 0;
  uStack_16e = 0;
  uStack_16c = 0;
  uStack_16a = 0;
  uStack_188 = 0;
  uStack_110 = 0;
  uStack_10c = 0;
  uStack_160 = (ulonglong)uVar17;
  uVar18 = uVar10;
  lStack_150 = param_4;
  lStack_140 = param_3;
  lStack_138 = param_2;
  if (0 < (int)uVar17) {
    do {
      uVar7 = *(ushort *)(param_1 + (0xfff - uVar18) * 2);
      uStack_158 = (uint)uVar10 + 1;
      if (uVar7 == 0) {
        uStack_158 = (uint)uVar10;
      }
      uVar10 = (ulonglong)uStack_158;
      bVar16 = (byte)uVar18;
      if ((((lStack_138 != 0) && ((*(byte *)(lStack_138 + (uVar18 >> 3)) >> (bVar16 & 7) & 1) != 0))
          || ((param_3 != 0 && ((*(byte *)((uVar18 >> 3) + param_3) >> (bVar16 & 7) & 1) != 0)))) ||
         ((param_4 != 0 && ((*(byte *)((uVar18 >> 3) + param_4) >> (bVar16 & 7) & 1) != 0)))) {
        bVar16 = bVar16 & 7;
        uVar10 = uVar18 >> 3;
        uVar17 = (uint)*(ushort *)(param_1 + 0xe);
        pbStack_190 = (byte *)((ulonglong)uVar7 + param_1);
        if ((*pbStack_190 & 1) == 0) {
          sStack_198 = 0;
          uStack_194 = 0;
          uStack_172 = 0;
          uStack_170 = 0;
          switch(*pbStack_190 & 0xe) {
          default:
            uVar17 = (uint)*(ushort *)(pbStack_190 + 2);
            if (0x1f9d < *(ushort *)(pbStack_190 + 2) - 1) {
              uStack_180 = uVar14;
              func_0x(pbStack_190,6);
              uVar14 = uStack_180;
            }
            break;
          case 4:
            uVar17 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar17 = 1;
          }
          uStack_188 = CONCAT44(uStack_188._4_4_,uVar17);
          lVar3 = param_1 + 0x2000;
          if (param_1 == 0) {
            lVar3 = 0;
          }
          uStack_17a = (undefined2)lVar3;
          uStack_178 = (undefined6)((ulonglong)lVar3 >> 0x10);
        }
        else {
          sStack_198 = 1;
          bVar1 = *pbStack_190;
          switch(bVar1 & 0x1c) {
          default:
            if ((char)pbStack_190[1] < '\0') {
              sVar2 = 3;
              uStack_180._0_2_ = 3;
              uStack_196 = (*(ushort *)(pbStack_190 + 1) & 0x7f) << 8 |
                           *(ushort *)(pbStack_190 + 1) >> 8;
            }
            else {
              uStack_196 = (ushort)pbStack_190[1];
              sVar2 = 2;
              uStack_180._0_2_ = 2;
            }
            uStack_17c = (short)(uStack_196 + 1 >> 1) + sVar2;
            if (uStack_196 < 0x1f) {
              uStack_180._2_2_ = 0;
              uStack_194 = 0;
              uStack_168 = 0;
            }
            else {
              iVar5 = uStack_196 - 1;
              uStack_194 = 0;
              uStack_168 = 0;
              uStack_180._2_2_ =
                   ((short)(iVar5 / 0x1e) + (short)(iVar5 >> 0x1f)) -
                   (short)((longlong)iVar5 * 0x88888889 >> 0x3f);
            }
            break;
          case 4:
            if (((bVar1 & 0x1c) == 4) && ((bVar1 & 2) != 0)) {
              uStack_180._0_2_ = 0;
              uStack_180._2_2_ = 0;
              uStack_17c = 0;
              uStack_17a = 0;
              uStack_196 = 0;
              uStack_178 = 0;
              uStack_172 = 0;
              uStack_194 = 0xf;
              uStack_168 = 1;
            }
            else {
              uStack_180._0_2_ = 0;
              uStack_180._2_2_ = 0;
              uStack_17c = 0;
              uStack_17a = 0;
              uStack_196 = 0;
              uStack_178 = 0;
              uStack_172 = 0;
              uStack_194 = 1;
              uStack_168 = 0;
            }
            break;
          case 8:
            uStack_180._0_2_ = 0;
            uStack_180._2_2_ = 0;
            uStack_17c = 0;
            uStack_17a = 0;
            uStack_196 = 0;
            uStack_178 = 0;
            uStack_172 = 0;
            uStack_194 = 9;
            uStack_168 = 0;
          }
          uVar14 = CONCAT22(uStack_180._2_2_,(undefined2)uStack_180);
          uStack_188 = 0;
          lVar3 = param_1 + 0x2000;
          if (param_1 == 0) {
            lVar3 = 0;
          }
          uStack_170 = (undefined2)lVar3;
          uStack_16e = (undefined2)((ulonglong)lVar3 >> 0x10);
          uStack_16c = (ushort)((ulonglong)lVar3 >> 0x20);
          uStack_16a = (undefined2)((ulonglong)lVar3 >> 0x30);
        }
        uStack_180 = uVar14;
        if (sStack_198 == 0) {
          uVar17 = func_0x(&uStack_196);
        }
        else {
          uVar17 = uStack_194;
          if (uStack_194 == 0) {
            func_0x(&uStack_196);
            uVar17 = uStack_194;
          }
        }
        if (sStack_198 == 0) {
          func_0x();
          uVar14 = uStack_180;
        }
        else {
          func_0x(&uStack_196,auStack_130);
          uVar14 = uStack_180;
        }
        if ((lStack_150 == 0) || ((*(byte *)(uVar10 + lStack_150) >> bVar16 & 1) == 0)) {
          uStack_180 = uVar14;
          if ((lStack_140 == 0) || ((*(byte *)(lStack_140 + uVar10) >> bVar16 & 1) == 0)) {
            if ((lStack_138 == 0) || ((*(byte *)(lStack_138 + uVar10) >> bVar16 & 1) == 0)) {
              uStack_1a8 = 0;
              (*_DAT_)(1,0x14d8760,0x14a3978,0xd63);
              uVar14 = uStack_180;
            }
          }
          else {
            func_0x(&sStack_198,(byte)(*(char *)(param_1 + 1) - 3U) < 2);
            *plStack_128 = *plStack_128 + 1;
            *(short *)(param_1 + 0x3a) = *(short *)(param_1 + 0x3a) + -1;
            uVar14 = uStack_180;
          }
          uStack_180 = uVar14;
          if (sStack_198 == 0) {
            func_0x();
          }
          else {
            func_0x(&uStack_196,&uStack_118);
          }
          uVar10 = (ulonglong)uStack_194;
          uVar7 = (short)(1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1;
          uVar14 = uStack_180;
          if (sStack_198 == 0) {
            if (uStack_194 == 0) {
              uVar10 = uStack_188 & 0xffffffff;
              uStack_196 = 0;
              uVar14 = (uint)uStack_188;
              if ((*pbStack_190 & 0x10) != 0) {
                uVar14 = (uint)uStack_188 + 2 + (*(ushort *)(pbStack_190 + uVar10) + 7 >> 3);
                uVar10 = (ulonglong)uVar14;
              }
              uStack_188 = CONCAT44(uVar14,(uint)uStack_188);
              uVar14 = (uint)uVar10;
              if ((*pbStack_190 & 0x20) == 0) {
                uStack_17c = 0;
                uStack_194 = uVar14;
              }
              else {
                puVar11 = (ushort *)(pbStack_190 + uVar10);
                uStack_17c = *puVar11;
                uVar15 = uVar10;
                if (uStack_17c == 0) {
                  if ((((cRam0000000001a2dffb != '\0') || ((bRam0000000001a3e900 & 1) != 0)) &&
                      (lVar3 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam0000000000f9c888 * 8) + 8 +
                                (ulonglong)*puRam0000000000f9c890), lVar3 != 0)) &&
                     ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                      (*(char *)(lVar3 + 0x499) != '\0')))) {
                    if ((cRam0000000001a2deeb == '\0') && ((bRam0000000001a3e900 & 2) == 0)) {
                      (*pcRam0000000000f9c828)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_1a8 = 0;
                      (*_DAT_)(1,0x131ea28,0x143e6f8,0x80f);
                    }
                  }
                  func_0x(pbStack_190,3);
                  uVar15 = uStack_188 >> 0x20;
                }
                uStack_180 = (int)uVar15 + (uStack_17c + 1) * 2;
                if (0x1f9e < uStack_180) {
                  if (((cRam0000000001a2dffb != '\0') || ((bRam0000000001a3e900 & 1) != 0)) &&
                     ((lVar3 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam0000000000f9c888 * 8) + 8 +
                                (ulonglong)*puRam0000000000f9c890), lVar3 != 0 &&
                      ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                       (*(char *)(lVar3 + 0x499) != '\0')))))) {
                    if ((cRam0000000001a2deeb == '\0') && ((bRam0000000001a3e900 & 2) == 0)) {
                      (*pcRam0000000000f9c828)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_1a8 = 0;
                      (*_DAT_)(1,0x131ea28,0x143e6f8,0x816);
                    }
                  }
                  func_0x(pbStack_190,4);
                  uVar15 = uStack_188 >> 0x20;
                }
                uVar13 = (ulonglong)uStack_17c;
                uStack_194 = puVar11[uVar13] & 0x7fff;
                uVar10 = (ulonglong)uStack_194;
                uVar14 = uStack_180;
                if (uStack_194 < uStack_180) {
                  if ((((cRam0000000001a2dffb != '\0') || ((bRam0000000001a3e900 & 1) != 0)) &&
                      (lVar3 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam0000000000f9c888 * 8) + 8 +
                                (ulonglong)*puRam0000000000f9c890), lVar3 != 0)) &&
                     ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                      (*(char *)(lVar3 + 0x499) != '\0')))) {
                    if ((cRam0000000001a2deeb == '\0') && ((bRam0000000001a3e900 & 2) == 0)) {
                      (*pcRam0000000000f9c828)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_1a8 = 0;
                      (*_DAT_)(1,0x131ea28,0x143e6f8,0x81d);
                    }
                  }
                  func_0x(pbStack_190,4);
                  uVar13 = (ulonglong)uStack_17c;
                  uVar15 = uStack_188 >> 0x20;
                  uVar10 = (ulonglong)uStack_194;
                  uVar14 = uStack_180;
                }
                do {
                  if (-1 < (short)puVar11[(ulonglong)((int)uVar13 - 1) + 1]) break;
                  if ((int)uVar13 == 1) {
                    uVar6 = 1;
                    uVar9 = uStack_180;
code_r0x0010081b:
                    if ((*(ushort *)(pbStack_190 + uVar6 * 2 + uVar15) & 0x7fff) < uVar9)
                    goto code_r0x00100828;
                  }
                  else {
                    uVar9 = *(ushort *)(pbStack_190 + uVar13 * 2 + (uVar15 - 2)) & 0x7fff;
                    uVar6 = uVar13;
                    if (uStack_180 <= uVar9) goto code_r0x0010081b;
code_r0x00100828:
                    uStack_180 = uVar14;
                    func_0x(pbStack_190,7);
                    uVar13 = (ulonglong)uStack_17c;
                    uVar15 = uStack_188 >> 0x20;
                    uVar10 = (ulonglong)uStack_194;
                    uVar14 = uStack_180;
                  }
                  if ((uVar9 < uStack_180) || ((uint)uVar10 < uVar9)) goto code_r0x00100b5e;
                  if (*(ushort *)(pbStack_190 + uVar9) == 5) {
                    uStack_196 = uStack_196 | 2;
                    uStack_17c = (short)uVar13 - 1;
                    uStack_16e = (undefined2)uVar9;
                    if ((*(ushort *)(pbStack_190 + (ulonglong)(uVar9 & 0xffff) + 2) & 0x4000) == 0)
                    {
                      uStack_16c = uStack_16c & 0xc7ff;
                    }
                    else {
                      uStack_16c = uStack_16c ^
                                   (*(ushort *)(pbStack_190 + (ulonglong)(uVar9 & 0xffff) + 2) ^
                                   uStack_16c) & 0x3800;
                    }
                    uStack_16c = uStack_16c ^
                                 (uStack_16c ^
                                 *(ushort *)(pbStack_190 + (ulonglong)(uVar9 & 0xffff) + 2)) & 0x7ff
                    ;
                    break;
                  }
                  if (*(ushort *)(pbStack_190 + uVar9) < 0x400) break;
                  uStack_196 = uStack_196 | 1;
                  uStack_17c = (short)uVar13 - 1;
                  uVar13 = (ulonglong)uStack_17c;
                } while (uStack_17c != 0);
              }
              iVar5 = 0;
              if ((*pbStack_190 & 0x40) == 0) {
                uStack_172 = 0;
                uStack_170 = 0;
              }
              else {
                uStack_172 = (undefined2)uVar10;
                uStack_170 = (undefined2)(uVar10 >> 0x10);
                uStack_194 = (int)uVar10 + 0xe;
                uStack_180 = uVar14;
                puVar4 = (ulonglong *)func_0x(&uStack_196);
                uVar10 = *puVar4;
                uVar12 = (ushort)(uVar10 >> 0x30);
                uVar8 = uVar12;
                if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
                  uVar8 = uVar12 & 0xdfff;
                  if ((uVar10 & 0x4000000000000000) != 0) {
                    uVar8 = uVar12 | 0x2000;
                  }
                }
                if (uVar8 == 0xfffc) {
                  iVar5 = (int)((uVar10 >> 0x20 & 0xffff) >> 5);
                }
                uStack_194 = uStack_194 + iVar5;
                uVar10 = (ulonglong)uStack_194;
                uVar14 = uStack_180;
              }
              uStack_180 = uVar14;
              if (((byte *)CONCAT62(uStack_178,uStack_17a) != (byte *)0x0) &&
                 ((byte *)CONCAT62(uStack_178,uStack_17a) < pbStack_190 + uVar10)) {
                if (((cRam0000000001a2dffb != '\0') || ((bRam0000000001a3e900 & 1) != 0)) &&
                   (((lVar3 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000f9c888 * 8) + 8 +
                               (ulonglong)*puRam0000000000f9c890), lVar3 != 0 &&
                     (lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0)) &&
                    (*(char *)(lVar3 + 0x499) != '\0')))) {
                  if ((cRam0000000001a2deeb == '\0') && ((bRam0000000001a3e900 & 2) == 0)) {
                    (*pcRam0000000000f9c828)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_1a8 = 0;
                    (*_DAT_)(1,0x131ea28,0x143e6f8,0x877);
                  }
                }
                func_0x(pbStack_190,0x12);
                uVar10 = (ulonglong)uStack_194;
              }
              uVar14 = uStack_180;
              if (0x3f3b < (int)uVar10 - 1U) {
                if (((cRam0000000001a2dffb != '\0') || ((bRam0000000001a3e900 & 1) != 0)) &&
                   ((lVar3 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam0000000000f9c888 * 8) + 8 +
                              (ulonglong)*puRam0000000000f9c890), lVar3 != 0 &&
                    ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                     (*(char *)(lVar3 + 0x499) != '\0')))))) {
                  if ((cRam0000000001a2deeb == '\0') && ((bRam0000000001a3e900 & 2) == 0)) {
                    (*pcRam0000000000f9c828)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_1a8 = 0;
                    (*_DAT_)(1,0x131ea28,0x143e6f8,0x87c);
                  }
                }
                func_0x(pbStack_190,5);
                uVar10 = (ulonglong)uStack_194;
                uVar14 = uStack_180;
              }
            }
code_r0x00100b5e:
            uVar9 = (uint)uVar10;
            if ((uVar9 < 9) && (((*pbStack_190 & 0xe) == 0 || ((*pbStack_190 & 0xe) == 0xc)))) {
              uVar9 = 9;
            }
          }
          else {
            if (uStack_194 == 0) {
              func_0x(&uStack_196);
              uVar14 = uStack_180;
            }
            uVar9 = uStack_194;
            if ((uStack_194 < 9) && (((*pbStack_190 & 0x1c) == 0 || ((*pbStack_190 & 0x1c) == 0xc)))
               ) {
              uVar9 = 9;
            }
          }
          uVar8 = (1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1;
          uVar7 = ((short)uVar17 + uVar7 & ~uVar7) - ((short)uVar9 + uVar8 & ~uVar8);
        }
        else {
          uVar7 = (1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1;
          *(undefined2 *)(param_1 + (0xfff - uVar18) * 2) = 0;
          uVar7 = (short)uVar17 + uVar7 & ~uVar7;
          *plStack_148 = *plStack_148 + 1;
        }
        *(short *)(param_1 + 0x1c) = *(short *)(param_1 + 0x1c) + uVar7;
        uVar10 = (ulonglong)uStack_158;
        param_3 = lStack_140;
        param_4 = lStack_150;
        param_7 = plStack_148;
      }
      iVar5 = (int)uVar10;
      uVar17 = (int)uVar18 + 1;
      uVar18 = (ulonglong)uVar17;
    } while ((int)uVar17 < (int)uStack_160);
    if (0 < *param_7) {
      uVar17 = (uint)*(ushort *)(param_1 + 0x16);
      while (uVar17 = uVar17 - 1, -1 < (int)uVar17) {
        if (*(short *)(param_1 + (0xfff - (longlong)(int)uVar17) * 2) == 0) {
          uVar7 = *(ushort *)(param_1 + 0x16);
          uStack_180 = uVar14;
          func_0x
                    (param_1 + (0x1001 - (ulonglong)uVar7) * 2,
                     param_1 + (0x1000 - (longlong)(int)(uint)uVar7) * 2,(uVar7 - uVar17) * 2 + -2);
          *(short *)(param_1 + 0x16) = *(short *)(param_1 + 0x16) + -1;
          *(short *)(param_1 + 0x1c) = *(short *)(param_1 + 0x1c) + 2;
          uVar14 = uStack_180;
        }
      }
    }
  }
  uStack_180 = uVar14;
  if (param_5 < iVar5 + 7U >> 3) {
    uStack_1a8 = 0;
    (*_DAT_)(1,0x14d8798,0x14a3978,0xda6);
  }
  func_0x(param_1,0xffffffff);
  func_0x(uStack_38 ^ (ulonglong)auStack_1c8);
  return;
}

