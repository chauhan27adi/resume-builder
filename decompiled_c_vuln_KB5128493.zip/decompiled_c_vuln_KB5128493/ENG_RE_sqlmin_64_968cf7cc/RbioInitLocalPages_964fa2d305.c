
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,ulonglong param_3,longlong param_4,
                 short param_5,undefined8 *param_6,undefined *param_7)

{
  byte *pbVar1;
  ushort uVar2;
  short sVar3;
  undefined8 *puVar4;
  char cVar5;
  int iVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  undefined8 uVar10;
  undefined4 *puVar11;
  longlong lVar12;
  longlong lVar13;
  short *psVar14;
  code *UNRECOVERED_JUMPTABLE_00;
  int iVar15;
  undefined4 uVar16;
  ulonglong uVar17;
  byte **ppbVar18;
  ulonglong uVar19;
  undefined4 auStackX_8 [2];
  undefined auStackX_10 [8];
  undefined auStackX_18 [8];
  undefined auStackX_20 [8];
  short sStack_8f88;
  undefined4 uStack_8f84;
  short sStack_8f80;
  ushort uStack_8f72;
  undefined4 uStack_8f68;
  undefined2 uStack_8f64;
  int iStack_8f60;
  int iStack_8f5c;
  undefined8 *puStack_8f38;
  undefined8 uStack_8f30;
  undefined2 uStack_8f28;
  undefined8 uStack_8f00;
  ulonglong uStack_8ef8;
  longlong *plStack_8ef0;
  undefined8 uStack_8ed8;
  ulonglong uStack_8ed0;
  undefined *puStack_8ec8;
  longlong *plStack_8ec0;
  undefined8 uStack_8eb8;
  undefined auStack_8ea8 [8];
  undefined4 uStack_8ea0;
  undefined4 uStack_8e98;
  undefined4 **ppuStack_8e90;
  undefined *puStack_8e88;
  undefined8 uStack_8e80;
  undefined4 *puStack_8e78;
  undefined4 uStack_8e70;
  undefined4 uStack_8e6c;
  undefined4 *puStack_8e68;
  undefined4 uStack_8e60;
  undefined4 uStack_8e5c;
  undefined4 *puStack_8e58;
  undefined4 uStack_8e50;
  undefined4 uStack_8e4c;
  undefined4 *puStack_8e48;
  undefined4 uStack_8e40;
  undefined4 uStack_8e3c;
  longlong lStack_8e38;
  int iStack_8e30;
  undefined4 uStack_8e2c;
  undefined auStack_8e28 [464];
  undefined8 uStack_8c58;
  undefined8 uStack_8c50;
  undefined4 auStack_8c48 [12];
  undefined auStack_8c18 [8];
  undefined4 uStack_8c10;
  undefined4 uStack_8c08;
  short **ppsStack_8c00;
  undefined *puStack_8bf8;
  undefined8 uStack_8bf0;
  short *psStack_8be8;
  undefined4 uStack_8be0;
  undefined4 uStack_8bdc;
  short *psStack_8bd8;
  int iStack_8bd0;
  undefined4 uStack_8bcc;
  undefined auStack_8bc8 [512];
  undefined8 uStack_89c8;
  undefined8 uStack_89c0;
  short asStack_89b8 [8];
  short sStack_89a8;
  undefined4 uStack_89a4;
  byte *pbStack_89a0;
  byte **ppbStack_8998;
  undefined8 uStack_898a;
  undefined2 uStack_8982;
  undefined2 uStack_8980;
  undefined6 uStack_897e;
  undefined4 uStack_8974;
  undefined auStack_8970 [16];
  undefined auStack_8960 [8];
  undefined8 uStack_8958;
  undefined8 uStack_8950;
  undefined6 uStack_8948;
  undefined2 uStack_8942;
  undefined6 uStack_8940;
  undefined2 uStack_893a;
  undefined8 uStack_8938;
  undefined auStack_8930 [16];
  undefined auStack_8920 [16];
  undefined auStack_8910 [16];
  undefined8 uStack_8900;
  undefined4 uStack_88f8;
  undefined4 uStack_88f4;
  undefined4 uStack_88f0;
  undefined4 uStack_88ec;
  undefined4 uStack_88e8;
  undefined4 uStack_88e4;
  undefined4 uStack_88e0;
  undefined4 uStack_88dc;
  undefined4 uStack_88d8;
  undefined4 uStack_88d4;
  undefined4 uStack_88d0;
  undefined4 uStack_88cc;
  undefined auStack_88b8 [348];
  undefined8 uStack_875c;
  undefined2 uStack_8754;
  ushort uStack_8732;
  undefined auStack_81b8 [16];
  undefined auStack_81a8 [16];
  undefined auStack_8198 [16];
  undefined auStack_8188 [16];
  undefined8 uStack_8178;
  undefined4 uStack_8170;
  undefined2 uStack_816c;
  short asStack_8168 [4231];
  undefined auStack_6059 [16384];
  undefined auStack_2059 [8193];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar7 = func_0x();
  sVar3 = param_5;
  lVar7 = -lVar7;
  uStack_8eb8 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar7);
  sStack_8f88 = param_5;
  puStack_8f38 = param_6;
  puStack_8ec8 = param_7;
  iVar15 = 0;
  iStack_8f5c = 0;
  iStack_8f60 = 0;
  sStack_89a8 = -1;
  pbStack_89a0 = (byte *)0x0;
  uStack_89a4 = 0;
  uStack_898a = 0;
  uStack_8980 = 0;
  uStack_897e = 0;
  ppbStack_8998 = (byte **)0x0;
  uStack_8f72 = uStack_8f72 & 0xffe0;
  *param_7 = 0;
  uVar17 = (ulonglong)auStack_6059 & 0xffffffffffffe000;
  uVar19 = (ulonglong)auStack_2059 & 0xffffffffffffe000;
  param_3 = param_3 & 0xffffffff;
  uStack_8f00 = param_1;
  uStack_8ef8 = param_3;
  uStack_8ed8 = param_2;
  uStack_8ed0 = uVar17;
  if ((_DAT_ & 0x20000) != 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100102;
    iVar6 = (*_DAT_)(asStack_8168,0x81,param_2,param_3 >> 1);
    if (iVar6 != 0) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100128;
      (*_DAT_)(1,0x160a5a0,0x15e67f8,0x1933);
    }
    uStack_8c10 = 0x20000;
    uStack_8c08 = 0;
    ppsStack_8c00 = &psStack_8be8;
    puStack_8bf8 = auStack_8bc8;
    uStack_89c8 = 0;
    uStack_8bf0 = 0;
    uStack_89c0 = 0;
    psStack_8be8 = asStack_89b8;
    uStack_8be0 = 10;
    uStack_8bdc = 1;
    asStack_89b8[0] = sVar3;
    lVar8 = -1;
    do {
      lVar8 = lVar8 + 1;
    } while (asStack_8168[lVar8] != 0);
    iStack_8bd0 = (int)lVar8 * 2;
    psStack_8bd8 = asStack_8168;
    uStack_8bcc = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1001d5;
    func_0x(auStack_8c18);
  }
  uVar16 = 0;
  if (sVar3 == 2) {
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100404;
    lVar8 = (*_DAT_)(param_2,2);
    if (lVar8 == 0) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100434;
      (*_DAT_)(1,0x1618748,0x15e67f8,0x198d);
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100445;
    puVar11 = (undefined4 *)(*_DAT_)(lVar8);
    uStack_88e8 = *puVar11;
    uStack_88e4 = puVar11[1];
    uStack_88e0 = puVar11[2];
    uStack_88dc = puVar11[3];
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100458;
    puVar11 = (undefined4 *)(*_DAT_)(lVar8);
    uStack_88d8 = *puVar11;
    uStack_88d4 = puVar11[1];
    uStack_88d0 = puVar11[2];
    uStack_88cc = puVar11[3];
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10046b;
    lVar13 = (*_DAT_)(lVar8);
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100477;
    puVar11 = (undefined4 *)(*_DAT_)(lVar8);
    uStack_88f8 = *puVar11;
    uStack_88f4 = puVar11[1];
    uStack_88f0 = puVar11[2];
    uStack_88ec = puVar11[3];
    auStack_81b8 = ZEXT816(0);
    auStack_81a8 = ZEXT816(0);
    auStack_8198 = ZEXT816(0);
    auStack_8188 = ZEXT816(0);
    uStack_8178 = 0;
    uStack_8170 = 0;
    uStack_816c = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1004ce;
    iVar6 = (*_DAT_)(&uStack_88f8,auStack_81b8,0x27);
    if (iVar6 < 1) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1004f4;
      (*_DAT_)(1,0x15f8ea0,0x15e9a80,0x36);
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100507;
    func_0x(0x14846c0,auStack_81b8);
    if ((_DAT_ & 0x100000) != 0) {
      uStack_8ea0 = 0x50000;
      uStack_8e98 = 0;
      ppuStack_8e90 = &puStack_8e78;
      puStack_8e88 = auStack_8e28;
      uStack_8c58 = 0;
      uStack_8e80 = 0;
      uStack_8c50 = 0;
      puStack_8e78 = auStack_8c48;
      uStack_8e70 = 0x24;
      uStack_8e6c = 4;
      auStack_8c48[0] = 2;
      puStack_8e68 = &uStack_88f8;
      uStack_8e60 = 0x10;
      uStack_8e5c = 1;
      puStack_8e58 = &uStack_88e8;
      uStack_8e50 = 0x10;
      uStack_8e4c = 2;
      puStack_8e48 = &uStack_88d8;
      uStack_8e40 = 0x10;
      uStack_8e3c = 3;
      if (lVar13 != 0) {
        lVar12 = -1;
        do {
          lVar12 = lVar12 + 1;
        } while (*(short *)(lVar13 + lVar12 * 2) != 0);
        iVar15 = (int)lVar12 * 2;
      }
      uStack_8e2c = 4;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10061f;
      lStack_8e38 = lVar13;
      iStack_8e30 = iVar15;
      func_0x(auStack_8ea8);
    }
    *(undefined4 *)(&stack0x00000048 + lVar7) = 1;
    *(undefined8 *)(&stack0x00000040 + lVar7) = 0;
    *(int **)((longlong)&param_7 + lVar7) = &iStack_8f60;
    *(ulonglong *)((longlong)&param_6 + lVar7) = uVar19;
    *(undefined4 *)((longlong)&param_5 + lVar7) = 0x2000;
    auStackX_20[lVar7] = 0;
    auStackX_18[lVar7] = 0;
    auStackX_10[lVar7] = 0;
    *(undefined *)((longlong)auStackX_8 + lVar7) = 3;
    *(undefined8 *)(auStackX_20 + lVar7 + -0x20) = 0xffffffffffffffff;
    *(undefined4 **)(&stack0xfffffffffffffff8 + lVar7) = &uStack_88f8;
    (&stack0xfffffffffffffff0)[lVar7] = 0;
    *(undefined2 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar7) = 0xffffffff;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100693;
    iStack_8f5c = (*_DAT_)(lVar8,0xffffffffffffffff,0xffffffff);
    if (iStack_8f5c < 0) {
      lVar8 = -1;
      do {
        lVar8 = lVar8 + 1;
      } while (*(short *)(param_4 + lVar8 * 2) != 0);
      *(int *)(&stack0xfffffffffffffff0 + lVar7) = iStack_8f5c;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar7) = param_4;
      *(int *)(&stack0xffffffffffffffe0 + lVar7) = (int)lVar8 * 2;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1006d3;
      (*_DAT_)(0x5a,0x25,0x10,1);
    }
    if (iStack_8f60 != 0x2000) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1006fa;
      (*_DAT_)(1,0x16186f8,0x15e67f8,0x19cc);
    }
  }
  else {
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1001fb;
    plVar9 = (longlong *)func_0x(uStack_8f00,param_4,0);
    lVar8 = -1;
    do {
      lVar8 = lVar8 + 1;
    } while (*(short *)(param_4 + lVar8 * 2) != 0);
    lVar13 = *plVar9;
    *(undefined4 *)((longlong)auStackX_8 + lVar7) = 1;
    plStack_8ec0 = plVar9;
    *(undefined4 *)(auStackX_20 + lVar7 + -0x20) = 0x2000;
    *(ulonglong *)(&stack0xfffffffffffffff8 + lVar7) = lVar8 * 2 & 0xffffffff;
    *(longlong *)(&stack0xfffffffffffffff0 + lVar7) = param_4;
    *(ulonglong *)(&stack0xffffffffffffffe8 + lVar7) = param_3;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = param_2;
    UNRECOVERED_JUMPTABLE_00 = *(code **)(lVar13 + 0x68);
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10025f;
    (*UNRECOVERED_JUMPTABLE_00)(plVar9,0,0,sStack_8f88);
    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar9 + 0x50);
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100268;
    (*UNRECOVERED_JUMPTABLE_00)(plVar9);
    puVar4 = puStack_8f38;
    if (sStack_8f88 == 1) {
      if ((((puStack_8f38 == (undefined8 *)0x0) || (*(short *)(puStack_8f38 + 1) != 0)) ||
          (*(int *)puStack_8f38 != 0)) || (*(int *)((longlong)puStack_8f38 + 4) != 0)) {
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1002b5;
        (*_DAT_)(1,0x1618710,0x15e67f8,0x1957);
      }
      uStack_8f84 = 9;
      sStack_8f80 = 1;
      if (DAT_ == '\0') {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100307;
        func_0x(plVar9,0,uVar17,&uStack_8f84);
        if (((puVar4 == (undefined8 *)0x0) || (*(short *)(puVar4 + 1) != 0)) ||
           ((*(int *)puVar4 != 0 || (*(int *)((longlong)puVar4 + 4) != 0)))) {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100345;
          (*_DAT_)(1,0x1618710,0x15e67f8,0x196e);
        }
        uVar2 = *(ushort *)(uVar17 + 0x1ffe);
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100361;
        func_0x(auStack_88b8,uVar2 + uVar17,0x6fa);
        *puVar4 = uStack_875c;
        *(undefined2 *)(puVar4 + 1) = uStack_8754;
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1002da;
        uVar10 = (*_DAT_)(plVar9,9);
        *(undefined8 **)(&stack0xffffffffffffffe0 + lVar7) = puVar4;
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1002f3;
        func_0x(uVar10,param_4,0x4000,uVar17);
      }
    }
    if (((*(short *)(puVar4 + 1) == 0) && (*(int *)puVar4 == 0)) &&
       (*(int *)((longlong)puVar4 + 4) == 0)) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1003b3;
      (*_DAT_)(1,0x1618730,0x15e67f8,0x197c);
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1003bf;
    (*_DAT_)(plVar9,puVar4);
    uStack_8f84 = 0;
    sStack_8f80 = sStack_8f88;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1003d9;
    func_0x(plVar9,0,uVar19,&uStack_8f84);
    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar9 + 0x40);
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1003e2;
    (*UNRECOVERED_JUMPTABLE_00)(plVar9);
    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar9 + 0xb0);
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1003f4;
    (*UNRECOVERED_JUMPTABLE_00)(plVar9,1);
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100703;
  uVar10 = (*_DAT_)(param_4);
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100712;
  plVar9 = (longlong *)func_0x(uStack_8f00,uVar10,0);
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100722;
  plStack_8ef0 = plVar9;
  lVar13 = (*_DAT_)(param_4);
  lVar8 = -1;
  do {
    lVar8 = lVar8 + 1;
  } while (*(short *)(lVar13 + lVar8 * 2) != 0);
  lVar13 = *plVar9;
  if (sStack_8f88 == 2) {
    uVar16 = 0x40;
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100761;
  uVar10 = (*_DAT_)(param_4);
  *(undefined4 *)((longlong)auStackX_8 + lVar7) = 1;
  *(undefined4 *)(auStackX_20 + lVar7 + -0x20) = uVar16;
  *(ulonglong *)(&stack0xfffffffffffffff8 + lVar7) = lVar8 * 2 & 0xffffffff;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar7) = uVar10;
  *(ulonglong *)(&stack0xffffffffffffffe8 + lVar7) = uStack_8ef8;
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = uStack_8ed8;
  UNRECOVERED_JUMPTABLE_00 = *(code **)(lVar13 + 0x68);
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10079b;
  (*UNRECOVERED_JUMPTABLE_00)(plVar9,0,0,sStack_8f88);
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar9 + 0x50);
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1007a5;
  (*UNRECOVERED_JUMPTABLE_00)(plVar9);
  if (sStack_8f88 == 1) {
    lVar8 = *(ushort *)(uStack_8ed0 + 0x1ffe) + uStack_8ed0;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1007d4;
    func_0x(auStack_88b8,lVar8,0x6fa);
    uStack_8732 = uStack_8732 | 6;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1007f1;
    func_0x(lVar8,auStack_88b8,0x6fa);
    uStack_8f84 = 9;
    sStack_8f80 = 1;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100814;
    func_0x(plVar9);
  }
  if ((*(int *)(uVar19 + 0x20) != 0) || (*(char *)(uVar19 + 1) != '\x0f')) {
    lVar8 = -1;
    do {
      lVar8 = lVar8 + 1;
    } while (*(short *)(param_4 + lVar8 * 2) != 0);
    *(int *)(&stack0xfffffffffffffff0 + lVar7) = iStack_8f5c;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar7) = param_4;
    *(int *)(&stack0xffffffffffffffe0 + lVar7) = (int)lVar8 * 2;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100866;
    (*_DAT_)(0x5a,0x25,0x10,2);
  }
  uStack_8974 = 0;
  if (-1 < *(char *)(uVar19 + 2)) goto LAB_;
  pbVar1 = (byte *)(uVar19 + 0x60);
  if ((sStack_89a8 == 0) || (ppbVar18 = ppbStack_8998, ppbStack_8998 == (byte **)0x0)) {
    uStack_8948 = 0;
    uStack_893a = 0;
    auStack_8920 = ZEXT816(0);
    auStack_8970 = ZEXT816(0);
    stack0xffffffffffff76a2 = SUB1614(ZEXT816(0),2);
    auStack_8960._0_2_ = 0xffff;
    uStack_8958 = 0;
    uStack_8942 = 0;
    uStack_8940 = 0;
    uStack_8938 = 0;
    uStack_8950 = 0;
    auStack_8930 = ZEXT816(0);
    auStack_8910._0_12_ = ZEXT812(0);
    auStack_8910._12_4_ = 0;
    uStack_8900 = 0;
    ppbVar18 = (byte **)auStack_8970;
  }
  if (*(short *)(uVar19 + 0x24) == 0) {
LAB_:
    uStack_8f30 = *(undefined8 *)(uVar19 + 0x28);
    uStack_8f28 = *(undefined2 *)(uVar19 + 0x30);
  }
  else {
    cVar5 = *(char *)(uVar19 + 1);
    if (cVar5 == '\v') {
      if (*(int *)(uVar19 + 0x18) != 99) {
LAB_:
        if (cVar5 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar5 != '\b') goto LAB_;
LAB_:
      if (*(int *)(uVar19 + 0x18) != 99) goto LAB_;
    }
    uStack_8f68 = *(undefined4 *)(uVar19 + 0x20);
    uStack_8f64 = *(undefined2 *)(uVar19 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100986;
    cVar5 = func_0x(&uStack_8f68);
    if (cVar5 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100996;
    func_0x(uVar19,&uStack_8f30);
  }
  *ppbVar18 = pbVar1;
  *(undefined4 *)(ppbVar18 + 0xc) = (undefined4)uStack_8f30;
  *(int *)((longlong)ppbVar18 + 100) = (int)((ulonglong)uStack_8f30 >> 0x20);
  *(undefined2 *)(ppbVar18 + 0xd) = uStack_8f28;
  *(undefined4 *)((longlong)ppbVar18 + 0x6c) = *(undefined4 *)(uVar19 + 0x20);
  *(undefined2 *)(ppbVar18 + 0xe) = *(undefined2 *)(uVar19 + 0x24);
  *(undefined2 *)((longlong)ppbVar18 + 0x72) = 0;
  uStack_8f68 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x125e5a0);
  uVar17 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x125e5a4);
  *(undefined2 *)(ppbVar18 + 2) = 0xffff;
  ppbVar18[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar18 + 0x2e) = 0;
  ppbVar18[7] = (byte *)0x0;
  ppbVar18[4] = (byte *)0x0;
  ppbVar18[9] = (byte *)0x0;
  ppbVar18[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar18 + 0xb) = 0;
  if ((**ppbVar18 & 2) != 0) {
    pbVar1 = pbVar1 + uVar17;
    if ((*pbVar1 & 1) == 0) {
      *(undefined2 *)(ppbVar18 + 2) = 0;
      ppbVar18[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar18 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100bcd */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x1019f0) - 0x12db890))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar18 + 2) = 1;
    ppbVar18[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x1019d0) * 4 +
                           0x1019c0) - 0x12db890);
                    /* WARNING: Could not emulate address calculation at 0x00100a4e */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar18 & 4) != 0) {
    uStack_8f68._2_2_ = (short)((uint)uStack_8f68 >> 0x10);
    if (uStack_8f68._2_2_ != 0) {
      uVar17 = (ulonglong)*(ushort *)(uVar19 + 0x61 + (longlong)uStack_8f68._2_2_ * 2);
    }
    psVar14 = (short *)(pbVar1 + uVar17);
    ppbVar18[9] = (byte *)psVar14;
    sVar3 = *psVar14;
    ppbVar18[10] = (byte *)(psVar14 + 1);
    *(short *)(ppbVar18 + 0xb) = (sVar3 + 1) * 2;
  }
  pbVar1 = ppbVar18[1];
  if (pbVar1 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100c83;
    func_0x(pbVar1,ppbVar18);
  }
LAB_:
  pbStack_89a0 = (byte *)(*(ushort *)(uVar19 + 0x1ffe) + uVar19);
  if ((*pbStack_89a0 & 1) == 0) {
    sStack_89a8 = 0;
    uStack_89a4 = 0;
    uStack_8982 = 0;
    uStack_8980 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100e68 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_89a0 & 0xe) * 4 + 0x101a5c) - 0x12db890
              ))(0x11ddf98);
    return;
  }
  sStack_89a8 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_89a0 & 0x1c) + 0x101a3c) * 4
                         + 0x101a2c) - 0x12db890);
                    /* WARNING: Could not emulate address calculation at 0x00100cd1 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_89a0,0x11ddf98);
  return;
}

