
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8
FUN_(longlong param_1,longlong *param_2,undefined8 param_3,longlong *param_4,
            undefined8 param_5,ulonglong *param_6,undefined8 param_7,int param_8,undefined8 param_9,
            int param_10)

{
  undefined4 *puVar1;
  ushort uVar2;
  undefined auVar3 [16];
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  bool bVar7;
  bool bVar8;
  char cVar9;
  undefined4 uVar10;
  int iVar11;
  undefined4 *puVar12;
  undefined8 uVar13;
  longlong lVar14;
  undefined4 *puVar15;
  ulonglong *puVar16;
  longlong lVar17;
  ulonglong *puVar18;
  uint uVar19;
  undefined4 *puVar20;
  ulonglong *puVar21;
  ulonglong *puVar22;
  longlong *plVar23;
  ulonglong *puVar24;
  ulonglong *puVar25;
  longlong unaff_GS_OFFSET;
  bool bVar26;
  undefined auStackX_20 [8];
  undefined8 in_stack_fffffffffffffef8;
  longlong lVar27;
  undefined8 uVar28;
  undefined *puVar29;
  undefined8 in_stack_ffffffffffffff08;
  ulonglong uVar30;
  undefined8 in_stack_ffffffffffffff10;
  undefined4 uVar32;
  undefined8 uVar31;
  undefined8 in_stack_ffffffffffffff18;
  undefined4 uVar33;
  undefined8 in_stack_ffffffffffffff20;
  undefined4 uVar35;
  longlong lVar34;
  undefined8 in_stack_ffffffffffffff28;
  uint uVar37;
  ulonglong uVar36;
  uint uStack_b8;
  undefined4 uStack_b4;
  longlong lStack_b0;
  undefined8 uStack_a8;
  longlong lStack_a0;
  int iStack_98;
  longlong lStack_90;
  longlong lStack_88;
  undefined8 uStack_80;
  undefined4 uStack_78;
  longlong lStack_70;
  undefined4 uStack_68;
  longlong lStack_60;
  undefined4 uStack_58;
  undefined8 uStack_50;
  undefined auStack_48 [16];
  
  uVar31 = param_5;
  uVar10 = (undefined4)((ulonglong)in_stack_ffffffffffffff08 >> 0x20);
  uVar32 = (undefined4)((ulonglong)in_stack_ffffffffffffff10 >> 0x20);
  uVar33 = (undefined4)((ulonglong)in_stack_ffffffffffffff18 >> 0x20);
  uVar35 = (undefined4)((ulonglong)in_stack_ffffffffffffff20 >> 0x20);
  uVar37 = (uint)((ulonglong)in_stack_ffffffffffffff28 >> 0x20);
  uVar19 = (uint)((ulonglong)in_stack_fffffffffffffef8 >> 0x20);
  uStack_50 = 0xfffffffffffffffe;
  puVar16 = (ulonglong *)0x0;
  bVar26 = false;
  *(undefined2 *)(param_1 + 0x3c) = *(undefined2 *)(param_4[6] + 0x6b8);
  *(undefined8 *)(param_1 + 0x298) = param_5;
  *(undefined8 *)(param_1 + 0x290) = param_3;
  *(longlong **)(param_1 + 0x180) = param_4;
  cVar9 = (**(code **)(*param_4 + 0x88))(param_4);
  *(bool *)(param_1 + 0x4bc) = cVar9 == '\0';
  *(undefined8 *)(param_1 + 0x248) = 0;
  plVar23 = *(longlong **)(param_1 + 0x48);
  if (plVar23 == (longlong *)0x0) {
    *(longlong **)(param_1 + 0x48) = param_2;
    (**(code **)(*param_2 + 8))(param_2);
    plVar23 = *(longlong **)(param_1 + 0x48);
  }
  lVar17 = 0x11c6390;
  if (param_6 != (ulonglong *)0x0) {
    lVar17 = (longlong)param_6;
  }
  *(longlong *)(param_1 + 0x50) = lVar17;
  puVar1 = (undefined4 *)CONCAT26(param_7._6_2_,CONCAT24(param_7._4_2_,(undefined4)param_7));
  if (puVar1 != (undefined4 *)0x0) {
    lVar17 = 2;
    puVar15 = (undefined4 *)(param_1 + 0x58);
    do {
      puVar20 = puVar15;
      puVar12 = puVar1;
      uVar4 = puVar12[1];
      uVar5 = puVar12[2];
      uVar6 = puVar12[3];
      *puVar20 = *puVar12;
      puVar20[1] = uVar4;
      puVar20[2] = uVar5;
      puVar20[3] = uVar6;
      uVar4 = puVar12[5];
      uVar5 = puVar12[6];
      uVar6 = puVar12[7];
      puVar20[4] = puVar12[4];
      puVar20[5] = uVar4;
      puVar20[6] = uVar5;
      puVar20[7] = uVar6;
      uVar4 = puVar12[9];
      uVar5 = puVar12[10];
      uVar6 = puVar12[0xb];
      puVar20[8] = puVar12[8];
      puVar20[9] = uVar4;
      puVar20[10] = uVar5;
      puVar20[0xb] = uVar6;
      uVar4 = puVar12[0xd];
      uVar5 = puVar12[0xe];
      uVar6 = puVar12[0xf];
      puVar20[0xc] = puVar12[0xc];
      puVar20[0xd] = uVar4;
      puVar20[0xe] = uVar5;
      puVar20[0xf] = uVar6;
      uVar4 = puVar12[0x11];
      uVar5 = puVar12[0x12];
      uVar6 = puVar12[0x13];
      puVar20[0x10] = puVar12[0x10];
      puVar20[0x11] = uVar4;
      puVar20[0x12] = uVar5;
      puVar20[0x13] = uVar6;
      uVar4 = puVar12[0x15];
      uVar5 = puVar12[0x16];
      uVar6 = puVar12[0x17];
      puVar20[0x14] = puVar12[0x14];
      puVar20[0x15] = uVar4;
      puVar20[0x16] = uVar5;
      puVar20[0x17] = uVar6;
      uVar4 = puVar12[0x19];
      uVar5 = puVar12[0x1a];
      uVar6 = puVar12[0x1b];
      puVar20[0x18] = puVar12[0x18];
      puVar20[0x19] = uVar4;
      puVar20[0x1a] = uVar5;
      puVar20[0x1b] = uVar6;
      uVar4 = puVar12[0x1d];
      uVar5 = puVar12[0x1e];
      uVar6 = puVar12[0x1f];
      puVar20[0x1c] = puVar12[0x1c];
      puVar20[0x1d] = uVar4;
      puVar20[0x1e] = uVar5;
      puVar20[0x1f] = uVar6;
      lVar17 = lVar17 + -1;
      puVar1 = puVar12 + 0x20;
      puVar15 = puVar20 + 0x20;
    } while (lVar17 != 0);
    uVar4 = puVar12[0x21];
    uVar5 = puVar12[0x22];
    uVar6 = puVar12[0x23];
    puVar20[0x20] = puVar12[0x20];
    puVar20[0x21] = uVar4;
    puVar20[0x22] = uVar5;
    puVar20[0x23] = uVar6;
    uVar4 = puVar12[0x25];
    uVar5 = puVar12[0x26];
    uVar6 = puVar12[0x27];
    puVar20[0x24] = puVar12[0x24];
    puVar20[0x25] = uVar4;
    puVar20[0x26] = uVar5;
    puVar20[0x27] = uVar6;
    *(undefined8 *)(puVar20 + 0x28) = *(undefined8 *)(puVar12 + 0x28);
  }
  func_0x(param_1 + 0x2a0);
  *(longlong **)(param_1 + 0x2a0) = plVar23;
  (**(code **)(*plVar23 + 8))(plVar23);
  func_0x(param_1 + 0x2a0,*(undefined8 *)(param_1 + 0x68));
  func_0x(uVar31,param_4,&param_6,0,(ulonglong)uVar19 << 0x20);
  *(int *)(param_1 + 0x4b8) = (int)param_6;
  if (param_8 == 0) {
    param_5._0_1_ = 0xc;
    if ((int)param_6 != 0) {
      param_5._0_1_ = 5;
    }
    uVar31 = CONCAT44(uVar32,1);
    uVar30 = CONCAT44(uVar10,1);
    func_0x
              (param_4,*(undefined8 *)(param_1 + 0x298),param_1 + 0x188,&param_5,auStack_48,0,uVar30
               ,uVar31,CONCAT44(uVar33,0xffffffff),CONCAT44(uVar35,1),(ulonglong)uVar37 << 0x20,0);
    param_6 = (ulonglong *)(*(ulonglong *)(param_1 + 0x298) >> 0x10);
    lVar27 = 0;
    func_0x(param_1 + 0x188,0,param_6,*(undefined8 *)(param_1 + 0x180),0);
    lVar17 = *(longlong *)(param_1 + 400);
    if (((DAT_ == '\0') || (*(ushort *)(param_4[6] + 0x67e) < 0x323)) ||
       ((DAT_ & 8) != 0)) {
      *(undefined4 *)(param_1 + 0x520) = 900;
      uVar10 = 0x70c;
    }
    else {
      uVar10 = 900;
      if (*(int *)(lVar17 + 0xf4) != 1) {
        uVar10 = 0x6a4;
      }
      *(undefined4 *)(param_1 + 0x520) = uVar10;
      uVar10 = 0xa2c;
    }
    *(undefined4 *)(param_1 + 0x524) = uVar10;
    if (*(int *)(param_1 + 0x4b8) != 0) {
      uVar36 = (ulonglong)
               *(uint *)(*(longlong *)
                          (*(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8) + 0x68) + 0x18);
      uVar13 = func_0x(param_1 + 0x188);
      iVar11 = func_0x(param_4,uVar13,uVar36 & 0xffffffff,0);
      if ((*(int *)(param_1 + 0x4b8) != 0) &&
         ((iVar11 == 0 || (iVar11 = func_0x(param_1 + 0x188,param_4), iVar11 == 0)))) {
        (*_DAT_)(6,9,0x10,1);
      }
    }
    if (*(int *)(param_1 + 0x4b8) != 0) {
      if (((*(int *)(*(longlong *)(param_1 + 400) + 0x3dc) != 0) ||
          (*(short *)(*(longlong *)(param_1 + 400) + 0x3e0) != 0)) &&
         (cVar9 = (**(code **)(*param_4 + 0x88))(param_4), cVar9 != '\0')) {
        lStack_b0 = 0;
        uStack_a8 = 0;
        lStack_a0 = 0;
        iStack_98 = 0;
        lVar14 = *(longlong *)(param_1 + 400);
        uStack_b8 = uStack_b8 & 0xfffffffc;
        uStack_b4 = 2;
        plVar23 = &lStack_90;
        puVar29 = (undefined *)&param_9;
        func_0x
                  (param_4,1,param_1 + 0x188,1,&uStack_b8,puVar29,auStackX_20,&lStack_88,plVar23);
        lVar27 = *(longlong *)(param_1 + 400) + 0x5b0;
        uStack_a8._4_4_ = 4;
        uVar31 = 0;
        uVar30 = 0;
        lStack_b0 = lVar27;
        uStack_a8._0_4_ =
             func_0x
                       (lVar27,4,0xffffffff,0,0,(ulonglong)puVar29 & 0xffffffff00000000,0,0,
                        (ulonglong)plVar23 & 0xffffffff00000000);
        param_7._0_4_ = 0;
        param_7._4_2_ = 0;
        (**(code **)(**(longlong **)(param_1 + 400) + 0xc0))
                  (*(longlong **)(param_1 + 400),param_4,&param_7,1);
        func_0x(lVar27,4);
        uStack_a8 = (ulonglong)uStack_a8._4_4_ << 0x20;
        func_0x(&lStack_a0,param_1 + 0x188);
        lVar34 = lStack_a0;
        lVar27 = -lStack_90;
        func_0x(lStack_a0,param_4,-*(longlong *)(lVar14 + 1000),-lStack_88,lVar27);
        if (iStack_98 != 0) {
          func_0x(*(longlong *)(lVar34 + 8) + 0x630,2);
          iStack_98 = 0;
        }
        lStack_a0 = 0;
      }
      cVar9 = (**(code **)(**(longlong **)(param_1 + 0x180) + 0x88))();
      if ((cVar9 == '\0') && (1 < *(uint *)(lVar17 + 0xf8))) {
        func_0x(param_1 + 0x188,1);
        uStack_80 = *(undefined8 *)(param_1 + 0x298);
        uStack_78 = 1;
        func_0x
                  (*(undefined8 *)(param_1 + 0x180),&uStack_80,0,0,0,1,uVar30 & 0xffffffffffff0000);
        param_6 = (ulonglong *)(*(ulonglong *)(param_1 + 0x298) >> 0x10);
        lVar27 = 0;
        func_0x(param_1 + 0x188,0,param_6,*(undefined8 *)(param_1 + 0x180),0);
      }
    }
    func_0x(param_1 + 0x4c0,param_1 + 0x188,0);
    lVar17 = *(longlong *)(param_1 + 0x298);
    uVar2 = *(ushort *)(*(longlong *)(param_1 + 400) + 0x3c8);
    lVar14 = *(longlong *)(param_1 + 0x180);
    if ((uVar2 != 1) || (*(short *)(*(longlong *)(lVar14 + 0x30) + 0x660) != 0)) {
      lVar34 = *(longlong *)(*(longlong *)(lVar14 + 0x30) + 0x698);
      if ((*(uint *)(lVar34 + 0x4c) < (uint)uVar2) ||
         ((((uVar2 == 0 ||
            (lVar34 = *(longlong *)(*(longlong *)(lVar34 + 0x28) + -8 + (ulonglong)uVar2 * 8),
            lVar34 == 0)) || (*(int *)(lVar34 + 0x38) < 8)) ||
          ((~(*(uint *)(lVar34 + 0x48) >> 3) & 1) == 0)))) {
        func_0x(lVar14,(ulonglong)uVar2,0,param_1 + 0x2a0,lVar17,1);
        lVar27 = lVar17;
      }
    }
    *(undefined (*) [16])(param_1 + 0x1c8) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0x1d8) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0x1e8) = ZEXT816(0);
    *(undefined (*) [16])(param_1 + 0x1f8) = ZEXT816(0);
    lVar17 = *(longlong *)(param_1 + 400);
    *(undefined4 *)(param_1 + 0x1c8) = *(undefined4 *)(lVar17 + 0x3c0);
    *(undefined2 *)(param_1 + 0x1cc) = *(undefined2 *)(lVar17 + 0x3c4);
    *(undefined2 *)(param_1 + 0x1ce) = *(undefined2 *)(lVar17 + 0x3c6);
    cVar9 = (**(code **)(**(longlong **)(param_1 + 0x180) + 0x88))();
    uVar10 = 8;
    if (cVar9 != '\0') {
      uVar10 = 0;
    }
    *(undefined4 *)(param_1 + 0x240) = uVar10;
    uVar19 = *(int *)(param_1 + 0x240) + 0xe + *(int *)(*(longlong *)(param_1 + 400) + 0xb0);
    if (0x1f9e < uVar19) {
      uVar19 = 0x1f9e;
    }
    *(uint *)(param_1 + 0x240) = uVar19;
    uVar28 = CONCAT71((int7)((ulonglong)lVar27 >> 8),5);
    uVar13 = (*_DAT_)(uVar19,*(undefined8 *)(param_1 + 0x48),0xba8650,0x214,uVar28);
    *(undefined8 *)(param_1 + 0x238) = uVar13;
    uVar28 = CONCAT71((int7)((ulonglong)uVar28 >> 8),5);
    uVar13 = (*_DAT_)(*(undefined4 *)(param_1 + 0x240),*(undefined8 *)(param_1 + 0x48),
                              0xba8650,0x218,uVar28);
    *(undefined8 *)(param_1 + 0x230) = uVar13;
    if ((*(int *)(param_1 + 0x4b8) == 0) ||
       ((lVar17 = *(longlong *)(param_1 + 400), (*(byte *)(lVar17 + 0x106) & 0x40) == 0 &&
        ((*(byte *)(lVar17 + 0x108) & 8) == 0)))) {
      uVar19 = *(uint *)(**(longlong **)(*(longlong *)(param_1 + 400) + 0x160) + 0x1c);
    }
    else {
      uVar19 = *(int *)(**(longlong **)(lVar17 + 0x160) + 0x1c) - 1;
    }
    *(uint *)(param_1 + 0x280) = uVar19;
    if (uVar19 != 0) {
      param_8 = 0x22c;
      auVar3._8_8_ = 0;
      auVar3._0_8_ = CONCAT44(0,uVar19);
      uVar30 = SUB168(ZEXT816(0x100) * auVar3,0);
      if (SUB168(ZEXT816(0x100) * auVar3,8) != 0) {
        uVar30 = 0xffffffffffffffff;
      }
      lVar17 = uVar30 + 0x10;
      if (0xffffffffffffffef < uVar30) {
        lVar17 = -1;
      }
      uVar28 = CONCAT71((int7)((ulonglong)uVar28 >> 8),5);
      param_6 = (ulonglong *)
                (*_DAT_)(lVar17,*(undefined8 *)(param_1 + 0x48),0xba8650,0x22c,uVar28);
      puVar22 = puVar16;
      if (param_6 != (ulonglong *)0x0) {
        *param_6 = CONCAT44(0,uVar19);
        puVar22 = param_6 + 2;
        uVar28 = 0xfffffffffe44aa90;
        func_0x(puVar22,0x100,uVar19,0xfffffffffe445810,0xfffffffffe44aa90);
      }
      *(ulonglong **)(param_1 + 0x218) = puVar22;
    }
    uVar10 = (undefined4)((ulonglong)uVar31 >> 0x20);
    lVar17 = param_1 + 0x188;
    bVar8 = false;
    if ((*(uint *)(*(longlong *)(param_1 + 400) + 0xb0) < 0x1f7d) ||
       (bVar7 = true, (*(byte *)(*(longlong *)(param_1 + 400) + 0x106) & 4) != 0)) {
      bVar7 = bVar8;
    }
    lVar27 = *(longlong *)(param_1 + 400);
    lVar14 = lVar27;
    if (*(longlong *)(lVar27 + 0x478) != 0) {
      lVar14 = *(longlong *)(lVar27 + 0x478);
    }
    if ((*(short *)(lVar14 + 0x440) != 0) || (*(short *)(lVar27 + 0xce) != 0)) {
      bVar8 = true;
    }
    if (((bVar7) || (bVar8)) && (param_10 != 0)) {
      lVar27 = *(longlong *)(param_1 + 400);
      if (*(longlong *)(lVar27 + 0x478) != 0) {
        lVar27 = *(longlong *)(lVar27 + 0x478);
      }
      if (*(short *)(lVar27 + 0x440) != 0) {
        lVar27 = *(longlong *)(param_1 + 400);
        if (*(longlong *)(lVar27 + 0x478) != 0) {
          lVar27 = *(longlong *)(lVar27 + 0x478);
        }
        if (*(int *)(lVar27 + 0x444) == 0) {
          bVar26 = *(short *)(lVar27 + 0x448) == 0;
        }
      }
    }
    puVar22 = puVar16;
    if (*(int *)(param_1 + 0x280) != 0) {
      do {
        lVar27 = **(longlong **)(*(longlong *)(param_1 + 400) + 0x160);
        puVar25 = (ulonglong *)(lVar27 + 0x30);
        puVar24 = *(ulonglong **)(lVar27 + 0x38);
        if (puVar24 == puVar25) {
          puVar24 = puVar16;
        }
        puVar21 = puVar16;
        if (puVar24 != (ulonglong *)0x0) {
          puVar21 = puVar24 + -0x2c;
        }
        puVar24 = puVar22;
        if ((int)puVar22 != 0) {
          do {
            puVar18 = (ulonglong *)puVar21[0x2d];
            if ((ulonglong *)puVar21[0x2d] == puVar25) {
              puVar18 = puVar16;
            }
            puVar21 = puVar16;
            if (puVar18 != (ulonglong *)0x0) {
              puVar21 = puVar18 + -0x2c;
            }
            puVar24 = (ulonglong *)((longlong)puVar24 - 1);
          } while (puVar24 != (ulonglong *)0x0);
        }
        func_0x
                  ((longlong)puVar22 * 0x100 + *(longlong *)(param_1 + 0x218),puVar21,
                   *(undefined2 *)(puVar21 + 7),puVar25,uVar28,*(byte *)(puVar21 + 4) >> 7,0);
        uVar10 = (undefined4)((ulonglong)uVar31 >> 0x20);
        uVar19 = (int)puVar22 + 1;
        puVar22 = (ulonglong *)(ulonglong)uVar19;
      } while (uVar19 < *(uint *)(param_1 + 0x280));
    }
    uVar32 = (undefined4)((ulonglong)uVar28 >> 0x20);
    puVar1 = (undefined4 *)(param_1 + 0x488);
    *(undefined4 *)(param_1 + 0x4a8) = 3;
    *(undefined4 *)(param_1 + 0x490) = 0x100000;
    *(undefined4 *)(param_1 + 0x4a4) = 1;
    *(undefined8 *)(param_1 + 0x498) = *(undefined8 *)(param_1 + 0x58);
    *(undefined4 *)(param_1 + 0x4a0) =
         *(undefined4 *)
          (*(longlong *)
            (*(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8) + 0x68) + 0x18);
    *(undefined4 *)(param_1 + 0x48c) = 0x22;
    if (puVar1 == (undefined4 *)0x0) {
      puVar15 = (undefined4 *)(*_DAT_)();
      *puVar15 = 0x16;
      (*_DAT_)();
    }
    else {
      *puVar1 = _DAT_;
    }
    lVar27 = *(longlong *)(param_1 + 400);
    if (*(int *)(**(longlong **)(lVar27 + 0x160) + 0x1c) != 0) {
      *(undefined *)(param_1 + 0x489) = 5;
      lVar27 = *(longlong *)(param_1 + 400);
    }
    lVar14 = param_1 + 0x2f8;
    lVar34 = param_1 + 0x2a0;
    uVar36 = 0;
    uVar30 = CONCAT44(uVar32,(uint)(*(byte *)(lVar27 + 0x107) >> 6)) & 0xffffffff00000001;
    func_0x
              (lVar14,1,1,0,uVar30,puVar1,*(undefined8 *)(param_1 + 0x180),
               CONCAT44(uVar10,0xffffffff),lVar17,lVar34,0,1);
    uVar10 = (undefined4)((ulonglong)lVar34 >> 0x20);
    func_0x(0,*(undefined8 *)(param_1 + 0x180),5,0,uVar30 & 0xffffffffffffff00);
    (*_DAT_)(*(undefined2 *)(param_1 + 0x3c),*(undefined8 *)(param_1 + 0x180),3,1);
    (**(code **)(**(longlong **)(param_1 + 0x180) + 0x270))();
    if (*(int *)(**(longlong **)(*(longlong *)(param_1 + 400) + 0x160) + 0x1c) == 0) {
      param_8 = 0x277;
      param_6 = (ulonglong *)
                (*_DAT_)(13000,*(undefined8 *)(param_1 + 0x48),0xba8650,0x277,5);
      if (param_6 != (ulonglong *)0x0) {
        puVar16 = (ulonglong *)func_0x(param_6);
      }
      *(ulonglong **)(param_1 + 0x210) = puVar16;
      func_0x
                (puVar16,*(undefined8 *)(param_1 + 0x180),0xffffffff,*(undefined8 *)(param_1 + 0x48)
                 ,lVar17,param_1 + 0x1c8,*(undefined8 *)(param_1 + 600),
                 *(undefined *)(param_1 + 0x4bc));
      if (((bVar8) || (bVar7)) && (param_10 != 0)) {
        if (bVar7) {
          if ((*(byte *)(param_1 + 0x378) & 2) == 0) {
            func_0x(lVar14);
            *(uint *)(param_1 + 0x378) = *(uint *)(param_1 + 0x378) | 2;
          }
          lStack_70 = param_1 + 0x388;
          uStack_68 = *(undefined4 *)(param_1 + 0x330);
          func_0x(&lStack_70);
        }
        if (bVar26) {
          if ((*(byte *)(param_1 + 0x378) & 2) == 0) {
            func_0x(lVar14);
            *(uint *)(param_1 + 0x378) = *(uint *)(param_1 + 0x378) | 2;
          }
          lStack_60 = param_1 + 0x3f0;
          uStack_58 = *(undefined4 *)(param_1 + 0x330);
          func_0x(&lStack_60);
        }
      }
    }
    else {
      param_8 = 0x29c;
      param_6 = (ulonglong *)
                (*_DAT_)(0x3e90,*(undefined8 *)(param_1 + 0x48),0xba8650,0x29c,5);
      if (param_6 != (ulonglong *)0x0) {
        puVar16 = (ulonglong *)func_0x(param_6,0);
      }
      *(ulonglong **)(param_1 + 0x208) = puVar16;
      lVar27 = *(longlong *)(param_1 + 600);
      if ((((*(byte *)(*(longlong *)(param_1 + 400) + 0x106) & 1) != 0) && (lVar27 == 0)) ||
         (lVar27 < 1)) {
        lVar27 = 1;
      }
      func_0x
                (puVar16,*(undefined8 *)(param_1 + 0x180),0xffffffff,*(undefined8 *)(param_1 + 0x48)
                 ,lVar17,param_1 + 0x1c8,0,*(undefined *)(param_1 + 0x4bc),lVar27,CONCAT44(uVar10,1)
                 ,uVar36 & 0xffffffff00000000,1,0);
    }
    *(undefined8 *)(param_1 + 0x4d0) = *(undefined8 *)(param_1 + 0x48);
    *(undefined8 *)(param_1 + 0x518) = *(undefined8 *)(param_1 + 0x48);
    *(undefined4 *)(param_1 + 0x250) = 1;
  }
  return 0;
}

