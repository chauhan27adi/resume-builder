
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,undefined8 param_3,undefined4 param_4)

{
  byte *pbVar1;
  byte *pbVar2;
  undefined2 uVar3;
  short sVar4;
  char cVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong lVar8;
  short *psVar9;
  code *UNRECOVERED_JUMPTABLE_00;
  byte **ppbVar10;
  ulonglong uVar11;
  undefined auStack_328 [4];
  undefined4 uStack_324;
  undefined8 uStack_320;
  undefined8 uStack_318;
  undefined8 uStack_30a;
  undefined8 uStack_300;
  undefined uStack_2ef;
  undefined2 uStack_2ec;
  longlong lStack_2e8;
  undefined4 uStack_2e0;
  undefined4 uStack_2d4;
  undefined2 uStack_2d0;
  longlong lStack_2b8;
  undefined8 uStack_2b0;
  undefined8 uStack_2a8;
  undefined2 uStack_2a0;
  undefined4 uStack_294;
  undefined2 uStack_290;
  longlong lStack_288;
  short sStack_1e0;
  undefined4 uStack_1dc;
  byte *pbStack_1d8;
  byte **ppbStack_1d0;
  undefined8 uStack_1c2;
  undefined2 uStack_1ba;
  undefined2 uStack_1b8;
  undefined6 uStack_1b6;
  undefined4 uStack_1ac;
  undefined auStack_1a8 [16];
  undefined auStack_198 [8];
  undefined8 uStack_190;
  undefined8 uStack_188;
  undefined6 uStack_180;
  undefined2 uStack_17a;
  undefined6 uStack_178;
  undefined2 uStack_172;
  undefined8 uStack_170;
  undefined auStack_168 [16];
  undefined auStack_158 [16];
  undefined auStack_148 [16];
  undefined8 uStack_138;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_328;
  lStack_2b8 = param_1 + 0x20;
  lStack_288 = *(longlong *)(param_1 + 0x28);
  pbStack_1d8 = (byte *)0x0;
  uStack_294 = *(undefined4 *)(param_2 + 0x20);
  uStack_290 = *(undefined2 *)(param_2 + 0x24);
  sStack_1e0 = -1;
  uStack_1dc = 0;
  uStack_1c2 = 0;
  uStack_1b8 = 0;
  uStack_1b6 = 0;
  ppbStack_1d0 = (byte **)0x0;
  uStack_320 = 0;
  uStack_324 = 0;
  uStack_30a = 0;
  uStack_300 = 0;
  uStack_318 = 0;
  uVar3 = *(undefined2 *)(**(longlong **)(lStack_288 + 0x160) + 0x1c);
  if ((*(int *)(lStack_288 + 0x100) == 0) || (uStack_2ef = 1, *(int *)(lStack_288 + 0x100) - 3U < 2)
     ) {
    uStack_2ef = 0;
  }
  uStack_2ec = uVar3;
  lStack_2e8 = param_1;
  uStack_2e0 = param_4;
  uStack_2b0 = param_3;
  if (*(longlong *)(param_1 + 0x80) == 0) {
    func_0x(*(undefined8 *)(param_1 + 200),uVar3,(longlong *)(param_1 + 0x80));
    if ((*(byte *)(*(longlong *)(param_1 + 0x28) + 0x42) & 4) == 0) {
      uVar6 = *(uint *)(*(longlong *)(param_1 + 0x28) + 0xb4);
      if (0xa58 < uVar6) {
        uVar6 = 0xa58;
      }
    }
    else {
      uVar6 = 0xa58;
    }
    *(uint *)(param_1 + 0x94) = uVar6;
    uVar7 = (*_DAT_)(uVar6,*(undefined8 *)(param_1 + 200),0x12da730,0x717,5);
    *(undefined8 *)(param_1 + 0x88) = uVar7;
  }
  if (*(longlong *)(param_1 + 0x70) != 0) {
    func_0x();
    *(undefined8 *)(param_1 + 0x70) = 0;
  }
  lVar8 = func_0x(*(undefined8 *)(param_1 + 200),uVar3);
  *(longlong *)(param_1 + 0x70) = lVar8;
  *(undefined2 *)(lVar8 + 0x62) = uVar3;
  uStack_1ac = 0;
  if (-1 < *(char *)(param_2 + 2)) goto LAB_;
  pbVar1 = (byte *)(param_2 + 0x60);
  if ((sStack_1e0 == 0) || (ppbVar10 = ppbStack_1d0, ppbStack_1d0 == (byte **)0x0)) {
    ppbVar10 = (byte **)auStack_1a8;
    uStack_180 = 0;
    stack0xfffffffffffffe6a = SUB1614(ZEXT816(0),2);
    auStack_198._0_2_ = 0xffff;
    uStack_172 = 0;
    uStack_190 = 0;
    uStack_17a = 0;
    uStack_178 = 0;
    uStack_170 = 0;
    uStack_188 = 0;
    auStack_168 = ZEXT816(0);
    auStack_148._0_12_ = ZEXT812(0);
    auStack_148._12_4_ = 0;
    uStack_138 = 0;
    auStack_158 = ZEXT816(0);
    auStack_1a8 = ZEXT816(0);
  }
  if (*(short *)(param_2 + 0x24) == 0) {
LAB_:
    uStack_2a8 = *(undefined8 *)(param_2 + 0x28);
    uStack_2a0 = *(undefined2 *)(param_2 + 0x30);
  }
  else {
    cVar5 = *(char *)(param_2 + 1);
    if (cVar5 == '\v') {
      if (*(int *)(param_2 + 0x18) != 99) {
LAB_:
        if (cVar5 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar5 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_2 + 0x18) != 99) goto LAB_;
    }
    uStack_2d4 = *(undefined4 *)(param_2 + 0x20);
    uStack_2d0 = *(undefined2 *)(param_2 + 0x24);
    cVar5 = func_0x(&uStack_2d4);
    if (cVar5 == '\0') goto LAB_;
    func_0x(param_2,&uStack_2a8);
  }
  *ppbVar10 = pbVar1;
  *(undefined4 *)(ppbVar10 + 0xc) = (undefined4)uStack_2a8;
  *(undefined2 *)(ppbVar10 + 0xd) = uStack_2a0;
  *(int *)((longlong)ppbVar10 + 100) = (int)((ulonglong)uStack_2a8 >> 0x20);
  *(undefined4 *)((longlong)ppbVar10 + 0x6c) = *(undefined4 *)(param_2 + 0x20);
  *(undefined2 *)(ppbVar10 + 0xe) = *(undefined2 *)(param_2 + 0x24);
  *(undefined2 *)((longlong)ppbVar10 + 0x72) = 0;
  uStack_2d4 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x109ad60);
  uVar11 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x109ad64);
  *(undefined2 *)(ppbVar10 + 2) = 0xffff;
  ppbVar10[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
  ppbVar10[7] = (byte *)0x0;
  ppbVar10[4] = (byte *)0x0;
  ppbVar10[9] = (byte *)0x0;
  ppbVar10[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar10 + 0xb) = 0;
  if ((**ppbVar10 & 2) != 0) {
    pbVar2 = pbVar1 + uVar11;
    if ((pbVar1[uVar11] & 1) == 0) {
      *(undefined2 *)(ppbVar10 + 2) = 0;
      *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar10 + 0x36) = 0;
      ppbVar10[3] = pbVar2;
                    /* WARNING: Could not emulate address calculation at 0x00100522 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x103e58) - 0x149f0d0))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar10 + 2) = 1;
    ppbVar10[3] = pbVar2;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x103e38) * 4 +
                           0x103e28) - 0x149f0d0);
                    /* WARNING: Could not emulate address calculation at 0x00100383 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar10 & 4) != 0) {
    uStack_2d4._2_2_ = (short)((uint)uStack_2d4 >> 0x10);
    if (uStack_2d4._2_2_ != 0) {
      uVar11 = (ulonglong)*(ushort *)(param_2 + 0x61 + (longlong)uStack_2d4._2_2_ * 2);
    }
    psVar9 = (short *)(pbVar1 + uVar11);
    ppbVar10[9] = (byte *)psVar9;
    sVar4 = *psVar9;
    ppbVar10[10] = (byte *)(psVar9 + 1);
    *(short *)(ppbVar10 + 0xb) = (sVar4 + 1) * 2;
  }
  if (ppbVar10[1] != (byte *)0x0) {
    func_0x(ppbVar10[1],ppbVar10);
  }
LAB_:
  pbStack_1d8 = (byte *)((ulonglong)*(ushort *)(param_2 + 0x1ffe) + param_2);
  if ((*pbStack_1d8 & 1) == 0) {
    sStack_1e0 = 0;
    uStack_1dc = 0;
    uStack_1ba = 0;
    uStack_1b8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010086c */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1d8 & 0xe) * 4 + 0x103ec4) - 0x149f0d0)
    )(0x101a758);
    return;
  }
  sStack_1e0 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1d8 & 0x1c) + 0x103ea4) * 4
                         + 0x103e94) - 0x149f0d0);
                    /* WARNING: Could not emulate address calculation at 0x00100640 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

