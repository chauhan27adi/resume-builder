
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * FUN_(longlong *param_1,uint *param_2,uint *param_3)

{
  ushort *puVar1;
  longlong lVar2;
  longlong *plVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  ulonglong *puVar7;
  longlong lVar8;
  longlong lVar9;
  ushort uVar10;
  short sVar11;
  uint uVar12;
  ulonglong uVar13;
  longlong lVar14;
  uint uVar15;
  int iVar16;
  uint uVar17;
  uint *puVar18;
  byte *pbVar19;
  ushort *puVar20;
  longlong unaff_GS_OFFSET;
  uint auStackX_10 [2];
  undefined auStackX_20 [8];
  
  uVar5 = *(ushort *)(param_2 + 1);
  uVar15 = uVar5 - 1;
  puVar18 = param_3;
  if (((ushort)uVar15 < *(ushort *)(param_1 + 1)) &&
     (puVar18 = (uint *)(ulonglong)(uVar15 & 0xffff),
     (*(byte *)(param_1[3] + (ulonglong)((uVar15 & 0xffff) >> 3)) >> ((byte)uVar15 & 7) & 1) != 0))
  {
    *param_3 = (uint)*(ushort *)(param_1[2] + 8 + (longlong)puVar18 * 10);
    return *(uint **)((longlong)puVar18 * 10 + param_1[2]);
  }
  lVar2 = *param_1;
  puVar1 = (ushort *)(lVar2 + 0x12);
  if (*(short *)(lVar2 + 0x10) != 0) {
    auStackX_10[0] = 0;
    puVar18 = (uint *)func_0x(puVar1,param_2,puVar18,param_3,auStackX_10);
    if ((((*(short *)(lVar2 + 0x10) != 0) &&
         (plVar3 = *(longlong **)(lVar2 + 0x20), plVar3 != (longlong *)0x0)) && (*plVar3 != 0)) &&
       (((*(byte *)((longlong)param_2 + 6) & 8) == 0 && ((auStackX_10[0] & 1) == 0)))) {
      if ((puVar18 == (uint *)0x0) || (puVar18 == (uint *)0x1692394)) {
        *param_3 = 0;
        puVar18 = (uint *)0x0;
      }
      else {
        puVar18 = (uint *)func_0x(plVar3,param_2,puVar18,*param_3,0,0,param_3,auStackX_10[0]
                                         );
      }
    }
    goto LAB_;
  }
  uVar12 = *param_2;
  if ((uVar12 & 0xc0000000) == 0x80000000) {
    iVar6 = func_0x(puVar1);
    if (iVar6 == 0) {
      *param_3 = 0;
      puVar18 = (uint *)0x0;
    }
    else {
      puVar18 = (uint *)func_0x(lVar2 + 0x3a,param_2,param_3,auStackX_20);
    }
    goto LAB_;
  }
  pbVar19 = *(byte **)(lVar2 + 0x18);
  bVar4 = *pbVar19;
  iVar16 = 1;
  iVar6 = 0;
  if ((bVar4 & 0x10) == 0) {
    if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
      uVar10 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
      iVar16 = iVar6;
      goto LAB_;
    }
  }
  else {
    uVar17 = *(uint *)(lVar2 + 0x20);
    if ((int)uVar12 < (int)uVar17) {
      if (*(ushort *)(pbVar19 + uVar17) < uVar5) {
        uVar10 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
        iVar16 = iVar6;
      }
      else {
        uVar10 = (ushort)(pbVar19[(ulonglong)(uVar5 - 1 >> 3) + (ulonglong)uVar17 + 2] >>
                         ((byte)(uVar5 - 1) & 7));
      }
    }
    else {
      uVar10 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
      iVar16 = iVar6;
    }
LAB_:
    if ((uVar10 & 1) != 0) {
      uVar15 = uVar15 & 0xffff;
      *param_3 = 0;
      puVar18 = (uint *)0x0;
      goto LAB_;
    }
    if ((iVar16 == 0) && ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
      puVar18 = *(uint **)(param_2 + 2);
      uVar15 = uVar15 & 0xffff;
      *param_3 = *puVar18;
      puVar18 = puVar18 + 1;
      goto LAB_;
    }
  }
  if (-1 < (int)uVar12) {
    uVar10 = *(ushort *)((longlong)param_2 + 6);
    if ((uVar10 & 8) != 0) {
      bVar4 = pbVar19[(int)uVar12];
      *param_3 = 1;
      puVar18 = (uint *)0x1692394;
      uVar15 = uVar15 & 0xffff;
      if ((bVar4 & (byte)(1 << ((byte)uVar10 & 7))) == 0) {
        puVar18 = (uint *)0x16929b8;
      }
      goto LAB_;
    }
    if ((uVar10 & 0x10) != 0) {
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) goto LAB_;
      }
      else {
        if ((int)*(uint *)(lVar2 + 0x20) <= (int)uVar12) goto LAB_;
        if (*(ushort *)(pbVar19 + *(uint *)(lVar2 + 0x20)) < uVar5) {
          puVar18 = *(uint **)(param_2 + 2);
          uVar15 = uVar15 & 0xffff;
          *param_3 = *puVar18;
          puVar18 = puVar18 + 1;
          goto LAB_;
        }
      }
    }
    uVar15 = uVar15 & 0xffff;
    *param_3 = 0;
    puVar18 = (uint *)((longlong)(int)*param_2 + *(longlong *)(lVar2 + 0x18));
    goto LAB_;
  }
  if (*(int *)(lVar2 + 0x14) == 0) {
    uVar12 = *(uint *)(lVar2 + 0x20);
    uVar13 = (ulonglong)uVar12;
    *(uint *)(lVar2 + 0x24) = uVar12;
    *puVar1 = 0;
    bVar4 = *pbVar19;
    if ((bVar4 & 0x10) != 0) {
      uVar12 = uVar12 + 2 + (*(ushort *)(pbVar19 + uVar13) + 7 >> 3);
      uVar13 = (ulonglong)uVar12;
      *(uint *)(lVar2 + 0x24) = uVar12;
      bVar4 = *pbVar19;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(lVar2 + 0x14) = (int)uVar13;
      *(undefined2 *)(lVar2 + 0x2c) = 0;
      *(int *)(lVar2 + 0x28) = (int)uVar13;
    }
    else {
      puVar20 = (ushort *)(pbVar19 + uVar13);
      uVar5 = *puVar20;
      *(ushort *)(lVar2 + 0x2c) = uVar5;
      if (uVar5 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar9 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar9 != 0)) &&
           ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x190d958,0x1a2d628,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(lVar2 + 0x18),3);
        uVar13 = (ulonglong)*(uint *)(lVar2 + 0x24);
        uVar5 = *(ushort *)(lVar2 + 0x2c);
      }
      uVar12 = (int)uVar13 + (uVar5 + 1) * 2;
      *(uint *)(lVar2 + 0x28) = uVar12;
      if (0x1f9e < uVar12) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar9 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar9 != 0 &&
            ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x190d958,0x1a2d628,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(lVar2 + 0x18),4);
        uVar5 = *(ushort *)(lVar2 + 0x2c);
        uVar12 = *(uint *)(lVar2 + 0x28);
      }
      uVar13 = (ulonglong)uVar5;
      uVar5 = puVar20[uVar13];
      *(uint *)(lVar2 + 0x14) = uVar5 & 0x7fff;
      if ((uVar5 & 0x7fff) < uVar12) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar9 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar9 != 0)) &&
           ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))
           ) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x190d958,0x1a2d628,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(lVar2 + 0x18),4);
        uVar13 = (ulonglong)*(ushort *)(lVar2 + 0x2c);
      }
      if ((short)puVar20[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
        lVar9 = *(longlong *)(lVar2 + 0x18);
        do {
          lVar14 = (ulonglong)*(uint *)(lVar2 + 0x24) + lVar9;
          if ((int)uVar13 == 1) {
            uVar12 = *(uint *)(lVar2 + 0x28);
            uVar17 = uVar12;
LAB_:
            if ((*(ushort *)(lVar14 + uVar13 * 2) & 0x7fff) < uVar12) goto LAB_;
          }
          else {
            uVar17 = *(uint *)(lVar2 + 0x28);
            uVar12 = *(ushort *)(lVar14 + -2 + uVar13 * 2) & 0x7fff;
            if (uVar17 <= uVar12) goto LAB_;
LAB_:
            func_0x(lVar9,7);
            uVar17 = *(uint *)(lVar2 + 0x28);
          }
          if ((uVar12 < uVar17) || (*(uint *)(lVar2 + 0x14) < uVar12)) goto LAB_;
          lVar9 = *(longlong *)(lVar2 + 0x18);
          if (*(ushort *)(lVar9 + (ulonglong)uVar12) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(lVar2 + 0x2c) = *(short *)(lVar2 + 0x2c) + -1;
            uVar5 = *(ushort *)(lVar2 + 0x3c) & 0xc7ff;
            *(short *)(lVar2 + 0x3a) = (short)uVar12;
            lVar9 = (ulonglong)(uVar12 & 0xffff) + *(longlong *)(lVar2 + 0x18);
            if ((*(ushort *)(lVar9 + 2) & 0x4000) != 0) {
              uVar5 = *(ushort *)(lVar9 + 2) & 0x3800 | uVar5;
            }
            *(ushort *)(lVar2 + 0x3c) = uVar5;
            *(ushort *)(lVar2 + 0x3c) = (uVar5 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar5;
            uVar13 = (ulonglong)*(uint *)(lVar2 + 0x14);
            goto LAB_;
          }
          if (*(ushort *)(lVar9 + (ulonglong)uVar12) < 0x400) break;
          *puVar1 = *puVar1 | 1;
          uVar5 = *(short *)(lVar2 + 0x2c) - 1;
          *(ushort *)(lVar2 + 0x2c) = uVar5;
          if ((uVar5 == 0) ||
             (uVar13 = (ulonglong)uVar5, -1 < (short)puVar20[(ulonglong)(uVar5 - 1) + 1])) break;
        } while( true );
      }
      uVar13 = (ulonglong)*(uint *)(lVar2 + 0x14);
    }
LAB_:
    if ((**(byte **)(lVar2 + 0x18) & 0x40) == 0) {
      *(undefined4 *)(lVar2 + 0x36) = 0;
    }
    else {
      *(int *)(lVar2 + 0x36) = (int)uVar13;
      *(int *)(lVar2 + 0x14) = (int)uVar13 + 0xe;
      puVar7 = (ulonglong *)func_0x(puVar1);
      uVar13 = *puVar7;
      uVar10 = (ushort)(uVar13 >> 0x30);
      uVar5 = uVar10;
      if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
        uVar5 = uVar10 & 0xdfff;
        if ((uVar13 & 0x4000000000000000) != 0) {
          uVar5 = uVar10 | 0x2000;
        }
      }
      if (uVar5 == 0xfffc) {
        iVar6 = (int)((uVar13 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(lVar2 + 0x14) = *(int *)(lVar2 + 0x14) + iVar6;
      uVar13 = (ulonglong)*(uint *)(lVar2 + 0x14);
    }
    iVar6 = (int)uVar13;
    if ((*(ulonglong *)(lVar2 + 0x2e) != 0) &&
       (*(ulonglong *)(lVar2 + 0x2e) < uVar13 + *(longlong *)(lVar2 + 0x18))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar9 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar9 != 0 &&
           (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) && (*(char *)(lVar9 + 0x499) != '\0'))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x190d958,0x1a2d628,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(lVar2 + 0x18),0x12);
      iVar6 = *(int *)(lVar2 + 0x14);
    }
    if (0x3f3b < iVar6 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar9 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar9 != 0 &&
          ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))))
         )) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x190d958,0x1a2d628,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(lVar2 + 0x18),5);
    }
  }
LAB_:
  sVar11 = -*(short *)param_2;
  if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
    bVar4 = **(byte **)(lVar2 + 0x18);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) == 0) goto LAB_;
    }
    else if (((int)*param_2 < (int)*(uint *)(lVar2 + 0x20)) &&
            (*(ushort *)(param_2 + 1) <=
             *(ushort *)(*(byte **)(lVar2 + 0x18) + *(uint *)(lVar2 + 0x20)))) goto LAB_;
LAB_:
    puVar18 = *(uint **)(param_2 + 2);
    uVar15 = uVar15 & 0xffff;
    *param_3 = *puVar18;
    puVar18 = puVar18 + 1;
    goto LAB_;
  }
LAB_:
  lVar9 = (longlong)sVar11;
  if ((uint)*(ushort *)(lVar2 + 0x2c) < (uint)(int)sVar11) {
    uVar15 = uVar15 & 0xffff;
    *param_3 = 0;
    puVar18 = *(uint **)(lVar2 + 0x18);
    goto LAB_;
  }
  lVar14 = *(longlong *)(lVar2 + 0x18);
  lVar8 = (ulonglong)*(uint *)(lVar2 + 0x24) + lVar14;
  if (sVar11 == 1) {
    uVar12 = *(uint *)(lVar2 + 0x28);
    uVar17 = *(ushort *)(lVar8 + lVar9 * 2) & 0x7fff;
LAB_:
    if (uVar17 < uVar12) goto LAB_;
  }
  else {
    uVar12 = *(ushort *)(lVar8 + -2 + lVar9 * 2) & 0x7fff;
    lVar14 = *(longlong *)(lVar2 + 0x18);
    uVar17 = *(ushort *)(lVar8 + lVar9 * 2) & 0x7fff;
    if (*(uint *)(lVar2 + 0x28) <= uVar12) goto LAB_;
LAB_:
    func_0x(lVar14,7);
  }
  uVar15 = uVar15 & 0xffff;
  *param_3 = uVar17 - uVar12;
  puVar18 = (uint *)((ulonglong)uVar12 + *(longlong *)(lVar2 + 0x18));
LAB_:
  if ((ushort)uVar15 < *(ushort *)(param_1 + 1)) {
    lVar2 = (ulonglong)(uVar15 & 0xffff) * 10;
    *(uint **)(lVar2 + param_1[2]) = puVar18;
    *(undefined2 *)(param_1[2] + 8 + lVar2) = *(undefined2 *)param_3;
    pbVar19 = (byte *)((ulonglong)((uVar15 & 0xffff) >> 3) + param_1[3]);
    *pbVar19 = *pbVar19 | (byte)(1 << (uVar15 & 7));
  }
  return puVar18;
}

