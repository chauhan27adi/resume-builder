
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x013ee8ea) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong *param_2,longlong param_3,uint *param_4,
                 longlong param_5)

{
  uint *puVar1;
  longlong **pplVar2;
  ulonglong *puVar3;
  ulonglong uVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong unaff_GS_OFFSET;
  uint in_stack_ffffffffffffff00;
  undefined8 auStack_90 [3];
  undefined8 uStack_78;
  uint *puStack_70;
  longlong lStack_68;
  longlong lStack_60;
  
  uStack_78 = 0xfffffffffffffffe;
  iVar7 = *(int *)(param_3 + 0x6b8);
  pplVar2 = (longlong **)
            (*param_1 +
            (param_1[1] &
            (ulonglong)((uint)*(ushort *)(param_4 + 1) + iVar7 * 0x100) * param_1[2] +
            (ulonglong)*param_4) * 8);
  puVar3 = (ulonglong *)
           (param_1 + (ulonglong)((uint)((longlong)pplVar2 - *param_1 >> 3) & 0x3ff) + 0xfb0);
  if ((*(byte *)(*(longlong *)(param_3 + 0x6b0) + 0x3a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(*(longlong *)(param_3 + 0x6b0) + 0x278) & 0x2000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  do {
    if (*(int *)puVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    LOCK();
    uVar4 = *puVar3;
    if (uVar4 == 0) {
      *puVar3 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (uVar4 != 0) {
      return;
    }
    plVar5 = *pplVar2;
    if (plVar5 != (longlong *)0x0) {
      if (((ulonglong)plVar5 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((*(uint *)(plVar5 + 0xe) != *param_4) ||
          (*(short *)((longlong)plVar5 + 0x74) != *(short *)(param_4 + 1))) ||
         (*(int *)((longlong)plVar5 + 0x2c) != iVar7)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (plVar5 != (longlong *)0x0) {
        lVar8 = *param_2;
        iVar7 = func_0x(plVar5,1,1,0,auStack_90,in_stack_ffffffffffffff00 & 0xffffff00,0,0);
        if (iVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*_DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *puVar3 = 0;
        func_0x(param_2,plVar5,0xff,4,0,4);
        if (lVar8 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*plVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        puVar1 = (uint *)((longlong)plVar5 + 100);
        if ((*puVar1 & 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        lStack_68 = *param_2;
        puStack_70 = puVar1;
        lStack_60 = func_0x(_DAT_,lStack_68,1,1);
        *(ushort *)(lStack_60 + 4) = *(ushort *)(lStack_60 + 4) & 0xfdff;
        *(ushort *)(lStack_60 + 4) = *(ushort *)(lStack_60 + 4) & 0xefff;
        *(undefined4 *)(lStack_60 + 0x40) = 1;
        LOCK();
        *puVar1 = *puVar1 & 0xffeff7ff;
        UNLOCK();
        *(undefined4 *)((longlong)plVar5 + 0x5c) = 0;
        LOCK();
        *(ushort *)((longlong)plVar5 + 0x62U) = *(ushort *)((longlong)plVar5 + 0x62U) & 0xfffe;
        UNLOCK();
        LOCK();
        *(ushort *)((longlong)plVar5 + 0x62U) = *(ushort *)((longlong)plVar5 + 0x62U) & 0xfffd;
        UNLOCK();
        LOCK();
        *(ushort *)((longlong)plVar5 + 0x62U) = *(ushort *)((longlong)plVar5 + 0x62U) & 0xfffb;
        UNLOCK();
        LOCK();
        *(ushort *)((longlong)plVar5 + 0x62U) = *(ushort *)((longlong)plVar5 + 0x62U) & 0xfeff;
        UNLOCK();
        func_0x(param_3,plVar5);
        if (param_5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (((byte)*(undefined4 *)((longlong)param_1 + 0x24) & 0x70) == 0x20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        lVar8 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 0x100);
        if (lVar8 != 0) {
          if (*(int *)(lVar8 + 0x22c) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((DAT_ & 0x80) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          func_0x(plVar5 + 0x13,1);
          if (_DAT_ != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          func_0x(param_1,plVar5,auStack_90[0]);
          if ((DAT_ & 4) == 0) {
            lVar8 = *(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
            if ((lVar8 != 0) && (**(longlong **)(lVar8 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(longlong *)(*param_2 + 0x30) = *(longlong *)(*param_2 + 0x30) * 0x10 + 0xc;
            return;
          }
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if (*param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*_DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar3 = 0;
    if (param_5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar8 = func_0x(param_1,1,1,0xc);
    if ((*(uint *)(lVar8 + 100) & 0x3fffdf6f) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(longlong *)(lVar8 + 0x90) == 0) {
      func_0x(lVar8);
    }
    *(uint *)(lVar8 + 0x70) = *param_4;
    *(undefined2 *)(lVar8 + 0x74) = *(undefined2 *)(param_4 + 1);
    *(longlong *)(lVar8 + 0x90) = param_3;
    uVar9 = 0;
    if (param_3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(lVar8 + 0x2c) = *(undefined4 *)(param_3 + 0x6b8);
    cVar6 = func_0x(param_3,lVar8);
    if (cVar6 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    LOCK();
    *(ushort *)(lVar8 + 0x62) = *(ushort *)(lVar8 + 0x62) & 0xfff7;
    UNLOCK();
    LOCK();
    *(ushort *)(lVar8 + 0x62) = *(ushort *)(lVar8 + 0x62) & 0xfeff;
    UNLOCK();
    in_stack_ffffffffffffff00 = (uint)uVar9;
    func_0x(param_2,lVar8,0xff,4,uVar9,in_stack_ffffffffffffff00);
  } while( true );
}

