
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  uint6 uVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  ulonglong *puVar10;
  undefined8 uVar11;
  longlong lVar12;
  byte bVar13;
  ulonglong uVar14;
  longlong *plVar15;
  undefined4 *puVar16;
  ushort uVar17;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  undefined8 unaff_RBX;
  ushort *puVar21;
  longlong lVar22;
  longlong lVar23;
  byte *pbVar24;
  longlong *plVar25;
  short *psVar26;
  longlong unaff_GS_OFFSET;
  longlong lStackX_8;
  undefined4 uStackX_10;
  undefined2 auStackX_14 [6];
  short *psStackX_20;
  undefined8 uStack_2bb8;
  undefined *puStack_2bb0;
  undefined2 auStack_2ba8 [2];
  undefined4 uStack_2ba4;
  undefined8 uStack_2ba0;
  undefined8 uStack_2b98;
  undefined8 uStack_2b8a;
  undefined8 uStack_2b80;
  undefined8 uStack_2b70;
  undefined auStack_2b68 [8];
  undefined4 uStack_2b60;
  undefined4 uStack_2b58;
  undefined4 **ppuStack_2b50;
  undefined *puStack_2b48;
  undefined8 uStack_2b40;
  undefined4 *puStack_2b38;
  undefined8 uStack_2b30;
  undefined auStack_2b28 [528];
  undefined8 uStack_2918;
  undefined8 uStack_2910;
  undefined4 uStack_2908;
  uint uStack_2904;
  undefined2 uStack_2900;
  undefined4 uStack_28fe;
  undefined8 uStack_28fa;
  undefined8 uStack_28f2;
  undefined auStack_28e8 [8];
  undefined4 uStack_28e0;
  undefined4 uStack_28d8;
  undefined4 **ppuStack_28d0;
  undefined *puStack_28c8;
  undefined8 uStack_28c0;
  undefined4 *puStack_28b8;
  undefined8 uStack_28b0;
  undefined auStack_28a8 [528];
  undefined8 uStack_2698;
  undefined8 uStack_2690;
  undefined4 uStack_2688;
  uint uStack_2684;
  undefined2 uStack_2680;
  undefined4 uStack_267e;
  undefined8 uStack_267a;
  undefined8 uStack_2672;
  undefined auStack_2668 [8];
  undefined4 uStack_2660;
  undefined4 uStack_2658;
  uint **ppuStack_2650;
  undefined *puStack_2648;
  undefined8 uStack_2640;
  uint *puStack_2638;
  undefined8 uStack_2630;
  undefined auStack_2628 [528];
  undefined8 uStack_2418;
  undefined8 uStack_2410;
  uint uStack_2408;
  undefined2 uStack_2404;
  undefined4 uStack_2402;
  longlong lStack_23fe;
  char cStack_23f6;
  undefined auStack_23e8 [9120];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  uStack_2b70 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002c18 + lVar9) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9);
  auStack_2ba8[0] = 0xffff;
  plVar25 = (longlong *)0x0;
  uStack_2ba0 = 0;
  uStack_2ba4 = 0;
  uStack_2b8a = 0;
  uStack_2b80 = 0;
  uStack_2b98 = 0;
  lVar23 = *(longlong *)(param_1 + 0xdf0);
  if (lVar23 == 0) goto LAB_;
  *(undefined8 *)((longlong)&psStackX_20 + lVar9) = param_2;
  *(undefined2 **)(&stack0x00000028 + lVar9) = auStack_2ba8;
  *(undefined **)(&stack0x00000030 + lVar9) = auStack_23e8;
  *(undefined4 *)(&stack0x00000038 + lVar9) = 0x239e;
  *(longlong *)(&stack0x00000040 + lVar9) = param_1 + 4000;
  plVar15 = (longlong *)(ulonglong)(*(ushort *)(lVar23 + 0x1c) - 2);
  if (*(ushort *)(lVar23 + 0x1c) < 3) {
    plVar15 = plVar25;
  }
  iVar8 = *(int *)(param_1 + 0xb38);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000cf;
  iVar8 = func_0x(lVar23,(longlong)&psStackX_20 + lVar9,plVar15,0x2000 - iVar8);
  if (iVar8 == 0) {
    uVar2 = *(undefined4 *)(param_1 + 0x1c);
    uVar3 = *(undefined8 *)(param_1 + 8);
    lVar23 = *(longlong *)(param_1 + 0xdf0);
    if (lVar23 == 0) {
      puVar16 = (undefined4 *)(_DAT_ + 0x70);
    }
    else {
      puVar16 = (undefined4 *)(lVar23 + 0x20);
    }
    uVar6 = *(uint6 *)(param_1 + 0x34);
    uVar1 = *(undefined2 *)(*(longlong *)(param_1 + 0x40) + 0x6b8);
    *(undefined8 *)((longlong)&lStackX_8 + lVar9) = 0xffffffffffffffff;
    *(undefined2 *)((longlong)auStackX_14 + lVar9 + 2) = 0;
    if ((_DAT_ & 0x1000) == 0) {
      *(longlong *)((longlong)&psStackX_20 + lVar9 + -0x20) = (longlong)&lStackX_8 + lVar9;
      puStack_2bb0 = &stack0xfffffffffffffff8 + lVar9;
    }
    else {
      *(ulonglong *)((longlong)&lStackX_8 + lVar9) = (ulonglong)uVar6 << 0x10;
      *(undefined2 *)((longlong)auStackX_14 + lVar9 + 4) = uVar1;
      *(undefined4 *)((longlong)&uStackX_10 + lVar9) = *puVar16;
      *(undefined2 *)((longlong)auStackX_14 + lVar9) = *(undefined2 *)(puVar16 + 1);
      *(longlong *)((longlong)&psStackX_20 + lVar9 + -0x20) = (longlong)&lStackX_8 + lVar9;
      puStack_2bb0 = &stack0xfffffffffffffff8 + lVar9;
      uVar11 = _DAT_;
      if (*_DAT_ != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100826;
        (*_DAT_)(&uStack_2bb8);
        uVar11 = uStack_2bb8;
      }
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar9) = uVar11;
      uStack_2b60 = 0x10000;
      uStack_2b58 = 0;
      ppuStack_2b50 = &puStack_2b38;
      puStack_2b48 = auStack_2b28;
      uStack_2918 = 0;
      uStack_2b40 = 0;
      uStack_2910 = 0;
      puStack_2b38 = &uStack_2908;
      uStack_2b30 = 0x1e;
      uStack_2908 = 0;
      uStack_28f2 = 0;
      puVar4 = *(undefined8 **)((longlong)&psStackX_20 + lVar9 + -0x20);
      uStack_28fa = *puVar4;
      uStack_2900 = *(undefined2 *)((longlong)puVar4 + 0xc);
      uStack_28fe = *(undefined4 *)(puVar4 + 1);
      uStack_2904 = (uint)*(ushort *)(puVar4 + 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008bd;
      func_0x(auStack_2b68);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar9) = uVar2;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar9) = param_1 + 0xe30;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008f3;
    iVar8 = func_0x(lVar23,0,param_1 + 0x20,uVar3);
    if ((_DAT_ >> 0xc & 1) != 0) {
      uStack_28e0 = 0x10000;
      uStack_28d8 = 0;
      ppuStack_28d0 = &puStack_28b8;
      puStack_28c8 = auStack_28a8;
      uStack_2698 = 0;
      uStack_28c0 = 0;
      uStack_2690 = 0;
      puStack_28b8 = &uStack_2688;
      uStack_28b0 = 0x1e;
      uStack_2688 = 1;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100972;
      uStack_2672 = func_0x(&stack0xfffffffffffffff8 + lVar9);
      puVar4 = *(undefined8 **)((longlong)&psStackX_20 + lVar9 + -0x20);
      uStack_267a = *puVar4;
      uStack_2680 = *(undefined2 *)((longlong)puVar4 + 0xc);
      uStack_267e = *(undefined4 *)(puVar4 + 1);
      uStack_2684 = (uint)*(ushort *)(puVar4 + 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1009b2;
      func_0x(auStack_28e8);
    }
    if (iVar8 != 0) {
      if (lVar23 == 0) {
        puVar16 = (undefined4 *)(_DAT_ + 0x70);
      }
      else {
        puVar16 = (undefined4 *)(lVar23 + 0x20);
      }
      if ((_DAT_ >> 0xb & 1) != 0) {
        uStack_2660 = 0x10000;
        uStack_2658 = 0;
        ppuStack_2650 = &puStack_2638;
        puStack_2648 = auStack_2628;
        uStack_2418 = 0;
        uStack_2640 = 0;
        uStack_2410 = 0;
        puStack_2638 = &uStack_2408;
        uStack_2630 = 0x13;
        uStack_2404 = *(undefined2 *)(puVar16 + 1);
        uStack_2402 = *puVar16;
        uStack_2408 = (uint)*(ushort *)(*(longlong *)(param_1 + 0x40) + 0x6b8);
        lStack_23fe = (ulonglong)*(uint6 *)(param_1 + 0x34) << 0x10;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10126c;
        cStack_23f6 = (char)iVar8;
        func_0x(auStack_2668);
      }
      goto LAB_;
    }
    if (*_DAT_ != (char)iVar8) {
      plVar15 = plVar25;
      if (_DAT_ != 0) {
        plVar15 = (longlong *)(_DAT_ + 0x6800);
      }
      if ((plVar15 != (longlong *)0x0) && (*plVar15 != 0)) {
        LOCK();
        plVar15 = (longlong *)(*plVar15 + 0x150);
        *plVar15 = *plVar15 + 1;
        UNLOCK();
      }
    }
    lVar23 = *(longlong *)(*(longlong *)(param_1 + 0x28) + 0x488);
    if (((lVar23 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar23 + 0x20) != 0) {
        lVar22 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar12 = *(longlong *)(lVar22 + 0x100);
        if (lVar12 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a69;
          (*_DAT_)(0);
          lVar12 = *(longlong *)(lVar22 + 0x100);
        }
        plVar15 = plVar25;
        if (*(longlong *)(lVar12 + 0x260) != 0) {
          plVar15 = (longlong *)(ulonglong)*(uint *)(*(longlong *)(lVar12 + 0x260) + 0xe68);
        }
        if ((uint)plVar15 < *(uint *)(_DAT_ + 8)) {
          lVar23 = *(longlong *)(*(longlong *)(lVar23 + 0x20) + (longlong)plVar15 * 8);
          *(longlong *)(lVar23 + 0x128) = *(longlong *)(lVar23 + 0x128) + 1;
          goto LAB_;
        }
      }
      LOCK();
      plVar15 = (longlong *)(*(longlong *)(lVar23 + 0x18) + 0x128);
      *plVar15 = *plVar15 + 1;
      UNLOCK();
    }
LAB_:
    puVar4 = *(undefined8 **)(&stack0x00000028 + lVar9);
    puVar4[1] = 0;
    *puVar4 = 0xffff;
    puVar4[3] = 0;
    puVar4[4] = 0;
    puVar4[2] = 0;
    *(undefined4 *)(puVar4 + 6) = 0;
    puVar4[5] = 0;
    puVar4 = *(undefined8 **)(&stack0x00000040 + lVar9);
    *puVar4 = 0;
    puVar4[0xc] = 0;
    *(undefined2 *)(puVar4 + 0xd) = 0;
    *(undefined8 *)((longlong)puVar4 + 0x6c) = 1;
    puVar4 = (undefined8 *)puVar4[1];
    if (puVar4 != (undefined8 *)0x0) {
      puVar5 = (undefined8 *)puVar4[1];
      if (puVar5 != (undefined8 *)0x0) {
        *puVar5 = 0;
        *(undefined4 *)(puVar5 + 0x481) = 0;
      }
      puVar4[3] = 0;
      *(undefined2 *)(puVar4 + 4) = 0;
      *puVar4 = 0;
      *(undefined4 *)(puVar4 + 0x14b) = 0;
    }
    lVar23 = *(longlong *)(param_1 + 0xdf0);
    uVar7 = *(ushort *)(lVar23 + 0x1c);
    plVar15 = (longlong *)(ulonglong)(uVar7 - 2);
    if (uVar7 < 3) {
      plVar15 = plVar25;
    }
    iVar8 = *(int *)(param_1 + 0xb38);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b64;
    iVar8 = func_0x(lVar23,(longlong)&psStackX_20 + lVar9,plVar15,0x2000 - iVar8);
    if (iVar8 == 0) goto LAB_;
    psVar26 = *(short **)(&stack0x00000028 + lVar9);
    if (-1 < *(char *)(*(longlong *)(param_1 + 0xdf0) + 2)) {
      psVar26 = *(short **)((longlong)&psStackX_20 + lVar9);
    }
    if (*psVar26 == 0) {
      if (*(int *)(psVar26 + 2) != 0) goto LAB_;
      psVar26[1] = 0;
      uVar18 = *(uint *)(psVar26 + 8);
      uVar20 = (ulonglong)uVar18;
      *(uint *)(psVar26 + 10) = uVar18;
      pbVar24 = *(byte **)(psVar26 + 4);
      bVar13 = *pbVar24;
      if ((bVar13 & 0x10) != 0) {
        uVar18 = uVar18 + 2 + (*(ushort *)(pbVar24 + uVar20) + 7 >> 3);
        uVar20 = (ulonglong)uVar18;
        *(uint *)(psVar26 + 10) = uVar18;
        bVar13 = *pbVar24;
      }
      if ((bVar13 & 0x20) == 0) {
        *(int *)(psVar26 + 2) = (int)uVar20;
        psVar26[0xe] = 0;
        *(int *)(psVar26 + 0xc) = (int)uVar20;
      }
      else {
        puVar21 = (ushort *)(pbVar24 + uVar20);
        uVar7 = *puVar21;
        psVar26[0xe] = uVar7;
        if (uVar7 == 0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar23 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar23 != 0 &&
              ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
               (*(char *)(lVar23 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c6a;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c8e;
              (*_DAT_)(1,0x129a368,0x13ba038,0x80f);
            }
          }
          uVar3 = *(undefined8 *)(psVar26 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c9c;
          func_0x(uVar3,3);
          uVar20 = (ulonglong)*(uint *)(psVar26 + 10);
          uVar7 = psVar26[0xe];
        }
        uVar18 = (int)uVar20 + (uVar7 + 1) * 2;
        *(uint *)(psVar26 + 0xc) = uVar18;
        if (0x1f9e < uVar18) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar23 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar23 != 0)) &&
             ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
              (*(char *)(lVar23 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d3c;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d60;
              (*_DAT_)(1,0x129a368,0x13ba038,0x816);
            }
          }
          uVar3 = *(undefined8 *)(psVar26 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d6e;
          func_0x(uVar3,4);
          uVar7 = psVar26[0xe];
          uVar18 = *(uint *)(psVar26 + 0xc);
        }
        uVar14 = (ulonglong)uVar7;
        uVar19 = puVar21[uVar14] & 0x7fff;
        *(uint *)(psVar26 + 2) = uVar19;
        if (uVar19 < uVar18) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar23 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar23 != 0 &&
              ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
               (*(char *)(lVar23 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100e0c;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100e30;
              (*_DAT_)(1,0x129a368,0x13ba038,0x81d);
            }
          }
          uVar3 = *(undefined8 *)(psVar26 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100e3e;
          func_0x(uVar3,4);
          uVar14 = (ulonglong)(ushort)psVar26[0xe];
          uVar19 = *(uint *)(psVar26 + 2);
        }
        if ((short)puVar21[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
          lVar23 = *(longlong *)(psVar26 + 4);
          do {
            if ((int)uVar14 == 1) {
              uVar18 = *(uint *)(psVar26 + 0xc);
              uVar19 = uVar18;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(psVar26 + 10) + lVar23 + uVar14 * 2) & 0x7fff) <
                  uVar18) goto LAB_;
            }
            else {
              uVar18 = *(ushort *)((ulonglong)*(uint *)(psVar26 + 10) + lVar23 + -2 + uVar14 * 2) &
                       0x7fff;
              uVar19 = *(uint *)(psVar26 + 0xc);
              if (uVar19 <= uVar18) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100eb4;
              func_0x(lVar23,7);
              uVar19 = *(uint *)(psVar26 + 0xc);
            }
            if ((uVar18 < uVar19) ||
               (uVar20 = (ulonglong)*(uint *)(psVar26 + 2), *(uint *)(psVar26 + 2) < uVar18))
            goto LAB_;
            lVar23 = *(longlong *)(psVar26 + 4);
            if (*(ushort *)((ulonglong)uVar18 + lVar23) == 5) {
              psVar26[1] = psVar26[1] | 2;
              psVar26[0xe] = psVar26[0xe] + -1;
              psVar26[0x15] = (short)uVar18;
              lVar23 = (ulonglong)(uVar18 & 0xffff) + *(longlong *)(psVar26 + 4);
              uVar7 = psVar26[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar23 + 2) & 0x4000) != 0) {
                uVar7 = *(ushort *)(lVar23 + 2) & 0x3800 | psVar26[0x16] & 0xc7ffU;
              }
              psVar26[0x16] = uVar7;
              psVar26[0x16] = (uVar7 ^ *(ushort *)(lVar23 + 2)) & 0x7ff ^ uVar7;
              uVar19 = *(uint *)(psVar26 + 2);
              break;
            }
            if (*(ushort *)((ulonglong)uVar18 + lVar23) < 0x400) goto LAB_;
            psVar26[1] = psVar26[1] | 1;
            uVar7 = psVar26[0xe] - 1;
            psVar26[0xe] = uVar7;
            if ((uVar7 == 0) ||
               (uVar14 = (ulonglong)uVar7, -1 < (short)puVar21[(ulonglong)(uVar7 - 1) + 1]))
            goto LAB_;
          } while( true );
        }
        uVar20 = (ulonglong)uVar19;
        pbVar24 = *(byte **)(psVar26 + 4);
      }
      goto LAB_;
    }
  }
  else {
    psVar26 = *(short **)(&stack0x00000028 + lVar9);
    if (-1 < *(char *)(*(longlong *)(param_1 + 0xdf0) + 2)) {
      psVar26 = *(short **)((longlong)&psStackX_20 + lVar9);
    }
    if (*psVar26 == 0) {
      if (*(int *)(psVar26 + 2) == 0) {
        psVar26[1] = 0;
        uVar18 = *(uint *)(psVar26 + 8);
        uVar20 = (ulonglong)uVar18;
        *(uint *)(psVar26 + 10) = uVar18;
        pbVar24 = *(byte **)(psVar26 + 4);
        bVar13 = *pbVar24;
        if ((bVar13 & 0x10) != 0) {
          uVar18 = uVar18 + 2 + (*(ushort *)(pbVar24 + uVar20) + 7 >> 3);
          uVar20 = (ulonglong)uVar18;
          *(uint *)(psVar26 + 10) = uVar18;
          bVar13 = *pbVar24;
        }
        if ((bVar13 & 0x20) == 0) {
          *(int *)(psVar26 + 2) = (int)uVar20;
          psVar26[0xe] = 0;
          *(int *)(psVar26 + 0xc) = (int)uVar20;
        }
        else {
          puVar21 = (ushort *)(pbVar24 + uVar20);
          uVar7 = *puVar21;
          psVar26[0xe] = uVar7;
          if (uVar7 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar23 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar23 != 0)) &&
               ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                (*(char *)(lVar23 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001db;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001ff;
                (*_DAT_)(1,0x129a368,0x13ba038,0x80f);
              }
            }
            uVar3 = *(undefined8 *)(psVar26 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10020d;
            func_0x(uVar3,3);
            uVar20 = (ulonglong)*(uint *)(psVar26 + 10);
            uVar7 = psVar26[0xe];
          }
          uVar18 = (int)uVar20 + (uVar7 + 1) * 2;
          *(uint *)(psVar26 + 0xc) = uVar18;
          if (0x1f9e < uVar18) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar23 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar23 != 0 &&
                ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                 (*(char *)(lVar23 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002ad;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002d1;
                (*_DAT_)(1,0x129a368,0x13ba038,0x816);
              }
            }
            uVar3 = *(undefined8 *)(psVar26 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002df;
            func_0x(uVar3,4);
            uVar7 = psVar26[0xe];
            uVar18 = *(uint *)(psVar26 + 0xc);
          }
          uVar14 = (ulonglong)uVar7;
          uVar19 = puVar21[uVar14] & 0x7fff;
          *(uint *)(psVar26 + 2) = uVar19;
          if (uVar19 < uVar18) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar23 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar23 != 0)) &&
               ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                (*(char *)(lVar23 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10037d;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003a1;
                (*_DAT_)(1,0x129a368,0x13ba038,0x81d);
              }
            }
            uVar3 = *(undefined8 *)(psVar26 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003af;
            func_0x(uVar3,4);
            uVar14 = (ulonglong)(ushort)psVar26[0xe];
            uVar19 = *(uint *)(psVar26 + 2);
          }
          if ((short)puVar21[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
            lVar23 = *(longlong *)(psVar26 + 4);
            do {
              if ((int)uVar14 == 1) {
                uVar18 = *(uint *)(psVar26 + 0xc);
                uVar19 = uVar18;
LAB_:
                if ((*(ushort *)((ulonglong)*(uint *)(psVar26 + 10) + lVar23 + uVar14 * 2) & 0x7fff)
                    < uVar18) goto LAB_;
              }
              else {
                uVar18 = *(ushort *)((ulonglong)*(uint *)(psVar26 + 10) + lVar23 + -2 + uVar14 * 2)
                         & 0x7fff;
                uVar19 = *(uint *)(psVar26 + 0xc);
                if (uVar19 <= uVar18) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100424;
                func_0x(lVar23,7);
                uVar19 = *(uint *)(psVar26 + 0xc);
              }
              if ((uVar18 < uVar19) ||
                 (uVar20 = (ulonglong)*(uint *)(psVar26 + 2), *(uint *)(psVar26 + 2) < uVar18))
              goto LAB_;
              lVar23 = *(longlong *)(psVar26 + 4);
              if (*(ushort *)((ulonglong)uVar18 + lVar23) == 5) {
                psVar26[1] = psVar26[1] | 2;
                psVar26[0xe] = psVar26[0xe] + -1;
                psVar26[0x15] = (short)uVar18;
                lVar23 = (ulonglong)(uVar18 & 0xffff) + *(longlong *)(psVar26 + 4);
                uVar7 = psVar26[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar23 + 2) & 0x4000) != 0) {
                  uVar7 = *(ushort *)(lVar23 + 2) & 0x3800 | psVar26[0x16] & 0xc7ffU;
                }
                psVar26[0x16] = uVar7;
                psVar26[0x16] = (uVar7 ^ *(ushort *)(lVar23 + 2)) & 0x7ff ^ uVar7;
                uVar19 = *(uint *)(psVar26 + 2);
                break;
              }
              if (*(ushort *)((ulonglong)uVar18 + lVar23) < 0x400) goto LAB_;
              psVar26[1] = psVar26[1] | 1;
              uVar7 = psVar26[0xe] - 1;
              psVar26[0xe] = uVar7;
              if ((uVar7 == 0) ||
                 (uVar14 = (ulonglong)uVar7, -1 < (short)puVar21[(ulonglong)(uVar7 - 1) + 1]))
              goto LAB_;
            } while( true );
          }
          uVar20 = (ulonglong)uVar19;
          pbVar24 = *(byte **)(psVar26 + 4);
        }
        goto LAB_;
      }
      goto LAB_;
    }
  }
  uVar18 = *(uint *)(psVar26 + 2);
  if (uVar18 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100746;
    func_0x(psVar26 + 1);
    uVar18 = *(uint *)(psVar26 + 2);
  }
  if (uVar18 < 9) {
    bVar13 = **(byte **)(psVar26 + 4) & 0x1c;
    goto joined_r0x0010072d;
  }
  goto LAB_;
LAB_:
  pbVar24 = *(byte **)(psVar26 + 4);
LAB_:
  iVar8 = 0;
  if ((*pbVar24 & 0x40) == 0) {
    *(undefined4 *)(psVar26 + 0x13) = 0;
  }
  else {
    *(int *)(psVar26 + 0x13) = (int)uVar20;
    *(int *)(psVar26 + 2) = (int)uVar20 + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100fc5;
    puVar10 = (ulonglong *)func_0x(psVar26 + 1);
    uVar20 = *puVar10;
    uVar17 = (ushort)(uVar20 >> 0x30);
    uVar7 = uVar17;
    if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
      uVar7 = uVar17 & 0xdfff;
      if ((uVar20 & 0x4000000000000000) != 0) {
        uVar7 = uVar17 | 0x2000;
      }
    }
    if (uVar7 == 0xfffc) {
      iVar8 = (int)((uVar20 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(psVar26 + 2) = *(int *)(psVar26 + 2) + iVar8;
    uVar20 = (ulonglong)*(uint *)(psVar26 + 2);
  }
  iVar8 = (int)uVar20;
  if ((*(ulonglong *)(psVar26 + 0xf) != 0) &&
     (*(ulonglong *)(psVar26 + 0xf) < uVar20 + *(longlong *)(psVar26 + 4))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar23 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar23 != 0 &&
         (lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0)) &&
        (*(char *)(lVar23 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1010b9;
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1010dd;
        (*_DAT_)(1,0x129a368,0x13ba038,0x877);
      }
    }
    uVar3 = *(undefined8 *)(psVar26 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1010eb;
    func_0x(uVar3,0x12);
    iVar8 = *(int *)(psVar26 + 2);
  }
  if (0x3f3b < iVar8 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar23 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar23 != 0 &&
        ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 && (*(char *)(lVar23 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) goto LAB_;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101192;
      (*_DAT_)(1,0x129a368,0x13ba038,0x87c);
    }
    goto LAB_;
  }
  goto LAB_;
LAB_:
  pbVar24 = *(byte **)(psVar26 + 4);
LAB_:
  iVar8 = 0;
  if ((*pbVar24 & 0x40) == 0) {
    *(undefined4 *)(psVar26 + 0x13) = 0;
  }
  else {
    *(int *)(psVar26 + 0x13) = (int)uVar20;
    *(int *)(psVar26 + 2) = (int)uVar20 + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100534;
    puVar10 = (ulonglong *)func_0x(psVar26 + 1);
    uVar20 = *puVar10;
    uVar17 = (ushort)(uVar20 >> 0x30);
    uVar7 = uVar17;
    if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
      uVar7 = uVar17 & 0xdfff;
      if ((uVar20 & 0x4000000000000000) != 0) {
        uVar7 = uVar17 | 0x2000;
      }
    }
    if (uVar7 == 0xfffc) {
      iVar8 = (int)((uVar20 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(psVar26 + 2) = *(int *)(psVar26 + 2) + iVar8;
    uVar20 = (ulonglong)*(uint *)(psVar26 + 2);
  }
  iVar8 = (int)uVar20;
  if ((*(ulonglong *)(psVar26 + 0xf) != 0) &&
     (*(ulonglong *)(psVar26 + 0xf) < uVar20 + *(longlong *)(psVar26 + 4))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar23 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar23 != 0 &&
         (lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0)) &&
        (*(char *)(lVar23 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100628;
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10064c;
        (*_DAT_)(1,0x129a368,0x13ba038,0x877);
      }
    }
    uVar3 = *(undefined8 *)(psVar26 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10065a;
    func_0x(uVar3,0x12);
    iVar8 = *(int *)(psVar26 + 2);
  }
  if (0x3f3b < iVar8 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar23 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar23 != 0 &&
        ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 && (*(char *)(lVar23 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
LAB_:
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1006e7;
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10070b;
        (*_DAT_)(1,0x129a368,0x13ba038,0x87c);
      }
    }
LAB_:
    uVar3 = *(undefined8 *)(psVar26 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100719;
    func_0x(uVar3,5);
  }
LAB_:
  uVar18 = *(uint *)(psVar26 + 2);
  if (uVar18 < 9) {
    bVar13 = **(byte **)(psVar26 + 4) & 0xe;
joined_r0x0010072d:
    if ((bVar13 == 0) || (bVar13 == 0xc)) {
      uVar18 = 9;
    }
  }
LAB_:
  uVar3 = *(undefined8 *)(psVar26 + 4);
  uVar11 = *(undefined8 *)(param_1 + 0xdf0);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100777;
  func_0x(uVar11,uVar3,uVar18);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101287;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9));
  return;
}

