
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,ulonglong param_4,
                 uint param_5,longlong *param_6)

{
  byte **ppbVar1;
  ushort *puVar2;
  code *pcVar3;
  byte bVar4;
  bool bVar5;
  undefined8 uVar6;
  int iVar7;
  uint *puVar8;
  longlong *plVar9;
  longlong lVar10;
  ulonglong *puVar11;
  longlong lVar12;
  byte *pbVar13;
  ulonglong uVar14;
  ushort uVar15;
  uint uVar16;
  longlong lVar17;
  ushort *puVar18;
  longlong lVar19;
  uint uVar20;
  uint uVar21;
  uint *puVar22;
  undefined8 uVar23;
  int iVar24;
  longlong unaff_GS_OFFSET;
  undefined8 auStack_220 [5];
  uint *puStack_1f8;
  uint auStack_1f0 [2];
  uint *puStack_1e8;
  uint auStack_1e0 [2];
  longlong *plStack_1d8;
  undefined4 auStack_1d0 [2];
  longlong alStack_1c8 [2];
  uint uStack_1b8;
  int iStack_1b4;
  ushort *puStack_1b0;
  byte bStack_1a8;
  uint uStack_1a4;
  uint uStack_1a0;
  byte bStack_19c;
  byte bStack_19b;
  byte bStack_19a;
  byte bStack_199;
  byte bStack_198;
  byte bStack_197;
  byte bStack_196;
  byte bStack_195;
  byte bStack_194;
  byte bStack_193;
  byte bStack_192;
  byte bStack_191;
  byte bStack_190;
  undefined8 uStack_188;
  undefined4 uStack_178;
  undefined4 uStack_174;
  uint uStack_170;
  undefined4 uStack_16c;
  undefined2 uStack_168;
  uint *puStack_160;
  ushort uStack_158;
  ushort uStack_154;
  ushort uStack_150;
  ushort uStack_14c;
  uint uStack_148;
  uint uStack_140;
  uint *puStack_138;
  ushort *puStack_130;
  uint *puStack_128;
  undefined4 uStack_120;
  uint uStack_118;
  undefined4 uStack_110;
  uint uStack_10c;
  int iStack_108;
  uint uStack_104;
  uint uStack_100;
  longlong lStack_f8;
  longlong lStack_f0;
  longlong lStack_e8;
  ulonglong uStack_e0;
  longlong lStack_d8;
  longlong lStack_d0;
  longlong lStack_c8;
  longlong *plStack_c0;
  longlong *plStack_b8;
  ulonglong uStack_b0;
  longlong lStack_a8;
  undefined8 uStack_a0;
  undefined8 uStack_88;
  uint *puStack_80;
  longlong *plStack_78;
  ulonglong *puStack_70;
  undefined auStack_50 [32];
  ulonglong uStack_30;
  
  uStack_88 = 0xfffffffffffffffe;
  uStack_30 = _DAT_ ^ (ulonglong)&uStack_1b8;
  uStack_174 = 0;
  uStack_1a0 = param_5;
  *param_6 = 0;
  auStack_220[0] = 0x100091;
  uStack_b0 = param_4;
  lStack_a8 = param_1;
  uStack_a0 = param_2;
  puVar8 = (uint *)func_0x
                             (*(undefined8 *)
                               (*(longlong *)(*(longlong *)(param_1 + 0x10) + 8) + 0x160),
                              param_4 & 0xffffffff);
  bStack_1a8 = *(byte *)((longlong)puVar8 + 0x21) & 4;
  iVar24 = (bStack_1a8 != 0) + 1;
  uStack_178 = iVar24;
  if (param_3 == (longlong *)0x0) {
    puStack_1f8 = (uint *)0x0;
    auStack_220[0] = 0x1000d8;
    (*_DAT_)(1,0x19b6240,0x1989be0,0xddd);
  }
  puStack_80 = *(uint **)(param_1 + 0x108);
  if (((*(byte *)(*(longlong *)(**(longlong **)(puStack_80 + 8) + 8) + 0x107) & 0x40) == 0) ||
     ((*puStack_80 & 0x1000000) != 0)) {
    uVar23 = 0;
  }
  else {
    uVar23 = 1;
  }
  auStack_220[0] = 0x10012f;
  plStack_b8 = param_3;
  iVar7 = func_0x(param_3,puStack_80 + 0x24,uVar23,auStack_50);
  if (iVar7 == 0x40f02) {
    auStack_220[0] = 0x10013e;
    func_0x(param_3);
    auStack_220[0] = 0x100148;
    (**(code **)(*param_3 + 8))(param_3);
    auStack_220[0] = 0x10015e;
    (*_DAT_)(0xdc,0x12,0x19);
  }
  *(uint *)(param_3 + 2) = *(uint *)(param_3 + 2) & 0xfffffeff;
  if (((char)*(uint *)(param_3 + 2) < '\0') || ((*(byte *)((longlong)param_3 + 0x34) & 1) == 0)) {
    auStack_220[0] = 0x100199;
    plVar9 = (longlong *)func_0x(param_3,0);
  }
  else if ((*(uint *)(param_3 + 2) >> 0xd & 1) == 0) {
    plVar9 = param_3 + 9;
  }
  else {
    plVar9 = (longlong *)param_3[0x29];
  }
  puVar18 = (ushort *)((longlong)plVar9 + 2);
  plStack_c0 = plVar9;
  plStack_78 = plVar9;
  if (*(short *)plVar9 == 0) {
    auStack_220[0] = 0x1001c0;
    func_0x();
  }
  else {
    auStack_220[0] = 0x1001c7;
    func_0x(puVar18,&uStack_16c);
  }
  uStack_120 = 0x1f9e;
  auStack_220[0] = 0x1001db;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  bVar4 = *(byte *)(puVar8 + 8) >> 1;
  puStack_160 = puVar8;
  if (*(short *)plVar9 != 0) {
    uStack_170 = 0;
    *(uint **)((longlong)auStack_1f0 + lVar10 + -8) = &uStack_170;
    *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100c70;
    puVar22 = (uint *)func_0x(puVar18,puVar8);
    puStack_128 = puVar22;
    if ((((*(short *)plVar9 != 0) && (plVar9 = (longlong *)plVar9[2], plVar9 != (longlong *)0x0)) &&
        (*plVar9 != 0)) && (((*(byte *)((longlong)puVar8 + 6) & 8) == 0 && ((uStack_170 & 1) == 0)))
       ) {
      if ((puVar22 == (uint *)0x0) || (puVar22 == (uint *)0x158a264)) {
        uStack_1b8 = 0;
        puVar22 = (uint *)0x0;
        puStack_128 = (uint *)0x0;
      }
      else {
        *(uint *)((longlong)auStack_1e0 + lVar10) = uStack_170;
        *(uint **)((longlong)&puStack_1e8 + lVar10) = &uStack_1b8;
        *(undefined4 *)((longlong)auStack_1f0 + lVar10) = 0x1f9e;
        *(longlong *)((longlong)auStack_1f0 + lVar10 + -8) = (longlong)&uStack_1b8 + lVar10;
        uVar16 = uStack_1b8;
        *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100cd3;
        puVar22 = (uint *)func_0x(plVar9,puVar8,puVar22,uVar16);
        puStack_128 = puVar22;
      }
    }
    goto LAB_;
  }
  uVar16 = *puVar8;
  puStack_1b0 = puVar18;
  if ((uVar16 & 0xc0000000) == 0x80000000) {
    *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100c1f;
    iVar7 = func_0x(puVar18);
    if (iVar7 == 0) {
      uStack_1b8 = 0;
      puVar22 = (uint *)0x0;
    }
    else {
      *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100c3a;
      puVar22 = (uint *)func_0x((short *)((longlong)plVar9 + 0x2a),puVar8,&uStack_1b8,
                                        &puStack_138);
    }
    goto LAB_;
  }
  if (((bVar4 & 1) == 0) && ((*(byte *)((longlong)puVar8 + 6) & 0x10) == 0)) {
    uStack_1a4 = 0;
LAB_:
    bVar5 = true;
LAB_:
    if (((bVar4 & 1) != 0) && (uStack_1a4 != 0)) {
      uStack_1b8 = 0;
      puVar22 = (uint *)0x0;
      goto LAB_;
    }
    if ((!bVar5) && ((*(byte *)((longlong)puVar8 + 6) & 0x10) != 0)) {
      puVar22 = *(uint **)(puVar8 + 2) + 1;
      uStack_1b8 = **(uint **)(puVar8 + 2);
      goto LAB_;
    }
  }
  else {
    pbVar13 = (byte *)plVar9[1];
    if ((*pbVar13 & 0x10) == 0) {
      bStack_19c = *pbVar13 & 0xe;
      bVar5 = false;
      if ((1 << bStack_19c & 0x1105U) == 0) {
        bVar5 = true;
        uStack_1a4 = 0;
      }
      else {
        uStack_1a4 = ~(uint)(*(ushort *)((longlong)puVar8 + 6) >> 4) & 1;
      }
      goto LAB_;
    }
    uVar21 = *(uint *)(plVar9 + 2);
    if ((int)uVar21 <= (int)uVar16) {
LAB_:
      uStack_1a4 = ~(uint)(*(ushort *)((longlong)puVar8 + 6) >> 4) & 1;
      bVar5 = false;
      goto LAB_;
    }
    if (*(ushort *)(pbVar13 + uVar21) < *(ushort *)(puVar8 + 1)) goto LAB_;
    if ((bVar4 & 1) != 0) {
      uStack_118 = *(ushort *)(puVar8 + 1) - 1;
      bStack_19b = pbVar13[(ulonglong)(uStack_118 >> 3) + (ulonglong)uVar21 + 2] >>
                   ((byte)uStack_118 & 7);
      uStack_1a4 = bStack_19b & 1;
      goto LAB_;
    }
    uStack_1a4 = 0;
    uStack_110 = 1;
  }
  if (-1 < (int)uVar16) {
    uVar15 = *(ushort *)((longlong)puVar8 + 6);
    if ((uVar15 & 8) != 0) {
      puVar22 = (uint *)0x158a264;
      if ((*(byte *)((longlong)(int)uVar16 + plVar9[1]) & (byte)(1 << ((byte)uVar15 & 7))) == 0) {
        puVar22 = (uint *)0x158a888;
      }
      uStack_1b8 = 1;
      goto LAB_;
    }
    if ((uVar15 & 0x10) != 0) {
      pbVar13 = (byte *)plVar9[1];
      if ((*pbVar13 & 0x10) == 0) {
        if ((1 << (*pbVar13 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar22 = *(uint **)(puVar8 + 2) + 1;
          uStack_1b8 = **(uint **)(puVar8 + 2);
          if (uStack_1b8 != 0x1f9e) {
            *(undefined8 *)((longlong)auStack_1f0 + lVar10 + -8) = 0;
            *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x1003a8;
            (*_DAT_)(1,0x19b3598,0x19b1f98,0x381);
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(plVar9 + 2) <= (int)uVar16) ||
              (*(ushort *)(pbVar13 + *(uint *)(plVar9 + 2)) < *(ushort *)(puVar8 + 1)))
      goto LAB_;
    }
    uStack_1b8 = 0x1f9e;
    puVar22 = (uint *)((longlong)(int)*puVar8 + plVar9[1]);
    goto LAB_;
  }
  uStack_188 = (uint *)((longlong)plVar9 + 4);
  if (*uStack_188 == 0) {
    iStack_1b4 = 0;
    *puVar18 = 0;
    uVar16 = *(uint *)(plVar9 + 2);
    puVar8 = (uint *)((longlong)plVar9 + 0x14);
    *puVar8 = uVar16;
    ppbVar1 = (byte **)(plVar9 + 1);
    pbVar13 = *ppbVar1;
    if ((*pbVar13 & 0x10) != 0) {
      uVar16 = uVar16 + (*(ushort *)(pbVar13 + *(uint *)(plVar9 + 2)) + 7 >> 3) + 2;
      *puVar8 = uVar16;
      pbVar13 = *ppbVar1;
    }
    puStack_138 = puVar8;
    if ((*pbVar13 & 0x20) == 0) {
      *uStack_188 = uVar16;
      *(short *)((longlong)plVar9 + 0x1c) = 0;
      *(uint *)(plVar9 + 3) = *puVar8;
    }
    else {
      puStack_130 = (ushort *)(pbVar13 + uVar16);
      uVar15 = *puStack_130;
      puVar2 = (ushort *)((longlong)plVar9 + 0x1c);
      *puVar2 = uVar15;
      if (uVar15 == 0) {
        iStack_1b4 = 1;
        if ((DAT_ != '\0') || (bStack_19a = DAT_, (DAT_ & 1) != 0)) {
          lVar17 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
          if (lVar17 == 0) {
            lStack_f8 = 0;
          }
          else {
            lStack_f8 = *(longlong *)(lVar17 + 0x60);
            if ((lStack_f8 != 0) && (*(char *)(lStack_f8 + 0x499) != '\0')) {
              if ((DAT_ == '\0') && (bStack_199 = DAT_ >> 1, (bStack_199 & 1) == 0))
              {
                *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x1004ec;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)((longlong)auStack_1f0 + lVar10 + -8) = 0;
                *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100510;
                (*_DAT_)(1,0x1805828,0x19254f8,0x80f);
              }
            }
          }
        }
        puVar18 = puStack_1b0;
        pbVar13 = *ppbVar1;
        *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x10052b;
        func_0x(pbVar13,3);
      }
      uVar16 = *puVar8 + (*puVar2 + 1) * 2;
      puVar22 = (uint *)(puVar18 + 0xb);
      *puVar22 = uVar16;
      if (0x1f9e < uVar16) {
        iStack_1b4 = iStack_1b4 + 1;
        if ((DAT_ != '\0') || (bStack_198 = DAT_, (DAT_ & 1) != 0)) {
          lVar17 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
          puVar18 = puStack_1b0;
          if (lVar17 == 0) {
            lStack_f0 = 0;
          }
          else {
            lStack_f0 = *(longlong *)(lVar17 + 0x60);
            if ((lStack_f0 != 0) && (*(char *)(lStack_f0 + 0x499) != '\0')) {
              if ((DAT_ == '\0') && (bStack_197 = DAT_ >> 1, (bStack_197 & 1) == 0))
              {
                *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x1005d8;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                puVar18 = puStack_1b0;
              }
              else {
                *(undefined8 *)((longlong)auStack_1f0 + lVar10 + -8) = 0;
                *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100600;
                (*_DAT_)(1,0x1805828,0x19254f8,0x816);
                puVar18 = puStack_1b0;
              }
            }
          }
        }
        pbVar13 = *ppbVar1;
        *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x10061f;
        func_0x(pbVar13,4);
      }
      uStack_158 = puStack_130[*puVar2];
      *uStack_188 = uStack_158 & 0x7fff;
      if ((uStack_158 & 0x7fff) < *puVar22) {
        iStack_1b4 = iStack_1b4 + 1;
        if ((DAT_ != '\0') || (bStack_196 = DAT_, (DAT_ & 1) != 0)) {
          lVar17 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
          puVar18 = puStack_1b0;
          if (lVar17 == 0) {
            lStack_e8 = 0;
          }
          else {
            lStack_e8 = *(longlong *)(lVar17 + 0x60);
            if ((lStack_e8 != 0) && (*(char *)(lStack_e8 + 0x499) != '\0')) {
              if ((DAT_ == '\0') && (bStack_195 = DAT_ >> 1, (bStack_195 & 1) == 0))
              {
                *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x1006d6;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                puVar18 = puStack_1b0;
              }
              else {
                *(undefined8 *)((longlong)auStack_1f0 + lVar10 + -8) = 0;
                *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x1006fe;
                (*_DAT_)(1,0x1805828,0x19254f8,0x81d);
                puVar18 = puStack_1b0;
              }
            }
          }
        }
        pbVar13 = *ppbVar1;
        *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x10071d;
        func_0x(pbVar13,4);
      }
      do {
        uVar15 = *puVar2;
        if (-1 < (short)puStack_130[(ulonglong)(uVar15 - 1) + 1]) break;
        pbVar13 = *ppbVar1;
        if (uVar15 == 1) {
          uVar16 = *puVar22;
          uVar21 = uVar16;
        }
        else {
          uStack_154 = *(ushort *)
                        (pbVar13 + (longlong)(int)(uVar15 - 2) * 2 + (ulonglong)*puVar8 + 2);
          uVar16 = uStack_154 & 0x7fff;
          uVar21 = *puVar22;
        }
        uStack_150 = *(ushort *)(pbVar13 + (longlong)(int)(uVar15 - 1) * 2 + (ulonglong)*puVar8 + 2)
        ;
        uStack_104 = uStack_150 & 0x7fff;
        uStack_100 = uVar16;
        if ((uVar16 < uVar21) || (uStack_104 < uVar16)) {
          *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x1007b3;
          func_0x(pbVar13,7);
          uVar21 = *puVar22;
        }
        uStack_10c = uVar16;
        if ((uVar16 < uVar21) || (*uStack_188 < uVar16)) {
          iStack_1b4 = iStack_1b4 + 1;
          iVar24 = uStack_178;
          goto LAB_;
        }
        uStack_14c = *(ushort *)(*ppbVar1 + uVar16);
        if (uStack_14c == 5) {
          *puVar18 = *puVar18 | 2;
          *puVar2 = *puVar2 - 1;
          puVar18[0x14] = (ushort)uVar16;
          lVar17 = (ulonglong)(uVar16 & 0xffff) + *(longlong *)(puVar18 + 3);
          uVar15 = *(ushort *)(lVar17 + 2);
          puVar18[0x15] = puVar18[0x15] & 0xc7ff;
          if ((uVar15 & 0x4000) != 0) {
            puVar18[0x15] = puVar18[0x15] | uVar15 & 0x3800;
          }
          puVar18[0x15] = (puVar18[0x15] ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ puVar18[0x15];
          break;
        }
        if (uStack_14c < 0x400) break;
        *puVar18 = *puVar18 | 1;
        *puVar2 = *puVar2 - 1;
        puVar8 = puStack_138;
      } while (*puVar2 != 0);
    }
    puVar8 = uStack_188;
    iVar24 = 0;
    if ((**ppbVar1 & 0x40) == 0) {
      *(undefined4 *)(puVar18 + 0x12) = 0;
    }
    else {
      *(uint *)(puVar18 + 0x12) = *uStack_188;
      *uStack_188 = *uStack_188 + 0xe;
      *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x1008a5;
      puVar11 = (ulonglong *)func_0x(puVar18);
      uStack_e0 = *puVar11;
      uVar15 = (ushort)(uStack_e0 >> 0x30);
      if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
        if ((uStack_e0 & 0x4000000000000000) == 0) {
          uVar15 = uVar15 & 0xdfff;
        }
        else {
          uVar15 = uVar15 | 0x2000;
        }
      }
      if (uVar15 == 0xfffc) {
        puStack_70 = &uStack_e0;
        iVar24 = (int)((uStack_e0 >> 0x20 & 0xffff) >> 5);
        iStack_108 = iVar24;
      }
      *puVar8 = *puVar8 + iVar24;
    }
    uVar16 = *puVar8;
    if ((*(byte **)(puVar18 + 0xe) != (byte *)0x0) &&
       (*(byte **)(puVar18 + 0xe) < *ppbVar1 + uVar16)) {
      iStack_1b4 = iStack_1b4 + 1;
      if ((DAT_ != '\0') || (bStack_194 = DAT_, (DAT_ & 1) != 0)) {
        lVar17 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
        puVar18 = puStack_1b0;
        if (lVar17 == 0) {
          lStack_d8 = 0;
        }
        else {
          lStack_d8 = *(longlong *)(lVar17 + 0x60);
          if ((lStack_d8 != 0) && (*(char *)(lStack_d8 + 0x499) != '\0')) {
            if ((DAT_ == '\0') && (bStack_193 = DAT_ >> 1, (bStack_193 & 1) == 0)) {
              *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x1009e0;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
              puVar18 = puStack_1b0;
            }
            else {
              *(undefined8 *)((longlong)auStack_1f0 + lVar10 + -8) = 0;
              *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100a04;
              (*_DAT_)(1,0x1805828,0x19254f8,0x877);
              puVar18 = puStack_1b0;
            }
          }
        }
      }
      pbVar13 = *ppbVar1;
      *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100a1f;
      func_0x(pbVar13,0x12);
      uVar16 = *puVar8;
    }
    iVar24 = uStack_178;
    if (0x3f3b < uVar16 - 1) {
      iStack_1b4 = iStack_1b4 + 1;
      if ((DAT_ != '\0') || (bStack_192 = DAT_, (DAT_ & 1) != 0)) {
        lVar17 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
        puVar18 = puStack_1b0;
        if (lVar17 == 0) {
          lStack_d0 = 0;
        }
        else {
          lStack_d0 = *(longlong *)(lVar17 + 0x60);
          if ((lStack_d0 != 0) && (*(char *)(lStack_d0 + 0x499) != '\0')) {
            if ((DAT_ == '\0') && (bStack_191 = DAT_ >> 1, (bStack_191 & 1) == 0)) {
              *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100abf;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              puVar18 = puStack_1b0;
            }
            else {
              *(undefined8 *)((longlong)auStack_1f0 + lVar10 + -8) = 0;
              *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100ae3;
              (*_DAT_)(1,0x1805828,0x19254f8,0x87c);
              puVar18 = puStack_1b0;
            }
          }
        }
      }
      pbVar13 = *ppbVar1;
      *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100afe;
      func_0x(pbVar13,5);
      iVar24 = uStack_178;
    }
  }
LAB_:
  uStack_178 = CONCAT22(uStack_178._2_2_,-*(short *)puStack_160);
  if ((*(byte *)((longlong)puStack_160 + 6) & 0x10) == 0) {
LAB_:
    uVar16 = (uint)-*(short *)puStack_160;
    if (puVar18[0xd] < uVar16) {
      uStack_1b8 = 0;
      puVar22 = *(uint **)(puVar18 + 3);
    }
    else {
      plVar9 = (longlong *)(puVar18 + 3);
      lVar17 = *plVar9;
      lStack_c8 = (ulonglong)*(uint *)(puVar18 + 9) + lVar17;
      if (uVar16 == 1) {
        uVar21 = *(uint *)(puVar18 + 0xb);
      }
      else {
        uVar21 = *(ushort *)(lStack_c8 + 2 + (longlong)(int)(uVar16 - 2) * 2) & 0x7fff;
        lVar17 = *plVar9;
        puVar18 = puStack_1b0;
      }
      uVar20 = *(ushort *)(lStack_c8 + 2 + (longlong)(int)(uVar16 - 1) * 2) & 0x7fff;
      uStack_140 = uVar16;
      if ((uVar21 < *(uint *)(puVar18 + 0xb)) || (uVar20 < uVar21)) {
        *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100bf7;
        func_0x(lVar17,7);
      }
      puVar22 = (uint *)((ulonglong)uVar21 + *plVar9);
      uStack_1b8 = uVar20 - uVar21;
    }
  }
  else {
    pbVar13 = *(byte **)(puVar18 + 3);
    if ((*pbVar13 & 0x10) == 0) {
      bStack_190 = *pbVar13 & 0xe;
      uVar16 = 1 << bStack_190 & 0x1105;
      uStack_148 = (uint)(uVar16 == 0);
      if (uVar16 == 0) goto LAB_;
    }
    else if (((int)*puStack_160 < (int)*(uint *)(puVar18 + 7)) &&
            (*(ushort *)(puStack_160 + 1) <= *(ushort *)(pbVar13 + *(uint *)(puVar18 + 7)))) {
      uStack_148 = 1;
      goto LAB_;
    }
    puVar22 = *(uint **)(puStack_160 + 2) + 1;
    uStack_1b8 = **(uint **)(puStack_160 + 2);
  }
LAB_:
  plVar9 = plStack_c0;
  puVar8 = puStack_160;
  if (puVar22 == (uint *)0x0) {
    uStack_1a0 = uStack_1a0 | 8;
  }
  else {
    *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100d01;
    iVar7 = func_0x(plVar9,puVar8);
    if (iVar7 == 0) {
      uStack_1a0 = uStack_1a0 | 0x200;
    }
  }
  *(undefined8 *)((longlong)auStack_220 + lVar10) = 0x100d2b;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  lVar17 = (longlong)&uStack_1b8 + lVar12 + lVar10;
  *(undefined8 *)((longlong)auStack_220 + lVar12 + lVar10) = 0x100d41;
  func_0x(lVar17);
  pcVar3 = *(code **)(*plStack_b8 + 8);
  *(undefined8 *)((longlong)auStack_220 + lVar12 + lVar10) = 0x100d4e;
  (*pcVar3)();
  *(undefined8 **)((longlong)alStack_1c8 + lVar12 + lVar10) = &uStack_188;
  *(undefined4 *)((longlong)auStack_1d0 + lVar12 + lVar10) = 0;
  *(longlong **)((longlong)&plStack_1d8 + lVar12 + lVar10) = param_6;
  *(uint *)((longlong)auStack_1e0 + lVar12 + lVar10) = uStack_1a0;
  uVar14 = uStack_b0;
  *(ulonglong *)((longlong)&puStack_1e8 + lVar12 + lVar10) = uStack_b0;
  *(uint *)((longlong)auStack_1f0 + lVar12 + lVar10) = uStack_1b8;
  *(longlong *)((longlong)auStack_1f0 + lVar12 + lVar10 + -8) = lVar17;
  uVar6 = uStack_a0;
  lVar17 = lStack_a8;
  uVar23 = *(undefined8 *)(lStack_a8 + 0x1e8);
  *(undefined8 *)((longlong)auStack_220 + lVar12 + lVar10) = 0x100db2;
  uStack_174 = func_0x(lVar17,uVar6,uVar23,iVar24);
  lVar17 = *param_6;
  if (bStack_1a8 == 0) {
    *(int *)((longlong)param_3 + 0xc) = *(int *)((longlong)param_3 + 0xc) + 1;
    *(longlong **)(lVar17 + 0x150) = param_3;
    *(undefined4 *)(lVar17 + 0x158) = 2;
  }
  else {
    *(longlong **)(lVar17 + 0x38) = param_3;
    *(undefined4 *)(lVar17 + 0x40) = 2;
    *(ulonglong *)(lVar17 + 0x48) = uVar14;
  }
  lVar19 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar17 = *(longlong *)(lVar19 + 0x100);
  if (lVar17 == 0) {
    *(undefined8 *)((longlong)auStack_220 + lVar12 + lVar10) = 0x100e16;
    (*_DAT_)();
    lVar17 = *(longlong *)(lVar19 + 0x100);
  }
  if (*(int *)(lVar17 + 0x22c) != 0) {
    *(undefined8 *)((longlong)auStack_220 + lVar12 + lVar10) = 0x100e2c;
    (*_DAT_)();
  }
  uVar14 = uStack_30 ^ (ulonglong)&uStack_1b8;
  *(undefined8 *)((longlong)auStack_220 + lVar12 + lVar10) = 0x100e3e;
  func_0x(uVar14);
  return;
}

