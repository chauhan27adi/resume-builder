
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,longlong param_2,short *param_3,int param_4,double *param_5,
                 uint param_6)

{
  ushort *puVar1;
  float fVar2;
  float fVar3;
  longlong *plVar4;
  double *pdVar5;
  byte bVar6;
  ushort uVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  ulonglong *puVar12;
  uint *puVar13;
  byte *pbVar14;
  byte *pbVar15;
  double *pdVar16;
  longlong lVar17;
  char *pcVar18;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar19;
  ushort uVar20;
  longlong lVar21;
  undefined *puVar22;
  undefined *puVar23;
  undefined *puVar24;
  short sVar25;
  byte bVar26;
  double *pdVar27;
  char cVar28;
  int *piVar29;
  int iVar30;
  double *pdVar31;
  ushort *puVar32;
  double *pdVar33;
  longlong unaff_GS_OFFSET;
  bool bVar34;
  undefined auStack_198 [32];
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined8 uStack_168;
  undefined8 uStack_160;
  uint uStack_158;
  uint uStack_148;
  uint uStack_144;
  uint uStack_120;
  undefined4 uStack_11c;
  longlong lStack_118;
  double **ppdStack_110;
  longlong lStack_108;
  ulonglong uStack_50;
  
  puVar23 = auStack_198;
  puVar24 = auStack_198;
  uStack_50 = _DAT_ ^ (ulonglong)&uStack_148;
  lVar21 = *(longlong *)(param_2 + 0x10);
  bVar6 = 0;
  iVar30 = 1;
  uStack_144 = param_6;
  ppdStack_110 = (double **)((ulonglong)(*(ushort *)(lVar21 + 0x28) - 1) * 0x10 + **param_1);
  piVar29 = (int *)((longlong)param_4 * 0x10 + lVar21);
  lStack_118 = lVar21;
  lStack_108 = param_2;
  if (param_4 == 0) {
    bVar6 = *(byte *)(lVar21 + 0x20) >> 1;
LAB_:
    bVar6 = bVar6 & 1;
  }
  else {
    if (param_4 == 1) {
      bVar6 = *(byte *)(lVar21 + 0x20);
      goto LAB_;
    }
    uStack_178 = (double *)0x15a5d38;
    (*_DAT_)(1,0x19aab90,0x19d6ba8,0x22c);
  }
  uVar20 = 0;
  uVar7 = *(ushort *)(lVar21 + 0x38);
  puVar1 = (ushort *)(param_3 + 1);
  uStack_11c = 0xffff;
  if (*param_3 == 0) {
    if ((bVar6 != 0) || ((*(byte *)((longlong)piVar29 + 6) & 0x10) != 0)) {
      pbVar15 = *(byte **)(param_3 + 4);
      iVar8 = iVar30;
      if ((*pbVar15 & 0x10) == 0) {
        if ((1 << (*pbVar15 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
        if (bVar6 != 0) goto LAB_;
      }
      else {
        uVar11 = *(uint *)(param_3 + 8);
        if ((int)uVar11 <= *piVar29) {
LAB_:
          uVar20 = ~(*(ushort *)((longlong)piVar29 + 6) >> 4) & 1;
          iVar8 = 0;
          goto LAB_;
        }
        if ((uint)*(ushort *)(pbVar15 + uVar11) < (uint)*(ushort *)(piVar29 + 1)) goto LAB_;
        if (bVar6 == 0) goto LAB_;
        uVar10 = *(ushort *)(piVar29 + 1) - 1;
        uVar20 = pbVar15[(ulonglong)(uVar10 >> 3) + (ulonglong)uVar11 + 2] >> ((byte)uVar10 & 7) & 1
        ;
LAB_:
        if (uVar20 != 0) {
          uStack_148 = 0;
          pdVar31 = (double *)0x0;
          pdVar33 = (double *)0x0;
          goto LAB_;
        }
      }
      if ((iVar8 == 0) && ((*(byte *)((longlong)piVar29 + 6) & 0x10) != 0)) {
        uStack_148 = **(uint **)(piVar29 + 2);
        pdVar31 = (double *)(*(uint **)(piVar29 + 2) + 1);
        pdVar33 = (double *)(ulonglong)uStack_148;
        goto LAB_;
      }
    }
LAB_:
    iVar8 = *piVar29;
    if (iVar8 < 0) {
      if (*(int *)(param_3 + 2) == 0) {
        pbVar15 = *(byte **)(param_3 + 4);
        uVar11 = *(uint *)(param_3 + 8);
        uVar19 = (ulonglong)uVar11;
        *puVar1 = 0;
        *(uint *)(param_3 + 10) = uVar11;
        bVar6 = *pbVar15;
        if ((bVar6 & 0x10) != 0) {
          uVar11 = uVar11 + 2 + (*(ushort *)(pbVar15 + uVar19) + 7 >> 3);
          uVar19 = (ulonglong)uVar11;
          *(uint *)(param_3 + 10) = uVar11;
          bVar6 = *pbVar15;
        }
        if ((bVar6 & 0x20) == 0) {
          *(int *)(param_3 + 2) = (int)uVar19;
          param_3[0xe] = 0;
          *(int *)(param_3 + 0xc) = (int)uVar19;
        }
        else {
          puVar32 = (ushort *)(pbVar15 + uVar19);
          uVar7 = *puVar32;
          param_3[0xe] = uVar7;
          if (uVar7 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar21 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar21 != 0)) &&
               ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                (*(char *)(lVar21 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_178 = (double *)0x0;
                (*_DAT_)(1,0x1829858,0x1949528,0x80f);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),3);
            uVar7 = param_3[0xe];
            uVar19 = (ulonglong)*(uint *)(param_3 + 10);
          }
          uVar11 = (int)uVar19 + (uVar7 + 1) * 2;
          *(uint *)(param_3 + 0xc) = uVar11;
          if (0x1f9e < uVar11) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar21 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar21 != 0 &&
                ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                 (*(char *)(lVar21 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_178 = (double *)0x0;
                (*_DAT_)(1,0x1829858,0x1949528,0x816);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),4);
            uVar7 = param_3[0xe];
            uVar11 = *(uint *)(param_3 + 0xc);
          }
          uVar19 = (ulonglong)uVar7;
          uVar7 = puVar32[uVar19];
          *(uint *)(param_3 + 2) = uVar7 & 0x7fff;
          if ((uVar7 & 0x7fff) < uVar11) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar21 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar21 != 0)) &&
               ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
                (*(char *)(lVar21 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_178 = (double *)0x0;
                (*_DAT_)(1,0x1829858,0x1949528,0x81d);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),4);
            uVar19 = (ulonglong)(ushort)param_3[0xe];
          }
          if ((short)puVar32[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
            lVar21 = *(longlong *)(param_3 + 4);
            do {
              if ((int)uVar19 == 1) {
                uVar11 = *(uint *)(param_3 + 0xc);
                uVar10 = uVar11;
LAB_:
                if ((*(ushort *)((ulonglong)*(uint *)(param_3 + 10) + lVar21 + uVar19 * 2) & 0x7fff)
                    < uVar11) goto LAB_;
              }
              else {
                uVar10 = *(uint *)(param_3 + 0xc);
                uVar11 = *(ushort *)((ulonglong)*(uint *)(param_3 + 10) + lVar21 + -2 + uVar19 * 2)
                         & 0x7fff;
                if (uVar10 <= uVar11) goto LAB_;
LAB_:
                func_0x(lVar21,7);
                uVar10 = *(uint *)(param_3 + 0xc);
              }
              if ((uVar11 < uVar10) || (*(uint *)(param_3 + 2) < uVar11)) goto LAB_;
              lVar21 = *(longlong *)(param_3 + 4);
              if (*(ushort *)(lVar21 + (ulonglong)uVar11) == 5) {
                *puVar1 = *puVar1 | 2;
                param_3[0xe] = param_3[0xe] + -1;
                param_3[0x15] = (short)uVar11;
                lVar21 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(param_3 + 4);
                uVar7 = param_3[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar21 + 2) & 0x4000) != 0) {
                  uVar7 = *(ushort *)(lVar21 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
                }
                param_3[0x16] = uVar7;
                param_3[0x16] = (uVar7 ^ *(ushort *)(lVar21 + 2)) & 0x7ff ^ uVar7;
                uVar19 = (ulonglong)*(uint *)(param_3 + 2);
                pbVar15 = *(byte **)(param_3 + 4);
                goto LAB_;
              }
              if (*(ushort *)(lVar21 + (ulonglong)uVar11) < 0x400) break;
              *puVar1 = *puVar1 | 1;
              uVar7 = param_3[0xe] - 1;
              param_3[0xe] = uVar7;
              if ((uVar7 == 0) ||
                 (uVar19 = (ulonglong)uVar7, -1 < (short)puVar32[(ulonglong)(uVar7 - 1) + 1]))
              break;
            } while( true );
          }
          uVar19 = (ulonglong)*(uint *)(param_3 + 2);
          pbVar15 = *(byte **)(param_3 + 4);
        }
LAB_:
        if ((*pbVar15 & 0x40) == 0) {
          *(undefined4 *)(param_3 + 0x13) = 0;
        }
        else {
          *(int *)(param_3 + 0x13) = (int)uVar19;
          *(int *)(param_3 + 2) = (int)uVar19 + 0xe;
          puVar12 = (ulonglong *)func_0x(puVar1);
          iVar8 = 0;
          uVar19 = *puVar12;
          uVar20 = (ushort)(uVar19 >> 0x30);
          uVar7 = uVar20;
          if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
            uVar7 = uVar20 & 0xdfff;
            if ((uVar19 & 0x4000000000000000) != 0) {
              uVar7 = uVar20 | 0x2000;
            }
          }
          if (uVar7 == 0xfffc) {
            iVar8 = (int)((uVar19 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar8;
          uVar19 = (ulonglong)*(uint *)(param_3 + 2);
        }
        iVar8 = (int)uVar19;
        if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
           (*(ulonglong *)(param_3 + 0xf) < uVar19 + *(longlong *)(param_3 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar21 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar21 != 0 &&
               (lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0)) &&
              (*(char *)(lVar21 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_178 = (double *)0x0;
              (*_DAT_)(1,0x1829858,0x1949528,0x877);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),0x12);
          iVar8 = *(int *)(param_3 + 2);
        }
        if (0x3f3b < iVar8 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar21 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar21 != 0 &&
              ((lVar21 = *(longlong *)(lVar21 + 0x60), lVar21 != 0 &&
               (*(char *)(lVar21 + 0x499) != '\0')))))) {
            if ((DAT_ != '\0') || ((DAT_ & 2) != 0)) {
              uStack_178 = (double *)0x0;
              (*_DAT_)(1,0x1829858,0x1949528,0x87c);
              func_0x(*(undefined8 *)(param_3 + 4),5);
              goto LAB_;
            }
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          func_0x(*(undefined8 *)(param_3 + 4),5);
        }
      }
LAB_:
      pdVar33 = (double *)0x0;
      sVar25 = -*(short *)piVar29;
      if ((*(byte *)((longlong)piVar29 + 6) & 0x10) != 0) {
        bVar6 = **(byte **)(param_3 + 4);
        if ((bVar6 & 0x10) == 0) {
          if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
            uStack_148 = **(uint **)(piVar29 + 2);
            pdVar31 = (double *)(*(uint **)(piVar29 + 2) + 1);
            pdVar33 = (double *)(ulonglong)uStack_148;
            goto LAB_;
          }
        }
        else if (((int)*(uint *)(param_3 + 8) <= *piVar29) ||
                (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                 *(ushort *)(piVar29 + 1))) goto LAB_;
      }
      pdVar31 = *(double **)(param_3 + 4);
      lVar21 = (longlong)sVar25;
      if ((uint)(int)sVar25 <= (uint)(ushort)param_3[0xe]) {
        uVar11 = *(uint *)(param_3 + 10);
        if (sVar25 == 1) {
          uVar10 = *(uint *)(param_3 + 0xc);
          uVar11 = *(ushort *)((longlong)pdVar31 + lVar21 * 2 + (ulonglong)uVar11) & 0x7fff;
LAB_:
          if (uVar11 < uVar10) goto LAB_;
        }
        else {
          puVar1 = (ushort *)((longlong)pdVar31 + lVar21 * 2 + (ulonglong)uVar11);
          uVar10 = *(ushort *)((longlong)pdVar31 + lVar21 * 2 + ((ulonglong)uVar11 - 2)) & 0x7fff;
          pdVar31 = *(double **)(param_3 + 4);
          uVar11 = *puVar1 & 0x7fff;
          if (*(uint *)(param_3 + 0xc) <= uVar10) goto LAB_;
LAB_:
          func_0x(pdVar31,7);
          pdVar31 = *(double **)(param_3 + 4);
        }
        pdVar31 = (double *)((longlong)pdVar31 + (ulonglong)uVar10);
        pdVar33 = (double *)(ulonglong)(uVar11 - uVar10);
      }
LAB_:
      uStack_148 = (uint)pdVar33;
    }
    else {
      uVar20 = *(ushort *)((longlong)piVar29 + 6);
      if ((uVar20 & 8) == 0) {
        uStack_148 = (uint)uVar7;
        if ((uVar20 & 0x10) != 0) {
          bVar6 = **(byte **)(param_3 + 4);
          if ((bVar6 & 0x10) == 0) {
            if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
              uVar11 = **(uint **)(piVar29 + 2);
              pdVar33 = (double *)(ulonglong)uVar11;
              pdVar31 = (double *)(*(uint **)(piVar29 + 2) + 1);
              if ((uStack_148 != 0) && (uVar11 != uStack_148)) {
                uStack_178 = (double *)0x0;
                (*_DAT_)(1,0x19d75c8,0x19d5fc8,0x381);
                uStack_148 = uVar11;
                goto LAB_;
              }
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_3 + 8) <= iVar8) ||
                  (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                   *(ushort *)(piVar29 + 1))) goto LAB_;
        }
        pdVar31 = (double *)((longlong)*piVar29 + *(longlong *)(param_3 + 4));
        pdVar33 = (double *)(ulonglong)uVar7;
      }
      else {
        pdVar31 = (double *)0x15ae294;
        pdVar33 = (double *)0x1;
        uStack_148 = 1;
        if ((*(byte *)((longlong)iVar8 + *(longlong *)(param_3 + 4)) &
            (byte)(1 << ((byte)uVar20 & 7))) == 0) {
          pdVar31 = (double *)0x15ae8b8;
        }
      }
    }
  }
  else {
    uStack_178 = (double *)&uStack_120;
    uStack_120 = 0;
    pdVar31 = (double *)func_0x(puVar1,piVar29,(double *)(ulonglong)uVar7,&uStack_148);
    if ((((*param_3 != 0) && (plVar4 = *(longlong **)(param_3 + 8), plVar4 != (longlong *)0x0)) &&
        (*plVar4 != 0)) &&
       (((*(byte *)((longlong)piVar29 + 6) & 8) == 0 && ((uStack_120 & 1) == 0)))) {
      if ((pdVar31 == (double *)0x0) || (pdVar31 == (double *)0x15ae294)) {
        pdVar31 = (double *)0x0;
        uStack_148 = 0;
        pdVar33 = pdVar31;
        goto LAB_;
      }
      uStack_160 = (double *)CONCAT44(uStack_160._4_4_,uStack_120);
      uStack_170 = (double *)CONCAT44(uStack_170._4_4_,uStack_144);
      uStack_178 = param_5;
      uStack_168 = &uStack_148;
      pdVar31 = (double *)func_0x(plVar4,piVar29,pdVar31,uStack_148);
    }
    pdVar33 = (double *)(ulonglong)uStack_148;
  }
LAB_:
  lVar21 = lStack_118;
  uVar11 = (uint)pdVar33;
  if (*(char *)(lStack_108 + 0x24) == '\0') {
    lVar21 = -0xf13af0;
    if (pdVar31 == (double *)0x0) {
      lVar17 = 0;
      uVar10 = uStack_148;
    }
    else {
      lVar17 = func_0x();
      puVar23 = auStack_198 + -lVar17;
      uVar7 = *(ushort *)(lStack_118 + 0x38);
      lVar17 = (longlong)&uStack_148 + -lVar17;
      if (0x1f9e < uVar7) {
        uVar7 = 0x1f9e;
      }
      uVar9 = *(byte *)(lStack_118 + 0x34) - 0x30;
      uVar11 = (uint)uVar7;
      uVar10 = uVar11;
      uStack_144 = uVar11;
      if (uVar9 < 0xc0) {
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)
                      *(uint *)(lVar21 + 0x101588c +
                               (ulonglong)*(byte *)(lVar21 + 0x10158c0 + (longlong)(int)uVar9) * 4)
                     + lVar21);
                    /* WARNING: Could not recover jumptable at 0x00100fb4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return;
      }
    }
    uStack_148 = uVar10;
    puVar24 = puVar23;
    if (lVar17 == 0) {
      bVar34 = *ppdStack_110 == (double *)0x0;
    }
    else {
      if (*ppdStack_110 == (double *)0x0) goto LAB_;
      uVar10 = *(byte *)(lStack_118 + 0x34) - 0xa5;
      if (uVar10 < 0x4b) {
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)
                      *(uint *)(lVar21 + 0x10159c4 +
                               (ulonglong)*(byte *)(lVar21 + 0x10159d0 + (longlong)(int)uVar10) * 4)
                     + lVar21);
                    /* WARNING: Could not recover jumptable at 0x001015ce. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return;
      }
      if (uVar11 != 0) {
        if (*(short *)((longlong)ppdStack_110 + 0xc) != 0) {
          uVar11 = *(byte *)(lStack_118 + 0x34) - 0x24;
          uStack_120 = (uint)*(ushort *)((longlong)ppdStack_110 + 0xc);
          if (uVar11 < 0xcd) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)(lVar21 + 0x1015a1c +
                                   (ulonglong)*(byte *)(lVar21 + 0x1015a68 + (longlong)(int)uVar11)
                                   * 4) + lVar21);
                    /* WARNING: Could not recover jumptable at 0x0010165e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
        }
        goto LAB_;
      }
      bVar34 = *(short *)((longlong)ppdStack_110 + 0xc) == 0;
    }
    puVar22 = puVar23;
    if (!bVar34) goto LAB_;
    goto LAB_;
  }
  pdVar27 = (double *)0x0;
  cVar28 = *(char *)(lStack_118 + 0x34);
  if (cVar28 != -0x53) {
    if (cVar28 != -0x51) {
      if ((cVar28 == -0x19) || (cVar28 == -0x11)) {
        if (*(longlong *)(lStack_118 + 0x100) == 0) {
          func_0x(lStack_118);
        }
        pdVar27 = *(double **)(lVar21 + 0x100);
        cVar28 = *(char *)(lVar21 + 0x34);
      }
      puVar24 = auStack_198;
      if ((pdVar31 == (double *)0x0) || (puVar24 = auStack_198, *ppdStack_110 == (double *)0x0))
      goto LAB_;
      uStack_168 = (uint *)CONCAT71(uStack_168._1_7_,
                                    *(char *)((longlong)ppdStack_110 + 0xe) == -0x7a);
      uStack_178 = (double *)
                   CONCAT44(uStack_178._4_4_,(uint)*(ushort *)((longlong)ppdStack_110 + 0xc));
      uStack_170 = pdVar27;
      iVar30 = func_0x(cVar28,pdVar31,pdVar33);
      puVar24 = auStack_198;
      puVar22 = auStack_198;
      if (iVar30 != 0) goto LAB_;
      goto LAB_;
    }
    if (*(longlong *)(lStack_118 + 0x100) == 0) {
      func_0x(lStack_118);
    }
    pdVar27 = *(double **)(lVar21 + 0x100);
  }
  pdVar5 = *ppdStack_110;
  if ((pdVar31 == (double *)0x0) || (puVar24 = auStack_198, pdVar5 == (double *)0x0))
  goto LAB_;
  uVar7 = *(ushort *)((longlong)ppdStack_110 + 0xc);
  pdVar16 = (double *)(ulonglong)uVar7;
  uVar10 = (uint)uVar7;
  puVar22 = auStack_198;
  switch(*(undefined *)(lVar21 + 0x34)) {
  case 0x24:
    bVar6 = func_0x(pdVar31,pdVar33,pdVar5,pdVar16);
    goto code_r0x00100e9f;
  case 0x28:
    pcVar18 = (char *)((longlong)pdVar31 + 2);
    iVar30 = 2;
    do {
      if (*pcVar18 != pcVar18[(longlong)pdVar5 - (longlong)pdVar31]) {
        puVar24 = auStack_198;
        if (*(byte *)((longlong)pdVar5 + (longlong)iVar30) <=
            *(byte *)((longlong)iVar30 + (longlong)pdVar31)) goto code_r0x00100f2a;
        break;
      }
      iVar30 = iVar30 + -1;
      pcVar18 = pcVar18 + -1;
      puVar24 = auStack_198;
    } while (-1 < (longlong)pcVar18 - (longlong)pdVar31);
    goto LAB_;
  case 0x29:
    iVar30 = uVar11 - 1;
    puVar22 = auStack_198;
    if (-1 < iVar30) {
      pcVar18 = (char *)((longlong)iVar30 + (longlong)pdVar31);
      do {
        if (*pcVar18 != pcVar18[(longlong)pdVar5 - (longlong)pdVar31]) {
          puVar24 = auStack_198;
          if (*(byte *)((longlong)pdVar5 + (longlong)iVar30) <=
              *(byte *)((longlong)iVar30 + (longlong)pdVar31)) goto code_r0x00100f2a;
          break;
        }
        iVar30 = iVar30 + -1;
        pcVar18 = pcVar18 + -1;
        puVar24 = auStack_198;
      } while (-1 < (longlong)pcVar18 - (longlong)pdVar31);
      goto LAB_;
    }
    break;
  case 0x2a:
    uVar19 = (ulonglong)(uVar11 - 4);
    puVar13 = (uint *)((longlong)pdVar31 + uVar19);
    uVar10 = *puVar13;
    bVar34 = uVar10 < *(uint *)(uVar19 + (longlong)pdVar5);
    if (uVar10 != *(uint *)(uVar19 + (longlong)pdVar5)) {
code_r0x00100dec:
      iVar8 = 4;
      if (bVar34) {
        iVar8 = iVar30;
      }
      puVar24 = auStack_198;
      if (iVar8 != 4) goto LAB_;
      goto code_r0x00100f2a;
    }
    pbVar15 = (byte *)((uVar19 - 1) + (longlong)pdVar5);
    puVar22 = auStack_198;
    if (uVar11 - 4 != 0) {
      pbVar14 = pbVar15;
      do {
        bVar34 = pbVar14[(longlong)puVar13 + (-1 - (longlong)pbVar15)] < *pbVar14;
        if (pbVar14[(longlong)puVar13 + (-1 - (longlong)pbVar15)] != *pbVar14)
        goto code_r0x00100dec;
        pbVar14 = pbVar14 + -1;
        uVar11 = (int)uVar19 - 1;
        uVar19 = (ulonglong)uVar11;
        puVar24 = auStack_198;
      } while (uVar11 != 0);
      goto LAB_;
    }
    break;
  case 0x2b:
    uVar19 = (ulonglong)(uVar11 - 6);
    bVar34 = *(uint *)(uVar19 + (longlong)pdVar31) < *(uint *)(uVar19 + (longlong)pdVar5);
    if (*(uint *)(uVar19 + (longlong)pdVar31) != *(uint *)(uVar19 + (longlong)pdVar5))
    goto code_r0x00100dec;
    pbVar15 = (byte *)((uVar19 - 1) + (longlong)pdVar5);
    puVar22 = auStack_198;
    if (uVar11 - 6 != 0) {
      lVar21 = uVar19 - (longlong)pbVar15;
      do {
        bVar34 = pbVar15[(longlong)pdVar31 + lVar21 + -1] < *pbVar15;
        if (pbVar15[(longlong)pdVar31 + lVar21 + -1] != *pbVar15) goto code_r0x00100dec;
        pbVar15 = pbVar15 + -1;
        uVar11 = (int)uVar19 - 1;
        uVar19 = (ulonglong)uVar11;
        puVar24 = auStack_198;
      } while (uVar11 != 0);
      goto LAB_;
    }
    break;
  case 0x30:
    if (*(byte *)pdVar5 < *(byte *)pdVar31) goto code_r0x00100f2a;
    puVar24 = auStack_198;
    if (*(byte *)pdVar5 <= *(byte *)pdVar31) goto LAB_;
    goto code_r0x00100f36;
  case 0x34:
    if (*(short *)pdVar31 <= *(short *)pdVar5) {
      puVar24 = auStack_198;
      if (*(short *)pdVar5 <= *(short *)pdVar31) goto LAB_;
      goto code_r0x00100f36;
    }
    goto code_r0x00100f2a;
  case 0x38:
  case 0x7a:
    if ((int)*(float *)pdVar31 <= (int)*(float *)pdVar5) {
      puVar24 = auStack_198;
      if ((int)*(float *)pdVar5 <= (int)*(float *)pdVar31) goto LAB_;
      goto code_r0x00100f36;
    }
    goto code_r0x00100f2a;
  case 0x3a:
    fVar3 = *(float *)pdVar31;
    fVar2 = *(float *)pdVar5;
    if ((uint)fVar2 > (uint)fVar3 || fVar3 == fVar2) {
      puVar24 = auStack_198;
      if ((uint)fVar2 <= (uint)fVar3) goto LAB_;
      goto code_r0x00100f36;
    }
    goto code_r0x00100f2a;
  case 0x3b:
    if (*(float *)pdVar31 <= *(float *)pdVar5) {
      puVar24 = auStack_198;
      if (*(float *)pdVar5 <= *(float *)pdVar31) goto LAB_;
      goto code_r0x00100f36;
    }
    goto code_r0x00100f2a;
  case 0x3c:
  case 0x3d:
  case 0x7f:
    if ((longlong)*pdVar31 <= (longlong)*pdVar5) {
      puVar24 = auStack_198;
      if ((longlong)*pdVar5 <= (longlong)*pdVar31) goto LAB_;
      goto code_r0x00100f36;
    }
    goto code_r0x00100f2a;
  case 0x3e:
    if (*pdVar31 <= *pdVar5) {
      puVar24 = auStack_198;
      if (*pdVar5 <= *pdVar31) goto LAB_;
      goto code_r0x00100f36;
    }
    goto code_r0x00100f2a;
  case 0x62:
    bVar6 = (*pcRam00000000014a5270)(pdVar31,pdVar33,pdVar5,pdVar16);
code_r0x00100e9f:
    puVar22 = auStack_198;
    if ((bVar6 & 2) == 0) {
      puVar24 = auStack_198;
      if ((bVar6 & 4) == 0) goto LAB_;
      goto code_r0x00100f2a;
    }
    break;
  case 0x68:
    if (*(byte *)pdVar5 < *(byte *)pdVar31) goto code_r0x00100f2a;
    puVar22 = auStack_198;
    if (*(byte *)pdVar31 < *(byte *)pdVar5) goto code_r0x00100f36;
    break;
  case 0x6a:
  case 0x6c:
    if (uVar11 == 0) {
      puVar22 = auStack_198;
      if (uVar7 != 0) {
code_r0x00100c09:
        puVar22 = auStack_198;
        if (*(char *)((longlong)ppdStack_110 + 0xe) != -0x7a) {
          if (uVar11 == 0) {
            puVar24 = auStack_198;
            if (uVar10 == 0) goto LAB_;
            goto code_r0x00100f36;
          }
          goto code_r0x00100f2a;
        }
      }
    }
    else {
      if (uVar10 == 0) goto code_r0x00100c09;
      bVar26 = *(byte *)pdVar31 & 1;
      bVar6 = *(byte *)pdVar5 & 1;
      if (bVar26 >= bVar6 && bVar26 != bVar6) goto code_r0x00100f2a;
      if (bVar26 < bVar6) goto code_r0x00100f36;
      if (uVar11 != uVar7) goto joined_r0x00100f18;
      lVar21 = (longlong)(int)uVar11;
      iVar30 = uVar11 - 4;
      puVar13 = (uint *)((longlong)pdVar31 + lVar21);
      if (bVar26 == 0) {
        puVar22 = auStack_198;
        if (0 < iVar30) {
          lVar21 = lVar21 - (longlong)puVar13;
          do {
            uVar11 = *(uint *)((longlong)pdVar5 + lVar21 + -4 + (longlong)puVar13);
            puVar13 = puVar13 + -1;
            iVar30 = iVar30 + -4;
            uVar10 = *puVar13;
            if (uVar10 >= uVar11 && uVar10 != uVar11) goto code_r0x00100f36;
            if (uVar10 < uVar11) goto code_r0x00100f2a;
            puVar24 = auStack_198;
          } while (0 < iVar30);
          goto LAB_;
        }
      }
      else {
        puVar22 = auStack_198;
        if (0 < iVar30) {
          lVar21 = lVar21 - (longlong)puVar13;
          do {
            uVar11 = *(uint *)((longlong)pdVar5 + lVar21 + -4 + (longlong)puVar13);
            puVar13 = puVar13 + -1;
            iVar30 = iVar30 + -4;
            uVar10 = *puVar13;
            if (uVar10 >= uVar11 && uVar10 != uVar11) goto code_r0x00100f2a;
            if (uVar10 < uVar11) goto code_r0x00100f36;
            puVar24 = auStack_198;
          } while (0 < iVar30);
          goto LAB_;
        }
      }
    }
    break;
  case 0xa5:
  case 0xad:
  case 0xf0:
    iVar30 = func_0x(pdVar31,pdVar33,pdVar5,pdVar16);
    goto joined_r0x00100e7a;
  case 0xa7:
  case 0xaf:
  case 0xe7:
  case 0xef:
    uStack_168 = (uint *)CONCAT44(uStack_168._4_4_,uVar11);
    uStack_178 = pdVar27;
    uStack_170 = pdVar31;
    uStack_160 = pdVar5;
    uStack_158 = uVar10;
    iVar30 = (*(code *)pdVar27[0xc])
                       (pdVar27[8],*(float *)((longlong)pdVar27 + 0x54),pdVar27[9],
                        *(float *)(pdVar27 + 10));
joined_r0x00100e7a:
    if (0 < iVar30) goto code_r0x00100f2a;
    puVar24 = auStack_198;
    if (-1 < iVar30) goto LAB_;
code_r0x00100f36:
    puVar22 = auStack_198;
    break;
  case 0xbd:
    if ((int)uVar11 < (int)(uint)uVar7) {
      pdVar16 = pdVar33;
    }
    if ((int)pdVar16 != 0) {
      lVar21 = (longlong)pdVar5 - (longlong)pdVar31;
      do {
        bVar26 = *(byte *)(lVar21 + (longlong)pdVar31);
        uVar9 = (int)pdVar16 - 1;
        pdVar16 = (double *)(ulonglong)uVar9;
        bVar6 = *(byte *)pdVar31;
        if (bVar6 >= bVar26 && bVar6 != bVar26) goto code_r0x00100f2a;
        if (bVar6 < bVar26) goto code_r0x00100f36;
        pdVar31 = (double *)((longlong)pdVar31 + 1);
      } while (uVar9 != 0);
    }
    if (uVar11 <= uVar10) {
joined_r0x00100f18:
      puVar24 = auStack_198;
      if (uVar7 <= uVar11) goto LAB_;
      goto code_r0x00100f36;
    }
code_r0x00100f2a:
    puVar24 = auStack_198;
    goto LAB_;
  }
LAB_:
  puVar24 = puVar22;
LAB_:
  uVar19 = uStack_50 ^ (ulonglong)&uStack_148;
  *(undefined8 *)(puVar24 + -8) = 0x101c6c;
  func_0x(uVar19);
  return;
}

