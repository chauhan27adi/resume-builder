
ulonglong FUN_(ushort *param_1)

{
  code *pcVar1;
  ulonglong uVar2;
  
  if (*(int *)(param_1 + 1) != 0) {
    return (ulonglong)(*param_1 >> 1 & 1);
  }
  pcVar1 = (code *)swi(3);
  uVar2 = (*pcVar1)();
  return uVar2;
}

