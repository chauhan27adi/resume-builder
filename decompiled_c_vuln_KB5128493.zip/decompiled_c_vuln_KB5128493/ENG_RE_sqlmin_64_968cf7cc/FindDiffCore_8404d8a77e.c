
/* WARNING: Control flow encountered bad instruction data */

undefined8
FUN_(longlong param_1,longlong param_2,ulonglong param_3,ulonglong param_4,uint param_5,
            uint param_6)

{
  char *pcVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  param_3 = param_3 & 0xffffffff;
  param_4 = param_4 & 0xffffffff;
  uVar3 = (ulonglong)param_5;
  if (param_3 < uVar3) {
    lVar2 = param_3 - param_4;
    pcVar1 = (char *)(param_2 + param_4);
    do {
      if (param_6 <= param_4) {
        return;
      }
      if (pcVar1[(lVar2 - param_2) + param_1] != *pcVar1) break;
      param_3 = param_3 + 1;
      param_4 = param_4 + 1;
      pcVar1 = pcVar1 + 1;
    } while (param_3 < uVar3);
  }
  if ((param_3 == uVar3) && (param_4 == param_6)) {
    return 0;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

