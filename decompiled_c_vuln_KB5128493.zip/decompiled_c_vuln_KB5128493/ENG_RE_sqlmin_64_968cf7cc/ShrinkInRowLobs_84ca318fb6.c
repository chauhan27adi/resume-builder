
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  longlong lVar1;
  byte bVar2;
  ushort uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  ulonglong *puVar8;
  longlong lVar9;
  longlong lVar10;
  ulonglong uVar11;
  ushort *puVar12;
  ushort *puVar13;
  uint uVar14;
  ushort uVar15;
  ushort uVar16;
  uint uVar17;
  byte *pbVar18;
  int iVar19;
  longlong unaff_GS_OFFSET;
  
  lVar1 = *(longlong *)(param_1 + 0x58);
  if (*param_2 == 0) {
    uVar4 = func_0x();
  }
  else {
    uVar4 = (uint)(ushort)param_2[1];
  }
  uVar14 = 0;
  if (0 < (int)uVar4) {
    do {
      if ((~uVar14 & 0xc0000000) == 0x80000000) {
        lVar7 = func_0x
                          (**(undefined8 **)(*(longlong *)(lVar1 + 8) + 0x160),~uVar14 & 0x1fffffff)
        ;
      }
      else {
        lVar7 = func_0x(*(undefined8 *)(*(longlong *)(lVar1 + 8) + 0x160));
      }
      if ((lVar7 != 0) &&
         ((*(short *)(lVar7 + 0x38) == -1 ||
          (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar7 + 0x34) + 0x81e680) + 0x11d3cf8
                    ) != '\0')))) {
        func_0x(param_1,lVar7,param_2);
      }
      uVar14 = uVar14 + 1;
    } while ((int)uVar14 < (int)uVar4);
  }
  puVar12 = (ushort *)(param_2 + 1);
  iVar19 = -1;
  uVar4 = 0;
  iVar5 = func_0x(param_2);
  if (0 < (longlong)iVar5) {
    lVar7 = 0;
    do {
      if (*(int *)(param_2 + 2) == 0) {
        pbVar18 = *(byte **)(param_2 + 4);
        uVar14 = *(uint *)(param_2 + 8);
        uVar11 = (ulonglong)uVar14;
        *puVar12 = 0;
        *(uint *)(param_2 + 10) = uVar14;
        bVar2 = *pbVar18;
        if ((bVar2 & 0x10) != 0) {
          uVar14 = uVar14 + 2 + (*(ushort *)(pbVar18 + uVar11) + 7 >> 3);
          uVar11 = (ulonglong)uVar14;
          *(uint *)(param_2 + 10) = uVar14;
          bVar2 = *pbVar18;
        }
        if ((bVar2 & 0x20) == 0) {
          *(int *)(param_2 + 2) = (int)uVar11;
          param_2[0xe] = 0;
          *(int *)(param_2 + 0xc) = (int)uVar11;
        }
        else {
          puVar13 = (ushort *)(pbVar18 + uVar11);
          uVar3 = *puVar13;
          param_2[0xe] = uVar3;
          if (uVar3 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar9 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar9 != 0)) &&
               ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                (*(char *)(lVar9 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0xa997a8,0xbb9478,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),3);
            uVar11 = (ulonglong)*(uint *)(param_2 + 10);
            uVar3 = param_2[0xe];
          }
          uVar14 = (int)uVar11 + (uVar3 + 1) * 2;
          *(uint *)(param_2 + 0xc) = uVar14;
          if (0x1f9e < uVar14) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar9 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar9 != 0 &&
                ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                 (*(char *)(lVar9 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xa997a8,0xbb9478,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar3 = param_2[0xe];
            uVar14 = *(uint *)(param_2 + 0xc);
          }
          uVar11 = (ulonglong)uVar3;
          uVar3 = puVar13[uVar11];
          *(uint *)(param_2 + 2) = uVar3 & 0x7fff;
          if ((uVar3 & 0x7fff) < uVar14) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar9 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar9 != 0)) &&
               ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                (*(char *)(lVar9 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xa997a8,0xbb9478,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar11 = (ulonglong)(ushort)param_2[0xe];
          }
          if ((short)puVar13[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
            pbVar18 = *(byte **)(param_2 + 4);
            do {
              if ((int)uVar11 == 1) {
                uVar14 = *(uint *)(param_2 + 0xc);
                uVar17 = uVar14;
LAB_:
                if ((*(ushort *)(pbVar18 + uVar11 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff
                    ) < uVar14) goto LAB_;
              }
              else {
                uVar17 = *(uint *)(param_2 + 0xc);
                uVar14 = *(ushort *)
                          (pbVar18 + uVar11 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) & 0x7fff
                ;
                if (uVar17 <= uVar14) goto LAB_;
LAB_:
                func_0x(pbVar18,7);
                uVar17 = *(uint *)(param_2 + 0xc);
              }
              if ((uVar14 < uVar17) || (*(uint *)(param_2 + 2) < uVar14)) goto LAB_;
              pbVar18 = *(byte **)(param_2 + 4);
              if (*(ushort *)(pbVar18 + uVar14) == 5) {
                *puVar12 = *puVar12 | 2;
                param_2[0xe] = param_2[0xe] + -1;
                uVar17 = uVar14 & 0xffff;
                param_2[0x15] = (short)uVar14;
                uVar3 = param_2[0x16] & 0xc7ffU;
                if ((*(ushort *)(pbVar18 + (ulonglong)uVar17 + 2) >> 0xe & 1) != 0) {
                  uVar3 = *(ushort *)(pbVar18 + (ulonglong)uVar17 + 2) & 0x3800 |
                          param_2[0x16] & 0xc7ffU;
                }
                param_2[0x16] = uVar3;
                param_2[0x16] =
                     (uVar3 ^ *(ushort *)(pbVar18 + (ulonglong)uVar17 + 2)) & 0x7ff ^ uVar3;
                goto LAB_;
              }
              if (*(ushort *)(pbVar18 + uVar14) < 0x400) goto LAB_;
              *puVar12 = *puVar12 | 1;
              uVar3 = param_2[0xe] - 1;
              param_2[0xe] = uVar3;
              if (uVar3 == 0) goto LAB_;
              uVar11 = (ulonglong)uVar3;
            } while ((short)puVar13[(ulonglong)(uVar3 - 1) + 1] < 0);
            uVar11 = (ulonglong)*(uint *)(param_2 + 2);
          }
          else {
LAB_:
            uVar11 = (ulonglong)*(uint *)(param_2 + 2);
            pbVar18 = *(byte **)(param_2 + 4);
          }
        }
        iVar6 = 0;
        if ((*pbVar18 & 0x40) == 0) {
          *(undefined4 *)(param_2 + 0x13) = 0;
        }
        else {
          *(int *)(param_2 + 0x13) = (int)uVar11;
          *(int *)(param_2 + 2) = (int)uVar11 + 0xe;
          puVar8 = (ulonglong *)func_0x(puVar12);
          uVar16 = (ushort)(*puVar8 >> 0x30);
          uVar3 = uVar16;
          if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
            uVar3 = uVar16 & 0xdfff;
            if ((uVar16 >> 0xe & 1) != 0) {
              uVar3 = uVar16 | 0x2000;
            }
          }
          if (uVar3 == 0xfffc) {
            iVar6 = (int)((*puVar8 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar6;
          uVar11 = (ulonglong)*(uint *)(param_2 + 2);
        }
        iVar6 = (int)uVar11;
        if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
           (*(ulonglong *)(param_2 + 0xf) < uVar11 + *(longlong *)(param_2 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar9 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar9 != 0 &&
               (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) &&
              (*(char *)(lVar9 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0xa997a8,0xbb9478,0x877,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),0x12);
          iVar6 = *(int *)(param_2 + 2);
        }
        if (0x3f3b < iVar6 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar9 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar9 != 0 &&
              ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
               (*(char *)(lVar9 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              func_0x(*(undefined8 *)(param_2 + 4),5);
              goto LAB_;
            }
            (*_DAT_)(1,0xa997a8,0xbb9478,0x87c,0);
          }
          func_0x(*(undefined8 *)(param_2 + 4),5);
        }
      }
LAB_:
      iVar6 = func_0x(puVar12);
      if (iVar6 == 0) {
        iVar6 = func_0x(puVar12);
        if (iVar6 == 0) {
          (*_DAT_)(1,0xc54e28,0xc45f18,0xd67,0);
        }
      }
      else {
        uVar3 = param_2[0x16];
        if (uVar4 < (uVar3 & 0x7ff)) {
          uVar16 = 0;
          lVar9 = *(longlong *)(param_2 + 4) + (ulonglong)(ushort)param_2[0x15];
          if ((uVar3 & 0x3800) == 0) {
            uVar15 = *(ushort *)(lVar9 + 2);
LAB_:
            uVar16 = uVar15 >> 0xb & 7;
          }
          else {
            lVar10 = 0;
            if ((uVar3 >> 0xb & 7) != 0) {
              do {
                if (((lVar10 == 0) || ((*(ushort *)(lVar9 + 2 + lVar10 * 2) & 0x7ff) <= uVar4)) &&
                   (uVar15 = *(ushort *)(lVar9 + 4 + lVar10 * 2),
                   (int)uVar4 <= (int)((uVar15 & 0x7ff) - 1))) goto LAB_;
                lVar10 = lVar10 + 1;
              } while (lVar10 < (longlong)(ulonglong)(uVar3 >> 0xb & 7));
            }
          }
          iVar19 = (uint)*(ushort *)
                          ((ulonglong)((uVar3 >> 0xb & 7) * 2) + *(longlong *)(param_2 + 4) +
                           lVar7 * 2 + 4 + (ulonglong)(ushort)param_2[0x15]) +
                   (uint)uVar16 * 0x10000;
        }
        else {
          (*_DAT_)(1,0xc54df8,0xc54e40,0x3c6,0);
        }
      }
      lVar9 = func_0x(**(undefined8 **)(*(longlong *)(lVar1 + 8) + 0x160),iVar19);
      if ((lVar9 != 0) &&
         ((*(short *)(lVar9 + 0x38) == -1 ||
          (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar9 + 0x34) + 0x81e680) + 0x11d3cf8
                    ) != '\0')))) {
        func_0x(param_1,lVar9,param_2);
      }
      uVar4 = uVar4 + 1;
      lVar7 = lVar7 + 1;
    } while (lVar7 < iVar5);
  }
  return;
}

