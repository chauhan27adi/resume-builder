
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(uint param_1,uint *param_2,ulonglong param_3,char param_4,int param_5,int *param_6
                 )

{
  int iVar1;
  
  if (param_1 < 0x5e2) {
    if (param_1 == 0x5e1) {
      if (((int)*param_2 < 0x2c0) && (*param_2 != 0)) {
        *param_2 = 0x2c0;
      }
      goto LAB_;
    }
    if (param_1 == 0x65) {
      if ((int)*param_2 < 0) {
        *param_2 = 0;
      }
      goto LAB_;
    }
    if (param_1 == 0x1f9) {
      if ((int)*param_2 < 0x200) {
        *param_2 = 0x200;
      }
      else if (0x7fff < (int)*param_2) {
        *param_2 = 0x7fff;
      }
      goto LAB_;
    }
    goto LAB_;
  }
  switch(param_1) {
  case 0x5ef:
    if ((int)*param_2 < 0) {
      *param_2 = 0;
    }
    else if (0x7fff < (int)*param_2) {
      *param_2 = 0x7fff;
    }
    break;
  case 0x5f0:
    if ((int)*param_2 < 0) {
      *param_2 = 600;
    }
    break;
  case 0x5fb:
  case 0x605:
    if ((int)*param_2 < -1) {
      *param_2 = 0xffffffff;
    }
    break;
  case 0x600:
    if (*param_2 == 0) {
      *param_2 = 0x800;
    }
    break;
  case 0x602:
    if ((int)*param_2 < 0) {
      *param_2 = 5;
    }
    break;
  case 0x615:
    if (0xe0f < *param_2 - 1) {
      *param_2 = 0x3c;
    }
    break;
  case 0x61b:
    if (0xff < *param_2 - 1) {
      *param_2 = 4;
    }
    break;
  case 0x62a:
  case 0x62b:
  case 0x630:
    if (*param_2 != 1) {
      *param_2 = 0;
    }
  default:
LAB_:
    if (param_1 == 0x6d) {
      if (100 < *param_2) {
        (*_DAT_)(0x3a,10,0x10,1);
      }
    }
    else if (param_1 == 0x5fe) {
      if ((*param_2 & 0xffff8000) == 0 && (*param_2 & 0xc00) != 0xc00) {
        (*_DAT_)();
      }
      else {
        (*_DAT_)(0x3a,0,0x19,5);
      }
    }
    else if (param_1 == 0x62e) {
code_r0x00100189:
      if (param_4 == '\0') {
        if ((*param_6 != 0) && (*param_6 < param_5)) {
          (*_DAT_)(0x3a,0x33,0x10,1);
        }
        if (0x10000 < param_5) {
          (*_DAT_)(0x3a,0x34,0x10,1,0x10000);
        }
      }
    }
    break;
  case 0x62e:
    if ((int)*param_2 < 0) {
      *param_2 = 0;
    }
    goto code_r0x00100189;
  case 0x62f:
    iVar1 = *param_6;
    if (((iVar1 < 0) || ((0 < param_5 && (iVar1 < param_5)))) || ((param_5 == 0 && (iVar1 < 0x100)))
       ) {
      *param_6 = 0;
      *param_2 = 0;
    }
  }
LAB_:
  if ((param_3 & 4) == 0) {
    if (param_1 == 0x65) {
      if (0x3c < (int)*param_2) {
        (*_DAT_)(0x3a,7,0x10,1,0x3c);
      }
    }
    else if ((param_1 == 0x66) && (*param_2 != 0)) {
                    /* WARNING: Could not recover jumptable at 0x001002a6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*_DAT_)(0x3a,8,0x10,1);
      return;
    }
  }
  return;
}

