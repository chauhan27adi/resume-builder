
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong param_3,longlong *param_4,
                 longlong param_5,undefined4 param_6,undefined8 param_7,short *param_8)

{
  short *psVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  uint uVar5;
  longlong lVar6;
  uint *puVar7;
  byte bVar8;
  bool bVar9;
  double dVar10;
  int iVar11;
  short *psVar12;
  ulonglong *puVar13;
  longlong lVar14;
  undefined8 uVar15;
  byte *pbVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  longlong lVar19;
  ushort uVar20;
  ushort uVar21;
  short sVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  longlong lVar26;
  longlong lVar27;
  ushort *puVar28;
  ulonglong uVar29;
  byte bVar30;
  uint uVar31;
  uint uVar32;
  longlong lVar33;
  longlong *plVar34;
  uint uVar35;
  longlong lVar36;
  int iVar37;
  ushort *puVar38;
  short *psVar39;
  undefined4 *puVar40;
  longlong unaff_GS_OFFSET;
  bool bVar41;
  undefined auStack_138 [32];
  undefined *puStack_118;
  short sStack_108;
  undefined4 uStack_104;
  short *psStack_100;
  longlong lStack_f8;
  longlong *plStack_f0;
  longlong lStack_e8;
  longlong *plStack_e0;
  longlong lStack_d8;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  short sStack_b8;
  undefined2 uStack_b6;
  undefined2 uStack_aa;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [12];
  undefined4 uStack_94;
  undefined auStack_90 [16];
  ulonglong uStack_80;
  undefined auStack_78 [16];
  ulonglong uStack_68;
  
  uStack_68 = _DAT_ ^ (ulonglong)auStack_138;
  lStack_e8 = param_5;
  cVar4 = *(char *)(param_4[6] + 0x1cde);
  psStack_100 = param_8;
  sStack_108 = *(short *)(*(longlong *)(param_3 + 8) + 200);
  lStack_f8 = param_3;
  plStack_f0 = param_1;
  plStack_e0 = param_4;
  lStack_d8 = param_2;
  psVar12 = (short *)(**(code **)*param_1)();
  uVar15 = 0;
  uStack_104 = 0x7fff;
  sVar22 = *psVar12;
  *param_8 = sVar22;
  if (sVar22 == 0) {
    psVar1 = param_8 + 1;
    if (*(int *)(psVar12 + 2) == 0) {
      pbVar16 = *(byte **)(psVar12 + 4);
      uVar31 = *(uint *)(psVar12 + 8);
      uVar17 = (ulonglong)uVar31;
      psVar12[1] = 0;
      *(uint *)(psVar12 + 10) = uVar31;
      bVar30 = *pbVar16;
      if ((bVar30 & 0x10) != 0) {
        uVar31 = uVar31 + (*(ushort *)(pbVar16 + uVar17) + 7 >> 3) + 2;
        uVar17 = (ulonglong)uVar31;
        *(uint *)(psVar12 + 10) = uVar31;
        bVar30 = *pbVar16;
      }
      if ((bVar30 & 0x20) == 0) {
        *(int *)(psVar12 + 2) = (int)uVar17;
        psVar12[0xe] = 0;
        *(int *)(psVar12 + 0xc) = (int)uVar17;
      }
      else {
        puVar38 = (ushort *)(pbVar16 + uVar17);
        uVar20 = *puVar38;
        psVar12[0xe] = uVar20;
        if (uVar20 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar33 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar33 != 0)) &&
             ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
              (*(char *)(lVar33 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar12 + 4),3);
          uVar20 = psVar12[0xe];
          uVar17 = (ulonglong)*(uint *)(psVar12 + 10);
        }
        uVar31 = (int)uVar17 + (uVar20 + 1) * 2;
        *(uint *)(psVar12 + 0xc) = uVar31;
        if (0x1f9e < uVar31) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar33 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar33 != 0 &&
              ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
               (*(char *)(lVar33 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar12 + 4),4);
          uVar20 = psVar12[0xe];
          uVar31 = *(uint *)(psVar12 + 0xc);
        }
        uVar17 = (ulonglong)uVar20;
        uVar20 = puVar38[uVar17];
        *(uint *)(psVar12 + 2) = uVar20 & 0x7fff;
        if ((uVar20 & 0x7fff) < uVar31) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar33 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar33 != 0)) &&
             ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
              (*(char *)(lVar33 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar12 + 4),4);
          uVar17 = (ulonglong)(ushort)psVar12[0xe];
        }
        if ((short)puVar38[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
          do {
            lVar33 = *(longlong *)(psVar12 + 4);
            if ((int)uVar17 == 1) {
              uVar31 = *(uint *)(psVar12 + 0xc);
              uVar25 = uVar31;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(psVar12 + 10) + lVar33 + uVar17 * 2) & 0x7fff) <
                  uVar31) goto LAB_;
            }
            else {
              uVar25 = *(uint *)(psVar12 + 0xc);
              uVar31 = *(ushort *)((ulonglong)*(uint *)(psVar12 + 10) + lVar33 + -2 + uVar17 * 2) &
                       0x7fff;
              if (uVar25 <= uVar31) goto LAB_;
LAB_:
              func_0x(lVar33,7);
              uVar25 = *(uint *)(psVar12 + 0xc);
              lVar33 = *(longlong *)(psVar12 + 4);
              uVar17 = (ulonglong)(ushort)psVar12[0xe];
            }
            if ((uVar31 < uVar25) || (*(uint *)(psVar12 + 2) < uVar31)) goto LAB_;
            if (*(ushort *)(lVar33 + (ulonglong)uVar31) == 5) {
              psVar12[1] = psVar12[1] | 2;
              psVar12[0xe] = (short)uVar17 + -1;
              psVar12[0x15] = (short)uVar31;
              lVar33 = (ulonglong)(uVar31 & 0xffff) + *(longlong *)(psVar12 + 4);
              uVar20 = psVar12[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar33 + 2) >> 0xe & 1) != 0) {
                uVar20 = *(ushort *)(lVar33 + 2) & 0x3800 | psVar12[0x16] & 0xc7ffU;
              }
              psVar12[0x16] = uVar20;
              psVar12[0x16] = (uVar20 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar20;
              uVar17 = (ulonglong)*(uint *)(psVar12 + 2);
              pbVar16 = *(byte **)(psVar12 + 4);
              goto LAB_;
            }
            if (*(ushort *)(lVar33 + (ulonglong)uVar31) < 0x400) break;
            psVar12[1] = psVar12[1] | 1;
            uVar20 = (short)uVar17 - 1;
            uVar17 = (ulonglong)uVar20;
            psVar12[0xe] = uVar20;
            if ((uVar20 == 0) || (-1 < (short)puVar38[(ulonglong)(uVar20 - 1) + 1])) break;
          } while( true );
        }
        uVar17 = (ulonglong)*(uint *)(psVar12 + 2);
        pbVar16 = *(byte **)(psVar12 + 4);
      }
LAB_:
      iVar11 = 0;
      if ((*pbVar16 & 0x40) == 0) {
        *(undefined4 *)(psVar12 + 0x13) = 0;
      }
      else {
        *(int *)(psVar12 + 0x13) = *(int *)(psVar12 + 2);
        *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + 0xe;
        puVar13 = (ulonglong *)func_0x(psVar12 + 1);
        uVar21 = (ushort)(*puVar13 >> 0x30);
        uVar20 = uVar21;
        if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
          uVar20 = uVar21 & 0xdfff;
          if ((uVar21 >> 0xe & 1) != 0) {
            uVar20 = uVar21 | 0x2000;
          }
        }
        if (uVar20 == 0xfffc) {
          iVar11 = (int)((*puVar13 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + iVar11;
        uVar17 = (ulonglong)*(uint *)(psVar12 + 2);
        pbVar16 = *(byte **)(psVar12 + 4);
      }
      iVar11 = (int)uVar17;
      if ((*(byte **)(psVar12 + 0xf) != (byte *)0x0) &&
         (*(byte **)(psVar12 + 0xf) < pbVar16 + uVar17)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar33 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar33 != 0 &&
             (lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0)) &&
            (*(char *)(lVar33 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_118 = (undefined *)0x0;
            (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x877);
          }
        }
        func_0x(*(undefined8 *)(psVar12 + 4),0x12);
        iVar11 = *(int *)(psVar12 + 2);
      }
      if (0x3f3b < iVar11 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar33 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar33 != 0 &&
            ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
             (*(char *)(lVar33 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            func_0x(*(undefined8 *)(psVar12 + 4),5);
            goto LAB_;
          }
          puStack_118 = (undefined *)0x0;
          (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x87c);
        }
        func_0x(*(undefined8 *)(psVar12 + 4),5);
      }
    }
LAB_:
    uVar31 = *(uint *)(psVar12 + 2);
    if ((uVar31 < 9) &&
       (((**(byte **)(psVar12 + 4) & 0xe) == 0 || ((**(byte **)(psVar12 + 4) & 0xe) == 0xc)))) {
      uVar31 = 9;
    }
    *(undefined4 *)(param_8 + 8) = *(undefined4 *)(psVar12 + 8);
    *psVar1 = psVar12[1];
    *(undefined4 *)(param_8 + 2) = *(undefined4 *)(psVar12 + 2);
    param_8[0xe] = psVar12[0xe];
    *(undefined4 *)(param_8 + 10) = *(undefined4 *)(psVar12 + 10);
    *(undefined4 *)(param_8 + 0xc) = *(undefined4 *)(psVar12 + 0xc);
    *(undefined4 *)(param_8 + 0x13) = *(undefined4 *)(psVar12 + 0x13);
    func_0x(param_7,param_6,*(undefined8 *)(psVar12 + 4),uVar31);
    *(undefined8 *)(param_8 + 4) = param_7;
    iVar11 = func_0x(psVar1);
    psVar39 = psStack_100;
    if (iVar11 != 0) {
      puVar38 = (ushort *)((ulonglong)*(uint *)(param_8 + 10) + *(longlong *)(param_8 + 4));
      uVar31 = *puVar38 - 1;
      if ((*(byte *)psVar1 & 1) == 0) {
        uVar31 = (uint)*puVar38;
      }
      if (uVar31 == 1) {
        uVar25 = *(uint *)(param_8 + 0xc);
LAB_:
        if ((puVar38[(int)uVar31] & 0x7fff) < uVar25) goto LAB_;
      }
      else {
        uVar25 = puVar38[(longlong)(int)uVar31 + -1] & 0x7fff;
        if (*(uint *)(param_8 + 0xc) <= uVar25) goto LAB_;
LAB_:
        func_0x(*(longlong *)(param_8 + 4),7);
      }
      param_8[0x15] = (short)uVar25;
      lVar33 = (ulonglong)(uVar25 & 0xffff) + *(longlong *)(param_8 + 4);
      uVar20 = param_8[0x16] & 0xc7ffU;
      if ((*(ushort *)(lVar33 + 2) >> 0xe & 1) != 0) {
        uVar20 = *(ushort *)(lVar33 + 2) & 0x3800 | param_8[0x16] & 0xc7ffU;
      }
      param_8[0x16] = uVar20;
      param_8[0x16] = (uVar20 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar20;
      psVar39 = psStack_100;
    }
  }
  else {
    psVar39 = param_8;
    if (((*psVar12 == 0) || (*(longlong **)(psVar12 + 8) == (longlong *)0x0)) ||
       (**(longlong **)(psVar12 + 8) == 0)) {
      func_0x(param_8 + 1,param_7,param_6,psVar12 + 1);
      if (*psVar12 != 0) {
        uVar15 = *(undefined8 *)(psVar12 + 8);
      }
      *(undefined8 *)(param_8 + 8) = uVar15;
    }
    else {
      func_0x(param_8,param_7,param_6,psVar12);
    }
  }
  uVar31 = 9;
  puVar38 = (ushort *)(psVar39 + 1);
  if (*psVar39 == 0) {
    func_0x();
  }
  else {
    func_0x(puVar38);
  }
  sVar22 = *psVar39;
  bVar30 = **(byte **)(psVar39 + 4);
  bVar8 = bVar30 >> 1;
  if (sVar22 == 0) {
    bVar8 = bVar30 >> 6;
  }
  if ((bVar8 & 1) != 0) {
    if (cVar4 != '\0') {
      uVar25 = uVar31;
      if (sVar22 == 0) {
        if ((bVar30 & 0xe) != 2) {
          if (*(int *)(psVar39 + 2) == 0) {
            pbVar16 = *(byte **)(psVar39 + 4);
            uVar23 = *(uint *)(psVar39 + 8);
            uVar17 = (ulonglong)uVar23;
            *puVar38 = 0;
            *(uint *)(psVar39 + 10) = uVar23;
            bVar30 = *pbVar16;
            if ((bVar30 & 0x10) != 0) {
              uVar23 = uVar23 + 2 + (*(ushort *)(pbVar16 + uVar17) + 7 >> 3);
              uVar17 = (ulonglong)uVar23;
              *(uint *)(psVar39 + 10) = uVar23;
              bVar30 = *pbVar16;
            }
            if ((bVar30 & 0x20) == 0) {
              *(int *)(psVar39 + 2) = (int)uVar17;
              psVar39[0xe] = 0;
              *(int *)(psVar39 + 0xc) = (int)uVar17;
            }
            else {
              puVar28 = (ushort *)(pbVar16 + uVar17);
              uVar20 = *puVar28;
              psVar39[0xe] = uVar20;
              if (uVar20 == 0) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar33 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar33 != 0 &&
                    ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                     (*(char *)(lVar33 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    puStack_118 = (undefined *)0x0;
                    (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x80f);
                  }
                }
                func_0x(*(undefined8 *)(psVar39 + 4),3);
                uVar20 = psVar39[0xe];
                uVar17 = (ulonglong)*(uint *)(psVar39 + 10);
              }
              uVar23 = (int)uVar17 + (uVar20 + 1) * 2;
              *(uint *)(psVar39 + 0xc) = uVar23;
              if (0x1f9e < uVar23) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar33 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar33 != 0)) &&
                   ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                    (*(char *)(lVar33 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puStack_118 = (undefined *)0x0;
                    (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x816);
                  }
                }
                func_0x(*(undefined8 *)(psVar39 + 4),4);
                uVar20 = psVar39[0xe];
                uVar23 = *(uint *)(psVar39 + 0xc);
              }
              uVar24 = puVar28[uVar20] & 0x7fff;
              *(uint *)(psVar39 + 2) = uVar24;
              if (uVar24 < uVar23) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar33 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar33 != 0 &&
                    ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                     (*(char *)(lVar33 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puStack_118 = (undefined *)0x0;
                    (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x81d);
                  }
                }
                func_0x(*(undefined8 *)(psVar39 + 4),4);
                uVar20 = psVar39[0xe];
                uVar24 = *(uint *)(psVar39 + 2);
              }
              if ((short)puVar28[(ulonglong)(uVar20 - 1) + 1] < 0) {
                do {
                  lVar33 = *(longlong *)(psVar39 + 4);
                  if (uVar20 == 1) {
                    uVar23 = *(uint *)(psVar39 + 0xc);
                    uVar17 = (ulonglong)uVar23;
LAB_:
                    if ((*(ushort *)
                          ((ulonglong)*(uint *)(psVar39 + 10) + lVar33 + (ulonglong)uVar20 * 2) &
                        0x7fff) < (uint)uVar17) goto LAB_;
                  }
                  else {
                    uVar23 = *(uint *)(psVar39 + 0xc);
                    uVar24 = *(ushort *)
                              ((ulonglong)*(uint *)(psVar39 + 10) + lVar33 + -2 +
                              (ulonglong)uVar20 * 2) & 0x7fff;
                    uVar17 = (ulonglong)uVar24;
                    if (uVar23 <= uVar24) goto LAB_;
LAB_:
                    func_0x(lVar33,7);
                    uVar23 = *(uint *)(psVar39 + 0xc);
                    lVar33 = *(longlong *)(psVar39 + 4);
                  }
                  if (((uint)uVar17 < uVar23) ||
                     (uVar24 = *(uint *)(psVar39 + 2), uVar24 < (uint)uVar17)) goto LAB_;
                  if (*(ushort *)(uVar17 + lVar33) == 5) {
                    *puVar38 = *puVar38 | 2;
                    psVar39[0xe] = psVar39[0xe] + -1;
                    psVar39[0x15] = (short)uVar17;
                    lVar33 = (uVar17 & 0xffff) + *(longlong *)(psVar39 + 4);
                    uVar20 = psVar39[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar33 + 2) >> 0xe & 1) != 0) {
                      uVar20 = *(ushort *)(lVar33 + 2) & 0x3800 | psVar39[0x16] & 0xc7ffU;
                    }
                    psVar39[0x16] = uVar20;
                    psVar39[0x16] = (uVar20 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar20;
                    uVar17 = (ulonglong)*(uint *)(psVar39 + 2);
                    pbVar16 = *(byte **)(psVar39 + 4);
                    goto LAB_;
                  }
                  if (*(ushort *)(uVar17 + lVar33) < 0x400) break;
                  *puVar38 = *puVar38 | 1;
                  uVar20 = psVar39[0xe] - 1;
                  psVar39[0xe] = uVar20;
                  if ((uVar20 == 0) || (-1 < (short)puVar28[(ulonglong)(uVar20 - 1) + 1])) break;
                } while( true );
              }
              uVar17 = (ulonglong)uVar24;
              pbVar16 = *(byte **)(psVar39 + 4);
            }
LAB_:
            iVar11 = 0;
            if ((*pbVar16 & 0x40) == 0) {
              *(undefined4 *)(psVar39 + 0x13) = 0;
            }
            else {
              *(int *)(psVar39 + 0x13) = (int)uVar17;
              *(int *)(psVar39 + 2) = (int)uVar17 + 0xe;
              puVar13 = (ulonglong *)func_0x(puVar38);
              uVar21 = (ushort)(*puVar13 >> 0x30);
              uVar20 = uVar21;
              if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
                uVar20 = uVar21 & 0xdfff;
                if ((uVar21 >> 0xe & 1) != 0) {
                  uVar20 = uVar21 | 0x2000;
                }
              }
              if (uVar20 == 0xfffc) {
                iVar11 = (int)((*puVar13 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar39 + 2) = *(int *)(psVar39 + 2) + iVar11;
              uVar17 = (ulonglong)*(uint *)(psVar39 + 2);
              pbVar16 = *(byte **)(psVar39 + 4);
            }
            iVar11 = (int)uVar17;
            if ((*(byte **)(psVar39 + 0xf) != (byte *)0x0) &&
               (*(byte **)(psVar39 + 0xf) < pbVar16 + uVar17)) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar33 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                   lVar33 != 0 && (lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0)) &&
                  (*(char *)(lVar33 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x877);
                }
              }
              func_0x(*(undefined8 *)(psVar39 + 4),0x12);
              iVar11 = *(int *)(psVar39 + 2);
            }
            if (0x3f3b < iVar11 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar33 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar33 != 0 &&
                  ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                   (*(char *)(lVar33 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  func_0x(*(undefined8 *)(psVar39 + 4),5);
                  goto LAB_;
                }
                puStack_118 = (undefined *)0x0;
                (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x87c);
              }
              func_0x(*(undefined8 *)(psVar39 + 4),5);
            }
          }
LAB_:
          if (*(uint *)(psVar39 + 2) < 9) {
            bVar30 = **(byte **)(psVar39 + 4);
            if (((bVar30 & 0xe) != 0) && ((bVar30 & 0xe) != 0xc)) goto LAB_;
          }
          else {
LAB_:
            bVar30 = **(byte **)(psVar39 + 4);
            uVar25 = *(uint *)(psVar39 + 2);
          }
          if ((bVar30 & 0x40) != 0) {
            uVar25 = *(uint *)(psVar39 + 0x13);
          }
          goto LAB_;
        }
      }
      else {
        if (((bVar30 & 0x1c) - 0x10 & 0xfffffffb) == 0) goto LAB_;
        uVar23 = *(uint *)(psVar39 + 2);
        if (uVar23 == 0) {
          func_0x(puVar38);
          uVar23 = *(uint *)(psVar39 + 2);
          if (uVar23 == 0) {
            func_0x(puVar38);
            uVar23 = *(uint *)(psVar39 + 2);
          }
        }
        if (uVar23 < 9) {
          bVar30 = **(byte **)(psVar39 + 4);
          if (((bVar30 & 0x1c) != 0) && ((bVar30 & 0x1c) != 0xc)) goto LAB_;
        }
        else {
LAB_:
          bVar30 = **(byte **)(psVar39 + 4);
          uVar25 = uVar23;
        }
        if ((bVar30 & 2) != 0) {
          uVar25 = *(uint *)(psVar39 + 0x18);
        }
LAB_:
        sVar22 = *psVar39;
        uVar23 = 0x16;
        if (sVar22 != 0) {
          uVar23 = 0x10;
        }
        if (uVar23 <= uVar25) goto LAB_;
      }
LAB_:
      if (sVar22 == 0) {
        if (*(int *)(psVar39 + 2) == 0) {
          pbVar16 = *(byte **)(psVar39 + 4);
          uVar25 = *(uint *)(psVar39 + 8);
          uVar17 = (ulonglong)uVar25;
          *puVar38 = 0;
          *(uint *)(psVar39 + 10) = uVar25;
          bVar30 = *pbVar16;
          if ((bVar30 & 0x10) != 0) {
            uVar25 = uVar25 + 2 + (*(ushort *)(pbVar16 + uVar17) + 7 >> 3);
            uVar17 = (ulonglong)uVar25;
            *(uint *)(psVar39 + 10) = uVar25;
            bVar30 = *pbVar16;
          }
          if ((bVar30 & 0x20) == 0) {
            *(int *)(psVar39 + 2) = (int)uVar17;
            psVar39[0xe] = 0;
            *(int *)(psVar39 + 0xc) = (int)uVar17;
          }
          else {
            puVar28 = (ushort *)(pbVar16 + uVar17);
            uVar20 = *puVar28;
            psVar39[0xe] = uVar20;
            if (uVar20 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar33 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar33 != 0)) &&
                 ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                  (*(char *)(lVar33 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x80f);
                }
              }
              func_0x(*(undefined8 *)(psVar39 + 4),3);
              uVar20 = psVar39[0xe];
              uVar17 = (ulonglong)*(uint *)(psVar39 + 10);
            }
            uVar25 = (int)uVar17 + (uVar20 + 1) * 2;
            *(uint *)(psVar39 + 0xc) = uVar25;
            if (0x1f9e < uVar25) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar33 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar33 != 0 &&
                  ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                   (*(char *)(lVar33 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x816);
                }
              }
              func_0x(*(undefined8 *)(psVar39 + 4),4);
              uVar20 = psVar39[0xe];
              uVar25 = *(uint *)(psVar39 + 0xc);
            }
            uVar23 = puVar28[uVar20] & 0x7fff;
            *(uint *)(psVar39 + 2) = uVar23;
            if (uVar23 < uVar25) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar33 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar33 != 0)) &&
                 ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                  (*(char *)(lVar33 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x81d);
                }
              }
              func_0x(*(undefined8 *)(psVar39 + 4),4);
              uVar20 = psVar39[0xe];
              uVar23 = *(uint *)(psVar39 + 2);
            }
            uVar17 = (ulonglong)uVar23;
            if ((short)puVar28[(ulonglong)(uVar20 - 1) + 1] < 0) {
              do {
                lVar33 = *(longlong *)(psVar39 + 4);
                if (uVar20 == 1) {
                  uVar25 = *(uint *)(psVar39 + 0xc);
                  uVar23 = uVar25;
LAB_:
                  if ((*(ushort *)
                        ((ulonglong)*(uint *)(psVar39 + 10) + lVar33 + (ulonglong)uVar20 * 2) &
                      0x7fff) < uVar25) goto LAB_;
                }
                else {
                  uVar23 = *(uint *)(psVar39 + 0xc);
                  uVar25 = *(ushort *)
                            ((ulonglong)*(uint *)(psVar39 + 10) + lVar33 + -2 +
                            (ulonglong)uVar20 * 2) & 0x7fff;
                  if (uVar23 <= uVar25) goto LAB_;
LAB_:
                  func_0x(lVar33,7);
                  uVar23 = *(uint *)(psVar39 + 0xc);
                  lVar33 = *(longlong *)(psVar39 + 4);
                }
                if ((uVar25 < uVar23) ||
                   (uVar17 = (ulonglong)*(uint *)(psVar39 + 2), *(uint *)(psVar39 + 2) < uVar25))
                goto LAB_;
                if (*(ushort *)((ulonglong)uVar25 + lVar33) == 5) {
                  *puVar38 = *puVar38 | 2;
                  psVar39[0xe] = psVar39[0xe] + -1;
                  psVar39[0x15] = (short)uVar25;
                  lVar33 = (ulonglong)(uVar25 & 0xffff) + *(longlong *)(psVar39 + 4);
                  uVar20 = psVar39[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar33 + 2) >> 0xe & 1) != 0) {
                    uVar20 = *(ushort *)(lVar33 + 2) & 0x3800 | psVar39[0x16] & 0xc7ffU;
                  }
                  psVar39[0x16] = uVar20;
                  psVar39[0x16] = (uVar20 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar20;
                  uVar17 = (ulonglong)*(uint *)(psVar39 + 2);
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar25 + lVar33) < 0x400) goto LAB_;
                *puVar38 = *puVar38 | 1;
                uVar20 = psVar39[0xe] - 1;
                psVar39[0xe] = uVar20;
                if (uVar20 == 0) goto LAB_;
              } while ((short)puVar28[(ulonglong)(uVar20 - 1) + 1] < 0);
              pbVar16 = *(byte **)(psVar39 + 4);
            }
            else {
LAB_:
              pbVar16 = *(byte **)(psVar39 + 4);
            }
          }
          iVar11 = 0;
          if ((*pbVar16 & 0x40) == 0) {
            *(undefined4 *)(psVar39 + 0x13) = 0;
          }
          else {
            *(int *)(psVar39 + 0x13) = (int)uVar17;
            *(int *)(psVar39 + 2) = (int)uVar17 + 0xe;
            puVar13 = (ulonglong *)func_0x(puVar38);
            uVar21 = (ushort)(*puVar13 >> 0x30);
            uVar20 = uVar21;
            if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
              uVar20 = uVar21 & 0xdfff;
              if ((uVar21 >> 0xe & 1) != 0) {
                uVar20 = uVar21 | 0x2000;
              }
            }
            if (uVar20 == 0xfffc) {
              iVar11 = (int)((*puVar13 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar39 + 2) = *(int *)(psVar39 + 2) + iVar11;
            uVar17 = (ulonglong)*(uint *)(psVar39 + 2);
            pbVar16 = *(byte **)(psVar39 + 4);
          }
          iVar11 = (int)uVar17;
          if ((*(byte **)(psVar39 + 0xf) != (byte *)0x0) &&
             (*(byte **)(psVar39 + 0xf) < pbVar16 + uVar17)) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar33 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar33 != 0 &&
                 (lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0)) &&
                (*(char *)(lVar33 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                puStack_118 = (undefined *)0x0;
                (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x877);
              }
            }
            func_0x(*(undefined8 *)(psVar39 + 4),0x12);
            iVar11 = *(int *)(psVar39 + 2);
          }
          if (0x3f3b < iVar11 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar33 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar33 != 0 &&
                ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
                 (*(char *)(lVar33 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                puStack_118 = (undefined *)0x0;
                (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x87c);
              }
            }
            func_0x(*(undefined8 *)(psVar39 + 4),5);
          }
        }
LAB_:
        if (*(uint *)(psVar39 + 2) < 9) {
          bVar30 = **(byte **)(psVar39 + 4);
          if (((bVar30 & 0xe) != 0) && ((bVar30 & 0xe) != 0xc)) goto LAB_;
        }
        else {
LAB_:
          bVar30 = **(byte **)(psVar39 + 4);
          uVar31 = *(uint *)(psVar39 + 2);
        }
        if ((bVar30 & 0x40) != 0) {
          uVar31 = *(uint *)(psVar39 + 0x13);
        }
      }
      else {
        uVar25 = *(uint *)(psVar39 + 2);
        if (uVar25 == 0) {
          func_0x(puVar38);
          uVar25 = *(uint *)(psVar39 + 2);
          if (uVar25 == 0) {
            func_0x(puVar38);
            uVar25 = *(uint *)(psVar39 + 2);
          }
        }
        if (uVar25 < 9) {
          bVar30 = **(byte **)(psVar39 + 4);
          if (((bVar30 & 0x1c) != 0) && ((bVar30 & 0x1c) != 0xc)) goto LAB_;
        }
        else {
LAB_:
          bVar30 = **(byte **)(psVar39 + 4);
          uVar31 = uVar25;
        }
        if ((bVar30 & 2) != 0) {
          uVar31 = *(uint *)(psVar39 + 0x18);
        }
      }
      sVar22 = *psVar39;
      uVar25 = 0x20;
      if (sVar22 != 0) {
        uVar25 = 0x18;
      }
      if (uVar31 < uVar25) goto LAB_;
    }
LAB_:
    if (sVar22 == 0) {
      func_0x(puVar38);
    }
    else {
      pbVar16 = *(byte **)(psVar39 + 4);
      bVar30 = *pbVar16;
      if ((bVar30 & 2) != 0) {
        if (*(int *)(psVar39 + 2) == 0) {
          func_0x(puVar38);
          pbVar16 = *(byte **)(psVar39 + 4);
          bVar30 = *pbVar16;
        }
        *pbVar16 = bVar30 & 0xfd;
        *(undefined4 *)(psVar39 + 2) = *(undefined4 *)(psVar39 + 0x18);
        *(undefined4 *)(psVar39 + 0x18) = 0;
      }
    }
  }
LAB_:
  (**(code **)(*plStack_f0 + 8))();
  func_0x(lStack_e8,psVar39);
  if (*psVar39 == 0) {
    if ((**(byte **)(psVar39 + 4) & 0x10) == 0) goto LAB_;
    uVar20 = *(ushort *)(*(byte **)(psVar39 + 4) + *(uint *)(psVar39 + 8));
  }
  else {
    uVar20 = *puVar38;
  }
  if ((uVar20 != 0) && (uVar31 = (uint)sStack_108, *psVar39 == 0)) {
    uVar25 = 0;
    if (*(int *)(psVar39 + 2) == 0) {
      pbVar16 = *(byte **)(psVar39 + 4);
      uVar23 = *(uint *)(psVar39 + 8);
      uVar17 = (ulonglong)uVar23;
      *puVar38 = 0;
      *(uint *)(psVar39 + 10) = uVar23;
      bVar30 = *pbVar16;
      if ((bVar30 & 0x10) != 0) {
        uVar23 = uVar23 + (*(ushort *)(pbVar16 + uVar17) + 7 >> 3) + 2;
        uVar17 = (ulonglong)uVar23;
        *(uint *)(psVar39 + 10) = uVar23;
        bVar30 = *pbVar16;
      }
      if ((bVar30 & 0x20) == 0) {
        *(int *)(psVar39 + 2) = (int)uVar17;
        psVar39[0xe] = 0;
        *(int *)(psVar39 + 0xc) = (int)uVar17;
      }
      else {
        puVar28 = (ushort *)(pbVar16 + uVar17);
        uVar20 = *puVar28;
        psVar39[0xe] = uVar20;
        if (uVar20 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar33 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar33 != 0)) &&
             ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
              (*(char *)(lVar33 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar39 + 4),3);
          uVar20 = psVar39[0xe];
          uVar17 = (ulonglong)*(uint *)(psVar39 + 10);
        }
        uVar23 = (int)uVar17 + (uVar20 + 1) * 2;
        *(uint *)(psVar39 + 0xc) = uVar23;
        if (0x1f9e < uVar23) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar33 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar33 != 0 &&
              ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
               (*(char *)(lVar33 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar39 + 4),4);
          uVar20 = psVar39[0xe];
          uVar23 = *(uint *)(psVar39 + 0xc);
        }
        uVar17 = (ulonglong)uVar20;
        uVar20 = puVar28[uVar17];
        *(uint *)(psVar39 + 2) = uVar20 & 0x7fff;
        if ((uVar20 & 0x7fff) < uVar23) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar33 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar33 != 0)) &&
             ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
              (*(char *)(lVar33 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar39 + 4),4);
          uVar17 = (ulonglong)(ushort)psVar39[0xe];
        }
        if ((short)puVar28[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
          do {
            lVar33 = *(longlong *)(psVar39 + 4);
            if ((int)uVar17 == 1) {
              uVar23 = *(uint *)(psVar39 + 0xc);
              uVar24 = uVar23;
LAB_:
              if ((*(ushort *)((ulonglong)*(uint *)(psVar39 + 10) + lVar33 + uVar17 * 2) & 0x7fff) <
                  uVar23) goto LAB_;
            }
            else {
              uVar24 = *(uint *)(psVar39 + 0xc);
              uVar23 = *(ushort *)((ulonglong)*(uint *)(psVar39 + 10) + lVar33 + -2 + uVar17 * 2) &
                       0x7fff;
              if (uVar24 <= uVar23) goto LAB_;
LAB_:
              func_0x(lVar33,7);
              uVar24 = *(uint *)(psVar39 + 0xc);
              lVar33 = *(longlong *)(psVar39 + 4);
            }
            if ((uVar23 < uVar24) || (*(uint *)(psVar39 + 2) < uVar23)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar23 + lVar33) == 5) {
              *puVar38 = *puVar38 | 2;
              psVar39[0xe] = psVar39[0xe] + -1;
              psVar39[0x15] = (short)uVar23;
              lVar33 = (ulonglong)(uVar23 & 0xffff) + *(longlong *)(psVar39 + 4);
              uVar20 = psVar39[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar33 + 2) >> 0xe & 1) != 0) {
                uVar20 = *(ushort *)(lVar33 + 2) & 0x3800 | psVar39[0x16] & 0xc7ffU;
              }
              psVar39[0x16] = uVar20;
              psVar39[0x16] = (uVar20 ^ *(ushort *)(lVar33 + 2)) & 0x7ff ^ uVar20;
              goto LAB_;
            }
            if (*(ushort *)((ulonglong)uVar23 + lVar33) < 0x400) goto LAB_;
            *puVar38 = *puVar38 | 1;
            uVar20 = psVar39[0xe] - 1;
            psVar39[0xe] = uVar20;
            if (uVar20 == 0) goto LAB_;
            uVar17 = (ulonglong)uVar20;
          } while ((short)puVar28[(ulonglong)(uVar20 - 1) + 1] < 0);
          uVar17 = (ulonglong)*(uint *)(psVar39 + 2);
          pbVar16 = *(byte **)(psVar39 + 4);
        }
        else {
LAB_:
          uVar17 = (ulonglong)*(uint *)(psVar39 + 2);
          pbVar16 = *(byte **)(psVar39 + 4);
        }
      }
      if ((*pbVar16 & 0x40) == 0) {
        *(undefined4 *)(psVar39 + 0x13) = 0;
      }
      else {
        *(int *)(psVar39 + 0x13) = (int)uVar17;
        *(int *)(psVar39 + 2) = (int)uVar17 + 0xe;
        puVar13 = (ulonglong *)func_0x(puVar38);
        uVar21 = (ushort)(*puVar13 >> 0x30);
        uVar20 = uVar21;
        if ((((uint)(int)(short)uVar21 >> 1 ^ (int)(short)uVar21) & 0x2000) != 0) {
          uVar20 = uVar21 & 0xdfff;
          if ((uVar21 >> 0xe & 1) != 0) {
            uVar20 = uVar21 | 0x2000;
          }
        }
        uVar23 = uVar25;
        if (uVar20 == 0xfffc) {
          uVar23 = (uint)((*puVar13 >> 0x20 & 0xffff) >> 5);
        }
        *(uint *)(psVar39 + 2) = *(int *)(psVar39 + 2) + uVar23;
        uVar17 = (ulonglong)*(uint *)(psVar39 + 2);
        pbVar16 = *(byte **)(psVar39 + 4);
      }
      iVar11 = (int)uVar17;
      if ((*(byte **)(psVar39 + 0xf) != (byte *)0x0) &&
         (*(byte **)(psVar39 + 0xf) < pbVar16 + uVar17)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar33 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar33 != 0 &&
             (lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0)) &&
            (*(char *)(lVar33 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_118 = (undefined *)0x0;
            (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x877);
          }
        }
        func_0x(*(undefined8 *)(psVar39 + 4),0x12);
        iVar11 = *(int *)(psVar39 + 2);
      }
      if (0x3f3b < iVar11 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar33 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar33 != 0 &&
            ((lVar33 = *(longlong *)(lVar33 + 0x60), lVar33 != 0 &&
             (*(char *)(lVar33 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_118 = (undefined *)0x0;
            (*_DAT_)(1,0xa98ef8,0xbb8bc8,0x87c);
          }
        }
        func_0x(*(undefined8 *)(psVar39 + 4),5);
      }
    }
LAB_:
    pbVar16 = *(byte **)(psVar39 + 4);
    bVar30 = *pbVar16 & 0x10;
    uVar23 = uVar25;
    if (bVar30 != 0) {
      uVar23 = (uint)*(ushort *)(pbVar16 + *(uint *)(psVar39 + 8));
    }
    if (uVar23 < uVar31) {
      uVar24 = *(uint *)(psVar39 + 8);
      if (bVar30 != 0) {
        uVar25 = (uVar23 + 7 >> 3) + 2;
      }
      uVar32 = (uVar31 + 7 >> 3) + 2;
      if (uVar25 < uVar32) {
        uVar5 = *(uint *)(psVar39 + 10);
        iVar11 = *(int *)(psVar39 + 2);
        iVar37 = uVar32 - uVar25;
        puVar28 = (ushort *)(pbVar16 + uVar5);
        if (((*pbVar16 & 0x20) != 0) && (uVar17 = 0, *puVar28 != 0)) {
          do {
            uVar35 = (int)uVar17 + 1;
            uVar20 = puVar28[uVar17 + 1];
            puVar28[uVar17 + 1] = (uVar20 + (short)iVar37 ^ uVar20) & (ushort)uStack_104 ^ uVar20;
            uVar17 = (ulonglong)uVar35;
          } while (uVar35 < *puVar28);
        }
        func_0x
                  ((byte *)((longlong)puVar28 + ((ulonglong)uVar32 - (ulonglong)uVar25)),puVar28,
                   iVar11 - uVar5);
        if (0 < iVar37) {
          func_0x(puVar28,0,(ulonglong)uVar32 - (ulonglong)uVar25);
        }
        *(int *)(psVar39 + 10) = *(int *)(psVar39 + 10) + iVar37;
        *(int *)(psVar39 + 0xc) = *(int *)(psVar39 + 0xc) + iVar37;
        *(int *)(psVar39 + 2) = *(int *)(psVar39 + 2) + iVar37;
        iVar11 = func_0x(puVar38);
        if (iVar11 != 0) {
          func_0x(puVar38);
        }
      }
      uVar20 = (ushort)uVar23;
      *(short *)(pbVar16 + uVar24) = sStack_108;
      while( true ) {
        uVar20 = uVar20 + 1;
        if (uVar31 < uVar20) break;
        uVar25 = uVar20 - 1;
        lVar33 = (ulonglong)(uVar25 >> 3) + (longlong)*(int *)(psVar39 + 8);
        *(byte *)(lVar33 + 2 + *(longlong *)(psVar39 + 4)) =
             *(byte *)(*(longlong *)(psVar39 + 4) + 2 + lVar33) | (byte)(1 << (uVar25 & 7));
      }
    }
  }
LAB_:
  dVar10 = _DAT_;
  if (((*(uint *)(lStack_f8 + 0x14) & 0xe0000000) != 0x80000000) ||
     (0xff < *(ushort *)(lStack_f8 + 0x18))) {
    uVar31 = 0;
    if (*(short *)(lStack_d8 + 0x62) != 0) {
      puVar40 = (undefined4 *)(*(longlong *)(lStack_d8 + 0x70) + 0x18);
      lVar33 = lStack_f8;
      do {
        if ((puVar40[10] & 0x200000) == 0) {
          lVar14 = *(longlong *)(lVar33 + 8);
          uStack_d0 = *puVar40;
          uStack_cc = puVar40[1];
          uStack_c8 = puVar40[2];
          uStack_c4 = puVar40[3];
          if ((((*(longlong *)(lVar14 + 0x90) == 0) || (DAT_ == '\0')) ||
              (*(longlong *)(*(longlong *)(*(longlong *)(lVar14 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
             (*(uint *)(lVar14 + 0xf4) < 2)) {
            if (*(int *)(lVar14 + 0x480) == 0) {
              func_0x();
            }
            plVar2 = (longlong *)CONCAT44(uStack_cc,uStack_d0);
            if (plVar2[1] == 0) {
LAB_:
              uVar29 = CONCAT44(uStack_c4,uStack_c8);
              LOCK();
              plVar2 = (longlong *)(*plVar2 + uVar29 * 8);
              *plVar2 = *plVar2 + 1;
              UNLOCK();
            }
            else {
              lVar27 = (ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
              lVar14 = *(longlong *)(lVar27 + 0x100);
              if (lVar14 == 0) {
                (*_DAT_)(0);
                lVar14 = *(longlong *)(lVar27 + 0x100);
              }
              if (*(longlong *)(lVar14 + 0x260) == 0) {
                uVar17 = 0;
              }
              else {
                uVar17 = (ulonglong)*(uint *)(*(longlong *)(lVar14 + 0x260) + 0xe68);
              }
              if (*(uint *)(_DAT_ + 8) <= (uint)uVar17) goto LAB_;
              uVar29 = CONCAT44(uStack_c4,uStack_c8);
              lVar14 = *(longlong *)(plVar2[1] + uVar17 * 8);
              *(longlong *)(lVar14 + uVar29 * 8) = *(longlong *)(lVar14 + uVar29 * 8) + 1;
            }
            if (*(char *)(plStack_e0[6] + 0x2068) != '\0') {
              lVar14 = *(longlong *)(lVar33 + 8);
              lVar27 = *(longlong *)(lVar14 + 0x160);
              func_0x();
              plVar2 = plStack_e0;
              lVar33 = lStack_f8;
              lVar26 = *(longlong *)(lVar27 + 8);
              bVar9 = false;
              uVar25 = (uint)uVar29;
              uVar17 = uVar29 & 0xffffffff;
              do {
                uVar18 = 0;
                plVar34 = *(longlong **)(*(longlong *)(lVar27 + 0x88) + uVar17 * 8);
                if ((*(longlong *)(lVar27 + 0x90) != 0) && (*(int *)(_DAT_ + 8) != 0)) {
                  do {
                    uVar23 = (int)uVar18 + 1;
                    plVar34 = (longlong *)
                              ((longlong)plVar34 +
                              *(longlong *)
                               (*(longlong *)(*(longlong *)(lVar27 + 0x90) + uVar18 * 8) +
                               uVar17 * 8));
                    uVar18 = (ulonglong)uVar23;
                  } while (uVar23 < *(uint *)(_DAT_ + 8));
                }
                uVar18 = 0;
                lVar6 = *(longlong *)(lVar26 + uVar17 * 8);
                if ((longlong)plVar34 <= lVar6) goto LAB_;
                lVar36 = **(longlong **)(lVar14 + 0x148);
                if ((*(longlong *)(lVar14 + 0x150) != 0) && (*(int *)(_DAT_ + 8) != 0)) {
                  do {
                    uVar23 = (int)uVar18 + 1;
                    lVar36 = lVar36 + **(longlong **)(*(longlong *)(lVar14 + 0x150) + uVar18 * 8);
                    uVar18 = (ulonglong)uVar23;
                  } while (uVar23 < *(uint *)(_DAT_ + 8));
                }
                lVar19 = 0x19;
                if (0x19 < (longlong)((double)lVar36 * dVar10)) {
                  lVar19 = (longlong)((double)lVar36 * dVar10);
                }
                plVar3 = (longlong *)(lVar26 + uVar17 * 8);
                LOCK();
                bVar41 = lVar6 == *plVar3;
                if (bVar41) {
                  *plVar3 = lVar19 + (longlong)plVar34;
                }
                UNLOCK();
              } while (!bVar41);
              bVar9 = true;
              plStack_f0 = plVar34;
              lStack_e8 = lVar6;
LAB_:
              lVar14 = lStack_e8;
              plVar34 = plStack_f0;
              if (bVar9) {
                lVar27 = *plStack_e0;
                uVar15 = func_0x(lStack_f8);
                (**(code **)(lVar27 + 0x2b8))(plVar2,uVar15);
                lVar26 = 0;
                uStack_a8 = 0;
                uStack_a4 = 0x8c0000;
                uStack_b6 = 0x40;
                uStack_aa = 0;
                lVar27 = **(longlong **)(*(longlong *)(lVar33 + 8) + 0x160);
                if (uVar25 < *(uint *)(lVar27 + 0x10)) {
                  puVar7 = *(uint **)(lVar27 + 8);
                  if (uVar25 < *puVar7) {
                    lVar26 = ((uVar29 & 0xffffffff) % (ulonglong)puVar7[9]) * 0x1c0 +
                             *(longlong *)
                              (*(longlong *)(puVar7 + 4) +
                              ((uVar29 & 0xffffffff) / (ulonglong)puVar7[9]) * 8);
                  }
                  else {
                    lVar26 = ((ulonglong)(uVar25 - *puVar7) % (ulonglong)puVar7[0x11]) * 0x1c0 +
                             *(longlong *)
                              (*(longlong *)(puVar7 + 0xc) +
                              ((ulonglong)(uVar25 - *puVar7) / (ulonglong)puVar7[0x11]) * 8);
                  }
                }
                uStack_80 = (ulonglong)*(uint *)(lVar26 + 0x3c);
                psStack_100 = &sStack_b8;
                auStack_a0._0_8_ = (ulonglong)*(uint6 *)(lVar33 + 0x14) << 0x10;
                auStack_a0._8_4_ = 4;
                uStack_94 = 0;
                auStack_90._8_8_ = lVar14;
                auStack_90._0_8_ = plVar34;
                uStack_104 = 0x40;
                iVar11 = func_0x(plVar2);
                if (iVar11 == 0) {
                  (**(code **)(*plVar2 + 0x270))(plVar2);
                }
                puStack_118 = auStack_78;
                (**(code **)(*plVar2 + 0x288))(plVar2,1,&uStack_104,&psStack_100);
              }
            }
          }
        }
        uVar31 = uVar31 + 1;
        puVar40 = puVar40 + 0x14;
      } while (uVar31 < *(ushort *)(lStack_d8 + 0x62));
    }
  }
  func_0x(uStack_68 ^ (ulonglong)auStack_138);
  return;
}

