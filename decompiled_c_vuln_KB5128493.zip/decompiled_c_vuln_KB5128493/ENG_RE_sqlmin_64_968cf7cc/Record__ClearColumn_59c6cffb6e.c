
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,uint *param_2)

{
  ushort *puVar1;
  short *psVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  short sVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  longlong lVar10;
  undefined8 uVar11;
  undefined4 *puVar12;
  byte *pbVar13;
  ulonglong uVar14;
  ushort uVar15;
  uint uVar16;
  ulonglong uVar17;
  uint uVar18;
  uint uVar19;
  ushort *puVar20;
  uint uVar21;
  undefined auStack_1a8 [32];
  uint *puStack_188;
  undefined8 uStack_180;
  uint auStack_178 [2];
  short *psStack_170;
  undefined4 uStack_168;
  undefined2 uStack_164;
  undefined2 uStack_162;
  uint *puStack_160;
  undefined auStack_158 [8];
  undefined auStack_150 [16];
  undefined auStack_140 [24];
  undefined auStack_128 [224];
  ulonglong uStack_48;
  
  cVar4 = DAT_;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1a8;
  puVar1 = (ushort *)(param_1 + 1);
  psStack_170 = param_1;
  puStack_160 = param_2;
  if (*param_1 != 0) {
    func_0x(puVar1);
    goto LAB_;
  }
  uVar16 = *param_2;
  if (-1 < (int)uVar16) {
    uVar19 = (uint)*(ushort *)((longlong)param_2 + 6);
    if ((*(ushort *)((longlong)param_2 + 6) & 8) == 0) {
      if (*(int *)(param_1 + 2) == 0) {
        pbVar13 = *(byte **)(param_1 + 4);
        uVar16 = *(uint *)(param_1 + 8);
        uVar14 = (ulonglong)uVar16;
        *puVar1 = 0;
        *(uint *)(param_1 + 10) = uVar16;
        bVar3 = *pbVar13;
        if ((bVar3 & 0x10) != 0) {
          uVar16 = uVar16 + 2 + (*(ushort *)(pbVar13 + uVar14) + 7 >> 3);
          uVar14 = (ulonglong)uVar16;
          *(uint *)(param_1 + 10) = uVar16;
          bVar3 = *pbVar13;
        }
        if ((bVar3 & 0x20) == 0) {
          *(int *)(param_1 + 2) = (int)uVar14;
          param_1[0xe] = 0;
          *(int *)(param_1 + 0xc) = (int)uVar14;
        }
        else {
          puVar20 = (ushort *)(pbVar13 + uVar14);
          uVar5 = *puVar20;
          param_1[0xe] = uVar5;
          if (uVar5 == 0) {
            cVar4 = func_0x(0x11021a0);
            if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar4 = func_0x(0x11021a0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                puStack_188 = (uint *)0x0;
                (*_DAT_)(1,0x9f2f28,0xb12bf8,0x80f);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),3);
            uVar14 = (ulonglong)*(uint *)(param_1 + 10);
            uVar5 = param_1[0xe];
          }
          uVar16 = (int)uVar14 + (uVar5 + 1) * 2;
          *(uint *)(param_1 + 0xc) = uVar16;
          if (0x1f9e < uVar16) {
            cVar4 = func_0x(0x11021a0);
            if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar4 = func_0x(0x11021a0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                puStack_188 = (uint *)0x0;
                (*_DAT_)(1,0x9f2f28,0xb12bf8,0x816);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
            uVar5 = param_1[0xe];
            uVar16 = *(uint *)(param_1 + 0xc);
          }
          uVar14 = (ulonglong)uVar5;
          uVar5 = puVar20[uVar14];
          *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
          if ((uVar5 & 0x7fff) < uVar16) {
            cVar4 = func_0x(0x11021a0);
            if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar4 = func_0x(0x11021a0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                puStack_188 = (uint *)0x0;
                (*_DAT_)(1,0x9f2f28,0xb12bf8,0x81d);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
            uVar14 = (ulonglong)(ushort)param_1[0xe];
          }
          if ((short)puVar20[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
            pbVar13 = *(byte **)(param_1 + 4);
            do {
              if ((int)uVar14 == 1) {
                uVar16 = *(uint *)(param_1 + 0xc);
                uVar19 = uVar16;
LAB_:
                if ((*(ushort *)(pbVar13 + uVar14 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff
                    ) < uVar16) goto LAB_;
              }
              else {
                uVar19 = *(uint *)(param_1 + 0xc);
                uVar16 = *(ushort *)
                          (pbVar13 + uVar14 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) & 0x7fff
                ;
                if (uVar19 <= uVar16) goto LAB_;
LAB_:
                func_0x(pbVar13,7);
                uVar19 = *(uint *)(param_1 + 0xc);
              }
              if ((uVar16 < uVar19) || (*(uint *)(param_1 + 2) < uVar16)) goto LAB_;
              pbVar13 = *(byte **)(param_1 + 4);
              if (*(ushort *)(pbVar13 + uVar16) == 5) {
                *puVar1 = *puVar1 | 2;
                param_1[0xe] = param_1[0xe] + -1;
                param_1[0x15] = (short)uVar16;
                lVar10 = (ulonglong)(uVar16 & 0xffff) + *(longlong *)(param_1 + 4);
                uVar5 = param_1[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar10 + 2) >> 0xe & 1) != 0) {
                  uVar5 = *(ushort *)(lVar10 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
                }
                param_1[0x16] = uVar5;
                param_1[0x16] = (uVar5 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar5;
                goto LAB_;
              }
              if (*(ushort *)(pbVar13 + uVar16) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar5 = param_1[0xe] - 1;
              param_1[0xe] = uVar5;
              if (uVar5 == 0) goto LAB_;
              uVar14 = (ulonglong)uVar5;
            } while ((short)puVar20[(ulonglong)(uVar5 - 1) + 1] < 0);
            uVar14 = (ulonglong)*(uint *)(param_1 + 2);
          }
          else {
LAB_:
            pbVar13 = *(byte **)(param_1 + 4);
            uVar14 = (ulonglong)*(uint *)(param_1 + 2);
          }
        }
        if ((*pbVar13 & 0x40) == 0) {
          *(undefined4 *)(param_1 + 0x13) = 0;
        }
        else {
          *(int *)(param_1 + 0x13) = (int)uVar14;
          *(int *)(param_1 + 2) = (int)uVar14 + 0xe;
          uVar11 = func_0x(puVar1);
          func_0x(uVar11,&uStack_168);
          iVar7 = func_0x(&uStack_168);
          *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar7;
          uVar14 = (ulonglong)*(uint *)(param_1 + 2);
        }
        iVar7 = (int)uVar14;
        if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
           (*(ulonglong *)(param_1 + 0xf) < uVar14 + *(longlong *)(param_1 + 4))) {
          cVar4 = func_0x(0x11021a0);
          if ((cVar4 != '\0') &&
             ((lVar10 = func_0x(), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            cVar4 = func_0x(0x11021a0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f2f28,0xb12bf8,0x877);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),0x12);
          iVar7 = *(int *)(param_1 + 2);
        }
        if (0x3f3b < iVar7 - 1U) {
          cVar4 = func_0x(0x11021a0);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11021a0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f2f28,0xb12bf8,0x87c);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),5);
        }
      }
LAB_:
      uVar16 = *puStack_160;
      if (*(uint *)(param_1 + 8) < uVar16) {
        func_0x(puVar1,0,uVar16 - *(uint *)(param_1 + 8),0);
        if ((1 << (**(byte **)(param_1 + 4) & 0xe) & 0x1105U) != 0) {
          *(short *)(*(byte **)(param_1 + 4) + 2) = (short)uVar16;
        }
        *(uint *)(param_1 + 8) = uVar16;
      }
    }
    else {
      uVar18 = uVar16 + 1;
      if (*(uint *)(param_1 + 8) < uVar18) {
        func_0x(puVar1,0,uVar18 - *(uint *)(param_1 + 8),0);
        if ((1 << (**(byte **)(param_1 + 4) & 0xe) & 0x1105U) != 0) {
          *(short *)(*(byte **)(param_1 + 4) + 2) = (short)uVar18;
        }
        *(uint *)(param_1 + 8) = uVar18;
        uVar19 = (uint)*(byte *)((longlong)param_2 + 6);
      }
      bVar3 = *(byte *)(*(longlong *)(param_1 + 4) + (longlong)(int)uVar16);
      if (cVar4 == '\0') {
        bVar3 = bVar3 & ~(byte)(1 << (uVar19 & 7));
      }
      else {
        bVar3 = bVar3 | (byte)(1 << (uVar19 & 7));
      }
      *(byte *)(*(longlong *)(param_1 + 4) + (longlong)(int)uVar16) = bVar3;
    }
    goto LAB_;
  }
  if ((uVar16 & 0xc0000000) == 0x80000000) {
    func_0x(auStack_128);
    uVar14 = 0;
    iVar7 = 0;
    auStack_178[0] = 0;
    if (*(int *)(param_1 + 2) == 0) {
      pbVar13 = *(byte **)(param_1 + 4);
      uVar16 = *(uint *)(param_1 + 8);
      uVar17 = (ulonglong)uVar16;
      *puVar1 = 0;
      *(uint *)(param_1 + 10) = uVar16;
      bVar3 = *pbVar13;
      if ((bVar3 & 0x10) != 0) {
        uVar16 = uVar16 + 2 + (*(ushort *)(pbVar13 + uVar17) + 7 >> 3);
        uVar17 = (ulonglong)uVar16;
        *(uint *)(param_1 + 10) = uVar16;
        bVar3 = *pbVar13;
      }
      if ((bVar3 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar17;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar17;
      }
      else {
        puVar20 = (ushort *)(pbVar13 + uVar17);
        uVar5 = *puVar20;
        param_1[0xe] = uVar5;
        if (uVar5 == 0) {
          cVar4 = func_0x(0x11021a0);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11021a0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f2f28,0xb12bf8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar17 = (ulonglong)*(uint *)(param_1 + 10);
          uVar5 = param_1[0xe];
        }
        uVar16 = (int)uVar17 + (uVar5 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar16;
        if (0x1f9e < uVar16) {
          cVar4 = func_0x(0x11021a0);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11021a0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f2f28,0xb12bf8,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar5 = param_1[0xe];
          uVar16 = *(uint *)(param_1 + 0xc);
        }
        uVar17 = (ulonglong)uVar5;
        uVar5 = puVar20[uVar17];
        *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar16) {
          cVar4 = func_0x(0x11021a0);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11021a0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f2f28,0xb12bf8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar17 = (ulonglong)(ushort)param_1[0xe];
        }
        if ((short)puVar20[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
          pbVar13 = *(byte **)(param_1 + 4);
          do {
            if ((int)uVar17 == 1) {
              uVar16 = *(uint *)(param_1 + 0xc);
              uVar19 = uVar16;
LAB_:
              if ((*(ushort *)(pbVar13 + uVar17 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff)
                  < uVar16) goto LAB_;
            }
            else {
              uVar19 = *(uint *)(param_1 + 0xc);
              uVar16 = *(ushort *)(pbVar13 + uVar17 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2))
                       & 0x7fff;
              if (uVar19 <= uVar16) goto LAB_;
LAB_:
              func_0x(pbVar13,7);
              uVar19 = *(uint *)(param_1 + 0xc);
            }
            if ((uVar16 < uVar19) || (*(uint *)(param_1 + 2) < uVar16)) goto LAB_;
            pbVar13 = *(byte **)(param_1 + 4);
            if (*(ushort *)(pbVar13 + uVar16) == 5) {
              *puVar1 = *puVar1 | 2;
              param_1[0xe] = param_1[0xe] + -1;
              param_1[0x15] = (short)uVar16;
              lVar10 = (ulonglong)(uVar16 & 0xffff) + *(longlong *)(param_1 + 4);
              uVar5 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar10 + 2) >> 0xe & 1) != 0) {
                uVar5 = *(ushort *)(lVar10 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar5;
              param_1[0x16] = (uVar5 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar5;
              goto LAB_;
            }
            if (*(ushort *)(pbVar13 + uVar16) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar5 = param_1[0xe] - 1;
            param_1[0xe] = uVar5;
            if (uVar5 == 0) goto LAB_;
            uVar17 = (ulonglong)uVar5;
          } while ((short)puVar20[(ulonglong)(uVar5 - 1) + 1] < 0);
          uVar17 = (ulonglong)*(uint *)(param_1 + 2);
        }
        else {
LAB_:
          pbVar13 = *(byte **)(param_1 + 4);
          uVar17 = (ulonglong)*(uint *)(param_1 + 2);
        }
      }
      if ((*pbVar13 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar17;
        *(int *)(param_1 + 2) = (int)uVar17 + 0xe;
        uVar11 = func_0x(puVar1);
        func_0x(uVar11,auStack_158);
        iVar9 = func_0x(auStack_158);
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar9;
        uVar17 = (ulonglong)*(uint *)(param_1 + 2);
      }
      iVar9 = (int)uVar17;
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar17 + *(longlong *)(param_1 + 4))) {
        cVar4 = func_0x(0x11021a0);
        if ((cVar4 != '\0') &&
           ((lVar10 = func_0x(), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0'))
           )) {
          cVar4 = func_0x(0x11021a0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_188 = (uint *)0x0;
            (*_DAT_)(1,0x9f2f28,0xb12bf8,0x877);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        iVar9 = *(int *)(param_1 + 2);
      }
      if (0x3f3b < iVar9 - 1U) {
        cVar4 = func_0x(0x11021a0);
        if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar4 = func_0x(0x11021a0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_188 = (uint *)0x0;
            (*_DAT_)(1,0x9f2f28,0xb12bf8,0x87c);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
      }
    }
LAB_:
    iVar9 = func_0x(puVar1);
    if (iVar9 == 0) goto LAB_;
    bVar3 = **(byte **)(param_1 + 4) >> 6 & 1;
    if ((**(byte **)(param_1 + 4) >> 6 & 1) != 0) {
      func_0x(puVar1,auStack_128);
    }
    if ((*(byte *)puVar1 & 1) != 0) {
      puVar12 = (undefined4 *)func_0x(puVar1,0x400,auStack_178);
      uStack_168 = *puVar12;
      uStack_164 = *(undefined2 *)(puVar12 + 1);
      uStack_162 = *(undefined2 *)((longlong)puVar12 + 6);
    }
    pbVar13 = *(byte **)(param_1 + 4);
    if ((*pbVar13 & 0x20) == 0) {
      func_0x(puVar1);
      pbVar13 = *(byte **)(param_1 + 4);
    }
    uVar16 = *(uint *)(param_1 + 10);
    iVar9 = func_0x(puVar1);
    lVar10 = *(longlong *)(param_1 + 4);
    uVar5 = param_1[0xe];
    uVar17 = (ulonglong)uVar5;
    puVar20 = (ushort *)(lVar10 + (ulonglong)*(uint *)(param_1 + 10));
    uVar19 = (uint)uVar5;
    if (iVar9 == 0) {
      uVar18 = *(uint *)(param_1 + 10) + (uVar5 + 1) * 2;
      if (*puVar20 != 0) {
        do {
          uVar21 = (int)uVar14 + 1;
          puVar20[(uVar14 & 0xffff) + 1] =
               puVar20[(uVar14 & 0xffff) + 1] ^
               (puVar20[uVar14 + 1] + 2 ^ puVar20[(uVar14 & 0xffff) + 1]) & 0x7fff;
          uVar14 = (ulonglong)uVar21;
        } while (uVar21 < *puVar20);
        lVar10 = *(longlong *)(param_1 + 4);
      }
      lVar10 = (ulonglong)uVar18 + lVar10;
      func_0x(lVar10 + 2,lVar10,*(int *)(param_1 + 2) - uVar18);
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 2;
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + 2;
      uVar15 = (ushort)*(undefined4 *)(param_1 + 0xc);
      if (uVar19 != 0) {
        uVar15 = puVar20[(ulonglong)(uVar5 - 1) + 1] & 0x7fff;
      }
      if (uVar19 < uVar5 + 1) {
        do {
          uVar14 = uVar17 & 0xffff;
          uVar19 = (int)uVar17 + 1;
          uVar17 = (ulonglong)uVar19;
          puVar20[uVar14 + 1] = uVar15 & 0x7fff;
        } while (uVar19 < uVar5 + 1);
      }
      *puVar20 = *puVar20 + 1;
      func_0x(puVar1);
      uVar5 = *(ushort *)(pbVar13 + (ulonglong)(ushort)param_1[0xe] * 2 + (ulonglong)uVar16 + 2);
      func_0x(auStack_140);
      uStack_180 = (short **)((ulonglong)uStack_180._4_4_ << 0x20);
      puStack_188 = puStack_160;
      func_0x(auStack_150,0,0,0);
      uStack_180 = &psStack_170;
      puStack_188 = (uint *)auStack_150;
      func_0x(param_1 + 0x15,uVar5 & 0x7fff,0x1f9e,1);
      iVar9 = (int)psStack_170;
    }
    else {
      uVar5 = puVar20[uVar17 + 1];
      if (uVar19 == 0) {
        uVar19 = *(uint *)(psStack_170 + 0xc);
LAB_:
        if ((uVar5 & 0x7fff) < uVar19) goto LAB_;
      }
      else {
        uVar19 = puVar20[uVar17] & 0x7fff;
        if (*(uint *)(psStack_170 + 0xc) <= uVar19) goto LAB_;
LAB_:
        func_0x(lVar10,7);
      }
      iVar7 = (uVar5 & 0x7fff) - uVar19;
      iVar9 = func_0x(param_1 + 0x15,puStack_160,0,0);
    }
    iVar7 = (iVar9 - iVar7) + *(int *)(param_1 + 2);
    *(int *)(param_1 + 2) = iVar7;
    if ((*(byte *)puVar1 & 1) != 0) {
      *(ushort *)(pbVar13 + (ulonglong)(ushort)param_1[0xe] * 2 + (ulonglong)uVar16 + 4) =
           (ushort)iVar7 | 0x8000;
      iVar7 = (*(int *)(param_1 + 2) - auStack_178[0]) + -2;
    }
    *(ushort *)(pbVar13 + (ulonglong)(ushort)param_1[0xe] * 2 + (ulonglong)uVar16 + 2) =
         (ushort)iVar7 | 0x8000;
    if (iVar9 == 0) {
      func_0x(puVar1,(ushort)param_1[0xe] + 1);
      if ((**(byte **)(param_1 + 4) & 0x20) != 0) {
        param_1[0xe] = param_1[0xe] + 1;
        *puVar1 = *puVar1 & 0xfffd;
        func_0x(param_1 + 0x15);
      }
    }
    else {
      *puVar1 = *puVar1 | 2;
      sVar6 = func_0x(puVar1,&psStack_170);
      param_1[0x15] = sVar6;
    }
    if ((*(byte *)puVar1 & 1) != 0) {
      func_0x(puVar1,0x400,auStack_178[0],&uStack_168);
    }
  }
  else {
    if (*(int *)(param_1 + 2) == 0) {
      pbVar13 = *(byte **)(param_1 + 4);
      uVar16 = *(uint *)(param_1 + 8);
      uVar14 = (ulonglong)uVar16;
      *puVar1 = 0;
      *(uint *)(param_1 + 10) = uVar16;
      bVar3 = *pbVar13;
      if ((bVar3 & 0x10) != 0) {
        uVar16 = uVar16 + 2 + (*(ushort *)(pbVar13 + uVar14) + 7 >> 3);
        uVar14 = (ulonglong)uVar16;
        *(uint *)(param_1 + 10) = uVar16;
        bVar3 = *pbVar13;
      }
      if ((bVar3 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar14;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar14;
      }
      else {
        puVar20 = (ushort *)(pbVar13 + uVar14);
        uVar5 = *puVar20;
        param_1[0xe] = uVar5;
        if (uVar5 == 0) {
          cVar4 = func_0x(0x11021a0);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11021a0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f2f28,0xb12bf8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar14 = (ulonglong)*(uint *)(param_1 + 10);
          uVar5 = param_1[0xe];
        }
        uVar16 = (int)uVar14 + (uVar5 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar16;
        if (0x1f9e < uVar16) {
          cVar4 = func_0x(0x11021a0);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11021a0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f2f28,0xb12bf8,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar5 = param_1[0xe];
          uVar16 = *(uint *)(param_1 + 0xc);
        }
        uVar14 = (ulonglong)uVar5;
        uVar5 = puVar20[uVar14];
        *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar16) {
          cVar4 = func_0x(0x11021a0);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11021a0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f2f28,0xb12bf8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar14 = (ulonglong)(ushort)param_1[0xe];
        }
        if ((short)puVar20[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
          pbVar13 = *(byte **)(param_1 + 4);
          do {
            if ((int)uVar14 == 1) {
              uVar16 = *(uint *)(param_1 + 0xc);
              uVar19 = uVar16;
LAB_:
              if ((*(ushort *)(pbVar13 + uVar14 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff)
                  < uVar16) goto LAB_;
            }
            else {
              uVar19 = *(uint *)(param_1 + 0xc);
              uVar16 = *(ushort *)(pbVar13 + uVar14 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2))
                       & 0x7fff;
              if (uVar19 <= uVar16) goto LAB_;
LAB_:
              func_0x(pbVar13,7);
              uVar19 = *(uint *)(param_1 + 0xc);
            }
            if ((uVar16 < uVar19) || (*(uint *)(param_1 + 2) < uVar16)) goto LAB_;
            pbVar13 = *(byte **)(param_1 + 4);
            if (*(ushort *)(pbVar13 + uVar16) == 5) {
              *puVar1 = *puVar1 | 2;
              param_1[0xe] = param_1[0xe] + -1;
              param_1[0x15] = (short)uVar16;
              lVar10 = (ulonglong)(uVar16 & 0xffff) + *(longlong *)(param_1 + 4);
              uVar5 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar10 + 2) >> 0xe & 1) != 0) {
                uVar5 = *(ushort *)(lVar10 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar5;
              param_1[0x16] = (uVar5 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar5;
              goto LAB_;
            }
            if (*(ushort *)(pbVar13 + uVar16) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar5 = param_1[0xe] - 1;
            param_1[0xe] = uVar5;
            if (uVar5 == 0) goto LAB_;
            uVar14 = (ulonglong)uVar5;
          } while ((short)puVar20[(ulonglong)(uVar5 - 1) + 1] < 0);
          uVar14 = (ulonglong)*(uint *)(param_1 + 2);
        }
        else {
LAB_:
          pbVar13 = *(byte **)(param_1 + 4);
          uVar14 = (ulonglong)*(uint *)(param_1 + 2);
        }
      }
      if ((*pbVar13 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar14;
        *(int *)(param_1 + 2) = (int)uVar14 + 0xe;
        uVar11 = func_0x(puVar1);
        func_0x(uVar11,&uStack_168);
        iVar7 = func_0x(&uStack_168);
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar7;
        uVar14 = (ulonglong)*(uint *)(param_1 + 2);
      }
      iVar7 = (int)uVar14;
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar14 + *(longlong *)(param_1 + 4))) {
        cVar4 = func_0x(0x11021a0);
        if ((cVar4 != '\0') &&
           ((lVar10 = func_0x(), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0'))
           )) {
          cVar4 = func_0x(0x11021a0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_188 = (uint *)0x0;
            (*_DAT_)(1,0x9f2f28,0xb12bf8,0x877);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        iVar7 = *(int *)(param_1 + 2);
      }
      if (0x3f3b < iVar7 - 1U) {
        cVar4 = func_0x(0x11021a0);
        if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar4 = func_0x(0x11021a0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_188 = (uint *)0x0;
            (*_DAT_)(1,0x9f2f28,0xb12bf8,0x87c);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
      }
    }
LAB_:
    psVar2 = psStack_170;
    uVar16 = -*param_2;
    if ((ushort)param_1[0xe] < uVar16) goto LAB_;
    func_0x(auStack_128);
    pbVar13 = *(byte **)(param_1 + 4);
    bVar3 = *pbVar13 >> 6 & 1;
    if ((*pbVar13 >> 6 & 1) != 0) {
      func_0x(puVar1,auStack_128);
      pbVar13 = *(byte **)(param_1 + 4);
    }
    if (uVar16 <= (ushort)param_1[0xe]) {
      uVar19 = *(ushort *)(pbVar13 + (longlong)(int)uVar16 * 2 + (ulonglong)*(uint *)(param_1 + 10))
               & 0x7fff;
      auStack_178[0] = uVar19;
      if (uVar16 == 1) {
        uVar14 = (ulonglong)*(uint *)(psVar2 + 0xc);
LAB_:
        if (uVar19 < (uint)uVar14) goto LAB_;
      }
      else {
        uVar14 = (ulonglong)
                 (*(ushort *)
                   (pbVar13 + (longlong)(int)uVar16 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2))
                 & 0x7fff);
        if (*(uint *)(psVar2 + 0xc) <=
            (*(ushort *)
              (pbVar13 + (longlong)(int)uVar16 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
            0x7fff)) goto LAB_;
LAB_:
        func_0x(pbVar13,7);
      }
      iVar7 = uVar19 - (int)uVar14;
      if (iVar7 != 0) {
        puVar20 = (ushort *)((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4));
        lVar10 = *(longlong *)(param_1 + 4);
        uVar8 = func_0x(*(undefined4 *)(param_1 + 2),auStack_178[0]);
        func_0x(uVar14 + lVar10,(longlong)iVar7 + uVar14 + lVar10,uVar8);
        uVar19 = uVar16 - 1;
        if ((int)uVar19 < (int)(uint)*puVar20) {
          do {
            uVar14 = (ulonglong)uVar19;
            lVar10 = (longlong)(int)uVar19;
            uVar19 = uVar19 + 1;
            puVar20[(uVar14 & 0xffff) + 1] =
                 puVar20[(uVar14 & 0xffff) + 1] ^
                 (puVar20[lVar10 + 1] - (short)iVar7 ^ puVar20[(uVar14 & 0xffff) + 1]) & 0x7fff;
          } while ((int)uVar19 < (int)(uint)*puVar20);
        }
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) - iVar7;
        iVar7 = func_0x(puVar1);
        if (iVar7 != 0) {
          sVar6 = func_0x(puVar1,&psStack_170);
          param_1[0x15] = sVar6;
        }
      }
    }
    if (uVar16 == (ushort)param_1[0xe]) {
      func_0x(puVar1,uVar16,1);
    }
  }
  if (bVar3 != 0) {
    func_0x(puVar1,auStack_128);
  }
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_1a8);
  return;
}

