
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint param_2,uint *param_3,ulonglong *param_4,uint param_5,
                 undefined2 param_6,char param_7,undefined8 param_8)

{
  byte *pbVar1;
  undefined4 uVar2;
  uint uVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  longlong lVar7;
  short *psVar8;
  ulonglong *puVar9;
  byte **ppbVar10;
  ushort uVar11;
  byte bVar12;
  short sVar13;
  ushort uVar14;
  undefined4 uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  ushort *puVar21;
  byte **ppbVar22;
  byte *pbVar23;
  longlong lVar24;
  ulonglong uVar25;
  short sVar26;
  longlong unaff_GS_OFFSET;
  bool bVar27;
  byte *apbStackX_8 [2];
  undefined4 uStack_21c8;
  undefined8 uStack_21c0;
  undefined2 uStack_21b8;
  uint uStack_21b0;
  uint uStack_21ac;
  uint uStack_21a8;
  longlong lStack_21a0;
  ulonglong *puStack_2198;
  undefined8 uStack_2190;
  uint *puStack_2188;
  short sStack_2180;
  ushort uStack_217e;
  uint uStack_217c;
  byte *pbStack_2178;
  undefined8 uStack_2170;
  undefined4 uStack_2168;
  ushort uStack_2164;
  undefined2 uStack_2162;
  undefined6 uStack_2160;
  undefined2 uStack_215a;
  undefined2 uStack_2158;
  undefined2 uStack_2156;
  ushort uStack_2154;
  undefined2 uStack_2152;
  undefined4 uStack_2150;
  uint uStack_214c;
  undefined auStack_2148 [16];
  undefined auStack_2138 [8];
  undefined8 uStack_2130;
  undefined8 uStack_2128;
  undefined6 uStack_2120;
  undefined2 uStack_211a;
  undefined6 uStack_2118;
  undefined2 uStack_2112;
  undefined8 uStack_2110;
  undefined auStack_2108 [16];
  undefined auStack_20f8 [16];
  undefined auStack_20e8 [16];
  undefined8 uStack_20d8;
  ulonglong uStack_20c8;
  undefined4 uStack_20c0;
  undefined2 uStack_20bc;
  undefined auStack_1fe8 [8096];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x100022;
  uStack_21ac = param_2;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar7);
  uStack_2190 = param_8;
  uStack_20c8 = 0;
  uStack_21a8 = param_5 & 1;
  sStack_2180 = -1;
  pbStack_2178 = (byte *)0x0;
  uStack_217c = 0;
  uStack_2162 = 0;
  uStack_2160 = 0;
  uStack_2158 = 0;
  uStack_2156 = 0;
  uStack_2154 = 0;
  uStack_2152 = 0;
  uStack_2170 = (byte **)0x0;
  *(undefined2 *)(&stack0x00000018 + lVar7) = 0xffff;
  *(undefined8 *)(&stack0x00000020 + lVar7) = 0;
  *(undefined4 *)(&stack0x0000001c + lVar7) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar7) = 0;
  *(undefined8 *)((longlong)&param_8 + lVar7) = 0;
  *(undefined8 *)((longlong)&param_5 + lVar7) = 0;
  uStack_21c0 = 0;
  uStack_20c0 = 0;
  uStack_20bc = 0;
  lStack_21a0 = param_1;
  puStack_2198 = param_4;
  puStack_2188 = param_3;
  if ((uStack_21a8 == 0) &&
     ((*(ushort *)(param_1 + 0x16) <= uStack_21ac ||
      (*(short *)(param_1 + (0xfff - (longlong)(int)uStack_21ac) * 2) == 0)))) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10010e;
    (*_DAT_)(1,0x14dd130,0x14a81c8,0xa5a);
  }
  ppbVar22 = (byte **)0x0;
  sVar26 = 2;
  uStack_21b0 = 9;
  uVar15 = 0xf;
  uVar20 = 0xf;
  uStack_214c = uStack_21ac;
  if (*(char *)(param_1 + 2) < '\0') {
    pbVar23 = (byte *)(param_1 + 0x60);
    if ((sStack_2180 == 0) || (ppbVar22 = uStack_2170, uStack_2170 == (byte **)0x0)) {
      uStack_2120 = 0;
      stack0xffffffffffffdeca = SUB1614(ZEXT816(0),2);
      auStack_2138._0_2_ = 0xffff;
      uStack_2112 = 0;
      uStack_2130 = 0;
      uStack_211a = 0;
      uStack_2118 = 0;
      uStack_2110 = 0;
      uStack_2128 = 0;
      auStack_2108 = ZEXT816(0);
      auStack_20e8._0_12_ = ZEXT812(0);
      auStack_20e8._12_4_ = 0;
      uStack_20d8 = 0;
      auStack_20f8 = ZEXT816(0);
      auStack_2148 = ZEXT816(0);
      ppbVar22 = (byte **)auStack_2148;
    }
    if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
      uStack_21c0 = *(undefined8 *)(param_1 + 0x28);
      uStack_21b8 = *(undefined2 *)(param_1 + 0x30);
    }
    else {
      cVar4 = *(char *)(param_1 + 1);
      if (cVar4 == '\v') {
        if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
          if (cVar4 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar4 != '\b') goto LAB_;
LAB_:
        if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
      }
      uStack_21c0 = CONCAT26(uStack_21c0._6_2_,*(undefined6 *)(param_1 + 0x20));
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1001f9;
      cVar4 = func_0x(&uStack_21c0);
      if (cVar4 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100209;
      func_0x(param_1,&uStack_21c0);
    }
    *ppbVar22 = pbVar23;
    *(undefined4 *)(ppbVar22 + 0xc) = (undefined4)uStack_21c0;
    *(undefined2 *)(ppbVar22 + 0xd) = uStack_21b8;
    uVar5 = (undefined4)((ulonglong)uStack_21c0 >> 0x20);
    *(undefined4 *)((longlong)ppbVar22 + 100) = uVar5;
    *(undefined4 *)((longlong)ppbVar22 + 0x6c) = *(undefined4 *)(param_1 + 0x20);
    *(undefined2 *)(ppbVar22 + 0xe) = *(undefined2 *)(param_1 + 0x24);
    *(undefined2 *)((longlong)ppbVar22 + 0x72) = 0;
    uVar2 = *(undefined4 *)((ulonglong)*pbVar23 * 6 + 0x111fd60);
    uVar25 = (ulonglong)*(short *)((ulonglong)*pbVar23 * 6 + 0x111fd64);
    *(undefined2 *)(ppbVar22 + 2) = 0xffff;
    ppbVar22[3] = (byte *)0x0;
    uVar16 = 0;
    *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
    ppbVar22[7] = (byte *)0x0;
    ppbVar22[4] = (byte *)0x0;
    ppbVar22[9] = (byte *)0x0;
    ppbVar22[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar22 + 0xb) = 0;
    uStack_21c0 = CONCAT44(uVar5,uVar2);
    if ((**ppbVar22 & 2) != 0) {
      pbVar1 = pbVar23 + uVar25;
      if ((pbVar23[uVar25] & 1) == 0) {
        *(undefined2 *)(ppbVar22 + 2) = 0;
        ppbVar22[3] = pbVar1;
        *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar22 + 0x36) = 0;
        switch(*pbVar1 & 0xe) {
        default:
          uVar16 = (uint)*(ushort *)(pbVar1 + 2);
          if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100486;
            func_0x(pbVar1,6);
          }
          break;
        case 4:
          uVar16 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar16 = 1;
        }
        *(uint *)(ppbVar22 + 4) = uVar16;
        *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar22 + 2) = 1;
        ppbVar22[3] = pbVar1;
        bVar12 = *pbVar1;
        switch(bVar12 & 0x1c) {
        default:
          if ((char)pbVar1[1] < '\0') {
            uVar11 = *(ushort *)(pbVar1 + 1);
            sVar13 = 3;
            *(ushort *)((longlong)ppbVar22 + 0x12) = uVar11;
            uVar11 = (uVar11 & 0x7f) << 8 | uVar11 >> 8;
          }
          else {
            sVar13 = 2;
            uVar11 = (ushort)pbVar1[1];
          }
          *(ushort *)((longlong)ppbVar22 + 0x12) = uVar11;
          *(short *)(ppbVar22 + 5) = sVar13;
          uVar11 = *(ushort *)((longlong)ppbVar22 + 0x12);
          *(short *)((longlong)ppbVar22 + 0x2c) = (short)(uVar11 + 1 >> 1) + sVar13;
          if (uVar11 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar22 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
            *(undefined4 *)(ppbVar22 + 8) = 0;
            ppbVar22[7] = (byte *)0x0;
            ppbVar22[4] = (byte *)0x0;
          }
          else {
            iVar6 = uVar11 - 1;
            *(short *)((longlong)ppbVar22 + 0x2a) =
                 ((short)(iVar6 / 0x1e) + (short)(iVar6 >> 0x1f)) -
                 (short)((longlong)iVar6 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
            *(undefined4 *)(ppbVar22 + 8) = 0;
            ppbVar22[7] = (byte *)0x0;
            ppbVar22[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar12 & 0x1c) != 4) || (uVar17 = 1, (bVar12 & 2) == 0)) {
            uVar17 = uVar16;
          }
          if (uVar17 == 0) {
            uVar15 = 1;
          }
          else {
            *(undefined4 *)(ppbVar22 + 8) = 0;
          }
          ppbVar22[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
          ppbVar22[6] = (byte *)0x0;
          ppbVar22[4] = (byte *)0x0;
          ppbVar22[7] = (byte *)0x0;
          ppbVar22[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar22 + 0x14) = uVar15;
          *(uint *)(ppbVar22 + 8) = (uint)(uVar17 != 0);
          ppbVar22[7] = (byte *)0x0;
          ppbVar22[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar22[7] = (byte *)0x0;
          ppbVar22[7] = (byte *)0x0;
          ppbVar22[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
          ppbVar22[6] = (byte *)0x0;
          ppbVar22[4] = (byte *)0x0;
          ppbVar22[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar22 + 0x14) = 9;
          *(undefined4 *)(ppbVar22 + 8) = 0;
          ppbVar22[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar22 & 4) != 0) {
      if (uStack_21c0._2_2_ != 0) {
        uVar25 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)uStack_21c0._2_2_ * 2);
      }
      psVar8 = (short *)(pbVar23 + uVar25);
      ppbVar22[9] = (byte *)psVar8;
      sVar13 = *psVar8;
      ppbVar22[10] = (byte *)(psVar8 + 1);
      *(short *)(ppbVar22 + 0xb) = (sVar13 + 1) * 2;
    }
    pbVar23 = ppbVar22[1];
    param_1 = lStack_21a0;
    param_4 = puStack_2198;
    if (pbVar23 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10051b;
      func_0x(pbVar23,ppbVar22);
      param_1 = lStack_21a0;
      param_4 = puStack_2198;
    }
  }
  uVar25 = 0;
  uVar16 = (uint)*(ushort *)(param_1 + 0xe);
  pbStack_2178 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)(int)uStack_21ac) * 2)
                         + param_1);
  if ((*pbStack_2178 & 1) == 0) {
    sStack_2180 = 0;
    uStack_217c = 0;
    uStack_215a = 0;
    uStack_2158 = 0;
    switch(*pbStack_2178 & 0xe) {
    default:
      uVar16 = (uint)*(ushort *)(pbStack_2178 + 2);
      if (0x1f9d < *(ushort *)(pbStack_2178 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100713;
        func_0x(pbStack_2178,6);
        uVar25 = (ulonglong)uStack_217c;
      }
      break;
    case 4:
      uVar16 = 9;
      uVar25 = 0;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar16 = 1;
    }
    uVar17 = (uint)uVar25;
    uStack_2170 = (byte **)CONCAT44(uStack_2170._4_4_,uVar16);
    lVar24 = param_1 + 0x2000;
    if (param_1 == 0) {
      lVar24 = 0;
    }
    uStack_2162 = (undefined2)lVar24;
    uStack_2160 = (undefined6)((ulonglong)lVar24 >> 0x10);
  }
  else {
    sStack_2180 = 1;
    bVar12 = *pbStack_2178;
    switch(bVar12 & 0x1c) {
    default:
      if ((char)pbStack_2178[1] < '\0') {
        uStack_217e = (*(ushort *)(pbStack_2178 + 1) & 0x7f) << 8 |
                      *(ushort *)(pbStack_2178 + 1) >> 8;
        uStack_2168._0_2_ = 3;
        sVar26 = 3;
      }
      else {
        uStack_217e = (ushort)pbStack_2178[1];
        uStack_2168._0_2_ = 2;
      }
      uStack_2164 = ((ushort)(uStack_217e + 1) >> 1) + sVar26;
      uVar20 = uVar25;
      if (uStack_217e < 0x1f) {
        uStack_2168._2_2_ = 0;
        uStack_217c = 0;
        uStack_2150 = 0;
      }
      else {
        iVar6 = uStack_217e - 1;
        uStack_2150 = 0;
        uStack_217c = 0;
        uStack_2168._2_2_ =
             ((short)(iVar6 / 0x1e) + (short)(iVar6 >> 0x1f)) -
             (short)((longlong)iVar6 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar12 & 0x1c) == 4) && ((bVar12 & 2) != 0)) {
        uStack_2168._0_2_ = 0;
        uStack_2168._2_2_ = 0;
        uStack_2164 = 0;
        uStack_2162 = 0;
        uStack_217e = 0;
        uStack_2160 = 0;
        uStack_215a = 0;
        uStack_217c = 0xf;
        uStack_2150 = 1;
      }
      else {
        uVar20 = 1;
        uStack_2168._0_2_ = 0;
        uStack_2168._2_2_ = 0;
        uStack_2164 = 0;
        uStack_2162 = 0;
        uStack_217c = 1;
        uStack_217e = 0;
        uStack_2160 = 0;
        uStack_215a = 0;
        uStack_2150 = 0;
      }
      break;
    case 8:
      uVar20 = 9;
      uStack_2168._0_2_ = 0;
      uStack_2168._2_2_ = 0;
      uStack_2164 = 0;
      uStack_2162 = 0;
      uStack_217c = 9;
      uStack_217e = 0;
      uStack_2160 = 0;
      uStack_215a = 0;
      uStack_2150 = 0;
    }
    uVar17 = (uint)uVar20;
    uVar20 = param_1 + 0x2000;
    if (param_1 == 0) {
      uVar20 = uVar25;
    }
    uStack_2158 = (undefined2)uVar20;
    uStack_2156 = (undefined2)(uVar20 >> 0x10);
    uStack_2154 = (ushort)(uVar20 >> 0x20);
    uStack_2152 = (undefined2)(uVar20 >> 0x30);
    uStack_2170 = ppbVar22;
  }
  if (sStack_2180 == 0) {
    bVar12 = *pbStack_2178 >> 6;
  }
  else {
    bVar12 = *pbStack_2178 >> 1;
  }
  if ((bVar12 & 1) == 0) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1007b2;
    (*_DAT_)(1,0x14dd148,0x14a81c8,0xa61);
    uVar17 = uStack_217c;
  }
  if (sStack_2180 == 0) {
    bVar27 = false;
    bVar12 = *pbStack_2178 & 0xe;
    if (bVar12 == 2) {
      bVar27 = (pbStack_2178[1] & 1) != 0;
    }
    else if (((bVar12 - 10 & 0xf9) == 0) && (bVar12 != 0x10)) {
      bVar27 = true;
    }
  }
  else {
    bVar27 = ((*pbStack_2178 & 0x1c) - 4 & 0xffffffe7) == 0;
  }
  if (!bVar27) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10082b;
    (*_DAT_)(1,0x14dd168,0x14a81c8,0xa62);
    uVar17 = uStack_217c;
  }
  if (sStack_2180 == 0) {
    if (uVar17 == 0) {
      uVar20 = (ulonglong)uStack_2170 & 0xffffffff;
      uStack_217e = 0;
      uVar16 = (uint)uStack_2170;
      if ((*pbStack_2178 & 0x10) != 0) {
        uVar16 = (uint)uStack_2170 + 2 + (*(ushort *)(pbStack_2178 + uVar20) + 7 >> 3);
        uVar20 = (ulonglong)uVar16;
      }
      uStack_2170 = (byte **)CONCAT44(uVar16,(uint)uStack_2170);
      if ((*pbStack_2178 & 0x20) == 0) {
        uStack_2164 = 0;
        uStack_217c = (uint)uVar20;
        uStack_2168 = (uint)uVar20;
      }
      else {
        puVar21 = (ushort *)(pbStack_2178 + uVar20);
        uStack_2164 = *puVar21;
        if (uStack_2164 == 0) {
          if ((((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
              (lVar24 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                         (ulonglong)*puRam0000000000fa10e0), lVar24 != 0)) &&
             ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
              (*(char *)(lVar24 + 0x499) != '\0')))) {
            if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100916;
              (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10093a;
              (*_DAT_)(1,0x1323278,0x1442f48,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100948;
          func_0x(pbStack_2178,3);
        }
        uStack_2168 = uStack_2170._4_4_ + (uStack_2164 + 1) * 2;
        if (0x1f9e < uStack_2168) {
          if (((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
             ((lVar24 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                         (ulonglong)*puRam0000000000fa10e0), lVar24 != 0 &&
              ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
               (*(char *)(lVar24 + 0x499) != '\0')))))) {
            if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1009e1;
              (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100a05;
              (*_DAT_)(1,0x1323278,0x1442f48,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100a13;
          func_0x(pbStack_2178,4);
        }
        uStack_217c = puVar21[uStack_2164] & 0x7fff;
        uVar20 = (ulonglong)uStack_217c;
        if (uStack_217c < uStack_2168) {
          if ((((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
              (lVar24 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                         (ulonglong)*puRam0000000000fa10e0), lVar24 != 0)) &&
             ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
              (*(char *)(lVar24 + 0x499) != '\0')))) {
            if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100aa4;
              (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100ae1;
              (*_DAT_)(1,0x1323278,0x1442f48,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100ab5;
          func_0x(pbStack_2178,4);
          uVar20 = (ulonglong)uStack_217c;
        }
        do {
          if (-1 < (short)puVar21[(ulonglong)(uStack_2164 - 1) + 1]) break;
          uVar16 = uStack_2168;
          if (((uStack_2164 != 1) &&
              (uVar16 = *(ushort *)
                         (pbStack_2178 +
                         (ulonglong)uStack_2164 * 2 + (((ulonglong)uStack_2170 >> 0x20) - 2)) &
                        0x7fff, uVar16 < uStack_2168)) ||
             ((*(ushort *)
                (pbStack_2178 + (ulonglong)uStack_2164 * 2 + ((ulonglong)uStack_2170 >> 0x20)) &
              0x7fff) < uVar16)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100b3b;
            func_0x(pbStack_2178,7);
            uVar20 = (ulonglong)uStack_217c;
          }
          uVar17 = (uint)uVar20;
          if ((uVar16 < uStack_2168) || (uVar17 < uVar16)) goto code_r0x00100e0b;
          if (*(ushort *)(pbStack_2178 + uVar16) == 5) {
            uStack_217e = uStack_217e | 2;
            uStack_2164 = uStack_2164 - 1;
            uStack_2156 = (undefined2)uVar16;
            if ((*(ushort *)(pbStack_2178 + (ulonglong)(uVar16 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_2154 = uStack_2154 & 0xc7ff;
            }
            else {
              uStack_2154 = uStack_2154 ^
                            (*(ushort *)(pbStack_2178 + (ulonglong)(uVar16 & 0xffff) + 2) ^
                            uStack_2154) & 0x3800;
            }
            uStack_2154 = (uStack_2154 ^
                          *(ushort *)(pbStack_2178 + (ulonglong)(uVar16 & 0xffff) + 2)) & 0x7ff ^
                          uStack_2154;
            break;
          }
          if (*(ushort *)(pbStack_2178 + uVar16) < 0x400) break;
          uStack_217e = uStack_217e | 1;
          uStack_2164 = uStack_2164 - 1;
        } while (uStack_2164 != 0);
      }
      if ((*pbStack_2178 & 0x40) == 0) {
        uStack_215a = 0;
        uStack_2158 = 0;
      }
      else {
        uStack_215a = (undefined2)uVar20;
        uStack_2158 = (undefined2)(uVar20 >> 0x10);
        uStack_217c = (int)uVar20 + 0xe;
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100c13;
        puVar9 = (ulonglong *)func_0x(&uStack_217e);
        iVar6 = 0;
        uVar20 = *puVar9;
        uVar14 = (ushort)(uVar20 >> 0x30);
        uVar11 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar11 = uVar14 & 0xdfff;
          if ((uVar20 & 0x4000000000000000) != 0) {
            uVar11 = uVar14 | 0x2000;
          }
        }
        if (uVar11 == 0xfffc) {
          iVar6 = (int)((uVar20 >> 0x20 & 0xffff) >> 5);
        }
        uStack_217c = uStack_217c + iVar6;
        uVar20 = (ulonglong)uStack_217c;
      }
      uVar17 = (uint)uVar20;
      if (((byte *)CONCAT62(uStack_2160,uStack_2162) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_2160,uStack_2162) < pbStack_2178 + uVar20)) {
        if (((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
           (((lVar24 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                        (ulonglong)*puRam0000000000fa10e0), lVar24 != 0 &&
             (lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0)) &&
            (*(char *)(lVar24 + 0x499) != '\0')))) {
          if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100d0d;
            (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100d33;
            (*_DAT_)(1,0x1323278,0x1442f48,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100d41;
        func_0x(pbStack_2178,0x12);
        uVar17 = uStack_217c;
      }
      if (0x3f3b < uVar17 - 1) {
        if (((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
           ((lVar24 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                       (ulonglong)*puRam0000000000fa10e0), lVar24 != 0 &&
            ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
             (*(char *)(lVar24 + 0x499) != '\0')))))) {
          if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100dc9;
            (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100e06;
            (*_DAT_)(1,0x1323278,0x1442f48,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100dda;
        func_0x(pbStack_2178,5);
        uVar17 = uStack_217c;
      }
    }
code_r0x00100e0b:
    uVar16 = uVar17;
    if ((uVar17 < 9) && (((*pbStack_2178 & 0xe) == 0 || ((*pbStack_2178 & 0xe) == 0xc)))) {
      uVar16 = 9;
    }
  }
  else {
    if (uVar17 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100e3b;
      func_0x(&uStack_217e);
      uVar17 = uStack_217c;
    }
    uVar16 = uVar17;
    if ((uVar17 < 9) && (((*pbStack_2178 & 0x1c) == 0 || ((*pbStack_2178 & 0x1c) == 0xc)))) {
      uVar16 = 9;
    }
  }
  ppbVar22 = (byte **)0x0;
  *(short *)(&stack0x00000018 + lVar7) = sStack_2180;
  iVar6 = 0;
  if (sStack_2180 != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101587;
    func_0x(&stack0x0000001a + lVar7,auStack_1fe8,0x1f9e,&uStack_217e);
    pbVar23 = *(byte **)(&stack0x00000020 + lVar7);
    ppbVar10 = uStack_2170;
    if (sStack_2180 == 0) {
      ppbVar10 = ppbVar22;
    }
    *(byte ***)((longlong)&param_5 + lVar7) = ppbVar10;
    goto code_r0x001015a3;
  }
  if (uVar17 == 0) {
    uVar20 = (ulonglong)uStack_2170 & 0xffffffff;
    uStack_217e = 0;
    uVar17 = (uint)uStack_2170;
    if ((*pbStack_2178 & 0x10) != 0) {
      uVar17 = (uint)uStack_2170 + 2 + (*(ushort *)(pbStack_2178 + uVar20) + 7 >> 3);
      uVar20 = (ulonglong)uVar17;
    }
    uStack_2170 = (byte **)CONCAT44(uVar17,(uint)uStack_2170);
    if ((*pbStack_2178 & 0x20) == 0) {
      uStack_2164 = 0;
      uStack_217c = (uint)uVar20;
      uStack_2168 = (uint)uVar20;
    }
    else {
      puVar21 = (ushort *)(pbStack_2178 + uVar20);
      uStack_2164 = *puVar21;
      if (uStack_2164 == 0) {
        if ((((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
            (lVar24 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                       (ulonglong)*puRam0000000000fa10e0), lVar24 != 0)) &&
           ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
            (*(char *)(lVar24 + 0x499) != '\0')))) {
          if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100f3e;
            (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3eb);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100f64;
            (*_DAT_)(1,0x1323278,0x1442f48,0x80f);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100f72;
        func_0x(pbStack_2178,3);
      }
      uStack_2168 = uStack_2170._4_4_ + (uStack_2164 + 1) * 2;
      if (0x1f9e < uStack_2168) {
        if (((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
           ((lVar24 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                       (ulonglong)*puRam0000000000fa10e0), lVar24 != 0 &&
            ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
             (*(char *)(lVar24 + 0x499) != '\0')))))) {
          if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101008;
            (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10102e;
            (*_DAT_)(1,0x1323278,0x1442f48,0x816);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10103c;
        func_0x(pbStack_2178,4);
      }
      uStack_217c = puVar21[uStack_2164] & 0x7fff;
      uVar20 = (ulonglong)uStack_217c;
      if (uStack_217c < uStack_2168) {
        if ((((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
            (lVar24 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                       (ulonglong)*puRam0000000000fa10e0), lVar24 != 0)) &&
           ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
            (*(char *)(lVar24 + 0x499) != '\0')))) {
          if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1010d1;
            (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1010f7;
            (*_DAT_)(1,0x1323278,0x1442f48,0x81d);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101105;
        func_0x(pbStack_2178,4);
        uVar20 = (ulonglong)uStack_217c;
      }
      do {
        if (-1 < (short)puVar21[(ulonglong)(uStack_2164 - 1) + 1]) break;
        uVar18 = uStack_2168;
        if (((uStack_2164 != 1) &&
            (uVar18 = *(ushort *)
                       (pbStack_2178 +
                       (ulonglong)uStack_2164 * 2 + (((ulonglong)uStack_2170 >> 0x20) - 2)) & 0x7fff
            , uVar18 < uStack_2168)) ||
           ((*(ushort *)
              (pbStack_2178 + (ulonglong)uStack_2164 * 2 + ((ulonglong)uStack_2170 >> 0x20)) &
            0x7fff) < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10115f;
          func_0x(pbStack_2178,7);
          uVar20 = (ulonglong)uStack_217c;
        }
        uVar17 = (uint)uVar20;
        if ((uVar18 < uStack_2168) || (uVar17 < uVar18)) goto code_r0x00101436;
        if (*(ushort *)(pbStack_2178 + uVar18) == 5) {
          uStack_217e = uStack_217e | 2;
          uStack_2164 = uStack_2164 - 1;
          uStack_2156 = (undefined2)uVar18;
          if ((*(ushort *)(pbStack_2178 + (ulonglong)(uVar18 & 0xffff) + 2) & 0x4000) == 0) {
            uStack_2154 = uStack_2154 & 0xc7ff;
          }
          else {
            uStack_2154 = uStack_2154 ^
                          (uStack_2154 ^
                          *(ushort *)(pbStack_2178 + (ulonglong)(uVar18 & 0xffff) + 2)) & 0x3800;
          }
          uStack_2154 = (uStack_2154 ^ *(ushort *)(pbStack_2178 + (ulonglong)(uVar18 & 0xffff) + 2))
                        & 0x7ff ^ uStack_2154;
          break;
        }
        if (*(ushort *)(pbStack_2178 + uVar18) < 0x400) break;
        uStack_217e = uStack_217e | 1;
        uStack_2164 = uStack_2164 - 1;
      } while (uStack_2164 != 0);
    }
    if ((*pbStack_2178 & 0x40) == 0) {
      uStack_215a = 0;
      uStack_2158 = 0;
    }
    else {
      uStack_215a = (undefined2)uVar20;
      uStack_2158 = (undefined2)(uVar20 >> 0x10);
      uStack_217c = (int)uVar20 + 0xe;
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101239;
      puVar9 = (ulonglong *)func_0x(&uStack_217e);
      uVar20 = *puVar9;
      uVar14 = (ushort)(uVar20 >> 0x30);
      uVar11 = uVar14;
      if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
        uVar11 = uVar14 & 0xdfff;
        if ((uVar20 & 0x4000000000000000) != 0) {
          uVar11 = uVar14 | 0x2000;
        }
      }
      if (uVar11 == 0xfffc) {
        iVar6 = (int)((uVar20 >> 0x20 & 0xffff) >> 5);
      }
      uStack_217c = uStack_217c + iVar6;
      uVar20 = (ulonglong)uStack_217c;
    }
    uVar17 = (uint)uVar20;
    if (((byte *)CONCAT62(uStack_2160,uStack_2162) != (byte *)0x0) &&
       ((byte *)CONCAT62(uStack_2160,uStack_2162) < pbStack_2178 + uVar20)) {
      if (((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
         (((lVar24 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                        (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                      (ulonglong)*puRam0000000000fa10e0), lVar24 != 0 &&
           (lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0)) &&
          (*(char *)(lVar24 + 0x499) != '\0')))) {
        if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101338;
          (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10135e;
          (*_DAT_)(1,0x1323278,0x1442f48,0x877);
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10136c;
      func_0x(pbStack_2178,0x12);
      uVar17 = uStack_217c;
    }
    if (0x3f3b < uVar17 - 1) {
      if (((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
         ((lVar24 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                       (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                     (ulonglong)*puRam0000000000fa10e0), lVar24 != 0 &&
          ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
           (*(char *)(lVar24 + 0x499) != '\0')))))) {
        if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1013f8;
          (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10141e;
          (*_DAT_)(1,0x1323278,0x1442f48,0x87c);
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10142c;
      func_0x(pbStack_2178,5);
      uVar17 = uStack_217c;
    }
  }
code_r0x00101436:
  uVar18 = uVar17;
  if ((uVar17 < 9) && (((*pbStack_2178 & 0xe) == 0 || ((*pbStack_2178 & 0xe) == 0xc)))) {
    uVar18 = 9;
  }
  *(uint *)((longlong)&param_5 + lVar7) = (uint)uStack_2170;
  *(ushort *)(&stack0x0000001a + lVar7) = uStack_217e;
  *(ushort *)(&stack0x00000034 + lVar7) = uStack_2164;
  *(int *)(&stack0x0000002c + lVar7) = uStack_2170._4_4_;
  *(uint *)((longlong)&param_6 + lVar7) = uStack_2168;
  *(uint *)(&stack0x0000003e + lVar7) = CONCAT22(uStack_2158,uStack_215a);
  *(uint *)(&stack0x0000001c + lVar7) = uVar17;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10149f;
  func_0x(auStack_1fe8,0x1f9e,pbStack_2178,uVar18);
  *(undefined **)(&stack0x00000020 + lVar7) = auStack_1fe8;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1014b5;
  iVar6 = func_0x(&stack0x0000001a + lVar7);
  pbVar23 = *(byte **)(&stack0x00000020 + lVar7);
  if (iVar6 == 0) goto code_r0x001015a3;
  puVar21 = (ushort *)(pbVar23 + *(uint *)(&stack0x0000002c + lVar7));
  uVar17 = *puVar21 - 1;
  if (((&stack0x0000001a)[lVar7] & 1) == 0) {
    uVar17 = (uint)*puVar21;
  }
  if (uVar17 == 1) {
    uVar18 = *(uint *)((longlong)&param_6 + lVar7);
code_r0x001014f6:
    if ((puVar21[(int)uVar17] & 0x7fff) < uVar18) goto code_r0x00101503;
  }
  else {
    uVar18 = puVar21[(longlong)(int)uVar17 + -1] & 0x7fff;
    if (*(uint *)((longlong)&param_6 + lVar7) <= uVar18) goto code_r0x001014f6;
code_r0x00101503:
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101510;
    func_0x(pbVar23,7);
    pbVar23 = *(byte **)(&stack0x00000020 + lVar7);
  }
  uVar11 = *(ushort *)((longlong)&param_8 + lVar7 + 4);
  *(short *)((longlong)&param_8 + lVar7 + 2) = (short)uVar18;
  if ((*(ushort *)(pbVar23 + (ulonglong)(uVar18 & 0xffff) + 2) & 0x4000) == 0) {
    uVar11 = uVar11 & 0xc7ff;
  }
  else {
    uVar11 = uVar11 ^ (uVar11 ^ *(ushort *)(pbVar23 + (ulonglong)(uVar18 & 0xffff) + 2)) & 0x3800;
  }
  *(ushort *)((longlong)&param_8 + lVar7 + 4) = uVar11;
  *(ushort *)((longlong)&param_8 + lVar7 + 4) =
       (uVar11 ^ *(ushort *)(pbVar23 + (ulonglong)(uVar18 & 0xffff) + 2)) & 0x7ff ^ uVar11;
code_r0x001015a3:
  if (*(short *)(&stack0x00000018 + lVar7) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1015b5;
    func_0x(&stack0x0000001a + lVar7);
  }
  else if ((*pbVar23 & 2) != 0) {
    if (*(int *)(&stack0x0000001c + lVar7) == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1015ce;
      func_0x(&stack0x0000001a + lVar7);
      pbVar23 = *(byte **)(&stack0x00000020 + lVar7);
    }
    *pbVar23 = *pbVar23 & 0xfd;
    *(undefined4 *)(&stack0x0000001c + lVar7) = uStack_21c8;
  }
  if (param_4 == (ulonglong *)0x0) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10160d;
    (*_DAT_)(1,0x14dd180,0x14a81c8,0xa75);
  }
  uVar20 = *param_4;
  uVar14 = (ushort)(uVar20 >> 0x30);
  uVar11 = uVar14;
  if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
    uVar11 = uVar14 & 0xdfff;
    if ((uVar20 & 0x4000000000000000) != 0) {
      uVar11 = uVar14 | 0x2000;
    }
  }
  if ((uVar11 == 0xfffc) && (0x1f < (ushort)(uVar20 >> 0x20))) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101686;
    (*_DAT_)(1,0x14dd0d0,0x14a81c8,0xa79);
  }
  uStack_20c0 = *(undefined4 *)(param_4 + 1);
  uStack_20c8 = *param_4;
  uStack_20bc = *(undefined2 *)((longlong)param_4 + 0xc);
  if (*(short *)(&stack0x00000018 + lVar7) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1016c2;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1016c9;
    func_0x(&stack0x0000001a + lVar7,&uStack_20c8);
  }
  if (*(short *)(&stack0x00000018 + lVar7) == 0) {
    uVar17 = *(uint *)(&stack0x0000001c + lVar7);
    if (uVar17 == 0) {
      uVar17 = *(uint *)((longlong)&param_5 + lVar7);
      uVar20 = (ulonglong)uVar17;
      *(undefined2 *)(&stack0x0000001a + lVar7) = 0;
      *(uint *)(&stack0x0000002c + lVar7) = uVar17;
      if ((**(byte **)(&stack0x00000020 + lVar7) & 0x10) != 0) {
        uVar17 = uVar17 + 2 + (*(ushort *)(*(byte **)(&stack0x00000020 + lVar7) + uVar20) + 7 >> 3);
        uVar20 = (ulonglong)uVar17;
        *(uint *)(&stack0x0000002c + lVar7) = uVar17;
      }
      if ((**(byte **)(&stack0x00000020 + lVar7) & 0x20) == 0) {
        *(int *)(&stack0x0000001c + lVar7) = (int)uVar20;
        *(undefined2 *)(&stack0x00000034 + lVar7) = 0;
        *(int *)((longlong)&param_6 + lVar7) = (int)uVar20;
      }
      else {
        puVar21 = (ushort *)(*(byte **)(&stack0x00000020 + lVar7) + uVar20);
        uVar11 = *puVar21;
        *(ushort *)(&stack0x00000034 + lVar7) = uVar11;
        if (uVar11 == 0) {
          if ((((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
              (lVar24 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                         (ulonglong)*puRam0000000000fa10e0), lVar24 != 0)) &&
             ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
              (*(char *)(lVar24 + 0x499) != '\0')))) {
            if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1017ae;
              (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1017d1;
              (*_DAT_)(1,0x1323278,0x1442f48,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1017e0;
          func_0x(*(undefined8 *)(&stack0x00000020 + lVar7),3);
          uVar11 = *(ushort *)(&stack0x00000034 + lVar7);
        }
        uVar18 = *(int *)(&stack0x0000002c + lVar7) + 2 + (uint)uVar11 * 2;
        *(uint *)((longlong)&param_6 + lVar7) = uVar18;
        if (0x1f9e < uVar18) {
          if (((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
             ((lVar24 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                         (ulonglong)*puRam0000000000fa10e0), lVar24 != 0 &&
              ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
               (*(char *)(lVar24 + 0x499) != '\0')))))) {
            if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101882;
              (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1018a5;
              (*_DAT_)(1,0x1323278,0x1442f48,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1018b4;
          func_0x(*(undefined8 *)(&stack0x00000020 + lVar7),4);
          uVar11 = *(ushort *)(&stack0x00000034 + lVar7);
          uVar18 = *(uint *)((longlong)&param_6 + lVar7);
        }
        uVar25 = (ulonglong)uVar11;
        uVar17 = puVar21[uVar25] & 0x7fff;
        *(uint *)(&stack0x0000001c + lVar7) = uVar17;
        if (uVar17 < uVar18) {
          if ((((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
              (lVar24 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                         (ulonglong)*puRam0000000000fa10e0), lVar24 != 0)) &&
             ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
              (*(char *)(lVar24 + 0x499) != '\0')))) {
            if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101955;
              (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101978;
              (*_DAT_)(1,0x1323278,0x1442f48,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101987;
          func_0x(*(undefined8 *)(&stack0x00000020 + lVar7),4);
          uVar25 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar7);
          uVar18 = *(uint *)((longlong)&param_6 + lVar7);
          uVar17 = *(uint *)(&stack0x0000001c + lVar7);
        }
        uVar20 = (ulonglong)uVar17;
        do {
          if (-1 < (short)puVar21[(ulonglong)((int)uVar25 - 1) + 1]) break;
          uVar19 = uVar18;
          if ((((int)uVar25 != 1) &&
              (uVar19 = *(ushort *)
                         ((ulonglong)*(uint *)(&stack0x0000002c + lVar7) +
                          *(longlong *)(&stack0x00000020 + lVar7) + -2 + uVar25 * 2) & 0x7fff,
              uVar19 < uVar18)) ||
             ((*(ushort *)
                ((ulonglong)*(uint *)(&stack0x0000002c + lVar7) +
                 *(longlong *)(&stack0x00000020 + lVar7) + uVar25 * 2) & 0x7fff) < uVar19)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1019f6;
            func_0x(*(undefined8 *)(&stack0x00000020 + lVar7),7);
            uVar25 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar7);
            uVar18 = *(uint *)((longlong)&param_6 + lVar7);
            uVar20 = (ulonglong)*(uint *)(&stack0x0000001c + lVar7);
          }
          uVar17 = (uint)uVar20;
          if ((uVar19 < uVar18) || (uVar17 < uVar19)) goto code_r0x00101cfe;
          if (*(ushort *)((ulonglong)uVar19 + *(longlong *)(&stack0x00000020 + lVar7)) == 5) {
            *(ushort *)(&stack0x0000001a + lVar7) = *(ushort *)(&stack0x0000001a + lVar7) | 2;
            uVar11 = *(ushort *)((longlong)&param_8 + lVar7 + 4);
            *(short *)(&stack0x00000034 + lVar7) = (short)uVar25 + -1;
            *(short *)((longlong)&param_8 + lVar7 + 2) = (short)uVar19;
            lVar24 = (ulonglong)(uVar19 & 0xffff) + *(longlong *)(&stack0x00000020 + lVar7);
            uVar14 = *(ushort *)(lVar24 + 2);
            if ((uVar14 & 0x4000) == 0) {
              uVar11 = uVar11 & 0xc7ff;
            }
            else {
              uVar11 = uVar11 ^ (uVar11 ^ uVar14) & 0x3800;
            }
            *(ushort *)((longlong)&param_8 + lVar7 + 4) = uVar11;
            *(ushort *)((longlong)&param_8 + lVar7 + 4) =
                 (uVar11 ^ *(ushort *)(lVar24 + 2)) & 0x7ff ^ uVar11;
            break;
          }
          if (*(ushort *)((ulonglong)uVar19 + *(longlong *)(&stack0x00000020 + lVar7)) < 0x400)
          break;
          *(ushort *)(&stack0x0000001a + lVar7) = *(ushort *)(&stack0x0000001a + lVar7) | 1;
          uVar11 = (short)uVar25 - 1;
          uVar25 = (ulonglong)uVar11;
          *(ushort *)(&stack0x00000034 + lVar7) = uVar11;
        } while (uVar11 != 0);
      }
      if ((**(byte **)(&stack0x00000020 + lVar7) & 0x40) == 0) {
        *(undefined4 *)(&stack0x0000003e + lVar7) = 0;
      }
      else {
        *(int *)(&stack0x0000003e + lVar7) = (int)uVar20;
        *(int *)(&stack0x0000001c + lVar7) = (int)uVar20 + 0xe;
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101b0e;
        puVar9 = (ulonglong *)func_0x(&stack0x0000001a + lVar7);
        uVar20 = *puVar9;
        uVar14 = (ushort)(uVar20 >> 0x30);
        uVar11 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar11 = uVar14 & 0xdfff;
          if ((uVar20 & 0x4000000000000000) != 0) {
            uVar11 = uVar14 | 0x2000;
          }
        }
        if (uVar11 == 0xfffc) {
          ppbVar22 = (byte **)((uVar20 >> 0x20 & 0xffff) >> 5);
        }
        uVar17 = *(int *)(&stack0x0000001c + lVar7) + (int)ppbVar22;
        uVar20 = (ulonglong)uVar17;
        *(uint *)(&stack0x0000001c + lVar7) = uVar17;
      }
      uVar17 = (uint)uVar20;
      if ((*(ulonglong *)(&stack0x00000036 + lVar7) != 0) &&
         (*(ulonglong *)(&stack0x00000036 + lVar7) <
          uVar20 + *(longlong *)(&stack0x00000020 + lVar7))) {
        if (((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
           (((lVar24 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                        (ulonglong)*puRam0000000000fa10e0), lVar24 != 0 &&
             (lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0)) &&
            (*(char *)(lVar24 + 0x499) != '\0')))) {
          if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101c09;
            (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101c2c;
            (*_DAT_)(1,0x1323278,0x1442f48,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101c3b;
        func_0x(*(undefined8 *)(&stack0x00000020 + lVar7),0x12);
        uVar17 = *(uint *)(&stack0x0000001c + lVar7);
      }
      if (0x3f3b < uVar17 - 1) {
        if (((cRam0000000001a3284b != '\0') || ((bRam0000000001a43150 & 1) != 0)) &&
           ((lVar24 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000fa10d8 * 8) + 8 +
                       (ulonglong)*puRam0000000000fa10e0), lVar24 != 0 &&
            ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
             (*(char *)(lVar24 + 0x499) != '\0')))))) {
          if ((cRam0000000001a3273b == '\0') && ((bRam0000000001a43150 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101cc8;
            (*pcRam0000000000fa1078)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101ceb;
            (*_DAT_)(1,0x1323278,0x1442f48,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101cfa;
        func_0x(*(undefined8 *)(&stack0x00000020 + lVar7),5);
        uVar17 = *(uint *)(&stack0x0000001c + lVar7);
      }
    }
code_r0x00101cfe:
    if ((8 < uVar17) ||
       (((**(byte **)(&stack0x00000020 + lVar7) & 0xe) != 0 &&
        ((**(byte **)(&stack0x00000020 + lVar7) & 0xe) != 0xc)))) {
      uStack_21b0 = uVar17;
    }
  }
  else {
    uVar17 = *(uint *)(&stack0x0000001c + lVar7);
    if (uVar17 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101d2c;
      func_0x(&stack0x0000001a + lVar7);
      uVar17 = *(uint *)(&stack0x0000001c + lVar7);
    }
    uStack_21b0 = uVar17;
    if ((uVar17 < 9) &&
       (((**(byte **)(&stack0x00000020 + lVar7) & 0x1c) == 0 ||
        ((**(byte **)(&stack0x00000020 + lVar7) & 0x1c) == 0xc)))) {
      uStack_21b0 = 9;
    }
  }
  uVar18 = uStack_21a8;
  uVar17 = uStack_21b0;
  uVar19 = 1;
  if (uStack_21a8 == 0) {
    uVar19 = param_5;
  }
  if (uStack_21b0 != uVar16) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101d8d;
    (*_DAT_)(1,0x14dd100,0x14a81c8,0xa92);
  }
  uVar3 = uStack_21ac;
  *(undefined8 *)((longlong)apbStackX_8 + lVar7) = uStack_2190;
  *(undefined2 *)(&stack0x00000020 + lVar7 + -0x20) = param_6;
  *(uint *)(&stack0xfffffffffffffff8 + lVar7) = uVar19;
  *(undefined **)(&stack0xfffffffffffffff0 + lVar7) = auStack_1fe8;
  *(uint *)(&stack0xffffffffffffffe8 + lVar7) = uVar17;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101dc7;
  func_0x(param_1,uVar3,0,uVar16);
  if ((param_7 != '\0') && (uVar18 != 0)) {
    if ((*(ushort *)(param_1 + 0x38) < *(ushort *)(puStack_2188 + 1)) ||
       ((*(ushort *)(puStack_2188 + 1) == *(ushort *)(param_1 + 0x38) &&
        (*(uint *)(param_1 + 0x34) < *puStack_2188)))) {
      *(uint *)(param_1 + 0x34) = *puStack_2188;
      *(undefined2 *)(param_1 + 0x38) = *(undefined2 *)(puStack_2188 + 1);
    }
  }
  *(ushort *)(param_1 + 4) = *(ushort *)(param_1 + 4) & 0x3fff;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x101e19;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar7));
  return;
}

