
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(ushort *param_1,undefined8 param_2,int *param_3)

{
  byte bVar1;
  ushort uVar2;
  int iVar3;
  ulonglong *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  ulonglong uVar7;
  uint uVar8;
  ushort *puVar9;
  ushort uVar10;
  byte *pbVar11;
  longlong lVar12;
  longlong unaff_GS_OFFSET;
  
  iVar3 = 0;
  if (*(int *)(param_1 + 1) == 0) {
    pbVar11 = *(byte **)(param_1 + 3);
    uVar6 = *(uint *)(param_1 + 7);
    uVar7 = (ulonglong)uVar6;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar6;
    bVar1 = *pbVar11;
    if ((bVar1 & 0x10) != 0) {
      uVar6 = uVar6 + 2 + (*(ushort *)(pbVar11 + uVar7) + 7 >> 3);
      uVar7 = (ulonglong)uVar6;
      *(uint *)(param_1 + 9) = uVar6;
      bVar1 = *pbVar11;
    }
    if ((bVar1 & 0x20) == 0) {
      *(int *)(param_1 + 1) = (int)uVar7;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = (int)uVar7;
    }
    else {
      puVar9 = (ushort *)(pbVar11 + uVar7);
      uVar2 = *puVar9;
      param_1[0xd] = uVar2;
      if (uVar2 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar12 != 0)) &&
           ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9ed188,0xb0ce58,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar7 = (ulonglong)*(uint *)(param_1 + 9);
        uVar2 = param_1[0xd];
      }
      uVar6 = (int)uVar7 + (uVar2 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar6;
      if (0x1f9e < uVar6) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar12 != 0 &&
            ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
             (*(char *)(lVar12 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ed188,0xb0ce58,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar2 = param_1[0xd];
        uVar6 = *(uint *)(param_1 + 0xb);
      }
      uVar7 = (ulonglong)uVar2;
      uVar2 = puVar9[uVar7];
      *(uint *)(param_1 + 1) = uVar2 & 0x7fff;
      if ((uVar2 & 0x7fff) < uVar6) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar12 != 0)) &&
           ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ed188,0xb0ce58,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar7 = (ulonglong)param_1[0xd];
      }
      if ((short)puVar9[(ulonglong)((int)uVar7 - 1) + 1] < 0) {
        pbVar11 = *(byte **)(param_1 + 3);
        do {
          if ((int)uVar7 == 1) {
            uVar6 = *(uint *)(param_1 + 0xb);
            uVar8 = uVar6;
LAB_:
            if ((*(ushort *)(pbVar11 + uVar7 * 2 + (ulonglong)*(uint *)(param_1 + 9)) & 0x7fff) <
                uVar6) goto LAB_;
          }
          else {
            uVar8 = *(uint *)(param_1 + 0xb);
            uVar6 = *(ushort *)(pbVar11 + uVar7 * 2 + ((ulonglong)*(uint *)(param_1 + 9) - 2)) &
                    0x7fff;
            if (uVar8 <= uVar6) goto LAB_;
LAB_:
            func_0x(pbVar11,7);
            uVar8 = *(uint *)(param_1 + 0xb);
          }
          if ((uVar6 < uVar8) || (*(uint *)(param_1 + 1) < uVar6)) goto LAB_;
          pbVar11 = *(byte **)(param_1 + 3);
          if (*(ushort *)(pbVar11 + uVar6) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = param_1[0xd] - 1;
            param_1[0x14] = (ushort)uVar6;
            lVar12 = (ulonglong)(uVar6 & 0xffff) + *(longlong *)(param_1 + 3);
            uVar2 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(lVar12 + 2) >> 0xe & 1) != 0) {
              uVar2 = *(ushort *)(lVar12 + 2) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar2;
            param_1[0x15] = (uVar2 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar2;
            goto LAB_;
          }
          if (*(ushort *)(pbVar11 + uVar6) < 0x400) goto LAB_;
          *param_1 = *param_1 | 1;
          uVar2 = param_1[0xd] - 1;
          param_1[0xd] = uVar2;
          if (uVar2 == 0) goto LAB_;
          uVar7 = (ulonglong)uVar2;
        } while ((short)puVar9[(ulonglong)(uVar2 - 1) + 1] < 0);
        uVar7 = (ulonglong)*(uint *)(param_1 + 1);
      }
      else {
LAB_:
        uVar7 = (ulonglong)*(uint *)(param_1 + 1);
        pbVar11 = *(byte **)(param_1 + 3);
      }
    }
    if ((*pbVar11 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar7;
      *(int *)(param_1 + 1) = (int)uVar7 + 0xe;
      puVar4 = (ulonglong *)func_0x(param_1);
      uVar10 = (ushort)(*puVar4 >> 0x30);
      uVar2 = uVar10;
      if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
        uVar2 = uVar10 & 0xdfff;
        if ((uVar10 >> 0xe & 1) != 0) {
          uVar2 = uVar10 | 0x2000;
        }
      }
      if (uVar2 == 0xfffc) {
        iVar3 = (int)((*puVar4 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar3;
      uVar7 = (ulonglong)*(uint *)(param_1 + 1);
    }
    iVar3 = (int)uVar7;
    if ((*(ulonglong *)(param_1 + 0xe) != 0) &&
       (*(ulonglong *)(param_1 + 0xe) < uVar7 + *(longlong *)(param_1 + 3))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar12 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar12 != 0 &&
           (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
          (*(char *)(lVar12 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9ed188,0xb0ce58,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      iVar3 = *(int *)(param_1 + 1);
    }
    if (0x3f3b < iVar3 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar12 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar12 != 0 &&
          ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
           (*(char *)(lVar12 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9ed188,0xb0ce58,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
    }
  }
LAB_:
  if ((*(byte *)param_1 & 1) == 0) {
    *param_3 = 0;
    return 0;
  }
  uVar2 = param_1[0xd];
  uVar10 = uVar2 + 1;
  iVar3 = func_0x(param_1);
  if (iVar3 != 0) {
    uVar10 = uVar2 + 2;
  }
  lVar12 = *(longlong *)(param_1 + 3);
  uVar6 = *(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar12 + (ulonglong)uVar10 * 2) & 0x7fff;
  if (uVar10 == 1) {
    uVar7 = (ulonglong)*(uint *)(param_1 + 0xb);
LAB_:
    if ((uint)uVar7 <= uVar6) goto LAB_;
  }
  else {
    uVar8 = *(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar12 + -2 + (ulonglong)uVar10 * 2) &
            0x7fff;
    uVar7 = (ulonglong)uVar8;
    if (*(uint *)(param_1 + 0xb) <= uVar8) goto LAB_;
  }
  func_0x(lVar12,7);
  lVar12 = *(longlong *)(param_1 + 3);
LAB_:
  if (lVar12 + uVar7 == 0) {
    puVar5 = (undefined4 *)(*_DAT_)();
    *puVar5 = 0x16;
    (*_DAT_)();
    lVar12 = *(longlong *)(param_1 + 3);
  }
  *param_3 = (uVar6 - (int)uVar7) + -2;
  return lVar12 + 2 + uVar7;
}

