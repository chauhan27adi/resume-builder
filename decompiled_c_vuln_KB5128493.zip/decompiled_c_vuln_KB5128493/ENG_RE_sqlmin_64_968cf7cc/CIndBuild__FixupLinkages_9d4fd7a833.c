
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  undefined8 uVar4;
  undefined auVar5 [16];
  uint **ppuVar6;
  undefined auVar7 [16];
  char cVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  uint *puVar17;
  short *psVar18;
  ulonglong *puVar19;
  ushort uVar20;
  ushort uVar21;
  undefined4 uVar22;
  ulonglong uVar23;
  ulonglong uVar24;
  int iVar25;
  ulonglong uVar26;
  int *piVar27;
  byte **ppbVar28;
  byte **ppbVar29;
  ulonglong uVar30;
  ushort *puVar31;
  byte **ppbVar32;
  ulonglong uVar33;
  int *piVar34;
  ulonglong uVar35;
  short sVar36;
  longlong *plVar37;
  longlong *plVar38;
  ulonglong uVar39;
  undefined2 uVar40;
  longlong lVar41;
  longlong lVar42;
  byte *pbVar43;
  undefined *puVar44;
  ulonglong uVar45;
  undefined uVar46;
  longlong unaff_GS_OFFSET;
  undefined auStack_b38 [32];
  undefined8 uStack_b18;
  undefined8 uStack_b10;
  undefined8 uStack_b08;
  uint uStack_b00;
  undefined uStack_af8;
  undefined4 uStack_af0;
  longlong lStack_ae8;
  undefined4 *puStack_ae0;
  int aiStack_ad8 [2];
  longlong *plStack_ad0;
  undefined uStack_ac8;
  uint uStack_ac4;
  uint uStack_ac0;
  longlong *plStack_ab8;
  undefined uStack_ab0;
  uint uStack_aac;
  uint uStack_aa8;
  undefined uStack_aa0;
  int iStack_a9c;
  short sStack_a98;
  int iStack_a94;
  short sStack_a90;
  uint uStack_a8c;
  undefined4 uStack_a88;
  longlong *plStack_a80;
  longlong lStack_a78;
  uint uStack_a70;
  uint uStack_a6c;
  uint uStack_a68;
  undefined4 uStack_a64;
  undefined8 uStack_a60;
  ushort uStack_a58;
  undefined8 uStack_a50;
  ushort uStack_a48;
  undefined8 uStack_a40;
  ushort uStack_a38;
  undefined8 uStack_a30;
  undefined2 uStack_a28;
  undefined8 uStack_a20;
  undefined2 uStack_a18;
  undefined8 uStack_a10;
  undefined2 uStack_a08;
  undefined8 uStack_a00;
  undefined2 uStack_9f8;
  undefined8 uStack_9f0;
  ushort uStack_9e8;
  undefined auStack_9e0 [4];
  undefined4 uStack_9dc;
  undefined4 uStack_9d8;
  undefined4 uStack_9d4;
  undefined4 uStack_9d0;
  undefined2 uStack_9cc;
  undefined4 uStack_9c8;
  undefined2 uStack_9c4;
  undefined4 uStack_9c0;
  undefined2 uStack_9bc;
  undefined4 uStack_9b8;
  undefined2 uStack_9b4;
  undefined4 uStack_9b0;
  undefined2 uStack_9ac;
  undefined4 uStack_9a8;
  undefined2 uStack_9a4;
  uint uStack_9a0;
  undefined2 uStack_99c;
  undefined4 uStack_998;
  undefined2 uStack_994;
  undefined4 uStack_990;
  undefined2 uStack_98c;
  undefined4 uStack_988;
  undefined2 uStack_984;
  undefined4 uStack_980;
  undefined2 uStack_97c;
  undefined auStack_978 [4];
  undefined4 uStack_974;
  undefined2 uStack_970;
  undefined8 uStack_968;
  undefined2 uStack_960;
  undefined8 uStack_958;
  undefined2 uStack_950;
  undefined8 uStack_948;
  undefined4 uStack_940;
  undefined8 uStack_93c;
  undefined4 uStack_934;
  undefined8 uStack_930;
  undefined4 uStack_928;
  undefined8 uStack_924;
  undefined4 uStack_91c;
  longlong *plStack_918;
  undefined4 uStack_910;
  undefined8 uStack_908;
  undefined2 uStack_900;
  undefined8 uStack_8f8;
  ushort uStack_8f0;
  undefined8 uStack_8e8;
  undefined2 uStack_8e0;
  undefined8 uStack_8d8;
  ushort uStack_8d0;
  undefined auStack_8c8 [4];
  undefined auStack_8c4 [4];
  undefined auStack_8c0 [4];
  undefined auStack_8bc [4];
  undefined auStack_8b8 [4];
  undefined auStack_8b4 [4];
  longlong lStack_8b0;
  undefined auStack_8a8 [4];
  undefined auStack_8a4 [4];
  uint uStack_8a0;
  undefined8 uStack_89c;
  uint uStack_888;
  undefined8 uStack_884;
  undefined8 uStack_860;
  undefined auStack_858 [8];
  undefined4 uStack_850;
  undefined4 uStack_848;
  uint **ppuStack_840;
  undefined *puStack_838;
  undefined8 uStack_830;
  uint *puStack_828;
  undefined4 uStack_820;
  undefined4 uStack_81c;
  longlong lStack_818;
  undefined4 uStack_810;
  undefined4 uStack_80c;
  longlong lStack_808;
  undefined4 uStack_800;
  undefined4 uStack_7fc;
  short *psStack_7f8;
  int iStack_7f0;
  undefined4 uStack_7ec;
  short *psStack_7e8;
  int iStack_7e0;
  undefined4 uStack_7dc;
  undefined8 uStack_7d8;
  undefined4 uStack_7d0;
  undefined4 uStack_7cc;
  undefined auStack_7c8 [448];
  undefined8 uStack_608;
  undefined8 uStack_600;
  uint uStack_5f8;
  short sStack_5f4;
  int iStack_5f2;
  undefined uStack_5ee;
  undefined uStack_5ed;
  undefined auStack_5b8 [8];
  undefined4 uStack_5b0;
  undefined4 uStack_5a8;
  uint **ppuStack_5a0;
  undefined *puStack_598;
  undefined8 uStack_590;
  uint *puStack_588;
  undefined4 uStack_580;
  undefined4 uStack_57c;
  longlong lStack_578;
  undefined4 uStack_570;
  undefined4 uStack_56c;
  longlong lStack_568;
  undefined4 uStack_560;
  undefined4 uStack_55c;
  short *psStack_558;
  int iStack_550;
  undefined4 uStack_54c;
  short *psStack_548;
  int iStack_540;
  undefined4 uStack_53c;
  undefined8 uStack_538;
  undefined4 uStack_530;
  undefined4 uStack_52c;
  undefined auStack_528 [448];
  undefined8 uStack_368;
  undefined8 uStack_360;
  uint uStack_358;
  short sStack_354;
  int iStack_352;
  undefined uStack_34e;
  undefined uStack_34d;
  ushort uStack_318;
  ushort uStack_316;
  uint uStack_314;
  int *piStack_310;
  undefined8 uStack_308;
  undefined4 uStack_300;
  ushort uStack_2fc;
  undefined2 uStack_2fa;
  undefined6 uStack_2f8;
  ushort uStack_2f2;
  undefined2 uStack_2f0;
  undefined2 uStack_2ee;
  ushort uStack_2ec;
  undefined2 uStack_2ea;
  uint uStack_2e8;
  int iStack_2e4;
  undefined auStack_2e0 [16];
  undefined auStack_2d0 [8];
  undefined8 uStack_2c8;
  undefined8 uStack_2c0;
  undefined6 uStack_2b8;
  undefined2 uStack_2b2;
  undefined6 uStack_2b0;
  undefined2 uStack_2aa;
  undefined8 uStack_2a8;
  undefined auStack_2a0 [16];
  undefined auStack_290 [16];
  undefined auStack_280 [16];
  undefined8 uStack_270;
  undefined2 uStack_268;
  ushort uStack_266;
  undefined4 uStack_264;
  byte *pbStack_260;
  undefined8 uStack_258;
  undefined2 uStack_250;
  short sStack_24e;
  short sStack_24c;
  undefined2 uStack_24a;
  undefined6 uStack_248;
  undefined2 uStack_242;
  undefined2 uStack_240;
  undefined6 uStack_23e;
  undefined4 uStack_238;
  int iStack_234;
  undefined auStack_230 [16];
  undefined auStack_220 [2];
  undefined auStack_21e [6];
  undefined8 uStack_218;
  uint uStack_210;
  undefined4 uStack_20c;
  short sStack_208;
  short sStack_206;
  short sStack_204;
  undefined2 uStack_202;
  undefined6 uStack_200;
  undefined2 uStack_1fa;
  undefined2 uStack_1f8;
  undefined6 uStack_1f6;
  uint uStack_1f0;
  undefined4 uStack_1ec;
  short *psStack_1e8;
  short *psStack_1e0;
  short sStack_1d8;
  undefined6 uStack_1d6;
  undefined auStack_1d0 [10];
  undefined auStack_1c6 [6];
  undefined8 uStack_1c0;
  ushort uStack_1b8;
  ushort uStack_1b6;
  undefined4 uStack_1b4;
  byte *pbStack_1b0;
  undefined8 uStack_1a8;
  undefined2 uStack_1a0;
  ushort uStack_19e;
  short sStack_19c;
  undefined2 uStack_19a;
  undefined6 uStack_198;
  ushort uStack_192;
  undefined2 uStack_190;
  undefined6 uStack_18e;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined auStack_180 [16];
  undefined auStack_170 [8];
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined6 uStack_158;
  undefined2 uStack_152;
  undefined6 uStack_150;
  undefined2 uStack_14a;
  undefined8 uStack_148;
  undefined auStack_140 [16];
  undefined auStack_130 [16];
  undefined auStack_120 [16];
  undefined8 uStack_110;
  uint auStack_108 [2];
  short asStack_100 [24];
  short asStack_d0 [24];
  short asStack_a0 [24];
  short asStack_70 [24];
  ulonglong uStack_40;
  
  uStack_860 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_b38;
  uStack_318 = 0xffff;
  piStack_310 = (int *)0x0;
  uStack_314 = 0;
  uStack_2fa = 0;
  uStack_2f8 = 0;
  uStack_2f0 = 0;
  uStack_2ee = 0;
  uStack_2ec = 0;
  uStack_2ea = 0;
  uStack_308 = (byte **)0x0;
  iStack_2e4 = 0xffffffff;
  plStack_918 = param_1 + 4;
  lStack_8b0 = param_1[5];
  plStack_a80 = param_1;
  if ((*(int *)((longlong)param_1 + 0xf5c) == 0) && (*(short *)(param_1 + 0x1ec) == 0)) {
LAB_:
    func_0x(uStack_40 ^ (ulonglong)auStack_b38);
    return;
  }
  plStack_ad0 = (longlong *)0x0;
  uStack_ac8 = 0;
  uStack_ac4 = 0;
  plStack_ab8 = (longlong *)0x0;
  uStack_ab0 = 0;
  uStack_aac = 0;
  iStack_a9c = *(int *)((longlong)param_1 + 0xf5c);
  sStack_a98 = *(short *)(param_1 + 0x1ec);
  iStack_a94 = *(int *)((longlong)param_1 + 0xf54);
  sStack_a90 = *(short *)(param_1 + 0x1eb);
  uStack_a64 = 2;
code_r0x0010011f:
  lVar16 = *(longlong *)(*plStack_a80 + 0x30);
  lVar14 = 0;
  uStack_89c = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar42 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar42 != 0) && (lVar42 = **(longlong **)(lVar42 + 0x38), lVar42 != 0)) {
      iVar9 = (*_DAT_)(lVar42,0x337);
      if (iVar9 != 0) goto LAB_;
    }
    lVar42 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar42 != 0) {
      lVar14 = *(longlong *)(lVar42 + 0x60);
    }
  }
LAB_:
  lVar42 = *(longlong *)(lVar16 + 0x728);
LAB_:
  plVar38 = plStack_ad0;
  lVar15 = 0;
  iVar9 = 0;
  uStack_a70 = 0;
  if (plStack_ad0 != (longlong *)0x0) {
    iVar25 = (int)(short)uStack_ac4;
    if (((*(ushort *)((longlong)plStack_ad0 + 0x62) & 0x400) == 0) || (iVar25 < 3)) {
      if (((byte)*(undefined2 *)((longlong)plStack_ad0 + 0x62) >> 3 & 1) != 0) {
        if (iVar25 == 3) {
          iVar25 = 4;
        }
        else if (iVar25 < 2) goto LAB_;
        if ((((*(uint *)((longlong)plStack_ad0 + 100) & 8) != 0) &&
            (lVar41 = plStack_ad0[0x12], lVar41 != 0)) && (*(longlong *)(lVar41 + 0x758) != 0)) {
          func_0x(*(undefined8 *)(lVar41 + 0x758),plStack_ad0,iVar25);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar38 + 100) & 8) != 0)) &&
         ((2 < iVar25 &&
          (((*(uint *)((longlong)plVar38 + 100) & 0xc0000000) != 0x40000000 && (*plVar38 != 0))))))
      {
        iVar11 = (*_DAT_)(*plVar38,0x2000,2,auStack_8a4);
        if (iVar11 != 0) {
          LOCK();
          *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      func_0x(plVar38 + 0x13,iVar25);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        func_0x(plVar38,0,iVar25);
      }
      uStack_ac4 = uStack_ac4 & 0xffff0000;
      plStack_ad0 = (longlong *)0x0;
    }
    else {
      func_0x(&plStack_ad0);
    }
  }
  if (*(longlong *)(lVar16 + 0x728) != 0) {
    func_0x(&plStack_ad0,&iStack_a9c,lVar16);
    plVar38 = plStack_ad0;
    if (plStack_ad0 != (longlong *)0x0) {
      iVar25 = (int)(short)uStack_ac4;
      if (((*(ushort *)((longlong)plStack_ad0 + 0x62) & 0x400) == 0) || (iVar25 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_ad0 + 0x62) >> 3 & 1) != 0) {
          if (iVar25 == 3) {
            iVar25 = 4;
          }
          else if (iVar25 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_ad0 + 100) & 8) != 0) &&
              (lVar41 = plStack_ad0[0x12], lVar41 != 0)) && (*(longlong *)(lVar41 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar41 + 0x758),plStack_ad0,iVar25);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar38 + 100) & 8) != 0)) &&
           ((2 < iVar25 &&
            (((*(uint *)((longlong)plVar38 + 100) & 0xc0000000) != 0x40000000 && (*plVar38 != 0)))))
           ) {
          iVar11 = (*_DAT_)(*plVar38,0x2000,2,auStack_8a8);
          if (iVar11 != 0) {
            LOCK();
            *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        func_0x(plVar38 + 0x13,iVar25);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar38,0,iVar25);
        }
        uStack_ac4 = uStack_ac4 & 0xffff0000;
        plStack_ad0 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_ad0);
      }
    }
  }
  func_0x(lVar16,&iStack_a9c);
  uStack_b10 = &uStack_8a0;
  uStack_b18 = (uint *)CONCAT44(uStack_b18._4_4_,4);
  plStack_ad0 = (longlong *)func_0x(_DAT_,lVar16,&iStack_a9c,&uStack_a70);
  if (lVar14 != 0) {
    uVar45 = (ulonglong)(*(uint *)(lVar14 + 0x500) & 0xf);
    if (*(longlong *)(lVar14 + 0x508 + uVar45 * 8) != *plStack_ad0) {
      *(longlong *)(lVar14 + 0x508 + uVar45 * 8) = *plStack_ad0;
      *(longlong *)(lVar14 + 0x500) = *(longlong *)(lVar14 + 0x500) + 1;
    }
  }
  uStack_ac4 = (uStack_a70 >> 3 & 1) << 0x18 | uStack_ac4 & 0xff0004 | 4;
  uStack_ac0 = uStack_a70 >> 4 & 1 | uStack_ac0 & 0xffffff00;
  if (((lVar42 != 0) && (lVar14 != 0)) && (lVar14 == *(longlong *)(lVar16 + 0x1c38))) {
    *(longlong *)(lVar42 + 0x5b28) = *(longlong *)(lVar42 + 0x5b28) + 1;
    if ((int)uStack_89c != 0) {
      *(longlong *)(lVar42 + 0x5b30) = *(longlong *)(lVar42 + 0x5b30) + 1;
      *(longlong *)(lVar42 + 0x5b38) = *(longlong *)(lVar42 + 0x5b38) + (ulonglong)uStack_8a0;
      if (0xffffff < uStack_ac4) {
        *(longlong *)(lVar42 + 0x5b40) = *(longlong *)(lVar42 + 0x5b40) + 1;
        *(longlong *)(lVar42 + 0x5b48) = *(longlong *)(lVar42 + 0x5b48) + (ulonglong)uStack_8a0;
      }
    }
  }
  cVar8 = func_0x(lVar16);
  if (((cVar8 == '\0') || (*(char *)(lVar16 + 0x2050) == '\0')) ||
     ((iStack_a9c == 0 || ((iStack_a9c == 9 && (sStack_a98 == 1)))))) goto LAB_;
  lVar41 = *plStack_ad0;
  if (*(short *)(lVar41 + 0x24) == 0) {
LAB_:
    uStack_a40 = *(undefined8 *)(lVar41 + 0x28);
    uStack_a38 = *(ushort *)(lVar41 + 0x30);
  }
  else {
    cVar8 = *(char *)(lVar41 + 1);
    if (cVar8 == '\v') {
      if (*(int *)(lVar41 + 0x18) != 99) {
LAB_:
        if (cVar8 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar8 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar41 + 0x18) != 99) goto LAB_;
    }
    uStack_9d0 = *(undefined4 *)(lVar41 + 0x20);
    uStack_9cc = *(undefined2 *)(lVar41 + 0x24);
    cVar8 = func_0x(&uStack_9d0);
    if (cVar8 == '\0') goto LAB_;
    func_0x(lVar41,&uStack_a40);
  }
  uVar12 = *(uint *)(lVar16 + 0x2108);
  do {
    uVar10 = uVar12 & 0xfffffffe;
    uStack_948 = *(undefined8 *)(lVar16 + 0x20fc);
    uStack_940 = *(undefined4 *)(lVar16 + 0x2104);
    LOCK();
    UNLOCK();
    uVar12 = *(uint *)(lVar16 + 0x2108);
  } while (uVar10 != uVar12);
  if ((uint)uStack_a40 <= (uint)uStack_948) {
    if ((uint)uStack_948 != (uint)uStack_a40) goto LAB_;
    uVar12 = (uint)((ulonglong)uStack_948 >> 0x20);
    if ((uStack_a40._4_4_ <= uVar12) &&
       ((uVar12 != uStack_a40._4_4_ || (uStack_a38 <= (ushort)uStack_940)))) goto LAB_;
  }
  if ((*(char *)(lVar16 + 0x6ac8) == '\0') &&
     (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) != *(longlong *)(lVar16 + 0x2120))) {
    cVar8 = func_0x(lVar16);
    if (cVar8 == '\0') {
      uVar12 = *(uint *)(lVar16 + 0x2108);
      do {
        uVar10 = uVar12 & 0xfffffffe;
        uStack_93c = *(undefined8 *)(lVar16 + 0x20fc);
        uStack_934 = *(undefined4 *)(lVar16 + 0x2104);
        LOCK();
        UNLOCK();
        uVar12 = *(uint *)(lVar16 + 0x2108);
      } while (uVar10 != uVar12);
      uVar21 = (ushort)uStack_934;
      uStack_8d0 = (ushort)uStack_934;
      lVar14 = *plStack_ad0;
      uStack_8d8 = uStack_93c;
      if (*(short *)(lVar14 + 0x24) == 0) {
LAB_:
        uStack_a60 = *(undefined8 *)(lVar14 + 0x28);
        uStack_a58 = *(ushort *)(lVar14 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar14 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(lVar14 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_9c0 = *(undefined4 *)(lVar14 + 0x20);
        uStack_9bc = *(undefined2 *)(lVar14 + 0x24);
        cVar8 = func_0x(&uStack_9c0);
        if (cVar8 == '\0') goto LAB_;
        func_0x(lVar14,&uStack_a60);
      }
      if ((uint)uStack_93c < (uint)uStack_a60) {
LAB_:
        lVar14 = *(longlong *)(lVar16 + 0x6b0);
        func_0x(&uStack_a60,asStack_100,auStack_9e0);
        func_0x(&uStack_8d8,asStack_d0,auStack_9e0);
        if ((_DAT_ & 0x10000) != 0) {
          uStack_850 = 0x60000;
          uStack_848 = 0;
          ppuStack_840 = &puStack_828;
          puStack_838 = auStack_7c8;
          uStack_608 = 0;
          uStack_830 = 0;
          uStack_600 = 0;
          puStack_828 = &uStack_5f8;
          uStack_820 = 0x34;
          uStack_81c = 5;
          uStack_810 = 0x10;
          uStack_80c = 5;
          uStack_800 = 0x10;
          uStack_7fc = 6;
          uStack_7ec = 7;
          uStack_7dc = 8;
          uStack_7d8 = 0;
          uStack_7d0 = 0;
          uStack_7cc = 9;
          uStack_5f8 = (uint)*(ushort *)(lVar16 + 0x6b8);
          sStack_5f4 = sStack_a98;
          iStack_5f2 = iStack_a9c;
          uStack_5ee = 0xff;
          uStack_5ed = *(undefined *)(*plStack_ad0 + 1);
          lStack_818 = lVar14 + 0x254;
          lStack_808 = lVar14 + 0x244;
          lVar16 = -1;
          do {
            lVar16 = lVar16 + 1;
          } while (asStack_100[lVar16] != 0);
          iStack_7f0 = (int)lVar16 * 2;
          psStack_7f8 = asStack_100;
          lVar16 = -1;
          do {
            lVar16 = lVar16 + 1;
          } while (asStack_d0[lVar16] != 0);
          iStack_7e0 = (int)lVar16 * 2;
          psStack_7e8 = asStack_d0;
          uStack_9dc = 0;
          puVar17 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar14,&uStack_9dc);
          ppuVar6 = ppuStack_840;
          if (puVar17 != (uint *)0x0) {
            lVar16 = -1;
            do {
              lVar16 = lVar16 + 1;
            } while (*(short *)((longlong)puVar17 + lVar16 * 2) != 0);
            iVar9 = (int)lVar16 * 2;
          }
          ppuStack_840[10] = puVar17;
          *(int *)(ppuVar6 + 0xb) = iVar9;
          *(undefined4 *)((longlong)ppuVar6 + 0x5c) = 9;
          func_0x(auStack_858);
        }
      }
      else if ((uint)uStack_93c == (uint)uStack_a60) {
        uVar12 = (uint)((ulonglong)uStack_a60 >> 0x20);
        if ((uStack_93c._4_4_ < uVar12) || ((uStack_93c._4_4_ == uVar12 && (uVar21 < uStack_a58))))
        goto LAB_;
      }
LAB_:
      lVar16 = *(longlong *)(*plStack_a80 + 0x30);
      uStack_884 = 0;
      if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
        lVar14 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
        if ((lVar14 != 0) && (lVar14 = **(longlong **)(lVar14 + 0x38), lVar14 != 0)) {
          iVar9 = (*_DAT_)(lVar14,0x337);
          if (iVar9 != 0) goto LAB_;
        }
        lVar14 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
        if (lVar14 != 0) {
          lVar15 = *(longlong *)(lVar14 + 0x60);
        }
      }
LAB_:
      lVar14 = *(longlong *)(lVar16 + 0x728);
      do {
        plVar38 = plStack_ab8;
        iVar9 = 0;
        uStack_a6c = 0;
        if (plStack_ab8 != (longlong *)0x0) {
          iVar25 = (int)(short)uStack_aac;
          if (((*(ushort *)((longlong)plStack_ab8 + 0x62) & 0x400) == 0) || (iVar25 < 3)) {
            if (((byte)*(undefined2 *)((longlong)plStack_ab8 + 0x62) >> 3 & 1) != 0) {
              if (iVar25 == 3) {
                iVar25 = 4;
              }
              else if (iVar25 < 2) goto LAB_;
              if ((((*(uint *)((longlong)plStack_ab8 + 100) & 8) != 0) &&
                  (lVar42 = plStack_ab8[0x12], lVar42 != 0)) && (*(longlong *)(lVar42 + 0x758) != 0)
                 ) {
                func_0x(*(undefined8 *)(lVar42 + 0x758),plStack_ab8,iVar25);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar38 + 100) & 8) != 0)) &&
               ((2 < iVar25 &&
                (((*(uint *)((longlong)plVar38 + 100) & 0xc0000000) != 0x40000000 && (*plVar38 != 0)
                 ))))) {
              iVar11 = (*_DAT_)(*plVar38,0x2000,2,auStack_8b8);
              if (iVar11 != 0) {
                LOCK();
                *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            func_0x(plVar38 + 0x13,iVar25);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(plVar38,0,iVar25);
            }
            uStack_aac = uStack_aac & 0xffff0000;
            plStack_ab8 = (longlong *)0x0;
          }
          else {
            func_0x(&plStack_ab8);
          }
        }
        if (*(longlong *)(lVar16 + 0x728) != 0) {
          func_0x(&plStack_ab8,&iStack_a94,lVar16);
          plVar38 = plStack_ab8;
          if (plStack_ab8 != (longlong *)0x0) {
            iVar25 = (int)(short)uStack_aac;
            if (((*(ushort *)((longlong)plStack_ab8 + 0x62) & 0x400) == 0) || (iVar25 < 3)) {
              if (((byte)*(undefined2 *)((longlong)plStack_ab8 + 0x62) >> 3 & 1) != 0) {
                if (iVar25 == 3) {
                  iVar25 = 4;
                }
                else if (iVar25 < 2) goto LAB_;
                if ((((*(uint *)((longlong)plStack_ab8 + 100) & 8) != 0) &&
                    (lVar42 = plStack_ab8[0x12], lVar42 != 0)) &&
                   (*(longlong *)(lVar42 + 0x758) != 0)) {
                  func_0x(*(undefined8 *)(lVar42 + 0x758),plStack_ab8,iVar25);
                }
              }
LAB_:
              if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar38 + 100) & 8) != 0))
                 && ((2 < iVar25 &&
                     (((*(uint *)((longlong)plVar38 + 100) & 0xc0000000) != 0x40000000 &&
                      (*plVar38 != 0)))))) {
                iVar11 = (*_DAT_)(*plVar38,0x2000,2,auStack_8bc);
                if (iVar11 != 0) {
                  LOCK();
                  *(uint *)((longlong)plVar38 + 100) =
                       *(uint *)((longlong)plVar38 + 100) & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *(uint *)((longlong)plVar38 + 100) =
                       *(uint *)((longlong)plVar38 + 100) | 0x40000000;
                  UNLOCK();
                }
              }
              func_0x(plVar38 + 0x13,iVar25);
              if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                func_0x(plVar38,0,iVar25);
              }
              uStack_aac = uStack_aac & 0xffff0000;
              plStack_ab8 = (longlong *)0x0;
            }
            else {
              func_0x(&plStack_ab8);
            }
          }
        }
        func_0x(lVar16,&iStack_a94);
        uStack_b10 = &uStack_888;
        uStack_b18 = (uint *)CONCAT44(uStack_b18._4_4_,4);
        plStack_ab8 = (longlong *)
                      func_0x(_DAT_,lVar16,&iStack_a94,&uStack_a6c);
        if (lVar15 != 0) {
          uVar45 = (ulonglong)(*(uint *)(lVar15 + 0x500) & 0xf);
          if (*(longlong *)(lVar15 + 0x508 + uVar45 * 8) != *plStack_ab8) {
            *(longlong *)(lVar15 + 0x508 + uVar45 * 8) = *plStack_ab8;
            *(longlong *)(lVar15 + 0x500) = *(longlong *)(lVar15 + 0x500) + 1;
          }
        }
        uStack_aac = (uStack_a6c >> 3 & 1) << 0x18 | uStack_aac & 0xff0004 | 4;
        uStack_aa8 = uStack_a6c >> 4 & 1 | uStack_aa8 & 0xffffff00;
        if (((lVar14 != 0) && (lVar15 != 0)) && (lVar15 == *(longlong *)(lVar16 + 0x1c38))) {
          *(longlong *)(lVar14 + 0x5b28) = *(longlong *)(lVar14 + 0x5b28) + 1;
          if ((int)uStack_884 != 0) {
            *(longlong *)(lVar14 + 0x5b30) = *(longlong *)(lVar14 + 0x5b30) + 1;
            *(longlong *)(lVar14 + 0x5b38) = *(longlong *)(lVar14 + 0x5b38) + (ulonglong)uStack_888;
            if (0xffffff < uStack_aac) {
              *(longlong *)(lVar14 + 0x5b40) = *(longlong *)(lVar14 + 0x5b40) + 1;
              *(longlong *)(lVar14 + 0x5b48) =
                   *(longlong *)(lVar14 + 0x5b48) + (ulonglong)uStack_888;
            }
          }
        }
        cVar8 = func_0x(lVar16);
        if (((cVar8 == '\0') || (*(char *)(lVar16 + 0x2050) == '\0')) ||
           ((iStack_a94 == 0 || ((iStack_a94 == 9 && (sStack_a90 == 1)))))) goto LAB_;
        lVar42 = *plStack_ab8;
        if (*(short *)(lVar42 + 0x24) == 0) {
LAB_:
          uStack_9f0 = *(undefined8 *)(lVar42 + 0x28);
          uStack_9e8 = *(ushort *)(lVar42 + 0x30);
        }
        else {
          cVar8 = *(char *)(lVar42 + 1);
          if (cVar8 == '\v') {
            if (*(int *)(lVar42 + 0x18) != 99) {
LAB_:
              if (cVar8 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar8 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar42 + 0x18) != 99) goto LAB_;
          }
          uStack_9b8 = *(undefined4 *)(lVar42 + 0x20);
          uStack_9b4 = *(undefined2 *)(lVar42 + 0x24);
          cVar8 = func_0x(&uStack_9b8);
          if (cVar8 == '\0') goto LAB_;
          func_0x(lVar42,&uStack_9f0);
        }
        uVar12 = *(uint *)(lVar16 + 0x2108);
        do {
          uVar10 = uVar12 & 0xfffffffe;
          uStack_930 = *(undefined8 *)(lVar16 + 0x20fc);
          uStack_928 = *(undefined4 *)(lVar16 + 0x2104);
          LOCK();
          UNLOCK();
          uVar12 = *(uint *)(lVar16 + 0x2108);
        } while (uVar10 != uVar12);
        if ((uint)uStack_9f0 <= (uint)uStack_930) {
          if ((uint)uStack_930 == (uint)uStack_9f0) {
            uVar12 = (uint)((ulonglong)uStack_930 >> 0x20);
            if ((uVar12 < uStack_9f0._4_4_) ||
               ((uVar12 == uStack_9f0._4_4_ && ((ushort)uStack_928 < uStack_9e8))))
            goto LAB_;
          }
          goto LAB_;
        }
LAB_:
        if ((*(char *)(lVar16 + 0x6ac8) == '\0') &&
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8) + 0x60) != *(longlong *)(lVar16 + 0x2120))) {
          cVar8 = func_0x(lVar16);
          if (cVar8 == '\0') {
            uVar12 = *(uint *)(lVar16 + 0x2108);
            do {
              uVar10 = uVar12 & 0xfffffffe;
              uStack_924 = *(undefined8 *)(lVar16 + 0x20fc);
              uStack_91c = *(undefined4 *)(lVar16 + 0x2104);
              LOCK();
              UNLOCK();
              uVar12 = *(uint *)(lVar16 + 0x2108);
            } while (uVar10 != uVar12);
            uVar21 = (ushort)uStack_91c;
            uStack_8f0 = (ushort)uStack_91c;
            lVar14 = *plStack_ab8;
            uStack_8f8 = uStack_924;
            if (*(short *)(lVar14 + 0x24) == 0) {
LAB_:
              uStack_a50 = *(undefined8 *)(lVar14 + 0x28);
              uStack_a48 = *(ushort *)(lVar14 + 0x30);
            }
            else {
              cVar8 = *(char *)(lVar14 + 1);
              if (cVar8 == '\v') {
                if (*(int *)(lVar14 + 0x18) != 99) {
LAB_:
                  if (cVar8 != '\t') goto LAB_;
                  goto LAB_;
                }
              }
              else {
                if (cVar8 != '\b') goto LAB_;
LAB_:
                if (*(int *)(lVar14 + 0x18) != 99) goto LAB_;
              }
              uStack_9a8 = *(undefined4 *)(lVar14 + 0x20);
              uStack_9a4 = *(undefined2 *)(lVar14 + 0x24);
              cVar8 = func_0x(&uStack_9a8);
              if (cVar8 == '\0') goto LAB_;
              func_0x(lVar14,&uStack_a50);
            }
            if ((uint)uStack_924 < (uint)uStack_a50) {
LAB_:
              lVar14 = *(longlong *)(lVar16 + 0x6b0);
              func_0x(&uStack_a50,asStack_a0,auStack_978);
              func_0x(&uStack_8f8,asStack_70,auStack_978);
              if ((_DAT_ & 0x10000) != 0) {
                uStack_5b0 = 0x60000;
                uStack_5a8 = 0;
                ppuStack_5a0 = &puStack_588;
                puStack_598 = auStack_528;
                uStack_368 = 0;
                uStack_590 = 0;
                uStack_360 = 0;
                puStack_588 = &uStack_358;
                uStack_580 = 0x34;
                uStack_57c = 5;
                uStack_570 = 0x10;
                uStack_56c = 5;
                uStack_560 = 0x10;
                uStack_55c = 6;
                uStack_54c = 7;
                uStack_53c = 8;
                uStack_538 = 0;
                uStack_530 = 0;
                uStack_52c = 9;
                uStack_358 = (uint)*(ushort *)(lVar16 + 0x6b8);
                sStack_354 = sStack_a90;
                iStack_352 = iStack_a94;
                uStack_34e = 0xff;
                uStack_34d = *(undefined *)(*plStack_ab8 + 1);
                lStack_578 = lVar14 + 0x254;
                lStack_568 = lVar14 + 0x244;
                lVar16 = -1;
                do {
                  lVar16 = lVar16 + 1;
                } while (asStack_a0[lVar16] != 0);
                iStack_550 = (int)lVar16 * 2;
                psStack_558 = asStack_a0;
                lVar16 = -1;
                do {
                  lVar16 = lVar16 + 1;
                } while (asStack_70[lVar16] != 0);
                iStack_540 = (int)lVar16 * 2;
                psStack_548 = asStack_70;
                uStack_9d8 = 0;
                puVar17 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar14,&uStack_9d8);
                ppuVar6 = ppuStack_5a0;
                if (puVar17 != (uint *)0x0) {
                  lVar16 = -1;
                  do {
                    lVar16 = lVar16 + 1;
                  } while (*(short *)((longlong)puVar17 + lVar16 * 2) != 0);
                  iVar9 = (int)lVar16 * 2;
                }
                ppuStack_5a0[10] = puVar17;
                *(int *)(ppuVar6 + 0xb) = iVar9;
                *(undefined4 *)((longlong)ppuVar6 + 0x5c) = 9;
                func_0x(auStack_5b8);
              }
            }
            else if ((uint)uStack_924 == (uint)uStack_a50) {
              uVar12 = (uint)((ulonglong)uStack_a50 >> 0x20);
              if ((uStack_924._4_4_ < uVar12) ||
                 ((uStack_924._4_4_ == uVar12 && (uVar21 < uStack_a48)))) goto LAB_;
            }
            goto LAB_;
          }
        }
        if (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8) + 0x60) == *(longlong *)(lVar16 + 0x2120)) goto LAB_;
        cVar8 = func_0x(lVar16);
        if (cVar8 != '\0') goto LAB_;
        if (lVar15 == 0) {
          lVar15 = func_0x();
        }
        lVar42 = *plStack_ab8;
        if (*(short *)(lVar42 + 0x24) == 0) {
LAB_:
          uStack_958 = *(undefined8 *)(lVar42 + 0x28);
          uStack_950 = *(undefined2 *)(lVar42 + 0x30);
        }
        else {
          cVar8 = *(char *)(lVar42 + 1);
          if (cVar8 == '\v') {
            if (*(int *)(lVar42 + 0x18) != 99) {
LAB_:
              if (cVar8 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar8 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar42 + 0x18) != 99) goto LAB_;
          }
          uStack_9b0 = *(undefined4 *)(lVar42 + 0x20);
          uStack_9ac = *(undefined2 *)(lVar42 + 0x24);
          cVar8 = func_0x(&uStack_9b0);
          if (cVar8 == '\0') goto LAB_;
          func_0x(lVar42,&uStack_958);
        }
        uVar40 = uStack_950;
        uVar4 = uStack_958;
        plVar38 = plStack_ab8;
        if (plStack_ab8 != (longlong *)0x0) {
          iVar9 = (int)(short)uStack_aac;
          if (((*(ushort *)((longlong)plStack_ab8 + 0x62) >> 10 & 1) == 0) || (iVar9 < 3)) {
            if (((byte)*(undefined2 *)((longlong)plStack_ab8 + 0x62) >> 3 & 1) != 0) {
              if (iVar9 == 3) {
                iVar9 = 4;
              }
              else if (iVar9 < 2) goto LAB_;
              if ((((*(uint *)((longlong)plStack_ab8 + 100) & 8) != 0) &&
                  (lVar42 = plStack_ab8[0x12], lVar42 != 0)) && (*(longlong *)(lVar42 + 0x758) != 0)
                 ) {
                func_0x(*(undefined8 *)(lVar42 + 0x758),plStack_ab8,iVar9);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar38 + 100) & 8) != 0)) &&
               ((2 < iVar9 &&
                (((*(uint *)((longlong)plVar38 + 100) & 0xc0000000) != 0x40000000 && (*plVar38 != 0)
                 ))))) {
              iVar25 = (*_DAT_)(*plVar38,0x2000,2,auStack_8c0);
              if (iVar25 != 0) {
                LOCK();
                *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            func_0x(plVar38 + 0x13,iVar9);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(plVar38,0,iVar9);
            }
            uStack_aac = uStack_aac & 0xffff0000;
            plStack_ab8 = (longlong *)0x0;
          }
          else {
            func_0x(&plStack_ab8);
          }
        }
        uStack_b18 = (uint *)0x0;
        uStack_908 = uVar4;
        uStack_900 = uVar40;
        func_0x(*(undefined8 *)(lVar16 + 0x728),&uStack_908,4);
      } while( true );
    }
  }
  if (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) == *(longlong *)(lVar16 + 0x2120)) goto LAB_;
  cVar8 = func_0x(lVar16);
  if (cVar8 != '\0') goto LAB_;
  if (lVar14 == 0) {
    lVar14 = func_0x();
  }
  lVar15 = *plStack_ad0;
  if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
    uStack_968 = *(undefined8 *)(lVar15 + 0x28);
    uStack_960 = *(undefined2 *)(lVar15 + 0x30);
  }
  else {
    cVar8 = *(char *)(lVar15 + 1);
    if (cVar8 == '\v') {
      if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
        if (cVar8 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar8 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
    }
    uStack_9c8 = *(undefined4 *)(lVar15 + 0x20);
    uStack_9c4 = *(undefined2 *)(lVar15 + 0x24);
    cVar8 = func_0x(&uStack_9c8);
    if (cVar8 == '\0') goto LAB_;
    func_0x(lVar15,&uStack_968);
  }
  uVar40 = uStack_960;
  uVar4 = uStack_968;
  plVar38 = plStack_ad0;
  if (plStack_ad0 != (longlong *)0x0) {
    iVar9 = (int)(short)uStack_ac4;
    if (((*(ushort *)((longlong)plStack_ad0 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
      if (((byte)*(undefined2 *)((longlong)plStack_ad0 + 0x62) >> 3 & 1) != 0) {
        if (iVar9 == 3) {
          iVar9 = 4;
        }
        else if (iVar9 < 2) goto LAB_;
        if ((((*(uint *)((longlong)plStack_ad0 + 100) & 8) != 0) &&
            (lVar15 = plStack_ad0[0x12], lVar15 != 0)) && (*(longlong *)(lVar15 + 0x758) != 0)) {
          func_0x(*(undefined8 *)(lVar15 + 0x758),plStack_ad0,iVar9);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar38 + 100) & 8) != 0)) &&
         ((2 < iVar9 &&
          (((*(uint *)((longlong)plVar38 + 100) & 0xc0000000) != 0x40000000 && (*plVar38 != 0))))))
      {
        iVar25 = (*_DAT_)(*plVar38,0x2000,2,auStack_8b4);
        if (iVar25 != 0) {
          LOCK();
          *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar38 + 100) = *(uint *)((longlong)plVar38 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      func_0x(plVar38 + 0x13,iVar9);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        func_0x(plVar38,0,iVar9);
      }
      uStack_ac4 = uStack_ac4 & 0xffff0000;
      plStack_ad0 = (longlong *)0x0;
    }
    else {
      func_0x(&plStack_ad0);
    }
  }
  uStack_b18 = (uint *)0x0;
  uStack_8e8 = uVar4;
  uStack_8e0 = uVar40;
  func_0x(*(undefined8 *)(lVar16 + 0x728),&uStack_8e8,4);
  goto LAB_;
LAB_:
  plVar38 = plStack_a80;
  lVar16 = *plStack_ad0;
  lVar14 = *plStack_ab8;
  uVar22 = 2;
  if (1 < *(int *)(plStack_a80 + 3) + 1U) {
    uVar22 = 0;
  }
  uStack_974 = *(undefined4 *)(lVar14 + 0x20);
  uStack_970 = *(undefined2 *)(lVar14 + 0x24);
  uStack_b08 = (int *)plStack_a80[1];
  uStack_b18 = &uStack_974;
  lStack_a78 = lVar14;
  uStack_b10._0_4_ = uVar22;
  func_0x(&plStack_ad0,plStack_a80[5] + 0x3c0,0x10,6);
  uVar22 = 2;
  if (1 < *(int *)(plVar38 + 3) + 1U) {
    uVar22 = 0;
  }
  uStack_9a0 = *(uint *)(lVar16 + 0x20);
  uStack_99c = *(undefined2 *)(lVar16 + 0x24);
  uStack_b08 = (int *)plVar38[1];
  uStack_b10 = (uint *)CONCAT44(uStack_b10._4_4_,uVar22);
  uStack_b18 = &uStack_9a0;
  func_0x(&plStack_ab8,plVar38[5] + 0x3c0,8,6);
  if ((*(char *)(lVar16 + 1) == '\x01') ||
     (((*(char *)(lVar16 + 1) == '\x02' && (*(char *)(lVar16 + 3) == '\0')) &&
      (1 < *(ushort *)(lVar16 + 6))))) {
    uStack_268 = 0xffff;
    puVar44 = (undefined *)0x0;
    pbStack_260 = (byte *)0x0;
    uStack_264 = 0;
    uStack_24a = 0;
    uStack_248 = 0;
    uStack_240 = 0;
    uStack_23e = 0;
    uStack_258 = (undefined *)0x0;
    uStack_1b8 = 0xffff;
    pbStack_1b0 = (byte *)0x0;
    uStack_1b4 = 0;
    uStack_19a = 0;
    uStack_198 = 0;
    uStack_190 = 0;
    uStack_18e = 0;
    uStack_1a8 = (byte **)0x0;
    uVar12 = (uint)*(ushort *)(**(longlong **)(plVar38[5] + 0x160) + 0x1c);
    uVar21 = *(ushort *)(lVar16 + 0x16);
    iStack_234 = uVar21 - 1;
    uStack_a8c = uVar12;
    if (*(char *)(lVar16 + 2) < '\0') {
      pbVar1 = (byte *)(lVar16 + 0x60);
      sStack_208 = 0;
      sStack_206 = 0;
      sStack_204 = 0;
      uStack_1fa = 0;
      uStack_1f0 = SUB164(ZEXT816(0),0);
      uStack_1f0 = 0;
      uStack_1ec = SUB164(ZEXT816(0),4);
      uStack_1ec = 0;
      psStack_1e0 = (short *)0x0;
      sStack_1d8 = 0;
      uStack_1d6 = 0;
      auStack_230._8_8_ = 0;
      _auStack_21e = SUB1614(ZEXT816(0),2);
      auStack_220 = (undefined  [2])0xffff;
      uStack_218 = 0;
      uStack_202 = 0;
      uStack_200 = 0;
      uStack_1f8 = 0;
      uStack_1f6 = 0;
      uStack_210 = 0;
      uStack_20c = 0;
      psStack_1e8 = (short *)0x0;
      _auStack_1d0 = ZEXT812(0);
      auStack_1c6._2_4_ = 0;
      uStack_1c0 = 0;
      puVar44 = auStack_230;
      uVar4 = 0;
      if (*(short *)(lVar16 + 0x24) == 0) {
LAB_:
        auStack_230._8_8_ = uVar4;
        uStack_a20 = *(undefined8 *)(lVar16 + 0x28);
        uStack_a18 = *(undefined2 *)(lVar16 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar16 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(lVar16 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          uVar4 = auStack_230._8_8_;
          if (*(int *)(lVar16 + 0x18) != 99) goto LAB_;
        }
        uStack_988 = *(undefined4 *)(lVar16 + 0x20);
        uStack_984 = *(undefined2 *)(lVar16 + 0x24);
        auStack_230 = ZEXT816(0);
        cVar8 = func_0x(&uStack_988);
        uVar4 = auStack_230._8_8_;
        if (cVar8 == '\0') goto LAB_;
        func_0x(lVar16,&uStack_a20);
      }
      auStack_230._0_8_ = pbVar1;
      auStack_1d0._8_2_ = uStack_a18;
      auStack_1d0._0_8_ = uStack_a20;
      auStack_1c6._2_4_ = *(undefined4 *)(lVar16 + 0x20);
      uStack_a88 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1085da0);
      uVar45 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1085da4);
      auStack_220 = (undefined  [2])0xffff;
      uVar10 = 0;
      _auStack_220 = _auStack_220 & 0xffffffff;
      uStack_218 = 0;
      uStack_202 = 0;
      uStack_200 = 0;
      uStack_1f8 = 0;
      uStack_1f6 = 0;
      uStack_210 = 0;
      uStack_20c = 0;
      psStack_1e8 = (short *)0x0;
      psStack_1e0 = (short *)0x0;
      sStack_1d8 = 0;
      if ((*pbVar1 & 2) != 0) {
        pbVar43 = pbVar1 + uVar45;
        uStack_218 = pbVar43;
        auVar5 = _auStack_220;
        if ((*pbVar43 & 1) == 0) {
          auVar5._14_2_ = 0;
          auVar5._0_14_ = _auStack_21e;
          _auStack_220 = auVar5 << 0x10;
          uStack_1fa = 0;
          uStack_1f8 = 0;
          switch(*pbVar43 & 0xe) {
          default:
            uVar10 = (uint)*(ushort *)(pbVar43 + 2);
            if (0x1f9d < *(ushort *)(pbVar43 + 2) - 1) {
              func_0x(pbVar43,6);
            }
            break;
          case 4:
            uVar10 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar10 = 1;
          }
          uStack_210 = uVar10;
          uStack_202 = 0;
          uStack_200 = 0;
        }
        else {
          auStack_220 = (undefined  [2])0x1;
          auVar7 = _auStack_220;
          bVar3 = *pbVar43;
          stack0xfffffffffffffde4 = auVar5._4_12_;
          switch(bVar3 & 0x1c) {
          default:
            if ((char)pbVar43[1] < '\0') {
              sStack_208 = 3;
              auStack_21e._0_2_ =
                   (*(ushort *)(pbVar43 + 1) & 0x7f) << 8 | *(ushort *)(pbVar43 + 1) >> 8;
            }
            else {
              sStack_208 = 2;
              auStack_21e._0_2_ = ZEXT12(pbVar43[1]);
            }
            auStack_220 = (undefined  [2])0x1;
            sStack_204 = (short)((ushort)auStack_21e._0_2_ + 1 >> 1) + sStack_208;
            if ((ushort)auStack_21e._0_2_ < 0x1f) {
              sStack_206 = 0;
              uStack_1f0 = 0;
              uStack_1f8 = 0;
              uStack_1f6 = 0;
              uStack_210 = 0;
              uStack_20c = 0;
            }
            else {
              iVar9 = (ushort)auStack_21e._0_2_ - 1;
              sStack_206 = ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                           (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
              uStack_1f0 = 0;
              uStack_1f8 = 0;
              uStack_1f6 = 0;
              uStack_210 = 0;
              uStack_20c = 0;
            }
            break;
          case 4:
            _auStack_220 = auVar7._0_4_;
            if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
              uVar10 = 1;
              _auStack_220 = CONCAT44(0xf,_auStack_220);
              uVar4 = _auStack_220;
            }
            else {
              _auStack_220 = CONCAT44(1,_auStack_220);
              uVar4 = _auStack_220;
            }
            _auStack_220 = uVar4;
            uStack_1fa = 0;
            sStack_204 = 0;
            auStack_220 = SUB82(uVar4,0);
            auStack_21e._0_2_ = 0;
            sStack_208 = 0;
            sStack_206 = 0;
            uStack_1f0 = uVar10;
            uStack_1f8 = 0;
            uStack_1f6 = 0;
            uStack_210 = 0;
            uStack_20c = 0;
            break;
          case 8:
            sStack_208 = 0;
            sStack_206 = 0;
            sStack_204 = 0;
            uStack_1fa = 0;
            _auStack_220 = 0x900000001;
            uStack_1f0 = 0;
            uStack_1f8 = 0;
            uStack_1f6 = 0;
            uStack_210 = 0;
            uStack_20c = 0;
          }
        }
      }
      uStack_200 = 0;
      uStack_202 = 0;
      if ((*(byte *)auStack_230._0_8_ & 4) != 0) {
        if (uStack_a88._2_2_ != 0) {
          uVar45 = (ulonglong)*(ushort *)(lVar16 + 0x61 + (longlong)uStack_a88._2_2_ * 2);
        }
        psStack_1e8 = (short *)(pbVar1 + uVar45);
        psStack_1e0 = psStack_1e8 + 1;
        sStack_1d8 = (*psStack_1e8 + 1) * 2;
      }
      lVar14 = lStack_a78;
      if (auStack_230._8_8_ != 0) {
        func_0x(auStack_230._8_8_,auStack_230);
        lVar14 = lStack_a78;
      }
    }
    pbStack_260 = (byte *)((ulonglong)*(ushort *)(lVar16 + (0x1000 - (ulonglong)uVar21) * 2) +
                          lVar16);
    if ((*pbStack_260 & 1) == 0) {
      uStack_268 = 0;
      uStack_264 = 0;
      uStack_242 = 0;
      uStack_240 = 0;
      uVar10 = (uint)*(ushort *)(lVar16 + 0xe);
      switch(*pbStack_260 & 0xe) {
      default:
        uVar21 = *(ushort *)(pbStack_260 + 2);
        uVar10 = (uint)uVar21;
        if (0x1f9d < uVar21 - 1) {
          func_0x(pbStack_260,6);
          uVar10 = (uint)uVar21;
        }
        break;
      case 4:
        uVar10 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar10 = 1;
      }
      uStack_258 = (undefined *)CONCAT44(uStack_258._4_4_,uVar10);
      uStack_24a = (undefined2)(lVar16 + 0x2000);
      uStack_248 = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
    }
    else {
      uStack_268 = 1;
      bVar3 = *pbStack_260;
      switch(bVar3 & 0x1c) {
      default:
        if ((char)pbStack_260[1] < '\0') {
          uStack_266 = (*(ushort *)(pbStack_260 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_260 + 1) >> 8;
          uStack_250 = 3;
          sVar36 = 3;
        }
        else {
          uStack_266 = (ushort)pbStack_260[1];
          uStack_250 = 2;
          sVar36 = 2;
        }
        sStack_24c = (short)(uStack_266 + 1 >> 1) + sVar36;
        if (uStack_266 < 0x1f) {
          sStack_24e = 0;
          uStack_264 = 0;
          uStack_238 = 0;
        }
        else {
          iVar9 = uStack_266 - 1;
          sStack_24e = ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                       (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
          uStack_264 = 0;
          uStack_238 = 0;
        }
        break;
      case 4:
        if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
          uStack_250 = 0;
          sStack_24e = 0;
          sStack_24c = 0;
          uStack_24a = 0;
          uStack_266 = 0;
          uStack_248 = 0;
          uStack_242 = 0;
          uStack_264 = 0xf;
          uStack_238 = 1;
        }
        else {
          uStack_250 = 0;
          sStack_24e = 0;
          sStack_24c = 0;
          uStack_24a = 0;
          uStack_266 = 0;
          uStack_248 = 0;
          uStack_242 = 0;
          uStack_264 = 1;
          uStack_238 = 0;
        }
        break;
      case 8:
        uStack_250 = 0;
        sStack_24e = 0;
        sStack_24c = 0;
        uStack_24a = 0;
        uStack_266 = 0;
        uStack_248 = 0;
        uStack_242 = 0;
        uStack_264 = 9;
        uStack_238 = 0;
      }
      uStack_240 = (undefined2)(lVar16 + 0x2000);
      uStack_23e = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
      uStack_258 = puVar44;
    }
    ppbVar32 = (byte **)0x0;
    uStack_184 = 0;
    ppbVar29 = ppbVar32;
    if (*(char *)(lVar14 + 2) < '\0') {
      pbVar1 = (byte *)(lVar14 + 0x60);
      if ((uStack_1b8 == 0) || (ppbVar28 = uStack_1a8, uStack_1a8 == (byte **)0x0)) {
        uStack_158 = 0;
        uStack_14a = 0;
        auStack_130 = ZEXT816(0);
        auStack_180 = ZEXT816(0);
        stack0xfffffffffffffe92 = SUB1614(ZEXT816(0),2);
        auStack_170._0_2_ = 0xffff;
        uStack_168 = 0;
        uStack_152 = 0;
        uStack_150 = 0;
        uStack_148 = 0;
        uStack_160 = 0;
        auStack_140 = ZEXT816(0);
        auStack_120._0_12_ = ZEXT812(0);
        auStack_120._12_4_ = 0;
        uStack_110 = 0;
        ppbVar28 = (byte **)auStack_180;
      }
      if (*(short *)(lVar14 + 0x24) == 0) {
code_r0x001042c0:
        uStack_a30 = *(undefined8 *)(lVar14 + 0x28);
        uStack_a28 = *(undefined2 *)(lVar14 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar14 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(lVar14 + 0x18) != 99) {
code_r0x00104281:
            if (cVar8 != '\t') goto code_r0x001042c0;
            goto code_r0x00104285;
          }
        }
        else {
          if (cVar8 != '\b') goto code_r0x00104281;
code_r0x00104285:
          if (*(int *)(lVar14 + 0x18) != 99) goto code_r0x001042c0;
        }
        uStack_980 = *(undefined4 *)(lVar14 + 0x20);
        uStack_97c = *(undefined2 *)(lVar14 + 0x24);
        cVar8 = func_0x(&uStack_980);
        ppbVar29 = ppbVar32;
        if (cVar8 == '\0') goto code_r0x001042c0;
        func_0x(lVar14,&uStack_a30);
        ppbVar29 = ppbVar32;
      }
      *ppbVar28 = pbVar1;
      *(undefined4 *)(ppbVar28 + 0xc) = (undefined4)uStack_a30;
      *(int *)((longlong)ppbVar28 + 100) = (int)((ulonglong)uStack_a30 >> 0x20);
      *(undefined2 *)(ppbVar28 + 0xd) = uStack_a28;
      *(undefined4 *)((longlong)ppbVar28 + 0x6c) = *(undefined4 *)(lVar14 + 0x20);
      *(undefined2 *)(ppbVar28 + 0xe) = *(undefined2 *)(lVar14 + 0x24);
      uVar40 = SUB82(ppbVar29,0);
      *(undefined2 *)((longlong)ppbVar28 + 0x72) = uVar40;
      uStack_a88 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1085da0);
      uVar45 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1085da4);
      *(undefined2 *)(ppbVar28 + 2) = 0xffff;
      ppbVar28[3] = (byte *)ppbVar29;
      uVar10 = (uint)ppbVar29;
      *(uint *)((longlong)ppbVar28 + 0x14) = uVar10;
      *(byte ***)((longlong)ppbVar28 + 0x2e) = ppbVar29;
      ppbVar28[7] = (byte *)ppbVar29;
      ppbVar28[4] = (byte *)ppbVar29;
      ppbVar28[9] = (byte *)ppbVar29;
      ppbVar28[10] = (byte *)ppbVar29;
      *(undefined2 *)(ppbVar28 + 0xb) = uVar40;
      if ((**ppbVar28 & 2) != 0) {
        pbVar43 = pbVar1 + uVar45;
        if ((*pbVar43 & 1) == 0) {
          *(undefined2 *)(ppbVar28 + 2) = uVar40;
          ppbVar28[3] = pbVar43;
          *(uint *)((longlong)ppbVar28 + 0x14) = uVar10;
          *(uint *)((longlong)ppbVar28 + 0x36) = uVar10;
          switch(*pbVar43 & 0xe) {
          default:
            uVar10 = (uint)*(ushort *)(pbVar43 + 2);
            if (0x1f9d < *(ushort *)(pbVar43 + 2) - 1) {
              func_0x(pbVar43,6);
              ppbVar29 = (byte **)0x0;
            }
            break;
          case 4:
            uVar10 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar10 = 1;
          }
          *(uint *)(ppbVar28 + 4) = uVar10;
          *(byte ***)((longlong)ppbVar28 + 0x2e) = ppbVar29;
        }
        else {
          *(undefined2 *)(ppbVar28 + 2) = 1;
          ppbVar28[3] = pbVar43;
          bVar3 = *pbVar43;
          switch(bVar3 & 0x1c) {
          default:
            if ((char)pbVar43[1] < '\0') {
              uVar21 = *(ushort *)(pbVar43 + 1);
              *(ushort *)((longlong)ppbVar28 + 0x12) = uVar21;
              sVar36 = 3;
              uVar21 = (uVar21 & 0x7f) << 8 | uVar21 >> 8;
            }
            else {
              sVar36 = 2;
              uVar21 = (ushort)pbVar43[1];
            }
            *(ushort *)((longlong)ppbVar28 + 0x12) = uVar21;
            *(short *)(ppbVar28 + 5) = sVar36;
            *(short *)((longlong)ppbVar28 + 0x2c) =
                 (short)(*(ushort *)((longlong)ppbVar28 + 0x12) + 1 >> 1) + sVar36;
            if (*(ushort *)((longlong)ppbVar28 + 0x12) < 0x1f) {
              *(undefined2 *)((longlong)ppbVar28 + 0x2a) = uVar40;
              *(uint *)((longlong)ppbVar28 + 0x14) = uVar10;
              *(uint *)(ppbVar28 + 8) = uVar10;
              ppbVar28[7] = (byte *)ppbVar29;
              ppbVar28[4] = (byte *)ppbVar29;
            }
            else {
              iVar9 = *(ushort *)((longlong)ppbVar28 + 0x12) - 1;
              *(short *)((longlong)ppbVar28 + 0x2a) =
                   ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                   (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
              *(uint *)((longlong)ppbVar28 + 0x14) = uVar10;
              *(uint *)(ppbVar28 + 8) = uVar10;
              ppbVar28[7] = (byte *)ppbVar29;
              ppbVar28[4] = (byte *)ppbVar29;
            }
            break;
          case 4:
            if (((bVar3 & 0x1c) != 4) || (uVar13 = 1, (bVar3 & 2) == 0)) {
              uVar13 = uVar10;
            }
            *(uint *)((longlong)ppbVar28 + 0x14) = uVar10;
            ppbVar28[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar28 + 0x12) = uVar40;
            ppbVar28[6] = (byte *)0x0;
            ppbVar28[4] = (byte *)ppbVar29;
            *(uint *)(ppbVar28 + 8) = uVar10;
            ppbVar28[7] = (byte *)ppbVar29;
            ppbVar28[3] = pbVar43;
            if (uVar13 == 0) {
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 1;
              *(uint *)(ppbVar28 + 8) = uVar10;
              ppbVar28[7] = (byte *)ppbVar29;
              ppbVar28[4] = (byte *)ppbVar29;
            }
            else {
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0xf;
              *(uint *)(ppbVar28 + 8) = uVar10;
              *(undefined4 *)(ppbVar28 + 8) = 1;
              ppbVar28[7] = (byte *)ppbVar29;
              ppbVar28[4] = (byte *)ppbVar29;
            }
            break;
          case 8:
            ppbVar28[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar28 + 0x12) = uVar40;
            ppbVar28[6] = (byte *)0x0;
            ppbVar28[4] = (byte *)ppbVar29;
            ppbVar28[7] = (byte *)ppbVar29;
            ppbVar28[3] = pbVar43;
            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 9;
            *(uint *)(ppbVar28 + 8) = uVar10;
            ppbVar28[7] = (byte *)ppbVar29;
            ppbVar28[4] = (byte *)ppbVar29;
          }
        }
      }
      if ((**ppbVar28 & 4) != 0) {
        if (uStack_a88._2_2_ != 0) {
          uVar45 = (ulonglong)*(ushort *)(lVar14 + 0x61 + (longlong)uStack_a88._2_2_ * 2);
        }
        psVar18 = (short *)(pbVar1 + uVar45);
        ppbVar28[9] = (byte *)psVar18;
        sVar36 = *psVar18;
        ppbVar28[10] = (byte *)(psVar18 + 1);
        *(short *)(ppbVar28 + 0xb) = (sVar36 + 1) * 2;
      }
      ppbVar32 = ppbVar28;
      lVar14 = lStack_a78;
      if (ppbVar28[1] != (byte *)0x0) {
        func_0x(ppbVar28[1],ppbVar28);
        ppbVar29 = (byte **)0x0;
        lVar14 = lStack_a78;
      }
    }
    uVar10 = (uint)*(ushort *)(lVar14 + 0xe);
    pbStack_1b0 = (byte *)((ulonglong)*(ushort *)(lVar14 + 0x1ffe) + lVar14);
    uVar21 = (ushort)ppbVar29;
    uStack_1b4 = SUB84(ppbVar29,0);
    if ((*pbStack_1b0 & 1) == 0) {
      uStack_190 = (undefined2)((ulonglong)ppbVar29 >> 0x10);
      uStack_1b8 = uVar21;
      uStack_192 = uVar21;
      switch(*pbStack_1b0 & 0xe) {
      default:
        uVar10 = (uint)*(ushort *)(pbStack_1b0 + 2);
        if (0x1f9d < *(ushort *)(pbStack_1b0 + 2) - 1) {
          func_0x(pbStack_1b0,6);
        }
        break;
      case 4:
        uVar10 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar10 = 1;
      }
      uStack_1a8 = (byte **)CONCAT44(uStack_1a8._4_4_,uVar10);
      uStack_19a = (undefined2)(lVar14 + 0x2000);
      uStack_198 = (undefined6)((ulonglong)(lVar14 + 0x2000) >> 0x10);
    }
    else {
      uStack_1b8 = 1;
      bVar3 = *pbStack_1b0;
      uStack_1b6 = uVar21;
      uStack_188 = uStack_1b4;
      switch(bVar3 & 0x1c) {
      default:
        if ((char)pbStack_1b0[1] < '\0') {
          uStack_1b6 = (*(ushort *)(pbStack_1b0 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_1b0 + 1) >> 8;
          uStack_1a0 = 3;
          uStack_a64 = CONCAT22(uStack_a64._2_2_,3);
        }
        else {
          uStack_1b6 = (ushort)pbStack_1b0[1];
          uStack_1a0 = 2;
        }
        sStack_19c = (short)(uStack_1b6 + 1 >> 1) + (short)uStack_a64;
        uStack_19e = uVar21;
        if (0x1e < uStack_1b6) {
          iVar9 = uStack_1b6 - 1;
          uStack_19e = ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                       (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
        }
        break;
      case 4:
        if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
          uStack_1a0 = 0;
          uStack_19e = 0;
          sStack_19c = 0;
          uStack_19a = 0;
          uStack_198 = 0;
          uStack_192 = 0;
          uStack_1b4 = 0xf;
          uStack_188 = 1;
        }
        else {
          uStack_1a0 = 0;
          uStack_19e = 0;
          sStack_19c = 0;
          uStack_19a = 0;
          uStack_198 = 0;
          uStack_192 = 0;
          uStack_1b4 = 1;
        }
        break;
      case 8:
        uStack_1a0 = 0;
        uStack_19e = 0;
        sStack_19c = 0;
        uStack_19a = 0;
        uStack_198 = 0;
        uStack_192 = 0;
        uStack_1b4 = 9;
      }
      uStack_190 = (undefined2)(lVar14 + 0x2000);
      uStack_18e = (undefined6)((ulonglong)(lVar14 + 0x2000) >> 0x10);
      uStack_1a8 = ppbVar32;
    }
    plVar38 = plStack_a80;
    lVar16 = plStack_a80[0x10];
    if (lVar16 == 0) {
      func_0x(plStack_a80[0x19],uVar12,plStack_a80 + 0x10);
      if ((*(byte *)(plVar38[5] + 0x42) & 4) == 0) {
        uVar12 = *(uint *)(plVar38[5] + 0xb4);
        if (0xa58 < uVar12) {
          uVar12 = 0xa58;
        }
      }
      else {
        uVar12 = 0xa58;
      }
      *(uint *)((longlong)plVar38 + 0x94) = uVar12;
      uStack_b18 = (uint *)CONCAT71(uStack_b18._1_7_,5);
      lVar14 = (*pcRam0000000000f07088)(uVar12,plVar38[0x19],0x12c5770,0x121b);
      plVar38[0x11] = lVar14;
      lVar16 = plVar38[0x10];
    }
    else {
      lVar14 = plStack_a80[0x11];
    }
    uVar22 = *(undefined4 *)((longlong)plVar38 + 0x94);
    uVar45 = 0;
    uStack_9d4 = 0;
    uVar12 = *(uint *)(**(longlong **)(plVar38[5] + 0x160) + 0x1c);
    iVar9 = *(int *)(plVar38[5] + 0x100);
    if ((iVar9 == 0) || (iVar9 - 3U < 2)) {
      uVar46 = 0;
    }
    else {
      uVar46 = 1;
    }
    uStack_aa0 = 0;
    *(undefined8 *)(lVar16 + 0x10) = 0;
    *(undefined4 *)(lVar16 + 8) = 0;
    uVar33 = uVar45;
    plVar37 = plVar38 + 4;
    plVar38 = plVar38 + 4;
    if (uVar12 != 0) {
      do {
        if (uVar45 == 0) {
          uVar23 = *(ulonglong *)(**(longlong **)(plVar37[1] + 0x160) + 0x38);
        }
        else {
          uVar23 = *(ulonglong *)(uVar45 + 0x168);
        }
        if (uVar23 == **(longlong **)(plVar37[1] + 0x160) + 0x30U) {
          uVar23 = 0;
        }
        uVar45 = 0;
        if (uVar23 != 0) {
          uVar45 = uVar23 - 0x160;
        }
        puStack_ae0 = &uStack_9d4;
        uStack_af8 = 0;
        uStack_b00 = uStack_b00 & 0xffffff00;
        uStack_b08 = (int *)CONCAT71(uStack_b08._1_7_,uVar46);
        uStack_b10 = (uint *)((ulonglong)uStack_b10 & 0xffffffff00000000);
        uStack_b18 = (uint *)&uStack_aa0;
        uStack_af0 = uVar22;
        lStack_ae8 = lVar14;
        func_0x(lVar16,uVar33,&uStack_268,uVar45);
        uVar10 = (int)uVar33 + 1;
        uVar33 = (ulonglong)uVar10;
        plVar37 = plStack_918;
        plVar38 = plStack_918;
      } while (uVar10 < uVar12);
    }
    uVar30 = 0;
    uVar45 = uVar30;
    uVar33 = uVar30;
    uVar23 = uVar30;
    if (uStack_a8c != 0) {
      do {
        uVar39 = **(longlong **)(plVar38[1] + 0x160) + 0x30;
        uVar35 = *(ulonglong *)(**(longlong **)(plVar38[1] + 0x160) + 0x38);
        if (uVar35 == uVar39) {
          uVar35 = uVar30;
        }
        uVar26 = uVar30;
        if (uVar35 != 0) {
          uVar26 = uVar35 - 0x160;
        }
        uVar35 = uVar45;
        if ((int)uVar23 != 0) {
          do {
            uVar24 = *(ulonglong *)(uVar26 + 0x168);
            if (*(ulonglong *)(uVar26 + 0x168) == uVar39) {
              uVar24 = uVar30;
            }
            uVar26 = uVar30;
            if (uVar24 != 0) {
              uVar26 = uVar24 - 0x160;
            }
            uVar35 = uVar35 - 1;
          } while (uVar35 != 0);
        }
        uVar46 = 0x83;
        if (-1 < *(char *)(uVar26 + 0x20)) {
          uVar46 = 0x85;
        }
        *(undefined *)(*(longlong *)plStack_a80[0x10] + 0xe + uVar33) = uVar46;
        uVar12 = (int)uVar23 + 1;
        plVar38 = plStack_a80 + 4;
        uVar45 = uVar45 + 1;
        uVar33 = uVar33 + 0x10;
        uVar23 = (ulonglong)uVar12;
      } while (uVar12 < uStack_a8c);
    }
    uStack_b18 = (uint *)((ulonglong)uStack_b18 & 0xffffffff00000000);
    iVar9 = func_0x(&uStack_1b8,plStack_a80[0x10],uStack_a8c,plStack_a80 + 4);
    if (iVar9 == 0) {
      uStack_b18 = (uint *)0x0;
      (*pcRam0000000000f070b0)(1,0x1444140,0x140e300,0x1240);
    }
    func_0x(&plStack_ab8);
    func_0x(&plStack_ad0);
    goto LAB_;
  }
  uVar21 = *(ushort *)(lVar16 + 0x16);
  iStack_2e4 = uVar21 - 1;
  if (*(char *)(lVar16 + 2) < '\0') {
    pbVar1 = (byte *)(lVar16 + 0x60);
    if ((uStack_318 == 0) || (ppbVar32 = uStack_308, uStack_308 == (byte **)0x0)) {
      uStack_2b8 = 0;
      uStack_2aa = 0;
      auStack_290 = ZEXT816(0);
      auStack_2e0 = ZEXT816(0);
      stack0xfffffffffffffd32 = SUB1614(ZEXT816(0),2);
      auStack_2d0._0_2_ = 0xffff;
      uStack_2c8 = 0;
      uStack_2b2 = 0;
      uStack_2b0 = 0;
      uStack_2a8 = 0;
      uStack_2c0 = 0;
      auStack_2a0 = ZEXT816(0);
      auStack_280._0_12_ = ZEXT812(0);
      auStack_280._12_4_ = 0;
      uStack_270 = 0;
      ppbVar32 = (byte **)auStack_2e0;
    }
    pbVar43 = (byte *)0x0;
    if (*(short *)(lVar16 + 0x24) == 0) {
LAB_:
      uStack_a00 = *(undefined8 *)(lVar16 + 0x28);
      uStack_9f8 = *(undefined2 *)(lVar16 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar16 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar16 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar16 + 0x18) != 99) goto LAB_;
      }
      uStack_998 = *(undefined4 *)(lVar16 + 0x20);
      uStack_994 = *(undefined2 *)(lVar16 + 0x24);
      cVar8 = func_0x(&uStack_998);
      if (cVar8 == '\0') goto LAB_;
      func_0x(lVar16,&uStack_a00);
    }
    *ppbVar32 = pbVar1;
    *(undefined4 *)(ppbVar32 + 0xc) = (undefined4)uStack_a00;
    *(int *)((longlong)ppbVar32 + 100) = (int)((ulonglong)uStack_a00 >> 0x20);
    *(undefined2 *)(ppbVar32 + 0xd) = uStack_9f8;
    *(undefined4 *)((longlong)ppbVar32 + 0x6c) = *(undefined4 *)(lVar16 + 0x20);
    *(undefined2 *)(ppbVar32 + 0xe) = *(undefined2 *)(lVar16 + 0x24);
    uVar40 = SUB82(pbVar43,0);
    *(undefined2 *)((longlong)ppbVar32 + 0x72) = uVar40;
    uStack_910 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1085da0);
    uVar45 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1085da4);
    *(undefined2 *)(ppbVar32 + 2) = 0xffff;
    ppbVar32[3] = pbVar43;
    uVar12 = (uint)pbVar43;
    *(uint *)((longlong)ppbVar32 + 0x14) = uVar12;
    *(byte **)((longlong)ppbVar32 + 0x2e) = pbVar43;
    ppbVar32[7] = pbVar43;
    ppbVar32[4] = pbVar43;
    ppbVar32[9] = pbVar43;
    ppbVar32[10] = pbVar43;
    *(undefined2 *)(ppbVar32 + 0xb) = uVar40;
    if ((**ppbVar32 & 2) != 0) {
      pbVar2 = pbVar1 + uVar45;
      if ((*pbVar2 & 1) == 0) {
        *(undefined2 *)(ppbVar32 + 2) = uVar40;
        ppbVar32[3] = pbVar2;
        *(uint *)((longlong)ppbVar32 + 0x14) = uVar12;
        *(uint *)((longlong)ppbVar32 + 0x36) = uVar12;
        switch(*pbVar2 & 0xe) {
        default:
          uVar12 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            func_0x(pbVar2,6);
            pbVar43 = (byte *)0x0;
          }
          break;
        case 4:
          uVar12 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar12 = 1;
        }
        *(uint *)(ppbVar32 + 4) = uVar12;
        *(byte **)((longlong)ppbVar32 + 0x2e) = pbVar43;
      }
      else {
        *(undefined2 *)(ppbVar32 + 2) = 1;
        ppbVar32[3] = pbVar2;
        bVar3 = *pbVar2;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar20 = *(ushort *)(pbVar2 + 1);
            *(ushort *)((longlong)ppbVar32 + 0x12) = uVar20;
            sVar36 = 3;
            uVar20 = (uVar20 & 0x7f) << 8 | uVar20 >> 8;
          }
          else {
            sVar36 = 2;
            uVar20 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar32 + 0x12) = uVar20;
          *(short *)(ppbVar32 + 5) = sVar36;
          *(short *)((longlong)ppbVar32 + 0x2c) =
               (short)(*(ushort *)((longlong)ppbVar32 + 0x12) + 1 >> 1) + sVar36;
          if (*(ushort *)((longlong)ppbVar32 + 0x12) < 0x1f) {
            *(undefined2 *)((longlong)ppbVar32 + 0x2a) = uVar40;
            *(uint *)((longlong)ppbVar32 + 0x14) = uVar12;
            *(uint *)(ppbVar32 + 8) = uVar12;
            ppbVar32[7] = pbVar43;
            ppbVar32[4] = pbVar43;
          }
          else {
            iVar9 = *(ushort *)((longlong)ppbVar32 + 0x12) - 1;
            *(short *)((longlong)ppbVar32 + 0x2a) =
                 ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                 (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
            *(uint *)((longlong)ppbVar32 + 0x14) = uVar12;
            *(uint *)(ppbVar32 + 8) = uVar12;
            ppbVar32[7] = pbVar43;
            ppbVar32[4] = pbVar43;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) != 4) || (uVar10 = 1, (bVar3 & 2) == 0)) {
            uVar10 = uVar12;
          }
          *(uint *)((longlong)ppbVar32 + 0x14) = uVar12;
          ppbVar32[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar32 + 0x12) = uVar40;
          ppbVar32[6] = (byte *)0x0;
          ppbVar32[4] = pbVar43;
          *(uint *)(ppbVar32 + 8) = uVar12;
          ppbVar32[7] = pbVar43;
          ppbVar32[3] = pbVar2;
          if (uVar10 == 0) {
            *(undefined4 *)((longlong)ppbVar32 + 0x14) = 1;
            *(uint *)(ppbVar32 + 8) = uVar12;
            ppbVar32[7] = pbVar43;
            ppbVar32[4] = pbVar43;
          }
          else {
            *(undefined4 *)((longlong)ppbVar32 + 0x14) = 0xf;
            *(uint *)(ppbVar32 + 8) = uVar12;
            *(undefined4 *)(ppbVar32 + 8) = 1;
            ppbVar32[7] = pbVar43;
            ppbVar32[4] = pbVar43;
          }
          break;
        case 8:
          ppbVar32[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar32 + 0x12) = uVar40;
          ppbVar32[6] = (byte *)0x0;
          ppbVar32[4] = pbVar43;
          ppbVar32[7] = pbVar43;
          ppbVar32[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar32 + 0x14) = 9;
          *(uint *)(ppbVar32 + 8) = uVar12;
          ppbVar32[7] = pbVar43;
          ppbVar32[4] = pbVar43;
        }
      }
    }
    uVar12 = (uint)pbVar43;
    if ((**ppbVar32 & 4) != 0) {
      if (uStack_910._2_2_ != 0) {
        uVar45 = (ulonglong)*(ushort *)(lVar16 + 0x61 + (longlong)uStack_910._2_2_ * 2);
      }
      psVar18 = (short *)(pbVar1 + uVar45);
      ppbVar32[9] = (byte *)psVar18;
      sVar36 = *psVar18;
      ppbVar32[10] = (byte *)(psVar18 + 1);
      *(short *)(ppbVar32 + 0xb) = (sVar36 + 1) * 2;
    }
    lVar14 = lStack_a78;
    if (ppbVar32[1] != (byte *)0x0) {
      func_0x(ppbVar32[1],ppbVar32);
      uVar12 = 0;
      lVar14 = lStack_a78;
    }
  }
  else {
    ppbVar32 = (byte **)0x0;
    uVar12 = 0;
  }
  ppbVar29 = (byte **)(ulonglong)*(ushort *)(lVar16 + 0xe);
  piStack_310 = (int *)((ulonglong)*(ushort *)(lVar16 + (0x1000 - (ulonglong)uVar21) * 2) + lVar16);
  uVar21 = (ushort)uVar12;
  uStack_314 = uVar12;
  if ((*(byte *)piStack_310 & 1) == 0) {
    uStack_2f0 = (undefined2)(uVar12 >> 0x10);
    uStack_318 = uVar21;
    uStack_2f2 = uVar21;
    switch(*(byte *)piStack_310 & 0xe) {
    default:
      ppbVar29 = (byte **)(ulonglong)*(ushort *)((longlong)piStack_310 + 2);
      if (0x1f9d < *(ushort *)((longlong)piStack_310 + 2) - 1) {
        func_0x(piStack_310,6);
        uVar12 = 0;
      }
      break;
    case 4:
      ppbVar29 = (byte **)0x9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      ppbVar29 = (byte **)0x1;
    }
    uStack_308 = (byte **)CONCAT44(uStack_308._4_4_,(int)ppbVar29);
    uStack_2fa = (undefined2)(lVar16 + 0x2000);
    uStack_2f8 = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
    ppbVar32 = ppbVar29;
  }
  else {
    uStack_318 = 1;
    bVar3 = *(byte *)piStack_310;
    uStack_316 = uVar21;
    uStack_2e8 = uVar12;
    switch(bVar3 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)piStack_310 + 1) < '\0') {
        uStack_316 = (*(ushort *)((longlong)piStack_310 + 1) & 0x7f) << 8 |
                     *(ushort *)((longlong)piStack_310 + 1) >> 8;
        sVar36 = 3;
        uStack_300._0_2_ = 3;
      }
      else {
        uStack_316 = (ushort)*(byte *)((longlong)piStack_310 + 1);
        sVar36 = 2;
        uStack_300._0_2_ = 2;
      }
      uStack_2fc = (short)(uStack_316 + 1 >> 1) + sVar36;
      uStack_300._2_2_ = uVar21;
      if (0x1e < uStack_316) {
        iVar9 = uStack_316 - 1;
        uStack_300._2_2_ =
             ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
             (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
        uStack_300._0_2_ = 0;
        uStack_300._2_2_ = 0;
        uStack_2fc = 0;
        uStack_2fa = 0;
        uStack_2f8 = 0;
        uStack_2f2 = 0;
        uStack_314 = 0xf;
        uStack_2e8 = 1;
      }
      else {
        uStack_300._0_2_ = 0;
        uStack_300._2_2_ = 0;
        uStack_2fc = 0;
        uStack_2fa = 0;
        uStack_2f8 = 0;
        uStack_2f2 = 0;
        uStack_314 = 1;
      }
      break;
    case 8:
      uStack_300._0_2_ = 0;
      uStack_300._2_2_ = 0;
      uStack_2fc = 0;
      uStack_2fa = 0;
      uStack_2f8 = 0;
      uStack_2f2 = 0;
      uStack_314 = 9;
    }
    lVar16 = lVar16 + 0x2000;
    uStack_2f0 = (undefined2)lVar16;
    uStack_2ee = (undefined2)((ulonglong)lVar16 >> 0x10);
    uStack_2ec = (ushort)((ulonglong)lVar16 >> 0x20);
    uStack_2ea = (undefined2)((ulonglong)lVar16 >> 0x30);
    ppbVar29 = (byte **)((ulonglong)ppbVar32 & 0xffffffff);
    uStack_308 = ppbVar32;
  }
  lVar16 = lStack_8b0;
  uVar10 = (uint)ppbVar29;
  puVar17 = (uint *)(lStack_8b0 + 0x210);
  if (uStack_318 == 0) {
    uVar12 = *puVar17;
    if ((uVar12 & 0xc0000000) == 0x80000000) {
      iVar9 = func_0x(&uStack_316);
      if (iVar9 == 0) {
code_r0x001028b0:
        piVar27 = (int *)0x0;
        iVar9 = 0;
      }
      else {
        piVar27 = (int *)func_0x(&uStack_2ee,puVar17,aiStack_ad8,auStack_8c4);
        iVar9 = aiStack_ad8[0];
      }
    }
    else {
      uVar21 = *(ushort *)(lStack_8b0 + 0x216);
      if ((uVar21 & 0x10) == 0) {
code_r0x00101fba:
        if ((int)uVar12 < 0) {
          piVar27 = piStack_310;
          if (uStack_314 == 0) {
            uStack_316 = 0;
            uVar12 = uVar10;
            if ((*(byte *)piStack_310 & 0x10) != 0) {
              uVar12 = uVar10 + 2 +
                       (*(ushort *)((longlong)ppbVar29 + (longlong)piStack_310) + 7 >> 3);
            }
            uStack_308 = (byte **)CONCAT44(uVar12,(uint)uStack_308);
            if ((*(byte *)piStack_310 & 0x20) != 0) {
              puVar31 = (ushort *)((ulonglong)uVar12 + (longlong)piStack_310);
              uStack_2fc = *puVar31;
              if (uStack_2fc == 0) {
                if ((((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
                    (lVar42 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar42 != 0)) &&
                   ((lVar42 = *(longlong *)(lVar42 + 0x60), lVar42 != 0 &&
                    (*(char *)(lVar42 + 0x499) != '\0')))) {
                  if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
                    (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_b18 = (uint *)0x0;
                    (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x80f);
                  }
                }
                func_0x(piStack_310,3);
              }
              uStack_300 = uStack_308._4_4_ + (uStack_2fc + 1) * 2;
              if (0x1f9e < uStack_300) {
                if (((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
                   ((lVar42 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar42 != 0 &&
                    ((lVar42 = *(longlong *)(lVar42 + 0x60), lVar42 != 0 &&
                     (*(char *)(lVar42 + 0x499) != '\0')))))) {
                  if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
                    (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_b18 = (uint *)0x0;
                    (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x816);
                  }
                }
                func_0x(piStack_310,4);
              }
              uStack_314 = puVar31[uStack_2fc] & 0x7fff;
              piVar27 = piStack_310;
              uVar12 = uStack_314;
              if (uStack_314 < uStack_300) {
                if ((((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
                    (lVar42 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar42 != 0)) &&
                   ((lVar42 = *(longlong *)(lVar42 + 0x60), lVar42 != 0 &&
                    (*(char *)(lVar42 + 0x499) != '\0')))) {
                  if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
                    (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_b18 = (uint *)0x0;
                    (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x81d);
                  }
                }
                func_0x(piStack_310,4);
                piVar27 = piStack_310;
                uVar12 = uStack_314;
              }
              while ((short)puVar31[(ulonglong)(uStack_2fc - 1) + 1] < 0) {
                uVar10 = uStack_300;
                if (((uStack_2fc != 1) &&
                    (uVar10 = *(ushort *)
                               ((longlong)piVar27 +
                               (ulonglong)uStack_2fc * 2 + (((ulonglong)uStack_308 >> 0x20) - 2)) &
                              0x7fff, uVar10 < uStack_300)) ||
                   ((*(ushort *)
                      ((longlong)piVar27 +
                      (ulonglong)uStack_2fc * 2 + ((ulonglong)uStack_308 >> 0x20)) & 0x7fff) <
                    uVar10)) {
                  func_0x(piVar27,7);
                  piVar27 = piStack_310;
                  uVar12 = uStack_314;
                }
                if ((uVar10 < uStack_300) || (uVar12 < uVar10)) goto code_r0x00102707;
                if (*(ushort *)((ulonglong)uVar10 + (longlong)piVar27) == 5) {
                  uStack_316 = uStack_316 | 2;
                  uStack_2fc = uStack_2fc - 1;
                  uStack_2ee = (undefined2)uVar10;
                  uVar21 = *(ushort *)((ulonglong)(uVar10 & 0xffff) + 2 + (longlong)piVar27);
                  if ((uVar21 & 0x4000) == 0) {
                    uStack_2ec = uStack_2ec & 0xc7ff;
                  }
                  else {
                    uStack_2ec = uStack_2ec ^ (uVar21 ^ uStack_2ec) & 0x3800;
                  }
                  uStack_2ec = uStack_2ec ^
                               (uStack_2ec ^
                               *(ushort *)((ulonglong)(uVar10 & 0xffff) + 2 + (longlong)piVar27)) &
                               0x7ff;
                  uVar10 = (uint)uStack_308;
                  goto code_r0x001024b9;
                }
                if (*(ushort *)((ulonglong)uVar10 + (longlong)piVar27) < 0x400) break;
                uStack_316 = uStack_316 | 1;
                uStack_2fc = uStack_2fc - 1;
                if (uStack_2fc == 0) break;
              }
              uVar10 = (uint)uStack_308;
              goto code_r0x001024b9;
            }
            uStack_2fc = 0;
            uStack_314 = uVar12;
            uStack_300 = uVar12;
code_r0x001024b9:
            if ((*(byte *)piVar27 & 0x40) == 0) {
              uStack_2f2 = 0;
              uStack_2f0 = 0;
            }
            else {
              uStack_2f2 = (ushort)uVar12;
              uStack_2f0 = (undefined2)(uVar12 >> 0x10);
              uStack_314 = uVar12 + 0xe;
              puVar19 = (ulonglong *)func_0x(&uStack_316);
              uVar45 = *puVar19;
              iVar9 = 0;
              uVar20 = (ushort)(uVar45 >> 0x30);
              uVar21 = uVar20;
              if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
                uVar21 = uVar20 & 0xdfff;
                if ((uVar45 & 0x4000000000000000) != 0) {
                  uVar21 = uVar20 | 0x2000;
                }
              }
              if (uVar21 == 0xfffc) {
                iVar9 = (int)((uVar45 >> 0x20 & 0xffff) >> 5);
              }
              uVar12 = uStack_314 + iVar9;
              piVar27 = piStack_310;
              uVar10 = (uint)uStack_308;
              uStack_314 = uVar12;
            }
            if (((byte *)CONCAT62(uStack_2f8,uStack_2fa) != (byte *)0x0) &&
               ((byte *)CONCAT62(uStack_2f8,uStack_2fa) <
                (byte *)((ulonglong)uVar12 + (longlong)piVar27))) {
              if (((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
                 (((lVar42 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                   piVar27 = piStack_310, lVar42 != 0 &&
                   (lVar42 = *(longlong *)(lVar42 + 0x60), lVar42 != 0)) &&
                  (*(char *)(lVar42 + 0x499) != '\0')))) {
                if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
                  (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3fa);
                  piVar27 = piStack_310;
                }
                else {
                  uStack_b18 = (uint *)0x0;
                  (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x877);
                  piVar27 = piStack_310;
                }
              }
              func_0x(piVar27,0x12);
              piVar27 = piStack_310;
              uVar12 = uStack_314;
              uVar10 = (uint)uStack_308;
            }
            if (uVar12 - 1 < 0x3f3c) goto code_r0x0010270d;
            if (((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
               ((lVar42 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), piVar27 = piStack_310, lVar42 != 0 &&
                ((lVar42 = *(longlong *)(lVar42 + 0x60), lVar42 != 0 &&
                 (*(char *)(lVar42 + 0x499) != '\0')))))) {
              if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
                (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3ed);
                piVar27 = piStack_310;
              }
              else {
                uStack_b18 = (uint *)0x0;
                (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x87c);
                piVar27 = piStack_310;
              }
            }
            func_0x(piVar27,5);
            piVar27 = piStack_310;
code_r0x00102707:
            uVar10 = (uint)uStack_308;
          }
code_r0x0010270d:
          sVar36 = -*(short *)puVar17;
          if ((*(byte *)(lVar16 + 0x216) & 0x10) != 0) {
            if ((*(byte *)piVar27 & 0x10) == 0) {
              if ((1 << (*(byte *)piVar27 & 0xe) & 0x1105U) != 0) {
code_r0x00102774:
                piVar27 = *(int **)(lVar16 + 0x218) + 1;
                iVar9 = **(int **)(lVar16 + 0x218);
                goto code_r0x001028b8;
              }
            }
            else if (((int)uVar10 <= (int)*puVar17) ||
                    (*(ushort *)((ulonglong)uVar10 + (longlong)piVar27) <
                     *(ushort *)(lVar16 + 0x214))) goto code_r0x00102774;
          }
          iVar9 = 0;
          if ((uint)(int)sVar36 <= (uint)uStack_2fc) {
            piVar34 = piVar27;
            uVar12 = uStack_300;
            if (sVar36 != 1) {
              piVar34 = piStack_310;
              uVar12 = *(ushort *)
                        ((longlong)piVar27 +
                        (longlong)sVar36 * 2 + (((ulonglong)uStack_308 >> 0x20) - 2)) & 0x7fff;
            }
            uVar10 = *(ushort *)
                      ((longlong)piVar27 + (longlong)sVar36 * 2 + ((ulonglong)uStack_308 >> 0x20)) &
                     0x7fff;
            if ((uVar12 < uStack_300) || (uVar10 < uVar12)) {
              func_0x(piVar34,7);
              piVar34 = piStack_310;
            }
            piVar27 = (int *)((ulonglong)uVar12 + (longlong)piVar34);
            iVar9 = uVar10 - uVar12;
          }
        }
        else if ((uVar21 & 8) == 0) {
          if ((uVar21 & 0x10) != 0) {
            if ((*(byte *)piStack_310 & 0x10) == 0) {
              if ((1 << (*(byte *)piStack_310 & 0xe) & 0x1105U) != 0) goto code_r0x00102013;
            }
            else if (((int)uVar10 <= (int)uVar12) ||
                    (*(ushort *)((longlong)ppbVar29 + (longlong)piStack_310) <
                     *(ushort *)(lStack_8b0 + 0x214))) {
code_r0x00102013:
              piVar27 = *(int **)(lStack_8b0 + 0x218) + 1;
              iVar9 = **(int **)(lStack_8b0 + 0x218);
              if (iVar9 != 6) {
                uStack_b18 = (uint *)0x0;
                (*pcRam0000000000f070b0)(1,0x1437028,0x1435a28,0x381);
              }
              goto code_r0x001028b8;
            }
          }
          aiStack_ad8[0] = 6;
          piVar27 = (int *)((longlong)(int)*puVar17 + (longlong)piStack_310);
          iVar9 = aiStack_ad8[0];
        }
        else {
          aiStack_ad8[0] = 1;
          piVar27 = (int *)0x100dcf4;
          iVar9 = aiStack_ad8[0];
          if ((*(byte *)((longlong)(int)uVar12 + (longlong)piStack_310) &
              (byte)(1 << ((byte)uVar21 & 7))) == 0) {
            piVar27 = (int *)0x100e318;
          }
        }
      }
      else if ((*(byte *)piStack_310 & 0x10) == 0) {
        if ((1 << (*(byte *)piStack_310 & 0xe) & 0x1105U) == 0) goto code_r0x00101fba;
        piVar27 = *(int **)(lStack_8b0 + 0x218) + 1;
        iVar9 = **(int **)(lStack_8b0 + 0x218);
      }
      else {
        if (((int)uVar12 < (int)ppbVar32) &&
           (*(ushort *)(lStack_8b0 + 0x214) <=
            *(ushort *)((longlong)ppbVar29 + (longlong)piStack_310))) goto code_r0x00101fba;
        piVar27 = *(int **)(lStack_8b0 + 0x218) + 1;
        iVar9 = **(int **)(lStack_8b0 + 0x218);
      }
    }
  }
  else {
    uStack_b18 = &uStack_a68;
    uStack_a68 = uVar12;
    piVar27 = (int *)func_0x(&uStack_316,puVar17,piStack_310,aiStack_ad8);
    iVar9 = aiStack_ad8[0];
    if ((((uStack_318 != 0) && (uStack_308 != (byte **)0x0)) && (*uStack_308 != (byte *)0x0)) &&
       (((*(byte *)(lVar16 + 0x216) & 8) == 0 && ((uStack_a68 & 1) == 0)))) {
      if ((piVar27 == (int *)0x0) || (piVar27 == (int *)0x100dcf4)) goto code_r0x001028b0;
      uStack_b00 = uStack_a68;
      uStack_b08 = aiStack_ad8;
      uStack_b10 = (uint *)CONCAT44(uStack_b10._4_4_,6);
      uStack_b18 = auStack_108;
      piVar27 = (int *)func_0x(uStack_308,puVar17,piVar27,aiStack_ad8[0]);
      iVar9 = aiStack_ad8[0];
    }
  }
code_r0x001028b8:
  aiStack_ad8[0] = iVar9;
  iStack_a9c = *piVar27;
  sStack_a98 = *(short *)(piVar27 + 1);
  ppbVar32 = (byte **)0x0;
  uVar12 = 0;
  iStack_2e4 = 0;
  if (*(char *)(lVar14 + 2) < '\0') {
    pbVar1 = (byte *)(lVar14 + 0x60);
    if ((uStack_318 == 0) || (ppbVar29 = uStack_308, uStack_308 == (byte **)0x0)) {
      uStack_2b8 = 0;
      uStack_2aa = 0;
      auStack_290 = ZEXT816(0);
      auStack_2e0 = ZEXT816(0);
      stack0xfffffffffffffd32 = SUB1614(ZEXT816(0),2);
      auStack_2d0._0_2_ = 0xffff;
      uStack_2c8 = 0;
      uStack_2b2 = 0;
      uStack_2b0 = 0;
      uStack_2a8 = 0;
      uStack_2c0 = 0;
      auStack_2a0 = ZEXT816(0);
      auStack_280._0_12_ = ZEXT812(0);
      auStack_280._12_4_ = 0;
      uStack_270 = 0;
      ppbVar29 = (byte **)auStack_2e0;
    }
    if (*(short *)(lVar14 + 0x24) == 0) {
code_r0x001029f6:
      uStack_a10 = *(undefined8 *)(lVar14 + 0x28);
      uStack_a08 = *(undefined2 *)(lVar14 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar14 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar14 + 0x18) != 99) {
code_r0x001029b7:
          if (cVar8 != '\t') goto code_r0x001029f6;
          goto code_r0x001029bb;
        }
      }
      else {
        if (cVar8 != '\b') goto code_r0x001029b7;
code_r0x001029bb:
        if (*(int *)(lVar14 + 0x18) != 99) goto code_r0x001029f6;
      }
      uStack_990 = *(undefined4 *)(lVar14 + 0x20);
      uStack_98c = *(undefined2 *)(lVar14 + 0x24);
      cVar8 = func_0x(&uStack_990);
      if (cVar8 == '\0') goto code_r0x001029f6;
      func_0x(lVar14,&uStack_a10);
    }
    *ppbVar29 = pbVar1;
    *(undefined4 *)(ppbVar29 + 0xc) = (undefined4)uStack_a10;
    *(int *)((longlong)ppbVar29 + 100) = (int)((ulonglong)uStack_a10 >> 0x20);
    *(undefined2 *)(ppbVar29 + 0xd) = uStack_a08;
    *(undefined4 *)((longlong)ppbVar29 + 0x6c) = *(undefined4 *)(lVar14 + 0x20);
    *(undefined2 *)(ppbVar29 + 0xe) = *(undefined2 *)(lVar14 + 0x24);
    uVar40 = SUB82(ppbVar32,0);
    *(undefined2 *)((longlong)ppbVar29 + 0x72) = uVar40;
    uStack_a88 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1085da0);
    uVar45 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1085da4);
    *(undefined2 *)(ppbVar29 + 2) = 0xffff;
    ppbVar29[3] = (byte *)ppbVar32;
    uVar12 = (uint)ppbVar32;
    *(uint *)((longlong)ppbVar29 + 0x14) = uVar12;
    *(byte ***)((longlong)ppbVar29 + 0x2e) = ppbVar32;
    ppbVar29[7] = (byte *)ppbVar32;
    ppbVar29[4] = (byte *)ppbVar32;
    ppbVar29[9] = (byte *)ppbVar32;
    ppbVar29[10] = (byte *)ppbVar32;
    *(undefined2 *)(ppbVar29 + 0xb) = uVar40;
    if ((**ppbVar29 & 2) != 0) {
      pbVar43 = pbVar1 + uVar45;
      if ((*pbVar43 & 1) == 0) {
        *(undefined2 *)(ppbVar29 + 2) = uVar40;
        ppbVar29[3] = pbVar43;
        *(uint *)((longlong)ppbVar29 + 0x14) = uVar12;
        *(uint *)((longlong)ppbVar29 + 0x36) = uVar12;
        switch(*pbVar43 & 0xe) {
        default:
          uVar12 = (uint)*(ushort *)(pbVar43 + 2);
          if (0x1f9d < *(ushort *)(pbVar43 + 2) - 1) {
            func_0x(pbVar43,6);
            ppbVar32 = (byte **)0x0;
          }
          break;
        case 4:
          uVar12 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar12 = 1;
        }
        *(uint *)(ppbVar29 + 4) = uVar12;
        *(byte ***)((longlong)ppbVar29 + 0x2e) = ppbVar32;
      }
      else {
        *(undefined2 *)(ppbVar29 + 2) = 1;
        ppbVar29[3] = pbVar43;
        bVar3 = *pbVar43;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbVar43[1] < '\0') {
            uVar21 = *(ushort *)(pbVar43 + 1);
            *(ushort *)((longlong)ppbVar29 + 0x12) = uVar21;
            sVar36 = 3;
            uVar21 = (uVar21 & 0x7f) << 8 | uVar21 >> 8;
          }
          else {
            sVar36 = 2;
            uVar21 = (ushort)pbVar43[1];
          }
          *(ushort *)((longlong)ppbVar29 + 0x12) = uVar21;
          *(short *)(ppbVar29 + 5) = sVar36;
          *(short *)((longlong)ppbVar29 + 0x2c) =
               (short)(*(ushort *)((longlong)ppbVar29 + 0x12) + 1 >> 1) + sVar36;
          if (*(ushort *)((longlong)ppbVar29 + 0x12) < 0x1f) {
            *(undefined2 *)((longlong)ppbVar29 + 0x2a) = uVar40;
            *(uint *)((longlong)ppbVar29 + 0x14) = uVar12;
            *(uint *)(ppbVar29 + 8) = uVar12;
            ppbVar29[7] = (byte *)ppbVar32;
            ppbVar29[4] = (byte *)ppbVar32;
          }
          else {
            iVar9 = *(ushort *)((longlong)ppbVar29 + 0x12) - 1;
            *(short *)((longlong)ppbVar29 + 0x2a) =
                 ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                 (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
            *(uint *)((longlong)ppbVar29 + 0x14) = uVar12;
            *(uint *)(ppbVar29 + 8) = uVar12;
            ppbVar29[7] = (byte *)ppbVar32;
            ppbVar29[4] = (byte *)ppbVar32;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) != 4) || (uVar10 = 1, (bVar3 & 2) == 0)) {
            uVar10 = uVar12;
          }
          *(uint *)((longlong)ppbVar29 + 0x14) = uVar12;
          ppbVar29[5] = (byte *)ppbVar32;
          *(undefined2 *)((longlong)ppbVar29 + 0x12) = uVar40;
          ppbVar29[6] = (byte *)ppbVar32;
          ppbVar29[4] = (byte *)ppbVar32;
          *(uint *)(ppbVar29 + 8) = uVar12;
          ppbVar29[7] = (byte *)ppbVar32;
          ppbVar29[3] = pbVar43;
          if (uVar10 == 0) {
            *(undefined4 *)((longlong)ppbVar29 + 0x14) = 1;
            *(uint *)(ppbVar29 + 8) = uVar12;
            ppbVar29[7] = (byte *)ppbVar32;
            ppbVar29[4] = (byte *)ppbVar32;
          }
          else {
            *(undefined4 *)((longlong)ppbVar29 + 0x14) = 0xf;
            *(uint *)(ppbVar29 + 8) = uVar12;
            *(undefined4 *)(ppbVar29 + 8) = 1;
            ppbVar29[7] = (byte *)ppbVar32;
            ppbVar29[4] = (byte *)ppbVar32;
          }
          break;
        case 8:
          ppbVar29[5] = (byte *)ppbVar32;
          *(undefined2 *)((longlong)ppbVar29 + 0x12) = uVar40;
          ppbVar29[6] = (byte *)ppbVar32;
          ppbVar29[4] = (byte *)ppbVar32;
          ppbVar29[7] = (byte *)ppbVar32;
          ppbVar29[3] = pbVar43;
          *(undefined4 *)((longlong)ppbVar29 + 0x14) = 9;
          *(uint *)(ppbVar29 + 8) = uVar12;
          ppbVar29[7] = (byte *)ppbVar32;
          ppbVar29[4] = (byte *)ppbVar32;
        }
      }
    }
    uVar12 = (uint)ppbVar32;
    if ((**ppbVar29 & 4) != 0) {
      if (uStack_a88._2_2_ != 0) {
        uVar45 = (ulonglong)*(ushort *)(lVar14 + 0x61 + (longlong)uStack_a88._2_2_ * 2);
      }
      psVar18 = (short *)(pbVar1 + uVar45);
      ppbVar29[9] = (byte *)psVar18;
      sVar36 = *psVar18;
      ppbVar29[10] = (byte *)(psVar18 + 1);
      *(short *)(ppbVar29 + 0xb) = (sVar36 + 1) * 2;
    }
    ppbVar32 = ppbVar29;
    if (ppbVar29[1] != (byte *)0x0) {
      func_0x(ppbVar29[1],ppbVar29);
      uVar12 = 0;
    }
  }
  piStack_310 = (int *)((ulonglong)*(ushort *)(lVar14 + 0x1ffe) + lVar14);
  uVar21 = (ushort)uVar12;
  uStack_314 = uVar12;
  if ((*(byte *)piStack_310 & 1) == 0) {
    uStack_2f0 = (undefined2)(uVar12 >> 0x10);
    ppbVar32 = (byte **)(ulonglong)*(ushort *)(lVar14 + 0xe);
    uStack_318 = uVar21;
    uStack_2f2 = uVar21;
    switch(*(byte *)piStack_310 & 0xe) {
    default:
      ppbVar32 = (byte **)(ulonglong)*(ushort *)((longlong)piStack_310 + 2);
      if (0x1f9d < *(ushort *)((longlong)piStack_310 + 2) - 1) {
        func_0x(piStack_310,6);
        uVar12 = 0;
      }
      break;
    case 4:
      ppbVar32 = (byte **)0x9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      ppbVar32 = (byte **)0x1;
    }
    uStack_308 = (byte **)CONCAT44(uStack_308._4_4_,(int)ppbVar32);
    uStack_2fa = (undefined2)(lVar14 + 0x2000);
    uStack_2f8 = (undefined6)((ulonglong)(lVar14 + 0x2000) >> 0x10);
    ppbVar29 = ppbVar32;
  }
  else {
    uStack_318 = 1;
    bVar3 = *(byte *)piStack_310;
    uStack_316 = uVar21;
    uStack_2e8 = uVar12;
    switch(bVar3 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)piStack_310 + 1) < '\0') {
        uStack_316 = (*(ushort *)((longlong)piStack_310 + 1) & 0x7f) << 8 |
                     *(ushort *)((longlong)piStack_310 + 1) >> 8;
        sVar36 = 3;
        uStack_300._0_2_ = 3;
      }
      else {
        uStack_316 = (ushort)*(byte *)((longlong)piStack_310 + 1);
        sVar36 = 2;
        uStack_300._0_2_ = 2;
      }
      uStack_2fc = (short)(uStack_316 + 1 >> 1) + sVar36;
      uStack_300._2_2_ = uVar21;
      if (0x1e < uStack_316) {
        iVar9 = uStack_316 - 1;
        uStack_300._2_2_ =
             ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
             (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
        uStack_300._0_2_ = 0;
        uStack_300._2_2_ = 0;
        uStack_2fc = 0;
        uStack_2fa = 0;
        uStack_2f8 = 0;
        uStack_2f2 = 0;
        uStack_314 = 0xf;
        uStack_2e8 = 1;
      }
      else {
        uStack_300._0_2_ = 0;
        uStack_300._2_2_ = 0;
        uStack_2fc = 0;
        uStack_2fa = 0;
        uStack_2f8 = 0;
        uStack_2f2 = 0;
        uStack_314 = 1;
      }
      break;
    case 8:
      uStack_300._0_2_ = 0;
      uStack_300._2_2_ = 0;
      uStack_2fc = 0;
      uStack_2fa = 0;
      uStack_2f8 = 0;
      uStack_2f2 = 0;
      uStack_314 = 9;
    }
    lVar14 = lVar14 + 0x2000;
    uStack_2f0 = (undefined2)lVar14;
    uStack_2ee = (undefined2)((ulonglong)lVar14 >> 0x10);
    uStack_2ec = (ushort)((ulonglong)lVar14 >> 0x20);
    uStack_2ea = (undefined2)((ulonglong)lVar14 >> 0x30);
    ppbVar29 = (byte **)((ulonglong)ppbVar32 & 0xffffffff);
    uStack_308 = ppbVar32;
  }
  uVar10 = (uint)ppbVar29;
  puVar17 = (uint *)(lVar16 + 0x210);
  if (uStack_318 == 0) {
    uVar12 = *puVar17;
    if ((uVar12 & 0xc0000000) == 0x80000000) {
      iVar9 = func_0x(&uStack_316);
      if (iVar9 == 0) goto code_r0x001039b8;
      piVar27 = (int *)func_0x(&uStack_2ee,puVar17,aiStack_ad8,auStack_8c8);
      iStack_a94 = *piVar27;
      sStack_a90 = *(short *)(piVar27 + 1);
      goto code_r0x0010011f;
    }
    uVar21 = *(ushort *)(lVar16 + 0x216);
    if ((uVar21 & 0x10) == 0) {
code_r0x00103055:
      if ((int)uVar12 < 0) {
        iVar9 = 0;
        piVar27 = piStack_310;
        if (uStack_314 == 0) {
          uStack_316 = 0;
          uVar12 = uVar10;
          if ((*(byte *)piStack_310 & 0x10) != 0) {
            uVar12 = uVar10 + 2 + (*(ushort *)((longlong)ppbVar29 + (longlong)piStack_310) + 7 >> 3)
            ;
          }
          uStack_308 = (byte **)CONCAT44(uVar12,(uint)uStack_308);
          if ((*(byte *)piStack_310 & 0x20) != 0) {
            puVar31 = (ushort *)((ulonglong)uVar12 + (longlong)piStack_310);
            uStack_2fc = *puVar31;
            if (uStack_2fc == 0) {
              if ((((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
                  (lVar14 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar14 != 0)) &&
                 ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                  (*(char *)(lVar14 + 0x499) != '\0')))) {
                if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
                  (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_b18 = (uint *)0x0;
                  (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x80f);
                }
              }
              func_0x(piStack_310,3);
            }
            uStack_300 = uStack_308._4_4_ + (uStack_2fc + 1) * 2;
            if (0x1f9e < uStack_300) {
              if (((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
                 ((lVar14 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar14 != 0 &&
                  ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                   (*(char *)(lVar14 + 0x499) != '\0')))))) {
                if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
                  (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_b18 = (uint *)0x0;
                  (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x816);
                }
              }
              func_0x(piStack_310,4);
            }
            uStack_314 = puVar31[uStack_2fc] & 0x7fff;
            piVar27 = piStack_310;
            uVar12 = uStack_314;
            if (uStack_314 < uStack_300) {
              if ((((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
                  (lVar14 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar14 != 0)) &&
                 ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                  (*(char *)(lVar14 + 0x499) != '\0')))) {
                if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
                  (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_b18 = (uint *)0x0;
                  (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x81d);
                }
              }
              func_0x(piStack_310,4);
              piVar27 = piStack_310;
              uVar12 = uStack_314;
            }
            while ((short)puVar31[(ulonglong)(uStack_2fc - 1) + 1] < 0) {
              uVar10 = uStack_300;
              if (((uStack_2fc != 1) &&
                  (uVar10 = *(ushort *)
                             ((longlong)piVar27 +
                             (ulonglong)uStack_2fc * 2 + (((ulonglong)uStack_308 >> 0x20) - 2)) &
                            0x7fff, uVar10 < uStack_300)) ||
                 ((*(ushort *)
                    ((longlong)piVar27 + (ulonglong)uStack_2fc * 2 + ((ulonglong)uStack_308 >> 0x20)
                    ) & 0x7fff) < uVar10)) {
                func_0x(piVar27,7);
                piVar27 = piStack_310;
                uVar12 = uStack_314;
              }
              if ((uVar10 < uStack_300) || (uVar12 < uVar10)) goto code_r0x001037ca;
              if (*(ushort *)((ulonglong)uVar10 + (longlong)piVar27) == 5) {
                uStack_316 = uStack_316 | 2;
                uStack_2fc = uStack_2fc - 1;
                uStack_2ee = (undefined2)uVar10;
                uVar21 = *(ushort *)((ulonglong)(uVar10 & 0xffff) + 2 + (longlong)piVar27);
                if ((uVar21 & 0x4000) == 0) {
                  uStack_2ec = uStack_2ec & 0xc7ff;
                }
                else {
                  uStack_2ec = uStack_2ec ^ (uVar21 ^ uStack_2ec) & 0x3800;
                }
                uStack_2ec = uStack_2ec ^
                             (uStack_2ec ^
                             *(ushort *)((ulonglong)(uVar10 & 0xffff) + 2 + (longlong)piVar27)) &
                             0x7ff;
                uVar10 = (uint)uStack_308;
                goto code_r0x0010357f;
              }
              if (*(ushort *)((ulonglong)uVar10 + (longlong)piVar27) < 0x400) break;
              uStack_316 = uStack_316 | 1;
              uStack_2fc = uStack_2fc - 1;
              if (uStack_2fc == 0) break;
            }
            uVar10 = (uint)uStack_308;
            goto code_r0x0010357f;
          }
          uStack_2fc = 0;
          uStack_314 = uVar12;
          uStack_300 = uVar12;
code_r0x0010357f:
          if ((*(byte *)piVar27 & 0x40) == 0) {
            uStack_2f2 = 0;
            uStack_2f0 = 0;
          }
          else {
            uStack_2f2 = (ushort)uVar12;
            uStack_2f0 = (undefined2)(uVar12 >> 0x10);
            uStack_314 = uVar12 + 0xe;
            puVar19 = (ulonglong *)func_0x(&uStack_316);
            uVar45 = *puVar19;
            uVar20 = (ushort)(uVar45 >> 0x30);
            uVar21 = uVar20;
            if ((((uint)(int)(short)uVar20 >> 1 ^ (int)(short)uVar20) & 0x2000) != 0) {
              uVar21 = uVar20 & 0xdfff;
              if ((uVar45 & 0x4000000000000000) != 0) {
                uVar21 = uVar20 | 0x2000;
              }
            }
            iVar25 = iVar9;
            if (uVar21 == 0xfffc) {
              iVar25 = (int)((uVar45 >> 0x20 & 0xffff) >> 5);
            }
            uVar12 = uStack_314 + iVar25;
            piVar27 = piStack_310;
            uVar10 = (uint)uStack_308;
            uStack_314 = uVar12;
          }
          if (((byte *)CONCAT62(uStack_2f8,uStack_2fa) != (byte *)0x0) &&
             ((byte *)CONCAT62(uStack_2f8,uStack_2fa) <
              (byte *)((ulonglong)uVar12 + (longlong)piVar27))) {
            if (((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
               (((lVar14 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), piVar27 = piStack_310, lVar14 != 0
                 && (lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0)) &&
                (*(char *)(lVar14 + 0x499) != '\0')))) {
              if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
                (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3fa);
                piVar27 = piStack_310;
              }
              else {
                uStack_b18 = (uint *)0x0;
                (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x877);
                piVar27 = piStack_310;
              }
            }
            func_0x(piVar27,0x12);
            piVar27 = piStack_310;
            uVar12 = uStack_314;
            uVar10 = (uint)uStack_308;
          }
          if (uVar12 - 1 < 0x3f3c) goto code_r0x001037d0;
          if (((cRam000000000199888b != '\0') || ((bRam00000000019a9190 & 1) != 0)) &&
             ((lVar14 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), piVar27 = piStack_310, lVar14 != 0 &&
              ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
               (*(char *)(lVar14 + 0x499) != '\0')))))) {
            if ((cRam000000000199877b == '\0') && ((bRam00000000019a9190 & 2) == 0)) {
              (*pcRam0000000000f070b8)(0x22,0x44,0x15,0x3ed);
              piVar27 = piStack_310;
            }
            else {
              uStack_b18 = (uint *)0x0;
              (*pcRam0000000000f070b0)(1,0x12892b8,0x13a8f88,0x87c);
              piVar27 = piStack_310;
            }
          }
          func_0x(piVar27,5);
          piVar27 = piStack_310;
code_r0x001037ca:
          uVar10 = (uint)uStack_308;
        }
code_r0x001037d0:
        sVar36 = -*(short *)puVar17;
        if ((*(byte *)(lVar16 + 0x216) & 0x10) != 0) {
          if ((*(byte *)piVar27 & 0x10) == 0) {
            if ((1 << (*(byte *)piVar27 & 0xe) & 0x1105U) != 0) {
code_r0x00103832:
              piVar27 = *(int **)(lVar16 + 0x218);
              aiStack_ad8[0] = *piVar27;
              iStack_a94 = piVar27[1];
              sStack_a90 = *(short *)(piVar27 + 2);
              goto code_r0x0010011f;
            }
          }
          else if (((int)uVar10 <= (int)*puVar17) ||
                  (*(ushort *)((ulonglong)uVar10 + (longlong)piVar27) < *(ushort *)(lVar16 + 0x214))
                  ) goto code_r0x00103832;
        }
        if ((uint)uStack_2fc < (uint)(int)sVar36) {
code_r0x001038b4:
          iStack_a94 = *piVar27;
          sStack_a90 = *(short *)(piVar27 + 1);
          aiStack_ad8[0] = iVar9;
        }
        else {
          piVar34 = piVar27;
          uVar12 = uStack_300;
          if (sVar36 != 1) {
            piVar34 = piStack_310;
            uVar12 = *(ushort *)
                      ((longlong)piVar27 +
                      (longlong)sVar36 * 2 + (((ulonglong)uStack_308 >> 0x20) - 2)) & 0x7fff;
          }
          uVar10 = *(ushort *)
                    ((longlong)piVar27 + (longlong)sVar36 * 2 + ((ulonglong)uStack_308 >> 0x20)) &
                   0x7fff;
          if ((uVar12 < uStack_300) || (uVar10 < uVar12)) {
            func_0x(piVar34,7);
            piVar34 = piStack_310;
          }
          aiStack_ad8[0] = uVar10 - uVar12;
          iStack_a94 = *(int *)((ulonglong)uVar12 + (longlong)piVar34);
          sStack_a90 = *(short *)((int *)((ulonglong)uVar12 + (longlong)piVar34) + 1);
        }
        goto code_r0x0010011f;
      }
      if ((uVar21 & 8) != 0) {
        aiStack_ad8[0] = 1;
        piVar27 = (int *)0x100dcf4;
        if ((*(byte *)((longlong)(int)uVar12 + (longlong)piStack_310) &
            (byte)(1 << ((byte)uVar21 & 7))) == 0) {
          piVar27 = (int *)0x100e318;
        }
        iStack_a94 = *piVar27;
        sStack_a90 = *(short *)(piVar27 + 1);
        goto code_r0x0010011f;
      }
      if ((uVar21 & 0x10) != 0) {
        if ((*(byte *)piStack_310 & 0x10) != 0) {
          if (((int)uVar12 < (int)uVar10) &&
             (*(ushort *)(lVar16 + 0x214) <= *(ushort *)((longlong)ppbVar29 + (longlong)piStack_310)
             )) goto code_r0x00103088;
code_r0x001030bb:
          piVar34 = *(int **)(lVar16 + 0x218);
          piVar27 = piVar34 + 1;
          iVar9 = *piVar34;
          if (iVar9 == 6) goto code_r0x001038b4;
          uStack_b18 = (uint *)0x0;
          (*pcRam0000000000f070b0)(1,0x1437028,0x1435a28,0x381);
          iStack_a94 = *piVar27;
          sStack_a90 = *(short *)(piVar34 + 2);
          aiStack_ad8[0] = iVar9;
          goto code_r0x0010011f;
        }
        if ((1 << (*(byte *)piStack_310 & 0xe) & 0x1105U) != 0) goto code_r0x001030bb;
      }
code_r0x00103088:
      aiStack_ad8[0] = 6;
      iStack_a94 = *(int *)((longlong)(int)*puVar17 + (longlong)piStack_310);
      sStack_a90 = *(short *)((int *)((longlong)(int)*puVar17 + (longlong)piStack_310) + 1);
      goto code_r0x0010011f;
    }
    if ((*(byte *)piStack_310 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_310 & 0xe) & 0x1105U) == 0) goto code_r0x00103055;
      aiStack_ad8[0] = **(int **)(lVar16 + 0x218);
      piVar27 = *(int **)(lVar16 + 0x218) + 1;
    }
    else {
      if (((int)uVar12 < (int)ppbVar32) &&
         (*(ushort *)(lVar16 + 0x214) <= *(ushort *)((longlong)ppbVar29 + (longlong)piStack_310)))
      goto code_r0x00103055;
      aiStack_ad8[0] = **(int **)(lVar16 + 0x218);
      piVar27 = *(int **)(lVar16 + 0x218) + 1;
    }
  }
  else {
    uStack_b18 = &uStack_a8c;
    uStack_a8c = uVar12;
    piVar27 = (int *)func_0x(&uStack_316,puVar17,piStack_310,aiStack_ad8);
    if ((((uStack_318 == 0) || (uStack_308 == (byte **)0x0)) || (*uStack_308 == (byte *)0x0)) ||
       (((*(byte *)(lVar16 + 0x216) & 8) != 0 || ((uStack_a8c & 1) != 0)))) goto code_r0x001039c0;
    if ((piVar27 != (int *)0x0) && (piVar27 != (int *)0x100dcf4)) {
      uStack_b00 = uStack_a8c;
      uStack_b08 = aiStack_ad8;
      uStack_b10 = (uint *)CONCAT44(uStack_b10._4_4_,6);
      uStack_b18 = auStack_108;
      piVar27 = (int *)func_0x(uStack_308,puVar17,piVar27,aiStack_ad8[0]);
      iStack_a94 = *piVar27;
      sStack_a90 = *(short *)(piVar27 + 1);
      goto code_r0x0010011f;
    }
code_r0x001039b8:
    aiStack_ad8[0] = 0;
    piVar27 = (int *)0x0;
  }
code_r0x001039c0:
  iStack_a94 = *piVar27;
  sStack_a90 = *(short *)(piVar27 + 1);
  goto code_r0x0010011f;
}

