
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,undefined *param_3)

{
  ushort *puVar1;
  uint *puVar2;
  uint *puVar3;
  byte **ppbVar4;
  ushort *puVar5;
  undefined2 uVar6;
  undefined4 uVar7;
  ushort uVar8;
  int iVar9;
  undefined4 *puVar10;
  ushort **ppuVar11;
  byte bVar12;
  uint uVar13;
  ushort uVar14;
  uint uVar15;
  ulonglong uVar16;
  longlong lVar17;
  longlong lVar18;
  uint uVar19;
  byte *pbVar20;
  longlong unaff_GS_OFFSET;
  undefined *puStack_a8;
  undefined4 uStack_90;
  undefined2 uStack_8c;
  undefined8 *puStack_88;
  ushort *puStack_80;
  ushort *puStack_78;
  undefined *puStack_70;
  undefined auStack_60 [8];
  undefined8 uStack_58;
  
  uStack_58 = 0xfffffffffffffffe;
  puStack_88 = (undefined8 *)0x0;
  puStack_a8 = param_3;
  if (param_3 == (undefined *)0x0) {
    puStack_88 = (undefined8 *)func_0x(_DAT_,1,1,0);
    puStack_a8 = (undefined *)*puStack_88;
  }
  func_0x(puStack_a8,0,0x2000);
  uStack_8c = *(undefined2 *)(param_1 + 0x20);
  uStack_90 = 0;
  puVar10 = (undefined4 *)func_0x(param_1,auStack_60,&uStack_90);
  uVar7 = *puVar10;
  uVar6 = *(undefined2 *)(puVar10 + 1);
  puStack_70 = puStack_a8;
  *puStack_a8 = 1;
  puStack_a8[1] = 0xf;
  *(undefined4 *)(puStack_a8 + 0x20) = uVar7;
  *(undefined2 *)(puStack_a8 + 0x24) = uVar6;
  *(undefined2 *)(puStack_a8 + 0x1e) = 0x60;
  *(undefined2 *)(puStack_a8 + 0x1c) = 0x1fa0;
  *(undefined8 *)(puStack_a8 + 0x28) = 0;
  *(undefined2 *)(puStack_a8 + 0x30) = 1;
  if (1 < (0xfd0 - (ulonglong)*(ushort *)(puStack_a8 + 0x16)) * 2) {
    *(undefined2 *)(puStack_a8 + 0x60) = 0;
  }
  *(undefined4 *)(puStack_a8 + 0x18) = 99;
  puVar1 = (ushort *)(param_2 + 1);
  if (*param_2 == 0) {
    puVar2 = (uint *)(param_2 + 2);
    puStack_78 = puVar1;
    if (*puVar2 == 0) {
      *puVar1 = 0;
      uVar15 = *(uint *)(param_2 + 8);
      uVar16 = (ulonglong)uVar15;
      puVar3 = (uint *)(param_2 + 10);
      *puVar3 = uVar15;
      ppbVar4 = (byte **)(param_2 + 4);
      pbVar20 = *ppbVar4;
      bVar12 = *pbVar20;
      if ((bVar12 & 0x10) != 0) {
        uVar15 = uVar15 + 2 + (*(ushort *)(pbVar20 + uVar16) + 7 >> 3);
        uVar16 = (ulonglong)uVar15;
        *puVar3 = uVar15;
        bVar12 = *pbVar20;
      }
      puVar5 = (ushort *)(param_2 + 0xe);
      if ((bVar12 & 0x20) == 0) {
        *puVar2 = (uint)uVar16;
        *puVar5 = 0;
        *(uint *)(param_2 + 0xc) = uVar15;
      }
      else {
        puStack_80 = (ushort *)(pbVar20 + uVar16);
        uVar14 = *puStack_80;
        *puVar5 = uVar14;
        if (uVar14 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar17 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar17 != 0)) &&
             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x13845f8,0x14a42c8,0x80f,0);
            }
          }
          func_0x(*ppbVar4,3);
          uVar15 = *puVar3;
        }
        uVar14 = *puVar5;
        uVar15 = uVar15 + (uVar14 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar15;
        if (0x1f9e < uVar15) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar17 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar17 != 0 &&
              ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
               (*(char *)(lVar17 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x13845f8,0x14a42c8,0x816,0);
            }
          }
          func_0x(*ppbVar4,4);
          uVar14 = *puVar5;
          uVar15 = *(uint *)(param_2 + 0xc);
        }
        uVar16 = (ulonglong)uVar14;
        uVar14 = puStack_80[uVar16];
        *puVar2 = uVar14 & 0x7fff;
        if ((uVar14 & 0x7fff) < uVar15) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar17 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar17 != 0)) &&
             ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
              (*(char *)(lVar17 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x13845f8,0x14a42c8,0x81d,0);
            }
          }
          func_0x(*ppbVar4,4);
          uVar16 = (ulonglong)*puVar5;
        }
        while ((short)puStack_80[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
          pbVar20 = *ppbVar4;
          uVar15 = *puVar3;
          if ((int)uVar16 == 1) {
            uVar19 = *(uint *)(param_2 + 0xc);
            uVar14 = *(ushort *)(pbVar20 + uVar16 * 2 + (ulonglong)uVar15);
            uVar13 = uVar19;
LAB_:
            if ((uVar14 & 0x7fff) < uVar19) goto LAB_;
          }
          else {
            uVar19 = *(ushort *)(pbVar20 + uVar16 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
            uVar13 = *(uint *)(param_2 + 0xc);
            uVar14 = *(ushort *)(pbVar20 + uVar16 * 2 + (ulonglong)uVar15);
            if (uVar13 <= uVar19) goto LAB_;
LAB_:
            func_0x(pbVar20,7);
            uVar13 = *(uint *)(param_2 + 0xc);
          }
          if ((uVar19 < uVar13) || (*puVar2 < uVar19)) goto LAB_;
          if (*(ushort *)(*ppbVar4 + uVar19) == 5) {
            *puVar1 = *puVar1 | 2;
            *puVar5 = *puVar5 - 1;
            param_2[0x15] = (short)uVar19;
            lVar17 = (ulonglong)(uVar19 & 0xffff) + *(longlong *)(param_2 + 4);
            uVar14 = *(ushort *)(lVar17 + 2);
            uVar8 = param_2[0x16] & 0xc7ff;
            if ((uVar14 & 0x4000) == 0) {
              param_2[0x16] = uVar8;
            }
            else {
              uVar8 = uVar14 & 0x3800 | uVar8;
              param_2[0x16] = uVar8;
            }
            param_2[0x16] = (uVar8 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar8;
            pbVar20 = *ppbVar4;
            uVar16 = (ulonglong)*puVar2;
            goto LAB_;
          }
          if (*(ushort *)(*ppbVar4 + uVar19) < 0x400) break;
          *puVar1 = *puVar1 | 1;
          uVar14 = *puVar5 - 1;
          *puVar5 = uVar14;
          if (uVar14 == 0) break;
          uVar16 = (ulonglong)uVar14;
        }
        pbVar20 = *ppbVar4;
        uVar16 = (ulonglong)*puVar2;
      }
LAB_:
      if ((*pbVar20 & 0x40) == 0) {
        *(undefined4 *)(puStack_78 + 0x12) = 0;
      }
      else {
        uVar15 = *puVar2;
        *(uint *)(puStack_78 + 0x12) = uVar15;
        *puVar2 = uVar15 + 0xe;
        ppuVar11 = (ushort **)func_0x(puVar1);
        puStack_78 = *ppuVar11;
        iVar9 = 0;
        uVar14 = (ushort)((ulonglong)puStack_78 >> 0x30);
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          if (((ulonglong)puStack_78 & 0x4000000000000000) == 0) {
            uVar14 = uVar14 & 0xdfff;
          }
          else {
            uVar14 = uVar14 | 0x2000;
          }
        }
        if (uVar14 == 0xfffc) {
          iVar9 = (int)(((ulonglong)puStack_78 >> 0x20 & 0xffff) >> 5);
        }
        *puVar2 = *puVar2 + iVar9;
        uVar16 = (ulonglong)*puVar2;
      }
      iVar9 = (int)uVar16;
      if ((*(byte **)(param_2 + 0xf) != (byte *)0x0) &&
         (*(byte **)(param_2 + 0xf) < *ppbVar4 + uVar16)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar17 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8), lVar17 != 0 && (lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0)) &&
            (*(char *)(lVar17 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x13845f8,0x14a42c8,0x877,0);
          }
        }
        func_0x(*ppbVar4,0x12);
        iVar9 = *(int *)(param_2 + 2);
      }
      if (0x3f3b < iVar9 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar17 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar17 != 0 &&
            ((lVar17 = *(longlong *)(lVar17 + 0x60), lVar17 != 0 &&
             (*(char *)(lVar17 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x13845f8,0x14a42c8,0x87c,0);
          }
        }
        func_0x(*ppbVar4,5);
      }
    }
LAB_:
    uVar15 = *puVar2;
    if (8 < uVar15) goto LAB_;
    bVar12 = **(byte **)(param_2 + 4) & 0xe;
  }
  else {
    uVar15 = *(uint *)(param_2 + 2);
    if (uVar15 == 0) {
      func_0x(puVar1);
      uVar15 = *(uint *)(param_2 + 2);
    }
    if (8 < uVar15) goto LAB_;
    bVar12 = **(byte **)(param_2 + 4) & 0x1c;
  }
  if ((bVar12 == 0) || (bVar12 == 0xc)) {
    uVar15 = 9;
  }
LAB_:
  iVar9 = func_0x(puStack_70,*(undefined8 *)(param_2 + 4),uVar15);
  if (iVar9 != 0) {
    (*_DAT_)(1,0x153cdb8,0x15093a8,0xa81,0);
  }
  func_0x(param_1);
  if (puStack_88 != (undefined8 *)0x0) {
    func_0x(_DAT_,puStack_88,0);
  }
  lVar18 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar17 = *(longlong *)(lVar18 + 0x100);
  if (lVar17 == 0) {
    (*_DAT_)();
    lVar17 = *(longlong *)(lVar18 + 0x100);
  }
  if (*(int *)(lVar17 + 0x22c) != 0) {
    (*_DAT_)();
  }
  return;
}

