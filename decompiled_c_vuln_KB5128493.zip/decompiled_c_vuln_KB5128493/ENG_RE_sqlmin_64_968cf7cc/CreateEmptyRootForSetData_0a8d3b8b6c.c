
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined4 param_2,undefined4 *param_3,longlong param_4)

{
  undefined8 *puVar1;
  byte *pbVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  longlong lVar7;
  longlong lVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  longlong lVar11;
  undefined8 uVar12;
  ulonglong uVar13;
  longlong lVar14;
  ushort uVar15;
  undefined8 unaff_RBX;
  ulonglong uVar16;
  longlong lVar17;
  longlong lVar18;
  int iVar19;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [4];
  undefined8 auStackX_18 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  puVar1 = (undefined8 *)((longlong)auStackX_18 + lVar11);
  *puVar1 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002120 + lVar11) = unaff_RBX;
  *(ulonglong *)(&stack0x000020c8 + lVar11) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10005a;
  func_0x(&stack0x00000028 + lVar11,&stack0x00000130 + lVar11);
  *(undefined8 *)(&stack0x00000028 + lVar11) = 0x83ed88;
  uVar4 = *param_3;
  *(undefined4 *)(&stack0x000000b0 + lVar11) = 0;
  *(undefined2 *)(&stack0x000000b4 + lVar11) = 0;
  *(undefined4 *)((longlong)auStackX_8 + lVar11) = 0;
  uVar16 = 0x10;
  *(undefined8 *)((longlong)auStackX_18 + lVar11 + -0x18) = 0x10;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = 2;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 8;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = uVar4;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000ad;
  func_0x(&stack0x00000028 + lVar11,param_1,0,0);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000b6;
  func_0x(&stack0x00000028 + lVar11);
  if ((((*(uint *)(&stack0x00000064 + lVar11) & 0x800) != 0) &&
      (*(int *)(&stack0x00000048 + lVar11) == 0)) && (*(short *)(&stack0x0000004c + lVar11) == 0)) {
    lVar7 = *(longlong *)(&stack0x00000078 + lVar11);
    if ((*(byte *)(lVar7 + 0xc) & 0xf) == 0) {
      uVar16 = (ulonglong)*(ushort *)(lVar7 + 0xe);
    }
    else {
      uVar15 = (*(short *)(lVar7 + 0x10) + 1) * 0xc;
      uVar16 = (ulonglong)uVar15;
      if (uVar15 == 0x10) goto LAB_;
    }
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100118;
    (*_DAT_)(1,0xc80f80,0xc2bf00,0xe57);
  }
LAB_:
  uVar13 = uVar16 + 0xf;
  if (uVar13 <= uVar16) {
    uVar13 = 0xffffffffffffff0;
  }
  uVar13 = uVar13 & 0xfffffffffffffff0;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10013a;
  func_0x();
  lVar8 = -uVar13;
  lVar7 = (longlong)auStackX_18 + lVar8 + lVar11;
  iVar19 = (int)uVar16;
  *(undefined8 *)((longlong)&uStack_40 + lVar8 + lVar11) = 0x100155;
  func_0x(&stack0x00000028 + lVar11,uVar16,lVar7);
  *(undefined8 *)((longlong)&uStack_40 + lVar8 + lVar11) = 0x10015e;
  func_0x(&stack0x00000028 + lVar11);
  lVar18 = (ulonglong)*(uint *)(param_4 + 4) * 0x40;
  pbVar2 = (byte *)(lVar18 + 0x18 + *(longlong *)(param_4 + 8));
  *pbVar2 = *pbVar2 & 0xfb;
  if (*(uint *)(param_4 + 0x20) < (uint)(*(int *)(param_4 + 0x10) + iVar19)) {
    lVar17 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar14 = *(longlong *)(lVar17 + 0x100);
    if (lVar14 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar8 + lVar11) = 0x1001ac;
      (*_DAT_)(0);
      lVar14 = *(longlong *)(lVar17 + 0x100);
    }
    (&stack0xffffffffffffffe8)[lVar8 + lVar11] = 5;
    uVar12 = *(undefined8 *)(lVar14 + 1000);
    *(undefined8 *)((longlong)&uStack_40 + lVar8 + lVar11) = 0x1001d7;
    uVar12 = (*_DAT_)(0x1f9e,uVar12,0xbc2a08,0xcd);
    *(undefined8 *)(param_4 + 0x18) = uVar12;
    *(undefined4 *)(param_4 + 0x10) = 0;
    pbVar2 = (byte *)(lVar18 + 0x18 + *(longlong *)(param_4 + 8));
    *pbVar2 = *pbVar2 | 4;
    *(undefined4 *)(param_4 + 0x20) = 0x1f9e;
  }
  uVar4 = param_3[1];
  uVar9 = param_3[2];
  uVar10 = param_3[3];
  puVar3 = (undefined4 *)(lVar18 + 8 + *(longlong *)(param_4 + 8));
  *puVar3 = *param_3;
  puVar3[1] = uVar4;
  puVar3[2] = uVar9;
  puVar3[3] = uVar10;
  *(undefined4 *)(lVar18 + *(longlong *)(param_4 + 8)) = param_2;
  pbVar2 = (byte *)(lVar18 + 0x18 + *(longlong *)(param_4 + 8));
  *pbVar2 = *pbVar2 & 0xfe;
  pbVar2 = (byte *)(lVar18 + 0x18 + *(longlong *)(param_4 + 8));
  *pbVar2 = *pbVar2 & 0xfd;
  lVar18 = *(longlong *)(param_4 + 8) + lVar18;
  *(ulonglong *)(lVar18 + 0x20) =
       (ulonglong)*(uint *)(param_4 + 0x10) + *(longlong *)(param_4 + 0x18);
  *(int *)(lVar18 + 0x28) = iVar19;
  uVar5 = *(uint *)(lVar18 + 0x2c);
  *(uint *)(lVar18 + 0x2c) = uVar5 & 0xfffffffb | 1;
  uVar4 = param_3[1];
  uVar9 = param_3[2];
  uVar10 = param_3[3];
  *(undefined4 *)(lVar18 + 0x30) = *param_3;
  *(undefined4 *)(lVar18 + 0x34) = uVar4;
  *(undefined4 *)(lVar18 + 0x38) = uVar9;
  *(undefined4 *)(lVar18 + 0x3c) = uVar10;
  *(uint *)(lVar18 + 0x2c) = uVar5 & 0xfffffff1 | 1;
  uVar5 = *(uint *)(param_4 + 0x10);
  iVar6 = *(int *)(param_4 + 0x20);
  lVar18 = *(longlong *)(param_4 + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar8 + lVar11) = 0x100262;
  func_0x((ulonglong)uVar5 + lVar18,iVar6 - uVar5,lVar7,uVar16);
  *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 1;
  *(int *)(param_4 + 0x10) = *(int *)(param_4 + 0x10) + iVar19;
  *(undefined8 *)((longlong)&uStack_40 + lVar8 + lVar11) = 0x100272;
  func_0x(&stack0x00000028 + lVar11);
  uVar16 = *(ulonglong *)(&stack0x000020c8 + lVar11);
  *(undefined8 *)((longlong)&uStack_40 + lVar8 + lVar11) = 0x100281;
  func_0x(uVar16 ^ (ulonglong)puVar1);
  return;
}

