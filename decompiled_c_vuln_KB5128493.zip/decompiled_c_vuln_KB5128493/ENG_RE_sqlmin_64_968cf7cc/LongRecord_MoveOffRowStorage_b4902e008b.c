
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 *param_5,int *param_6)

{
  ushort *puVar1;
  undefined8 uVar2;
  longlong *plVar3;
  undefined8 uVar4;
  byte bVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint *puVar9;
  ulonglong *puVar10;
  ulonglong uVar11;
  longlong lVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  longlong lVar15;
  undefined *puVar16;
  ushort *puVar17;
  uint uVar18;
  int *piVar19;
  ushort uVar20;
  short sVar21;
  ushort uVar22;
  ushort uVar23;
  byte *pbVar24;
  longlong lVar25;
  uint uVar26;
  uint uVar27;
  short *psVar28;
  longlong unaff_GS_OFFSET;
  undefined auStack_e8 [80];
  int aiStack_98 [2];
  uint uStack_90;
  undefined4 uStack_8c;
  int *piStack_88;
  uint uStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  longlong lStack_70;
  longlong lStack_68;
  uint auStack_60 [2];
  undefined8 uStack_58;
  undefined8 uStack_50;
  short *psStack_48;
  longlong lStack_40;
  ulonglong uStack_38;
  
  puVar16 = auStack_e8;
  uStack_38 = _DAT_ ^ (ulonglong)aiStack_98;
  lVar25 = *(longlong *)(param_1 + 0x58);
  iVar7 = 0;
  uStack_90 = 0;
  uStack_8c = (uint)(uStack_8c._2_2_ & 0xffe0) << 0x10;
  piStack_88 = (int *)0x0;
  lVar15 = *(longlong *)(lVar25 + 8);
  lStack_68 = 0;
  iStack_78 = -1;
  iVar8 = iVar7;
  lStack_70 = lVar25;
  uStack_58 = param_4;
  uStack_50 = param_3;
  psStack_48 = param_2;
  lStack_40 = param_1;
  if (*(int *)(lVar15 + 0x100) == 2) {
    if ((*(byte *)(lVar15 + 0x42) & 4) == 0) {
      uVar13 = (ulonglong)*(uint *)(lVar15 + 0xb0);
      if (0x1f9e < *(uint *)(lVar15 + 0xb0)) {
        uVar13 = 0x1f9e;
      }
    }
    else {
      uVar13 = 0x1f9e;
    }
    iVar8 = (int)uVar13;
    uVar11 = uVar13 + 0xf;
    if (uVar11 <= uVar13) {
      uVar11 = 0xffffffffffffff0;
    }
    uVar11 = uVar11 & 0xfffffffffffffff0;
    iVar7 = 0;
    func_0x();
    puVar16 = auStack_e8 + -uVar11;
    lStack_68 = (longlong)aiStack_98 + -uVar11;
  }
  lVar15 = lStack_68;
  puVar1 = (ushort *)(param_2 + 1);
  *param_6 = iVar7;
  uVar27 = 0;
  *param_5 = 0;
  if (*param_2 == (short)iVar7) {
    *(undefined8 *)(puVar16 + -8) = 0x1000fd;
    uVar6 = func_0x(puVar1);
    lVar25 = lStack_70;
  }
  else {
    uVar6 = (uint)*puVar1;
  }
  psVar28 = param_2;
  if (0 < (int)uVar6) {
    do {
      uVar18 = ~uVar27;
      if ((uVar18 & 0xc0000000) == 0x80000000) {
        uVar2 = **(undefined8 **)(*(longlong *)(lVar25 + 8) + 0x160);
        *(undefined8 *)(puVar16 + -8) = 0x100163;
        puVar9 = (uint *)func_0x(uVar2,uVar18 & 0x1fffffff);
        lVar25 = lStack_70;
      }
      else {
        uVar2 = *(undefined8 *)(*(longlong *)(lVar25 + 8) + 0x160);
        *(undefined8 *)(puVar16 + -8) = 0x100148;
        puVar9 = (uint *)func_0x(uVar2);
      }
      if (puVar9 == (uint *)0x0) {
        *(undefined8 *)(puVar16 + -8) = 0x10017a;
        func_0x(lVar25,uVar18,&uStack_90);
      }
      else {
        uStack_90 = *puVar9;
        uStack_8c = puVar9[1];
        piStack_88 = *(int **)(puVar9 + 2);
      }
      *(undefined8 *)(puVar16 + -8) = 0x10018f;
      iVar7 = func_0x(psVar28,&uStack_90);
      if (iVar7 != 0) {
        piVar19 = (int *)0x0;
        iStack_7c = 0;
        if (*psVar28 == 0) {
          if ((uStack_90 & 0xc0000000) == 0x80000000) {
            *(undefined8 *)(puVar16 + -8) = 0x1009af;
            iVar7 = func_0x(puVar1);
            if (iVar7 == 0) {
              aiStack_98[0] = 0;
              iVar7 = aiStack_98[0];
            }
            else {
              *(undefined8 *)(puVar16 + -8) = 0x1009c8;
              piVar19 = (int *)func_0x(param_2 + 0x15,&uStack_90,aiStack_98,auStack_60);
              iVar7 = aiStack_98[0];
            }
          }
          else {
            uVar20 = uStack_8c._2_2_ >> 4 & 1;
            if (uVar20 != 0) {
              bVar5 = **(byte **)(param_2 + 4);
              if ((bVar5 & 0x10) == 0) {
                if ((1 << (bVar5 & 0xe) & 0x1105U) == 0) goto LAB_;
              }
              else if (((int)uStack_90 < (int)*(uint *)(param_2 + 8)) &&
                      ((ushort)uStack_8c <=
                       *(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8))))
              goto LAB_;
              goto LAB_;
            }
LAB_:
            if ((int)uStack_90 < 0) {
              if (*(int *)(param_2 + 2) == 0) {
                pbVar24 = *(byte **)(param_2 + 4);
                uVar18 = *(uint *)(param_2 + 8);
                uVar13 = (ulonglong)uVar18;
                *puVar1 = 0;
                *(uint *)(param_2 + 10) = uVar18;
                bVar5 = *pbVar24;
                if ((bVar5 & 0x10) != 0) {
                  uVar18 = uVar18 + 2 + (*(ushort *)(pbVar24 + uVar13) + 7 >> 3);
                  uVar13 = (ulonglong)uVar18;
                  *(uint *)(param_2 + 10) = uVar18;
                  bVar5 = *pbVar24;
                }
                if ((bVar5 & 0x20) == 0) {
                  *(int *)(param_2 + 2) = (int)uVar13;
                  param_2[0xe] = 0;
                  *(int *)(param_2 + 0xc) = (int)uVar13;
                }
                else {
                  puVar17 = (ushort *)(pbVar24 + uVar13);
                  uVar20 = *puVar17;
                  param_2[0xe] = uVar20;
                  if (uVar20 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar25 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar25 != 0)) &&
                       ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                        (*(char *)(lVar25 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar16 + -8) = 0x1003ba;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar16 + 0x20) = 0;
                        *(undefined8 *)(puVar16 + -8) = 0x1003e0;
                        (*_DAT_)(1,0xa9ea88,0xbbe758,0x80f);
                      }
                    }
                    uVar2 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)(puVar16 + -8) = 0x1003ee;
                    func_0x(uVar2,3);
                    uVar13 = (ulonglong)*(uint *)(param_2 + 10);
                    uVar20 = param_2[0xe];
                  }
                  uVar18 = (int)uVar13 + (uVar20 + 1) * 2;
                  *(uint *)(param_2 + 0xc) = uVar18;
                  if (0x1f9e < uVar18) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar25 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar25 != 0 &&
                        ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                         (*(char *)(lVar25 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar16 + -8) = 0x10048d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar16 + 0x20) = 0;
                        *(undefined8 *)(puVar16 + -8) = 0x1004b3;
                        (*_DAT_)(1,0xa9ea88,0xbbe758,0x816);
                      }
                    }
                    uVar2 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)(puVar16 + -8) = 0x1004c1;
                    func_0x(uVar2,4);
                    uVar20 = param_2[0xe];
                    uVar18 = *(uint *)(param_2 + 0xc);
                  }
                  uVar13 = (ulonglong)uVar20;
                  uVar20 = puVar17[uVar13];
                  *(uint *)(param_2 + 2) = uVar20 & 0x7fff;
                  if ((uVar20 & 0x7fff) < uVar18) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar25 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar25 != 0)) &&
                       ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                        (*(char *)(lVar25 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar16 + -8) = 0x10055f;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar16 + 0x20) = 0;
                        *(undefined8 *)(puVar16 + -8) = 0x100585;
                        (*_DAT_)(1,0xa9ea88,0xbbe758,0x81d);
                      }
                    }
                    uVar2 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)(puVar16 + -8) = 0x100593;
                    func_0x(uVar2,4);
                    uVar13 = (ulonglong)(ushort)param_2[0xe];
                  }
                  if ((short)puVar17[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
                    pbVar24 = *(byte **)(param_2 + 4);
                    do {
                      if ((int)uVar13 == 1) {
                        uVar18 = *(uint *)(param_2 + 0xc);
                        uVar26 = uVar18;
LAB_:
                        if ((*(ushort *)(pbVar24 + uVar13 * 2 + (ulonglong)*(uint *)(param_2 + 10))
                            & 0x7fff) < uVar18) goto LAB_;
                      }
                      else {
                        uVar26 = *(uint *)(param_2 + 0xc);
                        uVar18 = *(ushort *)
                                  (pbVar24 + uVar13 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2))
                                 & 0x7fff;
                        if (uVar26 <= uVar18) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar16 + -8) = 0x1005f2;
                        func_0x(pbVar24,7);
                        uVar26 = *(uint *)(param_2 + 0xc);
                      }
                      if ((uVar18 < uVar26) || (*(uint *)(param_2 + 2) < uVar18)) goto LAB_;
                      pbVar24 = *(byte **)(param_2 + 4);
                      if (*(ushort *)(pbVar24 + uVar18) == 5) {
                        *puVar1 = *puVar1 | 2;
                        param_2[0xe] = param_2[0xe] + -1;
                        param_2[0x15] = (short)uVar18;
                        lVar25 = (ulonglong)(uVar18 & 0xffff) + *(longlong *)(param_2 + 4);
                        uVar20 = param_2[0x16] & 0xc7ffU;
                        if ((*(ushort *)(lVar25 + 2) >> 0xe & 1) != 0) {
                          uVar20 = *(ushort *)(lVar25 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                        }
                        param_2[0x16] = uVar20;
                        param_2[0x16] = (uVar20 ^ *(ushort *)(lVar25 + 2)) & 0x7ff ^ uVar20;
                        goto LAB_;
                      }
                      if (*(ushort *)(pbVar24 + uVar18) < 0x400) goto LAB_;
                      *puVar1 = *puVar1 | 1;
                      uVar20 = param_2[0xe] - 1;
                      param_2[0xe] = uVar20;
                      if (uVar20 == 0) goto LAB_;
                      uVar13 = (ulonglong)uVar20;
                    } while ((short)puVar17[(ulonglong)(uVar20 - 1) + 1] < 0);
                    uVar13 = (ulonglong)*(uint *)(param_2 + 2);
                  }
                  else {
LAB_:
                    uVar13 = (ulonglong)*(uint *)(param_2 + 2);
                    pbVar24 = *(byte **)(param_2 + 4);
                  }
                }
                iVar7 = 0;
                if ((*pbVar24 & 0x40) == 0) {
                  *(undefined4 *)(param_2 + 0x13) = 0;
                }
                else {
                  *(int *)(param_2 + 0x13) = (int)uVar13;
                  *(int *)(param_2 + 2) = (int)uVar13 + 0xe;
                  *(undefined8 *)(puVar16 + -8) = 0x1006e2;
                  puVar10 = (ulonglong *)func_0x(puVar1);
                  uVar23 = (ushort)(*puVar10 >> 0x30);
                  uVar20 = uVar23;
                  if ((((uint)(int)(short)uVar23 >> 1 ^ (int)(short)uVar23) & 0x2000) != 0) {
                    uVar20 = uVar23 & 0xdfff;
                    if ((uVar23 >> 0xe & 1) != 0) {
                      uVar20 = uVar23 | 0x2000;
                    }
                  }
                  if (uVar20 == 0xfffc) {
                    iVar7 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar7;
                  uVar13 = (ulonglong)*(uint *)(param_2 + 2);
                }
                iVar7 = (int)uVar13;
                if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
                   (*(ulonglong *)(param_2 + 0xf) < uVar13 + *(longlong *)(param_2 + 4))) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar25 = *(longlong *)
                                  (*(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                       lVar25 != 0 && (lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0)) &&
                      (*(char *)(lVar25 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar16 + -8) = 0x1007de;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar16 + 0x20) = 0;
                      *(undefined8 *)(puVar16 + -8) = 0x100804;
                      (*_DAT_)(1,0xa9ea88,0xbbe758,0x877);
                    }
                  }
                  uVar2 = *(undefined8 *)(param_2 + 4);
                  *(undefined8 *)(puVar16 + -8) = 0x100812;
                  func_0x(uVar2,0x12);
                  iVar7 = *(int *)(param_2 + 2);
                }
                if (0x3f3b < iVar7 - 1U) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar25 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar25 != 0 &&
                      ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                       (*(char *)(lVar25 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar16 + -8) = 0x10089e;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar16 + 0x20) = 0;
                      *(undefined8 *)(puVar16 + -8) = 0x1008c4;
                      (*_DAT_)(1,0xa9ea88,0xbbe758,0x87c);
                    }
                  }
                  uVar2 = *(undefined8 *)(param_2 + 4);
                  *(undefined8 *)(puVar16 + -8) = 0x1008d2;
                  func_0x(uVar2,5);
                }
              }
LAB_:
              sVar21 = -(short)uStack_90;
              if ((uStack_8c & 0x100000) != 0) {
                bVar5 = **(byte **)(param_2 + 4);
                if ((bVar5 & 0x10) == 0) {
                  if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                    piVar19 = piStack_88 + 1;
                    iVar7 = *piStack_88;
                    goto LAB_;
                  }
                }
                else {
                  if ((int)*(uint *)(param_2 + 8) <= (int)uStack_90) goto LAB_;
                  if (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
                      (ushort)uStack_8c) {
                    piVar19 = piStack_88 + 1;
                    iVar7 = *piStack_88;
                    goto LAB_;
                  }
                }
              }
              piVar19 = *(int **)(param_2 + 4);
              if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar21) {
                iVar7 = 0;
              }
              else {
                uVar18 = *(ushort *)
                          ((longlong)piVar19 +
                          (longlong)sVar21 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff;
                if (sVar21 == 1) {
                  uVar26 = *(uint *)(param_2 + 0xc);
LAB_:
                  if (uVar18 < uVar26) goto LAB_;
                }
                else {
                  uVar26 = *(ushort *)
                            ((longlong)piVar19 +
                            (longlong)sVar21 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                           0x7fff;
                  if (*(uint *)(param_2 + 0xc) <= uVar26) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar16 + -8) = 0x100982;
                  func_0x(piVar19,7);
                  piVar19 = *(int **)(param_2 + 4);
                }
                piVar19 = (int *)((longlong)piVar19 + (ulonglong)uVar26);
                psVar28 = psStack_48;
                iVar7 = uVar18 - uVar26;
              }
            }
            else {
              if ((uStack_8c & 0x80000) != 0) {
                piVar19 = (int *)0x8234c4;
                aiStack_98[0] = 1;
                iVar7 = aiStack_98[0];
                if ((*(byte *)((longlong)(int)uStack_90 + *(longlong *)(param_2 + 4)) &
                    (byte)(1 << (uStack_8c._2_1_ & 7))) == 0) {
                  piVar19 = (int *)0x823ae8;
                }
                goto LAB_;
              }
              if (uVar20 != 0) {
                bVar5 = **(byte **)(param_2 + 4);
                if ((bVar5 & 0x10) == 0) {
                  if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                    iVar7 = *piStack_88;
                    piVar19 = piStack_88 + 1;
                    if (iVar7 != 0x1f9e) {
                      *(undefined8 *)(puVar16 + 0x20) = 0;
                      *(undefined8 *)(puVar16 + -8) = 0x1002ac;
                      (*_DAT_)(1,0xc4c7f8,0xc4b1f8,0x381);
                    }
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(param_2 + 8) <= (int)uStack_90) ||
                        (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
                         (ushort)uStack_8c)) goto LAB_;
              }
              piVar19 = (int *)((longlong)(int)uStack_90 + *(longlong *)(param_2 + 4));
              aiStack_98[0] = 0x1f9e;
              iVar7 = aiStack_98[0];
            }
          }
        }
        else {
          uStack_80 = 0;
          *(uint **)(puVar16 + 0x20) = &uStack_80;
          *(undefined8 *)(puVar16 + -8) = 0x1009f1;
          piVar19 = (int *)func_0x(puVar1,&uStack_90);
          iVar7 = aiStack_98[0];
          if ((((*psVar28 != 0) && (plVar3 = *(longlong **)(psVar28 + 8), plVar3 != (longlong *)0x0)
               ) && (*plVar3 != 0)) && (((uStack_8c & 0x80000) == 0 && ((uStack_80 & 1) == 0)))) {
            if ((piVar19 == (int *)0x0) || (piVar19 == (int *)0x8234c4)) {
              piVar19 = (int *)0x0;
              aiStack_98[0] = 0;
              iVar7 = aiStack_98[0];
            }
            else {
              *(uint *)(puVar16 + 0x38) = uStack_80;
              *(int **)(puVar16 + 0x30) = aiStack_98;
              *(int *)(puVar16 + 0x28) = iVar8;
              *(longlong *)(puVar16 + 0x20) = lVar15;
              *(undefined8 *)(puVar16 + -8) = 0x100a4f;
              piVar19 = (int *)func_0x(plVar3,&uStack_90,piVar19,iVar7);
              iVar7 = aiStack_98[0];
            }
          }
        }
LAB_:
        aiStack_98[0] = iVar7;
        lVar25 = lStack_40;
        uVar4 = uStack_50;
        uVar2 = uStack_58;
        *(int **)(puVar16 + 0x40) = &iStack_7c;
        *(undefined8 **)(puVar16 + 0x38) = param_5;
        *(int *)(puVar16 + 0x30) = aiStack_98[0];
        *(int **)(puVar16 + 0x28) = piVar19;
        *(uint **)(puVar16 + 0x20) = &uStack_90;
        *(undefined8 *)(puVar16 + -8) = 0x100a97;
        func_0x(lVar25,psVar28,uVar4,uVar2);
        if ((*param_6 == 0) && (iStack_7c == 0)) {
          iVar7 = 0;
        }
        else {
          iVar7 = 1;
        }
        *param_6 = iVar7;
      }
      uVar27 = uVar27 + 1;
      lVar15 = lStack_68;
      lVar25 = lStack_70;
    } while ((int)uVar27 < (int)uVar6);
  }
  uVar11 = 0;
  *(undefined8 *)(puVar16 + -8) = 0x100ad5;
  iVar8 = func_0x(psVar28);
  lStack_68 = (longlong)iVar8;
  uVar13 = uVar11;
  uVar27 = auStack_60[0];
  if (0 < lStack_68) {
    do {
      if (*(int *)(param_2 + 2) == 0) {
        pbVar24 = *(byte **)(param_2 + 4);
        uVar6 = *(uint *)(param_2 + 8);
        uVar14 = (ulonglong)uVar6;
        *puVar1 = 0;
        *(uint *)(param_2 + 10) = uVar6;
        bVar5 = *pbVar24;
        if ((bVar5 & 0x10) != 0) {
          uVar6 = uVar6 + 2 + (*(ushort *)(pbVar24 + uVar14) + 7 >> 3);
          uVar14 = (ulonglong)uVar6;
          *(uint *)(param_2 + 10) = uVar6;
          bVar5 = *pbVar24;
        }
        if ((bVar5 & 0x20) == 0) {
          *(int *)(param_2 + 2) = (int)uVar14;
          param_2[0xe] = 0;
          *(int *)(param_2 + 0xc) = (int)uVar14;
        }
        else {
          puVar17 = (ushort *)(pbVar24 + uVar14);
          uVar20 = *puVar17;
          param_2[0xe] = uVar20;
          if (uVar20 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar25 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar25 != 0)) &&
               ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                (*(char *)(lVar25 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar16 + -8) = 0x100bc0;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar16 + 0x20) = 0;
                *(undefined8 *)(puVar16 + -8) = 0x100be6;
                (*_DAT_)(1,0xa9ea88,0xbbe758,0x80f);
              }
            }
            uVar2 = *(undefined8 *)(param_2 + 4);
            *(undefined8 *)(puVar16 + -8) = 0x100bf4;
            func_0x(uVar2,3);
            uVar14 = (ulonglong)*(uint *)(param_2 + 10);
            uVar20 = param_2[0xe];
          }
          uVar6 = (int)uVar14 + (uVar20 + 1) * 2;
          *(uint *)(param_2 + 0xc) = uVar6;
          if (0x1f9e < uVar6) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar25 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar25 != 0 &&
                ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                 (*(char *)(lVar25 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar16 + -8) = 0x100c93;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar16 + 0x20) = 0;
                *(undefined8 *)(puVar16 + -8) = 0x100cb9;
                (*_DAT_)(1,0xa9ea88,0xbbe758,0x816);
              }
            }
            uVar2 = *(undefined8 *)(param_2 + 4);
            *(undefined8 *)(puVar16 + -8) = 0x100cc7;
            func_0x(uVar2,4);
            uVar20 = param_2[0xe];
            uVar6 = *(uint *)(param_2 + 0xc);
          }
          uVar14 = (ulonglong)uVar20;
          uVar20 = puVar17[uVar14];
          *(uint *)(param_2 + 2) = uVar20 & 0x7fff;
          if ((uVar20 & 0x7fff) < uVar6) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar25 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar25 != 0)) &&
               ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
                (*(char *)(lVar25 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar16 + -8) = 0x100d65;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar16 + 0x20) = 0;
                *(undefined8 *)(puVar16 + -8) = 0x100d8b;
                (*_DAT_)(1,0xa9ea88,0xbbe758,0x81d);
              }
            }
            uVar2 = *(undefined8 *)(param_2 + 4);
            *(undefined8 *)(puVar16 + -8) = 0x100d99;
            func_0x(uVar2,4);
            uVar14 = (ulonglong)(ushort)param_2[0xe];
          }
          if ((short)puVar17[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
            pbVar24 = *(byte **)(param_2 + 4);
            do {
              if ((int)uVar14 == 1) {
                uVar6 = *(uint *)(param_2 + 0xc);
                uVar18 = uVar6;
LAB_:
                if ((*(ushort *)(pbVar24 + uVar14 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff
                    ) < uVar6) goto LAB_;
              }
              else {
                uVar18 = *(uint *)(param_2 + 0xc);
                uVar6 = *(ushort *)(pbVar24 + uVar14 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2))
                        & 0x7fff;
                if (uVar18 <= uVar6) goto LAB_;
LAB_:
                *(undefined8 *)(puVar16 + -8) = 0x100e02;
                func_0x(pbVar24,7);
                uVar18 = *(uint *)(param_2 + 0xc);
              }
              if ((uVar6 < uVar18) || (*(uint *)(param_2 + 2) < uVar6)) goto LAB_;
              pbVar24 = *(byte **)(param_2 + 4);
              if (*(ushort *)(pbVar24 + uVar6) == 5) {
                *puVar1 = *puVar1 | 2;
                param_2[0xe] = param_2[0xe] + -1;
                param_2[0x15] = (short)uVar6;
                lVar25 = (ulonglong)(uVar6 & 0xffff) + *(longlong *)(param_2 + 4);
                uVar20 = param_2[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar25 + 2) >> 0xe & 1) != 0) {
                  uVar20 = *(ushort *)(lVar25 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                }
                param_2[0x16] = uVar20;
                param_2[0x16] = (uVar20 ^ *(ushort *)(lVar25 + 2)) & 0x7ff ^ uVar20;
                goto LAB_;
              }
              if (*(ushort *)(pbVar24 + uVar6) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar20 = param_2[0xe] - 1;
              param_2[0xe] = uVar20;
              if (uVar20 == 0) goto LAB_;
              uVar14 = (ulonglong)uVar20;
            } while ((short)puVar17[(ulonglong)(uVar20 - 1) + 1] < 0);
            uVar14 = (ulonglong)*(uint *)(param_2 + 2);
          }
          else {
LAB_:
            uVar14 = (ulonglong)*(uint *)(param_2 + 2);
            pbVar24 = *(byte **)(param_2 + 4);
          }
        }
        iVar8 = 0;
        if ((*pbVar24 & 0x40) == 0) {
          *(undefined4 *)(param_2 + 0x13) = 0;
        }
        else {
          *(int *)(param_2 + 0x13) = (int)uVar14;
          *(int *)(param_2 + 2) = (int)uVar14 + 0xe;
          *(undefined8 *)(puVar16 + -8) = 0x100ef2;
          puVar10 = (ulonglong *)func_0x(puVar1);
          uVar23 = (ushort)(*puVar10 >> 0x30);
          uVar20 = uVar23;
          if ((((uint)(int)(short)uVar23 >> 1 ^ (int)(short)uVar23) & 0x2000) != 0) {
            uVar20 = uVar23 & 0xdfff;
            if ((uVar23 >> 0xe & 1) != 0) {
              uVar20 = uVar23 | 0x2000;
            }
          }
          if (uVar20 == 0xfffc) {
            iVar8 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar8;
          uVar14 = (ulonglong)*(uint *)(param_2 + 2);
        }
        iVar8 = (int)uVar14;
        if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
           (*(ulonglong *)(param_2 + 0xf) < uVar14 + *(longlong *)(param_2 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar25 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar25 != 0 &&
               (lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0)) &&
              (*(char *)(lVar25 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar16 + -8) = 0x100fee;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar16 + 0x20) = 0;
              *(undefined8 *)(puVar16 + -8) = 0x101014;
              (*_DAT_)(1,0xa9ea88,0xbbe758,0x877);
            }
          }
          uVar2 = *(undefined8 *)(param_2 + 4);
          *(undefined8 *)(puVar16 + -8) = 0x101022;
          func_0x(uVar2,0x12);
          iVar8 = *(int *)(param_2 + 2);
        }
        if (0x3f3b < iVar8 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar25 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar25 != 0 &&
              ((lVar25 = *(longlong *)(lVar25 + 0x60), lVar25 != 0 &&
               (*(char *)(lVar25 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)(puVar16 + -8) = 0x1010ae;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              uVar2 = *(undefined8 *)(param_2 + 4);
              *(undefined8 *)(puVar16 + -8) = 0x1010bc;
              func_0x(uVar2,5);
              goto LAB_;
            }
            *(undefined8 *)(puVar16 + 0x20) = 0;
            *(undefined8 *)(puVar16 + -8) = 0x1010e2;
            (*_DAT_)(1,0xa9ea88,0xbbe758,0x87c);
          }
          uVar2 = *(undefined8 *)(param_2 + 4);
          *(undefined8 *)(puVar16 + -8) = 0x1010f0;
          func_0x(uVar2,5);
        }
      }
LAB_:
      *(undefined8 *)(puVar16 + -8) = 0x1010fc;
      iVar8 = func_0x(puVar1);
      uVar6 = (uint)uVar13;
      if (iVar8 == 0) {
        *(undefined8 *)(puVar16 + -8) = 0x10123e;
        iVar8 = func_0x(puVar1);
        lVar25 = 0;
        if (iVar8 == 0) {
          *(undefined8 *)(puVar16 + 0x20) = 0;
          *(undefined8 *)(puVar16 + -8) = 0x101264;
          (*_DAT_)(1,0xc5a108,0xc4b1f8,0xd67);
          lVar25 = 0;
        }
      }
      else {
        uVar20 = param_2[0x16];
        if (uVar6 < (uVar20 & 0x7ff)) {
          uVar13 = (ulonglong)(ushort)param_2[0x15];
          lVar15 = *(longlong *)(param_2 + 4);
          uVar23 = 0;
          lVar25 = lVar15 + uVar13;
          if ((uVar20 & 0x3800) == 0) {
            uVar22 = *(ushort *)(lVar25 + 2);
LAB_:
            uVar23 = uVar22 >> 0xb & 7;
          }
          else {
            lVar12 = 0;
            if ((uVar20 >> 0xb & 7) != 0) {
              do {
                if (((lVar12 == 0) || ((*(ushort *)(lVar25 + 2 + lVar12 * 2) & 0x7ff) <= uVar6)) &&
                   (uVar22 = *(ushort *)(lVar25 + 4 + lVar12 * 2),
                   (int)uVar6 <= (int)((uVar22 & 0x7ff) - 1))) goto LAB_;
                lVar12 = lVar12 + 1;
              } while (lVar12 < (longlong)(ulonglong)(uVar20 >> 0xb & 7));
            }
          }
          uVar26 = uVar20 >> 0xb & 7;
          uVar27 = uVar26 * 2;
          uVar18 = (uVar20 & 0x7ff) * 2;
          iStack_78 = (uint)*(ushort *)((ulonglong)uVar27 + 4 + uVar11 * 2 + lVar15 + uVar13) +
                      (uint)uVar23 * 0x10000;
          lVar15 = (ulonglong)uVar18 + (ulonglong)uVar27 + lVar15 + uVar13;
          if (uVar11 == 0) {
            uVar18 = (uVar18 + uVar26) * 2 + 4;
          }
          else {
            uVar18 = *(ushort *)(lVar15 + 2 + uVar11 * 2) & 0x7fff;
          }
          aiStack_98[0] = (*(ushort *)(lVar15 + 4 + uVar11 * 2) & 0x7fff) - uVar18;
          uVar27 = (uint)(*(ushort *)(lVar15 + 4 + uVar11 * 2) >> 0xf);
          lVar25 = (ulonglong)uVar18 + lVar25;
        }
        else {
          *(undefined8 *)(puVar16 + 0x20) = 0;
          *(undefined8 *)(puVar16 + -8) = 0x101234;
          (*_DAT_)(1,0xc5a0d8,0xc5a120,0x3c6);
          lVar25 = 0;
        }
      }
      iVar8 = iStack_78;
      if (uVar27 != 0) {
        iStack_74 = 0;
        uVar2 = **(undefined8 **)(*(longlong *)(lStack_70 + 8) + 0x160);
        *(undefined8 *)(puVar16 + -8) = 0x10128a;
        puVar9 = (uint *)func_0x(uVar2,iVar8);
        lVar15 = lStack_40;
        psVar28 = psStack_48;
        uVar4 = uStack_50;
        uVar2 = uStack_58;
        uVar18 = *puVar9;
        uVar26 = puVar9[1];
        piVar19 = *(int **)(puVar9 + 2);
        *(int **)(puVar16 + 0x40) = &iStack_74;
        *(undefined8 **)(puVar16 + 0x38) = param_5;
        *(int *)(puVar16 + 0x30) = aiStack_98[0];
        *(longlong *)(puVar16 + 0x28) = lVar25;
        *(uint **)(puVar16 + 0x20) = &uStack_90;
        uStack_90 = uVar18;
        uStack_8c = uVar26;
        piStack_88 = piVar19;
        *(undefined8 *)(puVar16 + -8) = 0x1012d0;
        func_0x(lVar15,psVar28,uVar4,uVar2);
        if ((*param_6 == 0) && (iStack_74 == 0)) {
          iVar8 = 0;
        }
        else {
          iVar8 = 1;
        }
        *param_6 = iVar8;
      }
      uVar11 = uVar11 + 1;
      uVar13 = (ulonglong)(uVar6 + 1);
    } while ((longlong)uVar11 < lStack_68);
  }
  uVar13 = uStack_38 ^ (ulonglong)aiStack_98;
  *(undefined8 *)(puVar16 + -8) = 0x10130e;
  func_0x(uVar13);
  return;
}

