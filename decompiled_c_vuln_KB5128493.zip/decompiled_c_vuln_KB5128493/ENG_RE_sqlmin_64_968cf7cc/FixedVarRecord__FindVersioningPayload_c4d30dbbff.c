
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

byte * FUN_(ushort *param_1)

{
  byte bVar1;
  ushort uVar2;
  ulonglong *puVar3;
  byte *pbVar4;
  ushort uVar5;
  ulonglong uVar6;
  int iVar7;
  ushort *puVar8;
  uint uVar9;
  uint uVar10;
  longlong lVar11;
  longlong unaff_GS_OFFSET;
  
  pbVar4 = *(byte **)(param_1 + 3);
  if ((*pbVar4 & 0x40) == 0) {
    return (byte *)0x0;
  }
  if (*(int *)(param_1 + 1) == 0) {
    uVar9 = *(uint *)(param_1 + 7);
    uVar6 = (ulonglong)uVar9;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar9;
    bVar1 = *pbVar4;
    if ((bVar1 & 0x10) != 0) {
      uVar9 = uVar9 + 2 + (*(ushort *)(pbVar4 + uVar6) + 7 >> 3);
      uVar6 = (ulonglong)uVar9;
      *(uint *)(param_1 + 9) = uVar9;
      bVar1 = *pbVar4;
    }
    if ((bVar1 & 0x20) == 0) {
      *(int *)(param_1 + 1) = (int)uVar6;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = (int)uVar6;
    }
    else {
      puVar8 = (ushort *)(pbVar4 + uVar6);
      uVar2 = *puVar8;
      param_1[0xd] = uVar2;
      if (uVar2 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar11 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar11 != 0)) &&
           ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9e8bb8,0xb08888,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar6 = (ulonglong)*(uint *)(param_1 + 9);
        uVar2 = param_1[0xd];
      }
      uVar9 = (int)uVar6 + (uVar2 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar9;
      if (0x1f9e < uVar9) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar11 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar11 != 0 &&
            ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
             (*(char *)(lVar11 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9e8bb8,0xb08888,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar2 = param_1[0xd];
        uVar9 = *(uint *)(param_1 + 0xb);
      }
      uVar6 = (ulonglong)uVar2;
      uVar2 = puVar8[uVar6];
      *(uint *)(param_1 + 1) = uVar2 & 0x7fff;
      if ((uVar2 & 0x7fff) < uVar9) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar11 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar11 != 0)) &&
           ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9e8bb8,0xb08888,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar6 = (ulonglong)param_1[0xd];
      }
      if ((short)puVar8[(ulonglong)((int)uVar6 - 1) + 1] < 0) {
        pbVar4 = *(byte **)(param_1 + 3);
        do {
          if ((int)uVar6 == 1) {
            uVar9 = *(uint *)(param_1 + 0xb);
            uVar10 = uVar9;
LAB_:
            if ((*(ushort *)(pbVar4 + uVar6 * 2 + (ulonglong)*(uint *)(param_1 + 9)) & 0x7fff) <
                uVar9) goto LAB_;
          }
          else {
            uVar10 = *(uint *)(param_1 + 0xb);
            uVar9 = *(ushort *)(pbVar4 + uVar6 * 2 + ((ulonglong)*(uint *)(param_1 + 9) - 2)) &
                    0x7fff;
            if (uVar10 <= uVar9) goto LAB_;
LAB_:
            func_0x(pbVar4,7);
            pbVar4 = *(byte **)(param_1 + 3);
            uVar10 = *(uint *)(param_1 + 0xb);
          }
          if ((uVar9 < uVar10) || (*(uint *)(param_1 + 1) < uVar9)) goto LAB_;
          if (*(ushort *)(pbVar4 + uVar9) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = param_1[0xd] - 1;
            param_1[0x14] = (ushort)uVar9;
            lVar11 = (ulonglong)(uVar9 & 0xffff) + *(longlong *)(param_1 + 3);
            uVar2 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(lVar11 + 2) >> 0xe & 1) != 0) {
              uVar2 = *(ushort *)(lVar11 + 2) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar2;
            param_1[0x15] = (uVar2 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar2;
            goto LAB_;
          }
          if (*(ushort *)(pbVar4 + uVar9) < 0x400) goto LAB_;
          *param_1 = *param_1 | 1;
          uVar2 = param_1[0xd] - 1;
          param_1[0xd] = uVar2;
          if (uVar2 == 0) goto LAB_;
          uVar6 = (ulonglong)uVar2;
        } while ((short)puVar8[(ulonglong)(uVar2 - 1) + 1] < 0);
        uVar6 = (ulonglong)*(uint *)(param_1 + 1);
      }
      else {
LAB_:
        uVar6 = (ulonglong)*(uint *)(param_1 + 1);
      }
    }
    pbVar4 = *(byte **)(param_1 + 3);
    iVar7 = 0;
    if ((*pbVar4 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar6;
      *(int *)(param_1 + 1) = (int)uVar6 + 0xe;
      puVar3 = (ulonglong *)func_0x(param_1);
      uVar5 = (ushort)(*puVar3 >> 0x30);
      uVar2 = uVar5;
      if ((((uint)(int)(short)uVar5 >> 1 ^ (int)(short)uVar5) & 0x2000) != 0) {
        uVar2 = uVar5 & 0xdfff;
        if ((uVar5 >> 0xe & 1) != 0) {
          uVar2 = uVar5 | 0x2000;
        }
      }
      if (uVar2 == 0xfffc) {
        iVar7 = (int)((*puVar3 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar7;
      uVar6 = (ulonglong)*(uint *)(param_1 + 1);
      pbVar4 = *(byte **)(param_1 + 3);
    }
    uVar9 = (uint)uVar6;
    if ((*(byte **)(param_1 + 0xe) != (byte *)0x0) && (*(byte **)(param_1 + 0xe) < pbVar4 + uVar6))
    {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar11 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar11 != 0 &&
           (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
          (*(char *)(lVar11 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9e8bb8,0xb08888,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      uVar9 = *(uint *)(param_1 + 1);
      pbVar4 = *(byte **)(param_1 + 3);
    }
    if ((uVar9 == 0) || (0x3f3c < uVar9)) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar11 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar11 != 0 &&
           (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
          (*(char *)(lVar11 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9e8bb8,0xb08888,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
      pbVar4 = *(byte **)(param_1 + 3);
    }
  }
LAB_:
  return pbVar4 + (ulonglong)*(uint *)(param_1 + 0x12) + 0xe;
}

