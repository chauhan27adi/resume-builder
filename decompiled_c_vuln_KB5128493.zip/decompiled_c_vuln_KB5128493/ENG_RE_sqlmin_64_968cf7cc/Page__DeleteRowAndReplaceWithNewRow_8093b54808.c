
void FUN_(longlong param_1,int param_2,uint param_3,short **param_4,undefined2 param_5,
                 undefined8 param_6)

{
  byte bVar1;
  bool bVar2;
  ushort uVar3;
  int iVar4;
  ulonglong *puVar5;
  short *psVar6;
  byte bVar7;
  longlong lVar8;
  short sVar9;
  ushort uVar10;
  short sVar11;
  uint uVar12;
  uint uVar13;
  ulonglong uVar14;
  uint uVar15;
  ushort *puVar16;
  uint uVar17;
  byte *pbVar18;
  ushort *puVar19;
  longlong unaff_GS_OFFSET;
  short asStackX_8 [4];
  int iStackX_10;
  uint uStackX_18;
  undefined8 in_stack_ffffffffffffff08;
  undefined4 uVar20;
  undefined4 uVar21;
  undefined2 uVar22;
  ushort uStack_c6;
  uint uStack_c4;
  byte *pbStack_c0;
  undefined4 uStack_b8;
  uint uStack_b4;
  uint uStack_b0;
  ushort uStack_ac;
  byte *pbStack_aa;
  undefined2 uStack_a2;
  undefined2 uStack_a0;
  undefined2 uStack_9e;
  ushort uStack_9c;
  undefined2 uStack_9a;
  undefined4 uStack_98;
  undefined2 uStack_90;
  ushort uStack_8e;
  undefined4 uStack_8c;
  byte *pbStack_88;
  undefined8 uStack_80;
  undefined4 uStack_78;
  short sStack_74;
  undefined8 uStack_72;
  undefined2 uStack_6a;
  undefined2 uStack_68;
  undefined6 uStack_66;
  undefined4 uStack_60;
  int aiStack_58 [2];
  short *psStack_50;
  ushort *puStack_48;
  
  if (*(char *)(param_1 + 2) < '\0') {
    psStack_50 = param_4[1];
  }
  else {
    psStack_50 = *param_4;
  }
  uVar14 = 0;
  uStack_c4 = 0;
  pbStack_aa = (byte *)0x0;
  puStack_48 = (ushort *)(param_1 + (0xfff - (longlong)param_2) * 2);
  pbStack_c0 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)param_2) * 2) + param_1)
  ;
  uStack_9e = 0;
  uStack_9c = 0;
  uStack_9a = 0;
  uStack_b8 = 0;
  uStack_b4 = 0;
  sVar9 = 3;
  iStackX_10 = param_2;
  uStackX_18 = param_3;
  if ((*pbStack_c0 & 1) == 0) {
    bVar2 = false;
    uStack_a2 = 0;
    uStack_a0 = 0;
    uVar14 = (ulonglong)*(ushort *)(param_1 + 0xe);
    switch(*pbStack_c0 & 0xe) {
    default:
      uVar14 = (ulonglong)*(ushort *)(pbStack_c0 + 2);
      if (0x1f9d < *(ushort *)(pbStack_c0 + 2) - 1) {
        func_0x(pbStack_c0,6);
      }
      break;
    case 4:
      uVar14 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar14 = 1;
    }
    pbStack_aa = (byte *)(param_1 + 0x2000);
    uStack_b8 = (undefined4)uVar14;
  }
  else {
    bVar2 = true;
    bVar7 = *pbStack_c0;
    switch(bVar7 & 0x1c) {
    default:
      if ((char)pbStack_c0[1] < '\0') {
        uStack_b0 = 3;
        uStack_c6 = (*(ushort *)(pbStack_c0 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_c0 + 1) >> 8;
      }
      else {
        uStack_c6 = (ushort)pbStack_c0[1];
        uStack_b0 = 2;
        sVar9 = 2;
      }
      uStack_ac = ((ushort)(uStack_c6 + 1) >> 1) + sVar9;
      if (uStack_c6 < 0x1f) {
        lVar8 = param_1 + 0x2000;
        uStack_a0 = (undefined2)lVar8;
        uStack_9e = (undefined2)((ulonglong)lVar8 >> 0x10);
        uStack_9c = (ushort)((ulonglong)lVar8 >> 0x20);
        uStack_9a = (undefined2)((ulonglong)lVar8 >> 0x30);
        uStack_98 = 0;
      }
      else {
        iVar4 = uStack_c6 - 1;
        uStack_98 = 0;
        uVar14 = 0;
        lVar8 = param_1 + 0x2000;
        uStack_a0 = (undefined2)lVar8;
        uStack_9e = (undefined2)((ulonglong)lVar8 >> 0x10);
        uStack_9c = (ushort)((ulonglong)lVar8 >> 0x20);
        uStack_9a = (undefined2)((ulonglong)lVar8 >> 0x30);
        uStack_b0 = CONCAT22(((short)(iVar4 / 0x1e) + (short)(iVar4 >> 0x1f)) -
                             (short)((longlong)iVar4 * 0x88888889 >> 0x3f),(undefined2)uStack_b0);
      }
      break;
    case 4:
      if (((bVar7 & 0x1c) == 4) && ((bVar7 & 2) != 0)) {
        uStack_b0 = 0;
        lVar8 = param_1 + 0x2000;
        uStack_c4 = 0xf;
        uStack_a0 = (undefined2)lVar8;
        uStack_9e = (undefined2)((ulonglong)lVar8 >> 0x10);
        uStack_9c = (ushort)((ulonglong)lVar8 >> 0x20);
        uStack_9a = (undefined2)((ulonglong)lVar8 >> 0x30);
        uVar14 = 0;
        uStack_c6 = 0;
        uStack_ac = 0;
        uStack_a2 = 0;
        uStack_98 = 1;
      }
      else {
        lVar8 = param_1 + 0x2000;
        uStack_b0 = 0;
        uStack_a0 = (undefined2)lVar8;
        uStack_9e = (undefined2)((ulonglong)lVar8 >> 0x10);
        uStack_9c = (ushort)((ulonglong)lVar8 >> 0x20);
        uStack_9a = (undefined2)((ulonglong)lVar8 >> 0x30);
        uStack_c6 = 0;
        uVar14 = 0;
        uStack_ac = 0;
        uStack_a2 = 0;
        uStack_c4 = 1;
        uStack_98 = 0;
      }
      break;
    case 8:
      uStack_b0 = 0;
      lVar8 = param_1 + 0x2000;
      uStack_c4 = 9;
      uStack_a0 = (undefined2)lVar8;
      uStack_9e = (undefined2)((ulonglong)lVar8 >> 0x10);
      uStack_9c = (ushort)((ulonglong)lVar8 >> 0x20);
      uStack_9a = (undefined2)((ulonglong)lVar8 >> 0x30);
      uVar14 = 0;
      uStack_c6 = 0;
      uStack_ac = 0;
      uStack_a2 = 0;
      uStack_98 = 0;
    }
  }
  if (bVar2) {
    if (uStack_c4 == 0) {
      func_0x(&uStack_c6);
    }
    uVar13 = uStack_c4;
    if (8 < uStack_c4) goto code_r0x001008ec;
    bVar7 = *pbStack_c0 & 0x1c;
  }
  else {
    uVar13 = uStack_c4;
    if (uStack_c4 == 0) {
      uStack_b4 = (uint)uVar14;
      uStack_c6 = 0;
      if ((*pbStack_c0 & 0x10) != 0) {
        uStack_b4 = uStack_b4 + 2 + (*(ushort *)(pbStack_c0 + uVar14) + 7 >> 3);
        uVar14 = (ulonglong)uStack_b4;
      }
      if ((*pbStack_c0 & 0x20) == 0) {
        uStack_ac = 0;
        uStack_c4 = (uint)uVar14;
        uStack_b0 = (uint)uVar14;
      }
      else {
        puVar16 = (ushort *)(pbStack_c0 + uVar14);
        uStack_ac = *puVar16;
        if (uStack_ac == 0) {
          if ((((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                        (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
              (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3eb);
            }
            else {
              in_stack_ffffffffffffff08 = 0;
              (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x80f,0);
            }
          }
          func_0x(pbStack_c0,3);
        }
        uStack_b0 = uStack_b4 + 2 + (uint)uStack_ac * 2;
        if (0x1f9e < uStack_b0) {
          if (((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
             ((lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                        (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0 &&
              ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
               (*(char *)(lVar8 + 0x499) != '\0')))))) {
            if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
              (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3ec);
            }
            else {
              in_stack_ffffffffffffff08 = 0;
              (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x816,0);
            }
          }
          func_0x(pbStack_c0,4);
        }
        uStack_c4 = puVar16[uStack_ac] & 0x7fff;
        uVar14 = (ulonglong)uStack_c4;
        uVar17 = uStack_b0;
        if (uStack_c4 < uStack_b0) {
          if ((((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                        (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
              (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3ec);
            }
            else {
              in_stack_ffffffffffffff08 = 0;
              (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x81d,0);
            }
          }
          func_0x(pbStack_c0,4);
          uVar14 = (ulonglong)uStack_c4;
          uVar17 = uStack_b0;
        }
        do {
          if (-1 < (short)puVar16[(ulonglong)(uStack_ac - 1) + 1]) break;
          uVar12 = uVar17;
          if (((uStack_ac != 1) &&
              (uVar12 = *(ushort *)
                         (pbStack_c0 + (ulonglong)uStack_ac * 2 + ((ulonglong)uStack_b4 - 2)) &
                        0x7fff, uVar12 < uVar17)) ||
             ((*(ushort *)(pbStack_c0 + (ulonglong)uStack_ac * 2 + (ulonglong)uStack_b4) & 0x7fff) <
              uVar12)) {
            func_0x(pbStack_c0,7);
            uVar14 = (ulonglong)uStack_c4;
            uVar17 = uStack_b0;
          }
          uVar13 = (uint)uVar14;
          if ((uVar12 < uVar17) || (uVar13 < uVar12)) goto code_r0x001008ab;
          if (*(ushort *)(pbStack_c0 + uVar12) == 5) {
            uStack_c6 = uStack_c6 | 2;
            uStack_ac = uStack_ac - 1;
            uStack_9e = (undefined2)uVar12;
            uVar3 = *(ushort *)(pbStack_c0 + (ulonglong)(uVar12 & 0xffff) + 2);
            uVar10 = uStack_9c & 0xc7ff;
            if ((uVar3 & 0x4000) != 0) {
              uVar10 = (uStack_9c ^ uVar3) & 0x3800 ^ uStack_9c;
            }
            uStack_9c = (uVar10 ^ uVar3) & 0x7ff ^ uVar10;
            break;
          }
          if (*(ushort *)(pbStack_c0 + uVar12) < 0x400) break;
          uStack_c6 = uStack_c6 | 1;
          uStack_ac = uStack_ac - 1;
        } while (uStack_ac != 0);
      }
      if ((*pbStack_c0 & 0x40) == 0) {
        uStack_a2 = 0;
        uStack_a0 = 0;
      }
      else {
        uStack_a2 = (undefined2)uVar14;
        uStack_a0 = (undefined2)(uVar14 >> 0x10);
        uStack_c4 = (int)uVar14 + 0xe;
        puVar5 = (ulonglong *)func_0x(&uStack_c6);
        iVar4 = 0;
        uVar14 = *puVar5;
        uVar10 = (ushort)(uVar14 >> 0x30);
        uVar3 = uVar10;
        if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
          uVar3 = uVar10 & 0xdfff;
          if ((uVar14 & 0x4000000000000000) != 0) {
            uVar3 = uVar10 | 0x2000;
          }
        }
        if (uVar3 == 0xfffc) {
          iVar4 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
        }
        uStack_c4 = uStack_c4 + iVar4;
        uVar14 = (ulonglong)uStack_c4;
      }
      uVar13 = (uint)uVar14;
      if ((pbStack_aa != (byte *)0x0) && (pbStack_aa < pbStack_c0 + uVar14)) {
        if (((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
           (((lVar8 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                       (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0 &&
             (lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0)) &&
            (*(char *)(lVar8 + 0x499) != '\0')))) {
          if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
            (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3fa);
          }
          else {
            in_stack_ffffffffffffff08 = 0;
            (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x877,0);
          }
        }
        func_0x(pbStack_c0,0x12);
        uVar13 = uStack_c4;
      }
      if (0x3f3b < uVar13 - 1) {
        if (((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
           ((lVar8 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                        (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                      (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0 &&
            ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))
            )))) {
          if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
            (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3ed);
          }
          else {
            in_stack_ffffffffffffff08 = 0;
            (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x87c,0);
          }
        }
        func_0x(pbStack_c0,5);
        uVar13 = uStack_c4;
      }
    }
code_r0x001008ab:
    if (8 < uVar13) goto code_r0x001008ec;
    bVar7 = *pbStack_c0 & 0xe;
  }
  if ((bVar7 == 0) || (bVar7 == 0xc)) {
    uVar13 = 9;
  }
code_r0x001008ec:
  psVar6 = psStack_50;
  uVar17 = (uint)((ulonglong)in_stack_ffffffffffffff08 >> 0x20);
  puVar16 = (ushort *)(psStack_50 + 1);
  if (*psStack_50 == 0) {
    if (*(int *)(psStack_50 + 2) == 0) {
      pbVar18 = *(byte **)(psStack_50 + 4);
      uVar12 = *(uint *)(psStack_50 + 8);
      uVar14 = (ulonglong)uVar12;
      *puVar16 = 0;
      *(uint *)(psStack_50 + 10) = uVar12;
      bVar7 = *pbVar18;
      if ((bVar7 & 0x10) != 0) {
        uVar12 = uVar12 + 2 + (*(ushort *)(pbVar18 + uVar14) + 7 >> 3);
        uVar14 = (ulonglong)uVar12;
        *(uint *)(psStack_50 + 10) = uVar12;
        bVar7 = *pbVar18;
      }
      if ((bVar7 & 0x20) == 0) {
        *(int *)(psStack_50 + 2) = (int)uVar14;
        psStack_50[0xe] = 0;
        *(int *)(psStack_50 + 0xc) = (int)uVar14;
      }
      else {
        puVar19 = (ushort *)(pbVar18 + uVar14);
        uVar3 = *puVar19;
        psStack_50[0xe] = uVar3;
        if (uVar3 == 0) {
          if ((((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                        (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
              (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3eb);
            }
            else {
              in_stack_ffffffffffffff08 = 0;
              (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(psVar6 + 4),3);
          uVar14 = (ulonglong)*(uint *)(psVar6 + 10);
          uVar3 = psVar6[0xe];
        }
        uVar17 = (int)uVar14 + (uVar3 + 1) * 2;
        *(uint *)(psVar6 + 0xc) = uVar17;
        if (0x1f9e < uVar17) {
          if (((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
             ((lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                        (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0 &&
              ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 &&
               (*(char *)(lVar8 + 0x499) != '\0')))))) {
            if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
              (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3ec);
            }
            else {
              in_stack_ffffffffffffff08 = 0;
              (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(psVar6 + 4),4);
          uVar3 = psVar6[0xe];
          uVar17 = *(uint *)(psVar6 + 0xc);
        }
        uVar14 = (ulonglong)uVar3;
        uVar12 = puVar19[uVar14] & 0x7fff;
        *(uint *)(psVar6 + 2) = uVar12;
        if (uVar12 < uVar17) {
          if ((((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
              (lVar8 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                        (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0)) &&
             ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
              ))) {
            if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
              (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3ec);
            }
            else {
              in_stack_ffffffffffffff08 = 0;
              (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(psVar6 + 4),4);
          uVar14 = (ulonglong)(ushort)psVar6[0xe];
          uVar12 = *(uint *)(psVar6 + 2);
        }
        uVar17 = (uint)((ulonglong)in_stack_ffffffffffffff08 >> 0x20);
        if ((short)puVar19[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
          lVar8 = *(longlong *)(psVar6 + 4);
          do {
            if ((int)uVar14 == 1) {
              uVar15 = *(uint *)(psVar6 + 0xc);
              uVar12 = uVar15;
code_r0x00100be7:
              if ((*(ushort *)((ulonglong)*(uint *)(psVar6 + 10) + lVar8 + uVar14 * 2) & 0x7fff) <
                  uVar15) goto code_r0x00100bf4;
            }
            else {
              uVar12 = *(uint *)(psVar6 + 0xc);
              uVar15 = *(ushort *)((ulonglong)*(uint *)(psVar6 + 10) + lVar8 + -2 + uVar14 * 2) &
                       0x7fff;
              if (uVar12 <= uVar15) goto code_r0x00100be7;
code_r0x00100bf4:
              func_0x(lVar8,7);
              uVar12 = *(uint *)(psVar6 + 0xc);
            }
            uVar17 = (uint)((ulonglong)in_stack_ffffffffffffff08 >> 0x20);
            if ((uVar15 < uVar12) || (uVar12 = *(uint *)(psVar6 + 2), uVar12 < uVar15))
            goto code_r0x00100ee8;
            lVar8 = *(longlong *)(psVar6 + 4);
            if (*(ushort *)((ulonglong)uVar15 + lVar8) == 5) {
              *puVar16 = *puVar16 | 2;
              psVar6[0xe] = psVar6[0xe] + -1;
              psVar6[0x15] = (short)uVar15;
              lVar8 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(psVar6 + 4);
              uVar3 = psVar6[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar8 + 2) & 0x4000) != 0) {
                uVar3 = *(ushort *)(lVar8 + 2) & 0x3800 | psVar6[0x16] & 0xc7ffU;
              }
              psVar6[0x16] = uVar3;
              psVar6[0x16] = (uVar3 ^ *(ushort *)(lVar8 + 2)) & 0x7ff ^ uVar3;
              uVar14 = (ulonglong)*(uint *)(psVar6 + 2);
              pbVar18 = *(byte **)(psVar6 + 4);
              goto code_r0x00100ce4;
            }
            if (*(ushort *)((ulonglong)uVar15 + lVar8) < 0x400) break;
            sVar9 = psVar6[0xe];
            *puVar16 = *puVar16 | 1;
            uVar3 = sVar9 - 1;
            psVar6[0xe] = uVar3;
            if ((uVar3 == 0) ||
               (uVar14 = (ulonglong)uVar3, -1 < (short)puVar19[(ulonglong)(uVar3 - 1) + 1])) break;
          } while( true );
        }
        uVar14 = (ulonglong)uVar12;
        pbVar18 = *(byte **)(psVar6 + 4);
      }
code_r0x00100ce4:
      iVar4 = 0;
      if ((*pbVar18 & 0x40) == 0) {
        *(undefined4 *)(psVar6 + 0x13) = 0;
      }
      else {
        *(int *)(psVar6 + 0x13) = (int)uVar14;
        *(int *)(psVar6 + 2) = (int)uVar14 + 0xe;
        puVar5 = (ulonglong *)func_0x(puVar16);
        uVar14 = *puVar5;
        uVar10 = (ushort)(uVar14 >> 0x30);
        uVar3 = uVar10;
        if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
          uVar3 = uVar10 & 0xdfff;
          if ((uVar14 & 0x4000000000000000) != 0) {
            uVar3 = uVar10 | 0x2000;
          }
        }
        if (uVar3 == 0xfffc) {
          iVar4 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar4;
        uVar14 = (ulonglong)*(uint *)(psVar6 + 2);
      }
      iVar4 = (int)uVar14;
      if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
         (*(ulonglong *)(psVar6 + 0xf) < uVar14 + *(longlong *)(psVar6 + 4))) {
        if (((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
           (((lVar8 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                       (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0 &&
             (lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0)) &&
            (*(char *)(lVar8 + 0x499) != '\0')))) {
          if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
            (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uVar17 = 0;
            (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(psVar6 + 4),0x12);
        iVar4 = *(int *)(psVar6 + 2);
      }
      if (0x3f3b < iVar4 - 1U) {
        if (((cRam0000000001a3092b != '\0') || ((bRam0000000001a41230 & 1) != 0)) &&
           ((lVar8 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                        (ulonglong)*puRam0000000000f9f1b8 * 8) + 8 +
                      (ulonglong)*puRam0000000000f9f1c0), lVar8 != 0 &&
            ((lVar8 = *(longlong *)(lVar8 + 0x60), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))
            )))) {
          if ((cRam0000000001a3081b == '\0') && ((bRam0000000001a41230 & 2) == 0)) {
            (*pcRam0000000000f9f158)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uVar17 = 0;
            (*pcRam0000000000f9f150)(1,0x1321358,0x1441028,0x87c,0);
          }
        }
        func_0x(*(undefined8 *)(psVar6 + 4),5);
      }
    }
code_r0x00100ee8:
    uVar12 = *(uint *)(psVar6 + 2);
    if ((uVar12 < 9) &&
       (((**(byte **)(psVar6 + 4) & 0xe) == 0 || ((**(byte **)(psVar6 + 4) & 0xe) == 0xc)))) {
      uVar12 = 9;
    }
  }
  else {
    uVar12 = *(uint *)(psStack_50 + 2);
    if (uVar12 == 0) {
      func_0x(puVar16);
      uVar12 = *(uint *)(psVar6 + 2);
    }
    if ((uVar12 < 9) &&
       (((**(byte **)(psVar6 + 4) & 0x1c) == 0 || ((**(byte **)(psVar6 + 4) & 0x1c) == 0xc)))) {
      uVar12 = 9;
    }
  }
  sVar9 = 2;
  *(ushort *)(param_1 + 4) = *(ushort *)(param_1 + 4) & 0xfffb;
  psVar6 = asStackX_8;
  lVar8 = (ulonglong)uVar17 << 0x20;
  uVar17 = uStackX_18;
  iVar4 = func_0x
                    (param_1,iStackX_10,uVar13,uVar12,lVar8,aiStack_58,psVar6,uStackX_18,param_6);
  uVar20 = (undefined4)((ulonglong)lVar8 >> 0x20);
  uVar21 = (undefined4)((ulonglong)psVar6 >> 0x20);
  uVar22 = (undefined2)(uVar17 >> 0x10);
  if (iVar4 == 0) {
    if (asStackX_8[0] != 0) {
      uVar3 = *(ushort *)(param_1 + 0x16);
      sVar11 = 0;
      lVar8 = (ulonglong)uVar3 - 1;
      if ((longlong)(ulonglong)(ushort)(uVar3 - asStackX_8[0]) <= lVar8) {
        psVar6 = (short *)(param_1 + (0xfff - lVar8) * 2);
        do {
          if (*psVar6 != 0) break;
          sVar11 = sVar11 + 1;
          lVar8 = lVar8 + -1;
          psVar6 = psVar6 + 1;
        } while ((longlong)(ulonglong)(ushort)(uVar3 - asStackX_8[0]) <= lVar8);
      }
      *(short *)(param_1 + 0x1c) = *(short *)(param_1 + 0x1c) + sVar11 * 2;
      *(ushort *)(param_1 + 0x16) = uVar3 - sVar11;
    }
    if (aiStack_58[0] != 0) {
      func_0x(param_1,iStackX_10);
    }
  }
  else {
    uVar20 = 0;
    (*pcRam0000000000f9f150)(1,0x14cfc58,0x14a62a8,0xaff,0);
  }
  uVar17 = uStackX_18;
  func_0x
            (param_1,iStackX_10,0,uVar13,CONCAT44(uVar20,uVar12),*(undefined8 *)(psStack_50 + 4),
             CONCAT44(uVar21,uStackX_18),CONCAT22(uVar22,param_5),param_6);
  pbStack_88 = (byte *)((ulonglong)*puStack_48 + param_1);
  bVar7 = *pbStack_88;
  if ((bVar7 & 1) == 0) {
    bVar1 = bVar7 >> 6;
  }
  else {
    bVar1 = bVar7 >> 1;
  }
  if ((bVar1 & 1) != 0) {
    if ((uVar17 & 0x40) != 0) {
      uStack_8c = 0;
      uStack_72 = 0;
      uStack_68 = 0;
      uStack_66 = 0;
      uStack_80 = 0;
      if ((bVar7 & 1) == 0) {
        uStack_90 = 0;
        uStack_6a = 0;
        uStack_68 = 0;
        uVar13 = (uint)*(ushort *)(param_1 + 0xe);
        switch(bVar7 & 0xe) {
        default:
          uVar13 = (uint)*(ushort *)(pbStack_88 + 2);
          if (0x1f9d < *(ushort *)(pbStack_88 + 2) - 1) {
            func_0x(pbStack_88,6);
          }
          break;
        case 4:
          uVar13 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar13 = 1;
        }
        uStack_80 = CONCAT44(uStack_80._4_4_,uVar13);
      }
      else {
        uStack_90 = 1;
        switch(bVar7 & 0x1c) {
        default:
          if ((char)pbStack_88[1] < '\0') {
            uStack_8e = (*(ushort *)(pbStack_88 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_88 + 1) >> 8
            ;
            uStack_78 = 3;
            sVar9 = 3;
          }
          else {
            uStack_8e = (ushort)pbStack_88[1];
            uStack_78 = 2;
          }
          sStack_74 = ((ushort)(uStack_8e + 1) >> 1) + sVar9;
          if (uStack_8e < 0x1f) {
            uStack_60 = 0;
          }
          else {
            iVar4 = uStack_8e - 1;
            uStack_60 = 0;
            uStack_78 = CONCAT22(((short)(iVar4 / 0x1e) + (short)(iVar4 >> 0x1f)) -
                                 (short)((longlong)iVar4 * 0x88888889 >> 0x3f),(undefined2)uStack_78
                                );
          }
          break;
        case 4:
          if (((bVar7 & 0x1c) == 4) && ((bVar7 & 2) != 0)) {
            uStack_78 = 0;
            uStack_8e = 0;
            sStack_74 = 0;
            uStack_6a = 0;
            uStack_8c = 0xf;
            uStack_60 = 1;
          }
          else {
            uStack_78 = 0;
            uStack_8e = 0;
            sStack_74 = 0;
            uStack_6a = 0;
            uStack_8c = 1;
            uStack_60 = 0;
          }
          break;
        case 8:
          uStack_78 = 0;
          uStack_8e = 0;
          sStack_74 = 0;
          uStack_6a = 0;
          uStack_8c = 9;
          uStack_60 = 0;
        }
      }
      func_0x(&uStack_90);
    }
    if ((*(ushort *)(param_1 + 4) & 0x2000) == 0) {
      *(ushort *)(param_1 + 4) = *(ushort *)(param_1 + 4) | 0x2000;
    }
  }
  return;
}

