
/* WARNING: Removing unreachable block (ram,0x00100d97) */
/* WARNING: Removing unreachable block (ram,0x00100da7) */
/* WARNING: Removing unreachable block (ram,0x00100db0) */
/* WARNING: Removing unreachable block (ram,0x00100dbd) */
/* WARNING: Removing unreachable block (ram,0x00100de6) */
/* WARNING: Removing unreachable block (ram,0x00100def) */
/* WARNING: Removing unreachable block (ram,0x00100df8) */
/* WARNING: Removing unreachable block (ram,0x00100e01) */
/* WARNING: Removing unreachable block (ram,0x00100e24) */
/* WARNING: Removing unreachable block (ram,0x00100e0a) */
/* WARNING: Removing unreachable block (ram,0x00100e48) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong param_3)

{
  undefined4 uVar1;
  longlong *plVar2;
  byte *pbVar3;
  code *pcVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  int iVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong lVar11;
  ulonglong *puVar12;
  ulonglong uVar13;
  ushort uVar14;
  uint uVar15;
  ulonglong uVar16;
  uint uVar17;
  uint uVar18;
  longlong lVar19;
  ushort *puVar20;
  ulonglong uVar21;
  ushort uVar22;
  longlong unaff_GS_OFFSET;
  undefined8 uStackX_8;
  uint uStackX_10;
  ushort uStackX_14;
  ulonglong uStackX_16;
  ushort uStack_1654;
  undefined2 auStack_1638 [2];
  undefined4 uStack_1634;
  undefined8 uStack_1630;
  undefined8 uStack_1628;
  undefined8 uStack_161a;
  undefined8 uStack_1610;
  undefined auStack_15f8 [2];
  undefined2 uStack_15f6;
  undefined2 uStack_15ea;
  undefined4 uStack_15e8;
  undefined2 uStack_15e4;
  undefined2 uStack_15e2;
  undefined4 uStack_15e0;
  longlong lStack_15dc;
  ushort uStack_15d4;
  undefined2 auStack_15d2 [69];
  undefined auStack_1548 [16];
  int iStack_1538;
  uint uStack_1534;
  uint uStack_1530;
  undefined *puStack_1528;
  undefined8 uStack_1520;
  undefined8 uStack_1518;
  undefined auStack_1508 [2656];
  undefined auStack_aa8 [2656];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x100022;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar8);
  plVar2 = (longlong *)param_2[1];
  uVar16 = 0;
  uStack_15e8 = 0;
  *(undefined2 *)(&stack0xfffffffffffffff8 + lVar8) = 0xffff;
  *(undefined2 *)(&stack0x00000030 + lVar8) = 0xffff;
  auStack_1638[0] = 0xffff;
  lVar11 = *param_2;
  uStack_15e4 = 0;
  uStack_15d4 = 0;
  *(undefined8 *)(&stack0x00000000 + lVar8) = 0;
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar8) = 0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar8 + 2) = 0;
  *(undefined8 *)(&stack0x00000020 + lVar8) = 0;
  *(undefined8 *)((longlong)&uStackX_8 + lVar8) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar8) = 0;
  *(undefined4 *)(&stack0x00000034 + lVar8) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar8) = 0;
  uStack_1630 = 0;
  uStack_1634 = 0;
  uStack_161a = 0;
  uStack_1610 = 0;
  uStack_1628 = 0;
  uVar18 = *(uint *)(**(longlong **)(*(longlong *)(lVar11 + 8) + 0x160) + 0x1c);
  lVar11 = *(longlong *)(param_1 + 0x58);
  if ((lVar11 == 0) || (*(uint *)(lVar11 + 0xc) < uVar18)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1000d1;
    (*_DAT_)(lVar11,0x18);
    *(undefined8 *)(param_1 + 0x58) = 0;
    uVar9 = *(undefined8 *)(param_3 + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1000e4;
    func_0x(uVar9,uVar18,param_1 + 0x58);
    uVar9 = *(undefined8 *)(param_1 + 0x58);
    lVar11 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1000f0;
    func_0x(lVar11,uVar9);
  }
  if (*(int *)(param_1 + 0x68) == 0) {
    uVar9 = *(undefined8 *)(param_3 + 8);
    (&stack0xffffffffffffffe8)[lVar8] = 5;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100117;
    uVar9 = (*_DAT_)(0xa58,uVar9,0x153c5a8,0x71c8);
    *(undefined8 *)(param_1 + 0x60) = uVar9;
    *(undefined4 *)(param_1 + 0x68) = 0xa58;
  }
  if (*(char *)(param_1 + 0x6c) != '\0') {
    plVar10 = *(longlong **)(param_1 + 0x58);
    if (*(int *)(plVar10 + 2) == *(int *)(*(longlong *)(param_1 + 0x28) + 0x10)) {
      if (((*(int *)(plVar10 + 2) != 2) &&
          (*(int *)(plVar10 + 1) == *(int *)(*(longlong *)(param_1 + 0x28) + 8))) &&
         (*(int *)(plVar10 + 1) != 0)) {
        do {
          lVar19 = *plVar10 + uVar16 * 0x10;
          uVar1 = *(undefined4 *)(lVar19 + 8);
          uVar9 = **(undefined8 **)(*(longlong *)(*param_2 + 8) + 0x160);
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100185;
          uVar9 = func_0x(uVar9,uVar1);
          lVar11 = **(longlong **)(param_1 + 0x28);
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10019a;
          iVar7 = func_0x(lVar19,lVar11 + uVar16 * 0x10,uVar9);
          if (iVar7 != 1) goto LAB_;
          plVar10 = *(longlong **)(param_1 + 0x58);
          uVar18 = (int)uVar16 + 1;
          uVar16 = (ulonglong)uVar18;
        } while (uVar18 < *(uint *)(plVar10 + 1));
      }
      goto LAB_;
    }
  }
LAB_:
  lVar11 = *param_2;
  uVar9 = *(undefined8 *)(param_1 + 0x40);
  uStack_15ea = 0;
  lStack_15dc = (ulonglong)*(uint6 *)(lVar11 + 0x14) << 0x10;
  uStack_15e0 = 3;
  if (*(char *)(param_1 + 0x3c) != '\0') {
    uStack_15e0 = 1;
  }
  uStack_15e2 = 0xdc;
  uStack_15f6 = 0x24;
  *(undefined **)(&stack0xfffffffffffffff0 + lVar8) = &stack0xfffffffffffffff8 + lVar8;
  *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100215;
  func_0x(lVar11,auStack_1638,uVar9,auStack_1508);
  uStack_1534 = *(uint *)(&stack0xfffffffffffffffc + lVar8);
  if (*(short *)(&stack0xfffffffffffffff8 + lVar8) == 0) {
    if (uStack_1534 == 0) {
      pbVar3 = *(byte **)(&stack0x00000000 + lVar8);
      uVar18 = *(uint *)((longlong)&uStackX_8 + lVar8);
      uVar16 = (ulonglong)uVar18;
      *(undefined2 *)(&stack0xfffffffffffffffa + lVar8) = 0;
      *(uint *)((longlong)&uStackX_8 + lVar8 + 4) = uVar18;
      if ((*pbVar3 & 0x10) != 0) {
        uVar18 = uVar18 + 2 + (*(ushort *)(pbVar3 + uVar16) + 7 >> 3);
        uVar16 = (ulonglong)uVar18;
        *(uint *)((longlong)&uStackX_8 + lVar8 + 4) = uVar18;
      }
      if ((**(byte **)(&stack0x00000000 + lVar8) & 0x20) == 0) {
        *(int *)(&stack0xfffffffffffffffc + lVar8) = (int)uVar16;
        *(undefined2 *)((longlong)&uStackX_14 + lVar8) = 0;
        *(int *)((longlong)&uStackX_10 + lVar8) = (int)uVar16;
      }
      else {
        puVar20 = (ushort *)(*(byte **)(&stack0x00000000 + lVar8) + uVar16);
        uVar22 = *puVar20;
        *(ushort *)((longlong)&uStackX_14 + lVar8) = uVar22;
        if (uVar22 == 0) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1002fd;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100320;
              (*_DAT_)(1,0x17a5ae8,0x18c57b8,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10032f;
          func_0x(*(undefined8 *)(&stack0x00000000 + lVar8),3);
          uVar22 = *(ushort *)((longlong)&uStackX_14 + lVar8);
        }
        uVar18 = *(int *)((longlong)&uStackX_8 + lVar8 + 4) + 2 + (uint)uVar22 * 2;
        *(uint *)((longlong)&uStackX_10 + lVar8) = uVar18;
        if (0x1f9e < uVar18) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1003d0;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1003f3;
              (*_DAT_)(1,0x17a5ae8,0x18c57b8,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100402;
          func_0x(*(undefined8 *)(&stack0x00000000 + lVar8),4);
          uVar22 = *(ushort *)((longlong)&uStackX_14 + lVar8);
          uVar18 = *(uint *)((longlong)&uStackX_10 + lVar8);
        }
        uVar21 = (ulonglong)uVar22;
        uVar15 = puVar20[uVar21] & 0x7fff;
        uVar16 = (ulonglong)uVar15;
        *(uint *)(&stack0xfffffffffffffffc + lVar8) = uVar15;
        if (uVar15 < uVar18) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar11 != 0 &&
              ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
               (*(char *)(lVar11 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1004a2;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1004c5;
              (*_DAT_)(1,0x17a5ae8,0x18c57b8,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1004d4;
          func_0x(*(undefined8 *)(&stack0x00000000 + lVar8),4);
          uVar21 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar8);
          uVar18 = *(uint *)((longlong)&uStackX_10 + lVar8);
          uVar16 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar8);
        }
        do {
          if (-1 < (short)puVar20[(ulonglong)((int)uVar21 - 1) + 1]) break;
          lVar11 = (ulonglong)*(uint *)((longlong)&uStackX_8 + lVar8 + 4) +
                   *(longlong *)(&stack0x00000000 + lVar8);
          if ((int)uVar21 == 1) {
            uVar13 = 1;
            uVar15 = uVar18;
LAB_:
            if ((*(ushort *)(lVar11 + uVar13 * 2) & 0x7fff) < uVar15) goto LAB_;
          }
          else {
            uVar15 = *(ushort *)(lVar11 + -2 + uVar21 * 2) & 0x7fff;
            uVar13 = uVar21;
            if (uVar18 <= uVar15) goto LAB_;
LAB_:
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10054b;
            func_0x(*(undefined8 *)(&stack0x00000000 + lVar8),7);
            uVar21 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar8);
            uVar18 = *(uint *)((longlong)&uStackX_10 + lVar8);
            uVar16 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar8);
          }
          uStack_1534 = (uint)uVar16;
          if ((uVar15 < uVar18) || (uStack_1534 < uVar15)) goto LAB_;
          if (*(ushort *)((ulonglong)uVar15 + *(longlong *)(&stack0x00000000 + lVar8)) == 5) {
            *(ushort *)(&stack0xfffffffffffffffa + lVar8) =
                 *(ushort *)(&stack0xfffffffffffffffa + lVar8) | 2;
            uVar22 = *(ushort *)(&stack0x00000024 + lVar8);
            *(short *)(&stack0x00000022 + lVar8) = (short)uVar15;
            lVar11 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(&stack0x00000000 + lVar8);
            *(short *)((longlong)&uStackX_14 + lVar8) = (short)uVar21 + -1;
            uVar14 = *(ushort *)(lVar11 + 2);
            if ((uVar14 & 0x4000) == 0) {
              uVar22 = uVar22 & 0xc7ff;
            }
            else {
              uVar22 = uVar22 ^ (uVar22 ^ uVar14) & 0x3800;
            }
            *(ushort *)(&stack0x00000024 + lVar8) = uVar22;
            *(ushort *)(&stack0x00000024 + lVar8) =
                 (uVar22 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar22;
            break;
          }
          if (*(ushort *)((ulonglong)uVar15 + *(longlong *)(&stack0x00000000 + lVar8)) < 0x400)
          break;
          *(ushort *)(&stack0xfffffffffffffffa + lVar8) =
               *(ushort *)(&stack0xfffffffffffffffa + lVar8) | 1;
          uVar22 = (short)uVar21 - 1;
          uVar21 = (ulonglong)uVar22;
          *(ushort *)((longlong)&uStackX_14 + lVar8) = uVar22;
        } while (uVar22 != 0);
      }
      iVar7 = 0;
      if ((**(byte **)(&stack0x00000000 + lVar8) & 0x40) == 0) {
        *(undefined4 *)(&stack0x0000001e + lVar8) = 0;
      }
      else {
        *(int *)(&stack0x0000001e + lVar8) = (int)uVar16;
        *(int *)(&stack0xfffffffffffffffc + lVar8) = (int)uVar16 + 0xe;
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1005d5;
        puVar12 = (ulonglong *)func_0x(&stack0xfffffffffffffffa + lVar8);
        uVar16 = *puVar12;
        uVar14 = (ushort)(uVar16 >> 0x30);
        uVar22 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar22 = uVar14 & 0xdfff;
          if ((uVar16 & 0x4000000000000000) != 0) {
            uVar22 = uVar14 | 0x2000;
          }
        }
        if (uVar22 == 0xfffc) {
          iVar7 = (int)((uVar16 >> 0x20 & 0xffff) >> 5);
        }
        uVar16 = (ulonglong)(uint)(*(int *)(&stack0xfffffffffffffffc + lVar8) + iVar7);
        *(int *)(&stack0xfffffffffffffffc + lVar8) =
             *(int *)(&stack0xfffffffffffffffc + lVar8) + iVar7;
      }
      uStack_1534 = (uint)uVar16;
      uVar21 = *(ulonglong *)((longlong)&uStackX_14 + lVar8 + 2);
      if ((uVar21 != 0) && (uVar21 < uVar16 + *(longlong *)(&stack0x00000000 + lVar8))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar11 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar11 != 0 &&
             (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100764;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100787;
            (*_DAT_)(1,0x17a5ae8,0x18c57b8,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100796;
        func_0x(*(undefined8 *)(&stack0x00000000 + lVar8),0x12);
        uStack_1534 = *(uint *)(&stack0xfffffffffffffffc + lVar8);
      }
      if (0x3f3b < uStack_1534 - 1) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar11 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar11 != 0 &&
            ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
             (*(char *)(lVar11 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100823;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100846;
            (*_DAT_)(1,0x17a5ae8,0x18c57b8,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100855;
        func_0x(*(undefined8 *)(&stack0x00000000 + lVar8),5);
        uStack_1534 = *(uint *)(&stack0xfffffffffffffffc + lVar8);
      }
    }
LAB_:
    if ((uStack_1534 < 9) &&
       (((**(byte **)(&stack0x00000000 + lVar8) & 0xe) == 0 ||
        ((**(byte **)(&stack0x00000000 + lVar8) & 0xe) == 0xc)))) {
      uStack_1534 = 9;
    }
  }
  else {
    if (uStack_1534 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10088b;
      func_0x(&stack0xfffffffffffffffa + lVar8);
      uStack_1534 = *(uint *)(&stack0xfffffffffffffffc + lVar8);
    }
    if ((uStack_1534 < 9) &&
       (((**(byte **)(&stack0x00000000 + lVar8) & 0x1c) == 0 ||
        ((**(byte **)(&stack0x00000000 + lVar8) & 0x1c) == 0xc)))) {
      uStack_1534 = 9;
    }
  }
  uVar18 = 9;
  uStack_1520 = *(undefined8 *)(&stack0x00000000 + lVar8);
  auStack_15d2[uStack_15d4] = (short)uStack_1534;
  uVar9 = 2;
  uStack_15d4 = uStack_15d4 + 1;
  if (*(char *)(param_1 + 0x3c) == '\0') {
    uVar9 = *(undefined8 *)(param_1 + 0x28);
    lVar11 = *param_2;
    *(undefined **)(&stack0xfffffffffffffff0 + lVar8) = &stack0x00000030 + lVar8;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100903;
    func_0x(lVar11,auStack_1638,uVar9,auStack_aa8);
    uStack_1530 = uVar18;
    if (*(short *)(&stack0x00000030 + lVar8) == 0) {
      uVar18 = *(uint *)(&stack0x00000034 + lVar8);
      if (uVar18 == 0) {
        uVar18 = *(uint *)(&stack0x00000040 + lVar8);
        uVar16 = (ulonglong)uVar18;
        *(undefined2 *)(&stack0x00000032 + lVar8) = 0;
        *(uint *)(&stack0x00000044 + lVar8) = uVar18;
        if ((**(byte **)(&stack0x00000038 + lVar8) & 0x10) != 0) {
          uVar18 = uVar18 + 2 +
                   (*(ushort *)(*(byte **)(&stack0x00000038 + lVar8) + uVar16) + 7 >> 3);
          uVar16 = (ulonglong)uVar18;
          *(uint *)(&stack0x00000044 + lVar8) = uVar18;
        }
        if ((**(byte **)(&stack0x00000038 + lVar8) & 0x20) == 0) {
          *(int *)(&stack0x00000034 + lVar8) = (int)uVar16;
        }
        else {
          puVar20 = (ushort *)(*(byte **)(&stack0x00000038 + lVar8) + uVar16);
          uStack_1654 = *puVar20;
          if (uStack_1654 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1009ea;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100a0d;
                (*_DAT_)(1,0x17a5ae8,0x18c57b8,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100a1c;
            func_0x(*(undefined8 *)(&stack0x00000038 + lVar8),3);
          }
          uVar15 = *(int *)(&stack0x00000044 + lVar8) + 2 + (uint)uStack_1654 * 2;
          if (0x1f9e < uVar15) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar11 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar11 != 0 &&
                ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                 (*(char *)(lVar11 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100abc;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100adf;
                (*_DAT_)(1,0x17a5ae8,0x18c57b8,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100aee;
            func_0x(*(undefined8 *)(&stack0x00000038 + lVar8),4);
          }
          uVar21 = (ulonglong)uStack_1654;
          uVar18 = puVar20[uVar21] & 0x7fff;
          uVar16 = (ulonglong)uVar18;
          *(uint *)(&stack0x00000034 + lVar8) = uVar18;
          if (uVar18 < uVar15) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar11 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar11 != 0)) &&
               ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100b8d;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100bb0;
                (*_DAT_)(1,0x17a5ae8,0x18c57b8,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100bbf;
            func_0x(*(undefined8 *)(&stack0x00000038 + lVar8),4);
            uVar21 = (ulonglong)uStack_1654;
            uVar16 = (ulonglong)*(uint *)(&stack0x00000034 + lVar8);
          }
          do {
            if (-1 < (short)puVar20[(ulonglong)((int)uVar21 - 1) + 1]) break;
            if ((int)uVar21 == 1) {
              uVar13 = 1;
              uVar17 = uVar15;
LAB_:
              if ((*(ushort *)
                    ((ulonglong)*(uint *)(&stack0x00000044 + lVar8) +
                     *(longlong *)(&stack0x00000038 + lVar8) + uVar13 * 2) & 0x7fff) < uVar17)
              goto LAB_;
            }
            else {
              uVar17 = *(ushort *)
                        ((ulonglong)*(uint *)(&stack0x00000044 + lVar8) +
                         *(longlong *)(&stack0x00000038 + lVar8) + -2 + uVar21 * 2) & 0x7fff;
              uVar13 = uVar21;
              if (uVar15 <= uVar17) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100c2b;
              func_0x(*(undefined8 *)(&stack0x00000038 + lVar8),7);
              uVar21 = (ulonglong)uStack_1654;
              uVar16 = (ulonglong)*(uint *)(&stack0x00000034 + lVar8);
            }
            uVar18 = (uint)uVar16;
            if ((uVar17 < uVar15) || (uVar18 < uVar17)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar17 + *(longlong *)(&stack0x00000038 + lVar8)) == 5) {
              *(ushort *)(&stack0x00000032 + lVar8) = *(ushort *)(&stack0x00000032 + lVar8) | 2;
              goto LAB_;
            }
            if (*(ushort *)((ulonglong)uVar17 + *(longlong *)(&stack0x00000038 + lVar8)) < 0x400)
            break;
            *(ushort *)(&stack0x00000032 + lVar8) = *(ushort *)(&stack0x00000032 + lVar8) | 1;
            uStack_1654 = (short)uVar21 - 1;
            uVar21 = (ulonglong)uStack_1654;
          } while (uStack_1654 != 0);
        }
        uVar18 = (uint)uVar16;
LAB_:
        iVar7 = 0;
        if ((**(byte **)(&stack0x00000038 + lVar8) & 0x40) != 0) {
          *(uint *)(&stack0x00000034 + lVar8) = uVar18 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100d24;
          puVar12 = (ulonglong *)func_0x(&stack0x00000032 + lVar8);
          uVar16 = *puVar12;
          uVar14 = (ushort)(uVar16 >> 0x30);
          uVar22 = uVar14;
          if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
            uVar22 = uVar14 & 0xdfff;
            if ((uVar16 & 0x4000000000000000) != 0) {
              uVar22 = uVar14 | 0x2000;
            }
          }
          if (uVar22 == 0xfffc) {
            iVar7 = (int)((uVar16 >> 0x20 & 0xffff) >> 5);
          }
          uVar18 = *(int *)(&stack0x00000034 + lVar8) + iVar7;
          *(uint *)(&stack0x00000034 + lVar8) = uVar18;
        }
        if (0x3f3b < uVar18 - 1) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar11 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar11 != 0)) &&
             ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
              (*(char *)(lVar11 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100ee4;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100f0a;
              (*_DAT_)(1,0x17a5ae8,0x18c57b8,0x87c);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100f19;
          func_0x(*(undefined8 *)(&stack0x00000038 + lVar8),5);
          uVar18 = *(uint *)(&stack0x00000034 + lVar8);
        }
      }
LAB_:
      if ((8 < uVar18) ||
         (((**(byte **)(&stack0x00000038 + lVar8) & 0xe) != 0 &&
          ((**(byte **)(&stack0x00000038 + lVar8) & 0xe) != 0xc)))) {
        uStack_1530 = uVar18;
      }
    }
    else {
      uVar18 = *(uint *)(&stack0x00000034 + lVar8);
      if (uVar18 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100f4a;
        func_0x(&stack0x00000032 + lVar8);
        uVar18 = *(uint *)(&stack0x00000034 + lVar8);
      }
      if ((8 < uVar18) ||
         (((**(byte **)(&stack0x00000038 + lVar8) & 0x1c) != 0 &&
          ((**(byte **)(&stack0x00000038 + lVar8) & 0x1c) != 0xc)))) {
        uStack_1530 = uVar18;
      }
    }
    uStack_1518 = *(undefined8 *)(&stack0x00000038 + lVar8);
    uVar9 = 3;
    auStack_15d2[uStack_15d4] = (short)uStack_1530;
    uStack_15d4 = uStack_15d4 + 1;
  }
  *(undefined **)(&stack0xffffffffffffffe8 + lVar8) = auStack_1548;
  iStack_1538 = (uint)uStack_15d4 * 2 + 0x26;
  puStack_1528 = auStack_15f8;
  pcVar4 = *(code **)(*plVar2 + 0x288);
  *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100fd4;
  (*pcVar4)(plVar2,uVar9,&iStack_1538,&puStack_1528);
  uVar1 = *(undefined4 *)(param_1 + 0x68);
  uVar9 = *(undefined8 *)(param_1 + 0x60);
  uVar5 = *(undefined8 *)(param_1 + 0x28);
  uVar6 = *(undefined8 *)(param_1 + 0x58);
  *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100fe9;
  func_0x(uVar6,uVar5,uVar9,uVar1);
  *(undefined *)(param_1 + 0x6c) = 1;
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100ffd;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar8));
  return;
}

