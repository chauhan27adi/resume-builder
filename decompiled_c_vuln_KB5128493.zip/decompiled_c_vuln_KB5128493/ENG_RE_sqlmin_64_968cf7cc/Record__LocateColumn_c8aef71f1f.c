// NOTE: 2 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

longlong FUN_(short *param_1,uint *param_2,undefined8 param_3,int param_4,
                     undefined4 *param_5,undefined8 param_6,undefined4 param_7)

{
  uint uVar1;
  byte *pbVar2;
  longlong *plVar3;
  code *pcVar4;
  int iVar5;
  longlong lVar6;
  uint uVar7;
  uint auStackX_8 [2];
  undefined auStack_38 [16];
  
  if (*param_1 != 0) {
    auStackX_8[0] = 0;
    lVar6 = func_0x(param_1 + 1,param_2,param_3,param_5,auStackX_8);
    if ((((*param_1 != 0) && (plVar3 = *(longlong **)(param_1 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) &&
       (((*(byte *)((longlong)param_2 + 6) & 8) == 0 && ((auStackX_8[0] & 1) == 0)))) {
      if ((lVar6 != 0) && (lVar6 != 0x24735b4)) {
        lVar6 = func_0x(plVar3,param_2,lVar6,*param_5,param_6,param_7,param_5,auStackX_8[0])
        ;
        return lVar6;
      }
      *param_5 = 0;
      lVar6 = 0;
    }
    return lVar6;
  }
  if ((*param_2 & 0xc0000000) == 0x80000000) {
    iVar5 = func_0x(param_1 + 1);
    if (iVar5 != 0) {
      lVar6 = func_0x(param_1 + 0x15,param_2,param_5,auStack_38);
      return lVar6;
    }
    *param_5 = 0;
    return 0;
  }
  if (param_4 != 0) {
    pbVar2 = *(byte **)(param_1 + 4);
    if ((*pbVar2 & 0x10) == 0) {
      pcVar4 = (code *)swi(3);
      lVar6 = (*pcVar4)();
      return lVar6;
    }
    uVar1 = *(uint *)(param_1 + 8);
    if ((int)*param_2 < (int)uVar1) {
      if ((uint)*(ushort *)(param_2 + 1) <= (uint)*(ushort *)(pbVar2 + uVar1)) {
        if (param_4 == 0) {
          pcVar4 = (code *)swi(3);
          lVar6 = (*pcVar4)();
          return lVar6;
        }
        uVar7 = *(ushort *)(param_2 + 1) - 1;
        if ((pbVar2[(ulonglong)uVar1 + (ulonglong)(uVar7 >> 3) + 2] >> ((byte)uVar7 & 7) & 1) == 0)
        {
          pcVar4 = (code *)swi(3);
          lVar6 = (*pcVar4)();
          return lVar6;
        }
        pcVar4 = (code *)swi(3);
        lVar6 = (*pcVar4)();
        return lVar6;
      }
    }
    pcVar4 = (code *)swi(3);
    lVar6 = (*pcVar4)();
    return lVar6;
  }
  pcVar4 = (code *)swi(3);
  lVar6 = (*pcVar4)();
  return lVar6;
}

