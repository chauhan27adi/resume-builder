
/* WARNING: Control flow encountered bad instruction data */

uint FUN_(longlong param_1,undefined8 *param_2,ulonglong *param_3,longlong *param_4)

{
  ushort uVar1;
  ushort uVar2;
  short *psVar3;
  byte *pbVar4;
  char cVar5;
  byte bVar6;
  short sVar7;
  uint uVar8;
  ulonglong uVar9;
  uint uVar10;
  ushort *puVar11;
  
  cVar5 = (**(code **)*param_2)(param_2);
  if (cVar5 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(param_1 + 0x24) & 0x25) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (0 < *(int *)(param_1 + 0x60)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *param_3 = 0;
  psVar3 = (short *)param_2[4];
  if (*psVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(psVar3 + 2) == 0) {
    pbVar4 = *(byte **)(psVar3 + 4);
    uVar8 = *(uint *)(psVar3 + 8);
    uVar9 = (ulonglong)uVar8;
    psVar3[1] = 0;
    *(uint *)(psVar3 + 10) = uVar8;
    bVar6 = *pbVar4;
    if ((bVar6 & 0x10) != 0) {
      uVar8 = uVar8 + 2 + (*(ushort *)(pbVar4 + uVar9) + 7 >> 3);
      uVar9 = (ulonglong)uVar8;
      *(uint *)(psVar3 + 10) = uVar8;
      bVar6 = *pbVar4;
    }
    if ((bVar6 & 0x20) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar11 = (ushort *)(pbVar4 + uVar9);
    uVar1 = *puVar11;
    psVar3[0xe] = uVar1;
    if (uVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar8 = (int)uVar9 + (uVar1 + 1) * 2;
    *(uint *)(psVar3 + 0xc) = uVar8;
    if (0x1f9e < uVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = puVar11[uVar1];
    *(uint *)(psVar3 + 2) = uVar2 & 0x7fff;
    if ((uVar2 & 0x7fff) < uVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((short)puVar11[(ulonglong)(uVar1 - 1) + 1] < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((**(byte **)(psVar3 + 4) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(psVar3 + 0x13) = 0;
    if ((*(ulonglong *)(psVar3 + 0xf) != 0) &&
       (*(ulonglong *)(psVar3 + 0xf) < (ulonglong)*(uint *)(psVar3 + 2) + *(longlong *)(psVar3 + 4))
       ) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (0x3f3b < *(uint *)(psVar3 + 2) - 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  sVar7 = -*(short *)(param_1 + 0x60);
  if ((*(byte *)(param_1 + 0x66) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((uint)(ushort)psVar3[0xe] < (uint)(int)sVar7) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar8 = *(ushort *)
           ((ulonglong)*(uint *)(psVar3 + 10) + *(longlong *)(psVar3 + 4) + (longlong)sVar7 * 2) &
          0x7fff;
  if (sVar7 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar10 = *(ushort *)
            ((ulonglong)*(uint *)(psVar3 + 10) + *(longlong *)(psVar3 + 4) + -2 +
            (longlong)sVar7 * 2) & 0x7fff;
  if ((*(uint *)(psVar3 + 0xc) <= uVar10) && (uVar10 <= uVar8)) {
    *(uint *)param_3 = uVar8 - uVar10;
    *param_4 = (ulonglong)uVar10 + *(longlong *)(psVar3 + 4);
    if (*param_3 <= (ulonglong)*(ushort *)(param_1 + 0x70)) {
      return *(uint *)(param_1 + 0x24) >> 6 & 1;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

