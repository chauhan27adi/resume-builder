
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,ushort **param_2,longlong param_3)

{
  short *psVar1;
  uint *puVar2;
  undefined4 uVar3;
  code *pcVar4;
  longlong *plVar5;
  undefined8 uVar6;
  uint6 uVar7;
  bool bVar8;
  bool bVar9;
  char cVar10;
  undefined2 uVar11;
  int iVar12;
  undefined4 uVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  undefined4 *puVar17;
  ushort *puVar18;
  undefined8 uVar19;
  undefined8 *puVar20;
  short *psVar21;
  byte bVar22;
  byte bVar23;
  ushort uVar24;
  uint uVar25;
  uint uVar26;
  undefined8 *puVar27;
  uint uVar28;
  int iVar29;
  byte *pbVar30;
  int *piVar31;
  uint uVar32;
  undefined8 unaff_RBX;
  uint *puVar33;
  undefined *puVar34;
  undefined *puVar35;
  ulonglong uVar36;
  uint uVar37;
  ushort *puVar38;
  ushort *puVar39;
  longlong lVar40;
  ushort uVar41;
  undefined8 *puVar42;
  undefined uVar43;
  ulonglong uVar44;
  longlong unaff_GS_OFFSET;
  bool bVar45;
  longlong *aplStackX_8 [2];
  ushort uStackX_18;
  ushort uStackX_1a;
  uint uStackX_1c;
  byte *pbStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  puVar35 = &stack0xffffffffffffffc8 + lVar14;
  puVar34 = &stack0xffffffffffffffc8 + lVar14;
  psVar1 = (short *)((longlong)&uStackX_18 + lVar14);
  *(undefined8 *)(&stack0x00000128 + lVar14) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000023e0 + lVar14) = unaff_RBX;
  *(ulonglong *)(&stack0x00002378 + lVar14) = _DAT_ ^ (ulonglong)psVar1;
  *(longlong *)(&stack0x00000080 + lVar14) = param_3;
  *(ushort ***)(&stack0x000000b0 + lVar14) = param_2;
  *(longlong **)(&stack0x00000058 + lVar14) = param_1;
  *(longlong **)(&stack0x00000118 + lVar14) = param_1;
  *psVar1 = -1;
  puVar39 = (ushort *)0x0;
  *(undefined8 *)((longlong)&pbStackX_20 + lVar14) = 0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar14 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000088 + lVar14) = 1;
  *(ushort **)(&stack0x00000110 + lVar14) = *param_2;
  lVar16 = param_1[2];
  *(longlong *)(&stack0x000000c8 + lVar14) = lVar16;
  lVar15 = *(longlong *)(lVar16 + 8);
  bVar23 = *(byte *)(lVar15 + 0x108);
  uVar43 = 0;
  if (((bVar23 & 0x40) == 0) || (param_1[0x8c] != 0)) {
    (&stack0x00000050)[lVar14] = 0;
  }
  else {
    (&stack0x00000050)[lVar14] = 1;
    bVar22 = *(byte *)(lVar15 + 0x109) & 4;
    if ((((((bVar22 != 0) && ((bVar23 & 2) != 0)) && (0xdac01 < *(uint *)(lVar15 + 0xf4))) &&
         (*(uint *)(lVar15 + 0xf4) != 0xdacfe)) ||
        (((*(byte *)(lVar15 + 0x41) & 0x20) == 0 && (bVar22 == 0)))) && ((DAT_ & 0x10) == 0)
       ) {
      lVar15 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar15 != 0) && (lVar15 = **(longlong **)(lVar15 + 0x38), lVar15 != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10013b;
        iVar12 = (*_DAT_)(lVar15,0xfc);
        if (iVar12 != 0) goto LAB_;
      }
      pcVar4 = *(code **)(*param_1 + 0x230);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100151;
      (*pcVar4)(param_1,param_2,param_3);
      goto LAB_;
    }
  }
LAB_:
  bVar23 = (*(byte *)(*(longlong *)(lVar16 + 8) + 0x106) & 1) + 2;
  iVar12 = *(int *)(*(longlong *)(lVar16 + 8) + 0x100);
  bVar8 = false;
  if ((iVar12 != 0) && (iVar12 != 3 && iVar12 != 4)) {
    bVar8 = true;
  }
  puVar38 = *param_2;
  if ((*(byte *)(puVar38 + 0x1c) & 0x20) == 0) {
    uVar25 = *(uint *)((longlong)param_2 + 0x14) & 0x10;
    *(undefined8 *)(&stack0x00000090 + lVar14) = 0;
    if (bVar8) {
      puVar18 = puVar39;
      if (uVar25 != 0) {
        puVar18 = puVar38;
      }
      uVar25 = -*(int *)(puVar18 + 8);
      *(uint *)(&stack0x0000009c + lVar14) = uVar25;
      uVar13 = *(undefined4 *)(puVar18 + 0xc);
      uVar3 = *(undefined4 *)(puVar18 + 10);
      *(undefined2 *)(&stack0xfffffffffffffff0 + lVar14) = 1;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = uVar13;
      if ((bVar23 & 1) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b2f;
        func_0x(psVar1,&stack0x000003d8 + lVar14,0x1f9e,uVar3);
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b28;
        func_0x();
      }
      puVar34 = &stack0xffffffffffffffc8 + lVar14;
      if (uVar25 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b59;
        lVar16 = func_0x();
        lVar16 = -lVar16;
        puVar34 = &stack0xffffffffffffffc8 + lVar16 + lVar14;
        puVar39 = (ushort *)((longlong)&uStackX_18 + lVar16 + lVar14);
        *(ushort **)(&stack0x00000090 + lVar14) = puVar39;
        *(undefined8 *)((longlong)&uStack_40 + lVar16 + lVar14) = 0x101b6f;
        func_0x(puVar39);
      }
      uVar41 = (*param_2)[0x31];
      *(undefined8 *)(&stack0x000000a8 + lVar14) = 0;
      puVar33 = (uint *)param_2[1];
      if (uVar41 != 0) {
        *(ulonglong *)(&stack0x000000a0 + lVar14) = (ulonglong)uVar41;
        lVar16 = *(longlong *)(&stack0x00000090 + lVar14);
        do {
          uVar25 = *puVar33;
          *(undefined8 *)(puVar34 + -8) = 0x101bba;
          func_0x(param_2,puVar33,&stack0x00000061 + lVar14);
          if ((&stack0x00000061)[lVar14] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar33 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar33[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar34 + -8) = 0x101f28;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar34 + -8) = 0x101f3a;
            func_0x(psVar1,puVar33,0,0);
            if ((int)uVar25 < 0) {
              puVar2 = (uint *)((longlong)(int)~uVar25 * 0x20 + 0xc + lVar16);
              *puVar2 = *puVar2 | 2;
            }
          }
          else {
            if (*(short *)(puVar33 + 1) != 0) {
              if (*psVar1 == 0) {
                *(undefined8 *)(puVar34 + -8) = 0x101bde;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar34 + -8) = 0x101be5;
                func_0x((longlong)&uStackX_18 + lVar14 + 2,puVar33);
              }
            }
            *(undefined8 *)(puVar34 + -8) = 0x101bf7;
            func_0x(param_2,puVar33,&stack0x000000a8 + lVar14);
            cVar10 = *(char *)(puVar33 + 0x10);
            uVar32 = 0;
            if ((cVar10 == '\x01') || (cVar10 == '\x02')) {
              lVar15 = *(longlong *)(&stack0x000000a8 + lVar14);
              if ((puVar33[0x10] >> 8 & 1) == 0) {
                uVar25 = *puVar33;
                lVar40 = *(longlong *)((longlong)&pbStackX_20 + lVar14);
                uVar11 = *(undefined2 *)(puVar33 + 0xf);
                *(undefined8 *)(puVar34 + -8) = 0x101d71;
                func_0x((int)uVar25 + lVar40,lVar15,uVar11);
              }
              else {
                iVar12 = 0;
                if (((puVar33[0x10] >> 0xf & 1) == 0) ||
                   ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  if ((*(byte *)(*(longlong *)(puVar33 + 0x12) + 0x2a) & 0x10) == 0) {
                    puVar39 = param_2[3];
                  }
                  else {
                    puVar39 = param_2[4];
                  }
                  uVar25 = *(uint *)(*(longlong *)(*(longlong *)(puVar33 + 0x12) + 0x18) +
                                    (longlong)puVar39);
                }
                else {
                  uVar25 = *(uint *)(param_2[7] + (ulonglong)puVar33[0xe] * 4);
                }
                uVar32 = (uint)*(ushort *)(puVar33 + 0xf);
                if (uVar25 < uVar32) {
                  iVar12 = uVar32 - uVar25;
                }
                else if (uVar32 < uVar25) {
                  *(undefined8 *)(puVar34 + -8) = 0x101dd7;
                  (*_DAT_)(6,0x5c,0x16);
                }
                uVar43 = *(undefined *)(*(longlong *)(puVar33 + 0x12) + 0x24);
                lVar40 = (longlong)(int)*puVar33 + *(longlong *)((longlong)&pbStackX_20 + lVar14);
                if ((lVar15 != 0) && (uVar25 != 0)) {
                  *(undefined8 *)(puVar34 + -8) = 0x101dfe;
                  func_0x(lVar40,lVar15,uVar25);
                }
                if (iVar12 != 0) {
                  *(undefined8 *)(puVar34 + -8) = 0x101e12;
                  func_0x((ulonglong)uVar25 + lVar40,uVar43,iVar12);
                }
                param_2 = *(ushort ***)(&stack0x000000b0 + lVar14);
              }
            }
            else if ((cVar10 == '\x03') || (cVar10 == '\x04')) {
              uVar37 = puVar33[0x10];
              piVar31 = *(int **)(&stack0x000000a8 + lVar14);
              if (((uVar37 >> 0xd & 1) == 0) || (*piVar31 != 0)) {
                if (((uVar37 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  lVar15 = *(longlong *)(puVar33 + 0x12);
                  if ((uVar37 >> 8 & 1) == 0) {
                    uVar32 = (uint)*(ushort *)(lVar15 + 2);
                  }
                  else if ((*(byte *)(lVar15 + 0x2a) & 0x10) == 0) {
                    uVar32 = *(uint *)(*(longlong *)(lVar15 + 0x18) + (longlong)param_2[3]);
                  }
                  else {
                    uVar32 = *(uint *)(*(longlong *)(lVar15 + 0x18) + (longlong)param_2[4]);
                  }
                }
                else {
                  uVar32 = *(uint *)(param_2[7] + (ulonglong)puVar33[0xe] * 4);
                }
              }
              if (*(ushort *)(puVar33 + 0xf) < uVar32) {
                *(undefined8 *)(puVar34 + -8) = 0x101d20;
                (*_DAT_)(6,0x52,0x16);
                piVar31 = *(int **)(&stack0x000000a8 + lVar14);
              }
              *(undefined4 *)(puVar34 + 0x28) = 0;
              *(uint **)(puVar34 + 0x20) = puVar33;
              *(undefined8 *)(puVar34 + -8) = 0x101d48;
              func_0x((longlong)(int)~uVar25 * 0x20 + lVar16,piVar31,uVar32);
            }
            else if (cVar10 == '\b') {
              if (*psVar1 == 0) {
                uVar19 = *(undefined8 *)(&stack0x000000a8 + lVar14);
                *(undefined8 *)(puVar34 + -8) = 0x101c6e;
                func_0x(psVar1,puVar33,uVar19);
              }
              else {
                *(undefined4 *)(puVar34 + 0x28) = 0;
                *(uint **)(puVar34 + 0x20) = puVar33;
                uVar19 = *(undefined8 *)(&stack0x000000a8 + lVar14);
                *(undefined8 *)(puVar34 + -8) = 0x101c9b;
                func_0x((longlong)(int)~uVar25 * 0x20 + lVar16,uVar19,1);
              }
            }
            else {
              *(undefined8 *)(puVar34 + 0x20) = 0x1571378;
              *(undefined8 *)(puVar34 + -8) = 0x101c4c;
              (*_DAT_)(1,0x19761d0,0x19a2b10);
            }
          }
          puVar33 = puVar33 + 0x14;
          plVar5 = (longlong *)(&stack0x000000a0 + lVar14);
          *plVar5 = *plVar5 + -1;
        } while (*plVar5 != 0);
        uVar25 = *(uint *)(&stack0x0000009c + lVar14);
        puVar39 = *(ushort **)(&stack0x00000090 + lVar14);
      }
      puVar38 = (ushort *)0x0;
      if (uVar25 != 0) {
        if (*psVar1 == 0) {
LAB_:
          uVar36 = (ulonglong)uVar25;
          uVar32 = uVar25 - 1;
          if (*(int *)(puVar39 + (ulonglong)uVar32 * 0x10 + 4) == 0) goto code_r0x00101e78;
          *(ushort *)(&stack0x00000034 + lVar14) = (ushort)uVar25;
          iVar12 = *(int *)(&stack0x0000002c + lVar14) + 2 + uVar25 * 2;
          *(int *)(&stack0x00000030 + lVar14) = iVar12;
          *(int *)((longlong)&uStackX_18 + lVar14 + 4) = iVar12;
          **(byte **)((longlong)&pbStackX_20 + lVar14) =
               **(byte **)((longlong)&pbStackX_20 + lVar14) | 0x20;
          uVar32 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
          if (uVar32 < 0x1f7d) {
            puVar38 = (ushort *)
                      ((ulonglong)*(uint *)(&stack0x0000002c + lVar14) +
                      *(longlong *)((longlong)&pbStackX_20 + lVar14));
            *puVar38 = (ushort)uVar25;
            uVar32 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
          }
          if (uVar25 != 0) {
            puVar33 = (uint *)(puVar39 + 6);
            do {
              puVar38 = puVar38 + 1;
              uVar44 = (ulonglong)uVar32;
              lVar16 = *(longlong *)((longlong)&pbStackX_20 + lVar14);
              uVar25 = puVar33[-1];
              uVar32 = uVar32 + uVar25;
              *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar32;
              if (uVar32 < 0x1f7d) {
                *puVar38 = (ushort)((*puVar33 & 1) << 0xf) | (ushort)uVar32 & 0x7fff;
                uVar19 = *(undefined8 *)(puVar33 + -3);
                *(undefined8 *)(puVar34 + -8) = 0x101fd8;
                func_0x(uVar44 + lVar16,uVar25,uVar19,uVar25);
                uVar32 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
              }
              puVar33 = puVar33 + 8;
              uVar36 = uVar36 - 1;
            } while (uVar36 != 0);
          }
          *(uint *)(&stack0x000000d8 + lVar14) = uVar32;
          goto LAB_;
        }
        *(undefined **)(puVar34 + 0x28) = &stack0x000000d8 + lVar14;
        *(ushort **)(puVar34 + 0x20) = puVar39;
        *(undefined8 *)(puVar34 + -8) = 0x10201a;
        func_0x((longlong)&uStackX_18 + lVar14 + 2,0x1f9e,0x1f7c,uVar25);
      }
    }
    else {
      *psVar1 = 0;
      puVar18 = puVar39;
      if (uVar25 != 0) {
        puVar18 = puVar38;
      }
      uVar25 = -*(int *)(puVar18 + 8);
      *(uint *)(&stack0x0000009c + lVar14) = uVar25;
      if ((bVar23 & 1) == 0) {
        uVar43 = 6;
      }
      iVar12 = 4;
      if ((bVar23 & 1) == 0) {
        iVar12 = 1;
      }
      iVar29 = *(int *)(puVar18 + 10);
      (&stack0xfffffffffffffff0)[lVar14] = uVar43;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = *(undefined4 *)(puVar18 + 0xc);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100204;
      func_0x
                ((longlong)&uStackX_18 + lVar14 + 2,&stack0x000003d8 + lVar14,0x1f9e,iVar29 - iVar12
                );
      if (uVar25 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10022c;
        lVar15 = func_0x();
        lVar15 = -lVar15;
        puVar34 = &stack0xffffffffffffffc8 + lVar15 + lVar14;
        lVar16 = (longlong)&uStackX_18 + lVar15 + lVar14;
        *(longlong *)(&stack0x00000090 + lVar14) = lVar16;
        *(undefined8 *)((longlong)&uStack_40 + lVar15 + lVar14) = 0x100242;
        func_0x(lVar16);
      }
      uVar41 = (*param_2)[0x31];
      *(uint *)(&stack0x000000d4 + lVar14) = (uint)uVar41;
      *(undefined8 *)(&stack0x000000c0 + lVar14) = 0;
      *(undefined4 *)(&stack0x000000b8 + lVar14) = 0;
      puVar33 = (uint *)param_2[1];
      *(uint **)(&stack0x00000070 + lVar14) = puVar33;
      if (uVar41 != 0) {
        do {
          uVar25 = *puVar33;
          *(undefined8 *)(puVar34 + -8) = 0x100292;
          func_0x(param_2,puVar33,&stack0x00000060 + lVar14);
          if ((&stack0x00000060)[lVar14] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar33 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar33[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar34 + -8) = 0x101a0e;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar34 + -8) = 0x101a20;
            func_0x((longlong)&uStackX_18 + lVar14 + 2,puVar33,0,0);
            if ((int)uVar25 < 0) {
              puVar2 = (uint *)((longlong)(int)~uVar25 * 0x20 + 0xc +
                               *(longlong *)(&stack0x00000090 + lVar14));
              *puVar2 = *puVar2 | 2;
            }
          }
          else {
            if (*(short *)(puVar33 + 1) != 0) {
              *(undefined8 *)(puVar34 + -8) = 0x1002af;
              func_0x((longlong)&uStackX_18 + lVar14 + 2,puVar33);
            }
            *(undefined8 *)(puVar34 + -8) = 0x1002c1;
            func_0x(param_2,puVar33,&stack0x000000c0 + lVar14);
            cVar10 = *(char *)(puVar33 + 0x10);
            uVar32 = 0;
            if ((cVar10 == '\x01') || (cVar10 == '\x02')) {
              lVar16 = *(longlong *)(&stack0x000000c0 + lVar14);
              if ((puVar33[0x10] >> 8 & 1) == 0) {
                uVar25 = *puVar33;
                lVar15 = *(longlong *)((longlong)&pbStackX_20 + lVar14);
                uVar11 = *(undefined2 *)(puVar33 + 0xf);
                *(undefined8 *)(puVar34 + -8) = 0x101925;
                func_0x((int)uVar25 + lVar15,lVar16,uVar11);
              }
              else {
                if (((puVar33[0x10] & 0x8000) == 0) ||
                   ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  if ((*(byte *)(*(longlong *)(puVar33 + 0x12) + 0x2a) & 0x10) == 0) {
                    puVar38 = param_2[3];
                  }
                  else {
                    puVar38 = param_2[4];
                  }
                  uVar25 = *(uint *)(*(longlong *)(*(longlong *)(puVar33 + 0x12) + 0x18) +
                                    (longlong)puVar38);
                }
                else {
                  uVar25 = *(uint *)(param_2[7] + (ulonglong)puVar33[0xe] * 4);
                }
                uVar37 = (uint)*(ushort *)(puVar33 + 0xf);
                if (uVar25 < uVar37) {
                  uVar32 = uVar37 - uVar25;
                }
                else if (uVar37 < uVar25) {
                  *(undefined8 *)(puVar34 + -8) = 0x101991;
                  (*_DAT_)(6,0x5c,0x16);
                }
                uVar43 = *(undefined *)(*(longlong *)(puVar33 + 0x12) + 0x24);
                lVar15 = (longlong)**(int **)(&stack0x00000070 + lVar14) +
                         *(longlong *)((longlong)&pbStackX_20 + lVar14);
                if ((lVar16 != 0) && (uVar25 != 0)) {
                  *(undefined8 *)(puVar34 + -8) = 0x1019bc;
                  func_0x(lVar15,lVar16,uVar25);
                }
                if (uVar32 != 0) {
                  *(undefined8 *)(puVar34 + -8) = 0x1019d0;
                  func_0x((ulonglong)uVar25 + lVar15,uVar43,uVar32);
                }
                puVar33 = *(uint **)(&stack0x00000070 + lVar14);
              }
            }
            else if ((cVar10 == '\x03') || (cVar10 == '\x04')) {
              uVar37 = puVar33[0x10];
              piVar31 = *(int **)(&stack0x000000c0 + lVar14);
              if (((uVar37 >> 0xd & 1) == 0) || (*piVar31 != 0)) {
                if (((uVar37 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  lVar16 = *(longlong *)(puVar33 + 0x12);
                  if ((uVar37 >> 8 & 1) == 0) {
                    uVar32 = (uint)*(ushort *)(lVar16 + 2);
                  }
                  else if ((*(byte *)(lVar16 + 0x2a) & 0x10) == 0) {
                    uVar32 = *(uint *)(*(longlong *)(lVar16 + 0x18) + (longlong)param_2[3]);
                  }
                  else {
                    uVar32 = *(uint *)(*(longlong *)(lVar16 + 0x18) + (longlong)param_2[4]);
                  }
                }
                else {
                  uVar32 = *(uint *)(param_2[7] + (ulonglong)puVar33[0xe] * 4);
                }
              }
              if (*(ushort *)(puVar33 + 0xf) < uVar32) {
                *(undefined8 *)(puVar34 + -8) = 0x1018cf;
                (*_DAT_)(6,0x52,0x16);
                piVar31 = *(int **)(&stack0x000000c0 + lVar14);
              }
              lVar16 = *(longlong *)(&stack0x00000090 + lVar14);
              *(undefined4 *)(puVar34 + 0x28) = 0;
              *(uint **)(puVar34 + 0x20) = puVar33;
              *(undefined8 *)(puVar34 + -8) = 0x1018fb;
              func_0x((longlong)(int)~uVar25 * 0x20 + lVar16,piVar31,uVar32);
            }
            else if (cVar10 == '\b') {
              *(char **)(&stack0x000000a0 + lVar14) = *(char **)(&stack0x000000c0 + lVar14);
              uVar25 = *puVar33;
              if ((int)uVar25 < 0) {
                if ((uVar25 & 0xc0000000) == 0x80000000) {
                  *(undefined8 *)(puVar34 + -8) = 0x10109f;
                  func_0x(&stack0x000002f8 + lVar14);
                  *(undefined4 *)(&stack0x00000098 + lVar14) = 0;
                  if (*(int *)((longlong)&uStackX_18 + lVar14 + 4) == 0) {
                    *(undefined2 *)((longlong)&uStackX_18 + lVar14 + 2) = 0;
                    uVar25 = *(uint *)(&stack0x00000028 + lVar14);
                    uVar36 = (ulonglong)uVar25;
                    *(uint *)(&stack0x0000002c + lVar14) = uVar25;
                    pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                    if ((*pbVar30 & 0x10) != 0) {
                      uVar25 = uVar25 + 2 + (*(ushort *)(pbVar30 + uVar36) + 7 >> 3);
                      uVar36 = (ulonglong)uVar25;
                      *(uint *)(&stack0x0000002c + lVar14) = uVar25;
                    }
                    uVar25 = (uint)uVar36;
                    if ((*pbVar30 & 0x20) == 0) {
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25;
                      *(undefined2 *)(&stack0x00000034 + lVar14) = 0;
                      *(uint *)(&stack0x00000030 + lVar14) = uVar25;
                    }
                    else {
                      puVar38 = (ushort *)(pbVar30 + uVar36);
                      uVar41 = *puVar38;
                      *(ushort *)(&stack0x00000034 + lVar14) = uVar41;
                      if (uVar41 == 0) {
                        *(undefined8 *)(puVar34 + -8) = 0x101106;
                        cVar10 = func_0x(0x1f04110);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar34 + -8) = 0x10110f;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar34 + -8) = 0x101129;
                            cVar10 = func_0x(0x1f04110);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar34 + -8) = 0x101145;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x10116b;
                              (*_DAT_)(1,0x17f4e98,0x1914b68,0x80f);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                        *(undefined8 *)(puVar34 + -8) = 0x101179;
                        func_0x(uVar19,3);
                        uVar41 = *(ushort *)(&stack0x00000034 + lVar14);
                        uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                        pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                      }
                      uVar32 = (int)uVar36 + (uVar41 + 1) * 2;
                      *(uint *)(&stack0x00000030 + lVar14) = uVar32;
                      if (0x1f9e < uVar32) {
                        *(undefined8 *)(puVar34 + -8) = 0x1011ad;
                        cVar10 = func_0x(0x1f04110);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar34 + -8) = 0x1011b6;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar34 + -8) = 0x1011d0;
                            cVar10 = func_0x(0x1f04110);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar34 + -8) = 0x1011ec;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x101212;
                              (*_DAT_)(1,0x17f4e98,0x1914b68,0x816);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                        *(undefined8 *)(puVar34 + -8) = 0x101220;
                        func_0x(uVar19,4);
                        uVar41 = *(ushort *)(&stack0x00000034 + lVar14);
                        uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                        uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                        pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                      }
                      uVar44 = (ulonglong)uVar41;
                      uVar25 = puVar38[uVar44] & 0x7fff;
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25;
                      if (uVar25 < uVar32) {
                        *(undefined8 *)(puVar34 + -8) = 0x101255;
                        cVar10 = func_0x(0x1f04110);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar34 + -8) = 0x10125e;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar34 + -8) = 0x101278;
                            cVar10 = func_0x(0x1f04110);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar34 + -8) = 0x101294;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x1012ba;
                              (*_DAT_)(1,0x17f4e98,0x1914b68,0x81d);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                        *(undefined8 *)(puVar34 + -8) = 0x1012c8;
                        func_0x(uVar19,4);
                        uVar44 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar14);
                        uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                        uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                        pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                        uVar25 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                      }
                      do {
                        if (-1 < (short)puVar38[(ulonglong)((int)uVar44 - 1) + 1]) break;
                        uVar37 = uVar32;
                        if ((int)uVar44 != 1) {
                          uVar37 = *(ushort *)(pbVar30 + uVar44 * 2 + (uVar36 - 2)) & 0x7fff;
                        }
                        if ((uVar37 < uVar32) ||
                           ((*(ushort *)(pbVar30 + uVar44 * 2 + uVar36) & 0x7fff) < uVar37)) {
                          *(undefined8 *)(puVar34 + -8) = 0x101329;
                          func_0x(pbVar30,7);
                          uVar44 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar14);
                          uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                          uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                          pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                          uVar25 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                        }
                        if ((uVar37 < uVar32) || (uVar25 < uVar37)) goto LAB_;
                        if (*(ushort *)(pbVar30 + uVar37) == 5) {
                          puVar38 = (ushort *)((longlong)&uStackX_18 + lVar14 + 2);
                          *puVar38 = *puVar38 | 2;
                          *(short *)(&stack0x00000034 + lVar14) = (short)uVar44 + -1;
                          *(short *)(&stack0x00000042 + lVar14) = (short)uVar37;
                          uVar41 = *(ushort *)(&stack0x00000044 + lVar14);
                          if ((*(ushort *)(pbVar30 + (ulonglong)(uVar37 & 0xffff) + 2) >> 0xe & 1)
                              == 0) {
                            uVar41 = uVar41 & 0xc7ff;
                          }
                          else {
                            uVar41 = uVar41 ^ (*(ushort *)
                                                (pbVar30 + (ulonglong)(uVar37 & 0xffff) + 2) ^
                                              uVar41) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar14) = uVar41;
                          *(ushort *)(&stack0x00000044 + lVar14) =
                               uVar41 ^ (uVar41 ^ *(ushort *)
                                                   (pbVar30 + (ulonglong)(uVar37 & 0xffff) + 2)) &
                                        0x7ff;
                          break;
                        }
                        if (*(ushort *)(pbVar30 + uVar37) < 0x400) break;
                        puVar18 = (ushort *)((longlong)&uStackX_18 + lVar14 + 2);
                        *puVar18 = *puVar18 | 1;
                        uVar41 = (short)uVar44 - 1;
                        uVar44 = (ulonglong)uVar41;
                        *(ushort *)(&stack0x00000034 + lVar14) = uVar41;
                      } while (uVar41 != 0);
                    }
                    if ((*pbVar30 & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar14) = 0;
                    }
                    else {
                      *(uint *)(&stack0x0000003e + lVar14) = uVar25;
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25 + 0xe;
                      *(undefined8 *)(puVar34 + -8) = 0x10139e;
                      uVar19 = func_0x((longlong)&uStackX_18 + lVar14 + 2);
                      *(undefined8 *)(puVar34 + -8) = 0x1013ad;
                      func_0x(uVar19,&stack0x00000108 + lVar14);
                      *(undefined8 *)(puVar34 + -8) = 0x1013b9;
                      iVar12 = func_0x(&stack0x00000108 + lVar14);
                      uVar25 = *(int *)((longlong)&uStackX_18 + lVar14 + 4) + iVar12;
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25;
                      pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                    }
                    if ((*(byte **)(&stack0x00000036 + lVar14) != (byte *)0x0) &&
                       (*(byte **)(&stack0x00000036 + lVar14) < pbVar30 + uVar25)) {
                      *(undefined8 *)(puVar34 + -8) = 0x10146a;
                      cVar10 = func_0x(0x1f04110);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar34 + -8) = 0x101473;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar34 + -8) = 0x10148d;
                          cVar10 = func_0x(0x1f04110);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar34 + -8) = 0x1014a9;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x1014cc;
                            (*_DAT_)(1,0x17f4e98,0x1914b68,0x877);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                      *(undefined8 *)(puVar34 + -8) = 0x1014da;
                      func_0x(uVar19,0x12);
                      uVar25 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                    }
                    if (0x3f3b < uVar25 - 1) {
                      *(undefined8 *)(puVar34 + -8) = 0x1014f5;
                      cVar10 = func_0x(0x1f04110);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar34 + -8) = 0x1014fe;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar34 + -8) = 0x101518;
                          cVar10 = func_0x(0x1f04110);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar34 + -8) = 0x101534;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x101557;
                            (*_DAT_)(1,0x17f4e98,0x1914b68,0x87c);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                      *(undefined8 *)(puVar34 + -8) = 0x101565;
                      func_0x(uVar19,5);
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar34 + -8) = 0x10156e;
                  func_0x((longlong)&uStackX_18 + lVar14 + 2);
                  bVar23 = **(byte **)((longlong)&pbStackX_20 + lVar14) >> 6;
                  if ((bVar23 & 1) != 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x101590;
                    func_0x
                              ((longlong)&uStackX_18 + lVar14 + 2,&stack0x000002f8 + lVar14);
                  }
                  if ((*(byte *)((longlong)&uStackX_18 + lVar14 + 2) & 1) != 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x1015ab;
                    puVar17 = (undefined4 *)
                              func_0x((longlong)&uStackX_18 + lVar14 + 2,0x400,
                                              &stack0x00000098 + lVar14);
                    *(undefined4 *)(&stack0x000000e0 + lVar14) = *puVar17;
                    *(undefined2 *)(&stack0x000000e4 + lVar14) = *(undefined2 *)(puVar17 + 1);
                    *(undefined2 *)(&stack0x000000e6 + lVar14) =
                         *(undefined2 *)((longlong)puVar17 + 6);
                  }
                  if ((**(byte **)((longlong)&pbStackX_20 + lVar14) & 0x20) == 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x1015db;
                    func_0x((longlong)&uStackX_18 + lVar14 + 2);
                  }
                  lVar15 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14) +
                           *(longlong *)((longlong)&pbStackX_20 + lVar14);
                  *(undefined8 *)(puVar34 + -8) = 0x1015eb;
                  iVar12 = func_0x((longlong)&uStackX_18 + lVar14 + 2);
                  lVar16 = *(longlong *)((longlong)&pbStackX_20 + lVar14);
                  if (iVar12 == 0) {
                    uVar41 = *(ushort *)(&stack0x00000034 + lVar14);
                    uVar36 = (ulonglong)uVar41;
                    puVar38 = (ushort *)(lVar16 + (ulonglong)*(uint *)(&stack0x0000002c + lVar14));
                    uVar25 = *(uint *)(&stack0x0000002c + lVar14) + (uVar41 + 1) * 2;
                    puVar18 = puVar39;
                    if (*puVar38 != 0) {
                      do {
                        uVar24 = puVar38[(longlong)puVar18 + 1];
                        puVar38[((ulonglong)puVar18 & 0xffff) + 1] =
                             puVar38[((ulonglong)puVar18 & 0xffff) + 1] & 0x8000;
                        puVar38[((ulonglong)puVar18 & 0xffff) + 1] =
                             puVar38[((ulonglong)puVar18 & 0xffff) + 1] |
                             (uVar24 & 0x7fff) + 2 & 0x7fff;
                        uVar32 = (int)puVar18 + 1;
                        puVar18 = (ushort *)(ulonglong)uVar32;
                      } while (uVar32 < *puVar38);
                      lVar16 = *(longlong *)((longlong)&pbStackX_20 + lVar14);
                    }
                    iVar12 = *(int *)((longlong)&uStackX_18 + lVar14 + 4);
                    *(undefined8 *)(puVar34 + -8) = 0x1016ca;
                    func_0x
                              ((ulonglong)uVar25 + 2 + lVar16,(ulonglong)uVar25 + lVar16,
                               iVar12 - uVar25);
                    piVar31 = (int *)((longlong)&uStackX_18 + lVar14 + 4);
                    *piVar31 = *piVar31 + 2;
                    uVar25 = *(int *)(&stack0x00000030 + lVar14) + 2;
                    *(uint *)(&stack0x00000030 + lVar14) = uVar25;
                    if (uVar41 != 0) {
                      uVar25 = puVar38[(ulonglong)(uVar41 - 1) + 1] & 0x7fff;
                    }
                    if ((uint)uVar41 < uVar41 + 1) {
                      do {
                        puVar38[(uVar36 & 0xffff) + 1] = (ushort)uVar25 & 0x7fff;
                        uVar32 = (int)uVar36 + 1;
                        uVar36 = (ulonglong)uVar32;
                      } while (uVar32 < uVar41 + 1);
                    }
                    *puVar38 = *puVar38 + 1;
                    *(undefined8 *)(puVar34 + -8) = 0x10170b;
                    func_0x((longlong)&uStackX_18 + lVar14 + 2);
                    uVar41 = *(ushort *)
                              (lVar15 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar14) * 2);
                    *(undefined8 *)(puVar34 + -8) = 0x101723;
                    func_0x(&stack0x00000140 + lVar14);
                    *(undefined4 *)(puVar34 + 0x28) = 0;
                    *(undefined8 *)(puVar34 + 0x20) = *(undefined8 *)(&stack0x00000070 + lVar14);
                    uVar19 = *(undefined8 *)(&stack0x000000a0 + lVar14);
                    *(undefined8 *)(puVar34 + -8) = 0x10174b;
                    func_0x(&stack0x00000130 + lVar14,uVar19,1);
                    *(undefined **)(puVar34 + 0x28) = &stack0x000000d0 + lVar14;
                    *(undefined **)(puVar34 + 0x20) = &stack0x00000130 + lVar14;
                    *(undefined8 *)(puVar34 + -8) = 0x10177d;
                    func_0x(&stack0x00000042 + lVar14,uVar41 & 0x7fff,0x1f9e);
                    iVar12 = *(int *)(&stack0x000000d0 + lVar14);
                    iVar29 = 0;
                  }
                  else {
                    uVar41 = *(ushort *)(&stack0x00000034 + lVar14);
                    uVar25 = *(uint *)(&stack0x00000030 + lVar14);
                    if (uVar41 != 0) {
                      uVar25 = *(ushort *)
                                ((ulonglong)*(uint *)(&stack0x0000002c + lVar14) + lVar16 +
                                (ulonglong)uVar41 * 2) & 0x7fff;
                    }
                    uVar32 = *(ushort *)
                              ((ulonglong)*(uint *)(&stack0x0000002c + lVar14) + lVar16 + 2 +
                              (ulonglong)uVar41 * 2) & 0x7fff;
                    if ((uVar25 < *(uint *)(&stack0x00000030 + lVar14)) || (uVar32 < uVar25)) {
                      *(undefined8 *)(puVar34 + -8) = 0x10162f;
                      func_0x(lVar16,7);
                    }
                    uVar19 = *(undefined8 *)(&stack0x000000a0 + lVar14);
                    uVar6 = *(undefined8 *)(&stack0x00000070 + lVar14);
                    *(undefined8 *)(puVar34 + -8) = 0x10164b;
                    iVar12 = func_0x(&stack0x00000042 + lVar14,uVar6,uVar19);
                    iVar29 = uVar32 - uVar25;
                  }
                  iVar29 = (*(int *)((longlong)&uStackX_18 + lVar14 + 4) - iVar29) + iVar12;
                  *(int *)((longlong)&uStackX_18 + lVar14 + 4) = iVar29;
                  if ((*(byte *)((longlong)&uStackX_18 + lVar14 + 2) & 1) != 0) {
                    *(ushort *)
                     (lVar15 + 2 + (ulonglong)(*(ushort *)(&stack0x00000034 + lVar14) + 1) * 2) =
                         (ushort)iVar29 | 0x8000;
                    iVar29 = (*(int *)((longlong)&uStackX_18 + lVar14 + 4) -
                             *(int *)(&stack0x00000098 + lVar14)) + -2;
                  }
                  *(ushort *)(lVar15 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar14) * 2) =
                       (ushort)iVar29 | 0x8000;
                  if (iVar12 == 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x1017d4;
                    func_0x();
                    if ((**(byte **)((longlong)&pbStackX_20 + lVar14) & 0x20) != 0) {
                      *(short *)(&stack0x00000034 + lVar14) =
                           *(short *)(&stack0x00000034 + lVar14) + 1;
                      puVar38 = (ushort *)((longlong)&uStackX_18 + lVar14 + 2);
                      *puVar38 = *puVar38 & 0xfffd;
                      *(undefined8 *)(puVar34 + -8) = 0x1017f3;
                      func_0x(&stack0x00000042 + lVar14);
                    }
                  }
                  else {
                    puVar38 = (ushort *)((longlong)&uStackX_18 + lVar14 + 2);
                    *puVar38 = *puVar38 | 2;
                    *(undefined8 *)(puVar34 + -8) = 0x101806;
                    uVar11 = func_0x((longlong)&uStackX_18 + lVar14 + 2);
                    *(undefined2 *)(&stack0x00000042 + lVar14) = uVar11;
                  }
                  if ((*(byte *)((longlong)&uStackX_18 + lVar14 + 2) & 1) != 0) {
                    uVar13 = *(undefined4 *)(&stack0x00000098 + lVar14);
                    *(undefined8 *)(puVar34 + -8) = 0x10182c;
                    func_0x((longlong)&uStackX_18 + lVar14 + 2,0x400,uVar13);
                  }
                  if ((bVar23 & 1) != 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x101841;
                    func_0x((longlong)&uStackX_18 + lVar14 + 2);
                  }
                  puVar33 = *(uint **)(&stack0x00000070 + lVar14);
                }
                else {
                  if (*(int *)((longlong)&uStackX_18 + lVar14 + 4) == 0) {
                    *(undefined2 *)((longlong)&uStackX_18 + lVar14 + 2) = 0;
                    uVar25 = *(uint *)(&stack0x00000028 + lVar14);
                    uVar36 = (ulonglong)uVar25;
                    *(uint *)(&stack0x0000002c + lVar14) = uVar25;
                    pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                    if ((*pbVar30 & 0x10) != 0) {
                      uVar25 = uVar25 + 2 + (*(ushort *)(pbVar30 + uVar36) + 7 >> 3);
                      uVar36 = (ulonglong)uVar25;
                      *(uint *)(&stack0x0000002c + lVar14) = uVar25;
                    }
                    uVar25 = (uint)uVar36;
                    if ((*pbVar30 & 0x20) == 0) {
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25;
                      *(undefined2 *)(&stack0x00000034 + lVar14) = 0;
                      *(uint *)(&stack0x00000030 + lVar14) = uVar25;
                    }
                    else {
                      puVar38 = (ushort *)(pbVar30 + uVar36);
                      uVar41 = *puVar38;
                      *(ushort *)(&stack0x00000034 + lVar14) = uVar41;
                      if (uVar41 == 0) {
                        *(undefined8 *)(puVar34 + -8) = 0x10098e;
                        cVar10 = func_0x(0x1f04110);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar34 + -8) = 0x100997;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar34 + -8) = 0x1009b1;
                            cVar10 = func_0x(0x1f04110);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar34 + -8) = 0x1009cd;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x1009f3;
                              (*_DAT_)(1,0x17f4e98,0x1914b68,0x80f);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                        *(undefined8 *)(puVar34 + -8) = 0x100a01;
                        func_0x(uVar19,3);
                        uVar41 = *(ushort *)(&stack0x00000034 + lVar14);
                        uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                        pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                      }
                      uVar32 = (int)uVar36 + (uVar41 + 1) * 2;
                      *(uint *)(&stack0x00000030 + lVar14) = uVar32;
                      if (0x1f9e < uVar32) {
                        *(undefined8 *)(puVar34 + -8) = 0x100a35;
                        cVar10 = func_0x(0x1f04110);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar34 + -8) = 0x100a3e;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar34 + -8) = 0x100a58;
                            cVar10 = func_0x(0x1f04110);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar34 + -8) = 0x100a74;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x100a9a;
                              (*_DAT_)(1,0x17f4e98,0x1914b68,0x816);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                        *(undefined8 *)(puVar34 + -8) = 0x100aa8;
                        func_0x(uVar19,4);
                        uVar41 = *(ushort *)(&stack0x00000034 + lVar14);
                        uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                        uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                        pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                      }
                      uVar44 = (ulonglong)uVar41;
                      uVar25 = puVar38[uVar44] & 0x7fff;
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25;
                      if (uVar25 < uVar32) {
                        *(undefined8 *)(puVar34 + -8) = 0x100add;
                        cVar10 = func_0x(0x1f04110);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar34 + -8) = 0x100ae6;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar34 + -8) = 0x100b00;
                            cVar10 = func_0x(0x1f04110);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar34 + -8) = 0x100b1c;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x100b42;
                              (*_DAT_)(1,0x17f4e98,0x1914b68,0x81d);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                        *(undefined8 *)(puVar34 + -8) = 0x100b50;
                        func_0x(uVar19,4);
                        uVar44 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar14);
                        uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                        uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                        pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                        uVar25 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                      }
                      do {
                        if (-1 < (short)puVar38[(ulonglong)((int)uVar44 - 1) + 1]) break;
                        uVar37 = uVar32;
                        if ((int)uVar44 != 1) {
                          uVar37 = *(ushort *)(pbVar30 + uVar44 * 2 + (uVar36 - 2)) & 0x7fff;
                        }
                        if ((uVar37 < uVar32) ||
                           ((*(ushort *)(pbVar30 + uVar44 * 2 + uVar36) & 0x7fff) < uVar37)) {
                          *(undefined8 *)(puVar34 + -8) = 0x100bb1;
                          func_0x(pbVar30,7);
                          uVar44 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar14);
                          uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                          uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                          pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                          uVar25 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                        }
                        if ((uVar37 < uVar32) || (uVar25 < uVar37)) goto LAB_;
                        if (*(ushort *)(pbVar30 + uVar37) == 5) {
                          puVar38 = (ushort *)((longlong)&uStackX_18 + lVar14 + 2);
                          *puVar38 = *puVar38 | 2;
                          *(short *)(&stack0x00000034 + lVar14) = (short)uVar44 + -1;
                          *(short *)(&stack0x00000042 + lVar14) = (short)uVar37;
                          uVar41 = *(ushort *)(&stack0x00000044 + lVar14);
                          if ((*(ushort *)(pbVar30 + (ulonglong)(uVar37 & 0xffff) + 2) >> 0xe & 1)
                              == 0) {
                            uVar41 = uVar41 & 0xc7ff;
                          }
                          else {
                            uVar41 = uVar41 ^ (uVar41 ^ *(ushort *)
                                                         (pbVar30 + (ulonglong)(uVar37 & 0xffff) + 2
                                                         )) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar14) = uVar41;
                          *(ushort *)(&stack0x00000044 + lVar14) =
                               uVar41 ^ (uVar41 ^ *(ushort *)
                                                   (pbVar30 + (ulonglong)(uVar37 & 0xffff) + 2)) &
                                        0x7ff;
                          break;
                        }
                        if (*(ushort *)(pbVar30 + uVar37) < 0x400) break;
                        puVar18 = (ushort *)((longlong)&uStackX_18 + lVar14 + 2);
                        *puVar18 = *puVar18 | 1;
                        uVar41 = (short)uVar44 - 1;
                        uVar44 = (ulonglong)uVar41;
                        *(ushort *)(&stack0x00000034 + lVar14) = uVar41;
                      } while (uVar41 != 0);
                    }
                    if ((*pbVar30 & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar14) = 0;
                    }
                    else {
                      *(uint *)(&stack0x0000003e + lVar14) = uVar25;
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25 + 0xe;
                      *(undefined8 *)(puVar34 + -8) = 0x100c26;
                      uVar19 = func_0x((longlong)&uStackX_18 + lVar14 + 2);
                      *(undefined8 *)(puVar34 + -8) = 0x100c35;
                      func_0x(uVar19,&stack0x00000100 + lVar14);
                      *(undefined8 *)(puVar34 + -8) = 0x100c41;
                      iVar12 = func_0x(&stack0x00000100 + lVar14);
                      uVar25 = *(int *)((longlong)&uStackX_18 + lVar14 + 4) + iVar12;
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25;
                      pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                    }
                    if ((*(byte **)(&stack0x00000036 + lVar14) != (byte *)0x0) &&
                       (*(byte **)(&stack0x00000036 + lVar14) < pbVar30 + uVar25)) {
                      *(undefined8 *)(puVar34 + -8) = 0x100cf7;
                      cVar10 = func_0x(0x1f04110);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar34 + -8) = 0x100d00;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar34 + -8) = 0x100d1a;
                          cVar10 = func_0x(0x1f04110);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar34 + -8) = 0x100d36;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x100d59;
                            (*_DAT_)(1,0x17f4e98,0x1914b68);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                      *(undefined8 *)(puVar34 + -8) = 0x100d67;
                      func_0x(uVar19,0x12);
                      uVar25 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                    }
                    if (0x3f3b < uVar25 - 1) {
                      *(undefined8 *)(puVar34 + -8) = 0x100d82;
                      cVar10 = func_0x(0x1f04110);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar34 + -8) = 0x100d8b;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar34 + -8) = 0x100da5;
                          cVar10 = func_0x(0x1f04110);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar34 + -8) = 0x100dc1;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x100de4;
                            (*_DAT_)(1,0x17f4e98,0x1914b68);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                      *(undefined8 *)(puVar34 + -8) = 0x100df2;
                      func_0x(uVar19,5);
                    }
                  }
LAB_:
                  uVar25 = -*puVar33;
                  *(undefined8 *)(puVar34 + -8) = 0x100e04;
                  func_0x(&stack0x00000218 + lVar14);
                  pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                  bVar23 = *pbVar30;
                  if ((bVar23 >> 6 & 1) != 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x100e26;
                    func_0x
                              ((longlong)&uStackX_18 + lVar14 + 2,&stack0x00000218 + lVar14);
                    pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                  }
                  if ((*pbVar30 & 0x20) == 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x100e39;
                    func_0x((longlong)&uStackX_18 + lVar14 + 2);
                    pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                  }
                  uVar41 = *(ushort *)(&stack0x00000034 + lVar14);
                  uVar37 = (uint)uVar41;
                  uVar32 = (uint)uVar41;
                  if (uVar32 < uVar25) {
                    puVar38 = (ushort *)(pbVar30 + *(uint *)(&stack0x0000002c + lVar14));
                    uVar37 = *(uint *)(&stack0x0000002c + lVar14) + 2 + uVar32 * 2;
                    uVar26 = (uVar25 - uVar41) * 2;
                    puVar18 = puVar39;
                    if (*puVar38 != 0) {
                      do {
                        uVar24 = puVar38[(longlong)puVar18 + 1];
                        puVar38[((ulonglong)puVar18 & 0xffff) + 1] =
                             puVar38[((ulonglong)puVar18 & 0xffff) + 1] & 0x8000;
                        puVar38[((ulonglong)puVar18 & 0xffff) + 1] =
                             puVar38[((ulonglong)puVar18 & 0xffff) + 1] |
                             (uVar24 & 0x7fff) + (short)uVar26 & 0x7fff;
                        uVar28 = (int)puVar18 + 1;
                        puVar18 = (ushort *)(ulonglong)uVar28;
                      } while (uVar28 < *puVar38);
                      pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                    }
                    iVar12 = *(int *)((longlong)&uStackX_18 + lVar14 + 4);
                    *(undefined8 *)(puVar34 + -8) = 0x100eca;
                    func_0x
                              (pbVar30 + (ulonglong)uVar37 + (ulonglong)uVar26,pbVar30 + uVar37,
                               iVar12 - uVar37);
                    piVar31 = (int *)((longlong)&uStackX_18 + lVar14 + 4);
                    *piVar31 = *piVar31 + uVar26;
                    uVar26 = *(int *)(&stack0x00000030 + lVar14) + uVar26;
                    *(uint *)(&stack0x00000030 + lVar14) = uVar26;
                    if (uVar41 != 0) {
                      uVar26 = puVar38[(ulonglong)(uVar32 - 1) + 1] & 0x7fff;
                    }
                    do {
                      puVar38[(ulonglong)(uVar32 & 0xffff) + 1] = (ushort)uVar26 & 0x7fff;
                      uVar32 = uVar32 + 1;
                    } while (uVar32 < uVar25);
                    *puVar38 = *puVar38 + (short)(uVar25 - uVar41);
                    *(undefined8 *)(puVar34 + -8) = 0x100f0b;
                    iVar12 = func_0x((longlong)&uStackX_18 + lVar14 + 2);
                    if (iVar12 != 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x100f1f;
                      uVar11 = func_0x
                                         ((longlong)&uStackX_18 + lVar14 + 2,
                                          &stack0x00000120 + lVar14);
                      *(undefined2 *)(&stack0x00000042 + lVar14) = uVar11;
                    }
                    uVar37 = uVar25 & 0xffff;
                    *(short *)(&stack0x00000034 + lVar14) = (short)uVar25;
                    pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                  }
                  uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                  if (uVar37 < uVar25) {
                    uVar44 = (ulonglong)
                             (*(ushort *)(pbVar30 + (ulonglong)uVar37 * 2 + uVar36) & 0x7fff);
                    iVar12 = 0;
LAB_:
                    puVar38 = (ushort *)(pbVar30 + uVar36);
                    uVar13 = *(undefined4 *)((longlong)&uStackX_18 + lVar14 + 4);
                    *(undefined8 *)(puVar34 + -8) = 0x100ff3;
                    uVar13 = func_0x(uVar13,iVar12 + (int)uVar44);
                    lVar16 = *(longlong *)((longlong)&pbStackX_20 + lVar14);
                    *(undefined8 *)(puVar34 + -8) = 0x10100f;
                    func_0x(lVar16 + 1 + uVar44,iVar12 + lVar16 + uVar44,uVar13);
                    uVar25 = uVar25 - 1;
                    if ((int)uVar25 < (int)(uint)*puVar38) {
                      do {
                        uVar41 = puVar38[(longlong)(int)uVar25 + 1];
                        puVar38[((ulonglong)uVar25 & 0xffff) + 1] =
                             puVar38[((ulonglong)uVar25 & 0xffff) + 1] & 0x8000;
                        puVar38[((ulonglong)uVar25 & 0xffff) + 1] =
                             puVar38[((ulonglong)uVar25 & 0xffff) + 1] |
                             ((uVar41 & 0x7fff) - (short)iVar12) + 1 & 0x7fff;
                        uVar25 = uVar25 + 1;
                      } while ((int)uVar25 < (int)(uint)*puVar38);
                    }
                    piVar31 = (int *)((longlong)&uStackX_18 + lVar14 + 4);
                    *piVar31 = *piVar31 + (1 - iVar12);
                    *(undefined8 *)(puVar34 + -8) = 0x101072;
                    iVar12 = func_0x((longlong)&uStackX_18 + lVar14 + 2);
                    if (iVar12 != 0) {
                      *(undefined8 *)(puVar34 + -8) = 0x101086;
                      uVar11 = func_0x((longlong)&uStackX_18 + lVar14 + 2);
                      *(undefined2 *)(&stack0x00000042 + lVar14) = uVar11;
                    }
                    pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                  }
                  else {
                    uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                    if (uVar25 != 1) {
                      uVar32 = *(ushort *)(pbVar30 + (longlong)(int)uVar25 * 2 + (uVar36 - 2)) &
                               0x7fff;
                    }
                    uVar44 = (ulonglong)uVar32;
                    uVar41 = *(ushort *)(pbVar30 + (longlong)(int)uVar25 * 2 + uVar36);
                    if ((uVar32 < *(uint *)(&stack0x00000030 + lVar14)) ||
                       ((uVar41 & 0x7fff) < uVar32)) {
                      *(undefined8 *)(puVar34 + -8) = 0x100f81;
                      func_0x(pbVar30);
                      uVar36 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14);
                      pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                    }
                    iVar12 = (uVar41 & 0x7fff) - uVar32;
                    if (iVar12 != 1) goto LAB_;
                  }
                  pbVar30[uVar44] = **(byte **)(&stack0x000000a0 + lVar14);
                  if ((bVar23 >> 6 & 1) != 0) {
                    *(undefined8 *)(puVar34 + -8) = 0x100fb9;
                    func_0x((longlong)&uStackX_18 + lVar14 + 2);
                  }
                  param_2 = *(ushort ***)(&stack0x000000b0 + lVar14);
                  puVar33 = *(uint **)(&stack0x00000070 + lVar14);
                }
              }
              else {
                bVar23 = (byte)*(ushort *)((longlong)puVar33 + 6);
                if ((*(ushort *)((longlong)puVar33 + 6) & 8) == 0) {
                  if (*(int *)((longlong)&uStackX_18 + lVar14 + 4) == 0) {
                    *(undefined2 *)((longlong)&uStackX_18 + lVar14 + 2) = 0;
                    uVar25 = *(uint *)(&stack0x00000028 + lVar14);
                    *(uint *)(&stack0x0000002c + lVar14) = uVar25;
                    if ((**(byte **)((longlong)&pbStackX_20 + lVar14) & 0x10) != 0) {
                      *(uint *)(&stack0x0000002c + lVar14) =
                           uVar25 + 2 +
                           (*(ushort *)(*(byte **)((longlong)&pbStackX_20 + lVar14) + uVar25) + 7 >>
                           3);
                    }
                    if ((**(byte **)((longlong)&pbStackX_20 + lVar14) & 0x20) == 0) {
                      uVar25 = *(uint *)(&stack0x0000002c + lVar14);
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25;
                      *(undefined2 *)(&stack0x00000034 + lVar14) = 0;
                      *(uint *)(&stack0x00000030 + lVar14) = uVar25;
                    }
                    else {
                      puVar38 = (ushort *)
                                (*(byte **)((longlong)&pbStackX_20 + lVar14) +
                                *(uint *)(&stack0x0000002c + lVar14));
                      uVar41 = *puVar38;
                      *(ushort *)(&stack0x00000034 + lVar14) = uVar41;
                      if (uVar41 == 0) {
                        *(undefined8 *)(puVar34 + -8) = 0x100475;
                        cVar10 = func_0x(0x1f04110);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar34 + -8) = 0x10047e;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar34 + -8) = 0x100498;
                            cVar10 = func_0x(0x1f04110);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar34 + -8) = 0x1004b4;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x1004d7;
                              (*_DAT_)(1,0x17f4e98,0x1914b68,0x80f);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                        *(undefined8 *)(puVar34 + -8) = 0x1004e5;
                        func_0x(uVar19,3);
                        uVar41 = *(ushort *)(&stack0x00000034 + lVar14);
                      }
                      uVar32 = *(int *)(&stack0x0000002c + lVar14) + 2 + (uint)uVar41 * 2;
                      *(uint *)(&stack0x00000030 + lVar14) = uVar32;
                      if (0x1f9e < uVar32) {
                        *(undefined8 *)(puVar34 + -8) = 0x100515;
                        cVar10 = func_0x(0x1f04110);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar34 + -8) = 0x10051e;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar34 + -8) = 0x100538;
                            cVar10 = func_0x(0x1f04110);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar34 + -8) = 0x100554;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x100577;
                              (*_DAT_)(1,0x17f4e98,0x1914b68,0x816);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                        *(undefined8 *)(puVar34 + -8) = 0x100585;
                        func_0x(uVar19,4);
                        uVar41 = *(ushort *)(&stack0x00000034 + lVar14);
                        uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                      }
                      uVar36 = (ulonglong)uVar41;
                      uVar25 = puVar38[uVar36] & 0x7fff;
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25;
                      if (uVar25 < uVar32) {
                        *(undefined8 *)(puVar34 + -8) = 0x1005b3;
                        cVar10 = func_0x(0x1f04110);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar34 + -8) = 0x1005bc;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar34 + -8) = 0x1005d6;
                            cVar10 = func_0x(0x1f04110);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar34 + -8) = 0x1005f2;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar34 + 0x20) = 0;
                              *(undefined8 *)(puVar34 + -8) = 0x100615;
                              (*_DAT_)(1,0x17f4e98,0x1914b68,0x81d);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                        *(undefined8 *)(puVar34 + -8) = 0x100623;
                        func_0x(uVar19,4);
                        uVar36 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar14);
                        uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                        uVar25 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                      }
                      do {
                        if (-1 < (short)puVar38[(ulonglong)((int)uVar36 - 1) + 1]) break;
                        lVar16 = (ulonglong)*(uint *)(&stack0x0000002c + lVar14) +
                                 *(longlong *)((longlong)&pbStackX_20 + lVar14);
                        uVar37 = uVar32;
                        if ((int)uVar36 != 1) {
                          uVar37 = *(ushort *)(lVar16 + -2 + uVar36 * 2) & 0x7fff;
                        }
                        if ((uVar37 < uVar32) ||
                           ((*(ushort *)(lVar16 + uVar36 * 2) & 0x7fff) < uVar37)) {
                          uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                          *(undefined8 *)(puVar34 + -8) = 0x10067a;
                          func_0x(uVar19,7);
                          uVar36 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar14);
                          uVar32 = *(uint *)(&stack0x00000030 + lVar14);
                          uVar25 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                        }
                        if ((uVar37 < uVar32) || (uVar25 < uVar37)) goto LAB_;
                        uVar41 = *(ushort *)
                                  ((ulonglong)uVar37 +
                                  *(longlong *)((longlong)&pbStackX_20 + lVar14));
                        if (uVar41 == 5) {
                          puVar38 = (ushort *)((longlong)&uStackX_18 + lVar14 + 2);
                          *puVar38 = *puVar38 | 2;
                          *(short *)(&stack0x00000034 + lVar14) = (short)uVar36 + -1;
                          *(short *)(&stack0x00000042 + lVar14) = (short)uVar37;
                          lVar16 = (ulonglong)(uVar37 & 0xffff) +
                                   *(longlong *)((longlong)&pbStackX_20 + lVar14);
                          uVar41 = *(ushort *)(lVar16 + 2);
                          uVar24 = *(ushort *)(&stack0x00000044 + lVar14);
                          if ((uVar41 >> 0xe & 1) == 0) {
                            uVar24 = uVar24 & 0xc7ff;
                          }
                          else {
                            uVar24 = uVar24 ^ (uVar24 ^ uVar41) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar14) = uVar24;
                          *(ushort *)(&stack0x00000044 + lVar14) =
                               uVar24 ^ (uVar24 ^ *(ushort *)(lVar16 + 2)) & 0x7ff;
                          break;
                        }
                        if (uVar41 < 0x400) break;
                        puVar18 = (ushort *)((longlong)&uStackX_18 + lVar14 + 2);
                        *puVar18 = *puVar18 | 1;
                        uVar41 = (short)uVar36 - 1;
                        uVar36 = (ulonglong)uVar41;
                        *(ushort *)(&stack0x00000034 + lVar14) = uVar41;
                      } while (uVar41 != 0);
                    }
                    if ((**(byte **)((longlong)&pbStackX_20 + lVar14) & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar14) = 0;
                    }
                    else {
                      *(uint *)(&stack0x0000003e + lVar14) = uVar25;
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25 + 0xe;
                      *(undefined8 *)(puVar34 + -8) = 0x100769;
                      uVar19 = func_0x((longlong)&uStackX_18 + lVar14 + 2);
                      *(undefined8 *)(puVar34 + -8) = 0x100778;
                      func_0x(uVar19,&stack0x000000f8 + lVar14);
                      *(undefined8 *)(puVar34 + -8) = 0x100784;
                      iVar12 = func_0x(&stack0x000000f8 + lVar14);
                      uVar25 = *(int *)((longlong)&uStackX_18 + lVar14 + 4) + iVar12;
                      *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar25;
                    }
                    if ((*(ulonglong *)(&stack0x00000036 + lVar14) != 0) &&
                       (*(ulonglong *)(&stack0x00000036 + lVar14) <
                        (ulonglong)uVar25 + *(longlong *)((longlong)&pbStackX_20 + lVar14))) {
                      *(undefined8 *)(puVar34 + -8) = 0x1007be;
                      cVar10 = func_0x(0x1f04110);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar34 + -8) = 0x1007c7;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar34 + -8) = 0x1007e1;
                          cVar10 = func_0x(0x1f04110);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar34 + -8) = 0x1007fd;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x100820;
                            (*_DAT_)(1,0x17f4e98,0x1914b68,0x877);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                      *(undefined8 *)(puVar34 + -8) = 0x10082e;
                      func_0x(uVar19,0x12);
                      uVar25 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                    }
                    if (0x3f3b < uVar25 - 1) {
                      *(undefined8 *)(puVar34 + -8) = 0x100849;
                      cVar10 = func_0x(0x1f04110);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar34 + -8) = 0x100852;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar34 + -8) = 0x10086c;
                          cVar10 = func_0x(0x1f04110);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar34 + -8) = 0x100888;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar34 + 0x20) = 0;
                            *(undefined8 *)(puVar34 + -8) = 0x1008ab;
                            (*_DAT_)(1,0x17f4e98,0x1914b68,0x87c);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar14);
                      *(undefined8 *)(puVar34 + -8) = 0x1008b9;
                      func_0x(uVar19,5);
                    }
                  }
LAB_:
                  uVar32 = *puVar33;
                  uVar25 = uVar32 + 1;
                  uVar37 = *(uint *)(&stack0x00000028 + lVar14);
                  if (uVar37 < uVar25) {
                    *(undefined8 *)(puVar34 + -8) = 0x1008dc;
                    func_0x((longlong)&uStackX_18 + lVar14 + 2,0,uVar25 - uVar37);
                    if ((1 << (**(byte **)((longlong)&pbStackX_20 + lVar14) & 0xe) & 0x1105U) != 0)
                    {
                      *(short *)(*(byte **)((longlong)&pbStackX_20 + lVar14) + 2) = (short)uVar25;
                    }
                    *(uint *)(&stack0x00000028 + lVar14) = uVar25;
                    uVar32 = *puVar33;
                  }
                  if (*(undefined **)(&stack0x000000a0 + lVar14) != (undefined *)0x0) {
                    *(undefined *)
                     ((longlong)(int)uVar32 + *(longlong *)((longlong)&pbStackX_20 + lVar14)) =
                         **(undefined **)(&stack0x000000a0 + lVar14);
                  }
                }
                else {
                  cVar10 = **(char **)(&stack0x000000c0 + lVar14);
                  uVar37 = uVar25 + 1;
                  uVar32 = *(uint *)(&stack0x00000028 + lVar14);
                  if (uVar32 < uVar37) {
                    *(undefined8 *)(puVar34 + -8) = 0x100364;
                    func_0x((longlong)&uStackX_18 + lVar14 + 2,0,uVar37 - uVar32);
                    pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                    if ((1 << (*pbVar30 & 0xe) & 0x1105U) != 0) {
                      *(short *)(pbVar30 + 2) = (short)uVar37;
                      pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                    }
                    *(uint *)(&stack0x00000028 + lVar14) = uVar37;
                    bVar23 = *(byte *)((longlong)puVar33 + 6);
                  }
                  else {
                    pbVar30 = *(byte **)((longlong)&pbStackX_20 + lVar14);
                  }
                  if (cVar10 == '\0') {
                    bVar23 = pbVar30[(int)uVar25] & ~(byte)(1 << (bVar23 & 7));
                  }
                  else {
                    bVar23 = pbVar30[(int)uVar25] | (byte)(1 << (bVar23 & 7));
                  }
                  pbVar30[(int)uVar25] = bVar23;
                }
              }
            }
            else {
              *(undefined8 *)(puVar34 + 0x20) = 0x1571378;
              *(undefined8 *)(puVar34 + -8) = 0x100317;
              (*_DAT_)(1,0x19761d0,0x19a2b10);
            }
          }
          puVar33 = puVar33 + 0x14;
          *(uint **)(&stack0x00000070 + lVar14) = puVar33;
          iVar12 = *(int *)(&stack0x000000b8 + lVar14);
          *(uint *)(&stack0x000000b8 + lVar14) = iVar12 + 1U;
        } while (iVar12 + 1U < *(uint *)(&stack0x000000d4 + lVar14));
        uVar25 = *(uint *)(&stack0x0000009c + lVar14);
      }
      if (uVar25 != 0) {
        lVar16 = *(longlong *)(&stack0x00000090 + lVar14);
        do {
          uVar36 = (ulonglong)uVar25;
          uVar32 = uVar25 - 1;
          if (*(int *)((ulonglong)uVar32 * 0x20 + 8 + lVar16) != 0) {
            *(ushort *)(&stack0x00000034 + lVar14) = (ushort)uVar25;
            iVar12 = *(int *)(&stack0x0000002c + lVar14) + 2 + uVar25 * 2;
            *(int *)(&stack0x00000030 + lVar14) = iVar12;
            *(int *)((longlong)&uStackX_18 + lVar14 + 4) = iVar12;
            **(byte **)((longlong)&pbStackX_20 + lVar14) =
                 **(byte **)((longlong)&pbStackX_20 + lVar14) | 0x20;
            uVar32 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
            if (uVar32 < 0x1f7d) {
              puVar39 = (ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000002c + lVar14) +
                        *(longlong *)((longlong)&pbStackX_20 + lVar14));
              *puVar39 = (ushort)uVar25;
              uVar32 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
            }
            if (uVar25 != 0) {
              puVar33 = (uint *)(lVar16 + 0xc);
              do {
                puVar39 = puVar39 + 1;
                uVar44 = (ulonglong)uVar32;
                lVar16 = *(longlong *)((longlong)&pbStackX_20 + lVar14);
                uVar25 = puVar33[-1];
                uVar32 = uVar32 + uVar25;
                *(uint *)((longlong)&uStackX_18 + lVar14 + 4) = uVar32;
                if (uVar32 < 0x1f7d) {
                  *puVar39 = (ushort)((*puVar33 & 1) << 0xf) | (ushort)uVar32 & 0x7fff;
                  uVar19 = *(undefined8 *)(puVar33 + -3);
                  *(undefined8 *)(puVar34 + -8) = 0x101ac8;
                  func_0x(uVar44 + lVar16,uVar25,uVar19,uVar25);
                  uVar32 = *(uint *)((longlong)&uStackX_18 + lVar14 + 4);
                }
                puVar33 = puVar33 + 8;
                uVar36 = uVar36 - 1;
              } while (uVar36 != 0);
            }
            break;
          }
          uVar25 = uVar32;
        } while (uVar32 != 0);
      }
    }
LAB_:
    param_3 = *(longlong *)(&stack0x00000080 + lVar14);
    param_1 = *(longlong **)(&stack0x00000058 + lVar14);
    puVar35 = puVar34;
  }
  else {
    if (bVar8) {
      lVar16 = 0x1f6c9a0;
      lVar15 = 0x1f5ef08;
    }
    else {
      lVar16 = 0x1f5f358;
      lVar15 = 0x1f5eed0;
    }
    if ((bVar23 & 1) == 0) {
      lVar16 = lVar15;
    }
    param_1[0x74] = lVar16;
    param_1[0x75] = 0;
    *(longlong **)((longlong)aplStackX_8 + lVar14) = param_1 + 0x52;
    *(undefined **)((longlong)&pbStackX_20 + lVar14 + -0x20) = &stack0x00000080 + lVar14;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar14) = 0x1f7c;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar14) = 0x1f9e;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar14) = &stack0x000003d8 + lVar14;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1020a4;
    func_0x(param_1 + 0x77,param_2,2,psVar1);
    puVar35 = &stack0xffffffffffffffc8 + lVar14;
  }
  puVar27 = (undefined8 *)0x0;
  lVar16 = *(longlong *)(&stack0x000000c8 + lVar14);
  *(undefined8 *)(puVar35 + -8) = 0x101e97;
  func_0x(lVar16);
  bVar23 = (&stack0x00000050)[lVar14];
  (&stack0x00000068)[lVar14] = (bVar23 ^ 1) * '\x02';
  lVar15 = *(longlong *)(lVar16 + 8);
  if ((((*(byte *)(lVar15 + 0x41) & 8) != 0) || ((*(byte *)(lVar15 + 0x108) & 0x40) != 0)) &&
     (*(longlong **)(lVar15 + 0x160) != (longlong *)0x0)) {
    lVar15 = **(longlong **)(lVar15 + 0x160);
    uVar25 = *(uint *)(lVar15 + 100);
    if (uVar25 != 0xffffffff) {
      puVar33 = *(uint **)(lVar15 + 8);
      if (uVar25 < *puVar33) {
        uVar32 = uVar25 / puVar33[9];
        uVar36 = (ulonglong)uVar25 % (ulonglong)puVar33[9];
        lVar15 = *(longlong *)(puVar33 + 4);
      }
      else {
        uVar32 = (uVar25 - *puVar33) / puVar33[0x11];
        uVar36 = (ulonglong)(uVar25 - *puVar33) % (ulonglong)puVar33[0x11];
        lVar15 = *(longlong *)(puVar33 + 0xc);
      }
      lVar15 = uVar36 * 0x1c0 + *(longlong *)(lVar15 + (ulonglong)uVar32 * 8);
      if (lVar15 != 0) {
        uVar11 = *(undefined2 *)(lVar15 + 0x38);
        *(undefined8 *)(puVar35 + -8) = 0x1020d9;
        func_0x(psVar1,lVar15,&stack0x00000068 + lVar14,uVar11);
      }
    }
  }
  if (param_1[0x8c] != 0) {
    *(undefined8 *)(puVar35 + -8) = 0x1020ef;
    uVar19 = func_0x();
    *(undefined8 *)(&stack0x000000e8 + lVar14) = uVar19;
    plVar5 = (longlong *)param_1[0x8c];
    lVar16 = param_1[0x8d];
    pcVar4 = *(code **)(*plVar5 + 0x18);
    *(undefined8 *)(puVar35 + -8) = 0x10210e;
    iVar12 = (*pcVar4)(plVar5,lVar16);
    if (iVar12 == 0) {
      pcVar4 = *(code **)(*param_1 + 0x220);
      *(undefined8 *)(puVar35 + -8) = 0x102123;
      iVar12 = (*pcVar4)(param_1,param_2);
      if (iVar12 != 0) {
        *(undefined8 *)(puVar35 + 0x20) = 0;
        *(undefined8 *)(puVar35 + -8) = 0x10214d;
        (*_DAT_)(1,0x19a5460,0x1979250,0x1e76);
      }
    }
    *(undefined8 *)(puVar35 + -8) = 0x10215c;
    (*_DAT_)(uVar19,1);
    goto LAB_;
  }
  *(undefined **)(puVar35 + 0x28) = &stack0x00000078 + lVar14;
  *(undefined8 *)(puVar35 + 0x20) = 0;
  *(undefined8 *)(puVar35 + -8) = 0x10217c;
  iVar12 = func_0x(param_1,psVar1,0,0);
  if (iVar12 == 0) {
    if ((DAT_ & 1) == 0) {
      lVar15 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar15 != 0) && (**(longlong **)(lVar15 + 0x38) != 0)) {
        *(undefined8 *)(puVar35 + -8) = 0x1021d3;
        iVar12 = (*_DAT_)();
        if (iVar12 != 0) goto LAB_;
      }
    }
    else {
LAB_:
      lVar15 = *(longlong *)(param_1[3] + 0xd0);
      puVar20 = puVar27;
      puVar42 = puVar27;
      if (lVar15 != 0) {
        puVar20 = *(undefined8 **)(lVar15 + 0x40);
        puVar42 = *(undefined8 **)(lVar15 + 0xf8);
      }
      uVar7 = *(uint6 *)(lVar16 + 0x14);
      uVar11 = *(undefined2 *)(*(longlong *)(param_1[3] + 0x30) + 0x6b8);
      *(undefined8 **)(puVar35 + 0x20) = puVar20;
      *(undefined8 *)(puVar35 + -8) = 0x10222d;
      func_0x(0x17febf0,uVar11,(ulonglong)uVar7 << 0x10,puVar42);
      *(undefined8 *)(puVar35 + -8) = 0x10223a;
      (*_DAT_)(&stack0x00000158 + lVar14);
      *(undefined8 *)(puVar35 + -8) = 0x102241;
      uVar19 = (*_DAT_)();
      *(undefined8 *)(puVar35 + -8) = 0x102252;
      lVar15 = (*_DAT_)(uVar19,0,0x6c0);
      *(longlong *)(&stack0x00000118 + lVar14) = lVar15;
      puVar20 = puVar27;
      if (lVar15 != 0) {
        *(undefined8 *)(puVar35 + -8) = 0x102268;
        puVar20 = (undefined8 *)func_0x(lVar15,0);
      }
      if (puVar20 != (undefined8 *)0x0) {
        *(undefined8 *)(puVar35 + -8) = 0x102285;
        iVar12 = (*_DAT_)(&stack0x00000158 + lVar14,puVar20);
        if (iVar12 == 0) {
          pcVar4 = *(code **)*puVar20;
          *(undefined8 *)(puVar35 + -8) = 0x102296;
          (*pcVar4)(puVar20,1);
        }
      }
      *(undefined8 *)(puVar35 + -8) = 0x1022a6;
      func_0x(psVar1);
      *(undefined8 *)(puVar35 + -8) = 0x1022b4;
      (*_DAT_)(&stack0x00000158 + lVar14);
    }
LAB_:
    lVar15 = *(longlong *)(lVar16 + 8);
    if ((((*(byte *)(lVar15 + 0x41) & 8) != 0) || ((*(byte *)(lVar15 + 0x108) & 0x40) != 0)) &&
       (*(longlong **)(lVar15 + 0x160) != (longlong *)0x0)) {
      lVar40 = **(longlong **)(lVar15 + 0x160);
      uVar25 = *(uint *)(lVar40 + 100);
      if (uVar25 != 0xffffffff) {
        puVar33 = *(uint **)(lVar40 + 8);
        if (uVar25 < *puVar33) {
          uVar36 = (ulonglong)uVar25 / (ulonglong)puVar33[9];
          uVar25 = uVar25 % puVar33[9];
          lVar40 = *(longlong *)(puVar33 + 4);
        }
        else {
          uVar25 = uVar25 - *puVar33;
          uVar36 = (ulonglong)uVar25 / (ulonglong)puVar33[0x11];
          uVar25 = uVar25 % puVar33[0x11];
          lVar40 = *(longlong *)(puVar33 + 0xc);
        }
        if ((ulonglong)uVar25 * 0x1c0 + *(longlong *)(lVar40 + uVar36 * 8) != 0) {
          if ((((*(longlong *)(lVar15 + 0x90) == 0) || (DAT_ == '\0')) ||
              (*(longlong *)(*(longlong *)(*(longlong *)(lVar15 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
             (*(uint *)(lVar15 + 0xf4) < 2)) {
            if (*(int *)(lVar15 + 0x480) == 0) {
              *(undefined8 *)(puVar35 + -8) = 0x10284e;
              func_0x(lVar15);
              lVar15 = *(longlong *)(lVar16 + 8);
            }
            if (*(longlong *)(lVar15 + 0x150) != 0) {
              lVar40 = (ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
              lVar16 = *(longlong *)(lVar40 + 0x100);
              if (lVar16 == 0) {
                *(undefined8 *)(puVar35 + -8) = 0x10288f;
                (*_DAT_)(0);
                lVar16 = *(longlong *)(lVar40 + 0x100);
              }
              if (*(longlong *)(lVar16 + 0x260) != 0) {
                puVar27 = (undefined8 *)(ulonglong)*(uint *)(*(longlong *)(lVar16 + 0x260) + 0xe68);
              }
              if ((uint)puVar27 < *(uint *)(_DAT_ + 8)) {
                lVar16 = *(longlong *)(*(longlong *)(lVar15 + 0x150) + (longlong)puVar27 * 8);
                *(longlong *)(lVar16 + 8) = *(longlong *)(lVar16 + 8) + 1;
                goto LAB_;
              }
            }
            LOCK();
            plVar5 = (longlong *)(*(longlong *)(lVar15 + 0x148) + 8);
            *plVar5 = *plVar5 + 1;
            UNLOCK();
          }
LAB_:
          *(undefined4 *)(&stack0x00000088 + lVar14) = 2;
          if (bVar23 != 0) {
            uVar19 = *(undefined8 *)(&stack0x00000078 + lVar14);
            *(undefined8 *)(puVar35 + -8) = 0x102901;
            func_0x(param_1,uVar19,4);
            uVar19 = *(undefined8 *)(&stack0x00000078 + lVar14);
            *(undefined8 *)(puVar35 + -8) = 0x10290d;
            func_0x(param_1,uVar19);
          }
          goto LAB_;
        }
      }
    }
    uVar19 = *(undefined8 *)(&stack0x00000078 + lVar14);
    *(undefined8 *)(puVar35 + -8) = 0x10291b;
    func_0x(param_1,uVar19);
    *(undefined4 *)(&stack0x00000088 + lVar14) = 4;
  }
  else {
    if (iVar12 != 1) goto LAB_;
    bVar8 = false;
    lVar16 = *(longlong *)(&stack0x00000078 + lVar14);
    uVar25 = *(uint *)(lVar16 + 0x10);
    uVar32 = uVar25 & 0xfffffeff;
    *(uint *)(lVar16 + 0x10) = uVar32;
    if (((char)uVar32 < '\0') || ((*(byte *)(lVar16 + 0x34) & 1) == 0)) {
      *(undefined8 *)(puVar35 + -8) = 0x10234a;
      psVar21 = (short *)func_0x(lVar16,0);
    }
    else if ((uVar25 >> 0xd & 1) == 0) {
      psVar21 = (short *)(lVar16 + 0x48);
    }
    else {
      psVar21 = *(short **)(lVar16 + 0x148);
    }
    pbVar30 = *(byte **)(psVar21 + 4);
    if (*psVar21 == 0) {
      bVar23 = *pbVar30 & 0xe;
      bVar45 = false;
      if (bVar23 == 2) {
        bVar45 = (pbVar30[1] & 1) != 0;
      }
      else if (((bVar23 - 10 & 0xf9) == 0) && (bVar23 != 0x10)) {
        bVar45 = true;
      }
    }
    else {
      bVar45 = ((*pbVar30 & 0x1c) - 4 & 0xffffffe7) == 0;
    }
    plVar5 = *(longlong **)(&stack0x00000058 + lVar14);
    if ((*(byte *)(param_3 + 0x14) & 0x10) != 0) {
      uVar19 = *(undefined8 *)(&stack0x00000078 + lVar14);
      pcVar4 = *(code **)(*plVar5 + 0x1c0);
      *(undefined8 *)(puVar35 + -8) = 0x1023b5;
      (*pcVar4)(plVar5,uVar19,param_3);
    }
    uVar19 = *(undefined8 *)(&stack0x000000c8 + lVar14);
    *(undefined8 *)(puVar35 + -8) = 0x1023c4;
    cVar10 = func_0x(uVar19,psVar21);
    if ((DAT_ & 1) == 0) {
      lVar15 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar15 != 0) && (lVar15 = **(longlong **)(lVar15 + 0x38), lVar15 != 0)) {
        *(undefined8 *)(puVar35 + -8) = 0x102417;
        iVar12 = (*_DAT_)(lVar15,600);
        if (iVar12 != 0) goto LAB_;
      }
    }
    else {
LAB_:
      lVar15 = *(longlong *)(plVar5[3] + 0xd0);
      puVar20 = puVar27;
      puVar42 = puVar27;
      if (lVar15 != 0) {
        puVar20 = *(undefined8 **)(lVar15 + 0x40);
        puVar42 = *(undefined8 **)(lVar15 + 0xf8);
      }
      uVar7 = *(uint6 *)(*(longlong *)(&stack0x000000c8 + lVar14) + 0x14);
      uVar11 = *(undefined2 *)(*(longlong *)(plVar5[3] + 0x30) + 0x6b8);
      *(undefined8 **)(puVar35 + 0x28) = puVar20;
      *(undefined8 **)(puVar35 + 0x20) = puVar42;
      *(undefined8 *)(puVar35 + -8) = 0x102480;
      func_0x(0x17feca0,uVar11,(ulonglong)uVar7 << 0x10,cVar10);
      *(undefined8 *)(puVar35 + -8) = 0x10248d;
      (*_DAT_)(&stack0x000001b8 + lVar14);
      *(undefined8 *)(puVar35 + -8) = 0x102494;
      uVar19 = (*_DAT_)();
      *(undefined8 *)(puVar35 + -8) = 0x1024a5;
      lVar15 = (*_DAT_)(uVar19,0,0x6c0);
      *(longlong *)(&stack0x000000e8 + lVar14) = lVar15;
      puVar20 = puVar27;
      if (lVar15 != 0) {
        *(undefined8 *)(puVar35 + -8) = 0x1024bb;
        puVar20 = (undefined8 *)func_0x(lVar15,0);
      }
      if (puVar20 != (undefined8 *)0x0) {
        *(undefined8 *)(puVar35 + -8) = 0x1024d8;
        iVar12 = (*_DAT_)(&stack0x000001b8 + lVar14,puVar20);
        if (iVar12 == 0) {
          pcVar4 = *(code **)*puVar20;
          *(undefined8 *)(puVar35 + -8) = 0x1024e9;
          (*pcVar4)(puVar20,1);
        }
      }
      *(undefined8 *)(puVar35 + -8) = 0x1024f9;
      func_0x(psVar1,&stack0x000001b8 + lVar14);
      *(undefined8 *)(puVar35 + -8) = 0x102507;
      (*_DAT_)(&stack0x000001b8 + lVar14);
    }
    if ((cVar10 != '\x04') && (bVar45)) {
      *(undefined8 *)(puVar35 + 0x20) = 0;
      *(undefined8 *)(puVar35 + -8) = 0x102539;
      (*_DAT_)(1,0x19a5428,0x1979250,0x1ec7);
    }
    bVar9 = bVar8;
    if ((&stack0x00000050)[lVar14] == '\0') {
      if (cVar10 == '\0') {
LAB_:
        *(undefined4 *)(&stack0x00000088 + lVar14) = 0;
        param_1 = *(longlong **)(&stack0x00000058 + lVar14);
        bVar9 = true;
        if (((*(uint *)param_1[0x21] & 0x800) == 0) || (*(int *)(param_1[0x5d] + 0x24) == 0)) {
          param_1 = *(longlong **)(&stack0x00000058 + lVar14);
        }
        else {
          param_1[0x36] = (longlong)psVar21;
          param_1[0x35] = lVar16;
          lVar16 = param_1[0x8a];
          if (lVar16 == 0) {
            *(undefined4 *)(&stack0x00000080 + lVar14) = 0x1f3c;
            puVar35[0x20] = 5;
            lVar16 = param_1[0x3e];
            *(undefined8 *)(puVar35 + -8) = 0x102630;
            puVar20 = (undefined8 *)(*_DAT_)(0x28,lVar16,0x158b958,0x1f3c);
            *(undefined8 **)(&stack0x000000e8 + lVar14) = puVar20;
            if (puVar20 != (undefined8 *)0x0) {
              *(undefined4 *)puVar20 = 0;
              puVar20[1] = 0;
              puVar20[2] = 0;
              puVar20[3] = 0;
              puVar20[4] = 0;
              puVar27 = puVar20;
            }
            param_1[0x8a] = (longlong)puVar27;
            lVar16 = param_1[0x5d];
            uVar19 = *(undefined8 *)(&stack0x000000b0 + lVar14);
            *(undefined8 *)(puVar35 + 0x30) = uVar19;
            *(undefined8 *)(puVar35 + 0x28) = *(undefined8 *)(lVar16 + 0x28);
            *(undefined8 *)(puVar35 + 0x20) = *(undefined8 *)(&stack0x000000c8 + lVar14);
            lVar15 = param_1[3];
            uVar13 = *(undefined4 *)(lVar16 + 0x24);
            lVar16 = param_1[0x3e];
            *(undefined8 *)(puVar35 + -8) = 0x10272e;
            func_0x(puVar27,lVar16,uVar13,lVar15);
            lVar16 = param_1[0x8a];
          }
          else {
            uVar19 = *(undefined8 *)(&stack0x000000b0 + lVar14);
          }
          lVar15 = param_1[0x5d];
          *(undefined8 *)(puVar35 + 0x30) = uVar19;
          *(undefined8 *)(puVar35 + 0x28) = *(undefined8 *)(lVar15 + 0x28);
          uVar13 = *(undefined4 *)(lVar15 + 0x24);
          *(undefined8 *)(puVar35 + -8) = 0x10275c;
          func_0x(lVar16,lVar15,uVar13);
          uVar19 = *(undefined8 *)(param_1[0x8a] + 8);
          uVar6 = *(undefined8 *)(param_1[0x8a] + 0x10);
          *(undefined8 *)(puVar35 + -8) = 0x102773;
          iVar12 = func_0x(param_1 + 0x32,uVar6,uVar19);
          if (iVar12 == 0) {
            uVar19 = *(undefined8 *)(&stack0x00000078 + lVar14);
            *(undefined8 *)(puVar35 + -8) = 0x102786;
            func_0x(param_1,uVar19,1);
            *(undefined4 *)(&stack0x00000088 + lVar14) = 2;
            bVar9 = bVar8;
          }
        }
      }
      else if (cVar10 == '\x02') {
        param_1 = *(longlong **)(&stack0x00000058 + lVar14);
        if ((*(uint *)param_1[0x21] & 0x800) != 0) {
          *(undefined4 *)(&stack0x00000088 + lVar14) = 5;
        }
      }
      else {
        if (cVar10 != '\x01') {
          *(undefined8 *)(puVar35 + 0x20) = 0;
          *(undefined8 *)(puVar35 + -8) = 0x10269a;
          (*_DAT_)(1,0x19a54a8,0x1979250,0x1ed4);
        }
        uVar19 = *(undefined8 *)(&stack0x00000078 + lVar14);
        param_1 = *(longlong **)(&stack0x00000058 + lVar14);
        *(undefined8 *)(puVar35 + -8) = 0x1026ad;
        func_0x(param_1,uVar19,2);
        *(undefined4 *)(&stack0x00000088 + lVar14) = 3;
      }
    }
    else {
      if (cVar10 != '\x04') {
        if (cVar10 == '\0') {
          uVar19 = *(undefined8 *)(&stack0x00000078 + lVar14);
          uVar6 = *(undefined8 *)(&stack0x00000058 + lVar14);
          *(undefined8 *)(puVar35 + -8) = 0x1025b4;
          func_0x(uVar6,uVar19,4);
          goto LAB_;
        }
        *(undefined8 *)(puVar35 + 0x20) = 0;
        *(undefined8 *)(puVar35 + -8) = 0x10257a;
        (*_DAT_)(1,0x19a54d0,0x1979250,0x1ec9);
      }
      param_1 = *(longlong **)(&stack0x00000058 + lVar14);
      if (bVar45) {
        *(uint *)(&stack0x00000088 + lVar14) = (*(uint *)param_1[0x21] & 0x800 | 0x200) >> 9;
      }
      else {
        *(undefined4 *)(&stack0x00000088 + lVar14) = 0;
        bVar9 = true;
      }
    }
    if (*(int *)((longlong)param_1 + 0x1cc) != 0) {
      param_1[0x74] = (longlong)psVar1;
      param_1[0x75] = 0;
      lVar16 = *(longlong *)(&stack0x00000110 + lVar14);
      *(undefined8 *)(puVar35 + -8) = 0x1027c9;
      func_0x(param_1 + 0x77,lVar16 + 0x78);
    }
    if (bVar9) {
      uVar19 = *(undefined8 *)(&stack0x00000078 + lVar14);
      *(undefined8 *)(puVar35 + -8) = 0x1027de;
      func_0x(param_1,uVar19);
    }
  }
LAB_:
  uVar19 = *(undefined8 *)(&stack0x00000078 + lVar14);
  pcVar4 = *(code **)(*param_1 + 0x20);
  *(undefined8 *)(puVar35 + -8) = 0x10292f;
  (*pcVar4)(param_1,uVar19);
LAB_:
  uVar36 = *(ulonglong *)(&stack0x00002378 + lVar14);
  *(undefined8 *)(puVar35 + -8) = 0x102941;
  func_0x(uVar36 ^ (ulonglong)psVar1);
  return;
code_r0x00101e78:
  uVar25 = uVar32;
  if (uVar32 == 0) goto LAB_;
  goto LAB_;
}

