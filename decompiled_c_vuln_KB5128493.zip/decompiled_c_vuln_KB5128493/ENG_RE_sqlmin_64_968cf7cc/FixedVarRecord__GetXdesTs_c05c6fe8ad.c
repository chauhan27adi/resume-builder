
undefined4 * FUN_(longlong param_1,undefined4 *param_2)

{
  undefined2 uVar1;
  code *pcVar2;
  longlong lVar3;
  undefined4 *puVar4;
  
  if (*(int *)(param_1 + 2) != 0) {
    lVar3 = func_0x(param_1);
    *param_2 = 0;
    *(undefined2 *)(param_2 + 1) = 0;
    if (lVar3 != 0) {
      uVar1 = *(undefined2 *)(lVar3 + 0xc);
      *param_2 = *(undefined4 *)(lVar3 + 8);
      *(undefined2 *)(param_2 + 1) = uVar1;
    }
    return param_2;
  }
  pcVar2 = (code *)swi(3);
  puVar4 = (undefined4 *)(*pcVar2)();
  return puVar4;
}

