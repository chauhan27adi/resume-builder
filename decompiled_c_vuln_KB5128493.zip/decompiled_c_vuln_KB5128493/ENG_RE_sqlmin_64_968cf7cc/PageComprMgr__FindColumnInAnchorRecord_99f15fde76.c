
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_(longlong param_1,undefined (*param_2) [16],int *param_3)

{
  ushort *puVar1;
  byte *pbVar2;
  longlong *plVar3;
  byte bVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  ulonglong *puVar8;
  longlong lVar9;
  longlong lVar10;
  ushort uVar11;
  short sVar12;
  uint uVar13;
  ulonglong uVar14;
  longlong lVar15;
  uint uVar16;
  ushort uVar17;
  ushort *puVar18;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  undefined auStackX_10 [8];
  undefined auStack_48 [6];
  byte bStack_42;
  int *piStack_40;
  
  _auStack_48 = *param_2;
  uVar17 = SUB162(_auStack_48,6);
  if ((SUB168(_auStack_48,0) >> 0x30 & 0x10) != 0) {
    uVar17 = 0;
    _auStack_48 = SUB168(_auStack_48,0) & 0xffefffffffffffff;
    piStack_40 = (int *)0x0;
  }
  if (*(longlong *)(param_1 + 8) != 0) {
    piVar7 = (int *)func_0x(*(longlong *)(param_1 + 8) + 0x18,auStack_48);
    return piVar7;
  }
  puVar1 = (ushort *)(param_1 + 0x12);
  iVar6 = 0;
  if (*(short *)(param_1 + 0x10) != 0) {
    auStackX_8[0] = 0;
    piVar7 = (int *)func_0x(puVar1,auStack_48,param_3,param_3,auStackX_8);
    if (*(short *)(param_1 + 0x10) == 0) {
      return piVar7;
    }
    plVar3 = *(longlong **)(param_1 + 0x20);
    if (plVar3 == (longlong *)0x0) {
      return piVar7;
    }
    if (*plVar3 == 0) {
      return piVar7;
    }
    if ((_auStack_48 & (undefined  [16])0x8000000000000) != (undefined  [16])0x0) {
      return piVar7;
    }
    if ((auStackX_8[0] & 1) != 0) {
      return piVar7;
    }
    if ((piVar7 != (int *)0x0) && (piVar7 != (int *)0x774084)) {
      piVar7 = (int *)func_0x
                                (plVar3,auStack_48,piVar7,*param_3,0,0,param_3,auStackX_8[0]);
      return piVar7;
    }
LAB_:
    *param_3 = 0;
    return (int *)0x0;
  }
  if ((auStack_48._0_4_ & 0xc0000000) == 0x80000000) {
    iVar6 = func_0x(puVar1);
    if (iVar6 != 0) {
      piVar7 = (int *)func_0x(param_1 + 0x3a,auStack_48,param_3,auStackX_10);
      return piVar7;
    }
    goto LAB_;
  }
  pbVar2 = *(byte **)(param_1 + 0x18);
  bVar4 = *pbVar2;
  iVar5 = iVar6;
  if ((bVar4 & 0x10) == 0) {
    if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
      uVar17 = ~(uVar17 >> 4);
      goto LAB_;
    }
  }
  else {
    uVar13 = *(uint *)(param_1 + 0x20);
    if ((int)auStack_48._0_4_ < (int)uVar13) {
      if ((uint)*(ushort *)(pbVar2 + uVar13) < (uint)(ushort)auStack_48._4_2_) {
        uVar17 = ~(uVar17 >> 4);
      }
      else {
        uVar16 = (ushort)auStack_48._4_2_ - 1;
        iVar5 = 1;
        uVar17 = (ushort)(pbVar2[(ulonglong)uVar13 + (ulonglong)(uVar16 >> 3) + 2] >>
                         ((byte)uVar16 & 7));
      }
    }
    else {
      uVar17 = ~(uVar17 >> 4);
    }
LAB_:
    if ((uVar17 & 1) != 0) {
      *param_3 = 0;
      return (int *)0x0;
    }
    if ((iVar5 == 0) && ((_auStack_48 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0))
    goto LAB_;
  }
  if (-1 < (int)auStack_48._0_4_) {
    if ((_auStack_48 & (undefined  [16])0x8000000000000) != (undefined  [16])0x0) {
      bVar4 = pbVar2[(int)auStack_48._0_4_];
      *param_3 = 1;
      if ((bVar4 & (byte)(1 << (bStack_42 & 7))) != 0) {
        return (int *)0x774084;
      }
      return (int *)0x7746a8;
    }
    if ((_auStack_48 & (undefined  [16])0x10000000000000) == (undefined  [16])0x0) {
LAB_:
      *param_3 = 0;
      return (int *)((longlong)(int)auStack_48._0_4_ + *(longlong *)(param_1 + 0x18));
    }
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
        *param_3 = *piStack_40;
        return piStack_40 + 1;
      }
      goto LAB_;
    }
    if (((int)auStack_48._0_4_ < (int)*(uint *)(param_1 + 0x20)) &&
       ((ushort)auStack_48._4_2_ <= *(ushort *)(pbVar2 + *(uint *)(param_1 + 0x20))))
    goto LAB_;
    goto LAB_;
  }
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar13 = *(uint *)(param_1 + 0x20);
    uVar14 = (ulonglong)uVar13;
    *(uint *)(param_1 + 0x24) = uVar13;
    *puVar1 = 0;
    bVar4 = *pbVar2;
    if ((bVar4 & 0x10) != 0) {
      uVar13 = uVar13 + 2 + (*(ushort *)(pbVar2 + uVar14) + 7 >> 3);
      uVar14 = (ulonglong)uVar13;
      *(uint *)(param_1 + 0x24) = uVar13;
      bVar4 = *pbVar2;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(param_1 + 0x14) = (int)uVar14;
      *(undefined2 *)(param_1 + 0x2c) = 0;
      *(int *)(param_1 + 0x28) = (int)uVar14;
    }
    else {
      puVar18 = (ushort *)(pbVar2 + uVar14);
      uVar17 = *puVar18;
      *(ushort *)(param_1 + 0x2c) = uVar17;
      if (uVar17 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar10 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar10 != 0)) &&
           ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
            (*(char *)(lVar10 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9ef648,0xb0f318,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 0x18),3);
        uVar17 = *(ushort *)(param_1 + 0x2c);
        uVar14 = (ulonglong)*(uint *)(param_1 + 0x24);
      }
      uVar13 = (int)uVar14 + (uVar17 + 1) * 2;
      *(uint *)(param_1 + 0x28) = uVar13;
      if (0x1f9e < uVar13) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar10 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar10 != 0 &&
            ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
             (*(char *)(lVar10 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ef648,0xb0f318,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 0x18),4);
        uVar17 = *(ushort *)(param_1 + 0x2c);
        uVar13 = *(uint *)(param_1 + 0x28);
      }
      uVar14 = (ulonglong)uVar17;
      uVar17 = puVar18[uVar14];
      *(uint *)(param_1 + 0x14) = uVar17 & 0x7fff;
      if ((uVar17 & 0x7fff) < uVar13) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar10 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar10 != 0)) &&
           ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
            (*(char *)(lVar10 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ef648,0xb0f318,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 0x18),4);
        uVar14 = (ulonglong)*(ushort *)(param_1 + 0x2c);
      }
      if ((short)puVar18[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
        lVar10 = *(longlong *)(param_1 + 0x18);
        do {
          lVar15 = (ulonglong)*(uint *)(param_1 + 0x24) + lVar10;
          if ((int)uVar14 == 1) {
            uVar13 = *(uint *)(param_1 + 0x28);
            uVar16 = uVar13;
LAB_:
            if ((*(ushort *)(lVar15 + uVar14 * 2) & 0x7fff) < uVar13) goto LAB_;
          }
          else {
            uVar16 = *(uint *)(param_1 + 0x28);
            uVar13 = *(ushort *)(lVar15 + -2 + uVar14 * 2) & 0x7fff;
            if (uVar16 <= uVar13) goto LAB_;
LAB_:
            func_0x(lVar10,7);
            uVar16 = *(uint *)(param_1 + 0x28);
          }
          if ((uVar13 < uVar16) || (*(uint *)(param_1 + 0x14) < uVar13)) goto LAB_;
          lVar10 = *(longlong *)(param_1 + 0x18);
          if (*(ushort *)(lVar10 + (ulonglong)uVar13) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(param_1 + 0x2c) = *(short *)(param_1 + 0x2c) + -1;
            uVar17 = *(ushort *)(param_1 + 0x3c) & 0xc7ff;
            *(short *)(param_1 + 0x3a) = (short)uVar13;
            lVar10 = (ulonglong)(uVar13 & 0xffff) + *(longlong *)(param_1 + 0x18);
            if ((*(ushort *)(lVar10 + 2) & 0x4000) != 0) {
              uVar17 = *(ushort *)(lVar10 + 2) & 0x3800 | uVar17;
            }
            *(ushort *)(param_1 + 0x3c) = uVar17;
            *(ushort *)(param_1 + 0x3c) = (uVar17 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar17;
            break;
          }
          if (*(ushort *)(lVar10 + (ulonglong)uVar13) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar17 = *(short *)(param_1 + 0x2c) - 1;
          *(ushort *)(param_1 + 0x2c) = uVar17;
          if ((uVar17 == 0) ||
             (uVar14 = (ulonglong)uVar17, -1 < (short)puVar18[(ulonglong)(uVar17 - 1) + 1]))
          goto LAB_;
        } while( true );
      }
      uVar14 = (ulonglong)*(uint *)(param_1 + 0x14);
    }
    goto LAB_;
  }
LAB_:
  sVar12 = -auStack_48._0_2_;
  if ((_auStack_48 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
    bVar4 = **(byte **)(param_1 + 0x18);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
        *param_3 = *piStack_40;
        return piStack_40 + 1;
      }
    }
    else if (((int)*(uint *)(param_1 + 0x20) <= (int)auStack_48._0_4_) ||
            (*(ushort *)(*(byte **)(param_1 + 0x18) + *(uint *)(param_1 + 0x20)) <
             (ushort)auStack_48._4_2_)) goto LAB_;
  }
  lVar10 = (longlong)sVar12;
  if ((uint)*(ushort *)(param_1 + 0x2c) < (uint)(int)sVar12) {
    *param_3 = 0;
    return *(int **)(param_1 + 0x18);
  }
  lVar15 = *(longlong *)(param_1 + 0x18);
  lVar9 = (ulonglong)*(uint *)(param_1 + 0x24) + lVar15;
  if (sVar12 == 1) {
    uVar13 = *(uint *)(param_1 + 0x28);
    uVar16 = *(ushort *)(lVar9 + lVar10 * 2) & 0x7fff;
LAB_:
    if (uVar13 <= uVar16) goto LAB_;
  }
  else {
    uVar13 = *(ushort *)(lVar9 + -2 + lVar10 * 2) & 0x7fff;
    lVar15 = *(longlong *)(param_1 + 0x18);
    uVar16 = *(ushort *)(lVar9 + lVar10 * 2) & 0x7fff;
    if (*(uint *)(param_1 + 0x28) <= uVar13) goto LAB_;
  }
  func_0x(lVar15,7);
LAB_:
  *param_3 = uVar16 - uVar13;
  return (int *)((ulonglong)uVar13 + *(longlong *)(param_1 + 0x18));
LAB_:
  uVar14 = (ulonglong)*(uint *)(param_1 + 0x14);
LAB_:
  if ((**(byte **)(param_1 + 0x18) & 0x40) == 0) {
    *(undefined4 *)(param_1 + 0x36) = 0;
  }
  else {
    *(int *)(param_1 + 0x36) = (int)uVar14;
    *(int *)(param_1 + 0x14) = (int)uVar14 + 0xe;
    puVar8 = (ulonglong *)func_0x(puVar1);
    uVar14 = *puVar8;
    uVar11 = (ushort)(uVar14 >> 0x30);
    uVar17 = uVar11;
    if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
      uVar17 = uVar11 & 0xdfff;
      if ((uVar14 & 0x4000000000000000) != 0) {
        uVar17 = uVar11 | 0x2000;
      }
    }
    if (uVar17 == 0xfffc) {
      iVar6 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + iVar6;
    uVar14 = (ulonglong)*(uint *)(param_1 + 0x14);
  }
  iVar6 = (int)uVar14;
  if ((*(ulonglong *)(param_1 + 0x2e) != 0) &&
     (*(ulonglong *)(param_1 + 0x2e) < uVar14 + *(longlong *)(param_1 + 0x18))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar10 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar10 != 0 &&
         (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
        (*(char *)(lVar10 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x9ef648,0xb0f318,0x877,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 0x18),0x12);
    iVar6 = *(int *)(param_1 + 0x14);
  }
  if (0x3f3b < iVar6 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar10 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar10 != 0 &&
        ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x9ef648,0xb0f318,0x87c,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 0x18),5);
  }
  goto LAB_;
}

