
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,undefined8 param_3,longlong **param_4)

{
  undefined4 *puVar1;
  byte bVar2;
  short sVar3;
  undefined8 uVar4;
  uint *puVar5;
  char cVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  short *psVar11;
  ushort uVar12;
  uint uVar13;
  int iVar14;
  code *UNRECOVERED_JUMPTABLE_00;
  int iVar15;
  byte **ppbVar16;
  undefined8 *puVar17;
  byte *pbVar18;
  undefined2 uVar19;
  longlong *plVar20;
  ulonglong uVar21;
  ushort uVar22;
  undefined4 uVar23;
  undefined4 auStackX_20 [2];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  puVar1 = (undefined4 *)((longlong)auStackX_20 + lVar7);
  *(undefined8 *)(&stack0x000001c0 + lVar7) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002fc0 + lVar7) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined8 *)(&stack0x00000168 + lVar7) = param_3;
  *(undefined8 *)(&stack0x00000150 + lVar7) = param_2;
  *(longlong *)(&stack0x00000040 + lVar7) = *(longlong *)(&stack0x00003048 + lVar7);
  iVar15 = 0;
  *puVar1 = 0;
  *(uint *)(&stack0x00000038 + lVar7) = (uint)*(ushort *)(**param_1 + 0x16);
  *(undefined (*) [16])(&stack0x00000ba0 + lVar7) = ZEXT816(0);
  *(undefined2 *)(&stack0x00000bb0 + lVar7) = 0xffff;
  *(undefined8 *)(&stack0x00000bb8 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000bb4 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000bce + lVar7) = 0;
  *(undefined8 *)(&stack0x00000bd8 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000bc0 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000be8 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000c00 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000c08 + lVar7) = 0;
  *(undefined2 *)(&stack0x00000c12 + lVar7) = 0;
  *(undefined2 *)(&stack0x000001d0 + lVar7) = 0;
  *(undefined4 *)(&stack0x000002d0 + lVar7) = 0;
  *(undefined2 *)(&stack0x000002e0 + lVar7) = 0;
  *(undefined8 *)(&stack0x000002d8 + lVar7) = 0;
  *(undefined8 *)(&stack0x000002e8 + lVar7) = 0;
  *(undefined2 *)(&stack0x00000a70 + lVar7) = 0xffff;
  *(undefined8 *)(&stack0x00000a78 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000a74 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000a8e + lVar7) = 0;
  *(undefined8 *)(&stack0x00000a98 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000a80 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000aa4 + lVar7) = 0xffffffff;
  *(undefined2 *)(&stack0x00000b20 + lVar7) = 0xffff;
  *(undefined8 *)(&stack0x00000b28 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000b24 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000b3e + lVar7) = 0;
  *(undefined8 *)(&stack0x00000b48 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000b30 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000b58 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000b60 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000178 + lVar7) =
       *(undefined8 *)(*(longlong *)(&stack0x00003048 + lVar7) + 0x30);
  plVar20 = *param_1;
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100173;
  lVar8 = func_0x(_DAT_,plVar20,1,0);
  *(longlong *)(&stack0x00000180 + lVar7) = lVar8;
  *(ushort *)(lVar8 + 4) = *(ushort *)(lVar8 + 4) & 0xedff;
  *(undefined4 *)(lVar8 + 0x40) = 1;
  plVar20 = *param_1;
  if (*(short *)((longlong)plVar20 + 0x2c) != 2) {
    lVar8 = plVar20[0x12];
    if (lVar8 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1001b1;
      func_0x(plVar20);
      lVar8 = plVar20[0x12];
      plVar20 = *param_1;
    }
    if (((*(byte *)(*(longlong *)(lVar8 + 0x6b0) + 0x3c) & 1) != 0) &&
       (*(longlong *)(*(longlong *)(lVar8 + 0x6b0) + 0x280) == 0)) {
      lVar8 = plVar20[0x12];
      if (lVar8 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1001e7;
        func_0x(plVar20);
        lVar8 = plVar20[0x12];
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1001f3;
      cVar6 = func_0x(lVar8);
      if (cVar6 == '\0') goto LAB_;
    }
    plVar20 = *param_1;
    lVar8 = plVar20[0x12];
    if (lVar8 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100213;
      func_0x(plVar20);
      lVar8 = plVar20[0x12];
    }
    if ((*(byte *)(lVar8 + 0x1cd0) & 0x20) == 0) {
      lVar8 = **param_1;
      if (*(short *)(lVar8 + 0x24) == 0) {
LAB_:
        *(undefined8 *)(&stack0x00000050 + lVar7) = *(undefined8 *)(lVar8 + 0x28);
        uVar22 = *(ushort *)(lVar8 + 0x30);
        *(ushort *)(&stack0x00000058 + lVar7) = uVar22;
      }
      else {
        cVar6 = *(char *)(lVar8 + 1);
        if (cVar6 == '\v') {
          if (*(int *)(lVar8 + 0x18) != 99) {
LAB_:
            if (cVar6 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar6 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar8 + 0x18) != 99) goto LAB_;
        }
        *(undefined4 *)(&stack0x000000b0 + lVar7) = *(undefined4 *)(lVar8 + 0x20);
        *(undefined2 *)(&stack0x000000b4 + lVar7) = *(undefined2 *)(lVar8 + 0x24);
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100279;
        cVar6 = func_0x(&stack0x000000b0 + lVar7);
        if (cVar6 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100289;
        func_0x(lVar8,&stack0x00000050 + lVar7);
        uVar22 = *(ushort *)(&stack0x00000058 + lVar7);
      }
      plVar20 = *param_1;
      lVar8 = plVar20[0x12];
      if (lVar8 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1002bd;
        func_0x(plVar20);
        lVar8 = plVar20[0x12];
      }
      uVar19 = *(undefined2 *)((longlong)plVar20 + 0x74);
      uVar4 = *(undefined8 *)(lVar8 + 0x6a0);
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1002d8;
      lVar9 = func_0x(uVar4,uVar19,0);
      plVar20 = *param_1;
      lVar8 = plVar20[0x12];
      if (lVar8 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1002f6;
        func_0x(plVar20);
        lVar8 = plVar20[0x12];
        plVar20 = *param_1;
      }
      if (((*(int *)(*(longlong *)(lVar8 + 0x7a8) + 0x58) != 0) ||
          (*(uint *)(&stack0x00000050 + lVar7) < *(uint *)(lVar9 + 0x130))) ||
         ((*(uint *)(lVar9 + 0x130) == *(uint *)(&stack0x00000050 + lVar7) &&
          ((*(uint *)(&stack0x00000054 + lVar7) < *(uint *)(lVar9 + 0x134) ||
           ((*(uint *)(lVar9 + 0x134) == *(uint *)(&stack0x00000054 + lVar7) &&
            (uVar22 < *(ushort *)(lVar9 + 0x138))))))))) {
        lVar8 = plVar20[0x12];
        if (lVar8 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10034b;
          func_0x(plVar20);
          lVar8 = plVar20[0x12];
          plVar20 = *param_1;
        }
        if (((*(byte *)(*(longlong *)(lVar8 + 0x6b0) + 0x3c) & 1) == 0) ||
           (*(longlong *)(*(longlong *)(lVar8 + 0x6b0) + 0x280) != 0)) {
          lVar8 = plVar20[0x12];
          if (lVar8 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10040a;
            func_0x(plVar20);
            lVar8 = plVar20[0x12];
            plVar20 = *param_1;
          }
          lVar9 = *plVar20;
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100421;
          func_0x(lVar8,lVar9 + 0x20);
          goto LAB_;
        }
      }
      lVar8 = plVar20[0x12];
      if (lVar8 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100389;
        func_0x(plVar20);
        lVar8 = plVar20[0x12];
        plVar20 = *param_1;
      }
      lVar9 = *plVar20;
      if ((*(int *)(*(longlong *)(lVar8 + 0x7a8) + 0x110) != 0) &&
         (uVar13 = *(uint *)(lVar9 + 0x20) & 0xfffffff8, uVar13 != (uVar13 / 0x7cd00) * 0x7cd00)) {
        lVar8 = plVar20[0x12];
        if (lVar8 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1003d6;
          func_0x(plVar20);
          lVar8 = plVar20[0x12];
          lVar9 = **param_1;
        }
        uVar4 = *(undefined8 *)(lVar8 + 0x7a8);
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1003f4;
        func_0x(uVar4,lVar9 + 0x20);
      }
    }
  }
LAB_:
  lVar8 = **param_1;
  if ((*(ushort *)(lVar8 + 4) & 0x2000) != 0) {
    if (*(short *)(lVar8 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000060 + lVar7) = *(undefined8 *)(lVar8 + 0x28);
      uVar22 = *(ushort *)(lVar8 + 0x30);
      *(ushort *)(&stack0x00000068 + lVar7) = uVar22;
    }
    else {
      cVar6 = *(char *)(lVar8 + 1);
      if (cVar6 == '\v') {
        if (*(int *)(lVar8 + 0x18) != 99) {
LAB_:
          if (cVar6 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar6 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar8 + 0x18) != 99) goto LAB_;
      }
      *(undefined4 *)(&stack0x000000b8 + lVar7) = *(undefined4 *)(lVar8 + 0x20);
      *(undefined2 *)(&stack0x000000bc + lVar7) = *(undefined2 *)(lVar8 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10048f;
      cVar6 = func_0x(&stack0x000000b8 + lVar7);
      if (cVar6 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10049f;
      func_0x(lVar8,&stack0x00000060 + lVar7);
      uVar22 = *(ushort *)(&stack0x00000068 + lVar7);
    }
    plVar20 = *param_1;
    lVar8 = plVar20[0x12];
    if (lVar8 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1004d1;
      func_0x(plVar20);
      lVar8 = plVar20[0x12];
    }
    puVar5 = *(uint **)(*(longlong *)(lVar8 + 0x6b0) + 0x2c0);
    uVar13 = *(uint *)(&stack0x00000060 + lVar7);
    if ((((*(short *)((longlong)puVar5 + 10) != 2) || (uVar13 != 0)) && (uVar13 <= *puVar5)) &&
       ((uVar13 != *puVar5 ||
        ((*(uint *)(&stack0x00000064 + lVar7) <= puVar5[1] &&
         ((*(uint *)(&stack0x00000064 + lVar7) != puVar5[1] || (uVar22 <= *(ushort *)(puVar5 + 2))))
         ))))) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100515;
      func_0x(param_1);
    }
  }
  plVar20 = *param_4;
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10052a;
  lVar8 = func_0x(_DAT_,plVar20,1,0);
  *(ushort *)(lVar8 + 4) = *(ushort *)(lVar8 + 4) & 0xedff;
  *(undefined4 *)(lVar8 + 0x40) = 1;
  plVar20 = *param_4;
  if (*(short *)((longlong)plVar20 + 0x2c) != 2) {
    lVar8 = plVar20[0x12];
    if (lVar8 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10055a;
      func_0x(plVar20);
      lVar8 = plVar20[0x12];
      plVar20 = *param_4;
    }
    if (((*(byte *)(*(longlong *)(lVar8 + 0x6b0) + 0x3c) & 1) != 0) &&
       (*(longlong *)(*(longlong *)(lVar8 + 0x6b0) + 0x280) == 0)) {
      lVar8 = plVar20[0x12];
      if (lVar8 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10058f;
        func_0x(plVar20);
        lVar8 = plVar20[0x12];
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10059b;
      cVar6 = func_0x(lVar8);
      if (cVar6 == '\0') goto LAB_;
    }
    plVar20 = *param_4;
    lVar8 = plVar20[0x12];
    if (lVar8 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1005ba;
      func_0x(plVar20);
      lVar8 = plVar20[0x12];
    }
    if ((*(byte *)(lVar8 + 0x1cd0) & 0x20) == 0) {
      lVar8 = **param_4;
      if (*(short *)(lVar8 + 0x24) == 0) {
LAB_:
        *(undefined8 *)(&stack0x00000070 + lVar7) = *(undefined8 *)(lVar8 + 0x28);
        uVar22 = *(ushort *)(lVar8 + 0x30);
        *(ushort *)(&stack0x00000078 + lVar7) = uVar22;
      }
      else {
        cVar6 = *(char *)(lVar8 + 1);
        if (cVar6 == '\v') {
          if (*(int *)(lVar8 + 0x18) != 99) {
LAB_:
            if (cVar6 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar6 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar8 + 0x18) != 99) goto LAB_;
        }
        *(undefined4 *)(&stack0x000000c0 + lVar7) = *(undefined4 *)(lVar8 + 0x20);
        *(undefined2 *)(&stack0x000000c4 + lVar7) = *(undefined2 *)(lVar8 + 0x24);
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10061f;
        cVar6 = func_0x(&stack0x000000c0 + lVar7);
        if (cVar6 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10062f;
        func_0x(lVar8,&stack0x00000070 + lVar7);
        uVar22 = *(ushort *)(&stack0x00000078 + lVar7);
      }
      plVar20 = *param_4;
      lVar8 = plVar20[0x12];
      if (lVar8 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100662;
        func_0x(plVar20);
        lVar8 = plVar20[0x12];
      }
      uVar19 = *(undefined2 *)((longlong)plVar20 + 0x74);
      uVar4 = *(undefined8 *)(lVar8 + 0x6a0);
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10067d;
      lVar9 = func_0x(uVar4,uVar19,0);
      plVar20 = *param_4;
      lVar8 = plVar20[0x12];
      if (lVar8 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10069a;
        func_0x(plVar20);
        lVar8 = plVar20[0x12];
        plVar20 = *param_4;
      }
      if (((*(int *)(*(longlong *)(lVar8 + 0x7a8) + 0x58) != 0) ||
          (*(uint *)(&stack0x00000070 + lVar7) < *(uint *)(lVar9 + 0x130))) ||
         ((*(uint *)(lVar9 + 0x130) == *(uint *)(&stack0x00000070 + lVar7) &&
          ((*(uint *)(&stack0x00000074 + lVar7) < *(uint *)(lVar9 + 0x134) ||
           ((*(uint *)(lVar9 + 0x134) == *(uint *)(&stack0x00000074 + lVar7) &&
            (uVar22 < *(ushort *)(lVar9 + 0x138))))))))) {
        lVar8 = plVar20[0x12];
        if (lVar8 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1006ee;
          func_0x(plVar20);
          lVar8 = plVar20[0x12];
          plVar20 = *param_4;
        }
        if (((*(byte *)(*(longlong *)(lVar8 + 0x6b0) + 0x3c) & 1) == 0) ||
           (*(longlong *)(*(longlong *)(lVar8 + 0x6b0) + 0x280) != 0)) {
          lVar8 = plVar20[0x12];
          if (lVar8 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1007a6;
            func_0x(plVar20);
            lVar8 = plVar20[0x12];
            plVar20 = *param_4;
          }
          lVar9 = *plVar20;
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1007bc;
          func_0x(lVar8,lVar9 + 0x20);
          goto LAB_;
        }
      }
      lVar8 = plVar20[0x12];
      if (lVar8 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100727;
        func_0x(plVar20);
        lVar8 = plVar20[0x12];
        plVar20 = *param_4;
      }
      lVar9 = *plVar20;
      if ((*(int *)(*(longlong *)(lVar8 + 0x7a8) + 0x110) != 0) &&
         (uVar13 = *(uint *)(lVar9 + 0x20) & 0xfffffff8, uVar13 != (uVar13 / 0x7cd00) * 0x7cd00)) {
        lVar8 = plVar20[0x12];
        if (lVar8 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100773;
          func_0x(plVar20);
          lVar8 = plVar20[0x12];
          lVar9 = **param_4;
        }
        uVar4 = *(undefined8 *)(lVar8 + 0x7a8);
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100790;
        func_0x(uVar4,lVar9 + 0x20);
      }
    }
  }
LAB_:
  lVar8 = **param_4;
  if ((*(ushort *)(lVar8 + 4) & 0x2000) != 0) {
    if (*(short *)(lVar8 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000080 + lVar7) = *(undefined8 *)(lVar8 + 0x28);
      uVar22 = *(ushort *)(lVar8 + 0x30);
      *(ushort *)(&stack0x00000088 + lVar7) = uVar22;
    }
    else {
      cVar6 = *(char *)(lVar8 + 1);
      if (cVar6 == '\v') {
        if (*(int *)(lVar8 + 0x18) != 99) {
LAB_:
          if (cVar6 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar6 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar8 + 0x18) != 99) goto LAB_;
      }
      *(undefined4 *)(&stack0x000000c8 + lVar7) = *(undefined4 *)(lVar8 + 0x20);
      *(undefined2 *)(&stack0x000000cc + lVar7) = *(undefined2 *)(lVar8 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10081e;
      cVar6 = func_0x(&stack0x000000c8 + lVar7);
      if (cVar6 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10082e;
      func_0x(lVar8,&stack0x00000080 + lVar7);
      uVar22 = *(ushort *)(&stack0x00000088 + lVar7);
    }
    plVar20 = *param_4;
    lVar8 = plVar20[0x12];
    if (lVar8 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10085f;
      func_0x(plVar20);
      lVar8 = plVar20[0x12];
    }
    puVar5 = *(uint **)(*(longlong *)(lVar8 + 0x6b0) + 0x2c0);
    uVar13 = *(uint *)(&stack0x00000080 + lVar7);
    if ((((*(short *)((longlong)puVar5 + 10) != 2) || (uVar13 != 0)) && (uVar13 <= *puVar5)) &&
       ((uVar13 != *puVar5 ||
        ((*(uint *)(&stack0x00000084 + lVar7) <= puVar5[1] &&
         ((*(uint *)(&stack0x00000084 + lVar7) != puVar5[1] || (uVar22 <= *(ushort *)(puVar5 + 2))))
         ))))) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1008a3;
      func_0x(param_4);
    }
  }
  lVar8 = **param_4;
  uVar22 = *(ushort *)(lVar8 + 0x16);
  lVar9 = *(longlong *)(&stack0x00000040 + lVar7);
  if (*(char *)(*(longlong *)(lVar9 + 0x30) + 0x1cde) != '\0') {
    plVar20 = *param_1;
    lVar10 = plVar20[0x12];
    if (lVar10 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1008db;
      func_0x(plVar20);
      lVar10 = plVar20[0x12];
    }
    if (*(ushort *)(lVar10 + 0x67e) < 0x387) {
      uVar12 = (ushort)(byte)~(*(byte *)(*plVar20 + 2) >> 6);
    }
    else {
      uVar12 = (ushort)~*(ushort *)((longlong)plVar20 + 0x62) >> 8;
    }
    if ((uVar12 & 1) != 0) {
      *(undefined8 *)(&stack0x000000f0 + lVar7) = 0;
      (&stack0x000000f8)[lVar7] = 0;
      uVar13 = *(uint *)(&stack0x000000fc + lVar7);
      *(uint *)(&stack0x000000fc + lVar7) = uVar13 & 0xffff0000;
      *(uint *)(&stack0x000000fc + lVar7) = uVar13 & 0xff000000;
      *(undefined4 *)(&stack0x000000fc + lVar7) = 0;
      plVar20 = *param_4;
      uVar13 = *(uint *)(plVar20 + 0xe);
      iVar14 = ((uVar13 & 0xfffffff8) / 0x1f98) * 0x1f98;
      uVar19 = *(undefined2 *)((longlong)plVar20 + 0x74);
      *(int *)(&stack0x00000048 + lVar7) = iVar14;
      *(undefined2 *)(&stack0x0000004c + lVar7) = uVar19;
      if (iVar14 == 0) {
        *(undefined4 *)(&stack0x00000048 + lVar7) = 1;
      }
      lVar9 = plVar20[0x12];
      if (lVar9 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100989;
        func_0x(plVar20);
        lVar9 = plVar20[0x12];
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1009a6;
      func_0x(&stack0x000000f0 + lVar7,&stack0x00000048 + lVar7,2,lVar9);
      cVar6 = *(char *)((ulonglong)(uVar13 % 0x1f98) + 4 +
                       (ulonglong)*(ushort *)(**(longlong **)(&stack0x000000f0 + lVar7) + 0x1ffe) +
                       **(longlong **)(&stack0x000000f0 + lVar7));
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1009df;
      func_0x(&stack0x000000f0 + lVar7);
      if (cVar6 < '\0') {
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1009f1;
        func_0x(param_1,1,0);
      }
      lVar9 = *(longlong *)(&stack0x00000040 + lVar7);
    }
  }
  lVar10 = **param_4;
  if ((*(ushort *)(lVar10 + 4) & 0x2000) != 0) {
    *(undefined4 *)(&stack0x00000b78 + lVar7) = 0;
    *(undefined2 *)(&stack0x00000b7c + lVar7) = 0;
    *(undefined8 *)(&stack0x00000b80 + lVar7) = 0;
    *(undefined2 *)(&stack0x00000b88 + lVar7) = 0;
    *(undefined4 *)(&stack0x00000b8a + lVar7) = 0;
    *(undefined2 *)(&stack0x00000b8e + lVar7) = 0;
    *(undefined8 *)(&stack0x00000b90 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100a43;
    func_0x(&stack0x00000b68 + lVar7,lVar10,0,(ulonglong)uVar22);
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100a52;
    func_0x(&stack0x00000b68 + lVar7,lVar9);
  }
  *(undefined4 *)(&stack0x00000028 + lVar7) = 0;
  *(ulonglong *)(&stack0x00000170 + lVar7) = (ulonglong)uVar22;
  if (uVar22 == 0) {
    if (*(short *)(&stack0x000001d0 + lVar7) != 0) {
      puVar17 = (undefined8 *)(&stack0x000001d8 + lVar7);
      do {
        uVar4 = *puVar17;
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1020d9;
        (*_DAT_)(uVar4);
        iVar15 = iVar15 + 1;
        puVar17 = puVar17 + 1;
      } while (iVar15 < (int)(uint)*(ushort *)(&stack0x000001d0 + lVar7));
    }
    if (*(longlong *)(&stack0x000002d8 + lVar7) != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1020fc;
      (*_DAT_)();
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10210d;
    func_0x(*(ulonglong *)(&stack0x00002fc0 + lVar7) ^ (ulonglong)puVar1);
    return;
  }
  *(undefined8 *)(&stack0x000000e0 + lVar7) = 0;
  *(undefined2 *)(&stack0x00000188 + lVar7) = 0xffff;
  *(undefined8 *)(&stack0x00000190 + lVar7) = 0;
  *(undefined4 *)(&stack0x0000018c + lVar7) = 0;
  *(undefined8 *)(&stack0x000001a6 + lVar7) = 0;
  *(undefined8 *)(&stack0x000001b0 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000198 + lVar7) = 0;
  uVar23 = 0;
  *(undefined (*) [16])(&stack0x00000128 + lVar7) = ZEXT816(0);
  *(undefined4 *)(&stack0x00000aa4 + lVar7) = 0;
  if (-1 < *(char *)(lVar8 + 2)) goto LAB_;
  pbVar18 = (byte *)(lVar8 + 0x60);
  if ((*(short *)(&stack0x00000a70 + lVar7) == 0) ||
     (ppbVar16 = *(byte ***)(&stack0x00000a80 + lVar7), ppbVar16 == (byte **)0x0)) {
    *(undefined (*) [16])(&stack0x00000ab8 + lVar7) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000ac8 + lVar7) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000ad8 + lVar7) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000ae8 + lVar7) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000af8 + lVar7) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000b08 + lVar7) = ZEXT816(0);
    *(undefined8 *)(&stack0x00000b18 + lVar7) = 0;
    *(undefined (*) [16])(&stack0x00000aa8 + lVar7) = ZEXT816(0);
    *(undefined2 *)(&stack0x00000ab8 + lVar7) = 0xffff;
    *(undefined8 *)(&stack0x00000ac0 + lVar7) = 0;
    *(undefined4 *)(&stack0x00000abc + lVar7) = 0;
    *(undefined8 *)(&stack0x00000ad6 + lVar7) = 0;
    *(undefined8 *)(&stack0x00000ae0 + lVar7) = 0;
    *(undefined8 *)(&stack0x00000ac8 + lVar7) = 0;
    *(undefined8 *)(&stack0x00000af0 + lVar7) = 0;
    *(undefined8 *)(&stack0x00000b08 + lVar7) = 0;
    *(undefined4 *)(&stack0x00000b10 + lVar7) = 0;
    *(undefined2 *)(&stack0x00000b1a + lVar7) = 0;
    ppbVar16 = (byte **)(&stack0x00000aa8 + lVar7);
  }
  if (*(short *)(lVar8 + 0x24) == 0) {
LAB_:
    uVar23 = (undefined4)*(undefined8 *)(lVar8 + 0x28);
    *(undefined8 *)(&stack0x00000090 + lVar7) = *(undefined8 *)(lVar8 + 0x28);
    uVar19 = *(undefined2 *)(lVar8 + 0x30);
    *(undefined2 *)(&stack0x00000098 + lVar7) = uVar19;
  }
  else {
    cVar6 = *(char *)(lVar8 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(lVar8 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar8 + 0x18) != 99) goto LAB_;
    }
    *(undefined4 *)(&stack0x000000d0 + lVar7) = *(undefined4 *)(lVar8 + 0x20);
    *(undefined2 *)(&stack0x000000d4 + lVar7) = *(undefined2 *)(lVar8 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100bc6;
    cVar6 = func_0x(&stack0x000000d0 + lVar7);
    if (cVar6 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100bd6;
    uVar23 = func_0x(lVar8,&stack0x00000090 + lVar7);
    uVar19 = *(undefined2 *)(&stack0x00000098 + lVar7);
  }
  *ppbVar16 = pbVar18;
  uVar4 = *(undefined8 *)(&stack0x00000090 + lVar7);
  *(undefined4 *)(ppbVar16 + 0xc) = *(undefined4 *)(&stack0x00000090 + lVar7);
  *(int *)((longlong)ppbVar16 + 100) = (int)((ulonglong)uVar4 >> 0x20);
  *(undefined2 *)(ppbVar16 + 0xd) = uVar19;
  *(undefined4 *)((longlong)ppbVar16 + 0x6c) = *(undefined4 *)(lVar8 + 0x20);
  *(undefined2 *)(ppbVar16 + 0xe) = *(undefined2 *)(lVar8 + 0x24);
  *(undefined2 *)((longlong)ppbVar16 + 0x72) = 0;
  bVar2 = *pbVar18;
  *(undefined4 *)(&stack0x00000108 + lVar7) = *(undefined4 *)((ulonglong)bVar2 * 6 + 0x10e0490);
  uVar21 = (ulonglong)*(short *)((ulonglong)bVar2 * 6 + 0x10e0494);
  *(undefined2 *)(ppbVar16 + 2) = 0xffff;
  ppbVar16[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar16 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar16 + 0x2e) = 0;
  ppbVar16[7] = (byte *)0x0;
  ppbVar16[4] = (byte *)0x0;
  ppbVar16[9] = (byte *)0x0;
  ppbVar16[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar16 + 0xb) = 0;
  if ((**ppbVar16 & 2) != 0) {
    pbVar18 = pbVar18 + uVar21;
    if ((*pbVar18 & 1) == 0) {
      *(undefined2 *)(ppbVar16 + 2) = 0;
      ppbVar16[3] = pbVar18;
      *(undefined4 *)((longlong)ppbVar16 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar16 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100e23 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar18 & 0xe) * 4 + 0x102158) - 0x14599a0))
                ();
      return;
    }
    *(undefined2 *)(ppbVar16 + 2) = 1;
    ppbVar16[3] = pbVar18;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar18 & 0x1c) + 0x102138) * 4 +
                           0x102128) - 0x14599a0);
                    /* WARNING: Could not emulate address calculation at 0x00100c9d */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar16 & 4) != 0) {
    if (*(short *)(&stack0x0000010a + lVar7) != 0) {
      uVar21 = (ulonglong)
               *(ushort *)(lVar8 + 0x61 + (longlong)*(short *)(&stack0x0000010a + lVar7) * 2);
    }
    psVar11 = (short *)(pbVar18 + uVar21);
    ppbVar16[9] = (byte *)psVar11;
    sVar3 = *psVar11;
    ppbVar16[10] = (byte *)(psVar11 + 1);
    *(short *)(ppbVar16 + 0xb) = (sVar3 + 1) * 2;
  }
  pbVar18 = ppbVar16[1];
  if (pbVar18 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100ee2;
    uVar23 = func_0x(pbVar18,ppbVar16);
  }
LAB_:
  pbVar18 = (byte *)((ulonglong)
                     *(ushort *)(lVar8 + (0xfff - *(longlong *)(&stack0x000000e0 + lVar7)) * 2) +
                    lVar8);
  bVar2 = *pbVar18;
  *(byte **)(&stack0x00000a78 + lVar7) = pbVar18;
  if ((bVar2 & 1) == 0) {
    *(undefined2 *)(&stack0x00000a70 + lVar7) = 0;
    *(undefined4 *)(&stack0x00000a74 + lVar7) = 0;
    *(undefined4 *)(&stack0x00000a96 + lVar7) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001010fa */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar18 & 0xe) * 4 + 0x1021c4) - 0x14599a0))
              (uVar23,(longlong)(int)(*pbVar18 & 0xe),0);
    return;
  }
  *(undefined2 *)(&stack0x00000a70 + lVar7) = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar18 & 0x1c) + 0x1021a4) * 4 +
                         0x102194) - 0x14599a0);
                    /* WARNING: Could not emulate address calculation at 0x00100f3c */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbVar18,0x105fe88);
  return;
}

