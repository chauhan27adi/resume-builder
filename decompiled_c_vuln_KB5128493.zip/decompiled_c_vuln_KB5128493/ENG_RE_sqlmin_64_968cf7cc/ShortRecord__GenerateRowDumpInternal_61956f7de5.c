
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,longlong *param_3,ulonglong param_4,int *param_5)

{
  ushort *puVar1;
  uint6 uVar2;
  byte bVar3;
  ushort uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  undefined4 *puVar10;
  ulonglong *puVar11;
  longlong lVar12;
  longlong lVar13;
  ulonglong uVar14;
  undefined4 uVar15;
  int *piVar16;
  ushort *puVar17;
  ushort uVar18;
  ushort uVar19;
  uint uVar20;
  byte *pbVar21;
  ulonglong uVar22;
  int iVar23;
  longlong unaff_GS_OFFSET;
  longlong lStackX_10;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  
  param_4 = param_4 & 0xffffffff;
  puVar1 = (ushort *)(param_2 + 1);
  uStack_60 = 0;
  uStack_5c = (uint)(uStack_5c._2_2_ & 0xffe0) << 0x10;
  uStack_58 = 0;
  if (*param_2 == 0) {
    uVar5 = func_0x(puVar1);
  }
  else {
    uVar5 = (uint)*puVar1;
  }
  iVar6 = func_0x(param_2);
  uVar2 = *(uint6 *)(*(longlong *)(param_1 + 0x18) + 0x14);
  uVar15 = *(undefined4 *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 0x20) + 0x664);
  iVar7 = func_0x(param_2);
  if (*param_2 == 0) {
    uVar8 = func_0x(puVar1);
  }
  else {
    uVar8 = (uint)*puVar1;
  }
  iVar7 = (uVar8 + iVar7) * 10 + 0x10;
  func_0x(param_3,0,param_4);
  if (param_3 == (longlong *)0x0) {
    puVar10 = (undefined4 *)(*_DAT_)();
    *puVar10 = 0x16;
    (*_DAT_)();
    param_3 = (longlong *)0x8;
LAB_:
    if (param_4 - 8 < 4) {
      func_0x(param_3,0,param_4 - 8);
      puVar10 = (undefined4 *)(*_DAT_)();
      *puVar10 = 0x22;
      (*_DAT_)();
    }
    else {
      *(undefined4 *)param_3 = uVar15;
    }
    piVar16 = (int *)((longlong)param_3 + 4);
    if (piVar16 != (int *)0x0) goto LAB_;
    puVar10 = (undefined4 *)(*_DAT_)();
    *puVar10 = 0x16;
  }
  else {
    if (param_4 < 8) {
      func_0x(param_3,0,param_4);
      puVar10 = (undefined4 *)(*_DAT_)();
      *puVar10 = 0x22;
      (*_DAT_)();
    }
    else {
      *param_3 = (ulonglong)uVar2 << 0x10;
    }
    param_3 = param_3 + 1;
    if (param_3 != (longlong *)0x0) goto LAB_;
    puVar10 = (undefined4 *)(*_DAT_)();
    *puVar10 = 0x16;
    (*_DAT_)();
    piVar16 = (int *)0x4;
LAB_:
    if (3 < param_4 - 0xc) {
      *piVar16 = iVar6 + uVar5;
      goto LAB_;
    }
    func_0x(piVar16,0,param_4 - 0xc);
    puVar10 = (undefined4 *)(*_DAT_)();
    *puVar10 = 0x22;
  }
  (*_DAT_)();
LAB_:
  if (iVar6 + uVar5 != 0) {
    uVar14 = 0;
    uVar22 = uVar14;
    if (0 < (int)uVar5) {
      do {
        uVar8 = ~(uint)uVar14;
        if ((uVar8 & 0xc0000000) == 0x80000000) {
          puVar10 = (undefined4 *)
                    func_0x
                              (**(undefined8 **)
                                 (*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) + 0x160),
                               uVar8 & 0x1fffffff);
        }
        else {
          puVar10 = (undefined4 *)
                    func_0x
                              (*(undefined8 *)
                                (*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) + 0x160));
        }
        if (puVar10 == (undefined4 *)0x0) {
          uVar15 = 0xffffffff;
          func_0x(*(undefined8 *)(param_1 + 0x18),uVar8,&uStack_60);
        }
        else {
          uStack_60 = *puVar10;
          uStack_5c = puVar10[1];
          uStack_58 = *(undefined8 *)(puVar10 + 2);
          uVar15 = puVar10[0xf];
        }
        func_0x(param_2,uVar15,&uStack_60,(longlong)piVar16 + uVar22 * 10 + 4);
        uVar22 = (ulonglong)((int)uVar22 + 1);
        uVar8 = (uint)uVar14 + 1;
        uVar14 = (ulonglong)uVar8;
      } while ((int)uVar8 < (int)uVar5);
    }
    uVar5 = 0;
    if (0 < (longlong)iVar6) {
      lStackX_10 = 0;
      iVar23 = iVar7;
      do {
        if (*(int *)(param_2 + 2) == 0) {
          pbVar21 = *(byte **)(param_2 + 4);
          uVar8 = *(uint *)(param_2 + 8);
          uVar14 = (ulonglong)uVar8;
          *puVar1 = 0;
          *(uint *)(param_2 + 10) = uVar8;
          bVar3 = *pbVar21;
          if ((bVar3 & 0x10) != 0) {
            uVar8 = uVar8 + 2 + (*(ushort *)(pbVar21 + uVar14) + 7 >> 3);
            uVar14 = (ulonglong)uVar8;
            *(uint *)(param_2 + 10) = uVar8;
            bVar3 = *pbVar21;
          }
          if ((bVar3 & 0x20) == 0) {
            *(int *)(param_2 + 2) = (int)uVar14;
            param_2[0xe] = 0;
            *(int *)(param_2 + 0xc) = (int)uVar14;
          }
          else {
            puVar17 = (ushort *)(pbVar21 + uVar14);
            uVar4 = *puVar17;
            param_2[0xe] = uVar4;
            if (uVar4 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar12 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar12 != 0)) &&
                 ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                  (*(char *)(lVar12 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x9fb418,0xb1b0e8,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),3);
              uVar14 = (ulonglong)*(uint *)(param_2 + 10);
              uVar4 = param_2[0xe];
            }
            uVar8 = (int)uVar14 + (uVar4 + 1) * 2;
            *(uint *)(param_2 + 0xc) = uVar8;
            if (0x1f9e < uVar8) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar12 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar12 != 0 &&
                  ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                   (*(char *)(lVar12 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x9fb418,0xb1b0e8,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar4 = param_2[0xe];
              uVar8 = *(uint *)(param_2 + 0xc);
            }
            uVar14 = (ulonglong)uVar4;
            uVar4 = puVar17[uVar14];
            *(uint *)(param_2 + 2) = uVar4 & 0x7fff;
            if ((uVar4 & 0x7fff) < uVar8) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar12 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar12 != 0)) &&
                 ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                  (*(char *)(lVar12 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x9fb418,0xb1b0e8,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar14 = (ulonglong)(ushort)param_2[0xe];
            }
            if ((short)puVar17[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
              pbVar21 = *(byte **)(param_2 + 4);
              do {
                if ((int)uVar14 == 1) {
                  uVar8 = *(uint *)(param_2 + 0xc);
                  uVar20 = uVar8;
LAB_:
                  if ((*(ushort *)(pbVar21 + uVar14 * 2 + (ulonglong)*(uint *)(param_2 + 10)) &
                      0x7fff) < uVar8) goto LAB_;
                }
                else {
                  uVar20 = *(uint *)(param_2 + 0xc);
                  uVar8 = *(ushort *)
                           (pbVar21 + uVar14 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                          0x7fff;
                  if (uVar20 <= uVar8) goto LAB_;
LAB_:
                  func_0x(pbVar21,7);
                  uVar20 = *(uint *)(param_2 + 0xc);
                }
                if ((uVar8 < uVar20) || (*(uint *)(param_2 + 2) < uVar8)) goto LAB_;
                pbVar21 = *(byte **)(param_2 + 4);
                if (*(ushort *)(pbVar21 + uVar8) == 5) {
                  *puVar1 = *puVar1 | 2;
                  param_2[0xe] = param_2[0xe] + -1;
                  uVar20 = uVar8 & 0xffff;
                  param_2[0x15] = (short)uVar8;
                  uVar4 = param_2[0x16] & 0xc7ffU;
                  if ((*(ushort *)(pbVar21 + (ulonglong)uVar20 + 2) >> 0xe & 1) != 0) {
                    uVar4 = *(ushort *)(pbVar21 + (ulonglong)uVar20 + 2) & 0x3800 |
                            param_2[0x16] & 0xc7ffU;
                  }
                  param_2[0x16] = uVar4;
                  param_2[0x16] =
                       (uVar4 ^ *(ushort *)(pbVar21 + (ulonglong)uVar20 + 2)) & 0x7ff ^ uVar4;
                  goto LAB_;
                }
                if (*(ushort *)(pbVar21 + uVar8) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar4 = param_2[0xe] - 1;
                param_2[0xe] = uVar4;
                if (uVar4 == 0) goto LAB_;
                uVar14 = (ulonglong)uVar4;
              } while ((short)puVar17[(ulonglong)(uVar4 - 1) + 1] < 0);
              uVar14 = (ulonglong)*(uint *)(param_2 + 2);
            }
            else {
LAB_:
              uVar14 = (ulonglong)*(uint *)(param_2 + 2);
              pbVar21 = *(byte **)(param_2 + 4);
            }
          }
          iVar9 = 0;
          if ((*pbVar21 & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0x13) = 0;
          }
          else {
            *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
            puVar11 = (ulonglong *)func_0x(puVar1);
            uVar19 = (ushort)(*puVar11 >> 0x30);
            uVar4 = uVar19;
            if ((((uint)(int)(short)uVar19 >> 1 ^ (int)(short)uVar19) & 0x2000) != 0) {
              uVar4 = uVar19 & 0xdfff;
              if ((uVar19 >> 0xe & 1) != 0) {
                uVar4 = uVar19 | 0x2000;
              }
            }
            if (uVar4 == 0xfffc) {
              iVar9 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar9;
            uVar14 = (ulonglong)*(uint *)(param_2 + 2);
          }
          iVar9 = (int)uVar14;
          if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
             (*(ulonglong *)(param_2 + 0xf) < uVar14 + *(longlong *)(param_2 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar12 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar12 != 0 &&
                 (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
                (*(char *)(lVar12 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x9fb418,0xb1b0e8,0x877,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),0x12);
            iVar9 = *(int *)(param_2 + 2);
          }
          if (0x3f3b < iVar9 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar12 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar12 != 0 &&
                ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                 (*(char *)(lVar12 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                func_0x(*(undefined8 *)(param_2 + 4),5);
                goto LAB_;
              }
              (*_DAT_)(1,0x9fb418,0xb1b0e8,0x87c,0);
            }
            func_0x(*(undefined8 *)(param_2 + 4),5);
          }
        }
LAB_:
        iVar9 = func_0x(puVar1);
        if (iVar9 == 0) {
          iVar9 = func_0x(puVar1);
          if (iVar9 == 0) {
            (*_DAT_)(1,0xbb6a98,0xba7b88,0xd67,0);
          }
        }
        else {
          uVar4 = param_2[0x16];
          if (uVar5 < (uVar4 & 0x7ff)) {
            uVar19 = 0;
            lVar12 = *(longlong *)(param_2 + 4) + (ulonglong)(ushort)param_2[0x15];
            if ((uVar4 & 0x3800) == 0) {
              uVar18 = *(ushort *)(lVar12 + 2);
LAB_:
              uVar19 = uVar18 >> 0xb & 7;
            }
            else {
              lVar13 = 0;
              if ((uVar4 >> 0xb & 7) != 0) {
                do {
                  if (((lVar13 == 0) || ((*(ushort *)(lVar12 + 2 + lVar13 * 2) & 0x7ff) <= uVar5))
                     && (uVar18 = *(ushort *)(lVar12 + 4 + lVar13 * 2),
                        (int)uVar5 <= (int)((uVar18 & 0x7ff) - 1))) goto LAB_;
                  lVar13 = lVar13 + 1;
                } while (lVar13 < (longlong)(ulonglong)(uVar4 >> 0xb & 7));
              }
            }
            iVar23 = (uint)*(ushort *)
                            ((ulonglong)((uVar4 >> 0xb & 7) * 2) + *(longlong *)(param_2 + 4) +
                             lStackX_10 * 2 + 4 + (ulonglong)(ushort)param_2[0x15]) +
                     (uint)uVar19 * 0x10000;
          }
          else {
            (*_DAT_)(1,0xbb6a68,0xbb6ab0,0x3c6,0);
          }
        }
        lVar12 = func_0x
                           (**(undefined8 **)
                              (*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) + 0x160),iVar23);
        func_0x(param_2,*(undefined4 *)(lVar12 + 0x3c),lVar12,
                        (longlong)piVar16 + (longlong)(int)uVar22 * 10 + 4);
        uVar22 = (ulonglong)((int)uVar22 + 1);
        lStackX_10 = lStackX_10 + 1;
        uVar5 = uVar5 + 1;
      } while (lStackX_10 < iVar6);
    }
  }
  *param_5 = iVar7;
  return;
}

