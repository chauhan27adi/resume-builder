
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  int *piVar1;
  ushort *puVar2;
  undefined2 uVar3;
  longlong lVar4;
  bool bVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  undefined4 uVar9;
  longlong lVar10;
  undefined8 uVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong *plVar14;
  byte *pbVar15;
  longlong lVar16;
  undefined8 *puVar17;
  undefined8 uVar18;
  ulonglong uVar19;
  ushort uVar20;
  uint uVar21;
  longlong unaff_GS_OFFSET;
  undefined auStack_258 [32];
  undefined8 uStack_238;
  undefined8 uStack_230;
  undefined4 uStack_228;
  undefined4 uStack_220;
  undefined auStack_218 [8];
  longlong *plStack_210;
  undefined4 uStack_208;
  undefined4 uStack_204;
  int iStack_200;
  int iStack_1fc;
  longlong lStack_1f8;
  int iStack_1f0;
  ulonglong uStack_1e8;
  undefined4 uStack_1e0;
  undefined8 uStack_1dc;
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined8 uStack_1cc;
  undefined4 uStack_1c0;
  undefined auStack_1bc [12];
  longlong *plStack_1b0;
  undefined8 uStack_1a8;
  longlong *plStack_1a0;
  undefined8 uStack_198;
  undefined8 *puStack_190;
  undefined *puStack_188;
  undefined2 uStack_180;
  undefined8 uStack_178;
  undefined4 uStack_170;
  undefined auStack_168 [16];
  undefined auStack_158 [16];
  undefined auStack_148 [16];
  undefined auStack_138 [16];
  longlong lStack_128;
  uint uStack_120;
  ulonglong uStack_118;
  undefined8 uStack_110;
  undefined auStack_108 [8];
  int iStack_100;
  undefined auStack_f8 [192];
  ulonglong uStack_38;
  
  uStack_1a8 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_258;
  uVar3 = *(undefined2 *)(param_1 + 1);
  plVar14 = (longlong *)0x0;
  if ((DAT_ & 8) == 0) {
    iStack_1f0 = 0;
  }
  else {
    iStack_1f0 = 1;
    iStack_200 = (*_DAT_)();
    iStack_1fc = 0x21;
    lStack_1f8 = func_0x(uVar3);
  }
  lVar4 = *(longlong *)(param_1[0xe] + 8);
  (*_DAT_)(auStack_f8);
  (*_DAT_)(auStack_218,auStack_f8);
  lVar10 = (*_DAT_)(auStack_218,param_1[0x11]);
  uVar11 = (**(code **)(**(longlong **)
                          (*(longlong *)
                            ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            ) + 0x90) + 0x1b0))();
  plVar12 = (longlong *)(**_DAT_)(_DAT_,uVar11,0x1a2e190,0xa2a);
  plStack_1b0 = plVar12;
  plStack_1a0 = plVar12;
  (*_DAT_)(*(undefined8 *)(lVar10 + 0xb0),plVar12);
  uStack_230 = (undefined *)((ulonglong)uStack_230._4_4_ << 0x20);
  uStack_238 = (ulonglong)uStack_238._4_4_ << 0x20;
  plVar12 = (longlong *)(**(code **)(*plVar12 + 0x38))(plVar12,*(undefined2 *)(param_1 + 1),0,0);
  uStack_220 = 0;
  uStack_228 = 0;
  uStack_230 = (undefined *)CONCAT71(uStack_230._1_7_,1);
  uStack_238 = uStack_238 & 0xffffffffffffff00;
  plVar13 = (longlong *)
            (**(code **)(*plVar12 + 0x78))(plVar12,*(undefined4 *)((longlong)param_1 + 0xc),1,0);
  plVar12 = (longlong *)(**(code **)(*plVar13 + 0x78))(plVar13);
  uStack_1e8 = 0;
  uStack_1dc = 0;
  uStack_1d4 = 0;
  uStack_1cc = 1;
  uStack_1d0 = 0xffffffff;
  uStack_1e0 = 0xfffffffe;
  plStack_210 = plVar12;
  (**(code **)(*plVar13 + 0x60))(plVar13,auStack_108);
  if ((iStack_100 == 0x2056) &&
     (plVar14 = (longlong *)(**(code **)(*plVar12 + 0xe8))(plVar12,1), plVar14 != (longlong *)0x0))
  {
    bVar5 = true;
  }
  else {
    bVar5 = false;
  }
  uVar19 = 0;
  if (*(int *)(lVar4 + 0x230) != 0) {
    do {
      *(undefined2 *)(uVar19 * 0x106 + 0x104 + *(longlong *)(lVar4 + 0x228)) = 0;
      pbVar15 = (byte *)(uVar19 * 0x30 + *(longlong *)(lVar4 + 0x238));
      if ((*(short *)(pbVar15 + 0x10) == -1) ||
         (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar15 + 0x17bba10) + 0x2171088) != '\0')) {
        *(int *)(lVar4 + 0x218) = *(int *)(lVar4 + 0x218) + 1;
      }
      uVar21 = (int)uVar19 + 1;
      uVar19 = (ulonglong)uVar21;
    } while (uVar21 < *(uint *)(lVar4 + 0x230));
  }
  if ((!bVar5) && (lVar16 = (**(code **)(*plVar12 + 0x1f0))(plVar12,0), lVar16 != 0)) {
    plVar14 = (longlong *)(**(code **)(*plVar12 + 0x1f0))(plVar12,0);
    lVar16 = *plVar12;
    uVar6 = (**(code **)(*plVar14 + 8))(plVar14);
    plVar14 = (longlong *)(**(code **)(lVar16 + 0xe8))(plVar12,uVar6);
  }
  if (plVar14 != (longlong *)0x0) {
    uVar21 = 1;
    iVar7 = (**(code **)(*plVar14 + 0x78))(plVar14);
    plVar12 = plStack_210;
    if (iVar7 != 0) {
      do {
        lVar16 = *plVar14;
        uVar6 = (**(code **)(lVar16 + 0x80))(plVar14,uVar21);
        plVar12 = (longlong *)(**(code **)(lVar16 + 0x40))(plVar14,uVar6);
        iVar7 = (**(code **)(*plVar12 + 0x10))();
        uVar20 = 0;
        uVar8 = *(uint *)(lVar4 + 0x230);
        if (uVar8 != 0) {
          do {
            if (*(int *)(*(longlong *)(lVar4 + 0x238) + 0x20 + (ulonglong)uVar20 * 0x30) == iVar7)
            break;
            uVar20 = uVar20 + 1;
          } while (uVar20 < uVar8);
        }
        if (uVar8 <= uVar20) {
          uStack_238 = 0;
          (*_DAT_)(1,0x1be05f0,0x1bba890,0xa53);
        }
        puVar2 = (ushort *)((ulonglong)uVar20 * 0x106 + 0x104 + *(longlong *)(lVar4 + 0x228));
        *puVar2 = *puVar2 | 1;
        *(int *)(lVar4 + 0x338) = *(int *)(lVar4 + 0x338) + 1;
        if ((((*(byte *)(*(longlong *)(lVar4 + 0x238) + 0x28 + (ulonglong)uVar20 * 0x30) & 0x40) !=
              0) && (uVar8 = (**(code **)(*plVar14 + 8))(plVar14), 1 < uVar8)) &&
           (*(longlong *)(lVar4 + 0x340) == 0)) {
          uStack_1c0 = 0xa62;
          uStack_198 = _DAT_;
          uStack_230 = (undefined *)CONCAT71(uStack_230._1_7_,6);
          uStack_238 = CONCAT44(uStack_238._4_4_,0xa62);
          puVar17 = (undefined8 *)(*_DAT_)(0x70,_DAT_,1,0x1a2e190);
          puStack_190 = puVar17;
          if (puVar17 != (undefined8 *)0x0) {
            uVar9 = (**(code **)(*plVar14 + 8))(plVar14);
            uVar6 = *(undefined4 *)((longlong)param_1 + 0xc);
            uVar3 = *(undefined2 *)(param_1 + 1);
            *puVar17 = 0x17a2b48;
            *(undefined2 *)(puVar17 + 1) = uVar3;
            *(undefined4 *)((longlong)puVar17 + 0xc) = uVar6;
            *(undefined4 *)(puVar17 + 2) = uVar9;
            *(undefined4 *)((longlong)puVar17 + 0x14) = 3;
            puVar17[3] = 0;
            puVar17[4] = 0;
            puVar17[5] = 0;
            puVar17[6] = 0;
            *(undefined4 *)(puVar17 + 7) = 0;
            puVar17[8] = 0;
            puVar17[9] = 0;
            puVar17[10] = 0;
            *(undefined4 *)(puVar17 + 0xb) = 0;
            puVar17[0xc] = 0;
            *(undefined4 *)(puVar17 + 0xd) = 0;
            *puVar17 = 0x17a2b20;
          }
          uStack_238 = 0;
          *(undefined8 **)(lVar4 + 0x340) = puVar17;
          func_0x(*(undefined2 *)(param_1 + 1),0x2d,0x70,1);
          plVar12 = *(longlong **)(lVar4 + 0x340);
          if (plVar12 == (longlong *)0x0) {
            (*_DAT_)(0xbb,0x37,0x10,0xd);
            plVar12 = *(longlong **)(lVar4 + 0x340);
          }
          uStack_230 = auStack_1bc;
          uStack_238 = 0;
          (**(code **)(*plVar12 + 8))(plVar12,lVar10,_DAT_,uVar11);
          uVar18 = (*_DAT_)(*(undefined8 *)(*(longlong *)(lVar10 + 0x80) + 0x108));
          (**(code **)(**(longlong **)(lVar4 + 0x340) + 0x10))
                    (*(longlong **)(lVar4 + 0x340),_DAT_,uVar18,uVar11);
          (*_DAT_)(*(undefined8 *)(lVar4 + 0x340),lVar10,uVar11);
        }
        uVar21 = uVar21 + 1;
        uVar8 = (**(code **)(*plVar14 + 0x78))(plVar14);
        plVar12 = plStack_210;
      } while (uVar21 <= uVar8);
    }
  }
  for (plVar14 = (longlong *)(**(code **)(*plVar12 + 0x168))(plVar12,0,0);
      plVar14 != (longlong *)0x0;
      plVar14 = (longlong *)(**(code **)(*plVar12 + 0x168))(plVar12,plVar14,0)) {
    (**(code **)(*plVar14 + 0x28))(plVar14,&uStack_1e8);
    if ((((uStack_1e8 & 0x100) != 0) || ((uStack_1e8 & 0x800) != 0)) &&
       (((uStack_1e8 & 0x400) == 0 && ((int)uStack_1dc == 0)))) {
      uVar21 = 1;
      iVar7 = (**(code **)(*plVar14 + 0x78))(plVar14);
      plVar12 = plStack_210;
      if (iVar7 != 0) {
        do {
          lVar10 = *plVar14;
          uVar6 = (**(code **)(lVar10 + 0x80))(plVar14,uVar21);
          plVar12 = (longlong *)(**(code **)(lVar10 + 0x40))(plVar14,uVar6);
          iVar7 = (**(code **)(*plVar12 + 0x10))(plVar12);
          uVar20 = 0;
          uVar8 = *(uint *)(lVar4 + 0x230);
          if (uVar8 != 0) {
            do {
              if (*(int *)(*(longlong *)(lVar4 + 0x238) + 0x20 + (ulonglong)uVar20 * 0x30) == iVar7)
              break;
              uVar20 = uVar20 + 1;
            } while (uVar20 < uVar8);
          }
          if (uVar20 < uVar8) {
            puVar2 = (ushort *)((ulonglong)uVar20 * 0x106 + 0x104 + *(longlong *)(lVar4 + 0x228));
            *puVar2 = *puVar2 | 2;
          }
          else if (param_1[0xb] == 0) {
            uStack_238 = 0;
            (*_DAT_)(1,0x1be0618,0x1bba890,0xa90);
          }
          uVar21 = uVar21 + 1;
          uVar8 = (**(code **)(*plVar14 + 0x78))(plVar14);
          plVar12 = plStack_210;
        } while (uVar21 <= uVar8);
      }
    }
  }
  if (((*(byte *)(*param_1 + 0x18) & 2) != 0) && (0 < *(int *)(lVar4 + 0x348))) {
    uVar6 = func_0x(*(undefined2 *)(param_1 + 1),0x1a2dca0);
    uStack_178 = (**(code **)(**(longlong **)
                                (*(longlong *)
                                  ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8)) + 0x90) + 0x1b0))();
    uStack_180 = *(undefined2 *)(param_1 + 1);
    puStack_188 = (undefined *)0x0;
    auStack_168 = ZEXT816(0);
    auStack_158 = ZEXT816(0);
    auStack_148 = ZEXT816(0);
    auStack_138 = ZEXT816(0);
    lStack_128 = 0;
    uStack_120 = 0;
    uStack_118 = 0;
    uStack_110 = 0;
    uStack_170 = uVar6;
    iVar7 = func_0x(&puStack_188,3,1,0);
    if (iVar7 != 0) {
      uStack_230 = (undefined *)((ulonglong)uStack_230 & 0xffffffff00000000);
      uStack_238 = CONCAT44(uStack_238._4_4_,4);
      func_0x(&puStack_188,0x17cc828,lVar4 + 0x348,lVar4 + 0x348);
      uStack_230 = puStack_188;
      uStack_238 = uStack_118;
      iVar7 = (**(code **)(*(longlong *)auStack_168._8_8_ + 0x18))(auStack_168._8_8_,0,1,0);
      while (iVar7 == 0) {
        uStack_208 = 0;
        if (puStack_188 != (undefined *)0x0) {
          uVar21 = func_0x(&puStack_188,0x17c6d40,&uStack_208);
          uVar19 = (ulonglong)uVar21;
          if ((ulonglong)uVar21 == *(ulonglong *)((ulonglong)(uVar21 - 1) * 0x58 + lStack_128)) {
LAB_:
            if (uVar21 <= uStack_120) {
              lVar10 = (ulonglong)(uVar21 - 1) * 0x58 + lStack_128;
              if ((((int *)(puStack_188 + *(longlong *)(lVar10 + 8)) != (int *)0x0) &&
                  (*(longlong *)(puStack_188 + *(longlong *)(lVar10 + 0x10)) == 4)) &&
                 (*(int *)(puStack_188 + *(longlong *)(lVar10 + 0x18)) != 3)) {
                if (*(uint *)(lVar4 + 0x230) != 0) {
                  uVar19 = 0;
                  do {
                    if (*(int *)(*(longlong *)(lVar4 + 0x238) + 0x20 + uVar19 * 0x30) ==
                        *(int *)(puStack_188 + *(longlong *)(lVar10 + 8))) {
                      puVar2 = (ushort *)(uVar19 * 0x106 + 0x104 + *(longlong *)(lVar4 + 0x228));
                      *puVar2 = *puVar2 | 4;
                      break;
                    }
                    uVar21 = (int)uVar19 + 1;
                    uVar19 = (ulonglong)uVar21;
                  } while (uVar21 < *(uint *)(lVar4 + 0x230));
                }
              }
            }
          }
          else {
            uVar21 = 1;
            if (uStack_120 != 0) {
              do {
                if (uVar19 == *(ulonglong *)((ulonglong)(uVar21 - 1) * 0x58 + lStack_128))
                goto LAB_;
                uVar21 = uVar21 + 1;
              } while (uVar21 <= uStack_120);
            }
          }
        }
        uStack_238 = uStack_118;
        uStack_230 = puStack_188;
        iVar7 = (**(code **)(*(longlong *)auStack_168._8_8_ + 0x18))(auStack_168._8_8_,0,1);
      }
      piVar1 = (int *)(lVar4 + 0x34c);
      if (0 < *piVar1) {
        uStack_230 = (undefined *)((ulonglong)uStack_230 & 0xffffffff00000000);
        uStack_238._4_4_ = (uint)(uStack_238 >> 0x20);
        uStack_238 = CONCAT44(uStack_238._4_4_,4);
        func_0x(&puStack_188,0x17cc828,piVar1,piVar1);
        uStack_230 = puStack_188;
        uStack_238 = uStack_118;
        iVar7 = (**(code **)(*(longlong *)auStack_168._8_8_ + 0x18))(auStack_168._8_8_,0,1);
        while (iVar7 == 0) {
          uStack_204 = 0;
          if (puStack_188 != (undefined *)0x0) {
            uVar21 = func_0x(&puStack_188,0x17c6d40,&uStack_204);
            uVar19 = (ulonglong)uVar21;
            if ((ulonglong)uVar21 == *(ulonglong *)((ulonglong)(uVar21 - 1) * 0x58 + lStack_128)) {
LAB_:
              if (uVar21 <= uStack_120) {
                lVar10 = (ulonglong)(uVar21 - 1) * 0x58 + lStack_128;
                if ((((int *)(puStack_188 + *(longlong *)(lVar10 + 8)) != (int *)0x0) &&
                    (*(longlong *)(puStack_188 + *(longlong *)(lVar10 + 0x10)) == 4)) &&
                   (*(int *)(puStack_188 + *(longlong *)(lVar10 + 0x18)) != 3)) {
                  if (*(uint *)(lVar4 + 0x230) != 0) {
                    uVar19 = 0;
                    do {
                      if (*(int *)(*(longlong *)(lVar4 + 0x238) + 0x20 + uVar19 * 0x30) ==
                          *(int *)(puStack_188 + *(longlong *)(lVar10 + 8))) {
                        puVar2 = (ushort *)(uVar19 * 0x106 + 0x104 + *(longlong *)(lVar4 + 0x228));
                        *puVar2 = *puVar2 | 8;
                        break;
                      }
                      uVar21 = (int)uVar19 + 1;
                      uVar19 = (ulonglong)uVar21;
                    } while (uVar21 < *(uint *)(lVar4 + 0x230));
                  }
                }
              }
            }
            else {
              uVar21 = 1;
              if (uStack_120 != 0) {
                do {
                  if (uVar19 == *(ulonglong *)((ulonglong)(uVar21 - 1) * 0x58 + lStack_128))
                  goto LAB_;
                  uVar21 = uVar21 + 1;
                } while (uVar21 <= uStack_120);
              }
            }
          }
          uStack_238 = uStack_118;
          uStack_230 = puStack_188;
          iVar7 = (**(code **)(*(longlong *)auStack_168._8_8_ + 0x18))(auStack_168._8_8_,0,1);
        }
      }
    }
    func_0x(&puStack_188);
  }
  (**(code **)*plStack_1b0)(plStack_1b0,1);
  (*_DAT_)(auStack_218);
  (*_DAT_)(auStack_f8);
  lVar4 = lStack_1f8;
  if ((iStack_1f0 != 0) && (lStack_1f8 != 0)) {
    iVar7 = (*_DAT_)();
    piVar1 = (int *)(lVar4 + 8 + (longlong)iStack_1fc * 4);
    *piVar1 = *piVar1 + (iVar7 - iStack_200);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_258);
  return;
}

