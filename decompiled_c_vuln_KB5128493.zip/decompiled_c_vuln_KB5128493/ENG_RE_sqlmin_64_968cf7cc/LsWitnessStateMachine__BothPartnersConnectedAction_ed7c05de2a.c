
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 *param_1,longlong param_2)

{
  undefined8 uVar1;
  
  switch(*(undefined4 *)(param_2 + 0x28)) {
  case 0x232b:
    func_0x(param_1,1);
    break;
  default:
    uVar1 = (**(code **)*param_1)(param_1);
    func_0x(param_1,0xbe6a08,uVar1);
    return;
  case 0x232d:
    func_0x(param_1,2);
    break;
  case 0x232f:
  case 0x2331:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  case 0x2330:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  case 0x2333:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  case 0x2334:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  case 0x2335:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  case 0x2339:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  case 0x233e:
    func_0x(param_1[0x192],param_2 + 0x48);
    if ((*(longlong *)(param_2 + 0x48) != 0) &&
       (*(longlong *)(*(longlong *)(param_2 + 0x48) + 0x28) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

