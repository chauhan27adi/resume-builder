
byte * FUN_(longlong param_1)

{
  code *pcVar1;
  byte *pbVar2;
  
  if ((**(byte **)(param_1 + 6) & 0x40) == 0) {
    pcVar1 = (code *)swi(3);
    pbVar2 = (byte *)(*pcVar1)();
    return pbVar2;
  }
  if (*(int *)(param_1 + 2) != 0) {
    return *(byte **)(param_1 + 6) + *(uint *)(param_1 + 0x24);
  }
  pcVar1 = (code *)swi(3);
  pbVar2 = (byte *)(*pcVar1)();
  return pbVar2;
}

