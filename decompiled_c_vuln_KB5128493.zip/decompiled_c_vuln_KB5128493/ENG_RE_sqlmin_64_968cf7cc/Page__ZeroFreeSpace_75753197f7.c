
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  short *psVar1;
  byte bVar2;
  undefined2 uVar3;
  longlong lVar4;
  short sVar5;
  uint uVar6;
  ulonglong *puVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  short *psVar11;
  uint uVar12;
  longlong lVar13;
  undefined *puVar14;
  ushort uVar15;
  ulonglong uVar16;
  ushort uVar17;
  ushort uVar18;
  uint uVar19;
  int iVar20;
  short *psVar21;
  short *psVar22;
  byte *pbVar23;
  longlong lVar24;
  ushort *puVar25;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_d0;
  undefined auStack_c8 [32];
  longlong alStack_a8 [2];
  uint auStack_98 [4];
  short asStack_88 [2];
  uint uStack_84;
  byte *pbStack_80;
  undefined8 uStack_78;
  uint uStack_70;
  ushort uStack_6c;
  byte *pbStack_6a;
  undefined2 uStack_62;
  undefined2 uStack_60;
  undefined2 uStack_5e;
  ushort uStack_5c;
  undefined2 uStack_5a;
  undefined4 uStack_58;
  longlong lStack_50;
  undefined8 uStack_48;
  longlong lStack_38;
  ulonglong uStack_30;
  
  uStack_30 = _DAT_ ^ (ulonglong)asStack_88;
  uStack_d0 = 0x100048;
  func_0x(param_1,0xffffffff);
  uVar18 = *(ushort *)(param_1 + 0x16);
  uVar10 = (ulonglong)uVar18;
  uVar15 = 0x60;
  if (uVar18 == 0) {
    *(undefined2 *)(param_1 + 0x1e) = 0x60;
    uVar19 = 0x60;
  }
  else {
    uVar19 = (uint)*(ushort *)(param_1 + 0x1e);
  }
  puVar14 = auStack_c8;
  if ((uint)*(ushort *)(param_1 + 0x1c) != (0x1000 - (uint)uVar18) * 2 - uVar19) {
    iVar20 = 0;
    uVar16 = 0;
    uVar8 = uVar10 * 8 + 0xf;
    if (uVar8 <= uVar10 * 8) {
      uVar8 = 0xffffffffffffff0;
    }
    uVar8 = uVar8 & 0xfffffffffffffff0;
    uStack_d0 = 0x1000b2;
    uVar9 = uVar16;
    func_0x();
    lVar4 = -uVar8;
    uVar8 = uVar9 & 0xffffffff;
    psVar1 = (short *)((longlong)asStack_88 + lVar4);
    uStack_48 = psVar1;
    if ((ushort)uVar9 < (ushort)uVar10) {
      psVar11 = (short *)(param_1 + 0x1ffe);
      psVar21 = psVar1;
      do {
        psVar22 = psVar21;
        if (*psVar11 != 0) {
          uVar16 = (ulonglong)((int)uVar16 + 1);
          psVar22 = psVar21 + 4;
          *psVar21 = *psVar11;
          *(int *)(psVar21 + 2) = (int)uVar8;
        }
        iVar20 = (int)uVar16;
        uVar19 = (int)uVar8 + 1;
        uVar8 = (ulonglong)uVar19;
        psVar11 = psVar11 + -1;
        psVar21 = psVar22;
      } while ((int)uVar19 < (int)(uint)*(ushort *)(param_1 + 0x16));
    }
    lVar24 = (longlong)iVar20;
    lStack_38 = lVar24;
    *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x10011a;
    (*_DAT_)(psVar1,lVar24,8,0xfffffffffec50cf0);
    psVar1 = uStack_48;
    puVar14 = auStack_c8 + lVar4;
    if (0 < iVar20) {
      lStack_50 = 0;
      do {
        lVar13 = lStack_50;
        uVar10 = 0;
        if (psVar1[lStack_50 * 4] != 0) {
          uVar8 = (ulonglong)*(ushort *)(param_1 + 0xe);
          uVar16 = 0;
          uStack_84 = 0;
          pbVar23 = (byte *)((ulonglong)
                             *(ushort *)
                              (param_1 +
                              (0xfff - (longlong)*(int *)(psVar1 + lStack_50 * 4 + 2)) * 2) +
                            param_1);
          pbStack_6a = (byte *)0x0;
          uStack_5e = 0;
          uStack_5c = 0;
          uStack_5a = 0;
          uStack_78 = 0;
          pbStack_80 = pbVar23;
          if ((*pbVar23 & 1) == 0) {
            asStack_88[0] = 0;
            uStack_62 = 0;
            uStack_60 = 0;
            switch(*pbVar23 & 0xe) {
            default:
              uVar8 = (ulonglong)*(ushort *)(pbVar23 + 2);
              uVar10 = uVar16;
              if (0x1f9d < *(ushort *)(pbVar23 + 2) - 1) {
                *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x10034d;
                func_0x(pbVar23,6);
                uVar10 = (ulonglong)uStack_84;
              }
              break;
            case 4:
              uVar8 = 9;
              uVar10 = uVar16;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar8 = 1;
              uVar10 = uVar16;
            }
            uVar19 = (uint)uVar10;
            pbStack_6a = (byte *)(param_1 + 0x2000);
            if (param_1 == 0) {
              pbStack_6a = (byte *)0x0;
            }
            uStack_78 = CONCAT44(uStack_78._4_4_,(int)uVar8);
          }
          else {
            asStack_88[0] = 1;
            bVar2 = *pbVar23;
            switch(bVar2 & 0x1c) {
            default:
              if ((char)pbVar23[1] < '\0') {
                sVar5 = 3;
                uStack_70 = 3;
                asStack_88[1] =
                     (*(ushort *)(pbVar23 + 1) & 0x7f) << 8 | *(ushort *)(pbVar23 + 1) >> 8;
              }
              else {
                asStack_88[1] = (short)pbVar23[1];
                sVar5 = 2;
                uStack_70 = 2;
              }
              uStack_6c = (short)((ushort)asStack_88[1] + 1 >> 1) + sVar5;
              if ((ushort)asStack_88[1] < 0x1f) {
                uStack_58 = 0;
                uVar16 = uVar10;
              }
              else {
                iVar20 = (ushort)asStack_88[1] - 1;
                uStack_58 = 0;
                uStack_70 = CONCAT22(((short)(iVar20 / 0x1e) + (short)(iVar20 >> 0x1f)) -
                                     (short)((longlong)iVar20 * 0x88888889 >> 0x3f),
                                     (undefined2)uStack_70);
              }
              break;
            case 4:
              if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
                uVar16 = 0xf;
                uStack_70 = 0;
                uStack_84 = 0xf;
                asStack_88[1] = 0;
                uStack_6c = 0;
                uStack_62 = 0;
                uStack_58 = 1;
              }
              else {
                uStack_70 = 0;
                uVar16 = 1;
                asStack_88[1] = 0;
                uStack_6c = 0;
                uStack_62 = 0;
                uStack_84 = 1;
                uStack_58 = 0;
              }
              break;
            case 8:
              uVar16 = 9;
              uStack_70 = 0;
              uStack_84 = 9;
              asStack_88[1] = 0;
              uStack_6c = 0;
              uStack_62 = 0;
              uStack_58 = 0;
            }
            uVar19 = (uint)uVar16;
            uStack_78 = 0;
            uVar8 = param_1 + 0x2000;
            if (param_1 == 0) {
              uVar8 = uVar10;
            }
            uStack_60 = (undefined2)uVar8;
            uStack_5e = (undefined2)(uVar8 >> 0x10);
            uStack_5c = (ushort)(uVar8 >> 0x20);
            uStack_5a = (undefined2)(uVar8 >> 0x30);
            uVar8 = uVar10;
          }
          if (asStack_88[0] == 0) {
            if (uVar19 == 0) {
              uVar19 = (uint)uVar8;
              asStack_88[1] = 0;
              if ((*pbStack_80 & 0x10) != 0) {
                if ((*pbStack_80 & 0x10) == 0) {
                  uVar6 = 0;
                }
                else {
                  uVar6 = (uint)*(ushort *)(pbStack_80 + uVar8);
                }
                uVar19 = uVar19 + 2 + (uVar6 + 7 >> 3);
                uVar8 = (ulonglong)uVar19;
              }
              uStack_78 = CONCAT44(uVar19,(int)uStack_78);
              if ((*pbStack_80 & 0x20) == 0) {
                uStack_6c = 0;
                uVar10 = uVar8;
                uStack_84 = (uint)uVar8;
                uStack_70 = (uint)uVar8;
              }
              else {
                puVar25 = (ushort *)(pbStack_80 + uVar8);
                uStack_6c = *puVar25;
                if (uStack_6c == 0) {
                  if ((((cRam0000000001a35d9b != '\0') || ((bRam0000000001a466a0 & 1) != 0)) &&
                      (lVar24 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam0000000000fa4628 * 8) + 8 +
                                 (ulonglong)*puRam0000000000fa4630), lVar24 != 0)) &&
                     ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                      (*(char *)(lVar24 + 0x499) != '\0')))) {
                    if ((cRam0000000001a35c8b == '\0') && ((bRam0000000001a466a0 & 2) == 0)) {
                      *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x10048f;
                      (*pcRam0000000000fa45c8)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)((longlong)alStack_a8 + lVar4) = 0;
                      *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1004b3;
                      (*pcRam0000000000fa45c0)(1,0x13267c8,0x1446498,0x80f);
                    }
                  }
                  pbVar23 = pbStack_80;
                  *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1004c1;
                  func_0x(pbVar23,3);
                  uVar8 = uStack_78 >> 0x20;
                }
                uStack_70 = (int)uVar8 + (uStack_6c + 1) * 2;
                if (0x1f9e < uStack_70) {
                  if (((cRam0000000001a35d9b != '\0') || ((bRam0000000001a466a0 & 1) != 0)) &&
                     ((lVar24 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam0000000000fa4628 * 8) + 8 +
                                 (ulonglong)*puRam0000000000fa4630), lVar24 != 0 &&
                      ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                       (*(char *)(lVar24 + 0x499) != '\0')))))) {
                    if ((cRam0000000001a35c8b == '\0') && ((bRam0000000001a466a0 & 2) == 0)) {
                      *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x100563;
                      (*pcRam0000000000fa45c8)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)alStack_a8 + lVar4) = 0;
                      *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x100589;
                      (*pcRam0000000000fa45c0)(1,0x13267c8,0x1446498,0x816);
                    }
                  }
                  pbVar23 = pbStack_80;
                  *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x100597;
                  func_0x(pbVar23,4);
                  uVar8 = uStack_78 >> 0x20;
                }
                uVar16 = (ulonglong)uStack_6c;
                uStack_84 = puVar25[uVar16] & 0x7fff;
                uVar10 = (ulonglong)uStack_84;
                uVar6 = uStack_70;
                if (uStack_84 < uStack_70) {
                  if ((((cRam0000000001a35d9b != '\0') || ((bRam0000000001a466a0 & 1) != 0)) &&
                      (lVar24 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam0000000000fa4628 * 8) + 8 +
                                 (ulonglong)*puRam0000000000fa4630), lVar24 != 0)) &&
                     ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                      (*(char *)(lVar24 + 0x499) != '\0')))) {
                    if ((cRam0000000001a35c8b == '\0') && ((bRam0000000001a466a0 & 2) == 0)) {
                      *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x100639;
                      (*pcRam0000000000fa45c8)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)alStack_a8 + lVar4) = 0;
                      *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x100662;
                      (*pcRam0000000000fa45c0)(1,0x13267c8,0x1446498,0x81d);
                    }
                  }
                  pbVar23 = pbStack_80;
                  *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x100670;
                  func_0x(pbVar23,4);
                  uVar16 = (ulonglong)uStack_6c;
                  uVar8 = uStack_78 >> 0x20;
                  uVar10 = (ulonglong)uStack_84;
                  uVar6 = uStack_70;
                }
                do {
                  pbVar23 = pbStack_80;
                  if (-1 < (short)puVar25[(ulonglong)((int)uVar16 - 1) + 1]) break;
                  if ((int)uVar16 == 1) {
                    uVar9 = 1;
                    uVar12 = uVar6;
code_r0x001006ba:
                    if ((*(ushort *)(pbStack_80 + uVar9 * 2 + uVar8) & 0x7fff) < uVar12)
                    goto code_r0x001006c7;
                  }
                  else {
                    uVar12 = *(ushort *)(pbStack_80 + uVar16 * 2 + (uVar8 - 2)) & 0x7fff;
                    uVar9 = uVar16;
                    if (uVar6 <= uVar12) goto code_r0x001006ba;
code_r0x001006c7:
                    *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1006d5;
                    func_0x(pbVar23,7);
                    uVar16 = (ulonglong)uStack_6c;
                    uVar8 = uStack_78 >> 0x20;
                    uVar10 = (ulonglong)uStack_84;
                    uVar6 = uStack_70;
                  }
                  uVar19 = (uint)uVar10;
                  lVar13 = lStack_50;
                  if ((uVar12 < uVar6) || (uVar19 < uVar12)) goto code_r0x001009c9;
                  if (*(ushort *)(pbStack_80 + uVar12) == 5) {
                    asStack_88[1] = asStack_88[1] | 2;
                    uStack_6c = (short)uVar16 - 1;
                    uStack_5e = (undefined2)uVar12;
                    if ((*(ushort *)(pbStack_80 + (ulonglong)(uVar12 & 0xffff) + 2) & 0x4000) == 0)
                    {
                      uStack_5c = uStack_5c & 0xc7ff;
                    }
                    else {
                      uStack_5c = uStack_5c ^
                                  (uStack_5c ^
                                  *(ushort *)(pbStack_80 + (ulonglong)(uVar12 & 0xffff) + 2)) &
                                  0x3800;
                    }
                    uStack_5c = uStack_5c ^
                                (uStack_5c ^
                                *(ushort *)(pbStack_80 + (ulonglong)(uVar12 & 0xffff) + 2)) & 0x7ff;
                    break;
                  }
                  if (*(ushort *)(pbStack_80 + uVar12) < 0x400) break;
                  asStack_88[1] = asStack_88[1] | 1;
                  uStack_6c = (short)uVar16 - 1;
                  uVar16 = (ulonglong)uStack_6c;
                } while (uStack_6c != 0);
              }
              if ((*pbStack_80 & 0x40) == 0) {
                uStack_62 = 0;
                uStack_60 = 0;
              }
              else {
                uStack_62 = (undefined2)uVar10;
                uStack_60 = (undefined2)(uVar10 >> 0x10);
                uStack_84 = (int)uVar10 + 0xe;
                *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1007c9;
                puVar7 = (ulonglong *)func_0x(asStack_88 + 1);
                iVar20 = 0;
                uVar10 = *puVar7;
                uVar17 = (ushort)(uVar10 >> 0x30);
                uVar18 = uVar17;
                if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
                  uVar18 = uVar17 & 0xdfff;
                  if ((uVar10 & 0x4000000000000000) != 0) {
                    uVar18 = uVar17 | 0x2000;
                  }
                }
                if (uVar18 == 0xfffc) {
                  iVar20 = (int)((uVar10 >> 0x20 & 0xffff) >> 5);
                }
                uStack_84 = uStack_84 + iVar20;
                uVar10 = (ulonglong)uStack_84;
              }
              uVar19 = (uint)uVar10;
              if ((pbStack_6a != (byte *)0x0) && (pbStack_6a < pbStack_80 + uVar10)) {
                if (((cRam0000000001a35d9b != '\0') || ((bRam0000000001a466a0 & 1) != 0)) &&
                   (((lVar24 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam0000000000fa4628 * 8) + 8 +
                                (ulonglong)*puRam0000000000fa4630), lVar24 != 0 &&
                     (lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0)) &&
                    (*(char *)(lVar24 + 0x499) != '\0')))) {
                  if ((cRam0000000001a35c8b == '\0') && ((bRam0000000001a466a0 & 2) == 0)) {
                    *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1008cb;
                    (*pcRam0000000000fa45c8)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)((longlong)alStack_a8 + lVar4) = 0;
                    *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1008f1;
                    (*pcRam0000000000fa45c0)(1,0x13267c8,0x1446498,0x877);
                  }
                }
                pbVar23 = pbStack_80;
                *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1008ff;
                func_0x(pbVar23,0x12);
                uVar19 = uStack_84;
              }
              lVar13 = lStack_50;
              if (0x3f3b < uVar19 - 1) {
                if (((cRam0000000001a35d9b != '\0') || ((bRam0000000001a466a0 & 1) != 0)) &&
                   ((lVar24 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000fa4628 * 8) + 8 +
                               (ulonglong)*puRam0000000000fa4630), lVar24 != 0 &&
                    ((lVar24 = *(longlong *)(lVar24 + 0x60), lVar24 != 0 &&
                     (*(char *)(lVar24 + 0x499) != '\0')))))) {
                  if ((cRam0000000001a35c8b == '\0') && ((bRam0000000001a466a0 & 2) == 0)) {
                    *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x10098b;
                    (*pcRam0000000000fa45c8)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)((longlong)alStack_a8 + lVar4) = 0;
                    *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1009b4;
                    (*pcRam0000000000fa45c0)(1,0x13267c8,0x1446498,0x87c);
                  }
                }
                pbVar23 = pbStack_80;
                *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1009c2;
                func_0x(pbVar23,5);
                lVar13 = lStack_50;
                uVar19 = uStack_84;
              }
            }
code_r0x001009c9:
            lVar24 = lStack_38;
            if ((uVar19 < 9) && (((*pbStack_80 & 0xe) == 0 || ((*pbStack_80 & 0xe) == 0xc)))) {
              uVar19 = 9;
            }
          }
          else {
            if (uVar19 == 0) {
              *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x1009f7;
              func_0x(asStack_88 + 1);
              uVar19 = uStack_84;
            }
            if ((uVar19 < 9) && (((*pbStack_80 & 0x1c) == 0 || ((*pbStack_80 & 0x1c) == 0xc)))) {
              uVar19 = 9;
            }
          }
          uVar18 = psVar1[lVar13 * 4];
          if (uVar15 < uVar18) {
            if (0x1fff < uVar18 + uVar19) {
              uStack_48 = (short *)CONCAT44(uStack_48._4_4_,*(undefined4 *)(param_1 + 0x20));
              uVar3 = *(undefined2 *)(param_1 + 0x24);
              *(uint *)((longlong)auStack_98 + lVar4 + 8) = (uint)uVar18;
              *(undefined4 *)((longlong)auStack_98 + lVar4) =
                   *(undefined4 *)(psVar1 + lVar13 * 4 + 2);
              *(undefined8 *)((longlong)alStack_a8 + lVar4 + 8) = 0x135e4d0;
              *(undefined8 **)((longlong)alStack_a8 + lVar4) = &uStack_48;
              *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x100a79;
              (*pcRam0000000000fa45c8)(0xb,0x18,0x16,0x65);
              uVar18 = psVar1[lVar13 * 4];
            }
            *(undefined8 *)(auStack_c8 + lVar4 + -8) = 0x100a96;
            func_0x((ulonglong)(uint)uVar15 + param_1,0,(uint)uVar18 - (uint)uVar15)
            ;
          }
          uVar15 = (short)uVar19 + psVar1[lVar13 * 4];
        }
        lStack_50 = lVar13 + 1;
        puVar14 = auStack_c8 + lVar4;
      } while (lStack_50 < lVar24);
    }
  }
  uVar18 = *(ushort *)(param_1 + 0x1e);
  iVar20 = (0x1000 - (uint)*(ushort *)(param_1 + 0x16)) * 2 - (uint)uVar18;
  if (iVar20 != 0) {
    *(undefined8 *)(puVar14 + -8) = 0x100ae9;
    func_0x((ulonglong)uVar18 + param_1,0,iVar20);
  }
  uVar10 = uStack_30 ^ (ulonglong)asStack_88;
  *(undefined8 *)(puVar14 + -8) = 0x100af5;
  func_0x(uVar10);
  return;
}

