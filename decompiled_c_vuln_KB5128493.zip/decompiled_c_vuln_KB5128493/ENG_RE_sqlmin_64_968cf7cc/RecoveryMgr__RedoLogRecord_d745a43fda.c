
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined4 *param_2,undefined param_3,ulonglong param_4)

{
  byte bVar1;
  undefined2 uVar2;
  char cVar3;
  short sVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  longlong *plVar10;
  longlong lVar11;
  undefined8 *puVar12;
  ulonglong *puVar13;
  undefined8 *puVar14;
  longlong *plVar15;
  ulonglong uVar16;
  undefined8 uVar17;
  undefined4 *puVar18;
  byte bVar19;
  uint uVar20;
  byte *pbVar21;
  longlong lVar22;
  longlong *plVar23;
  longlong *plVar24;
  ushort uVar25;
  uint *puVar26;
  longlong *plVar27;
  undefined *puVar28;
  ushort *puVar29;
  uint uVar30;
  undefined6 *puVar31;
  longlong unaff_GS_OFFSET;
  bool bVar32;
  undefined auStack_ee8 [32];
  undefined8 uStack_ec8;
  undefined8 uStack_ec0;
  undefined8 uStack_eb8;
  undefined8 uStack_eb0;
  undefined4 uStack_ea8;
  undefined uStack_ea0;
  undefined2 uStack_e98;
  ulonglong uStack_e90;
  short sStack_e88;
  ushort uStack_e86;
  uint uStack_e84;
  byte *pbStack_e80;
  undefined8 uStack_e78;
  uint uStack_e70;
  ushort uStack_e6c;
  byte *pbStack_e6a;
  undefined2 uStack_e62;
  undefined2 uStack_e60;
  undefined2 uStack_e5e;
  ushort uStack_e5c;
  undefined2 uStack_e5a;
  undefined4 uStack_e58;
  undefined uStack_e50;
  longlong *plStack_e48;
  short sStack_e40;
  ushort uStack_e3e;
  uint uStack_e3c;
  byte *pbStack_e38;
  undefined8 uStack_e30;
  uint uStack_e28;
  ushort uStack_e24;
  byte *pbStack_e22;
  undefined2 uStack_e1a;
  undefined2 uStack_e18;
  undefined2 uStack_e16;
  ushort uStack_e14;
  undefined2 uStack_e12;
  undefined4 uStack_e10;
  undefined4 uStack_e08;
  undefined2 uStack_e04;
  undefined4 *puStack_e00;
  undefined4 *puStack_df8;
  undefined8 uStack_df0;
  int iStack_de0;
  longlong *plStack_dd8;
  char cStack_dd0;
  byte bStack_dcf;
  uint uStack_dcc;
  undefined4 *puStack_dc8;
  undefined8 uStack_dc0;
  uint uStack_db8;
  uint uStack_db4;
  uint uStack_db0;
  int iStack_dac;
  uint uStack_da8;
  uint uStack_da4;
  undefined8 uStack_da0;
  ushort uStack_d48;
  uint uStack_d44;
  int iStack_d40;
  undefined4 uStack_d3c;
  undefined4 uStack_d38;
  undefined4 uStack_d34;
  uint auStack_d30 [2];
  undefined4 uStack_d28;
  undefined2 uStack_d24;
  undefined8 uStack_d18;
  undefined8 uStack_d10;
  uint uStack_ce8;
  undefined2 uStack_ce4;
  undefined8 uStack_ce0;
  longlong lStack_cd0;
  undefined uStack_cc8;
  undefined4 uStack_cc4;
  longlong *plStack_ca8;
  uint uStack_ca0;
  undefined2 uStack_c9c;
  uint uStack_c9a;
  undefined2 uStack_c96;
  undefined8 uStack_c90;
  undefined2 uStack_c88;
  undefined8 uStack_c70;
  undefined2 uStack_c68;
  undefined8 uStack_c60;
  undefined2 uStack_c58;
  undefined8 uStack_c50;
  undefined2 uStack_c48;
  undefined8 uStack_c40;
  undefined2 uStack_c38;
  undefined auStack_c30 [4];
  int iStack_c2c;
  longlong *plStack_c20;
  longlong *plStack_c18;
  longlong *plStack_c10;
  longlong *plStack_c08;
  longlong *plStack_c00;
  longlong *plStack_bf8;
  undefined auStack_bf0 [16];
  longlong lStack_be0;
  undefined8 *****pppppuStack_bd8;
  undefined8 *****pppppuStack_bd0;
  undefined4 uStack_bc8;
  undefined8 uStack_bc0;
  longlong *plStack_bb8;
  undefined4 auStack_ba0 [2];
  undefined8 uStack_b98;
  undefined8 uStack_b90;
  undefined8 uStack_b88;
  undefined8 uStack_b80;
  undefined4 auStack_b78 [2];
  undefined8 uStack_b70;
  undefined8 uStack_b68;
  undefined8 uStack_b60;
  undefined8 uStack_b58;
  undefined8 uStack_ae0;
  undefined6 *puStack_ad8;
  undefined8 uStack_ad0;
  longlong lStack_ac8;
  undefined4 *puStack_ac0;
  uint *puStack_ab8;
  longlong lStack_ab0;
  longlong lStack_aa8;
  uint *puStack_aa0;
  undefined8 *puStack_a98;
  undefined8 uStack_a90;
  longlong lStack_a88;
  undefined auStack_a50 [40];
  undefined auStack_a28 [8];
  undefined2 uStack_a20;
  undefined2 uStack_a1e;
  undefined4 uStack_a18;
  uint **ppuStack_a10;
  undefined *puStack_a08;
  undefined8 uStack_a00;
  uint *puStack_9f8;
  undefined4 uStack_9f0;
  undefined2 uStack_9ec;
  undefined2 uStack_9ea;
  longlong lStack_9e8;
  int iStack_9e0;
  undefined2 uStack_9dc;
  undefined2 uStack_9da;
  undefined auStack_9d8 [512];
  undefined4 uStack_7d8;
  undefined4 uStack_7d4;
  undefined8 uStack_7d0;
  uint uStack_7c8;
  undefined8 uStack_7c4;
  uint uStack_7bc;
  uint uStack_7b8;
  undefined auStack_7a8 [8];
  undefined4 uStack_7a0;
  undefined4 uStack_798;
  uint **ppuStack_790;
  undefined *puStack_788;
  undefined8 uStack_780;
  uint *puStack_778;
  undefined4 uStack_770;
  undefined4 uStack_76c;
  longlong *plStack_768;
  int iStack_760;
  undefined4 uStack_75c;
  undefined auStack_758 [512];
  undefined8 uStack_558;
  undefined8 uStack_550;
  uint uStack_548;
  undefined8 uStack_544;
  uint uStack_53c;
  uint uStack_538;
  undefined auStack_528 [80];
  undefined8 uStack_4d8;
  undefined2 uStack_4d0;
  undefined8 uStack_4c8;
  undefined2 uStack_4c0;
  undefined4 uStack_4bc;
  undefined8 uStack_4b8;
  undefined2 uStack_4b0;
  undefined4 uStack_4ac;
  undefined auStack_4a8 [16];
  undefined auStack_498 [16];
  undefined4 uStack_488;
  undefined4 uStack_484;
  undefined4 uStack_480;
  undefined4 uStack_47c;
  undefined4 uStack_478;
  uint uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined4 uStack_468;
  undefined4 uStack_464;
  undefined4 uStack_460;
  undefined4 uStack_45c;
  undefined auStack_458 [96];
  longlong alStack_3f8 [12];
  longlong alStack_398 [12];
  longlong alStack_338 [12];
  undefined auStack_2d8 [96];
  undefined auStack_278 [112];
  undefined auStack_208 [112];
  undefined auStack_198 [112];
  undefined auStack_128 [112];
  undefined auStack_b8 [112];
  ulonglong uStack_48;
  
  uStack_ae0 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_ee8;
  uStack_e98 = CONCAT11(uStack_e98._1_1_,param_3);
  plVar27 = (longlong *)0x0;
  iVar6 = 0;
  iStack_dac = 0;
  plStack_e48 = (longlong *)0x0;
  plVar10 = plVar27;
  uStack_e90 = param_4;
  plStack_dd8 = param_1;
  puStack_dc8 = param_2;
  uStack_dc0 = param_1;
  uStack_da0 = param_2;
  plStack_ca8 = param_1;
  if (((DAT_ & 0x10) != 0) ||
     (((lVar22 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar22 != 0 && (**(longlong **)(lVar22 + 0x38) != 0)) &&
      (iVar5 = (*_DAT_)(), iVar5 != 0)))) {
    while (((DAT_ & 0x10) != 0 ||
           (((lVar22 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
             param_4 = uStack_e90, lVar22 != 0 && (**(longlong **)(lVar22 + 0x38) != 0)) &&
            (iVar5 = (*_DAT_)(), param_4 = uStack_e90, iVar5 != 0))))) {
      iVar5 = (int)plVar10;
      if (iVar5 == (iVar5 / 0xc) * 0xc) {
        func_0x(0xf9c9e0,0xf9c9a0,*(undefined4 *)(*(longlong *)(*param_1 + 0x6b0) + 0x3a0),
                        *(longlong *)(*param_1 + 0x6b0) + 0x3a8);
      }
      auStack_b78[0] = 0x400060;
      uStack_b70 = 0;
      uStack_b60 = 0;
      uStack_b68 = 0;
      uStack_b58 = 0;
      iVar9 = func_0x(5000,auStack_b78);
      plVar10 = (longlong *)(ulonglong)(iVar5 + 1);
      if (iVar9 == 2) {
        func_0x(0x86);
      }
    }
  }
  if ((((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) != 0) &&
      (bVar19 = *(byte *)((longlong)param_2 + 0x16), 0x7e < bVar19)) &&
     ((bVar19 != 0x99 && (bVar19 != 0x86)))) {
    uStack_ec8 = 0;
    (*_DAT_)(1,0x10d23a0,0x1089cc0,0x3081);
  }
  if ((_DAT_ & 0x20000000) != 0) {
    uStack_7a0 = 0x20000;
    uStack_798 = 0;
    ppuStack_790 = &puStack_778;
    puStack_788 = auStack_758;
    uStack_558 = 0;
    uStack_780 = 0;
    uStack_550 = 0;
    puStack_778 = &uStack_548;
    uStack_770 = 0x1c;
    uStack_76c = 1;
    uStack_75c = 4;
    uStack_548 = (uint)*(ushort *)(*(longlong *)(*param_1 + 0x6b0) + 0x28);
    uStack_544 = CONCAT44(*(undefined4 *)((longlong)param_1 + 0x5674),
                          *(undefined4 *)(param_1 + 0xacf));
    uStack_53c = (uint)*(ushort *)((longlong)param_1 + 0x567c);
    bVar19 = *(byte *)((longlong)param_2 + 0x16);
    uStack_538 = (uint)bVar19;
    pbVar21 = (byte *)0xd44110;
    plVar10 = plVar27;
    do {
      iStack_760 = iVar6;
      if (*pbVar21 == bVar19) {
        plStack_768 = *(longlong **)(pbVar21 + 8);
        if (plStack_768 != (longlong *)0x0) {
          lVar22 = -1;
          do {
            lVar22 = lVar22 + 1;
          } while (*(short *)((longlong)plStack_768 + lVar22 * 2) != 0);
          iStack_760 = (int)lVar22 * 2;
        }
        break;
      }
      plStack_768 = plVar27;
      if (bVar19 < *pbVar21) break;
      plVar10 = (longlong *)((longlong)plVar10 + 1);
      pbVar21 = pbVar21 + 0x10;
    } while (plVar10 < (longlong *)0x57);
    func_0x(auStack_7a8);
  }
  pbVar21 = (byte *)0xd44110;
  if ((((((char)uStack_e98 == '\0') && (param_4 != 0)) && (lVar22 = param_1[0x108a], lVar22 != 0))
      && ((*(byte *)(lVar22 + 0x210) & 1) != 0)) &&
     ((*(short *)((longlong)param_1 + 0x567c) == 1 || (*(longlong *)(lVar22 + 0x200) == 0)))) {
    lVar11 = func_0x(*(undefined8 *)(lVar22 + 0x1c8));
    *(longlong *)(lVar22 + 0x200) = lVar11;
    *(undefined *)(lVar22 + 0x208) = 0;
    if (lVar11 == 0) {
      func_0x(0xf928f0,*(undefined4 *)((longlong)param_1 + 0x5674),
                      *(undefined4 *)(param_1 + 0xacf),*(undefined2 *)((longlong)param_1 + 0x567c));
      func_0x(param_1);
      *(undefined *)(*param_1 + 0x65f9) = 0;
    }
  }
  plVar10 = plVar27;
  if (((*(byte *)((longlong)param_2 + 0xe) & 2) == 0) ||
     (plVar10 = (longlong *)0x0, (*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) != 0)) {
LAB_:
    plVar23 = plVar27;
    if (*(char *)(param_1 + 0xbfb) != '\0') goto LAB_;
    plVar24 = (longlong *)param_1[0xadc];
    if (plVar24 != (longlong *)0x0) goto LAB_;
  }
  else {
    uStack_d28 = param_2[4];
    uStack_d24 = *(undefined2 *)(param_2 + 5);
    plVar10 = (longlong *)func_0x(param_1 + 0xb74);
    plStack_e48 = plVar10;
    if ((plVar10 == (longlong *)0x0) ||
       (((*(int *)((longlong)plVar10 + 0x3c) - 10U & 0xfffffffd) == 0 ||
        ((*(byte *)(*param_1 + 0x1cd0) & 0x40) != 0)))) goto LAB_;
    plVar23 = (longlong *)plVar10[0x10];
    if (((((char)uStack_e98 == '\0') || (param_1[0x108a] == 0)) ||
        ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) != 0)) &&
       ((iVar5 = func_0x(), iVar5 != 0 &&
        ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) == 0)))) {
      func_0x(auStack_528,param_2);
      if ((*(char *)(param_1 + 0x108e) != '\0') &&
         (cVar3 = func_0x(param_1,param_2 + 4), cVar3 == '\0')) {
        *(undefined4 *)((longlong)plVar10 + 0x11c) = 1;
      }
      uStack_bc0 = 0xf018f0;
      plVar24 = plVar27;
      if (*(int *)(plVar10 + 0xb) != 3) {
        plVar24 = (longlong *)(ulonglong)(*(int *)((longlong)plVar10 + 0x11c) != 0);
      }
      plStack_bb8 = plVar23;
      func_0x(auStack_528,*(undefined2 *)(plVar23[6] + 0x6b8),&uStack_bc0,plVar24);
    }
    if (*(int *)((longlong)plVar10 + 0x11c) == 0) {
      func_0x(plVar23,param_2,(longlong)param_1 + 0x5674);
    }
    plStack_e48 = plVar10;
    if ((((*(char *)(*param_1 + 0x1cde) != '\0') &&
         (cVar3 = func_0x(param_2), cVar3 != '\0')) &&
        ((plStack_e48 = plVar10, (*(ushort *)((longlong)param_2 + 0xe) & 0x100) != 0 &&
         ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) == 0)))) &&
       ((param_1[0x108c] != 0 || ((char)uStack_e98 == '\0')))) {
      func_0x(plVar23);
      lVar22 = *(longlong *)param_1[0x108c];
      if ((*(char *)(lVar22 + 0x16) == -0x21) ||
         (plStack_e48 = plVar10, *(char *)(lVar22 + 0x16) == -0x20)) {
        if ((*(byte *)(lVar22 + 0xe) & 1) == 0) {
          lVar22 = plVar23[0x488];
          plStack_e48 = plVar10;
          while (lVar22 != 0) {
            lVar22 = *(longlong *)(lVar22 + 8);
            (*_DAT_)(plVar23[0x488],0x10);
            plVar23[0x488] = lVar22;
            param_2 = puStack_dc8;
          }
          plVar23[0x489] = 0;
          uVar17 = (**(code **)(**(longlong **)(plVar23[6] + 0x6d0) + 0x78))();
          uStack_ec8 = CONCAT71(uStack_ec8._1_7_,5);
          puVar12 = (undefined8 *)(*_DAT_)(0x10,uVar17,0xfa9f98,0x20c5);
          *puVar12 = 0;
          puVar12[1] = plVar23[0x48a];
          plVar23[0x48a] = (longlong)puVar12;
        }
        else {
          plVar24 = (longlong *)plVar23[0x48a];
          plVar23[0x48a] = plVar24[1];
          *plVar24 = lVar22;
          plVar24[1] = 0;
          if (plVar23[0x488] == 0) {
            plVar23[0x488] = (longlong)plVar24;
            plVar23[0x489] = (longlong)plVar24;
            plStack_e48 = plVar10;
          }
          else {
            *(longlong **)(plVar23[0x489] + 8) = plVar24;
            plVar23[0x489] = (longlong)plVar24;
            plStack_e48 = plVar10;
          }
        }
      }
      param_1[0x108c] = 0;
    }
    if ((*(byte *)((longlong)param_2 + 0xe) & 1) != 0) {
      if (1 < (ulonglong)param_1[0xb3c]) {
        param_1[0xb3c] = param_1[0xb3c] - 2;
      }
      if ((((DAT_ == '\0') && ((DAT_ & 8) == 0)) &&
          ((bool)(*(byte *)((longlong)param_2 + 0xf) & 1) !=
           ((*(uint *)(plVar10 + 7) & 0x240) == 0x40))) &&
         ((*(char *)((longlong)param_2 + 0x16) != -0xc &&
          (*(char *)((longlong)param_2 + 0x16) != -0x73)))) {
        uStack_ec8 = 0;
        (*_DAT_)(1,0x10d2480,0x1089cc0,0x3137);
      }
    }
    if ((*(char *)(param_1 + 0xbfb) == '\0') &&
       (plVar24 = (longlong *)param_1[0xadc], plVar24 != (longlong *)0x0)) {
LAB_:
      (**(code **)(*plVar24 + 0x40))();
    }
    if (*(char *)(param_1 + 0xbfb) != '\0') {
LAB_:
      if ((plVar10 != (longlong *)0x0) && (lVar22 = plVar10[0x10], lVar22 != 0)) {
        *(undefined8 *)(lVar22 + 0x221c) = *(undefined8 *)((longlong)plVar10 + 0x4c);
        *(undefined2 *)(lVar22 + 0x2224) = *(undefined2 *)((longlong)plVar10 + 0x54);
      }
    }
  }
  bVar19 = *(byte *)((longlong)param_2 + 0x16);
  if (0x7e < bVar19) {
    func_0x(param_1,param_2,(char)uStack_e98,plVar10);
    goto LAB_;
  }
  puStack_e00 = param_2;
  puStack_df8 = param_2;
  iVar5 = func_0x(*param_1);
  if (iVar5 == 0) {
    if (*(char *)((longlong)param_2 + 0x17) == '\v') {
      if (bVar19 == 4) {
        bVar32 = *(short *)((longlong)param_2 + 0x1e) == 0;
LAB_:
        if ((bVar32) && ((*(byte *)((longlong)param_2 + 0xe) & 1) == 0)) {
          func_0x(param_1,param_2,(longlong)param_1 + 0x5674);
        }
      }
    }
    else if ((*(char *)((longlong)param_2 + 0x17) == '\b') && (bVar19 == 7)) {
      bVar32 = *(short *)((longlong)param_2 + 0x1e) == 1;
      goto LAB_;
    }
  }
  puVar31 = (undefined6 *)(param_2 + 6);
  uStack_ce8 = *(uint *)puVar31;
  uStack_ce4 = *(undefined2 *)(param_2 + 7);
  uStack_e90 = func_0x(*(undefined8 *)
                                (*(longlong *)param_1[0xbf0] +
                                ((ulonglong)uStack_ce8 %
                                (ulonglong)*(uint *)((longlong *)param_1[0xbf0] + 1)) * 8),
                               &uStack_ce8);
  if ((_DAT_ != 0) &&
     (((uStack_df0 = *(undefined8 *)(*param_1 + 0x6a20), *(short *)(*param_1 + 0x6a28) != 0 ||
       ((uint)uStack_df0 != 0)) || ((int)((ulonglong)uStack_df0 >> 0x20) != 0)))) {
    bVar32 = false;
    plVar24 = plVar27;
    while( true ) {
      param_2 = puStack_dc8;
      lVar22 = *param_1;
      uStack_df0 = *(undefined8 *)(lVar22 + 0x6a20);
      if (*(short *)(lVar22 + 0x6a28) != *(short *)((longlong)param_1 + 0x567c)) break;
      if (((uint)uStack_df0 != *(int *)((longlong)param_1 + 0x5674)) ||
         ((int)((ulonglong)uStack_df0 >> 0x20) != *(int *)(param_1 + 0xacf))) break;
      bVar32 = true;
      iVar5 = (int)plVar24;
      if (iVar5 == (iVar5 / 0xc) * 0xc) {
        uStack_eb8 = (longlong *)
                     CONCAT44(uStack_eb8._4_4_,(uint)*(ushort *)((longlong)param_1 + 0x567c));
        uStack_ec0 = (undefined8 *)CONCAT44(uStack_ec0._4_4_,*(undefined4 *)(param_1 + 0xacf));
        uStack_ec8 = CONCAT44(uStack_ec8._4_4_,*(int *)((longlong)param_1 + 0x5674));
        func_0x(0xf9ca70,0xf9c9a0,*(undefined4 *)(*(longlong *)(lVar22 + 0x6b0) + 0x3a0),
                        *(longlong *)(lVar22 + 0x6b0) + 0x3a8);
      }
      plVar24 = (longlong *)(ulonglong)(iVar5 + 1);
      auStack_ba0[0] = 0x400060;
      uStack_b98 = 0;
      uStack_b88 = 0;
      uStack_b90 = 0;
      uStack_b80 = 0;
      iVar5 = func_0x(5000,auStack_ba0);
      if (iVar5 == 2) {
        func_0x(0x86);
      }
      func_0x(*param_1);
    }
    puVar31 = (undefined6 *)(puStack_dc8 + 6);
    if (bVar32) {
      uStack_eb8 = (longlong *)
                   CONCAT44(uStack_eb8._4_4_,(uint)*(ushort *)((longlong)param_1 + 0x567c));
      uStack_ec0 = (undefined8 *)CONCAT44(uStack_ec0._4_4_,*(undefined4 *)(param_1 + 0xacf));
      uStack_ec8 = CONCAT44(uStack_ec8._4_4_,*(undefined4 *)((longlong)param_1 + 0x5674));
      func_0x(0xf9cb00,0xf9c9a0,*(undefined4 *)(*(longlong *)(lVar22 + 0x6b0) + 0x3a0),
                      *(longlong *)(lVar22 + 0x6b0) + 0x3a8);
      goto LAB_;
    }
  }
  uVar16 = uStack_e90;
  if (uStack_e90 == 0) goto LAB_;
  iVar5 = func_0x(param_1,param_2);
  if (iVar5 == 0) {
LAB_:
    if (*(char *)((longlong)param_2 + 0x16) != '\x10') goto LAB_;
  }
  else {
    uVar8 = *(uint *)(uVar16 + 0x30);
    do {
      uVar20 = uVar8 & 0xfffffffe;
      uStack_df0 = *(undefined8 *)(uVar16 + 0x24);
      LOCK();
      UNLOCK();
      uVar8 = *(uint *)(uVar16 + 0x30);
    } while (uVar20 != uVar8);
    if (((uint)uStack_df0 <= *(uint *)((longlong)param_1 + 0x5674)) &&
       ((*(uint *)((longlong)param_1 + 0x5674) != (uint)uStack_df0 ||
        ((uVar8 = (uint)((ulonglong)uStack_df0 >> 0x20), uVar8 <= *(uint *)(param_1 + 0xacf) &&
         ((*(uint *)(param_1 + 0xacf) != uVar8 ||
          (*(ushort *)(uVar16 + 0x2c) <= *(ushort *)((longlong)param_1 + 0x567c))))))))) {
LAB_:
      puStack_e00 = puStack_df8;
      goto LAB_;
    }
    if (((*(byte *)(*(longlong *)(*param_1 + 0x6b0) + 0x3c) & 1) == 0) ||
       ((*(longlong *)(*(longlong *)(*param_1 + 0x6b0) + 0x280) != 0 ||
        (*(char *)(param_1 + 0xbfb) == '\0')))) {
LAB_:
      if (((DAT_ & 8) != 0) ||
         (((lVar22 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
           lVar22 != 0 && (lVar22 = **(longlong **)(lVar22 + 0x38), lVar22 != 0)) &&
          (iVar6 = (*_DAT_)(lVar22,0xd4b), uVar16 = uStack_e90, iVar6 != 0)))) {
        uStack_da4 = 100;
        func_0x((longlong)param_1 + 0x5674,&uStack_da4,auStack_b8);
        func_0x((longlong)param_1 + 0x5674,auStack_2d8,&plStack_ca8);
        uStack_ea8 = *(uint *)puVar31;
        bVar19 = *(byte *)((longlong)param_2 + 0x16);
        plVar10 = plVar27;
        do {
          bVar1 = *pbVar21;
          if (bVar1 == bVar19) {
            uStack_eb8 = *(longlong **)(pbVar21 + 8);
            break;
          }
          uStack_eb8 = plVar27;
          if (bVar19 <= bVar1 && bVar1 != bVar19) break;
          plVar10 = (longlong *)((longlong)plVar10 + 1);
          pbVar21 = pbVar21 + 0x10;
        } while (plVar10 < (longlong *)0x57);
        uStack_eb0 = CONCAT44(uStack_eb0._4_4_,(uint)*(ushort *)(param_2 + 7));
        uStack_ec0 = (undefined8 *)CONCAT44(uStack_ec0._4_4_,param_2[4]);
        uStack_ec8 = CONCAT44(uStack_ec8._4_4_,(uint)*(ushort *)(param_2 + 5));
        func_0x(0xf9cb80,uStack_da4 >> 1,auStack_b8,auStack_2d8);
        uVar16 = uStack_e90;
      }
      if ((*(char *)(param_1 + 0xbfb) == '\0') && ((*(byte *)((longlong)param_2 + 0xe) & 1) == 0)) {
        if (uVar16 != 0) goto LAB_;
        if ((plVar23 != (longlong *)0x0) &&
           (cVar3 = (**(code **)(*plVar23 + 0x88))(plVar23), cVar3 != '\0')) {
          plVar10 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&plStack_c00);
            plVar10 = plStack_c00;
          }
          uStack_dc0 = (longlong *)CONCAT26(uStack_dc0._6_2_,*puVar31);
          iVar6 = func_0x(_DAT_,*param_1,&uStack_dc0,0);
          plVar23 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&plStack_bf8);
            plVar23 = plStack_bf8;
          }
          plVar24 = plVar27;
          if ((plVar23 < plVar10) ||
             (plVar24 = (longlong *)((longlong)plVar23 - (longlong)plVar10),
             plVar24 != (longlong *)0xffffffffffffffff)) {
            if (*_DAT_ == 0) {
              uVar16 = (ulonglong)plVar24 / 10000;
            }
            else {
              uVar16 = (ulonglong)((longlong)plVar24 * 1000) / *_DAT_;
            }
          }
          else {
            uVar16 = 0xffffffffffffffff;
          }
          param_1[0xb5b] = param_1[0xb5b] + 1;
          if (iVar6 == 0) {
            param_1[0xb5c] = param_1[0xb5c] + 1;
          }
          if (uVar16 != 0) {
            param_1[0xb5e] = param_1[0xb5e] + 1;
          }
          param_1[0xb5d] = param_1[0xb5d] + (longlong)plVar24;
        }
LAB_:
        uStack_4c8 = 0;
        uStack_4c0 = 0;
        uStack_4bc = 0;
        puVar12 = &uStack_4c8;
      }
      else {
        if (uVar16 == 0) goto LAB_;
LAB_:
        uStack_4b8 = *(undefined8 *)(uVar16 + 0x24);
        uStack_4b0 = *(undefined2 *)(uVar16 + 0x2c);
        uStack_4ac = *(undefined4 *)(uVar16 + 0x30);
        puVar12 = &uStack_4b8;
      }
      uVar8 = *(uint *)((longlong)puVar12 + 0xc);
      uStack_c70 = *puVar12;
      uStack_c68 = *(undefined2 *)(puVar12 + 1);
      do {
        uVar20 = uVar8 & 0xfffffffe;
        LOCK();
        UNLOCK();
        uVar8 = *(uint *)((longlong)puVar12 + 0xc);
      } while (uVar20 != uVar8);
      uStack_c40 = *(undefined8 *)((longlong)param_1 + 0x5674);
      uStack_c38 = *(undefined2 *)((longlong)param_1 + 0x567c);
      uStack_ea0 = 0;
      uStack_ea8 = CONCAT31(uStack_ea8._1_3_,1);
      uStack_eb0 = uStack_eb0 & 0xffffffffffffff00;
      uStack_eb8 = (longlong *)((ulonglong)uStack_eb8 & 0xffffffffffffff00);
      uStack_ec0 = (undefined8 *)((ulonglong)uStack_ec0 & 0xffffffffffffff00);
      uStack_ec8 = CONCAT71(uStack_ec8._1_7_,1);
      func_0x(param_1,param_2,&uStack_c40,&uStack_c70);
      lVar22 = *(longlong *)(*param_1 + 0x6b0);
      if ((((*(byte *)(lVar22 + 0x3c) & 1) != 0) && (*(longlong *)(lVar22 + 0x280) == 0)) &&
         (lVar22 = func_0x
                             (*(undefined8 *)(*param_1 + 0x6a0),*(undefined2 *)(param_2 + 7),0),
         (*(byte *)(lVar22 + 100) & 0x40) == 0)) {
        (**(code **)(**(longlong **)(*param_1 + 0x6c8) + 0x170))
                  (*(longlong **)(*param_1 + 0x6c8),auStack_4a8);
        if (*(char *)((longlong)param_2 + 0x16) == '\x10') {
          (*_DAT_)();
        }
        else {
          (*_DAT_)(lVar22,(longlong)param_1 + 0x5674,auStack_4a8,*(uint *)puVar31);
        }
      }
      if (uStack_e90 != 0) {
        plVar10 = (longlong *)param_1[0xbf0];
        if (plVar10 != (longlong *)0x0) {
          plVar27 = *(longlong **)
                     (*plVar10 +
                     ((ulonglong)*(uint *)(uStack_e90 + 0x10) % (ulonglong)*(uint *)(plVar10 + 1)) *
                     8);
        }
        uVar8 = *(uint *)(uStack_e90 + 0x30);
        do {
          uVar20 = uVar8 & 0xfffffffe;
          uStack_c60 = *(undefined8 *)(uStack_e90 + 0x24);
          uStack_c58 = *(undefined2 *)(uStack_e90 + 0x2c);
          LOCK();
          UNLOCK();
          uVar8 = *(uint *)(uStack_e90 + 0x30);
        } while (uVar20 != uVar8);
        func_0x(uStack_e90,&uStack_c60,plVar27);
      }
      goto LAB_;
    }
    if ((*(uint *)puVar31 == 0) ||
       ((*(uint *)puVar31 == 9 && (*(short *)((longlong)puVar31 + 4) == 1)))) goto LAB_;
    if (*(char *)((longlong)param_2 + 0x16) != '\x13') goto LAB_;
    puStack_e00 = puStack_df8;
LAB_:
    if (((*(byte *)(*param_1 + 0x1cd0) & 1) != 0) || (*(int *)(*param_1 + 0x674) == 5)) {
      uStack_ec8 = 0;
      (*_DAT_)(1,0x10d2420,0x1089cc0,0x3215);
      uVar16 = uStack_e90;
    }
  }
  iVar9 = 0;
  iVar5 = iVar6;
  if ((*(int *)(param_1 + 0xbfe) != 0) &&
     ((plVar10 == (longlong *)0x0 || (iVar5 = iVar9, *(int *)(plVar10 + 0xb) != 3)))) {
    iVar5 = 1;
  }
  *(int *)((longlong)param_1 + 0x5ff4) = iVar5;
  uVar8 = *(uint *)(uVar16 + 0x38);
  if (*(int *)(uVar16 + 0x48) != 1) {
    uVar8 = uVar8 & 0xffff;
  }
  if ((uVar8 != 0) && (iVar5 = func_0x(param_1,(uint *)(uVar16 + 0x38),plVar10), iVar5 != 0)
     ) {
    if (((DAT_ & 8) != 0) ||
       (((lVar22 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
         lVar22 != 0 && (lVar22 = **(longlong **)(lVar22 + 0x38), lVar22 != 0)) &&
        (iVar6 = (*_DAT_)(lVar22,0xd4b), iVar6 != 0)))) {
      uStack_db4 = 100;
      func_0x((longlong)param_1 + 0x5674,&uStack_db4,auStack_278);
      func_0x((longlong)param_1 + 0x5674,auStack_458,auStack_c30);
      uStack_ea8 = *(uint *)puVar31;
      bVar19 = *(byte *)((longlong)param_2 + 0x16);
      plVar10 = plVar27;
      do {
        bVar1 = *pbVar21;
        if (bVar1 == bVar19) {
          plVar27 = *(longlong **)(pbVar21 + 8);
          break;
        }
        if (bVar19 <= bVar1 && bVar1 != bVar19) break;
        plVar10 = (longlong *)((longlong)plVar10 + 1);
        pbVar21 = pbVar21 + 0x10;
      } while (plVar10 < (longlong *)0x57);
      uStack_eb0 = CONCAT44(uStack_eb0._4_4_,(uint)*(ushort *)(param_2 + 7));
      uStack_ec0 = (undefined8 *)CONCAT44(uStack_ec0._4_4_,param_2[4]);
      uStack_ec8 = CONCAT44(uStack_ec8._4_4_,(uint)*(ushort *)(param_2 + 5));
      uStack_eb8 = plVar27;
      func_0x(0xf9cc40,uStack_db4 >> 1,auStack_278,auStack_458);
    }
    uVar8 = *(uint *)(uStack_e90 + 0x30);
    do {
      uVar20 = uVar8 & 0xfffffffe;
      uStack_c50 = *(undefined8 *)(uStack_e90 + 0x24);
      uStack_c48 = *(undefined2 *)(uStack_e90 + 0x2c);
      LOCK();
      UNLOCK();
      uVar8 = *(uint *)(uStack_e90 + 0x30);
    } while (uVar20 != uVar8);
    uStack_c90 = *(undefined8 *)((longlong)param_1 + 0x5674);
    uStack_c88 = *(undefined2 *)((longlong)param_1 + 0x567c);
    uStack_ea0 = 0;
    uStack_ea8 = uStack_ea8 & 0xffffff00;
    uStack_eb0 = uStack_eb0 & 0xffffffffffffff00;
    uStack_eb8 = (longlong *)((ulonglong)uStack_eb8 & 0xffffffffffffff00);
    uStack_ec0 = (undefined8 *)((ulonglong)uStack_ec0 & 0xffffffffffffff00);
    uStack_ec8 = CONCAT71(uStack_ec8._1_7_,1);
    func_0x(param_1,param_2,&uStack_c90,&uStack_c50);
    goto LAB_;
  }
  uStack_ec8 = 930000;
  if (*(int *)((longlong)param_1 + 0x5ff4) == 0) {
    uStack_ec8 = 0xe2ec0;
  }
  uStack_ec0 = (undefined8 *)0x0;
  func_0x(auStack_a50,0,0,0);
  if ((((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) == 0) &&
      (*(char *)(*plStack_dd8 + 0x206c) == '\0')) || (*(char *)((longlong)param_2 + 0x16) != '\x10')
     ) {
    uStack_478 = 0;
    uStack_474 = uStack_474 & 0xffff0000;
    uStack_e98 = CONCAT11(uStack_e98._1_1_,DAT_);
    cStack_dd0 = DAT_;
    if (DAT_ != '\0') {
      puVar18 = (undefined4 *)func_0x(param_1);
      uStack_488 = *param_2;
      uStack_484 = param_2[1];
      uStack_480 = param_2[2];
      uStack_47c = param_2[3];
      uStack_478 = param_2[4];
      uStack_474 = param_2[5];
      uStack_470 = param_2[6];
      uStack_46c = param_2[7];
      uStack_468 = param_2[8];
      uStack_464 = param_2[9];
      uStack_460 = param_2[10];
      uStack_45c = param_2[0xb];
      puStack_ac0 = puVar18;
      if (puVar18 != (undefined4 *)0x0) {
        uStack_d44 = func_0x(param_2);
        if ((*(char *)((longlong)param_2 + 0x16) == '\n') && (uStack_d44 < 0x34)) {
          uStack_d44 = 0x34;
        }
        func_0x(puVar18,0x6000,param_2,uStack_d44);
        puStack_e00 = puVar18;
        puStack_df8 = puVar18;
      }
    }
    uStack_e50 = 0;
    lVar22 = param_1[0x108a];
    uVar16 = uStack_e90;
    if ((lVar22 == 0) ||
       (iVar5 = func_0x(param_1,puStack_e00), uVar16 = uStack_e90, iVar5 != 0)) {
LAB_:
      puVar18 = puStack_e00;
      uStack_eb0 = 0;
      uStack_eb8 = (longlong *)0x0;
      uStack_ec0 = (undefined8 *)((ulonglong)uStack_ec0 & 0xffffffffffffff00);
      uStack_ec8 = uStack_ec8 & 0xffffffffffffff00;
      iVar5 = func_0x(param_1,puStack_e00,(longlong)param_1 + 0x5674,uVar16);
      iStack_de0 = iVar5;
      iStack_c2c = iVar5;
      if ((*(char *)((longlong)param_2 + 0x16) == '\x15') && (iVar5 == 0)) {
        puVar26 = puVar18 + 6;
        uStack_c9a = *puVar26;
        uStack_c96 = *(undefined2 *)(puVar18 + 7);
        lStack_ab0 = *param_1;
        puStack_ab8 = puVar26;
        lStack_aa8 = func_0x(*(undefined8 *)(lStack_ab0 + 0x6a0),uStack_c96,1);
        if (lStack_aa8 != 0) {
          uStack_e08 = *puVar26;
          uStack_e04 = *(undefined2 *)(puVar18 + 7);
          puStack_aa0 = puVar26;
          if (uStack_e08 < *(uint *)(lStack_aa8 + 0x80)) {
            func_0x(param_1,puStack_e00,(longlong)param_1 + 0x5674);
          }
        }
      }
    }
    else {
      uStack_ec8 = uStack_e90;
      cVar3 = func_0x(lVar22,param_2,(longlong)param_1 + 0x5674,plVar10);
      if (cVar3 == '\0') {
        func_0x(param_1,0);
        goto LAB_;
      }
      iStack_de0 = 0;
      iStack_dac = 1;
      uStack_e50 = 1;
      iVar5 = iVar9;
    }
    puVar12 = (undefined8 *)((longlong)param_1 + 0x5674);
    if (((char)uStack_e98 != '\0') &&
       (iVar7 = func_0x(puStack_e00,&uStack_488,0x30), iVar7 != 0)) {
      uStack_ce0 = 0x4000000000000017;
      if ((_DAT_ & 0x40000000) != 0) {
        puStack_dc8 = (undefined4 *)*puVar12;
        uStack_df0 = 0x4000000000000017;
        uStack_a20 = 0;
        uStack_a1e = 2;
        uStack_a18 = 0;
        ppuStack_a10 = &puStack_9f8;
        puStack_a08 = auStack_9d8;
        uStack_7d8 = 0;
        uStack_7d4 = 0;
        uStack_a00 = 0;
        uStack_7d0 = 0;
        puStack_9f8 = &uStack_7c8;
        uStack_9f0 = 0x1c;
        uStack_9ec = 1;
        uStack_9ea = 0;
        lStack_9e8 = 0;
        iStack_9e0 = 0;
        uStack_9dc = 4;
        uStack_9da = 0;
        uStack_d48 = *(ushort *)(*(longlong *)(*param_1 + 0x6b0) + 0x28);
        uStack_7c8 = (uint)uStack_d48;
        uStack_a90 = CONCAT44(*(undefined4 *)puVar12,*(undefined4 *)(param_1 + 0xacf));
        uStack_7bc = (uint)*(ushort *)((longlong)param_1 + 0x567c);
        uStack_7b8 = (uint)*(byte *)((longlong)param_2 + 0x16);
        puStack_a98 = puVar12;
        uStack_7c4 = uStack_a90;
        uVar2 = 4;
        lStack_a88 = func_0x(*(byte *)((longlong)param_2 + 0x16));
        uStack_9dc = uVar2;
        if (lStack_a88 != 0) {
          lVar22 = -1;
          do {
            lVar22 = lVar22 + 1;
          } while (*(short *)(lStack_a88 + lVar22 * 2) != 0);
          iVar6 = (int)lVar22 * 2;
        }
        uStack_9da = 0;
        iStack_d40 = iVar6;
        lStack_9e8 = lStack_a88;
        iStack_9e0 = iVar6;
        func_0x(auStack_a28);
      }
      cVar3 = func_0x(*param_1);
      if (cVar3 == '\0') {
        bStack_dcf = DAT_;
        if ((DAT_ & 1) == 0) goto LAB_;
        bVar19 = *(byte *)((longlong)param_2 + 0x16);
        uStack_ec8 = 0x10d1f48;
        uVar17 = 0x32ce;
      }
      else {
        bVar19 = *(byte *)((longlong)param_2 + 0x16);
        uStack_ec8 = 0x10d1f78;
        uVar17 = 0x32c4;
      }
      uStack_ec0 = (undefined8 *)CONCAT44(uStack_ec0._4_4_,(uint)bVar19);
      (*_DAT_)(1,0x108d8b8,0x1089cc0,uVar17);
    }
LAB_:
    if (iVar5 != 0) {
      param_1[0xbfc] = param_1[0xbfc] + 1;
    }
  }
  else {
    uStack_ca0 = *(uint *)puVar31;
    uStack_c9c = *(undefined2 *)((longlong)puVar31 + 4);
    uStack_ad0 = *(undefined8 *)(*plStack_dd8 + 0x6a0);
    puStack_ad8 = puVar31;
    lStack_ac8 = func_0x(uStack_ad0,uStack_c9c,1);
    if (((lStack_ac8 == 0) || ((*(byte *)(lStack_ac8 + 100) & 0x40) == 0)) && (param_1[0x108a] != 0)
       ) {
      func_0x(param_1[0x108a],0xd44bd8,(longlong)param_1 + 0x5674);
    }
    func_0x(param_1,param_2,(longlong)param_1 + 0x5674,uStack_e90);
    iStack_de0 = 0;
  }
  func_0x(auStack_a50);
  lVar11 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar22 = *(longlong *)(lVar11 + 0x100);
  if (lVar22 == 0) {
    (*_DAT_)();
    lVar22 = *(longlong *)(lVar11 + 0x100);
  }
  if (*(int *)(lVar22 + 0x22c) != 0) {
    (*_DAT_)();
  }
  if (iStack_de0 == 0) {
    if (iStack_dac == 0) {
      if (((DAT_ & 8) != 0) ||
         (((lVar22 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
           lVar22 != 0 && (lVar22 = **(longlong **)(lVar22 + 0x38), lVar22 != 0)) &&
          (iVar6 = (*_DAT_)(lVar22,0xd4b), iVar6 != 0)))) {
        uStack_d34 = 0x5c;
        uStack_db8 = 100;
        func_0x((longlong)param_1 + 0x5674,&uStack_db8,auStack_128);
        func_0x((longlong)param_1 + 0x5674,alStack_338,&uStack_d34);
        uStack_ea8 = puStack_df8[6];
        bVar19 = *(byte *)((longlong)param_2 + 0x16);
        plVar10 = plVar27;
        do {
          bVar1 = *pbVar21;
          if (bVar1 == bVar19) {
            uStack_eb8 = *(longlong **)(pbVar21 + 8);
            break;
          }
          uStack_eb8 = plVar27;
          if (bVar19 <= bVar1 && bVar1 != bVar19) break;
          plVar10 = (longlong *)((longlong)plVar10 + 1);
          pbVar21 = pbVar21 + 0x10;
        } while (plVar10 < (longlong *)0x57);
        uStack_eb0 = CONCAT44(uStack_eb0._4_4_,(uint)*(ushort *)(puStack_df8 + 7));
        uStack_ec0 = (undefined8 *)CONCAT44(uStack_ec0._4_4_,param_2[4]);
        uStack_ec8 = CONCAT44(uStack_ec8._4_4_,(uint)*(ushort *)(param_2 + 5));
        plVar10 = alStack_338;
        puVar28 = auStack_128;
        uVar17 = 0xf9b650;
        uVar8 = uStack_db8;
        goto LAB_;
      }
    }
    else if (((DAT_ & 8) != 0) ||
            (((lVar22 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
              lVar22 != 0 && (lVar22 = **(longlong **)(lVar22 + 0x38), lVar22 != 0)) &&
             (iVar6 = (*_DAT_)(lVar22,0xd4b), iVar6 != 0)))) {
      uStack_d38 = 0x5c;
      uStack_da8 = 100;
      func_0x((longlong)param_1 + 0x5674,&uStack_da8,auStack_198);
      func_0x((longlong)param_1 + 0x5674,alStack_398,&uStack_d38);
      uStack_ea8 = puStack_df8[6];
      bVar19 = *(byte *)((longlong)param_2 + 0x16);
      plVar10 = plVar27;
      do {
        bVar1 = *pbVar21;
        if (bVar1 == bVar19) {
          uStack_eb8 = *(longlong **)(pbVar21 + 8);
          break;
        }
        uStack_eb8 = plVar27;
        if (bVar19 <= bVar1 && bVar1 != bVar19) break;
        plVar10 = (longlong *)((longlong)plVar10 + 1);
        pbVar21 = pbVar21 + 0x10;
      } while (plVar10 < (longlong *)0x57);
      uStack_eb0 = CONCAT44(uStack_eb0._4_4_,(uint)*(ushort *)(puStack_df8 + 7));
      uStack_ec0 = (undefined8 *)CONCAT44(uStack_ec0._4_4_,param_2[4]);
      uStack_ec8 = CONCAT44(uStack_ec8._4_4_,(uint)*(ushort *)(param_2 + 5));
      plVar10 = alStack_398;
      puVar28 = auStack_198;
      uVar17 = 0xf9b020;
      uVar8 = uStack_da8;
LAB_:
      func_0x(uVar17,uVar8 >> 1,puVar28,plVar10);
    }
    if (*(int *)(param_1 + 4) != 3) goto LAB_;
  }
  else if (((DAT_ & 8) != 0) ||
          (((lVar22 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
            lVar22 != 0 && (lVar22 = **(longlong **)(lVar22 + 0x38), lVar22 != 0)) &&
           (iVar6 = (*_DAT_)(lVar22,0xd4b), iVar6 != 0)))) {
    uStack_d3c = 0x5c;
    uStack_db0 = 100;
    func_0x((longlong)param_1 + 0x5674,&uStack_db0,auStack_208);
    func_0x((longlong)param_1 + 0x5674,alStack_3f8,&uStack_d3c);
    uStack_ea8 = puStack_df8[6];
    bVar19 = *(byte *)((longlong)param_2 + 0x16);
    plVar10 = plVar27;
    do {
      bVar1 = *pbVar21;
      if (bVar1 == bVar19) {
        uStack_eb8 = *(longlong **)(pbVar21 + 8);
        break;
      }
      uStack_eb8 = plVar27;
      if (bVar19 <= bVar1 && bVar1 != bVar19) break;
      plVar10 = (longlong *)((longlong)plVar10 + 1);
      pbVar21 = pbVar21 + 0x10;
    } while (plVar10 < (longlong *)0x57);
    uStack_eb0 = CONCAT44(uStack_eb0._4_4_,(uint)*(ushort *)(puStack_df8 + 7));
    uStack_ec0 = (undefined8 *)CONCAT44(uStack_ec0._4_4_,param_2[4]);
    uStack_ec8 = CONCAT44(uStack_ec8._4_4_,(uint)*(ushort *)(param_2 + 5));
    func_0x(0xf9af90,uStack_db0 >> 1,auStack_208,alStack_3f8);
  }
  if (*(char *)((longlong)param_2 + 0x16) == '\x04') {
    if (((*(char *)((longlong)param_2 + 0x17) == '\x14') ||
        (*(char *)((longlong)param_2 + 0x17) == '\x17')) &&
       ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) == 0)) {
      uStack_e98 = *(ushort *)(*param_1 + 0x67e);
      lVar22 = *(longlong *)(*param_1 + 0x6b0);
      uVar16 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      if (*(int *)(lVar22 + 0x1500) == 0) {
        LOCK();
        bVar32 = *(ulonglong *)(lVar22 + 0x1500) == 0;
        if (bVar32) {
          *(ulonglong *)(lVar22 + 0x1500) = uVar16;
        }
        UNLOCK();
        if (!bVar32) goto LAB_;
      }
      else {
LAB_:
        plVar23 = plVar27;
        plVar10 = plVar27;
        if (((byte)*_DAT_ & 0x84) == 0x84) {
          lVar11 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          if ((lVar11 != 0) && (*(longlong *)(lVar11 + 0x110) == lVar11)) {
            plVar10 = *(longlong **)(lVar11 + 0x100);
          }
          if ((plVar10 != (longlong *)0x0) && (plVar23 = _DAT_, *_DAT_ != 0)) {
            (*_DAT_)(&plStack_c20);
            plVar23 = plStack_c20;
          }
        }
        if (*(char *)(_DAT_ + 199) < '\0') {
          func_0x(lVar22 + 0x1500,plVar10,uVar16);
        }
        else {
          func_0x(lVar22 + 0x1500,uVar16);
        }
        if (plVar10 != (longlong *)0x0) {
          plVar24 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&plStack_c18);
            plVar24 = plStack_c18;
          }
          plVar15 = plVar27;
          if (plVar23 <= plVar24) {
            plVar15 = (longlong *)((longlong)plVar24 - (longlong)plVar23);
          }
          plVar10[399] = plVar10[399] + (longlong)plVar15;
        }
      }
      lVar22 = *param_1;
      uStack_ce0 = *(undefined8 *)(lVar22 + 0x8a8);
      uStack_e08 = CONCAT22(uStack_e08._2_2_,*(undefined2 *)(lVar22 + 0x8b0));
      lVar22 = *(longlong *)(lVar22 + 0x6b0);
      if ((*_DAT_ != '\0') && (iVar6 = (*_DAT_)(), iVar6 == (iVar6 / 5) * 5)) {
        func_0x();
      }
      *(undefined8 *)(lVar22 + 0x1500) = 0;
      func_0x(*param_1);
      lVar22 = *(longlong *)(*param_1 + 0x6b0);
      uVar16 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      if (*(int *)(lVar22 + 0x1500) == 0) {
        LOCK();
        bVar32 = *(ulonglong *)(lVar22 + 0x1500) == 0;
        if (bVar32) {
          *(ulonglong *)(lVar22 + 0x1500) = uVar16;
        }
        UNLOCK();
        if (!bVar32) goto LAB_;
      }
      else {
LAB_:
        plVar23 = plVar27;
        plVar10 = plVar27;
        if (((byte)*_DAT_ & 0x84) == 0x84) {
          lVar11 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          if ((lVar11 != 0) && (*(longlong *)(lVar11 + 0x110) == lVar11)) {
            plVar10 = *(longlong **)(lVar11 + 0x100);
          }
          if ((plVar10 != (longlong *)0x0) && (plVar23 = _DAT_, *_DAT_ != 0)) {
            (*_DAT_)(&plStack_c10);
            plVar23 = plStack_c10;
          }
        }
        if (*(char *)(_DAT_ + 199) < '\0') {
          func_0x(lVar22 + 0x1500,plVar10,uVar16);
        }
        else {
          func_0x(lVar22 + 0x1500,uVar16);
        }
        if (plVar10 != (longlong *)0x0) {
          plVar24 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&plStack_c08);
            plVar24 = plStack_c08;
          }
          plVar15 = plVar27;
          if (plVar23 <= plVar24) {
            plVar15 = (longlong *)((longlong)plVar24 - (longlong)plVar23);
          }
          plVar10[399] = plVar10[399] + (longlong)plVar15;
        }
      }
      lVar22 = *param_1;
      uStack_df0 = *(undefined8 *)(lVar22 + 0x8a8);
      uVar25 = *(ushort *)(lVar22 + 0x8b0);
      lVar22 = *(longlong *)(lVar22 + 0x6b0);
      if ((*_DAT_ != '\0') && (iVar6 = (*_DAT_)(), iVar6 == (iVar6 / 5) * 5)) {
        func_0x();
      }
      *(undefined8 *)(lVar22 + 0x1500) = 0;
      lVar22 = *param_1;
      if (uStack_e98 != *(ushort *)(lVar22 + 0x67e)) {
        uStack_ec0 = (undefined8 *)CONCAT44(uStack_ec0._4_4_,(uint)*(ushort *)(lVar22 + 0x67e));
        uStack_ec8 = CONCAT44(uStack_ec8._4_4_,(uint)uStack_e98);
        func_0x(lVar22,0x3e1,*(undefined4 *)(*(longlong *)(lVar22 + 0x6b0) + 0x3a0),
                        *(longlong *)(lVar22 + 0x6b0) + 0x3a8);
        lVar22 = *plStack_dd8;
      }
      if ((*(char *)(lVar22 + 0x2050) != '\0') &&
         ((*(byte *)(*(longlong *)(lVar22 + 0x6b0) + 0x2ac) & 2) != 0)) {
        func_0x
                  (_DAT_,*(undefined2 *)(*(longlong *)(lVar22 + 0x6b0) + 0x28),0x7d35c1d,1);
        lVar22 = *param_1;
        if ((uint)uStack_ce0 < (uint)uStack_df0) {
LAB_:
          if (((*(byte *)(*(longlong *)(lVar22 + 0x6b0) + 0x2ac) & 2) != 0) ||
             ((*(byte *)(*(longlong *)(lVar22 + 0x6b0) + 0x38) & 8) == 0)) {
            plVar10 = plVar27;
            if (*(int *)(_DAT_ + 0x4c) != 0) {
              plVar10 = **(longlong ***)(_DAT_ + 0x28);
            }
            iVar6 = func_0x(plVar10[0x242]);
            if (iVar6 != 0) {
              func_0x(*(undefined8 *)(lVar22 + 0x6a0));
              func_0x(*(undefined8 *)(lVar22 + 0x6a8));
              (*_DAT_)(lVar22);
            }
          }
        }
        else if ((uint)uStack_df0 == (uint)uStack_ce0) {
          if ((uStack_ce0._4_4_ < uStack_df0._4_4_) ||
             ((uStack_df0._4_4_ == uStack_ce0._4_4_ && ((ushort)uStack_e08 < uVar25))))
          goto LAB_;
        }
      }
    }
  }
  else if (*(char *)((longlong)param_2 + 0x16) == '\x10') {
    sStack_e88 = -1;
    pbStack_e80 = (byte *)0x0;
    uStack_e84 = 0;
    pbStack_e6a = (byte *)0x0;
    uStack_e60 = 0;
    uStack_e5e = 0;
    uStack_e5c = 0;
    uStack_e5a = 0;
    uStack_e78 = 0;
    uVar20 = 0;
    uVar8 = 0;
    uStack_e3c = 0;
    pbStack_e22 = (byte *)0x0;
    uStack_e18 = 0;
    uStack_e16 = 0;
    uStack_e14 = 0;
    uStack_e12 = 0;
    uStack_e30 = 0;
    uStack_4d8 = 0;
    uStack_4d0 = 1;
    pbStack_e38 = (byte *)func_0x((longlong)param_2 + 0x3e,0,&uStack_dcc);
    plVar10 = plVar27;
    if ((*pbStack_e38 & 1) == 0) {
      sStack_e40 = 0;
      uStack_e1a = 0;
      uStack_e18 = 0;
      uVar8 = 0;
      switch(*pbStack_e38 & 0xe) {
      default:
        plVar10 = (longlong *)(ulonglong)*(ushort *)(pbStack_e38 + 2);
        uVar8 = uVar20;
        if (0x1f9d < *(ushort *)(pbStack_e38 + 2) - 1) {
          func_0x(pbStack_e38,6);
          uVar8 = uStack_e3c;
        }
        break;
      case 4:
        plVar10 = (longlong *)0x9;
        uVar8 = uVar20;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        plVar10 = (longlong *)0x1;
        uVar8 = uVar20;
      }
      uStack_e30 = CONCAT44(uStack_e30._4_4_,(int)plVar10);
    }
    else {
      sStack_e40 = 1;
      bVar19 = *pbStack_e38;
      switch(bVar19 & 0x1c) {
      default:
        if ((char)pbStack_e38[1] < '\0') {
          uStack_e3e = (*(ushort *)(pbStack_e38 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_e38 + 1) >> 8;
          uStack_e28 = 3;
          sVar4 = 3;
        }
        else {
          uStack_e3e = (ushort)pbStack_e38[1];
          sVar4 = 2;
          uStack_e28 = 2;
        }
        uStack_e24 = (short)(uStack_e3e + 1 >> 1) + sVar4;
        if (uStack_e3e < 0x1f) {
          uStack_e10 = 0;
          uVar8 = 0;
        }
        else {
          iVar6 = uStack_e3e - 1;
          uStack_e28 = CONCAT22(((short)(iVar6 / 0x1e) + (short)(iVar6 >> 0x1f)) -
                                (short)((longlong)iVar6 * 0x88888889 >> 0x3f),(undefined2)uStack_e28
                               );
          uStack_e10 = 0;
          plVar10 = (longlong *)0x0;
        }
        break;
      case 4:
        if (((bVar19 & 0x1c) == 4) && ((bVar19 & 2) != 0)) {
          uStack_e28 = 0;
          uStack_e3e = 0;
          uStack_e24 = 0;
          uStack_e1a = 0;
          uVar8 = 0xf;
          uStack_e3c = 0xf;
          uStack_e10 = 1;
          plVar10 = (longlong *)0x0;
        }
        else {
          uStack_e28 = 0;
          uStack_e3e = 0;
          uStack_e24 = 0;
          uStack_e1a = 0;
          uVar8 = 1;
          uStack_e3c = 1;
          uStack_e10 = 0;
          plVar10 = (longlong *)0x0;
        }
        break;
      case 8:
        uStack_e28 = 0;
        uStack_e3e = 0;
        uStack_e24 = 0;
        uStack_e1a = 0;
        uVar8 = 9;
        uStack_e3c = 9;
        uStack_e10 = 0;
        plVar10 = (longlong *)0x0;
      }
    }
    if (sStack_e40 == 0) {
      if (uVar8 == 0) {
        uStack_e3e = 0;
        uVar8 = (uint)plVar10;
        if ((*pbStack_e38 & 0x10) != 0) {
          uVar8 = uVar8 + 2 + (*(ushort *)(pbStack_e38 + (longlong)plVar10) + 7 >> 3);
          plVar10 = (longlong *)(ulonglong)uVar8;
        }
        uStack_e30 = CONCAT44(uVar8,(undefined4)uStack_e30);
        if ((*pbStack_e38 & 0x20) == 0) {
          uStack_e24 = 0;
          uStack_e3c = (uint)plVar10;
          uStack_e28 = (uint)plVar10;
        }
        else {
          puVar29 = (ushort *)((longlong)plVar10 + (longlong)pbStack_e38);
          uStack_e24 = *puVar29;
          if (uStack_e24 == 0) {
            if ((((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
                (lVar22 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar22 != 0)) &&
               ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                (*(char *)(lVar22 + 0x499) != '\0')))) {
              if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
                (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_ec8 = 0;
                (*_DAT_)(1,0xf034d8,0x10231a8,0x80f);
              }
            }
            func_0x(pbStack_e38,3);
          }
          uStack_e28 = uStack_e30._4_4_ + 2 + (uint)uStack_e24 * 2;
          if (0x1f9e < uStack_e28) {
            if (((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
               ((lVar22 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar22 != 0 &&
                ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                 (*(char *)(lVar22 + 0x499) != '\0')))))) {
              if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
                (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_ec8 = 0;
                (*_DAT_)(1,0xf034d8,0x10231a8,0x816);
              }
            }
            func_0x(pbStack_e38,4);
          }
          uStack_e3c = puVar29[uStack_e24] & 0x7fff;
          if (uStack_e3c < uStack_e28) {
            if ((((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
                (lVar22 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar22 != 0)) &&
               ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                (*(char *)(lVar22 + 0x499) != '\0')))) {
              if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
                (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_ec8 = 0;
                (*_DAT_)(1,0xf034d8,0x10231a8,0x81d);
              }
            }
            func_0x(pbStack_e38,4);
          }
          plVar10 = (longlong *)(ulonglong)uStack_e3c;
          uVar20 = uStack_e28;
          do {
            if (-1 < (short)puVar29[(ulonglong)(uStack_e24 - 1) + 1]) break;
            uVar30 = uVar20;
            if (uStack_e24 != 1) {
              uVar30 = *(ushort *)
                        (pbStack_e38 + (ulonglong)uStack_e24 * 2 + ((uStack_e30 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar30 < uVar20) ||
               ((*(ushort *)(pbStack_e38 + (ulonglong)uStack_e24 * 2 + (uStack_e30 >> 0x20)) &
                0x7fff) < uVar30)) {
              func_0x(pbStack_e38,7);
              plVar10 = (longlong *)(ulonglong)uStack_e3c;
              uVar20 = uStack_e28;
            }
            uVar8 = (uint)plVar10;
            if ((uVar30 < uVar20) || (uVar8 < uVar30)) goto code_r0x001020d5;
            if (*(ushort *)(pbStack_e38 + uVar30) == 5) {
              uStack_e3e = uStack_e3e | 2;
              uStack_e24 = uStack_e24 - 1;
              uStack_e16 = (undefined2)uVar30;
              if ((*(ushort *)(pbStack_e38 + (ulonglong)(uVar30 & 0xffff) + 2) & 0x4000) == 0) {
                uStack_e14 = uStack_e14 & 0xc7ff;
              }
              else {
                uStack_e14 = (*(ushort *)(pbStack_e38 + (ulonglong)(uVar30 & 0xffff) + 2) ^
                             uStack_e14) & 0x3800 ^ uStack_e14;
              }
              uStack_e14 = (uStack_e14 ^ *(ushort *)(pbStack_e38 + (ulonglong)(uVar30 & 0xffff) + 2)
                           ) & 0x7ff ^ uStack_e14;
              break;
            }
            if (*(ushort *)(pbStack_e38 + uVar30) < 0x400) break;
            uStack_e3e = uStack_e3e | 1;
            uStack_e24 = uStack_e24 - 1;
          } while (uStack_e24 != 0);
        }
        if ((*pbStack_e38 & 0x40) == 0) {
          uStack_e1a = 0;
          uStack_e18 = 0;
        }
        else {
          uStack_e1a = SUB82(plVar10,0);
          uStack_e18 = (undefined2)((ulonglong)plVar10 >> 0x10);
          uStack_e3c = (int)plVar10 + 0xe;
          puVar13 = (ulonglong *)func_0x(&uStack_e3e);
          uVar16 = *puVar13;
          uVar25 = (ushort)(uVar16 >> 0x30);
          if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
            if ((uVar16 & 0x4000000000000000) == 0) {
              uVar25 = uVar25 & 0xdfff;
            }
            else {
              uVar25 = uVar25 | 0x2000;
            }
          }
          iVar6 = iVar9;
          if (uVar25 == 0xfffc) {
            iVar6 = (int)((uVar16 >> 0x20 & 0xffff) >> 5);
          }
          uStack_e3c = uStack_e3c + iVar6;
          plVar10 = (longlong *)(ulonglong)uStack_e3c;
        }
        uVar8 = (uint)plVar10;
        if ((pbStack_e22 != (byte *)0x0) &&
           (pbStack_e22 < (byte *)((longlong)plVar10 + (longlong)pbStack_e38))) {
          if (((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
             (((lVar22 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar22 != 0 && (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0))
              && (*(char *)(lVar22 + 0x499) != '\0')))) {
            if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
              (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_ec8 = 0;
              (*_DAT_)(1,0xf034d8,0x10231a8,0x877);
            }
          }
          func_0x(pbStack_e38,0x12);
          uVar8 = uStack_e3c;
        }
        if (0x3f3b < uVar8 - 1) {
          if (((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
             ((lVar22 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar22 != 0 &&
              ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
               (*(char *)(lVar22 + 0x499) != '\0')))))) {
            if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
              (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_ec8 = 0;
              (*_DAT_)(1,0xf034d8,0x10231a8,0x87c);
            }
          }
          func_0x(pbStack_e38,5);
          uVar8 = uStack_e3c;
        }
      }
code_r0x001020d5:
      if (uVar8 < 9) {
        bVar19 = *pbStack_e38 & 0xe;
joined_r0x0010211a:
        if ((bVar19 == 0) || (bVar19 == 0xc)) {
          uVar8 = 9;
        }
      }
    }
    else {
      if (uVar8 == 0) {
        func_0x(&uStack_e3e);
        uVar8 = uStack_e3c;
      }
      if (uVar8 < 9) {
        bVar19 = *pbStack_e38 & 0x1c;
        goto joined_r0x0010211a;
      }
    }
    uVar20 = 9;
    if (uVar8 != uStack_dcc) {
      uStack_ec8 = 0;
      (*_DAT_)(1,0x10d1f20,0x1089cc0,0x33e7);
    }
    pbStack_e80 = (byte *)func_0x((longlong)param_2 + 0x3e,1,&uStack_dcc);
    plVar10 = plVar27;
    if ((*pbStack_e80 & 1) == 0) {
      sStack_e88 = 0;
      uStack_e62 = 0;
      uStack_e60 = 0;
      switch(*pbStack_e80 & 0xe) {
      default:
        plVar10 = (longlong *)(ulonglong)*(ushort *)(pbStack_e80 + 2);
        if (0x1f9d < *(ushort *)(pbStack_e80 + 2) - 1) {
          func_0x(pbStack_e80,6);
        }
        break;
      case 4:
        plVar10 = (longlong *)0x9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        plVar10 = (longlong *)0x1;
      }
      uStack_e78 = CONCAT44(uStack_e78._4_4_,(int)plVar10);
    }
    else {
      sStack_e88 = 1;
      bVar19 = *pbStack_e80;
      switch(bVar19 & 0x1c) {
      default:
        if ((char)pbStack_e80[1] < '\0') {
          uStack_e86 = (*(ushort *)(pbStack_e80 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_e80 + 1) >> 8;
          uVar25 = 3;
          sVar4 = 3;
        }
        else {
          uStack_e86 = (ushort)pbStack_e80[1];
          uVar25 = 2;
          sVar4 = 2;
        }
        uStack_e6c = (short)(uStack_e86 + 1 >> 1) + sVar4;
        if (uStack_e86 < 0x1f) {
          uStack_e70 = (uint)uVar25;
          uStack_e58 = 0;
        }
        else {
          iVar6 = uStack_e86 - 1;
          uStack_e70 = CONCAT22(((short)(iVar6 / 0x1e) + (short)(iVar6 >> 0x1f)) -
                                (short)((longlong)iVar6 * 0x88888889 >> 0x3f),uVar25);
          uStack_e58 = 0;
          plVar10 = (longlong *)0x0;
        }
        break;
      case 4:
        if (((bVar19 & 0x1c) == 4) && ((bVar19 & 2) != 0)) {
          uStack_e70 = 0;
          uStack_e86 = 0;
          uStack_e6c = 0;
          uStack_e62 = 0;
          uStack_e84 = 0xf;
          uStack_e58 = 1;
          plVar10 = (longlong *)0x0;
        }
        else {
          uStack_e70 = 0;
          uStack_e86 = 0;
          uStack_e6c = 0;
          uStack_e62 = 0;
          uStack_e84 = 1;
          uStack_e58 = 0;
          plVar10 = (longlong *)0x0;
        }
        break;
      case 8:
        uStack_e70 = 0;
        uStack_e86 = 0;
        uStack_e6c = 0;
        uStack_e62 = 0;
        uStack_e84 = 9;
        uStack_e58 = 0;
        plVar10 = (longlong *)0x0;
      }
    }
    uVar8 = (uint)plVar10;
    if (sStack_e88 == 0) {
      if (uStack_e84 == 0) {
        uStack_e86 = 0;
        if ((*pbStack_e80 & 0x10) != 0) {
          uVar8 = uVar8 + 2 + (*(ushort *)(pbStack_e80 + (longlong)plVar10) + 7 >> 3);
        }
        uStack_e78 = CONCAT44(uVar8,(undefined4)uStack_e78);
        if ((*pbStack_e80 & 0x20) == 0) {
          uStack_e6c = 0;
          uStack_e84 = uVar8;
          uStack_e70 = uVar8;
        }
        else {
          puVar29 = (ushort *)(pbStack_e80 + uVar8);
          uStack_e6c = *puVar29;
          if (uStack_e6c == 0) {
            if ((((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
                (lVar22 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar22 != 0)) &&
               ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                (*(char *)(lVar22 + 0x499) != '\0')))) {
              if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
                (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_ec8 = 0;
                (*_DAT_)(1,0xf034d8,0x10231a8,0x80f);
              }
            }
            func_0x(pbStack_e80,3);
          }
          uStack_e70 = uStack_e78._4_4_ + 2 + (uint)uStack_e6c * 2;
          if (0x1f9e < uStack_e70) {
            if (((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
               ((lVar22 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar22 != 0 &&
                ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                 (*(char *)(lVar22 + 0x499) != '\0')))))) {
              if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
                (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_ec8 = 0;
                (*_DAT_)(1,0xf034d8,0x10231a8,0x816);
              }
            }
            func_0x(pbStack_e80,4);
          }
          uStack_e84 = puVar29[uStack_e6c] & 0x7fff;
          uVar8 = uStack_e70;
          if (uStack_e84 < uStack_e70) {
            if ((((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
                (lVar22 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar22 != 0)) &&
               ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                (*(char *)(lVar22 + 0x499) != '\0')))) {
              if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
                (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_ec8 = 0;
                (*_DAT_)(1,0xf034d8,0x10231a8,0x81d);
              }
            }
            func_0x(pbStack_e80,4);
            uVar8 = uStack_e70;
          }
          do {
            if (-1 < (short)puVar29[(ulonglong)(uStack_e6c - 1) + 1]) break;
            uVar30 = uVar8;
            if (uStack_e6c != 1) {
              uVar30 = *(ushort *)
                        (pbStack_e80 + (ulonglong)uStack_e6c * 2 + ((uStack_e78 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar30 < uVar8) ||
               ((*(ushort *)(pbStack_e80 + (ulonglong)uStack_e6c * 2 + (uStack_e78 >> 0x20)) &
                0x7fff) < uVar30)) {
              func_0x(pbStack_e80,7);
              uVar8 = uStack_e70;
            }
            if ((uVar30 < uVar8) || (uStack_e84 < uVar30)) goto code_r0x001029a6;
            if (*(ushort *)(pbStack_e80 + uVar30) == 5) {
              uStack_e86 = uStack_e86 | 2;
              uStack_e6c = uStack_e6c - 1;
              uStack_e5e = (undefined2)uVar30;
              if ((*(ushort *)(pbStack_e80 + (ulonglong)(uVar30 & 0xffff) + 2) & 0x4000) == 0) {
                uStack_e5c = uStack_e5c & 0xc7ff;
              }
              else {
                uStack_e5c = (*(ushort *)(pbStack_e80 + (ulonglong)(uVar30 & 0xffff) + 2) ^
                             uStack_e5c) & 0x3800 ^ uStack_e5c;
              }
              uStack_e5c = (uStack_e5c ^ *(ushort *)(pbStack_e80 + (ulonglong)(uVar30 & 0xffff) + 2)
                           ) & 0x7ff ^ uStack_e5c;
              break;
            }
            if (*(ushort *)(pbStack_e80 + uVar30) < 0x400) break;
            uStack_e86 = uStack_e86 | 1;
            uStack_e6c = uStack_e6c - 1;
          } while (uStack_e6c != 0);
        }
        if ((*pbStack_e80 & 0x40) == 0) {
          uStack_e62 = 0;
          uStack_e60 = 0;
        }
        else {
          uStack_e62 = (undefined2)uStack_e84;
          uStack_e60 = (undefined2)(uStack_e84 >> 0x10);
          uStack_e84 = uStack_e84 + 0xe;
          puVar13 = (ulonglong *)func_0x(&uStack_e86);
          uVar16 = *puVar13;
          uVar25 = (ushort)(uVar16 >> 0x30);
          if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
            if ((uVar16 & 0x4000000000000000) == 0) {
              uVar25 = uVar25 & 0xdfff;
            }
            else {
              uVar25 = uVar25 | 0x2000;
            }
          }
          iVar6 = iVar9;
          if (uVar25 == 0xfffc) {
            iVar6 = (int)((uVar16 >> 0x20 & 0xffff) >> 5);
          }
          uStack_e84 = uStack_e84 + iVar6;
        }
        if ((pbStack_e6a != (byte *)0x0) && (pbStack_e6a < pbStack_e80 + uStack_e84)) {
          if (((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
             (((lVar22 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar22 != 0 && (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0))
              && (*(char *)(lVar22 + 0x499) != '\0')))) {
            if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
              (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_ec8 = 0;
              (*_DAT_)(1,0xf034d8,0x10231a8,0x877);
            }
          }
          func_0x(pbStack_e80,0x12);
        }
        if (0x3f3b < uStack_e84 - 1) {
          if (((cRam0000000001612aab != '\0') || ((bRam00000000016233b0 & 1) != 0)) &&
             ((lVar22 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar22 != 0 &&
              ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
               (*(char *)(lVar22 + 0x499) != '\0')))))) {
            if ((cRam000000000161299b == '\0') && ((bRam00000000016233b0 & 2) == 0)) {
              (*pcRam0000000000b812d8)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_ec8 = 0;
              (*_DAT_)(1,0xf034d8,0x10231a8,0x87c);
            }
          }
          func_0x(pbStack_e80,5);
        }
      }
code_r0x001029a6:
      if ((8 < uStack_e84) || (((*pbStack_e80 & 0xe) != 0 && ((*pbStack_e80 & 0xe) != 0xc)))) {
        uVar20 = uStack_e84;
      }
    }
    else {
      if (uStack_e84 == 0) {
        func_0x(&uStack_e86);
      }
      if ((uStack_e84 < 9) && (((*pbStack_e80 & 0x1c) == 0 || ((*pbStack_e80 & 0x1c) == 0xc)))) {
        uStack_e08 = 9;
        uVar20 = uStack_e08;
      }
      else {
        uStack_e08 = uStack_e84;
        uVar20 = uStack_e84;
      }
    }
    if (uVar20 != uStack_dcc) {
      uStack_ec8 = 0;
      (*_DAT_)(1,0x10d1ef8,0x1089cc0,0x33ec);
    }
    puVar12 = (undefined8 *)func_0x((longlong)param_2 + 0x3e,3,auStack_d30);
    if (*(ushort *)((longlong)param_2 + 0x3e) < 3) {
      puVar14 = &uStack_4d8;
    }
    else {
      puVar14 = (undefined8 *)func_0x((longlong)param_2 + 0x3e,2,auStack_bf0);
    }
    iVar6 = 1;
    if ((*(int *)(param_1 + 4) != 3) && ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) == 0)) {
      iVar6 = iVar9;
    }
    iVar5 = func_0x(&sStack_e40);
    puVar18 = puStack_e00;
    if (iVar5 == 2) {
      uStack_bc8 = 0;
      pppppuStack_bd0 = &pppppuStack_bd8;
      pppppuStack_bd8 = &pppppuStack_bd8;
      uStack_d18 = 0;
      uStack_d10 = 0;
      uVar17 = func_0x
                         (*(undefined8 *)(*param_1 + 0x6a0),*(undefined2 *)(puStack_e00 + 7),
                          &uStack_d18,4);
      func_0x(uVar17,1);
      lStack_be0._0_4_ = 7;
      uStack_eb8 = &lStack_be0;
      uStack_ec8 = CONCAT44(uStack_ec8._4_4_,auStack_d30[0] >> 5);
      uStack_ec0 = puVar12;
      (**(code **)(**(longlong **)(*param_1 + 0x6c8) + 0x200))
                (*(longlong **)(*param_1 + 0x6c8),*(undefined2 *)(puVar18 + 7),&sStack_e40,
                 &sStack_e88);
      (**(code **)(**(longlong **)(*param_1 + 0x6c8) + 0x208))
                (*(longlong **)(*param_1 + 0x6c8),&lStack_be0);
      if ((int)uStack_d10 != 0) {
        func_0x(uStack_d18,uStack_d10._4_4_);
        uStack_d10 = uStack_d10 & 0xffffffff00000000;
      }
    }
    else {
      uStack_eb8 = (longlong *)((longlong)param_1 + 0x5674);
      uStack_eb0 = CONCAT44(uStack_eb0._4_4_,1);
      uStack_ec8 = CONCAT44(uStack_ec8._4_4_,iVar6);
      uStack_ec0 = puVar14;
      func_0x
                (*(undefined8 *)(*param_1 + 0x6a0),*(undefined2 *)(puStack_e00 + 7),&sStack_e40,
                 &sStack_e88);
    }
  }
  uVar17 = _DAT_;
  if (((((*(byte *)(uStack_e90 + 0x16) & 2) != 0) &&
       (*(short *)((longlong)param_1 + 0x567c) == *(short *)(uStack_e90 + 0x20))) &&
      (*(int *)((longlong)param_1 + 0x5674) == *(int *)(uStack_e90 + 0x18))) &&
     (*(int *)(param_1 + 0xacf) == *(int *)(uStack_e90 + 0x1c))) {
    uStack_da0 = (undefined4 *)
                 CONCAT26(uStack_da0._6_2_,*(undefined6 *)(*(longlong *)(uStack_e90 + 0x50) + 0x10))
    ;
    lStack_cd0 = 0;
    uStack_cc8 = 0;
    uStack_cc4 = 0;
    iVar6 = func_0x
                      (_DAT_,&uStack_da0,*(undefined4 *)(*param_1 + 0x6b8),&lStack_cd0);
    if (((iVar6 != 0) && ((*(uint *)(lStack_cd0 + 100) >> 0xb & 1) == 0)) &&
       (((*(uint *)(lStack_cd0 + 100) & 2) != 0 &&
        (plVar27 = (longlong *)0x0, (*(uint *)(lStack_cd0 + 100) & 4) == 0)))) {
      uVar8 = func_0x(uVar17,lStack_cd0,3,0);
      plVar27 = (longlong *)(ulonglong)uVar8;
    }
    func_0x(&lStack_cd0);
    LOCK();
    plStack_dd8[0xb5f] = plStack_dd8[0xb5f] + 1;
    UNLOCK();
    LOCK();
    plStack_dd8[0xb60] = plStack_dd8[0xb60] + (longlong)plVar27;
    UNLOCK();
  }
LAB_:
  func_0x(param_1,(longlong)param_1 + 0x5674);
  func_0x(param_1 + 0xad2,(longlong)param_1 + 0x5674);
  func_0x(param_2,param_1 + 0xadd);
  if (((*(char *)(*param_1 + 0x2050) != '\0') &&
      (plVar27 = *(longlong **)(*param_1 + 0x65f0), *plVar27 != 0)) &&
     (*(char *)(plVar27 + 0x370) == '\0')) {
    if (*(uint *)(plVar27 + 0xa8) < 0x10001) {
      lVar22 = *(longlong *)plVar27[0xb];
      uVar17 = func_0x(param_1,auStack_498,0);
      (**(code **)(lVar22 + 0x18))(plVar27[0xb],uVar17);
    }
    else if (*(char *)((longlong)param_1 + 0x56c4) != '\0') {
      puVar18 = (undefined4 *)func_0x(param_1,auStack_498,0);
      if ((*plVar27 != 0) && (0x1ffff < *(uint *)(plVar27 + 0xa8))) {
        (*_DAT_)(*plVar27,CONCAT44(*puVar18,puVar18[1]));
      }
    }
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_ee8);
  return;
}

