
void FUN_(undefined8 param_1,int param_2,undefined4 param_3)

{
  code *UNRECOVERED_JUMPTABLE;
  
  if ((1 < param_2 - 1U) && (param_2 != 7)) {
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)param_2 + 0x1002a8) * 4 + 0x10022c) -
                 0x544840);
                    /* WARNING: Could not recover jumptable at 0x0010003d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(param_1,UNRECOVERED_JUMPTABLE,0);
    return;
  }
  func_0x(param_1,param_3,0,1,1,0xfffffffe,0,0,0);
  return;
}

