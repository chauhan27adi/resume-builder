
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ushort *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  byte bVar2;
  undefined8 uVar3;
  ushort *puVar4;
  uint **ppuVar5;
  char cVar6;
  int iVar7;
  longlong lVar8;
  ulonglong uVar9;
  ushort uVar10;
  uint uVar11;
  byte **ppbVar12;
  longlong lVar13;
  uint uVar14;
  byte **ppbVar15;
  uint *puVar16;
  ushort *puVar17;
  byte *pbVar18;
  short sVar19;
  uint uVar20;
  longlong unaff_GS_OFFSET;
  undefined auStack_d28 [32];
  undefined8 uStack_d08;
  uint *puStack_d00;
  int iStack_cf8;
  byte **ppbStack_cf0;
  undefined uStack_ce8;
  uint uStack_ce4;
  uint uStack_ce0;
  ushort *puStack_cd8;
  char cStack_cd0;
  char cStack_ccf;
  char cStack_cce;
  undefined uStack_ccd;
  char cStack_ccc;
  ushort uStack_cca;
  int iStack_cc8;
  int iStack_cc0;
  int iStack_cb8;
  int iStack_cb0;
  int iStack_ca0;
  short sStack_c9c;
  undefined8 uStack_c98;
  undefined2 uStack_c90;
  byte bStack_c88;
  byte bStack_c87;
  byte bStack_c86;
  byte bStack_c85;
  byte bStack_c84;
  byte bStack_c83;
  byte bStack_c82;
  byte bStack_c81;
  byte bStack_c80;
  byte bStack_c7f;
  byte bStack_c7e;
  ushort uStack_c78;
  ushort uStack_c70;
  ushort uStack_c68;
  byte bStack_c60;
  ushort uStack_c58;
  ushort uStack_c50;
  ushort uStack_c48;
  ushort uStack_c40;
  ushort uStack_c38;
  undefined8 uStack_c30;
  short sStack_c28;
  char cStack_c20;
  byte bStack_c1f;
  byte bStack_c1e;
  byte bStack_c1d;
  byte bStack_c1c;
  byte bStack_c1b;
  byte bStack_c1a;
  byte bStack_c19;
  byte bStack_c18;
  uint uStack_c10;
  uint uStack_c08;
  int iStack_c00;
  undefined8 uStack_bfc;
  undefined4 uStack_bf4;
  uint uStack_bf0;
  undefined8 uStack_bec;
  undefined4 uStack_be4;
  byte **ppbStack_be0;
  uint uStack_bd8;
  uint uStack_bd4;
  undefined8 uStack_bd0;
  ushort uStack_bc8;
  undefined8 uStack_bc0;
  ushort uStack_bb8;
  undefined4 uStack_bb0;
  undefined2 uStack_bac;
  undefined4 uStack_ba8;
  undefined2 uStack_ba4;
  undefined4 uStack_ba0;
  undefined2 uStack_b9c;
  undefined4 uStack_b98;
  undefined2 uStack_b94;
  byte **ppbStack_b90;
  undefined2 uStack_b88;
  undefined2 uStack_b80;
  short sStack_b78;
  ushort uStack_b70;
  ushort uStack_b68;
  short sStack_b64;
  ushort uStack_b60;
  ushort uStack_b5c;
  ushort uStack_b58;
  ushort uStack_b54;
  ushort uStack_b50;
  ushort uStack_b4c;
  ushort uStack_b48;
  int iStack_b30;
  uint uStack_b28;
  uint uStack_b20;
  uint uStack_b18;
  uint uStack_b10;
  uint uStack_b08;
  uint uStack_b00;
  undefined4 uStack_af8;
  byte **ppbStack_af0;
  uint uStack_ae8;
  uint uStack_ae0;
  uint uStack_ad8;
  undefined4 uStack_ad0;
  short sStack_acc;
  undefined4 uStack_ac8;
  undefined auStack_ac4 [4];
  uint uStack_ac0;
  byte **ppbStack_ab8;
  byte **ppbStack_ab0;
  byte **ppbStack_aa8;
  byte *pbStack_aa0;
  undefined8 uStack_a98;
  uint uStack_a90;
  byte **ppbStack_a88;
  uint uStack_a78;
  uint uStack_a70;
  uint uStack_a68;
  uint uStack_a60;
  undefined8 uStack_a58;
  undefined2 uStack_a50;
  uint *puStack_a48;
  undefined8 *puStack_a40;
  ushort *puStack_a38;
  ushort *puStack_a30;
  undefined4 uStack_a28;
  undefined2 uStack_a24;
  undefined4 uStack_a22;
  undefined2 uStack_a1e;
  undefined8 uStack_a18;
  ushort uStack_a10;
  undefined8 uStack_a08;
  undefined2 uStack_a00;
  undefined4 uStack_9f8;
  undefined auStack_9f4 [4];
  int iStack_9f0;
  int iStack_9e8;
  uint uStack_9e0;
  int iStack_9d8;
  uint uStack_9d0;
  uint uStack_9cc;
  int iStack_9c8;
  uint uStack_9c4;
  uint uStack_9c0;
  uint uStack_9bc;
  undefined auStack_9b8 [36];
  undefined4 uStack_994;
  longlong lStack_990;
  undefined8 *puStack_988;
  undefined4 uStack_980;
  uint *puStack_978;
  undefined4 uStack_970;
  undefined4 uStack_96c;
  longlong lStack_968;
  longlong lStack_960;
  longlong lStack_958;
  longlong lStack_950;
  ulonglong uStack_948;
  longlong lStack_940;
  longlong lStack_938;
  undefined auStack_930 [8];
  uint *puStack_928;
  uint uStack_920;
  undefined4 uStack_91c;
  undefined auStack_918 [8];
  uint uStack_910;
  undefined8 *puStack_908;
  int iStack_900;
  int iStack_8fc;
  uint uStack_8f8;
  undefined8 uStack_8f4;
  undefined2 uStack_8ec;
  undefined2 uStack_8ea;
  ushort *puStack_8e8;
  uint *puStack_8d0;
  uint *puStack_8c8;
  ushort *puStack_8c0;
  ushort *puStack_8b8;
  uint *puStack_8b0;
  byte *pbStack_8a8;
  uint *puStack_8a0;
  uint *puStack_898;
  byte *pbStack_890;
  byte **ppbStack_888;
  byte **ppbStack_880;
  longlong lStack_878;
  byte *pbStack_870;
  undefined4 *puStack_868;
  undefined4 *puStack_860;
  undefined8 *puStack_858;
  uint *puStack_850;
  longlong lStack_848;
  longlong lStack_840;
  longlong lStack_838;
  longlong lStack_830;
  uint *puStack_828;
  byte *pbStack_820;
  undefined4 *puStack_818;
  undefined4 *puStack_810;
  longlong lStack_808;
  undefined2 *puStack_800;
  uint **ppuStack_7f8;
  longlong *plStack_7f0;
  longlong *plStack_7e8;
  short **ppsStack_7e0;
  short **ppsStack_7d8;
  undefined8 *puStack_7d0;
  byte *pbStack_7c8;
  longlong *plStack_7c0;
  longlong *plStack_7b8;
  short *psStack_7b0;
  short **ppsStack_7a8;
  short *psStack_7a0;
  short **ppsStack_798;
  uint *puStack_790;
  uint **ppuStack_788;
  longlong lStack_780;
  longlong lStack_778;
  longlong lStack_770;
  longlong lStack_768;
  undefined8 *puStack_760;
  byte *pbStack_758;
  undefined4 *puStack_750;
  undefined4 *puStack_748;
  undefined8 *puStack_740;
  ushort *puStack_738;
  ushort *puStack_730;
  uint *puStack_728;
  byte *pbStack_720;
  uint *puStack_718;
  uint *puStack_710;
  undefined8 *puStack_708;
  undefined8 uStack_700;
  byte *pbStack_6f8;
  undefined *puStack_6f0;
  undefined *puStack_6e8;
  undefined *puStack_6e0;
  undefined *puStack_6d8;
  undefined *puStack_6d0;
  undefined *puStack_6c8;
  undefined4 *puStack_6c0;
  undefined4 *puStack_6b8;
  undefined8 *puStack_6b0;
  undefined4 *puStack_6a8;
  byte *pbStack_6a0;
  byte **ppbStack_698;
  byte **ppbStack_690;
  longlong lStack_688;
  byte **ppbStack_680;
  undefined4 *puStack_678;
  byte **ppbStack_670;
  byte **ppbStack_668;
  byte *pbStack_660;
  byte **ppbStack_658;
  ushort *puStack_650;
  byte *pbStack_648;
  ushort *puStack_640;
  ushort *puStack_638;
  byte *pbStack_630;
  byte *pbStack_628;
  byte *pbStack_620;
  short *psStack_618;
  short **ppsStack_610;
  byte *pbStack_608;
  ushort *puStack_600;
  byte *pbStack_5f8;
  ushort *puStack_5f0;
  ushort *puStack_5e8;
  byte *pbStack_5e0;
  byte *pbStack_5d8;
  byte *pbStack_5d0;
  longlong lStack_5c8;
  longlong lStack_5c0;
  longlong lStack_5b8;
  longlong lStack_5b0;
  longlong lStack_5a8;
  longlong lStack_5a0;
  longlong lStack_598;
  longlong lStack_590;
  longlong lStack_588;
  ushort *puStack_580;
  byte *pbStack_578;
  ushort *puStack_570;
  longlong lStack_568;
  ulonglong *puStack_560;
  ulonglong *puStack_558;
  longlong lStack_550;
  longlong lStack_548;
  longlong lStack_540;
  longlong lStack_538;
  longlong lStack_530;
  longlong lStack_528;
  byte *pbStack_520;
  ushort *puStack_518;
  ushort *puStack_510;
  longlong lStack_508;
  byte **ppbStack_500;
  byte **ppbStack_4f8;
  byte **ppbStack_4f0;
  ushort *puStack_4e8;
  ushort *puStack_4e0;
  uint *puStack_4d8;
  byte *pbStack_4d0;
  uint *puStack_4c8;
  uint *puStack_4c0;
  longlong lStack_488;
  longlong lStack_480;
  longlong *plStack_478;
  longlong lStack_470;
  longlong lStack_468;
  longlong lStack_460;
  longlong lStack_458;
  longlong lStack_450;
  ushort *puStack_448;
  ushort *puStack_440;
  uint *puStack_438;
  byte *pbStack_430;
  uint uStack_428;
  undefined4 uStack_424;
  undefined4 uStack_420;
  undefined auStack_408 [8];
  undefined2 uStack_400;
  undefined2 uStack_3fe;
  undefined4 uStack_3f8;
  uint **ppuStack_3f0;
  undefined *puStack_3e8;
  undefined8 uStack_3e0;
  uint *puStack_3d8;
  undefined4 uStack_3d0;
  undefined2 uStack_3cc;
  undefined2 uStack_3ca;
  longlong lStack_3c8;
  undefined4 uStack_3c0;
  undefined2 uStack_3bc;
  undefined2 uStack_3ba;
  longlong lStack_3b8;
  undefined4 uStack_3b0;
  undefined2 uStack_3ac;
  undefined2 uStack_3aa;
  short *psStack_3a8;
  int iStack_3a0;
  undefined2 uStack_39c;
  undefined2 uStack_39a;
  short *psStack_398;
  int iStack_390;
  undefined2 uStack_38c;
  undefined2 uStack_38a;
  undefined8 uStack_388;
  undefined4 uStack_380;
  undefined2 uStack_37c;
  undefined2 uStack_37a;
  undefined auStack_378 [448];
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined8 uStack_1b0;
  uint uStack_1a8;
  short sStack_1a4;
  int iStack_1a2;
  undefined uStack_19e;
  byte bStack_19d;
  ushort uStack_150;
  ushort uStack_14e;
  uint uStack_14c;
  byte *pbStack_148;
  undefined8 uStack_140;
  uint uStack_138;
  ushort uStack_134;
  byte *pbStack_132;
  undefined2 uStack_12a;
  undefined2 uStack_128;
  undefined6 uStack_126;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined auStack_118 [16];
  undefined auStack_108 [8];
  undefined8 uStack_100;
  undefined8 uStack_f8;
  undefined6 uStack_f0;
  undefined2 uStack_ea;
  undefined6 uStack_e8;
  undefined2 uStack_e2;
  undefined8 uStack_e0;
  undefined auStack_d8 [16];
  undefined auStack_c8 [16];
  undefined auStack_b8 [16];
  undefined8 uStack_a8;
  short asStack_a0 [24];
  short asStack_70 [24];
  ulonglong uStack_40;
  
  uStack_700 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_d28;
  uStack_150 = 0xffff;
  ppbVar12 = (byte **)0x0;
  pbStack_148 = (byte *)0x0;
  uVar20 = 0;
  uStack_14c = 0;
  pbStack_132 = (byte *)0x0;
  uStack_128 = 0;
  uStack_126 = 0;
  uStack_140 = (byte **)0x0;
  uStack_11c = 0xffffffff;
  ppbStack_be0 = (byte **)0x0;
  ppbStack_cf0 = (byte **)0x0;
  uStack_ce8 = 0;
  uStack_ce4 = 0;
  sStack_c9c = *(short *)(param_1 + 0x20);
  iStack_ca0 = 0;
  uStack_a98 = param_3;
  puStack_8e8 = param_2;
  lVar8 = func_0x
                    (_DAT_,*(uint *)(param_1 + 0x60) & 0xffff,
                     *(uint *)(param_1 + 0x60) >> 0x10);
  uStack_b88 = *(undefined2 *)(param_1 + 0x20);
  lStack_488 = func_0x(*(undefined8 *)(lVar8 + 0x6a0),uStack_b88,1);
  if (lStack_488 == param_1) {
    iStack_c00 = 0;
    uStack_424 = 0;
    uStack_420 = 0;
    cStack_c20 = *_DAT_;
    ppbStack_b90 = ppbVar12;
    if ((cStack_c20 != '\0') && (bStack_c1f = DAT_ >> 7, -1 < (char)DAT_)) {
      iStack_b30 = 0;
      lStack_480 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      plStack_478 = (longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)(lStack_480 + (ulonglong)*_DAT_ * 8));
      lStack_470 = *plStack_478;
      if ((lStack_470 == 0) ||
         (lStack_968 = **(longlong **)(lStack_470 + 0x38), lStack_468 = lStack_968, lStack_968 == 0)
         ) {
        lStack_968 = 0;
      }
      else {
        iStack_b30 = (*_DAT_)(lStack_968,0x337);
        if (iStack_b30 != 0) goto LAB_;
      }
      lStack_460 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      lStack_458 = (ulonglong)*_DAT_ +
                   *(longlong *)(lStack_460 + (ulonglong)*_DAT_ * 8);
      lStack_450 = *(longlong *)(lStack_458 + 8);
      if (lStack_450 != 0) {
        ppbStack_b90 = *(byte ***)(lStack_450 + 0x60);
      }
    }
LAB_:
    lStack_990 = *(longlong *)(lVar8 + 0x728);
    puStack_a48 = &uStack_428;
LAB_:
    uStack_bd8 = 0;
    if (ppbStack_cf0 != (byte **)0x0) {
      puStack_448 = (ushort *)((longlong)ppbStack_cf0 + 0x62);
      uStack_c78 = *puStack_448;
      if (((uStack_c78 & 0x400) == 0) || ((short)uStack_ce4 < 3)) {
        iStack_cc0 = (int)(short)uStack_ce4;
        ppbStack_ab8 = ppbStack_cf0;
        uStack_c70 = *puStack_448;
        puStack_440 = puStack_448;
        if (((byte)uStack_c70 >> 3 & 1) != 0) {
          if (iStack_cc0 == 3) {
            iStack_cc0 = 4;
          }
          else if (iStack_cc0 < 2) goto LAB_;
          puStack_438 = (uint *)((longlong)ppbStack_cf0 + 100);
          uStack_b28 = *puStack_438;
          if ((((uStack_b28 & 8) != 0) && (pbVar18 = ppbStack_cf0[0x12], pbVar18 != (byte *)0x0)) &&
             (pbStack_430 = pbVar18, *(longlong *)(pbVar18 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(pbVar18 + 0x758),ppbStack_cf0,iStack_cc0);
          }
        }
LAB_:
        bStack_c60 = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar16 = (uint *)((longlong)ppbStack_ab8 + 100);
          uStack_b00 = *puVar16;
          puStack_8d0 = puVar16;
          if ((((uStack_b00 & 8) != 0) && (2 < iStack_cc0)) &&
             ((uStack_b08 = *puVar16, puStack_8c8 = puVar16, (uStack_b08 & 0xc0000000) != 0x40000000
              && (*ppbStack_ab8 != (byte *)0x0)))) {
            uStack_980 = 2;
            iVar7 = (*_DAT_)(*ppbStack_ab8,0x2000,2,auStack_930);
            if (iVar7 != 0) {
              LOCK();
              *puVar16 = *puVar16 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar16 = *puVar16 | 0x40000000;
              UNLOCK();
            }
          }
        }
        ppbVar15 = ppbStack_ab8;
        iVar7 = iStack_cc0;
        func_0x(ppbStack_ab8 + 0x13,iStack_cc0);
        if ((_DAT_ != 0) && (bStack_c1e = DAT_ >> 1, (bStack_c1e & 1) != 0)) {
          func_0x(ppbVar15,0,iVar7);
        }
        uStack_ce4 = uStack_ce4 & 0xffff0000;
        ppbStack_cf0 = (byte **)0x0;
      }
      else {
        func_0x(&ppbStack_cf0);
      }
    }
    if ((*(longlong *)(lVar8 + 0x728) != 0) &&
       (func_0x(&ppbStack_cf0,&iStack_ca0,lVar8), ppbStack_cf0 != (byte **)0x0)) {
      puStack_8c0 = (ushort *)((longlong)ppbStack_cf0 + 0x62);
      uStack_c68 = *puStack_8c0;
      if (((uStack_c68 & 0x400) == 0) || ((short)uStack_ce4 < 3)) {
        iStack_cb8 = (int)(short)uStack_ce4;
        ppbStack_af0 = ppbStack_cf0;
        uStack_c38 = *puStack_8c0;
        puStack_8b8 = puStack_8c0;
        if (((byte)uStack_c38 >> 3 & 1) != 0) {
          if (iStack_cb8 == 3) {
            iStack_cb8 = 4;
          }
          else if (iStack_cb8 < 2) goto LAB_;
          puStack_8b0 = (uint *)((longlong)ppbStack_cf0 + 100);
          uStack_b10 = *puStack_8b0;
          if ((((uStack_b10 & 8) != 0) && (pbVar18 = ppbStack_cf0[0x12], pbVar18 != (byte *)0x0)) &&
             (pbStack_8a8 = pbVar18, *(longlong *)(pbVar18 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(pbVar18 + 0x758),ppbStack_cf0,iStack_cb8);
          }
        }
LAB_:
        bStack_c1d = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar16 = (uint *)((longlong)ppbStack_af0 + 100);
          uStack_a60 = *puVar16;
          puStack_8a0 = puVar16;
          if ((((uStack_a60 & 8) != 0) && (2 < iStack_cb8)) &&
             ((uStack_a68 = *puVar16, puStack_898 = puVar16, (uStack_a68 & 0xc0000000) != 0x40000000
              && (*ppbStack_af0 != (byte *)0x0)))) {
            uStack_91c = 2;
            iVar7 = (*_DAT_)(*ppbStack_af0,0x2000,2,auStack_918);
            if (iVar7 != 0) {
              LOCK();
              *puVar16 = *puVar16 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar16 = *puVar16 | 0x40000000;
              UNLOCK();
            }
          }
        }
        ppbVar15 = ppbStack_af0;
        iVar7 = iStack_cb8;
        func_0x(ppbStack_af0 + 0x13,iStack_cb8);
        if ((_DAT_ != 0) && (bStack_c1c = DAT_ >> 1, (bStack_c1c & 1) != 0)) {
          func_0x(ppbVar15,0,iVar7);
        }
        uStack_ce4 = uStack_ce4 & 0xffff0000;
        ppbStack_cf0 = (byte **)0x0;
      }
      else {
        func_0x(&ppbStack_cf0);
      }
    }
    puStack_d00 = puStack_a48;
    uStack_d08 = CONCAT44(uStack_d08._4_4_,2);
    ppbStack_cf0 = (byte **)func_0x(_DAT_,lVar8,&iStack_ca0,&uStack_bd8);
    if (ppbStack_b90 != (byte **)0x0) {
      pbStack_890 = *ppbStack_cf0;
      ppbStack_888 = ppbStack_b90 + 0xa0;
      ppbStack_880 = ppbStack_888 + (ulonglong)(*(uint *)ppbStack_888 & 0xf) + 1;
      if (*ppbStack_880 != pbStack_890) {
        *ppbStack_880 = pbStack_890;
        *ppbStack_888 = *ppbStack_888 + 1;
      }
    }
    uVar11 = uStack_bd8 >> 3 & 1;
    uStack_ce4 = uVar11 << 0x18 | uStack_ce4 & 0xff0002 | 2;
    uStack_ce0 = uStack_bd8 >> 4 & 1 | uStack_ce0 & 0xffffff00;
    if (((lStack_990 != 0) && (ppbStack_b90 != (byte **)0x0)) &&
       (ppbStack_b90 == *(byte ***)(lVar8 + 0x1c38))) {
      lStack_878 = lStack_990 + 0x59b8;
      *(longlong *)(lStack_990 + 0x5b28) = *(longlong *)(lStack_990 + 0x5b28) + 1;
      uStack_910 = uVar11;
      if (puStack_a48[1] != 0) {
        *(longlong *)(lStack_990 + 0x5b30) = *(longlong *)(lStack_990 + 0x5b30) + 1;
        *(longlong *)(lStack_990 + 0x5b38) =
             *(longlong *)(lStack_990 + 0x5b38) + (ulonglong)*puStack_a48;
        if (uVar11 != 0) {
          *(longlong *)(lStack_990 + 0x5b40) = *(longlong *)(lStack_990 + 0x5b40) + 1;
          *(longlong *)(lStack_990 + 0x5b48) =
               *(longlong *)(lStack_990 + 0x5b48) + (ulonglong)*puStack_a48;
        }
      }
    }
    cVar6 = func_0x(lVar8);
    if ((cVar6 == '\0') || (*(char *)(lVar8 + 0x2050) == '\0')) goto LAB_;
    if (iStack_ca0 == 0) {
LAB_:
      uStack_ccd = 1;
      goto LAB_;
    }
    uStack_a22 = 9;
    uStack_a1e = 1;
    if ((iStack_ca0 == 9) && (sStack_c9c == 1)) goto LAB_;
    uStack_ccd = 0;
    pbVar18 = *ppbStack_cf0;
    cStack_cd0 = '\0';
    pbStack_870 = pbVar18;
    if (*(short *)(pbVar18 + 0x24) == 0) {
LAB_:
      uStack_bc0 = *(undefined8 *)(pbVar18 + 0x28);
      uStack_bb8 = *(ushort *)(pbVar18 + 0x30);
    }
    else {
      bVar2 = pbVar18[1];
      if ((((bVar2 == 0xb) || (bVar2 == 8)) || (bVar2 == 9)) && (*(int *)(pbVar18 + 0x18) == 99)) {
        puStack_868 = &uStack_ba8;
        puStack_860 = (undefined4 *)(pbVar18 + 0x20);
        uStack_ba8 = *puStack_860;
        uStack_ba4 = *(undefined2 *)(pbVar18 + 0x24);
        cVar6 = func_0x(&uStack_ba8);
        if (cVar6 == '\0') goto LAB_;
        cStack_cd0 = '\x01';
      }
      else {
LAB_:
        cStack_cd0 = '\0';
      }
      if (cStack_cd0 == '\0') goto LAB_;
      func_0x(pbVar18,&uStack_bc0);
    }
    puStack_858 = &uStack_bc0;
    puVar1 = (undefined8 *)(lVar8 + 0x20fc);
    puVar16 = (uint *)(lVar8 + 0x2108);
    uStack_bd4 = *puVar16;
    do {
      uStack_a78 = uStack_bd4 & 0xfffffffe;
      uStack_bec = *puVar1;
      uStack_be4 = *(undefined4 *)(lVar8 + 0x2104);
      LOCK();
      UNLOCK();
      uStack_bd4 = *puVar16;
    } while (uStack_a78 != uStack_bd4);
    puStack_988 = puVar1;
    puStack_928 = puVar16;
    puStack_850 = puVar16;
    if ((uint)uStack_bc0 <= (uint)uStack_bec) {
      if ((uint)uStack_bec != (uint)uStack_bc0) goto LAB_;
      uVar11 = (uint)((ulonglong)uStack_bec >> 0x20);
      if ((uStack_bc0._4_4_ <= uVar11) &&
         ((uVar11 != uStack_bc0._4_4_ || (uStack_bb8 <= (ushort)uStack_be4)))) goto LAB_;
    }
    if (*(char *)(lVar8 + 0x6ac8) != '\0') {
LAB_:
      lStack_780 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      lStack_778 = (ulonglong)*_DAT_ +
                   *(longlong *)(lStack_780 + (ulonglong)*_DAT_ * 8);
      lStack_770 = *(longlong *)(lStack_778 + 8);
      lStack_768 = *(longlong *)(lStack_770 + 0x60);
      if ((lStack_768 == *(longlong *)(lVar8 + 0x2120)) ||
         (cVar6 = func_0x(lVar8), cVar6 != '\0')) goto LAB_;
      if (ppbStack_b90 == (byte **)0x0) {
        ppbStack_b90 = (byte **)func_0x();
      }
      puStack_760 = &uStack_c98;
      pbVar18 = *ppbStack_cf0;
      cStack_cce = '\0';
      pbStack_758 = pbVar18;
      if (*(short *)(pbVar18 + 0x24) == 0) {
LAB_:
        uStack_c98 = *(undefined8 *)(pbVar18 + 0x28);
        uStack_c90 = *(undefined2 *)(pbVar18 + 0x30);
      }
      else {
        bVar2 = pbVar18[1];
        if ((((bVar2 == 0xb) || (bVar2 == 8)) || (bVar2 == 9)) && (*(int *)(pbVar18 + 0x18) == 99))
        {
          puStack_750 = &uStack_b98;
          puStack_748 = (undefined4 *)(pbVar18 + 0x20);
          uStack_b98 = *puStack_748;
          uStack_b94 = *(undefined2 *)(pbVar18 + 0x24);
          cVar6 = func_0x(&uStack_b98);
          if (cVar6 == '\0') goto LAB_;
          cStack_cce = '\x01';
        }
        else {
LAB_:
          cStack_cce = '\0';
        }
        if (cStack_cce == '\0') goto LAB_;
        func_0x(pbVar18,&uStack_c98);
      }
      puStack_740 = &uStack_c98;
      uStack_8ea = 0;
      uStack_8f4 = uStack_c98;
      uStack_8ec = uStack_c90;
      if (ppbStack_cf0 != (byte **)0x0) {
        puStack_738 = (ushort *)((longlong)ppbStack_cf0 + 0x62);
        uStack_c58 = *puStack_738;
        if (((uStack_c58 & 0x400) == 0) || ((short)uStack_ce4 < 3)) {
          iStack_cc8 = (int)(short)uStack_ce4;
          ppbStack_ab0 = ppbStack_cf0;
          uStack_c50 = *puStack_738;
          puStack_730 = puStack_738;
          if (((byte)uStack_c50 >> 3 & 1) != 0) {
            if (iStack_cc8 == 3) {
              iStack_cc8 = 4;
            }
            else if (iStack_cc8 < 2) goto LAB_;
            puStack_728 = (uint *)((longlong)ppbStack_cf0 + 100);
            uStack_ad8 = *puStack_728;
            if ((((uStack_ad8 & 8) != 0) && (pbVar18 = ppbStack_cf0[0x12], pbVar18 != (byte *)0x0))
               && (pbStack_720 = pbVar18, *(longlong *)(pbVar18 + 0x758) != 0)) {
              func_0x(*(undefined8 *)(pbVar18 + 0x758),ppbStack_cf0,iStack_cc8);
            }
          }
LAB_:
          bStack_c1b = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar16 = (uint *)((longlong)ppbStack_ab0 + 100);
            uStack_ae0 = *puVar16;
            puStack_718 = puVar16;
            if (((((uStack_ae0 & 8) != 0) && (2 < iStack_cc8)) &&
                (uStack_ae8 = *puVar16, puStack_710 = puVar16,
                (uStack_ae8 & 0xc0000000) != 0x40000000)) && (*ppbStack_ab0 != (byte *)0x0)) {
              uStack_9f8 = 2;
              iVar7 = (*_DAT_)(*ppbStack_ab0,0x2000,2,auStack_9f4);
              if (iVar7 != 0) {
                LOCK();
                *puVar16 = *puVar16 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar16 = *puVar16 | 0x40000000;
                UNLOCK();
              }
            }
          }
          ppbVar15 = ppbStack_ab0;
          iVar7 = iStack_cc8;
          func_0x(ppbStack_ab0 + 0x13,iStack_cc8);
          if ((_DAT_ != 0) && (bStack_c19 = DAT_ >> 1, (bStack_c19 & 1) != 0)) {
            func_0x(ppbVar15,0,iVar7);
          }
          uStack_ce4 = uStack_ce4 & 0xffff0000;
          ppbStack_cf0 = (byte **)0x0;
        }
        else {
          func_0x(&ppbStack_cf0);
        }
      }
      puStack_708 = &uStack_a08;
      puStack_908 = &uStack_a58;
      uStack_d08 = 0;
      uStack_a58 = uStack_c98;
      uStack_a50 = uStack_c90;
      uStack_a08 = uStack_c98;
      uStack_a00 = uStack_c90;
      func_0x(*(undefined8 *)(lVar8 + 0x728),&uStack_a58,4);
      goto LAB_;
    }
    lStack_848 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    lStack_840 = (ulonglong)*_DAT_ +
                 *(longlong *)(lStack_848 + (ulonglong)*_DAT_ * 8);
    lStack_838 = *(longlong *)(lStack_840 + 8);
    lStack_830 = *(longlong *)(lStack_838 + 0x60);
    if ((lStack_830 == *(longlong *)(lVar8 + 0x2120)) ||
       (cVar6 = func_0x(lVar8), cVar6 != '\0')) goto LAB_;
    uStack_bf0 = *puVar16;
    puStack_978 = (uint *)(lVar8 + 0x2108);
    do {
      uStack_ac0 = uStack_bf0 & 0xfffffffe;
      uStack_bfc = *puVar1;
      uStack_bf4 = *(undefined4 *)(lVar8 + 0x2104);
      LOCK();
      UNLOCK();
      uStack_bf0 = *puStack_978;
    } while (uStack_ac0 != uStack_bf0);
    uVar10 = (ushort)uStack_bf4;
    uStack_a10 = (ushort)uStack_bf4;
    pbVar18 = *ppbStack_cf0;
    cStack_ccf = '\0';
    puStack_a40 = puVar1;
    uStack_a18 = uStack_bfc;
    puStack_828 = puVar16;
    pbStack_820 = pbVar18;
    if (*(short *)(pbVar18 + 0x24) == 0) {
LAB_:
      uStack_bd0 = *(undefined8 *)(pbVar18 + 0x28);
      uStack_bc8 = *(ushort *)(pbVar18 + 0x30);
    }
    else {
      bVar2 = pbVar18[1];
      if ((((bVar2 == 0xb) || (bVar2 == 8)) || (bVar2 == 9)) && (*(int *)(pbVar18 + 0x18) == 99)) {
        puStack_818 = &uStack_bb0;
        puStack_810 = (undefined4 *)(pbVar18 + 0x20);
        uStack_bb0 = *puStack_810;
        uStack_bac = *(undefined2 *)(pbVar18 + 0x24);
        cVar6 = func_0x(&uStack_bb0);
        if (cVar6 == '\0') goto LAB_;
        cStack_ccf = '\x01';
      }
      else {
LAB_:
        cStack_ccf = '\0';
      }
      if (cStack_ccf == '\0') goto LAB_;
      func_0x(pbVar18,&uStack_bd0);
    }
    if ((uint)uStack_bfc < (uint)uStack_bd0) {
LAB_:
      lVar13 = *(longlong *)(lVar8 + 0x6b0);
      lStack_808 = lVar13;
      func_0x(&uStack_bd0,asStack_a0,auStack_ac4);
      func_0x(&uStack_a18,asStack_70,auStack_ac4);
      uStack_970 = 0x1d;
      uStack_96c = 0x10000;
      if ((_DAT_ & 0x10000) == 0) goto LAB_;
      uStack_b80 = 6;
      puStack_800 = &uStack_400;
      uStack_400 = 0;
      uStack_3fe = 6;
      uStack_3f8 = 0;
      ppuStack_3f0 = &puStack_3d8;
      puStack_3e8 = auStack_378;
      uStack_1b8 = 0;
      uStack_1b4 = 0;
      uStack_3e0 = 0;
      uStack_1b0 = 0;
      ppuStack_7f8 = &puStack_3d8;
      puStack_3d8 = &uStack_1a8;
      uStack_3d0 = 0x34;
      uStack_3cc = 5;
      uStack_3ca = 0;
      plStack_7f0 = &lStack_3c8;
      plStack_7e8 = &lStack_3b8;
      ppsStack_7e0 = &psStack_3a8;
      psStack_3a8 = (short *)0x0;
      iStack_3a0 = 0;
      uStack_39c = 7;
      uStack_39a = 0;
      ppsStack_7d8 = &psStack_398;
      psStack_398 = (short *)0x0;
      iStack_390 = 0;
      uStack_38c = 8;
      uStack_38a = 0;
      puStack_7d0 = &uStack_388;
      uStack_388 = 0;
      uStack_380 = 0;
      uStack_37c = 9;
      uStack_37a = 0;
      uStack_1a8 = (uint)*(ushort *)(lVar8 + 0x6b8);
      sStack_1a4 = sStack_c9c;
      iStack_1a2 = iStack_ca0;
      uStack_19e = 0xff;
      pbStack_7c8 = *ppbStack_cf0;
      bStack_19d = pbStack_7c8[1];
      plStack_7c0 = &lStack_3c8;
      lStack_3c8 = lVar13 + 0x254;
      uStack_3c0 = 0x10;
      uStack_3bc = 5;
      uStack_3ba = 0;
      plStack_7b8 = &lStack_3b8;
      lStack_3b8 = lVar13 + 0x244;
      uStack_3b0 = 0x10;
      uStack_3ac = 6;
      uStack_3aa = 0;
      psStack_7b0 = asStack_a0;
      lVar8 = -1;
      do {
        lVar8 = lVar8 + 1;
      } while (asStack_a0[lVar8] != 0);
      iStack_900 = (int)lVar8 * 2;
      ppsStack_7a8 = &psStack_3a8;
      psStack_3a8 = asStack_a0;
      iStack_3a0 = iStack_900;
      uStack_39c = 7;
      uStack_39a = 0;
      psStack_7a0 = asStack_70;
      lVar8 = -1;
      do {
        lVar8 = lVar8 + 1;
      } while (asStack_70[lVar8] != 0);
      iStack_8fc = (int)lVar8 * 2;
      ppsStack_798 = &psStack_398;
      psStack_398 = asStack_70;
      uStack_38c = 8;
      uStack_38a = 0;
      uStack_ac8 = 0;
      iStack_390 = iStack_8fc;
      puStack_790 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar13,&uStack_ac8);
      ppuVar5 = ppuStack_3f0;
      uVar11 = uVar20;
      if (puStack_790 != (uint *)0x0) {
        lVar8 = -1;
        do {
          lVar8 = lVar8 + 1;
        } while (*(short *)((longlong)puStack_790 + lVar8 * 2) != 0);
        uVar11 = (int)lVar8 * 2;
      }
      ppuStack_788 = ppuStack_3f0 + 10;
      uStack_8f8 = uVar11;
      *ppuStack_788 = puStack_790;
      *(uint *)(ppuVar5 + 0xb) = uVar11;
      *(undefined2 *)((longlong)ppuVar5 + 0x5c) = 9;
      *(undefined2 *)((longlong)ppuVar5 + 0x5e) = 0;
      func_0x(auStack_408);
      ppbStack_be0 = ppbStack_cf0;
      goto LAB_;
    }
    if ((uint)uStack_bfc == (uint)uStack_bd0) {
      uVar11 = (uint)((ulonglong)uStack_bd0 >> 0x20);
      if ((uStack_bfc._4_4_ < uVar11) || ((uStack_bfc._4_4_ == uVar11 && (uVar10 < uStack_bc8))))
      goto LAB_;
    }
LAB_:
    ppbStack_be0 = ppbStack_cf0;
  }
  else {
    iStack_c00 = 1;
    ppbStack_be0 = (byte **)func_0x(_DAT_,1,1,1);
    puStack_908 = (undefined8 *)0x0;
    func_0x(param_1,0,*ppbStack_be0,&iStack_ca0);
  }
LAB_:
  pbVar18 = *ppbStack_be0;
  uStack_11c = 0;
  pbStack_6f8 = pbVar18;
  if ((char)pbVar18[2] < '\0') {
    if ((uStack_150 == 0) || (ppbVar15 = uStack_140, uStack_140 == (byte **)0x0)) {
      puStack_6f0 = auStack_118;
      uStack_f0 = 0;
      uStack_e2 = 0;
      auStack_c8 = ZEXT816(0);
      puStack_6e8 = auStack_118;
      auStack_118 = ZEXT816(0);
      puStack_6e0 = auStack_108;
      stack0xfffffffffffffefa = SUB1614(ZEXT816(0),2);
      auStack_108._0_2_ = 0xffff;
      uStack_100 = 0;
      uStack_ea = 0;
      uStack_e8 = 0;
      uStack_e0 = 0;
      uStack_f8 = 0;
      puStack_6d8 = auStack_d8 + 8;
      auStack_d8 = ZEXT816(0);
      puStack_6d0 = auStack_b8;
      auStack_b8._0_12_ = ZEXT812(0);
      auStack_b8._12_4_ = 0;
      puStack_6c8 = auStack_b8 + 0xc;
      uStack_a8 = 0;
      ppbVar15 = (byte **)auStack_118;
    }
    cStack_ccc = '\0';
    ppbStack_aa8 = ppbVar15;
    if (*(short *)(pbVar18 + 0x24) == 0) {
LAB_:
      uStack_c30 = *(undefined8 *)(pbVar18 + 0x28);
      sStack_c28 = *(short *)(pbVar18 + 0x30);
    }
    else {
      bVar2 = pbVar18[1];
      if ((((bVar2 == 0xb) || (bVar2 == 8)) || (bVar2 == 9)) && (*(int *)(pbVar18 + 0x18) == 99)) {
        puStack_6c0 = &uStack_ba0;
        puStack_6b8 = (undefined4 *)(pbVar18 + 0x20);
        uStack_ba0 = *puStack_6b8;
        uStack_b9c = *(undefined2 *)(pbVar18 + 0x24);
        cVar6 = func_0x(&uStack_ba0);
        if (cVar6 == '\0') goto LAB_;
        cStack_ccc = '\x01';
      }
      else {
LAB_:
        cStack_ccc = '\0';
      }
      if (cStack_ccc == '\0') goto LAB_;
      func_0x(pbVar18,&uStack_c30);
    }
    puStack_6b0 = &uStack_c30;
    puStack_6a8 = (undefined4 *)(pbVar18 + 0x20);
    pbStack_6a0 = pbVar18 + 0x60;
    if (((pbStack_6a0 == *ppbVar15) &&
        (ppbStack_690 = ppbVar15 + 0xc, sStack_c28 == *(short *)(ppbVar15 + 0xd))) &&
       (((int)uStack_c30 == *(int *)ppbStack_690 &&
        (uStack_c30._4_4_ == *(int *)((longlong)ppbVar15 + 100))))) {
      lStack_688 = (longlong)ppbVar15 + 0x6c;
    }
    *ppbVar15 = pbStack_6a0;
    ppbStack_680 = ppbVar15 + 0xc;
    sStack_b78 = sStack_c28;
    iStack_9f0 = uStack_c30._4_4_;
    iStack_9e8 = (int)uStack_c30;
    *(int *)ppbStack_680 = (int)uStack_c30;
    *(int *)((longlong)ppbVar15 + 100) = uStack_c30._4_4_;
    *(short *)(ppbVar15 + 0xd) = sStack_c28;
    puStack_678 = (undefined4 *)((longlong)ppbVar15 + 0x6c);
    *puStack_678 = *puStack_6a8;
    *(undefined2 *)(ppbVar15 + 0xe) = *(undefined2 *)(pbVar18 + 0x24);
    *(undefined2 *)((longlong)ppbVar15 + 0x72) = 0;
    uVar9 = (ulonglong)*pbStack_6a0;
    uStack_b70 = (ushort)*pbStack_6a0;
    uStack_a28 = *(undefined4 *)(uVar9 * 6 + 0x117e650);
    uStack_a24 = *(undefined2 *)(uVar9 * 6 + 0x117e654);
    uStack_ad0 = *(undefined4 *)(uVar9 * 6 + 0x117e650);
    uStack_cca = *(short *)(uVar9 * 6 + 0x117e654);
    pbStack_aa0 = pbVar18 + 99;
    ppbStack_670 = ppbVar15 + 2;
    *(undefined2 *)ppbStack_670 = 0xffff;
    ppbVar15[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar15 + 0x2e) = 0;
    ppbVar15[7] = (byte *)0x0;
    ppbVar15[4] = (byte *)0x0;
    ppbStack_668 = ppbVar15 + 9;
    *ppbStack_668 = (byte *)0x0;
    ppbVar15[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar15 + 0xb) = 0;
    sStack_acc = uStack_cca;
    ppbStack_698 = ppbVar15;
    if ((**ppbVar15 & 2) != 0) {
      pbStack_660 = pbStack_6a0 + (short)uStack_cca;
      bVar2 = *pbStack_660;
      uStack_b68 = (ushort)(bVar2 & 1);
      *(ushort *)ppbStack_670 = uStack_b68;
      puVar17 = (ushort *)((longlong)ppbVar15 + 0x12);
      ppbStack_658 = ppbStack_670;
      if ((bVar2 & 1) == 0) {
        uStack_c10 = 0;
        ppbVar15[3] = pbStack_660;
        *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar15 + 0x36) = 0;
        pbStack_648 = ppbVar15[3];
        puStack_650 = puVar17;
        switch(*pbStack_648 & 0xe) {
        default:
          uVar10 = *(ushort *)(pbStack_660 + 2);
          uVar20 = (uint)uVar10;
          uStack_c10 = (uint)uVar10;
          if (0x1f9d < uVar10 - 1) {
            func_0x(pbStack_648,6);
          }
          break;
        case 4:
          uVar20 = 9;
          uStack_c10 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar20 = 1;
          uStack_c10 = 1;
        }
        *(uint *)(ppbVar15 + 4) = uVar20;
        *(undefined8 *)((longlong)ppbVar15 + 0x2e) = 0;
      }
      else {
        ppbVar15[3] = pbStack_660;
        bVar2 = *pbStack_660;
        switch(bVar2 & 0x1c) {
        default:
          puStack_638 = (ushort *)(pbStack_660 + 1);
          if ((char)*(byte *)puStack_638 < '\0') {
            uVar10 = *puStack_638;
            *puVar17 = uVar10;
            *puVar17 = (uVar10 & 0x7f) << 8 | uVar10 >> 8;
            *(undefined2 *)(ppbVar15 + 5) = 3;
            sVar19 = 3;
          }
          else {
            *puVar17 = (ushort)*(byte *)puStack_638;
            sVar19 = 2;
            *(undefined2 *)(ppbVar15 + 5) = 2;
          }
          *(short *)((longlong)ppbVar15 + 0x2c) = (short)(*puVar17 + 1 >> 1) + sVar19;
          if (*puVar17 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar15 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
            *(undefined4 *)(ppbVar15 + 8) = 0;
          }
          else {
            iVar7 = *puVar17 - 1;
            *(short *)((longlong)ppbVar15 + 0x2a) =
                 ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                 (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
            *(undefined4 *)(ppbVar15 + 8) = 0;
          }
          break;
        case 4:
          pbStack_628 = pbStack_660;
          pbStack_620 = pbStack_660;
          if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
            ppbVar15[3] = (byte *)0x0;
            *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
            *(undefined2 *)(ppbVar15 + 5) = 0;
            *puVar17 = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x2a) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x2c) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x2e) = 0;
            *(undefined2 *)(ppbVar15 + 6) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x32) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x34) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x36) = 0;
            ppbVar15[4] = (byte *)0x0;
            *(undefined4 *)(ppbVar15 + 8) = 0;
            ppbVar15[7] = (byte *)0x0;
            ppbVar15[3] = pbStack_660;
            *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0xf;
            *(undefined4 *)(ppbVar15 + 8) = 0;
            *(undefined4 *)(ppbVar15 + 8) = 1;
          }
          else {
            ppbVar15[3] = (byte *)0x0;
            *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
            *(undefined2 *)(ppbVar15 + 5) = 0;
            *puVar17 = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x2a) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x2c) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x2e) = 0;
            *(undefined2 *)(ppbVar15 + 6) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x32) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x34) = 0;
            *(undefined2 *)((longlong)ppbVar15 + 0x36) = 0;
            ppbVar15[4] = (byte *)0x0;
            *(undefined4 *)(ppbVar15 + 8) = 0;
            ppbVar15[7] = (byte *)0x0;
            ppbVar15[3] = pbStack_660;
            *(undefined4 *)((longlong)ppbVar15 + 0x14) = 1;
            *(undefined4 *)(ppbVar15 + 8) = 0;
          }
          break;
        case 8:
          ppbVar15[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
          *(undefined2 *)(ppbVar15 + 5) = 0;
          *puVar17 = 0;
          *(undefined2 *)((longlong)ppbVar15 + 0x2a) = 0;
          *(undefined2 *)((longlong)ppbVar15 + 0x2c) = 0;
          *(undefined2 *)((longlong)ppbVar15 + 0x2e) = 0;
          *(undefined2 *)(ppbVar15 + 6) = 0;
          *(undefined2 *)((longlong)ppbVar15 + 0x32) = 0;
          *(undefined2 *)((longlong)ppbVar15 + 0x34) = 0;
          *(undefined2 *)((longlong)ppbVar15 + 0x36) = 0;
          ppbVar15[4] = (byte *)0x0;
          *(undefined4 *)(ppbVar15 + 8) = 0;
          ppbVar15[7] = (byte *)0x0;
          ppbVar15[3] = pbStack_660;
          *(undefined4 *)((longlong)ppbVar15 + 0x14) = 9;
          *(undefined4 *)(ppbVar15 + 8) = 0;
          pbStack_630 = pbStack_660;
        }
        ppbVar15[7] = (byte *)0x0;
        ppbVar15[4] = (byte *)0x0;
        puStack_640 = puVar17;
      }
    }
    if ((**ppbVar15 & 4) != 0) {
      if (uStack_ad0._2_2_ == 0) {
        uVar9 = (ulonglong)(short)uStack_cca;
      }
      else {
        uVar9 = (ulonglong)*(ushort *)(pbStack_aa0 + (longlong)uStack_ad0._2_2_ * 2 + -2);
      }
      psStack_618 = (short *)(pbVar18 + uVar9 + 0x60);
      ppbVar15[9] = (byte *)psStack_618;
      sStack_b64 = *psStack_618;
      ppbVar15[10] = (byte *)(psStack_618 + 1);
      *(short *)(ppbVar15 + 0xb) = (sStack_b64 + 1) * 2;
      ppsStack_610 = (short **)(ppbVar15 + 9);
    }
    if (ppbVar15[1] != (byte *)0x0) {
      func_0x(ppbVar15[1],ppbVar15);
    }
  }
  else {
    ppbStack_aa8 = (byte **)0x0;
    ppbVar15 = ppbVar12;
  }
  uVar10 = 3;
  uVar20 = (uint)*(ushort *)(pbVar18 + 0xe);
  uStack_9e0 = (uint)*(ushort *)(pbVar18 + 0xe);
  pbStack_608 = pbVar18 + *(ushort *)(pbVar18 + 0x1ffe);
  uStack_cca = (ushort)(*pbStack_608 & 1);
  uStack_150 = uStack_cca;
  if ((*pbStack_608 & 1) == 0) {
    pbStack_148 = pbStack_608;
    uStack_14c = 0;
    uStack_12a = 0;
    uStack_128 = 0;
    uStack_c08 = uStack_9e0;
    puStack_600 = &uStack_14e;
    pbStack_5f8 = pbStack_608;
    switch(*pbStack_608 & 0xe) {
    default:
      uVar10 = *(ushort *)(pbStack_608 + 2);
      uVar20 = (uint)uVar10;
      uStack_c08 = (uint)uVar10;
      if (0x1f9d < uVar10 - 1) {
        func_0x(pbStack_608,6);
      }
      break;
    case 4:
      uVar20 = 9;
      uStack_c08 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar20 = 1;
      uStack_c08 = 1;
    }
    uStack_140 = (byte **)CONCAT44(uStack_140._4_4_,uVar20);
    pbStack_132 = pbVar18 + 0x2000;
  }
  else {
    pbStack_148 = pbStack_608;
    bVar2 = *pbStack_608;
    switch(bVar2 & 0x1c) {
    default:
      puStack_5e8 = (ushort *)(pbStack_608 + 1);
      if ((char)*(byte *)puStack_5e8 < '\0') {
        uStack_14e = (*puStack_5e8 & 0x7f) << 8 | *puStack_5e8 >> 8;
      }
      else {
        uStack_14e = (ushort)*(byte *)puStack_5e8;
        uVar10 = 2;
      }
      uStack_134 = (short)(uStack_14e + 1 >> 1) + uVar10;
      if (uStack_14e < 0x1f) {
        uStack_138 = (uint)uVar10;
        uStack_14c = 0;
        uStack_120 = 0;
      }
      else {
        iVar7 = uStack_14e - 1;
        uStack_138 = CONCAT22(((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                              (short)((longlong)iVar7 * 0x88888889 >> 0x3f),uVar10);
        uStack_14c = 0;
        uStack_120 = 0;
      }
      break;
    case 4:
      pbStack_5d8 = pbStack_608;
      pbStack_5d0 = pbStack_608;
      if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
        uStack_14e = 0;
        uStack_138 = 0;
        uStack_134 = 0;
        pbStack_132 = (byte *)0x0;
        uStack_12a = 0;
        uStack_14c = 0xf;
        uStack_120 = 1;
      }
      else {
        uStack_14e = 0;
        uStack_138 = 0;
        uStack_134 = 0;
        pbStack_132 = (byte *)0x0;
        uStack_12a = 0;
        uStack_14c = 1;
        uStack_120 = 0;
      }
      break;
    case 8:
      uStack_14e = 0;
      uStack_138 = 0;
      uStack_134 = 0;
      pbStack_132 = (byte *)0x0;
      uStack_12a = 0;
      uStack_14c = 9;
      uStack_120 = 0;
      pbStack_5e0 = pbStack_608;
    }
    uStack_128 = SUB82(pbVar18 + 0x2000,0);
    uStack_126 = (undefined6)((ulonglong)(pbVar18 + 0x2000) >> 0x10);
    uStack_140 = ppbVar15;
    uVar20 = (uint)ppbVar15;
    puStack_5f0 = &uStack_14e;
  }
  puVar17 = puStack_8e8;
  *puStack_8e8 = uStack_150;
  if (uStack_150 == 0) {
    puVar17 = &uStack_14e;
    puStack_a30 = puStack_8e8 + 1;
    puStack_cd8 = puVar17;
    if (uStack_14c == 0) {
      iStack_cf8 = 0;
      uStack_14e = 0;
      if ((*pbStack_148 & 0x10) != 0) {
        uVar20 = uVar20 + 2 + (*(ushort *)(pbStack_148 + uVar20) + 7 >> 3);
      }
      uStack_140 = (byte **)CONCAT44(uVar20,(undefined4)uStack_140);
      if ((*pbStack_148 & 0x20) == 0) {
        uStack_14c = uVar20;
        uStack_134 = 0;
        uStack_138 = uVar20;
      }
      else {
        puStack_a38 = (ushort *)(pbStack_148 + uVar20);
        uStack_134 = *puStack_a38;
        if (*puStack_a38 == 0) {
          iStack_cf8 = 1;
          if ((cRam0000000001a9113b != '\0') ||
             (bStack_c18 = bRam0000000001aa1a40, (bRam0000000001aa1a40 & 1) != 0)) {
            lStack_5c8 = *(longlong *)(unaff_GS_OFFSET + 0x58);
            lStack_5c0 = (ulonglong)*_DAT_ +
                         *(longlong *)(lStack_5c8 + (ulonglong)*_DAT_ * 8);
            lStack_5b8 = *(longlong *)(lStack_5c0 + 8);
            if (lStack_5b8 == 0) {
              lStack_960 = 0;
            }
            else {
              lStack_960 = *(longlong *)(lStack_5b8 + 0x60);
              if ((lStack_960 != 0) && (*(char *)(lStack_960 + 0x499) != '\0')) {
                if ((cRam0000000001a9102b == '\0') &&
                   (bStack_c88 = bRam0000000001aa1a40 >> 1, (bStack_c88 & 1) == 0)) {
                  (*pcRam0000000000fff968)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_d08 = 0;
                  (*pcRam0000000000fff960)(1,0x1381b68,0x14a1838,0x80f);
                }
              }
            }
          }
          puVar17 = puStack_cd8;
          func_0x(pbStack_148,3);
          uVar20 = uStack_140._4_4_;
        }
        uStack_138 = uVar20 + (uStack_134 + 1) * 2;
        if (0x1f9e < uStack_138) {
          iStack_cf8 = iStack_cf8 + 1;
          if ((cRam0000000001a9113b != '\0') ||
             (bStack_c87 = bRam0000000001aa1a40, (bRam0000000001aa1a40 & 1) != 0)) {
            lStack_5b0 = *(longlong *)(unaff_GS_OFFSET + 0x58);
            lStack_5a8 = (ulonglong)*_DAT_ +
                         *(longlong *)(lStack_5b0 + (ulonglong)*_DAT_ * 8);
            lStack_5a0 = *(longlong *)(lStack_5a8 + 8);
            puVar17 = puStack_cd8;
            if (lStack_5a0 == 0) {
              lStack_958 = 0;
            }
            else {
              lStack_958 = *(longlong *)(lStack_5a0 + 0x60);
              if ((lStack_958 != 0) && (*(char *)(lStack_958 + 0x499) != '\0')) {
                if ((cRam0000000001a9102b == '\0') &&
                   (bStack_c86 = bRam0000000001aa1a40 >> 1, (bStack_c86 & 1) == 0)) {
                  (*pcRam0000000000fff968)(0x22,0x44,0x15,0x3ec);
                  puVar17 = puStack_cd8;
                }
                else {
                  uStack_d08 = 0;
                  (*pcRam0000000000fff960)(1,0x1381b68,0x14a1838,0x816);
                  puVar17 = puStack_cd8;
                }
              }
            }
          }
          func_0x(pbStack_148,4);
          uVar20 = uStack_140._4_4_;
        }
        uVar9 = (ulonglong)uStack_134;
        uStack_b60 = puStack_a38[uVar9];
        uStack_14c = uStack_b60 & 0x7fff;
        uVar11 = uStack_138;
        if ((uStack_b60 & 0x7fff) < uStack_138) {
          iStack_cf8 = iStack_cf8 + 1;
          if ((cRam0000000001a9113b != '\0') ||
             (bStack_c85 = bRam0000000001aa1a40, (bRam0000000001aa1a40 & 1) != 0)) {
            lStack_598 = *(longlong *)(unaff_GS_OFFSET + 0x58);
            lStack_590 = (ulonglong)*_DAT_ +
                         *(longlong *)(lStack_598 + (ulonglong)*_DAT_ * 8);
            lStack_588 = *(longlong *)(lStack_590 + 8);
            puVar17 = puStack_cd8;
            if (lStack_588 == 0) {
              lStack_950 = 0;
            }
            else {
              lStack_950 = *(longlong *)(lStack_588 + 0x60);
              if ((lStack_950 != 0) && (*(char *)(lStack_950 + 0x499) != '\0')) {
                if ((cRam0000000001a9102b == '\0') &&
                   (bStack_c84 = bRam0000000001aa1a40 >> 1, (bStack_c84 & 1) == 0)) {
                  (*pcRam0000000000fff968)(0x22,0x44,0x15,0x3ec);
                  puVar17 = puStack_cd8;
                }
                else {
                  uStack_d08 = 0;
                  (*pcRam0000000000fff960)(1,0x1381b68,0x14a1838,0x81d);
                  puVar17 = puStack_cd8;
                }
              }
            }
          }
          func_0x(pbStack_148,4);
          uVar9 = (ulonglong)uStack_134;
          uVar20 = uStack_140._4_4_;
          uVar11 = uStack_138;
        }
        do {
          iVar7 = (int)uVar9;
          puStack_580 = puStack_a38 + (ulonglong)(iVar7 - 1) + 1;
          if (-1 < (short)*puStack_580) break;
          pbStack_578 = pbStack_148 + uVar20;
          uVar14 = uVar11;
          if (iVar7 != 1) {
            uStack_b5c = *(ushort *)(pbStack_578 + (longlong)(iVar7 + -2) * 2 + 2);
            uVar14 = uStack_b5c & 0x7fff;
          }
          uStack_b58 = *(ushort *)(pbStack_578 + (longlong)(iVar7 + -1) * 2 + 2);
          uStack_9d0 = uStack_b58 & 0x7fff;
          iStack_9d8 = iVar7;
          if ((uVar14 < uVar11) || (uStack_9d0 < uVar14)) {
            func_0x(pbStack_148,7);
            uVar9 = (ulonglong)uStack_134;
            uVar20 = uStack_140._4_4_;
            uVar11 = uStack_138;
          }
          uStack_9cc = uVar14;
          if ((uVar14 < uVar11) || (uStack_14c < uVar14)) {
            iStack_cf8 = iStack_cf8 + 1;
            goto code_r0x001025eb;
          }
          uStack_b54 = *(ushort *)(pbStack_148 + uVar14);
          if (uStack_b54 == 5) {
            *puVar17 = *puVar17 | 2;
            puVar17[0xd] = puVar17[0xd] - 1;
            puStack_570 = puVar17 + 0x14;
            *puStack_570 = (ushort)uVar14;
            lStack_568 = (ulonglong)(uVar14 & 0xffff) + *(longlong *)(puVar17 + 3);
            uVar10 = *(ushort *)(lStack_568 + 2);
            puVar17[0x15] = puVar17[0x15] & 0xc7ff;
            if ((uVar10 & 0x4000) != 0) {
              puVar17[0x15] = puVar17[0x15] | uVar10 & 0x3800;
            }
            puVar17[0x15] = (puVar17[0x15] ^ *(ushort *)(lStack_568 + 2)) & 0x7ff ^ puVar17[0x15];
            break;
          }
          if (uStack_b54 < 0x400) break;
          uStack_14e = uStack_14e | 1;
          uStack_134 = (short)uVar9 - 1;
          uVar9 = (ulonglong)uStack_134;
        } while (uStack_134 != 0);
      }
      ppbVar12 = (byte **)(puVar17 + 3);
      if ((**ppbVar12 & 0x40) == 0) {
        *(undefined4 *)(puVar17 + 0x12) = 0;
      }
      else {
        *(undefined4 *)(puVar17 + 0x12) = *(undefined4 *)(puVar17 + 1);
        *(int *)(puVar17 + 1) = *(int *)(puVar17 + 1) + 0xe;
        puStack_560 = (ulonglong *)func_0x(puVar17);
        uStack_948 = *puStack_560;
        uStack_b50 = (ushort)(uStack_948 >> 0x30);
        if ((((uint)(int)(short)uStack_b50 >> 1 ^ (int)(short)uStack_b50) & 0x2000) != 0) {
          if ((uStack_948 & 0x4000000000000000) == 0) {
            uStack_b50 = uStack_b50 & 0xdfff;
          }
          else {
            uStack_b50 = uStack_b50 | 0x2000;
          }
        }
        iVar7 = 0;
        if (uStack_b50 == 0xfffc) {
          puStack_558 = &uStack_948;
          iVar7 = (int)((uStack_948 >> 0x20 & 0xffff) >> 5);
          iStack_9c8 = iVar7;
        }
        *(int *)(puVar17 + 1) = *(int *)(puVar17 + 1) + iVar7;
      }
      if ((*(byte **)(puVar17 + 0xe) != (byte *)0x0) &&
         (*(byte **)(puVar17 + 0xe) < *ppbVar12 + *(uint *)(puVar17 + 1))) {
        iStack_cf8 = iStack_cf8 + 1;
        if ((cRam0000000001a9113b != '\0') ||
           (bStack_c83 = bRam0000000001aa1a40, (bRam0000000001aa1a40 & 1) != 0)) {
          lStack_550 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          lStack_548 = (ulonglong)*_DAT_ +
                       *(longlong *)(lStack_550 + (ulonglong)*_DAT_ * 8);
          lStack_540 = *(longlong *)(lStack_548 + 8);
          puVar17 = puStack_cd8;
          if (lStack_540 == 0) {
            lStack_940 = 0;
          }
          else {
            lStack_940 = *(longlong *)(lStack_540 + 0x60);
            if ((lStack_940 != 0) && (*(char *)(lStack_940 + 0x499) != '\0')) {
              if ((cRam0000000001a9102b == '\0') &&
                 (bStack_c82 = bRam0000000001aa1a40 >> 1, (bStack_c82 & 1) == 0)) {
                (*pcRam0000000000fff968)(0x22,0x44,0x15,0x3fa);
                puVar17 = puStack_cd8;
              }
              else {
                uStack_d08 = 0;
                (*pcRam0000000000fff960)(1,0x1381b68,0x14a1838,0x877);
                puVar17 = puStack_cd8;
              }
            }
          }
        }
        func_0x(*ppbVar12,0x12);
      }
      if (0x3f3b < *(int *)(puVar17 + 1) - 1U) {
        iStack_cf8 = iStack_cf8 + 1;
        if ((cRam0000000001a9113b != '\0') ||
           (bStack_c81 = bRam0000000001aa1a40, (bRam0000000001aa1a40 & 1) != 0)) {
          lStack_538 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          lStack_530 = (ulonglong)*_DAT_ +
                       *(longlong *)(lStack_538 + (ulonglong)*_DAT_ * 8);
          lStack_528 = *(longlong *)(lStack_530 + 8);
          puVar17 = puStack_cd8;
          if (lStack_528 == 0) {
            lStack_938 = 0;
          }
          else {
            lStack_938 = *(longlong *)(lStack_528 + 0x60);
            if ((lStack_938 != 0) && (*(char *)(lStack_938 + 0x499) != '\0')) {
              if ((cRam0000000001a9102b == '\0') &&
                 (bStack_c80 = bRam0000000001aa1a40 >> 1, (bStack_c80 & 1) == 0)) {
                (*pcRam0000000000fff968)(0x22,0x44,0x15,0x3ed);
                puVar17 = puStack_cd8;
              }
              else {
                uStack_d08 = 0;
                (*pcRam0000000000fff960)(1,0x1381b68,0x14a1838,0x87c);
                puVar17 = puStack_cd8;
              }
            }
          }
        }
        func_0x(*ppbVar12,5);
      }
    }
code_r0x001025eb:
    puVar4 = puStack_a30;
    uVar3 = uStack_a98;
    uStack_920 = *(uint *)(puVar17 + 1);
    if (uStack_920 < 9) {
      pbStack_520 = *(byte **)(puVar17 + 3);
      bStack_c7f = *pbStack_520 & 0xe;
      if ((bStack_c7f == 0) || (bStack_c7f == 0xc)) {
        uStack_920 = 9;
      }
    }
    *(undefined4 *)(puStack_a30 + 7) = *(undefined4 *)(puVar17 + 7);
    *puStack_a30 = *puVar17;
    *(undefined4 *)(puStack_a30 + 1) = *(undefined4 *)(puVar17 + 1);
    puStack_a30[0xd] = puVar17[0xd];
    *(undefined4 *)(puStack_a30 + 9) = *(undefined4 *)(puVar17 + 9);
    *(undefined4 *)(puStack_a30 + 0xb) = *(undefined4 *)(puVar17 + 0xb);
    *(undefined4 *)(puStack_a30 + 0x12) = *(undefined4 *)(puVar17 + 0x12);
    func_0x(uStack_a98,0x5d6,*(undefined8 *)(puVar17 + 3),uStack_920);
    *(undefined8 *)(puVar4 + 3) = uVar3;
    iVar7 = func_0x(puVar4);
    if (iVar7 != 0) {
      puStack_518 = (ushort *)((ulonglong)*(uint *)(puVar4 + 9) + *(longlong *)(puVar4 + 3));
      uStack_a90 = (uint)*puStack_518;
      if ((*(byte *)puVar4 & 1) != 0) {
        uStack_a90 = *puStack_518 - 1;
      }
      if (uStack_a90 == 1) {
        uVar20 = *(uint *)(puVar4 + 0xb);
        uVar11 = uVar20;
      }
      else {
        uStack_b4c = puStack_518[(longlong)(int)(uStack_a90 - 2) + 1];
        uVar20 = uStack_b4c & 0x7fff;
        uVar11 = *(uint *)(puVar4 + 0xb);
      }
      uStack_b48 = puStack_518[(longlong)(int)(uStack_a90 - 1) + 1];
      uStack_9c0 = uStack_b48 & 0x7fff;
      uStack_9c4 = uVar20;
      if ((uVar20 < uVar11) || (uStack_9c0 < uVar20)) {
        func_0x(*(longlong *)(puVar4 + 3),7);
      }
      puStack_510 = puStack_a30 + 0x14;
      *puStack_510 = (ushort)uVar20;
      lStack_508 = (ulonglong)(uVar20 & 0xffff) + *(longlong *)(puStack_a30 + 3);
      uVar10 = *(ushort *)(lStack_508 + 2);
      puStack_a30[0x15] = puStack_a30[0x15] & 0xc7ff;
      if ((uVar10 & 0x4000) != 0) {
        puStack_a30[0x15] = puStack_a30[0x15] | uVar10 & 0x3800;
      }
      puStack_a30[0x15] =
           (puStack_a30[0x15] ^ *(ushort *)(lStack_508 + 2)) & 0x7ff ^ puStack_a30[0x15];
      uStack_9bc = uVar20;
    }
  }
  else {
    ppbStack_500 = uStack_140;
    if ((uStack_140 == (byte **)0x0) || (ppbStack_4f8 = uStack_140, *uStack_140 == (byte *)0x0)) {
      uStack_af8 = 0;
      func_0x(puStack_8e8 + 1,uStack_a98,0x5d6,&uStack_14e);
      ppbStack_4f0 = uStack_140;
      if (uStack_150 == 0) {
        ppbStack_4f0 = ppbVar12;
      }
      *(byte ***)(puVar17 + 8) = ppbStack_4f0;
    }
    else {
      uStack_af8 = 1;
      func_0x(puStack_8e8,uStack_a98,0x5d6,&uStack_150);
    }
  }
  if (iStack_c00 != 0) {
    func_0x(_DAT_,ppbStack_be0,0);
    goto code_r0x00102d39;
  }
  if (ppbStack_cf0 == (byte **)0x0) goto code_r0x00102d39;
  puStack_4e8 = (ushort *)((longlong)ppbStack_cf0 + 0x62);
  uStack_c48 = *puStack_4e8;
  if (((uStack_c48 & 0x400) != 0) && (2 < (short)uStack_ce4)) {
    func_0x(&ppbStack_cf0);
    goto code_r0x00102d39;
  }
  iStack_cb0 = (int)(short)uStack_ce4;
  ppbStack_a88 = ppbStack_cf0;
  uStack_c40 = *puStack_4e8;
  puStack_4e0 = puStack_4e8;
  if (((byte)uStack_c40 >> 3 & 1) != 0) {
    if (iStack_cb0 == 3) {
      iStack_cb0 = 4;
    }
    else if (iStack_cb0 < 2) goto code_r0x00102c46;
    puStack_4d8 = (uint *)((longlong)ppbStack_cf0 + 100);
    uStack_a70 = *puStack_4d8;
    if ((((uStack_a70 & 8) != 0) && (pbVar18 = ppbStack_cf0[0x12], pbVar18 != (byte *)0x0)) &&
       (pbStack_4d0 = pbVar18, *(longlong *)(pbVar18 + 0x758) != 0)) {
      func_0x(*(undefined8 *)(pbVar18 + 0x758),ppbStack_cf0,iStack_cb0);
    }
  }
code_r0x00102c46:
  bStack_c1a = DAT_ >> 7;
  if ((char)DAT_ < '\0') {
    puVar16 = (uint *)((longlong)ppbStack_a88 + 100);
    uStack_b20 = *puVar16;
    puStack_4c8 = puVar16;
    if ((((uStack_b20 & 8) != 0) && (2 < iStack_cb0)) &&
       ((uStack_b18 = *puVar16, puStack_4c0 = puVar16, (uStack_b18 & 0xc0000000) != 0x40000000 &&
        (*ppbStack_a88 != (byte *)0x0)))) {
      uStack_994 = 2;
      iVar7 = (*_DAT_)(*ppbStack_a88,0x2000,2,auStack_9b8);
      if (iVar7 != 0) {
        LOCK();
        *puVar16 = *puVar16 & 0x3fffffff;
        UNLOCK();
        LOCK();
        *puVar16 = *puVar16 | 0x40000000;
        UNLOCK();
      }
    }
  }
  ppbVar12 = ppbStack_a88;
  iVar7 = iStack_cb0;
  func_0x(ppbStack_a88 + 0x13,iStack_cb0);
  if ((_DAT_ != 0) && (bStack_c7e = DAT_ >> 1, (bStack_c7e & 1) != 0)) {
    func_0x(ppbVar12,0,iVar7);
  }
  uStack_ce4 = uStack_ce4 & 0xffff0000;
  ppbStack_cf0 = (byte **)0x0;
code_r0x00102d39:
  lVar13 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar8 = *(longlong *)(lVar13 + 0x100);
  if (lVar8 == 0) {
    (*pcRam0000000000fff9e0)();
    lVar8 = *(longlong *)(lVar13 + 0x100);
  }
  if (*(int *)(lVar8 + 0x22c) != 0) {
    (*pcRam0000000000fff8c0)();
  }
  func_0x(&ppbStack_cf0);
  func_0x(uStack_40 ^ (ulonglong)auStack_d28);
  return;
}

