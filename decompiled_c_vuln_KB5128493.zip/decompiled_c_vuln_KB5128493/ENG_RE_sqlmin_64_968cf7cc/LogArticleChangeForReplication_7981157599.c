
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong param_2,int param_3,ulonglong param_4,
                 longlong param_5)

{
  longlong *plVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  longlong lVar12;
  ulonglong uVar13;
  undefined8 unaff_RBX;
  undefined8 uVar14;
  ulonglong uVar15;
  longlong lVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  longlong lVar19;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [2];
  undefined8 uStackX_10;
  int iStackX_18;
  undefined auStackX_1c [12];
  short asStack_3248 [320];
  short asStack_2fc8 [264];
  short asStack_2db8 [1008];
  longlong lStack_25d8;
  undefined2 uStack_25d0;
  undefined8 uStack_25c8;
  int iStack_25c0;
  undefined auStack_25b8 [16];
  undefined auStack_25a8 [16];
  undefined auStack_2598 [16];
  undefined auStack_2588 [16];
  longlong lStack_2578;
  uint uStack_2570;
  undefined8 uStack_2568;
  undefined8 uStack_2560;
  longlong lStack_2558;
  undefined8 uStack_2550;
  undefined auStack_2548 [16];
  undefined8 uStack_2538;
  undefined4 uStack_2530;
  undefined auStack_252c [1024];
  undefined8 uStack_212c;
  undefined2 uStack_2124;
  undefined4 uStack_2018;
  longlong lStack_78;
  int iStack_70;
  undefined auStack_68 [8];
  undefined8 uStack_60;
  int iStack_58;
  longlong *plStack_50;
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  *(undefined8 *)((longlong)&uStackX_10 + lVar12) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000034e8 + lVar12) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12);
  uVar17 = 0;
  uStack_2550 = 0;
  auStack_2548 = ZEXT816(0);
  uStack_2530 = 0;
  uStack_212c = 0;
  uStack_2124 = 0;
  uStack_2018 = 1;
  lStack_78 = 0;
  iStack_70 = 0;
  lStack_2558 = 0x1a149c0;
  plStack_50 = (longlong *)0x0;
  _auStack_68 = ZEXT816(0);
  iStack_58 = 1;
  uStack_2538 = 0;
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar12) = 0;
  *(undefined4 *)(auStackX_1c + lVar12 + -0x1c) = 0;
  if (param_3 == 0) {
    uVar14 = 0x1a11948;
  }
  else {
    iVar5 = (int)param_4;
    if (iVar5 == 0) {
      uVar14 = 0x1817520;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100123;
      func_0x(auStackX_1c + lVar12,0,0xeec);
      *(int *)((longlong)&iStackX_18 + lVar12) = iVar5;
      if (*(char *)(param_5 + 1) == '8') {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100170;
        iVar3 = func_0x(param_2 & 0xffff,0x1a14c10);
        if (iVar3 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10018e;
          func_0x(0x4977,0x10,3,0x1a14c10);
        }
        else {
          pcVar2 = *(code **)(**(longlong **)
                                (*(longlong *)
                                  ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8)) + 0x90) + 0x1b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001c5;
          uStack_25c8 = (*pcVar2)();
          lStack_25d8 = 0;
          auStack_25b8 = ZEXT816(0);
          auStack_25a8 = ZEXT816(0);
          auStack_2598 = ZEXT816(0);
          auStack_2588 = ZEXT816(0);
          lStack_2578 = 0;
          uStack_2570 = 0;
          uStack_2568 = 0;
          uStack_2560 = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10023a;
          uStack_25d0 = (short)param_2;
          iStack_25c0 = iVar3;
          iVar3 = func_0x(&lStack_25d8,3,1);
          if (iVar3 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100256;
            func_0x(0x49aa,0x10,9,0x1a14c10);
          }
          else {
            lVar16 = *(longlong *)auStack_25b8._8_8_;
            *(longlong *)(&stack0xfffffffffffffff0 + lVar12) = lStack_25d8;
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = uStack_2568;
            pcVar2 = *(code **)(lVar16 + 0x18);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10028a;
            iVar3 = (*pcVar2)(auStack_25b8._8_8_,0,1);
            uVar15 = uVar17;
            while (iVar3 == 0) {
              *(undefined4 *)(auStackX_1c + lVar12 + -0x18) = 0;
              uVar13 = uVar17;
              if (lStack_25d8 == 0) {
LAB_:
                lVar16 = lStack_25d8;
                if (uVar15 < 5) goto LAB_;
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002d0;
                uVar4 = func_0x(&lStack_25d8,0x17b0938,auStackX_1c + lVar12 + -0x18);
                uVar18 = (ulonglong)uVar4;
                if ((ulonglong)uVar4 == *(ulonglong *)((ulonglong)(uVar4 - 1) * 0x58 + lStack_2578))
                {
LAB_:
                  uVar15 = uVar17;
                  if (uVar4 <= uStack_2570) {
                    lVar16 = (ulonglong)(uVar4 - 1) * 0x58 + lStack_2578;
                    uVar15 = *(ulonglong *)(lStack_25d8 + *(longlong *)(lVar16 + 0x10));
                    uVar13 = *(longlong *)(lVar16 + 8) + lStack_25d8;
                    goto LAB_;
                  }
                }
                else {
                  uVar4 = 1;
                  uVar15 = uVar17;
                  if (uStack_2570 != 0) {
                    do {
                      if (uVar18 == *(ulonglong *)((ulonglong)(uVar4 - 1) * 0x58 + lStack_2578))
                      goto LAB_;
                      uVar4 = uVar4 + 1;
                    } while (uVar4 <= uStack_2570);
                  }
                }
LAB_:
                lVar16 = lStack_25d8;
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100373;
                func_0x(&stack0xfffffffffffffffc + lVar12,uVar13,uVar15);
              }
              *(undefined4 *)((longlong)auStackX_8 + lVar12) = 0;
              uVar13 = uVar17;
              if (lVar16 == 0) {
                lVar16 = 0;
LAB_:
                if (uVar15 < 5) goto LAB_;
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100398;
                uVar4 = func_0x(&lStack_25d8,0x1817520,(longlong)auStackX_8 + lVar12);
                uVar18 = (ulonglong)uVar4;
                lVar16 = lStack_25d8;
                if ((ulonglong)uVar4 == *(ulonglong *)((ulonglong)(uVar4 - 1) * 0x58 + lStack_2578))
                {
LAB_:
                  uVar15 = uVar17;
                  if (uVar4 <= uStack_2570) {
                    lVar19 = (ulonglong)(uVar4 - 1) * 0x58 + lStack_2578;
                    uVar15 = *(ulonglong *)(lStack_25d8 + *(longlong *)(lVar19 + 0x10));
                    uVar13 = *(longlong *)(lVar19 + 8) + lStack_25d8;
                    goto LAB_;
                  }
                }
                else {
                  uVar4 = 1;
                  uVar15 = uVar17;
                  if (uStack_2570 != 0) {
                    do {
                      if (uVar18 == *(ulonglong *)((ulonglong)(uVar4 - 1) * 0x58 + lStack_2578))
                      goto LAB_;
                      uVar4 = uVar4 + 1;
                    } while (uVar4 <= uStack_2570);
                  }
                }
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100443;
                func_0x(auStackX_1c + lVar12 + -0x1c,uVar13,uVar15);
              }
              if ((*(int *)(&stack0xfffffffffffffffc + lVar12) == param_3) &&
                 (*(int *)(auStackX_1c + lVar12 + -0x1c) == iVar5)) goto LAB_;
              lVar19 = *(longlong *)auStack_25b8._8_8_;
              *(longlong *)(&stack0xfffffffffffffff0 + lVar12) = lVar16;
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = uStack_2568;
              pcVar2 = *(code **)(lVar19 + 0x18);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100479;
              iVar3 = (*pcVar2)(auStack_25b8._8_8_,0,1);
            }
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1004a5;
            (*_DAT_)(1,0x1bc9ad0,0x1ba34c0,0x220);
LAB_:
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1004b9;
            iVar3 = func_0x((longlong)&iStackX_18 + lVar12,param_4 & 0xffffffff,&lStack_25d8
                                   );
            if (iVar3 == 0) {
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) =
                   *(undefined4 *)(&stack0xfffffffffffffffc + lVar12);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1004dd;
              (*_DAT_)(0xbb,0x38,0x10,5);
            }
            auStack_68._4_4_ = iVar5;
            auStack_68._0_4_ = *(undefined4 *)(&stack0xfffffffffffffffc + lVar12);
            uStack_60 = 0x33;
            iStack_58 = 0;
            plVar1 = *(longlong **)
                      (*(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                      0x90);
            pcVar2 = *(code **)(*plVar1 + 0x288);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100535;
            plStack_50 = (longlong *)(*pcVar2)(plVar1,param_2 & 0xffff);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100544;
            iVar5 = func_0x(plStack_50);
            if (iVar5 == 0) {
              pcVar2 = *(code **)(*plStack_50 + 0x270);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100558;
              (*pcVar2)();
            }
            lVar19 = -1;
            lVar16 = -1;
            do {
              lVar16 = lVar16 + 1;
            } while (asStack_3248[lVar16] != 0);
            uVar4 = (int)lVar16 * 2;
            *(uint *)(&stack0xfffffffffffffff8 + lVar12) = uVar4;
            iVar5 = 1;
            uVar15 = uStack_212c & 0xffffffff;
            uVar13 = uVar17;
            do {
              uVar8 = (uint)uVar13;
              if (3 < uVar8) break;
              uVar6 = 0x400 - (int)uVar15;
              uVar10 = 4 - uVar8;
              if (uVar6 <= 4 - uVar8) {
                uVar10 = uVar6;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1005cf;
              func_0x
                        (auStack_252c + uVar15,&stack0xfffffffffffffff8 + uVar13 + lVar12,uVar10);
              uVar13 = (ulonglong)(uVar8 + uVar10);
              uVar6 = (uint)uStack_212c + uVar10;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar6);
              if (uVar8 + uVar10 != 4) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100616;
                  (*_DAT_)(1,0x1bc8dd0,0x1ba33f0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100629;
                iVar5 = (*pcVar2)(&lStack_2558,0);
                uVar6 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar6;
            } while (iVar5 != 0);
            uVar8 = 1;
            uVar13 = uVar17;
            uVar10 = uVar4;
            while ((uVar10 != 0 && (uVar10 = (uint)uVar13, uVar10 < uVar4))) {
              uVar7 = 0x400 - (int)uVar15;
              uVar6 = uVar4 - uVar10;
              if (uVar7 <= uVar4 - uVar10) {
                uVar6 = uVar7;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10068c;
              func_0x(auStack_252c + uVar15,(longlong)asStack_3248 + uVar13,uVar6);
              uVar13 = (ulonglong)(uVar10 + uVar6);
              uVar7 = (uint)uStack_212c + uVar6;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar7);
              if (uVar4 != uVar10 + uVar6) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006d0;
                  (*_DAT_)(1,0x1bc8dd0,0x1ba33f0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006e3;
                uVar8 = (*pcVar2)(&lStack_2558,0);
                uVar7 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar7;
              uVar10 = uVar8;
            }
            lVar16 = -1;
            do {
              lVar16 = lVar16 + 1;
            } while (asStack_2fc8[lVar16] != 0);
            uVar8 = (int)lVar16 * 2;
            *(uint *)(&stack0xfffffffffffffff8 + lVar12) = uVar8;
            iVar5 = 1;
            uVar13 = uVar17;
            do {
              uVar10 = (uint)uVar13;
              if (3 < uVar10) break;
              uVar7 = 0x400 - (int)uVar15;
              uVar6 = 4 - uVar10;
              if (uVar7 <= 4 - uVar10) {
                uVar6 = uVar7;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100761;
              func_0x
                        (auStack_252c + uVar15,&stack0xfffffffffffffff8 + uVar13 + lVar12,uVar6);
              uVar13 = (ulonglong)(uVar10 + uVar6);
              uVar7 = (uint)uStack_212c + uVar6;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar7);
              if (uVar10 + uVar6 != 4) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1007aa;
                  (*_DAT_)(1,0x1bc8dd0,0x1ba33f0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1007bd;
                iVar5 = (*pcVar2)(&lStack_2558,0);
                uVar7 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar7;
            } while (iVar5 != 0);
            uVar10 = 1;
            uVar13 = uVar17;
            uVar6 = uVar8;
            while ((uVar6 != 0 && (uVar6 = (uint)uVar13, uVar6 < uVar8))) {
              uVar9 = 0x400 - (int)uVar15;
              uVar7 = uVar8 - uVar6;
              if (uVar9 <= uVar8 - uVar6) {
                uVar7 = uVar9;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100820;
              func_0x(auStack_252c + uVar15,(longlong)asStack_2fc8 + uVar13,uVar7);
              uVar13 = (ulonglong)(uVar6 + uVar7);
              uVar9 = (uint)uStack_212c + uVar7;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar9);
              if (uVar8 != uVar6 + uVar7) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100866;
                  (*_DAT_)(1,0x1bc8dd0,0x1ba33f0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100879;
                uVar10 = (*pcVar2)(&lStack_2558,0);
                uVar9 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar9;
              uVar6 = uVar10;
            }
            do {
              lVar19 = lVar19 + 1;
            } while (asStack_2db8[lVar19] != 0);
            uVar10 = (int)lVar19 * 2;
            *(uint *)(&stack0xfffffffffffffff8 + lVar12) = uVar10;
            iVar5 = 1;
            uVar13 = uVar17;
            do {
              uVar6 = (uint)uVar13;
              if (3 < uVar6) break;
              uVar9 = 0x400 - (int)uVar15;
              uVar7 = 4 - uVar6;
              if (uVar9 <= 4 - uVar6) {
                uVar7 = uVar9;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1008ef;
              func_0x
                        (auStack_252c + uVar15,&stack0xfffffffffffffff8 + uVar13 + lVar12,uVar7);
              uVar13 = (ulonglong)(uVar6 + uVar7);
              uVar9 = (uint)uStack_212c + uVar7;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar9);
              if (uVar6 + uVar7 != 4) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100936;
                  (*_DAT_)(1,0x1bc8dd0,0x1ba33f0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100949;
                iVar5 = (*pcVar2)(&lStack_2558,0);
                uVar9 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar9;
            } while (iVar5 != 0);
            uVar6 = 1;
            uVar13 = uVar17;
            uVar7 = uVar10;
            while ((uVar7 != 0 && (uVar7 = (uint)uVar13, uVar7 < uVar10))) {
              uVar11 = 0x400 - (int)uVar15;
              uVar9 = uVar10 - uVar7;
              if (uVar11 <= uVar10 - uVar7) {
                uVar9 = uVar11;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1009ae;
              func_0x(auStack_252c + uVar15,(longlong)asStack_2db8 + uVar13,uVar9);
              uVar13 = (ulonglong)(uVar7 + uVar9);
              uVar11 = (uint)uStack_212c + uVar9;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar11);
              if (uVar10 != uVar7 + uVar9) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1009f3;
                  (*_DAT_)(1,0x1bc8dd0,0x1ba33f0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100a06;
                uVar6 = (*pcVar2)(&lStack_2558,0);
                uVar11 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar11;
              uVar7 = uVar6;
            }
            iVar5 = 1;
            do {
              uVar6 = (uint)uVar17;
              if (3 < uVar6) break;
              uVar9 = 0x400 - (int)uVar15;
              uVar7 = 4 - uVar6;
              if (uVar9 <= 4 - uVar6) {
                uVar7 = uVar9;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100a63;
              func_0x
                        (auStack_252c + uVar15,&stack0x0000003c + uVar17 + lVar12,uVar7);
              uVar17 = (ulonglong)(uVar6 + uVar7);
              uVar9 = (uint)uStack_212c + uVar7;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar9);
              if (uVar6 + uVar7 != 4) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100aaa;
                  (*_DAT_)(1,0x1bc8dd0,0x1ba33f0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100abd;
                iVar5 = (*pcVar2)(&lStack_2558,0);
                uVar9 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar9;
            } while (iVar5 != 0);
            uVar10 = uVar4 + uVar8 + 0x10 + uVar10;
            if (*(uint *)(&stack0x0000003c + lVar12) != 0) {
              lVar16 = *(longlong *)(&stack0x00000040 + lVar12);
              uVar17 = (ulonglong)*(uint *)(&stack0x0000003c + lVar12);
              do {
                if (0x400 < (ulonglong)uVar10 + 4) {
                  uVar10 = 0;
                  if (plStack_50 == (longlong *)0x0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100b14;
                    func_0x(0x4956,0x10,2,0x1a14980);
                  }
                  else {
                    pcVar2 = *(code **)(lStack_2558 + 0x78);
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100b2c;
                    (*pcVar2)(&lStack_2558,1);
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100b44;
                func_0x(&lStack_2558,lVar16,4);
                uVar10 = uVar10 + 4;
                lVar16 = lVar16 + 4;
                uVar17 = uVar17 - 1;
              } while (uVar17 != 0);
            }
            if (plStack_50 == (longlong *)0x0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100b75;
              func_0x(0x4956,0x10,2,0x1a14980);
            }
            else {
              pcVar2 = *(code **)(lStack_2558 + 0x78);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100b8d;
              (*pcVar2)(&lStack_2558,1);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100b9a;
          func_0x(&lStack_25d8);
        }
        goto LAB_;
      }
      uVar14 = 0x18eb1a0;
    }
  }
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = uVar14;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10015b;
  func_0x(0x493e,0x10,2,0x1a17d20);
LAB_:
  lStack_2558 = 0x1a11b78;
  if ((iStack_70 != 0) && (lStack_78 != 0)) {
    pcVar2 = *(code **)(*_DAT_ + 0x28);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100bd9;
    (*pcVar2)();
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100be8;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12));
  return;
}

