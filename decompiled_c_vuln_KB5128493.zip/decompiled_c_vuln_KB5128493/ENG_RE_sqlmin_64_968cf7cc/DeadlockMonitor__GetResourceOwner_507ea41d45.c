
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00100115) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,uint param_2,int param_3,undefined4 *param_4)

{
  longlong *plVar1;
  int *piVar2;
  int iVar3;
  longlong lVar4;
  longlong lVar5;
  int *piVar6;
  ulonglong uStackX_20;
  longlong lStack_70;
  undefined4 uStack_68;
  int iStack_60;
  int iStack_5c;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  
  lVar5 = _DAT_;
  iStack_60 = 0x400000;
  uStack_58 = 0;
  uStack_48 = 0;
  uStack_50 = 0;
  uStack_40 = 0;
  *param_4 = 0;
  if (*(int *)(param_1 + 0xb8) == 0) {
    if (param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lStack_70 = 0;
    uStack_68 = 0;
    iVar3 = func_0x(param_1,&lStack_70,&iStack_60,&uStackX_20);
    if (lStack_70 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar3 != 0) {
      return 0;
    }
  }
  else {
    func_0x(param_1);
    if (param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    piVar6 = (int *)0x0;
    if ((*(longlong *)(param_1 + 0x98) != 0) &&
       (piVar2 = *(int **)(param_1 + 200), piVar6 = (int *)0x0, piVar2 != (int *)0x0)) {
      uStackX_20 = *(ulonglong *)(*(longlong *)(param_1 + 0x98) + 0x88);
      iStack_60 = *piVar2;
      iStack_5c = piVar2[1];
      uStack_58 = *(undefined8 *)(piVar2 + 2);
      uStack_50 = *(undefined8 *)(piVar2 + 4);
      uStack_48 = *(undefined8 *)(piVar2 + 6);
      uStack_40 = *(undefined8 *)(piVar2 + 8);
      lVar4 = (*_DAT_)(piVar2);
      piVar6 = piVar2;
      if (lVar4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if ((ulonglong)param_2 < *(ulonglong *)(param_1 + 0x100)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(param_1);
    if (piVar6 == (int *)0x0) {
      return 0;
    }
  }
  if (param_3 == 0) {
    if (((DAT_ == (char)param_3) && (*(int *)(lVar5 + 0x1b8) == 1)) &&
       (uStackX_20 < *(ulonglong *)(lVar5 + 0x1b0))) {
      plVar1 = (longlong *)(lVar5 + 0x3aba8 + (ulonglong)(ushort)iStack_60 * 0x30);
      *plVar1 = *plVar1 + (*(ulonglong *)(lVar5 + 0x1b0) - uStackX_20);
      plVar1 = (longlong *)(lVar5 + 0x3abc8 + (ulonglong)(ushort)iStack_60 * 0x30);
      *plVar1 = *plVar1 + 1;
    }
  }
  lVar5 = (*_DAT_)(&iStack_60);
  if (lVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iStack_60 != 0) {
    if ((short)((uint)iStack_60 >> 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iStack_60 + 0xfdfffee7U < 4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iStack_60 == 0x400062) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((iStack_60 - 0x40012bU < 2) || (iStack_60 == 0x4000bb)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iStack_60 == 0x4000d5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  return 0;
}

