
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  int *piVar3;
  char cVar4;
  byte bVar5;
  ushort uVar6;
  longlong lVar7;
  short *psVar8;
  undefined8 uVar9;
  longlong lVar10;
  ulonglong *puVar11;
  undefined4 *puVar12;
  longlong lVar13;
  uint uVar14;
  code *UNRECOVERED_JUMPTABLE;
  ushort uVar15;
  longlong lVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  ulonglong *puVar19;
  undefined *puVar20;
  longlong *plVar21;
  ushort *puVar22;
  short sVar23;
  int iVar24;
  longlong *plVar25;
  longlong *plVar26;
  byte *pbVar27;
  byte *pbVar28;
  uint uVar29;
  uint *puVar30;
  undefined4 uVar31;
  uint auStackX_18 [3];
  uint uStackX_24;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  puVar20 = &stack0xffffffffffffffc0 + lVar7;
  uVar1 = (longlong)auStackX_18 + lVar7 + -0x18;
  *(undefined8 *)(&stack0x000002a0 + lVar7) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000023d0 + lVar7) = _DAT_ ^ uVar1;
  *(undefined8 *)(&stack0x00000288 + lVar7) = param_4;
  *(undefined8 *)(&stack0x00000158 + lVar7) = param_3;
  *(longlong *)(&stack0x00000280 + lVar7) = param_1;
  UNRECOVERED_JUMPTABLE = *(code **)*param_2;
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100064;
  cVar4 = (*UNRECOVERED_JUMPTABLE)(param_2);
  if (cVar4 != '\0') {
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100079;
    func_0x(param_1,param_2,param_3,param_4);
    puVar20 = &stack0xffffffffffffffc0 + lVar7;
    goto LAB_;
  }
  lVar13 = *(longlong *)(param_1 + 0x28);
  if (lVar13 == 0) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1000a9;
    (*_DAT_)(1,0x18e5ed8,0x18b90d8,0x240);
    puVar20 = &stack0xffffffffffffffc0 + lVar7;
    goto LAB_;
  }
  lVar16 = param_2[1];
  *(longlong *)(&stack0x000000d8 + lVar7) = lVar16;
  *(undefined8 *)(&stack0x00000168 + lVar7) = 0x14d9b00;
  *(undefined (*) [16])(&stack0x00000170 + lVar7) = ZEXT816(0);
  plVar21 = (longlong *)0x0;
  *(undefined8 *)(&stack0x00000180 + lVar7) = 0;
  *(undefined (*) [16])(&stack0x00000190 + lVar7) = ZEXT816(0);
  *(undefined4 *)(&stack0x000001a0 + lVar7) = 1;
  *(undefined4 *)(&stack0x000001a4 + lVar7) = 1;
  *(undefined8 *)(&stack0x000001a8 + lVar7) = 0;
  *(undefined4 *)(&stack0x000001b0 + lVar7) = 0;
  *(undefined8 *)(&stack0x000001b8 + lVar7) = 0xffffffffffffffff;
  *(uint *)(&stack0x000001c4 + lVar7) = *(uint *)(&stack0x000001c4 + lVar7) & 0xfffffff8;
  *(undefined8 *)(&stack0x000001c8 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000064 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000078 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000080 + lVar7) = 0;
  *(undefined4 *)(&stack0x000000d4 + lVar7) = 0;
  lVar10 = *(longlong *)(param_1 + 0x40);
  uVar15 = *(ushort *)(lVar13 + 0x62);
  *(longlong *)(&stack0x00000050 + lVar7) = lVar13;
  *(uint *)(&stack0x00000060 + lVar7) = (uint)uVar15;
  *(longlong *)(&stack0x00000068 + lVar7) = lVar10;
  *(undefined8 *)(&stack0x00000070 + lVar7) = 0;
  *(undefined8 *)(&stack0x000000a8 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000058 + lVar7) = *(undefined8 *)(lVar13 + 0x70);
  if (lVar16 != 0) {
    lVar2 = **(longlong **)(*(longlong *)(lVar16 + 8) + 0x160);
    *(undefined8 *)(&stack0x00000078 + lVar7) = *(undefined8 *)(lVar2 + 0xa8);
    *(undefined4 *)(&stack0x00000080 + lVar7) = *(undefined4 *)(lVar2 + 0xb0);
  }
  *(undefined4 *)(&stack0x00000064 + lVar7) = 0x10;
  uVar18 = 0x10;
  if (((*(ushort *)(lVar13 + 0x38) & 0x400) != 0) && (lVar10 != 0)) {
    *(undefined4 *)(&stack0x00000064 + lVar7) = 0x12;
    *(undefined8 *)(&stack0x00000090 + lVar7) = 0;
    *(undefined8 *)(&stack0x00000098 + lVar7) = 0;
    *(undefined8 *)(&stack0x00000088 + lVar7) = 0;
    uVar18 = 0x12;
  }
  plVar25 = (longlong *)param_2[3];
  *(longlong **)(&stack0x000000e8 + lVar7) = plVar25;
  if (plVar25 == (longlong *)0x0) {
    *(undefined8 *)(&stack0x000000e8 + lVar7) = 0;
    psVar8 = (short *)param_2[4];
    plVar25 = plVar21;
  }
  else {
    UNRECOVERED_JUMPTABLE = *(code **)*plVar25;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1001da;
    psVar8 = (short *)(*UNRECOVERED_JUMPTABLE)(plVar25);
    uVar18 = (ulonglong)*(uint *)(&stack0x00000064 + lVar7);
    lVar13 = *(longlong *)(&stack0x00000050 + lVar7);
  }
  uVar29 = *(uint *)(param_1 + 0x24);
  if ((uVar29 & 0x10) == 0) {
    uVar14 = (uint)uVar18 & 0xfffffffd;
    uVar18 = (ulonglong)uVar14;
    *(uint *)(&stack0x00000064 + lVar7) = uVar14;
    *(uint *)(&stack0x000000d4 + lVar7) = uVar29 >> 6 & 1;
  }
  uVar29 = 0;
  if ((*(short *)(*(longlong *)(param_1 + 0x28) + 0x3a) == 0) &&
     (*(int *)(*(longlong *)(param_1 + 0x28) + 0x50) == 0)) {
    if ((*(byte *)(lVar13 + 0x30) & 1) != 0) {
      if (*psVar8 == 0) {
        if ((**(byte **)(psVar8 + 4) & 0x10) != 0) {
          uVar29 = (uint)*(ushort *)(*(byte **)(psVar8 + 4) + *(uint *)(psVar8 + 8));
        }
      }
      else {
        uVar29 = (uint)(ushort)psVar8[1];
      }
      if (*(uint *)(lVar13 + 0x18) <= uVar29) {
        *psVar8 = 0;
        uVar15 = *(ushort *)(*(longlong *)(&stack0x00000050 + lVar7) + 0x62);
        *(uint *)(&stack0x00000040 + lVar7) = (uint)uVar15;
        puVar30 = *(uint **)(&stack0x00000058 + lVar7);
        plVar25 = plVar21;
        if (uVar15 != 0) {
          do {
            plVar26 = (longlong *)0x0;
            cVar4 = *(char *)(puVar30 + 0x10);
            if (cVar4 == '\x01') {
              if ((*(byte *)((longlong)puVar30 + 6) & 0x10) == 0) {
                uVar29 = *(byte *)((ulonglong)(*(ushort *)(puVar30 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(psVar8 + 8) + 2 + *(longlong *)(psVar8 + 4))
                         >> ((byte)(*(ushort *)(puVar30 + 1) - 1) & 7) & 1;
              }
              else {
                *(undefined **)(&stack0xffffffffffffffe0 + lVar7) = &stack0x00000224 + lVar7;
                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x101123;
                func_0x(psVar8 + 1,puVar30,1,&stack0x000000f4 + lVar7);
                uVar29 = *(uint *)(&stack0x000000f4 + lVar7);
              }
              if (uVar29 == 0) goto LAB_;
LAB_:
              lVar13 = *(longlong *)(&stack0x00000068 + lVar7);
              if ((*(byte *)(*(longlong *)(puVar30 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar13 = *(longlong *)(&stack0x00000070 + lVar7);
              }
              *(undefined *)(lVar13 + *(longlong *)(puVar30 + 0xc)) = 3;
              plVar26 = plVar25;
            }
            else {
              if (cVar4 == '\x02') {
LAB_:
                uVar15 = *(ushort *)(puVar30 + 0xf);
                if ((*(byte *)((longlong)puVar30 + 6) & 0x10) == 0) {
LAB_:
                  *(uint *)((longlong)&uStackX_24 + lVar7) = (uint)uVar15;
                  plVar26 = (longlong *)((longlong)(int)*puVar30 + *(longlong *)(psVar8 + 4));
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar7) = &stack0x00000144 + lVar7;
                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1011a8;
                  func_0x(psVar8 + 1,puVar30,0,&stack0x00000228 + lVar7);
                  if (*(int *)(&stack0x00000144 + lVar7) != 0) goto LAB_;
                  plVar26 = (longlong *)(*(uint **)(puVar30 + 2) + 1);
                  uVar29 = **(uint **)(puVar30 + 2);
                  if ((uVar15 != 0) && (uVar29 != uVar15)) {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1011ed;
                    (*_DAT_)(1,0x18e2a08,0x18e1408,0x381);
                  }
                  *(uint *)((longlong)&uStackX_24 + lVar7) = uVar29;
                }
                lVar13 = *(longlong *)(&stack0x00000068 + lVar7);
                if ((*(byte *)(*(longlong *)(puVar30 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar13 = *(longlong *)(&stack0x00000070 + lVar7);
                }
                *(undefined *)(lVar13 + *(longlong *)(puVar30 + 0xc)) = 0;
              }
              else {
                if (cVar4 == '\x03') {
                  if ((*(byte *)((longlong)puVar30 + 6) & 0x10) == 0) {
                    uVar29 = *(byte *)((ulonglong)(*(ushort *)(puVar30 + 1) - 1 >> 3) +
                                       (ulonglong)*(uint *)(psVar8 + 8) + 2 +
                                      *(longlong *)(psVar8 + 4)) >>
                             ((byte)(*(ushort *)(puVar30 + 1) - 1) & 7) & 1;
                  }
                  else {
                    *(undefined **)(&stack0xffffffffffffffe0 + lVar7) = &stack0x0000021c + lVar7;
                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100a8a;
                    func_0x(psVar8 + 1,puVar30,1,&stack0x00000154 + lVar7);
                    uVar29 = *(uint *)(&stack0x00000154 + lVar7);
                  }
                  if (uVar29 != 0) goto LAB_;
                }
                else if (cVar4 != '\x04') {
                  if (cVar4 == '\b') {
                    iVar24 = puVar30[0x10] << 0xc;
                    uVar15 = *(ushort *)(puVar30 + 0xf);
                    if ((*puVar30 & 0xc0000000) == 0x80000000) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1009f8;
                      iVar24 = func_0x(psVar8 + 1);
                      if (iVar24 != 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100a13;
                        plVar26 = (longlong *)
                                  func_0x(psVar8 + 0x15,puVar30,
                                                  (longlong)&uStackX_24 + lVar7,
                                                  &stack0x00000218 + lVar7);
                        goto LAB_;
                      }
                      *(undefined4 *)((longlong)&uStackX_24 + lVar7) = 0;
                      uVar15 = *(ushort *)(*(longlong *)(puVar30 + 0x12) + 0x2a);
                    }
                    else {
                      if ((iVar24 < 0) || ((*(byte *)((longlong)puVar30 + 6) & 0x10) != 0)) {
                        *(undefined **)(&stack0xffffffffffffffe0 + lVar7) = &stack0x000000b4 + lVar7
                        ;
                        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100356;
                        func_0x
                                  (psVar8 + 1,puVar30,iVar24 < 0,&stack0x000000b0 + lVar7);
                        if ((iVar24 < 0) && (*(int *)(&stack0x000000b0 + lVar7) != 0)) {
                          *(undefined4 *)((longlong)&uStackX_24 + lVar7) = 0;
                          plVar26 = (longlong *)0x0;
                          goto LAB_;
                        }
                        iVar24 = *(int *)(&stack0x000000b4 + lVar7);
                      }
                      else {
                        *(undefined4 *)(&stack0x000000b0 + lVar7) = 0;
                        iVar24 = 1;
                        *(undefined4 *)(&stack0x000000b4 + lVar7) = 1;
                      }
                      if ((iVar24 == 0) && ((*(byte *)((longlong)puVar30 + 6) & 0x10) != 0)) {
                        puVar12 = *(undefined4 **)(puVar30 + 2);
                        *(undefined4 *)((longlong)&uStackX_24 + lVar7) = *puVar12;
                        plVar26 = (longlong *)(puVar12 + 1);
                      }
                      else if ((int)*puVar30 < 0) {
                        if (*(int *)(psVar8 + 2) == 0) {
                          psVar8[1] = 0;
                          uVar29 = *(uint *)(psVar8 + 8);
                          uVar18 = (ulonglong)uVar29;
                          *(uint *)(psVar8 + 10) = uVar29;
                          pbVar27 = *(byte **)(psVar8 + 4);
                          bVar5 = *pbVar27;
                          if ((bVar5 & 0x10) != 0) {
                            uVar29 = uVar29 + (*(ushort *)(pbVar27 + uVar18) + 7 >> 3) + 2;
                            uVar18 = (ulonglong)uVar29;
                            *(uint *)(psVar8 + 10) = uVar29;
                            bVar5 = *pbVar27;
                          }
                          if ((bVar5 & 0x20) == 0) {
                            *(int *)(psVar8 + 2) = (int)uVar18;
                            psVar8[0xe] = 0;
                            *(uint *)(psVar8 + 0xc) = uVar29;
                          }
                          else {
                            puVar22 = (ushort *)(pbVar27 + uVar18);
                            uVar15 = *puVar22;
                            psVar8[0xe] = uVar15;
                            if (uVar15 == 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1004aa;
                              cVar4 = func_0x(0x1e43f10);
                              if (cVar4 != '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1004b3;
                                lVar13 = func_0x();
                                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1004cd;
                                  cVar4 = func_0x(0x1e43f10);
                                  if (cVar4 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1004e9;
                                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100513;
                                    (*_DAT_)(1,0x1734c98,0x1854968,0x80f);
                                  }
                                }
                              }
                              uVar9 = *(undefined8 *)(psVar8 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100521;
                              func_0x(uVar9,3);
                              uVar15 = psVar8[0xe];
                              uVar29 = *(uint *)(psVar8 + 10);
                            }
                            uVar29 = uVar29 + (uVar15 + 1) * 2;
                            *(uint *)(psVar8 + 0xc) = uVar29;
                            if (0x1f9e < uVar29) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100552;
                              cVar4 = func_0x(0x1e43f10);
                              if (cVar4 != '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10055b;
                                lVar13 = func_0x();
                                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100575;
                                  cVar4 = func_0x(0x1e43f10);
                                  if (cVar4 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100591;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1005bb;
                                    (*_DAT_)(1,0x1734c98,0x1854968,0x816);
                                  }
                                }
                              }
                              uVar9 = *(undefined8 *)(psVar8 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1005c9;
                              func_0x(uVar9,4);
                              uVar15 = psVar8[0xe];
                              uVar29 = *(uint *)(psVar8 + 0xc);
                            }
                            uVar18 = (ulonglong)uVar15;
                            uVar15 = puVar22[uVar18];
                            *(uint *)(psVar8 + 2) = uVar15 & 0x7fff;
                            if ((uVar15 & 0x7fff) < uVar29) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1005f8;
                              cVar4 = func_0x(0x1e43f10);
                              if (cVar4 != '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100601;
                                lVar13 = func_0x();
                                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10061b;
                                  cVar4 = func_0x(0x1e43f10);
                                  if (cVar4 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100637;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100661;
                                    (*_DAT_)(1,0x1734c98,0x1854968,0x81d);
                                  }
                                }
                              }
                              uVar9 = *(undefined8 *)(psVar8 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10066f;
                              func_0x(uVar9,4);
                              uVar18 = (ulonglong)(ushort)psVar8[0xe];
                            }
                            if ((short)puVar22[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
                              do {
                                lVar13 = *(longlong *)(psVar8 + 4);
                                lVar16 = (ulonglong)*(uint *)(psVar8 + 10) + lVar13;
                                if ((int)uVar18 == 1) {
                                  uVar29 = *(uint *)(psVar8 + 0xc);
                                  uVar14 = uVar29;
LAB_:
                                  if ((*(ushort *)(lVar16 + uVar18 * 2) & 0x7fff) < uVar29)
                                  goto LAB_;
                                }
                                else {
                                  uVar29 = *(ushort *)(lVar16 + -2 + uVar18 * 2) & 0x7fff;
                                  uVar14 = *(uint *)(psVar8 + 0xc);
                                  if (uVar14 <= uVar29) goto LAB_;
LAB_:
                                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1006d8;
                                  func_0x(lVar13,7);
                                  uVar14 = *(uint *)(psVar8 + 0xc);
                                }
                                if ((uVar29 < uVar14) || (*(uint *)(psVar8 + 2) < uVar29))
                                goto LAB_;
                                if (*(ushort *)((ulonglong)uVar29 + *(longlong *)(psVar8 + 4)) == 5)
                                {
                                  psVar8[1] = psVar8[1] | 2;
                                  psVar8[0xe] = psVar8[0xe] + -1;
                                  psVar8[0x15] = (short)uVar29;
                                  lVar13 = (ulonglong)(uVar29 & 0xffff) + *(longlong *)(psVar8 + 4);
                                  uVar15 = *(ushort *)(lVar13 + 2);
                                  uVar6 = psVar8[0x16] & 0xc7ff;
                                  if ((uVar15 >> 0xe & 1) != 0) {
                                    uVar6 = uVar15 & 0x3800 | uVar6;
                                  }
                                  psVar8[0x16] = uVar6;
                                  psVar8[0x16] = (uVar6 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar6;
                                  goto LAB_;
                                }
                                if (*(ushort *)((ulonglong)uVar29 + *(longlong *)(psVar8 + 4)) <
                                    0x400) goto LAB_;
                                psVar8[1] = psVar8[1] | 1;
                                uVar15 = psVar8[0xe] - 1;
                                psVar8[0xe] = uVar15;
                                if (uVar15 == 0) goto LAB_;
                                uVar18 = (ulonglong)uVar15;
                              } while ((short)puVar22[(ulonglong)(uVar15 - 1) + 1] < 0);
                              pbVar27 = *(byte **)(psVar8 + 4);
                            }
                            else {
LAB_:
                              pbVar27 = *(byte **)(psVar8 + 4);
                            }
                          }
                          if ((*pbVar27 & 0x40) == 0) {
                            *(undefined4 *)(psVar8 + 0x13) = 0;
                          }
                          else {
                            *(int *)(psVar8 + 0x13) = *(int *)(psVar8 + 2);
                            *(int *)(psVar8 + 2) = *(int *)(psVar8 + 2) + 0xe;
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1007d9;
                            uVar9 = func_0x(psVar8 + 1);
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1007e8;
                            func_0x(uVar9,&stack0x00000230 + lVar7);
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1007f4;
                            iVar24 = func_0x(&stack0x00000230 + lVar7);
                            *(int *)(psVar8 + 2) = *(int *)(psVar8 + 2) + iVar24;
                          }
                          uVar29 = *(uint *)(psVar8 + 2);
                          if ((*(ulonglong *)(psVar8 + 0xf) != 0) &&
                             (*(ulonglong *)(psVar8 + 0xf) <
                              (ulonglong)uVar29 + *(longlong *)(psVar8 + 4))) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10082a;
                            cVar4 = func_0x(0x1e43f10);
                            if (cVar4 != '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100833;
                              lVar13 = func_0x();
                              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10084d;
                                cVar4 = func_0x(0x1e43f10);
                                if (cVar4 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100869;
                                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10088f;
                                  (*_DAT_)(1,0x1734c98,0x1854968,0x877);
                                }
                              }
                            }
                            uVar9 = *(undefined8 *)(psVar8 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10089d;
                            func_0x(uVar9,0x12);
                            uVar29 = *(uint *)(psVar8 + 2);
                          }
                          if (0x3f3b < uVar29 - 1) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1008b7;
                            cVar4 = func_0x(0x1e43f10);
                            if (cVar4 != '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1008c0;
                              lVar13 = func_0x();
                              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1008da;
                                cVar4 = func_0x(0x1e43f10);
                                if (cVar4 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1008f6;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10091c;
                                  (*_DAT_)(1,0x1734c98,0x1854968,0x87c);
                                }
                              }
                            }
                            uVar9 = *(undefined8 *)(psVar8 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10092a;
                            func_0x(uVar9,5);
                          }
                        }
LAB_:
                        sVar23 = -*(short *)puVar30;
                        if ((*(byte *)((longlong)puVar30 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe0 + lVar7) =
                               &stack0x0000014c + lVar7;
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10095a;
                          func_0x(psVar8 + 1,puVar30,0,&stack0x00000214 + lVar7);
                          if (*(int *)(&stack0x0000014c + lVar7) == 0) {
                            puVar12 = *(undefined4 **)(puVar30 + 2);
                            *(undefined4 *)((longlong)&uStackX_24 + lVar7) = *puVar12;
                            plVar26 = (longlong *)(puVar12 + 1);
                            goto LAB_;
                          }
                        }
                        lVar13 = (longlong)sVar23;
                        if ((uint)(ushort)psVar8[0xe] < (uint)(int)sVar23) {
                          *(undefined4 *)((longlong)&uStackX_24 + lVar7) = 0;
                          plVar26 = *(longlong **)(psVar8 + 4);
                        }
                        else {
                          lVar16 = *(longlong *)(psVar8 + 4);
                          lVar10 = (ulonglong)*(uint *)(psVar8 + 10) + lVar16;
                          if (sVar23 == 1) {
                            uVar18 = (ulonglong)*(uint *)(psVar8 + 0xc);
                            uVar14 = *(ushort *)(lVar10 + lVar13 * 2) & 0x7fff;
LAB_:
                            if (uVar14 < (uint)uVar18) goto LAB_;
                          }
                          else {
                            uVar29 = *(ushort *)(lVar10 + -2 + lVar13 * 2) & 0x7fff;
                            uVar18 = (ulonglong)uVar29;
                            uVar14 = *(ushort *)(lVar10 + lVar13 * 2) & 0x7fff;
                            lVar16 = *(longlong *)(psVar8 + 4);
                            if (*(uint *)(psVar8 + 0xc) <= uVar29) goto LAB_;
LAB_:
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1009d5;
                            func_0x(lVar16,7);
                          }
                          *(uint *)((longlong)&uStackX_24 + lVar7) = uVar14 - (int)uVar18;
                          plVar26 = (longlong *)(uVar18 + *(longlong *)(psVar8 + 4));
                        }
                      }
                      else if ((*(ushort *)((longlong)puVar30 + 6) & 8) == 0) {
                        if ((*(ushort *)((longlong)puVar30 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe0 + lVar7) =
                               &stack0x0000013c + lVar7;
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1003ce;
                          func_0x(psVar8 + 1,puVar30,0,&stack0x00000210 + lVar7);
                          if (*(int *)(&stack0x0000013c + lVar7) == 0) {
                            plVar26 = (longlong *)(*(uint **)(puVar30 + 2) + 1);
                            uVar29 = **(uint **)(puVar30 + 2);
                            if ((uVar15 != 0) && (uVar29 != uVar15)) {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100413;
                              (*_DAT_)(1,0x18e2a08,0x18e1408,0x381);
                            }
                            *(uint *)((longlong)&uStackX_24 + lVar7) = uVar29;
                            goto LAB_;
                          }
                        }
                        *(uint *)((longlong)&uStackX_24 + lVar7) = (uint)uVar15;
                        plVar26 = (longlong *)((longlong)(int)*puVar30 + *(longlong *)(psVar8 + 4));
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10043b;
                        plVar26 = (longlong *)func_0x(psVar8 + 1,puVar30);
                      }
LAB_:
                      uVar15 = *(ushort *)(*(longlong *)(puVar30 + 0x12) + 0x2a);
                      if (plVar26 != (longlong *)0x0) {
                        lVar13 = *(longlong *)(&stack0x00000068 + lVar7);
                        if ((uVar15 & 0x10) != 0) {
                          lVar13 = *(longlong *)(&stack0x00000070 + lVar7);
                        }
                        *(undefined *)(lVar13 + *(longlong *)(puVar30 + 0xc)) = 0;
                        goto LAB_;
                      }
                    }
                    lVar13 = *(longlong *)(&stack0x00000068 + lVar7);
                    if ((uVar15 & 0x10) != 0) {
                      lVar13 = *(longlong *)(&stack0x00000070 + lVar7);
                    }
                    *(undefined *)(lVar13 + *(longlong *)(puVar30 + 0xc)) = 3;
                    goto LAB_;
                  }
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0x14b1178;
                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1002eb;
                  (*_DAT_)(1,0x18b5fd0,0x18e2910,0x27d);
                  plVar26 = plVar25;
                  goto LAB_;
                }
                if (*(int *)(psVar8 + 2) == 0) {
                  psVar8[1] = 0;
                  uVar29 = *(uint *)(psVar8 + 8);
                  uVar18 = (ulonglong)uVar29;
                  *(uint *)(psVar8 + 10) = uVar29;
                  pbVar27 = *(byte **)(psVar8 + 4);
                  bVar5 = *pbVar27;
                  pbVar28 = pbVar27;
                  if ((bVar5 & 0x10) != 0) {
                    uVar29 = uVar29 + (*(ushort *)(pbVar27 + uVar18) + 7 >> 3) + 2;
                    uVar18 = (ulonglong)uVar29;
                    *(uint *)(psVar8 + 10) = uVar29;
                    bVar5 = *pbVar27;
                    pbVar28 = *(byte **)(psVar8 + 4);
                  }
                  if ((bVar5 & 0x20) == 0) {
                    *(int *)(psVar8 + 2) = (int)uVar18;
                    psVar8[0xe] = 0;
                    *(uint *)(psVar8 + 0xc) = uVar29;
                  }
                  else {
                    puVar22 = (ushort *)(pbVar27 + uVar18);
                    uVar15 = *puVar22;
                    psVar8[0xe] = uVar15;
                    if (uVar15 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100b38;
                      cVar4 = func_0x(0x1e43f10);
                      if (cVar4 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100b41;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100b5b;
                          cVar4 = func_0x(0x1e43f10);
                          if (cVar4 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100b77;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100ba1;
                            (*_DAT_)(1,0x1734c98,0x1854968,0x80f);
                          }
                        }
                      }
                      uVar9 = *(undefined8 *)(psVar8 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100baf;
                      func_0x(uVar9,3);
                      uVar15 = psVar8[0xe];
                      uVar29 = *(uint *)(psVar8 + 10);
                    }
                    uVar29 = uVar29 + (uVar15 + 1) * 2;
                    *(uint *)(psVar8 + 0xc) = uVar29;
                    if (0x1f9e < uVar29) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100be0;
                      cVar4 = func_0x(0x1e43f10);
                      if (cVar4 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100be9;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100c03;
                          cVar4 = func_0x(0x1e43f10);
                          if (cVar4 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100c1f;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100c49;
                            (*_DAT_)(1,0x1734c98,0x1854968,0x816);
                          }
                        }
                      }
                      uVar9 = *(undefined8 *)(psVar8 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100c57;
                      func_0x(uVar9,4);
                      uVar15 = psVar8[0xe];
                      uVar29 = *(uint *)(psVar8 + 0xc);
                    }
                    uVar18 = (ulonglong)uVar15;
                    uVar15 = puVar22[uVar18];
                    *(uint *)(psVar8 + 2) = uVar15 & 0x7fff;
                    if ((uVar15 & 0x7fff) < uVar29) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100c86;
                      cVar4 = func_0x(0x1e43f10);
                      if (cVar4 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100c8f;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100ca9;
                          cVar4 = func_0x(0x1e43f10);
                          if (cVar4 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100cc5;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100cef;
                            (*_DAT_)(1,0x1734c98,0x1854968,0x81d);
                          }
                        }
                      }
                      uVar9 = *(undefined8 *)(psVar8 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100cfd;
                      func_0x(uVar9,4);
                      uVar18 = (ulonglong)(ushort)psVar8[0xe];
                    }
                    if ((short)puVar22[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
                      do {
                        lVar13 = *(longlong *)(psVar8 + 4);
                        if ((int)uVar18 == 1) {
                          uVar29 = *(uint *)(psVar8 + 0xc);
                          uVar14 = uVar29;
LAB_:
                          if ((*(ushort *)((ulonglong)*(uint *)(psVar8 + 10) + lVar13 + uVar18 * 2)
                              & 0x7fff) < uVar29) goto LAB_;
                        }
                        else {
                          uVar29 = *(ushort *)
                                    ((ulonglong)*(uint *)(psVar8 + 10) + lVar13 + -2 + uVar18 * 2) &
                                   0x7fff;
                          uVar14 = *(uint *)(psVar8 + 0xc);
                          if (uVar14 <= uVar29) goto LAB_;
LAB_:
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100d68;
                          func_0x(lVar13,7);
                          uVar14 = *(uint *)(psVar8 + 0xc);
                          lVar13 = *(longlong *)(psVar8 + 4);
                        }
                        if ((uVar29 < uVar14) || (*(uint *)(psVar8 + 2) < uVar29))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar29 + lVar13) == 5) {
                          psVar8[1] = psVar8[1] | 2;
                          psVar8[0xe] = psVar8[0xe] + -1;
                          psVar8[0x15] = (short)uVar29;
                          lVar13 = (ulonglong)(uVar29 & 0xffff) + *(longlong *)(psVar8 + 4);
                          uVar15 = *(ushort *)(lVar13 + 2);
                          uVar6 = psVar8[0x16] & 0xc7ff;
                          if ((uVar15 >> 0xe & 1) != 0) {
                            uVar6 = uVar15 & 0x3800 | uVar6;
                          }
                          psVar8[0x16] = uVar6;
                          psVar8[0x16] = (uVar6 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar6;
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar29 + lVar13) < 0x400) goto LAB_;
                        psVar8[1] = psVar8[1] | 1;
                        uVar15 = psVar8[0xe] - 1;
                        psVar8[0xe] = uVar15;
                        if (uVar15 == 0) goto LAB_;
                        uVar18 = (ulonglong)uVar15;
                      } while ((short)puVar22[(ulonglong)(uVar15 - 1) + 1] < 0);
                      pbVar28 = *(byte **)(psVar8 + 4);
                    }
                    else {
LAB_:
                      pbVar28 = *(byte **)(psVar8 + 4);
                    }
                  }
                  if ((*pbVar28 & 0x40) == 0) {
                    *(undefined4 *)(psVar8 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar8 + 0x13) = *(int *)(psVar8 + 2);
                    *(int *)(psVar8 + 2) = *(int *)(psVar8 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100e62;
                    uVar9 = func_0x(psVar8 + 1);
                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100e71;
                    func_0x(uVar9,&stack0x00000238 + lVar7);
                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100e7d;
                    iVar24 = func_0x(&stack0x00000238 + lVar7);
                    *(int *)(psVar8 + 2) = *(int *)(psVar8 + 2) + iVar24;
                    pbVar28 = *(byte **)(psVar8 + 4);
                  }
                  uVar29 = *(uint *)(psVar8 + 2);
                  if ((*(byte **)(psVar8 + 0xf) != (byte *)0x0) &&
                     (*(byte **)(psVar8 + 0xf) < pbVar28 + uVar29)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100eb6;
                    cVar4 = func_0x(0x1e43f10);
                    if (cVar4 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100ebf;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100ed9;
                        cVar4 = func_0x(0x1e43f10);
                        if (cVar4 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100ef5;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100f1b;
                          (*_DAT_)(1,0x1734c98,0x1854968,0x877);
                        }
                      }
                    }
                    uVar9 = *(undefined8 *)(psVar8 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100f29;
                    func_0x(uVar9,0x12);
                    uVar29 = *(uint *)(psVar8 + 2);
                  }
                  if (0x3f3b < uVar29 - 1) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100f43;
                    cVar4 = func_0x(0x1e43f10);
                    if (cVar4 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100f4c;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100f66;
                        cVar4 = func_0x(0x1e43f10);
                        if (cVar4 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100f82;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100fa8;
                          (*_DAT_)(1,0x1734c98,0x1854968,0x87c);
                        }
                      }
                    }
                    uVar9 = *(undefined8 *)(psVar8 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100fb6;
                    func_0x(uVar9,5);
                  }
                }
LAB_:
                sVar23 = -*(short *)puVar30;
                if ((*(byte *)((longlong)puVar30 + 6) & 0x10) == 0) {
LAB_:
                  lVar13 = (longlong)sVar23;
                  if ((uint)(ushort)psVar8[0xe] < (uint)(int)sVar23) {
                    *(undefined4 *)((longlong)&uStackX_24 + lVar7) = 0;
                    plVar26 = *(longlong **)(psVar8 + 4);
                    iVar24 = 0;
                  }
                  else {
                    lVar16 = *(longlong *)(psVar8 + 4);
                    lVar10 = (ulonglong)*(uint *)(psVar8 + 10) + lVar16;
                    if (sVar23 == 1) {
                      uVar18 = (ulonglong)*(uint *)(psVar8 + 0xc);
                      uVar29 = *(ushort *)(lVar10 + lVar13 * 2) & 0x7fff;
LAB_:
                      if (uVar29 < (uint)uVar18) goto LAB_;
                    }
                    else {
                      uVar14 = *(ushort *)(lVar10 + -2 + lVar13 * 2) & 0x7fff;
                      uVar18 = (ulonglong)uVar14;
                      uVar29 = *(ushort *)(lVar10 + lVar13 * 2) & 0x7fff;
                      lVar16 = *(longlong *)(psVar8 + 4);
                      if (*(uint *)(psVar8 + 0xc) <= uVar14) goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10105e;
                      func_0x(lVar16,7);
                    }
                    iVar24 = uVar29 - (int)uVar18;
                    *(int *)((longlong)&uStackX_24 + lVar7) = iVar24;
                    plVar26 = (longlong *)(uVar18 + *(longlong *)(psVar8 + 4));
                  }
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar7) = &stack0x000000f0 + lVar7;
                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100fe6;
                  func_0x(psVar8 + 1,puVar30,0,&stack0x00000220 + lVar7);
                  if (*(int *)(&stack0x000000f0 + lVar7) != 0) goto LAB_;
                  piVar3 = *(int **)(puVar30 + 2);
                  iVar24 = *piVar3;
                  *(int *)((longlong)&uStackX_24 + lVar7) = iVar24;
                  plVar26 = (longlong *)(piVar3 + 1);
                }
                if (((puVar30[0x10] & 0x2000) != 0) && (iVar24 == 0)) {
                  *(undefined4 *)((longlong)&uStackX_24 + lVar7) = 4;
                  plVar26 = (longlong *)0x14db03c;
                }
                lVar13 = *(longlong *)(&stack0x00000068 + lVar7);
                if ((*(byte *)(*(longlong *)(puVar30 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar13 = *(longlong *)(&stack0x00000070 + lVar7);
                }
                *(undefined *)(lVar13 + *(longlong *)(puVar30 + 0xc)) = 0;
                if ((1 << (**(byte **)(psVar8 + 4) & 0xe) & 0x440U) != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1010c9;
                  iVar24 = func_0x(puVar30);
                  if (iVar24 != 0) goto LAB_;
                }
                if ((uint)*(ushort *)(puVar30 + 0xf) < *(uint *)((longlong)&uStackX_24 + lVar7)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1010f5;
                  (*_DAT_)(6,0x52,0x16,0x91);
                }
              }
LAB_:
              uVar29 = *(uint *)((longlong)&uStackX_24 + lVar7);
              lVar13 = *(longlong *)(puVar30 + 0x12);
              if ((puVar30[0x10] & 0x800) == 0) {
                lVar16 = *(longlong *)(&stack0x00000068 + lVar7);
                if ((*(byte *)(lVar13 + 0x2a) & 0x10) != 0) {
                  lVar16 = *(longlong *)(&stack0x00000070 + lVar7);
                }
                lVar13 = *(longlong *)(puVar30 + 10);
                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x101244;
                func_0x(lVar16 + lVar13,plVar26);
              }
              else {
                uVar15 = *(ushort *)(lVar13 + 0x2a) & 0x10;
                if (*(int *)(lVar13 + 0x10) == 10) {
                  lVar13 = *(longlong *)(&stack0x00000068 + lVar7);
                  if (uVar15 != 0) {
                    lVar13 = *(longlong *)(&stack0x00000070 + lVar7);
                  }
                  *(longlong **)(lVar13 + *(longlong *)(puVar30 + 10)) = plVar26;
                }
                else {
                  lVar13 = *(longlong *)(&stack0x00000068 + lVar7);
                  if (uVar15 != 0) {
                    lVar13 = *(longlong *)(&stack0x00000070 + lVar7);
                  }
                  uVar9 = *(undefined8 *)(*(longlong *)(puVar30 + 10) + lVar13);
                  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x101270;
                  func_0x(uVar9,plVar26);
                }
              }
              if ((puVar30[0x10] & 0x100) != 0) {
                lVar13 = *(longlong *)(&stack0x00000068 + lVar7);
                if ((*(byte *)(*(longlong *)(puVar30 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar13 = *(longlong *)(&stack0x00000070 + lVar7);
                }
                *(ulonglong *)(lVar13 + *(longlong *)(*(longlong *)(puVar30 + 0x12) + 0x18)) =
                     (ulonglong)uVar29;
              }
            }
LAB_:
            uVar29 = (int)plVar21 + 1;
            plVar21 = (longlong *)(ulonglong)uVar29;
            puVar30 = puVar30 + 0x14;
            plVar25 = plVar26;
          } while (uVar29 < *(uint *)(&stack0x00000040 + lVar7));
        }
        plVar25 = *(longlong **)(&stack0x000000e8 + lVar7);
        goto LAB_;
      }
    }
    if (plVar25 == (longlong *)0x0) {
      *(short **)(&stack0x00000170 + lVar7) = psVar8;
    }
    else {
      *(longlong **)(&stack0x00000178 + lVar7) = plVar25;
      UNRECOVERED_JUMPTABLE = *(code **)*plVar25;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x101334;
      uVar9 = (*UNRECOVERED_JUMPTABLE)(plVar25);
      *(undefined8 *)(&stack0x00000170 + lVar7) = uVar9;
      uVar18 = (ulonglong)*(uint *)(&stack0x00000064 + lVar7);
    }
    if (*psVar8 == 0) {
      *psVar8 = 0;
      puVar20 = &stack0xffffffffffffffc0 + lVar7;
      if (((&stack0x00000064)[lVar7] & 0x10) != 0) {
        iVar24 = *(int *)(&stack0x00000060 + lVar7);
        *(int *)(&stack0x00000040 + lVar7) = iVar24;
        lVar13 = *(longlong *)(&stack0x00000058 + lVar7);
        *(undefined4 *)((longlong)auStackX_18 + lVar7 + 4) = 0;
        puVar20 = &stack0xffffffffffffffc0 + lVar7;
        if (iVar24 != 0) {
          do {
            if (*(byte *)(lVar13 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar13 + 0x40) * 4 + 0x106424) -
                           0x10086b0);
                    /* WARNING: Could not emulate address calculation at 0x0010139f */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar29 = *(uint *)(lVar13 + 0x40);
            if ((uVar29 >> 10 & 1) != 0) {
              lVar16 = *(longlong *)(&stack0x00000068 + lVar7);
              if ((*(byte *)(*(longlong *)(lVar13 + 0x48) + 0x2a) & 0x10) != 0) {
                lVar16 = *(longlong *)(&stack0x00000070 + lVar7);
              }
              *(undefined *)(lVar16 + *(longlong *)(lVar13 + 0x30)) = 3;
              uVar29 = *(uint *)(lVar13 + 0x40);
            }
            if ((uVar29 >> 9 & 1) != 0) {
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar7) =
                   *(undefined4 *)((longlong)auStackX_18 + lVar7 + 8);
              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1033b4;
              func_0x();
            }
            uVar29 = (int)plVar21 + 1;
            plVar21 = (longlong *)(ulonglong)uVar29;
            *(uint *)((longlong)auStackX_18 + lVar7 + 4) = uVar29;
            lVar13 = lVar13 + 0x50;
            puVar20 = &stack0xffffffffffffffc0 + lVar7;
          } while (uVar29 < *(uint *)(&stack0x00000040 + lVar7));
        }
      }
    }
    else if (*(int *)(*(longlong *)(lVar16 + 8) + 0x100) == 2) {
      uVar29 = *(uint *)(lVar13 + 0x34);
      *(uint *)((longlong)auStackX_18 + lVar7 + 4) = uVar29;
      uVar17 = (ulonglong)uVar29 + 0xf;
      if (uVar17 <= uVar29) {
        uVar17 = 0xffffffffffffff0;
      }
      uVar17 = uVar17 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x103ce9;
      func_0x();
      lVar13 = -uVar17;
      *(longlong *)(&stack0x000000e0 + lVar7) = (longlong)auStackX_18 + lVar13 + lVar7 + -0x18;
      puVar20 = &stack0xffffffffffffffc0 + lVar13 + lVar7;
      if ((uVar18 & 0x10) != 0) {
        *(int *)(&stack0x00000138 + lVar7) = *(int *)(&stack0x00000060 + lVar7);
        lVar16 = *(longlong *)(&stack0x00000058 + lVar7);
        *(undefined4 *)(&stack0x00000040 + lVar7) = 0;
        puVar20 = &stack0xffffffffffffffc0 + lVar13 + lVar7;
        if (*(int *)(&stack0x00000060 + lVar7) != 0) {
          do {
            if (*(byte *)(lVar16 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar16 + 0x40) * 4 + 0x106774) -
                           0x10086b0);
                    /* WARNING: Could not emulate address calculation at 0x00103d3e */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar29 = *(uint *)(lVar16 + 0x40);
            if ((uVar29 >> 10 & 1) != 0) {
              lVar10 = *(longlong *)(&stack0x00000068 + lVar7);
              if ((*(byte *)(*(longlong *)(lVar16 + 0x48) + 0x2a) & 0x10) != 0) {
                lVar10 = *(longlong *)(&stack0x00000070 + lVar7);
              }
              *(undefined *)(lVar10 + *(longlong *)(lVar16 + 0x30)) = 3;
              uVar29 = *(uint *)(lVar16 + 0x40);
            }
            if ((uVar29 >> 9 & 1) != 0) {
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar13 + lVar7) =
                   *(undefined4 *)((longlong)auStackX_18 + lVar7);
              *(undefined8 *)((longlong)&uStack_48 + lVar13 + lVar7) = 0x103ebc;
              func_0x(&stack0x00000050 + lVar7);
            }
            iVar24 = *(int *)(&stack0x00000040 + lVar7);
            *(uint *)(&stack0x00000040 + lVar7) = iVar24 + 1U;
            lVar16 = lVar16 + 0x50;
            puVar20 = &stack0xffffffffffffffc0 + lVar13 + lVar7;
          } while (iVar24 + 1U < *(uint *)(&stack0x00000138 + lVar7));
        }
      }
    }
    else {
      if (*psVar8 == -1) {
        *psVar8 = 1;
        uVar18 = (ulonglong)*(uint *)(&stack0x00000064 + lVar7);
      }
      puVar20 = &stack0xffffffffffffffc0 + lVar7;
      if ((uVar18 & 0x10) != 0) {
        uVar29 = *(uint *)(&stack0x00000060 + lVar7);
        lVar13 = *(longlong *)(&stack0x00000058 + lVar7);
        puVar20 = &stack0xffffffffffffffc0 + lVar7;
        if (uVar29 != 0) {
          do {
            if (*(byte *)(lVar13 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar13 + 0x40) * 4 + 0x1065cc) -
                           0x10086b0);
                    /* WARNING: Could not emulate address calculation at 0x0010342e */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar14 = *(uint *)(lVar13 + 0x40);
            if ((uVar14 >> 10 & 1) != 0) {
              lVar16 = *(longlong *)(&stack0x00000068 + lVar7);
              if ((*(byte *)(*(longlong *)(lVar13 + 0x48) + 0x2a) & 0x10) != 0) {
                lVar16 = *(longlong *)(&stack0x00000070 + lVar7);
              }
              *(undefined *)(lVar16 + *(longlong *)(lVar13 + 0x30)) = 3;
              uVar14 = *(uint *)(lVar13 + 0x40);
            }
            if ((uVar14 >> 9 & 1) != 0) {
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar7) =
                   *(undefined4 *)(&stack0x0000003c + lVar7);
              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1035e2;
              func_0x();
            }
            uVar14 = (int)plVar21 + 1;
            plVar21 = (longlong *)(ulonglong)uVar14;
            lVar13 = lVar13 + 0x50;
            puVar20 = &stack0xffffffffffffffc0 + lVar7;
          } while (uVar14 < uVar29);
        }
      }
    }
    plVar25 = *(longlong **)(&stack0x000000e8 + lVar7);
    if (plVar25 != (longlong *)0x0) {
      UNRECOVERED_JUMPTABLE = *(code **)(**(longlong **)(&stack0x00000178 + lVar7) + 8);
      *(undefined8 *)(puVar20 + -8) = 0x103f01;
      (*UNRECOVERED_JUMPTABLE)();
      goto LAB_;
    }
  }
  else {
    *(undefined8 *)(&stack0x00000190 + lVar7) = param_2[2];
    *(undefined **)(&stack0x00000198 + lVar7) = &stack0x00000168 + lVar7;
    *(longlong *)(&stack0x000001a8 + lVar7) = lVar16;
    lVar13 = *(longlong *)(lVar16 + 8);
    lVar16 = lVar13;
    if (*(longlong *)(lVar13 + 0x478) != 0) {
      lVar16 = *(longlong *)(lVar13 + 0x478);
    }
    if ((*(short *)(lVar16 + 0x440) == 0) && (*(short *)(lVar13 + 0xce) == 0)) {
      uVar29 = *(uint *)(&stack0x000001c4 + lVar7);
    }
    else {
      uVar29 = *(uint *)(&stack0x000001c4 + lVar7) | 1;
      *(uint *)(&stack0x000001c4 + lVar7) = uVar29;
    }
    lVar13 = *(longlong *)(&stack0x000001a8 + lVar7);
    if ((0x1f7c < *(uint *)(*(longlong *)(lVar13 + 8) + 0xb0)) &&
       ((*(byte *)(*(longlong *)(lVar13 + 8) + 0x106) & 4) == 0)) {
      uVar29 = uVar29 | 2;
      *(uint *)(&stack0x000001c4 + lVar7) = uVar29;
    }
    *(undefined4 *)(&stack0x000001b0 + lVar7) =
         *(undefined4 *)(*(longlong *)(lVar13 + 0x20) + 0x664);
    *(ulonglong *)(&stack0x000001b8 + lVar7) = (ulonglong)*(uint6 *)(lVar13 + 0x14) << 0x10;
    *(undefined2 *)(&stack0x000001c0 + lVar7) =
         *(undefined2 *)(*(longlong *)(lVar13 + 0x20) + 0x660);
    *(uint *)(&stack0x000001c4 + lVar7) = uVar29 | 4;
    *(undefined8 *)(&stack0x00000400 + lVar7) = 0;
    *(undefined8 *)(&stack0x00000408 + lVar7) = 0;
    *(undefined4 *)(&stack0x00000410 + lVar7) = 0;
    *(undefined8 *)(&stack0x00000418 + lVar7) = 0;
    *(undefined4 *)(&stack0x00000420 + lVar7) = 0;
    if (plVar25 == (longlong *)0x0) {
      *(short **)(&stack0x00000170 + lVar7) = psVar8;
      *(undefined8 *)(&stack0x00000178 + lVar7) = 0;
    }
    else {
      *(undefined8 *)(&stack0x00000170 + lVar7) = 0;
      *(longlong **)(&stack0x00000178 + lVar7) = plVar25;
    }
    lVar13 = *(longlong *)(&stack0x00000050 + lVar7);
    puVar20 = &stack0xffffffffffffffc0 + lVar7;
    plVar26 = plVar21;
    if ((*(byte *)(lVar13 + 0x38) & 8) != 0) {
      plVar26 = (longlong *)(&stack0x00000400 + lVar7);
      uVar15 = *(ushort *)(lVar13 + 0x62);
      *(uint *)(&stack0x00000400 + lVar7) = (uint)uVar15;
      *(undefined4 *)(&stack0x00000420 + lVar7) = 0x1f9e;
      *(undefined **)(&stack0x00000418 + lVar7) = &stack0x00000424 + lVar7;
      uVar17 = (ulonglong)(uint)uVar15 * 0x40;
      uVar18 = uVar17 + 0xf;
      if (uVar18 <= uVar17) {
        uVar18 = 0xffffffffffffff0;
      }
      uVar18 = uVar18 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1062a0;
      func_0x();
      lVar16 = -uVar18;
      puVar20 = &stack0xffffffffffffffc0 + lVar16 + lVar7;
      *(longlong *)(&stack0x00000408 + lVar7) = (longlong)auStackX_18 + lVar16 + lVar7 + -0x18;
      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar7) = 0x1062b6;
      func_0x((longlong)auStackX_18 + lVar16 + lVar7 + -0x18,0);
    }
    *(undefined8 *)(puVar20 + 0x28) = 0;
    *(undefined **)(puVar20 + 0x20) = &stack0x00000150 + lVar7;
    *(undefined8 *)(puVar20 + -8) = 0x1062e1;
    uVar31 = func_0x
                       (&stack0x00000190 + lVar7,&stack0x00000050 + lVar7,plVar26,
                        &stack0x0000020c + lVar7);
    if (*(int *)(&stack0x00000150 + lVar7) == 2) {
      UNRECOVERED_JUMPTABLE = *(code **)(*plVar25 + 0x10);
      *(undefined8 *)(puVar20 + -8) = 0x1062f4;
      uVar31 = (*UNRECOVERED_JUMPTABLE)(plVar25);
    }
    if ((*(byte *)(lVar13 + 0x38) & 8) != 0) {
      *(undefined **)(puVar20 + 0x28) = &stack0x00000050 + lVar7;
      *(undefined8 *)(puVar20 + 0x20) = 0;
      *(undefined8 *)(puVar20 + -8) = 0x106315;
      func_0x(uVar31,0,0,plVar26);
    }
    lVar13 = *(longlong *)(&stack0x00000408 + lVar7);
    if ((lVar13 != 0) && (uVar29 = *(uint *)(&stack0x00000400 + lVar7), uVar29 != 0)) {
      do {
        lVar16 = (longlong)plVar21 * 0x40;
        if ((*(byte *)(lVar13 + 0x18 + lVar16) & 4) != 0) {
          uVar9 = *(undefined8 *)(lVar13 + 0x20 + lVar16);
          *(undefined8 *)(puVar20 + -8) = 0x106358;
          (*_DAT_)(uVar9);
          pbVar27 = (byte *)(*(longlong *)(&stack0x00000408 + lVar7) + 0x18 + lVar16);
          *pbVar27 = *pbVar27 & 0xfb;
          lVar13 = *(longlong *)(&stack0x00000408 + lVar7);
          uVar29 = *(uint *)(&stack0x00000400 + lVar7);
        }
        uVar14 = (int)plVar21 + 1;
        plVar21 = (longlong *)(ulonglong)uVar14;
      } while (uVar14 < uVar29);
    }
LAB_:
    if (plVar25 != (longlong *)0x0) {
      UNRECOVERED_JUMPTABLE = *(code **)(*plVar25 + 8);
      *(undefined8 *)(puVar20 + -8) = 0x1012e3;
      (*UNRECOVERED_JUMPTABLE)(plVar25);
    }
  }
  lVar13 = *(longlong *)(&stack0x00000280 + lVar7);
  if (**(char **)(lVar13 + 0x40) == '\x03') {
    lVar13 = 0;
  }
  else {
    puVar11 = (ulonglong *)(*(char **)(lVar13 + 0x40) + 4);
    puVar19 = *(ulonglong **)(&stack0x00000158 + lVar7);
    if (puVar19 == (ulonglong *)0x0) {
LAB_:
      *(undefined8 *)(puVar20 + -8) = 0x106385;
      puVar12 = (undefined4 *)(*_DAT_)();
      *puVar12 = 0x16;
      *(undefined8 *)(puVar20 + -8) = 0x106391;
      (*_DAT_)();
      puVar19 = *(ulonglong **)(&stack0x00000158 + lVar7);
    }
    else {
      if (puVar11 == (ulonglong *)0x0) {
        *puVar19 = 0;
        goto LAB_;
      }
      *puVar19 = *puVar11;
    }
    lVar16 = *(longlong *)(*(longlong *)(lVar13 + 0x28) + 0x70);
    if ((*(byte *)(lVar13 + 0x24) & 4) == 0) {
      uVar15 = *(ushort *)(lVar16 + 0x3c);
    }
    else {
      lVar16 = *(longlong *)(lVar16 + 0x48);
      if ((*(ushort *)(lVar16 + 0xc) & 0x800) == 0) {
        uVar15 = *(ushort *)(lVar16 + 2);
      }
      else {
        uVar15 = 0x12;
      }
    }
    if ((ulonglong)uVar15 < *puVar19) {
      *(undefined8 *)(puVar20 + -8) = 0x1063e4;
      (*_DAT_)(6,0x52,0x16,0x9c);
    }
    lVar13 = *(longlong *)(lVar13 + 0x40) + 0xc;
  }
  **(longlong **)(&stack0x00000288 + lVar7) = lVar13;
LAB_:
  uVar18 = *(ulonglong *)(&stack0x000023d0 + lVar7);
  *(undefined8 *)(puVar20 + -8) = 0x10640f;
  func_0x(uVar18 ^ uVar1);
  return;
}

