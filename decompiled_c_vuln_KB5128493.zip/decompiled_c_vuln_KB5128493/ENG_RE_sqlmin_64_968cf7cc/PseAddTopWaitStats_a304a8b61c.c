
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_(longlong param_1,longlong param_2)

{
  byte bVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined auVar4 [16];
  undefined auVar5 [16];
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  uint uVar9;
  longlong lVar10;
  undefined8 uVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  undefined4 *puVar14;
  undefined4 *puVar15;
  ushort *puVar16;
  undefined4 *puVar17;
  undefined4 *puVar18;
  ulonglong uVar19;
  uint uVar20;
  longlong lVar21;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_e8;
  undefined8 *puStack_e0;
  longlong lStack_d8;
  ulonglong uStack_d0;
  undefined8 *puStack_c8;
  longlong lStack_c0;
  undefined4 *puStack_b8;
  undefined4 uStack_a8;
  undefined8 *puStack_a0;
  undefined4 *puStack_98;
  undefined4 *puStack_90;
  undefined8 uStack_88;
  longlong lStack_80;
  undefined8 uStack_78;
  undefined4 *puStack_70;
  undefined4 *puStack_68;
  undefined4 *apuStack_60 [4];
  
  uStack_88 = 0xfffffffffffffffe;
  if ((*(int *)(*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)_DAT_ * 8)
               + 4) < _DAT_) &&
     (func_0x(&DAT_), _DAT_ == -1)) {
    _DAT_ = 0x11c;
    _DAT_ = 0x61;
    _DAT_ = 0x100;
    _DAT_ = 0xd9;
    _DAT_ = 0xdb;
    _DAT_ = 0xda;
    _DAT_ = 0xa9;
    _DAT_ = 0x1ae;
    _DAT_ = 0x13c;
    _DAT_ = 0x13d;
    _DAT_ = 0x79;
    _DAT_ = 0x2c6;
    _DAT_ = 0x1d7;
    _DAT_ = 0xab;
    _DAT_ = 0x7b;
    _DAT_ = 299;
    _DAT_ = 0xd5;
    _DAT_ = 0x13b;
    _DAT_ = 0xb8;
    _DAT_ = 0x60;
    _DAT_ = 0xc9;
    _DAT_ = 0x127;
    _DAT_ = 0x10d;
    _DAT_ = 0x132;
    _DAT_ = 0x2bd;
    _DAT_ = 0xd3;
    _DAT_ = 0xd8;
    _DAT_ = 0xe8;
    _DAT_ = 0xd4;
    _DAT_ = 0x108;
    _DAT_ = 0xfe;
    _DAT_ = 0xbd;
    _DAT_ = 0x369;
    _DAT_ = 0x35a;
    _DAT_ = 0x32a;
    _DAT_ = 0x421;
    _DAT_ = 0x448;
    _DAT_ = 0x3dd;
    func_0x(&DAT_);
  }
  lVar21 = *(longlong *)(param_2 + 0x178);
  if (((lVar21 == 0) || ((*(byte *)(lVar21 + 0x410) & 2) == 0)) ||
     (lVar21 = *(longlong *)(lVar21 + 0x498), lVar21 == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar10 = *(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            0x100);
  if (lVar10 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lStack_d8 = lVar21;
  lVar10 = (*_DAT_)(0x13890,*(undefined8 *)(lVar10 + 1000),0x241ac68,0x4d8,1);
  lStack_c0 = lVar10;
  lStack_80 = lVar10;
  func_0x(lVar10,0,0x13890);
  uVar9 = (*_DAT_)(**(undefined8 **)(param_2 + 0x60),lVar10);
  puVar18 = (undefined4 *)0x0;
  puVar15 = puVar18;
  if (uVar9 != 0) {
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar10 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    puStack_e0 = (undefined8 *)0x0;
    if (10 < uVar9) {
      uVar9 = 10;
    }
    lVar2 = *(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             0x100);
    if (lVar2 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_e8 = (ulonglong)uVar9;
    uVar19 = CONCAT44(0,uVar9 + 1);
    auVar4._8_8_ = 0;
    auVar4._0_8_ = uVar19;
    uVar11 = SUB168(ZEXT816(0x10) * auVar4,0);
    if (SUB168(ZEXT816(0x10) * auVar4,8) != 0) {
      uVar11 = 0xffffffffffffffff;
    }
    puStack_e0 = (undefined8 *)
                 (*_DAT_)(uVar11,*(undefined8 *)(lVar2 + 1000),0x2432bb8,0x2c,1);
    if (puStack_e0 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar12 = puStack_e0;
    for (; uVar19 != 0; uVar19 = uVar19 - 1) {
      *puVar12 = 0;
      *(undefined4 *)(puVar12 + 1) = 0;
      puVar12 = puVar12 + 2;
    }
    lVar21 = lVar21 + 0x20;
    uVar9 = uStack_e8._4_4_;
    puVar14 = puVar18;
    do {
      if (*(longlong *)((lVar10 - lStack_d8) + lVar21) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar20 = (int)puVar14 + 1;
      puVar14 = (undefined4 *)(ulonglong)uVar20;
      lVar21 = lVar21 + 0x30;
    } while (uVar20 < 0x682);
    if (uStack_e8._4_4_ != 0) {
      puStack_a0 = (undefined8 *)0x0;
      lVar21 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 0x100);
      if (lVar21 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar19 = CONCAT44(0,uStack_e8._4_4_);
      auVar5._8_8_ = 0;
      auVar5._0_8_ = uVar19;
      uVar11 = SUB168(ZEXT816(0x10) * auVar5,0);
      if (SUB168(ZEXT816(0x10) * auVar5,8) != 0) {
        uVar11 = 0xffffffffffffffff;
      }
      uStack_d0 = uVar19;
      puVar12 = (undefined8 *)
                (*_DAT_)(uVar11,*(undefined8 *)(lVar21 + 1000),0x2432bb8,0x43,1);
      if (puVar12 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar13 = puVar12;
      if (uVar9 != 0) {
        do {
          *puVar13 = 0;
          *(undefined4 *)(puVar13 + 1) = 0;
          puVar13 = puVar13 + 2;
          uVar19 = uVar19 - 1;
        } while (uVar19 != 0);
      }
      puStack_c8 = puVar12;
      puStack_a0 = puVar12;
      if (uVar9 != 0) {
        do {
          puVar14 = (undefined4 *)func_0x(&uStack_e8,apuStack_60);
          uVar6 = puVar14[1];
          uVar7 = puVar14[2];
          uVar8 = puVar14[3];
          puVar13 = puVar12 + (ulonglong)((uVar9 - (int)puVar15) - 1) * 2;
          *(undefined4 *)puVar13 = *puVar14;
          *(undefined4 *)((longlong)puVar13 + 4) = uVar6;
          *(undefined4 *)(puVar13 + 1) = uVar7;
          *(undefined4 *)((longlong)puVar13 + 0xc) = uVar8;
          uVar20 = (int)puVar15 + 1;
          puVar15 = (undefined4 *)(ulonglong)uVar20;
        } while (uVar20 < uVar9);
      }
      uVar11 = *(undefined8 *)(param_1 + 0x18);
      uStack_78 = uVar11;
      puVar15 = (undefined4 *)(*_DAT_)(0x90,uVar11,0x241ac68,0x537,1);
      if (puVar15 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *puVar15 = 0x1c8;
      *(undefined2 *)(puVar15 + 1) = 0x101;
      *(undefined8 *)(puVar15 + 2) = 0;
      *(undefined8 *)(puVar15 + 4) = *(undefined8 *)(param_1 + 0x18);
      puVar15[6] = 0;
      *(undefined8 *)(puVar15 + 0x20) = 0;
      *(undefined8 *)(puVar15 + 0x22) = 0;
      puStack_90 = puVar15;
      if (uVar9 != 0) {
        do {
          lVar21 = *(longlong *)(lStack_c0 + 0x20 + (ulonglong)*(uint *)(puVar12 + 1) * 0x30);
          lVar10 = *(longlong *)(lStack_d8 + 0x20 + (ulonglong)*(uint *)(puVar12 + 1) * 0x30);
          puVar16 = (ushort *)(*_DAT_)();
          puVar14 = (undefined4 *)(*_DAT_)(0x90,uVar11,0x241ac68,0x53e,1);
          if (puVar14 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *puVar14 = 0x177;
          *(undefined2 *)(puVar14 + 1) = 0x101;
          *(undefined8 *)(puVar14 + 2) = 0;
          *(undefined8 *)(puVar14 + 4) = *(undefined8 *)(param_1 + 0x18);
          puVar14[6] = 0;
          *(undefined8 *)(puVar14 + 0x20) = 0;
          *(undefined8 *)(puVar14 + 0x22) = 0;
          puStack_98 = puVar14;
          puStack_70 = puVar14;
          puStack_68 = (undefined4 *)(*_DAT_)(0x18,uVar11,0x241ac68,0x53f,1);
          if (puStack_68 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *puStack_68 = 0x178;
          uVar19 = 0xffffffffffffffff;
          do {
            uVar19 = uVar19 + 1;
          } while (puVar16[uVar19] != 0);
          bVar1 = *(byte *)(puStack_68 + 5);
          *(ushort **)(puStack_68 + 2) = puVar16;
          puStack_68[4] = (uint)uVar19 * 2;
          *(byte *)(puStack_68 + 5) = bVar1 & 0xfc | 1;
          uVar20 = (uint)uVar19 & 0x7fffffff;
          puVar17 = puVar18;
          uVar9 = 0;
          if ((uVar19 & 0x7fffffff) != 0) {
            do {
              uVar9 = (uint)puVar17;
              if ((*puVar16 & 0xff00) != 0) break;
              uVar9 = uVar9 + 1;
              puVar16 = puVar16 + 1;
              puVar17 = (undefined4 *)(ulonglong)uVar9;
            } while (uVar9 < uVar20);
          }
          if (uVar20 <= uVar9) {
            *(byte *)(puStack_68 + 5) = bVar1 & 0xfc | 3;
          }
          func_0x(puVar14);
          apuStack_60[0] = (undefined4 *)(*_DAT_)(0x18,uVar11,0x241ac68,0x540,1);
          if (apuStack_60[0] == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar3 = *puVar12;
          *apuStack_60[0] = 0x1c6;
          *(undefined8 *)(apuStack_60[0] + 2) = uVar3;
          func_0x(puVar14);
          uStack_a8 = 0x541;
          puStack_b8 = (undefined4 *)(*_DAT_)(0x18,uVar11,0x241ac68,0x541,1);
          if (puStack_b8 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *puStack_b8 = 0x1c7;
          *(longlong *)(puStack_b8 + 2) = lVar21 - lVar10;
          func_0x(puVar14,puStack_b8);
          puStack_98 = (undefined4 *)0x0;
          func_0x(puVar15,puVar14);
          (*_DAT_)(0,0x90);
          puVar12 = puVar12 + 2;
          uStack_d0 = uStack_d0 - 1;
        } while (uStack_d0 != 0);
        uStack_d0 = 0;
        puVar12 = puStack_c8;
      }
      puStack_90 = (undefined4 *)0x0;
      (*_DAT_)(0,0x90);
      (*_DAT_)(puVar12);
    }
    (*_DAT_)(puStack_e0);
    lVar10 = lStack_c0;
  }
  (*_DAT_)(lVar10);
  return puVar15;
}

