
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,ulonglong param_2,undefined2 param_3)

{
  char cVar1;
  longlong lVar2;
  int iVar3;
  longlong lVar4;
  undefined auStack_118 [32];
  undefined4 uStack_f8;
  undefined2 uStack_f0;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_118;
  lVar4 = ((longlong)
           ((param_2 - param_1[0x88]) +
           (ulonglong)(ushort)((longlong)(param_2 - param_1[0x88]) >> 0x3f)) >> 0x10) * 0x155 +
          (param_2 & 0xffff) / 0xc0;
  lVar4 = (param_1[2] + 0x12a9 + lVar4 * 2 & 0xfffffffffffff000U) -
          (param_1[2] + 0xfff + lVar4 * 2 & 0xfffffffffffff000U);
  iVar3 = *_DAT_;
  if (iVar3 == 1) {
    cVar1 = (*_DAT_)(_DAT_);
    iVar3 = (cVar1 != '\0') + 2;
  }
  if (iVar3 - 1U < 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_f8 = 4;
  uStack_f0 = param_3;
  lVar2 = (*_DAT_)(*param_1,param_2,0x10000,0x1000);
  if (lVar2 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((longlong)((ulonglong)((uint)(lVar4 >> 0x3f) & 0xfff) + lVar4) >> 0xc == 0) {
    func_0x(uStack_48 ^ (ulonglong)auStack_118);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

