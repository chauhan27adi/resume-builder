
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong *param_1)

{
  short sVar1;
  ushort uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined4 *puVar7;
  undefined8 uVar8;
  longlong lVar9;
  ulonglong uVar10;
  ushort *puVar11;
  uint uVar12;
  longlong *plVar13;
  longlong unaff_GS_OFFSET;
  longlong unaff_retaddr;
  undefined auStackX_8 [8];
  longlong lStack_18;
  undefined2 uStack_10;
  
  *(undefined4 *)((longlong)param_1 + (ulonglong)(*(uint *)(param_1 + 0x46) & 0x3f) * 4 + 0x130) = 7
  ;
  uVar10 = (ulonglong)*(byte *)(param_1 + 0x347);
  param_1[0x46] = param_1[0x46] + 1;
  plVar13 = param_1 + uVar10 * 3;
  lVar6 = func_0x();
  plVar13[0x47] = lVar6;
  param_1[uVar10 * 3 + 0x48] = unaff_retaddr;
  plVar13[0x49] = 0x298;
  param_1[0x347] = param_1[0x347] + 1;
  func_0x(param_1);
  lVar6 = 0;
  do {
    while( true ) {
      plVar13 = (longlong *)param_1[0x355];
      if (plVar13 == (longlong *)0x0) {
        uVar12 = (uint)*(byte *)((longlong)param_1 + 0x22);
      }
      else {
        uVar12 = *(uint *)((longlong)plVar13 + 0x3cc);
      }
      if (uVar12 == 3) {
        return 0;
      }
      if (uVar12 == 2) {
        sVar1 = *(short *)(param_1 + 4);
        uVar2 = sVar1 - 1;
        *(ushort *)(param_1 + 4) = uVar2;
        if (uVar2 != 0) {
          puVar11 = (ushort *)param_1[7];
          goto LAB_;
        }
        *(short *)(param_1 + 4) = sVar1;
      }
      if (plVar13 == (longlong *)0x0) {
        (**(code **)(*param_1 + 0xa8))(param_1);
      }
      else {
        puVar7 = (undefined4 *)(**(code **)(*plVar13 + 0x38))(plVar13,_DAT_,0,0,0);
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        *(undefined4 *)(param_1 + 7) = *puVar7;
        *(undefined4 *)((longlong)param_1 + 0x3c) = uVar3;
        *(undefined4 *)(param_1 + 8) = uVar4;
        *(undefined4 *)((longlong)param_1 + 0x44) = uVar5;
        if (uVar12 != 1) {
          puVar7 = (undefined4 *)
                   (**(code **)(*(longlong *)param_1[0x355] + 0x60))
                             ((longlong *)param_1[0x355],auStackX_8);
          uVar3 = puVar7[1];
          *(undefined4 *)(param_1 + 3) = *puVar7;
          *(undefined4 *)((longlong)param_1 + 0x1c) = uVar3;
          *(undefined2 *)(param_1 + 4) = 0;
        }
        if ((((*(char *)(param_1 + 8) != '\0') && (*(short *)(param_1 + 10) == 0)) &&
            (*(int *)(param_1 + 9) == 0)) &&
           ((*(int *)((longlong)param_1 + 0x4c) == 0 && (lVar9 = param_1[7], lVar9 != 0)))) {
          param_1[9] = *(longlong *)(lVar9 + 0xc);
          *(undefined2 *)(param_1 + 10) = *(undefined2 *)(lVar9 + 0x14);
          *(short *)(param_1 + 10) = *(short *)(lVar9 + 2) + 1;
        }
      }
      puVar11 = (ushort *)param_1[7];
      if (puVar11 != (ushort *)0x0) break;
      plVar13 = (longlong *)param_1[0x355];
      if (plVar13 == (longlong *)0x0) {
        *(undefined *)((longlong)param_1 + 0x22) = 3;
        param_1[5] = 0;
      }
      else {
        (**(code **)(*plVar13 + 0x30))(plVar13,1);
        param_1[5] = 0;
      }
    }
    if (uVar12 == 1) {
      if (param_1[0x355] == 0) {
        *(undefined *)((longlong)param_1 + 0x22) = 2;
      }
      if (puVar11[1] != 0) {
        if (puVar11[1] < *(ushort *)(param_1 + 4)) {
          lVar9 = func_0x();
          if (lVar9 == 0) {
            lVar9 = *(longlong *)
                     ((ulonglong)*_DAT_ + 8 +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
            if (((lVar9 == 0) || (*(longlong *)(lVar9 + 0x60) == 0)) ||
               (*(char *)(*(longlong *)
                           (*(longlong *)
                             ((ulonglong)*_DAT_ + 8 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              )) + 0x60) + 0x49f) == '\0')) {
              (*_DAT_)(1,0x11b2670,0x116fb70,0xed5,0);
            }
          }
          plVar13 = (longlong *)param_1[0x355];
          if (plVar13 == (longlong *)0x0) {
            *(undefined *)((longlong)param_1 + 0x22) = 3;
          }
          else {
            (**(code **)(*plVar13 + 0x30))(plVar13,1);
          }
          uStack_10 = *(undefined2 *)(param_1 + 4);
          lStack_18 = param_1[3];
          param_1[5] = 0;
          lVar9 = *(longlong *)(*(longlong *)(param_1[2] + 8) + 0x6b0);
          (*_DAT_)(0x5a,3,0x14,8,&lStack_18,*(undefined4 *)(lVar9 + 0x3a0),lVar9 + 0x3a8);
          puVar11 = (ushort *)param_1[7];
        }
        uVar2 = *(ushort *)(param_1 + 4);
LAB_:
        param_1[5] = (ulonglong)
                     *(ushort *)((longlong)puVar11 + (ulonglong)puVar11[2] + (ulonglong)uVar2 * -2)
                     + (longlong)puVar11;
        if (3 < *puVar11) {
          lVar6 = *(longlong *)(puVar11 + 0x10);
        }
        param_1[6] = lVar6;
                    /* WARNING: Could not recover jumptable at 0x001001f4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar8 = (**(code **)(*param_1 + 0x20))(param_1);
        return uVar8;
      }
    }
    *(ushort *)(param_1 + 4) = puVar11[1] + 1;
  } while( true );
}

