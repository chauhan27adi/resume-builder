
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2)

{
  undefined2 uVar1;
  longlong lVar2;
  undefined auVar3 [16];
  char cVar4;
  int iVar5;
  uint uVar6;
  longlong lVar7;
  undefined8 uVar8;
  undefined4 *puVar9;
  longlong lVar10;
  longlong lVar11;
  ulonglong uVar12;
  longlong unaff_GS_OFFSET;
  undefined auStack_1f8 [32];
  undefined8 uStack_1d8;
  undefined8 uStack_1d0;
  ulonglong uStack_1c8;
  undefined8 uStack_1c0;
  undefined4 uStack_1b8;
  int aiStack_1a8 [2];
  uint auStack_1a0 [2];
  undefined4 auStack_198 [2];
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 auStack_180 [2];
  undefined8 uStack_178;
  undefined4 uStack_170;
  undefined auStack_168 [16];
  undefined auStack_158 [16];
  undefined auStack_148 [16];
  undefined auStack_138 [16];
  undefined auStack_128 [16];
  undefined auStack_118 [16];
  undefined8 uStack_108;
  undefined8 uStack_f8;
  undefined auStack_f0 [16];
  undefined auStack_e0 [16];
  undefined auStack_d0 [24];
  longlong lStack_b8;
  undefined2 uStack_b0;
  undefined8 uStack_a8;
  int iStack_a0;
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  longlong lStack_58;
  uint uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  
  uStack_f8 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_1f8;
  lVar2 = *(longlong *)
           ((ulonglong)*_DAT_ + 8 +
           *(longlong *)((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)));
  lVar11 = *(longlong *)((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)) +
           (ulonglong)*_DAT_;
  lVar7 = *(longlong *)(lVar11 + 0x100);
  auStack_198[0] = param_2;
  if (lVar7 == 0) {
    (*_DAT_)(0);
    lVar7 = *(longlong *)(lVar11 + 0x100);
  }
  lVar7 = *(longlong *)(lVar7 + 600);
  uStack_178 = 0;
  uStack_170 = 1;
  auStack_168 = ZEXT816(0);
  uStack_190 = 0;
  aiStack_1a8[0] = 0;
  if ((lVar2 == 0) || (lVar7 == 0)) {
    uStack_1d8 = 0;
    (*_DAT_)(1,0x1c00400,0x1bda9c0,0x395);
  }
  if (*(longlong *)(param_1 + 0x28) != 0) {
    uStack_1d8 = 0;
    (*_DAT_)(1,0x1c003e8,0x1bda9c0,0x396);
  }
  uVar1 = *(undefined2 *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x50) + 8);
  uStack_170 = 1;
  auStack_168._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  cVar4 = (**(code **)(*(longlong *)auStack_168._0_8_ + 0x1d0))();
  if (cVar4 == '\0') {
    uStack_1b8 = 0;
    uStack_1c0 = 0;
    uStack_1c8 = uStack_1c8 & 0xffffffffffffff00;
    uStack_1d0 = (undefined8 *)CONCAT44(uStack_1d0._4_4_,2);
    uStack_1d8 = CONCAT44(uStack_1d8._4_4_,1);
    (**(code **)(*(longlong *)auStack_168._0_8_ + 8))(auStack_168._0_8_,0x1a4c140,0x20,1);
    uStack_178 = CONCAT44(uStack_178._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_168._0_8_ + 0xe8))
              (auStack_168._0_8_,1,1,(longlong)&uStack_178 + 4);
    uStack_170 = 1;
    uStack_178 = CONCAT44(uStack_178._4_4_,4);
  }
  iVar5 = func_0x(uVar1,0x1a4c0c8);
  if (iVar5 == 0) {
    func_0x(0x4977,0x10,1,0x1a4c0c8);
  }
  else {
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0xb70) = 0;
    uStack_a8 = (**(code **)(*(longlong *)auStack_168._0_8_ + 0x1b0))();
    lStack_b8 = 0;
    auStack_98 = ZEXT816(0);
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    auStack_68 = ZEXT816(0);
    lStack_58 = 0;
    uStack_50 = 0;
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_b0 = uVar1;
    iStack_a0 = iVar5;
    iVar5 = func_0x(&lStack_b8,3,1);
    if (iVar5 == 0) {
      func_0x(0x49aa,0x10,2,0x1a4c0f8);
    }
    else {
      auStack_1a0[0] = 4;
      auStack_d0._0_4_ = func_0x(&lStack_b8,0x17ec9d8,auStack_1a0);
      auStack_f0 = ZEXT816(0);
      auStack_e0 = ZEXT816(0);
      auStack_d0._4_12_ = SUB1612(ZEXT816(0),4);
      uStack_108 = 0;
      auStack_118 = ZEXT416(auStack_1a0[0]) << 0x40;
      auStack_148 = ZEXT816(0);
      auStack_158 = ZEXT416((uint)auStack_d0._0_4_);
      auStack_128._0_12_ = ZEXT412(1) << 0x40;
      auStack_128._12_4_ = 0;
      auStack_138._8_8_ = 0;
      auStack_138._0_8_ = auStack_f0;
      uStack_1c8 = 0;
      uStack_1d0 = &uStack_40;
      uStack_1d8 = 0;
      (**(code **)(*(longlong *)auStack_88._8_8_ + 0x20))(auStack_88._8_8_,2,1,auStack_158);
      uStack_1c8 = uStack_1c8 & 0xffffffff00000000;
      uStack_1d0 = (undefined8 *)auStack_198;
      uStack_1d8 = 1;
      (**(code **)(*(longlong *)auStack_78._8_8_ + 0x28))(auStack_78._8_8_,uStack_40,1,auStack_198);
      uStack_1d0 = (undefined8 *)lStack_b8;
      lVar2 = (longlong)uStack_1d0;
      while( true ) {
        uStack_1d0 = (undefined8 *)lVar2;
        uStack_1d8 = uStack_48;
        iVar5 = (**(code **)(*(longlong *)auStack_98._8_8_ + 0x18))(auStack_98._8_8_,0,1,0);
        if (iVar5 != 0) break;
        if (((*(uint *)(lVar7 + 0xbc) & 4) != 0) &&
           ((iVar5 = func_0x(), iVar5 != 0 ||
            (((lVar2 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
              lVar2 != 0 && (*(char *)(*(longlong *)(lVar2 + 0x38) + 8) != '\0')) &&
             (iVar5 = func_0x(), iVar5 == 0)))))) goto LAB_;
        uStack_18c = 0;
        lVar2 = lStack_b8;
        if (lStack_b8 != 0) {
          uVar6 = func_0x(&lStack_b8,0x17e6ef0,&uStack_18c);
          uVar12 = (ulonglong)uVar6;
          if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_58)) {
LAB_:
            lVar2 = lStack_b8;
            if (uVar6 <= uStack_50) {
              lVar11 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_58;
              lVar2 = lStack_b8;
              if (((*(longlong *)(lVar11 + 8) + lStack_b8 != 0) &&
                  (lVar2 = lStack_b8, *(longlong *)(lStack_b8 + *(longlong *)(lVar11 + 0x10)) == 4))
                 && (lVar2 = lStack_b8, *(int *)(lStack_b8 + *(longlong *)(lVar11 + 0x18)) != 3)) {
                *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
                uStack_188 = 0;
                lVar2 = lStack_b8;
                if (lStack_b8 != 0) {
                  uVar6 = func_0x(&lStack_b8,0x1a4c0a0,&uStack_188);
                  lVar2 = lStack_b8;
                  uVar12 = (ulonglong)uVar6;
                  if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_58))
                  {
LAB_:
                    if (uVar6 <= uStack_50) {
                      lVar11 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_58;
                      uVar12 = *(ulonglong *)(lStack_b8 + *(longlong *)(lVar11 + 0x10));
                      lVar10 = *(longlong *)(lVar11 + 8) + lStack_b8;
                      if (((lVar10 != 0) && (uVar12 - 1 < 4)) &&
                         ((*(int *)(lStack_b8 + *(longlong *)(lVar11 + 0x18)) != 3 &&
                          (func_0x(aiStack_1a8,lVar10,uVar12 & 0xffffffff),
                          aiStack_1a8[0] == 0)))) {
                        *(int *)(param_1 + 0xb70) = *(int *)(param_1 + 0xb70) + 1;
                        uStack_1d0 = (undefined8 *)lVar2;
                        lVar2 = (longlong)uStack_1d0;
                      }
                    }
                  }
                  else {
                    uVar6 = 1;
                    if (uStack_50 != 0) {
                      do {
                        if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_58))
                        goto LAB_;
                        uVar6 = uVar6 + 1;
                      } while (uVar6 <= uStack_50);
                      uStack_1d0 = (undefined8 *)lStack_b8;
                      lVar2 = (longlong)uStack_1d0;
                    }
                  }
                }
              }
            }
          }
          else {
            uVar6 = 1;
            lVar2 = lStack_b8;
            if (uStack_50 != 0) {
              do {
                if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_58))
                goto LAB_;
                uVar6 = uVar6 + 1;
                lVar2 = lStack_b8;
              } while (uVar6 <= uStack_50);
            }
          }
        }
      }
      if (*(uint *)(param_1 + 0x24) != 0) {
        auVar3 = ZEXT816(4) * ZEXT416(*(uint *)(param_1 + 0x24));
        uVar8 = auVar3._0_8_;
        if (auVar3._8_8_ != 0) {
          uVar8 = 0xffffffffffffffff;
        }
        uStack_1d0 = (undefined8 *)CONCAT71(uStack_1d0._1_7_,6);
        uStack_1d8 = CONCAT44(uStack_1d8._4_4_,0x3cf);
        uVar8 = (*_DAT_)(uVar8,_DAT_,1,0x1a4c1e8);
        *(undefined8 *)(param_1 + 0x28) = uVar8;
        uStack_1d8 = 0;
        func_0x(uVar1,0x1f,(ulonglong)*(uint *)(param_1 + 0x24) << 2,1);
        if (*(longlong *)(param_1 + 0x28) == 0) {
          uStack_1d8 = 0;
          (*_DAT_)(1,0x1c00438,0x1bda9c0,0x3d2);
        }
        if (*(uint *)(param_1 + 0xb70) != 0) {
          auVar3 = ZEXT816(4) * ZEXT416(*(uint *)(param_1 + 0xb70));
          uVar8 = auVar3._0_8_;
          if (auVar3._8_8_ != 0) {
            uVar8 = 0xffffffffffffffff;
          }
          uStack_1d0 = (undefined8 *)CONCAT71(uStack_1d0._1_7_,6);
          uStack_1d8 = CONCAT44(uStack_1d8._4_4_,0x3d7);
          uVar8 = (*_DAT_)(uVar8,_DAT_,1,0x1a4c1e8);
          *(undefined8 *)(param_1 + 0xb38) = uVar8;
          uStack_1d8 = 0;
          func_0x(uVar1,0x30,(ulonglong)*(uint *)(param_1 + 0xb70) << 2,1);
          if (*(longlong *)(param_1 + 0xb38) == 0) {
            uStack_1d8 = 0;
            (*_DAT_)(1,0x1c00410,0x1bda9c0,0x3d8);
          }
          *(undefined4 *)(param_1 + 0x24) = 0;
          *(undefined4 *)(param_1 + 0xb70) = 0;
          iVar5 = (**(code **)(*(longlong *)auStack_78._0_8_ + 0x38))(auStack_78._0_8_,0);
          if (iVar5 != 0) {
            uStack_1d8 = CONCAT44(uStack_1d8._4_4_,iVar5);
            func_0x(0x497a,0x10,1,0x1a4c058);
          }
          uStack_1d0 = (undefined8 *)lStack_b8;
          lVar2 = (longlong)uStack_1d0;
          while( true ) {
            uStack_1d0 = (undefined8 *)lVar2;
            uStack_1d8 = uStack_48;
            iVar5 = (**(code **)(*(longlong *)auStack_98._8_8_ + 0x18))(auStack_98._8_8_,0,1,0);
            if ((iVar5 != 0) ||
               (((*(uint *)(lVar7 + 0xbc) & 4) != 0 &&
                ((iVar5 = func_0x(), iVar5 != 0 ||
                 (((lVar2 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              )), lVar2 != 0 && (*(char *)(*(longlong *)(lVar2 + 0x38) + 8) != '\0')
                   ) && (iVar5 = func_0x(), iVar5 == 0)))))))) break;
            uStack_184 = 0;
            lVar2 = lStack_b8;
            if (lStack_b8 != 0) {
              uVar6 = func_0x(&lStack_b8,0x17e6ef0,&uStack_184);
              uVar12 = (ulonglong)uVar6;
              if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_58)) {
LAB_:
                lVar2 = lStack_b8;
                if (uVar6 <= uStack_50) {
                  lVar11 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_58;
                  puVar9 = (undefined4 *)(*(longlong *)(lVar11 + 8) + lStack_b8);
                  lVar2 = lStack_b8;
                  if (((puVar9 != (undefined4 *)0x0) &&
                      (lVar2 = lStack_b8,
                      *(longlong *)(lStack_b8 + *(longlong *)(lVar11 + 0x10)) == 4)) &&
                     (lVar2 = lStack_b8, *(int *)(lStack_b8 + *(longlong *)(lVar11 + 0x18)) != 3)) {
                    uStack_190 = *puVar9;
                    *(undefined4 *)
                     (*(longlong *)(param_1 + 0x28) + (ulonglong)*(uint *)(param_1 + 0x24) * 4) =
                         uStack_190;
                    *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
                    auStack_180[0] = 0;
                    lVar2 = lStack_b8;
                    if (lStack_b8 != 0) {
                      uVar6 = func_0x(&lStack_b8,0x1a4c0a0,auStack_180);
                      lVar2 = lStack_b8;
                      uVar12 = (ulonglong)uVar6;
                      if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_58)) {
LAB_:
                        if (uVar6 <= uStack_50) {
                          lVar11 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_58;
                          uVar12 = *(ulonglong *)(lStack_b8 + *(longlong *)(lVar11 + 0x10));
                          lVar10 = *(longlong *)(lVar11 + 8) + lStack_b8;
                          if (((lVar10 != 0) && (uVar12 - 1 < 4)) &&
                             ((*(int *)(lStack_b8 + *(longlong *)(lVar11 + 0x18)) != 3 &&
                              (func_0x(aiStack_1a8,lVar10,uVar12 & 0xffffffff),
                              aiStack_1a8[0] == 0)))) {
                            *(undefined4 *)
                             (*(longlong *)(param_1 + 0xb38) +
                             (ulonglong)*(uint *)(param_1 + 0xb70) * 4) = uStack_190;
                            *(int *)(param_1 + 0xb70) = *(int *)(param_1 + 0xb70) + 1;
                            lVar2 = lStack_b8;
                          }
                        }
                      }
                      else {
                        uVar6 = 1;
                        if (uStack_50 != 0) {
                          do {
                            if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_58))
                            goto LAB_;
                            uVar6 = uVar6 + 1;
                          } while (uVar6 <= uStack_50);
                          uStack_1d0 = (undefined8 *)lStack_b8;
                          lVar2 = (longlong)uStack_1d0;
                        }
                      }
                    }
                  }
                }
              }
              else {
                uVar6 = 1;
                lVar2 = lStack_b8;
                if (uStack_50 != 0) {
                  do {
                    if (uVar12 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_58))
                    goto LAB_;
                    uVar6 = uVar6 + 1;
                  } while (uVar6 <= uStack_50);
                  lVar2 = lStack_b8;
                }
              }
            }
          }
        }
      }
    }
LAB_:
    func_0x(&lStack_b8);
  }
  func_0x(&uStack_178,0);
  if ((int)uStack_178 != 0) {
    func_0x(&uStack_178,0);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_1f8);
  return;
}

