
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  short *psVar1;
  byte *pbVar2;
  byte *pbVar3;
  undefined8 *puVar4;
  code *pcVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  char cVar15;
  char cVar16;
  int iVar17;
  longlong lVar18;
  short *psVar19;
  ulonglong *puVar20;
  undefined8 uVar21;
  longlong *plVar22;
  longlong lVar23;
  undefined4 *puVar24;
  byte bVar25;
  ushort uVar26;
  int iVar27;
  byte *pbVar28;
  longlong lVar29;
  undefined4 *puVar30;
  ushort uVar31;
  undefined4 uVar32;
  ushort *puVar33;
  longlong lVar34;
  short sVar35;
  uint uVar36;
  undefined8 unaff_RBX;
  ulonglong uVar37;
  byte **ppbVar38;
  undefined *puVar39;
  ushort *puVar40;
  undefined4 *puVar41;
  ushort uVar42;
  uint uVar43;
  uint uVar44;
  undefined2 *puVar45;
  uint uVar46;
  undefined2 uVar47;
  ulonglong uVar48;
  longlong *plVar49;
  longlong unaff_GS_OFFSET;
  undefined2 auStackX_8 [4];
  undefined4 uStackX_10;
  undefined2 auStackX_14 [2];
  undefined4 uStackX_18;
  ushort auStackX_1c [2];
  short sStackX_20;
  undefined2 uStackX_22;
  int iStackX_24;
  undefined8 uStack_100;
  undefined auStack_f8 [48];
  undefined auStack_c8 [16];
  undefined2 auStack_b8 [2];
  undefined4 uStack_b4;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_9a;
  undefined8 uStack_90;
  undefined auStack_88 [8];
  undefined8 uStack_80;
  undefined auStack_78 [16];
  undefined8 uStack_68;
  undefined4 auStack_60 [2];
  undefined8 uStack_58;
  undefined2 auStack_48 [2];
  undefined4 uStack_44;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar18 = func_0x();
  lVar18 = -lVar18;
  pbVar3 = &stack0xfffffffffffffff8 + lVar18;
  *(undefined8 *)(&stack0x000023e0 + lVar18) = unaff_RBX;
  *(ulonglong *)(&stack0x00002378 + lVar18) = _DAT_ ^ (ulonglong)pbVar3;
  ppbVar38 = (byte **)0x0;
  *(longlong *)(&stack0x00000080 + lVar18) = param_1;
  *(undefined8 *)(&stack0x000002d0 + lVar18) = 0;
  pbVar28 = (byte *)(param_1 + 0x530);
  *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
  *(undefined8 *)(&stack0x000002e6 + lVar18) = 0;
  *(undefined2 *)(&stack0x000002c8 + lVar18) = 0xffff;
  lVar29 = *(longlong *)(param_1 + 0x28);
  *(undefined8 *)(&stack0x000002f0 + lVar18) = 0;
  *(undefined8 *)(&stack0x000002d8 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar18) = 0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar18 + 0xc) = 0;
  *(undefined8 *)(&stack0x0000003e + lVar18) = 0;
  *(undefined8 *)(&stack0x00000048 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000030 + lVar18) = 0;
  *(undefined (*) [16])(&stack0x00000098 + lVar18) = ZEXT816(0);
  *(undefined4 *)(&stack0x00000388 + lVar18) = 0;
  *(undefined2 *)(&stack0x0000038c + lVar18) = 0;
  *(undefined8 *)(&stack0x00000390 + lVar18) = 0;
  *(undefined2 *)(&stack0x00000398 + lVar18) = 0;
  *(undefined4 *)(&stack0x0000039a + lVar18) = 0;
  *(undefined2 *)(&stack0x0000039e + lVar18) = 0;
  *(undefined8 *)(&stack0x000003a0 + lVar18) = 0;
  *(undefined4 *)(&stack0x000003b8 + lVar18) = 0;
  *(undefined2 *)(&stack0x000003bc + lVar18) = 0;
  *(undefined8 *)(&stack0x000003c0 + lVar18) = 0;
  *(undefined2 *)(&stack0x000003c8 + lVar18) = 0;
  *(undefined4 *)(&stack0x000003ca + lVar18) = 0;
  *(undefined2 *)(&stack0x000003ce + lVar18) = 0;
  *(undefined8 *)(&stack0x000003d0 + lVar18) = 0;
  lVar29 = *(longlong *)(lVar29 + 8);
  *(longlong *)(&stack0x00000068 + lVar18) = lVar29;
  *(undefined4 *)(&stack0x00000058 + lVar18) = param_2;
  bVar25 = *pbVar28;
  *(undefined8 *)(&stack0x00000090 + lVar18) = param_3;
  *(byte **)(&stack0x00000078 + lVar18) = pbVar28;
  *pbVar3 = bVar25;
  *(longlong *)(&stack0x00000088 + lVar18) = lVar29 + 0x28;
  puVar39 = &stack0xffffffffffffffc8 + lVar18;
  if ((DAT_ & 4) != 0) goto LAB_;
  *(longlong *)(&stack0x00000070 + lVar18) = param_1 + 0x30;
  *pbVar28 = bVar25 & 0xfb | 1;
  *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100147;
  func_0x(param_1 + 0x30);
  plVar49 = (longlong *)(param_1 + 0x2b0);
  *(longlong **)(&stack0x00000060 + lVar18) = plVar49;
  *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10015a;
  func_0x(plVar49);
  if (*(longlong *)(param_1 + 0x2d8) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10016a;
    func_0x(plVar49,0);
  }
  lVar29 = *(longlong *)(param_1 + 0x508);
  iVar17 = *(int *)(param_1 + 0x2d0);
  *(int *)(&stack0x000002fc + lVar18) = iVar17;
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar18) = 9;
  if (*(char *)(lVar29 + 2) < '\0') {
    pbVar28 = (byte *)(lVar29 + 0x60);
    if ((*(short *)(&stack0x000002c8 + lVar18) == 0) ||
       (ppbVar38 = *(byte ***)(&stack0x000002d8 + lVar18), ppbVar38 == (byte **)0x0)) {
      *(undefined (*) [16])(&stack0x00000310 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000370 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000320 + lVar18) = ZEXT816(0);
      *(byte ***)(&stack0x00000318 + lVar18) = ppbVar38;
      *(undefined (*) [16])(&stack0x00000330 + lVar18) = ZEXT816(0);
      *(int *)(&stack0x00000314 + lVar18) = (int)ppbVar38;
      *(undefined (*) [16])(&stack0x00000360 + lVar18) = ZEXT816(0);
      *(byte ***)(&stack0x0000032e + lVar18) = ppbVar38;
      *(undefined (*) [16])(&stack0x00000340 + lVar18) = ZEXT816(0);
      *(byte ***)(&stack0x00000338 + lVar18) = ppbVar38;
      *(byte ***)(&stack0x00000320 + lVar18) = ppbVar38;
      *(byte ***)(&stack0x00000348 + lVar18) = ppbVar38;
      *(short *)(&stack0x00000372 + lVar18) = (short)ppbVar38;
      ppbVar38 = (byte **)(&stack0x00000300 + lVar18);
      *(undefined (*) [16])(&stack0x00000350 + lVar18) = ZEXT816(0);
      *(undefined2 *)(&stack0x00000310 + lVar18) = 0xffff;
      *(undefined (*) [16])(&stack0x00000300 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000360 + lVar18) = 0;
      *(undefined4 *)(&stack0x00000368 + lVar18) = 0;
    }
    if (*(short *)(lVar29 + 0x24) == 0) {
LAB_:
      uVar47 = *(undefined2 *)(lVar29 + 0x30);
      *(undefined8 *)((longlong)&uStackX_18 + lVar18 + -0x18) = *(undefined8 *)(lVar29 + 0x28);
      *(undefined2 *)((longlong)auStackX_8 + lVar18) = uVar47;
    }
    else {
      cVar15 = *(char *)(lVar29 + 1);
      if (cVar15 == '\v') {
        if (*(int *)(lVar29 + 0x18) != 99) {
LAB_:
          if (cVar15 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar15 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar29 + 0x18) != 99) goto LAB_;
      }
      *(undefined4 *)((longlong)&uStackX_10 + lVar18) = *(undefined4 *)(lVar29 + 0x20);
      *(undefined2 *)((longlong)auStackX_14 + lVar18) = *(undefined2 *)(lVar29 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10029b;
      cVar15 = func_0x((longlong)&uStackX_10 + lVar18);
      if (cVar15 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1002ab;
      func_0x(lVar29,(longlong)&uStackX_18 + lVar18 + -0x18);
      uVar47 = *(undefined2 *)((longlong)auStackX_8 + lVar18);
    }
    uVar32 = *(undefined4 *)((longlong)&uStackX_18 + lVar18 + -0x18);
    *ppbVar38 = pbVar28;
    *(undefined4 *)(ppbVar38 + 0xc) = uVar32;
    uVar21 = *(undefined8 *)((longlong)&uStackX_18 + lVar18 + -0x18);
    *(undefined2 *)(ppbVar38 + 0xd) = uVar47;
    *(int *)((longlong)ppbVar38 + 100) = (int)((ulonglong)uVar21 >> 0x20);
    *(undefined4 *)((longlong)ppbVar38 + 0x6c) = *(undefined4 *)(lVar29 + 0x20);
    *(undefined2 *)(ppbVar38 + 0xe) = *(undefined2 *)(lVar29 + 0x24);
    *(undefined2 *)((longlong)ppbVar38 + 0x72) = 0;
    uVar32 = *(undefined4 *)((ulonglong)*pbVar28 * 6 + 0x165d3e0);
    uVar48 = (ulonglong)*(short *)((ulonglong)*pbVar28 * 6 + 0x165d3e4);
    *(undefined2 *)(ppbVar38 + 2) = 0xffff;
    ppbVar38[3] = (byte *)0x0;
    uVar43 = 0;
    *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar38 + 0x2e) = 0;
    ppbVar38[7] = (byte *)0x0;
    ppbVar38[4] = (byte *)0x0;
    ppbVar38[9] = (byte *)0x0;
    ppbVar38[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar38 + 0xb) = 0;
    *(undefined4 *)((longlong)&uStackX_18 + lVar18) = uVar32;
    if ((**ppbVar38 & 2) != 0) {
      pbVar2 = pbVar28 + uVar48;
      if ((pbVar28[uVar48] & 1) == 0) {
        *(undefined2 *)(ppbVar38 + 2) = 0;
        ppbVar38[3] = pbVar2;
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar38 + 0x36) = 0;
        switch(*pbVar2 & 0xe) {
        default:
          uVar43 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10053e;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar43 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar43 = 1;
        }
        *(uint *)(ppbVar38 + 4) = uVar43;
        *(undefined8 *)((longlong)ppbVar38 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar38 + 2) = 1;
        ppbVar38[3] = pbVar2;
        bVar25 = *pbVar2;
        switch(bVar25 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar26 = *(ushort *)(pbVar2 + 1);
            sVar35 = 3;
            *(ushort *)((longlong)ppbVar38 + 0x12) = uVar26;
            uVar26 = (uVar26 & 0x7f) << 8 | uVar26 >> 8;
          }
          else {
            sVar35 = 2;
            uVar26 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar38 + 0x12) = uVar26;
          *(short *)(ppbVar38 + 5) = sVar35;
          uVar26 = *(ushort *)((longlong)ppbVar38 + 0x12);
          *(short *)((longlong)ppbVar38 + 0x2c) = (short)(uVar26 + 1 >> 1) + sVar35;
          if (uVar26 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
            *(undefined4 *)(ppbVar38 + 8) = 0;
            ppbVar38[7] = (byte *)0x0;
            ppbVar38[4] = (byte *)0x0;
          }
          else {
            iVar27 = uVar26 - 1;
            *(short *)((longlong)ppbVar38 + 0x2a) =
                 ((short)(iVar27 / 0x1e) + (short)(iVar27 >> 0x1f)) -
                 (short)((longlong)iVar27 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
            *(undefined4 *)(ppbVar38 + 8) = 0;
            ppbVar38[7] = (byte *)0x0;
            ppbVar38[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar25 & 0x1c) == 4) && ((bVar25 & 2) != 0)) {
            *(undefined4 *)(ppbVar38 + 8) = 0;
            uVar43 = 1;
            uVar32 = 0xf;
          }
          else {
            uVar32 = 1;
          }
          *(undefined4 *)(ppbVar38 + 8) = 0;
          ppbVar38[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
          *(undefined2 *)(ppbVar38 + 5) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x12) = 0;
          *(undefined8 *)((longlong)ppbVar38 + 0x2a) = 0;
          *(undefined4 *)((longlong)ppbVar38 + 0x32) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x36) = 0;
          ppbVar38[4] = (byte *)0x0;
          ppbVar38[7] = (byte *)0x0;
          ppbVar38[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = uVar32;
          *(uint *)(ppbVar38 + 8) = uVar43;
          ppbVar38[7] = (byte *)0x0;
          ppbVar38[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar38[7] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = 9;
          ppbVar38[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar38 + 0x12) = 0;
          ppbVar38[6] = (byte *)0x0;
          ppbVar38[4] = (byte *)0x0;
          ppbVar38[3] = pbVar2;
          *(undefined4 *)(ppbVar38 + 8) = 0;
          ppbVar38[7] = (byte *)0x0;
          ppbVar38[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar38 & 4) != 0) {
      sVar35 = *(short *)((longlong)&uStackX_18 + lVar18 + 2);
      if (sVar35 != 0) {
        uVar48 = (ulonglong)*(ushort *)(lVar29 + 0x61 + (longlong)sVar35 * 2);
      }
      psVar19 = (short *)(pbVar28 + uVar48);
      ppbVar38[9] = (byte *)psVar19;
      sVar35 = *psVar19;
      ppbVar38[10] = (byte *)(psVar19 + 1);
      *(short *)(ppbVar38 + 0xb) = (sVar35 + 1) * 2;
    }
    pbVar28 = ppbVar38[1];
    if (pbVar28 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1005d7;
      func_0x(pbVar28,ppbVar38);
    }
    plVar49 = *(longlong **)(&stack0x00000060 + lVar18);
  }
  uVar48 = 0;
  uVar37 = (ulonglong)*(ushort *)(lVar29 + 0xe);
  pbVar28 = (byte *)((ulonglong)*(ushort *)(lVar29 + (0xfff - (longlong)iVar17) * 2) + lVar29);
  bVar25 = *pbVar28;
  *(byte **)(&stack0x000002d0 + lVar18) = pbVar28;
  if ((bVar25 & 1) == 0) {
    *(undefined2 *)(&stack0x000002c8 + lVar18) = 0;
    *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
    *(undefined4 *)(&stack0x000002ee + lVar18) = 0;
    switch(*pbVar28 & 0xe) {
    default:
      uVar37 = (ulonglong)*(ushort *)(pbVar28 + 2);
      if (0x1f9d < *(ushort *)(pbVar28 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100831;
        func_0x(pbVar28,6);
        uVar48 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
      }
      break;
    case 4:
      uVar37 = 9;
      uVar48 = 0;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar37 = 1;
    }
    *(int *)(&stack0x000002d8 + lVar18) = (int)uVar37;
    ppbVar38 = *(byte ***)(&stack0x000002d8 + lVar18);
    *(longlong *)(&stack0x000002e6 + lVar18) = lVar29 + 0x2000;
  }
  else {
    *(undefined2 *)(&stack0x000002c8 + lVar18) = 1;
    bVar25 = *pbVar28;
    switch(bVar25 & 0x1c) {
    default:
      if ((char)pbVar28[1] < '\0') {
        uVar26 = (*(ushort *)(pbVar28 + 1) & 0x7f) << 8 | *(ushort *)(pbVar28 + 1) >> 8;
        uVar47 = 3;
        sVar35 = 3;
        *(ushort *)(&stack0x000002ca + lVar18) = uVar26;
      }
      else {
        uVar26 = (ushort)pbVar28[1];
        *(ushort *)(&stack0x000002ca + lVar18) = uVar26;
        uVar47 = 2;
        sVar35 = 2;
      }
      *(undefined2 *)(&stack0x000002e0 + lVar18) = uVar47;
      *(ushort *)(&stack0x000002e4 + lVar18) = ((ushort)(uVar26 + 1) >> 1) + sVar35;
      if (uVar26 < 0x1f) {
        *(undefined2 *)(&stack0x000002e2 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
      }
      else {
        iVar17 = uVar26 - 1;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
        *(short *)(&stack0x000002e2 + lVar18) =
             ((short)(iVar17 / 0x1e) + (short)(iVar17 >> 0x1f)) -
             (short)((longlong)iVar17 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar25 & 0x1c) == 4) && ((bVar25 & 2) != 0)) {
        uVar48 = 0xf;
        *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0xf;
        *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
        *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 1;
      }
      else {
        *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
        uVar48 = 1;
        *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
        *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 1;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
      }
      break;
    case 8:
      *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
      uVar48 = 9;
      *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
      *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
      *(undefined4 *)(&stack0x000002cc + lVar18) = 9;
      *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
    }
    *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar38;
    *(longlong *)(&stack0x000002f0 + lVar18) = lVar29 + 0x2000;
    uVar37 = (ulonglong)ppbVar38 & 0xffffffff;
  }
  sVar35 = *(short *)(&stack0x000002c8 + lVar18);
  *(short *)((longlong)&uStackX_18 + lVar18 + 8) = sVar35;
  if (sVar35 == 0) {
    if ((int)uVar48 == 0) {
      *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
      *(int *)(&stack0x000002dc + lVar18) = (int)uVar37;
      uVar48 = uVar37;
      if ((**(byte **)(&stack0x000002d0 + lVar18) & 0x10) != 0) {
        uVar43 = (int)uVar37 + 2 +
                 (*(ushort *)(*(byte **)(&stack0x000002d0 + lVar18) + uVar37) + 7 >> 3);
        uVar48 = (ulonglong)uVar43;
        *(uint *)(&stack0x000002dc + lVar18) = uVar43;
      }
      if ((**(byte **)(&stack0x000002d0 + lVar18) & 0x20) == 0) {
        *(int *)(&stack0x000002cc + lVar18) = (int)uVar48;
        *(undefined2 *)(&stack0x000002e4 + lVar18) = 0;
        *(int *)(&stack0x000002e0 + lVar18) = (int)uVar48;
        uVar37 = uVar48;
      }
      else {
        psVar19 = (short *)(*(byte **)(&stack0x000002d0 + lVar18) + uVar48);
        sVar35 = *psVar19;
        *(short *)(&stack0x000002e4 + lVar18) = sVar35;
        if (sVar35 == 0) {
          if ((((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
              (lVar29 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014de758 * 8) + 8 +
                         (ulonglong)*puRam00000000014de760), lVar29 != 0)) &&
             ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
              (*(char *)(lVar29 + 0x499) != '\0')))) {
            if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10096a;
              (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1009e2;
              (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x80f);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1009f3;
          func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),3);
        }
        uVar43 = *(int *)(&stack0x000002dc + lVar18) +
                 (*(ushort *)(&stack0x000002e4 + lVar18) + 1) * 2;
        *(uint *)(&stack0x000002e0 + lVar18) = uVar43;
        if (0x1f9e < uVar43) {
          if (((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
             ((lVar29 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014de758 * 8) + 8 +
                         (ulonglong)*puRam00000000014de760), lVar29 != 0 &&
              ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
               (*(char *)(lVar29 + 0x499) != '\0')))))) {
            if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100a9a;
              (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100abe;
              (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x816);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100acf;
          func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),4);
          uVar43 = *(uint *)(&stack0x000002e0 + lVar18);
        }
        uVar37 = (ulonglong)uVar43;
        uVar44 = (ushort)psVar19[*(ushort *)(&stack0x000002e4 + lVar18)] & 0x7fff;
        uVar48 = (ulonglong)uVar44;
        *(uint *)(&stack0x000002cc + lVar18) = uVar44;
        if (uVar44 < uVar43) {
          if ((((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
              (lVar29 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014de758 * 8) + 8 +
                         (ulonglong)*puRam00000000014de760), lVar29 != 0)) &&
             ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
              (*(char *)(lVar29 + 0x499) != '\0')))) {
            if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100b74;
              (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100b9a;
              (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x81d);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100bab;
          func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),4);
          uVar37 = (ulonglong)*(uint *)(&stack0x000002e0 + lVar18);
          uVar48 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
        }
        do {
          uVar26 = *(ushort *)(&stack0x000002e4 + lVar18);
          if (-1 < psVar19[(ulonglong)(uVar26 - 1) + 1]) break;
          uVar44 = (uint)uVar37;
          if (((uVar26 != 1) &&
              (uVar44 = *(ushort *)
                         ((ulonglong)*(uint *)(&stack0x000002dc + lVar18) +
                          *(longlong *)(&stack0x000002d0 + lVar18) + -2 +
                         (longlong)(int)(uint)uVar26 * 2) & 0x7fff, uVar44 < (uint)uVar37)) ||
             ((*(ushort *)
                ((ulonglong)*(uint *)(&stack0x000002dc + lVar18) +
                 *(longlong *)(&stack0x000002d0 + lVar18) + (ulonglong)uVar26 * 2) & 0x7fff) <
              uVar44)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100c1f;
            func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),7);
            uVar37 = (ulonglong)*(uint *)(&stack0x000002e0 + lVar18);
            uVar48 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
          }
          uVar43 = (uint)uVar37;
          if ((uVar44 < uVar43) || ((uint)uVar48 < uVar44)) goto code_r0x00100f7e;
          if (*(ushort *)((ulonglong)uVar44 + *(longlong *)(&stack0x000002d0 + lVar18)) == 5) {
            *(ushort *)(&stack0x000002ca + lVar18) = *(ushort *)(&stack0x000002ca + lVar18) | 2;
            *(short *)(&stack0x000002e4 + lVar18) = *(short *)(&stack0x000002e4 + lVar18) + -1;
            uVar26 = *(ushort *)(&stack0x000002f4 + lVar18);
            *(short *)(&stack0x000002f2 + lVar18) = (short)uVar44;
            lVar29 = (ulonglong)(uVar44 & 0xffff) + *(longlong *)(&stack0x000002d0 + lVar18);
            uVar42 = *(ushort *)(lVar29 + 2);
            if ((uVar42 & 0x4000) == 0) {
              uVar26 = uVar26 & 0xc7ff;
            }
            else {
              uVar26 = uVar26 ^ (uVar26 ^ uVar42) & 0x3800;
            }
            *(ushort *)(&stack0x000002f4 + lVar18) = uVar26;
            *(ushort *)(&stack0x000002f4 + lVar18) =
                 (uVar26 ^ *(ushort *)(lVar29 + 2)) & 0x7ff ^ uVar26;
            goto code_r0x00100d16;
          }
          if (*(ushort *)((ulonglong)uVar44 + *(longlong *)(&stack0x000002d0 + lVar18)) < 0x400)
          break;
          *(ushort *)(&stack0x000002ca + lVar18) = *(ushort *)(&stack0x000002ca + lVar18) | 1;
          psVar1 = (short *)(&stack0x000002e4 + lVar18);
          *psVar1 = *psVar1 + -1;
        } while (*psVar1 != 0);
      }
      uVar43 = (uint)uVar37;
code_r0x00100d16:
      if ((**(byte **)(&stack0x000002d0 + lVar18) & 0x40) == 0) {
        *(undefined4 *)(&stack0x000002ee + lVar18) = 0;
      }
      else {
        *(int *)(&stack0x000002ee + lVar18) = (int)uVar48;
        *(int *)(&stack0x000002cc + lVar18) = (int)uVar48 + 0xe;
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100d44;
        puVar20 = (ulonglong *)func_0x(&stack0x000002ca + lVar18);
        iVar17 = 0;
        uVar48 = *puVar20;
        uVar42 = (ushort)(uVar48 >> 0x30);
        uVar26 = uVar42;
        if ((((uint)(int)(short)uVar42 >> 1 ^ (int)(short)uVar42) & 0x2000) != 0) {
          uVar26 = uVar42 & 0xdfff;
          if ((uVar48 & 0x4000000000000000) != 0) {
            uVar26 = uVar42 | 0x2000;
          }
        }
        if (uVar26 == 0xfffc) {
          iVar17 = (int)((uVar48 >> 0x20 & 0xffff) >> 5);
        }
        uVar48 = (ulonglong)(uint)(*(int *)(&stack0x000002cc + lVar18) + iVar17);
        uVar43 = *(uint *)(&stack0x000002e0 + lVar18);
        *(int *)(&stack0x000002cc + lVar18) = *(int *)(&stack0x000002cc + lVar18) + iVar17;
      }
      iVar17 = (int)uVar48;
      if ((*(ulonglong *)(&stack0x000002e6 + lVar18) != 0) &&
         (*(ulonglong *)(&stack0x000002e6 + lVar18) <
          uVar48 + *(longlong *)(&stack0x000002d0 + lVar18))) {
        if (((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
           (((lVar29 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000014de758 * 8) + 8 +
                        (ulonglong)*puRam00000000014de760), lVar29 != 0 &&
             (lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0)) &&
            (*(char *)(lVar29 + 0x499) != '\0')))) {
          if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100e63;
            (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100e87;
            (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x877);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100e98;
        func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),0x12);
        uVar43 = *(uint *)(&stack0x000002e0 + lVar18);
        iVar17 = *(int *)(&stack0x000002cc + lVar18);
      }
      if (0x3f3b < iVar17 - 1U) {
        if (((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
           ((lVar29 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000014de758 * 8) + 8 +
                       (ulonglong)*puRam00000000014de760), lVar29 != 0 &&
            ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
             (*(char *)(lVar29 + 0x499) != '\0')))))) {
          if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100f30;
            (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100f56;
            (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x87c);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100f67;
        func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),5);
        uVar43 = *(uint *)(&stack0x000002e0 + lVar18);
        iVar17 = *(int *)(&stack0x000002cc + lVar18);
      }
    }
    else {
      uVar43 = *(uint *)(&stack0x000002e0 + lVar18);
code_r0x00100f7e:
      iVar17 = (int)uVar48;
    }
    *(undefined4 *)(&stack0x00000030 + lVar18) = *(undefined4 *)(&stack0x000002d8 + lVar18);
    *(undefined2 *)((longlong)&uStackX_18 + lVar18 + 10) =
         *(undefined2 *)(&stack0x000002ca + lVar18);
    *(undefined2 *)(&stack0x0000003c + lVar18) = *(undefined2 *)(&stack0x000002e4 + lVar18);
    *(uint *)(&stack0x00000038 + lVar18) = uVar43;
    *(undefined4 *)(&stack0x00000034 + lVar18) = *(undefined4 *)(&stack0x000002dc + lVar18);
    uVar32 = *(undefined4 *)(&stack0x000002ee + lVar18);
    *(int *)((longlong)&uStackX_18 + lVar18 + 0xc) = iVar17;
    *(undefined4 *)(&stack0x00000046 + lVar18) = uVar32;
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101004;
    func_0x
              (&stack0x000003d8 + lVar18,0x1f9e,*(undefined8 *)(&stack0x000002d0 + lVar18));
    *(undefined **)(&stack0x00000028 + lVar18) = &stack0x000003d8 + lVar18;
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101018;
    iVar17 = func_0x((longlong)&uStackX_18 + lVar18 + 10);
    pbVar28 = *(byte **)(&stack0x00000028 + lVar18);
    if (iVar17 != 0) {
      puVar33 = (ushort *)(pbVar28 + *(uint *)(&stack0x00000034 + lVar18));
      uVar43 = *puVar33 - 1;
      if ((*(byte *)((longlong)&uStackX_18 + lVar18 + 10) & 1) == 0) {
        uVar43 = (uint)*puVar33;
      }
      if (uVar43 == 1) {
        uVar44 = *(uint *)(&stack0x00000038 + lVar18);
code_r0x00101054:
        if ((puVar33[(int)uVar43] & 0x7fff) < uVar44) goto code_r0x00101061;
      }
      else {
        uVar44 = puVar33[(longlong)(int)uVar43 + -1] & 0x7fff;
        if (*(uint *)(&stack0x00000038 + lVar18) <= uVar44) goto code_r0x00101054;
code_r0x00101061:
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10106e;
        func_0x(pbVar28,7);
        pbVar28 = *(byte **)(&stack0x00000028 + lVar18);
      }
      uVar26 = *(ushort *)(&stack0x0000004c + lVar18);
      *(short *)(&stack0x0000004a + lVar18) = (short)uVar44;
      if ((*(ushort *)(pbVar28 + (ulonglong)(uVar44 & 0xffff) + 2) & 0x4000) == 0) {
        uVar26 = uVar26 & 0xc7ff;
      }
      else {
        uVar26 = uVar26 ^ (*(ushort *)(pbVar28 + (ulonglong)(uVar44 & 0xffff) + 2) ^ uVar26) &
                          0x3800;
      }
      *(ushort *)(&stack0x0000004c + lVar18) = uVar26;
      *(ushort *)(&stack0x0000004c + lVar18) =
           (uVar26 ^ *(ushort *)(pbVar28 + (ulonglong)(uVar44 & 0xffff) + 2)) & 0x7ff ^ uVar26;
    }
  }
  else {
    if ((ppbVar38 == (byte **)0x0) || (*ppbVar38 == (byte *)0x0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10110b;
      func_0x((longlong)&uStackX_18 + lVar18 + 10,&stack0x000003d8 + lVar18,0x1f9e);
      uVar21 = *(undefined8 *)(&stack0x000002d8 + lVar18);
      if (*(short *)(&stack0x000002c8 + lVar18) == 0) {
        uVar21 = 0;
      }
      *(undefined8 *)(&stack0x00000030 + lVar18) = uVar21;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1010e9;
      func_0x((longlong)&uStackX_18 + lVar18 + 8,&stack0x000003d8 + lVar18,0x1f9e);
    }
    pbVar28 = *(byte **)(&stack0x00000028 + lVar18);
  }
  sVar35 = *(short *)((longlong)&uStackX_18 + lVar18 + 8);
  if (sVar35 == 0) {
    bVar25 = *pbVar28 >> 6;
  }
  else {
    bVar25 = *pbVar28 >> 1;
  }
  if ((bVar25 & 1) != 0) {
    if (sVar35 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101164;
      func_0x();
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10116b;
      func_0x((longlong)&uStackX_18 + lVar18 + 10,(longlong)&uStackX_18 + lVar18);
    }
    uVar26 = *(ushort *)((longlong)&uStackX_18 + lVar18 + 6);
    uVar42 = uVar26;
    if (((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) &&
       (uVar42 = uVar26 & 0xdfff, (uVar26 & 0x4000) != 0)) {
      uVar42 = uVar26 | 0x2000;
    }
    if ((uVar42 == 0xfffc) &&
       (puVar39 = &stack0xffffffffffffffc8 + lVar18,
       0x1f < *(ushort *)((longlong)&uStackX_18 + lVar18 + 4))) goto LAB_;
  }
  if (plVar49[5] == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1011bd;
    func_0x(plVar49,0);
  }
  if (*(int *)(plVar49 + 0x48) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1011d2;
    func_0x(plVar49,*(undefined4 *)(&stack0x00000058 + lVar18));
  }
  if (iRam0000000001f77bd8 != 0) {
    plVar22 = (longlong *)plVar49[0x1a];
    puVar4 = *(undefined8 **)(plVar49[1] + 8);
    iVar17 = *(int *)(plVar22 + 2);
    cVar15 = *(char *)(puVar4[6] + 0x1cde);
    pcVar5 = *(code **)*puVar4;
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10120b;
    cVar16 = (*pcVar5)(puVar4);
    if (cVar16 == '\0') {
      if (cVar15 == '\0') {
        if (iVar17 << 0x1f < 0) {
          if ((*(byte *)(plVar22 + 2) & 0x40) == 0) goto code_r0x0010124b;
          lVar29 = puVar4[0x1a];
          if (((lVar29 != 0) && (*(char *)(lVar29 + 0x34) != '\0')) &&
             (*(longlong *)(lVar29 + 0x40) != 0)) {
            LOCK();
            lVar23 = *(longlong *)(lVar29 + 0x128);
            if (lVar23 == 0) {
              *(longlong *)(lVar29 + 0x128) = 0;
              lVar23 = 0;
            }
            UNLOCK();
            if (*(longlong *)(*plVar22 + 0x28) != lVar23) goto code_r0x0010124b;
          }
        }
      }
      else {
code_r0x0010124b:
        lVar29 = *(longlong *)(*(longlong *)(plVar49[1] + 8) + 0x30);
        if (*(int *)((longlong)plVar49 + 0x244) == 0) {
          if (*(int *)(*(longlong *)(lVar29 + 0x6b0) + 0x5ec) == 1) {
            lVar29 = lVar29 + 0x18;
            goto code_r0x00101284;
          }
        }
        else if (*(int *)(*(longlong *)(lVar29 + 0x6b0) + 0x5ec) == 1) {
          lVar29 = lVar29 + 0x28;
code_r0x00101284:
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101289;
          plVar22 = (longlong *)func_0x(lVar29);
          *plVar22 = *plVar22 + 1;
        }
      }
    }
  }
  bVar25 = *(byte *)plVar49[0x1c] >> 1;
  if (*(short *)(plVar49 + 0x1b) == 0) {
    bVar25 = *(byte *)plVar49[0x1c] >> 6;
  }
  if ((bVar25 & 1) != 0) {
    uVar32 = *(undefined4 *)(plVar49 + 4);
    uVar21 = *(undefined8 *)plVar49[5];
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1012cd;
    func_0x(&stack0x00000378 + lVar18,uVar21,uVar32);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1012d5;
  func_0x(plVar49);
  if (*(short *)((longlong)&uStackX_18 + lVar18 + 8) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1012e5;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1012ec;
    func_0x((longlong)&uStackX_18 + lVar18 + 10);
  }
  lVar29 = *(longlong *)(&stack0x00000070 + lVar18);
  *(longlong *)(&stack0x00000098 + lVar18) = (longlong)&uStackX_18 + lVar18 + 8;
  if (*(longlong *)(lVar29 + 0x28) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10130c;
    func_0x(lVar29,0);
  }
  lVar23 = *(longlong *)(lVar29 + 600);
  iVar17 = *(int *)(lVar29 + 0x20);
  *(int *)(&stack0x000002fc + lVar18) = iVar17;
  if (*(char *)(lVar23 + 2) < '\0') {
    pbVar28 = (byte *)(lVar23 + 0x60);
    if ((*(short *)(&stack0x000002c8 + lVar18) == 0) ||
       (ppbVar38 = *(byte ***)(&stack0x000002d8 + lVar18), ppbVar38 == (byte **)0x0)) {
      ppbVar38 = (byte **)(&stack0x00000300 + lVar18);
      *(undefined8 *)(&stack0x00000370 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000310 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000318 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000320 + lVar18) = ZEXT816(0);
      *(undefined2 *)(&stack0x00000310 + lVar18) = 0xffff;
      *(undefined (*) [16])(&stack0x00000330 + lVar18) = ZEXT816(0);
      *(undefined4 *)(&stack0x00000314 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000360 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x0000032e + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000340 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000338 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000320 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000348 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000360 + lVar18) = 0;
      *(undefined4 *)(&stack0x00000368 + lVar18) = 0;
      *(undefined2 *)(&stack0x00000372 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000350 + lVar18) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00000300 + lVar18) = ZEXT816(0);
    }
    if (*(short *)(lVar23 + 0x24) == 0) {
code_r0x00101439:
      uVar47 = *(undefined2 *)(lVar23 + 0x30);
      *(undefined8 *)((longlong)&uStackX_18 + lVar18 + -0x18) = *(undefined8 *)(lVar23 + 0x28);
    }
    else {
      cVar15 = *(char *)(lVar23 + 1);
      if (cVar15 == '\v') {
        if (*(int *)(lVar23 + 0x18) != 99) {
code_r0x00101401:
          if (cVar15 != '\t') goto code_r0x00101439;
          goto code_r0x00101405;
        }
      }
      else {
        if (cVar15 != '\b') goto code_r0x00101401;
code_r0x00101405:
        if (*(int *)(lVar23 + 0x18) != 99) goto code_r0x00101439;
      }
      *(undefined4 *)((longlong)&uStackX_10 + lVar18) = *(undefined4 *)(lVar23 + 0x20);
      *(undefined2 *)((longlong)auStackX_14 + lVar18) = *(undefined2 *)(lVar23 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101422;
      cVar15 = func_0x((longlong)&uStackX_10 + lVar18);
      if (cVar15 == '\0') goto code_r0x00101439;
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101432;
      func_0x(lVar23,(longlong)&uStackX_18 + lVar18 + -0x18);
      uVar47 = *(undefined2 *)((longlong)auStackX_8 + lVar18);
    }
    uVar32 = *(undefined4 *)((longlong)&uStackX_18 + lVar18 + -0x18);
    *ppbVar38 = pbVar28;
    *(undefined4 *)(ppbVar38 + 0xc) = uVar32;
    uVar21 = *(undefined8 *)((longlong)&uStackX_18 + lVar18 + -0x18);
    *(undefined2 *)(ppbVar38 + 0xd) = uVar47;
    *(int *)((longlong)ppbVar38 + 100) = (int)((ulonglong)uVar21 >> 0x20);
    *(undefined4 *)((longlong)ppbVar38 + 0x6c) = *(undefined4 *)(lVar23 + 0x20);
    *(undefined2 *)(ppbVar38 + 0xe) = *(undefined2 *)(lVar23 + 0x24);
    *(undefined2 *)((longlong)ppbVar38 + 0x72) = 0;
    uVar32 = *(undefined4 *)((ulonglong)*pbVar28 * 6 + 0x165d3e0);
    uVar48 = (ulonglong)*(short *)((ulonglong)*pbVar28 * 6 + 0x165d3e4);
    *(undefined2 *)(ppbVar38 + 2) = 0xffff;
    ppbVar38[3] = (byte *)0x0;
    uVar43 = 0;
    *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar38 + 0x2e) = 0;
    ppbVar38[7] = (byte *)0x0;
    ppbVar38[4] = (byte *)0x0;
    ppbVar38[9] = (byte *)0x0;
    ppbVar38[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar38 + 0xb) = 0;
    *(undefined4 *)((longlong)&uStackX_18 + lVar18) = uVar32;
    if ((**ppbVar38 & 2) != 0) {
      pbVar2 = pbVar28 + uVar48;
      if ((pbVar28[uVar48] & 1) == 0) {
        *(undefined2 *)(ppbVar38 + 2) = 0;
        ppbVar38[3] = pbVar2;
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar38 + 0x36) = 0;
        switch(*pbVar2 & 0xe) {
        default:
          uVar43 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1016a9;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar43 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar43 = 1;
        }
        *(uint *)(ppbVar38 + 4) = uVar43;
        *(undefined8 *)((longlong)ppbVar38 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar38 + 2) = 1;
        ppbVar38[3] = pbVar2;
        bVar25 = *pbVar2;
        switch(bVar25 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar26 = *(ushort *)(pbVar2 + 1);
            sVar35 = 3;
            *(ushort *)((longlong)ppbVar38 + 0x12) = uVar26;
            uVar26 = (uVar26 & 0x7f) << 8 | uVar26 >> 8;
          }
          else {
            sVar35 = 2;
            uVar26 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar38 + 0x12) = uVar26;
          *(short *)(ppbVar38 + 5) = sVar35;
          uVar26 = *(ushort *)((longlong)ppbVar38 + 0x12);
          *(short *)((longlong)ppbVar38 + 0x2c) = (short)(uVar26 + 1 >> 1) + sVar35;
          if (uVar26 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
            *(undefined4 *)(ppbVar38 + 8) = 0;
            ppbVar38[7] = (byte *)0x0;
            ppbVar38[4] = (byte *)0x0;
          }
          else {
            iVar27 = uVar26 - 1;
            *(short *)((longlong)ppbVar38 + 0x2a) =
                 ((short)(iVar27 / 0x1e) + (short)(iVar27 >> 0x1f)) -
                 (short)((longlong)iVar27 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
            *(undefined4 *)(ppbVar38 + 8) = 0;
            ppbVar38[7] = (byte *)0x0;
            ppbVar38[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar25 & 0x1c) != 4) || (uVar44 = 1, (bVar25 & 2) == 0)) {
            uVar44 = uVar43;
          }
          if (uVar44 == 0) {
            uVar32 = 1;
          }
          else {
            *(undefined4 *)(ppbVar38 + 8) = 0;
            uVar32 = 0xf;
          }
          ppbVar38[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar38 + 0x12) = 0;
          ppbVar38[6] = (byte *)0x0;
          ppbVar38[4] = (byte *)0x0;
          ppbVar38[7] = (byte *)0x0;
          ppbVar38[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = uVar32;
          *(uint *)(ppbVar38 + 8) = (uint)(uVar44 != 0);
          ppbVar38[7] = (byte *)0x0;
          ppbVar38[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar38[7] = (byte *)0x0;
          ppbVar38[7] = (byte *)0x0;
          ppbVar38[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar38 + 0x12) = 0;
          ppbVar38[6] = (byte *)0x0;
          ppbVar38[4] = (byte *)0x0;
          ppbVar38[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = 9;
          *(undefined4 *)(ppbVar38 + 8) = 0;
          ppbVar38[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar38 & 4) != 0) {
      sVar35 = *(short *)((longlong)&uStackX_18 + lVar18 + 2);
      if (sVar35 != 0) {
        uVar48 = (ulonglong)*(ushort *)(lVar23 + 0x61 + (longlong)sVar35 * 2);
      }
      psVar19 = (short *)(pbVar28 + uVar48);
      ppbVar38[9] = (byte *)psVar19;
      sVar35 = *psVar19;
      ppbVar38[10] = (byte *)(psVar19 + 1);
      *(short *)(ppbVar38 + 0xb) = (sVar35 + 1) * 2;
    }
    pbVar28 = ppbVar38[1];
    if (pbVar28 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101734;
      func_0x(pbVar28,ppbVar38);
    }
    plVar49 = *(longlong **)(&stack0x00000060 + lVar18);
  }
  else {
    ppbVar38 = (byte **)0x0;
  }
  uVar43 = (uint)*(ushort *)(lVar23 + 0xe);
  pbVar28 = (byte *)((ulonglong)*(ushort *)(lVar23 + (0xfff - (longlong)iVar17) * 2) + lVar23);
  bVar25 = *pbVar28;
  *(byte **)(&stack0x000002d0 + lVar18) = pbVar28;
  if ((bVar25 & 1) == 0) {
    *(undefined2 *)(&stack0x000002c8 + lVar18) = 0;
    *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
    *(undefined4 *)(&stack0x000002ee + lVar18) = 0;
    switch(*pbVar28 & 0xe) {
    default:
      uVar43 = (uint)*(ushort *)(pbVar28 + 2);
      if (0x1f9d < *(ushort *)(pbVar28 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1019dc;
        func_0x(pbVar28,6);
      }
      break;
    case 4:
      uVar43 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar43 = 1;
    }
    *(uint *)(&stack0x000002d8 + lVar18) = uVar43;
    *(longlong *)(&stack0x000002e6 + lVar18) = lVar23 + 0x2000;
  }
  else {
    *(undefined2 *)(&stack0x000002c8 + lVar18) = 1;
    bVar25 = *pbVar28;
    switch(bVar25 & 0x1c) {
    default:
      if ((char)pbVar28[1] < '\0') {
        uVar26 = (*(ushort *)(pbVar28 + 1) & 0x7f) << 8 | *(ushort *)(pbVar28 + 1) >> 8;
        uVar47 = 3;
        sVar35 = 3;
        *(ushort *)(&stack0x000002ca + lVar18) = uVar26;
      }
      else {
        uVar26 = (ushort)pbVar28[1];
        *(ushort *)(&stack0x000002ca + lVar18) = uVar26;
        uVar47 = 2;
        sVar35 = 2;
      }
      *(undefined2 *)(&stack0x000002e0 + lVar18) = uVar47;
      *(ushort *)(&stack0x000002e4 + lVar18) = ((ushort)(uVar26 + 1) >> 1) + sVar35;
      if (uVar26 < 0x1f) {
        *(undefined2 *)(&stack0x000002e2 + lVar18) = 0;
        *(longlong *)(&stack0x000002f0 + lVar18) = lVar23 + 0x2000;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
        *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar38;
      }
      else {
        iVar17 = uVar26 - 1;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
        *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar38;
        *(longlong *)(&stack0x000002f0 + lVar18) = lVar23 + 0x2000;
        *(short *)(&stack0x000002e2 + lVar18) =
             ((short)(iVar17 / 0x1e) + (short)(iVar17 >> 0x1f)) -
             (short)((longlong)iVar17 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar25 & 0x1c) == 4) && ((bVar25 & 2) != 0)) {
        *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
        *(longlong *)(&stack0x000002f0 + lVar18) = lVar23 + 0x2000;
        *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
        *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0xf;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 1;
        *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar38;
      }
      else {
        *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
        *(longlong *)(&stack0x000002f0 + lVar18) = lVar23 + 0x2000;
        *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
        *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 1;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
        *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar38;
      }
      break;
    case 8:
      *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
      *(longlong *)(&stack0x000002f0 + lVar18) = lVar23 + 0x2000;
      *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
      *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
      *(undefined4 *)(&stack0x000002cc + lVar18) = 9;
      *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
      *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar38;
    }
  }
  uVar21 = 0;
  lVar29 = *(longlong *)(*(longlong *)(&stack0x00000080 + lVar18) + 0x288);
  puVar39 = &stack0xffffffffffffffc8 + lVar18;
  if (*(char *)(lVar29 + 2) < '\0') {
    puVar45 = (undefined2 *)((longlong)auStack_48 + lVar18);
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0;
    *puVar45 = 0xffff;
    *(undefined4 *)((longlong)&uStack_44 + lVar18) = 0;
    *(undefined8 *)(&stack0xffffffffffffffd6 + lVar18) = 0;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar18) = 0;
    *(undefined8 *)(&stack0xffffffffffffffc8 + lVar18) = 0;
    *(undefined8 *)((longlong)&uStack_80 + lVar18) = 0x101a7e;
    lVar23 = func_0x();
    lVar23 = -lVar23;
    puVar39 = auStack_f8 + lVar23 + lVar18;
    *(undefined (*) [16])(auStack_c8 + lVar23 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])((longlong)auStack_b8 + lVar23 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])((longlong)&uStack_a8 + lVar23 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])((longlong)&uStack_9a + lVar23 + lVar18 + 2) = ZEXT816(0);
    *(undefined (*) [16])(auStack_88 + lVar23 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])(auStack_78 + lVar23 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])((longlong)&uStack_68 + lVar23 + lVar18) = ZEXT816(0);
    *(undefined8 *)((longlong)&uStack_58 + lVar23 + lVar18) = 0;
    *(undefined2 *)((longlong)auStack_b8 + lVar23 + lVar18) = 0xffff;
    *(undefined8 *)((longlong)&uStack_b0 + lVar23 + lVar18) = uVar21;
    *(int *)((longlong)&uStack_b4 + lVar23 + lVar18) = (int)uVar21;
    *(undefined8 *)((longlong)&uStack_9a + lVar23 + lVar18) = uVar21;
    *(undefined8 *)((longlong)&uStack_90 + lVar23 + lVar18) = uVar21;
    *(undefined8 *)((longlong)&uStack_a8 + lVar23 + lVar18) = uVar21;
    *(undefined8 *)((longlong)&uStack_80 + lVar23 + lVar18) = uVar21;
    *(undefined8 *)((longlong)&uStack_68 + lVar23 + lVar18) = 0;
    *(undefined4 *)((longlong)auStack_60 + lVar23 + lVar18) = 0;
    *(short *)((longlong)&uStack_58 + lVar23 + lVar18 + 2) = (short)uVar21;
    *(longlong *)(&stack0x000000a8 + lVar18) = (longlong)auStack_48 + lVar23 + lVar18;
    *(undefined (**) [16])(&stack0x000000b8 + lVar18) =
         (undefined (*) [16])(auStack_c8 + lVar23 + lVar18);
    *(undefined2 **)(&stack0x000000a0 + lVar18) = puVar45;
    *(undefined4 *)(&stack0x000000b0 + lVar18) = 0x239e;
    *(undefined8 *)((longlong)&uStack_100 + lVar23 + lVar18) = 0x101b0d;
    func_0x(&stack0x00000098 + lVar18,lVar29);
  }
  pcVar5 = *(code **)(**(longlong **)(&stack0x00000068 + lVar18) + 0x58);
  *(undefined8 *)(puVar39 + -8) = 0x101b17;
  cVar15 = (*pcVar5)();
  psVar19 = *(short **)(&stack0x000000a0 + lVar18);
  if (-1 < *(char *)(lVar29 + 2)) {
    psVar19 = *(short **)(&stack0x00000098 + lVar18);
  }
  puVar33 = (ushort *)(psVar19 + 1);
  if (*psVar19 == 0) {
    if (*(int *)(psVar19 + 2) == 0) {
      pbVar28 = *(byte **)(psVar19 + 4);
      uVar43 = *(uint *)(psVar19 + 8);
      uVar48 = (ulonglong)uVar43;
      *puVar33 = 0;
      *(uint *)(psVar19 + 10) = uVar43;
      bVar25 = *pbVar28;
      if ((bVar25 & 0x10) != 0) {
        uVar43 = uVar43 + 2 + (*(ushort *)(pbVar28 + uVar48) + 7 >> 3);
        uVar48 = (ulonglong)uVar43;
        *(uint *)(psVar19 + 10) = uVar43;
        bVar25 = *pbVar28;
      }
      if ((bVar25 & 0x20) == 0) {
        *(int *)(psVar19 + 2) = (int)uVar48;
        psVar19[0xe] = 0;
        *(int *)(psVar19 + 0xc) = (int)uVar48;
      }
      else {
        puVar40 = (ushort *)(pbVar28 + uVar48);
        uVar26 = *puVar40;
        psVar19[0xe] = uVar26;
        if (uVar26 == 0) {
          if ((((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
              (lVar23 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014de758 * 8) + 8 +
                         (ulonglong)*puRam00000000014de760), lVar23 != 0)) &&
             ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
              (*(char *)(lVar23 + 0x499) != '\0')))) {
            if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
              *(undefined8 *)(puVar39 + -8) = 0x101c12;
              (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x101c38;
              (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x80f);
            }
          }
          uVar21 = *(undefined8 *)(psVar19 + 4);
          *(undefined8 *)(puVar39 + -8) = 0x101c46;
          func_0x(uVar21,3);
          uVar26 = psVar19[0xe];
          uVar48 = (ulonglong)*(uint *)(psVar19 + 10);
        }
        uVar43 = (int)uVar48 + (uVar26 + 1) * 2;
        *(uint *)(psVar19 + 0xc) = uVar43;
        if (0x1f9e < uVar43) {
          if (((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
             ((lVar23 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014de758 * 8) + 8 +
                         (ulonglong)*puRam00000000014de760), lVar23 != 0 &&
              ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
               (*(char *)(lVar23 + 0x499) != '\0')))))) {
            if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
              *(undefined8 *)(puVar39 + -8) = 0x101ce5;
              (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x101d0b;
              (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x816);
            }
          }
          uVar21 = *(undefined8 *)(psVar19 + 4);
          *(undefined8 *)(puVar39 + -8) = 0x101d19;
          func_0x(uVar21,4);
          uVar26 = psVar19[0xe];
          uVar43 = *(uint *)(psVar19 + 0xc);
        }
        uVar42 = puVar40[uVar26];
        *(uint *)(psVar19 + 2) = uVar42 & 0x7fff;
        if ((uVar42 & 0x7fff) < uVar43) {
          if ((((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
              (lVar23 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014de758 * 8) + 8 +
                         (ulonglong)*puRam00000000014de760), lVar23 != 0)) &&
             ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
              (*(char *)(lVar23 + 0x499) != '\0')))) {
            if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
              *(undefined8 *)(puVar39 + -8) = 0x101db7;
              (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x101ddd;
              (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x81d);
            }
          }
          uVar21 = *(undefined8 *)(psVar19 + 4);
          *(undefined8 *)(puVar39 + -8) = 0x101deb;
          func_0x(uVar21,4);
          uVar26 = psVar19[0xe];
        }
        if ((short)puVar40[(ulonglong)(uVar26 - 1) + 1] < 0) {
          do {
            lVar23 = *(longlong *)(psVar19 + 4);
            lVar34 = (ulonglong)*(uint *)(psVar19 + 10) + lVar23;
            if (uVar26 == 1) {
              uVar43 = *(uint *)(psVar19 + 0xc);
              uVar44 = uVar43;
code_r0x00101e3c:
              if ((*(ushort *)(lVar34 + (ulonglong)uVar26 * 2) & 0x7fff) < uVar43)
              goto code_r0x00101e49;
            }
            else {
              uVar44 = *(uint *)(psVar19 + 0xc);
              uVar43 = *(ushort *)(lVar34 + -2 + (ulonglong)uVar26 * 2) & 0x7fff;
              if (uVar44 <= uVar43) goto code_r0x00101e3c;
code_r0x00101e49:
              *(undefined8 *)(puVar39 + -8) = 0x101e56;
              func_0x(lVar23,7);
              uVar44 = *(uint *)(psVar19 + 0xc);
            }
            if ((uVar43 < uVar44) || (*(uint *)(psVar19 + 2) < uVar43)) goto code_r0x0010213f;
            if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar19 + 4)) == 5) {
              *puVar33 = *puVar33 | 2;
              psVar19[0xe] = psVar19[0xe] + -1;
              psVar19[0x15] = (short)uVar43;
              lVar23 = (ulonglong)(uVar43 & 0xffff) + *(longlong *)(psVar19 + 4);
              uVar26 = psVar19[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar23 + 2) >> 0xe & 1) != 0) {
                uVar26 = *(ushort *)(lVar23 + 2) & 0x3800 | psVar19[0x16] & 0xc7ffU;
              }
              psVar19[0x16] = uVar26;
              psVar19[0x16] = (uVar26 ^ *(ushort *)(lVar23 + 2)) & 0x7ff ^ uVar26;
              goto code_r0x00101f12;
            }
            if (*(ushort *)((ulonglong)uVar43 + *(longlong *)(psVar19 + 4)) < 0x400)
            goto code_r0x00101f12;
            *puVar33 = *puVar33 | 1;
            uVar26 = psVar19[0xe] - 1;
            psVar19[0xe] = uVar26;
            if (uVar26 == 0) goto code_r0x00101f12;
          } while ((short)puVar40[(ulonglong)(uVar26 - 1) + 1] < 0);
          uVar48 = (ulonglong)*(uint *)(psVar19 + 2);
        }
        else {
code_r0x00101f12:
          uVar48 = (ulonglong)*(uint *)(psVar19 + 2);
        }
      }
      iVar17 = 0;
      if ((**(byte **)(psVar19 + 4) & 0x40) == 0) {
        *(undefined4 *)(psVar19 + 0x13) = 0;
      }
      else {
        *(int *)(psVar19 + 0x13) = (int)uVar48;
        *(int *)(psVar19 + 2) = (int)uVar48 + 0xe;
        *(undefined8 *)(puVar39 + -8) = 0x101f3d;
        puVar20 = (ulonglong *)func_0x(puVar33);
        uVar42 = (ushort)(*puVar20 >> 0x30);
        uVar26 = uVar42;
        if ((((uint)(int)(short)uVar42 >> 1 ^ (int)(short)uVar42) & 0x2000) != 0) {
          uVar26 = uVar42 & 0xdfff;
          if ((uVar42 >> 0xe & 1) != 0) {
            uVar26 = uVar42 | 0x2000;
          }
        }
        if (uVar26 == 0xfffc) {
          iVar17 = (int)((*puVar20 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar19 + 2) = *(int *)(psVar19 + 2) + iVar17;
        uVar48 = (ulonglong)*(uint *)(psVar19 + 2);
      }
      iVar17 = (int)uVar48;
      if ((*(ulonglong *)(psVar19 + 0xf) != 0) &&
         (*(ulonglong *)(psVar19 + 0xf) < uVar48 + *(longlong *)(psVar19 + 4))) {
        if (((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
           (((lVar23 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000014de758 * 8) + 8 +
                        (ulonglong)*puRam00000000014de760), lVar23 != 0 &&
             (lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0)) &&
            (*(char *)(lVar23 + 0x499) != '\0')))) {
          if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
            *(undefined8 *)(puVar39 + -8) = 0x102039;
            (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar39 + 0x20) = 0;
            *(undefined8 *)(puVar39 + -8) = 0x10205f;
            (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x877);
          }
        }
        uVar21 = *(undefined8 *)(psVar19 + 4);
        *(undefined8 *)(puVar39 + -8) = 0x10206d;
        func_0x(uVar21,0x12);
        iVar17 = *(int *)(psVar19 + 2);
      }
      if (0x3f3b < iVar17 - 1U) {
        if (((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
           ((lVar23 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000014de758 * 8) + 8 +
                       (ulonglong)*puRam00000000014de760), lVar23 != 0 &&
            ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
             (*(char *)(lVar23 + 0x499) != '\0')))))) {
          if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
            *(undefined8 *)(puVar39 + -8) = 0x1020f9;
            (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3ed);
            uVar21 = *(undefined8 *)(psVar19 + 4);
            *(undefined8 *)(puVar39 + -8) = 0x102107;
            func_0x(uVar21,5);
            goto code_r0x0010213f;
          }
          *(undefined8 *)(puVar39 + 0x20) = 0;
          *(undefined8 *)(puVar39 + -8) = 0x10212d;
          (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x87c);
        }
        uVar21 = *(undefined8 *)(psVar19 + 4);
        *(undefined8 *)(puVar39 + -8) = 0x10213b;
        func_0x(uVar21,5);
      }
    }
code_r0x0010213f:
    uVar43 = *(uint *)(psVar19 + 2);
    if (uVar43 < 9) {
      bVar25 = **(byte **)(psVar19 + 4) & 0xe;
joined_r0x00102179:
      if ((bVar25 == 0) || (bVar25 == 0xc)) {
        uVar43 = 9;
      }
    }
  }
  else {
    uVar43 = *(uint *)(psVar19 + 2);
    if (uVar43 == 0) {
      *(undefined8 *)(puVar39 + -8) = 0x102167;
      func_0x(puVar33);
      uVar43 = *(uint *)(psVar19 + 2);
    }
    if (uVar43 < 9) {
      bVar25 = **(byte **)(psVar19 + 4) & 0x1c;
      goto joined_r0x00102179;
    }
  }
  uVar26 = (short)(1 << ((byte)*(undefined2 *)(lVar29 + 4) & 2)) - 1;
  if (*(short *)(&stack0x000002c8 + lVar18) == 0) {
    uVar44 = *(uint *)(&stack0x000002cc + lVar18);
    if (uVar44 == 0) {
      uVar44 = *(uint *)(&stack0x000002d8 + lVar18);
      uVar48 = (ulonglong)uVar44;
      *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
      *(uint *)(&stack0x000002dc + lVar18) = uVar44;
      if ((**(byte **)(&stack0x000002d0 + lVar18) & 0x10) != 0) {
        uVar44 = uVar44 + 2 + (*(ushort *)(*(byte **)(&stack0x000002d0 + lVar18) + uVar48) + 7 >> 3)
        ;
        uVar48 = (ulonglong)uVar44;
        *(uint *)(&stack0x000002dc + lVar18) = uVar44;
      }
      if ((**(byte **)(&stack0x000002d0 + lVar18) & 0x20) == 0) {
        *(int *)(&stack0x000002cc + lVar18) = (int)uVar48;
        *(undefined2 *)(&stack0x000002e4 + lVar18) = 0;
        *(int *)(&stack0x000002e0 + lVar18) = (int)uVar48;
      }
      else {
        puVar33 = (ushort *)(*(byte **)(&stack0x000002d0 + lVar18) + uVar48);
        uVar42 = *puVar33;
        *(ushort *)(&stack0x000002e4 + lVar18) = uVar42;
        if (uVar42 == 0) {
          if ((((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
              (lVar23 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014de758 * 8) + 8 +
                         (ulonglong)*puRam00000000014de760), lVar23 != 0)) &&
             ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
              (*(char *)(lVar23 + 0x499) != '\0')))) {
            if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
              *(undefined8 *)(puVar39 + -8) = 0x102290;
              (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x1022b5;
              (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x80f);
            }
          }
          uVar21 = *(undefined8 *)(&stack0x000002d0 + lVar18);
          *(undefined8 *)(puVar39 + -8) = 0x1022c6;
          func_0x(uVar21,3);
          uVar42 = *(ushort *)(&stack0x000002e4 + lVar18);
        }
        uVar46 = *(int *)(&stack0x000002dc + lVar18) + 2 + (uint)uVar42 * 2;
        *(uint *)(&stack0x000002e0 + lVar18) = uVar46;
        if (0x1f9e < uVar46) {
          if (((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
             ((lVar23 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014de758 * 8) + 8 +
                         (ulonglong)*puRam00000000014de760), lVar23 != 0 &&
              ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
               (*(char *)(lVar23 + 0x499) != '\0')))))) {
            if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
              *(undefined8 *)(puVar39 + -8) = 0x10236d;
              (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x102392;
              (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x816);
            }
          }
          uVar21 = *(undefined8 *)(&stack0x000002d0 + lVar18);
          *(undefined8 *)(puVar39 + -8) = 0x1023a3;
          func_0x(uVar21,4);
          uVar42 = *(ushort *)(&stack0x000002e4 + lVar18);
          uVar46 = *(uint *)(&stack0x000002e0 + lVar18);
        }
        uVar37 = (ulonglong)uVar42;
        uVar44 = puVar33[uVar37] & 0x7fff;
        uVar48 = (ulonglong)uVar44;
        *(uint *)(&stack0x000002cc + lVar18) = uVar44;
        if (uVar44 < uVar46) {
          if ((((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
              (lVar23 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000014de758 * 8) + 8 +
                         (ulonglong)*puRam00000000014de760), lVar23 != 0)) &&
             ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
              (*(char *)(lVar23 + 0x499) != '\0')))) {
            if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
              *(undefined8 *)(puVar39 + -8) = 0x102449;
              (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x10246e;
              (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x81d);
            }
          }
          uVar21 = *(undefined8 *)(&stack0x000002d0 + lVar18);
          *(undefined8 *)(puVar39 + -8) = 0x10247f;
          func_0x(uVar21,4);
          uVar37 = (ulonglong)*(ushort *)(&stack0x000002e4 + lVar18);
          uVar46 = *(uint *)(&stack0x000002e0 + lVar18);
          uVar48 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
        }
        do {
          iVar17 = (int)uVar37;
          if (-1 < (short)puVar33[(ulonglong)(iVar17 - 1) + 1]) break;
          uVar36 = uVar46;
          if (((iVar17 != 1) &&
              (uVar36 = *(ushort *)
                         ((ulonglong)*(uint *)(&stack0x000002dc + lVar18) +
                          *(longlong *)(&stack0x000002d0 + lVar18) + -2 + (longlong)iVar17 * 2) &
                        0x7fff, uVar36 < uVar46)) ||
             ((*(ushort *)
                ((ulonglong)*(uint *)(&stack0x000002dc + lVar18) +
                 *(longlong *)(&stack0x000002d0 + lVar18) + uVar37 * 2) & 0x7fff) < uVar36)) {
            uVar21 = *(undefined8 *)(&stack0x000002d0 + lVar18);
            *(undefined8 *)(puVar39 + -8) = 0x1024ff;
            func_0x(uVar21,7);
            uVar37 = (ulonglong)*(ushort *)(&stack0x000002e4 + lVar18);
            uVar46 = *(uint *)(&stack0x000002e0 + lVar18);
            uVar48 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
          }
          uVar44 = (uint)uVar48;
          if ((uVar36 < uVar46) || (uVar44 < uVar36)) goto code_r0x0010283c;
          if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x000002d0 + lVar18)) == 5) {
            *(ushort *)(&stack0x000002ca + lVar18) = *(ushort *)(&stack0x000002ca + lVar18) | 2;
            uVar42 = *(ushort *)(&stack0x000002f4 + lVar18);
            *(short *)(&stack0x000002e4 + lVar18) = (short)uVar37 + -1;
            *(short *)(&stack0x000002f2 + lVar18) = (short)uVar36;
            lVar23 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(&stack0x000002d0 + lVar18);
            uVar31 = *(ushort *)(lVar23 + 2);
            if ((uVar31 >> 0xe & 1) == 0) {
              uVar42 = uVar42 & 0xc7ff;
            }
            else {
              uVar42 = uVar42 ^ (uVar31 ^ uVar42) & 0x3800;
            }
            *(ushort *)(&stack0x000002f4 + lVar18) = uVar42;
            *(ushort *)(&stack0x000002f4 + lVar18) =
                 (uVar42 ^ *(ushort *)(lVar23 + 2)) & 0x7ff ^ uVar42;
            break;
          }
          if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(&stack0x000002d0 + lVar18)) < 0x400)
          break;
          *(ushort *)(&stack0x000002ca + lVar18) = *(ushort *)(&stack0x000002ca + lVar18) | 1;
          uVar42 = (short)uVar37 - 1;
          uVar37 = (ulonglong)uVar42;
          *(ushort *)(&stack0x000002e4 + lVar18) = uVar42;
        } while (uVar42 != 0);
      }
      iVar17 = 0;
      if ((**(byte **)(&stack0x000002d0 + lVar18) & 0x40) == 0) {
        *(undefined4 *)(&stack0x000002ee + lVar18) = 0;
      }
      else {
        *(int *)(&stack0x000002ee + lVar18) = (int)uVar48;
        *(int *)(&stack0x000002cc + lVar18) = (int)uVar48 + 0xe;
        *(undefined8 *)(puVar39 + -8) = 0x102598;
        puVar20 = (ulonglong *)func_0x(&stack0x000002ca + lVar18);
        uVar31 = (ushort)(*puVar20 >> 0x30);
        uVar42 = uVar31;
        if ((((uint)(int)(short)uVar31 >> 1 ^ (int)(short)uVar31) & 0x2000) != 0) {
          uVar42 = uVar31 & 0xdfff;
          if ((uVar31 >> 0xe & 1) != 0) {
            uVar42 = uVar31 | 0x2000;
          }
        }
        if (uVar42 == 0xfffc) {
          iVar17 = (int)((*puVar20 >> 0x20 & 0xffff) >> 5);
        }
        uVar48 = (ulonglong)(uint)(*(int *)(&stack0x000002cc + lVar18) + iVar17);
        *(int *)(&stack0x000002cc + lVar18) = *(int *)(&stack0x000002cc + lVar18) + iVar17;
      }
      uVar44 = (uint)uVar48;
      if ((*(ulonglong *)(&stack0x000002e6 + lVar18) != 0) &&
         (*(ulonglong *)(&stack0x000002e6 + lVar18) <
          uVar48 + *(longlong *)(&stack0x000002d0 + lVar18))) {
        if (((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
           (((lVar23 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000014de758 * 8) + 8 +
                        (ulonglong)*puRam00000000014de760), lVar23 != 0 &&
             (lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0)) &&
            (*(char *)(lVar23 + 0x499) != '\0')))) {
          if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
            *(undefined8 *)(puVar39 + -8) = 0x10273f;
            (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar39 + 0x20) = 0;
            *(undefined8 *)(puVar39 + -8) = 0x102762;
            (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x877);
          }
        }
        uVar21 = *(undefined8 *)(&stack0x000002d0 + lVar18);
        *(undefined8 *)(puVar39 + -8) = 0x102773;
        func_0x(uVar21,0x12);
        uVar44 = *(uint *)(&stack0x000002cc + lVar18);
      }
      if (0x3f3b < uVar44 - 1) {
        if (((cRam0000000001f6fecb != '\0') || ((bRam0000000001f807d0 & 1) != 0)) &&
           ((lVar23 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000014de758 * 8) + 8 +
                       (ulonglong)*puRam00000000014de760), lVar23 != 0 &&
            ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
             (*(char *)(lVar23 + 0x499) != '\0')))))) {
          if ((cRam0000000001f6fdbb == '\0') && ((bRam0000000001f807d0 & 2) == 0)) {
            *(undefined8 *)(puVar39 + -8) = 0x102802;
            (*pcRam00000000014de6f8)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(puVar39 + 0x20) = 0;
            *(undefined8 *)(puVar39 + -8) = 0x102825;
            (*pcRam00000000014de6f0)(1,0x18608f8,0x19805c8,0x87c);
          }
        }
        uVar21 = *(undefined8 *)(&stack0x000002d0 + lVar18);
        *(undefined8 *)(puVar39 + -8) = 0x102836;
        func_0x(uVar21,5);
        uVar44 = *(uint *)(&stack0x000002cc + lVar18);
      }
    }
code_r0x0010283c:
    if ((8 < uVar44) ||
       (((**(byte **)(&stack0x000002d0 + lVar18) & 0xe) != 0 &&
        ((**(byte **)(&stack0x000002d0 + lVar18) & 0xe) != 0xc)))) {
      *(uint *)(&stack0xfffffffffffffffc + lVar18) = uVar44;
    }
  }
  else {
    uVar44 = *(uint *)(&stack0x000002cc + lVar18);
    if (uVar44 == 0) {
      *(undefined8 *)(puVar39 + -8) = 0x102875;
      func_0x(&stack0x000002ca + lVar18);
      uVar44 = *(uint *)(&stack0x000002cc + lVar18);
    }
    if ((uVar44 < 9) &&
       (((**(byte **)(&stack0x000002d0 + lVar18) & 0x1c) == 0 ||
        ((**(byte **)(&stack0x000002d0 + lVar18) & 0x1c) == 0xc)))) {
      *(undefined4 *)(&stack0xfffffffffffffffc + lVar18) = 9;
    }
    else {
      *(uint *)(&stack0xfffffffffffffffc + lVar18) = uVar44;
    }
  }
  sVar35 = 1 << ((byte)*(undefined2 *)(lVar29 + 4) & 2);
  iVar17 = (uint)(ushort)((short)uVar43 + uVar26 & ~uVar26) -
           (uint)(ushort)(sVar35 + -1 + (short)*(undefined4 *)(&stack0xfffffffffffffffc + lVar18) &
                         -sVar35);
  if (iVar17 < 0) {
code_r0x00102925:
    lVar29 = *(longlong *)(&stack0x00000068 + lVar18);
    *(undefined8 *)(puVar39 + -8) = 0x102938;
    func_0x(&stack0x00000378 + lVar18,lVar29);
    puVar41 = *(undefined4 **)(&stack0x00000078 + lVar18);
    lVar23 = 2;
    puVar24 = puVar41;
    puVar30 = (undefined4 *)(&stack0x000000c8 + lVar18);
    do {
      uVar32 = puVar24[1];
      uVar7 = puVar24[2];
      uVar8 = puVar24[3];
      uVar9 = puVar24[4];
      uVar10 = puVar24[5];
      uVar11 = puVar24[6];
      uVar12 = puVar24[7];
      *puVar30 = *puVar24;
      puVar30[1] = uVar32;
      puVar30[2] = uVar7;
      puVar30[3] = uVar8;
      uVar32 = puVar24[8];
      uVar7 = puVar24[9];
      uVar8 = puVar24[10];
      uVar13 = puVar24[0xb];
      puVar30[4] = uVar9;
      puVar30[5] = uVar10;
      puVar30[6] = uVar11;
      puVar30[7] = uVar12;
      uVar9 = puVar24[0xc];
      uVar10 = puVar24[0xd];
      uVar11 = puVar24[0xe];
      uVar12 = puVar24[0xf];
      puVar30[8] = uVar32;
      puVar30[9] = uVar7;
      puVar30[10] = uVar8;
      puVar30[0xb] = uVar13;
      uVar32 = puVar24[0x10];
      uVar7 = puVar24[0x11];
      uVar8 = puVar24[0x12];
      uVar13 = puVar24[0x13];
      puVar30[0xc] = uVar9;
      puVar30[0xd] = uVar10;
      puVar30[0xe] = uVar11;
      puVar30[0xf] = uVar12;
      uVar10 = puVar24[0x14];
      uVar11 = puVar24[0x15];
      uVar12 = puVar24[0x16];
      uVar14 = puVar24[0x17];
      puVar30[0x10] = uVar32;
      puVar30[0x11] = uVar7;
      puVar30[0x12] = uVar8;
      puVar30[0x13] = uVar13;
      uVar32 = puVar24[0x18];
      uVar7 = puVar24[0x19];
      uVar8 = puVar24[0x1a];
      uVar9 = puVar24[0x1b];
      puVar30[0x14] = uVar10;
      puVar30[0x15] = uVar11;
      puVar30[0x16] = uVar12;
      puVar30[0x17] = uVar14;
      uVar10 = puVar24[0x1c];
      uVar11 = puVar24[0x1d];
      uVar12 = puVar24[0x1e];
      uVar13 = puVar24[0x1f];
      puVar24 = puVar24 + 0x20;
      puVar30[0x18] = uVar32;
      puVar30[0x19] = uVar7;
      puVar30[0x1a] = uVar8;
      puVar30[0x1b] = uVar9;
      puVar30[0x1c] = uVar10;
      puVar30[0x1d] = uVar11;
      puVar30[0x1e] = uVar12;
      puVar30[0x1f] = uVar13;
      lVar23 = lVar23 + -1;
      puVar30 = puVar30 + 0x20;
    } while (lVar23 != 0);
    uVar21 = *(undefined8 *)(&stack0x00000070 + lVar18);
    *(undefined8 *)(puVar39 + 0x20) = *(undefined8 *)(&stack0x00000090 + lVar18);
    *(undefined8 *)(puVar39 + -8) = 0x1029d8;
    func_0x(uVar21,&stack0x00000098 + lVar18,&stack0x000000c8 + lVar18);
    uVar32 = *(undefined4 *)(&stack0x00000058 + lVar18);
    *(undefined8 *)(puVar39 + -8) = 0x1029ea;
    func_0x(uVar21,uVar32,&stack0x000003a8 + lVar18);
    *(undefined8 *)(puVar39 + -8) = 0x1029f2;
    func_0x(uVar21);
    lVar23 = 2;
    puVar24 = puVar41;
    puVar30 = (undefined4 *)(&stack0x000001c8 + lVar18);
    do {
      uVar32 = puVar24[1];
      uVar7 = puVar24[2];
      uVar8 = puVar24[3];
      uVar9 = puVar24[4];
      uVar10 = puVar24[5];
      uVar11 = puVar24[6];
      uVar12 = puVar24[7];
      *puVar30 = *puVar24;
      puVar30[1] = uVar32;
      puVar30[2] = uVar7;
      puVar30[3] = uVar8;
      uVar32 = puVar24[8];
      uVar7 = puVar24[9];
      uVar8 = puVar24[10];
      uVar13 = puVar24[0xb];
      puVar30[4] = uVar9;
      puVar30[5] = uVar10;
      puVar30[6] = uVar11;
      puVar30[7] = uVar12;
      uVar9 = puVar24[0xc];
      uVar10 = puVar24[0xd];
      uVar11 = puVar24[0xe];
      uVar12 = puVar24[0xf];
      puVar30[8] = uVar32;
      puVar30[9] = uVar7;
      puVar30[10] = uVar8;
      puVar30[0xb] = uVar13;
      uVar32 = puVar24[0x10];
      uVar7 = puVar24[0x11];
      uVar8 = puVar24[0x12];
      uVar13 = puVar24[0x13];
      puVar30[0xc] = uVar9;
      puVar30[0xd] = uVar10;
      puVar30[0xe] = uVar11;
      puVar30[0xf] = uVar12;
      uVar10 = puVar24[0x14];
      uVar11 = puVar24[0x15];
      uVar12 = puVar24[0x16];
      uVar14 = puVar24[0x17];
      puVar30[0x10] = uVar32;
      puVar30[0x11] = uVar7;
      puVar30[0x12] = uVar8;
      puVar30[0x13] = uVar13;
      uVar32 = puVar24[0x18];
      uVar7 = puVar24[0x19];
      uVar8 = puVar24[0x1a];
      uVar9 = puVar24[0x1b];
      puVar30[0x14] = uVar10;
      puVar30[0x15] = uVar11;
      puVar30[0x16] = uVar12;
      puVar30[0x17] = uVar14;
      uVar10 = puVar24[0x1c];
      uVar11 = puVar24[0x1d];
      uVar12 = puVar24[0x1e];
      uVar13 = puVar24[0x1f];
      puVar24 = puVar24 + 0x20;
      puVar30[0x18] = uVar32;
      puVar30[0x19] = uVar7;
      puVar30[0x1a] = uVar8;
      puVar30[0x1b] = uVar9;
      puVar30[0x1c] = uVar10;
      puVar30[0x1d] = uVar11;
      puVar30[0x1e] = uVar12;
      puVar30[0x1f] = uVar13;
      lVar23 = lVar23 + -1;
      puVar30 = puVar30 + 0x20;
    } while (lVar23 != 0);
    *(undefined8 *)(puVar39 + 0x20) = 0;
    *(undefined8 *)(puVar39 + -8) = 0x102a63;
    func_0x(plVar49,0,&stack0x000001c8 + lVar18,0);
    *(undefined8 *)(puVar39 + -8) = 0x102a72;
    func_0x(&stack0x000003a8 + lVar18,lVar29);
    *(undefined8 *)(puVar39 + -8) = 0x102a7f;
    func_0x(plVar49,0,0);
    if ((plVar49[2] != CONCAT44(uRam0000000001f80e8c,uRam0000000001f80e88)) ||
       (plVar49[3] != CONCAT44(uRam0000000001f80e94,uRam0000000001f80e90))) {
      if ((*(byte *)(plVar49 + 0xe) & 2) != 0) {
        *(undefined8 *)(puVar39 + -8) = 0x102aac;
        iVar17 = func_0x(plVar49 + 0xf);
        if (iVar17 != 0) {
          *(longlong *)(*plVar49 + 0x30) = *(longlong *)(*plVar49 + 0x30) + -1;
        }
      }
      *(undefined *)(plVar49 + 0xe) = 0;
      *(undefined4 *)((longlong)plVar49 + 0x6c) = 0;
      *(undefined4 *)(plVar49 + 0x11) = 0;
      if ((*(byte *)(plVar49 + 0x14) & 2) != 0) {
        *(undefined8 *)(puVar39 + -8) = 0x102adb;
        iVar17 = func_0x(plVar49 + 0x15);
        if (iVar17 != 0) {
          *(longlong *)(*plVar49 + 0x30) = *(longlong *)(*plVar49 + 0x30) + -1;
        }
      }
      *(undefined *)(plVar49 + 0x14) = 0;
      *(undefined4 *)((longlong)plVar49 + 0x9c) = 0;
      *(undefined4 *)(plVar49 + 0x17) = 0;
      if (plVar49[5] != 0) {
        *(undefined *)((longlong)plVar49 + 0x36) = 0;
        plVar49[5] = 0;
        *(undefined2 *)((longlong)plVar49 + 0x34) = 0;
        *(undefined4 *)(plVar49[2] + 0x48) = 0;
      }
      uVar21 = *(undefined8 *)*plVar49;
      *(undefined8 *)(puVar39 + -8) = 0x102b24;
      func_0x(uVar21,plVar49 + 2);
      uVar9 = uRam0000000001f80e94;
      uVar8 = uRam0000000001f80e90;
      uVar7 = uRam0000000001f80e8c;
      uVar32 = uRam0000000001f80e88;
      *(undefined4 *)(plVar49 + 0x4e) = 0xffffffff;
      *(undefined4 *)(plVar49 + 4) = 0xffffffff;
      *(undefined4 *)(plVar49 + 2) = uVar32;
      *(undefined4 *)((longlong)plVar49 + 0x14) = uVar7;
      *(undefined4 *)(plVar49 + 3) = uVar8;
      *(undefined4 *)((longlong)plVar49 + 0x1c) = uVar9;
      *(undefined4 *)(plVar49 + 0x48) = 0;
      plVar49[0x4b] = 0;
      plVar49[0x4a] = 0;
      plVar49[0x4c] = 0;
      *(undefined2 *)((longlong)plVar49 + 0x274) = 0xffff;
      *(undefined8 *)((longlong)plVar49 + 0x276) = 0;
      *(undefined4 *)(plVar49 + 0x18) = 2;
    }
  }
  else {
    piVar6 = *(int **)(&stack0x00000088 + lVar18);
    if (piVar6 == (int *)0x0) {
      uVar43 = (uint)*(ushort *)(lVar29 + 0x1c);
    }
    else {
      uVar43 = (uint)*(ushort *)(lVar29 + 0x26);
      if (((*(short *)(piVar6 + 1) == *(short *)(lVar29 + 0x38)) &&
          (*piVar6 == *(int *)(lVar29 + 0x34))) && (cVar15 == '\0')) {
        uVar43 = (uint)*(ushort *)(lVar29 + 0x26) - (uint)*(ushort *)(lVar29 + 0x32);
      }
      if (uVar43 < *(ushort *)(lVar29 + 0x1c)) {
        uVar43 = *(ushort *)(lVar29 + 0x1c) - uVar43;
      }
      else {
        uVar43 = 0;
      }
    }
    if (iVar17 <= (int)uVar43) goto code_r0x00102925;
    puVar41 = *(undefined4 **)(&stack0x00000078 + lVar18);
    lVar29 = *(longlong *)(&stack0x00000068 + lVar18);
  }
  bVar25 = (*pbVar3 ^ *(byte *)puVar41) & 4 ^ *(byte *)puVar41;
  *(byte *)puVar41 = (bVar25 ^ *pbVar3) & 1 ^ bVar25;
  plVar49 = (longlong *)(*(longlong *)(lVar29 + 0x30) + 0x198);
  *plVar49 = *plVar49 + 1;
LAB_:
  uVar48 = *(ulonglong *)(&stack0x00002378 + lVar18);
  *(undefined8 *)(puVar39 + -8) = 0x102bb8;
  func_0x(uVar48 ^ (ulonglong)pbVar3);
  return;
}

