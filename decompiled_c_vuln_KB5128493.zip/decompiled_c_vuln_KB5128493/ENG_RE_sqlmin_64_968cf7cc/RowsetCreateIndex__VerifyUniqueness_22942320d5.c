
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,longlong param_3)

{
  ushort *puVar1;
  longlong *plVar2;
  short *psVar3;
  ushort uVar4;
  int iVar5;
  ulonglong *puVar6;
  uint *puVar7;
  uint uVar8;
  ulonglong uVar9;
  byte bVar10;
  ushort uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  ushort *puVar16;
  uint *puVar17;
  ulonglong uVar18;
  uint *puVar19;
  short sVar20;
  uint *puVar21;
  longlong lVar22;
  byte *pbVar23;
  uint **ppuVar24;
  undefined2 *puVar25;
  int iVar26;
  longlong unaff_GS_OFFSET;
  undefined auStack_f8 [32];
  undefined8 uStack_d8;
  longlong *plStack_d0;
  uint *puStack_c8;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  uint uStack_a8;
  uint uStack_a4;
  uint auStack_a0 [2];
  longlong lStack_98;
  longlong lStack_90;
  short *psStack_88;
  longlong lStack_80;
  byte abStack_78 [4];
  uint uStack_74;
  longlong lStack_70;
  undefined auStack_68 [8];
  undefined8 uStack_60;
  uint *puStack_58;
  undefined2 uStack_50;
  undefined2 auStack_4e [3];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_f8;
  lStack_98 = *(longlong *)(param_1 + 0x48);
  lStack_70 = param_1 + 0x2c8;
  ppuVar24 = &puStack_58;
  puVar25 = auStack_4e;
  puVar1 = (ushort *)(param_1 + 0x192);
  iVar26 = *(int *)(**(longlong **)(*(longlong *)(lStack_98 + 8) + 0x160) + 0x1c);
  iVar5 = iVar26 + -1;
  if ((*(byte *)(*(longlong *)(lStack_98 + 8) + 0x106) & 0x40) == 0) {
    iVar5 = iVar26;
  }
  uStack_60 = *(undefined8 *)(param_1 + 0x198);
  uVar14 = (uint)(iVar5 != 0);
  uStack_a8 = uVar14;
  lStack_90 = param_1;
  psStack_88 = param_2;
  lStack_80 = param_3;
  if (*(short *)(param_1 + 400) == 0) {
    if (*(int *)(param_1 + 0x194) == 0) {
      pbVar23 = *(byte **)(param_1 + 0x198);
      uVar12 = *(uint *)(param_1 + 0x1a0);
      uVar15 = (ulonglong)uVar12;
      *puVar1 = 0;
      *(uint *)(param_1 + 0x1a4) = uVar12;
      bVar10 = *pbVar23;
      if ((bVar10 & 0x10) != 0) {
        uVar12 = uVar12 + 2 + (*(ushort *)(pbVar23 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar12;
        *(uint *)(param_1 + 0x1a4) = uVar12;
        bVar10 = *pbVar23;
      }
      if ((bVar10 & 0x20) == 0) {
        *(int *)(param_1 + 0x194) = (int)uVar15;
        *(undefined2 *)(param_1 + 0x1ac) = 0;
        *(int *)(param_1 + 0x1a8) = (int)uVar15;
      }
      else {
        puVar16 = (ushort *)(pbVar23 + uVar15);
        uVar4 = *puVar16;
        *(ushort *)(param_1 + 0x1ac) = uVar4;
        if (uVar4 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar22 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar22 != 0)) &&
             ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
              (*(char *)(lVar22 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_d8 = (uint *)0x0;
              (*_DAT_)(1,0xa6ed68,0xb8ea38,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 0x198),3);
          uVar15 = (ulonglong)*(uint *)(param_1 + 0x1a4);
          uVar4 = *(ushort *)(param_1 + 0x1ac);
        }
        uVar12 = (int)uVar15 + (uVar4 + 1) * 2;
        *(uint *)(param_1 + 0x1a8) = uVar12;
        if (0x1f9e < uVar12) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar22 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar22 != 0 &&
              ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
               (*(char *)(lVar22 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d8 = (uint *)0x0;
              (*_DAT_)(1,0xa6ed68,0xb8ea38,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 0x198),4);
          uVar4 = *(ushort *)(param_1 + 0x1ac);
          uVar12 = *(uint *)(param_1 + 0x1a8);
        }
        uVar9 = (ulonglong)uVar4;
        uVar13 = puVar16[uVar9] & 0x7fff;
        *(uint *)(param_1 + 0x194) = uVar13;
        if (uVar13 < uVar12) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar22 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar22 != 0)) &&
             ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
              (*(char *)(lVar22 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d8 = (uint *)0x0;
              (*_DAT_)(1,0xa6ed68,0xb8ea38,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 0x198),4);
          uVar9 = (ulonglong)*(ushort *)(param_1 + 0x1ac);
          uVar13 = *(uint *)(param_1 + 0x194);
        }
        uVar15 = (ulonglong)uVar13;
        if ((short)puVar16[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
          pbVar23 = *(byte **)(param_1 + 0x198);
          do {
            if ((int)uVar9 == 1) {
              uVar12 = *(uint *)(param_1 + 0x1a8);
              uVar13 = uVar12;
LAB_:
              if ((*(ushort *)(pbVar23 + uVar9 * 2 + (ulonglong)*(uint *)(param_1 + 0x1a4)) & 0x7fff
                  ) < uVar12) goto LAB_;
            }
            else {
              uVar13 = *(uint *)(param_1 + 0x1a8);
              uVar12 = *(ushort *)
                        (pbVar23 + uVar9 * 2 + ((ulonglong)*(uint *)(param_1 + 0x1a4) - 2)) & 0x7fff
              ;
              if (uVar13 <= uVar12) goto LAB_;
LAB_:
              func_0x(pbVar23,7);
              uVar13 = *(uint *)(param_1 + 0x1a8);
            }
            if ((uVar12 < uVar13) ||
               (uVar15 = (ulonglong)*(uint *)(param_1 + 0x194), *(uint *)(param_1 + 0x194) < uVar12)
               ) goto LAB_;
            pbVar23 = *(byte **)(param_1 + 0x198);
            if (*(ushort *)(pbVar23 + uVar12) == 5) {
              *puVar1 = *puVar1 | 2;
              *(short *)(param_1 + 0x1ac) = *(short *)(param_1 + 0x1ac) + -1;
              uVar4 = *(ushort *)(param_1 + 0x1bc) & 0xc7ff;
              *(short *)(param_1 + 0x1ba) = (short)uVar12;
              lVar22 = (ulonglong)(uVar12 & 0xffff) + *(longlong *)(param_1 + 0x198);
              if ((*(ushort *)(lVar22 + 2) >> 0xe & 1) != 0) {
                uVar4 = *(ushort *)(lVar22 + 2) & 0x3800 | uVar4;
              }
              *(ushort *)(param_1 + 0x1bc) = uVar4;
              *(ushort *)(param_1 + 0x1bc) = (uVar4 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar4;
              uVar15 = (ulonglong)*(uint *)(lStack_90 + 0x194);
              goto LAB_;
            }
            if (*(ushort *)(pbVar23 + uVar12) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar4 = *(short *)(param_1 + 0x1ac) - 1;
            *(ushort *)(param_1 + 0x1ac) = uVar4;
            if (uVar4 == 0) goto LAB_;
            uVar9 = (ulonglong)uVar4;
          } while ((short)puVar16[(ulonglong)(uVar4 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar23 = *(byte **)(param_1 + 0x198);
        }
      }
      iVar26 = 0;
      if ((*pbVar23 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x1b6) = 0;
      }
      else {
        *(int *)(param_1 + 0x1b6) = (int)uVar15;
        *(int *)(param_1 + 0x194) = (int)uVar15 + 0xe;
        puVar6 = (ulonglong *)func_0x(puVar1);
        uVar11 = (ushort)(*puVar6 >> 0x30);
        uVar4 = uVar11;
        if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
          uVar4 = uVar11 & 0xdfff;
          if ((uVar11 >> 0xe & 1) != 0) {
            uVar4 = uVar11 | 0x2000;
          }
        }
        if (uVar4 == 0xfffc) {
          iVar26 = (int)((*puVar6 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_1 + 0x194) = *(int *)(param_1 + 0x194) + iVar26;
        uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
      }
      iVar26 = (int)uVar15;
      if ((*(ulonglong *)(param_1 + 0x1ae) != 0) &&
         (*(ulonglong *)(param_1 + 0x1ae) < uVar15 + *(longlong *)(param_1 + 0x198))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar22 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar22 != 0 &&
             (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
            (*(char *)(lVar22 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_d8 = (uint *)0x0;
            (*_DAT_)(1,0xa6ed68,0xb8ea38,0x877);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 0x198),0x12);
        iVar26 = *(int *)(param_1 + 0x194);
      }
      if (0x3f3b < iVar26 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar22 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar22 != 0 &&
            ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
             (*(char *)(lVar22 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
            func_0x(*(undefined8 *)(param_1 + 0x198),5);
            goto LAB_;
          }
          uStack_d8 = (uint *)0x0;
          (*_DAT_)(1,0xa6ed68,0xb8ea38,0x87c);
        }
        func_0x(*(undefined8 *)(param_1 + 0x198),5);
      }
    }
LAB_:
    uVar12 = *(uint *)(param_1 + 0x194);
    if (uVar12 < 9) {
      bVar10 = **(byte **)(param_1 + 0x198) & 0xe;
joined_r0x001006fd:
      if ((bVar10 == 0) || (bVar10 == 0xc)) {
        uVar12 = 9;
      }
    }
  }
  else {
    uVar12 = *(uint *)(param_1 + 0x194);
    if (uVar12 == 0) {
      func_0x(puVar1);
      uVar12 = *(uint *)(param_1 + 0x194);
    }
    if (uVar12 < 9) {
      bVar10 = **(byte **)(param_1 + 0x198) & 0x1c;
      goto joined_r0x001006fd;
    }
  }
  uVar15 = 0;
  uStack_50 = (undefined2)uVar12;
  if (uVar14 != 0) {
    do {
      puVar19 = (uint *)0x0;
      lVar22 = **(longlong **)(*(longlong *)(lStack_98 + 8) + 0x160);
      puVar7 = *(uint **)(lVar22 + 0x38);
      puVar21 = (uint *)(lVar22 + 0x30);
      if (puVar7 == puVar21) {
        puVar7 = puVar19;
      }
      puVar17 = puVar19;
      if (puVar7 != (uint *)0x0) {
        puVar17 = puVar7 + -0x58;
      }
      iVar26 = (int)uVar15;
      if (iVar26 != 0) {
        do {
          puVar7 = *(uint **)(puVar17 + 0x5a);
          if (*(uint **)(puVar17 + 0x5a) == puVar21) {
            puVar7 = puVar19;
          }
          puVar17 = puVar19;
          if (puVar7 != (uint *)0x0) {
            puVar17 = puVar7 + -0x58;
          }
          uVar15 = uVar15 - 1;
        } while (uVar15 != 0);
      }
      bVar10 = *(byte *)(puVar17 + 8);
      if (*(short *)(lStack_90 + 400) == 0) {
        uVar13 = *puVar17;
        if ((uVar13 & 0xc0000000) == 0x80000000) {
          iVar5 = func_0x(puVar1);
          if (iVar5 != 0) {
            puVar19 = (uint *)func_0x(param_1 + 0x1ba,puVar17,&uStack_a4,&uStack_74);
            uVar12 = uStack_a4;
            goto LAB_;
          }
LAB_:
          uStack_a4 = 0;
          uVar12 = uStack_a4;
        }
        else {
          if (((bVar10 & 2) != 0) || ((*(byte *)((longlong)puVar17 + 6) & 0x10) != 0)) {
            pbVar23 = *(byte **)(param_1 + 0x198);
            if ((*pbVar23 & 0x10) == 0) {
              if ((1 << (*pbVar23 & 0xe) & 0x1105U) != 0) goto LAB_;
              puVar7 = (uint *)0x1;
              puVar21 = puVar19;
LAB_:
              uVar12 = (uint)puVar21;
              iVar5 = (int)puVar7;
              if ((bVar10 & 2) != 0) goto LAB_;
            }
            else {
              uVar12 = *(uint *)(param_1 + 0x1a0);
              if ((int)uVar12 <= (int)uVar13) {
LAB_:
                puVar21 = (uint *)(ulonglong)(~(uint)(*(ushort *)((longlong)puVar17 + 6) >> 4) & 1);
                puVar7 = puVar19;
                goto LAB_;
              }
              if ((uint)*(ushort *)(pbVar23 + uVar12) < (uint)*(ushort *)(puVar17 + 1))
              goto LAB_;
              if ((bVar10 & 2) == 0) goto LAB_;
              uVar8 = *(ushort *)(puVar17 + 1) - 1;
              iVar5 = 1;
              uVar12 = pbVar23[(ulonglong)uVar12 + (ulonglong)(uVar8 >> 3) + 2] >> ((byte)uVar8 & 7)
                       & 1;
LAB_:
              if (uVar12 != 0) goto LAB_;
            }
            if ((iVar5 == 0) && ((*(byte *)((longlong)puVar17 + 6) & 0x10) != 0)) {
              puVar19 = *(uint **)(puVar17 + 2) + 1;
              uVar12 = **(uint **)(puVar17 + 2);
              goto LAB_;
            }
          }
LAB_:
          if ((int)uVar13 < 0) {
            if (*(int *)(param_1 + 0x194) == 0) {
              pbVar23 = *(byte **)(param_1 + 0x198);
              uVar14 = *(uint *)(param_1 + 0x1a0);
              uVar15 = (ulonglong)uVar14;
              *puVar1 = 0;
              *(uint *)(param_1 + 0x1a4) = uVar14;
              bVar10 = *pbVar23;
              if ((bVar10 & 0x10) != 0) {
                uVar14 = uVar14 + 2 + (*(ushort *)(pbVar23 + uVar15) + 7 >> 3);
                uVar15 = (ulonglong)uVar14;
                *(uint *)(param_1 + 0x1a4) = uVar14;
                bVar10 = *pbVar23;
              }
              if ((bVar10 & 0x20) == 0) {
                *(int *)(param_1 + 0x194) = (int)uVar15;
                *(undefined2 *)(param_1 + 0x1ac) = 0;
                *(int *)(param_1 + 0x1a8) = (int)uVar15;
              }
              else {
                puVar16 = (ushort *)(pbVar23 + uVar15);
                uVar4 = *puVar16;
                *(ushort *)(param_1 + 0x1ac) = uVar4;
                if (uVar4 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0)) &&
                     ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                      (*(char *)(lVar22 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0xa6ed68,0xb8ea38,0x80f);
                    }
                  }
                  func_0x(*(undefined8 *)(param_1 + 0x198),3);
                  uVar15 = (ulonglong)*(uint *)(param_1 + 0x1a4);
                  uVar4 = *(ushort *)(param_1 + 0x1ac);
                }
                uVar14 = (int)uVar15 + (uVar4 + 1) * 2;
                *(uint *)(param_1 + 0x1a8) = uVar14;
                if (0x1f9e < uVar14) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0 &&
                      ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                       (*(char *)(lVar22 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0xa6ed68,0xb8ea38,0x816);
                    }
                  }
                  func_0x(*(undefined8 *)(param_1 + 0x198),4);
                  uVar4 = *(ushort *)(param_1 + 0x1ac);
                  uVar14 = *(uint *)(param_1 + 0x1a8);
                }
                uVar15 = (ulonglong)uVar4;
                uVar4 = puVar16[uVar15];
                *(uint *)(param_1 + 0x194) = uVar4 & 0x7fff;
                if ((uVar4 & 0x7fff) < uVar14) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0)) &&
                     ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                      (*(char *)(lVar22 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0xa6ed68,0xb8ea38,0x81d);
                    }
                  }
                  func_0x(*(undefined8 *)(param_1 + 0x198),4);
                  uVar15 = (ulonglong)*(ushort *)(param_1 + 0x1ac);
                }
                if ((short)puVar16[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                  pbVar23 = *(byte **)(param_1 + 0x198);
                  do {
                    if ((int)uVar15 == 1) {
                      uVar14 = *(uint *)(param_1 + 0x1a8);
                      uVar12 = uVar14;
LAB_:
                      if ((*(ushort *)(pbVar23 + uVar15 * 2 + (ulonglong)*(uint *)(param_1 + 0x1a4))
                          & 0x7fff) < uVar14) goto LAB_;
                    }
                    else {
                      uVar12 = *(uint *)(param_1 + 0x1a8);
                      uVar14 = *(ushort *)
                                (pbVar23 + uVar15 * 2 + ((ulonglong)*(uint *)(param_1 + 0x1a4) - 2))
                               & 0x7fff;
                      if (uVar12 <= uVar14) goto LAB_;
LAB_:
                      func_0x(pbVar23,7);
                      uVar12 = *(uint *)(param_1 + 0x1a8);
                    }
                    if ((uVar14 < uVar12) || (*(uint *)(param_1 + 0x194) < uVar14))
                    goto LAB_;
                    pbVar23 = *(byte **)(param_1 + 0x198);
                    if (*(ushort *)(pbVar23 + uVar14) == 5) {
                      *puVar1 = *puVar1 | 2;
                      *(short *)(param_1 + 0x1ac) = *(short *)(param_1 + 0x1ac) + -1;
                      uVar4 = *(ushort *)(param_1 + 0x1bc) & 0xc7ff;
                      *(short *)(param_1 + 0x1ba) = (short)uVar14;
                      lVar22 = (ulonglong)(uVar14 & 0xffff) + *(longlong *)(param_1 + 0x198);
                      if ((*(ushort *)(lVar22 + 2) >> 0xe & 1) != 0) {
                        uVar4 = *(ushort *)(lVar22 + 2) & 0x3800 | uVar4;
                      }
                      *(ushort *)(param_1 + 0x1bc) = uVar4;
                      *(ushort *)(param_1 + 0x1bc) =
                           (uVar4 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar4;
                      goto LAB_;
                    }
                    if (*(ushort *)(pbVar23 + uVar14) < 0x400) goto LAB_;
                    *puVar1 = *puVar1 | 1;
                    uVar4 = *(short *)(param_1 + 0x1ac) - 1;
                    *(ushort *)(param_1 + 0x1ac) = uVar4;
                    if (uVar4 == 0) goto LAB_;
                    uVar15 = (ulonglong)uVar4;
                  } while ((short)puVar16[(ulonglong)(uVar4 - 1) + 1] < 0);
                  uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
                }
                else {
LAB_:
                  uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
                  pbVar23 = *(byte **)(param_1 + 0x198);
                }
              }
              iVar5 = 0;
              if ((*pbVar23 & 0x40) == 0) {
                *(undefined4 *)(param_1 + 0x1b6) = 0;
              }
              else {
                *(int *)(param_1 + 0x1b6) = (int)uVar15;
                *(int *)(param_1 + 0x194) = (int)uVar15 + 0xe;
                puVar6 = (ulonglong *)func_0x(puVar1);
                uVar11 = (ushort)(*puVar6 >> 0x30);
                uVar4 = uVar11;
                if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
                  uVar4 = uVar11 & 0xdfff;
                  if ((uVar11 >> 0xe & 1) != 0) {
                    uVar4 = uVar11 | 0x2000;
                  }
                }
                if (uVar4 == 0xfffc) {
                  iVar5 = (int)((*puVar6 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(param_1 + 0x194) = *(int *)(param_1 + 0x194) + iVar5;
                uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
              }
              iVar5 = (int)uVar15;
              if ((*(ulonglong *)(param_1 + 0x1ae) != 0) &&
                 (*(ulonglong *)(param_1 + 0x1ae) < uVar15 + *(longlong *)(param_1 + 0x198))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar22 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                     lVar22 != 0 && (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
                    (*(char *)(lVar22 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_d8 = (uint *)0x0;
                    (*_DAT_)(1,0xa6ed68,0xb8ea38,0x877);
                  }
                }
                func_0x(*(undefined8 *)(param_1 + 0x198),0x12);
                iVar5 = *(int *)(param_1 + 0x194);
              }
              if (0x3f3b < iVar5 - 1U) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar22 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar22 != 0 &&
                    ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                     (*(char *)(lVar22 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_d8 = (uint *)0x0;
                    (*_DAT_)(1,0xa6ed68,0xb8ea38,0x87c);
                  }
                }
                func_0x(*(undefined8 *)(param_1 + 0x198),5);
              }
            }
LAB_:
            sVar20 = -*(short *)puVar17;
            uVar14 = uStack_a8;
            if ((*(byte *)((longlong)puVar17 + 6) & 0x10) != 0) {
              bVar10 = **(byte **)(param_1 + 0x198);
              if ((bVar10 & 0x10) == 0) {
                if ((1 << (bVar10 & 0xe) & 0x1105U) != 0) {
LAB_:
                  puVar19 = *(uint **)(puVar17 + 2) + 1;
                  uVar12 = **(uint **)(puVar17 + 2);
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(param_1 + 0x1a0) <= (int)*puVar17) ||
                      (*(ushort *)(*(byte **)(param_1 + 0x198) + *(uint *)(param_1 + 0x1a0)) <
                       *(ushort *)(puVar17 + 1))) goto LAB_;
            }
            puVar19 = *(uint **)(param_1 + 0x198);
            lVar22 = (longlong)sVar20;
            if ((uint)*(ushort *)(param_1 + 0x1ac) < (uint)(int)sVar20) {
              uStack_a4 = 0;
              uVar12 = uStack_a4;
            }
            else {
              uVar14 = *(uint *)(param_1 + 0x1a4);
              if (sVar20 == 1) {
                uVar13 = *(ushort *)((longlong)puVar19 + lVar22 * 2 + (ulonglong)uVar14) & 0x7fff;
                uVar12 = *(uint *)(lStack_90 + 0x1a8);
LAB_:
                if (uVar13 < uVar12) goto LAB_;
              }
              else {
                uVar12 = *(ushort *)((longlong)puVar19 + lVar22 * 2 + ((ulonglong)uVar14 - 2)) &
                         0x7fff;
                uVar13 = *(ushort *)((longlong)puVar19 + lVar22 * 2 + (ulonglong)uVar14) & 0x7fff;
                if (*(uint *)(lStack_90 + 0x1a8) <= uVar12) goto LAB_;
LAB_:
                func_0x(puVar19,7);
                puVar19 = *(uint **)(param_1 + 0x198);
              }
              puVar19 = (uint *)((longlong)puVar19 + (ulonglong)uVar12);
              uVar14 = uStack_a8;
              uVar12 = uVar13 - uVar12;
            }
          }
          else {
            uVar4 = *(ushort *)((longlong)puVar17 + 6);
            if ((uVar4 & 8) == 0) {
              uVar8 = (uint)*(ushort *)(puVar17 + 0xe);
              if ((uVar4 & 0x10) != 0) {
                bVar10 = **(byte **)(param_1 + 0x198);
                if ((bVar10 & 0x10) == 0) {
                  if ((1 << (bVar10 & 0xe) & 0x1105U) != 0) {
LAB_:
                    uVar12 = **(uint **)(puVar17 + 2);
                    puVar19 = *(uint **)(puVar17 + 2) + 1;
                    if ((uVar8 != 0) && (uVar12 != uVar8)) {
                      uStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0xc1cad8,0xc1b4d8,0x381);
                    }
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(param_1 + 0x1a0) <= (int)uVar13) ||
                        (*(ushort *)(*(byte **)(param_1 + 0x198) + *(uint *)(param_1 + 0x1a0)) <
                         *(ushort *)(puVar17 + 1))) goto LAB_;
              }
              puVar19 = (uint *)((longlong)(int)*puVar17 + *(longlong *)(param_1 + 0x198));
              uVar12 = uVar8;
            }
            else {
              puVar19 = (uint *)0x7f37a4;
              uStack_a4 = 1;
              uVar12 = uStack_a4;
              if ((*(byte *)((longlong)(int)uVar13 + *(longlong *)(param_1 + 0x198)) &
                  (byte)(1 << ((byte)uVar4 & 7))) == 0) {
                puVar19 = (uint *)0x7f3dc8;
              }
            }
          }
        }
      }
      else {
        uStack_d8 = auStack_a0;
        auStack_a0[0] = 0;
        puVar19 = (uint *)func_0x(puVar1,puVar17,puVar21,&uStack_a4);
        uVar12 = uStack_a4;
        if ((((*(short *)(lStack_90 + 400) != 0) &&
             (plVar2 = *(longlong **)(lStack_90 + 0x1a0), plVar2 != (longlong *)0x0)) &&
            (*plVar2 != 0)) &&
           (((*(byte *)((longlong)puVar17 + 6) & 8) == 0 && ((auStack_a0[0] & 1) == 0)))) {
          if ((puVar19 == (uint *)0x0) || (puVar19 == (uint *)0x7f37a4)) {
            puVar19 = (uint *)0x0;
            uVar12 = 0;
          }
          else {
            uStack_c0 = CONCAT44(uStack_c0._4_4_,auStack_a0[0]);
            puStack_c8 = &uStack_a4;
            plStack_d0 = (longlong *)((ulonglong)plStack_d0 & 0xffffffff00000000);
            uStack_d8 = (uint *)0x0;
            puVar19 = (uint *)func_0x(plVar2,puVar17,puVar19,uStack_a4);
            uVar12 = uStack_a4;
          }
        }
      }
LAB_:
      uStack_a4 = uVar12;
      uVar12 = iVar26 + 1;
      uVar15 = (ulonglong)uVar12;
      *ppuVar24 = puVar19;
      ppuVar24 = ppuVar24 + 1;
      *puVar25 = (undefined2)uStack_a4;
      puVar25 = puVar25 + 1;
    } while (uVar12 < uVar14);
  }
  psVar3 = psStack_88;
  puVar1 = (ushort *)(psStack_88 + 1);
  lStack_98 = *(longlong *)(lStack_90 + 0x48);
  ppuVar24 = (uint **)(lStack_80 + 0x10);
  puVar25 = (undefined2 *)(lStack_80 + 0x1a);
  iVar26 = *(int *)(**(longlong **)(*(longlong *)(lStack_98 + 8) + 0x160) + 0x1c);
  iVar5 = iVar26 + -1;
  if ((*(byte *)(*(longlong *)(lStack_98 + 8) + 0x106) & 0x40) == 0) {
    iVar5 = iVar26;
  }
  *(undefined8 *)(lStack_80 + 8) = *(undefined8 *)(psStack_88 + 4);
  uVar14 = (uint)(iVar5 != 0);
  uStack_74 = uVar14;
  if (*psStack_88 == 0) {
    if (*(int *)(psStack_88 + 2) == 0) {
      pbVar23 = *(byte **)(psStack_88 + 4);
      uVar12 = *(uint *)(psStack_88 + 8);
      uVar15 = (ulonglong)uVar12;
      *puVar1 = 0;
      *(uint *)(psStack_88 + 10) = uVar12;
      bVar10 = *pbVar23;
      if ((bVar10 & 0x10) != 0) {
        uVar12 = uVar12 + 2 + (*(ushort *)(pbVar23 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar12;
        *(uint *)(psStack_88 + 10) = uVar12;
        bVar10 = *pbVar23;
      }
      if ((bVar10 & 0x20) == 0) {
        *(int *)(psStack_88 + 2) = (int)uVar15;
        psStack_88[0xe] = 0;
        *(int *)(psStack_88 + 0xc) = (int)uVar15;
      }
      else {
        puVar16 = (ushort *)(pbVar23 + uVar15);
        uVar4 = *puVar16;
        psStack_88[0xe] = uVar4;
        if (uVar4 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar22 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar22 != 0)) &&
             ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
              (*(char *)(lVar22 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_d8 = (uint *)0x0;
              (*_DAT_)(1,0xa6ed68,0xb8ea38,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar3 + 4),3);
          uVar15 = (ulonglong)*(uint *)(psVar3 + 10);
          uVar4 = psVar3[0xe];
        }
        uVar12 = (int)uVar15 + (uVar4 + 1) * 2;
        *(uint *)(psVar3 + 0xc) = uVar12;
        if (0x1f9e < uVar12) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar22 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar22 != 0 &&
              ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
               (*(char *)(lVar22 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d8 = (uint *)0x0;
              (*_DAT_)(1,0xa6ed68,0xb8ea38,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar3 + 4),4);
          uVar4 = psVar3[0xe];
          uVar12 = *(uint *)(psVar3 + 0xc);
        }
        uVar9 = (ulonglong)uVar4;
        uVar13 = puVar16[uVar9] & 0x7fff;
        *(uint *)(psVar3 + 2) = uVar13;
        if (uVar13 < uVar12) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar22 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar22 != 0)) &&
             ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
              (*(char *)(lVar22 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d8 = (uint *)0x0;
              (*_DAT_)(1,0xa6ed68,0xb8ea38,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar3 + 4),4);
          uVar9 = (ulonglong)(ushort)psVar3[0xe];
          uVar13 = *(uint *)(psVar3 + 2);
        }
        uVar15 = (ulonglong)uVar13;
        if ((short)puVar16[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
          pbVar23 = *(byte **)(psVar3 + 4);
          do {
            if ((int)uVar9 == 1) {
              uVar12 = *(uint *)(psVar3 + 0xc);
              uVar18 = (ulonglong)uVar12;
LAB_:
              if ((*(ushort *)(pbVar23 + uVar9 * 2 + (ulonglong)*(uint *)(psVar3 + 10)) & 0x7fff) <
                  (uint)uVar18) goto LAB_;
            }
            else {
              uVar12 = *(uint *)(psVar3 + 0xc);
              uVar18 = (ulonglong)
                       (*(ushort *)(pbVar23 + uVar9 * 2 + ((ulonglong)*(uint *)(psVar3 + 10) - 2)) &
                       0x7fff);
              if (uVar12 <= (*(ushort *)
                              (pbVar23 + uVar9 * 2 + ((ulonglong)*(uint *)(psVar3 + 10) - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
              func_0x(pbVar23,7);
              uVar12 = *(uint *)(psVar3 + 0xc);
            }
            if (((uint)uVar18 < uVar12) ||
               (uVar15 = (ulonglong)*(uint *)(psVar3 + 2), *(uint *)(psVar3 + 2) < (uint)uVar18))
            goto LAB_;
            pbVar23 = *(byte **)(psVar3 + 4);
            if (*(ushort *)(pbVar23 + uVar18) == 5) {
              *puVar1 = *puVar1 | 2;
              psVar3[0xe] = psVar3[0xe] + -1;
              psVar3[0x15] = (short)uVar18;
              lVar22 = (uVar18 & 0xffff) + *(longlong *)(psVar3 + 4);
              uVar4 = psVar3[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar22 + 2) >> 0xe & 1) != 0) {
                uVar4 = *(ushort *)(lVar22 + 2) & 0x3800 | psVar3[0x16] & 0xc7ffU;
              }
              psVar3[0x16] = uVar4;
              psVar3[0x16] = (uVar4 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar4;
              uVar15 = (ulonglong)*(uint *)(psStack_88 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar23 + uVar18) < 0x400) goto LAB_;
            sVar20 = psVar3[0xe];
            *puVar1 = *puVar1 | 1;
            uVar4 = sVar20 - 1;
            psVar3[0xe] = uVar4;
            if (uVar4 == 0) goto LAB_;
            uVar9 = (ulonglong)uVar4;
          } while ((short)puVar16[(ulonglong)(uVar4 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar23 = *(byte **)(psVar3 + 4);
        }
      }
      iVar26 = 0;
      if ((*pbVar23 & 0x40) == 0) {
        *(undefined4 *)(psVar3 + 0x13) = 0;
      }
      else {
        *(int *)(psVar3 + 0x13) = (int)uVar15;
        *(int *)(psVar3 + 2) = (int)uVar15 + 0xe;
        puVar6 = (ulonglong *)func_0x(puVar1);
        uVar11 = (ushort)(*puVar6 >> 0x30);
        uVar4 = uVar11;
        if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
          uVar4 = uVar11 & 0xdfff;
          if ((uVar11 >> 0xe & 1) != 0) {
            uVar4 = uVar11 | 0x2000;
          }
        }
        if (uVar4 == 0xfffc) {
          iVar26 = (int)((*puVar6 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar3 + 2) = *(int *)(psVar3 + 2) + iVar26;
        uVar15 = (ulonglong)*(uint *)(psVar3 + 2);
      }
      iVar26 = (int)uVar15;
      if ((*(ulonglong *)(psVar3 + 0xf) != 0) &&
         (*(ulonglong *)(psVar3 + 0xf) < uVar15 + *(longlong *)(psVar3 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar22 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar22 != 0 &&
             (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
            (*(char *)(lVar22 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_d8 = (uint *)0x0;
            (*_DAT_)(1,0xa6ed68,0xb8ea38,0x877);
          }
        }
        func_0x(*(undefined8 *)(psVar3 + 4),0x12);
        iVar26 = *(int *)(psVar3 + 2);
      }
      if (0x3f3b < iVar26 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar22 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar22 != 0 &&
            ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
             (*(char *)(lVar22 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_d8 = (uint *)0x0;
            (*_DAT_)(1,0xa6ed68,0xb8ea38,0x87c);
          }
        }
        func_0x(*(undefined8 *)(psVar3 + 4),5);
      }
    }
LAB_:
    uVar12 = *(uint *)(psVar3 + 2);
    if (8 < uVar12) goto LAB_;
    bVar10 = **(byte **)(psVar3 + 4) & 0xe;
  }
  else {
    uVar12 = *(uint *)(psStack_88 + 2);
    if (uVar12 == 0) {
      func_0x(puVar1);
      uVar12 = *(uint *)(psVar3 + 2);
    }
    if (8 < uVar12) goto LAB_;
    bVar10 = **(byte **)(psVar3 + 4) & 0x1c;
  }
  if ((bVar10 == 0) || (bVar10 == 0xc)) {
    uVar12 = 9;
  }
LAB_:
  uVar15 = 0;
  *(short *)(lStack_80 + 0x18) = (short)uVar12;
  if (uVar14 != 0) {
    do {
      puVar19 = (uint *)0x0;
      lVar22 = **(longlong **)(*(longlong *)(lStack_98 + 8) + 0x160);
      puVar7 = *(uint **)(lVar22 + 0x38);
      puVar21 = (uint *)(lVar22 + 0x30);
      if (puVar7 == puVar21) {
        puVar7 = puVar19;
      }
      puVar17 = puVar19;
      if (puVar7 != (uint *)0x0) {
        puVar17 = puVar7 + -0x58;
      }
      iVar26 = (int)uVar15;
      if (iVar26 != 0) {
        do {
          puVar7 = *(uint **)(puVar17 + 0x5a);
          if (*(uint **)(puVar17 + 0x5a) == puVar21) {
            puVar7 = puVar19;
          }
          puVar17 = puVar19;
          if (puVar7 != (uint *)0x0) {
            puVar17 = puVar7 + -0x58;
          }
          uVar15 = uVar15 - 1;
        } while (uVar15 != 0);
      }
      bVar10 = *(byte *)(puVar17 + 8);
      if (*psStack_88 == 0) {
        uVar13 = *puVar17;
        if ((uVar13 & 0xc0000000) == 0x80000000) {
          iVar5 = func_0x(puVar1);
          if (iVar5 != 0) {
            puVar19 = (uint *)func_0x(psVar3 + 0x15,puVar17,&uStack_a8,auStack_a0);
            uVar12 = uStack_a8;
            goto LAB_;
          }
LAB_:
          uStack_a8 = 0;
          uVar12 = uStack_a8;
        }
        else {
          if (((bVar10 & 2) != 0) || ((*(byte *)((longlong)puVar17 + 6) & 0x10) != 0)) {
            pbVar23 = *(byte **)(psVar3 + 4);
            if ((*pbVar23 & 0x10) == 0) {
              if ((1 << (*pbVar23 & 0xe) & 0x1105U) != 0) goto LAB_;
              puVar7 = (uint *)0x1;
              puVar21 = puVar19;
LAB_:
              uVar12 = (uint)puVar21;
              iVar5 = (int)puVar7;
              if ((bVar10 & 2) != 0) goto LAB_;
            }
            else {
              uVar12 = *(uint *)(psVar3 + 8);
              if ((int)uVar12 <= (int)uVar13) {
LAB_:
                puVar21 = (uint *)(ulonglong)(~(uint)(*(ushort *)((longlong)puVar17 + 6) >> 4) & 1);
                puVar7 = puVar19;
                goto LAB_;
              }
              if ((uint)*(ushort *)(pbVar23 + uVar12) < (uint)*(ushort *)(puVar17 + 1))
              goto LAB_;
              if ((bVar10 & 2) == 0) goto LAB_;
              uVar8 = *(ushort *)(puVar17 + 1) - 1;
              iVar5 = 1;
              uVar12 = pbVar23[(ulonglong)uVar12 + (ulonglong)(uVar8 >> 3) + 2] >> ((byte)uVar8 & 7)
                       & 1;
LAB_:
              if (uVar12 != 0) goto LAB_;
            }
            if ((iVar5 == 0) && ((*(byte *)((longlong)puVar17 + 6) & 0x10) != 0)) {
              puVar19 = *(uint **)(puVar17 + 2) + 1;
              uVar12 = **(uint **)(puVar17 + 2);
              goto LAB_;
            }
          }
LAB_:
          if ((int)uVar13 < 0) {
            if (*(int *)(psVar3 + 2) == 0) {
              pbVar23 = *(byte **)(psVar3 + 4);
              uVar14 = *(uint *)(psVar3 + 8);
              uVar15 = (ulonglong)uVar14;
              *puVar1 = 0;
              *(uint *)(psVar3 + 10) = uVar14;
              bVar10 = *pbVar23;
              if ((bVar10 & 0x10) != 0) {
                uVar14 = uVar14 + 2 + (*(ushort *)(pbVar23 + uVar15) + 7 >> 3);
                uVar15 = (ulonglong)uVar14;
                *(uint *)(psVar3 + 10) = uVar14;
                bVar10 = *pbVar23;
              }
              if ((bVar10 & 0x20) == 0) {
                *(int *)(psVar3 + 2) = (int)uVar15;
                psVar3[0xe] = 0;
                *(int *)(psVar3 + 0xc) = (int)uVar15;
              }
              else {
                puVar16 = (ushort *)(pbVar23 + uVar15);
                uVar4 = *puVar16;
                psVar3[0xe] = uVar4;
                if (uVar4 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0)) &&
                     ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                      (*(char *)(lVar22 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0xa6ed68,0xb8ea38,0x80f);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar3 + 4),3);
                  uVar15 = (ulonglong)*(uint *)(psVar3 + 10);
                  uVar4 = psVar3[0xe];
                }
                uVar14 = (int)uVar15 + (uVar4 + 1) * 2;
                *(uint *)(psVar3 + 0xc) = uVar14;
                if (0x1f9e < uVar14) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0 &&
                      ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                       (*(char *)(lVar22 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0xa6ed68,0xb8ea38,0x816);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar3 + 4),4);
                  uVar4 = psVar3[0xe];
                  uVar14 = *(uint *)(psVar3 + 0xc);
                }
                uVar15 = (ulonglong)uVar4;
                uVar4 = puVar16[uVar15];
                *(uint *)(psVar3 + 2) = uVar4 & 0x7fff;
                if ((uVar4 & 0x7fff) < uVar14) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar22 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar22 != 0)) &&
                     ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                      (*(char *)(lVar22 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0xa6ed68,0xb8ea38,0x81d);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar3 + 4),4);
                  uVar15 = (ulonglong)(ushort)psVar3[0xe];
                }
                if ((short)puVar16[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                  pbVar23 = *(byte **)(psVar3 + 4);
                  do {
                    if ((int)uVar15 == 1) {
                      uVar14 = *(uint *)(psVar3 + 0xc);
                      uVar12 = uVar14;
LAB_:
                      if ((*(ushort *)(pbVar23 + uVar15 * 2 + (ulonglong)*(uint *)(psVar3 + 10)) &
                          0x7fff) < uVar14) goto LAB_;
                    }
                    else {
                      uVar12 = *(uint *)(psVar3 + 0xc);
                      uVar14 = *(ushort *)
                                (pbVar23 + uVar15 * 2 + ((ulonglong)*(uint *)(psVar3 + 10) - 2)) &
                               0x7fff;
                      if (uVar12 <= uVar14) goto LAB_;
LAB_:
                      func_0x(pbVar23,7);
                      uVar12 = *(uint *)(psVar3 + 0xc);
                    }
                    if ((uVar14 < uVar12) || (*(uint *)(psVar3 + 2) < uVar14)) goto LAB_;
                    pbVar23 = *(byte **)(psVar3 + 4);
                    if (*(ushort *)(pbVar23 + uVar14) == 5) {
                      *puVar1 = *puVar1 | 2;
                      psVar3[0xe] = psVar3[0xe] + -1;
                      psVar3[0x15] = (short)uVar14;
                      lVar22 = (ulonglong)(uVar14 & 0xffff) + *(longlong *)(psVar3 + 4);
                      uVar4 = psVar3[0x16] & 0xc7ffU;
                      if ((*(ushort *)(lVar22 + 2) >> 0xe & 1) != 0) {
                        uVar4 = *(ushort *)(lVar22 + 2) & 0x3800 | psVar3[0x16] & 0xc7ffU;
                      }
                      psVar3[0x16] = uVar4;
                      psVar3[0x16] = (uVar4 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar4;
                      goto LAB_;
                    }
                    if (*(ushort *)(pbVar23 + uVar14) < 0x400) goto LAB_;
                    sVar20 = psVar3[0xe];
                    *puVar1 = *puVar1 | 1;
                    uVar4 = sVar20 - 1;
                    psVar3[0xe] = uVar4;
                    if (uVar4 == 0) goto LAB_;
                    uVar15 = (ulonglong)uVar4;
                  } while ((short)puVar16[(ulonglong)(uVar4 - 1) + 1] < 0);
                  uVar15 = (ulonglong)*(uint *)(psVar3 + 2);
                }
                else {
LAB_:
                  uVar15 = (ulonglong)*(uint *)(psVar3 + 2);
                  pbVar23 = *(byte **)(psVar3 + 4);
                }
              }
              iVar5 = 0;
              if ((*pbVar23 & 0x40) == 0) {
                *(undefined4 *)(psVar3 + 0x13) = 0;
              }
              else {
                *(int *)(psVar3 + 0x13) = (int)uVar15;
                *(int *)(psVar3 + 2) = (int)uVar15 + 0xe;
                puVar6 = (ulonglong *)func_0x(puVar1);
                uVar11 = (ushort)(*puVar6 >> 0x30);
                uVar4 = uVar11;
                if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
                  uVar4 = uVar11 & 0xdfff;
                  if ((uVar11 >> 0xe & 1) != 0) {
                    uVar4 = uVar11 | 0x2000;
                  }
                }
                if (uVar4 == 0xfffc) {
                  iVar5 = (int)((*puVar6 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(psVar3 + 2) = *(int *)(psVar3 + 2) + iVar5;
                uVar15 = (ulonglong)*(uint *)(psVar3 + 2);
              }
              iVar5 = (int)uVar15;
              if ((*(ulonglong *)(psVar3 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar3 + 0xf) < uVar15 + *(longlong *)(psVar3 + 4))) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar22 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                     lVar22 != 0 && (lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0)) &&
                    (*(char *)(lVar22 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_d8 = (uint *)0x0;
                    (*_DAT_)(1,0xa6ed68,0xb8ea38,0x877);
                  }
                }
                func_0x(*(undefined8 *)(psVar3 + 4),0x12);
                iVar5 = *(int *)(psVar3 + 2);
              }
              if (0x3f3b < iVar5 - 1U) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar22 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar22 != 0 &&
                    ((lVar22 = *(longlong *)(lVar22 + 0x60), lVar22 != 0 &&
                     (*(char *)(lVar22 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_d8 = (uint *)0x0;
                    (*_DAT_)(1,0xa6ed68,0xb8ea38,0x87c);
                  }
                }
                func_0x(*(undefined8 *)(psVar3 + 4),5);
              }
            }
LAB_:
            sVar20 = -*(short *)puVar17;
            uVar14 = uStack_74;
            if ((*(byte *)((longlong)puVar17 + 6) & 0x10) != 0) {
              bVar10 = **(byte **)(psVar3 + 4);
              if ((bVar10 & 0x10) == 0) {
                if ((1 << (bVar10 & 0xe) & 0x1105U) != 0) {
LAB_:
                  puVar19 = *(uint **)(puVar17 + 2) + 1;
                  uVar12 = **(uint **)(puVar17 + 2);
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(psVar3 + 8) <= (int)*puVar17) ||
                      (*(ushort *)(*(byte **)(psVar3 + 4) + *(uint *)(psVar3 + 8)) <
                       *(ushort *)(puVar17 + 1))) goto LAB_;
            }
            puVar19 = *(uint **)(psVar3 + 4);
            if ((uint)(ushort)psVar3[0xe] < (uint)(int)sVar20) {
              uStack_a8 = 0;
              uVar12 = uStack_a8;
            }
            else {
              uVar12 = *(ushort *)
                        ((longlong)puVar19 +
                        (longlong)sVar20 * 2 + (ulonglong)*(uint *)(psVar3 + 10)) & 0x7fff;
              if (sVar20 == 1) {
                uVar13 = *(uint *)(psStack_88 + 0xc);
LAB_:
                if (uVar12 < uVar13) goto LAB_;
              }
              else {
                uVar13 = *(ushort *)
                          ((longlong)puVar19 +
                          (longlong)sVar20 * 2 + ((ulonglong)*(uint *)(psVar3 + 10) - 2)) & 0x7fff;
                if (*(uint *)(psStack_88 + 0xc) <= uVar13) goto LAB_;
LAB_:
                func_0x(puVar19,7);
                puVar19 = *(uint **)(psVar3 + 4);
              }
              puVar19 = (uint *)((longlong)puVar19 + (ulonglong)uVar13);
              uVar14 = uStack_74;
              uVar12 = uVar12 - uVar13;
            }
          }
          else {
            uVar4 = *(ushort *)((longlong)puVar17 + 6);
            if ((uVar4 & 8) == 0) {
              uVar8 = (uint)*(ushort *)(puVar17 + 0xe);
              if ((uVar4 & 0x10) != 0) {
                bVar10 = **(byte **)(psVar3 + 4);
                if ((bVar10 & 0x10) == 0) {
                  if ((1 << (bVar10 & 0xe) & 0x1105U) != 0) {
LAB_:
                    uVar12 = **(uint **)(puVar17 + 2);
                    puVar19 = *(uint **)(puVar17 + 2) + 1;
                    if ((uVar8 != 0) && (uVar12 != uVar8)) {
                      uStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0xc1cad8,0xc1b4d8,0x381);
                    }
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(psVar3 + 8) <= (int)uVar13) ||
                        (*(ushort *)(*(byte **)(psVar3 + 4) + *(uint *)(psVar3 + 8)) <
                         *(ushort *)(puVar17 + 1))) goto LAB_;
              }
              puVar19 = (uint *)((longlong)(int)*puVar17 + *(longlong *)(psVar3 + 4));
              uVar12 = uVar8;
            }
            else {
              puVar19 = (uint *)0x7f37a4;
              uStack_a8 = 1;
              uVar12 = uStack_a8;
              if ((*(byte *)((longlong)(int)uVar13 + *(longlong *)(psVar3 + 4)) &
                  (byte)(1 << ((byte)uVar4 & 7))) == 0) {
                puVar19 = (uint *)0x7f3dc8;
              }
            }
          }
        }
      }
      else {
        uStack_d8 = auStack_a0;
        auStack_a0[0] = 0;
        puVar19 = (uint *)func_0x(puVar1,puVar17,puVar21,&uStack_a8);
        uVar12 = uStack_a8;
        if ((((*psStack_88 != 0) &&
             (plVar2 = *(longlong **)(psStack_88 + 8), plVar2 != (longlong *)0x0)) && (*plVar2 != 0)
            ) && (((*(byte *)((longlong)puVar17 + 6) & 8) == 0 && ((auStack_a0[0] & 1) == 0)))) {
          if ((puVar19 == (uint *)0x0) || (puVar19 == (uint *)0x7f37a4)) {
            puVar19 = (uint *)0x0;
            uVar12 = 0;
          }
          else {
            uStack_c0 = CONCAT44(uStack_c0._4_4_,auStack_a0[0]);
            puStack_c8 = &uStack_a8;
            plStack_d0 = (longlong *)((ulonglong)plStack_d0 & 0xffffffff00000000);
            uStack_d8 = (uint *)0x0;
            puVar19 = (uint *)func_0x(plVar2,puVar17,puVar19,uStack_a8);
            uVar12 = uStack_a8;
          }
        }
      }
LAB_:
      uStack_a8 = uVar12;
      uVar12 = iVar26 + 1;
      uVar15 = (ulonglong)uVar12;
      *ppuVar24 = puVar19;
      ppuVar24 = ppuVar24 + 1;
      *puVar25 = (undefined2)uStack_a8;
      puVar25 = puVar25 + 1;
    } while (uVar12 < uVar14);
  }
  lVar22 = lStack_90;
  uStack_c0 = lStack_80 + 0x1c;
  uStack_b8 = 1;
  puStack_c8 = (uint *)abStack_78;
  plStack_d0 = &lStack_70;
  uStack_d8 = (uint *)CONCAT62(uStack_d8._2_6_,
                               *(undefined2 *)
                                (*(longlong *)(*(longlong *)(lStack_90 + 0x48) + 8) + 0xb8));
  func_0x
            (auStack_68,lStack_80,*(undefined8 *)(lStack_90 + 0x138),
             *(undefined4 *)(lStack_90 + 0x240));
  if (((abStack_78[0] & 1) != 0) &&
     ((*(byte *)(*(longlong *)(*(longlong *)(lVar22 + 0x48) + 8) + 0x106) & 0x40) == 0)) {
    func_0x(lVar22,lStack_80);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_f8);
  return;
}

