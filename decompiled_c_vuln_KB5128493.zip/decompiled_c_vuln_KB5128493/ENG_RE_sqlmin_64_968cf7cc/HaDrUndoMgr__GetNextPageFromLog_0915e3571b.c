
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined4 *param_2,int *param_3)

{
  ushort uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  uint uVar4;
  longlong lVar5;
  char cVar6;
  longlong lVar7;
  uint *puVar8;
  longlong lVar9;
  byte *pbVar10;
  longlong *plVar11;
  undefined8 uVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  longlong **pplVar15;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar16;
  uint uVar17;
  char cVar18;
  bool bVar19;
  undefined8 extraout_XMM0_Qa;
  undefined auStack_408 [32];
  undefined8 uStack_3e8;
  char cStack_3d8;
  char cStack_3d7;
  undefined2 uStack_3d0;
  undefined4 uStack_3cc;
  undefined8 uStack_3c8;
  undefined8 uStack_3c0;
  undefined8 uStack_3b2;
  undefined8 uStack_3a8;
  undefined2 uStack_398;
  undefined4 uStack_394;
  byte *pbStack_390;
  undefined8 uStack_388;
  undefined8 uStack_37a;
  undefined2 uStack_372;
  undefined2 uStack_370;
  undefined6 uStack_36e;
  char cStack_360;
  char cStack_35f;
  ushort auStack_35c [2];
  uint auStack_358 [2];
  longlong lStack_350;
  undefined4 *puStack_348;
  undefined auStack_340 [4];
  uint auStack_33c [3];
  undefined8 uStack_330;
  undefined2 uStack_328;
  longlong *plStack_320;
  longlong *aplStack_318 [4];
  undefined auStack_2f8 [8];
  undefined4 uStack_2f0;
  undefined4 uStack_2e8;
  ulonglong **ppuStack_2e0;
  undefined *puStack_2d8;
  undefined8 uStack_2d0;
  ulonglong *puStack_2c8;
  undefined8 uStack_2c0;
  undefined auStack_2b8 [528];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  ulonglong uStack_98;
  ulonglong uStack_90;
  int *apiStack_88 [2];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_408;
  cVar18 = '\0';
  cStack_3d7 = '\0';
  *param_2 = 0;
  *(undefined2 *)(param_2 + 1) = 0;
  cStack_3d8 = '\0';
  *param_3 = 0;
  puStack_348 = param_2;
  apiStack_88[0] = param_3;
LAB_:
  if ((*(int *)(param_1 + 9) == 3) ||
     (lVar7 = (*(code *)param_1[4][5])(param_1 + 4), lStack_350 = lVar7, lVar7 == 0)) {
LAB_:
    *(undefined4 *)(param_1 + 9) = 3;
LAB_:
    func_0x(uStack_48 ^ (ulonglong)auStack_408);
    return;
  }
  puVar8 = (uint *)(*(code *)param_1[4][3])(param_1 + 4,auStack_78);
  if ((*puVar8 < *(uint *)((longlong)param_1 + 0x3b4)) ||
     ((*puVar8 == *(uint *)((longlong)param_1 + 0x3b4) &&
      ((puVar8[1] < *(uint *)(param_1 + 0x77) ||
       ((puVar8[1] == *(uint *)(param_1 + 0x77) &&
        (*(ushort *)(puVar8 + 2) < *(ushort *)((longlong)param_1 + 0x3bc))))))))) goto LAB_;
  puVar8 = (uint *)(*(code *)param_1[4][3])(param_1 + 4,auStack_68);
  if ((*puVar8 < *(uint *)(param_1 + 2)) ||
     ((*puVar8 == *(uint *)(param_1 + 2) &&
      ((puVar8[1] < *(uint *)((longlong)param_1 + 0x14) ||
       ((puVar8[1] == *(uint *)((longlong)param_1 + 0x14) &&
        (*(ushort *)(puVar8 + 2) < *(ushort *)(param_1 + 3))))))))) {
    cStack_3d8 = '\x01';
  }
  cVar6 = cStack_3d8;
  if (0x7e < *(byte *)(lVar7 + 0x16)) goto LAB_;
  lVar9 = (**(code **)**param_1)();
  if ((*(byte *)(lVar9 + 0x1cd0) & 0x40) != 0) {
    if (*(short *)(lVar7 + 0x1c) == 1) {
      bVar19 = *(int *)(lVar7 + 0x18) == 9;
    }
    else {
      bVar19 = *(short *)(lVar7 + 0x1c) == 2;
    }
    if (!bVar19) goto LAB_;
  }
  if ((*(uint *)(param_1 + 0x80) < (uint)*(ushort *)(lVar7 + 0x1c)) ||
     (*(char *)((longlong)param_1[0x81] + ((ulonglong)*(ushort *)(lVar7 + 0x1c) - 1)) != '\x01')) {
    if (cVar6 == '\0') {
      if ((*(char *)(lVar7 + 0x17) != '\x11') || (*(char *)(lVar7 + 0x16) != '\x10')) {
        if ((*(uint *)(lVar7 + 0x24) <= *(uint *)(param_1 + 2)) &&
           ((*(uint *)(param_1 + 2) != *(uint *)(lVar7 + 0x24) ||
            ((*(uint *)(lVar7 + 0x28) <= *(uint *)((longlong)param_1 + 0x14) &&
             ((*(uint *)((longlong)param_1 + 0x14) != *(uint *)(lVar7 + 0x28) ||
              (*(ushort *)(lVar7 + 0x2c) <= *(ushort *)(param_1 + 3))))))))) {
          uVar3 = *(undefined4 *)(lVar7 + 0x18);
          *(undefined2 *)(param_2 + 1) = *(undefined2 *)(lVar7 + 0x1c);
          *param_2 = uVar3;
          cStack_3d7 = '\x01';
        }
        goto LAB_;
      }
      cVar6 = func_0x(lVar7);
      if (cVar6 == '\0') {
        uStack_3c8 = 0;
        uStack_3d0 = 0xffff;
        uStack_3cc = 0;
        uStack_3b2 = 0;
        uStack_3a8 = 0;
        uStack_3c0 = 0;
        uStack_398 = 0xffff;
        pbStack_390 = (byte *)0x0;
        uStack_394 = 0;
        uStack_37a = 0;
        uStack_370 = 0;
        uStack_36e = 0;
        uStack_388 = 0;
        pbStack_390 = (byte *)func_0x(lVar7 + 0x3e,0,auStack_340);
        if ((*pbStack_390 & 1) == 0) {
          uStack_398 = 0;
          uStack_372 = 0;
          uStack_370 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010038f */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_390 & 0xe) * 4 + 0x101a40) -
                    0x649f60))((longlong)(int)(*pbStack_390 & 0xe),0xffffffffff9b60a0,pbStack_390);
          return;
        }
        uStack_398 = 1;
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_390 & 0x1c) + 0x101a20) * 4 +
                               0x101a10) - 0x649f60);
                    /* WARNING: Could not emulate address calculation at 0x00100220 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return;
      }
    }
    else {
LAB_:
      bVar19 = false;
      if (((*(char *)(lVar7 + 0x17) == '\v') && (*(char *)(lVar7 + 0x16) == '\x04')) &&
         (*(short *)(lVar7 + 0x1e) == 0)) {
        pbVar10 = (byte *)func_0x(lVar7 + 0x3e,0,auStack_33c);
        lVar9 = func_0x(lVar7 + 0x3e,1,auStack_358);
        if ((*(ushort *)(lVar7 + 0x3c) & 0x400) != 0) {
          auStack_358[0] = (uint)*(ushort *)(lVar7 + 0x3a);
        }
        if (*(ushort *)(lVar7 + 0x38) < 4) {
          auStack_358[0] = auStack_358[0] + *(ushort *)(lVar7 + 0x38);
          if (auStack_358[0] < 5) {
            auStack_358[0] = 0;
            auStack_33c[0] = 0;
          }
          else {
            auStack_358[0] = auStack_358[0] - 4;
            auStack_33c[0] = auStack_358[0];
          }
        }
        param_1[0x10] = (longlong *)0x0;
        uVar4 = *(uint *)(lVar7 + 0x18);
        uVar1 = *(ushort *)(lVar7 + 0x38);
        uVar2 = *(undefined2 *)(lVar7 + 0x1c);
        uVar16 = auStack_33c[0];
        if (auStack_358[0] < auStack_33c[0]) {
          uVar16 = auStack_358[0];
        }
        if (uVar16 < 9) {
          param_2 = puStack_348;
          if (uVar16 == 0) goto LAB_;
        }
        else {
          uStack_3e8 = (ushort *)0x0;
          (*_DAT_)(1,0x228a940,0x22750e0,0x14d);
        }
        lVar9 = lVar9 - (longlong)pbVar10;
        uVar17 = 0;
        do {
          if (((pbVar10[lVar9] ^ *pbVar10) & 0x40) != 0) {
            bVar19 = true;
            lVar7 = (ulonglong)*(uint *)(param_1 + 0x10) * 6;
            *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) + 1;
            *(undefined2 *)(lVar7 + 0x54 + (longlong)param_1) = uVar2;
            *(uint *)(lVar7 + 0x50 + (longlong)param_1) =
                 (uVar17 - 4) + (uVar4 & 0xfffffff8) + (uint)uVar1;
          }
          uVar17 = uVar17 + 1;
          pbVar10 = pbVar10 + 1;
        } while (uVar17 < uVar16);
        param_2 = puStack_348;
        if (bVar19) {
          *(undefined4 *)(param_1 + 9) = 2;
          cStack_3d7 = '\x01';
          if (cStack_3d8 != '\0') {
            uVar3 = *(undefined4 *)(lStack_350 + 0x18);
            *(undefined2 *)(puStack_348 + 1) = *(undefined2 *)(lStack_350 + 0x1c);
            *puStack_348 = uVar3;
          }
        }
      }
LAB_:
      lVar7 = lStack_350;
      cVar18 = cStack_3d7;
      if (param_1[0x83] == (longlong *)0x0) {
        uVar4 = *(uint *)(param_1 + 0x11);
        *(uint *)(param_1 + 0x11) = uVar4 + 1;
        if ((uVar4 & 7) == 0) {
LAB_:
          plVar11 = (longlong *)(**(code **)(**param_1 + 8))();
          lVar9 = *plVar11;
          uVar12 = (*(code *)param_1[4][3])(param_1 + 4,auStack_58);
          uVar13 = (**(code **)(lVar9 + 0x78))(plVar11,(longlong)param_1 + 0x3b4,uVar12,0);
          plVar11 = param_1[0x7f];
          func_0x(plVar11);
          lVar9 = plVar11[4];
          lVar5 = plVar11[3];
          func_0x(plVar11);
          plVar11 = param_1[0x7f];
          func_0x(plVar11);
          lVar9 = plVar11[4] + ((lVar5 - lVar9) - uVar13);
          if (plVar11[3] <= lVar9) {
            lVar9 = plVar11[3];
          }
          plVar11[4] = lVar9;
          func_0x(plVar11);
          if ((_DAT_ & 0x8000) != 0) {
            ppuStack_2e0 = &puStack_2c8;
            uStack_2f0 = 0x10000;
            puStack_2d8 = auStack_2b8;
            uStack_2e8 = 0;
            puStack_2c8 = &uStack_98;
            uStack_98 = uVar13 >> 10;
            uStack_90 = (ulonglong)param_1[0x7e] >> 10;
            uStack_a8 = 0;
            uStack_2d0 = 0;
            uStack_a0 = 0;
            uStack_2c0 = 0x10;
            func_0x(auStack_2f8);
          }
          plVar11 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&plStack_320);
            plVar11 = plStack_320;
          }
          param_1[0x85] = plVar11;
          uVar14 = (longlong)plVar11 - (longlong)param_1[0x86];
          if (plVar11 < param_1[0x86]) {
            uVar14 = 0;
          }
          if (uVar14 == 0xffffffffffffffff) {
            uVar14 = 0xffffffffffffffff;
          }
          else if (*_DAT_ == 0) {
            uVar14 = uVar14 / 10000;
          }
          else {
            uVar14 = (uVar14 * 1000) / *_DAT_;
          }
          if (((param_1[1] != (longlong *)0x0) && (299999 < uVar14)) &&
             (param_1[0x7e] != (longlong *)0x0)) {
            func_0x(0x20a9da0,param_1[1][0x26] + 0x120,uVar13);
            plVar11 = _DAT_;
            if (*_DAT_ != 0) {
              (*_DAT_)(aplStack_318);
              plVar11 = aplStack_318[0];
            }
            param_1[0x86] = plVar11;
          }
          param_2 = puStack_348;
          if (*_DAT_ != '\0') {
            lVar9 = (**(code **)(**param_1 + 0x10))();
            uStack_3e8 = (ushort *)CONCAT44(uStack_3e8._4_4_,(uint)*(ushort *)(lVar9 + 0x28));
            func_0x(0x2806e20,10,0xa8);
            param_2 = puStack_348;
          }
        }
      }
      else if (*(int *)((longlong)param_1[0x83] + 0x40c) < 0) goto LAB_;
LAB_:
      if ((cStack_3d8 == '\0') &&
         (lVar9 = (**(code **)**param_1)(), (*(byte *)(lVar9 + 0x1cd0) & 0x40) == 0)) {
        uStack_3e8 = auStack_35c;
        func_0x(extraout_XMM0_Qa,lVar7,&cStack_360);
        uVar1 = auStack_35c[0];
        if ((cStack_360 != '\0') && (cStack_35f != '\0')) {
          *apiStack_88[0] = (*(char *)(lVar7 + 0x16) != -0x7a) + 1;
          pplVar15 = (longlong **)(*(code *)param_1[4][3])(param_1 + 4,apiStack_88);
          param_1[0x78] = *pplVar15;
          *(undefined2 *)(param_1 + 0x79) = *(undefined2 *)(pplVar15 + 1);
          *(ushort *)(param_2 + 1) = auStack_35c[0];
          *param_2 = 0;
          goto LAB_;
        }
        if ((*(char *)(lVar7 + 0x16) == -0x7a) &&
           ((uVar13 = (ulonglong)auStack_35c[0], *(uint *)(param_1 + 0x80) < (uint)auStack_35c[0] ||
            (*(char *)((longlong)param_1[0x81] + (uVar13 - 1)) != '\x01')))) {
          lVar7 = (**(code **)**param_1)();
          if ((uVar1 != 0) &&
             (((uVar1 <= *(ushort *)(*(longlong *)(lVar7 + 0x6a0) + 0x74) &&
               (lVar7 = *(longlong *)
                         (*(longlong *)(*(longlong *)(lVar7 + 0x6a0) + 0x50) + -8 + uVar13 * 8),
               lVar7 != 0)) && ((*(byte *)(lVar7 + 100) & 4) == 0)))) {
            uStack_330 = 0;
            uStack_328 = 0;
            func_0x(param_1,lVar7,&uStack_330);
          }
        }
      }
      if (cVar18 != '\0') goto LAB_;
    }
  }
  goto LAB_;
}

