
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_(short *param_1,uint *param_2,undefined8 param_3,int param_4,int *param_5,
                  int **param_6,int *param_7,undefined8 param_8,undefined4 param_9)

{
  longlong *plVar1;
  byte bVar2;
  ushort uVar3;
  ushort uVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  ulonglong *puVar8;
  longlong lVar9;
  uint uVar10;
  longlong lVar11;
  short sVar12;
  uint uVar13;
  ulonglong uVar14;
  int iVar15;
  uint uVar16;
  byte *pbVar17;
  longlong lVar18;
  ushort *puVar19;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  undefined auStack_38 [16];
  
  if (*param_1 != 0) {
    if (*param_1 != 1) {
      (*_DAT_)(1,0xb77d40,0xbd3da8,0xd3,0x772ee8);
      return (int *)0x0;
    }
    auStackX_8[0] = 0;
    piVar6 = (int *)func_0x(param_1 + 1,param_2,param_3,param_5,auStackX_8);
    if ((((*param_1 != 0) && (plVar1 = *(longlong **)(param_1 + 8), plVar1 != (longlong *)0x0)) &&
        (*plVar1 != 0)) &&
       (((*(byte *)((longlong)param_2 + 6) & 8) == 0 && ((auStackX_8[0] & 1) == 0)))) {
      if ((piVar6 == (int *)0x0) || (piVar6 == (int *)0x77b444)) {
        *param_5 = 0;
        piVar6 = (int *)0x0;
      }
      else {
        piVar6 = (int *)func_0x
                                  (plVar1,param_2,piVar6,*param_5,param_8,param_9,param_5,
                                   auStackX_8[0]);
      }
    }
    piVar7 = (int *)func_0x(param_1 + 1,param_2);
    *param_6 = piVar7;
    return piVar6;
  }
  uVar13 = *param_2;
  if ((uVar13 & 0xc0000000) == 0x80000000) {
    iVar5 = func_0x(param_1 + 1);
    if (iVar5 != 0) {
      piVar6 = (int *)func_0x(param_1 + 0x15,param_2,param_5,auStack_38);
      goto LAB_;
    }
LAB_:
    piVar6 = (int *)0x0;
    *param_5 = 0;
    goto LAB_;
  }
  uVar3 = 0;
  iVar15 = 1;
  iVar5 = 0;
  if ((param_4 != 0) || ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
    pbVar17 = *(byte **)(param_1 + 4);
    if ((*pbVar17 & 0x10) == 0) {
      if ((1 << (*pbVar17 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
      if (param_4 != 0) goto LAB_;
    }
    else {
      uVar16 = *(uint *)(param_1 + 8);
      if ((int)uVar16 <= (int)uVar13) {
LAB_:
        uVar3 = ~(*(ushort *)((longlong)param_2 + 6) >> 4) & 1;
        iVar15 = iVar5;
        goto LAB_;
      }
      if ((uint)*(ushort *)(pbVar17 + uVar16) < (uint)*(ushort *)(param_2 + 1)) goto LAB_;
      if (param_4 == 0) goto LAB_;
      uVar10 = *(ushort *)(param_2 + 1) - 1;
      uVar3 = pbVar17[(ulonglong)uVar16 + (ulonglong)(uVar10 >> 3) + 2] >> ((byte)uVar10 & 7) & 1;
LAB_:
      if (uVar3 != 0) goto LAB_;
    }
    if ((iVar15 != 0) || ((*(byte *)((longlong)param_2 + 6) & 0x10) == 0)) goto LAB_;
    goto LAB_;
  }
LAB_:
  if (-1 < (int)uVar13) {
    uVar3 = *(ushort *)((longlong)param_2 + 6);
    if ((uVar3 & 8) != 0) {
      piVar6 = (int *)0x77b444;
      bVar2 = *(byte *)((longlong)(int)uVar13 + *(longlong *)(param_1 + 4));
      *param_5 = 1;
      if ((bVar2 & (byte)(1 << ((byte)uVar3 & 7))) == 0) {
        piVar6 = (int *)0x77ba68;
      }
      goto LAB_;
    }
    iVar5 = (int)param_3;
    if ((uVar3 & 0x10) != 0) {
      bVar2 = **(byte **)(param_1 + 4);
      if ((bVar2 & 0x10) == 0) {
        if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
LAB_:
          iVar15 = **(int **)(param_2 + 2);
          piVar6 = *(int **)(param_2 + 2) + 1;
          if ((iVar5 != 0) && (iVar15 != iVar5)) {
            (*_DAT_)(1,0xba4778,0xba3178,0x381,0);
          }
          *param_5 = iVar15;
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uVar13) ||
              (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
               *(ushort *)(param_2 + 1))) goto LAB_;
    }
    *param_5 = iVar5;
    piVar6 = (int *)((longlong)(int)*param_2 + *(longlong *)(param_1 + 4));
    goto LAB_;
  }
  if (*(int *)(param_1 + 2) == 0) {
    pbVar17 = *(byte **)(param_1 + 4);
    uVar13 = *(uint *)(param_1 + 8);
    uVar14 = (ulonglong)uVar13;
    param_1[1] = 0;
    *(uint *)(param_1 + 10) = uVar13;
    bVar2 = *pbVar17;
    if ((bVar2 & 0x10) != 0) {
      uVar13 = uVar13 + 2 + (*(ushort *)(pbVar17 + uVar14) + 7 >> 3);
      uVar14 = (ulonglong)uVar13;
      *(uint *)(param_1 + 10) = uVar13;
      bVar2 = *pbVar17;
    }
    if ((bVar2 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar14;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar14;
    }
    else {
      puVar19 = (ushort *)(pbVar17 + uVar14);
      uVar3 = *puVar19;
      param_1[0xe] = uVar3;
      if (uVar3 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar11 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar11 != 0)) &&
           ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9f6a08,0xb166d8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar14 = (ulonglong)*(uint *)(param_1 + 10);
        uVar3 = param_1[0xe];
      }
      uVar13 = (int)uVar14 + (uVar3 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar13;
      if (0x1f9e < uVar13) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar11 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar11 != 0 &&
            ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
             (*(char *)(lVar11 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9f6a08,0xb166d8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar3 = param_1[0xe];
        uVar13 = *(uint *)(param_1 + 0xc);
      }
      uVar14 = (ulonglong)uVar3;
      uVar3 = puVar19[uVar14];
      *(uint *)(param_1 + 2) = uVar3 & 0x7fff;
      if ((uVar3 & 0x7fff) < uVar13) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar11 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar11 != 0)) &&
           ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9f6a08,0xb166d8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar14 = (ulonglong)(ushort)param_1[0xe];
      }
      if ((short)puVar19[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
        lVar11 = *(longlong *)(param_1 + 4);
        do {
          if ((int)uVar14 == 1) {
            uVar13 = *(uint *)(param_1 + 0xc);
            uVar16 = uVar13;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar11 + uVar14 * 2) & 0x7fff) <
                uVar13) goto LAB_;
          }
          else {
            uVar16 = *(uint *)(param_1 + 0xc);
            uVar13 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar11 + -2 + uVar14 * 2) &
                     0x7fff;
            if (uVar16 <= uVar13) goto LAB_;
LAB_:
            func_0x(lVar11,7);
            uVar16 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar13 < uVar16) || (*(uint *)(param_1 + 2) < uVar13)) goto LAB_;
          lVar11 = *(longlong *)(param_1 + 4);
          if (*(ushort *)(lVar11 + (ulonglong)uVar13) == 5) {
            param_1[1] = param_1[1] | 2;
            param_1[0xe] = param_1[0xe] + -1;
            uVar4 = param_1[0x16] & 0xc7ff;
            param_1[0x15] = (short)uVar13;
            lVar11 = (ulonglong)(uVar13 & 0xffff) + *(longlong *)(param_1 + 4);
            uVar3 = *(ushort *)(lVar11 + 2);
            if ((uVar3 & 0x4000) != 0) {
              uVar4 = uVar3 & 0x3800 | uVar4;
            }
            param_1[0x16] = uVar4;
            param_1[0x16] = (uVar4 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar4;
            uVar14 = (ulonglong)*(uint *)(param_1 + 2);
            pbVar17 = *(byte **)(param_1 + 4);
            goto LAB_;
          }
          if (*(ushort *)(lVar11 + (ulonglong)uVar13) < 0x400) break;
          param_1[1] = param_1[1] | 1;
          uVar3 = param_1[0xe] - 1;
          param_1[0xe] = uVar3;
          if ((uVar3 == 0) ||
             (uVar14 = (ulonglong)uVar3, -1 < (short)puVar19[(ulonglong)(uVar3 - 1) + 1])) break;
        } while( true );
      }
      uVar14 = (ulonglong)*(uint *)(param_1 + 2);
      pbVar17 = *(byte **)(param_1 + 4);
    }
LAB_:
    if ((*pbVar17 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = *(int *)(param_1 + 2);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + 0xe;
      puVar8 = (ulonglong *)func_0x(param_1 + 1);
      uVar14 = *puVar8;
      uVar3 = (ushort)(uVar14 >> 0x30);
      if ((((uint)(int)(short)uVar3 >> 1 ^ (int)(short)uVar3) & 0x2000) != 0) {
        if ((uVar14 & 0x4000000000000000) == 0) {
          uVar3 = uVar3 & 0xdfff;
        }
        else {
          uVar3 = uVar3 | 0x2000;
        }
      }
      if (uVar3 == 0xfffc) {
        iVar5 = (int)((uVar14 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar5;
      uVar14 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar5 = (int)uVar14;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar14 + *(longlong *)(param_1 + 4))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar11 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar11 != 0 &&
           (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
          (*(char *)(lVar11 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9f6a08,0xb166d8,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar5 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar5 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar11 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar11 != 0 &&
          ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
           (*(char *)(lVar11 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9f6a08,0xb166d8,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar12 = -*(short *)param_2;
  if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
    bVar2 = **(byte **)(param_1 + 4);
    if ((bVar2 & 0x10) == 0) {
      if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
LAB_:
        piVar6 = *(int **)(param_2 + 2) + 1;
        *param_5 = **(int **)(param_2 + 2);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)*param_2) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
             *(ushort *)(param_2 + 1))) goto LAB_;
  }
  lVar11 = (longlong)sVar12;
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar12) {
    *param_5 = 0;
    piVar6 = *(int **)(param_1 + 4);
    goto LAB_;
  }
  lVar18 = *(longlong *)(param_1 + 4);
  lVar9 = (ulonglong)*(uint *)(param_1 + 10) + lVar18;
  if (sVar12 == 1) {
    uVar13 = *(uint *)(param_1 + 0xc);
    uVar16 = *(ushort *)(lVar9 + lVar11 * 2) & 0x7fff;
LAB_:
    if (uVar16 < uVar13) goto LAB_;
  }
  else {
    uVar13 = *(ushort *)(lVar9 + -2 + lVar11 * 2) & 0x7fff;
    lVar18 = *(longlong *)(param_1 + 4);
    uVar16 = *(ushort *)(lVar9 + lVar11 * 2) & 0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar13) goto LAB_;
LAB_:
    func_0x(lVar18,7);
  }
  *param_5 = uVar16 - uVar13;
  piVar6 = (int *)((ulonglong)uVar13 + *(longlong *)(param_1 + 4));
LAB_:
  *param_6 = piVar6;
  *param_7 = *param_5;
  return piVar6;
}

