
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong *param_3,longlong param_4)

{
  uint *puVar1;
  code *pcVar2;
  char *pcVar3;
  char cVar4;
  byte bVar5;
  undefined uVar6;
  short sVar7;
  ushort uVar8;
  ushort uVar9;
  ushort uVar10;
  undefined2 uVar11;
  undefined4 uVar12;
  int iVar13;
  uint uVar14;
  longlong lVar15;
  byte *pbVar16;
  undefined4 *puVar17;
  longlong lVar18;
  longlong lVar19;
  undefined8 uVar20;
  longlong lVar21;
  undefined *puVar22;
  byte *pbVar23;
  undefined8 uVar24;
  undefined8 uVar25;
  undefined2 *puVar26;
  byte bVar27;
  uint uVar28;
  ulonglong uVar29;
  uint uVar30;
  uint uVar31;
  uint uVar32;
  undefined8 unaff_RBX;
  int *piVar33;
  longlong *plVar34;
  uint *puVar35;
  undefined *puVar36;
  uint uVar37;
  uint uVar38;
  int iVar39;
  ushort *puVar40;
  ushort *puVar41;
  undefined2 *puVar42;
  int iVar43;
  longlong lVar44;
  longlong lVar45;
  short *psVar46;
  ulonglong uVar47;
  undefined2 *puVar48;
  uint auStackX_18 [2];
  longlong lStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  puVar36 = &stack0xffffffffffffffc8 + lVar15;
  puVar22 = &stack0xffffffffffffffc8 + lVar15;
  puVar1 = (uint *)((longlong)auStackX_18 + lVar15);
  *(undefined8 *)(&stack0x00000330 + lVar15) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00006850 + lVar15) = unaff_RBX;
  *(ulonglong *)(&stack0x000067f8 + lVar15) = _DAT_ ^ (ulonglong)puVar1;
  uVar20 = 0;
  iVar13 = 0;
  lVar44 = *(longlong *)(param_1 + 0x3f0);
  *(longlong *)((longlong)&lStackX_20 + lVar15) = lVar44;
  if (*(longlong *)(lVar44 + 0x10) == 0) {
    plVar34 = (longlong *)(param_1 + 0x40);
    if (param_2 != plVar34) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107fbd;
      (*_DAT_)(1,0xbd2e08,0xbd2de0,0x4f5);
    }
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar15) = &stack0x000001f8 + lVar15;
    lVar44 = *plVar34;
    uVar20 = *(undefined8 *)(param_1 + 0x38);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107fe0;
    func_0x(uVar20,lVar44,param_3,param_4);
    lVar44 = *(longlong *)(&stack0x000001f8 + lVar15);
    if (lVar44 != 0) {
      if (lVar44 != *plVar34) {
        *(longlong *)(param_1 + 0x48) = *plVar34;
        lVar44 = *(longlong *)(&stack0x000001f8 + lVar15);
      }
      *plVar34 = lVar44;
      puVar22 = &stack0xffffffffffffffc8 + lVar15;
    }
    goto LAB_;
  }
  *(undefined8 *)(&stack0x00000310 + lVar15) = 0x7bbf00;
  *(undefined (*) [16])(&stack0x00000318 + lVar15) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000328 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10008e;
  func_0x(&stack0x00000398 + lVar15);
  *(undefined4 *)(&stack0x000000bc + lVar15) = 0;
  *(undefined8 *)(&stack0x000000d0 + lVar15) = 0;
  *(undefined4 *)(&stack0x000000d8 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1000af;
  func_0x(&stack0x000002c8 + lVar15);
  if (param_3 == (longlong *)0x0) {
    param_3 = *(longlong **)(&stack0x000000a8 + lVar15);
    puVar36 = &stack0xffffffffffffffc8 + lVar15;
  }
  else {
    if ((*(int *)(param_1 + 0x3d8) == *(int *)(param_3 + 1)) &&
       (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x3c4) * 0x10000)) {
      pcVar2 = **(code ***)(param_1 + 0x3b0);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100106;
      sVar7 = (*pcVar2)(param_1 + 0x3b0);
      if (*(short *)((longlong)param_3 + 0xc) != sVar7) goto LAB_;
      if (param_3[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10012b;
      func_0x(param_3,param_1 + 0x3b0);
    }
    uVar47 = (ulonglong)*(ushort *)(param_3 + 7);
    uVar9 = *(ushort *)((longlong)param_3 + 0x62);
    if ((*(ushort *)(param_3 + 7) & 0x400) == 0) {
      *(longlong **)(&stack0x000000a8 + lVar15) = param_3;
      *(uint *)(&stack0x000000b8 + lVar15) = (uint)uVar9;
      *(longlong *)(&stack0x000000c0 + lVar15) = param_4;
      *(undefined8 *)(&stack0x000000c8 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000100 + lVar15) = 0;
      *(longlong *)(&stack0x000000b0 + lVar15) = param_3[0xe];
      lVar44 = **(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160);
      *(undefined8 *)(&stack0x000000d0 + lVar15) = *(undefined8 *)(lVar44 + 0xa8);
      *(undefined4 *)(&stack0x000000d8 + lVar15) = *(undefined4 *)(lVar44 + 0xb0);
      *(uint *)(&stack0x000000bc + lVar15) = *(uint *)(&stack0x000000bc + lVar15) | 0x10;
      puVar36 = &stack0xffffffffffffffc8 + lVar15;
    }
    else {
      if (uVar9 == 0) {
        lVar44 = 0;
        uVar9 = 0;
      }
      else {
        iVar13 = (uint)uVar9 * 8;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001c9;
        lVar18 = func_0x();
        lVar18 = -lVar18;
        *(longlong *)(&stack0x00000090 + lVar15) = (longlong)auStackX_18 + lVar18 + lVar15;
        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar15) = 0x1001ea;
        lVar19 = func_0x();
        lVar19 = -lVar19;
        puVar36 = &stack0xffffffffffffffc8 + lVar19 + lVar18 + lVar15;
        lVar44 = (longlong)auStackX_18 + lVar19 + lVar18 + lVar15;
        *(longlong *)(&stack0x00000070 + lVar15) = lVar44;
        uVar8 = *(ushort *)(param_3 + 0xb);
        uVar32 = *(uint *)((longlong)param_3 + 0x54);
        uVar37 = 0x1f9e;
        if (uVar32 < 0x1f9f) {
LAB_:
          uVar37 = uVar32;
          if (uVar32 != 0) goto LAB_;
        }
        else {
          if (0x1f9d < uVar8) {
            uVar32 = (uint)uVar8;
            goto LAB_;
          }
LAB_:
          *(undefined **)(&stack0x000000f8 + lVar15) = &stack0x000002c8 + lVar15;
          *(undefined8 *)((longlong)&uStack_40 + lVar19 + lVar18 + lVar15) = 0x100232;
          func_0x(&stack0x000002c8 + lVar15);
          uVar47 = (ulonglong)uVar37 + 0xf;
          if (uVar47 <= uVar37) {
            uVar47 = 0xffffffffffffff0;
          }
          uVar47 = uVar47 & 0xfffffffffffffff0;
          *(undefined8 *)((longlong)&uStack_40 + lVar19 + lVar18 + lVar15) = 0x100253;
          func_0x();
          puVar36 = &stack0xffffffffffffffc8 + -uVar47 + lVar19 + lVar18 + lVar15;
          *(ulonglong *)(&stack0x000002d0 + lVar15) =
               (longlong)auStackX_18 + -uVar47 + lVar19 + lVar18 + lVar15;
          *(ushort *)(&stack0x000002cc + lVar15) = (short)uVar37 - uVar8;
          *(ushort *)(&stack0x000002ce + lVar15) = uVar8;
          uVar9 = *(ushort *)((longlong)param_3 + 0x62);
          uVar47 = (ulonglong)*(ushort *)(param_3 + 7);
          lVar44 = *(longlong *)(&stack0x00000070 + lVar15);
        }
        uVar20 = *(undefined8 *)(&stack0x00000090 + lVar15);
      }
      *(longlong **)(&stack0x000000a8 + lVar15) = param_3;
      *(uint *)(&stack0x000000b8 + lVar15) = (uint)uVar9;
      *(longlong *)(&stack0x000000c0 + lVar15) = param_4;
      *(undefined8 *)(&stack0x000000c8 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000100 + lVar15) = 0;
      *(longlong *)(&stack0x000000b0 + lVar15) = param_3[0xe];
      lVar18 = **(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160);
      *(undefined8 *)(&stack0x000000d0 + lVar15) = *(undefined8 *)(lVar18 + 0xa8);
      *(undefined4 *)(&stack0x000000d8 + lVar15) = *(undefined4 *)(lVar18 + 0xb0);
      uVar32 = *(uint *)(&stack0x000000bc + lVar15);
      *(uint *)(&stack0x000000bc + lVar15) = uVar32 | 0x10;
      if (((uVar47 & 0x400) != 0) && (param_4 != 0)) {
        *(uint *)(&stack0x000000bc + lVar15) = uVar32 | 0x14;
        *(int *)(puVar36 + 0x30) = iVar13;
        *(longlong *)(puVar36 + 0x28) = lVar44;
        *(int *)(puVar36 + 0x20) = iVar13;
        *(undefined8 *)(puVar36 + -8) = 0x100345;
        func_0x(&stack0x000000a8 + lVar15,param_1 + 0x3b0,(uint)uVar9,uVar20);
        param_3 = *(longlong **)(&stack0x000000a8 + lVar15);
      }
    }
  }
  lVar44 = 0;
  lVar18 = *(longlong *)((longlong)&lStackX_20 + lVar15);
  psVar46 = (short *)(lVar18 + 8);
  *(short **)(&stack0x00000088 + lVar15) = psVar46;
  *(int *)(&stack0x00000078 + lVar15) = *(int *)(*(longlong *)(param_1 + 0x3b8) + 0xb0) * 2;
  uVar32 = 0;
  if ((*(byte *)(param_3 + 7) & 0x20) == 0) {
    if ((*(uint *)((longlong)param_3 + 0x5c) & 2) == 0) {
      if ((*(uint *)((longlong)param_3 + 0x5c) & 4) == 0) {
        if (*psVar46 == 0) {
          *psVar46 = 0;
          puVar41 = (ushort *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 10);
          *(ushort **)(&stack0x00000090 + lVar15) = puVar41;
          uVar9 = *(ushort *)(*(longlong *)(&stack0x000000a8 + lVar15) + 0x62);
          *(uint *)(&stack0x000000a0 + lVar15) = (uint)uVar9;
          *(undefined4 *)(&stack0x00000080 + lVar15) = 0;
          puVar35 = *(uint **)(&stack0x000000b0 + lVar15);
          *(uint **)(&stack0x00000060 + lVar15) = puVar35;
          if (uVar9 != 0) {
            do {
              uVar47 = 0;
              (&stack0x00000069)[lVar15] = 0;
              *(undefined8 *)(puVar36 + -8) = 0x100598;
              func_0x(&stack0x000000a8 + lVar15,puVar35,&stack0x00000069 + lVar15);
              if ((&stack0x00000069)[lVar15] == '\x03') {
                if ((puVar35[0x10] & 0x4000) == 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x103154;
                  (*_DAT_)(6,0x51,0x10,1);
                }
                uVar11 = *(undefined2 *)(puVar35 + 0xf);
                *(undefined8 *)(puVar36 + -8) = 0x103168;
                func_0x(puVar41,puVar35,uVar11,1);
                goto LAB_;
              }
              if (*(short *)(puVar35 + 1) != 0) {
                *(undefined8 *)(puVar36 + -8) = 0x1005b6;
                func_0x(puVar41,puVar35);
              }
              *(undefined8 *)(puVar36 + -8) = 0x1005cc;
              func_0x(&stack0x000000a8 + lVar15,puVar35,&stack0x00000138 + lVar15);
              cVar4 = *(char *)(puVar35 + 0x10);
              if ((cVar4 == '\x01') || (cVar4 == '\x02')) {
                lVar44 = *(longlong *)(&stack0x00000138 + lVar15);
                if ((puVar35[0x10] >> 8 & 1) == 0) {
                  uVar32 = *puVar35;
                  lVar18 = *(longlong *)(puVar41 + 3);
                  uVar11 = *(undefined2 *)(puVar35 + 0xf);
                  *(undefined8 *)(puVar36 + -8) = 0x103073;
                  func_0x((int)uVar32 + lVar18,lVar44,uVar11);
                }
                else {
                  if (((puVar35[0x10] & 0x8000) == 0) || (((&stack0x000000bc)[lVar15] & 8) == 0)) {
                    lVar18 = *(longlong *)(&stack0x000000c0 + lVar15);
                    if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
                      lVar18 = *(longlong *)(&stack0x000000c8 + lVar15);
                    }
                    uVar32 = *(uint *)(*(longlong *)(*(longlong *)(puVar35 + 0x12) + 0x18) + lVar18)
                    ;
                  }
                  else {
                    uVar32 = *(uint *)(*(longlong *)(&stack0x000000e0 + lVar15) +
                                      (ulonglong)puVar35[0xe] * 8);
                  }
                  uVar37 = (uint)*(ushort *)(puVar35 + 0xf);
                  if (uVar32 < uVar37) {
                    uVar47 = (ulonglong)(uVar37 - uVar32);
                  }
                  else if (uVar37 < uVar32) {
                    *(undefined8 *)(puVar36 + -8) = 0x1030e4;
                    (*_DAT_)(6,0x5c,0x16,1);
                  }
                  uVar6 = *(undefined *)(*(longlong *)(puVar35 + 0x12) + 0x24);
                  iVar13 = **(int **)(&stack0x00000060 + lVar15);
                  lVar18 = *(longlong *)(puVar41 + 3);
                  if ((lVar44 != 0) && (uVar32 != 0)) {
                    *(undefined8 *)(puVar36 + -8) = 0x103110;
                    func_0x(iVar13 + lVar18,lVar44,uVar32);
                  }
                  if ((int)uVar47 == 0) {
LAB_:
                    puVar35 = *(uint **)(&stack0x00000060 + lVar15);
                  }
                  else {
                    *(undefined8 *)(puVar36 + -8) = 0x103129;
                    func_0x((ulonglong)uVar32 + iVar13 + lVar18,uVar6,uVar47);
                    puVar35 = *(uint **)(&stack0x00000060 + lVar15);
                  }
                }
              }
              else if ((cVar4 == '\x03') || (cVar4 == '\x04')) {
                uVar32 = puVar35[0x10];
                piVar33 = *(int **)(&stack0x00000138 + lVar15);
                *(int **)(&stack0x00000070 + lVar15) = piVar33;
                if (((uVar32 >> 0xd & 1) == 0) || (*piVar33 != 0)) {
                  if (((uVar32 & 0x8000) == 0) || (((&stack0x000000bc)[lVar15] & 8) == 0)) {
                    lVar44 = *(longlong *)(puVar35 + 0x12);
                    if ((uVar32 >> 8 & 1) == 0) {
                      uVar47 = (ulonglong)*(ushort *)(lVar44 + 2);
                    }
                    else {
                      lVar18 = *(longlong *)(&stack0x000000c0 + lVar15);
                      if ((*(byte *)(lVar44 + 0x2a) & 0x10) != 0) {
                        lVar18 = *(longlong *)(&stack0x000000c8 + lVar15);
                      }
                      uVar47 = (ulonglong)*(uint *)(*(longlong *)(lVar44 + 0x18) + lVar18);
                    }
                  }
                  else {
                    uVar47 = (ulonglong)
                             *(uint *)(*(longlong *)(&stack0x000000e0 + lVar15) +
                                      (ulonglong)puVar35[0xe] * 8);
                  }
                }
                uVar32 = (uint)uVar47;
                *puVar1 = uVar32;
                if (*(ushort *)(puVar35 + 0xf) < uVar32) {
                  *(undefined8 *)(puVar36 + -8) = 0x101b8e;
                  (*_DAT_)(6,0x52,0x16,0x93);
                  piVar33 = *(int **)(&stack0x00000138 + lVar15);
                  *(int **)(&stack0x00000070 + lVar15) = piVar33;
                }
                uVar37 = *puVar35;
                if (-1 < (int)uVar37) {
                  uVar9 = *(ushort *)((longlong)puVar35 + 6);
                  if ((uVar9 & 8) == 0) {
                    if (*(int *)(puVar41 + 1) == 0) {
                      *puVar41 = 0;
                      uVar37 = *(uint *)(puVar41 + 7);
                      uVar29 = (ulonglong)uVar37;
                      *(uint *)(puVar41 + 9) = uVar37;
                      pbVar23 = *(byte **)(puVar41 + 3);
                      bVar27 = *pbVar23;
                      pbVar16 = pbVar23;
                      if ((bVar27 & 0x10) != 0) {
                        uVar37 = uVar37 + (*(ushort *)(pbVar23 + uVar29) + 7 >> 3) + 2;
                        uVar29 = (ulonglong)uVar37;
                        *(uint *)(puVar41 + 9) = uVar37;
                        bVar27 = *pbVar23;
                        pbVar16 = *(byte **)(puVar41 + 3);
                      }
                      if ((bVar27 & 0x20) == 0) {
                        *(int *)(puVar41 + 1) = (int)uVar29;
                        puVar41[0xd] = 0;
                        *(uint *)(puVar41 + 0xb) = uVar37;
                      }
                      else {
                        puVar40 = (ushort *)(pbVar23 + uVar29);
                        uVar9 = *puVar40;
                        puVar41[0xd] = uVar9;
                        if (uVar9 == 0) {
                          *(undefined8 *)(puVar36 + -8) = 0x101c20;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x101c29;
                            lVar44 = func_0x();
                            if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar36 + -8) = 0x101c43;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x101c5f;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x101c85;
                                (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                              }
                            }
                          }
                          uVar20 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x101c93;
                          func_0x(uVar20,3);
                          uVar9 = puVar41[0xd];
                          uVar37 = *(uint *)(puVar41 + 9);
                        }
                        uVar37 = uVar37 + (uVar9 + 1) * 2;
                        *(uint *)(puVar41 + 0xb) = uVar37;
                        if (0x1f9e < uVar37) {
                          *(undefined8 *)(puVar36 + -8) = 0x101cc2;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x101ccb;
                            lVar44 = func_0x();
                            if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar36 + -8) = 0x101ce5;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x101d01;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x101d27;
                                (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                              }
                            }
                          }
                          uVar20 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x101d35;
                          func_0x(uVar20,4);
                          uVar9 = puVar41[0xd];
                          uVar37 = *(uint *)(puVar41 + 0xb);
                        }
                        uVar29 = (ulonglong)uVar9;
                        uVar9 = puVar40[uVar29];
                        *(uint *)(puVar41 + 1) = uVar9 & 0x7fff;
                        if ((uVar9 & 0x7fff) < uVar37) {
                          *(undefined8 *)(puVar36 + -8) = 0x101d5f;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x101d68;
                            lVar44 = func_0x();
                            if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar36 + -8) = 0x101d82;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x101d9e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x101dc4;
                                (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                              }
                            }
                          }
                          uVar20 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x101dd2;
                          func_0x(uVar20,4);
                          uVar29 = (ulonglong)puVar41[0xd];
                        }
                        if ((short)puVar40[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                          do {
                            lVar44 = *(longlong *)(puVar41 + 3);
                            lVar18 = (ulonglong)*(uint *)(puVar41 + 9) + lVar44;
                            if ((int)uVar29 == 1) {
                              uVar37 = *(uint *)(puVar41 + 0xb);
                              uVar9 = *(ushort *)(lVar18 + uVar29 * 2);
                              uVar38 = uVar37;
LAB_:
                              if ((uVar9 & 0x7fff) < uVar37) goto LAB_;
                            }
                            else {
                              uVar37 = *(ushort *)(lVar18 + -2 + uVar29 * 2) & 0x7fff;
                              uVar38 = *(uint *)(puVar41 + 0xb);
                              uVar9 = *(ushort *)(lVar18 + uVar29 * 2);
                              if (uVar38 <= uVar37) goto LAB_;
LAB_:
                              *(undefined8 *)(puVar36 + -8) = 0x101e37;
                              func_0x(lVar44,7);
                              uVar38 = *(uint *)(puVar41 + 0xb);
                              lVar44 = *(longlong *)(puVar41 + 3);
                            }
                            if ((uVar37 < uVar38) || (*(uint *)(puVar41 + 1) < uVar37))
                            goto LAB_;
                            if (*(ushort *)((ulonglong)uVar37 + lVar44) == 5) {
                              *puVar41 = *puVar41 | 2;
                              puVar41[0xd] = puVar41[0xd] - 1;
                              puVar41[0x14] = (ushort)uVar37;
                              lVar44 = (ulonglong)(uVar37 & 0xffff) + *(longlong *)(puVar41 + 3);
                              uVar9 = *(ushort *)(lVar44 + 2);
                              uVar8 = puVar41[0x15] & 0xc7ff;
                              if ((uVar9 >> 0xe & 1) != 0) {
                                uVar8 = uVar9 & 0x3800 | uVar8;
                              }
                              puVar41[0x15] = uVar8;
                              puVar41[0x15] = (uVar8 ^ *(ushort *)(lVar44 + 2)) & 0x7ff ^ uVar8;
                              goto LAB_;
                            }
                            if (*(ushort *)((ulonglong)uVar37 + lVar44) < 0x400) goto LAB_;
                            *puVar41 = *puVar41 | 1;
                            uVar9 = puVar41[0xd] - 1;
                            puVar41[0xd] = uVar9;
                            if (uVar9 == 0) goto LAB_;
                            uVar29 = (ulonglong)uVar9;
                          } while ((short)puVar40[(ulonglong)(uVar9 - 1) + 1] < 0);
                          pbVar16 = *(byte **)(puVar41 + 3);
                        }
                        else {
LAB_:
                          pbVar16 = *(byte **)(puVar41 + 3);
                        }
                      }
                      if ((*pbVar16 & 0x40) == 0) {
                        *(undefined4 *)(puVar41 + 0x12) = 0;
                      }
                      else {
                        *(int *)(puVar41 + 0x12) = *(int *)(puVar41 + 1);
                        *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 0xe;
                        *(undefined8 *)(puVar36 + -8) = 0x101f21;
                        uVar20 = func_0x(puVar41);
                        *(undefined8 *)(puVar36 + -8) = 0x101f30;
                        func_0x(uVar20,&stack0x00000238 + lVar15);
                        *(undefined8 *)(puVar36 + -8) = 0x101f3c;
                        iVar13 = func_0x(&stack0x00000238 + lVar15);
                        *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
                        pbVar16 = *(byte **)(puVar41 + 3);
                      }
                      uVar37 = *(uint *)(puVar41 + 1);
                      if ((*(byte **)(puVar41 + 0xe) != (byte *)0x0) &&
                         (*(byte **)(puVar41 + 0xe) < pbVar16 + uVar37)) {
                        *(undefined8 *)(puVar36 + -8) = 0x101f72;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x101f7b;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x101f95;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x101fb1;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x101fd7;
                              (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x101fe5;
                        func_0x(uVar20,0x12);
                        uVar37 = *(uint *)(puVar41 + 1);
                      }
                      if (0x3f3b < uVar37 - 1) {
                        *(undefined8 *)(puVar36 + -8) = 0x101ffe;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x102007;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x102021;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x10203d;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x102063;
                              (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x102071;
                        func_0x(uVar20,5);
                      }
                    }
LAB_:
                    uVar37 = *puVar35;
                    uVar31 = uVar37 + uVar32;
                    uVar38 = *(uint *)(puVar41 + 7);
                    if (uVar38 < uVar31) {
                      *(undefined8 *)(puVar36 + -8) = 0x102093;
                      func_0x(puVar41,0,uVar31 - uVar38,0);
                      if ((1 << (**(byte **)(puVar41 + 3) & 0xe) & 0x1105U) != 0) {
                        *(short *)(*(byte **)(puVar41 + 3) + 2) = (short)uVar31;
                      }
                      *(uint *)(puVar41 + 7) = uVar31;
                      uVar37 = *puVar35;
                    }
                    lVar44 = *(longlong *)(puVar41 + 3);
                    if ((piVar33 != (int *)0x0) && (uVar32 != 0)) {
                      *(undefined8 *)(puVar36 + -8) = 0x1020d6;
                      func_0x((int)uVar37 + lVar44,piVar33,uVar47);
                    }
                  }
                  else {
LAB_:
                    uVar38 = (uint)uVar9;
                    lVar44 = (longlong)(int)uVar37;
                    cVar4 = *(char *)piVar33;
                    uVar37 = uVar37 + 1;
                    uVar32 = *(uint *)(puVar41 + 7);
                    if (uVar32 < uVar37) {
                      *(undefined8 *)(puVar36 + -8) = 0x10066d;
                      func_0x(puVar41,0,uVar37 - uVar32,0);
                      if ((1 << (**(byte **)(puVar41 + 3) & 0xe) & 0x1105U) != 0) {
                        *(short *)(*(byte **)(puVar41 + 3) + 2) = (short)uVar37;
                      }
                      *(uint *)(puVar41 + 7) = uVar37;
                      uVar38 = (uint)*(byte *)((longlong)puVar35 + 6);
                    }
                    lVar18 = *(longlong *)(puVar41 + 3);
                    if (cVar4 == '\0') {
                      *(byte *)(lVar18 + lVar44) =
                           *(byte *)(lVar18 + lVar44) & ~(byte)(1 << (uVar38 & 7));
                    }
                    else {
                      *(byte *)(lVar18 + lVar44) =
                           *(byte *)(lVar18 + lVar44) | (byte)(1 << (uVar38 & 7));
                    }
                  }
                  goto LAB_;
                }
                if ((uVar37 & 0xc0000000) != 0x80000000) {
                  if (*(int *)(puVar41 + 1) == 0) {
                    *puVar41 = 0;
                    uVar37 = *(uint *)(puVar41 + 7);
                    uVar29 = (ulonglong)uVar37;
                    *(uint *)(puVar41 + 9) = uVar37;
                    pbVar23 = *(byte **)(puVar41 + 3);
                    bVar27 = *pbVar23;
                    if ((bVar27 & 0x10) != 0) {
                      uVar37 = uVar37 + (*(ushort *)(pbVar23 + uVar29) + 7 >> 3) + 2;
                      uVar29 = (ulonglong)uVar37;
                      *(uint *)(puVar41 + 9) = uVar37;
                      bVar27 = *pbVar23;
                    }
                    if ((bVar27 & 0x20) == 0) {
                      *(int *)(puVar41 + 1) = (int)uVar29;
                      puVar41[0xd] = 0;
                      *(uint *)(puVar41 + 0xb) = uVar37;
                    }
                    else {
                      puVar40 = (ushort *)(pbVar23 + uVar29);
                      uVar9 = *puVar40;
                      puVar41[0xd] = uVar9;
                      if (uVar9 == 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x102181;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x10218a;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x1021a4;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x1021c0;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x1021e6;
                              (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x1021f4;
                        func_0x(uVar20,3);
                        uVar9 = puVar41[0xd];
                        uVar37 = *(uint *)(puVar41 + 9);
                      }
                      uVar37 = uVar37 + (uVar9 + 1) * 2;
                      *(uint *)(puVar41 + 0xb) = uVar37;
                      if (0x1f9e < uVar37) {
                        *(undefined8 *)(puVar36 + -8) = 0x102223;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x10222c;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x102246;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x102262;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x102288;
                              (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x102296;
                        func_0x(uVar20,4);
                        uVar9 = puVar41[0xd];
                        uVar37 = *(uint *)(puVar41 + 0xb);
                      }
                      uVar29 = (ulonglong)uVar9;
                      uVar9 = puVar40[uVar29];
                      *(uint *)(puVar41 + 1) = uVar9 & 0x7fff;
                      if ((uVar9 & 0x7fff) < uVar37) {
                        *(undefined8 *)(puVar36 + -8) = 0x1022c0;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x1022c9;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x1022e3;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x1022ff;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x102325;
                              (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x102333;
                        func_0x(uVar20,4);
                        uVar29 = (ulonglong)puVar41[0xd];
                      }
                      if ((short)puVar40[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                        do {
                          lVar44 = *(longlong *)(puVar41 + 3);
                          lVar18 = (ulonglong)*(uint *)(puVar41 + 9) + lVar44;
                          if ((int)uVar29 == 1) {
                            uVar37 = *(uint *)(puVar41 + 0xb);
                            uVar9 = *(ushort *)(lVar18 + uVar29 * 2);
                            uVar38 = uVar37;
LAB_:
                            if ((uVar9 & 0x7fff) < uVar37) goto LAB_;
                          }
                          else {
                            uVar37 = *(ushort *)(lVar18 + -2 + uVar29 * 2) & 0x7fff;
                            uVar38 = *(uint *)(puVar41 + 0xb);
                            uVar9 = *(ushort *)(lVar18 + uVar29 * 2);
                            if (uVar38 <= uVar37) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar36 + -8) = 0x102397;
                            func_0x(lVar44,7);
                            uVar38 = *(uint *)(puVar41 + 0xb);
                          }
                          if ((uVar37 < uVar38) || (*(uint *)(puVar41 + 1) < uVar37))
                          goto LAB_;
                          if (*(ushort *)((ulonglong)uVar37 + *(longlong *)(puVar41 + 3)) == 5) {
                            *puVar41 = *puVar41 | 2;
                            puVar41[0xd] = puVar41[0xd] - 1;
                            puVar41[0x14] = (ushort)uVar37;
                            lVar44 = (ulonglong)(uVar37 & 0xffff) + *(longlong *)(puVar41 + 3);
                            uVar9 = *(ushort *)(lVar44 + 2);
                            uVar8 = puVar41[0x15] & 0xc7ff;
                            if ((uVar9 >> 0xe & 1) != 0) {
                              uVar8 = uVar9 & 0x3800 | uVar8;
                            }
                            puVar41[0x15] = uVar8;
                            puVar41[0x15] = (uVar8 ^ *(ushort *)(lVar44 + 2)) & 0x7ff ^ uVar8;
                            goto LAB_;
                          }
                          if (*(ushort *)((ulonglong)uVar37 + *(longlong *)(puVar41 + 3)) < 0x400)
                          goto LAB_;
                          *puVar41 = *puVar41 | 1;
                          uVar9 = puVar41[0xd] - 1;
                          puVar41[0xd] = uVar9;
                          if (uVar9 == 0) goto LAB_;
                          uVar29 = (ulonglong)uVar9;
                        } while ((short)puVar40[(ulonglong)(uVar9 - 1) + 1] < 0);
                        pbVar23 = *(byte **)(puVar41 + 3);
                      }
                      else {
LAB_:
                        pbVar23 = *(byte **)(puVar41 + 3);
                      }
                    }
                    if ((*pbVar23 & 0x40) == 0) {
                      *(undefined4 *)(puVar41 + 0x12) = 0;
                    }
                    else {
                      *(int *)(puVar41 + 0x12) = *(int *)(puVar41 + 1);
                      *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 0xe;
                      *(undefined8 *)(puVar36 + -8) = 0x102480;
                      uVar20 = func_0x(puVar41);
                      *(undefined8 *)(puVar36 + -8) = 0x10248f;
                      func_0x(uVar20,&stack0x00000240 + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x10249b;
                      iVar13 = func_0x(&stack0x00000240 + lVar15);
                      *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
                    }
                    uVar37 = *(uint *)(puVar41 + 1);
                    if ((*(ulonglong *)(puVar41 + 0xe) != 0) &&
                       (*(ulonglong *)(puVar41 + 0xe) <
                        (ulonglong)uVar37 + *(longlong *)(puVar41 + 3))) {
                      *(undefined8 *)(puVar36 + -8) = 0x1024ce;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x1024d7;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x1024f1;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x10250d;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x102533;
                            (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x102541;
                      func_0x(uVar20,0x12);
                      uVar37 = *(uint *)(puVar41 + 1);
                    }
                    if (0x3f3b < uVar37 - 1) {
                      *(undefined8 *)(puVar36 + -8) = 0x10255a;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x102563;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x10257d;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x102599;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x1025bf;
                            (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x1025cd;
                      func_0x(uVar20,5);
                    }
                  }
LAB_:
                  uVar37 = -*puVar35;
                  if ((uVar32 == 0) && (puVar41[0xd] < uVar37)) goto LAB_;
                  *(undefined8 *)(puVar36 + -8) = 0x1025f2;
                  func_0x(&stack0x00000598 + lVar15);
                  pbVar23 = *(byte **)(puVar41 + 3);
                  bVar27 = *pbVar23;
                  if ((bVar27 >> 6 & 1) != 0) {
                    *(undefined8 *)(puVar36 + -8) = 0x102616;
                    func_0x(puVar41,&stack0x00000598 + lVar15);
                    pbVar23 = *(byte **)(puVar41 + 3);
                  }
                  if (uVar32 != 0) {
                    if ((*pbVar23 & 0x20) == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x102633;
                      func_0x(puVar41);
                      pbVar23 = *(byte **)(puVar41 + 3);
                    }
                    uVar9 = puVar41[0xd];
                    uVar32 = (uint)uVar9;
                    if (uVar9 < uVar37) {
                      iVar13 = uVar37 - uVar9;
                      puVar40 = (ushort *)(pbVar23 + *(uint *)(puVar41 + 9));
                      uVar38 = *(uint *)(puVar41 + 9) + 2 + uVar32 * 2;
                      uVar31 = iVar13 * 2;
                      uVar30 = 0;
                      if (*puVar40 != 0) {
                        do {
                          uVar9 = puVar40[(ulonglong)uVar30 + 1];
                          puVar40[(ulonglong)(uVar30 & 0xffff) + 1] =
                               puVar40[(ulonglong)(uVar30 & 0xffff) + 1] & 0x8000;
                          puVar40[(ulonglong)(uVar30 & 0xffff) + 1] =
                               puVar40[(ulonglong)(uVar30 & 0xffff) + 1] |
                               (uVar9 & 0x7fff) + (short)uVar31 & 0x7fff;
                          uVar30 = uVar30 + 1;
                        } while (uVar30 < *puVar40);
                        pbVar23 = *(byte **)(puVar41 + 3);
                      }
                      iVar39 = *(int *)(puVar41 + 1);
                      *(undefined8 *)(puVar36 + -8) = 0x1026bc;
                      func_0x
                                (pbVar23 + (ulonglong)uVar38 + (ulonglong)uVar31,pbVar23 + uVar38,
                                 iVar39 - uVar38);
                      *(uint *)(puVar41 + 1) = *(int *)(puVar41 + 1) + uVar31;
                      *(uint *)(puVar41 + 0xb) = *(int *)(puVar41 + 0xb) + uVar31;
                      uVar9 = (ushort)*(undefined4 *)(puVar41 + 0xb);
                      if (uVar32 != 0) {
                        uVar9 = puVar40[(ulonglong)(uVar32 - 1) + 1] & 0x7fff;
                      }
                      do {
                        puVar40[(ulonglong)(uVar32 & 0xffff) + 1] = uVar9 & 0x7fff;
                        uVar32 = uVar32 + 1;
                      } while (uVar32 < uVar37);
                      *puVar40 = *puVar40 + (short)iVar13;
                      *(undefined8 *)(puVar36 + -8) = 0x10270b;
                      iVar13 = func_0x(puVar41);
                      if (iVar13 != 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x10271e;
                        uVar9 = func_0x(puVar41,&stack0x00000208 + lVar15);
                        puVar41[0x14] = uVar9;
                      }
                      puVar41[0xd] = (ushort)uVar37;
                      pbVar23 = *(byte **)(puVar41 + 3);
                      uVar47 = (ulonglong)*puVar1;
                    }
                  }
                  uVar32 = *(uint *)(puVar41 + 9);
                  if (puVar41[0xd] < uVar37) {
                    uVar32 = *(ushort *)(pbVar23 + (ulonglong)puVar41[0xd] * 2 + (ulonglong)uVar32)
                             & 0x7fff;
                    iVar13 = 0;
                  }
                  else {
                    uVar9 = *(ushort *)(pbVar23 + (longlong)(int)uVar37 * 2 + (ulonglong)uVar32);
                    if (uVar37 == 1) {
                      uVar32 = *(uint *)(puVar41 + 0xb);
LAB_:
                      if ((uVar9 & 0x7fff) < uVar32) goto LAB_;
                    }
                    else {
                      uVar32 = *(ushort *)
                                (pbVar23 + (longlong)(int)uVar37 * 2 + ((ulonglong)uVar32 - 2)) &
                               0x7fff;
                      if (*(uint *)(puVar41 + 0xb) <= uVar32) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar36 + -8) = 0x10277f;
                      func_0x(pbVar23,7);
                      pbVar23 = *(byte **)(puVar41 + 3);
                    }
                    iVar13 = (uVar9 & 0x7fff) - uVar32;
                  }
                  if ((int)uVar47 != iVar13) {
                    puVar40 = (ushort *)(pbVar23 + *(uint *)(puVar41 + 9));
                    lVar44 = *(longlong *)(puVar41 + 3);
                    uVar12 = *(undefined4 *)(puVar41 + 1);
                    *(undefined8 *)(puVar36 + -8) = 0x1027b9;
                    uVar12 = func_0x(uVar12,uVar32 + iVar13);
                    uVar38 = *puVar1;
                    *(undefined8 *)(puVar36 + -8) = 0x1027ce;
                    func_0x
                              ((longlong)(int)uVar38 + (ulonglong)uVar32 + lVar44,
                               (longlong)iVar13 + (ulonglong)uVar32 + lVar44,uVar12);
                    uVar38 = uVar37 - 1;
                    if ((int)uVar38 < (int)(uint)*puVar40) {
                      uVar31 = *puVar1;
                      do {
                        uVar9 = puVar40[(longlong)(int)uVar38 + 1];
                        puVar40[((ulonglong)uVar38 & 0xffff) + 1] =
                             puVar40[((ulonglong)uVar38 & 0xffff) + 1] & 0x8000;
                        puVar40[((ulonglong)uVar38 & 0xffff) + 1] =
                             puVar40[((ulonglong)uVar38 & 0xffff) + 1] |
                             ((uVar9 & 0x7fff) - (short)iVar13) + (short)uVar31 & 0x7fff;
                        uVar38 = uVar38 + 1;
                      } while ((int)uVar38 < (int)(uint)*puVar40);
                      puVar41 = *(ushort **)(&stack0x00000090 + lVar15);
                    }
                    uVar47 = (ulonglong)*puVar1;
                    *(uint *)(puVar41 + 1) = *(int *)(puVar41 + 1) + (*puVar1 - iVar13);
                    *(undefined8 *)(puVar36 + -8) = 0x102838;
                    iVar13 = func_0x(puVar41);
                    if (iVar13 != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x10284b;
                      uVar9 = func_0x(puVar41,&stack0x0000020c + lVar15);
                      puVar41[0x14] = uVar9;
                    }
                  }
                  lVar44 = *(longlong *)(puVar41 + 3);
                  uVar20 = *(undefined8 *)(&stack0x00000070 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x102862;
                  func_0x((ulonglong)uVar32 + lVar44,uVar20,uVar47);
                  if (((int)uVar47 == 0) && (uVar37 == puVar41[0xd])) {
                    *(undefined8 *)(puVar36 + -8) = 0x10287f;
                    func_0x(puVar41,uVar37,1);
                  }
                  if ((bVar27 >> 6 & 1) != 0) {
                    *(undefined8 *)(puVar36 + -8) = 0x102893;
                    func_0x(puVar41,&stack0x00000598 + lVar15);
                  }
                  puVar35 = *(uint **)(&stack0x00000060 + lVar15);
                  goto LAB_;
                }
                *(undefined8 *)(puVar36 + -8) = 0x1028ae;
                func_0x(&stack0x00000678 + lVar15);
                *(undefined4 *)(&stack0x00000108 + lVar15) = 0;
                if (*(int *)(puVar41 + 1) == 0) {
                  *puVar41 = 0;
                  uVar37 = *(uint *)(puVar41 + 7);
                  uVar29 = (ulonglong)uVar37;
                  *(uint *)(puVar41 + 9) = uVar37;
                  pbVar23 = *(byte **)(puVar41 + 3);
                  bVar27 = *pbVar23;
                  if ((bVar27 & 0x10) != 0) {
                    uVar37 = uVar37 + (*(ushort *)(pbVar23 + uVar29) + 7 >> 3) + 2;
                    uVar29 = (ulonglong)uVar37;
                    *(uint *)(puVar41 + 9) = uVar37;
                    bVar27 = *pbVar23;
                  }
                  if ((bVar27 & 0x20) == 0) {
                    *(int *)(puVar41 + 1) = (int)uVar29;
                    puVar41[0xd] = 0;
                    *(uint *)(puVar41 + 0xb) = uVar37;
                  }
                  else {
                    puVar40 = (ushort *)(pbVar23 + uVar29);
                    uVar9 = *puVar40;
                    puVar41[0xd] = uVar9;
                    if (uVar9 == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x102918;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x102921;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x10293b;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x102957;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x10297d;
                            (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x10298b;
                      func_0x(uVar20,3);
                      uVar9 = puVar41[0xd];
                      uVar37 = *(uint *)(puVar41 + 9);
                    }
                    uVar37 = uVar37 + (uVar9 + 1) * 2;
                    *(uint *)(puVar41 + 0xb) = uVar37;
                    if (0x1f9e < uVar37) {
                      *(undefined8 *)(puVar36 + -8) = 0x1029ba;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x1029c3;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x1029dd;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x1029f9;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x102a1f;
                            (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x102a2d;
                      func_0x(uVar20,4);
                      uVar9 = puVar41[0xd];
                      uVar37 = *(uint *)(puVar41 + 0xb);
                    }
                    uVar29 = (ulonglong)uVar9;
                    uVar9 = puVar40[uVar29];
                    *(uint *)(puVar41 + 1) = uVar9 & 0x7fff;
                    if ((uVar9 & 0x7fff) < uVar37) {
                      *(undefined8 *)(puVar36 + -8) = 0x102a57;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x102a60;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x102a7a;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x102a96;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x102abc;
                            (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x102aca;
                      func_0x(uVar20,4);
                      uVar29 = (ulonglong)puVar41[0xd];
                    }
                    if ((short)puVar40[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                      do {
                        lVar44 = *(longlong *)(puVar41 + 3);
                        lVar18 = (ulonglong)*(uint *)(puVar41 + 9) + lVar44;
                        if ((int)uVar29 == 1) {
                          uVar37 = *(uint *)(puVar41 + 0xb);
                          uVar9 = *(ushort *)(lVar18 + uVar29 * 2);
                          uVar38 = uVar37;
LAB_:
                          if ((uVar9 & 0x7fff) < uVar37) goto LAB_;
                        }
                        else {
                          uVar37 = *(ushort *)(lVar18 + -2 + uVar29 * 2) & 0x7fff;
                          uVar38 = *(uint *)(puVar41 + 0xb);
                          uVar9 = *(ushort *)(lVar18 + uVar29 * 2);
                          if (uVar38 <= uVar37) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar36 + -8) = 0x102b27;
                          func_0x(lVar44,7);
                          uVar38 = *(uint *)(puVar41 + 0xb);
                        }
                        if ((uVar37 < uVar38) || (*(uint *)(puVar41 + 1) < uVar37))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar37 + *(longlong *)(puVar41 + 3)) == 5) {
                          *puVar41 = *puVar41 | 2;
                          puVar41[0xd] = puVar41[0xd] - 1;
                          puVar41[0x14] = (ushort)uVar37;
                          lVar44 = (ulonglong)(uVar37 & 0xffff) + *(longlong *)(puVar41 + 3);
                          uVar9 = *(ushort *)(lVar44 + 2);
                          uVar8 = puVar41[0x15] & 0xc7ff;
                          if ((uVar9 >> 0xe & 1) != 0) {
                            uVar8 = uVar9 & 0x3800 | uVar8;
                          }
                          puVar41[0x15] = uVar8;
                          puVar41[0x15] = (uVar8 ^ *(ushort *)(lVar44 + 2)) & 0x7ff ^ uVar8;
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar37 + *(longlong *)(puVar41 + 3)) < 0x400)
                        goto LAB_;
                        *puVar41 = *puVar41 | 1;
                        uVar9 = puVar41[0xd] - 1;
                        puVar41[0xd] = uVar9;
                        if (uVar9 == 0) goto LAB_;
                        uVar29 = (ulonglong)uVar9;
                      } while ((short)puVar40[(ulonglong)(uVar9 - 1) + 1] < 0);
                      pbVar23 = *(byte **)(puVar41 + 3);
                    }
                    else {
LAB_:
                      pbVar23 = *(byte **)(puVar41 + 3);
                    }
                  }
                  if ((*pbVar23 & 0x40) == 0) {
                    *(undefined4 *)(puVar41 + 0x12) = 0;
                  }
                  else {
                    *(int *)(puVar41 + 0x12) = *(int *)(puVar41 + 1);
                    *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 0xe;
                    *(undefined8 *)(puVar36 + -8) = 0x102c10;
                    uVar20 = func_0x(puVar41);
                    *(undefined8 *)(puVar36 + -8) = 0x102c1f;
                    func_0x(uVar20,&stack0x00000248 + lVar15);
                    *(undefined8 *)(puVar36 + -8) = 0x102c2b;
                    iVar13 = func_0x(&stack0x00000248 + lVar15);
                    *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
                  }
                  uVar37 = *(uint *)(puVar41 + 1);
                  if ((*(ulonglong *)(puVar41 + 0xe) != 0) &&
                     (*(ulonglong *)(puVar41 + 0xe) < (ulonglong)uVar37 + *(longlong *)(puVar41 + 3)
                     )) {
                    *(undefined8 *)(puVar36 + -8) = 0x102c5e;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + -8) = 0x102c67;
                      lVar44 = func_0x();
                      if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar36 + -8) = 0x102c81;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 == '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x102c9d;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(puVar36 + 0x20) = 0;
                          *(undefined8 *)(puVar36 + -8) = 0x102cc3;
                          (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                        }
                      }
                    }
                    uVar20 = *(undefined8 *)(puVar41 + 3);
                    *(undefined8 *)(puVar36 + -8) = 0x102cd1;
                    func_0x(uVar20,0x12);
                    uVar37 = *(uint *)(puVar41 + 1);
                  }
                  if (0x3f3b < uVar37 - 1) {
                    *(undefined8 *)(puVar36 + -8) = 0x102cea;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + -8) = 0x102cf3;
                      lVar44 = func_0x();
                      if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar36 + -8) = 0x102d0d;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 == '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x102d29;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(puVar36 + 0x20) = 0;
                          *(undefined8 *)(puVar36 + -8) = 0x102d4f;
                          (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                        }
                      }
                    }
                    uVar20 = *(undefined8 *)(puVar41 + 3);
                    *(undefined8 *)(puVar36 + -8) = 0x102d5d;
                    func_0x(uVar20,5);
                  }
                }
LAB_:
                *(undefined8 *)(puVar36 + -8) = 0x102d65;
                iVar13 = func_0x(puVar41);
                if ((iVar13 == 0) && (uVar32 == 0)) goto LAB_;
                bVar27 = **(byte **)(puVar41 + 3);
                if ((bVar27 >> 6 & 1) != 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x102d93;
                  func_0x(puVar41,&stack0x00000678 + lVar15);
                }
                if ((*(byte *)puVar41 & 1) != 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x102dac;
                  puVar17 = (undefined4 *)func_0x(puVar41,0x400,&stack0x00000108 + lVar15);
                  *(undefined4 *)(&stack0x000001e8 + lVar15) = *puVar17;
                  *(undefined2 *)(&stack0x000001ec + lVar15) = *(undefined2 *)(puVar17 + 1);
                  *(undefined2 *)(&stack0x000001ee + lVar15) =
                       *(undefined2 *)((longlong)puVar17 + 6);
                }
                pbVar23 = *(byte **)(puVar41 + 3);
                if ((*pbVar23 & 0x20) == 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x102ddb;
                  func_0x(puVar41);
                  pbVar23 = *(byte **)(puVar41 + 3);
                }
                uVar32 = *(uint *)(puVar41 + 9);
                *(undefined8 *)(puVar36 + -8) = 0x102dee;
                iVar13 = func_0x(puVar41);
                lVar44 = *(longlong *)(puVar41 + 3);
                uVar9 = puVar41[0xd];
                uVar29 = (ulonglong)uVar9;
                puVar40 = (ushort *)(lVar44 + (ulonglong)*(uint *)(puVar41 + 9));
                uVar37 = (uint)uVar9;
                if (iVar13 == 0) {
                  uVar31 = *(uint *)(puVar41 + 9) + (uVar9 + 1) * 2;
                  uVar38 = 0;
                  if (*puVar40 != 0) {
                    do {
                      uVar8 = puVar40[(ulonglong)uVar38 + 1];
                      puVar40[(ulonglong)(uVar38 & 0xffff) + 1] =
                           puVar40[(ulonglong)(uVar38 & 0xffff) + 1] & 0x8000;
                      puVar40[(ulonglong)(uVar38 & 0xffff) + 1] =
                           puVar40[(ulonglong)(uVar38 & 0xffff) + 1] | (uVar8 & 0x7fff) + 2 & 0x7fff
                      ;
                      uVar38 = uVar38 + 1;
                    } while (uVar38 < *puVar40);
                    lVar44 = *(longlong *)(puVar41 + 3);
                  }
                  lVar44 = (ulonglong)uVar31 + lVar44;
                  iVar13 = *(int *)(puVar41 + 1);
                  *(undefined8 *)(puVar36 + -8) = 0x102ec5;
                  func_0x(lVar44 + 2,lVar44,iVar13 - uVar31);
                  *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 2;
                  *(int *)(puVar41 + 0xb) = *(int *)(puVar41 + 0xb) + 2;
                  uVar8 = (ushort)*(undefined4 *)(puVar41 + 0xb);
                  if (uVar37 != 0) {
                    uVar8 = puVar40[(ulonglong)(uVar9 - 1) + 1] & 0x7fff;
                  }
                  if (uVar37 < uVar9 + 1) {
                    do {
                      puVar40[(uVar29 & 0xffff) + 1] = uVar8 & 0x7fff;
                      uVar37 = (int)uVar29 + 1;
                      uVar29 = (ulonglong)uVar37;
                    } while (uVar37 < uVar9 + 1);
                  }
                  *puVar40 = *puVar40 + 1;
                  *(undefined8 *)(puVar36 + -8) = 0x102f19;
                  func_0x(puVar41);
                  iVar39 = 0;
                  uVar9 = *(ushort *)(pbVar23 + (ulonglong)puVar41[0xd] * 2 + (ulonglong)uVar32 + 2)
                  ;
                  *(undefined8 *)(puVar36 + -8) = 0x102f31;
                  func_0x(&stack0x00000388 + lVar15);
                  *(undefined4 *)(puVar36 + 0x28) = 0;
                  *(undefined8 *)(puVar36 + 0x20) = *(undefined8 *)(&stack0x00000060 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x102f53;
                  func_0x(&stack0x00000378 + lVar15,piVar33,uVar47,0);
                  *(undefined **)(puVar36 + 0x28) = &stack0x000001cc + lVar15;
                  *(undefined **)(puVar36 + 0x20) = &stack0x00000378 + lVar15;
                  *(undefined8 *)(puVar36 + -8) = 0x102f8e;
                  func_0x(puVar41 + 0x14,uVar9 & 0x7fff,0x1f9e,1);
                  iVar13 = *(int *)(&stack0x000001cc + lVar15);
                }
                else {
                  if (uVar37 == 0) {
                    uVar37 = *(uint *)(puVar41 + 0xb);
                    uVar38 = puVar40[uVar29 + 1] & 0x7fff;
LAB_:
                    if (uVar38 < uVar37) goto LAB_;
                  }
                  else {
                    uVar37 = puVar40[uVar29] & 0x7fff;
                    uVar38 = puVar40[uVar29 + 1] & 0x7fff;
                    if (*(uint *)(puVar41 + 0xb) <= uVar37) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar36 + -8) = 0x102e3f;
                    func_0x(lVar44,7);
                  }
                  iVar39 = uVar38 - uVar37;
                  uVar37 = *puVar1;
                  uVar20 = *(undefined8 *)(&stack0x00000060 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x102e58;
                  iVar13 = func_0x(puVar41 + 0x14,uVar20,piVar33,uVar37);
                }
                iVar39 = (iVar13 - iVar39) + *(int *)(puVar41 + 1);
                *(int *)(puVar41 + 1) = iVar39;
                if ((*(byte *)puVar41 & 1) != 0) {
                  *(ushort *)(pbVar23 + (ulonglong)puVar41[0xd] * 2 + (ulonglong)uVar32 + 4) =
                       (ushort)iVar39 | 0x8000;
                  iVar39 = (*(int *)(puVar41 + 1) - *(int *)(&stack0x00000108 + lVar15)) + -2;
                }
                *(ushort *)(pbVar23 + (ulonglong)puVar41[0xd] * 2 + (ulonglong)uVar32 + 2) =
                     (ushort)iVar39 | 0x8000;
                if (iVar13 == 0) {
                  uVar9 = puVar41[0xd];
                  *(undefined8 *)(puVar36 + -8) = 0x102fe3;
                  func_0x(puVar41,uVar9 + 1);
                  if ((**(byte **)(puVar41 + 3) & 0x20) != 0) {
                    puVar41[0xd] = puVar41[0xd] + 1;
                    *puVar41 = *puVar41 & 0xfffd;
                    *(undefined8 *)(puVar36 + -8) = 0x103000;
                    func_0x(puVar41 + 0x14);
                  }
                }
                else {
                  *puVar41 = *puVar41 | 2;
                  *(undefined8 *)(puVar36 + -8) = 0x103012;
                  uVar9 = func_0x(puVar41,&stack0x00000210 + lVar15);
                  puVar41[0x14] = uVar9;
                }
                if ((*(byte *)puVar41 & 1) != 0) {
                  uVar12 = *(undefined4 *)(&stack0x00000108 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x103036;
                  func_0x(puVar41,0x400,uVar12,&stack0x000001e8 + lVar15);
                }
                if ((bVar27 >> 6 & 1) != 0) {
                  puVar22 = &stack0x00000678;
LAB_:
                  *(undefined8 *)(puVar36 + -8) = 0x101af1;
                  func_0x(puVar41,(longlong)puVar22 + lVar15);
                }
LAB_:
                puVar35 = *(uint **)(&stack0x00000060 + lVar15);
              }
              else if (cVar4 == '\b') {
                piVar33 = *(int **)(&stack0x00000138 + lVar15);
                *(int **)(&stack0x00000070 + lVar15) = piVar33;
                uVar37 = *puVar35;
                if ((int)uVar37 < 0) {
                  if ((uVar37 & 0xc0000000) == 0x80000000) {
                    *(undefined8 *)(puVar36 + -8) = 0x101352;
                    func_0x(&stack0x000004b8 + lVar15);
                    *(undefined4 *)(&stack0x00000110 + lVar15) = 0;
                    if (*(int *)(puVar41 + 1) == 0) {
                      *puVar41 = 0;
                      uVar32 = *(uint *)(puVar41 + 7);
                      uVar29 = (ulonglong)uVar32;
                      *(uint *)(puVar41 + 9) = uVar32;
                      pbVar23 = *(byte **)(puVar41 + 3);
                      bVar27 = *pbVar23;
                      pbVar16 = pbVar23;
                      if ((bVar27 & 0x10) != 0) {
                        uVar32 = uVar32 + (*(ushort *)(pbVar23 + uVar29) + 7 >> 3) + 2;
                        uVar29 = (ulonglong)uVar32;
                        *(uint *)(puVar41 + 9) = uVar32;
                        bVar27 = *pbVar23;
                        pbVar16 = *(byte **)(puVar41 + 3);
                      }
                      if ((bVar27 & 0x20) == 0) {
                        *(int *)(puVar41 + 1) = (int)uVar29;
                        puVar41[0xd] = 0;
                        *(uint *)(puVar41 + 0xb) = uVar32;
                      }
                      else {
                        puVar40 = (ushort *)(pbVar23 + uVar29);
                        uVar9 = *puVar40;
                        puVar41[0xd] = uVar9;
                        if (uVar9 == 0) {
                          *(undefined8 *)(puVar36 + -8) = 0x1013c4;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x1013cd;
                            lVar44 = func_0x();
                            if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar36 + -8) = 0x1013e7;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x101403;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x101429;
                                (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                              }
                            }
                          }
                          uVar20 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x101437;
                          func_0x(uVar20,3);
                          uVar9 = puVar41[0xd];
                          uVar32 = *(uint *)(puVar41 + 9);
                        }
                        uVar32 = uVar32 + (uVar9 + 1) * 2;
                        *(uint *)(puVar41 + 0xb) = uVar32;
                        if (0x1f9e < uVar32) {
                          *(undefined8 *)(puVar36 + -8) = 0x101466;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x10146f;
                            lVar44 = func_0x();
                            if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar36 + -8) = 0x101489;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x1014a5;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x1014cb;
                                (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                              }
                            }
                          }
                          uVar20 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x1014d9;
                          func_0x(uVar20,4);
                          uVar9 = puVar41[0xd];
                          uVar32 = *(uint *)(puVar41 + 0xb);
                        }
                        uVar29 = (ulonglong)uVar9;
                        uVar9 = puVar40[uVar29];
                        *(uint *)(puVar41 + 1) = uVar9 & 0x7fff;
                        if ((uVar9 & 0x7fff) < uVar32) {
                          *(undefined8 *)(puVar36 + -8) = 0x101503;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x10150c;
                            lVar44 = func_0x();
                            if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar36 + -8) = 0x101526;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x101542;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x101568;
                                (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                              }
                            }
                          }
                          uVar20 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x101576;
                          func_0x(uVar20,4);
                          uVar29 = (ulonglong)puVar41[0xd];
                        }
                        if ((short)puVar40[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                          do {
                            lVar44 = *(longlong *)(puVar41 + 3);
                            lVar18 = (ulonglong)*(uint *)(puVar41 + 9) + lVar44;
                            if ((int)uVar29 == 1) {
                              uVar32 = *(uint *)(puVar41 + 0xb);
                              uVar9 = *(ushort *)(lVar18 + uVar29 * 2);
                              uVar37 = uVar32;
LAB_:
                              if ((uVar9 & 0x7fff) < uVar32) goto LAB_;
                            }
                            else {
                              uVar32 = *(ushort *)(lVar18 + -2 + uVar29 * 2) & 0x7fff;
                              uVar37 = *(uint *)(puVar41 + 0xb);
                              uVar9 = *(ushort *)(lVar18 + uVar29 * 2);
                              if (uVar37 <= uVar32) goto LAB_;
LAB_:
                              *(undefined8 *)(puVar36 + -8) = 0x1015d7;
                              func_0x(lVar44,7);
                              uVar37 = *(uint *)(puVar41 + 0xb);
                              lVar44 = *(longlong *)(puVar41 + 3);
                            }
                            if ((uVar32 < uVar37) || (*(uint *)(puVar41 + 1) < uVar32))
                            goto LAB_;
                            if (*(ushort *)((ulonglong)uVar32 + lVar44) == 5) {
                              *puVar41 = *puVar41 | 2;
                              puVar41[0xd] = puVar41[0xd] - 1;
                              puVar41[0x14] = (ushort)uVar32;
                              lVar44 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(puVar41 + 3);
                              uVar9 = *(ushort *)(lVar44 + 2);
                              uVar8 = puVar41[0x15] & 0xc7ff;
                              if ((uVar9 >> 0xe & 1) != 0) {
                                uVar8 = uVar9 & 0x3800 | uVar8;
                              }
                              puVar41[0x15] = uVar8;
                              puVar41[0x15] = (uVar8 ^ *(ushort *)(lVar44 + 2)) & 0x7ff ^ uVar8;
                              goto LAB_;
                            }
                            if (*(ushort *)((ulonglong)uVar32 + lVar44) < 0x400) goto LAB_;
                            *puVar41 = *puVar41 | 1;
                            uVar9 = puVar41[0xd] - 1;
                            puVar41[0xd] = uVar9;
                            if (uVar9 == 0) goto LAB_;
                            uVar29 = (ulonglong)uVar9;
                          } while ((short)puVar40[(ulonglong)(uVar9 - 1) + 1] < 0);
                          pbVar16 = *(byte **)(puVar41 + 3);
                          uVar29 = (ulonglong)*(uint *)(puVar41 + 1);
                        }
                        else {
LAB_:
                          pbVar16 = *(byte **)(puVar41 + 3);
                          uVar29 = (ulonglong)*(uint *)(puVar41 + 1);
                        }
                      }
                      if ((*pbVar16 & 0x40) == 0) {
                        *(undefined4 *)(puVar41 + 0x12) = 0;
                      }
                      else {
                        *(int *)(puVar41 + 0x12) = (int)uVar29;
                        *(int *)(puVar41 + 1) = (int)uVar29 + 0xe;
                        *(undefined8 *)(puVar36 + -8) = 0x1016c1;
                        uVar20 = func_0x(puVar41);
                        *(undefined8 *)(puVar36 + -8) = 0x1016d0;
                        func_0x(uVar20,&stack0x00000230 + lVar15);
                        *(undefined8 *)(puVar36 + -8) = 0x1016dc;
                        iVar13 = func_0x(&stack0x00000230 + lVar15);
                        *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
                        uVar29 = (ulonglong)*(uint *)(puVar41 + 1);
                        pbVar16 = *(byte **)(puVar41 + 3);
                      }
                      iVar13 = (int)uVar29;
                      if ((*(byte **)(puVar41 + 0xe) != (byte *)0x0) &&
                         (*(byte **)(puVar41 + 0xe) < pbVar16 + uVar29)) {
                        *(undefined8 *)(puVar36 + -8) = 0x101715;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x10171e;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x101738;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x101754;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x10177a;
                              (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x101788;
                        func_0x(uVar20,0x12);
                        iVar13 = *(int *)(puVar41 + 1);
                      }
                      if (0x3f3b < iVar13 - 1U) {
                        *(undefined8 *)(puVar36 + -8) = 0x1017a1;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x1017aa;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x1017c4;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x1017e0;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x101806;
                              (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x101814;
                        func_0x(uVar20,5);
                      }
                    }
LAB_:
                    *(undefined8 *)(puVar36 + -8) = 0x10181c;
                    func_0x(puVar41);
                    bVar27 = **(byte **)(puVar41 + 3);
                    if ((bVar27 >> 6 & 1) != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x10183d;
                      func_0x(puVar41,&stack0x000004b8 + lVar15);
                    }
                    if ((*(byte *)puVar41 & 1) != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x101856;
                      puVar17 = (undefined4 *)
                                func_0x(puVar41,0x400,&stack0x00000110 + lVar15);
                      *(undefined4 *)(&stack0x000001e0 + lVar15) = *puVar17;
                      *(undefined2 *)(&stack0x000001e4 + lVar15) = *(undefined2 *)(puVar17 + 1);
                      *(undefined2 *)(&stack0x000001e6 + lVar15) =
                           *(undefined2 *)((longlong)puVar17 + 6);
                    }
                    pbVar23 = *(byte **)(puVar41 + 3);
                    if ((*pbVar23 & 0x20) == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x101885;
                      func_0x(puVar41);
                      pbVar23 = *(byte **)(puVar41 + 3);
                    }
                    uVar32 = *(uint *)(puVar41 + 9);
                    *(undefined8 *)(puVar36 + -8) = 0x101898;
                    iVar13 = func_0x(puVar41);
                    lVar44 = *(longlong *)(puVar41 + 3);
                    uVar9 = puVar41[0xd];
                    uVar29 = (ulonglong)uVar9;
                    puVar40 = (ushort *)(lVar44 + (ulonglong)*(uint *)(puVar41 + 9));
                    uVar37 = (uint)uVar9;
                    if (iVar13 == 0) {
                      uVar38 = *(uint *)(puVar41 + 9) + (uVar9 + 1) * 2;
                      if (*puVar40 != 0) {
                        do {
                          uVar8 = puVar40[uVar47 + 1];
                          puVar40[(uVar47 & 0xffff) + 1] = puVar40[(uVar47 & 0xffff) + 1] & 0x8000;
                          puVar40[(uVar47 & 0xffff) + 1] =
                               puVar40[(uVar47 & 0xffff) + 1] | (uVar8 & 0x7fff) + 2 & 0x7fff;
                          uVar31 = (int)uVar47 + 1;
                          uVar47 = (ulonglong)uVar31;
                        } while (uVar31 < *puVar40);
                        lVar44 = *(longlong *)(puVar41 + 3);
                      }
                      lVar44 = (ulonglong)uVar38 + lVar44;
                      iVar13 = *(int *)(puVar41 + 1);
                      *(undefined8 *)(puVar36 + -8) = 0x101974;
                      func_0x(lVar44 + 2,lVar44,iVar13 - uVar38);
                      *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 2;
                      *(int *)(puVar41 + 0xb) = *(int *)(puVar41 + 0xb) + 2;
                      uVar8 = (ushort)*(undefined4 *)(puVar41 + 0xb);
                      if (uVar37 != 0) {
                        uVar8 = puVar40[(ulonglong)(uVar9 - 1) + 1] & 0x7fff;
                      }
                      if (uVar37 < uVar9 + 1) {
                        do {
                          puVar40[(uVar29 & 0xffff) + 1] = uVar8 & 0x7fff;
                          uVar37 = (int)uVar29 + 1;
                          uVar29 = (ulonglong)uVar37;
                        } while (uVar37 < uVar9 + 1);
                      }
                      *puVar40 = *puVar40 + 1;
                      *(undefined8 *)(puVar36 + -8) = 0x1019b9;
                      func_0x(puVar41);
                      iVar39 = 0;
                      uVar9 = *(ushort *)
                               (pbVar23 + (ulonglong)puVar41[0xd] * 2 + (ulonglong)uVar32 + 2);
                      *(undefined8 *)(puVar36 + -8) = 0x1019d5;
                      func_0x(&stack0x00000368 + lVar15);
                      *(undefined4 *)(puVar36 + 0x28) = 0;
                      *(undefined8 *)(puVar36 + 0x20) = *(undefined8 *)(&stack0x00000060 + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x1019f9;
                      func_0x(&stack0x00000358 + lVar15,piVar33,1,0);
                      *(undefined **)(puVar36 + 0x28) = &stack0x000001c8 + lVar15;
                      *(undefined **)(puVar36 + 0x20) = &stack0x00000358 + lVar15;
                      *(undefined8 *)(puVar36 + -8) = 0x101a35;
                      func_0x(puVar41 + 0x14,uVar9 & 0x7fff,0x1f9e);
                      iVar13 = *(int *)(&stack0x000001c8 + lVar15);
                    }
                    else {
                      if (uVar37 == 0) {
                        uVar37 = *(uint *)(puVar41 + 0xb);
                        uVar38 = puVar40[uVar29 + 1] & 0x7fff;
LAB_:
                        if (uVar38 < uVar37) goto LAB_;
                      }
                      else {
                        uVar37 = puVar40[uVar29] & 0x7fff;
                        uVar38 = puVar40[uVar29 + 1] & 0x7fff;
                        if (*(uint *)(puVar41 + 0xb) <= uVar37) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar36 + -8) = 0x1018ea;
                        func_0x(lVar44,7);
                      }
                      iVar39 = uVar38 - uVar37;
                      uVar20 = *(undefined8 *)(&stack0x00000060 + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x101905;
                      iVar13 = func_0x(puVar41 + 0x14,uVar20,piVar33);
                    }
                    iVar39 = (*(int *)(puVar41 + 1) - iVar39) + iVar13;
                    *(int *)(puVar41 + 1) = iVar39;
                    if ((*(byte *)puVar41 & 1) != 0) {
                      *(ushort *)(pbVar23 + (ulonglong)puVar41[0xd] * 2 + (ulonglong)uVar32 + 4) =
                           (ushort)iVar39 | 0x8000;
                      iVar39 = (*(int *)(puVar41 + 1) - *(int *)(&stack0x00000110 + lVar15)) + -2;
                    }
                    *(ushort *)(pbVar23 + (ulonglong)puVar41[0xd] * 2 + (ulonglong)uVar32 + 2) =
                         (ushort)iVar39 | 0x8000;
                    if (iVar13 == 0) {
                      uVar9 = puVar41[0xd];
                      *(undefined8 *)(puVar36 + -8) = 0x101a8a;
                      func_0x(puVar41,uVar9 + 1,0);
                      if ((**(byte **)(puVar41 + 3) & 0x20) != 0) {
                        puVar41[0xd] = puVar41[0xd] + 1;
                        *puVar41 = *puVar41 & 0xfffd;
                        *(undefined8 *)(puVar36 + -8) = 0x101aa7;
                        func_0x(puVar41 + 0x14);
                      }
                    }
                    else {
                      *puVar41 = *puVar41 | 2;
                      *(undefined8 *)(puVar36 + -8) = 0x101ab9;
                      uVar9 = func_0x(puVar41,&stack0x00000204 + lVar15);
                      puVar41[0x14] = uVar9;
                    }
                    if ((*(byte *)puVar41 & 1) != 0) {
                      uVar12 = *(undefined4 *)(&stack0x00000110 + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x101add;
                      func_0x(puVar41,0x400,uVar12);
                    }
                    if ((bVar27 >> 6 & 1) != 0) {
                      puVar22 = &stack0x000004b8;
                      goto LAB_;
                    }
                    goto LAB_;
                  }
                  if (*(int *)(puVar41 + 1) == 0) {
                    *puVar41 = 0;
                    uVar32 = *(uint *)(puVar41 + 7);
                    uVar47 = (ulonglong)uVar32;
                    *(uint *)(puVar41 + 9) = uVar32;
                    pbVar23 = *(byte **)(puVar41 + 3);
                    bVar27 = *pbVar23;
                    pbVar16 = pbVar23;
                    if ((bVar27 & 0x10) != 0) {
                      uVar32 = uVar32 + (*(ushort *)(pbVar23 + uVar47) + 7 >> 3) + 2;
                      uVar47 = (ulonglong)uVar32;
                      *(uint *)(puVar41 + 9) = uVar32;
                      bVar27 = *pbVar23;
                      pbVar16 = *(byte **)(puVar41 + 3);
                    }
                    if ((bVar27 & 0x20) == 0) {
                      *(int *)(puVar41 + 1) = (int)uVar47;
                      puVar41[0xd] = 0;
                      *(uint *)(puVar41 + 0xb) = uVar32;
                    }
                    else {
                      puVar40 = (ushort *)(pbVar23 + uVar47);
                      uVar9 = *puVar40;
                      puVar41[0xd] = uVar9;
                      if (uVar9 == 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x100c71;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x100c7a;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x100c94;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x100cb0;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x100cd6;
                              (*_DAT_)(1,0xa17098,0xb36d68);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x100ce4;
                        func_0x(uVar20,3);
                        uVar9 = puVar41[0xd];
                        uVar32 = *(uint *)(puVar41 + 9);
                      }
                      uVar32 = uVar32 + (uVar9 + 1) * 2;
                      *(uint *)(puVar41 + 0xb) = uVar32;
                      if (0x1f9e < uVar32) {
                        *(undefined8 *)(puVar36 + -8) = 0x100d13;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x100d1c;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x100d36;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x100d52;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x100d78;
                              (*_DAT_)(1,0xa17098,0xb36d68);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x100d86;
                        func_0x(uVar20,4);
                        uVar9 = puVar41[0xd];
                        uVar32 = *(uint *)(puVar41 + 0xb);
                      }
                      uVar47 = (ulonglong)uVar9;
                      uVar9 = puVar40[uVar47];
                      *(uint *)(puVar41 + 1) = uVar9 & 0x7fff;
                      if ((uVar9 & 0x7fff) < uVar32) {
                        *(undefined8 *)(puVar36 + -8) = 0x100db0;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x100db9;
                          lVar44 = func_0x();
                          if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar36 + -8) = 0x100dd3;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x100def;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x100e15;
                              (*_DAT_)(1,0xa17098,0xb36d68);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x100e23;
                        func_0x(uVar20,4);
                        uVar47 = (ulonglong)puVar41[0xd];
                      }
                      if ((short)puVar40[(ulonglong)((int)uVar47 - 1) + 1] < 0) {
                        do {
                          lVar44 = *(longlong *)(puVar41 + 3);
                          lVar18 = (ulonglong)*(uint *)(puVar41 + 9) + lVar44;
                          if ((int)uVar47 == 1) {
                            uVar32 = *(uint *)(puVar41 + 0xb);
                            uVar9 = *(ushort *)(lVar18 + uVar47 * 2);
                            uVar37 = uVar32;
LAB_:
                            if ((uVar9 & 0x7fff) < uVar32) goto LAB_;
                          }
                          else {
                            uVar32 = *(ushort *)(lVar18 + -2 + uVar47 * 2) & 0x7fff;
                            uVar37 = *(uint *)(puVar41 + 0xb);
                            uVar9 = *(ushort *)(lVar18 + uVar47 * 2);
                            if (uVar37 <= uVar32) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar36 + -8) = 0x100e87;
                            func_0x(lVar44,7);
                            uVar37 = *(uint *)(puVar41 + 0xb);
                          }
                          if ((uVar32 < uVar37) || (*(uint *)(puVar41 + 1) < uVar32))
                          goto LAB_;
                          if (*(ushort *)((ulonglong)uVar32 + *(longlong *)(puVar41 + 3)) == 5) {
                            *puVar41 = *puVar41 | 2;
                            puVar41[0xd] = puVar41[0xd] - 1;
                            puVar41[0x14] = (ushort)uVar32;
                            lVar44 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(puVar41 + 3);
                            uVar9 = *(ushort *)(lVar44 + 2);
                            uVar8 = puVar41[0x15] & 0xc7ff;
                            if ((uVar9 >> 0xe & 1) != 0) {
                              uVar8 = uVar9 & 0x3800 | uVar8;
                            }
                            puVar41[0x15] = uVar8;
                            puVar41[0x15] = (uVar8 ^ *(ushort *)(lVar44 + 2)) & 0x7ff ^ uVar8;
                            goto LAB_;
                          }
                          if (*(ushort *)((ulonglong)uVar32 + *(longlong *)(puVar41 + 3)) < 0x400)
                          goto LAB_;
                          *puVar41 = *puVar41 | 1;
                          uVar9 = puVar41[0xd] - 1;
                          puVar41[0xd] = uVar9;
                          if (uVar9 == 0) goto LAB_;
                          uVar47 = (ulonglong)uVar9;
                        } while ((short)puVar40[(ulonglong)(uVar9 - 1) + 1] < 0);
                        pbVar16 = *(byte **)(puVar41 + 3);
                      }
                      else {
LAB_:
                        pbVar16 = *(byte **)(puVar41 + 3);
                      }
                    }
                    if ((*pbVar16 & 0x40) == 0) {
                      *(undefined4 *)(puVar41 + 0x12) = 0;
                    }
                    else {
                      *(int *)(puVar41 + 0x12) = *(int *)(puVar41 + 1);
                      *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 0xe;
                      *(undefined8 *)(puVar36 + -8) = 0x100f6c;
                      uVar20 = func_0x(puVar41);
                      *(undefined8 *)(puVar36 + -8) = 0x100f7b;
                      func_0x(uVar20,&stack0x00000228 + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x100f87;
                      iVar13 = func_0x(&stack0x00000228 + lVar15);
                      *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
                    }
                    uVar32 = *(uint *)(puVar41 + 1);
                    if ((*(ulonglong *)(puVar41 + 0xe) != 0) &&
                       (*(ulonglong *)(puVar41 + 0xe) <
                        (ulonglong)uVar32 + *(longlong *)(puVar41 + 3))) {
                      *(undefined8 *)(puVar36 + -8) = 0x100fbb;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x100fc4;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x100fde;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x100ffa;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x101020;
                            (*_DAT_)(1,0xa17098,0xb36d68);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x10102e;
                      func_0x(uVar20,0x12);
                      uVar32 = *(uint *)(puVar41 + 1);
                    }
                    if (0x3f3b < uVar32 - 1) {
                      *(undefined8 *)(puVar36 + -8) = 0x101047;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x101050;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x10106a;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x101086;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x1010ac;
                            (*_DAT_)(1,0xa17098,0xb36d68);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x1010ba;
                      func_0x(uVar20,5);
                    }
                  }
LAB_:
                  uVar32 = -*puVar35;
                  *(undefined8 *)(puVar36 + -8) = 0x1010cd;
                  func_0x(&stack0x000003d8 + lVar15);
                  pbVar23 = *(byte **)(puVar41 + 3);
                  bVar27 = *pbVar23;
                  bVar5 = bVar27 >> 6;
                  if ((bVar5 & 1) != 0) {
                    *(undefined8 *)(puVar36 + -8) = 0x1010f1;
                    func_0x(puVar41,&stack0x000003d8 + lVar15);
                    pbVar23 = *(byte **)(puVar41 + 3);
                    bVar27 = *pbVar23;
                  }
                  if ((bVar27 & 0x20) == 0) {
                    *(undefined8 *)(puVar36 + -8) = 0x101105;
                    func_0x(puVar41);
                    pbVar23 = *(byte **)(puVar41 + 3);
                  }
                  uVar9 = puVar41[0xd];
                  uVar37 = (uint)uVar9;
                  if (uVar9 < uVar32) {
                    iVar13 = uVar32 - uVar9;
                    puVar40 = (ushort *)(pbVar23 + *(uint *)(puVar41 + 9));
                    uVar38 = *(uint *)(puVar41 + 9) + 2 + uVar37 * 2;
                    uVar31 = iVar13 * 2;
                    uVar30 = 0;
                    if (*puVar40 != 0) {
                      do {
                        uVar9 = puVar40[(ulonglong)uVar30 + 1];
                        puVar40[(ulonglong)(uVar30 & 0xffff) + 1] =
                             puVar40[(ulonglong)(uVar30 & 0xffff) + 1] & 0x8000;
                        puVar40[(ulonglong)(uVar30 & 0xffff) + 1] =
                             puVar40[(ulonglong)(uVar30 & 0xffff) + 1] |
                             (uVar9 & 0x7fff) + (short)uVar31 & 0x7fff;
                        uVar30 = uVar30 + 1;
                      } while (uVar30 < *puVar40);
                      pbVar23 = *(byte **)(puVar41 + 3);
                    }
                    iVar39 = *(int *)(puVar41 + 1);
                    *(undefined8 *)(puVar36 + -8) = 0x10119c;
                    func_0x
                              (pbVar23 + (ulonglong)uVar38 + (ulonglong)uVar31,pbVar23 + uVar38,
                               iVar39 - uVar38);
                    *(uint *)(puVar41 + 1) = *(int *)(puVar41 + 1) + uVar31;
                    *(uint *)(puVar41 + 0xb) = *(int *)(puVar41 + 0xb) + uVar31;
                    uVar9 = (ushort)*(undefined4 *)(puVar41 + 0xb);
                    if (uVar37 != 0) {
                      uVar9 = puVar40[(ulonglong)(uVar37 - 1) + 1] & 0x7fff;
                    }
                    do {
                      puVar40[(ulonglong)(uVar37 & 0xffff) + 1] = uVar9 & 0x7fff;
                      uVar37 = uVar37 + 1;
                    } while (uVar37 < uVar32);
                    *puVar40 = *puVar40 + (short)iVar13;
                    *(undefined8 *)(puVar36 + -8) = 0x1011db;
                    iVar13 = func_0x(puVar41);
                    if (iVar13 != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x1011ee;
                      uVar9 = func_0x(puVar41,&stack0x00000214 + lVar15);
                      puVar41[0x14] = uVar9;
                    }
                    puVar41[0xd] = (ushort)uVar32;
                    uVar37 = uVar32 & 0xffff;
                    pbVar23 = *(byte **)(puVar41 + 3);
                  }
                  uVar38 = *(uint *)(puVar41 + 9);
                  if (uVar37 < uVar32) {
                    uVar37 = *(ushort *)(pbVar23 + (ulonglong)uVar37 * 2 + (ulonglong)uVar38) &
                             0x7fff;
                    iVar13 = 0;
LAB_:
                    puVar40 = (ushort *)(pbVar23 + *(uint *)(puVar41 + 9));
                    lVar44 = *(longlong *)(puVar41 + 3);
                    uVar12 = *(undefined4 *)(puVar41 + 1);
                    *(undefined8 *)(puVar36 + -8) = 0x1012b3;
                    uVar12 = func_0x(uVar12,uVar37 + iVar13);
                    *(undefined8 *)(puVar36 + -8) = 0x1012c5;
                    func_0x
                              ((ulonglong)uVar37 + lVar44 + 1,
                               (longlong)iVar13 + (ulonglong)uVar37 + lVar44,uVar12);
                    uVar32 = uVar32 - 1;
                    if ((int)uVar32 < (int)(uint)*puVar40) {
                      do {
                        uVar9 = puVar40[(longlong)(int)uVar32 + 1];
                        puVar40[((ulonglong)uVar32 & 0xffff) + 1] =
                             puVar40[((ulonglong)uVar32 & 0xffff) + 1] & 0x8000;
                        puVar40[((ulonglong)uVar32 & 0xffff) + 1] =
                             puVar40[((ulonglong)uVar32 & 0xffff) + 1] |
                             ((uVar9 & 0x7fff) - (short)iVar13) + 1 & 0x7fff;
                        uVar32 = uVar32 + 1;
                      } while ((int)uVar32 < (int)(uint)*puVar40);
                    }
                    *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + (1 - iVar13);
                    *(undefined8 *)(puVar36 + -8) = 0x101326;
                    iVar13 = func_0x(puVar41);
                    if (iVar13 != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x10133d;
                      uVar9 = func_0x(puVar41,&stack0x00000200 + lVar15);
                      puVar41[0x14] = uVar9;
                    }
                  }
                  else {
                    uVar9 = *(ushort *)(pbVar23 + (longlong)(int)uVar32 * 2 + (ulonglong)uVar38);
                    if (uVar32 == 1) {
                      uVar37 = *(uint *)(puVar41 + 0xb);
LAB_:
                      if ((uVar9 & 0x7fff) < uVar37) goto LAB_;
                    }
                    else {
                      uVar37 = *(ushort *)
                                (pbVar23 + (longlong)(int)uVar32 * 2 + ((ulonglong)uVar38 - 2)) &
                               0x7fff;
                      if (*(uint *)(puVar41 + 0xb) <= uVar37) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar36 + -8) = 0x10124c;
                      func_0x(pbVar23,7);
                      pbVar23 = *(byte **)(puVar41 + 3);
                    }
                    iVar13 = (uVar9 & 0x7fff) - uVar37;
                    if (iVar13 != 1) goto LAB_;
                  }
                  *(undefined *)(*(longlong *)(puVar41 + 3) + (ulonglong)uVar37) =
                       **(undefined **)(&stack0x00000070 + lVar15);
                  if ((bVar5 & 1) != 0) {
                    *(undefined8 *)(puVar36 + -8) = 0x101280;
                    func_0x(puVar41,&stack0x000003d8 + lVar15);
                  }
                  goto LAB_;
                }
                uVar9 = *(ushort *)((longlong)puVar35 + 6);
                if ((uVar9 & 8) != 0) goto LAB_;
                if (*(int *)(puVar41 + 1) == 0) {
                  *puVar41 = 0;
                  uVar32 = *(uint *)(puVar41 + 7);
                  uVar47 = (ulonglong)uVar32;
                  *(uint *)(puVar41 + 9) = uVar32;
                  pbVar23 = *(byte **)(puVar41 + 3);
                  bVar27 = *pbVar23;
                  pbVar16 = pbVar23;
                  if ((bVar27 & 0x10) != 0) {
                    uVar32 = uVar32 + (*(ushort *)(pbVar23 + uVar47) + 7 >> 3) + 2;
                    uVar47 = (ulonglong)uVar32;
                    *(uint *)(puVar41 + 9) = uVar32;
                    bVar27 = *pbVar23;
                    pbVar16 = *(byte **)(puVar41 + 3);
                  }
                  if ((bVar27 & 0x20) == 0) {
                    *(int *)(puVar41 + 1) = (int)uVar47;
                    puVar41[0xd] = 0;
                    *(uint *)(puVar41 + 0xb) = uVar32;
                  }
                  else {
                    puVar40 = (ushort *)(pbVar23 + uVar47);
                    uVar9 = *puVar40;
                    puVar41[0xd] = uVar9;
                    if (uVar9 == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x100735;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x10073e;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x100758;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x100774;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x10079a;
                            (*_DAT_)(1,0xa17098,0xb36d68);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x1007a8;
                      func_0x(uVar20,3);
                      uVar9 = puVar41[0xd];
                      uVar32 = *(uint *)(puVar41 + 9);
                    }
                    uVar32 = uVar32 + (uVar9 + 1) * 2;
                    *(uint *)(puVar41 + 0xb) = uVar32;
                    if (0x1f9e < uVar32) {
                      *(undefined8 *)(puVar36 + -8) = 0x1007d7;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x1007e0;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x1007fa;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x100816;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x10083c;
                            (*_DAT_)(1,0xa17098,0xb36d68);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x10084a;
                      func_0x(uVar20,4);
                      uVar9 = puVar41[0xd];
                      uVar32 = *(uint *)(puVar41 + 0xb);
                    }
                    uVar47 = (ulonglong)uVar9;
                    uVar9 = puVar40[uVar47];
                    *(uint *)(puVar41 + 1) = uVar9 & 0x7fff;
                    if ((uVar9 & 0x7fff) < uVar32) {
                      *(undefined8 *)(puVar36 + -8) = 0x100874;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x10087d;
                        lVar44 = func_0x();
                        if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar36 + -8) = 0x100897;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x1008b3;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x1008d9;
                            (*_DAT_)(1,0xa17098,0xb36d68);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x1008e7;
                      func_0x(uVar20,4);
                      uVar47 = (ulonglong)puVar41[0xd];
                    }
                    if ((short)puVar40[(ulonglong)((int)uVar47 - 1) + 1] < 0) {
                      do {
                        lVar44 = *(longlong *)(puVar41 + 3);
                        lVar18 = (ulonglong)*(uint *)(puVar41 + 9) + lVar44;
                        if ((int)uVar47 == 1) {
                          uVar32 = *(uint *)(puVar41 + 0xb);
                          uVar9 = *(ushort *)(lVar18 + uVar47 * 2);
                          uVar37 = uVar32;
LAB_:
                          if ((uVar9 & 0x7fff) < uVar32) goto LAB_;
                        }
                        else {
                          uVar32 = *(ushort *)(lVar18 + -2 + uVar47 * 2) & 0x7fff;
                          uVar37 = *(uint *)(puVar41 + 0xb);
                          uVar9 = *(ushort *)(lVar18 + uVar47 * 2);
                          if (uVar37 <= uVar32) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar36 + -8) = 0x100947;
                          func_0x(lVar44,7);
                          uVar37 = *(uint *)(puVar41 + 0xb);
                          lVar44 = *(longlong *)(puVar41 + 3);
                        }
                        if ((uVar32 < uVar37) || (*(uint *)(puVar41 + 1) < uVar32))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar32 + lVar44) == 5) {
                          *puVar41 = *puVar41 | 2;
                          puVar41[0xd] = puVar41[0xd] - 1;
                          puVar41[0x14] = (ushort)uVar32;
                          lVar44 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(puVar41 + 3);
                          uVar9 = *(ushort *)(lVar44 + 2);
                          uVar8 = puVar41[0x15] & 0xc7ff;
                          if ((uVar9 >> 0xe & 1) != 0) {
                            uVar8 = uVar9 & 0x3800 | uVar8;
                          }
                          puVar41[0x15] = uVar8;
                          puVar41[0x15] = (uVar8 ^ *(ushort *)(lVar44 + 2)) & 0x7ff ^ uVar8;
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar32 + lVar44) < 0x400) goto LAB_;
                        *puVar41 = *puVar41 | 1;
                        uVar9 = puVar41[0xd] - 1;
                        puVar41[0xd] = uVar9;
                        if (uVar9 == 0) goto LAB_;
                        uVar47 = (ulonglong)uVar9;
                      } while ((short)puVar40[(ulonglong)(uVar9 - 1) + 1] < 0);
                      pbVar16 = *(byte **)(puVar41 + 3);
                    }
                    else {
LAB_:
                      pbVar16 = *(byte **)(puVar41 + 3);
                    }
                  }
                  if ((*pbVar16 & 0x40) == 0) {
                    *(undefined4 *)(puVar41 + 0x12) = 0;
                  }
                  else {
                    *(int *)(puVar41 + 0x12) = *(int *)(puVar41 + 1);
                    *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 0xe;
                    *(undefined8 *)(puVar36 + -8) = 0x100a2e;
                    uVar20 = func_0x(puVar41);
                    *(undefined8 *)(puVar36 + -8) = 0x100a3d;
                    func_0x(uVar20,&stack0x00000220 + lVar15);
                    *(undefined8 *)(puVar36 + -8) = 0x100a49;
                    iVar13 = func_0x(&stack0x00000220 + lVar15);
                    *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
                    pbVar16 = *(byte **)(puVar41 + 3);
                  }
                  uVar32 = *(uint *)(puVar41 + 1);
                  if ((*(byte **)(puVar41 + 0xe) != (byte *)0x0) &&
                     (*(byte **)(puVar41 + 0xe) < pbVar16 + uVar32)) {
                    *(undefined8 *)(puVar36 + -8) = 0x100a80;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + -8) = 0x100a89;
                      lVar44 = func_0x();
                      if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar36 + -8) = 0x100aa3;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 == '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x100abf;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar36 + 0x20) = 0;
                          *(undefined8 *)(puVar36 + -8) = 0x100ae5;
                          (*_DAT_)(1,0xa17098,0xb36d68);
                        }
                      }
                    }
                    uVar20 = *(undefined8 *)(puVar41 + 3);
                    *(undefined8 *)(puVar36 + -8) = 0x100af3;
                    func_0x(uVar20,0x12);
                    uVar32 = *(uint *)(puVar41 + 1);
                  }
                  if (0x3f3b < uVar32 - 1) {
                    *(undefined8 *)(puVar36 + -8) = 0x100b0c;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + -8) = 0x100b15;
                      lVar44 = func_0x();
                      if ((lVar44 != 0) && (*(char *)(lVar44 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar36 + -8) = 0x100b2f;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 == '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x100b4b;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar36 + 0x20) = 0;
                          *(undefined8 *)(puVar36 + -8) = 0x100b71;
                          (*_DAT_)(1,0xa17098,0xb36d68);
                        }
                      }
                    }
                    uVar20 = *(undefined8 *)(puVar41 + 3);
                    *(undefined8 *)(puVar36 + -8) = 0x100b7f;
                    func_0x(uVar20,5);
                  }
                }
LAB_:
                uVar37 = *puVar35;
                uVar32 = uVar37 + 1;
                uVar38 = *(uint *)(puVar41 + 7);
                if (uVar38 < uVar32) {
                  *(undefined8 *)(puVar36 + -8) = 0x100ba0;
                  func_0x(puVar41,0,uVar32 - uVar38,0);
                  if ((1 << (**(byte **)(puVar41 + 3) & 0xe) & 0x1105U) != 0) {
                    *(short *)(*(byte **)(puVar41 + 3) + 2) = (short)uVar32;
                  }
                  *(uint *)(puVar41 + 7) = uVar32;
                  uVar37 = *puVar35;
                }
                if (piVar33 != (int *)0x0) {
                  *(char *)((longlong)(int)uVar37 + *(longlong *)(puVar41 + 3)) = *(char *)piVar33;
                }
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0x793578;
                *(undefined8 *)(puVar36 + -8) = 0x100624;
                (*_DAT_)(1,0xb983d0,0xbc4d10);
              }
LAB_:
              puVar35 = puVar35 + 0x14;
              *(uint **)(&stack0x00000060 + lVar15) = puVar35;
              iVar13 = *(int *)(&stack0x00000080 + lVar15);
              *(uint *)(&stack0x00000080 + lVar15) = iVar13 + 1U;
            } while (iVar13 + 1U < *(uint *)(&stack0x000000a0 + lVar15));
          }
        }
        else if (*(ushort *)((longlong)param_3 + 0x62) != 0) {
          plVar34 = (longlong *)(*(longlong *)(&stack0x000000b0 + lVar15) + 0x48);
          uVar47 = (ulonglong)*(ushort *)((longlong)param_3 + 0x62);
          do {
            iVar13 = 0;
            (&stack0x00000068)[lVar15] = 0;
            *(undefined8 *)(puVar36 + -8) = 0x1031c8;
            func_0x
                      (&stack0x000000a8 + lVar15,plVar34 + -9,&stack0x00000068 + lVar15);
            if ((&stack0x00000068)[lVar15] == '\x03') {
              if ((*(uint *)(plVar34 + -1) & 0x4000) == 0) {
                *(undefined8 *)(puVar36 + -8) = 0x1034ef;
                (*_DAT_)(6,0x51,0x10,1);
              }
              uVar11 = *(undefined2 *)((longlong)plVar34 + -0xc);
              *(undefined8 *)(puVar36 + -8) = 0x103506;
              func_0x(psVar46,plVar34 + -9,uVar11,1);
            }
            else {
              if (*(short *)((longlong)plVar34 + -0x44) != 0) {
                lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
                if (*psVar46 == 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x1031f2;
                  func_0x();
                }
                else {
                  *(undefined8 *)(puVar36 + -8) = 0x1031f9;
                  func_0x(lVar44 + 10,plVar34 + -9);
                }
              }
              *(undefined8 *)(puVar36 + -8) = 0x103210;
              func_0x
                        (&stack0x000000a8 + lVar15,plVar34 + -9,&stack0x00000140 + lVar15);
              cVar4 = *(char *)(plVar34 + -1);
              if ((cVar4 == '\x01') || (cVar4 == '\x02')) {
                lVar44 = *(longlong *)(&stack0x00000140 + lVar15);
                if ((*(uint *)(plVar34 + -1) >> 8 & 1) == 0) {
                  iVar13 = *(int *)(plVar34 + -9);
                  lVar18 = *(longlong *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0x10);
                  uVar11 = *(undefined2 *)((longlong)plVar34 + -0xc);
                  *(undefined8 *)(puVar36 + -8) = 0x10333e;
                  func_0x(iVar13 + lVar18,lVar44,uVar11);
                }
                else {
                  if (((*(uint *)(plVar34 + -1) & 0x8000) == 0) ||
                     (((&stack0x000000bc)[lVar15] & 8) == 0)) {
                    lVar18 = *(longlong *)(&stack0x000000c0 + lVar15);
                    if ((*(byte *)(*plVar34 + 0x2a) & 0x10) != 0) {
                      lVar18 = *(longlong *)(&stack0x000000c8 + lVar15);
                    }
                    uVar32 = *(uint *)(*(longlong *)(*plVar34 + 0x18) + lVar18);
                  }
                  else {
                    uVar32 = *(uint *)(*(longlong *)(&stack0x000000e0 + lVar15) +
                                      (ulonglong)*(uint *)(plVar34 + -2) * 8);
                  }
                  uVar37 = (uint)*(ushort *)((longlong)plVar34 + -0xc);
                  if (uVar32 < uVar37) {
                    iVar13 = uVar37 - uVar32;
                  }
                  else if (uVar37 < uVar32) {
                    *(undefined8 *)(puVar36 + -8) = 0x1033ab;
                    (*_DAT_)(6,0x5c,0x16,1);
                  }
                  uVar6 = *(undefined *)(*plVar34 + 0x24);
                  lVar18 = (longlong)*(int *)(plVar34 + -9) +
                           *(longlong *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0x10);
                  if ((lVar44 != 0) && (uVar32 != 0)) {
                    *(undefined8 *)(puVar36 + -8) = 0x1033d6;
                    func_0x(lVar18,lVar44,uVar32);
                  }
                  if (iVar13 != 0) {
                    *(undefined8 *)(puVar36 + -8) = 0x1033eb;
                    func_0x((ulonglong)uVar32 + lVar18,uVar6,iVar13);
                  }
                  psVar46 = *(short **)(&stack0x00000088 + lVar15);
                }
              }
              else if ((cVar4 == '\x03') || (cVar4 == '\x04')) {
                uVar32 = *(uint *)(plVar34 + -1);
                piVar33 = *(int **)(&stack0x00000140 + lVar15);
                if (((uVar32 >> 0xd & 1) == 0) || (*piVar33 != 0)) {
                  if (((uVar32 & 0x8000) == 0) || (((&stack0x000000bc)[lVar15] & 8) == 0)) {
                    lVar44 = *plVar34;
                    if ((uVar32 >> 8 & 1) == 0) {
                      uVar32 = (uint)*(ushort *)(lVar44 + 2);
                    }
                    else {
                      lVar18 = *(longlong *)(&stack0x000000c0 + lVar15);
                      if ((*(byte *)(lVar44 + 0x2a) & 0x10) != 0) {
                        lVar18 = *(longlong *)(&stack0x000000c8 + lVar15);
                      }
                      uVar32 = *(uint *)(*(longlong *)(lVar44 + 0x18) + lVar18);
                    }
                  }
                  else {
                    uVar32 = *(uint *)(*(longlong *)(&stack0x000000e0 + lVar15) +
                                      (ulonglong)*(uint *)(plVar34 + -2) * 8);
                  }
                }
                else {
                  uVar32 = 0;
                }
                if (*(ushort *)((longlong)plVar34 + -0xc) < uVar32) {
                  *(undefined8 *)(puVar36 + -8) = 0x1032fa;
                  (*_DAT_)(6,0x52,0x16,0x93);
                  piVar33 = *(int **)(&stack0x00000140 + lVar15);
                }
                *(undefined8 *)(puVar36 + -8) = 0x103310;
                func_0x(psVar46,plVar34 + -9,piVar33,uVar32);
              }
              else if (cVar4 == '\b') {
                uVar20 = *(undefined8 *)(&stack0x00000140 + lVar15);
                *(undefined8 *)(puVar36 + -8) = 0x103277;
                func_0x(psVar46,plVar34 + -9,uVar20,1);
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0x793578;
                *(undefined8 *)(puVar36 + -8) = 0x103259;
                (*_DAT_)(1,0xb983d0,0xbc4d10,0x380);
              }
            }
            plVar34 = plVar34 + 10;
            uVar47 = uVar47 - 1;
          } while (uVar47 != 0);
        }
      }
      else {
        *psVar46 = 0;
        lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
        uVar9 = *(ushort *)(*(longlong *)(&stack0x000000a8 + lVar15) + 0x62);
        piVar33 = *(int **)(*(longlong *)(&stack0x000000a8 + lVar15) + 0x70);
        if (uVar9 != 0) {
          *(ulonglong *)(&stack0x00000070 + lVar15) = (ulonglong)uVar9;
          do {
            *(undefined8 *)(puVar36 + -8) = 0x1003df;
            cVar4 = func_0x(&stack0x000000a8 + lVar15,piVar33);
            if (cVar4 == '\x03') {
              if ((piVar33[0x10] & 0x4000U) == 0) {
                *(undefined8 *)(puVar36 + -8) = 0x100520;
                (*_DAT_)(6,0x51,0x10,4);
              }
              uVar11 = *(undefined2 *)(piVar33 + 0xf);
              *(undefined8 *)(puVar36 + -8) = 0x100535;
              func_0x(lVar44 + 10,piVar33,uVar11,1);
            }
            else {
              *(undefined8 *)(puVar36 + -8) = 0x1003f4;
              func_0x(lVar44 + 10,piVar33);
              *(undefined8 *)(puVar36 + -8) = 0x10040a;
              func_0x(&stack0x000000a8 + lVar15,piVar33,&stack0x00000218 + lVar15);
              lVar18 = *(longlong *)(&stack0x00000218 + lVar15);
              if (((uint)piVar33[0x10] >> 8 & 1) == 0) {
                iVar13 = *piVar33;
                lVar19 = *(longlong *)(lVar44 + 0x10);
                uVar11 = *(undefined2 *)(piVar33 + 0xf);
                *(undefined8 *)(puVar36 + -8) = 0x10042f;
                func_0x(iVar13 + lVar19,lVar18,uVar11);
              }
              else {
                iVar13 = 0;
                if (((piVar33[0x10] & 0x8000U) == 0) || (((&stack0x000000bc)[lVar15] & 8) == 0)) {
                  lVar19 = *(longlong *)(&stack0x000000c0 + lVar15);
                  if ((*(byte *)(*(longlong *)(piVar33 + 0x12) + 0x2a) & 0x10) != 0) {
                    lVar19 = *(longlong *)(&stack0x000000c8 + lVar15);
                  }
                  uVar32 = *(uint *)(*(longlong *)(*(longlong *)(piVar33 + 0x12) + 0x18) + lVar19);
                }
                else {
                  uVar32 = *(uint *)(*(longlong *)(&stack0x000000e0 + lVar15) +
                                    (ulonglong)(uint)piVar33[0xe] * 8);
                }
                uVar37 = (uint)*(ushort *)(piVar33 + 0xf);
                if (uVar32 < uVar37) {
                  iVar13 = uVar37 - uVar32;
                }
                else if (uVar37 < uVar32) {
                  *(undefined8 *)(puVar36 + -8) = 0x1004a2;
                  (*_DAT_)(6,0x5c,0x16,1);
                }
                uVar6 = *(undefined *)(*(longlong *)(piVar33 + 0x12) + 0x24);
                lVar19 = (longlong)*piVar33 + *(longlong *)(lVar44 + 0x10);
                if ((lVar18 != 0) && (uVar32 != 0)) {
                  *(undefined8 *)(puVar36 + -8) = 0x1004ca;
                  func_0x(lVar19,lVar18,uVar32);
                }
                if (iVar13 != 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x1004de;
                  func_0x((ulonglong)uVar32 + lVar19,uVar6,iVar13);
                }
              }
            }
            piVar33 = piVar33 + 0x14;
            plVar34 = (longlong *)(&stack0x00000070 + lVar15);
            *plVar34 = *plVar34 + -1;
          } while (*plVar34 != 0);
        }
      }
      lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
      if (**(short **)(&stack0x00000088 + lVar15) == 0) {
        if (*(int *)(lVar44 + 0xc) == 0) {
          *(undefined2 *)(lVar44 + 10) = 0;
          uVar32 = *(uint *)(lVar44 + 0x18);
          uVar47 = (ulonglong)uVar32;
          *(uint *)(lVar44 + 0x1c) = uVar32;
          pbVar23 = *(byte **)(lVar44 + 0x10);
          bVar27 = *pbVar23;
          if ((bVar27 & 0x10) != 0) {
            uVar32 = uVar32 + 2 + (*(ushort *)(pbVar23 + uVar47) + 7 >> 3);
            uVar47 = (ulonglong)uVar32;
            *(uint *)(lVar44 + 0x1c) = uVar32;
            bVar27 = *pbVar23;
          }
          if ((bVar27 & 0x20) == 0) {
            *(int *)(lVar44 + 0xc) = (int)uVar47;
            *(undefined2 *)(lVar44 + 0x24) = 0;
            *(uint *)(lVar44 + 0x20) = uVar32;
          }
          else {
            puVar41 = (ushort *)(pbVar23 + uVar47);
            uVar9 = *puVar41;
            *(ushort *)(lVar44 + 0x24) = uVar9;
            if (uVar9 == 0) {
              *(undefined8 *)(puVar36 + -8) = 0x103483;
              cVar4 = func_0x(0x1126310);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x103490;
                lVar18 = func_0x();
                if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar36 + -8) = 0x1034b2;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x1034ce;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar36 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + -8) = 0x10352f;
                    (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                  }
                }
              }
              uVar20 = *(undefined8 *)(lVar44 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x10353d;
              func_0x(uVar20,3);
              uVar9 = *(ushort *)(lVar44 + 0x24);
              uVar32 = *(uint *)(lVar44 + 0x1c);
            }
            uVar32 = uVar32 + (uVar9 + 1) * 2;
            *(uint *)(lVar44 + 0x20) = uVar32;
            if (0x1f9e < uVar32) {
              *(undefined8 *)(puVar36 + -8) = 0x10356c;
              cVar4 = func_0x(0x1126310);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x103575;
                lVar18 = func_0x();
                if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar36 + -8) = 0x10358f;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x1035ab;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar36 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + -8) = 0x1035d1;
                    (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                  }
                }
              }
              uVar20 = *(undefined8 *)(lVar44 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x1035df;
              func_0x(uVar20,4);
              uVar9 = *(ushort *)(lVar44 + 0x24);
              uVar32 = *(uint *)(lVar44 + 0x20);
            }
            uVar47 = (ulonglong)uVar9;
            uVar9 = puVar41[uVar47];
            *(uint *)(lVar44 + 0xc) = uVar9 & 0x7fff;
            if ((uVar9 & 0x7fff) < uVar32) {
              *(undefined8 *)(puVar36 + -8) = 0x10360f;
              cVar4 = func_0x(0x1126310);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x103618;
                lVar18 = func_0x();
                if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar36 + -8) = 0x103632;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x10364e;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar36 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + -8) = 0x103674;
                    (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                  }
                }
              }
              uVar20 = *(undefined8 *)(lVar44 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x103682;
              func_0x(uVar20,4);
              uVar47 = (ulonglong)*(ushort *)(lVar44 + 0x24);
            }
            if ((short)puVar41[(ulonglong)((int)uVar47 - 1) + 1] < 0) {
              do {
                lVar18 = *(longlong *)(lVar44 + 0x10);
                lVar19 = (ulonglong)*(uint *)(lVar44 + 0x1c) + lVar18;
                if ((int)uVar47 == 1) {
                  uVar32 = *(uint *)(lVar44 + 0x20);
                  uVar9 = *(ushort *)(lVar19 + uVar47 * 2);
                  uVar37 = uVar32;
LAB_:
                  if ((uVar9 & 0x7fff) < uVar32) goto LAB_;
                }
                else {
                  uVar32 = *(ushort *)(lVar19 + -2 + uVar47 * 2) & 0x7fff;
                  uVar37 = *(uint *)(lVar44 + 0x20);
                  uVar9 = *(ushort *)(lVar19 + uVar47 * 2);
                  if (uVar37 <= uVar32) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar36 + -8) = 0x1036e7;
                  func_0x(lVar18,7);
                  uVar37 = *(uint *)(lVar44 + 0x20);
                }
                if ((uVar32 < uVar37) || (*(uint *)(lVar44 + 0xc) < uVar32)) goto LAB_;
                uVar9 = *(ushort *)((ulonglong)uVar32 + *(longlong *)(lVar44 + 0x10));
                if (uVar9 == 5) {
                  *(ushort *)(lVar44 + 10) = *(ushort *)(lVar44 + 10) | 2;
                  *(short *)(lVar44 + 0x24) = *(short *)(lVar44 + 0x24) + -1;
                  *(short *)(lVar44 + 0x32) = (short)uVar32;
                  lVar18 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(lVar44 + 0x10);
                  uVar9 = *(ushort *)(lVar44 + 0x34) & 0xc7ff;
                  if ((*(ushort *)(lVar18 + 2) >> 0xe & 1) != 0) {
                    uVar9 = *(ushort *)(lVar18 + 2) & 0x3800 | uVar9;
                  }
                  *(ushort *)(lVar44 + 0x34) = uVar9;
                  *(ushort *)(lVar44 + 0x34) = (uVar9 ^ *(ushort *)(lVar18 + 2)) & 0x7ff ^ uVar9;
                  goto LAB_;
                }
                if (uVar9 < 0x400) goto LAB_;
                *(ushort *)(lVar44 + 10) = *(ushort *)(lVar44 + 10) | 1;
                uVar9 = *(short *)(lVar44 + 0x24) - 1;
                *(ushort *)(lVar44 + 0x24) = uVar9;
                if (uVar9 == 0) goto LAB_;
                uVar47 = (ulonglong)uVar9;
              } while ((short)puVar41[(ulonglong)(uVar9 - 1) + 1] < 0);
              pbVar23 = *(byte **)(lVar44 + 0x10);
              uVar47 = (ulonglong)*(uint *)(lVar44 + 0xc);
            }
            else {
LAB_:
              pbVar23 = *(byte **)(lVar44 + 0x10);
              uVar47 = (ulonglong)*(uint *)(lVar44 + 0xc);
            }
          }
          if ((*pbVar23 & 0x40) == 0) {
            *(undefined4 *)(lVar44 + 0x2e) = 0;
          }
          else {
            *(int *)(lVar44 + 0x2e) = (int)uVar47;
            *(int *)(lVar44 + 0xc) = (int)uVar47 + 0xe;
            *(undefined8 *)(puVar36 + -8) = 0x1037da;
            uVar20 = func_0x(lVar44 + 10);
            *(undefined8 *)(puVar36 + -8) = 0x1037e9;
            func_0x(uVar20,&stack0x00000250 + lVar15);
            *(undefined8 *)(puVar36 + -8) = 0x1037f5;
            iVar13 = func_0x(&stack0x00000250 + lVar15);
            *(int *)(lVar44 + 0xc) = *(int *)(lVar44 + 0xc) + iVar13;
            uVar47 = (ulonglong)*(uint *)(lVar44 + 0xc);
          }
          iVar13 = (int)uVar47;
          if ((*(ulonglong *)(lVar44 + 0x26) != 0) &&
             (*(ulonglong *)(lVar44 + 0x26) < uVar47 + *(longlong *)(lVar44 + 0x10))) {
            *(undefined8 *)(puVar36 + -8) = 0x10382b;
            cVar4 = func_0x(0x1126310);
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x103834;
              lVar18 = func_0x();
              if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
                *(undefined8 *)(puVar36 + -8) = 0x10384e;
                cVar4 = func_0x(0x1126310);
                if (cVar4 == '\0') {
                  *(undefined8 *)(puVar36 + -8) = 0x10386a;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar36 + 0x20) = 0;
                  *(undefined8 *)(puVar36 + -8) = 0x103890;
                  (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                }
              }
            }
            uVar20 = *(undefined8 *)(lVar44 + 0x10);
            *(undefined8 *)(puVar36 + -8) = 0x10389e;
            func_0x(uVar20,0x12);
            iVar13 = *(int *)(lVar44 + 0xc);
          }
          if (0x3f3b < iVar13 - 1U) {
            *(undefined8 *)(puVar36 + -8) = 0x1038b7;
            cVar4 = func_0x(0x1126310);
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x1038c0;
              lVar18 = func_0x();
              if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
                *(undefined8 *)(puVar36 + -8) = 0x1038da;
                cVar4 = func_0x(0x1126310);
                if (cVar4 == '\0') {
                  *(undefined8 *)(puVar36 + -8) = 0x1038f6;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar36 + 0x20) = 0;
                  *(undefined8 *)(puVar36 + -8) = 0x10391c;
                  (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                }
              }
            }
            uVar20 = *(undefined8 *)(lVar44 + 0x10);
            *(undefined8 *)(puVar36 + -8) = 0x10392a;
            func_0x(uVar20,5);
          }
        }
LAB_:
        uVar32 = *(uint *)(lVar44 + 0xc);
        if ((uVar32 < 9) &&
           ((bVar27 = **(byte **)(lVar44 + 0x10) & 0xe, bVar27 == 0 || (bVar27 == 0xc)))) {
          uVar32 = 9;
        }
      }
      else {
        *(undefined8 *)(puVar36 + -8) = 0x103956;
        uVar32 = func_0x(lVar44 + 10);
      }
      if (*(uint *)(&stack0x00000078 + lVar15) < uVar32) {
        *(undefined8 *)(puVar36 + -8) = 0x103979;
        (*_DAT_)(6,0x52,0x16,0xba);
      }
    }
    else {
      *(undefined8 *)(&stack0x00000030 + lVar15) = 0;
      *(undefined4 *)(&stack0x0000002c + lVar15) = 0;
      *(undefined8 *)(&stack0x00000046 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000050 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000038 + lVar15) = 0;
      sVar7 = *psVar46;
      *(short *)(&stack0x00000028 + lVar15) = sVar7;
      *(undefined4 *)(&stack0x00000080 + lVar15) = 1;
      uVar12 = 9;
      if (sVar7 == 0) {
        lVar18 = *(longlong *)((longlong)&lStackX_20 + lVar15);
        puVar41 = (ushort *)(lVar18 + 10);
        if (*(int *)(lVar18 + 0xc) == 0) {
          *puVar41 = 0;
          uVar37 = *(uint *)(lVar18 + 0x18);
          uVar47 = (ulonglong)uVar37;
          *(uint *)(lVar18 + 0x1c) = uVar37;
          pbVar23 = *(byte **)(lVar18 + 0x10);
          bVar27 = *pbVar23;
          pbVar16 = pbVar23;
          if ((bVar27 & 0x10) != 0) {
            uVar37 = uVar37 + 2 + (*(ushort *)(pbVar23 + uVar47) + 7 >> 3);
            uVar47 = (ulonglong)uVar37;
            *(uint *)(lVar18 + 0x1c) = uVar37;
            bVar27 = *pbVar23;
            pbVar16 = *(byte **)(lVar18 + 0x10);
          }
          if ((bVar27 & 0x20) == 0) {
            *(int *)(lVar18 + 0xc) = (int)uVar47;
            *(undefined2 *)(lVar18 + 0x24) = 0;
            *(uint *)(lVar18 + 0x20) = uVar37;
            lVar19 = lVar18;
          }
          else {
            puVar40 = (ushort *)(pbVar23 + uVar47);
            uVar9 = *puVar40;
            *(ushort *)(lVar18 + 0x24) = uVar9;
            if (uVar9 == 0) {
              *(undefined8 *)(puVar36 + -8) = 0x103a2b;
              cVar4 = func_0x(0x1126310);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x103a34;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar36 + -8) = 0x103a4e;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x103a6a;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar36 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + -8) = 0x103a8d;
                    (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                  }
                }
              }
              uVar20 = *(undefined8 *)(lVar18 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x103a9b;
              func_0x(uVar20,3);
              uVar9 = *(ushort *)(lVar18 + 0x24);
              uVar37 = *(uint *)(lVar18 + 0x1c);
            }
            uVar37 = uVar37 + (uVar9 + 1) * 2;
            *(uint *)(lVar18 + 0x20) = uVar37;
            if (0x1f9e < uVar37) {
              *(undefined8 *)(puVar36 + -8) = 0x103acb;
              cVar4 = func_0x(0x1126310);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x103ad4;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar36 + -8) = 0x103aee;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x103b0a;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar36 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + -8) = 0x103b2d;
                    (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                  }
                }
              }
              uVar20 = *(undefined8 *)(lVar18 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x103b3b;
              func_0x(uVar20,4);
              uVar9 = *(ushort *)(lVar18 + 0x24);
              uVar37 = *(uint *)(lVar18 + 0x20);
            }
            uVar47 = (ulonglong)uVar9;
            uVar9 = puVar40[uVar47];
            *(uint *)(lVar18 + 0xc) = uVar9 & 0x7fff;
            if ((uVar9 & 0x7fff) < uVar37) {
              *(undefined8 *)(puVar36 + -8) = 0x103b6b;
              cVar4 = func_0x(0x1126310);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x103b74;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar36 + -8) = 0x103b8e;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x103baa;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar36 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + -8) = 0x103bcd;
                    (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                  }
                }
              }
              uVar20 = *(undefined8 *)(lVar18 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x103bdb;
              func_0x(uVar20,4);
              uVar47 = (ulonglong)*(ushort *)(lVar18 + 0x24);
            }
            lVar19 = *(longlong *)((longlong)&lStackX_20 + lVar15);
            if ((short)puVar40[(ulonglong)((int)uVar47 - 1) + 1] < 0) {
              do {
                lVar45 = *(longlong *)(lVar18 + 0x10);
                lVar21 = (ulonglong)*(uint *)(lVar18 + 0x1c) + lVar45;
                if ((int)uVar47 == 1) {
                  uVar37 = *(uint *)(lVar18 + 0x20);
                  uVar9 = *(ushort *)(lVar21 + uVar47 * 2);
                  uVar38 = uVar37;
LAB_:
                  if ((uVar9 & 0x7fff) < uVar37) goto LAB_;
                }
                else {
                  uVar37 = *(ushort *)(lVar21 + -2 + uVar47 * 2) & 0x7fff;
                  uVar38 = *(uint *)(lVar19 + 0x20);
                  uVar9 = *(ushort *)(lVar21 + uVar47 * 2);
                  if (uVar38 <= uVar37) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar36 + -8) = 0x103c48;
                  func_0x(lVar45,7);
                  lVar19 = *(longlong *)((longlong)&lStackX_20 + lVar15);
                  uVar38 = *(uint *)(lVar19 + 0x20);
                  lVar45 = *(longlong *)(lVar19 + 0x10);
                }
                if ((uVar37 < uVar38) || (*(uint *)(lVar18 + 0xc) < uVar37)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar37 + lVar45) == 5) {
                  *puVar41 = *puVar41 | 2;
                  *(short *)(lVar18 + 0x24) = *(short *)(lVar18 + 0x24) + -1;
                  *(short *)(lVar18 + 0x32) = (short)uVar37;
                  lVar45 = (ulonglong)(uVar37 & 0xffff) + *(longlong *)(lVar18 + 0x10);
                  uVar9 = *(ushort *)(lVar18 + 0x34) & 0xc7ff;
                  if ((*(ushort *)(lVar45 + 2) >> 0xe & 1) != 0) {
                    uVar9 = *(ushort *)(lVar45 + 2) & 0x3800 | uVar9;
                  }
                  *(ushort *)(lVar18 + 0x34) = uVar9;
                  *(ushort *)(lVar18 + 0x34) = (uVar9 ^ *(ushort *)(lVar45 + 2)) & 0x7ff ^ uVar9;
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar37 + lVar45) < 0x400) goto LAB_;
                *puVar41 = *puVar41 | 1;
                uVar9 = *(short *)(lVar18 + 0x24) - 1;
                *(ushort *)(lVar18 + 0x24) = uVar9;
                if (uVar9 == 0) goto LAB_;
                uVar47 = (ulonglong)uVar9;
              } while ((short)puVar40[(ulonglong)(uVar9 - 1) + 1] < 0);
              pbVar16 = *(byte **)(lVar18 + 0x10);
              uVar47 = (ulonglong)*(uint *)(lVar18 + 0xc);
            }
            else {
LAB_:
              pbVar16 = *(byte **)(lVar18 + 0x10);
              uVar47 = (ulonglong)*(uint *)(lVar18 + 0xc);
            }
          }
          if ((*pbVar16 & 0x40) == 0) {
            *(undefined4 *)(lVar18 + 0x2e) = 0;
            uVar37 = *(uint *)(lVar19 + 0xc);
          }
          else {
            *(int *)(lVar18 + 0x2e) = (int)uVar47;
            *(int *)(lVar18 + 0xc) = (int)uVar47 + 0xe;
            *(undefined8 *)(puVar36 + -8) = 0x103d42;
            uVar20 = func_0x(puVar41);
            *(undefined8 *)(puVar36 + -8) = 0x103d51;
            func_0x(uVar20,&stack0x00000258 + lVar15);
            *(undefined8 *)(puVar36 + -8) = 0x103d5d;
            iVar13 = func_0x(&stack0x00000258 + lVar15);
            *(int *)(lVar18 + 0xc) = *(int *)(lVar18 + 0xc) + iVar13;
            uVar37 = *(uint *)(lVar18 + 0xc);
            pbVar16 = *(byte **)(lVar18 + 0x10);
          }
          if ((*(byte **)(lVar18 + 0x26) != (byte *)0x0) &&
             (*(byte **)(lVar18 + 0x26) < pbVar16 + uVar37)) {
            *(undefined8 *)(puVar36 + -8) = 0x103d98;
            cVar4 = func_0x(0x1126310);
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x103da1;
              lVar19 = func_0x();
              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                *(undefined8 *)(puVar36 + -8) = 0x103dbb;
                cVar4 = func_0x(0x1126310);
                if (cVar4 == '\0') {
                  *(undefined8 *)(puVar36 + -8) = 0x103dd7;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar36 + 0x20) = 0;
                  *(undefined8 *)(puVar36 + -8) = 0x103dfa;
                  (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                }
              }
            }
            uVar20 = *(undefined8 *)(lVar18 + 0x10);
            *(undefined8 *)(puVar36 + -8) = 0x103e08;
            func_0x(uVar20,0x12);
            uVar37 = *(uint *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0xc);
          }
          if (0x3f3b < uVar37 - 1) {
            *(undefined8 *)(puVar36 + -8) = 0x103e25;
            cVar4 = func_0x(0x1126310);
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x103e2e;
              lVar19 = func_0x();
              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                *(undefined8 *)(puVar36 + -8) = 0x103e48;
                cVar4 = func_0x(0x1126310);
                if (cVar4 == '\0') {
                  *(undefined8 *)(puVar36 + -8) = 0x103e64;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar36 + 0x20) = 0;
                  *(undefined8 *)(puVar36 + -8) = 0x103e87;
                  (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                }
              }
            }
            uVar20 = *(undefined8 *)(lVar18 + 0x10);
            *(undefined8 *)(puVar36 + -8) = 0x103e95;
            func_0x(uVar20,5);
          }
        }
LAB_:
        uVar37 = *(uint *)(lVar18 + 0xc);
        if ((uVar37 < 9) &&
           ((bVar27 = **(byte **)(lVar18 + 0x10) & 0xe, bVar27 == 0 || (bVar27 == 0xc)))) {
          uVar37 = 9;
        }
        *(undefined4 *)(&stack0x00000038 + lVar15) = *(undefined4 *)(lVar18 + 0x18);
        *(ushort *)(&stack0x0000002a + lVar15) = *puVar41;
        *(undefined4 *)(&stack0x0000002c + lVar15) = *(undefined4 *)(lVar18 + 0xc);
        *(undefined2 *)(&stack0x00000044 + lVar15) = *(undefined2 *)(lVar18 + 0x24);
        *(undefined4 *)(&stack0x0000003c + lVar15) = *(undefined4 *)(lVar18 + 0x1c);
        *(undefined4 *)(&stack0x00000040 + lVar15) = *(undefined4 *)(lVar18 + 0x20);
        *(undefined4 *)(&stack0x0000004e + lVar15) = *(undefined4 *)(lVar18 + 0x2e);
        uVar20 = *(undefined8 *)(lVar18 + 0x10);
        *(undefined8 *)(puVar36 + -8) = 0x103ef8;
        func_0x(&stack0x00000918 + lVar15,0x1f9e,uVar20,uVar37);
        *(undefined **)(&stack0x00000030 + lVar15) = &stack0x00000918 + lVar15;
        *(undefined8 *)(puVar36 + -8) = 0x103f0c;
        iVar13 = func_0x(&stack0x0000002a + lVar15);
        if (iVar13 != 0) {
          *(undefined8 *)(puVar36 + -8) = 0x103f20;
          uVar10 = func_0x(&stack0x0000002a + lVar15,&stack0x000002c4 + lVar15);
          *(ushort *)(&stack0x00000052 + lVar15) = uVar10;
          uVar9 = *(ushort *)((ulonglong)uVar10 + *(longlong *)(&stack0x00000030 + lVar15) + 2);
          uVar8 = *(ushort *)(&stack0x00000054 + lVar15);
          if ((uVar9 >> 0xe & 1) == 0) {
            uVar8 = uVar8 & 0xc7ff;
          }
          else {
            uVar8 = uVar8 ^ (uVar9 ^ uVar8) & 0x3800;
          }
          *(ushort *)(&stack0x00000054 + lVar15) = uVar8;
          *(ushort *)(&stack0x00000054 + lVar15) =
               (uVar8 ^ *(ushort *)
                         ((ulonglong)uVar10 + *(longlong *)(&stack0x00000030 + lVar15) + 2)) & 0x7ff
               ^ uVar8;
        }
        lVar18 = *(longlong *)((longlong)&lStackX_20 + lVar15);
      }
      else {
        lVar18 = *(longlong *)((longlong)&lStackX_20 + lVar15);
        if (((*psVar46 == 0) || (*(longlong **)(lVar18 + 0x18) == (longlong *)0x0)) ||
           (**(longlong **)(lVar18 + 0x18) == 0)) {
          *(undefined8 *)(puVar36 + -8) = 0x104036;
          func_0x(&stack0x0000002a + lVar15,&stack0x00000918 + lVar15,0x1f9e,lVar18 + 10);
          lVar19 = lVar44;
          if (*psVar46 != 0) {
            lVar19 = *(longlong *)(lVar18 + 0x18);
          }
          *(longlong *)(&stack0x00000038 + lVar15) = lVar19;
        }
        else {
          *(undefined8 *)(puVar36 + -8) = 0x104015;
          func_0x(&stack0x00000028 + lVar15,&stack0x00000918 + lVar15,0x1f9e,psVar46);
        }
      }
      if (*(short *)(&stack0x00000028 + lVar15) == 0) {
        *(undefined2 *)(&stack0x00000028 + lVar15) = 0;
        *psVar46 = 0;
        puVar41 = (ushort *)(lVar18 + 10);
        *(ushort **)(&stack0x00000070 + lVar15) = puVar41;
        uVar20 = *(undefined8 *)(lVar18 + 0x10);
        *(undefined8 *)(&stack0x00000090 + lVar15) = 0;
        if (((&stack0x000000bc)[lVar15] & 0x10) != 0) {
          lVar44 = *(longlong *)(&stack0x000000a8 + lVar15);
        }
        *(undefined8 *)(&stack0x00000148 + lVar15) = 0;
        *(undefined4 *)(&stack0x00000098 + lVar15) = 0;
        lVar44 = lVar44 + 0x10;
        *(undefined8 *)(puVar36 + -8) = 0x103fc2;
        iVar13 = func_0x(lVar44);
        *(undefined8 *)(puVar36 + -8) = 0x103fcf;
        uVar32 = func_0x(&stack0x0000002a + lVar15);
        if ((uint)-iVar13 < uVar32) {
          *(undefined8 *)(puVar36 + -8) = 0x103fdf;
          uVar32 = func_0x(&stack0x0000002a + lVar15);
        }
        else {
          *(undefined8 *)(puVar36 + -8) = 0x10405b;
          iVar13 = func_0x(lVar44);
          uVar32 = -iVar13;
        }
        uVar47 = (ulonglong)uVar32;
        *puVar1 = uVar32;
        *(undefined8 *)(puVar36 + -8) = 0x10406e;
        iVar13 = func_0x(&stack0x0000002a + lVar15);
        if (iVar13 != 0) {
          *(undefined8 *)(puVar36 + -8) = 0x10408c;
          cVar4 = func_0x
                            (&stack0x000000a8 + lVar15,&stack0x00000148 + lVar15,
                             &stack0x00000098 + lVar15);
          if (cVar4 != '\0') {
            uVar12 = *(undefined4 *)(&stack0x00000098 + lVar15);
            uVar24 = *(undefined8 *)(&stack0x00000148 + lVar15);
            *(undefined8 *)(puVar36 + -8) = 0x1040a6;
            uVar37 = func_0x(uVar24,uVar12,&stack0x0000002a + lVar15);
            if (uVar32 <= uVar37) {
              uVar12 = *(undefined4 *)(&stack0x00000098 + lVar15);
              uVar24 = *(undefined8 *)(&stack0x00000148 + lVar15);
              *(undefined8 *)(puVar36 + -8) = 0x1040c4;
              uVar32 = func_0x(uVar24,uVar12,&stack0x0000002a + lVar15);
              uVar47 = (ulonglong)uVar32;
              *puVar1 = uVar32;
            }
          }
        }
        uVar32 = (uint)uVar47;
        *(undefined8 *)(puVar36 + -8) = 0x1040d2;
        uVar37 = func_0x(lVar44);
        *(undefined8 *)(puVar36 + -8) = 0x1040dc;
        uVar12 = func_0x(lVar44);
        *(undefined8 *)(lVar18 + 0x10) = uVar20;
        *(undefined4 *)(lVar18 + 0x18) = uVar12;
        *(undefined2 *)(lVar18 + 0x24) = 0;
        *puVar41 = 0;
        *(undefined4 *)(lVar18 + 0x2e) = 0;
        *(undefined8 *)(puVar36 + -8) = 0x1040fc;
        cVar4 = func_0x(&stack0x0000002a + lVar15);
        if (cVar4 == '\x06') {
          *(undefined8 *)(puVar36 + -8) = 0x104108;
          puVar22 = (undefined *)func_0x(puVar41);
          *puVar22 = 6;
          uVar38 = 1;
        }
        else {
          *(undefined8 *)(puVar36 + -8) = 0x104116;
          puVar22 = (undefined *)func_0x(puVar41);
          *puVar22 = 0;
          *(undefined *)(*(longlong *)(lVar18 + 0x10) + 1) = 0;
          uVar12 = *(undefined4 *)(lVar18 + 0x18);
          *(undefined8 *)(puVar36 + -8) = 0x10412c;
          func_0x(puVar41,uVar12);
          uVar38 = 4;
        }
        uVar31 = *(uint *)(&stack0x00000038 + lVar15);
        if (*(uint *)(lVar18 + 0x18) <= uVar31) {
          uVar31 = *(uint *)(lVar18 + 0x18);
        }
        lVar44 = *(longlong *)(&stack0x00000030 + lVar15);
        lVar19 = *(longlong *)(lVar18 + 0x10);
        *(undefined8 *)(puVar36 + -8) = 0x104156;
        func_0x
                  (lVar19 + (ulonglong)uVar38,lVar44 + (ulonglong)uVar38,uVar31 - uVar38);
        if (uVar37 == 0) {
          uVar12 = *(undefined4 *)(lVar18 + 0x18);
          *(undefined4 *)(lVar18 + 0x1c) = uVar12;
        }
        else {
          *(undefined8 *)(puVar36 + -8) = 0x104166;
          pbVar23 = (byte *)func_0x(puVar41);
          *pbVar23 = *pbVar23 | 0x10;
          *(uint *)(lVar18 + 0x1c) = (uVar37 + 7 >> 3) + 2 + *(int *)(lVar18 + 0x18);
          *(undefined8 *)(puVar36 + -8) = 0x104181;
          pbVar23 = (byte *)func_0x(&stack0x0000002a + lVar15);
          if ((*pbVar23 & 0x10) == 0) {
            uVar38 = 0;
            *(undefined8 *)(puVar36 + -8) = 0x104220;
            func_0x(&stack0x00000298 + lVar15);
            *(short *)((ulonglong)*(uint *)(lVar18 + 0x18) + *(longlong *)(lVar18 + 0x10)) =
                 (short)uVar37;
          }
          else {
            uVar31 = *(uint *)(&stack0x00000038 + lVar15);
            lVar44 = *(longlong *)(&stack0x00000030 + lVar15);
            uVar9 = *(ushort *)((ulonglong)uVar31 + lVar44);
            uVar38 = (uint)uVar9;
            if (uVar9 == uVar37) {
              uVar37 = *(uint *)(lVar18 + 0x18);
              iVar13 = *(int *)(lVar18 + 0x1c);
              lVar19 = *(longlong *)(lVar18 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x1041b0;
              func_0x
                        ((ulonglong)uVar37 + lVar19,(ulonglong)uVar31 + lVar44,iVar13 - uVar37);
              uVar12 = *(undefined4 *)(lVar18 + 0x1c);
              goto LAB_;
            }
            *(undefined8 *)(puVar36 + -8) = 0x1041c4;
            func_0x(&stack0x00000298 + lVar15);
            *(short *)((ulonglong)*(uint *)(lVar18 + 0x18) + *(longlong *)(lVar18 + 0x10)) =
                 (short)uVar37;
            if (uVar9 != 0) {
              uVar31 = *(uint *)(&stack0x00000038 + lVar15);
              uVar28 = *(int *)(&stack0x0000003c + lVar15) - uVar31;
              uVar30 = *(uint *)(lVar18 + 0x18);
              uVar14 = *(int *)(lVar18 + 0x1c) - uVar30;
              if (uVar28 <= uVar14) {
                uVar14 = uVar28;
              }
              lVar44 = *(longlong *)(&stack0x00000030 + lVar15);
              lVar19 = *(longlong *)(lVar18 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x10420f;
              func_0x
                        (lVar19 + (ulonglong)uVar30 + 2,lVar44 + 2 + (ulonglong)uVar31,uVar14 - 2);
            }
          }
          if (uVar37 < uVar38) {
            uVar38 = uVar37 & 0xffff;
          }
          uVar9 = (ushort)uVar38;
          while (uVar9 = uVar9 + 1, uVar9 <= uVar37) {
            *(undefined8 *)(puVar36 + -8) = 0x10424f;
            func_0x(&stack0x00000298 + lVar15,uVar9);
            *(undefined8 *)(puVar36 + -8) = 0x10425e;
            func_0x(puVar41,&stack0x00000298 + lVar15);
          }
          uVar12 = *(undefined4 *)(lVar18 + 0x1c);
        }
LAB_:
        *(undefined4 *)(lVar18 + 0x20) = uVar12;
        *(undefined4 *)(lVar18 + 0xc) = uVar12;
        if (uVar32 == 0) {
          lVar44 = *(longlong *)(&stack0x00000090 + lVar15);
        }
        else {
          uVar29 = uVar47 * 0x20 + 0xf;
          if (uVar29 <= uVar47 * 0x20) {
            uVar29 = 0xffffffffffffff0;
          }
          uVar29 = uVar29 & 0xfffffffffffffff0;
          *(undefined8 *)(puVar36 + -8) = 0x1042ad;
          func_0x();
          lVar18 = -uVar29;
          puVar22 = puVar36 + lVar18 + 0x50;
          *(undefined **)(&stack0x00000090 + lVar15) = puVar22;
          if (*(int *)(&stack0x0000002c + lVar15) == 0) {
            *(undefined2 *)(&stack0x0000002a + lVar15) = 0;
            *(undefined4 *)(&stack0x0000003c + lVar15) = *(undefined4 *)(&stack0x00000038 + lVar15);
            *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1042d7;
            pbVar23 = (byte *)func_0x(&stack0x0000002a + lVar15);
            if ((*pbVar23 & 0x10) != 0) {
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1042e5;
              pbVar23 = (byte *)func_0x(&stack0x0000002a + lVar15);
              if ((*pbVar23 & 0x10) == 0) {
                uVar37 = 0;
              }
              else {
                uVar37 = (uint)*(ushort *)
                                ((ulonglong)*(uint *)(&stack0x00000038 + lVar15) +
                                *(longlong *)(&stack0x00000030 + lVar15));
              }
              *(uint *)(&stack0x0000003c + lVar15) =
                   (uVar37 + 7 >> 3) + *(int *)(&stack0x0000003c + lVar15) + 2;
            }
            *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104314;
            pbVar23 = (byte *)func_0x(&stack0x0000002a + lVar15);
            if ((*pbVar23 & 0x20) == 0) {
              *(undefined4 *)(&stack0x0000002c + lVar15) =
                   *(undefined4 *)(&stack0x0000003c + lVar15);
              *(undefined2 *)(&stack0x00000044 + lVar15) = 0;
              *(undefined4 *)(&stack0x00000040 + lVar15) =
                   *(undefined4 *)(&stack0x0000003c + lVar15);
            }
            else {
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104326;
              puVar40 = (ushort *)func_0x(&stack0x0000002a + lVar15);
              uVar9 = *puVar40;
              *(ushort *)(&stack0x00000044 + lVar15) = uVar9;
              if (uVar9 == 0) {
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104344;
                cVar4 = func_0x(0x1126310);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10434d;
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10435d;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104379;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar36 + lVar18 + 0x20) = 0;
                      *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10439f;
                      (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1043ad;
                func_0x(uVar20,3);
                uVar9 = *(ushort *)(&stack0x00000044 + lVar15);
              }
              uVar37 = *(int *)(&stack0x0000003c + lVar15) + 2 + (uint)uVar9 * 2;
              *(uint *)(&stack0x00000040 + lVar15) = uVar37;
              if (0x1f9e < uVar37) {
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1043d6;
                cVar4 = func_0x(0x1126310);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1043df;
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1043ef;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10440b;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar36 + lVar18 + 0x20) = 0;
                      *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104431;
                      (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10443f;
                func_0x(uVar20,4);
                uVar9 = *(ushort *)(&stack0x00000044 + lVar15);
              }
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104457;
              uVar9 = func_0x(puVar40 + 1,(ulonglong)uVar9 - 1);
              *(uint *)(&stack0x0000002c + lVar15) = (uint)uVar9;
              if ((uint)uVar9 <= *(uint *)(&stack0x00000040 + lVar15) &&
                  *(uint *)(&stack0x00000040 + lVar15) != (uint)uVar9) {
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10446e;
                cVar4 = func_0x(0x1126310);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104477;
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104487;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1044a3;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar36 + lVar18 + 0x20) = 0;
                      *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1044cd;
                      (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1044db;
                func_0x(uVar20,4);
              }
              uVar9 = *(ushort *)(&stack0x00000044 + lVar15);
              do {
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1044ed;
                iVar13 = func_0x(puVar40 + 1,uVar9 - 1);
                if (iVar13 == 0) break;
                uVar9 = *(ushort *)(&stack0x00000044 + lVar15);
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104502;
                lVar44 = func_0x(&stack0x0000002a + lVar15);
                if (uVar9 == 1) {
                  uVar29 = (ulonglong)*(uint *)(&stack0x00000040 + lVar15);
                }
                else {
                  *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10451f;
                  uVar8 = func_0x(lVar44 + 2,(ulonglong)uVar9 - 2);
                  uVar29 = (ulonglong)uVar8;
                }
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10452f;
                uVar9 = func_0x(lVar44 + 2,(ulonglong)(uint)uVar9 - 1);
                uVar37 = *(uint *)(&stack0x00000040 + lVar15);
                uVar38 = (uint)uVar29;
                if ((uVar38 < uVar37) || (uVar9 < uVar38)) {
                  uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                  *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10454b;
                  func_0x(uVar20,7);
                  uVar37 = *(uint *)(&stack0x00000040 + lVar15);
                }
                if ((uVar38 < uVar37) || (*(uint *)(&stack0x0000002c + lVar15) < uVar38))
                goto LAB_;
                if (*(ushort *)(uVar29 + *(longlong *)(&stack0x00000030 + lVar15)) == 5) {
                  *(ushort *)(&stack0x0000002a + lVar15) =
                       *(ushort *)(&stack0x0000002a + lVar15) | 2;
                  *(short *)(&stack0x00000044 + lVar15) = *(short *)(&stack0x00000044 + lVar15) + -1
                  ;
                  *(short *)(&stack0x00000052 + lVar15) = (short)uVar29;
                  lVar44 = (uVar29 & 0xffff) + *(longlong *)(&stack0x00000030 + lVar15);
                  *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10460f;
                  iVar13 = func_0x(lVar44);
                  if (iVar13 == 0) {
                    *(ushort *)(&stack0x00000054 + lVar15) =
                         *(ushort *)(&stack0x00000054 + lVar15) & 0xc7ff;
                  }
                  else {
                    *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10461b;
                    sVar7 = func_0x(lVar44);
                    *(ushort *)(&stack0x00000054 + lVar15) =
                         *(ushort *)(&stack0x00000054 + lVar15) ^
                         (sVar7 << 0xb ^ *(ushort *)(&stack0x00000054 + lVar15)) & 0x3800;
                  }
                  *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104648;
                  uVar9 = func_0x(lVar44);
                  *(ushort *)(&stack0x00000054 + lVar15) =
                       *(ushort *)(&stack0x00000054 + lVar15) ^
                       (*(ushort *)(&stack0x00000054 + lVar15) ^ uVar9) & 0x7ff;
                  break;
                }
                if (*(ushort *)(uVar29 + *(longlong *)(&stack0x00000030 + lVar15)) < 0x400) break;
                *(ushort *)(&stack0x0000002a + lVar15) = *(ushort *)(&stack0x0000002a + lVar15) | 1;
                uVar9 = *(short *)(&stack0x00000044 + lVar15) - 1;
                *(ushort *)(&stack0x00000044 + lVar15) = uVar9;
              } while (uVar9 != 0);
            }
            *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1045a3;
            iVar13 = func_0x(&stack0x0000002a + lVar15);
            if (iVar13 == 0) {
              *(undefined4 *)(&stack0x0000004e + lVar15) = 0;
              uVar37 = *(uint *)(&stack0x0000002c + lVar15);
            }
            else {
              *(int *)(&stack0x0000004e + lVar15) = *(int *)(&stack0x0000002c + lVar15);
              *(int *)(&stack0x0000002c + lVar15) = *(int *)(&stack0x0000002c + lVar15) + 0xe;
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1045c3;
              uVar20 = func_0x(&stack0x0000002a + lVar15);
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1045d2;
              func_0x(uVar20,&stack0x00000260 + lVar15);
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1045de;
              iVar13 = func_0x(&stack0x00000260 + lVar15);
              uVar37 = *(int *)(&stack0x0000002c + lVar15) + iVar13;
              *(uint *)(&stack0x0000002c + lVar15) = uVar37;
            }
            if ((*(ulonglong *)(&stack0x00000046 + lVar15) != 0) &&
               (*(ulonglong *)(&stack0x00000046 + lVar15) <
                (ulonglong)uVar37 + *(longlong *)(&stack0x00000030 + lVar15))) {
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1046a7;
              cVar4 = func_0x(0x1126310);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1046b0;
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1046c0;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1046dc;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar36 + lVar18 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104702;
                    (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                  }
                }
              }
              uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104710;
              func_0x(uVar20,0x12);
              uVar37 = *(uint *)(&stack0x0000002c + lVar15);
            }
            if (0x3f3b < uVar37 - 1) {
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10472c;
              cVar4 = func_0x(0x1126310);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104735;
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104745;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104761;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar36 + lVar18 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104787;
                    (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                  }
                }
              }
              uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104795;
              func_0x(uVar20,5);
            }
          }
LAB_:
          uVar9 = *(ushort *)(&stack0x00000044 + lVar15);
          uVar37 = (uint)uVar9;
          if ((uVar32 <= uVar9) || (uVar32 = (uint)uVar9, uVar9 != 0)) {
            uVar37 = uVar32;
            *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1047b9;
            lVar44 = func_0x(&stack0x0000002a + lVar15);
            uVar32 = *(uint *)(&stack0x00000040 + lVar15);
            *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1047cb;
            func_0x(&stack0x000002f0 + lVar15);
            uVar38 = 0;
            lVar44 = lVar44 + 2;
            lVar19 = 0;
            do {
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1047ea;
              iVar13 = func_0x(lVar44,uVar38);
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x1047fc;
              uVar9 = func_0x(lVar44,lVar19);
              lVar45 = *(longlong *)(&stack0x00000030 + lVar15);
              *(undefined4 *)(puVar36 + lVar18 + 0x28) = 0;
              *(undefined **)(puVar36 + lVar18 + 0x20) = &stack0x000002f0 + lVar15;
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104828;
              func_0x(puVar22,(ulonglong)uVar32 + lVar45,uVar9 - uVar32,iVar13 != 0)
              ;
              *(undefined8 *)(puVar36 + lVar18 + -8) = 0x104833;
              uVar9 = func_0x(lVar44,lVar19);
              uVar32 = (uint)uVar9;
              uVar38 = uVar38 + 1;
              lVar19 = lVar19 + 1;
              puVar22 = puVar22 + 0x20;
            } while (uVar38 < uVar37);
            puVar41 = *(ushort **)(&stack0x00000070 + lVar15);
            uVar47 = (ulonglong)*puVar1;
          }
          lVar44 = *(longlong *)(&stack0x00000090 + lVar15);
          *(undefined8 *)(puVar36 + lVar18 + -8) = 0x10486b;
          func_0x((ulonglong)uVar37 * 0x20 + lVar44,0,((int)uVar47 - uVar37) * 0x20)
          ;
          puVar36 = puVar36 + lVar18;
        }
        lVar18 = *(longlong *)(&stack0x00000148 + lVar15);
        if (lVar18 != 0) {
          *(int *)(puVar36 + 0x28) = (int)uVar47;
          *(longlong *)(puVar36 + 0x20) = lVar44;
          uVar12 = *(undefined4 *)(&stack0x00000098 + lVar15);
          *(undefined8 *)(puVar36 + -8) = 0x10489c;
          func_0x(lVar18,uVar12,&stack0x0000002a + lVar15,puVar41);
        }
        *(undefined8 *)(puVar36 + -8) = 0x1048a8;
        uVar20 = func_0x(&stack0x000000a8 + lVar15);
        *(undefined8 *)(puVar36 + -8) = 0x1048b0;
        uVar9 = func_0x(uVar20);
        *(uint *)(&stack0x00000060 + lVar15) = (uint)uVar9;
        *(undefined8 *)(&stack0x00000120 + lVar15) = 0;
        *(undefined4 *)(&stack0x000000a0 + lVar15) = 0;
        *(undefined8 *)(puVar36 + -8) = 0x1048d0;
        lVar18 = func_0x(&stack0x000000a8 + lVar15);
        *(longlong *)(&stack0x00000128 + lVar15) = lVar18;
        if (uVar9 != 0) {
          do {
            *(undefined8 *)(puVar36 + -8) = 0x1048f8;
            uVar20 = func_0x(lVar18);
            *(undefined8 *)(&stack0x00000130 + lVar15) = uVar20;
            *(undefined8 *)(puVar36 + -8) = 0x10490a;
            iVar13 = func_0x(lVar18);
            *(undefined8 *)(puVar36 + -8) = 0x10491f;
            func_0x(&stack0x000000a8 + lVar15,lVar18,&stack0x0000007c + lVar15);
            if ((&stack0x0000007c)[lVar15] == '\x03') {
              *(undefined8 *)(puVar36 + -8) = 0x106173;
              iVar39 = func_0x(lVar18);
              if (iVar39 == 0) {
                *(undefined8 *)(puVar36 + -8) = 0x10617f;
                iVar39 = func_0x(lVar18);
                if (iVar39 == 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x106197;
                  (*_DAT_)(6,0x51,0x10,3);
                }
              }
              *(undefined8 *)(puVar36 + -8) = 0x1061a8;
              func_0x(puVar41,uVar20,0,0);
              if (iVar13 < 0) {
                puVar35 = (uint *)((longlong)(-1 - iVar13) * 0x20 + 0xc + lVar44);
                *puVar35 = *puVar35 | 2;
              }
            }
            else {
              *(undefined8 *)(puVar36 + -8) = 0x104931;
              sVar7 = func_0x(uVar20);
              if (sVar7 != 0) {
                *(undefined8 *)(puVar36 + -8) = 0x104941;
                func_0x(puVar41,uVar20);
              }
              *(undefined8 *)(puVar36 + -8) = 0x104957;
              func_0x(&stack0x000000a8 + lVar15,lVar18,&stack0x00000120 + lVar15);
              *(undefined8 *)(puVar36 + -8) = 0x10495f;
              iVar39 = func_0x(lVar18);
              if ((iVar39 == 1) || (iVar39 == 2)) {
                lVar44 = *(longlong *)(&stack0x00000120 + lVar15);
                *(undefined8 *)(puVar36 + -8) = 0x106037;
                iVar13 = func_0x(lVar18);
                if (iVar13 == 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x106043;
                  uVar11 = func_0x();
                  *(undefined8 *)(puVar36 + -8) = 0x10604e;
                  uVar20 = func_0x(lVar18);
                  *(undefined8 *)(puVar36 + -8) = 0x106056;
                  iVar13 = func_0x(uVar20);
                  lVar19 = *(longlong *)(puVar41 + 3);
                  *(undefined8 *)(puVar36 + -8) = 0x106068;
                  func_0x(iVar13 + lVar19,lVar44,uVar11);
                }
                else {
                  iVar39 = 0;
                  *(undefined8 *)(puVar36 + -8) = 0x106074;
                  iVar13 = func_0x(lVar18);
                  if ((iVar13 == 0) || (((&stack0x000000bc)[lVar15] & 8) == 0)) {
                    *(undefined8 *)(puVar36 + -8) = 0x10609f;
                    iVar13 = func_0x(lVar18);
                    if (iVar13 == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x1060d1;
                      uVar9 = func_0x(lVar18);
                      uVar32 = (uint)uVar9;
                    }
                    else {
                      *(undefined8 *)(puVar36 + -8) = 0x1060ab;
                      uVar20 = func_0x();
                      *(undefined8 *)(puVar36 + -8) = 0x1060bd;
                      uVar24 = func_0x(&stack0x000000a8 + lVar15,lVar18);
                      *(undefined8 *)(puVar36 + -8) = 0x1060c8;
                      uVar32 = func_0x(uVar24,uVar20);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar36 + -8) = 0x106089;
                    uVar32 = func_0x(lVar18);
                    uVar32 = *(uint *)(*(longlong *)(&stack0x000000e0 + lVar15) +
                                      (ulonglong)uVar32 * 8);
                  }
                  *(undefined8 *)(puVar36 + -8) = 0x1060dc;
                  uVar9 = func_0x(lVar18);
                  if (uVar32 < uVar9) {
                    *(undefined8 *)(puVar36 + -8) = 0x1060eb;
                    uVar9 = func_0x(lVar18);
                    iVar39 = uVar9 - uVar32;
                  }
                  else {
                    *(undefined8 *)(puVar36 + -8) = 0x1060f7;
                    uVar9 = func_0x(lVar18);
                    if (uVar9 < uVar32) {
                      *(undefined8 *)(puVar36 + -8) = 0x106114;
                      (*_DAT_)(6,0x5c,0x16);
                    }
                  }
                  *(undefined8 *)(puVar36 + -8) = 0x10611c;
                  uVar6 = func_0x(lVar18);
                  *(undefined8 *)(puVar36 + -8) = 0x106128;
                  uVar20 = func_0x(lVar18);
                  *(undefined8 *)(puVar36 + -8) = 0x106130;
                  iVar13 = func_0x(uVar20);
                  lVar19 = *(longlong *)(puVar41 + 3);
                  if ((lVar44 != 0) && (uVar32 != 0)) {
                    *(undefined8 *)(puVar36 + -8) = 0x10614e;
                    func_0x(iVar13 + lVar19,lVar44,uVar32);
                  }
                  if (iVar39 != 0) {
                    *(undefined8 *)(puVar36 + -8) = 0x106166;
                    func_0x((ulonglong)uVar32 + iVar13 + lVar19,uVar6,iVar39);
                  }
                }
              }
              else if ((iVar39 == 3) || (iVar39 == 4)) {
                *(undefined8 *)(puVar36 + -8) = 0x105f54;
                iVar39 = func_0x(lVar18);
                if ((iVar39 == 0) || (**(int **)(&stack0x00000120 + lVar15) != 0)) {
                  *(undefined8 *)(puVar36 + -8) = 0x105f70;
                  iVar39 = func_0x(lVar18);
                  if ((iVar39 == 0) || (((&stack0x000000bc)[lVar15] & 8) == 0)) {
                    *(undefined8 *)(puVar36 + -8) = 0x105f9b;
                    iVar39 = func_0x(lVar18);
                    if (iVar39 == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x105fcd;
                      uVar9 = func_0x(lVar18);
                      uVar32 = (uint)uVar9;
                    }
                    else {
                      *(undefined8 *)(puVar36 + -8) = 0x105fa7;
                      uVar24 = func_0x();
                      *(undefined8 *)(puVar36 + -8) = 0x105fb9;
                      uVar25 = func_0x(&stack0x000000a8 + lVar15,lVar18);
                      *(undefined8 *)(puVar36 + -8) = 0x105fc4;
                      uVar32 = func_0x(uVar25,uVar24);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar36 + -8) = 0x105f85;
                    uVar32 = func_0x(lVar18);
                    uVar32 = *(uint *)(*(longlong *)(&stack0x000000e0 + lVar15) +
                                      (ulonglong)uVar32 * 8);
                  }
                }
                else {
                  uVar32 = 0;
                }
                *(undefined8 *)(puVar36 + -8) = 0x105fd8;
                uVar9 = func_0x(lVar18);
                if (uVar9 < uVar32) {
                  *(undefined8 *)(puVar36 + -8) = 0x105ff5;
                  (*_DAT_)(6,0x52,0x16);
                }
                *(undefined4 *)(puVar36 + 0x28) = 0;
                *(undefined8 *)(puVar36 + 0x20) = uVar20;
                uVar20 = *(undefined8 *)(&stack0x00000120 + lVar15);
                *(undefined8 *)(puVar36 + -8) = 0x106023;
                func_0x((longlong)(-1 - iVar13) * 0x20 + lVar44,uVar20,uVar32);
              }
              else if (iVar39 == 8) {
                pcVar3 = *(char **)(&stack0x00000120 + lVar15);
                *(char **)(&stack0x00000070 + lVar15) = pcVar3;
                *(undefined8 *)(puVar36 + -8) = 0x1049c6;
                iVar13 = func_0x(uVar20);
                if (iVar13 < 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x104f87;
                  iVar13 = func_0x(uVar20);
                  if (iVar13 == 0) {
                    if (*(int *)(puVar41 + 1) == 0) {
                      *puVar41 = 0;
                      *(undefined4 *)(puVar41 + 9) = *(undefined4 *)(puVar41 + 7);
                      *(undefined8 *)(puVar36 + -8) = 0x104fae;
                      pbVar23 = (byte *)func_0x(puVar41);
                      if ((*pbVar23 & 0x10) != 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x104fbb;
                        pbVar23 = (byte *)func_0x(puVar41);
                        if ((*pbVar23 & 0x10) == 0) {
                          uVar32 = 0;
                        }
                        else {
                          uVar32 = (uint)*(ushort *)
                                          ((ulonglong)*(uint *)(puVar41 + 7) +
                                          *(longlong *)(puVar41 + 3));
                        }
                        *(uint *)(puVar41 + 9) = *(int *)(puVar41 + 9) + (uVar32 + 7 >> 3) + 2;
                      }
                      *(undefined8 *)(puVar36 + -8) = 0x104fe3;
                      pbVar23 = (byte *)func_0x(puVar41);
                      if ((*pbVar23 & 0x20) == 0) {
                        *(undefined4 *)(puVar41 + 1) = *(undefined4 *)(puVar41 + 9);
                        puVar41[0xd] = 0;
                        *(undefined4 *)(puVar41 + 0xb) = *(undefined4 *)(puVar41 + 9);
                        lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
                      }
                      else {
                        *(undefined8 *)(puVar36 + -8) = 0x104ff4;
                        puVar40 = (ushort *)func_0x(puVar41);
                        uVar9 = *puVar40;
                        puVar41[0xd] = uVar9;
                        if (uVar9 == 0) {
                          *(undefined8 *)(puVar36 + -8) = 0x10500f;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x105018;
                            cVar4 = func_0x();
                            if (cVar4 != '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x105028;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x105044;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x10506a;
                                (*_DAT_)(1,0xa17098,0xb36d68);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x105078;
                          func_0x(uVar24,3);
                          uVar9 = puVar41[0xd];
                        }
                        uVar32 = *(int *)(puVar41 + 9) + (uVar9 + 1) * 2;
                        *(uint *)(puVar41 + 0xb) = uVar32;
                        if (0x1f9e < uVar32) {
                          *(undefined8 *)(puVar36 + -8) = 0x10509f;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x1050a8;
                            cVar4 = func_0x();
                            if (cVar4 != '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x1050b8;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x1050d4;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x1050fa;
                                (*_DAT_)(1,0xa17098,0xb36d68);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x105108;
                          func_0x(uVar24,4);
                          uVar9 = puVar41[0xd];
                        }
                        puVar40 = puVar40 + 1;
                        *(undefined8 *)(puVar36 + -8) = 0x10511e;
                        uVar9 = func_0x(puVar40,(ulonglong)uVar9 - 1);
                        *(uint *)(puVar41 + 1) = (uint)uVar9;
                        if ((uint)uVar9 <= *(uint *)(puVar41 + 0xb) &&
                            *(uint *)(puVar41 + 0xb) != (uint)uVar9) {
                          *(undefined8 *)(puVar36 + -8) = 0x105135;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x10513e;
                            cVar4 = func_0x();
                            if (cVar4 != '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x10514e;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x10516a;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x105190;
                                (*_DAT_)(1,0xa17098,0xb36d68);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x10519e;
                          func_0x(uVar24,4);
                        }
                        lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
                        uVar9 = *(ushort *)(lVar44 + 0x24);
                        *(undefined8 *)(puVar36 + -8) = 0x1051b1;
                        iVar13 = func_0x(puVar40,uVar9 - 1);
                        while (iVar13 != 0) {
                          uVar9 = puVar41[0xd];
                          *(undefined8 *)(puVar36 + -8) = 0x1051cc;
                          lVar18 = func_0x(puVar41);
                          if (uVar9 == 1) {
                            uVar32 = *(uint *)(puVar41 + 0xb);
                          }
                          else {
                            *(undefined8 *)(puVar36 + -8) = 0x1051e9;
                            uVar8 = func_0x(lVar18 + 2,(ulonglong)uVar9 - 2);
                            uVar32 = (uint)uVar8;
                          }
                          *(undefined8 *)(puVar36 + -8) = 0x1051f9;
                          uVar9 = func_0x(lVar18 + 2,(ulonglong)(uint)uVar9 - 1);
                          if ((uVar32 < *(uint *)(puVar41 + 0xb)) || (uVar9 < uVar32)) {
                            uVar24 = *(undefined8 *)(puVar41 + 3);
                            *(undefined8 *)(puVar36 + -8) = 0x105213;
                            func_0x(uVar24,7);
                            if (uVar32 < *(uint *)(lVar44 + 0x20)) goto LAB_;
                          }
                          if (*(uint *)(puVar41 + 1) < uVar32) goto LAB_;
                          if (*(ushort *)((ulonglong)uVar32 + *(longlong *)(puVar41 + 3)) == 5) {
                            *puVar41 = *puVar41 | 2;
                            puVar41[0xd] = puVar41[0xd] - 1;
                            puVar41[0x14] = (ushort)uVar32;
                            lVar18 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(puVar41 + 3);
                            *(undefined8 *)(puVar36 + -8) = 0x1052d3;
                            iVar13 = func_0x(lVar18);
                            if (iVar13 == 0) {
                              puVar41[0x15] = puVar41[0x15] & 0xc7ff;
                            }
                            else {
                              *(undefined8 *)(puVar36 + -8) = 0x1052df;
                              uVar9 = func_0x(lVar18);
                              puVar41[0x15] = puVar41[0x15] & 0xc7ff;
                              puVar41[0x15] = puVar41[0x15] | (uVar9 & 7) << 0xb;
                            }
                            *(undefined8 *)(puVar36 + -8) = 0x105307;
                            uVar9 = func_0x(lVar18);
                            puVar41[0x15] = puVar41[0x15] & 0xf800;
                            puVar41[0x15] = puVar41[0x15] | uVar9 & 0x7ff;
                            break;
                          }
                          if (*(ushort *)((ulonglong)uVar32 + *(longlong *)(puVar41 + 3)) < 0x400)
                          break;
                          *puVar41 = *puVar41 | 1;
                          uVar9 = puVar41[0xd] - 1;
                          puVar41[0xd] = uVar9;
                          if (uVar9 == 0) break;
                          *(undefined8 *)(puVar36 + -8) = 0x10525f;
                          iVar13 = func_0x(puVar40,uVar9 - 1);
                        }
                      }
                      *(undefined8 *)(puVar36 + -8) = 0x105271;
                      iVar13 = func_0x(puVar41);
                      if (iVar13 == 0) {
                        *(undefined4 *)(puVar41 + 0x12) = 0;
                        uVar32 = *(uint *)(lVar44 + 0xc);
                      }
                      else {
                        *(int *)(puVar41 + 0x12) = *(int *)(puVar41 + 1);
                        *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 0xe;
                        *(undefined8 *)(puVar36 + -8) = 0x10528d;
                        uVar24 = func_0x(puVar41);
                        *(undefined8 *)(puVar36 + -8) = 0x10529c;
                        func_0x(uVar24,&stack0x00000270 + lVar15);
                        *(undefined8 *)(puVar36 + -8) = 0x1052a8;
                        iVar13 = func_0x(&stack0x00000270 + lVar15);
                        *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
                        uVar32 = *(uint *)(puVar41 + 1);
                      }
                      if ((*(ulonglong *)(puVar41 + 0xe) != 0) &&
                         (*(ulonglong *)(puVar41 + 0xe) <
                          (ulonglong)uVar32 + *(longlong *)(puVar41 + 3))) {
                        *(undefined8 *)(puVar36 + -8) = 0x105362;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x10536b;
                          cVar4 = func_0x();
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x10537b;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x105397;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x1053bd;
                              (*_DAT_)(1,0xa17098,0xb36d68);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x1053cb;
                        func_0x(uVar24,0x12);
                        uVar32 = *(uint *)(lVar44 + 0xc);
                      }
                      if (0x3f3b < uVar32 - 1) {
                        *(undefined8 *)(puVar36 + -8) = 0x1053e5;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x1053ee;
                          cVar4 = func_0x();
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x1053fe;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x10541a;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x105440;
                              (*_DAT_)(1,0xa17098,0xb36d68);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x10544e;
                        func_0x(uVar24,5);
                      }
                    }
LAB_:
                    *(undefined8 *)(puVar36 + -8) = 0x105456;
                    iVar13 = func_0x(uVar20);
                    uVar32 = -iVar13;
                    *(undefined8 *)(puVar36 + -8) = 0x105468;
                    func_0x(&stack0x00000758 + lVar15);
                    *(undefined8 *)(puVar36 + -8) = 0x105470;
                    iVar13 = func_0x(puVar41);
                    *(int *)(&stack0x00000088 + lVar15) = iVar13;
                    if (iVar13 != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x105486;
                      func_0x(puVar41,&stack0x00000758 + lVar15);
                    }
                    *(undefined8 *)(puVar36 + -8) = 0x10548e;
                    pbVar23 = (byte *)func_0x(puVar41);
                    if ((*pbVar23 & 0x20) == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x10549b;
                      func_0x(puVar41);
                    }
                    uVar9 = puVar41[0xd];
                    uVar37 = (uint)uVar9;
                    if (uVar9 < uVar32) {
                      iVar13 = uVar32 - uVar9;
                      *(int *)(&stack0x00000130 + lVar15) = iVar13;
                      lVar44 = *(longlong *)(puVar41 + 3);
                      puVar40 = (ushort *)(lVar44 + (ulonglong)*(uint *)(puVar41 + 9));
                      uVar38 = *(uint *)(puVar41 + 9) + 2 + uVar37 * 2;
                      *(uint *)(&stack0x000001d0 + lVar15) = uVar38;
                      uVar31 = iVar13 * 2;
                      uVar30 = 0;
                      if (*puVar40 != 0) {
                        do {
                          *(undefined8 *)(puVar36 + -8) = 0x1054eb;
                          uVar9 = func_0x(puVar40 + 1,uVar30);
                          *(undefined8 *)(puVar36 + -8) = 0x1054fe;
                          func_0x(puVar40 + 1,uVar30 & 0xffff,uVar9 + uVar31);
                          uVar30 = uVar30 + 1;
                        } while (uVar30 < *puVar40);
                        lVar44 = *(longlong *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0x10)
                        ;
                        uVar38 = *(uint *)(&stack0x000001d0 + lVar15);
                      }
                      iVar13 = *(int *)(puVar41 + 1);
                      *(undefined8 *)(puVar36 + -8) = 0x105533;
                      func_0x
                                ((ulonglong)uVar31 + (ulonglong)uVar38 + lVar44,
                                 lVar44 + (ulonglong)uVar38,iVar13 - uVar38);
                      *(uint *)(puVar41 + 1) = *(int *)(puVar41 + 1) + uVar31;
                      uVar31 = *(int *)(puVar41 + 0xb) + uVar31;
                      *(uint *)(puVar41 + 0xb) = uVar31;
                      if (uVar37 != 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x105550;
                        uVar9 = func_0x(puVar40 + 1,uVar37 - 1);
                        uVar31 = (uint)uVar9;
                      }
                      do {
                        *(undefined8 *)(puVar36 + -8) = 0x105572;
                        func_0x(puVar40 + 1,uVar37 & 0xffff,uVar31 & 0xffff);
                        uVar37 = uVar37 + 1;
                      } while (uVar37 < uVar32);
                      *puVar40 = *puVar40 + (short)*(undefined4 *)(&stack0x00000130 + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x10558c;
                      iVar13 = func_0x(puVar41);
                      if (iVar13 != 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x105598;
                        func_0x(puVar41);
                      }
                      puVar41[0xd] = (ushort)uVar32;
                      uVar37 = uVar32 & 0xffff;
                    }
                    if (uVar37 < uVar32) {
                      *(undefined8 *)(puVar36 + -8) = 0x105614;
                      lVar44 = func_0x(puVar41);
                      uVar9 = puVar41[0xd];
                      *(undefined8 *)(puVar36 + -8) = 0x105624;
                      uVar9 = func_0x(lVar44 + 2,(ulonglong)uVar9 - 1);
                      uVar37 = (uint)uVar9;
                      iVar13 = 0;
LAB_:
                      uVar32 = uVar32 - 1;
                      *(undefined8 *)(puVar36 + -8) = 0x105636;
                      puVar40 = (ushort *)func_0x(puVar41);
                      lVar44 = *(longlong *)(puVar41 + 3);
                      uVar12 = *(undefined4 *)(puVar41 + 1);
                      *(undefined8 *)(puVar36 + -8) = 0x10564c;
                      uVar12 = func_0x(uVar12,iVar13 + uVar37);
                      *(undefined8 *)(puVar36 + -8) = 0x105664;
                      func_0x
                                (lVar44 + 1 + (ulonglong)uVar37,
                                 (longlong)iVar13 + (ulonglong)uVar37 + lVar44,uVar12);
                      if ((int)uVar32 < (int)(uint)*puVar40) {
                        do {
                          *(undefined8 *)(puVar36 + -8) = 0x10568c;
                          uVar9 = func_0x(puVar40 + 1,(longlong)(int)uVar32);
                          *(undefined8 *)(puVar36 + -8) = 0x1056a0;
                          func_0x
                                    (puVar40 + 1,uVar32 & 0xffff,(uint)uVar9 + (1 - iVar13));
                          uVar32 = uVar32 + 1;
                        } while ((int)uVar32 < (int)(uint)*puVar40);
                      }
                      *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + (1 - iVar13);
                      *(undefined8 *)(puVar36 + -8) = 0x1056c0;
                      iVar13 = func_0x(puVar41);
                      if (iVar13 != 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x1056cc;
                        func_0x(puVar41);
                      }
                    }
                    else {
                      *(undefined8 *)(puVar36 + -8) = 0x1055b1;
                      lVar44 = func_0x(puVar41);
                      if (uVar32 == 1) {
                        uVar37 = *(uint *)(puVar41 + 0xb);
                      }
                      else {
                        *(undefined8 *)(puVar36 + -8) = 0x1055d0;
                        uVar9 = func_0x(lVar44 + 2,(longlong)(int)(uVar32 - 2));
                        uVar37 = (uint)uVar9;
                      }
                      *(undefined8 *)(puVar36 + -8) = 0x1055e3;
                      uVar9 = func_0x(lVar44 + 2,(longlong)(int)(uVar32 - 1));
                      if ((uVar37 < *(uint *)(puVar41 + 0xb)) || (uVar9 < uVar37)) {
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x105600;
                        func_0x(uVar20,7);
                      }
                      iVar13 = uVar9 - uVar37;
                      if (iVar13 != 1) goto LAB_;
                    }
                    *(undefined *)(*(longlong *)(puVar41 + 3) + (ulonglong)uVar37) =
                         **(undefined **)(&stack0x00000070 + lVar15);
                    if (*(int *)(&stack0x00000088 + lVar15) != 0) {
                      puVar22 = &stack0x00000758;
LAB_:
                      *(undefined8 *)(puVar36 + -8) = 0x1056f2;
                      func_0x(puVar41,(longlong)puVar22 + lVar15);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar36 + -8) = 0x105771;
                    func_0x(&stack0x00000838 + lVar15);
                    uVar32 = 0;
                    *(undefined4 *)(&stack0x0000010c + lVar15) = 0;
                    *(undefined8 *)(puVar36 + -8) = 0x105785;
                    func_0x(&stack0x000001f0 + lVar15);
                    if (*(int *)(puVar41 + 1) == 0) {
                      *puVar41 = 0;
                      *(undefined4 *)(puVar41 + 9) = *(undefined4 *)(puVar41 + 7);
                      *(undefined8 *)(puVar36 + -8) = 0x10579f;
                      pbVar23 = (byte *)func_0x(puVar41);
                      if ((*pbVar23 & 0x10) != 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x1057ac;
                        pbVar23 = (byte *)func_0x(puVar41);
                        if ((*pbVar23 & 0x10) != 0) {
                          uVar32 = (uint)*(ushort *)
                                          ((ulonglong)*(uint *)(puVar41 + 7) +
                                          *(longlong *)(puVar41 + 3));
                        }
                        *(uint *)(puVar41 + 9) = *(int *)(puVar41 + 9) + (uVar32 + 7 >> 3) + 2;
                      }
                      *(undefined8 *)(puVar36 + -8) = 0x1057d4;
                      pbVar23 = (byte *)func_0x(puVar41);
                      if ((*pbVar23 & 0x20) == 0) {
                        *(undefined4 *)(puVar41 + 1) = *(undefined4 *)(puVar41 + 9);
                        puVar41[0xd] = 0;
                        *(undefined4 *)(puVar41 + 0xb) = *(undefined4 *)(puVar41 + 9);
                        lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
                      }
                      else {
                        *(undefined8 *)(puVar36 + -8) = 0x1057e5;
                        puVar40 = (ushort *)func_0x(puVar41);
                        uVar9 = *puVar40;
                        puVar41[0xd] = uVar9;
                        if (uVar9 == 0) {
                          *(undefined8 *)(puVar36 + -8) = 0x105800;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x105809;
                            cVar4 = func_0x();
                            if (cVar4 != '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x105819;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x105835;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x10585b;
                                (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                              }
                            }
                          }
                          uVar20 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x105869;
                          func_0x(uVar20,3);
                          uVar9 = puVar41[0xd];
                        }
                        uVar32 = *(int *)(puVar41 + 9) + (uVar9 + 1) * 2;
                        *(uint *)(puVar41 + 0xb) = uVar32;
                        if (0x1f9e < uVar32) {
                          *(undefined8 *)(puVar36 + -8) = 0x105890;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x105899;
                            cVar4 = func_0x();
                            if (cVar4 != '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x1058a9;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x1058c5;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x1058eb;
                                (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                              }
                            }
                          }
                          uVar20 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x1058f9;
                          func_0x(uVar20,4);
                          uVar9 = puVar41[0xd];
                        }
                        puVar40 = puVar40 + 1;
                        *(undefined8 *)(puVar36 + -8) = 0x10590f;
                        uVar9 = func_0x(puVar40,(ulonglong)uVar9 - 1);
                        *(uint *)(puVar41 + 1) = (uint)uVar9;
                        if ((uint)uVar9 <= *(uint *)(puVar41 + 0xb) &&
                            *(uint *)(puVar41 + 0xb) != (uint)uVar9) {
                          *(undefined8 *)(puVar36 + -8) = 0x105926;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x10592f;
                            cVar4 = func_0x();
                            if (cVar4 != '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x10593f;
                              cVar4 = func_0x(0x1126310);
                              if (cVar4 == '\0') {
                                *(undefined8 *)(puVar36 + -8) = 0x10595b;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar36 + 0x20) = 0;
                                *(undefined8 *)(puVar36 + -8) = 0x105981;
                                (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                              }
                            }
                          }
                          uVar20 = *(undefined8 *)(puVar41 + 3);
                          *(undefined8 *)(puVar36 + -8) = 0x10598f;
                          func_0x(uVar20,4);
                        }
                        lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
                        uVar9 = *(ushort *)(lVar44 + 0x24);
                        *(undefined8 *)(puVar36 + -8) = 0x1059a2;
                        iVar13 = func_0x(puVar40,uVar9 - 1);
                        while (iVar13 != 0) {
                          uVar9 = puVar41[0xd];
                          *(undefined8 *)(puVar36 + -8) = 0x1059bc;
                          lVar18 = func_0x(puVar41);
                          if (uVar9 == 1) {
                            uVar32 = *(uint *)(puVar41 + 0xb);
                          }
                          else {
                            *(undefined8 *)(puVar36 + -8) = 0x1059d9;
                            uVar8 = func_0x(lVar18 + 2,(ulonglong)uVar9 - 2);
                            uVar32 = (uint)uVar8;
                          }
                          *(undefined8 *)(puVar36 + -8) = 0x1059e9;
                          uVar9 = func_0x(lVar18 + 2,(ulonglong)(uint)uVar9 - 1);
                          if ((uVar32 < *(uint *)(puVar41 + 0xb)) || (uVar9 < uVar32)) {
                            uVar20 = *(undefined8 *)(puVar41 + 3);
                            *(undefined8 *)(puVar36 + -8) = 0x105a03;
                            func_0x(uVar20,7);
                            if (uVar32 < *(uint *)(lVar44 + 0x20)) goto LAB_;
                          }
                          if (*(uint *)(puVar41 + 1) < uVar32) goto LAB_;
                          if (*(ushort *)((ulonglong)uVar32 + *(longlong *)(puVar41 + 3)) == 5) {
                            *puVar41 = *puVar41 | 2;
                            puVar41[0xd] = puVar41[0xd] - 1;
                            puVar41[0x14] = (ushort)uVar32;
                            lVar18 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(puVar41 + 3);
                            *(undefined8 *)(puVar36 + -8) = 0x105ac3;
                            iVar13 = func_0x(lVar18);
                            if (iVar13 == 0) {
                              puVar41[0x15] = puVar41[0x15] & 0xc7ff;
                            }
                            else {
                              *(undefined8 *)(puVar36 + -8) = 0x105acf;
                              uVar9 = func_0x(lVar18);
                              puVar41[0x15] = puVar41[0x15] & 0xc7ff;
                              puVar41[0x15] = puVar41[0x15] | (uVar9 & 7) << 0xb;
                            }
                            *(undefined8 *)(puVar36 + -8) = 0x105af7;
                            uVar9 = func_0x(lVar18);
                            puVar41[0x15] = puVar41[0x15] & 0xf800;
                            puVar41[0x15] = puVar41[0x15] | uVar9 & 0x7ff;
                            break;
                          }
                          if (*(ushort *)((ulonglong)uVar32 + *(longlong *)(puVar41 + 3)) < 0x400)
                          break;
                          *puVar41 = *puVar41 | 1;
                          uVar9 = puVar41[0xd] - 1;
                          puVar41[0xd] = uVar9;
                          if (uVar9 == 0) break;
                          *(undefined8 *)(puVar36 + -8) = 0x105a4f;
                          iVar13 = func_0x(puVar40,uVar9 - 1);
                        }
                      }
                      *(undefined8 *)(puVar36 + -8) = 0x105a61;
                      iVar13 = func_0x(puVar41);
                      if (iVar13 == 0) {
                        *(undefined4 *)(puVar41 + 0x12) = 0;
                        uVar32 = *(uint *)(lVar44 + 0xc);
                      }
                      else {
                        *(int *)(puVar41 + 0x12) = *(int *)(puVar41 + 1);
                        *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 0xe;
                        *(undefined8 *)(puVar36 + -8) = 0x105a7d;
                        uVar20 = func_0x(puVar41);
                        *(undefined8 *)(puVar36 + -8) = 0x105a8c;
                        func_0x(uVar20,&stack0x00000278 + lVar15);
                        *(undefined8 *)(puVar36 + -8) = 0x105a98;
                        iVar13 = func_0x(&stack0x00000278 + lVar15);
                        *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
                        uVar32 = *(uint *)(puVar41 + 1);
                      }
                      if ((*(ulonglong *)(puVar41 + 0xe) != 0) &&
                         (*(ulonglong *)(puVar41 + 0xe) <
                          (ulonglong)uVar32 + *(longlong *)(puVar41 + 3))) {
                        *(undefined8 *)(puVar36 + -8) = 0x105b52;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x105b5b;
                          cVar4 = func_0x();
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x105b6b;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x105b87;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x105bad;
                              (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x105bbb;
                        func_0x(uVar20,0x12);
                        uVar32 = *(uint *)(lVar44 + 0xc);
                      }
                      if (0x3f3b < uVar32 - 1) {
                        *(undefined8 *)(puVar36 + -8) = 0x105bd5;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x105bde;
                          cVar4 = func_0x();
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x105bee;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x105c0a;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x105c30;
                              (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                            }
                          }
                        }
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x105c3e;
                        func_0x(uVar20,5);
                      }
                    }
LAB_:
                    *(undefined8 *)(puVar36 + -8) = 0x105c46;
                    func_0x(puVar41);
                    *(undefined8 *)(puVar36 + -8) = 0x105c4e;
                    iVar13 = func_0x(puVar41);
                    *(int *)(&stack0x00000088 + lVar15) = iVar13;
                    if (iVar13 != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x105c67;
                      func_0x(puVar41,&stack0x00000838 + lVar15);
                    }
                    if ((*(byte *)puVar41 & 1) != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x105c80;
                      uVar20 = func_0x(puVar41,0x400,&stack0x0000010c + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x105c8f;
                      func_0x(&stack0x000001f0 + lVar15,uVar20);
                    }
                    *(undefined8 *)(puVar36 + -8) = 0x105c97;
                    pbVar23 = (byte *)func_0x(puVar41);
                    if ((*pbVar23 & 0x20) == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x105ca4;
                      func_0x(puVar41);
                    }
                    *(undefined8 *)(puVar36 + -8) = 0x105cac;
                    lVar44 = func_0x(puVar41);
                    *(undefined8 *)(puVar36 + -8) = 0x105cb7;
                    iVar39 = func_0x(puVar41);
                    if (iVar39 == 0) {
                      uVar9 = puVar41[0xd];
                      uVar37 = (uint)uVar9;
                      lVar18 = *(longlong *)(puVar41 + 3);
                      puVar40 = (ushort *)(lVar18 + (ulonglong)*(uint *)(puVar41 + 9));
                      uVar32 = *(uint *)(puVar41 + 9) + 2 + uVar37 * 2;
                      uVar38 = 0;
                      if (*puVar40 != 0) {
                        do {
                          *(undefined8 *)(puVar36 + -8) = 0x105d7b;
                          uVar8 = func_0x(puVar40 + 1,uVar38);
                          *(undefined8 *)(puVar36 + -8) = 0x105d8f;
                          func_0x(puVar40 + 1,uVar38 & 0xffff,uVar8 + 2);
                          uVar38 = uVar38 + 1;
                        } while (uVar38 < *puVar40);
                        lVar18 = *(longlong *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0x10)
                        ;
                      }
                      lVar18 = (ulonglong)uVar32 + lVar18;
                      iVar13 = *(int *)(puVar41 + 1);
                      *(undefined8 *)(puVar36 + -8) = 0x105db8;
                      func_0x(lVar18 + 2,lVar18,iVar13 - uVar32);
                      *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 2;
                      uVar32 = *(int *)(puVar41 + 0xb) + 2;
                      *(uint *)(puVar41 + 0xb) = uVar32;
                      if (uVar9 != 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x105dd5;
                        uVar9 = func_0x(puVar40 + 1,uVar37 - 1);
                        uVar32 = (uint)uVar9;
                      }
                      uVar38 = uVar37 + 1;
                      if (uVar37 < uVar38) {
                        do {
                          *(undefined8 *)(puVar36 + -8) = 0x105df5;
                          func_0x(puVar40 + 1,uVar37 & 0xffff,uVar32 & 0xffff,0);
                          uVar37 = uVar37 + 1;
                        } while (uVar37 < uVar38);
                      }
                      *puVar40 = *puVar40 + 1;
                      *(undefined8 *)(puVar36 + -8) = 0x105e08;
                      func_0x(puVar41);
                      iVar43 = 0;
                      uVar9 = puVar41[0xd];
                      *(undefined8 *)(puVar36 + -8) = 0x105e1f;
                      uVar11 = func_0x(lVar44 + 2,uVar9);
                      *(undefined8 *)(puVar36 + -8) = 0x105e2e;
                      func_0x(&stack0x00000338 + lVar15);
                      *(undefined4 *)(puVar36 + 0x28) = 0;
                      *(undefined8 *)(puVar36 + 0x20) = *(undefined8 *)(&stack0x00000130 + lVar15);
                      uVar20 = *(undefined8 *)(&stack0x00000070 + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x105e5b;
                      func_0x(&stack0x00000338 + lVar15,uVar20,1,0);
                      *(undefined **)(puVar36 + 0x28) = &stack0x000001d4 + lVar15;
                      *(undefined **)(puVar36 + 0x20) = &stack0x00000338 + lVar15;
                      *(undefined8 *)(puVar36 + -8) = 0x105e8a;
                      func_0x(puVar41 + 0x14,uVar11,0x1f9e,1);
                      iVar39 = *(int *)(&stack0x000001d4 + lVar15);
                      iVar13 = *(int *)(&stack0x00000088 + lVar15);
                    }
                    else {
                      uVar9 = puVar41[0xd];
                      uVar32 = uVar9 + 1;
                      *(undefined8 *)(puVar36 + -8) = 0x105cd3;
                      lVar18 = func_0x(puVar41);
                      if (uVar32 == 1) {
                        uVar32 = *(uint *)(puVar41 + 0xb);
                      }
                      else {
                        *(undefined8 *)(puVar36 + -8) = 0x105cef;
                        uVar8 = func_0x(lVar18 + 2,(ulonglong)uVar32 - 2);
                        uVar32 = (uint)uVar8;
                      }
                      *(undefined8 *)(puVar36 + -8) = 0x105cfe;
                      uVar9 = func_0x(lVar18 + 2,uVar9);
                      if ((uVar32 < *(uint *)(puVar41 + 0xb)) || (uVar9 < uVar32)) {
                        uVar20 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x105d18;
                        func_0x(uVar20,7);
                      }
                      iVar43 = uVar9 - uVar32;
                      uVar20 = *(undefined8 *)(&stack0x00000070 + lVar15);
                      uVar24 = *(undefined8 *)(&stack0x00000130 + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x105d37;
                      iVar39 = func_0x(puVar41 + 0x14,uVar24,uVar20,1);
                    }
                    iVar43 = (iVar39 - iVar43) + *(int *)(puVar41 + 1);
                    *(int *)(puVar41 + 1) = iVar43;
                    if ((*(byte *)puVar41 & 1) != 0) {
                      uVar9 = puVar41[0xd];
                      *(undefined8 *)(puVar36 + -8) = 0x105eb8;
                      func_0x(lVar44 + 2,uVar9 + 1,iVar43,1);
                      iVar43 = (*(int *)(puVar41 + 1) - *(int *)(&stack0x0000010c + lVar15)) + -2;
                    }
                    uVar9 = puVar41[0xd];
                    *(undefined8 *)(puVar36 + -8) = 0x105ed6;
                    func_0x(lVar44 + 2,uVar9,iVar43);
                    if (iVar39 == 0) {
                      uVar9 = puVar41[0xd];
                      *(undefined8 *)(puVar36 + -8) = 0x105eeb;
                      func_0x(puVar41,uVar9 + 1,0);
                      *(undefined8 *)(puVar36 + -8) = 0x105ef3;
                      pbVar23 = (byte *)func_0x(puVar41);
                      if ((*pbVar23 & 0x20) != 0) {
                        puVar41[0xd] = puVar41[0xd] + 1;
                        *puVar41 = *puVar41 & 0xfffd;
                        *(undefined8 *)(puVar36 + -8) = 0x105f0c;
                        func_0x(puVar41 + 0x14);
                      }
                    }
                    else {
                      *puVar41 = *puVar41 | 2;
                      *(undefined8 *)(puVar36 + -8) = 0x105f17;
                      func_0x(puVar41);
                    }
                    if ((*(byte *)puVar41 & 1) != 0) {
                      uVar12 = *(undefined4 *)(&stack0x0000010c + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x105f37;
                      func_0x(puVar41,0x400,uVar12);
                    }
                    if (iVar13 != 0) {
                      puVar22 = &stack0x00000838;
                      goto LAB_;
                    }
                  }
                  lVar18 = *(longlong *)(&stack0x00000128 + lVar15);
                }
                else {
                  *(undefined8 *)(puVar36 + -8) = 0x1049d9;
                  iVar13 = func_0x();
                  if (iVar13 != 0) {
                    cVar4 = *pcVar3;
                    *(undefined8 *)(puVar36 + -8) = 0x1049ec;
                    iVar13 = func_0x(uVar20);
                    uVar32 = iVar13 + 1;
                    if (*(uint *)(puVar41 + 7) < uVar32) {
                      iVar39 = *(int *)(puVar41 + 7);
                      *(undefined8 *)(puVar36 + -8) = 0x104a0e;
                      func_0x(puVar41,0,uVar32 - iVar39);
                      *(undefined8 *)(puVar36 + -8) = 0x104a16;
                      iVar39 = func_0x(puVar41);
                      if (iVar39 != 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x104a27;
                        func_0x(puVar41,uVar32);
                      }
                      *(uint *)(puVar41 + 7) = uVar32;
                    }
                    pbVar23 = (byte *)((longlong)iVar13 + *(longlong *)(puVar41 + 3));
                    bVar27 = *pbVar23;
                    *(undefined8 *)(puVar36 + -8) = 0x104a3c;
                    bVar5 = func_0x(uVar20);
                    if (cVar4 == '\0') {
                      *pbVar23 = bVar27 & ~(byte)(1 << (bVar5 & 0x1f));
                    }
                    else {
                      *pbVar23 = bVar27 | (byte)(1 << (bVar5 & 0x1f));
                    }
                    goto LAB_;
                  }
                  if (*(int *)(puVar41 + 1) == 0) {
                    *puVar41 = 0;
                    *(undefined4 *)(puVar41 + 9) = *(undefined4 *)(puVar41 + 7);
                    *(undefined8 *)(puVar36 + -8) = 0x104a75;
                    pbVar23 = (byte *)func_0x(puVar41);
                    if ((*pbVar23 & 0x10) != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x104a82;
                      pbVar23 = (byte *)func_0x(puVar41);
                      if ((*pbVar23 & 0x10) == 0) {
                        uVar32 = 0;
                      }
                      else {
                        uVar32 = (uint)*(ushort *)
                                        ((ulonglong)*(uint *)(puVar41 + 7) +
                                        *(longlong *)(puVar41 + 3));
                      }
                      *(uint *)(puVar41 + 9) = *(int *)(puVar41 + 9) + (uVar32 + 7 >> 3) + 2;
                    }
                    *(undefined8 *)(puVar36 + -8) = 0x104aaa;
                    pbVar23 = (byte *)func_0x(puVar41);
                    if ((*pbVar23 & 0x20) == 0) {
                      *(undefined4 *)(puVar41 + 1) = *(undefined4 *)(puVar41 + 9);
                      puVar41[0xd] = 0;
                      *(undefined4 *)(puVar41 + 0xb) = *(undefined4 *)(puVar41 + 9);
LAB_:
                      lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
                    }
                    else {
                      *(undefined8 *)(puVar36 + -8) = 0x104abb;
                      puVar40 = (ushort *)func_0x(puVar41);
                      uVar9 = *puVar40;
                      puVar41[0xd] = uVar9;
                      if (uVar9 == 0) {
                        *(undefined8 *)(puVar36 + -8) = 0x104ad6;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x104adf;
                          cVar4 = func_0x();
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x104aef;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x104b0b;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x104b31;
                              (*_DAT_)(1,0xa17098,0xb36d68);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x104b3f;
                        func_0x(uVar24,3);
                        uVar9 = puVar41[0xd];
                      }
                      uVar32 = *(int *)(puVar41 + 9) + (uVar9 + 1) * 2;
                      *(uint *)(puVar41 + 0xb) = uVar32;
                      if (0x1f9e < uVar32) {
                        *(undefined8 *)(puVar36 + -8) = 0x104b66;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x104b6f;
                          cVar4 = func_0x();
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x104b7f;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x104b9b;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x104bc1;
                              (*_DAT_)(1,0xa17098,0xb36d68);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x104bcf;
                        func_0x(uVar24,4);
                        uVar9 = puVar41[0xd];
                      }
                      puVar40 = puVar40 + 1;
                      *(undefined8 *)(puVar36 + -8) = 0x104be5;
                      uVar9 = func_0x(puVar40,(ulonglong)uVar9 - 1);
                      *(uint *)(puVar41 + 1) = (uint)uVar9;
                      if ((uint)uVar9 <= *(uint *)(puVar41 + 0xb) &&
                          *(uint *)(puVar41 + 0xb) != (uint)uVar9) {
                        *(undefined8 *)(puVar36 + -8) = 0x104bfc;
                        cVar4 = func_0x(0x1126310);
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x104c05;
                          cVar4 = func_0x();
                          if (cVar4 != '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x104c15;
                            cVar4 = func_0x(0x1126310);
                            if (cVar4 == '\0') {
                              *(undefined8 *)(puVar36 + -8) = 0x104c31;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar36 + 0x20) = 0;
                              *(undefined8 *)(puVar36 + -8) = 0x104c57;
                              (*_DAT_)(1,0xa17098,0xb36d68);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(puVar41 + 3);
                        *(undefined8 *)(puVar36 + -8) = 0x104c65;
                        func_0x(uVar24,4);
                      }
                      lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
                      uVar9 = *(ushort *)(lVar44 + 0x24);
                      *(undefined8 *)(puVar36 + -8) = 0x104c77;
                      iVar13 = func_0x(puVar40,uVar9 - 1);
                      if (iVar13 != 0) {
                        do {
                          uVar9 = puVar41[0xd];
                          *(undefined8 *)(puVar36 + -8) = 0x104c8c;
                          lVar44 = func_0x(puVar41);
                          if (uVar9 == 1) {
                            uVar32 = *(uint *)(puVar41 + 0xb);
                          }
                          else {
                            *(undefined8 *)(puVar36 + -8) = 0x104ca9;
                            uVar8 = func_0x(lVar44 + 2,(ulonglong)uVar9 - 2);
                            uVar32 = (uint)uVar8;
                          }
                          *(undefined8 *)(puVar36 + -8) = 0x104cb9;
                          uVar9 = func_0x(lVar44 + 2,(ulonglong)(uint)uVar9 - 1);
                          if ((uVar32 < *(uint *)(puVar41 + 0xb)) || (uVar9 < uVar32)) {
                            uVar24 = *(undefined8 *)(puVar41 + 3);
                            *(undefined8 *)(puVar36 + -8) = 0x104cd3;
                            func_0x(uVar24,7);
                            if (uVar32 < *(uint *)(*(longlong *)((longlong)&lStackX_20 + lVar15) +
                                                  0x20)) goto LAB_;
                          }
                          if (*(uint *)(puVar41 + 1) < uVar32) goto LAB_;
                          if (*(ushort *)((ulonglong)uVar32 + *(longlong *)(puVar41 + 3)) == 5) {
                            *puVar41 = *puVar41 | 2;
                            puVar41[0xd] = puVar41[0xd] - 1;
                            puVar41[0x14] = (ushort)uVar32;
                            lVar44 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(puVar41 + 3);
                            *(undefined8 *)(puVar36 + -8) = 0x104d9e;
                            iVar13 = func_0x(lVar44);
                            if (iVar13 == 0) {
                              puVar41[0x15] = puVar41[0x15] & 0xc7ff;
                            }
                            else {
                              *(undefined8 *)(puVar36 + -8) = 0x104daa;
                              uVar9 = func_0x(lVar44);
                              puVar41[0x15] = puVar41[0x15] & 0xc7ff;
                              puVar41[0x15] = puVar41[0x15] | (uVar9 & 7) << 0xb;
                            }
                            *(undefined8 *)(puVar36 + -8) = 0x104dd2;
                            uVar9 = func_0x(lVar44);
                            puVar41[0x15] = puVar41[0x15] & 0xf800;
                            puVar41[0x15] = puVar41[0x15] | uVar9 & 0x7ff;
                            break;
                          }
                          if (*(ushort *)((ulonglong)uVar32 + *(longlong *)(puVar41 + 3)) < 0x400)
                          break;
                          *puVar41 = *puVar41 | 1;
                          uVar9 = puVar41[0xd] - 1;
                          puVar41[0xd] = uVar9;
                          if (uVar9 == 0) break;
                          *(undefined8 *)(puVar36 + -8) = 0x104d26;
                          iVar13 = func_0x(puVar40,uVar9 - 1);
                        } while (iVar13 != 0);
                        goto LAB_;
                      }
                    }
                    *(undefined8 *)(puVar36 + -8) = 0x104d3c;
                    iVar13 = func_0x(puVar41);
                    if (iVar13 == 0) {
                      *(undefined4 *)(puVar41 + 0x12) = 0;
                      uVar32 = *(uint *)(lVar44 + 0xc);
                    }
                    else {
                      *(int *)(puVar41 + 0x12) = *(int *)(puVar41 + 1);
                      *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 0xe;
                      *(undefined8 *)(puVar36 + -8) = 0x104d58;
                      uVar24 = func_0x(puVar41);
                      *(undefined8 *)(puVar36 + -8) = 0x104d67;
                      func_0x(uVar24,&stack0x00000268 + lVar15);
                      *(undefined8 *)(puVar36 + -8) = 0x104d73;
                      iVar13 = func_0x(&stack0x00000268 + lVar15);
                      *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
                      uVar32 = *(uint *)(puVar41 + 1);
                    }
                    if ((*(ulonglong *)(puVar41 + 0xe) != 0) &&
                       (*(ulonglong *)(puVar41 + 0xe) <
                        (ulonglong)uVar32 + *(longlong *)(puVar41 + 3))) {
                      *(undefined8 *)(puVar36 + -8) = 0x104e28;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x104e31;
                        cVar4 = func_0x();
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x104e41;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x104e5d;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x104e83;
                            (*_DAT_)(1,0xa17098,0xb36d68);
                          }
                        }
                      }
                      uVar24 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x104e91;
                      func_0x(uVar24,0x12);
                      uVar32 = *(uint *)(lVar44 + 0xc);
                    }
                    if (0x3f3b < uVar32 - 1) {
                      *(undefined8 *)(puVar36 + -8) = 0x104eaa;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x104eb3;
                        cVar4 = func_0x();
                        if (cVar4 != '\0') {
                          *(undefined8 *)(puVar36 + -8) = 0x104ec3;
                          cVar4 = func_0x(0x1126310);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar36 + -8) = 0x104edf;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar36 + 0x20) = 0;
                            *(undefined8 *)(puVar36 + -8) = 0x104f05;
                            (*_DAT_)(1,0xa17098,0xb36d68);
                          }
                        }
                      }
                      uVar24 = *(undefined8 *)(puVar41 + 3);
                      *(undefined8 *)(puVar36 + -8) = 0x104f13;
                      func_0x(uVar24,5);
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar36 + -8) = 0x104f1b;
                  iVar13 = func_0x(uVar20);
                  uVar32 = iVar13 + 1;
                  if (*(uint *)(puVar41 + 7) < uVar32) {
                    iVar13 = *(int *)(puVar41 + 7);
                    *(undefined8 *)(puVar36 + -8) = 0x104f3a;
                    func_0x(puVar41,0,uVar32 - iVar13);
                    *(undefined8 *)(puVar36 + -8) = 0x104f42;
                    iVar13 = func_0x(puVar41);
                    if (iVar13 != 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x104f53;
                      func_0x(puVar41,uVar32);
                    }
                    *(uint *)(puVar41 + 7) = uVar32;
                  }
                  *(undefined8 *)(puVar36 + -8) = 0x104f5e;
                  iVar13 = func_0x(uVar20);
                  if (*(undefined **)(&stack0x00000070 + lVar15) != (undefined *)0x0) {
                    *(undefined *)((longlong)iVar13 + *(longlong *)(puVar41 + 3)) =
                         **(undefined **)(&stack0x00000070 + lVar15);
                  }
                }
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0x793578;
                *(undefined8 *)(puVar36 + -8) = 0x1049ae;
                (*_DAT_)(1,0xb983d0,0xbc4d10);
              }
            }
LAB_:
            lVar18 = lVar18 + 0x50;
            *(longlong *)(&stack0x00000128 + lVar15) = lVar18;
            iVar13 = *(int *)(&stack0x000000a0 + lVar15);
            *(uint *)(&stack0x000000a0 + lVar15) = iVar13 + 1U;
            lVar44 = *(longlong *)(&stack0x00000090 + lVar15);
          } while (iVar13 + 1U < *(uint *)(&stack0x00000060 + lVar15));
          uVar47 = (ulonglong)*puVar1;
        }
        puVar40 = (ushort *)0x0;
        if ((int)uVar47 != 0) {
          lVar44 = *(longlong *)(&stack0x00000090 + lVar15);
LAB_:
          uVar32 = (uint)uVar47;
          uVar37 = uVar32 - 1;
          if (*(int *)((ulonglong)uVar37 * 0x20 + 8 + lVar44) == 0) goto code_r0x0010575b;
          puVar41[0xd] = (ushort)uVar47;
          iVar13 = *(int *)(puVar41 + 9) + 2 + uVar32 * 2;
          *(int *)(puVar41 + 0xb) = iVar13;
          *(int *)(puVar41 + 1) = iVar13;
          *(undefined8 *)(puVar36 + -8) = 0x1061e4;
          pbVar23 = (byte *)func_0x(puVar41);
          *pbVar23 = *pbVar23 | 0x20;
          uVar37 = *(uint *)(puVar41 + 1);
          uVar38 = *(uint *)(&stack0x00000078 + lVar15);
          if (uVar37 <= uVar38) {
            *(undefined8 *)(puVar36 + -8) = 0x1061f9;
            puVar40 = (ushort *)func_0x(puVar41);
            *puVar40 = (ushort)uVar47;
            uVar37 = *(uint *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0xc);
            uVar38 = *(uint *)(&stack0x00000078 + lVar15);
          }
          uVar31 = 0;
          if (uVar32 != 0) {
            puVar35 = (uint *)(lVar44 + 0xc);
            do {
              uVar30 = *(uint *)(puVar41 + 1);
              lVar44 = *(longlong *)(puVar41 + 3);
              uVar14 = puVar35[-1];
              uVar37 = uVar14 + uVar30;
              *(uint *)(puVar41 + 1) = uVar37;
              if (uVar37 <= uVar38) {
                uVar38 = *puVar35;
                *(undefined8 *)(puVar36 + -8) = 0x10624d;
                func_0x(puVar40 + 1,uVar31,uVar37,uVar38 & 1);
                uVar20 = *(undefined8 *)(puVar35 + -3);
                *(undefined8 *)(puVar36 + -8) = 0x10625f;
                func_0x((ulonglong)uVar30 + lVar44,uVar14,uVar20,uVar14);
                uVar38 = *(uint *)(&stack0x00000078 + lVar15);
              }
              uVar31 = uVar31 + 1;
              puVar35 = puVar35 + 8;
            } while (uVar31 < uVar32);
            uVar37 = *(uint *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0xc);
          }
          if (uVar38 < uVar37) {
            *(undefined4 *)(&stack0x00000080 + lVar15) = 0;
          }
        }
      }
      else {
        *(undefined8 *)(&stack0x00000070 + lVar15) = *(undefined8 *)(lVar18 + 0x10);
        *(undefined8 *)(&stack0x00000060 + lVar15) = 0;
        *(undefined8 *)(puVar36 + -8) = 0x1062a0;
        lVar18 = func_0x(&stack0x000000a8 + lVar15);
        *(undefined2 *)(&stack0x00000158 + lVar15) = 0xffff;
        *(undefined8 *)(&stack0x00000160 + lVar15) = 0;
        *(undefined4 *)(&stack0x0000015c + lVar15) = 0;
        *(undefined8 *)(&stack0x00000176 + lVar15) = 0;
        *(undefined8 *)(&stack0x00000180 + lVar15) = 0;
        *(undefined8 *)(puVar36 + -8) = 0x1062d9;
        func_0x(&stack0x0000015a + lVar15,0);
        *(undefined8 *)(&stack0x00000150 + lVar15) = 0;
        *(undefined4 *)(&stack0x0000009c + lVar15) = 0;
        if (*(short *)(&stack0x00000028 + lVar15) == 0) {
LAB_:
          psVar46 = (short *)(&stack0x00000028 + lVar15);
          puVar41 = (ushort *)(&stack0x0000002a + lVar15);
        }
        else {
          *(undefined8 *)(puVar36 + -8) = 0x1062fb;
          lVar19 = func_0x(&stack0x0000002a + lVar15);
          if (lVar19 == 0) goto LAB_;
          lVar19 = lVar44;
          if (*(short *)(&stack0x00000028 + lVar15) != 0) {
            *(undefined8 *)(puVar36 + -8) = 0x106319;
            lVar19 = func_0x(&stack0x0000002a + lVar15);
          }
          *(undefined8 *)(puVar36 + -8) = 0x106321;
          iVar13 = func_0x(lVar19);
          if (iVar13 == 0) goto LAB_;
          *(short *)(&stack0x00000158 + lVar15) = *(short *)(&stack0x00000028 + lVar15);
          if (*(short *)(&stack0x00000028 + lVar15) == 0) {
            if (*(int *)(&stack0x0000002c + lVar15) == 0) {
              *(undefined2 *)(&stack0x0000002a + lVar15) = 0;
              *(undefined4 *)(&stack0x0000003c + lVar15) =
                   *(undefined4 *)(&stack0x00000038 + lVar15);
              *(undefined8 *)(puVar36 + -8) = 0x10635b;
              pbVar23 = (byte *)func_0x(&stack0x0000002a + lVar15);
              if ((*pbVar23 & 0x10) != 0) {
                *(undefined8 *)(puVar36 + -8) = 0x106369;
                pbVar23 = (byte *)func_0x(&stack0x0000002a + lVar15);
                if ((*pbVar23 & 0x10) != 0) {
                  uVar32 = (uint)*(ushort *)
                                  ((ulonglong)*(uint *)(&stack0x00000038 + lVar15) +
                                  *(longlong *)(&stack0x00000030 + lVar15));
                }
                *(uint *)(&stack0x0000003c + lVar15) =
                     (uVar32 + 7 >> 3) + *(int *)(&stack0x0000003c + lVar15) + 2;
              }
              *(undefined8 *)(puVar36 + -8) = 0x106398;
              pbVar23 = (byte *)func_0x(&stack0x0000002a + lVar15);
              if ((*pbVar23 & 0x20) == 0) {
                *(undefined4 *)(&stack0x0000002c + lVar15) =
                     *(undefined4 *)(&stack0x0000003c + lVar15);
                *(undefined2 *)(&stack0x00000044 + lVar15) = 0;
                *(undefined4 *)(&stack0x00000040 + lVar15) =
                     *(undefined4 *)(&stack0x0000003c + lVar15);
              }
              else {
                *(undefined8 *)(puVar36 + -8) = 0x1063aa;
                puVar41 = (ushort *)func_0x(&stack0x0000002a + lVar15);
                uVar9 = *puVar41;
                *(ushort *)(&stack0x00000044 + lVar15) = uVar9;
                if (uVar9 == 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x1063c8;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x1063d1;
                    cVar4 = func_0x();
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + -8) = 0x1063e1;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x1063fd;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar36 + 0x20) = 0;
                        *(undefined8 *)(puVar36 + -8) = 0x106420;
                        (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x10642e;
                  func_0x(uVar20,3);
                  uVar9 = *(ushort *)(&stack0x00000044 + lVar15);
                }
                uVar32 = *(int *)(&stack0x0000003c + lVar15) + 2 + (uint)uVar9 * 2;
                *(uint *)(&stack0x00000040 + lVar15) = uVar32;
                if (0x1f9e < uVar32) {
                  *(undefined8 *)(puVar36 + -8) = 0x106453;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x10645c;
                    cVar4 = func_0x();
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + -8) = 0x10646c;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x106488;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar36 + 0x20) = 0;
                        *(undefined8 *)(puVar36 + -8) = 0x1064ab;
                        (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x1064b9;
                  func_0x(uVar20,4);
                  uVar9 = *(ushort *)(&stack0x00000044 + lVar15);
                }
                *(undefined8 *)(puVar36 + -8) = 0x1064d1;
                uVar9 = func_0x(puVar41 + 1,(ulonglong)uVar9 - 1);
                *(uint *)(&stack0x0000002c + lVar15) = (uint)uVar9;
                if ((uint)uVar9 <= *(uint *)(&stack0x00000040 + lVar15) &&
                    *(uint *)(&stack0x00000040 + lVar15) != (uint)uVar9) {
                  *(undefined8 *)(puVar36 + -8) = 0x1064e8;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x1064f1;
                    cVar4 = func_0x();
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + -8) = 0x106501;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar36 + -8) = 0x10651d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar36 + 0x20) = 0;
                        *(undefined8 *)(puVar36 + -8) = 0x106544;
                        (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x106552;
                  func_0x(uVar20,4);
                }
                uVar9 = *(ushort *)(&stack0x00000044 + lVar15);
                do {
                  *(undefined8 *)(puVar36 + -8) = 0x10656d;
                  iVar13 = func_0x(puVar41 + 1,uVar9 - 1);
                  if (iVar13 == 0) break;
                  uVar9 = *(ushort *)(&stack0x00000044 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x106582;
                  lVar44 = func_0x(&stack0x0000002a + lVar15);
                  if (uVar9 == 1) {
                    uVar32 = *(uint *)(&stack0x00000040 + lVar15);
                  }
                  else {
                    *(undefined8 *)(puVar36 + -8) = 0x10659e;
                    uVar8 = func_0x(lVar44 + 2,(ulonglong)uVar9 - 2);
                    uVar32 = (uint)uVar8;
                  }
                  *(undefined8 *)(puVar36 + -8) = 0x1065ae;
                  uVar9 = func_0x(lVar44 + 2,(ulonglong)(uint)uVar9 - 1);
                  if ((uVar32 < *(uint *)(&stack0x00000040 + lVar15)) || (uVar9 < uVar32)) {
                    uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                    *(undefined8 *)(puVar36 + -8) = 0x1065c8;
                    func_0x(uVar20,7);
                  }
                  if ((uVar32 < *(uint *)(&stack0x00000040 + lVar15)) ||
                     (*(uint *)(&stack0x0000002c + lVar15) < uVar32)) goto LAB_;
                  uVar9 = *(ushort *)(*(longlong *)(&stack0x00000030 + lVar15) + (ulonglong)uVar32);
                  if (uVar9 == 5) {
                    *(ushort *)(&stack0x0000002a + lVar15) =
                         *(ushort *)(&stack0x0000002a + lVar15) | 2;
                    *(short *)(&stack0x00000044 + lVar15) =
                         *(short *)(&stack0x00000044 + lVar15) + -1;
                    *(short *)(&stack0x00000052 + lVar15) = (short)uVar32;
                    lVar44 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(&stack0x00000030 + lVar15)
                    ;
                    *(undefined8 *)(puVar36 + -8) = 0x106673;
                    iVar13 = func_0x(lVar44);
                    if (iVar13 == 0) {
                      *(ushort *)(&stack0x00000054 + lVar15) =
                           *(ushort *)(&stack0x00000054 + lVar15) & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)(puVar36 + -8) = 0x10667f;
                      sVar7 = func_0x(lVar44);
                      *(ushort *)(&stack0x00000054 + lVar15) =
                           *(ushort *)(&stack0x00000054 + lVar15) ^
                           (sVar7 << 0xb ^ *(ushort *)(&stack0x00000054 + lVar15)) & 0x3800;
                    }
                    *(undefined8 *)(puVar36 + -8) = 0x1066ac;
                    uVar9 = func_0x(lVar44);
                    *(ushort *)(&stack0x00000054 + lVar15) =
                         *(ushort *)(&stack0x00000054 + lVar15) ^
                         (uVar9 ^ *(ushort *)(&stack0x00000054 + lVar15)) & 0x7ff;
                    break;
                  }
                  if (uVar9 < 0x400) break;
                  *(ushort *)(&stack0x0000002a + lVar15) =
                       *(ushort *)(&stack0x0000002a + lVar15) | 1;
                  uVar9 = *(short *)(&stack0x00000044 + lVar15) - 1;
                  *(ushort *)(&stack0x00000044 + lVar15) = uVar9;
                } while (uVar9 != 0);
              }
              *(undefined8 *)(puVar36 + -8) = 0x106617;
              iVar13 = func_0x(&stack0x0000002a + lVar15);
              if (iVar13 == 0) {
                *(undefined4 *)(&stack0x0000004e + lVar15) = 0;
              }
              else {
                *(int *)(&stack0x0000004e + lVar15) = *(int *)(&stack0x0000002c + lVar15);
                *(int *)(&stack0x0000002c + lVar15) = *(int *)(&stack0x0000002c + lVar15) + 0xe;
                *(undefined8 *)(puVar36 + -8) = 0x106634;
                uVar20 = func_0x(&stack0x0000002a + lVar15);
                *(undefined8 *)(puVar36 + -8) = 0x106643;
                func_0x(uVar20,&stack0x00000280 + lVar15);
                *(undefined8 *)(puVar36 + -8) = 0x10664f;
                iVar13 = func_0x(&stack0x00000280 + lVar15);
                *(int *)(&stack0x0000002c + lVar15) = *(int *)(&stack0x0000002c + lVar15) + iVar13;
              }
              if ((*(ulonglong *)(&stack0x00000046 + lVar15) != 0) &&
                 (*(ulonglong *)(&stack0x00000046 + lVar15) <
                  (ulonglong)*(uint *)(&stack0x0000002c + lVar15) +
                  *(longlong *)(&stack0x00000030 + lVar15))) {
                *(undefined8 *)(puVar36 + -8) = 0x106703;
                cVar4 = func_0x(0x1126310);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar36 + -8) = 0x10670c;
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x10671c;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar36 + -8) = 0x106738;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar36 + 0x20) = 0;
                      *(undefined8 *)(puVar36 + -8) = 0x10675e;
                      (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                *(undefined8 *)(puVar36 + -8) = 0x10676c;
                func_0x(uVar20,0x12);
              }
              if (0x3f3b < *(int *)(&stack0x0000002c + lVar15) - 1U) {
                *(undefined8 *)(puVar36 + -8) = 0x106784;
                cVar4 = func_0x(0x1126310);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar36 + -8) = 0x10678d;
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x10679d;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar36 + -8) = 0x1067b9;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar36 + 0x20) = 0;
                      *(undefined8 *)(puVar36 + -8) = 0x1067df;
                      (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(&stack0x00000030 + lVar15);
                *(undefined8 *)(puVar36 + -8) = 0x1067ed;
                func_0x(uVar20,5);
              }
            }
LAB_:
            if (*(uint *)(&stack0x0000002c + lVar15) < 9) {
              *(undefined8 *)(puVar36 + -8) = 0x1067fc;
              cVar4 = func_0x(&stack0x0000002a + lVar15);
              if ((cVar4 != '\0') && (cVar4 != '\f')) goto LAB_;
            }
            else {
LAB_:
              uVar12 = *(undefined4 *)(&stack0x0000002c + lVar15);
            }
            *(undefined4 *)(&stack0x00000168 + lVar15) = *(undefined4 *)(&stack0x00000038 + lVar15);
            *(undefined2 *)(&stack0x0000015a + lVar15) = *(undefined2 *)(&stack0x0000002a + lVar15);
            *(undefined4 *)(&stack0x0000015c + lVar15) = *(undefined4 *)(&stack0x0000002c + lVar15);
            *(undefined2 *)(&stack0x00000174 + lVar15) = *(undefined2 *)(&stack0x00000044 + lVar15);
            *(undefined4 *)(&stack0x0000016c + lVar15) = *(undefined4 *)(&stack0x0000003c + lVar15);
            *(undefined4 *)(&stack0x00000170 + lVar15) = *(undefined4 *)(&stack0x00000040 + lVar15);
            *(undefined4 *)(&stack0x0000017e + lVar15) = *(undefined4 *)(&stack0x0000004e + lVar15);
            *(undefined8 *)(puVar36 + -8) = 0x106854;
            uVar20 = func_0x(&stack0x0000002a + lVar15);
            *(undefined8 *)(puVar36 + -8) = 0x10686b;
            func_0x(&stack0x000028b8 + lVar15,0x1f9e,uVar20,uVar12);
            *(undefined **)(&stack0x00000160 + lVar15) = &stack0x000028b8 + lVar15;
            *(undefined8 *)(puVar36 + -8) = 0x106885;
            iVar13 = func_0x(&stack0x0000015a + lVar15);
            if (iVar13 == 0) {
LAB_:
              psVar46 = (short *)(&stack0x00000158 + lVar15);
              puVar41 = (ushort *)(&stack0x0000015a + lVar15);
            }
            else {
              *(undefined8 *)(puVar36 + -8) = 0x1068a0;
              uVar9 = func_0x(&stack0x0000015a + lVar15,&stack0x000002c0 + lVar15);
              *(ushort *)(&stack0x00000182 + lVar15) = uVar9;
              lVar44 = (ulonglong)uVar9 + *(longlong *)(&stack0x00000160 + lVar15);
              *(undefined8 *)(puVar36 + -8) = 0x1068b9;
              iVar13 = func_0x(lVar44);
              if (iVar13 == 0) {
                *(ushort *)(&stack0x00000184 + lVar15) =
                     *(ushort *)(&stack0x00000184 + lVar15) & 0xc7ff;
              }
              else {
                *(undefined8 *)(puVar36 + -8) = 0x1068c5;
                sVar7 = func_0x(lVar44);
                *(ushort *)(&stack0x00000184 + lVar15) =
                     *(ushort *)(&stack0x00000184 + lVar15) ^
                     (sVar7 << 0xb ^ *(ushort *)(&stack0x00000184 + lVar15)) & 0x3800;
              }
              *(undefined8 *)(puVar36 + -8) = 0x1068fb;
              uVar9 = func_0x(lVar44);
              *(ushort *)(&stack0x00000184 + lVar15) =
                   *(ushort *)(&stack0x00000184 + lVar15) ^
                   (uVar9 ^ *(ushort *)(&stack0x00000184 + lVar15)) & 0x7ff;
              psVar46 = (short *)(&stack0x00000158 + lVar15);
              puVar41 = (ushort *)(&stack0x0000015a + lVar15);
            }
          }
          else {
            *(undefined8 *)(puVar36 + -8) = 0x106933;
            lVar19 = func_0x(&stack0x0000002a + lVar15);
            if (lVar19 == 0) {
LAB_:
              *(undefined8 *)(puVar36 + -8) = 0x10699d;
              func_0x(&stack0x0000015a + lVar15,&stack0x000028b8 + lVar15,0x1f9e,
                              &stack0x0000002a + lVar15);
              if (*(short *)(&stack0x00000028 + lVar15) != 0) {
                *(undefined8 *)(puVar36 + -8) = 0x1069b2;
                lVar44 = func_0x(&stack0x0000002a + lVar15);
              }
              *(undefined8 *)(puVar36 + -8) = 0x1069c1;
              func_0x(&stack0x0000015a + lVar15,lVar44);
              goto LAB_;
            }
            lVar19 = lVar44;
            if (*(short *)(&stack0x00000028 + lVar15) != 0) {
              *(undefined8 *)(puVar36 + -8) = 0x10694d;
              lVar19 = func_0x(&stack0x0000002a + lVar15);
            }
            *(undefined8 *)(puVar36 + -8) = 0x106955;
            iVar13 = func_0x(lVar19);
            if (iVar13 == 0) goto LAB_;
            *(undefined8 *)(puVar36 + -8) = 0x106973;
            func_0x(&stack0x00000158 + lVar15,&stack0x000028b8 + lVar15,0x1f9e,
                            &stack0x00000028 + lVar15);
            psVar46 = (short *)(&stack0x00000158 + lVar15);
            puVar41 = (ushort *)(&stack0x0000015a + lVar15);
          }
        }
        lVar18 = lVar18 + 0x10;
        *(undefined8 *)(puVar36 + -8) = 0x1069e5;
        iVar13 = func_0x(lVar18);
        *(undefined8 *)(puVar36 + -8) = 0x1069f1;
        uVar32 = func_0x(psVar46);
        if ((uint)-iVar13 < uVar32) {
          *(undefined8 *)(puVar36 + -8) = 0x106a00;
          uVar32 = func_0x(psVar46);
        }
        else {
          *(undefined8 *)(puVar36 + -8) = 0x106a0d;
          iVar13 = func_0x(lVar18);
          uVar32 = -iVar13;
        }
        uVar47 = (ulonglong)uVar32;
        *puVar1 = uVar32;
        *(undefined8 *)(puVar36 + -8) = 0x106a20;
        iVar13 = func_0x(&stack0x00000028 + lVar15);
        if (iVar13 != 0) {
          *(undefined8 *)(puVar36 + -8) = 0x106a3e;
          cVar4 = func_0x
                            (&stack0x000000a8 + lVar15,&stack0x00000150 + lVar15,
                             &stack0x0000009c + lVar15);
          if (cVar4 != '\0') {
            uVar12 = *(undefined4 *)(&stack0x0000009c + lVar15);
            uVar20 = *(undefined8 *)(&stack0x00000150 + lVar15);
            *(undefined8 *)(puVar36 + -8) = 0x106a58;
            uVar37 = func_0x(uVar20,uVar12,&stack0x00000028 + lVar15);
            if (uVar32 <= uVar37) {
              uVar12 = *(undefined4 *)(&stack0x0000009c + lVar15);
              uVar20 = *(undefined8 *)(&stack0x00000150 + lVar15);
              *(undefined8 *)(puVar36 + -8) = 0x106a73;
              uVar32 = func_0x(uVar20,uVar12,&stack0x00000028 + lVar15);
              uVar47 = (ulonglong)uVar32;
              *puVar1 = uVar32;
            }
          }
        }
        *(undefined8 *)(puVar36 + -8) = 0x106a81;
        uVar32 = func_0x(lVar18);
        *(undefined8 *)(puVar36 + -8) = 0x106a8b;
        uVar12 = func_0x(lVar18);
        sVar7 = *psVar46;
        **(short **)(&stack0x00000088 + lVar15) = sVar7;
        lVar44 = *(longlong *)((longlong)&lStackX_20 + lVar15);
        puVar48 = (undefined2 *)(lVar44 + 10);
        *(undefined2 **)(&stack0x00000090 + lVar15) = puVar48;
        uVar20 = *(undefined8 *)(&stack0x00000070 + lVar15);
        if (sVar7 == 0) {
          *(undefined8 *)(lVar44 + 0x10) = uVar20;
          *(undefined4 *)(lVar44 + 0x18) = uVar12;
          uVar37 = 0;
          *(undefined2 *)(lVar44 + 0x24) = 0;
          *puVar48 = 0;
          *(undefined4 *)(lVar44 + 0x2e) = 0;
          *(undefined8 *)(puVar36 + -8) = 0x106acf;
          cVar4 = func_0x(puVar41);
          if (cVar4 == '\x06') {
            *(undefined8 *)(puVar36 + -8) = 0x106adb;
            puVar22 = (undefined *)func_0x(puVar48);
            *puVar22 = 6;
            uVar38 = 1;
          }
          else {
            *(undefined8 *)(puVar36 + -8) = 0x106ae8;
            puVar22 = (undefined *)func_0x(puVar48);
            *puVar22 = 0;
            *(undefined *)(*(longlong *)(lVar44 + 0x10) + 1) = 0;
            uVar12 = *(undefined4 *)(lVar44 + 0x18);
            *(undefined8 *)(puVar36 + -8) = 0x106afd;
            func_0x(puVar48,uVar12);
            uVar38 = 4;
          }
          uVar31 = *(uint *)(puVar41 + 7);
          if (*(uint *)(lVar44 + 0x18) <= uVar31) {
            uVar31 = *(uint *)(lVar44 + 0x18);
          }
          lVar18 = *(longlong *)(puVar41 + 3);
          lVar19 = *(longlong *)(lVar44 + 0x10);
          *(undefined8 *)(puVar36 + -8) = 0x106b29;
          func_0x
                    (lVar19 + (ulonglong)uVar38,lVar18 + (ulonglong)uVar38,uVar31 - uVar38);
          if (uVar32 == 0) {
            uVar12 = *(undefined4 *)(lVar44 + 0x18);
            *(undefined4 *)(lVar44 + 0x1c) = uVar12;
            *(undefined4 *)(lVar44 + 0x20) = uVar12;
            *(undefined4 *)(lVar44 + 0xc) = uVar12;
          }
          else {
            *(undefined8 *)(puVar36 + -8) = 0x106b39;
            pbVar23 = (byte *)func_0x(puVar48);
            *pbVar23 = *pbVar23 | 0x10;
            *(uint *)(lVar44 + 0x1c) = (uVar32 + 7 >> 3) + *(int *)(lVar44 + 0x18) + 2;
            *(undefined8 *)(puVar36 + -8) = 0x106b57;
            pbVar23 = (byte *)func_0x(puVar41);
            if ((*pbVar23 & 0x10) == 0) {
              *(undefined8 *)(puVar36 + -8) = 0x106c01;
              func_0x(&stack0x000002a8 + lVar15);
              *(short *)((ulonglong)*(uint *)(lVar44 + 0x18) + *(longlong *)(lVar44 + 0x10)) =
                   (short)uVar32;
            }
            else {
              lVar18 = *(longlong *)(puVar41 + 3);
              uVar9 = *(ushort *)((ulonglong)*(uint *)(puVar41 + 7) + lVar18);
              uVar37 = (uint)uVar9;
              if (uVar9 == uVar32) {
                uVar32 = *(uint *)(lVar44 + 0x18);
                iVar13 = *(int *)(lVar44 + 0x1c);
                uVar37 = *(uint *)(puVar41 + 7);
                lVar19 = *(longlong *)(lVar44 + 0x10);
                *(undefined8 *)(puVar36 + -8) = 0x106b89;
                func_0x
                          ((ulonglong)uVar32 + lVar19,(ulonglong)uVar37 + lVar18,iVar13 - uVar32);
                *(undefined4 *)(lVar44 + 0x20) = *(undefined4 *)(lVar44 + 0x1c);
                *(undefined4 *)(lVar44 + 0xc) = *(undefined4 *)(lVar44 + 0x1c);
                goto LAB_;
              }
              *(undefined8 *)(puVar36 + -8) = 0x106ba8;
              func_0x(&stack0x000002a8 + lVar15);
              *(short *)((ulonglong)*(uint *)(lVar44 + 0x18) + *(longlong *)(lVar44 + 0x10)) =
                   (short)uVar32;
              if (uVar9 != 0) {
                uVar38 = *(uint *)(lVar44 + 0x18);
                uVar30 = *(int *)(lVar44 + 0x1c) - uVar38;
                uVar31 = *(uint *)(puVar41 + 7);
                uVar14 = *(int *)(puVar41 + 9) - uVar31;
                if (uVar14 <= uVar30) {
                  uVar30 = uVar14;
                }
                lVar18 = *(longlong *)(puVar41 + 3);
                lVar19 = *(longlong *)(lVar44 + 0x10);
                *(undefined8 *)(puVar36 + -8) = 0x106bf3;
                func_0x
                          (lVar19 + (ulonglong)uVar38 + 2,(ulonglong)uVar31 + lVar18 + 2,uVar30 - 2)
                ;
              }
            }
            if (uVar32 < uVar37) {
              uVar37 = uVar32 & 0xffff;
            }
            uVar9 = (ushort)uVar37;
            while (uVar9 = uVar9 + 1, uVar9 <= uVar32) {
              *(undefined8 *)(puVar36 + -8) = 0x106c3f;
              func_0x(&stack0x000002a8 + lVar15,uVar9);
              *(undefined8 *)(puVar36 + -8) = 0x106c4e;
              func_0x(puVar48,&stack0x000002a8 + lVar15);
            }
            *(undefined4 *)(lVar44 + 0x20) = *(undefined4 *)(lVar44 + 0x1c);
            *(undefined4 *)(lVar44 + 0xc) = *(undefined4 *)(lVar44 + 0x1c);
          }
        }
        else {
          *(uint *)(puVar36 + 0x20) = uVar32;
          uVar12 = *(undefined4 *)(&stack0x00000078 + lVar15);
          *(undefined8 *)(puVar36 + -8) = 0x106c8f;
          func_0x(puVar48,uVar20,uVar12,puVar41);
        }
LAB_:
        uVar32 = (uint)uVar47;
        if (uVar32 == 0) {
          puVar22 = *(undefined **)(&stack0x00000060 + lVar15);
        }
        else {
          uVar29 = uVar47 * 0x20 + 0xf;
          if (uVar29 <= uVar47 * 0x20) {
            uVar29 = 0xffffffffffffff0;
          }
          uVar29 = uVar29 & 0xfffffffffffffff0;
          *(undefined8 *)(puVar36 + -8) = 0x106cc1;
          func_0x();
          lVar44 = -uVar29;
          puVar22 = puVar36 + lVar44 + 0x50;
          *(undefined **)(&stack0x00000060 + lVar15) = puVar22;
          if (*psVar46 == 0) {
            if (*(int *)(puVar41 + 1) == 0) {
              *puVar41 = 0;
              *(undefined4 *)(puVar41 + 9) = *(undefined4 *)(puVar41 + 7);
              *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106cf6;
              pbVar23 = (byte *)func_0x(puVar41);
              if ((*pbVar23 & 0x10) != 0) {
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106d03;
                pbVar23 = (byte *)func_0x(puVar41);
                if ((*pbVar23 & 0x10) == 0) {
                  uVar37 = 0;
                }
                else {
                  uVar37 = (uint)*(ushort *)
                                  ((ulonglong)*(uint *)(puVar41 + 7) + *(longlong *)(puVar41 + 3));
                }
                *(uint *)(puVar41 + 9) = *(int *)(puVar41 + 9) + (uVar37 + 7 >> 3) + 2;
              }
              *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106d2b;
              pbVar23 = (byte *)func_0x(puVar41);
              if ((*pbVar23 & 0x20) == 0) {
                *(undefined4 *)(puVar41 + 1) = *(undefined4 *)(puVar41 + 9);
                puVar41[0xd] = 0;
                *(undefined4 *)(puVar41 + 0xb) = *(undefined4 *)(puVar41 + 9);
              }
              else {
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106d3c;
                puVar40 = (ushort *)func_0x(puVar41);
                uVar9 = *puVar40;
                puVar41[0xd] = uVar9;
                if (uVar9 == 0) {
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106d57;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106d60;
                    cVar4 = func_0x();
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106d70;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106d8c;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar36 + lVar44 + 0x20) = 0;
                        *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106db2;
                        (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(puVar41 + 3);
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106dc0;
                  func_0x(uVar20,3);
                  uVar9 = puVar41[0xd];
                }
                uVar37 = *(int *)(puVar41 + 9) + (uVar9 + 1) * 2;
                *(uint *)(puVar41 + 0xb) = uVar37;
                if (0x1f9e < uVar37) {
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106de7;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106df0;
                    cVar4 = func_0x();
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106e00;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106e1c;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar36 + lVar44 + 0x20) = 0;
                        *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106e42;
                        (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(puVar41 + 3);
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106e50;
                  func_0x(uVar20,4);
                  uVar9 = puVar41[0xd];
                }
                puVar40 = puVar40 + 1;
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106e66;
                uVar9 = func_0x(puVar40,(ulonglong)uVar9 - 1);
                *(uint *)(puVar41 + 1) = (uint)uVar9;
                if ((uint)uVar9 <= *(uint *)(puVar41 + 0xb) &&
                    *(uint *)(puVar41 + 0xb) != (uint)uVar9) {
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106e7d;
                  cVar4 = func_0x(0x1126310);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106e86;
                    cVar4 = func_0x();
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106e96;
                      cVar4 = func_0x(0x1126310);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106eb2;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar36 + lVar44 + 0x20) = 0;
                        *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106ed8;
                        (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(puVar41 + 3);
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106ee6;
                  func_0x(uVar20,4);
                }
                uVar9 = puVar41[0xd];
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106ef4;
                iVar13 = func_0x(puVar40,uVar9 - 1);
                while (iVar13 != 0) {
                  uVar9 = puVar41[0xd];
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106f0c;
                  lVar18 = func_0x(puVar41);
                  if (uVar9 == 1) {
                    uVar29 = (ulonglong)*(uint *)(puVar41 + 0xb);
                  }
                  else {
                    *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106f29;
                    uVar8 = func_0x(lVar18 + 2,(ulonglong)uVar9 - 2);
                    uVar29 = (ulonglong)uVar8;
                  }
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106f39;
                  uVar9 = func_0x(lVar18 + 2,(ulonglong)(uint)uVar9 - 1);
                  uVar37 = (uint)uVar29;
                  if ((uVar37 < *(uint *)(puVar41 + 0xb)) || (uVar9 < uVar37)) {
                    uVar20 = *(undefined8 *)(puVar41 + 3);
                    *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106f53;
                    func_0x(uVar20,7);
                    if (uVar37 < *(uint *)(puVar41 + 0xb)) goto LAB_;
                  }
                  if (*(uint *)(puVar41 + 1) < uVar37) goto LAB_;
                  if (*(ushort *)(uVar29 + *(longlong *)(puVar41 + 3)) == 5) {
                    *puVar41 = *puVar41 | 2;
                    puVar41[0xd] = puVar41[0xd] - 1;
                    puVar41[0x14] = (ushort)uVar29;
                    lVar18 = (uVar29 & 0xffff) + *(longlong *)(puVar41 + 3);
                    *(undefined8 *)(puVar36 + lVar44 + -8) = 0x10701c;
                    iVar13 = func_0x(lVar18);
                    if (iVar13 == 0) {
                      puVar41[0x15] = puVar41[0x15] & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107028;
                      uVar9 = func_0x(lVar18);
                      puVar41[0x15] = puVar41[0x15] & 0xc7ff;
                      puVar41[0x15] = puVar41[0x15] | (uVar9 & 7) << 0xb;
                    }
                    *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107050;
                    uVar9 = func_0x(lVar18);
                    puVar41[0x15] = puVar41[0x15] & 0xf800;
                    puVar41[0x15] = puVar41[0x15] | uVar9 & 0x7ff;
                    break;
                  }
                  if (*(ushort *)(uVar29 + *(longlong *)(puVar41 + 3)) < 0x400) break;
                  *puVar41 = *puVar41 | 1;
                  uVar9 = puVar41[0xd] - 1;
                  puVar41[0xd] = uVar9;
                  if (uVar9 == 0) break;
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106fa2;
                  iVar13 = func_0x(puVar40,uVar9 - 1);
                }
              }
              *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106fb7;
              iVar13 = func_0x(puVar41);
              if (iVar13 == 0) {
                *(undefined4 *)(puVar41 + 0x12) = 0;
              }
              else {
                *(int *)(puVar41 + 0x12) = *(int *)(puVar41 + 1);
                *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + 0xe;
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106fd6;
                uVar20 = func_0x(puVar41);
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106fe5;
                func_0x(uVar20,&stack0x00000288 + lVar15);
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x106ff1;
                iVar13 = func_0x(&stack0x00000288 + lVar15);
                *(int *)(puVar41 + 1) = *(int *)(puVar41 + 1) + iVar13;
              }
              uVar37 = *(uint *)(puVar41 + 1);
              if ((*(ulonglong *)(puVar41 + 0xe) != 0) &&
                 (*(ulonglong *)(puVar41 + 0xe) < (ulonglong)uVar37 + *(longlong *)(puVar41 + 3))) {
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x1070a9;
                cVar4 = func_0x(0x1126310);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x1070b2;
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + lVar44 + -8) = 0x1070c2;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar36 + lVar44 + -8) = 0x1070de;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar36 + lVar44 + 0x20) = 0;
                      *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107104;
                      (*_DAT_)(1,0xa17098,0xb36d68,0x877);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(puVar41 + 3);
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107112;
                func_0x(uVar20,0x12);
                uVar37 = *(uint *)(puVar41 + 1);
              }
              if (0x3f3b < uVar37 - 1) {
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x10712e;
                cVar4 = func_0x(0x1126310);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107137;
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107147;
                    cVar4 = func_0x(0x1126310);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107163;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar36 + lVar44 + 0x20) = 0;
                      *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107189;
                      (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(puVar41 + 3);
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107197;
                func_0x(uVar20,5);
              }
            }
LAB_:
            uVar37 = (uint)puVar41[0xd];
            if (uVar32 <= puVar41[0xd]) {
              uVar37 = uVar32;
            }
            if (uVar37 != 0) {
              *(undefined8 *)(puVar36 + lVar44 + -8) = 0x1071b7;
              lVar18 = func_0x(puVar41);
              uVar32 = *(uint *)(puVar41 + 0xb);
              *(undefined8 *)(puVar36 + lVar44 + -8) = 0x1071ca;
              func_0x(&stack0x00000300 + lVar15);
              uVar47 = 0;
              lVar18 = lVar18 + 2;
              do {
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x1071df;
                iVar13 = func_0x(lVar18,uVar47);
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x1071f1;
                uVar9 = func_0x(lVar18,uVar47);
                lVar19 = *(longlong *)(puVar41 + 3);
                lVar45 = *(longlong *)(&stack0x00000060 + lVar15);
                *(undefined4 *)(puVar36 + lVar44 + 0x28) = 0;
                *(undefined **)(puVar36 + lVar44 + 0x20) = &stack0x00000300 + lVar15;
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107226;
                func_0x
                          (uVar47 * 0x20 + lVar45,(ulonglong)uVar32 + lVar19,uVar9 - uVar32,
                           iVar13 != 0);
                *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107231;
                uVar9 = func_0x(lVar18,uVar47);
                uVar32 = (uint)uVar9;
                uVar38 = (int)uVar47 + 1;
                uVar47 = (ulonglong)uVar38;
              } while (uVar38 < uVar37);
              puVar48 = *(undefined2 **)(&stack0x00000090 + lVar15);
              uVar47 = (ulonglong)*puVar1;
            }
            puVar22 = *(undefined **)(&stack0x00000060 + lVar15);
            *(undefined8 *)(puVar36 + lVar44 + -8) = 0x107264;
            func_0x
                      (puVar22 + (ulonglong)uVar37 * 0x20,0,((int)uVar47 - uVar37) * 0x20);
            puVar36 = puVar36 + lVar44;
          }
          else {
            *(undefined8 *)(puVar36 + lVar44 + -8) = 0x10727a;
            func_0x(puVar41,puVar22,uVar47);
            puVar36 = puVar36 + lVar44;
          }
        }
        lVar44 = *(longlong *)(&stack0x00000150 + lVar15);
        if (lVar44 != 0) {
          *(int *)(puVar36 + 0x28) = (int)uVar47;
          *(undefined **)(puVar36 + 0x20) = puVar22;
          uVar20 = *(undefined8 *)(&stack0x00000088 + lVar15);
          uVar12 = *(undefined4 *)(&stack0x0000009c + lVar15);
          *(undefined8 *)(puVar36 + -8) = 0x1072a9;
          func_0x(lVar44,uVar12,&stack0x00000028 + lVar15,uVar20);
        }
        *(undefined8 *)(puVar36 + -8) = 0x1072b5;
        uVar20 = func_0x(&stack0x000000a8 + lVar15);
        *(undefined8 *)(puVar36 + -8) = 0x1072bd;
        uVar9 = func_0x(uVar20);
        *(undefined8 *)(&stack0x00000118 + lVar15) = 0;
        *(undefined8 *)(puVar36 + -8) = 0x1072d5;
        lVar44 = func_0x(&stack0x000000a8 + lVar15);
        if (uVar9 != 0) {
          uVar47 = (ulonglong)uVar9;
          do {
            *(undefined8 *)(puVar36 + -8) = 0x1072eb;
            uVar20 = func_0x(lVar44);
            *(undefined8 *)(puVar36 + -8) = 0x1072f6;
            iVar13 = func_0x(lVar44);
            *(undefined8 *)(puVar36 + -8) = 0x10730c;
            func_0x(&stack0x000000a8 + lVar15,lVar44,&stack0x0000007d + lVar15);
            if ((&stack0x0000007d)[lVar15] == '\x03') {
              *(undefined8 *)(puVar36 + -8) = 0x107647;
              iVar39 = func_0x(lVar44);
              if (iVar39 == 0) {
                *(undefined8 *)(puVar36 + -8) = 0x107653;
                iVar39 = func_0x(lVar44);
                if (iVar39 == 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x10766b;
                  (*_DAT_)(6,0x51,0x10,3);
                }
              }
              uVar24 = *(undefined8 *)(&stack0x00000088 + lVar15);
              *(undefined8 *)(puVar36 + -8) = 0x10767d;
              func_0x(uVar24,uVar20,0,0);
              if (iVar13 < 0) {
                *(uint *)(puVar22 + (longlong)-iVar13 * 0x20 + -0x14) =
                     *(uint *)(puVar22 + (longlong)-iVar13 * 0x20 + -0x14) | 2;
              }
            }
            else {
              *(undefined8 *)(puVar36 + -8) = 0x10731e;
              sVar7 = func_0x(uVar20);
              psVar46 = *(short **)(&stack0x00000088 + lVar15);
              if (sVar7 != 0) {
                if (*psVar46 == 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x107338;
                  func_0x();
                }
                else {
                  *(undefined8 *)(puVar36 + -8) = 0x10733f;
                  func_0x(puVar48,uVar20);
                }
              }
              *(undefined8 *)(puVar36 + -8) = 0x107355;
              func_0x(&stack0x000000a8 + lVar15,lVar44,&stack0x00000118 + lVar15);
              *(undefined8 *)(puVar36 + -8) = 0x10735d;
              iVar39 = func_0x(lVar44);
              if ((iVar39 == 1) || (iVar39 == 2)) {
                lVar18 = *(longlong *)(&stack0x00000118 + lVar15);
                *(undefined8 *)(puVar36 + -8) = 0x107507;
                iVar13 = func_0x(lVar44);
                if (iVar13 == 0) {
                  *(undefined8 *)(puVar36 + -8) = 0x107513;
                  uVar11 = func_0x();
                  *(undefined8 *)(puVar36 + -8) = 0x10751e;
                  uVar20 = func_0x(lVar44);
                  *(undefined8 *)(puVar36 + -8) = 0x107526;
                  iVar13 = func_0x(uVar20);
                  lVar19 = *(longlong *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0x10);
                  *(undefined8 *)(puVar36 + -8) = 0x10753f;
                  func_0x(iVar13 + lVar19,lVar18,uVar11);
                }
                else {
                  iVar39 = 0;
                  *(undefined8 *)(puVar36 + -8) = 0x10754b;
                  iVar13 = func_0x(lVar44);
                  if ((iVar13 == 0) || (((&stack0x000000bc)[lVar15] & 8) == 0)) {
                    *(undefined8 *)(puVar36 + -8) = 0x107576;
                    iVar13 = func_0x(lVar44);
                    if (iVar13 == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x1075a8;
                      uVar9 = func_0x(lVar44);
                      uVar32 = (uint)uVar9;
                    }
                    else {
                      *(undefined8 *)(puVar36 + -8) = 0x107582;
                      uVar20 = func_0x();
                      *(undefined8 *)(puVar36 + -8) = 0x107594;
                      uVar24 = func_0x(&stack0x000000a8 + lVar15,lVar44);
                      *(undefined8 *)(puVar36 + -8) = 0x10759f;
                      uVar32 = func_0x(uVar24,uVar20);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar36 + -8) = 0x107560;
                    uVar32 = func_0x(lVar44);
                    uVar32 = *(uint *)(*(longlong *)(&stack0x000000e0 + lVar15) +
                                      (ulonglong)uVar32 * 8);
                  }
                  *(undefined8 *)(puVar36 + -8) = 0x1075b3;
                  uVar9 = func_0x(lVar44);
                  if (uVar32 < uVar9) {
                    *(undefined8 *)(puVar36 + -8) = 0x1075c2;
                    uVar9 = func_0x(lVar44);
                    iVar39 = uVar9 - uVar32;
                  }
                  else {
                    *(undefined8 *)(puVar36 + -8) = 0x1075ce;
                    uVar9 = func_0x(lVar44);
                    if (uVar9 < uVar32) {
                      *(undefined8 *)(puVar36 + -8) = 0x1075eb;
                      (*_DAT_)(6,0x5c,0x16);
                    }
                  }
                  *(undefined8 *)(puVar36 + -8) = 0x1075f3;
                  uVar6 = func_0x(lVar44);
                  (&stack0x0000007e)[lVar15] = uVar6;
                  *(undefined8 *)(puVar36 + -8) = 0x1075fe;
                  uVar20 = func_0x(lVar44);
                  *(undefined8 *)(puVar36 + -8) = 0x107606;
                  iVar13 = func_0x(uVar20);
                  lVar19 = (longlong)iVar13 +
                           *(longlong *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0x10);
                  if ((lVar18 != 0) && (uVar32 != 0)) {
                    *(undefined8 *)(puVar36 + -8) = 0x107628;
                    func_0x(lVar19,lVar18,uVar32);
                  }
                  if (iVar39 != 0) {
                    uVar6 = (&stack0x0000007e)[lVar15];
                    *(undefined8 *)(puVar36 + -8) = 0x10763d;
                    func_0x((ulonglong)uVar32 + lVar19,uVar6,iVar39);
                  }
                }
              }
              else if ((iVar39 == 3) || (iVar39 == 4)) {
                *(undefined8 *)(puVar36 + -8) = 0x107421;
                iVar39 = func_0x(lVar44);
                if ((iVar39 == 0) || (**(int **)(&stack0x00000118 + lVar15) != 0)) {
                  *(undefined8 *)(puVar36 + -8) = 0x10743d;
                  iVar39 = func_0x(lVar44);
                  if ((iVar39 == 0) || (((&stack0x000000bc)[lVar15] & 8) == 0)) {
                    *(undefined8 *)(puVar36 + -8) = 0x107468;
                    iVar39 = func_0x(lVar44);
                    if (iVar39 == 0) {
                      *(undefined8 *)(puVar36 + -8) = 0x10749a;
                      uVar9 = func_0x(lVar44);
                      uVar32 = (uint)uVar9;
                    }
                    else {
                      *(undefined8 *)(puVar36 + -8) = 0x107474;
                      uVar24 = func_0x();
                      *(undefined8 *)(puVar36 + -8) = 0x107486;
                      uVar25 = func_0x(&stack0x000000a8 + lVar15,lVar44);
                      *(undefined8 *)(puVar36 + -8) = 0x107491;
                      uVar32 = func_0x(uVar25,uVar24);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar36 + -8) = 0x107452;
                    uVar32 = func_0x(lVar44);
                    uVar32 = *(uint *)(*(longlong *)(&stack0x000000e0 + lVar15) +
                                      (ulonglong)uVar32 * 8);
                  }
                }
                else {
                  uVar32 = 0;
                }
                *(undefined8 *)(puVar36 + -8) = 0x1074a5;
                uVar9 = func_0x(lVar44);
                if (uVar9 < uVar32) {
                  *(undefined8 *)(puVar36 + -8) = 0x1074c2;
                  (*_DAT_)(6,0x52,0x16);
                }
                *(undefined4 *)(puVar36 + 0x28) = 0;
                *(undefined8 *)(puVar36 + 0x20) = uVar20;
                uVar20 = *(undefined8 *)(&stack0x00000118 + lVar15);
                *(undefined8 *)(puVar36 + -8) = 0x1074f3;
                func_0x(puVar22 + (longlong)(-1 - iVar13) * 0x20,uVar20,uVar32);
              }
              else if (iVar39 == 8) {
                *(undefined8 *)(puVar36 + -8) = 0x1073c0;
                sVar7 = func_0x(psVar46);
                if (sVar7 == 0) {
                  uVar24 = *(undefined8 *)(&stack0x00000118 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x1073dd;
                  func_0x(psVar46,uVar20,uVar24);
                }
                else {
                  *(undefined4 *)(puVar36 + 0x28) = 0;
                  *(undefined8 *)(puVar36 + 0x20) = uVar20;
                  uVar20 = *(undefined8 *)(&stack0x00000118 + lVar15);
                  *(undefined8 *)(puVar36 + -8) = 0x107414;
                  func_0x(puVar22 + (longlong)(-1 - iVar13) * 0x20,uVar20,1);
                }
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0x793578;
                *(undefined8 *)(puVar36 + -8) = 0x1073b3;
                (*_DAT_)(1,0xb983d0,0xbc4d10);
              }
            }
            lVar44 = lVar44 + 0x50;
            uVar47 = uVar47 - 1;
            puVar22 = *(undefined **)(&stack0x00000060 + lVar15);
          } while (uVar47 != 0);
          uVar47 = (ulonglong)*puVar1;
        }
        puVar42 = (undefined2 *)0x0;
        if ((int)uVar47 != 0) {
          if (**(short **)(&stack0x00000088 + lVar15) == 0) {
            *(undefined8 *)(&stack0x00000070 + lVar15) = 0;
            lVar44 = *(longlong *)(&stack0x00000060 + lVar15);
LAB_:
            uVar32 = (uint)uVar47;
            uVar37 = uVar32 - 1;
            if (*(int *)((ulonglong)uVar37 * 0x20 + 8 + lVar44) == 0) goto code_r0x001076e4;
            puVar48[0xd] = (short)uVar47;
            iVar13 = *(int *)(puVar48 + 9) + 2 + uVar32 * 2;
            *(int *)(puVar48 + 0xb) = iVar13;
            *(int *)(puVar48 + 1) = iVar13;
            *(undefined8 *)(puVar36 + -8) = 0x107712;
            pbVar23 = (byte *)func_0x(puVar48);
            *pbVar23 = *pbVar23 | 0x20;
            uVar37 = *(uint *)(puVar48 + 1);
            uVar38 = *(uint *)(&stack0x00000078 + lVar15);
            puVar26 = puVar42;
            if (uVar37 <= uVar38) {
              *(undefined8 *)(puVar36 + -8) = 0x10772a;
              puVar26 = (undefined2 *)func_0x(puVar48);
              *(undefined2 **)(&stack0x00000070 + lVar15) = puVar26;
              *puVar26 = (short)uVar47;
              uVar37 = *(uint *)(puVar48 + 1);
              uVar38 = *(uint *)(&stack0x00000078 + lVar15);
            }
            if (uVar32 != 0) {
              puVar35 = (uint *)(lVar44 + 0xc);
              do {
                uVar31 = *(uint *)(puVar48 + 1);
                lVar44 = *(longlong *)(puVar48 + 3);
                uVar30 = puVar35[-1];
                uVar37 = uVar31 + uVar30;
                *(uint *)(puVar48 + 1) = uVar37;
                if (uVar37 <= uVar38) {
                  uVar38 = *puVar35;
                  *(undefined8 *)(puVar36 + -8) = 0x107780;
                  func_0x(puVar26 + 1,puVar42,uVar37,uVar38 & 1);
                  uVar20 = *(undefined8 *)(puVar35 + -3);
                  *(undefined8 *)(puVar36 + -8) = 0x107792;
                  func_0x((ulonglong)uVar31 + lVar44,uVar30,uVar20,uVar30);
                  uVar37 = *(uint *)(puVar48 + 1);
                  uVar38 = *(uint *)(&stack0x00000078 + lVar15);
                }
                uVar31 = (int)puVar42 + 1;
                puVar42 = (undefined2 *)(ulonglong)uVar31;
                puVar35 = puVar35 + 8;
                puVar26 = *(undefined2 **)(&stack0x00000070 + lVar15);
              } while (uVar31 < uVar32);
            }
            *(uint *)(&stack0x000001d8 + lVar15) = uVar37;
            uVar32 = (uint)(*(uint *)(puVar48 + 1) <= uVar38);
            goto LAB_;
          }
          *(undefined **)(puVar36 + 0x28) = &stack0x000001d8 + lVar15;
          *(undefined8 *)(puVar36 + 0x20) = *(undefined8 *)(&stack0x00000060 + lVar15);
          uVar12 = *(undefined4 *)(&stack0x00000078 + lVar15);
          *(undefined8 *)(puVar36 + -8) = 0x1077e5;
          uVar32 = func_0x(puVar48,uVar12,uVar12,uVar47);
LAB_:
          *(undefined4 *)(&stack0x00000080 + lVar15) = 0;
          if (uVar32 == 0) goto LAB_;
        }
        *(undefined4 *)(&stack0x00000080 + lVar15) = 1;
      }
LAB_:
      if (*(int *)(&stack0x00000080 + lVar15) == 0) {
        *(undefined8 *)(puVar36 + -8) = 0x107813;
        (*_DAT_)(6,0x52,0x16,0xb7);
      }
    }
  }
  else {
    *(undefined2 *)(&stack0x00000190 + lVar15) = 0xffff;
    *(undefined8 *)(&stack0x00000198 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000194 + lVar15) = 0;
    *(undefined8 *)(&stack0x000001ae + lVar15) = 0;
    *(undefined8 *)(&stack0x000001b8 + lVar15) = 0;
    *(undefined8 *)(puVar36 + -8) = 0x10784e;
    func_0x(&stack0x00000192 + lVar15,0);
    sVar7 = *psVar46;
    *(short *)(&stack0x00000190 + lVar15) = sVar7;
    if (sVar7 == 0) {
      if (*(int *)(lVar18 + 0xc) == 0) {
        *(undefined2 *)(lVar18 + 10) = 0;
        *(undefined4 *)(lVar18 + 0x1c) = *(undefined4 *)(lVar18 + 0x18);
        *(undefined8 *)(puVar36 + -8) = 0x107884;
        pbVar23 = (byte *)func_0x(lVar18 + 10);
        if ((*pbVar23 & 0x10) != 0) {
          *(undefined8 *)(puVar36 + -8) = 0x107892;
          pbVar23 = (byte *)func_0x(lVar18 + 10);
          if ((*pbVar23 & 0x10) != 0) {
            uVar32 = (uint)*(ushort *)
                            ((ulonglong)*(uint *)(lVar18 + 0x18) + *(longlong *)(lVar18 + 0x10));
          }
          *(int *)(lVar18 + 0x1c) = *(int *)(lVar18 + 0x1c) + (uVar32 + 7 >> 3) + 2;
        }
        *(undefined8 *)(puVar36 + -8) = 0x1078be;
        pbVar23 = (byte *)func_0x(lVar18 + 10);
        if ((*pbVar23 & 0x20) == 0) {
          *(undefined4 *)(lVar18 + 0xc) = *(undefined4 *)(lVar18 + 0x1c);
          *(undefined2 *)(lVar18 + 0x24) = 0;
          *(undefined4 *)(lVar18 + 0x20) = *(undefined4 *)(lVar18 + 0x1c);
        }
        else {
          *(undefined8 *)(puVar36 + -8) = 0x1078d5;
          puVar41 = (ushort *)func_0x(lVar18 + 10);
          uVar9 = *puVar41;
          *(ushort *)(lVar18 + 0x24) = uVar9;
          if (uVar9 == 0) {
            *(undefined8 *)(puVar36 + -8) = 0x1078f1;
            cVar4 = func_0x(0x1126310);
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x1078fa;
              cVar4 = func_0x();
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x10790a;
                cVar4 = func_0x(0x1126310);
                if (cVar4 == '\0') {
                  *(undefined8 *)(puVar36 + -8) = 0x107924;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar36 + 0x20) = 0;
                  *(undefined8 *)(puVar36 + -8) = 0x107947;
                  (*_DAT_)(1,0xa17098,0xb36d68,0x80f);
                }
              }
            }
            uVar20 = *(undefined8 *)(lVar18 + 0x10);
            *(undefined8 *)(puVar36 + -8) = 0x107955;
            func_0x(uVar20,3);
            uVar9 = *(ushort *)(lVar18 + 0x24);
          }
          uVar32 = *(int *)(lVar18 + 0x1c) + 2 + (uint)uVar9 * 2;
          *(uint *)(lVar18 + 0x20) = uVar32;
          if (0x1f9e < uVar32) {
            *(undefined8 *)(puVar36 + -8) = 0x10797f;
            cVar4 = func_0x(0x1126310);
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x107988;
              cVar4 = func_0x();
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x107998;
                cVar4 = func_0x(0x1126310);
                if (cVar4 == '\0') {
                  *(undefined8 *)(puVar36 + -8) = 0x1079b4;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar36 + 0x20) = 0;
                  *(undefined8 *)(puVar36 + -8) = 0x1079d7;
                  (*_DAT_)(1,0xa17098,0xb36d68,0x816);
                }
              }
            }
            uVar20 = *(undefined8 *)(lVar18 + 0x10);
            *(undefined8 *)(puVar36 + -8) = 0x1079e5;
            func_0x(uVar20,4);
            uVar9 = *(ushort *)(lVar18 + 0x24);
          }
          puVar41 = puVar41 + 1;
          *(undefined8 *)(puVar36 + -8) = 0x1079fc;
          uVar9 = func_0x(puVar41,(ulonglong)uVar9 - 1);
          *(uint *)(lVar18 + 0xc) = (uint)uVar9;
          if ((uint)uVar9 <= *(uint *)(lVar18 + 0x20) && *(uint *)(lVar18 + 0x20) != (uint)uVar9) {
            *(undefined8 *)(puVar36 + -8) = 0x107a15;
            cVar4 = func_0x(0x1126310);
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x107a1e;
              cVar4 = func_0x();
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x107a2e;
                cVar4 = func_0x(0x1126310);
                if (cVar4 == '\0') {
                  *(undefined8 *)(puVar36 + -8) = 0x107a4a;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar36 + 0x20) = 0;
                  *(undefined8 *)(puVar36 + -8) = 0x107a6d;
                  (*_DAT_)(1,0xa17098,0xb36d68,0x81d);
                }
              }
            }
            uVar20 = *(undefined8 *)(lVar18 + 0x10);
            *(undefined8 *)(puVar36 + -8) = 0x107a7b;
            func_0x(uVar20,4);
          }
          uVar9 = *(ushort *)(lVar18 + 0x24);
          *(undefined8 *)(puVar36 + -8) = 0x107a8a;
          iVar13 = func_0x(puVar41,uVar9 - 1);
          while (iVar13 != 0) {
            uVar9 = *(ushort *)(lVar18 + 0x24);
            *(undefined8 *)(puVar36 + -8) = 0x107aa0;
            lVar44 = func_0x(lVar18 + 10);
            if (uVar9 == 1) {
              uVar32 = *(uint *)(lVar18 + 0x20);
            }
            else {
              *(undefined8 *)(puVar36 + -8) = 0x107abe;
              uVar8 = func_0x(lVar44 + 2,(ulonglong)uVar9 - 2);
              uVar32 = (uint)uVar8;
            }
            *(undefined8 *)(puVar36 + -8) = 0x107ace;
            uVar9 = func_0x(lVar44 + 2,(ulonglong)(uint)uVar9 - 1);
            if ((uVar32 < *(uint *)(lVar18 + 0x20)) || (uVar9 < uVar32)) {
              uVar20 = *(undefined8 *)(lVar18 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x107ae9;
              func_0x(uVar20,7);
              if (uVar32 < *(uint *)(lVar18 + 0x20)) goto LAB_;
            }
            if (*(uint *)(lVar18 + 0xc) < uVar32) goto LAB_;
            uVar9 = *(ushort *)((ulonglong)uVar32 + *(longlong *)(lVar18 + 0x10));
            if (uVar9 == 5) {
              *(ushort *)(lVar18 + 10) = *(ushort *)(lVar18 + 10) | 2;
              *(short *)(lVar18 + 0x24) = *(short *)(lVar18 + 0x24) + -1;
              *(short *)(lVar18 + 0x32) = (short)uVar32;
              lVar44 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(lVar18 + 0x10);
              *(undefined8 *)(puVar36 + -8) = 0x107bbf;
              iVar13 = func_0x(lVar44);
              if (iVar13 == 0) {
                *(ushort *)(lVar18 + 0x34) = *(ushort *)(lVar18 + 0x34) & 0xc7ff;
              }
              else {
                *(undefined8 *)(puVar36 + -8) = 0x107bcb;
                uVar9 = func_0x(lVar44);
                *(ushort *)(lVar18 + 0x34) = *(ushort *)(lVar18 + 0x34) & 0xc7ff;
                *(ushort *)(lVar18 + 0x34) = *(ushort *)(lVar18 + 0x34) | (uVar9 & 7) << 0xb;
              }
              *(undefined8 *)(puVar36 + -8) = 0x107bf6;
              uVar9 = func_0x(lVar44);
              *(ushort *)(lVar18 + 0x34) = *(ushort *)(lVar18 + 0x34) & 0xf800;
              *(ushort *)(lVar18 + 0x34) = *(ushort *)(lVar18 + 0x34) | uVar9 & 0x7ff;
              break;
            }
            if (uVar9 < 0x400) break;
            *(ushort *)(lVar18 + 10) = *(ushort *)(lVar18 + 10) | 1;
            uVar9 = *(short *)(lVar18 + 0x24) - 1;
            *(ushort *)(lVar18 + 0x24) = uVar9;
            if (uVar9 == 0) break;
            *(undefined8 *)(puVar36 + -8) = 0x107b3e;
            iVar13 = func_0x(puVar41,uVar9 - 1);
          }
        }
        *(undefined8 *)(puVar36 + -8) = 0x107b57;
        iVar13 = func_0x(lVar18 + 10);
        if (iVar13 == 0) {
          *(undefined4 *)(lVar18 + 0x2e) = 0;
        }
        else {
          *(int *)(lVar18 + 0x2e) = *(int *)(lVar18 + 0xc);
          *(int *)(lVar18 + 0xc) = *(int *)(lVar18 + 0xc) + 0xe;
          *(undefined8 *)(puVar36 + -8) = 0x107b77;
          uVar20 = func_0x(lVar18 + 10);
          *(undefined8 *)(puVar36 + -8) = 0x107b86;
          func_0x(uVar20,&stack0x00000290 + lVar15);
          *(undefined8 *)(puVar36 + -8) = 0x107b92;
          iVar13 = func_0x(&stack0x00000290 + lVar15);
          *(int *)(lVar18 + 0xc) = *(int *)(lVar18 + 0xc) + iVar13;
        }
        uVar32 = *(uint *)(lVar18 + 0xc);
        if ((*(ulonglong *)(lVar18 + 0x26) != 0) &&
           (*(ulonglong *)(lVar18 + 0x26) < (ulonglong)uVar32 + *(longlong *)(lVar18 + 0x10))) {
          *(undefined8 *)(puVar36 + -8) = 0x107c50;
          cVar4 = func_0x(0x1126310);
          if (cVar4 != '\0') {
            *(undefined8 *)(puVar36 + -8) = 0x107c59;
            cVar4 = func_0x();
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x107c69;
              cVar4 = func_0x(0x1126310);
              if (cVar4 == '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x107c85;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0;
                *(undefined8 *)(puVar36 + -8) = 0x107ca8;
                (*_DAT_)(1,0xa17098,0xb36d68,0x877);
              }
            }
          }
          uVar20 = *(undefined8 *)(lVar18 + 0x10);
          *(undefined8 *)(puVar36 + -8) = 0x107cb6;
          func_0x(uVar20,0x12);
          uVar32 = *(uint *)(lVar18 + 0xc);
        }
        if (0x3f3b < uVar32 - 1) {
          *(undefined8 *)(puVar36 + -8) = 0x107cd0;
          cVar4 = func_0x(0x1126310);
          if (cVar4 != '\0') {
            *(undefined8 *)(puVar36 + -8) = 0x107cd9;
            cVar4 = func_0x();
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x107ce9;
              cVar4 = func_0x(0x1126310);
              if (cVar4 == '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x107d05;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0;
                *(undefined8 *)(puVar36 + -8) = 0x107d28;
                (*_DAT_)(1,0xa17098,0xb36d68,0x87c);
              }
            }
          }
          uVar20 = *(undefined8 *)(lVar18 + 0x10);
          *(undefined8 *)(puVar36 + -8) = 0x107d36;
          func_0x(uVar20,5);
        }
      }
LAB_:
      uVar32 = *(uint *)(lVar18 + 0xc);
      if (uVar32 < 9) {
        *(undefined8 *)(puVar36 + -8) = 0x107d49;
        cVar4 = func_0x(lVar18 + 10);
        if ((cVar4 == '\0') || (cVar4 == '\f')) {
          uVar32 = 9;
        }
        else {
          uVar32 = *(uint *)(lVar18 + 0xc);
        }
      }
      *(undefined4 *)(&stack0x000001a0 + lVar15) = *(undefined4 *)(lVar18 + 0x18);
      *(undefined2 *)(&stack0x00000192 + lVar15) = *(undefined2 *)(lVar18 + 10);
      *(undefined4 *)(&stack0x00000194 + lVar15) = *(undefined4 *)(lVar18 + 0xc);
      *(undefined2 *)(&stack0x000001ac + lVar15) = *(undefined2 *)(lVar18 + 0x24);
      *(undefined4 *)(&stack0x000001a4 + lVar15) = *(undefined4 *)(lVar18 + 0x1c);
      *(undefined4 *)(&stack0x000001a8 + lVar15) = *(undefined4 *)(lVar18 + 0x20);
      *(undefined4 *)(&stack0x000001b6 + lVar15) = *(undefined4 *)(lVar18 + 0x2e);
      *(undefined8 *)(puVar36 + -8) = 0x107db0;
      uVar20 = func_0x(lVar18 + 10);
      *(undefined8 *)(puVar36 + -8) = 0x107dc7;
      func_0x(&stack0x00004858 + lVar15,0x1f9e,uVar20,uVar32);
      *(undefined **)(&stack0x00000198 + lVar15) = &stack0x00004858 + lVar15;
      *(undefined8 *)(puVar36 + -8) = 0x107de1;
      iVar13 = func_0x(&stack0x00000192 + lVar15);
      if (iVar13 != 0) {
        *(undefined8 *)(puVar36 + -8) = 0x107dfc;
        uVar9 = func_0x(&stack0x00000192 + lVar15,&stack0x000002bc + lVar15);
        *(ushort *)(&stack0x000001ba + lVar15) = uVar9;
        lVar44 = (ulonglong)uVar9 + *(longlong *)(&stack0x00000198 + lVar15);
        *(undefined8 *)(puVar36 + -8) = 0x107e15;
        iVar13 = func_0x(lVar44);
        if (iVar13 == 0) {
          *(ushort *)(&stack0x000001bc + lVar15) = *(ushort *)(&stack0x000001bc + lVar15) & 0xc7ff;
        }
        else {
          *(undefined8 *)(puVar36 + -8) = 0x107e21;
          sVar7 = func_0x(lVar44);
          *(ushort *)(&stack0x000001bc + lVar15) =
               *(ushort *)(&stack0x000001bc + lVar15) ^
               (sVar7 << 0xb ^ *(ushort *)(&stack0x000001bc + lVar15)) & 0x3800;
        }
        *(undefined8 *)(puVar36 + -8) = 0x107e57;
        uVar9 = func_0x(lVar44);
        *(ushort *)(&stack0x000001bc + lVar15) =
             *(ushort *)(&stack0x000001bc + lVar15) ^
             (uVar9 ^ *(ushort *)(&stack0x000001bc + lVar15)) & 0x7ff;
      }
    }
    else {
      if (*psVar46 != 0) {
        *(undefined8 *)(puVar36 + -8) = 0x107eef;
        lVar19 = func_0x(lVar18 + 10);
        if (lVar19 != 0) {
          if (*psVar46 != 0) {
            *(undefined8 *)(puVar36 + -8) = 0x107f0a;
            lVar44 = func_0x(lVar18 + 10);
          }
          *(undefined8 *)(puVar36 + -8) = 0x107f12;
          iVar13 = func_0x(lVar44);
          if (iVar13 != 0) {
            *(undefined8 *)(puVar36 + -8) = 0x107f32;
            func_0x(&stack0x00000190 + lVar15,&stack0x00004858 + lVar15,0x1f9e,psVar46);
            goto LAB_;
          }
        }
      }
      *(undefined8 *)(puVar36 + -8) = 0x107f54;
      func_0x(&stack0x00000192 + lVar15,&stack0x00004858 + lVar15,0x1f9e,lVar18 + 10);
      if (*psVar46 == 0) {
        *(undefined8 *)(puVar36 + -8) = 0x107f6e;
        func_0x(&stack0x00000192 + lVar15,0);
      }
      else {
        *(undefined8 *)(puVar36 + -8) = 0x107f7c;
        uVar20 = func_0x(lVar18 + 10);
        *(undefined8 *)(puVar36 + -8) = 0x107f8b;
        func_0x(&stack0x00000192 + lVar15,uVar20);
      }
    }
LAB_:
    *(undefined8 *)(puVar36 + -8) = 0x107e89;
    func_0x(&stack0x00000310 + lVar15,&stack0x00000190 + lVar15);
    *(undefined8 *)(puVar36 + 0x40) = 0;
    *(undefined **)(puVar36 + 0x38) = &stack0x000002b8 + lVar15;
    uVar12 = *(undefined4 *)(&stack0x00000078 + lVar15);
    *(undefined4 *)(puVar36 + 0x30) = uVar12;
    *(undefined4 *)(puVar36 + 0x28) = uVar12;
    *(undefined8 *)(puVar36 + 0x20) = *(undefined8 *)(lVar18 + 0x10);
    *(undefined8 *)(puVar36 + -8) = 0x107eca;
    func_0x(&stack0x00000398 + lVar15,&stack0x000000a8 + lVar15,2,psVar46);
  }
  *(undefined8 *)(puVar36 + -8) = 0x107ed7;
  func_0x(&stack0x000002c8 + lVar15);
  puVar22 = puVar36;
LAB_:
  uVar47 = *(ulonglong *)(&stack0x000067f8 + lVar15);
  *(undefined8 *)(puVar22 + -8) = 0x10801c;
  func_0x(uVar47 ^ (ulonglong)puVar1);
  return;
code_r0x0010575b:
  uVar47 = (ulonglong)uVar37;
  if (uVar37 == 0) goto LAB_;
  goto LAB_;
code_r0x001076e4:
  uVar47 = (ulonglong)uVar37;
  if (uVar37 == 0) goto LAB_;
  goto LAB_;
}

