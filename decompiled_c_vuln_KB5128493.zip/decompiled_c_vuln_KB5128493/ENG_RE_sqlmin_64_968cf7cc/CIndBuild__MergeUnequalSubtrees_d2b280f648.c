
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,longlong **param_3)

{
  byte *pbVar1;
  ushort uVar2;
  short sVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  char cVar7;
  uint uVar8;
  short *psVar9;
  int iVar10;
  code *UNRECOVERED_JUMPTABLE_00;
  byte **ppbVar11;
  ulonglong uVar12;
  uint uVar13;
  undefined auStack_928 [72];
  longlong lStack_8e0;
  undefined4 uStack_8c8;
  undefined8 uStack_8c0;
  longlong lStack_888;
  undefined8 uStack_860;
  undefined2 uStack_858;
  undefined8 uStack_850;
  undefined2 uStack_848;
  longlong **pplStack_830;
  undefined4 uStack_818;
  undefined2 uStack_814;
  undefined4 uStack_810;
  undefined2 uStack_80c;
  longlong **pplStack_7e0;
  undefined8 uStack_728;
  short sStack_1c8;
  undefined4 uStack_1c4;
  byte *pbStack_1c0;
  byte **ppbStack_1b8;
  undefined8 uStack_1aa;
  undefined2 uStack_1a2;
  undefined2 uStack_1a0;
  undefined6 uStack_19e;
  int iStack_194;
  undefined auStack_190 [16];
  undefined auStack_180 [8];
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined6 uStack_168;
  undefined2 uStack_162;
  undefined6 uStack_160;
  undefined2 uStack_15a;
  undefined8 uStack_158;
  undefined auStack_150 [16];
  undefined auStack_140 [16];
  undefined auStack_130 [16];
  undefined8 uStack_120;
  ulonglong uStack_50;
  
  uStack_728 = 0xfffffffffffffffe;
  uStack_50 = _DAT_ ^ (ulonglong)auStack_928;
  lVar4 = **param_2;
  lVar5 = **param_3;
  sStack_1c8 = -1;
  pbStack_1c0 = (byte *)0x0;
  uVar13 = 0;
  uStack_1c4 = 0;
  uStack_1aa = 0;
  uStack_1a0 = 0;
  uStack_19e = 0;
  ppbStack_1b8 = (byte **)0x0;
  uStack_8c0 = *(undefined8 *)(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0xf50) = 1;
  if (*(char *)(lVar4 + 1) == '\x01') {
    uVar8 = 1;
  }
  else {
    uVar8 = uVar13;
    if ((*(char *)(lVar4 + 1) == '\x02') && (*(char *)(lVar4 + 3) == '\0')) {
      uVar8 = (uint)(1 < *(ushort *)(lVar4 + 6));
    }
  }
  if (*(char *)(lVar5 + 1) == '\x01') {
    uVar13 = 1;
  }
  else if ((*(char *)(lVar5 + 1) == '\x02') && (*(char *)(lVar5 + 3) == '\0')) {
    uVar13 = (uint)(1 < *(ushort *)(lVar5 + 6));
  }
  lStack_8e0 = lVar4;
  lStack_888 = param_1;
  pplStack_830 = param_2;
  pplStack_7e0 = param_3;
  if (uVar8 == uVar13) {
    if (uVar8 == 0) {
      iVar10 = (uint)*(byte *)(lVar4 + 3) - (uint)*(byte *)(lVar5 + 3);
      goto LAB_;
    }
  }
  else {
    iVar10 = (uVar8 ^ 1) * 2 + -1;
LAB_:
    if (0 < iVar10) {
      *(undefined4 *)(param_1 + 0xf50) = 0;
      lVar6 = *(longlong *)(param_1 + 0x60);
      *(undefined4 *)(lVar6 + 0x14) = *(undefined4 *)(lVar4 + 0x20);
      *(undefined2 *)(lVar6 + 0x18) = *(undefined2 *)(lVar4 + 0x24);
      *(undefined2 *)(lVar6 + 0x1a) = 0;
      func_0x(param_1,lVar5);
      func_0x(param_1,lVar5,param_2);
      *(undefined4 *)(param_1 + 0xf54) = *(undefined4 *)(lVar5 + 0x20);
      *(undefined2 *)(param_1 + 0xf58) = *(undefined2 *)(lVar5 + 0x24);
      lVar4 = **param_2;
      uVar2 = *(ushort *)(lVar4 + 0x16);
      iStack_194 = uVar2 - 1;
      if (-1 < *(char *)(lVar4 + 2)) goto LAB_;
      pbVar1 = (byte *)(lVar4 + 0x60);
      if ((sStack_1c8 == 0) || (ppbVar11 = ppbStack_1b8, ppbStack_1b8 == (byte **)0x0)) {
        uStack_168 = 0;
        uStack_15a = 0;
        auStack_140 = ZEXT816(0);
        auStack_190 = ZEXT816(0);
        stack0xfffffffffffffe82 = SUB1614(ZEXT816(0),2);
        auStack_180._0_2_ = 0xffff;
        uStack_178 = 0;
        uStack_162 = 0;
        uStack_160 = 0;
        uStack_158 = 0;
        uStack_170 = 0;
        auStack_150 = ZEXT816(0);
        auStack_130._0_12_ = ZEXT812(0);
        auStack_130._12_4_ = 0;
        uStack_120 = 0;
        ppbVar11 = (byte **)auStack_190;
      }
      if (*(short *)(lVar4 + 0x24) == 0) {
LAB_:
        uStack_850 = *(undefined8 *)(lVar4 + 0x28);
        uStack_848 = *(undefined2 *)(lVar4 + 0x30);
      }
      else {
        cVar7 = *(char *)(lVar4 + 1);
        if (cVar7 == '\v') {
          if (*(int *)(lVar4 + 0x18) != 99) {
LAB_:
            if (cVar7 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar7 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar4 + 0x18) != 99) goto LAB_;
        }
        uStack_818 = *(undefined4 *)(lVar4 + 0x20);
        uStack_814 = *(undefined2 *)(lVar4 + 0x24);
        cVar7 = func_0x(&uStack_818,0x100ce88);
        if (cVar7 == '\0') goto LAB_;
        func_0x(lVar4,&uStack_850);
      }
      *ppbVar11 = pbVar1;
      *(undefined4 *)(ppbVar11 + 0xc) = (undefined4)uStack_850;
      *(int *)((longlong)ppbVar11 + 100) = (int)((ulonglong)uStack_850 >> 0x20);
      *(undefined2 *)(ppbVar11 + 0xd) = uStack_848;
      *(undefined4 *)((longlong)ppbVar11 + 0x6c) = *(undefined4 *)(lVar4 + 0x20);
      *(undefined2 *)(ppbVar11 + 0xe) = *(undefined2 *)(lVar4 + 0x24);
      *(undefined2 *)((longlong)ppbVar11 + 0x72) = 0;
      uStack_8c8 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x108d490);
      uVar12 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x108d494);
      *(undefined2 *)(ppbVar11 + 2) = 0xffff;
      ppbVar11[3] = (byte *)0x0;
      *(undefined4 *)((longlong)ppbVar11 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar11 + 0x2e) = 0;
      ppbVar11[7] = (byte *)0x0;
      ppbVar11[4] = (byte *)0x0;
      ppbVar11[9] = (byte *)0x0;
      ppbVar11[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar11 + 0xb) = 0;
      if ((**ppbVar11 & 2) != 0) {
        pbVar1 = pbVar1 + uVar12;
        if ((*pbVar1 & 1) == 0) {
          *(undefined2 *)(ppbVar11 + 2) = 0;
          ppbVar11[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar11 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar11 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001004ff */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x103a2c) - 0x14ac9a0
                    ))();
          return;
        }
        *(undefined2 *)(ppbVar11 + 2) = 1;
        ppbVar11[3] = pbVar1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x103a0c) * 4
                               + 0x1039fc) - 0x14ac9a0);
                    /* WARNING: Could not emulate address calculation at 0x0010036e */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      if ((**ppbVar11 & 4) != 0) {
        uStack_8c8._2_2_ = (short)((uint)uStack_8c8 >> 0x10);
        if (uStack_8c8._2_2_ != 0) {
          uVar12 = (ulonglong)*(ushort *)(lVar4 + 0x61 + (longlong)uStack_8c8._2_2_ * 2);
        }
        psVar9 = (short *)(pbVar1 + uVar12);
        ppbVar11[9] = (byte *)psVar9;
        sVar3 = *psVar9;
        ppbVar11[10] = (byte *)(psVar9 + 1);
        *(short *)(ppbVar11 + 0xb) = (sVar3 + 1) * 2;
      }
      if (ppbVar11[1] != (byte *)0x0) {
        func_0x(ppbVar11[1],ppbVar11);
      }
LAB_:
      pbStack_1c0 = (byte *)((ulonglong)*(ushort *)(lVar4 + (0x1000 - (ulonglong)uVar2) * 2) + lVar4
                            );
      if ((*pbStack_1c0 & 1) == 0) {
        sStack_1c8 = 0;
        uStack_1c4 = 0;
        uStack_1a2 = 0;
        uStack_1a0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007c2 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1c0 & 0xe) * 4 + 0x103a98) -
                  0x14ac9a0))((longlong)(int)(*pbStack_1c0 & 0xe),0x100ce88,pbStack_1c0);
        return;
      }
      sStack_1c8 = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1c0 & 0x1c) + 0x103a78)
                              * 4 + 0x103a68) - 0x14ac9a0);
                    /* WARNING: Could not emulate address calculation at 0x00100616 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
  }
  lVar6 = *(longlong *)(param_1 + 0x60);
  *(undefined4 *)(lVar6 + 0x14) = *(undefined4 *)(lVar5 + 0x20);
  *(undefined2 *)(lVar6 + 0x18) = *(undefined2 *)(lVar5 + 0x24);
  *(undefined2 *)(lVar6 + 0x1a) = 0;
  func_0x(param_1,lVar4);
  func_0x(param_1,lVar4,param_3);
  lVar4 = **param_3;
  iStack_194 = 0;
  if (-1 < *(char *)(lVar4 + 2)) goto LAB_;
  pbVar1 = (byte *)(lVar4 + 0x60);
  if ((sStack_1c8 == 0) || (ppbVar11 = ppbStack_1b8, ppbStack_1b8 == (byte **)0x0)) {
    uStack_168 = 0;
    uStack_15a = 0;
    auStack_140 = ZEXT816(0);
    auStack_190 = ZEXT816(0);
    stack0xfffffffffffffe82 = SUB1614(ZEXT816(0),2);
    auStack_180._0_2_ = 0xffff;
    uStack_178 = 0;
    uStack_162 = 0;
    uStack_160 = 0;
    uStack_158 = 0;
    uStack_170 = 0;
    auStack_150 = ZEXT816(0);
    auStack_130._0_12_ = ZEXT812(0);
    auStack_130._12_4_ = 0;
    uStack_120 = 0;
    ppbVar11 = (byte **)auStack_190;
  }
  if (*(short *)(lVar4 + 0x24) == 0) {
LAB_:
    uStack_860 = *(undefined8 *)(lVar4 + 0x28);
    uStack_858 = *(undefined2 *)(lVar4 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar4 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar4 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar4 + 0x18) != 99) goto LAB_;
    }
    uStack_810 = *(undefined4 *)(lVar4 + 0x20);
    uStack_80c = *(undefined2 *)(lVar4 + 0x24);
    cVar7 = func_0x(&uStack_810,6);
    if (cVar7 == '\0') goto LAB_;
    func_0x(lVar4,&uStack_860);
  }
  *ppbVar11 = pbVar1;
  *(undefined4 *)(ppbVar11 + 0xc) = (undefined4)uStack_860;
  *(int *)((longlong)ppbVar11 + 100) = (int)((ulonglong)uStack_860 >> 0x20);
  *(undefined2 *)(ppbVar11 + 0xd) = uStack_858;
  *(undefined4 *)((longlong)ppbVar11 + 0x6c) = *(undefined4 *)(lVar4 + 0x20);
  *(undefined2 *)(ppbVar11 + 0xe) = *(undefined2 *)(lVar4 + 0x24);
  *(undefined2 *)((longlong)ppbVar11 + 0x72) = 0;
  uStack_8c8 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x108d490);
  uVar12 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x108d494);
  *(undefined2 *)(ppbVar11 + 2) = 0xffff;
  ppbVar11[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar11 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar11 + 0x2e) = 0;
  ppbVar11[7] = (byte *)0x0;
  ppbVar11[4] = (byte *)0x0;
  ppbVar11[9] = (byte *)0x0;
  ppbVar11[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar11 + 0xb) = 0;
  if ((**ppbVar11 & 2) != 0) {
    pbVar1 = pbVar1 + uVar12;
    if ((*pbVar1 & 1) == 0) {
      *(undefined2 *)(ppbVar11 + 2) = 0;
      ppbVar11[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar11 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar11 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001015f6 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x103b04) - 0x14ac9a0))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar11 + 2) = 1;
    ppbVar11[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x103ae4) * 4 +
                           0x103ad4) - 0x14ac9a0);
                    /* WARNING: Could not emulate address calculation at 0x00101465 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar11 & 4) != 0) {
    uStack_8c8._2_2_ = (short)((uint)uStack_8c8 >> 0x10);
    if (uStack_8c8._2_2_ != 0) {
      uVar12 = (ulonglong)*(ushort *)(lVar4 + 0x61 + (longlong)uStack_8c8._2_2_ * 2);
    }
    psVar9 = (short *)(pbVar1 + uVar12);
    ppbVar11[9] = (byte *)psVar9;
    sVar3 = *psVar9;
    ppbVar11[10] = (byte *)(psVar9 + 1);
    *(short *)(ppbVar11 + 0xb) = (sVar3 + 1) * 2;
  }
  if (ppbVar11[1] != (byte *)0x0) {
    func_0x(ppbVar11[1],ppbVar11);
  }
LAB_:
  pbStack_1c0 = (byte *)((ulonglong)*(ushort *)(lVar4 + 0x1ffe) + lVar4);
  if ((*pbStack_1c0 & 1) == 0) {
    sStack_1c8 = 0;
    uStack_1c4 = 0;
    uStack_1a2 = 0;
    uStack_1a0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001018a9 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1c0 & 0xe) * 4 + 0x103b70) - 0x14ac9a0)
    )((longlong)(int)(*pbStack_1c0 & 0xe),6,pbStack_1c0);
    return;
  }
  sStack_1c8 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1c0 & 0x1c) + 0x103b50) * 4
                         + 0x103b40) - 0x14ac9a0);
                    /* WARNING: Could not emulate address calculation at 0x001016ff */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

