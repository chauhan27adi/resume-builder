
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,int param_3,undefined4 param_4,int param_5,
                 undefined8 param_6)

{
  undefined2 uVar1;
  undefined4 uVar2;
  longlong *plVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  bool bVar6;
  longlong **pplVar7;
  byte bVar8;
  ushort uVar9;
  int iVar10;
  undefined4 uVar11;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar12;
  undefined4 *puVar13;
  ushort uVar14;
  longlong lVar15;
  longlong lVar16;
  longlong *plVar17;
  undefined8 *puVar18;
  uint uVar19;
  uint uVar20;
  byte bVar21;
  undefined auStack_328 [24];
  undefined8 uStack_310;
  undefined8 auStack_308 [4];
  undefined8 uStack_2e8;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined4 uStack_2d4;
  undefined8 uStack_2d0;
  undefined8 uStack_2c8;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined4 uStack_2b4;
  undefined4 auStack_2b0 [2];
  undefined2 auStack_2a8 [4];
  undefined8 uStack_2a0;
  undefined auStack_298 [32];
  undefined8 uStack_278;
  undefined2 auStack_258 [2];
  undefined4 uStack_254;
  byte *pbStack_250;
  undefined8 uStack_248;
  undefined8 uStack_23a;
  undefined2 uStack_232;
  undefined2 uStack_230;
  undefined6 uStack_22e;
  longlong lStack_220;
  int iStack_218;
  undefined4 uStack_214;
  undefined2 uStack_210;
  undefined2 uStack_20e;
  undefined4 uStack_20c;
  undefined2 uStack_208;
  undefined2 uStack_206;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined2 uStack_1fc;
  undefined2 uStack_1fa;
  undefined4 uStack_1f8;
  undefined2 uStack_1f4;
  undefined2 uStack_1f2;
  undefined4 uStack_1f0;
  undefined2 uStack_1ec;
  undefined2 uStack_1ea;
  undefined4 uStack_1e8;
  undefined2 uStack_1e4;
  undefined2 uStack_1e2;
  longlong **pplStack_1e0;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  longlong *plStack_1d0;
  undefined8 uStack_1c8;
  undefined4 uStack_1c0;
  undefined2 uStack_1bc;
  undefined8 uStack_1ba;
  undefined2 uStack_1b2;
  undefined2 uStack_1b0;
  undefined6 uStack_1ae;
  undefined4 uStack_198;
  undefined2 uStack_194;
  undefined8 uStack_190;
  undefined4 uStack_188;
  undefined8 uStack_180;
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined4 *puStack_168;
  undefined4 *puStack_160;
  undefined4 *puStack_158;
  undefined2 uStack_150;
  char cStack_14e;
  longlong lStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  byte bStack_120;
  undefined7 uStack_11f;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined8 uStack_108;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined8 uStack_e8;
  undefined4 uStack_d8;
  undefined4 auStack_d4 [31];
  ulonglong uStack_58;
  
  puVar18 = (undefined8 *)auStack_298;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_258;
  uStack_178 = 0x78;
  plStack_1d0 = (longlong *)0x0;
  uStack_1d8 = CONCAT22(uStack_1d8._2_2_,0xffff);
  uStack_1d4 = 0;
  puStack_168 = &uStack_d8;
  uStack_1ba = 0;
  puStack_158 = auStack_d4;
  uStack_1b0 = 0;
  uStack_1ae = 0;
  puStack_160 = &uStack_d8;
  lStack_220 = *(longlong *)(param_1 + 0x50);
  uStack_1c8 = 0;
  uStack_198 = 0;
  uStack_194 = 0;
  uStack_190 = 0;
  uStack_188 = 0;
  uStack_180 = 0;
  uStack_170 = 0;
  uStack_150 = 0;
  cStack_14e = '\0';
  uStack_d8 = 0x4000000;
  lVar15 = *(longlong *)(*(longlong *)(param_1 + 0x10) + 0x58);
  uStack_204 = param_4;
  iStack_218 = param_3;
  pplStack_1e0 = param_2;
  if (((*(uint *)(lVar15 + 0x14) & 0xe0000000) != 0x80000000) ||
     (bVar6 = true, 0xff < *(ushort *)(lVar15 + 0x18))) {
    bVar6 = false;
  }
  uVar11 = 0x68;
  if (!bVar6) {
    uVar11 = 0x54;
  }
  if ((param_5 == 1) && ((*(uint *)(param_1 + 0x3c) & 0x10000) != 0)) {
    uStack_254 = 0;
    uStack_23a = 0;
    uStack_230 = 0;
    uStack_22e = 0;
    uStack_248 = 0;
    pbStack_250 = (byte *)((ulonglong)*(ushort *)(**param_2 + (0xfff - (longlong)param_3) * 2) +
                          **param_2);
    if ((*pbStack_250 & 1) == 0) {
      auStack_258[0] = 0;
      uStack_232 = 0;
      uStack_230 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010036e */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_250 & 0xe) * 4 + 0x101100) -
                0x121dc80))();
      return;
    }
    auStack_258[0] = 1;
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_250 & 0x1c) + 0x1010e0) *
                            4 + 0x1010d0) - 0x121dc80);
                    /* WARNING: Could not emulate address calculation at 0x001001ac */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
  uVar9 = *(ushort *)(*(longlong *)(param_1 + 0x50) + 0xc);
  uVar14 = uVar9 & 0xf;
  if ((uVar9 & 0xf) == 0) {
LAB_:
    *(undefined4 *)(*(longlong *)(param_1 + 0x50) + 0x10) = *(undefined4 *)(param_1 + 0x34);
    plVar17 = *(longlong **)(param_1 + 0x50);
    puVar18 = (undefined8 *)auStack_298;
  }
  else {
    if (uVar14 != 1) {
      if (uVar14 != 8) {
        uStack_278 = 0x129bba8;
        uStack_2a0 = 0x100b6f;
        (*_DAT_)(1,0x16a0a00,0x16a4378,0x852);
        goto LAB_;
      }
      goto LAB_;
    }
    lVar15 = *(longlong *)(*(longlong *)(param_1 + 0x10) + 0x58);
    if (((*(uint *)(lVar15 + 0x14) & 0xe0000000) == 0x80000000) &&
       (*(ushort *)(lVar15 + 0x18) < 0x100)) {
      plVar3 = *(longlong **)(param_1 + 0x50);
      plVar17 = &uStack_2e8;
      uStack_2e8 = *plVar3;
      uStack_2e0 = *(undefined4 *)(plVar3 + 1);
      uStack_2d8 = *(undefined4 *)(plVar3 + 2);
      uStack_2d4 = *(undefined4 *)(param_1 + 0x34);
      uStack_2dc = CONCAT22((short)((uint)*(undefined4 *)((longlong)plVar3 + 0xc) >> 0x10),6);
      uVar9 = *(ushort *)(plVar3 + 2);
      if (5 < uVar9) {
        auStack_308[0] = 0;
        (*_DAT_)(1,0x16d4a00,0x16a4378,0x792);
        uVar9 = *(ushort *)(plVar3 + 2);
      }
      uVar19 = 0;
      puVar18 = (undefined8 *)auStack_328;
      if (uVar9 != 0) {
        do {
          uVar12 = (ulonglong)uVar19;
          lVar15 = (ulonglong)uVar19 + 2;
          uVar19 = uVar19 + 1;
          (&uStack_2d0)[uVar12 * 2] = *(undefined8 *)((longlong)plVar3 + uVar12 * 0x10 + 0x14);
          *(undefined4 *)(plVar17 + lVar15 * 2) =
               *(undefined4 *)((longlong)plVar3 + uVar12 * 0x10 + 0x1c);
          *(undefined2 *)((longlong)&uStack_2e8 + lVar15 * 0x10 + 4) =
               *(undefined2 *)(plVar3 + uVar12 * 2 + 4);
          *(undefined2 *)((longlong)&uStack_2e8 + lVar15 * 0x10 + 6) =
               *(undefined2 *)((longlong)plVar3 + uVar12 * 0x10 + 0x22);
          puVar18 = (undefined8 *)auStack_328;
        } while (uVar19 < *(ushort *)(plVar3 + 2));
      }
    }
    else {
      puVar13 = *(undefined4 **)(param_1 + 0x50);
      plVar17 = &uStack_2c8;
      uStack_2c8._0_4_ = *puVar13;
      uStack_2c8._4_4_ = puVar13[1];
      uStack_2c0 = puVar13[2];
      uStack_2b8 = puVar13[4];
      uStack_2b4 = *(undefined4 *)(param_1 + 0x34);
      uStack_2bc = CONCAT22((short)((uint)puVar13[3] >> 0x10),5);
      uVar9 = *(ushort *)(puVar13 + 4);
      if (5 < uVar9) {
        uStack_2e8 = 0;
        uStack_310 = 0x100cab;
        (*_DAT_)(1,0x16d4a00,0x16a4378,0x767);
        uVar9 = *(ushort *)(puVar13 + 4);
      }
      puVar18 = auStack_308;
      uVar19 = 0;
      if (uVar9 != 0) {
        do {
          uVar12 = (ulonglong)uVar19;
          uVar20 = uVar19 + 1;
          auStack_2b0[uVar12 * 3] = puVar13[(ulonglong)uVar19 * 4 + 5];
          auStack_2b0[uVar12 * 3 + 1] = puVar13[(ulonglong)uVar19 * 4 + 7];
          auStack_2a8[uVar12 * 6] = *(undefined2 *)(puVar13 + (ulonglong)uVar19 * 4 + 8);
          auStack_2a8[uVar12 * 6 + 1] =
               *(undefined2 *)((longlong)puVar13 + (ulonglong)uVar19 * 0x10 + 0x22);
          puVar18 = auStack_308;
          uVar19 = uVar20;
        } while (uVar20 < *(ushort *)(puVar13 + 4));
      }
    }
  }
  lVar15 = *plVar17;
  uVar2 = *(undefined4 *)(plVar17 + 1);
  uVar1 = *(undefined2 *)((longlong)plVar17 + 0xc);
  uStack_1d8 = 0;
  uStack_1b2 = 0;
  uStack_1b0 = 0;
  plStack_1d0 = plVar17;
  *(undefined *)plVar17 = 8;
  lStack_220 = lVar15;
  *(undefined *)((longlong)plStack_1d0 + 1) = 0;
  *(short *)((longlong)plStack_1d0 + 2) = (short)uVar11;
  uStack_1c8 = CONCAT44(uVar11,uVar11);
  uStack_1bc = 0;
  *(undefined8 *)((longlong)puVar18 + -8) = 0x100d83;
  uStack_1d4 = uVar11;
  uStack_1c0 = uVar11;
  bVar8 = func_0x(param_1 + 8);
  bVar21 = 0;
  uStack_140 = *(undefined4 *)(param_1 + 0x58);
  uStack_13c = *(undefined4 *)(param_1 + 0x5c);
  uStack_138 = *(undefined4 *)(param_1 + 0x60);
  uStack_134 = *(undefined4 *)(param_1 + 100);
  lVar15 = *(longlong *)(param_1 + 0xa8);
  if (*(int *)(*(longlong *)(param_1 + 0x10) + 0x38) == 3) {
    bVar21 = 2;
  }
  bVar8 = (bVar21 | bVar8 & 1) * '\x02';
  bStack_120 = bVar8 | bStack_120 & 0xe0 | (byte)uStack_204 & 1;
  if (param_5 == 1) {
    puStack_160 = puStack_168;
    *puStack_168 = 0x4000000;
    puStack_158 = puStack_168 + 1;
    uStack_170 = 0;
    if ((*(byte *)(param_1 + 0x68) & 2) == 0) {
      if ((*(byte *)(param_1 + 0x94) & 1) != 0) {
        lVar16 = param_1 + 0x98;
        goto LAB_;
      }
    }
    else {
      lVar16 = param_1 + 0x44;
LAB_:
      *(undefined8 *)((longlong)puVar18 + -8) = 0x100e34;
      func_0x(param_1 + 8,lVar16,&uStack_198);
    }
    if ((bVar8 & 4) != 0) {
      *(undefined8 *)((longlong)puVar18 + 0x20) = 0x16d49d8;
      *(undefined8 *)((longlong)puVar18 + -8) = 0x100e65;
      (*_DAT_)(1,0x16d49c8,0x16a4378,0x87d);
    }
    pplVar7 = pplStack_1e0;
    lVar16 = **pplStack_1e0;
    *(undefined8 *)((longlong)puVar18 + -8) = 0x100e7c;
    func_0x(param_1 + 8,lVar16,iStack_218);
    uStack_118 = uStack_140;
    uStack_114 = uStack_13c;
    uStack_110 = uStack_138;
    uStack_10c = uStack_134;
    uStack_108 = CONCAT71(uStack_11f,bStack_120);
    if ((*(longlong *)(lVar15 + 8) == 0) ||
       (lVar16 = *(longlong *)(*(longlong *)(lVar15 + 8) + 8), *(char *)(lVar16 + 0x3f) != '\0')) {
      if (*(int *)(lVar15 + 0x40) == 2) {
        uStack_1fa = 0;
        uStack_200 = **(undefined4 **)(lVar15 + 0x30);
        puVar13 = &uStack_200;
        uStack_1fc = *(undefined2 *)(*(undefined4 **)(lVar15 + 0x30) + 1);
      }
      else {
        uStack_1f2 = 0;
        uStack_1f8 = **(undefined4 **)(lVar15 + 0x28);
        puVar13 = &uStack_1f8;
        uStack_1f4 = *(undefined2 *)(*(undefined4 **)(lVar15 + 0x28) + 1);
      }
      uStack_214 = *puVar13;
      uStack_210 = *(undefined2 *)(puVar13 + 1);
    }
    else {
      uStack_214 = *(undefined4 *)(lVar16 + 8);
      uStack_210 = *(undefined2 *)(lVar16 + 0xc);
    }
    lVar15 = *(longlong *)(param_1 + 0x10);
    uVar4 = *(undefined8 *)(param_1 + 8);
    *(undefined4 **)((longlong)puVar18 + 0x38) = &uStack_1d8;
    *(undefined4 **)((longlong)puVar18 + 0x30) = &uStack_118;
    *(int *)((longlong)puVar18 + 0x28) = iStack_218;
    uStack_20e = 0;
    uVar5 = *(undefined8 *)(lVar15 + 0x58);
    *(undefined4 **)((longlong)puVar18 + 0x20) = &uStack_198;
    *(undefined8 *)((longlong)puVar18 + -8) = 0x100f4d;
    iVar10 = func_0x(pplVar7,uVar5,&uStack_214,uVar4);
    if (iVar10 != 0) {
      *(undefined8 *)((longlong)puVar18 + 0x20) = 0;
      *(undefined8 *)((longlong)puVar18 + -8) = 0x100f75;
      (*_DAT_)(1,0x16d4368,0x16a4378,0x88a);
    }
    *(uint *)(param_1 + 0x68) = *(uint *)(param_1 + 0x68) & 0xfffffffd;
    *(uint *)(param_1 + 0x94) = *(uint *)(param_1 + 0x94) & 0xfffffffe;
  }
  else {
    *(undefined8 *)((longlong)puVar18 + -8) = 0x100f98;
    func_0x(param_1 + 8,param_6,&uStack_198);
    uStack_f8 = uStack_140;
    uStack_f4 = uStack_13c;
    uStack_f0 = uStack_138;
    uStack_ec = uStack_134;
    lStack_148 = (ulonglong)*(uint6 *)(*(longlong *)(lVar15 + 0x10) + 0x14) << 0x10;
    uStack_e8 = CONCAT71(uStack_11f,bStack_120);
    if ((*(longlong *)(lVar15 + 8) == 0) ||
       (lVar16 = *(longlong *)(*(longlong *)(lVar15 + 8) + 8), *(char *)(lVar16 + 0x3f) != '\0')) {
      if (*(int *)(lVar15 + 0x40) == 2) {
        uStack_1ea = 0;
        uStack_1f0 = **(undefined4 **)(lVar15 + 0x30);
        puVar13 = &uStack_1f0;
        uStack_1ec = *(undefined2 *)(*(undefined4 **)(lVar15 + 0x30) + 1);
      }
      else {
        uStack_1e2 = 0;
        uStack_1e8 = **(undefined4 **)(lVar15 + 0x28);
        puVar13 = &uStack_1e8;
        uStack_1e4 = *(undefined2 *)(*(undefined4 **)(lVar15 + 0x28) + 1);
      }
      uStack_20c = *puVar13;
      uStack_208 = *(undefined2 *)(puVar13 + 1);
    }
    else {
      uStack_20c = *(undefined4 *)(lVar16 + 8);
      uStack_208 = *(undefined2 *)(lVar16 + 0xc);
    }
    uVar4 = *(undefined8 *)(param_1 + 8);
    *(undefined4 **)((longlong)puVar18 + 0x38) = &uStack_1d8;
    *(undefined4 **)((longlong)puVar18 + 0x30) = &uStack_f8;
    *(int *)((longlong)puVar18 + 0x28) = iStack_218;
    uStack_206 = 0;
    *(undefined4 **)((longlong)puVar18 + 0x20) = &uStack_198;
    *(undefined8 *)((longlong)puVar18 + -8) = 0x101084;
    func_0x(pplStack_1e0,&lStack_148,&uStack_20c,uVar4);
  }
  *plVar17 = lStack_220;
  *(undefined4 *)(plVar17 + 1) = uVar2;
  *(undefined2 *)((longlong)plVar17 + 0xc) = uVar1;
  if (cStack_14e != '\0') {
    *(undefined *)(*(longlong *)(param_1 + 0x10) + 0x188) = 0;
  }
LAB_:
  *(undefined8 *)((longlong)puVar18 + -8) = 0x1010b9;
  func_0x(uStack_58 ^ (ulonglong)auStack_258);
  return;
}

