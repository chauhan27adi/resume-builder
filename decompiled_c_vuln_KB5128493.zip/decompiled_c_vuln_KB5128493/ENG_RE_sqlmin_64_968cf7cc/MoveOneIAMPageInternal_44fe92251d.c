
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(int *param_1,undefined8 param_2,int *param_3,ulonglong *param_4,undefined4 param_5
                 ,longlong param_6,longlong **param_7,longlong **param_8)

{
  byte *pbVar1;
  byte *pbVar2;
  longlong lVar3;
  bool bVar4;
  int *piVar5;
  undefined8 uVar6;
  char cVar7;
  short sVar8;
  short sVar9;
  int iVar10;
  int iVar11;
  longlong lVar12;
  short *psVar13;
  ulonglong *puVar14;
  byte bVar15;
  ushort uVar16;
  undefined4 uVar17;
  ushort uVar18;
  uint uVar19;
  uint uVar20;
  byte **ppbVar21;
  byte **ppbVar22;
  ulonglong uVar23;
  byte **ppbVar24;
  longlong *plVar25;
  ushort *puVar26;
  uint uVar27;
  ulonglong uVar28;
  undefined4 uVar29;
  uint uVar30;
  uint uVar31;
  longlong unaff_GS_OFFSET;
  undefined auStack_2c8 [32];
  undefined8 uStack_2a8;
  undefined8 uStack_2a0;
  undefined8 uStack_298;
  byte *pbStack_290;
  undefined8 uStack_288;
  undefined8 uStack_280;
  ulonglong *puStack_278;
  longlong **pplStack_270;
  undefined4 uStack_268;
  undefined8 uStack_260;
  undefined4 uStack_258;
  undefined4 uStack_250;
  undefined8 uStack_248;
  undefined8 uStack_240;
  int iStack_238;
  undefined2 uStack_234;
  uint uStack_230;
  int iStack_22c;
  short sStack_228;
  int iStack_224;
  short sStack_220;
  longlong *plStack_218;
  undefined uStack_210;
  uint uStack_20c;
  longlong *plStack_200;
  undefined uStack_1f8;
  uint uStack_1f4;
  undefined8 uStack_1e8;
  int *piStack_1e0;
  ulonglong uStack_1d8;
  undefined4 uStack_1d0;
  undefined8 uStack_1c8;
  undefined2 uStack_1c0;
  undefined8 uStack_1b8;
  undefined2 uStack_1b0;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined2 uStack_1a0;
  int iStack_19c;
  short sStack_198;
  int iStack_194;
  short sStack_190;
  undefined4 uStack_18c;
  undefined2 uStack_188;
  int iStack_184;
  undefined2 uStack_180;
  int iStack_17c;
  undefined2 uStack_178;
  int iStack_170;
  undefined2 uStack_16c;
  undefined2 uStack_16a;
  ulonglong *puStack_168;
  ulonglong uStack_160;
  undefined8 uStack_158;
  ulonglong uStack_150;
  undefined4 uStack_148;
  undefined2 uStack_144;
  undefined4 uStack_140;
  undefined2 uStack_13c;
  longlong **pplStack_138;
  longlong **pplStack_130;
  int *piStack_128;
  undefined8 uStack_120;
  undefined auStack_118 [4];
  undefined auStack_114 [4];
  undefined auStack_110 [4];
  undefined auStack_10c [4];
  undefined auStack_108 [8];
  longlong lStack_100;
  undefined8 uStack_f8;
  short sStack_f0;
  ushort uStack_ee;
  uint uStack_ec;
  byte *pbStack_e8;
  undefined8 uStack_e0;
  undefined4 uStack_d8;
  ushort uStack_d4;
  undefined2 uStack_d2;
  undefined6 uStack_d0;
  undefined2 uStack_ca;
  undefined2 uStack_c8;
  undefined2 uStack_c6;
  ushort uStack_c4;
  undefined2 uStack_c2;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined auStack_b8 [16];
  undefined auStack_a8 [8];
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined6 uStack_88;
  undefined2 uStack_82;
  undefined8 uStack_80;
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  undefined8 uStack_48;
  ulonglong uStack_40;
  
  uStack_f8 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_2c8;
  lStack_100 = param_6;
  pplStack_138 = param_7;
  pplStack_130 = param_8;
  sStack_f0 = -1;
  ppbVar24 = (byte **)0x0;
  pbStack_e8 = (byte *)0x0;
  uStack_ec = 0;
  uStack_d2 = 0;
  uStack_d0 = 0;
  uStack_c8 = 0;
  uStack_c6 = 0;
  uStack_c4 = 0;
  uStack_c2 = 0;
  uStack_e0 = (byte **)0x0;
  uVar28 = param_4[6];
  uStack_1a8 = 0;
  uStack_1d8 = 0;
  if (param_6 != 0) {
    uStack_1d8 = *(ulonglong *)(param_6 + 0x14) & 0xffffffffffff;
  }
  piStack_1e0 = param_1;
  puStack_168 = param_4;
  uStack_160 = uVar28;
  piStack_128 = param_3;
  lVar12 = func_0x(*(undefined8 *)(uVar28 + 0x6a0),*(undefined2 *)(param_3 + 1),0);
  func_0x(param_7,param_3,2,uVar28);
  plVar25 = *param_7;
  lVar3 = *plVar25;
  uStack_1a4 = *(undefined4 *)((ulonglong)*(ushort *)(lVar3 + 0x1ffe) + 0x28 + lVar3);
  uStack_1a0 = *(undefined2 *)((ulonglong)*(ushort *)(lVar3 + 0x1ffe) + 0x2c + lVar3);
  if (*param_1 == *(int *)(lVar3 + 0x18)) {
    sVar9 = 0;
    if (*(short *)(param_1 + 1) != 1) {
      sVar9 = *(short *)(param_1 + 1);
    }
    sVar8 = 0;
    if (*(short *)(lVar3 + 6) != 1) {
      sVar8 = *(short *)(lVar3 + 6);
    }
    if (sVar9 == sVar8) {
      if (((*(ushort *)((longlong)plVar25 + 0x62) & 0x400) == 0) ||
         (*(short *)((longlong)param_7 + 0xc) < 3)) {
        iVar10 = (int)*(short *)((longlong)param_7 + 0xc);
        plVar25 = *param_7;
        if ((((byte)*(undefined2 *)((longlong)plVar25 + 0x62) >> 3 & 1) != 0) &&
           ((((iVar11 = 4, iVar10 == 3 || (iVar11 = iVar10, 1 < iVar10)) &&
             (iVar10 = iVar11, (*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
            ((lVar3 = plVar25[0x12], lVar3 != 0 && (*(longlong *)(lVar3 + 0x758) != 0)))))) {
          func_0x(*(undefined8 *)(lVar3 + 0x758),plVar25,iVar10);
        }
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
           ((2 < iVar10 &&
            ((((*(uint *)((longlong)plVar25 + 100) & 0xc0000000) != 0x40000000 && (*plVar25 != 0))
             && (iVar11 = (*_DAT_)(*plVar25,0x2000,2,auStack_118), iVar11 != 0)))))) {
          LOCK();
          *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar25 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar25,0,iVar10);
        }
        *(undefined2 *)((longlong)param_7 + 0xc) = 0;
        *param_7 = (longlong *)0x0;
        param_1 = piStack_1e0;
      }
      else {
        func_0x(param_7);
      }
      puVar14 = puStack_168;
      iStack_170 = *param_1;
      uStack_16c = *(undefined2 *)(param_1 + 1);
      uStack_16a = 0;
      pplStack_270 = param_8;
      puStack_278 = (ulonglong *)0x0;
      uStack_280 = (undefined4 *)CONCAT44(uStack_280._4_4_,1);
      uStack_288 = &uStack_1a4;
      uStack_298 = &uStack_1d8;
      uStack_2a0 = &iStack_170;
      uStack_2a8 = (undefined8 *)CONCAT62(uStack_2a8._2_6_,*(undefined2 *)(lVar12 + 0x84));
      iVar10 = func_0x(puStack_168,puStack_168,param_5,0);
      if (iVar10 == 0) goto LAB_;
      plVar25 = *param_8;
      iStack_238 = *(int *)(plVar25 + 0xe);
      uStack_234 = *(undefined2 *)((longlong)plVar25 + 0x74);
      if (plVar25 != (longlong *)0x0) {
        if (((*(ushort *)((longlong)plVar25 + 0x62) & 0x400) == 0) ||
           (*(short *)((longlong)param_8 + 0xc) < 3)) {
          iVar10 = (int)*(short *)((longlong)param_8 + 0xc);
          plVar25 = *param_8;
          if (((((byte)*(undefined2 *)((longlong)plVar25 + 0x62) >> 3 & 1) != 0) &&
              (((iVar11 = 4, iVar10 == 3 || (iVar11 = iVar10, 1 < iVar10)) &&
               (iVar10 = iVar11, (*(uint *)((longlong)plVar25 + 100) & 8) != 0)))) &&
             ((lVar3 = plVar25[0x12], lVar3 != 0 && (*(longlong *)(lVar3 + 0x758) != 0)))) {
            func_0x(*(undefined8 *)(lVar3 + 0x758),plVar25,iVar10);
          }
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
             ((2 < iVar10 &&
              ((((*(uint *)((longlong)plVar25 + 100) & 0xc0000000) != 0x40000000 && (*plVar25 != 0))
               && (iVar11 = (*_DAT_)(*plVar25,0x2000,2,auStack_114), iVar11 != 0)))))) {
            LOCK();
            *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) | 0x40000000;
            UNLOCK();
          }
          func_0x(plVar25 + 0x13,iVar10);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(plVar25,0,iVar10);
          }
          *(undefined2 *)((longlong)param_8 + 0xc) = 0;
          *param_8 = (longlong *)0x0;
        }
        else {
          func_0x(param_8);
        }
      }
      piVar5 = piStack_128;
      uVar28 = uStack_160;
      func_0x(param_7,piStack_128,4,uStack_160);
      if ((*piVar5 != *(int *)(**param_7 + 0x20)) ||
         (*(short *)(piVar5 + 1) != *(short *)(**param_7 + 0x24))) {
        uStack_2a8 = (undefined8 *)0x0;
        (*_DAT_)(1,0x172f4d0,0x16ff910,0x7e4);
      }
      func_0x(param_8,&iStack_238,4,uVar28);
      piVar5 = piStack_1e0;
      plVar25 = *param_7;
      iStack_224 = *(int *)(*plVar25 + 8);
      sStack_220 = *(short *)(*plVar25 + 0xc);
      if ((iStack_224 != 0) || (sStack_220 != 0)) {
        uStack_298 = puVar14;
        uStack_2a0 = (int *)((ulonglong)uStack_2a0 & 0xffffffff00000000);
        uStack_2a8 = (undefined8 *)&iStack_19c;
        iStack_19c = iStack_224;
        sStack_198 = sStack_220;
        func_0x(param_8,piStack_1e0,8);
        plVar25 = *param_7;
      }
      iStack_22c = *(int *)(*plVar25 + 0x10);
      sStack_228 = *(short *)(*plVar25 + 0x14);
      if ((iStack_22c != 0) || (sStack_228 != 0)) {
        uStack_298 = puVar14;
        uStack_2a0 = (int *)((ulonglong)uStack_2a0 & 0xffffffff00000000);
        uStack_2a8 = (undefined8 *)&iStack_194;
        iStack_194 = iStack_22c;
        sStack_190 = sStack_228;
        func_0x(param_8,piVar5,0x10);
        plVar25 = *param_7;
      }
      lVar3 = *plVar25;
      uStack_bc = 0;
      uStack_230 = 9;
      uVar29 = 0xf;
      ppbVar21 = (byte **)0xf;
      uVar30 = 0xf;
      uVar31 = 0;
      ppbVar22 = ppbVar24;
      if (*(char *)(lVar3 + 2) < '\0') {
        pbVar1 = (byte *)(lVar3 + 0x60);
        if ((sStack_f0 == 0) || (ppbVar22 = uStack_e0, uStack_e0 == (byte **)0x0)) {
          uStack_90 = 0;
          uStack_82 = 0;
          auStack_68 = ZEXT816(0);
          auStack_b8 = ZEXT816(0);
          stack0xffffffffffffff5a = SUB1614(ZEXT816(0),2);
          auStack_a8._0_2_ = 0xffff;
          uStack_a0 = 0;
          uStack_8a = 0;
          uStack_88 = 0;
          uStack_80 = 0;
          uStack_98 = 0;
          auStack_78 = ZEXT816(0);
          auStack_58._0_12_ = ZEXT812(0);
          auStack_58._12_4_ = 0;
          uStack_48 = 0;
          ppbVar22 = (byte **)auStack_b8;
        }
        if (*(short *)(lVar3 + 0x24) == 0) {
LAB_:
          uStack_1c8 = *(undefined8 *)(lVar3 + 0x28);
          uStack_1c0 = *(undefined2 *)(lVar3 + 0x30);
        }
        else {
          cVar7 = *(char *)(lVar3 + 1);
          if (cVar7 == '\v') {
            if (*(int *)(lVar3 + 0x18) != 99) {
LAB_:
              if (cVar7 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar7 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar3 + 0x18) != 99) goto LAB_;
          }
          uStack_140 = *(undefined4 *)(lVar3 + 0x20);
          uStack_13c = *(undefined2 *)(lVar3 + 0x24);
          cVar7 = func_0x(&uStack_140);
          if (cVar7 == '\0') goto LAB_;
          func_0x(lVar3,&uStack_1c8);
        }
        *ppbVar22 = pbVar1;
        *(undefined4 *)(ppbVar22 + 0xc) = (undefined4)uStack_1c8;
        *(int *)((longlong)ppbVar22 + 100) = (int)((ulonglong)uStack_1c8 >> 0x20);
        *(undefined2 *)(ppbVar22 + 0xd) = uStack_1c0;
        *(undefined4 *)((longlong)ppbVar22 + 0x6c) = *(undefined4 *)(lVar3 + 0x20);
        *(undefined2 *)(ppbVar22 + 0xe) = *(undefined2 *)(lVar3 + 0x24);
        *(undefined2 *)((longlong)ppbVar22 + 0x72) = 0;
        uStack_1d0 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1377a70);
        uVar28 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1377a74);
        *(undefined2 *)(ppbVar22 + 2) = 0xffff;
        ppbVar22[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
        ppbVar22[7] = (byte *)0x0;
        ppbVar22[4] = (byte *)0x0;
        ppbVar22[9] = (byte *)0x0;
        ppbVar22[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar22 + 0xb) = 0;
        if ((**ppbVar22 & 2) != 0) {
          pbVar2 = pbVar1 + uVar28;
          if ((*pbVar2 & 1) == 0) {
            *(undefined2 *)(ppbVar22 + 2) = 0;
            ppbVar22[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar22 + 0x36) = 0;
            uVar19 = uVar31;
            switch(*pbVar2 & 0xe) {
            default:
              uVar19 = (uint)*(ushort *)(pbVar2 + 2);
              if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
                func_0x(pbVar2,6);
              }
              break;
            case 4:
              uVar19 = 9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar19 = 1;
            }
            *(uint *)(ppbVar22 + 4) = uVar19;
            *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
          }
          else {
            *(undefined2 *)(ppbVar22 + 2) = 1;
            ppbVar22[3] = pbVar2;
            bVar15 = *pbVar2;
            switch(bVar15 & 0x1c) {
            default:
              if ((char)pbVar2[1] < '\0') {
                uVar16 = *(ushort *)(pbVar2 + 1);
                *(ushort *)((longlong)ppbVar22 + 0x12) = uVar16;
                sVar9 = 3;
                uVar16 = (uVar16 & 0x7f) << 8 | uVar16 >> 8;
              }
              else {
                sVar9 = 2;
                uVar16 = (ushort)pbVar2[1];
              }
              *(ushort *)((longlong)ppbVar22 + 0x12) = uVar16;
              *(short *)(ppbVar22 + 5) = sVar9;
              uVar16 = *(ushort *)((longlong)ppbVar22 + 0x12);
              *(short *)((longlong)ppbVar22 + 0x2c) = (short)(uVar16 + 1 >> 1) + sVar9;
              if (uVar16 < 0x1f) {
                *(undefined2 *)((longlong)ppbVar22 + 0x2a) = 0;
                *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
                *(undefined4 *)(ppbVar22 + 8) = 0;
                ppbVar22[7] = (byte *)0x0;
                ppbVar22[4] = (byte *)0x0;
              }
              else {
                iVar10 = uVar16 - 1;
                *(short *)((longlong)ppbVar22 + 0x2a) =
                     ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                     (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
                *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
                *(undefined4 *)(ppbVar22 + 8) = 0;
                ppbVar22[7] = (byte *)0x0;
                ppbVar22[4] = (byte *)0x0;
              }
              break;
            case 4:
              if (((bVar15 & 0x1c) != 4) || (bVar4 = true, (bVar15 & 2) == 0)) {
                bVar4 = false;
              }
              if (!bVar4) {
                uVar17 = 1;
              }
              else {
                *(undefined4 *)(ppbVar22 + 8) = 0;
                uVar17 = uVar29;
              }
              ppbVar22[5] = (byte *)0x0;
              *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
              ppbVar22[6] = (byte *)0x0;
              ppbVar22[4] = (byte *)0x0;
              ppbVar22[7] = (byte *)0x0;
              ppbVar22[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar22 + 0x14) = uVar17;
              *(uint *)(ppbVar22 + 8) = (uint)bVar4;
              ppbVar22[7] = (byte *)0x0;
              ppbVar22[4] = (byte *)0x0;
              break;
            case 8:
              ppbVar22[5] = (byte *)0x0;
              *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
              ppbVar22[6] = (byte *)0x0;
              ppbVar22[4] = (byte *)0x0;
              ppbVar22[7] = (byte *)0x0;
              ppbVar22[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar22 + 0x14) = 9;
              *(undefined4 *)(ppbVar22 + 8) = 0;
              ppbVar22[7] = (byte *)0x0;
              ppbVar22[4] = (byte *)0x0;
            }
          }
        }
        if ((**ppbVar22 & 4) != 0) {
          if (uStack_1d0._2_2_ != 0) {
            uVar28 = (ulonglong)*(ushort *)(lVar3 + 0x61 + (longlong)uStack_1d0._2_2_ * 2);
          }
          psVar13 = (short *)(pbVar1 + uVar28);
          ppbVar22[9] = (byte *)psVar13;
          sVar9 = *psVar13;
          ppbVar22[10] = (byte *)(psVar13 + 1);
          *(short *)(ppbVar22 + 0xb) = (sVar9 + 1) * 2;
        }
        param_7 = pplStack_138;
        if (ppbVar22[1] != (byte *)0x0) {
          func_0x(ppbVar22[1],ppbVar22);
          param_7 = pplStack_138;
        }
      }
      uVar19 = (uint)*(ushort *)(lVar3 + 0xe);
      pbStack_e8 = (byte *)((ulonglong)*(ushort *)(lVar3 + 0x1ffe) + lVar3);
      if ((*pbStack_e8 & 1) == 0) {
        sStack_f0 = 0;
        ppbVar22 = (byte **)0x0;
        uStack_ec = 0;
        uStack_ca = 0;
        uStack_c8 = 0;
        ppbVar21 = ppbVar24;
        switch(*pbStack_e8 & 0xe) {
        default:
          uVar19 = (uint)*(ushort *)(pbStack_e8 + 2);
          ppbVar21 = ppbVar22;
          if (0x1f9d < *(ushort *)(pbStack_e8 + 2) - 1) {
            func_0x(pbStack_e8,6);
            ppbVar21 = (byte **)(ulonglong)uStack_ec;
          }
          break;
        case 4:
          uVar19 = 9;
          ppbVar21 = ppbVar22;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar19 = 1;
          ppbVar21 = ppbVar22;
        }
        uStack_e0 = (byte **)CONCAT44(uStack_e0._4_4_,uVar19);
        uStack_d2 = (undefined2)(lVar3 + 0x2000);
        uStack_d0 = (undefined6)((ulonglong)(lVar3 + 0x2000) >> 0x10);
        ppbVar22 = (byte **)(ulonglong)uVar19;
      }
      else {
        sStack_f0 = 1;
        bVar15 = *pbStack_e8;
        switch(bVar15 & 0x1c) {
        default:
          if ((char)pbStack_e8[1] < '\0') {
            uStack_ee = (*(ushort *)(pbStack_e8 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_e8 + 1) >> 8
            ;
            uStack_d8._0_2_ = 3;
            sVar9 = 3;
          }
          else {
            uStack_ee = (ushort)pbStack_e8[1];
            uStack_d8._0_2_ = 2;
            sVar9 = 2;
          }
          uStack_d4 = (short)(uStack_ee + 1 >> 1) + sVar9;
          if (uStack_ee < 0x1f) {
            uStack_d8._2_2_ = 0;
            uStack_ec = 0;
            uStack_c0 = 0;
            ppbVar21 = ppbVar24;
          }
          else {
            iVar10 = uStack_ee - 1;
            uStack_d8._2_2_ =
                 ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                 (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
            ppbVar21 = (byte **)0x0;
            uStack_ec = 0;
            uStack_c0 = 0;
          }
          break;
        case 4:
          if (((bVar15 & 0x1c) == 4) && ((bVar15 & 2) != 0)) {
            uStack_d8._0_2_ = 0;
            uStack_d8._2_2_ = 0;
            uStack_d4 = 0;
            uStack_d2 = 0;
            uStack_ee = 0;
            uStack_d0 = 0;
            uStack_ca = 0;
            uStack_ec = 0xf;
            uStack_c0 = 1;
          }
          else {
            uStack_d8._0_2_ = 0;
            uStack_d8._2_2_ = 0;
            uStack_d4 = 0;
            uStack_d2 = 0;
            uStack_ee = 0;
            uStack_d0 = 0;
            uStack_ca = 0;
            ppbVar21 = (byte **)0x1;
            uStack_ec = 1;
            uStack_c0 = 0;
          }
          break;
        case 8:
          uStack_d8._0_2_ = 0;
          uStack_d8._2_2_ = 0;
          uStack_d4 = 0;
          uStack_d2 = 0;
          uStack_ee = 0;
          uStack_d0 = 0;
          uStack_ca = 0;
          ppbVar21 = (byte **)0x9;
          uStack_ec = 9;
          uStack_c0 = 0;
        }
        lVar3 = lVar3 + 0x2000;
        uStack_c8 = (undefined2)lVar3;
        uStack_c6 = (undefined2)((ulonglong)lVar3 >> 0x10);
        uStack_c4 = (ushort)((ulonglong)lVar3 >> 0x20);
        uStack_c2 = (undefined2)((ulonglong)lVar3 >> 0x30);
        uStack_e0 = ppbVar22;
      }
      if (sStack_f0 == 0) {
        uVar19 = CONCAT22(uStack_d8._2_2_,(undefined2)uStack_d8);
        if ((int)ppbVar21 == 0) {
          uStack_ee = 0;
          uVar19 = (uint)ppbVar22;
          ppbVar21 = (byte **)((ulonglong)ppbVar22 & 0xffffffff);
          if ((*pbStack_e8 & 0x10) != 0) {
            uVar19 = uVar19 + 2 +
                     (*(ushort *)(pbStack_e8 + ((ulonglong)ppbVar22 & 0xffffffff)) + 7 >> 3);
            ppbVar21 = (byte **)(ulonglong)uVar19;
          }
          uStack_e0 = (byte **)CONCAT44(uVar19,(uint)uStack_e0);
          uVar19 = (uint)ppbVar21;
          if ((*pbStack_e8 & 0x20) == 0) {
            uStack_d4 = 0;
            uStack_ec = uVar19;
          }
          else {
            puVar26 = (ushort *)((longlong)ppbVar21 + (longlong)pbStack_e8);
            uStack_d4 = *puVar26;
            if (uStack_d4 == 0) {
              if ((((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                  (lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0)) &&
                 ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                  (*(char *)(lVar3 + 0x499) != '\0')))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x80f);
                }
              }
              func_0x(pbStack_e8,3);
            }
            uStack_d8 = uStack_e0._4_4_ + 2 + (uint)uStack_d4 * 2;
            if (0x1f9e < uStack_d8) {
              if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                 ((lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                  ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                   (*(char *)(lVar3 + 0x499) != '\0')))))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x816);
                }
              }
              func_0x(pbStack_e8,4);
            }
            uVar28 = (ulonglong)uStack_d4;
            uStack_ec = puVar26[uVar28] & 0x7fff;
            ppbVar21 = (byte **)(ulonglong)uStack_ec;
            uVar19 = uStack_d8;
            if (uStack_ec < uStack_d8) {
              if ((((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                  (lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0)) &&
                 ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                  (*(char *)(lVar3 + 0x499) != '\0')))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x81d);
                }
              }
              func_0x(pbStack_e8,4);
              uVar28 = (ulonglong)uStack_d4;
              ppbVar21 = (byte **)(ulonglong)uStack_ec;
              uVar19 = uStack_d8;
            }
            do {
              if (-1 < (short)puVar26[(ulonglong)((int)uVar28 - 1) + 1]) break;
              uVar20 = uStack_d8;
              if ((int)uVar28 != 1) {
                uVar20 = *(ushort *)(pbStack_e8 + uVar28 * 2 + (((ulonglong)uStack_e0 >> 0x20) - 2))
                         & 0x7fff;
              }
              if ((uVar20 < uStack_d8) ||
                 ((*(ushort *)(pbStack_e8 + uVar28 * 2 + ((ulonglong)uStack_e0 >> 0x20)) & 0x7fff) <
                  uVar20)) {
                uStack_d8 = uVar19;
                func_0x(pbStack_e8,7);
                uVar28 = (ulonglong)uStack_d4;
                ppbVar21 = (byte **)(ulonglong)uStack_ec;
                uVar19 = uStack_d8;
              }
              if ((uVar20 < uStack_d8) || ((uint)ppbVar21 < uVar20)) goto code_r0x0010124a;
              if (*(ushort *)(pbStack_e8 + uVar20) == 5) {
                uStack_ee = uStack_ee | 2;
                uStack_d4 = (short)uVar28 - 1;
                uStack_c6 = (undefined2)uVar20;
                if ((*(ushort *)(pbStack_e8 + (ulonglong)(uVar20 & 0xffff) + 2) & 0x4000) == 0) {
                  uStack_c4 = uStack_c4 & 0xc7ff;
                }
                else {
                  uStack_c4 = uStack_c4 ^
                              (uStack_c4 ^
                              *(ushort *)(pbStack_e8 + (ulonglong)(uVar20 & 0xffff) + 2)) & 0x3800;
                }
                uStack_c4 = (uStack_c4 ^ *(ushort *)(pbStack_e8 + (ulonglong)(uVar20 & 0xffff) + 2))
                            & 0x7ff ^ uStack_c4;
                break;
              }
              if (*(ushort *)(pbStack_e8 + uVar20) < 0x400) break;
              uStack_ee = uStack_ee | 1;
              uStack_d4 = (short)uVar28 - 1;
              uVar28 = (ulonglong)uStack_d4;
            } while (uStack_d4 != 0);
          }
          if ((*pbStack_e8 & 0x40) == 0) {
            uStack_ca = 0;
            uStack_c8 = 0;
          }
          else {
            uStack_ca = SUB82(ppbVar21,0);
            uStack_c8 = (undefined2)((ulonglong)ppbVar21 >> 0x10);
            uStack_ec = (int)ppbVar21 + 0xe;
            uStack_d8 = uVar19;
            puVar14 = (ulonglong *)func_0x(&uStack_ee);
            uVar28 = *puVar14;
            uVar18 = (ushort)(uVar28 >> 0x30);
            uVar16 = uVar18;
            if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
              uVar16 = uVar18 & 0xdfff;
              if ((uVar28 & 0x4000000000000000) != 0) {
                uVar16 = uVar18 | 0x2000;
              }
            }
            uVar19 = uVar31;
            if (uVar16 == 0xfffc) {
              uVar19 = (uint)((uVar28 >> 0x20 & 0xffff) >> 5);
            }
            uStack_ec = uStack_ec + uVar19;
            ppbVar21 = (byte **)(ulonglong)uStack_ec;
            uVar19 = uStack_d8;
          }
          uStack_d8 = uVar19;
          if (((byte *)CONCAT62(uStack_d0,uStack_d2) != (byte *)0x0) &&
             ((byte *)CONCAT62(uStack_d0,uStack_d2) <
              (byte *)((longlong)ppbVar21 + (longlong)pbStack_e8))) {
            if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
               (((lVar3 = *(longlong *)
                           ((ulonglong)*puRam00000000011f8df0 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                 (lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0)) &&
                (*(char *)(lVar3 + 0x499) != '\0')))) {
              if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_2a8 = (undefined8 *)0x0;
                (*_DAT_)(1,0x157af88,0x169ac58,0x877);
              }
            }
            func_0x(pbStack_e8,0x12);
            ppbVar21 = (byte **)(ulonglong)uStack_ec;
          }
          uVar19 = uStack_d8;
          if (0x3f3b < (int)ppbVar21 - 1U) {
            if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
               ((lVar3 = *(longlong *)
                          ((ulonglong)*puRam00000000011f8df0 +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                 (*(char *)(lVar3 + 0x499) != '\0')))))) {
              if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_2a8 = (undefined8 *)0x0;
                (*_DAT_)(1,0x157af88,0x169ac58,0x87c);
              }
            }
            func_0x(pbStack_e8,5);
            ppbVar21 = (byte **)(ulonglong)uStack_ec;
            uVar19 = uStack_d8;
          }
        }
code_r0x0010124a:
        if (8 < (uint)ppbVar21) goto code_r0x0010129a;
        bVar15 = *pbStack_e8 & 0xe;
joined_r0x0010128b:
        if ((bVar15 != 0) && (bVar15 != 0xc)) goto code_r0x0010129a;
        uVar17 = 9;
      }
      else {
        if ((int)ppbVar21 == 0) {
          func_0x(&uStack_ee);
          ppbVar21 = (byte **)(ulonglong)uStack_ec;
        }
        uVar19 = CONCAT22(uStack_d8._2_2_,(undefined2)uStack_d8);
        if ((uint)ppbVar21 < 9) {
          bVar15 = *pbStack_e8 & 0x1c;
          goto joined_r0x0010128b;
        }
code_r0x0010129a:
        uVar17 = SUB84(ppbVar21,0);
      }
      uVar20 = (uint)ppbVar21;
      uStack_d8 = uVar19;
      if (sStack_f0 == 0) {
        if (uVar20 == 0) {
          uStack_ee = 0;
          ppbVar21 = (byte **)((ulonglong)uStack_e0 & 0xffffffff);
          uVar19 = (uint)uStack_e0;
          if ((*pbStack_e8 & 0x10) != 0) {
            uVar19 = (uint)uStack_e0 + 2 +
                     (*(ushort *)((longlong)ppbVar21 + (longlong)pbStack_e8) + 7 >> 3);
            ppbVar21 = (byte **)(ulonglong)uVar19;
          }
          uStack_e0 = (byte **)CONCAT44(uVar19,(uint)uStack_e0);
          uVar19 = (uint)ppbVar21;
          if ((*pbStack_e8 & 0x20) == 0) {
            uStack_d4 = 0;
            uStack_ec = uVar19;
          }
          else {
            puVar26 = (ushort *)((longlong)ppbVar21 + (longlong)pbStack_e8);
            uStack_d4 = *puVar26;
            if (uStack_d4 == 0) {
              if ((((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                  (lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0)) &&
                 ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                  (*(char *)(lVar3 + 0x499) != '\0')))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x80f);
                }
              }
              func_0x(pbStack_e8,3);
            }
            uStack_d8 = uStack_e0._4_4_ + 2 + (uint)uStack_d4 * 2;
            if (0x1f9e < uStack_d8) {
              if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                 ((lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                  ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                   (*(char *)(lVar3 + 0x499) != '\0')))))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x816);
                }
              }
              func_0x(pbStack_e8,4);
            }
            uVar28 = (ulonglong)uStack_d4;
            uStack_ec = puVar26[uVar28] & 0x7fff;
            if (uStack_ec < uStack_d8) {
              if ((((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                  (lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0)) &&
                 ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                  (*(char *)(lVar3 + 0x499) != '\0')))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x81d);
                }
              }
              func_0x(pbStack_e8,4);
              uVar28 = (ulonglong)uStack_d4;
            }
            ppbVar21 = (byte **)(ulonglong)uStack_ec;
            uVar19 = uStack_d8;
            do {
              if (-1 < (short)puVar26[(ulonglong)((int)uVar28 - 1) + 1]) break;
              uVar20 = uStack_d8;
              if ((int)uVar28 != 1) {
                uVar20 = *(ushort *)(pbStack_e8 + uVar28 * 2 + (((ulonglong)uStack_e0 >> 0x20) - 2))
                         & 0x7fff;
              }
              if ((uVar20 < uStack_d8) ||
                 ((*(ushort *)(pbStack_e8 + uVar28 * 2 + ((ulonglong)uStack_e0 >> 0x20)) & 0x7fff) <
                  uVar20)) {
                uStack_d8 = uVar19;
                func_0x(pbStack_e8,7);
                uVar28 = (ulonglong)uStack_d4;
                ppbVar21 = (byte **)(ulonglong)uStack_ec;
                uVar19 = uStack_d8;
              }
              if ((uVar20 < uStack_d8) || ((uint)ppbVar21 < uVar20)) goto code_r0x00101913;
              if (*(ushort *)(pbStack_e8 + uVar20) == 5) {
                uStack_ee = uStack_ee | 2;
                uStack_d4 = (short)uVar28 - 1;
                uStack_c6 = (undefined2)uVar20;
                if ((*(ushort *)(pbStack_e8 + (ulonglong)(uVar20 & 0xffff) + 2) & 0x4000) == 0) {
                  uStack_c4 = uStack_c4 & 0xc7ff;
                }
                else {
                  uStack_c4 = uStack_c4 ^
                              (*(ushort *)(pbStack_e8 + (ulonglong)(uVar20 & 0xffff) + 2) ^
                              uStack_c4) & 0x3800;
                }
                uStack_c4 = (uStack_c4 ^ *(ushort *)(pbStack_e8 + (ulonglong)(uVar20 & 0xffff) + 2))
                            & 0x7ff ^ uStack_c4;
                break;
              }
              if (*(ushort *)(pbStack_e8 + uVar20) < 0x400) break;
              uStack_ee = uStack_ee | 1;
              uStack_d4 = (short)uVar28 - 1;
              uVar28 = (ulonglong)uStack_d4;
            } while (uStack_d4 != 0);
          }
          if ((*pbStack_e8 & 0x40) == 0) {
            uStack_ca = 0;
            uStack_c8 = 0;
          }
          else {
            uStack_ca = SUB82(ppbVar21,0);
            uStack_c8 = (undefined2)((ulonglong)ppbVar21 >> 0x10);
            uStack_ec = (int)ppbVar21 + 0xe;
            uStack_d8 = uVar19;
            puVar14 = (ulonglong *)func_0x(&uStack_ee);
            uVar28 = *puVar14;
            uVar18 = (ushort)(uVar28 >> 0x30);
            uVar16 = uVar18;
            if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
              uVar16 = uVar18 & 0xdfff;
              if ((uVar28 & 0x4000000000000000) != 0) {
                uVar16 = uVar18 | 0x2000;
              }
            }
            uVar19 = uVar31;
            if (uVar16 == 0xfffc) {
              uVar19 = (uint)((uVar28 >> 0x20 & 0xffff) >> 5);
            }
            uStack_ec = uStack_ec + uVar19;
            ppbVar21 = (byte **)(ulonglong)uStack_ec;
            uVar19 = uStack_d8;
          }
          uStack_d8 = uVar19;
          if (((byte *)CONCAT62(uStack_d0,uStack_d2) != (byte *)0x0) &&
             ((byte *)CONCAT62(uStack_d0,uStack_d2) <
              (byte *)((longlong)ppbVar21 + (longlong)pbStack_e8))) {
            if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
               (((lVar3 = *(longlong *)
                           ((ulonglong)*puRam00000000011f8df0 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                 (lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0)) &&
                (*(char *)(lVar3 + 0x499) != '\0')))) {
              if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_2a8 = (undefined8 *)0x0;
                (*_DAT_)(1,0x157af88,0x169ac58,0x877);
              }
            }
            func_0x(pbStack_e8,0x12);
            ppbVar21 = (byte **)(ulonglong)uStack_ec;
          }
          uVar19 = uStack_d8;
          if (0x3f3b < (int)ppbVar21 - 1U) {
            if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
               ((lVar3 = *(longlong *)
                          ((ulonglong)*puRam00000000011f8df0 +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                 (*(char *)(lVar3 + 0x499) != '\0')))))) {
              if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_2a8 = (undefined8 *)0x0;
                (*_DAT_)(1,0x157af88,0x169ac58,0x87c);
              }
            }
            func_0x(pbStack_e8,5);
            ppbVar21 = (byte **)(ulonglong)uStack_ec;
            uVar19 = uStack_d8;
          }
        }
code_r0x00101913:
        uVar20 = (uint)ppbVar21;
        uStack_d8 = uVar19;
        if (uVar20 < 9) {
          bVar15 = *pbStack_e8 & 0xe;
joined_r0x00101954:
          if ((bVar15 == 0) || (bVar15 == 0xc)) {
            uVar20 = 9;
          }
        }
      }
      else {
        if (uVar20 == 0) {
          func_0x(&uStack_ee);
          uVar20 = uStack_ec;
        }
        if (uVar20 < 9) {
          bVar15 = *pbStack_e8 & 0x1c;
          goto joined_r0x00101954;
        }
      }
      uStack_240 = 0;
      uStack_248 = 0;
      uStack_250 = 0;
      uStack_258 = 0;
      uStack_260 = 0;
      uStack_268 = 0;
      pplStack_270 = (longlong **)0x0;
      puStack_278 = puStack_168;
      uStack_280 = (undefined4 *)((ulonglong)uStack_280._4_4_ << 0x20);
      uStack_288 = (undefined4 *)((ulonglong)uStack_288._4_4_ << 0x20);
      pbStack_290 = pbStack_e8;
      uStack_298 = (ulonglong *)CONCAT44(uStack_298._4_4_,uVar17);
      uStack_2a0 = (int *)CONCAT44(uStack_2a0._4_4_,uVar20);
      uStack_2a8 = (undefined8 *)((ulonglong)uStack_2a8._4_4_ << 0x20);
      iVar10 = func_0x(pplStack_130,0,piStack_1e0,0);
      if (iVar10 != 0) {
        uStack_2a8 = (undefined8 *)0x0;
        (*_DAT_)(1,0x1728b58,0x16ff910,0x81b);
      }
      lVar3 = **param_7;
      uStack_bc = 1;
      ppbVar21 = ppbVar24;
      if (*(char *)(lVar3 + 2) < '\0') {
        pbVar1 = (byte *)(lVar3 + 0x60);
        if ((sStack_f0 == 0) || (ppbVar21 = uStack_e0, uStack_e0 == (byte **)0x0)) {
          uStack_90 = 0;
          uStack_82 = 0;
          auStack_68 = ZEXT816(0);
          auStack_b8 = ZEXT816(0);
          stack0xffffffffffffff5a = SUB1614(ZEXT816(0),2);
          auStack_a8._0_2_ = 0xffff;
          uStack_a0 = 0;
          uStack_8a = 0;
          uStack_88 = 0;
          uStack_80 = 0;
          uStack_98 = 0;
          auStack_78 = ZEXT816(0);
          auStack_58._0_12_ = ZEXT812(0);
          auStack_58._12_4_ = 0;
          uStack_48 = 0;
          ppbVar21 = (byte **)auStack_b8;
        }
        if (*(short *)(lVar3 + 0x24) == 0) {
code_r0x00101b1e:
          uStack_1b8 = *(undefined8 *)(lVar3 + 0x28);
          uStack_1b0 = *(undefined2 *)(lVar3 + 0x30);
        }
        else {
          cVar7 = *(char *)(lVar3 + 1);
          if (cVar7 == '\v') {
            if (*(int *)(lVar3 + 0x18) != 99) {
code_r0x00101ae3:
              if (cVar7 != '\t') goto code_r0x00101b1e;
              goto code_r0x00101ae7;
            }
          }
          else {
            if (cVar7 != '\b') goto code_r0x00101ae3;
code_r0x00101ae7:
            if (*(int *)(lVar3 + 0x18) != 99) goto code_r0x00101b1e;
          }
          uStack_148 = *(undefined4 *)(lVar3 + 0x20);
          uStack_144 = *(undefined2 *)(lVar3 + 0x24);
          cVar7 = func_0x(&uStack_148);
          if (cVar7 == '\0') goto code_r0x00101b1e;
          func_0x(lVar3,&uStack_1b8);
        }
        *ppbVar21 = pbVar1;
        *(undefined4 *)(ppbVar21 + 0xc) = (undefined4)uStack_1b8;
        *(int *)((longlong)ppbVar21 + 100) = (int)((ulonglong)uStack_1b8 >> 0x20);
        *(undefined2 *)(ppbVar21 + 0xd) = uStack_1b0;
        *(undefined4 *)((longlong)ppbVar21 + 0x6c) = *(undefined4 *)(lVar3 + 0x20);
        *(undefined2 *)(ppbVar21 + 0xe) = *(undefined2 *)(lVar3 + 0x24);
        *(undefined2 *)((longlong)ppbVar21 + 0x72) = 0;
        uStack_1d0 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1377a70);
        uVar28 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1377a74);
        *(undefined2 *)(ppbVar21 + 2) = 0xffff;
        ppbVar21[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar21 + 0x2e) = 0;
        ppbVar21[7] = (byte *)0x0;
        ppbVar21[4] = (byte *)0x0;
        ppbVar21[9] = (byte *)0x0;
        ppbVar21[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar21 + 0xb) = 0;
        if ((**ppbVar21 & 2) != 0) {
          pbVar2 = pbVar1 + uVar28;
          if ((*pbVar2 & 1) == 0) {
            *(undefined2 *)(ppbVar21 + 2) = 0;
            ppbVar21[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar21 + 0x36) = 0;
            uVar19 = uVar31;
            switch(*pbVar2 & 0xe) {
            default:
              uVar19 = (uint)*(ushort *)(pbVar2 + 2);
              if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
                func_0x(pbVar2,6);
              }
              break;
            case 4:
              uVar19 = 9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar19 = 1;
            }
            *(uint *)(ppbVar21 + 4) = uVar19;
            *(undefined8 *)((longlong)ppbVar21 + 0x2e) = 0;
          }
          else {
            *(undefined2 *)(ppbVar21 + 2) = 1;
            ppbVar21[3] = pbVar2;
            bVar15 = *pbVar2;
            switch(bVar15 & 0x1c) {
            default:
              if ((char)pbVar2[1] < '\0') {
                uVar16 = *(ushort *)(pbVar2 + 1);
                *(ushort *)((longlong)ppbVar21 + 0x12) = uVar16;
                sVar9 = 3;
                uVar16 = (uVar16 & 0x7f) << 8 | uVar16 >> 8;
              }
              else {
                sVar9 = 2;
                uVar16 = (ushort)pbVar2[1];
              }
              *(ushort *)((longlong)ppbVar21 + 0x12) = uVar16;
              *(short *)(ppbVar21 + 5) = sVar9;
              uVar16 = *(ushort *)((longlong)ppbVar21 + 0x12);
              *(short *)((longlong)ppbVar21 + 0x2c) = (short)(uVar16 + 1 >> 1) + sVar9;
              if (uVar16 < 0x1f) {
                *(undefined2 *)((longlong)ppbVar21 + 0x2a) = 0;
                *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
                *(undefined4 *)(ppbVar21 + 8) = 0;
                ppbVar21[7] = (byte *)0x0;
                ppbVar21[4] = (byte *)0x0;
              }
              else {
                *(short *)((longlong)ppbVar21 + 0x2a) = (short)((int)(uVar16 - 1) / 0x1e);
                *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
                *(undefined4 *)(ppbVar21 + 8) = 0;
                ppbVar21[7] = (byte *)0x0;
                ppbVar21[4] = (byte *)0x0;
              }
              break;
            case 4:
              if (((bVar15 & 0x1c) != 4) || (uVar19 = 1, (bVar15 & 2) == 0)) {
                uVar19 = uVar31;
              }
              if (uVar19 == 0) {
                uVar29 = 1;
              }
              else {
                *(undefined4 *)(ppbVar21 + 8) = 0;
              }
              ppbVar21[5] = (byte *)0x0;
              *(undefined2 *)((longlong)ppbVar21 + 0x12) = 0;
              ppbVar21[6] = (byte *)0x0;
              ppbVar21[4] = (byte *)0x0;
              ppbVar21[7] = (byte *)0x0;
              ppbVar21[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar21 + 0x14) = uVar29;
              *(uint *)(ppbVar21 + 8) = (uint)(uVar19 != 0);
              ppbVar21[7] = (byte *)0x0;
              ppbVar21[4] = (byte *)0x0;
              break;
            case 8:
              ppbVar21[5] = (byte *)0x0;
              *(undefined2 *)((longlong)ppbVar21 + 0x12) = 0;
              ppbVar21[6] = (byte *)0x0;
              ppbVar21[4] = (byte *)0x0;
              ppbVar21[7] = (byte *)0x0;
              ppbVar21[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar21 + 0x14) = 9;
              *(undefined4 *)(ppbVar21 + 8) = 0;
              ppbVar21[7] = (byte *)0x0;
              ppbVar21[4] = (byte *)0x0;
            }
          }
        }
        if ((**ppbVar21 & 4) != 0) {
          if (uStack_1d0._2_2_ != 0) {
            uVar28 = (ulonglong)*(ushort *)(lVar3 + 0x61 + (longlong)uStack_1d0._2_2_ * 2);
          }
          psVar13 = (short *)(pbVar1 + uVar28);
          ppbVar21[9] = (byte *)psVar13;
          sVar9 = *psVar13;
          ppbVar21[10] = (byte *)(psVar13 + 1);
          *(short *)(ppbVar21 + 0xb) = (sVar9 + 1) * 2;
        }
        if (ppbVar21[1] != (byte *)0x0) {
          func_0x(ppbVar21[1],ppbVar21);
        }
      }
      uVar19 = (uint)*(ushort *)(lVar3 + 0xe);
      pbStack_e8 = (byte *)((ulonglong)*(ushort *)(lVar3 + 0x1ffc) + lVar3);
      if ((*pbStack_e8 & 1) == 0) {
        sStack_f0 = 0;
        uStack_ec = 0;
        uStack_ca = 0;
        uStack_c8 = 0;
        switch(*pbStack_e8 & 0xe) {
        default:
          uVar19 = (uint)*(ushort *)(pbStack_e8 + 2);
          if (0x1f9d < *(ushort *)(pbStack_e8 + 2) - 1) {
            func_0x(pbStack_e8,6);
          }
          break;
        case 4:
          uVar19 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar19 = 1;
        }
        uStack_e0 = (byte **)CONCAT44(uStack_e0._4_4_,uVar19);
        uStack_d2 = (undefined2)(lVar3 + 0x2000);
        uStack_d0 = (undefined6)((ulonglong)(lVar3 + 0x2000) >> 0x10);
        ppbVar21 = (byte **)(ulonglong)uVar19;
        uVar30 = uStack_ec;
      }
      else {
        sStack_f0 = 1;
        bVar15 = *pbStack_e8;
        switch(bVar15 & 0x1c) {
        default:
          if ((char)pbStack_e8[1] < '\0') {
            uStack_ee = (*(ushort *)(pbStack_e8 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_e8 + 1) >> 8
            ;
            uStack_d8._0_2_ = 3;
            sVar9 = 3;
          }
          else {
            uStack_ee = (ushort)pbStack_e8[1];
            uStack_d8._0_2_ = 2;
            sVar9 = 2;
          }
          uStack_d4 = (short)(uStack_ee + 1 >> 1) + sVar9;
          if (uStack_ee < 0x1f) {
            uStack_d8._2_2_ = 0;
            uStack_ec = 0;
            uStack_c0 = 0;
            uVar30 = 0;
          }
          else {
            uStack_d8._2_2_ = (short)((int)(uStack_ee - 1) / 0x1e);
            uVar30 = 0;
            uStack_ec = 0;
            uStack_c0 = 0;
          }
          break;
        case 4:
          if (((bVar15 & 0x1c) == 4) && ((bVar15 & 2) != 0)) {
            uStack_d8._0_2_ = 0;
            uStack_d8._2_2_ = 0;
            uStack_d4 = 0;
            uStack_d2 = 0;
            uStack_ee = 0;
            uStack_d0 = 0;
            uStack_ca = 0;
            uStack_ec = 0xf;
            uStack_c0 = 1;
          }
          else {
            uStack_d8._0_2_ = 0;
            uStack_d8._2_2_ = 0;
            uStack_d4 = 0;
            uStack_d2 = 0;
            uStack_ee = 0;
            uStack_d0 = 0;
            uStack_ca = 0;
            uVar30 = 1;
            uStack_ec = 1;
            uStack_c0 = 0;
          }
          break;
        case 8:
          uStack_d8._0_2_ = 0;
          uStack_d8._2_2_ = 0;
          uStack_d4 = 0;
          uStack_d2 = 0;
          uStack_ee = 0;
          uStack_d0 = 0;
          uStack_ca = 0;
          uVar30 = 9;
          uStack_ec = 9;
          uStack_c0 = 0;
        }
        lVar3 = lVar3 + 0x2000;
        uStack_c8 = (undefined2)lVar3;
        uStack_c6 = (undefined2)((ulonglong)lVar3 >> 0x10);
        uStack_c4 = (ushort)((ulonglong)lVar3 >> 0x20);
        uStack_c2 = (undefined2)((ulonglong)lVar3 >> 0x30);
        uStack_e0 = ppbVar21;
      }
      if (sStack_f0 == 0) {
        uVar19 = uStack_d8;
        if (uVar30 == 0) {
          uStack_ee = 0;
          uVar30 = (uint)ppbVar21;
          uVar28 = (ulonglong)ppbVar21 & 0xffffffff;
          if ((*pbStack_e8 & 0x10) != 0) {
            uVar30 = uVar30 + 2 +
                     (*(ushort *)(pbStack_e8 + ((ulonglong)ppbVar21 & 0xffffffff)) + 7 >> 3);
            uVar28 = (ulonglong)uVar30;
          }
          uStack_e0 = (byte **)CONCAT44(uVar30,(uint)uStack_e0);
          uVar19 = (uint)uVar28;
          if ((*pbStack_e8 & 0x20) == 0) {
            uStack_d4 = 0;
            uStack_ec = uVar19;
          }
          else {
            puVar26 = (ushort *)(pbStack_e8 + uVar28);
            uStack_d4 = *puVar26;
            if (uStack_d4 == 0) {
              if ((((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                  (lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0)) &&
                 ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                  (*(char *)(lVar3 + 0x499) != '\0')))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x80f);
                }
              }
              func_0x(pbStack_e8,3);
            }
            uStack_d8 = uStack_e0._4_4_ + 2 + (uint)uStack_d4 * 2;
            if (0x1f9e < uStack_d8) {
              if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                 ((lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                  ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                   (*(char *)(lVar3 + 0x499) != '\0')))))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x816);
                }
              }
              func_0x(pbStack_e8,4);
            }
            uVar23 = (ulonglong)uStack_d4;
            uStack_ec = puVar26[uVar23] & 0x7fff;
            if (uStack_ec < uStack_d8) {
              if ((((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                  (lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0)) &&
                 ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                  (*(char *)(lVar3 + 0x499) != '\0')))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x81d);
                }
              }
              func_0x(pbStack_e8,4);
              uVar23 = (ulonglong)uStack_d4;
            }
            uVar28 = (ulonglong)uStack_ec;
            uVar19 = uStack_d8;
            do {
              if (-1 < (short)puVar26[(ulonglong)((int)uVar23 - 1) + 1]) break;
              uVar20 = uStack_d8;
              if ((int)uVar23 != 1) {
                uVar20 = *(ushort *)(pbStack_e8 + uVar23 * 2 + (((ulonglong)uStack_e0 >> 0x20) - 2))
                         & 0x7fff;
              }
              if ((uVar20 < uStack_d8) ||
                 ((*(ushort *)(pbStack_e8 + uVar23 * 2 + ((ulonglong)uStack_e0 >> 0x20)) & 0x7fff) <
                  uVar20)) {
                uStack_d8 = uVar19;
                func_0x(pbStack_e8,7);
                uVar23 = (ulonglong)uStack_d4;
                uVar28 = (ulonglong)uStack_ec;
                uVar19 = uStack_d8;
              }
              uVar30 = (uint)uVar28;
              if ((uVar20 < uStack_d8) || (uVar30 < uVar20)) goto code_r0x00102715;
              if (*(ushort *)(pbStack_e8 + uVar20) == 5) {
                uStack_ee = uStack_ee | 2;
                uStack_d4 = (short)uVar23 - 1;
                uStack_c6 = (undefined2)uVar20;
                if ((*(ushort *)(pbStack_e8 + (ulonglong)(uVar20 & 0xffff) + 2) & 0x4000) == 0) {
                  uStack_c4 = uStack_c4 & 0xc7ff;
                }
                else {
                  uStack_c4 = uStack_c4 ^
                              (*(ushort *)(pbStack_e8 + (ulonglong)(uVar20 & 0xffff) + 2) ^
                              uStack_c4) & 0x3800;
                }
                uStack_c4 = (uStack_c4 ^ *(ushort *)(pbStack_e8 + (ulonglong)(uVar20 & 0xffff) + 2))
                            & 0x7ff ^ uStack_c4;
                break;
              }
              if (*(ushort *)(pbStack_e8 + uVar20) < 0x400) break;
              uStack_ee = uStack_ee | 1;
              uStack_d4 = (short)uVar23 - 1;
              uVar23 = (ulonglong)uStack_d4;
            } while (uStack_d4 != 0);
          }
          if ((*pbStack_e8 & 0x40) == 0) {
            uStack_ca = 0;
            uStack_c8 = 0;
          }
          else {
            uStack_ca = (undefined2)uVar28;
            uStack_c8 = (undefined2)(uVar28 >> 0x10);
            uStack_ec = (int)uVar28 + 0xe;
            uStack_d8 = uVar19;
            puVar14 = (ulonglong *)func_0x(&uStack_ee);
            uVar28 = *puVar14;
            uVar18 = (ushort)(uVar28 >> 0x30);
            uVar16 = uVar18;
            if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
              uVar16 = uVar18 & 0xdfff;
              if ((uVar28 & 0x4000000000000000) != 0) {
                uVar16 = uVar18 | 0x2000;
              }
            }
            uVar30 = uVar31;
            if (uVar16 == 0xfffc) {
              uVar30 = (uint)((uVar28 >> 0x20 & 0xffff) >> 5);
            }
            uStack_ec = uStack_ec + uVar30;
            uVar28 = (ulonglong)uStack_ec;
            uVar19 = uStack_d8;
          }
          uVar30 = (uint)uVar28;
          uStack_d8 = uVar19;
          if (((byte *)CONCAT62(uStack_d0,uStack_d2) != (byte *)0x0) &&
             ((byte *)CONCAT62(uStack_d0,uStack_d2) < pbStack_e8 + uVar28)) {
            if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
               (((lVar3 = *(longlong *)
                           ((ulonglong)*puRam00000000011f8df0 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                 (lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0)) &&
                (*(char *)(lVar3 + 0x499) != '\0')))) {
              if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_2a8 = (undefined8 *)0x0;
                (*_DAT_)(1,0x157af88,0x169ac58,0x877);
              }
            }
            func_0x(pbStack_e8,0x12);
            uVar30 = uStack_ec;
          }
          uVar19 = uStack_d8;
          if (0x3f3b < uVar30 - 1) {
            if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
               ((lVar3 = *(longlong *)
                          ((ulonglong)*puRam00000000011f8df0 +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                 (*(char *)(lVar3 + 0x499) != '\0')))))) {
              if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_2a8 = (undefined8 *)0x0;
                (*_DAT_)(1,0x157af88,0x169ac58,0x87c);
              }
            }
            func_0x(pbStack_e8,5);
            uVar30 = uStack_ec;
            uVar19 = uStack_d8;
          }
        }
code_r0x00102715:
        uVar20 = uVar30;
        if ((uVar30 < 9) && (((*pbStack_e8 & 0xe) == 0 || ((*pbStack_e8 & 0xe) == 0xc)))) {
          uVar20 = 9;
        }
      }
      else {
        if (uVar30 == 0) {
          func_0x(&uStack_ee);
          uVar30 = uStack_ec;
        }
        uVar20 = uVar30;
        uVar19 = uStack_d8;
        if ((uVar30 < 9) && (((*pbStack_e8 & 0x1c) == 0 || ((*pbStack_e8 & 0x1c) == 0xc)))) {
          uVar20 = 9;
        }
      }
      uStack_d8 = uVar19;
      if (sStack_f0 == 0) {
        if (uVar30 == 0) {
          uStack_ee = 0;
          uVar28 = (ulonglong)uStack_e0 & 0xffffffff;
          uVar30 = (uint)uStack_e0;
          if ((*pbStack_e8 & 0x10) != 0) {
            uVar30 = (uint)uStack_e0 + 2 + (*(ushort *)(pbStack_e8 + uVar28) + 7 >> 3);
            uVar28 = (ulonglong)uVar30;
          }
          uStack_e0 = (byte **)CONCAT44(uVar30,(uint)uStack_e0);
          uVar19 = (uint)uVar28;
          if ((*pbStack_e8 & 0x20) == 0) {
            uStack_d4 = 0;
            uStack_ec = uVar19;
          }
          else {
            puVar26 = (ushort *)(pbStack_e8 + uVar28);
            uStack_d4 = *puVar26;
            if (uStack_d4 == 0) {
              if ((((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                  (lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0)) &&
                 ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                  (*(char *)(lVar3 + 0x499) != '\0')))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x80f);
                }
              }
              func_0x(pbStack_e8,3);
            }
            uStack_d8 = uStack_e0._4_4_ + 2 + (uint)uStack_d4 * 2;
            if (0x1f9e < uStack_d8) {
              if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                 ((lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                  ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                   (*(char *)(lVar3 + 0x499) != '\0')))))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x816);
                }
              }
              func_0x(pbStack_e8,4);
            }
            uVar23 = (ulonglong)uStack_d4;
            uStack_ec = puVar26[uVar23] & 0x7fff;
            uVar28 = (ulonglong)uStack_ec;
            uVar19 = uStack_d8;
            if (uStack_ec < uStack_d8) {
              if ((((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
                  (lVar3 = *(longlong *)
                            ((ulonglong)*puRam00000000011f8df0 +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0)) &&
                 ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                  (*(char *)(lVar3 + 0x499) != '\0')))) {
                if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                  (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2a8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0x157af88,0x169ac58,0x81d);
                }
              }
              func_0x(pbStack_e8,4);
              uVar23 = (ulonglong)uStack_d4;
              uVar28 = (ulonglong)uStack_ec;
              uVar19 = uStack_d8;
            }
            do {
              if (-1 < (short)puVar26[(ulonglong)((int)uVar23 - 1) + 1]) break;
              uVar27 = uStack_d8;
              if ((int)uVar23 != 1) {
                uVar27 = *(ushort *)(pbStack_e8 + uVar23 * 2 + (((ulonglong)uStack_e0 >> 0x20) - 2))
                         & 0x7fff;
              }
              if ((uVar27 < uStack_d8) ||
                 ((*(ushort *)(pbStack_e8 + uVar23 * 2 + ((ulonglong)uStack_e0 >> 0x20)) & 0x7fff) <
                  uVar27)) {
                uStack_d8 = uVar19;
                func_0x(pbStack_e8,7);
                uVar23 = (ulonglong)uStack_d4;
                uVar28 = (ulonglong)uStack_ec;
                uVar19 = uStack_d8;
              }
              uVar30 = (uint)uVar28;
              if ((uVar27 < uStack_d8) || (uVar30 < uVar27)) goto code_r0x00102dff;
              if (*(ushort *)(pbStack_e8 + uVar27) == 5) {
                uStack_ee = uStack_ee | 2;
                uStack_d4 = (short)uVar23 - 1;
                uStack_c6 = (undefined2)uVar27;
                if ((*(ushort *)(pbStack_e8 + (ulonglong)(uVar27 & 0xffff) + 2) & 0x4000) == 0) {
                  uStack_c4 = uStack_c4 & 0xc7ff;
                }
                else {
                  uStack_c4 = uStack_c4 ^
                              (*(ushort *)(pbStack_e8 + (ulonglong)(uVar27 & 0xffff) + 2) ^
                              uStack_c4) & 0x3800;
                }
                uStack_c4 = (uStack_c4 ^ *(ushort *)(pbStack_e8 + (ulonglong)(uVar27 & 0xffff) + 2))
                            & 0x7ff ^ uStack_c4;
                break;
              }
              if (*(ushort *)(pbStack_e8 + uVar27) < 0x400) break;
              uStack_ee = uStack_ee | 1;
              uStack_d4 = (short)uVar23 - 1;
              uVar23 = (ulonglong)uStack_d4;
            } while (uStack_d4 != 0);
          }
          if ((*pbStack_e8 & 0x40) == 0) {
            uStack_ca = 0;
            uStack_c8 = 0;
          }
          else {
            uStack_ca = (undefined2)uVar28;
            uStack_c8 = (undefined2)(uVar28 >> 0x10);
            uStack_ec = (int)uVar28 + 0xe;
            uStack_d8 = uVar19;
            puVar14 = (ulonglong *)func_0x(&uStack_ee);
            uVar28 = *puVar14;
            uVar18 = (ushort)(uVar28 >> 0x30);
            uVar16 = uVar18;
            if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
              uVar16 = uVar18 & 0xdfff;
              if ((uVar28 & 0x4000000000000000) != 0) {
                uVar16 = uVar18 | 0x2000;
              }
            }
            uVar30 = uVar31;
            if (uVar16 == 0xfffc) {
              uVar30 = (uint)((uVar28 >> 0x20 & 0xffff) >> 5);
            }
            uStack_ec = uStack_ec + uVar30;
            uVar28 = (ulonglong)uStack_ec;
            uVar19 = uStack_d8;
          }
          uVar30 = (uint)uVar28;
          uStack_d8 = uVar19;
          if (((byte *)CONCAT62(uStack_d0,uStack_d2) != (byte *)0x0) &&
             ((byte *)CONCAT62(uStack_d0,uStack_d2) < pbStack_e8 + uVar28)) {
            if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
               (((lVar3 = *(longlong *)
                           ((ulonglong)*puRam00000000011f8df0 +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                 (lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0)) &&
                (*(char *)(lVar3 + 0x499) != '\0')))) {
              if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_2a8 = (undefined8 *)0x0;
                (*_DAT_)(1,0x157af88,0x169ac58,0x877);
              }
            }
            func_0x(pbStack_e8,0x12);
            uVar30 = uStack_ec;
          }
          uVar19 = uStack_d8;
          if (0x3f3b < uVar30 - 1) {
            if (((cRam0000000001c8a55b != '\0') || ((bRam0000000001c9ae60 & 1) != 0)) &&
               ((lVar3 = *(longlong *)
                          ((ulonglong)*puRam00000000011f8df0 +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                            (ulonglong)*puRam00000000011f8de8 * 8) + 8), lVar3 != 0 &&
                ((lVar3 = *(longlong *)(lVar3 + 0x60), lVar3 != 0 &&
                 (*(char *)(lVar3 + 0x499) != '\0')))))) {
              if ((cRam0000000001c8a44b == '\0') && ((bRam0000000001c9ae60 & 2) == 0)) {
                (*pcRam00000000011f8d88)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_2a8 = (undefined8 *)0x0;
                (*_DAT_)(1,0x157af88,0x169ac58,0x87c);
              }
            }
            func_0x(pbStack_e8,5);
            uVar30 = uStack_ec;
            uVar19 = uStack_d8;
          }
        }
code_r0x00102dff:
        uStack_d8 = uVar19;
        if ((8 < uVar30) || (((*pbStack_e8 & 0xe) != 0 && ((*pbStack_e8 & 0xe) != 0xc)))) {
code_r0x00102e19:
          uStack_230 = uVar30;
        }
      }
      else {
        if (uVar30 == 0) {
          func_0x(&uStack_ee);
          uVar30 = uStack_ec;
        }
        if ((8 < uVar30) || (((*pbStack_e8 & 0x1c) != 0 && ((*pbStack_e8 & 0x1c) != 0xc))))
        goto code_r0x00102e19;
        uStack_230 = 9;
      }
      puVar14 = puStack_168;
      piVar5 = piStack_1e0;
      uStack_240 = 0;
      uStack_248 = 0;
      uStack_250 = 0;
      uStack_258 = 0;
      uStack_260 = 0;
      uStack_268 = 0;
      pplStack_270 = (longlong **)0x0;
      puStack_278 = puStack_168;
      uStack_280 = (undefined4 *)((ulonglong)uStack_280._4_4_ << 0x20);
      uStack_288 = (undefined4 *)((ulonglong)uStack_288._4_4_ << 0x20);
      pbStack_290 = pbStack_e8;
      uStack_298 = (ulonglong *)CONCAT44(uStack_298._4_4_,uVar20);
      uStack_2a0 = (int *)CONCAT44(uStack_2a0._4_4_,uStack_230);
      uStack_2a8 = (undefined8 *)((ulonglong)uStack_2a8._4_4_ << 0x20);
      iVar10 = func_0x(pplStack_130,0,piStack_1e0,1);
      if (iVar10 != 0) {
        uStack_2a8 = (undefined8 *)0x0;
        (*_DAT_)(1,0x1728b58,0x16ff910,0x831);
      }
      if ((iStack_224 != 0) || (sStack_220 != 0)) {
        plStack_200 = (longlong *)0x0;
        uStack_1f8 = 0;
        uStack_1f4 = 0;
        func_0x(&plStack_200,&iStack_224,4,uStack_160);
        iStack_17c = iStack_238;
        uStack_178 = uStack_234;
        uStack_298 = puVar14;
        uStack_2a0 = (int *)((ulonglong)uStack_2a0 & 0xffffffff00000000);
        uStack_2a8 = (undefined8 *)&iStack_17c;
        func_0x(&plStack_200,piVar5,0x10);
        plVar25 = plStack_200;
        if (plStack_200 != (longlong *)0x0) {
          iVar10 = (int)(short)uStack_1f4;
          if (((*(ushort *)((longlong)plStack_200 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
            if (((byte)*(undefined2 *)((longlong)plStack_200 + 0x62) >> 3 & 1) != 0) {
              if (iVar10 == 3) {
                iVar10 = 4;
              }
              else if (iVar10 < 2) goto code_r0x00102ffe;
              if ((((*(uint *)((longlong)plStack_200 + 100) & 8) != 0) &&
                  (lVar3 = plStack_200[0x12], lVar3 != 0)) && (*(longlong *)(lVar3 + 0x758) != 0)) {
                func_0x(*(undefined8 *)(lVar3 + 0x758),plStack_200,iVar10);
              }
            }
code_r0x00102ffe:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
               ((2 < iVar10 &&
                (((*(uint *)((longlong)plVar25 + 100) & 0xc0000000) != 0x40000000 && (*plVar25 != 0)
                 ))))) {
              iVar11 = (*_DAT_)(*plVar25,0x2000,2,auStack_110);
              if (iVar11 != 0) {
                LOCK();
                *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            func_0x(plVar25 + 0x13,iVar10);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(plVar25,0,iVar10);
            }
            uStack_1f4 = uStack_1f4 & 0xffff0000;
            plStack_200 = (longlong *)0x0;
          }
          else {
            func_0x(&plStack_200);
          }
        }
        func_0x(&plStack_200);
      }
      if ((iStack_22c != 0) || (sStack_228 != 0)) {
        plStack_218 = (longlong *)0x0;
        uStack_210 = 0;
        uStack_20c = 0;
        func_0x(&plStack_218,&iStack_22c,4,uStack_160);
        iStack_184 = iStack_238;
        uStack_180 = uStack_234;
        uStack_298 = puVar14;
        uStack_2a0 = (int *)((ulonglong)uStack_2a0 & 0xffffffff00000000);
        uStack_2a8 = (undefined8 *)&iStack_184;
        func_0x(&plStack_218,piVar5,8);
        plVar25 = plStack_218;
        if (plStack_218 != (longlong *)0x0) {
          iVar10 = (int)(short)uStack_20c;
          if (((*(ushort *)((longlong)plStack_218 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
            if (((byte)*(undefined2 *)((longlong)plStack_218 + 0x62) >> 3 & 1) != 0) {
              if (iVar10 == 3) {
                iVar10 = 4;
              }
              else if (iVar10 < 2) goto code_r0x001031a2;
              if ((((*(uint *)((longlong)plStack_218 + 100) & 8) != 0) &&
                  (lVar3 = plStack_218[0x12], lVar3 != 0)) && (*(longlong *)(lVar3 + 0x758) != 0)) {
                func_0x(*(undefined8 *)(lVar3 + 0x758),plStack_218,iVar10);
              }
            }
code_r0x001031a2:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
               ((2 < iVar10 &&
                (((*(uint *)((longlong)plVar25 + 100) & 0xc0000000) != 0x40000000 && (*plVar25 != 0)
                 ))))) {
              iVar11 = (*_DAT_)(*plVar25,0x2000,2,auStack_10c);
              if (iVar11 != 0) {
                LOCK();
                *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            func_0x(plVar25 + 0x13,iVar10);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(plVar25,0,iVar10);
            }
            uStack_20c = uStack_20c & 0xffff0000;
            plStack_218 = (longlong *)0x0;
          }
          else {
            func_0x(&plStack_218);
          }
        }
        func_0x(&plStack_218);
      }
      lVar3 = lStack_100;
      uStack_18c = 0;
      uStack_188 = 0;
      uStack_158 = 0;
      uStack_150 = 0;
      uStack_1e8 = 0;
      uStack_120 = 0;
      if (lStack_100 != 0) {
        func_0x(lStack_100,&uStack_158);
        ppbVar24 = (byte **)(uStack_150 >> 0x20);
        uVar31 = (uint)uStack_150;
      }
      uVar6 = uStack_158;
      puStack_278 = (ulonglong *)0x0;
      uStack_280 = &uStack_1a8;
      uStack_288 = (undefined4 *)((ulonglong)uStack_288 & 0xffffffffffffff00);
      pbStack_290 = (byte *)0x0;
      uStack_298 = (ulonglong *)((ulonglong)uStack_298 & 0xffffffff00000000);
      uStack_2a0 = piStack_128;
      uStack_2a8 = &uStack_1e8;
      cVar7 = func_0x(&uStack_120,puVar14,&uStack_18c,piVar5);
      if (uVar31 != 0) {
        func_0x(uVar6,ppbVar24);
        uStack_150 = uStack_150 & 0xffffffff00000000;
      }
      if (cVar7 == '\0') {
        (*pcRam00000000011f8d88)(0x1a,5,0x19,7);
      }
      goto LAB_;
    }
  }
  if (((*(ushort *)((longlong)plVar25 + 0x62) >> 10 & 1) == 0) ||
     (*(short *)((longlong)param_7 + 0xc) < 3)) {
    iVar10 = (int)*(short *)((longlong)param_7 + 0xc);
    plVar25 = *param_7;
    if (((byte)*(undefined2 *)((longlong)plVar25 + 0x62) >> 3 & 1) != 0) {
      if (iVar10 == 3) {
        iVar10 = 4;
      }
      else if (iVar10 < 2) goto LAB_;
      if ((((*(uint *)((longlong)plVar25 + 100) & 8) != 0) && (lVar3 = plVar25[0x12], lVar3 != 0))
         && (*(longlong *)(lVar3 + 0x758) != 0)) {
        func_0x(*(undefined8 *)(lVar3 + 0x758),plVar25,iVar10);
      }
    }
LAB_:
    if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
        ((2 < iVar10 &&
         (((*(uint *)((longlong)plVar25 + 100) & 0xc0000000) != 0x40000000 && (*plVar25 != 0))))))
       && (iVar11 = (*_DAT_)(*plVar25,0x2000,2,auStack_108), iVar11 != 0)) {
      LOCK();
      *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) & 0x3fffffff;
      UNLOCK();
      LOCK();
      *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) | 0x40000000;
      UNLOCK();
    }
    func_0x(plVar25 + 0x13,iVar10);
    if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
      func_0x(plVar25,0,iVar10);
    }
    *(undefined2 *)((longlong)param_7 + 0xc) = 0;
    *param_7 = (longlong *)0x0;
  }
  else {
    func_0x(param_7);
  }
LAB_:
  func_0x(uStack_40 ^ (ulonglong)auStack_2c8);
  return;
}

