
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  ushort *puVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 *puVar8;
  ulonglong uVar9;
  ushort uVar10;
  longlong lVar11;
  longlong *plVar12;
  int iVar13;
  int iVar14;
  longlong unaff_retaddr;
  
  lVar11 = 0;
  uVar10 = 0;
  *(undefined4 *)((longlong)param_1 + (ulonglong)(*(uint *)(param_1 + 0x46) & 0x3f) * 4 + 0x130) = 7
  ;
  uVar9 = (ulonglong)*(byte *)(param_1 + 0x347);
  param_1[0x46] = param_1[0x46] + 1;
  plVar12 = param_1 + uVar9 * 3;
  lVar6 = func_0x();
  plVar12[0x47] = lVar6;
  param_1[uVar9 * 3 + 0x48] = unaff_retaddr;
  plVar12[0x49] = 0x298;
  param_1[0x347] = param_1[0x347] + 1;
  func_0x(param_1);
  if (param_1[0x355] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar1 = *(int *)(param_1[0x355] + 0x3cc);
  if (iVar1 == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar1 == 2) {
    lVar7 = (**(code **)(*param_1 + 0x20))(param_1);
    lVar6 = *(longlong *)(lVar7 + 4);
    iVar13 = (int)lVar6;
    iVar14 = (int)((ulonglong)lVar6 >> 0x20);
    uVar10 = *(ushort *)(lVar7 + 0xc);
    if (((iVar13 < 1) || (iVar14 < 1)) || (uVar10 == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(int *)(param_1 + 3) == iVar13) && (*(int *)((longlong)param_1 + 0x1c) == iVar14)) {
      param_1[3] = lVar6;
      *(ushort *)(param_1 + 4) = uVar10;
      puVar4 = (ushort *)param_1[7];
      param_1[5] = (ulonglong)
                   *(ushort *)((longlong)puVar4 + (ulonglong)puVar4[2] + (ulonglong)uVar10 * -2) +
                   (longlong)puVar4;
      if (3 < *puVar4) {
        lVar11 = *(longlong *)(puVar4 + 0x10);
      }
      param_1[6] = lVar11;
      if (param_1[0x355] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      goto LAB_;
    }
  }
  else {
    iVar13 = 0;
    iVar14 = 0;
  }
  plVar12 = (longlong *)param_1[0x355];
  if (plVar12 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar1 == 2) {
    param_1[3] = CONCAT44(iVar14,iVar13);
    *(ushort *)(param_1 + 4) = uVar10;
  }
  uVar2 = *(undefined4 *)((longlong)param_1 + 0x1c);
  uVar3 = *(undefined4 *)(param_1 + 3);
  *(undefined2 *)(plVar12 + 0x41) = *(undefined2 *)(param_1 + 4);
  *(undefined4 *)(plVar12 + 0x40) = uVar3;
  *(undefined4 *)((longlong)plVar12 + 0x204) = uVar2;
  puVar8 = (undefined4 *)(**(code **)(*plVar12 + 0x38))(plVar12,plVar12[0x40],0,0,0);
  uVar2 = puVar8[1];
  uVar3 = puVar8[2];
  uVar5 = puVar8[3];
  *(undefined4 *)(param_1 + 7) = *puVar8;
  *(undefined4 *)((longlong)param_1 + 0x3c) = uVar2;
  *(undefined4 *)(param_1 + 8) = uVar3;
  *(undefined4 *)((longlong)param_1 + 0x44) = uVar5;
  if (*(char *)(param_1 + 8) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar1 == 1) {
    if ((param_1[7] == 0) || (*(ushort *)(param_1[7] + 2) < *(ushort *)(param_1 + 4))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (param_1[0x355] == 0) {
      *(undefined *)((longlong)param_1 + 0x22) = 2;
    }
  }
  puVar4 = (ushort *)param_1[7];
  param_1[5] = (ulonglong)
               *(ushort *)
                ((longlong)puVar4 + (ulonglong)puVar4[2] + (ulonglong)*(ushort *)(param_1 + 4) * -2)
               + (longlong)puVar4;
  if (3 < *puVar4) {
    lVar11 = *(longlong *)(puVar4 + 0x10);
  }
  param_1[6] = lVar11;
LAB_:
  (**(code **)(*param_1 + 0x20))(param_1);
  return;
}

