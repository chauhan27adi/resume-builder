
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_(ushort *param_1)

{
  byte bVar1;
  ushort uVar2;
  ulonglong *puVar3;
  ulonglong uVar4;
  ushort uVar5;
  uint uVar6;
  uint uVar7;
  ulonglong uVar8;
  int iVar9;
  ushort *puVar10;
  longlong lVar11;
  byte *pbVar12;
  longlong unaff_GS_OFFSET;
  
  if (*(int *)(param_1 + 1) != 0) {
    return *(uint *)(param_1 + 1);
  }
  pbVar12 = *(byte **)(param_1 + 3);
  uVar6 = *(uint *)(param_1 + 7);
  uVar8 = (ulonglong)uVar6;
  *param_1 = 0;
  *(uint *)(param_1 + 9) = uVar6;
  bVar1 = *pbVar12;
  if ((bVar1 & 0x10) != 0) {
    uVar6 = uVar6 + 2 + (*(ushort *)(pbVar12 + uVar8) + 7 >> 3);
    uVar8 = (ulonglong)uVar6;
    *(uint *)(param_1 + 9) = uVar6;
    bVar1 = *pbVar12;
  }
  if ((bVar1 & 0x20) == 0) {
    *(int *)(param_1 + 1) = (int)uVar8;
    param_1[0xd] = 0;
    *(int *)(param_1 + 0xb) = (int)uVar8;
  }
  else {
    puVar10 = (ushort *)(pbVar12 + uVar8);
    uVar2 = *puVar10;
    param_1[0xd] = uVar2;
    if (uVar2 == 0) {
      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
          (lVar11 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar11 != 0)) &&
         ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0')
          ))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3eb);
        }
        else {
          (*_DAT_)(1,0x18c8a58,0x19e8728,0x80f,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),3);
      uVar8 = (ulonglong)*(uint *)(param_1 + 9);
      uVar2 = param_1[0xd];
    }
    uVar6 = (int)uVar8 + (uVar2 + 1) * 2;
    *(uint *)(param_1 + 0xb) = uVar6;
    if (0x1f9e < uVar6) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar11 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar11 != 0 &&
          ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
           (*(char *)(lVar11 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ec);
        }
        else {
          (*_DAT_)(1,0x18c8a58,0x19e8728,0x816,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),4);
      uVar2 = param_1[0xd];
      uVar6 = *(uint *)(param_1 + 0xb);
    }
    uVar4 = (ulonglong)uVar2;
    uVar7 = puVar10[uVar4] & 0x7fff;
    *(uint *)(param_1 + 1) = uVar7;
    if (uVar7 < uVar6) {
      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
          (lVar11 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar11 != 0)) &&
         ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0')
          ))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ec);
        }
        else {
          (*_DAT_)(1,0x18c8a58,0x19e8728,0x81d,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),4);
      uVar4 = (ulonglong)param_1[0xd];
      uVar7 = *(uint *)(param_1 + 1);
    }
    uVar8 = (ulonglong)uVar7;
    if ((short)puVar10[(ulonglong)((int)uVar4 - 1) + 1] < 0) {
      lVar11 = *(longlong *)(param_1 + 3);
      do {
        if ((int)uVar4 == 1) {
          uVar6 = *(uint *)(param_1 + 0xb);
          uVar7 = uVar6;
LAB_:
          if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar11 + uVar4 * 2) & 0x7fff) < uVar6
             ) goto LAB_;
        }
        else {
          uVar7 = *(uint *)(param_1 + 0xb);
          uVar6 = *(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar11 + -2 + uVar4 * 2) & 0x7fff;
          if (uVar7 <= uVar6) goto LAB_;
LAB_:
          func_0x(lVar11,7);
          uVar7 = *(uint *)(param_1 + 0xb);
        }
        if (uVar6 < uVar7) goto LAB_;
        uVar7 = *(uint *)(param_1 + 1);
        uVar8 = (ulonglong)uVar7;
        if (uVar7 < uVar6) {
          return uVar7;
        }
        lVar11 = *(longlong *)(param_1 + 3);
        if (*(ushort *)((ulonglong)uVar6 + lVar11) == 5) {
          *param_1 = *param_1 | 2;
          param_1[0xd] = param_1[0xd] - 1;
          param_1[0x14] = (ushort)uVar6;
          lVar11 = (ulonglong)(uVar6 & 0xffff) + *(longlong *)(param_1 + 3);
          uVar2 = param_1[0x15] & 0xc7ff;
          if ((*(ushort *)(lVar11 + 2) >> 0xe & 1) != 0) {
            uVar2 = *(ushort *)(lVar11 + 2) & 0x3800 | param_1[0x15] & 0xc7ff;
          }
          param_1[0x15] = uVar2;
          param_1[0x15] = (uVar2 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar2;
          uVar8 = (ulonglong)*(uint *)(param_1 + 1);
          pbVar12 = *(byte **)(param_1 + 3);
          goto LAB_;
        }
        if (*(ushort *)((ulonglong)uVar6 + lVar11) < 0x400) break;
        *param_1 = *param_1 | 1;
        uVar2 = param_1[0xd] - 1;
        param_1[0xd] = uVar2;
        if ((uVar2 == 0) ||
           (uVar4 = (ulonglong)uVar2, -1 < (short)puVar10[(ulonglong)(uVar2 - 1) + 1])) break;
      } while( true );
    }
    pbVar12 = *(byte **)(param_1 + 3);
  }
LAB_:
  iVar9 = 0;
  if ((*pbVar12 & 0x40) == 0) {
    *(undefined4 *)(param_1 + 0x12) = 0;
  }
  else {
    *(int *)(param_1 + 0x12) = (int)uVar8;
    *(int *)(param_1 + 1) = (int)uVar8 + 0xe;
    puVar3 = (ulonglong *)func_0x(param_1);
    uVar5 = (ushort)(*puVar3 >> 0x30);
    uVar2 = uVar5;
    if ((((uint)(int)(short)uVar5 >> 1 ^ (int)(short)uVar5) & 0x2000) != 0) {
      uVar2 = uVar5 & 0xdfff;
      if ((uVar5 >> 0xe & 1) != 0) {
        uVar2 = uVar5 | 0x2000;
      }
    }
    if (uVar2 == 0xfffc) {
      iVar9 = (int)((*puVar3 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar9;
    uVar8 = (ulonglong)*(uint *)(param_1 + 1);
  }
  iVar9 = (int)uVar8;
  if ((*(ulonglong *)(param_1 + 0xe) != 0) &&
     (*(ulonglong *)(param_1 + 0xe) < uVar8 + *(longlong *)(param_1 + 3))) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       (((lVar11 = *(longlong *)
                    (*(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                    (ulonglong)*_DAT_), lVar11 != 0 &&
         (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
        (*(char *)(lVar11 + 0x499) != '\0')))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x18c8a58,0x19e8728,0x877,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 3),0x12);
    iVar9 = *(int *)(param_1 + 1);
  }
  if (0x3f3b < iVar9 - 1U) {
    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
       ((lVar11 = *(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_), lVar11 != 0 &&
        ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))
        )))) {
      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x18c8a58,0x19e8728,0x87c,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 3),5);
  }
LAB_:
  return *(uint *)(param_1 + 1);
}

