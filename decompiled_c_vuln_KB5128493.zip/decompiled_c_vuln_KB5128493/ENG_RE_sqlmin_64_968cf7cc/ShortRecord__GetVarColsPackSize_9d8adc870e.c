
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,int *param_3,int *param_4,undefined8 param_5,
                 undefined4 *param_6)

{
  int iVar1;
  int iVar2;
  short *psVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined auStack_88 [8];
  undefined4 uStack_80;
  uint uStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  short *psStack_68;
  int *piStack_58;
  int *piStack_50;
  undefined8 uStack_48;
  longlong lStack_40;
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)auStack_88;
  uVar5 = 0;
  uStack_80 = 0;
  uStack_7c = (uStack_7c >> 0x10 & 0xffe0) << 0x10;
  uStack_78 = 0;
  uStack_70 = 0;
  uStack_48 = 0;
  if (*(int *)(*(longlong *)(param_2 + 8) + 0x100) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  psVar3 = *(short **)(param_1 + 8);
  piStack_58 = param_3;
  piStack_50 = param_4;
  lStack_40 = param_1;
  if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
    psStack_68 = psVar3;
    psVar3 = (short *)(**(code **)**(undefined8 **)(param_1 + 0x10))();
  }
  *param_3 = 0;
  *param_4 = 0;
  *param_6 = 0;
  if (*psVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  psStack_68 = psVar3;
  iVar1 = func_0x(psVar3 + 1);
  if (0 < iVar1) {
    do {
      if ((~uVar5 & 0xc0000000) == 0x80000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar4 = (undefined4 *)
               func_0x(*(undefined8 *)(*(longlong *)(param_2 + 8) + 0x160),~uVar5);
      psVar3 = psStack_68;
      if (puVar4 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uStack_80 = *puVar4;
      uStack_7c = puVar4[1];
      uStack_78 = *(undefined8 *)(puVar4 + 2);
      *piStack_58 = *piStack_58 + 1;
      iVar2 = func_0x(psStack_68,&uStack_80);
      if (iVar2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar5 = uVar5 + 1;
    } while ((int)uVar5 < iVar1);
  }
  iVar1 = func_0x(psVar3);
  if (0 < iVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*piStack_50 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong **)(lStack_40 + 0x10) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(lStack_40 + 0x10) + 8))();
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_88);
  return;
}

