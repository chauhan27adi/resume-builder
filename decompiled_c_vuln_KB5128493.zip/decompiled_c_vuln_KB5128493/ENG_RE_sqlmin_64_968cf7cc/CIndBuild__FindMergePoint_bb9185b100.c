
/* WARNING: Removing unreachable block (ram,0x0010021b) */
/* WARNING: Heritage AFTER dead removal. Example location: s0xfffffffffffffe80 : 0x00100300 */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_(longlong *param_1,longlong param_2,longlong **param_3)

{
  byte *pbVar1;
  undefined4 uVar2;
  longlong lVar3;
  ushort uVar4;
  uint **ppuVar5;
  char cVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong lVar12;
  uint *puVar13;
  uint uVar14;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar15;
  uint uVar16;
  longlong lVar17;
  ulonglong uVar18;
  longlong unaff_GS_OFFSET;
  undefined auStack_8e8 [32];
  undefined8 uStack_8c8;
  uint *puStack_8c0;
  int iStack_8a4;
  undefined2 uStack_8a0;
  int iStack_89c;
  short sStack_898;
  undefined8 uStack_894;
  undefined4 uStack_88c;
  longlong *plStack_888;
  longlong lStack_880;
  uint auStack_870 [2];
  longlong lStack_868;
  undefined8 uStack_860;
  ushort uStack_858;
  undefined8 uStack_840;
  undefined2 uStack_838;
  undefined8 uStack_830;
  ushort uStack_828;
  undefined auStack_808 [4];
  undefined4 uStack_804;
  undefined4 uStack_800;
  undefined2 uStack_7fc;
  undefined4 uStack_7e8;
  undefined2 uStack_7e4;
  undefined4 uStack_7e0;
  undefined2 uStack_7dc;
  undefined4 uStack_7d8;
  undefined2 uStack_7d4;
  undefined8 uStack_7b8;
  undefined2 uStack_7b0;
  undefined4 uStack_79c;
  undefined8 uStack_770;
  undefined2 uStack_768;
  undefined8 uStack_760;
  ushort uStack_758;
  undefined auStack_750 [4];
  undefined auStack_74c [16];
  undefined auStack_73c [36];
  uint uStack_718;
  undefined8 uStack_714;
  undefined auStack_6f8 [8];
  undefined4 uStack_6f0;
  undefined4 uStack_6e8;
  uint **ppuStack_6e0;
  undefined *puStack_6d8;
  undefined8 uStack_6d0;
  uint *puStack_6c8;
  undefined4 uStack_6c0;
  undefined4 uStack_6bc;
  longlong lStack_6b8;
  undefined4 uStack_6b0;
  undefined4 uStack_6ac;
  longlong lStack_6a8;
  undefined4 uStack_6a0;
  undefined4 uStack_69c;
  short *psStack_698;
  int iStack_690;
  undefined4 uStack_68c;
  short *psStack_688;
  int iStack_680;
  undefined4 uStack_67c;
  undefined8 uStack_678;
  undefined4 uStack_670;
  undefined4 uStack_66c;
  undefined auStack_668 [448];
  undefined8 uStack_4a8;
  undefined8 uStack_4a0;
  uint uStack_498;
  short sStack_494;
  int iStack_492;
  undefined uStack_48e;
  undefined uStack_48d;
  undefined2 uStack_1b8;
  undefined4 uStack_1b4;
  byte *pbStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_19a;
  undefined2 uStack_192;
  undefined2 uStack_190;
  undefined6 uStack_18e;
  uint uStack_184;
  undefined auStack_180 [16];
  undefined auStack_170 [8];
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined6 uStack_158;
  undefined2 uStack_152;
  undefined6 uStack_150;
  undefined2 uStack_14a;
  undefined8 uStack_148;
  undefined auStack_140 [16];
  undefined auStack_130 [16];
  undefined auStack_120 [16];
  undefined8 uStack_110;
  short asStack_d0 [24];
  short asStack_a0 [48];
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_8e8;
  lStack_880 = param_1[5];
  lVar17 = -1;
  iStack_8a4 = *(int *)(**param_3 + 0x20);
  uStack_8a0 = *(undefined2 *)(**param_3 + 0x24);
  uVar16 = 0;
  iStack_89c = 0;
  sStack_898 = 0;
  uStack_1b8 = 0xffff;
  pbStack_1b0 = (byte *)0x0;
  uStack_1b4 = 0;
  uStack_19a = 0;
  uStack_190 = 0;
  uStack_18e = 0;
  uStack_1a8 = 0;
  uStack_184 = 0xffffffff;
  lVar12 = **param_3;
  if (*(char *)(lVar12 + 1) == '\x01') {
    uVar8 = 1;
  }
  else {
    uVar8 = uVar16;
    if ((*(char *)(lVar12 + 1) == '\x02') && (*(char *)(lVar12 + 3) == '\0')) {
      uVar8 = (uint)(1 < *(ushort *)(lVar12 + 6));
    }
  }
  if (*(char *)(param_2 + 1) == '\x01') {
    uVar14 = 1;
  }
  else {
    uVar14 = uVar16;
    if ((*(char *)(param_2 + 1) == '\x02') && (*(char *)(param_2 + 3) == '\0')) {
      uVar14 = (uint)(1 < *(ushort *)(param_2 + 6));
    }
  }
  plStack_888 = param_1;
  lStack_868 = param_2;
  if (uVar8 == uVar14) {
    if (uVar8 != 0) goto LAB_;
    iVar7 = (uint)*(byte *)(lVar12 + 3) - (uint)*(byte *)(param_2 + 3);
  }
  else {
    iVar7 = (uVar8 ^ 1) * 2 + -1;
  }
  if (iVar7 == 0) {
LAB_:
    uStack_714 = 0;
    lVar12 = *(longlong *)(*param_1 + 0x30);
    if ((((*_DAT_ == '\0') || ((DAT_ & 0x80) != 0)) ||
        ((lVar11 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
         lVar11 != 0 &&
         ((lVar11 = **(longlong **)(lVar11 + 0x38), lVar11 != 0 &&
          (iVar7 = (*_DAT_)(lVar11,0x337), iVar7 != 0)))))) ||
       (lVar11 = *(longlong *)
                  (*(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                  (ulonglong)*_DAT_), lVar11 == 0)) {
      lVar11 = 0;
    }
    else {
      lVar11 = *(longlong *)(lVar11 + 0x60);
    }
    lVar3 = *(longlong *)(lVar12 + 0x728);
    do {
      auStack_870[0] = 0;
      if (*param_3 != (longlong *)0x0) {
        if (((*(ushort *)((longlong)*param_3 + 0x62) >> 10 & 1) == 0) ||
           (*(short *)((longlong)param_3 + 0xc) < 3)) {
          plVar10 = *param_3;
          iVar7 = (int)*(short *)((longlong)param_3 + 0xc);
          if (((byte)*(undefined2 *)((longlong)plVar10 + 0x62) >> 3 & 1) != 0) {
            if (iVar7 == 3) {
              iVar7 = 4;
            }
            else if (iVar7 < 2) goto LAB_;
            if ((((*(uint *)((longlong)plVar10 + 100) & 8) != 0) &&
                (lVar15 = plVar10[0x12], lVar15 != 0)) && (*(longlong *)(lVar15 + 0x758) != 0)) {
              func_0x(*(undefined8 *)(lVar15 + 0x758),plVar10,iVar7);
            }
          }
LAB_:
          if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar10 + 100) & 8) != 0)) &&
              ((2 < iVar7 &&
               (((*(uint *)((longlong)plVar10 + 100) & 0xc0000000) != 0x40000000 && (*plVar10 != 0))
               )))) && (iVar9 = (*_DAT_)(*plVar10,0x2000,2,auStack_74c), iVar9 != 0)) {
            LOCK();
            *(uint *)((longlong)plVar10 + 100) = *(uint *)((longlong)plVar10 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar10 + 100) = *(uint *)((longlong)plVar10 + 100) | 0x40000000;
            UNLOCK();
          }
          func_0x(plVar10 + 0x13,iVar7);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(plVar10,0,iVar7);
          }
          *(undefined2 *)((longlong)param_3 + 0xc) = 0;
          *param_3 = (longlong *)0x0;
        }
        else {
          func_0x(param_3);
        }
      }
      if (*(longlong *)(lVar12 + 0x728) != 0) {
        func_0x(param_3,&iStack_89c,lVar12);
        if (*param_3 != (longlong *)0x0) {
          if (((*(ushort *)((longlong)*param_3 + 0x62) >> 10 & 1) == 0) ||
             (*(short *)((longlong)param_3 + 0xc) < 3)) {
            plVar10 = *param_3;
            iVar7 = (int)*(short *)((longlong)param_3 + 0xc);
            if (((byte)*(undefined2 *)((longlong)plVar10 + 0x62) >> 3 & 1) != 0) {
              if (iVar7 == 3) {
                iVar7 = 4;
              }
              else if (iVar7 < 2) goto LAB_;
              if ((((*(uint *)((longlong)plVar10 + 100) & 8) != 0) &&
                  (lVar15 = plVar10[0x12], lVar15 != 0)) && (*(longlong *)(lVar15 + 0x758) != 0)) {
                func_0x(*(undefined8 *)(lVar15 + 0x758),plVar10,iVar7);
              }
            }
LAB_:
            if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar10 + 100) & 8) != 0))
                && ((2 < iVar7 &&
                    (((*(uint *)((longlong)plVar10 + 100) & 0xc0000000) != 0x40000000 &&
                     (*plVar10 != 0)))))) &&
               (iVar9 = (*_DAT_)(*plVar10,0x2000,2,auStack_750), iVar9 != 0)) {
              LOCK();
              *(uint *)((longlong)plVar10 + 100) = *(uint *)((longlong)plVar10 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar10 + 100) = *(uint *)((longlong)plVar10 + 100) | 0x40000000;
              UNLOCK();
            }
            func_0x(plVar10 + 0x13,iVar7);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(plVar10,0,iVar7);
            }
            *(undefined2 *)((longlong)param_3 + 0xc) = 0;
            *param_3 = (longlong *)0x0;
          }
          else {
            func_0x(param_3);
          }
        }
      }
      func_0x(lVar12,&iStack_89c);
      puStack_8c0 = &uStack_718;
      uStack_8c8 = CONCAT44(uStack_8c8._4_4_,4);
      plVar10 = (longlong *)func_0x(_DAT_,lVar12,&iStack_89c,auStack_870);
      *param_3 = plVar10;
      *(undefined2 *)((longlong)param_3 + 0xc) = 4;
      if (lVar11 != 0) {
        uVar18 = (ulonglong)(*(uint *)(lVar11 + 0x500) & 0xf);
        if (*(longlong *)(lVar11 + 0x508 + uVar18 * 8) != *plVar10) {
          *(longlong *)(lVar11 + 0x508 + uVar18 * 8) = *plVar10;
          *(longlong *)(lVar11 + 0x500) = *(longlong *)(lVar11 + 0x500) + 1;
        }
      }
      *(byte *)((longlong)param_3 + 0xf) = (byte)(auStack_870[0] >> 3) & 1;
      *(byte *)(param_3 + 2) = (byte)(auStack_870[0] >> 4) & 1;
      if (((lVar3 != 0) && (lVar11 != 0)) && (lVar11 == *(longlong *)(lVar12 + 0x1c38))) {
        *(longlong *)(lVar3 + 0x5b28) = *(longlong *)(lVar3 + 0x5b28) + 1;
        if ((int)uStack_714 != 0) {
          *(longlong *)(lVar3 + 0x5b30) = *(longlong *)(lVar3 + 0x5b30) + 1;
          *(longlong *)(lVar3 + 0x5b38) = *(longlong *)(lVar3 + 0x5b38) + (ulonglong)uStack_718;
          if ((auStack_870[0] >> 3 & 1) != 0) {
            *(longlong *)(lVar3 + 0x5b40) = *(longlong *)(lVar3 + 0x5b40) + 1;
            *(longlong *)(lVar3 + 0x5b48) = *(longlong *)(lVar3 + 0x5b48) + (ulonglong)uStack_718;
          }
        }
      }
      cVar6 = func_0x(lVar12);
      if (((cVar6 == '\0') || (*(char *)(lVar12 + 0x2050) == '\0')) ||
         ((iStack_89c == 0 || ((iStack_89c == 9 && (sStack_898 == 1)))))) goto LAB_;
      lVar15 = **param_3;
      if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
        uStack_830 = *(undefined8 *)(lVar15 + 0x28);
        uStack_828 = *(ushort *)(lVar15 + 0x30);
      }
      else {
        cVar6 = *(char *)(lVar15 + 1);
        if (cVar6 == '\v') {
          if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
            if (cVar6 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar6 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
        }
        uStack_7e8 = *(undefined4 *)(lVar15 + 0x20);
        uStack_7e4 = *(undefined2 *)(lVar15 + 0x24);
        cVar6 = func_0x(&uStack_7e8);
        if (cVar6 == '\0') goto LAB_;
        func_0x(lVar15,&uStack_830);
      }
      uVar16 = *(uint *)(lVar12 + 0x2108);
      do {
        uStack_894 = *(undefined8 *)(lVar12 + 0x20fc);
        uVar8 = uVar16 & 0xfffffffe;
        uStack_88c = *(undefined4 *)(lVar12 + 0x2104);
        LOCK();
        UNLOCK();
        uVar16 = *(uint *)(lVar12 + 0x2108);
      } while (uVar8 != uVar16);
      if ((uint)uStack_830 <= (uint)uStack_894) {
        if ((uint)uStack_894 != (uint)uStack_830) goto LAB_;
        uVar16 = (uint)((ulonglong)uStack_894 >> 0x20);
        if ((uStack_830._4_4_ <= uVar16) &&
           ((uVar16 != uStack_830._4_4_ || (uStack_828 <= (ushort)uStack_88c)))) goto LAB_;
      }
      if ((*(char *)(lVar12 + 0x6ac8) == '\0') &&
         ((*(longlong *)
            (*(longlong *)
              (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8 + (ulonglong)*_DAT_) + 0x60) != *(longlong *)(lVar12 + 0x2120) &&
          (cVar6 = func_0x(lVar12), cVar6 == '\0')))) {
        uVar16 = *(uint *)(lVar12 + 0x2108);
        do {
          uStack_894 = *(undefined8 *)(lVar12 + 0x20fc);
          uVar8 = uVar16 & 0xfffffffe;
          uStack_88c = *(undefined4 *)(lVar12 + 0x2104);
          LOCK();
          UNLOCK();
          uVar16 = *(uint *)(lVar12 + 0x2108);
        } while (uVar8 != uVar16);
        uVar4 = (ushort)uStack_88c;
        uStack_758 = (ushort)uStack_88c;
        lVar11 = **param_3;
        uStack_760 = uStack_894;
        if (*(short *)(lVar11 + 0x24) == 0) {
LAB_:
          uStack_860 = *(undefined8 *)(lVar11 + 0x28);
          uStack_858 = *(ushort *)(lVar11 + 0x30);
        }
        else {
          cVar6 = *(char *)(lVar11 + 1);
          if (cVar6 == '\v') {
            if (*(int *)(lVar11 + 0x18) != 99) {
LAB_:
              if (cVar6 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar6 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar11 + 0x18) != 99) goto LAB_;
          }
          uStack_7d8 = *(undefined4 *)(lVar11 + 0x20);
          uStack_7d4 = *(undefined2 *)(lVar11 + 0x24);
          cVar6 = func_0x(&uStack_7d8);
          if (cVar6 == '\0') goto LAB_;
          func_0x(lVar11,&uStack_860);
        }
        if ((uint)uStack_860 <= (uint)uStack_894) {
          if ((uint)uStack_894 != (uint)uStack_860) goto LAB_;
          uVar16 = (uint)((ulonglong)uStack_860 >> 0x20);
          if ((uVar16 <= uStack_894._4_4_) &&
             ((uStack_894._4_4_ != uVar16 || (uStack_858 <= uVar4)))) goto LAB_;
        }
        lVar11 = *(longlong *)(lVar12 + 0x6b0);
        func_0x(&uStack_860,asStack_d0,auStack_808);
        func_0x(&uStack_760,asStack_a0,auStack_808);
        if ((_DAT_ & 0x10000) != 0) {
          ppuStack_6e0 = &puStack_6c8;
          uStack_6f0 = 0x60000;
          puStack_6d8 = auStack_668;
          puStack_6c8 = &uStack_498;
          uStack_498 = (uint)*(ushort *)(lVar12 + 0x6b8);
          sStack_494 = sStack_898;
          iStack_492 = iStack_89c;
          iVar7 = 0;
          uStack_6e8 = 0;
          uStack_4a8 = 0;
          uStack_6d0 = 0;
          uStack_4a0 = 0;
          uStack_6c0 = 0x34;
          uStack_6bc = 5;
          uStack_6b0 = 0x10;
          uStack_6ac = 5;
          uStack_6a0 = 0x10;
          uStack_69c = 6;
          uStack_68c = 7;
          uStack_67c = 8;
          uStack_678 = 0;
          uStack_670 = 0;
          uStack_66c = 9;
          uStack_48e = 0xff;
          uStack_48d = *(undefined *)(**param_3 + 1);
          lStack_6b8 = lVar11 + 0x254;
          lStack_6a8 = lVar11 + 0x244;
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_d0[lVar12] != 0);
          iStack_690 = (int)lVar12 * 2;
          psStack_698 = asStack_d0;
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_a0[lVar12] != 0);
          iStack_680 = (int)lVar12 * 2;
          uStack_804 = 0;
          psStack_688 = asStack_a0;
          puVar13 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar11,&uStack_804);
          ppuVar5 = ppuStack_6e0;
          if (puVar13 != (uint *)0x0) {
            do {
              lVar17 = lVar17 + 1;
            } while (*(short *)((longlong)puVar13 + lVar17 * 2) != 0);
            iVar7 = (int)lVar17 * 2;
          }
          ppuStack_6e0[10] = puVar13;
          *(int *)(ppuVar5 + 0xb) = iVar7;
          *(undefined4 *)((longlong)ppuVar5 + 0x5c) = 9;
          func_0x(auStack_6f8);
        }
LAB_:
        func_0x(uStack_40 ^ (ulonglong)auStack_8e8);
        return;
      }
      if ((*(longlong *)
            (*(longlong *)
              (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8 + (ulonglong)*_DAT_) + 0x60) == *(longlong *)(lVar12 + 0x2120)) ||
         (cVar6 = func_0x(lVar12), cVar6 != '\0')) goto LAB_;
      if (lVar11 == 0) {
        lVar11 = func_0x();
      }
      lVar15 = **param_3;
      if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
        uStack_7b8 = *(undefined8 *)(lVar15 + 0x28);
        uStack_7b0 = *(undefined2 *)(lVar15 + 0x30);
      }
      else {
        cVar6 = *(char *)(lVar15 + 1);
        if (cVar6 == '\v') {
          if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
            if (cVar6 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar6 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
        }
        uStack_7e0 = *(undefined4 *)(lVar15 + 0x20);
        uStack_7dc = *(undefined2 *)(lVar15 + 0x24);
        cVar6 = func_0x(&uStack_7e0);
        if (cVar6 == '\0') goto LAB_;
        func_0x(lVar15,&uStack_7b8);
      }
      if (*param_3 != (longlong *)0x0) {
        if (((*(ushort *)((longlong)*param_3 + 0x62) >> 10 & 1) == 0) ||
           (*(short *)((longlong)param_3 + 0xc) < 3)) {
          plVar10 = *param_3;
          iVar7 = (int)*(short *)((longlong)param_3 + 0xc);
          if (((byte)*(undefined2 *)((longlong)plVar10 + 0x62) >> 3 & 1) != 0) {
            if (iVar7 == 3) {
              iVar7 = 4;
            }
            else if (iVar7 < 2) goto LAB_;
            if ((((*(uint *)((longlong)plVar10 + 100) & 8) != 0) &&
                (lVar15 = plVar10[0x12], lVar15 != 0)) && (*(longlong *)(lVar15 + 0x758) != 0)) {
              func_0x(*(undefined8 *)(lVar15 + 0x758),plVar10,iVar7);
            }
          }
LAB_:
          if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar10 + 100) & 8) != 0)) &&
              ((2 < iVar7 &&
               (((*(uint *)((longlong)plVar10 + 100) & 0xc0000000) != 0x40000000 && (*plVar10 != 0))
               )))) && (iVar9 = (*_DAT_)(*plVar10,0x2000,2,auStack_73c), iVar9 != 0)) {
            LOCK();
            *(uint *)((longlong)plVar10 + 100) = *(uint *)((longlong)plVar10 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar10 + 100) = *(uint *)((longlong)plVar10 + 100) | 0x40000000;
            UNLOCK();
          }
          func_0x(plVar10 + 0x13,iVar7);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(plVar10,0,iVar7);
          }
          *(undefined2 *)((longlong)param_3 + 0xc) = 0;
          *param_3 = (longlong *)0x0;
        }
        else {
          func_0x(param_3);
        }
      }
      uStack_770 = uStack_7b8;
      uStack_768 = uStack_7b0;
      uStack_8c8 = 0;
      func_0x(*(undefined8 *)(lVar12 + 0x728),&uStack_770,4,4);
    } while( true );
  }
  if (*(int *)(param_1 + 0x1ea) == 0) {
    uVar16 = *(ushort *)(lVar12 + 0x16) - 1;
  }
  iStack_89c = iStack_8a4;
  sStack_898 = uStack_8a0;
  uStack_184 = uVar16;
  if (-1 < *(char *)(lVar12 + 2)) goto LAB_;
  pbVar1 = (byte *)(lVar12 + 0x60);
  uStack_158 = 0;
  stack0xfffffffffffffe92 = SUB1614(ZEXT816(0),2);
  auStack_170._0_2_ = 0xffff;
  uStack_14a = SUB162(ZEXT816(0),6);
  uStack_168 = 0;
  uStack_152 = 0;
  uStack_150 = 0;
  uStack_160 = 0;
  auStack_140 = ZEXT816(0);
  auStack_120._0_12_ = ZEXT812(0);
  auStack_120._12_4_ = 0;
  uStack_110 = 0;
  auStack_130 = ZEXT816(0);
  auStack_180 = ZEXT816(0);
  uStack_110 = 0;
  uStack_148 = 0;
  uStack_14a = 0;
  uStack_150 = 0;
  uStack_152 = 0;
  uStack_158 = 0;
  uStack_160 = 0;
  if (*(short *)(lVar12 + 0x24) == 0) {
LAB_:
    uStack_840 = *(undefined8 *)(lVar12 + 0x28);
    uStack_838 = *(undefined2 *)(lVar12 + 0x30);
  }
  else {
    cVar6 = *(char *)(lVar12 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(lVar12 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar12 + 0x18) != 99) goto LAB_;
    }
    uStack_800 = *(undefined4 *)(lVar12 + 0x20);
    uStack_7fc = *(undefined2 *)(lVar12 + 0x24);
    cVar6 = func_0x(&uStack_800);
    if (cVar6 == '\0') goto LAB_;
    func_0x(lVar12,&uStack_840);
  }
  lVar17 = auStack_180._8_8_;
                    /* WARNING: Ignoring partial resolution of indirect */
  auStack_180._0_8_ = pbVar1;
                    /* WARNING: Ignoring partial resolution of indirect */
  auStack_120._0_4_ = (undefined4)uStack_840;
                    /* WARNING: Ignoring partial resolution of indirect */
  uStack_110._0_2_ = *(undefined2 *)(lVar12 + 0x24);
  uVar2 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1080550);
  uVar18 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1080554);
                    /* WARNING: Ignoring partial resolution of indirect */
  auStack_170._0_2_ = 0xffff;
  uStack_150 = 0;
  uStack_152 = 0;
  uStack_160 = 0;
                    /* WARNING: Ignoring partial resolution of indirect */
  auStack_130._0_8_ = 0;
  uStack_79c = uVar2;
  if ((*pbVar1 & 2) != 0) {
    if ((pbVar1[uVar18] & 1) == 0) {
                    /* WARNING: Ignoring partial resolution of indirect */
      auStack_170._0_2_ = 0;
                    /* WARNING: Could not emulate address calculation at 0x001004c8 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(pbVar1[uVar18] & 0xe) * 4 + 0x102780) -
                0x14b98e0))();
      return;
    }
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_170._0_2_ = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(pbVar1[uVar18] & 0x1c) + 0x102760)
                            * 4 + 0x102750) - 0x14b98e0);
                    /* WARNING: Could not emulate address calculation at 0x00100336 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar1 & 4) != 0) {
    uStack_79c._2_2_ = (short)((uint)uVar2 >> 0x10);
    if (uStack_79c._2_2_ != 0) {
      uVar18 = (ulonglong)*(ushort *)(lVar12 + 0x61 + (longlong)uStack_79c._2_2_ * 2);
    }
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_130._0_8_ = pbVar1 + uVar18 + 2;
  }
  if (lVar17 != 0) {
    func_0x(lVar17,auStack_180);
  }
LAB_:
  pbStack_1b0 = (byte *)((ulonglong)*(ushort *)(lVar12 + (0xfff - (longlong)(int)uVar16) * 2) +
                        lVar12);
  if ((*pbStack_1b0 & 1) == 0) {
    uStack_1b8 = 0;
    uStack_1b4 = 0;
    uStack_192 = 0;
    uStack_190 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007c0 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1b0 & 0xe) * 4 + 0x1027ec) - 0x14b98e0)
    )(0xfffffffffeb46720,(longlong)(int)(*pbStack_1b0 & 0xe),pbStack_1b0);
    return;
  }
  uStack_1b8 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1b0 & 0x1c) + 0x1027cc) * 4
                         + 0x1027bc) - 0x14b98e0);
                    /* WARNING: Could not emulate address calculation at 0x001005d7 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_1b0,pbStack_1b0);
  return;
}

