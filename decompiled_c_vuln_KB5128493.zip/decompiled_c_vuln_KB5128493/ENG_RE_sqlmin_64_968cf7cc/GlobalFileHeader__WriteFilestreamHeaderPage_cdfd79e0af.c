
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,char param_2,undefined4 param_3,undefined4 param_4,
                 undefined2 param_5,undefined *param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined8 param_10,undefined4 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined8 param_15,undefined8 param_16,
                 undefined4 param_17,undefined8 param_18,undefined8 param_19,undefined8 param_20,
                 undefined8 param_21,undefined8 param_22,undefined8 param_23,undefined8 param_24,
                 undefined8 param_25,undefined8 param_26,undefined8 param_27,undefined8 param_28,
                 undefined8 param_29,undefined8 param_30,undefined8 param_31,undefined8 param_32)

{
  longlong lVar1;
  undefined8 uVar2;
  int iVar3;
  ulonglong *puVar4;
  longlong *plVar5;
  byte bVar6;
  ulonglong uVar7;
  ushort uVar8;
  ushort uVar9;
  ulonglong uVar10;
  uint uVar11;
  ushort *puVar12;
  int iVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  byte *pbVar17;
  longlong unaff_GS_OFFSET;
  undefined auStack_dd8 [32];
  undefined8 uStack_db8;
  undefined *puStack_db0;
  undefined4 uStack_da8;
  undefined4 uStack_da0;
  undefined4 uStack_d98;
  undefined8 uStack_d90;
  undefined4 uStack_d88;
  undefined8 uStack_d80;
  undefined8 uStack_d78;
  undefined8 uStack_d70;
  undefined8 uStack_d68;
  undefined8 uStack_d60;
  undefined4 uStack_d58;
  undefined8 uStack_d50;
  undefined8 uStack_d48;
  undefined8 uStack_d40;
  undefined8 uStack_d38;
  undefined8 uStack_d30;
  undefined8 uStack_d28;
  undefined8 uStack_d20;
  undefined8 uStack_d18;
  undefined8 uStack_d10;
  undefined8 uStack_d08;
  undefined8 uStack_d00;
  undefined8 uStack_cf8;
  undefined8 uStack_cf0;
  undefined8 uStack_ce8;
  char cStack_cd8;
  short sStack_cd0;
  ushort uStack_cce;
  uint uStack_ccc;
  byte *pbStack_cc8;
  undefined8 uStack_cc0;
  uint uStack_cb8;
  ushort uStack_cb4;
  byte *pbStack_cb2;
  undefined2 uStack_caa;
  undefined2 uStack_ca8;
  undefined2 uStack_ca6;
  ushort uStack_ca4;
  undefined2 uStack_ca2;
  undefined4 uStack_c98;
  undefined4 uStack_c94;
  undefined4 auStack_c90 [2];
  undefined8 uStack_c88;
  undefined8 uStack_c80;
  undefined8 uStack_c78;
  undefined8 uStack_c70;
  undefined8 uStack_c68;
  undefined8 uStack_c60;
  undefined *puStack_c58;
  undefined8 uStack_c50;
  undefined auStack_c48 [16];
  undefined auStack_c38 [16];
  undefined4 uStack_c28;
  uint uStack_c24;
  byte abStack_c20 [1528];
  undefined auStack_628 [1504];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_dd8;
  puStack_c58 = param_6;
  uStack_c60 = param_12;
  uStack_c68 = param_13;
  uStack_c70 = param_14;
  uStack_c78 = param_15;
  uStack_c80 = param_16;
  uStack_ce8 = param_32;
  uStack_c88 = param_18;
  sStack_cd0 = -1;
  uStack_cf0 = param_31;
  uStack_cf8 = param_30;
  uStack_d00 = param_29;
  uStack_d08 = param_28;
  uStack_d10 = param_26;
  uStack_d18 = param_25;
  uStack_d20 = param_24;
  uStack_d28 = param_23;
  uStack_d30 = param_22;
  uStack_d38 = param_21;
  uStack_d40 = param_20;
  uStack_d48 = param_19;
  pbStack_cc8 = (byte *)0x0;
  uStack_ccc = 0;
  pbStack_cb2 = (byte *)0x0;
  uStack_ca8 = 0;
  uStack_ca6 = 0;
  uStack_ca4 = 0;
  uStack_ca2 = 0;
  uStack_cc0 = 0;
  auStack_c90[0] = 0;
  uStack_d50 = param_18;
  uStack_d58 = param_17;
  uStack_d60 = param_16;
  uStack_d68 = param_15;
  uStack_d70 = param_14;
  uStack_d78 = param_13;
  uStack_d80 = param_12;
  uStack_d88 = param_11;
  uStack_d90 = param_10;
  uStack_d98 = param_9;
  uStack_da0 = param_8;
  uStack_da8 = param_7;
  auStack_c48 = ZEXT816(0);
  auStack_c38 = ZEXT816(0);
  puStack_db0 = param_6;
  uStack_db8 = (undefined4 *)CONCAT62(uStack_db8._2_6_,param_5);
  cStack_cd8 = param_2;
  uStack_c98 = param_4;
  uStack_c94 = param_3;
  uStack_c50 = param_1;
  func_0x(&sStack_cd0,auStack_628,param_3,param_4);
  if (sStack_cd0 == 0) {
    uVar11 = uStack_ccc;
    if (uStack_ccc == 0) {
      uVar10 = uStack_cc0 & 0xffffffff;
      uStack_cce = 0;
      uVar11 = (uint)uStack_cc0;
      if ((*pbStack_cc8 & 0x10) != 0) {
        uVar11 = (uint)uStack_cc0 + 2 + (*(ushort *)(pbStack_cc8 + uVar10) + 7 >> 3);
        uVar10 = (ulonglong)uVar11;
      }
      uStack_cc0 = CONCAT44(uVar11,(uint)uStack_cc0);
      uStack_cb8 = (uint)uVar10;
      if ((*pbStack_cc8 & 0x20) == 0) {
        uStack_cb4 = 0;
        uStack_ccc = uStack_cb8;
      }
      else {
        puVar12 = (ushort *)(pbStack_cc8 + uVar10);
        uStack_cb4 = *puVar12;
        if (uStack_cb4 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_db8 = (undefined4 *)0x0;
              (*_DAT_)(1,0x137a9a8,0x149a678,0x80f);
            }
          }
          func_0x(pbStack_cc8,3);
        }
        uStack_cb8 = uStack_cc0._4_4_ + 2 + (uint)uStack_cb4 * 2;
        if (0x1f9e < uStack_cb8) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar1 != 0 &&
              ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 &&
               (*(char *)(lVar1 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_db8 = (undefined4 *)0x0;
              (*_DAT_)(1,0x137a9a8,0x149a678,0x816);
            }
          }
          func_0x(pbStack_cc8,4);
        }
        uVar16 = (ulonglong)uStack_cb4;
        uStack_ccc = puVar12[uVar16] & 0x7fff;
        if (uStack_ccc < uStack_cb8) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar1 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar1 != 0)) &&
             ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0')
              ))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_db8 = (undefined4 *)0x0;
              (*_DAT_)(1,0x137a9a8,0x149a678,0x81d);
            }
          }
          func_0x(pbStack_cc8,4);
          uVar16 = (ulonglong)uStack_cb4;
        }
        uVar15 = (ulonglong)uStack_cb8;
        uVar10 = (ulonglong)uStack_ccc;
        do {
          if (-1 < (short)puVar12[(ulonglong)((int)uVar16 - 1) + 1]) break;
          if ((int)uVar16 == 1) {
            uVar7 = 1;
            uVar14 = uVar15;
LAB_:
            if ((*(ushort *)(pbStack_cc8 + uVar7 * 2 + (uStack_cc0 >> 0x20)) & 0x7fff) <
                (uint)uVar14) goto LAB_;
          }
          else {
            uVar14 = (ulonglong)
                     (*(ushort *)(pbStack_cc8 + uVar16 * 2 + ((uStack_cc0 >> 0x20) - 2)) & 0x7fff);
            uVar7 = uVar16;
            if ((uint)uVar15 <=
                (*(ushort *)(pbStack_cc8 + uVar16 * 2 + ((uStack_cc0 >> 0x20) - 2)) & 0x7fff))
            goto LAB_;
LAB_:
            func_0x(pbStack_cc8,7);
            uVar16 = (ulonglong)uStack_cb4;
            uVar15 = (ulonglong)uStack_cb8;
            uVar10 = (ulonglong)uStack_ccc;
          }
          uVar11 = (uint)uVar10;
          if (((uint)uVar14 < (uint)uVar15) || (uVar11 < (uint)uVar14)) goto LAB_;
          if (*(ushort *)(pbStack_cc8 + uVar14) == 5) {
            uStack_cce = uStack_cce | 2;
            uStack_cb4 = (short)uVar16 - 1;
            uStack_ca6 = (undefined2)uVar14;
            if ((*(ushort *)(pbStack_cc8 + (uVar14 & 0xffff) + 2) >> 0xe & 1) == 0) {
              uStack_ca4 = uStack_ca4 & 0xc7ff;
            }
            else {
              uStack_ca4 = uStack_ca4 ^
                           (uStack_ca4 ^ *(ushort *)(pbStack_cc8 + (uVar14 & 0xffff) + 2)) & 0x3800;
            }
            uStack_ca4 = (uStack_ca4 ^ *(ushort *)(pbStack_cc8 + (uVar14 & 0xffff) + 2)) & 0x7ff ^
                         uStack_ca4;
            break;
          }
          if (*(ushort *)(pbStack_cc8 + uVar14) < 0x400) break;
          uStack_cce = uStack_cce | 1;
          uStack_cb4 = (short)uVar16 - 1;
          uVar16 = (ulonglong)uStack_cb4;
        } while (uStack_cb4 != 0);
      }
      iVar13 = 0;
      if ((*pbStack_cc8 & 0x40) == 0) {
        uStack_caa = 0;
        uStack_ca8 = 0;
      }
      else {
        uStack_caa = (undefined2)uVar10;
        uStack_ca8 = (undefined2)(uVar10 >> 0x10);
        uStack_ccc = (int)uVar10 + 0xe;
        puVar4 = (ulonglong *)func_0x(&uStack_cce);
        uVar8 = (ushort)(*puVar4 >> 0x30);
        uVar9 = uVar8;
        if ((((uint)(int)(short)uVar8 >> 1 ^ (int)(short)uVar8) & 0x2000) != 0) {
          uVar9 = uVar8 & 0xdfff;
          if ((uVar8 >> 0xe & 1) != 0) {
            uVar9 = uVar8 | 0x2000;
          }
        }
        if (uVar9 == 0xfffc) {
          iVar13 = (int)((*puVar4 >> 0x20 & 0xffff) >> 5);
        }
        uStack_ccc = uStack_ccc + iVar13;
        uVar10 = (ulonglong)uStack_ccc;
      }
      uVar11 = (uint)uVar10;
      if ((pbStack_cb2 != (byte *)0x0) && (pbStack_cb2 < pbStack_cc8 + uVar10)) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar1 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar1 != 0 &&
             (lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0)) &&
            (*(char *)(lVar1 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_db8 = (undefined4 *)0x0;
            (*_DAT_)(1,0x137a9a8,0x149a678,0x877);
          }
        }
        func_0x(pbStack_cc8,0x12);
        uVar11 = uStack_ccc;
      }
      if (0x3f3b < uVar11 - 1) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar1 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar1 != 0 &&
            ((lVar1 = *(longlong *)(lVar1 + 0x60), lVar1 != 0 && (*(char *)(lVar1 + 0x499) != '\0'))
            )))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_db8 = (undefined4 *)0x0;
            (*_DAT_)(1,0x137a9a8,0x149a678,0x87c);
          }
        }
        func_0x(pbStack_cc8,5);
        uVar11 = uStack_ccc;
      }
    }
LAB_:
    if (uVar11 < 9) {
      bVar6 = *pbStack_cc8 & 0xe;
joined_r0x00100851:
      if ((bVar6 == 0) || (bVar6 == 0xc)) {
        uVar11 = 9;
      }
    }
  }
  else {
    if (uStack_ccc == 0) {
      func_0x(&uStack_cce);
    }
    uVar11 = uStack_ccc;
    if (uStack_ccc < 9) {
      bVar6 = *pbStack_cc8 & 0x1c;
      goto joined_r0x00100851;
    }
  }
  func_0x(&uStack_c24,0,0x5fc);
  iVar13 = 0x600;
  uStack_c28 = 4;
  if (cStack_cd8 == '\0') {
    iVar13 = uVar11 + 8;
  }
  func_0x(abStack_c20,0x5f8,pbStack_cc8,uVar11);
  uVar2 = uStack_c50;
  uVar10 = 0xffffffff;
  uStack_c24 = 0xffffffff;
  uVar16 = (ulonglong)(iVar13 - 8U);
  pbVar17 = abStack_c20;
  if (iVar13 - 8U != 0) {
    do {
      bVar6 = *pbVar17;
      pbVar17 = pbVar17 + 1;
      uStack_c24 = (uint)uVar10 >> 8 ^ *(uint *)(((bVar6 ^ uVar10) & 0xff) * 4 + 0x1116b60);
      uVar10 = (ulonglong)uStack_c24;
      uVar16 = uVar16 - 1;
    } while (uVar16 != 0);
  }
  plVar5 = (longlong *)func_0x(uStack_c50);
  if (plVar5 != (longlong *)0x0) {
    iVar3 = (**(code **)(*plVar5 + 0xc0))(plVar5,uVar2,iVar13);
    if (iVar3 == 0) goto LAB_;
    plVar5 = (longlong *)func_0x(uVar2);
    if (plVar5 != (longlong *)0x0) {
      puStack_db0 = auStack_c48;
      uStack_db8 = auStack_c90;
      iVar13 = (**(code **)(*plVar5 + 0xe0))(plVar5,uVar2,&uStack_c28,iVar13);
      if (iVar13 == 0) goto LAB_;
      plVar5 = (longlong *)func_0x(uVar2);
      if (plVar5 != (longlong *)0x0) {
        (**(code **)(*plVar5 + 200))(plVar5,uVar2);
        goto LAB_;
      }
    }
  }
  (*_DAT_)(0x32);
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_dd8);
  return;
}

