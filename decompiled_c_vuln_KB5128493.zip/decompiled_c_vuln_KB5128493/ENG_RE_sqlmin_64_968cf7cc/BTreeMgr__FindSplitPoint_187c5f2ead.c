
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,undefined4 param_3)

{
  ushort uVar1;
  short sVar2;
  undefined auStack_2c8 [32];
  undefined8 uStack_2a8;
  undefined4 uStack_298;
  undefined4 uStack_280;
  undefined4 uStack_278;
  ushort uStack_26c;
  int iStack_268;
  undefined4 uStack_264;
  undefined4 uStack_260;
  int iStack_25c;
  undefined4 uStack_258;
  undefined8 uStack_250;
  undefined2 uStack_e0;
  undefined4 uStack_dc;
  byte *pbStack_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c2;
  undefined2 uStack_ba;
  undefined2 uStack_b8;
  undefined6 uStack_b6;
  undefined4 uStack_ac;
  ulonglong uStack_30;
  
  uStack_30 = _DAT_ ^ (ulonglong)auStack_2c8;
  uStack_e0 = 0xffff;
  pbStack_d8 = (byte *)0x0;
  uStack_dc = 0;
  uStack_c2 = 0;
  uStack_b8 = 0;
  uStack_b6 = 0;
  uStack_d0 = 0;
  uStack_ac = 0xffffffff;
  uStack_298 = 0;
  if (*(ushort *)(param_2 + 0x1c) < 3) {
    iStack_268 = 0;
  }
  else {
    iStack_268 = *(ushort *)(param_2 + 0x1c) - 2;
  }
  sVar2 = 1 << ((byte)*(undefined2 *)(param_2 + 4) & 2);
  uVar1 = *(ushort *)(param_2 + 0x16);
  uStack_26c = sVar2 + -1 + *(short *)(*(longlong *)(**(longlong **)(param_1 + 8) + 8) + 0xb4) &
               -sVar2;
  uStack_280 = param_3;
  if (uVar1 < 3) {
    uStack_2a8 = 0;
    (*_DAT_)(1,0x27f86d8,0x27cf248,0x1727);
    uVar1 = *(ushort *)(param_2 + 0x16);
  }
  if (uVar1 == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(param_1 + 0x14c) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (-1 < *(char *)(param_2 + 2)) {
    uStack_278 = 0xfd0;
    uStack_264 = 0xffffffff;
    uStack_258 = 0xffffffff;
    uStack_260 = 0;
    iStack_25c = 0x1f9e - *(int *)(*(longlong *)(**(longlong **)(param_1 + 8) + 8) + 0xb4);
    if (*(short *)(param_2 + 0x16) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_250 = 0;
    uStack_ac = 0;
    if (-1 < *(char *)(param_2 + 2)) {
      pbStack_d8 = (byte *)((ulonglong)*(ushort *)(param_2 + 0x1ffe) + param_2);
      if ((*pbStack_d8 & 1) == 0) {
        uStack_e0 = 0;
        uStack_dc = 0;
        uStack_ba = 0;
        uStack_b8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010020d */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_d8 & 0xe) * 4 + 0xfef8c) - 0xf23f0)
        )(0x23c7438,(longlong)(int)(*pbStack_d8 & 0xe),0);
        return;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

