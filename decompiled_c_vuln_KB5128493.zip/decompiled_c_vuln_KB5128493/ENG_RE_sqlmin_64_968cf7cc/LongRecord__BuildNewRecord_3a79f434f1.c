
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00100386) */
/* WARNING: Removing unreachable block (ram,0x01d205cf) */
/* WARNING: Removing unreachable block (ram,0x00113134) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4)

{
  uint *puVar1;
  byte bVar2;
  char cVar3;
  undefined4 uVar4;
  undefined *puVar5;
  uint *puVar6;
  undefined2 *puVar7;
  byte *pbVar8;
  undefined8 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  uint uVar12;
  uint uVar13;
  longlong lVar14;
  int iVar15;
  ushort uVar16;
  undefined8 unaff_RBX;
  short *psVar17;
  longlong lVar18;
  undefined *puVar19;
  undefined8 *puVar20;
  uint uVar21;
  ulonglong uVar22;
  undefined4 *puVar23;
  longlong lVar24;
  short *psVar25;
  ulonglong uStackX_8;
  short *psStackX_10;
  longlong alStackX_18 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  puVar19 = &stack0xffffffffffffffc8 + lVar14;
  puVar1 = (uint *)(&stack0xfffffffffffffff8 + lVar14);
  *(undefined8 *)(&stack0x00000170 + lVar14) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002190 + lVar14) = unaff_RBX;
  *(ulonglong *)(&stack0x00002138 + lVar14) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined4 *)(&stack0x00000058 + lVar14) = param_4;
  *(undefined8 *)(&stack0x00000118 + lVar14) = param_3;
  *(undefined4 *)((longlong)&uStackX_8 + lVar14) = param_2;
  *(undefined8 *)(&stack0x00000088 + lVar14) = param_1;
  *(undefined4 *)(&stack0x00000028 + lVar14) = *(undefined4 *)(&stack0x000021b0 + lVar14);
  iVar15 = *(int *)(&stack0x000021a8 + lVar14);
  psVar25 = *(short **)(&stack0x000021c0 + lVar14);
  *(short **)(&stack0x00000060 + lVar14) = psVar25;
  lVar24 = *(longlong *)(&stack0x000021c8 + lVar14);
  *(longlong *)(&stack0x00000130 + lVar14) = lVar24;
  *(undefined8 *)(&stack0x00000050 + lVar14) = *(undefined8 *)(&stack0x000021d0 + lVar14);
  *(undefined8 *)(&stack0x00000120 + lVar14) = *(undefined8 *)(&stack0x000021d8 + lVar14);
  *(undefined8 *)(&stack0x000000a8 + lVar14) = *(undefined8 *)(&stack0x000021e8 + lVar14);
  *(undefined8 *)(&stack0x00000070 + lVar14) = *(undefined8 *)(&stack0x000021f0 + lVar14);
  *(undefined8 *)(&stack0x00000040 + lVar14) = *(undefined8 *)(&stack0x000021f8 + lVar14);
  *(undefined8 *)((longlong)&psStackX_10 + lVar14) = *(undefined8 *)(&stack0x00002200 + lVar14);
  puVar5 = *(undefined **)(&stack0x00002208 + lVar14);
  *(undefined8 *)(&stack0x00000068 + lVar14) = *(undefined8 *)(&stack0x00002220 + lVar14);
  *(undefined8 *)(&stack0x000000b0 + lVar14) = *(undefined8 *)(&stack0x00002228 + lVar14);
  *(undefined8 *)(&stack0x000000f8 + lVar14) = *(undefined8 *)(&stack0x00002238 + lVar14);
  *(undefined4 **)(&stack0x000000f0 + lVar14) = *(undefined4 **)(&stack0x00002240 + lVar14);
  puVar6 = *(uint **)(&stack0x00002248 + lVar14);
  *(uint **)(&stack0x00000110 + lVar14) = puVar6;
  *(undefined8 *)(&stack0x00000128 + lVar14) = *(undefined8 *)(&stack0x00002258 + lVar14);
  *(undefined8 *)(&stack0x00000108 + lVar14) = *(undefined8 *)(&stack0x00002260 + lVar14);
  *(undefined8 *)(&stack0x00000100 + lVar14) = *(undefined8 *)(&stack0x00002268 + lVar14);
  *(undefined8 *)((longlong)alStackX_18 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar14) = 0;
  *(undefined2 *)(&stack0x00000138 + lVar14) = 0xffff;
  *(undefined8 *)(&stack0x00000140 + lVar14) = 0;
  *(undefined4 *)(&stack0x0000013c + lVar14) = 0;
  *(undefined8 *)(&stack0x00000156 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000160 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000148 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000034 + lVar14) = 0;
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar14) = 1;
  *(undefined8 *)(&stack0x000000a0 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000048 + lVar14) = 0;
  **(undefined4 **)(&stack0x00002240 + lVar14) = 0;
  if (lVar24 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)(&stack0x000000d8 + lVar14) = 0;
  *(undefined8 *)(&stack0x000000b8 + lVar14) = 0;
  *(short **)(&stack0x000000e8 + lVar14) = psVar25 + 1;
  if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1001d0;
  uVar12 = func_0x(psVar25 + 1);
  uVar13 = uVar12;
  if (uVar12 <= (uint)-iVar15) {
    uVar13 = -iVar15;
  }
  bVar2 = **(byte **)(psVar25 + 4);
  if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(uint *)((longlong)alStackX_18 + lVar14 + -0x14) = uVar13;
  if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
    *(undefined8 *)(&stack0x000000a0 + lVar14) =
         *(undefined8 *)(*(longlong *)(&stack0x00000050 + lVar14) + 0x28);
    iVar15 = *(int *)(*(longlong *)(&stack0x00000050 + lVar14) + 0x30);
    *(int *)(&stack0x00000048 + lVar14) = iVar15;
    *(uint *)((longlong)alStackX_18 + lVar14 + -0x14) = uVar13;
    if (iVar15 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10022f;
  uVar13 = func_0x(psVar25);
  *(uint *)((longlong)alStackX_18 + lVar14 + -0x18) = uVar13;
  *(uint *)(&stack0x0000002c + lVar14) = uVar13;
  *puVar1 = *(int *)(&stack0x00000058 + lVar14) + uVar13;
  *(undefined4 *)(&stack0x00000030 + lVar14) = 9;
  if (puVar6 == (uint *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(psVar25 + 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar21 = *(uint *)(psVar25 + 2);
  if (uVar21 < 9) {
    if ((**(byte **)(psVar25 + 4) & 0xe) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar21 = 9;
  }
  *puVar6 = uVar21;
  puVar6[1] = uVar12;
  puVar6[2] = uVar13;
  *(undefined8 *)(puVar6 + 3) = 0;
  if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar7 = *(undefined2 **)((longlong)&psStackX_10 + lVar14);
  *puVar7 = 0;
  *(undefined2 **)((longlong)alStackX_18 + lVar14 + 8) = puVar7 + 1;
  *(undefined **)(puVar7 + 4) = puVar5;
  *(undefined4 *)(puVar7 + 8) = *(undefined4 *)(&stack0x000021b8 + lVar14);
  puVar7[0xe] = 0;
  puVar7[1] = 0;
  *(undefined4 *)(puVar7 + 0x13) = 0;
  if ((**(byte **)(psVar25 + 4) & 0xe) == 6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar5 = 0;
  *(undefined *)(*(longlong *)(puVar7 + 4) + 1) = 0;
  *(short *)(*(longlong *)(puVar7 + 4) + 2) = (short)*(undefined4 *)(puVar7 + 8);
  uVar13 = *(uint *)(psVar25 + 8);
  if (*(uint *)(puVar7 + 8) <= uVar13) {
    uVar13 = *(uint *)(puVar7 + 8);
  }
  lVar24 = *(longlong *)(psVar25 + 4);
  lVar18 = *(longlong *)(puVar7 + 4);
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100340;
  func_0x(lVar18 + 4,lVar24 + 4,uVar13 - 4);
  uVar13 = *(uint *)(&stack0x00000028 + lVar14);
  if (uVar13 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  **(byte **)(puVar7 + 4) = **(byte **)(puVar7 + 4) | 0x10;
  uVar12 = *(uint *)(puVar7 + 8);
  iVar15 = uVar12 + 2 + (uVar13 + 7 >> 3);
  *(int *)(puVar7 + 10) = iVar15;
  pbVar8 = *(byte **)(psVar25 + 4);
  if ((*pbVar8 & 0x10) == 0) {
    *(short *)(*(longlong *)(puVar7 + 4) + (ulonglong)uVar12) = (short)uVar13;
    uVar16 = 1;
    uVar12 = 1;
    if (uVar13 != 0) {
      do {
        uVar22 = (ulonglong)(uVar12 - 1 >> 3);
        *(byte *)(uVar22 + 2 + (longlong)*(int *)(puVar7 + 8) + *(longlong *)(puVar7 + 4)) =
             *(byte *)(uVar22 + 2 + (longlong)*(int *)(puVar7 + 8) + *(longlong *)(puVar7 + 4)) |
             (byte)(1 << (uVar12 - 1 & 7));
        uVar16 = uVar16 + 1;
        uVar12 = (uint)uVar16;
      } while (uVar12 <= uVar13);
    }
    psVar17 = *(short **)((longlong)&psStackX_10 + lVar14);
    *(undefined4 *)(puVar7 + 0xc) = *(undefined4 *)(puVar7 + 10);
    *(undefined4 *)(puVar7 + 2) = *(undefined4 *)(puVar7 + 10);
  }
  else {
    if (*(ushort *)(pbVar8 + *(uint *)(psVar25 + 8)) != uVar13) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar13 = *(uint *)(psVar25 + 8);
    lVar24 = *(longlong *)(puVar7 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10040a;
    func_0x(lVar24 + (ulonglong)uVar12,pbVar8 + uVar13,iVar15 - uVar12);
    psVar17 = *(short **)((longlong)&psStackX_10 + lVar14);
    *(undefined4 *)(puVar7 + 0xc) = *(undefined4 *)(puVar7 + 10);
    *(undefined4 *)(puVar7 + 2) = *(undefined4 *)(puVar7 + 10);
  }
  if (*psVar17 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(puVar7 + 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(uint *)(puVar7 + 2) < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  **(uint **)(&stack0x00000068 + lVar14) = *(uint *)(puVar7 + 2);
  **(undefined4 **)(&stack0x000000b0 + lVar14) = 0;
  uVar13 = *(uint *)((longlong)alStackX_18 + lVar14 + -0x14);
  if (uVar13 != 0) {
    uVar22 = (ulonglong)uVar13 * 0x20;
    if (uVar22 + 0xf <= uVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10048a;
    func_0x();
    lVar24 = -uVar22;
    puVar19 = &stack0xffffffffffffffc8 + lVar24 + lVar14;
    *(undefined **)((longlong)alStackX_18 + lVar14) = &stack0xfffffffffffffff8 + lVar24 + lVar14;
    *(undefined8 *)((longlong)&uStack_40 + lVar24 + lVar14) = 0x1004a7;
    func_0x(&stack0xfffffffffffffff8 + lVar24 + lVar14,0,uVar13 << 5);
    if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(psVar25 + 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar12 = (uint)(ushort)psVar25[0xe];
    if (uVar13 <= (ushort)psVar25[0xe]) {
      uVar12 = uVar13;
    }
    if (uVar12 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar9 = *(undefined8 *)((longlong)alStackX_18 + lVar14);
    *(undefined8 *)((longlong)&uStack_40 + lVar24 + lVar14) = 0x1004f0;
    func_0x(uVar9,0,uVar13 * 0x20);
  }
  if (*puVar1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)alStackX_18 + lVar14 + -0x14) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar20 = *(undefined8 **)(&stack0x00000070 + lVar14);
  if (puVar20 != (undefined8 *)0x0) {
    uVar4 = *(undefined4 *)(puVar20 + 1);
    uVar9 = *puVar20;
    *(undefined8 *)(puVar19 + -8) = 0x100530;
    func_0x(uVar9,0,uVar4);
  }
  if (*(int *)(&stack0x00002230 + lVar14) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar13 = 0;
  **(undefined4 **)(&stack0x00000040 + lVar14) = 0;
  psVar25 = *(short **)((longlong)&psStackX_10 + lVar14);
  if (*(longlong *)(&stack0x000000a0 + lVar14) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar1 = 0;
  uVar12 = *(uint *)((longlong)&uStackX_8 + lVar14);
  if (uVar12 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar24 = *(longlong *)(&stack0x00000118 + lVar14) + 0x38;
  uVar22 = (ulonglong)uVar12;
  *(ulonglong *)((longlong)&uStackX_8 + lVar14) = (ulonglong)uVar12;
  do {
    if (*(char *)(lVar24 + 8) != '\0') {
      if (*(int *)(lVar24 + -0x38) < 1) {
        if ((-1 < *(int *)(lVar24 + -0x38)) ||
           ((*(ushort *)(*(longlong *)(lVar24 + 0x10) + 0xc) & 0x400) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        lVar18 = (ulonglong)uVar13 * 0x40 +
                 *(longlong *)(*(longlong *)(&stack0x000000a8 + lVar14) + 8);
        uVar12 = *(uint *)(lVar18 + 8);
        if ((*(ushort *)(lVar18 + 0xc) != 0) &&
           ((uint)*(ushort *)(lVar18 + 0xc) <= *(uint *)(&stack0x00000028 + lVar14))) {
          if ((*(byte *)(lVar18 + 0x18) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar21 = *(ushort *)(lVar18 + 0xc) - 1;
          uVar22 = (ulonglong)(uVar21 >> 3);
          *(byte *)((longlong)*(int *)(psVar25 + 8) + *(longlong *)(psVar25 + 4) + 2 + uVar22) =
               *(byte *)((longlong)*(int *)(psVar25 + 8) + *(longlong *)(psVar25 + 4) + 2 + uVar22)
               & ~(byte)(1 << (uVar21 & 7));
        }
        puVar23 = (undefined4 *)
                  ((longlong)(int)~uVar12 * 0x20 + *(longlong *)((longlong)alStackX_18 + lVar14));
        if ((*(byte *)(puVar23 + 3) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((*(int *)(&stack0x00000034 + lVar14) == 0) &&
           (*(uint *)(lVar18 + 0x28) <= (uint)puVar23[2])) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined4 *)(&stack0x00000034 + lVar14) = 1;
        uVar4 = *(undefined4 *)(lVar18 + 0x24);
        uVar10 = *(undefined4 *)(lVar18 + 0x28);
        uVar11 = *(undefined4 *)(lVar18 + 0x2c);
        *puVar23 = *(undefined4 *)(lVar18 + 0x20);
        puVar23[1] = uVar4;
        puVar23[2] = uVar10;
        puVar23[3] = uVar11;
        uVar4 = *(undefined4 *)(lVar18 + 0x34);
        uVar10 = *(undefined4 *)(lVar18 + 0x38);
        uVar11 = *(undefined4 *)(lVar18 + 0x3c);
        puVar23[4] = *(undefined4 *)(lVar18 + 0x30);
        puVar23[5] = uVar4;
        puVar23[6] = uVar10;
        puVar23[7] = uVar11;
        uVar13 = uVar13 + 1;
        *puVar1 = uVar13;
      }
      else {
        uVar13 = *(uint *)(lVar24 + 8);
        if ((uVar13 >> 10 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((*(byte *)(*(longlong *)(lVar24 + 0x10) + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        cVar3 = *(char *)(*(longlong *)(*(longlong *)(&stack0x00000050 + lVar14) + 0x18) +
                         *(longlong *)(lVar24 + -8));
        if (cVar3 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((uVar13 & 0x8000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((uVar13 >> 8 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((*(byte *)(*(longlong *)(lVar24 + 0x10) + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar12 = *(uint *)(*(longlong *)(*(longlong *)(&stack0x00000050 + lVar14) + 0x18) +
                          *(longlong *)(*(longlong *)(lVar24 + 0x10) + 0x18));
        if ((uVar13 & 0x48000) == 0x48000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((*(byte *)(*(longlong *)(lVar24 + 0x10) + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        puVar20 = (undefined8 *)
                  (*(longlong *)(lVar24 + -0x10) +
                  *(longlong *)(*(longlong *)(&stack0x00000050 + lVar14) + 0x18));
        if ((uVar13 >> 0xb & 1) != 0) {
          puVar20 = (undefined8 *)*puVar20;
        }
        uVar16 = *(ushort *)(lVar24 + -0x34);
        if ((uVar16 != 0) && ((uint)uVar16 <= *(uint *)(&stack0x00000028 + lVar14))) {
          if (cVar3 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar22 = (ulonglong)(uVar16 - 1 >> 3);
          *(byte *)(uVar22 + 2 + (longlong)*(int *)(psVar25 + 8) + *(longlong *)(psVar25 + 4)) =
               *(byte *)(uVar22 + 2 + (longlong)*(int *)(psVar25 + 8) + *(longlong *)(psVar25 + 4))
               & ~(byte)(1 << (uVar16 - 1 & 7));
        }
        if (puVar20 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(char *)(lVar24 + 8) != '\x01') {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar16 = *(ushort *)(lVar24 + 4);
        if (uVar16 < uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        iVar15 = *(int *)(lVar24 + -0x38);
        lVar18 = *(longlong *)(*(longlong *)((longlong)&psStackX_10 + lVar14) + 8);
        if (uVar12 != 0) {
          *(undefined8 *)(puVar19 + -8) = 0x1006f8;
          func_0x(iVar15 + lVar18,puVar20,uVar12);
        }
        if (uVar16 != uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar13 = *puVar1;
      }
      uVar22 = *(ulonglong *)((longlong)&uStackX_8 + lVar14);
    }
    lVar24 = lVar24 + 0x50;
    uVar22 = uVar22 - 1;
    *(ulonglong *)((longlong)&uStackX_8 + lVar14) = uVar22;
    psVar25 = *(short **)((longlong)&psStackX_10 + lVar14);
    if (uVar22 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  } while( true );
}

