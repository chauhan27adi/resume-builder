
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2,longlong *param_3,undefined8 param_4)

{
  char cVar1;
  short sVar2;
  code *pcVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  byte bVar6;
  int iVar7;
  int iVar8;
  longlong lVar9;
  short *psVar10;
  longlong lVar11;
  ulonglong *puVar12;
  undefined8 uVar13;
  longlong lVar14;
  ushort uVar15;
  uint uVar16;
  byte *pbVar17;
  ushort uVar18;
  uint uVar19;
  uint uVar20;
  ulonglong uVar21;
  longlong lVar22;
  uint uVar23;
  ushort *puVar24;
  ulonglong uVar25;
  ushort *puVar26;
  longlong unaff_GS_OFFSET;
  bool bVar27;
  undefined8 uStackX_8;
  uint uStackX_10;
  ushort uStackX_14;
  ulonglong uStackX_16;
  undefined auStackX_1e [4];
  ushort auStackX_22 [3];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  *(undefined8 *)(&stack0x00000080 + lVar9) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002048 + lVar9) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9);
  *(undefined8 *)(&stack0x00000048 + lVar9) = param_4;
  *(longlong **)(&stack0x00000070 + lVar9) = param_3;
  uVar19 = (uint)param_2;
  uVar21 = param_2 & 0xffffffff;
  *(uint *)(&stack0x00000050 + lVar9) = uVar19;
  *(longlong *)(&stack0x00000058 + lVar9) = param_1;
  lVar14 = *(longlong *)(&stack0x000020b8 + lVar9);
  *(longlong *)(&stack0x00000068 + lVar9) = lVar14;
  *(undefined8 *)(&stack0x00000060 + lVar9) = *(undefined8 *)(&stack0x000020c0 + lVar9);
  *(undefined2 *)(&stack0xfffffffffffffff8 + lVar9) = 0xffff;
  *(undefined8 *)(auStackX_1e + lVar9 + -0x1e) = 0;
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar9) = 0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar9 + 2) = 0;
  *(undefined8 *)(auStackX_1e + lVar9 + 2) = 0;
  *(undefined8 *)((longlong)&uStackX_8 + lVar9) = 0;
  *(undefined4 *)(&stack0x00000034 + lVar9) = 0;
  *(undefined4 *)(&stack0x00000038 + lVar9) = 0;
  *(undefined4 *)(&stack0x0000003c + lVar9) = 0;
  cVar1 = *(char *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 0x30) + 0x1cde);
  uVar23 = uVar19 & 0xc2;
  *(uint *)(&stack0x00000040 + lVar9) = uVar23;
  if ((lVar14 == 0) || (iVar8 = 1, (param_2 & 8) == 0)) {
    iVar8 = 0;
  }
  *(int *)(&stack0x00000030 + lVar9) = iVar8;
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000f2;
  psVar10 = (short *)func_0x(param_3,1);
  if (cVar1 != '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100107;
    iVar7 = func_0x(param_3,0,0);
    if (iVar7 != 0) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10012f;
      (*_DAT_)(1,0x18d9738,0x18d0f28,0x1d5b);
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10013e;
    psVar10 = (short *)func_0x(param_3,1);
    if (psVar10 == (short *)0x0) {
      pcVar3 = *(code **)(*param_3 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10014f;
      (*pcVar3)(param_3);
      goto LAB_;
    }
  }
  if (((((param_2 & 0x10) != 0) || ((param_2 & 0xc2) != 0)) || (iVar8 != 0)) ||
     (iVar8 = 0, (uVar19 >> 8 & 1) != 0)) {
    sVar2 = *psVar10;
    *(short *)(&stack0xfffffffffffffff8 + lVar9) = sVar2;
    if (sVar2 == 0) {
      puVar24 = (ushort *)(psVar10 + 1);
      if (*(int *)(psVar10 + 2) == 0) {
        *puVar24 = 0;
        uVar23 = *(uint *)(psVar10 + 8);
        uVar21 = (ulonglong)uVar23;
        *(uint *)(psVar10 + 10) = uVar23;
        pbVar17 = *(byte **)(psVar10 + 4);
        bVar6 = *pbVar17;
        if ((bVar6 & 0x10) != 0) {
          uVar23 = uVar23 + (*(ushort *)(pbVar17 + uVar21) + 7 >> 3) + 2;
          uVar21 = (ulonglong)uVar23;
          *(uint *)(psVar10 + 10) = uVar23;
          bVar6 = *pbVar17;
        }
        if ((bVar6 & 0x20) == 0) {
          *(int *)(psVar10 + 2) = (int)uVar21;
          psVar10[0xe] = 0;
          *(int *)(psVar10 + 0xc) = (int)uVar21;
        }
        else {
          puVar26 = (ushort *)(pbVar17 + uVar21);
          uVar18 = *puVar26;
          psVar10[0xe] = uVar18;
          if (uVar18 == 0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar14 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar14 != 0 &&
                ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                 (*(char *)(lVar14 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10025c;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100282;
                (*_DAT_)(1,0x174cb58,0x186c828,0x80f);
              }
            }
            uVar13 = *(undefined8 *)(psVar10 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100290;
            func_0x(uVar13,3);
            uVar21 = (ulonglong)*(uint *)(psVar10 + 10);
            uVar18 = psVar10[0xe];
          }
          uVar23 = (int)uVar21 + (uVar18 + 1) * 2;
          *(uint *)(psVar10 + 0xc) = uVar23;
          if (0x1f9e < uVar23) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar14 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar14 != 0)) &&
               ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                (*(char *)(lVar14 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10032d;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100353;
                (*_DAT_)(1,0x174cb58,0x186c828,0x816);
              }
            }
            uVar13 = *(undefined8 *)(psVar10 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100361;
            func_0x(uVar13,4);
            uVar18 = psVar10[0xe];
          }
          uVar21 = (ulonglong)uVar18;
          uVar18 = puVar26[uVar21];
          *(uint *)(psVar10 + 2) = uVar18 & 0x7fff;
          if ((uVar18 & 0x7fff) < *(uint *)(psVar10 + 0xc)) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar14 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar14 != 0 &&
                ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                 (*(char *)(lVar14 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003f9;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10041f;
                (*_DAT_)(1,0x174cb58,0x186c828,0x81d);
              }
            }
            uVar13 = *(undefined8 *)(psVar10 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10042d;
            func_0x(uVar13,4);
            uVar21 = (ulonglong)(ushort)psVar10[0xe];
          }
          if ((short)puVar26[(ulonglong)((int)uVar21 - 1) + 1] < 0) {
            do {
              lVar14 = *(longlong *)(psVar10 + 4);
              lVar11 = (ulonglong)*(uint *)(psVar10 + 10) + lVar14;
              if ((int)uVar21 == 1) {
                uVar23 = *(uint *)(psVar10 + 0xc);
                uVar18 = *(ushort *)(lVar11 + uVar21 * 2);
                uVar19 = uVar23;
LAB_:
                if ((uVar18 & 0x7fff) < uVar23) goto LAB_;
              }
              else {
                uVar23 = *(ushort *)(lVar11 + -2 + uVar21 * 2) & 0x7fff;
                uVar19 = *(uint *)(psVar10 + 0xc);
                uVar18 = *(ushort *)(lVar11 + uVar21 * 2);
                if (uVar19 <= uVar23) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004a1;
                func_0x(lVar14,7);
                uVar19 = *(uint *)(psVar10 + 0xc);
                lVar14 = *(longlong *)(psVar10 + 4);
                uVar21 = (ulonglong)(ushort)psVar10[0xe];
              }
              if ((uVar23 < uVar19) || (*(uint *)(psVar10 + 2) < uVar23)) goto LAB_;
              if (*(ushort *)(lVar14 + (ulonglong)uVar23) == 5) {
                *puVar24 = *puVar24 | 2;
                psVar10[0xe] = (short)uVar21 + -1;
                psVar10[0x15] = (short)uVar23;
                lVar14 = (ulonglong)(uVar23 & 0xffff) + *(longlong *)(psVar10 + 4);
                uVar18 = *(ushort *)(lVar14 + 2);
                uVar15 = psVar10[0x16] & 0xc7ff;
                if ((uVar18 & 0x4000) != 0) {
                  uVar15 = uVar18 & 0x3800 | uVar15;
                }
                psVar10[0x16] = uVar15;
                psVar10[0x16] = (uVar15 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar15;
                uVar21 = (ulonglong)*(uint *)(psVar10 + 2);
                pbVar17 = *(byte **)(psVar10 + 4);
                goto LAB_;
              }
              if (*(ushort *)(lVar14 + (ulonglong)uVar23) < 0x400) break;
              *puVar24 = *puVar24 | 1;
              uVar18 = (short)uVar21 - 1;
              psVar10[0xe] = uVar18;
              if ((uVar18 == 0) ||
                 (uVar21 = (ulonglong)uVar18, -1 < (short)puVar26[(ulonglong)(uVar18 - 1) + 1]))
              break;
            } while( true );
          }
          uVar21 = (ulonglong)*(uint *)(psVar10 + 2);
          pbVar17 = *(byte **)(psVar10 + 4);
        }
LAB_:
        if ((*pbVar17 & 0x40) == 0) {
          *(undefined4 *)(psVar10 + 0x13) = 0;
        }
        else {
          *(int *)(psVar10 + 0x13) = *(int *)(psVar10 + 2);
          *(int *)(psVar10 + 2) = *(int *)(psVar10 + 2) + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1005c0;
          puVar12 = (ulonglong *)func_0x(puVar24);
          uVar21 = *puVar12;
          uVar23 = 0;
          uVar18 = (ushort)(uVar21 >> 0x30);
          if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
            if ((uVar21 & 0x4000000000000000) == 0) {
              uVar18 = uVar18 & 0xdfff;
            }
            else {
              uVar18 = uVar18 | 0x2000;
            }
          }
          if (uVar18 == 0xfffc) {
            uVar23 = ((uint)(uVar21 >> 0x20) & 0xffff) >> 5;
          }
          *(uint *)(psVar10 + 2) = *(int *)(psVar10 + 2) + uVar23;
          uVar21 = (ulonglong)*(uint *)(psVar10 + 2);
          pbVar17 = *(byte **)(psVar10 + 4);
        }
        iVar8 = (int)uVar21;
        if ((*(byte **)(psVar10 + 0xf) != (byte *)0x0) &&
           (*(byte **)(psVar10 + 0xf) < pbVar17 + uVar21)) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar14 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), lVar14 != 0 && (lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0))
              && (*(char *)(lVar14 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1006bf;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1006e5;
              (*_DAT_)(1,0x174cb58,0x186c828,0x877);
            }
          }
          uVar13 = *(undefined8 *)(psVar10 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1006f3;
          func_0x(uVar13,0x12);
          iVar8 = *(int *)(psVar10 + 2);
        }
        if (0x3f3b < iVar8 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar14 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), lVar14 != 0 &&
              ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
               (*(char *)(lVar14 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10077e;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              uVar13 = *(undefined8 *)(psVar10 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10078c;
              func_0x(uVar13,5);
              goto LAB_;
            }
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1007b2;
            (*_DAT_)(1,0x174cb58,0x186c828,0x87c);
          }
          uVar13 = *(undefined8 *)(psVar10 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1007c0;
          func_0x(uVar13,5);
        }
      }
LAB_:
      *(undefined4 *)((longlong)&uStackX_8 + lVar9) = *(undefined4 *)(psVar10 + 8);
      *(ushort *)(&stack0xfffffffffffffffa + lVar9) = *puVar24;
      *(undefined4 *)(&stack0xfffffffffffffffc + lVar9) = *(undefined4 *)(psVar10 + 2);
      *(short *)((longlong)&uStackX_14 + lVar9) = psVar10[0xe];
      *(undefined4 *)((longlong)&uStackX_8 + lVar9 + 4) = *(undefined4 *)(psVar10 + 10);
      *(undefined4 *)((longlong)&uStackX_10 + lVar9) = *(undefined4 *)(psVar10 + 0xc);
      *(undefined4 *)(auStackX_1e + lVar9) = *(undefined4 *)(psVar10 + 0x13);
      uVar13 = *(undefined8 *)(psVar10 + 4);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10084f;
      func_0x(&stack0x000000a8 + lVar9,0x1f9e,uVar13);
      *(undefined **)(auStackX_1e + lVar9 + -0x1e) = &stack0x000000a8 + lVar9;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100866;
      iVar8 = func_0x(&stack0xfffffffffffffffa + lVar9);
      if (iVar8 != 0) {
        lVar14 = *(longlong *)(auStackX_1e + lVar9 + -0x1e);
        puVar24 = (ushort *)((ulonglong)*(uint *)((longlong)&uStackX_8 + lVar9 + 4) + lVar14);
        uVar23 = *puVar24 - 1;
        if (((&stack0xfffffffffffffffa)[lVar9] & 1) == 0) {
          uVar23 = (uint)*puVar24;
        }
        uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
        if (uVar23 != 1) {
          uVar19 = puVar24[(longlong)(int)uVar23 + -1] & 0x7fff;
        }
        if ((uVar19 < *(uint *)((longlong)&uStackX_10 + lVar9)) ||
           ((puVar24[(int)uVar23] & 0x7fff) < uVar19)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008c6;
          func_0x(lVar14,7);
          lVar14 = *(longlong *)(auStackX_1e + lVar9 + -0x1e);
        }
        *(short *)(auStackX_1e + lVar9 + 4) = (short)uVar19;
        uVar18 = *(ushort *)(((ulonglong)uVar19 & 0xffff) + 2 + lVar14);
        uVar15 = *(ushort *)(auStackX_1e + lVar9 + 6);
        if ((uVar18 & 0x4000) == 0) {
          uVar15 = uVar15 & 0xc7ff;
        }
        else {
          uVar15 = uVar15 ^ (uVar18 ^ uVar15) & 0x3800;
        }
        *(ushort *)(auStackX_1e + lVar9 + 6) = uVar15;
        *(ushort *)(auStackX_1e + lVar9 + 6) =
             (uVar15 ^ *(ushort *)(((ulonglong)uVar19 & 0xffff) + 2 + lVar14)) & 0x7ff ^ uVar15;
      }
    }
    else if (((*psVar10 == 0) || (*(longlong **)(psVar10 + 8) == (longlong *)0x0)) ||
            (**(longlong **)(psVar10 + 8) == 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10095c;
      func_0x(&stack0xfffffffffffffffa + lVar9,&stack0x000000a8 + lVar9,0x1f9e);
      if (*psVar10 == 0) {
        uVar13 = 0;
      }
      else {
        uVar13 = *(undefined8 *)(psVar10 + 8);
      }
      *(undefined8 *)((longlong)&uStackX_8 + lVar9) = uVar13;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10093e;
      func_0x(&stack0xfffffffffffffff8 + lVar9,&stack0x000000a8 + lVar9,0x1f9e);
    }
    uVar23 = 9;
    if (*(short *)(&stack0xfffffffffffffff8 + lVar9) == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100993;
      func_0x();
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10099a;
      func_0x(&stack0xfffffffffffffffa + lVar9);
    }
    uVar19 = *(uint *)(&stack0xfffffffffffffffc + lVar9);
    uVar21 = (ulonglong)uVar19;
    if (cVar1 == '\0') {
LAB_:
      if (*(short *)(&stack0xfffffffffffffff8 + lVar9) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101786;
        func_0x(&stack0xfffffffffffffffa + lVar9);
      }
      else if ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 2) != 0) {
        if (uVar19 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101997;
          func_0x(&stack0xfffffffffffffffa + lVar9);
        }
        **(byte **)(auStackX_1e + lVar9 + -0x1e) = **(byte **)(auStackX_1e + lVar9 + -0x1e) & 0xfd;
        *(undefined4 *)(&stack0xfffffffffffffffc + lVar9) =
             *(undefined4 *)(&stack0x00000028 + lVar9);
        *(undefined4 *)(&stack0x00000028 + lVar9) = 0;
      }
    }
    else {
      if (*(short *)(&stack0xfffffffffffffff8 + lVar9) == 0) {
        pbVar17 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
        if ((*pbVar17 & 0xe) != 2) {
          if (uVar19 == 0) {
            *(undefined2 *)(&stack0xfffffffffffffffa + lVar9) = 0;
            uVar19 = *(uint *)((longlong)&uStackX_8 + lVar9);
            uVar21 = (ulonglong)uVar19;
            *(uint *)((longlong)&uStackX_8 + lVar9 + 4) = uVar19;
            if ((*pbVar17 & 0x10) != 0) {
              uVar19 = uVar19 + 2 + (*(ushort *)(pbVar17 + uVar21) + 7 >> 3);
              uVar21 = (ulonglong)uVar19;
              *(uint *)((longlong)&uStackX_8 + lVar9 + 4) = uVar19;
            }
            if ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x20) == 0) {
              *(int *)(&stack0xfffffffffffffffc + lVar9) = (int)uVar21;
              *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 0;
              *(int *)((longlong)&uStackX_10 + lVar9) = (int)uVar21;
            }
            else {
              puVar24 = (ushort *)(*(byte **)(auStackX_1e + lVar9 + -0x1e) + uVar21);
              uVar18 = *puVar24;
              *(ushort *)((longlong)&uStackX_14 + lVar9) = uVar18;
              if (uVar18 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar14 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0)) &&
                   ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                    (*(char *)(lVar14 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a97;
                    (*_DAT_)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100abd;
                    (*_DAT_)(1,0x174cb58,0x186c828);
                  }
                }
                uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100acc;
                func_0x(uVar13,3);
                uVar18 = *(ushort *)((longlong)&uStackX_14 + lVar9);
              }
              uVar19 = *(int *)((longlong)&uStackX_8 + lVar9 + 4) + 2 + (uint)uVar18 * 2;
              *(uint *)((longlong)&uStackX_10 + lVar9) = uVar19;
              if (0x1f9e < uVar19) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar14 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0 &&
                    ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                     (*(char *)(lVar14 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b70;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b96;
                    (*_DAT_)(1,0x174cb58,0x186c828,0x816);
                  }
                }
                uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100ba5;
                func_0x(uVar13,4);
                uVar18 = *(ushort *)((longlong)&uStackX_14 + lVar9);
                uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
              }
              uVar25 = (ulonglong)uVar18;
              uVar20 = puVar24[uVar25] & 0x7fff;
              *(uint *)(&stack0xfffffffffffffffc + lVar9) = uVar20;
              if (uVar20 < uVar19) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar14 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0)) &&
                   ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                    (*(char *)(lVar14 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c45;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c6b;
                    (*_DAT_)(1,0x174cb58,0x186c828,0x81d);
                  }
                }
                uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c7a;
                func_0x(uVar13,4);
                uVar25 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar9);
                uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
                uVar20 = *(uint *)(&stack0xfffffffffffffffc + lVar9);
              }
              uVar21 = (ulonglong)uVar20;
              do {
                if (-1 < (short)puVar24[(ulonglong)((int)uVar25 - 1) + 1]) break;
                lVar14 = (ulonglong)*(uint *)((longlong)&uStackX_8 + lVar9 + 4) +
                         *(longlong *)(auStackX_1e + lVar9 + -0x1e);
                uVar20 = uVar19;
                if ((int)uVar25 != 1) {
                  uVar20 = *(ushort *)(lVar14 + -2 + uVar25 * 2) & 0x7fff;
                }
                if ((uVar20 < uVar19) || ((*(ushort *)(lVar14 + uVar25 * 2) & 0x7fff) < uVar20)) {
                  uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100cf9;
                  func_0x(uVar13,7);
                  uVar25 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar9);
                  uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
                  uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
                }
                if ((uVar20 < uVar19) || ((uint)uVar21 < uVar20)) goto LAB_;
                uVar18 = *(ushort *)((ulonglong)uVar20 + *(longlong *)(auStackX_1e + lVar9 + -0x1e))
                ;
                if (uVar18 == 5) {
                  *(ushort *)(&stack0xfffffffffffffffa + lVar9) =
                       *(ushort *)(&stack0xfffffffffffffffa + lVar9) | 2;
                  *(short *)((longlong)&uStackX_14 + lVar9) = (short)uVar25 + -1;
                  *(short *)(auStackX_1e + lVar9 + 4) = (short)uVar20;
                  lVar14 = ((ulonglong)uVar20 & 0xffff) + *(longlong *)(auStackX_1e + lVar9 + -0x1e)
                  ;
                  uVar18 = *(ushort *)(lVar14 + 2);
                  uVar15 = *(ushort *)(auStackX_1e + lVar9 + 6);
                  if ((uVar18 & 0x4000) == 0) {
                    uVar15 = uVar15 & 0xc7ff;
                  }
                  else {
                    uVar15 = uVar15 ^ (uVar18 ^ uVar15) & 0x3800;
                  }
                  *(ushort *)(auStackX_1e + lVar9 + 6) = uVar15;
                  *(ushort *)(auStackX_1e + lVar9 + 6) =
                       (uVar15 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar15;
                  break;
                }
                if (uVar18 < 0x400) break;
                *(ushort *)(&stack0xfffffffffffffffa + lVar9) =
                     *(ushort *)(&stack0xfffffffffffffffa + lVar9) | 1;
                uVar18 = (short)uVar25 - 1;
                uVar25 = (ulonglong)uVar18;
                *(ushort *)((longlong)&uStackX_14 + lVar9) = uVar18;
              } while (uVar18 != 0);
            }
            if ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x40) == 0) {
              *(undefined4 *)(auStackX_1e + lVar9) = 0;
            }
            else {
              *(int *)(auStackX_1e + lVar9) = (int)uVar21;
              *(int *)(&stack0xfffffffffffffffc + lVar9) = (int)uVar21 + 0xe;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100dec;
              puVar12 = (ulonglong *)func_0x(&stack0xfffffffffffffffa + lVar9);
              uVar21 = *puVar12;
              uVar19 = 0;
              uVar18 = (ushort)(uVar21 >> 0x30);
              if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
                if ((uVar21 & 0x4000000000000000) == 0) {
                  uVar18 = uVar18 & 0xdfff;
                }
                else {
                  uVar18 = uVar18 | 0x2000;
                }
              }
              if (uVar18 == 0xfffc) {
                uVar19 = ((uint)(uVar21 >> 0x20) & 0xffff) >> 5;
              }
              uVar21 = (ulonglong)(*(int *)(&stack0xfffffffffffffffc + lVar9) + uVar19);
              *(uint *)(&stack0xfffffffffffffffc + lVar9) =
                   *(int *)(&stack0xfffffffffffffffc + lVar9) + uVar19;
            }
            uVar25 = *(ulonglong *)((longlong)&uStackX_14 + lVar9 + 2);
            if ((uVar25 != 0) && (uVar25 < uVar21 + *(longlong *)(auStackX_1e + lVar9 + -0x1e))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar14 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0 &&
                   (lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0)) &&
                  (*(char *)(lVar14 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100ee3;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100f09;
                  (*_DAT_)(1,0x174cb58,0x186c828);
                }
              }
              uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100f18;
              func_0x(uVar13,0x12);
              uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
            }
            if (0x3f3b < (int)uVar21 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar14 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0 &&
                  ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                   (*(char *)(lVar14 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100fa4;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100fca;
                  (*_DAT_)(1,0x174cb58,0x186c828);
                }
              }
              uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100fd9;
              func_0x(uVar13,5);
              uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
            }
          }
LAB_:
          uVar20 = (uint)uVar21;
          if ((uVar20 < 9) &&
             (((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0xe) == 0 ||
              ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0xe) == 0xc)))) {
            uVar20 = 9;
            bVar27 = (**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x40) == 0;
            uVar16 = *(uint *)(auStackX_1e + lVar9);
          }
          else {
            bVar27 = (**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x40) == 0;
            uVar16 = *(uint *)(auStackX_1e + lVar9);
          }
LAB_:
          uVar19 = (uint)uVar21;
          if (bVar27) {
            uVar16 = uVar20;
          }
          uVar20 = 0x10;
          if (*(short *)(&stack0xfffffffffffffff8 + lVar9) == 0) {
            uVar20 = 0x16;
          }
          if (uVar20 <= uVar16) goto LAB_;
          goto LAB_;
        }
LAB_:
        if ((int)uVar21 == 0) {
          *(undefined2 *)(&stack0xfffffffffffffffa + lVar9) = 0;
          uVar19 = *(uint *)((longlong)&uStackX_8 + lVar9);
          uVar21 = (ulonglong)uVar19;
          *(uint *)((longlong)&uStackX_8 + lVar9 + 4) = uVar19;
          if ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x10) != 0) {
            uVar19 = uVar19 + 2 +
                     (*(ushort *)(*(byte **)(auStackX_1e + lVar9 + -0x1e) + uVar21) + 7 >> 3);
            uVar21 = (ulonglong)uVar19;
            *(uint *)((longlong)&uStackX_8 + lVar9 + 4) = uVar19;
          }
          if ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x20) == 0) {
            *(int *)(&stack0xfffffffffffffffc + lVar9) = (int)uVar21;
            *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 0;
            *(int *)((longlong)&uStackX_10 + lVar9) = (int)uVar21;
          }
          else {
            puVar24 = (ushort *)(*(byte **)(auStackX_1e + lVar9 + -0x1e) + uVar21);
            uVar18 = *puVar24;
            *(ushort *)((longlong)&uStackX_14 + lVar9) = uVar18;
            if (uVar18 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar14 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0)) &&
                 ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                  (*(char *)(lVar14 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1011ba;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1011e0;
                  (*_DAT_)(1,0x174cb58,0x186c828);
                }
              }
              uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1011ef;
              func_0x(uVar13,3);
              uVar18 = *(ushort *)((longlong)&uStackX_14 + lVar9);
            }
            uVar19 = *(int *)((longlong)&uStackX_8 + lVar9 + 4) + 2 + (uint)uVar18 * 2;
            *(uint *)((longlong)&uStackX_10 + lVar9) = uVar19;
            if (0x1f9e < uVar19) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar14 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0 &&
                  ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                   (*(char *)(lVar14 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101293;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1012b9;
                  (*_DAT_)(1,0x174cb58,0x186c828,0x816);
                }
              }
              uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1012c8;
              func_0x(uVar13,4);
              uVar18 = *(ushort *)((longlong)&uStackX_14 + lVar9);
              uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
            }
            uVar25 = (ulonglong)uVar18;
            uVar20 = puVar24[uVar25] & 0x7fff;
            uVar21 = (ulonglong)uVar20;
            *(uint *)(&stack0xfffffffffffffffc + lVar9) = uVar20;
            if (uVar20 < uVar19) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar14 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar14 != 0)) &&
                 ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                  (*(char *)(lVar14 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101368;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10138e;
                  (*_DAT_)(1,0x174cb58,0x186c828,0x81d);
                }
              }
              uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10139d;
              func_0x(uVar13,4);
              uVar25 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar9);
              uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
              uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
            }
            do {
              if (-1 < (short)puVar24[(ulonglong)((int)uVar25 - 1) + 1]) break;
              lVar14 = (ulonglong)*(uint *)((longlong)&uStackX_8 + lVar9 + 4) +
                       *(longlong *)(auStackX_1e + lVar9 + -0x1e);
              uVar20 = uVar19;
              if ((int)uVar25 != 1) {
                uVar20 = *(ushort *)(lVar14 + -2 + uVar25 * 2) & 0x7fff;
              }
              if ((uVar20 < uVar19) || ((*(ushort *)(lVar14 + uVar25 * 2) & 0x7fff) < uVar20)) {
                uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101409;
                func_0x(uVar13,7);
                uVar25 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar9);
                uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
                uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
              }
              if ((uVar20 < uVar19) || ((uint)uVar21 < uVar20)) goto LAB_;
              uVar18 = *(ushort *)((ulonglong)uVar20 + *(longlong *)(auStackX_1e + lVar9 + -0x1e));
              if (uVar18 == 5) {
                *(ushort *)(&stack0xfffffffffffffffa + lVar9) =
                     *(ushort *)(&stack0xfffffffffffffffa + lVar9) | 2;
                *(short *)((longlong)&uStackX_14 + lVar9) = (short)uVar25 + -1;
                *(short *)(auStackX_1e + lVar9 + 4) = (short)uVar20;
                lVar14 = ((ulonglong)uVar20 & 0xffff) + *(longlong *)(auStackX_1e + lVar9 + -0x1e);
                uVar18 = *(ushort *)(lVar14 + 2);
                uVar15 = *(ushort *)(auStackX_1e + lVar9 + 6);
                if ((uVar18 & 0x4000) == 0) {
                  uVar15 = uVar15 & 0xc7ff;
                }
                else {
                  uVar15 = uVar15 ^ (uVar15 ^ uVar18) & 0x3800;
                }
                *(ushort *)(auStackX_1e + lVar9 + 6) = uVar15;
                *(ushort *)(auStackX_1e + lVar9 + 6) =
                     (uVar15 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar15;
                break;
              }
              if (uVar18 < 0x400) break;
              *(ushort *)(&stack0xfffffffffffffffa + lVar9) =
                   *(ushort *)(&stack0xfffffffffffffffa + lVar9) | 1;
              uVar18 = (short)uVar25 - 1;
              uVar25 = (ulonglong)uVar18;
              *(ushort *)((longlong)&uStackX_14 + lVar9) = uVar18;
            } while (uVar18 != 0);
          }
          if ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x40) == 0) {
            *(undefined4 *)(auStackX_1e + lVar9) = 0;
          }
          else {
            *(int *)(auStackX_1e + lVar9) = (int)uVar21;
            *(int *)(&stack0xfffffffffffffffc + lVar9) = (int)uVar21 + 0xe;
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1014f0;
            puVar12 = (ulonglong *)func_0x(&stack0xfffffffffffffffa + lVar9);
            uVar21 = *puVar12;
            uVar19 = 0;
            uVar18 = (ushort)(uVar21 >> 0x30);
            if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
              if ((uVar21 & 0x4000000000000000) == 0) {
                uVar18 = uVar18 & 0xdfff;
              }
              else {
                uVar18 = uVar18 | 0x2000;
              }
            }
            if (uVar18 == 0xfffc) {
              uVar19 = ((uint)(uVar21 >> 0x20) & 0xffff) >> 5;
            }
            uVar21 = (ulonglong)(*(int *)(&stack0xfffffffffffffffc + lVar9) + uVar19);
            *(uint *)(&stack0xfffffffffffffffc + lVar9) =
                 *(int *)(&stack0xfffffffffffffffc + lVar9) + uVar19;
          }
          uVar25 = *(ulonglong *)((longlong)&uStackX_14 + lVar9 + 2);
          if ((uVar25 != 0) && (uVar25 < uVar21 + *(longlong *)(auStackX_1e + lVar9 + -0x1e))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar14 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar14 != 0 &&
                 (lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0)) &&
                (*(char *)(lVar14 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1015e7;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10160d;
                (*_DAT_)(1,0x174cb58,0x186c828,0x877);
              }
            }
            uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10161c;
            func_0x(uVar13,0x12);
            uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
          }
          if (0x3f3b < (int)uVar21 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar14 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar14 != 0 &&
                ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
                 (*(char *)(lVar14 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1016a8;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1016ce;
                (*_DAT_)(1,0x174cb58,0x186c828,0x87c);
              }
            }
            uVar13 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1016dd;
            func_0x(uVar13,5);
            uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
          }
        }
LAB_:
        uVar19 = (uint)uVar21;
        if ((8 < uVar19) ||
           (((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0xe) != 0 &&
            ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0xe) != 0xc)))) {
          uVar23 = uVar19;
        }
        bVar6 = **(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x40;
        uVar20 = *(uint *)(auStackX_1e + lVar9);
      }
      else {
        if (((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x1c) - 0x10 & 0xfffffffb) != 0) {
          if (uVar19 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10105d;
            func_0x(&stack0xfffffffffffffffa + lVar9);
            uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
            if (*(uint *)(&stack0xfffffffffffffffc + lVar9) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10106f;
              func_0x(&stack0xfffffffffffffffa + lVar9);
              uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
            }
          }
          uVar20 = (uint)uVar21;
          if ((uVar20 < 9) &&
             (((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x1c) == 0 ||
              ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x1c) == 0xc)))) {
            uVar20 = 9;
          }
          bVar27 = (**(byte **)(auStackX_1e + lVar9 + -0x1e) & 2) == 0;
          uVar16 = *(uint *)(&stack0x00000028 + lVar9);
          goto LAB_;
        }
LAB_:
        uVar19 = (uint)uVar21;
        if (*(short *)(&stack0xfffffffffffffff8 + lVar9) == 0) goto LAB_;
        if (uVar19 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101717;
          func_0x(&stack0xfffffffffffffffa + lVar9);
          uVar19 = *(uint *)(&stack0xfffffffffffffffc + lVar9);
          if (uVar19 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101729;
            func_0x(&stack0xfffffffffffffffa + lVar9);
            uVar19 = *(uint *)(&stack0xfffffffffffffffc + lVar9);
          }
        }
        if ((8 < uVar19) ||
           (((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x1c) != 0 &&
            ((**(byte **)(auStackX_1e + lVar9 + -0x1e) & 0x1c) != 0xc)))) {
          uVar23 = uVar19;
        }
        bVar6 = **(byte **)(auStackX_1e + lVar9 + -0x1e) & 2;
        uVar20 = *(uint *)(&stack0x00000028 + lVar9);
      }
      if (bVar6 == 0) {
        uVar20 = uVar23;
      }
      uVar23 = 0x18;
      if (*(short *)(&stack0xfffffffffffffff8 + lVar9) == 0) {
        uVar23 = 0x20;
      }
      if (uVar23 <= uVar20) goto LAB_;
    }
    param_3 = *(longlong **)(&stack0x00000070 + lVar9);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10179d;
    iVar8 = func_0x(param_3,0,0);
    if (iVar8 != 0) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1017c5;
      (*_DAT_)(1,0x18d9738,0x18d0f28,0x1d90);
    }
    uVar21 = (ulonglong)*(uint *)(&stack0x00000050 + lVar9);
    param_1 = *(longlong *)(&stack0x00000058 + lVar9);
    uVar23 = *(uint *)(&stack0x00000040 + lVar9);
    iVar8 = *(int *)(&stack0x00000030 + lVar9);
  }
  pcVar3 = *(code **)(*param_3 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1017e6;
  (*pcVar3)(param_3);
  if ((uVar23 != 0) || ((uVar21 & 0x10) != 0)) {
    puVar4 = *(undefined8 **)(param_1 + 0x2e0);
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x00000038 + lVar9;
    uVar13 = *(undefined8 *)(param_1 + 0x1e8);
    uVar5 = *puVar4;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101817;
    func_0x(uVar5,uVar13,&stack0xfffffffffffffff8 + lVar9,uVar21);
  }
  uVar13 = *(undefined8 *)(&stack0x00000048 + lVar9);
  if (iVar8 != 0) {
    *(undefined **)(&stack0xfffffffffffffff0 + lVar9) = &stack0x00000034 + lVar9;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = uVar13;
    uVar5 = *(undefined8 *)(param_1 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101854;
    func_0x(uVar5,&stack0xfffffffffffffff8 + lVar9,*(undefined8 *)(&stack0x00000068 + lVar9)
                    ,*(undefined8 *)(&stack0x00000060 + lVar9));
  }
  if (((uint)uVar21 >> 8 & 1) != 0) {
    uVar5 = *(undefined8 *)(param_1 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101873;
    func_0x(uVar5,&stack0xfffffffffffffff8 + lVar9,uVar13,&stack0x0000003c + lVar9);
  }
  if ((((*(int *)(&stack0x00000034 + lVar9) != 0) || (*(int *)(&stack0x00000038 + lVar9) != 0)) ||
      (*(int *)(&stack0x0000003c + lVar9) != 0)) && ((uVar21 & 0x20) == 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1018a0;
    func_0x(param_3,&stack0xfffffffffffffff8 + lVar9,0,0);
  }
  if ((uVar21 & 4) != 0) {
    *(undefined4 *)(&stack0x00000040 + lVar9) = 0x1dcc;
    lVar11 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar14 = *(longlong *)(lVar11 + 0x100);
    if (lVar14 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1018e4;
      (*_DAT_)(0);
      lVar14 = *(longlong *)(lVar11 + 0x100);
    }
    uVar13 = *(undefined8 *)(lVar14 + 1000);
    *(undefined8 *)(&stack0x00000068 + lVar9) = uVar13;
    (&stack0xffffffffffffffe8)[lVar9] = 5;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101917;
    lVar14 = (*_DAT_)(0x110,uVar13,0x1756f60,0x1dcc);
    *(longlong *)(&stack0x00000060 + lVar9) = lVar14;
    if (lVar14 == 0) {
      lVar14 = 0;
    }
    else {
      lVar22 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar11 = *(longlong *)(lVar22 + 0x100);
      if (lVar11 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10195e;
        (*_DAT_)(0);
        lVar11 = *(longlong *)(lVar22 + 0x100);
      }
      uVar13 = *(undefined8 *)(lVar11 + 1000);
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101974;
      lVar14 = func_0x(lVar14,uVar13);
    }
    *(longlong *)(&stack0x00000048 + lVar9) = lVar14;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1019ce;
    func_0x(lVar14,0,0x110);
    *(undefined2 *)(lVar14 + 0xe) = 2;
    *(ushort *)(lVar14 + 0x38) = *(ushort *)(lVar14 + 0x38) | 2;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar9) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = &stack0x00000058 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1019fe;
    func_0x(param_1,param_3,lVar14,0);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101a06;
    func_0x(lVar14);
    lVar11 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar14 = *(longlong *)(lVar11 + 0x100);
    if (lVar14 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101a38;
      (*_DAT_)();
      lVar14 = *(longlong *)(lVar11 + 0x100);
    }
    if (*(int *)(lVar14 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101a4e;
      (*_DAT_)();
    }
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101a5e;
  func_0x
            (*(ulonglong *)(&stack0x00002048 + lVar9) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar9));
  return;
}

