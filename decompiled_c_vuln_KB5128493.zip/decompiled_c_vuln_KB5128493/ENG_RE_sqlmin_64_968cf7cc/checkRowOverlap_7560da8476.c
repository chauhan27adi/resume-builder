
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,int param_3)

{
  uint *puVar1;
  uint *puVar2;
  byte **ppbVar3;
  uint *puVar4;
  undefined2 uVar5;
  undefined2 uVar6;
  undefined8 uVar7;
  longlong lVar8;
  longlong lVar9;
  bool bVar10;
  short sVar11;
  ushort uVar12;
  int iVar13;
  ulonglong *puVar14;
  byte bVar15;
  ushort uVar16;
  int iVar17;
  undefined4 uVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  ulonglong uVar21;
  ushort uVar22;
  uint uVar23;
  ulonglong uVar24;
  longlong lVar25;
  ulonglong uVar26;
  ushort *puVar27;
  longlong lVar28;
  longlong lVar29;
  ushort *puVar30;
  short *psVar31;
  byte *pbVar32;
  ulonglong uVar33;
  ushort *puVar34;
  uint uVar35;
  longlong unaff_GS_OFFSET;
  undefined8 auStack_220 [5];
  undefined8 uStack_1f8;
  longlong alStack_1f0 [2];
  int aiStack_1e0 [2];
  short *apsStack_1d8 [2];
  int iStack_1c8;
  int iStack_1c4;
  ushort *puStack_1c0;
  ushort *puStack_1b8;
  uint uStack_1b0;
  int iStack_1ac;
  uint uStack_1a8;
  uint uStack_1a4;
  longlong lStack_1a0;
  byte bStack_198;
  byte bStack_197;
  byte bStack_196;
  byte bStack_195;
  byte bStack_194;
  byte bStack_193;
  byte bStack_192;
  byte bStack_191;
  byte bStack_190;
  byte bStack_18f;
  byte bStack_18e;
  longlong lStack_188;
  longlong lStack_180;
  int iStack_178;
  undefined4 uStack_174;
  undefined2 uStack_170;
  undefined2 uStack_16e;
  longlong lStack_168;
  ushort uStack_160;
  ushort uStack_15c;
  ushort uStack_158;
  ushort uStack_154;
  int iStack_150;
  int iStack_14c;
  longlong lStack_148;
  longlong lStack_140;
  longlong lStack_138;
  ushort *puStack_130;
  longlong lStack_128;
  longlong lStack_120;
  longlong lStack_118;
  uint uStack_110;
  uint uStack_10c;
  uint uStack_108;
  uint uStack_104;
  uint uStack_100;
  uint uStack_fc;
  longlong lStack_f8;
  longlong lStack_f0;
  longlong lStack_e8;
  ulonglong uStack_e0;
  longlong lStack_d8;
  longlong lStack_d0;
  longlong lStack_c8;
  longlong lStack_c0;
  longlong lStack_b8;
  longlong lStack_a8;
  undefined8 uStack_a0;
  ulonglong *puStack_98;
  undefined auStack_68 [40];
  ulonglong uStack_40;
  
  uStack_a0 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)&iStack_1c8;
  uVar20 = 0;
  uVar21 = 1;
  iStack_1c8 = 0;
  uVar12 = *(ushort *)(param_1 + 0x16);
  uVar26 = (ulonglong)uVar12;
  if (uVar12 == 0) {
    uVar26 = 1;
  }
  uVar19 = uVar26 * 8 + 0xf;
  uVar33 = 0xffffffffffffff0;
  if (uVar19 <= uVar26 * 8) {
    uVar19 = 0xffffffffffffff0;
  }
  uVar19 = uVar19 & 0xfffffffffffffff0;
  auStack_220[0] = 0x1000ca;
  uVar24 = uVar20;
  lStack_168 = param_1;
  lStack_140 = param_1;
  lStack_138 = param_1;
  lStack_128 = param_1;
  lStack_120 = param_1;
  lStack_c0 = param_1;
  lStack_b8 = param_1;
  func_0x();
  lVar8 = -uVar19;
  puStack_1b8 = (ushort *)((longlong)&iStack_1c8 + lVar8);
  uVar19 = uVar26 * 0x34 + 0xf;
  if (uVar19 <= uVar26 * 0x34) {
    uVar19 = uVar33;
  }
  uVar19 = uVar19 & 0xfffffffffffffff0;
  *(undefined8 *)((longlong)auStack_220 + lVar8) = 0x1000f2;
  func_0x();
  puVar27 = puStack_1b8;
  lVar9 = -uVar19;
  lStack_148 = (longlong)&iStack_1c8 + lVar9 + lVar8;
  iStack_178 = (param_3 != 2) + 2;
  iStack_14c = iStack_178;
  if (uVar12 != 0) {
    puVar30 = (ushort *)(param_1 + 0x1ffe);
    puVar34 = puStack_1b8;
    uVar26 = uVar20;
    do {
      uVar12 = *puVar30;
      uVar21 = uVar21 & 0xffffffff;
      if ((uint)uVar12 < (uint)uVar24) {
        uVar21 = uVar20;
      }
      *puVar34 = uVar12;
      *(int *)(puVar34 + 2) = (int)uVar26;
      uVar35 = (int)uVar26 + 1;
      uVar26 = (ulonglong)uVar35;
      puVar30 = puVar30 + -1;
      puVar34 = puVar34 + 4;
      uVar22 = *(ushort *)(param_1 + 0x16);
      uVar19 = (ulonglong)(uint)uVar12;
      if ((uint)uVar12 < (uint)uVar24) {
        uVar19 = uVar24 & 0xffffffff;
      }
      uVar24 = uVar19;
    } while ((int)uVar35 < (int)(uint)uVar22);
    if ((int)uVar21 == 0) {
      *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10017d;
      (*_DAT_)(puVar27,(uint)uVar22,8,0xfffffffffec36980);
    }
  }
  lVar29 = param_1 + 0x60;
  lStack_1a0 = lVar29;
  lStack_180 = lVar29;
  lStack_118 = lVar29;
  lStack_a8 = lVar29;
  if (*(char *)(param_1 + 2) < '\0') {
    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10019d;
    sVar11 = func_0x();
    uVar35 = (uint)(ushort)(sVar11 + 0x60);
    uStack_1b0 = 0x1fa0;
    if (*(char *)(param_1 + 2) < '\0') {
      *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1001c2;
      uVar12 = func_0x(lVar29);
      uStack_1b0 = 0x1fa0 - uVar12;
    }
  }
  else {
    uVar35 = 0x60;
    uStack_1b0 = 0x1fa0;
  }
  uStack_1a4 = 0;
  lVar29 = param_1;
  uVar21 = uVar20;
  while( true ) {
    uVar23 = uStack_1b0;
    puVar27 = puStack_1b8;
    iStack_1ac = (int)uVar20;
    if ((int)(uint)*(ushort *)(lVar29 + 0x16) <= iStack_1ac) break;
    lVar25 = (longlong)iStack_1ac;
    uVar12 = puStack_1b8[lVar25 * 4];
    lStack_188 = lVar25;
    lStack_c8 = lVar25;
    if (uVar12 == 0) {
      uStack_1a4 = (int)uVar21 + 1;
      uVar21 = (ulonglong)uStack_1a4;
      uStack_1b0 = uStack_1b0 - 2;
      uVar20 = (ulonglong)(iStack_1ac + 1);
    }
    else {
      if (((uVar12 < uVar35) && (iStack_1c8 = 1, param_3 != 0)) && (param_3 == 2)) {
        *(uint *)((longlong)alStack_1f0 + lVar9 + lVar8) = (uint)uVar12;
        *(undefined4 *)((longlong)&uStack_1f8 + lVar9 + lVar8) =
             *(undefined4 *)(puVar27 + lVar25 * 4 + 2);
        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100262;
        func_0x(0x22ee,param_1,0x13441a0,1);
        uVar12 = puStack_1b8[lStack_188 * 4];
      }
      puVar27 = puStack_1b8;
      if ((((uint)uVar12 & (1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1U) != 0) &&
         (iStack_1c8 = iStack_1c8 + 1, param_3 == 2)) {
        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1002a8;
        func_0x(param_1,0x13442e0,0x66);
      }
      psVar31 = (short *)(lStack_148 + lStack_188 * 0x34);
      if (param_2 == 1) {
        uVar12 = puStack_1b8[lStack_188 * 4];
        lVar25 = (ulonglong)uVar12 + lStack_128;
        if (iStack_1ac == *(ushort *)(lVar29 + 0x16) - 1) {
          uVar22 = *(ushort *)(lVar29 + 0x1e);
        }
        else {
          uVar22 = puStack_1b8[lStack_188 * 4 + 4];
        }
        lVar29 = (ulonglong)uVar22 + lStack_120;
        if (*(char *)(param_1 + 2) < '\0') {
          *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10030a;
          sVar11 = func_0x(param_1 + 0x60);
          uVar22 = sVar11 + 0x60;
          uVar12 = puStack_1b8[lStack_188 * 4];
        }
        else {
          uVar22 = 0x60;
        }
        lVar28 = lStack_188;
        puVar27 = puStack_1b8;
        if (((uVar12 < uVar22) && (iStack_1c8 = iStack_1c8 + 1, param_3 != 0)) && (param_3 == 2)) {
          *(uint *)((longlong)alStack_1f0 + lVar9 + lVar8) = (uint)uVar12;
          *(undefined4 *)((longlong)&uStack_1f8 + lVar9 + lVar8) =
               *(undefined4 *)(puVar27 + lVar28 * 4 + 2);
          *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100361;
          func_0x(0x22ed,param_1,0x1344270,1);
          uVar12 = puStack_1b8[lStack_188 * 4];
        }
        lVar28 = lStack_188;
        puVar27 = puStack_1b8;
        if ((*(ushort *)(lStack_138 + 0x1e) < uVar12) && (iStack_1c8 = iStack_1c8 + 1, param_3 == 2)
           ) {
          *(uint *)((longlong)alStack_1f0 + lVar9 + lVar8) = (uint)uVar12;
          *(undefined4 *)((longlong)&uStack_1f8 + lVar9 + lVar8) =
               *(undefined4 *)(puVar27 + lVar28 * 4 + 2);
          *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1003ae;
          func_0x(0x22ed,param_1,0x1344210,2);
        }
        if (iStack_1c8 != 0) goto LAB_;
        *(undefined8 *)((longlong)alStack_1f0 + lVar9 + lVar8) = 0;
        *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = _DAT_;
        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1003dd;
        func_0x(auStack_68,0,0,0);
        uVar18 = *(undefined4 *)(param_1 + 0x18);
        uVar5 = *(undefined2 *)(param_1 + 6);
        puStack_1c0 = (ushort *)(ulonglong)CONCAT24(uVar5,uVar18);
        uStack_16e = 0;
        uVar6 = *(undefined2 *)(param_1 + 0xe);
        uStack_174 = uVar18;
        uStack_170 = uVar5;
        *(short **)((longlong)apsStack_1d8 + lVar9 + lVar8) = psVar31;
        *(int *)((longlong)aiStack_1e0 + lVar9 + lVar8) = iStack_178;
        *(longlong *)((longlong)alStack_1f0 + lVar9 + lVar8 + 8) = lVar29;
        *(undefined2 *)((longlong)alStack_1f0 + lVar9 + lVar8) = uVar5;
        *(undefined4 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = uVar18;
        uVar18 = *(undefined4 *)(puStack_1b8 + lStack_188 * 4 + 2);
        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10044c;
        iVar13 = func_0x(lVar25,uVar6,param_1 + 0x20,uVar18);
        if (iVar13 == 0) {
          puVar27 = (ushort *)(psVar31 + 1);
          if (*psVar31 == 0) {
            puVar1 = (uint *)(psVar31 + 2);
            puStack_1c0 = puVar27;
            if (*puVar1 == 0) {
              iStack_1c4 = 0;
              *puVar27 = 0;
              uVar35 = *(uint *)(psVar31 + 8);
              puVar2 = (uint *)(psVar31 + 10);
              *puVar2 = uVar35;
              ppbVar3 = (byte **)(psVar31 + 4);
              pbVar32 = *ppbVar3;
              if ((*pbVar32 & 0x10) != 0) {
                uVar35 = uVar35 + 2 + (*(ushort *)(pbVar32 + *(uint *)(psVar31 + 8)) + 7 >> 3);
                *puVar2 = uVar35;
                pbVar32 = *ppbVar3;
              }
              if ((*pbVar32 & 0x20) == 0) {
                *puVar1 = uVar35;
                psVar31[0xe] = 0;
                *(uint *)(psVar31 + 0xc) = *puVar2;
              }
              else {
                puStack_130 = (ushort *)(pbVar32 + uVar35);
                uVar12 = *puStack_130;
                puVar30 = (ushort *)(psVar31 + 0xe);
                *puVar30 = uVar12;
                if (uVar12 == 0) {
                  iStack_1c4 = 1;
                  if ((DAT_ != '\0') || (bStack_198 = DAT_, (DAT_ & 1) != 0)
                     ) {
                    lVar29 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8);
                    if (lVar29 == 0) {
                      lStack_f8 = 0;
                      pbVar32 = *ppbVar3;
                      *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1005cf;
                      func_0x(pbVar32,3);
                      goto LAB_;
                    }
                    lStack_f8 = *(longlong *)(lVar29 + 0x60);
                    if ((lStack_f8 != 0) && (*(char *)(lStack_f8 + 0x499) != '\0')) {
                      if ((DAT_ != '\0') ||
                         (bStack_197 = DAT_ >> 1, (bStack_197 & 1) != 0)) {
                        *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1005a4;
                        (*_DAT_)(1,0x130c458,0x142c128,0x80f);
                        puVar27 = puStack_1c0;
                        pbVar32 = *ppbVar3;
                        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1005b4;
                        func_0x(pbVar32,3);
                        goto LAB_;
                      }
                      *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10056c;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                  }
                  puVar27 = puStack_1c0;
                  pbVar32 = *ppbVar3;
                  *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10057e;
                  func_0x(pbVar32,3);
                }
LAB_:
                uVar35 = *puVar2 + (*puVar30 + 1) * 2;
                puVar4 = (uint *)(puVar27 + 0xb);
                *puVar4 = uVar35;
                if (0x1f9e < uVar35) {
                  iStack_1c4 = iStack_1c4 + 1;
                  if ((DAT_ != '\0') || (bStack_196 = DAT_, (DAT_ & 1) != 0)
                     ) {
                    lVar29 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8);
                    puVar27 = puStack_1c0;
                    if (lVar29 == 0) {
                      lStack_f0 = 0;
                    }
                    else {
                      lStack_f0 = *(longlong *)(lVar29 + 0x60);
                      if ((lStack_f0 != 0) && (*(char *)(lStack_f0 + 0x499) != '\0')) {
                        if ((DAT_ == '\0') &&
                           (bStack_195 = DAT_ >> 1, (bStack_195 & 1) == 0)) {
                          *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100681;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          puVar27 = puStack_1c0;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                          *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1006a7;
                          (*_DAT_)(1,0x130c458,0x142c128,0x816);
                          puVar27 = puStack_1c0;
                        }
                      }
                    }
                  }
                  pbVar32 = *ppbVar3;
                  *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1006c2;
                  func_0x(pbVar32,4);
                }
                uStack_160 = puStack_130[*puVar30];
                *puVar1 = uStack_160 & 0x7fff;
                if ((uStack_160 & 0x7fff) < *puVar4) {
                  iStack_1c4 = iStack_1c4 + 1;
                  if ((DAT_ != '\0') || (bStack_194 = DAT_, (DAT_ & 1) != 0)
                     ) {
                    lVar29 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8);
                    puVar27 = puStack_1c0;
                    if (lVar29 == 0) {
                      lStack_e8 = 0;
                    }
                    else {
                      lStack_e8 = *(longlong *)(lVar29 + 0x60);
                      if ((lStack_e8 != 0) && (*(char *)(lStack_e8 + 0x499) != '\0')) {
                        if ((DAT_ == '\0') &&
                           (bStack_193 = DAT_ >> 1, (bStack_193 & 1) == 0)) {
                          *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100777;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          puVar27 = puStack_1c0;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                          *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10079d;
                          (*_DAT_)(1,0x130c458,0x142c128,0x81d);
                          puVar27 = puStack_1c0;
                        }
                      }
                    }
                  }
                  pbVar32 = *ppbVar3;
                  *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1007b8;
                  func_0x(pbVar32,4);
                }
                do {
                  uVar12 = *puVar30;
                  if (-1 < (short)puStack_130[(ulonglong)(uVar12 - 1) + 1]) break;
                  pbVar32 = *ppbVar3;
                  if (uVar12 == 1) {
                    uVar35 = *puVar4;
                    uVar23 = uVar35;
                  }
                  else {
                    uStack_15c = *(ushort *)
                                  (pbVar32 +
                                  (longlong)(int)(uVar12 - 2) * 2 + (ulonglong)*puVar2 + 2);
                    uVar35 = uStack_15c & 0x7fff;
                    uVar23 = *puVar4;
                  }
                  uStack_158 = *(ushort *)
                                (pbVar32 + (longlong)(int)(uVar12 - 1) * 2 + (ulonglong)*puVar2 + 2)
                  ;
                  uStack_10c = uStack_158 & 0x7fff;
                  uStack_108 = uVar35;
                  if ((uVar35 < uVar23) || (uStack_10c < uVar35)) {
                    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100843;
                    func_0x(pbVar32,7);
                    uVar23 = *puVar4;
                  }
                  uStack_110 = uVar35;
                  if ((uVar35 < uVar23) || (*puVar1 < uVar35)) {
                    iStack_1c4 = iStack_1c4 + 1;
                    goto LAB_;
                  }
                  uStack_154 = *(ushort *)(*ppbVar3 + uVar35);
                  if (uStack_154 == 5) {
                    *puVar27 = *puVar27 | 2;
                    *puVar30 = *puVar30 - 1;
                    puVar27[0x14] = (ushort)uVar35;
                    lVar29 = (ulonglong)(uVar35 & 0xffff) + *(longlong *)(puVar27 + 3);
                    uVar12 = *(ushort *)(lVar29 + 2);
                    if ((uVar12 & 0x4000) == 0) {
                      puVar27[0x15] = puVar27[0x15] & 0xc7ff;
                    }
                    else {
                      puVar27[0x15] = puVar27[0x15] & 0xc7ff;
                      puVar27[0x15] = puVar27[0x15] | uVar12 & 0x3800;
                    }
                    puVar27[0x15] =
                         (puVar27[0x15] ^ *(ushort *)(lVar29 + 2)) & 0x7ff ^ puVar27[0x15];
                    break;
                  }
                  if (uStack_154 < 0x400) break;
                  *puVar27 = *puVar27 | 1;
                  *puVar30 = *puVar30 - 1;
                } while (*puVar30 != 0);
              }
              if ((**ppbVar3 & 0x40) == 0) {
                *(undefined4 *)(puVar27 + 0x12) = 0;
              }
              else {
                *(uint *)(puVar27 + 0x12) = *puVar1;
                *puVar1 = *puVar1 + 0xe;
                *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100931;
                puVar14 = (ulonglong *)func_0x(puVar27);
                uStack_e0 = *puVar14;
                iStack_150 = 0;
                uVar12 = (ushort)(uStack_e0 >> 0x30);
                if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
                  if ((uStack_e0 & 0x4000000000000000) == 0) {
                    uVar12 = uVar12 & 0xdfff;
                  }
                  else {
                    uVar12 = uVar12 | 0x2000;
                  }
                }
                if (uVar12 == 0xfffc) {
                  puStack_98 = &uStack_e0;
                  iStack_150 = (int)((uStack_e0 >> 0x20 & 0xffff) >> 5);
                }
                *puVar1 = *puVar1 + iStack_150;
              }
              if ((*(byte **)(puVar27 + 0xe) != (byte *)0x0) &&
                 (*(byte **)(puVar27 + 0xe) < *ppbVar3 + *puVar1)) {
                iStack_1c4 = iStack_1c4 + 1;
                if ((DAT_ != '\0') || (bStack_192 = DAT_, (DAT_ & 1) != 0))
                {
                  lVar29 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8);
                  puVar27 = puStack_1c0;
                  if (lVar29 == 0) {
                    lStack_d8 = 0;
                  }
                  else {
                    lStack_d8 = *(longlong *)(lVar29 + 0x60);
                    if ((lStack_d8 != 0) && (*(char *)(lStack_d8 + 0x499) != '\0')) {
                      if ((DAT_ == '\0') &&
                         (bStack_191 = DAT_ >> 1, (bStack_191 & 1) == 0)) {
                        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100a61;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        puVar27 = puStack_1c0;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100a87;
                        (*_DAT_)(1,0x130c458,0x142c128,0x877);
                        puVar27 = puStack_1c0;
                      }
                    }
                  }
                }
                pbVar32 = *ppbVar3;
                *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100aa2;
                func_0x(pbVar32,0x12);
              }
              if (0x3f3b < *puVar1 - 1) {
                iStack_1c4 = iStack_1c4 + 1;
                if ((DAT_ != '\0') || (bStack_190 = DAT_, (DAT_ & 1) != 0))
                {
                  lVar29 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8);
                  puVar27 = puStack_1c0;
                  if (lVar29 == 0) {
                    lStack_d0 = 0;
                  }
                  else {
                    lStack_d0 = *(longlong *)(lVar29 + 0x60);
                    if ((lStack_d0 != 0) && (*(char *)(lStack_d0 + 0x499) != '\0')) {
                      if ((DAT_ == '\0') &&
                         (bStack_18f = DAT_ >> 1, (bStack_18f & 1) == 0)) {
                        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100b43;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        puVar27 = puStack_1c0;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100b69;
                        (*_DAT_)(1,0x130c458,0x142c128,0x87c);
                        puVar27 = puStack_1c0;
                      }
                    }
                  }
                }
                pbVar32 = *ppbVar3;
                *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100b84;
                func_0x(pbVar32,5);
              }
            }
LAB_:
            uVar35 = *puVar1;
            uStack_fc = uVar35;
            if ((uVar35 < 9) &&
               ((bStack_18e = **(byte **)(puVar27 + 3) & 0xe, bStack_18e == 0 || (bStack_18e == 0xc)
                ))) {
              uVar35 = 9;
              uStack_fc = uVar35;
            }
          }
          else {
            uVar35 = *(uint *)(psVar31 + 2);
            if (uVar35 == 0) {
              *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100bda;
              func_0x(puVar27);
              uVar35 = *(uint *)(psVar31 + 2);
            }
            uStack_104 = uVar35;
            if ((uVar35 < 9) &&
               ((uStack_100 = **(byte **)(psVar31 + 4) & 0x1c,
                (**(byte **)(psVar31 + 4) & 0x1c) == 0 || (uStack_100 == 0xc)))) {
              uVar35 = 9;
              uStack_104 = uVar35;
            }
          }
          iVar13 = iStack_1c8;
          uStack_1a8 = uVar35;
          if ((0x1f9e < uVar35) && (iStack_1c8 = iStack_1c8 + 1, iVar13 = iStack_1c8, param_3 == 2))
          {
            *(undefined4 *)((longlong)alStack_1f0 + lVar9 + lVar8) = 0x1f9e;
            *(uint *)((longlong)&uStack_1f8 + lVar9 + lVar8) = uVar35;
            *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100c3d;
            func_0x(0x22ed,param_1,0x13441e0,0x39);
            iVar13 = iStack_1c8;
          }
        }
        iStack_1c8 = iVar13;
        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100c4a;
        func_0x(auStack_68);
        lVar25 = lStack_1a0;
        lVar28 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar29 = *(longlong *)(lVar28 + 0x100);
        if (lVar29 == 0) {
          *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100cde;
          (*_DAT_)();
          lVar29 = *(longlong *)(lVar28 + 0x100);
        }
        if (*(int *)(lVar29 + 0x22c) != 0) {
          *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100cf4;
          (*_DAT_)();
        }
        if (iStack_1c8 != 0) goto LAB_;
        lStack_180 = lVar25;
      }
      else {
        uVar35 = (uint)*(ushort *)(param_1 + 0xe);
        pbVar32 = (byte *)((ulonglong)
                           *(ushort *)
                            (param_1 +
                            (0xfff - (longlong)*(int *)(puVar27 + lStack_188 * 4 + 2)) * 2) +
                          param_1);
        puVar27 = (ushort *)(psVar31 + 1);
        iVar13 = 0;
        if ((*pbVar32 & 1) == 0) {
          *psVar31 = 0;
          *(byte **)(psVar31 + 4) = pbVar32;
          *(undefined4 *)(psVar31 + 2) = 0;
          *(undefined4 *)(psVar31 + 0x13) = 0;
          switch(*pbVar32 & 0xe) {
          default:
            uVar35 = (uint)*(ushort *)(pbVar32 + 2);
            if (0x1f9d < *(ushort *)(pbVar32 + 2) - 1) {
              *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x100f12;
              func_0x(pbVar32,6);
            }
            break;
          case 4:
            uVar35 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar35 = 1;
          }
          *(uint *)(psVar31 + 8) = uVar35;
          lVar29 = lStack_168 + 0x2000;
          if (lStack_140 == 0) {
            lVar29 = 0;
          }
          *(longlong *)(psVar31 + 0xf) = lVar29;
        }
        else {
          *psVar31 = 1;
          *(byte **)(psVar31 + 4) = pbVar32;
          bVar15 = *pbVar32;
          switch(bVar15 & 0x1c) {
          default:
            if ((char)pbVar32[1] < '\0') {
              uVar12 = *(ushort *)(pbVar32 + 1);
              *puVar27 = uVar12;
              sVar11 = 3;
              uVar12 = (uVar12 & 0x7f) << 8 | uVar12 >> 8;
            }
            else {
              sVar11 = 2;
              uVar12 = (ushort)pbVar32[1];
            }
            *puVar27 = uVar12;
            psVar31[0xc] = sVar11;
            uVar12 = *puVar27;
            psVar31[0xe] = (short)(uVar12 + 1 >> 1) + sVar11;
            if (uVar12 < 0x1f) {
              psVar31[0xd] = 0;
              *(undefined4 *)(psVar31 + 2) = 0;
              *(undefined4 *)(psVar31 + 0x18) = 0;
            }
            else {
              iVar17 = uVar12 - 1;
              psVar31[0xd] = ((short)(iVar17 / 0x1e) + (short)(iVar17 >> 0x1f)) -
                             (short)((longlong)iVar17 * 0x88888889 >> 0x3f);
              *(undefined4 *)(psVar31 + 2) = 0;
              *(undefined4 *)(psVar31 + 0x18) = 0;
            }
            break;
          case 4:
            if (((bVar15 & 0x1c) != 4) || (bVar10 = true, (bVar15 & 2) == 0)) {
              bVar10 = false;
            }
            if (!bVar10) {
              uVar18 = 1;
            }
            else {
              *(undefined4 *)(psVar31 + 0x18) = 0;
              uVar18 = 0xf;
            }
            *(undefined8 *)(psVar31 + 0xc) = 0;
            *puVar27 = 0;
            *(undefined8 *)(psVar31 + 0x10) = 0;
            *(undefined8 *)(psVar31 + 8) = 0;
            *(undefined8 *)(psVar31 + 0x14) = 0;
            *(byte **)(psVar31 + 4) = pbVar32;
            *(undefined4 *)(psVar31 + 2) = uVar18;
            *(uint *)(psVar31 + 0x18) = (uint)bVar10;
            break;
          case 8:
            *(undefined8 *)(psVar31 + 0xc) = 0;
            *puVar27 = 0;
            *(undefined8 *)(psVar31 + 0x10) = 0;
            *(undefined8 *)(psVar31 + 8) = 0;
            *(undefined8 *)(psVar31 + 0x14) = 0;
            *(byte **)(psVar31 + 4) = pbVar32;
            *(undefined4 *)(psVar31 + 2) = 9;
            *(undefined4 *)(psVar31 + 0x18) = 0;
          }
          lVar29 = lStack_168 + 0x2000;
          if (lStack_140 == 0) {
            lVar29 = 0;
          }
          *(longlong *)(psVar31 + 0x14) = lVar29;
          *(undefined8 *)(psVar31 + 8) = 0;
        }
        lStack_180 = lStack_1a0;
        if (*psVar31 == 0) {
          if (*(int *)(psVar31 + 2) == 0) {
            *puVar27 = 0;
            uVar35 = *(uint *)(psVar31 + 8);
            uVar21 = (ulonglong)uVar35;
            *(uint *)(psVar31 + 10) = uVar35;
            pbVar32 = *(byte **)(psVar31 + 4);
            bVar15 = *pbVar32;
            if ((bVar15 & 0x10) != 0) {
              uVar35 = uVar35 + 2 + (*(ushort *)(pbVar32 + uVar21) + 7 >> 3);
              uVar21 = (ulonglong)uVar35;
              *(uint *)(psVar31 + 10) = uVar35;
              bVar15 = *pbVar32;
            }
            if ((bVar15 & 0x20) == 0) {
              *(int *)(psVar31 + 2) = (int)uVar21;
              psVar31[0xe] = 0;
              *(int *)(psVar31 + 0xc) = (int)uVar21;
            }
            else {
              puVar30 = (ushort *)(pbVar32 + uVar21);
              uVar12 = *puVar30;
              psVar31[0xe] = uVar12;
              if (uVar12 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar29 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar29 != 0)) &&
                   ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
                    (*(char *)(lVar29 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10104b;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10106f;
                    (*_DAT_)(1,0x130c458,0x142c128,0x80f);
                  }
                }
                uVar7 = *(undefined8 *)(psVar31 + 4);
                *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10107d;
                func_0x(uVar7,3);
                uVar21 = (ulonglong)*(uint *)(psVar31 + 10);
                uVar12 = psVar31[0xe];
              }
              uVar35 = (int)uVar21 + (uVar12 + 1) * 2;
              *(uint *)(psVar31 + 0xc) = uVar35;
              if (0x1f9e < uVar35) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar29 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar29 != 0 &&
                    ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
                     (*(char *)(lVar29 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10111b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10113f;
                    (*_DAT_)(1,0x130c458,0x142c128,0x816);
                  }
                }
                uVar7 = *(undefined8 *)(psVar31 + 4);
                *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10114d;
                func_0x(uVar7,4);
                uVar12 = psVar31[0xe];
                uVar35 = *(uint *)(psVar31 + 0xc);
              }
              uVar20 = (ulonglong)uVar12;
              uVar23 = puVar30[uVar20] & 0x7fff;
              *(uint *)(psVar31 + 2) = uVar23;
              if (uVar23 < uVar35) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar29 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                    lVar29 != 0)) &&
                   ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
                    (*(char *)(lVar29 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1011e9;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10120d;
                    (*_DAT_)(1,0x130c458,0x142c128,0x81d);
                  }
                }
                uVar7 = *(undefined8 *)(psVar31 + 4);
                *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10121b;
                func_0x(uVar7,4);
                uVar20 = (ulonglong)(ushort)psVar31[0xe];
                uVar23 = *(uint *)(psVar31 + 2);
              }
              uVar21 = (ulonglong)uVar23;
              if ((short)puVar30[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
                pbVar32 = *(byte **)(psVar31 + 4);
                do {
                  if ((int)uVar20 == 1) {
                    uVar35 = *(uint *)(psVar31 + 0xc);
                    uVar23 = uVar35;
code_r0x00101267:
                    if ((*(ushort *)(pbVar32 + uVar20 * 2 + (ulonglong)*(uint *)(psVar31 + 10)) &
                        0x7fff) < uVar35) goto code_r0x00101274;
                  }
                  else {
                    uVar35 = *(ushort *)
                              (pbVar32 + uVar20 * 2 + ((ulonglong)*(uint *)(psVar31 + 10) - 2)) &
                             0x7fff;
                    uVar23 = *(uint *)(psVar31 + 0xc);
                    if (uVar23 <= uVar35) goto code_r0x00101267;
code_r0x00101274:
                    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x101281;
                    func_0x(pbVar32,7);
                    uVar23 = *(uint *)(psVar31 + 0xc);
                  }
                  if ((uVar35 < uVar23) ||
                     (uVar21 = (ulonglong)*(uint *)(psVar31 + 2), *(uint *)(psVar31 + 2) < uVar35))
                  goto code_r0x00101547;
                  pbVar32 = *(byte **)(psVar31 + 4);
                  if (*(ushort *)(pbVar32 + uVar35) == 5) {
                    *puVar27 = *puVar27 | 2;
                    psVar31[0xe] = psVar31[0xe] + -1;
                    psVar31[0x15] = (short)uVar35;
                    uVar12 = psVar31[0x16] & 0xc7ff;
                    if ((*(ushort *)(pbVar32 + (ulonglong)(uVar35 & 0xffff) + 2) >> 0xe & 1) != 0) {
                      uVar12 = *(ushort *)(pbVar32 + (ulonglong)(uVar35 & 0xffff) + 2) & 0x3800 |
                               uVar12;
                    }
                    psVar31[0x16] = uVar12;
                    psVar31[0x16] =
                         (uVar12 ^ *(ushort *)(pbVar32 + (ulonglong)(uVar35 & 0xffff) + 2)) & 0x7ff
                         ^ uVar12;
                    uVar21 = (ulonglong)*(uint *)(psVar31 + 2);
                    goto code_r0x0010133e;
                  }
                  if (*(ushort *)(pbVar32 + uVar35) < 0x400) goto code_r0x0010133e;
                  *puVar27 = *puVar27 | 1;
                  uVar12 = psVar31[0xe] - 1;
                  psVar31[0xe] = uVar12;
                  if (uVar12 == 0) goto code_r0x0010133e;
                  uVar20 = (ulonglong)uVar12;
                } while ((short)puVar30[(ulonglong)(uVar12 - 1) + 1] < 0);
              }
              else {
code_r0x0010133e:
                pbVar32 = *(byte **)(psVar31 + 4);
              }
            }
            if ((*pbVar32 & 0x40) == 0) {
              *(undefined4 *)(psVar31 + 0x13) = 0;
            }
            else {
              *(int *)(psVar31 + 0x13) = (int)uVar21;
              *(int *)(psVar31 + 2) = (int)uVar21 + 0xe;
              *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x101368;
              puVar14 = (ulonglong *)func_0x(puVar27);
              uVar12 = (ushort)(*puVar14 >> 0x30);
              if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
                if ((uVar12 >> 0xe & 1) == 0) {
                  uVar12 = uVar12 & 0xdfff;
                }
                else {
                  uVar12 = uVar12 | 0x2000;
                }
              }
              if (uVar12 == 0xfffc) {
                iVar13 = (int)((*puVar14 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar13;
              uVar21 = (ulonglong)*(uint *)(psVar31 + 2);
            }
            iVar13 = (int)uVar21;
            if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
               (*(ulonglong *)(psVar31 + 0xf) < uVar21 + *(longlong *)(psVar31 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar29 = *(longlong *)
                              (*(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                   lVar29 != 0 && (lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0)) &&
                  (*(char *)(lVar29 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x101457;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                  *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10147b;
                  (*_DAT_)(1,0x130c458,0x142c128,0x877);
                }
              }
              uVar7 = *(undefined8 *)(psVar31 + 4);
              *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x101489;
              func_0x(uVar7,0x12);
              iVar13 = *(int *)(psVar31 + 2);
            }
            if (0x3f3b < iVar13 - 1U) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar29 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar29 != 0 &&
                  ((lVar29 = *(longlong *)(lVar29 + 0x60), lVar29 != 0 &&
                   (*(char *)(lVar29 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x101515;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_1f8 + lVar9 + lVar8) = 0;
                  *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x101539;
                  (*_DAT_)(1,0x130c458,0x142c128,0x87c);
                }
              }
              uVar7 = *(undefined8 *)(psVar31 + 4);
              *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x101547;
              func_0x(uVar7,5);
            }
          }
code_r0x00101547:
          uVar35 = *(uint *)(psVar31 + 2);
          uStack_1a8 = uVar35;
          if (uVar35 < 9) {
            bVar15 = **(byte **)(psVar31 + 4) & 0xe;
joined_r0x00101581:
            if ((bVar15 == 0) || (uStack_1a8 = uVar35, bVar15 == 0xc)) {
              uStack_1a8 = 9;
            }
          }
        }
        else {
          uVar35 = *(uint *)(psVar31 + 2);
          if (uVar35 == 0) {
            *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10156f;
            func_0x(puVar27);
            uVar35 = *(uint *)(psVar31 + 2);
          }
          uStack_1a8 = uVar35;
          if (uVar35 < 9) {
            bVar15 = **(byte **)(psVar31 + 4) & 0x1c;
            goto joined_r0x00101581;
          }
        }
      }
      lVar29 = lStack_138;
      lVar25 = lStack_188;
      uVar23 = uStack_1a8;
      puVar27 = puStack_1b8;
      bVar15 = (byte)*(undefined2 *)(param_1 + 4);
      sVar11 = 1 << (bVar15 & 2);
      uVar35 = (uint)(ushort)(sVar11 + -1 + (short)uStack_1a8 + puStack_1b8[lStack_188 * 4] &
                             -sVar11);
      if (((*(ushort *)(lStack_138 + 0x1e) < uVar35) && (iStack_1c8 = iStack_1c8 + 1, param_3 != 0))
         && (param_3 == 2)) {
        *(uint *)((longlong)alStack_1f0 + lVar9 + lVar8) = (uint)*(ushort *)(lStack_138 + 0x1e);
        *(undefined4 *)((longlong)&uStack_1f8 + lVar9 + lVar8) =
             *(undefined4 *)(puVar27 + lVar25 * 4 + 2);
        *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10160b;
        func_0x(0x22ef,param_1,0x1344480,1);
        bVar15 = (byte)*(undefined2 *)(lStack_168 + 4);
      }
      uVar12 = (1 << (bVar15 & 2)) - 1;
      uStack_1b0 = uStack_1b0 + (-2 - (uVar12 + uVar23 & 0xffff & (uint)(ushort)~uVar12));
      if (iStack_1c8 != 0) goto LAB_;
      uVar21 = (ulonglong)uStack_1a4;
      uVar20 = (ulonglong)(iStack_1ac + 1);
    }
  }
  if ((*(ushort *)(lVar29 + 0x1e) < uVar35) && (iStack_1c8 = 1, param_3 == 2)) {
    *(uint *)((longlong)alStack_1f0 + lVar9 + lVar8) = (uint)*(ushort *)(lVar29 + 0x1e);
    *(uint *)((longlong)&uStack_1f8 + lVar9 + lVar8) = uVar35;
    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x101689;
    func_0x(0x22eb,param_1,0x1344480,0x69);
  }
  if (((*(char *)(lVar29 + 1) != '\x0e') && (uVar12 = *(ushort *)(lVar29 + 0x1c), uVar12 != uVar23))
     && (iStack_1c8 = iStack_1c8 + 1, param_3 == 2)) {
    *(uint *)((longlong)alStack_1f0 + lVar9 + lVar8) = uVar23;
    *(uint *)((longlong)&uStack_1f8 + lVar9 + lVar8) = (uint)uVar12;
    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1016c0;
    func_0x(0x22eb,param_1,0x1344448,0x6a);
  }
  lVar25 = lStack_1a0;
  if (*(char *)(param_1 + 2) < '\0') {
    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1016d0;
    sVar11 = func_0x(lVar25);
    uVar12 = sVar11 + 0x60;
  }
  else {
    uVar12 = 0x60;
  }
  lVar25 = lStack_118;
  uVar16 = 0x60;
  uVar22 = *(ushort *)(lVar29 + 0x16);
  if (((ulonglong)uVar12 + (0xfd0 - (ulonglong)uVar22) * 2 < (ulonglong)*(ushort *)(lVar29 + 0x1e))
     && (iStack_1c8 = iStack_1c8 + 1, param_3 == 2)) {
    if (*(char *)(param_1 + 2) < '\0') {
      *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10171e;
      sVar11 = func_0x(lVar25);
      uVar22 = *(ushort *)(lStack_168 + 0x16);
      uVar16 = sVar11 + 0x60;
    }
    uVar12 = *(ushort *)(lVar29 + 0x1c);
    *(uint *)((longlong)alStack_1f0 + lVar9 + lVar8) = (uint)uVar16 + (0xfd0 - (uint)uVar22) * 2;
    *(uint *)((longlong)&uStack_1f8 + lVar9 + lVar8) = (uint)uVar12;
    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10175f;
    func_0x(0x22eb,param_1,0x1344340,0x6b);
  }
  uVar35 = uStack_1a4;
  if ((((*(byte *)(param_1 + 4) & 8) == 0) && (uStack_1a4 != 0)) &&
     (iStack_1c8 = iStack_1c8 + 1, param_3 == 2)) {
    *(undefined4 *)((longlong)alStack_1f0 + lVar9 + lVar8) = 0;
    *(uint *)((longlong)&uStack_1f8 + lVar9 + lVar8) = uVar35;
    *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x10179c;
    func_0x(0x22eb,param_1,0x1344508,0x6c);
  }
LAB_:
  uVar21 = uStack_40 ^ (ulonglong)&iStack_1c8;
  *(undefined8 *)((longlong)auStack_220 + lVar9 + lVar8) = 0x1017b2;
  func_0x(uVar21);
  return;
}

