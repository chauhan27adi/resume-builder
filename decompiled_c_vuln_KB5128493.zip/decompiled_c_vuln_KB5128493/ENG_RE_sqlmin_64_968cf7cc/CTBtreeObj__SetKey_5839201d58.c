
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  ushort uVar1;
  ulonglong *puVar2;
  ulonglong uVar3;
  ushort uVar4;
  uint uVar5;
  uint uVar6;
  undefined4 uVar7;
  ulonglong uVar8;
  int iVar9;
  byte bVar10;
  byte *pbVar11;
  longlong lVar12;
  ushort *puVar13;
  longlong unaff_GS_OFFSET;
  
  if (param_2 == (short *)0x0) {
    *(undefined *)(param_1 + 0x6e) = 0;
    *(undefined2 *)(param_1 + 0x50) = 0x70;
    *(undefined4 *)(param_1 + 0x68) = 0;
    return;
  }
  *(undefined *)(param_1 + 0x6e) = 1;
  if (*param_2 == 0) {
    if (*(int *)(param_2 + 2) == 0) {
      pbVar11 = *(byte **)(param_2 + 4);
      param_2[1] = 0;
      uVar5 = *(uint *)(param_2 + 8);
      uVar8 = (ulonglong)uVar5;
      *(uint *)(param_2 + 10) = uVar5;
      bVar10 = *pbVar11;
      if ((bVar10 & 0x10) != 0) {
        uVar5 = uVar5 + 2 + (*(ushort *)(pbVar11 + uVar8) + 7 >> 3);
        uVar8 = (ulonglong)uVar5;
        *(uint *)(param_2 + 10) = uVar5;
        bVar10 = *pbVar11;
      }
      if ((bVar10 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar8;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar8;
      }
      else {
        puVar13 = (ushort *)(pbVar11 + uVar8);
        uVar1 = *puVar13;
        param_2[0xe] = uVar1;
        if (uVar1 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xdb02a8,0xecff78,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar8 = (ulonglong)*(uint *)(param_2 + 10);
          uVar1 = param_2[0xe];
        }
        uVar5 = (int)uVar8 + (uVar1 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar5;
        if (0x1f9e < uVar5) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar12 != 0 &&
              ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
               (*(char *)(lVar12 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdb02a8,0xecff78,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar1 = param_2[0xe];
          uVar5 = *(uint *)(param_2 + 0xc);
        }
        uVar3 = (ulonglong)uVar1;
        uVar6 = puVar13[uVar3] & 0x7fff;
        *(uint *)(param_2 + 2) = uVar6;
        if (uVar6 < uVar5) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdb02a8,0xecff78,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar3 = (ulonglong)(ushort)param_2[0xe];
          uVar6 = *(uint *)(param_2 + 2);
        }
        uVar8 = (ulonglong)uVar6;
        if ((short)puVar13[(ulonglong)((int)uVar3 - 1) + 1] < 0) {
          pbVar11 = *(byte **)(param_2 + 4);
          do {
            if ((int)uVar3 == 1) {
              uVar5 = *(uint *)(param_2 + 0xc);
              uVar6 = uVar5;
LAB_:
              if ((*(ushort *)(pbVar11 + uVar3 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff) <
                  uVar5) goto LAB_;
            }
            else {
              uVar6 = *(uint *)(param_2 + 0xc);
              uVar5 = *(ushort *)(pbVar11 + uVar3 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                      0x7fff;
              if (uVar6 <= uVar5) goto LAB_;
LAB_:
              func_0x(pbVar11,7);
              uVar6 = *(uint *)(param_2 + 0xc);
            }
            if ((uVar5 < uVar6) ||
               (uVar8 = (ulonglong)*(uint *)(param_2 + 2), *(uint *)(param_2 + 2) < uVar5))
            goto LAB_;
            pbVar11 = *(byte **)(param_2 + 4);
            if (*(ushort *)(pbVar11 + uVar5) == 5) {
              param_2[1] = param_2[1] | 2;
              param_2[0xe] = param_2[0xe] + -1;
              param_2[0x15] = (short)uVar5;
              lVar12 = (ulonglong)(uVar5 & 0xffff) + *(longlong *)(param_2 + 4);
              uVar1 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar12 + 2) >> 0xe & 1) != 0) {
                uVar1 = *(ushort *)(lVar12 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar1;
              param_2[0x16] = (uVar1 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar1;
              uVar8 = (ulonglong)*(uint *)(param_2 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar11 + uVar5) < 0x400) goto LAB_;
            param_2[1] = param_2[1] | 1;
            uVar1 = param_2[0xe] - 1;
            param_2[0xe] = uVar1;
            if (uVar1 == 0) goto LAB_;
            uVar3 = (ulonglong)uVar1;
          } while ((short)puVar13[(ulonglong)(uVar1 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar11 = *(byte **)(param_2 + 4);
        }
      }
      iVar9 = 0;
      if ((*pbVar11 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar8;
        *(int *)(param_2 + 2) = (int)uVar8 + 0xe;
        puVar2 = (ulonglong *)func_0x(param_2 + 1);
        uVar4 = (ushort)(*puVar2 >> 0x30);
        uVar1 = uVar4;
        if ((((uint)(int)(short)uVar4 >> 1 ^ (int)(short)uVar4) & 0x2000) != 0) {
          uVar1 = uVar4 & 0xdfff;
          if ((uVar4 >> 0xe & 1) != 0) {
            uVar1 = uVar4 | 0x2000;
          }
        }
        if (uVar1 == 0xfffc) {
          iVar9 = (int)((*puVar2 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar9;
        uVar8 = (ulonglong)*(uint *)(param_2 + 2);
      }
      iVar9 = (int)uVar8;
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar8 + *(longlong *)(param_2 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar12 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar12 != 0 &&
             (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xdb02a8,0xecff78,0x877,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        iVar9 = *(int *)(param_2 + 2);
      }
      if (0x3f3b < iVar9 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar12 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar12 != 0 &&
            ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
             (*(char *)(lVar12 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0xdb02a8,0xecff78,0x87c,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
      }
    }
LAB_:
    uVar5 = *(uint *)(param_2 + 2);
    if (8 < uVar5) goto LAB_;
    bVar10 = **(byte **)(param_2 + 4) & 0xe;
  }
  else {
    uVar5 = *(uint *)(param_2 + 2);
    if (uVar5 == 0) {
      func_0x(param_2 + 1);
      uVar5 = *(uint *)(param_2 + 2);
    }
    if (8 < uVar5) goto LAB_;
    bVar10 = **(byte **)(param_2 + 4) & 0x1c;
  }
  if ((bVar10 == 0) || (bVar10 == 0xc)) {
    uVar5 = 9;
  }
LAB_:
  uVar7 = 9;
  *(short *)(param_1 + 0x50) = (short)uVar5 + 0x70;
  if (*param_2 == 0) {
    *(undefined4 *)(param_1 + 0x68) = *(undefined4 *)(param_2 + 8);
    return;
  }
  if ((**(byte **)(param_2 + 4) & 0x1c) == 4) {
    uVar7 = 1;
  }
  else if ((**(byte **)(param_2 + 4) & 0x1c) != 0x10) {
    *(uint *)(param_1 + 0x68) = (uint)(ushort)param_2[0xe] + (uint)(ushort)param_2[0xd];
    return;
  }
  *(undefined4 *)(param_1 + 0x68) = uVar7;
  return;
}

