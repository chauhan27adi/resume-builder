
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 *param_1,longlong param_2)

{
  int iVar1;
  undefined8 uVar2;
  
  switch(*(undefined4 *)(param_2 + 0x28)) {
  case 1000:
    iVar1 = func_0x(param_1[0x192]);
    if (iVar1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    break;
  case 0x3e9:
  case 0x3ea:
  case 0x3f6:
  case 0x3f7:
  case 0x3fa:
  case 0x3fb:
  case 0x3fc:
  case 0x3fd:
  case 0x3fe:
  case 0x3ff:
  case 0x400:
  case 0x401:
  case 0x402:
  case 0x403:
  case 0x404:
  case 0x406:
  case 0x407:
  case 0x40a:
  case 0x417:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  default:
    uVar2 = (**(code **)*param_1)(param_1);
    func_0x(param_1,0xbed5e8,uVar2);
    break;
  case 0x3f5:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  case 0x40d:
    func_0x(param_1[0x192] + 0x17c8,0xbcb,param_1[0x192],0,*(undefined8 *)(param_2 + 0x50),0
                   );
    return;
  case 0x414:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}

