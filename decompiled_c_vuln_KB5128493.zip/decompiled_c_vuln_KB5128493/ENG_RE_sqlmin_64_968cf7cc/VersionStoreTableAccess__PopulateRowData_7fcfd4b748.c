
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int *param_2,ulonglong *param_3,longlong param_4,
                 undefined4 param_5,uint *param_6,undefined *param_7)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  undefined2 uVar4;
  byte **ppbVar5;
  uint **ppuVar6;
  char cVar7;
  ushort uVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  longlong lVar12;
  byte **ppbVar13;
  uint *puVar14;
  longlong lVar15;
  short *psVar16;
  undefined4 *puVar17;
  ulonglong *puVar18;
  undefined4 uVar19;
  uint uVar20;
  short sVar21;
  ushort uVar22;
  undefined *puVar23;
  int iVar24;
  ushort *puVar25;
  ulonglong *puVar26;
  uint uVar27;
  byte **ppbVar28;
  short sVar30;
  ulonglong uVar31;
  byte *pbVar32;
  uint uVar33;
  ulonglong uVar34;
  int *piVar35;
  longlong unaff_GS_OFFSET;
  undefined auStack_5a8 [32];
  undefined8 uStack_588;
  undefined8 uStack_580;
  uint *puStack_578;
  undefined8 uStack_570;
  uint auStack_568 [2];
  byte **ppbStack_560;
  undefined uStack_558;
  uint uStack_554;
  uint uStack_550;
  uint uStack_548;
  ushort uStack_544;
  ushort uStack_542;
  uint *puStack_540;
  undefined4 uStack_538;
  undefined2 uStack_534;
  undefined8 uStack_530;
  undefined4 uStack_528;
  uint uStack_524;
  undefined4 uStack_520;
  uint uStack_51c;
  undefined8 uStack_518;
  ushort uStack_510;
  undefined8 uStack_508;
  ushort uStack_500;
  undefined auStack_4f8 [4];
  undefined4 uStack_4f4;
  int *piStack_4f0;
  undefined4 uStack_4e8;
  undefined2 uStack_4e4;
  undefined4 uStack_4e0;
  undefined2 uStack_4dc;
  undefined4 uStack_4d8;
  undefined2 uStack_4d4;
  undefined8 uStack_4d0;
  undefined2 uStack_4c8;
  undefined8 uStack_4c0;
  undefined2 uStack_4b8;
  ulonglong *puStack_4b0;
  undefined *puStack_4a8;
  undefined8 uStack_4a0;
  undefined2 uStack_498;
  undefined8 uStack_490;
  ushort uStack_488;
  undefined auStack_480 [8];
  uint *puStack_478;
  longlong lStack_470;
  undefined auStack_468 [4];
  undefined auStack_464 [4];
  undefined auStack_460 [8];
  uint uStack_458;
  undefined8 uStack_454;
  undefined4 auStack_440 [2];
  undefined8 uStack_438;
  undefined8 uStack_430;
  undefined8 uStack_428;
  undefined8 uStack_420;
  undefined8 uStack_418;
  undefined auStack_408 [8];
  undefined4 uStack_400;
  undefined4 uStack_3f8;
  uint **ppuStack_3f0;
  undefined *puStack_3e8;
  undefined8 uStack_3e0;
  uint *puStack_3d8;
  undefined4 uStack_3d0;
  undefined4 uStack_3cc;
  longlong lStack_3c8;
  undefined4 uStack_3c0;
  undefined4 uStack_3bc;
  longlong lStack_3b8;
  undefined4 uStack_3b0;
  undefined4 uStack_3ac;
  short *psStack_3a8;
  int iStack_3a0;
  undefined4 uStack_39c;
  short *psStack_398;
  int iStack_390;
  undefined4 uStack_38c;
  undefined8 uStack_388;
  undefined4 uStack_380;
  undefined4 uStack_37c;
  undefined auStack_378 [448];
  undefined8 uStack_1b8;
  undefined8 uStack_1b0;
  uint uStack_1a8;
  undefined2 uStack_1a4;
  int iStack_1a2;
  undefined uStack_19e;
  byte bStack_19d;
  short sStack_168;
  ushort uStack_166;
  uint uStack_164;
  byte **ppbStack_160;
  undefined8 uStack_158;
  undefined4 uStack_150;
  ushort uStack_14c;
  undefined2 uStack_14a;
  undefined6 uStack_148;
  undefined2 uStack_142;
  undefined2 uStack_140;
  undefined2 uStack_13e;
  ushort uStack_13c;
  undefined2 uStack_13a;
  undefined4 uStack_138;
  int iStack_134;
  undefined auStack_130 [16];
  undefined auStack_120 [8];
  undefined8 uStack_118;
  undefined8 uStack_110;
  undefined6 uStack_108;
  undefined2 uStack_102;
  undefined6 uStack_100;
  undefined2 uStack_fa;
  undefined8 uStack_f8;
  undefined auStack_f0 [16];
  undefined auStack_e0 [16];
  undefined auStack_d0 [16];
  undefined8 uStack_c0;
  short asStack_b8 [24];
  short asStack_88 [24];
  ulonglong uStack_58;
  byte **ppbVar29;
  
  uStack_418 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_5a8;
  puStack_4a8 = param_7;
  puStack_478 = param_6;
  ppbVar29 = (byte **)0x0;
  ppbVar28 = (byte **)0x0;
  ppbStack_560 = (byte **)0x0;
  uStack_558 = 0;
  uStack_554 = 0;
  sStack_168 = -1;
  ppbStack_160 = (byte **)0x0;
  uStack_164 = 0;
  uStack_14a = 0;
  uStack_148 = 0;
  uStack_140 = 0;
  uStack_13e = 0;
  uStack_13c = 0;
  uStack_13a = 0;
  uStack_158 = (byte **)0x0;
  iStack_134 = -1;
  auStack_568[0] = 0;
  lVar15 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x10) + 0x60) + 0x30);
  uVar27 = 0;
  piStack_4f0 = param_2;
  puStack_4b0 = param_3;
  lStack_470 = param_4;
  if (((*(short *)(param_6 + 2) != 0) || (*param_6 != 0)) || (param_6[1] != 0)) {
    if (param_7 == (undefined *)0x0) {
      uStack_588 = (uint *)0x0;
      (*_DAT_)(1,0x10fc680,0x10b5238,0x13c8);
    }
    lVar12 = func_0x(*(undefined8 *)(lVar15 + 0x6a0));
    iVar10 = *param_2;
    uVar4 = *(undefined2 *)(lVar12 + 0x5f0);
    iVar24 = 0x3c;
    do {
      uStack_570 = 0;
      puStack_578 = (uint *)0x0;
      uStack_580 = (uint *)CONCAT44(uStack_580._4_4_,10000);
      uStack_588 = param_6;
      iVar9 = func_0x(lVar15,uVar4,iVar10,1);
      if (-1 < iVar9) goto LAB_;
      auStack_440[0] = 0x400060;
      uStack_438 = 0;
      uStack_428 = 0;
      uStack_430 = 0;
      uStack_420 = 0;
      func_0x(100,auStack_440);
      iVar24 = iVar24 + -1;
      puVar23 = puStack_4a8;
    } while (iVar24 != 0);
LAB_:
    *puVar23 = 1;
code_r0x00101f39:
    func_0x(&ppbStack_560);
    func_0x(uStack_58 ^ (ulonglong)auStack_5a8);
    return;
  }
LAB_:
  uStack_454 = 0;
  ppbVar13 = ppbVar29;
  if ((((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) &&
      ((lVar12 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar12 == 0 ||
       ((lVar12 = **(longlong **)(lVar12 + 0x38), lVar12 == 0 ||
        (iVar10 = (*_DAT_)(lVar12,0x337), iVar10 == 0)))))) &&
     (lVar12 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8),
     lVar12 != 0)) {
    ppbVar13 = *(byte ***)(lVar12 + 0x60);
  }
  lVar12 = *(longlong *)(lVar15 + 0x728);
  uStack_520 = 2;
  do {
    ppbVar5 = ppbStack_560;
    uStack_524 = 0;
    if (ppbStack_560 != (byte **)0x0) {
      iVar10 = (int)(short)uStack_554;
      if (((*(ushort *)((longlong)ppbStack_560 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
        if (((byte)*(undefined2 *)((longlong)ppbStack_560 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)((longlong)ppbStack_560 + 100) & 8) != 0) &&
              (pbVar32 = ppbStack_560[0x12], pbVar32 != (byte *)0x0)) &&
             (*(longlong *)(pbVar32 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(pbVar32 + 0x758),ppbStack_560,iVar10);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)ppbVar5 + 100) & 8) != 0)) &&
            ((2 < iVar10 &&
             (((*(uint *)((longlong)ppbVar5 + 100) & 0xc0000000) != 0x40000000 &&
              (*ppbVar5 != (byte *)0x0)))))) &&
           (iVar24 = (*_DAT_)(*ppbVar5,0x2000,2,auStack_468), iVar24 != 0)) {
          LOCK();
          *(uint *)((longlong)ppbVar5 + 100) = *(uint *)((longlong)ppbVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)ppbVar5 + 100) = *(uint *)((longlong)ppbVar5 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(ppbVar5 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(ppbVar5,0,iVar10);
        }
        uStack_554 = uStack_554 & 0xffff0000;
        ppbStack_560 = (byte **)0x0;
      }
      else {
        func_0x(&ppbStack_560);
      }
    }
    piVar35 = piStack_4f0;
    if ((*(longlong *)(lVar15 + 0x728) != 0) &&
       (func_0x(&ppbStack_560,piStack_4f0,lVar15), ppbVar5 = ppbStack_560,
       ppbStack_560 != (byte **)0x0)) {
      iVar10 = (int)(short)uStack_554;
      if (((*(ushort *)((longlong)ppbStack_560 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
        if (((byte)*(undefined2 *)((longlong)ppbStack_560 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)((longlong)ppbStack_560 + 100) & 8) != 0) &&
              (pbVar32 = ppbStack_560[0x12], pbVar32 != (byte *)0x0)) &&
             (*(longlong *)(pbVar32 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(pbVar32 + 0x758),ppbStack_560,iVar10);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)ppbVar5 + 100) & 8) != 0)) &&
            ((2 < iVar10 &&
             (((*(uint *)((longlong)ppbVar5 + 100) & 0xc0000000) != 0x40000000 &&
              (*ppbVar5 != (byte *)0x0)))))) &&
           (iVar24 = (*_DAT_)(*ppbVar5,0x2000,2,auStack_464), iVar24 != 0)) {
          LOCK();
          *(uint *)((longlong)ppbVar5 + 100) = *(uint *)((longlong)ppbVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)ppbVar5 + 100) = *(uint *)((longlong)ppbVar5 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(ppbVar5 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(ppbVar5,0,iVar10);
        }
        uStack_554 = uStack_554 & 0xffff0000;
        ppbStack_560 = (byte **)0x0;
        piVar35 = piStack_4f0;
      }
      else {
        func_0x(&ppbStack_560);
      }
    }
    uStack_580 = &uStack_458;
    uStack_588 = (uint *)CONCAT44(uStack_588._4_4_,2);
    ppbStack_560 = (byte **)func_0x(_DAT_,lVar15,piVar35,&uStack_524);
    if (ppbVar13 != (byte **)0x0) {
      if (ppbVar13[(ulonglong)(*(uint *)(ppbVar13 + 0xa0) & 0xf) + 0xa1] != *ppbStack_560) {
        ppbVar13[(ulonglong)(*(uint *)(ppbVar13 + 0xa0) & 0xf) + 0xa1] = *ppbStack_560;
        ppbVar13[0xa0] = ppbVar13[0xa0] + 1;
      }
    }
    uStack_554 = (uStack_524 >> 3 & 1) << 0x18 | uStack_554 & 0xff0002 | 2;
    uStack_550 = uStack_524 >> 4 & 1 | uStack_550 & 0xffffff00;
    if (((lVar12 != 0) && (ppbVar13 != (byte **)0x0)) && (ppbVar13 == *(byte ***)(lVar15 + 0x1c38)))
    {
      *(longlong *)(lVar12 + 0x5b28) = *(longlong *)(lVar12 + 0x5b28) + 1;
      if ((int)uStack_454 != 0) {
        *(longlong *)(lVar12 + 0x5b30) = *(longlong *)(lVar12 + 0x5b30) + 1;
        *(longlong *)(lVar12 + 0x5b38) = *(longlong *)(lVar12 + 0x5b38) + (ulonglong)uStack_458;
        if (0xffffff < uStack_554) {
          *(longlong *)(lVar12 + 0x5b40) = *(longlong *)(lVar12 + 0x5b40) + 1;
          *(longlong *)(lVar12 + 0x5b48) = *(longlong *)(lVar12 + 0x5b48) + (ulonglong)uStack_458;
        }
      }
    }
    cVar7 = func_0x(lVar15);
    if (((cVar7 == '\0') || (*(char *)(lVar15 + 0x2050) == '\0')) ||
       ((*piVar35 == 0 || ((*piVar35 == 9 && (*(short *)(piVar35 + 1) == 1)))))) goto LAB_;
    pbVar32 = *ppbStack_560;
    if (*(short *)(pbVar32 + 0x24) == 0) {
LAB_:
      uStack_508 = *(undefined8 *)(pbVar32 + 0x28);
      uStack_500 = *(ushort *)(pbVar32 + 0x30);
    }
    else {
      bVar3 = pbVar32[1];
      if (bVar3 == 0xb) {
        if (*(int *)(pbVar32 + 0x18) != 99) {
LAB_:
          if (bVar3 != 9) goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (bVar3 != 8) goto LAB_;
LAB_:
        if (*(int *)(pbVar32 + 0x18) != 99) goto LAB_;
      }
      uStack_4e8 = *(undefined4 *)(pbVar32 + 0x20);
      uStack_4e4 = *(undefined2 *)(pbVar32 + 0x24);
      cVar7 = func_0x(&uStack_4e8);
      if (cVar7 == '\0') goto LAB_;
      func_0x(pbVar32,&uStack_508);
    }
    uVar33 = *(uint *)(lVar15 + 0x2108);
    do {
      uVar11 = uVar33 & 0xfffffffe;
      uStack_530 = *(undefined8 *)(lVar15 + 0x20fc);
      uStack_528 = *(undefined4 *)(lVar15 + 0x2104);
      LOCK();
      UNLOCK();
      uVar33 = *(uint *)(lVar15 + 0x2108);
    } while (uVar11 != uVar33);
    if ((uint)uStack_508 <= (uint)uStack_530) {
      if ((uint)uStack_530 != (uint)uStack_508) goto LAB_;
      uVar33 = (uint)((ulonglong)uStack_530 >> 0x20);
      if ((uStack_508._4_4_ <= uVar33) &&
         ((uVar33 != uStack_508._4_4_ || (uStack_500 <= (ushort)uStack_528)))) goto LAB_;
    }
    if ((*(char *)(lVar15 + 0x6ac8) == '\0') &&
       ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) != *(longlong *)(lVar15 + 0x2120) &&
        (cVar7 = func_0x(lVar15), cVar7 == '\0')))) break;
    if ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) == *(longlong *)(lVar15 + 0x2120)) ||
       (cVar7 = func_0x(lVar15), cVar7 != '\0')) goto LAB_;
    if (ppbVar13 == (byte **)0x0) {
      ppbVar13 = (byte **)func_0x();
    }
    pbVar32 = *ppbStack_560;
    if (*(short *)(pbVar32 + 0x24) == 0) {
LAB_:
      uStack_4d0 = *(undefined8 *)(pbVar32 + 0x28);
      uStack_4c8 = *(undefined2 *)(pbVar32 + 0x30);
    }
    else {
      bVar3 = pbVar32[1];
      if (bVar3 == 0xb) {
        if (*(int *)(pbVar32 + 0x18) != 99) {
LAB_:
          if (bVar3 != 9) goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (bVar3 != 8) goto LAB_;
LAB_:
        if (*(int *)(pbVar32 + 0x18) != 99) goto LAB_;
      }
      uStack_4e0 = *(undefined4 *)(pbVar32 + 0x20);
      uStack_4dc = *(undefined2 *)(pbVar32 + 0x24);
      cVar7 = func_0x(&uStack_4e0);
      if (cVar7 == '\0') goto LAB_;
      func_0x(pbVar32,&uStack_4d0);
    }
    ppbVar5 = ppbStack_560;
    if (ppbStack_560 != (byte **)0x0) {
      iVar10 = (int)(short)uStack_554;
      if (((*(ushort *)((longlong)ppbStack_560 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
        if (((byte)*(undefined2 *)((longlong)ppbStack_560 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)((longlong)ppbStack_560 + 100) & 8) != 0) &&
              (pbVar32 = ppbStack_560[0x12], pbVar32 != (byte *)0x0)) &&
             (*(longlong *)(pbVar32 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(pbVar32 + 0x758),ppbStack_560,iVar10);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)ppbVar5 + 100) & 8) != 0)) &&
            ((2 < iVar10 &&
             (((*(uint *)((longlong)ppbVar5 + 100) & 0xc0000000) != 0x40000000 &&
              (*ppbVar5 != (byte *)0x0)))))) &&
           (iVar24 = (*_DAT_)(*ppbVar5,0x2000,2,auStack_460), iVar24 != 0)) {
          LOCK();
          *(uint *)((longlong)ppbVar5 + 100) = *(uint *)((longlong)ppbVar5 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)ppbVar5 + 100) = *(uint *)((longlong)ppbVar5 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(ppbVar5 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(ppbVar5,0,iVar10);
        }
        uStack_554 = uStack_554 & 0xffff0000;
        ppbStack_560 = (byte **)0x0;
      }
      else {
        func_0x(&ppbStack_560);
      }
    }
    uStack_4a0 = uStack_4d0;
    uStack_498 = uStack_4c8;
    uStack_588 = (uint *)0x0;
    func_0x(*(undefined8 *)(lVar15 + 0x728),&uStack_4a0,4);
  } while( true );
  uVar33 = *(uint *)(lVar15 + 0x2108);
  do {
    uVar11 = uVar33 & 0xfffffffe;
    uStack_530 = *(undefined8 *)(lVar15 + 0x20fc);
    uStack_528 = *(undefined4 *)(lVar15 + 0x2104);
    LOCK();
    UNLOCK();
    uVar33 = *(uint *)(lVar15 + 0x2108);
  } while (uVar11 != uVar33);
  uVar8 = (ushort)uStack_528;
  uStack_488 = (ushort)uStack_528;
  pbVar32 = *ppbStack_560;
  uStack_490 = uStack_530;
  if (*(short *)(pbVar32 + 0x24) == 0) {
LAB_:
    uStack_518 = *(undefined8 *)(pbVar32 + 0x28);
    uStack_510 = *(ushort *)(pbVar32 + 0x30);
  }
  else {
    bVar3 = pbVar32[1];
    if (bVar3 == 0xb) {
      if (*(int *)(pbVar32 + 0x18) != 99) {
LAB_:
        if (bVar3 != 9) goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (bVar3 != 8) goto LAB_;
LAB_:
      if (*(int *)(pbVar32 + 0x18) != 99) goto LAB_;
    }
    uStack_4d8 = *(undefined4 *)(pbVar32 + 0x20);
    uStack_4d4 = *(undefined2 *)(pbVar32 + 0x24);
    cVar7 = func_0x(&uStack_4d8);
    if (cVar7 == '\0') goto LAB_;
    func_0x(pbVar32,&uStack_518);
  }
  if ((uint)uStack_530 < (uint)uStack_518) {
LAB_:
    lVar12 = *(longlong *)(lVar15 + 0x6b0);
    func_0x(&uStack_518,asStack_b8,auStack_4f8);
    func_0x(&uStack_490,asStack_88,auStack_4f8);
    if ((_DAT_ & 0x10000) != 0) {
      uStack_400 = 0x60000;
      uStack_3f8 = 0;
      ppuStack_3f0 = &puStack_3d8;
      puStack_3e8 = auStack_378;
      uStack_1b8 = 0;
      uStack_3e0 = 0;
      uStack_1b0 = 0;
      puStack_3d8 = &uStack_1a8;
      uStack_3d0 = 0x34;
      uStack_3cc = 5;
      uStack_3c0 = 0x10;
      uStack_3bc = 5;
      uStack_3b0 = 0x10;
      uStack_3ac = 6;
      uStack_39c = 7;
      uStack_38c = 8;
      uStack_388 = 0;
      uStack_380 = 0;
      uStack_37c = 9;
      uStack_1a8 = (uint)*(ushort *)(lVar15 + 0x6b8);
      uStack_1a4 = *(undefined2 *)(piVar35 + 1);
      iStack_1a2 = *piVar35;
      uStack_19e = 1;
      bStack_19d = (*ppbStack_560)[1];
      lStack_3c8 = lVar12 + 0x254;
      lStack_3b8 = lVar12 + 0x244;
      lVar15 = -1;
      do {
        lVar15 = lVar15 + 1;
      } while (asStack_b8[lVar15] != 0);
      iStack_3a0 = (int)lVar15 * 2;
      psStack_3a8 = asStack_b8;
      lVar15 = -1;
      do {
        lVar15 = lVar15 + 1;
      } while (asStack_88[lVar15] != 0);
      iStack_390 = (int)lVar15 * 2;
      psStack_398 = asStack_88;
      uStack_4f4 = 0;
      puVar14 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar12,&uStack_4f4);
      ppuVar6 = ppuStack_3f0;
      uVar33 = uVar27;
      if (puVar14 != (uint *)0x0) {
        lVar15 = -1;
        do {
          lVar15 = lVar15 + 1;
        } while (*(short *)((longlong)puVar14 + lVar15 * 2) != 0);
        uVar33 = (int)lVar15 * 2;
      }
      ppuStack_3f0[10] = puVar14;
      *(uint *)(ppuVar6 + 0xb) = uVar33;
      *(undefined4 *)((longlong)ppuVar6 + 0x5c) = 9;
      func_0x(auStack_408);
    }
  }
  else if ((uint)uStack_530 == (uint)uStack_518) {
    uVar33 = (uint)((ulonglong)uStack_518 >> 0x20);
    if ((uStack_530._4_4_ < uVar33) || ((uStack_530._4_4_ == uVar33 && (uVar8 < uStack_510))))
    goto LAB_;
  }
LAB_:
  uVar34 = 8;
  if ((1 < (short)uStack_554) && ((*ppbStack_560)[1] != 1)) {
    if (ppbVar13 != (byte **)0x0) {
      ppbVar13[0xb1] = *ppbStack_560;
    }
    lVar15 = func_0x();
    if ((lVar15 != 0) && (lVar15 = func_0x(), *(longlong *)(lVar15 + 0x30) != 0)) {
      lVar15 = func_0x();
      uVar33 = *(uint *)(*(longlong *)(lVar15 + 0x30) + 0xc);
      if ((uVar33 < 0xe) && ((0x2640U >> (uVar33 & 0x1f) & 1) != 0)) goto LAB_;
    }
    func_0x(0,uVar34 & 0xffffffff);
  }
LAB_:
  pbVar32 = *ppbStack_560;
  if ((pbVar32[1] != 1) ||
     (sVar30 = *(short *)((longlong)piVar35 + 6),
     (int)(*(ushort *)(pbVar32 + 0x16) - 1) < (int)sVar30)) {
    cVar7 = func_0x();
    if ((cVar7 != '\0') && (DAT_ == '\0')) {
      (*_DAT_)(0xdc,0x11,0x11,2);
    }
    puVar23 = puStack_4a8;
    if (((*(short *)(puStack_478 + 2) == 0) && (*puStack_478 == 0)) && (puStack_478[1] == 0)) {
      uStack_588 = (uint *)0x10fc670;
      (*_DAT_)(1,0x10b8ed8,0x10b5238,0x13fb);
      sVar30 = *(short *)((longlong)piVar35 + 6);
      goto LAB_;
    }
    if (puStack_4a8 == (undefined *)0x0) {
      uStack_588 = (uint *)0x0;
      (*_DAT_)(1,0x10fc680,0x10b5238,0x13f5);
    }
    goto LAB_;
  }
LAB_:
  iStack_134 = (int)sVar30;
  ppbVar13 = ppbVar29;
  if ((char)pbVar32[2] < '\0') {
    pbVar1 = pbVar32 + 0x60;
    if ((sStack_168 == 0) || (ppbVar13 = uStack_158, uStack_158 == (byte **)0x0)) {
      uStack_108 = 0;
      uStack_fa = 0;
      auStack_e0 = ZEXT816(0);
      auStack_130 = ZEXT816(0);
      stack0xfffffffffffffee2 = SUB1614(ZEXT816(0),2);
      auStack_120._0_2_ = 0xffff;
      uStack_118 = 0;
      uStack_102 = 0;
      uStack_100 = 0;
      uStack_f8 = 0;
      uStack_110 = 0;
      auStack_f0 = ZEXT816(0);
      auStack_d0._0_12_ = ZEXT812(0);
      auStack_d0._12_4_ = 0;
      uStack_c0 = 0;
      ppbVar13 = (byte **)auStack_130;
    }
    if (*(short *)(pbVar32 + 0x24) == 0) {
LAB_:
      uStack_4c0 = *(undefined8 *)(pbVar32 + 0x28);
      uStack_4b8 = *(undefined2 *)(pbVar32 + 0x30);
    }
    else {
      bVar3 = pbVar32[1];
      if (bVar3 == 0xb) {
        if (*(int *)(pbVar32 + 0x18) != 99) {
LAB_:
          if (bVar3 != 9) goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (bVar3 != 8) goto LAB_;
LAB_:
        if (*(int *)(pbVar32 + 0x18) != 99) goto LAB_;
      }
      uStack_538 = *(undefined4 *)(pbVar32 + 0x20);
      uStack_534 = *(undefined2 *)(pbVar32 + 0x24);
      cVar7 = func_0x(&uStack_538,0xcaafd8,0xcaafd8);
      if (cVar7 == '\0') goto LAB_;
      func_0x(pbVar32,&uStack_4c0);
    }
    *ppbVar13 = pbVar1;
    *(undefined4 *)(ppbVar13 + 0xc) = (undefined4)uStack_4c0;
    *(int *)((longlong)ppbVar13 + 100) = (int)((ulonglong)uStack_4c0 >> 0x20);
    *(undefined2 *)(ppbVar13 + 0xd) = uStack_4b8;
    *(undefined4 *)((longlong)ppbVar13 + 0x6c) = *(undefined4 *)(pbVar32 + 0x20);
    *(undefined2 *)(ppbVar13 + 0xe) = *(undefined2 *)(pbVar32 + 0x24);
    *(undefined2 *)((longlong)ppbVar13 + 0x72) = 0;
    uStack_538 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0xd2b5e0);
    uVar34 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0xd2b5e4);
    *(undefined2 *)(ppbVar13 + 2) = 0xffff;
    ppbVar13[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
    ppbVar13[7] = (byte *)0x0;
    ppbVar13[4] = (byte *)0x0;
    ppbVar13[9] = (byte *)0x0;
    ppbVar13[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar13 + 0xb) = 0;
    if ((**ppbVar13 & 2) != 0) {
      pbVar2 = pbVar1 + uVar34;
      if ((*pbVar2 & 1) == 0) {
        *(undefined2 *)(ppbVar13 + 2) = 0;
        ppbVar13[3] = pbVar2;
        *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar13 + 0x36) = 0;
        uVar33 = uVar27;
        switch(*pbVar2 & 0xe) {
        default:
          uVar33 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar33 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar33 = 1;
        }
        *(uint *)(ppbVar13 + 4) = uVar33;
        *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar13 + 2) = 1;
        ppbVar13[3] = pbVar2;
        bVar3 = *pbVar2;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar8 = *(ushort *)(pbVar2 + 1);
            *(ushort *)((longlong)ppbVar13 + 0x12) = uVar8;
            sVar21 = 3;
            uVar8 = (uVar8 & 0x7f) << 8 | uVar8 >> 8;
          }
          else {
            sVar21 = 2;
            uVar8 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar13 + 0x12) = uVar8;
          *(short *)(ppbVar13 + 5) = sVar21;
          uVar8 = *(ushort *)((longlong)ppbVar13 + 0x12);
          *(short *)((longlong)ppbVar13 + 0x2c) = (short)(uVar8 + 1 >> 1) + sVar21;
          if (uVar8 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar13 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
            *(undefined4 *)(ppbVar13 + 8) = 0;
            ppbVar13[7] = (byte *)0x0;
            ppbVar13[4] = (byte *)0x0;
          }
          else {
            iVar10 = uVar8 - 1;
            *(short *)((longlong)ppbVar13 + 0x2a) =
                 ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                 (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
            *(undefined4 *)(ppbVar13 + 8) = 0;
            ppbVar13[7] = (byte *)0x0;
            ppbVar13[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) != 4) || (uVar33 = 1, (bVar3 & 2) == 0)) {
            uVar33 = uVar27;
          }
          if (uVar33 == 0) {
            uVar19 = 1;
          }
          else {
            *(undefined4 *)(ppbVar13 + 8) = 0;
            uVar19 = 0xf;
          }
          ppbVar13[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar13 + 0x12) = 0;
          ppbVar13[6] = (byte *)0x0;
          ppbVar13[4] = (byte *)0x0;
          ppbVar13[7] = (byte *)0x0;
          ppbVar13[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar13 + 0x14) = uVar19;
          *(uint *)(ppbVar13 + 8) = (uint)(uVar33 != 0);
          ppbVar13[7] = (byte *)0x0;
          ppbVar13[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar13[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar13 + 0x12) = 0;
          ppbVar13[6] = (byte *)0x0;
          ppbVar13[4] = (byte *)0x0;
          ppbVar13[7] = (byte *)0x0;
          ppbVar13[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar13 + 0x14) = 9;
          *(undefined4 *)(ppbVar13 + 8) = 0;
          ppbVar13[7] = (byte *)0x0;
          ppbVar13[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar13 & 4) != 0) {
      if (uStack_538._2_2_ != 0) {
        uVar34 = (ulonglong)*(ushort *)(pbVar32 + (longlong)uStack_538._2_2_ * 2 + 0x61);
      }
      psVar16 = (short *)(pbVar1 + uVar34);
      ppbVar13[9] = (byte *)psVar16;
      sVar21 = *psVar16;
      ppbVar13[10] = (byte *)(psVar16 + 1);
      *(short *)(ppbVar13 + 0xb) = (sVar21 + 1) * 2;
    }
    if (ppbVar13[1] != (byte *)0x0) {
      func_0x(ppbVar13[1],ppbVar13);
    }
  }
  uVar33 = 1;
  ppbStack_160 = (byte **)(pbVar32 + *(ushort *)(pbVar32 + (0xfff - (longlong)sVar30) * 2));
  if ((*(byte *)ppbStack_160 & 1) == 0) {
    sStack_168 = 0;
    uStack_164 = 0;
    uStack_142 = 0;
    uStack_140 = 0;
    uVar11 = (uint)*(ushort *)(pbVar32 + 0xe);
    switch(*(byte *)ppbStack_160 & 0xe) {
    default:
      uVar11 = (uint)*(ushort *)((longlong)ppbStack_160 + 2);
      if (0x1f9d < *(ushort *)((longlong)ppbStack_160 + 2) - 1) {
        func_0x(ppbStack_160,6);
      }
      break;
    case 4:
      uVar11 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar11 = uVar33;
    }
    uStack_158 = (byte **)CONCAT44(uStack_158._4_4_,uVar11);
    uStack_14a = SUB82(pbVar32 + 0x2000,0);
    uStack_148 = (undefined6)((ulonglong)(pbVar32 + 0x2000) >> 0x10);
  }
  else {
    sStack_168 = 1;
    bVar3 = *(byte *)ppbStack_160;
    switch(bVar3 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)ppbStack_160 + 1) < '\0') {
        uStack_166 = (*(ushort *)((longlong)ppbStack_160 + 1) & 0x7f) << 8 |
                     *(ushort *)((longlong)ppbStack_160 + 1) >> 8;
        uStack_150._0_2_ = 3;
        uStack_520 = CONCAT22(uStack_520._2_2_,3);
      }
      else {
        uStack_166 = (ushort)*(byte *)((longlong)ppbStack_160 + 1);
        uStack_150._0_2_ = 2;
      }
      uStack_14c = (short)(uStack_166 + 1 >> 1) + (short)uStack_520;
      if (uStack_166 < 0x1f) {
        uStack_150._2_2_ = 0;
        uStack_164 = 0;
        uStack_138 = 0;
      }
      else {
        iVar10 = uStack_166 - 1;
        uStack_150._2_2_ =
             ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
             (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
        uStack_164 = 0;
        uStack_138 = 0;
      }
      break;
    case 4:
      if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
        uStack_150._0_2_ = 0;
        uStack_150._2_2_ = 0;
        uStack_14c = 0;
        uStack_14a = 0;
        uStack_166 = 0;
        uStack_148 = 0;
        uStack_142 = 0;
        uStack_164 = 0xf;
        uStack_138 = 1;
      }
      else {
        uStack_150._0_2_ = 0;
        uStack_150._2_2_ = 0;
        uStack_14c = 0;
        uStack_14a = 0;
        uStack_166 = 0;
        uStack_148 = 0;
        uStack_142 = 0;
        uStack_164 = 1;
        uStack_138 = 0;
      }
      break;
    case 8:
      uStack_150._0_2_ = 0;
      uStack_150._2_2_ = 0;
      uStack_14c = 0;
      uStack_14a = 0;
      uStack_166 = 0;
      uStack_148 = 0;
      uStack_142 = 0;
      uStack_164 = 9;
      uStack_138 = 0;
    }
    pbVar32 = pbVar32 + 0x2000;
    uStack_140 = SUB82(pbVar32,0);
    uStack_13e = (undefined2)((ulonglong)pbVar32 >> 0x10);
    uStack_13c = (ushort)((ulonglong)pbVar32 >> 0x20);
    uStack_13a = (undefined2)((ulonglong)pbVar32 >> 0x30);
    uStack_158 = ppbVar13;
  }
  ppbVar13 = ppbStack_160;
  puVar26 = puStack_4b0;
  func_0x(puStack_4b0 + 2,0x28,(longlong)ppbStack_160 + 4);
  puVar18 = puVar26 + 7;
  if (puVar18 == (ulonglong *)0x0) {
code_r0x00101438:
    puVar17 = (undefined4 *)(*pcRam0000000000bacc90)();
    *puVar17 = 0x16;
    (*pcRam0000000000bacca8)();
  }
  else {
    if ((undefined2 *)((longlong)ppbVar13 + 0x2c) == (undefined2 *)0x0) {
      *(undefined2 *)puVar18 = 0;
      goto code_r0x00101438;
    }
    *(undefined2 *)puVar18 = *(undefined2 *)((longlong)ppbVar13 + 0x2c);
  }
  puVar18 = puVar26 + 8;
  if (puVar18 == (ulonglong *)0x0) {
code_r0x00101469:
    puVar17 = (undefined4 *)(*pcRam0000000000bacc90)();
    *puVar17 = 0x16;
    (*pcRam0000000000bacca8)();
  }
  else {
    if ((ulonglong *)((longlong)ppbVar13 + 0x2e) == (ulonglong *)0x0) {
      *puVar18 = 0;
      goto code_r0x00101469;
    }
    *puVar18 = *(ulonglong *)((longlong)ppbVar13 + 0x2e);
  }
  puVar18 = puVar26 + 9;
  if (puVar18 == (ulonglong *)0x0) {
code_r0x00101498:
    puVar17 = (undefined4 *)(*pcRam0000000000bacc90)();
    *puVar17 = 0x16;
    (*pcRam0000000000bacca8)();
  }
  else {
    if ((ulonglong *)((longlong)ppbVar13 + 0x36) == (ulonglong *)0x0) {
      *puVar18 = 0;
      goto code_r0x00101498;
    }
    *puVar18 = *(ulonglong *)((longlong)ppbVar13 + 0x36);
  }
  lVar15 = lStack_470;
  if (lStack_470 == 0) goto code_r0x00101f39;
  uStack_588 = (uint *)((ulonglong)uStack_588 & 0xffffffff00000000);
  func_0x(&uStack_548,0xffffffff,1);
  if (sStack_168 == 0) {
    if ((uStack_548 & 0xc0000000) == 0x80000000) {
      iVar10 = func_0x(&uStack_166);
      uVar11 = CONCAT22(uStack_150._2_2_,(undefined2)uStack_150);
      if (iVar10 != 0) {
        ppbVar28 = (byte **)func_0x(&uStack_13e,&uStack_548,auStack_568,auStack_480);
        goto code_r0x00101ee9;
      }
      auStack_568[0] = 0;
    }
    else {
      bVar3 = *(byte *)ppbStack_160;
      uVar34 = (ulonglong)uStack_158 & 0xffffffff;
      puVar26 = puStack_4b0;
      uVar11 = uStack_150;
      if ((bVar3 & 0x10) == 0) {
        if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
          uVar8 = ~(uStack_542 >> 4);
          uVar33 = uVar27;
          goto code_r0x0010157c;
        }
code_r0x001015b6:
        if ((int)uStack_548 < 0) {
          ppbVar28 = ppbStack_160;
          uVar33 = (uint)uStack_158;
          if (uStack_164 == 0) {
            uStack_166 = 0;
            uVar11 = (uint)uStack_158;
            if ((*(byte *)ppbStack_160 & 0x10) != 0) {
              uVar11 = (uint)uStack_158 + 2 +
                       (*(ushort *)(uVar34 + (longlong)ppbStack_160) + 7 >> 3);
              uVar34 = (ulonglong)uVar11;
            }
            uStack_158 = (byte **)CONCAT44(uVar11,(uint)uStack_158);
            uVar11 = (uint)uVar34;
            if ((*(byte *)ppbStack_160 & 0x20) == 0) {
              uStack_14c = 0;
              uVar31 = uVar34;
              uStack_164 = uVar11;
            }
            else {
              puVar25 = (ushort *)(uVar34 + (longlong)ppbStack_160);
              uStack_14c = *puVar25;
              if (uStack_14c == 0) {
                if ((((cRam000000000163e0cb != '\0') || ((bRam000000000164e9d0 & 1) != 0)) &&
                    (lVar12 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0)) &&
                   ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                    (*(char *)(lVar12 + 0x499) != '\0')))) {
                  if ((cRam000000000163dfbb == '\0') && ((bRam000000000164e9d0 & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_588 = (uint *)0x0;
                    (*_DAT_)(1,0xf2eaf8,0x104e7c8,0x80f);
                  }
                }
                func_0x(ppbStack_160,3);
              }
              uStack_150 = uStack_158._4_4_ + (uStack_14c + 1) * 2;
              if (0x1f9e < uStack_150) {
                if (((cRam000000000163e0cb != '\0') || ((bRam000000000164e9d0 & 1) != 0)) &&
                   ((lVar12 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0 &&
                    ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                     (*(char *)(lVar12 + 0x499) != '\0')))))) {
                  if ((cRam000000000163dfbb == '\0') && ((bRam000000000164e9d0 & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_588 = (uint *)0x0;
                    (*_DAT_)(1,0xf2eaf8,0x104e7c8,0x816);
                  }
                }
                func_0x(ppbStack_160,4);
              }
              uStack_164 = puVar25[uStack_14c] & 0x7fff;
              if (uStack_164 < uStack_150) {
                if ((((cRam000000000163e0cb != '\0') || ((bRam000000000164e9d0 & 1) != 0)) &&
                    (lVar12 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar12 != 0)) &&
                   ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                    (*(char *)(lVar12 + 0x499) != '\0')))) {
                  if ((cRam000000000163dfbb == '\0') && ((bRam000000000164e9d0 & 2) == 0)) {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_588 = (uint *)0x0;
                    (*_DAT_)(1,0xf2eaf8,0x104e7c8,0x81d);
                  }
                }
                func_0x(ppbStack_160,4);
              }
              uVar31 = (ulonglong)uStack_164;
              uVar34 = (ulonglong)uStack_150;
              ppbVar28 = ppbStack_160;
              uVar11 = uStack_150;
              do {
                if (-1 < (short)puVar25[(ulonglong)(uStack_14c - 1) + 1]) break;
                uVar33 = (uint)uVar34;
                if (uStack_14c != 1) {
                  uVar33 = *(ushort *)
                            ((longlong)ppbVar28 +
                            (ulonglong)uStack_14c * 2 + (((ulonglong)uStack_158 >> 0x20) - 2)) &
                           0x7fff;
                }
                if ((uVar33 < (uint)uVar34) ||
                   ((*(ushort *)
                      ((longlong)ppbVar28 +
                      (ulonglong)uStack_14c * 2 + ((ulonglong)uStack_158 >> 0x20)) & 0x7fff) <
                    uVar33)) {
                  uStack_150 = uVar11;
                  func_0x(ppbVar28,7);
                  uVar34 = (ulonglong)uStack_150;
                  uVar31 = (ulonglong)uStack_164;
                  ppbVar28 = ppbStack_160;
                  uVar11 = uStack_150;
                }
                uStack_150 = (uint)uVar34;
                if ((uVar33 < uStack_150) || ((uint)uVar31 < uVar33)) {
                  uVar33 = (uint)uStack_158;
                  goto code_r0x00101d2c;
                }
                if (*(ushort *)((longlong)ppbVar28 + (ulonglong)uVar33) == 5) {
                  uStack_166 = uStack_166 | 2;
                  uStack_14c = uStack_14c - 1;
                  uStack_13e = (undefined2)uVar33;
                  uVar8 = *(ushort *)((ulonglong)(uVar33 & 0xffff) + 2 + (longlong)ppbVar28);
                  if ((uVar8 >> 0xe & 1) == 0) {
                    uStack_13c = uStack_13c & 0xc7ff;
                  }
                  else {
                    uStack_13c = uStack_13c ^ (uStack_13c ^ uVar8) & 0x3800;
                  }
                  uStack_13c = (uStack_13c ^
                               *(ushort *)((ulonglong)(uVar33 & 0xffff) + 2 + (longlong)ppbVar28)) &
                               0x7ff ^ uStack_13c;
                  break;
                }
                if (*(ushort *)((longlong)ppbVar28 + (ulonglong)uVar33) < 0x400) break;
                uStack_166 = uStack_166 | 1;
                uStack_14c = uStack_14c - 1;
              } while (uStack_14c != 0);
              uVar33 = (uint)uStack_158;
            }
            uStack_150 = (uint)uVar34;
            if ((*(byte *)ppbVar28 & 0x40) == 0) {
              uStack_142 = 0;
              uStack_140 = 0;
            }
            else {
              uStack_142 = (undefined2)uVar31;
              uStack_140 = (undefined2)(uVar31 >> 0x10);
              uStack_164 = (int)uVar31 + 0xe;
              uStack_150 = uVar11;
              puVar18 = (ulonglong *)func_0x(&uStack_166);
              uVar22 = (ushort)(*puVar18 >> 0x30);
              uVar8 = uVar22;
              if ((((uint)(int)(short)uVar22 >> 1 ^ (int)(short)uVar22) & 0x2000) != 0) {
                uVar8 = uVar22 & 0xdfff;
                if ((uVar22 >> 0xe & 1) != 0) {
                  uVar8 = uVar22 | 0x2000;
                }
              }
              if (uVar8 == 0xfffc) {
                uVar27 = (uint)((*puVar18 >> 0x20 & 0xffff) >> 5);
              }
              uStack_164 = uStack_164 + uVar27;
              uVar31 = (ulonglong)uStack_164;
              ppbVar28 = ppbStack_160;
              uVar33 = (uint)uStack_158;
              uVar11 = uStack_150;
            }
            uVar27 = (uint)uVar31;
            if ((CONCAT62(uStack_148,uStack_14a) != 0) &&
               (CONCAT62(uStack_148,uStack_14a) < uVar31 + (longlong)ppbVar28)) {
              uStack_150 = uVar11;
              if (((cRam000000000163e0cb != '\0') || ((bRam000000000164e9d0 & 1) != 0)) &&
                 (((lVar12 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), ppbVar28 = ppbStack_160,
                   lVar12 != 0 && (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
                  (*(char *)(lVar12 + 0x499) != '\0')))) {
                if ((cRam000000000163dfbb == '\0') && ((bRam000000000164e9d0 & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  ppbVar28 = ppbStack_160;
                }
                else {
                  uStack_588 = (uint *)0x0;
                  (*_DAT_)(1,0xf2eaf8,0x104e7c8,0x877);
                  ppbVar28 = ppbStack_160;
                }
              }
              func_0x(ppbVar28,0x12);
              ppbVar28 = ppbStack_160;
              uVar27 = uStack_164;
              uVar33 = (uint)uStack_158;
              uVar11 = uStack_150;
            }
            if (0x3f3b < uVar27 - 1) {
              uStack_150 = uVar11;
              if (((cRam000000000163e0cb != '\0') || ((bRam000000000164e9d0 & 1) != 0)) &&
                 ((lVar12 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), ppbVar28 = ppbStack_160,
                  lVar12 != 0 &&
                  ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
                   (*(char *)(lVar12 + 0x499) != '\0')))))) {
                if ((cRam000000000163dfbb == '\0') && ((bRam000000000164e9d0 & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  ppbVar28 = ppbStack_160;
                }
                else {
                  uStack_588 = (uint *)0x0;
                  (*_DAT_)(1,0xf2eaf8,0x104e7c8,0x87c);
                  ppbVar28 = ppbStack_160;
                }
              }
              func_0x(ppbVar28,5);
              ppbVar28 = ppbStack_160;
              uVar33 = (uint)uStack_158;
              uVar11 = uStack_150;
            }
          }
code_r0x00101d2c:
          sVar30 = -(short)uStack_548;
          if ((uStack_542 & 0x10) == 0) {
code_r0x00101d51:
            if ((uint)uStack_14c < (uint)(int)sVar30) {
              auStack_568[0] = 0;
              puVar26 = puStack_4b0;
            }
            else {
              ppbVar29 = ppbVar28;
              uVar27 = uStack_150;
              if (sVar30 != 1) {
                ppbVar29 = ppbStack_160;
                uStack_150 = uVar11;
                uVar27 = *(ushort *)
                          ((longlong)ppbVar28 +
                          (longlong)sVar30 * 2 + (((ulonglong)uStack_158 >> 0x20) - 2)) & 0x7fff;
              }
              uVar33 = *(ushort *)
                        ((longlong)ppbVar28 + (longlong)sVar30 * 2 + ((ulonglong)uStack_158 >> 0x20)
                        ) & 0x7fff;
              if ((uVar27 < uStack_150) || (uVar33 < uVar27)) {
                uStack_150 = uVar11;
                func_0x(ppbVar29,7);
                ppbVar29 = ppbStack_160;
                uVar11 = uStack_150;
              }
              ppbVar28 = (byte **)((ulonglong)uVar27 + (longlong)ppbVar29);
              auStack_568[0] = uVar33 - uVar27;
              puVar26 = puStack_4b0;
            }
          }
          else {
            if ((*(byte *)ppbVar28 & 0x10) == 0) {
              if ((1 << (*(byte *)ppbVar28 & 0xe) & 0x1105U) == 0) goto code_r0x00101d51;
            }
            else if (((int)uStack_548 < (int)uVar33) &&
                    (uStack_544 <= *(ushort *)((ulonglong)uVar33 + (longlong)ppbVar28)))
            goto code_r0x00101d51;
code_r0x00101d8c:
            ppbVar28 = (byte **)(puStack_540 + 1);
            auStack_568[0] = *puStack_540;
            puVar26 = puStack_4b0;
          }
        }
        else if ((uStack_542 & 8) == 0) {
          if ((uStack_542 & 0x10) != 0) {
            if ((bVar3 & 0x10) == 0) {
              if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
                ppbVar28 = (byte **)(puStack_540 + 1);
                auStack_568[0] = *puStack_540;
                goto code_r0x00101eec;
              }
            }
            else {
              uVar11 = CONCAT22(uStack_150._2_2_,(undefined2)uStack_150);
              if (((int)(uint)uStack_158 <= (int)uStack_548) ||
                 (uVar11 = uStack_150, *(ushort *)(uVar34 + (longlong)ppbStack_160) < uStack_544))
              goto code_r0x00101d8c;
            }
          }
          ppbVar28 = (byte **)((longlong)ppbStack_160 + (longlong)(int)uStack_548);
          auStack_568[0] = 0;
          uVar11 = uStack_150;
        }
        else {
          ppbVar28 = (byte **)0xcb3534;
          if ((*(byte *)((longlong)(int)uStack_548 + (longlong)ppbStack_160) &
              (byte)(1 << ((byte)uStack_542 & 7))) == 0) {
            ppbVar28 = (byte **)0xcb3b58;
          }
          auStack_568[0] = 1;
        }
      }
      else {
        if ((int)uStack_548 < (int)(uint)uStack_158) {
          if ((uint)*(ushort *)(uVar34 + (longlong)ppbStack_160) < (uint)uStack_544) {
            uVar8 = ~(uStack_542 >> 4);
            uVar33 = uVar27;
          }
          else {
            uVar20 = uStack_544 - 1;
            uVar8 = (ushort)(*(byte *)((longlong)ppbStack_160 +
                                      uVar34 + (ulonglong)(uVar20 >> 3) + 2) >> ((byte)uVar20 & 7));
          }
        }
        else {
          uVar8 = ~(uStack_542 >> 4);
          uVar33 = uVar27;
        }
code_r0x0010157c:
        if ((uVar8 & 1) == 0) {
          if ((uVar33 != 0) || ((uStack_542 & 0x10) == 0)) goto code_r0x001015b6;
          ppbVar28 = (byte **)(puStack_540 + 1);
          auStack_568[0] = *puStack_540;
        }
        else {
          auStack_568[0] = 0;
          ppbVar28 = ppbVar29;
        }
      }
    }
  }
  else {
    uStack_51c = 0;
    uStack_588 = &uStack_51c;
    ppbVar28 = (byte **)func_0x(&uStack_166,&uStack_548);
    if ((((sStack_168 != 0) && (uStack_158 != (byte **)0x0)) && (*uStack_158 != (byte *)0x0)) &&
       (((uStack_542 & 8) == 0 && ((uStack_51c & 1) == 0)))) {
      if ((ppbVar28 == (byte **)0x0) || (ppbVar28 == (byte **)0xcb3534)) {
        auStack_568[0] = 0;
        ppbVar28 = ppbVar29;
      }
      else {
        uStack_570 = CONCAT44(uStack_570._4_4_,uStack_51c);
        puStack_578 = auStack_568;
        uStack_580 = (uint *)((ulonglong)uStack_580 & 0xffffffff00000000);
        uStack_588 = (uint *)0x0;
        ppbVar28 = (byte **)func_0x(uStack_158,&uStack_548,ppbVar28,auStack_568[0]);
      }
    }
code_r0x00101ee9:
    uVar11 = CONCAT22(uStack_150._2_2_,(undefined2)uStack_150);
  }
code_r0x00101eec:
  uStack_150 = uVar11;
  func_0x(lVar15,param_5,ppbVar28,auStack_568[0]);
  *puVar26 = (ulonglong)auStack_568[0];
  goto code_r0x00101f39;
}

