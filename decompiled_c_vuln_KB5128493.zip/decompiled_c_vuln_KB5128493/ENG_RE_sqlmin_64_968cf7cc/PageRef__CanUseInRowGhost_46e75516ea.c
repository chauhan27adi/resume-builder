// NOTE: 2 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 param_1,undefined8 param_2,longlong *param_3)

{
  char cVar1;
  
  cVar1 = (**(code **)(*param_3 + 0x20))(param_3);
  if (cVar1 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

