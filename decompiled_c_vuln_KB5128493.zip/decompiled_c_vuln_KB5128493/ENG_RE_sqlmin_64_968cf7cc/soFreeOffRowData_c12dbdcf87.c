
/* WARNING: Heritage AFTER dead removal. Example location: s0xffffffffffffff48 : 0x0010025b */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_(longlong param_1,longlong *param_2)

{
  byte *pbVar1;
  ushort uVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong lVar5;
  char cVar6;
  longlong lVar7;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar8;
  undefined auStack_1b8 [72];
  undefined4 uStack_170;
  undefined2 uStack_16c;
  ushort uStack_16a;
  undefined8 uStack_168;
  uint uStack_160;
  undefined8 uStack_150;
  undefined2 uStack_148;
  undefined4 uStack_140;
  undefined2 uStack_13c;
  undefined8 uStack_138;
  longlong lStack_130;
  longlong lStack_128;
  undefined4 uStack_118;
  longlong *plStack_108;
  undefined2 uStack_f0;
  undefined4 uStack_ec;
  byte *pbStack_e8;
  undefined8 uStack_e0;
  undefined8 uStack_d2;
  undefined2 uStack_ca;
  undefined2 uStack_c8;
  undefined6 uStack_c6;
  uint uStack_bc;
  undefined auStack_b8 [16];
  undefined auStack_a8 [8];
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined6 uStack_88;
  undefined2 uStack_82;
  undefined8 uStack_80;
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  undefined8 uStack_48;
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_1b8;
  plStack_108 = *(longlong **)(param_1 + 0x60);
  lVar4 = *param_2;
  uStack_138 = *(undefined8 *)(*plStack_108 + 0x58);
  uStack_16a = uStack_16a & 0xffe0;
  uStack_f0 = 0xffff;
  pbStack_e8 = (byte *)0x0;
  uStack_ec = 0;
  uStack_d2 = 0;
  uStack_c8 = 0;
  uStack_c6 = 0;
  uStack_e0 = 0;
  uStack_bc = 0xffffffff;
  uStack_170 = 0;
  uStack_16c = 0;
  uStack_168 = 0;
  uVar2 = *(ushort *)(lVar4 + 0x16);
  uStack_160 = (uVar2 != 0) - 1;
  lStack_130 = lVar4;
  if ((int)uStack_160 < (int)(uint)uVar2) {
    lStack_128 = (longlong)(int)uStack_160;
    do {
      if ((uStack_160 < uVar2) && (lVar7 = 0xfff - lStack_128, *(short *)(lVar4 + lVar7 * 2) != 0))
      {
        uStack_bc = uStack_160;
        if (-1 < *(char *)(lVar4 + 2)) goto LAB_;
        pbVar1 = (byte *)(lVar4 + 0x60);
        uStack_90 = 0;
        stack0xffffffffffffff5a = SUB1614(ZEXT816(0),2);
        auStack_a8._0_2_ = 0xffff;
        uStack_82 = SUB162(ZEXT816(0),6);
        uStack_a0 = 0;
        uStack_8a = 0;
        uStack_88 = 0;
        uStack_98 = 0;
        auStack_78 = ZEXT816(0);
        auStack_58._0_12_ = ZEXT812(0);
        auStack_58._12_4_ = 0;
        uStack_48 = 0;
        auStack_68 = ZEXT816(0);
        auStack_b8 = ZEXT816(0);
        uStack_48 = 0;
        uStack_80 = 0;
        uStack_82 = 0;
        uStack_88 = 0;
        uStack_8a = 0;
        uStack_90 = 0;
        uStack_98 = 0;
        if (*(short *)(lVar4 + 0x24) == 0) {
LAB_:
          uStack_150 = *(undefined8 *)(lVar4 + 0x28);
          uStack_148 = *(undefined2 *)(lVar4 + 0x30);
        }
        else {
          cVar6 = *(char *)(lVar4 + 1);
          if (cVar6 == '\v') {
            if (*(int *)(lVar4 + 0x18) != 99) {
LAB_:
              if (cVar6 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar6 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar4 + 0x18) != 99) goto LAB_;
          }
          uStack_140 = *(undefined4 *)(lVar4 + 0x20);
          uStack_13c = *(undefined2 *)(lVar4 + 0x24);
          cVar6 = func_0x(&uStack_140);
          if (cVar6 == '\0') goto LAB_;
          func_0x(lVar4,&uStack_150);
        }
        lVar5 = auStack_b8._8_8_;
                    /* WARNING: Ignoring partial resolution of indirect */
        auStack_b8._0_8_ = pbVar1;
                    /* WARNING: Ignoring partial resolution of indirect */
        auStack_58._0_4_ = (undefined4)uStack_150;
                    /* WARNING: Ignoring partial resolution of indirect */
        uStack_48._0_2_ = *(undefined2 *)(lVar4 + 0x24);
        uVar3 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x106cf80);
        uVar8 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x106cf84);
                    /* WARNING: Ignoring partial resolution of indirect */
        auStack_a8._0_2_ = 0xffff;
        uStack_88 = 0;
        uStack_8a = 0;
        uStack_98 = 0;
                    /* WARNING: Ignoring partial resolution of indirect */
        auStack_68._0_8_ = 0;
        uStack_118 = uVar3;
        if ((*pbVar1 & 2) != 0) {
          if ((pbVar1[uVar8] & 1) == 0) {
                    /* WARNING: Ignoring partial resolution of indirect */
            auStack_a8._0_2_ = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100427 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(pbVar1[uVar8] & 0xe) * 4 + 0x1019a4) -
                      0x14cceb0))();
            return;
          }
                    /* WARNING: Ignoring partial resolution of indirect */
          auStack_a8._0_2_ = 1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)
                                  *(byte *)((longlong)(int)(pbVar1[uVar8] & 0x1c) + 0x101984) * 4 +
                                 0x101974) - 0x14cceb0);
                    /* WARNING: Could not emulate address calculation at 0x00100291 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if ((*pbVar1 & 4) != 0) {
          uStack_118._2_2_ = (short)((uint)uVar3 >> 0x10);
          if (uStack_118._2_2_ != 0) {
            uVar8 = (ulonglong)*(ushort *)(lVar4 + 0x61 + (longlong)uStack_118._2_2_ * 2);
          }
                    /* WARNING: Ignoring partial resolution of indirect */
          auStack_68._0_8_ = pbVar1 + uVar8 + 2;
        }
        if (lVar5 != 0) {
          func_0x(lVar5,auStack_b8);
        }
LAB_:
        pbStack_e8 = (byte *)((ulonglong)*(ushort *)(lVar4 + lVar7 * 2) + lStack_130);
        if ((*pbStack_e8 & 1) == 0) {
          uStack_f0 = 0;
          uStack_ec = 0;
          uStack_ca = 0;
          uStack_c8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100677 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_e8 & 0xe) * 4 + 0x101a10) -
                    0x14cceb0))();
          return;
        }
        uStack_f0 = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_e8 & 0x1c) + 0x1019f0)
                                * 4 + 0x1019e0) - 0x14cceb0);
                    /* WARNING: Could not emulate address calculation at 0x0010052b */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      lStack_128 = lStack_128 + 1;
      uVar2 = *(ushort *)(lVar4 + 0x16);
      uStack_160 = uStack_160 + 1;
    } while ((int)uStack_160 < (int)(uint)uVar2);
  }
  func_0x(_DAT_ ^ (ulonglong)auStack_1b8 ^ (ulonglong)auStack_1b8);
  return;
}

