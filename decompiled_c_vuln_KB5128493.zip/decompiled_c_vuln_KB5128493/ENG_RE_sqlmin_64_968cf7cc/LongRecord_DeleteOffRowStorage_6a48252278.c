
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,uint *param_3)

{
  uint *puVar1;
  longlong *plVar2;
  undefined8 uVar3;
  code *pcVar4;
  ushort uVar5;
  int iVar6;
  uint uVar7;
  longlong lVar8;
  longlong lVar9;
  ulonglong *puVar10;
  longlong lVar11;
  byte bVar12;
  ulonglong uVar13;
  ushort uVar14;
  short sVar15;
  short *psVar16;
  undefined8 unaff_RBX;
  undefined *puVar17;
  ulonglong uVar18;
  ushort *puVar19;
  undefined4 uVar20;
  uint *puVar22;
  byte *pbVar23;
  uint uVar24;
  longlong unaff_GS_OFFSET;
  uint uStackX_8;
  uint uStackX_c;
  undefined auStackX_10 [8];
  undefined4 auStackX_18 [4];
  undefined8 uStack_40;
  uint *puVar21;
  
  uStack_40 = 0x100016;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  puVar17 = &stack0xffffffffffffffc8 + lVar8;
  puVar1 = (uint *)((longlong)&uStackX_8 + lVar8);
  *(undefined8 *)(&stack0x00000030 + lVar8) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002730 + lVar8) = unaff_RBX;
  *(ulonglong *)(&stack0x000026c8 + lVar8) = _DAT_ ^ (ulonglong)puVar1;
  lVar11 = 0;
  uVar20 = 0;
  puVar21 = (uint *)0x0;
  lVar9 = *(longlong *)(*(longlong *)(param_1 + 0x58) + 8);
  psVar16 = param_2;
  puVar22 = param_3;
  if (*(int *)(lVar9 + 0x100) == 2) {
    if ((*(byte *)(lVar9 + 0x42) & 4) == 0) {
      uVar18 = (ulonglong)*(uint *)(lVar9 + 0xb0);
      if (0x1f9e < *(uint *)(lVar9 + 0xb0)) {
        uVar18 = 0x1f9e;
      }
    }
    else {
      uVar18 = 0x1f9e;
    }
    uVar20 = (undefined4)uVar18;
    uVar13 = uVar18 + 0xf;
    if (uVar13 <= uVar18) {
      uVar13 = 0xffffffffffffff0;
    }
    uVar13 = uVar13 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10009e;
    func_0x();
    puVar17 = &stack0xffffffffffffffc8 + -uVar13 + lVar8;
    lVar11 = (longlong)&uStackX_8 + -uVar13 + lVar8;
  }
  if (*psVar16 != 0) {
    *(undefined4 *)((longlong)&uStackX_c + lVar8) = 0;
    *(longlong *)(puVar17 + 0x20) = (longlong)&uStackX_c + lVar8;
    *(undefined8 *)(puVar17 + -8) = 0x100940;
    puVar21 = (uint *)func_0x(param_2 + 1,param_3);
    if ((((*param_2 != 0) && (plVar2 = *(longlong **)(param_2 + 8), plVar2 != (longlong *)0x0)) &&
        (*plVar2 != 0)) &&
       (((*(byte *)((longlong)param_3 + 6) & 8) == 0 &&
        ((*(uint *)((longlong)&uStackX_c + lVar8) & 1) == 0)))) {
      if ((puVar21 == (uint *)0x0) || (puVar21 == (uint *)0x81fb44)) {
        puVar21 = (uint *)0x0;
        *puVar1 = 0;
      }
      else {
        *(uint *)(puVar17 + 0x38) = *(uint *)((longlong)&uStackX_c + lVar8);
        *(uint **)(puVar17 + 0x30) = puVar1;
        *(undefined4 *)(puVar17 + 0x28) = uVar20;
        *(longlong *)(puVar17 + 0x20) = lVar11;
        uVar7 = *puVar1;
        *(undefined8 *)(puVar17 + -8) = 0x10099a;
        puVar21 = (uint *)func_0x(plVar2,param_3,puVar21,uVar7);
      }
    }
    goto LAB_;
  }
  uVar7 = *puVar22;
  if ((uVar7 & 0xc0000000) == 0x80000000) {
    *(undefined8 *)(puVar17 + -8) = 0x1008ff;
    iVar6 = func_0x(param_2 + 1);
    if (iVar6 == 0) {
      *puVar1 = 0;
    }
    else {
      *(undefined8 *)(puVar17 + -8) = 0x100917;
      puVar21 = (uint *)func_0x(param_2 + 0x15,param_3,puVar1,auStackX_10 + lVar8);
    }
    goto LAB_;
  }
  uVar5 = *(ushort *)((longlong)puVar22 + 6);
  if ((uVar5 & 0x10) != 0) {
    bVar12 = **(byte **)(param_2 + 4);
    if ((bVar12 & 0x10) == 0) {
      if ((1 << (bVar12 & 0xe) & 0x1105U) == 0) goto LAB_;
    }
    else if (((int)uVar7 < (int)*(uint *)(param_2 + 8)) &&
            (*(ushort *)(param_3 + 1) <=
             *(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)))) goto LAB_;
    goto LAB_;
  }
LAB_:
  if (-1 < (int)uVar7) {
    if ((uVar5 & 8) != 0) {
      puVar21 = (uint *)0x81fb44;
      if ((*(byte *)((longlong)(int)uVar7 + *(longlong *)(param_2 + 4)) &
          (byte)(1 << ((byte)uVar5 & 7))) == 0) {
        puVar21 = (uint *)0x820168;
      }
      *puVar1 = 1;
      goto LAB_;
    }
    if ((uVar5 & 0x10) != 0) {
      bVar12 = **(byte **)(param_2 + 4);
      if ((bVar12 & 0x10) == 0) {
        if ((1 << (bVar12 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar21 = *(uint **)(param_3 + 2) + 1;
          uVar7 = **(uint **)(param_3 + 2);
          if (uVar7 != 0x1f9e) {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x1001b8;
            (*_DAT_)(1,0xc48e78,0xc47878,0x381);
            *puVar1 = uVar7;
            goto LAB_;
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_2 + 8) <= (int)uVar7) ||
              (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
               *(ushort *)(param_3 + 1))) goto LAB_;
    }
    puVar21 = (uint *)((longlong)(int)uVar7 + *(longlong *)(param_2 + 4));
    *puVar1 = 0x1f9e;
    goto LAB_;
  }
  if (*(int *)(param_2 + 2) == 0) {
    param_2[1] = 0;
    uVar7 = *(uint *)(param_2 + 8);
    uVar18 = (ulonglong)uVar7;
    *(uint *)(param_2 + 10) = uVar7;
    pbVar23 = *(byte **)(param_2 + 4);
    bVar12 = *pbVar23;
    if ((bVar12 & 0x10) != 0) {
      uVar7 = uVar7 + 2 + (*(ushort *)(pbVar23 + uVar18) + 7 >> 3);
      uVar18 = (ulonglong)uVar7;
      *(uint *)(param_2 + 10) = uVar7;
      bVar12 = *pbVar23;
    }
    if ((bVar12 & 0x20) == 0) {
      *(int *)(param_2 + 2) = (int)uVar18;
      param_2[0xe] = 0;
      *(int *)(param_2 + 0xc) = (int)uVar18;
    }
    else {
      puVar19 = (ushort *)(pbVar23 + uVar18);
      uVar5 = *puVar19;
      param_2[0xe] = uVar5;
      if (uVar5 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar11 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar11 != 0)) &&
           ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar17 + -8) = 0x1002ce;
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x1002f2;
            (*_DAT_)(1,0xa9b108,0xbbadd8,0x80f);
          }
        }
        uVar3 = *(undefined8 *)(param_2 + 4);
        *(undefined8 *)(puVar17 + -8) = 0x100300;
        func_0x(uVar3,3);
        uVar5 = param_2[0xe];
        uVar18 = (ulonglong)*(uint *)(param_2 + 10);
      }
      uVar7 = (int)uVar18 + (uVar5 + 1) * 2;
      *(uint *)(param_2 + 0xc) = uVar7;
      if (0x1f9e < uVar7) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar11 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar11 != 0 &&
            ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
             (*(char *)(lVar11 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar17 + -8) = 0x10039f;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x1003c3;
            (*_DAT_)(1,0xa9b108,0xbbadd8,0x816);
          }
        }
        uVar3 = *(undefined8 *)(param_2 + 4);
        *(undefined8 *)(puVar17 + -8) = 0x1003d1;
        func_0x(uVar3,4);
        uVar5 = param_2[0xe];
        uVar7 = *(uint *)(param_2 + 0xc);
      }
      uVar18 = (ulonglong)uVar5;
      uVar5 = puVar19[uVar18];
      *(uint *)(param_2 + 2) = uVar5 & 0x7fff;
      if ((uVar5 & 0x7fff) < uVar7) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar11 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       ), lVar11 != 0)) &&
           ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
            (*(char *)(lVar11 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            *(undefined8 *)(puVar17 + -8) = 0x100472;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x100496;
            (*_DAT_)(1,0xa9b108,0xbbadd8,0x81d);
          }
        }
        uVar3 = *(undefined8 *)(param_2 + 4);
        *(undefined8 *)(puVar17 + -8) = 0x1004a4;
        func_0x(uVar3,4);
        uVar18 = (ulonglong)(ushort)param_2[0xe];
      }
      if ((short)puVar19[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
        lVar11 = *(longlong *)(param_2 + 4);
        do {
          lVar9 = (ulonglong)*(uint *)(param_2 + 10) + lVar11;
          if ((int)uVar18 == 1) {
            uVar7 = *(uint *)(param_2 + 0xc);
            uVar5 = *(ushort *)(lVar9 + uVar18 * 2);
            uVar24 = uVar7;
LAB_:
            if ((uVar5 & 0x7fff) < uVar7) goto LAB_;
          }
          else {
            uVar7 = *(ushort *)(lVar9 + -2 + uVar18 * 2) & 0x7fff;
            uVar24 = *(uint *)(param_2 + 0xc);
            uVar5 = *(ushort *)(lVar9 + uVar18 * 2);
            if (uVar24 <= uVar7) goto LAB_;
LAB_:
            *(undefined8 *)(puVar17 + -8) = 0x100517;
            func_0x(lVar11,7);
            uVar24 = *(uint *)(param_2 + 0xc);
          }
          if ((uVar7 < uVar24) || (*(uint *)(param_2 + 2) < uVar7)) goto LAB_;
          lVar11 = *(longlong *)(param_2 + 4);
          if (*(ushort *)(lVar11 + (ulonglong)uVar7) == 5) {
            param_2[1] = param_2[1] | 2;
            param_2[0xe] = param_2[0xe] + -1;
            param_2[0x15] = (short)uVar7;
            lVar11 = (ulonglong)(uVar7 & 0xffff) + *(longlong *)(param_2 + 4);
            uVar5 = param_2[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar11 + 2) & 0x4000) != 0) {
              uVar5 = *(ushort *)(lVar11 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
            }
            param_2[0x16] = uVar5;
            param_2[0x16] = (uVar5 ^ *(ushort *)(lVar11 + 2)) & 0x7ff ^ uVar5;
            uVar18 = (ulonglong)*(uint *)(param_2 + 2);
            pbVar23 = *(byte **)(param_2 + 4);
            goto LAB_;
          }
          if (*(ushort *)(lVar11 + (ulonglong)uVar7) < 0x400) break;
          param_2[1] = param_2[1] | 1;
          uVar5 = param_2[0xe] - 1;
          param_2[0xe] = uVar5;
          if ((uVar5 == 0) ||
             (uVar18 = (ulonglong)uVar5, -1 < (short)puVar19[(ulonglong)(uVar5 - 1) + 1])) break;
        } while( true );
      }
      uVar18 = (ulonglong)*(uint *)(param_2 + 2);
      pbVar23 = *(byte **)(param_2 + 4);
    }
LAB_:
    iVar6 = 0;
    if ((*pbVar23 & 0x40) == 0) {
      *(undefined4 *)(param_2 + 0x13) = 0;
    }
    else {
      *(int *)(param_2 + 0x13) = (int)uVar18;
      *(int *)(param_2 + 2) = (int)uVar18 + 0xe;
      *(undefined8 *)(puVar17 + -8) = 0x10062a;
      puVar10 = (ulonglong *)func_0x(param_2 + 1);
      uVar18 = *puVar10;
      uVar14 = (ushort)(uVar18 >> 0x30);
      uVar5 = uVar14;
      if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
        uVar5 = uVar14 & 0xdfff;
        if ((uVar18 & 0x4000000000000000) != 0) {
          uVar5 = uVar14 | 0x2000;
        }
      }
      if (uVar5 == 0xfffc) {
        iVar6 = (int)((uVar18 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar6;
      uVar18 = (ulonglong)*(uint *)(param_2 + 2);
    }
    iVar6 = (int)uVar18;
    if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
       (*(ulonglong *)(param_2 + 0xf) < uVar18 + *(longlong *)(param_2 + 4))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar11 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
           , lVar11 != 0 && (lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0)) &&
          (*(char *)(lVar11 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          *(undefined8 *)(puVar17 + -8) = 0x100722;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(puVar17 + 0x20) = 0;
          *(undefined8 *)(puVar17 + -8) = 0x100746;
          (*_DAT_)(1,0xa9b108,0xbbadd8,0x877);
        }
      }
      uVar3 = *(undefined8 *)(param_2 + 4);
      *(undefined8 *)(puVar17 + -8) = 0x100754;
      func_0x(uVar3,0x12);
      iVar6 = *(int *)(param_2 + 2);
    }
    if (0x3f3b < iVar6 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar11 = *(longlong *)
                     ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8),
          lVar11 != 0 &&
          ((lVar11 = *(longlong *)(lVar11 + 0x60), lVar11 != 0 &&
           (*(char *)(lVar11 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          *(undefined8 *)(puVar17 + -8) = 0x1007e0;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(puVar17 + 0x20) = 0;
          *(undefined8 *)(puVar17 + -8) = 0x100804;
          (*_DAT_)(1,0xa9b108,0xbbadd8,0x87c);
        }
      }
      uVar3 = *(undefined8 *)(param_2 + 4);
      *(undefined8 *)(puVar17 + -8) = 0x100812;
      func_0x(uVar3,5);
    }
  }
LAB_:
  sVar15 = -*(short *)param_3;
  if ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0) {
    bVar12 = **(byte **)(param_2 + 4);
    if ((bVar12 & 0x10) == 0) {
      if ((1 << (bVar12 & 0xe) & 0x1105U) != 0) {
LAB_:
        puVar21 = *(uint **)(param_3 + 2) + 1;
        *puVar1 = **(uint **)(param_3 + 2);
        goto LAB_;
      }
    }
    else {
      if ((int)*(uint *)(param_2 + 8) <= (int)*param_3) goto LAB_;
      if (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) < *(ushort *)(param_3 + 1))
      {
        puVar21 = *(uint **)(param_3 + 2) + 1;
        *puVar1 = **(uint **)(param_3 + 2);
        goto LAB_;
      }
    }
  }
  lVar11 = (longlong)sVar15;
  puVar21 = *(uint **)(param_2 + 4);
  if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar15) {
    uVar7 = 0;
LAB_:
    *puVar1 = uVar7;
    goto LAB_;
  }
  uVar7 = *(uint *)(param_2 + 10);
  if (sVar15 == 1) {
    uVar24 = *(uint *)(param_2 + 0xc);
    uVar7 = *(ushort *)((longlong)puVar21 + lVar11 * 2 + (ulonglong)uVar7) & 0x7fff;
LAB_:
    if (uVar7 < uVar24) goto LAB_;
  }
  else {
    uVar24 = *(ushort *)((longlong)puVar21 + lVar11 * 2 + ((ulonglong)uVar7 - 2)) & 0x7fff;
    uVar7 = *(ushort *)((longlong)puVar21 + lVar11 * 2 + (ulonglong)uVar7) & 0x7fff;
    puVar21 = *(uint **)(param_2 + 4);
    if (*(uint *)(param_2 + 0xc) <= uVar24) goto LAB_;
LAB_:
    *(undefined8 *)(puVar17 + -8) = 0x1008d5;
    func_0x(puVar21,7);
    puVar21 = *(uint **)(param_2 + 4);
  }
  puVar21 = (uint *)((longlong)puVar21 + (ulonglong)uVar24);
  *puVar1 = uVar7 - uVar24;
LAB_:
  if (*puVar1 != 0) {
    if ((*puVar1 < 0x30) || (*(short *)puVar21 != 3)) {
      *(undefined8 *)(puVar17 + -8) = 0x100b44;
      func_0x(&stack0x00000628 + lVar8,&stack0x00000730 + lVar8);
      *(undefined8 *)(&stack0x00000628 + lVar8) = 0x8355c8;
      *(undefined4 *)(puVar17 + 0x28) = 0;
      *(uint *)(puVar17 + 0x20) = *param_3;
      uVar7 = *puVar1;
      *(undefined8 *)(puVar17 + -8) = 0x100b76;
      func_0x(&stack0x00000628 + lVar8,param_1,puVar21,uVar7);
      *(undefined8 *)(puVar17 + -8) = 0x100b82;
      func_0x(&stack0x00000628 + lVar8);
      *(undefined8 *)(puVar17 + -8) = 0x100b8e;
      func_0x(&stack0x00000628 + lVar8);
      *(undefined8 *)(puVar17 + -8) = 0x100b9b;
      func_0x(&stack0x00000628 + lVar8);
    }
    else {
      uVar7 = *param_3;
      if ((int)uVar7 < 0) {
        if ((uVar7 & 0xc0000000) == 0x80000000) {
          uVar3 = **(undefined8 **)(*(longlong *)(*(longlong *)(param_1 + 0x58) + 8) + 0x160);
          *(undefined8 *)(puVar17 + -8) = 0x100a11;
          lVar11 = func_0x(uVar3,uVar7 & 0x1fffffff);
        }
        else {
          uVar3 = *(undefined8 *)(*(longlong *)(*(longlong *)(param_1 + 0x58) + 8) + 0x160);
          *(undefined8 *)(puVar17 + -8) = 0x1009f6;
          lVar11 = func_0x(uVar3);
        }
        if (lVar11 != 0) {
          *(undefined8 *)(puVar17 + -8) = 0x100a26;
          func_0x(&stack0x00000038 + lVar8);
          *(undefined4 *)((longlong)auStackX_18 + lVar8) = _DAT_;
          *(undefined4 *)((longlong)auStackX_18 + lVar8 + 4) = uRam000000000081fe7c;
          *(undefined4 *)((longlong)auStackX_18 + lVar8 + 8) = uRam000000000081fe80;
          *(undefined4 *)((longlong)auStackX_18 + lVar8 + 0xc) = uRam000000000081fe84;
          *(undefined4 *)(&stack0x00000028 + lVar8) = 0;
          *(longlong *)(puVar17 + 0x38) = (longlong)auStackX_18 + lVar8;
          *(undefined4 *)(puVar17 + 0x30) = *(undefined4 *)(lVar11 + 0x3c);
          *(undefined4 *)(puVar17 + 0x28) = 0x800;
          *(undefined4 *)(puVar17 + 0x20) = 0;
          *(undefined8 *)(puVar17 + -8) = 0x100a63;
          func_0x(&stack0x00000038 + lVar8,param_1,puVar21);
          *(undefined8 *)(puVar17 + -8) = 0x100a6c;
          func_0x(&stack0x00000038 + lVar8);
          bVar12 = (&stack0x000002e8)[lVar8];
          if (((bVar12 & 2) != 0) && (((&stack0x00000044)[lVar8] & 8) != 0)) {
            *(undefined8 *)(puVar17 + -8) = 0x100a87;
            func_0x(&stack0x00000038 + lVar8);
            uVar7 = *(uint *)(&stack0x00000044 + lVar8) & 0xfffffff7;
            *(uint *)(&stack0x00000044 + lVar8) = uVar7;
            if ((char)uVar7 < '\0') {
              *(undefined8 *)(puVar17 + -8) = 0x100a9d;
              func_0x(&stack0x00000038 + lVar8);
              uVar7 = *(uint *)(&stack0x00000044 + lVar8);
            }
            bVar12 = (&stack0x000002e8)[lVar8];
            if ((uVar7 & 2) != 0) {
              bVar12 = bVar12 & 0xfe;
              (&stack0x000002e8)[lVar8] = bVar12;
              *(uint *)(&stack0x00000044 + lVar8) = uVar7 & 0xfffffffd;
            }
          }
          (&stack0x000002e8)[lVar8] = bVar12 & 0xfd;
          *(undefined8 *)(puVar17 + -8) = 0x100ace;
          func_0x(&stack0x00000038 + lVar8,0);
          *(uint *)(&stack0x00000044 + lVar8) = *(uint *)(&stack0x00000044 + lVar8) | 4;
          if (*(longlong **)(&stack0x00000368 + lVar8) != (longlong *)0x0) {
            pcVar4 = *(code **)(**(longlong **)(&stack0x00000368 + lVar8) + 0x10);
            *(undefined8 *)(puVar17 + -8) = 0x100ae4;
            (*pcVar4)();
            *(undefined8 *)(&stack0x00000368 + lVar8) = 0;
          }
          *(undefined8 *)(&stack0x00000038 + lVar8) = 0xacca88;
          *(undefined4 *)(&stack0x00000040 + lVar8) = 0xfccccccf;
          *(undefined8 *)(puVar17 + -8) = 0x100b08;
          func_0x(&stack0x00000038 + lVar8,1);
          *(undefined8 *)(puVar17 + -8) = 0x100b15;
          func_0x(&stack0x000005f8 + lVar8);
          if (*(longlong **)(&stack0x00000368 + lVar8) != (longlong *)0x0) {
            pcVar4 = *(code **)(**(longlong **)(&stack0x00000368 + lVar8) + 0x10);
            *(undefined8 *)(puVar17 + -8) = 0x100b28;
            (*pcVar4)();
            *(undefined8 *)(&stack0x00000368 + lVar8) = 0;
          }
        }
      }
    }
  }
  if (*param_2 == 0) {
    *(undefined8 *)(puVar17 + -8) = 0x100bb2;
    func_0x(param_2 + 1,param_3,0);
  }
  else {
    if (*(int *)(param_2 + 2) == 0) {
      *(undefined8 *)(puVar17 + -8) = 0x100bc4;
      func_0x(param_2 + 1);
    }
    if (*(ushort *)(param_3 + 1) <= (ushort)param_2[1]) {
      uVar5 = param_2[0xf];
      lVar11 = *(longlong *)(param_2 + 4);
      *(undefined8 *)(puVar17 + -8) = 0x100be5;
      uVar7 = func_0x(param_2 + 1);
      puVar19 = (ushort *)((ulonglong)uVar5 + lVar11 + 3 + (ulonglong)uVar7 * 2);
      *puVar19 = *puVar19 & 0x7fff;
    }
  }
  *(undefined8 *)(puVar17 + -8) = 0x100c02;
  func_0x(param_2,param_3,0,0);
  uVar18 = *(ulonglong *)(&stack0x000026c8 + lVar8);
  *(undefined8 *)(puVar17 + -8) = 0x100c11;
  func_0x(uVar18 ^ (ulonglong)puVar1);
  return;
}

