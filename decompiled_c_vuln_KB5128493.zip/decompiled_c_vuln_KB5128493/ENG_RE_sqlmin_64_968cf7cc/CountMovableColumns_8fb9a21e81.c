
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_(longlong param_1,short *param_2,longlong *param_3,int param_4)

{
  ushort *puVar1;
  byte bVar2;
  ushort uVar3;
  uint uVar4;
  int iVar5;
  longlong lVar6;
  ulonglong *puVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  ushort *puVar11;
  uint uVar12;
  int iVar13;
  ushort uVar14;
  ushort uVar15;
  byte *pbVar16;
  int iVar17;
  ulonglong uVar18;
  int iVar19;
  longlong unaff_GS_OFFSET;
  
  uVar12 = 0;
  iVar17 = 0;
  iVar19 = -1;
  if (param_3 != (longlong *)0x0) {
    param_2 = (short *)(**(code **)*param_3)(param_3);
  }
  puVar1 = (ushort *)(param_2 + 1);
  if (*param_2 == 0) {
    uVar4 = func_0x(puVar1);
  }
  else {
    uVar4 = (uint)*puVar1;
  }
  if (0 < (int)uVar4) {
    do {
      if ((~uVar12 & 0xc0000000) == 0x80000000) {
        lVar6 = func_0x
                          (**(undefined8 **)(*(longlong *)(param_1 + 8) + 0x160),
                           ~uVar12 & 0x1fffffff);
      }
      else {
        lVar6 = func_0x(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x160));
      }
      if ((lVar6 != 0) && ((*(byte *)(lVar6 + 0x21) & 0x10) != 0)) {
        iVar17 = iVar17 + 1;
      }
      uVar12 = uVar12 + 1;
    } while ((int)uVar12 < (int)uVar4);
  }
  if (param_4 == 0) {
    iVar13 = func_0x(param_2);
  }
  else {
    iVar13 = 0;
  }
  uVar10 = 0;
  uVar18 = uVar10;
  if (0 < (longlong)iVar13) {
    do {
      if (*(int *)(param_2 + 2) == 0) {
        pbVar16 = *(byte **)(param_2 + 4);
        uVar12 = *(uint *)(param_2 + 8);
        uVar9 = (ulonglong)uVar12;
        *puVar1 = 0;
        *(uint *)(param_2 + 10) = uVar12;
        bVar2 = *pbVar16;
        if ((bVar2 & 0x10) != 0) {
          uVar12 = uVar12 + 2 + (*(ushort *)(pbVar16 + uVar9) + 7 >> 3);
          uVar9 = (ulonglong)uVar12;
          *(uint *)(param_2 + 10) = uVar12;
          bVar2 = *pbVar16;
        }
        if ((bVar2 & 0x20) == 0) {
          *(int *)(param_2 + 2) = (int)uVar9;
          param_2[0xe] = 0;
          *(int *)(param_2 + 0xc) = (int)uVar9;
        }
        else {
          puVar11 = (ushort *)(pbVar16 + uVar9);
          uVar3 = *puVar11;
          param_2[0xe] = uVar3;
          if (uVar3 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar6 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar6 != 0)) &&
               ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 &&
                (*(char *)(lVar6 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0xaa63d8,0xbc60a8,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),3);
            uVar9 = (ulonglong)*(uint *)(param_2 + 10);
            uVar3 = param_2[0xe];
          }
          uVar12 = (int)uVar9 + (uVar3 + 1) * 2;
          *(uint *)(param_2 + 0xc) = uVar12;
          if (0x1f9e < uVar12) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar6 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar6 != 0 &&
                ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 &&
                 (*(char *)(lVar6 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xaa63d8,0xbc60a8,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar3 = param_2[0xe];
            uVar12 = *(uint *)(param_2 + 0xc);
          }
          uVar9 = (ulonglong)uVar3;
          uVar3 = puVar11[uVar9];
          *(uint *)(param_2 + 2) = uVar3 & 0x7fff;
          if ((uVar3 & 0x7fff) < uVar12) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar6 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar6 != 0)) &&
               ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 &&
                (*(char *)(lVar6 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xaa63d8,0xbc60a8,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar9 = (ulonglong)(ushort)param_2[0xe];
          }
          if ((short)puVar11[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
            pbVar16 = *(byte **)(param_2 + 4);
            do {
              if ((int)uVar9 == 1) {
                uVar12 = *(uint *)(param_2 + 0xc);
                uVar4 = uVar12;
LAB_:
                if ((*(ushort *)(pbVar16 + uVar9 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff)
                    < uVar12) goto LAB_;
              }
              else {
                uVar4 = *(uint *)(param_2 + 0xc);
                uVar12 = *(ushort *)(pbVar16 + uVar9 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2))
                         & 0x7fff;
                if (uVar4 <= uVar12) goto LAB_;
LAB_:
                func_0x(pbVar16,7);
                uVar4 = *(uint *)(param_2 + 0xc);
              }
              if ((uVar12 < uVar4) || (*(uint *)(param_2 + 2) < uVar12)) goto LAB_;
              pbVar16 = *(byte **)(param_2 + 4);
              if (*(ushort *)(pbVar16 + uVar12) == 5) {
                *puVar1 = *puVar1 | 2;
                param_2[0xe] = param_2[0xe] + -1;
                uVar4 = uVar12 & 0xffff;
                param_2[0x15] = (short)uVar12;
                uVar3 = param_2[0x16] & 0xc7ffU;
                if ((*(ushort *)(pbVar16 + (ulonglong)uVar4 + 2) >> 0xe & 1) != 0) {
                  uVar3 = *(ushort *)(pbVar16 + (ulonglong)uVar4 + 2) & 0x3800 |
                          param_2[0x16] & 0xc7ffU;
                }
                param_2[0x16] = uVar3;
                param_2[0x16] =
                     (uVar3 ^ *(ushort *)(pbVar16 + (ulonglong)uVar4 + 2)) & 0x7ff ^ uVar3;
                goto LAB_;
              }
              if (*(ushort *)(pbVar16 + uVar12) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar3 = param_2[0xe] - 1;
              param_2[0xe] = uVar3;
              if (uVar3 == 0) goto LAB_;
              uVar9 = (ulonglong)uVar3;
            } while ((short)puVar11[(ulonglong)(uVar3 - 1) + 1] < 0);
            uVar9 = (ulonglong)*(uint *)(param_2 + 2);
          }
          else {
LAB_:
            uVar9 = (ulonglong)*(uint *)(param_2 + 2);
            pbVar16 = *(byte **)(param_2 + 4);
          }
        }
        iVar5 = 0;
        if ((*pbVar16 & 0x40) == 0) {
          *(undefined4 *)(param_2 + 0x13) = 0;
        }
        else {
          *(int *)(param_2 + 0x13) = (int)uVar9;
          *(int *)(param_2 + 2) = (int)uVar9 + 0xe;
          puVar7 = (ulonglong *)func_0x(puVar1);
          uVar15 = (ushort)(*puVar7 >> 0x30);
          uVar3 = uVar15;
          if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
            uVar3 = uVar15 & 0xdfff;
            if ((uVar15 >> 0xe & 1) != 0) {
              uVar3 = uVar15 | 0x2000;
            }
          }
          if (uVar3 == 0xfffc) {
            iVar5 = (int)((*puVar7 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar5;
          uVar9 = (ulonglong)*(uint *)(param_2 + 2);
        }
        iVar5 = (int)uVar9;
        if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
           (*(ulonglong *)(param_2 + 0xf) < uVar9 + *(longlong *)(param_2 + 4))) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar6 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar6 != 0 &&
               (lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0)) &&
              (*(char *)(lVar6 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0xaa63d8,0xbc60a8,0x877,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),0x12);
          iVar5 = *(int *)(param_2 + 2);
        }
        if (0x3f3b < iVar5 - 1U) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar6 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar6 != 0 &&
              ((lVar6 = *(longlong *)(lVar6 + 0x60), lVar6 != 0 &&
               (*(char *)(lVar6 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              func_0x(*(undefined8 *)(param_2 + 4),5);
              goto LAB_;
            }
            (*_DAT_)(1,0xaa63d8,0xbc60a8,0x87c,0);
          }
          func_0x(*(undefined8 *)(param_2 + 4),5);
        }
      }
LAB_:
      iVar5 = func_0x(puVar1);
      uVar12 = (uint)uVar10;
      if (iVar5 == 0) {
        iVar5 = func_0x(puVar1);
        if (iVar5 == 0) {
          (*_DAT_)(1,0xc61a58,0xc52b48,0xd67,0);
        }
      }
      else {
        uVar3 = param_2[0x16];
        if (uVar12 < (uVar3 & 0x7ff)) {
          uVar15 = 0;
          lVar6 = *(longlong *)(param_2 + 4) + (ulonglong)(ushort)param_2[0x15];
          if ((uVar3 & 0x3800) == 0) {
            uVar14 = *(ushort *)(lVar6 + 2);
LAB_:
            uVar15 = uVar14 >> 0xb & 7;
          }
          else {
            lVar8 = 0;
            if ((uVar3 >> 0xb & 7) != 0) {
              do {
                if (((lVar8 == 0) || ((*(ushort *)(lVar6 + 2 + lVar8 * 2) & 0x7ff) <= uVar12)) &&
                   (uVar14 = *(ushort *)(lVar6 + 4 + lVar8 * 2),
                   (int)uVar12 <= (int)((uVar14 & 0x7ff) - 1))) goto LAB_;
                lVar8 = lVar8 + 1;
              } while (lVar8 < (longlong)(ulonglong)(uVar3 >> 0xb & 7));
            }
          }
          iVar19 = (uint)*(ushort *)
                          ((ulonglong)((uVar3 >> 0xb & 7) * 2) + *(longlong *)(param_2 + 4) +
                           uVar18 * 2 + 4 + (ulonglong)(ushort)param_2[0x15]) +
                   (uint)uVar15 * 0x10000;
        }
        else {
          (*_DAT_)(1,0xc61a28,0xc61a70,0x3c6,0);
        }
      }
      lVar6 = func_0x(**(undefined8 **)(*(longlong *)(param_1 + 8) + 0x160),iVar19);
      if ((lVar6 != 0) && ((*(byte *)(lVar6 + 0x21) & 0x10) != 0)) {
        iVar17 = iVar17 + 1;
      }
      uVar10 = (ulonglong)(uVar12 + 1);
      uVar18 = uVar18 + 1;
    } while ((longlong)uVar18 < (longlong)iVar13);
  }
  if (param_3 != (longlong *)0x0) {
    (**(code **)(*param_3 + 8))();
  }
  return iVar17;
}

