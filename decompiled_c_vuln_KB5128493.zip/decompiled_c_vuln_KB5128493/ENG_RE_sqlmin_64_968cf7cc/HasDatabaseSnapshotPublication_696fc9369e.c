
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined2 param_1)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong unaff_GS_OFFSET;
  undefined auStack_128 [32];
  undefined8 uStack_108;
  undefined8 uStack_100;
  undefined uStack_f8;
  undefined8 uStack_f0;
  undefined4 uStack_e8;
  short asStack_d8 [2];
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined auStack_c0 [16];
  undefined8 uStack_b0;
  longlong lStack_a8;
  undefined2 uStack_a0;
  undefined8 uStack_98;
  int iStack_90;
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  longlong lStack_48;
  uint uStack_40;
  undefined8 uStack_38;
  undefined8 uStack_30;
  ulonglong uStack_28;
  
  uStack_b0 = 0xfffffffffffffffe;
  uStack_28 = _DAT_ ^ (ulonglong)auStack_128;
  asStack_d8[0] = 0;
  uStack_d0 = 0;
  uStack_c8 = 1;
  auStack_c0._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_c0._8_8_ = 0;
  cVar2 = (**(code **)(*(longlong *)auStack_c0._0_8_ + 0x1d0))();
  if (cVar2 == '\0') {
    uStack_e8 = 0;
    uStack_f0 = 0;
    uStack_f8 = 0;
    uStack_100 = CONCAT44(uStack_100._4_4_,2);
    uStack_108 = CONCAT44(uStack_108._4_4_,1);
    (**(code **)(*(longlong *)auStack_c0._0_8_ + 8))(auStack_c0._0_8_,0x1a5b7b8,0x3c);
    uStack_d0 = CONCAT44(uStack_d0._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_c0._0_8_ + 0xe8))
              (auStack_c0._0_8_,1,1,(longlong)&uStack_d0 + 4);
    uStack_c8 = 1;
    uStack_d0 = CONCAT44(uStack_d0._4_4_,4);
  }
  iVar3 = func_0x(param_1,0x1a5a840);
  if (iVar3 != 0) {
    uStack_98 = (**(code **)(**(longlong **)
                               (*(longlong *)
                                 ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8)) + 0x90) + 0x1b0))();
    lStack_a8 = 0;
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    auStack_68 = ZEXT816(0);
    auStack_58 = ZEXT816(0);
    lStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    uStack_30 = 0;
    uStack_a0 = param_1;
    iStack_90 = iVar3;
    iVar3 = func_0x(&lStack_a8,3,1);
    if (iVar3 != 0) {
      uStack_100 = lStack_a8;
      lVar1 = uStack_100;
      do {
        do {
          while( true ) {
            do {
              uStack_100 = lVar1;
              uStack_108 = uStack_38;
              iVar3 = (**(code **)(*(longlong *)auStack_88._8_8_ + 0x18))(auStack_88._8_8_,0,1);
              if (iVar3 != 0) goto LAB_;
              uStack_d4 = 0;
              lVar1 = lStack_a8;
            } while (lStack_a8 == 0);
            uVar4 = func_0x(&lStack_a8,0x1a5b738,&uStack_d4);
            lVar1 = lStack_a8;
            uVar6 = (ulonglong)uVar4;
            if (uVar6 == *(ulonglong *)((ulonglong)(uVar4 - 1) * 0x58 + lStack_48)) break;
            uVar4 = 1;
            if (uStack_40 != 0) {
              do {
                if (uVar6 == *(ulonglong *)((ulonglong)(uVar4 - 1) * 0x58 + lStack_48))
                goto LAB_;
                uVar4 = uVar4 + 1;
              } while (uVar4 <= uStack_40);
            }
          }
LAB_:
        } while (uStack_40 < uVar4);
        lVar5 = (ulonglong)(uVar4 - 1) * 0x58 + lStack_48;
      } while ((((*(longlong *)(lVar5 + 8) + lStack_a8 == 0) ||
                (1 < *(longlong *)(lStack_a8 + *(longlong *)(lVar5 + 0x10)) - 1U)) ||
               (*(int *)(lStack_a8 + *(longlong *)(lVar5 + 0x18)) == 3)) ||
              (func_0x(asStack_d8), 1 < (ushort)(asStack_d8[0] - 5U)));
    }
LAB_:
    func_0x(&lStack_a8);
  }
  func_0x(&uStack_d0,0);
  if ((int)uStack_d0 != 0) {
    func_0x(&uStack_d0,0);
  }
  func_0x(uStack_28 ^ (ulonglong)auStack_128);
  return;
}

