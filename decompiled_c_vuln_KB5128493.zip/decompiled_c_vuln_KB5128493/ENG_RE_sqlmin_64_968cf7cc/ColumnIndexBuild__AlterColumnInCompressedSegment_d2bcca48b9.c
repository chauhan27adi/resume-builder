
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong param_3,undefined8 param_4)

{
  uint6 *puVar1;
  byte bVar2;
  byte bVar3;
  short sVar4;
  ushort uVar5;
  uint uVar6;
  code *pcVar7;
  short *psVar8;
  char *pcVar9;
  undefined8 *puVar10;
  uint6 uVar11;
  char cVar12;
  undefined uVar13;
  undefined2 uVar14;
  short sVar15;
  undefined4 uVar16;
  int iVar17;
  int iVar18;
  longlong lVar19;
  undefined8 uVar20;
  longlong *plVar21;
  longlong *plVar22;
  longlong lVar23;
  uint *puVar24;
  undefined8 *puVar25;
  undefined8 uVar26;
  longlong *plVar27;
  byte *pbVar28;
  uint uVar29;
  ulonglong uVar30;
  ushort uVar31;
  longlong lVar32;
  longlong lVar33;
  longlong lVar34;
  undefined4 uVar35;
  undefined8 uVar36;
  longlong *plVar37;
  longlong *plVar38;
  longlong unaff_GS_OFFSET;
  bool bVar39;
  bool bVar40;
  undefined8 uStackX_8;
  undefined8 uStackX_10;
  undefined auStackX_18 [8];
  undefined8 uStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar19 = func_0x();
  lVar19 = -lVar19;
  *(undefined8 *)(&stack0x000006e8 + lVar19) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002f58 + lVar19) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar19);
  *(undefined8 *)(&stack0x000001b8 + lVar19) = param_4;
  *(longlong *)(&stack0x00000098 + lVar19) = param_3;
  *(undefined8 *)(&stack0x00000188 + lVar19) = param_2;
  *(longlong *)(&stack0x000000d0 + lVar19) = param_1;
  *(longlong *)(&stack0x000003c0 + lVar19) = param_1;
  plVar38 = (longlong *)0x0;
  *(undefined8 *)(&stack0x00000110 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000218 + lVar19) = 0;
  *(undefined4 *)(&stack0x00000234 + lVar19) = 0xffffffff;
  *(undefined4 *)(&stack0x0000022c + lVar19) = 0;
  *(undefined4 *)(&stack0x00000238 + lVar19) = 1;
  *(undefined8 *)(&stack0x00000240 + lVar19) = 0;
  *(undefined (*) [16])(&stack0x00000248 + lVar19) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000258 + lVar19) = 0;
  *(undefined4 *)(&stack0x00000260 + lVar19) = 100;
  *(undefined8 *)(&stack0x00000264 + lVar19) = 100;
  *(undefined4 *)(&stack0x00000230 + lVar19) = 1;
  *(undefined8 *)(&stack0x00000208 + lVar19) = 0;
  *(undefined4 *)(&stack0x00000210 + lVar19) = 0;
  *(undefined4 *)(&stack0x00000270 + lVar19) = _DAT_;
  *(undefined4 *)(&stack0x0000026c + lVar19) = 0;
  *(undefined4 *)(&stack0x00000278 + lVar19) = 0;
  uVar29 = *(uint *)(&stack0x0000027c + lVar19);
  *(uint *)(&stack0x0000027c + lVar19) = uVar29 & 0xfffffffe;
  *(uint *)(&stack0x0000027c + lVar19) = uVar29 & 0xfffffffc;
  *(uint *)(&stack0x0000027c + lVar19) = uVar29 & 0xfffffff8;
  *(uint *)(&stack0x0000027c + lVar19) = uVar29 & 0xfffffff0;
  *(undefined8 *)(&stack0x00000288 + lVar19) = 0;
  (&stack0x00000280)[lVar19] = (&stack0x00000280)[lVar19] & 0xfe;
  *(undefined8 *)(&stack0x000002b8 + lVar19) = 0xf88c10;
  *(undefined8 *)(&stack0x000002b8 + lVar19) = 0xf800f0;
  *(undefined8 *)(&stack0x000002c8 + lVar19) = 0;
  *(undefined4 *)(&stack0x000002d0 + lVar19) = 0;
  *(undefined4 *)(&stack0x000002e0 + lVar19) = 0xffffffff;
  *(undefined4 *)(&stack0x000002f0 + lVar19) = 0x80000000;
  (&stack0x000002e8)[lVar19] = 0;
  uVar29 = (*(undefined4 **)(param_3 + 8))[0xc];
  uVar35 = **(undefined4 **)(param_3 + 8);
  *(undefined8 *)(&stack0x00000090 + lVar19) = 0;
  lVar32 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar23 = *(longlong *)(lVar32 + 0x100);
  if (lVar23 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1001d5;
    (*_DAT_)();
    lVar23 = *(longlong *)(lVar32 + 0x100);
  }
  uVar20 = *(undefined8 *)(param_1 + 0x78);
  *(undefined8 *)(&stack0x00000430 + lVar19) = *(undefined8 *)(lVar23 + 1000);
  *(undefined8 *)(&stack0x00000438 + lVar19) = uVar20;
  *(undefined8 *)(&stack0x00000440 + lVar19) = 0;
  (&stack0x00000448)[lVar19] = 0;
  *(undefined8 *)(&stack0x00000118 + lVar19) = 0;
  (&stack0x00000039)[lVar19] = 0;
  uVar30 = *(ulonglong *)(*(longlong *)(param_1 + 0x70) + 0x14);
  lVar32 = ((uVar30 >> 0x20 & 0xffff) << 0x20 | uVar30 & 0xffffffff) << 0x10;
  lVar23 = *(longlong *)(*(longlong *)(param_1 + 0x70) + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100246;
  uVar20 = func_0x(lVar23 + 0xa0);
  *(undefined2 *)(&stack0x00000121 + lVar19) = 0;
  (&stack0x00000123)[lVar19] = 0;
  *(undefined8 *)(&stack0x00000134 + lVar19) = 0;
  (&stack0x00000120)[lVar19] = 0;
  *(undefined4 *)(&stack0x00000124 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000128 + lVar19) = 0xffffffffffffffff;
  *(undefined4 *)(&stack0x00000130 + lVar19) = 0;
  *(undefined4 *)(&stack0x0000013c + lVar19) = 0;
  *(undefined2 *)(&stack0x000000d9 + lVar19) = 0;
  (&stack0x000000db)[lVar19] = 0;
  *(undefined8 *)(&stack0x000000ec + lVar19) = 0;
  (&stack0x000000d8)[lVar19] = 0;
  *(undefined4 *)(&stack0x000000dc + lVar19) = 0;
  *(undefined8 *)(&stack0x000000e0 + lVar19) = 0xffffffffffffffff;
  *(undefined4 *)(&stack0x000000e8 + lVar19) = 0;
  *(undefined4 *)(&stack0x000000f4 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000140 + lVar19) = 0;
  *(undefined8 *)(&stack0x000001c0 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000298 + lVar19) = 0;
  (&stack0x000002a0)[lVar19] = 0;
  *(undefined8 *)(&stack0x000002a8 + lVar19) = 0;
  *(undefined8 *)(&stack0x000002b0 + lVar19) = 0;
  *(undefined4 *)(&stack0x000000a8 + lVar19) = 3;
  *(undefined (*) [16])(&stack0x000000b0 + lVar19) = ZEXT816(0);
  *(undefined4 *)(&stack0x000000c0 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000720 + lVar19) = *(undefined8 *)(param_1 + 0x78);
  *(undefined4 *)(&stack0x000000f8 + lVar19) = 0;
  *(undefined2 *)(&stack0x000000fc + lVar19) = 0;
  *(undefined2 *)(&stack0x000000fe + lVar19) = 0;
  *(int *)(&stack0x000000c8 + lVar19) = (int)uVar30;
  uVar14 = (undefined2)(uVar30 >> 0x20);
  *(undefined2 *)(&stack0x000000cc + lVar19) = uVar14;
  *(undefined2 *)(&stack0x000000ce + lVar19) = 0;
  *(undefined2 *)(&stack0x000000fc + lVar19) = uVar14;
  *(int *)(&stack0x000000f8 + lVar19) = (int)uVar30;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar19) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100392;
  func_0x(&stack0x000002b8 + lVar19,0,*(undefined8 *)(&stack0x000000f8 + lVar19));
  *(undefined4 *)(&stack0x0000022c + lVar19) = 3;
  *(undefined4 *)(&stack0x00000238 + lVar19) = 1;
  *(undefined8 *)(&stack0x00000240 + lVar19) = uVar20;
  *(undefined8 *)(&stack0x00000250 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000258 + lVar19) = 0;
  *(undefined4 *)(&stack0x00000260 + lVar19) = 0;
  *(undefined4 *)(&stack0x00000264 + lVar19) = 0;
  *(uint *)(&stack0x00000208 + lVar19) = *(uint *)(&stack0x00000208 + lVar19) | 8;
  *(undefined4 *)(&stack0x00000224 + lVar19) = 0x1000;
  (&stack0x000000a0)[lVar19] = DAT_;
  if ((DAT_ != '\0') &&
     (*(longlong *)
       (*(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x328) + 0x30) + 0x6b0) + 0x14c8) != 0))
  {
    uVar20 = *(undefined8 *)(param_1 + 0x78);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100424;
    uVar20 = func_0x(uVar20,1);
    *(undefined8 *)(&stack0x000001c0 + lVar19) = uVar20;
    *(undefined8 *)(&stack0x00000418 + lVar19) = 0;
    lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x000007b0 + lVar19) = lVar23;
    lVar33 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x000007c0 + lVar19) = lVar33;
    lVar23 = *(longlong *)(lVar33 + 0x100);
    *(longlong *)(&stack0x00000408 + lVar19) = lVar23;
    if (lVar23 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10047d;
      (*_DAT_)();
      lVar23 = *(longlong *)(lVar33 + 0x100);
      *(longlong *)(&stack0x00000408 + lVar19) = lVar23;
    }
    uVar20 = *(undefined8 *)(lVar23 + 1000);
    *(undefined8 *)(&stack0x000007c8 + lVar19) = uVar20;
    uVar26 = *(undefined8 *)(*(longlong *)(param_1 + 0x328) + 0x290);
    *(undefined8 *)(&stack0x000007d0 + lVar19) = uVar26;
    pcVar7 = *_DAT_;
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1004c7;
    plVar21 = (longlong *)(*pcVar7)(uVar20,uVar26,0x1244898,0xcf5);
    *(longlong **)(&stack0x000007d8 + lVar19) = plVar21;
    plVar22 = *(longlong **)(&stack0x00000410 + lVar19);
    if (plVar21 != (longlong *)0x0) {
      plVar22 = plVar38;
    }
    *(longlong **)(&stack0x00000410 + lVar19) = plVar22;
    *(longlong **)(&stack0x00000418 + lVar19) = plVar21;
    lVar23 = *plVar21;
    pcVar7 = *(code **)(**(longlong **)(*(longlong *)(&stack0x000000d0 + lVar19) + 0x68) + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100506;
    uVar14 = (*pcVar7)();
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar19) = 0;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar19) = 0;
    pcVar7 = *(code **)(lVar23 + 0x38);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10051f;
    plVar22 = (longlong *)(*pcVar7)(plVar21,uVar14,0,0);
    *(longlong **)(&stack0x000007e0 + lVar19) = plVar22;
    lVar23 = *plVar22;
    pcVar7 = *(code **)(**(longlong **)(*(longlong *)(&stack0x000000d0 + lVar19) + 0x68) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10053f;
    uVar16 = (*pcVar7)();
    *(undefined4 *)((longlong)&uStackX_20 + lVar19 + -0x20) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar19) = 0;
    (&stack0xfffffffffffffff0)[lVar19] = 1;
    (&stack0xffffffffffffffe8)[lVar19] = 0;
    pcVar7 = *(code **)(lVar23 + 0x78);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100561;
    plVar22 = (longlong *)(*pcVar7)(plVar22,uVar16,1,0);
    *(longlong **)(&stack0x000007e8 + lVar19) = plVar22;
    pcVar7 = *(code **)(*plVar22 + 0x78);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100572;
    plVar22 = (longlong *)(*pcVar7)(plVar22);
    *(longlong **)(&stack0x000007f0 + lVar19) = plVar22;
    pcVar7 = *(code **)(*plVar22 + 0x3f8);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100586;
    iVar17 = (*pcVar7)(plVar22);
    if (iVar17 == 2) {
      (&stack0x00000280)[lVar19] = (&stack0x00000280)[lVar19] | 1;
    }
    *(longlong **)(&stack0x000007f8 + lVar19) = plVar21;
    pcVar7 = *(code **)*plVar21;
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1005a8;
    (*pcVar7)(plVar21,1);
  }
  *(longlong *)(&stack0x00000800 + lVar19) = *(longlong *)(&stack0x000002c0 + lVar19);
  uVar20 = *(undefined8 *)(*(longlong *)(&stack0x000002c0 + lVar19) + 0x160);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1005c7;
  lVar23 = func_0x(uVar20,(ulonglong)uVar29);
  *(longlong *)(&stack0x00000808 + lVar19) = lVar23;
  *(longlong *)(&stack0x00000830 + lVar19) = *(longlong *)(&stack0x000002c0 + lVar19);
  uVar20 = *(undefined8 *)(*(longlong *)(&stack0x000002c0 + lVar19) + 0x160);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1005f1;
  uVar20 = func_0x(uVar20,uVar35);
  *(undefined8 *)(&stack0x00000838 + lVar19) = uVar20;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10060c;
  func_0x(lVar23,&stack0x00000120 + lVar19);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10061c;
  func_0x(uVar20,&stack0x000000d8 + lVar19);
  bVar2 = (&stack0x00000120)[lVar19];
  (&stack0x000000a1)[lVar19] = bVar2;
  sVar15 = *(short *)(&stack0x00000130 + lVar19);
  if ((sVar15 == -1) ||
     (bVar3 = *(byte *)((ulonglong)bVar2 + 0xf88c80), (&stack0x000000a2)[lVar19] = bVar3,
     *(char *)((ulonglong)bVar3 + 0x193e2f8) != '\0')) {
    uVar31 = 0x1fa4;
  }
  else {
    uVar31 = 0x1f9e;
    if (*(ushort *)(lVar23 + 0x38) < 0x1f9f) {
      uVar31 = *(ushort *)(lVar23 + 0x38);
    }
  }
  *(ushort *)(&stack0x00000184 + lVar19) = uVar31;
  *(undefined4 *)(&stack0x00000170 + lVar19) = 0x1fa4;
  *(undefined4 *)(&stack0x00000490 + lVar19) = 0;
  *(undefined **)(&stack0x00000498 + lVar19) = &stack0x00000170 + lVar19;
  *(undefined **)(&stack0x00000840 + lVar19) = &stack0x00000f78 + lVar19;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1006cc;
  func_0x(&stack0x000004b8 + lVar19,0,0xb0);
  *(undefined **)(&stack0x00000398 + lVar19) = &stack0x000004b8 + lVar19;
  *(undefined **)(&stack0x000000c8 + lVar19) = &stack0x00000f78 + lVar19;
  uVar13 = *(undefined *)(lVar23 + 0x34);
  (&stack0x00000050)[lVar19] = uVar13;
  *(undefined2 *)(&stack0x00000f7a + lVar19) = 0;
  (&stack0x00000f78)[lVar19] = 3;
  (&stack0x00000f79)[lVar19] = uVar13;
  *(undefined **)(&stack0x00000848 + lVar19) = &stack0x00000f80 + lVar19;
  *(undefined8 *)(&stack0x00000f80 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000f88 + lVar19) = 0;
  *(undefined4 *)(&stack0x00000f90 + lVar19) = 0;
  *(ulonglong *)(&stack0x000004b8 + lVar19) = (ulonglong)uVar29;
  *(undefined8 *)(&stack0x000004d0 + lVar19) = 0;
  uVar6 = *(uint *)(&stack0x000004f0 + lVar19);
  *(uint *)(&stack0x000004f0 + lVar19) = uVar6 | 4;
  *(undefined8 *)(&stack0x000004c0 + lVar19) = 8;
  bVar2 = *(byte *)((ulonglong)bVar2 + 0xf88c80);
  uVar30 = (ulonglong)bVar2;
  (&stack0x00000058)[lVar19] = bVar2;
  cVar12 = *(char *)(uVar30 + 0xf89fd0);
  (&stack0x00000059)[lVar19] = cVar12;
  lVar33 = 8;
  lVar23 = 8;
  if (cVar12 != '\0') {
    *(undefined8 *)(&stack0x000004c0 + lVar19) = 0xb;
    lVar33 = 0xb;
    lVar23 = 0xb;
  }
  *(uint *)(&stack0x000004f0 + lVar19) = uVar6 | 5;
  *(ulonglong *)(&stack0x00000500 + lVar19) = (ulonglong)uVar31;
  (&stack0x0000005a)[lVar19] = bVar2;
  cVar12 = *(char *)(uVar30 + 0xf9d0d0);
  (&stack0x0000005b)[lVar19] = cVar12;
  if (cVar12 != '\0') {
    *(undefined8 *)(&stack0x000004c8 + lVar19) = 0x10;
    *(uint *)(&stack0x000004f0 + lVar19) = uVar6 | 7;
    *(ushort *)(&stack0x0000050c + lVar19) = *(ushort *)(&stack0x0000050c + lVar19) & 0xbfff;
    *(undefined **)(&stack0x00000f80 + lVar19) = &stack0x00000fb8 + lVar19;
    lVar33 = 0x40;
    *(undefined8 *)(&stack0x000004c0 + lVar19) = 0x40;
    lVar23 = 0x40;
  }
  if ((sVar15 == -1) ||
     ((&stack0x0000005c)[lVar19] = bVar2, lVar23 = lVar33, *(char *)(uVar30 + 0x193e2f8) != '\0')) {
    *(undefined2 *)(&stack0x0000050c + lVar19) = 0x800;
    *(longlong *)(&stack0x000004c0 + lVar19) = lVar23 + -4;
    *(undefined **)(&stack0x000004e8 + lVar19) = &stack0x00000490 + lVar19;
  }
  *(undefined **)(&stack0x00000368 + lVar19) = &stack0x00000f98 + lVar19;
  *(undefined2 *)(&stack0x00000f9a + lVar19) = 0;
  (&stack0x00000f98)[lVar19] = 3;
  (&stack0x00000f99)[lVar19] = 0x7f;
  *(undefined **)(&stack0x00000850 + lVar19) = &stack0x00000fa0 + lVar19;
  *(undefined8 *)(&stack0x00000fa0 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000fa8 + lVar19) = 0;
  *(undefined4 *)(&stack0x00000fb0 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000510 + lVar19) = 0;
  *(undefined8 *)(&stack0x00000518 + lVar19) = 0x28;
  *(undefined8 *)(&stack0x00000528 + lVar19) = 0x20;
  *(undefined8 *)(&stack0x00000558 + lVar19) = 8;
  *(undefined4 *)(&stack0x00000548 + lVar19) = 5;
  *(undefined **)(&stack0x00000568 + lVar19) = &stack0x00000f18 + lVar19;
  *(undefined **)(&stack0x00000570 + lVar19) = &stack0x00000eb8 + lVar19;
  *(undefined4 *)(&stack0x00000378 + lVar19) = 0xd4b;
  (&stack0xffffffffffffffe8)[lVar19] = 5;
  plVar22 = *(longlong **)(&stack0x000000d0 + lVar19);
  lVar23 = plVar22[1];
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100947;
  lVar23 = (*_DAT_)(0x1fb8,lVar23,0x1244898,0xd4b);
  *(longlong *)(&stack0x00000578 + lVar19) = lVar23;
  plVar21 = plVar38;
  if (lVar23 != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100961;
    plVar21 = (longlong *)func_0x(lVar23,0,0);
  }
  *(longlong **)(&stack0x00000580 + lVar19) = plVar21;
  *(longlong **)(&stack0x000003b8 + lVar19) = plVar21;
  *(undefined4 *)(&stack0x000000a4 + lVar19) = 0x60;
  *(undefined **)(&stack0xffffffffffffffe8 + lVar19) = &stack0x000000a4 + lVar19;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1009a3;
  func_0x(plVar21,0,0,&stack0x00000eb8 + lVar19);
  (&stack0xffffffffffffffe8)[lVar19] = 5;
  lVar23 = plVar22[1];
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1009c5;
  puVar24 = (uint *)(*_DAT_)(8,lVar23,0x1244898,0xd4f);
  *(uint **)(&stack0x00000588 + lVar19) = puVar24;
  *(uint **)(&stack0x000003b0 + lVar19) = puVar24;
  *puVar24 = uVar29;
  puVar24[1] = 0;
  *(undefined8 *)(&stack0x00000b98 + lVar19) = 0xf89880;
  *(undefined8 *)(&stack0x00000b98 + lVar19) = 0xf88328;
  lVar23 = *(longlong *)(&stack0x00000098 + lVar19);
  uVar35 = *(undefined4 *)(lVar23 + 0x38);
  *(undefined4 *)(&stack0x000003c8 + lVar19) = uVar35;
  *(undefined4 *)(&stack0x00000ba0 + lVar19) = uVar35;
  *(undefined4 *)(&stack0x00000ba4 + lVar19) = 0;
  uVar29 = *(uint *)(&stack0x00000ba8 + lVar19);
  *(uint *)(&stack0x00000ba8 + lVar19) = uVar29 & 0xfffffffe;
  *(uint *)(&stack0x00000ba8 + lVar19) = uVar29 & 0xfffffffc;
  *(uint *)(&stack0x00000ba8 + lVar19) = uVar29 & 0xfffffff8;
  *(uint *)(&stack0x00000ba8 + lVar19) = uVar29 & 0xfffffff0;
  *(uint *)(&stack0x00000ba8 + lVar19) = uVar29 & 0xffffffe0;
  *(undefined2 *)(&stack0x00000bac + lVar19) = 0;
  *(undefined2 *)(&stack0x00000cae + lVar19) = 0;
  *(undefined2 *)(&stack0x00000db0 + lVar19) = 0;
  (&stack0x00000030)[lVar19] = 0;
  (&stack0x00000028)[lVar19] = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar19) = 0;
  auStackX_18[lVar19] = 0;
  *(undefined *)((longlong)&uStackX_10 + lVar19) = 0;
  *(undefined8 *)((longlong)&uStackX_8 + lVar19) = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar19 + -0x20) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar19) = 0;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar19) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar19) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100abe;
  func_0x(&stack0x00000a68 + lVar19,0,0,&stack0x00000b98 + lVar19);
  *(uint **)(&stack0x00000590 + lVar19) = puVar24;
  *(uint **)(&stack0x00000aa8 + lVar19) = puVar24;
  *(undefined2 *)(&stack0x00000ab0 + lVar19) = 2;
  *(undefined8 *)(&stack0x00000158 + lVar19) = 0;
  uVar29 = *(uint *)(&stack0x0000020c + lVar19);
  *(uint *)(&stack0x0000020c + lVar19) = uVar29 | 0x4000;
  *(uint *)(&stack0x0000020c + lVar19) = uVar29 | 0x204000;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100b1b;
  cVar12 = func_0x(&stack0x00000430 + lVar19,lVar32,0,&stack0x000001d0 + lVar19);
  if (cVar12 != '\0') {
    uVar20 = *(undefined8 *)(plVar22[0xf] + 0x30);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100b31;
    cVar12 = func_0x(uVar20);
    if (cVar12 == '\0') {
      lVar33 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00000598 + lVar19) = lVar33;
      lVar34 = (ulonglong)*_DAT_ + *(longlong *)(lVar33 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x000005a0 + lVar19) = lVar34;
      lVar33 = *(longlong *)(lVar34 + 0x100);
      *(longlong *)(&stack0x00000358 + lVar19) = lVar33;
      if (lVar33 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100b82;
        (*_DAT_)();
        lVar33 = *(longlong *)(lVar34 + 0x100);
        *(longlong *)(&stack0x00000358 + lVar19) = lVar33;
      }
      uVar20 = *(undefined8 *)(lVar33 + 1000);
      *(undefined8 *)(&stack0x000005a8 + lVar19) = uVar20;
      (&stack0x00000028)[lVar19] = 0;
      *(undefined *)((longlong)&uStackX_20 + lVar19) = 0;
      auStackX_18[lVar19] = 0;
      *(undefined *)((longlong)&uStackX_10 + lVar19) = 0;
      *(undefined8 *)((longlong)&uStackX_8 + lVar19) = 0;
      *(undefined8 *)((longlong)&uStackX_20 + lVar19 + -0x20) = 0;
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar19) = 0;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar19) = 2;
      (&stack0xffffffffffffffe8)[lVar19] = 0;
      uVar35 = *(undefined4 *)(lVar23 + 0x38);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100be1;
      lVar23 = func_0x(uVar20,uVar35,*(undefined8 *)(&stack0x000001d0 + lVar19));
      *(longlong *)(&stack0x000005b0 + lVar19) = lVar23;
      plVar21 = *(longlong **)(&stack0x00000360 + lVar19);
      if (lVar23 != 0) {
        plVar21 = plVar38;
      }
      *(longlong **)(&stack0x00000360 + lVar19) = plVar21;
      *(longlong *)(&stack0x00000118 + lVar19) = lVar23;
    }
    (&stack0x00000039)[lVar19] = 1;
  }
  lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
  *(longlong *)(&stack0x000005b8 + lVar19) = lVar23;
  puVar25 = (undefined8 *)
            ((ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8));
  *(undefined8 **)(&stack0x000005c0 + lVar19) = puVar25;
  uVar20 = *puVar25;
  *(undefined8 *)(&stack0x000005c8 + lVar19) = uVar20;
  *(undefined8 *)(&stack0x000001d8 + lVar19) = uVar20;
  *(undefined8 *)((longlong)&uStackX_10 + lVar19) = uVar20;
  *(undefined4 *)((longlong)&uStackX_8 + lVar19) = 0;
  *(undefined **)((longlong)&uStackX_20 + lVar19 + -0x20) = &stack0x00000a68 + lVar19;
  *(undefined **)(&stack0xfffffffffffffff8 + lVar19) = &stack0x00000208 + lVar19;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar19) = 0;
  *(undefined **)(&stack0xffffffffffffffe8 + lVar19) = &stack0x00000158 + lVar19;
  lVar23 = plVar22[0xf];
  lVar33 = plVar22[1];
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100c9f;
  iVar17 = func_0x(&stack0x000008b8 + lVar19,lVar32,lVar33,lVar23);
  *(int *)(&stack0x0000003c + lVar19) = iVar17;
  if (iVar17 < 0) {
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar19) = *(undefined4 *)(&stack0x0000003c + lVar19);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100cca;
    (*_DAT_)(0x161,0x44,0x11,0xb);
  }
  lVar23 = *(longlong *)(&stack0x00000158 + lVar19);
  *(longlong *)(&stack0x000005d0 + lVar19) = lVar23;
  *(undefined8 *)(&stack0x00000158 + lVar19) = 0;
  *(longlong *)(&stack0x00000090 + lVar19) = lVar23;
  lVar32 = *(longlong *)(lVar23 + 8);
  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar19) = 0;
  *(undefined **)(&stack0xfffffffffffffff0 + lVar19) = &stack0x00000110 + lVar19;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar19) = 0;
  pcVar7 = *(code **)(lVar32 + 0x20);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100d18;
  iVar17 = (*pcVar7)((longlong *)(lVar23 + 8),2,2,&stack0x000004b8 + lVar19);
  *(int *)(&stack0x0000003c + lVar19) = iVar17;
  if (iVar17 < 0) {
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar19) = *(undefined4 *)(&stack0x0000003c + lVar19);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100d43;
    (*_DAT_)(0x161,0x44,0x11,0xc);
  }
  *(longlong **)(&stack0x000005d8 + lVar19) = plVar22 + 0x25;
  *(longlong *)(&stack0x000001d8 + lVar19) = plVar22[0xe];
  if (plVar22[0x16] == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100d73;
    func_0x(plVar22);
  }
  *(undefined *)(plVar22 + 0x45) = 1;
  iVar17 = -1;
  *(undefined4 *)(&stack0x00000048 + lVar19) = 0xffffffff;
  *(undefined (*) [16])(&stack0x000001e8 + lVar19) = ZEXT816(0);
  (&stack0x000001f8)[lVar19] = (&stack0x000001f8)[lVar19] & 0xfe;
  lVar23 = plVar22[100];
  *(longlong *)(&stack0x000005e0 + lVar19) = lVar23;
  lVar32 = plVar22[0x65];
  *(longlong *)(&stack0x000005e8 + lVar19) = lVar32;
  *(longlong *)(&stack0x000001f0 + lVar19) = lVar23;
  *(longlong *)(&stack0x000001e8 + lVar19) = lVar32;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100dd7;
  func_0x(&stack0x00000858 + lVar19);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100de5;
  func_0x(&stack0x000009a8 + lVar19);
  bVar2 = *(byte *)((ulonglong)(byte)(&stack0x00000120)[lVar19] + 0xf88c80);
  (&stack0x0000005d)[lVar19] = bVar2;
  cVar12 = *(char *)((ulonglong)bVar2 + 0xf89fd0);
  (&stack0x0000005e)[lVar19] = cVar12;
  if ((cVar12 != '\0') ||
     ((&stack0x0000005f)[lVar19] = bVar2, *(char *)((ulonglong)bVar2 + 0xf9d270) != '\0')) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100e3f;
    func_0x(&stack0x00000f78 + lVar19,&stack0x00000120 + lVar19);
  }
  while( true ) {
    *(undefined4 *)(&stack0x00000044 + lVar19) = 0xffffffff;
    lVar23 = *(longlong *)(*(longlong *)(&stack0x00000090 + lVar19) + 0x28);
    *(undefined **)(&stack0xfffffffffffffff0 + lVar19) = &stack0x00000f78 + lVar19;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar19) = *(undefined8 *)(&stack0x00000110 + lVar19);
    pcVar7 = *(code **)(lVar23 + 0x18);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100e89;
    iVar18 = (*pcVar7)((longlong *)(*(longlong *)(&stack0x00000090 + lVar19) + 0x28),0,1,0);
    *(int *)(&stack0x0000003c + lVar19) = iVar18;
    if (iVar18 < 0) {
      iVar18 = *(int *)(&stack0x0000003c + lVar19);
      *(int *)(&stack0xffffffffffffffe8 + lVar19) = iVar18;
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100eb6;
      (*_DAT_)(0x161,0x44,0x11,0xe);
      iVar17 = *(int *)(&stack0x00000048 + lVar19);
    }
    if (iVar18 == 0) {
      uVar20 = *(undefined8 *)(*(longlong *)(&stack0x00000368 + lVar19) + 8);
      *(undefined8 *)(&stack0x000005f0 + lVar19) = uVar20;
      *(int *)(&stack0x00000044 + lVar19) = (int)((ulonglong)uVar20 >> 0x20);
      *(int *)(&stack0x00000100 + lVar19) = (int)uVar20;
    }
    if ((*(int *)(&stack0x00000044 + lVar19) != iVar17) || (iVar18 == 0x40ec6)) break;
LAB_:
    if (iVar18 != 0) goto LAB_;
    lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x000006c0 + lVar19) = lVar23;
    lVar23 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x000006c8 + lVar19) = lVar23;
    lVar23 = *(longlong *)(lVar23 + 8);
    *(longlong *)(&stack0x000006d0 + lVar19) = lVar23;
    lVar23 = *(longlong *)(lVar23 + 0x60);
    *(longlong *)(&stack0x000006d8 + lVar19) = lVar23;
    if ((*(byte *)(*(longlong *)(lVar23 + 0x4e8) + 0x70) & 1) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10161b;
      (*_DAT_)(0x161,0x39,0x11,1);
    }
    uVar35 = *(undefined4 *)(*(undefined8 **)(&stack0x000001b8 + lVar19) + 1);
    *(undefined4 *)(&stack0x000003e8 + lVar19) = uVar35;
    uVar20 = **(undefined8 **)(&stack0x000001b8 + lVar19);
    *(undefined8 *)(&stack0x000006e0 + lVar19) = uVar20;
    *(undefined8 *)(&stack0x000004a0 + lVar19) = uVar20;
    *(undefined4 *)(&stack0x000004a8 + lVar19) = uVar35;
    lVar23 = *(longlong *)(&stack0x00000098 + lVar19);
    puVar25 = *(undefined8 **)(*(longlong *)(lVar23 + 8) + 0xe8);
    uVar35 = *(undefined4 *)(puVar25 + 1);
    *(undefined4 *)(&stack0x000003f8 + lVar19) = uVar35;
    uVar20 = *puVar25;
    *(undefined8 *)(&stack0x000007b8 + lVar19) = uVar20;
    *(undefined8 *)(&stack0x00000420 + lVar19) = uVar20;
    *(undefined4 *)(&stack0x00000428 + lVar19) = uVar35;
    *(undefined8 *)(&stack0x00000108 + lVar19) = 0;
    *(undefined8 *)(&stack0x00000148 + lVar19) = 0;
    *(undefined2 *)(&stack0x000000aa + lVar19) = 0;
    (&stack0x000000a8)[lVar19] = 3;
    (&stack0x000000a9)[lVar19] = 0;
    *(undefined **)(&stack0x000006f0 + lVar19) = &stack0x000000b0 + lVar19;
    *(undefined8 *)(&stack0x000000b0 + lVar19) = 0;
    *(undefined8 *)(&stack0x000000b8 + lVar19) = 0;
    *(undefined4 *)(&stack0x000000c0 + lVar19) = 0;
    lVar32 = *(longlong *)(lVar23 + 8);
    uVar14 = *(undefined2 *)(lVar32 + 8);
    *(undefined2 *)(&stack0x00000168 + lVar19) = uVar14;
    bVar39 = *(char *)(lVar23 + 0x4d) == '\0';
    (&stack0x00000068)[lVar19] = bVar39;
    bVar40 = *(char *)(lVar32 + 0x17) != '\0';
    (&stack0x00000070)[lVar19] = bVar40;
    *(undefined4 *)(&stack0x00000450 + lVar19) = 1;
    *(undefined **)(&stack0x00000458 + lVar19) = &stack0x00000120 + lVar19;
    *(undefined **)(&stack0x00000460 + lVar19) = &stack0x000000d8 + lVar19;
    *(undefined **)(&stack0x00000468 + lVar19) = &stack0x000004a0 + lVar19;
    *(undefined **)(&stack0x00000470 + lVar19) = &stack0x00000420 + lVar19;
    (&stack0x00000478)[lVar19] = bVar40;
    (&stack0x00000479)[lVar19] = bVar39;
    *(undefined2 *)(&stack0x0000047a + lVar19) = uVar14;
    (&stack0x00000040)[lVar19] = 0;
    plVar21 = plVar38;
    if ((&stack0x00000039)[lVar19] == '\0') {
LAB_:
      if (((*(short *)(&stack0x00000130 + lVar19) == -1) ||
          (bVar2 = *(byte *)((ulonglong)(byte)(&stack0x00000120)[lVar19] + 0xf88c80),
          (&stack0x00000086)[lVar19] = bVar2, *(char *)((ulonglong)bVar2 + 0x193e2f8) != '\0')) &&
         (pcVar9 = *(char **)(&stack0x000000c8 + lVar19), *pcVar9 != '\x03')) {
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar19) =
             *(undefined8 *)(&stack0x00000090 + lVar19);
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar19) = 0;
        lVar23 = plVar22[0xe];
        lVar32 = plVar22[1];
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101a35;
        plVar21 = (longlong *)
                  func_0x(lVar32,lVar23,*(undefined8 *)(&stack0x00000110 + lVar19),
                                  &stack0x00000f78 + lVar19);
        *(longlong **)(&stack0x00000700 + lVar19) = plVar21;
        *(longlong **)(&stack0x00000148 + lVar19) = plVar21;
        *(undefined4 *)(&stack0x000000a4 + lVar19) = 0x60;
        *(undefined **)(&stack0xffffffffffffffe8 + lVar19) = &stack0x000000a4 + lVar19;
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101a75;
        func_0x(plVar21,0,0,&stack0x00000f18 + lVar19);
        *(undefined **)(pcVar9 + 8) = &stack0x00000f18 + lVar19;
      }
      lVar23 = plVar22[1];
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101aa3;
      pbVar28 = (byte *)func_0x
                                  (*(undefined8 *)(&stack0x000000c8 + lVar19),
                                   &stack0x000000a8 + lVar19,&stack0x00000450 + lVar19,lVar23);
      *(byte **)(&stack0x00000108 + lVar19) = pbVar28;
    }
    else {
      uVar20 = *(undefined8 *)(plVar22[0xf] + 0x30);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10177b;
      cVar12 = func_0x(uVar20);
      if (cVar12 == '\0') {
        pcVar7 = *(code **)(**(longlong **)(&stack0x00000118 + lVar19) + 0x18);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10184a;
        cVar12 = (*pcVar7)(*(longlong **)(&stack0x00000118 + lVar19),
                           *(undefined4 *)(&stack0x00000044 + lVar19),
                           *(undefined4 *)(&stack0x00000100 + lVar19));
      }
      else {
        plVar27 = *(longlong **)(&stack0x000002a8 + lVar19);
        if (plVar27 == (longlong *)0x0) {
          plVar27 = *(longlong **)(*(longlong *)(&stack0x00000298 + lVar19) + 0x10);
        }
        *(longlong **)(&stack0x000003a0 + lVar19) = plVar27;
        pcVar7 = *(code **)(*plVar27 + 0x28);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1017b1;
        cVar12 = (*pcVar7)(plVar27,*(undefined4 *)(&stack0x00000100 + lVar19));
      }
      (&stack0x00000040)[lVar19] = cVar12;
      if (cVar12 == '\0') goto LAB_;
      bVar2 = (&stack0x000000d8)[lVar19];
      (&stack0x00000078)[lVar19] = bVar2;
      *(undefined2 *)(&stack0x0000019a + lVar19) = 0;
      (&stack0x00000198)[lVar19] = 3;
      (&stack0x00000199)[lVar19] = bVar2;
      *(undefined **)(&stack0x000006f8 + lVar19) = &stack0x000001a0 + lVar19;
      *(undefined8 *)(&stack0x000001a0 + lVar19) = 0;
      *(undefined8 *)(&stack0x000001a8 + lVar19) = 0;
      *(undefined4 *)(&stack0x000001b0 + lVar19) = 0;
      bVar3 = *(byte *)((ulonglong)bVar2 + 0xf88c80);
      uVar30 = (ulonglong)bVar3;
      (&stack0x00000080)[lVar19] = bVar3;
      cVar12 = *(char *)(uVar30 + 0xf89fd0);
      (&stack0x00000081)[lVar19] = cVar12;
      if (cVar12 != '\0') {
        if ((byte)(bVar2 + 0x10) < 2) {
          (&stack0x00000082)[lVar19] = bVar3;
          uVar13 = *(undefined *)(uVar30 * 4 + 0xf89ec2);
        }
        else {
          uVar13 = (&stack0x000000ea)[lVar19];
        }
        (&stack0x00000041)[lVar19] = uVar13;
        (&stack0x000001a1)[lVar19] = uVar13;
        if ((byte)(bVar2 + 0x10) < 2) {
          (&stack0x00000083)[lVar19] = bVar3;
          uVar13 = *(undefined *)(uVar30 * 4 + 0xf89ec3);
        }
        else {
          uVar13 = (&stack0x000000eb)[lVar19];
        }
        (&stack0x00000042)[lVar19] = uVar13;
        (&stack0x000001a2)[lVar19] = uVar13;
      }
      (&stack0x00000084)[lVar19] = bVar3;
      if (*(char *)(uVar30 + 0xfa0b50) != '\0') {
        *(undefined2 *)(&stack0x0000019a + lVar19) = 1;
      }
      if (bVar40) {
        pbVar28 = &stack0x00000198 + lVar19;
        *(byte **)(&stack0x00000108 + lVar19) = pbVar28;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101966;
        (*_DAT_)(&stack0x00000198 + lVar19,0);
        pbVar28 = &stack0x00000198 + lVar19;
        *(byte **)(&stack0x00000108 + lVar19) = pbVar28;
        if ((*(short *)(&stack0x000000e8 + lVar19) == -1) ||
           (bVar2 = *(byte *)((ulonglong)(byte)(&stack0x000000d8)[lVar19] + 0xf88c80),
           (&stack0x00000085)[lVar19] = bVar2, *(char *)((ulonglong)bVar2 + 0x193e2f8) != '\0')) {
          *(undefined **)(&stack0x000001a0 + lVar19) = &stack0x00000eb8 + lVar19;
          plVar21 = (longlong *)0x0;
        }
      }
    }
    *(undefined8 *)(&stack0x00000150 + lVar19) = 0;
    plVar27 = plVar38;
    if (((*(short *)(&stack0x000000e8 + lVar19) == -1) ||
        (bVar2 = *(byte *)((ulonglong)(byte)(&stack0x000000d8)[lVar19] + 0xf88c80),
        (&stack0x00000087)[lVar19] = bVar2, *(char *)((ulonglong)bVar2 + 0x193e2f8) != '\0')) &&
       (*pbVar28 != 3)) {
      plVar27 = *(longlong **)(pbVar28 + 8);
      pcVar7 = *(code **)(*plVar27 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101afc;
      plVar27 = (longlong *)(*pcVar7)(plVar27,0);
      *(longlong **)(&stack0x00000708 + lVar19) = plVar27;
      *(longlong **)(&stack0x00000150 + lVar19) = plVar27;
      bVar2 = *pbVar28;
      *(uint *)(&stack0x000003f0 + lVar19) = (uint)bVar2;
      (&stack0x00000810)[lVar19] = bVar2;
      *(longlong **)(&stack0x00000818 + lVar19) = plVar27;
      *(undefined8 *)(&stack0x00000820 + lVar19) = 8;
      pbVar28 = &stack0x00000810 + lVar19;
      *(byte **)(&stack0x00000108 + lVar19) = pbVar28;
    }
    *(undefined4 *)(&stack0x0000030c + lVar19) = 0;
    *(undefined8 *)(&stack0x00000320 + lVar19) = 0;
    *(undefined4 *)(&stack0x00000328 + lVar19) = 0;
    plVar37 = *(longlong **)(&stack0x00000188 + lVar19);
    if (plVar37 != (longlong *)0x0) {
      *(longlong **)(&stack0x00000710 + lVar19) = plVar37;
      puVar25 = (undefined8 *)plVar22[0xe];
      *(undefined8 **)(&stack0x00000718 + lVar19) = puVar25;
      iVar17 = *(int *)(puVar25 + 5);
      *(int *)(&stack0x000000d0 + lVar19) = iVar17;
      if ((iVar17 == *(int *)(plVar37 + 1)) &&
         (*(uint6 **)(&stack0x000001e0 + lVar19) = (uint6 *)((longlong)puVar25 + 0x14),
         *plVar37 == (ulonglong)*(uint6 *)((longlong)puVar25 + 0x14) * 0x10000)) {
        pcVar7 = *(code **)*puVar25;
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101bbd;
        sVar15 = (*pcVar7)(puVar25);
        plVar37 = *(longlong **)(&stack0x00000188 + lVar19);
        if (*(short *)((longlong)plVar37 + 0xc) != sVar15) goto LAB_;
        if (plVar37[0x15] != 0) {
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar19) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar19);
          UNLOCK();
          pbVar28 = *(byte **)(&stack0x00000108 + lVar19);
          plVar21 = *(longlong **)(&stack0x00000148 + lVar19);
          plVar27 = *(longlong **)(&stack0x00000150 + lVar19);
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101c00;
        func_0x(plVar37,puVar25);
        plVar37 = *(longlong **)(&stack0x00000188 + lVar19);
      }
      lVar23 = plVar22[0xe];
      uVar5 = *(ushort *)((longlong)plVar37 + 0x62);
      uVar31 = *(ushort *)(plVar37 + 7);
      *(longlong **)(&stack0x000002f8 + lVar19) = plVar37;
      *(uint *)(&stack0x00000308 + lVar19) = (uint)uVar5;
      *(byte **)(&stack0x00000310 + lVar19) = pbVar28;
      *(undefined8 *)(&stack0x00000318 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000350 + lVar19) = 0;
      *(longlong *)(&stack0x00000300 + lVar19) = plVar37[0xe];
      if ((uVar31 & 0x400) == 0) {
        *(uint *)(&stack0x00000400 + lVar19) = (uint)uVar5;
        *(longlong *)(&stack0x00000728 + lVar19) = lVar23;
        if (lVar23 != 0) {
          lVar23 = *(longlong *)(lVar23 + 8);
          *(longlong *)(&stack0x00000730 + lVar19) = lVar23;
          plVar37 = *(longlong **)(lVar23 + 0x160);
          *(longlong **)(&stack0x00000738 + lVar19) = plVar37;
          lVar23 = *plVar37;
          *(longlong *)(&stack0x00000740 + lVar19) = lVar23;
          *(undefined8 *)(&stack0x00000320 + lVar19) = *(undefined8 *)(lVar23 + 0xa8);
          *(undefined4 *)(&stack0x00000328 + lVar19) = *(undefined4 *)(lVar23 + 0xb0);
        }
        *(uint *)(&stack0x0000030c + lVar19) = *(uint *)(&stack0x0000030c + lVar19) | 0x10;
      }
      else {
        *(uint *)(&stack0x000003e0 + lVar19) = (uint)uVar5;
        *(longlong *)(&stack0x00000748 + lVar19) = lVar23;
        if (lVar23 != 0) {
          lVar23 = *(longlong *)(lVar23 + 8);
          *(longlong *)(&stack0x00000750 + lVar19) = lVar23;
          plVar37 = *(longlong **)(lVar23 + 0x160);
          *(longlong **)(&stack0x00000758 + lVar19) = plVar37;
          lVar23 = *plVar37;
          *(longlong *)(&stack0x00000760 + lVar19) = lVar23;
          *(undefined8 *)(&stack0x00000320 + lVar19) = *(undefined8 *)(lVar23 + 0xa8);
          *(undefined4 *)(&stack0x00000328 + lVar19) = *(undefined4 *)(lVar23 + 0xb0);
        }
        uVar29 = *(uint *)(&stack0x0000030c + lVar19);
        *(uint *)(&stack0x0000030c + lVar19) = uVar29 | 0x10;
        if (pbVar28 != (byte *)0x0) {
          *(uint *)(&stack0x00000308 + lVar19) = (uint)uVar5;
          *(undefined8 *)(&stack0x00000330 + lVar19) = 0;
          *(undefined4 *)(&stack0x00000340 + lVar19) = 0;
          *(undefined8 *)(&stack0x00000338 + lVar19) = 0;
          *(undefined4 *)(&stack0x00000344 + lVar19) = 0;
          if ((uVar29 & 4) == 0) {
            *(uint *)(&stack0x0000030c + lVar19) = uVar29 | 0x12;
          }
        }
      }
    }
    lVar23 = plVar22[0x15];
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101d74;
    iVar17 = func_0x(lVar23);
    *(int *)(&stack0x00000190 + lVar19) = iVar17;
    if (iVar17 == -0x3efffffd) {
      uVar26 = 0x20;
      uVar20 = 0xe0;
      uVar35 = 0x10;
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101ded;
      (*_DAT_)(uVar20,uVar26,uVar35);
LAB_:
      lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00000768 + lVar19) = lVar23;
      lVar32 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00000770 + lVar19) = lVar32;
      lVar23 = *(longlong *)(lVar32 + 0x100);
      *(longlong *)(&stack0x000003a8 + lVar19) = lVar23;
      if (lVar23 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101e38;
        (*_DAT_)(0);
        lVar23 = *(longlong *)(lVar32 + 0x100);
        *(longlong *)(&stack0x000003a8 + lVar19) = lVar23;
      }
      lVar23 = *(longlong *)(lVar23 + 600);
      *(longlong *)(&stack0x00000778 + lVar19) = lVar23;
      puVar24 = (uint *)(lVar23 + 0xbc);
      *(uint **)(&stack0x00000780 + lVar19) = puVar24;
      uVar29 = *puVar24 >> 2;
      (&stack0x00000088)[lVar19] = (byte)uVar29 & 1;
      if ((uVar29 & 1) == 0) {
code_r0x00101ef7:
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar19) =
             *(undefined4 *)(&stack0x00000190 + lVar19);
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar19) = 0x13afe20;
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101f2b;
        (*_DAT_)(1,0x13afe50,0x13afe78);
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101e7a;
        iVar17 = func_0x();
        if (iVar17 == 0) {
          lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          *(longlong *)(&stack0x00000788 + lVar19) = lVar23;
          plVar21 = (longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8));
          *(longlong **)(&stack0x00000790 + lVar19) = plVar21;
          lVar23 = *plVar21;
          *(longlong *)(&stack0x00000798 + lVar19) = lVar23;
          *(longlong *)(&stack0x000001e0 + lVar19) = lVar23;
          *(longlong *)(&stack0x000007a0 + lVar19) = lVar23;
          if (lVar23 != 0) {
            *(longlong *)(&stack0x000007a8 + lVar19) = lVar23;
            *(longlong *)(&stack0x000001e0 + lVar19) = lVar23;
            if (*(char *)(*(longlong *)(lVar23 + 0x38) + 8) != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101ef0;
              iVar17 = func_0x();
              if (iVar17 == 0) goto LAB_;
            }
          }
          goto code_r0x00101ef7;
        }
      }
LAB_:
      plVar27 = *(longlong **)(&stack0x00000150 + lVar19);
      plVar21 = *(longlong **)(&stack0x00000148 + lVar19);
    }
    else {
      if (iVar17 == -0x3effffdf) {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101dd4;
        func_0x(0x7a);
        goto LAB_;
      }
      if (iVar17 == -0x3effffde) {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101dcb;
        func_0x(0x91);
        goto LAB_;
      }
      if (iVar17 == -0x3effffdd) {
        uVar35 = 0x19;
        uVar26 = 1;
        uVar20 = 0x24;
        goto LAB_;
      }
      if (iVar17 == -0x3efcffff) {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101da5;
        func_0x(0x80);
        goto LAB_;
      }
      if (iVar17 < 0) goto LAB_;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101f43;
    func_0x(plVar22);
    if (plVar27 != (longlong *)0x0) {
      pcVar7 = *(code **)(*plVar27 + 0x10);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101f52;
      (*pcVar7)(plVar27);
    }
    if (((&stack0x000000aa)[lVar19] & 1) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101f72;
      (*_DAT_)(&stack0x000000a8 + lVar19);
      *(undefined2 *)(&stack0x000000aa + lVar19) = 0;
      (&stack0x000000a8)[lVar19] = 3;
      (&stack0x000000a9)[lVar19] = 0;
      *(undefined **)(&stack0x000003d0 + lVar19) = &stack0x000000b0 + lVar19;
      *(undefined8 *)(&stack0x000000b0 + lVar19) = 0;
      *(undefined8 *)(&stack0x000000b8 + lVar19) = 0;
      *(undefined4 *)(&stack0x000000c0 + lVar19) = 0;
    }
    if (plVar21 == (longlong *)0x0) {
      iVar17 = *(int *)(&stack0x00000048 + lVar19);
    }
    else {
      pcVar7 = *(code **)(*plVar21 + 0x10);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101fcd;
      (*pcVar7)(plVar21);
      iVar17 = *(int *)(&stack0x00000048 + lVar19);
    }
  }
  if (iVar17 != -1) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100f0c;
    func_0x(plVar22,iVar17);
    lVar23 = plVar22[0x15];
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100f19;
    iVar17 = func_0x(lVar23);
    *(int *)(&stack0x00000178 + lVar19) = iVar17;
    if (iVar17 == -0x3efffffd) {
      uVar36 = 1;
      uVar26 = 0x20;
      uVar20 = 0xe0;
      uVar35 = 0x10;
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100f92;
      (*_DAT_)(uVar20,uVar26,uVar35,uVar36);
    }
    else if (iVar17 == -0x3effffdf) {
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100f79;
      func_0x(0x7a);
    }
    else if (iVar17 == -0x3effffde) {
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100f70;
      func_0x(0x91);
    }
    else {
      if (iVar17 == -0x3effffdd) {
        uVar36 = 0x2f;
        uVar35 = 0x19;
        uVar26 = 1;
        uVar20 = 0x24;
        goto LAB_;
      }
      if (iVar17 == -0x3efcffff) {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100f4a;
        func_0x(0x80);
      }
      else if (-1 < iVar17) goto LAB_;
    }
    lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x000005f8 + lVar19) = lVar23;
    lVar32 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x00000600 + lVar19) = lVar32;
    lVar23 = *(longlong *)(lVar32 + 0x100);
    *(longlong *)(&stack0x00000370 + lVar19) = lVar23;
    if (lVar23 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100fdd;
      (*_DAT_)(0);
      lVar23 = *(longlong *)(lVar32 + 0x100);
      *(longlong *)(&stack0x00000370 + lVar19) = lVar23;
    }
    lVar23 = *(longlong *)(lVar23 + 600);
    *(longlong *)(&stack0x00000608 + lVar19) = lVar23;
    puVar24 = (uint *)(lVar23 + 0xbc);
    *(uint **)(&stack0x00000610 + lVar19) = puVar24;
    uVar29 = *puVar24 >> 2;
    (&stack0x00000060)[lVar19] = (byte)uVar29 & 1;
    if ((uVar29 & 1) == 0) {
code_r0x0010109c:
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar19) =
           *(undefined4 *)(&stack0x00000178 + lVar19);
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar19) = 0x13afe20;
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1010c9;
      (*_DAT_)(1,0x13afe50,0x13afe78,0x25d);
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10101f;
      iVar17 = func_0x();
      if (iVar17 == 0) {
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00000618 + lVar19) = lVar23;
        plVar21 = (longlong *)
                  ((ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8)
                  );
        *(longlong **)(&stack0x00000620 + lVar19) = plVar21;
        lVar23 = *plVar21;
        *(longlong *)(&stack0x00000628 + lVar19) = lVar23;
        *(longlong *)(&stack0x000000d0 + lVar19) = lVar23;
        *(longlong *)(&stack0x00000630 + lVar19) = lVar23;
        if (lVar23 != 0) {
          *(longlong *)(&stack0x00000638 + lVar19) = lVar23;
          *(longlong *)(&stack0x000000d0 + lVar19) = lVar23;
          if (*(char *)(*(longlong *)(lVar23 + 0x38) + 8) != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101095;
            iVar17 = func_0x();
            if (iVar17 == 0) goto LAB_;
          }
        }
        goto code_r0x0010109c;
      }
    }
LAB_:
    iVar18 = *(int *)(&stack0x0000003c + lVar19);
  }
LAB_:
  (&stack0x00000038)[lVar19] = 0;
  (&stack0x00000061)[lVar19] = DAT_;
  if ((DAT_ == '\0') ||
     ((&stack0x00000062)[lVar19] = DAT_,
     *(longlong *)(*(longlong *)(*(longlong *)(plVar22[0x65] + 0x30) + 0x6b0) + 0x14c8) == 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101555;
    uVar13 = func_0x(&stack0x000001e8 + lVar19);
    (&stack0x00000038)[lVar19] = uVar13;
    lVar23 = *(longlong *)(&stack0x00000098 + lVar19);
LAB_:
    if ((&stack0x00000038)[lVar19] != '\0') {
      if (*(int *)(*(longlong *)(&stack0x00000858 + lVar19) + 0x20) !=
          *(int *)(&stack0x00000044 + lVar19)) {
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar19) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10159f;
        (*_DAT_)(1,0x13c00b8,0x1388ee0,0xe60);
      }
      *(undefined4 *)(&stack0x00000048 + lVar19) = *(undefined4 *)(&stack0x00000044 + lVar19);
      goto LAB_;
    }
  }
  else {
    uVar20 = *(undefined8 *)(&stack0x000001c0 + lVar19);
    while( true ) {
      bVar39 = false;
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101137;
      cVar12 = func_0x(&stack0x000001e8 + lVar19);
      if (cVar12 == '\0') break;
      *(longlong *)(&stack0x00000640 + lVar19) = *(longlong *)(&stack0x00000858 + lVar19);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101160;
      func_0x(&stack0x000009a8 + lVar19,*(longlong *)(&stack0x00000858 + lVar19) + 0x28);
      *(undefined4 *)(&stack0x00000180 + lVar19) =
           *(undefined4 *)(*(longlong *)(&stack0x00000858 + lVar19) + 0x20);
      bVar2 = (&stack0x00000280)[lVar19];
      (&stack0x00000063)[lVar19] = bVar2 & 1;
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10118c;
      uVar26 = func_0x(uVar20);
      *(undefined **)(&stack0xffffffffffffffe8 + lVar19) = &stack0x00000180 + lVar19;
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1011b0;
      cVar12 = func_0x(uVar20,uVar26,&stack0x000009a8 + lVar19,bVar2 & 1);
      (&stack0x00000064)[lVar19] = cVar12;
      if (cVar12 != '\0') {
        lVar23 = plVar22[0x65];
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1011dc;
        cVar12 = func_0x(&stack0x00000858 + lVar19,lVar23,
                                 *(undefined8 *)(&stack0x000001d8 + lVar19));
        if (cVar12 != '\0') {
          (&stack0x00000038)[lVar19] = 1;
          bVar39 = true;
          break;
        }
      }
      (&stack0x00000038)[lVar19] = 0;
    }
    if (bVar39) {
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101200;
      func_0x(&stack0x000008e8 + lVar19);
      *(longlong *)(&stack0x00000648 + lVar19) = *(longlong *)(&stack0x00000858 + lVar19);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101222;
      func_0x(&stack0x000008e8 + lVar19,*(longlong *)(&stack0x00000858 + lVar19) + 0x28);
      psVar8 = *(short **)(&stack0x00000140 + lVar19);
      if (((psVar8 == (short *)0x0) || (*psVar8 != *(short *)(&stack0x00000944 + lVar19))) ||
         (psVar8[1] != *(short *)(&stack0x00000948 + lVar19))) {
        *(undefined4 *)(&stack0x000003d8 + lVar19) = 0xe29;
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00000650 + lVar19) = lVar23;
        lVar32 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00000658 + lVar19) = lVar32;
        lVar23 = *(longlong *)(lVar32 + 0x100);
        *(longlong *)(&stack0x00000380 + lVar19) = lVar23;
        if (lVar23 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1012a4;
          (*_DAT_)(0);
          lVar23 = *(longlong *)(lVar32 + 0x100);
          *(longlong *)(&stack0x00000380 + lVar19) = lVar23;
        }
        uVar20 = *(undefined8 *)(lVar23 + 1000);
        *(undefined8 *)(&stack0x00000660 + lVar19) = uVar20;
        *(undefined8 *)(&stack0x00000668 + lVar19) = uVar20;
        (&stack0xffffffffffffffe8)[lVar19] = 5;
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1012e7;
        plVar27 = (longlong *)(*_DAT_)(4,uVar20,0x1244898,0xe29);
        *(longlong **)(&stack0x00000670 + lVar19) = plVar27;
        plVar21 = plVar38;
        if (plVar27 != (longlong *)0x0) {
          sVar15 = *(short *)(&stack0x00000944 + lVar19);
          if (*(short *)(&stack0x00000946 + lVar19) == sVar15) {
            *(short *)(&stack0x0000008a + lVar19) = sVar15;
          }
          else {
            sVar15 = 0x7fff;
            *(undefined2 *)(&stack0x0000008a + lVar19) = 0x7fff;
          }
          sVar4 = *(short *)(&stack0x00000948 + lVar19);
          *(short *)(&stack0x00000160 + lVar19) = sVar4;
          *(short *)plVar27 = sVar15;
          *(short *)((longlong)plVar27 + 2) = sVar4;
          plVar21 = plVar27;
        }
        *(longlong **)(&stack0x000001c8 + lVar19) = plVar21;
        plVar27 = *(longlong **)(&stack0x00000140 + lVar19);
        if (plVar27 != plVar21) {
          *(longlong **)(&stack0x00000678 + lVar19) = plVar27;
          *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101371;
          (*_DAT_)(plVar27,4);
        }
        *(longlong **)(&stack0x00000140 + lVar19) = plVar21;
        if ((&stack0x00000039)[lVar19] == '\0') {
          iVar18 = *(int *)(&stack0x0000003c + lVar19);
          goto LAB_;
        }
        lVar23 = plVar22[100];
        *(uint6 **)(&stack0x00000680 + lVar19) = (uint6 *)(lVar23 + 0x14);
        *(ulonglong *)(&stack0x00000390 + lVar19) = (ulonglong)*(uint6 *)(lVar23 + 0x14) << 0x10;
        lVar23 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00000688 + lVar19) = lVar23;
        lVar32 = (ulonglong)*_DAT_ + *(longlong *)(lVar23 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00000690 + lVar19) = lVar32;
        lVar23 = *(longlong *)(lVar32 + 0x100);
        *(longlong *)(&stack0x00000388 + lVar19) = lVar23;
        if (lVar23 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1013fa;
          (*_DAT_)();
          lVar23 = *(longlong *)(lVar32 + 0x100);
          *(longlong *)(&stack0x00000388 + lVar19) = lVar23;
        }
        uVar20 = *(undefined8 *)(lVar23 + 1000);
        *(undefined8 *)(&stack0x00000698 + lVar19) = uVar20;
        (&stack0x00000028)[lVar19] = 0;
        *(undefined *)((longlong)&uStackX_20 + lVar19) = 0;
        auStackX_18[lVar19] = 0;
        *(undefined *)((longlong)&uStackX_10 + lVar19) = 0;
        *(undefined8 *)((longlong)&uStackX_8 + lVar19) = *(undefined8 *)(&stack0x00000390 + lVar19);
        *(undefined8 *)((longlong)&uStackX_20 + lVar19 + -0x20) =
             *(undefined8 *)(&stack0x000001c8 + lVar19);
        *(undefined8 *)(&stack0xfffffffffffffff8 + lVar19) = 0;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar19) = 2;
        (&stack0xffffffffffffffe8)[lVar19] = 0;
        lVar32 = plVar22[0xf];
        lVar23 = *(longlong *)(&stack0x00000098 + lVar19);
        uVar35 = *(undefined4 *)(lVar23 + 0x38);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101475;
        plVar27 = (longlong *)
                  func_0x
                            (uVar20,uVar35,*(undefined8 *)(&stack0x000001d0 + lVar19),lVar32);
        *(longlong **)(&stack0x000006a0 + lVar19) = plVar27;
        plVar21 = *(longlong **)(&stack0x00000118 + lVar19);
        if ((plVar21 != plVar27) &&
           (*(longlong **)(&stack0x000006a8 + lVar19) = plVar21, plVar21 != (longlong *)0x0)) {
          pcVar7 = *(code **)(*plVar21 + 0x50);
          *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1014a4;
          (*pcVar7)(plVar21,1);
        }
        *(longlong **)(&stack0x00000118 + lVar19) = plVar27;
        iVar18 = *(int *)(&stack0x0000003c + lVar19);
      }
      else {
LAB_:
        lVar23 = *(longlong *)(&stack0x00000098 + lVar19);
      }
      lVar32 = plVar22[100];
      puVar1 = (uint6 *)(lVar32 + 0x14);
      *(uint6 **)(&stack0x000006b0 + lVar19) = puVar1;
      uVar11 = *puVar1;
      *(undefined *)((longlong)&uStackX_10 + lVar19) = 1;
      *(undefined *)((longlong)&uStackX_8 + lVar19) = 0;
      *(undefined8 *)((longlong)&uStackX_20 + lVar19 + -0x20) = 0;
      *(ulonglong *)(&stack0xfffffffffffffff8 + lVar19) = (ulonglong)uVar11 << 0x10;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar19) = 0;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar19) = 0xffffffff;
      uVar35 = *(undefined4 *)(*(longlong *)(&stack0x00000858 + lVar19) + 0x20);
      lVar33 = plVar22[0xf];
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101522;
      func_0x(&stack0x00000298 + lVar19,lVar32,lVar33,uVar35);
      *(undefined8 *)(&stack0x000006b8 + lVar19) = *(undefined8 *)(&stack0x00000998 + lVar19);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10153e;
      (*_DAT_)(*(undefined8 *)(&stack0x00000998 + lVar19),0x98);
      goto LAB_;
    }
    lVar23 = *(longlong *)(&stack0x00000098 + lVar19);
  }
  *(undefined8 *)((longlong)&uStackX_8 + lVar19) = *(undefined8 *)(&stack0x00000090 + lVar19);
  *(undefined8 *)((longlong)&uStackX_20 + lVar19 + -0x20) =
       *(undefined8 *)(&stack0x000001b8 + lVar19);
  *(longlong *)(&stack0xfffffffffffffff8 + lVar19) = lVar23;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar19) = *(undefined8 *)(&stack0x00000398 + lVar19);
  *(undefined **)(&stack0xffffffffffffffe8 + lVar19) = &stack0x000000d8 + lVar19;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101817;
  func_0x(plVar22,&stack0x000002b8 + lVar19,*(undefined8 *)(&stack0x000000c8 + lVar19),
                  &stack0x00000120 + lVar19);
LAB_:
  if (*(char *)(plVar22 + 5) == '\0') {
    lVar23 = *plVar22;
    (&stack0xfffffffffffffff0)[lVar19] = 0;
    (&stack0xffffffffffffffe8)[lVar19] = 0;
    pcVar7 = *(code **)(lVar23 + 0x18);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101ff6;
    (*pcVar7)(plVar22,0,0,0xffffffffffffffff);
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10182b;
    func_0x();
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x101ffe;
  func_0x(plVar22);
  pcVar7 = *(code **)(*(longlong *)(*(longlong *)(&stack0x00000090 + lVar19) + 8) + 0x30);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10201b;
  (*pcVar7)((longlong *)(*(longlong *)(&stack0x00000090 + lVar19) + 8),
            *(undefined8 *)(&stack0x00000110 + lVar19),0);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10202b;
  func_0x(&stack0x000002b8 + lVar19,1);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10203f;
  (*_DAT_)(*(undefined8 *)(&stack0x00000a58 + lVar19),0x98);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10204d;
  func_0x(&stack0x00000858 + lVar19);
  if (*(longlong *)(&stack0x000001e8 + lVar19) != 0) {
    *(undefined (*) [16])(&stack0x000001e8 + lVar19) = ZEXT816(0);
  }
  if (*(longlong **)(&stack0x00000158 + lVar19) != (longlong *)0x0) {
    pcVar7 = *(code **)(**(longlong **)(&stack0x00000158 + lVar19) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x102078;
    (*pcVar7)();
  }
  *(undefined8 *)(&stack0x00000b98 + lVar19) = 0xf88328;
  *(undefined8 *)(&stack0x00000b98 + lVar19) = 0xf89880;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1020aa;
  (*_DAT_)(*(undefined8 *)(&stack0x000003b0 + lVar19),4);
  if (*(longlong **)(&stack0x000003b8 + lVar19) != (longlong *)0x0) {
    pcVar7 = *(code **)(**(longlong **)(&stack0x000003b8 + lVar19) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1020be;
    (*pcVar7)();
  }
  lVar32 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar23 = *(longlong *)(lVar32 + 0x100);
  if (lVar23 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x102100;
    (*_DAT_)();
    lVar23 = *(longlong *)(lVar32 + 0x100);
  }
  if (*(int *)(lVar23 + 0x22c) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x102116;
    (*_DAT_)();
  }
  if (*(longlong *)(&stack0x000002b0 + lVar19) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10212c;
    func_0x(*(longlong *)(&stack0x000002b0 + lVar19),1);
  }
  puVar25 = *(undefined8 **)(&stack0x000002a8 + lVar19);
  if (puVar25 != (undefined8 *)0x0) {
    pcVar7 = *(code **)*puVar25;
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x102142;
    (*pcVar7)(puVar25,1);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x102150;
  func_0x(&stack0x00000298 + lVar19);
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x102164;
  (*_DAT_)(*(undefined8 *)(&stack0x00000140 + lVar19),4);
  plVar38 = *(longlong **)(&stack0x00000118 + lVar19);
  if (plVar38 != (longlong *)0x0) {
    pcVar7 = *(code **)(*plVar38 + 0x50);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10217b;
    (*pcVar7)(plVar38,1);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x102189;
  func_0x(&stack0x00000430 + lVar19);
  if (*(longlong **)(&stack0x00000090 + lVar19) != (longlong *)0x0) {
    pcVar7 = *(code **)(**(longlong **)(&stack0x00000090 + lVar19) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10219d;
    (*pcVar7)();
  }
  *(undefined8 *)(&stack0x000002b8 + lVar19) = 0xf800f0;
  if (*(int *)(&stack0x000002c8 + lVar19) == 3) {
    *(undefined4 *)(&stack0x000002c8 + lVar19) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1021cf;
    func_0x(*(longlong *)(&stack0x000002c0 + lVar19) + 0x530,1);
  }
  puVar25 = *(undefined8 **)(&stack0x00000218 + lVar19);
  *(undefined8 **)(&stack0x000003d0 + lVar19) = puVar25;
  if (puVar25 != (undefined8 *)0x0) {
    puVar10 = (undefined8 *)*puVar25;
    while (puVar10 != (undefined8 *)0x0) {
      *puVar25 = *puVar10;
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x102201;
      (*_DAT_)(puVar10,0x30);
      puVar10 = (undefined8 *)*puVar25;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10221a;
    (*_DAT_)(puVar25,0x38);
  }
  *(undefined8 *)(&stack0x00000218 + lVar19) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x102232;
  func_0x
            (*(ulonglong *)(&stack0x00002f58 + lVar19) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar19));
  return;
}

