
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  undefined4 uStackX_8;
  
  lVar2 = 0;
  uStackX_8 = *(undefined4 *)(param_1 + 8);
  lVar3 = lVar2;
  do {
    if (*(char *)((longlong)&uStackX_8 + lVar3) != '\0') {
      uVar1 = (*_DAT_)(param_2 + 0x10);
      *(ulonglong *)(param_2 + 0x18) = *(ulonglong *)(param_2 + 0x18) ^ uVar1;
    }
    lVar3 = lVar3 + 1;
  } while (lVar3 < 4);
  do {
    if (*(char *)(lVar2 + 0x60 + param_1) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar2 = lVar2 + 1;
  } while (lVar2 < 4);
  return;
}

