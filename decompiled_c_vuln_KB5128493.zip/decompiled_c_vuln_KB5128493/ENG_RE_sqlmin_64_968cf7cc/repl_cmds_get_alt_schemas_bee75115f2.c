
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined *param_1,undefined2 param_2,ulonglong param_3,longlong param_4)

{
  int *piVar1;
  ulonglong uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  longlong lVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  longlong lVar14;
  ulonglong uVar15;
  longlong unaff_GS_OFFSET;
  bool bVar16;
  undefined auStack_328 [32];
  undefined8 uStack_308;
  undefined8 uStack_300;
  undefined8 uStack_2f8;
  undefined8 uStack_2f0;
  undefined4 uStack_2e8;
  undefined8 uStack_2d8;
  undefined2 uStack_2d0;
  undefined uStack_2c8;
  undefined uStack_2c7;
  undefined uStack_2c6;
  undefined uStack_2c5;
  undefined uStack_2c4;
  undefined uStack_2c3;
  undefined uStack_2c2;
  undefined uStack_2c1;
  undefined2 uStack_2c0;
  uint auStack_2b8 [2];
  undefined8 uStack_2b0;
  longlong lStack_2a8;
  undefined8 uStack_2a0;
  undefined4 uStack_298;
  undefined auStack_290 [16];
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined4 auStack_278 [2];
  ulonglong uStack_270;
  int iStack_268;
  int iStack_264;
  longlong lStack_260;
  int iStack_258;
  undefined8 uStack_250;
  longlong *plStack_248;
  undefined4 uStack_240;
  longlong *plStack_238;
  undefined uStack_230;
  undefined4 *puStack_228;
  undefined4 *puStack_220;
  undefined auStack_218 [16];
  undefined auStack_208 [16];
  undefined auStack_1f8 [16];
  undefined auStack_1e8 [16];
  undefined auStack_1d8 [16];
  undefined8 uStack_1c8;
  undefined8 uStack_1b8;
  undefined auStack_1a8 [16];
  undefined auStack_198 [16];
  undefined auStack_188 [16];
  longlong lStack_178;
  undefined2 uStack_170;
  undefined8 uStack_168;
  int iStack_160;
  undefined auStack_158 [16];
  undefined auStack_148 [16];
  undefined auStack_138 [16];
  undefined auStack_128 [16];
  longlong lStack_118;
  uint uStack_110;
  undefined8 uStack_108;
  undefined8 uStack_100;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  undefined2 uStack_d8;
  undefined2 uStack_d6;
  undefined8 uStack_d0;
  undefined2 uStack_be;
  undefined auStack_b8 [16];
  undefined4 uStack_a8;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined2 uStack_94;
  undefined8 *puStack_90;
  undefined2 uStack_88;
  undefined8 uStack_84;
  undefined8 uStack_78;
  uint uStack_70;
  undefined2 uStack_6c;
  undefined uStack_68;
  undefined uStack_67;
  undefined uStack_66;
  undefined uStack_65;
  undefined uStack_64;
  undefined uStack_63;
  undefined uStack_62;
  undefined uStack_61;
  undefined uStack_60;
  undefined uStack_5f;
  undefined uStack_58;
  undefined uStack_57;
  undefined uStack_56;
  undefined uStack_55;
  undefined uStack_54;
  undefined uStack_53;
  undefined uStack_52;
  undefined uStack_51;
  undefined uStack_50;
  undefined uStack_4f;
  ulonglong uStack_48;
  
  uStack_1b8 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_328;
  puVar12 = (undefined4 *)0x0;
  uStack_270 = param_3;
  if ((DAT_ & 8) == 0) {
    iStack_258 = 0;
  }
  else {
    iStack_258 = 1;
    iStack_268 = (*_DAT_)();
    iStack_264 = 6;
    lStack_260 = func_0x(param_2);
  }
  lVar8 = (**(code **)(_DAT_ + 0x20))(param_2);
  lStack_2a8 = lVar8;
  if (((param_3 == 0) && ((*(uint *)(lVar8 + 0x278) & 0x400) == 0)) && ((DAT_ & 2) == 0)) {
    uStack_2b0 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    if (*(int *)(lVar8 + 0x1500) == 0) {
      LOCK();
      bVar16 = *(ulonglong *)(lVar8 + 0x1500) == 0;
      if (bVar16) {
        *(ulonglong *)(lVar8 + 0x1500) = uStack_2b0;
      }
      UNLOCK();
      if (!bVar16) goto LAB_;
    }
    else {
LAB_:
      puVar13 = puVar12;
      puVar10 = puVar12;
      if (((byte)*_DAT_ & 0x84) == 0x84) {
        lVar14 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        if ((lVar14 != 0) && (*(longlong *)(lVar14 + 0x110) == lVar14)) {
          puVar13 = *(undefined4 **)(lVar14 + 0x100);
        }
        if ((puVar13 != (undefined4 *)0x0) && (puVar10 = _DAT_, *_DAT_ != 0)) {
          (*_DAT_)(&puStack_228);
          puVar10 = puStack_228;
        }
      }
      if (*(char *)(_DAT_ + 199) < '\0') {
        func_0x(lVar8 + 0x1500,puVar13,uStack_2b0);
      }
      else {
        func_0x(lVar8 + 0x1500);
      }
      if (puVar13 != (undefined4 *)0x0) {
        puVar11 = _DAT_;
        if (*_DAT_ != 0) {
          (*_DAT_)(&puStack_220);
          puVar11 = puStack_220;
        }
        puVar9 = puVar12;
        if (puVar10 <= puVar11) {
          puVar9 = (undefined4 *)((longlong)puVar11 - (longlong)puVar10);
        }
        *(longlong *)(puVar13 + 0x31e) = *(longlong *)(puVar13 + 0x31e) + (longlong)puVar9;
      }
    }
    lVar8 = lStack_2a8;
    uStack_2d8 = *(undefined8 *)(lStack_2a8 + 0x9c8);
    uStack_2d0 = *(undefined2 *)(lStack_2a8 + 0x9d0);
    if ((*_DAT_ != '\0') && (iVar4 = (*_DAT_)(), iVar4 == (iVar4 / 5) * 5)) {
      func_0x();
    }
    *(undefined8 *)(lVar8 + 0x1500) = 0;
    iVar4 = func_0x(&uStack_2d8,param_2);
    if (iVar4 == 0) goto LAB_;
  }
  uStack_2a0 = 0;
  uStack_2b0 = uStack_2b0 & 0xffffffff00000000;
  uStack_298 = 1;
  auStack_290._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_290._8_8_ = 0;
  cVar3 = (**(code **)(*(longlong *)auStack_290._0_8_ + 0x1d0))();
  if (cVar3 == '\0') {
    uStack_2e8 = 0;
    uStack_2f0 = 0;
    uStack_2f8 = uStack_2f8 & 0xffffffffffffff00;
    uStack_300 = (undefined8 *)CONCAT44(uStack_300._4_4_,2);
    uStack_308 = CONCAT44(uStack_308._4_4_,1);
    (**(code **)(*(longlong *)auStack_290._0_8_ + 8))(auStack_290._0_8_,0x1a726f8,0x1c);
    uStack_2a0 = CONCAT44(uStack_2a0._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_290._0_8_ + 0xe8))
              (auStack_290._0_8_,1,1,(longlong)&uStack_2a0 + 4);
    uStack_298 = 1;
    uStack_2a0 = CONCAT44(uStack_2a0._4_4_,4);
  }
  uStack_240 = 1;
  plStack_238 = (longlong *)0x0;
  uStack_230 = 0;
  uStack_250 = 0x181c540;
  plStack_248 = *(longlong **)(*(longlong *)(lStack_2a8 + 0x1210) + 0x6c8);
  plStack_238 = (longlong *)(**(code **)(*plStack_248 + 0x80))(plStack_248,1,plStack_248,0);
  uStack_2f8 = CONCAT44(uStack_2f8._4_4_,2);
  uStack_300 = (undefined8 *)CONCAT44(uStack_300._4_4_,0x14);
  uStack_308 = 0x1a75d40;
  (**(code **)(*plStack_238 + 8))(plStack_238,0,4);
  uStack_68 = param_1[3];
  uStack_67 = param_1[2];
  uStack_66 = param_1[1];
  uStack_65 = *param_1;
  uStack_64 = param_1[7];
  uStack_63 = param_1[6];
  uStack_62 = param_1[5];
  uStack_61 = param_1[4];
  uStack_60 = param_1[9];
  uStack_5f = param_1[8];
  if (param_4 != 0) {
    *(undefined8 *)(param_4 + 0x2c) = *(undefined8 *)(param_4 + 0x20);
    *(undefined4 *)(param_4 + 0x34) = *(undefined4 *)(param_4 + 0x28);
    uVar5 = (*_DAT_)();
    *(undefined4 *)(param_4 + 0x108) = uVar5;
  }
  iVar4 = func_0x(param_2,0x1a726f8);
  if (iVar4 == 0) {
    func_0x(0x4977,0x10,1,0x1a726f8);
    func_0x(&uStack_2a0,0);
  }
  else {
    uStack_168 = (**(code **)(*(longlong *)auStack_290._0_8_ + 0x1b0))();
    lStack_178 = 0;
    auStack_158 = ZEXT816(0);
    auStack_148 = ZEXT816(0);
    auStack_138 = ZEXT816(0);
    auStack_128 = ZEXT816(0);
    lStack_118 = 0;
    uStack_110 = 0;
    uStack_108 = 0;
    uStack_100 = 0;
    uStack_170 = param_2;
    iStack_160 = iVar4;
    iVar4 = func_0x(&lStack_178,3,1);
    if (iVar4 == 0) {
      func_0x(0x49aa,0x10,5,0x1a726f8);
    }
    else {
      auStack_2b8[0] = 10;
      auStack_188._0_4_ = func_0x(&lStack_178,0x1a726e0,auStack_2b8);
      auStack_1a8 = ZEXT816(0);
      auStack_198 = ZEXT816(0);
      auStack_188._4_12_ = SUB1612(ZEXT816(0),4);
      uStack_1c8 = 0;
      auStack_1d8 = ZEXT416(auStack_2b8[0]) << 0x40;
      auStack_208 = ZEXT816(0);
      auStack_218 = ZEXT416((uint)auStack_188._0_4_);
      auStack_1e8._0_12_ = ZEXT412(1) << 0x40;
      auStack_1e8._12_4_ = 0;
      auStack_1f8._8_8_ = 0;
      auStack_1f8._0_8_ = auStack_1a8;
      uStack_2f8 = 0;
      uStack_300 = &uStack_100;
      uStack_308 = 0;
      (**(code **)(*(longlong *)auStack_148._8_8_ + 0x20))(auStack_148._8_8_,2,1,auStack_218);
      uStack_2f8 = uStack_2f8 & 0xffffffff00000000;
      uStack_300 = (undefined8 *)0x0;
      uStack_308 = 0;
      (**(code **)(*(longlong *)auStack_138._8_8_ + 0x28))
                (auStack_138._8_8_,uStack_100,1,&uStack_68);
      uStack_300 = (undefined8 *)lStack_178;
      uStack_308 = uStack_108;
      iVar4 = (**(code **)(*(longlong *)auStack_158._8_8_ + 0x18))(auStack_158._8_8_,0,1);
      uVar2 = uStack_270;
      if (iVar4 == 0) {
        uStack_2b0 = CONCAT44(uStack_2b0._4_4_,1);
        puVar13 = puVar12;
        do {
          uStack_280 = 0;
          puVar10 = puVar12;
          if (lStack_178 != 0) {
            uVar6 = func_0x(&lStack_178,0x180e680,&uStack_280);
            uVar15 = (ulonglong)uVar6;
            if (uVar15 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_118)) {
LAB_:
              puVar13 = puVar12;
              if (uVar6 <= uStack_110) {
                lVar8 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_118;
                puVar10 = (undefined4 *)(*(longlong *)(lVar8 + 8) + lStack_178);
                puVar13 = *(undefined4 **)(lStack_178 + *(longlong *)(lVar8 + 0x10));
              }
            }
            else {
              uVar6 = 1;
              puVar13 = puVar12;
              if (uStack_110 != 0) {
                do {
                  if (uVar15 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_118))
                  goto LAB_;
                  uVar6 = uVar6 + 1;
                } while (uVar6 <= uStack_110);
              }
            }
          }
          uVar5 = *puVar10;
          uStack_27c = 0;
          puVar10 = puVar12;
          if (lStack_178 == 0) {
LAB_:
            lVar8 = lStack_178;
            if (puVar13 < (undefined4 *)0xb) goto LAB_;
          }
          else {
            uVar6 = func_0x(&lStack_178,0x1a726e0,&uStack_27c);
            uVar15 = (ulonglong)uVar6;
            if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_118)) {
LAB_:
              puVar13 = puVar12;
              if (uVar6 <= uStack_110) {
                lVar8 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_118;
                puVar13 = *(undefined4 **)(lStack_178 + *(longlong *)(lVar8 + 0x10));
                puVar10 = (undefined4 *)(*(longlong *)(lVar8 + 8) + lStack_178);
                goto LAB_;
              }
            }
            else {
              uVar6 = 1;
              puVar13 = puVar12;
              if (uStack_110 != 0) {
                do {
                  if (uVar15 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_118))
                  goto LAB_;
                  uVar6 = uVar6 + 1;
                } while (uVar6 <= uStack_110);
              }
            }
LAB_:
            lVar8 = lStack_178;
            func_0x(&uStack_68,puVar10,puVar13);
          }
          auStack_278[0] = 0;
          puVar10 = puVar12;
          if (lVar8 == 0) {
            lVar8 = 0;
LAB_:
            if (puVar13 < (undefined4 *)0xb) goto LAB_;
          }
          else {
            uVar6 = func_0x(&lStack_178,0x1a726c0,auStack_278);
            uVar15 = (ulonglong)uVar6;
            lVar8 = lStack_178;
            if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_118)) {
LAB_:
              puVar13 = puVar12;
              if (uVar6 <= uStack_110) {
                lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_118;
                puVar13 = *(undefined4 **)(lStack_178 + *(longlong *)(lVar14 + 0x10));
                puVar10 = (undefined4 *)(*(longlong *)(lVar14 + 8) + lStack_178);
                goto LAB_;
              }
            }
            else {
              uVar6 = 1;
              puVar13 = puVar12;
              if (uStack_110 != 0) {
                do {
                  if (uVar15 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_118))
                  goto LAB_;
                  uVar6 = uVar6 + 1;
                } while (uVar6 <= uStack_110);
              }
            }
LAB_:
            func_0x(&uStack_58,puVar10,puVar13);
          }
          uStack_270 = uStack_270 & 0xffffffff00000000;
          puVar10 = puVar12;
          if (lVar8 != 0) {
            uVar6 = func_0x(&lStack_178,0x1a726d0,&uStack_270);
            uVar15 = (ulonglong)uVar6;
            if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_118)) {
LAB_:
              puVar13 = (undefined4 *)0x0;
              if (uVar6 <= uStack_110) {
                lVar8 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_118;
                puVar10 = (undefined4 *)(*(longlong *)(lVar8 + 8) + lStack_178);
                puVar13 = *(undefined4 **)(lStack_178 + *(longlong *)(lVar8 + 0x10));
              }
            }
            else {
              uVar6 = 1;
              puVar13 = puVar12;
              if (uStack_110 != 0) {
                do {
                  if (uVar15 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_118))
                  goto LAB_;
                  uVar6 = uVar6 + 1;
                } while (uVar6 <= uStack_110);
              }
            }
          }
          uStack_88 = *(undefined2 *)puVar10;
          uStack_2d8 = CONCAT35(CONCAT21(CONCAT11(uStack_64,uStack_63),uStack_62),
                                CONCAT14(uStack_61,
                                         CONCAT31(CONCAT21(CONCAT11(uStack_68,uStack_67),uStack_66),
                                                  uStack_65)));
          uStack_2d0 = CONCAT11(uStack_60,uStack_5f);
          uStack_2c5 = uStack_58;
          uStack_2c6 = uStack_57;
          uStack_2c7 = uStack_56;
          uStack_2c8 = uStack_55;
          uStack_2c1 = uStack_54;
          uStack_2c2 = uStack_53;
          uStack_2c3 = uStack_52;
          uStack_2c4 = uStack_51;
          uStack_2c0 = CONCAT11(uStack_50,uStack_4f);
          uStack_f8 = 0;
          uStack_f0 = 0;
          uStack_e8 = 0;
          uStack_e0 = uStack_2d8;
          uStack_d8 = uStack_2d0;
          uStack_d6 = 0;
          uStack_d0 = 0;
          uStack_be = 0;
          auStack_b8 = ZEXT816(0);
          uStack_a0 = 0;
          uStack_98 = 0;
          uStack_94 = 0;
          puStack_90 = &uStack_250;
          uStack_84 = 0;
          uStack_78 = 0;
          uStack_6c = *(undefined2 *)
                       (*(longlong *)
                         (*(longlong *)
                           ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
                         + 0x50) + 8);
          uStack_70 = DAT_ >> 1 & 1;
          uStack_a8 = uVar5;
          func_0x(&uStack_f8,uVar2);
          if (param_4 != 0) {
            *(uint *)(param_4 + 0x2c) =
                 CONCAT13(uStack_2c5,CONCAT12(uStack_2c6,CONCAT11(uStack_2c7,uStack_2c8)));
            *(uint *)(param_4 + 0x30) =
                 CONCAT13(uStack_2c1,CONCAT12(uStack_2c2,CONCAT11(uStack_2c3,uStack_2c4)));
            *(undefined2 *)(param_4 + 0x34) = uStack_2c0;
            *(int *)(param_4 + 0x80) = *(int *)(param_4 + 0x80) + 1;
            if ((_DAT_ != 0) &&
               (iVar4 = *(int *)(param_4 + 0x108), iVar7 = (*_DAT_)(),
               _DAT_ <= (uint)(iVar7 - iVar4))) {
              func_0x(param_4,2);
              uVar5 = (*_DAT_)();
              *(undefined4 *)(param_4 + 0x108) = uVar5;
            }
          }
          func_0x(&uStack_f8);
          uStack_300 = (undefined8 *)lStack_178;
          uStack_308 = uStack_108;
          iVar4 = (**(code **)(*(longlong *)auStack_158._8_8_ + 0x18))(auStack_158._8_8_,0);
        } while (iVar4 == 0);
      }
    }
    func_0x(&lStack_178);
    func_0x(&uStack_2a0,0);
    if ((int)uStack_2b0 != 0) {
      func_0x(0xffff);
    }
  }
  uStack_250 = 0x181c540;
  if (plStack_238 != (longlong *)0x0) {
    (**(code **)*plStack_238)(plStack_238,1);
    plStack_238 = (longlong *)0x0;
  }
  if ((int)uStack_2a0 != 0) {
    func_0x(&uStack_2a0,0);
  }
LAB_:
  lVar8 = lStack_260;
  if ((iStack_258 != 0) && (lStack_260 != 0)) {
    iVar4 = (*_DAT_)();
    piVar1 = (int *)(lVar8 + 8 + (longlong)iStack_264 * 4);
    *piVar1 = *piVar1 + (iVar4 - iStack_268);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_328);
  return;
}

