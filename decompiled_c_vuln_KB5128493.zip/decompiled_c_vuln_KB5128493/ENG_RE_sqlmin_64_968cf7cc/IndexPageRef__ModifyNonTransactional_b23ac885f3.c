
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,int param_3,short *param_4)

{
  short *psVar1;
  byte *pbVar2;
  longlong lVar3;
  longlong **pplVar4;
  undefined8 uVar5;
  undefined auVar6 [16];
  longlong **pplVar7;
  char cVar8;
  byte bVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  ushort uVar12;
  int iVar13;
  int iVar14;
  byte *pbVar15;
  ushort uVar16;
  uint uVar17;
  uint uVar18;
  undefined *puVar19;
  ulonglong uVar20;
  short sVar21;
  ushort uVar22;
  undefined auStack_1e8 [40];
  undefined8 uStack_1c0;
  undefined auStack_1a0 [8];
  undefined8 uStack_198;
  undefined2 auStack_17c [2];
  undefined2 uStack_178;
  undefined auStack_176 [14];
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined2 uStack_158;
  int iStack_150;
  undefined auStack_148 [12];
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined *puStack_128;
  int iStack_120;
  undefined2 *puStack_118;
  undefined2 *puStack_110;
  undefined *puStack_108;
  undefined *puStack_100;
  short sStack_f8;
  ushort uStack_f6;
  int iStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined2 uStack_e0;
  short sStack_de;
  short sStack_dc;
  undefined2 uStack_da;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  uint uStack_c8;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [2];
  undefined auStack_ae [2];
  undefined auStack_ac [12];
  uint uStack_a0;
  undefined4 uStack_9c;
  short sStack_98;
  short sStack_96;
  short sStack_94;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  uint uStack_80;
  undefined4 uStack_7c;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [10];
  undefined auStack_56 [6];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_168;
  sStack_f8 = 0xffff;
  puVar19 = (undefined *)0x0;
  pbStack_f0 = (byte *)0x0;
  sVar21 = 3;
  iStack_f4 = 0;
  uStack_da = 0;
  uStack_d8 = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_e8 = (undefined *)0x0;
  lVar3 = **param_1;
  uStack_168 = param_1;
  iStack_150 = param_3;
  iStack_c4 = param_3;
  if (*(char *)(lVar3 + 2) < '\0') {
    pbVar15 = (byte *)(lVar3 + 0x60);
    puVar19 = auStack_c0;
    _auStack_ae = SUB1614(ZEXT816(0),2);
    auStack_b0 = (undefined  [2])0xffff;
    sStack_98 = 0;
    sStack_96 = 0;
    sStack_94 = 0;
    uStack_8a = 0;
    auStack_ac._4_8_ = 0;
    uStack_80 = 0;
    uStack_7c = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    psStack_78 = (short *)0x0;
    _auStack_60 = ZEXT812(0);
    auStack_56._2_4_ = 0;
    uStack_50 = 0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uStack_66 = 0;
    auStack_c0 = ZEXT816(0);
    uVar5 = 0;
    if (*(short *)(lVar3 + 0x24) == 0) {
LAB_:
      auStack_c0._8_8_ = uVar5;
      uStack_160 = *(undefined8 *)(lVar3 + 0x28);
      uStack_158 = *(undefined2 *)(lVar3 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar3 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar3 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar3 + 0x18) != 99) goto LAB_;
      }
      uStack_160 = CONCAT26(uStack_160._6_2_,*(undefined6 *)(lVar3 + 0x20));
      uStack_1c0 = 0x10016e;
      cVar8 = func_0x(&uStack_160,0x1626298);
      uVar5 = auStack_c0._8_8_;
      if (cVar8 == '\0') goto LAB_;
      uStack_1c0 = 0x10017e;
      func_0x(lVar3,&uStack_160);
    }
    auStack_60._8_2_ = uStack_158;
    auStack_60._0_8_ = uStack_160;
    auStack_c0._0_8_ = pbVar15;
    auStack_56._2_4_ = *(undefined4 *)(lVar3 + 0x20);
    uVar18 = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_88 = 0;
    uStack_86 = 0;
    uVar20 = (ulonglong)*(short *)((ulonglong)*pbVar15 * 6 + 0x16a68a4);
    uStack_160 = CONCAT44((int)((ulonglong)uStack_160 >> 0x20),
                          *(undefined4 *)((ulonglong)*pbVar15 * 6 + 0x16a68a0));
    auStack_ac._4_8_ = 0;
    _auStack_ae = (uint6)(_auStack_b0 >> 0x10) & 0xffff;
    auStack_b0 = (undefined  [2])0xffff;
    uStack_a0 = 0;
    uStack_9c = 0;
    psStack_78 = (short *)0x0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uVar17 = uStack_a0;
    if ((*pbVar15 & 2) != 0) {
      pbVar2 = pbVar15 + uVar20;
      auStack_ac._4_8_ = pbVar2;
      if ((pbVar15[uVar20] & 1) == 0) {
        auVar6._14_2_ = 0;
        auVar6._0_14_ = _auStack_ae;
        _auStack_b0 = auVar6 << 0x10;
        uStack_8a = 0;
        uStack_88 = 0;
        uVar17 = uVar18;
        switch(*pbVar2 & 0xe) {
        default:
          uVar22 = *(ushort *)(pbVar2 + 2);
          uVar17 = (uint)uVar22;
          if (0x1f9d < uVar22 - 1) {
            uStack_1c0 = 0x10046a;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar17 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar17 = 1;
        }
      }
      else {
        bVar9 = *pbVar2;
        switch(bVar9 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            auStack_ae = (undefined  [2])
                         ((*(ushort *)(pbVar2 + 1) & 0x7f) << 8 | *(ushort *)(pbVar2 + 1) >> 8);
            sStack_98 = 3;
          }
          else {
            auStack_ae = (undefined  [2])(ushort)pbVar2[1];
            sStack_98 = 2;
          }
          auStack_b0 = (undefined  [2])0x1;
          sStack_94 = (short)((ushort)auStack_ae + 1 >> 1) + sStack_98;
          if ((ushort)auStack_ae < 0x1f) {
            uStack_80 = 0;
            sStack_96 = 0;
            uStack_88 = 0;
            uStack_86 = 0;
            uStack_a0 = 0;
            uStack_9c = 0;
            uVar17 = uStack_a0;
          }
          else {
            iVar13 = (ushort)auStack_ae - 1;
            uStack_80 = 0;
            uStack_88 = 0;
            uStack_86 = 0;
            uStack_a0 = 0;
            uStack_9c = 0;
            sStack_96 = ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                        (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
            uVar17 = uStack_a0;
          }
          break;
        case 4:
          if (((bVar9 & 0x1c) == 4) && ((bVar9 & 2) != 0)) {
            uVar18 = 1;
            auStack_ac._0_4_ = 0xf;
          }
          else {
            auStack_ac._0_4_ = 1;
          }
          sStack_98 = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_8a = 0;
          _auStack_b0 = 1;
          uStack_88 = 0;
          uStack_86 = 0;
          uStack_a0 = 0;
          uStack_9c = 0;
          uVar17 = uStack_a0;
          uStack_80 = uVar18;
          break;
        case 8:
          sStack_98 = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_8a = 0;
          _auStack_b0 = 0x900000001;
          uStack_80 = 0;
          uStack_88 = 0;
          uStack_86 = 0;
          uStack_a0 = 0;
          uStack_9c = 0;
          uVar17 = uStack_a0;
        }
      }
    }
    uStack_a0 = uVar17;
    uStack_90 = 0;
    uStack_92 = 0;
    if ((*(byte *)auStack_c0._0_8_ & 4) != 0) {
      if (uStack_160._2_2_ != 0) {
        uVar20 = (ulonglong)*(ushort *)(lVar3 + 0x61 + (longlong)uStack_160._2_2_ * 2);
      }
      psStack_78 = (short *)(pbVar15 + uVar20);
      psStack_70 = psStack_78 + 1;
      sStack_68 = (*psStack_78 + 1) * 2;
    }
    if (auStack_c0._8_8_ != 0) {
      uStack_1c0 = 0x100519;
      func_0x(auStack_c0._8_8_,auStack_c0);
    }
  }
  iVar13 = iStack_150;
  pplVar7 = uStack_168;
  pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar3 + (0xfff - (longlong)iStack_150) * 2) + lVar3);
  if ((*pbStack_f0 & 1) == 0) {
    sStack_f8 = 0;
    iStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
    uVar17 = (uint)*(ushort *)(lVar3 + 0xe);
    switch(*pbStack_f0 & 0xe) {
    default:
      uVar17 = (uint)*(ushort *)(pbStack_f0 + 2);
      if (0x1f9d < *(ushort *)(pbStack_f0 + 2) - 1) {
        uStack_1c0 = 0x1007a8;
        func_0x(pbStack_f0,6);
      }
      break;
    case 4:
      uVar17 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar17 = 1;
    }
    uStack_e8 = (undefined *)CONCAT44(uStack_e8._4_4_,uVar17);
    uStack_da = (undefined2)(lVar3 + 0x2000);
    uStack_d8 = (undefined6)((ulonglong)(lVar3 + 0x2000) >> 0x10);
  }
  else {
    sStack_f8 = 1;
    bVar9 = *pbStack_f0;
    uStack_e8 = puVar19;
    switch(bVar9 & 0x1c) {
    default:
      if ((char)pbStack_f0[1] < '\0') {
        uStack_e0 = 3;
        uStack_f6 = (*(ushort *)(pbStack_f0 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_f0 + 1) >> 8;
      }
      else {
        uStack_f6 = (ushort)pbStack_f0[1];
        uStack_e0 = 2;
        sVar21 = 2;
      }
      sStack_dc = ((ushort)(uStack_f6 + 1) >> 1) + sVar21;
      if (uStack_f6 < 0x1f) {
        sStack_de = 0;
        uStack_d0 = (undefined2)(lVar3 + 0x2000);
        uStack_ce = (undefined6)((ulonglong)(lVar3 + 0x2000) >> 0x10);
        iStack_f4 = 0;
        uStack_c8 = 0;
      }
      else {
        iVar14 = uStack_f6 - 1;
        iStack_f4 = 0;
        uStack_c8 = 0;
        sStack_de = ((short)(iVar14 / 0x1e) + (short)(iVar14 >> 0x1f)) -
                    (short)((longlong)iVar14 * 0x88888889 >> 0x3f);
        uStack_d0 = (undefined2)(lVar3 + 0x2000);
        uStack_ce = (undefined6)((ulonglong)(lVar3 + 0x2000) >> 0x10);
      }
      break;
    case 4:
      if (((bVar9 & 0x1c) == 4) && ((bVar9 & 2) != 0)) {
        uStack_e0 = 0;
        sStack_de = 0;
        sStack_dc = 0;
        uStack_da = 0;
        uStack_d0 = (undefined2)(lVar3 + 0x2000);
        uStack_ce = (undefined6)((ulonglong)(lVar3 + 0x2000) >> 0x10);
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        iStack_f4 = 0xf;
        uStack_c8 = 1;
      }
      else {
        uStack_e0 = 0;
        sStack_de = 0;
        sStack_dc = 0;
        uStack_da = 0;
        uStack_d0 = (undefined2)(lVar3 + 0x2000);
        uStack_ce = (undefined6)((ulonglong)(lVar3 + 0x2000) >> 0x10);
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        iStack_f4 = 1;
        uStack_c8 = 0;
      }
      break;
    case 8:
      uStack_e0 = 0;
      sStack_de = 0;
      sStack_dc = 0;
      uStack_da = 0;
      uStack_d0 = (undefined2)(lVar3 + 0x2000);
      uStack_ce = (undefined6)((ulonglong)(lVar3 + 0x2000) >> 0x10);
      uStack_f6 = 0;
      uStack_d8 = 0;
      uStack_d2 = 0;
      iStack_f4 = 9;
      uStack_c8 = 0;
    }
  }
  if (sStack_f8 == 0) {
    bVar9 = *pbStack_f0 >> 6;
  }
  else {
    bVar9 = *pbStack_f0 >> 1;
  }
  if ((bVar9 & 1) == 0) {
    if (*param_4 == 0) {
      uStack_1c0 = 0x1009f9;
      func_0x(param_4 + 1);
    }
    else {
      pbVar15 = *(byte **)(param_4 + 4);
      bVar9 = *pbVar15;
      if ((bVar9 & 2) != 0) {
        if (*(int *)(param_4 + 2) == 0) {
          uStack_1c0 = 0x100a82;
          func_0x(param_4 + 1);
          pbVar15 = *(byte **)(param_4 + 4);
          bVar9 = *pbVar15;
        }
        *pbVar15 = bVar9 & 0xfd;
        *(undefined4 *)(param_4 + 2) = *(undefined4 *)(param_4 + 0x18);
        *(undefined4 *)(param_4 + 0x18) = 0;
      }
    }
    goto code_r0x001009fc;
  }
  if (sStack_f8 == 0) {
    uStack_1c0 = 0x10081c;
    puVar10 = (undefined8 *)func_0x();
  }
  else {
    uStack_1c0 = 0x100829;
    func_0x(&uStack_f6);
    if ((*pbStack_f0 & 2) == 0) {
      puVar10 = (undefined8 *)0x0;
    }
    else {
      puVar10 = (undefined8 *)(pbStack_f0 + uStack_c8);
    }
  }
  puVar11 = (undefined8 *)0x0;
  pplVar4 = (longlong **)*puVar10;
  psVar1 = param_4 + 1;
  uVar22 = (ushort)((ulonglong)pplVar4 >> 0x30);
  uStack_160 = CONCAT26(uStack_160._6_2_,*(undefined6 *)(puVar10 + 1));
  uStack_168 = pplVar4;
  if (*param_4 == 0) {
    uStack_1c0 = 0x100879;
    func_0x();
  }
  else {
    uStack_1c0 = 0x100880;
    func_0x(psVar1,&uStack_160);
  }
  uVar12 = uVar22;
  if ((((uint)(int)(short)uVar22 >> 1 ^ (int)(short)uVar22) & 0x2000) != 0) {
    uVar12 = uVar22 & 0xdfff;
    if ((uVar22 >> 0xe & 1) != 0) {
      uVar12 = uVar22 | 0x2000;
    }
  }
  uVar16 = uStack_168._6_2_;
  if (uVar12 == 0xfffc) {
    if ((((uint)(int)(short)uStack_168._6_2_ >> 1 ^ (int)(short)uStack_168._6_2_) & 0x2000) != 0) {
      uVar22 = uStack_168._6_2_ & 0xdfff;
      if ((uStack_168._6_2_ >> 0xe & 1) != 0) {
        uVar22 = uStack_168._6_2_ | 0x2000;
      }
    }
    if ((uVar22 != 0xfffc) || (uStack_168._4_2_ < 0x20)) goto code_r0x0010095c;
    if (sStack_f8 == 0) {
      uStack_1c0 = 0x100905;
      puVar11 = (undefined8 *)func_0x(&uStack_f6);
    }
    else if ((*pbStack_f0 & 2) != 0) {
      if (iStack_f4 == 0) {
        uStack_1c0 = 0x10091f;
        func_0x(&uStack_f6);
      }
      puVar11 = (undefined8 *)(pbStack_f0 + (ulonglong)uStack_c8 + 0xe);
    }
    if (*param_4 == 0) {
      uStack_1c0 = 0x10094b;
      func_0x();
      uVar16 = uStack_168._6_2_;
    }
    else {
      uStack_1c0 = 0x100956;
      func_0x(psVar1,&uStack_168,puVar11);
      uVar16 = uStack_168._6_2_;
    }
  }
  else {
code_r0x0010095c:
    if (*param_4 == 0) {
      uStack_1c0 = 0x10096f;
      func_0x(psVar1,&uStack_168);
      uVar16 = uStack_168._6_2_;
    }
    else {
      if (*(int *)(param_4 + 2) == 0) {
        uStack_1c0 = 0x100983;
        func_0x(psVar1);
      }
      uStack_1c0 = 0x10098b;
      func_0x(psVar1);
      if ((**(byte **)(param_4 + 4) & 2) != 0) {
        puVar11 = (undefined8 *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 0x18));
      }
      *puVar11 = pplVar4;
      *(undefined4 *)(param_4 + 2) = 0;
      uStack_1c0 = 0x1009ae;
      func_0x(psVar1);
    }
  }
  iVar13 = iStack_150;
  if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) >> 0xd & 1) != 0) {
    uStack_198 = 0;
    uStack_1c0 = 0x1009e1;
    (*pcRam0000000001527bb0)(1,0x1a58868,0x1a2e100,0xd6c);
    iVar13 = iStack_150;
  }
code_r0x001009fc:
  uStack_130 = 0x7e;
  uStack_134 = 1;
  puStack_100 = auStack_1e8;
  puStack_108 = auStack_1a0;
  iStack_120 = 0;
  puStack_118 = auStack_17c;
  uStack_13c = 0;
  puStack_110 = &uStack_178;
  puStack_128 = auStack_176;
  uStack_138 = 2;
  if (sStack_f8 == 0) {
    func_0x();
  }
  else {
    func_0x(&uStack_f6,param_4 + 1,auStack_148);
  }
  if (iStack_120 != 0) {
    uStack_168 = (longlong **)
                 (ulonglong)*(uint6 *)(*(longlong *)(*(longlong *)pplVar7[5][1] + 8) + 0x3c0);
    func_0x(pplVar7,0,&uStack_168,iVar13,*puStack_118,*puStack_110,
                    *(undefined4 *)(puStack_108 + 0x1c),*(undefined8 *)(puStack_100 + 0x38),0x12);
  }
  func_0x(uStack_48 ^ (ulonglong)&uStack_168);
  return;
}

