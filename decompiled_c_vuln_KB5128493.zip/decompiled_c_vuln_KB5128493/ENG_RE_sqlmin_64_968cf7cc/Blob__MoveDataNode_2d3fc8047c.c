
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 *param_2,undefined4 *param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  undefined8 uVar6;
  longlong lVar7;
  bool bVar8;
  undefined4 *puVar9;
  char cVar10;
  int iVar11;
  longlong lVar12;
  short *psVar13;
  ulonglong *puVar14;
  ushort uVar15;
  undefined4 uVar16;
  ulonglong uVar17;
  ushort uVar18;
  int iVar19;
  longlong lVar20;
  uint uVar21;
  longlong lVar22;
  undefined *puVar23;
  ushort *puVar24;
  uint uVar25;
  byte **ppbVar26;
  ulonglong uVar27;
  ulonglong uVar28;
  longlong *plVar29;
  uint uVar30;
  short sVar31;
  longlong lVar32;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_440;
  undefined auStack_438 [32];
  undefined8 uStack_418;
  undefined uStack_410;
  longlong *plStack_408;
  undefined uStack_400;
  uint uStack_3fc;
  longlong *plStack_3f0;
  undefined uStack_3e8;
  uint uStack_3e4;
  undefined8 uStack_3d8;
  undefined2 uStack_3d0;
  undefined2 auStack_3c8 [4];
  undefined4 *puStack_3c0;
  undefined4 uStack_3b8;
  undefined4 uStack_3b0;
  undefined2 uStack_3ac;
  undefined4 uStack_3a8;
  undefined2 uStack_3a4;
  undefined4 uStack_3a0;
  undefined2 uStack_39c;
  undefined2 uStack_39a;
  longlong lStack_398;
  longlong lStack_390;
  undefined4 *puStack_388;
  undefined8 uStack_380;
  undefined auStack_378 [8];
  undefined4 uStack_370;
  undefined4 uStack_368;
  longlong **pplStack_360;
  undefined *puStack_358;
  undefined8 uStack_350;
  longlong *plStack_348;
  undefined8 uStack_340;
  undefined auStack_338 [528];
  undefined8 uStack_128;
  undefined8 uStack_120;
  longlong lStack_118;
  longlong lStack_110;
  uint uStack_108;
  short sStack_f8;
  ushort uStack_f6;
  uint uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  ushort uStack_dc;
  undefined2 uStack_da;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined2 uStack_ce;
  ushort uStack_cc;
  undefined2 uStack_ca;
  uint uStack_c8;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined8 uStack_88;
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [16];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  puVar23 = auStack_438;
  uStack_380 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&plStack_408;
  uVar16 = *param_3;
  uVar4 = *(undefined2 *)(param_3 + 1);
  uVar5 = *(undefined2 *)((longlong)param_3 + 6);
  plStack_408 = (longlong *)0x0;
  uStack_400 = 0;
  uStack_3fc = 0;
  plStack_3f0 = (longlong *)0x0;
  uStack_3e8 = 0;
  uStack_3e4 = 0;
  sStack_f8 = -1;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d8 = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_cc = 0;
  uStack_ca = 0;
  uStack_e8 = (byte **)0x0;
  sVar31 = *(short *)((longlong)param_3 + 6);
  lVar32 = (longlong)sVar31;
  uStack_3b0 = *param_3;
  uStack_3ac = *(undefined2 *)(param_3 + 1);
  uStack_440 = 0x1000f2;
  puStack_3c0 = param_2;
  lStack_398 = param_1;
  puStack_388 = param_3;
  lVar12 = func_0x(param_1,&plStack_408,&uStack_3b0);
  if (lVar12 == 0) {
    *param_2 = uVar16;
    *(undefined2 *)(param_2 + 1) = uVar4;
    *(undefined2 *)((longlong)param_2 + 6) = uVar5;
    uStack_440 = 0x10010e;
    func_0x(&plStack_3f0);
    puVar23 = auStack_438;
    goto LAB_;
  }
  if (*(char *)(*(longlong *)(param_1 + 0x20) + 0x1cde) != '\0') {
    uStack_3a0 = *param_3;
    uStack_39c = *(undefined2 *)(param_3 + 1);
    uStack_39a = *(undefined2 *)((longlong)param_3 + 6);
    uStack_410 = 0;
    uStack_418 = 0;
    uStack_440 = 0x100157;
    func_0x(param_1,&uStack_3a0,&plStack_408);
  }
  lVar12 = *plStack_408;
  if (((uint)*(ushort *)(lVar12 + 0x16) <= (uint)(int)sVar31) ||
     (lStack_390 = lVar32, *(short *)(lVar12 + (0xfff - lVar32) * 2) == 0)) {
    *param_2 = uVar16;
    *(undefined2 *)(param_2 + 1) = uVar4;
    *(undefined2 *)((longlong)param_2 + 6) = uVar5;
    uStack_440 = 0x10145e;
    func_0x(&plStack_3f0);
    goto LAB_;
  }
  iStack_c4 = (int)sVar31;
  if (*(char *)(lVar12 + 2) < '\0') {
    pbVar1 = (byte *)(lVar12 + 0x60);
    if ((sStack_f8 == 0) || (ppbVar26 = uStack_e8, uStack_e8 == (byte **)0x0)) {
      uStack_98 = 0;
      uStack_8a = 0;
      auStack_70 = ZEXT816(0);
      auStack_c0 = ZEXT816(0);
      stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
      auStack_b0._0_2_ = 0xffff;
      uStack_a8 = 0;
      uStack_92 = 0;
      uStack_90 = 0;
      uStack_88 = 0;
      uStack_a0 = 0;
      auStack_80 = ZEXT816(0);
      auStack_60._0_12_ = ZEXT812(0);
      auStack_60._12_4_ = 0;
      uStack_50 = 0;
      ppbVar26 = (byte **)auStack_c0;
    }
    if (*(short *)(lVar12 + 0x24) == 0) {
LAB_:
      uStack_3d8 = *(undefined8 *)(lVar12 + 0x28);
      uStack_3d0 = *(undefined2 *)(lVar12 + 0x30);
    }
    else {
      cVar10 = *(char *)(lVar12 + 1);
      if (cVar10 == '\v') {
        if (*(int *)(lVar12 + 0x18) != 99) {
LAB_:
          if (cVar10 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar10 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar12 + 0x18) != 99) goto LAB_;
      }
      uStack_3a8 = *(undefined4 *)(lVar12 + 0x20);
      uStack_3a4 = *(undefined2 *)(lVar12 + 0x24);
      uStack_440 = 0x1002b1;
      cVar10 = func_0x(&uStack_3a8);
      if (cVar10 == '\0') goto LAB_;
      uStack_440 = 0x1002c1;
      func_0x(lVar12,&uStack_3d8);
    }
    *ppbVar26 = pbVar1;
    *(undefined4 *)(ppbVar26 + 0xc) = (undefined4)uStack_3d8;
    *(int *)((longlong)ppbVar26 + 100) = (int)((ulonglong)uStack_3d8 >> 0x20);
    *(undefined2 *)(ppbVar26 + 0xd) = uStack_3d0;
    *(undefined4 *)((longlong)ppbVar26 + 0x6c) = *(undefined4 *)(lVar12 + 0x20);
    *(undefined2 *)(ppbVar26 + 0xe) = *(undefined2 *)(lVar12 + 0x24);
    *(undefined2 *)((longlong)ppbVar26 + 0x72) = 0;
    uStack_3b8 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1338700);
    uVar17 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1338704);
    *(undefined2 *)(ppbVar26 + 2) = 0xffff;
    ppbVar26[3] = (byte *)0x0;
    uVar30 = 0;
    *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
    ppbVar26[7] = (byte *)0x0;
    ppbVar26[4] = (byte *)0x0;
    ppbVar26[9] = (byte *)0x0;
    ppbVar26[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar26 + 0xb) = 0;
    if ((**ppbVar26 & 2) != 0) {
      pbVar2 = pbVar1 + uVar17;
      if ((*pbVar2 & 1) == 0) {
        *(undefined2 *)(ppbVar26 + 2) = 0;
        ppbVar26[3] = pbVar2;
        *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar26 + 0x36) = 0;
        switch(*pbVar2 & 0xe) {
        default:
          uVar30 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            uStack_440 = 0x100541;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar30 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar30 = 1;
        }
        *(uint *)(ppbVar26 + 4) = uVar30;
        *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar26 + 2) = 1;
        ppbVar26[3] = pbVar2;
        bVar3 = *pbVar2;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar15 = *(ushort *)(pbVar2 + 1);
            *(ushort *)((longlong)ppbVar26 + 0x12) = uVar15;
            sVar31 = 3;
            uVar15 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
          }
          else {
            sVar31 = 2;
            uVar15 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar26 + 0x12) = uVar15;
          *(short *)(ppbVar26 + 5) = sVar31;
          uVar15 = *(ushort *)((longlong)ppbVar26 + 0x12);
          *(short *)((longlong)ppbVar26 + 0x2c) = (short)(uVar15 + 1 >> 1) + sVar31;
          if (uVar15 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar26 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
            *(undefined4 *)(ppbVar26 + 8) = 0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
          }
          else {
            iVar19 = uVar15 - 1;
            *(short *)((longlong)ppbVar26 + 0x2a) =
                 ((short)(iVar19 / 0x1e) + (short)(iVar19 >> 0x1f)) -
                 (short)((longlong)iVar19 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
            *(undefined4 *)(ppbVar26 + 8) = 0;
            ppbVar26[7] = (byte *)0x0;
            ppbVar26[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) != 4) || (uVar21 = 1, (bVar3 & 2) == 0)) {
            uVar21 = uVar30;
          }
          if (uVar21 == 0) {
            uVar16 = 1;
          }
          else {
            *(undefined4 *)(ppbVar26 + 8) = 0;
            uVar16 = 0xf;
          }
          ppbVar26[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar26 + 0x12) = 0;
          ppbVar26[6] = (byte *)0x0;
          ppbVar26[4] = (byte *)0x0;
          ppbVar26[7] = (byte *)0x0;
          ppbVar26[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar26 + 0x14) = uVar16;
          *(uint *)(ppbVar26 + 8) = (uint)(uVar21 != 0);
          ppbVar26[7] = (byte *)0x0;
          ppbVar26[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar26[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar26 + 0x12) = 0;
          ppbVar26[6] = (byte *)0x0;
          ppbVar26[4] = (byte *)0x0;
          ppbVar26[7] = (byte *)0x0;
          ppbVar26[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar26 + 0x14) = 9;
          *(undefined4 *)(ppbVar26 + 8) = 0;
          ppbVar26[7] = (byte *)0x0;
          ppbVar26[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar26 & 4) != 0) {
      if (uStack_3b8._2_2_ != 0) {
        uVar17 = (ulonglong)*(ushort *)(lVar12 + 0x61 + (longlong)uStack_3b8._2_2_ * 2);
      }
      psVar13 = (short *)(pbVar1 + uVar17);
      ppbVar26[9] = (byte *)psVar13;
      sVar31 = *psVar13;
      ppbVar26[10] = (byte *)(psVar13 + 1);
      *(short *)(ppbVar26 + 0xb) = (sVar31 + 1) * 2;
    }
    param_2 = puStack_3c0;
    if (ppbVar26[1] != (byte *)0x0) {
      uStack_440 = 0x1005d3;
      func_0x(ppbVar26[1],ppbVar26);
      param_2 = puStack_3c0;
    }
  }
  else {
    ppbVar26 = (byte **)0x0;
  }
  uVar30 = 9;
  pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar12 + (0xfff - lStack_390) * 2) + lVar12);
  if ((*pbStack_f0 & 1) == 0) {
    sStack_f8 = 0;
    uStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
    uVar21 = (uint)*(ushort *)(lVar12 + 0xe);
    switch(*pbStack_f0 & 0xe) {
    default:
      uVar15 = *(ushort *)(pbStack_f0 + 2);
      uVar21 = (uint)uVar15;
      if (0x1f9d < uVar15 - 1) {
        uStack_440 = 0x1008a6;
        func_0x(pbStack_f0,6);
      }
      break;
    case 4:
      uVar21 = uVar30;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar21 = 1;
    }
    uStack_e8 = (byte **)CONCAT44(uStack_e8._4_4_,uVar21);
    uStack_da = (undefined2)(lVar12 + 0x2000);
    uStack_d8 = (undefined6)((ulonglong)(lVar12 + 0x2000) >> 0x10);
    ppbVar26 = (byte **)(ulonglong)uVar21;
  }
  else {
    sStack_f8 = 1;
    bVar3 = *pbStack_f0;
    uStack_e8 = ppbVar26;
    switch(bVar3 & 0x1c) {
    default:
      if ((char)pbStack_f0[1] < '\0') {
        uStack_f6 = (*(ushort *)(pbStack_f0 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_f0 + 1) >> 8;
        sVar31 = 3;
        uStack_e0._0_2_ = 3;
      }
      else {
        uStack_f6 = (ushort)pbStack_f0[1];
        uStack_e0._0_2_ = 2;
        sVar31 = 2;
      }
      uStack_dc = (short)(uStack_f6 + 1 >> 1) + sVar31;
      if (uStack_f6 < 0x1f) {
        uStack_e0._2_2_ = 0;
        uStack_f4 = 0;
        uStack_c8 = 0;
        lVar12 = lVar12 + 0x2000;
        uStack_d0 = (undefined2)lVar12;
        uStack_ce = (undefined2)((ulonglong)lVar12 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
      }
      else {
        iVar19 = uStack_f6 - 1;
        uStack_e0._2_2_ =
             ((short)(iVar19 / 0x1e) + (short)(iVar19 >> 0x1f)) -
             (short)((longlong)iVar19 * 0x88888889 >> 0x3f);
        uStack_f4 = 0;
        uStack_c8 = 0;
        lVar12 = lVar12 + 0x2000;
        uStack_d0 = (undefined2)lVar12;
        uStack_ce = (undefined2)((ulonglong)lVar12 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
      }
      break;
    case 4:
      if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_da = 0;
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_f4 = 0xf;
        uStack_c8 = 1;
        lVar12 = lVar12 + 0x2000;
        uStack_d0 = (undefined2)lVar12;
        uStack_ce = (undefined2)((ulonglong)lVar12 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
      }
      else {
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_da = 0;
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_f4 = 1;
        uStack_c8 = 0;
        lVar12 = lVar12 + 0x2000;
        uStack_d0 = (undefined2)lVar12;
        uStack_ce = (undefined2)((ulonglong)lVar12 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
      }
      break;
    case 8:
      uStack_e0._0_2_ = 0;
      uStack_e0._2_2_ = 0;
      uStack_dc = 0;
      uStack_da = 0;
      uStack_f6 = 0;
      uStack_d8 = 0;
      uStack_d2 = 0;
      uStack_f4 = 9;
      uStack_c8 = 0;
      lVar12 = lVar12 + 0x2000;
      uStack_d0 = (undefined2)lVar12;
      uStack_ce = (undefined2)((ulonglong)lVar12 >> 0x10);
      uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
      uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
    }
  }
  if (sStack_f8 == 0) {
    uVar21 = uStack_f4;
    if (uStack_f4 == 0) {
      uStack_f6 = 0;
      uVar21 = (uint)ppbVar26;
      uVar17 = (ulonglong)ppbVar26 & 0xffffffff;
      if ((*pbStack_f0 & 0x10) != 0) {
        uVar21 = uVar21 + 2 +
                 (*(ushort *)(pbStack_f0 + ((ulonglong)ppbVar26 & 0xffffffff)) + 7 >> 3);
        uVar17 = (ulonglong)uVar21;
      }
      uStack_e8 = (byte **)CONCAT44(uVar21,(undefined4)uStack_e8);
      if ((*pbStack_f0 & 0x20) == 0) {
        uStack_dc = 0;
        uStack_f4 = (uint)uVar17;
        uStack_e0 = (uint)uVar17;
      }
      else {
        puVar24 = (ushort *)(pbStack_f0 + uVar17);
        uStack_dc = *puVar24;
        if (uStack_dc == 0) {
          if ((((cRam0000000001c4b1eb != '\0') || ((bRam0000000001c5baf0 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         ((ulonglong)*puRam00000000011b9a80 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000011b9a78 * 8) + 8), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001c4b0db == '\0') && ((bRam0000000001c5baf0 & 2) == 0)) {
              uStack_440 = 0x1009f7;
              (*pcRam00000000011b9a18)(0x22,0x44,0x15);
            }
            else {
              uStack_418 = 0;
              uStack_440 = 0x100a1b;
              (*pcRam00000000011b9a10)(1,0x153bc18,0x165b8e8);
            }
          }
          uStack_440 = 0x100a2c;
          func_0x(pbStack_f0,3);
        }
        uStack_e0 = uStack_e8._4_4_ + 2 + (uint)uStack_dc * 2;
        if (0x1f9e < uStack_e0) {
          if (((cRam0000000001c4b1eb != '\0') || ((bRam0000000001c5baf0 & 1) != 0)) &&
             ((lVar12 = *(longlong *)
                         ((ulonglong)*puRam00000000011b9a80 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000011b9a78 * 8) + 8), lVar12 != 0 &&
              ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
               (*(char *)(lVar12 + 0x499) != '\0')))))) {
            if ((cRam0000000001c4b0db == '\0') && ((bRam0000000001c5baf0 & 2) == 0)) {
              uStack_440 = 0x100ad5;
              (*pcRam00000000011b9a18)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_418 = 0;
              uStack_440 = 0x100af9;
              (*pcRam00000000011b9a10)(1,0x153bc18,0x165b8e8,0x816);
            }
          }
          uStack_440 = 0x100b0a;
          func_0x(pbStack_f0,4);
        }
        uStack_f4 = puVar24[uStack_dc] & 0x7fff;
        if (uStack_f4 < uStack_e0) {
          if ((((cRam0000000001c4b1eb != '\0') || ((bRam0000000001c5baf0 & 1) != 0)) &&
              (lVar12 = *(longlong *)
                         ((ulonglong)*puRam00000000011b9a80 +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                           (ulonglong)*puRam00000000011b9a78 * 8) + 8), lVar12 != 0)) &&
             ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            if ((cRam0000000001c4b0db == '\0') && ((bRam0000000001c5baf0 & 2) == 0)) {
              uStack_440 = 0x100bae;
              (*pcRam00000000011b9a18)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_418 = 0;
              uStack_440 = 0x100bd4;
              (*pcRam00000000011b9a10)(1,0x153bc18,0x165b8e8,0x81d);
            }
          }
          uStack_440 = 0x100be5;
          func_0x(pbStack_f0,4);
        }
        uVar28 = (ulonglong)uStack_e0;
        uVar17 = (ulonglong)uStack_f4;
        do {
          if (-1 < (short)puVar24[(ulonglong)(uStack_dc - 1) + 1]) break;
          uVar27 = uVar28;
          if (uStack_dc != 1) {
            uVar27 = (ulonglong)
                     (*(ushort *)
                       (pbStack_f0 + (ulonglong)uStack_dc * 2 + (((ulonglong)uStack_e8 >> 0x20) - 2)
                       ) & 0x7fff);
          }
          uVar25 = (uint)uVar27;
          if ((uVar25 < (uint)uVar28) ||
             ((*(ushort *)(pbStack_f0 + (ulonglong)uStack_dc * 2 + ((ulonglong)uStack_e8 >> 0x20)) &
              0x7fff) < uVar25)) {
            uStack_440 = 0x100c5f;
            func_0x(pbStack_f0,7);
            uVar28 = (ulonglong)uStack_e0;
            uVar17 = (ulonglong)uStack_f4;
          }
          uVar21 = (uint)uVar17;
          if ((uVar25 < (uint)uVar28) || (uVar21 < uVar25)) goto code_r0x00100f8f;
          if (*(ushort *)(pbStack_f0 + uVar27) == 5) {
            uStack_f6 = uStack_f6 | 2;
            uStack_dc = uStack_dc - 1;
            uStack_ce = (undefined2)uVar27;
            if ((*(ushort *)(pbStack_f0 + (uVar27 & 0xffff) + 2) & 0x4000) == 0) {
              uStack_cc = uStack_cc & 0xc7ff;
            }
            else {
              uStack_cc = uStack_cc ^
                          (*(ushort *)(pbStack_f0 + (uVar27 & 0xffff) + 2) ^ uStack_cc) & 0x3800;
            }
            uStack_cc = (uStack_cc ^ *(ushort *)(pbStack_f0 + (uVar27 & 0xffff) + 2)) & 0x7ff ^
                        uStack_cc;
            break;
          }
          if (*(ushort *)(pbStack_f0 + uVar27) < 0x400) break;
          uStack_f6 = uStack_f6 | 1;
          uStack_dc = uStack_dc - 1;
        } while (uStack_dc != 0);
      }
      if ((*pbStack_f0 & 0x40) == 0) {
        uStack_d2 = 0;
        uStack_d0 = 0;
      }
      else {
        uStack_d2 = (undefined2)uVar17;
        uStack_d0 = (undefined2)(uVar17 >> 0x10);
        uStack_f4 = (int)uVar17 + 0xe;
        uStack_440 = 0x100d87;
        puVar14 = (ulonglong *)func_0x(&uStack_f6);
        uVar17 = *puVar14;
        uVar21 = 0;
        uVar18 = (ushort)(uVar17 >> 0x30);
        uVar15 = uVar18;
        if ((((uint)(int)(short)uVar18 >> 1 ^ (int)(short)uVar18) & 0x2000) != 0) {
          uVar15 = uVar18 & 0xdfff;
          if ((uVar17 & 0x4000000000000000) != 0) {
            uVar15 = uVar18 | 0x2000;
          }
        }
        if (uVar15 == 0xfffc) {
          uVar21 = ((uint)(uVar17 >> 0x20) & 0xffff) >> 5;
        }
        uStack_f4 = uStack_f4 + uVar21;
        uVar17 = (ulonglong)uStack_f4;
      }
      uVar21 = (uint)uVar17;
      if (((byte *)CONCAT62(uStack_d8,uStack_da) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_d8,uStack_da) < pbStack_f0 + uVar17)) {
        if (((cRam0000000001c4b1eb != '\0') || ((bRam0000000001c5baf0 & 1) != 0)) &&
           (((lVar12 = *(longlong *)
                        ((ulonglong)*puRam00000000011b9a80 +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                          (ulonglong)*puRam00000000011b9a78 * 8) + 8), lVar12 != 0 &&
             (lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0)) &&
            (*(char *)(lVar12 + 0x499) != '\0')))) {
          if ((cRam0000000001c4b0db == '\0') && ((bRam0000000001c5baf0 & 2) == 0)) {
            uStack_440 = 0x100e8d;
            (*pcRam00000000011b9a18)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_418 = 0;
            uStack_440 = 0x100eb3;
            (*pcRam00000000011b9a10)(1,0x153bc18,0x165b8e8,0x877);
          }
        }
        uStack_440 = 0x100ec4;
        func_0x(pbStack_f0,0x12);
        uVar21 = uStack_f4;
      }
      if (0x3f3b < uVar21 - 1) {
        if (((cRam0000000001c4b1eb != '\0') || ((bRam0000000001c5baf0 & 1) != 0)) &&
           ((lVar12 = *(longlong *)
                       ((ulonglong)*puRam00000000011b9a80 +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                         (ulonglong)*puRam00000000011b9a78 * 8) + 8), lVar12 != 0 &&
            ((lVar12 = *(longlong *)(lVar12 + 0x60), lVar12 != 0 &&
             (*(char *)(lVar12 + 0x499) != '\0')))))) {
          if ((cRam0000000001c4b0db == '\0') && ((bRam0000000001c5baf0 & 2) == 0)) {
            uStack_440 = 0x100f52;
            (*pcRam00000000011b9a18)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_418 = 0;
            uStack_440 = 0x100f78;
            (*pcRam00000000011b9a10)(1,0x153bc18,0x165b8e8,0x87c);
          }
        }
        uStack_440 = 0x100f89;
        func_0x(pbStack_f0,5);
        uVar21 = uStack_f4;
      }
    }
code_r0x00100f8f:
    if ((8 < uVar21) || (((*pbStack_f0 & 0xe) != 0 && ((*pbStack_f0 & 0xe) != 0xc)))) {
      uVar30 = uVar21;
    }
    bVar3 = *pbStack_f0 & 0x40;
    uVar21 = CONCAT22(uStack_d0,uStack_d2);
  }
  else {
    if (uStack_f4 == 0) {
      uStack_440 = 0x100fcd;
      func_0x(&uStack_f6);
      if (uStack_f4 == 0) {
        uStack_440 = 0x100fe3;
        func_0x(&uStack_f6);
      }
    }
    if ((8 < uStack_f4) || (((*pbStack_f0 & 0x1c) != 0 && ((*pbStack_f0 & 0x1c) != 0xc)))) {
      uVar30 = uStack_f4;
    }
    bVar3 = *pbStack_f0 & 2;
    uVar21 = uStack_c8;
  }
  if (bVar3 == 0) {
    uVar21 = uVar30;
  }
  uStack_440 = 0x101040;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar23 = auStack_438 + lVar12;
  lVar32 = (longlong)(int)(uVar21 - 0xe);
  *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x10105b;
  func_0x((longlong)&plStack_408 + lVar12);
  plVar29 = plStack_408;
  if (plStack_408 != (longlong *)0x0) {
    iVar19 = (int)(short)uStack_3fc;
    if (((*(ushort *)((longlong)plStack_408 + 0x62) >> 10 & 1) == 0) || (iVar19 < 3)) {
      if (((byte)*(undefined2 *)((longlong)plStack_408 + 0x62) >> 3 & 1) != 0) {
        if (iVar19 == 3) {
          iVar19 = 4;
        }
        else if (iVar19 < 2) goto code_r0x00101143;
        if ((((*(uint *)((longlong)plStack_408 + 100) & 8) != 0) &&
            (lVar22 = plStack_408[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0)) {
          uVar6 = *(undefined8 *)(lVar22 + 0x758);
          *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x101143;
          func_0x(uVar6,plVar29,iVar19);
        }
      }
code_r0x00101143:
      if ((((bRam0000000001c5b5b5 & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0))
         && ((2 < iVar19 &&
             (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 &&
              (lVar22 = *plVar29, lVar22 != 0)))))) {
        *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x101184;
        iVar11 = (*pcRam00000000011b6af8)(lVar22,0x2000,2,&puStack_3c0);
        if (iVar11 != 0) {
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x1011a6;
      func_0x(plVar29 + 0x13,iVar19);
      if ((iRam0000000001c5d770 != 0) && ((bRam0000000001c5b71f & 2) != 0)) {
        *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x1011c5;
        func_0x(plVar29,0,iVar19);
      }
      uStack_3fc = uStack_3fc & 0xffff0000;
      plStack_408 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x101081;
      func_0x(&plStack_408);
    }
  }
  *(undefined4 *)(&uStack_410 + lVar12) = 2;
  *(uint *)(&uStack_410 + lVar12 + -8) = uVar21 - 0xe;
  lVar22 = lStack_398;
  *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x1010a8;
  func_0x(lVar22,&plStack_3f0,auStack_3c8,(longlong)&plStack_408 + lVar12);
  plVar29 = plStack_3f0;
  uVar16 = *(undefined4 *)(*plStack_3f0 + 0x20);
  uVar4 = *(undefined2 *)(*plStack_3f0 + 0x24);
  iVar19 = (int)(short)uStack_3e4;
  if (((*(ushort *)((longlong)plStack_3f0 + 0x62) >> 10 & 1) == 0) || (iVar19 < 3)) {
    if (((byte)*(undefined2 *)((longlong)plStack_3f0 + 0x62) >> 3 & 1) != 0) {
      if (iVar19 == 3) {
        iVar19 = 4;
      }
      else if (iVar19 < 2) goto code_r0x00101233;
      if ((((*(uint *)((longlong)plStack_3f0 + 100) & 8) != 0) &&
          (lVar22 = plStack_3f0[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0)) {
        uVar6 = *(undefined8 *)(lVar22 + 0x758);
        *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x101233;
        func_0x(uVar6,plVar29,iVar19);
      }
    }
code_r0x00101233:
    if ((((bRam0000000001c5b5b5 & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
       ((2 < iVar19 &&
        (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 &&
         (lVar22 = *plVar29, lVar22 != 0)))))) {
      *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x101274;
      iVar11 = (*pcRam00000000011b6af8)(lVar22,0x2000,2,&uStack_3b8);
      if (iVar11 != 0) {
        LOCK();
        *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) & 0x3fffffff;
        UNLOCK();
        LOCK();
        *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) | 0x40000000;
        UNLOCK();
      }
    }
    *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x101296;
    func_0x(plVar29 + 0x13,iVar19);
    if ((iRam0000000001c5d770 != 0) && ((bRam0000000001c5b71f & 2) != 0)) {
      *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x1012b5;
      func_0x(plVar29,0,iVar19);
    }
    uStack_3e4 = uStack_3e4 & 0xffff0000;
    plStack_3f0 = (longlong *)0x0;
    lVar22 = lStack_398;
  }
  else {
    *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x1010e2;
    func_0x(&plStack_3f0);
  }
  puVar9 = puStack_388;
  *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x1012db;
  func_0x(lVar22,puVar9,0,0);
  if (*pcRam00000000011b91f0 != '\0') {
    uVar15 = *(ushort *)(*(longlong *)(lVar22 + 0x20) + 0x6b8);
    bVar8 = false;
    lVar7 = *(longlong *)((ulonglong)(uVar15 >> 8) * 8 + 0x1c675d0);
    lVar20 = lStack_390;
    if (((lVar7 != 0) &&
        (plVar29 = (longlong *)(lVar7 + ((ulonglong)(uVar15 & 0xff) + 0x500) * 8),
        plVar29 != (longlong *)0x0)) && (*plVar29 != 0)) {
      LOCK();
      plVar29 = (longlong *)(*plVar29 + 0x150);
      lVar7 = *plVar29;
      *plVar29 = *plVar29 + lVar32;
      UNLOCK();
      if ((bRam0000000001c67570 & 0x20) != 0) {
        plVar29 = (longlong *)0x0;
        if (lRam0000000001c675d0 != 0) {
          plVar29 = (longlong *)(lRam0000000001c675d0 + 0x2800);
        }
        if ((plVar29 != (longlong *)0x0) && (*plVar29 != 0)) {
          LOCK();
          plVar29 = (longlong *)(*plVar29 + 0x150);
          *plVar29 = *plVar29 + lVar32;
          UNLOCK();
        }
      }
      bVar8 = true;
      lVar20 = lVar7 + lVar32;
    }
    if (((uRam0000000001c5c054 & 0x20000) != 0) && (bVar8)) {
      uStack_370 = 0x10000;
      uStack_368 = 0;
      pplStack_360 = &plStack_348;
      puStack_358 = auStack_338;
      uStack_128 = 0;
      uStack_350 = 0;
      uStack_120 = 0;
      plStack_348 = &lStack_118;
      uStack_340 = 0x14;
      uStack_108 = (uint)*(ushort *)(*(longlong *)(lVar22 + 0x20) + 0x6b8);
      lStack_118 = lVar20;
      lStack_110 = lVar32;
      *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x10142d;
      func_0x(auStack_378);
    }
  }
  *param_2 = uVar16;
  *(undefined2 *)(param_2 + 1) = uVar4;
  *(undefined2 *)((longlong)param_2 + 6) = auStack_3c8[0];
  *(undefined8 *)(auStack_438 + lVar12 + -8) = 0x101444;
  func_0x(&plStack_3f0);
LAB_:
  *(undefined8 *)(puVar23 + -8) = 0x101468;
  func_0x(&plStack_408);
  uVar17 = uStack_48 ^ (ulonglong)&plStack_408;
  *(undefined8 *)(puVar23 + -8) = 0x10147a;
  func_0x(uVar17);
  return;
}

