
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong *param_2,undefined *param_3,undefined4 *param_4)

{
  char *pcVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined8 *puVar4;
  code *pcVar5;
  short *psVar6;
  longlong lVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  bool bVar10;
  ushort uVar11;
  uint uVar12;
  undefined4 uVar13;
  int iVar14;
  uint uVar15;
  longlong lVar16;
  undefined8 uVar17;
  ulonglong *puVar18;
  uint *puVar19;
  byte bVar20;
  uint uVar21;
  ulonglong uVar22;
  byte bVar23;
  short sVar24;
  ushort uVar25;
  byte *pbVar26;
  longlong lVar27;
  uint uVar28;
  longlong lVar30;
  undefined *puVar31;
  undefined *puVar32;
  ushort *puVar33;
  undefined4 *puVar34;
  uint uVar35;
  uint uVar36;
  ulonglong uVar37;
  longlong *plVar38;
  uint *puVar39;
  longlong lVar40;
  uint *puVar41;
  uint uVar42;
  longlong unaff_GS_OFFSET;
  char cVar43;
  undefined4 extraout_XMM0_Da;
  char acStackX_20 [4];
  uint uStackX_24;
  undefined8 uStack_48;
  uint *puVar29;
  
  uStack_48 = 0x100017;
  lVar16 = func_0x();
  lVar16 = -lVar16;
  puVar32 = &stack0xffffffffffffffc0 + lVar16;
  pcVar1 = acStackX_20 + lVar16;
  *(undefined8 *)(&stack0x000000c0 + lVar16) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000020b0 + lVar16) = _DAT_ ^ (ulonglong)pcVar1;
  *(undefined4 **)(&stack0x000000b0 + lVar16) = param_4;
  *(undefined **)(&stack0x00000058 + lVar16) = param_3;
  *(longlong **)(&stack0x00000038 + lVar16) = param_2;
  *(longlong **)(&stack0x00000050 + lVar16) = param_1;
  *(undefined8 *)(&stack0x00000098 + lVar16) = *(undefined8 *)(&stack0x00002130 + lVar16);
  puVar29 = (uint *)0x0;
  uVar28 = 0;
  *(undefined4 *)(&stack0x00000088 + lVar16) = 0;
  *(undefined4 *)(&stack0x00000064 + lVar16) = 0;
  *(undefined4 *)(&stack0x00000068 + lVar16) = 0;
  *(undefined8 *)(&stack0x000000d0 + lVar16) = 0;
  *(undefined8 *)(&stack0x000000d8 + lVar16) = 0;
  *(undefined4 *)(&stack0x000000e0 + lVar16) = 0;
  *(undefined8 *)(&stack0x000000e8 + lVar16) = 0;
  *(undefined4 *)(&stack0x000000f0 + lVar16) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar16) = 0;
  *(undefined8 *)(&stack0x00000048 + lVar16) = 0;
  lVar40 = param_2[1];
  *(longlong *)(&stack0x000000b8 + lVar16) = lVar40;
  *(undefined4 *)(&stack0x0000002c + lVar16) = *(undefined4 *)(*(longlong *)(lVar40 + 0x80) + 0x14);
  *(undefined4 *)(&stack0x00000060 + lVar16) = 0;
  *(undefined8 *)(&stack0x000000a0 + lVar16) = 0;
  cVar43 = '\0';
  *pcVar1 = '\0';
  (&stack0x00000028)[lVar16] = 0;
  *param_4 = 0;
  lVar30 = *(longlong *)(param_1[3] + 8);
  if (*(int *)(lVar30 + 0x100) == 2) {
    if ((*(byte *)(lVar30 + 0x42) & 4) == 0) {
      uVar37 = (ulonglong)*(uint *)(lVar30 + 0xb0);
      if (0x1f9e < *(uint *)(lVar30 + 0xb0)) {
        uVar37 = 0x1f9e;
      }
    }
    else {
      uVar37 = 0x1f9e;
    }
    *(int *)(&stack0x00000060 + lVar16) = (int)uVar37;
    uVar22 = uVar37 + 0xf;
    if (uVar22 <= uVar37) {
      uVar22 = 0xffffffffffffff0;
    }
    uVar22 = uVar22 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_48 + lVar16) = 0x100125;
    func_0x();
    puVar32 = &stack0xffffffffffffffc0 + -uVar22 + lVar16;
    *(char **)(&stack0x000000a0 + lVar16) = acStackX_20 + -uVar22 + lVar16;
  }
  lVar30 = param_1[1];
  puVar4 = *(undefined8 **)(lVar30 + 0x10);
  if (puVar4 != (undefined8 *)0x0) {
    pcVar5 = *(code **)*puVar4;
    *(undefined8 *)(puVar32 + -8) = 0x100149;
    uVar17 = (*pcVar5)(puVar4);
    *(undefined8 *)(param_1[1] + 8) = uVar17;
    lVar30 = param_1[1];
  }
  psVar6 = *(short **)(lVar30 + 8);
  *(undefined4 *)(&stack0x00000034 + lVar16) = 0;
  puVar39 = *(uint **)(*(longlong *)(lVar40 + 0x80) + 0x18);
  *(uint **)(&stack0x00000078 + lVar16) = puVar39;
  uVar42 = *(uint *)(&stack0x0000002c + lVar16);
  if (uVar42 != 0) {
    *(undefined8 *)(&stack0x00000070 + lVar16) = 0;
    lVar40 = -0x1ca8e10;
    puVar19 = puVar29;
    puVar31 = puVar32;
    puVar41 = puVar29;
    do {
      uVar13 = SUB84(puVar19,0);
      puVar32 = puVar31;
      puVar19 = puVar29;
      if (0x19 < *(byte *)(puVar39 + 0x10)) {
LAB_:
        *(undefined8 *)(puVar31 + 0x20) = 0x810a18;
        *(undefined8 *)(puVar31 + -8) = 0x102876;
        (*_DAT_)(1,0xc15870,0xc1bb70,0x203);
        goto code_r0x0010287c;
      }
      uVar15 = 0;
      switch((ulonglong)
             *(uint *)(lVar40 + 0x1dab99c + (longlong)(char)*(byte *)(puVar39 + 0x10) * 4) + lVar40)
      {
      case 0x1001ae:
        iVar14 = puVar39[0x10] << 0xc;
        uVar42 = (uint)*(ushort *)(puVar39 + 0xf);
        if (*psVar6 == 0) {
          uVar35 = *puVar39;
          if ((uVar35 & 0xc0000000) == 0x80000000) {
            *(undefined8 *)(puVar31 + -8) = 0x100a57;
            iVar14 = func_0x(psVar6 + 1);
            if (iVar14 == 0) goto code_r0x001027c5;
            *(undefined8 *)(puVar31 + -8) = 0x100a76;
            puVar19 = (uint *)func_0x(psVar6 + 0x15,puVar39,(longlong)&uStackX_24 + lVar16,
                                              &stack0x000000a8 + lVar16);
          }
          else {
            uVar36 = uVar28;
            if ((iVar14 < 0) || ((*(byte *)((longlong)puVar39 + 6) & 0x10) != 0)) {
              pbVar26 = *(byte **)(psVar6 + 4);
              if ((*pbVar26 & 0x10) == 0) {
                if ((1 << (*pbVar26 & 0xe) & 0x1105U) != 0) goto code_r0x0010022f;
                uVar12 = uVar28;
                bVar10 = true;
code_r0x0010023f:
                if (iVar14 < 0) goto code_r0x00100285;
code_r0x00100243:
                if ((!bVar10) && ((*(byte *)((longlong)puVar39 + 6) & 0x10) != 0)) {
                  puVar34 = *(undefined4 **)(puVar39 + 2);
                  *(undefined4 *)((longlong)&uStackX_24 + lVar16) = *puVar34;
                  puVar19 = puVar34 + 1;
                  break;
                }
                goto code_r0x00100297;
              }
              uVar12 = *(uint *)(psVar6 + 8);
              if ((int)uVar12 <= (int)uVar35) {
code_r0x0010022f:
                uVar12 = ~(uint)(*(ushort *)((longlong)puVar39 + 6) >> 4) & 1;
                bVar10 = false;
                goto code_r0x0010023f;
              }
              if ((uint)*(ushort *)(pbVar26 + uVar12) < (uint)*(ushort *)(puVar39 + 1))
              goto code_r0x0010022f;
              if (-1 < iVar14) goto code_r0x00100297;
              uVar21 = *(ushort *)(puVar39 + 1) - 1;
              uVar12 = pbVar26[(ulonglong)(uVar21 >> 3) + (ulonglong)uVar12 + 2] >>
                       ((byte)uVar21 & 7) & 1;
              bVar10 = true;
code_r0x00100285:
              if (uVar12 == 0) goto code_r0x00100243;
code_r0x0010028f:
              *(uint *)((longlong)&uStackX_24 + lVar16) = uVar36;
            }
            else {
code_r0x00100297:
              if ((int)uVar35 < 0) {
                if (*(int *)(psVar6 + 2) == 0) {
                  psVar6[1] = 0;
                  uVar42 = *(uint *)(psVar6 + 8);
                  uVar37 = (ulonglong)uVar42;
                  *(uint *)(psVar6 + 10) = uVar42;
                  pbVar26 = *(byte **)(psVar6 + 4);
                  bVar23 = *pbVar26;
                  if ((bVar23 & 0x10) != 0) {
                    uVar42 = uVar42 + 2 + (*(ushort *)(pbVar26 + uVar37) + 7 >> 3);
                    uVar37 = (ulonglong)uVar42;
                    *(uint *)(psVar6 + 10) = uVar42;
                    bVar23 = *pbVar26;
                  }
                  if ((bVar23 & 0x20) == 0) {
                    *(int *)(psVar6 + 2) = (int)uVar37;
                    psVar6[0xe] = 0;
                    *(int *)(psVar6 + 0xc) = (int)uVar37;
                  }
                  else {
                    puVar33 = (ushort *)(pbVar26 + uVar37);
                    uVar11 = *puVar33;
                    psVar6[0xe] = uVar11;
                    if (uVar11 == 0) {
                      if ((((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                          (lVar40 = *(longlong *)
                                     ((ulonglong)*puRam00000000007123a0 +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0)) &&
                         ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                          (*(char *)(lVar40 + 0x499) != '\0')))) {
                        if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                          *(undefined8 *)(puVar31 + -8) = 0x100440;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar31 + 0x20) = 0;
                          *(undefined8 *)(puVar31 + -8) = 0x100466;
                          (*_DAT_)(1,0xa94538,0xbb4208,0x80f);
                        }
                      }
                      uVar17 = *(undefined8 *)(psVar6 + 4);
                      *(undefined8 *)(puVar31 + -8) = 0x100474;
                      func_0x(uVar17,3);
                      uVar37 = (ulonglong)*(uint *)(psVar6 + 10);
                      uVar11 = psVar6[0xe];
                    }
                    uVar42 = (int)uVar37 + (uVar11 + 1) * 2;
                    *(uint *)(psVar6 + 0xc) = uVar42;
                    if (0x1f9e < uVar42) {
                      if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                         ((lVar40 = *(longlong *)
                                     ((ulonglong)*puRam00000000007123a0 +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                          ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                           (*(char *)(lVar40 + 0x499) != '\0')))))) {
                        if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                          *(undefined8 *)(puVar31 + -8) = 0x100513;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar31 + 0x20) = 0;
                          *(undefined8 *)(puVar31 + -8) = 0x100539;
                          (*_DAT_)(1,0xa94538,0xbb4208,0x816);
                        }
                      }
                      uVar17 = *(undefined8 *)(psVar6 + 4);
                      *(undefined8 *)(puVar31 + -8) = 0x100547;
                      func_0x(uVar17,4);
                      uVar11 = psVar6[0xe];
                      uVar42 = *(uint *)(psVar6 + 0xc);
                    }
                    uVar37 = (ulonglong)uVar11;
                    uVar11 = puVar33[uVar37];
                    *(uint *)(psVar6 + 2) = uVar11 & 0x7fff;
                    if ((uVar11 & 0x7fff) < uVar42) {
                      if ((((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                          (lVar40 = *(longlong *)
                                     ((ulonglong)*puRam00000000007123a0 +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0)) &&
                         ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                          (*(char *)(lVar40 + 0x499) != '\0')))) {
                        if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                          *(undefined8 *)(puVar31 + -8) = 0x1005e4;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar31 + 0x20) = 0;
                          *(undefined8 *)(puVar31 + -8) = 0x10060a;
                          (*_DAT_)(1,0xa94538,0xbb4208,0x81d);
                        }
                      }
                      uVar17 = *(undefined8 *)(psVar6 + 4);
                      *(undefined8 *)(puVar31 + -8) = 0x100618;
                      func_0x(uVar17,4);
                      uVar37 = (ulonglong)(ushort)psVar6[0xe];
                    }
                    if ((short)puVar33[(ulonglong)((int)uVar37 - 1) + 1] < 0) {
                      lVar40 = *(longlong *)(psVar6 + 4);
                      do {
                        lVar30 = (ulonglong)*(uint *)(psVar6 + 10) + lVar40;
                        if ((int)uVar37 == 1) {
                          uVar42 = *(uint *)(psVar6 + 0xc);
                          uVar11 = *(ushort *)(lVar30 + uVar37 * 2);
                          uVar35 = uVar42;
code_r0x0010067c:
                          if ((uVar11 & 0x7fff) < uVar42) goto code_r0x00100680;
                        }
                        else {
                          uVar42 = *(ushort *)(lVar30 + -2 + uVar37 * 2) & 0x7fff;
                          uVar35 = *(uint *)(psVar6 + 0xc);
                          uVar11 = *(ushort *)(lVar30 + uVar37 * 2);
                          if (uVar35 <= uVar42) goto code_r0x0010067c;
code_r0x00100680:
                          *(undefined8 *)(puVar31 + -8) = 0x10068d;
                          func_0x(lVar40,7);
                          uVar35 = *(uint *)(psVar6 + 0xc);
                        }
                        if ((uVar42 < uVar35) || (*(uint *)(psVar6 + 2) < uVar42))
                        goto code_r0x00100982;
                        lVar40 = *(longlong *)(psVar6 + 4);
                        if (*(ushort *)((ulonglong)uVar42 + lVar40) == 5) {
                          psVar6[1] = psVar6[1] | 2;
                          psVar6[0xe] = psVar6[0xe] + -1;
                          psVar6[0x15] = (short)uVar42;
                          lVar40 = (ulonglong)(uVar42 & 0xffff) + *(longlong *)(psVar6 + 4);
                          uVar11 = psVar6[0x16] & 0xc7ffU;
                          if ((*(ushort *)(lVar40 + 2) >> 0xe & 1) != 0) {
                            uVar11 = *(ushort *)(lVar40 + 2) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                          }
                          psVar6[0x16] = uVar11;
                          psVar6[0x16] = (uVar11 ^ *(ushort *)(lVar40 + 2)) & 0x7ff ^ uVar11;
                          goto code_r0x0010075e;
                        }
                        if (*(ushort *)((ulonglong)uVar42 + lVar40) < 0x400) goto code_r0x0010075e;
                        psVar6[1] = psVar6[1] | 1;
                        uVar11 = psVar6[0xe] - 1;
                        psVar6[0xe] = uVar11;
                        if (uVar11 == 0) goto code_r0x0010075e;
                        uVar37 = (ulonglong)uVar11;
                      } while ((short)puVar33[(ulonglong)(uVar11 - 1) + 1] < 0);
                      uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
                      pbVar26 = *(byte **)(psVar6 + 4);
                    }
                    else {
code_r0x0010075e:
                      uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
                      pbVar26 = *(byte **)(psVar6 + 4);
                    }
                  }
                  if ((*pbVar26 & 0x40) == 0) {
                    *(undefined4 *)(psVar6 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
                    *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
                    *(undefined8 *)(puVar31 + -8) = 0x100792;
                    puVar18 = (ulonglong *)func_0x(psVar6 + 1);
                    uVar25 = (ushort)(*puVar18 >> 0x30);
                    uVar11 = uVar25;
                    if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
                      uVar11 = uVar25 & 0xdfff;
                      if ((uVar25 >> 0xe & 1) != 0) {
                        uVar11 = uVar25 | 0x2000;
                      }
                    }
                    if (uVar11 == 0xfffc) {
                      uVar15 = (uint)((*puVar18 >> 0x20 & 0xffff) >> 5);
                    }
                    *(uint *)(psVar6 + 2) = *(int *)(psVar6 + 2) + uVar15;
                    uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
                  }
                  iVar14 = (int)uVar37;
                  if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar6 + 0xf) < uVar37 + *(longlong *)(psVar6 + 4))) {
                    if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                       (((lVar40 = *(longlong *)
                                    ((ulonglong)*puRam00000000007123a0 +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                         (lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0)) &&
                        (*(char *)(lVar40 + 0x499) != '\0')))) {
                      if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                        *(undefined8 *)(puVar31 + -8) = 0x10088e;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar31 + 0x20) = 0;
                        *(undefined8 *)(puVar31 + -8) = 0x1008b4;
                        (*_DAT_)(1,0xa94538,0xbb4208,0x877);
                      }
                    }
                    uVar17 = *(undefined8 *)(psVar6 + 4);
                    *(undefined8 *)(puVar31 + -8) = 0x1008c2;
                    func_0x(uVar17,0x12);
                    iVar14 = *(int *)(psVar6 + 2);
                  }
                  if (0x3f3b < iVar14 - 1U) {
                    if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                       ((lVar40 = *(longlong *)
                                   ((ulonglong)*puRam00000000007123a0 +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                        ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                         (*(char *)(lVar40 + 0x499) != '\0')))))) {
                      if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                        *(undefined8 *)(puVar31 + -8) = 0x10094e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar31 + 0x20) = 0;
                        *(undefined8 *)(puVar31 + -8) = 0x100974;
                        (*_DAT_)(1,0xa94538,0xbb4208,0x87c);
                      }
                    }
                    uVar17 = *(undefined8 *)(psVar6 + 4);
                    *(undefined8 *)(puVar31 + -8) = 0x100982;
                    func_0x(uVar17,5);
                  }
                }
code_r0x00100982:
                sVar24 = -*(short *)puVar39;
                if ((*(byte *)((longlong)puVar39 + 6) & 0x10) != 0) {
                  bVar23 = **(byte **)(psVar6 + 4);
                  if ((bVar23 & 0x10) == 0) {
                    if ((1 << (bVar23 & 0xe) & 0x1105U) != 0) {
code_r0x001009f6:
                      puVar34 = *(undefined4 **)(puVar39 + 2);
                      *(undefined4 *)((longlong)&uStackX_24 + lVar16) = *puVar34;
                      puVar19 = puVar34 + 1;
                      break;
                    }
                  }
                  else if (((int)*(uint *)(psVar6 + 8) <= (int)*puVar39) ||
                          (*(ushort *)(*(byte **)(psVar6 + 4) + *(uint *)(psVar6 + 8)) <
                           *(ushort *)(puVar39 + 1))) goto code_r0x001009f6;
                }
                lVar40 = (longlong)sVar24;
                puVar19 = *(uint **)(psVar6 + 4);
                if ((uint)(ushort)psVar6[0xe] < (uint)(int)sVar24) goto code_r0x0010028f;
                uVar42 = *(uint *)(psVar6 + 10);
                if (sVar24 == 1) {
                  uVar15 = *(uint *)(psVar6 + 0xc);
                  uVar42 = *(ushort *)((longlong)puVar19 + lVar40 * 2 + (ulonglong)uVar42) & 0x7fff;
code_r0x00100a2a:
                  if (uVar42 < uVar15) goto code_r0x00100a2e;
                }
                else {
                  uVar15 = *(ushort *)((longlong)puVar19 + lVar40 * 2 + ((ulonglong)uVar42 - 2)) &
                           0x7fff;
                  uVar42 = *(ushort *)((longlong)puVar19 + lVar40 * 2 + (ulonglong)uVar42) & 0x7fff;
                  puVar19 = *(uint **)(psVar6 + 4);
                  if (*(uint *)(psVar6 + 0xc) <= uVar15) goto code_r0x00100a2a;
code_r0x00100a2e:
                  *(undefined8 *)(puVar31 + -8) = 0x100a3b;
                  func_0x(puVar19,7);
                  puVar19 = *(uint **)(psVar6 + 4);
                }
                *(uint *)((longlong)&uStackX_24 + lVar16) = uVar42 - uVar15;
                puVar19 = (uint *)((longlong)puVar19 + (ulonglong)uVar15);
              }
              else {
                uVar11 = *(ushort *)((longlong)puVar39 + 6);
                if ((uVar11 & 8) != 0) {
                  puVar19 = (uint *)0x818f74;
                  if ((*(byte *)((longlong)(int)uVar35 + *(longlong *)(psVar6 + 4)) &
                      (byte)(1 << ((byte)uVar11 & 7))) == 0) {
                    puVar19 = (uint *)0x819598;
                  }
                  *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 1;
                  break;
                }
                if ((uVar11 & 0x10) != 0) {
                  bVar23 = **(byte **)(psVar6 + 4);
                  if ((bVar23 & 0x10) == 0) {
                    if ((1 << (bVar23 & 0xe) & 0x1105U) != 0) {
code_r0x001002f6:
                      puVar19 = *(uint **)(puVar39 + 2) + 1;
                      uVar36 = **(uint **)(puVar39 + 2);
                      if ((uVar42 != 0) && (uVar36 != uVar42)) {
                        *(undefined8 *)(puVar31 + 0x20) = 0;
                        *(undefined8 *)(puVar31 + -8) = 0x10032e;
                        (*_DAT_)(1,0xc422a8,0xc40ca8,0x381);
                        *(uint *)((longlong)&uStackX_24 + lVar16) = uVar36;
                        break;
                      }
                      goto code_r0x0010028f;
                    }
                  }
                  else if (((int)*(uint *)(psVar6 + 8) <= (int)uVar35) ||
                          (*(ushort *)(*(byte **)(psVar6 + 4) + *(uint *)(psVar6 + 8)) <
                           *(ushort *)(puVar39 + 1))) goto code_r0x001002f6;
                }
                lVar40 = *(longlong *)(psVar6 + 4);
                *(uint *)((longlong)&uStackX_24 + lVar16) = uVar42;
                puVar19 = (uint *)((int)uVar35 + lVar40);
              }
            }
          }
        }
        else {
          *(undefined4 *)(&stack0x00000080 + lVar16) = 0;
          *(undefined **)(puVar31 + 0x20) = &stack0x00000080 + lVar16;
          *(undefined8 *)(puVar31 + -8) = 0x100a9b;
          puVar19 = (uint *)func_0x(psVar6 + 1,puVar39);
          if ((((*psVar6 != 0) && (plVar38 = *(longlong **)(psVar6 + 8), plVar38 != (longlong *)0x0)
               ) && (*plVar38 != 0)) &&
             (((*(byte *)((longlong)puVar39 + 6) & 8) == 0 &&
              ((*(uint *)(&stack0x00000080 + lVar16) & 1) == 0)))) {
            if ((puVar19 == (uint *)0x0) || (puVar19 == (uint *)0x818f74)) goto code_r0x001027c5;
            *(uint *)(puVar31 + 0x38) = *(uint *)(&stack0x00000080 + lVar16);
            *(longlong *)(puVar31 + 0x30) = (longlong)&uStackX_24 + lVar16;
            *(undefined4 *)(puVar31 + 0x28) = 0;
            *(undefined8 *)(puVar31 + 0x20) = 0;
            uVar13 = *(undefined4 *)((longlong)&uStackX_24 + lVar16);
            *(undefined8 *)(puVar31 + -8) = 0x100b16;
            puVar19 = (uint *)func_0x(plVar38,puVar39,puVar19,uVar13);
          }
        }
        break;
      case 0x100b1e:
        if ((puVar39[0x10] & 0x80000) != 0) {
          if (*psVar6 == 0) {
            pbVar26 = *(byte **)(psVar6 + 4);
            if ((*pbVar26 & 0x10) == 0) {
              if ((1 << (*pbVar26 & 0xe) & 0x1105U) != 0) {
code_r0x00100b83:
                uVar15 = ~(uint)(*(ushort *)((longlong)puVar39 + 6) >> 4) & 1;
              }
            }
            else {
              uVar42 = *(uint *)(psVar6 + 8);
              if ((int)*puVar39 < (int)uVar42) {
                if ((uint)*(ushort *)(pbVar26 + uVar42) < (uint)*(ushort *)(puVar39 + 1))
                goto code_r0x00100b83;
                uVar15 = *(ushort *)(puVar39 + 1) - 1;
                uVar15 = pbVar26[(ulonglong)uVar42 + (ulonglong)(uVar15 >> 3) + 2] >>
                         ((byte)uVar15 & 7) & 1;
              }
              else {
                uVar15 = ~(uint)(*(ushort *)((longlong)puVar39 + 6) >> 4) & 1;
              }
            }
          }
          else {
            uVar11 = *(ushort *)(puVar39 + 1);
            if ((ushort)psVar6[1] < uVar11) {
              uVar15 = ~(uint)(*(ushort *)((longlong)puVar39 + 6) >> 4) & 1;
            }
            else {
              bVar23 = *(byte *)((longlong)((int)(uVar11 - 1) / 2) + (ulonglong)(ushort)psVar6[0xc]
                                + *(longlong *)(psVar6 + 4));
              bVar20 = bVar23 >> 4;
              if ((uVar11 & 1) != 0) {
                bVar20 = bVar23 & 0xf;
              }
              uVar15 = (uint)(bVar20 == 0);
            }
          }
          if (uVar15 != 0) {
            *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 0;
            puVar19 = (uint *)0x0;
            break;
          }
        }
      case 0x100c14:
        uVar11 = *(ushort *)(puVar39 + 0xf);
        if ((*(byte *)((longlong)puVar39 + 6) & 0x10) == 0) {
code_r0x00100c3d:
          puVar19 = (uint *)((longlong)(int)*puVar39 + *(longlong *)(psVar6 + 4));
          uVar42 = (uint)uVar11;
        }
        else {
          bVar23 = **(byte **)(psVar6 + 4);
          if ((bVar23 & 0x10) == 0) {
            if ((1 << (bVar23 & 0xe) & 0x1105U) == 0) goto code_r0x00100c3d;
          }
          else if (((int)*puVar39 < (int)*(uint *)(psVar6 + 8)) &&
                  (*(ushort *)(puVar39 + 1) <=
                   *(ushort *)(*(byte **)(psVar6 + 4) + *(uint *)(psVar6 + 8))))
          goto code_r0x00100c3d;
          puVar19 = *(uint **)(puVar39 + 2) + 1;
          uVar42 = **(uint **)(puVar39 + 2);
          if ((uVar11 != 0) && (uVar42 != uVar11)) {
            *(undefined8 *)(puVar31 + 0x20) = 0;
            *(undefined8 *)(puVar31 + -8) = 0x100c9d;
            (*_DAT_)(1,0xc422a8,0xc40ca8,0x381);
            *(uint *)((longlong)&uStackX_24 + lVar16) = uVar42;
            break;
          }
        }
        *(uint *)((longlong)&uStackX_24 + lVar16) = uVar42;
        break;
      case 0x100ca5:
        if ((puVar39[0x10] & 0x80000) != 0) {
          if (*psVar6 == 0) {
            pbVar26 = *(byte **)(psVar6 + 4);
            if ((*pbVar26 & 0x10) == 0) {
              uVar35 = uVar15;
              if ((1 << (*pbVar26 & 0xe) & 0x1105U) != 0) {
code_r0x00100d0a:
                uVar35 = ~(uint)(*(ushort *)((longlong)puVar39 + 6) >> 4) & 1;
              }
            }
            else {
              uVar35 = *(uint *)(psVar6 + 8);
              if ((int)*puVar39 < (int)uVar35) {
                if ((uint)*(ushort *)(pbVar26 + uVar35) < (uint)*(ushort *)(puVar39 + 1))
                goto code_r0x00100d0a;
                uVar36 = *(ushort *)(puVar39 + 1) - 1;
                uVar35 = pbVar26[(ulonglong)uVar35 + (ulonglong)(uVar36 >> 3) + 2] >>
                         ((byte)uVar36 & 7) & 1;
              }
              else {
                uVar35 = ~(uint)(*(ushort *)((longlong)puVar39 + 6) >> 4) & 1;
              }
            }
          }
          else {
            uVar11 = *(ushort *)(puVar39 + 1);
            if ((ushort)psVar6[1] < uVar11) {
              uVar35 = ~(uint)(*(ushort *)((longlong)puVar39 + 6) >> 4) & 1;
            }
            else {
              bVar23 = *(byte *)((longlong)((int)(uVar11 - 1) / 2) + (ulonglong)(ushort)psVar6[0xc]
                                + *(longlong *)(psVar6 + 4));
              bVar20 = bVar23 >> 4;
              if ((uVar11 & 1) != 0) {
                bVar20 = bVar23 & 0xf;
              }
              uVar35 = (uint)(bVar20 == 0);
            }
          }
          if (uVar35 != 0) {
            puVar19 = (uint *)0x0;
            *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 0;
            lVar40 = *(longlong *)(puVar39 + 0x12);
            if (((*(int *)(lVar40 + 0x10) != 10) && ((*(byte *)(lVar40 + 0xc) & 0x40) != 0)) &&
               (plVar38 = *(longlong **)(&stack0x00002138 + lVar16), plVar38 != (longlong *)0x0)) {
              uVar15 = *(uint *)(lVar40 + 8);
              do {
                uVar35 = *(uint *)(plVar38 + 1);
                if ((ulonglong)uVar15 < (ulonglong)uVar35 + 0x100) {
                  if ((uVar35 <= uVar15) &&
                     ((*(uint *)((longlong)plVar38 + (ulonglong)(uVar15 - uVar35 >> 5) * 4 + 0xc) &
                      1 << ((byte)(uVar15 - uVar35) & 0x1f)) != 0)) {
                    puVar34 = (undefined4 *)((longlong)puVar41 * 0x50 + param_2[2]);
                    iVar14 = *(int *)(*(longlong *)(puVar34 + 0x12) + 0x10);
                    if (((*(byte *)(*(longlong *)(puVar34 + 0x12) + 0xc) & 0x40) != 0) &&
                       (0x10 < *(ushort *)(puVar34 + 0xf))) {
                      if (iVar14 == 3) {
                        lVar40 = param_1[3];
                        *(undefined8 *)(puVar31 + -8) = 0x102b65;
                        func_0x(lVar40);
                        *(undefined8 *)(puVar31 + -8) = 0x102b6a;
                        func_0x();
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                      }
                      if (iVar14 == 6) goto code_r0x00102b6b;
                    }
                    if (iVar14 == 7) {
code_r0x00102b6b:
                      *(undefined8 *)(puVar31 + -8) = 0x102b70;
                      func_0x();
                      pcVar5 = (code *)swi(3);
                      (*pcVar5)();
                      return;
                    }
                    if (iVar14 == 2) {
                      lVar40 = (ulonglong)*(uint *)(param_3 + 4) * 0x40;
                      uVar13 = puVar34[1];
                      uVar8 = puVar34[2];
                      uVar9 = puVar34[3];
                      puVar2 = (undefined4 *)(lVar40 + 8 + *(longlong *)(param_3 + 8));
                      *puVar2 = *puVar34;
                      puVar2[1] = uVar13;
                      puVar2[2] = uVar8;
                      puVar2[3] = uVar9;
                      *(undefined4 *)(lVar40 + *(longlong *)(param_3 + 8)) =
                           *(undefined4 *)(&stack0x00000034 + lVar16);
                      pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
                      *pbVar26 = *pbVar26 | 1;
                      pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
                      *pbVar26 = *pbVar26 & 0xfb;
                      pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
                      *pbVar26 = *pbVar26 & 0xfd;
                      lVar40 = lVar40 + *(longlong *)(param_3 + 8);
                      *(undefined8 *)(lVar40 + 0x20) = 0;
                      *(undefined4 *)(lVar40 + 0x28) = 0;
                      *(uint *)(lVar40 + 0x2c) = *(uint *)(lVar40 + 0x2c) & 0xfffffffa;
                      uVar13 = puVar34[1];
                      uVar8 = puVar34[2];
                      uVar9 = puVar34[3];
                      *(undefined4 *)(lVar40 + 0x30) = *puVar34;
                      *(undefined4 *)(lVar40 + 0x34) = uVar13;
                      *(undefined4 *)(lVar40 + 0x38) = uVar8;
                      *(undefined4 *)(lVar40 + 0x3c) = uVar9;
                      *(uint *)(lVar40 + 0x2c) = *(uint *)(lVar40 + 0x2c) & 0xfffffff5;
                      *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
                      goto code_r0x0010290d;
                    }
                  }
                  break;
                }
                plVar38 = (longlong *)*plVar38;
              } while (plVar38 != (longlong *)0x0);
            }
            break;
          }
        }
      case 0x100eb6:
        if (*psVar6 == 0) {
          uVar42 = *puVar39;
          if (*(int *)(psVar6 + 2) == 0) {
            psVar6[1] = 0;
            uVar35 = *(uint *)(psVar6 + 8);
            uVar37 = (ulonglong)uVar35;
            *(uint *)(psVar6 + 10) = uVar35;
            pbVar26 = *(byte **)(psVar6 + 4);
            bVar23 = *pbVar26;
            if ((bVar23 & 0x10) != 0) {
              uVar35 = uVar35 + 2 + (*(ushort *)(pbVar26 + uVar37) + 7 >> 3);
              uVar37 = (ulonglong)uVar35;
              *(uint *)(psVar6 + 10) = uVar35;
              bVar23 = *pbVar26;
            }
            if ((bVar23 & 0x20) == 0) {
              *(int *)(psVar6 + 2) = (int)uVar37;
              psVar6[0xe] = 0;
              *(int *)(psVar6 + 0xc) = (int)uVar37;
            }
            else {
              puVar33 = (ushort *)(pbVar26 + uVar37);
              uVar11 = *puVar33;
              psVar6[0xe] = uVar11;
              if (uVar11 == 0) {
                if ((((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                    (lVar40 = *(longlong *)
                               ((ulonglong)*puRam00000000007123a0 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0)) &&
                   ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                    (*(char *)(lVar40 + 0x499) != '\0')))) {
                  if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                    *(undefined8 *)(puVar31 + -8) = 0x100f98;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar31 + 0x20) = 0;
                    *(undefined8 *)(puVar31 + -8) = 0x100fbe;
                    (*_DAT_)(1,0xa94538,0xbb4208,0x80f);
                  }
                }
                uVar17 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar31 + -8) = 0x100fcc;
                func_0x(uVar17,3);
                uVar37 = (ulonglong)*(uint *)(psVar6 + 10);
                uVar11 = psVar6[0xe];
              }
              uVar35 = (int)uVar37 + (uVar11 + 1) * 2;
              *(uint *)(psVar6 + 0xc) = uVar35;
              if (0x1f9e < uVar35) {
                if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                   ((lVar40 = *(longlong *)
                               ((ulonglong)*puRam00000000007123a0 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                    ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                     (*(char *)(lVar40 + 0x499) != '\0')))))) {
                  if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                    *(undefined8 *)(puVar31 + -8) = 0x10106b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar31 + 0x20) = 0;
                    *(undefined8 *)(puVar31 + -8) = 0x101091;
                    (*_DAT_)(1,0xa94538,0xbb4208,0x816);
                  }
                }
                uVar17 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar31 + -8) = 0x10109f;
                func_0x(uVar17,4);
                uVar11 = psVar6[0xe];
                uVar35 = *(uint *)(psVar6 + 0xc);
              }
              uVar37 = (ulonglong)uVar11;
              uVar11 = puVar33[uVar37];
              *(uint *)(psVar6 + 2) = uVar11 & 0x7fff;
              if ((uVar11 & 0x7fff) < uVar35) {
                if ((((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                    (lVar40 = *(longlong *)
                               ((ulonglong)*puRam00000000007123a0 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0)) &&
                   ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                    (*(char *)(lVar40 + 0x499) != '\0')))) {
                  if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                    *(undefined8 *)(puVar31 + -8) = 0x10113c;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar31 + 0x20) = 0;
                    *(undefined8 *)(puVar31 + -8) = 0x101162;
                    (*_DAT_)(1,0xa94538,0xbb4208,0x81d);
                  }
                }
                uVar17 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar31 + -8) = 0x101170;
                func_0x(uVar17,4);
                uVar37 = (ulonglong)(ushort)psVar6[0xe];
              }
              if ((short)puVar33[(ulonglong)((int)uVar37 - 1) + 1] < 0) {
                lVar40 = *(longlong *)(psVar6 + 4);
                do {
                  lVar30 = (ulonglong)*(uint *)(psVar6 + 10) + lVar40;
                  if ((int)uVar37 == 1) {
                    uVar35 = *(uint *)(psVar6 + 0xc);
                    uVar11 = *(ushort *)(lVar30 + uVar37 * 2);
                    uVar36 = uVar35;
code_r0x001011cc:
                    if ((uVar11 & 0x7fff) < uVar35) goto code_r0x001011d0;
                  }
                  else {
                    uVar35 = *(ushort *)(lVar30 + -2 + uVar37 * 2) & 0x7fff;
                    uVar36 = *(uint *)(psVar6 + 0xc);
                    uVar11 = *(ushort *)(lVar30 + uVar37 * 2);
                    if (uVar36 <= uVar35) goto code_r0x001011cc;
code_r0x001011d0:
                    *(undefined8 *)(puVar31 + -8) = 0x1011dd;
                    func_0x(lVar40,7);
                    uVar36 = *(uint *)(psVar6 + 0xc);
                  }
                  if ((uVar35 < uVar36) || (*(uint *)(psVar6 + 2) < uVar35)) goto code_r0x001014d1;
                  lVar40 = *(longlong *)(psVar6 + 4);
                  if (*(ushort *)((ulonglong)uVar35 + lVar40) == 5) {
                    psVar6[1] = psVar6[1] | 2;
                    psVar6[0xe] = psVar6[0xe] + -1;
                    psVar6[0x15] = (short)uVar35;
                    lVar40 = (ulonglong)(uVar35 & 0xffff) + *(longlong *)(psVar6 + 4);
                    uVar11 = psVar6[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar40 + 2) >> 0xe & 1) != 0) {
                      uVar11 = *(ushort *)(lVar40 + 2) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                    }
                    psVar6[0x16] = uVar11;
                    psVar6[0x16] = (uVar11 ^ *(ushort *)(lVar40 + 2)) & 0x7ff ^ uVar11;
                    goto code_r0x001012ae;
                  }
                  if (*(ushort *)((ulonglong)uVar35 + lVar40) < 0x400) goto code_r0x001012ae;
                  psVar6[1] = psVar6[1] | 1;
                  uVar11 = psVar6[0xe] - 1;
                  psVar6[0xe] = uVar11;
                  if (uVar11 == 0) goto code_r0x001012ae;
                  uVar37 = (ulonglong)uVar11;
                } while ((short)puVar33[(ulonglong)(uVar11 - 1) + 1] < 0);
                uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
                pbVar26 = *(byte **)(psVar6 + 4);
              }
              else {
code_r0x001012ae:
                uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
                pbVar26 = *(byte **)(psVar6 + 4);
              }
            }
            if ((*pbVar26 & 0x40) == 0) {
              *(undefined4 *)(psVar6 + 0x13) = 0;
            }
            else {
              *(int *)(psVar6 + 0x13) = (int)uVar37;
              *(int *)(psVar6 + 2) = (int)uVar37 + 0xe;
              *(undefined8 *)(puVar31 + -8) = 0x1012e1;
              puVar18 = (ulonglong *)func_0x(psVar6 + 1);
              uVar25 = (ushort)(*puVar18 >> 0x30);
              uVar11 = uVar25;
              if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
                uVar11 = uVar25 & 0xdfff;
                if ((uVar25 >> 0xe & 1) != 0) {
                  uVar11 = uVar25 | 0x2000;
                }
              }
              uVar35 = uVar15;
              if (uVar11 == 0xfffc) {
                uVar35 = (uint)((*puVar18 >> 0x20 & 0xffff) >> 5);
              }
              *(uint *)(psVar6 + 2) = *(int *)(psVar6 + 2) + uVar35;
              uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
            }
            iVar14 = (int)uVar37;
            if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
               (*(ulonglong *)(psVar6 + 0xf) < uVar37 + *(longlong *)(psVar6 + 4))) {
              if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                 (((lVar40 = *(longlong *)
                              ((ulonglong)*puRam00000000007123a0 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                   (lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0)) &&
                  (*(char *)(lVar40 + 0x499) != '\0')))) {
                if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                  *(undefined8 *)(puVar31 + -8) = 0x1013dd;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar31 + 0x20) = 0;
                  *(undefined8 *)(puVar31 + -8) = 0x101403;
                  (*_DAT_)(1,0xa94538,0xbb4208,0x877);
                }
              }
              uVar17 = *(undefined8 *)(psVar6 + 4);
              *(undefined8 *)(puVar31 + -8) = 0x101411;
              func_0x(uVar17,0x12);
              iVar14 = *(int *)(psVar6 + 2);
            }
            if (0x3f3b < iVar14 - 1U) {
              if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                 ((lVar40 = *(longlong *)
                             ((ulonglong)*puRam00000000007123a0 +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                  ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                   (*(char *)(lVar40 + 0x499) != '\0')))))) {
                if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                  *(undefined8 *)(puVar31 + -8) = 0x10149d;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar31 + 0x20) = 0;
                  *(undefined8 *)(puVar31 + -8) = 0x1014c3;
                  (*_DAT_)(1,0xa94538,0xbb4208,0x87c);
                }
              }
              uVar17 = *(undefined8 *)(psVar6 + 4);
              *(undefined8 *)(puVar31 + -8) = 0x1014d1;
              func_0x(uVar17,5);
            }
          }
code_r0x001014d1:
          puVar39 = *(uint **)(&stack0x00000078 + lVar16);
          if ((*(byte *)((longlong)puVar39 + 6) & 0x10) != 0) {
            bVar23 = **(byte **)(psVar6 + 4);
            if ((bVar23 & 0x10) == 0) {
              if ((1 << (bVar23 & 0xe) & 0x1105U) == 0) goto code_r0x001014f9;
code_r0x0010153a:
              puVar19 = *(undefined4 **)(puVar39 + 2) + 1;
              *(undefined4 *)((longlong)&uStackX_24 + lVar16) = **(undefined4 **)(puVar39 + 2);
              *(undefined4 *)(&stack0x00000030 + lVar16) = 0;
              goto code_r0x0010165f;
            }
            if (((int)*(uint *)(psVar6 + 8) <= (int)*puVar39) ||
               (*(ushort *)(*(byte **)(psVar6 + 4) + *(uint *)(psVar6 + 8)) <
                *(ushort *)(puVar39 + 1))) goto code_r0x0010153a;
          }
code_r0x001014f9:
          uVar42 = -uVar42;
          puVar19 = *(uint **)(psVar6 + 4);
          if ((ushort)psVar6[0xe] < uVar42) {
            *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 0;
            *(undefined4 *)(&stack0x00000030 + lVar16) = 0;
          }
          else {
            uVar35 = *(uint *)(psVar6 + 10);
            if (uVar42 == 1) {
              uVar36 = *(uint *)(psVar6 + 0xc);
              puVar39 = puVar19;
            }
            else {
              uVar36 = *(ushort *)
                        ((longlong)puVar19 + (longlong)(int)uVar42 * 2 + ((ulonglong)uVar35 - 2)) &
                       0x7fff;
              puVar39 = *(uint **)(psVar6 + 4);
            }
            iVar14 = (*(ushort *)((longlong)puVar19 + (longlong)(int)uVar42 * 2 + (ulonglong)uVar35)
                     & 0x7fff) - uVar36;
            *(int *)((longlong)&uStackX_24 + lVar16) = iVar14;
            if (iVar14 == 0) {
              puVar19 = (uint *)((longlong)puVar39 + (ulonglong)uVar36);
              puVar39 = *(uint **)(&stack0x00000078 + lVar16);
              *(undefined4 *)(&stack0x00000030 + lVar16) = 0;
            }
            else {
              puVar33 = (ushort *)
                        ((longlong)puVar19 + (ulonglong)(uVar42 - 1) * 2 + (ulonglong)uVar35 + 2);
              puVar19 = (uint *)((longlong)puVar39 + (ulonglong)uVar36);
              puVar39 = *(uint **)(&stack0x00000078 + lVar16);
              *(uint *)(&stack0x00000030 + lVar16) = (uint)(*puVar33 >> 0xf);
            }
          }
        }
        else {
          *(undefined4 *)(&stack0x00000084 + lVar16) = 0;
          *(undefined **)(puVar31 + 0x20) = &stack0x00000084 + lVar16;
          *(undefined8 *)(puVar31 + -8) = 0x1015dc;
          puVar19 = (uint *)func_0x(psVar6 + 1,puVar39);
          uVar42 = *(uint *)(&stack0x00000084 + lVar16);
          if (((*psVar6 == 0) || (plVar38 = *(longlong **)(psVar6 + 8), plVar38 == (longlong *)0x0))
             || ((*plVar38 == 0 ||
                 (((*(byte *)((longlong)puVar39 + 6) & 8) != 0 || ((uVar42 & 1) != 0)))))) {
code_r0x00101650:
            *(uint *)(&stack0x00000030 + lVar16) = uVar42 & 1;
            if (puVar19 != (uint *)0x0) goto code_r0x0010165f;
          }
          else {
            if ((puVar19 != (uint *)0x0) && (puVar19 != (uint *)0x818f74)) {
              *(uint *)(puVar31 + 0x38) = uVar42;
              *(longlong *)(puVar31 + 0x30) = (longlong)&uStackX_24 + lVar16;
              *(undefined4 *)(puVar31 + 0x28) = *(undefined4 *)(&stack0x00000060 + lVar16);
              *(undefined8 *)(puVar31 + 0x20) = *(undefined8 *)(&stack0x000000a0 + lVar16);
              uVar13 = *(undefined4 *)((longlong)&uStackX_24 + lVar16);
              *(undefined8 *)(puVar31 + -8) = 0x10164d;
              puVar19 = (uint *)func_0x(plVar38,puVar39,puVar19,uVar13);
              goto code_r0x00101650;
            }
            *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 0;
            *(uint *)(&stack0x00000030 + lVar16) = uVar42 & 1;
          }
          puVar19 = *(uint **)(psVar6 + 4);
        }
code_r0x0010165f:
        if ((*(ushort *)(*(longlong *)(puVar39 + 0x12) + 0xc) & 0x400) == 0) {
          if (*(int *)((longlong)&uStackX_24 + lVar16) == 0) {
code_r0x00101cee:
            if ((puVar39[0x10] & 0x2000) != 0) {
              *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 4;
              puVar19 = (uint *)0x87f408;
              break;
            }
          }
        }
        else {
          if (*(int *)(psVar6 + 2) == 0) {
            psVar6[1] = 0;
            uVar42 = *(uint *)(psVar6 + 8);
            uVar37 = (ulonglong)uVar42;
            *(uint *)(psVar6 + 10) = uVar42;
            pbVar26 = *(byte **)(psVar6 + 4);
            bVar23 = *pbVar26;
            if ((bVar23 & 0x10) != 0) {
              uVar42 = uVar42 + 2 + (*(ushort *)(pbVar26 + uVar37) + 7 >> 3);
              uVar37 = (ulonglong)uVar42;
              *(uint *)(psVar6 + 10) = uVar42;
              bVar23 = *pbVar26;
            }
            if ((bVar23 & 0x20) == 0) {
              *(int *)(psVar6 + 2) = (int)uVar37;
              psVar6[0xe] = 0;
              *(int *)(psVar6 + 0xc) = (int)uVar37;
            }
            else {
              puVar33 = (ushort *)(pbVar26 + uVar37);
              uVar11 = *puVar33;
              psVar6[0xe] = uVar11;
              if (uVar11 == 0) {
                if ((((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                    (lVar40 = *(longlong *)
                               ((ulonglong)*puRam00000000007123a0 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0)) &&
                   ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                    (*(char *)(lVar40 + 0x499) != '\0')))) {
                  if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                    *(undefined8 *)(puVar31 + -8) = 0x101749;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar31 + 0x20) = 0;
                    *(undefined8 *)(puVar31 + -8) = 0x10177e;
                    (*_DAT_)(1,0xa94538,0xbb4208,0x80f);
                  }
                }
                uVar17 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar31 + -8) = 0x10178c;
                func_0x(uVar17,3);
                uVar37 = (ulonglong)*(uint *)(psVar6 + 10);
                uVar11 = psVar6[0xe];
              }
              uVar42 = (int)uVar37 + (uVar11 + 1) * 2;
              *(uint *)(psVar6 + 0xc) = uVar42;
              if (0x1f9e < uVar42) {
                if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                   ((lVar40 = *(longlong *)
                               ((ulonglong)*puRam00000000007123a0 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                    ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                     (*(char *)(lVar40 + 0x499) != '\0')))))) {
                  if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                    *(undefined8 *)(puVar31 + -8) = 0x10182b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar31 + 0x20) = 0;
                    *(undefined8 *)(puVar31 + -8) = 0x101851;
                    (*_DAT_)(1,0xa94538,0xbb4208,0x816);
                  }
                }
                uVar17 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar31 + -8) = 0x10185f;
                func_0x(uVar17,4);
                uVar11 = psVar6[0xe];
                uVar42 = *(uint *)(psVar6 + 0xc);
              }
              uVar37 = (ulonglong)uVar11;
              uVar11 = puVar33[uVar37];
              *(uint *)(psVar6 + 2) = uVar11 & 0x7fff;
              if ((uVar11 & 0x7fff) < uVar42) {
                if ((((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                    (lVar40 = *(longlong *)
                               ((ulonglong)*puRam00000000007123a0 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0)) &&
                   ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                    (*(char *)(lVar40 + 0x499) != '\0')))) {
                  if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                    *(undefined8 *)(puVar31 + -8) = 0x1018fc;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar31 + 0x20) = 0;
                    *(undefined8 *)(puVar31 + -8) = 0x101922;
                    (*_DAT_)(1,0xa94538,0xbb4208,0x81d);
                  }
                }
                uVar17 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar31 + -8) = 0x101930;
                func_0x(uVar17,4);
                uVar37 = (ulonglong)(ushort)psVar6[0xe];
              }
              if ((short)puVar33[(ulonglong)((int)uVar37 - 1) + 1] < 0) {
                lVar40 = *(longlong *)(psVar6 + 4);
                do {
                  lVar30 = (ulonglong)*(uint *)(psVar6 + 10) + lVar40;
                  if ((int)uVar37 == 1) {
                    uVar42 = *(uint *)(psVar6 + 0xc);
                    uVar11 = *(ushort *)(lVar30 + uVar37 * 2);
                    uVar35 = uVar42;
code_r0x0010198c:
                    if ((uVar11 & 0x7fff) < uVar42) goto code_r0x00101990;
                  }
                  else {
                    uVar42 = *(ushort *)(lVar30 + -2 + uVar37 * 2) & 0x7fff;
                    uVar35 = *(uint *)(psVar6 + 0xc);
                    uVar11 = *(ushort *)(lVar30 + uVar37 * 2);
                    if (uVar35 <= uVar42) goto code_r0x0010198c;
code_r0x00101990:
                    *(undefined8 *)(puVar31 + -8) = 0x10199d;
                    func_0x(lVar40,7);
                    uVar35 = *(uint *)(psVar6 + 0xc);
                  }
                  if ((uVar42 < uVar35) || (*(uint *)(psVar6 + 2) < uVar42)) goto code_r0x00101c92;
                  lVar40 = *(longlong *)(psVar6 + 4);
                  if (*(ushort *)((ulonglong)uVar42 + lVar40) == 5) {
                    psVar6[1] = psVar6[1] | 2;
                    psVar6[0xe] = psVar6[0xe] + -1;
                    psVar6[0x15] = (short)uVar42;
                    lVar40 = (ulonglong)(uVar42 & 0xffff) + *(longlong *)(psVar6 + 4);
                    uVar11 = psVar6[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar40 + 2) >> 0xe & 1) != 0) {
                      uVar11 = *(ushort *)(lVar40 + 2) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                    }
                    psVar6[0x16] = uVar11;
                    psVar6[0x16] = (uVar11 ^ *(ushort *)(lVar40 + 2)) & 0x7ff ^ uVar11;
                    goto code_r0x00101a6e;
                  }
                  if (*(ushort *)((ulonglong)uVar42 + lVar40) < 0x400) goto code_r0x00101a6e;
                  psVar6[1] = psVar6[1] | 1;
                  uVar11 = psVar6[0xe] - 1;
                  psVar6[0xe] = uVar11;
                  if (uVar11 == 0) goto code_r0x00101a6e;
                  uVar37 = (ulonglong)uVar11;
                } while ((short)puVar33[(ulonglong)(uVar11 - 1) + 1] < 0);
                uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
                pbVar26 = *(byte **)(psVar6 + 4);
              }
              else {
code_r0x00101a6e:
                uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
                pbVar26 = *(byte **)(psVar6 + 4);
              }
            }
            if ((*pbVar26 & 0x40) == 0) {
              *(undefined4 *)(psVar6 + 0x13) = 0;
            }
            else {
              *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
              *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
              *(undefined8 *)(puVar31 + -8) = 0x101aa2;
              puVar18 = (ulonglong *)func_0x(psVar6 + 1);
              uVar25 = (ushort)(*puVar18 >> 0x30);
              uVar11 = uVar25;
              if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
                uVar11 = uVar25 & 0xdfff;
                if ((uVar25 >> 0xe & 1) != 0) {
                  uVar11 = uVar25 | 0x2000;
                }
              }
              if (uVar11 == 0xfffc) {
                uVar15 = (uint)((*puVar18 >> 0x20 & 0xffff) >> 5);
              }
              *(uint *)(psVar6 + 2) = *(int *)(psVar6 + 2) + uVar15;
              uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
            }
            iVar14 = (int)uVar37;
            if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
               (*(ulonglong *)(psVar6 + 0xf) < uVar37 + *(longlong *)(psVar6 + 4))) {
              if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                 (((lVar40 = *(longlong *)
                              ((ulonglong)*puRam00000000007123a0 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                   (lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0)) &&
                  (*(char *)(lVar40 + 0x499) != '\0')))) {
                if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                  *(undefined8 *)(puVar31 + -8) = 0x101b9e;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar31 + 0x20) = 0;
                  *(undefined8 *)(puVar31 + -8) = 0x101bc4;
                  (*_DAT_)(1,0xa94538,0xbb4208,0x877);
                }
              }
              uVar17 = *(undefined8 *)(psVar6 + 4);
              *(undefined8 *)(puVar31 + -8) = 0x101bd2;
              func_0x(uVar17,0x12);
              iVar14 = *(int *)(psVar6 + 2);
            }
            if (0x3f3b < iVar14 - 1U) {
              if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                 ((lVar40 = *(longlong *)
                             ((ulonglong)*puRam00000000007123a0 +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                  ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                   (*(char *)(lVar40 + 0x499) != '\0')))))) {
                if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                  *(undefined8 *)(puVar31 + -8) = 0x101c5e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar31 + 0x20) = 0;
                  *(undefined8 *)(puVar31 + -8) = 0x101c84;
                  (*_DAT_)(1,0xa94538,0xbb4208,0x87c);
                }
              }
              uVar17 = *(undefined8 *)(psVar6 + 4);
              *(undefined8 *)(puVar31 + -8) = 0x101c92;
              func_0x(uVar17,5);
            }
          }
code_r0x00101c92:
          *(undefined8 *)(puVar31 + -8) = 0x101c9b;
          iVar14 = func_0x(psVar6 + 1);
          if (iVar14 == 0) {
            *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 0;
            puVar19 = puVar29;
          }
          else {
            *(undefined8 *)(puVar31 + -8) = 0x101cb3;
            puVar19 = (uint *)func_0x(psVar6 + 0x15,puVar39,(longlong)&uStackX_24 + lVar16,
                                              &stack0x00000030 + lVar16);
          }
          if (*(int *)((longlong)&uStackX_24 + lVar16) == 0) {
            if ((puVar19 != (uint *)0x0) &&
               ((*(int *)(*(longlong *)(puVar39 + 0x12) + 0x10) != 10 ||
                ((*(ushort *)(*(longlong *)(puVar39 + 0x12) + 0xc) & 0x800) != 0))))
            goto code_r0x00101cee;
            break;
          }
        }
        if (*(int *)(*(longlong *)(puVar39 + 0x12) + 0x10) == 10) break;
        param_3 = *(undefined **)(&stack0x00000058 + lVar16);
        if ((*(int *)(*(longlong *)(puVar39 + 0x12) + 0x10) == 9) && (param_3 == (undefined *)0x0))
        {
          param_3 = &stack0x000000d0 + lVar16;
          *(undefined **)(&stack0x00000058 + lVar16) = param_3;
          *(undefined4 *)(&stack0x000000d0 + lVar16) = *(undefined4 *)(&stack0x0000002c + lVar16);
          *(undefined4 *)(&stack0x000000f0 + lVar16) = 0x1f9e;
          *(undefined **)(&stack0x000000e8 + lVar16) = &stack0x000000f4 + lVar16;
          *(undefined8 *)(puVar31 + -8) = 0x101d78;
          lVar40 = func_0x();
          lVar40 = -lVar40;
          puVar32 = puVar31 + lVar40;
          *(undefined **)(&stack0x000000d8 + lVar16) = puVar31 + lVar40 + 0x60;
          *(undefined8 *)(puVar31 + lVar40 + -8) = 0x101d8e;
          func_0x(puVar31 + lVar40 + 0x60,0);
        }
        uVar42 = *(uint *)((longlong)&uStackX_24 + lVar16);
        (&stack0x00000028)[lVar16] = 0;
        puVar34 = (undefined4 *)
                  (*(longlong *)(&stack0x00000070 + lVar16) * 0x50 +
                  *(longlong *)(*(longlong *)(&stack0x00000038 + lVar16) + 0x10));
        switch(*(undefined4 *)(*(longlong *)(puVar34 + 0x12) + 0x10)) {
        case 2:
          lVar40 = (ulonglong)*(uint *)(param_3 + 4) * 0x40;
          pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
          *pbVar26 = *pbVar26 & 0xfb;
          if (*(uint *)(param_3 + 0x20) < *(int *)(param_3 + 0x10) + uVar42) {
            lVar27 = (ulonglong)*puRam00000000007123a0 +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam0000000000712398 * 8
                      );
            lVar30 = *(longlong *)(lVar27 + 0x100);
            if (lVar30 == 0) {
              *(undefined8 *)(puVar32 + -8) = 0x101f9f;
              (*pcRam00000000007123b0)(0);
              lVar30 = *(longlong *)(lVar27 + 0x100);
            }
            puVar32[0x20] = 5;
            uVar17 = *(undefined8 *)(lVar30 + 1000);
            *(undefined8 *)(puVar32 + -8) = 0x101fca;
            uVar17 = (*pcRam0000000000712308)(0x1f9e,uVar17,0xbb2678,0xcd);
            param_3 = *(undefined **)(&stack0x00000058 + lVar16);
            *(undefined8 *)(param_3 + 0x18) = uVar17;
            *(undefined4 *)(param_3 + 0x10) = 0;
            pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
            *pbVar26 = *pbVar26 | 4;
            *(undefined4 *)(param_3 + 0x20) = 0x1f9e;
          }
          uVar13 = puVar34[1];
          uVar8 = puVar34[2];
          uVar9 = puVar34[3];
          puVar2 = (undefined4 *)(lVar40 + 8 + *(longlong *)(param_3 + 8));
          *puVar2 = *puVar34;
          puVar2[1] = uVar13;
          puVar2[2] = uVar8;
          puVar2[3] = uVar9;
          *(undefined4 *)(*(longlong *)(param_3 + 8) + lVar40) =
               *(undefined4 *)(&stack0x00000034 + lVar16);
          pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
          *pbVar26 = *pbVar26 & 0xfe;
          pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
          *pbVar26 = *pbVar26 & 0xfd;
          lVar40 = *(longlong *)(param_3 + 8) + lVar40;
          *(ulonglong *)(lVar40 + 0x20) =
               (ulonglong)*(uint *)(param_3 + 0x10) + *(longlong *)(param_3 + 0x18);
          uVar35 = *(uint *)(&stack0x00000030 + lVar16) & 1;
          uVar15 = *(uint *)(lVar40 + 0x2c) & 0xfffffffa;
code_r0x0010202e:
          *(uint *)(lVar40 + 0x28) = uVar42;
          *(uint *)(lVar40 + 0x2c) = uVar35 | uVar15;
          uVar13 = puVar34[1];
          uVar8 = puVar34[2];
          uVar9 = puVar34[3];
          *(undefined4 *)(lVar40 + 0x30) = *puVar34;
          *(undefined4 *)(lVar40 + 0x34) = uVar13;
          *(undefined4 *)(lVar40 + 0x38) = uVar8;
          *(undefined4 *)(lVar40 + 0x3c) = uVar9;
          *(uint *)(lVar40 + 0x2c) = (uVar35 | uVar15) & 0xfffffff5;
          uVar15 = *(uint *)(param_3 + 0x10);
          iVar14 = *(int *)(param_3 + 0x20);
          lVar40 = *(longlong *)(param_3 + 0x18);
          *(undefined8 *)(puVar32 + -8) = 0x10205b;
          func_0x((ulonglong)uVar15 + lVar40,iVar14 - uVar15,puVar19,uVar42);
          *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
          *(uint *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + uVar42;
        default:
          param_2 = *(longlong **)(&stack0x00000038 + lVar16);
          param_1 = *(longlong **)(&stack0x00000050 + lVar16);
          break;
        case 3:
        case 4:
        case 5:
          uVar17 = *(undefined8 *)(*(longlong *)(&stack0x00000050 + lVar16) + 0x18);
          *(undefined8 *)(puVar32 + -8) = 0x102b7e;
          func_0x(uVar17);
          *(undefined8 *)(puVar32 + -8) = 0x102b83;
          func_0x();
          pcVar5 = (code *)swi(3);
          (*pcVar5)();
          return;
        case 6:
          *(undefined8 *)(puVar32 + -8) = 0x102b89;
          func_0x();
          pcVar5 = (code *)swi(3);
          (*pcVar5)();
          return;
        case 9:
          if (*(int *)(&stack0x00000030 + lVar16) != 0) {
            lVar40 = (ulonglong)*(uint *)(param_3 + 4) * 0x40;
            pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
            *pbVar26 = *pbVar26 & 0xfb;
            if (*(uint *)(param_3 + 0x20) < *(int *)(param_3 + 0x10) + uVar42) {
              lVar27 = (ulonglong)*puRam00000000007123a0 +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                        (ulonglong)*puRam0000000000712398 * 8);
              lVar30 = *(longlong *)(lVar27 + 0x100);
              if (lVar30 == 0) {
                *(undefined8 *)(puVar32 + -8) = 0x101ebd;
                (*pcRam00000000007123b0)(0);
                lVar30 = *(longlong *)(lVar27 + 0x100);
              }
              puVar32[0x20] = 5;
              uVar17 = *(undefined8 *)(lVar30 + 1000);
              *(undefined8 *)(puVar32 + -8) = 0x101ee8;
              uVar17 = (*pcRam0000000000712308)(0x1f9e,uVar17,0xbb2678,0xcd);
              param_3 = *(undefined **)(&stack0x00000058 + lVar16);
              *(undefined8 *)(param_3 + 0x18) = uVar17;
              *(undefined4 *)(param_3 + 0x10) = 0;
              pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
              *pbVar26 = *pbVar26 | 4;
              *(undefined4 *)(param_3 + 0x20) = 0x1f9e;
            }
            uVar13 = puVar34[1];
            uVar8 = puVar34[2];
            uVar9 = puVar34[3];
            puVar2 = (undefined4 *)(lVar40 + 8 + *(longlong *)(param_3 + 8));
            *puVar2 = *puVar34;
            puVar2[1] = uVar13;
            puVar2[2] = uVar8;
            puVar2[3] = uVar9;
            *(undefined4 *)(*(longlong *)(param_3 + 8) + lVar40) =
                 *(undefined4 *)(&stack0x00000034 + lVar16);
            pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
            *pbVar26 = *pbVar26 & 0xfe;
            pbVar26 = (byte *)(lVar40 + 0x18 + *(longlong *)(param_3 + 8));
            *pbVar26 = *pbVar26 & 0xfd;
            lVar40 = *(longlong *)(param_3 + 8) + lVar40;
            *(ulonglong *)(lVar40 + 0x20) =
                 (ulonglong)*(uint *)(param_3 + 0x10) + *(longlong *)(param_3 + 0x18);
            uVar35 = *(uint *)(lVar40 + 0x2c) & 0xfffffffa;
            uVar15 = *(uint *)(&stack0x00000030 + lVar16) & 1;
            goto code_r0x0010202e;
          }
          param_1 = *(longlong **)(&stack0x00000050 + lVar16);
          if (*(ushort *)(puVar34 + 0xf) < uVar42) {
            uVar13 = *(undefined4 *)(*(longlong *)(puVar34 + 0x12) + 4);
            uVar17 = **(undefined8 **)(*(longlong *)(*(longlong *)(*param_1 + 0x58) + 8) + 0x160);
            *(undefined8 *)(puVar32 + -8) = 0x101e07;
            lVar40 = func_0x(uVar17,uVar13);
            if ((*(byte *)(lVar40 + 0x34) != 0xf1) &&
               ((*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar40 + 0x34) + 0x819410) +
                          0x139f590) == '\0' || (*(short *)(lVar40 + 0x38) != -1)))) {
              *(undefined8 *)(puVar32 + -8) = 0x101e4c;
              (*_DAT_)(6,0x52,0x16,0x8f);
            }
          }
          *(uint *)(puVar32 + 0x20) = uVar42;
          param_2 = *(longlong **)(&stack0x00000038 + lVar16);
          *(undefined8 *)(puVar32 + -8) = 0x101e63;
          func_0x(param_2);
        }
        lVar40 = -0x1ca8e10;
        cVar43 = *pcVar1 != '\0';
        *pcVar1 = cVar43;
        puVar39 = *(uint **)(&stack0x00000078 + lVar16);
        uVar42 = *(uint *)(&stack0x0000002c + lVar16);
        puVar41 = *(uint **)(&stack0x00000070 + lVar16);
        goto code_r0x00102919;
      case 0x10165f:
        goto code_r0x0010165f;
      case 0x10208e:
        puVar19 = *(uint **)(psVar6 + 4);
        if (*psVar6 == 0) {
          if (*(int *)(psVar6 + 2) == 0) {
            psVar6[1] = 0;
            uVar42 = *(uint *)(psVar6 + 8);
            uVar37 = (ulonglong)uVar42;
            *(uint *)(psVar6 + 10) = uVar42;
            pbVar26 = *(byte **)(psVar6 + 4);
            bVar23 = *pbVar26;
            if ((bVar23 & 0x10) != 0) {
              uVar42 = uVar42 + 2 + (*(ushort *)(pbVar26 + uVar37) + 7 >> 3);
              uVar37 = (ulonglong)uVar42;
              *(uint *)(psVar6 + 10) = uVar42;
              bVar23 = *pbVar26;
            }
            if ((bVar23 & 0x20) == 0) {
              *(int *)(psVar6 + 2) = (int)uVar37;
              psVar6[0xe] = 0;
              *(int *)(psVar6 + 0xc) = (int)uVar37;
            }
            else {
              puVar33 = (ushort *)(pbVar26 + uVar37);
              uVar11 = *puVar33;
              psVar6[0xe] = uVar11;
              if (uVar11 == 0) {
                if ((((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                    (lVar40 = *(longlong *)
                               ((ulonglong)*puRam00000000007123a0 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0)) &&
                   ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                    (*(char *)(lVar40 + 0x499) != '\0')))) {
                  if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                    *(undefined8 *)(puVar31 + -8) = 0x102172;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar31 + 0x20) = 0;
                    *(undefined8 *)(puVar31 + -8) = 0x102198;
                    (*_DAT_)(1,0xa94538,0xbb4208,0x80f);
                  }
                }
                uVar17 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar31 + -8) = 0x1021a6;
                func_0x(uVar17,3);
                uVar37 = (ulonglong)*(uint *)(psVar6 + 10);
                uVar11 = psVar6[0xe];
              }
              uVar42 = (int)uVar37 + (uVar11 + 1) * 2;
              *(uint *)(psVar6 + 0xc) = uVar42;
              if (0x1f9e < uVar42) {
                if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                   ((lVar40 = *(longlong *)
                               ((ulonglong)*puRam00000000007123a0 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                    ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                     (*(char *)(lVar40 + 0x499) != '\0')))))) {
                  if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                    *(undefined8 *)(puVar31 + -8) = 0x102245;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar31 + 0x20) = 0;
                    *(undefined8 *)(puVar31 + -8) = 0x10226b;
                    (*_DAT_)(1,0xa94538,0xbb4208,0x816);
                  }
                }
                uVar17 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar31 + -8) = 0x102279;
                func_0x(uVar17,4);
                uVar11 = psVar6[0xe];
                uVar42 = *(uint *)(psVar6 + 0xc);
              }
              uVar37 = (ulonglong)uVar11;
              uVar11 = puVar33[uVar37];
              *(uint *)(psVar6 + 2) = uVar11 & 0x7fff;
              if ((uVar11 & 0x7fff) < uVar42) {
                if ((((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                    (lVar40 = *(longlong *)
                               ((ulonglong)*puRam00000000007123a0 +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0)) &&
                   ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                    (*(char *)(lVar40 + 0x499) != '\0')))) {
                  if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                    *(undefined8 *)(puVar31 + -8) = 0x102316;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar31 + 0x20) = 0;
                    *(undefined8 *)(puVar31 + -8) = 0x10233c;
                    (*_DAT_)(1,0xa94538,0xbb4208,0x81d);
                  }
                }
                uVar17 = *(undefined8 *)(psVar6 + 4);
                *(undefined8 *)(puVar31 + -8) = 0x10234a;
                func_0x(uVar17,4);
                uVar37 = (ulonglong)(ushort)psVar6[0xe];
              }
              if ((short)puVar33[(ulonglong)((int)uVar37 - 1) + 1] < 0) {
                lVar40 = *(longlong *)(psVar6 + 4);
                do {
                  lVar30 = (ulonglong)*(uint *)(psVar6 + 10) + lVar40;
                  if ((int)uVar37 == 1) {
                    uVar42 = *(uint *)(psVar6 + 0xc);
                    uVar11 = *(ushort *)(lVar30 + uVar37 * 2);
                    uVar35 = uVar42;
code_r0x001023ac:
                    if ((uVar11 & 0x7fff) < uVar42) goto code_r0x001023b0;
                  }
                  else {
                    uVar42 = *(ushort *)(lVar30 + -2 + uVar37 * 2) & 0x7fff;
                    uVar35 = *(uint *)(psVar6 + 0xc);
                    uVar11 = *(ushort *)(lVar30 + uVar37 * 2);
                    if (uVar35 <= uVar42) goto code_r0x001023ac;
code_r0x001023b0:
                    *(undefined8 *)(puVar31 + -8) = 0x1023bd;
                    func_0x(lVar40,7);
                    uVar35 = *(uint *)(psVar6 + 0xc);
                  }
                  if ((uVar42 < uVar35) || (*(uint *)(psVar6 + 2) < uVar42)) goto code_r0x001026b2;
                  lVar40 = *(longlong *)(psVar6 + 4);
                  if (*(ushort *)((ulonglong)uVar42 + lVar40) == 5) {
                    psVar6[1] = psVar6[1] | 2;
                    psVar6[0xe] = psVar6[0xe] + -1;
                    psVar6[0x15] = (short)uVar42;
                    lVar40 = (ulonglong)(uVar42 & 0xffff) + *(longlong *)(psVar6 + 4);
                    uVar11 = psVar6[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar40 + 2) >> 0xe & 1) != 0) {
                      uVar11 = *(ushort *)(lVar40 + 2) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                    }
                    psVar6[0x16] = uVar11;
                    psVar6[0x16] = (uVar11 ^ *(ushort *)(lVar40 + 2)) & 0x7ff ^ uVar11;
                    goto code_r0x0010248e;
                  }
                  if (*(ushort *)((ulonglong)uVar42 + lVar40) < 0x400) goto code_r0x0010248e;
                  psVar6[1] = psVar6[1] | 1;
                  uVar11 = psVar6[0xe] - 1;
                  psVar6[0xe] = uVar11;
                  if (uVar11 == 0) goto code_r0x0010248e;
                  uVar37 = (ulonglong)uVar11;
                } while ((short)puVar33[(ulonglong)(uVar11 - 1) + 1] < 0);
                uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
                pbVar26 = *(byte **)(psVar6 + 4);
              }
              else {
code_r0x0010248e:
                uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
                pbVar26 = *(byte **)(psVar6 + 4);
              }
            }
            if ((*pbVar26 & 0x40) == 0) {
              *(undefined4 *)(psVar6 + 0x13) = 0;
            }
            else {
              *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
              *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
              *(undefined8 *)(puVar31 + -8) = 0x1024c2;
              puVar18 = (ulonglong *)func_0x(psVar6 + 1);
              uVar25 = (ushort)(*puVar18 >> 0x30);
              uVar11 = uVar25;
              if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
                uVar11 = uVar25 & 0xdfff;
                if ((uVar25 >> 0xe & 1) != 0) {
                  uVar11 = uVar25 | 0x2000;
                }
              }
              if (uVar11 == 0xfffc) {
                uVar15 = (uint)((*puVar18 >> 0x20 & 0xffff) >> 5);
              }
              *(uint *)(psVar6 + 2) = *(int *)(psVar6 + 2) + uVar15;
              uVar37 = (ulonglong)*(uint *)(psVar6 + 2);
            }
            iVar14 = (int)uVar37;
            if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
               (*(ulonglong *)(psVar6 + 0xf) < uVar37 + *(longlong *)(psVar6 + 4))) {
              if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                 (((lVar40 = *(longlong *)
                              ((ulonglong)*puRam00000000007123a0 +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                   (lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0)) &&
                  (*(char *)(lVar40 + 0x499) != '\0')))) {
                if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                  *(undefined8 *)(puVar31 + -8) = 0x1025be;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar31 + 0x20) = 0;
                  *(undefined8 *)(puVar31 + -8) = 0x1025e4;
                  (*_DAT_)(1,0xa94538,0xbb4208,0x877);
                }
              }
              uVar17 = *(undefined8 *)(psVar6 + 4);
              *(undefined8 *)(puVar31 + -8) = 0x1025f2;
              func_0x(uVar17,0x12);
              iVar14 = *(int *)(psVar6 + 2);
            }
            if (0x3f3b < iVar14 - 1U) {
              if (((cRam00000000011a3b0b != '\0') || ((bRam00000000011b4410 & 1) != 0)) &&
                 ((lVar40 = *(longlong *)
                             ((ulonglong)*puRam00000000007123a0 +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam0000000000712398 * 8) + 8), lVar40 != 0 &&
                  ((lVar40 = *(longlong *)(lVar40 + 0x60), lVar40 != 0 &&
                   (*(char *)(lVar40 + 0x499) != '\0')))))) {
                if ((cRam00000000011a39fb == '\0') && ((bRam00000000011b4410 & 2) == 0)) {
                  *(undefined8 *)(puVar31 + -8) = 0x10267e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar31 + 0x20) = 0;
                  *(undefined8 *)(puVar31 + -8) = 0x1026a4;
                  (*_DAT_)(1,0xa94538,0xbb4208,0x87c);
                }
              }
              uVar17 = *(undefined8 *)(psVar6 + 4);
              *(undefined8 *)(puVar31 + -8) = 0x1026b2;
              func_0x(uVar17,5);
            }
          }
code_r0x001026b2:
          uVar42 = *(uint *)(psVar6 + 2);
          if (uVar42 < 9) {
            bVar23 = **(byte **)(psVar6 + 4) & 0xe;
joined_r0x001026f0:
            if ((bVar23 == 0) || (bVar23 == 0xc)) {
              uVar42 = 9;
            }
          }
        }
        else {
          uVar42 = *(uint *)(psVar6 + 2);
          if (uVar42 == 0) {
            *(undefined8 *)(puVar31 + -8) = 0x1026dd;
            func_0x(psVar6 + 1);
            uVar42 = *(uint *)(psVar6 + 2);
          }
          if (uVar42 < 9) {
            bVar23 = **(byte **)(psVar6 + 4) & 0x1c;
            goto joined_r0x001026f0;
          }
        }
        *(uint *)((longlong)&uStackX_24 + lVar16) = uVar42;
        break;
      case 0x102704:
code_r0x00102704:
        if (*(longlong *)(&stack0x00000040 + lVar16) == 0) {
          uVar37 = (ulonglong)uVar42 * 4 + 0xf;
          if (uVar37 <= (ulonglong)uVar42 * 4) {
            uVar37 = 0xffffffffffffff0;
          }
          uVar37 = uVar37 & 0xfffffffffffffff0;
          *(undefined8 *)(puVar31 + -8) = 0x102730;
          func_0x();
          puVar32 = puVar31 + -uVar37;
          *(undefined **)(&stack0x00000040 + lVar16) = puVar31 + -uVar37 + 0x60;
          uVar42 = *(uint *)(&stack0x0000002c + lVar16);
          *(uint *)(&stack0x00000048 + lVar16) = uVar42;
          *(undefined4 *)(&stack0x0000004c + lVar16) = 0;
          puVar41 = *(uint **)(&stack0x00000070 + lVar16);
        }
        *(undefined4 *)
         (*(longlong *)(&stack0x00000040 + lVar16) +
         (ulonglong)*(uint *)(&stack0x0000004c + lVar16) * 4) = uVar13;
        *(int *)(&stack0x0000004c + lVar16) = *(int *)(&stack0x0000004c + lVar16) + 1;
        goto code_r0x00102914;
      case 0x10275e:
        plVar38 = (longlong *)param_1[1];
        pcVar5 = *(code **)(*plVar38 + 0x18);
        *(undefined8 *)(puVar31 + -8) = 0x102779;
        (*pcVar5)(plVar38,&stack0x000020a0 + lVar16,8,(longlong)&uStackX_24 + lVar16);
        puVar19 = (uint *)(&stack0x000020a0 + lVar16);
        break;
      case 0x102785:
        pcVar5 = *(code **)(*(longlong *)param_1[1] + 0x10);
        *(undefined8 *)(puVar31 + -8) = 0x10278f;
        uVar13 = (*pcVar5)();
        *(undefined4 *)(&stack0x0000008c + lVar16) = uVar13;
        *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 4;
        puVar19 = (uint *)(&stack0x0000008c + lVar16);
        break;
      case 0x1027a2:
        if (*(int *)(*(longlong *)(puVar39 + 0x12) + 0x10) != 10) goto code_r0x00102704;
        goto code_r0x00102914;
      case 0x1027b5:
        *(undefined8 *)(puVar31 + -8) = 0x1027bd;
        iVar14 = func_0x(psVar6);
        if (0 < iVar14) {
          *(undefined8 *)(puVar31 + -8) = 0x102b5b;
          func_0x(extraout_XMM0_Da,puVar39);
          pcVar5 = (code *)swi(3);
          (*pcVar5)();
          return;
        }
code_r0x001027c5:
        *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 0;
        puVar19 = (uint *)0x0;
        break;
      case 0x1027d1:
        pcVar5 = *(code **)(**pplRam0000000000711740 + 0x1f8);
        *(undefined8 *)(puVar31 + -8) = 0x1027e4;
        lVar40 = (*pcVar5)();
        iVar14 = 1;
        if (*(int *)(lVar40 + 0x34) != 0) {
          iVar14 = *(int *)(lVar40 + 0x34);
        }
        *(int *)(&stack0x00000090 + lVar16) = iVar14;
        *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 4;
        puVar19 = (uint *)(&stack0x00000090 + lVar16);
        break;
      case 0x102801:
        *(undefined4 *)(&stack0x00000094 + lVar16) =
             *(undefined4 *)(*(longlong *)(param_1[3] + 0x20) + 0x664);
        *(undefined4 *)((longlong)&uStackX_24 + lVar16) = 4;
        puVar19 = (uint *)(&stack0x00000094 + lVar16);
        break;
      case 0x10281f:
        plVar38 = (longlong *)param_1[1];
        pcVar5 = *(code **)(*plVar38 + 0x20);
        *(undefined8 *)(puVar31 + -8) = 0x10283a;
        (*pcVar5)(plVar38,&stack0x000020a8 + lVar16,0xa59,(longlong)&uStackX_24 + lVar16);
        puVar19 = (uint *)(&stack0x000020a8 + lVar16);
        if (*(int *)((longlong)&uStackX_24 + lVar16) == 0) {
          puVar19 = puVar29;
        }
        break;
      case 0x10284b:
        goto LAB_;
      }
code_r0x0010287c:
      uVar42 = puVar39[0x10];
      param_2 = *(longlong **)(&stack0x00000038 + lVar16);
      if (((uVar42 >> 10 & 1) != 0) && (puVar19 == (uint *)0x0)) {
        *(undefined8 *)
         (*(longlong *)(*(longlong *)(*param_2 + 0x18) + (ulonglong)puVar39[10] * 8) +
         (longlong)*(int *)(*param_2 + 0x40) * 8) = 1;
        uVar42 = puVar39[0x10];
      }
      if ((uVar42 >> 9 & 1) != 0) {
        if ((uVar42 & 0x800) == 0) {
          if ((uint)*(ushort *)(puVar39 + 0xf) < *(uint *)((longlong)&uStackX_24 + lVar16)) {
            *(undefined8 *)(puVar31 + -8) = 0x1028d9;
            (*_DAT_)(6,0x52,0x16,0x95);
          }
        }
        else {
          **(undefined4 **)(&stack0x000000b0 + lVar16) = 1;
        }
        *(undefined4 *)(puVar31 + 0x20) = *(undefined4 *)((longlong)&uStackX_24 + lVar16);
        *(undefined8 *)(puVar31 + -8) = 0x1028fd;
        func_0x(param_2);
      }
      puVar41 = *(uint **)(&stack0x00000070 + lVar16);
      uVar42 = *(uint *)(&stack0x0000002c + lVar16);
      param_3 = *(undefined **)(&stack0x00000058 + lVar16);
      param_1 = *(longlong **)(&stack0x00000050 + lVar16);
code_r0x0010290d:
      lVar40 = -0x1ca8e10;
code_r0x00102914:
      cVar43 = *pcVar1;
code_r0x00102919:
      uVar15 = *(int *)(&stack0x00000034 + lVar16) + 1;
      *(uint *)(&stack0x00000034 + lVar16) = uVar15;
      puVar41 = (uint *)((longlong)puVar41 + 1);
      *(uint **)(&stack0x00000070 + lVar16) = puVar41;
      puVar39 = puVar39 + 0x14;
      *(uint **)(&stack0x00000078 + lVar16) = puVar39;
      if (uVar42 <= uVar15) goto LAB_;
      puVar19 = (uint *)(ulonglong)uVar15;
      puVar31 = puVar32;
    } while( true );
  }
LAB_:
  if (*(longlong **)(lVar30 + 0x10) != (longlong *)0x0) {
    pcVar5 = *(code **)(**(longlong **)(lVar30 + 0x10) + 8);
    *(undefined8 *)(puVar32 + -8) = 0x10294f;
    (*pcVar5)();
  }
  if (*(int *)(&stack0x0000004c + lVar16) != 0) {
    *(undefined **)(puVar32 + 0x28) = &stack0x00000068 + lVar16;
    *(undefined **)(puVar32 + 0x20) = &stack0x00000064 + lVar16;
    *(undefined8 *)(puVar32 + -8) = 0x10297a;
    func_0x(param_1,param_2,&stack0x00000040 + lVar16,&stack0x00000088 + lVar16);
  }
  if ((param_3 != (undefined *)0x0) &&
     (lVar40 = *(longlong *)(&stack0x00000058 + lVar16), *(int *)(lVar40 + 4) != 0)) {
    uVar17 = *(undefined8 *)(&stack0x00000038 + lVar16);
    lVar30 = *(longlong *)(&stack0x000000b8 + lVar16);
    do {
      puVar39 = (uint *)((longlong)puVar29 * 0x40 + *(longlong *)(lVar40 + 8));
      lVar27 = (ulonglong)*puVar39 * 0x50 + *(longlong *)(*(longlong *)(lVar30 + 0x80) + 0x18);
      iVar14 = *(int *)(*(longlong *)(lVar27 + 0x48) + 0x10);
      if (iVar14 != 2) {
        if (iVar14 == 9) {
          uVar28 = puVar39[0xb];
          *(undefined **)(puVar32 + 0x38) = &stack0x00000028 + lVar16;
          *(undefined8 *)(puVar32 + 0x30) = uVar17;
          *(uint *)(puVar32 + 0x28) = uVar28 & 1;
          *(undefined8 *)(puVar32 + 0x20) = *(undefined8 *)(puVar39 + 8);
          uVar28 = puVar39[10];
          lVar7 = *param_1;
          *(undefined8 *)(puVar32 + -8) = 0x102a36;
          func_0x(&stack0x00000028 + lVar16,lVar27,lVar7,uVar28);
          if ((cVar43 != '\0') || ((&stack0x00000028)[lVar16] != '\0')) {
            cVar43 = '\x01';
          }
        }
        else {
          *(undefined8 *)(puVar32 + 0x20) = 0x810a18;
          *(undefined8 *)(puVar32 + -8) = 0x102a06;
          (*_DAT_)(1,0xc15870,0xc1bb70,0x265);
        }
      }
      uVar28 = (int)puVar29 + 1;
      puVar29 = (uint *)(ulonglong)uVar28;
    } while (uVar28 < *(uint *)(lVar40 + 4));
  }
  uVar37 = 0;
  if (*(longlong **)(param_1[1] + 0x10) != (longlong *)0x0) {
    pcVar5 = *(code **)(**(longlong **)(param_1[1] + 0x10) + 8);
    *(undefined8 *)(puVar32 + -8) = 0x102a65;
    (*pcVar5)();
  }
  if (cVar43 == '\0') {
    iVar14 = *(int *)(&stack0x00000064 + lVar16);
    iVar3 = *(int *)(&stack0x00000088 + lVar16);
    if (((iVar3 == 0) && (iVar14 == 0)) && (*(int *)(&stack0x00000068 + lVar16) == 0)) {
      **(undefined4 **)(&stack0x00000098 + lVar16) = 1;
    }
    else {
      **(undefined4 **)(&stack0x00000098 + lVar16) = 0;
      if (iVar3 != 0) {
        lVar40 = *param_1;
        *(undefined8 *)(puVar32 + -8) = 0x102aad;
        func_0x(lVar40,1);
        iVar14 = *(int *)(&stack0x00000064 + lVar16);
      }
      if (iVar14 != 0) {
        lVar40 = *param_1;
        *(undefined8 *)(puVar32 + -8) = 0x102abe;
        func_0x(lVar40,0);
      }
      if (*(int *)(&stack0x00000068 + lVar16) != 0) {
        lVar40 = *param_1;
        *(undefined8 *)(puVar32 + -8) = 0x102ad1;
        func_0x(lVar40,2);
      }
    }
  }
  else {
    **(undefined4 **)(&stack0x00000098 + lVar16) = 2;
  }
  lVar40 = *(longlong *)(&stack0x000000d8 + lVar16);
  if ((lVar40 != 0) && (uVar28 = *(uint *)(&stack0x000000d0 + lVar16), uVar28 != 0)) {
    do {
      lVar30 = uVar37 * 0x40;
      if ((*(byte *)(lVar40 + 0x18 + lVar30) & 4) != 0) {
        uVar17 = *(undefined8 *)(lVar40 + 0x20 + lVar30);
        *(undefined8 *)(puVar32 + -8) = 0x102b09;
        (*_DAT_)(uVar17);
        pbVar26 = (byte *)(*(longlong *)(&stack0x000000d8 + lVar16) + 0x18 + lVar30);
        *pbVar26 = *pbVar26 & 0xfb;
        lVar40 = *(longlong *)(&stack0x000000d8 + lVar16);
        uVar28 = *(uint *)(&stack0x000000d0 + lVar16);
      }
      uVar42 = (int)uVar37 + 1;
      uVar37 = (ulonglong)uVar42;
    } while (uVar42 < uVar28);
  }
  uVar37 = *(ulonglong *)(&stack0x000020b0 + lVar16);
  *(undefined8 *)(puVar32 + -8) = 0x102b39;
  func_0x(uVar37 ^ (ulonglong)pcVar1);
  return;
LAB_:
  lVar30 = param_1[1];
  goto LAB_;
}

