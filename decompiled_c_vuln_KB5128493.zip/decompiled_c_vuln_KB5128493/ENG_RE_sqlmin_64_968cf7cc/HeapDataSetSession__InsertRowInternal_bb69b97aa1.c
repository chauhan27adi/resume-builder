
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,undefined8 param_3)

{
  short *psVar1;
  byte bVar2;
  code *pcVar3;
  char *pcVar4;
  short *psVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  char cVar8;
  char cVar9;
  undefined uVar10;
  short sVar11;
  ushort uVar12;
  undefined2 uVar13;
  int iVar14;
  undefined4 uVar15;
  longlong lVar16;
  longlong lVar17;
  undefined4 *puVar18;
  longlong *plVar19;
  longlong lVar20;
  undefined8 *puVar21;
  undefined8 *puVar22;
  longlong lVar23;
  undefined8 uVar24;
  undefined8 uVar25;
  int *piVar26;
  undefined4 *puVar27;
  byte bVar28;
  ushort uVar29;
  uint uVar30;
  undefined8 *puVar31;
  byte bVar32;
  uint uVar33;
  int iVar34;
  byte *pbVar35;
  ulonglong uVar36;
  ulonglong uVar37;
  uint *puVar38;
  longlong *plVar39;
  uint uVar40;
  uint uVar41;
  undefined8 unaff_RBX;
  longlong *plVar42;
  undefined *puVar43;
  undefined *puVar44;
  ulonglong uVar45;
  ushort *puVar46;
  undefined8 *puVar47;
  uint uVar48;
  ushort *puVar49;
  short *psVar50;
  longlong lVar51;
  undefined2 *puVar52;
  longlong *plVar53;
  longlong unaff_GS_OFFSET;
  bool bVar54;
  longlong alStackX_8 [4];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar16 = func_0x();
  lVar16 = -lVar16;
  puVar44 = &stack0xffffffffffffffc8 + lVar16;
  puVar43 = &stack0xffffffffffffffc8 + lVar16;
  psVar1 = (short *)(&stack0x00000038 + lVar16);
  *(undefined8 *)(&stack0x000001e0 + lVar16) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000029e0 + lVar16) = unaff_RBX;
  *(ulonglong *)(&stack0x00002978 + lVar16) = _DAT_ ^ (ulonglong)psVar1;
  *(undefined8 *)(&stack0x000001b0 + lVar16) = param_3;
  *(longlong ***)(&stack0x00000078 + lVar16) = param_2;
  *(longlong *)(&stack0x00000090 + lVar16) = param_1;
  *(longlong *)(&stack0x00000120 + lVar16) = param_1;
  *psVar1 = -1;
  plVar19 = (longlong *)0x0;
  *(undefined8 *)(&stack0x00000040 + lVar16) = 0;
  *(undefined4 *)(&stack0x0000003c + lVar16) = 0;
  *(undefined8 *)(&stack0x00000056 + lVar16) = 0;
  *(undefined8 *)(&stack0x00000060 + lVar16) = 0;
  *(undefined8 *)(&stack0x00000048 + lVar16) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100095;
  func_0x(&stack0x000001b8 + lVar16,param_1,1);
  puVar47 = (undefined8 *)**(longlong **)(param_1 + 0x2e0);
  *(undefined8 **)(&stack0x00000100 + lVar16) = puVar47;
  plVar42 = *param_2;
  if ((*(int *)(puVar47 + 5) == *(int *)(plVar42 + 1)) &&
     (*plVar42 == (ulonglong)*(uint6 *)((longlong)puVar47 + 0x14) * 0x10000)) {
    pcVar3 = *(code **)*puVar47;
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1000d1;
    sVar11 = (*pcVar3)(puVar47);
    if (*(short *)((longlong)plVar42 + 0xc) != sVar11) goto LAB_;
    if (plVar42[0x15] != 0) {
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16);
      UNLOCK();
    }
  }
  else {
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1000f2;
    func_0x(plVar42,puVar47);
  }
  bVar54 = false;
  if ((*(int *)(puVar47[1] + 0x100) != 0) && (1 < *(int *)(puVar47[1] + 0x100) - 3U)) {
    bVar54 = true;
  }
  plVar42 = *param_2;
  *(undefined4 *)(&stack0x000000c8 + lVar16) = 0x10;
  if ((*(byte *)(plVar42 + 7) & 0x20) == 0) {
    *(undefined8 *)(&stack0x00000088 + lVar16) = 0;
    if (bVar54) {
      plVar39 = plVar19;
      if ((*(byte *)((longlong)param_2 + 0x14) & 0x10) != 0) {
        plVar39 = plVar42;
      }
      uVar40 = -*(int *)(plVar39 + 2);
      *(uint *)(&stack0x00000074 + lVar16) = uVar40;
      *(undefined2 *)(&stack0xfffffffffffffff0 + lVar16) = 1;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) = *(undefined4 *)(plVar39 + 3);
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101af5;
      func_0x(psVar1,&stack0x000009d8 + lVar16,0x1f9e);
      if (uVar40 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101b1f;
        lVar17 = func_0x();
        lVar17 = -lVar17;
        puVar44 = &stack0xffffffffffffffc8 + lVar17 + lVar16;
        plVar19 = (longlong *)(&stack0x00000038 + lVar17 + lVar16);
        *(longlong **)(&stack0x00000088 + lVar16) = plVar19;
        *(undefined8 *)((longlong)&uStack_40 + lVar17 + lVar16) = 0x101b35;
        func_0x(plVar19,0);
      }
      uVar12 = *(ushort *)((longlong)*param_2 + 0x62);
      *(undefined8 *)(&stack0x000000c0 + lVar16) = 0;
      plVar42 = param_2[1];
      if (uVar12 != 0) {
        *(ulonglong *)(&stack0x000000a0 + lVar16) = (ulonglong)uVar12;
        lVar17 = *(longlong *)(&stack0x00000088 + lVar16);
        do {
          uVar40 = *(uint *)plVar42;
          *(undefined8 *)(puVar44 + -8) = 0x101b71;
          func_0x(param_2,plVar42,&stack0x00000071 + lVar16);
          if ((&stack0x00000071)[lVar16] == '\x03') {
            if (((*(ushort *)(plVar42[9] + 0xc) & 0x400) == 0) &&
               ((*(uint *)(plVar42 + 8) & 0x4000) == 0)) {
              *(undefined8 *)(puVar44 + -8) = 0x101e5d;
              (*_DAT_)(6,0x51,0x10);
            }
            *(undefined8 *)(puVar44 + -8) = 0x101e6f;
            func_0x(psVar1,plVar42,0);
            if ((int)uVar40 < 0) {
              puVar38 = (uint *)((longlong)(int)~uVar40 * 0x20 + 0xc + lVar17);
              *puVar38 = *puVar38 | 2;
            }
          }
          else {
            if (*(short *)((longlong)plVar42 + 4) != 0) {
              if (*psVar1 == 0) {
                *(undefined8 *)(puVar44 + -8) = 0x101b95;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar44 + -8) = 0x101b9c;
                func_0x(&stack0x0000003a + lVar16,plVar42);
              }
            }
            *(undefined8 *)(puVar44 + -8) = 0x101bae;
            func_0x(param_2,plVar42,&stack0x000000c0 + lVar16);
            cVar8 = *(char *)(plVar42 + 8);
            uVar41 = 0;
            if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
              lVar23 = *(longlong *)(&stack0x000000c0 + lVar16);
              if ((*(uint *)(plVar42 + 8) >> 8 & 1) == 0) {
                uVar40 = *(uint *)plVar42;
                lVar20 = *(longlong *)(&stack0x00000040 + lVar16);
                uVar13 = *(undefined2 *)((longlong)plVar42 + 0x3c);
                *(undefined8 *)(puVar44 + -8) = 0x101d26;
                func_0x((int)uVar40 + lVar20,lVar23,uVar13);
              }
              else {
                iVar14 = 0;
                lVar20 = *(longlong *)(&stack0x00000078 + lVar16);
                if (((*(uint *)(plVar42 + 8) & 0x8000) == 0) ||
                   ((*(byte *)(lVar20 + 0x14) & 8) == 0)) {
                  if ((*(byte *)(plVar42[9] + 0x2a) & 0x10) == 0) {
                    lVar20 = *(longlong *)(lVar20 + 0x18);
                  }
                  else {
                    lVar20 = *(longlong *)(lVar20 + 0x20);
                  }
                  uVar40 = *(uint *)(*(longlong *)(plVar42[9] + 0x18) + lVar20);
                }
                else {
                  uVar40 = *(uint *)(*(longlong *)(lVar20 + 0x38) +
                                    (ulonglong)*(uint *)(plVar42 + 7) * 8);
                }
                uVar41 = (uint)*(ushort *)((longlong)plVar42 + 0x3c);
                if (uVar40 < uVar41) {
                  iVar14 = uVar41 - uVar40;
                }
                else if (uVar41 < uVar40) {
                  *(undefined8 *)(puVar44 + -8) = 0x101d91;
                  (*_DAT_)(6,0x5c,0x16);
                }
                uVar10 = *(undefined *)(plVar42[9] + 0x24);
                uVar41 = *(uint *)plVar42;
                lVar20 = *(longlong *)(&stack0x00000040 + lVar16);
                if ((lVar23 != 0) && (uVar40 != 0)) {
                  *(undefined8 *)(puVar44 + -8) = 0x101db8;
                  func_0x((int)uVar41 + lVar20,lVar23,uVar40);
                }
                if (iVar14 != 0) {
                  *(undefined8 *)(puVar44 + -8) = 0x101dcd;
                  func_0x((ulonglong)uVar40 + (int)uVar41 + lVar20,uVar10,iVar14);
                }
                param_2 = *(longlong ***)(&stack0x00000078 + lVar16);
              }
            }
            else if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
              uVar48 = *(uint *)(plVar42 + 8);
              piVar26 = *(int **)(&stack0x000000c0 + lVar16);
              if (((uVar48 >> 0xd & 1) == 0) || (*piVar26 != 0)) {
                if (((uVar48 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  lVar23 = plVar42[9];
                  if ((uVar48 >> 8 & 1) == 0) {
                    uVar41 = (uint)*(ushort *)(lVar23 + 2);
                  }
                  else if ((*(byte *)(lVar23 + 0x2a) & 0x10) == 0) {
                    uVar41 = *(uint *)(*(longlong *)(lVar23 + 0x18) + (longlong)param_2[3]);
                  }
                  else {
                    uVar41 = *(uint *)(*(longlong *)(lVar23 + 0x18) + (longlong)param_2[4]);
                  }
                }
                else {
                  uVar41 = *(uint *)(param_2[7] + *(uint *)(plVar42 + 7));
                }
              }
              if (*(ushort *)((longlong)plVar42 + 0x3c) < uVar41) {
                *(undefined8 *)(puVar44 + -8) = 0x101cd2;
                (*_DAT_)(6,0x52,0x16);
                piVar26 = *(int **)(&stack0x000000c0 + lVar16);
              }
              *(undefined4 *)(puVar44 + 0x28) = 0;
              *(longlong **)(puVar44 + 0x20) = plVar42;
              *(undefined8 *)(puVar44 + -8) = 0x101cfd;
              func_0x((longlong)(int)~uVar40 * 0x20 + lVar17,piVar26,uVar41);
            }
            else if (cVar8 == '\b') {
              if (*psVar1 == 0) {
                uVar24 = *(undefined8 *)(&stack0x000000c0 + lVar16);
                *(undefined8 *)(puVar44 + -8) = 0x101c26;
                func_0x(psVar1,plVar42,uVar24);
              }
              else {
                *(undefined4 *)(puVar44 + 0x28) = 0;
                *(longlong **)(puVar44 + 0x20) = plVar42;
                uVar24 = *(undefined8 *)(&stack0x000000c0 + lVar16);
                *(undefined8 *)(puVar44 + -8) = 0x101c53;
                func_0x((longlong)(int)~uVar40 * 0x20 + lVar17,uVar24,1);
              }
            }
            else {
              *(undefined8 *)(puVar44 + 0x20) = 0x14f2b98;
              *(undefined8 *)(puVar44 + -8) = 0x101c04;
              (*_DAT_)(1,0x18f79f0,0x1924330);
            }
          }
          plVar42 = plVar42 + 10;
          plVar19 = (longlong *)(&stack0x000000a0 + lVar16);
          *plVar19 = *plVar19 + -1;
        } while (*plVar19 != 0);
        uVar40 = *(uint *)(&stack0x00000074 + lVar16);
        plVar19 = *(longlong **)(&stack0x00000088 + lVar16);
      }
      puVar49 = (ushort *)0x0;
      if (uVar40 != 0) {
        if (*psVar1 == 0) {
LAB_:
          uVar45 = (ulonglong)uVar40;
          uVar41 = uVar40 - 1;
          if (*(int *)(plVar19 + (ulonglong)uVar41 * 4 + 1) == 0) goto code_r0x00101e24;
          *(ushort *)(&stack0x00000054 + lVar16) = (ushort)uVar40;
          iVar14 = *(int *)(&stack0x0000004c + lVar16) + 2 + uVar40 * 2;
          *(int *)(&stack0x00000050 + lVar16) = iVar14;
          *(int *)(&stack0x0000003c + lVar16) = iVar14;
          **(byte **)(&stack0x00000040 + lVar16) = **(byte **)(&stack0x00000040 + lVar16) | 0x20;
          uVar41 = *(uint *)(&stack0x0000003c + lVar16);
          if (uVar41 < 0x1f7d) {
            puVar49 = (ushort *)
                      ((ulonglong)*(uint *)(&stack0x0000004c + lVar16) +
                      *(longlong *)(&stack0x00000040 + lVar16));
            *puVar49 = (ushort)uVar40;
            uVar41 = *(uint *)(&stack0x0000003c + lVar16);
          }
          if (uVar40 != 0) {
            puVar38 = (uint *)((longlong)plVar19 + 0xc);
            do {
              puVar49 = puVar49 + 1;
              uVar36 = (ulonglong)uVar41;
              lVar17 = *(longlong *)(&stack0x00000040 + lVar16);
              uVar40 = puVar38[-1];
              uVar41 = uVar41 + uVar40;
              *(uint *)(&stack0x0000003c + lVar16) = uVar41;
              if (uVar41 < 0x1f7d) {
                *puVar49 = (ushort)((*puVar38 & 1) << 0xf) | (ushort)uVar41 & 0x7fff;
                uVar24 = *(undefined8 *)(puVar38 + -3);
                *(undefined8 *)(puVar44 + -8) = 0x101f18;
                func_0x(uVar36 + lVar17,uVar40,uVar24);
                uVar41 = *(uint *)(&stack0x0000003c + lVar16);
              }
              puVar38 = puVar38 + 8;
              uVar45 = uVar45 - 1;
            } while (uVar45 != 0);
          }
          *(uint *)(&stack0x0000009c + lVar16) = uVar41;
          goto LAB_;
        }
        *(undefined **)(puVar44 + 0x28) = &stack0x0000009c + lVar16;
        *(longlong **)(puVar44 + 0x20) = plVar19;
        *(undefined8 *)(puVar44 + -8) = 0x101f54;
        func_0x(&stack0x0000003a + lVar16,0x1f9e,0x1f7c);
      }
    }
    else {
      *psVar1 = 0;
      plVar39 = plVar19;
      if ((*(byte *)((longlong)param_2 + 0x14) & 0x10) != 0) {
        plVar39 = plVar42;
      }
      uVar40 = -*(int *)(plVar39 + 2);
      *(uint *)(&stack0x00000098 + lVar16) = uVar40;
      (&stack0xfffffffffffffff0)[lVar16] = 0;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) = *(undefined4 *)(plVar39 + 3);
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100183;
      func_0x(&stack0x0000003a + lVar16,&stack0x000009d8 + lVar16);
      puVar44 = &stack0xffffffffffffffc8 + lVar16;
      if (uVar40 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1001ab;
        lVar17 = func_0x();
        lVar17 = -lVar17;
        puVar44 = &stack0xffffffffffffffc8 + lVar17 + lVar16;
        plVar19 = (longlong *)(&stack0x00000038 + lVar17 + lVar16);
        *(longlong **)(&stack0x00000088 + lVar16) = plVar19;
        *(undefined8 *)((longlong)&uStack_40 + lVar17 + lVar16) = 0x1001c1;
        func_0x(plVar19,0);
      }
      uVar12 = *(ushort *)((longlong)*param_2 + 0x62);
      *(uint *)(&stack0x00000074 + lVar16) = (uint)uVar12;
      *(undefined8 *)(&stack0x000000d0 + lVar16) = 0;
      *(undefined4 *)(&stack0x00000080 + lVar16) = 0;
      plVar42 = param_2[1];
      if (uVar12 != 0) {
        do {
          uVar45 = 0;
          uVar40 = *(uint *)plVar42;
          *(undefined8 *)(puVar44 + -8) = 0x100203;
          func_0x(param_2,plVar42,&stack0x00000070 + lVar16);
          if ((&stack0x00000070)[lVar16] == '\x03') {
            if (((*(ushort *)(plVar42[9] + 0xc) & 0x400) == 0) &&
               ((*(uint *)(plVar42 + 8) & 0x4000) == 0)) {
              *(undefined8 *)(puVar44 + -8) = 0x1019f0;
              (*_DAT_)(6,0x51,0x10);
            }
            *(undefined8 *)(puVar44 + -8) = 0x101a02;
            func_0x(&stack0x0000003a + lVar16,plVar42,0);
            if ((int)uVar40 < 0) {
              puVar38 = (uint *)((longlong)(int)~uVar40 * 0x20 + 0xc + (longlong)plVar19);
              *puVar38 = *puVar38 | 2;
            }
          }
          else {
            if (*(short *)((longlong)plVar42 + 4) != 0) {
              *(undefined8 *)(puVar44 + -8) = 0x100221;
              func_0x(&stack0x0000003a + lVar16,plVar42);
            }
            *(undefined8 *)(puVar44 + -8) = 0x100233;
            func_0x(param_2,plVar42,&stack0x000000d0 + lVar16);
            cVar8 = *(char *)(plVar42 + 8);
            if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
              lVar17 = *(longlong *)(&stack0x000000d0 + lVar16);
              if ((*(uint *)(plVar42 + 8) >> 8 & 1) == 0) {
                uVar40 = *(uint *)plVar42;
                lVar23 = *(longlong *)(&stack0x00000040 + lVar16);
                uVar13 = *(undefined2 *)((longlong)plVar42 + 0x3c);
                *(undefined8 *)(puVar44 + -8) = 0x101915;
                func_0x((int)uVar40 + lVar23,lVar17,uVar13);
              }
              else {
                iVar14 = 0;
                if (((*(uint *)(plVar42 + 8) & 0x8000) == 0) ||
                   ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  if ((*(byte *)(plVar42[9] + 0x2a) & 0x10) == 0) {
                    plVar19 = param_2[3];
                  }
                  else {
                    plVar19 = param_2[4];
                  }
                  uVar40 = *(uint *)(*(longlong *)(plVar42[9] + 0x18) + (longlong)plVar19);
                }
                else {
                  uVar40 = *(uint *)(param_2[7] + *(uint *)(plVar42 + 7));
                }
                uVar41 = (uint)*(ushort *)((longlong)plVar42 + 0x3c);
                if (uVar40 < uVar41) {
                  iVar14 = uVar41 - uVar40;
                }
                else if (uVar41 < uVar40) {
                  *(undefined8 *)(puVar44 + -8) = 0x101978;
                  (*_DAT_)(6,0x5c,0x16);
                }
                uVar10 = *(undefined *)(plVar42[9] + 0x24);
                uVar41 = *(uint *)plVar42;
                lVar23 = *(longlong *)(&stack0x00000040 + lVar16);
                if ((lVar17 != 0) && (uVar40 != 0)) {
                  *(undefined8 *)(puVar44 + -8) = 0x1019a0;
                  func_0x((int)uVar41 + lVar23,lVar17,uVar40);
                }
                if (iVar14 != 0) {
                  *(undefined8 *)(puVar44 + -8) = 0x1019b4;
                  func_0x((ulonglong)uVar40 + (int)uVar41 + lVar23,uVar10,iVar14);
                }
                param_2 = *(longlong ***)(&stack0x00000078 + lVar16);
              }
            }
            else {
              uVar41 = 0;
              if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
                uVar48 = *(uint *)(plVar42 + 8);
                piVar26 = *(int **)(&stack0x000000d0 + lVar16);
                if (((uVar48 >> 0xd & 1) == 0) || (*piVar26 != 0)) {
                  if (((uVar48 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0))
                  {
                    lVar17 = plVar42[9];
                    if ((uVar48 >> 8 & 1) == 0) {
                      uVar41 = (uint)*(ushort *)(lVar17 + 2);
                    }
                    else if ((*(byte *)(lVar17 + 0x2a) & 0x10) == 0) {
                      uVar41 = *(uint *)(*(longlong *)(lVar17 + 0x18) + (longlong)param_2[3]);
                    }
                    else {
                      uVar41 = *(uint *)(*(longlong *)(lVar17 + 0x18) + (longlong)param_2[4]);
                    }
                  }
                  else {
                    uVar41 = *(uint *)(param_2[7] + *(uint *)(plVar42 + 7));
                  }
                }
                if (*(ushort *)((longlong)plVar42 + 0x3c) < uVar41) {
                  *(undefined8 *)(puVar44 + -8) = 0x1018bf;
                  (*_DAT_)(6,0x52,0x16);
                  piVar26 = *(int **)(&stack0x000000d0 + lVar16);
                }
                *(undefined4 *)(puVar44 + 0x28) = 0;
                *(longlong **)(puVar44 + 0x20) = plVar42;
                *(undefined8 *)(puVar44 + -8) = 0x1018ea;
                func_0x(plVar19 + (longlong)(int)~uVar40 * 4,piVar26,uVar41);
              }
              else if (cVar8 == '\b') {
                pcVar4 = *(char **)(&stack0x000000d0 + lVar16);
                *(char **)(&stack0x000000a0 + lVar16) = pcVar4;
                uVar40 = *(uint *)plVar42;
                if ((int)uVar40 < 0) {
                  if ((uVar40 & 0xc0000000) == 0x80000000) {
                    *(undefined8 *)(puVar44 + -8) = 0x101087;
                    func_0x(&stack0x000008f8 + lVar16);
                    *(undefined4 *)(&stack0x000000a8 + lVar16) = 0;
                    if (*(int *)(&stack0x0000003c + lVar16) == 0) {
                      *(undefined2 *)(&stack0x0000003a + lVar16) = 0;
                      uVar40 = *(uint *)(&stack0x00000048 + lVar16);
                      uVar36 = (ulonglong)uVar40;
                      *(uint *)(&stack0x0000004c + lVar16) = uVar40;
                      pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                      if ((*pbVar35 & 0x10) != 0) {
                        uVar40 = uVar40 + 2 + (*(ushort *)(pbVar35 + uVar36) + 7 >> 3);
                        uVar36 = (ulonglong)uVar40;
                        *(uint *)(&stack0x0000004c + lVar16) = uVar40;
                      }
                      uVar40 = (uint)uVar36;
                      if ((*pbVar35 & 0x20) == 0) {
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40;
                        *(undefined2 *)(&stack0x00000054 + lVar16) = 0;
                        *(uint *)(&stack0x00000050 + lVar16) = uVar40;
                      }
                      else {
                        puVar49 = (ushort *)(pbVar35 + uVar36);
                        uVar12 = *puVar49;
                        *(ushort *)(&stack0x00000054 + lVar16) = uVar12;
                        if (uVar12 == 0) {
                          *(undefined8 *)(puVar44 + -8) = 0x1010e8;
                          cVar8 = func_0x(0x1e85930);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar44 + -8) = 0x1010f1;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar44 + -8) = 0x10110b;
                              cVar8 = func_0x(0x1e85930);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar44 + -8) = 0x101127;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar44 + 0x20) = 0;
                                *(undefined8 *)(puVar44 + -8) = 0x10114d;
                                (*_DAT_)(1,0x17766b8,0x1896388,0x80f);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                          *(undefined8 *)(puVar44 + -8) = 0x10115b;
                          func_0x(uVar24,3);
                          uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                          uVar36 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                          pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                        }
                        uVar48 = (int)uVar36 + (uVar12 + 1) * 2;
                        *(uint *)(&stack0x00000050 + lVar16) = uVar48;
                        if (0x1f9e < uVar48) {
                          *(undefined8 *)(puVar44 + -8) = 0x10118e;
                          cVar8 = func_0x(0x1e85930);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar44 + -8) = 0x101197;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar44 + -8) = 0x1011b1;
                              cVar8 = func_0x(0x1e85930);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar44 + -8) = 0x1011cd;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar44 + 0x20) = 0;
                                *(undefined8 *)(puVar44 + -8) = 0x1011f3;
                                (*_DAT_)(1,0x17766b8,0x1896388,0x816);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                          *(undefined8 *)(puVar44 + -8) = 0x101201;
                          func_0x(uVar24,4);
                          uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                          uVar48 = *(uint *)(&stack0x00000050 + lVar16);
                          uVar36 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                          pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                        }
                        uVar37 = (ulonglong)uVar12;
                        uVar40 = puVar49[uVar37] & 0x7fff;
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40;
                        if (uVar40 < uVar48) {
                          *(undefined8 *)(puVar44 + -8) = 0x10123a;
                          cVar8 = func_0x(0x1e85930);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar44 + -8) = 0x101243;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar44 + -8) = 0x10125d;
                              cVar8 = func_0x(0x1e85930);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar44 + -8) = 0x101279;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar44 + 0x20) = 0;
                                *(undefined8 *)(puVar44 + -8) = 0x10129f;
                                (*_DAT_)(1,0x17766b8,0x1896388,0x81d);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                          *(undefined8 *)(puVar44 + -8) = 0x1012ad;
                          func_0x(uVar24,4);
                          uVar37 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar16);
                          uVar48 = *(uint *)(&stack0x00000050 + lVar16);
                          uVar36 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                          pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                          uVar40 = *(uint *)(&stack0x0000003c + lVar16);
                        }
                        do {
                          sVar11 = (short)uVar37;
                          if (-1 < (short)puVar49[(ulonglong)((int)uVar37 - 1) + 1]) break;
                          uVar30 = uVar48;
                          if ((int)uVar37 != 1) {
                            uVar30 = *(ushort *)(pbVar35 + uVar37 * 2 + (uVar36 - 2)) & 0x7fff;
                          }
                          if ((uVar30 < uVar48) ||
                             ((*(ushort *)(pbVar35 + uVar37 * 2 + uVar36) & 0x7fff) < uVar30)) {
                            *(undefined8 *)(puVar44 + -8) = 0x10130c;
                            func_0x(pbVar35,7);
                            sVar11 = *(short *)(&stack0x00000054 + lVar16);
                            uVar48 = *(uint *)(&stack0x00000050 + lVar16);
                            uVar36 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                            pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                            uVar40 = *(uint *)(&stack0x0000003c + lVar16);
                          }
                          if ((uVar30 < uVar48) || (uVar40 < uVar30)) goto LAB_;
                          if (*(ushort *)(pbVar35 + uVar30) == 5) {
                            *(ushort *)(&stack0x0000003a + lVar16) =
                                 *(ushort *)(&stack0x0000003a + lVar16) | 2;
                            *(short *)(&stack0x00000054 + lVar16) = sVar11 + -1;
                            *(short *)(&stack0x00000062 + lVar16) = (short)uVar30;
                            uVar12 = *(ushort *)(&stack0x00000064 + lVar16);
                            if ((*(ushort *)(pbVar35 + (ulonglong)(uVar30 & 0xffff) + 2) >> 0xe & 1)
                                == 0) {
                              uVar12 = uVar12 & 0xc7ff;
                            }
                            else {
                              uVar12 = uVar12 ^ (uVar12 ^ *(ushort *)
                                                           (pbVar35 +
                                                           (ulonglong)(uVar30 & 0xffff) + 2)) &
                                                0x3800;
                            }
                            *(ushort *)(&stack0x00000064 + lVar16) = uVar12;
                            *(ushort *)(&stack0x00000064 + lVar16) =
                                 uVar12 ^ (uVar12 ^ *(ushort *)
                                                     (pbVar35 + (ulonglong)(uVar30 & 0xffff) + 2)) &
                                          0x7ff;
                            break;
                          }
                          if (*(ushort *)(pbVar35 + uVar30) < 0x400) break;
                          *(ushort *)(&stack0x0000003a + lVar16) =
                               *(ushort *)(&stack0x0000003a + lVar16) | 1;
                          uVar12 = sVar11 - 1;
                          uVar37 = (ulonglong)uVar12;
                          *(ushort *)(&stack0x00000054 + lVar16) = uVar12;
                        } while (uVar12 != 0);
                      }
                      if ((*pbVar35 & 0x40) == 0) {
                        *(undefined4 *)(&stack0x0000005e + lVar16) = 0;
                      }
                      else {
                        *(uint *)(&stack0x0000005e + lVar16) = uVar40;
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40 + 0xe;
                        *(undefined8 *)(puVar44 + -8) = 0x1013f3;
                        uVar24 = func_0x(&stack0x0000003a + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x101402;
                        func_0x(uVar24,&stack0x00000180 + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x10140e;
                        iVar14 = func_0x(&stack0x00000180 + lVar16);
                        uVar40 = *(int *)(&stack0x0000003c + lVar16) + iVar14;
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40;
                        pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                      }
                      if ((*(byte **)(&stack0x00000056 + lVar16) != (byte *)0x0) &&
                         (*(byte **)(&stack0x00000056 + lVar16) < pbVar35 + uVar40)) {
                        *(undefined8 *)(puVar44 + -8) = 0x10144b;
                        cVar8 = func_0x(0x1e85930);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar44 + -8) = 0x101454;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar44 + -8) = 0x10146e;
                            cVar8 = func_0x(0x1e85930);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar44 + -8) = 0x10148a;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(puVar44 + 0x20) = 0;
                              *(undefined8 *)(puVar44 + -8) = 0x1014b0;
                              (*_DAT_)(1,0x17766b8,0x1896388,0x877);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x1014be;
                        func_0x(uVar24,0x12);
                        uVar40 = *(uint *)(&stack0x0000003c + lVar16);
                      }
                      if (0x3f3b < uVar40 - 1) {
                        *(undefined8 *)(puVar44 + -8) = 0x1014d9;
                        cVar8 = func_0x(0x1e85930);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar44 + -8) = 0x1014e2;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar44 + -8) = 0x1014fc;
                            cVar8 = func_0x(0x1e85930);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar44 + -8) = 0x101518;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(puVar44 + 0x20) = 0;
                              *(undefined8 *)(puVar44 + -8) = 0x10153e;
                              (*_DAT_)(1,0x17766b8,0x1896388,0x87c);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x10154c;
                        func_0x(uVar24,5);
                      }
                    }
LAB_:
                    *(undefined8 *)(puVar44 + -8) = 0x101555;
                    func_0x(&stack0x0000003a + lVar16);
                    bVar28 = **(byte **)(&stack0x00000040 + lVar16);
                    if ((bVar28 >> 6 & 1) != 0) {
                      *(undefined8 *)(puVar44 + -8) = 0x101577;
                      func_0x(&stack0x0000003a + lVar16,&stack0x000008f8 + lVar16);
                    }
                    if (((&stack0x0000003a)[lVar16] & 1) != 0) {
                      *(undefined8 *)(puVar44 + -8) = 0x10158f;
                      puVar18 = (undefined4 *)
                                func_0x(&stack0x0000003a + lVar16,0x400,
                                                &stack0x000000a8 + lVar16);
                      *(undefined4 *)(&stack0x00000110 + lVar16) = *puVar18;
                      *(undefined2 *)(&stack0x00000114 + lVar16) = *(undefined2 *)(puVar18 + 1);
                      *(undefined2 *)(&stack0x00000116 + lVar16) =
                           *(undefined2 *)((longlong)puVar18 + 6);
                    }
                    if ((**(byte **)(&stack0x00000040 + lVar16) & 0x20) == 0) {
                      *(undefined8 *)(puVar44 + -8) = 0x1015bf;
                      func_0x(&stack0x0000003a + lVar16);
                    }
                    lVar23 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16) +
                             *(longlong *)(&stack0x00000040 + lVar16);
                    *(undefined8 *)(puVar44 + -8) = 0x1015cf;
                    iVar14 = func_0x(&stack0x0000003a + lVar16);
                    lVar17 = *(longlong *)(&stack0x00000040 + lVar16);
                    if (iVar14 == 0) {
                      uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                      uVar36 = (ulonglong)uVar12;
                      puVar49 = (ushort *)(lVar17 + (ulonglong)*(uint *)(&stack0x0000004c + lVar16))
                      ;
                      uVar40 = *(uint *)(&stack0x0000004c + lVar16) + (uVar12 + 1) * 2;
                      if (*puVar49 != 0) {
                        do {
                          uVar29 = puVar49[uVar45 + 1];
                          puVar49[(uVar45 & 0xffff) + 1] = puVar49[(uVar45 & 0xffff) + 1] & 0x8000;
                          puVar49[(uVar45 & 0xffff) + 1] =
                               puVar49[(uVar45 & 0xffff) + 1] | (uVar29 & 0x7fff) + 2 & 0x7fff;
                          uVar48 = (int)uVar45 + 1;
                          uVar45 = (ulonglong)uVar48;
                        } while (uVar48 < *puVar49);
                        lVar17 = *(longlong *)(&stack0x00000040 + lVar16);
                      }
                      iVar14 = *(int *)(&stack0x0000003c + lVar16);
                      *(undefined8 *)(puVar44 + -8) = 0x1016ba;
                      func_0x
                                ((ulonglong)uVar40 + 2 + lVar17,(ulonglong)uVar40 + lVar17,
                                 iVar14 - uVar40);
                      *(int *)(&stack0x0000003c + lVar16) = *(int *)(&stack0x0000003c + lVar16) + 2;
                      uVar40 = *(int *)(&stack0x00000050 + lVar16) + 2;
                      *(uint *)(&stack0x00000050 + lVar16) = uVar40;
                      if (uVar12 != 0) {
                        uVar40 = puVar49[(ulonglong)(uVar12 - 1) + 1] & 0x7fff;
                      }
                      if ((uint)uVar12 < uVar12 + 1) {
                        do {
                          puVar49[(uVar36 & 0xffff) + 1] = (ushort)uVar40 & 0x7fff;
                          uVar48 = (int)uVar36 + 1;
                          uVar36 = (ulonglong)uVar48;
                        } while (uVar48 < uVar12 + 1);
                      }
                      *puVar49 = *puVar49 + 1;
                      *(undefined8 *)(puVar44 + -8) = 0x10170a;
                      func_0x(&stack0x0000003a + lVar16);
                      uVar12 = *(ushort *)
                                (lVar23 + 2 + (ulonglong)*(ushort *)(&stack0x00000054 + lVar16) * 2)
                      ;
                      *(undefined8 *)(puVar44 + -8) = 0x101722;
                      func_0x(&stack0x00000278 + lVar16);
                      *(undefined4 *)(puVar44 + 0x28) = 0;
                      *(longlong **)(puVar44 + 0x20) = plVar42;
                      *(undefined8 *)(puVar44 + -8) = 0x101742;
                      func_0x(&stack0x00000268 + lVar16,pcVar4,1);
                      *(undefined **)(puVar44 + 0x28) = &stack0x000000f8 + lVar16;
                      *(undefined **)(puVar44 + 0x20) = &stack0x00000268 + lVar16;
                      *(undefined8 *)(puVar44 + -8) = 0x10177b;
                      func_0x(&stack0x00000062 + lVar16,uVar12 & 0x7fff,0x1f9e);
                      iVar14 = *(int *)(&stack0x000000f8 + lVar16);
                    }
                    else {
                      uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                      uVar40 = *(uint *)(&stack0x00000050 + lVar16);
                      if (uVar12 != 0) {
                        uVar40 = *(ushort *)
                                  ((ulonglong)*(uint *)(&stack0x0000004c + lVar16) + lVar17 +
                                  (ulonglong)uVar12 * 2) & 0x7fff;
                      }
                      uVar41 = *(ushort *)
                                ((ulonglong)*(uint *)(&stack0x0000004c + lVar16) + lVar17 + 2 +
                                (ulonglong)(uint)uVar12 * 2) & 0x7fff;
                      if ((uVar40 < *(uint *)(&stack0x00000050 + lVar16)) || (uVar41 < uVar40)) {
                        *(undefined8 *)(puVar44 + -8) = 0x10161d;
                        func_0x(lVar17,7);
                      }
                      uVar41 = uVar41 - uVar40;
                      *(undefined8 *)(puVar44 + -8) = 0x101634;
                      iVar14 = func_0x(&stack0x00000062 + lVar16,plVar42,pcVar4);
                    }
                    iVar34 = (*(int *)(&stack0x0000003c + lVar16) - uVar41) + iVar14;
                    *(int *)(&stack0x0000003c + lVar16) = iVar34;
                    if (((&stack0x0000003a)[lVar16] & 1) != 0) {
                      *(ushort *)
                       (lVar23 + 2 + (ulonglong)(*(ushort *)(&stack0x00000054 + lVar16) + 1) * 2) =
                           (ushort)iVar34 | 0x8000;
                      iVar34 = (*(int *)(&stack0x0000003c + lVar16) -
                               *(int *)(&stack0x000000a8 + lVar16)) + -2;
                    }
                    *(ushort *)(lVar23 + 2 + (ulonglong)*(ushort *)(&stack0x00000054 + lVar16) * 2)
                         = (ushort)iVar34 | 0x8000;
                    if (iVar14 == 0) {
                      uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                      *(undefined8 *)(puVar44 + -8) = 0x1017cf;
                      func_0x(&stack0x0000003a + lVar16,uVar12 + 1);
                      if ((**(byte **)(&stack0x00000040 + lVar16) & 0x20) != 0) {
                        *(short *)(&stack0x00000054 + lVar16) =
                             *(short *)(&stack0x00000054 + lVar16) + 1;
                        *(ushort *)(&stack0x0000003a + lVar16) =
                             *(ushort *)(&stack0x0000003a + lVar16) & 0xfffd;
                        *(undefined8 *)(puVar44 + -8) = 0x1017ee;
                        func_0x(&stack0x00000062 + lVar16);
                      }
                    }
                    else {
                      *(ushort *)(&stack0x0000003a + lVar16) =
                           *(ushort *)(&stack0x0000003a + lVar16) | 2;
                      *(undefined8 *)(puVar44 + -8) = 0x101801;
                      uVar13 = func_0x
                                         (&stack0x0000003a + lVar16,&stack0x0000016c + lVar16);
                      *(undefined2 *)(&stack0x00000062 + lVar16) = uVar13;
                    }
                    if (((&stack0x0000003a)[lVar16] & 1) != 0) {
                      uVar15 = *(undefined4 *)(&stack0x000000a8 + lVar16);
                      *(undefined8 *)(puVar44 + -8) = 0x101824;
                      func_0x(&stack0x0000003a + lVar16,0x400,uVar15);
                    }
                    if ((bVar28 >> 6 & 1) != 0) {
                      *(undefined8 *)(puVar44 + -8) = 0x101839;
                      func_0x(&stack0x0000003a + lVar16,&stack0x000008f8 + lVar16);
                    }
                    param_2 = *(longlong ***)(&stack0x00000078 + lVar16);
                  }
                  else {
                    if (*(int *)(&stack0x0000003c + lVar16) == 0) {
                      *(undefined2 *)(&stack0x0000003a + lVar16) = 0;
                      uVar40 = *(uint *)(&stack0x00000048 + lVar16);
                      uVar45 = (ulonglong)uVar40;
                      *(uint *)(&stack0x0000004c + lVar16) = uVar40;
                      pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                      if ((*pbVar35 & 0x10) != 0) {
                        uVar40 = uVar40 + 2 + (*(ushort *)(pbVar35 + uVar45) + 7 >> 3);
                        uVar45 = (ulonglong)uVar40;
                        *(uint *)(&stack0x0000004c + lVar16) = uVar40;
                      }
                      uVar40 = (uint)uVar45;
                      if ((*pbVar35 & 0x20) == 0) {
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40;
                        *(undefined2 *)(&stack0x00000054 + lVar16) = 0;
                        *(uint *)(&stack0x00000050 + lVar16) = uVar40;
                      }
                      else {
                        puVar49 = (ushort *)(pbVar35 + uVar45);
                        uVar12 = *puVar49;
                        *(ushort *)(&stack0x00000054 + lVar16) = uVar12;
                        if (uVar12 == 0) {
                          *(undefined8 *)(puVar44 + -8) = 0x100990;
                          cVar8 = func_0x(0x1e85930);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar44 + -8) = 0x100999;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar44 + -8) = 0x1009b3;
                              cVar8 = func_0x(0x1e85930);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar44 + -8) = 0x1009cf;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar44 + 0x20) = 0;
                                *(undefined8 *)(puVar44 + -8) = 0x1009f5;
                                (*_DAT_)(1,0x17766b8,0x1896388,0x80f);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                          *(undefined8 *)(puVar44 + -8) = 0x100a03;
                          func_0x(uVar24,3);
                          uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                          uVar45 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                          pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                        }
                        uVar41 = (int)uVar45 + (uVar12 + 1) * 2;
                        *(uint *)(&stack0x00000050 + lVar16) = uVar41;
                        if (0x1f9e < uVar41) {
                          *(undefined8 *)(puVar44 + -8) = 0x100a36;
                          cVar8 = func_0x(0x1e85930);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar44 + -8) = 0x100a3f;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar44 + -8) = 0x100a59;
                              cVar8 = func_0x(0x1e85930);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar44 + -8) = 0x100a75;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar44 + 0x20) = 0;
                                *(undefined8 *)(puVar44 + -8) = 0x100a9b;
                                (*_DAT_)(1,0x17766b8,0x1896388,0x816);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                          *(undefined8 *)(puVar44 + -8) = 0x100aa9;
                          func_0x(uVar24,4);
                          uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                          uVar41 = *(uint *)(&stack0x00000050 + lVar16);
                          uVar45 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                          pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                        }
                        uVar36 = (ulonglong)uVar12;
                        uVar40 = puVar49[uVar36] & 0x7fff;
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40;
                        if (uVar40 < uVar41) {
                          *(undefined8 *)(puVar44 + -8) = 0x100ae2;
                          cVar8 = func_0x(0x1e85930);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar44 + -8) = 0x100aeb;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar44 + -8) = 0x100b05;
                              cVar8 = func_0x(0x1e85930);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar44 + -8) = 0x100b21;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar44 + 0x20) = 0;
                                *(undefined8 *)(puVar44 + -8) = 0x100b47;
                                (*_DAT_)(1,0x17766b8,0x1896388,0x81d);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                          *(undefined8 *)(puVar44 + -8) = 0x100b55;
                          func_0x(uVar24,4);
                          uVar36 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar16);
                          uVar41 = *(uint *)(&stack0x00000050 + lVar16);
                          uVar45 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                          pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                          uVar40 = *(uint *)(&stack0x0000003c + lVar16);
                        }
                        do {
                          sVar11 = (short)uVar36;
                          if (-1 < (short)puVar49[(ulonglong)((int)uVar36 - 1) + 1]) break;
                          uVar48 = uVar41;
                          if ((int)uVar36 != 1) {
                            uVar48 = *(ushort *)(pbVar35 + uVar36 * 2 + (uVar45 - 2)) & 0x7fff;
                          }
                          if ((uVar48 < uVar41) ||
                             ((*(ushort *)(pbVar35 + uVar36 * 2 + uVar45) & 0x7fff) < uVar48)) {
                            *(undefined8 *)(puVar44 + -8) = 0x100bbc;
                            func_0x(pbVar35,7);
                            sVar11 = *(short *)(&stack0x00000054 + lVar16);
                            uVar41 = *(uint *)(&stack0x00000050 + lVar16);
                            uVar45 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                            pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                            uVar40 = *(uint *)(&stack0x0000003c + lVar16);
                          }
                          if ((uVar48 < uVar41) || (uVar40 < uVar48)) goto LAB_;
                          if (*(ushort *)(pbVar35 + uVar48) == 5) {
                            *(ushort *)(&stack0x0000003a + lVar16) =
                                 *(ushort *)(&stack0x0000003a + lVar16) | 2;
                            *(short *)(&stack0x00000054 + lVar16) = sVar11 + -1;
                            *(short *)(&stack0x00000062 + lVar16) = (short)uVar48;
                            uVar12 = *(ushort *)(&stack0x00000064 + lVar16);
                            if ((*(ushort *)(pbVar35 + (ulonglong)(uVar48 & 0xffff) + 2) >> 0xe & 1)
                                == 0) {
                              uVar12 = uVar12 & 0xc7ff;
                            }
                            else {
                              uVar12 = uVar12 ^ (uVar12 ^ *(ushort *)
                                                           (pbVar35 +
                                                           (ulonglong)(uVar48 & 0xffff) + 2)) &
                                                0x3800;
                            }
                            *(ushort *)(&stack0x00000064 + lVar16) = uVar12;
                            *(ushort *)(&stack0x00000064 + lVar16) =
                                 uVar12 ^ (uVar12 ^ *(ushort *)
                                                     (pbVar35 + (ulonglong)(uVar48 & 0xffff) + 2)) &
                                          0x7ff;
                            break;
                          }
                          if (*(ushort *)(pbVar35 + uVar48) < 0x400) break;
                          *(ushort *)(&stack0x0000003a + lVar16) =
                               *(ushort *)(&stack0x0000003a + lVar16) | 1;
                          uVar12 = sVar11 - 1;
                          uVar36 = (ulonglong)uVar12;
                          *(ushort *)(&stack0x00000054 + lVar16) = uVar12;
                        } while (uVar12 != 0);
                      }
                      if ((*pbVar35 & 0x40) == 0) {
                        *(undefined4 *)(&stack0x0000005e + lVar16) = 0;
                      }
                      else {
                        *(uint *)(&stack0x0000005e + lVar16) = uVar40;
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40 + 0xe;
                        *(undefined8 *)(puVar44 + -8) = 0x100c9b;
                        uVar24 = func_0x(&stack0x0000003a + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x100caa;
                        func_0x(uVar24,&stack0x00000178 + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x100cb6;
                        iVar14 = func_0x(&stack0x00000178 + lVar16);
                        uVar40 = *(int *)(&stack0x0000003c + lVar16) + iVar14;
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40;
                        pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                      }
                      if ((*(byte **)(&stack0x00000056 + lVar16) != (byte *)0x0) &&
                         (*(byte **)(&stack0x00000056 + lVar16) < pbVar35 + uVar40)) {
                        *(undefined8 *)(puVar44 + -8) = 0x100cf3;
                        cVar8 = func_0x(0x1e85930);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar44 + -8) = 0x100cfc;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar44 + -8) = 0x100d16;
                            cVar8 = func_0x(0x1e85930);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar44 + -8) = 0x100d32;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar44 + 0x20) = 0;
                              *(undefined8 *)(puVar44 + -8) = 0x100d58;
                              (*_DAT_)(1,0x17766b8,0x1896388);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x100d66;
                        func_0x(uVar24,0x12);
                        uVar40 = *(uint *)(&stack0x0000003c + lVar16);
                      }
                      if (0x3f3b < uVar40 - 1) {
                        *(undefined8 *)(puVar44 + -8) = 0x100d81;
                        cVar8 = func_0x(0x1e85930);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar44 + -8) = 0x100d8a;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar44 + -8) = 0x100da4;
                            cVar8 = func_0x(0x1e85930);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar44 + -8) = 0x100dc0;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar44 + 0x20) = 0;
                              *(undefined8 *)(puVar44 + -8) = 0x100de6;
                              (*_DAT_)(1,0x17766b8,0x1896388);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x100df4;
                        func_0x(uVar24,5);
                      }
                    }
LAB_:
                    uVar40 = -*(uint *)plVar42;
                    *(undefined8 *)(puVar44 + -8) = 0x100e07;
                    func_0x(&stack0x00000818 + lVar16);
                    pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                    bVar28 = *pbVar35;
                    if ((bVar28 >> 6 & 1) != 0) {
                      *(undefined8 *)(puVar44 + -8) = 0x100e29;
                      func_0x(&stack0x0000003a + lVar16,&stack0x00000818 + lVar16);
                      pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                    }
                    if ((*pbVar35 & 0x20) == 0) {
                      *(undefined8 *)(puVar44 + -8) = 0x100e3c;
                      func_0x(&stack0x0000003a + lVar16);
                      pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                    }
                    uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                    uVar48 = (uint)uVar12;
                    uVar41 = (uint)uVar12;
                    if (uVar41 < uVar40) {
                      puVar49 = (ushort *)(pbVar35 + *(uint *)(&stack0x0000004c + lVar16));
                      uVar48 = *(uint *)(&stack0x0000004c + lVar16) + 2 + uVar41 * 2;
                      uVar30 = (uVar40 - uVar12) * 2;
                      uVar33 = 0;
                      if (*puVar49 != 0) {
                        do {
                          uVar29 = puVar49[(ulonglong)uVar33 + 1];
                          puVar49[(ulonglong)(uVar33 & 0xffff) + 1] =
                               puVar49[(ulonglong)(uVar33 & 0xffff) + 1] & 0x8000;
                          puVar49[(ulonglong)(uVar33 & 0xffff) + 1] =
                               puVar49[(ulonglong)(uVar33 & 0xffff) + 1] |
                               (uVar29 & 0x7fff) + (short)uVar30 & 0x7fff;
                          uVar33 = uVar33 + 1;
                        } while (uVar33 < *puVar49);
                        pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                      }
                      iVar14 = *(int *)(&stack0x0000003c + lVar16);
                      *(undefined8 *)(puVar44 + -8) = 0x100eca;
                      func_0x
                                (pbVar35 + (ulonglong)uVar48 + (ulonglong)uVar30,pbVar35 + uVar48,
                                 iVar14 - uVar48);
                      *(uint *)(&stack0x0000003c + lVar16) =
                           *(int *)(&stack0x0000003c + lVar16) + uVar30;
                      uVar30 = *(int *)(&stack0x00000050 + lVar16) + uVar30;
                      *(uint *)(&stack0x00000050 + lVar16) = uVar30;
                      if (uVar12 != 0) {
                        uVar30 = puVar49[(ulonglong)(uVar41 - 1) + 1] & 0x7fff;
                      }
                      do {
                        puVar49[(ulonglong)(uVar41 & 0xffff) + 1] = (ushort)uVar30 & 0x7fff;
                        uVar41 = uVar41 + 1;
                      } while (uVar41 < uVar40);
                      *puVar49 = *puVar49 + (short)(uVar40 - uVar12);
                      *(undefined8 *)(puVar44 + -8) = 0x100f0c;
                      iVar14 = func_0x(&stack0x0000003a + lVar16);
                      if (iVar14 != 0) {
                        *(undefined8 *)(puVar44 + -8) = 0x100f20;
                        uVar13 = func_0x
                                           (&stack0x0000003a + lVar16,&stack0x000001c0 + lVar16);
                        *(undefined2 *)(&stack0x00000062 + lVar16) = uVar13;
                      }
                      uVar48 = uVar40 & 0xffff;
                      *(short *)(&stack0x00000054 + lVar16) = (short)uVar40;
                      pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                    }
                    uVar45 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                    if (uVar48 < uVar40) {
                      uVar41 = *(ushort *)(pbVar35 + (ulonglong)uVar48 * 2 + uVar45) & 0x7fff;
                      iVar14 = 0;
LAB_:
                      puVar49 = (ushort *)(pbVar35 + uVar45);
                      uVar15 = *(undefined4 *)(&stack0x0000003c + lVar16);
                      *(undefined8 *)(puVar44 + -8) = 0x100fb7;
                      uVar15 = func_0x(uVar15,iVar14 + uVar41);
                      lVar17 = *(longlong *)(&stack0x00000040 + lVar16);
                      *(undefined8 *)(puVar44 + -8) = 0x100fd3;
                      func_0x
                                (lVar17 + 1 + (ulonglong)uVar41,iVar14 + lVar17 + (ulonglong)uVar41,
                                 uVar15);
                      uVar40 = uVar40 - 1;
                      if ((int)uVar40 < (int)(uint)*puVar49) {
                        do {
                          uVar12 = puVar49[(longlong)(int)uVar40 + 1];
                          puVar49[((ulonglong)uVar40 & 0xffff) + 1] =
                               puVar49[((ulonglong)uVar40 & 0xffff) + 1] & 0x8000;
                          puVar49[((ulonglong)uVar40 & 0xffff) + 1] =
                               puVar49[((ulonglong)uVar40 & 0xffff) + 1] |
                               ((uVar12 & 0x7fff) - (short)iVar14) + 1 & 0x7fff;
                          uVar40 = uVar40 + 1;
                        } while ((int)uVar40 < (int)(uint)*puVar49);
                      }
                      *(int *)(&stack0x0000003c + lVar16) =
                           *(int *)(&stack0x0000003c + lVar16) + (1 - iVar14);
                      *(undefined8 *)(puVar44 + -8) = 0x101030;
                      iVar14 = func_0x(&stack0x0000003a + lVar16);
                      if (iVar14 != 0) {
                        *(undefined8 *)(puVar44 + -8) = 0x101044;
                        uVar13 = func_0x
                                           (&stack0x0000003a + lVar16,&stack0x00000168 + lVar16);
                        *(undefined2 *)(&stack0x00000062 + lVar16) = uVar13;
                      }
                      pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                    }
                    else {
                      uVar41 = *(uint *)(&stack0x00000050 + lVar16);
                      if (uVar40 != 1) {
                        uVar41 = *(ushort *)(pbVar35 + (longlong)(int)uVar40 * 2 + (uVar45 - 2)) &
                                 0x7fff;
                      }
                      uVar12 = *(ushort *)(pbVar35 + (longlong)(int)uVar40 * 2 + uVar45);
                      if ((uVar41 < *(uint *)(&stack0x00000050 + lVar16)) ||
                         ((uVar12 & 0x7fff) < uVar41)) {
                        *(undefined8 *)(puVar44 + -8) = 0x100f7e;
                        func_0x(pbVar35,7);
                        uVar45 = (ulonglong)*(uint *)(&stack0x0000004c + lVar16);
                        pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                      }
                      iVar14 = (uVar12 & 0x7fff) - uVar41;
                      if (iVar14 != 1) goto LAB_;
                    }
                    pbVar35[uVar41] = **(byte **)(&stack0x000000a0 + lVar16);
                    if ((bVar28 >> 6 & 1) != 0) {
                      *(undefined8 *)(puVar44 + -8) = 0x10106f;
                      func_0x(&stack0x0000003a + lVar16,&stack0x00000818 + lVar16);
                    }
                    param_2 = *(longlong ***)(&stack0x00000078 + lVar16);
                  }
                }
                else {
                  bVar28 = (byte)*(ushort *)((longlong)plVar42 + 6);
                  if ((*(ushort *)((longlong)plVar42 + 6) & 8) == 0) {
                    if (*(int *)(&stack0x0000003c + lVar16) == 0) {
                      *(undefined2 *)(&stack0x0000003a + lVar16) = 0;
                      uVar40 = *(uint *)(&stack0x00000048 + lVar16);
                      *(uint *)(&stack0x0000004c + lVar16) = uVar40;
                      if ((**(byte **)(&stack0x00000040 + lVar16) & 0x10) != 0) {
                        *(uint *)(&stack0x0000004c + lVar16) =
                             uVar40 + 2 +
                             (*(ushort *)(*(byte **)(&stack0x00000040 + lVar16) + uVar40) + 7 >> 3);
                      }
                      if ((**(byte **)(&stack0x00000040 + lVar16) & 0x20) == 0) {
                        uVar40 = *(uint *)(&stack0x0000004c + lVar16);
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40;
                        *(undefined2 *)(&stack0x00000054 + lVar16) = 0;
                        *(uint *)(&stack0x00000050 + lVar16) = uVar40;
                      }
                      else {
                        puVar49 = (ushort *)
                                  (*(byte **)(&stack0x00000040 + lVar16) +
                                  *(uint *)(&stack0x0000004c + lVar16));
                        uVar12 = *puVar49;
                        *(ushort *)(&stack0x00000054 + lVar16) = uVar12;
                        if (uVar12 == 0) {
                          *(undefined8 *)(puVar44 + -8) = 0x100397;
                          cVar8 = func_0x(0x1e85930);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar44 + -8) = 0x1003a0;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar44 + -8) = 0x1003ba;
                              cVar8 = func_0x(0x1e85930);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar44 + -8) = 0x1003d6;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar44 + 0x20) = 0;
                                *(undefined8 *)(puVar44 + -8) = 0x1003fc;
                                (*_DAT_)(1,0x17766b8,0x1896388,0x80f);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                          *(undefined8 *)(puVar44 + -8) = 0x10040a;
                          func_0x(uVar24,3);
                          uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                        }
                        uVar41 = *(int *)(&stack0x0000004c + lVar16) + 2 + (uint)uVar12 * 2;
                        *(uint *)(&stack0x00000050 + lVar16) = uVar41;
                        if (0x1f9e < uVar41) {
                          *(undefined8 *)(puVar44 + -8) = 0x100439;
                          cVar8 = func_0x(0x1e85930);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar44 + -8) = 0x100442;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar44 + -8) = 0x10045c;
                              cVar8 = func_0x(0x1e85930);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar44 + -8) = 0x100478;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar44 + 0x20) = 0;
                                *(undefined8 *)(puVar44 + -8) = 0x10049e;
                                (*_DAT_)(1,0x17766b8,0x1896388,0x816);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                          *(undefined8 *)(puVar44 + -8) = 0x1004ac;
                          func_0x(uVar24,4);
                          uVar12 = *(ushort *)(&stack0x00000054 + lVar16);
                          uVar41 = *(uint *)(&stack0x00000050 + lVar16);
                        }
                        uVar45 = (ulonglong)uVar12;
                        uVar40 = puVar49[uVar45] & 0x7fff;
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40;
                        if (uVar40 < uVar41) {
                          *(undefined8 *)(puVar44 + -8) = 0x1004de;
                          cVar8 = func_0x(0x1e85930);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar44 + -8) = 0x1004e7;
                            lVar17 = func_0x();
                            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar44 + -8) = 0x100501;
                              cVar8 = func_0x(0x1e85930);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar44 + -8) = 0x10051d;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar44 + 0x20) = 0;
                                *(undefined8 *)(puVar44 + -8) = 0x100543;
                                (*_DAT_)(1,0x17766b8,0x1896388,0x81d);
                              }
                            }
                          }
                          uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                          *(undefined8 *)(puVar44 + -8) = 0x100551;
                          func_0x(uVar24,4);
                          uVar45 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar16);
                          uVar41 = *(uint *)(&stack0x00000050 + lVar16);
                          uVar40 = *(uint *)(&stack0x0000003c + lVar16);
                        }
                        do {
                          if (-1 < (short)puVar49[(ulonglong)((int)uVar45 - 1) + 1]) break;
                          uVar48 = uVar41;
                          if ((int)uVar45 != 1) {
                            uVar48 = *(ushort *)
                                      ((ulonglong)*(uint *)(&stack0x0000004c + lVar16) +
                                       *(longlong *)(&stack0x00000040 + lVar16) + -2 + uVar45 * 2) &
                                     0x7fff;
                          }
                          if ((uVar48 < uVar41) ||
                             ((*(ushort *)
                                ((ulonglong)*(uint *)(&stack0x0000004c + lVar16) +
                                 *(longlong *)(&stack0x00000040 + lVar16) + uVar45 * 2) & 0x7fff) <
                              uVar48)) {
                            uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                            *(undefined8 *)(puVar44 + -8) = 0x1005bf;
                            func_0x(uVar24,7);
                            uVar45 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar16);
                            uVar41 = *(uint *)(&stack0x00000050 + lVar16);
                            uVar40 = *(uint *)(&stack0x0000003c + lVar16);
                          }
                          if ((uVar48 < uVar41) || (uVar40 < uVar48)) goto LAB_;
                          if (*(ushort *)
                               ((ulonglong)uVar48 + *(longlong *)(&stack0x00000040 + lVar16)) == 5)
                          {
                            *(ushort *)(&stack0x0000003a + lVar16) =
                                 *(ushort *)(&stack0x0000003a + lVar16) | 2;
                            *(short *)(&stack0x00000054 + lVar16) = (short)uVar45 + -1;
                            *(short *)(&stack0x00000062 + lVar16) = (short)uVar48;
                            lVar17 = (ulonglong)(uVar48 & 0xffff) +
                                     *(longlong *)(&stack0x00000040 + lVar16);
                            uVar12 = *(ushort *)(lVar17 + 2);
                            uVar29 = *(ushort *)(&stack0x00000064 + lVar16);
                            if ((uVar12 >> 0xe & 1) == 0) {
                              uVar29 = uVar29 & 0xc7ff;
                            }
                            else {
                              uVar29 = uVar29 ^ (uVar29 ^ uVar12) & 0x3800;
                            }
                            *(ushort *)(&stack0x00000064 + lVar16) = uVar29;
                            *(ushort *)(&stack0x00000064 + lVar16) =
                                 uVar29 ^ (uVar29 ^ *(ushort *)(lVar17 + 2)) & 0x7ff;
                            break;
                          }
                          if (*(ushort *)
                               ((ulonglong)uVar48 + *(longlong *)(&stack0x00000040 + lVar16)) <
                              0x400) break;
                          *(ushort *)(&stack0x0000003a + lVar16) =
                               *(ushort *)(&stack0x0000003a + lVar16) | 1;
                          uVar12 = (short)uVar45 - 1;
                          uVar45 = (ulonglong)uVar12;
                          *(ushort *)(&stack0x00000054 + lVar16) = uVar12;
                        } while (uVar12 != 0);
                      }
                      if ((**(byte **)(&stack0x00000040 + lVar16) & 0x40) == 0) {
                        *(undefined4 *)(&stack0x0000005e + lVar16) = 0;
                      }
                      else {
                        *(uint *)(&stack0x0000005e + lVar16) = uVar40;
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40 + 0xe;
                        *(undefined8 *)(puVar44 + -8) = 0x1006a8;
                        uVar24 = func_0x(&stack0x0000003a + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x1006b7;
                        func_0x(uVar24,&stack0x00000170 + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x1006c3;
                        iVar14 = func_0x(&stack0x00000170 + lVar16);
                        uVar40 = *(int *)(&stack0x0000003c + lVar16) + iVar14;
                        *(uint *)(&stack0x0000003c + lVar16) = uVar40;
                      }
                      if ((*(ulonglong *)(&stack0x00000056 + lVar16) != 0) &&
                         (*(ulonglong *)(&stack0x00000056 + lVar16) <
                          (ulonglong)uVar40 + *(longlong *)(&stack0x00000040 + lVar16))) {
                        *(undefined8 *)(puVar44 + -8) = 0x1006fd;
                        cVar8 = func_0x(0x1e85930);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar44 + -8) = 0x100706;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar44 + -8) = 0x100720;
                            cVar8 = func_0x(0x1e85930);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar44 + -8) = 0x10073c;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(puVar44 + 0x20) = 0;
                              *(undefined8 *)(puVar44 + -8) = 0x100762;
                              (*_DAT_)(1,0x17766b8,0x1896388,0x877);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x100770;
                        func_0x(uVar24,0x12);
                        uVar40 = *(uint *)(&stack0x0000003c + lVar16);
                      }
                      if (0x3f3b < uVar40 - 1) {
                        *(undefined8 *)(puVar44 + -8) = 0x10078b;
                        cVar8 = func_0x(0x1e85930);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar44 + -8) = 0x100794;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar44 + -8) = 0x1007ae;
                            cVar8 = func_0x(0x1e85930);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar44 + -8) = 0x1007ca;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(puVar44 + 0x20) = 0;
                              *(undefined8 *)(puVar44 + -8) = 0x1007f0;
                              (*_DAT_)(1,0x17766b8,0x1896388,0x87c);
                            }
                          }
                        }
                        uVar24 = *(undefined8 *)(&stack0x00000040 + lVar16);
                        *(undefined8 *)(puVar44 + -8) = 0x1007fe;
                        func_0x(uVar24,5);
                      }
                    }
LAB_:
                    uVar41 = *(uint *)plVar42;
                    uVar40 = uVar41 + 1;
                    uVar48 = *(uint *)(&stack0x00000048 + lVar16);
                    if (uVar48 < uVar40) {
                      *(undefined8 *)(puVar44 + -8) = 0x100822;
                      func_0x(&stack0x0000003a + lVar16,0,uVar40 - uVar48);
                      if ((1 << (**(byte **)(&stack0x00000040 + lVar16) & 0xe) & 0x1105U) != 0) {
                        *(short *)(*(byte **)(&stack0x00000040 + lVar16) + 2) = (short)uVar40;
                      }
                      *(uint *)(&stack0x00000048 + lVar16) = uVar40;
                      uVar41 = *(uint *)plVar42;
                    }
                    if (pcVar4 != (char *)0x0) {
                      *(char *)((longlong)(int)uVar41 + *(longlong *)(&stack0x00000040 + lVar16)) =
                           *pcVar4;
                    }
                  }
                  else {
                    cVar8 = *pcVar4;
                    uVar48 = uVar40 + 1;
                    uVar41 = *(uint *)(&stack0x00000048 + lVar16);
                    if (uVar41 < uVar48) {
                      *(undefined8 *)(puVar44 + -8) = 0x1002d7;
                      func_0x(&stack0x0000003a + lVar16,0,uVar48 - uVar41);
                      pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                      if ((1 << (*pbVar35 & 0xe) & 0x1105U) != 0) {
                        *(short *)(pbVar35 + 2) = (short)uVar48;
                        pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                      }
                      *(uint *)(&stack0x00000048 + lVar16) = uVar48;
                      bVar28 = *(byte *)((longlong)plVar42 + 6);
                    }
                    else {
                      pbVar35 = *(byte **)(&stack0x00000040 + lVar16);
                    }
                    if (cVar8 == '\0') {
                      pbVar35[(int)uVar40] = pbVar35[(int)uVar40] & ~(byte)(1 << (bVar28 & 7));
                    }
                    else {
                      pbVar35[(int)uVar40] = pbVar35[(int)uVar40] | (byte)(1 << (bVar28 & 7));
                    }
                  }
                }
              }
              else {
                *(undefined8 *)(puVar44 + 0x20) = 0x14f2b98;
                *(undefined8 *)(puVar44 + -8) = 0x10028a;
                (*_DAT_)(1,0x18f79f0,0x1924330);
              }
            }
          }
          plVar42 = plVar42 + 10;
          iVar14 = *(int *)(&stack0x00000080 + lVar16);
          *(uint *)(&stack0x00000080 + lVar16) = iVar14 + 1U;
          plVar19 = *(longlong **)(&stack0x00000088 + lVar16);
        } while (iVar14 + 1U < *(uint *)(&stack0x00000074 + lVar16));
        uVar40 = *(uint *)(&stack0x00000098 + lVar16);
      }
      puVar49 = (ushort *)0x0;
      if (uVar40 != 0) {
        lVar17 = *(longlong *)(&stack0x00000088 + lVar16);
        do {
          uVar45 = (ulonglong)uVar40;
          uVar41 = uVar40 - 1;
          if (*(int *)((ulonglong)uVar41 * 0x20 + 8 + lVar17) != 0) {
            *(ushort *)(&stack0x00000054 + lVar16) = (ushort)uVar40;
            iVar14 = *(int *)(&stack0x0000004c + lVar16) + 2 + uVar40 * 2;
            *(int *)(&stack0x00000050 + lVar16) = iVar14;
            *(int *)(&stack0x0000003c + lVar16) = iVar14;
            **(byte **)(&stack0x00000040 + lVar16) = **(byte **)(&stack0x00000040 + lVar16) | 0x20;
            uVar41 = *(uint *)(&stack0x0000003c + lVar16);
            if (uVar41 < 0x1f7d) {
              puVar49 = (ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000004c + lVar16) +
                        *(longlong *)(&stack0x00000040 + lVar16));
              *puVar49 = (ushort)uVar40;
              uVar41 = *(uint *)(&stack0x0000003c + lVar16);
            }
            if (uVar40 != 0) {
              puVar38 = (uint *)(lVar17 + 0xc);
              do {
                puVar49 = puVar49 + 1;
                uVar36 = (ulonglong)uVar41;
                lVar17 = *(longlong *)(&stack0x00000040 + lVar16);
                uVar40 = puVar38[-1];
                uVar41 = uVar41 + uVar40;
                *(uint *)(&stack0x0000003c + lVar16) = uVar41;
                if (uVar41 < 0x1f7d) {
                  *puVar49 = (ushort)((*puVar38 & 1) << 0xf) | (ushort)uVar41 & 0x7fff;
                  uVar24 = *(undefined8 *)(puVar38 + -3);
                  *(undefined8 *)(puVar44 + -8) = 0x101aa8;
                  func_0x(uVar36 + lVar17,uVar40,uVar24);
                  uVar41 = *(uint *)(&stack0x0000003c + lVar16);
                }
                puVar38 = puVar38 + 8;
                uVar45 = uVar45 - 1;
              } while (uVar45 != 0);
            }
            break;
          }
          uVar40 = uVar41;
        } while (uVar41 != 0);
      }
    }
LAB_:
    lVar17 = *(longlong *)(&stack0x00000090 + lVar16);
    puVar43 = puVar44;
  }
  else {
    uVar24 = 0x1ee0b78;
    if (bVar54) {
      uVar24 = 0x1eee1c0;
    }
    lVar17 = *(longlong *)(&stack0x00000090 + lVar16);
    *(undefined8 *)(lVar17 + 0xa68) = uVar24;
    *(undefined8 *)(lVar17 + 0xa70) = 0;
    *(longlong *)((longlong)alStackX_8 + lVar16) = lVar17 + 0x290;
    *(undefined **)((longlong)alStackX_8 + lVar16 + -8) = &stack0x00000108 + lVar16;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar16) = 0x1f7c;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar16) = 0x1f9e;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar16) = &stack0x000009d8 + lVar16;
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101fc7;
    func_0x(lVar17 + 0xa80,param_2,2);
  }
  puVar47 = (undefined8 *)0x0;
  lVar23 = *(longlong *)(&stack0x00000100 + lVar16);
  *(undefined8 *)(puVar43 + -8) = 0x1008c4;
  iVar14 = func_0x(lVar23);
  if (iVar14 == 0) {
    *(undefined8 *)(puVar43 + -8) = 0x1008d3;
    func_0x(lVar23,1);
  }
  lVar20 = *(longlong *)(lVar17 + 0xae8);
  if (lVar20 == lVar17 + 0xae0) {
LAB_:
    *(undefined4 *)(&stack0x00000074 + lVar16) = 0x75f;
    puVar43[0x20] = 5;
    uVar24 = *(undefined8 *)(lVar17 + 0x1f0);
    *(undefined8 *)(puVar43 + -8) = 0x101ff7;
    lVar20 = (*_DAT_)(0x638,uVar24,0x1780cf8);
    *(longlong *)(&stack0x000000a0 + lVar16) = lVar20;
    puVar21 = puVar47;
    if (lVar20 != 0) {
      *(undefined8 *)(puVar43 + -8) = 0x102008;
      puVar21 = (undefined8 *)func_0x(lVar20);
    }
    *(undefined8 **)(&stack0x000000b8 + lVar16) = puVar21;
    uVar24 = *(undefined8 *)(lVar17 + 0x2d8);
    *(undefined8 *)(puVar43 + -8) = 0x102026;
    func_0x(puVar21,uVar24);
  }
  else {
    puVar21 = puVar47;
    if (lVar20 != 0) {
      puVar21 = (undefined8 *)(lVar20 + -0x10);
    }
    *(undefined8 **)(&stack0x000000b8 + lVar16) = puVar21;
    if (puVar21 == (undefined8 *)0x0) goto LAB_;
    plVar19 = (longlong *)puVar21[3];
    lVar20 = puVar21[2];
    *(longlong **)(lVar20 + 8) = plVar19;
    *plVar19 = lVar20;
    puVar21[3] = 0;
    puVar21[2] = 0;
  }
  plVar19 = puVar21 + 2;
  puVar21[3] = *(undefined8 *)(lVar17 + 0xaf8);
  **(longlong ***)(lVar17 + 0xaf8) = plVar19;
  *(longlong **)(lVar17 + 0xaf8) = plVar19;
  *plVar19 = lVar17 + 0xaf0;
  puVar38 = *(uint **)(lVar17 + 0x108);
  uVar40 = *puVar38;
  puVar31 = *(undefined8 **)(lVar17 + 0x2e0);
  uVar41 = 0;
  if (*(int *)(puVar21 + 0xc6) == 1) {
    puVar21[5] = puVar31;
    puVar21[7] = puVar31;
    puVar21[0x20] = *(longlong *)(puVar21[6] + 0x48) + 0x28;
    *(undefined4 *)(puVar21 + 0x1e) = 2;
    if (*(int *)(*(longlong *)(puVar21[4] + 0x48) + 0x18) != 1) {
      uVar24 = *puVar31;
      *(undefined8 *)(puVar43 + -8) = 0x1020b6;
      func_0x(puVar21 + 0xa7,uVar24,uVar40 >> 0x1b & 1);
      lVar17 = puVar21[4];
      bVar32 = 0;
      bVar28 = bVar32;
      if (*(int *)(lVar17 + 0x40) == 3) {
        bVar28 = 8;
      }
      bVar2 = *(byte *)(puVar21 + 0xa6);
      *(byte *)(puVar21 + 0xa6) = bVar28 | bVar2 & 0xf7;
      if (*(int *)(lVar17 + 0x40) == 4) {
        bVar32 = 0x10;
      }
      bVar32 = bVar32 | bVar28 | bVar2 & 0xe7;
      *(byte *)(puVar21 + 0xa6) = bVar32;
      *(byte *)(puVar21 + 0xa6) =
           ((char)((*(int *)(*(longlong *)(lVar17 + 0x10) + 0x50) << 0x1f) >> 0x1f) << 5 ^ bVar32) &
           0x20 ^ bVar32;
      *(undefined4 *)(puVar21 + 0xa9) = *(undefined4 *)(*(longlong *)(lVar17 + 0x48) + 0x188);
      *(undefined4 *)((longlong)puVar21 + 0x54c) = *(undefined4 *)(puVar31 + 4);
    }
    *(undefined4 *)(puVar21 + 0xc6) = 2;
    puVar38 = *(uint **)(*(longlong *)(&stack0x00000090 + lVar16) + 0x108);
  }
  if (((*(byte *)(*(longlong *)(**(longlong **)(puVar38 + 8) + 8) + 0x107) & 0x40) == 0) ||
     ((*puVar38 & 0x1000000) != 0)) {
    bVar28 = 0;
  }
  else {
    bVar28 = 4;
  }
  plVar19 = *(longlong **)(puVar21[5] + 8);
  *(undefined8 *)(&stack0x00000148 + lVar16) = 0;
  *(undefined4 *)(&stack0x00000074 + lVar16) = 0;
  *(short **)(&stack0x00000140 + lVar16) = psVar1;
  puVar44 = puVar43;
  if (*(int *)(*(longlong *)(lVar23 + 8) + 0x100) == 2) {
    puVar52 = (undefined2 *)(puVar43 + 0x30);
    *puVar52 = 0xffff;
    *(undefined8 *)(puVar43 + 0x38) = 0;
    *(undefined4 *)(puVar43 + 0x34) = 0;
    *(undefined8 *)(puVar43 + 0x4e) = 0;
    *(undefined8 *)(puVar43 + 0x58) = 0;
    *(undefined8 *)(puVar43 + 0x40) = 0;
    *(undefined8 *)(puVar43 + -0x48) = 0x1021c3;
    lVar17 = func_0x();
    lVar17 = -lVar17;
    puVar44 = puVar43 + lVar17 + -0xc0;
    *(undefined (*) [16])(puVar43 + lVar17 + -0x50) = ZEXT816(0);
    *(undefined (*) [16])(puVar43 + lVar17 + -0x40) = ZEXT816(0);
    *(undefined (*) [16])(puVar43 + lVar17 + -0x30) = ZEXT816(0);
    *(undefined (*) [16])(puVar43 + lVar17 + -0x20) = ZEXT816(0);
    *(undefined (*) [16])(puVar43 + lVar17 + -0x10) = ZEXT816(0);
    *(undefined (*) [16])(puVar43 + lVar17) = ZEXT816(0);
    *(undefined (*) [16])(puVar43 + lVar17 + 0x10) = ZEXT816(0);
    *(undefined8 *)(puVar43 + lVar17 + 0x20) = 0;
    *(undefined2 *)(puVar43 + lVar17 + -0x40) = 0xffff;
    *(undefined8 *)(puVar43 + lVar17 + -0x38) = 0;
    *(undefined4 *)(puVar43 + lVar17 + -0x3c) = 0;
    *(undefined8 *)(puVar43 + lVar17 + -0x22) = 0;
    *(undefined8 *)(puVar43 + lVar17 + -0x18) = 0;
    *(undefined8 *)(puVar43 + lVar17 + -0x30) = 0;
    *(undefined8 *)(puVar43 + lVar17 + -8) = 0;
    *(undefined8 *)(puVar43 + lVar17 + 0x10) = 0;
    *(undefined4 *)(puVar43 + lVar17 + 0x18) = 0;
    *(undefined2 *)(puVar43 + lVar17 + 0x22) = 0;
    *(undefined2 **)(&stack0x00000148 + lVar16) = puVar52;
    *(undefined **)(&stack0x00000150 + lVar16) = puVar43 + lVar17 + 0x30;
    *(undefined4 *)(&stack0x00000158 + lVar16) = 0x239e;
    *(undefined (**) [16])(&stack0x00000160 + lVar16) =
         (undefined (*) [16])(puVar43 + lVar17 + -0x50);
  }
  plVar42 = (longlong *)puVar21[5];
  plVar39 = (longlong *)plVar42[3];
  plVar53 = plVar42;
  if (plVar39 == (longlong *)0x0) {
    plVar39 = (longlong *)(plVar42[1] + 0x208);
    plVar42[3] = (longlong)plVar39;
    plVar53 = (longlong *)puVar21[5];
  }
  if ((*plVar39 == (ulonglong)*(uint6 *)(*plVar42 + 0x14) * 0x10000) && (*(int *)(plVar39 + 1) != 0)
     ) {
    *(undefined4 *)(&stack0x00000074 + lVar16) = 1;
    *(undefined4 *)(&stack0x00000078 + lVar16) = 0;
    iVar14 = *(int *)(puVar21 + 0xa9);
    *(int *)(&stack0x00000098 + lVar16) = iVar14;
    if (iVar14 == 0) {
      *(undefined4 *)(&stack0x00000080 + lVar16) = *(undefined4 *)(&stack0x0000009c + lVar16);
      *(undefined4 *)(&stack0x00000098 + lVar16) = *(undefined4 *)(&stack0x0000009c + lVar16);
    }
    else {
      *(undefined4 *)(&stack0x00000078 + lVar16) = 1;
      *(undefined4 *)(&stack0x00000080 + lVar16) = *(undefined4 *)((longlong)puVar21 + 0x54c);
      lVar17 = plVar53[3];
      iVar14 = *(int *)(lVar17 + 8);
      if ((iVar14 == 0) || (*(int *)(lVar17 + 0xc) != 0)) {
        puVar31 = puVar47;
        if (iVar14 != 0) goto LAB_;
      }
      else {
        puVar31 = (undefined8 *)0x2;
LAB_:
        uVar41 = (uint)puVar31;
        if (*(int *)(lVar17 + 0xc) == iVar14 + -1) {
          uVar41 = uVar41 | 1;
        }
      }
      *(uint *)(puVar21 + 0xa9) = uVar41;
      *(undefined4 *)((longlong)puVar21 + 0x54c) = *(undefined4 *)(plVar53 + 4);
    }
  }
  else {
    *(undefined4 *)(&stack0x00000080 + lVar16) = *(undefined4 *)(&stack0x0000009c + lVar16);
    *(undefined4 *)(&stack0x00000078 + lVar16) = *(undefined4 *)(&stack0x00000108 + lVar16);
    *(undefined4 *)(&stack0x00000098 + lVar16) = *(undefined4 *)(&stack0x0000009c + lVar16);
  }
  *(uint *)((longlong)puVar21 + 0x634) = *(uint *)((longlong)puVar21 + 0x634) & 0xfffffffe;
  puVar31 = puVar21 + 0xa6;
  *(byte *)puVar31 = (*(byte *)puVar31 & 0xfa | bVar28) & 0x7f;
  *(undefined4 *)((longlong)puVar21 + 0x54c) = *(undefined4 *)(plVar53 + 4);
  if (*(int *)(puVar21[4] + 0x40) != 1) {
    pcVar3 = *(code **)(*plVar19 + 0x270);
    *(undefined8 *)(puVar44 + -8) = 0x10234b;
    (*pcVar3)(plVar19);
  }
  *(byte *)((longlong)puVar21 + 0x531) = *(byte *)((longlong)puVar21 + 0x531) & 0xfb;
  lVar17 = 2;
  puVar22 = puVar31;
  puVar18 = (undefined4 *)(&stack0x000002e8 + lVar16);
  do {
    uVar15 = *(undefined4 *)((longlong)puVar22 + 4);
    uVar6 = *(undefined4 *)(puVar22 + 1);
    uVar7 = *(undefined4 *)((longlong)puVar22 + 0xc);
    *puVar18 = *(undefined4 *)puVar22;
    puVar18[1] = uVar15;
    puVar18[2] = uVar6;
    puVar18[3] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar22 + 0x14);
    uVar6 = *(undefined4 *)(puVar22 + 3);
    uVar7 = *(undefined4 *)((longlong)puVar22 + 0x1c);
    puVar18[4] = *(undefined4 *)(puVar22 + 2);
    puVar18[5] = uVar15;
    puVar18[6] = uVar6;
    puVar18[7] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar22 + 0x24);
    uVar6 = *(undefined4 *)(puVar22 + 5);
    uVar7 = *(undefined4 *)((longlong)puVar22 + 0x2c);
    puVar18[8] = *(undefined4 *)(puVar22 + 4);
    puVar18[9] = uVar15;
    puVar18[10] = uVar6;
    puVar18[0xb] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar22 + 0x34);
    uVar6 = *(undefined4 *)(puVar22 + 7);
    uVar7 = *(undefined4 *)((longlong)puVar22 + 0x3c);
    puVar18[0xc] = *(undefined4 *)(puVar22 + 6);
    puVar18[0xd] = uVar15;
    puVar18[0xe] = uVar6;
    puVar18[0xf] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar22 + 0x44);
    uVar6 = *(undefined4 *)(puVar22 + 9);
    uVar7 = *(undefined4 *)((longlong)puVar22 + 0x4c);
    puVar18[0x10] = *(undefined4 *)(puVar22 + 8);
    puVar18[0x11] = uVar15;
    puVar18[0x12] = uVar6;
    puVar18[0x13] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar22 + 0x54);
    uVar6 = *(undefined4 *)(puVar22 + 0xb);
    uVar7 = *(undefined4 *)((longlong)puVar22 + 0x5c);
    puVar18[0x14] = *(undefined4 *)(puVar22 + 10);
    puVar18[0x15] = uVar15;
    puVar18[0x16] = uVar6;
    puVar18[0x17] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar22 + 100);
    uVar6 = *(undefined4 *)(puVar22 + 0xd);
    uVar7 = *(undefined4 *)((longlong)puVar22 + 0x6c);
    puVar18[0x18] = *(undefined4 *)(puVar22 + 0xc);
    puVar18[0x19] = uVar15;
    puVar18[0x1a] = uVar6;
    puVar18[0x1b] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar22 + 0x74);
    uVar6 = *(undefined4 *)(puVar22 + 0xf);
    uVar7 = *(undefined4 *)((longlong)puVar22 + 0x7c);
    puVar18[0x1c] = *(undefined4 *)(puVar22 + 0xe);
    puVar18[0x1d] = uVar15;
    puVar18[0x1e] = uVar6;
    puVar18[0x1f] = uVar7;
    puVar22 = puVar22 + 0x10;
    lVar17 = lVar17 + -1;
    puVar18 = puVar18 + 0x20;
  } while (lVar17 != 0);
  pcVar3 = *(code **)(*plVar19 + 0x28);
  *(undefined8 *)(puVar44 + -8) = 0x1023bb;
  cVar8 = (*pcVar3)(plVar19);
  puVar22 = (undefined8 *)(*(longlong *)(&stack0x00000090 + lVar16) + 0xa40);
  if (cVar8 != '\0') {
    puVar22 = puVar47;
  }
  *(undefined8 **)(&stack0x00000088 + lVar16) = puVar22;
  plVar19 = puVar21 + 6;
  bVar28 = (&stack0x000002e9)[lVar16];
  if ((puVar22 != (undefined8 *)0x0) &&
     (((*(int *)(puVar22 + 1) != 0 || (*(short *)((longlong)puVar22 + 0xc) != 0)) &&
      ((bVar28 & 4) == 0)))) {
    puVar47 = (undefined8 *)*plVar19;
    *(undefined **)(puVar44 + 0x20) = &stack0x00000210 + lVar16;
    uVar24 = *puVar47;
    *(undefined8 *)(puVar44 + -8) = 0x102422;
    iVar14 = func_0x(uVar24,puVar22,3,2);
    if (iVar14 != 0) {
      puVar18 = (undefined4 *)(&stack0x000002e8 + lVar16);
      lVar17 = 2;
      puVar27 = (undefined4 *)(&stack0x000003e8 + lVar16);
      do {
        uVar15 = puVar18[1];
        uVar6 = puVar18[2];
        uVar7 = puVar18[3];
        *puVar27 = *puVar18;
        puVar27[1] = uVar15;
        puVar27[2] = uVar6;
        puVar27[3] = uVar7;
        uVar15 = puVar18[5];
        uVar6 = puVar18[6];
        uVar7 = puVar18[7];
        puVar27[4] = puVar18[4];
        puVar27[5] = uVar15;
        puVar27[6] = uVar6;
        puVar27[7] = uVar7;
        uVar15 = puVar18[9];
        uVar6 = puVar18[10];
        uVar7 = puVar18[0xb];
        puVar27[8] = puVar18[8];
        puVar27[9] = uVar15;
        puVar27[10] = uVar6;
        puVar27[0xb] = uVar7;
        uVar15 = puVar18[0xd];
        uVar6 = puVar18[0xe];
        uVar7 = puVar18[0xf];
        puVar27[0xc] = puVar18[0xc];
        puVar27[0xd] = uVar15;
        puVar27[0xe] = uVar6;
        puVar27[0xf] = uVar7;
        uVar15 = puVar18[0x11];
        uVar6 = puVar18[0x12];
        uVar7 = puVar18[0x13];
        puVar27[0x10] = puVar18[0x10];
        puVar27[0x11] = uVar15;
        puVar27[0x12] = uVar6;
        puVar27[0x13] = uVar7;
        uVar15 = puVar18[0x15];
        uVar6 = puVar18[0x16];
        uVar7 = puVar18[0x17];
        puVar27[0x14] = puVar18[0x14];
        puVar27[0x15] = uVar15;
        puVar27[0x16] = uVar6;
        puVar27[0x17] = uVar7;
        uVar15 = puVar18[0x19];
        uVar6 = puVar18[0x1a];
        uVar7 = puVar18[0x1b];
        puVar27[0x18] = puVar18[0x18];
        puVar27[0x19] = uVar15;
        puVar27[0x1a] = uVar6;
        puVar27[0x1b] = uVar7;
        uVar15 = puVar18[0x1d];
        uVar6 = puVar18[0x1e];
        uVar7 = puVar18[0x1f];
        puVar27[0x1c] = puVar18[0x1c];
        puVar27[0x1d] = uVar15;
        puVar27[0x1e] = uVar6;
        puVar27[0x1f] = uVar7;
        puVar18 = puVar18 + 0x20;
        lVar17 = lVar17 + -1;
        puVar27 = puVar27 + 0x20;
      } while (lVar17 != 0);
      *(undefined4 *)(puVar44 + 0x30) = 0;
      *(undefined **)(puVar44 + 0x28) = &stack0x000003e8 + lVar16;
      *(undefined8 *)(puVar44 + 0x20) = 0;
      *(undefined8 *)(puVar44 + -8) = 0x1024c1;
      func_0x(plVar19,&stack0x00000210 + lVar16,&stack0x00000140 + lVar16,0);
    }
  }
  puVar47 = puVar21;
  if (*(int *)(puVar21 + 0x1e) != 4) {
    if ((bVar28 & 4) == 0) {
      *(undefined4 *)(&stack0x00000250 + lVar16) = 0;
      (&stack0x00000260)[lVar16] = 0;
      *(undefined8 *)(puVar44 + -8) = 0x1024f3;
      func_0x(&stack0x000007f8 + lVar16);
      *(undefined8 *)(&stack0x000002ac + lVar16) = 0;
      *(undefined4 *)(&stack0x000002bc + lVar16) = 0;
      plVar42 = (longlong *)puVar21[7];
      lVar17 = *plVar42;
      *(longlong *)(&stack0x000000b0 + lVar16) = lVar17;
      *(longlong *)(&stack0x00000120 + lVar16) = *(longlong *)(lVar17 + 8) + 0x3c0;
      plVar42 = (longlong *)plVar42[1];
      pcVar3 = *(code **)(*plVar42 + 0x58);
      *(undefined8 *)(puVar44 + -8) = 0x102530;
      (*pcVar3)(plVar42);
      (&stack0x000007f6)[lVar16] = 1;
      (&stack0x00000128)[lVar16] = (&stack0x00000128)[lVar16] & 0xfc;
      *(undefined8 *)(puVar44 + -8) = 0x10254a;
      func_0x(&stack0x00000130 + lVar16);
      *(undefined4 *)(&stack0x00000130 + lVar16) = *(undefined4 *)(&stack0x000002f0 + lVar16);
      *(undefined4 *)(&stack0x00000134 + lVar16) = *(undefined4 *)(&stack0x000002f4 + lVar16);
      *(undefined4 *)(&stack0x00000138 + lVar16) = *(undefined4 *)(&stack0x000002f8 + lVar16);
      *(undefined4 *)(&stack0x0000013c + lVar16) = *(undefined4 *)(&stack0x000002fc + lVar16);
      (&stack0x00000128)[lVar16] =
           (byte)(&stack0x000002e8)[lVar16] >> 6 & 2 | (&stack0x000002e8)[lVar16] & 1 |
           (&stack0x00000128)[lVar16] & 0xfc;
      *(undefined4 *)(&stack0x000000d8 + lVar16) = *(undefined4 *)(&stack0x00000128 + lVar16);
      *(undefined4 *)(&stack0x000000dc + lVar16) = *(undefined4 *)(&stack0x0000012c + lVar16);
      *(undefined4 *)(&stack0x000000e0 + lVar16) = *(undefined4 *)(&stack0x00000130 + lVar16);
      *(undefined4 *)(&stack0x000000e4 + lVar16) = *(undefined4 *)(&stack0x00000134 + lVar16);
      *(undefined4 *)(&stack0x000000f0 + lVar16) = *(undefined4 *)(&stack0x000002f8 + lVar16);
      *(undefined4 *)(&stack0x000000f4 + lVar16) = *(undefined4 *)(&stack0x000002fc + lVar16);
      psVar5 = *(short **)(&stack0x00000140 + lVar16);
      *(short **)(&stack0x000000a0 + lVar16) = psVar5;
      puVar49 = (ushort *)(psVar5 + 1);
      if (*psVar5 == 0) {
        if (*(int *)(psVar5 + 2) == 0) {
          *puVar49 = 0;
          uVar40 = *(uint *)(psVar5 + 8);
          uVar45 = (ulonglong)uVar40;
          *(uint *)(psVar5 + 10) = uVar40;
          pbVar35 = *(byte **)(psVar5 + 4);
          bVar28 = *pbVar35;
          if ((bVar28 & 0x10) != 0) {
            uVar40 = uVar40 + 2 + (*(ushort *)(pbVar35 + uVar45) + 7 >> 3);
            uVar45 = (ulonglong)uVar40;
            *(uint *)(psVar5 + 10) = uVar40;
            bVar28 = *pbVar35;
          }
          if ((bVar28 & 0x20) == 0) {
            *(int *)(psVar5 + 2) = (int)uVar45;
            psVar5[0xe] = 0;
            *(undefined4 *)(psVar5 + 0xc) = *(undefined4 *)(psVar5 + 10);
          }
          else {
            puVar46 = (ushort *)(pbVar35 + uVar45);
            uVar12 = *puVar46;
            psVar5[0xe] = uVar12;
            if (uVar12 == 0) {
              *(undefined8 *)(puVar44 + -8) = 0x102610;
              cVar8 = func_0x(0x1e85930);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar44 + -8) = 0x102619;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar44 + -8) = 0x102633;
                  cVar8 = func_0x(0x1e85930);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar44 + -8) = 0x10264f;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar44 + 0x20) = 0;
                    *(undefined8 *)(puVar44 + -8) = 0x102675;
                    (*_DAT_)(1,0x17766b8,0x1896388,0x80f);
                  }
                }
              }
              uVar24 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar44 + -8) = 0x102683;
              func_0x(uVar24,3);
              uVar12 = psVar5[0xe];
            }
            uVar40 = *(int *)(psVar5 + 10) + 2 + (uint)uVar12 * 2;
            *(uint *)(psVar5 + 0xc) = uVar40;
            if (0x1f9e < uVar40) {
              *(undefined8 *)(puVar44 + -8) = 0x1026aa;
              cVar8 = func_0x(0x1e85930);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar44 + -8) = 0x1026b3;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar44 + -8) = 0x1026cd;
                  cVar8 = func_0x(0x1e85930);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar44 + -8) = 0x1026e9;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar44 + 0x20) = 0;
                    *(undefined8 *)(puVar44 + -8) = 0x10270f;
                    (*_DAT_)(1,0x17766b8,0x1896388,0x816);
                  }
                }
              }
              uVar24 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar44 + -8) = 0x10271d;
              func_0x(uVar24,4);
            }
            uVar12 = puVar46[(ushort)psVar5[0xe]];
            *(uint *)(psVar5 + 2) = uVar12 & 0x7fff;
            if ((uVar12 & 0x7fff) < *(uint *)(psVar5 + 0xc)) {
              *(undefined8 *)(puVar44 + -8) = 0x102746;
              cVar8 = func_0x(0x1e85930);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar44 + -8) = 0x10274f;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar44 + -8) = 0x102769;
                  cVar8 = func_0x(0x1e85930);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar44 + -8) = 0x102785;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar44 + 0x20) = 0;
                    *(undefined8 *)(puVar44 + -8) = 0x1027ab;
                    (*_DAT_)(1,0x17766b8,0x1896388,0x81d);
                  }
                }
              }
              uVar24 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar44 + -8) = 0x1027b9;
              func_0x(uVar24,4);
            }
            uVar12 = psVar5[0xe];
            do {
              uVar45 = (ulonglong)uVar12;
              if (-1 < (short)puVar46[(ulonglong)(uVar12 - 1) + 1]) break;
              lVar17 = *(longlong *)(psVar5 + 4);
              lVar23 = (ulonglong)*(uint *)(psVar5 + 10) + lVar17;
              if (uVar12 == 1) {
                uVar40 = *(uint *)(psVar5 + 0xc);
                uVar12 = *(ushort *)(lVar23 + uVar45 * 2);
                uVar41 = uVar40;
LAB_:
                if ((uVar12 & 0x7fff) < uVar40) goto LAB_;
              }
              else {
                uVar40 = *(ushort *)(lVar23 + -2 + uVar45 * 2) & 0x7fff;
                uVar41 = *(uint *)(psVar5 + 0xc);
                uVar12 = *(ushort *)(lVar23 + uVar45 * 2);
                if (uVar41 <= uVar40) goto LAB_;
LAB_:
                *(undefined8 *)(puVar44 + -8) = 0x102819;
                func_0x(lVar17,7);
                uVar41 = *(uint *)(psVar5 + 0xc);
                lVar17 = *(longlong *)(psVar5 + 4);
              }
              if ((uVar40 < uVar41) || (*(uint *)(psVar5 + 2) < uVar40)) goto LAB_;
              if (*(ushort *)(lVar17 + (ulonglong)uVar40) == 5) {
                *puVar49 = *puVar49 | 2;
                psVar5[0xe] = psVar5[0xe] + -1;
                psVar5[0x15] = (short)uVar40;
                lVar17 = (ulonglong)(uVar40 & 0xffff) + *(longlong *)(psVar5 + 4);
                uVar12 = psVar5[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar17 + 2) >> 0xe & 1) != 0) {
                  uVar12 = *(ushort *)(lVar17 + 2) & 0x3800 | psVar5[0x16] & 0xc7ffU;
                }
                psVar5[0x16] = uVar12;
                psVar5[0x16] = (uVar12 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar12;
                break;
              }
              if (*(ushort *)(lVar17 + (ulonglong)uVar40) < 0x400) break;
              *puVar49 = *puVar49 | 1;
              uVar12 = psVar5[0xe] - 1;
              psVar5[0xe] = uVar12;
            } while (uVar12 != 0);
          }
          if ((**(byte **)(psVar5 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar5 + 0x13) = 0;
          }
          else {
            *(undefined4 *)(psVar5 + 0x13) = *(undefined4 *)(psVar5 + 2);
            *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + 0xe;
            *(undefined8 *)(puVar44 + -8) = 0x1028f2;
            uVar24 = func_0x(puVar49);
            *(undefined8 *)(puVar44 + -8) = 0x102901;
            func_0x(uVar24,&stack0x00000188 + lVar16);
            *(undefined8 *)(puVar44 + -8) = 0x10290d;
            iVar14 = func_0x(&stack0x00000188 + lVar16);
            *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + iVar14;
          }
          uVar40 = *(uint *)(psVar5 + 2);
          if ((*(ulonglong *)(psVar5 + 0xf) != 0) &&
             (*(ulonglong *)(psVar5 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar5 + 4))) {
            *(undefined8 *)(puVar44 + -8) = 0x102941;
            cVar8 = func_0x(0x1e85930);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar44 + -8) = 0x10294a;
              lVar17 = func_0x();
              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                *(undefined8 *)(puVar44 + -8) = 0x102964;
                cVar8 = func_0x(0x1e85930);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar44 + -8) = 0x102980;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar44 + 0x20) = 0;
                  *(undefined8 *)(puVar44 + -8) = 0x1029a6;
                  (*_DAT_)(1,0x17766b8,0x1896388,0x877);
                }
              }
            }
            uVar24 = *(undefined8 *)(psVar5 + 4);
            *(undefined8 *)(puVar44 + -8) = 0x1029b4;
            func_0x(uVar24,0x12);
            uVar40 = *(uint *)(psVar5 + 2);
          }
          if (0x3f3b < uVar40 - 1) {
            *(undefined8 *)(puVar44 + -8) = 0x1029cd;
            cVar8 = func_0x(0x1e85930);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar44 + -8) = 0x1029d6;
              lVar17 = func_0x();
              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                *(undefined8 *)(puVar44 + -8) = 0x1029f0;
                cVar8 = func_0x(0x1e85930);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar44 + -8) = 0x102a0c;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar44 + 0x20) = 0;
                  *(undefined8 *)(puVar44 + -8) = 0x102a32;
                  (*_DAT_)(1,0x17766b8,0x1896388,0x87c);
                }
              }
            }
            uVar24 = *(undefined8 *)(psVar5 + 4);
            *(undefined8 *)(puVar44 + -8) = 0x102a40;
            func_0x(uVar24,5);
          }
        }
LAB_:
        uVar40 = *(uint *)(psVar5 + 2);
        if (uVar40 < 9) {
          bVar28 = **(byte **)(psVar5 + 4);
          if (((bVar28 & 0xe) != 0) && ((bVar28 & 0xe) != 0xc)) goto LAB_;
          uVar40 = 9;
        }
        else {
LAB_:
          bVar28 = **(byte **)(psVar5 + 4);
        }
        if ((bVar28 & 0x40) != 0) {
          uVar40 = *(uint *)(psVar5 + 0x13);
        }
        psVar50 = *(short **)(&stack0x000000a0 + lVar16);
      }
      else {
        if (*(int *)(psVar5 + 2) == 0) {
          *(undefined8 *)(puVar44 + -8) = 0x102a88;
          func_0x(puVar49);
        }
        *(undefined8 *)(puVar44 + -8) = 0x102a90;
        uVar40 = func_0x(puVar49);
        psVar50 = psVar5;
        if ((**(byte **)(psVar5 + 4) & 2) != 0) {
          uVar40 = *(uint *)(psVar5 + 0x18);
        }
      }
      pcVar3 = *(code **)*plVar42;
      *(undefined8 *)(puVar44 + -8) = 0x102aa8;
      cVar8 = (*pcVar3)(plVar42);
      if (cVar8 == '\0') {
        if (((&stack0x000000d8)[lVar16] & 1) == 0) {
LAB_:
          lVar17 = plVar42[0x1a];
          if (((&stack0x000000e0)[lVar16] & 1) != 0) goto LAB_;
          pcVar3 = *(code **)*plVar42;
          *(undefined8 *)(puVar44 + -8) = 0x102f8a;
          cVar8 = (*pcVar3)(plVar42);
          if (cVar8 != '\0') goto LAB_;
          pcVar3 = *(code **)(*plVar42 + 0x88);
          *(undefined8 *)(puVar44 + -8) = 0x102f9e;
          cVar8 = (*pcVar3)(plVar42);
          if (cVar8 != '\0') {
            if ((&stack0x000000e1)[lVar16] != '\0') goto LAB_;
            if (lVar17 == 0) {
              pcVar3 = *(code **)(*plVar42 + 0x18);
              *(undefined8 *)(puVar44 + -8) = 0x102fc1;
              cVar8 = (*pcVar3)(plVar42);
              if (cVar8 == '\0') goto LAB_;
            }
            if ((*(byte *)(plVar42 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar42 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar42 + 0x43) & 1) != 0) {
                  if (plVar42[0x1a] == 0) {
                    pcVar3 = *(code **)(*plVar42 + 0x88);
                    *(undefined8 *)(puVar44 + -8) = 0x103005;
                    cVar8 = (*pcVar3)(plVar42);
                    if (cVar8 != '\0') {
                      pcVar3 = *(code **)(*plVar42 + 0x18);
                      *(undefined8 *)(puVar44 + -8) = 0x103012;
                      cVar8 = (*pcVar3)(plVar42);
                      if (cVar8 == '\0') {
                        *(byte *)(plVar42 + 0x4a) = *(byte *)(plVar42 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)(puVar44 + -8) = 0x10302b;
                  iVar14 = func_0x(plVar42);
                  if (iVar14 == 0) {
                    pcVar3 = *(code **)(*plVar42 + 0x270);
                    *(undefined8 *)(puVar44 + -8) = 0x10303b;
                    (*pcVar3)(plVar42);
                  }
                  if ((*(byte *)(plVar42 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar42 + 0x4a) & 0x52) == 2) {
                      lVar23 = plVar42[0x1a];
                      *(undefined8 *)(puVar44 + -8) = 0x103075;
                      cVar8 = func_0x(lVar23);
                      if (((cVar8 != '\0') && (*(char *)(plVar42[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar42[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(puVar44 + 0x20) = 0;
                        *(undefined8 *)(puVar44 + -8) = 0x1030be;
                        func_0x(0x1e8a0f0,0x1c,0x10,1);
                      }
                    }
                    uVar41 = (uint)((*(byte *)(plVar42 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar3 = *(code **)(*plVar42 + 0x1e8);
                    *(undefined8 *)(puVar44 + -8) = 0x103051;
                    uVar24 = (*pcVar3)(plVar42);
                    *(undefined8 *)(puVar44 + -8) = 0x103059;
                    uVar41 = func_0x(uVar24);
                  }
                  if (uVar41 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if (((*(byte *)(plVar42 + 0x4a) & 0x40) != 0) &&
                   ((&stack0x000000e2)[lVar16] != '\0')) goto LAB_;
              }
            }
          }
LAB_:
          if (((&stack0x000000e0)[lVar16] & 0x1c) == 0) {
            lVar23 = *(longlong *)(&stack0x000000e8 + lVar16);
            if (lVar23 != 0) {
              iVar14 = *(int *)(*(longlong *)(lVar23 + 8) + 0x68);
              bVar54 = iVar14 < 0;
              if (bVar54) {
                *(undefined8 *)(puVar44 + 0x20) = 0;
                *(undefined8 *)(puVar44 + -8) = 0x103138;
                (*_DAT_)(1,0x1925038,0x1923708,0xc9d);
                iVar14 = *(int *)(*(longlong *)(lVar23 + 8) + 0x68);
                bVar54 = iVar14 < 0;
              }
              if (((iVar14 != 0 && !bVar54) &&
                  (iVar14 = *(int *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar16) + 8) +
                                    0x100), iVar14 != 0)) && (1 < iVar14 - 3U)) {
                *(undefined8 *)(puVar44 + 0x20) = 0;
                *(undefined8 *)(puVar44 + -8) = 0x103187;
                (*_DAT_)(1,0x1925060,0x19250b0,0x116);
              }
              uVar24 = *(undefined8 *)(&stack0x000000e8 + lVar16);
              *(undefined8 *)(puVar44 + -8) = 0x103193;
              iVar14 = func_0x(uVar24);
              if ((((iVar14 != 0) &&
                   ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar16) + 8) + 0x109)
                    & 1) == 0)) &&
                  (iVar14 = *(int *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar16) + 8) +
                                    0x100), iVar14 != 0)) && (1 < iVar14 - 3U)) {
                *(undefined8 *)(puVar44 + 0x20) = 0;
                *(undefined8 *)(puVar44 + -8) = 0x1031e5;
                (*_DAT_)(1,0x19250e0,0x19250b0,0x119);
              }
            }
            if ((lVar17 != 0) && ((0 < *(int *)(lVar17 + 0x78) || (0 < *(int *)(lVar17 + 0x74)))))
            goto LAB_;
            if ((*(byte *)(plVar42 + 0x4a) & 4) != 0) goto LAB_;
            if ((*(byte *)(plVar42 + 0x4a) & 0x5a) != 0) goto LAB_;
            if ((*(byte *)(plVar42 + 0x43) & 1) == 0) goto LAB_;
            if (plVar42[0x1a] != 0) {
LAB_:
              *(undefined8 *)(puVar44 + -8) = 0x103257;
              iVar14 = func_0x(plVar42);
              if (iVar14 == 0) {
                pcVar3 = *(code **)(*plVar42 + 0x270);
                *(undefined8 *)(puVar44 + -8) = 0x103267;
                (*pcVar3)(plVar42);
              }
              if ((*(byte *)(plVar42 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar42 + 0x4a) & 0x52) == 2) {
                  lVar23 = plVar42[0x1a];
                  *(undefined8 *)(puVar44 + -8) = 0x1032a1;
                  cVar8 = func_0x(lVar23);
                  if (((cVar8 != '\0') && (*(char *)(plVar42[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(plVar42[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                    *(undefined8 *)(puVar44 + 0x20) = 0;
                    *(undefined8 *)(puVar44 + -8) = 0x1032ea;
                    func_0x(0x1e8a0f0,0x1c,0x10,1);
                  }
                }
                uVar41 = (uint)((*(byte *)(plVar42 + 0x4a) & 0x5a) != 0);
              }
              else {
                pcVar3 = *(code **)(*plVar42 + 0x1e8);
                *(undefined8 *)(puVar44 + -8) = 0x10327d;
                uVar24 = (*pcVar3)(plVar42);
                *(undefined8 *)(puVar44 + -8) = 0x103285;
                uVar41 = func_0x(uVar24);
              }
              if (uVar41 == 0) goto LAB_;
              goto LAB_;
            }
            pcVar3 = *(code **)(*plVar42 + 0x88);
            *(undefined8 *)(puVar44 + -8) = 0x10323a;
            cVar8 = (*pcVar3)(plVar42);
            if (cVar8 == '\0') goto LAB_;
            pcVar3 = *(code **)(*plVar42 + 0x18);
            *(undefined8 *)(puVar44 + -8) = 0x103247;
            cVar8 = (*pcVar3)(plVar42);
            if (cVar8 != '\0') goto LAB_;
LAB_:
            *(byte *)(plVar42 + 0x4a) = *(byte *)(plVar42 + 0x4a) | 4;
            goto LAB_;
          }
LAB_:
          if (lVar17 != 0) {
LAB_:
            if (((&stack0x000000e0)[lVar16] & 0x1c) == 0) {
              lVar23 = *(longlong *)(&stack0x000000e8 + lVar16);
              if (lVar23 != 0) {
                iVar14 = *(int *)(*(longlong *)(lVar23 + 8) + 0x68);
                bVar54 = iVar14 < 0;
                if (bVar54) {
                  *(undefined8 *)(puVar44 + 0x20) = 0;
                  *(undefined8 *)(puVar44 + -8) = 0x10335a;
                  (*_DAT_)(1,0x1925038,0x1923708,0xc9d);
                  iVar14 = *(int *)(*(longlong *)(lVar23 + 8) + 0x68);
                  bVar54 = iVar14 < 0;
                }
                if (((iVar14 != 0 && !bVar54) &&
                    (iVar14 = *(int *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar16) + 8) +
                                      0x100), iVar14 != 0)) && (1 < iVar14 - 3U)) {
                  *(undefined8 *)(puVar44 + 0x20) = 0;
                  *(undefined8 *)(puVar44 + -8) = 0x1033a9;
                  (*_DAT_)(1,0x1925060,0x19250b0,0x116);
                }
                uVar24 = *(undefined8 *)(&stack0x000000e8 + lVar16);
                *(undefined8 *)(puVar44 + -8) = 0x1033b5;
                iVar14 = func_0x(uVar24);
                if (((iVar14 != 0) &&
                    ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar16) + 8) + 0x109)
                     & 1) == 0)) &&
                   ((iVar14 = *(int *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar16) + 8) +
                                      0x100), iVar14 != 0 && (1 < iVar14 - 3U)))) {
                  *(undefined8 *)(puVar44 + 0x20) = 0;
                  *(undefined8 *)(puVar44 + -8) = 0x103407;
                  (*_DAT_)(1,0x19250e0,0x19250b0,0x119);
                }
              }
              if ((*(int *)(lVar17 + 0x78) < 1) && (*(int *)(lVar17 + 0x74) < 1)) {
                if ((*(byte *)(plVar42 + 0x4a) & 4) == 0) {
                  if ((*(byte *)(plVar42 + 0x4a) & 0x5a) == 0) {
                    if ((*(byte *)(plVar42 + 0x43) & 1) != 0) {
                      if (plVar42[0x1a] == 0) {
                        pcVar3 = *(code **)(*plVar42 + 0x88);
                        *(undefined8 *)(puVar44 + -8) = 0x103457;
                        cVar8 = (*pcVar3)(plVar42);
                        if (cVar8 != '\0') {
                          pcVar3 = *(code **)(*plVar42 + 0x18);
                          *(undefined8 *)(puVar44 + -8) = 0x103464;
                          cVar8 = (*pcVar3)(plVar42);
                          if (cVar8 == '\0') {
                            *(byte *)(plVar42 + 0x4a) = *(byte *)(plVar42 + 0x4a) | 4;
                            goto LAB_;
                          }
                        }
                      }
                      *(undefined8 *)(puVar44 + -8) = 0x10347d;
                      iVar14 = func_0x(plVar42);
                      if (iVar14 == 0) {
                        pcVar3 = *(code **)(*plVar42 + 0x270);
                        *(undefined8 *)(puVar44 + -8) = 0x10348d;
                        (*pcVar3)(plVar42);
                      }
                      if ((*(byte *)(plVar42 + 0x43) & 4) == 0) {
                        if ((*(byte *)(plVar42 + 0x4a) & 0x52) == 2) {
                          lVar23 = plVar42[0x1a];
                          *(undefined8 *)(puVar44 + -8) = 0x1034c7;
                          cVar8 = func_0x(lVar23);
                          if (((cVar8 != '\0') && (*(char *)(plVar42[0x1a] + 0x130) == '\0')) &&
                             (*(undefined *)(plVar42[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                            *(undefined8 *)(puVar44 + 0x20) = 0;
                            *(undefined8 *)(puVar44 + -8) = 0x103510;
                            func_0x(0x1e8a0f0,0x1c,0x10,1);
                          }
                        }
                        uVar41 = (uint)((*(byte *)(plVar42 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        pcVar3 = *(code **)(*plVar42 + 0x1e8);
                        *(undefined8 *)(puVar44 + -8) = 0x1034a3;
                        uVar24 = (*pcVar3)(plVar42);
                        *(undefined8 *)(puVar44 + -8) = 0x1034ab;
                        uVar41 = func_0x(uVar24);
                      }
                      if (uVar41 != 0) goto LAB_;
                    }
                  }
                  else {
LAB_:
                    if ((*(byte *)(plVar42 + 0x4a) & 0x10) != 0) goto LAB_;
                  }
                }
LAB_:
                if ((*(byte *)(plVar42 + 0x4a) & 4) == 0) {
                  if ((*(byte *)(plVar42 + 0x4a) & 0x5a) == 0) {
                    if ((*(byte *)(plVar42 + 0x43) & 1) != 0) {
                      if (plVar42[0x1a] == 0) {
                        pcVar3 = *(code **)(*plVar42 + 0x88);
                        *(undefined8 *)(puVar44 + -8) = 0x10356e;
                        cVar8 = (*pcVar3)(plVar42);
                        if (cVar8 != '\0') {
                          pcVar3 = *(code **)(*plVar42 + 0x18);
                          *(undefined8 *)(puVar44 + -8) = 0x10357b;
                          cVar8 = (*pcVar3)(plVar42);
                          if (cVar8 == '\0') {
                            *(byte *)(plVar42 + 0x4a) = *(byte *)(plVar42 + 0x4a) | 4;
                            goto LAB_;
                          }
                        }
                      }
                      *(undefined8 *)(puVar44 + -8) = 0x103594;
                      iVar14 = func_0x(plVar42);
                      if (iVar14 == 0) {
                        pcVar3 = *(code **)(*plVar42 + 0x270);
                        *(undefined8 *)(puVar44 + -8) = 0x1035a4;
                        (*pcVar3)(plVar42);
                      }
                      if ((*(byte *)(plVar42 + 0x43) & 4) == 0) {
                        if ((*(byte *)(plVar42 + 0x4a) & 0x52) == 2) {
                          lVar23 = plVar42[0x1a];
                          *(undefined8 *)(puVar44 + -8) = 0x1035de;
                          cVar8 = func_0x(lVar23);
                          if (((cVar8 != '\0') && (*(char *)(plVar42[0x1a] + 0x130) == '\0')) &&
                             (*(undefined *)(plVar42[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                            *(undefined8 *)(puVar44 + 0x20) = 0;
                            *(undefined8 *)(puVar44 + -8) = 0x103627;
                            func_0x(0x1e8a0f0,0x1c,0x10,1);
                          }
                        }
                        uVar41 = (uint)((*(byte *)(plVar42 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        pcVar3 = *(code **)(*plVar42 + 0x1e8);
                        *(undefined8 *)(puVar44 + -8) = 0x1035ba;
                        uVar24 = (*pcVar3)(plVar42);
                        *(undefined8 *)(puVar44 + -8) = 0x1035c2;
                        uVar41 = func_0x(uVar24);
                      }
                      if (uVar41 != 0) goto LAB_;
                    }
                  }
                  else {
LAB_:
                    if ((*(byte *)(plVar42 + 0x4a) & 0x40) != 0) goto LAB_;
                  }
                }
              }
            }
LAB_:
            *(undefined8 *)(puVar44 + -8) = 0x10364f;
            func_0x(lVar17,0);
          }
LAB_:
          *(undefined8 *)(puVar44 + -8) = 0x103657;
          iVar14 = func_0x(plVar42);
          if (iVar14 == 0) {
            pcVar3 = *(code **)(*plVar42 + 0x270);
            *(undefined8 *)(puVar44 + -8) = 0x103667;
            (*pcVar3)(plVar42);
          }
          lVar17 = plVar42[0x1a];
          if (((&stack0x000000e0)[lVar16] & 0x24) == 0) {
            if ((*(byte *)(plVar42 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar42 + 0x4a) & 0x5a) != 0) goto LAB_;
              if ((*(byte *)(plVar42 + 0x43) & 1) != 0) {
                if (lVar17 == 0) {
                  pcVar3 = *(code **)(*plVar42 + 0x88);
                  *(undefined8 *)(puVar44 + -8) = 0x1036b2;
                  cVar8 = (*pcVar3)(plVar42);
                  if (cVar8 != '\0') {
                    pcVar3 = *(code **)(*plVar42 + 0x18);
                    *(undefined8 *)(puVar44 + -8) = 0x1036bf;
                    cVar8 = (*pcVar3)(plVar42);
                    if (cVar8 == '\0') goto LAB_;
                  }
                }
                *(undefined8 *)(puVar44 + -8) = 0x1036cf;
                iVar14 = func_0x(plVar42);
                if (iVar14 == 0) {
                  pcVar3 = *(code **)(*plVar42 + 0x270);
                  *(undefined8 *)(puVar44 + -8) = 0x1036df;
                  (*pcVar3)(plVar42);
                }
                if ((*(byte *)(plVar42 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar42 + 0x4a) & 0x52) == 2) {
                    lVar23 = plVar42[0x1a];
                    *(undefined8 *)(puVar44 + -8) = 0x103719;
                    cVar8 = func_0x(lVar23);
                    if (((cVar8 != '\0') && (*(char *)(plVar42[0x1a] + 0x130) == '\0')) &&
                       (*(undefined *)(plVar42[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                      *(undefined8 *)(puVar44 + 0x20) = 0;
                      *(undefined8 *)(puVar44 + -8) = 0x103762;
                      func_0x(0x1e8a0f0,0x1c,0x10,1);
                    }
                  }
                  uVar41 = (uint)((*(byte *)(plVar42 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar3 = *(code **)(*plVar42 + 0x1e8);
                  *(undefined8 *)(puVar44 + -8) = 0x1036f5;
                  uVar24 = (*pcVar3)(plVar42);
                  *(undefined8 *)(puVar44 + -8) = 0x1036fd;
                  uVar41 = func_0x(uVar24);
                }
                if (uVar41 != 0) goto LAB_;
              }
            }
            if ((lVar17 == 0) || (*(int *)(lVar17 + 0x74) < 1)) goto LAB_;
          }
LAB_:
          uVar24 = *(undefined8 *)(&stack0x000000a0 + lVar16);
          *(undefined8 *)(puVar44 + -8) = 0x10378d;
          iVar14 = func_0x(uVar24);
          if (iVar14 != 0) {
            *(undefined8 *)(puVar44 + -8) = 0x1037a0;
            func_0x(uVar24,&stack0x00000198 + lVar16);
            *(undefined8 *)(puVar44 + -8) = 0x1037ac;
            iVar14 = func_0x(&stack0x00000198 + lVar16);
            uVar40 = uVar40 + iVar14;
          }
          lVar17 = plVar42[0x1a];
          pcVar3 = *(code **)(*plVar42 + 0x88);
          *(undefined8 *)(puVar44 + -8) = 0x1037c2;
          cVar8 = (*pcVar3)(plVar42);
          if ((((cVar8 == '\0') && (lVar17 != 0)) &&
              ((0 < *(int *)(lVar17 + 0x78) || (0 < *(int *)(lVar17 + 0x74))))) && (uVar40 < 0x1f74)
             ) {
            uVar40 = uVar40 + 8;
          }
          uVar40 = uVar40 + 0xe;
        }
        else {
          pcVar3 = *(code **)(*plVar42 + 0x88);
          *(undefined8 *)(puVar44 + -8) = 0x102f59;
          cVar8 = (*pcVar3)(plVar42);
          if (cVar8 == '\0') goto LAB_;
          pcVar3 = *(code **)(*plVar42 + 0x18);
          *(undefined8 *)(puVar44 + -8) = 0x102f66;
          cVar8 = (*pcVar3)(plVar42);
          if (cVar8 != '\0') goto LAB_;
LAB_:
          psVar50 = *(short **)(&stack0x000000a0 + lVar16);
          *(undefined8 *)(puVar44 + -8) = 0x103801;
          iVar14 = func_0x(psVar50);
          if (iVar14 != 0) {
            if (*psVar50 != 0) goto LAB_;
            if (*(int *)(psVar5 + 2) == 0) {
              *puVar49 = 0;
              uVar40 = *(uint *)(psVar5 + 8);
              uVar45 = (ulonglong)uVar40;
              *(uint *)(psVar5 + 10) = uVar40;
              pbVar35 = *(byte **)(psVar5 + 4);
              bVar28 = *pbVar35;
              if ((bVar28 & 0x10) != 0) {
                uVar40 = uVar40 + 2 + (*(ushort *)(pbVar35 + uVar45) + 7 >> 3);
                uVar45 = (ulonglong)uVar40;
                *(uint *)(psVar5 + 10) = uVar40;
                bVar28 = *pbVar35;
              }
              if ((bVar28 & 0x20) == 0) {
                *(int *)(psVar5 + 2) = (int)uVar45;
                psVar5[0xe] = 0;
                *(undefined4 *)(psVar5 + 0xc) = *(undefined4 *)(psVar5 + 10);
              }
              else {
                puVar46 = (ushort *)(pbVar35 + uVar45);
                uVar12 = *puVar46;
                psVar5[0xe] = uVar12;
                if (uVar12 == 0) {
                  *(undefined8 *)(puVar44 + -8) = 0x103874;
                  cVar8 = func_0x(0x1e85930);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar44 + -8) = 0x10387d;
                    lVar17 = func_0x();
                    if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar44 + -8) = 0x103897;
                      cVar8 = func_0x(0x1e85930);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar44 + -8) = 0x1038b3;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar44 + 0x20) = 0;
                        *(undefined8 *)(puVar44 + -8) = 0x1038d9;
                        (*_DAT_)(1,0x17766b8,0x1896388,0x80f);
                      }
                    }
                  }
                  uVar24 = *(undefined8 *)(psVar5 + 4);
                  *(undefined8 *)(puVar44 + -8) = 0x1038e7;
                  func_0x(uVar24,3);
                  uVar12 = psVar5[0xe];
                }
                uVar40 = *(int *)(psVar5 + 10) + 2 + (uint)uVar12 * 2;
                *(uint *)(psVar5 + 0xc) = uVar40;
                if (0x1f9e < uVar40) {
                  *(undefined8 *)(puVar44 + -8) = 0x10390e;
                  cVar8 = func_0x(0x1e85930);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar44 + -8) = 0x103917;
                    lVar17 = func_0x();
                    if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar44 + -8) = 0x103931;
                      cVar8 = func_0x(0x1e85930);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar44 + -8) = 0x10394d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar44 + 0x20) = 0;
                        *(undefined8 *)(puVar44 + -8) = 0x103973;
                        (*_DAT_)(1,0x17766b8,0x1896388,0x816);
                      }
                    }
                  }
                  uVar24 = *(undefined8 *)(psVar5 + 4);
                  *(undefined8 *)(puVar44 + -8) = 0x103981;
                  func_0x(uVar24,4);
                }
                uVar12 = puVar46[(ushort)psVar5[0xe]];
                *(uint *)(psVar5 + 2) = uVar12 & 0x7fff;
                if ((uVar12 & 0x7fff) < *(uint *)(psVar5 + 0xc)) {
                  *(undefined8 *)(puVar44 + -8) = 0x1039aa;
                  cVar8 = func_0x(0x1e85930);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar44 + -8) = 0x1039b3;
                    lVar17 = func_0x();
                    if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar44 + -8) = 0x1039cd;
                      cVar8 = func_0x(0x1e85930);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar44 + -8) = 0x1039e9;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar44 + 0x20) = 0;
                        *(undefined8 *)(puVar44 + -8) = 0x103a0f;
                        (*_DAT_)(1,0x17766b8,0x1896388,0x81d);
                      }
                    }
                  }
                  uVar24 = *(undefined8 *)(psVar5 + 4);
                  *(undefined8 *)(puVar44 + -8) = 0x103a1d;
                  func_0x(uVar24,4);
                }
                uVar12 = psVar5[0xe];
                do {
                  uVar45 = (ulonglong)uVar12;
                  if (-1 < (short)puVar46[(ulonglong)(uVar12 - 1) + 1]) break;
                  lVar17 = *(longlong *)(psVar5 + 4);
                  lVar23 = (ulonglong)*(uint *)(psVar5 + 10) + lVar17;
                  if (uVar12 == 1) {
                    uVar40 = *(uint *)(psVar5 + 0xc);
                    uVar36 = (ulonglong)uVar40;
                    uVar12 = *(ushort *)(lVar23 + uVar45 * 2);
LAB_:
                    if ((uVar12 & 0x7fff) < (uint)uVar36) goto LAB_;
                  }
                  else {
                    uVar41 = *(ushort *)(lVar23 + -2 + uVar45 * 2) & 0x7fff;
                    uVar36 = (ulonglong)uVar41;
                    uVar40 = *(uint *)(psVar5 + 0xc);
                    uVar12 = *(ushort *)(lVar23 + uVar45 * 2);
                    if (uVar40 <= uVar41) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar44 + -8) = 0x103a86;
                    func_0x(lVar17,7);
                    uVar40 = *(uint *)(psVar5 + 0xc);
                  }
                  if (((uint)uVar36 < uVar40) || (*(uint *)(psVar5 + 2) < (uint)uVar36))
                  goto LAB_;
                  if (*(ushort *)(uVar36 + *(longlong *)(psVar5 + 4)) == 5) {
                    *puVar49 = *puVar49 | 2;
                    psVar5[0xe] = psVar5[0xe] + -1;
                    psVar5[0x15] = (short)uVar36;
                    lVar17 = (uVar36 & 0xffff) + *(longlong *)(psVar5 + 4);
                    uVar12 = psVar5[0x16] & 0xc7ffU;
                    if ((*(ushort *)(lVar17 + 2) >> 0xe & 1) != 0) {
                      uVar12 = *(ushort *)(lVar17 + 2) & 0x3800 | psVar5[0x16] & 0xc7ffU;
                    }
                    psVar5[0x16] = uVar12;
                    psVar5[0x16] = (uVar12 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar12;
                    break;
                  }
                  if (*(ushort *)(uVar36 + *(longlong *)(psVar5 + 4)) < 0x400) break;
                  *puVar49 = *puVar49 | 1;
                  uVar12 = psVar5[0xe] - 1;
                  psVar5[0xe] = uVar12;
                } while (uVar12 != 0);
              }
              if ((**(byte **)(psVar5 + 4) & 0x40) == 0) {
                *(undefined4 *)(psVar5 + 0x13) = 0;
              }
              else {
                *(undefined4 *)(psVar5 + 0x13) = *(undefined4 *)(psVar5 + 2);
                *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + 0xe;
                *(undefined8 *)(puVar44 + -8) = 0x103af1;
                uVar24 = func_0x(puVar49);
                *(undefined8 *)(puVar44 + -8) = 0x103b00;
                func_0x(uVar24,&stack0x000001a0 + lVar16);
                *(undefined8 *)(puVar44 + -8) = 0x103b0c;
                iVar14 = func_0x(&stack0x000001a0 + lVar16);
                *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + iVar14;
              }
              uVar40 = *(uint *)(psVar5 + 2);
              if ((*(ulonglong *)(psVar5 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar5 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar5 + 4))) {
                *(undefined8 *)(puVar44 + -8) = 0x103bb4;
                cVar8 = func_0x(0x1e85930);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar44 + -8) = 0x103bbd;
                  lVar17 = func_0x();
                  if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar44 + -8) = 0x103bd7;
                    cVar8 = func_0x(0x1e85930);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar44 + -8) = 0x103bf3;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar44 + 0x20) = 0;
                      *(undefined8 *)(puVar44 + -8) = 0x103c19;
                      (*_DAT_)(1,0x17766b8,0x1896388,0x877);
                    }
                  }
                }
                uVar24 = *(undefined8 *)(psVar5 + 4);
                *(undefined8 *)(puVar44 + -8) = 0x103c27;
                func_0x(uVar24,0x12);
                uVar40 = *(uint *)(psVar5 + 2);
              }
              if (0x3f3b < uVar40 - 1) {
                *(undefined8 *)(puVar44 + -8) = 0x103c40;
                cVar8 = func_0x(0x1e85930);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar44 + -8) = 0x103c49;
                  lVar17 = func_0x();
                  if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar44 + -8) = 0x103c63;
                    cVar8 = func_0x(0x1e85930);
                    if (cVar8 == '\0') goto LAB_;
                    *(undefined8 *)(puVar44 + 0x20) = 0;
                    *(undefined8 *)(puVar44 + -8) = 0x103ca5;
                    (*_DAT_)(1,0x17766b8,0x1896388,0x87c);
                  }
                }
                goto LAB_;
              }
            }
            goto LAB_;
          }
        }
      }
      else if (*psVar50 == 0) {
        if (*(int *)(psVar5 + 2) == 0) {
          *puVar49 = 0;
          uVar40 = *(uint *)(psVar5 + 8);
          uVar45 = (ulonglong)uVar40;
          *(uint *)(psVar5 + 10) = uVar40;
          pbVar35 = *(byte **)(psVar5 + 4);
          bVar28 = *pbVar35;
          if ((bVar28 & 0x10) != 0) {
            uVar40 = uVar40 + 2 + (*(ushort *)(pbVar35 + uVar45) + 7 >> 3);
            uVar45 = (ulonglong)uVar40;
            *(uint *)(psVar5 + 10) = uVar40;
            bVar28 = *pbVar35;
          }
          if ((bVar28 & 0x20) == 0) {
            *(int *)(psVar5 + 2) = (int)uVar45;
            psVar5[0xe] = 0;
            *(undefined4 *)(psVar5 + 0xc) = *(undefined4 *)(psVar5 + 10);
          }
          else {
            puVar46 = (ushort *)(pbVar35 + uVar45);
            uVar12 = *puVar46;
            psVar5[0xe] = uVar12;
            if (uVar12 == 0) {
              *(undefined8 *)(puVar44 + -8) = 0x102b1b;
              cVar8 = func_0x(0x1e85930);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar44 + -8) = 0x102b24;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar44 + -8) = 0x102b3e;
                  cVar8 = func_0x(0x1e85930);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar44 + -8) = 0x102b5a;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar44 + 0x20) = 0;
                    *(undefined8 *)(puVar44 + -8) = 0x102b80;
                    (*_DAT_)(1,0x17766b8,0x1896388,0x80f);
                  }
                }
              }
              uVar24 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar44 + -8) = 0x102b8e;
              func_0x(uVar24,3);
              uVar12 = psVar5[0xe];
            }
            uVar40 = *(int *)(psVar5 + 10) + 2 + (uint)uVar12 * 2;
            *(uint *)(psVar5 + 0xc) = uVar40;
            if (0x1f9e < uVar40) {
              *(undefined8 *)(puVar44 + -8) = 0x102bb5;
              cVar8 = func_0x(0x1e85930);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar44 + -8) = 0x102bbe;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar44 + -8) = 0x102bd8;
                  cVar8 = func_0x(0x1e85930);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar44 + -8) = 0x102bf4;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar44 + 0x20) = 0;
                    *(undefined8 *)(puVar44 + -8) = 0x102c1a;
                    (*_DAT_)(1,0x17766b8,0x1896388,0x816);
                  }
                }
              }
              uVar24 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar44 + -8) = 0x102c28;
              func_0x(uVar24,4);
            }
            uVar12 = puVar46[(ushort)psVar5[0xe]];
            *(uint *)(psVar5 + 2) = uVar12 & 0x7fff;
            if ((uVar12 & 0x7fff) < *(uint *)(psVar5 + 0xc)) {
              *(undefined8 *)(puVar44 + -8) = 0x102c51;
              cVar8 = func_0x(0x1e85930);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar44 + -8) = 0x102c5a;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar44 + -8) = 0x102c74;
                  cVar8 = func_0x(0x1e85930);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar44 + -8) = 0x102c90;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar44 + 0x20) = 0;
                    *(undefined8 *)(puVar44 + -8) = 0x102cb6;
                    (*_DAT_)(1,0x17766b8,0x1896388,0x81d);
                  }
                }
              }
              uVar24 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar44 + -8) = 0x102cc4;
              func_0x(uVar24,4);
            }
            uVar12 = psVar5[0xe];
            do {
              uVar45 = (ulonglong)uVar12;
              if (-1 < (short)puVar46[(ulonglong)(uVar12 - 1) + 1]) break;
              lVar17 = *(longlong *)(psVar5 + 4);
              lVar23 = (ulonglong)*(uint *)(psVar5 + 10) + lVar17;
              if (uVar12 == 1) {
                uVar40 = *(uint *)(psVar5 + 0xc);
                uVar36 = (ulonglong)uVar40;
                uVar12 = *(ushort *)(lVar23 + uVar45 * 2);
LAB_:
                if ((uVar12 & 0x7fff) < (uint)uVar36) goto LAB_;
              }
              else {
                uVar41 = *(ushort *)(lVar23 + -2 + uVar45 * 2) & 0x7fff;
                uVar36 = (ulonglong)uVar41;
                uVar40 = *(uint *)(psVar5 + 0xc);
                uVar12 = *(ushort *)(lVar23 + uVar45 * 2);
                if (uVar40 <= uVar41) goto LAB_;
LAB_:
                *(undefined8 *)(puVar44 + -8) = 0x102d26;
                func_0x(lVar17,7);
                uVar40 = *(uint *)(psVar5 + 0xc);
              }
              if (((uint)uVar36 < uVar40) || (*(uint *)(psVar5 + 2) < (uint)uVar36))
              goto LAB_;
              if (*(ushort *)(uVar36 + *(longlong *)(psVar5 + 4)) == 5) {
                *puVar49 = *puVar49 | 2;
                psVar5[0xe] = psVar5[0xe] + -1;
                psVar5[0x15] = (short)uVar36;
                lVar17 = (uVar36 & 0xffff) + *(longlong *)(psVar5 + 4);
                uVar12 = psVar5[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar17 + 2) >> 0xe & 1) != 0) {
                  uVar12 = *(ushort *)(lVar17 + 2) & 0x3800 | psVar5[0x16] & 0xc7ffU;
                }
                psVar5[0x16] = uVar12;
                psVar5[0x16] = (uVar12 ^ *(ushort *)(lVar17 + 2)) & 0x7ff ^ uVar12;
                break;
              }
              if (*(ushort *)(uVar36 + *(longlong *)(psVar5 + 4)) < 0x400) break;
              *puVar49 = *puVar49 | 1;
              uVar12 = psVar5[0xe] - 1;
              psVar5[0xe] = uVar12;
            } while (uVar12 != 0);
          }
          if ((**(byte **)(psVar5 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar5 + 0x13) = 0;
          }
          else {
            *(undefined4 *)(psVar5 + 0x13) = *(undefined4 *)(psVar5 + 2);
            *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + 0xe;
            *(undefined8 *)(puVar44 + -8) = 0x102d91;
            uVar24 = func_0x(puVar49);
            *(undefined8 *)(puVar44 + -8) = 0x102da0;
            func_0x(uVar24,&stack0x00000190 + lVar16);
            *(undefined8 *)(puVar44 + -8) = 0x102dac;
            iVar14 = func_0x(&stack0x00000190 + lVar16);
            *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + iVar14;
          }
          uVar40 = *(uint *)(psVar5 + 2);
          if ((*(ulonglong *)(psVar5 + 0xf) != 0) &&
             (*(ulonglong *)(psVar5 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar5 + 4))) {
            *(undefined8 *)(puVar44 + -8) = 0x102e54;
            cVar8 = func_0x(0x1e85930);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar44 + -8) = 0x102e5d;
              lVar17 = func_0x();
              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                *(undefined8 *)(puVar44 + -8) = 0x102e77;
                cVar8 = func_0x(0x1e85930);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar44 + -8) = 0x102e93;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar44 + 0x20) = 0;
                  *(undefined8 *)(puVar44 + -8) = 0x102eb9;
                  (*_DAT_)(1,0x17766b8,0x1896388,0x877);
                }
              }
            }
            uVar24 = *(undefined8 *)(psVar5 + 4);
            *(undefined8 *)(puVar44 + -8) = 0x102ec7;
            func_0x(uVar24,0x12);
            uVar40 = *(uint *)(psVar5 + 2);
          }
          if (uVar40 - 1 < 0x3f3c) goto LAB_;
          *(undefined8 *)(puVar44 + -8) = 0x102ee4;
          cVar8 = func_0x(0x1e85930);
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar44 + -8) = 0x102ef1;
            lVar17 = func_0x();
            if ((lVar17 == 0) || (*(char *)(lVar17 + 0x499) == '\0')) goto LAB_;
            *(undefined8 *)(puVar44 + -8) = 0x102f13;
            cVar8 = func_0x(0x1e85930);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar44 + 0x20) = 0;
              *(undefined8 *)(puVar44 + -8) = 0x102f3f;
              (*_DAT_)(1,0x17766b8,0x1896388,0x87c);
              goto LAB_;
            }
LAB_:
            *(undefined8 *)(puVar44 + -8) = 0x103c7f;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
LAB_:
          uVar24 = *(undefined8 *)(psVar5 + 4);
          *(undefined8 *)(puVar44 + -8) = 0x103cb3;
          func_0x(uVar24,5);
        }
LAB_:
        uVar40 = *(uint *)(psVar5 + 2);
        if ((uVar40 < 9) &&
           (((**(byte **)(psVar5 + 4) & 0xe) == 0 || ((**(byte **)(psVar5 + 4) & 0xe) == 0xc)))) {
          uVar40 = 9;
        }
      }
      else {
LAB_:
        *(undefined8 *)(puVar44 + -8) = 0x103cde;
        uVar40 = func_0x(puVar49);
      }
      lVar17 = *plVar19;
      lVar23 = *(longlong *)(&stack0x000000b0 + lVar16);
      bVar28 = *(byte *)(*(longlong *)(lVar23 + 8) + 0x107);
      iVar14 = *(int *)(lVar17 + 0x40);
      *(undefined8 *)(puVar44 + -8) = 0x103d10;
      uVar25 = func_0x(lVar23,&stack0x000001e8 + lVar16);
      *(undefined8 *)(puVar44 + 0x40) = *(undefined8 *)(lVar17 + 0x10);
      lVar17 = *(longlong *)(&stack0x00000120 + lVar16);
      *(undefined2 *)(puVar44 + 0x38) = *(undefined2 *)(lVar17 + 8);
      *(longlong *)(puVar44 + 0x30) = lVar17;
      *(uint *)(puVar44 + 0x28) = bVar28 >> 6 & 1;
      *(uint *)(puVar44 + 0x20) = (uint)(iVar14 != 1);
      uVar24 = *(undefined8 *)(&stack0x000000b0 + lVar16);
      *(undefined8 *)(puVar44 + -8) = 0x103d4f;
      func_0x(&stack0x00000288 + lVar16,plVar42,uVar25,uVar24);
      *(undefined *)((longlong)puVar21 + 0x2ae) = 0;
      *(undefined8 *)(puVar44 + -8) = 0x103d60;
      cVar8 = func_0x(uVar24);
      *(undefined8 *)(puVar44 + -8) = 0x103d6f;
      cVar9 = func_0x(uVar24);
      lVar17 = *plVar19;
      *(uint *)(puVar44 + 0x28) = -(uint)(cVar8 != '\0') & 2;
      *(uint *)(puVar44 + 0x20) = (uint)(cVar9 != '\0');
      uVar25 = *(undefined8 *)(lVar17 + 0x20);
      *(undefined8 *)(puVar44 + -8) = 0x103d9c;
      func_0x(&stack0x00000240 + lVar16,&stack0x00000288 + lVar16,uVar25,uVar40);
      *(undefined8 *)(puVar44 + -8) = 0x103dae;
      uVar25 = func_0x(uVar24,&stack0x000001f0 + lVar16);
      *(undefined8 *)(puVar44 + -8) = 0x103db6;
      uVar25 = func_0x(uVar25);
      lVar17 = plVar42[6];
      *(undefined8 *)(puVar44 + -8) = 0x103dc2;
      cVar8 = func_0x(lVar17,uVar25);
      if (cVar8 != '\0') {
        *(undefined4 *)(&stack0x000000c8 + lVar16) = 1;
      }
      uVar40 = 0;
LAB_:
      uVar15 = 0;
      *(undefined8 *)(puVar44 + -8) = 0x103df3;
      func_0x(&stack0x00000240 + lVar16,&stack0x000007f8 + lVar16);
      *(undefined8 *)(puVar44 + -8) = 0x103e06;
      piVar26 = (int *)func_0x(&stack0x000007f8 + lVar16,&stack0x000001d0 + lVar16);
      if ((*piVar26 == 0) && (*(short *)(piVar26 + 1) == 0)) goto LAB_;
      if (*(char *)(*(longlong *)(*plVar19 + 0x20) + 1) != '\x05') {
        pcVar3 = *(code **)(*plVar42 + 0x28);
        *(undefined8 *)(puVar44 + -8) = 0x103e31;
        cVar9 = (*pcVar3)(plVar42);
        if (cVar9 != '\0') goto LAB_;
        *(undefined8 *)(puVar44 + -8) = 0x103e41;
        iVar14 = func_0x(uVar24);
        if (iVar14 != 0) goto LAB_;
        *(undefined8 *)(puVar44 + -8) = 0x103e5e;
        uVar24 = func_0x(&stack0x000007f8 + lVar16,&stack0x000001ca + lVar16);
        *(undefined8 *)(puVar44 + -8) = 0x103e69;
        uVar13 = func_0x(plVar42);
        *(undefined8 *)(puVar44 + -8) = 0x103e7e;
        func_0x(&stack0x000007e8 + lVar16,uVar13,uVar24,0);
        if (*(char *)(*(longlong *)(*plVar19 + 0x20) + 2) == '\0') {
          uVar24 = *(undefined8 *)(&stack0x000000b0 + lVar16);
          *(undefined8 *)(puVar44 + -8) = 0x103e99;
          cVar9 = func_0x(uVar24);
          if (cVar9 != '\0') goto LAB_;
          *(undefined8 *)(puVar44 + -8) = 0x103eb4;
          uVar25 = func_0x(&stack0x000001f8 + lVar16,8);
          uVar24 = *(undefined8 *)(&stack0x000000b0 + lVar16);
          *(undefined8 *)(puVar44 + -8) = 0x103ec7;
          uVar24 = func_0x(uVar24,&stack0x00000200 + lVar16);
          *(undefined8 *)(puVar44 + -8) = 0x103ed2;
          iVar14 = func_0x(uVar24,uVar25);
          if (iVar14 != 0) {
            uVar24 = *(undefined8 *)(&stack0x000000b0 + lVar16);
            *(undefined8 *)(puVar44 + -8) = 0x103ef2;
            uVar24 = func_0x(uVar24,&stack0x00000208 + lVar16);
            lVar17 = puVar21[7];
            *(undefined8 *)(puVar44 + 0x60) = 0;
            *(undefined8 **)(puVar44 + 0x58) = puVar21 + 0x18;
            *(undefined8 *)(puVar44 + 0x50) = uVar24;
            *(undefined8 *)(puVar44 + 0x48) = 0;
            *(undefined4 *)(puVar44 + 0x40) = 0;
            puVar44[0x38] = 0;
            *(undefined4 *)(puVar44 + 0x30) = 0;
            *(undefined4 *)(puVar44 + 0x28) = 1;
            *(undefined4 *)(puVar44 + 0x20) = 1;
            uVar24 = *(undefined8 *)(lVar17 + 8);
            *(undefined8 *)(puVar44 + -8) = 0x103f40;
            uVar15 = func_0x(uVar24,&stack0x000007e8 + lVar16,8);
          }
        }
        else {
LAB_:
          *(undefined4 *)(puVar44 + 0x38) = 1;
          *(undefined4 *)(puVar44 + 0x30) = 0;
          *(undefined4 *)(puVar44 + 0x28) = 0;
          *(undefined8 **)(puVar44 + 0x20) = puVar21 + 0x18;
          *(undefined8 *)(puVar44 + -8) = 0x103f7e;
          uVar15 = func_0x(plVar19,&stack0x000007e8 + lVar16,2);
        }
        *(undefined8 *)(puVar44 + -8) = 0x103f8b;
        cVar9 = func_0x(uVar15);
        if (cVar9 == '\0') goto LAB_;
LAB_:
        uVar40 = uVar40 + 1;
        if (*(uint *)(&stack0x000000c8 + lVar16) <= uVar40) goto LAB_;
        uVar24 = *(undefined8 *)(&stack0x000000b0 + lVar16);
        goto LAB_;
      }
LAB_:
      puVar47 = (undefined8 *)*plVar19;
      *(undefined **)(puVar44 + 0x20) = &stack0x00000220 + lVar16;
      uVar24 = *puVar47;
      *(undefined8 *)(puVar44 + -8) = 0x103fbe;
      iVar14 = func_0x(uVar24,&stack0x000007f8 + lVar16,3);
      if (iVar14 == 0) {
        if ((*(char *)(*(longlong *)(*plVar19 + 0x20) + 1) != '\x05') &&
           (*(char *)(*(longlong *)(*plVar19 + 0x20) + 2) != '\0')) {
          *(undefined8 *)(puVar44 + -8) = 0x10426b;
          iVar14 = func_0x(puVar21 + 0x18);
          if (iVar14 != 0) {
            *(undefined8 *)(puVar44 + -8) = 0x10427c;
            uVar24 = func_0x(puVar21 + 0x18);
            *(undefined8 *)(puVar44 + -8) = 0x104284;
            iVar14 = func_0x(uVar24);
            if (iVar14 != 0) {
              *(longlong *)(*plVar19 + 0x30) = *(longlong *)(*plVar19 + 0x30) + -1;
            }
          }
          *(undefined8 *)(puVar44 + -8) = 0x10429d;
          func_0x(puVar21 + 0x18);
          *(undefined8 *)(puVar44 + -8) = 0x1042aa;
          func_0x(puVar21 + 0x18);
          goto LAB_;
        }
      }
      else {
        puVar18 = (undefined4 *)(&stack0x000002e8 + lVar16);
        lVar17 = 2;
        puVar27 = (undefined4 *)(&stack0x000004e8 + lVar16);
        do {
          uVar15 = puVar18[1];
          uVar6 = puVar18[2];
          uVar7 = puVar18[3];
          *puVar27 = *puVar18;
          puVar27[1] = uVar15;
          puVar27[2] = uVar6;
          puVar27[3] = uVar7;
          uVar15 = puVar18[5];
          uVar6 = puVar18[6];
          uVar7 = puVar18[7];
          puVar27[4] = puVar18[4];
          puVar27[5] = uVar15;
          puVar27[6] = uVar6;
          puVar27[7] = uVar7;
          uVar15 = puVar18[9];
          uVar6 = puVar18[10];
          uVar7 = puVar18[0xb];
          puVar27[8] = puVar18[8];
          puVar27[9] = uVar15;
          puVar27[10] = uVar6;
          puVar27[0xb] = uVar7;
          uVar15 = puVar18[0xd];
          uVar6 = puVar18[0xe];
          uVar7 = puVar18[0xf];
          puVar27[0xc] = puVar18[0xc];
          puVar27[0xd] = uVar15;
          puVar27[0xe] = uVar6;
          puVar27[0xf] = uVar7;
          uVar15 = puVar18[0x11];
          uVar6 = puVar18[0x12];
          uVar7 = puVar18[0x13];
          puVar27[0x10] = puVar18[0x10];
          puVar27[0x11] = uVar15;
          puVar27[0x12] = uVar6;
          puVar27[0x13] = uVar7;
          uVar15 = puVar18[0x15];
          uVar6 = puVar18[0x16];
          uVar7 = puVar18[0x17];
          puVar27[0x14] = puVar18[0x14];
          puVar27[0x15] = uVar15;
          puVar27[0x16] = uVar6;
          puVar27[0x17] = uVar7;
          uVar15 = puVar18[0x19];
          uVar6 = puVar18[0x1a];
          uVar7 = puVar18[0x1b];
          puVar27[0x18] = puVar18[0x18];
          puVar27[0x19] = uVar15;
          puVar27[0x1a] = uVar6;
          puVar27[0x1b] = uVar7;
          uVar15 = puVar18[0x1d];
          uVar6 = puVar18[0x1e];
          uVar7 = puVar18[0x1f];
          puVar27[0x1c] = puVar18[0x1c];
          puVar27[0x1d] = uVar15;
          puVar27[0x1e] = uVar6;
          puVar27[0x1f] = uVar7;
          puVar18 = puVar18 + 0x20;
          lVar17 = lVar17 + -1;
          puVar27 = puVar27 + 0x20;
        } while (lVar17 != 0);
        *(undefined4 *)(puVar44 + 0x30) = 1;
        *(undefined **)(puVar44 + 0x28) = &stack0x000004e8 + lVar16;
        *(undefined8 *)(puVar44 + 0x20) = 0;
        *(undefined8 *)(puVar44 + -8) = 0x104064;
        func_0x(plVar19,&stack0x00000220 + lVar16,&stack0x00000140 + lVar16);
      }
      if (*(int *)(puVar21 + 0x1e) != 4) goto LAB_;
      *(undefined8 *)(puVar44 + -8) = 0x10407f;
      uVar10 = func_0x(&stack0x00000240 + lVar16);
      *(undefined *)((longlong)puVar21 + 0x2ae) = uVar10;
LAB_:
      if ((cVar8 != '\0') && (*(int *)(puVar21 + 0x1e) != 4)) {
        *(undefined8 *)(puVar44 + -8) = 0x1040b2;
        piVar26 = (int *)func_0x
                                   (&stack0x000007f8 + lVar16,&stack0x000001c4 + lVar16);
        if ((*piVar26 != 0) || (*(short *)(piVar26 + 1) != 0)) {
          *(undefined8 *)(puVar44 + -8) = 0x1040ce;
          func_0x(&stack0x00000118 + lVar16);
          uVar24 = *(undefined8 *)(&stack0x000000b0 + lVar16);
          *(undefined8 *)(puVar44 + -8) = 0x1040d7;
          uVar24 = func_0x(uVar24);
          *(undefined8 *)(puVar44 + -8) = 0x1040e6;
          func_0x(&stack0x00000118 + lVar16,uVar24);
          *(undefined8 *)(puVar44 + -8) = 0x1040f9;
          uVar24 = func_0x(&stack0x000007f8 + lVar16,&stack0x000001d8 + lVar16);
          *(undefined8 *)(puVar44 + -8) = 0x104108;
          func_0x(&stack0x000001a8 + lVar16,uVar24);
          (&stack0x00000072)[lVar16] = 4;
          *(undefined8 *)(puVar44 + -8) = 0x104119;
          uVar15 = func_0x(4);
          *(undefined8 *)(puVar44 + -8) = 0x104122;
          uVar15 = func_0x(uVar15,2);
          *(undefined8 *)(puVar44 + -8) = 0x10412e;
          uVar15 = func_0x(uVar15,0x20);
          *(undefined8 *)(puVar44 + -8) = 0x10413c;
          func_0x(&stack0x00000230 + lVar16,uVar15);
          *(longlong **)(puVar44 + 0x30) = plVar42;
          puVar44[0x28] = 1;
          *(undefined4 *)(puVar44 + 0x20) = 1;
          lVar17 = plVar42[6];
          *(undefined8 *)(puVar44 + -8) = 0x10416a;
          func_0x
                    (lVar17,&stack0x00000118 + lVar16,&stack0x000001a8 + lVar16,
                     &stack0x00000072 + lVar16);
          *(undefined8 *)(puVar44 + -8) = 0x104177;
          func_0x(&stack0x00000230 + lVar16);
        }
      }
LAB_:
      puVar47 = *(undefined8 **)(&stack0x000000b8 + lVar16);
      puVar22 = *(undefined8 **)(&stack0x00000088 + lVar16);
    }
    lVar23 = 2;
    lVar17 = 0;
    if (*(int *)(puVar21 + 0x1e) != 4) {
      puVar18 = (undefined4 *)(&stack0x000002e8 + lVar16);
      puVar27 = (undefined4 *)(&stack0x000005e8 + lVar16);
      do {
        uVar15 = puVar18[1];
        uVar6 = puVar18[2];
        uVar7 = puVar18[3];
        *puVar27 = *puVar18;
        puVar27[1] = uVar15;
        puVar27[2] = uVar6;
        puVar27[3] = uVar7;
        uVar15 = puVar18[5];
        uVar6 = puVar18[6];
        uVar7 = puVar18[7];
        puVar27[4] = puVar18[4];
        puVar27[5] = uVar15;
        puVar27[6] = uVar6;
        puVar27[7] = uVar7;
        uVar15 = puVar18[9];
        uVar6 = puVar18[10];
        uVar7 = puVar18[0xb];
        puVar27[8] = puVar18[8];
        puVar27[9] = uVar15;
        puVar27[10] = uVar6;
        puVar27[0xb] = uVar7;
        uVar15 = puVar18[0xd];
        uVar6 = puVar18[0xe];
        uVar7 = puVar18[0xf];
        puVar27[0xc] = puVar18[0xc];
        puVar27[0xd] = uVar15;
        puVar27[0xe] = uVar6;
        puVar27[0xf] = uVar7;
        uVar15 = puVar18[0x11];
        uVar6 = puVar18[0x12];
        uVar7 = puVar18[0x13];
        puVar27[0x10] = puVar18[0x10];
        puVar27[0x11] = uVar15;
        puVar27[0x12] = uVar6;
        puVar27[0x13] = uVar7;
        uVar15 = puVar18[0x15];
        uVar6 = puVar18[0x16];
        uVar7 = puVar18[0x17];
        puVar27[0x14] = puVar18[0x14];
        puVar27[0x15] = uVar15;
        puVar27[0x16] = uVar6;
        puVar27[0x17] = uVar7;
        uVar15 = puVar18[0x19];
        uVar6 = puVar18[0x1a];
        uVar7 = puVar18[0x1b];
        puVar27[0x18] = puVar18[0x18];
        puVar27[0x19] = uVar15;
        puVar27[0x1a] = uVar6;
        puVar27[0x1b] = uVar7;
        uVar15 = puVar18[0x1d];
        uVar6 = puVar18[0x1e];
        uVar7 = puVar18[0x1f];
        puVar27[0x1c] = puVar18[0x1c];
        puVar27[0x1d] = uVar15;
        puVar27[0x1e] = uVar6;
        puVar27[0x1f] = uVar7;
        puVar18 = puVar18 + 0x20;
        lVar23 = lVar23 + -1;
        puVar27 = puVar27 + 0x20;
      } while (lVar23 != 0);
      *(undefined **)(puVar44 + 0x20) = &stack0x000005e8 + lVar16;
      *(undefined8 *)(puVar44 + -8) = 0x104223;
      func_0x(plVar19,&stack0x00000140 + lVar16,0,0);
    }
    if (puVar22 != (undefined8 *)0x0) {
      if ((longlong *)puVar21[0xb] == (longlong *)0x0) {
        if (*(int *)(puVar21 + 0x1e) != 2) {
          *(undefined8 *)(puVar44 + -8) = 0x1042e4;
          func_0x(plVar19,1);
          if (*(int *)(puVar21 + 0x1e) != 2) {
            lVar17 = *(longlong *)puVar21[0xb];
          }
        }
      }
      else {
        lVar17 = *(longlong *)puVar21[0xb];
      }
      *(undefined4 *)(puVar22 + 1) = *(undefined4 *)(lVar17 + 0x20);
      *(undefined2 *)((longlong)puVar22 + 0xc) = *(undefined2 *)(lVar17 + 0x24);
      *(undefined2 *)((longlong)puVar22 + 0xe) = 0;
      *puVar22 = 0;
      *(undefined4 *)((longlong)puVar22 + 0x1c) = 1;
      puVar22[2] = 0;
      *(undefined2 *)(puVar22 + 3) = 0;
    }
  }
  lVar17 = 2;
  uVar45 = 0;
  puVar18 = (undefined4 *)(&stack0x000006e8 + lVar16);
  do {
    uVar15 = *(undefined4 *)((longlong)puVar31 + 4);
    uVar6 = *(undefined4 *)(puVar31 + 1);
    uVar7 = *(undefined4 *)((longlong)puVar31 + 0xc);
    *puVar18 = *(undefined4 *)puVar31;
    puVar18[1] = uVar15;
    puVar18[2] = uVar6;
    puVar18[3] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar31 + 0x14);
    uVar6 = *(undefined4 *)(puVar31 + 3);
    uVar7 = *(undefined4 *)((longlong)puVar31 + 0x1c);
    puVar18[4] = *(undefined4 *)(puVar31 + 2);
    puVar18[5] = uVar15;
    puVar18[6] = uVar6;
    puVar18[7] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar31 + 0x24);
    uVar6 = *(undefined4 *)(puVar31 + 5);
    uVar7 = *(undefined4 *)((longlong)puVar31 + 0x2c);
    puVar18[8] = *(undefined4 *)(puVar31 + 4);
    puVar18[9] = uVar15;
    puVar18[10] = uVar6;
    puVar18[0xb] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar31 + 0x34);
    uVar6 = *(undefined4 *)(puVar31 + 7);
    uVar7 = *(undefined4 *)((longlong)puVar31 + 0x3c);
    puVar18[0xc] = *(undefined4 *)(puVar31 + 6);
    puVar18[0xd] = uVar15;
    puVar18[0xe] = uVar6;
    puVar18[0xf] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar31 + 0x44);
    uVar6 = *(undefined4 *)(puVar31 + 9);
    uVar7 = *(undefined4 *)((longlong)puVar31 + 0x4c);
    puVar18[0x10] = *(undefined4 *)(puVar31 + 8);
    puVar18[0x11] = uVar15;
    puVar18[0x12] = uVar6;
    puVar18[0x13] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar31 + 0x54);
    uVar6 = *(undefined4 *)(puVar31 + 0xb);
    uVar7 = *(undefined4 *)((longlong)puVar31 + 0x5c);
    puVar18[0x14] = *(undefined4 *)(puVar31 + 10);
    puVar18[0x15] = uVar15;
    puVar18[0x16] = uVar6;
    puVar18[0x17] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar31 + 100);
    uVar6 = *(undefined4 *)(puVar31 + 0xd);
    uVar7 = *(undefined4 *)((longlong)puVar31 + 0x6c);
    puVar18[0x18] = *(undefined4 *)(puVar31 + 0xc);
    puVar18[0x19] = uVar15;
    puVar18[0x1a] = uVar6;
    puVar18[0x1b] = uVar7;
    uVar15 = *(undefined4 *)((longlong)puVar31 + 0x74);
    uVar6 = *(undefined4 *)(puVar31 + 0xf);
    uVar7 = *(undefined4 *)((longlong)puVar31 + 0x7c);
    puVar18[0x1c] = *(undefined4 *)(puVar31 + 0xe);
    puVar18[0x1d] = uVar15;
    puVar18[0x1e] = uVar6;
    puVar18[0x1f] = uVar7;
    puVar31 = puVar31 + 0x10;
    lVar17 = lVar17 + -1;
    puVar18 = puVar18 + 0x20;
  } while (lVar17 != 0);
  *(undefined8 *)(puVar44 + 0x20) = 0;
  *(undefined8 *)(puVar44 + -8) = 0x1043b2;
  func_0x(plVar19,&stack0x00000140 + lVar16,&stack0x000006e8 + lVar16,1);
  *(uint *)((longlong)puVar47 + 0x634) = *(uint *)((longlong)puVar47 + 0x634) | 1;
  if (*(int *)(&stack0x00000074 + lVar16) != 0) {
    puVar21 = *(undefined8 **)(puVar47[5] + 0x18);
    *(int *)((longlong)puVar21 + 0xc) = *(int *)((longlong)puVar21 + 0xc) + 1;
    if (*(uint *)(puVar21 + 1) <= *(uint *)((longlong)puVar21 + 0xc)) {
      *(undefined4 *)(puVar21 + 1) = 0;
      *puVar21 = 0;
    }
    if (*(int *)(&stack0x00000078 + lVar16) != 0) {
      *(undefined4 *)(puVar47 + 0xa9) = *(undefined4 *)(&stack0x00000098 + lVar16);
      *(undefined4 *)((longlong)puVar47 + 0x54c) = *(undefined4 *)(&stack0x00000080 + lVar16);
    }
  }
  lVar17 = *(longlong *)(&stack0x00000100 + lVar16);
  lVar23 = *(longlong *)(*(longlong *)(lVar17 + 8) + 0x488);
  if (((lVar23 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
    if (*(longlong *)(lVar23 + 0x20) != 0) {
      lVar51 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar20 = *(longlong *)(lVar51 + 0x100);
      if (lVar20 == 0) {
        *(undefined8 *)(puVar44 + -8) = 0x104463;
        (*_DAT_)(0);
        lVar20 = *(longlong *)(lVar51 + 0x100);
        lVar17 = *(longlong *)(&stack0x00000100 + lVar16);
      }
      if (*(longlong *)(lVar20 + 0x260) != 0) {
        uVar45 = (ulonglong)*(uint *)(*(longlong *)(lVar20 + 0x260) + 0xe68);
      }
      if ((uint)uVar45 < *(uint *)(_DAT_ + 8)) {
        plVar19 = *(longlong **)(*(longlong *)(lVar23 + 0x20) + uVar45 * 8);
        *plVar19 = *plVar19 + 1;
        goto LAB_;
      }
    }
    LOCK();
    **(longlong **)(lVar23 + 0x18) = **(longlong **)(lVar23 + 0x18) + 1;
    UNLOCK();
  }
LAB_:
  if (((*(longlong *)(*(longlong *)(lVar17 + 8) + 0x70) != 0) ||
      (*(int *)(*(longlong *)(*(longlong *)(lVar17 + 0x20) + 0x710) + 0x40) != 0)) &&
     ((*(byte *)(*(longlong *)(lVar17 + 8) + 0x106) & 4) == 0)) {
    plVar19 = (longlong *)
              (*(longlong *)
                (*(longlong *)(*(longlong *)(*(longlong *)(&stack0x00000090 + lVar16) + 0x2e0) + 8)
                + 0x30) + 0x140);
    *plVar19 = *plVar19 + 1;
  }
  **(undefined8 **)(&stack0x000001b0 + lVar16) = puVar47;
  plVar19 = *(longlong **)(&stack0x000001b8 + lVar16);
  if (plVar19 != (longlong *)0x0) {
    pcVar3 = *(code **)(*plVar19 + 0xd0);
    *(undefined8 *)(puVar44 + -8) = 0x104513;
    (*pcVar3)(plVar19,0);
  }
  uVar45 = *(ulonglong *)(&stack0x00002978 + lVar16);
  *(undefined8 *)(puVar44 + -8) = 0x104522;
  func_0x(uVar45 ^ (ulonglong)psVar1);
  return;
code_r0x00101e24:
  uVar40 = uVar41;
  if (uVar41 == 0) goto LAB_;
  goto LAB_;
}

