
undefined8 FUN_(uint *param_1,uint *param_2)

{
  byte bVar1;
  undefined8 uVar2;
  int iVar3;
  uint uVar4;
  short sVar5;
  short sVar6;
  undefined2 uStack_168;
  ushort uStack_166;
  undefined4 uStack_164;
  byte *pbStack_160;
  undefined8 uStack_158;
  undefined4 uStack_150;
  short sStack_14c;
  undefined8 uStack_14a;
  undefined2 uStack_142;
  undefined2 uStack_140;
  undefined6 uStack_13e;
  undefined4 uStack_138;
  undefined2 uStack_130;
  ushort uStack_12e;
  undefined4 uStack_12c;
  byte *pbStack_128;
  undefined8 uStack_120;
  undefined4 uStack_118;
  short sStack_114;
  undefined8 uStack_112;
  undefined2 uStack_10a;
  undefined2 uStack_108;
  undefined6 uStack_106;
  undefined4 uStack_100;
  longlong lStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  undefined4 uStack_d0;
  uint auStack_c8 [2];
  longlong lStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  undefined2 *puStack_a8;
  undefined8 uStack_a0;
  undefined auStack_98 [16];
  uint auStack_78 [2];
  longlong lStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined2 *puStack_58;
  undefined8 uStack_50;
  undefined auStack_48 [16];
  
  uStack_164 = 0;
  uStack_14a = 0;
  uStack_140 = 0;
  uStack_13e = 0;
  uStack_158 = 0;
  uStack_12c = 0;
  uStack_112 = 0;
  uStack_108 = 0;
  uStack_106 = 0;
  uStack_120 = 0;
  if (*param_1 == 0) {
    if (*param_2 == 0) {
      uVar2 = 1;
    }
    else {
      uVar2 = 3;
    }
  }
  else if (*param_2 == 0) {
    uVar2 = 2;
  }
  else {
    pbStack_160 = *(byte **)(param_1 + 2);
    lStack_f8 = 0;
    auStack_78[0] = 0;
    uStack_68 = 0;
    uStack_50 = 0;
    auStack_48 = ZEXT816(0);
    auStack_c8[0] = 0;
    sVar5 = 3;
    uStack_b8 = 0;
    uStack_a0 = 0;
    auStack_98 = ZEXT816(0);
    sVar6 = 3;
    if ((*pbStack_160 & 1) == 0) {
      uStack_168 = 0;
      uStack_142 = 0;
      uStack_140 = 0;
      uVar4 = *param_1;
      switch(*pbStack_160 & 0xe) {
      default:
        uVar4 = (uint)*(ushort *)(pbStack_160 + 2);
        if (0x1f9d < uVar4 - 1) {
          func_0x(pbStack_160,6);
        }
        break;
      case 4:
        uVar4 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar4 = 1;
      }
      uStack_158 = CONCAT44(uStack_158._4_4_,uVar4);
    }
    else {
      uStack_168 = 1;
      bVar1 = *pbStack_160;
      switch(bVar1 & 0x1c) {
      default:
        if ((char)pbStack_160[1] < '\0') {
          uStack_150 = 3;
          uStack_166 = (*(ushort *)(pbStack_160 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_160 + 1) >> 8;
        }
        else {
          uStack_166 = (ushort)pbStack_160[1];
          uStack_150 = 2;
          sVar6 = 2;
        }
        sStack_14c = ((ushort)(uStack_166 + 1) >> 1) + sVar6;
        if (uStack_166 < 0x1f) {
          uStack_138 = 0;
        }
        else {
          iVar3 = uStack_166 - 1;
          uStack_138 = 0;
          uStack_150 = CONCAT22(((short)(iVar3 / 0x1e) + (short)(iVar3 >> 0x1f)) -
                                (short)((longlong)iVar3 * 0x88888889 >> 0x3f),(undefined2)uStack_150
                               );
        }
        break;
      case 4:
        if (((bVar1 & 0x1c) == 4) && ((bVar1 & 2) != 0)) {
          uStack_150 = 0;
          uStack_166 = 0;
          sStack_14c = 0;
          uStack_142 = 0;
          uStack_164 = 0xf;
          uStack_138 = 1;
        }
        else {
          uStack_150 = 0;
          uStack_166 = 0;
          sStack_14c = 0;
          uStack_142 = 0;
          uStack_164 = 1;
          uStack_138 = 0;
        }
        break;
      case 8:
        uStack_150 = 0;
        uStack_166 = 0;
        sStack_14c = 0;
        uStack_142 = 0;
        uStack_164 = 9;
        uStack_138 = 0;
      }
    }
    pbStack_128 = *(byte **)(param_2 + 2);
    if ((*pbStack_128 & 1) == 0) {
      uStack_130 = 0;
      uStack_10a = 0;
      uStack_108 = 0;
      uVar4 = *param_2;
      switch(*pbStack_128 & 0xe) {
      default:
        uVar4 = (uint)*(ushort *)(pbStack_128 + 2);
        if (0x1f9d < uVar4 - 1) {
          func_0x(pbStack_128,6);
        }
        break;
      case 4:
        uVar4 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar4 = 1;
      }
      uStack_120 = CONCAT44(uStack_120._4_4_,uVar4);
    }
    else {
      uStack_130 = 1;
      bVar1 = *pbStack_128;
      switch(bVar1 & 0x1c) {
      default:
        if ((char)pbStack_128[1] < '\0') {
          uStack_118 = 3;
          uStack_12e = (*(ushort *)(pbStack_128 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_128 + 1) >> 8;
        }
        else {
          uStack_12e = (ushort)pbStack_128[1];
          uStack_118 = 2;
          sVar5 = 2;
        }
        sStack_114 = ((ushort)(uStack_12e + 1) >> 1) + sVar5;
        if (uStack_12e < 0x1f) {
          uStack_100 = 0;
        }
        else {
          iVar3 = uStack_12e - 1;
          uStack_118 = CONCAT22(((short)(iVar3 / 0x1e) + (short)(iVar3 >> 0x1f)) -
                                (short)((longlong)iVar3 * 0x88888889 >> 0x3f),(undefined2)uStack_118
                               );
          uStack_100 = 0;
        }
        break;
      case 4:
        if (((bVar1 & 0x1c) == 4) && ((bVar1 & 2) != 0)) {
          uStack_12c = 0xf;
          uStack_118 = 0;
          uStack_12e = 0;
          sStack_114 = 0;
          uStack_10a = 0;
          uStack_100 = 1;
        }
        else {
          uStack_12c = 1;
          uStack_118 = 0;
          uStack_12e = 0;
          sStack_114 = 0;
          uStack_10a = 0;
          uStack_100 = 0;
        }
        break;
      case 8:
        uStack_12c = 9;
        uStack_118 = 0;
        uStack_12e = 0;
        sStack_114 = 0;
        uStack_10a = 0;
        uStack_100 = 0;
      }
    }
    lStack_c0 = *(longlong *)(param_1 + 4);
    lStack_f8 = *(longlong *)(lStack_c0 + 0x80);
    uStack_f0 = 6;
    uStack_e0 = 0;
    uStack_e8 = 0;
    uStack_d8 = 0;
    uStack_d0 = 0;
    uStack_ec = *(undefined4 *)(**(longlong **)(*(longlong *)(lStack_f8 + 8) + 0x160) + 0x1c);
    puStack_58 = &uStack_168;
    auStack_78[0] = auStack_78[0] | 1;
    auStack_c8[0] = auStack_c8[0] | 1;
    puStack_a8 = &uStack_130;
    uStack_60 = 0;
    uStack_b0 = 0;
    lStack_70 = lStack_c0;
    uVar2 = func_0x(auStack_78,&lStack_f8,auStack_c8);
  }
  return uVar2;
}

