
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong param_3,undefined4 *param_4)

{
  byte bVar1;
  longlong lVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong lVar7;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar8;
  ulonglong uVar9;
  undefined auStackX_20 [4];
  char acStackX_24 [4];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar5 = func_0x();
  lVar5 = -lVar5;
  *(undefined8 *)(&stack0x000000c8 + lVar5) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000020b0 + lVar5) = _DAT_ ^ (ulonglong)(auStackX_20 + lVar5);
  *(undefined4 **)(&stack0x000000b8 + lVar5) = param_4;
  *(longlong *)(&stack0x00000068 + lVar5) = param_3;
  *(longlong **)(&stack0x00000070 + lVar5) = param_2;
  *(longlong *)(&stack0x00000030 + lVar5) = param_1;
  *(undefined8 *)(&stack0x000000a0 + lVar5) = *(undefined8 *)(&stack0x00002130 + lVar5);
  uVar9 = 0;
  *(undefined4 *)(&stack0x00000050 + lVar5) = 0;
  *(undefined4 *)(&stack0x0000007c + lVar5) = 0;
  *(undefined4 *)(&stack0x00000038 + lVar5) = 0;
  *(undefined8 *)(&stack0x000000d0 + lVar5) = 0;
  *(undefined8 *)(&stack0x000000d8 + lVar5) = 0;
  *(undefined4 *)(&stack0x000000e0 + lVar5) = 0;
  *(undefined8 *)(&stack0x000000e8 + lVar5) = 0;
  *(undefined4 *)(&stack0x000000f0 + lVar5) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar5) = 0;
  *(undefined8 *)(&stack0x00000048 + lVar5) = 0;
  lVar2 = *param_2;
  *(longlong *)(&stack0x000000c0 + lVar5) = lVar2;
  *(undefined4 *)(&stack0x00000028 + lVar5) = *(undefined4 *)(*(longlong *)(lVar2 + 0x80) + 0x14);
  *(undefined4 *)(&stack0x00000078 + lVar5) = 0;
  *(undefined8 *)(&stack0x000000a8 + lVar5) = 0;
  *(undefined4 *)(&stack0x00000088 + lVar5) = 0;
  acStackX_24[lVar5] = '\0';
  acStackX_24[lVar5 + 1] = '\0';
  *param_4 = 0;
  if (*(int *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) + 0x100) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar7 = *(longlong *)(param_1 + 8);
  puVar3 = *(undefined8 **)(lVar7 + 0x10);
  if (puVar3 != (undefined8 *)0x0) {
    UNRECOVERED_JUMPTABLE = *(code **)*puVar3;
    *(undefined8 *)((longlong)&uStack_48 + lVar5) = 0x100109;
    uVar6 = (*UNRECOVERED_JUMPTABLE)(puVar3);
    *(undefined8 *)(*(longlong *)(param_1 + 8) + 8) = uVar6;
    lVar7 = *(longlong *)(param_1 + 8);
  }
  *(undefined4 *)(&stack0x00000060 + lVar5) = 0;
  lVar2 = *(longlong *)(*(longlong *)(lVar2 + 0x80) + 0x18);
  *(longlong *)(&stack0x00000058 + lVar5) = lVar2;
  if (*(int *)(&stack0x00000028 + lVar5) != 0) {
    *(undefined8 *)(&stack0x00000098 + lVar5) = 0;
    bVar1 = *(byte *)(lVar2 + 0x40);
    if (0x19 < bVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)*(uint *)((longlong)(char)bVar1 * 4 + 0xffe50) + 0x7f100);
                    /* WARNING: Could not emulate address calculation at 0x00100171 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,0x2538928,0x800);
    return;
  }
  if (*(longlong **)(lVar7 + 0x10) != (longlong *)0x0) {
    UNRECOVERED_JUMPTABLE = *(code **)(**(longlong **)(lVar7 + 0x10) + 8);
    *(undefined8 *)((longlong)&uStack_48 + lVar5) = 0x1002ce;
    (*UNRECOVERED_JUMPTABLE)();
  }
  if (*(int *)(&stack0x0000004c + lVar5) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_3 != 0) && (*(int *)(param_3 + 4) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  plVar4 = *(longlong **)(*(longlong *)(param_1 + 8) + 0x10);
  if (plVar4 != (longlong *)0x0) {
    UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 8);
    *(undefined8 *)((longlong)&uStack_48 + lVar5) = 0x1002fd;
    (*UNRECOVERED_JUMPTABLE)();
  }
  if (acStackX_24[lVar5] != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((*(int *)(&stack0x00000050 + lVar5) == 0) && (*(int *)(&stack0x0000007c + lVar5) == 0)) &&
     (*(int *)(&stack0x00000038 + lVar5) == 0)) {
    **(undefined4 **)(&stack0x000000a0 + lVar5) = 1;
    if ((*(longlong *)(&stack0x000000d8 + lVar5) != 0) && (*(uint *)(&stack0x000000d0 + lVar5) != 0)
       ) {
      do {
        if ((*(byte *)(*(longlong *)(&stack0x000000d8 + lVar5) + 0x18 + uVar9 * 0x40) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar8 = (int)uVar9 + 1;
        uVar9 = (ulonglong)uVar8;
      } while (uVar8 < *(uint *)(&stack0x000000d0 + lVar5));
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar5) = 0x100389;
    func_0x(*(ulonglong *)(&stack0x000020b0 + lVar5) ^ (ulonglong)(auStackX_20 + lVar5));
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

