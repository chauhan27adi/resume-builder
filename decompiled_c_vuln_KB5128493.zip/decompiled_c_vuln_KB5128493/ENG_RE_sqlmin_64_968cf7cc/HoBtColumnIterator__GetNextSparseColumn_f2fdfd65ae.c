
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong *param_1)

{
  ushort *puVar1;
  uint uVar2;
  longlong lVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  ulonglong *puVar7;
  longlong lVar8;
  uint uVar9;
  ushort uVar10;
  uint uVar11;
  ulonglong uVar12;
  longlong lVar13;
  uint uVar14;
  longlong lVar15;
  byte *pbVar16;
  ushort *puVar17;
  longlong unaff_GS_OFFSET;
  int iStackX_8;
  
  uVar2 = *(uint *)(param_1 + 2);
  lVar8 = 0;
  uVar14 = 0;
  if (*(uint *)((longlong)param_1 + 0xc) <= uVar2) {
    return 0;
  }
  lVar3 = param_1[4];
  puVar1 = (ushort *)(lVar3 + 2);
  if (*(int *)(lVar3 + 4) == 0) {
    pbVar16 = *(byte **)(lVar3 + 8);
    uVar11 = *(uint *)(lVar3 + 0x10);
    uVar12 = (ulonglong)uVar11;
    *puVar1 = 0;
    *(uint *)(lVar3 + 0x14) = uVar11;
    bVar4 = *pbVar16;
    if ((bVar4 & 0x10) != 0) {
      uVar11 = uVar11 + 2 + (*(ushort *)(pbVar16 + uVar12) + 7 >> 3);
      uVar12 = (ulonglong)uVar11;
      *(uint *)(lVar3 + 0x14) = uVar11;
      bVar4 = *pbVar16;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(lVar3 + 4) = (int)uVar12;
      *(undefined2 *)(lVar3 + 0x1c) = 0;
      *(int *)(lVar3 + 0x18) = (int)uVar12;
    }
    else {
      puVar17 = (ushort *)(pbVar16 + uVar12);
      uVar5 = *puVar17;
      *(ushort *)(lVar3 + 0x1c) = uVar5;
      if (uVar5 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0)) &&
           ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
            (*(char *)(lVar15 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x105f338,0x117f008,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(lVar3 + 8),3);
        uVar12 = (ulonglong)*(uint *)(lVar3 + 0x14);
        uVar5 = *(ushort *)(lVar3 + 0x1c);
      }
      uVar11 = (int)uVar12 + (uVar5 + 1) * 2;
      *(uint *)(lVar3 + 0x18) = uVar11;
      if (0x1f9e < uVar11) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0 &&
            ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
             (*(char *)(lVar15 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x105f338,0x117f008,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(lVar3 + 8),4);
        uVar5 = *(ushort *)(lVar3 + 0x1c);
        uVar11 = *(uint *)(lVar3 + 0x18);
      }
      uVar12 = (ulonglong)uVar5;
      uVar5 = puVar17[uVar12];
      *(uint *)(lVar3 + 4) = uVar5 & 0x7fff;
      if ((uVar5 & 0x7fff) < uVar11) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar15 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar15 != 0)) &&
           ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
            (*(char *)(lVar15 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x105f338,0x117f008,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(lVar3 + 8),4);
        uVar12 = (ulonglong)*(ushort *)(lVar3 + 0x1c);
      }
      if ((short)puVar17[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
        lVar15 = *(longlong *)(lVar3 + 8);
        do {
          lVar13 = (ulonglong)*(uint *)(lVar3 + 0x14) + lVar15;
          if ((int)uVar12 == 1) {
            uVar11 = *(uint *)(lVar3 + 0x18);
            uVar9 = uVar11;
LAB_:
            if ((*(ushort *)(lVar13 + uVar12 * 2) & 0x7fff) < uVar11) goto LAB_;
          }
          else {
            uVar9 = *(uint *)(lVar3 + 0x18);
            uVar11 = *(ushort *)(lVar13 + -2 + uVar12 * 2) & 0x7fff;
            if (uVar9 <= uVar11) goto LAB_;
LAB_:
            func_0x(lVar15,7);
            uVar9 = *(uint *)(lVar3 + 0x18);
          }
          if ((uVar11 < uVar9) || (*(uint *)(lVar3 + 4) < uVar11)) goto LAB_;
          lVar15 = *(longlong *)(lVar3 + 8);
          if (*(ushort *)(lVar15 + (ulonglong)uVar11) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(lVar3 + 0x1c) = *(short *)(lVar3 + 0x1c) + -1;
            uVar5 = *(ushort *)(lVar3 + 0x2c) & 0xc7ff;
            *(short *)(lVar3 + 0x2a) = (short)uVar11;
            lVar15 = (ulonglong)(uVar11 & 0xffff) + lVar15;
            if ((*(ushort *)(lVar15 + 2) & 0x4000) != 0) {
              uVar5 = *(ushort *)(lVar15 + 2) & 0x3800 | uVar5;
            }
            *(ushort *)(lVar3 + 0x2c) = uVar5;
            *(ushort *)(lVar3 + 0x2c) = (uVar5 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar5;
            uVar12 = (ulonglong)*(uint *)(lVar3 + 4);
            pbVar16 = *(byte **)(lVar3 + 8);
            goto LAB_;
          }
          if (*(ushort *)(lVar15 + (ulonglong)uVar11) < 0x400) break;
          *puVar1 = *puVar1 | 1;
          uVar5 = *(short *)(lVar3 + 0x1c) - 1;
          *(ushort *)(lVar3 + 0x1c) = uVar5;
          if ((uVar5 == 0) ||
             (uVar12 = (ulonglong)uVar5, -1 < (short)puVar17[(ulonglong)(uVar5 - 1) + 1])) break;
        } while( true );
      }
      uVar12 = (ulonglong)*(uint *)(lVar3 + 4);
      pbVar16 = *(byte **)(lVar3 + 8);
    }
LAB_:
    if ((*pbVar16 & 0x40) == 0) {
      *(undefined4 *)(lVar3 + 0x26) = 0;
    }
    else {
      *(int *)(lVar3 + 0x26) = *(int *)(lVar3 + 4);
      *(int *)(lVar3 + 4) = *(int *)(lVar3 + 4) + 0xe;
      puVar7 = (ulonglong *)func_0x(puVar1);
      uVar12 = *puVar7;
      uVar10 = (ushort)(uVar12 >> 0x30);
      uVar5 = uVar10;
      if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
        uVar5 = uVar10 & 0xdfff;
        if ((uVar12 & 0x4000000000000000) != 0) {
          uVar5 = uVar10 | 0x2000;
        }
      }
      uVar11 = uVar14;
      if (uVar5 == 0xfffc) {
        uVar11 = (uint)((uVar12 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(lVar3 + 4) = *(int *)(lVar3 + 4) + uVar11;
      uVar12 = (ulonglong)*(uint *)(lVar3 + 4);
    }
    iVar6 = (int)uVar12;
    if ((*(ulonglong *)(lVar3 + 0x1e) != 0) &&
       (*(ulonglong *)(lVar3 + 0x1e) < uVar12 + *(longlong *)(lVar3 + 8))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar15 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar15 != 0 &&
           (lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0)) &&
          (*(char *)(lVar15 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x105f338,0x117f008,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(lVar3 + 8),0x12);
      iVar6 = *(int *)(lVar3 + 4);
    }
    if (0x3f3b < iVar6 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar15 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar15 != 0 &&
          ((lVar15 = *(longlong *)(lVar15 + 0x60), lVar15 != 0 &&
           (*(char *)(lVar15 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x105f338,0x117f008,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(lVar3 + 8),5);
    }
  }
LAB_:
  iVar6 = func_0x(puVar1);
  if (iVar6 == 0) {
    iVar6 = func_0x(puVar1);
    if (iVar6 == 0) {
      (*_DAT_)(1,0x121a9b8,0x120baa8,0xd67,0);
    }
  }
  else if (((int)uVar2 < 0) || ((int)(*(ushort *)(lVar3 + 0x2c) & 0x7ff) <= (int)uVar2)) {
    (*_DAT_)(1,0x121a988,0x121a9d0,0x3c6,0);
  }
  else {
    uVar5 = *(ushort *)(lVar3 + 0x2c);
    lVar15 = *(longlong *)(lVar3 + 8) + (ulonglong)*(ushort *)(lVar3 + 0x2a);
    if ((uVar5 & 0x3800) == 0) {
      uVar14 = (uint)(*(ushort *)(lVar15 + 2) >> 0xb & 7);
    }
    else if ((uVar5 >> 0xb & 7) != 0) {
      do {
        if (((lVar8 == 0) || ((int)(*(ushort *)(lVar15 + 2 + lVar8 * 2) & 0x7ff) <= (int)uVar2)) &&
           (uVar10 = *(ushort *)(lVar15 + 4 + lVar8 * 2), (int)uVar2 <= (int)((uVar10 & 0x7ff) - 1))
           ) {
          uVar14 = (uint)(uVar10 >> 0xb & 7);
          break;
        }
        lVar8 = lVar8 + 1;
      } while (lVar8 < (longlong)(ulonglong)(uVar5 >> 0xb & 7));
    }
    iStackX_8 = (uint)*(ushort *)
                       ((ulonglong)((uVar5 >> 0xb & 7) * 2) + *(longlong *)(lVar3 + 8) +
                        (longlong)(int)uVar2 * 2 + 4 + (ulonglong)*(ushort *)(lVar3 + 0x2a)) +
                uVar14 * 0x10000;
  }
  lVar8 = func_0x(**(undefined8 **)(*(longlong *)(*param_1 + 8) + 0x160),iStackX_8);
  *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + 1;
  param_1[3] = lVar8;
  return 1;
}

