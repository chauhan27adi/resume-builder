
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined4 *param_1)

{
  bool bVar1;
  longlong lVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  char cVar7;
  int iVar8;
  longlong lVar9;
  longlong *plVar10;
  char *pcVar11;
  longlong unaff_GS_OFFSET;
  undefined auStack_308 [32];
  undefined8 uStack_2e8;
  undefined8 uStack_2e0;
  uint uStack_2d8;
  undefined8 uStack_2d0;
  ulonglong uStack_2c8;
  int aiStack_2b8 [2];
  longlong lStack_2b0;
  undefined8 uStack_2a8;
  undefined4 uStack_2a0;
  undefined auStack_298 [16];
  undefined8 uStack_288;
  undefined4 uStack_278;
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined8 uStack_268;
  undefined2 uStack_260;
  undefined8 uStack_258;
  int iStack_250;
  undefined auStack_248 [16];
  undefined auStack_238 [16];
  undefined auStack_228 [16];
  undefined auStack_218 [16];
  undefined8 uStack_208;
  undefined4 uStack_200;
  undefined8 uStack_1f8;
  undefined8 uStack_1f0;
  undefined2 auStack_1e8 [2];
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined auStack_d8 [144];
  ulonglong uStack_48;
  
  uStack_288 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_308;
  uStack_2a8 = 0;
  uStack_2a0 = 1;
  auStack_298 = ZEXT816(0);
  auStack_1e8[0] = 0;
  uStack_1e4 = _DAT_;
  uStack_1e0 = uRam000000000182366c;
  uStack_1dc = uRam0000000001823670;
  uStack_1d8 = uRam0000000001823674;
  uStack_1d4 = *param_1;
  uStack_1d0 = param_1[1];
  uStack_1cc = param_1[2];
  uStack_1c8 = param_1[3];
  uStack_1c4 = _DAT_;
  uStack_1c0 = uRam000000000182366c;
  uStack_1bc = uRam0000000001823670;
  uStack_1b8 = uRam0000000001823674;
  func_0x(auStack_1e8,0);
  (*_DAT_)(auStack_d8,0x41,0x1a8d560);
  func_0x(auStack_1e8,param_1);
  uStack_2a0 = 1;
  plVar10 = *(longlong **)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x90);
  auStack_298._0_8_ = plVar10;
  cVar7 = (**(code **)(*plVar10 + 0x1d0))();
  if (cVar7 == '\0') {
    uStack_2c8 = uStack_2c8 & 0xffffffff00000000;
    uStack_2d0 = 0;
    uStack_2d8 = uStack_2d8 & 0xffffff00;
    uStack_2e0 = CONCAT44(uStack_2e0._4_4_,2);
    uStack_2e8 = CONCAT44(uStack_2e8._4_4_,1);
    (**(code **)(*(longlong *)auStack_298._0_8_ + 8))(auStack_298._0_8_,0x1a8d5b8,0x2e);
    uStack_2a8 = CONCAT44(uStack_2a8._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_298._0_8_ + 0xe8))
              (auStack_298._0_8_,1,1,(longlong)&uStack_2a8 + 4);
    uStack_2a0 = 1;
    uStack_2a8 = CONCAT44(uStack_2a8._4_4_,4);
  }
  iVar8 = func_0x(*(undefined2 *)((longlong)param_1 + 0x106),0x1a8c870);
  if (iVar8 == 0) {
    uStack_2c8 = 0x1a8c870;
    uStack_2d0 = CONCAT44(uStack_2d0._4_4_,2);
    uStack_2d8 = 0x10;
    uStack_2e0 = CONCAT44(uStack_2e0._4_4_,0x58c3);
    uStack_2e8 = 0;
    func_0x(1,param_1,0,0);
  }
  else {
    uStack_258 = (**(code **)(*(longlong *)auStack_298._0_8_ + 0x1b0))();
    uStack_260 = *(undefined2 *)((longlong)param_1 + 0x106);
    uStack_268 = 0;
    auStack_248 = ZEXT816(0);
    auStack_238 = ZEXT816(0);
    auStack_228 = ZEXT816(0);
    auStack_218 = ZEXT816(0);
    uStack_208 = 0;
    uStack_200 = 0;
    uStack_1f8 = 0;
    uStack_1f0 = 0;
    lStack_2b0 = 0;
    aiStack_2b8[0] = 0;
    iStack_250 = iVar8;
    iVar8 = func_0x(&uStack_268,3,1);
    if (iVar8 == 0) {
      uStack_2c8 = 0x1a8c870;
      uStack_2d0 = CONCAT44(uStack_2d0._4_4_,0xc);
      uStack_2d8 = 0x10;
      uStack_2e0 = CONCAT44(uStack_2e0._4_4_,0x49aa);
      uStack_2e8 = 0;
      func_0x(1,param_1,0);
    }
    else {
      uStack_2e0 = uStack_268;
      uStack_2e8 = uStack_1f8;
      iVar8 = (**(code **)(*(longlong *)auStack_248._8_8_ + 0x18))(auStack_248._8_8_,0,1,0);
      while ((iVar8 == 0 && (*(char *)((longlong)param_1 + 0x229) != '\0'))) {
        bVar1 = false;
        uStack_278 = _DAT_;
        uStack_274 = uRam000000000182366c;
        uStack_270 = uRam0000000001823670;
        uStack_26c = uRam0000000001823674;
        lVar9 = func_0x(&uStack_268,0x1897618,&lStack_2b0,aiStack_2b8);
        if (lVar9 == 0) {
          uStack_2e8 = 0;
          (*_DAT_)(1,0x1c48490,0x1c22650,0x24e);
        }
        lVar2 = lStack_2b0;
        if (lStack_2b0 != 0x10) {
          uStack_2e8 = 0;
          (*_DAT_)(1,0x1c484c0,0x1c22650,0x251);
        }
        iVar8 = aiStack_2b8[0];
        if (aiStack_2b8[0] == 3) {
          uStack_2e8 = 0;
          (*_DAT_)(1,0x1c484a0,0x1c22650,0x253);
        }
        if (lVar9 == 0) {
          uStack_2e8 = 0;
          (*_DAT_)(1,0x1c47c54,0x1c22268,0xbb);
        }
        if (lVar2 != 0x10) {
          uStack_2e8 = 0;
          (*_DAT_)(1,0x1c47c80,0x1c22268,0xbc);
        }
        if (iVar8 == 3) {
          uStack_2e8 = 0;
          (*_DAT_)(1,0x1c47c60,0x1c22268,0xbd);
        }
        func_0x(&uStack_278,lVar9,lVar2);
        uVar6 = uStack_26c;
        uVar5 = uStack_270;
        uVar4 = uStack_274;
        uVar3 = uStack_278;
        plVar10 = (longlong *)
                  func_0x(param_1,*(undefined2 *)((longlong)param_1 + 0x106),&uStack_278);
        if (plVar10 == (longlong *)0x0) {
          uStack_278 = uVar3;
          uStack_274 = uVar4;
          uStack_270 = uVar5;
          uStack_26c = uVar6;
          plVar10 = (longlong *)func_0x(&uStack_268,&uStack_278,param_1,auStack_1e8);
          if (plVar10 != (longlong *)0x0) {
            func_0x(param_1,plVar10);
            bVar1 = true;
            goto LAB_;
          }
        }
        else {
LAB_:
          pcVar11 = (char *)func_0x(&uStack_268,0x18bf590,&lStack_2b0,aiStack_2b8);
          if (pcVar11 == (char *)0x0) {
            uStack_2e8 = 0;
            (*_DAT_)(1,0x1c48490,0x1c22650,0x24e);
          }
          if (lStack_2b0 != 1) {
            uStack_2e8 = 0;
            (*_DAT_)(1,0x1c484c0,0x1c22650,0x251);
          }
          if (aiStack_2b8[0] == 3) {
            uStack_2e8 = 0;
            (*_DAT_)(1,0x1c484a0,0x1c22650,0x253);
          }
          cVar7 = *pcVar11;
          (**(code **)*plVar10)(plVar10,cVar7 != '\0',auStack_1e8);
          if ((cVar7 != '\0') && (bVar1)) {
            (**(code **)(*plVar10 + 0x58))(plVar10);
          }
        }
        uStack_2e0 = uStack_268;
        uStack_2e8 = uStack_1f8;
        iVar8 = (**(code **)(*(longlong *)auStack_248._8_8_ + 0x18))(auStack_248._8_8_,0,1);
      }
    }
    func_0x(&uStack_268);
  }
  func_0x(&uStack_2a8,0);
  if ((int)uStack_2a8 != 0) {
    func_0x(&uStack_2a8,0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_308);
  return;
}

