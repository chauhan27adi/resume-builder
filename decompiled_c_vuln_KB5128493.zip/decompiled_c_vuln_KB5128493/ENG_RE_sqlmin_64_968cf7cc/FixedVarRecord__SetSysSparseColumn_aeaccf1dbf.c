
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ushort *param_1,undefined4 param_2,int param_3,longlong param_4)

{
  byte bVar1;
  int iVar2;
  ulonglong *puVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined4 *puVar6;
  byte *pbVar7;
  byte *pbVar8;
  undefined2 *puVar9;
  ushort uVar10;
  ushort uVar11;
  longlong lVar13;
  ushort *puVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  longlong unaff_GS_OFFSET;
  undefined auStack_188 [32];
  undefined8 uStack_168;
  int iStack_158;
  uint uStack_154;
  int iStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  longlong lStack_140;
  undefined8 uStack_138;
  undefined4 uStack_130;
  undefined2 uStack_12c;
  ulonglong uStack_58;
  ulonglong uVar12;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_188;
  uVar5 = 0;
  iVar2 = 0;
  uStack_138 = 0;
  uStack_148 = 0;
  uStack_130 = 0;
  uStack_12c = 0;
  iStack_158 = param_3;
  uStack_14c = param_2;
  lStack_140 = param_4;
  if (*(int *)(param_1 + 1) == 0) {
    pbVar8 = *(byte **)(param_1 + 3);
    uVar16 = *(uint *)(param_1 + 7);
    uVar12 = (ulonglong)uVar16;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar16;
    bVar1 = *pbVar8;
    pbVar7 = pbVar8;
    if ((bVar1 & 0x10) != 0) {
      uVar16 = uVar16 + 2 + (*(ushort *)(pbVar8 + uVar12) + 7 >> 3);
      uVar12 = (ulonglong)uVar16;
      pbVar7 = *(byte **)(param_1 + 3);
      *(uint *)(param_1 + 9) = uVar16;
      bVar1 = *pbVar8;
    }
    if ((bVar1 & 0x20) == 0) {
      *(int *)(param_1 + 1) = (int)uVar12;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = (int)uVar12;
    }
    else {
      puVar14 = (ushort *)(pbVar8 + uVar12);
      uVar10 = *puVar14;
      param_1[0xd] = uVar10;
      if (uVar10 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar13 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar13 != 0)) &&
           ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
            (*(char *)(lVar13 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            uStack_168 = 0;
            (*_DAT_)(1,0x9ecab8,0xb0c788,0x80f);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar10 = param_1[0xd];
        uVar12 = (ulonglong)*(uint *)(param_1 + 9);
      }
      uVar16 = (int)uVar12 + (uVar10 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar16;
      if (0x1f9e < uVar16) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar13 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar13 != 0 &&
            ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
             (*(char *)(lVar13 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            uStack_168 = 0;
            (*_DAT_)(1,0x9ecab8,0xb0c788,0x816);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar10 = param_1[0xd];
        uVar16 = *(uint *)(param_1 + 0xb);
      }
      uVar12 = (ulonglong)uVar10;
      uVar10 = puVar14[uVar12];
      *(uint *)(param_1 + 1) = uVar10 & 0x7fff;
      if ((uVar10 & 0x7fff) < uVar16) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar13 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar13 != 0)) &&
           ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
            (*(char *)(lVar13 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            uStack_168 = 0;
            (*_DAT_)(1,0x9ecab8,0xb0c788,0x81d);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar12 = (ulonglong)param_1[0xd];
      }
      if ((short)puVar14[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
        do {
          lVar13 = *(longlong *)(param_1 + 3);
          if ((int)uVar12 == 1) {
            uVar16 = *(uint *)(param_1 + 0xb);
            uVar19 = uVar16;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar13 + uVar12 * 2) & 0x7fff) <
                uVar16) goto LAB_;
          }
          else {
            uVar19 = *(uint *)(param_1 + 0xb);
            uVar16 = *(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar13 + -2 + uVar12 * 2) &
                     0x7fff;
            if (uVar19 <= uVar16) goto LAB_;
LAB_:
            func_0x(lVar13,7);
            uVar19 = *(uint *)(param_1 + 0xb);
            lVar13 = *(longlong *)(param_1 + 3);
            uVar12 = (ulonglong)param_1[0xd];
          }
          if ((uVar16 < uVar19) || (*(uint *)(param_1 + 1) < uVar16)) goto LAB_;
          if (*(ushort *)(lVar13 + (ulonglong)uVar16) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = (short)uVar12 - 1;
            param_1[0x14] = (ushort)uVar16;
            lVar13 = (ulonglong)(uVar16 & 0xffff) + *(longlong *)(param_1 + 3);
            uVar10 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(lVar13 + 2) >> 0xe & 1) != 0) {
              uVar10 = *(ushort *)(lVar13 + 2) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar10;
            param_1[0x15] = (uVar10 ^ *(ushort *)(lVar13 + 2)) & 0x7ff ^ uVar10;
            goto LAB_;
          }
          if (*(ushort *)(lVar13 + (ulonglong)uVar16) < 0x400) goto LAB_;
          *param_1 = *param_1 | 1;
          uVar10 = (short)uVar12 - 1;
          uVar12 = (ulonglong)uVar10;
          param_1[0xd] = uVar10;
          if (uVar10 == 0) goto LAB_;
        } while ((short)puVar14[(ulonglong)(uVar10 - 1) + 1] < 0);
        uVar12 = (ulonglong)*(uint *)(param_1 + 1);
        pbVar7 = *(byte **)(param_1 + 3);
      }
      else {
LAB_:
        uVar12 = (ulonglong)*(uint *)(param_1 + 1);
        pbVar7 = *(byte **)(param_1 + 3);
      }
    }
    if ((*pbVar7 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar12;
      *(int *)(param_1 + 1) = (int)uVar12 + 0xe;
      puVar3 = (ulonglong *)func_0x(param_1);
      uVar11 = (ushort)(*puVar3 >> 0x30);
      uVar10 = uVar11;
      if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
        uVar10 = uVar11 & 0xdfff;
        if ((uVar11 >> 0xe & 1) != 0) {
          uVar10 = uVar11 | 0x2000;
        }
      }
      if (uVar10 == 0xfffc) {
        iVar2 = (int)((*puVar3 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar2;
      uVar12 = (ulonglong)*(uint *)(param_1 + 1);
      pbVar7 = *(byte **)(param_1 + 3);
    }
    iVar2 = (int)uVar12;
    if ((*(byte **)(param_1 + 0xe) != (byte *)0x0) && (*(byte **)(param_1 + 0xe) < pbVar7 + uVar12))
    {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar13 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar13 != 0 &&
           (lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0)) &&
          (*(char *)(lVar13 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          uStack_168 = 0;
          (*_DAT_)(1,0x9ecab8,0xb0c788,0x877);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      iVar2 = *(int *)(param_1 + 1);
    }
    if (0x3f3b < iVar2 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar13 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar13 != 0 &&
          ((lVar13 = *(longlong *)(lVar13 + 0x60), lVar13 != 0 &&
           (*(char *)(lVar13 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          uStack_168 = 0;
          (*_DAT_)(1,0x9ecab8,0xb0c788,0x87c);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
    }
  }
LAB_:
  pbVar8 = *(byte **)(param_1 + 3);
  bVar1 = *pbVar8;
  uVar16 = bVar1 >> 6 & 1;
  uStack_154 = uVar16;
  if ((bVar1 >> 6 & 1) != 0) {
    func_0x(param_1,&uStack_138);
    pbVar8 = *(byte **)(param_1 + 3);
    bVar1 = *pbVar8;
  }
  if ((bVar1 & 0x20) == 0) {
    *pbVar8 = bVar1 | 0x20;
    *(undefined2 *)(*(longlong *)(param_1 + 3) + (ulonglong)*(uint *)(param_1 + 9)) = 0;
    pbVar8 = *(byte **)(param_1 + 3);
    *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + 2;
    *(int *)(param_1 + 0xb) = *(int *)(param_1 + 9) + 2;
  }
  uVar19 = *(uint *)(param_1 + 9);
  uVar10 = param_1[0xd];
  uVar12 = (ulonglong)uVar10;
  iVar2 = func_0x(param_1);
  if (iVar2 != 0) {
    uVar12 = (ulonglong)(uVar10 + 1);
  }
  uVar15 = (uint)uVar12;
  if ((param_4 != 0) && ((*(byte *)param_1 & 1) == 0)) {
    lVar13 = *(longlong *)(param_1 + 3);
    puVar14 = (ushort *)(lVar13 + (ulonglong)*(uint *)(param_1 + 9));
    uVar18 = *(uint *)(param_1 + 9) + 2 + uVar15 * 2;
    if (*puVar14 != 0) {
      do {
        uVar17 = (int)uVar5 + 1;
        puVar14[(uVar5 & 0xffff) + 1] =
             puVar14[(uVar5 & 0xffff) + 1] ^
             (puVar14[uVar5 + 1] + 2 ^ puVar14[(uVar5 & 0xffff) + 1]) & 0x7fff;
        uVar5 = (ulonglong)uVar17;
      } while (uVar17 < *puVar14);
      lVar13 = *(longlong *)(param_1 + 3);
    }
    lVar13 = (ulonglong)uVar18 + lVar13;
    func_0x(lVar13 + 2,lVar13,*(int *)(param_1 + 1) - uVar18);
    *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + 2;
    uVar18 = *(int *)(param_1 + 0xb) + 2;
    *(uint *)(param_1 + 0xb) = uVar18;
    if (uVar15 != 0) {
      uVar18 = puVar14[(ulonglong)(uVar15 - 1) + 1] & 0x7fff;
    }
    if (uVar15 < uVar15 + 1) {
      uVar5 = uVar12;
      do {
        uVar4 = uVar5 & 0xffff;
        uVar17 = (int)uVar5 + 1;
        uVar5 = (ulonglong)uVar17;
        puVar14[uVar4 + 1] = (ushort)uVar18 & 0x7fff;
      } while (uVar17 < uVar15 + 1);
    }
    *puVar14 = *puVar14 + 1;
    func_0x(param_1);
    *param_1 = *param_1 | 1;
    *(ushort *)(pbVar8 + uVar12 * 2 + (ulonglong)uVar19 + 2) =
         *(ushort *)(pbVar8 + uVar12 * 2 + (ulonglong)uVar19 + 2) | 0x8000;
  }
  iVar2 = uVar15 + 1;
  lVar13 = (ulonglong)*(uint *)(param_1 + 9) + *(longlong *)(param_1 + 3);
  uVar19 = *(ushort *)(lVar13 + 2 + uVar12 * 2) & 0x7fff;
  iStack_150 = iVar2;
  if (iVar2 == 1) {
    uVar18 = *(uint *)(param_1 + 0xb);
LAB_:
    if (uVar19 < uVar18) goto LAB_;
  }
  else {
    uVar18 = *(ushort *)(lVar13 + uVar12 * 2) & 0x7fff;
    if (*(uint *)(param_1 + 0xb) <= uVar18) goto LAB_;
LAB_:
    func_0x(*(longlong *)(param_1 + 3),7);
  }
  uVar20 = uVar19 - uVar18;
  uVar17 = iStack_158 + 2;
  if (iStack_158 == 0) {
    uVar17 = 0;
  }
  if (uVar17 != uVar20) {
    lVar13 = *(longlong *)(param_1 + 3);
    uVar16 = *(uint *)(param_1 + 1);
    puVar14 = (ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar13);
    if (uVar16 < uVar19) {
      iVar2 = -1;
      func_0x(0x80070216,uVar16,uVar19);
      lVar13 = *(longlong *)(param_1 + 3);
    }
    else {
      iVar2 = uVar16 - uVar19;
    }
    func_0x
              ((longlong)(int)uVar17 + (ulonglong)uVar18 + lVar13,
               (longlong)(int)uVar20 + (ulonglong)uVar18 + lVar13,iVar2);
    if (uVar15 < *puVar14) {
      do {
        uVar5 = uVar12 & 0xffff;
        iVar2 = (int)uVar12;
        uVar16 = iVar2 + 1;
        uVar12 = (ulonglong)uVar16;
        puVar14[uVar5 + 1] =
             puVar14[uVar5 + 1] ^
             ((puVar14[(longlong)iVar2 + 1] - (short)uVar20) + (short)uVar17 ^ puVar14[uVar5 + 1]) &
             0x7fff;
      } while ((int)uVar16 < (int)(uint)*puVar14);
    }
    *(uint *)(param_1 + 1) = *(int *)(param_1 + 1) + (uVar17 - uVar20);
    func_0x(param_1);
    uVar16 = uStack_154;
    iVar2 = iStack_150;
  }
  if (iStack_158 == 0) goto LAB_;
  puVar9 = (undefined2 *)(*(longlong *)(param_1 + 3) + (ulonglong)uVar18);
  if (puVar9 == (undefined2 *)0x0) {
    puVar6 = (undefined4 *)(*_DAT_)();
    *puVar6 = 0x16;
LAB_:
    (*_DAT_)();
  }
  else {
    if (uVar17 < 2) {
      func_0x(puVar9,0);
      puVar6 = (undefined4 *)(*_DAT_)();
      *puVar6 = 0x22;
      goto LAB_;
    }
    *puVar9 = (short)uStack_14c;
  }
  func_0x
            (*(longlong *)(param_1 + 3) + 2 + (ulonglong)uVar18,uVar17 - 2,lStack_140,iStack_158);
LAB_:
  if (uVar17 == 0) {
    func_0x(param_1,iVar2,0);
    if ((**(byte **)(param_1 + 3) & 0x20) != 0) {
      param_1[0xd] = param_1[0xd] + 1;
    }
    *param_1 = *param_1 & 0xfffe;
  }
  if (uVar16 != 0) {
    func_0x(param_1,&uStack_138);
  }
  iVar2 = func_0x(param_1);
  if (iVar2 != 0) {
    func_0x(param_1);
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_188);
  return;
}

