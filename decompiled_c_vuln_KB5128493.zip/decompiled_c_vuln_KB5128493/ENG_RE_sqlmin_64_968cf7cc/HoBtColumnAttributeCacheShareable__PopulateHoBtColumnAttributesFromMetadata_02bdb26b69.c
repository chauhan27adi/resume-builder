
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,longlong param_4)

{
  int iVar1;
  uint uVar2;
  longlong *plVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_348 [32];
  uint *puStack_328;
  undefined4 uStack_318;
  uint uStack_314;
  int iStack_310;
  uint auStack_308 [2];
  undefined8 uStack_300;
  undefined8 uStack_2f8;
  undefined4 uStack_2f0;
  longlong lStack_2e8;
  longlong *plStack_2e0;
  undefined8 uStack_2d8;
  undefined auStack_2c8 [11];
  byte bStack_2bd;
  int aiStack_26c [137];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_348;
  iVar5 = 0;
  uStack_314 = 0;
  uStack_318 = 0;
  auStack_308[0] = 0;
  lStack_2e8 = param_4;
  plStack_2e0 = param_3;
  uStack_2d8 = param_2;
  iVar1 = iVar5;
  while( true ) {
    iStack_310 = iVar1;
    plVar3 = plStack_2e0;
    if (*(int *)(param_1 + 0x10) != -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((auStack_308[0] & 0x10000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    auStack_308[0] = 3;
    uStack_300 = 0;
    uStack_2f8 = 0;
    uStack_2f0 = 0;
    if (lStack_2e8 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar1 = (**(code **)(*plStack_2e0 + 0x28))(plStack_2e0,iVar5 + 1,0xfffe);
    if (iVar1 == -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x18))(plVar3,iVar1);
    uVar2 = (**(code **)(*plVar3 + 0x10))(plVar3);
    (**(code **)(*plVar3 + 0x20))(plVar3,auStack_2c8);
    if ((bStack_2bd & 0x80) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    piVar4 = (int *)func_0x(*(undefined8 *)(param_1 + 8),iVar5);
    puStack_328 = auStack_308;
    func_0x(piVar4,iVar1,uVar2,auStack_2c8);
    if ((*(byte *)((longlong)piVar4 + 0x21) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)((longlong)piVar4 + 0x21) & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(short *)(piVar4 + 10) != 0) {
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 1;
      aiStack_26c[*(ushort *)(piVar4 + 10)] = iVar5;
    }
    if (piVar4[0xb] != 0) break;
    if (piVar4[0xc] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(char *)((longlong)piVar4 + 0x21) < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*piVar4 < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)(piVar4 + 8) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((uVar2 <= uStack_314) || (0x4000000 < uVar2)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar5 = iVar5 + 1;
    uStack_314 = uVar2;
    iVar1 = iStack_310 + 1;
    if ((*(byte *)((longlong)piVar4 + 6) & 0x10) == 0) {
      iVar1 = iStack_310;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

