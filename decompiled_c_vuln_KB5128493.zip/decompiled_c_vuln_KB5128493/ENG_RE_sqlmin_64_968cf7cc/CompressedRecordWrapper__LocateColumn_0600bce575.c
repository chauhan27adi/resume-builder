
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short **param_1,byte *param_2,uint *param_3,int param_4,int param_5,int *param_6,
                 undefined4 *param_7,uint *param_8,undefined4 param_9)

{
  ushort *puVar1;
  short *psVar2;
  longlong *plVar3;
  bool bVar4;
  undefined4 *puVar5;
  int *piVar6;
  short **ppsVar7;
  byte bVar8;
  ushort uVar9;
  int iVar10;
  ulonglong *puVar11;
  uint uVar12;
  code *UNRECOVERED_JUMPTABLE;
  ushort uVar13;
  uint uVar14;
  ulonglong uVar15;
  longlong lVar16;
  int *piVar17;
  ulonglong uVar18;
  ushort *puVar19;
  short sVar20;
  byte *pbVar21;
  uint uVar22;
  longlong unaff_GS_OFFSET;
  undefined auStack_128 [32];
  uint *puStack_108;
  undefined4 uStack_100;
  int *piStack_f8;
  uint uStack_f0;
  int iStack_e8;
  int iStack_e4;
  uint uStack_e0;
  undefined auStack_dc [4];
  undefined4 *puStack_d8;
  int *piStack_d0;
  short **ppsStack_c8;
  ulonglong uStack_50;
  
  uStack_50 = _DAT_ ^ (ulonglong)auStack_128;
  psVar2 = *param_1;
  bVar4 = false;
  uVar9 = 0;
  puVar1 = (ushort *)(psVar2 + 1);
  piStack_d0 = param_6;
  iStack_e8 = 0;
  puStack_d8 = param_7;
  ppsStack_c8 = param_1;
  if (*psVar2 != 0) {
    puStack_108 = &uStack_e0;
    uStack_e0 = 0;
    piVar17 = (int *)func_0x(puVar1,param_3,param_3,&iStack_e8);
    iVar10 = iStack_e8;
    if ((((*psVar2 != 0) && (plVar3 = *(longlong **)(psVar2 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) && (((*(byte *)((longlong)param_3 + 6) & 8) == 0 && ((uStack_e0 & 1) == 0)))
       ) {
      if ((piVar17 == (int *)0x0) || (piVar17 == (int *)0x775b74)) {
        piVar17 = (int *)0x0;
        iStack_e8 = 0;
        iVar10 = iStack_e8;
      }
      else {
        uStack_f0 = uStack_e0;
        piStack_f8 = &iStack_e8;
        uStack_100 = param_9;
        puStack_108 = param_8;
        piVar17 = (int *)func_0x(plVar3,param_3,piVar17,iStack_e8);
        iVar10 = iStack_e8;
      }
    }
    goto LAB_;
  }
  uVar14 = *param_3;
  if ((uVar14 & 0xc0000000) == 0x80000000) {
    iVar10 = func_0x(puVar1);
    if (iVar10 == 0) {
      piVar17 = (int *)0x0;
      iVar10 = iStack_e8;
    }
    else {
      piVar17 = (int *)func_0x(psVar2 + 0x15,param_3,&iStack_e8,auStack_dc);
      iVar10 = iStack_e8;
    }
    goto LAB_;
  }
  if ((param_5 != 0) || ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0)) {
    pbVar21 = *(byte **)(psVar2 + 4);
    if ((*pbVar21 & 0x10) == 0) {
      if ((1 << (*pbVar21 & 0xe) & 0x1105U) == 0) {
        bVar4 = true;
      }
      else {
LAB_:
        uVar9 = ~(*(ushort *)((longlong)param_3 + 6) >> 4) & 1;
      }
LAB_:
      if (param_5 != 0) goto LAB_;
    }
    else {
      uVar22 = *(uint *)(psVar2 + 8);
      if ((int)uVar22 <= (int)uVar14) goto LAB_;
      if ((uint)*(ushort *)(pbVar21 + uVar22) < (uint)*(ushort *)(param_3 + 1)) {
        uVar9 = ~(*(ushort *)((longlong)param_3 + 6) >> 4) & 1;
        bVar4 = false;
        goto LAB_;
      }
      if (param_5 == 0) goto LAB_;
      uVar12 = *(ushort *)(param_3 + 1) - 1;
      bVar4 = true;
      uVar9 = pbVar21[(ulonglong)(uVar12 >> 3) + (ulonglong)uVar22 + 2] >> ((byte)uVar12 & 7) & 1;
LAB_:
      piVar17 = (int *)0x0;
      iVar10 = iStack_e8;
      if (uVar9 != 0) goto LAB_;
    }
    if ((!bVar4) && ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0)) {
      piVar17 = *(int **)(param_3 + 2) + 1;
      iVar10 = **(int **)(param_3 + 2);
      goto LAB_;
    }
  }
LAB_:
  if (-1 < (int)uVar14) {
    uVar9 = *(ushort *)((longlong)param_3 + 6);
    if ((uVar9 & 8) != 0) {
      piVar17 = (int *)0x775b74;
      iStack_e8 = 1;
      iVar10 = iStack_e8;
      if ((*(byte *)(*(longlong *)(psVar2 + 4) + (longlong)(int)uVar14) &
          (byte)(1 << ((byte)uVar9 & 7))) == 0) {
        piVar17 = (int *)0x776198;
      }
      goto LAB_;
    }
    if ((uVar9 & 0x10) != 0) {
      bVar8 = **(byte **)(psVar2 + 4);
      if ((bVar8 & 0x10) == 0) {
        if ((1 << (bVar8 & 0xe) & 0x1105U) != 0) {
LAB_:
          iVar10 = **(int **)(param_3 + 2);
          piVar17 = *(int **)(param_3 + 2) + 1;
          if ((param_4 != 0) && (iVar10 != param_4)) {
            puStack_108 = (uint *)0x0;
            (*_DAT_)(1,0xb9eea8,0xb9d8a8,0x381);
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(psVar2 + 8) <= (int)uVar14) ||
              (*(ushort *)(*(byte **)(psVar2 + 4) + *(uint *)(psVar2 + 8)) <
               *(ushort *)(param_3 + 1))) goto LAB_;
    }
    piVar17 = (int *)((longlong)(int)uVar14 + *(longlong *)(psVar2 + 4));
    iVar10 = param_4;
    goto LAB_;
  }
  if (*(int *)(psVar2 + 2) == 0) {
    pbVar21 = *(byte **)(psVar2 + 4);
    uVar14 = *(uint *)(psVar2 + 8);
    uVar15 = (ulonglong)uVar14;
    *puVar1 = 0;
    *(uint *)(psVar2 + 10) = uVar14;
    bVar8 = *pbVar21;
    if ((bVar8 & 0x10) != 0) {
      uVar14 = uVar14 + 2 + (*(ushort *)(pbVar21 + uVar15) + 7 >> 3);
      uVar15 = (ulonglong)uVar14;
      *(uint *)(psVar2 + 10) = uVar14;
      bVar8 = *pbVar21;
    }
    if ((bVar8 & 0x20) == 0) {
      *(int *)(psVar2 + 2) = (int)uVar15;
      psVar2[0xe] = 0;
      *(int *)(psVar2 + 0xc) = (int)uVar15;
    }
    else {
      puVar19 = (ushort *)(pbVar21 + uVar15);
      uVar9 = *puVar19;
      psVar2[0xe] = uVar9;
      if (uVar9 == 0) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar16 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar16 != 0)) &&
           ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
            (*(char *)(lVar16 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            puStack_108 = (uint *)0x0;
            (*_DAT_)(1,0x9f1138,0xb10e08,0x80f);
          }
        }
        func_0x(*(undefined8 *)(psVar2 + 4),3);
        uVar9 = psVar2[0xe];
        uVar15 = (ulonglong)*(uint *)(psVar2 + 10);
      }
      uVar14 = (int)uVar15 + (uVar9 + 1) * 2;
      *(uint *)(psVar2 + 0xc) = uVar14;
      if (0x1f9e < uVar14) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar16 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar16 != 0 &&
            ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
             (*(char *)(lVar16 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puStack_108 = (uint *)0x0;
            (*_DAT_)(1,0x9f1138,0xb10e08,0x816);
          }
        }
        func_0x(*(undefined8 *)(psVar2 + 4),4);
        uVar9 = psVar2[0xe];
        uVar14 = *(uint *)(psVar2 + 0xc);
      }
      uVar15 = (ulonglong)uVar9;
      uVar9 = puVar19[uVar15];
      *(uint *)(psVar2 + 2) = uVar9 & 0x7fff;
      if ((uVar9 & 0x7fff) < uVar14) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar16 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar16 != 0)) &&
           ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
            (*(char *)(lVar16 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puStack_108 = (uint *)0x0;
            (*_DAT_)(1,0x9f1138,0xb10e08,0x81d);
          }
        }
        func_0x(*(undefined8 *)(psVar2 + 4),4);
        uVar15 = (ulonglong)(ushort)psVar2[0xe];
      }
      if ((short)puVar19[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
        pbVar21 = *(byte **)(psVar2 + 4);
        do {
          if ((int)uVar15 == 1) {
            uVar14 = *(uint *)(psVar2 + 0xc);
            uVar18 = (ulonglong)uVar14;
LAB_:
            if ((*(ushort *)(pbVar21 + uVar15 * 2 + (ulonglong)*(uint *)(psVar2 + 10)) & 0x7fff) <
                (uint)uVar18) goto LAB_;
          }
          else {
            uVar14 = *(uint *)(psVar2 + 0xc);
            uVar18 = (ulonglong)
                     (*(ushort *)(pbVar21 + uVar15 * 2 + ((ulonglong)*(uint *)(psVar2 + 10) - 2)) &
                     0x7fff);
            if (uVar14 <= (*(ushort *)
                            (pbVar21 + uVar15 * 2 + ((ulonglong)*(uint *)(psVar2 + 10) - 2)) &
                          0x7fff)) goto LAB_;
LAB_:
            func_0x(pbVar21,7);
            uVar14 = *(uint *)(psVar2 + 0xc);
          }
          if (((uint)uVar18 < uVar14) || (*(uint *)(psVar2 + 2) < (uint)uVar18)) goto LAB_;
          pbVar21 = *(byte **)(psVar2 + 4);
          if (*(ushort *)(pbVar21 + uVar18) == 5) {
            *puVar1 = *puVar1 | 2;
            psVar2[0xe] = psVar2[0xe] + -1;
            psVar2[0x15] = (short)uVar18;
            lVar16 = (uVar18 & 0xffff) + *(longlong *)(psVar2 + 4);
            uVar9 = psVar2[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar16 + 2) >> 0xe & 1) != 0) {
              uVar9 = *(ushort *)(lVar16 + 2) & 0x3800 | psVar2[0x16] & 0xc7ffU;
            }
            psVar2[0x16] = uVar9;
            psVar2[0x16] = (uVar9 ^ *(ushort *)(lVar16 + 2)) & 0x7ff ^ uVar9;
            goto LAB_;
          }
          if (*(ushort *)(pbVar21 + uVar18) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar9 = psVar2[0xe] - 1;
          psVar2[0xe] = uVar9;
          if (uVar9 == 0) goto LAB_;
          uVar15 = (ulonglong)uVar9;
        } while ((short)puVar19[(ulonglong)(uVar9 - 1) + 1] < 0);
        uVar15 = (ulonglong)*(uint *)(psVar2 + 2);
      }
      else {
LAB_:
        uVar15 = (ulonglong)*(uint *)(psVar2 + 2);
        pbVar21 = *(byte **)(psVar2 + 4);
      }
    }
    if ((*pbVar21 & 0x40) == 0) {
      *(undefined4 *)(psVar2 + 0x13) = 0;
    }
    else {
      *(int *)(psVar2 + 0x13) = (int)uVar15;
      *(int *)(psVar2 + 2) = (int)uVar15 + 0xe;
      puVar11 = (ulonglong *)func_0x(puVar1);
      iVar10 = 0;
      uVar13 = (ushort)(*puVar11 >> 0x30);
      uVar9 = uVar13;
      if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
        uVar9 = uVar13 & 0xdfff;
        if ((uVar13 >> 0xe & 1) != 0) {
          uVar9 = uVar13 | 0x2000;
        }
      }
      if (uVar9 == 0xfffc) {
        iVar10 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(psVar2 + 2) = *(int *)(psVar2 + 2) + iVar10;
      uVar15 = (ulonglong)*(uint *)(psVar2 + 2);
    }
    iVar10 = (int)uVar15;
    if ((*(ulonglong *)(psVar2 + 0xf) != 0) &&
       (*(ulonglong *)(psVar2 + 0xf) < uVar15 + *(longlong *)(psVar2 + 4))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar16 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar16 != 0 &&
           (lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0)) &&
          (*(char *)(lVar16 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          puStack_108 = (uint *)0x0;
          (*_DAT_)(1,0x9f1138,0xb10e08,0x877);
        }
      }
      func_0x(*(undefined8 *)(psVar2 + 4),0x12);
      iVar10 = *(int *)(psVar2 + 2);
    }
    if (0x3f3b < iVar10 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar16 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar16 != 0 &&
          ((lVar16 = *(longlong *)(lVar16 + 0x60), lVar16 != 0 &&
           (*(char *)(lVar16 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          puStack_108 = (uint *)0x0;
          (*_DAT_)(1,0x9f1138,0xb10e08,0x87c);
        }
      }
      func_0x(*(undefined8 *)(psVar2 + 4),5);
    }
  }
LAB_:
  sVar20 = -*(short *)param_3;
  if ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0) {
    bVar8 = **(byte **)(psVar2 + 4);
    if ((bVar8 & 0x10) == 0) {
      if ((1 << (bVar8 & 0xe) & 0x1105U) != 0) {
LAB_:
        piVar17 = *(int **)(param_3 + 2) + 1;
        iVar10 = **(int **)(param_3 + 2);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(psVar2 + 8) <= (int)*param_3) ||
            (*(ushort *)(*(byte **)(psVar2 + 4) + *(uint *)(psVar2 + 8)) < *(ushort *)(param_3 + 1))
            ) goto LAB_;
  }
  piVar17 = *(int **)(psVar2 + 4);
  lVar16 = (longlong)sVar20;
  iVar10 = iStack_e8;
  if ((uint)(ushort)psVar2[0xe] < (uint)(int)sVar20) goto LAB_;
  uVar14 = *(uint *)(psVar2 + 10);
  if (sVar20 == 1) {
    uVar22 = *(uint *)(psVar2 + 0xc);
    uVar14 = *(ushort *)((longlong)piVar17 + lVar16 * 2 + (ulonglong)uVar14) & 0x7fff;
LAB_:
    if (uVar14 < uVar22) goto LAB_;
  }
  else {
    puVar1 = (ushort *)((longlong)piVar17 + lVar16 * 2 + (ulonglong)uVar14);
    uVar22 = *(ushort *)((longlong)piVar17 + lVar16 * 2 + ((ulonglong)uVar14 - 2)) & 0x7fff;
    piVar17 = *(int **)(psVar2 + 4);
    uVar14 = *puVar1 & 0x7fff;
    if (*(uint *)(psVar2 + 0xc) <= uVar22) goto LAB_;
LAB_:
    func_0x(piVar17,7);
  }
  piVar17 = (int *)((ulonglong)uVar22 + *(longlong *)(psVar2 + 4));
  iVar10 = uVar14 - uVar22;
LAB_:
  iStack_e8 = iVar10;
  ppsVar7 = ppsStack_c8;
  piVar6 = piStack_d0;
  puVar5 = puStack_d8;
  *puStack_d8 = 0;
  *piStack_d0 = iStack_e8;
  if ((piVar17 != (int *)0x0) &&
     (iVar10 = func_0x(*ppsStack_c8,param_2,param_3), iVar10 != 0)) {
    iStack_e4 = *(int *)(ppsVar7 + 2);
    if (*param_2 - 0x30 < 0xc0) {
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*param_2 - 0x30) + 0x10118c) * 4
                             + 0x101158) - 0x1d4c210);
                    /* WARNING: Could not emulate address calculation at 0x00100a78 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,ppsVar7[1]);
      return;
    }
    *piVar6 = iStack_e4;
    *puVar5 = 1;
  }
  func_0x(uStack_50 ^ (ulonglong)auStack_128);
  return;
}

