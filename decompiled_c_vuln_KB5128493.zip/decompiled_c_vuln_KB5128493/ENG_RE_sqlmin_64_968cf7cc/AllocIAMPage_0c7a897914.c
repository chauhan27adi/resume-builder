
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x0117fc8c) */
/* WARNING: Removing unreachable block (ram,0x00065c2d) */
/* WARNING: Removing unreachable block (ram,0x000a0d51) */

undefined8
FUN_(ulonglong param_1,undefined8 param_2,uint param_3,uint param_4,short param_5,
            undefined8 param_6,undefined8 param_7,int param_8,int *param_9,undefined8 param_10,
            longlong *param_11,undefined8 param_12)

{
  longlong lVar1;
  int *piVar2;
  longlong *plVar3;
  int iVar4;
  int iStackX_8;
  undefined2 uStackX_c;
  undefined8 uStackX_10;
  undefined4 uStackX_18;
  ulonglong uVar5;
  undefined4 *puVar6;
  uint auStack_68 [2];
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  
  plVar3 = param_11;
  piVar2 = param_9;
  uStack_50 = 0xfffffffffffffffe;
  iStackX_8 = 0;
  uStackX_c = 0;
  uStackX_18 = 0;
  uStack_60 = 0;
  uStack_58 = 0;
  if (*(short *)(param_9 + 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((param_3 & 8) == 0) && (param_4 != 2)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  auStack_68[0] = (uint)((param_3 & 2) == 0);
  lVar1 = *(longlong *)(param_1 + 0x30);
  if (param_5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_9 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(short *)(lVar1 + 0x6b8) == 2) && (param_5 != 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_11 != (longlong *)0x0) && (*param_11 != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar6 = &param_8;
  uVar5 = (ulonglong)param_4;
  uStackX_10 = param_2;
  iVar4 = func_0x(auStack_68,0x2d6d6a0,param_7,param_1,param_3,uVar5,param_5,&iStackX_8,0x10
                          ,puVar6);
  if (iVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_4 != 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(short *)(lVar1 + 0x6b8) != 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_8 != iStackX_8) {
    param_11._0_4_ = 0;
    param_11._4_2_ = 0;
    func_0x
              (param_12,param_6,2,0,param_1,uVar5,10,&param_8,0,
               (ulonglong)puVar6 & 0xffffffffffffff00,0x5a,0,uStackX_18,&iStackX_8,&param_11,piVar2,
               0);
    func_0x(param_12,2,0xffffffff,0,param_1 & 0xffffffff00000000,0,1);
    if ((plVar3 != (longlong *)0x0) && (*plVar3 != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    return 1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

