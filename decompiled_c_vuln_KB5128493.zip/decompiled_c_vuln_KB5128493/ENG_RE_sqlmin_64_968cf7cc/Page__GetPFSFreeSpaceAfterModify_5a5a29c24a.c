
void FUN_(longlong param_1)

{
  code *UNRECOVERED_JUMPTABLE;
  byte *pbVar1;
  int in_stack_00000028;
  
  pbVar1 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)in_stack_00000028) * 2) +
                   param_1);
  if ((*pbVar1 & 1) != 0) {
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x100970) * 4 +
                           0x100960) - 0x1428170);
                    /* WARNING: Could not emulate address calculation at 0x0010008a */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
                    /* WARNING: Could not emulate address calculation at 0x00100234 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x100990) - 0x1428170))();
  return;
}

