
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong *param_3,int *param_4)

{
  undefined4 uVar1;
  code *pcVar2;
  short *psVar3;
  undefined8 uVar4;
  longlong *plVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  uint uVar9;
  longlong lVar10;
  ulonglong *puVar11;
  longlong lVar12;
  byte bVar13;
  undefined uVar14;
  ulonglong uVar15;
  byte bVar16;
  byte *pbVar17;
  undefined *puVar18;
  ulonglong uVar19;
  ushort *puVar20;
  uint uVar21;
  short sVar22;
  uint uVar23;
  longlong lVar24;
  uint *puVar25;
  uint *puVar26;
  longlong unaff_GS_OFFSET;
  undefined auStack_b88 [64];
  uint uStack_b48;
  uint uStack_b44;
  undefined4 uStack_b40;
  uint uStack_b3c;
  uint uStack_b38;
  uint uStack_b34;
  longlong *plStack_b30;
  int *piStack_b28;
  uint auStack_b20 [2];
  undefined auStack_b18 [8];
  longlong lStack_b10;
  uint auStack_b08 [4];
  uint auStack_af8 [16];
  uint auStack_ab8 [664];
  ulonglong uStack_58;
  
  puVar18 = auStack_b88;
  uStack_58 = _DAT_ ^ (ulonglong)&uStack_b48;
  uVar23 = 0;
  uStack_b40 = 0;
  lVar10 = *(longlong *)(param_1[3] + 8);
  lStack_b10 = 0;
  plStack_b30 = param_1;
  piStack_b28 = param_4;
  if (*(int *)(lVar10 + 0x100) == 2) {
    if ((*(byte *)(lVar10 + 0x42) & 4) == 0) {
      uVar19 = (ulonglong)*(uint *)(lVar10 + 0xb0);
      if (0x1f9e < *(uint *)(lVar10 + 0xb0)) {
        uVar19 = 0x1f9e;
      }
    }
    else {
      uVar19 = 0x1f9e;
    }
    uStack_b40 = (undefined4)uVar19;
    uVar15 = uVar19 + 0xf;
    if (uVar15 <= uVar19) {
      uVar15 = 0xffffffffffffff0;
    }
    uVar15 = uVar15 & 0xfffffffffffffff0;
    uVar23 = 0;
    func_0x();
    puVar18 = auStack_b88 + -uVar15;
    lStack_b10 = (longlong)&uStack_b48 + -uVar15;
  }
  if ((undefined8 *)param_1[2] != (undefined8 *)0x0) {
    pcVar2 = **(code ***)(undefined8 *)param_1[2];
    *(undefined8 *)(puVar18 + -8) = 0x1000bb;
    lVar10 = (*pcVar2)();
    param_1[1] = lVar10;
    uVar23 = 0;
  }
  psVar3 = (short *)param_1[1];
  if ((*(byte *)(param_2 + 0x14) & 0x10) != 0) {
    uVar23 = *(uint *)(param_2 + 0x10);
  }
  uStack_b44 = uVar23;
  if (param_3 == (longlong *)0x0) {
LAB_:
    *param_4 = 0;
    puVar25 = *(uint **)(param_2 + 8);
    if (uVar23 == 0) goto LAB_;
  }
  else {
    uVar1 = *(undefined4 *)(param_3 + 1);
    lVar10 = *param_3;
    *(undefined8 *)(puVar18 + -8) = 0x1000ee;
    func_0x(lVar10,0,uVar1);
    uVar9 = uStack_b44;
    lVar10 = *(longlong *)(param_2 + 8);
    uVar21 = 0;
    param_4 = piStack_b28;
    if (uVar23 == 0) goto LAB_;
    uVar19 = 0;
    do {
      if ((*(char *)(lVar10 + 0x40) == '\x03') || (*(char *)(lVar10 + 0x40) == '\x04')) {
        *(undefined8 *)(puVar18 + -8) = 0x10011a;
        iVar8 = func_0x(psVar3,lVar10);
        if (iVar8 != 0) {
          pbVar17 = (byte *)((uVar19 >> 3) + *param_3);
          *pbVar17 = *pbVar17 | (byte)(1 << (uVar21 & 7));
        }
      }
      uVar21 = uVar21 + 1;
      uVar19 = uVar19 + 1;
      lVar10 = lVar10 + 0x50;
    } while (uVar21 < uVar9);
    *piStack_b28 = 0;
    puVar25 = *(uint **)(param_2 + 8);
    param_4 = piStack_b28;
    uVar23 = uStack_b44;
  }
  puVar26 = (uint *)0x0;
  uStack_b34 = 0;
  do {
    plVar5 = plStack_b30;
    uVar6 = 0;
    uVar19 = 0x779f08;
    uVar9 = puVar25[0x10];
    if ((uVar9 >> 0xb & 1) != 0) {
      *param_4 = 1;
      uVar9 = (uint)*(byte *)(puVar25 + 0x10);
    }
    uVar7 = 0;
    switch((char)uVar9) {
    case '\0':
      goto code_r0x00101cc3;
    case '\x01':
      if (*psVar3 == 0) {
        pbVar17 = *(byte **)(psVar3 + 4);
        if ((*pbVar17 & 0x10) == 0) {
          if ((1 << (*pbVar17 & 0xe) & 0x1105U) != 0) {
code_r0x0010020c:
            uVar7 = ~(*(ushort *)((longlong)puVar25 + 6) >> 4) & 1;
          }
        }
        else {
          uVar23 = *(uint *)(psVar3 + 8);
          if ((int)*puVar25 < (int)uVar23) {
            if ((uint)*(ushort *)(pbVar17 + uVar23) < (uint)*(ushort *)(puVar25 + 1))
            goto code_r0x0010020c;
            uVar9 = *(ushort *)(puVar25 + 1) - 1;
            uVar7 = pbVar17[(ulonglong)uVar23 + (ulonglong)(uVar9 >> 3) + 2] >> ((byte)uVar9 & 7) &
                    1;
          }
          else {
            uVar7 = ~(*(ushort *)((longlong)puVar25 + 6) >> 4) & 1;
          }
        }
      }
      else {
        uVar6 = *(ushort *)(puVar25 + 1);
        if ((ushort)psVar3[1] < uVar6) {
          uVar7 = ~(*(ushort *)((longlong)puVar25 + 6) >> 4) & 1;
        }
        else {
          bVar16 = *(byte *)((longlong)((int)(uVar6 - 1) / 2) + (ulonglong)(ushort)psVar3[0xc] +
                            *(longlong *)(psVar3 + 4));
          bVar13 = bVar16 >> 4;
          if ((uVar6 & 1) != 0) {
            bVar13 = bVar16 & 0xf;
          }
          uVar7 = (ushort)(bVar13 == 0);
        }
      }
      if (uVar7 == 0) goto code_r0x0010029b;
      puVar26 = (uint *)0x0;
      uStack_b48 = 0;
      uVar23 = uStack_b48;
      break;
    case '\x02':
code_r0x0010029b:
      uVar9 = (uint)*(ushort *)(puVar25 + 0xf);
      if ((*(byte *)((longlong)puVar25 + 6) & 0x10) != 0) {
        bVar16 = **(byte **)(psVar3 + 4);
        if ((bVar16 & 0x10) == 0) {
          if ((1 << (bVar16 & 0xe) & 0x1105U) != 0) {
code_r0x001002ec:
            uVar23 = **(uint **)(puVar25 + 2);
            puVar26 = *(uint **)(puVar25 + 2) + 1;
            if ((uVar9 != 0) && (uVar23 != uVar9)) {
              *(undefined8 *)(puVar18 + 0x20) = 0;
              *(undefined8 *)(puVar18 + -8) = 0x100324;
              (*_DAT_)(1,0xbab798,0xbaa198,0x381);
            }
            break;
          }
        }
        else if (((int)*(uint *)(psVar3 + 8) <= (int)*puVar25) ||
                (*(ushort *)(*(byte **)(psVar3 + 4) + *(uint *)(psVar3 + 8)) <
                 *(ushort *)(puVar25 + 1))) goto code_r0x001002ec;
      }
      puVar26 = (uint *)((longlong)(int)*puVar25 + *(longlong *)(psVar3 + 4));
      uVar23 = uVar9;
      break;
    case '\x03':
      if (*psVar3 == 0) {
        pbVar17 = *(byte **)(psVar3 + 4);
        if ((*pbVar17 & 0x10) == 0) {
          uVar15 = uVar19;
          if ((1 << (*pbVar17 & 0xe) & 0x1105U) != 0) {
code_r0x00100385:
            uVar7 = ~(*(ushort *)((longlong)puVar25 + 6) >> 4) & 1;
            uVar19 = uVar15;
          }
        }
        else {
          uVar15 = (ulonglong)*(uint *)(psVar3 + 8);
          if ((int)*puVar25 < (int)*(uint *)(psVar3 + 8)) {
            if ((uint)*(ushort *)(pbVar17 + uVar15) < (uint)*(ushort *)(puVar25 + 1))
            goto code_r0x00100385;
            uVar23 = *(ushort *)(puVar25 + 1) - 1;
            uVar7 = pbVar17[uVar15 + (ulonglong)(uVar23 >> 3) + 2] >> ((byte)uVar23 & 7) & 1;
            uVar19 = uVar15;
          }
          else {
            uVar7 = ~(*(ushort *)((longlong)puVar25 + 6) >> 4) & 1;
          }
        }
      }
      else {
        uVar6 = *(ushort *)(puVar25 + 1);
        uVar19 = (ulonglong)uVar6;
        if ((ushort)psVar3[1] < uVar6) {
          uVar7 = ~(*(ushort *)((longlong)puVar25 + 6) >> 4) & 1;
        }
        else {
          bVar16 = *(byte *)((longlong)((int)(uVar6 - 1) / 2) + (ulonglong)(ushort)psVar3[0xc] +
                            *(longlong *)(psVar3 + 4));
          uVar19 = (ulonglong)uVar6 & 0xffffffffffffff01;
          bVar13 = bVar16 >> 4;
          if ((uVar6 & 1) != 0) {
            bVar13 = bVar16 & 0xf;
          }
          uVar7 = (ushort)(bVar13 == 0);
        }
      }
      if (uVar7 == 0) goto code_r0x00100414;
      puVar26 = (uint *)0x0;
      uStack_b48 = 0;
      uVar23 = uStack_b48;
      break;
    case '\x04':
code_r0x00100414:
      if (*psVar3 == 0) {
        if (*(int *)(psVar3 + 2) == 0) {
          pbVar17 = *(byte **)(psVar3 + 4);
          uVar23 = *(uint *)(psVar3 + 8);
          uVar19 = (ulonglong)uVar23;
          psVar3[1] = 0;
          *(uint *)(psVar3 + 10) = uVar23;
          bVar16 = *pbVar17;
          if ((bVar16 & 0x10) != 0) {
            uVar23 = uVar23 + 2 + (*(ushort *)(pbVar17 + uVar19) + 7 >> 3);
            uVar19 = (ulonglong)uVar23;
            *(uint *)(psVar3 + 10) = uVar23;
            bVar16 = *pbVar17;
          }
          if ((bVar16 & 0x20) == 0) {
            *(int *)(psVar3 + 2) = (int)uVar19;
            psVar3[0xe] = 0;
            *(int *)(psVar3 + 0xc) = (int)uVar19;
          }
          else {
            puVar20 = (ushort *)(pbVar17 + uVar19);
            uVar6 = *puVar20;
            psVar3[0xe] = uVar6;
            if (uVar6 == 0) {
              if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                 ((lVar10 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam000000000067b888 * 8) + 8 +
                             (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                  ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                   (*(char *)(lVar10 + 0x499) != '\0')))))) {
                if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                  *(undefined8 *)(puVar18 + -8) = 0x1004f6;
                  (*pcRam000000000067b828)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar18 + 0x20) = 0;
                  *(undefined8 *)(puVar18 + -8) = 0x10051c;
                  (*_DAT_)(1,0x9fda28,0xb1d6f8,0x80f);
                }
              }
              uVar4 = *(undefined8 *)(psVar3 + 4);
              *(undefined8 *)(puVar18 + -8) = 0x10052a;
              func_0x(uVar4,3);
              uVar19 = (ulonglong)*(uint *)(psVar3 + 10);
              uVar6 = psVar3[0xe];
            }
            uVar23 = (int)uVar19 + (uVar6 + 1) * 2;
            *(uint *)(psVar3 + 0xc) = uVar23;
            if (0x1f9e < uVar23) {
              if ((((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                  (lVar10 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam000000000067b888 * 8) + 8 +
                             (ulonglong)*puRam000000000067b890), lVar10 != 0)) &&
                 ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                  (*(char *)(lVar10 + 0x499) != '\0')))) {
                if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                  *(undefined8 *)(puVar18 + -8) = 0x1005ca;
                  (*pcRam000000000067b828)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar18 + 0x20) = 0;
                  *(undefined8 *)(puVar18 + -8) = 0x1005f0;
                  (*_DAT_)(1,0x9fda28,0xb1d6f8,0x816);
                }
              }
              uVar4 = *(undefined8 *)(psVar3 + 4);
              *(undefined8 *)(puVar18 + -8) = 0x1005fe;
              func_0x(uVar4,4);
              uVar6 = psVar3[0xe];
              uVar23 = *(uint *)(psVar3 + 0xc);
            }
            uVar19 = (ulonglong)uVar6;
            uVar6 = puVar20[uVar19];
            *(uint *)(psVar3 + 2) = uVar6 & 0x7fff;
            if ((uVar6 & 0x7fff) < uVar23) {
              if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                 ((lVar10 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam000000000067b888 * 8) + 8 +
                             (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                  ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                   (*(char *)(lVar10 + 0x499) != '\0')))))) {
                if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                  *(undefined8 *)(puVar18 + -8) = 0x10069c;
                  (*pcRam000000000067b828)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar18 + 0x20) = 0;
                  *(undefined8 *)(puVar18 + -8) = 0x1006c2;
                  (*_DAT_)(1,0x9fda28,0xb1d6f8,0x81d);
                }
              }
              uVar4 = *(undefined8 *)(psVar3 + 4);
              *(undefined8 *)(puVar18 + -8) = 0x1006d0;
              func_0x(uVar4,4);
              uVar19 = (ulonglong)(ushort)psVar3[0xe];
            }
            if ((short)puVar20[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
              lVar10 = *(longlong *)(psVar3 + 4);
              do {
                if ((int)uVar19 == 1) {
                  uVar23 = *(uint *)(psVar3 + 0xc);
                  uVar9 = uVar23;
code_r0x0010071a:
                  if ((*(ushort *)((ulonglong)*(uint *)(psVar3 + 10) + lVar10 + uVar19 * 2) & 0x7fff
                      ) < uVar23) goto code_r0x00100727;
                }
                else {
                  uVar9 = *(uint *)(psVar3 + 0xc);
                  uVar23 = *(ushort *)((ulonglong)*(uint *)(psVar3 + 10) + lVar10 + -2 + uVar19 * 2)
                           & 0x7fff;
                  if (uVar9 <= uVar23) goto code_r0x0010071a;
code_r0x00100727:
                  *(undefined8 *)(puVar18 + -8) = 0x100734;
                  func_0x(lVar10,7);
                  uVar9 = *(uint *)(psVar3 + 0xc);
                }
                if ((uVar23 < uVar9) || (*(uint *)(psVar3 + 2) < uVar23)) goto code_r0x00100a38;
                lVar10 = *(longlong *)(psVar3 + 4);
                if (*(ushort *)((ulonglong)uVar23 + lVar10) == 5) {
                  psVar3[1] = psVar3[1] | 2;
                  psVar3[0xe] = psVar3[0xe] + -1;
                  uVar7 = psVar3[0x16] & 0xc7ff;
                  psVar3[0x15] = (short)uVar23;
                  lVar10 = (ulonglong)(uVar23 & 0xffff) + *(longlong *)(psVar3 + 4);
                  uVar6 = *(ushort *)(lVar10 + 2);
                  if ((uVar6 >> 0xe & 1) != 0) {
                    uVar7 = uVar6 & 0x3800 | uVar7;
                  }
                  psVar3[0x16] = uVar7;
                  psVar3[0x16] = (uVar7 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar7;
                  goto code_r0x00100809;
                }
                if (*(ushort *)((ulonglong)uVar23 + lVar10) < 0x400) goto code_r0x00100809;
                psVar3[1] = psVar3[1] | 1;
                uVar6 = psVar3[0xe] - 1;
                psVar3[0xe] = uVar6;
                if (uVar6 == 0) goto code_r0x00100809;
                uVar19 = (ulonglong)uVar6;
              } while ((short)puVar20[(ulonglong)(uVar6 - 1) + 1] < 0);
              uVar19 = (ulonglong)*(uint *)(psVar3 + 2);
              pbVar17 = *(byte **)(psVar3 + 4);
            }
            else {
code_r0x00100809:
              uVar19 = (ulonglong)*(uint *)(psVar3 + 2);
              pbVar17 = *(byte **)(psVar3 + 4);
            }
          }
          iVar8 = 0;
          if ((*pbVar17 & 0x40) == 0) {
            *(undefined4 *)(psVar3 + 0x13) = 0;
          }
          else {
            *(int *)(psVar3 + 0x13) = (int)uVar19;
            *(int *)(psVar3 + 2) = (int)uVar19 + 0xe;
            *(undefined8 *)(puVar18 + -8) = 0x10083c;
            puVar11 = (ulonglong *)func_0x(psVar3 + 1);
            uVar6 = (ushort)(*puVar11 >> 0x30);
            if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
              if ((uVar6 >> 0xe & 1) == 0) {
                uVar6 = uVar6 & 0xdfff;
              }
              else {
                uVar6 = uVar6 | 0x2000;
              }
            }
            if (uVar6 == 0xfffc) {
              iVar8 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar3 + 2) = *(int *)(psVar3 + 2) + iVar8;
            uVar19 = (ulonglong)*(uint *)(psVar3 + 2);
          }
          iVar8 = (int)uVar19;
          if ((*(ulonglong *)(psVar3 + 0xf) != 0) &&
             (*(ulonglong *)(psVar3 + 0xf) < uVar19 + *(longlong *)(psVar3 + 4))) {
            if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
               (((lVar10 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam000000000067b888 * 8) + 8 +
                            (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                 (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                *(undefined8 *)(puVar18 + -8) = 0x100931;
                (*pcRam000000000067b828)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar18 + 0x20) = 0;
                *(undefined8 *)(puVar18 + -8) = 0x100957;
                (*_DAT_)(1,0x9fda28,0xb1d6f8,0x877);
              }
            }
            uVar4 = *(undefined8 *)(psVar3 + 4);
            *(undefined8 *)(puVar18 + -8) = 0x100965;
            func_0x(uVar4,0x12);
            iVar8 = *(int *)(psVar3 + 2);
          }
          if (0x3f3b < iVar8 - 1U) {
            if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam000000000067b888 * 8) + 8 +
                           (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                *(undefined8 *)(puVar18 + -8) = 0x1009f2;
                (*pcRam000000000067b828)(0x22,0x44,0x15,0x3ed);
                uVar4 = *(undefined8 *)(psVar3 + 4);
                *(undefined8 *)(puVar18 + -8) = 0x100a00;
                func_0x(uVar4,5);
                goto code_r0x00100a38;
              }
              *(undefined8 *)(puVar18 + 0x20) = 0;
              *(undefined8 *)(puVar18 + -8) = 0x100a26;
              (*_DAT_)(1,0x9fda28,0xb1d6f8,0x87c);
            }
            uVar4 = *(undefined8 *)(psVar3 + 4);
            *(undefined8 *)(puVar18 + -8) = 0x100a34;
            func_0x(uVar4,5);
          }
        }
code_r0x00100a38:
        sVar22 = -*(short *)puVar25;
        if ((*(byte *)((longlong)puVar25 + 6) & 0x10) == 0) {
code_r0x00100a66:
          lVar10 = (longlong)sVar22;
          if ((uint)(ushort)psVar3[0xe] < (uint)(int)sVar22) {
code_r0x00100bba:
            uStack_b48 = 0;
            goto code_r0x00100b8a;
          }
          lVar24 = *(longlong *)(psVar3 + 4);
          lVar12 = (ulonglong)*(uint *)(psVar3 + 10) + lVar24;
          if (sVar22 == 1) {
            uVar23 = *(uint *)(psVar3 + 0xc);
            uVar9 = *(ushort *)(lVar12 + lVar10 * 2) & 0x7fff;
code_r0x00100ae1:
            if (uVar9 < uVar23) goto code_r0x00100ae5;
          }
          else {
            uVar23 = *(ushort *)(lVar12 + -2 + lVar10 * 2) & 0x7fff;
            lVar24 = *(longlong *)(psVar3 + 4);
            uVar9 = *(ushort *)(lVar12 + lVar10 * 2) & 0x7fff;
            if (*(uint *)(psVar3 + 0xc) <= uVar23) goto code_r0x00100ae1;
code_r0x00100ae5:
            *(undefined8 *)(puVar18 + -8) = 0x100af2;
            func_0x(lVar24,7);
          }
          uStack_b48 = uVar9 - uVar23;
          puVar26 = (uint *)((ulonglong)uVar23 + *(longlong *)(psVar3 + 4));
        }
        else {
          bVar16 = **(byte **)(psVar3 + 4);
          if ((bVar16 & 0x10) == 0) {
            if ((1 << (bVar16 & 0xe) & 0x1105U) == 0) goto code_r0x00100a66;
          }
          else if (((int)*puVar25 < (int)*(uint *)(psVar3 + 8)) &&
                  (*(ushort *)(puVar25 + 1) <=
                   *(ushort *)(*(byte **)(psVar3 + 4) + *(uint *)(psVar3 + 8))))
          goto code_r0x00100a66;
          uStack_b48 = **(uint **)(puVar25 + 2);
          puVar26 = *(uint **)(puVar25 + 2) + 1;
        }
      }
      else {
        uStack_b3c = 0;
        *(uint **)(puVar18 + 0x20) = &uStack_b3c;
        *(undefined8 *)(puVar18 + -8) = 0x100b1f;
        puVar26 = (uint *)func_0x(psVar3 + 1,puVar25,uVar19,&uStack_b48);
        uVar23 = uStack_b48;
        if ((((*psVar3 != 0) && (plVar5 = *(longlong **)(psVar3 + 8), plVar5 != (longlong *)0x0)) &&
            (*plVar5 != 0)) &&
           (((*(byte *)((longlong)puVar25 + 6) & 8) == 0 && ((uStack_b3c & 1) == 0)))) {
          if ((puVar26 == (uint *)0x0) || (puVar26 == (uint *)0x782464)) goto code_r0x00100bba;
          *(uint *)(puVar18 + 0x38) = uStack_b3c;
          *(uint **)(puVar18 + 0x30) = &uStack_b48;
          *(undefined4 *)(puVar18 + 0x28) = uStack_b40;
          *(longlong *)(puVar18 + 0x20) = lStack_b10;
          *(undefined8 *)(puVar18 + -8) = 0x100b82;
          puVar26 = (uint *)func_0x(plVar5,puVar25,puVar26,uVar23);
        }
        if (puVar26 == (uint *)0x0) {
code_r0x00100b8a:
          puVar26 = *(uint **)(psVar3 + 4);
        }
      }
      uVar23 = uStack_b48;
      if ((uStack_b48 == 0) && ((puVar25[0x10] & 0x2000) != 0)) {
        uStack_b48 = 4;
        puVar26 = (uint *)0x7e8a7c;
        uVar23 = uStack_b48;
      }
      break;
    case '\x05':
      puVar26 = *(uint **)(psVar3 + 4);
      if (*psVar3 == 0) {
        if (*(int *)(psVar3 + 2) == 0) {
          pbVar17 = *(byte **)(psVar3 + 4);
          uVar23 = *(uint *)(psVar3 + 8);
          uVar19 = (ulonglong)uVar23;
          psVar3[1] = 0;
          *(uint *)(psVar3 + 10) = uVar23;
          bVar16 = *pbVar17;
          if ((bVar16 & 0x10) != 0) {
            uVar23 = uVar23 + 2 + (*(ushort *)(pbVar17 + uVar19) + 7 >> 3);
            uVar19 = (ulonglong)uVar23;
            *(uint *)(psVar3 + 10) = uVar23;
            bVar16 = *pbVar17;
          }
          if ((bVar16 & 0x20) == 0) {
            *(int *)(psVar3 + 2) = (int)uVar19;
            psVar3[0xe] = 0;
            *(int *)(psVar3 + 0xc) = (int)uVar19;
          }
          else {
            puVar20 = (ushort *)(pbVar17 + uVar19);
            uVar6 = *puVar20;
            psVar3[0xe] = uVar6;
            if (uVar6 == 0) {
              if ((((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                  (lVar10 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam000000000067b888 * 8) + 8 +
                             (ulonglong)*puRam000000000067b890), lVar10 != 0)) &&
                 ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                  (*(char *)(lVar10 + 0x499) != '\0')))) {
                if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                  *(undefined8 *)(puVar18 + -8) = 0x10162d;
                  (*pcRam000000000067b828)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar18 + 0x20) = 0;
                  *(undefined8 *)(puVar18 + -8) = 0x101653;
                  (*_DAT_)(1,0x9fda28,0xb1d6f8,0x80f);
                }
              }
              uVar4 = *(undefined8 *)(psVar3 + 4);
              *(undefined8 *)(puVar18 + -8) = 0x101661;
              func_0x(uVar4,3);
              uVar19 = (ulonglong)*(uint *)(psVar3 + 10);
              uVar6 = psVar3[0xe];
            }
            uVar23 = (int)uVar19 + (uVar6 + 1) * 2;
            *(uint *)(psVar3 + 0xc) = uVar23;
            if (0x1f9e < uVar23) {
              if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                 ((lVar10 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam000000000067b888 * 8) + 8 +
                             (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                  ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                   (*(char *)(lVar10 + 0x499) != '\0')))))) {
                if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                  *(undefined8 *)(puVar18 + -8) = 0x101701;
                  (*pcRam000000000067b828)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar18 + 0x20) = 0;
                  *(undefined8 *)(puVar18 + -8) = 0x101727;
                  (*_DAT_)(1,0x9fda28,0xb1d6f8,0x816);
                }
              }
              uVar4 = *(undefined8 *)(psVar3 + 4);
              *(undefined8 *)(puVar18 + -8) = 0x101735;
              func_0x(uVar4,4);
              uVar6 = psVar3[0xe];
              uVar23 = *(uint *)(psVar3 + 0xc);
            }
            uVar19 = (ulonglong)uVar6;
            uVar6 = puVar20[uVar19];
            *(uint *)(psVar3 + 2) = uVar6 & 0x7fff;
            if ((uVar6 & 0x7fff) < uVar23) {
              if ((((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                  (lVar10 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*puRam000000000067b888 * 8) + 8 +
                             (ulonglong)*puRam000000000067b890), lVar10 != 0)) &&
                 ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                  (*(char *)(lVar10 + 0x499) != '\0')))) {
                if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                  *(undefined8 *)(puVar18 + -8) = 0x1017d3;
                  (*pcRam000000000067b828)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar18 + 0x20) = 0;
                  *(undefined8 *)(puVar18 + -8) = 0x1017f9;
                  (*_DAT_)(1,0x9fda28,0xb1d6f8,0x81d);
                }
              }
              uVar4 = *(undefined8 *)(psVar3 + 4);
              *(undefined8 *)(puVar18 + -8) = 0x101807;
              func_0x(uVar4,4);
              uVar19 = (ulonglong)(ushort)psVar3[0xe];
            }
            if ((short)puVar20[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
              lVar10 = *(longlong *)(psVar3 + 4);
              do {
                if ((int)uVar19 == 1) {
                  uVar23 = *(uint *)(psVar3 + 0xc);
                  uVar15 = (ulonglong)uVar23;
code_r0x0010184b:
                  if ((*(ushort *)((ulonglong)*(uint *)(psVar3 + 10) + lVar10 + uVar19 * 2) & 0x7fff
                      ) < (uint)uVar15) goto code_r0x00101858;
                }
                else {
                  uVar23 = *(uint *)(psVar3 + 0xc);
                  uVar9 = *(ushort *)((ulonglong)*(uint *)(psVar3 + 10) + lVar10 + -2 + uVar19 * 2)
                          & 0x7fff;
                  uVar15 = (ulonglong)uVar9;
                  if (uVar23 <= uVar9) goto code_r0x0010184b;
code_r0x00101858:
                  *(undefined8 *)(puVar18 + -8) = 0x101865;
                  func_0x(lVar10,7);
                  uVar23 = *(uint *)(psVar3 + 0xc);
                }
                if (((uint)uVar15 < uVar23) || (*(uint *)(psVar3 + 2) < (uint)uVar15))
                goto code_r0x00101b57;
                lVar10 = *(longlong *)(psVar3 + 4);
                if (*(ushort *)(uVar15 + lVar10) == 5) {
                  psVar3[1] = psVar3[1] | 2;
                  psVar3[0xe] = psVar3[0xe] + -1;
                  psVar3[0x15] = (short)uVar15;
                  lVar10 = (uVar15 & 0xffff) + lVar10;
                  uVar7 = psVar3[0x16] & 0xc7ff;
                  uVar6 = *(ushort *)(lVar10 + 2);
                  if ((uVar6 >> 0xe & 1) != 0) {
                    uVar7 = uVar6 & 0x3800 | uVar7;
                  }
                  psVar3[0x16] = uVar7;
                  psVar3[0x16] = (uVar7 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar7;
                  goto code_r0x00101939;
                }
                if (*(ushort *)(uVar15 + lVar10) < 0x400) goto code_r0x00101939;
                psVar3[1] = psVar3[1] | 1;
                uVar6 = psVar3[0xe] - 1;
                psVar3[0xe] = uVar6;
                if (uVar6 == 0) goto code_r0x00101939;
                uVar19 = (ulonglong)uVar6;
              } while ((short)puVar20[(ulonglong)(uVar6 - 1) + 1] < 0);
              uVar19 = (ulonglong)*(uint *)(psVar3 + 2);
              pbVar17 = *(byte **)(psVar3 + 4);
            }
            else {
code_r0x00101939:
              uVar19 = (ulonglong)*(uint *)(psVar3 + 2);
              pbVar17 = *(byte **)(psVar3 + 4);
            }
          }
          iVar8 = 0;
          if ((*pbVar17 & 0x40) == 0) {
            *(undefined4 *)(psVar3 + 0x13) = 0;
          }
          else {
            *(int *)(psVar3 + 0x13) = *(int *)(psVar3 + 2);
            *(int *)(psVar3 + 2) = *(int *)(psVar3 + 2) + 0xe;
            *(undefined8 *)(puVar18 + -8) = 0x10196d;
            puVar11 = (ulonglong *)func_0x(psVar3 + 1);
            uVar6 = (ushort)(*puVar11 >> 0x30);
            if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
              if ((uVar6 >> 0xe & 1) == 0) {
                uVar6 = uVar6 & 0xdfff;
              }
              else {
                uVar6 = uVar6 | 0x2000;
              }
            }
            if (uVar6 == 0xfffc) {
              iVar8 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar3 + 2) = *(int *)(psVar3 + 2) + iVar8;
            uVar19 = (ulonglong)*(uint *)(psVar3 + 2);
          }
          iVar8 = (int)uVar19;
          if ((*(ulonglong *)(psVar3 + 0xf) != 0) &&
             (*(ulonglong *)(psVar3 + 0xf) < uVar19 + *(longlong *)(psVar3 + 4))) {
            if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
               (((lVar10 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                              (ulonglong)*puRam000000000067b888 * 8) + 8 +
                            (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                 (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                *(undefined8 *)(puVar18 + -8) = 0x101a62;
                (*pcRam000000000067b828)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar18 + 0x20) = 0;
                *(undefined8 *)(puVar18 + -8) = 0x101a88;
                (*_DAT_)(1,0x9fda28,0xb1d6f8,0x877);
              }
            }
            uVar4 = *(undefined8 *)(psVar3 + 4);
            *(undefined8 *)(puVar18 + -8) = 0x101a96;
            func_0x(uVar4,0x12);
            iVar8 = *(int *)(psVar3 + 2);
          }
          if (0x3f3b < iVar8 - 1U) {
            if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                             (ulonglong)*puRam000000000067b888 * 8) + 8 +
                           (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                *(undefined8 *)(puVar18 + -8) = 0x101b23;
                (*pcRam000000000067b828)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar18 + 0x20) = 0;
                *(undefined8 *)(puVar18 + -8) = 0x101b49;
                (*_DAT_)(1,0x9fda28,0xb1d6f8,0x87c);
              }
            }
            uVar4 = *(undefined8 *)(psVar3 + 4);
            *(undefined8 *)(puVar18 + -8) = 0x101b57;
            func_0x(uVar4,5);
          }
        }
code_r0x00101b57:
        uVar23 = *(uint *)(psVar3 + 2);
        if (uVar23 < 9) {
          bVar16 = **(byte **)(psVar3 + 4) & 0xe;
joined_r0x00101b95:
          if ((bVar16 == 0) || (bVar16 == 0xc)) {
            uVar23 = 9;
          }
        }
      }
      else {
        uVar23 = *(uint *)(psVar3 + 2);
        if (uVar23 == 0) {
          *(undefined8 *)(puVar18 + -8) = 0x101b82;
          func_0x(psVar3 + 1);
          uVar23 = *(uint *)(psVar3 + 2);
        }
        if (uVar23 < 9) {
          bVar16 = **(byte **)(psVar3 + 4) & 0x1c;
          goto joined_r0x00101b95;
        }
      }
      break;
    case '\x06':
      pcVar2 = *(code **)*plStack_b30;
      *(undefined8 *)(puVar18 + -8) = 0x101bc3;
      (*pcVar2)(plVar5,auStack_b08,8,&uStack_b48);
      puVar26 = auStack_b08;
      uVar23 = uStack_b48;
      break;
    case '\a':
      pcVar2 = *(code **)(*plStack_b30 + 8);
      *(undefined8 *)(puVar18 + -8) = 0x101be7;
      (*pcVar2)(plVar5,auStack_af8,0x40,&uStack_b48);
      puVar26 = auStack_af8;
      uVar23 = uStack_b48;
      break;
    case '\b':
      iVar8 = puVar25[0x10] << 0xc;
      if (*psVar3 == 0) {
        uVar9 = *puVar25;
        if ((uVar9 & 0xc0000000) == 0x80000000) {
          *(undefined8 *)(puVar18 + -8) = 0x101486;
          iVar8 = func_0x(psVar3 + 1);
          if (iVar8 != 0) {
            *(undefined8 *)(puVar18 + -8) = 0x1014a2;
            puVar26 = (uint *)func_0x(psVar3 + 0x15,puVar25,&uStack_b48,auStack_b18);
            uVar23 = uStack_b48;
            break;
          }
code_r0x00100c9e:
          uStack_b48 = 0;
          puVar26 = (uint *)0x0;
          uVar23 = uStack_b48;
        }
        else {
          if ((iVar8 < 0) || ((*(byte *)((longlong)puVar25 + 6) & 0x10) != 0)) {
            pbVar17 = *(byte **)(psVar3 + 4);
            if ((*pbVar17 & 0x10) == 0) {
              if ((1 << (*pbVar17 & 0xe) & 0x1105U) != 0) goto code_r0x00100c43;
              uVar7 = uVar6;
              uVar6 = 1;
code_r0x00100c52:
              if (iVar8 < 0) goto code_r0x00100c9a;
            }
            else {
              uVar23 = *(uint *)(psVar3 + 8);
              if ((int)uVar23 <= (int)uVar9) {
code_r0x00100c43:
                uVar7 = ~(*(ushort *)((longlong)puVar25 + 6) >> 4) & 1;
                goto code_r0x00100c52;
              }
              if ((uint)*(ushort *)(pbVar17 + uVar23) < (uint)*(ushort *)(puVar25 + 1))
              goto code_r0x00100c43;
              if (-1 < iVar8) goto code_r0x00100cb0;
              uVar21 = *(ushort *)(puVar25 + 1) - 1;
              uVar6 = 1;
              uVar7 = pbVar17[(ulonglong)uVar23 + (ulonglong)(uVar21 >> 3) + 2] >>
                      ((byte)uVar21 & 7) & 1;
code_r0x00100c9a:
              if (uVar7 != 0) goto code_r0x00100c9e;
            }
            if ((uVar6 == 0) && ((*(byte *)((longlong)puVar25 + 6) & 0x10) != 0)) {
              puVar26 = *(uint **)(puVar25 + 2) + 1;
              uVar23 = **(uint **)(puVar25 + 2);
              break;
            }
          }
code_r0x00100cb0:
          if ((int)uVar9 < 0) {
            if (*(int *)(psVar3 + 2) == 0) {
              pbVar17 = *(byte **)(psVar3 + 4);
              uVar23 = *(uint *)(psVar3 + 8);
              uVar19 = (ulonglong)uVar23;
              psVar3[1] = 0;
              *(uint *)(psVar3 + 10) = uVar23;
              bVar16 = *pbVar17;
              if ((bVar16 & 0x10) != 0) {
                uVar23 = uVar23 + 2 + (*(ushort *)(pbVar17 + uVar19) + 7 >> 3);
                uVar19 = (ulonglong)uVar23;
                *(uint *)(psVar3 + 10) = uVar23;
                bVar16 = *pbVar17;
              }
              if ((bVar16 & 0x20) == 0) {
                *(int *)(psVar3 + 2) = (int)uVar19;
                psVar3[0xe] = 0;
                *(int *)(psVar3 + 0xc) = (int)uVar19;
              }
              else {
                puVar20 = (ushort *)(pbVar17 + uVar19);
                uVar6 = *puVar20;
                psVar3[0xe] = uVar6;
                if (uVar6 == 0) {
                  if ((((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                      (lVar10 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam000000000067b888 * 8) + 8 +
                                 (ulonglong)*puRam000000000067b890), lVar10 != 0)) &&
                     ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                      (*(char *)(lVar10 + 0x499) != '\0')))) {
                    if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                      *(undefined8 *)(puVar18 + -8) = 0x100e61;
                      (*pcRam000000000067b828)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar18 + 0x20) = 0;
                      *(undefined8 *)(puVar18 + -8) = 0x100e87;
                      (*_DAT_)(1,0x9fda28,0xb1d6f8,0x80f);
                    }
                  }
                  uVar4 = *(undefined8 *)(psVar3 + 4);
                  *(undefined8 *)(puVar18 + -8) = 0x100e95;
                  func_0x(uVar4,3);
                  uVar19 = (ulonglong)*(uint *)(psVar3 + 10);
                  uVar6 = psVar3[0xe];
                }
                uVar23 = (int)uVar19 + (uVar6 + 1) * 2;
                *(uint *)(psVar3 + 0xc) = uVar23;
                if (0x1f9e < uVar23) {
                  if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                     ((lVar10 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam000000000067b888 * 8) + 8 +
                                 (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                      ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                       (*(char *)(lVar10 + 0x499) != '\0')))))) {
                    if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                      *(undefined8 *)(puVar18 + -8) = 0x100f35;
                      (*pcRam000000000067b828)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar18 + 0x20) = 0;
                      *(undefined8 *)(puVar18 + -8) = 0x100f5b;
                      (*_DAT_)(1,0x9fda28,0xb1d6f8,0x816);
                    }
                  }
                  uVar4 = *(undefined8 *)(psVar3 + 4);
                  *(undefined8 *)(puVar18 + -8) = 0x100f69;
                  func_0x(uVar4,4);
                  uVar6 = psVar3[0xe];
                  uVar23 = *(uint *)(psVar3 + 0xc);
                }
                uVar19 = (ulonglong)uVar6;
                uVar6 = puVar20[uVar19];
                *(uint *)(psVar3 + 2) = uVar6 & 0x7fff;
                if ((uVar6 & 0x7fff) < uVar23) {
                  if ((((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                      (lVar10 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*puRam000000000067b888 * 8) + 8 +
                                 (ulonglong)*puRam000000000067b890), lVar10 != 0)) &&
                     ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                      (*(char *)(lVar10 + 0x499) != '\0')))) {
                    if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                      *(undefined8 *)(puVar18 + -8) = 0x101007;
                      (*pcRam000000000067b828)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar18 + 0x20) = 0;
                      *(undefined8 *)(puVar18 + -8) = 0x10102d;
                      (*_DAT_)(1,0x9fda28,0xb1d6f8,0x81d);
                    }
                  }
                  uVar4 = *(undefined8 *)(psVar3 + 4);
                  *(undefined8 *)(puVar18 + -8) = 0x10103b;
                  func_0x(uVar4,4);
                  uVar19 = (ulonglong)(ushort)psVar3[0xe];
                }
                if ((short)puVar20[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
                  lVar10 = *(longlong *)(psVar3 + 4);
                  do {
                    if ((int)uVar19 == 1) {
                      uVar23 = *(uint *)(psVar3 + 0xc);
                      uVar9 = uVar23;
code_r0x0010108a:
                      if ((*(ushort *)((ulonglong)*(uint *)(psVar3 + 10) + lVar10 + uVar19 * 2) &
                          0x7fff) < uVar23) goto code_r0x00101097;
                    }
                    else {
                      uVar9 = *(uint *)(psVar3 + 0xc);
                      uVar23 = *(ushort *)
                                ((ulonglong)*(uint *)(psVar3 + 10) + lVar10 + -2 + uVar19 * 2) &
                               0x7fff;
                      if (uVar9 <= uVar23) goto code_r0x0010108a;
code_r0x00101097:
                      *(undefined8 *)(puVar18 + -8) = 0x1010a4;
                      func_0x(lVar10,7);
                      uVar9 = *(uint *)(psVar3 + 0xc);
                    }
                    if ((uVar23 < uVar9) || (*(uint *)(psVar3 + 2) < uVar23)) goto code_r0x001013a6;
                    lVar10 = *(longlong *)(psVar3 + 4);
                    if (*(ushort *)((ulonglong)uVar23 + lVar10) == 5) {
                      psVar3[1] = psVar3[1] | 2;
                      psVar3[0xe] = psVar3[0xe] + -1;
                      uVar7 = psVar3[0x16] & 0xc7ff;
                      psVar3[0x15] = (short)uVar23;
                      lVar10 = (ulonglong)(uVar23 & 0xffff) + *(longlong *)(psVar3 + 4);
                      uVar6 = *(ushort *)(lVar10 + 2);
                      if ((uVar6 >> 0xe & 1) != 0) {
                        uVar7 = uVar6 & 0x3800 | uVar7;
                      }
                      psVar3[0x16] = uVar7;
                      psVar3[0x16] = (uVar7 ^ *(ushort *)(lVar10 + 2)) & 0x7ff ^ uVar7;
                      goto code_r0x00101179;
                    }
                    if (*(ushort *)((ulonglong)uVar23 + lVar10) < 0x400) goto code_r0x00101179;
                    psVar3[1] = psVar3[1] | 1;
                    uVar6 = psVar3[0xe] - 1;
                    psVar3[0xe] = uVar6;
                    if (uVar6 == 0) goto code_r0x00101179;
                    uVar19 = (ulonglong)uVar6;
                  } while ((short)puVar20[(ulonglong)(uVar6 - 1) + 1] < 0);
                  uVar19 = (ulonglong)*(uint *)(psVar3 + 2);
                  pbVar17 = *(byte **)(psVar3 + 4);
                }
                else {
code_r0x00101179:
                  uVar19 = (ulonglong)*(uint *)(psVar3 + 2);
                  pbVar17 = *(byte **)(psVar3 + 4);
                }
              }
              iVar8 = 0;
              if ((*pbVar17 & 0x40) == 0) {
                *(undefined4 *)(psVar3 + 0x13) = 0;
              }
              else {
                *(int *)(psVar3 + 0x13) = *(int *)(psVar3 + 2);
                *(int *)(psVar3 + 2) = *(int *)(psVar3 + 2) + 0xe;
                *(undefined8 *)(puVar18 + -8) = 0x1011ad;
                puVar11 = (ulonglong *)func_0x(psVar3 + 1);
                uVar6 = (ushort)(*puVar11 >> 0x30);
                if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
                  if ((uVar6 >> 0xe & 1) == 0) {
                    uVar6 = uVar6 & 0xdfff;
                  }
                  else {
                    uVar6 = uVar6 | 0x2000;
                  }
                }
                if (uVar6 == 0xfffc) {
                  iVar8 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(psVar3 + 2) = *(int *)(psVar3 + 2) + iVar8;
                uVar19 = (ulonglong)*(uint *)(psVar3 + 2);
              }
              iVar8 = (int)uVar19;
              if ((*(ulonglong *)(psVar3 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar3 + 0xf) < uVar19 + *(longlong *)(psVar3 + 4))) {
                if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                   (((lVar10 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*puRam000000000067b888 * 8) + 8 +
                                (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                     (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
                    (*(char *)(lVar10 + 0x499) != '\0')))) {
                  if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                    *(undefined8 *)(puVar18 + -8) = 0x10129f;
                    (*pcRam000000000067b828)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar18 + 0x20) = 0;
                    *(undefined8 *)(puVar18 + -8) = 0x1012c5;
                    (*_DAT_)(1,0x9fda28,0xb1d6f8,0x877);
                  }
                }
                uVar4 = *(undefined8 *)(psVar3 + 4);
                *(undefined8 *)(puVar18 + -8) = 0x1012d3;
                func_0x(uVar4,0x12);
                iVar8 = *(int *)(psVar3 + 2);
              }
              if (0x3f3b < iVar8 - 1U) {
                if (((cRam000000000110cffb != '\0') || ((bRam000000000111d900 & 1) != 0)) &&
                   ((lVar10 = *(longlong *)
                               (*(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*puRam000000000067b888 * 8) + 8 +
                               (ulonglong)*puRam000000000067b890), lVar10 != 0 &&
                    ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                     (*(char *)(lVar10 + 0x499) != '\0')))))) {
                  if ((cRam000000000110ceeb == '\0') && ((bRam000000000111d900 & 2) == 0)) {
                    *(undefined8 *)(puVar18 + -8) = 0x101360;
                    (*pcRam000000000067b828)(0x22,0x44,0x15,0x3ed);
                    uVar4 = *(undefined8 *)(psVar3 + 4);
                    *(undefined8 *)(puVar18 + -8) = 0x10136e;
                    func_0x(uVar4,5);
                    goto code_r0x001013a6;
                  }
                  *(undefined8 *)(puVar18 + 0x20) = 0;
                  *(undefined8 *)(puVar18 + -8) = 0x101394;
                  (*_DAT_)(1,0x9fda28,0xb1d6f8,0x87c);
                }
                uVar4 = *(undefined8 *)(psVar3 + 4);
                *(undefined8 *)(puVar18 + -8) = 0x1013a2;
                func_0x(uVar4,5);
              }
            }
code_r0x001013a6:
            sVar22 = -*(short *)puVar25;
            if ((*(byte *)((longlong)puVar25 + 6) & 0x10) != 0) {
              bVar16 = **(byte **)(psVar3 + 4);
              if ((bVar16 & 0x10) == 0) {
                if ((1 << (bVar16 & 0xe) & 0x1105U) != 0) {
code_r0x0010141b:
                  puVar26 = *(uint **)(puVar25 + 2) + 1;
                  uVar23 = **(uint **)(puVar25 + 2);
                  break;
                }
              }
              else if (((int)*(uint *)(psVar3 + 8) <= (int)*puVar25) ||
                      (*(ushort *)(*(byte **)(psVar3 + 4) + *(uint *)(psVar3 + 8)) <
                       *(ushort *)(puVar25 + 1))) goto code_r0x0010141b;
            }
            lVar10 = (longlong)sVar22;
            if ((uint)(ushort)psVar3[0xe] < (uint)(int)sVar22) {
              uStack_b48 = 0;
              puVar26 = *(uint **)(psVar3 + 4);
              uVar23 = uStack_b48;
            }
            else {
              lVar24 = *(longlong *)(psVar3 + 4);
              lVar12 = (ulonglong)*(uint *)(psVar3 + 10) + lVar24;
              if (sVar22 == 1) {
                uVar23 = *(uint *)(psVar3 + 0xc);
                uVar9 = *(ushort *)(lVar12 + lVar10 * 2) & 0x7fff;
code_r0x0010144f:
                if (uVar9 < uVar23) goto code_r0x00101453;
              }
              else {
                uVar23 = *(ushort *)(lVar12 + -2 + lVar10 * 2) & 0x7fff;
                lVar24 = *(longlong *)(psVar3 + 4);
                uVar9 = *(ushort *)(lVar12 + lVar10 * 2) & 0x7fff;
                if (*(uint *)(psVar3 + 0xc) <= uVar23) goto code_r0x0010144f;
code_r0x00101453:
                *(undefined8 *)(puVar18 + -8) = 0x101460;
                func_0x(lVar24,7);
              }
              puVar26 = (uint *)((ulonglong)uVar23 + *(longlong *)(psVar3 + 4));
              uVar23 = uVar9 - uVar23;
            }
          }
          else {
            uVar6 = *(ushort *)((longlong)puVar25 + 6);
            if ((uVar6 & 8) == 0) {
              uVar21 = (uint)*(ushort *)(puVar25 + 0xf);
              if ((uVar6 & 0x10) == 0) {
code_r0x00100ceb:
                puVar26 = (uint *)((longlong)(int)*puVar25 + *(longlong *)(psVar3 + 4));
                uVar23 = uVar21;
              }
              else {
                bVar16 = **(byte **)(psVar3 + 4);
                if ((bVar16 & 0x10) == 0) {
                  if ((1 << (bVar16 & 0xe) & 0x1105U) == 0) goto code_r0x00100ceb;
                }
                else if (((int)uVar9 < (int)*(uint *)(psVar3 + 8)) &&
                        (*(ushort *)(puVar25 + 1) <=
                         *(ushort *)(*(byte **)(psVar3 + 4) + *(uint *)(psVar3 + 8))))
                goto code_r0x00100ceb;
                uVar23 = **(uint **)(puVar25 + 2);
                puVar26 = *(uint **)(puVar25 + 2) + 1;
                if ((uVar21 != 0) && (uVar23 != uVar21)) {
                  *(undefined8 *)(puVar18 + 0x20) = 0;
                  *(undefined8 *)(puVar18 + -8) = 0x100d51;
                  (*_DAT_)(1,0xbab798,0xbaa198,0x381);
                }
              }
            }
            else {
              puVar26 = (uint *)0x782464;
              uStack_b48 = 1;
              uVar23 = uStack_b48;
              if ((*(byte *)((longlong)(int)uVar9 + *(longlong *)(psVar3 + 4)) &
                  (byte)(1 << ((byte)uVar6 & 7))) == 0) {
                puVar26 = (uint *)0x782a88;
              }
            }
          }
        }
      }
      else {
        uStack_b38 = 0;
        *(uint **)(puVar18 + 0x20) = &uStack_b38;
        *(undefined8 *)(puVar18 + -8) = 0x1014c6;
        puVar26 = (uint *)func_0x(psVar3 + 1,puVar25,iVar8 >> 0x1f,&uStack_b48);
        uVar23 = uStack_b48;
        if ((((*psVar3 != 0) && (plVar5 = *(longlong **)(psVar3 + 8), plVar5 != (longlong *)0x0)) &&
            (*plVar5 != 0)) &&
           (((*(byte *)((longlong)puVar25 + 6) & 8) == 0 && ((uStack_b38 & 1) == 0)))) {
          if ((puVar26 == (uint *)0x0) || (puVar26 == (uint *)0x782464)) goto code_r0x00100c9e;
          *(uint *)(puVar18 + 0x38) = uStack_b38;
          *(uint **)(puVar18 + 0x30) = &uStack_b48;
          *(undefined4 *)(puVar18 + 0x28) = 0;
          *(undefined8 *)(puVar18 + 0x20) = 0;
          *(undefined8 *)(puVar18 + -8) = 0x101540;
          puVar26 = (uint *)func_0x(plVar5,puVar25,puVar26,uVar23);
          uVar23 = uStack_b48;
        }
      }
      break;
    case '\t':
    case '\n':
      pcVar2 = *(code **)(*plStack_b30 + 0x10);
      *(undefined8 *)(puVar18 + -8) = 0x101bfa;
      auStack_b20[0] = (*pcVar2)(plVar5);
      uStack_b48 = 4;
      puVar26 = auStack_b20;
      uVar23 = uStack_b48;
      break;
    default:
      *(undefined8 *)(puVar18 + 0x20) = 0x779f08;
      *(undefined8 *)(puVar18 + -8) = 0x101c52;
      (*_DAT_)(1,0xb7ed60,0xb85148,0x120);
      uVar23 = uStack_b48;
      break;
    case '\x19':
      pcVar2 = *(code **)(*plStack_b30 + 0x20);
      *(undefined8 *)(puVar18 + -8) = 0x101c25;
      (*pcVar2)(plVar5,auStack_ab8,0xa59,&uStack_b48);
      puVar26 = auStack_ab8;
      uVar23 = uStack_b48;
    }
    uStack_b48 = uVar23;
    uVar9 = puVar25[0x10];
    if ((uVar9 >> 10 & 1) != 0) {
      if ((*(byte *)(*(longlong *)(puVar25 + 0x12) + 0x2a) & 0x10) == 0) {
        lVar10 = *(longlong *)(param_2 + 0x18);
      }
      else {
        lVar10 = *(longlong *)(param_2 + 0x20);
      }
      uVar14 = 0;
      if (puVar26 == (uint *)0x0) {
        uVar14 = 3;
      }
      *(undefined *)(lVar10 + *(longlong *)(puVar25 + 0xc)) = uVar14;
      uVar9 = puVar25[0x10];
    }
    uVar23 = uStack_b44;
    if ((uVar9 >> 9 & 1) != 0) {
      *(uint *)(puVar18 + 0x20) = uStack_b48;
      *(undefined8 *)(puVar18 + -8) = 0x101cab;
      func_0x(param_2);
      uVar23 = uStack_b44;
    }
code_r0x00101cc3:
    puVar25 = puVar25 + 0x14;
    uStack_b34 = uStack_b34 + 1;
    param_4 = piStack_b28;
  } while (uStack_b34 < uVar23);
LAB_:
  if (((longlong *)plStack_b30[2] != (longlong *)0x0) && (*param_4 == 0)) {
    pcVar2 = *(code **)(*(longlong *)plStack_b30[2] + 8);
    *(undefined8 *)(puVar18 + -8) = 0x101cf3;
    (*pcVar2)();
  }
  uVar19 = uStack_58 ^ (ulonglong)&uStack_b48;
  *(undefined8 *)(puVar18 + -8) = 0x101d02;
  func_0x(uVar19);
  return;
}

