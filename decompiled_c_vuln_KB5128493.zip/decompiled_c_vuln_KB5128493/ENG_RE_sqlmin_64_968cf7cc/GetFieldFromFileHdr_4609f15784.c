
/* WARNING: Removing unreachable block (ram,0x00100108) */
/* WARNING: Removing unreachable block (ram,0x00100138) */
/* WARNING: Removing unreachable block (ram,0x00100140) */
/* WARNING: Removing unreachable block (ram,0x0010010d) */
/* WARNING: Removing unreachable block (ram,0x0010014d) */
/* WARNING: Removing unreachable block (ram,0x00100166) */
/* WARNING: Removing unreachable block (ram,0x0010018c) */
/* WARNING: Removing unreachable block (ram,0x00100190) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

byte * FUN_(short *param_1,uint param_2,uint param_3,undefined4 param_4)

{
  ushort *puVar1;
  longlong *plVar2;
  byte bVar3;
  ushort uVar4;
  int iVar5;
  ulonglong *puVar6;
  byte *pbVar7;
  byte *pbVar8;
  ushort uVar9;
  short sVar10;
  uint uVar11;
  ulonglong uVar12;
  uint uVar13;
  longlong lVar14;
  ushort *puVar15;
  longlong unaff_GS_OFFSET;
  undefined auStackX_10 [8];
  uint auStackX_18 [2];
  undefined4 auStackX_20 [2];
  uint uStack_48;
  ushort uStack_44;
  ushort uStack_42;
  longlong lStack_40;
  
  uStack_48 = -param_2;
  uStack_44 = (ushort)param_2;
  uVar13 = uStack_48 & 0xc0000000;
  uStack_42 = uStack_42 & 0xffe0;
  uVar11 = param_2;
  if (uVar13 == 0x80000000) {
    uStack_44 = 0;
    uVar11 = 0;
  }
  lStack_40 = 0;
  puVar1 = (ushort *)(param_1 + 1);
  iVar5 = 0;
  auStackX_20[0] = param_4;
  if (*param_1 != 0) {
    auStackX_18[0] = 0;
    pbVar8 = (byte *)func_0x(puVar1,&uStack_48,uVar13,auStackX_20,auStackX_18);
    pbVar7 = pbVar8;
    if ((((((*param_1 != 0) && (plVar2 = *(longlong **)(param_1 + 8), plVar2 != (longlong *)0x0)) &&
          (*plVar2 != 0)) && (((uStack_42 & 8) == 0 && ((auStackX_18[0] & 1) == 0)))) &&
        (pbVar7 = (byte *)0x0, pbVar8 != (byte *)0x0)) && (pbVar8 != (byte *)0x1183874)) {
      pbVar7 = (byte *)func_0x
                                 (plVar2,&uStack_48,pbVar8,auStackX_20[0],0,0,auStackX_20,
                                  auStackX_18[0]);
      return pbVar7;
    }
    return pbVar7;
  }
  auStackX_18[0] = param_3;
  if (uVar13 == 0x80000000) {
    iVar5 = func_0x(puVar1);
    if (iVar5 != 0) {
      pbVar7 = (byte *)func_0x(param_1 + 0x15,&uStack_48,auStackX_20,auStackX_10);
      return pbVar7;
    }
    return (byte *)0x0;
  }
  pbVar7 = *(byte **)(param_1 + 4);
  if ((*pbVar7 & 0x10) == 0) {
    uVar11 = 1 << (*pbVar7 & 0xe) & 0x1105;
  }
  else {
    uVar13 = *(uint *)(param_1 + 8);
    if ((int)uVar13 <= (int)uStack_48) {
      return (byte *)0x0;
    }
    if ((uint)*(ushort *)(pbVar7 + uVar13) < (uVar11 & 0xffff)) {
      return (byte *)0x0;
    }
    uVar11 = (uVar11 & 0xffff) - 1;
    uVar11 = pbVar7[(ulonglong)uVar13 + (ulonglong)(uVar11 >> 3) + 2] >> ((byte)uVar11 & 7) & 1;
  }
  if (uVar11 != 0) {
    return (byte *)0x0;
  }
  if ((int)param_2 < 1) {
    return pbVar7 + (int)uStack_48;
  }
  if (*(int *)(param_1 + 2) == 0) {
    uVar11 = *(uint *)(param_1 + 8);
    uVar12 = (ulonglong)uVar11;
    *(uint *)(param_1 + 10) = uVar11;
    *puVar1 = 0;
    bVar3 = *pbVar7;
    if ((bVar3 & 0x10) != 0) {
      uVar11 = uVar11 + 2 + (*(ushort *)(pbVar7 + uVar12) + 7 >> 3);
      uVar12 = (ulonglong)uVar11;
      *(uint *)(param_1 + 10) = uVar11;
      bVar3 = *pbVar7;
    }
    if ((bVar3 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar12;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar12;
    }
    else {
      puVar15 = (ushort *)(pbVar7 + uVar12);
      uVar4 = *puVar15;
      param_1[0xe] = uVar4;
      if (uVar4 == 0) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar14 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar14 != 0 &&
            ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
             (*(char *)(lVar14 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x13fee38,0x151eb08,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar12 = (ulonglong)*(uint *)(param_1 + 10);
        uVar4 = param_1[0xe];
      }
      uVar11 = (int)uVar12 + (uVar4 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar11;
      if (0x1f9e < uVar11) {
        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
            (lVar14 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar14 != 0)) &&
           ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
            (*(char *)(lVar14 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x13fee38,0x151eb08,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar4 = param_1[0xe];
        uVar11 = *(uint *)(param_1 + 0xc);
      }
      uVar12 = (ulonglong)uVar4;
      uVar4 = puVar15[uVar12];
      *(uint *)(param_1 + 2) = uVar4 & 0x7fff;
      if ((uVar4 & 0x7fff) < uVar11) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar14 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar14 != 0 &&
            ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
             (*(char *)(lVar14 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x13fee38,0x151eb08,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar12 = (ulonglong)(ushort)param_1[0xe];
      }
      if ((short)puVar15[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
        lVar14 = *(longlong *)(param_1 + 4);
        do {
          if ((int)uVar12 == 1) {
            uVar11 = *(uint *)(param_1 + 0xc);
            uVar13 = uVar11;
LAB_:
            if ((*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar14 + uVar12 * 2) & 0x7fff) <
                uVar11) goto LAB_;
          }
          else {
            uVar13 = *(uint *)(param_1 + 0xc);
            uVar11 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar14 + -2 + uVar12 * 2) &
                     0x7fff;
            if (uVar13 <= uVar11) goto LAB_;
LAB_:
            func_0x(lVar14,7);
            uVar13 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar11 < uVar13) || (*(uint *)(param_1 + 2) < uVar11)) goto LAB_;
          lVar14 = *(longlong *)(param_1 + 4);
          if (*(ushort *)((ulonglong)uVar11 + lVar14) == 5) {
            *puVar1 = *puVar1 | 2;
            param_1[0xe] = param_1[0xe] + -1;
            param_1[0x15] = (short)uVar11;
            lVar14 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(param_1 + 4);
            uVar4 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(lVar14 + 2) >> 0xe & 1) != 0) {
              uVar4 = *(ushort *)(lVar14 + 2) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar4;
            param_1[0x16] = (uVar4 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar4;
            goto LAB_;
          }
          if (*(ushort *)((ulonglong)uVar11 + lVar14) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar4 = param_1[0xe] - 1;
          param_1[0xe] = uVar4;
          if (uVar4 == 0) goto LAB_;
          uVar12 = (ulonglong)uVar4;
        } while ((short)puVar15[(ulonglong)(uVar4 - 1) + 1] < 0);
        uVar12 = (ulonglong)*(uint *)(param_1 + 2);
      }
      else {
LAB_:
        uVar12 = (ulonglong)*(uint *)(param_1 + 2);
      }
    }
    if ((**(byte **)(param_1 + 4) & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = (int)uVar12;
      *(int *)(param_1 + 2) = (int)uVar12 + 0xe;
      puVar6 = (ulonglong *)func_0x(puVar1);
      uVar9 = (ushort)(*puVar6 >> 0x30);
      uVar4 = uVar9;
      if ((((uint)(int)(short)uVar9 >> 1 ^ (int)(short)uVar9) & 0x2000) != 0) {
        uVar4 = uVar9 & 0xdfff;
        if ((uVar9 >> 0xe & 1) != 0) {
          uVar4 = uVar9 | 0x2000;
        }
      }
      if (uVar4 == 0xfffc) {
        iVar5 = (int)((*puVar6 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar5;
      uVar12 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar5 = (int)uVar12;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar12 + *(longlong *)(param_1 + 4))) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         (((lVar14 = *(longlong *)
                      (*(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                      + (ulonglong)*_DAT_), lVar14 != 0 &&
           (lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0)) &&
          (*(char *)(lVar14 + 0x499) != '\0')))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x13fee38,0x151eb08,0x877,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar5 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar5 - 1U) {
      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
         ((lVar14 = *(longlong *)
                     (*(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                     (ulonglong)*_DAT_), lVar14 != 0 &&
          ((lVar14 = *(longlong *)(lVar14 + 0x60), lVar14 != 0 &&
           (*(char *)(lVar14 + 0x499) != '\0')))))) {
        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x13fee38,0x151eb08,0x87c,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar10 = -(short)uStack_48;
  if ((uStack_42 & 0x10) != 0) {
    bVar3 = **(byte **)(param_1 + 4);
    if ((bVar3 & 0x10) == 0) {
      if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
        return (byte *)(lStack_40 + 4);
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_48) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < uStack_44))
    goto LAB_;
  }
  pbVar7 = *(byte **)(param_1 + 4);
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar10) {
    return pbVar7;
  }
  if (sVar10 == 1) {
    uVar11 = *(uint *)(param_1 + 0xc);
    pbVar8 = pbVar7;
LAB_:
    if (uVar11 <= (*(ushort *)(pbVar7 + (longlong)sVar10 * 2 + (ulonglong)*(uint *)(param_1 + 10)) &
                  0x7fff)) goto LAB_;
  }
  else {
    pbVar8 = *(byte **)(param_1 + 4);
    uVar11 = *(ushort *)(pbVar7 + (longlong)sVar10 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
             0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar11) goto LAB_;
  }
  func_0x(pbVar8,7);
  pbVar8 = *(byte **)(param_1 + 4);
LAB_:
  return pbVar8 + uVar11;
}

