
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,undefined4 param_3)

{
  undefined2 uVar1;
  short sVar2;
  undefined auVar3 [16];
  uint uVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  short *psVar10;
  undefined8 uVar11;
  short *psVar12;
  longlong lVar13;
  longlong lVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  int *piVar17;
  ulonglong uVar18;
  longlong lVar19;
  ulonglong uVar20;
  int *piVar21;
  int *piVar22;
  longlong unaff_GS_OFFSET;
  bool bVar23;
  undefined auStack_1d8 [32];
  undefined8 uStack_1b8;
  undefined8 uStack_1b0;
  int iStack_1a8;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  int iStack_168;
  int iStack_164;
  longlong lStack_160;
  int iStack_158;
  int iStack_150;
  int iStack_14c;
  longlong lStack_148;
  undefined4 uStack_140;
  undefined8 uStack_138;
  longlong alStack_128 [12];
  longlong lStack_c8;
  undefined2 uStack_c0;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  longlong lStack_68;
  uint uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_138 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1d8;
  uVar1 = *(undefined2 *)(param_1 + 8);
  piVar21 = (int *)0x0;
  uStack_178 = param_3;
  if ((DAT_ & 8) == 0) {
    iStack_158 = 0;
  }
  else {
    iStack_158 = 1;
    iStack_168 = (*_DAT_)();
    iStack_164 = 0x23;
    lStack_160 = func_0x(uVar1);
  }
  if (*(longlong *)(param_1 + 0x80) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde868,0x1bb8ce0,0xc07);
  }
  if (param_2 == (longlong *)0x0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde9e8,0x1bb8ce0,0xc08);
  }
  if (*(longlong *)(param_1 + 0x70) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde4b0,0x1bb8ce0,0xc09);
  }
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x30) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x170) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x280) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x500) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x710) = 0;
  psVar12 = (short *)(*(longlong *)(param_1 + 0x80) + 0xb80);
  lVar14 = 4;
  lVar19 = 0x1882138 - (longlong)psVar12;
  do {
    if ((lVar14 == -0x7ffffffa) || (sVar2 = *(short *)(lVar19 + (longlong)psVar12), sVar2 == 0))
    break;
    *psVar12 = sVar2;
    psVar12 = psVar12 + 1;
    lVar14 = lVar14 + -1;
  } while (lVar14 != 0);
  psVar10 = psVar12 + -1;
  if (lVar14 != 0) {
    psVar10 = psVar12;
  }
  *psVar10 = 0;
  if (lVar14 == 0) {
    iStack_1a8 = -0x7ff8ff86;
    uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0xc14);
    uStack_1b8 = 0x1a2c5e0;
    (*_DAT_)(4,7,0x10,1);
  }
  uVar5 = func_0x(*(longlong *)(param_1 + 0x80) + 0xb80);
  *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x20) = uVar5;
  uStack_198 = 0;
  piVar17 = piVar21;
  piVar22 = piVar21;
  if (*param_2 == 0) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde2e4,0x1bb8ce0,0xc1b);
  }
  else {
    uVar6 = func_0x(param_2,0x182cd80,&uStack_198);
    uVar18 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 != *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) {
      uVar6 = 1;
      uVar4 = 1;
      if (*(uint *)(param_2 + 0xd) != 0) {
        do {
          uVar6 = uVar4;
          if (uVar18 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) break;
          uVar6 = uVar6 + 1;
          uVar4 = uVar6;
        } while (uVar6 <= *(uint *)(param_2 + 0xd));
      }
    }
    if (*(uint *)(param_2 + 0xd) < uVar6) goto LAB_;
    lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc];
    piVar17 = *(int **)(*param_2 + *(longlong *)(lVar14 + 0x10));
    piVar22 = (int *)(*(longlong *)(lVar14 + 8) + *param_2);
    if (piVar22 == (int *)0x0) goto LAB_;
  }
  func_0x(*(undefined8 *)(param_1 + 0x80),piVar22,piVar17);
  uStack_194 = 0;
  piVar22 = piVar21;
  if (*param_2 == 0) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde2e4,0x1bb8ce0,0xc1f);
  }
  else {
    uVar6 = func_0x(param_2,0x198d1b0,&uStack_194);
    uVar18 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 != *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) {
      uVar6 = 1;
      uVar4 = 1;
      if (*(uint *)(param_2 + 0xd) != 0) {
        do {
          uVar6 = uVar4;
          if (uVar18 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) break;
          uVar6 = uVar6 + 1;
          uVar4 = uVar6;
        } while (uVar6 <= *(uint *)(param_2 + 0xd));
      }
    }
    piVar17 = piVar21;
    if (*(uint *)(param_2 + 0xd) < uVar6) goto LAB_;
    lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc];
    piVar17 = *(int **)(*param_2 + *(longlong *)(lVar14 + 0x10));
    piVar22 = (int *)(*(longlong *)(lVar14 + 8) + *param_2);
    if (piVar22 == (int *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 4,piVar22,piVar17);
  uStack_190 = 0;
  piVar22 = piVar21;
  if (*param_2 == 0) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde2e4,0x1bb8ce0,0xc23);
  }
  else {
    uVar6 = func_0x(param_2,0x17c6198,&uStack_190);
    uVar18 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 != *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) {
      uVar6 = 1;
      uVar4 = 1;
      if (*(uint *)(param_2 + 0xd) != 0) {
        do {
          uVar6 = uVar4;
          if (uVar18 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) break;
          uVar6 = uVar6 + 1;
          uVar4 = uVar6;
        } while (uVar6 <= *(uint *)(param_2 + 0xd));
      }
    }
    piVar17 = piVar21;
    if (*(uint *)(param_2 + 0xd) < uVar6) goto LAB_;
    lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc];
    piVar17 = *(int **)(*param_2 + *(longlong *)(lVar14 + 0x10));
    piVar22 = (int *)(*(longlong *)(lVar14 + 8) + *param_2);
    if (piVar22 == (int *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 8,piVar22,piVar17);
  uStack_18c = 0;
  piVar22 = piVar21;
  if (*param_2 == 0) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde2e4,0x1bb8ce0,0xc27);
  }
  else {
    uVar6 = func_0x(param_2,0x1a271a8,&uStack_18c);
    uVar18 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 != *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) {
      uVar6 = 1;
      uVar4 = 1;
      if (*(uint *)(param_2 + 0xd) != 0) {
        do {
          uVar6 = uVar4;
          if (uVar18 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) break;
          uVar6 = uVar6 + 1;
          uVar4 = uVar6;
        } while (uVar6 <= *(uint *)(param_2 + 0xd));
      }
    }
    piVar17 = piVar21;
    if (*(uint *)(param_2 + 0xd) < uVar6) goto LAB_;
    lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc];
    piVar17 = *(int **)(*param_2 + *(longlong *)(lVar14 + 0x10));
    piVar22 = (int *)(*(longlong *)(lVar14 + 8) + *param_2);
    if (piVar22 == (int *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0xc,piVar22,piVar17);
  uStack_188 = 0;
  piVar22 = piVar21;
  if (*param_2 == 0) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde2e4,0x1bb8ce0,0xc2b);
  }
  else {
    uVar6 = func_0x(param_2,0x17c5230,&uStack_188);
    uVar18 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 != *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) {
      uVar6 = 1;
      uVar4 = 1;
      if (*(uint *)(param_2 + 0xd) != 0) {
        do {
          uVar6 = uVar4;
          if (uVar18 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) break;
          uVar6 = uVar6 + 1;
          uVar4 = uVar6;
        } while (uVar6 <= *(uint *)(param_2 + 0xd));
      }
    }
    piVar17 = piVar21;
    if (*(uint *)(param_2 + 0xd) < uVar6) goto LAB_;
    lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc];
    piVar17 = *(int **)(*param_2 + *(longlong *)(lVar14 + 0x10));
    piVar22 = (int *)(*(longlong *)(lVar14 + 8) + *param_2);
    if (piVar22 == (int *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0x10,piVar22,piVar17);
  uStack_184 = 0;
  piVar22 = piVar21;
  if (*param_2 == 0) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde2e4,0x1bb8ce0,0xc2f);
  }
  else {
    uVar6 = func_0x(param_2,0x17cb3b0,&uStack_184);
    uVar18 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 != *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) {
      uVar6 = 1;
      uVar4 = 1;
      if (*(uint *)(param_2 + 0xd) != 0) {
        do {
          uVar6 = uVar4;
          if (uVar18 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) break;
          uVar6 = uVar6 + 1;
          uVar4 = uVar6;
        } while (uVar6 <= *(uint *)(param_2 + 0xd));
      }
    }
    piVar17 = piVar21;
    if (*(uint *)(param_2 + 0xd) < uVar6) goto LAB_;
    lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc];
    piVar17 = *(int **)(*param_2 + *(longlong *)(lVar14 + 0x10));
    piVar22 = (int *)(*(longlong *)(lVar14 + 8) + *param_2);
    if (piVar22 == (int *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0x11,piVar22,piVar17);
  lVar14 = *(longlong *)(param_1 + 0x80) + 0x30;
  if (lVar14 == 0) {
    uStack_1b8 = 0;
    (*_DAT_)((int)*(longlong *)(param_1 + 0x80) + 0x31,0x1bdea1c,0x1bb8ce0,0xccd);
  }
  uStack_180 = 0;
  if (*param_2 == 0) {
LAB_:
    uVar18 = 0;
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bdea10,0x1bb8ce0,0xc37);
  }
  else {
    uVar6 = func_0x(param_2,0x1a2bf20,&uStack_180);
    uVar18 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 != *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) {
      uVar6 = 1;
      uVar4 = 1;
      if (*(uint *)(param_2 + 0xd) != 0) {
        do {
          uVar6 = uVar4;
          if (uVar18 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) break;
          uVar6 = uVar6 + 1;
          uVar4 = uVar6;
        } while (uVar6 <= *(uint *)(param_2 + 0xd));
      }
    }
    if (*(uint *)(param_2 + 0xd) < uVar6) goto LAB_;
    lVar13 = (ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc];
    lVar19 = *param_2;
    uVar18 = *(ulonglong *)(lVar19 + *(longlong *)(lVar13 + 0x10));
    iVar7 = *(int *)(lVar19 + *(longlong *)(lVar13 + 0x18));
    lVar19 = *(longlong *)(lVar13 + 8) + lVar19;
    if (0x102 < uVar18) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1bdea28,0x1bb8ce0,0xcd6);
    }
    if (((lVar19 == 0) || (uVar18 == 0)) || (iVar7 == 3)) goto LAB_;
    if (uVar18 < 0x103) {
      func_0x(lVar14,lVar19,uVar18);
    }
  }
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x30 + (uVar18 & 0xfffffffffffffffe)) = 0;
  lVar14 = *(longlong *)(param_1 + 0x80) + 0x170;
  if (lVar14 == 0) {
    uStack_1b8 = 0;
    (*_DAT_)((int)*(longlong *)(param_1 + 0x80) + 0x171,0x1bdea1c,0x1bb8ce0,0xccd);
  }
  uStack_17c = 0;
  if (*param_2 == 0) {
LAB_:
    uVar18 = 0;
  }
  else {
    uVar6 = func_0x(param_2,0x1a2bed8,&uStack_17c);
    uVar18 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 != *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) {
      uVar6 = 1;
      uVar4 = 1;
      if (*(uint *)(param_2 + 0xd) != 0) {
        do {
          uVar6 = uVar4;
          if (uVar18 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc])) break;
          uVar6 = uVar6 + 1;
          uVar4 = uVar6;
        } while (uVar6 <= *(uint *)(param_2 + 0xd));
      }
    }
    if (*(uint *)(param_2 + 0xd) < uVar6) goto LAB_;
    lVar13 = (ulonglong)(uVar6 - 1) * 0x58 + param_2[0xc];
    lVar19 = *param_2;
    uVar18 = *(ulonglong *)(lVar19 + *(longlong *)(lVar13 + 0x10));
    iVar7 = *(int *)(lVar19 + *(longlong *)(lVar13 + 0x18));
    lVar19 = *(longlong *)(lVar13 + 8) + lVar19;
    if (0x102 < uVar18) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1bdea28,0x1bb8ce0,0xcd6);
    }
    if (((lVar19 == 0) || (uVar18 == 0)) || (iVar7 == 3)) goto LAB_;
    if (uVar18 < 0x103) {
      func_0x(lVar14,lVar19,uVar18);
    }
  }
  uVar16 = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x170 + (uVar18 & 0xfffffffffffffffe)) = 0;
  if ((*(longlong *)(param_1 + 0x68) != 0) &&
     (piVar21 = *(int **)(*(longlong *)(param_1 + 0x68) + 0x70), piVar21 != (int *)0x0)) {
LAB_:
    if ((piVar21[1] != (*(int **)(param_1 + 0x80))[2]) || (*piVar21 != **(int **)(param_1 + 0x80)))
    goto LAB_;
    uVar6 = piVar21[8];
    uVar11 = (*_DAT_)();
    uStack_1b0 = *(ulonglong *)(piVar21 + 6);
    uStack_1b8 = (ulonglong)(uVar6 >> 1);
    iVar7 = func_0x(*(longlong *)(param_1 + 0x80) + 0x280,0x101,0x18835a0,uVar11);
    if (iVar7 < 0) {
      uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0xc45);
      uStack_1b8 = 0x1a2c5e0;
      iStack_1a8 = iVar7;
      (*_DAT_)(4,7,0x10,1);
    }
    uVar6 = piVar21[0xc];
    uVar11 = (*_DAT_)();
    uStack_1b0 = *(ulonglong *)(piVar21 + 10);
    uStack_1b8 = (ulonglong)(uVar6 >> 1);
    iVar7 = func_0x(*(longlong *)(param_1 + 0x80) + 0x500,0x101,0x18835a0,uVar11);
    if (iVar7 < 0) {
      uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0xc48);
      uStack_1b8 = 0x1a2c5e0;
      iStack_1a8 = iVar7;
      (*_DAT_)(4,7,0x10,1);
    }
    uVar6 = piVar21[0x10];
    uVar11 = (*_DAT_)();
    uStack_1b0 = *(ulonglong *)(piVar21 + 0xe);
    uStack_1b8 = (ulonglong)(uVar6 >> 1);
    iVar7 = func_0x(*(longlong *)(param_1 + 0x80) + 0x710,0x101,0x18835a0,uVar11);
    if (iVar7 < 0) {
      uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0xc4b);
      uStack_1b8 = 0x1a2c5e0;
      iStack_1a8 = iVar7;
      (*_DAT_)(4,7,0x10,1);
    }
    *(int *)(*(longlong *)(param_1 + 0x80) + 0x24) = piVar21[2];
    auVar3 = ZEXT816(4) * ZEXT416(*(uint *)(*(longlong *)(param_1 + 0x80) + 0x24));
    uVar11 = auVar3._0_8_;
    if (auVar3._8_8_ != 0) {
      uVar11 = 0xffffffffffffffff;
    }
    uStack_1b0 = CONCAT71(uStack_1b0._1_7_,6);
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,0xc4e);
    uVar11 = (*_DAT_)(uVar11,_DAT_,1,0x1a2c5e0);
    *(undefined8 *)(*(longlong *)(param_1 + 0x80) + 0x28) = uVar11;
    uStack_1b8 = 0;
    func_0x(*(undefined2 *)(param_1 + 8),0x1f,
                    (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x80) + 0x24) << 2,1);
    lVar14 = *(longlong *)(param_1 + 0x80);
    if (*(longlong *)(lVar14 + 0x28) == 0) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1bde9f8,0x1bb8ce0,0xc4f);
      lVar14 = *(longlong *)(param_1 + 0x80);
    }
    uVar15 = uVar16;
    if (*(int *)(lVar14 + 0x24) != 0) {
      do {
        *(undefined4 *)(uVar15 * 4 + *(longlong *)(lVar14 + 0x28)) =
             *(undefined4 *)(uVar15 * 4 + *(longlong *)(piVar21 + 4));
        uVar6 = (int)uVar15 + 1;
        lVar14 = *(longlong *)(param_1 + 0x80);
        uVar15 = (ulonglong)uVar6;
      } while (uVar6 < *(uint *)(lVar14 + 0x24));
    }
    lVar14 = *(longlong *)(param_1 + 0x68);
    uStack_1b8 = lVar14 + 0x1c;
    uStack_1b0 = CONCAT62(uStack_1b0._2_6_,*(undefined2 *)(lVar14 + 0x80));
    func_0x(param_1,8,lVar14 + 4,lVar14 + 0x10);
  }
LAB_:
  if ((*(longlong *)(param_1 + 0x68) == 0) || (piVar21 == (int *)0x0)) {
    iVar7 = func_0x(*(undefined4 **)(param_1 + 0x80),**(undefined4 **)(param_1 + 0x80),
                            param_2);
    if (iVar7 == 0) {
      uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_1 + 0xc));
      (*_DAT_)(0xbb,0x38,0x10,4);
    }
    else {
      uStack_1b0 = uStack_1b0 & 0xffffffffffff0000;
      uStack_1b8 = 0;
      func_0x(param_1,4,0);
    }
  }
  uVar5 = func_0x(*(longlong *)(param_1 + 0x80) + 0x280);
  *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x14) = uVar5;
  uVar5 = func_0x(*(longlong *)(param_1 + 0x80) + 0x500);
  *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x18) = uVar5;
  uVar5 = func_0x(*(longlong *)(param_1 + 0x80) + 0x710);
  *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x1c) = uVar5;
  func_0x(param_1);
  uStack_b8 = (**(code **)(**(longlong **)
                             (*(longlong *)
                               ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8)) + 0x90) + 0x1b0))();
  uStack_c0 = *(undefined2 *)(param_1 + 8);
  lStack_c8 = 0;
  uStack_b0 = uStack_178;
  auStack_a8 = ZEXT816(0);
  auStack_98 = ZEXT816(0);
  auStack_88 = ZEXT816(0);
  auStack_78 = ZEXT816(0);
  lStack_68 = 0;
  uStack_60 = 0;
  uStack_58 = 0;
  uStack_50 = 0;
  iVar7 = func_0x(&lStack_c8,3,1);
  if (iVar7 == 0) {
    uStack_1b8 = 0x1a26890;
    (*_DAT_)(0xbc,0x3a,0x10,8);
  }
  uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0x10);
  uStack_1b8 = CONCAT44(uStack_1b8._4_4_,4);
  func_0x(&lStack_c8,0x1a271a8,*(longlong *)(param_1 + 0x80) + 0xc,0);
  uStack_1b0 = lStack_c8;
  uStack_1b8 = uStack_58;
  (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1);
  uStack_174 = 0;
  uVar15 = uVar16;
  if (lStack_c8 != 0) {
    uVar6 = func_0x(&lStack_c8,0x1a2bef0,&uStack_174);
    uVar20 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_68)) {
LAB_:
      uVar18 = uVar16;
      if (uVar6 <= uStack_60) {
        lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_68;
        uVar15 = *(longlong *)(lVar14 + 8) + lStack_c8;
        uVar18 = *(ulonglong *)(lStack_c8 + *(longlong *)(lVar14 + 0x10));
      }
    }
    else {
      uVar6 = 1;
      uVar18 = uVar16;
      if (uStack_60 != 0) {
        do {
          if (uVar20 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_68))
          goto LAB_;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uStack_60);
      }
    }
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0xec8,uVar15,uVar18);
  if (*(int *)(*(longlong *)(param_1 + 0x80) + 0xec8) == 0) {
    uStack_170 = 0;
    uVar15 = uVar16;
    if (lStack_c8 != 0) {
      uVar6 = func_0x(&lStack_c8,0x1a2c770,&uStack_170);
      uVar20 = (ulonglong)uVar6;
      if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_68)) {
LAB_:
        uVar18 = uVar16;
        if (uVar6 <= uStack_60) {
          lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_68;
          uVar15 = *(longlong *)(lVar14 + 8) + lStack_c8;
          uVar18 = *(ulonglong *)(lStack_c8 + *(longlong *)(lVar14 + 0x10));
        }
      }
      else {
        uVar6 = 1;
        uVar18 = uVar16;
        if (uStack_60 != 0) {
          do {
            if (uVar20 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_68))
            goto LAB_;
            uVar6 = uVar6 + 1;
          } while (uVar6 <= uStack_60);
        }
      }
    }
    func_0x(*(longlong *)(param_1 + 0x80) + 0xec8,uVar15,uVar18);
  }
  uStack_16c = 0;
  if (lStack_c8 != 0) {
    uVar6 = func_0x(&lStack_c8,0x1982048,&uStack_16c);
    uVar15 = (ulonglong)uVar6;
    if ((ulonglong)uVar6 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_68)) {
LAB_:
      uVar18 = uVar16;
      if (uVar6 <= uStack_60) {
        lVar14 = (ulonglong)(uVar6 - 1) * 0x58 + lStack_68;
        uVar16 = *(longlong *)(lVar14 + 8) + lStack_c8;
        uVar18 = *(ulonglong *)(lStack_c8 + *(longlong *)(lVar14 + 0x10));
      }
    }
    else {
      uVar6 = 1;
      uVar18 = uVar16;
      if (uStack_60 != 0) {
        do {
          if (uVar15 == *(ulonglong *)((ulonglong)(uVar6 - 1) * 0x58 + lStack_68))
          goto LAB_;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uStack_60);
      }
    }
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0xed8,uVar16,uVar18);
  lVar14 = *(longlong *)(param_1 + 0x80);
  if ((*(byte *)(lVar14 + 0x11) & 8) != 0) goto LAB_;
  *(undefined4 *)(lVar14 + 0xedc) =
       *(undefined4 *)(*(longlong *)(*(longlong *)(param_1 + 0x70) + 8) + 0x240);
  lVar14 = *(longlong *)(param_1 + 0x80);
  if ((*(int *)(lVar14 + 0xedc) != 0) && (((byte)*(undefined4 *)(lVar14 + 0xed8) & 9) == 9)) {
    uVar6 = 1;
    lVar19 = *(longlong *)(param_1 + 0x70);
    if (*(int *)(*(longlong *)(lVar19 + 8) + 0x230) != 0) {
      do {
        iVar7 = *(int *)(*(longlong *)(*(longlong *)(lVar19 + 8) + 0x238) + 0x20 +
                        (ulonglong)(uVar6 - 1) * 0x30);
        if (iVar7 == 0x8000003) {
          *(uint *)(lVar14 + 0xee0) = uVar6;
        }
        else if (iVar7 == 0x8000008) {
          *(uint *)(lVar14 + 0xee4) = uVar6;
        }
        lVar14 = *(longlong *)(param_1 + 0x80);
        if ((*(int *)(lVar14 + 0xee0) != 0) && (*(int *)(lVar14 + 0xee4) != 0)) break;
        uVar6 = uVar6 + 1;
        lVar19 = *(longlong *)(param_1 + 0x70);
      } while (uVar6 <= *(uint *)(*(longlong *)(lVar19 + 8) + 0x230));
    }
  }
  if (*(int *)(lVar14 + 0xee0) == 0) {
    *(undefined4 *)(lVar14 + 0xee0) = 0xffffffff;
    lVar14 = *(longlong *)(param_1 + 0x80);
  }
  if (*(int *)(lVar14 + 0xee4) == 0) {
    *(undefined4 *)(lVar14 + 0xee4) = 0xffffffff;
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x70) + 8) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde858,0x1bb8ce0,0xcab);
  }
  uVar1 = *(undefined2 *)(param_1 + 8);
  bVar23 = (DAT_ & 8) != 0;
  if (bVar23) {
    uStack_140 = 1;
    iVar8 = (*_DAT_)();
    iVar7 = 0x27;
    iStack_14c = 0x27;
    iStack_150 = iVar8;
    lStack_148 = func_0x(uVar1);
  }
  else {
    uStack_140 = 0;
    iVar7 = iStack_14c;
    iVar8 = iStack_150;
  }
  lVar14 = lStack_148;
  if (*(longlong *)(param_1 + 0x80) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde868,0x1bb8ce0,0xd39);
  }
  lVar19 = *(longlong *)(param_1 + 0x70);
  if (*(longlong *)(lVar19 + 8) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1bde858,0x1bb8ce0,0xd3a);
    lVar19 = *(longlong *)(param_1 + 0x70);
  }
  uStack_1b0 = 0;
  uStack_1b8 = 0;
  func_0x(alStack_128,*(undefined8 *)(param_1 + 0x80),*(undefined8 *)(lVar19 + 8),0);
  iVar9 = (*(undefined4 **)(param_1 + 0x80))[5];
  if ((iVar9 == 0) || (iVar9 == 1)) {
LAB_:
    iVar9 = func_0x(alStack_128);
    if (iVar9 == 0) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1bde8a0,0x1bb8ce0,0xd53);
    }
  }
  else if (iVar9 == 2) {
    iVar9 = func_0x(alStack_128);
    if (iVar9 == 0) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1bde878,0x1bb8ce0,0xd44);
    }
  }
  else if (iVar9 == 3) {
    iVar9 = func_0x(alStack_128);
    if (iVar9 == 0) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1bde878,0x1bb8ce0,0xd4a);
    }
    *(undefined4 *)(*(longlong *)(alStack_128[0] + 0x138) + 0xc) = 0;
  }
  else {
    if (iVar9 == 6) goto LAB_;
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,**(undefined4 **)(param_1 + 0x80));
    func_0x(0x4948,0x10,1,0x1a2c790);
  }
  if ((bVar23) && (lVar14 != 0)) {
    iVar9 = (*_DAT_)();
    piVar21 = (int *)(lVar14 + 8 + (longlong)iVar7 * 4);
    *piVar21 = *piVar21 + (iVar9 - iVar8);
  }
  func_0x(param_1);
  lVar14 = *(longlong *)(param_1 + 0x80);
LAB_:
  if ((*(int *)(lVar14 + 0xedc) != 0) && (((byte)*(undefined4 *)(lVar14 + 0xed8) & 9) == 9)) {
    func_0x(lVar14 + 0xb80,lVar14 + 0x710,0x202);
    *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x20) =
         *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x1c);
  }
  func_0x(&lStack_c8);
  lVar14 = lStack_160;
  if ((iStack_158 != 0) && (lStack_160 != 0)) {
    iVar7 = (*_DAT_)();
    piVar21 = (int *)(lVar14 + 8 + (longlong)iStack_164 * 4);
    *piVar21 = *piVar21 + (iVar7 - iStack_168);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_1d8);
  return;
LAB_:
  piVar21 = *(int **)(piVar21 + 0x12);
  if (piVar21 == (int *)0x0) goto LAB_;
  goto LAB_;
}

