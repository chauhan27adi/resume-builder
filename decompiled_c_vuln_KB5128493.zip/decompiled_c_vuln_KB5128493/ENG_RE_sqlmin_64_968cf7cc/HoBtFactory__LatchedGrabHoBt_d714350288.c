
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(longlong param_1,undefined8 *param_2,longlong *param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lStackX_8;
  int iStack_38;
  
  lVar6 = 0;
  uVar5 = (ulonglong)*(ushort *)((longlong)param_2 + 4);
  if (uVar5 != 0) {
    do {
      if ((uVar5 & *(longlong *)(param_1 + 0x30) - 1U) != 0) break;
      uVar5 = uVar5 >> 1;
    } while (uVar5 != 0);
  }
  uVar5 = *(longlong *)(param_1 + 0x30) - 1U &
          uVar5 * *(longlong *)(param_1 + 0x38) + (longlong)*(int *)param_2;
  plVar3 = (longlong *)(uVar5 * 0x10 + *(longlong *)(param_1 + 0x20));
  if (param_3 != (longlong *)0x0) {
    *param_3 = 0;
  }
  lVar2 = (uVar5 % *(ulonglong *)(param_1 + 0x10)) * 0x20 + *(longlong *)(param_1 + 8);
  iStack_38 = func_0x(lVar2,2,0xffffffff,0,0,0,0,0,0);
  if (*(char *)(param_1 + 0x28) == '\0') {
    for (lStackX_8 = *plVar3; lVar4 = lVar6, lStackX_8 != 0;
        lStackX_8 = *(longlong *)(lStackX_8 + 0x98)) {
      if ((((*(int *)(lStackX_8 + 0x84) == (int)*param_2) &&
           (*(short *)(lStackX_8 + 0x88) == (short)((ulonglong)*param_2 >> 0x20))) &&
          ((*(byte *)(lStackX_8 + 0x40) & 2) == 0)) &&
         (((*(byte *)(lStackX_8 + 0x40) & 1) != 0 &&
          (*(longlong *)(lStackX_8 + 0x90) == *(longlong *)(param_1 + 0x18))))) {
        func_0x(lStackX_8 + 0x530,1,0xffffffff,0,0,0,0,0,0);
        uVar1 = *param_2;
        if ((*(byte *)(lStackX_8 + 0x40) & 1) == 0) {
          (*_DAT_)(1,0x1235e40,0x121bd88,0x182,0);
        }
        if (((*(int *)(lStackX_8 + 0x84) == (int)uVar1) &&
            (*(short *)(lStackX_8 + 0x88) == (short)((ulonglong)uVar1 >> 0x20))) &&
           ((*(byte *)(lStackX_8 + 0x40) & 2) == 0)) {
          lVar4 = 0;
          if (*(longlong *)(param_1 + 0x18) != *(longlong *)(lStackX_8 + 0x90)) {
            (*_DAT_)(1,0x1235e20,0x11f49c8,0x61d,0);
          }
          break;
        }
        func_0x(lStackX_8 + 0x530,1);
      }
    }
  }
  else {
    lVar4 = plVar3[1];
    lStackX_8 = lVar6;
    if (lVar4 == 0) goto LAB_;
    do {
      lStackX_8 = *(longlong *)(*(longlong *)(lVar4 + 8) + 8);
      if ((((*(int *)(lStackX_8 + 0x84) == (int)*param_2) &&
           (*(short *)(lStackX_8 + 0x88) == (short)((ulonglong)*param_2 >> 0x20))) &&
          ((*(byte *)(lStackX_8 + 0x40) & 2) == 0)) &&
         (((*(byte *)(lStackX_8 + 0x40) & 1) != 0 &&
          (*(longlong *)(lStackX_8 + 0x90) == *(longlong *)(param_1 + 0x18))))) {
        func_0x(lStackX_8 + 0x530,1,0xffffffff,0,0,0,0,0,0);
        uVar1 = *param_2;
        if ((*(byte *)(lStackX_8 + 0x40) & 1) == 0) {
          (*_DAT_)(1,0x1235e40,0x121bd88,0x182,0);
        }
        if (((*(int *)(lStackX_8 + 0x84) == (int)uVar1) &&
            (*(short *)(lStackX_8 + 0x88) == (short)((ulonglong)uVar1 >> 0x20))) &&
           ((*(byte *)(lStackX_8 + 0x40) & 2) == 0)) {
          if (*(longlong *)(param_1 + 0x18) != *(longlong *)(lStackX_8 + 0x90)) {
            (*_DAT_)(1,0x1235e20,0x11f49c8,0x5fa,0);
          }
          if (param_3 != (longlong *)0x0) {
            *param_3 = lVar4;
          }
          break;
        }
        func_0x(lStackX_8 + 0x530,1);
      }
      lVar4 = *(longlong *)(lVar4 + 0x18);
    } while (lVar4 != 0);
  }
  func_0x(lVar2,2);
  iStack_38 = 0;
  if ((*(char *)(param_1 + 0x28) != '\0') && (lVar4 == 0)) {
    lStackX_8 = lVar6;
  }
LAB_:
  if (iStack_38 != 0) {
    func_0x(lVar2,2);
  }
  return lStackX_8;
}

