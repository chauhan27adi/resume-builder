
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(undefined8 param_1,longlong param_2)

{
  short *psVar1;
  short sVar2;
  byte bVar3;
  byte bVar4;
  ushort uVar5;
  ulonglong uVar6;
  ulonglong *puVar7;
  int iVar8;
  ulonglong uVar9;
  longlong lVar10;
  byte *pbVar11;
  byte bVar12;
  ushort uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  ushort *puVar17;
  uint uVar18;
  longlong lVar19;
  undefined8 uVar20;
  uint uVar21;
  ushort *puVar22;
  longlong unaff_GS_OFFSET;
  bool bVar23;
  undefined8 uStackX_10;
  ulonglong in_stack_ffffffffffffff48;
  undefined4 uVar24;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined2 uStack_90;
  undefined2 uStack_8e;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined2 uStack_80;
  undefined2 uStack_7e;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined2 uStack_70;
  undefined2 uStack_6e;
  longlong lStack_68;
  undefined4 uStack_60;
  int iStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_50;
  short *psStack_48;
  undefined4 uStack_40;
  
  psVar1 = (short *)(param_2 + 0xa0);
  uVar14 = 0;
  uVar16 = 0;
  pbVar11 = *(byte **)(param_2 + 0xa8);
  sVar2 = *psVar1;
  if (sVar2 == 0) {
    if (((*pbVar11 & 0xe) == 2) && ((pbVar11[1] & 1) != 0)) {
      return 0;
    }
  }
  else if ((*pbVar11 & 0x1c) == 0x14) {
    return 0;
  }
  if ((*(byte *)(param_2 + 0x10) & 0x80) != 0) {
    uVar6 = func_0x();
    return uVar6;
  }
  bVar4 = *pbVar11;
  bVar12 = bVar4 & 0xe;
  bVar3 = bVar12;
  if (sVar2 != 0) {
    bVar3 = bVar4 & 0x1c;
  }
  uVar18 = 0;
  if (bVar3 == 0) {
LAB_:
    lVar19 = *(longlong *)(param_2 + 0x98);
    lStack_68 = 0;
    uStackX_10 = 0;
    iVar8 = func_0x(psVar1);
    if ((iVar8 < 1) || (iVar8 = func_0x(param_1,lVar19,param_2), iVar8 != 0)) {
      iVar8 = func_0x(param_2);
      if (iVar8 == 0) {
        lStack_68 = *(longlong *)(lVar19 + 0x80);
        uStack_60 = 9;
        uStack_50 = 0;
        uStack_58 = 0;
        uStack_40 = 0;
        lVar19 = **(longlong **)(*(longlong *)(lStack_68 + 8) + 0x160);
        iStack_5c = *(int *)(lVar19 + 0x10) - *(int *)(lVar19 + 0x18);
        psStack_48 = psVar1;
        iVar8 = func_0x(&lStack_68,&uStackX_10);
        while (iVar8 != 0) {
          in_stack_ffffffffffffff48 = in_stack_ffffffffffffff48 & 0xffffffff00000000;
          uVar16 = func_0x(param_1,param_2 + 0x18,param_2,uStackX_10,
                                   in_stack_ffffffffffffff48);
          uVar14 = uVar14 | uVar16;
          if (uVar14 != 0) {
            if ((uVar14 & 8) == 0) break;
            func_0x(0x7f);
            uVar14 = uVar14 - 8;
            if (uVar14 != 0) break;
          }
          iVar8 = func_0x(&lStack_68,&uStackX_10);
        }
        return (ulonglong)uVar14;
      }
      uStack_78 = *(undefined4 *)(param_2 + 0x154);
      uVar20 = 0xe5d4e0;
      uStack_74 = *(undefined4 *)(param_2 + 0x158);
      uStack_70 = *(undefined2 *)(param_2 + 0x15c);
      uStack_6e = *(undefined2 *)(param_2 + 0x15e);
      if (iVar8 == 2) {
        uVar20 = 0xe5d120;
      }
      func_0x(&uStack_78,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,uVar20,0x15,0,0);
      func_0x(param_1,2,param_2 + 0x60);
    }
    return 4;
  }
  uVar15 = (uint)bVar4;
  if (sVar2 == 0) {
    if (bVar12 == 2) goto LAB_;
    bVar23 = bVar12 == 4;
  }
  else {
    if (((uVar15 & 0x1c) - 0x10 & 0xfffffffb) == 0) goto LAB_;
    bVar23 = (bVar4 & 0x1c) == 8;
  }
  if ((bVar23) && (*(short *)(param_2 + 0x7a) != 2)) {
    return 0;
  }
  if (sVar2 == 0) {
    if (bVar12 == 2) {
      uVar14 = (uint)((pbVar11[1] & 1) != 0);
    }
    else {
      uVar14 = uVar16;
      if (((bVar12 - 10 & 0xf9) == 0) && (bVar12 != 0x10)) {
        uVar14 = 1;
      }
    }
  }
  else {
    uVar14 = (uint)(((uVar15 & 0x1c) - 4 & 0xffffffe7) == 0);
  }
  if (uVar14 != 0) {
    if (sVar2 == 0) {
      if ((1 << (bVar4 & 0xe) & 0x440U) == 0) {
LAB_:
        if (*(short *)(param_2 + 0x7a) == 2) {
          return 0;
        }
        if ((*(int *)(*(longlong *)(param_2 + 0x98) + 0x328) - 2U & 0xfffffffd) == 0) {
          return 0;
        }
      }
    }
    else if (((uVar15 & 0x1c) - 0x18 & 0xfffffffb) != 0) goto LAB_;
  }
  if (sVar2 != 0) {
    if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) goto LAB_;
LAB_:
    uVar18 = (uint)(((bVar4 & 0x1c) - 4 & 0xffffffe7) == 0);
    goto LAB_;
  }
  if (bVar12 == 0xe) {
LAB_:
    if (*(short *)(param_2 + 0x7a) == 1) {
      uVar14 = 9;
      if (sVar2 == 0) {
        iVar8 = *(int *)(param_2 + 0xb0);
      }
      else if ((uVar15 & 0x1c) == 4) {
        iVar8 = 1;
      }
      else if ((uVar15 & 0x1c) == 0x10) {
        iVar8 = 9;
      }
      else {
        iVar8 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
      }
      if (iVar8 == 1) {
        return 0;
      }
      if (sVar2 == 0) {
        puVar17 = (ushort *)(param_2 + 0xa2);
        uVar21 = *(uint *)(param_2 + 0xb0);
        if (*(int *)(param_2 + 0xa4) == 0) {
          pbVar11 = *(byte **)(param_2 + 0xa8);
          uVar14 = *(uint *)(param_2 + 0xb0);
          uVar6 = (ulonglong)uVar14;
          *puVar17 = 0;
          *(uint *)(param_2 + 0xb4) = uVar14;
          bVar4 = *pbVar11;
          if ((bVar4 & 0x10) != 0) {
            uVar14 = uVar14 + 2 + (*(ushort *)(pbVar11 + uVar6) + 7 >> 3);
            uVar6 = (ulonglong)uVar14;
            *(uint *)(param_2 + 0xb4) = uVar14;
            bVar4 = *pbVar11;
          }
          if ((bVar4 & 0x20) == 0) {
            *(int *)(param_2 + 0xa4) = (int)uVar6;
            *(undefined2 *)(param_2 + 0xbc) = 0;
            *(int *)(param_2 + 0xb8) = (int)uVar6;
          }
          else {
            puVar22 = (ushort *)(pbVar11 + uVar6);
            uVar5 = *puVar22;
            *(ushort *)(param_2 + 0xbc) = uVar5;
            if (uVar5 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar19 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar19 != 0)) &&
                 ((lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0 &&
                  (*(char *)(lVar19 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  in_stack_ffffffffffffff48 = 0;
                  (*_DAT_)(1,0xd7bf78,0xe9bc48,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),3);
              uVar6 = (ulonglong)*(uint *)(param_2 + 0xb4);
              uVar5 = *(ushort *)(param_2 + 0xbc);
            }
            uVar14 = (int)uVar6 + (uVar5 + 1) * 2;
            *(uint *)(param_2 + 0xb8) = uVar14;
            if (0x1f9e < uVar14) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar19 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar19 != 0 &&
                  ((lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0 &&
                   (*(char *)(lVar19 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  in_stack_ffffffffffffff48 = 0;
                  (*_DAT_)(1,0xd7bf78,0xe9bc48,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
              uVar5 = *(ushort *)(param_2 + 0xbc);
              uVar14 = *(uint *)(param_2 + 0xb8);
            }
            uVar9 = (ulonglong)uVar5;
            uVar15 = puVar22[uVar9] & 0x7fff;
            *(uint *)(param_2 + 0xa4) = uVar15;
            if (uVar15 < uVar14) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar19 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar19 != 0)) &&
                 ((lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0 &&
                  (*(char *)(lVar19 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  in_stack_ffffffffffffff48 = 0;
                  (*_DAT_)(1,0xd7bf78,0xe9bc48,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
              uVar9 = (ulonglong)*(ushort *)(param_2 + 0xbc);
              uVar15 = *(uint *)(param_2 + 0xa4);
            }
            uVar6 = (ulonglong)uVar15;
            if ((short)puVar22[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
              do {
                lVar19 = *(longlong *)(param_2 + 0xa8);
                lVar10 = (ulonglong)*(uint *)(param_2 + 0xb4) + lVar19;
                if ((int)uVar9 == 1) {
                  uVar14 = *(uint *)(param_2 + 0xb8);
                  uVar15 = uVar14;
LAB_:
                  if ((*(ushort *)(lVar10 + uVar9 * 2) & 0x7fff) < uVar14) goto LAB_;
                }
                else {
                  uVar15 = *(uint *)(param_2 + 0xb8);
                  uVar14 = *(ushort *)(lVar10 + -2 + uVar9 * 2) & 0x7fff;
                  if (uVar15 <= uVar14) goto LAB_;
LAB_:
                  func_0x(lVar19,7);
                  uVar15 = *(uint *)(param_2 + 0xb8);
                  lVar19 = *(longlong *)(param_2 + 0xa8);
                }
                if ((uVar14 < uVar15) ||
                   (uVar6 = (ulonglong)*(uint *)(param_2 + 0xa4), *(uint *)(param_2 + 0xa4) < uVar14
                   )) goto LAB_;
                if (*(ushort *)((ulonglong)uVar14 + lVar19) == 5) {
                  *puVar17 = *puVar17 | 2;
                  *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
                  uVar5 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
                  *(short *)(param_2 + 0xca) = (short)uVar14;
                  lVar19 = (ulonglong)(uVar14 & 0xffff) + *(longlong *)(param_2 + 0xa8);
                  if ((*(ushort *)(lVar19 + 2) >> 0xe & 1) != 0) {
                    uVar5 = *(ushort *)(lVar19 + 2) & 0x3800 | uVar5;
                  }
                  *(ushort *)(param_2 + 0xcc) = uVar5;
                  *(ushort *)(param_2 + 0xcc) = (uVar5 ^ *(ushort *)(lVar19 + 2)) & 0x7ff ^ uVar5;
                  uVar6 = (ulonglong)*(uint *)(param_2 + 0xa4);
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar14 + lVar19) < 0x400) goto LAB_;
                *puVar17 = *puVar17 | 1;
                uVar5 = *(short *)(param_2 + 0xbc) - 1;
                *(ushort *)(param_2 + 0xbc) = uVar5;
                if (uVar5 == 0) goto LAB_;
                uVar9 = (ulonglong)uVar5;
              } while ((short)puVar22[(ulonglong)(uVar5 - 1) + 1] < 0);
              pbVar11 = *(byte **)(param_2 + 0xa8);
            }
            else {
LAB_:
              pbVar11 = *(byte **)(param_2 + 0xa8);
            }
          }
          if ((*pbVar11 & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0xc6) = 0;
          }
          else {
            *(int *)(param_2 + 0xc6) = (int)uVar6;
            *(int *)(param_2 + 0xa4) = (int)uVar6 + 0xe;
            puVar7 = (ulonglong *)func_0x(puVar17);
            uVar13 = (ushort)(*puVar7 >> 0x30);
            uVar5 = uVar13;
            if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
              uVar5 = uVar13 & 0xdfff;
              if ((uVar13 >> 0xe & 1) != 0) {
                uVar5 = uVar13 | 0x2000;
              }
            }
            if (uVar5 == 0xfffc) {
              uVar16 = (uint)((*puVar7 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + uVar16;
            uVar6 = (ulonglong)*(uint *)(param_2 + 0xa4);
            pbVar11 = *(byte **)(param_2 + 0xa8);
          }
          iVar8 = (int)uVar6;
          if ((*(byte **)(param_2 + 0xbe) != (byte *)0x0) &&
             (*(byte **)(param_2 + 0xbe) < pbVar11 + uVar6)) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar19 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar19 != 0 &&
                 (lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0)) &&
                (*(char *)(lVar19 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd7bf78,0xe9bc48,0x877,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
            iVar8 = *(int *)(param_2 + 0xa4);
          }
          if (0x3f3b < iVar8 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar19 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar19 != 0 &&
                ((lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0 &&
                 (*(char *)(lVar19 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd7bf78,0xe9bc48,0x87c,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),5);
          }
        }
LAB_:
        uVar16 = *(uint *)(param_2 + 0xa4);
        if (uVar16 < 9) {
          pbVar11 = *(byte **)(param_2 + 0xa8);
          bVar4 = *pbVar11;
          if (((bVar4 & 0xe) != 0) && ((bVar4 & 0xe) != 0xc)) goto LAB_;
          uVar14 = 9;
        }
        else {
LAB_:
          pbVar11 = *(byte **)(param_2 + 0xa8);
          bVar4 = *pbVar11;
          uVar14 = uVar16;
        }
        if ((bVar4 & 0x40) != 0) {
          uVar14 = *(uint *)(param_2 + 0xc6);
        }
      }
      else {
        if ((uVar15 & 0x1c) == 4) {
          uVar21 = 1;
        }
        else {
          uVar21 = uVar14;
          if ((uVar15 & 0x1c) != 0x10) {
            uVar21 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
          }
        }
        uVar16 = *(uint *)(param_2 + 0xa4);
        if (uVar16 == 0) {
          func_0x(param_2 + 0xa2);
          uVar16 = *(uint *)(param_2 + 0xa4);
          if (uVar16 == 0) {
            func_0x(param_2 + 0xa2);
            uVar16 = *(uint *)(param_2 + 0xa4);
          }
        }
        if (uVar16 < 9) {
          pbVar11 = *(byte **)(param_2 + 0xa8);
          bVar4 = *pbVar11;
          if (((bVar4 & 0x1c) != 0) && ((bVar4 & 0x1c) != 0xc)) goto LAB_;
        }
        else {
LAB_:
          pbVar11 = *(byte **)(param_2 + 0xa8);
          bVar4 = *pbVar11;
          uVar14 = uVar16;
        }
        if ((bVar4 & 2) != 0) {
          uVar14 = *(uint *)(param_2 + 0xd0);
        }
      }
      uVar24 = (undefined4)(in_stack_ffffffffffffff48 >> 0x20);
      puVar17 = (ushort *)(param_2 + 0xa2);
      if (uVar21 == uVar14) {
        return 0;
      }
      if (*psVar1 != 0) {
        if (uVar16 == 0) {
          func_0x(puVar17);
          uVar16 = *(uint *)(param_2 + 0xa4);
          pbVar11 = *(byte **)(param_2 + 0xa8);
          if (uVar16 == 0) {
            func_0x(puVar17);
            pbVar11 = *(byte **)(param_2 + 0xa8);
            uVar16 = *(uint *)(param_2 + 0xa4);
          }
        }
        if ((uVar16 < 9) && (((*pbVar11 & 0x1c) == 0 || ((*pbVar11 & 0x1c) == 0xc)))) {
          uVar16 = 9;
        }
        if ((*pbVar11 & 2) != 0) {
          uVar16 = *(uint *)(param_2 + 0xd0);
        }
        goto LAB_;
      }
      if (uVar16 == 0) {
        uVar16 = *(uint *)(param_2 + 0xb0);
        uVar6 = (ulonglong)uVar16;
        *(uint *)(param_2 + 0xb4) = uVar16;
        *puVar17 = 0;
        if ((*pbVar11 & 0x10) != 0) {
          uVar16 = uVar16 + 2 + (*(ushort *)(pbVar11 + uVar6) + 7 >> 3);
          uVar6 = (ulonglong)uVar16;
          *(uint *)(param_2 + 0xb4) = uVar16;
        }
        if ((*pbVar11 & 0x20) == 0) {
          *(int *)(param_2 + 0xa4) = (int)uVar6;
          *(undefined2 *)(param_2 + 0xbc) = 0;
          *(int *)(param_2 + 0xb8) = (int)uVar6;
        }
        else {
          puVar22 = (ushort *)(pbVar11 + uVar6);
          uVar5 = *puVar22;
          *(ushort *)(param_2 + 0xbc) = uVar5;
          if (uVar5 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar19 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar19 != 0)) &&
               ((lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0 &&
                (*(char *)(lVar19 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd7bf78,0xe9bc48,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),3);
            uVar6 = (ulonglong)*(uint *)(param_2 + 0xb4);
            uVar5 = *(ushort *)(param_2 + 0xbc);
          }
          uVar16 = (int)uVar6 + (uVar5 + 1) * 2;
          *(uint *)(param_2 + 0xb8) = uVar16;
          if (0x1f9e < uVar16) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar19 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar19 != 0 &&
                ((lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0 &&
                 (*(char *)(lVar19 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd7bf78,0xe9bc48,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),4);
            uVar5 = *(ushort *)(param_2 + 0xbc);
            uVar16 = *(uint *)(param_2 + 0xb8);
          }
          uVar9 = (ulonglong)uVar5;
          uVar14 = puVar22[uVar9] & 0x7fff;
          *(uint *)(param_2 + 0xa4) = uVar14;
          if (uVar14 < uVar16) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar19 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar19 != 0)) &&
               ((lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0 &&
                (*(char *)(lVar19 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd7bf78,0xe9bc48,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),4);
            uVar9 = (ulonglong)*(ushort *)(param_2 + 0xbc);
            uVar14 = *(uint *)(param_2 + 0xa4);
          }
          uVar24 = (undefined4)(in_stack_ffffffffffffff48 >> 0x20);
          uVar6 = (ulonglong)uVar14;
          if ((short)puVar22[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
            do {
              pbVar11 = *(byte **)(param_2 + 0xa8);
              if ((int)uVar9 == 1) {
                uVar16 = *(uint *)(param_2 + 0xb8);
                uVar14 = uVar16;
LAB_:
                if ((*(ushort *)(pbVar11 + uVar9 * 2 + (ulonglong)*(uint *)(param_2 + 0xb4)) &
                    0x7fff) < uVar16) goto LAB_;
              }
              else {
                uVar14 = *(uint *)(param_2 + 0xb8);
                uVar16 = *(ushort *)
                          (pbVar11 + uVar9 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2)) &
                         0x7fff;
                if (uVar14 <= uVar16) goto LAB_;
LAB_:
                func_0x(pbVar11,7);
                uVar14 = *(uint *)(param_2 + 0xb8);
                pbVar11 = *(byte **)(param_2 + 0xa8);
              }
              uVar24 = (undefined4)(in_stack_ffffffffffffff48 >> 0x20);
              if ((uVar16 < uVar14) ||
                 (uVar6 = (ulonglong)*(uint *)(param_2 + 0xa4), *(uint *)(param_2 + 0xa4) < uVar16))
              goto LAB_;
              if (*(ushort *)(pbVar11 + uVar16) == 5) {
                *puVar17 = *puVar17 | 2;
                *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
                uVar5 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
                *(short *)(param_2 + 0xca) = (short)uVar16;
                lVar19 = (ulonglong)(uVar16 & 0xffff) + *(longlong *)(param_2 + 0xa8);
                if ((*(ushort *)(lVar19 + 2) >> 0xe & 1) != 0) {
                  uVar5 = *(ushort *)(lVar19 + 2) & 0x3800 | uVar5;
                }
                *(ushort *)(param_2 + 0xcc) = uVar5;
                *(ushort *)(param_2 + 0xcc) = (uVar5 ^ *(ushort *)(lVar19 + 2)) & 0x7ff ^ uVar5;
                uVar6 = (ulonglong)*(uint *)(param_2 + 0xa4);
                goto LAB_;
              }
              if (*(ushort *)(pbVar11 + uVar16) < 0x400) goto LAB_;
              *puVar17 = *puVar17 | 1;
              uVar5 = *(short *)(param_2 + 0xbc) - 1;
              *(ushort *)(param_2 + 0xbc) = uVar5;
              if (uVar5 == 0) goto LAB_;
              uVar9 = (ulonglong)uVar5;
            } while ((short)puVar22[(ulonglong)(uVar5 - 1) + 1] < 0);
            pbVar11 = *(byte **)(param_2 + 0xa8);
          }
          else {
LAB_:
            pbVar11 = *(byte **)(param_2 + 0xa8);
          }
        }
        if ((*pbVar11 & 0x40) == 0) {
          *(undefined4 *)(param_2 + 0xc6) = 0;
        }
        else {
          *(int *)(param_2 + 0xc6) = (int)uVar6;
          *(int *)(param_2 + 0xa4) = (int)uVar6 + 0xe;
          puVar7 = (ulonglong *)func_0x(puVar17);
          uVar13 = (ushort)(*puVar7 >> 0x30);
          uVar5 = uVar13;
          if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
            uVar5 = uVar13 & 0xdfff;
            if ((uVar13 >> 0xe & 1) != 0) {
              uVar5 = uVar13 | 0x2000;
            }
          }
          if (uVar5 == 0xfffc) {
            uVar18 = (uint)((*puVar7 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + uVar18;
          uVar6 = (ulonglong)*(uint *)(param_2 + 0xa4);
          pbVar11 = *(byte **)(param_2 + 0xa8);
        }
        uVar16 = (uint)uVar6;
        if ((*(byte **)(param_2 + 0xbe) != (byte *)0x0) &&
           (*(byte **)(param_2 + 0xbe) < pbVar11 + uVar6)) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar19 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar19 != 0 &&
               (lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0)) &&
              (*(char *)(lVar19 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uVar24 = 0;
              (*_DAT_)(1,0xd7bf78,0xe9bc48,0x877,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
          uVar16 = *(uint *)(param_2 + 0xa4);
          pbVar11 = *(byte **)(param_2 + 0xa8);
        }
        if ((uVar16 == 0) || (0x3f3c < uVar16)) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar19 = *(longlong *)
                          (*(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8 + (ulonglong)*_DAT_), lVar19 != 0 &&
               (lVar19 = *(longlong *)(lVar19 + 0x60), lVar19 != 0)) &&
              (*(char *)(lVar19 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uVar24 = 0;
              (*_DAT_)(1,0xd7bf78,0xe9bc48,0x87c,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),5);
          pbVar11 = *(byte **)(param_2 + 0xa8);
        }
      }
LAB_:
      uVar16 = *(uint *)(param_2 + 0xa4);
      if (uVar16 < 9) {
        bVar4 = *pbVar11;
        if (((bVar4 & 0xe) != 0) && ((bVar4 & 0xe) != 0xc)) goto LAB_;
        uVar16 = 9;
      }
      else {
LAB_:
        bVar4 = *pbVar11;
      }
      if ((bVar4 & 0x40) != 0) {
        uVar16 = *(uint *)(param_2 + 0xc6);
      }
LAB_:
      if (*psVar1 == 0) {
        iVar8 = *(int *)(param_2 + 0xb0);
      }
      else if ((*pbVar11 & 0x1c) == 4) {
        iVar8 = 1;
      }
      else if ((*pbVar11 & 0x1c) == 0x10) {
        iVar8 = 9;
      }
      else {
        iVar8 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
      }
      uStack_98 = *(undefined4 *)(param_2 + 0x154);
      uStack_94 = *(undefined4 *)(param_2 + 0x158);
      uStack_90 = *(undefined2 *)(param_2 + 0x15c);
      uStack_8e = *(undefined2 *)(param_2 + 0x15e);
      func_0x(&uStack_98,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,0xe5d520,
                      CONCAT44(uVar24,0x14),iVar8,uVar16);
      func_0x(param_1,2,param_2 + 0x60);
      return 4;
    }
    if (sVar2 != 0) goto LAB_;
  }
  if (bVar12 == 2) {
    uVar18 = (uint)((pbVar11[1] & 1) != 0);
  }
  else if (((bVar12 - 10 & 0xf9) == 0) && (bVar12 != 0x10)) {
    uVar18 = 1;
  }
LAB_:
  if ((uVar18 != 0) && (*(short *)(param_2 + 0x7a) == 1)) {
    return 0;
  }
  uStack_88 = *(undefined4 *)(param_2 + 0x154);
  uStack_84 = *(undefined4 *)(param_2 + 0x158);
  uStack_80 = *(undefined2 *)(param_2 + 0x15c);
  uStack_7e = *(undefined2 *)(param_2 + 0x15e);
  func_0x(&uStack_88,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,0xe5d420,3,0,0);
  func_0x(param_1,2,param_2 + 0x60);
  return 0x14;
}

