
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,ulonglong param_3,undefined8 param_4,
                 int **param_5,longlong param_6)

{
  longlong *plVar1;
  code *pcVar2;
  longlong lVar3;
  char cVar4;
  byte bVar5;
  int iVar6;
  longlong lVar7;
  undefined8 uVar8;
  ulonglong *puVar9;
  longlong lVar10;
  int *piVar11;
  undefined4 *puVar12;
  ulonglong uVar13;
  ushort uVar14;
  ushort uVar15;
  uint uVar16;
  ulonglong uVar17;
  int *piVar18;
  uint uVar19;
  uint uVar20;
  int *piVar21;
  ulonglong uVar22;
  short sVar23;
  ushort *puVar24;
  int **ppiVar25;
  int iVar26;
  longlong unaff_GS_OFFSET;
  undefined4 uVar27;
  undefined4 uVar28;
  undefined4 uVar29;
  undefined4 uVar30;
  int iStackX_8;
  ushort uStackX_c;
  ushort uStackX_e;
  int *piStackX_10;
  uint uStackX_18;
  undefined4 uStackX_1c;
  longlong lStackX_20;
  undefined auStack_4128 [16];
  undefined4 uStack_4118;
  undefined4 uStack_4114;
  undefined4 uStack_4110;
  undefined4 uStack_410c;
  short sStack_4108;
  ushort uStack_4106;
  uint uStack_4104;
  int *piStack_4100;
  undefined8 uStack_40f8;
  uint uStack_40f0;
  ushort uStack_40ec;
  byte *pbStack_40ea;
  undefined2 uStack_40e2;
  undefined2 uStack_40e0;
  undefined2 uStack_40de;
  ushort uStack_40dc;
  undefined2 uStack_40da;
  undefined4 uStack_40d4;
  undefined auStack_4058 [8191];
  undefined auStack_2059 [8193];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  *(undefined8 *)((longlong)&param_5 + lVar7) = 0xfffffffffffffffe;
  ppiVar25 = param_5;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar7);
  *(undefined8 *)((longlong)&param_6 + lVar7) = param_1;
  *(int ***)((longlong)&lStackX_20 + lVar7) = param_5;
  lVar3 = param_6;
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100072;
  cVar4 = func_0x(param_2,param_3 & 0xffffffff,param_4,(longlong)&uStackX_1c + lVar7);
  if (cVar4 == '\0') {
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10008a;
    uVar8 = (*_DAT_)(*(undefined4 *)((longlong)&uStackX_1c + lVar7),auStack_4058,0,0);
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar7) = param_2;
    *(int *)(&stack0xffffffffffffffe8 + lVar7) = (int)param_3;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = uVar8;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1000ae;
    (*_DAT_)(0x33,0x17,0x10,0x14);
  }
  piVar11 = (int *)0x0;
  sStack_4108 = -1;
  piStack_4100 = (int *)0x0;
  uStack_4104 = 0;
  pbStack_40ea = (byte *)0x0;
  uStack_40e0 = 0;
  uStack_40de = 0;
  uStack_40dc = 0;
  uStack_40da = 0;
  uStack_40f8 = (longlong *)0x0;
  uStack_40d4 = 0xffffffff;
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1000e9;
  iVar6 = func_0x(param_4,(ulonglong)auStack_2059 & 0xfffffffffffff000,&sStack_4108);
  if (iVar6 == 0) goto LAB_;
  *(undefined4 *)((longlong)&iStackX_8 + lVar7) = 0xffffffd2;
  *(undefined2 *)((longlong)&uStackX_c + lVar7) = 0x2e;
  *(ushort *)((longlong)&uStackX_c + lVar7 + 2) =
       *(ushort *)((longlong)&uStackX_c + lVar7 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_c + lVar7 + 4) = 0;
  iVar6 = 0;
  if (sStack_4108 == 0) {
    iVar26 = 1;
    if ((*(byte *)piStack_4100 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_4100 & 0xe) & 0x1105U) != 0) {
        bVar5 = 0xff;
        iVar26 = iVar6;
        goto LAB_;
      }
LAB_:
      piVar18 = piStack_4100;
      uVar16 = uStack_40f0;
      if (uStack_4104 == 0) {
        uStack_4106 = 0;
        uVar17 = (ulonglong)uStack_40f8 & 0xffffffff;
        uVar16 = (uint)uStack_40f8;
        if ((*(byte *)piStack_4100 & 0x10) != 0) {
          uVar16 = (uint)uStack_40f8 + 2 + (*(ushort *)(uVar17 + (longlong)piStack_4100) + 7 >> 3);
          uVar17 = (ulonglong)uVar16;
        }
        uStack_40f8 = (longlong *)CONCAT44(uVar16,(uint)uStack_40f8);
        if ((*(byte *)piStack_4100 & 0x20) == 0) {
          uStack_4104 = (uint)uVar17;
          uStack_40ec = 0;
          uStack_40f0 = (uint)uVar17;
          uVar22 = uVar17;
        }
        else {
          puVar24 = (ushort *)(uVar17 + (longlong)piStack_4100);
          uStack_40ec = *puVar24;
          if (*puVar24 == 0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100287;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1002ab;
                (*_DAT_)(1,0x13c9ae8,0x14e97b8,0x80f);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1002bc;
            func_0x(piStack_4100,3);
          }
          uStack_40f0 = uStack_40f8._4_4_ + (uStack_40ec + 1) * 2;
          if (0x1f9e < uStack_40f0) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0 &&
                ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                 (*(char *)(lVar10 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10035c;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100380;
                (*_DAT_)(1,0x13c9ae8,0x14e97b8,0x816);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10038e;
            func_0x(piStack_4100,4);
          }
          uStack_4104 = puVar24[uStack_40ec] & 0x7fff;
          if ((puVar24[uStack_40ec] & 0x7fff) < uStack_40f0) {
            if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                (lVar10 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar10 != 0)) &&
               ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100428;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10044c;
                (*_DAT_)(1,0x13c9ae8,0x14e97b8,0x81d);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10045a;
            func_0x(piStack_4100,4);
          }
          uVar22 = (ulonglong)uStack_40f0;
          uVar17 = (ulonglong)uStack_4104;
          piVar18 = piStack_4100;
          do {
            uVar13 = (ulonglong)uStack_40ec;
            if (-1 < (short)puVar24[(ulonglong)(uStack_40ec - 1) + 1]) break;
            if (uStack_40ec == 1) {
              uVar13 = 1;
              uVar19 = (uint)uVar22;
            }
            else {
              uVar19 = *(ushort *)
                        ((longlong)piVar18 + uVar13 * 2 + (((ulonglong)uStack_40f8 >> 0x20) - 2)) &
                       0x7fff;
            }
            if ((uVar19 < (uint)uVar22) ||
               ((*(ushort *)((longlong)piVar18 + uVar13 * 2 + ((ulonglong)uStack_40f8 >> 0x20)) &
                0x7fff) < uVar19)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1004c7;
              func_0x(piVar18,7);
              uVar22 = (ulonglong)uStack_40f0;
              uVar17 = (ulonglong)uStack_4104;
              piVar18 = piStack_4100;
            }
            uVar16 = (uint)uVar22;
            if ((uVar19 < uVar16) || ((uint)uVar17 < uVar19)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar18) == 5) {
              uStack_4106 = uStack_4106 | 2;
              uStack_40ec = uStack_40ec - 1;
              uStack_40de = (short)uVar19;
              uVar15 = *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar18);
              if ((uVar15 & 0x4000) == 0) {
                uStack_40dc = uStack_40dc & 0xc7ff;
              }
              else {
                uStack_40dc = uStack_40dc ^ (uVar15 ^ uStack_40dc) & 0x3800;
              }
              uStack_40dc = (uStack_40dc ^
                            *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + (longlong)piVar18)) &
                            0x7ff ^ uStack_40dc;
              break;
            }
            if (*(ushort *)((ulonglong)uVar19 + (longlong)piVar18) < 0x400) break;
            uStack_4106 = uStack_4106 | 1;
            uStack_40ec = uStack_40ec - 1;
          } while (uStack_40ec != 0);
        }
        uVar16 = (uint)uVar22;
        if ((*(byte *)piVar18 & 0x40) == 0) {
          uStack_40e2 = 0;
          uStack_40e0 = 0;
        }
        else {
          uStack_40e2 = (undefined2)uVar17;
          uStack_40e0 = (undefined2)(uVar17 >> 0x10);
          uStack_4104 = (int)uVar17 + 0xe;
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100597;
          puVar9 = (ulonglong *)func_0x(&uStack_4106);
          uVar17 = *puVar9;
          uVar14 = (ushort)(uVar17 >> 0x30);
          uVar15 = uVar14;
          if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
            uVar15 = uVar14 & 0xdfff;
            if ((uVar17 & 0x4000000000000000) != 0) {
              uVar15 = uVar14 | 0x2000;
            }
          }
          iVar26 = iVar6;
          if (uVar15 == 0xfffc) {
            iVar26 = (int)((uVar17 >> 0x20 & 0xffff) >> 5);
          }
          uVar17 = (ulonglong)(uStack_4104 + iVar26);
          uStack_4104 = uStack_4104 + iVar26;
          piVar18 = piStack_4100;
          uVar16 = uStack_40f0;
        }
        uVar19 = (uint)uVar17;
        if ((pbStack_40ea != (byte *)0x0) && (pbStack_40ea < (byte *)(uVar17 + (longlong)piVar18)))
        {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             (((lVar10 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                          + 8), piVar18 = piStack_4100, lVar10 != 0 &&
               (lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0)) &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100691;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
              piVar18 = piStack_4100;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1006b5;
              (*_DAT_)(1,0x13c9ae8,0x14e97b8,0x877);
              piVar18 = piStack_4100;
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1006c6;
          func_0x(piVar18,0x12);
          piVar18 = piStack_4100;
          uVar19 = uStack_4104;
          uVar16 = uStack_40f0;
        }
        if (0x3f3b < uVar19 - 1) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar10 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8), piVar18 = piStack_4100, lVar10 != 0 &&
              ((lVar10 = *(longlong *)(lVar10 + 0x60), lVar10 != 0 &&
               (*(char *)(lVar10 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100756;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              piVar18 = piStack_4100;
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10077a;
              (*_DAT_)(1,0x13c9ae8,0x14e97b8,0x87c);
              piVar18 = piStack_4100;
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x10078b;
          func_0x(piVar18,5);
          piVar18 = piStack_4100;
          uVar16 = uStack_40f0;
        }
      }
LAB_:
      sVar23 = -*(short *)((longlong)&iStackX_8 + lVar7);
      if ((*(byte *)((longlong)&uStackX_c + lVar7 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar18 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar18 & 0xe) & 0x1105U) != 0) {
LAB_:
            piVar21 = *(int **)((longlong)&uStackX_c + lVar7 + 4);
            piVar18 = piVar21 + 1;
            iVar6 = *piVar21;
            ppiVar25 = *(int ***)((longlong)&lStackX_20 + lVar7);
            *(int *)((longlong)&lStackX_20 + lVar7 + -0x20) = iVar6;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40f8 <= *(int *)((longlong)&iStackX_8 + lVar7)) ||
                (*(ushort *)(((ulonglong)uStack_40f8 & 0xffffffff) + (longlong)piVar18) <
                 *(ushort *)((longlong)&uStackX_c + lVar7))) goto LAB_;
      }
      if ((uint)uStack_40ec < (uint)(int)sVar23) {
        ppiVar25 = *(int ***)((longlong)&lStackX_20 + lVar7);
        *(undefined4 *)((longlong)&lStackX_20 + lVar7 + -0x20) = 0;
      }
      else {
        piVar21 = piVar18;
        uVar19 = uVar16;
        if (sVar23 != 1) {
          uVar16 = *(ushort *)
                    ((longlong)piVar18 +
                    (longlong)sVar23 * 2 + (((ulonglong)uStack_40f8 >> 0x20) - 2)) & 0x7fff;
          piVar21 = piStack_4100;
          uVar19 = uStack_40f0;
        }
        uVar20 = *(ushort *)
                  ((longlong)piVar18 + (longlong)sVar23 * 2 + ((ulonglong)uStack_40f8 >> 0x20)) &
                 0x7fff;
        if ((uVar16 < uVar19) || (uVar20 < uVar16)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100846;
          func_0x(piVar21,7);
          piVar21 = piStack_4100;
        }
        piVar18 = (int *)((ulonglong)uVar16 + (longlong)piVar21);
        iVar6 = uVar20 - uVar16;
        ppiVar25 = *(int ***)((longlong)&lStackX_20 + lVar7);
        *(int *)((longlong)&lStackX_20 + lVar7 + -0x20) = iVar6;
      }
    }
    else {
      if ((int)(uint)uStack_40f8 < -0x2d) {
        bVar5 = 0xff;
        iVar26 = iVar6;
      }
      else if (*(ushort *)((longlong)piStack_4100 + ((ulonglong)uStack_40f8 & 0xffffffff)) < 0x2e) {
        bVar5 = 0xff;
        iVar26 = iVar6;
      }
      else {
        bVar5 = *(byte *)((longlong)piStack_4100 + ((ulonglong)uStack_40f8 & 0xffffffff) + 7) >> 5;
      }
LAB_:
      if ((bVar5 & 1) == 0) {
        if ((iVar26 != 0) || ((*(byte *)((longlong)&uStackX_c + lVar7 + 2) & 0x10) == 0))
        goto LAB_;
        piVar18 = (int *)0x4;
        iVar6 = **(int **)((longlong)&uStackX_c + lVar7 + 4);
        *(int *)((longlong)&lStackX_20 + lVar7 + -0x20) = iVar6;
      }
      else {
        *(undefined4 *)((longlong)&lStackX_20 + lVar7 + -0x20) = 0;
        piVar18 = piVar11;
      }
    }
  }
  else {
    *(undefined4 *)((longlong)&uStackX_18 + lVar7) = 0;
    *(longlong *)(&stack0xffffffffffffffe0 + lVar7) = (longlong)&uStackX_18 + lVar7;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100895;
    piVar18 = (int *)func_0x(&uStack_4106,(longlong)&iStackX_8 + lVar7);
    if ((((sStack_4108 == 0) || (uStack_40f8 == (longlong *)0x0)) || (*uStack_40f8 == 0)) ||
       (((*(byte *)((longlong)&uStackX_c + lVar7 + 2) & 8) != 0 ||
        ((*(uint *)((longlong)&uStackX_18 + lVar7) & 1) != 0)))) {
LAB_:
      iVar6 = *(int *)((longlong)&lStackX_20 + lVar7 + -0x20);
    }
    else {
      if ((piVar18 != (int *)0x0) && (piVar18 != (int *)0x114e524)) {
        *(uint *)(&stack0xfffffffffffffff8 + lVar7) = *(uint *)((longlong)&uStackX_18 + lVar7);
        *(longlong *)(&stack0xfffffffffffffff0 + lVar7) = (longlong)&lStackX_20 + lVar7 + -0x20;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
        uVar27 = *(undefined4 *)((longlong)&lStackX_20 + lVar7 + -0x20);
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1008fd;
        piVar18 = (int *)func_0x
                                   (uStack_40f8,(longlong)&iStackX_8 + lVar7,piVar18,uVar27);
        goto LAB_;
      }
      *(undefined4 *)((longlong)&lStackX_20 + lVar7 + -0x20) = 0;
      piVar18 = (int *)0x0;
    }
  }
LAB_:
  if (iVar6 != 0) {
    if ((piVar18 == (int *)0x0) || (iVar6 != 600)) goto LAB_;
    if ((*(byte *)piVar18 & 0x1f) != 0) {
      *(undefined4 *)((longlong)&uStackX_1c + lVar7) = 0x693b;
      (&stack0xffffffffffffffe0)[lVar7] = 5;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100954;
      lVar10 = (*_DAT_)(0x568,param_1,0x1173fd8,0x693b);
      *(longlong *)((longlong)&lStackX_20 + lVar7) = lVar10;
      if (lVar10 != 0) {
        *(undefined4 *)(&stack0xffffffffffffffe0 + lVar7) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100974;
        piVar11 = (int *)(*_DAT_)(lVar10,piVar18,600,param_1);
      }
      if (piVar11 == (int *)0x0) goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100982;
      lVar10 = (*_DAT_)();
      if ((*(char *)(lVar10 + 0x393) == '\0') || (lVar3 == 0)) {
        uStack_4118 = _DAT_;
        uStack_4114 = uRam000000000114e85c;
        uStack_4110 = uRam000000000114e860;
        uStack_410c = uRam000000000114e864;
        puVar12 = &uStack_4118;
      }
      else {
        plVar1 = *(longlong **)(lVar3 + 0x58);
        uVar27 = _DAT_;
        uVar28 = uRam000000000114e85c;
        uVar29 = uRam000000000114e860;
        uVar30 = uRam000000000114e864;
        if (plVar1 != (longlong *)0x0) {
          pcVar2 = *(code **)(*plVar1 + 0x98);
          *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1009a9;
          puVar12 = (undefined4 *)(*pcVar2)();
          uVar27 = *puVar12;
          uVar28 = puVar12[1];
          uVar29 = puVar12[2];
          uVar30 = puVar12[3];
        }
        auStack_4128._4_4_ = uVar28;
        auStack_4128._0_4_ = uVar27;
        auStack_4128._8_4_ = uVar29;
        auStack_4128._12_4_ = uVar30;
        puVar12 = (undefined4 *)auStack_4128;
      }
      (&stack0xffffffffffffffe8)[lVar7] = 0;
      *(undefined4 **)(&stack0xffffffffffffffe0 + lVar7) = puVar12;
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1009ef;
      (*_DAT_)(piVar11,0,0,0);
    }
  }
  *ppiVar25 = piVar11;
LAB_:
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100a07;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar7));
  return;
}

