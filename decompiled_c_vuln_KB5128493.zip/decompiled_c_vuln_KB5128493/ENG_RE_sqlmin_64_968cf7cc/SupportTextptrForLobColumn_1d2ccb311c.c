
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,short *param_3,uint *param_4)

{
  longlong *plVar1;
  bool bVar2;
  ushort uVar3;
  int iVar4;
  uint *puVar5;
  ulonglong *puVar6;
  uint uVar7;
  ulonglong uVar8;
  byte bVar9;
  ushort uVar10;
  uint uVar11;
  uint uVar12;
  ulonglong uVar13;
  undefined *puVar14;
  ushort *puVar15;
  short sVar16;
  byte *pbVar17;
  longlong lVar18;
  uint uVar19;
  longlong unaff_GS_OFFSET;
  undefined auStack_a8 [8];
  undefined8 uStack_a0;
  undefined auStack_98 [16];
  undefined8 uStack_88;
  undefined4 uStack_80;
  uint *puStack_78;
  uint uStack_70;
  uint auStack_68 [4];
  uint uStack_58;
  uint uStack_54;
  undefined auStack_50 [8];
  longlong *plStack_48;
  longlong lStack_40;
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)&uStack_58;
  puVar14 = auStack_98;
  plStack_48 = param_2;
  lStack_40 = param_1;
  if ((*(byte *)(*(longlong *)(param_1 + 8) + 0x107) & 0x40) == 0) goto LAB_;
  uStack_a0 = 0x100055;
  iVar4 = func_0x(param_2[6]);
  puVar14 = auStack_98;
  if ((((iVar4 == 0) ||
       (puVar14 = auStack_98, (*(ushort *)(*(longlong *)(param_4 + 0x12) + 0xc) & 0x40) == 0)) ||
      (puVar14 = auStack_98, *(short *)(param_4 + 0xf) != 0x10)) ||
     (puVar14 = auStack_98, (*(ushort *)(*(longlong *)(param_4 + 0x12) + 0xc) & 2) == 0))
  goto LAB_;
  puVar14 = auStack_a8;
  bVar2 = false;
  iVar4 = param_4[0x10] << 0xc;
  uVar19 = 0;
  if (*param_3 == 0) {
    uVar11 = *param_4;
    if ((uVar11 & 0xc0000000) == 0x80000000) {
      iVar4 = func_0x(param_3 + 1);
      if (iVar4 == 0) {
        uStack_58 = 0;
        puVar5 = (uint *)0x0;
      }
      else {
        puVar5 = (uint *)func_0x(param_3 + 0x15,param_4,&uStack_58,auStack_50);
      }
    }
    else {
      uStack_58 = uVar19;
      if ((iVar4 < 0) || ((*(byte *)((longlong)param_4 + 6) & 0x10) != 0)) {
        pbVar17 = *(byte **)(param_3 + 4);
        if ((*pbVar17 & 0x10) == 0) {
          if ((1 << (*pbVar17 & 0xe) & 0x1105U) != 0) goto LAB_;
          bVar2 = true;
          uVar12 = uVar19;
LAB_:
          if (iVar4 < 0) goto LAB_;
        }
        else {
          uVar12 = *(uint *)(param_3 + 8);
          if ((int)uVar12 <= (int)uVar11) {
LAB_:
            uVar12 = ~(uint)(*(ushort *)((longlong)param_4 + 6) >> 4) & 1;
            goto LAB_;
          }
          if ((uint)*(ushort *)(pbVar17 + uVar12) < (uint)*(ushort *)(param_4 + 1))
          goto LAB_;
          if (-1 < iVar4) goto LAB_;
          uVar7 = *(ushort *)(param_4 + 1) - 1;
          bVar2 = true;
          uVar12 = pbVar17[(ulonglong)uVar12 + (ulonglong)(uVar7 >> 3) + 2] >> ((byte)uVar7 & 7) & 1
          ;
LAB_:
          puVar5 = (uint *)0x0;
          if (uVar12 != 0) goto LAB_;
        }
        if ((!bVar2) && ((*(byte *)((longlong)param_4 + 6) & 0x10) != 0)) {
          puVar5 = *(uint **)(param_4 + 2) + 1;
          uStack_58 = **(uint **)(param_4 + 2);
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar11 < 0) {
        if (*(int *)(param_3 + 2) == 0) {
          pbVar17 = *(byte **)(param_3 + 4);
          uVar11 = *(uint *)(param_3 + 8);
          uVar13 = (ulonglong)uVar11;
          param_3[1] = 0;
          *(uint *)(param_3 + 10) = uVar11;
          bVar9 = *pbVar17;
          if ((bVar9 & 0x10) != 0) {
            uVar11 = uVar11 + 2 + (*(ushort *)(pbVar17 + uVar13) + 7 >> 3);
            uVar13 = (ulonglong)uVar11;
            *(uint *)(param_3 + 10) = uVar11;
            bVar9 = *pbVar17;
          }
          if ((bVar9 & 0x20) == 0) {
            *(int *)(param_3 + 2) = (int)uVar13;
            param_3[0xe] = 0;
            *(int *)(param_3 + 0xc) = (int)uVar13;
          }
          else {
            puVar15 = (ushort *)(pbVar17 + uVar13);
            uVar3 = *puVar15;
            param_3[0xe] = uVar3;
            if (uVar3 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar18 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar18 != 0)) &&
                 ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                  (*(char *)(lVar18 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_88 = (uint *)0x0;
                  (*_DAT_)(1,0x173db88,0x185d858,0x80f);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),3);
              uVar13 = (ulonglong)*(uint *)(param_3 + 10);
              uVar3 = param_3[0xe];
            }
            uVar11 = (int)uVar13 + (uVar3 + 1) * 2;
            *(uint *)(param_3 + 0xc) = uVar11;
            if (0x1f9e < uVar11) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar18 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar18 != 0 &&
                  ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                   (*(char *)(lVar18 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_88 = (uint *)0x0;
                  (*_DAT_)(1,0x173db88,0x185d858,0x816);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),4);
              uVar3 = param_3[0xe];
              uVar11 = *(uint *)(param_3 + 0xc);
            }
            uVar13 = (ulonglong)uVar3;
            uVar3 = puVar15[uVar13];
            *(uint *)(param_3 + 2) = uVar3 & 0x7fff;
            if ((uVar3 & 0x7fff) < uVar11) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar18 = *(longlong *)
                             (*(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                  lVar18 != 0)) &&
                 ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                  (*(char *)(lVar18 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_88 = (uint *)0x0;
                  (*_DAT_)(1,0x173db88,0x185d858,0x81d);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),4);
              uVar13 = (ulonglong)(ushort)param_3[0xe];
            }
            if ((short)puVar15[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
              pbVar17 = *(byte **)(param_3 + 4);
              do {
                if ((int)uVar13 == 1) {
                  uVar11 = *(uint *)(param_3 + 0xc);
                  uVar12 = uVar11;
LAB_:
                  if ((*(ushort *)(pbVar17 + uVar13 * 2 + (ulonglong)*(uint *)(param_3 + 10)) &
                      0x7fff) < uVar11) goto LAB_;
                }
                else {
                  uVar12 = *(uint *)(param_3 + 0xc);
                  uVar11 = *(ushort *)
                            (pbVar17 + uVar13 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                           0x7fff;
                  if (uVar12 <= uVar11) goto LAB_;
LAB_:
                  func_0x(pbVar17,7);
                  uVar12 = *(uint *)(param_3 + 0xc);
                }
                if ((uVar11 < uVar12) || (*(uint *)(param_3 + 2) < uVar11)) goto LAB_;
                pbVar17 = *(byte **)(param_3 + 4);
                if (*(ushort *)(pbVar17 + uVar11) == 5) {
                  param_3[1] = param_3[1] | 2;
                  param_3[0xe] = param_3[0xe] + -1;
                  param_3[0x15] = (short)uVar11;
                  lVar18 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(param_3 + 4);
                  uVar3 = param_3[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar18 + 2) >> 0xe & 1) != 0) {
                    uVar3 = *(ushort *)(lVar18 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
                  }
                  param_3[0x16] = uVar3;
                  param_3[0x16] = (uVar3 ^ *(ushort *)(lVar18 + 2)) & 0x7ff ^ uVar3;
                  goto LAB_;
                }
                if (*(ushort *)(pbVar17 + uVar11) < 0x400) goto LAB_;
                param_3[1] = param_3[1] | 1;
                uVar3 = param_3[0xe] - 1;
                param_3[0xe] = uVar3;
                if (uVar3 == 0) goto LAB_;
                uVar13 = (ulonglong)uVar3;
              } while ((short)puVar15[(ulonglong)(uVar3 - 1) + 1] < 0);
              uVar13 = (ulonglong)*(uint *)(param_3 + 2);
            }
            else {
LAB_:
              uVar13 = (ulonglong)*(uint *)(param_3 + 2);
              pbVar17 = *(byte **)(param_3 + 4);
            }
          }
          if ((*pbVar17 & 0x40) == 0) {
            *(undefined4 *)(param_3 + 0x13) = 0;
          }
          else {
            *(int *)(param_3 + 0x13) = (int)uVar13;
            *(int *)(param_3 + 2) = (int)uVar13 + 0xe;
            puVar6 = (ulonglong *)func_0x(param_3 + 1);
            uVar10 = (ushort)(*puVar6 >> 0x30);
            uVar3 = uVar10;
            if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
              uVar3 = uVar10 & 0xdfff;
              if ((uVar10 >> 0xe & 1) != 0) {
                uVar3 = uVar10 | 0x2000;
              }
            }
            uVar11 = uVar19;
            if (uVar3 == 0xfffc) {
              uVar11 = (uint)((*puVar6 >> 0x20 & 0xffff) >> 5);
            }
            *(uint *)(param_3 + 2) = *(int *)(param_3 + 2) + uVar11;
            uVar13 = (ulonglong)*(uint *)(param_3 + 2);
          }
          iVar4 = (int)uVar13;
          if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
             (*(ulonglong *)(param_3 + 0xf) < uVar13 + *(longlong *)(param_3 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar18 = *(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_), lVar18 != 0 &&
                 (lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0)) &&
                (*(char *)(lVar18 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_88 = (uint *)0x0;
                (*_DAT_)(1,0x173db88,0x185d858,0x877);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),0x12);
            iVar4 = *(int *)(param_3 + 2);
          }
          if (0x3f3b < iVar4 - 1U) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar18 = *(longlong *)
                           (*(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            + 8 + (ulonglong)*_DAT_), lVar18 != 0 &&
                ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
                 (*(char *)(lVar18 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_88 = (uint *)0x0;
                (*_DAT_)(1,0x173db88,0x185d858,0x87c);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),5);
          }
        }
LAB_:
        sVar16 = -*(short *)param_4;
        if ((*(byte *)((longlong)param_4 + 6) & 0x10) != 0) {
          bVar9 = **(byte **)(param_3 + 4);
          if ((bVar9 & 0x10) == 0) {
            if ((1 << (bVar9 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar5 = *(uint **)(param_4 + 2) + 1;
              uStack_58 = **(uint **)(param_4 + 2);
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_3 + 8) <= (int)*param_4) ||
                  (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                   *(ushort *)(param_4 + 1))) goto LAB_;
        }
        puVar5 = *(uint **)(param_3 + 4);
        lVar18 = (longlong)sVar16;
        if ((uint)(int)sVar16 <= (uint)(ushort)param_3[0xe]) {
          uVar11 = *(uint *)(param_3 + 10);
          if (sVar16 == 1) {
            uVar12 = *(uint *)(param_3 + 0xc);
            uVar11 = *(ushort *)((longlong)puVar5 + lVar18 * 2 + (ulonglong)uVar11) & 0x7fff;
LAB_:
            if (uVar11 < uVar12) goto LAB_;
          }
          else {
            puVar15 = (ushort *)((longlong)puVar5 + lVar18 * 2 + (ulonglong)uVar11);
            uVar12 = *(ushort *)((longlong)puVar5 + lVar18 * 2 + ((ulonglong)uVar11 - 2)) & 0x7fff;
            puVar5 = *(uint **)(param_3 + 4);
            uVar11 = *puVar15 & 0x7fff;
            if (*(uint *)(param_3 + 0xc) <= uVar12) goto LAB_;
LAB_:
            func_0x(puVar5,7);
            puVar5 = *(uint **)(param_3 + 4);
          }
          puVar5 = (uint *)((longlong)puVar5 + (ulonglong)uVar12);
          uStack_58 = uVar11 - uVar12;
        }
      }
      else {
        uVar3 = *(ushort *)((longlong)param_4 + 6);
        if ((uVar3 & 8) == 0) {
          if ((uVar3 & 0x10) != 0) {
            bVar9 = **(byte **)(param_3 + 4);
            if ((bVar9 & 0x10) == 0) {
              if ((1 << (bVar9 & 0xe) & 0x1105U) != 0) {
LAB_:
                uStack_58 = **(uint **)(param_4 + 2);
                puVar5 = *(uint **)(param_4 + 2) + 1;
                if (uStack_58 != 0x10) {
                  uStack_88 = (uint *)0x0;
                  (*_DAT_)(1,0x18eb8f8,0x18ea2f8,0x381);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_3 + 8) <= (int)uVar11) ||
                    (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                     *(ushort *)(param_4 + 1))) goto LAB_;
          }
          uStack_58 = 0x10;
          puVar5 = (uint *)((longlong)(int)uVar11 + *(longlong *)(param_3 + 4));
        }
        else {
          uStack_58 = 1;
          puVar5 = (uint *)0x14c25c4;
          if ((*(byte *)((longlong)(int)uVar11 + *(longlong *)(param_3 + 4)) &
              (byte)(1 << ((byte)uVar3 & 7))) == 0) {
            puVar5 = (uint *)0x14c2be8;
          }
        }
      }
    }
  }
  else {
    uStack_88 = &uStack_54;
    uStack_54 = 0;
    puVar5 = (uint *)func_0x(param_3 + 1,param_4,iVar4 >> 0x1f,&uStack_58);
    if (((*param_3 != 0) && (plVar1 = *(longlong **)(param_3 + 8), plVar1 != (longlong *)0x0)) &&
       ((*plVar1 != 0 && (((*(byte *)((longlong)param_4 + 6) & 8) == 0 && ((uStack_54 & 1) == 0)))))
       ) {
      if ((puVar5 == (uint *)0x0) || (puVar5 == (uint *)0x14c25c4)) {
        uStack_58 = 0;
        puVar5 = (uint *)0x0;
      }
      else {
        uStack_70 = uStack_54;
        uStack_80 = 0x10;
        uStack_88 = auStack_68;
        puStack_78 = &uStack_58;
        puVar5 = (uint *)func_0x(plVar1,param_4,puVar5,uStack_58);
      }
    }
  }
LAB_:
  if (*param_3 == 0) {
    if (*(int *)(param_3 + 2) == 0) {
      pbVar17 = *(byte **)(param_3 + 4);
      uVar11 = *(uint *)(param_3 + 8);
      uVar13 = (ulonglong)uVar11;
      param_3[1] = 0;
      *(uint *)(param_3 + 10) = uVar11;
      bVar9 = *pbVar17;
      if ((bVar9 & 0x10) != 0) {
        uVar11 = uVar11 + 2 + (*(ushort *)(pbVar17 + uVar13) + 7 >> 3);
        uVar13 = (ulonglong)uVar11;
        *(uint *)(param_3 + 10) = uVar11;
        bVar9 = *pbVar17;
      }
      if ((bVar9 & 0x20) == 0) {
        *(int *)(param_3 + 2) = (int)uVar13;
        param_3[0xe] = 0;
        *(int *)(param_3 + 0xc) = (int)uVar13;
      }
      else {
        puVar15 = (ushort *)(pbVar17 + uVar13);
        uVar3 = *puVar15;
        param_3[0xe] = uVar3;
        if (uVar3 == 0) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_88 = (uint *)0x0;
              (*_DAT_)(1,0x173db88,0x185d858,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),3);
          uVar13 = (ulonglong)*(uint *)(param_3 + 10);
          uVar3 = param_3[0xe];
        }
        uVar11 = (int)uVar13 + (uVar3 + 1) * 2;
        *(uint *)(param_3 + 0xc) = uVar11;
        if (0x1f9e < uVar11) {
          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
             ((lVar18 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar18 != 0 &&
              ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
               (*(char *)(lVar18 + 0x499) != '\0')))))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_88 = (uint *)0x0;
              (*_DAT_)(1,0x173db88,0x185d858,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),4);
          uVar3 = param_3[0xe];
          uVar11 = *(uint *)(param_3 + 0xc);
        }
        uVar8 = (ulonglong)uVar3;
        uVar12 = puVar15[uVar8] & 0x7fff;
        *(uint *)(param_3 + 2) = uVar12;
        if (uVar12 < uVar11) {
          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
              (lVar18 = *(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_), lVar18 != 0)) &&
             ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
              (*(char *)(lVar18 + 0x499) != '\0')))) {
            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_88 = (uint *)0x0;
              (*_DAT_)(1,0x173db88,0x185d858,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),4);
          uVar8 = (ulonglong)(ushort)param_3[0xe];
          uVar12 = *(uint *)(param_3 + 2);
        }
        uVar13 = (ulonglong)uVar12;
        if ((short)puVar15[(ulonglong)((int)uVar8 - 1) + 1] < 0) {
          pbVar17 = *(byte **)(param_3 + 4);
          do {
            if ((int)uVar8 == 1) {
              uVar11 = *(uint *)(param_3 + 0xc);
              uVar12 = uVar11;
LAB_:
              if ((*(ushort *)(pbVar17 + uVar8 * 2 + (ulonglong)*(uint *)(param_3 + 10)) & 0x7fff) <
                  uVar11) goto LAB_;
            }
            else {
              uVar12 = *(uint *)(param_3 + 0xc);
              uVar11 = *(ushort *)(pbVar17 + uVar8 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                       0x7fff;
              if (uVar12 <= uVar11) goto LAB_;
LAB_:
              func_0x(pbVar17,7);
              uVar12 = *(uint *)(param_3 + 0xc);
            }
            if ((uVar11 < uVar12) ||
               (uVar13 = (ulonglong)*(uint *)(param_3 + 2), *(uint *)(param_3 + 2) < uVar11))
            goto LAB_;
            pbVar17 = *(byte **)(param_3 + 4);
            if (*(ushort *)(pbVar17 + uVar11) == 5) {
              param_3[1] = param_3[1] | 2;
              param_3[0xe] = param_3[0xe] + -1;
              param_3[0x15] = (short)uVar11;
              lVar18 = (ulonglong)(uVar11 & 0xffff) + *(longlong *)(param_3 + 4);
              uVar3 = param_3[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar18 + 2) >> 0xe & 1) != 0) {
                uVar3 = *(ushort *)(lVar18 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
              }
              param_3[0x16] = uVar3;
              param_3[0x16] = (uVar3 ^ *(ushort *)(lVar18 + 2)) & 0x7ff ^ uVar3;
              uVar13 = (ulonglong)*(uint *)(param_3 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar17 + uVar11) < 0x400) goto LAB_;
            param_3[1] = param_3[1] | 1;
            uVar3 = param_3[0xe] - 1;
            param_3[0xe] = uVar3;
            if (uVar3 == 0) goto LAB_;
            uVar8 = (ulonglong)uVar3;
          } while ((short)puVar15[(ulonglong)(uVar3 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar17 = *(byte **)(param_3 + 4);
        }
      }
      if ((*pbVar17 & 0x40) == 0) {
        *(undefined4 *)(param_3 + 0x13) = 0;
      }
      else {
        *(int *)(param_3 + 0x13) = (int)uVar13;
        *(int *)(param_3 + 2) = (int)uVar13 + 0xe;
        puVar6 = (ulonglong *)func_0x(param_3 + 1);
        uVar10 = (ushort)(*puVar6 >> 0x30);
        uVar3 = uVar10;
        if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
          uVar3 = uVar10 & 0xdfff;
          if ((uVar10 >> 0xe & 1) != 0) {
            uVar3 = uVar10 | 0x2000;
          }
        }
        if (uVar3 == 0xfffc) {
          uVar19 = (uint)((*puVar6 >> 0x20 & 0xffff) >> 5);
        }
        *(uint *)(param_3 + 2) = *(int *)(param_3 + 2) + uVar19;
        uVar13 = (ulonglong)*(uint *)(param_3 + 2);
      }
      iVar4 = (int)uVar13;
      if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
         (*(ulonglong *)(param_3 + 0xf) < uVar13 + *(longlong *)(param_3 + 4))) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           (((lVar18 = *(longlong *)
                        (*(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                         8 + (ulonglong)*_DAT_), lVar18 != 0 &&
             (lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0)) &&
            (*(char *)(lVar18 + 0x499) != '\0')))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_88 = (uint *)0x0;
            (*_DAT_)(1,0x173db88,0x185d858,0x877);
          }
        }
        func_0x(*(undefined8 *)(param_3 + 4),0x12);
        iVar4 = *(int *)(param_3 + 2);
      }
      if (0x3f3b < iVar4 - 1U) {
        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
           ((lVar18 = *(longlong *)
                       (*(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
                       + (ulonglong)*_DAT_), lVar18 != 0 &&
            ((lVar18 = *(longlong *)(lVar18 + 0x60), lVar18 != 0 &&
             (*(char *)(lVar18 + 0x499) != '\0')))))) {
          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_88 = (uint *)0x0;
            (*_DAT_)(1,0x173db88,0x185d858,0x87c);
          }
        }
        func_0x(*(undefined8 *)(param_3 + 4),5);
      }
    }
LAB_:
    uVar19 = *(uint *)(param_3 + 2);
    if (uVar19 < 9) {
      bVar9 = **(byte **)(param_3 + 4) & 0xe;
joined_r0x0010103b:
      if ((bVar9 == 0) || (bVar9 == 0xc)) {
        uVar19 = 9;
      }
    }
  }
  else {
    uVar19 = *(uint *)(param_3 + 2);
    if (uVar19 == 0) {
      func_0x(param_3 + 1);
      uVar19 = *(uint *)(param_3 + 2);
    }
    if (uVar19 < 9) {
      bVar9 = **(byte **)(param_3 + 4) & 0x1c;
      goto joined_r0x0010103b;
    }
  }
  uStack_88 = (uint *)CONCAT44(uStack_88._4_4_,uVar19);
  (**(code **)(*plStack_48 + 200))
            (plStack_48,(longlong)*(int *)(lStack_40 + 0x14),puVar5,*(undefined8 *)(param_3 + 4));
LAB_:
  *(undefined8 *)(puVar14 + -8) = 0x101076;
  func_0x(uStack_38 ^ (ulonglong)&uStack_58);
  return;
}

