
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  ushort uVar4;
  longlong **pplVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  bool bVar9;
  char cVar10;
  char cVar11;
  undefined uVar12;
  byte bVar13;
  byte bVar14;
  byte bVar15;
  short sVar16;
  undefined2 uVar17;
  ushort uVar18;
  int iVar19;
  uint uVar20;
  int iVar21;
  undefined4 uVar22;
  longlong lVar23;
  longlong lVar24;
  undefined8 uVar25;
  undefined8 uVar26;
  longlong lVar27;
  longlong lVar28;
  longlong *plVar29;
  ulonglong uVar30;
  undefined8 uVar31;
  undefined8 *puVar32;
  undefined4 *puVar33;
  ulonglong uVar34;
  longlong lVar35;
  code *UNRECOVERED_JUMPTABLE;
  undefined *puVar36;
  longlong **pplVar37;
  undefined8 *puVar38;
  longlong unaff_GS_OFFSET;
  longlong lStackX_8;
  undefined8 uStackX_10;
  longlong lStackX_18;
  undefined8 uStackX_20;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar23 = func_0x();
  lVar23 = -lVar23;
  piVar2 = (int *)(&stack0x00000050 + lVar23);
  *(undefined8 *)(&stack0x00000918 + lVar23) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000079f0 + lVar23) = _DAT_ ^ (ulonglong)piVar2;
  *(undefined8 *)(&stack0x00000080 + lVar23) = param_4;
  *(undefined8 *)(&stack0x000000b8 + lVar23) = param_3;
  *(longlong *)(&stack0x000001f8 + lVar23) = param_2;
  *(longlong **)(&stack0x00000078 + lVar23) = param_1;
  cVar10 = (&stack0x00007a70)[lVar23];
  (&stack0x00000058)[lVar23] = cVar10;
  pplVar5 = *(longlong ***)(&stack0x00007a80 + lVar23);
  *(undefined4 *)(&stack0x00000408 + lVar23) = *(undefined4 *)(param_2 + 0x18);
  *(undefined2 *)(&stack0x0000040c + lVar23) = *(undefined2 *)(param_2 + 0x1c);
  *(undefined **)(&stack0xffffffffffffffe0 + lVar23) = &stack0x00000408 + lVar23;
  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1000a2;
  func_0x(&stack0x00001608 + lVar23,param_1 + 299);
  uVar31 = 0;
  *(undefined4 *)(&stack0x000002a0 + lVar23) = 0;
  *(undefined4 *)(&stack0x00000308 + lVar23) = 0;
  *(undefined4 *)(&stack0x00000354 + lVar23) = 0;
  *(undefined4 *)(&stack0x000004e4 + lVar23) = 0;
  *(undefined4 *)(&stack0x000004e8 + lVar23) = 0;
  *piVar2 = 0;
  *(undefined4 *)(&stack0x000002a4 + lVar23) = 0;
  *(undefined4 *)(&stack0x0000028c + lVar23) = 0;
  *(undefined4 *)(&stack0x00000288 + lVar23) = 0;
  (&stack0x00000099)[lVar23] = 0;
  (&stack0x00000055)[lVar23] = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1000f6;
  func_0x(&stack0x00000938 + lVar23);
  pplVar37 = (longlong **)(&stack0x00000938 + lVar23);
  *(longlong ***)(&stack0x00000070 + lVar23) = pplVar37;
  (&stack0x00000054)[lVar23] = 0;
  (&stack0x0000005c)[lVar23] = 0;
  (&stack0x00000088)[lVar23] = 0;
  if (pplVar5 == (longlong **)0x0) {
    bVar9 = false;
  }
  else {
    if (cVar10 == '\0') {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10013d;
      (*_DAT_)(1,0x14985b8,0x1463170,0x2a93);
    }
    *(longlong ***)(&stack0x00000070 + lVar23) = pplVar5;
    bVar9 = true;
    (&stack0x00000055)[lVar23] = 1;
    pplVar37 = pplVar5;
  }
  *(undefined8 *)(&stack0x000000c0 + lVar23) = 0;
  *(undefined4 *)(&stack0x00000060 + lVar23) = 1;
  if ((bVar9) && ((3 < *(short *)((longlong)pplVar37 + 0xc) || (*pplVar37 != (longlong *)0x0)))) {
    bVar9 = true;
  }
  else {
    bVar9 = false;
  }
  if (param_1[0xbfd] != 0) {
    uVar17 = *(undefined2 *)(param_2 + 0x1c);
    uVar25 = *(undefined8 *)(*param_1 + 0x6a0);
    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100190;
    lVar24 = func_0x(uVar25,uVar17,0);
    if (((*(byte *)(lVar24 + 0x7c) & 0x20) != 0) && ((*(byte *)(lVar24 + 0x1fc) & 4) != 0)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1001ab;
      func_0x(&stack0x00000178 + lVar23);
      *(undefined4 *)(&stack0x000002a0 + lVar23) = 1;
    }
  }
  if ((*(char *)(param_2 + 0x16) == '|') && ((*(byte *)(*param_1 + 0x1cd0) & 0x40) == 0)) {
    sVar16 = *(short *)(*(longlong *)(*param_1 + 0x6b0) + 0x28);
    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1001e3;
    cVar10 = func_0x(0x19ed480);
    if (cVar10 != '\0') {
      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1001f2;
      lVar24 = func_0x();
      if ((((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) && (sVar16 != 1)) &&
         (sVar16 != 0x7ffb)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100217;
        cVar10 = func_0x(0x19ed480);
        if (cVar10 == '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100231;
          (*_DAT_)(0x22,0x44,0x15,0x26);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100254;
          (*_DAT_)(1,0x1317f10,0x1317f50,0x2ac4);
        }
      }
    }
    if ((bVar9) && (*pplVar37 != (longlong *)0x0)) {
      if (((*(ushort *)((longlong)*pplVar37 + 0x62) >> 10 & 1) == 0) ||
         (*(short *)((longlong)pplVar37 + 0xc) < 3)) {
        iVar19 = (int)*(short *)((longlong)pplVar37 + 0xc);
        plVar29 = *pplVar37;
        if (((byte)*(undefined2 *)((longlong)plVar29 + 0x62) >> 3 & 1) != 0) {
          if (iVar19 == 3) {
            iVar19 = 4;
          }
          else if (iVar19 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plVar29 + 100) & 8) != 0) &&
              (lVar24 = plVar29[0x12], lVar24 != 0)) && (*(longlong *)(lVar24 + 0x758) != 0)) {
            uVar25 = *(undefined8 *)(lVar24 + 0x758);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1002e3;
            func_0x(uVar25,plVar29,iVar19);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
            (2 < iVar19)) &&
           (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 && (*plVar29 != 0)))) {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100318;
          func_0x(plVar29,1);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100327;
        func_0x(plVar29 + 0x13,iVar19);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100346;
          func_0x(plVar29,0,iVar19);
        }
        *(undefined2 *)((longlong)pplVar37 + 0xc) = 0;
        *pplVar37 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100284;
        func_0x(pplVar37);
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10035a;
    iVar19 = func_0x();
    puVar38 = *(undefined8 **)(&stack0x000000b8 + lVar23);
    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10037d;
    func_0x(param_2,puVar38,iVar19 != 0 && sVar16 == 0x7ffb);
    lVar24 = *(longlong *)(&stack0x00007a88 + lVar23);
    if (lVar24 != 0) {
      *(longlong *)(lVar24 + 0x30) = *(longlong *)(lVar24 + 0x30) + 1;
    }
    plVar29 = *(longlong **)(*(longlong *)(&stack0x00000078 + lVar23) + 0x5f80);
    lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
    if (plVar29 != (longlong *)0x0) {
      uVar31 = *(undefined8 *)
                (*plVar29 +
                ((ulonglong)*(uint *)(lVar24 + 0x10) % (ulonglong)*(uint *)(plVar29 + 1)) * 8);
    }
    *(undefined8 *)(&stack0x000003e8 + lVar23) = *puVar38;
    *(undefined2 *)(&stack0x000003f0 + lVar23) = *(undefined2 *)(puVar38 + 1);
    *(undefined2 *)(lVar24 + 0x22) = 0xded0;
    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1003e3;
    iVar19 = func_0x(lVar24 + 0x24);
    *(undefined8 *)(lVar24 + 0x24) = *(undefined8 *)(&stack0x000003e8 + lVar23);
    *(undefined2 *)(lVar24 + 0x2c) = *(undefined2 *)(&stack0x000003f0 + lVar23);
    *(int *)(lVar24 + 0x30) = iVar19 + 2;
    *(undefined8 *)(&stack0x00000578 + lVar23) = *(undefined8 *)(&stack0x000003e8 + lVar23);
    *(undefined2 *)(&stack0x00000580 + lVar23) = *(undefined2 *)(&stack0x000003f0 + lVar23);
    puVar36 = &stack0x00000578 + lVar23;
  }
  else {
    uVar17 = *(undefined2 *)(param_2 + 0x1c);
    uVar25 = *(undefined8 *)(*param_1 + 0x6a0);
    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100447;
    lVar24 = func_0x(uVar25,uVar17,1);
    if ((*(byte *)(*param_1 + 0x1cd0) & 0x40) == 0) {
LAB_:
      if ((lVar24 != 0) && (*(uint *)(param_2 + 0x18) < *(uint *)(lVar24 + 0x80))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10053f;
        func_0x(&stack0x000012f8 + lVar23,0,0,0);
        lVar35 = *(longlong *)(*param_1 + 0x6b0);
        if (((*(byte *)(lVar35 + 0x3c) & 1) != 0) && (*(longlong *)(lVar35 + 0x280) == 0)) {
          plVar29 = *(longlong **)(*param_1 + 0x6c8);
          UNRECOVERED_JUMPTABLE = *(code **)(*plVar29 + 0x170);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100570;
          (*UNRECOVERED_JUMPTABLE)(plVar29,&stack0x000012f8 + lVar23);
        }
        if (*(char *)(param_2 + 0x16) == '\x01') {
          if (bVar9) {
            pplVar37 = *(longlong ***)(&stack0x00000070 + lVar23);
            if (*pplVar37 != (longlong *)0x0) {
              if (((*(ushort *)((longlong)*pplVar37 + 0x62) >> 10 & 1) == 0) ||
                 (*(short *)((longlong)pplVar37 + 0xc) < 3)) {
                iVar19 = (int)*(short *)((longlong)pplVar37 + 0xc);
                *(int *)(&stack0x00000060 + lVar23) = iVar19;
                plVar29 = *pplVar37;
                if (((byte)*(undefined2 *)((longlong)plVar29 + 0x62) >> 3 & 1) != 0) {
                  if (iVar19 == 3) {
                    iVar19 = 4;
                    *(undefined4 *)(&stack0x00000060 + lVar23) = 4;
                  }
                  else if (iVar19 < 2) goto LAB_;
                  if ((((*(uint *)((longlong)plVar29 + 100) & 8) != 0) &&
                      (lVar35 = plVar29[0x12], lVar35 != 0)) && (*(longlong *)(lVar35 + 0x758) != 0)
                     ) {
                    uVar25 = *(undefined8 *)(lVar35 + 0x758);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10060a;
                    func_0x(uVar25,plVar29,iVar19);
                  }
                }
LAB_:
                if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)
                    ) && ((2 < *(int *)(&stack0x00000060 + lVar23) &&
                          (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 &&
                           (*plVar29 != 0)))))) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10063f;
                  func_0x(plVar29,1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10064e;
                func_0x(plVar29 + 0x13,*(undefined4 *)(&stack0x00000060 + lVar23));
                if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10066e;
                  func_0x(plVar29,0,*(undefined4 *)(&stack0x00000060 + lVar23));
                }
                puVar38 = *(undefined8 **)(&stack0x00000070 + lVar23);
                *(undefined2 *)((longlong)puVar38 + 0xc) = 0;
                *puVar38 = 0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1005aa;
                func_0x();
              }
            }
          }
          if ((&stack0x00000055)[lVar23] != '\0') {
            LOCK();
            iVar19 = *(int *)(*(longlong *)(&stack0x00000080 + lVar23) + 0x9c);
            if (iVar19 == 0) {
              *(int *)(*(longlong *)(&stack0x00000080 + lVar23) + 0x9c) = 0;
              iVar19 = 0;
            }
            UNLOCK();
            if (iVar19 == 0) {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1006b4;
              (*_DAT_)(1,0x1498578,0x1463170,0x2b0c);
            }
          }
          if ((*(int *)(param_1 + 4) == 1) && (*(char *)(param_2 + 0x33) == '\x01')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1006dd;
            func_0x(&stack0x000007b8 + lVar23,0,0,0);
            puVar38 = *(undefined8 **)(&stack0x000000b8 + lVar23);
            *(undefined8 *)(&stack0x00000598 + lVar23) = *puVar38;
            *(undefined2 *)(&stack0x000005a0 + lVar23) = *(undefined2 *)(puVar38 + 1);
            *(undefined *)((longlong)&lStackX_8 + lVar23) = 0;
            *(undefined *)((longlong)&uStackX_20 + lVar23 + -0x20) = 0;
            (&stack0xfffffffffffffff8)[lVar23] = 0;
            (&stack0xfffffffffffffff0)[lVar23] = (&stack0x0000005c)[lVar23];
            (&stack0xffffffffffffffe8)[lVar23] = (&stack0x00000054)[lVar23];
            (&stack0xffffffffffffffe0)[lVar23] = 1;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100735;
            func_0x(param_1,param_2,&stack0x00000598 + lVar23,&stack0x000007b8 + lVar23);
            lVar24 = *(longlong *)(&stack0x00007a88 + lVar23);
            if (lVar24 != 0) {
              *(longlong *)(lVar24 + 0x30) = *(longlong *)(lVar24 + 0x30) + 1;
            }
            plVar29 = (longlong *)param_1[0xbf0];
            lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
            if (plVar29 != (longlong *)0x0) {
              uVar31 = *(undefined8 *)
                        (*plVar29 +
                        ((ulonglong)*(uint *)(lVar24 + 0x10) % (ulonglong)*(uint *)(plVar29 + 1)) *
                        8);
            }
            *(undefined8 *)(&stack0x00000388 + lVar23) = *puVar38;
            *(undefined2 *)(&stack0x00000390 + lVar23) = *(undefined2 *)(puVar38 + 1);
            *(undefined2 *)(lVar24 + 0x22) = 0xfed0;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100797;
            iVar19 = func_0x(lVar24 + 0x24);
            *(undefined8 *)(lVar24 + 0x24) = *(undefined8 *)(&stack0x00000388 + lVar23);
            *(undefined2 *)(lVar24 + 0x2c) = *(undefined2 *)(&stack0x00000390 + lVar23);
            *(int *)(lVar24 + 0x30) = iVar19 + 2;
            *(undefined8 *)(&stack0x000005a8 + lVar23) = *(undefined8 *)(&stack0x00000388 + lVar23);
            *(undefined2 *)(&stack0x000005b0 + lVar23) = *(undefined2 *)(&stack0x00000390 + lVar23);
            puVar36 = &stack0x000005a8 + lVar23;
            goto LAB_;
          }
          if (((*(byte *)(*(longlong *)(*param_1 + 0x6b0) + 0x3c) & 1) == 0) ||
             (*(longlong *)(*(longlong *)(*param_1 + 0x6b0) + 0x280) != 0)) {
            uVar12 = 0;
          }
          else {
            uVar22 = *(undefined4 *)(param_2 + 0x18);
            uVar25 = *(undefined8 *)(&stack0x000000b8 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100821;
            (*_DAT_)(lVar24,uVar25,&stack0x000012f8 + lVar23,uVar22);
            if ((&stack0x00007a78)[lVar23] == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10083a;
              cVar11 = func_0x(0x19ed480);
              if (cVar11 == '\0') {
                uVar12 = 0;
                *(undefined **)(&stack0xffffffffffffffe8 + lVar23) = &stack0x0000005c + lVar23;
                *(undefined **)(&stack0xffffffffffffffe0 + lVar23) = &stack0x00000054 + lVar23;
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100867;
                iVar19 = func_0x(param_1,lVar24,param_2,uVar25);
                if (iVar19 != 0) {
                  plVar29 = (longlong *)param_1[0xbf0];
                  lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
                  if (plVar29 != (longlong *)0x0) {
                    uVar31 = *(undefined8 *)
                              (*plVar29 +
                              ((ulonglong)*(uint *)(lVar24 + 0x10) %
                              (ulonglong)*(uint *)(plVar29 + 1)) * 8);
                  }
                  *(undefined8 *)(&stack0x00000378 + lVar23) =
                       **(undefined8 **)(&stack0x000000b8 + lVar23);
                  *(undefined2 *)(&stack0x00000380 + lVar23) =
                       *(undefined2 *)(*(undefined8 **)(&stack0x000000b8 + lVar23) + 1);
                  *(undefined2 *)(lVar24 + 0x22) = 0x5ed0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1008c1;
                  iVar19 = func_0x(lVar24 + 0x24);
                  *(undefined8 *)(lVar24 + 0x24) = *(undefined8 *)(&stack0x00000378 + lVar23);
                  *(undefined2 *)(lVar24 + 0x2c) = *(undefined2 *)(&stack0x00000380 + lVar23);
                  *(int *)(lVar24 + 0x30) = iVar19 + 2;
                  *(undefined8 *)(&stack0x00000568 + lVar23) =
                       *(undefined8 *)(&stack0x00000378 + lVar23);
                  *(undefined2 *)(&stack0x00000570 + lVar23) =
                       *(undefined2 *)(&stack0x00000380 + lVar23);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100911;
                  func_0x(lVar24,&stack0x00000568 + lVar23,uVar31);
                  lVar24 = *(longlong *)(&stack0x00007a88 + lVar23);
                  if (lVar24 != 0) {
                    *(longlong *)(lVar24 + 0x18) = *(longlong *)(lVar24 + 0x18) + 1;
                  }
                  goto LAB_;
                }
                goto LAB_;
              }
            }
            uVar12 = 1;
          }
LAB_:
          *(undefined4 *)(&stack0x00000410 + lVar23) = *(undefined4 *)(param_2 + 0x18);
          *(undefined2 *)(&stack0x00000414 + lVar23) = *(undefined2 *)(param_2 + 0x1c);
          (&stack0xffffffffffffffe8)[lVar23] = cVar10;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = 0;
          lVar35 = *param_1;
          pplVar37 = *(longlong ***)(&stack0x00000070 + lVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100974;
          func_0x(_DAT_,pplVar37,lVar35,&stack0x00000410 + lVar23);
          lVar35 = *(longlong *)(&stack0x00007a88 + lVar23);
          if (lVar35 != 0) {
            *(longlong *)(lVar35 + 0x10) = *(longlong *)(lVar35 + 0x10) + 1;
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10099c;
          func_0x(&stack0x000007d8 + lVar23,1);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1009aa;
          func_0x(pplVar37,0,0);
          plVar29 = *pplVar37;
          *(undefined4 *)(&stack0x00000416 + lVar23) = *(undefined4 *)(param_2 + 0x18);
          *(undefined2 *)(&stack0x0000041a + lVar23) = *(undefined2 *)(param_2 + 0x1c);
          plVar6 = *(longlong **)(&stack0x00000078 + lVar23);
          if (*(int *)(*(longlong *)(*plVar6 + 0x7a8) + 0x110) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1009ec;
            iVar19 = func_0x(&stack0x00000416 + lVar23,8);
            if (iVar19 == 0) {
              *(undefined4 *)(&stack0x0000041c + lVar23) = *(undefined4 *)(param_2 + 0x18);
              *(undefined2 *)(&stack0x00000420 + lVar23) = *(undefined2 *)(param_2 + 0x1c);
              uVar25 = *(undefined8 *)(*plVar6 + 0x7a8);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100a1d;
              func_0x(uVar25,&stack0x0000041c + lVar23);
            }
          }
          if ((*(short *)(param_2 + 2) == 0x4c) || (*(short *)(param_2 + 0x50) == 0)) {
            uVar17 = *(undefined2 *)(param_2 + 0x2e);
            uVar22 = *(undefined4 *)(param_2 + 0x20);
            *(undefined4 *)(&stack0x000002a8 + lVar23) = *(undefined4 *)(param_2 + 0x18);
            *(undefined2 *)(&stack0x000002ac + lVar23) = *(undefined2 *)(param_2 + 0x1c);
            if ((*(uint *)(lVar24 + 100) >> 8 & 1) != 0) {
              *(undefined2 *)(&stack0x000002ac + lVar23) = *(undefined2 *)(lVar24 + 0x5f0);
            }
            *(undefined4 *)(&stack0x00000498 + lVar23) = uVar22;
            *(undefined2 *)(&stack0x0000049c + lVar23) = uVar17;
            *(undefined2 *)(&stack0x0000049e + lVar23) = 0;
            puVar38 = *(undefined8 **)(&stack0x000000b8 + lVar23);
            *(undefined8 **)((longlong)&uStackX_10 + lVar23) = puVar38;
            *(longlong *)((longlong)&lStackX_8 + lVar23) = param_2 + 0x3c;
            *(longlong *)((longlong)&uStackX_20 + lVar23 + -0x20) = param_2 + 0x34;
            (&stack0xfffffffffffffff8)[lVar23] = *(undefined *)(param_2 + 0x32);
            *(undefined2 *)(&stack0xfffffffffffffff0 + lVar23) = *(undefined2 *)(param_2 + 0x3a);
            (&stack0xffffffffffffffe8)[lVar23] = *(undefined *)(param_2 + 0x31);
            *(undefined2 *)(&stack0xffffffffffffffe0 + lVar23) = *(undefined2 *)(param_2 + 0x42);
            uVar3 = *(undefined *)(param_2 + 0x30);
            lVar24 = *plVar29;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100af9;
            func_0x(lVar24,uVar3,&stack0x000002a8 + lVar23,&stack0x00000498 + lVar23);
            lVar24 = *plVar29;
            cVar10 = *(char *)(lVar24 + 1);
            if (cVar10 == '\n') {
              uVar22 = *(undefined4 *)(param_2 + 0x4c);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100b4e;
              func_0x(lVar24,param_2 + 0x44,uVar22);
            }
            else if (cVar10 == '\x10') {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100b30;
              uVar25 = func_0x();
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100b3f;
              func_0x(uVar25,&stack0x000002a8 + lVar23);
            }
            else if (cVar10 == '\x11') {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100b14;
              uVar25 = func_0x();
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100b29;
              func_0x(uVar25,&stack0x000002a8 + lVar23,0x11,0);
            }
          }
          else {
            lVar24 = *plVar29;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100a38;
            func_0x(param_2,lVar24);
            lVar24 = *plVar29;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100a46;
            func_0x(plVar6,param_2,lVar24);
            puVar38 = *(undefined8 **)(&stack0x000000b8 + lVar23);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100b62;
          func_0x(&stack0x000007c8 + lVar23,0,0,0);
          *(undefined8 *)(&stack0x000005b8 + lVar23) = *puVar38;
          *(undefined2 *)(&stack0x000005c0 + lVar23) = *(undefined2 *)(puVar38 + 1);
          *(undefined *)((longlong)&lStackX_8 + lVar23) = 0;
          *(undefined *)((longlong)&uStackX_20 + lVar23 + -0x20) = 0;
          (&stack0xfffffffffffffff8)[lVar23] = uVar12;
          (&stack0xfffffffffffffff0)[lVar23] = (&stack0x0000005c)[lVar23];
          (&stack0xffffffffffffffe8)[lVar23] = (&stack0x00000054)[lVar23];
          (&stack0xffffffffffffffe0)[lVar23] = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100bb8;
          func_0x(plVar6,param_2,&stack0x000005b8 + lVar23,&stack0x000007c8 + lVar23);
          uVar17 = *(undefined2 *)((longlong)plVar29 + 0x62);
          *(undefined4 *)(&stack0x00000424 + lVar23) = *(undefined4 *)(param_2 + 0x18);
          *(undefined2 *)(&stack0x00000428 + lVar23) = *(undefined2 *)(param_2 + 0x1c);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100be4;
          uVar12 = func_0x(&stack0x00000424 + lVar23);
          lVar24 = *plVar29;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100bf7;
          func_0x(lVar24,puVar38,uVar12,(byte)uVar17 >> 3 & 1);
          plVar7 = (longlong *)plVar6[0xbf0];
          lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
          if (plVar7 != (longlong *)0x0) {
            uVar31 = *(undefined8 *)
                      (*plVar7 +
                      ((ulonglong)*(uint *)(lVar24 + 0x10) % (ulonglong)*(uint *)(plVar7 + 1)) * 8);
          }
          *(undefined8 *)(&stack0x00000368 + lVar23) = *puVar38;
          *(undefined2 *)(&stack0x00000370 + lVar23) = *(undefined2 *)(puVar38 + 1);
          *(undefined2 *)(lVar24 + 0x22) = 0xfed0;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100c46;
          iVar19 = func_0x(lVar24 + 0x24);
          *(undefined8 *)(lVar24 + 0x24) = *(undefined8 *)(&stack0x00000368 + lVar23);
          *(undefined2 *)(lVar24 + 0x2c) = *(undefined2 *)(&stack0x00000370 + lVar23);
          *(int *)(lVar24 + 0x30) = iVar19 + 2;
          *(undefined8 *)(&stack0x000005c8 + lVar23) = *(undefined8 *)(&stack0x00000368 + lVar23);
          *(undefined2 *)(&stack0x000005d0 + lVar23) = *(undefined2 *)(&stack0x00000370 + lVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100c99;
          func_0x(lVar24,&stack0x000005c8 + lVar23,uVar31);
          if (*(int *)(&stack0x000002a0 + lVar23) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100cb3;
            func_0x(plVar29,1);
          }
          puVar38 = *(undefined8 **)(&stack0x00000070 + lVar23);
          if ((*(byte *)((longlong)plVar6 + 0x24) & 4) != 0) {
            uVar31 = *puVar38;
            uVar25 = *(undefined8 *)(*plVar6 + 0x758);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100cd5;
            func_0x(uVar25,uVar31,1);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100ce9;
          func_0x(&stack0x000014c0 + lVar23,0,0,0);
          uVar31 = *puVar38;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100d02;
          func_0x(_DAT_,uVar31,0,&stack0x000014c0 + lVar23);
          if (lVar35 != 0) {
            *(longlong *)(lVar35 + 0x30) = *(longlong *)(lVar35 + 0x30) + 1;
          }
          *(uint *)(*(longlong *)(&stack0x000007e0 + lVar23) + 0x268) =
               *(uint *)(*(longlong *)(&stack0x000007e0 + lVar23) + 0x268) &
               ~*(uint *)(&stack0x000007d8 + lVar23);
          goto LAB_;
        }
        uVar25 = *(undefined8 *)(*(longlong *)(*param_1 + 0x6b0) + 0x1210);
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100d42;
        iVar19 = func_0x(uVar25);
        if (((iVar19 == 1) && (*(char *)(param_2 + 0x16) == '\x04')) &&
           (*(char *)(param_2 + 0x17) == '\x14')) {
          if (bVar9) {
            pplVar37 = *(longlong ***)(&stack0x00000070 + lVar23);
            if (*pplVar37 != (longlong *)0x0) {
              if (((*(ushort *)((longlong)*pplVar37 + 0x62) >> 10 & 1) == 0) ||
                 (*(short *)((longlong)pplVar37 + 0xc) < 3)) {
                iVar19 = (int)*(short *)((longlong)pplVar37 + 0xc);
                plVar29 = *pplVar37;
                if (((byte)*(undefined2 *)((longlong)plVar29 + 0x62) >> 3 & 1) != 0) {
                  if (iVar19 == 3) {
                    iVar19 = 4;
                  }
                  else if (iVar19 < 2) goto LAB_;
                  if ((((*(uint *)((longlong)plVar29 + 100) & 8) != 0) &&
                      (lVar35 = plVar29[0x12], lVar35 != 0)) && (*(longlong *)(lVar35 + 0x758) != 0)
                     ) {
                    uVar25 = *(undefined8 *)(lVar35 + 0x758);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100dea;
                    func_0x(uVar25,plVar29,iVar19);
                  }
                }
LAB_:
                if (((((DAT_ & 0x80) != 0) &&
                     ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) && (2 < iVar19)) &&
                   (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 &&
                    (*plVar29 != 0)))) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100e1e;
                  func_0x(plVar29,1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100e2c;
                func_0x(plVar29 + 0x13,iVar19);
                if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100e4b;
                  func_0x(plVar29,0,iVar19);
                }
                puVar38 = *(undefined8 **)(&stack0x00000070 + lVar23);
                *(undefined2 *)((longlong)puVar38 + 0xc) = 0;
                *puVar38 = 0;
                param_1 = *(longlong **)(&stack0x00000078 + lVar23);
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100d90;
                func_0x();
              }
            }
          }
          if ((&stack0x00000055)[lVar23] != '\0') {
            LOCK();
            iVar19 = *(int *)(*(longlong *)(&stack0x00000080 + lVar23) + 0x9c);
            if (iVar19 == 0) {
              *(int *)(*(longlong *)(&stack0x00000080 + lVar23) + 0x9c) = 0;
              iVar19 = 0;
            }
            UNLOCK();
            if (iVar19 == 0) {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100e95;
              (*_DAT_)(1,0x1498578,0x1463170,0x2c11);
            }
          }
          if (*(short *)(param_2 + 0x38) == 0x2fc) {
            (&stack0x00000098)[lVar23] = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100ebb;
            func_0x(param_2 + 0x3e,0,&stack0x00000680 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100ecd;
            uVar26 = func_0x(param_2 + 0x3e,1,&stack0x00000684 + lVar23);
            uVar25 = *(undefined8 *)(*param_1 + 0x6b0);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100eea;
            iVar19 = func_0x
                               (uVar25,uVar26,&stack0x00000098 + lVar23,&stack0x00000100 + lVar23);
            if (iVar19 < 0) {
              uVar25 = 0x1318130;
              if ((&stack0x00000100)[lVar23] != '\0') {
                uVar25 = 0x106f448;
              }
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = uVar25;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100f21;
              (*_DAT_)(0x22,0x3d,0x15,1);
            }
            if ((&stack0x00000098)[lVar23] != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100f2e;
              func_0x(0x9e);
            }
          }
        }
        lVar35 = *(longlong *)(&stack0x00007a88 + lVar23);
        if (((*(byte *)(*(longlong *)(*param_1 + 0x6b0) + 0x3c) & 1) != 0) &&
           (*(longlong *)(*(longlong *)(*param_1 + 0x6b0) + 0x280) == 0)) {
          puVar38 = *(undefined8 **)(&stack0x000000b8 + lVar23);
          if ((*(byte *)(lVar24 + 100) & 0x40) == 0) {
            uVar22 = *(undefined4 *)(param_2 + 0x18);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100f79;
            (*_DAT_)(lVar24,puVar38,&stack0x000012f8 + lVar23,uVar22);
          }
          if (*(short *)(*(longlong *)(&stack0x00000070 + lVar23) + 0xc) < 4) {
            if ((&stack0x00007a78)[lVar23] == '\0') {
              lVar27 = *(longlong *)(&stack0x00000078 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100fa4;
              cVar11 = func_0x(lVar27,param_2);
              if (cVar11 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100fb8;
                cVar11 = func_0x(0x19ed480);
                if (cVar11 == '\0') {
                  (&stack0x00000088)[lVar23] = 0;
                  if (lVar35 != 0) {
                    *(longlong *)(lVar35 + 0x28) = *(longlong *)(lVar35 + 0x28) + 1;
                  }
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar23) = &stack0x0000005c + lVar23;
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar23) = &stack0x00000054 + lVar23;
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100ff6;
                  iVar19 = func_0x(lVar27,lVar24,param_2,puVar38);
                  if (iVar19 != 0) {
                    plVar29 = *(longlong **)(lVar27 + 0x5f80);
                    uVar25 = uVar31;
                    if (plVar29 != (longlong *)0x0) {
                      uVar25 = *(undefined8 *)
                                (*plVar29 +
                                ((ulonglong)
                                 *(uint *)(*(longlong *)(&stack0x00000080 + lVar23) + 0x10) %
                                (ulonglong)*(uint *)(plVar29 + 1)) * 8);
                    }
                    *(undefined8 *)(&stack0x000003d8 + lVar23) = *puVar38;
                    *(undefined2 *)(&stack0x000003e0 + lVar23) = *(undefined2 *)(puVar38 + 1);
                    lVar27 = *(longlong *)(&stack0x00000080 + lVar23);
                    *(undefined2 *)(lVar27 + 0x22) = 0x5ed0;
                    puVar38 = (undefined8 *)(lVar27 + 0x24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101053;
                    iVar19 = func_0x(puVar38);
                    *puVar38 = *(undefined8 *)(&stack0x000003d8 + lVar23);
                    *(undefined2 *)(lVar27 + 0x2c) = *(undefined2 *)(&stack0x000003e0 + lVar23);
                    lVar28 = *(longlong *)(&stack0x00000080 + lVar23);
                    *(int *)(lVar28 + 0x30) = iVar19 + 2;
                    *(undefined8 *)(&stack0x000005d8 + lVar23) =
                         *(undefined8 *)(&stack0x000003d8 + lVar23);
                    *(undefined2 *)(&stack0x000005e0 + lVar23) =
                         *(undefined2 *)(&stack0x000003e0 + lVar23);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1010a3;
                    func_0x(lVar28,&stack0x000005d8 + lVar23,uVar25);
                    if (((*(byte *)(lVar24 + 100) & 0x40) == 0) &&
                       ((&stack0x00000055)[lVar23] != '\0')) {
                      lVar28 = *(longlong *)(&stack0x00000078 + lVar23);
                      if ((*(longlong *)(lVar28 + 0x8450) != 0) &&
                         ((*(byte *)(*(longlong *)(lVar28 + 0x8450) + 0x210) & 0x10) != 0)) {
                        lVar8 = *(longlong *)(&stack0x00000080 + lVar23);
                        piVar1 = (int *)(lVar8 + 0x9c);
                        LOCK();
                        iVar19 = *piVar1;
                        if (iVar19 == 0) {
                          *piVar1 = 0;
                          iVar19 = 0;
                        }
                        UNLOCK();
                        if (iVar19 == 0) {
                          *(undefined8 *)(&stack0x000004a0 + lVar23) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10110b;
                          func_0x(lVar8,&stack0x00001308 + lVar23,&stack0x000004a0 + lVar23)
                          ;
                          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10111f;
                          func_0x(&stack0x000014b0 + lVar23,0,0,0);
                          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101132;
                          iVar19 = func_0x
                                             (&stack0x00001308 + lVar23,&stack0x000014b0 + lVar23);
                          if (iVar19 == 0) {
                            LOCK();
                            iVar19 = *(int *)(*(longlong *)(&stack0x00000080 + lVar23) + 0x9c);
                            if (iVar19 == 0) {
                              *(int *)(*(longlong *)(&stack0x00000080 + lVar23) + 0x9c) = 0;
                              iVar19 = 0;
                            }
                            UNLOCK();
                            if (iVar19 == 0) {
                              if (*(longlong *)(&stack0x000004a0 + lVar23) == 0) {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10117b;
                                (*_DAT_)(1,0x14985c8,0x1463170,0x2c8b);
                              }
                              uVar22 = *(undefined4 *)(param_2 + 0x18);
                              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101196;
                              (*_DAT_)(lVar24,&stack0x00001308 + lVar23,
                                               &stack0x000012f8 + lVar23,uVar22);
                              if (lVar35 != 0) {
                                *(longlong *)(lVar35 + 0x28) = *(longlong *)(lVar35 + 0x28) + 1;
                              }
                              *(undefined **)(&stack0xffffffffffffffe8 + lVar23) =
                                   &stack0x0000005c + lVar23;
                              *(undefined **)(&stack0xffffffffffffffe0 + lVar23) =
                                   &stack0x00000054 + lVar23;
                              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1011d1;
                              iVar19 = func_0x(lVar28,lVar24,
                                                       *(undefined8 *)(&stack0x000004a0 + lVar23),
                                                       &stack0x00001308 + lVar23);
                              if (iVar19 != 0) {
                                plVar29 = *(longlong **)(lVar28 + 0x5f80);
                                lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
                                if (plVar29 != (longlong *)0x0) {
                                  uVar31 = *(undefined8 *)
                                            (*plVar29 +
                                            ((ulonglong)*(uint *)(lVar24 + 0x10) %
                                            (ulonglong)*(uint *)(plVar29 + 1)) * 8);
                                }
                                *(undefined8 *)(&stack0x000003c8 + lVar23) =
                                     *(undefined8 *)(&stack0x00001308 + lVar23);
                                *(undefined2 *)(&stack0x000003d0 + lVar23) =
                                     *(undefined2 *)(&stack0x00001310 + lVar23);
                                *(undefined2 *)(lVar24 + 0x22) = 0x5ed0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10122b;
                                iVar19 = func_0x(puVar38);
                                *puVar38 = *(undefined8 *)(&stack0x000003c8 + lVar23);
                                *(undefined2 *)(lVar27 + 0x2c) =
                                     *(undefined2 *)(&stack0x000003d0 + lVar23);
                                *(int *)(lVar24 + 0x30) = iVar19 + 2;
                                *(undefined8 *)(&stack0x000005e8 + lVar23) =
                                     *(undefined8 *)(&stack0x000003c8 + lVar23);
                                *(undefined2 *)(&stack0x000005f0 + lVar23) =
                                     *(undefined2 *)(&stack0x000003d0 + lVar23);
                                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10127b;
                                uVar20 = func_0x(lVar24,&stack0x000005e8 + lVar23,uVar31);
                                if (lVar35 != 0) {
                                  *(ulonglong *)(lVar35 + 0x20) =
                                       *(longlong *)(lVar35 + 0x20) + (ulonglong)uVar20;
                                  *(longlong *)(lVar35 + 0x18) = *(longlong *)(lVar35 + 0x18) + 1;
                                }
                                goto LAB_;
                              }
                            }
                          }
                        }
                      }
                    }
                    if (lVar35 != 0) {
                      *(longlong *)(lVar35 + 0x18) = *(longlong *)(lVar35 + 0x18) + 1;
                    }
                    goto LAB_;
                  }
                  goto LAB_;
                }
              }
            }
            (&stack0x00000088)[lVar23] = 1;
          }
          else {
            (&stack0x00000054)[lVar23] = 1;
          }
        }
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1012c9;
        lVar27 = func_0x();
        *(longlong *)(&stack0x000000a0 + lVar23) = lVar27;
        if (lVar27 != 0) {
          *(undefined *)(lVar27 + 0x49e) = 0;
        }
        *(undefined8 *)(&stack0x000000b0 + lVar23) = 2;
        pplVar37 = *(longlong ***)(&stack0x00000070 + lVar23);
        if (((&stack0x00000055)[lVar23] == '\0') || (*(short *)((longlong)pplVar37 + 0xc) < 4)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101310;
          func_0x(&stack0x00001608 + lVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10131c;
          cVar11 = func_0x(0x19ed480);
          plVar29 = *(longlong **)(&stack0x00000078 + lVar23);
          if ((cVar11 == '\0') || ((*(uint *)((longlong)plVar29 + 0x24) >> 7 & 1) == 0)) {
            *(undefined4 *)(&stack0x00000200 + lVar23) = *(undefined4 *)(param_2 + 0x18);
            *(undefined2 *)(&stack0x00000204 + lVar23) = *(undefined2 *)(param_2 + 0x1c);
            lVar27 = *plVar29;
            if ((*_DAT_ == '\0') || ((DAT_ & 0x80) != 0)) {
LAB_:
              *(undefined8 *)(&stack0x00000068 + lVar23) = 0;
            }
            else {
              lVar28 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
              if ((lVar28 != 0) && (lVar28 = **(longlong **)(lVar28 + 0x38), lVar28 != 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1013f3;
                iVar19 = (*_DAT_)(lVar28,0x337);
                if (iVar19 != 0) goto LAB_;
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1013fc;
              uVar25 = func_0x();
              *(undefined8 *)(&stack0x00000068 + lVar23) = uVar25;
            }
            *(undefined8 *)(&stack0x00000090 + lVar23) = *(undefined8 *)(lVar27 + 0x728);
            *(undefined4 *)(&stack0x000002c0 + lVar23) = 0;
            if (*pplVar37 != (longlong *)0x0) {
              if (((*(ushort *)((longlong)*pplVar37 + 0x62) >> 10 & 1) == 0) ||
                 (*(short *)((longlong)pplVar37 + 0xc) < 3)) {
                iVar19 = (int)*(short *)((longlong)pplVar37 + 0xc);
                plVar29 = *pplVar37;
                if (((byte)*(undefined2 *)((longlong)plVar29 + 0x62) >> 3 & 1) != 0) {
                  if (iVar19 == 3) {
                    iVar19 = 4;
                  }
                  else if (iVar19 < 2) goto LAB_;
                  if ((((*(uint *)((longlong)plVar29 + 100) & 8) != 0) &&
                      (lVar28 = plVar29[0x12], lVar28 != 0)) && (*(longlong *)(lVar28 + 0x758) != 0)
                     ) {
                    uVar25 = *(undefined8 *)(lVar28 + 0x758);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10149c;
                    func_0x(uVar25,plVar29,iVar19);
                  }
                }
LAB_:
                if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)
                    ) && ((2 < iVar19 &&
                          (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 &&
                           (*plVar29 != 0)))))) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1014d4;
                  func_0x(plVar29,1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1014e3;
                func_0x(plVar29 + 0x13,iVar19);
                if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101502;
                  func_0x(plVar29,0,iVar19);
                }
                pplVar37 = *(longlong ***)(&stack0x00000070 + lVar23);
                *(undefined2 *)((longlong)pplVar37 + 0xc) = 0;
                *pplVar37 = (longlong *)0x0;
                cVar10 = (&stack0x00000058)[lVar23];
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10143e;
                func_0x(pplVar37);
              }
            }
            if ((*(longlong *)(lVar27 + 0x728) != 0) && (cVar10 == '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10153c;
              func_0x(pplVar37,&stack0x00000200 + lVar23,lVar27);
              if (*pplVar37 != (longlong *)0x0) {
                if (((*(ushort *)((longlong)*pplVar37 + 0x62) >> 10 & 1) == 0) ||
                   (*(short *)((longlong)pplVar37 + 0xc) < 3)) {
                  iVar19 = (int)*(short *)((longlong)pplVar37 + 0xc);
                  plVar29 = *pplVar37;
                  if (((byte)*(undefined2 *)((longlong)plVar29 + 0x62) >> 3 & 1) != 0) {
                    if (iVar19 == 3) {
                      iVar19 = 4;
                    }
                    else if (iVar19 < 2) goto LAB_;
                    if ((((*(uint *)((longlong)plVar29 + 100) & 8) != 0) &&
                        (lVar28 = plVar29[0x12], lVar28 != 0)) &&
                       (*(longlong *)(lVar28 + 0x758) != 0)) {
                      uVar25 = *(undefined8 *)(lVar28 + 0x758);
                      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1015c0;
                      func_0x(uVar25,plVar29,iVar19);
                    }
                  }
LAB_:
                  if ((((DAT_ & 0x80) != 0) &&
                      ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
                     ((2 < iVar19 &&
                      (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 &&
                       (*plVar29 != 0)))))) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1015f8;
                    func_0x(plVar29,1);
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101607;
                  func_0x(plVar29 + 0x13,iVar19);
                  if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101626;
                    func_0x(plVar29,0,iVar19);
                  }
                  pplVar37 = *(longlong ***)(&stack0x00000070 + lVar23);
                  *(undefined2 *)((longlong)pplVar37 + 0xc) = 0;
                  *pplVar37 = (longlong *)0x0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101562;
                  func_0x(pplVar37);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101641;
            func_0x(lVar27,&stack0x00000200 + lVar23);
            *(undefined **)(&stack0xffffffffffffffe8 + lVar23) = &stack0x000004e0 + lVar23;
            *(undefined4 *)(&stack0xffffffffffffffe0 + lVar23) = 4;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101675;
            plVar29 = (longlong *)
                      func_0x
                                (_DAT_,lVar27,&stack0x00000200 + lVar23,
                                 &stack0x000002c0 + lVar23);
            *pplVar37 = plVar29;
            *(undefined2 *)((longlong)pplVar37 + 0xc) = 4;
            lVar28 = *(longlong *)(&stack0x00000068 + lVar23);
            if (lVar28 != 0) {
              uVar30 = (ulonglong)(*(uint *)(lVar28 + 0x500) & 0xf);
              if (*(longlong *)(lVar28 + 0x508 + uVar30 * 8) != *plVar29) {
                *(longlong *)(lVar28 + 0x508 + uVar30 * 8) = *plVar29;
                *(longlong *)(lVar28 + 0x500) = *(longlong *)(lVar28 + 0x500) + 1;
              }
            }
            *(byte *)((longlong)pplVar37 + 0xf) =
                 (byte)(*(uint *)(&stack0x000002c0 + lVar23) >> 3) & 1;
            *(byte *)(pplVar37 + 2) = (byte)(*(uint *)(&stack0x000002c0 + lVar23) >> 4) & 1;
            if (((*(longlong *)(&stack0x00000090 + lVar23) != 0) && (lVar28 != 0)) &&
               (lVar28 == *(longlong *)(lVar27 + 0x1c38))) {
              cVar10 = *(char *)((longlong)pplVar37 + 0xf);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1016f5;
              func_0x(*(longlong *)(&stack0x00000090 + lVar23) + 0x59b8,(int)cVar10,
                              &stack0x000004e0 + lVar23);
            }
            if (((((*(byte *)(*(longlong *)(lVar27 + 0x6b0) + 0x3c) & 1) == 0) ||
                 (*(longlong *)(*(longlong *)(lVar27 + 0x6b0) + 0x280) != 0)) ||
                ((*(char *)(lVar27 + 0x2050) == '\0' || (*(int *)(&stack0x00000200 + lVar23) == 0)))
                ) || ((*(int *)(&stack0x00000200 + lVar23) == 9 &&
                      (*(short *)(&stack0x00000204 + lVar23) == 1)))) {
LAB_:
              plVar29 = *pplVar37;
            }
            else {
              lVar28 = **pplVar37;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10175c;
              func_0x(&stack0x000013c0 + lVar23,0,0,0);
              *(undefined2 *)(&stack0x000013ca + lVar23) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101777;
              func_0x(lVar27 + 0x20fc,&stack0x000013c0 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10178c;
              uVar25 = func_0x(lVar28,&stack0x000015e0 + lVar23,0,0);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10179b;
              iVar19 = func_0x(&stack0x000013c0 + lVar23,uVar25);
              if (iVar19 == 0) {
LAB_:
                pplVar37 = *(longlong ***)(&stack0x00000070 + lVar23);
                goto LAB_;
              }
              if (*(char *)(lVar27 + 0x6ac8) == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1017b8;
                cVar10 = func_0x(lVar27);
                if (cVar10 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1017c8;
                  cVar10 = func_0x(lVar27);
                  if (cVar10 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1017e4;
                    func_0x(&stack0x000013a0 + lVar23,0,0,0);
                    *(undefined2 *)(&stack0x000013aa + lVar23) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1017ff;
                    func_0x(lVar27 + 0x20fc,&stack0x000013a0 + lVar23);
                    *(undefined8 *)(&stack0x000013b0 + lVar23) =
                         *(undefined8 *)(&stack0x000013a0 + lVar23);
                    *(undefined2 *)(&stack0x000013b8 + lVar23) =
                         *(undefined2 *)(&stack0x000013a8 + lVar23);
                    pplVar37 = *(longlong ***)(&stack0x00000070 + lVar23);
                    lVar28 = **pplVar37;
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101839;
                    func_0x(lVar28,&stack0x000013d0 + lVar23,0,0);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10184c;
                    iVar19 = func_0x
                                       (&stack0x000013b0 + lVar23,&stack0x000013d0 + lVar23);
                    if (iVar19 == 0) goto LAB_;
                    lVar28 = *(longlong *)(lVar27 + 0x6b0);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101875;
                    func_0x(&stack0x000013d0 + lVar23,&stack0x00001830 + lVar23,
                                    &stack0x00000480 + lVar23);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10188f;
                    func_0x(&stack0x000013b0 + lVar23,&stack0x00001800 + lVar23,
                                    &stack0x00000480 + lVar23);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101894;
                    iVar19 = func_0x();
                    if (iVar19 != 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1018a8;
                      func_0x(&stack0x00000ce0 + lVar23);
                      *(uint *)(&stack0x00000f40 + lVar23) = (uint)*(ushort *)(lVar27 + 0x6b8);
                      *(undefined2 *)(&stack0x00000f44 + lVar23) =
                           *(undefined2 *)(&stack0x00000204 + lVar23);
                      *(undefined4 *)(&stack0x00000f46 + lVar23) =
                           *(undefined4 *)(&stack0x00000200 + lVar23);
                      (&stack0x00000f4a)[lVar23] = 0xff;
                      (&stack0x00000f4b)[lVar23] =
                           *(undefined *)(***(longlong ***)(&stack0x00000070 + lVar23) + 1);
                      *(undefined2 *)(&stack0xffffffffffffffe0 + lVar23) = 1;
                      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101911;
                      func_0x(&stack0x00000ce8 + lVar23,lVar28 + 0x254,0x10);
                      *(undefined2 *)(&stack0xffffffffffffffe0 + lVar23) = 2;
                      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101938;
                      func_0x(&stack0x00000ce8 + lVar23,lVar28 + 0x244,0x10);
                      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10194b;
                      func_0x(&stack0x00000ce0 + lVar23,&stack0x00001830 + lVar23);
                      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10195e;
                      func_0x(&stack0x00000ce0 + lVar23,&stack0x00001800 + lVar23);
                      *(undefined4 *)(&stack0x00000484 + lVar23) = 0;
                      UNRECOVERED_JUMPTABLE = *(code **)(_DAT_ + 0x10);
                      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101979;
                      uVar25 = (*UNRECOVERED_JUMPTABLE)(lVar28,&stack0x00000484 + lVar23);
                      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101988;
                      func_0x(&stack0x00000ce0 + lVar23,uVar25);
                      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101994;
                      func_0x(&stack0x00000ce0 + lVar23);
                    }
                    goto LAB_;
                  }
                }
              }
              plVar29 = **(longlong ***)(&stack0x00000070 + lVar23);
            }
            lVar28 = *plVar29;
          }
          else {
            *(undefined4 *)(&stack0x0000042c + lVar23) = *(undefined4 *)(param_2 + 0x18);
            *(undefined2 *)(&stack0x00000430 + lVar23) = *(undefined2 *)(param_2 + 0x1c);
            *(undefined *)((longlong)&uStackX_20 + lVar23 + -0x20) = 0;
            (&stack0xfffffffffffffff8)[lVar23] = cVar10;
            *(undefined **)(&stack0xfffffffffffffff0 + lVar23) = &stack0x000004e0 + lVar23;
            *(longlong *)(&stack0xffffffffffffffe8 + lVar23) = *plVar29;
            *(undefined4 *)(&stack0xffffffffffffffe0 + lVar23) = 4;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10137f;
            lVar28 = func_0x(pplVar37,param_2,&stack0x0000042c + lVar23,0xff);
          }
          *(longlong *)(&stack0x00000068 + lVar23) = lVar28;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1019ae;
          func_0x(&stack0x00001608 + lVar23);
          if (lVar35 != 0) {
            *(longlong *)(lVar35 + 0x10) = *(longlong *)(lVar35 + 0x10) + 1;
          }
          (&stack0x00000099)[lVar23] = 1;
          lVar27 = *(longlong *)(&stack0x000000a0 + lVar23);
        }
        else {
          lVar28 = **pplVar37;
          *(longlong *)(&stack0x00000068 + lVar23) = lVar28;
        }
        if (lVar35 != 0) {
          *(longlong *)(lVar35 + 0x30) = *(longlong *)(lVar35 + 0x30) + 1;
        }
        if ((lVar27 != 0) && (*(char *)(lVar27 + 0x49e) != '\0')) {
          lVar35 = *(longlong *)(**(longlong **)(&stack0x00000078 + lVar23) + 0x728);
          uVar12 = *(undefined *)(lVar28 + 1);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101a02;
          func_0x(lVar35 + 0x88,uVar12);
          if (*(byte *)(param_2 + 0x16) < 0x7f) {
            LOCK();
            plVar29 = (longlong *)(lVar35 + 0x2e0 + (ulonglong)*(byte *)(param_2 + 0x16) * 8);
            *plVar29 = *plVar29 + 1;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101a2c;
        uVar25 = func_0x(lVar28,&stack0x000015d0 + lVar23,0,0);
        puVar38 = *(undefined8 **)(&stack0x000000b8 + lVar23);
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101a3b;
        iVar19 = func_0x(puVar38,uVar25);
        uVar17 = *(undefined2 *)(**(longlong **)(&stack0x00000070 + lVar23) + 0x62);
        *(undefined8 *)(&stack0x000005f8 + lVar23) = *puVar38;
        *(undefined2 *)(&stack0x00000600 + lVar23) = *(undefined2 *)(puVar38 + 1);
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101a89;
        uVar25 = func_0x(lVar28,&stack0x000009d0 + lVar23,0,0);
        *(byte *)((longlong)&lStackX_8 + lVar23) = (byte)uVar17 >> 4 & 1;
        *(bool *)((longlong)&uStackX_20 + lVar23 + -0x20) = iVar19 == 0;
        (&stack0xfffffffffffffff8)[lVar23] = (&stack0x00000088)[lVar23];
        (&stack0xfffffffffffffff0)[lVar23] = (&stack0x0000005c)[lVar23];
        (&stack0xffffffffffffffe8)[lVar23] = (&stack0x00000054)[lVar23];
        (&stack0xffffffffffffffe0)[lVar23] = iVar19 == 0;
        plVar29 = *(longlong **)(&stack0x00000078 + lVar23);
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101ac8;
        func_0x(plVar29,param_2,&stack0x000005f8 + lVar23,uVar25);
        *(undefined4 *)(&stack0x00000432 + lVar23) = *(undefined4 *)(param_2 + 0x18);
        *(undefined2 *)(&stack0x00000436 + lVar23) = *(undefined2 *)(param_2 + 0x1c);
        if (*(int *)(*(longlong *)(*plVar29 + 0x7a8) + 0x110) != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101b02;
          iVar21 = func_0x(&stack0x00000432 + lVar23);
          if (iVar21 == 0) {
            *(undefined4 *)(&stack0x00000438 + lVar23) = *(undefined4 *)(param_2 + 0x18);
            *(undefined2 *)(&stack0x0000043c + lVar23) = *(undefined2 *)(param_2 + 0x1c);
            uVar25 = *(undefined8 *)(*plVar29 + 0x7a8);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101b32;
            func_0x(uVar25);
          }
        }
        lVar35 = *(longlong *)(&stack0x00000080 + lVar23);
        if ((&stack0x00000099)[lVar23] != '\0') {
          plVar6 = *(longlong **)(&stack0x00000070 + lVar23);
          uVar20 = *(uint *)((longlong)plVar6 + 0xc);
          if (((uVar20 & 0xff000000) != 0) || (uVar25 = uVar31, (*(byte *)(lVar35 + 0x16) & 8) == 0)
             ) {
            uVar25 = *(undefined8 *)(*plVar6 + 0x40);
            *(ushort *)(lVar35 + 0x16) = *(ushort *)(lVar35 + 0x16) | 8;
            uVar20 = *(uint *)((longlong)plVar6 + 0xc);
          }
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar23) = uVar25;
          *(uint *)(&stack0xffffffffffffffe0 + lVar23) = (uint)(iVar19 == 0);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101b9c;
          func_0x(plVar29 + 0xb37,(int)uVar20 >> 0x18,
                          *(undefined4 *)(&stack0x000004e4 + lVar23),
                          *(undefined4 *)(&stack0x000004e0 + lVar23));
          if (*(int *)(&stack0x000004e4 + lVar23) != 0) {
            if ((DAT_ & 8) == 0) {
              lVar27 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
              if ((lVar27 != 0) && (**(longlong **)(lVar27 + 0x38) != 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101bf8;
                iVar21 = (*_DAT_)();
                if (iVar21 != 0) goto LAB_;
              }
            }
            else {
LAB_:
              *(undefined4 *)(&stack0x00000490 + lVar23) = 0x5c;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101c1a;
              func_0x
                        (*(undefined8 *)(&stack0x000000b8 + lVar23),&stack0x000015f0 + lVar23);
              *(undefined4 *)(&stack0x000006d8 + lVar23) = 100;
              *(undefined **)(&stack0x000006d0 + lVar23) = &stack0x00001860 + lVar23;
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar23) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101c54;
              func_0x
                        (&stack0x000015f0 + lVar23,&stack0x00001860 + lVar23,
                         &stack0x000006d8 + lVar23,0);
              uVar20 = *(uint *)(&stack0x000006d8 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101c71;
              func_0x(*(undefined8 *)(&stack0x000000b8 + lVar23),&stack0x000019f0 + lVar23,
                              &stack0x00000490 + lVar23);
              uVar22 = *(undefined4 *)(param_2 + 0x18);
              uVar18 = *(ushort *)(param_2 + 0x1c);
              uVar4 = *(ushort *)(param_2 + 0x14);
              *(int *)((longlong)&lStackX_8 + lVar23) =
                   (int)*(char *)(*(longlong *)(&stack0x00000070 + lVar23) + 0xf);
              *(undefined4 *)((longlong)&uStackX_20 + lVar23 + -0x20) = uVar22;
              *(uint *)(&stack0xfffffffffffffff8 + lVar23) = (uint)uVar18;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar23) =
                   *(undefined4 *)(&stack0x000004e0 + lVar23);
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar23) = *(undefined4 *)(param_2 + 0x10);
              *(uint *)(&stack0xffffffffffffffe0 + lVar23) = (uint)uVar4;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101cca;
              func_0x(0x1318070,uVar20 >> 1,&stack0x00001860 + lVar23,
                              &stack0x000019f0 + lVar23);
              lVar35 = *(longlong *)(&stack0x00000080 + lVar23);
            }
          }
        }
        if ((iVar19 == 0) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1021aa;
          uVar31 = func_0x(param_2);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1021c2;
          uVar25 = func_0x(lVar28,&stack0x000014d0 + lVar23,0,0);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1021cd;
          iVar19 = func_0x(uVar25,uVar31);
          while (iVar19 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1021e8;
            cVar10 = func_0x(param_2);
            if (cVar10 == '\x10') {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1021fb;
              uVar31 = func_0x(param_2,&stack0x00000810 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102203;
              uVar17 = func_0x(uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10220e;
              uVar31 = func_0x(plVar29);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10221c;
              uVar31 = func_0x(uVar31,uVar17,0);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102224;
              iVar19 = func_0x(uVar31);
              if (iVar19 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10223d;
                uVar31 = func_0x(lVar28,&stack0x000015c0 + lVar23,0,0);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102249;
                iVar19 = func_0x(uVar31,*(undefined8 *)(&stack0x000000b8 + lVar23));
                if (iVar19 != 0) break;
              }
              if (*(int *)(plVar29 + 4) == 2) {
                lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102827;
                uVar31 = func_0x(*(undefined8 *)(&stack0x00000078 + lVar23),lVar24 + 0x10);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10283f;
                uVar25 = func_0x(lVar28,&stack0x000009c0 + lVar23,0,0);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102851;
                func_0x(lVar24,uVar25,uVar31,0xded0);
                goto LAB_;
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102263;
            uVar31 = func_0x(plVar29);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10226b;
            cVar10 = func_0x(uVar31);
            if (cVar10 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102277;
              cVar10 = func_0x(plVar29);
              if (cVar10 != '\0') goto LAB_;
            }
            else {
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102283;
              cVar10 = func_0x(param_2);
              if (cVar10 == '\x15') {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10229b;
                uVar31 = func_0x(&stack0x000014e0 + lVar23,0,0,0);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1022a6;
                uVar25 = func_0x(param_2);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1022b1;
                iVar19 = func_0x(uVar25,uVar31);
                if (iVar19 != 0) break;
              }
            }
            if (*_DAT_ != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1022ca;
              uVar31 = func_0x();
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1022d7;
              iVar19 = func_0x(uVar31,0x337);
              if (iVar19 == 0) {
                if (*(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) != 0)
                {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102307;
                  uVar31 = func_0x();
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10230f;
                  lVar24 = func_0x(uVar31);
                  if (lVar24 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102322;
                    iVar19 = (*_DAT_)(lVar24,0x337);
                    if (iVar19 != 0) goto LAB_;
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10232b;
                lVar24 = func_0x();
                if (lVar24 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102338;
                  uVar31 = func_0x(lVar24);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102343;
                  func_0x(uVar31,lVar28);
                }
              }
            }
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10234b;
            uVar31 = func_0x(param_2);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102363;
            uVar25 = func_0x(lVar28,&stack0x000014f0 + lVar23,0,0);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10236e;
            iVar19 = func_0x(uVar25,uVar31);
            if (iVar19 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10237a;
              iVar19 = func_0x(lVar28);
              if (iVar19 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10286e;
                uVar31 = func_0x(lVar28,&stack0x00001530 + lVar23,0,0);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102884;
                func_0x(uVar31,&stack0x00001990 + lVar23,&stack0x00000494 + lVar23);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10289b;
                func_0x(*(undefined8 *)(&stack0x000000b8 + lVar23),&stack0x00001930 + lVar23
                                ,&stack0x00000494 + lVar23);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1028a0;
                iVar19 = func_0x();
                if (iVar19 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1028b4;
                  func_0x(&stack0x00000f80 + lVar23);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1028bc;
                  uVar31 = func_0x(plVar29);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1028c4;
                  uVar17 = func_0x(uVar31);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1028d3;
                  func_0x(&stack0x00000f80 + lVar23,uVar17);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1028e2;
                  uVar31 = func_0x(param_2,&stack0x00000874 + lVar23);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1028ea;
                  uVar22 = func_0x(uVar31);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1028f8;
                  func_0x(&stack0x00000f80 + lVar23,uVar22);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102907;
                  uVar31 = func_0x(param_2,&stack0x0000086e + lVar23);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10290f;
                  uVar17 = func_0x(uVar31);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10291e;
                  func_0x(&stack0x00000f80 + lVar23,uVar17);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102931;
                  func_0x(&stack0x00000f80 + lVar23,&stack0x00001930 + lVar23);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102944;
                  func_0x(&stack0x00000f80 + lVar23,&stack0x00001990 + lVar23);
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102950;
                  func_0x(&stack0x00000f80 + lVar23);
                }
                break;
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102397;
            uVar31 = func_0x(lVar28,&stack0x00001500 + lVar23,0,0);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1023ad;
            func_0x(uVar31,&stack0x00001ab0 + lVar23,&stack0x00000358 + lVar23);
            puVar38 = *(undefined8 **)(&stack0x000000b8 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1023c7;
            func_0x(puVar38,&stack0x00001a50 + lVar23,&stack0x00000358 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1023cf;
            uVar31 = func_0x(param_2);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1023e5;
            func_0x(uVar31,&stack0x000018d0 + lVar23,&stack0x00000358 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1023ea;
            iVar19 = func_0x();
            if (iVar19 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1023fe;
              func_0x(&stack0x00000a30 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102411;
              func_0x(&stack0x00000a30 + lVar23,&stack0x00001a50 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102419;
              uVar31 = func_0x(param_2);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102421;
              uVar31 = func_0x(uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102430;
              func_0x(&stack0x00000a30 + lVar23,uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10243f;
              uVar31 = func_0x(param_2,&stack0x00000816 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102447;
              uVar22 = func_0x(uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102455;
              func_0x(&stack0x00000a30 + lVar23,uVar22);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102464;
              uVar31 = func_0x(param_2,&stack0x00000908 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10246c;
              uVar31 = func_0x(uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10247b;
              func_0x(&stack0x00000a30 + lVar23,uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102483;
              uVar31 = func_0x(plVar29);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10248b;
              uVar31 = func_0x(uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10249a;
              func_0x(&stack0x00000a30 + lVar23,uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1024a2;
              uVar31 = func_0x(plVar29);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1024aa;
              uVar17 = func_0x(uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1024b9;
              func_0x(&stack0x00000a30 + lVar23,uVar17);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1024cc;
              func_0x(&stack0x00000a30 + lVar23,&stack0x00001ab0 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1024d8;
              func_0x(&stack0x000004a8 + lVar23);
              *(undefined4 *)(&stack0x000004a8 + lVar23) = *(undefined4 *)(lVar28 + 0x18);
              *(undefined2 *)(&stack0x000004ac + lVar23) = *(undefined2 *)(lVar28 + 6);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1024f8;
              uVar31 = func_0x(&stack0x000004a8 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102507;
              func_0x(&stack0x00000a30 + lVar23,uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10250f;
              uVar12 = func_0x(lVar28);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10251e;
              func_0x(&stack0x00000a30 + lVar23,uVar12);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102526;
              uVar12 = func_0x(param_2);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102535;
              func_0x(&stack0x00000a30 + lVar23,uVar12);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10253d;
              uVar12 = func_0x(param_2);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10254c;
              func_0x(&stack0x00000a30 + lVar23,uVar12);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10255f;
              func_0x(&stack0x00000a30 + lVar23,&stack0x000018d0 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10256b;
              func_0x(&stack0x00000a30 + lVar23);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102570;
            uVar31 = func_0x();
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10257d;
            iVar19 = func_0x(uVar31,0xd85);
            if (iVar19 != 0) {
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102961;
              func_0x(0x1318000);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102969;
              puVar32 = (undefined8 *)func_0x(param_2);
              *(undefined8 *)(&stack0x00000650 + lVar23) = *puVar32;
              *(undefined2 *)(&stack0x00000658 + lVar23) = *(undefined2 *)(puVar32 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102995;
              puVar32 = (undefined8 *)func_0x(lVar28,&stack0x00001540 + lVar23,0,0);
              *(undefined8 *)(&stack0x00000660 + lVar23) = *puVar32;
              *(undefined2 *)(&stack0x00000668 + lVar23) = *(undefined2 *)(puVar32 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1029bb;
              puVar33 = (undefined4 *)func_0x(param_2,&stack0x00000868 + lVar23);
              *(undefined4 *)(&stack0x00000460 + lVar23) = *puVar33;
              *(undefined2 *)(&stack0x00000464 + lVar23) = *(undefined2 *)(puVar33 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1029d9;
              puVar33 = (undefined4 *)func_0x(param_2);
              *(undefined4 *)(&stack0x00000470 + lVar23) = *puVar33;
              *(undefined2 *)(&stack0x00000474 + lVar23) = *(undefined2 *)(puVar33 + 1);
              *(undefined8 *)(&stack0x00000670 + lVar23) = *puVar38;
              *(undefined2 *)(&stack0x00000678 + lVar23) = *(undefined2 *)(puVar38 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a12;
              func_0x(&stack0x000004b8 + lVar23);
              *(undefined4 *)(&stack0x000004b8 + lVar23) = *(undefined4 *)(lVar28 + 0x18);
              *(undefined2 *)(&stack0x000004bc + lVar23) = *(undefined2 *)(lVar28 + 6);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a2e;
              bVar13 = func_0x(param_2);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a3a;
              bVar14 = func_0x(param_2);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a46;
              bVar15 = func_0x(lVar28);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a56;
              uVar31 = func_0x(&stack0x000004b8 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a61;
              uVar25 = func_0x(plVar29);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a69;
              uVar18 = func_0x(uVar25);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a74;
              uVar25 = func_0x(plVar29);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a7c;
              uVar25 = func_0x(uVar25);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a88;
              uVar26 = func_0x(*(undefined8 *)(&stack0x00000078 + lVar23));
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102a90;
              uVar22 = func_0x(uVar26);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102aa5;
              uVar26 = func_0x
                                 (*(undefined8 *)(&stack0x000001f8 + lVar23),
                                  &stack0x00000928 + lVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102aad;
              uVar26 = func_0x(uVar26);
              *(undefined **)(&stack0x00000028 + lVar23) = &stack0x00000650 + lVar23;
              *(uint *)((longlong)&uStackX_20 + lVar23) = (uint)bVar13;
              *(uint *)((longlong)&lStackX_18 + lVar23) = (uint)bVar14;
              *(uint *)((longlong)&uStackX_10 + lVar23) = (uint)bVar15;
              *(undefined8 *)((longlong)&lStackX_8 + lVar23) = uVar31;
              *(undefined **)((longlong)&uStackX_20 + lVar23 + -0x20) = &stack0x00000660 + lVar23;
              *(uint *)(&stack0xfffffffffffffff8 + lVar23) = (uint)uVar18;
              *(undefined8 *)(&stack0xfffffffffffffff0 + lVar23) = uVar25;
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar23) = uVar22;
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = uVar26;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102b0a;
              func_0x(0xd80,&stack0x00000670 + lVar23,&stack0x00000470 + lVar23,
                              &stack0x00000460 + lVar23);
              param_2 = *(longlong *)(&stack0x000001f8 + lVar23);
              plVar29 = *(longlong **)(&stack0x00000078 + lVar23);
              break;
            }
            if (*(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1025b1;
              uVar31 = func_0x();
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1025b9;
              lVar24 = func_0x(uVar31);
              if (lVar24 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1025cc;
                iVar19 = (*_DAT_)(lVar24,0xd85);
                if (iVar19 != 0) goto LAB_;
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1025dc;
            uVar31 = func_0x(plVar29);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1025e4;
            cVar10 = func_0x(uVar31);
            if (cVar10 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1025f0;
              cVar10 = func_0x(plVar29);
              *(undefined4 *)(&stack0x000000a0 + lVar23) = 0x15;
              if (cVar10 != '\0') goto LAB_;
            }
            else {
LAB_:
              *(undefined4 *)(&stack0x000000a0 + lVar23) = 0x17;
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10260a;
            puVar32 = (undefined8 *)func_0x(param_2);
            *(undefined8 *)(&stack0x00000620 + lVar23) = *puVar32;
            *(undefined2 *)(&stack0x00000628 + lVar23) = *(undefined2 *)(puVar32 + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102636;
            puVar32 = (undefined8 *)func_0x(lVar28,&stack0x00001510 + lVar23,0,0);
            *(undefined8 *)(&stack0x00000630 + lVar23) = *puVar32;
            *(undefined2 *)(&stack0x00000638 + lVar23) = *(undefined2 *)(puVar32 + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10265c;
            puVar33 = (undefined4 *)func_0x(param_2,&stack0x00000896 + lVar23);
            *(undefined4 *)(&stack0x00000440 + lVar23) = *puVar33;
            *(undefined2 *)(&stack0x00000444 + lVar23) = *(undefined2 *)(puVar33 + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10267a;
            puVar33 = (undefined4 *)func_0x(param_2);
            *(undefined4 *)(&stack0x00000450 + lVar23) = *puVar33;
            *(undefined2 *)(&stack0x00000454 + lVar23) = *(undefined2 *)(puVar33 + 1);
            *(undefined8 *)(&stack0x00000640 + lVar23) = *puVar38;
            *(undefined2 *)(&stack0x00000648 + lVar23) = *(undefined2 *)(puVar38 + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1026b3;
            func_0x(&stack0x000004b0 + lVar23);
            *(undefined4 *)(&stack0x000004b0 + lVar23) = *(undefined4 *)(lVar28 + 0x18);
            *(undefined2 *)(&stack0x000004b4 + lVar23) = *(undefined2 *)(lVar28 + 6);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1026cf;
            bVar13 = func_0x(param_2);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1026db;
            bVar14 = func_0x(param_2);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1026e7;
            bVar15 = func_0x(lVar28);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1026f7;
            uVar31 = func_0x(&stack0x000004b0 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102702;
            uVar25 = func_0x(plVar29);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10270a;
            uVar18 = func_0x(uVar25);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102715;
            uVar25 = func_0x(plVar29);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10271d;
            uVar25 = func_0x(uVar25);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102729;
            uVar26 = func_0x(*(undefined8 *)(&stack0x00000078 + lVar23));
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102731;
            uVar22 = func_0x(uVar26);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102746;
            uVar26 = func_0x
                               (*(undefined8 *)(&stack0x000001f8 + lVar23),&stack0x00000920 + lVar23
                               );
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10274e;
            uVar26 = func_0x(uVar26);
            *(undefined **)(&stack0x00000040 + lVar23) = &stack0x00000620 + lVar23;
            *(uint *)(&stack0x00000038 + lVar23) = (uint)bVar13;
            *(uint *)(&stack0x00000030 + lVar23) = (uint)bVar14;
            *(uint *)(&stack0x00000028 + lVar23) = (uint)bVar15;
            *(undefined8 *)((longlong)&uStackX_20 + lVar23) = uVar31;
            *(undefined **)((longlong)&lStackX_18 + lVar23) = &stack0x00000630 + lVar23;
            *(uint *)((longlong)&uStackX_10 + lVar23) = (uint)uVar18;
            *(undefined8 *)((longlong)&lStackX_8 + lVar23) = uVar25;
            *(undefined4 *)((longlong)&uStackX_20 + lVar23 + -0x20) = uVar22;
            *(undefined8 *)(&stack0xfffffffffffffff8 + lVar23) = uVar26;
            *(undefined **)(&stack0xfffffffffffffff0 + lVar23) = &stack0x00000440 + lVar23;
            *(undefined **)(&stack0xffffffffffffffe8 + lVar23) = &stack0x00000450 + lVar23;
            *(undefined **)(&stack0xffffffffffffffe0 + lVar23) = &stack0x00000640 + lVar23;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1027ca;
            (*_DAT_)(0x22);
            param_2 = *(longlong *)(&stack0x000001f8 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1027d9;
            func_0x(param_2);
            lVar28 = *(longlong *)(&stack0x00000068 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1027f5;
            uVar31 = func_0x(lVar28,&stack0x000014d0 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102800;
            iVar19 = func_0x(uVar31);
            plVar29 = *(longlong **)(&stack0x00000078 + lVar23);
          }
          lVar24 = 0;
          uVar30 = _DAT_;
          if (*_DAT_ != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102b31;
            (*_DAT_)(&stack0x000006c8 + lVar23);
            uVar30 = *(ulonglong *)(&stack0x000006c8 + lVar23);
          }
          uVar31 = *(undefined8 *)(&stack0x00000070 + lVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102b53;
          uVar25 = func_0x(uVar31,0,0);
          *(undefined8 *)(&stack0x00000068 + lVar23) = uVar25;
          if (*(int *)(plVar29 + 4) == 3) {
            uVar34 = _DAT_;
            if (*_DAT_ != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102b79;
              (*_DAT_)(&stack0x000006a8 + lVar23);
              uVar34 = *(ulonglong *)(&stack0x000006a8 + lVar23);
            }
            if (uVar30 <= uVar34) {
              lVar24 = uVar34 - uVar30;
            }
            *(longlong *)(&stack0x000006b0 + lVar23) = lVar24;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102bb1;
            func_0x(plVar29 + 0xb37,&stack0x000006b0 + lVar23);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102bb9;
          iVar19 = func_0x(param_2);
          if (iVar19 == 0) {
            uVar20 = *(uint *)(&stack0x00000060 + lVar23);
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102bcf;
            iVar19 = func_0x(param_2,1);
            uVar20 = 8;
            if (iVar19 != 0) {
              uVar20 = 10;
            }
            *(longlong *)(&stack0x000000c0 + lVar23) = param_2 + 0x10;
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102bed;
          uVar25 = func_0x();
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102bfa;
          iVar19 = func_0x(uVar25,0xe49);
          if (iVar19 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102c08;
            uVar22 = func_0x(0x10);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102c12;
            lVar24 = func_0x(uVar31);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102c1d;
            func_0x(lVar24 + 100,uVar22);
          }
          *(uint *)(&stack0x00000060 + lVar23) = uVar20 | 0x1000;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102c3e;
          func_0x(&stack0x00000958 + lVar23,1);
          uVar20 = *(byte *)(param_2 + 0x16) - 2;
          if (uVar20 < 0x7d) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)uVar20 + 0x10d2cc) * 4 +
                                   0x10d27c) - 0x145f140);
                    /* WARNING: Could not emulate address calculation at 0x00102c59 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = 0x105a6e8;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cc65;
          (*_DAT_)(1,0x145f540,0x1463170,0x3590);
          iVar19 = *piVar2;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cc75;
          lVar24 = func_0x(*(undefined8 *)(&stack0x00000070 + lVar23));
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cc83;
          sVar16 = func_0x(lVar24 + 0x62,8);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cc98;
          uVar31 = func_0x(param_2,&stack0x0000087c + lVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cca0;
          uVar12 = func_0x(uVar31);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ccb5;
          func_0x
                    (*(undefined8 *)(&stack0x00000068 + lVar23),
                     *(undefined8 *)(&stack0x000000b8 + lVar23),uVar12,sVar16 != 0);
          lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cccb;
          uVar31 = func_0x(*(undefined8 *)(&stack0x00000078 + lVar23),lVar24 + 0x10);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ccde;
          uVar25 = func_0x
                             (&stack0x00000980 + lVar23,*(undefined8 *)(&stack0x000000b8 + lVar23));
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ccf0;
          func_0x(lVar24,uVar25,uVar31,0xded0);
          uVar31 = *(undefined8 *)(&stack0x00000070 + lVar23);
          if (*(int *)(&stack0x000002a0 + lVar23) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd05;
            uVar25 = func_0x(uVar31);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd16;
            func_0x(uVar25,1);
          }
          lVar24 = *(longlong *)(&stack0x00000078 + lVar23);
          if ((*(byte *)(lVar24 + 0x24) & 4) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd30;
            uVar31 = func_0x(uVar31);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd3b;
            uVar25 = func_0x(lVar24);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd49;
            func_0x(uVar25,uVar31,1);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd5d;
          uVar31 = func_0x(&stack0x000015a0 + lVar23,0,0,0);
          plVar29 = *(longlong **)(&stack0x00000070 + lVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd6e;
          func_0x(plVar29,0,uVar31);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd73;
          uVar31 = func_0x();
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd80;
          iVar21 = func_0x(uVar31,0xe49);
          if (iVar21 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd8e;
            uVar22 = func_0x(0x10);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cd98;
            lVar35 = func_0x(plVar29);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cda3;
            func_0x(lVar35 + 100,uVar22);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cdab;
            func_0x(plVar29);
          }
          if (iVar19 != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cdbc;
              lVar35 = func_0x(0x19f1c40);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cdc7;
              uVar25 = func_0x(lVar24);
              uVar31 = *(undefined8 *)(lVar35 + 0x20);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cdd7;
              cVar10 = func_0x(uVar31,uRam0000000000000024,uVar25);
            } while (cVar10 == '\0');
          }
          if (*(int *)(&stack0x000002a4 + lVar23) != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cdf0;
              lVar35 = func_0x(0x19f1c40);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cdfb;
              uVar25 = func_0x(lVar24);
              uVar31 = *(undefined8 *)(lVar35 + 0x20);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ce0e;
              cVar10 = func_0x(uVar31,uRam0000000000000190,uVar25);
            } while (cVar10 == '\0');
          }
          if (*(int *)(&stack0x0000028c + lVar23) != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ce2c;
              lVar35 = func_0x(0x19f1c40);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ce37;
              uVar25 = func_0x(lVar24);
              uVar31 = *(undefined8 *)(lVar35 + 0x20);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ce4a;
              cVar10 = func_0x(uVar31,uRam0000000000000188,uVar25);
            } while (cVar10 == '\0');
          }
          if (*(int *)(&stack0x00000288 + lVar23) != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ce6c;
              lVar35 = func_0x(0x19f1c40);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ce77;
              uVar25 = func_0x(lVar24);
              uVar31 = *(undefined8 *)(lVar35 + 0x20);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ce8b;
              cVar10 = func_0x(uVar31,uVar25,uRam000000000000013a);
            } while (cVar10 == '\0');
          }
          iVar19 = *(int *)(&stack0x00000308 + lVar23);
          if (iVar19 == 0) {
            if (*(int *)(&stack0x00000354 + lVar23) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cf7d;
              uVar31 = func_0x(plVar29);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cf88;
              func_0x(plVar29);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cf92;
              func_0x(uVar31,0);
            }
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cea7;
            func_0x(plVar29);
            uVar25 = _DAT_;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ceba;
            puVar32 = (undefined8 *)func_0x(&stack0x00000910 + lVar23);
            puVar38 = *(undefined8 **)(&stack0x00000078 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cec9;
            uVar26 = func_0x(puVar38);
            uVar31 = *puVar32;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10ceda;
            func_0x(uVar25,uVar31,uVar26,0);
            uVar31 = *puVar38;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cee2;
            cVar10 = func_0x(uVar31);
            if (((cVar10 != '\0') && (*(char *)(puVar38 + 0xbfb) != '\0')) && (iVar19 == 2)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cefd;
              uVar31 = func_0x(puVar38);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cf05;
              uVar31 = func_0x(uVar31);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cf0f;
              func_0x(uVar31,0);
            }
            plVar29 = *(longlong **)(&stack0x00000070 + lVar23);
          }
          if ((&stack0x00000055)[lVar23] != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cf2e;
            iVar19 = func_0x(plVar29,4);
            if ((iVar19 == 0) && (lVar24 = *plVar29, lVar24 != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cf50;
              sVar16 = func_0x(lVar24 + 0x62,0x400);
              if ((sVar16 == 0) || (*(short *)((longlong)plVar29 + 0xc) < 3)) {
                iVar19 = (int)*(short *)((longlong)plVar29 + 0xc);
                plVar29 = *(longlong **)(&stack0x00000070 + lVar23);
                lVar24 = *plVar29;
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cfb0;
                sVar16 = func_0x(lVar24 + 0x62,8);
                if ((sVar16 != 0) && ((iVar21 = 4, iVar19 == 3 || (iVar21 = iVar19, 1 < iVar19)))) {
                  iVar19 = iVar21;
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cfd2;
                  iVar21 = func_0x(lVar24 + 100,8);
                  if ((iVar21 != 0) && (*(longlong *)(lVar24 + 0x90) != 0)) {
                    uVar31 = *(undefined8 *)(lVar24 + 0x90);
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cff5;
                    func_0x(uVar31,lVar24,iVar19);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cffa;
                uVar31 = func_0x();
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d007;
                iVar21 = func_0x(uVar31,0x32f);
                if (iVar21 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d019;
                  iVar21 = func_0x(lVar24 + 100,8);
                  if ((iVar21 != 0) && (2 < iVar19)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d02d;
                    func_0x(lVar24,1);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d03b;
                func_0x(lVar24 + 0x98,iVar19);
                if (_DAT_ != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d049;
                  uVar31 = func_0x();
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d056;
                  iVar21 = func_0x(uVar31,0xe79);
                  if (iVar21 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d067;
                    func_0x(lVar24,0,iVar19);
                  }
                }
                *(undefined2 *)((longlong)plVar29 + 0xc) = 0;
                *plVar29 = 0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10cf64;
                func_0x(plVar29);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d07b;
          func_0x(&stack0x00000958 + lVar23);
          goto LAB_;
        }
        *(undefined2 *)(lVar35 + 0x22) = 0xbed0;
        if ((((*(byte *)(*(longlong *)(*plVar29 + 0x6b0) + 0x3c) & 1) != 0) &&
            (*(longlong *)(*(longlong *)(*plVar29 + 0x6b0) + 0x280) == 0)) &&
           ((*(byte *)(lVar24 + 100) & 0x40) == 0)) {
          uVar22 = *(undefined4 *)(param_2 + 0x18);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101d1a;
          uVar25 = func_0x(lVar28,&stack0x000015b0 + lVar23,0,0);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101d30;
          (*_DAT_)(lVar24,uVar25,&stack0x000012f8 + lVar23,uVar22);
          lVar35 = *(longlong *)(&stack0x00000080 + lVar23);
        }
        plVar6 = *(longlong **)(&stack0x00000070 + lVar23);
        if (((*(uint *)(*plVar6 + 100) & 2) == 0) && (_DAT_ != 0)) {
          if ((*(ushort *)(*plVar6 + 0x62) & 0x10) == 0) {
            if ((*(uint *)((longlong)plVar29 + 0x24) >> 7 & 1) != 0) {
              uVar17 = *(undefined2 *)(*(longlong *)(*plVar29 + 0x6b0) + 0x28);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101d83;
              cVar10 = func_0x(uVar17);
              if (cVar10 != '\0') goto LAB_;
            }
          }
          else {
LAB_:
            if ((*(uint *)((longlong)plVar29 + 0x24) >> 7 & 1) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101da6;
              uVar25 = func_0x(lVar28,&stack0x00001590 + lVar23,0,0);
              lVar27 = *plVar29;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101db8;
              func_0x(lVar27 + 0x6a40,uVar25);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101dc5;
            func_0x(plVar6,0,0);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101dd9;
            func_0x(&stack0x000014a0 + lVar23,0,0,0);
            lVar27 = *plVar6;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101df3;
            func_0x(_DAT_,lVar27,0,&stack0x000014a0 + lVar23);
            LOCK();
            *_DAT_ = *_DAT_ + 1;
            UNLOCK();
          }
        }
        if (*(char *)(param_2 + 0x16) == '\x10') {
          if (*(longlong *)(*(longlong *)(*plVar29 + 0x6b0) + 0x280) == 0) {
            if ((*(int *)(plVar29 + 4) == 1) && (*(char *)(lVar24 + 0x5b) == '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101eeb;
              func_0x(plVar29,param_2);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101ef7;
              uVar31 = func_0x(plVar29,lVar35 + 0x10);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101f0f;
              uVar25 = func_0x(lVar28,&stack0x00000990 + lVar23,0,0);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101f24;
              func_0x(*(undefined8 *)(&stack0x00000080 + lVar23),uVar25,uVar31,0xbed0);
            }
          }
          else {
            plVar29 = (longlong *)plVar29[0xbf0];
            if (plVar29 != (longlong *)0x0) {
              uVar31 = *(undefined8 *)
                        (*plVar29 +
                        ((ulonglong)*(uint *)(lVar35 + 0x10) % (ulonglong)*(uint *)(plVar29 + 1)) *
                        8);
            }
            *(undefined8 *)(&stack0x000003b8 + lVar23) =
                 **(undefined8 **)(&stack0x000000b8 + lVar23);
            *(undefined2 *)(&stack0x000003c0 + lVar23) =
                 *(undefined2 *)(*(undefined8 **)(&stack0x000000b8 + lVar23) + 1);
            *(undefined2 *)(lVar35 + 0x22) = 0xbed0;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101e75;
            iVar19 = func_0x(lVar35 + 0x24);
            *(undefined8 *)(lVar35 + 0x24) = *(undefined8 *)(&stack0x000003b8 + lVar23);
            *(undefined2 *)(lVar35 + 0x2c) = *(undefined2 *)(&stack0x000003c0 + lVar23);
            lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
            *(int *)(lVar24 + 0x30) = iVar19 + 2;
            *(undefined8 *)(&stack0x00000608 + lVar23) = *(undefined8 *)(&stack0x000003b8 + lVar23);
            *(undefined2 *)(&stack0x00000610 + lVar23) = *(undefined2 *)(&stack0x000003c0 + lVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101ec6;
            func_0x(lVar24,&stack0x00000608 + lVar23,uVar31);
          }
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101f31;
          cVar10 = func_0x(param_2);
          if (cVar10 == '\x13') {
            lVar24 = *plVar29;
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101f41;
            cVar10 = func_0x(lVar24);
            if (cVar10 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101f55;
              uVar25 = func_0x(plVar29,lVar35 + 0x10);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101f6d;
              uVar26 = func_0x(lVar28,&stack0x000009a0 + lVar23,0,0);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101f82;
              func_0x(*(undefined8 *)(&stack0x00000080 + lVar23),uVar26,uVar25,0xbed0);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101f8e;
              iVar19 = func_0x(plVar29 + 0xb74);
              if (iVar19 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101f9d;
                uVar25 = func_0x(param_2);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101fa8;
                lVar24 = func_0x(plVar29,uVar25);
                if (lVar24 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101fb5;
                  uVar31 = func_0x(lVar24);
                }
              }
              lVar24 = *plVar29;
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101fc5;
              uVar25 = func_0x(lVar24);
              (&stack0xffffffffffffffe8)[lVar23] = 1;
              (&stack0xffffffffffffffe0)[lVar23] = *(undefined *)(plVar29 + 0xbfb);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101fe6;
              func_0x(uVar25,param_2,lVar28,uVar31);
              goto LAB_;
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x101ff7;
          uVar31 = func_0x(plVar29,lVar35 + 0x10);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10200f;
          uVar25 = func_0x(lVar28,&stack0x000009b0 + lVar23,0,0);
          lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102027;
          func_0x(lVar24,uVar25,uVar31,0xbed0);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10203c;
          uVar31 = func_0x(lVar28,&stack0x00001520 + lVar23,0,0);
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102048;
          iVar19 = func_0x(lVar24 + 0x18,uVar31);
          if (iVar19 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102054;
            lVar24 = func_0x(plVar6);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102062;
            iVar19 = func_0x(lVar24 + 100,2);
            uVar31 = _DAT_;
            if (iVar19 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102075;
              uVar25 = func_0x(plVar6);
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102080;
              func_0x(uVar31,uVar25);
            }
          }
        }
LAB_:
        if (((&stack0x00000055)[lVar23] != '\0') || (lVar24 = *plVar6, lVar24 == 0))
        goto LAB_;
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1020a5;
        sVar16 = func_0x(lVar24 + 0x62,0x400);
        if ((sVar16 != 0) && (2 < *(short *)((longlong)plVar6 + 0xc))) {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1020bb;
          func_0x(plVar6);
          goto LAB_;
        }
        iVar19 = (int)*(short *)((longlong)plVar6 + 0xc);
        lVar24 = *plVar6;
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1020d8;
        sVar16 = func_0x(lVar24 + 0x62,8);
        if (sVar16 != 0) {
          if (iVar19 == 3) {
            iVar19 = 4;
          }
          else if (iVar19 < 2) goto LAB_;
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1020fc;
          iVar21 = func_0x(lVar24 + 100,8);
          if ((iVar21 != 0) && (*(longlong *)(lVar24 + 0x90) != 0)) {
            uVar31 = *(undefined8 *)(lVar24 + 0x90);
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10211f;
            func_0x(uVar31,lVar24,iVar19);
          }
        }
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102124;
        uVar31 = func_0x();
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102131;
        iVar21 = func_0x(uVar31,0x32f);
        if (iVar21 != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102143;
          iVar21 = func_0x(lVar24 + 100,8);
          if ((iVar21 != 0) && (2 < iVar19)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102159;
            func_0x(lVar24,1);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102167;
        func_0x(lVar24 + 0x98,iVar19);
        if (_DAT_ != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102175;
          uVar31 = func_0x();
          *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102182;
          iVar21 = func_0x(uVar31,0xe79);
          if (iVar21 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x102193;
            func_0x(lVar24,0,iVar19);
          }
        }
        *(undefined2 *)((longlong)plVar6 + 0xc) = 0;
        *plVar6 = 0;
        goto LAB_;
      }
      if (bVar9) {
        pplVar37 = *(longlong ***)(&stack0x00000070 + lVar23);
        if (*pplVar37 != (longlong *)0x0) {
          if (((*(ushort *)((longlong)*pplVar37 + 0x62) >> 10 & 1) == 0) ||
             (*(short *)((longlong)pplVar37 + 0xc) < 3)) {
            iVar19 = (int)*(short *)((longlong)pplVar37 + 0xc);
            plVar29 = *pplVar37;
            if (((byte)*(undefined2 *)((longlong)plVar29 + 0x62) >> 3 & 1) != 0) {
              if (iVar19 == 3) {
                iVar19 = 4;
              }
              else if (iVar19 < 2) goto LAB_;
              if ((((*(uint *)((longlong)plVar29 + 100) & 8) != 0) &&
                  (lVar24 = plVar29[0x12], lVar24 != 0)) && (*(longlong *)(lVar24 + 0x758) != 0)) {
                uVar25 = *(undefined8 *)(lVar24 + 0x758);
                *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d111;
                func_0x(uVar25,plVar29,iVar19);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
               ((2 < iVar19 &&
                (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 && (*plVar29 != 0)
                 ))))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d146;
              func_0x(plVar29,1);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d155;
            func_0x(plVar29 + 0x13);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d174;
              func_0x(plVar29,0,iVar19);
            }
            *(undefined2 *)((longlong)pplVar37 + 0xc) = 0;
            *pplVar37 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d0b3;
            func_0x(pplVar37);
          }
        }
      }
      plVar29 = (longlong *)param_1[0xbf0];
      lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
      if (plVar29 != (longlong *)0x0) {
        uVar31 = *(undefined8 *)
                  (*plVar29 +
                  ((ulonglong)*(uint *)(lVar24 + 0x10) % (ulonglong)*(uint *)(plVar29 + 1)) * 8);
      }
      *(undefined8 *)(&stack0x000003a8 + lVar23) = **(undefined8 **)(&stack0x000000b8 + lVar23);
      *(undefined2 *)(&stack0x000003b0 + lVar23) =
           *(undefined2 *)(*(undefined8 **)(&stack0x000000b8 + lVar23) + 1);
      *(undefined2 *)(lVar24 + 0x22) = 0x5ed0;
      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d1d0;
      iVar19 = func_0x(lVar24 + 0x24);
      *(undefined8 *)(lVar24 + 0x24) = *(undefined8 *)(&stack0x000003a8 + lVar23);
      *(undefined2 *)(lVar24 + 0x2c) = *(undefined2 *)(&stack0x000003b0 + lVar23);
      *(int *)(lVar24 + 0x30) = iVar19 + 2;
      *(undefined8 *)(&stack0x00000558 + lVar23) = *(undefined8 *)(&stack0x000003a8 + lVar23);
      *(undefined2 *)(&stack0x00000560 + lVar23) = *(undefined2 *)(&stack0x000003b0 + lVar23);
      puVar36 = &stack0x00000558;
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x100468;
      iVar19 = func_0x(param_1,lVar24,param_2);
      if (iVar19 == 0) goto LAB_;
      plVar29 = (longlong *)param_1[0xbf0];
      lVar24 = *(longlong *)(&stack0x00000080 + lVar23);
      if (plVar29 != (longlong *)0x0) {
        uVar31 = *(undefined8 *)
                  (*plVar29 +
                  ((ulonglong)*(uint *)(lVar24 + 0x10) % (ulonglong)*(uint *)(plVar29 + 1)) * 8);
      }
      *(undefined8 *)(&stack0x00000398 + lVar23) = **(undefined8 **)(&stack0x000000b8 + lVar23);
      *(undefined2 *)(&stack0x000003a0 + lVar23) =
           *(undefined2 *)(*(undefined8 **)(&stack0x000000b8 + lVar23) + 1);
      *(undefined2 *)(lVar24 + 0x22) = 0x5ed0;
      *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x1004c4;
      iVar19 = func_0x(lVar24 + 0x24);
      *(undefined8 *)(lVar24 + 0x24) = *(undefined8 *)(&stack0x00000398 + lVar23);
      *(undefined2 *)(lVar24 + 0x2c) = *(undefined2 *)(&stack0x000003a0 + lVar23);
      *(int *)(lVar24 + 0x30) = iVar19 + 2;
      *(undefined8 *)(&stack0x00000588 + lVar23) = *(undefined8 *)(&stack0x00000398 + lVar23);
      *(undefined2 *)(&stack0x00000590 + lVar23) = *(undefined2 *)(&stack0x000003a0 + lVar23);
      puVar36 = &stack0x00000588;
    }
    puVar36 = puVar36 + lVar23;
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d227;
  func_0x(lVar24,puVar36,uVar31);
LAB_:
  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d239;
  func_0x(&stack0x00000178 + lVar23);
  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d246;
  func_0x(&stack0x00000938 + lVar23);
  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d253;
  func_0x(&stack0x00001608 + lVar23);
  *(undefined8 *)((longlong)&uStack_48 + lVar23) = 0x10d265;
  func_0x(*(ulonglong *)(&stack0x000079f0 + lVar23) ^ (ulonglong)piVar2);
  return;
}

