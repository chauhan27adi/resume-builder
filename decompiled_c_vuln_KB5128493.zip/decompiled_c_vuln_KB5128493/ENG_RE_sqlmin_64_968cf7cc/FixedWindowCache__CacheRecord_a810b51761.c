
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong *param_2,longlong param_3,undefined8 *param_4)

{
  uint *puVar1;
  ushort uVar2;
  undefined4 uVar3;
  byte bVar4;
  bool bVar5;
  short *psVar6;
  int *piVar7;
  undefined8 *puVar8;
  char cVar9;
  short sVar10;
  ushort uVar11;
  ushort uVar12;
  undefined2 uVar13;
  undefined4 uVar14;
  longlong lVar15;
  longlong lVar16;
  undefined8 uVar17;
  undefined4 *puVar18;
  byte *pbVar19;
  longlong *plVar20;
  undefined uVar21;
  int iVar22;
  ulonglong uVar23;
  uint uVar24;
  longlong lVar25;
  longlong *plVar26;
  uint *puVar27;
  undefined *puVar28;
  undefined *puVar29;
  uint uVar30;
  uint uVar31;
  int iVar32;
  ushort *puVar33;
  ushort *puVar34;
  short *psVar35;
  uint uVar36;
  uint uVar37;
  ulonglong uVar38;
  byte bVar39;
  undefined8 uStack_320;
  undefined auStack_318 [80];
  longlong lStack_2c8;
  short *psStack_2c0;
  uint uStack_2b8;
  longlong *plStack_2b0;
  uint *puStack_2a8;
  int iStack_2a0;
  uint uStack_29c;
  uint uStack_298;
  int *piStack_290;
  uint uStack_288;
  undefined auStack_284 [4];
  int *piStack_280;
  longlong *plStack_278;
  uint *puStack_270;
  uint uStack_268;
  uint uStack_264;
  longlong lStack_260;
  longlong lStack_258;
  undefined8 uStack_250;
  undefined4 uStack_248;
  longlong lStack_240;
  undefined *puStack_228;
  undefined8 uStack_220;
  longlong lStack_218;
  int iStack_210;
  int iStack_208;
  uint uStack_204;
  int *piStack_200;
  undefined4 uStack_1f8;
  undefined2 uStack_1f4;
  undefined2 uStack_1f2;
  longlong lStack_1f0;
  int iStack_1e8;
  undefined8 *puStack_1e0;
  undefined auStack_1d8 [8];
  undefined auStack_1d0 [8];
  undefined auStack_1c8 [8];
  undefined auStack_1c0 [4];
  short sStack_1bc;
  ushort uStack_1ba;
  longlong lStack_1b8;
  longlong lStack_1b0;
  undefined8 uStack_198;
  undefined auStack_190 [16];
  undefined auStack_180 [24];
  undefined auStack_168 [64];
  undefined auStack_128 [224];
  ulonglong uStack_48;
  
  puVar28 = auStack_318;
  uStack_198 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&lStack_2c8;
  lVar25 = ((*param_1 + -1) % (longlong)*(int *)(param_1 + 1)) * 0x50 + param_1[2];
  *param_1 = *param_1 + 1;
  puStack_1e0 = param_4;
  if (*(longlong *)(lVar25 + 0x10) != 0) {
    lStack_218 = 0;
    iStack_210 = 0;
    *(undefined8 *)(lVar25 + 0x10) = 0;
    *(undefined8 *)(lVar25 + 8) = 0xffff;
    *(undefined8 *)(lVar25 + 0x20) = 0;
    *(undefined8 *)(lVar25 + 0x28) = 0;
    *(undefined8 *)(lVar25 + 0x18) = 0;
    *(undefined4 *)(lVar25 + 0x38) = 0;
    *(undefined8 *)(lVar25 + 0x30) = 0;
    uStack_320 = 0x1000bf;
    func_0x(&lStack_218,param_4);
    lVar16 = lStack_218;
    uStack_320 = 0x1000cf;
    func_0x(*(undefined8 *)(lStack_218 + 8));
    uStack_320 = 0x1000db;
    func_0x(*(undefined8 *)(lVar16 + 8),0xffffffffffffffff);
    if (iStack_210 != 0) {
      uStack_320 = 0x1000f8;
      func_0x(*(longlong *)(lVar16 + 8) + 0x630,2);
      iStack_210 = 0;
    }
    lStack_218 = 0;
  }
  uStack_320 = 0x10011a;
  func_0x(auStack_168);
  lStack_1f0 = 0;
  iStack_1e8 = 0;
  uStack_264 = 0;
  uStack_250 = 0;
  uStack_248 = 0;
  uStack_320 = 0x100143;
  func_0x(auStack_1c0);
  lVar16 = param_4[1];
  bVar39 = *(byte *)(lVar16 + 0x106) & 1;
  puVar29 = auStack_318;
  uVar30 = uStack_264;
  if (param_2 == (longlong *)0x0) goto LAB_;
  if ((*(int *)(param_4 + 5) == *(int *)(param_2 + 1)) &&
     (*param_2 == (ulonglong)*(uint6 *)((longlong)param_4 + 0x14) * 0x10000)) {
    uStack_320 = 0x100191;
    sVar10 = (**(code **)*param_4)(param_4);
    if (*(short *)((longlong)param_2 + 0xc) != sVar10) goto LAB_;
    if (param_2[0x15] != 0) {
      LOCK();
      UNLOCK();
    }
  }
  else {
LAB_:
    uStack_320 = 0x1001b3;
    func_0x(param_2,param_4);
  }
  uVar11 = *(ushort *)(param_2 + 7);
  uVar12 = *(ushort *)((longlong)param_2 + 0x62);
  plStack_278 = param_2;
  lStack_260 = param_3;
  if ((uVar11 >> 10 & 1) == 0) {
    lStack_258 = 0;
    uStack_220 = 0;
    puStack_270 = (uint *)param_2[0xe];
    lVar16 = param_4[1];
    uStack_250 = *(undefined8 *)(**(longlong **)(lVar16 + 0x160) + 0xa8);
    uStack_248 = *(undefined4 *)(**(longlong **)(lVar16 + 0x160) + 0xb0);
    puVar29 = auStack_318;
    uStack_268 = (uint)uVar12;
    uVar30 = uStack_264 | 0x10;
  }
  else {
    if (uVar12 == 0) {
      iVar22 = 0;
      uVar12 = 0;
      puVar27 = (uint *)0x0;
      plVar26 = (longlong *)0x0;
    }
    else {
      iVar22 = (uint)uVar12 * 8;
      uStack_320 = 0x10023b;
      lVar16 = func_0x();
      lVar16 = -lVar16;
      puStack_2a8 = (uint *)((longlong)&lStack_2c8 + lVar16);
      *(undefined8 *)(auStack_318 + lVar16 + -8) = 0x10025c;
      lVar15 = func_0x();
      lVar15 = -lVar15;
      puVar28 = auStack_318 + lVar15 + lVar16;
      plVar26 = (longlong *)((longlong)&lStack_2c8 + lVar15 + lVar16);
      uVar2 = *(ushort *)(param_2 + 0xb);
      uVar36 = 0x1f9e;
      uVar30 = *(uint *)((longlong)param_2 + 0x54);
      plStack_2b0 = plVar26;
      if (((0x1f9e < *(uint *)((longlong)param_2 + 0x54)) && (uVar30 = (uint)uVar2, uVar2 < 0x1f9e))
         || (puVar27 = puStack_2a8, uVar36 = uVar30, uVar30 != 0)) {
        puStack_228 = auStack_1c0;
        *(undefined8 *)(auStack_318 + lVar15 + lVar16 + -8) = 0x1002a4;
        func_0x(auStack_1c0);
        uVar23 = (ulonglong)uVar36 + 0xf;
        if (uVar23 <= uVar36) {
          uVar23 = 0xffffffffffffff0;
        }
        uVar23 = uVar23 & 0xfffffffffffffff0;
        *(undefined8 *)(auStack_318 + lVar15 + lVar16 + -8) = 0x1002c5;
        func_0x();
        puVar28 = auStack_318 + -uVar23 + lVar15 + lVar16;
        lStack_1b8 = (longlong)&lStack_2c8 + -uVar23 + lVar15 + lVar16;
        sStack_1bc = (short)uVar36 - uVar2;
        uVar12 = *(ushort *)((longlong)param_2 + 0x62);
        uVar11 = *(ushort *)(param_2 + 7);
        puVar27 = puStack_2a8;
        plVar26 = plStack_2b0;
        uStack_1ba = uVar2;
      }
    }
    puVar8 = puStack_1e0;
    uVar36 = (uint)uVar12;
    lStack_258 = 0;
    uStack_220 = 0;
    puStack_270 = (uint *)param_2[0xe];
    lVar16 = puStack_1e0[1];
    uStack_250 = *(undefined8 *)(**(longlong **)(lVar16 + 0x160) + 0xa8);
    uStack_248 = *(undefined4 *)(**(longlong **)(lVar16 + 0x160) + 0xb0);
    puVar29 = puVar28;
    uStack_268 = uVar36;
    uVar30 = uStack_264 | 0x10;
    if (((uVar11 >> 10 & 1) != 0) && (param_3 != 0)) {
      uStack_264 = uStack_264 | 0x14;
      *(int *)(puVar28 + 0x30) = iVar22;
      *(longlong **)(puVar28 + 0x28) = plVar26;
      *(int *)(puVar28 + 0x20) = iVar22;
      *(undefined8 *)(puVar28 + -8) = 0x100398;
      func_0x(&plStack_278,puVar8,uVar36,puVar27);
      lVar16 = puVar8[1];
      uVar30 = uStack_264;
    }
  }
LAB_:
  uStack_264 = uVar30;
  plVar26 = (longlong *)0x0;
  psVar35 = (short *)(lVar25 + 8);
  uVar30 = *(uint *)(lVar25 + 0x48);
  uVar17 = *(undefined8 *)(lVar25 + 0x40);
  uVar36 = *(uint *)(lVar16 + 0xb0);
  if ((*(int *)(lVar16 + 0x100) == 0) || (*(int *)(lVar16 + 0x100) - 3U < 2)) {
    bVar5 = false;
  }
  else {
    bVar5 = true;
  }
  psStack_2c0 = psVar35;
  uStack_2b8 = uVar36;
  uStack_29c = uVar30;
  if ((*(byte *)(plStack_278 + 7) & 0x20) == 0) {
    if (bVar5) {
      plStack_2b0 = (longlong *)0x0;
      plVar20 = plVar26;
      if ((uStack_264 & 0x10) != 0) {
        plVar20 = plStack_278;
      }
      uVar31 = -*(int *)(plVar20 + 2);
      uVar14 = *(undefined4 *)(plVar20 + 3);
      uVar3 = *(undefined4 *)((longlong)plVar20 + 0x14);
      uStack_298 = uVar31;
      *(undefined2 *)(puVar29 + 0x28) = 1;
      *(undefined4 *)(puVar29 + 0x20) = uVar14;
      if (bVar39 == 0) {
        *(undefined8 *)(puVar29 + -8) = 0x101e4e;
        func_0x(psVar35,uVar17,uVar30,uVar3);
      }
      else {
        *(undefined8 *)(puVar29 + -8) = 0x101e47;
        func_0x();
      }
      if (uVar31 != 0) {
        *(undefined8 *)(puVar29 + -8) = 0x101e78;
        lVar25 = func_0x();
        lVar25 = -lVar25;
        plVar26 = (longlong *)(puVar29 + lVar25 + 0x50);
        plStack_2b0 = plVar26;
        *(undefined8 *)(puVar29 + lVar25 + -8) = 0x101e8e;
        func_0x(plVar26,0);
        puVar29 = puVar29 + lVar25;
      }
      plVar20 = plStack_2b0;
      piStack_290 = (int *)0x0;
      if (*(ushort *)((longlong)plStack_278 + 0x62) != 0) {
        puVar27 = puStack_270 + 0xe;
        puStack_2a8 = (uint *)(ulonglong)*(ushort *)((longlong)plStack_278 + 0x62);
        do {
          puVar1 = puVar27 + -0xe;
          uVar30 = *puVar1;
          *(undefined8 *)(puVar29 + -8) = 0x101ed7;
          func_0x(&plStack_278,puVar1,&lStack_2c8);
          if ((char)lStack_2c8 == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar27 + 4) + 0xc) & 0x400) == 0) &&
               ((puVar27[2] & 0x4000) == 0)) {
              *(undefined8 *)(puVar29 + -8) = 0x1021be;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar29 + -8) = 0x1021cf;
            func_0x(psVar35,puVar1,0,0);
            if ((int)uVar30 < 0) {
              puVar1 = (uint *)((longlong)(int)~uVar30 * 0x20 + 0xc + (longlong)plVar20);
              *puVar1 = *puVar1 | 2;
            }
          }
          else {
            if (*(short *)(puVar27 + -0xd) != 0) {
              if (*psVar35 == 0) {
                *(undefined8 *)(puVar29 + -8) = 0x101efa;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar29 + -8) = 0x101f01;
                func_0x(psVar35 + 1,puVar1);
              }
            }
            *(undefined8 *)(puVar29 + -8) = 0x101f11;
            func_0x(&plStack_278,puVar1,&piStack_290);
            piVar7 = piStack_290;
            cVar9 = *(char *)(puVar27 + 2);
            if ((cVar9 == '\x01') || (cVar9 == '\x02')) {
              if ((puVar27[2] >> 8 & 1) == 0) {
                uVar30 = *puVar1;
                lVar25 = *(longlong *)(psVar35 + 4);
                uVar13 = *(undefined2 *)(puVar27 + 1);
                *(undefined8 *)(puVar29 + -8) = 0x10207f;
                func_0x((int)uVar30 + lVar25,piVar7,uVar13);
              }
              else {
                if (((puVar27[2] & 0x8000) == 0) || ((uStack_264 & 8) == 0)) {
                  lVar25 = lStack_260;
                  if ((*(byte *)(*(longlong *)(puVar27 + 4) + 0x2a) & 0x10) != 0) {
                    lVar25 = lStack_258;
                  }
                  uVar30 = *(uint *)(*(longlong *)(*(longlong *)(puVar27 + 4) + 0x18) + lVar25);
                }
                else {
                  uVar30 = *(uint *)(lStack_240 + (ulonglong)*puVar27 * 8);
                }
                uVar36 = (uint)*(ushort *)(puVar27 + 1);
                if (uVar30 < uVar36) {
                  iVar22 = uVar36 - uVar30;
                }
                else {
                  iVar22 = 0;
                  if (uVar36 < uVar30) {
                    *(undefined8 *)(puVar29 + -8) = 0x1020e8;
                    (*_DAT_)(6,0x5c,0x16);
                    iVar22 = 0;
                  }
                }
                uVar21 = *(undefined *)(*(longlong *)(puVar27 + 4) + 0x24);
                uVar36 = *puVar1;
                lVar25 = *(longlong *)(psStack_2c0 + 4);
                if ((piVar7 != (int *)0x0) && (uVar30 != 0)) {
                  *(undefined8 *)(puVar29 + -8) = 0x102113;
                  func_0x((int)uVar36 + lVar25,piVar7,uVar30);
                }
                psVar35 = psStack_2c0;
                if (iVar22 != 0) {
                  *(undefined8 *)(puVar29 + -8) = 0x102128;
                  func_0x((ulonglong)uVar30 + (int)uVar36 + lVar25,uVar21,iVar22);
                  psVar35 = psStack_2c0;
                }
              }
            }
            else if ((cVar9 == '\x03') || (cVar9 == '\x04')) {
              uVar36 = puVar27[2];
              if (((uVar36 >> 0xd & 1) == 0) || (*piStack_290 != 0)) {
                if (((uVar36 & 0x8000) == 0) || ((uStack_264 & 8) == 0)) {
                  lVar25 = *(longlong *)(puVar27 + 4);
                  if ((uVar36 >> 8 & 1) == 0) {
                    uVar36 = (uint)*(ushort *)(lVar25 + 2);
                  }
                  else {
                    lVar16 = lStack_260;
                    if ((*(byte *)(lVar25 + 0x2a) & 0x10) != 0) {
                      lVar16 = lStack_258;
                    }
                    uVar36 = *(uint *)(*(longlong *)(lVar25 + 0x18) + lVar16);
                  }
                }
                else {
                  uVar36 = *(uint *)(lStack_240 + (ulonglong)*puVar27 * 8);
                }
              }
              else {
                uVar36 = 0;
              }
              if (*(ushort *)(puVar27 + 1) < uVar36) {
                *(undefined8 *)(puVar29 + -8) = 0x10202f;
                (*_DAT_)(6,0x52,0x16);
              }
              piVar7 = piStack_290;
              *(undefined4 *)(puVar29 + 0x28) = 0;
              *(uint **)(puVar29 + 0x20) = puVar1;
              *(undefined8 *)(puVar29 + -8) = 0x102059;
              func_0x(plVar20 + (longlong)(int)~uVar30 * 4,piVar7,uVar36);
              psVar35 = psStack_2c0;
            }
            else if (cVar9 == '\b') {
              if (*psVar35 == 0) {
                *(undefined8 *)(puVar29 + -8) = 0x101f89;
                func_0x(psVar35,puVar1,piVar7);
              }
              else {
                *(undefined4 *)(puVar29 + 0x28) = 0;
                *(uint **)(puVar29 + 0x20) = puVar1;
                piVar7 = piStack_290;
                *(undefined8 *)(puVar29 + -8) = 0x101fb6;
                func_0x(plVar20 + (longlong)(int)~uVar30 * 4,piVar7,1);
              }
            }
            else {
              *(undefined8 *)(puVar29 + 0x20) = 0x782f28;
              *(undefined8 *)(puVar29 + -8) = 0x101f69;
              (*_DAT_)(1,0xb87d80,0xbb46c0);
            }
          }
          puVar27 = puVar27 + 0x14;
          puStack_2a8 = (uint *)((longlong)puStack_2a8 + -1);
          plVar26 = plStack_2b0;
          uVar30 = uStack_29c;
          uVar36 = uStack_2b8;
          uVar31 = uStack_298;
        } while (puStack_2a8 != (uint *)0x0);
      }
      uVar37 = uStack_29c;
      psVar6 = psStack_2c0;
      puVar34 = (ushort *)0x0;
      if (uVar31 != 0) {
        if (*psVar35 == 0) {
          do {
            uVar23 = (ulonglong)uVar31;
            uVar30 = uVar31 - 1;
            if (*(int *)(plVar26 + (ulonglong)uVar30 * 4 + 1) != 0) {
              psVar35[0xe] = (ushort)uVar31;
              iVar22 = *(int *)(psVar35 + 10) + 2 + uVar31 * 2;
              *(int *)(psVar35 + 0xc) = iVar22;
              *(int *)(psVar35 + 2) = iVar22;
              **(byte **)(psVar35 + 4) = **(byte **)(psVar35 + 4) | 0x20;
              if (*(uint *)(psVar35 + 2) <= uStack_2b8) {
                puVar34 = (ushort *)
                          ((ulonglong)*(uint *)(psVar35 + 10) + *(longlong *)(psVar35 + 4));
                *puVar34 = (ushort)uVar31;
              }
              if (uVar31 != 0) {
                puVar27 = (uint *)((longlong)plVar26 + 0xc);
                uVar30 = uStack_2b8;
                do {
                  puVar34 = puVar34 + 1;
                  uVar31 = *(uint *)(psVar6 + 2);
                  lVar25 = *(longlong *)(psVar6 + 4);
                  uVar24 = puVar27[-1];
                  uVar36 = uVar31 + uVar24;
                  *(uint *)(psVar6 + 2) = uVar36;
                  if ((uVar36 <= uVar30) && (uVar36 <= uVar37)) {
                    *puVar34 = (ushort)((*puVar27 & 1) << 0xf) | (ushort)uVar36 & 0x7fff;
                    uVar17 = *(undefined8 *)(puVar27 + -3);
                    *(undefined8 *)(puVar29 + -8) = 0x102281;
                    func_0x((ulonglong)uVar31 + lVar25,uVar24,uVar17,uVar24);
                    uVar30 = uStack_2b8;
                  }
                  puVar27 = puVar27 + 8;
                  uVar23 = uVar23 - 1;
                } while (uVar23 != 0);
              }
              break;
            }
            uVar31 = uVar30;
          } while (uVar30 != 0);
        }
        else {
          *(undefined **)(puVar29 + 0x28) = auStack_284;
          *(longlong **)(puVar29 + 0x20) = plVar26;
          *(undefined8 *)(puVar29 + -8) = 0x1022b7;
          func_0x(psVar35 + 1,uVar30,uVar36,uVar31);
        }
      }
    }
    else {
      *psVar35 = 0;
      puVar34 = (ushort *)(lVar25 + 10);
      plStack_2b0 = (longlong *)0x0;
      plVar20 = (longlong *)0x0;
      if ((uStack_264 & 0x10) != 0) {
        plVar20 = plStack_278;
      }
      uVar36 = -*(int *)(plVar20 + 2);
      uVar21 = 0;
      if (bVar39 == 0) {
        uVar21 = 6;
      }
      iVar22 = 4;
      if (bVar39 == 0) {
        iVar22 = 1;
      }
      iVar32 = *(int *)((longlong)plVar20 + 0x14);
      uStack_298 = uVar36;
      puVar29[0x28] = uVar21;
      *(undefined4 *)(puVar29 + 0x20) = *(undefined4 *)(plVar20 + 3);
      *(undefined8 *)(puVar29 + -8) = 0x100447;
      func_0x(puVar34,uVar17,uVar30,iVar32 - iVar22);
      if (uVar36 != 0) {
        *(undefined8 *)(puVar29 + -8) = 0x10046f;
        lVar16 = func_0x();
        lVar16 = -lVar16;
        plVar26 = (longlong *)(puVar29 + lVar16 + 0x50);
        plStack_2b0 = plVar26;
        *(undefined8 *)(puVar29 + lVar16 + -8) = 0x100485;
        func_0x(plVar26,0);
        puVar29 = puVar29 + lVar16;
      }
      uStack_204 = (uint)*(ushort *)((longlong)plStack_278 + 0x62);
      piStack_280 = (int *)0x0;
      uStack_288 = 0;
      puStack_2a8 = puStack_270;
      if (uStack_204 != 0) {
        do {
          puVar27 = puStack_2a8;
          uVar30 = *puStack_2a8;
          *(undefined8 *)(puVar29 + -8) = 0x1004db;
          func_0x(&plStack_278,puVar27,&lStack_2c8);
          if ((char)lStack_2c8 == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar27 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar27[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar29 + -8) = 0x101c21;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar29 + -8) = 0x101c32;
            func_0x(puVar34,puVar27,0,0);
            if ((int)uVar30 < 0) {
              puVar27 = (uint *)((longlong)(int)~uVar30 * 0x20 + 0xc + (longlong)plVar26);
              *puVar27 = *puVar27 | 2;
            }
          }
          else {
            if (*(short *)(puVar27 + 1) != 0) {
              *(undefined8 *)(puVar29 + -8) = 0x1004f8;
              func_0x(puVar34,puVar27);
            }
            *(undefined8 *)(puVar29 + -8) = 0x100508;
            func_0x(&plStack_278,puVar27,&piStack_280);
            piVar7 = piStack_280;
            cVar9 = *(char *)(puVar27 + 0x10);
            if ((cVar9 == '\x01') || (cVar9 == '\x02')) {
              if ((puVar27[0x10] >> 8 & 1) == 0) {
                uVar30 = *puVar27;
                lVar16 = *(longlong *)(lVar25 + 0x10);
                uVar13 = *(undefined2 *)(puVar27 + 0xf);
                *(undefined8 *)(puVar29 + -8) = 0x101b45;
                func_0x((int)uVar30 + lVar16,piVar7,uVar13);
              }
              else {
                if (((puVar27[0x10] & 0x8000) == 0) || ((uStack_264 & 8) == 0)) {
                  lVar16 = lStack_260;
                  if ((*(byte *)(*(longlong *)(puVar27 + 0x12) + 0x2a) & 0x10) != 0) {
                    lVar16 = lStack_258;
                  }
                  uVar30 = *(uint *)(*(longlong *)(*(longlong *)(puVar27 + 0x12) + 0x18) + lVar16);
                }
                else {
                  uVar30 = *(uint *)(lStack_240 + (ulonglong)puVar27[0xe] * 8);
                }
                uVar36 = (uint)*(ushort *)(puVar27 + 0xf);
                if (uVar30 < uVar36) {
                  iVar22 = uVar36 - uVar30;
                }
                else {
                  iVar22 = 0;
                  if (uVar36 < uVar30) {
                    *(undefined8 *)(puVar29 + -8) = 0x101bb0;
                    (*_DAT_)(6,0x5c,0x16);
                    iVar22 = 0;
                  }
                }
                uVar21 = *(undefined *)(*(longlong *)(puVar27 + 0x12) + 0x24);
                lVar16 = (longlong)(int)*puVar27 + *(longlong *)(lVar25 + 0x10);
                if ((piVar7 != (int *)0x0) && (uVar30 != 0)) {
                  *(undefined8 *)(puVar29 + -8) = 0x101bd8;
                  func_0x(lVar16,piVar7,uVar30);
                }
                if (iVar22 != 0) {
                  *(undefined8 *)(puVar29 + -8) = 0x101bf1;
                  func_0x((ulonglong)uVar30 + lVar16,uVar21,iVar22);
                }
              }
            }
            else if ((cVar9 == '\x03') || (cVar9 == '\x04')) {
              uVar36 = puVar27[0x10];
              if (((uVar36 >> 0xd & 1) == 0) || (*piStack_280 != 0)) {
                if (((uVar36 & 0x8000) == 0) || ((uStack_264 & 8) == 0)) {
                  lVar16 = *(longlong *)(puVar27 + 0x12);
                  if ((uVar36 >> 8 & 1) == 0) {
                    uVar36 = (uint)*(ushort *)(lVar16 + 2);
                  }
                  else {
                    lVar15 = lStack_260;
                    if ((*(byte *)(lVar16 + 0x2a) & 0x10) != 0) {
                      lVar15 = lStack_258;
                    }
                    uVar36 = *(uint *)(*(longlong *)(lVar16 + 0x18) + lVar15);
                  }
                }
                else {
                  uVar36 = *(uint *)(lStack_240 + (ulonglong)puVar27[0xe] * 8);
                }
              }
              else {
                uVar36 = 0;
              }
              if (*(ushort *)(puVar27 + 0xf) < uVar36) {
                *(undefined8 *)(puVar29 + -8) = 0x101aec;
                (*_DAT_)(6,0x52,0x16);
              }
              piVar7 = piStack_280;
              *(undefined4 *)(puVar29 + 0x28) = 0;
              *(uint **)(puVar29 + 0x20) = puVar27;
              *(undefined8 *)(puVar29 + -8) = 0x101b14;
              func_0x(plVar26 + (longlong)(int)~uVar30 * 4,piVar7,uVar36);
            }
            else if (cVar9 == '\b') {
              piStack_200 = piStack_280;
              uVar30 = *puVar27;
              lVar16 = (longlong)(int)uVar30;
              if ((int)uVar30 < 0) {
                if ((uVar30 & 0xc0000000) == 0x80000000) {
                  *(undefined8 *)(puVar29 + -8) = 0x1012ce;
                  func_0x(auStack_128);
                  iStack_2a0 = 0;
                  if (*(int *)(lVar25 + 0xc) == 0) {
                    *puVar34 = 0;
                    uVar30 = *(uint *)(lVar25 + 0x18);
                    uVar23 = (ulonglong)uVar30;
                    *(uint *)(lVar25 + 0x1c) = uVar30;
                    pbVar19 = *(byte **)(lVar25 + 0x10);
                    bVar39 = *pbVar19;
                    if ((bVar39 & 0x10) != 0) {
                      uVar30 = uVar30 + 2 + (*(ushort *)(pbVar19 + uVar23) + 7 >> 3);
                      uVar23 = (ulonglong)uVar30;
                      *(uint *)(lVar25 + 0x1c) = uVar30;
                      bVar39 = *pbVar19;
                    }
                    if ((bVar39 & 0x20) == 0) {
                      *(int *)(lVar25 + 0xc) = (int)uVar23;
                      *(undefined2 *)(lVar25 + 0x24) = 0;
                      *(int *)(lVar25 + 0x20) = (int)uVar23;
                    }
                    else {
                      puVar33 = (ushort *)(pbVar19 + uVar23);
                      uVar11 = *puVar33;
                      *(ushort *)(lVar25 + 0x24) = uVar11;
                      if (uVar11 == 0) {
                        *(undefined8 *)(puVar29 + -8) = 0x101334;
                        cVar9 = func_0x(0x1115cc0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x10133d;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar29 + -8) = 0x101357;
                            cVar9 = func_0x(0x1115cc0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar29 + -8) = 0x101373;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar29 + 0x20) = 0;
                              *(undefined8 *)(puVar29 + -8) = 0x101399;
                              (*_DAT_)(1,0xa06a48,0xb26718,0x80f);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(lVar25 + 0x10);
                        *(undefined8 *)(puVar29 + -8) = 0x1013a7;
                        func_0x(uVar17,3);
                        uVar23 = (ulonglong)*(uint *)(lVar25 + 0x1c);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                        uVar11 = *(ushort *)(lVar25 + 0x24);
                      }
                      uVar30 = (int)uVar23 + (uVar11 + 1) * 2;
                      *(uint *)(lVar25 + 0x20) = uVar30;
                      if (0x1f9e < uVar30) {
                        *(undefined8 *)(puVar29 + -8) = 0x1013db;
                        cVar9 = func_0x(0x1115cc0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x1013e4;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar29 + -8) = 0x1013fe;
                            cVar9 = func_0x(0x1115cc0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar29 + -8) = 0x10141a;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar29 + 0x20) = 0;
                              *(undefined8 *)(puVar29 + -8) = 0x101440;
                              (*_DAT_)(1,0xa06a48,0xb26718,0x816);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(lVar25 + 0x10);
                        *(undefined8 *)(puVar29 + -8) = 0x10144e;
                        func_0x(uVar17,4);
                        uVar11 = *(ushort *)(lVar25 + 0x24);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                        uVar30 = *(uint *)(lVar25 + 0x20);
                      }
                      uVar23 = (ulonglong)uVar11;
                      uVar11 = puVar33[uVar23];
                      *(uint *)(lVar25 + 0xc) = uVar11 & 0x7fff;
                      if ((uVar11 & 0x7fff) < uVar30) {
                        *(undefined8 *)(puVar29 + -8) = 0x10147e;
                        cVar9 = func_0x(0x1115cc0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x101487;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar29 + -8) = 0x1014a1;
                            cVar9 = func_0x(0x1115cc0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar29 + -8) = 0x1014bd;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar29 + 0x20) = 0;
                              *(undefined8 *)(puVar29 + -8) = 0x1014e3;
                              (*_DAT_)(1,0xa06a48,0xb26718,0x81d);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(lVar25 + 0x10);
                        *(undefined8 *)(puVar29 + -8) = 0x1014f1;
                        func_0x(uVar17,4);
                        uVar23 = (ulonglong)*(ushort *)(lVar25 + 0x24);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                      }
                      uVar38 = uVar23;
                      if ((short)puVar33[(ulonglong)((int)uVar23 - 1) + 1] < 0) {
                        do {
                          sVar10 = (short)uVar38;
                          uVar30 = *(uint *)(lVar25 + 0x1c);
                          if ((int)uVar23 == 1) {
                            uVar36 = *(uint *)(lVar25 + 0x20);
                            uVar11 = *(ushort *)(pbVar19 + uVar23 * 2 + (ulonglong)uVar30);
                            uVar31 = uVar36;
LAB_:
                            if ((uVar11 & 0x7fff) < uVar36) goto LAB_;
                          }
                          else {
                            uVar36 = *(ushort *)(pbVar19 + uVar23 * 2 + ((ulonglong)uVar30 - 2)) &
                                     0x7fff;
                            uVar31 = *(uint *)(lVar25 + 0x20);
                            uVar11 = *(ushort *)(pbVar19 + uVar23 * 2 + (ulonglong)uVar30);
                            if (uVar31 <= uVar36) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar29 + -8) = 0x101556;
                            func_0x(pbVar19,7);
                            uVar31 = *(uint *)(lVar25 + 0x20);
                            pbVar19 = *(byte **)(lVar25 + 0x10);
                            sVar10 = *(short *)(lVar25 + 0x24);
                          }
                          if ((uVar36 < uVar31) || (*(uint *)(lVar25 + 0xc) < uVar36))
                          goto LAB_;
                          if (*(ushort *)(pbVar19 + uVar36) == 5) {
                            *puVar34 = *puVar34 | 2;
                            *(short *)(lVar25 + 0x24) = sVar10 + -1;
                            *(short *)(lVar25 + 0x32) = (short)uVar36;
                            lVar16 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(lVar25 + 0x10);
                            uVar11 = *(ushort *)(lVar16 + 2);
                            uVar12 = *(ushort *)(lVar25 + 0x34) & 0xc7ff;
                            if ((uVar11 & 0x4000) != 0) {
                              uVar12 = uVar11 & 0x3800 | uVar12;
                            }
                            *(ushort *)(lVar25 + 0x34) = uVar12;
                            *(ushort *)(lVar25 + 0x34) =
                                 (uVar12 ^ *(ushort *)(lVar16 + 2)) & 0x7ff ^ uVar12;
                            goto LAB_;
                          }
                          if (*(ushort *)(pbVar19 + uVar36) < 0x400) goto LAB_;
                          *puVar34 = *puVar34 | 1;
                          uVar11 = sVar10 - 1;
                          *(ushort *)(lVar25 + 0x24) = uVar11;
                          if (uVar11 == 0) goto LAB_;
                          uVar38 = (ulonglong)uVar11;
                          uVar23 = (ulonglong)(uint)uVar11;
                        } while ((short)puVar33[(ulonglong)(uVar11 - 1) + 1] < 0);
                        uVar23 = (ulonglong)*(uint *)(lVar25 + 0xc);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                      }
                      else {
LAB_:
                        uVar23 = (ulonglong)*(uint *)(lVar25 + 0xc);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                      }
                    }
                    if ((*pbVar19 & 0x40) == 0) {
                      *(undefined4 *)(lVar25 + 0x2e) = 0;
                    }
                    else {
                      *(int *)(lVar25 + 0x2e) = (int)uVar23;
                      *(int *)(lVar25 + 0xc) = (int)uVar23 + 0xe;
                      *(undefined8 *)(puVar29 + -8) = 0x101648;
                      uVar17 = func_0x(puVar34);
                      *(undefined8 *)(puVar29 + -8) = 0x101657;
                      func_0x(uVar17,&lStack_218);
                      *(undefined8 *)(puVar29 + -8) = 0x101663;
                      iVar22 = func_0x(&lStack_218);
                      *(int *)(lVar25 + 0xc) = *(int *)(lVar25 + 0xc) + iVar22;
                      uVar23 = (ulonglong)*(uint *)(lVar25 + 0xc);
                      pbVar19 = *(byte **)(lVar25 + 0x10);
                    }
                    iVar22 = (int)uVar23;
                    if ((*(byte **)(lVar25 + 0x26) != (byte *)0x0) &&
                       (*(byte **)(lVar25 + 0x26) < pbVar19 + uVar23)) {
                      *(undefined8 *)(puVar29 + -8) = 0x10169b;
                      cVar9 = func_0x(0x1115cc0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x1016a4;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x1016be;
                          cVar9 = func_0x(0x1115cc0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x1016da;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x101700;
                            (*_DAT_)(1,0xa06a48,0xb26718,0x877);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(lVar25 + 0x10);
                      *(undefined8 *)(puVar29 + -8) = 0x10170e;
                      func_0x(uVar17,0x12);
                      iVar22 = *(int *)(lVar25 + 0xc);
                    }
                    if (0x3f3b < iVar22 - 1U) {
                      *(undefined8 *)(puVar29 + -8) = 0x101727;
                      cVar9 = func_0x(0x1115cc0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x101730;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x10174a;
                          cVar9 = func_0x(0x1115cc0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x101766;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x10178c;
                            (*_DAT_)(1,0xa06a48,0xb26718,0x87c);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(lVar25 + 0x10);
                      *(undefined8 *)(puVar29 + -8) = 0x10179a;
                      func_0x(uVar17,5);
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar29 + -8) = 0x1017a2;
                  func_0x(puVar34);
                  bVar39 = **(byte **)(lVar25 + 0x10) >> 6;
                  if ((bVar39 & 1) != 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x1017c3;
                    func_0x(puVar34,auStack_128);
                  }
                  if ((*(byte *)puVar34 & 1) != 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x1017d9;
                    puVar18 = (undefined4 *)func_0x(puVar34,0x400,&iStack_2a0);
                    uStack_1f8 = *puVar18;
                    uStack_1f4 = *(undefined2 *)(puVar18 + 1);
                    uStack_1f2 = *(undefined2 *)((longlong)puVar18 + 6);
                  }
                  pbVar19 = *(byte **)(lVar25 + 0x10);
                  if ((*pbVar19 & 0x20) == 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x101808;
                    func_0x(puVar34);
                    pbVar19 = *(byte **)(lVar25 + 0x10);
                  }
                  uVar30 = *(uint *)(lVar25 + 0x1c);
                  *(undefined8 *)(puVar29 + -8) = 0x10181b;
                  iVar22 = func_0x(puVar34);
                  lVar16 = *(longlong *)(lVar25 + 0x10);
                  uVar11 = *(ushort *)(lVar25 + 0x24);
                  uVar23 = (ulonglong)uVar11;
                  puVar33 = (ushort *)(lVar16 + (ulonglong)*(uint *)(lVar25 + 0x1c));
                  uVar36 = (uint)uVar11;
                  if (iVar22 == 0) {
                    uVar37 = *(uint *)(lVar25 + 0x1c) + (uVar11 + 1) * 2;
                    uVar31 = 0;
                    if (*puVar33 != 0) {
                      do {
                        uVar12 = puVar33[(ulonglong)uVar31 + 1];
                        puVar33[(ulonglong)(uVar31 & 0xffff) + 1] =
                             puVar33[(ulonglong)(uVar31 & 0xffff) + 1] & 0x8000;
                        puVar33[(ulonglong)(uVar31 & 0xffff) + 1] =
                             puVar33[(ulonglong)(uVar31 & 0xffff) + 1] |
                             (uVar12 & 0x7fff) + 2 & 0x7fff;
                        uVar31 = uVar31 + 1;
                      } while (uVar31 < *puVar33);
                      lVar16 = *(longlong *)(lVar25 + 0x10);
                    }
                    lVar16 = (ulonglong)uVar37 + lVar16;
                    iVar22 = *(int *)(lVar25 + 0xc);
                    *(undefined8 *)(puVar29 + -8) = 0x1018f4;
                    func_0x(lVar16 + 2,lVar16,iVar22 - uVar37);
                    *(int *)(lVar25 + 0xc) = *(int *)(lVar25 + 0xc) + 2;
                    *(int *)(lVar25 + 0x20) = *(int *)(lVar25 + 0x20) + 2;
                    uVar12 = (ushort)*(undefined4 *)(lVar25 + 0x20);
                    if (uVar36 != 0) {
                      uVar12 = puVar33[(ulonglong)(uVar11 - 1) + 1] & 0x7fff;
                    }
                    if (uVar36 < uVar11 + 1) {
                      do {
                        puVar33[(uVar23 & 0xffff) + 1] = uVar12 & 0x7fff;
                        uVar36 = (int)uVar23 + 1;
                        uVar23 = (ulonglong)uVar36;
                      } while (uVar36 < uVar11 + 1);
                    }
                    *puVar33 = *puVar33 + 1;
                    *(undefined8 *)(puVar29 + -8) = 0x101939;
                    func_0x(puVar34);
                    iVar32 = 0;
                    uVar11 = *(ushort *)
                              (pbVar19 +
                              (ulonglong)*(ushort *)(lVar25 + 0x24) * 2 + (ulonglong)uVar30 + 2);
                    *(undefined8 *)(puVar29 + -8) = 0x101955;
                    func_0x(auStack_180);
                    *(undefined4 *)(puVar29 + 0x28) = 0;
                    *(uint **)(puVar29 + 0x20) = puVar27;
                    piVar7 = piStack_200;
                    *(undefined8 *)(puVar29 + -8) = 0x101979;
                    func_0x(auStack_190,piVar7,1,0);
                    *(int **)(puVar29 + 0x28) = &iStack_208;
                    *(undefined **)(puVar29 + 0x20) = auStack_190;
                    *(undefined8 *)(puVar29 + -8) = 0x1019b4;
                    func_0x(lVar25 + 0x32,uVar11 & 0x7fff,0x1f9e);
                    iVar22 = iStack_208;
                  }
                  else {
                    if (uVar36 == 0) {
                      uVar36 = *(uint *)(psStack_2c0 + 0xc);
                      uVar31 = puVar33[uVar23 + 1] & 0x7fff;
LAB_:
                      if (uVar31 < uVar36) goto LAB_;
                    }
                    else {
                      uVar36 = puVar33[uVar23] & 0x7fff;
                      uVar31 = puVar33[uVar23 + 1] & 0x7fff;
                      if (*(uint *)(psStack_2c0 + 0xc) <= uVar36) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar29 + -8) = 0x10186e;
                      func_0x(lVar16,7);
                    }
                    piVar7 = piStack_200;
                    iVar32 = uVar31 - uVar36;
                    *(undefined8 *)(puVar29 + -8) = 0x10188c;
                    iVar22 = func_0x(lVar25 + 0x32,puVar27,piVar7);
                  }
                  iVar32 = (*(int *)(lVar25 + 0xc) - iVar32) + iVar22;
                  *(int *)(lVar25 + 0xc) = iVar32;
                  if ((*(byte *)puVar34 & 1) != 0) {
                    *(ushort *)
                     (pbVar19 + (ulonglong)*(ushort *)(lVar25 + 0x24) * 2 + (ulonglong)uVar30 + 4) =
                         (ushort)iVar32 | 0x8000;
                    iVar32 = (*(int *)(lVar25 + 0xc) - iStack_2a0) + -2;
                  }
                  *(ushort *)
                   (pbVar19 + (ulonglong)*(ushort *)(lVar25 + 0x24) * 2 + (ulonglong)uVar30 + 2) =
                       (ushort)iVar32 | 0x8000;
                  if (iVar22 == 0) {
                    uVar11 = *(ushort *)(lVar25 + 0x24);
                    *(undefined8 *)(puVar29 + -8) = 0x101a06;
                    func_0x(puVar34,uVar11 + 1,0);
                    if ((**(byte **)(lVar25 + 0x10) & 0x20) != 0) {
                      *(short *)(lVar25 + 0x24) = *(short *)(lVar25 + 0x24) + 1;
                      *puVar34 = *puVar34 & 0xfffd;
                      *(undefined8 *)(puVar29 + -8) = 0x101a23;
                      func_0x((undefined2 *)(lVar25 + 0x32));
                    }
                  }
                  else {
                    *puVar34 = *puVar34 | 2;
                    *(undefined8 *)(puVar29 + -8) = 0x101a32;
                    uVar13 = func_0x(puVar34,auStack_284);
                    *(undefined2 *)(lVar25 + 0x32) = uVar13;
                  }
                  iVar22 = iStack_2a0;
                  if ((*(byte *)puVar34 & 1) != 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x101a53;
                    func_0x(puVar34,0x400,iVar22);
                  }
                  if ((bVar39 & 1) != 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x101a6b;
                    func_0x(puVar34,auStack_128);
                  }
                }
                else {
                  if (*(int *)(lVar25 + 0xc) == 0) {
                    *puVar34 = 0;
                    uVar30 = *(uint *)(lVar25 + 0x18);
                    uVar23 = (ulonglong)uVar30;
                    *(uint *)(lVar25 + 0x1c) = uVar30;
                    pbVar19 = *(byte **)(lVar25 + 0x10);
                    bVar39 = *pbVar19;
                    if ((bVar39 & 0x10) != 0) {
                      uVar30 = uVar30 + (*(ushort *)(pbVar19 + uVar23) + 7 >> 3) + 2;
                      uVar23 = (ulonglong)uVar30;
                      *(uint *)(lVar25 + 0x1c) = uVar30;
                      bVar39 = *pbVar19;
                    }
                    if ((bVar39 & 0x20) == 0) {
                      *(int *)(lVar25 + 0xc) = (int)uVar23;
                      *(undefined2 *)(lVar25 + 0x24) = 0;
                      *(int *)(lVar25 + 0x20) = (int)uVar23;
                    }
                    else {
                      puVar33 = (ushort *)(pbVar19 + uVar23);
                      uVar11 = *puVar33;
                      *(ushort *)(lVar25 + 0x24) = uVar11;
                      if (uVar11 == 0) {
                        *(undefined8 *)(puVar29 + -8) = 0x100bb5;
                        cVar9 = func_0x(0x1115cc0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x100bbe;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar29 + -8) = 0x100bd8;
                            cVar9 = func_0x(0x1115cc0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar29 + -8) = 0x100bf4;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar29 + 0x20) = 0;
                              *(undefined8 *)(puVar29 + -8) = 0x100c1a;
                              (*_DAT_)(1,0xa06a48,0xb26718,0x80f);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(lVar25 + 0x10);
                        *(undefined8 *)(puVar29 + -8) = 0x100c28;
                        func_0x(uVar17,3);
                        uVar23 = (ulonglong)*(uint *)(lVar25 + 0x1c);
                        uVar11 = *(ushort *)(lVar25 + 0x24);
                      }
                      uVar30 = (int)uVar23 + (uVar11 + 1) * 2;
                      *(uint *)(lVar25 + 0x20) = uVar30;
                      if (0x1f9e < uVar30) {
                        *(undefined8 *)(puVar29 + -8) = 0x100c58;
                        cVar9 = func_0x(0x1115cc0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x100c61;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar29 + -8) = 0x100c7b;
                            cVar9 = func_0x(0x1115cc0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar29 + -8) = 0x100c97;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar29 + 0x20) = 0;
                              *(undefined8 *)(puVar29 + -8) = 0x100cbd;
                              (*_DAT_)(1,0xa06a48,0xb26718,0x816);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(lVar25 + 0x10);
                        *(undefined8 *)(puVar29 + -8) = 0x100ccb;
                        func_0x(uVar17,4);
                        uVar11 = *(ushort *)(lVar25 + 0x24);
                        uVar30 = *(uint *)(lVar25 + 0x20);
                      }
                      uVar23 = (ulonglong)uVar11;
                      uVar11 = puVar33[uVar23];
                      *(uint *)(lVar25 + 0xc) = uVar11 & 0x7fff;
                      if ((uVar11 & 0x7fff) < uVar30) {
                        *(undefined8 *)(puVar29 + -8) = 0x100cf7;
                        cVar9 = func_0x(0x1115cc0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x100d00;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar29 + -8) = 0x100d1a;
                            cVar9 = func_0x(0x1115cc0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar29 + -8) = 0x100d36;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar29 + 0x20) = 0;
                              *(undefined8 *)(puVar29 + -8) = 0x100d5c;
                              (*_DAT_)(1,0xa06a48,0xb26718);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(lVar25 + 0x10);
                        *(undefined8 *)(puVar29 + -8) = 0x100d6a;
                        func_0x(uVar17,4);
                        uVar23 = (ulonglong)*(ushort *)(lVar25 + 0x24);
                      }
                      if ((short)puVar33[(ulonglong)((int)uVar23 - 1) + 1] < 0) {
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                        do {
                          uVar30 = *(uint *)(lVar25 + 0x1c);
                          if ((int)uVar23 == 1) {
                            uVar36 = *(uint *)(lVar25 + 0x20);
                            uVar11 = *(ushort *)(pbVar19 + uVar23 * 2 + (ulonglong)uVar30);
                            uVar31 = uVar36;
LAB_:
                            if ((uVar11 & 0x7fff) < uVar36) goto LAB_;
                          }
                          else {
                            uVar36 = *(ushort *)(pbVar19 + uVar23 * 2 + ((ulonglong)uVar30 - 2)) &
                                     0x7fff;
                            uVar31 = *(uint *)(lVar25 + 0x20);
                            uVar11 = *(ushort *)(pbVar19 + uVar23 * 2 + (ulonglong)uVar30);
                            if (uVar31 <= uVar36) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar29 + -8) = 0x100dd4;
                            func_0x(pbVar19,7);
                            uVar31 = *(uint *)(lVar25 + 0x20);
                          }
                          if ((uVar36 < uVar31) || (*(uint *)(lVar25 + 0xc) < uVar36))
                          goto LAB_;
                          pbVar19 = *(byte **)(lVar25 + 0x10);
                          if (*(ushort *)(pbVar19 + uVar36) == 5) {
                            *puVar34 = *puVar34 | 2;
                            *(short *)(lVar25 + 0x24) = *(short *)(lVar25 + 0x24) + -1;
                            *(short *)(lVar25 + 0x32) = (short)uVar36;
                            uVar11 = *(ushort *)(lVar25 + 0x34) & 0xc7ff;
                            if ((*(ushort *)(pbVar19 + (ulonglong)(uVar36 & 0xffff) + 2) & 0x4000)
                                != 0) {
                              uVar11 = *(ushort *)(pbVar19 + (ulonglong)(uVar36 & 0xffff) + 2) &
                                       0x3800 | uVar11;
                            }
                            *(ushort *)(lVar25 + 0x34) = uVar11;
                            *(ushort *)(lVar25 + 0x34) =
                                 (uVar11 ^ *(ushort *)(pbVar19 + (ulonglong)(uVar36 & 0xffff) + 2))
                                 & 0x7ff ^ uVar11;
                            goto LAB_;
                          }
                          if (*(ushort *)(pbVar19 + uVar36) < 0x400) goto LAB_;
                          *puVar34 = *puVar34 | 1;
                          uVar11 = *(short *)(lVar25 + 0x24) - 1;
                          *(ushort *)(lVar25 + 0x24) = uVar11;
                          if (uVar11 == 0) goto LAB_;
                          uVar23 = (ulonglong)uVar11;
                        } while ((short)puVar33[(ulonglong)(uVar11 - 1) + 1] < 0);
                        uVar23 = (ulonglong)*(uint *)(lVar25 + 0xc);
                      }
                      else {
LAB_:
                        uVar23 = (ulonglong)*(uint *)(lVar25 + 0xc);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                      }
                    }
                    if ((*pbVar19 & 0x40) == 0) {
                      *(undefined4 *)(lVar25 + 0x2e) = 0;
                    }
                    else {
                      *(int *)(lVar25 + 0x2e) = (int)uVar23;
                      *(int *)(lVar25 + 0xc) = (int)uVar23 + 0xe;
                      *(undefined8 *)(puVar29 + -8) = 0x100ebf;
                      uVar17 = func_0x(puVar34);
                      *(undefined8 *)(puVar29 + -8) = 0x100ece;
                      func_0x(uVar17,auStack_1c8);
                      *(undefined8 *)(puVar29 + -8) = 0x100eda;
                      iVar22 = func_0x(auStack_1c8);
                      *(int *)(lVar25 + 0xc) = *(int *)(lVar25 + 0xc) + iVar22;
                      uVar23 = (ulonglong)*(uint *)(lVar25 + 0xc);
                    }
                    iVar22 = (int)uVar23;
                    if ((*(ulonglong *)(lVar25 + 0x26) != 0) &&
                       (*(ulonglong *)(lVar25 + 0x26) < uVar23 + *(longlong *)(lVar25 + 0x10))) {
                      *(undefined8 *)(puVar29 + -8) = 0x100f0f;
                      cVar9 = func_0x(0x1115cc0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x100f18;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x100f32;
                          cVar9 = func_0x(0x1115cc0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x100f4e;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x100f74;
                            (*_DAT_)(1,0xa06a48,0xb26718);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(lVar25 + 0x10);
                      *(undefined8 *)(puVar29 + -8) = 0x100f82;
                      func_0x(uVar17,0x12);
                      iVar22 = *(int *)(lVar25 + 0xc);
                    }
                    if (0x3f3b < iVar22 - 1U) {
                      *(undefined8 *)(puVar29 + -8) = 0x100f9b;
                      cVar9 = func_0x(0x1115cc0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x100fa4;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x100fbe;
                          cVar9 = func_0x(0x1115cc0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x100fda;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x101000;
                            (*_DAT_)(1,0xa06a48,0xb26718);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(lVar25 + 0x10);
                      *(undefined8 *)(puVar29 + -8) = 0x10100e;
                      func_0x(uVar17,5);
                    }
                  }
LAB_:
                  uVar30 = -*puVar27;
                  *(undefined8 *)(puVar29 + -8) = 0x101021;
                  func_0x(auStack_128);
                  pbVar19 = *(byte **)(lVar25 + 0x10);
                  bVar39 = *pbVar19;
                  bVar4 = bVar39 >> 6;
                  if ((bVar4 & 1) != 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x101045;
                    func_0x(puVar34,auStack_128);
                    pbVar19 = *(byte **)(lVar25 + 0x10);
                    bVar39 = *pbVar19;
                  }
                  if ((bVar39 & 0x20) == 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x101059;
                    func_0x(puVar34);
                    pbVar19 = *(byte **)(lVar25 + 0x10);
                  }
                  uVar11 = *(ushort *)(lVar25 + 0x24);
                  uVar36 = (uint)uVar11;
                  if (uVar11 < uVar30) {
                    iVar22 = uVar30 - uVar11;
                    puVar33 = (ushort *)(pbVar19 + *(uint *)(lVar25 + 0x1c));
                    uVar31 = *(uint *)(lVar25 + 0x1c) + 2 + uVar36 * 2;
                    uVar37 = iVar22 * 2;
                    uVar24 = 0;
                    if (*puVar33 != 0) {
                      do {
                        uVar11 = puVar33[(ulonglong)uVar24 + 1];
                        puVar33[(ulonglong)(uVar24 & 0xffff) + 1] =
                             puVar33[(ulonglong)(uVar24 & 0xffff) + 1] & 0x8000;
                        puVar33[(ulonglong)(uVar24 & 0xffff) + 1] =
                             puVar33[(ulonglong)(uVar24 & 0xffff) + 1] |
                             (uVar11 & 0x7fff) + (short)uVar37 & 0x7fff;
                        uVar24 = uVar24 + 1;
                      } while (uVar24 < *puVar33);
                      pbVar19 = *(byte **)(lVar25 + 0x10);
                    }
                    iVar32 = *(int *)(lVar25 + 0xc);
                    *(undefined8 *)(puVar29 + -8) = 0x1010ec;
                    func_0x
                              (pbVar19 + (ulonglong)uVar37 + (ulonglong)uVar31,pbVar19 + uVar31,
                               iVar32 - uVar31);
                    *(int *)(lVar25 + 0xc) = *(int *)(lVar25 + 0xc) + uVar37;
                    *(int *)(lVar25 + 0x20) = *(int *)(lVar25 + 0x20) + uVar37;
                    uVar11 = (ushort)*(undefined4 *)(lVar25 + 0x20);
                    if (uVar36 != 0) {
                      uVar11 = puVar33[(ulonglong)(uVar36 - 1) + 1] & 0x7fff;
                    }
                    do {
                      puVar33[(ulonglong)(uVar36 & 0xffff) + 1] = uVar11 & 0x7fff;
                      uVar36 = uVar36 + 1;
                    } while (uVar36 < uVar30);
                    *puVar33 = *puVar33 + (short)iVar22;
                    *(undefined8 *)(puVar29 + -8) = 0x10112b;
                    iVar22 = func_0x(puVar34);
                    if (iVar22 != 0) {
                      *(undefined8 *)(puVar29 + -8) = 0x10113e;
                      uVar13 = func_0x(puVar34,auStack_1d8);
                      *(undefined2 *)(lVar25 + 0x32) = uVar13;
                    }
                    *(short *)(lVar25 + 0x24) = (short)uVar30;
                    uVar36 = uVar30 & 0xffff;
                    pbVar19 = *(byte **)(lVar25 + 0x10);
                  }
                  uVar31 = *(uint *)(lVar25 + 0x1c);
                  if (uVar36 < uVar30) {
                    uVar36 = *(ushort *)(pbVar19 + (ulonglong)uVar36 * 2 + (ulonglong)uVar31) &
                             0x7fff;
                    iVar22 = 0;
LAB_:
                    puVar33 = (ushort *)(pbVar19 + *(uint *)(lVar25 + 0x1c));
                    lVar16 = (ulonglong)uVar36 + *(longlong *)(lVar25 + 0x10);
                    uVar14 = *(undefined4 *)(lVar25 + 0xc);
                    *(undefined8 *)(puVar29 + -8) = 0x1011de;
                    uVar14 = func_0x(uVar14,uVar36 + iVar22);
                    *(undefined8 *)(puVar29 + -8) = 0x1011f0;
                    func_0x(lVar16 + 1,iVar22 + lVar16,uVar14);
                    uVar30 = uVar30 - 1;
                    if ((int)uVar30 < (int)(uint)*puVar33) {
                      do {
                        uVar11 = puVar33[(longlong)(int)uVar30 + 1];
                        puVar33[((ulonglong)uVar30 & 0xffff) + 1] =
                             puVar33[((ulonglong)uVar30 & 0xffff) + 1] & 0x8000;
                        puVar33[((ulonglong)uVar30 & 0xffff) + 1] =
                             puVar33[((ulonglong)uVar30 & 0xffff) + 1] |
                             ((uVar11 & 0x7fff) - (short)iVar22) + 1 & 0x7fff;
                        uVar30 = uVar30 + 1;
                      } while ((int)uVar30 < (int)(uint)*puVar33);
                    }
                    *(int *)(lVar25 + 0xc) = *(int *)(lVar25 + 0xc) + (1 - iVar22);
                    *(undefined8 *)(puVar29 + -8) = 0x101252;
                    iVar22 = func_0x(puVar34);
                    if (iVar22 != 0) {
                      *(undefined8 *)(puVar29 + -8) = 0x101262;
                      uVar13 = func_0x(puVar34,&piStack_290);
                      *(undefined2 *)(lVar25 + 0x32) = uVar13;
                    }
                  }
                  else {
                    if (uVar30 == 1) {
                      uVar36 = *(uint *)(psStack_2c0 + 0xc);
                      uVar31 = *(ushort *)(pbVar19 + (ulonglong)uVar31 + 2) & 0x7fff;
LAB_:
                      if (uVar31 < uVar36) goto LAB_;
                    }
                    else {
                      uVar36 = *(ushort *)
                                (pbVar19 + (longlong)(int)uVar30 * 2 + ((ulonglong)uVar31 - 2)) &
                               0x7fff;
                      uVar31 = *(ushort *)(pbVar19 + (longlong)(int)uVar30 * 2 + (ulonglong)uVar31)
                               & 0x7fff;
                      if (*(uint *)(psStack_2c0 + 0xc) <= uVar36) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar29 + -8) = 0x1011a6;
                      func_0x(pbVar19,7);
                      pbVar19 = *(byte **)(lVar25 + 0x10);
                    }
                    iVar22 = uVar31 - uVar36;
                    if (iVar22 != 1) goto LAB_;
                  }
                  *(char *)(*(longlong *)(lVar25 + 0x10) + (ulonglong)uVar36) = *(char *)piStack_200
                  ;
                  if ((bVar4 & 1) != 0) {
                    *(undefined8 *)(puVar29 + -8) = 0x10128e;
                    func_0x(puVar34,auStack_128);
                  }
                }
              }
              else {
                uVar36 = (uint)*(ushort *)((longlong)puVar27 + 6);
                if ((*(ushort *)((longlong)puVar27 + 6) & 8) == 0) {
                  if (*(int *)(lVar25 + 0xc) == 0) {
                    *puVar34 = 0;
                    uVar30 = *(uint *)(lVar25 + 0x18);
                    uVar23 = (ulonglong)uVar30;
                    *(uint *)(lVar25 + 0x1c) = uVar30;
                    pbVar19 = *(byte **)(lVar25 + 0x10);
                    bVar39 = *pbVar19;
                    if ((bVar39 & 0x10) != 0) {
                      uVar30 = uVar30 + 2 + (*(ushort *)(pbVar19 + uVar23) + 7 >> 3);
                      uVar23 = (ulonglong)uVar30;
                      *(uint *)(lVar25 + 0x1c) = uVar30;
                      bVar39 = *pbVar19;
                    }
                    if ((bVar39 & 0x20) == 0) {
                      *(int *)(lVar25 + 0xc) = (int)uVar23;
                      *(undefined2 *)(lVar25 + 0x24) = 0;
                      *(int *)(lVar25 + 0x20) = (int)uVar23;
                    }
                    else {
                      puVar33 = (ushort *)(pbVar19 + uVar23);
                      uVar11 = *puVar33;
                      *(ushort *)(lVar25 + 0x24) = uVar11;
                      if (uVar11 == 0) {
                        *(undefined8 *)(puVar29 + -8) = 0x100678;
                        cVar9 = func_0x(0x1115cc0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x100681;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar29 + -8) = 0x10069b;
                            cVar9 = func_0x(0x1115cc0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar29 + -8) = 0x1006b7;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar29 + 0x20) = 0;
                              *(undefined8 *)(puVar29 + -8) = 0x1006dd;
                              (*_DAT_)(1,0xa06a48,0xb26718,0x80f);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(lVar25 + 0x10);
                        *(undefined8 *)(puVar29 + -8) = 0x1006eb;
                        func_0x(uVar17,3);
                        uVar23 = (ulonglong)*(uint *)(lVar25 + 0x1c);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                        uVar11 = *(ushort *)(lVar25 + 0x24);
                      }
                      uVar30 = (int)uVar23 + (uVar11 + 1) * 2;
                      *(uint *)(lVar25 + 0x20) = uVar30;
                      if (0x1f9e < uVar30) {
                        *(undefined8 *)(puVar29 + -8) = 0x10071f;
                        cVar9 = func_0x(0x1115cc0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x100728;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar29 + -8) = 0x100742;
                            cVar9 = func_0x(0x1115cc0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar29 + -8) = 0x10075e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar29 + 0x20) = 0;
                              *(undefined8 *)(puVar29 + -8) = 0x100784;
                              (*_DAT_)(1,0xa06a48,0xb26718,0x816);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(lVar25 + 0x10);
                        *(undefined8 *)(puVar29 + -8) = 0x100792;
                        func_0x(uVar17,4);
                        uVar11 = *(ushort *)(lVar25 + 0x24);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                        uVar30 = *(uint *)(lVar25 + 0x20);
                      }
                      uVar23 = (ulonglong)uVar11;
                      uVar11 = puVar33[uVar23];
                      *(uint *)(lVar25 + 0xc) = uVar11 & 0x7fff;
                      if ((uVar11 & 0x7fff) < uVar30) {
                        *(undefined8 *)(puVar29 + -8) = 0x1007c2;
                        cVar9 = func_0x(0x1115cc0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar29 + -8) = 0x1007cb;
                          lVar16 = func_0x();
                          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar29 + -8) = 0x1007e5;
                            cVar9 = func_0x(0x1115cc0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar29 + -8) = 0x100801;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar29 + 0x20) = 0;
                              *(undefined8 *)(puVar29 + -8) = 0x100827;
                              (*_DAT_)(1,0xa06a48,0xb26718,0x81d);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(lVar25 + 0x10);
                        *(undefined8 *)(puVar29 + -8) = 0x100835;
                        func_0x(uVar17,4);
                        uVar23 = (ulonglong)*(ushort *)(lVar25 + 0x24);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                      }
                      if ((short)puVar33[(ulonglong)((int)uVar23 - 1) + 1] < 0) {
                        do {
                          uVar30 = *(uint *)(lVar25 + 0x1c);
                          if ((int)uVar23 == 1) {
                            uVar36 = *(uint *)(lVar25 + 0x20);
                            uVar11 = *(ushort *)(pbVar19 + uVar23 * 2 + (ulonglong)uVar30);
                            uVar31 = uVar36;
LAB_:
                            if ((uVar11 & 0x7fff) < uVar36) goto LAB_;
                          }
                          else {
                            uVar36 = *(ushort *)(pbVar19 + uVar23 * 2 + ((ulonglong)uVar30 - 2)) &
                                     0x7fff;
                            uVar31 = *(uint *)(lVar25 + 0x20);
                            uVar11 = *(ushort *)(pbVar19 + uVar23 * 2 + (ulonglong)uVar30);
                            if (uVar31 <= uVar36) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar29 + -8) = 0x100894;
                            func_0x(pbVar19,7);
                            uVar31 = *(uint *)(lVar25 + 0x20);
                            pbVar19 = *(byte **)(lVar25 + 0x10);
                          }
                          if ((uVar36 < uVar31) || (*(uint *)(lVar25 + 0xc) < uVar36))
                          goto LAB_;
                          if (*(ushort *)(pbVar19 + uVar36) == 5) {
                            *puVar34 = *puVar34 | 2;
                            *(short *)(lVar25 + 0x24) = *(short *)(lVar25 + 0x24) + -1;
                            *(short *)(lVar25 + 0x32) = (short)uVar36;
                            lVar16 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(lVar25 + 0x10);
                            uVar11 = *(ushort *)(lVar16 + 2);
                            uVar12 = *(ushort *)(lVar25 + 0x34) & 0xc7ff;
                            if ((uVar11 & 0x4000) != 0) {
                              uVar12 = uVar11 & 0x3800 | uVar12;
                            }
                            *(ushort *)(lVar25 + 0x34) = uVar12;
                            *(ushort *)(lVar25 + 0x34) =
                                 (uVar12 ^ *(ushort *)(lVar16 + 2)) & 0x7ff ^ uVar12;
                            goto LAB_;
                          }
                          if (*(ushort *)(pbVar19 + uVar36) < 0x400) goto LAB_;
                          *puVar34 = *puVar34 | 1;
                          uVar11 = *(short *)(lVar25 + 0x24) - 1;
                          *(ushort *)(lVar25 + 0x24) = uVar11;
                          if (uVar11 == 0) goto LAB_;
                          uVar23 = (ulonglong)uVar11;
                        } while ((short)puVar33[(ulonglong)(uVar11 - 1) + 1] < 0);
                        uVar23 = (ulonglong)*(uint *)(lVar25 + 0xc);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                      }
                      else {
LAB_:
                        uVar23 = (ulonglong)*(uint *)(lVar25 + 0xc);
                        pbVar19 = *(byte **)(lVar25 + 0x10);
                      }
                    }
                    if ((*pbVar19 & 0x40) == 0) {
                      *(undefined4 *)(lVar25 + 0x2e) = 0;
                    }
                    else {
                      *(int *)(lVar25 + 0x2e) = (int)uVar23;
                      *(int *)(lVar25 + 0xc) = (int)uVar23 + 0xe;
                      *(undefined8 *)(puVar29 + -8) = 0x100981;
                      uVar17 = func_0x(puVar34);
                      *(undefined8 *)(puVar29 + -8) = 0x100990;
                      func_0x(uVar17,auStack_1d0);
                      *(undefined8 *)(puVar29 + -8) = 0x10099c;
                      iVar22 = func_0x(auStack_1d0);
                      *(int *)(lVar25 + 0xc) = *(int *)(lVar25 + 0xc) + iVar22;
                      uVar23 = (ulonglong)*(uint *)(lVar25 + 0xc);
                      pbVar19 = *(byte **)(lVar25 + 0x10);
                    }
                    iVar22 = (int)uVar23;
                    if ((*(byte **)(lVar25 + 0x26) != (byte *)0x0) &&
                       (*(byte **)(lVar25 + 0x26) < pbVar19 + uVar23)) {
                      *(undefined8 *)(puVar29 + -8) = 0x1009d4;
                      cVar9 = func_0x(0x1115cc0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x1009dd;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x1009f7;
                          cVar9 = func_0x(0x1115cc0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x100a13;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x100a39;
                            (*_DAT_)(1,0xa06a48,0xb26718);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(lVar25 + 0x10);
                      *(undefined8 *)(puVar29 + -8) = 0x100a47;
                      func_0x(uVar17,0x12);
                      iVar22 = *(int *)(lVar25 + 0xc);
                    }
                    if (0x3f3b < iVar22 - 1U) {
                      *(undefined8 *)(puVar29 + -8) = 0x100a60;
                      cVar9 = func_0x(0x1115cc0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x100a69;
                        lVar16 = func_0x();
                        if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar29 + -8) = 0x100a83;
                          cVar9 = func_0x(0x1115cc0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar29 + -8) = 0x100a9f;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar29 + 0x20) = 0;
                            *(undefined8 *)(puVar29 + -8) = 0x100ac5;
                            (*_DAT_)(1,0xa06a48,0xb26718);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(lVar25 + 0x10);
                      *(undefined8 *)(puVar29 + -8) = 0x100ad3;
                      func_0x(uVar17,5);
                    }
                  }
LAB_:
                  uVar36 = *puVar27;
                  uVar30 = uVar36 + 1;
                  uVar31 = *(uint *)(lVar25 + 0x18);
                  if (uVar31 < uVar30) {
                    *(undefined8 *)(puVar29 + -8) = 0x100af4;
                    func_0x(puVar34,0,uVar30 - uVar31);
                    if ((1 << (**(byte **)(lVar25 + 0x10) & 0xe) & 0x1105U) != 0) {
                      *(short *)(*(byte **)(lVar25 + 0x10) + 2) = (short)uVar30;
                    }
                    *(uint *)(lVar25 + 0x18) = uVar30;
                    uVar36 = *puVar27;
                  }
                  if (piVar7 != (int *)0x0) {
                    *(char *)((longlong)(int)uVar36 + *(longlong *)(lVar25 + 0x10)) =
                         *(char *)piVar7;
                  }
                }
                else {
                  cVar9 = *(char *)piStack_280;
                  uVar30 = uVar30 + 1;
                  uVar31 = *(uint *)(lVar25 + 0x18);
                  if (uVar31 < uVar30) {
                    *(undefined8 *)(puVar29 + -8) = 0x1005b2;
                    func_0x(puVar34,0,uVar30 - uVar31);
                    if ((1 << (**(byte **)(lVar25 + 0x10) & 0xe) & 0x1105U) != 0) {
                      *(short *)(*(byte **)(lVar25 + 0x10) + 2) = (short)uVar30;
                    }
                    *(uint *)(lVar25 + 0x18) = uVar30;
                    uVar36 = (uint)*(byte *)((longlong)puVar27 + 6);
                  }
                  lVar15 = *(longlong *)(lVar25 + 0x10);
                  if (cVar9 == '\0') {
                    *(byte *)(lVar15 + lVar16) =
                         *(byte *)(lVar15 + lVar16) & ~(byte)(1 << (uVar36 & 7));
                  }
                  else {
                    *(byte *)(lVar15 + lVar16) =
                         *(byte *)(lVar15 + lVar16) | (byte)(1 << (uVar36 & 7));
                  }
                }
              }
            }
            else {
              *(undefined8 *)(puVar29 + 0x20) = 0x782f28;
              *(undefined8 *)(puVar29 + -8) = 0x100561;
              (*_DAT_)(1,0xb87d80,0xbb46c0);
            }
          }
          puStack_2a8 = puStack_2a8 + 0x14;
          uStack_288 = uStack_288 + 1;
          plVar26 = plStack_2b0;
          uVar36 = uStack_298;
        } while (uStack_288 < uStack_204);
      }
      uVar30 = uStack_29c;
      puVar34 = (ushort *)0x0;
      do {
        uVar31 = uVar36;
        if (uVar31 == 0) goto LAB_;
        uVar23 = (ulonglong)uVar31;
        uVar36 = uVar31 - 1;
      } while (*(int *)(plStack_2b0 + (ulonglong)(uVar31 - 1) * 4 + 1) == 0);
      *(ushort *)(lVar25 + 0x24) = (ushort)uVar31;
      iVar22 = *(int *)(lVar25 + 0x1c) + 2 + uVar31 * 2;
      *(int *)(lVar25 + 0x20) = iVar22;
      *(int *)(lVar25 + 0xc) = iVar22;
      **(byte **)(lVar25 + 0x10) = **(byte **)(lVar25 + 0x10) | 0x20;
      if (*(uint *)(lVar25 + 0xc) <= uStack_2b8) {
        puVar34 = (ushort *)((ulonglong)*(uint *)(lVar25 + 0x1c) + *(longlong *)(lVar25 + 0x10));
        *puVar34 = (ushort)uVar31;
      }
      if (uVar31 != 0) {
        puVar27 = (uint *)((longlong)plStack_2b0 + 0xc);
        uVar36 = uStack_2b8;
        do {
          puVar34 = puVar34 + 1;
          uVar37 = *(uint *)(lVar25 + 0xc);
          lVar16 = *(longlong *)(lVar25 + 0x10);
          uVar24 = puVar27[-1];
          uVar31 = uVar37 + uVar24;
          *(uint *)(lVar25 + 0xc) = uVar31;
          if ((uVar31 <= uVar36) && (uVar31 <= uVar30)) {
            *puVar34 = (ushort)((*puVar27 & 1) << 0xf) | (ushort)uVar31 & 0x7fff;
            uVar17 = *(undefined8 *)(puVar27 + -3);
            *(undefined8 *)(puVar29 + -8) = 0x101d0f;
            func_0x((ulonglong)uVar37 + lVar16,uVar24,uVar17,uVar24);
            uVar36 = uStack_2b8;
          }
          puVar27 = puVar27 + 8;
          uVar23 = uVar23 - 1;
        } while (uVar23 != 0);
      }
    }
  }
  else {
    *(undefined8 *)(puVar29 + 0x40) = 0;
    *(undefined **)(puVar29 + 0x38) = auStack_284;
    *(uint *)(puVar29 + 0x30) = uVar36;
    *(uint *)(puVar29 + 0x28) = uVar30;
    *(undefined8 *)(puVar29 + 0x20) = uVar17;
    *(undefined8 *)(puVar29 + -8) = 0x1022f1;
    func_0x(auStack_168,&plStack_278,2,psVar35);
  }
LAB_:
  puVar8 = puStack_1e0;
  if (((*(uint *)((longlong)puStack_1e0 + 0x14) & 0xe0000000) != 0x80000000) ||
     (0xff < *(ushort *)(puStack_1e0 + 3))) {
    *(undefined8 *)(puVar29 + -8) = 0x101d56;
    func_0x(puVar8,1);
  }
  *(undefined8 *)(puVar29 + -8) = 0x101d65;
  func_0x(&lStack_1f0,puVar8);
  lVar25 = lStack_1f0;
  uVar17 = *(undefined8 *)(lStack_1f0 + 8);
  *(undefined8 *)(puVar29 + -8) = 0x101d75;
  func_0x(uVar17);
  uVar17 = *(undefined8 *)(lVar25 + 8);
  *(undefined8 *)(puVar29 + -8) = 0x101d83;
  func_0x(uVar17,1);
  if (iStack_1e8 != 0) {
    lVar25 = *(longlong *)(lVar25 + 8);
    *(undefined8 *)(puVar29 + -8) = 0x101da1;
    func_0x(lVar25 + 0x630,2);
    iStack_1e8 = 0;
  }
  lStack_1f0 = 0;
  lVar25 = lStack_1b0;
  while (lVar25 != 0) {
    lVar16 = *(longlong *)(lVar25 + 8000);
    *(undefined8 *)(puVar29 + -8) = 0x101dd2;
    (*_DAT_)(lVar25,0x1f48);
    lVar25 = lVar16;
  }
  uVar23 = uStack_48 ^ (ulonglong)&lStack_2c8;
  *(undefined8 *)(puVar29 + -8) = 0x101dec;
  func_0x(uVar23);
  return;
}

