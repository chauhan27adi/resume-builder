
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint *param_2,undefined2 param_3,longlong *param_4,int param_5)

{
  byte *pbVar1;
  byte *pbVar2;
  undefined uVar3;
  byte bVar4;
  undefined8 uVar5;
  int **ppiVar6;
  longlong *plVar7;
  code *pcVar8;
  uint **ppuVar9;
  char cVar10;
  undefined2 uVar11;
  short sVar12;
  int iVar13;
  uint uVar14;
  int iVar15;
  int iVar16;
  longlong lVar17;
  longlong lVar18;
  uint *puVar19;
  ulonglong uVar20;
  byte **ppbVar21;
  byte **ppbVar22;
  longlong lVar23;
  short *psVar24;
  ulonglong *puVar25;
  undefined4 *puVar26;
  short sVar27;
  undefined4 uVar28;
  longlong *plVar29;
  int *piVar30;
  short sVar31;
  ushort uVar32;
  ushort uVar33;
  int iVar34;
  byte **ppbVar35;
  uint uVar36;
  int *piVar37;
  uint uVar38;
  undefined2 *puVar39;
  uint uVar40;
  longlong lVar41;
  ulonglong uVar42;
  ushort *puVar43;
  undefined *puVar44;
  longlong unaff_GS_OFFSET;
  bool bVar45;
  uint auStackX_8 [2];
  char acStackX_10 [8];
  undefined4 uStackX_18;
  undefined2 auStackX_1c [2];
  uint *puStackX_20;
  ushort uStack_2548;
  int iStack_2544;
  short sStack_2540;
  uint uStack_253c;
  uint uStack_2538;
  longlong lStack_2530;
  undefined8 uStack_2528;
  ushort uStack_2520;
  undefined8 uStack_2518;
  undefined8 uStack_2510;
  undefined2 uStack_2508;
  undefined8 uStack_2500;
  ushort uStack_24f8;
  undefined auStack_24f0 [4];
  undefined4 uStack_24ec;
  undefined4 uStack_24e8;
  undefined2 uStack_24e4;
  undefined4 uStack_24e0;
  undefined2 uStack_24dc;
  undefined4 uStack_24d8;
  undefined2 uStack_24d4;
  undefined4 uStack_24d0;
  undefined2 uStack_24cc;
  undefined4 uStack_24c8;
  undefined2 uStack_24c4;
  undefined4 uStack_24c0;
  undefined2 uStack_24bc;
  undefined4 uStack_24b8;
  undefined2 uStack_24b4;
  undefined4 uStack_24b0;
  undefined2 uStack_24ac;
  undefined4 uStack_24a8;
  undefined2 uStack_24a4;
  undefined8 uStack_24a0;
  undefined4 uStack_2498;
  undefined2 uStack_2494;
  undefined2 uStack_2492;
  undefined4 uStack_2490;
  undefined2 uStack_248c;
  undefined2 uStack_248a;
  int iStack_2488;
  undefined2 uStack_2484;
  undefined2 uStack_2482;
  int iStack_2480;
  undefined2 uStack_247c;
  undefined2 uStack_247a;
  int iStack_2478;
  short sStack_2474;
  int iStack_2470;
  undefined2 uStack_246c;
  short sStack_246a;
  undefined8 uStack_2468;
  undefined2 uStack_2460;
  undefined *puStack_2458;
  longlong *plStack_2450;
  uint uStack_2448;
  undefined8 uStack_2444;
  undefined8 uStack_2430;
  undefined2 uStack_2428;
  undefined8 uStack_2420;
  ushort uStack_2418;
  undefined8 uStack_2410;
  undefined uStack_2408;
  undefined4 uStack_2404;
  longlong lStack_23f8;
  undefined auStack_23f0 [4];
  undefined auStack_23ec [4];
  undefined auStack_23e8 [4];
  undefined auStack_23e4 [4];
  undefined auStack_23e0 [8];
  undefined8 uStack_23d8;
  undefined auStack_23c8 [8];
  undefined4 uStack_23c0;
  undefined4 uStack_23b8;
  uint **ppuStack_23b0;
  undefined *puStack_23a8;
  undefined8 uStack_23a0;
  uint *puStack_2398;
  undefined4 uStack_2390;
  undefined4 uStack_238c;
  longlong lStack_2388;
  undefined4 uStack_2380;
  undefined4 uStack_237c;
  longlong lStack_2378;
  undefined4 uStack_2370;
  undefined4 uStack_236c;
  short *psStack_2368;
  int iStack_2360;
  undefined4 uStack_235c;
  short *psStack_2358;
  int iStack_2350;
  undefined4 uStack_234c;
  undefined8 uStack_2348;
  undefined4 uStack_2340;
  undefined4 uStack_233c;
  undefined auStack_2338 [448];
  undefined8 uStack_2178;
  undefined8 uStack_2170;
  uint uStack_2168;
  undefined2 uStack_2164;
  int iStack_2162;
  undefined uStack_215e;
  undefined uStack_215d;
  short sStack_2128;
  ushort uStack_2126;
  uint uStack_2124;
  byte *pbStack_2120;
  undefined8 uStack_2118;
  undefined4 uStack_2110;
  ushort uStack_210c;
  undefined2 uStack_210a;
  undefined6 uStack_2108;
  undefined2 uStack_2102;
  undefined2 uStack_2100;
  undefined2 uStack_20fe;
  ushort uStack_20fc;
  undefined2 uStack_20fa;
  undefined4 uStack_20f8;
  int iStack_20f4;
  undefined auStack_20f0 [16];
  undefined auStack_20e0 [8];
  undefined8 uStack_20d8;
  undefined8 uStack_20d0;
  undefined6 uStack_20c8;
  undefined2 uStack_20c2;
  undefined6 uStack_20c0;
  undefined2 uStack_20ba;
  undefined8 uStack_20b8;
  undefined auStack_20b0 [16];
  undefined auStack_20a0 [16];
  undefined auStack_2090 [16];
  undefined8 uStack_2080;
  undefined8 uStack_2078;
  uint uStack_2070;
  undefined2 uStack_206c;
  undefined2 uStack_206a;
  undefined8 uStack_2068;
  undefined8 uStack_2060;
  short asStack_2058 [24];
  short asStack_2028 [24];
  undefined auStack_1ff8 [4];
  longlong lStack_1ff4;
  uint uStack_1fec;
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar17 = func_0x();
  lVar17 = -lVar17;
  uStack_23d8 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar17);
  *(undefined2 *)(&stack0xfffffffffffffff0 + lVar17) = param_3;
  *(uint **)((longlong)auStackX_1c + lVar17 + 4) = param_2;
  *(longlong *)((longlong)&param_5 + lVar17) = param_1;
  ppbVar35 = (byte **)0x0;
  iVar16 = 0;
  iVar34 = 0;
  puStack_2458 = (undefined *)0x0;
  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
  plStack_2450 = param_4;
  *(undefined *)((longlong)auStackX_1c + lVar17 + -0x1c) = 0;
  uVar40 = *(uint *)((longlong)auStackX_1c + lVar17 + -0x18);
  *(uint *)((longlong)auStackX_1c + lVar17 + -0x18) = uVar40 & 0xffff0000;
  *(uint *)((longlong)auStackX_1c + lVar17 + -0x18) = uVar40 & 0xff000000;
  *(undefined4 *)((longlong)auStackX_1c + lVar17 + -0x18) = 0;
  uStack_2410 = 0;
  uStack_2408 = 0;
  uStack_2404 = 0;
  sStack_2128 = -1;
  pbStack_2120 = (byte *)0x0;
  uStack_2124 = 0;
  uStack_210a = 0;
  uStack_2108 = 0;
  uStack_2100 = 0;
  uStack_20fe = 0;
  uStack_20fc = 0;
  uStack_20fa = 0;
  uStack_2118 = (byte **)0x0;
  iStack_20f4 = -1;
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1000ed;
  func_0x(0x67);
  lVar23 = *(longlong *)(param_1 + 0xa0);
  sVar31 = *(short *)(param_2 + 1);
  lStack_23f8 = lVar23;
  uStack_2110 = CONCAT22(uStack_2110._2_2_,(undefined2)uStack_2110);
  if (sVar31 == 0) goto code_r0x001029b1;
  uVar5 = *(undefined8 *)(*(longlong *)(param_1 + 0x20) + 0x6a0);
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10011f;
  lVar18 = func_0x(uVar5,sVar31,1);
  uStack_2110 = CONCAT22(uStack_2110._2_2_,(undefined2)uStack_2110);
  if ((lVar18 == 0) ||
     (uVar40 = *param_2, uStack_2110 = CONCAT22(uStack_2110._2_2_,(undefined2)uStack_2110),
     *(uint *)(lVar18 + 0x80) <= uVar40)) goto code_r0x001029b1;
  lVar18 = *(longlong *)(lVar23 + 8);
  if ((lVar18 == 0) || (lVar41 = *(longlong *)(lVar18 + 8), *(char *)(lVar41 + 0x3f) != '\0')) {
    if (*(int *)(lVar23 + 0x40) == 2) {
      sStack_2540 = *(short *)(*(longlong *)(lVar23 + 0x30) + 0x10);
      iStack_2544 = *(int *)(*(longlong *)(lVar23 + 0x30) + 0xc);
    }
    else {
      sStack_2540 = *(short *)(*(longlong *)(lVar23 + 0x28) + 0x20);
      iStack_2544 = *(int *)(*(longlong *)(lVar23 + 0x28) + 0x1c);
    }
    if (lVar18 != 0) goto LAB_;
LAB_:
    if (*(int *)(lVar23 + 0x40) == 2) {
      uStack_2498 = **(undefined4 **)(lVar23 + 0x30);
      uStack_2494 = *(undefined2 *)(*(undefined4 **)(lVar23 + 0x30) + 1);
      uStack_2492 = 0;
      puVar26 = &uStack_2498;
    }
    else {
      uStack_2490 = **(undefined4 **)(lVar23 + 0x28);
      uStack_248c = *(undefined2 *)(*(undefined4 **)(lVar23 + 0x28) + 1);
      uStack_248a = 0;
      puVar26 = &uStack_2490;
    }
    *(undefined4 *)(&stack0x00000030 + lVar17) = *puVar26;
    uVar11 = *(undefined2 *)(puVar26 + 1);
  }
  else {
    iStack_2544 = *(int *)(lVar41 + 0x38);
    sStack_2540 = *(short *)(lVar41 + 0x3c);
LAB_:
    lVar18 = *(longlong *)(lVar18 + 8);
    if (*(char *)(lVar18 + 0x3f) != '\0') goto LAB_;
    *(undefined4 *)(&stack0x00000030 + lVar17) = *(undefined4 *)(lVar18 + 8);
    uVar11 = *(undefined2 *)(lVar18 + 0xc);
  }
  *(undefined2 *)(&stack0x00000036 + lVar17) = 0;
  *(undefined2 *)(&stack0x00000034 + lVar17) = uVar11;
  if ((iStack_2544 == 0) &&
     (uStack_2110 = CONCAT22(uStack_2110._2_2_,(undefined2)uStack_2110), sStack_2540 == 0)) {
code_r0x001029b1:
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1029bd;
    func_0x(&uStack_2410);
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1029c8;
    func_0x(&stack0xfffffffffffffff8 + lVar17);
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1029da;
    func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar17));
    return;
  }
  uStack_2060 = 0;
  uStack_206c = *(undefined2 *)(param_2 + 1);
  uStack_206a = 0;
  uStack_2078 = 0;
  uStack_2068 = 0;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar17) = 5;
  uVar5 = *(undefined8 *)(param_1 + 0x20);
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100256;
  uStack_2070 = uVar40;
  cVar10 = func_0x(uVar5,&stack0x00000030 + lVar17,&iStack_2544,&uStack_2078);
  if (cVar10 == '\0') goto code_r0x001029b1;
  ppiVar6 = *(int ***)(param_1 + 8);
  uStack_2444 = 0;
  lVar18 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar23 = *(longlong *)(lVar18 + 0x100);
  puVar19 = _DAT_;
  uStack_24a0 = ppiVar6;
  if (lVar23 == 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1002a0;
    puVar19 = (uint *)(*_DAT_)(0);
    lVar23 = *(longlong *)(lVar18 + 0x100);
  }
  uVar42 = rdtsc();
  uVar20 = CONCAT44((int)((ulonglong)puVar19 >> 0x20),(int)uVar42) | uVar42 & 0xffffffff00000000;
  uVar42 = *(ulonglong *)(lVar23 + 0x340);
  if ((uVar42 < uVar20) ||
     ((uVar42 != 0x7fffffffffffffff &&
      (*(ulonglong *)(*(longlong *)(lVar23 + 0x260) + 0xdf0) < uVar42 - uVar20)))) {
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100319;
    iVar13 = func_0x(0,0x1c5ac80);
    bVar45 = iVar13 == 2;
LAB_:
    if (bVar45) {
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100325;
      func_0x(0xa6);
    }
  }
  else if (((*(uint *)(*(longlong *)(lVar23 + 600) + 0xbc) & 4) != 0) &&
          (lVar23 = *(longlong *)(*(longlong *)(lVar23 + 600) + 0x98),
          (*(byte *)(lVar23 + 0x268) & 1) == 0)) {
    bVar45 = (*(uint *)(lVar23 + 800) & 0x180) == 0;
    goto LAB_;
  }
  lVar23 = *(longlong *)(ppiVar6[0xb] + 8);
  ppbVar22 = ppbVar35;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar18 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar18 != 0) && (lVar18 = **(longlong **)(lVar18 + 0x38), lVar18 != 0)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100380;
      iVar13 = (*_DAT_)(lVar18,0x337);
      if (iVar13 != 0) goto LAB_;
    }
    lVar18 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar18 != 0) {
      ppbVar22 = *(byte ***)(lVar18 + 0x60);
    }
  }
LAB_:
  lVar18 = *(longlong *)(lVar23 + 0x728);
LAB_:
  uStack_253c = 0;
  lVar41 = *(longlong *)(&stack0xfffffffffffffff8 + lVar17);
  if (lVar41 != 0) {
    iVar13 = (int)*(short *)((longlong)auStackX_1c + lVar17 + -0x18);
    if (((*(ushort *)(lVar41 + 0x62) & 0x400) == 0) || (iVar13 < 3)) {
      plVar29 = *(longlong **)(&stack0xfffffffffffffff8 + lVar17);
      if (((byte)*(undefined2 *)(lVar41 + 0x62) >> 3 & 1) != 0) {
        if (iVar13 == 3) {
          iVar13 = 4;
        }
        else if (iVar13 < 2) goto LAB_;
        if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 100) & 8) != 0) &&
            (lVar41 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 0x90),
            lVar41 != 0)) && (*(longlong *)(lVar41 + 0x758) != 0)) {
          uVar5 = *(undefined8 *)(lVar41 + 0x758);
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100462;
          func_0x(uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar17),iVar13);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
         ((2 < iVar13 &&
          (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar41 = *plVar29, lVar41 != 0)))))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1004ab;
        iVar15 = (*_DAT_)(lVar41,0x2000,2,auStack_23f0);
        if (iVar15 != 0) {
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1004ce;
      func_0x(plVar29 + 0x13,iVar13);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1004ed;
        func_0x(plVar29,0,iVar13);
      }
      puVar19 = (uint *)((longlong)auStackX_1c + lVar17 + -0x18);
      *puVar19 = *puVar19 & 0xffff0000;
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1003fb;
      func_0x(&stack0xfffffffffffffff8 + lVar17);
    }
  }
  if (*(longlong *)(lVar23 + 0x728) != 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10051d;
    func_0x(&stack0xfffffffffffffff8 + lVar17,param_2,lVar23);
    lVar41 = *(longlong *)(&stack0xfffffffffffffff8 + lVar17);
    if (lVar41 != 0) {
      iVar13 = (int)*(short *)((longlong)auStackX_1c + lVar17 + -0x18);
      if (((*(ushort *)(lVar41 + 0x62) & 0x400) == 0) || (iVar13 < 3)) {
        plVar29 = *(longlong **)(&stack0xfffffffffffffff8 + lVar17);
        if (((byte)*(undefined2 *)(lVar41 + 0x62) >> 3 & 1) != 0) {
          if (iVar13 == 3) {
            iVar13 = 4;
          }
          else if (iVar13 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 100) & 8) != 0) &&
              (lVar41 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 0x90),
              lVar41 != 0)) && (*(longlong *)(lVar41 + 0x758) != 0)) {
            uVar5 = *(undefined8 *)(lVar41 + 0x758);
            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1005af;
            func_0x(uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar17),iVar13)
            ;
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
           ((2 < iVar13 &&
            (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar41 = *plVar29, lVar41 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1005f4;
          iVar15 = (*_DAT_)(lVar41,0x2000,2,auStack_23e0);
          if (iVar15 != 0) {
            LOCK();
            *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100617;
        func_0x(plVar29 + 0x13,iVar13);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100636;
          func_0x(plVar29,0,iVar13);
        }
        puVar19 = (uint *)((longlong)auStackX_1c + lVar17 + -0x18);
        *puVar19 = *puVar19 & 0xffff0000;
        *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100548;
        func_0x(&stack0xfffffffffffffff8 + lVar17);
      }
    }
  }
  *(uint **)(&stack0xffffffffffffffe8 + lVar17) = &uStack_2448;
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar17) = 2;
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10066e;
  ppbVar21 = (byte **)func_0x(_DAT_,lVar23,param_2,&uStack_253c);
  *(byte ***)(&stack0xfffffffffffffff8 + lVar17) = ppbVar21;
  uVar40 = *(uint *)((longlong)auStackX_1c + lVar17 + -0x18) & 0xffff0002 | 2;
  *(uint *)((longlong)auStackX_1c + lVar17 + -0x18) = uVar40;
  if (ppbVar22 != (byte **)0x0) {
    if (ppbVar22[(ulonglong)(*(uint *)(ppbVar22 + 0xa0) & 0xf) + 0xa1] != *ppbVar21) {
      ppbVar22[(ulonglong)(*(uint *)(ppbVar22 + 0xa0) & 0xf) + 0xa1] = *ppbVar21;
      ppbVar22[0xa0] = ppbVar22[0xa0] + 1;
      uVar40 = *(uint *)((longlong)auStackX_1c + lVar17 + -0x18);
    }
  }
  uVar40 = (uStack_253c >> 3 & 1) << 0x18 | uVar40 & 0xffffff;
  *(uint *)((longlong)auStackX_1c + lVar17 + -0x18) = uVar40;
  *(uint *)((longlong)auStackX_8 + lVar17) =
       uStack_253c >> 4 & 1 | *(uint *)((longlong)auStackX_8 + lVar17) & 0xffffff00;
  if (((lVar18 != 0) && (ppbVar22 != (byte **)0x0)) && (ppbVar22 == *(byte ***)(lVar23 + 0x1c38))) {
    *(longlong *)(lVar18 + 0x5b28) = *(longlong *)(lVar18 + 0x5b28) + 1;
    if ((int)uStack_2444 != 0) {
      *(longlong *)(lVar18 + 0x5b30) = *(longlong *)(lVar18 + 0x5b30) + 1;
      *(longlong *)(lVar18 + 0x5b38) = *(longlong *)(lVar18 + 0x5b38) + (ulonglong)uStack_2448;
      if (0xffffff < uVar40) {
        *(longlong *)(lVar18 + 0x5b40) = *(longlong *)(lVar18 + 0x5b40) + 1;
        *(longlong *)(lVar18 + 0x5b48) = *(longlong *)(lVar18 + 0x5b48) + (ulonglong)uStack_2448;
      }
    }
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100746;
  cVar10 = func_0x(lVar23);
  uStack_2538 = 9;
  piVar37 = *(int **)((longlong)auStackX_1c + lVar17 + 4);
  uVar40 = 0;
  if (((cVar10 == '\0') || (*(char *)(lVar23 + 0x2050) == '\0')) ||
     ((*piVar37 == 0 || ((*piVar37 == 9 && (*(short *)(piVar37 + 1) == 1)))))) goto LAB_;
  lVar41 = **(longlong **)(&stack0xfffffffffffffff8 + lVar17);
  if (*(short *)(lVar41 + 0x24) == 0) {
LAB_:
    uStack_2500 = *(undefined8 *)(lVar41 + 0x28);
    uStack_24f8 = *(ushort *)(lVar41 + 0x30);
  }
  else {
    cVar10 = *(char *)(lVar41 + 1);
    if (cVar10 == '\v') {
      if (*(int *)(lVar41 + 0x18) != 99) {
LAB_:
        if (cVar10 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar10 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar41 + 0x18) != 99) goto LAB_;
    }
    uStack_24e8 = *(undefined4 *)(lVar41 + 0x20);
    uStack_24e4 = *(undefined2 *)(lVar41 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1007d6;
    cVar10 = func_0x(&uStack_24e8);
    if (cVar10 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1007e6;
    func_0x(lVar41,&uStack_2500);
  }
  uVar38 = *(uint *)(lVar23 + 0x2108);
  do {
    uVar14 = uVar38 & 0xfffffffe;
    *(undefined8 *)(&stack0x00000038 + lVar17) = *(undefined8 *)(lVar23 + 0x20fc);
    uVar28 = *(undefined4 *)(lVar23 + 0x2104);
    LOCK();
    *(undefined4 *)(&stack0xffffffffffffffc0 + lVar17) =
         *(undefined4 *)(&stack0xffffffffffffffc0 + lVar17);
    UNLOCK();
    uVar38 = *(uint *)(lVar23 + 0x2108);
  } while (uVar14 != uVar38);
  if ((uint)uStack_2500 <= *(uint *)(&stack0x00000038 + lVar17)) {
    if (*(uint *)(&stack0x00000038 + lVar17) != (uint)uStack_2500) goto LAB_;
    uVar38 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000038 + lVar17) >> 0x20);
    if ((uStack_2500._4_4_ <= uVar38) &&
       ((uVar38 != uStack_2500._4_4_ || (uStack_2548 = (ushort)uVar28, uStack_24f8 <= uStack_2548)))
       ) goto LAB_;
  }
  if ((*(char *)(lVar23 + 0x6ac8) == '\0') &&
     (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) != *(longlong *)(lVar23 + 0x2120))) {
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1008ad;
    cVar10 = func_0x(lVar23);
    if (cVar10 == '\0') {
      uVar38 = *(uint *)(lVar23 + 0x2108);
      do {
        uVar14 = uVar38 & 0xfffffffe;
        uStack_2420 = *(undefined8 *)(lVar23 + 0x20fc);
        *(undefined8 *)(&stack0x00000038 + lVar17) = uStack_2420;
        uVar28 = *(undefined4 *)(lVar23 + 0x2104);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc0 + lVar17) =
             *(undefined4 *)(&stack0xffffffffffffffc0 + lVar17);
        UNLOCK();
        uVar38 = *(uint *)(lVar23 + 0x2108);
      } while (uVar14 != uVar38);
      uStack_2548 = (ushort)uVar28;
      uStack_2418 = uStack_2548;
      lVar18 = **(longlong **)(&stack0xfffffffffffffff8 + lVar17);
      if (*(short *)(lVar18 + 0x24) == 0) {
LAB_:
        uStack_2528 = *(undefined8 *)(lVar18 + 0x28);
        uStack_2520 = *(ushort *)(lVar18 + 0x30);
      }
      else {
        cVar10 = *(char *)(lVar18 + 1);
        if (cVar10 == '\v') {
          if (*(int *)(lVar18 + 0x18) != 99) {
LAB_:
            if (cVar10 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar10 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar18 + 0x18) != 99) goto LAB_;
        }
        uStack_24d8 = *(undefined4 *)(lVar18 + 0x20);
        uStack_24d4 = *(undefined2 *)(lVar18 + 0x24);
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100b8a;
        cVar10 = func_0x(&uStack_24d8);
        if (cVar10 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100b9a;
        func_0x(lVar18,&uStack_2528);
      }
      if ((*(uint *)(&stack0x00000038 + lVar17) < (uint)uStack_2528) ||
         ((*(uint *)(&stack0x00000038 + lVar17) == (uint)uStack_2528 &&
          ((uVar38 = (uint)((ulonglong)uStack_2528 >> 0x20),
           *(uint *)(&stack0x0000003c + lVar17) < uVar38 ||
           ((*(uint *)(&stack0x0000003c + lVar17) == uVar38 && (uStack_2548 < uStack_2520)))))))) {
        lVar18 = *(longlong *)(lVar23 + 0x6b0);
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100bfe;
        func_0x(&uStack_2528,asStack_2058,auStack_24f0);
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100c15;
        func_0x(&uStack_2420,asStack_2028,auStack_24f0);
        if ((_DAT_ & 0x10000) == 0) goto LAB_;
        uStack_23c0 = 0x60000;
        uStack_23b8 = 0;
        ppuStack_23b0 = &puStack_2398;
        puStack_23a8 = auStack_2338;
        uStack_2178 = 0;
        uStack_23a0 = 0;
        uStack_2170 = 0;
        puStack_2398 = &uStack_2168;
        uStack_2390 = 0x34;
        uStack_238c = 5;
        uStack_2380 = 0x10;
        uStack_237c = 5;
        uStack_2370 = 0x10;
        uStack_236c = 6;
        uStack_235c = 7;
        uStack_234c = 8;
        uStack_2348 = 0;
        uStack_2340 = 0;
        uStack_233c = 9;
        uStack_2168 = (uint)*(ushort *)(lVar23 + 0x6b8);
        piVar37 = *(int **)((longlong)auStackX_1c + lVar17 + 4);
        uStack_2164 = *(undefined2 *)(piVar37 + 1);
        iStack_2162 = *piVar37;
        uStack_215e = 0xff;
        uStack_215d = *(undefined *)(**(longlong **)(&stack0xfffffffffffffff8 + lVar17) + 1);
        lStack_2388 = lVar18 + 0x254;
        lStack_2378 = lVar18 + 0x244;
        lVar23 = -1;
        do {
          lVar23 = lVar23 + 1;
        } while (asStack_2058[lVar23] != 0);
        iStack_2360 = (int)lVar23 * 2;
        psStack_2368 = asStack_2058;
        lVar23 = -1;
        do {
          lVar23 = lVar23 + 1;
        } while (asStack_2028[lVar23] != 0);
        iStack_2350 = (int)lVar23 * 2;
        psStack_2358 = asStack_2028;
        uStack_24ec = 0;
        pcVar8 = *(code **)(_DAT_ + 0x10);
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100dd4;
        puVar19 = (uint *)(*pcVar8)(lVar18,&uStack_24ec);
        ppuVar9 = ppuStack_23b0;
        uVar38 = uVar40;
        if (puVar19 != (uint *)0x0) {
          lVar23 = -1;
          do {
            lVar23 = lVar23 + 1;
          } while (*(short *)((longlong)puVar19 + lVar23 * 2) != 0);
          uVar38 = (int)lVar23 * 2;
        }
        ppuStack_23b0[10] = puVar19;
        *(uint *)(ppuVar9 + 0xb) = uVar38;
        *(undefined4 *)((longlong)ppuVar9 + 0x5c) = 9;
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100e0e;
        func_0x(auStack_23c8);
      }
      else {
LAB_:
        piVar37 = *(int **)((longlong)auStackX_1c + lVar17 + 4);
      }
LAB_:
      if (*uStack_24a0 != (int *)0x0) {
        if (((*(uint *)((longlong)auStackX_1c + lVar17 + -0x18) & 0xff000000) != 0) &&
           (piVar30 = *uStack_24a0 + 1, *piVar30 = *piVar30 + 1,
           *(char *)((longlong)auStackX_8 + lVar17) != '\0')) {
          (*uStack_24a0)[2] = (*uStack_24a0)[2] + 1;
        }
        **uStack_24a0 = **uStack_24a0 + 1;
      }
      if ((int)uStack_2444 != 0) {
        uVar28 = *(undefined4 *)(uStack_24a0 + 0x2f);
        uVar3 = *(undefined *)(**(longlong **)(&stack0xfffffffffffffff8 + lVar17) + 1);
        piVar30 = uStack_24a0[0xb];
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100e6c;
        func_0x(piVar30,uVar3,&uStack_2448,uVar28);
      }
      lVar23 = **(longlong **)(&stack0xfffffffffffffff8 + lVar17);
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100e8b;
      iVar13 = func_0x(lVar23,1,3);
      if (iVar13 == 0) {
        sVar31 = *(short *)(&stack0xfffffffffffffff0 + lVar17);
        if (((uint)(int)sVar31 < (uint)*(ushort *)(lVar23 + 0x16)) &&
           (*(short *)(lVar23 + (0xfff - (longlong)sVar31) * 2) != 0)) {
          if ((*(longlong *)(lStack_23f8 + 8) == 0) ||
             (lVar18 = *(longlong *)(*(longlong *)(lStack_23f8 + 8) + 8),
             *(char *)(lVar18 + 0x3f) != '\0')) {
            if (*(int *)(lStack_23f8 + 0x40) == 2) {
              iStack_2488 = **(int **)(lStack_23f8 + 0x30);
              uStack_2484 = *(undefined2 *)(*(int **)(lStack_23f8 + 0x30) + 1);
              uStack_2482 = 0;
              piVar30 = &iStack_2488;
            }
            else {
              iStack_2480 = **(int **)(lStack_23f8 + 0x28);
              uStack_247c = *(undefined2 *)(*(int **)(lStack_23f8 + 0x28) + 1);
              uStack_247a = 0;
              piVar30 = &iStack_2480;
            }
            iStack_2478 = *piVar30;
            sStack_2474 = *(short *)(piVar30 + 1);
          }
          else {
            iStack_2478 = *(int *)(lVar18 + 8);
            sStack_2474 = *(short *)(lVar18 + 0xc);
          }
          if (*(int *)(lVar23 + 0x18) == iStack_2478) {
            sVar27 = 0;
            if (*(short *)(lVar23 + 6) != 1) {
              sVar27 = *(short *)(lVar23 + 6);
            }
            sVar12 = 0;
            if (sStack_2474 != 1) {
              sVar12 = sStack_2474;
            }
            if (sVar27 == sVar12) {
              cVar10 = *(char *)(lVar23 + 1);
              acStackX_10[lVar17] = cVar10;
              if (cVar10 == '\x03' || cVar10 == '\x04') {
                if (*(char *)(*(longlong *)(*(longlong *)((longlong)&param_5 + lVar17) + 0x20) +
                             0x1cde) != '\0') {
                  iStack_2470 = *piVar37;
                  uStack_246c = *(undefined2 *)(piVar37 + 1);
                  (&stack0xffffffffffffffe8)[lVar17] = 0;
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100fad;
                  sStack_246a = sVar31;
                  func_0x
                            (*(longlong *)((longlong)&param_5 + lVar17),&iStack_2470,
                             &stack0xfffffffffffffff8 + lVar17,1);
                  acStackX_10[lVar17] = *(char *)(lVar23 + 1);
                }
                iStack_20f4 = (int)sVar31;
                uVar38 = 0xf;
                ppbVar22 = ppbVar35;
                if (*(char *)(lVar23 + 2) < '\0') {
                  pbVar1 = (byte *)(lVar23 + 0x60);
                  if ((sStack_2128 == 0) || (ppbVar22 = uStack_2118, uStack_2118 == (byte **)0x0)) {
                    uStack_20c8 = 0;
                    uStack_20ba = 0;
                    auStack_20a0 = ZEXT816(0);
                    auStack_20f0 = ZEXT816(0);
                    stack0xffffffffffffdf22 = SUB1614(ZEXT816(0),2);
                    auStack_20e0._0_2_ = 0xffff;
                    uStack_20d8 = 0;
                    uStack_20c2 = 0;
                    uStack_20c0 = 0;
                    uStack_20b8 = 0;
                    uStack_20d0 = 0;
                    auStack_20b0 = ZEXT816(0);
                    auStack_2090._0_12_ = ZEXT812(0);
                    auStack_2090._12_4_ = 0;
                    uStack_2080 = 0;
                    ppbVar22 = (byte **)auStack_20f0;
                  }
                  if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
                    uStack_2510 = *(undefined8 *)(lVar23 + 0x28);
                    uStack_2508 = *(undefined2 *)(lVar23 + 0x30);
                  }
                  else {
                    cVar10 = *(char *)(lVar23 + 1);
                    if (cVar10 == '\v') {
                      if (*(int *)(lVar23 + 0x18) != 99) {
LAB_:
                        if (cVar10 != '\t') goto LAB_;
                        goto LAB_;
                      }
                    }
                    else {
                      if (cVar10 != '\b') goto LAB_;
LAB_:
                      if (*(int *)(lVar23 + 0x18) != 99) goto LAB_;
                    }
                    uStack_24d0 = *(undefined4 *)(lVar23 + 0x20);
                    uStack_24cc = *(undefined2 *)(lVar23 + 0x24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1010db;
                    cVar10 = func_0x(&uStack_24d0,0x12b6b78);
                    if (cVar10 == '\0') goto LAB_;
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1010eb;
                    func_0x(lVar23,&uStack_2510);
                  }
                  *ppbVar22 = pbVar1;
                  *(undefined4 *)(ppbVar22 + 0xc) = (undefined4)uStack_2510;
                  *(int *)((longlong)ppbVar22 + 100) = (int)((ulonglong)uStack_2510 >> 0x20);
                  *(undefined2 *)(ppbVar22 + 0xd) = uStack_2508;
                  *(undefined4 *)((longlong)ppbVar22 + 0x6c) = *(undefined4 *)(lVar23 + 0x20);
                  *(undefined2 *)(ppbVar22 + 0xe) = *(undefined2 *)(lVar23 + 0x24);
                  *(undefined2 *)((longlong)ppbVar22 + 0x72) = 0;
                  uStack_24a0 = (int **)CONCAT44(uStack_24a0._4_4_,
                                                 *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1337180)
                                                );
                  uVar42 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1337184);
                  *(undefined2 *)(ppbVar22 + 2) = 0xffff;
                  ppbVar22[3] = (byte *)0x0;
                  *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
                  *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
                  ppbVar22[7] = (byte *)0x0;
                  ppbVar22[4] = (byte *)0x0;
                  ppbVar22[9] = (byte *)0x0;
                  ppbVar22[10] = (byte *)0x0;
                  *(undefined2 *)(ppbVar22 + 0xb) = 0;
                  if ((**ppbVar22 & 2) != 0) {
                    pbVar2 = pbVar1 + uVar42;
                    if ((*pbVar2 & 1) == 0) {
                      *(undefined2 *)(ppbVar22 + 2) = 0;
                      ppbVar22[3] = pbVar2;
                      *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
                      *(undefined4 *)((longlong)ppbVar22 + 0x36) = 0;
                      uVar14 = uVar40;
                      switch(*pbVar2 & 0xe) {
                      default:
                        uVar14 = (uint)*(ushort *)(pbVar2 + 2);
                        if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101365;
                          func_0x(pbVar2,6);
                        }
                        break;
                      case 4:
                        uVar14 = 9;
                        break;
                      case 6:
                      case 10:
                        break;
                      case 0xe:
                        uVar14 = 1;
                      }
                      *(uint *)(ppbVar22 + 4) = uVar14;
                      *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
                    }
                    else {
                      *(undefined2 *)(ppbVar22 + 2) = 1;
                      ppbVar22[3] = pbVar2;
                      bVar4 = *pbVar2;
                      switch(bVar4 & 0x1c) {
                      default:
                        if ((char)pbVar2[1] < '\0') {
                          uVar33 = *(ushort *)(pbVar2 + 1);
                          *(ushort *)((longlong)ppbVar22 + 0x12) = uVar33;
                          sVar31 = 3;
                          uVar33 = (uVar33 & 0x7f) << 8 | uVar33 >> 8;
                        }
                        else {
                          sVar31 = 2;
                          uVar33 = (ushort)pbVar2[1];
                        }
                        *(ushort *)((longlong)ppbVar22 + 0x12) = uVar33;
                        *(short *)(ppbVar22 + 5) = sVar31;
                        uVar33 = *(ushort *)((longlong)ppbVar22 + 0x12);
                        *(short *)((longlong)ppbVar22 + 0x2c) = (short)(uVar33 + 1 >> 1) + sVar31;
                        if (uVar33 < 0x1f) {
                          *(undefined2 *)((longlong)ppbVar22 + 0x2a) = 0;
                          *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
                          *(undefined4 *)(ppbVar22 + 8) = 0;
                          ppbVar22[7] = (byte *)0x0;
                          ppbVar22[4] = (byte *)0x0;
                        }
                        else {
                          iVar13 = uVar33 - 1;
                          *(short *)((longlong)ppbVar22 + 0x2a) =
                               ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                               (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
                          *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
                          *(undefined4 *)(ppbVar22 + 8) = 0;
                          ppbVar22[7] = (byte *)0x0;
                          ppbVar22[4] = (byte *)0x0;
                        }
                        break;
                      case 4:
                        if (((bVar4 & 0x1c) != 4) || (uVar14 = 1, (bVar4 & 2) == 0)) {
                          uVar14 = uVar40;
                        }
                        if (uVar14 == 0) {
                          uVar28 = 1;
                        }
                        else {
                          *(undefined4 *)(ppbVar22 + 8) = 0;
                          uVar28 = 0xf;
                        }
                        ppbVar22[5] = (byte *)0x0;
                        *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
                        ppbVar22[6] = (byte *)0x0;
                        ppbVar22[4] = (byte *)0x0;
                        ppbVar22[7] = (byte *)0x0;
                        ppbVar22[3] = pbVar2;
                        *(undefined4 *)((longlong)ppbVar22 + 0x14) = uVar28;
                        *(uint *)(ppbVar22 + 8) = (uint)(uVar14 != 0);
                        ppbVar22[7] = (byte *)0x0;
                        ppbVar22[4] = (byte *)0x0;
                        break;
                      case 8:
                        ppbVar22[5] = (byte *)0x0;
                        *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
                        ppbVar22[6] = (byte *)0x0;
                        ppbVar22[4] = (byte *)0x0;
                        ppbVar22[7] = (byte *)0x0;
                        ppbVar22[3] = pbVar2;
                        *(undefined4 *)((longlong)ppbVar22 + 0x14) = 9;
                        *(undefined4 *)(ppbVar22 + 8) = 0;
                        ppbVar22[7] = (byte *)0x0;
                        ppbVar22[4] = (byte *)0x0;
                      }
                    }
                  }
                  if ((**ppbVar22 & 4) != 0) {
                    if (uStack_24a0._2_2_ != 0) {
                      uVar42 = (ulonglong)
                               *(ushort *)(lVar23 + 0x61 + (longlong)uStack_24a0._2_2_ * 2);
                    }
                    psVar24 = (short *)(pbVar1 + uVar42);
                    ppbVar22[9] = (byte *)psVar24;
                    sVar31 = *psVar24;
                    ppbVar22[10] = (byte *)(psVar24 + 1);
                    *(short *)(ppbVar22 + 0xb) = (sVar31 + 1) * 2;
                  }
                  pbVar1 = ppbVar22[1];
                  if (pbVar1 != (byte *)0x0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1013fc;
                    func_0x(pbVar1,ppbVar22);
                  }
                }
                uVar14 = 8;
                pbStack_2120 = (byte *)((ulonglong)
                                        *(ushort *)
                                         (lVar23 + (0xfff - (longlong)
                                                            *(short *)(&stack0xfffffffffffffff0 +
                                                                      lVar17)) * 2) + lVar23);
                if ((*pbStack_2120 & 1) == 0) {
                  sStack_2128 = 0;
                  uStack_2124 = 0;
                  uStack_2102 = 0;
                  uStack_2100 = 0;
                  uVar38 = (uint)*(ushort *)(lVar23 + 0xe);
                  switch(*pbStack_2120 & 0xe) {
                  default:
                    uVar33 = *(ushort *)(pbStack_2120 + 2);
                    uVar38 = (uint)uVar33;
                    if (0x1f9d < uVar33 - 1) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10162e;
                      func_0x(pbStack_2120,6);
                      uVar38 = (uint)uVar33;
                    }
                    break;
                  case 4:
                    uVar38 = 9;
                    break;
                  case 6:
                  case 10:
                    break;
                  case 0xe:
                    uVar38 = 1;
                  }
                  uStack_2118 = (byte **)CONCAT44(uStack_2118._4_4_,uVar38);
                  uStack_210a = (undefined2)(lVar23 + 0x2000);
                  uStack_2108 = (undefined6)((ulonglong)(lVar23 + 0x2000) >> 0x10);
                  uVar38 = uStack_2124;
                }
                else {
                  sStack_2128 = 1;
                  bVar4 = *pbStack_2120;
                  switch(bVar4 & 0x1c) {
                  default:
                    if ((char)pbStack_2120[1] < '\0') {
                      uStack_2126 = (*(ushort *)(pbStack_2120 + 1) & 0x7f) << 8 |
                                    *(ushort *)(pbStack_2120 + 1) >> 8;
                      uStack_2110._0_2_ = 3;
                      sVar31 = 3;
                    }
                    else {
                      uStack_2126 = (ushort)pbStack_2120[1];
                      uStack_2110._0_2_ = 2;
                      sVar31 = 2;
                    }
                    uStack_210c = (short)(uStack_2126 + 1 >> 1) + sVar31;
                    if (uStack_2126 < 0x1f) {
                      uStack_2110._2_2_ = 0;
                      uStack_2124 = 0;
                      uStack_20f8 = 0;
                      uVar38 = 0;
                    }
                    else {
                      iVar13 = uStack_2126 - 1;
                      uStack_2110._2_2_ =
                           ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                           (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
                      uVar38 = 0;
                      uStack_2124 = 0;
                      uStack_20f8 = 0;
                    }
                    break;
                  case 4:
                    if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
                      uStack_2110._0_2_ = 0;
                      uStack_2110._2_2_ = 0;
                      uStack_210c = 0;
                      uStack_210a = 0;
                      uStack_2126 = 0;
                      uStack_2108 = 0;
                      uStack_2102 = 0;
                      uStack_2124 = 0xf;
                      uStack_20f8 = 1;
                    }
                    else {
                      uStack_2110._0_2_ = 0;
                      uStack_2110._2_2_ = 0;
                      uStack_210c = 0;
                      uStack_210a = 0;
                      uStack_2126 = 0;
                      uStack_2108 = 0;
                      uStack_2102 = 0;
                      uVar38 = 1;
                      uStack_2124 = 1;
                      uStack_20f8 = 0;
                    }
                    break;
                  case 8:
                    uStack_2110._0_2_ = 0;
                    uStack_2110._2_2_ = 0;
                    uStack_210c = 0;
                    uStack_210a = 0;
                    uStack_2126 = 0;
                    uStack_2108 = 0;
                    uStack_2102 = 0;
                    uVar38 = 9;
                    uStack_2124 = 9;
                    uStack_20f8 = 0;
                  }
                  lVar23 = lVar23 + 0x2000;
                  uStack_2100 = (undefined2)lVar23;
                  uStack_20fe = (undefined2)((ulonglong)lVar23 >> 0x10);
                  uStack_20fc = (ushort)((ulonglong)lVar23 >> 0x20);
                  uStack_20fa = (undefined2)((ulonglong)lVar23 >> 0x30);
                  uStack_2118 = ppbVar22;
                }
                if ((sStack_2128 == 0) && ((*pbStack_2120 & 0xe) == 8)) {
                  uVar14 = uStack_2110;
                  if (uVar38 == 0) {
                    uStack_2126 = 0;
                    uVar42 = (ulonglong)uStack_2118 & 0xffffffff;
                    uVar38 = (uint)uStack_2118;
                    if ((*pbStack_2120 & 0x10) != 0) {
                      uVar38 = (uint)uStack_2118 + 2 + (*(ushort *)(pbStack_2120 + uVar42) + 7 >> 3)
                      ;
                      uVar42 = (ulonglong)uVar38;
                    }
                    uStack_2118 = (byte **)CONCAT44(uVar38,(uint)uStack_2118);
                    uVar14 = (uint)uVar42;
                    if ((*pbStack_2120 & 0x20) == 0) {
                      uStack_210c = 0;
                      uStack_2124 = uVar14;
                    }
                    else {
                      puVar43 = (ushort *)(pbStack_2120 + uVar42);
                      uStack_210c = *puVar43;
                      if (uStack_210c == 0) {
                        if ((((cRam0000000001c49c6b != '\0') || ((bRam0000000001c5a570 & 1) != 0))
                            && (lVar23 = *(longlong *)
                                          ((ulonglong)*_DAT_ +
                                           *(longlong *)
                                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                            (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0)) &&
                           ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                            (*(char *)(lVar23 + 0x499) != '\0')))) {
                          if ((cRam0000000001c49b5b == '\0') && ((bRam0000000001c5a570 & 2) == 0)) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101761;
                            (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1017d1;
                            (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x80f);
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1017e2;
                        func_0x(pbStack_2120,3);
                      }
                      uStack_2110 = uStack_2118._4_4_ + 2 + (uint)uStack_210c * 2;
                      if (0x1f9e < uStack_2110) {
                        if (((cRam0000000001c49c6b != '\0') || ((bRam0000000001c5a570 & 1) != 0)) &&
                           ((lVar23 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0 &&
                            ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                             (*(char *)(lVar23 + 0x499) != '\0')))))) {
                          if ((cRam0000000001c49b5b == '\0') && ((bRam0000000001c5a570 & 2) == 0)) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101888;
                            (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1018ac;
                            (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x816);
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1018bd;
                        func_0x(pbStack_2120,4);
                      }
                      uVar20 = (ulonglong)uStack_210c;
                      uStack_2124 = puVar43[uVar20] & 0x7fff;
                      uVar42 = (ulonglong)uStack_2124;
                      uVar14 = uStack_2110;
                      if (uStack_2124 < uStack_2110) {
                        if ((((cRam0000000001c49c6b != '\0') || ((bRam0000000001c5a570 & 1) != 0))
                            && (lVar23 = *(longlong *)
                                          ((ulonglong)*_DAT_ +
                                           *(longlong *)
                                            (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                            (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0)) &&
                           ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                            (*(char *)(lVar23 + 0x499) != '\0')))) {
                          if ((cRam0000000001c49b5b == '\0') && ((bRam0000000001c5a570 & 2) == 0)) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101962;
                            (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101986;
                            (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x81d);
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101997;
                        func_0x(pbStack_2120,4);
                        uVar20 = (ulonglong)uStack_210c;
                        uVar42 = (ulonglong)uStack_2124;
                        uVar14 = uStack_2110;
                      }
                      do {
                        if (-1 < (short)puVar43[(ulonglong)((int)uVar20 - 1) + 1]) break;
                        uVar36 = uStack_2110;
                        if ((int)uVar20 != 1) {
                          uVar36 = *(ushort *)
                                    (pbStack_2120 +
                                    uVar20 * 2 + (((ulonglong)uStack_2118 >> 0x20) - 2)) & 0x7fff;
                        }
                        if ((uVar36 < uStack_2110) ||
                           ((*(ushort *)
                              (pbStack_2120 + uVar20 * 2 + ((ulonglong)uStack_2118 >> 0x20)) &
                            0x7fff) < uVar36)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101a10;
                          uStack_2110 = uVar14;
                          func_0x(pbStack_2120,7);
                          uVar20 = (ulonglong)uStack_210c;
                          uVar42 = (ulonglong)uStack_2124;
                          uVar14 = uStack_2110;
                        }
                        uVar38 = (uint)uVar42;
                        if ((uVar36 < uStack_2110) || (uVar38 < uVar36)) goto code_r0x00101d2a;
                        if (*(ushort *)(pbStack_2120 + uVar36) == 5) {
                          uStack_2126 = uStack_2126 | 2;
                          uStack_210c = (short)uVar20 - 1;
                          uStack_20fe = (undefined2)uVar36;
                          if ((*(ushort *)(pbStack_2120 + (ulonglong)(uVar36 & 0xffff) + 2) >> 0xe &
                              1) == 0) {
                            uStack_20fc = uStack_20fc & 0xc7ff;
                          }
                          else {
                            uStack_20fc = uStack_20fc ^
                                          (uStack_20fc ^
                                          *(ushort *)
                                           (pbStack_2120 + (ulonglong)(uVar36 & 0xffff) + 2)) &
                                          0x3800;
                          }
                          uStack_20fc = (uStack_20fc ^
                                        *(ushort *)(pbStack_2120 + (ulonglong)(uVar36 & 0xffff) + 2)
                                        ) & 0x7ff ^ uStack_20fc;
                          break;
                        }
                        if (*(ushort *)(pbStack_2120 + uVar36) < 0x400) break;
                        uStack_2126 = uStack_2126 | 1;
                        uStack_210c = (short)uVar20 - 1;
                        uVar20 = (ulonglong)uStack_210c;
                      } while (uStack_210c != 0);
                    }
                    if ((*pbStack_2120 & 0x40) == 0) {
                      uStack_2102 = 0;
                      uStack_2100 = 0;
                    }
                    else {
                      uStack_2102 = (undefined2)uVar42;
                      uStack_2100 = (undefined2)(uVar42 >> 0x10);
                      uStack_2124 = (int)uVar42 + 0xe;
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101b2b;
                      uStack_2110 = uVar14;
                      puVar25 = (ulonglong *)func_0x(&uStack_2126);
                      uVar32 = (ushort)(*puVar25 >> 0x30);
                      uVar33 = uVar32;
                      if ((((uint)(int)(short)uVar32 >> 1 ^ (int)(short)uVar32) & 0x2000) != 0) {
                        uVar33 = uVar32 & 0xdfff;
                        if ((uVar32 >> 0xe & 1) != 0) {
                          uVar33 = uVar32 | 0x2000;
                        }
                      }
                      if (uVar33 == 0xfffc) {
                        iVar16 = (int)((*puVar25 >> 0x20 & 0xffff) >> 5);
                      }
                      uStack_2124 = uStack_2124 + iVar16;
                      uVar42 = (ulonglong)uStack_2124;
                      uVar14 = uStack_2110;
                    }
                    uVar38 = (uint)uVar42;
                    uStack_2110 = uVar14;
                    if (((byte *)CONCAT62(uStack_2108,uStack_210a) != (byte *)0x0) &&
                       ((byte *)CONCAT62(uStack_2108,uStack_210a) < pbStack_2120 + uVar42)) {
                      if (((cRam0000000001c49c6b != '\0') || ((bRam0000000001c5a570 & 1) != 0)) &&
                         (((lVar23 = *(longlong *)
                                      ((ulonglong)*_DAT_ +
                                       *(longlong *)
                                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                        (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0 &&
                           (lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0)) &&
                          (*(char *)(lVar23 + 0x499) != '\0')))) {
                        if ((cRam0000000001c49b5b == '\0') && ((bRam0000000001c5a570 & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101c2c;
                          (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101c50;
                          (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x877);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101c61;
                      func_0x(pbStack_2120,0x12);
                      uVar38 = uStack_2124;
                    }
                    uVar14 = uStack_2110;
                    if (0x3f3b < uVar38 - 1) {
                      if (((cRam0000000001c49c6b != '\0') || ((bRam0000000001c5a570 & 1) != 0)) &&
                         ((lVar23 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0 &&
                          ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                           (*(char *)(lVar23 + 0x499) != '\0')))))) {
                        if ((cRam0000000001c49b5b == '\0') && ((bRam0000000001c5a570 & 2) == 0)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101cef;
                          (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101d13;
                          (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x87c);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101d24;
                      func_0x(pbStack_2120,5);
                      uVar38 = uStack_2124;
                      uVar14 = uStack_2110;
                    }
                  }
code_r0x00101d2a:
                  if (((uVar38 < 9) &&
                      (((*pbStack_2120 & 0xe) == 0 || ((*pbStack_2120 & 0xe) == 0xc)))) ||
                     (uVar38 < 0x1f9e)) {
                    uStack_2110 = uVar14;
                    if (sStack_2128 == 0) {
                      uVar36 = uVar38;
                      if (uVar38 == 0) {
                        uStack_2126 = 0;
                        uVar42 = (ulonglong)uStack_2118 & 0xffffffff;
                        uVar38 = (uint)uStack_2118;
                        if ((*pbStack_2120 & 0x10) != 0) {
                          uVar38 = (uint)uStack_2118 + 2 +
                                   (*(ushort *)(pbStack_2120 + uVar42) + 7 >> 3);
                          uVar42 = (ulonglong)uVar38;
                        }
                        uStack_2118 = (byte **)CONCAT44(uVar38,(uint)uStack_2118);
                        uVar14 = (uint)uVar42;
                        if ((*pbStack_2120 & 0x20) == 0) {
                          uStack_210c = 0;
                          uStack_2124 = uVar14;
                        }
                        else {
                          puVar43 = (ushort *)(pbStack_2120 + uVar42);
                          uStack_210c = *puVar43;
                          if (uStack_210c == 0) {
                            if ((((cRam0000000001c49c6b != '\0') ||
                                 ((bRam0000000001c5a570 & 1) != 0)) &&
                                (lVar23 = *(longlong *)
                                           ((ulonglong)*_DAT_ +
                                            *(longlong *)
                                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                             (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0)) &&
                               ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                                (*(char *)(lVar23 + 0x499) != '\0')))) {
                              if ((cRam0000000001c49b5b == '\0') &&
                                 ((bRam0000000001c5a570 & 2) == 0)) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101e3c;
                                (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101e60;
                                (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x80f);
                              }
                            }
                            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101e71;
                            func_0x(pbStack_2120,3);
                          }
                          uStack_2110 = uStack_2118._4_4_ + 2 + (uint)uStack_210c * 2;
                          if (0x1f9e < uStack_2110) {
                            if (((cRam0000000001c49c6b != '\0') || ((bRam0000000001c5a570 & 1) != 0)
                                ) && ((lVar23 = *(longlong *)
                                                 ((ulonglong)*_DAT_ +
                                                  *(longlong *)
                                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                                   (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0
                                      && ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                                          (*(char *)(lVar23 + 0x499) != '\0')))))) {
                              if ((cRam0000000001c49b5b == '\0') &&
                                 ((bRam0000000001c5a570 & 2) == 0)) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101f17;
                                (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101f3b;
                                (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x816);
                              }
                            }
                            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101f4c;
                            func_0x(pbStack_2120,4);
                          }
                          uVar20 = (ulonglong)uStack_210c;
                          uStack_2124 = puVar43[uVar20] & 0x7fff;
                          uVar42 = (ulonglong)uStack_2124;
                          uVar14 = uStack_2110;
                          if (uStack_2124 < uStack_2110) {
                            if ((((cRam0000000001c49c6b != '\0') ||
                                 ((bRam0000000001c5a570 & 1) != 0)) &&
                                (lVar23 = *(longlong *)
                                           ((ulonglong)*_DAT_ +
                                            *(longlong *)
                                             (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                             (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0)) &&
                               ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                                (*(char *)(lVar23 + 0x499) != '\0')))) {
                              if ((cRam0000000001c49b5b == '\0') &&
                                 ((bRam0000000001c5a570 & 2) == 0)) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x101ff1;
                                (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102015;
                                (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x81d);
                              }
                            }
                            *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102026;
                            func_0x(pbStack_2120,4);
                            uVar20 = (ulonglong)uStack_210c;
                            uVar42 = (ulonglong)uStack_2124;
                            uVar14 = uStack_2110;
                          }
                          do {
                            if (-1 < (short)puVar43[(ulonglong)((int)uVar20 - 1) + 1]) break;
                            uVar38 = uStack_2110;
                            if ((int)uVar20 != 1) {
                              uVar38 = *(ushort *)
                                        (pbStack_2120 +
                                        uVar20 * 2 + (((ulonglong)uStack_2118 >> 0x20) - 2)) &
                                       0x7fff;
                            }
                            if ((uVar38 < uStack_2110) ||
                               ((*(ushort *)
                                  (pbStack_2120 + uVar20 * 2 + ((ulonglong)uStack_2118 >> 0x20)) &
                                0x7fff) < uVar38)) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1020a0;
                              uStack_2110 = uVar14;
                              func_0x(pbStack_2120,7);
                              uVar20 = (ulonglong)uStack_210c;
                              uVar42 = (ulonglong)uStack_2124;
                              uVar14 = uStack_2110;
                            }
                            uVar36 = (uint)uVar42;
                            if ((uVar38 < uStack_2110) || (uVar36 < uVar38)) goto code_r0x001023b3;
                            if (*(ushort *)(pbStack_2120 + uVar38) == 5) {
                              uStack_2126 = uStack_2126 | 2;
                              uStack_210c = (short)uVar20 - 1;
                              uStack_20fe = (undefined2)uVar38;
                              if ((*(ushort *)(pbStack_2120 + (ulonglong)(uVar38 & 0xffff) + 2) >>
                                   0xe & 1) == 0) {
                                uStack_20fc = uStack_20fc & 0xc7ff;
                              }
                              else {
                                uStack_20fc = uStack_20fc ^
                                              (uStack_20fc ^
                                              *(ushort *)
                                               (pbStack_2120 + (ulonglong)(uVar38 & 0xffff) + 2)) &
                                              0x3800;
                              }
                              uStack_20fc = (uStack_20fc ^
                                            *(ushort *)
                                             (pbStack_2120 + (ulonglong)(uVar38 & 0xffff) + 2)) &
                                            0x7ff ^ uStack_20fc;
                              break;
                            }
                            if (*(ushort *)(pbStack_2120 + uVar38) < 0x400) break;
                            uStack_2126 = uStack_2126 | 1;
                            uStack_210c = (short)uVar20 - 1;
                            uVar20 = (ulonglong)uStack_210c;
                          } while (uStack_210c != 0);
                        }
                        if ((*pbStack_2120 & 0x40) == 0) {
                          uStack_2102 = 0;
                          uStack_2100 = 0;
                        }
                        else {
                          uStack_2102 = (undefined2)uVar42;
                          uStack_2100 = (undefined2)(uVar42 >> 0x10);
                          uStack_2124 = (int)uVar42 + 0xe;
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1021b9;
                          uStack_2110 = uVar14;
                          puVar25 = (ulonglong *)func_0x(&uStack_2126);
                          uVar33 = (ushort)(*puVar25 >> 0x30);
                          if ((((uint)(int)(short)uVar33 >> 1 ^ (int)(short)uVar33) & 0x2000) != 0)
                          {
                            if ((uVar33 >> 0xe & 1) == 0) {
                              uVar33 = uVar33 & 0xdfff;
                            }
                            else {
                              uVar33 = uVar33 | 0x2000;
                            }
                          }
                          if (uVar33 == 0xfffc) {
                            iVar34 = (int)((*puVar25 >> 0x20 & 0xffff) >> 5);
                          }
                          uStack_2124 = uStack_2124 + iVar34;
                          uVar42 = (ulonglong)uStack_2124;
                          uVar14 = uStack_2110;
                        }
                        uVar36 = (uint)uVar42;
                        uStack_2110 = uVar14;
                        if (((byte *)CONCAT62(uStack_2108,uStack_210a) != (byte *)0x0) &&
                           ((byte *)CONCAT62(uStack_2108,uStack_210a) < pbStack_2120 + uVar42)) {
                          if (((cRam0000000001c49c6b != '\0') || ((bRam0000000001c5a570 & 1) != 0))
                             && (((lVar23 = *(longlong *)
                                             ((ulonglong)*_DAT_ +
                                              *(longlong *)
                                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                               (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0 &&
                                  (lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0)) &&
                                 (*(char *)(lVar23 + 0x499) != '\0')))) {
                            if ((cRam0000000001c49b5b == '\0') && ((bRam0000000001c5a570 & 2) == 0))
                            {
                              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1022b5;
                              (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1022d9;
                              (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x877);
                            }
                          }
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1022ea;
                          func_0x(pbStack_2120,0x12);
                          uVar36 = uStack_2124;
                        }
                        uVar14 = uStack_2110;
                        if (0x3f3b < uVar36 - 1) {
                          if (((cRam0000000001c49c6b != '\0') || ((bRam0000000001c5a570 & 1) != 0))
                             && ((lVar23 = *(longlong *)
                                            ((ulonglong)*_DAT_ +
                                             *(longlong *)
                                              (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                              (ulonglong)*_DAT_ * 8) + 8), lVar23 != 0 &&
                                 ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                                  (*(char *)(lVar23 + 0x499) != '\0')))))) {
                            if ((cRam0000000001c49b5b == '\0') && ((bRam0000000001c5a570 & 2) == 0))
                            {
                              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102378;
                              (*pcRam00000000011b8498)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10239c;
                              (*pcRam00000000011b8490)(1,0x153a698,0x165a368,0x87c);
                            }
                          }
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1023ad;
                          func_0x(pbStack_2120,5);
                          uVar36 = uStack_2124;
                          uVar14 = uStack_2110;
                        }
                      }
code_r0x001023b3:
                      if ((8 < uVar36) ||
                         ((uVar38 = uStack_2538, (*pbStack_2120 & 0xe) != 0 &&
                          ((*pbStack_2120 & 0xe) != 0xc)))) {
                        uVar38 = uVar36;
                        uStack_2538 = uVar36;
                      }
                    }
                    else {
                      if (uVar38 == 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1023e4;
                        func_0x(&uStack_2126);
                        uVar38 = uStack_2124;
                        uVar14 = uStack_2110;
                      }
                      if ((uVar38 < 9) &&
                         (((*pbStack_2120 & 0x1c) == 0 || ((*pbStack_2120 & 0x1c) == 0xc)))) {
                        uVar38 = 9;
                      }
                    }
                  }
                  else {
                    uVar38 = 0x1f9e;
                  }
                  uStack_2110 = uVar14;
                  if (uVar38 != 0) {
                    if ((pbStack_2120 == (byte *)0x0) || (0x1f9e < uVar38)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102453;
                      func_0x(auStack_1ff8,0,0x1f9e);
                      if (pbStack_2120 == (byte *)0x0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102463;
                        puVar26 = (undefined4 *)(*pcRam00000000011b8830)();
                        *puVar26 = 0x16;
                      }
                      else {
                        if (uVar38 < 0x1f9f) goto code_r0x00102486;
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10247a;
                        puVar26 = (undefined4 *)(*pcRam00000000011b8830)();
                        *puVar26 = 0x22;
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102486;
                      (*pcRam00000000011b8848)();
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10243d;
                      func_0x(auStack_1ff8,pbStack_2120,uVar38);
                    }
                  }
code_r0x00102486:
                  uVar14 = uStack_1fec & 0xf;
                  puVar44 = auStack_1ff8;
                  lStack_2530 = lStack_1ff4;
                }
                else {
                  puVar44 = puStack_2458;
                  if (plStack_2450 != (longlong *)0x0) {
                    lStack_2530 = *plStack_2450;
                  }
                }
                plVar29 = plStack_2450;
                lVar23 = *(longlong *)(&stack0xfffffffffffffff8 + lVar17);
                if (lVar23 != 0) {
                  iVar34 = (int)*(short *)((longlong)auStackX_1c + lVar17 + -0x18);
                  if (((*(ushort *)(lVar23 + 0x62) >> 10 & 1) == 0) || (iVar34 < 3)) {
                    plVar7 = *(longlong **)(&stack0xfffffffffffffff8 + lVar17);
                    if (((byte)*(undefined2 *)(lVar23 + 0x62) >> 3 & 1) != 0) {
                      if (iVar34 == 3) {
                        iVar34 = 4;
                      }
                      else if (iVar34 < 2) goto code_r0x0010254b;
                      if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 100) & 8)
                            != 0) &&
                          (lVar23 = *(longlong *)
                                     (*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 0x90),
                          lVar23 != 0)) && (*(longlong *)(lVar23 + 0x758) != 0)) {
                        uVar5 = *(undefined8 *)(lVar23 + 0x758);
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10254b;
                        func_0x
                                  (uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar17),iVar34);
                      }
                    }
code_r0x0010254b:
                    if ((((DAT_ & 0x80) != 0) &&
                        ((*(uint *)((longlong)plVar7 + 100) & 8) != 0)) &&
                       ((2 < iVar34 &&
                        (((*(uint *)((longlong)plVar7 + 100) & 0xc0000000) != 0x40000000 &&
                         (lVar23 = *plVar7, lVar23 != 0)))))) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10258f;
                      iVar16 = (*_DAT_)(lVar23,0x2000,2,auStack_23e8);
                      if (iVar16 != 0) {
                        LOCK();
                        *(uint *)((longlong)plVar7 + 100) =
                             *(uint *)((longlong)plVar7 + 100) & 0x3fffffff;
                        UNLOCK();
                        LOCK();
                        *(uint *)((longlong)plVar7 + 100) =
                             *(uint *)((longlong)plVar7 + 100) | 0x40000000;
                        UNLOCK();
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1025b1;
                    func_0x(plVar7 + 0x13,iVar34);
                    if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1025d0;
                      func_0x(plVar7,0,iVar34);
                    }
                    puVar19 = (uint *)((longlong)auStackX_1c + lVar17 + -0x18);
                    *puVar19 = *puVar19 & 0xffff0000;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1024e6;
                    func_0x(&stack0xfffffffffffffff8 + lVar17);
                  }
                }
                if ((plVar29 == (longlong *)0x0) || (lStack_2530 == *plVar29)) {
                  switch(uVar14) {
                  default:
                    puVar26 = *(undefined4 **)((longlong)auStackX_1c + lVar17 + 4);
                    uVar28 = *puVar26;
                    uVar11 = *(undefined2 *)(puVar26 + 1);
                    uVar5 = *(undefined8 *)((longlong)&param_5 + lVar17);
                    if (acStackX_10[lVar17] == '\x04') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10285b;
                      uStack_24a8 = uVar28;
                      uStack_24a4 = uVar11;
                      func_0x(uVar5,&uStack_24a8);
                    }
                    else {
                      *(undefined4 *)((longlong)&uStackX_18 + lVar17) = uVar28;
                      *(undefined2 *)((longlong)auStackX_1c + lVar17) = uVar11;
                      *(undefined2 *)((longlong)auStackX_1c + lVar17 + 2) =
                           *(undefined2 *)(&stack0xfffffffffffffff0 + lVar17);
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102883;
                      func_0x(uVar5,(longlong)&uStackX_18 + lVar17,0,0);
                    }
                    break;
                  case 1:
                  case 2:
                    puVar26 = *(undefined4 **)((longlong)auStackX_1c + lVar17 + 4);
                    uVar28 = *puVar26;
                    uVar11 = *(undefined2 *)(puVar26 + 1);
                    uVar5 = *(undefined8 *)((longlong)&param_5 + lVar17);
                    if (uVar14 == 1) {
                      *(undefined4 *)((longlong)&uStackX_18 + lVar17) = uVar28;
                      *(undefined2 *)((longlong)auStackX_1c + lVar17) = uVar11;
                      *(undefined2 *)((longlong)auStackX_1c + lVar17 + 2) =
                           *(undefined2 *)(&stack0xfffffffffffffff0 + lVar17);
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102784;
                      func_0x(uVar5,(longlong)&uStackX_18 + lVar17,0,0);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102799;
                      uStack_24b8 = uVar28;
                      uStack_24b4 = uVar11;
                      func_0x(uVar5,&uStack_24b8);
                    }
                    iVar34 = param_5;
                    uVar33 = *(ushort *)(puVar44 + 0x10);
                    if (((*(ushort *)(puVar44 + 0xe) < uVar33) || (0x1f8 < uVar33)) ||
                       ((uVar38 = (uint)uVar33, uVar14 == 1 && (uVar38 = (uint)uVar33, 5 < uVar33)))
                       ) {
                      uVar38 = uVar40;
                    }
                    if (param_5 != 0) {
                      while (iVar16 = (int)ppbVar35, iVar16 < (int)uVar38) {
                        if ((undefined8 *)(puVar44 + (longlong)iVar16 * 0x10 + 0x1c) ==
                            (undefined8 *)0x0) {
                          uStack_2518 = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1027fd;
                          puVar26 = (undefined4 *)(*pcRam00000000011b8830)();
                          *puVar26 = 0x16;
                          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102809;
                          (*pcRam00000000011b8848)();
                        }
                        else {
                          uStack_2518 = *(undefined8 *)(puVar44 + (longlong)iVar16 * 0x10 + 0x1c);
                        }
                        uStack_24b0 = (undefined4)uStack_2518;
                        uStack_24ac = uStack_2518._4_2_;
                        *(int *)(&stack0xffffffffffffffe0 + lVar17) = iVar34;
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102830;
                        FUN_(uVar5,&uStack_24b0,uStack_2518._6_2_,&lStack_2530);
                        ppbVar35 = (byte **)(ulonglong)(iVar16 + 1);
                      }
                    }
                    break;
                  case 4:
                  case 5:
                    puVar26 = *(undefined4 **)((longlong)auStackX_1c + lVar17 + 4);
                    *(undefined4 *)((longlong)&uStackX_18 + lVar17) = *puVar26;
                    *(undefined2 *)((longlong)auStackX_1c + lVar17) = *(undefined2 *)(puVar26 + 1);
                    *(undefined2 *)((longlong)auStackX_1c + lVar17 + 2) =
                         *(undefined2 *)(&stack0xfffffffffffffff0 + lVar17);
                    uVar5 = *(undefined8 *)((longlong)&param_5 + lVar17);
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102645;
                    func_0x(uVar5,(longlong)&uStackX_18 + lVar17,0,0);
                    iVar34 = param_5;
                    uVar33 = *(ushort *)(puVar44 + 0x10);
                    if ((*(ushort *)(puVar44 + 0xe) < uVar33) || (uVar38 = (uint)uVar33, 5 < uVar33)
                       ) {
                      uVar38 = uVar40;
                    }
                    if (param_5 != 0) {
                      puVar39 = (undefined2 *)(puVar44 + 0x22);
                      for (; (longlong)ppbVar35 < (longlong)(ulonglong)uVar38;
                          ppbVar35 = (byte **)((longlong)ppbVar35 + 1)) {
                        uStack_24c8 = *(undefined4 *)(puVar39 + -3);
                        uStack_24c4 = puVar39[-1];
                        *(int *)(&stack0xffffffffffffffe0 + lVar17) = iVar34;
                        uVar11 = *puVar39;
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10269f;
                        FUN_(uVar5,&uStack_24c8,uVar11,&lStack_2530);
                        puVar39 = puVar39 + 6;
                      }
                    }
                    break;
                  case 6:
                    puVar26 = *(undefined4 **)((longlong)auStackX_1c + lVar17 + 4);
                    *(undefined4 *)((longlong)&uStackX_18 + lVar17) = *puVar26;
                    *(undefined2 *)((longlong)auStackX_1c + lVar17) = *(undefined2 *)(puVar26 + 1);
                    *(undefined2 *)((longlong)auStackX_1c + lVar17 + 2) =
                         *(undefined2 *)(&stack0xfffffffffffffff0 + lVar17);
                    uVar5 = *(undefined8 *)((longlong)&param_5 + lVar17);
                    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1026de;
                    func_0x(uVar5,(longlong)&uStackX_18 + lVar17,0,0);
                    iVar34 = param_5;
                    uVar33 = *(ushort *)(puVar44 + 0x10);
                    if ((*(ushort *)(puVar44 + 0xe) < uVar33) || (uVar38 = (uint)uVar33, 5 < uVar33)
                       ) {
                      uVar38 = uVar40;
                    }
                    if (param_5 != 0) {
                      puVar39 = (undefined2 *)(puVar44 + 0x26);
                      for (; (longlong)ppbVar35 < (longlong)(ulonglong)uVar38;
                          ppbVar35 = (byte **)((longlong)ppbVar35 + 1)) {
                        uStack_24c0 = *(undefined4 *)(puVar39 + -3);
                        uStack_24bc = puVar39[-1];
                        *(int *)(&stack0xffffffffffffffe0 + lVar17) = iVar34;
                        uVar11 = *puVar39;
                        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10273f;
                        FUN_(uVar5,&uStack_24c0,uVar11,&lStack_2530);
                        puVar39 = puVar39 + 8;
                      }
                    }
                  }
                }
                goto code_r0x001029b1;
              }
            }
          }
        }
      }
      lVar23 = *(longlong *)(&stack0xfffffffffffffff8 + lVar17);
      if (lVar23 == 0) goto code_r0x001029b1;
      iVar34 = (int)*(short *)((longlong)auStackX_1c + lVar17 + -0x18);
      if (((*(ushort *)(lVar23 + 0x62) >> 10 & 1) != 0) && (2 < iVar34)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1028b5;
        func_0x(&stack0xfffffffffffffff8 + lVar17);
        goto code_r0x001029b1;
      }
      plVar29 = *(longlong **)(&stack0xfffffffffffffff8 + lVar17);
      if (((byte)*(undefined2 *)(lVar23 + 0x62) >> 3 & 1) != 0) {
        if (iVar34 == 3) {
          iVar34 = 4;
        }
        else if (iVar34 < 2) goto LAB_;
        if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 100) & 8) != 0) &&
            (lVar23 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 0x90),
            lVar23 != 0)) && (*(longlong *)(lVar23 + 0x758) != 0)) {
          uVar5 = *(undefined8 *)(lVar23 + 0x758);
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x10291b;
          func_0x(uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar17),iVar34);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
         ((2 < iVar34 &&
          (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar23 = *plVar29, lVar23 != 0)))))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102960;
        iVar16 = (*_DAT_)(lVar23,0x2000,2,auStack_23ec);
        if (iVar16 != 0) {
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x102982;
      func_0x(plVar29 + 0x13,iVar34);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1029a1;
        func_0x(plVar29,0,iVar34);
      }
      puVar19 = (uint *)((longlong)auStackX_1c + lVar17 + -0x18);
      *puVar19 = *puVar19 & 0xffff0000;
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
      goto code_r0x001029b1;
    }
  }
  if (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) == *(longlong *)(lVar23 + 0x2120)) goto LAB_;
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1008f1;
  cVar10 = func_0x(lVar23);
  if (cVar10 != '\0') goto LAB_;
  if (ppbVar22 == (byte **)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100903;
    ppbVar22 = (byte **)func_0x();
  }
  plVar29 = *(longlong **)(&stack0xfffffffffffffff8 + lVar17);
  lVar41 = *plVar29;
  if (*(short *)(lVar41 + 0x24) == 0) {
LAB_:
    uStack_2468 = *(undefined8 *)(lVar41 + 0x28);
    uStack_2460 = *(undefined2 *)(lVar41 + 0x30);
  }
  else {
    cVar10 = *(char *)(lVar41 + 1);
    if (cVar10 == '\v') {
      if (*(int *)(lVar41 + 0x18) != 99) {
LAB_:
        if (cVar10 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar10 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar41 + 0x18) != 99) goto LAB_;
    }
    uStack_24e0 = *(undefined4 *)(lVar41 + 0x20);
    uStack_24dc = *(undefined2 *)(lVar41 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100953;
    cVar10 = func_0x(&uStack_24e0);
    if (cVar10 == '\0') {
      plVar29 = *(longlong **)(&stack0xfffffffffffffff8 + lVar17);
      goto LAB_;
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100963;
    func_0x(lVar41,&uStack_2468);
    plVar29 = *(longlong **)(&stack0xfffffffffffffff8 + lVar17);
  }
  if (plVar29 != (longlong *)0x0) {
    iVar13 = (int)*(short *)((longlong)auStackX_1c + lVar17 + -0x18);
    if (((*(ushort *)((longlong)plVar29 + 0x62) & 0x400) == 0) || (iVar13 < 3)) {
      plVar7 = *(longlong **)(&stack0xfffffffffffffff8 + lVar17);
      if (((byte)*(undefined2 *)((longlong)plVar29 + 0x62) >> 3 & 1) != 0) {
        if (iVar13 == 3) {
          iVar13 = 4;
        }
        else if (iVar13 < 2) goto LAB_;
        if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 100) & 8) != 0) &&
            (lVar41 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar17) + 0x90),
            lVar41 != 0)) && (*(longlong *)(lVar41 + 0x758) != 0)) {
          uVar5 = *(undefined8 *)(lVar41 + 0x758);
          *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100a15;
          func_0x(uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar17),iVar13);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar7 + 100) & 8) != 0)) &&
         ((2 < iVar13 &&
          (((*(uint *)((longlong)plVar7 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar41 = *plVar7, lVar41 != 0)))))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100a5b;
        iVar15 = (*_DAT_)(lVar41,0x2000,2,auStack_23e4);
        if (iVar15 != 0) {
          LOCK();
          *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100a7e;
      func_0x(plVar7 + 0x13,iVar13);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100a9d;
        func_0x(plVar7,0,iVar13);
      }
      puVar19 = (uint *)((longlong)auStackX_1c + lVar17 + -0x18);
      *puVar19 = *puVar19 & 0xffff0000;
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1009ae;
      func_0x(&stack0xfffffffffffffff8 + lVar17);
    }
  }
  uStack_2430 = uStack_2468;
  uStack_2428 = uStack_2460;
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar17) = 0;
  uVar5 = *(undefined8 *)(lVar23 + 0x728);
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100ae8;
  func_0x(uVar5,&uStack_2430,4);
  param_2 = *(uint **)((longlong)auStackX_1c + lVar17 + 4);
  goto LAB_;
}

