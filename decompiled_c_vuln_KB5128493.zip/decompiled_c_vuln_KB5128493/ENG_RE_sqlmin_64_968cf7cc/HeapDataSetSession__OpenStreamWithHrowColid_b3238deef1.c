
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,ulonglong param_4,
                 uint param_5,longlong *param_6)

{
  byte **ppbVar1;
  ushort *puVar2;
  longlong *plVar3;
  code *pcVar4;
  undefined8 uVar5;
  byte bVar6;
  bool bVar7;
  undefined8 uVar8;
  int iVar9;
  uint *puVar10;
  short *psVar11;
  longlong lVar12;
  ulonglong *puVar13;
  longlong lVar14;
  byte *pbVar15;
  ulonglong uVar16;
  ushort uVar17;
  uint uVar18;
  longlong lVar19;
  ushort *puVar20;
  longlong lVar21;
  uint uVar22;
  uint uVar23;
  uint *puVar24;
  int iVar25;
  longlong unaff_GS_OFFSET;
  undefined8 auStack_1e0 [5];
  uint *puStack_1b8;
  uint auStack_1b0 [2];
  uint *puStack_1a8;
  uint auStack_1a0 [2];
  longlong *plStack_198;
  undefined4 auStack_190 [2];
  longlong alStack_188 [2];
  uint uStack_178;
  int iStack_174;
  ushort *puStack_170;
  byte bStack_168;
  uint uStack_164;
  uint uStack_160;
  byte bStack_15c;
  byte bStack_15b;
  byte bStack_15a;
  byte bStack_159;
  byte bStack_158;
  byte bStack_157;
  byte bStack_156;
  byte bStack_155;
  byte bStack_154;
  byte bStack_153;
  byte bStack_152;
  byte bStack_151;
  byte bStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_138;
  uint uStack_134;
  undefined4 uStack_130;
  undefined2 uStack_12c;
  uint *puStack_128;
  short *psStack_120;
  ushort uStack_118;
  ushort uStack_114;
  ushort uStack_110;
  ushort uStack_10c;
  uint uStack_108;
  uint uStack_100;
  uint *puStack_f8;
  ushort *puStack_f0;
  uint *puStack_e8;
  undefined4 uStack_e0;
  uint uStack_dc;
  uint uStack_d8;
  uint uStack_d4;
  int iStack_d0;
  uint uStack_c8;
  undefined4 uStack_c0;
  longlong lStack_b8;
  longlong lStack_b0;
  longlong lStack_a8;
  ulonglong uStack_a0;
  longlong lStack_98;
  longlong lStack_90;
  longlong lStack_88;
  ulonglong uStack_80;
  longlong lStack_78;
  undefined8 uStack_70;
  undefined8 uStack_58;
  ulonglong *puStack_50;
  ulonglong uStack_30;
  
  uStack_58 = 0xfffffffffffffffe;
  uStack_30 = _DAT_ ^ (ulonglong)&uStack_178;
  uStack_14c = 0;
  uStack_160 = param_5;
  uStack_80 = param_4;
  lStack_78 = param_1;
  uStack_70 = param_2;
  if (param_3 == (longlong *)0x0) {
    puStack_1b8 = (uint *)0x0;
    auStack_1e0[0] = 0x1000a0;
    (*_DAT_)(1,0x192b770,0x18ff128,0xbc0);
  }
  *param_6 = 0;
  auStack_1e0[0] = 0x1000ce;
  puVar10 = (uint *)func_0x
                              (*(undefined8 *)
                                (*(longlong *)(**(longlong **)(param_1 + 0x2e0) + 8) + 0x160),
                               param_4 & 0xffffffff);
  bStack_168 = *(byte *)((longlong)puVar10 + 0x21) & 4;
  puVar24 = (uint *)0x0;
  iVar25 = (bStack_168 != 0) + 1;
  auStack_1e0[0] = 0x1000fa;
  uStack_138 = iVar25;
  iVar9 = func_0x(param_3,0,0);
  if (iVar9 == 0x40f02) {
    if ((param_3[8] != _DAT_) || (param_3[9] != _DAT_)) {
      if ((*(byte *)(param_3 + 0x14) & 2) != 0) {
        auStack_1e0[0] = 0x100135;
        iVar9 = func_0x(param_3 + 0x15);
        if (iVar9 != 0) {
          *(longlong *)(param_3[6] + 0x30) = *(longlong *)(param_3[6] + 0x30) + -1;
        }
      }
      *(undefined *)(param_3 + 0x14) = 0;
      *(undefined4 *)((longlong)param_3 + 0x9c) = 0;
      *(undefined4 *)(param_3 + 0x17) = 0;
    }
    if ((param_3[0x58] != _DAT_) || (param_3[0x59] != _DAT_)) {
      if ((*(byte *)(param_3 + 100) & 2) != 0) {
        auStack_1e0[0] = 0x10018d;
        iVar9 = func_0x(param_3 + 0x65);
        if (iVar9 != 0) {
          *(longlong *)(param_3[0x56] + 0x30) = *(longlong *)(param_3[0x56] + 0x30) + -1;
        }
      }
      *(undefined *)(param_3 + 100) = 0;
      *(undefined4 *)((longlong)param_3 + 0x31c) = 0;
      *(undefined4 *)(param_3 + 0x67) = 0;
    }
    *(undefined4 *)((longlong)param_3 + 0x634) = 0;
    *(undefined4 *)((longlong)param_3 + 0x634) = 1;
    auStack_1e0[0] = 0x1001d7;
    (*_DAT_)(0xdc,0x12,0x19,1);
  }
  auStack_1e0[0] = 0x1001e5;
  psVar11 = (short *)func_0x(param_3,1,0);
  psStack_120 = psVar11;
  if (*psVar11 == 0) {
    auStack_1e0[0] = 0x1001ff;
    func_0x(psVar11 + 1);
  }
  else {
    auStack_1e0[0] = 0x100211;
    func_0x(psVar11 + 1,&uStack_130);
  }
  puVar20 = (ushort *)(psVar11 + 1);
  uStack_c0 = 0x1f9e;
  auStack_1e0[0] = 0x100225;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  bVar6 = *(byte *)(puVar10 + 8) >> 1;
  puStack_128 = puVar10;
  if (*psStack_120 != 0) {
    uStack_134 = 0;
    *(uint **)((longlong)auStack_1b0 + lVar12 + -8) = &uStack_134;
    *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100c5f;
    puVar24 = (uint *)func_0x(puVar20,puVar10);
    puStack_e8 = puVar24;
    if ((((*psStack_120 != 0) &&
         (plVar3 = *(longlong **)(psStack_120 + 8), plVar3 != (longlong *)0x0)) && (*plVar3 != 0))
       && (((*(byte *)((longlong)puVar10 + 6) & 8) == 0 && ((uStack_134 & 1) == 0)))) {
      if ((puVar24 == (uint *)0x0) || (puVar24 == (uint *)0x14ff794)) {
        puVar24 = (uint *)0x0;
        uStack_178 = 0;
        puStack_e8 = puVar24;
      }
      else {
        *(uint *)((longlong)auStack_1a0 + lVar12) = uStack_134;
        *(uint **)((longlong)&puStack_1a8 + lVar12) = &uStack_178;
        *(undefined4 *)((longlong)auStack_1b0 + lVar12) = 0x1f9e;
        *(longlong *)((longlong)auStack_1b0 + lVar12 + -8) = (longlong)&uStack_178 + lVar12;
        uVar18 = uStack_178;
        *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100cc7;
        puVar24 = (uint *)func_0x(plVar3,puVar10,puVar24,uVar18);
        puStack_e8 = puVar24;
      }
    }
    goto LAB_;
  }
  uVar18 = *puVar10;
  puStack_170 = puVar20;
  if ((uVar18 & 0xc0000000) == 0x80000000) {
    *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100c20;
    iVar9 = func_0x(puVar20);
    if (iVar9 != 0) {
      *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100c3f;
      puVar24 = (uint *)func_0x(psVar11 + 0x15,puVar10,&uStack_178,&puStack_f8);
      goto LAB_;
    }
LAB_:
    uStack_178 = 0;
    goto LAB_;
  }
  bVar7 = true;
  if (((bVar6 & 1) == 0) && ((*(byte *)((longlong)puVar10 + 6) & 0x10) == 0)) {
    uStack_164 = 0;
LAB_:
    if (((bVar6 & 1) != 0) && (uStack_164 != 0)) goto LAB_;
    if ((!bVar7) && ((*(byte *)((longlong)puVar10 + 6) & 0x10) != 0)) {
      puVar24 = *(uint **)(puVar10 + 2) + 1;
      uStack_178 = **(uint **)(puVar10 + 2);
      goto LAB_;
    }
  }
  else {
    pbVar15 = *(byte **)(psVar11 + 4);
    if ((*pbVar15 & 0x10) == 0) {
      bStack_15c = *pbVar15 & 0xe;
      if ((1 << bStack_15c & 0x1105U) == 0) {
        bVar7 = true;
        uStack_164 = 0;
      }
      else {
        bVar7 = false;
        uStack_164 = ~(uint)(*(ushort *)((longlong)puVar10 + 6) >> 4) & 1;
      }
      goto LAB_;
    }
    uVar23 = *(uint *)(psVar11 + 8);
    if ((int)uVar23 <= (int)uVar18) {
LAB_:
      uStack_164 = ~(uint)(*(ushort *)((longlong)puVar10 + 6) >> 4) & 1;
      bVar7 = false;
      goto LAB_;
    }
    if (*(ushort *)(pbVar15 + uVar23) < *(ushort *)(puVar10 + 1)) goto LAB_;
    if ((bVar6 & 1) != 0) {
      uStack_c8 = *(ushort *)(puVar10 + 1) - 1;
      bStack_15b = pbVar15[(ulonglong)(uStack_c8 >> 3) + (ulonglong)uVar23 + 2] >>
                   ((byte)uStack_c8 & 7);
      uStack_164 = bStack_15b & 1;
      goto LAB_;
    }
    uStack_164 = 0;
    uStack_e0 = 1;
  }
  if (-1 < (int)uVar18) {
    uVar17 = *(ushort *)((longlong)puVar10 + 6);
    if ((uVar17 & 8) != 0) {
      puVar24 = (uint *)0x14ff794;
      if ((*(byte *)((longlong)(int)uVar18 + *(longlong *)(psVar11 + 4)) &
          (byte)(1 << ((byte)uVar17 & 7))) == 0) {
        puVar24 = (uint *)0x14ffdb8;
      }
      uStack_178 = 1;
      goto LAB_;
    }
    if ((uVar17 & 0x10) != 0) {
      pbVar15 = *(byte **)(psVar11 + 4);
      if ((*pbVar15 & 0x10) == 0) {
        if ((1 << (*pbVar15 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar24 = *(uint **)(puVar10 + 2) + 1;
          uStack_178 = **(uint **)(puVar10 + 2);
          if (uStack_178 != 0x1f9e) {
            *(undefined8 *)((longlong)auStack_1b0 + lVar12 + -8) = 0;
            *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x1003d6;
            (*_DAT_)(1,0x1928ac8,0x19274c8,0x381);
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(psVar11 + 8) <= (int)uVar18) ||
              (*(ushort *)(pbVar15 + *(uint *)(psVar11 + 8)) < *(ushort *)(puVar10 + 1)))
      goto LAB_;
    }
    uStack_178 = 0x1f9e;
    puVar24 = (uint *)((longlong)(int)*puVar10 + *(longlong *)(psVar11 + 4));
    goto LAB_;
  }
  uStack_148 = (uint *)(psVar11 + 2);
  if (*uStack_148 == 0) {
    iStack_174 = 0;
    *puVar20 = 0;
    uVar18 = *(uint *)(psVar11 + 8);
    puVar24 = (uint *)(psVar11 + 10);
    *puVar24 = uVar18;
    ppbVar1 = (byte **)(psVar11 + 4);
    pbVar15 = *ppbVar1;
    if ((*pbVar15 & 0x10) != 0) {
      uVar18 = uVar18 + (*(ushort *)(pbVar15 + *(uint *)(psVar11 + 8)) + 7 >> 3) + 2;
      *puVar24 = uVar18;
      pbVar15 = *ppbVar1;
    }
    puStack_f8 = puVar24;
    if ((*pbVar15 & 0x20) == 0) {
      *uStack_148 = uVar18;
      psVar11[0xe] = 0;
      *(uint *)(psVar11 + 0xc) = *puVar24;
    }
    else {
      puStack_f0 = (ushort *)(pbVar15 + uVar18);
      uVar17 = *puStack_f0;
      puVar2 = (ushort *)(psVar11 + 0xe);
      *puVar2 = uVar17;
      if (uVar17 == 0) {
        iStack_174 = 1;
        if ((DAT_ != '\0') || (bStack_15a = DAT_, (DAT_ & 1) != 0)) {
          lVar19 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
          if (lVar19 == 0) {
            lStack_b8 = 0;
          }
          else {
            lStack_b8 = *(longlong *)(lVar19 + 0x60);
            if ((lStack_b8 != 0) && (*(char *)(lStack_b8 + 0x499) != '\0')) {
              if ((DAT_ == '\0') && (bStack_159 = DAT_ >> 1, (bStack_159 & 1) == 0))
              {
                *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100512;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)((longlong)auStack_1b0 + lVar12 + -8) = 0;
                *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100538;
                (*_DAT_)(1,0x177ad58,0x189aa28,0x80f);
              }
            }
          }
        }
        puVar20 = puStack_170;
        pbVar15 = *ppbVar1;
        *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100553;
        func_0x(pbVar15,3);
      }
      uVar18 = *puVar24 + (*puVar2 + 1) * 2;
      puVar10 = (uint *)(puVar20 + 0xb);
      *puVar10 = uVar18;
      if (0x1f9e < uVar18) {
        iStack_174 = iStack_174 + 1;
        if ((DAT_ != '\0') || (bStack_158 = DAT_, (DAT_ & 1) != 0)) {
          lVar19 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
          puVar20 = puStack_170;
          if (lVar19 == 0) {
            lStack_b0 = 0;
          }
          else {
            lStack_b0 = *(longlong *)(lVar19 + 0x60);
            if ((lStack_b0 != 0) && (*(char *)(lStack_b0 + 0x499) != '\0')) {
              if ((DAT_ == '\0') && (bStack_157 = DAT_ >> 1, (bStack_157 & 1) == 0))
              {
                *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100600;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                puVar20 = puStack_170;
              }
              else {
                *(undefined8 *)((longlong)auStack_1b0 + lVar12 + -8) = 0;
                *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100626;
                (*_DAT_)(1,0x177ad58,0x189aa28,0x816);
                puVar20 = puStack_170;
              }
            }
          }
        }
        pbVar15 = *ppbVar1;
        *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100641;
        func_0x(pbVar15,4);
      }
      uStack_118 = puStack_f0[*puVar2];
      *uStack_148 = uStack_118 & 0x7fff;
      if ((uStack_118 & 0x7fff) < *puVar10) {
        iStack_174 = iStack_174 + 1;
        if ((DAT_ != '\0') || (bStack_156 = DAT_, (DAT_ & 1) != 0)) {
          lVar19 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
          puVar20 = puStack_170;
          if (lVar19 == 0) {
            lStack_a8 = 0;
          }
          else {
            lStack_a8 = *(longlong *)(lVar19 + 0x60);
            if ((lStack_a8 != 0) && (*(char *)(lStack_a8 + 0x499) != '\0')) {
              if ((DAT_ == '\0') && (bStack_155 = DAT_ >> 1, (bStack_155 & 1) == 0))
              {
                *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x1006f8;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                puVar20 = puStack_170;
              }
              else {
                *(undefined8 *)((longlong)auStack_1b0 + lVar12 + -8) = 0;
                *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x10071e;
                (*_DAT_)(1,0x177ad58,0x189aa28,0x81d);
                puVar20 = puStack_170;
              }
            }
          }
        }
        pbVar15 = *ppbVar1;
        *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100739;
        func_0x(pbVar15,4);
      }
      do {
        uVar17 = *puVar2;
        if (-1 < (short)puStack_f0[(ulonglong)(uVar17 - 1) + 1]) break;
        pbVar15 = *ppbVar1;
        if (uVar17 == 1) {
          uVar18 = *puVar10;
          uVar23 = uVar18;
        }
        else {
          uStack_114 = *(ushort *)
                        (pbVar15 + (longlong)(int)(uVar17 - 2) * 2 + (ulonglong)*puVar24 + 2);
          uVar18 = uStack_114 & 0x7fff;
          uVar23 = *puVar10;
        }
        uStack_110 = *(ushort *)
                      (pbVar15 + (longlong)(int)(uVar17 - 1) * 2 + (ulonglong)*puVar24 + 2);
        uStack_d8 = uStack_110 & 0x7fff;
        uStack_dc = uVar18;
        if ((uVar18 < uVar23) || (uStack_d8 < uVar18)) {
          *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x1007c3;
          func_0x(pbVar15,7);
          uVar23 = *puVar10;
        }
        uStack_d4 = uVar18;
        if ((uVar18 < uVar23) || (*uStack_148 < uVar18)) {
          iStack_174 = iStack_174 + 1;
          iVar25 = uStack_138;
          goto LAB_;
        }
        uStack_10c = *(ushort *)(*ppbVar1 + uVar18);
        if (uStack_10c == 5) {
          *puVar20 = *puVar20 | 2;
          *puVar2 = *puVar2 - 1;
          puVar20[0x14] = (ushort)uVar18;
          lVar19 = (ulonglong)(uVar18 & 0xffff) + *(longlong *)(puVar20 + 3);
          uVar17 = *(ushort *)(lVar19 + 2);
          puVar20[0x15] = puVar20[0x15] & 0xc7ff;
          if ((uVar17 & 0x4000) != 0) {
            puVar20[0x15] = puVar20[0x15] | uVar17 & 0x3800;
          }
          puVar20[0x15] = (puVar20[0x15] ^ *(ushort *)(lVar19 + 2)) & 0x7ff ^ puVar20[0x15];
          break;
        }
        if (uStack_10c < 0x400) break;
        *puVar20 = *puVar20 | 1;
        *puVar2 = *puVar2 - 1;
        puVar24 = puStack_f8;
      } while (*puVar2 != 0);
    }
    puVar24 = uStack_148;
    if ((**ppbVar1 & 0x40) == 0) {
      *(undefined4 *)(puVar20 + 0x12) = 0;
    }
    else {
      *(uint *)(puVar20 + 0x12) = *uStack_148;
      *uStack_148 = *uStack_148 + 0xe;
      *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x1008af;
      puVar13 = (ulonglong *)func_0x(puVar20);
      uStack_a0 = *puVar13;
      uVar17 = (ushort)(uStack_a0 >> 0x30);
      if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
        if ((uStack_a0 & 0x4000000000000000) == 0) {
          uVar17 = uVar17 & 0xdfff;
        }
        else {
          uVar17 = uVar17 | 0x2000;
        }
      }
      iVar25 = 0;
      if (uVar17 == 0xfffc) {
        puStack_50 = &uStack_a0;
        iVar25 = (int)((uStack_a0 >> 0x20 & 0xffff) >> 5);
        iStack_d0 = iVar25;
      }
      *puVar24 = *puVar24 + iVar25;
    }
    uVar18 = *puVar24;
    if ((*(byte **)(puVar20 + 0xe) != (byte *)0x0) &&
       (*(byte **)(puVar20 + 0xe) < *ppbVar1 + uVar18)) {
      iStack_174 = iStack_174 + 1;
      if ((DAT_ != '\0') || (bStack_154 = DAT_, (DAT_ & 1) != 0)) {
        lVar19 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
        puVar20 = puStack_170;
        if (lVar19 == 0) {
          lStack_98 = 0;
        }
        else {
          lStack_98 = *(longlong *)(lVar19 + 0x60);
          if ((lStack_98 != 0) && (*(char *)(lStack_98 + 0x499) != '\0')) {
            if ((DAT_ == '\0') && (bStack_153 = DAT_ >> 1, (bStack_153 & 1) == 0)) {
              *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x1009ec;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
              puVar20 = puStack_170;
            }
            else {
              *(undefined8 *)((longlong)auStack_1b0 + lVar12 + -8) = 0;
              *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100a10;
              (*_DAT_)(1,0x177ad58,0x189aa28,0x877);
              puVar20 = puStack_170;
            }
          }
        }
      }
      pbVar15 = *ppbVar1;
      *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100a2b;
      func_0x(pbVar15,0x12);
      uVar18 = *puVar24;
    }
    iVar25 = uStack_138;
    if (0x3f3b < uVar18 - 1) {
      iStack_174 = iStack_174 + 1;
      if ((DAT_ != '\0') || (bStack_152 = DAT_, (DAT_ & 1) != 0)) {
        lVar19 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
        puVar20 = puStack_170;
        if (lVar19 == 0) {
          lStack_90 = 0;
        }
        else {
          lStack_90 = *(longlong *)(lVar19 + 0x60);
          if ((lStack_90 != 0) && (*(char *)(lStack_90 + 0x499) != '\0')) {
            if ((DAT_ == '\0') && (bStack_151 = DAT_ >> 1, (bStack_151 & 1) == 0)) {
              *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100acb;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              puVar20 = puStack_170;
            }
            else {
              *(undefined8 *)((longlong)auStack_1b0 + lVar12 + -8) = 0;
              *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100aef;
              (*_DAT_)(1,0x177ad58,0x189aa28,0x87c);
              puVar20 = puStack_170;
            }
          }
        }
      }
      pbVar15 = *ppbVar1;
      *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100b0a;
      func_0x(pbVar15,5);
      iVar25 = uStack_138;
    }
  }
LAB_:
  uStack_138 = CONCAT22(uStack_138._2_2_,-*(short *)puStack_128);
  if ((*(byte *)((longlong)puStack_128 + 6) & 0x10) == 0) {
LAB_:
    uVar18 = (uint)-*(short *)puStack_128;
    if (puVar20[0xd] < uVar18) {
      uStack_178 = 0;
      puVar24 = *(uint **)(puVar20 + 3);
    }
    else {
      plVar3 = (longlong *)(puVar20 + 3);
      lVar19 = *plVar3;
      lStack_88 = (ulonglong)*(uint *)(puVar20 + 9) + lVar19;
      if (uVar18 == 1) {
        uVar23 = *(uint *)(puVar20 + 0xb);
      }
      else {
        uVar23 = *(ushort *)(lStack_88 + 2 + (longlong)(int)(uVar18 - 2) * 2) & 0x7fff;
        lVar19 = *plVar3;
        puVar20 = puStack_170;
      }
      uVar22 = *(ushort *)(lStack_88 + 2 + (longlong)(int)(uVar18 - 1) * 2) & 0x7fff;
      uStack_100 = uVar18;
      if ((uVar23 < *(uint *)(puVar20 + 0xb)) || (uVar22 < uVar23)) {
        *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100bff;
        func_0x(lVar19,7);
      }
      puVar24 = (uint *)((ulonglong)uVar23 + *plVar3);
      uStack_178 = uVar22 - uVar23;
    }
  }
  else {
    pbVar15 = *(byte **)(puVar20 + 3);
    if ((*pbVar15 & 0x10) == 0) {
      bStack_150 = *pbVar15 & 0xe;
      uVar18 = 1 << bStack_150 & 0x1105;
      uStack_108 = (uint)(uVar18 == 0);
      if (uVar18 == 0) goto LAB_;
    }
    else if (((int)*puStack_128 < (int)*(uint *)(puVar20 + 7)) &&
            (*(ushort *)(puStack_128 + 1) <= *(ushort *)(pbVar15 + *(uint *)(puVar20 + 7)))) {
      uStack_108 = 1;
      goto LAB_;
    }
    puVar24 = *(uint **)(puStack_128 + 2) + 1;
    uStack_178 = **(uint **)(puStack_128 + 2);
  }
LAB_:
  psVar11 = psStack_120;
  puVar10 = puStack_128;
  if (puVar24 == (uint *)0x0) {
    uStack_160 = uStack_160 | 8;
  }
  else {
    *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100cf3;
    iVar9 = func_0x(psVar11,puVar10);
    if (iVar9 == 0) {
      uStack_160 = uStack_160 | 0x200;
    }
  }
  *(undefined8 *)((longlong)auStack_1e0 + lVar12) = 0x100d1d;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  lVar19 = (longlong)&uStack_178 + lVar14 + lVar12;
  *(undefined8 *)((longlong)auStack_1e0 + lVar14 + lVar12) = 0x100d33;
  func_0x(lVar19);
  pcVar4 = *(code **)(*param_3 + 8);
  *(undefined8 *)((longlong)auStack_1e0 + lVar14 + lVar12) = 0x100d3c;
  (*pcVar4)(param_3);
  *(undefined8 **)((longlong)alStack_188 + lVar14 + lVar12) = &uStack_148;
  *(undefined4 *)((longlong)auStack_190 + lVar14 + lVar12) = 0;
  *(longlong **)((longlong)&plStack_198 + lVar14 + lVar12) = param_6;
  *(uint *)((longlong)auStack_1a0 + lVar14 + lVar12) = uStack_160;
  uVar16 = uStack_80;
  *(ulonglong *)((longlong)&puStack_1a8 + lVar14 + lVar12) = uStack_80;
  *(uint *)((longlong)auStack_1b0 + lVar14 + lVar12) = uStack_178;
  *(longlong *)((longlong)auStack_1b0 + lVar14 + lVar12 + -8) = lVar19;
  uVar8 = uStack_70;
  lVar19 = lStack_78;
  uVar5 = *(undefined8 *)(lStack_78 + 0x1e8);
  *(undefined8 *)((longlong)auStack_1e0 + lVar14 + lVar12) = 0x100da1;
  uStack_14c = func_0x(lVar19,uVar8,uVar5,iVar25);
  lVar19 = *param_6;
  if (bStack_168 == 0) {
    *(int *)((longlong)param_3 + 0xc) = *(int *)((longlong)param_3 + 0xc) + 1;
    *(longlong **)(lVar19 + 0x150) = param_3;
    *(undefined4 *)(lVar19 + 0x158) = 2;
  }
  else {
    *(longlong **)(lVar19 + 0x38) = param_3;
    *(undefined4 *)(lVar19 + 0x40) = 2;
    *(ulonglong *)(lVar19 + 0x48) = uVar16;
  }
  lVar21 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar19 = *(longlong *)(lVar21 + 0x100);
  if (lVar19 == 0) {
    *(undefined8 *)((longlong)auStack_1e0 + lVar14 + lVar12) = 0x100e04;
    (*_DAT_)();
    lVar19 = *(longlong *)(lVar21 + 0x100);
  }
  if (*(int *)(lVar19 + 0x22c) != 0) {
    *(undefined8 *)((longlong)auStack_1e0 + lVar14 + lVar12) = 0x100e1a;
    (*_DAT_)();
  }
  uVar16 = uStack_30 ^ (ulonglong)&uStack_178;
  *(undefined8 *)((longlong)auStack_1e0 + lVar14 + lVar12) = 0x100e2c;
  func_0x(uVar16);
  return;
}

