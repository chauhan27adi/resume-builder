
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2,int param_3,longlong param_4,undefined8 param_5
                 ,undefined4 param_6,longlong *param_7,longlong *param_8)

{
  uint *puVar1;
  byte *pbVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  int *piVar7;
  undefined auVar8 [16];
  undefined4 uVar9;
  undefined4 uVar10;
  ulonglong uVar11;
  char cVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  longlong lVar16;
  longlong lVar17;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar18;
  undefined8 unaff_RBX;
  int iVar19;
  undefined8 uVar20;
  longlong lVar21;
  ulonglong uVar22;
  ulonglong uVar23;
  undefined4 auStackX_8 [2];
  undefined8 uStackX_10;
  undefined auStackX_18 [16];
  longlong lStack_2c08;
  int iStack_2c00;
  ulonglong uStack_2bf0;
  undefined8 uStack_2be8;
  undefined2 uStack_2be0;
  undefined2 auStack_2bd8 [2];
  undefined4 uStack_2bd4;
  undefined8 uStack_2bd0;
  undefined8 uStack_2bc8;
  undefined8 uStack_2bba;
  undefined8 uStack_2bb0;
  int iStack_2ba0;
  undefined4 uStack_2b9c;
  undefined2 uStack_2b98;
  undefined4 uStack_2b94;
  undefined2 uStack_2b90;
  longlong *plStack_2b88;
  ulonglong uStack_2b80;
  longlong *plStack_2b78;
  undefined4 uStack_2b70;
  undefined4 uStack_2b68;
  undefined4 uStack_2b64;
  undefined4 uStack_2b60;
  undefined4 uStack_2b5c;
  undefined auStack_2b58 [16];
  longlong lStack_2b48;
  undefined8 uStack_2b40;
  undefined2 uStack_2b38;
  undefined4 uStack_2b34;
  byte *pbStack_2b30;
  undefined8 uStack_2b28;
  undefined8 uStack_2b1a;
  undefined2 uStack_2b12;
  undefined2 uStack_2b10;
  undefined6 uStack_2b0e;
  undefined4 uStack_2b04;
  undefined auStack_2b00 [16];
  undefined auStack_2af0 [8];
  undefined8 uStack_2ae8;
  undefined8 uStack_2ae0;
  undefined6 uStack_2ad8;
  undefined2 uStack_2ad2;
  undefined6 uStack_2ad0;
  undefined2 uStack_2aca;
  undefined2 uStack_2ac8;
  undefined6 uStack_2ac6;
  undefined8 uStack_2ac0;
  short *psStack_2ab8;
  short *psStack_2ab0;
  short sStack_2aa8;
  undefined6 uStack_2aa6;
  undefined auStack_2aa0 [10];
  undefined auStack_2a96 [6];
  undefined8 uStack_2a90;
  undefined8 uStack_2a88;
  undefined8 uStack_2a80;
  undefined auStack_2a78 [16];
  undefined auStack_2a68 [16];
  undefined4 uStack_2a58;
  undefined8 uStack_2a54;
  uint uStack_2a4c;
  undefined auStack_2a48 [20];
  undefined uStack_2a34;
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  iStack_2ba0 = param_3;
  lVar16 = func_0x();
  uVar20 = param_5;
  lVar16 = -lVar16;
  uStack_2b40 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002c60 + lVar16) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar16);
  *(longlong *)((longlong)&param_7 + lVar16) = param_1;
  *(undefined8 *)((longlong)&param_8 + lVar16) = param_5;
  plStack_2b78 = param_7;
  plStack_2b88 = param_8;
  iStack_2c00 = 0;
  uStack_2b68 = _DAT_;
  uStack_2b64 = uRam0000000001effa2c;
  uStack_2b60 = _DAT_;
  uStack_2b5c = uRam0000000001effa34;
  *(undefined8 *)((longlong)&param_5 + lVar16) = 0;
  auStack_2bd8[0] = 0xffff;
  uStack_2bd0 = 0;
  uStack_2bd4 = 0;
  uStack_2bba = 0;
  uStack_2bb0 = 0;
  uStack_2bc8 = 0;
  auStack_2b58 = ZEXT816(0);
  lStack_2b48 = 0;
  if ((longlong)param_2 < 2) {
    param_2 = 8;
  }
  for (lVar17 = *(longlong *)(param_1 + 0x348);
      (lStack_2c08 = param_4, uStack_2b80 = param_2, lVar17 != param_1 + 0x340 && (lVar17 != 0));
      lVar17 = *(longlong *)(lVar17 + 8)) {
    lVar18 = *(longlong *)(lVar17 + 0x10);
    if (*(int *)(lVar18 + 8) == 0) {
      if ((*(byte *)(lVar17 + 0x18) & 1) != 0) {
        *(undefined8 *)(lVar18 + 0x10) = *(undefined8 *)(param_1 + 0x370);
        *(undefined4 *)(lVar18 + 4) = 2;
        *(uint *)(lVar17 + 0x18) = *(uint *)(lVar17 + 0x18) & 0xfffffffe;
        lVar18 = *(longlong *)(lVar17 + 0x10);
      }
      *(int *)(lVar18 + 8) = *(int *)(lVar18 + 8) + 1;
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100126;
      func_0x((longlong)&param_5 + lVar16);
      goto LAB_;
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100130;
  func_0x(param_1 + 0x340);
  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10013d;
  func_0x((longlong)&param_5 + lVar16);
LAB_:
  do {
    uVar22 = 0;
    if (0xf < iStack_2c00) {
LAB_:
      piVar7 = *(int **)((longlong)&param_5 + lVar16);
      if (piVar7 != (int *)0x0) {
        piVar3 = piVar7 + 2;
        *piVar3 = *piVar3 + -1;
        if (*piVar3 == 0) {
          if (*piVar7 == 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101a94;
            func_0x(piVar7,1);
          }
          else {
            lVar17 = *(longlong *)((longlong)&param_5 + lVar16);
            puVar1 = (uint *)(lVar17 + 4);
            if ((*puVar1 & 4) != 0) {
              if ((*puVar1 & 0x10) == 0) {
                lVar18 = *(longlong *)(lVar17 + 0x48);
                if ((lVar18 != CONCAT44(uRam0000000001effa2c,_DAT_)) ||
                   (*(longlong *)(lVar17 + 0x50) != CONCAT44(uRam0000000001effa34,_DAT_))) {
                  *(undefined4 *)(lVar18 + 0x48) = 0;
                  *(undefined8 *)(lVar18 + 0x50) = 0;
                  *(undefined *)(lVar17 + 0x3e) = 0;
                  *(undefined8 *)(lVar17 + 0x30) = 0;
                  *(undefined2 *)(lVar17 + 0x3c) = 0;
                }
                uVar10 = uRam0000000001effa34;
                uVar9 = _DAT_;
                uVar4 = uRam0000000001effa2c;
                *(undefined4 *)(lVar17 + 0x48) = _DAT_;
                *(undefined4 *)(lVar17 + 0x4c) = uVar4;
                *(undefined4 *)(lVar17 + 0x50) = uVar9;
                *(undefined4 *)(lVar17 + 0x54) = uVar10;
                *(undefined8 *)(lVar17 + 0x58) = 0;
              }
              uVar20 = *(undefined8 *)
                        (*(longlong *)(*(longlong *)((longlong)&param_5 + lVar16) + 0x18) + 0x10);
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101afb;
              func_0x(uVar20,*(longlong *)((longlong)&param_5 + lVar16) + 0x20);
              *puVar1 = *puVar1 & 0xffffff6b;
            }
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101b12;
      func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar16));
      return;
    }
    uStack_2a34 = 0;
    iStack_2c00 = iStack_2c00 + 1;
    *(undefined4 *)((longlong)&param_6 + lVar16) = 0;
    uStack_2bf0 = 0;
    lVar17 = *(longlong *)(param_1 + 0x2e0);
    auStackX_18[lVar16] = 0;
    *(undefined8 *)((longlong)&uStackX_10 + lVar16) = 0;
    *(undefined4 *)((longlong)auStackX_8 + lVar16) = param_6;
    *(undefined8 *)(auStackX_18 + lVar16 + -0x18) = uVar20;
    *(undefined8 *)(&stack0xfffffffffffffff8 + lVar16) = 0;
    *(undefined **)(&stack0xfffffffffffffff0 + lVar16) = auStack_2a48;
    *(undefined4 **)(&stack0xffffffffffffffe8 + lVar16) = &uStack_2b68;
    uVar5 = *(undefined8 *)(lVar17 + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1001b7;
    func_0x(uVar5,param_4,0,3);
  } while ((longlong)param_2 < 1);
  lVar17 = *(longlong *)((longlong)&param_5 + lVar16);
  uVar23 = uVar22;
  do {
    lVar18 = *(longlong *)((longlong)&param_5 + lVar16);
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1001d2;
    func_0x(lVar18);
    if ((*(longlong **)(lVar17 + 0x30) == (longlong *)0x0) ||
       (lVar21 = **(longlong **)(lVar17 + 0x30), lVar21 == 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101a54;
      func_0x(*(undefined8 *)((longlong)&param_5 + lVar16));
LAB_:
      *(undefined8 *)(lStack_2c08 + 0x10) = 2;
      *(undefined4 *)(lStack_2c08 + 8) = 0;
      goto LAB_;
    }
    param_4 = lStack_2c08;
    if (*(short *)(lVar21 + 0x3a) != 0) {
      uStack_2b9c = *(undefined4 *)(lVar21 + 0x20);
      uStack_2b98 = *(undefined2 *)(lVar21 + 0x24);
      iVar14 = 6;
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100211;
      func_0x(lVar18);
      lVar21 = *(longlong *)(param_1 + 0x2e0);
      uStack_2a88 = 0;
      uStack_2a4c = uStack_2a4c & 0xfffffff8;
      uStack_2a54 = 0;
      uStack_2a80 = 0;
      auStack_2a78 = ZEXT816(0);
      auStack_2a68 = ZEXT816(0);
      uStack_2a58 = 0;
      *(undefined8 **)(&stack0xfffffffffffffff0 + lVar16) = &uStack_2a88;
      *(undefined4 **)(&stack0xffffffffffffffe8 + lVar16) = &uStack_2b9c;
      uVar20 = *(undefined8 *)(lVar21 + 0x10);
      uVar5 = *(undefined8 *)(param_1 + 0x10);
      uVar6 = *(undefined8 *)(param_1 + 0x18);
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100281;
      iVar13 = func_0x(uVar6,uVar5,uVar20,param_1 + 0x340);
      iVar19 = uStack_2a4c << 0x1d;
      if (iVar13 == 0) {
LAB_:
        if (iVar19 < 0) {
          *plStack_2b88 = *plStack_2b88 + 1;
          param_1 = *(longlong *)((longlong)&param_7 + lVar16);
          uVar20 = *(undefined8 *)((longlong)&param_8 + lVar16);
          goto LAB_;
        }
        if (iVar14 != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101966;
          func_0x(*(undefined8 *)((longlong)&param_5 + lVar16));
          param_1 = *(longlong *)((longlong)&param_7 + lVar16);
          uVar20 = *(undefined8 *)((longlong)&param_8 + lVar16);
          goto LAB_;
        }
      }
      else {
        iVar14 = 6;
        if (iVar19 < 0) {
LAB_:
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1002f5;
          func_0x(*(undefined8 *)((longlong)&param_5 + lVar16));
          goto LAB_;
        }
        *(undefined4 *)(lVar18 + 100) = 3;
        uVar20 = *(undefined8 *)(*(longlong *)(lVar18 + 0x18) + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1002b7;
        iVar14 = func_0x(uVar20,lVar18 + 0x20,3);
        if (iVar14 != 0) {
          *(uint *)(lVar18 + 0xa0) = *(uint *)(lVar18 + 0xa0) | 0x10;
        }
        lVar21 = *(longlong *)((longlong)&param_5 + lVar16);
        uVar20 = *(undefined8 *)(*(longlong *)(lVar18 + 0x18) + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1002e0;
        func_0x(uVar20,lVar18 + 0x20,lVar21 + 0x60,lVar17 + 0x30);
        puVar1 = (uint *)(lVar21 + 4);
        *puVar1 = *puVar1 & 0xffffffef;
        if (iVar14 != 0) goto LAB_;
      }
      param_1 = *(longlong *)((longlong)&param_7 + lVar16);
      uVar23 = (ulonglong)*(uint *)((longlong)&param_6 + lVar16);
      lVar21 = 0;
      uVar22 = uStack_2bf0;
      if (*(longlong **)(lVar17 + 0x30) != (longlong *)0x0) {
        lVar21 = **(longlong **)(lVar17 + 0x30);
      }
    }
    uVar11 = uStack_2b80;
    if (*(short *)(lVar21 + 0x16) == 0) {
      lVar18 = *(longlong *)(param_1 + 0x108);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar16) = 0;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) = 0;
      uVar4 = *(undefined4 *)(lVar18 + 0xa8);
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10035a;
      iVar14 = func_0x(*(undefined8 *)((longlong)&param_5 + lVar16),5,uVar4,0);
      if (iVar14 != 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100373;
        iVar14 = func_0x(param_1);
        if (iVar14 == 0) {
          *plStack_2b88 = *plStack_2b88 + 1;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100388;
        func_0x(*(undefined8 *)((longlong)&param_5 + lVar16));
        uVar20 = *(undefined8 *)((longlong)&param_8 + lVar16);
        goto LAB_;
      }
    }
    else {
      uVar22 = uVar22 + 1;
      if ((uVar22 != 1) && (uVar22 == 2)) {
        uStack_2b38 = 0xffff;
        pbStack_2b30 = (byte *)0x0;
        uStack_2b34 = 0;
        uStack_2b1a = 0;
        uStack_2b10 = 0;
        uStack_2b0e = 0;
        uStack_2b28 = 0;
        uStack_2b04 = 0;
        if (-1 < *(char *)(lVar21 + 2)) goto LAB_;
        pbVar2 = (byte *)(lVar21 + 0x60);
        uStack_2ad8 = 0;
        uStack_2aca = 0;
        uStack_2ac0 = 0;
        psStack_2ab0 = (short *)0x0;
        sStack_2aa8 = 0;
        uStack_2aa6 = 0;
        auStack_2b00._8_8_ = 0;
        stack0xffffffffffffd512 = SUB1614(ZEXT816(0),2);
        auStack_2af0._0_2_ = 0xffff;
        uStack_2ae8 = 0;
        uStack_2ad2 = 0;
        uStack_2ad0 = 0;
        uStack_2ac8 = 0;
        uStack_2ac6 = 0;
        uStack_2ae0 = 0;
        psStack_2ab8 = (short *)0x0;
        _auStack_2aa0 = ZEXT812(0);
        auStack_2a96._2_4_ = 0;
        uStack_2a90 = 0;
        lVar17 = 0;
        if (*(short *)(lVar21 + 0x24) == 0) {
LAB_:
          auStack_2b00._8_8_ = lVar17;
          uStack_2be8 = *(undefined8 *)(lVar21 + 0x28);
          uStack_2be0 = *(undefined2 *)(lVar21 + 0x30);
        }
        else {
          cVar12 = *(char *)(lVar21 + 1);
          if (cVar12 == '\v') {
            if (*(int *)(lVar21 + 0x18) != 99) {
LAB_:
              if (cVar12 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar12 != '\b') goto LAB_;
LAB_:
            lVar17 = auStack_2b00._8_8_;
            if (*(int *)(lVar21 + 0x18) != 99) goto LAB_;
          }
          uStack_2b94 = *(undefined4 *)(lVar21 + 0x20);
          uStack_2b90 = *(undefined2 *)(lVar21 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1004ce;
          auStack_2b00 = ZEXT816(0);
          cVar12 = func_0x(&uStack_2b94);
          lVar17 = auStack_2b00._8_8_;
          if (cVar12 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1004de;
          func_0x(lVar21,&uStack_2be8);
        }
        auStack_2b00._0_8_ = pbVar2;
        auStack_2aa0._8_2_ = uStack_2be0;
        auStack_2aa0._0_8_ = uStack_2be8;
        auStack_2a96._2_4_ = *(undefined4 *)(lVar21 + 0x20);
        lVar17 = (ulonglong)*pbVar2 * 6;
        uStack_2b70 = *(undefined4 *)(lVar17 + 0x15dbf80);
        uVar22 = (ulonglong)*(short *)(lVar17 + 0x15dbf84);
        auStack_2af0._0_2_ = 0xffff;
        auStack_2af0 = (undefined  [8])((ulonglong)auStack_2af0 & 0xffffffff);
        uStack_2ae8 = 0;
        uStack_2ad2 = 0;
        uStack_2ad0 = 0;
        uStack_2ac8 = 0;
        uStack_2ac6 = 0;
        uStack_2ae0 = 0;
        psStack_2ab8 = (short *)0x0;
        psStack_2ab0 = (short *)0x0;
        sStack_2aa8 = 0;
        if ((*pbVar2 & 2) != 0) {
          pbVar2 = pbVar2 + uVar22;
          uStack_2ae8 = pbVar2;
          if ((*pbVar2 & 1) != 0) {
            auStack_2af0._0_2_ = 1;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x101b40)
                                    * 4 + 0x101b30) - 0xf5deb0);
                    /* WARNING: Could not emulate address calculation at 0x001005da */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          auVar8._14_2_ = 0;
          auVar8._0_14_ = stack0xffffffffffffd512;
          _auStack_2af0 = auVar8 << 0x10;
          uStack_2aca = 0;
          uStack_2ac8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007a4 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x101b60) - 0xf5deb0)
          )();
          return;
        }
        if ((*pbVar2 & 4) != 0) {
          uStack_2b70._2_2_ = (short)((uint)uStack_2b70 >> 0x10);
          if (uStack_2b70._2_2_ != 0) {
            uVar22 = (ulonglong)*(ushort *)(lVar21 + 0x61 + (longlong)uStack_2b70._2_2_ * 2);
          }
          psStack_2ab8 = (short *)(pbVar2 + uVar22);
          psStack_2ab0 = psStack_2ab8 + 1;
          sStack_2aa8 = (*psStack_2ab8 + 1) * 2;
        }
        if (auStack_2b00._8_8_ != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100876;
          func_0x(auStack_2b00._8_8_,auStack_2b00);
        }
LAB_:
        pbStack_2b30 = (byte *)((ulonglong)*(ushort *)(lVar21 + 0x1ffe) + lVar21);
        if ((*pbStack_2b30 & 1) != 0) {
          uStack_2b38 = 1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)
                                  *(byte *)((longlong)(int)(*pbStack_2b30 & 0x1c) + 0x101bac) * 4 +
                                 0x101b9c) - 0xf5deb0);
                    /* WARNING: Could not emulate address calculation at 0x001008b6 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        uStack_2b38 = 0;
        uStack_2b34 = 0;
        uStack_2b12 = 0;
        uStack_2b10 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100a4a */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_2b30 & 0xe) * 4 + 0x101bcc) -
                  0xf5deb0))(0xffffffffff0a2150,(longlong)(int)(*pbStack_2b30 & 0xe),0);
        return;
      }
      uVar15 = (int)uVar23 + ((uint)*(ushort *)(lVar21 + 0x1c) - iStack_2ba0);
      uVar23 = (ulonglong)uVar15;
      *(uint *)((longlong)&param_6 + lVar16) = uVar15;
      if (0x2000 < (int)uVar15) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101a46;
        func_0x(*(undefined8 *)((longlong)&param_5 + lVar16));
        goto LAB_;
      }
      param_1 = *(longlong *)((longlong)&param_7 + lVar16);
      param_2 = uStack_2b80;
      uStack_2bf0 = uVar22;
      if (uVar22 == uStack_2b80) {
        *(undefined4 *)(&stack0xfffffffffffffff8 + lVar16) = 0;
        uVar20 = *(undefined8 *)((longlong)&param_8 + lVar16);
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar16) = uVar20;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) = param_6;
        uVar5 = *(undefined8 *)(param_1 + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101a1d;
        func_0x(uVar5,auStack_2bd8,0,lStack_2c08);
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101a27;
        func_0x(*(undefined8 *)((longlong)&param_5 + lVar16));
        param_2 = uVar11;
        goto LAB_;
      }
    }
    lVar18 = *(longlong *)((longlong)&param_5 + lVar16);
    lVar21 = *(longlong *)(param_1 + 0x2e0);
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar16) = 1;
    *(undefined **)(&stack0xfffffffffffffff0 + lVar16) = auStack_2b58;
    *(undefined4 **)(&stack0xffffffffffffffe8 + lVar16) = &uStack_2b68;
    uVar20 = *(undefined8 *)(lVar21 + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1018bb;
    lStack_2b48 = lVar18;
    uVar15 = func_0x(uVar20);
    puVar1 = (uint *)(lVar18 + 4);
    if (((byte)*puVar1 & 0x14) == 4) {
      lVar18 = *(longlong *)(lVar17 + 0x48);
      if ((lVar18 != CONCAT44(uRam0000000001effa2c,_DAT_)) ||
         (*(longlong *)(lVar17 + 0x50) != CONCAT44(uRam0000000001effa34,_DAT_))) {
        *(undefined4 *)(lVar18 + 0x48) = 0;
        *(undefined8 *)(lVar18 + 0x50) = 0;
        *(undefined *)(lVar17 + 0x3e) = 0;
        *(undefined8 *)(lVar17 + 0x30) = 0;
        *(undefined2 *)(lVar17 + 0x3c) = 0;
      }
      uVar10 = uRam0000000001effa34;
      uVar9 = _DAT_;
      uVar4 = uRam0000000001effa2c;
      *(undefined4 *)(lVar17 + 0x48) = _DAT_;
      *(undefined4 *)(lVar17 + 0x4c) = uVar4;
      *(undefined4 *)(lVar17 + 0x50) = uVar9;
      *(undefined4 *)(lVar17 + 0x54) = uVar10;
      *(undefined8 *)(lVar17 + 0x58) = 0;
      lVar18 = *(longlong *)((longlong)&param_5 + lVar16);
      uVar20 = *(undefined8 *)(*(longlong *)(lVar18 + 0x18) + 0x10);
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101923;
      func_0x(uVar20);
      *(undefined4 *)(lVar18 + 0x60) = 1;
      *puVar1 = *puVar1 | 0x10;
    }
    if (uVar15 == 4) {
      *plStack_2b78 = *plStack_2b78 + uVar22;
      goto LAB_;
    }
    param_1 = *(longlong *)((longlong)&param_7 + lVar16);
    uVar20 = *(undefined8 *)((longlong)&param_8 + lVar16);
    if ((1 < uVar15) || ((longlong)param_2 <= (longlong)uVar22)) goto LAB_;
  } while( true );
}

