
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,short *param_3,longlong param_4,uint param_5,
                 uint param_6)

{
  ushort *puVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  bool bVar5;
  byte bVar6;
  ushort uVar7;
  int iVar8;
  uint uVar9;
  ulonglong *puVar10;
  uint *puVar11;
  ulonglong uVar12;
  longlong lVar13;
  ushort uVar14;
  uint uVar15;
  uint *puVar16;
  longlong lVar17;
  undefined *puVar18;
  uint *puVar19;
  ushort *puVar20;
  uint *puVar21;
  short sVar22;
  longlong lVar23;
  byte *pbVar24;
  uint uVar25;
  uint *puVar26;
  uint *puVar27;
  uint uVar28;
  uint *puVar29;
  longlong unaff_GS_OFFSET;
  undefined auStack_e8 [80];
  uint uStack_98;
  int iStack_94;
  int iStack_90;
  uint uStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  int iStack_78;
  uint uStack_74;
  longlong lStack_70;
  longlong lStack_68;
  longlong lStack_60;
  undefined auStack_58 [8];
  longlong lStack_50;
  short *psStack_48;
  longlong *plStack_40;
  ulonglong uStack_38;
  
  puVar18 = auStack_e8;
  uStack_38 = _DAT_ ^ (ulonglong)&uStack_98;
  lVar23 = *(longlong *)(param_1 + 8);
  puVar27 = (uint *)0x0;
  uVar9 = 0;
  uStack_98 = 0;
  uStack_88 = 0;
  iStack_94 = 0;
  uStack_84 = 0;
  lStack_68 = 0;
  uStack_8c = 0;
  iStack_90 = 0;
  puVar16 = puVar27;
  puVar21 = puVar27;
  puVar26 = puVar27;
  lStack_60 = param_4;
  lStack_50 = param_1;
  psStack_48 = param_3;
  plStack_40 = param_2;
  if (*(int *)(lVar23 + 0x100) == 2) {
    if ((*(byte *)(lVar23 + 0x42) & 4) == 0) {
      puVar21 = (uint *)(ulonglong)*(uint *)(lVar23 + 0xb0);
      if (0x1f9e < *(uint *)(lVar23 + 0xb0)) {
        puVar21 = (uint *)0x1f9e;
      }
    }
    else {
      puVar21 = (uint *)0x1f9e;
    }
    uStack_84 = (uint)puVar21;
    puVar11 = (uint *)((longlong)puVar21 + 0xf);
    if (puVar11 <= puVar21) {
      puVar11 = (uint *)0xffffffffffffff0;
    }
    uVar12 = (ulonglong)puVar11 & 0xfffffffffffffff0;
    func_0x();
    puVar18 = auStack_e8 + -uVar12;
    lStack_68 = (longlong)&uStack_98 + -uVar12;
  }
  iStack_78 = *(int *)(lVar23 + 0xf4);
  uStack_74 = *(uint *)(**(longlong **)(lVar23 + 0x160) + 0x1c);
  uStack_7c = *(uint *)(param_4 + 0x40);
  if (uStack_74 <= *(uint *)(param_4 + 0x40)) {
    uStack_7c = uStack_74;
  }
  if (uStack_74 != 0) {
    lStack_70 = 0;
    puVar11 = puVar27;
    puVar29 = puVar27;
    uVar15 = uStack_7c;
    do {
      lVar23 = **(longlong **)(*(longlong *)(lStack_50 + 8) + 0x160);
      if (puVar29 == (uint *)0x0) {
        puVar19 = *(uint **)(lVar23 + 0x38);
      }
      else {
        puVar19 = *(uint **)(puVar29 + 0x5a);
      }
      if (puVar19 == (uint *)(lVar23 + 0x30)) {
        puVar19 = puVar27;
      }
      puVar29 = puVar27;
      if (puVar19 != (uint *)0x0) {
        puVar29 = puVar19 + -0x58;
      }
      if (param_2 == (longlong *)0x0) {
        puVar1 = (ushort *)(param_3 + 1);
        bVar6 = *(byte *)(puVar29 + 8);
        if (*param_3 == 0) {
          uVar28 = *puVar29;
          if ((uVar28 & 0xc0000000) == 0x80000000) {
            *(undefined8 *)(puVar18 + -8) = 0x1009e8;
            iVar8 = func_0x(puVar1);
            if (iVar8 != 0) {
              *(undefined8 *)(puVar18 + -8) = 0x100a04;
              puVar19 = (uint *)func_0x(param_3 + 0x15,puVar29,&uStack_98,auStack_58);
              uVar15 = uStack_98;
              goto LAB_;
            }
LAB_:
            puVar19 = (uint *)0x0;
            uStack_98 = 0;
            uVar15 = uStack_98;
          }
          else {
            if (((bVar6 & 2) != 0) || ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0)) {
              pbVar24 = *(byte **)(param_3 + 4);
              if ((*pbVar24 & 0x10) == 0) {
                if ((1 << (*pbVar24 & 0xe) & 0x1105U) != 0) goto LAB_;
                uVar15 = uVar9;
                bVar5 = true;
LAB_:
                if ((bVar6 & 2) != 0) goto LAB_;
              }
              else {
                uVar15 = *(uint *)(param_3 + 8);
                if ((int)uVar15 <= (int)uVar28) {
LAB_:
                  uVar15 = ~(uint)(*(ushort *)((longlong)puVar29 + 6) >> 4) & 1;
                  bVar5 = false;
                  goto LAB_;
                }
                if ((uint)*(ushort *)(pbVar24 + uVar15) < (uint)*(ushort *)(puVar29 + 1))
                goto LAB_;
                if ((bVar6 & 2) == 0) goto LAB_;
                uVar25 = *(ushort *)(puVar29 + 1) - 1;
                bVar5 = true;
                uVar15 = pbVar24[(ulonglong)uVar15 + (ulonglong)(uVar25 >> 3) + 2] >>
                         ((byte)uVar25 & 7) & 1;
LAB_:
                if (uVar15 != 0) goto LAB_;
              }
              if ((!bVar5) && ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0)) {
                puVar19 = *(uint **)(puVar29 + 2) + 1;
                uVar15 = **(uint **)(puVar29 + 2);
                goto LAB_;
              }
            }
LAB_:
            if ((int)uVar28 < 0) {
              if (*(int *)(param_3 + 2) == 0) {
                pbVar24 = *(byte **)(param_3 + 4);
                uVar15 = *(uint *)(param_3 + 8);
                uVar12 = (ulonglong)uVar15;
                *puVar1 = 0;
                *(uint *)(param_3 + 10) = uVar15;
                bVar6 = *pbVar24;
                if ((bVar6 & 0x10) != 0) {
                  uVar15 = uVar15 + 2 + (*(ushort *)(pbVar24 + uVar12) + 7 >> 3);
                  uVar12 = (ulonglong)uVar15;
                  *(uint *)(param_3 + 10) = uVar15;
                  bVar6 = *pbVar24;
                }
                if ((bVar6 & 0x20) == 0) {
                  *(int *)(param_3 + 2) = (int)uVar12;
                  param_3[0xe] = 0;
                  *(int *)(param_3 + 0xc) = (int)uVar12;
                }
                else {
                  puVar20 = (ushort *)(pbVar24 + uVar12);
                  uVar7 = *puVar20;
                  param_3[0xe] = uVar7;
                  if (uVar7 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar23 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar23 != 0)) &&
                       ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                        (*(char *)(lVar23 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar18 + -8) = 0x100402;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar18 + 0x20) = 0;
                        *(undefined8 *)(puVar18 + -8) = 0x100428;
                        (*_DAT_)(1,0x17c4618,0x18e42e8,0x80f);
                      }
                    }
                    uVar2 = *(undefined8 *)(param_3 + 4);
                    *(undefined8 *)(puVar18 + -8) = 0x100436;
                    func_0x(uVar2,3);
                    uVar12 = (ulonglong)*(uint *)(param_3 + 10);
                    uVar7 = param_3[0xe];
                  }
                  uVar15 = (int)uVar12 + (uVar7 + 1) * 2;
                  *(uint *)(param_3 + 0xc) = uVar15;
                  if (0x1f9e < uVar15) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar23 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar23 != 0 &&
                        ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                         (*(char *)(lVar23 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar18 + -8) = 0x1004d6;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar18 + 0x20) = 0;
                        *(undefined8 *)(puVar18 + -8) = 0x1004fc;
                        (*_DAT_)(1,0x17c4618,0x18e42e8,0x816);
                      }
                    }
                    uVar2 = *(undefined8 *)(param_3 + 4);
                    *(undefined8 *)(puVar18 + -8) = 0x10050a;
                    func_0x(uVar2,4);
                    uVar7 = param_3[0xe];
                    uVar15 = *(uint *)(param_3 + 0xc);
                  }
                  uVar12 = (ulonglong)uVar7;
                  uVar7 = puVar20[uVar12];
                  *(uint *)(param_3 + 2) = uVar7 & 0x7fff;
                  if ((uVar7 & 0x7fff) < uVar15) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar23 = *(longlong *)
                                   (*(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_)
                        , lVar23 != 0)) &&
                       ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                        (*(char *)(lVar23 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar18 + -8) = 0x1005a8;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar18 + 0x20) = 0;
                        *(undefined8 *)(puVar18 + -8) = 0x1005ce;
                        (*_DAT_)(1,0x17c4618,0x18e42e8,0x81d);
                      }
                    }
                    uVar2 = *(undefined8 *)(param_3 + 4);
                    *(undefined8 *)(puVar18 + -8) = 0x1005dc;
                    func_0x(uVar2,4);
                    uVar12 = (ulonglong)(ushort)param_3[0xe];
                  }
                  if ((short)puVar20[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
                    pbVar24 = *(byte **)(param_3 + 4);
                    do {
                      if ((int)uVar12 == 1) {
                        uVar15 = *(uint *)(param_3 + 0xc);
                        uVar28 = uVar15;
LAB_:
                        if ((*(ushort *)(pbVar24 + uVar12 * 2 + (ulonglong)*(uint *)(param_3 + 10))
                            & 0x7fff) < uVar15) goto LAB_;
                      }
                      else {
                        uVar28 = *(uint *)(param_3 + 0xc);
                        uVar15 = *(ushort *)
                                  (pbVar24 + uVar12 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2))
                                 & 0x7fff;
                        if (uVar28 <= uVar15) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar18 + -8) = 0x100642;
                        func_0x(pbVar24,7);
                        uVar28 = *(uint *)(param_3 + 0xc);
                      }
                      if ((uVar15 < uVar28) || (*(uint *)(param_3 + 2) < uVar15)) goto LAB_;
                      pbVar24 = *(byte **)(param_3 + 4);
                      if (*(ushort *)(pbVar24 + uVar15) == 5) {
                        *puVar1 = *puVar1 | 2;
                        param_3[0xe] = param_3[0xe] + -1;
                        param_3[0x15] = (short)uVar15;
                        lVar23 = (ulonglong)(uVar15 & 0xffff) + *(longlong *)(param_3 + 4);
                        uVar7 = param_3[0x16] & 0xc7ffU;
                        if ((*(ushort *)(lVar23 + 2) >> 0xe & 1) != 0) {
                          uVar7 = *(ushort *)(lVar23 + 2) & 0x3800 | param_3[0x16] & 0xc7ffU;
                        }
                        param_3[0x16] = uVar7;
                        param_3[0x16] = (uVar7 ^ *(ushort *)(lVar23 + 2)) & 0x7ff ^ uVar7;
                        goto LAB_;
                      }
                      if (*(ushort *)(pbVar24 + uVar15) < 0x400) goto LAB_;
                      *puVar1 = *puVar1 | 1;
                      uVar7 = param_3[0xe] - 1;
                      param_3[0xe] = uVar7;
                      if (uVar7 == 0) goto LAB_;
                      uVar12 = (ulonglong)uVar7;
                    } while ((short)puVar20[(ulonglong)(uVar7 - 1) + 1] < 0);
                    uVar12 = (ulonglong)*(uint *)(param_3 + 2);
                  }
                  else {
LAB_:
                    uVar12 = (ulonglong)*(uint *)(param_3 + 2);
                    pbVar24 = *(byte **)(param_3 + 4);
                  }
                }
                if ((*pbVar24 & 0x40) == 0) {
                  *(undefined4 *)(param_3 + 0x13) = 0;
                }
                else {
                  *(int *)(param_3 + 0x13) = (int)uVar12;
                  *(int *)(param_3 + 2) = (int)uVar12 + 0xe;
                  *(undefined8 *)(puVar18 + -8) = 0x10072f;
                  puVar10 = (ulonglong *)func_0x(puVar1);
                  uVar14 = (ushort)(*puVar10 >> 0x30);
                  uVar7 = uVar14;
                  if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
                    uVar7 = uVar14 & 0xdfff;
                    if ((uVar14 >> 0xe & 1) != 0) {
                      uVar7 = uVar14 | 0x2000;
                    }
                  }
                  uVar15 = uVar9;
                  if (uVar7 == 0xfffc) {
                    uVar15 = (uint)((*puVar10 >> 0x20 & 0xffff) >> 5);
                  }
                  *(uint *)(param_3 + 2) = *(int *)(param_3 + 2) + uVar15;
                  uVar12 = (ulonglong)*(uint *)(param_3 + 2);
                }
                iVar8 = (int)uVar12;
                if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
                   (*(ulonglong *)(param_3 + 0xf) < uVar12 + *(longlong *)(param_3 + 4))) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar23 = *(longlong *)
                                  (*(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                       lVar23 != 0 && (lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0)) &&
                      (*(char *)(lVar23 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar18 + -8) = 0x10082c;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar18 + 0x20) = 0;
                      *(undefined8 *)(puVar18 + -8) = 0x100852;
                      (*_DAT_)(1,0x17c4618,0x18e42e8,0x877);
                    }
                  }
                  uVar2 = *(undefined8 *)(param_3 + 4);
                  *(undefined8 *)(puVar18 + -8) = 0x100860;
                  func_0x(uVar2,0x12);
                  iVar8 = *(int *)(param_3 + 2);
                }
                if (0x3f3b < iVar8 - 1U) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar23 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar23 != 0 &&
                      ((lVar23 = *(longlong *)(lVar23 + 0x60), lVar23 != 0 &&
                       (*(char *)(lVar23 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar18 + -8) = 0x1008ec;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar18 + 0x20) = 0;
                      *(undefined8 *)(puVar18 + -8) = 0x100912;
                      (*_DAT_)(1,0x17c4618,0x18e42e8,0x87c);
                    }
                  }
                  uVar2 = *(undefined8 *)(param_3 + 4);
                  *(undefined8 *)(puVar18 + -8) = 0x100920;
                  func_0x(uVar2,5);
                }
              }
LAB_:
              sVar22 = -*(short *)puVar29;
              if ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0) {
                bVar6 = **(byte **)(param_3 + 4);
                if ((bVar6 & 0x10) == 0) {
                  if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
                    puVar19 = *(uint **)(puVar29 + 2) + 1;
                    uVar15 = **(uint **)(puVar29 + 2);
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(param_3 + 8) <= (int)*puVar29) ||
                        (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                         *(ushort *)(puVar29 + 1))) goto LAB_;
              }
              puVar19 = *(uint **)(param_3 + 4);
              uVar15 = uVar9;
              if ((uint)(int)sVar22 <= (uint)(ushort)param_3[0xe]) {
                uVar15 = *(ushort *)
                          ((longlong)puVar19 +
                          (longlong)sVar22 * 2 + (ulonglong)*(uint *)(param_3 + 10)) & 0x7fff;
                if (sVar22 == 1) {
                  uVar28 = *(uint *)(param_3 + 0xc);
LAB_:
                  if (uVar15 < uVar28) goto LAB_;
                }
                else {
                  uVar28 = *(ushort *)
                            ((longlong)puVar19 +
                            (longlong)sVar22 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                           0x7fff;
                  if (*(uint *)(param_3 + 0xc) <= uVar28) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar18 + -8) = 0x1009c2;
                  func_0x(puVar19,7);
                  puVar19 = *(uint **)(param_3 + 4);
                }
                puVar19 = (uint *)((longlong)puVar19 + (ulonglong)uVar28);
                param_3 = psStack_48;
                uVar15 = uVar15 - uVar28;
              }
            }
            else {
              uVar7 = *(ushort *)((longlong)puVar29 + 6);
              if ((uVar7 & 8) == 0) {
                uVar25 = (uint)*(ushort *)(puVar29 + 0xe);
                if ((uVar7 & 0x10) != 0) {
                  bVar6 = **(byte **)(param_3 + 4);
                  if ((bVar6 & 0x10) == 0) {
                    if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
                      uVar15 = **(uint **)(puVar29 + 2);
                      puVar19 = *(uint **)(puVar29 + 2) + 1;
                      if ((uVar25 != 0) && (uVar15 != uVar25)) {
                        *(undefined8 *)(puVar18 + 0x20) = 0;
                        *(undefined8 *)(puVar18 + -8) = 0x1002f6;
                        (*_DAT_)(1,0x1972388,0x1970d88,0x381);
                      }
                      goto LAB_;
                    }
                  }
                  else if (((int)*(uint *)(param_3 + 8) <= (int)uVar28) ||
                          (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                           *(ushort *)(puVar29 + 1))) goto LAB_;
                }
                puVar19 = (uint *)((longlong)(int)*puVar29 + *(longlong *)(param_3 + 4));
                uVar15 = uVar25;
              }
              else {
                puVar19 = (uint *)0x1549054;
                uStack_98 = 1;
                uVar15 = uStack_98;
                if ((*(byte *)((longlong)(int)uVar28 + *(longlong *)(param_3 + 4)) &
                    (byte)(1 << ((byte)uVar7 & 7))) == 0) {
                  puVar19 = (uint *)0x1549678;
                }
              }
            }
          }
        }
        else {
          uStack_80 = 0;
          *(uint **)(puVar18 + 0x20) = &uStack_80;
          *(undefined8 *)(puVar18 + -8) = 0x100a9e;
          puVar19 = (uint *)func_0x(puVar1,puVar29,uVar15,&uStack_98);
          uVar15 = uStack_98;
          if ((((*param_3 != 0) && (plVar3 = *(longlong **)(param_3 + 8), plVar3 != (longlong *)0x0)
               ) && (*plVar3 != 0)) &&
             (((*(byte *)((longlong)puVar29 + 6) & 8) == 0 && ((uStack_80 & 1) == 0)))) {
            if ((puVar19 == (uint *)0x0) || (puVar19 == (uint *)0x1549054)) {
              uStack_98 = 0;
              puVar19 = (uint *)0x0;
              uVar15 = uStack_98;
            }
            else {
              *(uint *)(puVar18 + 0x38) = uStack_80;
              *(uint **)(puVar18 + 0x30) = &uStack_98;
              lVar23 = lStack_68;
              *(int *)(puVar18 + 0x28) = (int)puVar21;
              *(longlong *)(puVar18 + 0x20) = lVar23;
              *(undefined8 *)(puVar18 + -8) = 0x100b11;
              puVar19 = (uint *)func_0x(plVar3,puVar29,puVar19,uVar15);
              uVar15 = uStack_98;
            }
          }
        }
LAB_:
        uStack_98 = uVar15;
        puVar16 = (uint *)(ulonglong)uStack_8c;
        puVar26 = (uint *)(ulonglong)uStack_88;
        uVar15 = uStack_7c;
      }
      else {
        uStack_98 = (uint)*(ushort *)(*param_2 + 0xc + lStack_70 * 0x10);
        puVar19 = *(uint **)(*param_2 + lStack_70 * 0x10);
      }
      lVar23 = lStack_60;
      iVar8 = iStack_78;
      uVar28 = (uint)puVar11;
      if (((puVar19 != (uint *)0x0) || (uStack_98 != 0)) ||
         (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar29 + 0xd) + 0x15494f0) +
                   0x154a7c0) == '\0')) {
        if (*(byte *)(puVar29 + 0xd) == 0x68) {
          iStack_90 = iStack_90 + 1;
          if (uVar28 < uVar15) {
            iStack_94 = iStack_94 + 1;
          }
        }
        else {
          if (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar29 + 0xd) + 0x15494f0) +
                       0x154a7c0) == '\0') {
            uVar7 = *(ushort *)(puVar29 + 0xe);
            if (0x1f9e < uVar7) {
              uVar7 = 0x1f9e;
            }
            uStack_98 = (uint)uVar7;
          }
          uStack_8c = (int)puVar16 + uStack_98;
          puVar16 = (uint *)(ulonglong)uStack_8c;
          if (uVar28 < uVar15) {
            uStack_88 = (int)puVar26 + uStack_98;
            puVar26 = (uint *)(ulonglong)uStack_88;
          }
        }
      }
      uVar25 = (uint)puVar26;
      puVar21 = (uint *)(ulonglong)uStack_84;
      lStack_70 = lStack_70 + 1;
      puVar11 = (uint *)(ulonglong)(uVar28 + 1);
      param_2 = plStack_40;
    } while (uVar28 + 1 < uStack_74);
    if (iStack_94 != 0) {
      uVar15 = iStack_94 >> 0x1f & 7;
      uVar9 = iStack_94 + uVar15;
      uVar25 = uVar25 + (uint)((uVar9 & 7) != uVar15) + ((int)uVar9 >> 3);
    }
    uVar9 = uStack_8c;
    if (iStack_90 != 0) {
      uVar15 = iStack_90 >> 0x1f & 7;
      uVar9 = iStack_90 + uVar15;
      uVar9 = uStack_8c + (uint)((uVar9 & 7) != uVar15) + ((int)uVar9 >> 3);
    }
    lVar17 = -1;
    if (param_5 < uVar25) {
      lVar4 = *(longlong *)(lStack_60 + 0x18);
      lVar13 = -1;
      do {
        lVar13 = lVar13 + 1;
      } while (*(short *)(lVar4 + lVar13 * 2) != 0);
      *(uint *)(puVar18 + 0x40) = (iStack_78 != 1) + 0x8a9a;
      *(uint *)(puVar18 + 0x38) = param_5;
      *(longlong *)(puVar18 + 0x30) = lVar4;
      *(int *)(puVar18 + 0x28) = (int)lVar13 * 2;
      *(uint *)(puVar18 + 0x20) = uVar25;
      *(undefined8 *)(puVar18 + -8) = 0x100c4c;
      (*_DAT_)(0x13,0x2e,0x10,3);
    }
    if (param_6 < uVar9) {
      lVar23 = *(longlong *)(lVar23 + 0x18);
      do {
        lVar17 = lVar17 + 1;
      } while (*(short *)(lVar23 + lVar17 * 2) != 0);
      *(uint *)(puVar18 + 0x40) = (iVar8 != 1) + 0x8a9a;
      *(uint *)(puVar18 + 0x38) = param_6;
      *(longlong *)(puVar18 + 0x30) = lVar23;
      *(int *)(puVar18 + 0x28) = (int)lVar17 * 2;
      *(uint *)(puVar18 + 0x20) = uVar9;
      *(undefined8 *)(puVar18 + -8) = 0x100cad;
      (*_DAT_)(0x13,0x2e,0x10,3);
    }
  }
  uVar12 = uStack_38 ^ (ulonglong)&uStack_98;
  *(undefined8 *)(puVar18 + -8) = 0x100cb9;
  func_0x(uVar12);
  return;
}

