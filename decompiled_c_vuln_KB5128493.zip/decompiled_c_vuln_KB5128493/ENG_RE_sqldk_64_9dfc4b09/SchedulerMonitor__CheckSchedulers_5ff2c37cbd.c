
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x0010023c) */
/* WARNING: Removing unreachable block (ram,0x00100246) */
/* WARNING: Removing unreachable block (ram,0x000fff1a) */
/* WARNING: Removing unreachable block (ram,0x00100250) */
/* WARNING: Removing unreachable block (ram,0x00274100) */
/* WARNING: Removing unreachable block (ram,0x0010026b) */
/* WARNING: Removing unreachable block (ram,0x0010031b) */
/* WARNING: Removing unreachable block (ram,0x0027412c) */
/* WARNING: Removing unreachable block (ram,0x0010032e) */
/* WARNING: Removing unreachable block (ram,0x0010033a) */
/* WARNING: Removing unreachable block (ram,0x00274174) */
/* WARNING: Removing unreachable block (ram,0x0010034b) */
/* WARNING: Removing unreachable block (ram,0x0010034f) */
/* WARNING: Removing unreachable block (ram,0x00100277) */
/* WARNING: Removing unreachable block (ram,0x001002c4) */
/* WARNING: Removing unreachable block (ram,0x001002d7) */
/* WARNING: Removing unreachable block (ram,0x00274123) */
/* WARNING: Removing unreachable block (ram,0x001002ed) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2)

{
  ulonglong *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  ulonglong uVar12;
  longlong unaff_GS_OFFSET;
  bool bVar13;
  undefined auStack_a28 [32];
  int iStack_a08;
  int iStack_9f8;
  int iStack_9f0;
  longlong lStack_9e8;
  undefined auStack_9e0 [16];
  undefined8 uStack_9d0;
  undefined8 uStack_9c8;
  undefined4 uStack_9c0;
  longlong lStack_9b8;
  undefined auStack_9b0 [16];
  undefined8 uStack_9a0;
  undefined8 uStack_998;
  undefined4 uStack_990;
  longlong lStack_8f0;
  longlong lStack_8e8;
  longlong lStack_8e0;
  undefined8 uStack_8b0;
  uint auStack_238 [64];
  uint auStack_138 [64];
  ulonglong uStack_38;
  
  uStack_8b0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_a28;
  iStack_a08 = 1;
  iStack_9f8 = 0;
  iStack_9f0 = param_2;
  lStack_9e8 = param_1;
  func_0x(auStack_138,0,0x100);
  func_0x(auStack_238,0,0x100);
  lVar11 = 0x198;
  if (param_2 != 1) {
    lVar11 = 0x1e8;
  }
  lVar8 = 0x168;
  if (param_2 != 1) {
    lVar8 = 0x1b8;
  }
  func_0x(&lStack_8f0,lVar8 + *(longlong *)(param_1 + 0x18),
                  lVar11 + *(longlong *)(param_1 + 0x18),1);
  lVar11 = 0;
  while( true ) {
    lVar8 = lStack_8f0;
    iVar3 = iStack_a08;
    lVar7 = 0;
    if (lVar11 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (lStack_8f0 != 0) break;
LAB_:
    lStack_9b8 = lVar7;
    if (lVar7 == 0) goto LAB_;
    iStack_9f8 = 1;
    func_0x(param_1,param_2,lVar7);
    if (iVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iStack_a08 = 0;
    lVar11 = lVar7;
    if (param_2 == 1) {
      auStack_9b0 = ZEXT816(0);
      uStack_998 = 0;
      uStack_990 = 0;
      uStack_9a0 = 0x4006c8;
      uVar6 = func_0x(0x4006c8);
      auStack_9b0._0_8_ = uVar6;
      func_0x(0x4006c8);
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (lStack_8f0 != lStack_8e8) {
    puVar1 = (ulonglong *)(lStack_8e0 + 0x10);
    if (*(int *)puVar1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    LOCK();
    uVar12 = *puVar1;
    if (uVar12 == 0) {
      *puVar1 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (uVar12 != 0) {
      return;
    }
    lVar8 = *(longlong *)(lVar11 + 0x18);
    if (lVar8 == lStack_8e0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar7 = 0;
    if (lVar8 != 0) {
      lVar7 = lVar8 + -0x10;
    }
    if (lVar7 != 0) {
      iVar5 = *(int *)(lVar7 + 0x28);
      if (iVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      iVar4 = *(int *)(lVar7 + 0x28);
      if (iVar5 == iVar4) {
        *(int *)(lVar7 + 0x28) = iVar5 + 1;
        iVar4 = iVar5;
      }
      UNLOCK();
      if (iVar5 != iVar4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (iVar5 + 1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if (DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar1 = 0;
    LOCK();
    piVar2 = (int *)(lVar11 + 0x28);
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    param_1 = lStack_9e8;
    lStack_8f0 = lVar7;
    if (iVar5 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    goto LAB_;
  }
  lStack_8f0 = 0;
  LOCK();
  piVar2 = (int *)(lVar8 + 0x28);
  iVar5 = *piVar2;
  *piVar2 = *piVar2 + -1;
  UNLOCK();
  if (iVar5 != 1) goto LAB_;
  if (*(longlong *)(lVar8 + 0x18) != 0) {
    func_0x(*(undefined8 *)(lVar8 + 0x20));
  }
  func_0x(lVar8);
LAB_:
  func_0x(&lStack_8f0);
  if (param_2 != 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  auStack_9e0 = ZEXT816(0);
  uStack_9c8 = 0;
  uStack_9c0 = 0;
  uStack_9d0 = 0x4006c8;
  lVar8 = func_0x(0x4006c8);
  auStack_9e0._0_8_ = lVar8;
  lVar7 = func_0x(0x4006c8);
  lVar11 = 0;
  while( true ) {
    if (lVar11 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar9 = 0;
    lVar10 = lVar8;
    auStack_9e0._8_8_ = lVar7;
    if (lVar8 != 0) {
      if (lVar8 == lVar7) {
        auStack_9e0._0_8_ = 0;
        LOCK();
        piVar2 = (int *)(lVar8 + 0x18);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        lVar9 = auStack_9e0._0_8_;
        lVar10 = auStack_9e0._0_8_;
        if (iVar3 == 1) {
          if (*(longlong *)(lVar8 + 8) == 0) {
            func_0x(lVar8);
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          func_0x(*(undefined8 *)(lVar8 + 0x10),lVar8);
          func_0x(lVar8);
          func_0x(lVar8,0xbe8);
          lVar10 = auStack_9e0._0_8_;
          break;
        }
      }
      else {
        if (_DAT_ != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        LOCK();
        bVar13 = _DAT_ != 0;
        uVar12 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
        if (bVar13) {
          uVar12 = _DAT_;
        }
        _DAT_ = uVar12;
        UNLOCK();
        if (bVar13) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        auStack_9e0._0_8_ = *(longlong *)(lVar11 + 8);
        if (auStack_9e0._0_8_ == 0x4006c8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (auStack_9e0._0_8_ != 0) {
          iVar3 = *(int *)(auStack_9e0._0_8_ + 0x18);
          if (iVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          LOCK();
          iVar5 = *(int *)(auStack_9e0._0_8_ + 0x18);
          if (iVar3 == iVar5) {
            *(int *)(auStack_9e0._0_8_ + 0x18) = iVar3 + 1;
            iVar5 = iVar3;
          }
          UNLOCK();
          if (iVar3 != iVar5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (iVar3 + 1 == 0) {
            return;
          }
        }
        if (DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        _DAT_ = 0;
        LOCK();
        piVar2 = (int *)(lVar11 + 0x18);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        lVar9 = auStack_9e0._0_8_;
        lVar10 = auStack_9e0._0_8_;
        if (iVar3 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
    }
    if (lVar9 == 0) break;
    uVar12 = (ulonglong)*(uint *)(lVar9 + 0xb30);
    lVar11 = lVar9;
    lVar8 = lVar10;
    if (auStack_238[uVar12] != 0) {
      *(uint *)(*(longlong *)(param_1 + 0x18) + 0x638 + uVar12 * 4) =
           auStack_138[uVar12] / auStack_238[uVar12];
    }
  }
  if (lVar10 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (auStack_9e0._8_8_ != 0) {
    LOCK();
    piVar2 = (int *)(auStack_9e0._8_8_ + 0x18);
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    auStack_9e0._8_8_ = 0;
  }
  uStack_9d0 = 0;
  if ((iStack_9f8 == 1) && (iStack_a08 == 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x1e0) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(int *)(param_1 + 0x1e0) = 0;
  func_0x(uStack_38 ^ (ulonglong)auStack_a28);
  return;
}

