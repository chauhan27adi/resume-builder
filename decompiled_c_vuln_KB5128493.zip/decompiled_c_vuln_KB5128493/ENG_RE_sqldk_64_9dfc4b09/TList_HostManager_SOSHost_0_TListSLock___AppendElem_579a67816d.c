
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,longlong **param_2)

{
  longlong **pplVar1;
  longlong *plVar2;
  code *pcVar3;
  int iVar4;
  longlong unaff_GS_OFFSET;
  
  pplVar1 = param_1 + 2;
  if (*(int *)pplVar1 == 0) {
    LOCK();
    plVar2 = *pplVar1;
    if (plVar2 == (longlong *)0x0) {
      *pplVar1 = (longlong *)(ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (plVar2 == (longlong *)0x0) {
      *param_2 = *param_1;
      (*param_1)[1] = (longlong)param_2;
      *param_1 = (longlong *)param_2;
      param_2[1] = (longlong *)param_1;
      *(int *)(param_1 + 3) = *(int *)(param_1 + 3) + 1;
      param_2[2] = (longlong *)param_1;
      if ((DAT_ != '\0') && (iVar4 = (*_DAT_)(), iVar4 == (iVar4 / 5) * 5)) {
        func_0x();
      }
      pcVar3 = (code *)swi(3);
      (*pcVar3)();
      return;
    }
  }
  pcVar3 = (code *)swi(3);
  (*pcVar3)();
  return;
}

