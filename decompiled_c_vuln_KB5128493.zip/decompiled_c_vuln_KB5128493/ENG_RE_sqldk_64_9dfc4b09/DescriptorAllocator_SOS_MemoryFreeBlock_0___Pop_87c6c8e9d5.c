
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x0010011a) */
/* WARNING: Removing unreachable block (ram,0x00164056) */
/* WARNING: Removing unreachable block (ram,0x00100127) */
/* WARNING: Removing unreachable block (ram,0x0016406c) */
/* WARNING: Removing unreachable block (ram,0x00100143) */
/* WARNING: Removing unreachable block (ram,0x00164064) */
/* WARNING: Removing unreachable block (ram,0x00100150) */
/* WARNING: Removing unreachable block (ram,0x00164074) */
/* WARNING: Removing unreachable block (ram,0x0010015d) */
/* WARNING: Removing unreachable block (ram,0x0016408b) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(longlong param_1,uint param_2,undefined8 param_3,longlong param_4)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  ulonglong uVar4;
  bool bVar5;
  
  if (param_4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar1 = *(ulonglong *)
           (((ulonglong)param_2 << (*(byte *)(param_1 + 0x4cc) & 0x3f)) +
            *(longlong *)(param_1 + 0x4c0) + 8);
  if (uVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar3 = (*_DAT_)(uVar1);
  if (lVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = *(ulonglong *)(uVar1 + 0x18);
  uVar4 = 0;
  if ((uVar2 != 0) && (uVar4 = 0, uVar2 < uVar1)) {
    uVar4 = uVar2 + 0x40;
    if (uVar2 + 0x40 == uVar1) {
      uVar4 = 0;
    }
    LOCK();
    bVar5 = uVar2 == *(ulonglong *)(uVar1 + 0x18);
    if (bVar5) {
      *(ulonglong *)(uVar1 + 0x18) = uVar4;
    }
    UNLOCK();
    if (!bVar5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    LOCK();
    *(int *)(uVar1 + 0x28) = *(int *)(uVar1 + 0x28) + -1;
    UNLOCK();
    uVar4 = uVar2;
  }
  if (uVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return uVar4;
}

