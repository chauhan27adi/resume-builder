
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,uint param_2)

{
  code *pcVar1;
  longlong unaff_GS_OFFSET;
  bool bVar2;
  
  if (*(int *)(param_1 + 0x10) != 0) {
    if (*(int *)(param_1 + 0x18) == 0) {
      LOCK();
      bVar2 = *(ulonglong *)(param_1 + 0x18) == 0;
      if (bVar2) {
        *(ulonglong *)(param_1 + 0x18) = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      }
      UNLOCK();
      if (bVar2) goto LAB_;
    }
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
  }
LAB_:
  if (*(longlong *)(param_1 + 0x20 + (ulonglong)(param_2 & 0xf) * 8) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}

