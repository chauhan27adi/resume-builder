
/* WARNING: Control flow encountered bad instruction data */

void FUN_(int *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  
  if (*param_1 != 0) {
    lVar1 = *(longlong *)(param_1 + 2);
    if (param_1[1] == 0) {
      (**(code **)(**(longlong **)(lVar1 + 0x260) + 0x10))
                (*(longlong **)(lVar1 + 0x260),lVar1,1,param_4,0xfffffffffffffffe);
    }
    else {
      *(uint *)(lVar1 + 800) = *(uint *)(lVar1 + 800) | 0x800;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

