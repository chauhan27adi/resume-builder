
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00295a31) */

undefined8 FUN_(longlong *param_1,longlong param_2)

{
  longlong lVar1;
  char cVar2;
  uint uVar3;
  ulonglong uVar4;
  
  if (*(int *)((longlong)param_1 + 0x1c) != 0) {
    if (param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar4 = 0;
    if (*(int *)((longlong)param_1 + 0x1c) != 0) {
      do {
        lVar1 = *(longlong *)(param_1[5] + uVar4 * 8);
        if ((lVar1 != 0) && (*(int *)(lVar1 + 0x30) == 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar3 = (int)uVar4 + 1;
        uVar4 = (ulonglong)uVar3;
      } while (uVar3 < *(uint *)((longlong)param_1 + 0x1c));
    }
    cVar2 = (**(code **)(*param_1 + 0x40))(param_1);
    if (cVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(param_1 + 9) != 0) {
      return 1;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

