
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2)

{
  ulonglong *puVar1;
  longlong *plVar2;
  ulonglong uVar3;
  code *pcVar4;
  int iVar5;
  longlong *plVar6;
  longlong unaff_GS_OFFSET;
  
  puVar1 = (ulonglong *)(param_1 + 2);
  plVar6 = param_1 + -6;
  if (param_1 == (longlong *)0x0) {
    plVar6 = (longlong *)0x0;
  }
  if (*(int *)puVar1 == 0) {
    LOCK();
    uVar3 = *puVar1;
    if (uVar3 == 0) {
      *puVar1 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (uVar3 == 0) {
      plVar2 = (longlong *)(param_2 + 0x10);
      *plVar2 = *param_1;
      *(longlong **)(*param_1 + 8) = plVar2;
      *param_1 = (longlong)plVar2;
      *(longlong **)(param_2 + 0x18) = param_1;
      *(int *)(param_1 + 3) = *(int *)(param_1 + 3) + 1;
      *(longlong **)(param_2 + 0x20) = plVar6;
      if ((DAT_ != '\0') && (iVar5 = (*_DAT_)(), iVar5 == (iVar5 / 5) * 5)) {
        func_0x();
      }
      pcVar4 = (code *)swi(3);
      (*pcVar4)();
      return;
    }
  }
  pcVar4 = (code *)swi(3);
  (*pcVar4)();
  return;
}

