
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong *param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  func_0x(*param_1);
  *param_1 = 0;
  lVar1 = *param_1;
  if (lVar1 != 0) {
    func_0x(lVar1,8,*(undefined8 *)(lVar1 + -8),0xfffffffffff88840,uVar2);
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}

