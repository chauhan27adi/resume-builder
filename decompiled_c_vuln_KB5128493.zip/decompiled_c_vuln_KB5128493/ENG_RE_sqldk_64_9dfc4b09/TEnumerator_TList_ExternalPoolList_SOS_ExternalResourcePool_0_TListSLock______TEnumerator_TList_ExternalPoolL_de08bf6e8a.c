
void FUN_(longlong *param_1)

{
  int *piVar1;
  int iVar2;
  longlong lVar3;
  
  lVar3 = *param_1;
  if (lVar3 != 0) {
    LOCK();
    piVar1 = (int *)(lVar3 + 0x18);
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      if (*(longlong *)(lVar3 + 8) != 0) {
        func_0x(*(undefined8 *)(lVar3 + 0x10),lVar3);
      }
      func_0x(lVar3,0x1f8);
    }
    *param_1 = 0;
  }
  lVar3 = param_1[1];
  if (lVar3 != 0) {
    LOCK();
    piVar1 = (int *)(lVar3 + 0x18);
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      if (*(longlong *)(lVar3 + 8) != 0) {
        func_0x(*(undefined8 *)(lVar3 + 0x10),lVar3);
      }
      func_0x(lVar3,0x1f8);
    }
    param_1[1] = 0;
  }
  if (param_1[3] != 0) {
    func_0x(param_1[3],*(undefined4 *)(param_1 + 4));
    param_1[3] = 0;
    *(undefined4 *)(param_1 + 4) = 0;
  }
  param_1[2] = 0;
  return;
}

