
/* WARNING: Control flow encountered bad instruction data */

void FUN_(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

