// NOTE: 1 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

/* WARNING: Control flow encountered bad instruction data */

void FUN_(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

