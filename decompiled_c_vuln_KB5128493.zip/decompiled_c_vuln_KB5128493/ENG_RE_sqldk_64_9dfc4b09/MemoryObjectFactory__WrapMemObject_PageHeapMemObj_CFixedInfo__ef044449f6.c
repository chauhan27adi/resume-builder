
undefined8 * FUN_(undefined4 param_1,ulonglong param_2,ulonglong param_3)

{
  ulonglong *puVar1;
  ushort *puVar2;
  undefined auVar3 [16];
  undefined8 uVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  uint uVar8;
  int iVar9;
  longlong lVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  uint uVar13;
  longlong lVar14;
  longlong unaff_GS_OFFSET;
  uint in_stack_00000040;
  longlong in_stack_00000048;
  undefined4 in_stack_00000050;
  undefined (*in_stack_00000058) [16];
  undefined8 uVar15;
  undefined4 uStack_60;
  undefined8 uStack_58;
  undefined2 uStack_50;
  undefined2 uStack_4e;
  
  uVar15 = 0xfffffffffffffffe;
  uVar4 = *(undefined8 *)((param_2 & 0xffffffff) * 8 + 0x34ae90);
  uVar13 = in_stack_00000040 & 0x12f0002;
  puVar11 = (undefined8 *)0x0;
  puVar12 = (undefined8 *)0x0;
  switch(param_1) {
  case 0:
    puVar5 = *(undefined8 **)(param_3 + 0x28);
    *(undefined8 **)(param_3 + 0x28) = puVar5 + 0x10;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    puVar12 = puVar11;
    if (puVar5 != (undefined8 *)0x0) {
      *(undefined4 *)(puVar5 + 1) = 1;
      *puVar5 = 0x27f998;
      puVar5[2] = 0x2000;
      *(undefined4 *)(puVar5 + 3) = 0;
      puVar5[4] = 0;
      *(undefined4 *)(puVar5 + 5) = 0;
      puVar5[6] = 0;
      puVar5[7] = 0;
      puVar5[8] = 0;
      puVar5[9] = 0;
      *puVar5 = 0x286db0;
      puVar11 = puVar5 + 0xd;
      puVar5[0xe] = puVar11;
      *puVar11 = puVar11;
      puVar12 = puVar5;
    }
    break;
  case 1:
    puVar12 = *(undefined8 **)(param_3 + 0x28);
    *(undefined8 **)(param_3 + 0x28) = puVar12 + 0x8a;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (puVar12 != (undefined8 *)0x0) {
      *(undefined4 *)(puVar12 + 1) = 1;
      *puVar12 = 0x27f998;
      puVar12[2] = 0x2000;
      *(undefined4 *)(puVar12 + 3) = 0;
      puVar12[4] = 0;
      *(undefined4 *)(puVar12 + 5) = 0;
      puVar12[6] = 0;
      puVar12[7] = 0;
      puVar12[8] = 0;
      puVar12[9] = 0;
      *puVar12 = 0x286db0;
      puVar11 = puVar12 + 0xd;
      puVar12[0xe] = puVar11;
      *puVar11 = puVar11;
      *puVar12 = 0x286b00;
      puVar12[0x12] = 0x29e568;
      puVar11 = puVar12;
    }
    goto code_r0x00100162;
  case 2:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x160;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    puVar12 = puVar11;
    if (lVar10 != 0) {
      puVar12 = (undefined8 *)func_0x();
    }
    break;
  case 3:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x530;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    goto code_r0x00100621;
  case 4:
    puVar5 = *(undefined8 **)(param_3 + 0x28);
    *(undefined8 **)(param_3 + 0x28) = puVar5 + 0x1a;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    puVar12 = puVar11;
    if (puVar5 != (undefined8 *)0x0) {
      *(undefined4 *)(puVar5 + 1) = 1;
      *puVar5 = 0x27f998;
      puVar5[2] = 0x2000;
      *(undefined4 *)(puVar5 + 3) = 0;
      puVar5[4] = 0;
      *(undefined4 *)(puVar5 + 5) = 0;
      puVar5[6] = 0;
      puVar5[7] = 0;
      puVar5[8] = 0;
      puVar5[9] = 0;
      *puVar5 = 0x286db0;
      puVar11 = puVar5 + 0xd;
      puVar5[0xe] = puVar11;
      *puVar11 = puVar11;
      *puVar5 = 0x282538;
      puVar5[0x10] = 0;
      *(undefined (*) [16])(puVar5 + 0x11) = ZEXT816(0);
      *(undefined (*) [16])(puVar5 + 0x13) = ZEXT816(0);
      *(undefined (*) [16])(puVar5 + 0x15) = ZEXT816(0);
      *(undefined (*) [16])(puVar5 + 0x17) = ZEXT816(0);
      puVar5[0x19] = 0;
      puVar12 = puVar5;
    }
    break;
  case 5:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x4a0;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    goto code_r0x00100162;
  case 6:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x1b0;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    puVar12 = puVar11;
    if (lVar10 != 0) {
      puVar12 = (undefined8 *)func_0x();
    }
    break;
  case 7:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x580;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    goto code_r0x00100621;
  default:
    goto LAB_;
  case 10:
    puVar1 = (ulonglong *)(param_3 + 0x28);
    uVar6 = *puVar1;
    *puVar1 = uVar6 + 0x220;
    puVar2 = (ushort *)(param_3 + 0x30);
    *puVar2 = *puVar2 | 1;
    if (uVar6 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    uVar13 = *(uint *)(*in_stack_00000058 + 4);
    if (((((uVar13 & 2) == 0) || ((uVar13 & 0x20) != 0)) || ((uVar13 & 0x10) != 0)) ||
       ((((uVar13 & 1) != 0 || ((uVar13 & 0x200) != 0)) ||
        (((uVar13 & 0x40) != 0 || ((cRam0000000000359780 == '\0' || (uRam000000000034d27c < 2)))))))
       ) {
      *(undefined4 *)(puVar11 + 0x2f) = 0;
      uVar13 = func_0x(in_stack_00000050);
    }
    else {
      *(undefined4 *)(puVar11 + 0x2f) = 1;
      uVar13 = uRam000000000034d27c;
    }
    puVar11[0x2b] = 0;
    param_3 = param_3 & 0xffffffffffffe000;
    if ((param_3 != 0) && (*(short *)(param_3 + 4) == 0x200)) {
      param_3 = *(ulonglong *)(param_3 + 0x28);
    }
    uVar7 = *puVar1;
    uVar6 = uVar7 + ((ulonglong)uVar13 * 8 + 0xf & 0xfffffffffffffff0);
    if (uVar6 < param_3 + 0x2000) {
      *puVar1 = uVar6;
      *puVar2 = *puVar2 | 1;
      puVar11[0x2b] = uVar7;
    }
    iVar9 = func_0x(puVar11,in_stack_00000048,in_stack_00000050,(ulonglong)uVar13,
                            in_stack_00000058);
    puVar12 = puVar11;
    if (iVar9 == 0) {
      return (undefined8 *)0x0;
    }
    break;
  case 0xb:
    puVar1 = (ulonglong *)(param_3 + 0x28);
    uVar6 = *puVar1;
    *puVar1 = uVar6 + 0x5f0;
    puVar2 = (ushort *)(param_3 + 0x30);
    *puVar2 = *puVar2 | 1;
    if (uVar6 == 0) {
      puVar12 = (undefined8 *)0x0;
    }
    else {
      puVar12 = (undefined8 *)func_0x();
    }
    uVar8 = *(uint *)(*in_stack_00000058 + 4);
    if (((((((uVar8 & 2) == 0) || ((uVar8 & 0x20) != 0)) || ((uVar8 & 0x10) != 0)) ||
         (((uVar8 & 1) != 0 || ((uVar8 & 0x200) != 0)))) || ((uVar8 & 0x40) != 0)) ||
       ((cRam0000000000359780 == '\0' || (uRam000000000034d27c < 2)))) {
      *(undefined4 *)(puVar12 + 0xa9) = 0;
      uVar8 = func_0x(in_stack_00000050);
    }
    else {
      *(undefined4 *)(puVar12 + 0xa9) = 1;
      uVar8 = uRam000000000034d27c;
    }
    puVar12[0xa5] = 0;
    param_3 = param_3 & 0xffffffffffffe000;
    if ((param_3 != 0) && (*(short *)(param_3 + 4) == 0x200)) {
      param_3 = *(ulonglong *)(param_3 + 0x28);
    }
    uVar7 = *puVar1;
    uVar6 = uVar7 + ((ulonglong)uVar8 * 8 + 0xf & 0xfffffffffffffff0);
    if (uVar6 < param_3 + 0x2000) {
      *puVar1 = uVar6;
      *puVar2 = *puVar2 | 1;
      puVar12[0xa5] = uVar7;
    }
    iVar9 = func_0x(puVar12,in_stack_00000048,in_stack_00000050,(ulonglong)uVar8,
                            in_stack_00000058);
    if (iVar9 == 0) {
      return (undefined8 *)0x0;
    }
    goto code_r0x00100bd7;
  case 0x10:
    puVar12 = *(undefined8 **)(param_3 + 0x28);
    *(undefined8 **)(param_3 + 0x28) = puVar12 + 0x12;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (puVar12 != (undefined8 *)0x0) {
      *(undefined4 *)(puVar12 + 1) = 1;
      *puVar12 = 0x27f998;
      puVar12[2] = 0x2000;
      *(undefined4 *)(puVar12 + 3) = 0;
      puVar12[4] = 0;
      *(undefined4 *)(puVar12 + 5) = 0;
      puVar12[6] = 0;
      puVar12[7] = 0;
      puVar12[8] = 0;
      puVar12[9] = 0;
      *puVar12 = 0x286db0;
      puVar11 = puVar12 + 0xd;
      puVar12[0xe] = puVar11;
      *puVar11 = puVar11;
      *puVar12 = 0x2836b0;
      puVar12[0x10] = 0;
      puVar11 = puVar12;
    }
    goto code_r0x001002ba;
  case 0x11:
    puVar12 = *(undefined8 **)(param_3 + 0x28);
    *(undefined8 **)(param_3 + 0x28) = puVar12 + 0x8c;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (puVar12 != (undefined8 *)0x0) {
      *(undefined4 *)(puVar12 + 1) = 1;
      *puVar12 = 0x27f998;
      puVar12[2] = 0x2000;
      *(undefined4 *)(puVar12 + 3) = 0;
      puVar12[4] = 0;
      *(undefined4 *)(puVar12 + 5) = 0;
      puVar12[6] = 0;
      puVar12[7] = 0;
      puVar12[8] = 0;
      puVar12[9] = 0;
      *puVar12 = 0x286db0;
      puVar11 = puVar12 + 0xd;
      puVar12[0xe] = puVar11;
      *puVar11 = puVar11;
      *puVar12 = 0x286b00;
      puVar12[0x12] = 0x29e568;
      *puVar12 = 0x283960;
      puVar12[0x8a] = 0;
      puVar11 = puVar12;
    }
    goto code_r0x001003de;
  case 0x12:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x160;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    goto code_r0x001002ba;
  case 0x13:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x530;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    goto code_r0x0010066f;
  case 0x14:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0xe0;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    goto code_r0x001002ba;
  case 0x15:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x4b0;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
code_r0x001003de:
    auVar3 = *in_stack_00000058;
    uStack_50 = (undefined2)*(undefined4 *)in_stack_00000058[1];
    uStack_4e = (undefined2)((uint)*(undefined4 *)in_stack_00000058[1] >> 0x10);
    if ((auVar3._0_8_ >> 0x20 & 1) == 0) {
      uStack_58 = auVar3._8_8_;
      uStack_60 = auVar3._0_4_;
      lVar10 = func_0x(uStack_60,auVar3._4_4_ & 0xfffffb2f | 0x220,uStack_58,uStack_50,
                               uStack_4e,*(undefined4 *)(in_stack_00000058[1] + 4),
                               *(undefined4 *)(in_stack_00000058[1] + 8),
                               *(undefined4 *)(in_stack_00000058[1] + 0xc),uVar15);
      puVar11[0x8a] = lVar10;
      if (lVar10 == 0) {
        return (undefined8 *)0x0;
      }
    }
code_r0x00100162:
    lVar14 = (ulonglong)uRam000000000003a048 +
             *(longlong *)
              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)uRam000000000034d760 * 8);
    lVar10 = *(longlong *)(lVar14 + 0x100);
    if (lVar10 == 0) {
      func_0x(0);
      lVar10 = *(longlong *)(lVar14 + 0x100);
    }
    puVar11[0x10] = *(undefined8 *)(lVar10 + 600);
    *(undefined4 *)(puVar11 + 0x11) = 1;
    *(uint *)((longlong)puVar11 + 0x8c) = uVar13;
    *(undefined4 *)(puVar11 + 0x87) = 0;
    *(uint *)((longlong)puVar11 + 0x43c) = in_stack_00000040 >> 0x19 & 1;
code_r0x001001c9:
    *(undefined4 *)(puVar11 + 0x88) = 0;
    puVar11[0x89] = 0;
    func_0x(puVar11 + 0x12,uVar4,uVar13,puVar11);
    puVar12 = puVar11;
    break;
  case 0x16:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x1b0;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
code_r0x001002ba:
    auVar3 = *in_stack_00000058;
    uStack_50 = (undefined2)*(undefined4 *)in_stack_00000058[1];
    puVar12 = puVar11;
    if ((auVar3._0_8_ >> 0x20 & 1) == 0) {
      uStack_58 = auVar3._8_8_;
      uStack_60 = auVar3._0_4_;
      lVar10 = func_0x(uStack_60,auVar3._4_4_ & 0xfffffb2f | 0x220,uStack_58,uStack_50,
                               (short)((uint)*(undefined4 *)in_stack_00000058[1] >> 0x10),
                               *(undefined4 *)(in_stack_00000058[1] + 4),
                               *(undefined4 *)(in_stack_00000058[1] + 8),
                               *(undefined4 *)(in_stack_00000058[1] + 0xc),uVar15);
      puVar11[0x10] = lVar10;
      if (lVar10 == 0) {
        return (undefined8 *)0x0;
      }
    }
    break;
  case 0x17:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x580;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
code_r0x0010066f:
    auVar3 = *in_stack_00000058;
    uStack_50 = (undefined2)*(undefined4 *)in_stack_00000058[1];
    if ((auVar3._0_8_ >> 0x20 & 1) == 0) {
      uStack_58 = auVar3._8_8_;
      uStack_60 = auVar3._0_4_;
      lVar10 = func_0x(uStack_60,auVar3._4_4_ & 0xfffffb2f | 0x220,uStack_58,uStack_50,
                               (short)((uint)*(undefined4 *)in_stack_00000058[1] >> 0x10),
                               *(undefined4 *)(in_stack_00000058[1] + 4),
                               *(undefined4 *)(in_stack_00000058[1] + 8),
                               *(undefined4 *)(in_stack_00000058[1] + 0xc),uVar15);
      puVar11[0x8a] = lVar10;
      if (lVar10 == 0) {
        return (undefined8 *)0x0;
      }
    }
code_r0x00100621:
    puVar11[0x10] = 0;
    *(undefined4 *)(puVar11 + 0x11) = 1;
    *(uint *)((longlong)puVar11 + 0x8c) = uVar13;
    puVar11[0x87] = 0;
    goto code_r0x001001c9;
  case 0x1a:
    puVar1 = (ulonglong *)(param_3 + 0x28);
    uVar6 = *puVar1;
    *puVar1 = uVar6 + 0x230;
    puVar2 = (ushort *)(param_3 + 0x30);
    *puVar2 = *puVar2 | 1;
    if (uVar6 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    uVar13 = *(uint *)(*in_stack_00000058 + 4);
    if (((((uVar13 & 2) == 0) || ((uVar13 & 0x20) != 0)) || ((uVar13 & 0x10) != 0)) ||
       ((((uVar13 & 1) != 0 || ((uVar13 & 0x200) != 0)) ||
        (((uVar13 & 0x40) != 0 || ((cRam0000000000359780 == '\0' || (uRam000000000034d27c < 2)))))))
       ) {
      *(undefined4 *)(puVar11 + 0x30) = 0;
      uVar13 = func_0x(in_stack_00000050);
    }
    else {
      *(undefined4 *)(puVar11 + 0x30) = 1;
      uVar13 = uRam000000000034d27c;
    }
    puVar11[0x2c] = 0;
    param_3 = param_3 & 0xffffffffffffe000;
    if ((param_3 != 0) && (*(short *)(param_3 + 4) == 0x200)) {
      param_3 = *(ulonglong *)(param_3 + 0x28);
    }
    uVar7 = *puVar1;
    uVar6 = uVar7 + ((ulonglong)uVar13 * 8 + 0xf & 0xfffffffffffffff0);
    if (uVar6 < param_3 + 0x2000) {
      *puVar1 = uVar6;
      *puVar2 = *puVar2 | 1;
      puVar11[0x2c] = uVar7;
    }
    iVar9 = func_0x(puVar11,in_stack_00000048,in_stack_00000050,(ulonglong)uVar13,
                            in_stack_00000058);
    if (iVar9 == 0) {
      return (undefined8 *)0x0;
    }
    auVar3 = *in_stack_00000058;
    uStack_50 = (undefined2)*(undefined4 *)in_stack_00000058[1];
    puVar12 = puVar11;
    if ((auVar3._0_8_ >> 0x20 & 1) == 0) {
      uStack_58 = auVar3._8_8_;
      uStack_60 = auVar3._0_4_;
      lVar10 = func_0x(uStack_60,auVar3._4_4_ & 0xfffffb2f | 0x220,uStack_58,uStack_50,
                               (short)((uint)*(undefined4 *)in_stack_00000058[1] >> 0x10),
                               *(undefined4 *)(in_stack_00000058[1] + 4),
                               *(undefined4 *)(in_stack_00000058[1] + 8),
                               *(undefined4 *)(in_stack_00000058[1] + 0xc));
      puVar11[0x10] = lVar10;
      if (lVar10 == 0) {
        return (undefined8 *)0x0;
      }
    }
    break;
  case 0x1b:
    puVar1 = (ulonglong *)(param_3 + 0x28);
    uVar6 = *puVar1;
    *puVar1 = uVar6 + 0x600;
    puVar2 = (ushort *)(param_3 + 0x30);
    *puVar2 = *puVar2 | 1;
    if (uVar6 == 0) {
      puVar12 = (undefined8 *)0x0;
    }
    else {
      puVar12 = (undefined8 *)func_0x();
    }
    uVar8 = *(uint *)(*in_stack_00000058 + 4);
    if (((((uVar8 & 2) == 0) || ((uVar8 & 0x20) != 0)) || ((uVar8 & 0x10) != 0)) ||
       ((((uVar8 & 1) != 0 || ((uVar8 & 0x200) != 0)) ||
        (((uVar8 & 0x40) != 0 || ((cRam0000000000359780 == '\0' || (uRam000000000034d27c < 2))))))))
    {
      *(undefined4 *)(puVar12 + 0xaa) = 0;
      uVar8 = func_0x(in_stack_00000050);
    }
    else {
      *(undefined4 *)(puVar12 + 0xaa) = 1;
      uVar8 = uRam000000000034d27c;
    }
    puVar12[0xa6] = 0;
    param_3 = param_3 & 0xffffffffffffe000;
    if ((param_3 != 0) && (*(short *)(param_3 + 4) == 0x200)) {
      param_3 = *(ulonglong *)(param_3 + 0x28);
    }
    uVar7 = *puVar1;
    uVar6 = uVar7 + ((ulonglong)uVar8 * 8 + 0xf & 0xfffffffffffffff0);
    if (uVar6 < param_3 + 0x2000) {
      *puVar1 = uVar6;
      *puVar2 = *puVar2 | 1;
      puVar12[0xa6] = uVar7;
    }
    iVar9 = func_0x(puVar12,in_stack_00000048,in_stack_00000050,(ulonglong)uVar8,
                            in_stack_00000058);
    if (iVar9 == 0) {
      return (undefined8 *)0x0;
    }
    auVar3 = *in_stack_00000058;
    uStack_50 = (undefined2)*(undefined4 *)in_stack_00000058[1];
    if ((auVar3._0_8_ >> 0x20 & 1) == 0) {
      uStack_58 = auVar3._8_8_;
      uStack_60 = auVar3._0_4_;
      lVar10 = func_0x(uStack_60,auVar3._4_4_ & 0xfffffb2f | 0x220,uStack_58,uStack_50,
                               (short)((uint)*(undefined4 *)in_stack_00000058[1] >> 0x10),
                               *(undefined4 *)(in_stack_00000058[1] + 4),
                               *(undefined4 *)(in_stack_00000058[1] + 8),
                               *(undefined4 *)(in_stack_00000058[1] + 0xc));
      puVar12[0x8a] = lVar10;
      if (lVar10 == 0) {
        return (undefined8 *)0x0;
      }
    }
code_r0x00100bd7:
    puVar12[0x10] = 0;
    *(undefined4 *)(puVar12 + 0x11) = 1;
    *(uint *)((longlong)puVar12 + 0x8c) = uVar13;
    puVar12[0x87] = 0;
    *(undefined4 *)(puVar12 + 0x88) = 0;
    puVar12[0x89] = 0;
    func_0x(puVar12 + 0x12,uVar4,uVar13,puVar12);
    break;
  case 0x20:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x100;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    func_0x(puVar11,in_stack_00000058,*(undefined *)(in_stack_00000048 + 0x44));
    puVar12 = puVar11;
    break;
  case 0x22:
    lVar10 = *(longlong *)(param_3 + 0x28);
    *(longlong *)(param_3 + 0x28) = lVar10 + 0x1d0;
    *(ushort *)(param_3 + 0x30) = *(ushort *)(param_3 + 0x30) | 1;
    if (lVar10 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    func_0x(puVar11,in_stack_00000058,*(undefined *)(in_stack_00000048 + 0x44));
    puVar12 = puVar11;
    break;
  case 0x2a:
    puVar1 = (ulonglong *)(param_3 + 0x28);
    uVar6 = *puVar1;
    *puVar1 = uVar6 + 0x2a0;
    puVar2 = (ushort *)(param_3 + 0x30);
    *puVar2 = *puVar2 | 1;
    if (uVar6 != 0) {
      puVar11 = (undefined8 *)func_0x();
    }
    uVar13 = *(uint *)(*in_stack_00000058 + 4);
    if ((((((uVar13 & 2) == 0) || ((uVar13 & 0x20) != 0)) || ((uVar13 & 0x10) != 0)) ||
        (((uVar13 & 1) != 0 || ((uVar13 & 0x200) != 0)))) ||
       (((uVar13 & 0x40) != 0 || ((cRam0000000000359780 == '\0' || (uRam000000000034d27c < 2)))))) {
      *(undefined4 *)(puVar11 + 0x3e) = 0;
      uVar13 = func_0x(in_stack_00000050);
    }
    else {
      *(undefined4 *)(puVar11 + 0x3e) = 1;
      uVar13 = uRam000000000034d27c;
    }
    puVar11[0x3a] = 0;
    param_3 = param_3 & 0xffffffffffffe000;
    if ((param_3 != 0) && (*(short *)(param_3 + 4) == 0x200)) {
      param_3 = *(ulonglong *)(param_3 + 0x28);
    }
    uVar7 = *puVar1;
    uVar6 = uVar7 + ((ulonglong)uVar13 * 8 + 0xf & 0xfffffffffffffff0);
    if (uVar6 < param_3 + 0x2000) {
      *puVar1 = uVar6;
      *puVar2 = *puVar2 | 1;
      puVar11[0x3a] = uVar7;
    }
    iVar9 = func_0x(puVar11,in_stack_00000048,in_stack_00000050,(ulonglong)uVar13,
                            in_stack_00000058);
    if (iVar9 == 0) {
      return (undefined8 *)0x0;
    }
    func_0x(puVar11,in_stack_00000058,*(undefined *)(in_stack_00000048 + 0x44));
    puVar12 = puVar11;
  }
  if (puVar12 != (undefined8 *)0x0) {
    puVar12[10] = 0;
    puVar12[0xc] = 0;
    puVar12[0xb] = 0;
    *(undefined4 *)(puVar12 + 0xf) = 1;
    *(uint *)((longlong)puVar12 + 0x7c) = in_stack_00000040 >> 0x17 & 1;
    *(uint *)(puVar12 + 5) = *(uint *)(puVar12 + 5) | 2;
  }
LAB_:
  return puVar12;
}

