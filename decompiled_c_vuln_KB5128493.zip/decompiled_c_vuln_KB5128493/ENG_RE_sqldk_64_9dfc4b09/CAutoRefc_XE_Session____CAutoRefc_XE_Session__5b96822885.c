
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong *param_1)

{
  int *piVar1;
  int iVar2;
  longlong lVar3;
  
  lVar3 = *param_1;
  if (lVar3 != 0) {
    LOCK();
    piVar1 = (int *)(lVar3 + 0x18);
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      if (*(longlong *)(lVar3 + 0x10) != 0) {
        func_0x(*(undefined8 *)(lVar3 + 0x20),lVar3);
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  return;
}

