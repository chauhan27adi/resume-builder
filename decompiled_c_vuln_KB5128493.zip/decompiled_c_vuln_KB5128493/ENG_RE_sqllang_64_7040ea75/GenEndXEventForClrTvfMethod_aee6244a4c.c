
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2,undefined8 param_3,uint param_4)

{
  longlong lVar1;
  undefined auVar2 [16];
  int iVar3;
  undefined8 uVar4;
  undefined4 *puVar5;
  ulonglong uVar6;
  int iVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong lVar10;
  longlong unaff_GS_OFFSET;
  undefined auStack_4d8 [32];
  undefined8 uStack_4b8;
  undefined8 uStack_4b0;
  undefined8 uStack_4a8;
  undefined8 *puStack_4a0;
  undefined4 *puStack_498;
  undefined4 *puStack_490;
  undefined4 *puStack_488;
  undefined4 *puStack_480;
  undefined4 **ppuStack_478;
  undefined4 **ppuStack_470;
  int *piStack_468;
  undefined8 *puStack_460;
  int *piStack_458;
  int iStack_448;
  int iStack_444;
  undefined4 uStack_440;
  undefined4 uStack_43c;
  undefined4 uStack_438;
  undefined4 uStack_434;
  undefined4 *puStack_430;
  undefined4 *puStack_428;
  undefined4 auStack_420 [2];
  undefined8 uStack_418;
  undefined8 uStack_410;
  ulonglong uStack_408;
  undefined8 uStack_400;
  undefined auStack_3f8 [8];
  undefined4 uStack_3f0;
  undefined4 uStack_3e8;
  undefined4 **ppuStack_3e0;
  undefined *puStack_3d8;
  undefined8 uStack_3d0;
  undefined4 *puStack_3c8;
  undefined4 uStack_3c0;
  undefined4 uStack_3bc;
  undefined4 *puStack_3b8;
  undefined4 uStack_3b0;
  undefined4 uStack_3ac;
  undefined8 uStack_3a8;
  uint uStack_3a0;
  undefined4 uStack_39c;
  undefined8 uStack_398;
  undefined4 uStack_390;
  undefined4 uStack_38c;
  undefined auStack_388 [480];
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined4 uStack_198;
  undefined4 uStack_194;
  ulonglong uStack_190;
  undefined8 uStack_188;
  undefined8 uStack_180;
  undefined4 uStack_178;
  undefined auStack_138 [256];
  ulonglong uStack_38;
  
  ppuStack_3e0 = &puStack_3c8;
  uStack_400 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_4d8;
  auStack_420[0] = 0x5446;
  uVar9 = 0;
  uStack_3f0 = 0x40000;
  uStack_3e8 = 0;
  puStack_3d8 = auStack_388;
  uStack_1a8 = 0;
  uStack_3d0 = 0;
  uStack_1a0 = 0;
  puStack_3c8 = &uStack_198;
  uStack_3c0 = 0x3c;
  uStack_3bc = 3;
  uStack_398 = 0;
  uStack_390 = 0;
  uStack_38c = 9;
  uStack_198 = *(undefined4 *)(param_1 + 0xe8);
  uStack_194 = SUB164(*(undefined (*) [16])(param_1 + 0x28),0xc);
  puStack_3b8 = auStack_420;
  uStack_3b0 = 2;
  uStack_3ac = 7;
  uStack_3a0 = param_4 & 0xfffffffe;
  uStack_39c = 8;
  uStack_188 = *(undefined8 *)
                (*(longlong *)
                  (*(longlong *)
                    ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8) +
                  0x30) + 0x570);
  uVar6 = _DAT_;
  uStack_3a8 = param_3;
  if (*_DAT_ != 0) {
    (*_DAT_)(&uStack_408);
    uVar6 = uStack_408;
  }
  uStack_190 = uVar9;
  if ((uVar6 < param_2) || (uStack_190 = uVar6 - param_2, uVar6 - param_2 != 0xffffffffffffffff)) {
    if (*_DAT_ == 0) {
      uStack_190 = uStack_190 / 10;
    }
    else {
      uStack_190 = (uStack_190 * 1000000) / *_DAT_;
    }
  }
  else {
    uStack_190 = 0xffffffffffffffff;
  }
  if ((((*(char *)(*(longlong *)
                    (*(longlong *)
                      ((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)) +
                    (ulonglong)*_DAT_) + 0x99) != '\0') &&
       (lVar1 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  ((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58))),
       lVar1 != 0)) && (lVar1 = *(longlong *)(lVar1 + 0xa0), uVar9 = 0, lVar1 != 0)) &&
     (uVar9 = *(ulonglong *)(lVar1 + 8), (*(uint *)(uVar9 + 0x20) >> 1 & 1) == 0)) {
    uVar9 = 0;
  }
  puStack_428 = (undefined4 *)0x0;
  lVar1 = *(longlong *)(_DAT_ + 0x10);
  uStack_410 = 0;
  uStack_434 = 0;
  uStack_440 = 0;
  uStack_43c = 0;
  uStack_438 = 0;
  puStack_430 = (undefined4 *)0x0;
  iStack_448 = 0;
  uStack_418 = 0;
  iStack_444 = 0;
  piStack_458 = &iStack_444;
  puStack_460 = &uStack_418;
  piStack_468 = &iStack_448;
  ppuStack_470 = &puStack_430;
  ppuStack_478 = &puStack_428;
  puStack_480 = &uStack_438;
  puStack_488 = &uStack_43c;
  puStack_490 = &uStack_440;
  puStack_498 = &uStack_434;
  puStack_4a0 = &uStack_410;
  uStack_4a8 = CONCAT44(uStack_4a8._4_4_,0x80);
  uStack_4b0 = auStack_138;
  uStack_4b8 = (ulonglong)uStack_4b8._4_4_ << 0x20;
  if (lVar1 == 0) {
    iVar3 = func_0x(uVar9,0,0,1);
  }
  else {
    iVar3 = func_0x();
  }
  puVar5 = puStack_430;
  switch(iVar3) {
  case 1:
    puVar5 = (undefined4 *)0x1da2dc0;
    iVar7 = 0x37;
    break;
  case 2:
    puVar5 = (undefined4 *)0x1da2e60;
    iVar7 = 0x37;
    break;
  case 3:
    puVar5 = (undefined4 *)0x1da2e30;
    iVar7 = 0x11;
    goto code_r0x00100473;
  case 4:
    iVar7 = iStack_448;
    if (lVar1 != 0) {
      iStack_448 = iStack_444 + 3;
      lVar8 = (ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar10 = *(longlong *)(lVar8 + 0x100);
      if (lVar10 == 0) {
        (*pcRam000000000189fc80)(0);
        lVar10 = *(longlong *)(lVar8 + 0x100);
      }
      auVar2._8_8_ = 0;
      auVar2._0_8_ = (longlong)(iStack_448 + 1);
      uVar4 = SUB168(ZEXT816(2) * auVar2,0);
      if (SUB168(ZEXT816(2) * auVar2,8) != 0) {
        uVar4 = 0xffffffffffffffff;
      }
      uStack_4b0 = (undefined *)CONCAT71(uStack_4b0._1_7_,3);
      uStack_4b8 = CONCAT44(uStack_4b8._4_4_,0x142);
      puVar5 = (undefined4 *)
               (*pcRam000000000189fc60)(uVar4,*(undefined8 *)(lVar10 + 1000),1,0x1da2d90);
      puStack_430 = puVar5;
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x1da2e60;
        iVar7 = 0x37;
      }
      else {
        if (puStack_428 != puVar5) {
          (*_DAT_)();
        }
        puStack_428 = puVar5;
        uVar4 = (*pcRam000000000189fad8)();
        uStack_4a8 = uStack_418;
        uStack_4b0 = (undefined *)CONCAT44(uStack_4b0._4_4_,iStack_444);
        uStack_4b8 = 0x1da2e58;
        func_0x(puStack_430,(longlong)(iStack_448 + 1),0x1da2d80,uVar4);
        iVar7 = iStack_448;
      }
    }
    break;
  case 5:
  case 6:
    goto code_r0x0010044b;
  default:
    uStack_4b8 = 0x1b2d750;
    (*_DAT_)(1,0x1eeb510,0x1eede08,0x15c);
code_r0x0010044b:
    iVar7 = iStack_448;
    if (iVar3 == 3) {
code_r0x00100473:
      uStack_180 = 0;
      uStack_178 = 0;
      goto LAB_;
    }
  }
  uStack_180 = CONCAT44(uStack_43c,uStack_440);
  uStack_178 = uStack_438;
LAB_:
  if (lVar1 != 0) {
    ppuStack_3e0[6] = puVar5;
    *(int *)(ppuStack_3e0 + 7) = iVar7 * 2;
    *(undefined4 *)((longlong)ppuStack_3e0 + 0x3c) = 9;
  }
  func_0x(auStack_3f8);
  (*_DAT_)(puStack_428);
  func_0x(uStack_38 ^ (ulonglong)auStack_4d8);
  return;
}

