
/* WARNING: Control flow encountered bad instruction data */

undefined8 FUN_(int *param_1,longlong *param_2)

{
  longlong lVar1;
  longlong lVar2;
  
  if (*(longlong *)(param_1 + 0x14) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *param_2;
  lVar2 = *(longlong *)(param_1 + 2);
  if ((*(int *)(lVar2 + 8) == *(int *)(lVar1 + 8)) &&
     (*(int *)(lVar2 + 0x18) == *(int *)(lVar1 + 0x18))) {
    if (*(int *)(lVar2 + 0x18) == 0xb) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(lVar2 + 0xc) == *(int *)(lVar1 + 0xc)) {
      return *(undefined8 *)(param_1 + 4);
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

