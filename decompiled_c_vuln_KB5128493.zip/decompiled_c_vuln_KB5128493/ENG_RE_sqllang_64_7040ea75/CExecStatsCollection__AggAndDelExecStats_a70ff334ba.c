
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  ulonglong *puVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong *plVar4;
  code *pcVar5;
  char *pcVar6;
  int iVar7;
  longlong unaff_GS_OFFSET;
  
  puVar1 = (ulonglong *)(param_1 + 0x670);
  if (*(int *)puVar1 == 0) {
    LOCK();
    uVar2 = *puVar1;
    if (uVar2 == 0) {
      *puVar1 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (uVar2 == 0) {
      lVar3 = *(longlong *)(param_2 + 0x660);
      plVar4 = *(longlong **)(param_2 + 0x668);
      *(longlong **)(lVar3 + 8) = plVar4;
      *plVar4 = lVar3;
      pcVar6 = _DAT_;
      *(undefined8 *)(param_2 + 0x668) = 0;
      *(undefined8 *)(param_2 + 0x660) = 0;
      if ((*pcVar6 != '\0') && (iVar7 = (*_DAT_)(), iVar7 == (iVar7 / 5) * 5)) {
        func_0x();
      }
      pcVar5 = (code *)swi(3);
      (*pcVar5)();
      return;
    }
  }
  pcVar5 = (code *)swi(3);
  (*pcVar5)();
  return;
}

