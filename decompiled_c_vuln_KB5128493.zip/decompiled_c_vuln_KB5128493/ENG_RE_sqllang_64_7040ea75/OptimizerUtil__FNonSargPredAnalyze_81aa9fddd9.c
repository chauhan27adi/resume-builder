
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  int iVar1;
  ulonglong uVar2;
  code *UNRECOVERED_JUMPTABLE;
  uint *in_stack_00000028;
  undefined *in_stack_00000030;
  
  uVar2 = func_0x();
  if (uVar2 < 0x18000) {
    (*_DAT_)(0x56,0x15,0x11,2);
  }
  *in_stack_00000030 = 0;
  *in_stack_00000028 = *in_stack_00000028 + 1;
  if (*in_stack_00000028 < 0x31) {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x18))(*(longlong **)(param_1 + 0x10));
    if (iVar1 - 0x57U < 0x12) {
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)*(uint *)((longlong)(int)(iVar1 - 0x57U) * 4 + 0x100168) - 0xeff0);
                    /* WARNING: Could not emulate address calculation at 0x0010009c */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

