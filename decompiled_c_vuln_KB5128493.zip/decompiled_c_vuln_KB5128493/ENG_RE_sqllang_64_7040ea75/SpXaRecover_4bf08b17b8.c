
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,longlong param_3,undefined *param_4)

{
  int iVar1;
  int iVar2;
  byte *pbVar3;
  undefined8 uVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 in_stack_ffffffffffffffb8;
  
  lVar6 = 0;
  if (param_3 == 0) {
    *(undefined4 *)(param_4 + 8) = 0;
LAB_:
    in_stack_ffffffffffffffb8 = CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),4);
    (*_DAT_)(0x1d8,1,0x10,1,in_stack_ffffffffffffffb8);
    if (param_3 != 0) goto LAB_;
    in_stack_ffffffffffffffb8 = 0;
    (*_DAT_)(1,0x171c794,0x1712e40,0x1a7,0);
LAB_:
    in_stack_ffffffffffffffb8 =
         CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),
                  (uint)*(ushort *)((undefined8 *)*param_2 + 1));
    (*_DAT_)(2,1,0x10,1,in_stack_ffffffffffffffb8,*(undefined8 *)*param_2,0xe,0x15da468);
    lVar7 = lVar6;
    if (param_3 != 0) goto LAB_;
LAB_:
    in_stack_ffffffffffffffb8 =
         CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),
                  (uint)*(ushort *)((undefined8 *)*param_2 + 1));
    (*_DAT_)(2,1,0x10,1,in_stack_ffffffffffffffb8,*(undefined8 *)*param_2,0x1c,0x16552a0);
    lVar8 = lVar6;
    if (param_3 != 0) goto LAB_;
LAB_:
    in_stack_ffffffffffffffb8 =
         CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),
                  (uint)*(ushort *)((undefined8 *)*param_2 + 1));
    (*_DAT_)(2,1,0x10,1,in_stack_ffffffffffffffb8,*(undefined8 *)*param_2,0x10,0x1655200);
    lVar5 = lVar6;
    if (param_3 != 0) goto LAB_;
  }
  else {
    iVar1 = *(int *)(param_3 + 0x1c);
    iVar2 = *(int *)(param_3 + 0x28);
    *(undefined4 *)(param_4 + 8) = 0;
    if (iVar1 - iVar2 != 4) goto LAB_;
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 1) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      in_stack_ffffffffffffffb8 = 0x15da468;
      (*_DAT_)(2,0xe,0x10,1,0x15da468,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      in_stack_ffffffffffffffb8 = 0x15da468;
      (*_DAT_)(2,0xe,0x10,1,0x15da468,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      in_stack_ffffffffffffffb8 = *(undefined8 *)*param_2;
      (*_DAT_)(5,0x5b,0x10,1,in_stack_ffffffffffffffb8,0x15da468);
    }
    lVar7 = *(longlong *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 2) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      in_stack_ffffffffffffffb8 = 0x16552a0;
      (*_DAT_)(2,0xe,0x10,1,0x16552a0,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      in_stack_ffffffffffffffb8 = 0x16552a0;
      (*_DAT_)(2,0xe,0x10,1,0x16552a0,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      in_stack_ffffffffffffffb8 = *(undefined8 *)*param_2;
      (*_DAT_)(5,0x5b,0x10,1,in_stack_ffffffffffffffb8,0x16552a0);
    }
    lVar8 = *(longlong *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 3) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x10 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      in_stack_ffffffffffffffb8 = 0x1655200;
      (*_DAT_)(2,0xe,0x10,1,0x1655200,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      in_stack_ffffffffffffffb8 = 0x1655200;
      (*_DAT_)(2,0xe,0x10,1,0x1655200,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      in_stack_ffffffffffffffb8 = CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),0x10)
      ;
      (*_DAT_)(0x51,0x3e,0x10,1,in_stack_ffffffffffffffb8,0x1655200);
    }
    lVar5 = *(longlong *)(pbVar3 + 8);
LAB_:
    if (3 < *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28)) {
      pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x18 +
                         (longlong)*(int *)(param_3 + 0x28) * 8);
      if (**(char **)(pbVar3 + 0x18) != DAT_) {
        uVar4 = (*_DAT_)();
        in_stack_ffffffffffffffb8 = 0x1655198;
        (*_DAT_)(2,0xe,0x10,1,0x1655198,uVar4);
      }
      if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
        uVar4 = (*_DAT_)(DAT_);
        in_stack_ffffffffffffffb8 = 0x1655198;
        (*_DAT_)(2,0xe,0x10,1,0x1655198,uVar4);
      }
      if ((*pbVar3 & 1) == 0) {
        in_stack_ffffffffffffffb8 = *(undefined8 *)*param_2;
        (*_DAT_)(5,0x5b,0x10,1,in_stack_ffffffffffffffb8,0x1655198);
      }
      lVar6 = *(longlong *)(pbVar3 + 8);
      goto LAB_;
    }
  }
  in_stack_ffffffffffffffb8 =
       CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),
                (uint)*(ushort *)((undefined8 *)*param_2 + 1));
  (*_DAT_)(2,1,0x10,1,in_stack_ffffffffffffffb8,*(undefined8 *)*param_2,0x10,0x1655198);
LAB_:
  (*_DAT_)(lVar7,lVar8,*(undefined4 *)(lVar5 + 8),lVar6,
                   CONCAT71((int7)((ulonglong)in_stack_ffffffffffffffb8 >> 8),
                            (char)((uint)*(undefined4 *)(param_3 + 0x20) >> 8)) & 0xffffffffffffff01
                  );
  *param_4 = 0;
  return;
}

