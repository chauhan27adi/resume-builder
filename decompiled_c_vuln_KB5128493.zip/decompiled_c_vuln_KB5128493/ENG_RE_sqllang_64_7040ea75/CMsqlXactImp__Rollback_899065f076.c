
void FUN_(longlong param_1)

{
  code *pcVar1;
  
  if (*(longlong *)(param_1 + 0x50) == 0) {
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
  }
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}

