
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1)

{
  longlong unaff_GS_OFFSET;
  undefined8 auStackX_8 [4];
  
  if ((*(byte *)(_DAT_ + 0x1f8) & 1) == 0) {
    if (*(longlong *)
         (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
         (ulonglong)*_DAT_) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)(_DAT_ + 0x1fa) & 0x40) == 0) {
      if (*(longlong *)
           ((ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) !=
          0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*_DAT_ != 0) {
        (*_DAT_)(auStackX_8);
        *(undefined8 *)(param_1 + 0x2a0) = auStackX_8[0];
        func_0x(param_1,0x12);
        (**(code **)(**(longlong **)(param_1 + 0x1c8) + 0x30))(*(longlong **)(param_1 + 0x1c8),1);
        return 0;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

