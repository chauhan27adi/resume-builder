
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  ulonglong uVar4;
  longlong lVar5;
  undefined8 uVar6;
  uint uStackX_8;
  undefined8 uVar7;
  
  lVar5 = (longlong)*(int *)(param_1 + 0x18);
  switch(*(int *)(param_1 + 0x18)) {
  case 1:
    if (*(int *)(param_1 + 0x1c) != 1) {
      *param_2 = (*(int *)(param_1 + 0x1c) != 2) + 0x4d;
      return;
    }
    *param_2 = 0x53;
    return;
  case 2:
    if (*(char *)(*(longlong *)(param_1 + 0x28) + 1) != '8') {
      param_2[4] = 0;
      return;
    }
    uVar4 = (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x28) + 8) * 1000;
    if (uVar4 < 0x100000000) {
      uVar3 = (uint)uVar4;
      if (uVar3 < 0x80000000) {
        param_2[4] = uVar3;
        return;
      }
      param_2[4] = -1;
    }
    (*pcRam0000000001786390)
              (0x101,8,0x10,1,*(undefined4 *)((longlong)*(int *)(param_1 + 0x18) * 0x18 + 0x24359d0)
               ,*(undefined8 *)((longlong)*(int *)(param_1 + 0x18) * 0x18 + 0x24359c8));
    return;
  case 3:
    break;
  case 4:
    uVar4 = (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x28) + 8);
    if (*(int *)(param_1 + 0x20) == 3) {
      uVar4 = uVar4 << 0x14;
      if (uVar4 < 0x100000000) {
        if ((uint)uVar4 < 0x80000000) goto code_r0x0010027a;
        uVar4 = 0xffffffff;
      }
      else {
        uVar4 = (ulonglong)uStackX_8;
      }
      uVar7 = *(undefined8 *)(lVar5 * 0x18 + 0x24359c8);
      uVar1 = *(undefined4 *)(lVar5 * 0x18 + 0x24359d0);
      uVar6 = 4;
    }
    else {
      uVar4 = uVar4 << 10;
      if (uVar4 < 0x100000000) {
        if ((uint)uVar4 < 0x80000000) goto code_r0x0010027a;
        uVar4 = 0xffffffff;
      }
      else {
        uVar4 = (ulonglong)uStackX_8;
      }
      uVar7 = *(undefined8 *)(lVar5 * 0x18 + 0x24359c8);
      uVar1 = *(undefined4 *)(lVar5 * 0x18 + 0x24359d0);
      uVar6 = 5;
    }
    (*pcRam0000000001786390)(0x101,8,0x10,uVar6,uVar1,uVar7);
code_r0x0010027a:
    param_2[3] = (int)((int)uVar4 + ((int)uVar4 >> 0x1f & 0x3ffU)) >> 10;
    return;
  case 5:
    if (*(int *)(param_1 + 0x1c) != 7) {
      iVar2 = 0x4e;
      if (*(int *)(param_1 + 0x1c) == 6) {
        iVar2 = 0x43;
      }
      param_2[1] = iVar2;
      return;
    }
    param_2[1] = 0x47;
    return;
  case 6:
    *(bool *)(param_2 + 5) = *(int *)(*(longlong *)(param_1 + 0x28) + 8) == 0xb9;
    return;
  case 7:
    *(bool *)((longlong)param_2 + 0x15) = *(int *)(*(longlong *)(param_1 + 0x28) + 8) == 0xb9;
    return;
  default:
    (*_DAT_)(1,0x1dd1cc0,0x1dcf550,0xa3d,0x1a13f00);
    return;
  }
  uVar4 = (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x28) + 8);
  if (*(int *)(param_1 + 0x20) == 3) {
    uVar4 = uVar4 << 0x14;
    if (uVar4 < 0x100000000) {
      if ((uint)uVar4 < 0x80000000) goto code_r0x001001a9;
      uVar4 = 0xffffffff;
    }
    else {
      uVar4 = (ulonglong)uStackX_8;
    }
    uVar7 = *(undefined8 *)(lVar5 * 0x18 + 0x24359c8);
    uVar1 = *(undefined4 *)(lVar5 * 0x18 + 0x24359d0);
    uVar6 = 2;
  }
  else {
    uVar4 = uVar4 << 10;
    if (uVar4 < 0x100000000) {
      if ((uint)uVar4 < 0x80000000) goto code_r0x001001a9;
      uVar4 = 0xffffffff;
    }
    else {
      uVar4 = (ulonglong)uStackX_8;
    }
    uVar7 = *(undefined8 *)(lVar5 * 0x18 + 0x24359c8);
    uVar1 = *(undefined4 *)(lVar5 * 0x18 + 0x24359d0);
    uVar6 = 3;
  }
  (*pcRam0000000001786390)(0x101,8,0x10,uVar6,uVar1,uVar7);
code_r0x001001a9:
  param_2[2] = (int)((int)uVar4 + ((int)uVar4 >> 0x1f & 0x3ffU)) >> 10;
  return;
}

