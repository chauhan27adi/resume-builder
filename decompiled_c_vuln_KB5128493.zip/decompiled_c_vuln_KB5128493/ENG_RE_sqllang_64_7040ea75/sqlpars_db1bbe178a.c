
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(void)

{
  longlong lVar1;
  undefined8 unaff_RBX;
  
  lVar1 = func_0x();
  *(undefined8 *)(&stack0x00000038 + -lVar1) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002678 + -lVar1) = unaff_RBX;
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

