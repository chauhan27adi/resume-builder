
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00100a06) */
/* WARNING: Removing unreachable block (ram,0x01486d70) */
/* WARNING: Removing unreachable block (ram,0x00100afd) */
/* WARNING: Removing unreachable block (ram,0x00100c61) */
/* WARNING: Removing unreachable block (ram,0x0010030a) */
/* WARNING: Removing unreachable block (ram,0x00100b14) */
/* WARNING: Removing unreachable block (ram,0x00100ab2) */
/* WARNING: Removing unreachable block (ram,0x01486d01) */
/* WARNING: Removing unreachable block (ram,0x00100946) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(undefined8 param_1,double *param_2,double *param_3,double *param_4,
                     double *param_5,double param_6,double **param_7,undefined4 param_8,
                     undefined4 param_9,double *param_10)

{
  double dVar1;
  double dVar2;
  undefined4 *puVar3;
  longlong lVar4;
  double dVar5;
  double dVar6;
  double *pdVar7;
  double **ppdVar8;
  longlong lVar9;
  undefined8 *puVar10;
  double *pdVar11;
  undefined8 *puVar12;
  uint uVar13;
  ulonglong uVar14;
  double dVar15;
  double dVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  double dVar19;
  undefined unaff_XMM6 [16];
  undefined auVar20 [16];
  undefined4 uVar21;
  double *pdStackX_10;
  double *pdStackX_18;
  double *pdStackX_20;
  double *pdVar22;
  undefined8 uVar23;
  undefined4 uVar24;
  undefined8 uVar25;
  undefined uVar26;
  double dStack_128;
  double adStack_120 [2];
  longlong lStack_110;
  undefined8 uStack_108;
  undefined auStack_100 [16];
  undefined8 *puStack_f0;
  
  dVar6 = _DAT_;
  dVar5 = _DAT_;
  uStack_108 = 0xfffffffffffffffe;
  puVar12 = (undefined8 *)0x0;
  if (*param_3 < 0.0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  auVar20._8_8_ = 0;
  auVar20._0_8_ = *param_3;
  auVar20 = sqrtpd(unaff_XMM6,auVar20);
  dVar19 = auVar20._0_8_;
  if (_DAT_ < dVar19) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar19 < _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((char)param_9 == '\0') {
    if (_DAT_ < *param_2 + _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*param_2 + _DAT_ < _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  pdStackX_10 = param_2;
  pdStackX_18 = param_3;
  pdStackX_20 = param_4;
  dVar15 = (double)func_0x();
  if (dVar5 < dVar15) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar15 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((char)param_8 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar19 = dVar19 * _DAT_;
  if (dVar5 < dVar19) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar19 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar15 = *pdStackX_10;
  dVar16 = dVar15 - dVar19;
  if (dVar5 < dVar16) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar16 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar1 = *param_4;
  if (dVar1 <= dVar16) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar5 < dVar19) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar19 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar16 = dVar15 + dVar19;
  if (dVar5 < dVar16) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar16 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_5 < dVar16) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar5 < dVar19) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar19 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar15 = dVar15 + dVar19;
  if (dVar5 < dVar15) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar15 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar15 = dVar15 - dVar1;
  if (dVar5 < dVar15) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar15 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar15 < 0.0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar5 < dVar15) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar15 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  param_8 = 0x2806;
  lStack_110 = (*_DAT_)(0x108,param_1,0x20a93b0,0x2806,1);
  ppdVar8 = param_7;
  if (lStack_110 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((double)*param_7 == _DAT_) || (*param_3 == 0.0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  param_6 = _DAT_;
  dStack_128 = 0.0;
  adStack_120[0] = _DAT_;
  uVar26 = 1;
  uVar25 = 0;
  uVar24 = 200;
  puVar10 = &param_6;
  uVar23 = 0;
  pdVar11 = &dStack_128;
  pdVar22 = adStack_120;
  lVar9 = func_0x(lStack_110,param_1,0x2a93010);
  pdVar7 = pdStackX_10;
  *(undefined *)(lVar9 + 0x58) = 0;
  if (((double)*ppdVar8 == _DAT_) || (*pdStackX_18 == 0.0)) {
    *(undefined4 *)(lVar9 + 0xa8) = 0x3e00;
    *(undefined8 *)(lVar9 + 0xb0) = 0;
    *(undefined8 *)(lVar9 + 0xb8) = 0;
    *(undefined4 *)(lVar9 + 0xc0) = 0;
    *(double *)(lVar9 + 0xb0) = *pdStackX_10;
    *(byte *)(lVar9 + 0xa0) = *(byte *)(lVar9 + 0xa0) | 2;
    param_9 = 0x2822;
    pdVar11 = (double *)
              (*_DAT_)(0x30,param_1,0x20a93b0,0x2822,1,pdVar11,uVar23,puVar10,uVar24,uVar25,
                               uVar26);
    if (pdVar11 == (double *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    pdStackX_10 = pdVar11;
    func_0x(pdVar11,param_1);
    *pdVar11 = 1.692058632766368e-316;
    pdVar11[3] = 0.0;
    pdVar11[4] = 0.0;
    pdVar11[5] = _DAT_;
    pdVar11[3] = 0.0;
    pdVar11[4] = _DAT_;
    pdVar11[5] = _DAT_;
    puVar3 = (undefined4 *)pdVar11[2];
    *puVar3 = 0x3e03;
    *(undefined8 *)(puVar3 + 2) = 0;
    *(undefined8 *)(puVar3 + 4) = 0;
    puVar3[6] = 0;
    *(undefined *)pdVar11[2] = 0;
    *(double *)((longlong)pdVar11[2] + 8) = *pdVar7;
    lVar4 = *(longlong *)(lVar9 + 0x60);
    uVar13 = *(uint *)(lVar4 + 0x20);
    if (*(longlong *)(lVar4 + 0x28) == 0) {
      uVar23 = func_0x(lVar4 + 0x10,uVar13);
      *(undefined8 *)(lVar4 + 0x28) = uVar23;
      *(uint *)(lVar4 + 0x20) = uVar13;
    }
    if (uVar13 <= *(uint *)(lVar4 + 0x1c)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(double **)(*(longlong *)(lVar4 + 0x28) + (ulonglong)*(uint *)(lVar4 + 0x1c) * 8) = pdVar11;
    *(int *)(lVar4 + 0x1c) = *(int *)(lVar4 + 0x1c) + 1;
  }
  else {
    *(undefined4 *)(lVar9 + 0xa8) = 0x3e00;
    *(undefined8 *)(lVar9 + 0xb0) = 0;
    *(undefined8 *)(lVar9 + 0xb8) = 0;
    *(undefined4 *)(lVar9 + 0xc0) = 0;
    *(double *)(lVar9 + 0xb0) = *param_4;
    *(byte *)(lVar9 + 0xa0) = *(byte *)(lVar9 + 0xa0) | 2;
    dVar19 = *param_4;
    adStack_120[0] = *pdStackX_18;
    dStack_128 = *pdStackX_10;
    param_6 = dVar19;
    puVar10 = (undefined8 *)func_0x(&lStack_110,&dStack_128,adStack_120,&param_6,pdVar22);
    uVar14 = 0;
    dVar15 = dVar15 / _DAT_;
    uVar24 = (int)*puVar10;
    uVar21 = (int)((ulonglong)*puVar10 >> 0x20);
    do {
      if (dVar5 < dVar15) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar15 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      dVar16 = (double)uVar14 * dVar15;
      if (dVar5 < dVar16) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar16 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      dVar16 = dVar1 + dVar16;
      if (dVar5 < dVar16) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar16 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar16 < *pdStackX_20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*param_5 < dVar16) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((puVar12 == (undefined8 *)0x0) || (uVar17 = uVar24, uVar18 = uVar21, dVar16 != dVar19)) {
        param_6 = dVar16 + 0.0;
        if (dVar5 < param_6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (param_6 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        adStack_120[0] = *pdStackX_18;
        dStack_128 = *pdStackX_10;
        pdVar11 = (double *)func_0x(auStack_100,&dStack_128,adStack_120,&param_6,pdVar22);
        dStack_128 = *pdVar11;
        uVar17 = SUB84(dStack_128,0);
        uVar18 = (undefined4)((ulonglong)dStack_128 >> 0x20);
        dStack_128 = dStack_128 - (double)CONCAT44(uVar21,uVar24);
        if (dVar5 < dStack_128) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (dStack_128 < dVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (dStack_128 <= 0.0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        pdVar11 = &dStack_128;
        if (_DAT_ <= dStack_128) {
          pdVar11 = (double *)&DAT_;
        }
        dVar2 = *pdVar11;
        if (dVar2 == 0.0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (0.0 < *param_10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        param_8 = 0x28a2;
        pdVar22 = (double *)0x1;
        dStack_128 = dVar2;
        puVar12 = (undefined8 *)(*_DAT_)(0x30,param_1,0x20a93b0);
        if (puVar12 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        puStack_f0 = puVar12;
        func_0x(puVar12,param_1);
        *puVar12 = 0x20a93e0;
        puVar12[3] = 0;
        puVar12[4] = 0;
        puVar12[5] = _DAT_;
        puVar3 = (undefined4 *)puVar12[2];
        *puVar3 = 0x3e03;
        *(undefined8 *)(puVar3 + 2) = 0;
        *(undefined8 *)(puVar3 + 4) = 0;
        puVar3[6] = 0;
        *(undefined *)puVar12[2] = 0;
        *(double *)(puVar12[2] + 8) = dVar16;
        if (dVar16 == dVar19) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        puVar12[3] = dVar2;
        dVar19 = _DAT_;
        puVar12[4] = 0;
        puVar12[5] = dVar19;
        lVar4 = *(longlong *)(lVar9 + 0x60);
        if (*(longlong *)(lVar4 + 0x28) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(uint *)(lVar4 + 0x20) <= *(uint *)(lVar4 + 0x1c)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined8 **)(*(longlong *)(lVar4 + 0x28) + (ulonglong)*(uint *)(lVar4 + 0x1c) * 8) =
             puVar12;
        *(int *)(lVar4 + 0x1c) = *(int *)(lVar4 + 0x1c) + 1;
        dVar19 = dVar16;
      }
      uVar13 = (int)uVar14 + 1;
      uVar14 = (ulonglong)uVar13;
      uVar24 = uVar17;
      uVar21 = uVar18;
    } while (uVar13 < 199);
  }
  pdStackX_10 = _DAT_;
  func_0x(lVar9,&pdStackX_10);
  pdStackX_10 = *param_7;
  func_0x(lVar9,&pdStackX_10);
  *(undefined4 *)(lVar9 + 0xd8) = 10;
  pdStackX_10 = (double *)0x0;
  func_0x(lVar9 + 0xe0,&pdStackX_10);
  *(undefined8 *)(lVar9 + 0x78) = 0;
  return lVar9;
}

