
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,longlong param_3,int param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 *param_7,undefined8 *param_8)

{
  undefined auVar1 [16];
  undefined8 uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  uint uVar6;
  longlong *plVar7;
  uint uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  uint uVar11;
  longlong lVar12;
  undefined8 uStack_c8;
  undefined4 uStack_c0;
  undefined8 uStack_b8;
  undefined uStack_b0;
  int iStack_ac;
  uint uStack_a8;
  longlong lStack_a0;
  int iStack_98;
  undefined8 uStack_90;
  undefined8 *puStack_88;
  longlong lStack_80;
  ulonglong uStack_78;
  longlong lStack_70;
  undefined8 *puStack_68;
  undefined8 *puStack_60;
  undefined8 uStack_58;
  
  uStack_58 = 0xfffffffffffffffe;
  if (param_4 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar10 = 0;
  iStack_98 = 0;
  uVar11 = *(uint *)(param_3 + 0x18);
  uStack_b0 = 0;
  iStack_ac = 0;
  uStack_a8 = 1;
  if (uVar11 != 0) {
    uStack_a8 = uVar11;
  }
  lStack_a0 = 0;
  uStack_c0 = 1;
  uStack_c8 = 0x1ebe218;
  uVar2 = SUB168(ZEXT816(8) * ZEXT416(uVar11),0);
  if (SUB168(ZEXT816(8) * ZEXT416(uVar11),8) != 0) {
    uVar2 = 0xffffffffffffffff;
  }
  uStack_b8 = param_1;
  uStack_90 = param_1;
  lStack_80 = (*_DAT_)(uVar2,param_1,0x1ec2448,0x647,1);
  uVar6 = 0;
  uVar9 = uVar10;
  if (uVar11 != 0) {
    do {
      lVar12 = *(longlong *)(*(longlong *)(param_3 + 0x20) + (longlong)(int)uVar9 * 8);
      if ((*(byte *)(*(longlong *)(lVar12 + 0x50) + 0x28) & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(longlong *)(lStack_80 + uVar10 * 8) = lVar12;
      uVar6 = (int)uVar10 + 1;
      uVar10 = (ulonglong)uVar6;
      uVar8 = (int)uVar9 + 1;
      param_1 = uStack_90;
      uVar9 = (ulonglong)uVar8;
    } while (uVar8 < uVar11);
  }
  if ((param_4 != 0) || (iStack_ac == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(int *)(param_2 + 8) = *(int *)(param_2 + 8) + 1;
  puVar3 = (undefined8 *)(*_DAT_)(0x28,param_1,0x1ec2448,0x671,1);
  if (puVar3 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar3 = 0x1df8fe0;
  *(undefined4 *)(puVar3 + 1) = 1;
  *puVar3 = 0x1d743d0;
  puVar3[2] = param_1;
  *puVar3 = 0x1d49ef8;
  *puVar3 = 0x1d4ab20;
  puVar3[3] = 0;
  *(undefined *)(puVar3 + 4) = 1;
  puStack_60 = puVar3;
  uVar2 = func_0x(1,param_1,&uStack_c8);
  puVar4 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x1ec2448,0x674,1);
  if (puVar4 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar4 = 0x1df8fe0;
  *(undefined4 *)(puVar4 + 1) = 1;
  *puVar4 = 0x1ebe150;
  puVar4[0xc] = 0;
  puVar4[0xd] = 0;
  puVar4[0xe] = 0;
  puVar4[0xf] = 0;
  puVar4[0x11] = _DAT_;
  puVar4[0x12] = 0;
  puVar4[0x13] = 0;
  puVar4[0x14] = 0;
  *(undefined4 *)(puVar4 + 3) = 2;
  puVar4[4] = puVar4 + 5;
  puVar4[5] = param_2;
  *(undefined8 *)(puVar4[4] + 8) = uVar2;
  puVar4[2] = puVar3;
  puVar4[10] = 0;
  puVar4[0xb] = 0;
  puVar4[0x10] = 0;
  puStack_88 = puVar4;
  puStack_60 = puVar4;
  func_0x(&uStack_b8);
  uVar10 = CONCAT44(0,uVar6);
  auVar1._8_8_ = 0;
  auVar1._0_8_ = uVar10;
  uVar2 = SUB168(ZEXT816(8) * auVar1,0);
  if (SUB168(ZEXT816(8) * auVar1,8) != 0) {
    uVar2 = 0xffffffffffffffff;
  }
  uStack_78 = uVar10;
  plVar5 = (longlong *)(*_DAT_)(uVar2,uStack_90,0x1ec2448,0x683,1);
  *(int *)(puVar4 + 1) = *(int *)(puVar4 + 1) + 1;
  puVar3 = puVar4;
  uVar9 = uVar10;
  if (uVar6 != 0) {
    lVar12 = lStack_80 - (longlong)plVar5;
    plVar7 = plVar5;
    do {
      func_0x(uStack_90,puVar3,*(undefined8 *)(lVar12 + (longlong)plVar7),0,param_5,param_6,
                      &puStack_68,&lStack_70);
      *plVar7 = lStack_70;
      puVar3 = puVar3 + 1;
      *(int *)puVar3 = *(int *)puVar3 + -1;
      if (*(int *)puVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar7 = plVar7 + 1;
      uVar10 = uVar10 - 1;
      puVar4 = puStack_88;
      puVar3 = puStack_68;
      uVar9 = uStack_78;
    } while (uVar10 != 0);
  }
  *param_7 = puVar3;
  puVar4 = puVar4 + 1;
  *(int *)puVar4 = *(int *)puVar4 + -1;
  if (*(int *)puVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar10 = 0;
  if (uVar6 != 0) {
    do {
      if (plVar5[uVar10] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar11 = (int)uVar10 + 1;
      uVar10 = (ulonglong)uVar11;
    } while (uVar11 < uVar6);
  }
  if (iStack_ac == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = func_0x(1,uStack_90,&uStack_c8);
  *param_8 = uVar2;
  plVar7 = plVar5;
  if (uVar6 != 0) {
    do {
      if (*plVar7 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar9 = uVar9 - 1;
      plVar7 = plVar7 + 1;
    } while (uVar9 != 0);
  }
  if (iStack_98 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  (*_DAT_)(lStack_80);
  (*_DAT_)(plVar5);
  uStack_c8 = 0x1df8fe0;
  func_0x(&uStack_b8);
  if (lStack_a0 != 0) {
    (*_DAT_)();
  }
  return;
}

