
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(char *param_1,longlong *param_2,longlong *param_3,char param_4,undefined4 param_5)

{
  undefined2 uVar1;
  ulonglong *puVar2;
  int iVar3;
  bool bVar4;
  ulonglong uVar5;
  char cVar6;
  byte bVar7;
  uint uVar8;
  longlong lVar9;
  undefined4 *puVar10;
  byte *pbVar11;
  longlong lVar12;
  ulonglong uVar13;
  undefined8 uVar14;
  int iVar15;
  undefined8 uVar16;
  ulonglong uVar17;
  uint uVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  longlong unaff_GS_OFFSET;
  undefined8 in_stack_ffffffffffffff38;
  undefined4 uVar21;
  undefined8 in_stack_ffffffffffffff40;
  undefined4 uVar22;
  undefined8 in_stack_ffffffffffffff48;
  undefined4 uVar23;
  undefined uStack_a8;
  undefined2 uStack_a7;
  undefined uStack_a5;
  undefined4 uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined2 uStack_8c;
  undefined uStack_8a;
  undefined auStack_89 [16];
  undefined uStack_79;
  undefined8 uStack_78;
  undefined8 uStack_70;
  int iStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined uStack_48;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  cVar6 = *param_1;
  if (cVar6 == '\x1b') {
    return;
  }
  uVar20 = 0;
  lVar12 = *(longlong *)
            (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             0x50 + (ulonglong)*_DAT_);
  uVar17 = uVar20;
  if (lVar12 != 0) {
    uVar17 = (ulonglong)*(ushort *)(lVar12 + 600);
  }
  (**(code **)(_DAT_ + 0x20))(uVar17);
  uVar21 = (undefined4)((ulonglong)in_stack_ffffffffffffff38 >> 0x20);
  uVar23 = (undefined4)((ulonglong)in_stack_ffffffffffffff48 >> 0x20);
  uVar22 = (undefined4)((ulonglong)in_stack_ffffffffffffff40 >> 0x20);
  switch(cVar6) {
  case '\x01':
  case '\x02':
  case '\t':
    puVar2 = *(ulonglong **)(param_1 + 0x28);
    if ((*puVar2 & 0xfffffffffb7fffff) != 0) {
      uVar17 = 1;
      do {
        if (((*puVar2 & uVar17) != 0) && (uVar17 != 0x800000)) {
          lVar12 = 0;
          if (lRam0000000001ea76b0 != 0) {
            lVar9 = 0;
            do {
              if (*(ulonglong *)(lVar9 + 0x1ea76c0) == uVar17) {
                uVar14 = *(undefined8 *)(lVar12 * 0x20 + 0x1ea76b0);
                goto code_r0x00100206;
              }
              lVar12 = lVar12 + 1;
              lVar9 = lVar12 * 0x20;
            } while (*(longlong *)(lVar9 + 0x1ea76b0) != 0);
          }
          uVar14 = 0;
code_r0x00100206:
          func_0x(0x58,3,*(undefined4 *)(param_1 + 0xcc),uVar14);
        }
        uVar21 = (undefined4)((ulonglong)in_stack_ffffffffffffff38 >> 0x20);
        uVar23 = (undefined4)((ulonglong)in_stack_ffffffffffffff48 >> 0x20);
        uVar22 = (undefined4)((ulonglong)in_stack_ffffffffffffff40 >> 0x20);
        uVar17 = uVar17 * 2;
      } while (uVar17 != 0);
    }
    if (((*(uint *)(param_1 + 4) & 0x10) == 0) &&
       (((*(uint *)(param_1 + 4) & 0x20) != 0 || (cVar6 != '\x01')))) {
      bVar4 = false;
    }
    else {
      bVar4 = true;
    }
    if (((*(byte *)(puVar2 + 0x1e) & 0x40) != 0) &&
       (cVar6 = (*pcRam0000000001e02968)(param_5), cVar6 == '\0')) {
      uVar14 = 0x46;
      break;
    }
    lVar12 = lRam0000000001451b10;
    if ((*(char *)(lRam0000000001e13828 + 0x45a) == '\0') ||
       ((*(byte *)(lRam0000000001e06480 + 0x4de) & 0x20) != 0)) {
      bVar7 = *(byte *)(puVar2 + 0x1e);
      if ((bVar7 & 0x40) != 0) {
        if (param_4 != '\0') {
          uVar14 = 0x48;
          break;
        }
        goto code_r0x00100295;
      }
code_r0x001002c3:
      if (bVar4) {
        uVar14 = 0x4b;
        break;
      }
    }
    else {
      bVar7 = *(byte *)(puVar2 + 0x1e);
code_r0x00100295:
      if ((bVar7 & 0x40) == 0) goto code_r0x001002c3;
      if (!bVar4) {
        uVar14 = 0x49;
        break;
      }
    }
    if (puVar2[0x12] == 0) {
      if (puVar2[0x16] != 0) {
        iVar15 = *(int *)(param_1 + 0xcc);
        if (lRam0000000001451b10 == 0) {
          lVar9 = lRam0000000001451b10;
          (*pcRam00000000011f7668)(1,0x1845d50,0x18411d8,0x7a,0);
          uVar21 = (undefined4)((ulonglong)lVar9 >> 0x20);
        }
        if (iVar15 != 0) {
          func_0x
                    (iVar15,0x6b,0x5e,0x10,CONCAT44(uVar21,0x47),CONCAT44(uVar22,0x8a5e),lVar12,
                     0x8a9e);
          return;
        }
        (*pcRam00000000011f76e0)
                  (0x6b,0x5e,0x10,0x47,CONCAT44(uVar21,0x8a5e),lVar12,CONCAT44(uVar23,0x8a9e));
        return;
      }
      if ((puVar2[0x19] == 0) && (puVar2[0x1b] == 0)) {
        if (param_2 == (longlong *)0x0) {
          return;
        }
        if ((bVar7 & 0x40) != 0) {
          if (param_4 == '\0') {
            return;
          }
          if (!bVar4) {
            return;
          }
          uVar18 = 1;
          iVar15 = (**(code **)(*param_3 + 0xd0))(param_3,0);
          if (iVar15 == 0) {
            return;
          }
          do {
            uVar14 = (**(code **)(*param_3 + 0xe0))(param_3,uVar18,0);
            uStack_a0 = 0xffffffffffffffff;
            uStack_a7 = 0;
            uStack_a5 = 0;
            uStack_94 = 0;
            uStack_a8 = 0;
            uStack_a4 = 0;
            uStack_98 = 0;
            uStack_8c = 0;
            uStack_8a = 0;
            uStack_79 = 0;
            auStack_89 = ZEXT816(0);
            func_0x(&uStack_a8,uVar14);
            if ((auStack_89 & (undefined  [16])0x1000000000000) != (undefined  [16])0x0) {
              (*pcRam00000000011f76e0)(0x1a2,0x2c,0x10,1);
            }
            uVar18 = uVar18 + 1;
            uVar8 = (**(code **)(*param_3 + 0xd0))(param_3,0);
          } while (uVar18 <= uVar8);
          return;
        }
        uStack_78 = 0;
        uStack_70 = 0;
        iStack_68 = 0;
        uStack_60 = 0;
        uStack_58 = 0;
        uStack_50 = 0;
        uStack_48 = 0;
        uVar17 = puVar2[0x15];
        if (uVar17 == 0) {
          return;
        }
        uVar20 = *(ulonglong *)(uVar17 + 8);
        if (uVar20 == uVar17) {
          return;
        }
        do {
          if (uVar20 == 0) {
            return;
          }
          lVar12 = *param_2;
          uVar21 = *(undefined4 *)(uVar20 + 0x18);
          uVar14 = *(undefined8 *)(uVar20 + 0x10);
          if ((char)*(byte *)(lVar12 + 0x1a0) < '\0') {
            puVar10 = (undefined4 *)0x1e6ed18;
          }
          else {
            if ((*(byte *)(lVar12 + 0x1a0) & 8) == 0) {
              uVar1 = *(undefined2 *)
                       (*(longlong *)
                         (*(longlong *)
                           ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
                         + 0x50) + 8);
            }
            else {
              uVar1 = *(undefined2 *)(lVar12 + 0x130);
            }
            puVar10 = (undefined4 *)(*pcRam00000000011f83f8)(uVar1);
          }
          uStack_2c = *puVar10;
          uStack_40 = uVar14;
          uStack_38 = uVar21;
          uStack_30 = (*pcRam00000000011f8730)(&uStack_2c,uVar14,uVar21);
          pbVar11 = (byte *)func_0x(lVar12 + 0x140,&uStack_40);
          if ((pbVar11 != (byte *)0x0) ||
             (pbVar11 = (byte *)func_0x(param_2,uVar14,uVar21,1),
             pbVar11 != (byte *)0x0)) {
            if (((pbVar11[0x25] & 1) != 0) && ((pbVar11[0x25] & 8) == 0)) {
              (*pcRam00000000011f76e0)(0x7b,0x35,0x10,1);
            }
            if (((~pbVar11[1] & 1) == 0) || (cRam0000000001e13579 != '\0')) {
              if (((*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar11 + 0x134fe00) + 0x1384e30) !=
                    '\0') ||
                  ((((pbVar11[1] & 0x10) != 0 && (*pbVar11 != 0xf0)) &&
                   (*(char *)((ulonglong)*(byte *)((ulonglong)pbVar11[0x1b] + 0x134fe00) + 0x1384e30
                             ) != '\0')))) &&
                 (cVar6 = (*pcRam00000000011f8740)(*(undefined4 *)(pbVar11 + 0x14)), cVar6 != '\0'))
              {
                uVar16 = 3;
                uVar14 = 0x9b;
                goto code_r0x00100839;
              }
            }
            else {
              func_0x(6,3,*(undefined4 *)(param_1 + 0xcc));
            }
            if (-1 < *(char *)(puVar2 + 0x1e)) {
              func_0x(&uStack_78,pbVar11,0,0,0xffffffff);
              iVar15 = (uStack_70._4_4_ + 7U >> 3) + (int)uStack_78;
              if ((int)uStack_70 != 0) {
                iVar15 = (iVar15 + 1U & 0xfffffffe) + ((int)uStack_70 + 1) * 2;
              }
              iVar3 = 0;
              if (iStack_68 != 0) {
                iVar3 = iStack_68;
              }
              if (0x9c4 < (uint)((iVar3 + -1 + iVar15 & -iVar3) + uStack_78._4_4_)) {
                (*pcRam00000000011f76e0)(0x19d,0x2d,0x10,1,0x9c4);
              }
            }
          }
          uVar20 = *(ulonglong *)(uVar20 + 8);
          if (uVar20 == puVar2[0x15]) {
            return;
          }
        } while( true );
      }
      goto code_r0x001000c7;
    }
    uVar16 = 3;
    uVar14 = 1;
    goto code_r0x00100839;
  case '\x03':
    if (cRam0000000001e13580 == '\0') {
      func_0x(9,0,*(undefined4 *)(param_1 + 0xcc),0);
    }
    uVar18 = *(uint *)(param_1 + 4);
    if ((uVar18 >> 10 & 1) != 0) {
      func_0x(0x87,0,*(undefined4 *)(param_1 + 0xcc),0);
      uVar18 = *(uint *)(param_1 + 4);
    }
    if ((uVar18 & 0x30000) == 0x30000 || (uVar18 & 0xc0000) == 0xc0000) {
      func_0x(0x8f,0,*(undefined4 *)(param_1 + 0xcc),0);
      uVar18 = *(uint *)(param_1 + 4);
    }
    if ((uVar18 & 0x53000) != 0) {
      func_0x(0x8d,0,*(undefined4 *)(param_1 + 0xcc),0);
      uVar18 = *(uint *)(param_1 + 4);
    }
    if ((uVar18 & 0xa0000) == 0) {
      return;
    }
    uVar14 = 0x8e;
    break;
  case '\x04':
    if (cRam0000000001e13580 == '\0') {
      func_0x(10,0,*(undefined4 *)(param_1 + 0xcc),0);
    }
    if ((*(uint *)(param_1 + 4) & 0x400) == 0) {
      return;
    }
  case '\x14':
    uVar14 = 0x87;
    break;
  default:
    goto LAB_;
  case '\n':
    if (cRam0000000001e13580 != '\0') {
      return;
    }
    uVar14 = 10;
    break;
  case '\v':
    if (cRam0000000001e1357c != '\0') {
      return;
    }
    uVar14 = 3;
    break;
  case '\f':
  case '\x0e':
    if (*(char *)(lRam0000000001e13828 + 0x45a) == '\0') {
      return;
    }
    if ((*(byte *)(lRam0000000001e06480 + 0x4de) & 0x20) != 0) {
      return;
    }
    if (param_4 == '\0') {
      return;
    }
    if (param_3 == (longlong *)0x0) {
      return;
    }
    lVar12 = (**(code **)(*param_3 + 0xe8))(param_3,1);
    if (lVar12 == 0) {
      return;
    }
    (*pcRam00000000011f76e0)(0x7b,0x31,0x10,1,CONCAT44(uVar21,2));
    return;
  case '\x0f':
    uVar14 = 7;
    break;
  case '\x10':
code_r0x001000c7:
    uVar14 = 0;
    break;
  case '\x11':
    (*pcRam00000000011f76e0)(0x7b,0x37,0x10,1);
    return;
  case '\x12':
    uVar14 = 0x84;
    break;
  case '\x13':
    uVar14 = 0x86;
    break;
  case '\x15':
    uVar14 = 4;
    break;
  case '\x16':
    uVar14 = 0x83;
    break;
  case '\x18':
    uVar14 = 0x85;
    break;
  case '\x19':
    uVar14 = 5;
    break;
  case '\x1c':
    puVar2 = *(ulonglong **)(param_1 + 0x30);
    if ((*puVar2 & 0xffffffffff7fffff) == 0) {
      return;
    }
    uVar17 = 1;
    do {
      if (((*puVar2 & uVar17) != 0) &&
         (uVar5 = uVar20, uVar13 = uVar20, lVar12 = lRam0000000001ea76b0, uVar17 != 0x800000)) {
        while (uVar19 = uVar20, lVar12 != 0) {
          if (*(ulonglong *)(uVar13 + 0x1ea76c0) == uVar17) {
            uVar19 = *(ulonglong *)(uVar5 * 0x20 + 0x1ea76b0);
            break;
          }
          uVar13 = (uVar5 + 1) * 0x20;
          uVar5 = uVar5 + 1;
          lVar12 = *(longlong *)(uVar13 + 0x1ea76b0);
        }
        func_0x(0x58,3,*(undefined4 *)(param_1 + 0xcc),uVar19);
      }
      uVar17 = uVar17 * 2;
      if (uVar17 == 0) {
        return;
      }
    } while( true );
  case '\x1f':
    uVar14 = 0x8b;
    break;
  case '(':
    uVar14 = 0x9d;
    break;
  case '*':
    uVar14 = 0x9f;
    break;
  case '+':
    uVar14 = 0xa0;
  }
  uVar16 = 0;
code_r0x00100839:
  func_0x(uVar14,uVar16,*(undefined4 *)(param_1 + 0xcc),0);
LAB_:
  return;
}

