
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,longlong param_2)

{
  if ((param_2 != 0) && (*(longlong *)(param_2 + 0x18) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(param_2 + 0x18) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(longlong *)(param_1 + 0x28) == 0) && (*(uint *)(param_1 + 0x1c) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(uint *)(param_1 + 0x1c) <= *(uint *)(param_1 + 0x20)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

