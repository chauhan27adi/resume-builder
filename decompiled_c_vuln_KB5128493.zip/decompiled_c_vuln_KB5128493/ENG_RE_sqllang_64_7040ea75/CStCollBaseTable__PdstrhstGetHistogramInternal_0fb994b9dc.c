
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(longlong *param_1,undefined8 *param_2,longlong param_3,longlong param_4,
                     longlong param_5,char param_6)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong unaff_GS_OFFSET;
  undefined8 *puStack_a0;
  undefined8 uStack_98;
  byte abStack_90 [16];
  short sStack_80;
  undefined8 uStack_70;
  
  uStack_70 = 0xfffffffffffffffe;
  if (param_4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = (**(code **)(*param_1 + 0x1d0))();
  cVar1 = func_0x(uVar2,param_2);
  if ((cVar1 != '\0') && (*(longlong *)(param_1[0x1e] + 0x48) != 0)) {
    uVar2 = (**(code **)*param_2)(param_2);
    abStack_90[0] = 0;
    sStack_80 = 0;
    func_0x(uVar2,abStack_90);
    if ((sStack_80 != -1) &&
       (*(char *)((ulonglong)*(byte *)((ulonglong)abStack_90[0] + 0x1ec2bd0) + 0x2986b58) == '\0'))
    {
      if (param_3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar4 = *(longlong *)
               (*(longlong *)
                 ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8) +
               0x48);
      plVar3 = (longlong *)(lVar4 + 0x310);
      if (lVar4 == 0) {
        plVar3 = (longlong *)0x318;
      }
      if ((param_6 != '\0') && ((*(uint *)(*plVar3 + 0x20) >> 10 & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uStack_98 = 0;
      puStack_a0 = param_2;
      lVar4 = func_0x(param_1 + 10,abStack_90,&puStack_a0);
      lVar4 = *(longlong *)(lVar4 + 8);
      if (lVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(int *)(lVar4 + 8) = *(int *)(lVar4 + 8) + 1;
      cVar1 = func_0x(param_1[0x1e]);
      if (cVar1 == '\0') {
        return lVar4;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

