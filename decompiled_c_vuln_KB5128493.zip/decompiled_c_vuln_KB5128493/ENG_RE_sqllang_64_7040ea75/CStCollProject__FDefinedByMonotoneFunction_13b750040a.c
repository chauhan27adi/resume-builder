
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uStackX_10;
  
  uStackX_10 = param_2;
  lVar1 = func_0x(*(undefined8 *)(param_1 + 0x50),&uStackX_10);
  if (lVar1 == 0) {
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x48) + 0x108) + 0xa8))();
    (**(code **)(*plVar2 + 0xe0))(plVar2,param_2,param_3,param_4,param_5);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

