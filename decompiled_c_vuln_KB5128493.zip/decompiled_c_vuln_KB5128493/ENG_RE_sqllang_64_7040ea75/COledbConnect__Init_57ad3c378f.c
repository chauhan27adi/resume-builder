
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4,
                 char param_5)

{
  byte bVar1;
  undefined uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 uVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong lVar9;
  ulonglong uVar10;
  int iVar11;
  longlong unaff_GS_OFFSET;
  undefined auStackX_18 [16];
  undefined8 in_stack_ffffffffffffff78;
  undefined8 in_stack_ffffffffffffff80;
  undefined4 uVar12;
  undefined8 uStack_60;
  undefined4 uStack_58;
  code **ppcStack_50;
  longlong *plStack_48;
  longlong *plStack_40;
  
  uVar12 = (undefined4)((ulonglong)in_stack_ffffffffffffff80 >> 0x20);
  uVar3 = (undefined4)((ulonglong)in_stack_ffffffffffffff78 >> 0x20);
  ppcStack_50 = (code **)0xf45560;
  iVar11 = 0;
  plStack_48 = (longlong *)0x0;
  plStack_40 = (longlong *)0x0;
  lVar9 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar8 = *(longlong *)(lVar9 + 0x100);
  if (lVar8 == 0) {
    (*_DAT_)(0);
    lVar8 = *(longlong *)(lVar9 + 0x100);
  }
  uVar5 = *(undefined8 *)(lVar8 + 1000);
  func_0x(&plStack_40,0x12bed70,0x26);
  (**ppcStack_50)(&ppcStack_50,uVar5);
  uVar5 = (*_DAT_)(param_2,param_3,param_4);
  *(undefined8 *)(param_1 + 0x80) = uVar5;
  uStack_60 = param_3;
  uStack_58 = param_4;
  plVar6 = (longlong *)(**(code **)(*plStack_48 + 0x88))(plStack_48,&uStack_60,0);
  if (plVar6 == (longlong *)0x0) {
    uVar5 = param_3;
    (*_DAT_)(0x48,2,0xb,2,CONCAT44(uVar3,param_4),param_3);
    uVar12 = (undefined4)((ulonglong)uVar5 >> 0x20);
  }
  uVar2 = 0xc1;
  if (param_5 != '\0') {
    uVar2 = 0xe0;
  }
  *(undefined *)(param_1 + 0x78) = uVar2;
  uVar3 = (**(code **)*plVar6)(plVar6);
  *(undefined4 *)(param_1 + 0x50) = uVar3;
  (**(code **)(*plVar6 + 0x10))(plVar6,param_1 + 0x5c);
  *(byte *)(param_1 + 0x8e) = *(byte *)(param_1 + 0x8e) & 0xfe;
  *(byte *)(param_1 + 0x8e) = *(byte *)(param_1 + 0x8e) | *(int *)(param_1 + 0x5c) != 0;
  puVar7 = (undefined8 *)(**(code **)(*plVar6 + 0x18))(plVar6,auStackX_18);
  *(undefined8 *)(param_1 + 0x70) = *puVar7;
  puVar7 = (undefined8 *)(**(code **)(*plVar6 + 0x28))(plVar6);
  func_0x(param_1,param_2,*puVar7);
  lVar8 = *(longlong *)(param_1 + 8);
  lVar9 = -1;
  do {
    lVar9 = lVar9 + 1;
  } while (*(short *)(lVar8 + lVar9 * 2) != 0);
  uVar10 = (ulonglong)(longlong)((int)lVar9 * 2) >> 1;
  iVar4 = (*_DAT_)(1,0,lVar8,uVar10 & 0xffffffff,0x10e9f38,CONCAT44(uVar12,8));
  if (iVar4 == 2) {
LAB_:
    uVar3 = 0;
    (*_DAT_)(1,0x1344e80,0x133a518,0x33f,0);
  }
  else {
    uVar3 = 0;
    iVar4 = (*_DAT_)(1,0,lVar8,uVar10 & 0xffffffff,0x10e9f98,10);
    if (iVar4 == 2) goto LAB_;
  }
  (**(code **)(*plVar6 + 0x30))(plVar6,param_2,param_1 + 0x28);
  (**(code **)(*plVar6 + 0x40))(plVar6,param_2,param_1 + 0x30);
  (**(code **)(*plVar6 + 0x50))(plVar6,param_2,param_1 + 0x20);
  (**(code **)(*plVar6 + 0x60))(plVar6,param_2,param_1 + 0x38);
  if (*(int *)(param_1 + 0x60) == 0) {
    lVar8 = (**(code **)(**_DAT_ + 0x1f8))();
    *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(lVar8 + 0x44);
  }
  if (*(int *)(param_1 + 100) == 0) {
    lVar8 = (**(code **)(**_DAT_ + 0x1f8))();
    *(undefined4 *)(param_1 + 100) = *(undefined4 *)(lVar8 + 0x6c);
  }
  if (plStack_48 != (longlong *)0x0) {
    (**(code **)*plStack_48)(plStack_48,1);
  }
  plStack_48 = (undefined8 *)0x0;
  if (((plStack_40 != (longlong *)0x0) && (lVar8 = (**(code **)(*plStack_40 + 0x48))(), lVar8 != 0))
     && (plStack_40 != (longlong *)0x0)) {
    (**(code **)(*plStack_40 + 0x20))();
  }
  bVar1 = *(byte *)(param_1 + 0x68);
  if ((char)bVar1 < '\0') {
    for (puVar7 = *(undefined8 **)
                   (*(longlong *)
                     (*(longlong *)
                       ((ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                     0x80) + 0x1f0); puVar7 != (undefined8 *)0x0; puVar7 = (undefined8 *)*puVar7) {
      if ((*(int *)(puVar7 + 1) != 0) && ((*(uint *)(puVar7 + 3) >> 4 & 1) == 0)) {
        if (iVar11 == 0) {
          if ((*(uint *)(puVar7 + 3) & 1) != 0) goto LAB_;
          break;
        }
        iVar11 = iVar11 + -1;
      }
    }
  }
  else {
LAB_:
    if (param_5 == '\0') {
      bVar1 = bVar1 & 2;
    }
    else {
      bVar1 = bVar1 & 0x10;
    }
    if (bVar1 != 0) goto LAB_;
  }
  uVar5 = 0x12bed98;
  if (param_5 != '\0') {
    uVar5 = 0xf5c810;
  }
  (*_DAT_)(0x4a,0xb,0x10,1,CONCAT44(uVar3,param_4),param_3,uVar5);
LAB_:
  func_0x(param_1);
  ppcStack_50 = (code **)0xf45560;
  if (plStack_48 != (undefined8 *)0x0) {
    (**(code **)*plStack_48)(plStack_48,1);
  }
  if (plStack_40 != (longlong *)0x0) {
    (**(code **)*plStack_40)(plStack_40,1);
  }
  return;
}

