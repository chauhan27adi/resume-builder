
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,longlong param_3,undefined *param_4)

{
  int iVar1;
  int iVar2;
  byte *pbVar3;
  undefined8 uVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  undefined8 uStackX_18;
  undefined8 uStack_58;
  longlong lStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  
  lVar7 = 0;
  if (param_3 == 0) {
    *(undefined4 *)(param_4 + 8) = 0;
LAB_:
    (*_DAT_)(0x1d8,3,0x10,1,9,0x10);
    if (param_3 != 0) goto LAB_;
    (*_DAT_)(1,0x171d844,0x1713ef0,0x4c,0);
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0xe,0x15db518);
    uStackX_18 = 0;
    if (param_3 != 0) goto LAB_;
    uStackX_18 = 0;
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x1c,0x1656350);
    uStack_58 = 0;
    if (param_3 != 0) goto LAB_;
    uStack_58 = 0;
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     8,0x1656280);
    uStack_40 = 0;
    if (param_3 != 0) goto LAB_;
    uStack_40 = 0;
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     8,0x1656270);
    uStack_48 = 0;
    if (param_3 != 0) goto LAB_;
    uStack_48 = 0;
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x10,0x16562b0);
    lStack_50 = 0;
    if (param_3 != 0) goto LAB_;
    lStack_50 = 0;
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x18,0x1656290);
    lVar8 = lVar7;
    if (param_3 != 0) goto LAB_;
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x1e,0x16562e0);
    lVar10 = lVar7;
    if (param_3 != 0) goto LAB_;
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x12,0x16562c8);
    lVar9 = lVar7;
    if (param_3 != 0) goto LAB_;
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x16,0x1656338);
    lVar5 = lVar7;
    if (param_3 != 0) goto LAB_;
LAB_:
    lVar6 = lVar7;
    if (param_3 == 0) goto LAB_;
  }
  else {
    iVar1 = *(int *)(param_3 + 0x1c);
    iVar2 = *(int *)(param_3 + 0x28);
    *(undefined4 *)(param_4 + 8) = 0;
    if (7 < (iVar1 - iVar2) - 9U) goto LAB_;
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 1) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x15db518,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x15db518,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x15db518);
    }
    uStackX_18 = *(undefined8 *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 2) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1656350,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1656350,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1656350);
    }
    uStack_58 = *(undefined8 *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 3) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x10 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1656280,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1656280,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,8,0x1656280);
    }
    uStack_40 = *(undefined8 *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 4) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x18 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1656270,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1656270,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,8,0x1656270);
    }
    uStack_48 = *(undefined8 *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 5) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x20 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x16562b0,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x16562b0,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,0x10,0x16562b0);
    }
    lStack_50 = *(longlong *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 6) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x28 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1656290,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1656290,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1656290);
    }
    lVar8 = *(longlong *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 7) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x30 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x16562e0,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x16562e0,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,0x1e,0x16562e0);
    }
    lVar10 = *(longlong *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 8) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x38 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x16562c8,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x16562c8,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,0x12,0x16562c8);
    }
    lVar9 = *(longlong *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 9) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x40 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1656338,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1656338,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1656338);
    }
    lVar5 = *(longlong *)(pbVar3 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 0xf) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x70 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if ((**(char **)(pbVar3 + 0x18) != DAT_) && (**(char **)(pbVar3 + 0x18) != '\x1f')) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1656300,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1656300,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,0x30,0x1656300);
    }
    lVar6 = *(longlong *)(pbVar3 + 8);
  }
  if (0xf < *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28)) {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x78 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if ((**(char **)(pbVar3 + 0x18) != DAT_) && (**(char **)(pbVar3 + 0x18) != '\x1f')) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1656260,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1656260,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1656260);
    }
    lVar7 = *(longlong *)(pbVar3 + 8);
  }
LAB_:
  (*_DAT_)(uStackX_18,uStack_58,uStack_40,uStack_48,*(undefined4 *)(lStack_50 + 8),lVar8,
                   *(undefined4 *)(lVar10 + 8),*(undefined4 *)(lVar9 + 8),lVar5,lVar6,lVar7,
                   (byte)((uint)*(undefined4 *)(param_3 + 0x20) >> 8) & 1);
  *param_4 = 0;
  return;
}

