
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,undefined4 param_3,undefined8 param_4)

{
  ulonglong uVar1;
  undefined4 auStackX_10 [2];
  
  uVar1 = func_0x();
  if (uVar1 < 0x30000) {
    (*_DAT_)(0x16,0xa2,0x10,1,0xdb7e90);
  }
  func_0x(param_1);
  (**(code **)(*param_2 + 0x50))(param_2,auStackX_10);
  switch(auStackX_10[0]) {
  case 0x41:
    func_0x(param_1,param_2,param_3,param_4);
    break;
  case 0x43:
  case 0x4b:
    func_0x(param_1,param_2,param_3);
    break;
  case 0x45:
    func_0x(param_1,param_2,param_3,param_4);
    break;
  case 0x47:
    func_0x(param_1,param_2,param_3);
    break;
  case 0x4c:
    func_0x(param_1,param_2,param_3);
    break;
  case 0x4d:
    func_0x(param_1,param_2,param_3,param_4);
    break;
  case 0x53:
    func_0x(param_1,param_2,param_3);
    break;
  case 0x55:
    func_0x(param_1,param_2,param_3);
    break;
  case 0x56:
  case 0x57:
    func_0x(param_1,param_2);
  }
  return;
}

