
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1)

{
  if (*(longlong *)(param_1 + 0xd8) != 0) {
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

