
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00100263) */
/* WARNING: Removing unreachable block (ram,0x01797344) */
/* WARNING: Removing unreachable block (ram,0x00100270) */
/* WARNING: Removing unreachable block (ram,0x0179734c) */
/* WARNING: Removing unreachable block (ram,0x001002af) */
/* WARNING: Removing unreachable block (ram,0x001002c0) */
/* WARNING: Removing unreachable block (ram,0x001002c3) */
/* WARNING: Removing unreachable block (ram,0x001002d6) */
/* WARNING: Removing unreachable block (ram,0x00100318) */
/* WARNING: Removing unreachable block (ram,0x0010031c) */
/* WARNING: Removing unreachable block (ram,0x00100330) */
/* WARNING: Removing unreachable block (ram,0x0010033b) */
/* WARNING: Removing unreachable block (ram,0x00100350) */
/* WARNING: Removing unreachable block (ram,0x01797355) */
/* WARNING: Removing unreachable block (ram,0x0010036f) */
/* WARNING: Removing unreachable block (ram,0x0010041c) */
/* WARNING: Removing unreachable block (ram,0x00100426) */
/* WARNING: Removing unreachable block (ram,0x00123631) */
/* WARNING: Removing unreachable block (ram,0x00100430) */
/* WARNING: Removing unreachable block (ram,0x0179735e) */
/* WARNING: Removing unreachable block (ram,0x0010043a) */
/* WARNING: Removing unreachable block (ram,0x01797366) */
/* WARNING: Removing unreachable block (ram,0x00100454) */
/* WARNING: Removing unreachable block (ram,0x0012363a) */
/* WARNING: Removing unreachable block (ram,0x0016079a) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2,undefined8 param_3,char param_4)

{
  undefined8 *puVar1;
  char cVar2;
  uint uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  int *piVar6;
  ulonglong uVar7;
  uint uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined2 uStackX_20;
  undefined8 uStack_e0;
  undefined2 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  longlong lStack_b8;
  undefined8 *puStack_b0;
  longlong *plStack_a8;
  longlong lStack_68;
  uint uStack_60;
  undefined8 uStack_58;
  undefined8 *puStack_50;
  
  uStackX_20 = CONCAT11(uStackX_20._1_1_,param_4);
  uStack_58 = 0xfffffffffffffffe;
  uVar3 = *(uint *)(param_2 + 0xc);
  puVar4 = (undefined8 *)(*_DAT_)(0x20,param_1,0x1fb1b68,0xa07,1);
  if (puVar4 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar4 = 0x1ec4f20;
  *(undefined4 *)(puVar4 + 1) = 1;
  *puVar4 = 0x1f8a190;
  puVar4[2] = param_1;
  uVar9 = 0;
  puVar4[3] = 0;
  uStack_d8 = uStackX_20;
  uStack_d4 = 0;
  uStack_d0 = 0;
  uStack_c8 = 0;
  uStack_c4 = 0;
  uStack_c0 = 0;
  uVar8 = uVar3;
  if (uVar3 < 5) {
    uVar8 = 5;
  }
  uStack_e0 = param_1;
  puStack_50 = puVar4;
  func_0x(&uStack_e0,uVar8,0);
  puVar5 = (undefined8 *)(*_DAT_)(0x20,param_1,0x1fb1b68,0xa0e,1);
  if (puVar5 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar5 = param_1;
  *(undefined4 *)((longlong)puVar5 + 0xc) = 0;
  uVar8 = 1;
  if (uVar3 != 0) {
    uVar8 = uVar3;
  }
  *(uint *)(puVar5 + 2) = uVar8;
  puVar5[3] = 0;
  uVar7 = uVar9;
  uVar10 = uVar9;
  puStack_b0 = puVar5;
  if (uVar3 != 0) {
    do {
      uVar8 = (uint)uVar7;
      if (*(uint *)(param_2 + 0xc) <= uVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plStack_a8 = *(longlong **)(uVar10 + *(longlong *)(param_2 + 0x18));
      cVar2 = (**(code **)(*plStack_a8 + 0x60))(plStack_a8,&lStack_b8);
      if (cVar2 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((lStack_b8 != 0) && (puVar4[3] != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(puVar4,lStack_b8);
      lStack_68 = lStack_b8;
      uStack_60 = uVar8;
      func_0x(&uStack_e0,&lStack_68,0);
      uVar7 = (ulonglong)(uVar8 + 1);
      uVar10 = uVar10 + 8;
    } while (uVar8 + 1 < uVar3);
  }
  if ((puVar4[3] != 0) && (uVar3 = func_0x(), 1 < uVar3)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_4 == '\0') {
    for (puVar1 = (undefined8 *)puVar4[3]; puVar1 != (undefined8 *)0x0;
        puVar1 = (undefined8 *)*puVar1) {
      piVar6 = (int *)((longlong)puVar1 + 0xc);
      uVar7 = uVar9;
      do {
        if (*piVar6 != 0) goto code_r0x00100483;
        uVar3 = (int)uVar7 + 1;
        uVar7 = (ulonglong)uVar3;
        piVar6 = piVar6 + 1;
      } while (uVar3 < 8);
    }
    if (*(int *)((longlong)puVar5 + 0xc) != 0) {
code_r0x00100483:
      if (puVar5 != (undefined8 *)0x0) {
        func_0x(puVar5);
        if (puVar5[3] != 0) {
          (*_DAT_)();
          puVar5[3] = 0;
        }
        *(undefined4 *)(puVar5 + 2) = 0;
        (*_DAT_)(puVar5,0x20);
      }
      func_0x(&uStack_e0);
      puVar5 = puVar4 + 1;
      *(int *)puVar5 = *(int *)puVar5 + -1;
      if (*(int *)puVar5 == 0) {
        (**(code **)*puVar4)(puVar4,1);
      }
      return 0;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

