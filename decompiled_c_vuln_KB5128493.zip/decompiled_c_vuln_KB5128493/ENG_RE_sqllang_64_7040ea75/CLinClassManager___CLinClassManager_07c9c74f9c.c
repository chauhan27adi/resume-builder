
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  longlong lVar1;
  longlong *plVar2;
  uint uVar3;
  uint uVar4;
  ulonglong uVar6;
  ulonglong uVar5;
  
  uVar3 = 0;
  uVar6 = 0;
  for (uVar5 = uVar6;
      (lVar1 = *(longlong *)(param_1 + 8), lVar1 != 0 && ((uint)uVar5 < *(uint *)(lVar1 + 0xc)));
      uVar5 = (ulonglong)((uint)uVar5 + 1)) {
    lVar1 = *(longlong *)(*(longlong *)(lVar1 + 0x18) + uVar5 * 8);
    if (lVar1 != 0) {
      (*_DAT_)(*(undefined8 *)(lVar1 + 8));
      (*_DAT_)(lVar1,0x10);
    }
  }
  if (lVar1 != 0) {
    *(undefined4 *)(lVar1 + 0xc) = 0;
    if (*(longlong *)(lVar1 + 0x18) != 0) {
      (*_DAT_)();
      *(undefined8 *)(lVar1 + 0x18) = 0;
    }
    *(undefined4 *)(lVar1 + 0x10) = 0;
    (*_DAT_)(lVar1,0x20);
  }
  uVar4 = *(uint *)(*(longlong *)(param_1 + 0x20) + 0xc);
  if (uVar4 != 0) {
    uVar5 = uVar6;
    do {
      uVar3 = (uint)uVar5;
      if (*(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x20) + 0x10) + uVar5 * 8) != 0)
      break;
      uVar3 = uVar3 + 1;
      uVar5 = (ulonglong)uVar3;
    } while (uVar3 < uVar4);
  }
  if (uVar3 != uVar4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)(param_1 + 0x20);
  if (lVar1 != 0) {
    func_0x(lVar1);
    (*_DAT_)(lVar1,0x28);
  }
  uVar3 = *(uint *)(*(longlong *)(param_1 + 0x28) + 0xc);
  uVar4 = 0;
  if (uVar3 != 0) {
    uVar5 = uVar6;
    do {
      uVar4 = (uint)uVar5;
      if (*(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x28) + 0x10) + uVar5 * 8) != 0)
      break;
      uVar4 = uVar4 + 1;
      uVar5 = (ulonglong)uVar4;
    } while (uVar4 < uVar3);
  }
  if (uVar4 != uVar3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)(param_1 + 0x28);
  if (lVar1 != 0) {
    func_0x(lVar1);
    (*_DAT_)(lVar1,0x28);
  }
  lVar1 = *(longlong *)(param_1 + 0x18);
  uVar3 = *(uint *)(lVar1 + 0xc);
  if (uVar3 != 0) {
    do {
      if (*(longlong *)(*(longlong *)(lVar1 + 0x10) + uVar6 * 8) != 0) break;
      uVar4 = (int)uVar6 + 1;
      uVar6 = (ulonglong)uVar4;
    } while (uVar4 < uVar3);
  }
  if ((uint)uVar6 != uVar3) {
    plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x10) + uVar6 * 8);
    while (plVar2 != (longlong *)0x0) {
      (*_DAT_)(plVar2[1],0x18);
      plVar2 = (longlong *)*plVar2;
      if (plVar2 == (longlong *)0x0) {
        do {
          uVar3 = (int)uVar6 + 1;
          uVar6 = (ulonglong)uVar3;
          if (*(uint *)(lVar1 + 0xc) <= uVar3) {
            if (uVar3 == *(uint *)(lVar1 + 0xc)) goto LAB_;
            break;
          }
        } while (*(longlong *)(*(longlong *)(lVar1 + 0x10) + (ulonglong)uVar3 * 8) == 0);
        plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x10) + (ulonglong)uVar3 * 8);
      }
    }
  }
LAB_:
  lVar1 = *(longlong *)(param_1 + 0x18);
  if (lVar1 != 0) {
    func_0x(lVar1);
    (*_DAT_)(lVar1,0x28);
  }
  return;
}

