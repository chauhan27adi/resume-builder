
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong unaff_GS_OFFSET;
  longlong lStack_40;
  
  lVar6 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  if ((lVar6 == 0) || (*(longlong *)(lVar6 + 0x110) != lVar6)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(lVar6 + 0x100) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar6 = *(longlong *)(*(longlong *)(lVar6 + 0x100) + 0x3e0);
  lStack_40 = 0;
  if (((*_DAT_ & 1) != 0) && (lVar6 != 0)) {
    uVar2 = (*_DAT_)();
    lStack_40 = (*_DAT_)(uVar2,*(undefined2 *)(lVar6 + 0xa0));
  }
  uVar5 = (ulonglong)*_DAT_;
  if (0x3c < *_DAT_) {
    uVar5 = 0x3c;
  }
  if (lStack_40 != 0) {
    func_0x(lStack_40,0x16,1);
    uVar3 = (*_DAT_)(lStack_40);
    uVar4 = (*_DAT_)(lStack_40,0x16,1);
    if ((uVar3 != 0) && (uVar4 != 0)) {
      uVar4 = uVar3 / uVar4 >> 1;
      uVar3 = uVar5;
      if (uVar5 < uVar4) {
        uVar3 = uVar4;
      }
      uVar5 = uVar5 * 100;
      if (uVar3 < uVar5 * 100) {
        uVar5 = uVar3;
      }
    }
  }
  uVar3 = 0;
  if (*_DAT_ == '\0') {
    if (uVar5 != 0) {
      do {
        uVar3 = uVar3 + *_DAT_;
      } while (uVar3 < uVar5);
    }
    if (lStack_40 != 0) {
      plVar1 = (longlong *)(*(longlong *)(lStack_40 + 8) + 0x4d0);
      *plVar1 = *plVar1 + uVar3;
    }
    if (*(int *)param_1 == 0) {
      LOCK();
      lVar6 = *param_1;
      if (lVar6 == 0) {
        *param_1 = param_2;
      }
      UNLOCK();
      if (lVar6 == 0) {
        return;
      }
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

