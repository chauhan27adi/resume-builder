
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(longlong param_1,longlong param_2,int param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  char cVar3;
  undefined8 *puVar4;
  
  if (*(longlong *)(param_2 + 8) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)
           (*(longlong *)(*(longlong *)(*(longlong *)(param_2 + 8) + 0x20) + (longlong)param_3 * 8)
           + 0x50);
  cVar3 = func_0x(param_4,param_2,lVar1 + 0x68,*(undefined8 *)(lVar1 + 0xd0),0);
  if (cVar3 == '\0') {
    puVar4 = (undefined8 *)(*_DAT_)(0x38,*(undefined8 *)(param_1 + 0x10),0x2118f78,0xca,1);
    if (puVar4 != (undefined8 *)0x0) {
      uVar2 = *(undefined8 *)(param_1 + 0x10);
      *puVar4 = 0x20511f0;
      *(undefined4 *)(puVar4 + 1) = 1;
      *puVar4 = 0x2116af8;
      _DAT_ = _DAT_ + 1;
      puVar4[2] = uVar2;
      puVar4[3] = 0;
      *(undefined *)(puVar4 + 4) = 2;
      puVar4[5] = 0;
      puVar4[6] = 0;
      func_0x(puVar4);
      *(byte *)(puVar4 + 4) = *(byte *)(puVar4 + 4) | 2;
      return puVar4;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

