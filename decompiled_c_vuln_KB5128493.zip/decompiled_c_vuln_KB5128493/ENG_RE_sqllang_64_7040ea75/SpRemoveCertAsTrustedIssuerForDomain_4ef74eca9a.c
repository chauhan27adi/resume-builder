
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong **param_2,longlong param_3,longlong param_4)

{
  undefined2 uVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined4 **ppuVar4;
  char cVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong lVar12;
  ulonglong *puVar13;
  longlong lVar14;
  longlong lVar15;
  uint uVar16;
  longlong unaff_GS_OFFSET;
  undefined auStack_388 [32];
  undefined8 uStack_368;
  undefined8 uStack_360;
  undefined8 uStack_358;
  short *psStack_350;
  undefined4 uStack_348;
  ulonglong uStack_340;
  undefined8 uStack_338;
  undefined8 uStack_330;
  undefined8 uStack_328;
  undefined4 uStack_320;
  undefined auStack_318 [16];
  undefined8 uStack_308;
  longlong *plStack_300;
  undefined auStack_2f8 [8];
  undefined4 uStack_2f0;
  undefined4 uStack_2e8;
  undefined4 **ppuStack_2e0;
  undefined *puStack_2d8;
  undefined8 uStack_2d0;
  undefined4 *puStack_2c8;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined8 uStack_2b8;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined auStack_2a8 [512];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined4 auStack_98 [4];
  short asStack_88 [32];
  ulonglong uStack_48;
  
  uStack_308 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_388;
  *(undefined4 *)(param_4 + 8) = 1;
  uVar2 = **param_2;
  uVar16 = (uint)*(ushort *)(*param_2 + 1);
  if ((param_3 == 0) ||
     (iVar7 = *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28),
     *(int *)(param_3 + 0x1c) == *(int *)(param_3 + 0x28))) {
    psStack_350 = (short *)0x14de210;
    uStack_358 = CONCAT44(uStack_358._4_4_,0x1a);
  }
  else {
    if (iVar7 != 1) {
      if (2 < iVar7) {
        *(undefined4 *)(param_4 + 8) = 0x1fd0;
        uStack_368 = CONCAT44(uStack_368._4_4_,uVar16);
        uStack_360 = uVar2;
        (*_DAT_)(0x51,0x2c,0x10,1);
      }
      goto LAB_;
    }
    psStack_350 = (short *)0x14de200;
    uStack_358 = CONCAT44(uStack_358._4_4_,0xe);
  }
  *(undefined4 *)(param_4 + 8) = 0xc9;
  uStack_368 = CONCAT44(uStack_368._4_4_,uVar16);
  uStack_360 = uVar2;
  (*_DAT_)(2,1,0x10,1);
LAB_:
  lVar12 = *(longlong *)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
  if (**(char **)(lVar12 + 0x18) == '8') {
    if (**(char **)(lVar12 + 8) == '\x03') {
      uStack_358 = 0x14de1e0;
      uStack_360 = CONCAT44(uStack_360._4_4_,0x1c);
      uStack_368 = 0x10813a8;
      (*_DAT_)(2,0x19,0x10,1);
    }
  }
  else {
    uStack_360 = (*_DAT_)(CONCAT71((int7)(int3)((uint)*(int *)(param_3 + 0x28) >> 8),0x38));
    uStack_368 = 0x14de1e0;
    (*_DAT_)(2,0xe,0x10,0xd4);
  }
  lVar3 = *(longlong *)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8);
  if (**(char **)(lVar3 + 0x18) == -0x19) {
    if (**(char **)(lVar3 + 8) == '\x03') {
      uStack_358 = 0x14de2a8;
      uStack_360 = CONCAT44(uStack_360._4_4_,0x10);
      uStack_368 = 0x10813a8;
      (*_DAT_)(2,0x19,0x10,1);
    }
  }
  else {
    uStack_360 = (*_DAT_)(CONCAT71((int7)(int3)((uint)*(int *)(param_3 + 0x28) >> 8),0xe7));
    uStack_368 = 0x14de2a8;
    (*_DAT_)(2,0xe,0x10,0xd4);
  }
  if (0x1fa < (*(uint *)(*(longlong *)(lVar3 + 8) + 0x10) & 0xfffffffe)) {
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    (*_DAT_)(0x176,0x33,0x10,1);
  }
  uStack_328 = 0;
  uVar2 = **param_2;
  uVar1 = *(undefined2 *)(*param_2 + 1);
  uStack_320 = 1;
  auStack_318._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_318._8_8_ = 0;
  cVar6 = *(char *)(*(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                   0x98);
  cVar5 = (**(code **)(*(longlong *)auStack_318._0_8_ + 0x1d0))();
  if (cVar5 == '\0') {
    uStack_348 = (uint)(cVar6 != '\0');
    psStack_350 = (short *)0x0;
    uStack_358 = uStack_358 & 0xffffffffffffff00;
    uStack_360 = CONCAT44(uStack_360._4_4_,1);
    uStack_368 = CONCAT44(uStack_368._4_4_,2);
    (**(code **)(*(longlong *)auStack_318._0_8_ + 8))(auStack_318._0_8_,uVar2,uVar1,1);
    uStack_328 = CONCAT44(uStack_328._4_4_,1);
  }
  else {
    if ((cVar6 != '\0') &&
       (cVar6 = (**(code **)(*(longlong *)auStack_318._0_8_ + 0x1e8))(), cVar6 != '\0')) {
      uStack_368 = 0;
      (*_DAT_)(1,0x1594320,0x1582ef8,0xeb);
    }
    (**(code **)(*(longlong *)auStack_318._0_8_ + 0xe8))
              (auStack_318._0_8_,2,1,(longlong)&uStack_328 + 4);
    uStack_320 = 1;
    uStack_328 = CONCAT44(uStack_328._4_4_,3);
  }
  uVar9 = (**(code **)(*(longlong *)auStack_318._0_8_ + 0x1b0))();
  lVar14 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar14 + 0x100);
  if (lVar15 == 0) {
    (*_DAT_)();
    lVar15 = *(longlong *)(lVar14 + 0x100);
  }
  plVar10 = (longlong *)(**_DAT_)(*(undefined8 *)(lVar15 + 1000),uVar9,0x14ddef8,0xc41);
  uVar1 = *(undefined2 *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x50) + 8);
  uStack_360 = uStack_360 & 0xffffffff00000000;
  uStack_368 = uStack_368 & 0xffffffff00000000;
  plStack_300 = plVar10;
  plVar11 = (longlong *)(**(code **)(*plVar10 + 0x38))(plVar10,uVar1,0,0);
  plVar11 = (longlong *)
            (**(code **)(*plVar11 + 0x328))
                      (plVar11,*(undefined4 *)(*(longlong *)(lVar12 + 8) + 8),1);
  if (plVar11 == (longlong *)0x0) {
    asStack_88[0] = 0;
    func_0x
              (asStack_88,0x20,0x10cafc8,*(undefined4 *)(*(longlong *)(lVar12 + 8) + 8));
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    lVar12 = -1;
    do {
      lVar12 = lVar12 + 1;
    } while (asStack_88[lVar12] != 0);
    uStack_358 = lVar12 * 2;
    psStack_350 = asStack_88;
    uStack_360 = CONCAT44(uStack_360._4_4_,0x8ac9);
    uStack_368 = CONCAT44(uStack_368._4_4_,0x333e);
    (*_DAT_)(0x97,0x33,0x10,1);
  }
  lVar15 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar12 = *(longlong *)(lVar15 + 0x100);
  if (lVar12 == 0) {
    (*_DAT_)(0);
    lVar12 = *(longlong *)(lVar15 + 0x100);
  }
  uVar9 = *(undefined8 *)(lVar12 + 1000);
  uVar8 = (**(code **)(*plVar11 + 8))();
  uStack_330 = 0;
  uStack_338 = 0;
  uStack_340 = uStack_340 & 0xffffffffffffff00;
  uStack_348 = CONCAT31(uStack_348._1_3_,1);
  psStack_350 = (short *)((ulonglong)psStack_350 & 0xffffffff00000000);
  uStack_358 = CONCAT44(uStack_358._4_4_,0xffffffff);
  uStack_360 = uStack_360 & 0xffffffff00000000;
  uStack_368 = CONCAT44(uStack_368._4_4_,uVar8);
  cVar6 = func_0x(0x4c414358,uVar9,plVar10,uVar1);
  if (cVar6 == '\0') {
    (*_DAT_)(0x98,0x2f,0x10,0x6b);
  }
  if ((_DAT_ & 0x2000000) != 0) {
    uStack_2f0 = 0x20000;
    uStack_2e8 = 0;
    ppuStack_2e0 = &puStack_2c8;
    puStack_2d8 = auStack_2a8;
    uStack_a8 = 0;
    uStack_2d0 = 0;
    uStack_a0 = 0;
    puStack_2c8 = auStack_98;
    uStack_2c0 = 0xc;
    uStack_2bc = 1;
    uStack_2b8 = 0;
    uStack_2b0 = 0;
    uStack_2ac = 1;
    auStack_98[0] = (**(code **)(*plVar11 + 8))(plVar11);
    ppuVar4 = ppuStack_2e0;
    uVar16 = *(uint *)(*(longlong *)(lVar3 + 8) + 0x10);
    ppuStack_2e0[2] = *(undefined4 **)(*(longlong *)(lVar3 + 8) + 8);
    *(uint *)(ppuVar4 + 3) = uVar16 & 0xfffffffe;
    *(undefined4 *)((longlong)ppuVar4 + 0x1c) = 1;
    func_0x(auStack_2f8);
  }
  cVar6 = (**(code **)(*plVar11 + 0xc0))
                    (plVar11,*(undefined8 *)(*(longlong *)(lVar3 + 8) + 8),
                     *(undefined4 *)(*(longlong *)(lVar3 + 8) + 0x10));
  if (cVar6 == '\0') {
    uVar2 = *(ulonglong *)(*(longlong *)(lVar3 + 8) + 8);
    uVar8 = *(undefined4 *)(*(longlong *)(lVar3 + 8) + 0x10);
    puVar13 = (ulonglong *)(**(code **)*plVar11)(plVar11);
    lVar12 = (**(code **)*plVar11)(plVar11);
    uStack_358 = CONCAT44(uStack_358._4_4_,uVar8);
    uStack_360 = *puVar13;
    uStack_368 = CONCAT44(uStack_368._4_4_,*(undefined4 *)(lVar12 + 8));
    psStack_350 = (short *)uVar2;
    uStack_348 = uVar8;
    uStack_340 = uVar2;
    (*_DAT_)(0x176,0x30,0x10,1);
  }
  else {
    (**(code **)(*plVar11 + 0xa8))
              (plVar11,*(undefined8 *)(*(longlong *)(lVar3 + 8) + 8),
               *(undefined4 *)(*(longlong *)(lVar3 + 8) + 0x10));
  }
  (**(code **)*plVar10)(plVar10,1);
  func_0x(&uStack_328,0);
  *(undefined4 *)(param_4 + 8) = 0;
  if ((int)uStack_328 != 0) {
    func_0x(&uStack_328,0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_388);
  return;
}

