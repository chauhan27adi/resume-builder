
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  ulonglong *puVar1;
  longlong *plVar2;
  longlong *plVar3;
  ulonglong uVar4;
  code *pcVar5;
  char *pcVar6;
  int iVar7;
  longlong unaff_GS_OFFSET;
  
  puVar1 = (ulonglong *)(param_1 + 0x670);
  if (*(int *)puVar1 == 0) {
    LOCK();
    uVar4 = *puVar1;
    if (uVar4 == 0) {
      *puVar1 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (uVar4 == 0) {
      plVar2 = (longlong *)(param_1 + 0x678);
      plVar3 = (longlong *)(param_2 + 0x660);
      *plVar3 = *plVar2;
      *(longlong **)(*plVar2 + 8) = plVar3;
      pcVar6 = _DAT_;
      *plVar2 = (longlong)plVar3;
      *(longlong **)(param_2 + 0x668) = plVar2;
      if ((*pcVar6 != '\0') && (iVar7 = (*_DAT_)(), iVar7 == (iVar7 / 5) * 5)) {
        func_0x();
      }
      pcVar5 = (code *)swi(3);
      (*pcVar5)();
      return;
    }
  }
  pcVar5 = (code *)swi(3);
  (*pcVar5)();
  return;
}

