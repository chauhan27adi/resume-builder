
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong **param_2,longlong param_3,longlong param_4)

{
  undefined2 uVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined auVar4 [16];
  undefined4 **ppuVar5;
  char cVar6;
  char cVar7;
  int iVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong lVar13;
  ulonglong *puVar14;
  uint uVar15;
  longlong lVar16;
  longlong lVar17;
  longlong unaff_GS_OFFSET;
  undefined auStack_678 [32];
  undefined8 uStack_658;
  undefined8 uStack_650;
  undefined8 uStack_648;
  short *psStack_640;
  undefined4 uStack_638;
  undefined uStack_630;
  undefined8 uStack_628;
  undefined8 uStack_620;
  byte abStack_618 [4];
  undefined4 uStack_614;
  undefined8 uStack_610;
  undefined4 uStack_608;
  undefined auStack_600 [16];
  undefined auStack_5f0 [16];
  undefined4 uStack_5e0;
  char *pcStack_5d8;
  longlong lStack_5d0;
  undefined uStack_5c8;
  undefined8 uStack_5c0;
  longlong *plStack_5b8;
  undefined *puStack_5b0;
  undefined auStack_5a8 [24];
  undefined8 uStack_590;
  int aiStack_580 [6];
  longlong lStack_568;
  undefined auStack_558 [24];
  longlong lStack_540;
  undefined auStack_528 [8];
  undefined4 uStack_520;
  undefined4 uStack_518;
  undefined4 **ppuStack_510;
  undefined *puStack_508;
  undefined8 uStack_500;
  undefined4 *puStack_4f8;
  undefined4 uStack_4f0;
  undefined4 uStack_4ec;
  undefined8 uStack_4e8;
  undefined4 uStack_4e0;
  undefined4 uStack_4dc;
  undefined auStack_4d8 [512];
  undefined8 uStack_2d8;
  undefined8 uStack_2d0;
  undefined4 auStack_2c8 [4];
  char acStack_2b8 [8];
  longlong lStack_2b0;
  undefined4 uStack_2a8;
  undefined8 uStack_2a0;
  short asStack_88 [32];
  ulonglong uStack_48;
  
  uStack_5c0 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_678;
  uStack_614 = 0;
  *(undefined4 *)(param_4 + 8) = 1;
  uVar2 = **param_2;
  uVar15 = (uint)*(ushort *)(*param_2 + 1);
  if ((param_3 == 0) ||
     (iVar8 = *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28),
     *(int *)(param_3 + 0x1c) == *(int *)(param_3 + 0x28))) {
    psStack_640 = (short *)0x14deb10;
    uStack_648 = CONCAT44(uStack_648._4_4_,0x1a);
  }
  else {
    if (iVar8 != 1) {
      if (2 < iVar8) {
        *(undefined4 *)(param_4 + 8) = 0x1fd0;
        uStack_658 = CONCAT44(uStack_658._4_4_,uVar15);
        uStack_650 = uVar2;
        (*_DAT_)(0x51,0x2c,0x10,1);
      }
      goto LAB_;
    }
    psStack_640 = (short *)0x14deb00;
    uStack_648 = CONCAT44(uStack_648._4_4_,0xe);
  }
  *(undefined4 *)(param_4 + 8) = 0xc9;
  uStack_658 = CONCAT44(uStack_658._4_4_,uVar15);
  uStack_650 = uVar2;
  (*_DAT_)(2,1,0x10,1);
LAB_:
  lVar13 = *(longlong *)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
  if (**(char **)(lVar13 + 0x18) == '8') {
    if (**(char **)(lVar13 + 8) == '\x03') {
      uStack_648 = 0x14deae0;
      uStack_650 = CONCAT44(uStack_650._4_4_,0x1c);
      uStack_658 = 0x1081ca8;
      (*_DAT_)(2,0x19,0x10,1);
    }
  }
  else {
    uStack_650 = (*_DAT_)(CONCAT71((int7)(int3)((uint)*(int *)(param_3 + 0x28) >> 8),0x38));
    uStack_658 = 0x14deae0;
    (*_DAT_)(2,0xe,0x10,0xd4);
  }
  lVar3 = *(longlong *)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8);
  if (**(char **)(lVar3 + 0x18) == -0x19) {
    if (**(char **)(lVar3 + 8) == '\x03') {
      uStack_648 = 0x14deba8;
      uStack_650 = CONCAT44(uStack_650._4_4_,0x10);
      uStack_658 = 0x1081ca8;
      (*_DAT_)(2,0x19,0x10,1);
    }
  }
  else {
    uStack_650 = (*_DAT_)(CONCAT71((int7)(int3)((uint)*(int *)(param_3 + 0x28) >> 8),0xe7));
    uStack_658 = 0x14deba8;
    (*_DAT_)(2,0xe,0x10,0xd4);
  }
  if (0x1fa < (*(uint *)(*(longlong *)(lVar3 + 8) + 0x10) & 0xfffffffe)) {
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    (*_DAT_)(0x176,0x33,0x10,1);
  }
  uStack_610 = 0;
  uVar2 = **param_2;
  uVar1 = *(undefined2 *)(*param_2 + 1);
  uStack_608 = 1;
  auStack_600._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_600._8_8_ = 0;
  cVar7 = *(char *)(*(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                   0x98);
  cVar6 = (**(code **)(*(longlong *)auStack_600._0_8_ + 0x1d0))();
  if (cVar6 == '\0') {
    uStack_638 = (uint)(cVar7 != '\0');
    psStack_640 = (short *)0x0;
    uStack_648 = uStack_648 & 0xffffffffffffff00;
    uStack_650 = CONCAT44(uStack_650._4_4_,1);
    uStack_658 = CONCAT44(uStack_658._4_4_,2);
    (**(code **)(*(longlong *)auStack_600._0_8_ + 8))(auStack_600._0_8_,uVar2,uVar1,1);
    uStack_610 = CONCAT44(uStack_610._4_4_,1);
  }
  else {
    if ((cVar7 != '\0') &&
       (cVar7 = (**(code **)(*(longlong *)auStack_600._0_8_ + 0x1e8))(), cVar7 != '\0')) {
      uStack_658 = 0;
      (*_DAT_)(1,0x1594c20,0x15837f8,0xeb);
    }
    (**(code **)(*(longlong *)auStack_600._0_8_ + 0xe8))
              (auStack_600._0_8_,2,1,(longlong)&uStack_610 + 4);
    uStack_608 = 1;
    uStack_610 = CONCAT44(uStack_610._4_4_,3);
  }
  uVar10 = (**(code **)(*(longlong *)auStack_600._0_8_ + 0x1b0))();
  lVar16 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar17 = *(longlong *)(lVar16 + 0x100);
  if (lVar17 == 0) {
    (*_DAT_)();
    lVar17 = *(longlong *)(lVar16 + 0x100);
  }
  plVar11 = (longlong *)(**_DAT_)(*(undefined8 *)(lVar17 + 1000),uVar10,0x14de7f8,0xb99);
  uVar1 = *(undefined2 *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x50) + 8);
  uStack_650 = uStack_650 & 0xffffffff00000000;
  uStack_658 = uStack_658 & 0xffffffff00000000;
  plStack_5b8 = plVar11;
  plVar12 = (longlong *)(**(code **)(*plVar11 + 0x38))(plVar11,uVar1,0,0);
  plVar12 = (longlong *)
            (**(code **)(*plVar12 + 0x328))
                      (plVar12,*(undefined4 *)(*(longlong *)(lVar13 + 8) + 8),1);
  if (plVar12 == (longlong *)0x0) {
    asStack_88[0] = 0;
    func_0x
              (asStack_88,0x20,0x10cb8c8,*(undefined4 *)(*(longlong *)(lVar13 + 8) + 8));
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    lVar13 = -1;
    do {
      lVar13 = lVar13 + 1;
    } while (asStack_88[lVar13] != 0);
    uStack_648 = lVar13 * 2;
    psStack_640 = asStack_88;
    uStack_650 = CONCAT44(uStack_650._4_4_,0x8ac9);
    uStack_658 = CONCAT44(uStack_658._4_4_,0x333e);
    (*_DAT_)(0x97,0x33,0x10,1);
  }
  lVar17 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar13 = *(longlong *)(lVar17 + 0x100);
  if (lVar13 == 0) {
    (*_DAT_)(0);
    lVar13 = *(longlong *)(lVar17 + 0x100);
  }
  uVar10 = *(undefined8 *)(lVar13 + 1000);
  uVar9 = (**(code **)(*plVar12 + 8))(plVar12);
  uStack_620 = 0;
  uStack_628 = 0;
  uStack_630 = 0;
  uStack_638 = CONCAT31(uStack_638._1_3_,1);
  psStack_640 = (short *)((ulonglong)psStack_640 & 0xffffffff00000000);
  uStack_648 = CONCAT44(uStack_648._4_4_,0xffffffff);
  uStack_650 = uStack_650 & 0xffffffff00000000;
  uStack_658 = CONCAT44(uStack_658._4_4_,uVar9);
  cVar7 = func_0x(0x4c414358,uVar10,plVar11,uVar1);
  if (cVar7 == '\0') {
    (*_DAT_)(0x98,0x2f,0x10,0x6a);
  }
  if ((_DAT_ & 0x1000000) != 0) {
    uStack_520 = 0x20000;
    uStack_518 = 0;
    ppuStack_510 = &puStack_4f8;
    puStack_508 = auStack_4d8;
    uStack_2d8 = 0;
    uStack_500 = 0;
    uStack_2d0 = 0;
    puStack_4f8 = auStack_2c8;
    uStack_4f0 = 0xc;
    uStack_4ec = 1;
    uStack_4e8 = 0;
    uStack_4e0 = 0;
    uStack_4dc = 1;
    auStack_2c8[0] = (**(code **)(*plVar12 + 8))(plVar12);
    ppuVar5 = ppuStack_510;
    uVar15 = *(uint *)(*(longlong *)(lVar3 + 8) + 0x10);
    ppuStack_510[2] = *(undefined4 **)(*(longlong *)(lVar3 + 8) + 8);
    *(uint *)(ppuVar5 + 3) = uVar15 & 0xfffffffe;
    *(undefined4 *)((longlong)ppuVar5 + 0x1c) = 1;
    func_0x(auStack_528);
  }
  cVar7 = (**(code **)(*plVar12 + 0xc0))
                    (plVar12,*(undefined8 *)(*(longlong *)(lVar3 + 8) + 8),
                     *(undefined4 *)(*(longlong *)(lVar3 + 8) + 0x10));
  if (cVar7 == '\0') {
    acStack_2b8[0] = '\x01';
    lStack_2b0 = 0;
    uStack_2a8 = 0;
    uStack_2a0 = 0;
    uStack_658 = 0;
    func_0x(acStack_2b8,auStack_558,3,0xf0000040);
    uStack_614 = 0;
    if (lStack_540 != 0) {
      (*_DAT_)();
    }
    auStack_5f0 = ZEXT816(0);
    uStack_5e0 = 0;
    pcStack_5d8 = acStack_2b8;
    lStack_5d0 = 0;
    uStack_5c8 = 0;
    lVar17 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar13 = *(longlong *)(lVar17 + 0x100);
    if (lVar13 == 0) {
      (*_DAT_)(0);
      lVar13 = *(longlong *)(lVar17 + 0x100);
    }
    func_0x(auStack_5f0,aiStack_580,*(undefined8 *)(lVar13 + 1000),plVar12);
    if (aiStack_580[0] != 0) {
      puStack_5b0 = auStack_5a8;
      uStack_590 = 0;
      func_0x(auStack_5a8,aiStack_580);
      func_0x(auStack_5a8,0);
    }
    if (lStack_568 != 0) {
      (*_DAT_)();
    }
    iVar8 = func_0x(lStack_5d0,0,0,0);
    if (iVar8 != 0) {
      func_0x(0x9249,10,1);
    }
    iVar8 = (*_DAT_)(0x10001,*(undefined8 *)(lStack_5d0 + 0x18),abStack_618,2);
    if ((iVar8 != 0) && ((abStack_618[0] & 4) == 0)) {
      *(undefined4 *)(param_4 + 8) = 0x3b2e;
      puVar14 = (ulonglong *)(**(code **)*plVar12)(plVar12);
      lVar13 = (**(code **)*plVar12)(plVar12);
      uStack_650 = *puVar14;
      uStack_658 = CONCAT44(uStack_658._4_4_,*(undefined4 *)(lVar13 + 8));
      (*_DAT_)(0x176,0x32,0x10,1);
    }
    (**(code **)(*plVar12 + 0xa0))
              (plVar12,*(undefined8 *)(*(longlong *)(lVar3 + 8) + 8),
               *(undefined4 *)(*(longlong *)(lVar3 + 8) + 0x10));
    if (lStack_5d0 != 0) {
      (*_DAT_)();
      lStack_5d0 = 0;
    }
    if (auStack_5f0._0_8_ != 0) {
      (*_DAT_)(auStack_5f0._0_8_,0);
      auVar4._8_8_ = 0;
      auVar4._0_8_ = auStack_5f0._8_8_;
      auStack_5f0 = auVar4 << 0x40;
    }
    if ((lStack_2b0 != 0) && (acStack_2b8[0] != '\0')) {
      (*_DAT_)(lStack_2b0,0);
    }
    lStack_2b0 = 0;
    uStack_2a8 = 0;
  }
  else {
    uVar2 = *(ulonglong *)(*(longlong *)(lVar3 + 8) + 8);
    uVar9 = *(undefined4 *)(*(longlong *)(lVar3 + 8) + 0x10);
    puVar14 = (ulonglong *)(**(code **)*plVar12)(plVar12);
    lVar13 = (**(code **)*plVar12)(plVar12);
    uStack_648 = CONCAT44(uStack_648._4_4_,uVar9);
    uStack_650 = *puVar14;
    uStack_658 = CONCAT44(uStack_658._4_4_,*(undefined4 *)(lVar13 + 8));
    psStack_640 = (short *)uVar2;
    (*_DAT_)(0x176,0x2f,0x10,1);
  }
  (**(code **)*plVar11)(plVar11,1);
  func_0x(&uStack_610,0);
  *(undefined4 *)(param_4 + 8) = 0;
  if ((int)uStack_610 != 0) {
    func_0x(&uStack_610,0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_678);
  return;
}

