
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x017777b1) */
/* WARNING: Removing unreachable block (ram,0x01777798) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(undefined8 param_1,undefined8 param_2,byte *param_3,byte *param_4,
                     longlong param_5,longlong param_6)

{
  longlong lVar1;
  int iVar2;
  longlong lVar3;
  longlong unaff_GS_OFFSET;
  ulonglong uVar4;
  undefined auStack_60 [40];
  
  if ((param_5 == 0) &&
     ((((*(short *)(param_3 + 0x10) == -1 ||
        (*(char *)((ulonglong)*(byte *)((ulonglong)*param_3 + 0x1e64fa0) + 0x2928f28) != '\0')) ||
       (*(short *)(param_4 + 0x10) == -1)) ||
      (*(char *)((ulonglong)*(byte *)((ulonglong)*param_4 + 0x1e64fa0) + 0x2928f28) != '\0')))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar3 = func_0x(param_1,param_2,param_3);
  uVar4 = 0xffffffffffea3300;
  func_0x(auStack_60,0,0,0,0xffffffffffea3300,0);
  if (*param_3 == 0x2b) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar2 = (*_DAT_)(lVar3,param_3,param_4,0,uVar4 & 0xffffffff00000000,param_1,0,0,0,0,0,
                           param_5,0);
  if (iVar2 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(auStack_60);
  lVar1 = *(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           0x100);
  if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(lVar1 + 0x22c) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((lVar3 != 0) && (param_6 != 0)) &&
     (iVar2 = (*_DAT_)(lVar3,param_4,param_3,param_2), iVar2 != 2)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return lVar3;
}

