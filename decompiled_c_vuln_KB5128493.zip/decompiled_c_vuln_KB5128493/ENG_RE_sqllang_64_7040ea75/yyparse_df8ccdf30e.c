
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(void)

{
  longlong lVar1;
  
  lVar1 = func_0x();
  lVar1 = -lVar1;
  *(undefined8 *)(&stack0x00001d30 + lVar1) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000251b0 + lVar1) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffe0 + lVar1);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

