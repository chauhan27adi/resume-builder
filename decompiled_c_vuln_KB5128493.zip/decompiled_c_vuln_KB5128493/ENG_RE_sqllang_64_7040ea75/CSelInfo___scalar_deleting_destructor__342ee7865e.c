
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,uint param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  *param_1 = 0x20c9c20;
  if (*(int *)(param_1 + 2) != 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar2 = (undefined8 *)param_1[0x11];
  if (puVar2 != (undefined8 *)0x0) {
    puVar1 = puVar2 + 1;
    *(int *)puVar1 = *(int *)puVar1 + -1;
    if (*(int *)puVar1 == 0) {
      (**(code **)*puVar2)(puVar2,1,param_3,param_4,0xfffffffffffffffe);
    }
  }
  puVar2 = (undefined8 *)param_1[0xd];
  if (puVar2 != (undefined8 *)0x0) {
    (**(code **)*puVar2)(puVar2,1);
  }
  if (*(char *)((longlong)param_1 + 0x19) == '\0') {
    *param_1 = 0x1fe5e50;
    if ((param_2 & 1) != 0) {
      (*_DAT_)(param_1,0x90);
    }
    return param_1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

