
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong *param_1,uint param_2)

{
  double dVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  
  lVar2 = *param_1;
  lVar3 = *(longlong *)(lVar2 + (ulonglong)param_2 * 8);
  if (1 < param_2) {
    lVar4 = *(longlong *)(*(longlong *)(lVar2 + (ulonglong)(param_2 >> 1) * 8) + 0x10);
    if (*(longlong *)(lVar3 + 0x10) < lVar4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(longlong *)(lVar3 + 0x10) == lVar4) &&
       (dVar1 = *(double *)(*(longlong *)(lVar2 + (ulonglong)(param_2 >> 1) * 8) + 8),
       *(double *)(lVar3 + 8) <= dVar1 && dVar1 != *(double *)(lVar3 + 8))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  *(longlong *)(lVar2 + (ulonglong)param_2 * 8) = lVar3;
  *(uint *)(*(longlong *)(*param_1 + (ulonglong)param_2 * 8) + 0x18) = param_2;
  return;
}

