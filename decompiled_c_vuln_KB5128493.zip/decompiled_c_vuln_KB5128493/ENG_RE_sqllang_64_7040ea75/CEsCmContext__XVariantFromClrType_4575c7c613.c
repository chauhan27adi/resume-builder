
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,longlong param_2)

{
  uint *puVar1;
  char cVar2;
  char cVar3;
  byte *pbVar4;
  uint uVar5;
  byte bVar6;
  uint uVar7;
  undefined4 uVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  ulonglong uVar12;
  short sVar13;
  undefined8 uVar14;
  undefined8 uStackX_10;
  undefined8 auStackX_18 [2];
  
  uVar7 = *(uint *)(param_2 + 0x60);
  cVar2 = *(char *)(param_2 + 0x49);
  if (uVar7 == 0xffffffff) {
    uVar7 = func_0x(param_1,param_2 + 0x28,0);
    func_0x(param_1,uVar7);
  }
  func_0x(param_1,param_2,0);
  if (((*(short *)(*(byte **)(param_2 + 0x20) + 0x10) == -1) ||
      (*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(param_2 + 0x20) + 0x1a09200) +
                0x24cd188) != '\0')) && (*(int *)(param_2 + 0x3c) != 0x25)) {
    func_0x(param_1,0x16);
    if (*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(param_2 + 0x20) + 0x1a09200) +
                 0x1a3e1f0) != '\0') {
      uVar8 = (*_DAT_)();
      uVar8 = (*_DAT_)(uVar8);
      func_0x(param_1,0x21);
      func_0x(param_1,uVar8);
      uVar9 = (*_DAT_)(*(undefined8 *)(param_2 + 0x20));
      if ((uVar9 >> 0x10 & 1) == 0) {
        uVar11 = uVar9 >> 0xc & 1;
        uVar5 = uVar11 | 2;
        if ((uVar9 & 0x2000) == 0) {
          uVar5 = uVar11;
        }
        uVar11 = uVar5 | 8;
        if ((uVar9 & 0x4000) == 0) {
          uVar11 = uVar5;
        }
        if ((uVar9 >> 0xf & 1) != 0) {
          uVar11 = uVar11 | 0x10;
        }
      }
      else {
        uVar11 = 0x8000;
      }
      func_0x(param_1,uVar11);
    }
    func_0x(param_1,4);
    func_0x(param_1,0x28);
    uVar14 = 0xa4;
    if (*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(param_2 + 0x20) + 0x1a09200) +
                 0x1a3e1f0) == '\0') {
      uVar14 = 0xa5;
    }
    iVar10 = func_0x(*param_1,param_1[1],uVar14,&uStackX_10);
    if (iVar10 == 1) {
      func_0x(0,1,0x15);
    }
    uVar9 = (uint)uStackX_10;
    func_0x(param_1,(uint)uStackX_10 & 0xff);
    func_0x(param_1,uVar9 >> 8 & 0xff);
    func_0x(param_1,uVar9 >> 0x10 & 0xff);
    func_0x(param_1,(char)(uVar9 >> 0x18));
    func_0x(param_1,0x25);
  }
  func_0x(param_1,uVar7);
  switch(*(undefined4 *)(param_2 + 0x3c)) {
  case 0x1d:
  case 0x1e:
    func_0x(param_1,0x28);
    iVar10 = (cVar2 != '\0') + 0x5e;
    break;
  case 0x1f:
  case 0x20:
    bVar6 = **(byte **)(param_2 + 0x20);
    if ((byte)(bVar6 + 0x10) < 2) {
      bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x1a09200) * 4 + 0x1a09302);
    }
    else {
      bVar6 = (*(byte **)(param_2 + 0x20))[0x12];
    }
    func_0x(param_1,bVar6);
    bVar6 = **(byte **)(param_2 + 0x20);
    if ((byte)(bVar6 + 0x10) < 2) {
      bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x1a09200) * 4 + 0x1a09303);
    }
    else {
      bVar6 = (*(byte **)(param_2 + 0x20))[0x13];
    }
    func_0x(param_1,bVar6);
    func_0x(param_1,0x28);
    iVar10 = (cVar2 != '\0') + 0x70;
    break;
  case 0x21:
  case 0x22:
    if (**(char **)(param_2 + 0x20) == '*') {
      func_0x(param_1,(*(char **)(param_2 + 0x20))[0x13]);
    }
    func_0x(param_1,0x28);
    cVar3 = **(char **)(param_2 + 0x20);
    if (cVar3 == '=') {
      iVar10 = (cVar2 != '\0') + 0x76;
    }
    else if (cVar3 == '(') {
      iVar10 = (cVar2 != '\0') + 0x86;
    }
    else {
      if (cVar3 != '*') goto code_r0x00100adf;
      iVar10 = (cVar2 != '\0') + 0x8e;
    }
    break;
  case 0x23:
  case 0x24:
    bVar6 = **(byte **)(param_2 + 0x20);
    if ((byte)(bVar6 + 0x10) < 2) {
      bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x1a09200) * 4 + 0x1a09303);
    }
    else {
      bVar6 = (*(byte **)(param_2 + 0x20))[0x13];
    }
    func_0x(param_1,bVar6);
    func_0x(param_1,0x28);
    iVar10 = (cVar2 != '\0') + 0x92;
    break;
  case 0x25:
    func_0x(param_1,param_2,0x18);
    func_0x(param_1,uVar7);
    func_0x(param_1,0x28);
    iVar10 = func_0x(*param_1,param_1[1],5,&uStackX_10);
    if (iVar10 == 1) {
      func_0x(0,1,0x15);
    }
    func_0x(param_1,(uint)uStackX_10 & 0xff);
    func_0x(param_1,(uint)uStackX_10 >> 8 & 0xff);
    func_0x(param_1,(uint)uStackX_10 >> 0x10 & 0xff);
    func_0x(param_1,(char)((uint)uStackX_10 >> 0x18));
    func_0x(param_1,0x55);
    func_0x(param_1,param_2,0);
    func_0x(param_1,param_2,2);
    func_0x(param_1,0x25);
    func_0x(param_1,0x48);
    func_0x(param_1,0x20);
    func_0x(param_1,0);
    func_0x(param_1,8);
    func_0x(param_1,0);
    func_0x(param_1,0);
    func_0x(param_1,0x60);
    func_0x(param_1,0x53);
    goto code_r0x00100adf;
  case 0x26:
  case 0x27:
    bVar6 = **(byte **)(param_2 + 0x20);
    if ((byte)(bVar6 + 0x10) < 2) {
      bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x1a09200) * 4 + 0x1a09303);
    }
    else {
      bVar6 = (*(byte **)(param_2 + 0x20))[0x13];
    }
    func_0x(param_1,bVar6);
    func_0x(param_1,0x28);
    iVar10 = (cVar2 != '\0') + 0x8a;
    break;
  default:
    (*_DAT_)(1,0x1efc410,0x1ef9ad0,0x14ba,0x1b3e650);
    goto code_r0x00100adf;
  case 0x38:
    pbVar4 = *(byte **)(param_2 + 0x20);
    uVar12 = (ulonglong)*(byte *)((ulonglong)*pbVar4 + 0x1a09200);
    if (((*(char *)(uVar12 + 0x1a45d28) == '\0') || (*(short *)(pbVar4 + 0x10) != -1)) &&
       (*pbVar4 != 0x22)) {
      sVar13 = *(short *)(pbVar4 + 0x10);
      if ((sVar13 == -1) || (*(char *)(uVar12 + 0x24cd188) != '\0')) {
        sVar13 = 0x1fa4;
      }
      func_0x(param_1,0x21);
      func_0x(param_1,sVar13);
      sVar13 = *(short *)(*(byte **)(param_2 + 0x20) + 0x10);
      if ((sVar13 == -1) ||
         (*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(param_2 + 0x20) + 0x1a09200) +
                   0x24cd188) != '\0')) {
        sVar13 = 0x1fa4;
      }
      func_0x(param_1,0x21);
      func_0x(param_1,sVar13);
      func_0x(param_1,0x15);
      uVar8 = (*pcRam00000000018b1b08)(*(undefined8 *)(param_2 + 0x20));
      func_0x(param_1,uVar8);
      func_0x(param_1,0x28);
      iVar10 = 0x59;
    }
    else {
      func_0x(param_1,0x28);
      iVar10 = func_0x(*param_1,param_1[1],0xb8,&uStackX_10);
      if (iVar10 == 1) {
        func_0x(0,1,0x15);
      }
      uVar9 = (uint)uStackX_10;
      func_0x(param_1,(uint)uStackX_10 & 0xff);
      func_0x(param_1,uVar9 >> 8 & 0xff);
      func_0x(param_1,uVar9 >> 0x10 & 0xff);
      func_0x(param_1,(char)(uVar9 >> 0x18));
      func_0x(param_1,0x28);
      iVar10 = 0xbb;
    }
    break;
  case 0x39:
    sVar13 = *(short *)(*(byte **)(param_2 + 0x20) + 0x10);
    if ((sVar13 == -1) ||
       (uVar12 = (ulonglong)**(byte **)(param_2 + 0x20),
       *(char *)((ulonglong)*(byte *)(uVar12 + 0x1a09200) + 0x24cd188) != '\0')) {
      func_0x(param_1,0x28);
      iVar10 = func_0x(*param_1,param_1[1],0xb1,&uStackX_10);
      if (iVar10 == 1) {
        func_0x(0,1,0x15);
      }
      uVar9 = (uint)uStackX_10;
      func_0x(param_1,(uint)uStackX_10 & 0xff);
      func_0x(param_1,uVar9 >> 8 & 0xff);
      func_0x(param_1,uVar9 >> 0x10 & 0xff);
      func_0x(param_1,(char)(uVar9 >> 0x18));
      func_0x(param_1,0x28);
      iVar10 = 0xb2;
    }
    else {
      if (*(char *)((ulonglong)*(byte *)(uVar12 + 0x1a09200) + 0x24cd188) != '\0') {
        sVar13 = 0x1fa4;
      }
      func_0x(param_1,0x21);
      func_0x(param_1,sVar13);
      sVar13 = *(short *)(*(byte **)(param_2 + 0x20) + 0x10);
      if ((sVar13 == -1) ||
         (*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(param_2 + 0x20) + 0x1a09200) +
                   0x24cd188) != '\0')) {
        sVar13 = 0x1fa4;
      }
      func_0x(param_1,0x21);
      func_0x(param_1,sVar13);
      func_0x(param_1,0x15);
      uVar8 = (*pcRam00000000018b1b08)(*(undefined8 *)(param_2 + 0x20));
      func_0x(param_1,uVar8);
      func_0x(param_1,0x28);
      iVar10 = 0x50;
    }
    break;
  case 0x42:
  case 0x43:
    uStackX_10 = 0;
    auStackX_18[0] = 0;
    func_0x(param_1,0x3a,&uStackX_10);
    uVar8 = *(undefined4 *)(param_1 + 0x14);
    func_0x(param_1,0x26);
    func_0x(param_1,param_2,3);
    func_0x(param_1,0x38,auStackX_18);
    func_0x(param_1,&uStackX_10,*(undefined4 *)param_1[10],((undefined4 *)param_1[10])[1]);
    *(undefined4 *)(param_1 + 0x14) = uVar8;
    func_0x(param_1,param_2,0);
    func_0x(param_1,param_2,2);
    func_0x(param_1,0x25);
    func_0x(param_1,0x48);
    func_0x(param_1,0x20);
    func_0x(param_1,0);
    func_0x(param_1,8);
    func_0x(param_1,0);
    func_0x(param_1,0);
    func_0x(param_1,0x60);
    func_0x(param_1,0x53);
    func_0x(param_1,0x1f);
    func_0x(param_1,0x18);
    func_0x(param_1,0x58);
    func_0x(param_1,uVar7);
    if (*(int *)(param_2 + 0x3c) == 0x42) {
      func_0x(param_1,0x6f);
      iVar10 = func_0x(*param_1,param_1[1],0xc6,&uStackX_10);
      if (iVar10 == 1) {
        func_0x(0,1,0x15);
      }
      uVar14 = uStackX_10;
      uVar9 = (uint)uStackX_10;
      func_0x(param_1,(uint)uStackX_10 & 0xff);
      func_0x(param_1,uVar9 >> 8 & 0xff);
      func_0x(param_1,uVar9 >> 0x10 & 0xff);
      func_0x(param_1,(char)((ulonglong)uVar14 >> 0x18));
    }
    func_0x(param_1,0x28);
    iVar10 = func_0x(*param_1,param_1[1],4,&uStackX_10);
    if (iVar10 == 1) {
      func_0x(0,1,0x15);
    }
    uVar14 = uStackX_10;
    uVar9 = (uint)uStackX_10;
    func_0x(param_1,(uint)uStackX_10 & 0xff);
    func_0x(param_1,uVar9 >> 8 & 0xff);
    func_0x(param_1,uVar9 >> 0x10 & 0xff);
    func_0x(param_1,(char)((ulonglong)uVar14 >> 0x18));
    func_0x(param_1,0x28);
    iVar10 = func_0x(*param_1,param_1[1],5,&uStackX_10);
    if (iVar10 == 1) {
      func_0x(0,1,0x15);
    }
    uVar14 = uStackX_10;
    uVar9 = (uint)uStackX_10;
    func_0x(param_1,(uint)uStackX_10 & 0xff);
    func_0x(param_1,uVar9 >> 8 & 0xff);
    func_0x(param_1,uVar9 >> 0x10 & 0xff);
    func_0x(param_1,(char)((ulonglong)uVar14 >> 0x18));
    func_0x(param_1,0x55);
    func_0x(param_1,auStackX_18,*(undefined4 *)param_1[10],((undefined4 *)param_1[10])[1]);
    goto code_r0x00100adf;
  }
  iVar10 = func_0x(*param_1,param_1[1],iVar10,&uStackX_10);
  if (iVar10 == 1) {
    func_0x(0,1,0x15);
  }
  func_0x(param_1,(uint)uStackX_10 & 0xff);
  func_0x(param_1,(uint)uStackX_10 >> 8 & 0xff);
  func_0x(param_1,(uint)uStackX_10 >> 0x10 & 0xff);
  func_0x(param_1,(char)((uint)uStackX_10 >> 0x18));
code_r0x00100adf:
  if (*(int *)(param_2 + 0x60) == -1) {
    puVar1 = (uint *)((ulonglong)uVar7 * 0x40 + 0x3c + param_1[0x10]);
    *puVar1 = *puVar1 | 1;
  }
  return;
}

