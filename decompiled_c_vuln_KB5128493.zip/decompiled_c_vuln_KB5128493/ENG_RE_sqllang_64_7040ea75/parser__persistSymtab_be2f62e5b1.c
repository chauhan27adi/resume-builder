
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined param_4)

{
  longlong lVar1;
  undefined8 uStack_128;
  longlong lStack_120;
  char *pcStack_118;
  undefined8 uStack_110;
  undefined4 uStack_104;
  undefined4 uStack_100;
  longlong lStack_f8;
  undefined8 uStack_f0;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  longlong lStack_d8;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  undefined auStack_b8 [16];
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined8 uStack_78;
  undefined auStack_68 [8];
  longlong *plStack_60;
  longlong *plStack_58;
  longlong lStack_50;
  
  uStack_78 = 0xfffffffffffffffe;
  uStack_104 = 0;
  uStack_100 = 0x28;
  lStack_f8 = 0;
  uStack_e4 = 0;
  uStack_e0 = 0x28;
  lStack_d8 = 0;
  pcStack_118 = *(char **)(param_1 + 0x60);
  auStack_b8 = ZEXT816(0);
  auStack_a8 = ZEXT816(0);
  auStack_98 = ZEXT816(0);
  uStack_c0 = 0;
  uStack_c8 = 0;
  auStack_88 = ZEXT816(0);
  *(undefined *)(param_1 + 0x594) = param_4;
  uStack_128 = param_3;
  lStack_120 = param_1;
  uStack_110 = param_3;
  uStack_f0 = param_3;
  func_0x(auStack_68,0,*(undefined8 *)(param_1 + 0x60));
  func_0x(auStack_68);
  pcStack_118 = *(char **)(lStack_120 + 0x60);
  lVar1 = lStack_120;
  do {
    auStack_88 = ZEXT816(0);
    auStack_98 = ZEXT816(0);
    auStack_a8 = ZEXT816(0);
    auStack_b8._8_8_ = 0;
    uStack_c8 = 0;
    auStack_b8._0_8_ = *(undefined8 *)(pcStack_118 + 0x80);
    while ((uint *)auStack_b8._0_8_ != (uint *)0x0) {
      switch(*(uint *)auStack_b8._0_8_ & 0xff) {
      case 2:
      case 7:
      case 10:
      case 0xb:
        goto code_r0x00100140;
      case 3:
        if ((*(byte *)(auStack_b8._0_8_ + 0x8c) & 1) == 0) goto code_r0x00100140;
      default:
        auStack_b8._0_8_ = *(uint **)(auStack_b8._0_8_ + 0x20);
        break;
      case 8:
        if ((*(byte *)(auStack_b8._0_8_ + 0x98) & 1) == 0) {
code_r0x00100140:
          if ((**(byte **)(auStack_b8._0_8_ + 0x10) & 1) == 0) {
code_r0x00100149:
            uStack_c0 = 0;
            func_0x(&uStack_128);
            func_0x(param_1,&uStack_128,0,0);
            auStack_b8._0_8_ = *(uint **)(auStack_b8._0_8_ + 0x20);
code_r0x00100176:
            while (lVar1 = lStack_120, (uint *)auStack_b8._0_8_ != (uint *)0x0) {
              switch(*(uint *)auStack_b8._0_8_ & 0xff) {
              case 2:
              case 7:
              case 10:
              case 0xb:
                goto code_r0x001001af;
              case 3:
                if ((*(byte *)(auStack_b8._0_8_ + 0x8c) & 1) == 0) goto code_r0x001001af;
              default:
                auStack_b8._0_8_ = *(uint **)(auStack_b8._0_8_ + 0x20);
                break;
              case 8:
                if ((*(byte *)(auStack_b8._0_8_ + 0x98) & 1) == 0) goto code_r0x001001af;
                auStack_b8._0_8_ = *(uint **)(auStack_b8._0_8_ + 0x20);
              }
            }
            goto LAB_;
          }
        }
        else {
          auStack_b8._0_8_ = *(uint **)(auStack_b8._0_8_ + 0x20);
        }
      }
    }
LAB_:
    if (pcStack_118 == *(char **)(lVar1 + 0x60)) {
      pcStack_118 = *(char **)(pcStack_118 + 0x80);
    }
    else {
      pcStack_118 = *(char **)(pcStack_118 + 0x20);
    }
    for (; (pcStack_118 != (char *)0x0 &&
           ((*pcStack_118 != '\x05' ||
            (*(longlong *)(pcStack_118 + 0x10) == *(longlong *)(lVar1 + 0x480)))));
        pcStack_118 = *(char **)(pcStack_118 + 0x20)) {
    }
    auStack_b8._0_8_ = 0;
    auStack_b8._8_8_ = 0;
    auStack_a8 = ZEXT816(0);
    auStack_98 = ZEXT816(0);
    uStack_c0 = 0;
    uStack_c8 = 0;
    auStack_88 = ZEXT816(0);
    if (pcStack_118 == (char *)0x0) {
      if (lStack_50 != 0) {
        (*_DAT_)(lStack_50,0x1f58);
      }
      (**(code **)(*plStack_60 + 0x10))();
      (**(code **)(*plStack_58 + 0x10))();
      uStack_e4 = 0;
      if (lStack_d8 != 0) {
        (*_DAT_)();
        lStack_d8 = 0;
      }
      uStack_e0 = 0;
      uStack_104 = 0;
      if (lStack_f8 != 0) {
        (*_DAT_)();
      }
      return;
    }
  } while( true );
code_r0x001001af:
  if ((**(byte **)(auStack_b8._0_8_ + 0x10) & 1) == 0) goto code_r0x00100149;
  goto code_r0x00100176;
}

