
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  longlong lVar1;
  char cVar2;
  longlong lVar3;
  longlong unaff_GS_OFFSET;
  
  lVar1 = *(longlong *)
           (*(longlong *)
             (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
              8 + (ulonglong)*_DAT_) + 0x48);
  lVar3 = lVar1 + -8;
  if (lVar1 == 0) {
    lVar3 = 0;
  }
  if (((*(byte *)(lVar3 + 0x69) & 1) == 0) &&
     (cVar2 = func_0x(*(undefined8 *)(param_1 + 0x20),lVar3), cVar2 != '\0')) {
    return;
  }
  func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x52);
  func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0xb0);
  func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x53);
  func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x5b);
  func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x55);
  if (*(int *)(param_1 + 0x3c) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x50);
  func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x67);
  func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x76);
  if (((*(int *)(param_1 + 0x3c) - 1U & 0xfffffffd) != 0) &&
     ((*(byte *)(_DAT_ + 0x44a) & 4) == 0)) {
    lVar1 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar1 != 0) && (**(longlong **)(lVar1 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),99);
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x66);
  }
  cVar2 = func_0x();
  if (((cVar2 != '\0') && (*(int *)(param_1 + 0x3c) != 2)) &&
     (func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x144),
     (*(byte *)(lVar3 + 0x69) & 4) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x3c) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x3c) != 2) {
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x5d);
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x5c);
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x5e);
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x5f);
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x180);
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x181);
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x68);
    func_0x(param_2,*(undefined8 *)(param_2 + 0x30),0x19f);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

