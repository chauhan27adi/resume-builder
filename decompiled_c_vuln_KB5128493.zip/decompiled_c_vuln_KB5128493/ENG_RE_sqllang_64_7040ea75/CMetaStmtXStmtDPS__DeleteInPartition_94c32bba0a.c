// NOTE: 1 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x000d1b7c) */

void FUN_(undefined8 param_1,undefined8 param_2,int param_3,undefined4 param_4)

{
  longlong lVar1;
  
  if (param_3 != -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = func_0x(param_1,param_4);
  if (lVar1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

